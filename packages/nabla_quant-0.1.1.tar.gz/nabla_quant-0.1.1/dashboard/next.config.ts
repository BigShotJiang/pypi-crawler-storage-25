import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Static export — generates a fully self-contained `out/` directory that
  // can be served by any static-file host, including the FastAPI backend via
  // StaticFiles.  All API + WebSocket calls go to the same-origin FastAPI
  // server (default: localhost:8000), so no CORS or proxy config is needed.
  output: "export",

  // Makes every page's output path end in /index.html which is required for
  // clean SPA-style navigation when served by StaticFiles with html=True.
  trailingSlash: true,
};

export default nextConfig;
