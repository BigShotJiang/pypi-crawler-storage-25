"""
nabla-quant command-line interface
===================================
Installed as the ``nabla`` console script.

Commands
--------
nabla price    -- price one option (European / American / Barrier)
nabla greeks   -- compute all 5 Greeks via AAD
nabla serve    -- start the FastAPI pricing server
nabla stress   -- run the 16-contract pipeline stress test
nabla version  -- print the installed version
"""

from __future__ import annotations

import argparse
import json
import sys


# ── helpers ──────────────────────────────────────────────────────────────────

def _engine():
    """Import nabla_quant; give a readable error if the C++ extension is missing."""
    try:
        import nabla_quant as nq
        return nq
    except ImportError as exc:
        sys.exit(
            f"[nabla] Cannot import the C++ extension: {exc}\n"
            "If you installed from source, make sure the build step completed:\n"
            "  cmake -B build -DCMAKE_BUILD_TYPE=Release -DNABLA_BUILD_PYTHON=ON\n"
            "  cmake --build build --parallel"
        )


def _print_result(label: str, result, *, json_out: bool) -> None:
    if json_out:
        d = {"price": result.price}
        print(json.dumps(d, indent=2))
    else:
        print(f"{label}")
        print(f"  price  = {result.price:.6f}")


def _print_greeks(g, *, json_out: bool) -> None:
    data = {
        "price": g.price,
        "delta": g.delta,
        "gamma": g.gamma,
        "theta": g.theta,
        "vega":  g.vega,
        "rho":   g.rho,
    }
    if json_out:
        print(json.dumps(data, indent=2))
    else:
        print(f"  price  = {g.price:>12.6f}")
        print(f"  delta  = {g.delta:>12.6f}")
        print(f"  gamma  = {g.gamma:>12.6f}")
        print(f"  theta  = {g.theta:>12.6f}")
        print(f"  vega   = {g.vega:>12.6f}")
        print(f"  rho    = {g.rho:>12.6f}")


# ── sub-command: price ────────────────────────────────────────────────────────

def _add_market_args(p: argparse.ArgumentParser) -> None:
    """Add the standard S/K/T/r/vol/q arguments to a sub-parser."""
    p.add_argument("--spot",   "-S", type=float, required=True,  help="Spot price")
    p.add_argument("--strike", "-K", type=float, required=True,  help="Strike price")
    p.add_argument("--expiry", "-T", type=float, required=True,  help="Time to expiry (years)")
    p.add_argument("--rate",   "-r", type=float, default=0.05,   help="Risk-free rate (default 0.05)")
    p.add_argument("--vol",    "-v", type=float, required=True,  help="Implied / flat volatility")
    p.add_argument("--div",    "-q", type=float, default=0.0,    help="Continuous dividend yield (default 0)")
    p.add_argument("--type",         type=str,   default="call",
                   choices=["call", "put"], help="Option type (default: call)")
    p.add_argument("--nodes",        type=int,   default=801,    help="PDE grid nodes (default 801)")
    p.add_argument("--steps",        type=int,   default=800,    help="Time steps (default 800)")
    p.add_argument("--json",         action="store_true",        help="Output as JSON")


def cmd_price(args: argparse.Namespace) -> None:
    nq = _engine()
    kw = dict(spot=args.spot, strike=args.strike, expiry=args.expiry,
              rate=args.rate, vol=args.vol, dividend=args.div,
              option_type=args.type,
              num_nodes=args.nodes, num_time_steps=args.steps)

    if args.american:
        label = f"American {args.type.upper()}  S={args.spot}  K={args.strike}  T={args.expiry}y"
        result = nq.american(**kw)
    elif args.barrier_level is not None:
        if args.barrier_dir is None or args.barrier_knock is None:
            sys.exit("--barrier-level requires --barrier-dir and --barrier-knock")
        label = (f"Barrier {args.barrier_dir}-{args.barrier_knock} {args.type.upper()}"
                 f"  S={args.spot}  K={args.strike}  B={args.barrier_level}  T={args.expiry}y")
        result = nq.barrier(**kw,
                            level=args.barrier_level,
                            direction=args.barrier_dir,
                            knock=args.barrier_knock)
    else:
        label = f"European {args.type.upper()}  S={args.spot}  K={args.strike}  T={args.expiry}y"
        result = nq.european(**kw)

    _print_result(label, result, json_out=args.json)


# ── sub-command: greeks ───────────────────────────────────────────────────────

def cmd_greeks(args: argparse.Namespace) -> None:
    nq = _engine()
    g = nq.greeks(spot=args.spot, strike=args.strike, expiry=args.expiry,
                  rate=args.rate, vol=args.vol, dividend=args.div,
                  option_type=args.type,
                  num_nodes=args.nodes, num_time_steps=args.steps)
    if not args.json:
        label = f"Greeks (AAD)  {args.type.upper()}  S={args.spot}  K={args.strike}  T={args.expiry}y  vol={args.vol}"
        print(label)
    _print_greeks(g, json_out=args.json)


# ── sub-command: serve ────────────────────────────────────────────────────────

def cmd_serve(args: argparse.Namespace) -> None:
    try:
        import uvicorn
    except ImportError:
        sys.exit("[nabla] uvicorn not found. Install it with: pip install uvicorn")

    from pathlib import Path
    static_dir = Path(__file__).parent / "dashboard_static"
    has_dashboard = static_dir.is_dir() and (static_dir / "index.html").exists()

    host_display = "localhost" if args.host in ("0.0.0.0", "::") else args.host
    base_url = f"http://{host_display}:{args.port}"

    print()
    print("  NablaQuant — Pricing Server")
    print(f"  Backend API : {base_url}/api/v1/health")
    print(f"  API docs    : {base_url}/docs")
    if has_dashboard:
        print(f"  Dashboard   : {base_url}/          ← open this in your browser")
    else:
        print("  Dashboard   : not bundled (run 'npm run dev' in dashboard/ from the repo)")
    print()

    if has_dashboard and not args.no_open:
        import threading, webbrowser
        def _open():
            import time; time.sleep(1.5)
            webbrowser.open(base_url)
        threading.Thread(target=_open, daemon=True).start()

    uvicorn.run(
        "nabla_quant.api.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=args.log_level,
    )


# ── sub-command: dashboard ───────────────────────────────────────────────────

def _find_dashboard_dir() -> "str | None":
    """Walk up from cwd and package dir looking for dashboard/package.json."""
    import os
    candidates = [
        # running from repo root
        os.path.join(os.getcwd(), "dashboard"),
        # running from python/ subdir
        os.path.join(os.getcwd(), "..", "dashboard"),
        # package installed; dashboard shipped alongside
        os.path.join(os.path.dirname(__file__), "..", "..", "dashboard"),
    ]
    for p in candidates:
        if os.path.isfile(os.path.join(p, "package.json")):
            return os.path.realpath(p)
    return None


def cmd_dashboard(args: argparse.Namespace) -> None:
    import os, shutil, subprocess, signal, threading, time, webbrowser

    # ── locate dashboard ──
    dash_dir = _find_dashboard_dir()
    if dash_dir is None:
        sys.exit(
            "[nabla] dashboard/ directory not found.\n"
            "Run this command from the NablaQuant repo root, or ensure\n"
            "the repo is cloned alongside the Python package."
        )

    # ── check npm is available ──
    npm_cmd = "npm.cmd" if sys.platform == "win32" else "npm"
    if shutil.which(npm_cmd) is None:
        sys.exit(
            "[nabla] npm not found on PATH.\n"
            "Install Node.js (https://nodejs.org) to run the live dashboard.\n"
            "Alternatively, use 'nabla serve' for the bundled static dashboard."
        )

    # ── check / install node_modules ──
    if not os.path.isdir(os.path.join(dash_dir, "node_modules")):
        print("[nabla] node_modules not found — running npm install (one-time, ~30s)…")
        r = subprocess.run([npm_cmd, "install"], cwd=dash_dir)
        if r.returncode != 0:
            sys.exit("[nabla] npm install failed.")

    fe_port = args.fe_port
    be_port = args.be_port
    host    = args.host

    print()
    print("  NablaQuant — Full-Stack Dashboard")
    print(f"  Backend (FastAPI + WS) : http://localhost:{be_port}")
    print(f"  Frontend (Next.js)     : http://localhost:{fe_port}  ← open this")
    print()
    print("  Press Ctrl-C to stop both servers.")
    print()

    # ── start Next.js dev server as a subprocess ──
    env = os.environ.copy()
    env["NEXT_PUBLIC_API_URL"] = f"http://localhost:{be_port}"
    env["NEXT_PUBLIC_WS_URL"]  = f"ws://localhost:{be_port}/ws/pricing"

    npm_proc = subprocess.Popen(
        [npm_cmd, "run", "dev", "--", "-p", str(fe_port)],
        cwd=dash_dir, env=env,
    )

    # ── auto-open browser once Next.js is ready ──
    def _wait_and_open():
        import urllib.request
        for _ in range(30):
            time.sleep(1)
            try:
                urllib.request.urlopen(f"http://localhost:{fe_port}", timeout=1)
                if not args.no_open:
                    webbrowser.open(f"http://localhost:{fe_port}")
                break
            except Exception:
                pass

    threading.Thread(target=_wait_and_open, daemon=True).start()

    # ── start FastAPI in the foreground (Ctrl-C kills both) ──
    try:
        import uvicorn
    except ImportError:
        npm_proc.terminate()
        sys.exit("[nabla] uvicorn not found. Install it with: pip install uvicorn")

    def _cleanup(sig, frame):
        print("\n[nabla] Shutting down…")
        npm_proc.terminate()
        sys.exit(0)

    signal.signal(signal.SIGINT, _cleanup)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, _cleanup)

    try:
        uvicorn.run(
            "nabla_quant.api.app:app",
            host=host,
            port=be_port,
            log_level=args.log_level,
        )
    finally:
        npm_proc.terminate()


# ── sub-command: stress ───────────────────────────────────────────────────────

def cmd_stress(args: argparse.Namespace) -> None:
    import importlib.util, os, runpy, sys as _sys
    # Locate stress_pipeline.py relative to this file's package root
    here = os.path.dirname(__file__)
    candidates = [
        os.path.join(here, "..", "tests", "stress_pipeline.py"),
        os.path.join(here, "..", "..", "tests", "stress_pipeline.py"),
    ]
    script = next((p for p in candidates if os.path.isfile(p)), None)
    if script is None:
        sys.exit(
            "[nabla] stress_pipeline.py not found.\n"
            "Run it directly:  PYTHONPATH=python python python/tests/stress_pipeline.py"
        )
    runpy.run_path(os.path.abspath(script), run_name="__main__")


# ── sub-command: version ──────────────────────────────────────────────────────

def cmd_version(args: argparse.Namespace) -> None:
    from nabla_quant import __version__
    print(f"nabla-quant {__version__}")


# ── entry point ───────────────────────────────────────────────────────────────

def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="nabla",
        description="NablaQuant — High-Performance PDE Option Pricing Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  nabla dashboard                        # full stack: Next.js :3000 + API :8000
  nabla serve                            # API + bundled static dashboard :8000
  nabla price  --spot 100 --strike 100 --expiry 1.0 --vol 0.20
  nabla price  --spot 100 --strike 100 --expiry 1.0 --vol 0.20 --american
  nabla price  --spot 100 --strike 100 --expiry 1.0 --vol 0.20 \\
               --barrier-level 80 --barrier-dir down --barrier-knock out
  nabla greeks --spot 100 --strike 100 --expiry 1.0 --vol 0.20 --json
  nabla stress
""",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    # ── price ──
    p_price = sub.add_parser("price", help="Price a single option")
    _add_market_args(p_price)
    p_price.add_argument("--american", action="store_true",
                         help="American-style early exercise")
    p_price.add_argument("--barrier-level",  type=float, default=None,
                         metavar="B",  help="Barrier level")
    p_price.add_argument("--barrier-dir",    type=str,   default=None,
                         choices=["up", "down"], metavar="DIR",
                         help="Barrier direction: up or down")
    p_price.add_argument("--barrier-knock",  type=str,   default=None,
                         choices=["in", "out"], metavar="KNOCK",
                         help="Barrier knock: in or out")
    p_price.set_defaults(func=cmd_price)

    # ── greeks ──
    p_greeks = sub.add_parser("greeks", help="Compute all Greeks via AAD")
    _add_market_args(p_greeks)
    p_greeks.set_defaults(func=cmd_greeks)

    # ── serve ──
    p_serve = sub.add_parser("serve", help="Start the FastAPI pricing server")
    p_serve.add_argument("--host",      default="0.0.0.0")
    p_serve.add_argument("--port",      type=int, default=8000)
    p_serve.add_argument("--reload",    action="store_true",
                         help="Auto-reload on code changes (dev mode)")
    p_serve.add_argument("--log-level", default="info",
                         choices=["debug", "info", "warning", "error"])
    p_serve.add_argument("--no-open", action="store_true",
                         help="Do not auto-open the dashboard in the browser")
    p_serve.set_defaults(func=cmd_serve)

    # ── dashboard ──
    p_dash = sub.add_parser(
        "dashboard",
        help="Launch the full-stack dashboard (FastAPI backend + Next.js frontend)",
    )
    p_dash.add_argument("--fe-port",  type=int, default=3000,
                        help="Next.js dev-server port (default 3000)")
    p_dash.add_argument("--be-port",  type=int, default=8000,
                        help="FastAPI backend port (default 8000)")
    p_dash.add_argument("--host",     default="0.0.0.0",
                        help="Backend bind host (default 0.0.0.0)")
    p_dash.add_argument("--log-level", default="info",
                        choices=["debug", "info", "warning", "error"])
    p_dash.add_argument("--no-open",  action="store_true",
                        help="Do not auto-open the browser")
    p_dash.set_defaults(func=cmd_dashboard)

    # ── stress ──
    p_stress = sub.add_parser("stress", help="Run the 16-contract pipeline stress test")
    p_stress.set_defaults(func=cmd_stress)

    # ── version ──
    p_ver = sub.add_parser("version", help="Print installed version")
    p_ver.set_defaults(func=cmd_version)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
