"""
NablaQuant - High-Performance PDE Option Pricing Engine

Python SDK wrapping the C++ core via pybind11. Provides both low-level access
to the PDE solver components and high-level convenience functions for common
pricing workflows.

Low-level (direct C++ bindings):
    from nabla_quant import _nabla_core as core
    mesh = core.SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=801, concentration=12.5)

High-level:
    import nabla_quant as nq
    result = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
    greeks = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
"""

import os as _os
import sys as _sys

# On Windows with MinGW-built extensions, the C++ runtime DLLs need to be
# discoverable. We auto-detect the compiler's bin directory from PATH.
if _sys.platform == "win32":
    for _p in _os.environ.get("PATH", "").split(_os.pathsep):
        if _os.path.isfile(_os.path.join(_p, "libstdc++-6.dll")):
            try:
                _os.add_dll_directory(_p)
            except OSError:
                pass
            break

from nabla_quant._nabla_core import (
    OptionType,
    ExerciseType,
    BoundaryType,
    BarrierDirection,
    BarrierKnock,
    MarketParams,
    ContractParams,
    SinhMesh,
    BoundaryConditions,
    LocalVolSurface,
    CrankNicolsonSolver,
    PricingResult,
    GreeksResult,
    BumpGreeks,
    GreeksCalculator,
    BarrierParams,
    BarrierPricingResult,
    BarrierPricer,
)

try:
    from importlib.metadata import version as _meta_version
    __version__ = _meta_version("nabla-quant")
except Exception:
    __version__ = "0.1.1"  # fallback for local dev / editable installs

_OPTION_TYPE_MAP = {"call": OptionType.Call, "put": OptionType.Put}
_DIRECTION_MAP = {"up": BarrierDirection.Up, "down": BarrierDirection.Down}
_KNOCK_MAP = {"out": BarrierKnock.Out, "in": BarrierKnock.In}


def _parse_option_type(s):
    if isinstance(s, OptionType):
        return s
    key = s.strip().lower()
    if key not in _OPTION_TYPE_MAP:
        raise ValueError(f"option_type must be 'call' or 'put', got '{s}'")
    return _OPTION_TYPE_MAP[key]


def _build_mesh(strike, spot=None, s_max_mult=4.0, num_nodes=801, concentration=None):
    conc = concentration if concentration is not None else strike / 8.0
    # Ensure the grid covers both strike*mult and the current spot (with headroom).
    # Without this, if spot >> strike the PDE interpolation lands outside the grid.
    s_max = s_max_mult * strike
    if spot is not None and spot > 0:
        s_max = max(s_max, spot * 1.5)
    return SinhMesh(
        strike=strike,
        s_min=0.0,
        s_max=s_max,
        num_nodes=num_nodes,
        concentration=conc,
    )


def _build_vol_surface(vol, vol_model=None, vol_params=None, spot=None, strike=None):
    if vol_model is None or vol_model == "flat":
        return None
    params = vol_params or {}
    if vol_model == "cev":
        beta = params.get("beta", 0.5)
        s_ref = params.get("s_ref", spot or 100.0)
        return LocalVolSurface.cev(vol, s_ref, beta)
    if vol_model == "skew":
        skew = params.get("skew_coeff", -0.1)
        term = params.get("term_slope", 0.0)
        k = params.get("strike", strike or 100.0)
        return LocalVolSurface.skew(vol, k, skew, term)
    raise ValueError(f"Unknown vol_model '{vol_model}'. Use 'flat', 'cev', or 'skew'.")


def european(
    spot,
    strike,
    expiry,
    rate,
    vol,
    option_type="call",
    dividend=0.0,
    num_nodes=801,
    num_time_steps=800,
    concentration=None,
    vol_model=None,
    vol_params=None,
):
    """Price a European option via Crank-Nicolson PDE.

    Returns a PricingResult with .price and .grid attributes.
    """
    ot = _parse_option_type(option_type)
    mkt = MarketParams(spot=spot, rate=rate, volatility=vol, dividend=dividend)
    con = ContractParams(strike=strike, expiry=expiry, type=ot)
    mesh = _build_mesh(strike, spot=spot, num_nodes=num_nodes, concentration=concentration)
    bc = BoundaryConditions(con, mkt, mesh)

    vol_surface = _build_vol_surface(vol, vol_model, vol_params, spot, strike)
    if vol_surface is not None:
        solver = CrankNicolsonSolver(mesh, bc, num_time_steps, vol_surface)
    else:
        solver = CrankNicolsonSolver(mesh, bc, num_time_steps)
    return solver.solve()


def american(
    spot,
    strike,
    expiry,
    rate,
    vol,
    option_type="put",
    dividend=0.0,
    num_nodes=801,
    num_time_steps=800,
    concentration=None,
    vol_model=None,
    vol_params=None,
):
    """Price an American option via Crank-Nicolson PDE with early-exercise projection.

    Returns a PricingResult with .price and .grid attributes.
    """
    ot = _parse_option_type(option_type)
    mkt = MarketParams(spot=spot, rate=rate, volatility=vol, dividend=dividend)
    con = ContractParams(
        strike=strike, expiry=expiry, type=ot, exercise=ExerciseType.American
    )
    mesh = _build_mesh(strike, spot=spot, num_nodes=num_nodes, concentration=concentration)
    bc = BoundaryConditions(con, mkt, mesh)

    vol_surface = _build_vol_surface(vol, vol_model, vol_params, spot, strike)
    if vol_surface is not None:
        solver = CrankNicolsonSolver(mesh, bc, num_time_steps, vol_surface)
    else:
        solver = CrankNicolsonSolver(mesh, bc, num_time_steps)
    return solver.solve()


def barrier(
    spot,
    strike,
    expiry,
    rate,
    vol,
    option_type="call",
    level=None,
    direction="down",
    knock="out",
    rebate=0.0,
    dividend=0.0,
    num_nodes=801,
    num_time_steps=800,
    concentration=None,
    vol_model=None,
    vol_params=None,
):
    """Price a barrier option via Crank-Nicolson PDE with absorbing boundaries.

    Returns a BarrierPricingResult with .price and .grid attributes.
    """
    if level is None:
        raise ValueError("barrier level is required")

    ot = _parse_option_type(option_type)
    mkt = MarketParams(spot=spot, rate=rate, volatility=vol, dividend=dividend)
    con = ContractParams(strike=strike, expiry=expiry, type=ot)
    mesh = _build_mesh(strike, spot=spot, num_nodes=num_nodes, concentration=concentration)
    bc = BoundaryConditions(con, mkt, mesh)

    if isinstance(direction, BarrierDirection):
        d = direction
    else:
        key = direction.strip().lower()
        if key not in _DIRECTION_MAP:
            raise ValueError(f"direction must be 'up' or 'down', got '{direction}'")
        d = _DIRECTION_MAP[key]

    if isinstance(knock, BarrierKnock):
        k = knock
    else:
        key = knock.strip().lower()
        if key not in _KNOCK_MAP:
            raise ValueError(f"knock must be 'in' or 'out', got '{knock}'")
        k = _KNOCK_MAP[key]

    bp = BarrierParams(level=level, direction=d, knock=k, rebate=rebate)

    vol_surface = _build_vol_surface(vol, vol_model, vol_params, spot, strike)
    if vol_surface is not None:
        pricer = BarrierPricer(mesh, bc, bp, num_time_steps, vol_surface)
    else:
        pricer = BarrierPricer(mesh, bc, bp, num_time_steps)
    return pricer.solve()


def greeks(
    spot,
    strike,
    expiry,
    rate,
    vol,
    option_type="call",
    dividend=0.0,
    num_nodes=801,
    num_time_steps=800,
    concentration=None,
):
    """Compute all Greeks via spatial derivatives + AAD (Vega, Rho).

    Returns a GreeksResult with .price, .delta, .gamma, .theta, .vega, .rho,
    .delta_surface, .gamma_surface attributes.
    """
    ot = _parse_option_type(option_type)
    mkt = MarketParams(spot=spot, rate=rate, volatility=vol, dividend=dividend)
    con = ContractParams(strike=strike, expiry=expiry, type=ot)
    mesh = _build_mesh(strike, spot=spot, num_nodes=num_nodes, concentration=concentration)
    bc = BoundaryConditions(con, mkt, mesh)
    calc = GreeksCalculator(mesh, bc, num_time_steps)
    return calc.compute()


def bump_greeks(
    spot,
    strike,
    expiry,
    rate,
    vol,
    option_type="call",
    dividend=0.0,
    num_nodes=801,
    num_time_steps=800,
    concentration=None,
):
    """Compute Greeks via bump-and-revalue (reference method).

    Returns a BumpGreeks with .delta, .gamma, .vega, .rho, .theta attributes.
    """
    ot = _parse_option_type(option_type)
    mkt = MarketParams(spot=spot, rate=rate, volatility=vol, dividend=dividend)
    con = ContractParams(strike=strike, expiry=expiry, type=ot)
    mesh = _build_mesh(strike, spot=spot, num_nodes=num_nodes, concentration=concentration)
    return GreeksCalculator.bump_and_revalue(mesh, con, mkt, num_time_steps)


__all__ = [
    # High-level functions
    "european",
    "american",
    "barrier",
    "greeks",
    "bump_greeks",
    # Core types
    "OptionType",
    "ExerciseType",
    "BoundaryType",
    "BarrierDirection",
    "BarrierKnock",
    "MarketParams",
    "ContractParams",
    "SinhMesh",
    "BoundaryConditions",
    "LocalVolSurface",
    "CrankNicolsonSolver",
    "PricingResult",
    "GreeksResult",
    "BumpGreeks",
    "GreeksCalculator",
    "BarrierParams",
    "BarrierPricingResult",
    "BarrierPricer",
]
