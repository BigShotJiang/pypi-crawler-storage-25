"""FastAPI application for the NablaQuant pricing engine."""

from __future__ import annotations

import asyncio
import json
import time
from concurrent.futures import ThreadPoolExecutor
from functools import partial

import numpy as np
from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

import nabla_quant as nq

from .market_data import (
    fetch_chain_sync,
    fetch_quote_sync,
    fetch_vol_surface_sync,
    list_expiries_sync,
    yfinance_available,
)
from .models import (
    AmericanRequest,
    BarrierRequest,
    BarrierResponse,
    BatchPricingRequest,
    BatchPricingResponse,
    GreeksRequest,
    GreeksResponse,
    HealthResponse,
    LocalVolPricingRequest,
    MarketChainResponse,
    MarketExpiriesResponse,
    MarketQuoteResponse,
    MarketVolSurfaceResponse,
    PricingRequest,
    PricingResponse,
)

_executor = ThreadPoolExecutor(max_workers=4)


def _run_european(req: PricingRequest) -> PricingResponse:
    result = nq.european(
        spot=req.spot,
        strike=req.strike,
        expiry=req.expiry,
        rate=req.rate,
        vol=req.volatility,
        option_type=req.option_type.value,
        dividend=req.dividend,
        num_nodes=req.num_nodes,
        num_time_steps=req.num_time_steps,
        concentration=req.concentration,
    )
    return PricingResponse(
        price=result.price,
        time_steps=result.time_steps,
        spatial_nodes=result.spatial_nodes,
    )


def _run_american(req: AmericanRequest) -> PricingResponse:
    result = nq.american(
        spot=req.spot,
        strike=req.strike,
        expiry=req.expiry,
        rate=req.rate,
        vol=req.volatility,
        option_type=req.option_type.value,
        dividend=req.dividend,
        num_nodes=req.num_nodes,
        num_time_steps=req.num_time_steps,
        concentration=req.concentration,
    )
    return PricingResponse(
        price=result.price,
        time_steps=result.time_steps,
        spatial_nodes=result.spatial_nodes,
    )


def _run_barrier(req: BarrierRequest) -> BarrierResponse:
    result = nq.barrier(
        spot=req.spot,
        strike=req.strike,
        expiry=req.expiry,
        rate=req.rate,
        vol=req.volatility,
        option_type=req.option_type.value,
        level=req.barrier_level,
        direction=req.barrier_direction.value,
        knock=req.barrier_knock.value,
        rebate=req.rebate,
        dividend=req.dividend,
        num_nodes=req.num_nodes,
        num_time_steps=req.num_time_steps,
        concentration=req.concentration,
    )
    return BarrierResponse(
        price=result.price,
        time_steps=result.time_steps,
        spatial_nodes=result.spatial_nodes,
    )


def _run_greeks(req: GreeksRequest) -> GreeksResponse:
    result = nq.greeks(
        spot=req.spot,
        strike=req.strike,
        expiry=req.expiry,
        rate=req.rate,
        vol=req.volatility,
        option_type=req.option_type.value,
        dividend=req.dividend,
        num_nodes=req.num_nodes,
        num_time_steps=req.num_time_steps,
        concentration=req.concentration,
    )
    return GreeksResponse(
        price=result.price,
        delta=result.delta,
        gamma=result.gamma,
        theta=result.theta,
        vega=result.vega,
        rho=result.rho,
    )


def _run_local_vol(req: LocalVolPricingRequest) -> PricingResponse:
    vol_model = req.vol_surface.model.value
    vol_params = {}
    if vol_model == "cev":
        vol_params["beta"] = req.vol_surface.beta
        if req.vol_surface.s_ref is not None:
            vol_params["s_ref"] = req.vol_surface.s_ref
    elif vol_model == "skew":
        vol_params["skew_coeff"] = req.vol_surface.skew_coeff
        vol_params["term_slope"] = req.vol_surface.term_slope

    result = nq.european(
        spot=req.spot,
        strike=req.strike,
        expiry=req.expiry,
        rate=req.rate,
        vol=req.volatility,
        option_type=req.option_type.value,
        dividend=req.dividend,
        num_nodes=req.num_nodes,
        num_time_steps=req.num_time_steps,
        concentration=req.concentration,
        vol_model=vol_model if vol_model != "flat" else None,
        vol_params=vol_params if vol_params else None,
    )
    return PricingResponse(
        price=result.price,
        time_steps=result.time_steps,
        spatial_nodes=result.spatial_nodes,
    )


def _compute_surface(params: dict) -> dict:
    """Compute option value surface V(S, T)."""
    spot = params["spot"]
    strike = params["strike"]
    rate = params["rate"]
    vol = params["volatility"]
    opt = params.get("option_type", "call")
    div = params.get("dividend", 0.0)
    num_nodes = params.get("num_nodes", 201)
    num_time_steps = params.get("num_time_steps", 500)

    spot_lo = params.get("spot_range", [spot * 0.5, spot * 1.5])[0]
    spot_hi = params.get("spot_range", [spot * 0.5, spot * 1.5])[1]
    exp_lo = params.get("expiry_range", [0.05, params["expiry"]])[0]
    exp_hi = params.get("expiry_range", [0.05, params["expiry"]])[1]
    spot_steps = params.get("spot_steps", 30)
    expiry_steps = params.get("expiry_steps", 20)

    spots = np.linspace(spot_lo, spot_hi, spot_steps).tolist()
    expiries = np.linspace(exp_lo, exp_hi, expiry_steps).tolist()
    values = []
    for T in expiries:
        row = []
        for S in spots:
            r = nq.european(spot=S, strike=strike, expiry=T, rate=rate, vol=vol,
                            option_type=opt, dividend=div,
                            num_nodes=num_nodes, num_time_steps=num_time_steps)
            row.append(round(r.price, 4))
        values.append(row)
    return {"spots": spots, "expiries": expiries, "values": values}


def _compute_greeks_grid(params: dict) -> dict:
    """Compute Greeks over a (S, T) grid."""
    spot = params["spot"]
    strike = params["strike"]
    rate = params["rate"]
    vol = params["volatility"]
    opt = params.get("option_type", "call")
    div = params.get("dividend", 0.0)
    num_nodes = params.get("num_nodes", 201)
    num_time_steps = params.get("num_time_steps", 500)

    spot_lo = params.get("spot_range", [spot * 0.5, spot * 1.5])[0]
    spot_hi = params.get("spot_range", [spot * 0.5, spot * 1.5])[1]
    exp_lo = params.get("expiry_range", [0.05, params["expiry"]])[0]
    exp_hi = params.get("expiry_range", [0.05, params["expiry"]])[1]
    spot_steps = params.get("spot_steps", 30)
    expiry_steps = params.get("expiry_steps", 20)

    spots = np.linspace(spot_lo, spot_hi, spot_steps).tolist()
    expiries = np.linspace(exp_lo, exp_hi, expiry_steps).tolist()
    grids = {k: [] for k in ("delta", "gamma", "theta", "vega", "rho")}
    for T in expiries:
        row = {k: [] for k in grids}
        for S in spots:
            g = nq.greeks(spot=S, strike=strike, expiry=T, rate=rate, vol=vol,
                          option_type=opt, dividend=div,
                          num_nodes=num_nodes, num_time_steps=num_time_steps)
            row["delta"].append(round(g.delta, 6))
            row["gamma"].append(round(g.gamma, 6))
            row["theta"].append(round(g.theta, 4))
            row["vega"].append(round(g.vega, 4))
            row["rho"].append(round(g.rho, 4))
        for k in grids:
            grids[k].append(row[k])
    return {"spots": spots, "expiries": expiries, **grids}


def _compute_vol_surface(params: dict) -> dict:
    """Compute implied volatility surface.

    If a market_symbol is provided and yfinance is available, calibrates from
    real option chain IVs. Otherwise falls back to parametric skew model.
    """
    spot = params["spot"]
    strike = params["strike"]
    base_vol = params["volatility"]

    market_symbol = params.get("market_symbol")
    if market_symbol and yfinance_available():
        try:
            mkt = fetch_vol_surface_sync(market_symbol, max_expiries=6)
            return {
                "spots": mkt["strikes"],
                "expiries": mkt["expiries"],
                "vols": [
                    [v if v is not None else base_vol for v in row]
                    for row in mkt["vols"]
                ],
                "source": "market",
            }
        except Exception:
            pass  # fall through to parametric

    spot_lo = params.get("spot_range", [spot * 0.5, spot * 1.5])[0]
    spot_hi = params.get("spot_range", [spot * 0.5, spot * 1.5])[1]
    exp_lo = params.get("expiry_range", [0.05, params["expiry"]])[0]
    exp_hi = params.get("expiry_range", [0.05, params["expiry"]])[1]
    spot_steps = params.get("spot_steps", 30)
    expiry_steps = params.get("expiry_steps", 20)

    spots = np.linspace(spot_lo, spot_hi, spot_steps).tolist()
    expiries = np.linspace(exp_lo, exp_hi, expiry_steps).tolist()

    skew_coeff = -0.15
    term_slope = 0.02
    vols = []
    for T in expiries:
        row = []
        for S in spots:
            moneyness = np.log(S / strike)
            local_vol = base_vol + skew_coeff * moneyness + term_slope * np.sqrt(T)
            row.append(round(max(0.01, local_vol), 4))
        vols.append(row)
    return {"spots": spots, "expiries": expiries, "vols": vols, "source": "parametric"}


def _sanitize(v: float, precision: int = 4) -> float | None:
    """Round a float and return None for inf/nan so JSON stays valid."""
    import math
    if not math.isfinite(v):
        return None
    return round(v, precision)


def _compute_single(params: dict) -> dict:
    """Single price + all Greeks."""
    g = nq.greeks(
        spot=params["spot"], strike=params["strike"],
        expiry=params["expiry"], rate=params["rate"],
        vol=params["volatility"],
        option_type=params.get("option_type", "call"),
        dividend=params.get("dividend", 0.0),
        num_nodes=params.get("num_nodes", 201),
        num_time_steps=params.get("num_time_steps", 500),
    )
    return {
        "price": _sanitize(g.price, 4),
        "delta": _sanitize(g.delta, 6),
        "gamma": _sanitize(g.gamma, 6),
        "theta": _sanitize(g.theta, 4),
        "vega": _sanitize(g.vega, 4),
        "rho": _sanitize(g.rho, 4),
    }


def create_app() -> FastAPI:
    app = FastAPI(
        title="NablaQuant Pricing API",
        description="Low-latency PDE option pricing engine with AAD Greeks",
        version=nq.__version__,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/api/v1/health", response_model=HealthResponse)
    async def health():
        return HealthResponse(
            status="ok",
            version=nq.__version__,
            engine="NablaQuant C++ PDE (Crank-Nicolson + AAD)",
        )

    @app.post("/api/v1/price/european", response_model=PricingResponse)
    async def price_european(req: PricingRequest):
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(_executor, partial(_run_european, req))
        except (ValueError, RuntimeError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.post("/api/v1/price/american", response_model=PricingResponse)
    async def price_american(req: AmericanRequest):
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(_executor, partial(_run_american, req))
        except (ValueError, RuntimeError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.post("/api/v1/price/barrier", response_model=BarrierResponse)
    async def price_barrier(req: BarrierRequest):
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(_executor, partial(_run_barrier, req))
        except (ValueError, RuntimeError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.post("/api/v1/greeks", response_model=GreeksResponse)
    async def compute_greeks(req: GreeksRequest):
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(_executor, partial(_run_greeks, req))
        except (ValueError, RuntimeError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.post("/api/v1/price/local_vol", response_model=PricingResponse)
    async def price_local_vol(req: LocalVolPricingRequest):
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(_executor, partial(_run_local_vol, req))
        except (ValueError, RuntimeError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.post("/api/v1/price/batch", response_model=BatchPricingResponse)
    async def price_batch(req: BatchPricingRequest):
        loop = asyncio.get_event_loop()
        tasks = [
            loop.run_in_executor(_executor, partial(_run_european, r))
            for r in req.requests
        ]
        try:
            results = await asyncio.gather(*tasks)
        except (ValueError, RuntimeError) as e:
            raise HTTPException(status_code=400, detail=str(e))
        return BatchPricingResponse(results=list(results), total_count=len(results))

    @app.get("/api/v1/market/quote", response_model=MarketQuoteResponse)
    async def market_quote(symbol: str = Query(..., min_length=1, max_length=12)):
        if not yfinance_available():
            raise HTTPException(
                status_code=503,
                detail="Market data requires yfinance: pip install yfinance",
            )
        loop = asyncio.get_event_loop()
        try:
            data = await loop.run_in_executor(_executor, partial(fetch_quote_sync, symbol))
            return MarketQuoteResponse(**data)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e)) from e

    @app.get("/api/v1/market/expiries", response_model=MarketExpiriesResponse)
    async def market_expiries(symbol: str = Query(..., min_length=1, max_length=12)):
        if not yfinance_available():
            raise HTTPException(
                status_code=503,
                detail="Market data requires yfinance: pip install yfinance",
            )
        loop = asyncio.get_event_loop()
        try:
            data = await loop.run_in_executor(_executor, partial(list_expiries_sync, symbol))
            return MarketExpiriesResponse(**data)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e)) from e

    @app.get("/api/v1/market/chain", response_model=MarketChainResponse)
    async def market_chain(
        symbol: str = Query(..., min_length=1, max_length=12),
        expiration: str = Query(..., min_length=8, max_length=16),
    ):
        if not yfinance_available():
            raise HTTPException(
                status_code=503,
                detail="Market data requires yfinance: pip install yfinance",
            )
        loop = asyncio.get_event_loop()
        try:
            data = await loop.run_in_executor(
                _executor, partial(fetch_chain_sync, symbol, expiration)
            )
            return MarketChainResponse(**data)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e)) from e

    @app.get("/api/v1/market/vol_surface", response_model=MarketVolSurfaceResponse)
    async def market_vol_surface(
        symbol: str = Query(..., min_length=1, max_length=12),
        max_expiries: int = Query(6, ge=2, le=12),
    ):
        if not yfinance_available():
            raise HTTPException(
                status_code=503,
                detail="Market data requires yfinance: pip install yfinance",
            )
        loop = asyncio.get_event_loop()
        try:
            data = await loop.run_in_executor(
                _executor, partial(fetch_vol_surface_sync, symbol, max_expiries)
            )
            return MarketVolSurfaceResponse(**data)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e)) from e

    @app.websocket("/ws/pricing")
    async def ws_pricing(ws: WebSocket):
        await ws.accept()
        loop = asyncio.get_event_loop()
        try:
            while True:
                raw = await ws.receive_text()
                msg = json.loads(raw)
                req_type = msg.get("type", "single_price")
                params = msg.get("params", {})

                t0 = time.perf_counter()
                dispatch = {
                    "single_price": _compute_single,
                    "surface": _compute_surface,
                    "greeks_surface": _compute_greeks_grid,
                    "vol_surface": _compute_vol_surface,
                }
                fn = dispatch.get(req_type)
                if fn is None:
                    await ws.send_json(
                        {
                            "type": "error",
                            "data": f"Unknown type: {req_type}",
                            "compute_time_ms": 0,
                            "request_id": msg.get("request_id"),
                        }
                    )
                    continue

                merged = {**params}
                for k in ("spot_range", "expiry_range", "spot_steps", "expiry_steps"):
                    if k in msg:
                        merged[k] = msg[k]

                try:
                    data = await loop.run_in_executor(_executor, partial(fn, merged))
                except Exception as e:
                    await ws.send_json(
                        {
                            "type": "error",
                            "data": str(e),
                            "compute_time_ms": 0,
                            "request_id": msg.get("request_id"),
                        }
                    )
                    continue

                elapsed = (time.perf_counter() - t0) * 1000
                await ws.send_json(
                    {
                        "type": req_type,
                        "data": data,
                        "compute_time_ms": round(elapsed, 1),
                        "request_id": msg.get("request_id"),
                    }
                )
        except WebSocketDisconnect:
            pass

    return app


app = create_app()

# ── Static dashboard ──────────────────────────────────────────────────────────
# Mount the pre-built Next.js static export so that `nabla serve` (or direct
# uvicorn) serves the full dashboard at http://localhost:PORT/ with zero extra
# dependencies.  Placed AFTER all API/WS route registrations so the API always
# takes precedence.  html=True makes the StaticFiles handler return index.html
# for any path it can't resolve, enabling SPA client-side routing.
from pathlib import Path as _Path
from fastapi.staticfiles import StaticFiles as _StaticFiles

_STATIC_DIR = _Path(__file__).parent.parent / "dashboard_static"
if _STATIC_DIR.is_dir():
    app.mount("/", _StaticFiles(directory=str(_STATIC_DIR), html=True), name="dashboard")
