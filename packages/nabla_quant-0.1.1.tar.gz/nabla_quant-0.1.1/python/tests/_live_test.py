"""
Live integration test against a running nabla serve instance.
Run with: PYTHONPATH=python python python/tests/_live_test.py
"""
import httpx, json, sys, asyncio, websockets

BASE = "http://localhost:8000"
WS   = "ws://localhost:8000/ws/pricing"
ok = 0; fail = 0

def check(label, resp, expected_keys=None, status=200):
    global ok, fail
    if resp.status_code != status:
        print(f"  FAIL [{label}] HTTP {resp.status_code}: {resp.text[:120]}")
        fail += 1; return None
    d = resp.json()
    if expected_keys:
        missing = [k for k in expected_keys if k not in d]
        if missing:
            print(f"  FAIL [{label}] missing keys: {missing}")
            fail += 1; return None
    preview = {k: round(d[k], 4) if isinstance(d.get(k), float) else d[k]
               for k in (expected_keys or list(d)[:3])}
    print(f"  PASS [{label}]  {json.dumps(preview, default=str)[:100]}")
    ok += 1; return d

def passed(label, msg=""):
    global ok
    print(f"  PASS [{label}]  {msg}")
    ok += 1

def failed(label, msg=""):
    global fail
    print(f"  FAIL [{label}]  {msg}")
    fail += 1

c = httpx.Client(base_url=BASE, timeout=30)
body = {"spot": 100, "strike": 100, "expiry": 1.0, "rate": 0.05, "volatility": 0.20}
spy_body = {"spot": 679, "strike": 679, "expiry": 0.011, "rate": 0.036, "volatility": 0.139}

# ── 1. Health ────────────────────────────────────────────────────────────────
print("\n── Health ──")
check("health", c.get("/api/v1/health"), ["status", "version"])

# ── 2. Pricing endpoints ──────────────────────────────────────────────────────
print("\n── Pricing endpoints ──")
r = check("European call",  c.post("/api/v1/price/european", json=body), ["price"])
if r: assert abs(r["price"] - 10.4506) < 0.01, f"price={r['price']}"

r = check("European put",   c.post("/api/v1/price/european",
          json={**body, "option_type": "put"}), ["price"])
if r: assert r["price"] > 0

r = check("American put",   c.post("/api/v1/price/american",
          json={**body, "option_type": "put"}), ["price"])
if r: assert r["price"] > 0

r = check("Barrier DOC",    c.post("/api/v1/price/barrier",
          json={**body, "barrier_level": 80,
                "barrier_direction": "down", "barrier_knock": "out"}), ["price"])
if r: assert 0 < r["price"] < 10.5, f"barrier price {r['price']}"

r = check("Local vol CEV",  c.post("/api/v1/price/local_vol",
          json={**body, "vol_model": "cev", "vol_params": {"beta": 0.5}}), ["price"])
if r: assert r["price"] > 0

r = check("Greeks AAD",     c.post("/api/v1/greeks", json=body),
          ["price", "delta", "gamma", "theta", "vega", "rho"])
if r:
    assert 0.5 < r["delta"] < 0.8
    assert r["gamma"] > 0
    assert r["theta"] < 0
    assert r["vega"] > 0

# ── 3. SPX-scale (high value) ─────────────────────────────────────────────────
print("\n── High-value / stress ──")
r = check("SPX-scale ATM",  c.post("/api/v1/greeks",
          json={"spot": 5300, "strike": 5300, "expiry": 0.25,
                "rate": 0.045, "volatility": 0.16}), ["price", "delta"])
if r:
    # No dividend here → BS ≈ 196-200; with q=1.4% → ~189. Accept 150-250.
    assert 150 < r["price"] < 250, f"SPX price {r['price']} out of range"
    assert 0.4 < r["delta"] < 0.7

r = check("Large spot SPY", c.post("/api/v1/greeks", json=spy_body),
          ["price", "delta", "gamma", "vega"])
if r:
    # Ensure no NaN / None (the mesh fix)
    assert all(r[k] is not None for k in ["price","delta","gamma","vega"]), "NaN in Greeks"
    assert r["price"] > 0

# ── 4. Batch pricing ─────────────────────────────────────────────────────────
print("\n── Batch pricing ──")
r = check("batch 2 contracts", c.post("/api/v1/price/batch",
          json={"requests": [body, {**body, "strike": 110, "option_type": "put"}]}),
          ["results"])
if r:
    prices = [round(x["price"], 4) for x in r["results"]]
    print(f"     prices: {prices}")
    assert all(p > 0 for p in prices)

# ── 5. Market data endpoints ──────────────────────────────────────────────────
print("\n── Market data (yfinance, may be slow) ──")
r_q = c.get("/api/v1/market/quote?symbol=SPY", timeout=20)
if r_q.status_code == 200:
    d = r_q.json()
    passed("SPY quote", f"spot={d.get('spot')}  rate={d.get('risk_free_rate')}  div={d.get('dividend_yield')}")
    assert d["spot"] > 0
else:
    print(f"  SKIP [SPY quote] HTTP {r_q.status_code} (yfinance unavailable)")

r_e = c.get("/api/v1/market/expiries?symbol=SPY", timeout=20)
if r_e.status_code == 200:
    exps = r_e.json().get("expirations", [])
    passed("SPY expiries", f"{len(exps)} expirations found")
else:
    print(f"  SKIP [SPY expiries] HTTP {r_e.status_code}")

# ── 6. Input validation ───────────────────────────────────────────────────────
print("\n── Input validation (422 expected) ──")
check("vol=900%  → 422", c.post("/api/v1/greeks",
      json={**body, "volatility": 9.0}), status=422)
check("spot=-1  → 422",  c.post("/api/v1/greeks",
      json={**body, "spot": -1}), status=422)
check("strike=0 → 422",  c.post("/api/v1/greeks",
      json={**body, "strike": 0}), status=422)
check("expiry=0 → 422",  c.post("/api/v1/greeks",
      json={**body, "expiry": 0}), status=422)

# ── 7. Static dashboard ───────────────────────────────────────────────────────
print("\n── Bundled dashboard ──")
r = c.get("/", follow_redirects=True)
if r.status_code == 200 and "<!DOCTYPE html>" in r.text:
    passed("GET /  → dashboard HTML", f"{len(r.text)} bytes")
    # Check the JS bundle is referenced
    if "_next" in r.text:
        passed("GET /  → Next.js _next assets referenced")
    else:
        failed("GET /  → _next assets not found in HTML")
else:
    failed("GET /", f"status={r.status_code}")

# ── 8. WebSocket end-to-end ───────────────────────────────────────────────────
print("\n── WebSocket pricing (end-to-end) ──")

async def test_ws():
    global ok, fail
    try:
        async with websockets.connect(WS, open_timeout=5) as ws:
            # single price
            req = {"type": "single_price", "params": {
                "spot": 100, "strike": 100, "expiry": 1.0,
                "rate": 0.05, "volatility": 0.20,
                "num_nodes": 201, "num_time_steps": 200
            }, "request_id": "test-1"}
            await ws.send(json.dumps(req))
            resp = json.loads(await asyncio.wait_for(ws.recv(), timeout=15))
            price = resp["data"]["price"]
            assert abs(price - 10.4506) < 0.05, f"WS price={price}"
            passed("WS single_price", f"price={round(price,4)}  compute={resp['compute_time_ms']}ms")

            # greeks surface (small grid)
            req2 = {"type": "greeks_surface", "params": {
                "spot": 100, "strike": 100, "expiry": 1.0,
                "rate": 0.05, "volatility": 0.20,
                "num_nodes": 101, "num_time_steps": 100
            }, "spot_range": [70, 130], "expiry_range": [0.1, 1.0],
               "spot_steps": 5, "expiry_steps": 3, "request_id": "test-2"}
            await ws.send(json.dumps(req2))
            resp2 = json.loads(await asyncio.wait_for(ws.recv(), timeout=30))
            assert resp2["type"] == "greeks_surface"
            passed("WS greeks_surface", f"compute={resp2['compute_time_ms']}ms")

            # vol surface
            req3 = {"type": "vol_surface", "params": {
                "spot": 100, "strike": 100, "expiry": 1.0,
                "rate": 0.05, "volatility": 0.20,
                "num_nodes": 101, "num_time_steps": 100
            }, "spot_range": [70, 130], "expiry_range": [0.1, 1.0],
               "spot_steps": 5, "expiry_steps": 3, "request_id": "test-3"}
            await ws.send(json.dumps(req3))
            resp3 = json.loads(await asyncio.wait_for(ws.recv(), timeout=30))
            assert resp3["type"] == "vol_surface"
            passed("WS vol_surface", f"compute={resp3['compute_time_ms']}ms")

    except Exception as e:
        failed("WebSocket", str(e))

asyncio.run(test_ws())

# ── Summary ───────────────────────────────────────────────────────────────────
print(f"\n{'='*60}")
print(f"  {ok} PASS   {fail} FAIL")
print(f"{'='*60}")
sys.exit(0 if fail == 0 else 1)
