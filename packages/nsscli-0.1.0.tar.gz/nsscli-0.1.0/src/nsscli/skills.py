import hashlib
import json
import os
import re
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath


SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,62}$")
USER_AGENT = "nsscli/0.1.0"


def add_skill(args) -> int:
    source = parse_skill_source(args.source, args.base_url)
    discovery_url = f"{source.base_url.rstrip('/')}/skills/{source.slug}/.well-known/agent-skills/index.json"

    discovery = fetch_json(discovery_url)
    entry = select_skill_entry(discovery, source.slug)
    archive_url = urllib.parse.urljoin(discovery_url, entry["url"])

    with tempfile.TemporaryDirectory(prefix="nsscli-") as temp_dir:
        temp_path = Path(temp_dir)
        archive_path = temp_path / f"{source.slug}.zip"
        extract_dir = temp_path / "extract"

        content = download_bytes(archive_url)
        verify_digest(content, entry.get("digest", ""))
        archive_path.write_bytes(content)
        extract_zip_safe(archive_path, extract_dir)

        skill_root = find_skill_root(extract_dir)
        install_root = resolve_install_root(args)
        target_dir = install_root / source.slug
        copy_skill(skill_root, target_dir, force=args.force)

    print(f"installed {source.slug} -> {target_dir}")
    return 0


def init_skill(args) -> int:
    raw_name = args.name.strip()
    slug = normalize_slug(raw_name)
    target = Path(args.target_dir or slug).expanduser().resolve()
    if target.exists():
        raise SystemExit(f"directory already exists: {target}")

    target.mkdir(parents=True)
    (target / "SKILL.md").write_text(build_skill_template(raw_name, slug), encoding="utf-8")
    (target / "README.md").write_text(f"# {raw_name}\n\n介绍这个 Skill 的用途、适用场景和使用方式。\n", encoding="utf-8")
    print(f"created {target}")
    return 0


def validate_skill(args) -> int:
    root = Path(args.path).expanduser().resolve()
    errors = validate_skill_dir(root)
    if errors:
        for error in errors:
            print(f"- {error}")
        return 1
    print("skill package is valid")
    return 0


def pack_skill(args) -> int:
    root = Path(args.path).expanduser().resolve()
    errors = validate_skill_dir(root)
    if errors:
        for error in errors:
            print(f"- {error}")
        return 1

    output = Path(args.output or f"{root.name}.zip").expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in root.rglob("*"):
            if not file.is_file() or should_skip_pack_file(file):
                continue
            archive.write(file, file.relative_to(root).as_posix())

    print(f"packed {output}")
    return 0


class SkillSource:
    def __init__(self, slug: str, base_url: str):
        self.slug = slug
        self.base_url = base_url


def parse_skill_source(value: str, default_base_url: str) -> SkillSource:
    text = (value or "").strip().rstrip("/")
    if not text:
        raise SystemExit("missing skill source")

    parsed = urllib.parse.urlparse(text)
    if parsed.scheme in ("http", "https") and parsed.netloc:
        slug = parse_slug_from_url_path(parsed.path)
        return SkillSource(slug=normalize_slug(slug), base_url=f"{parsed.scheme}://{parsed.netloc}")

    if text.startswith("@"):
        text = text[1:]
    if "/" in text:
        text = text.rsplit("/", 1)[-1]
    return SkillSource(slug=normalize_slug(text), base_url=default_base_url)


def parse_slug_from_url_path(path: str) -> str:
    parts = [urllib.parse.unquote(part) for part in path.split("/") if part]
    for index, part in enumerate(parts):
        if part in ("skill", "skills") and index + 1 < len(parts):
            next_part = parts[index + 1]
            if next_part.startswith("@") and index + 2 < len(parts):
                return parts[index + 2]
            return next_part
    raise SystemExit(f"cannot parse skill slug from URL path: {path}")


def normalize_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9-]+", "-", (value or "").strip().lower()).strip("-")
    if not SLUG_RE.match(slug):
        raise SystemExit(f"invalid skill slug: {value}")
    return slug


def fetch_json(url: str) -> dict:
    raw = download_bytes(url)
    try:
        data = json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"invalid discovery JSON: {url}") from exc
    if not isinstance(data, dict):
        raise SystemExit(f"invalid discovery JSON: {url}")
    return data


def download_bytes(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        raise SystemExit(f"request failed: {exc.code} {url}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"request failed: {url} ({exc.reason})") from exc


def select_skill_entry(discovery: dict, slug: str) -> dict:
    skills = discovery.get("skills")
    if not isinstance(skills, list) or not skills:
        raise SystemExit("discovery JSON does not contain skills")

    for entry in skills:
        if isinstance(entry, dict) and entry.get("name") == slug:
            validate_discovery_entry(entry)
            return entry

    if len(skills) == 1 and isinstance(skills[0], dict):
        validate_discovery_entry(skills[0])
        return skills[0]

    raise SystemExit(f"skill not found in discovery JSON: {slug}")


def validate_discovery_entry(entry: dict) -> None:
    if entry.get("type") != "archive" or entry.get("format") != "zip" or not entry.get("url"):
        raise SystemExit("unsupported skill artifact; expected zip archive")


def verify_digest(content: bytes, digest: str) -> None:
    if not digest:
        return
    if not digest.startswith("sha256:"):
        return
    expected = digest.split(":", 1)[1].lower()
    actual = hashlib.sha256(content).hexdigest()
    if actual != expected:
        raise SystemExit("downloaded skill archive digest mismatch")


def extract_zip_safe(archive_path: Path, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            relative = safe_zip_path(info.filename)
            target = output_dir.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(info.filename))


def safe_zip_path(name: str) -> PurePosixPath:
    normalized = name.replace("\\", "/")
    path = PurePosixPath(normalized)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise SystemExit(f"unsafe archive path: {name}")
    return path


def find_skill_root(root: Path) -> Path:
    direct = root / "SKILL.md"
    if direct.exists():
        return root
    for file in root.rglob("SKILL.md"):
        return file.parent
    raise SystemExit("downloaded archive does not contain SKILL.md")


def resolve_install_root(args) -> Path:
    if args.install_dir:
        return Path(args.install_dir).expanduser().resolve()

    if args.project:
        if args.agent == "claude-code":
            return (Path.cwd() / ".claude" / "skills").resolve()
        return (Path.cwd() / ".agents" / "skills").resolve()

    if args.agent == "claude-code":
        return Path.home() / ".claude" / "skills"
    if args.agent == "default":
        return Path.home() / ".config" / "agents" / "skills"
    return Path.home() / ".codex" / "skills"


def copy_skill(source: Path, target: Path, force: bool) -> None:
    if target.exists():
        if not force:
            raise SystemExit(f"target already exists: {target}. Use --force to overwrite.")
        shutil.rmtree(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, target)


def validate_skill_dir(root: Path) -> list:
    errors = []
    if not root.exists() or not root.is_dir():
        return [f"directory not found: {root}"]

    skill_file = root / "SKILL.md"
    readme_file = root / "README.md"
    if not skill_file.exists():
        errors.append("missing SKILL.md")
    if not readme_file.exists():
        errors.append("missing README.md")
    if skill_file.exists():
        content = skill_file.read_text(encoding="utf-8", errors="ignore")
        if not content.lstrip("\ufeff").startswith("---\n"):
            errors.append("SKILL.md should start with YAML front matter")
        if not re.search(r"^name:\s*.+", content, re.MULTILINE):
            errors.append("SKILL.md front matter missing name")
        if not re.search(r"^description:\s*.+", content, re.MULTILINE):
            errors.append("SKILL.md front matter missing description")
    return errors


def should_skip_pack_file(file: Path) -> bool:
    parts = set(file.parts)
    return "__pycache__" in parts or ".git" in parts or file.name in {".DS_Store"}


def build_skill_template(name: str, slug: str) -> str:
    return f"""---
name: {slug}
description: Describe when this Skill should be used.
license: MIT
compatibility: Requires a filesystem-based agent.
allowed-tools: Bash Read Write Edit Glob Grep
metadata:
  user-invocable: "true"
---

# {name}

写清楚这个 Skill 的能力边界、触发场景和执行步骤。
"""
