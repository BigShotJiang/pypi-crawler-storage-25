import argparse
from typing import List, Optional

from . import __version__
from .skills import add_skill, init_skill, pack_skill, validate_skill


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if not hasattr(args, "handler"):
        parser.print_help()
        return 0

    return args.handler(args)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="nsscli", description="NSSCTF command line interface.")
    parser.add_argument("--version", action="version", version=f"nsscli {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    skills_parser = subparsers.add_parser("skills", help="Manage installed Skills.")
    skills_subparsers = skills_parser.add_subparsers(dest="skills_command")
    add_add_parser(skills_subparsers.add_parser("add", help="Install a Skill from NSSCTF Skill Hub."))

    skill_parser = subparsers.add_parser("skill", help="Create, validate, package, or install a Skill.")
    skill_subparsers = skill_parser.add_subparsers(dest="skill_command")
    add_init_parser(skill_subparsers.add_parser("init", help="Create a local Skill package."))
    add_validate_parser(skill_subparsers.add_parser("validate", help="Validate a local Skill package."))
    add_pack_parser(skill_subparsers.add_parser("pack", help="Package a local Skill directory."))
    add_add_parser(skill_subparsers.add_parser("add", help="Install a Skill from NSSCTF Skill Hub."))
    add_add_parser(skill_subparsers.add_parser("install", help="Install a Skill from NSSCTF Skill Hub."))

    return parser


def add_add_parser(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("source", help="Skill slug, @scope/slug, @slug, or https://nssctf.cn/skills/<slug> URL.")
    parser.add_argument("--agent", choices=("codex", "claude-code", "default"), default="codex")
    parser.add_argument("--project", action="store_true", help="Install into the current project.")
    parser.add_argument("--global", dest="global_install", action="store_true", help="Install into the user home.")
    parser.add_argument("--dir", dest="install_dir", help="Custom skills root directory.")
    parser.add_argument("--base-url", default="https://nssctf.cn", help="Skill Hub base URL.")
    parser.add_argument("--force", action="store_true", help="Overwrite an existing installed Skill.")
    parser.set_defaults(handler=add_skill)


def add_init_parser(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("name", help="Skill name or slug.")
    parser.add_argument("--dir", dest="target_dir", help="Output directory. Defaults to the slug.")
    parser.set_defaults(handler=init_skill)


def add_validate_parser(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("path", nargs="?", default=".", help="Skill directory.")
    parser.set_defaults(handler=validate_skill)


def add_pack_parser(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("path", nargs="?", default=".", help="Skill directory.")
    parser.add_argument("--output", "-o", help="Output zip file.")
    parser.set_defaults(handler=pack_skill)
