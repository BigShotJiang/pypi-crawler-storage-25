# nsscli

`nsscli` 是 NSSCTF Skill Hub 的 Python 命令行工具，用于创建、校验、打包和安装 Skill。

## 安装

```bash
pip install --upgrade nsscli
nsscli --help
```

本地开发：

```bash
cd nsscli
pip install -e .
nsscli --help
```

## 安装 Skill

```bash
nsscli skills add @nssctf/ctf-pwn
nsscli skills add @ctf-pwn
nsscli skills add ctf-pwn
nsscli skills add https://nssctf.cn/skills/ctf-pwn
```

默认安装到 `~/.codex/skills/<slug>`。也可以指定目标：

```bash
nsscli skills add @nssctf/ctf-pwn --agent claude-code
nsscli skills add @nssctf/ctf-pwn --agent default
nsscli skills add @nssctf/ctf-pwn --project
nsscli skills add @nssctf/ctf-pwn --dir ~/.codex/skills --force
```

## 本地 Skill 工作流

```bash
nsscli skill init ctf-pwn
nsscli skill validate ./ctf-pwn
nsscli skill pack ./ctf-pwn --output ctf-pwn.zip
```

`nsscli skill add` 和 `nsscli skill install` 也可作为 `nsscli skills add` 的别名。

## 兼容安装方式

平台也支持官方 `skills` CLI 和 Bash 脚本：

```bash
npx skills add https://nssctf.cn/skills/ctf-pwn
curl -fsSL https://nssctf.cn/skills/install.sh | bash -s -- @nssctf/ctf-pwn
```

## 运行要求

- Python `>=3.9`
- 只使用 Python 标准库，无额外运行时依赖
