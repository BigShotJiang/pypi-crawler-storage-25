"""Tests for the Claude Agent SDK adapter.

The adapter is covered via a fake ``claude_agent_sdk`` module
installed into ``sys.modules`` so tests stay fast and deterministic
regardless of whether the real package is installed in the venv.
"""

from __future__ import annotations

import sys
import types
from pathlib import Path
from typing import Any, AsyncIterator

import pytest

from doorae_agent.integrations.claude_code import (
    ClaudeCodeAdapter,
    integrate_with_claude_code,
)


@pytest.fixture
def fake_sdk(monkeypatch: pytest.MonkeyPatch) -> list[dict[str, Any]]:
    """Stub the claude_agent_sdk module with a recording query()."""
    calls: list[dict[str, Any]] = []

    class FakeOptions:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

        def __repr__(self) -> str:  # pragma: no cover - debugging
            return f"FakeOptions({self.kwargs!r})"

    async def fake_query(
        *, prompt: str, options: FakeOptions, transport: Any = None
    ) -> AsyncIterator[Any]:
        calls.append({"prompt": prompt, "options": options})

        class TextBlock:
            def __init__(self, text: str) -> None:
                self.text = text

        class ToolUseBlock:
            # Real SDK puts the skill name and tool args here. We
            # give it a ``text`` attribute too so the adapter has
            # a chance to leak it — good regression target.
            # Issue #144 — ``name`` and ``input`` are what the
            # observability log reads; we keep the values distinct
            # from anything that would show up as a leaked reply.
            text = "TOOL USE: activate_skill"
            name = "mcp__github__get_me"
            input = {"reason": "debug"}

        class ToolResultBlock:
            # Same deal — skill activation returns the SKILL.md
            # body here, which must not show up in the reply.
            text = "SKILL BODY LEAKED INTO TOOL RESULT"

        class AssistantMessage:
            content = [
                TextBlock("hello from fake claude"),
                ToolUseBlock(),
                ToolResultBlock(),
            ]
            session_id = "sess-abc"

        class ResultMessage:
            result = "hello from fake claude"
            session_id = "sess-abc"

        yield AssistantMessage()
        yield ResultMessage()

    # Issue #159 Phase C — the real SDK exposes ``tool`` /
    # ``create_sdk_mcp_server`` for in-process MCP servers. The
    # adapter builds a ``handoff_to`` tool on top of them, so the
    # fake SDK has to mimic the decorator + server-config shape.
    from types import SimpleNamespace

    def fake_tool(name: str, description: str, input_schema: Any,
                  annotations: Any = None):
        def decorator(handler):
            return SimpleNamespace(
                name=name,
                description=description,
                input_schema=input_schema,
                handler=handler,
                annotations=annotations,
            )
        return decorator

    def fake_create_sdk_mcp_server(
        name: str, version: str = "1.0.0", tools: list | None = None,
    ):
        # The real shape is an ``McpSdkServerConfig`` TypedDict; for
        # tests we just return a plain dict that preserves identity.
        return {
            "type": "sdk",
            "name": name,
            "version": version,
            "tools": tools or [],
        }

    fake_module = types.ModuleType("claude_agent_sdk")
    fake_module.ClaudeAgentOptions = FakeOptions  # type: ignore[attr-defined]
    fake_module.query = fake_query  # type: ignore[attr-defined]
    fake_module.tool = fake_tool  # type: ignore[attr-defined]
    fake_module.create_sdk_mcp_server = fake_create_sdk_mcp_server  # type: ignore[attr-defined]
    fake_module.__version__ = "0.1.58-fake"

    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_module)
    return calls


class TestStart:
    @pytest.mark.asyncio
    async def test_start_without_sdk_installed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Adapter starts gracefully when claude-agent-sdk is missing."""
        monkeypatch.setitem(sys.modules, "claude_agent_sdk", None)
        adapter = ClaudeCodeAdapter(agent_name="TestBot")
        await adapter.start()
        assert adapter._sdk is None

    @pytest.mark.asyncio
    async def test_on_message_returns_none_without_sdk(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setitem(sys.modules, "claude_agent_sdk", None)
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        result = await adapter.on_message(
            {"content": "Hi", "room_id": "r1"}
        )
        assert result is None


class TestOnMessage:
    @pytest.mark.asyncio
    async def test_passes_cwd_and_setting_sources(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        adapter = ClaudeCodeAdapter()
        await adapter.start()
        result = await adapter.on_message(
            {"content": "Hi", "room_id": "r1"}
        )
        # The reply must be the TextBlock content, NOT the tool-use
        # or tool-result blocks that also carry a ``text`` attr.
        # This was the real-world bug: the adapter was harvesting
        # every block with a ``text`` attribute, so a skill
        # activation (ToolResultBlock) echoed the SKILL.md body
        # directly into the room.
        assert result == "hello from fake claude"
        assert "SKILL BODY LEAKED" not in (result or "")
        assert "TOOL USE" not in (result or "")
        opts = fake_sdk[0]["options"].kwargs

        # cwd must be Path.cwd() so the SDK resolves per-agent
        # state from the materialized directory.
        assert opts["cwd"] == str(Path.cwd())

        # setting_sources=["project"] is the non-negotiable flag
        # that makes CLAUDE.md / project skills actually load.
        # A silent regression here would drop all per-agent
        # configuration — pin the exact value.
        assert opts["setting_sources"] == ["project"]

        # Issue #134 — permission_mode must be bypassPermissions so
        # MCP tool calls aren't gated by an interactive approval
        # prompt that will never be answered in a headless agent.
        # Without this, any attached MCP (GitHub, Linear, etc.) is
        # effectively unusable: Claude reports "no permission" and
        # never actually invokes the tool.
        assert opts["permission_mode"] == "bypassPermissions"

    @pytest.mark.asyncio
    async def test_system_prompt_only_passed_when_set(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        adapter = ClaudeCodeAdapter()  # system_prompt defaults to None
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "r1"})
        assert "system_prompt" not in fake_sdk[-1]["options"].kwargs

        adapter = ClaudeCodeAdapter(system_prompt="you are a bot")
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "r1"})
        assert (
            fake_sdk[-1]["options"].kwargs.get("system_prompt")
            == "you are a bot"
        )

    @pytest.mark.asyncio
    async def test_model_passed_when_set(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        adapter = ClaudeCodeAdapter(model="claude-sonnet-4-6")
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "r1"})
        assert (
            fake_sdk[-1]["options"].kwargs.get("model") == "claude-sonnet-4-6"
        )

    @pytest.mark.asyncio
    async def test_session_resumes_per_room(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Turn 1 has no ``resume``; turn 2 resumes the session id
        captured from turn 1's messages.
        """
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        await adapter.on_message({"content": "turn 1", "room_id": "r1"})
        assert "resume" not in fake_sdk[0]["options"].kwargs
        # ``_last_session_id`` gets captured during the query loop;
        # integrate_with_claude_code normally promotes it into the
        # room map. Mimic that promotion here.
        adapter._sessions["r1"] = adapter._last_session_id  # type: ignore[attr-defined]

        await adapter.on_message({"content": "turn 2", "room_id": "r1"})
        assert fake_sdk[1]["options"].kwargs.get("resume") == "sess-abc"

    @pytest.mark.asyncio
    async def test_rooms_are_isolated(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        await adapter.on_message({"content": "room 1", "room_id": "r1"})
        adapter._sessions["r1"] = adapter._last_session_id  # type: ignore[attr-defined]
        # Room 2's first turn must NOT inherit room 1's session.
        await adapter.on_message({"content": "room 2", "room_id": "r2"})

        assert fake_sdk[1]["options"].kwargs.get("resume") is None

    @pytest.mark.asyncio
    async def test_tool_use_emits_structlog_entry(
        self, fake_sdk: list[dict[str, Any]], capfd: pytest.CaptureFixture[str]
    ) -> None:
        """Issue #144 — every ToolUseBlock in the stream should fire a
        ``claude_code.tool_use`` log entry carrying the tool name and
        the *keys* of the input payload (values are omitted to avoid
        leaking tokens / PII that MCP tools often carry).

        structlog writes to stdout directly (not through the stdlib
        logging root), so ``capfd`` is the right capture fixture.
        """
        adapter = ClaudeCodeAdapter()
        await adapter.start()
        await adapter.on_message({"content": "Hi", "room_id": "r1"})

        out = capfd.readouterr().out
        tool_use_lines = [
            line for line in out.splitlines() if "claude_code.tool_use" in line
        ]
        assert tool_use_lines, (
            f"expected tool_use log entry in stdout, got:\n{out}"
        )
        line = tool_use_lines[0]
        assert "tool_name=mcp__github__get_me" in line
        # Input *keys* must be logged, *values* must not.
        assert "'reason'" in line  # the key name
        # The value ("debug") must not appear in the tool_use line.
        # (Note: the substring "debug" as a log level name can appear
        # in other lines, so we scope the check to this line only.)
        assert "debug" not in line


class TestIntegrateWithClaudeCode:
    @pytest.mark.asyncio
    async def test_integrate_registers_handler(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Bot")
        assert len(client._message_handlers) == 0

        adapter = await integrate_with_claude_code(client, {"name": "Bot"})

        assert len(client._message_handlers) == 1
        assert isinstance(adapter, ClaudeCodeAdapter)


class TestHandoffTool:
    """Issue #159 Phase C — ``handoff_to`` custom tool exposed by the
    Claude Code adapter when the agent is the orchestrator of the
    current room.

    The tool is *conditionally* wired: only orchestrator rooms get
    the MCP server registration. Worker agents (and rooms under
    ``mentioned_only`` / ``round_robin``) must not see it, otherwise
    the LLM is tempted to use it outside its designed scope.
    """

    @pytest.mark.asyncio
    async def test_handoff_tool_exposed_when_orchestrator(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Client's orchestrator map points at me → options carry an
        ``mcp_servers`` entry and ``allowed_tools`` with the handoff
        tool name prefixed as ``mcp__<server>__<tool>``."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Orc")
        client._agent_id = "agent-alpha"
        client._my_participant_ids = {"orc-pid"}
        client._orchestrator_agent_id["room-a"] = "agent-alpha"

        adapter = ClaudeCodeAdapter(client=client)
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        assert "mcp_servers" in opts
        assert "doorae" in opts["mcp_servers"]
        assert "mcp__doorae__handoff_to" in opts.get("allowed_tools", [])

    @pytest.mark.asyncio
    async def test_handoff_tool_hidden_when_not_orchestrator(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Worker agent in an orchestrator room → no ``mcp_servers``
        stamp. The tool is strictly orchestrator-scoped."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Worker")
        client._agent_id = "agent-beta"  # not the orchestrator
        client._orchestrator_agent_id["room-a"] = "agent-alpha"

        adapter = ClaudeCodeAdapter(client=client)
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        assert "mcp_servers" not in opts
        assert "allowed_tools" not in opts

    @pytest.mark.asyncio
    async def test_handoff_tool_hidden_without_client(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Adapter constructed without a ChatClient reference (legacy
        call site) must still function — just without the tool. This
        preserves source-compat for any caller not yet updated."""
        adapter = ClaudeCodeAdapter()
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        assert "mcp_servers" not in opts

    @pytest.mark.asyncio
    async def test_handoff_handler_sends_marker_to_client(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Invoking the tool handler directly calls ``client.send``
        with the ``[HANDOFF] <@user:pid> reason`` marker. The server
        picks this up and updates ``Room.next_speaker_participant_id``
        (tested separately in cluster suite)."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Orc")
        client._agent_id = "agent-alpha"
        client._orchestrator_agent_id["room-a"] = "agent-alpha"

        sent: list[dict[str, Any]] = []

        async def fake_send(room_id, content, metadata=None, **kwargs):
            sent.append({"room_id": room_id, "content": content, "metadata": metadata})

        client.send = fake_send  # type: ignore[method-assign]

        adapter = ClaudeCodeAdapter(client=client)
        await adapter.start()
        # Drive one on_message so the SDK options capture the
        # ``mcp_servers`` entry (and the MCP server config is built).
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        # Fish the handoff tool out of the fake SDK server config and
        # invoke its handler directly. In production the SDK calls
        # this callback *during* the ``query()`` iteration, while
        # ``_current_room_id`` is still set — we simulate that by
        # re-setting it before invoking the handler.
        opts = fake_sdk[-1]["options"].kwargs
        server_cfg = opts["mcp_servers"]["doorae"]
        handoff_tool = next(
            t for t in server_cfg["tools"] if t.name == "handoff_to"
        )
        adapter._current_room_id = "room-a"
        result = await handoff_tool.handler(
            {"participant_id": "worker-pid-123", "reason": "logs expert"}
        )

        assert len(sent) == 1
        assert sent[0]["room_id"] == "room-a"
        assert sent[0]["content"].startswith("[HANDOFF] <@user:worker-pid-123>")
        assert "logs expert" in sent[0]["content"]
        assert sent[0]["metadata"] == {
            "handoff": {
                "target_participant_id": "worker-pid-123",
                "reason": "logs expert",
            }
        }
        # Tool must return a non-error MCP response shape so the
        # LLM sees a confirmation rather than a retry prompt.
        assert result.get("is_error") is not True
        content = result.get("content") or []
        assert content and content[0].get("type") == "text"

    @pytest.mark.asyncio
    async def test_handoff_handler_reports_error_on_missing_args(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Tool called without a participant id → tool returns an
        ``is_error`` MCP response so the LLM can retry."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Orc")
        client._agent_id = "agent-alpha"
        client._orchestrator_agent_id["room-a"] = "agent-alpha"
        sent: list[Any] = []

        async def fake_send(*args, **kwargs):
            sent.append((args, kwargs))

        client.send = fake_send  # type: ignore[method-assign]

        adapter = ClaudeCodeAdapter(client=client)
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        handoff_tool = next(
            t for t in opts["mcp_servers"]["doorae"]["tools"]
            if t.name == "handoff_to"
        )
        adapter._current_room_id = "room-a"
        result = await handoff_tool.handler({"reason": "no target"})

        assert result.get("is_error") is True
        assert len(sent) == 0


class TestOrchestratorRosterPrompt:
    """Issue #221 — the orchestrator adapter injects the room roster
    into ``system_prompt`` so the LLM can call ``handoff_to`` with a
    real participant UUID. Before this was wired, the LLM had no
    source of UUIDs and routinely emitted display names that the
    server rejected as unknown participants."""

    @pytest.mark.asyncio
    async def test_orchestrator_prompt_includes_room_roster(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Roster lines carry ``<@user:uuid>`` annotations so the LLM's
        mention-syntax pattern matching preserves the UUID."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Orc")
        client._agent_id = "agent-alpha"
        client._my_participant_ids = {"orc-pid"}
        client._orchestrator_agent_id["room-a"] = "agent-alpha"
        client._participants_by_room["room-a"] = {
            "orc-pid": {
                "id": "orc-pid",
                "display_name": "orc",
                "kind": "agent",
                "agent_id": "agent-alpha",
            },
            "worker-pid": {
                "id": "worker-pid",
                "display_name": "worker",
                "kind": "agent",
                "agent_id": "agent-beta",
            },
            "user-pid": {
                "id": "user-pid",
                "display_name": "alice",
                "kind": "user",
                "agent_id": None,
            },
        }

        adapter = ClaudeCodeAdapter(system_prompt="You are Orc.", client=client)
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        prompt = opts.get("system_prompt", "")
        assert prompt.startswith("You are Orc.")
        assert "<@user:worker-pid>" in prompt
        assert "<@user:user-pid>" in prompt
        # The orchestrator must not see itself in the roster —
        # ``handoff_to me`` would be a no-op cycle.
        assert "<@user:orc-pid>" not in prompt
        # The display_name should appear alongside the UUID so the LLM
        # can reason about *who* to hand off to, not just UUIDs.
        assert "worker" in prompt
        assert "alice" in prompt

    @pytest.mark.asyncio
    async def test_non_orchestrator_prompt_unchanged(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Worker agents don't get roster stamping — their prompt
        remains verbatim from construction. This keeps the roster
        strictly scoped to the agent that can actually use it."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Worker")
        client._agent_id = "agent-beta"
        client._orchestrator_agent_id["room-a"] = "agent-alpha"
        client._participants_by_room["room-a"] = {
            "other-pid": {
                "id": "other-pid",
                "display_name": "other",
                "kind": "agent",
                "agent_id": "agent-alpha",
            },
        }

        adapter = ClaudeCodeAdapter(
            system_prompt="You are Worker.", client=client
        )
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        assert opts.get("system_prompt") == "You are Worker."

    @pytest.mark.asyncio
    async def test_orchestrator_without_base_prompt_gets_roster_only(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """An adapter created without a custom system_prompt should
        still receive the roster as a standalone prompt — we don't
        want the CLAUDE.md-driven default path to silently skip the
        roster."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Orc")
        client._agent_id = "agent-alpha"
        client._my_participant_ids = {"orc-pid"}
        client._orchestrator_agent_id["room-a"] = "agent-alpha"
        client._participants_by_room["room-a"] = {
            "worker-pid": {
                "id": "worker-pid",
                "display_name": "worker",
                "kind": "agent",
                "agent_id": "agent-beta",
            },
        }

        adapter = ClaudeCodeAdapter(client=client)
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        prompt = opts.get("system_prompt")
        assert prompt is not None
        assert "<@user:worker-pid>" in prompt

    @pytest.mark.asyncio
    async def test_orchestrator_with_empty_roster_leaves_prompt_unchanged(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Pre-#221 servers don't stamp the roster — the adapter must
        still produce a workable prompt without it. Roster absence
        should not inject a stray "Room participants:" header."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Orc")
        client._agent_id = "agent-alpha"
        client._orchestrator_agent_id["room-a"] = "agent-alpha"
        # _participants_by_room not populated — pre-#221 server path.

        adapter = ClaudeCodeAdapter(system_prompt="You are Orc.", client=client)
        await adapter.start()
        await adapter.on_message({"content": "hi", "room_id": "room-a"})

        opts = fake_sdk[-1]["options"].kwargs
        assert opts.get("system_prompt") == "You are Orc."


class TestIngestContext:
    """Issue #74 — `ingest_context` absorbs ambient messages into a
    per-room buffer that the next active turn consumes as a prompt
    prefix, without triggering an LLM call itself."""

    @pytest.mark.asyncio
    async def test_ingest_then_on_message_prepends_prefix(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        await adapter.ingest_context({
            "room_id": "r1",
            "participant_id": "rep-agent",
            "content": "대상 방은 GraphQL 선호",
            "metadata": {"room_query_result": {"target_room_id": "r2"}},
        })
        # Buffer should hold one formatted line.
        assert len(adapter._pending_context["r1"]) == 1

        await adapter.on_message({"content": "어때요?", "room_id": "r1"})

        sent_prompt = fake_sdk[-1]["prompt"]
        assert "[참고] 룸 r2에서" in sent_prompt
        assert "어때요?" in sent_prompt

    @pytest.mark.asyncio
    async def test_prefix_consumed_once(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Drain clears the buffer — re-injecting the same line on
        turn 2 would duplicate it in both the prompt and the SDK
        session, wasting tokens and drifting into "the model thinks
        the same context repeats every turn" confusion."""
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        await adapter.ingest_context({
            "room_id": "r1",
            "participant_id": "agent-a",
            "content": "참고 발언",
            "metadata": {},
        })
        await adapter.on_message({"content": "질문 1", "room_id": "r1"})
        await adapter.on_message({"content": "질문 2", "room_id": "r1"})

        assert "[참고]" in fake_sdk[0]["prompt"]
        assert "[참고]" not in fake_sdk[1]["prompt"]

    @pytest.mark.asyncio
    async def test_rooms_have_independent_buffers(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        await adapter.ingest_context({
            "room_id": "r1",
            "participant_id": "a",
            "content": "r1-only",
            "metadata": {},
        })

        await adapter.on_message({"content": "in r2", "room_id": "r2"})

        # r2's prompt must be clean — r1's buffer leaking across
        # rooms would mix unrelated conversations into each other.
        assert "r1-only" not in fake_sdk[-1]["prompt"]

    @pytest.mark.asyncio
    async def test_empty_content_not_stashed(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Typing indicators and membership events carry empty
        content on the message frame; they're not conversational and
        shouldn't take a slot in the limited context buffer."""
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        await adapter.ingest_context({
            "room_id": "r1",
            "participant_id": "a",
            "content": "",
            "metadata": {"ingest_only": True},
        })
        await adapter.ingest_context({
            "room_id": "r1",
            "participant_id": "a",
            "content": "   ",
            "metadata": {"ingest_only": True},
        })

        assert adapter._pending_context.get("r1") is None

    @pytest.mark.asyncio
    async def test_size_cap_drops_oldest(
        self, fake_sdk: list[dict[str, Any]]
    ) -> None:
        """Eleventh entry evicts the first so a chatty room can't
        balloon prompt size unbounded. FIFO gives the freshest
        messages a consistent guarantee of making it into the
        prefix."""
        adapter = ClaudeCodeAdapter()
        await adapter.start()

        from doorae_agent.integrations.claude_code import _PENDING_CONTEXT_MAX

        for i in range(_PENDING_CONTEXT_MAX + 2):
            await adapter.ingest_context({
                "room_id": "r1",
                "participant_id": "a",
                "content": f"mID{i:02d}",
                "metadata": {},
            })

        buf = adapter._pending_context["r1"]
        assert len(buf) == _PENDING_CONTEXT_MAX
        rendered = [line for _, line in buf]
        # First two entries evicted by FIFO. Remaining span is
        # mID02 .. mID11 inclusive.
        assert all("mID00" not in line for line in rendered)
        assert all("mID01" not in line for line in rendered)
        assert any("mID02" in line for line in rendered)
        assert any("mID11" in line for line in rendered)

    @pytest.mark.asyncio
    async def test_format_room_query_result_locator(self) -> None:
        """The target room id is the locator a reader needs to go
        look at the original thread — it must survive into the
        breadcrumb. Without it, 'the other room said X' is
        ungrounded."""
        adapter = ClaudeCodeAdapter()
        line = adapter._format_context_line({
            "room_id": "r1",
            "participant_id": "rep",
            "content": "백엔드 팀 결론 요약",
            "metadata": {"room_query_result": {"target_room_id": "backend-1"}},
        })
        assert line is not None
        assert "backend-1" in line
        assert "[참고]" in line

    @pytest.mark.asyncio
    async def test_handler_routes_ingest_only(
        self,
        fake_sdk: list[dict[str, Any]],
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """End-to-end through the handler: an ``ingest_only`` message
        must land in the buffer AND must not trigger a reply on its
        own. This is the property the #74 fix is ultimately shipping
        — one `[취합 결과]` broadcast feeds all listeners' context
        without N duplicate responses."""
        from doorae_agent.client import ChatClient

        client = ChatClient("ws://localhost:8000", token="t", agent_name="Bot")
        # Prime the client with a participant id so decide_policy's
        # self-message rule doesn't accidentally match. The rep
        # that broadcasts `[취합 결과]` is a different agent.
        client._my_participant_ids = {"me-pid"}

        # Stub the network surface so the handler can reach the
        # ``send`` / ``sendTyping`` calls without a live WS. The
        # handler doesn't care about payload delivery here — we're
        # asserting against the SDK call log.
        sent: list[tuple[str, str]] = []

        async def _fake_send(room_id: str, content: str, metadata=None):
            sent.append((room_id, content))

        async def _fake_typing(room_id: str, is_typing: bool):
            return None

        monkeypatch.setattr(client, "send", _fake_send)
        monkeypatch.setattr(client, "sendTyping", _fake_typing)

        adapter = await integrate_with_claude_code(client, {"name": "Bot"})
        handler = client._message_handlers[0]

        ingest_msg = {
            "room_id": "r1",
            "participant_id": "rep-pid",
            "content": "[취합 결과] (3/3명 응답)\n...",
            "metadata": {
                "_nonce": "x",
                "ingest_only": True,
                "room_query_result": {"target_room_id": "r2"},
            },
        }
        await handler(ingest_msg)

        # No LLM call yet — ingestion is non-responsive.
        assert fake_sdk == []
        # The line is buffered for the next active turn.
        assert len(adapter._pending_context["r1"]) == 1
        # And nothing was broadcast — single broadcast, no fan-out.
        assert sent == []

        # Next turn from a human carries the prefix into the SDK.
        await handler({
            "room_id": "r1",
            "participant_id": "human",
            "content": "앞 내용 참고해서 답변해줘",
            "metadata": {},
        })

        assert len(fake_sdk) == 1
        assert "[참고]" in fake_sdk[0]["prompt"]
