"""Tests for the local inference proxy mock helpers."""

from __future__ import annotations

import json
import uuid
from unittest.mock import AsyncMock

from ojin.entities.interaction_messages import (
    InteractionResponse,
    InteractionResponseMessage,
    InteractionResponsePayload,
)
from tests.mock import inference_proxy_mock

_INTERACTION_ID = uuid.UUID("00000000-0000-0000-0000-000000000001")
_TIMESTAMP_MS = 123456


def _expected_final_response_bytes() -> bytes:
    test_video_bytes = b"\x00\x01\x02\x03\x04\x05" * 100
    return InteractionResponseMessage(
        payload=InteractionResponse(
            interaction_id=str(_INTERACTION_ID),
            payloads=[
                InteractionResponsePayload(
                    payload_type="video",
                    data=test_video_bytes,
                )
            ],
            is_final_response=True,
            timestamp=_TIMESTAMP_MS,
            index=0,
            usage=1,
        )
    ).to_bytes()


async def test_end_interaction_text_message_sends_final_response(monkeypatch) -> None:
    """EndInteraction text messages should not be parsed as binary input."""
    websocket = AsyncMock()
    monkeypatch.setattr(inference_proxy_mock.uuid, "uuid4", lambda: _INTERACTION_ID)
    monkeypatch.setattr(inference_proxy_mock.time, "monotonic", lambda: 123.456)

    await inference_proxy_mock._handle_ws_message(
        websocket,
        "session-123",
        {
            "text": json.dumps(
                {"type": inference_proxy_mock.MessageType.END_INTERACTION}
            )
        },
    )

    websocket.send_bytes.assert_awaited_once_with(_expected_final_response_bytes())


async def test_preparsed_text_message_sends_final_response(monkeypatch) -> None:
    """Already parsed text payloads should be used without json.loads."""
    websocket = AsyncMock()
    monkeypatch.setattr(inference_proxy_mock.uuid, "uuid4", lambda: _INTERACTION_ID)
    monkeypatch.setattr(inference_proxy_mock.time, "monotonic", lambda: 123.456)

    await inference_proxy_mock._handle_ws_message(
        websocket,
        "session-123",
        {"text": {"type": inference_proxy_mock.MessageType.END_INTERACTION}},
    )

    websocket.send_bytes.assert_awaited_once_with(_expected_final_response_bytes())
