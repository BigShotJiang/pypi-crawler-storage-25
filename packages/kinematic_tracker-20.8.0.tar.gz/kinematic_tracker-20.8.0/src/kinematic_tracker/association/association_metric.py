"""Types of association metrics (similarity scores)."""

from enum import Enum


class AssociationMetric(Enum):
    GIOU_AXES_ALIGNED = 'giou-axes-aligned'
    GIOU_YAW = 'giou-yaw'
    MAHALANOBIS = 'mahalanobis'
    MAHALANOBIS_SIZE_MODULATED = 'mahalanobis-size-modulated'
    IOU_LIKE_TWO_YAW = 'iou-like-two-yaw'
