"""."""

import numpy as np

from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw


def test_it(driver: MetricIouLikeTwoYaw) -> None:
    """."""
    wrz_m2 = np.linspace(1, 6, 6).reshape(3, 2)
    driver.normalize_yaw_quat_inplace(wrz_m2)
    ref = [
        [0.4472135954999579, 0.8944271909999159],
        [0.6, 0.8],
        [0.6401843996644799, 0.7682212795973759],
    ]
    assert np.allclose(ref, wrz_m2)
