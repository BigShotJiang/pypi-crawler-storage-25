"""."""

import cv2
import numpy as np

from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw


def test_get_target_t8(driver: MetricIouLikeTwoYaw, filters: list[cv2.KalmanFilter]) -> None:
    trk_t8 = driver.get_target_t8(filters)
    ref = [
        [1.0, 2.0, 3.0, 0.49613893835683387, 0.8682431421244593, 8.0, 9.0, 10.0],
        [11.0, 12.0, 13.0, 0.6357072528610997, 0.7719302356170498, 18.0, 19.0, 20.0],
        [21.0, 22.0, 23.0, 0.6643638388299198, 0.7474093186836598, 28.0, 29.0, 30.0],
    ]
    assert np.allclose(trk_t8[:3], ref)
