"""."""

import pytest

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.association.metric_giou_aligned import MetricGIoUAligned
from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw
from kinematic_tracker.association.metric_mahalanobis import MetricMahalanobis


def test_at_start(tracker: NdKkfTracker) -> None:
    """."""
    assert isinstance(tracker.metric_driver, MetricMahalanobis)


def test_metric_iou(tracker: NdKkfTracker) -> None:
    """."""
    tracker.set_association_metric('giou-axes-aligned', ind_pos_size=(0, 1, 2, 3, 4, 5))
    assert isinstance(tracker.metric_driver, MetricGIoUAligned)
    driver = tracker.metric_driver
    assert driver.ind_pos_size.shape == (6,)
    assert driver.ind_pos_size == pytest.approx((0, 1, 2, 3, 4, 5))
    assert tracker.association.mah_pre_factor == pytest.approx(1.0)
    assert tracker.association.ind_pos_size == (0, 1, 2, 3, 4, 5)


def test_mahalanobis(tracker: NdKkfTracker) -> None:
    """."""
    tracker.set_association_metric('mahalanobis', 0.567)
    assert isinstance(tracker.metric_driver, MetricMahalanobis)
    assert tracker.association.mah_pre_factor == pytest.approx(0.567)


def test_metric_giou_yaw() -> None:
    """."""
    tracker = NdKkfTracker([1, 1, 1], [3, 2, 3])
    tracker.set_association_metric('giou-yaw', ind_pos_w_rz_size=(0, 1, 2, 3, 4, 5, 6, 7))
    assert isinstance(tracker.metric_driver, MetricGIoUYaw)
    driver = tracker.metric_driver
    assert driver.ind_pos_w_rz_size.shape == (8,)
    assert driver.ind_pos_w_rz_size == pytest.approx((0, 1, 2, 3, 4, 5, 6, 7))
    assert tracker.association.ind_pos_w_rz_size == (0, 1, 2, 3, 4, 5, 6, 7)


def test_metric_iou_like_two_yaw() -> None:
    """."""
    tracker = NdKkfTracker([1, 1, 1], [3, 2, 3])
    tracker.set_association_metric('iou-like-two-yaw', ind_pos_w_rz_size=(0, 1, 2, 3, 4, 5, 6, 7))
    assert isinstance(tracker.metric_driver, MetricIouLikeTwoYaw)
    driver = tracker.metric_driver
    assert driver.ind_pos_w_rz_size.shape == (8,)
    assert driver.ind_pos_w_rz_size == pytest.approx((0, 1, 2, 3, 4, 5, 6, 7))
    assert tracker.association.ind_pos_w_rz_size == (0, 1, 2, 3, 4, 5, 6, 7)
