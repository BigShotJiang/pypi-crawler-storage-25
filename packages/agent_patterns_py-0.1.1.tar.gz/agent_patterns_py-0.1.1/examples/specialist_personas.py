"""
Example: Pre-built specialist persona tools.

These demonstrate the persona pattern (see tools/persona.py) applied to
common software development workflows.  Copy, modify, or use directly.

Each tool wraps prompt_expert with a carefully crafted expert description
and a structured prompt — showing how to build domain-specific tools on
top of the base persona primitive.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from agent_patterns.tools.persona import prompt_expert
from agent_patterns.tools.registry import register_tool

if TYPE_CHECKING:
    from agent_patterns.core.context import ActionContext


@register_tool(tags=["documentation"])
def generate_technical_documentation(
    action_context: "ActionContext",
    code_or_feature: str,
) -> str:
    """
    Generate comprehensive technical documentation via a senior technical
    writer persona.

    Args:
        code_or_feature: The code snippet or feature description to document.
    """
    return prompt_expert(
        action_context=action_context,
        description_of_expert="""
You are a senior technical writer with 15 years of experience in software documentation.
Your expertise includes:
- Writing clear and precise API documentation
- Explaining complex technical concepts to developers
- Documenting implementation details and integration points
- Creating code examples that illustrate key concepts
- Identifying and documenting important caveats and edge cases

Your documentation strikes the perfect balance between completeness and clarity.
""",
        prompt=f"""Create comprehensive technical documentation for:

{code_or_feature}

Include:
1. Overview of purpose and functionality
2. Implementation approach
3. Key interfaces and integration points
4. Usage examples with code snippets
5. Important considerations and edge cases
6. Performance implications (if relevant)""",
    )


@register_tool(tags=["testing"])
def design_test_suite(
    action_context: "ActionContext",
    feature_description: str,
) -> str:
    """
    Design a comprehensive test suite via a senior QA engineer persona.

    Args:
        feature_description: Description of the feature to test.
    """
    return prompt_expert(
        action_context=action_context,
        description_of_expert="""
You are a senior QA engineer with 12 years of experience in test design and automation.
Your expertise includes comprehensive test strategy, unit/integration/e2e testing,
performance and security testing, and identifying edge cases others miss.
""",
        prompt=f"""Design a comprehensive test suite for:

{feature_description}

Cover:
1. Unit tests for individual components
2. Integration tests for component interactions
3. End-to-end tests for critical paths
4. Performance scenarios (if relevant)
5. Edge cases and error conditions
6. Test data requirements

For each category: specific scenarios, expected outcomes, edge cases, challenges.""",
    )


@register_tool(tags=["code_quality"])
def perform_code_review(
    action_context: "ActionContext",
    code: str,
) -> str:
    """
    Review code and suggest improvements via a senior software architect
    persona.

    Args:
        code: The source code to review.
    """
    return prompt_expert(
        action_context=action_context,
        description_of_expert="""
You are a senior software architect with 20 years of experience in code review.
Your expertise covers architecture patterns, code quality, performance optimisation,
scalability, and security best practices. You identify subtle design issues and
suggest practical improvements without over-engineering.
""",
        prompt=f"""Review the following code and provide detailed improvement suggestions:

{code}

Address:
1. Code organisation and structure
2. Design pattern opportunities
3. Performance optimisation
4. Error handling completeness
5. Edge case handling
6. Maintainability concerns

For each suggestion: explain the issue, rationale for change, specific improvement,
and any trade-offs.""",
    )


@register_tool(tags=["communication"])
def write_feature_announcement(
    action_context: "ActionContext",
    feature_details: str,
    audience: str,
) -> str:
    """
    Write a feature announcement via a product marketing expert persona.

    Args:
        feature_details: Technical details of the feature.
        audience:        Target audience (e.g. ``"technical"``, ``"business"``).
    """
    return prompt_expert(
        action_context=action_context,
        description_of_expert="""
You are a senior product marketing manager with 12 years of experience in
technical product communication. You excel at translating technical features
into clear value propositions and adapting messaging for different audiences.
""",
        prompt=f"""Write a feature announcement for:

{feature_details}

Audience: {audience}

Include:
1. Compelling introduction
2. Clear feature explanation
3. Key benefits and use cases
4. Technical details (adapted for {audience} audience)
5. Implementation requirements
6. Call to action

Ensure tone and depth are appropriate for a {audience} audience.""",
    )
