from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any
from zoneinfo import ZoneInfo

from agent_patterns.capabilities.base import Capability

if TYPE_CHECKING:
    from agent_patterns.core.context import ActionContext
    from agent_patterns.language.base import Prompt


class TimeAwareCapability(Capability):
    """
    Makes the agent aware of the current date and time.

    On initialisation, adds the current timestamp to memory so the agent
    has it from the very first prompt.  On every subsequent iteration,
    prepends fresh time information to the system message so the agent
    never reasons about stale time data.

    Configure the timezone via ``action_context_props``::

        agent.run(
            "Schedule a meeting",
            action_context_props={"time_zone": "Europe/London"},
        )

    Defaults to ``America/Chicago`` if no timezone is provided.
    """

    def __init__(self) -> None:
        super().__init__(
            name="Time Awareness",
            description="Keeps the agent informed of the current date and time.",
        )

    def _current_time(self, action_context: "ActionContext") -> datetime:
        tz_name = action_context.get("time_zone", "America/Chicago")
        return datetime.now(ZoneInfo(tz_name))

    def init(self, agent: Any, action_context: "ActionContext") -> None:
        tz_name = action_context.get("time_zone", "America/Chicago")
        now = self._current_time(action_context)
        human = now.strftime("%H:%M %A, %B %d, %Y")
        iso = now.strftime("%Y-%m-%dT%H:%M:%S%z")

        memory = action_context.get_memory()
        if memory is not None:
            memory.add_memory({
                "type": "system",
                "content": (
                    f"Right now it is {human} (ISO: {iso}). "
                    f"You are in the {tz_name} timezone. "
                    "Consider the day and time when responding if relevant."
                ),
            })

    def process_prompt(
        self, agent: Any, action_context: "ActionContext", prompt: "Prompt"
    ) -> "Prompt":
        tz_name = action_context.get("time_zone", "America/Chicago")
        now = self._current_time(action_context)
        time_prefix = f"Current time: {now.strftime('%H:%M %A, %B %d, %Y')} ({tz_name})\n\n"

        messages = list(prompt.messages)
        if messages and messages[0].get("role") == "system":
            messages[0] = {**messages[0], "content": time_prefix + messages[0]["content"]}
        else:
            messages.insert(0, {"role": "system", "content": time_prefix})

        from agent_patterns.language.base import Prompt as P
        return P(messages=messages, tools=prompt.tools, metadata=prompt.metadata)
