from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional


class Action:
    """
    Represents a tool the agent can invoke.

    ``Action`` is the *interface* — it describes what the tool does and
    what parameters it accepts.  The ``Environment`` provides the
    *implementation* that actually runs the underlying function.

    Attributes:
        name:        Unique identifier matched against the LLM's tool call.
        function:    The Python callable to execute.
        description: Human/LLM-readable description (used in the prompt).
        parameters:  JSON Schema object describing the tool's arguments.
        terminal:    When ``True``, the agent loop stops after this action.
    """

    def __init__(
        self,
        name: str,
        function: Callable,
        description: str,
        parameters: Dict,
        terminal: bool = False,
    ) -> None:
        self.name = name
        self.function = function
        self.description = description
        self.terminal = terminal
        self.parameters = parameters

    def execute(self, **kwargs: Any) -> Any:
        """Call the underlying function with *kwargs*."""
        return self.function(**kwargs)


class ActionRegistry:
    """
    Maps action names to :class:`Action` objects.

    Use :class:`~agent_patterns.tools.registry.PythonActionRegistry` for
    automatic population from the ``@register_tool`` decorator registry.
    """

    def __init__(self) -> None:
        self.actions: Dict[str, Action] = {}

    def register(self, action: Action) -> None:
        """Add *action* to the registry (overwrites if name already exists)."""
        self.actions[action.name] = action

    def get_action(self, name: str) -> Optional[Action]:
        """Return the ``Action`` for *name*, or ``None`` if not found."""
        return self.actions.get(name)

    def get_actions(self) -> List[Action]:
        """Return all registered actions."""
        return list(self.actions.values())
