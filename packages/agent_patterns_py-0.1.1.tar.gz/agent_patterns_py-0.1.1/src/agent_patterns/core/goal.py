from dataclasses import dataclass


@dataclass(frozen=True)
class Goal:
    """
    A single agent goal.

    Goals describe *what* the agent should achieve (high-level objectives)
    and *how* it should approach the task (instructions, constraints,
    examples).  Multiple goals are sorted by ``priority`` before being
    injected into the prompt.

    Attributes:
        priority:    Lower numbers run first in the prompt.
        name:        Short label shown as a section heading.
        description: Full instructions / objective text.
    """

    priority: int
    name: str
    description: str
