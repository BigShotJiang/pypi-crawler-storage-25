from __future__ import annotations

from typing import Dict, List, Optional


class Memory:
    """
    Stores the agent's interaction history as an ordered list of typed
    message dicts.

    Each item is a dict with at minimum a ``"type"`` key
    (``"user"`` | ``"assistant"`` | ``"environment"`` | ``"system"``)
    and a ``"content"`` key.

    Subclass this to add richer backends (vector stores, databases, etc.)
    without changing the agent loop — the interface stays the same.
    """

    def __init__(self) -> None:
        self.items: List[Dict] = []

    def add_memory(self, memory: Dict) -> None:
        """Append *memory* to the history."""
        self.items.append(memory)

    def get_memories(self, limit: Optional[int] = None) -> List[Dict]:
        """Return up to *limit* memories (all if ``None``)."""
        return self.items[:limit]

    def copy_without_system_memories(self) -> "Memory":
        """Return a shallow copy that excludes ``type="system"`` entries."""
        filtered = Memory()
        filtered.items = [m for m in self.items if m.get("type") != "system"]
        return filtered
