from __future__ import annotations

import inspect
import time
import traceback as tb
from typing import TYPE_CHECKING, Any, Callable, Dict

if TYPE_CHECKING:
    from agent_patterns.core.action import Action
    from agent_patterns.core.context import ActionContext


def has_named_parameter(func: Callable, param_name: str) -> bool:
    """Return ``True`` if *func* declares a parameter named *param_name*."""
    return param_name in inspect.signature(func).parameters


class Environment:
    """
    Executes :class:`~agent_patterns.core.action.Action` objects and wraps
    their results in a structured dict.

    Override :meth:`execute_action` in subclasses to add dependency
    injection, sandboxing, or specialised execution strategies.
    """

    def execute_action(
        self,
        agent: Any,
        action_context: "ActionContext",
        action: "Action",
        args: Dict,
    ) -> Dict:
        """Execute *action* with *args* and return a result dict."""
        try:
            result = action.execute(**args)
            return self.format_result(result)
        except Exception as e:
            return {
                "tool_executed": False,
                "error": str(e),
                "traceback": tb.format_exc(),
            }

    def format_result(self, result: Any) -> Dict:
        """Wrap a raw return value in the standard result envelope."""
        return {
            "tool_executed": True,
            "result": result,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }


class PythonEnvironment(Environment):
    """
    Environment that auto-injects dependencies into tool functions.

    Before calling a tool, it inspects the function's parameter list and
    injects:

    - ``action_context``  → the live :class:`~agent_patterns.core.context.ActionContext`
    - ``action_agent``    → the :class:`~agent_patterns.core.agent.Agent` instance
    - ``_<key>``          → ``action_context.properties[key]``

    This keeps the agent loop free of dependency-management logic while
    giving tools access to shared resources (LLM, auth tokens, memory, etc.)
    without those parameters appearing in the LLM's tool schema.
    """

    def execute_action(
        self,
        agent: Any,
        action_context: "ActionContext",
        action: "Action",
        args: Dict,
    ) -> Dict:
        try:
            call_args = dict(args)
            fn = action.function

            if has_named_parameter(fn, "action_context"):
                call_args["action_context"] = action_context

            if has_named_parameter(fn, "action_agent"):
                call_args["action_agent"] = agent

            for key, value in action_context.properties.items():
                param = f"_{key}"
                if has_named_parameter(fn, param):
                    call_args[param] = value

            result = action.execute(**call_args)
            return self.format_result(result)
        except Exception as e:
            return {
                "tool_executed": False,
                "error": str(e),
                "traceback": tb.format_exc(),
            }
