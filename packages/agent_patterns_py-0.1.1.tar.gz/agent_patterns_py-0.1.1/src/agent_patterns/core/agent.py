from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, Callable, Dict, List, Optional

from agent_patterns.core.action import ActionRegistry
from agent_patterns.core.context import ActionContext
from agent_patterns.core.environment import Environment
from agent_patterns.core.goal import Goal
from agent_patterns.core.memory import Memory
from agent_patterns.language.base import AgentLanguage, Prompt

if TYPE_CHECKING:
    from agent_patterns.capabilities.base import Capability

logger = logging.getLogger(__name__)


class Agent:
    """
    Core GAME loop: Goals · Actions · Memory · Environment.

    The loop runs until one of:

    - A ``terminal`` action is selected.
    - ``max_iterations`` is reached.
    - ``max_duration_seconds`` elapses.
    - A :class:`~agent_patterns.capabilities.base.Capability` signals stop.

    **Capabilities** plug into eight lifecycle hooks without modifying this
    class.  Pass a list of them to ``capabilities``.

    Example::

        agent = Agent(
            goals=[Goal(1, "task", "Do X")],
            agent_language=AgentFunctionCallingActionLanguage(),
            action_registry=PythonActionRegistry(tags=["my_tools"]),
            generate_response=make_generate_response("openai/gpt-4o"),
            environment=PythonEnvironment(),
        )
        memory = agent.run("Please do X for me.")
    """

    def __init__(
        self,
        goals: List[Goal],
        agent_language: AgentLanguage,
        action_registry: ActionRegistry,
        generate_response: Callable[[Prompt], str],
        environment: Environment,
        capabilities: Optional[List["Capability"]] = None,
        max_iterations: int = 50,
        max_duration_seconds: int = 180,
        verbose: bool = True,
    ) -> None:
        self.goals = goals
        self.generate_response = generate_response
        self.agent_language = agent_language
        self.actions = action_registry
        self.environment = environment
        self.capabilities: List["Capability"] = capabilities or []
        self.max_iterations = max_iterations
        self.max_duration_seconds = max_duration_seconds
        self.verbose = verbose

    # ------------------------------------------------------------------
    # Prompt construction
    # ------------------------------------------------------------------

    def construct_prompt(
        self, goals: List[Goal], memory: Memory, actions: ActionRegistry
    ) -> Prompt:
        return self.agent_language.construct_prompt(
            actions=actions.get_actions(),
            environment=self.environment,
            goals=goals,
            memory=memory,
        )

    # ------------------------------------------------------------------
    # Response helpers
    # ------------------------------------------------------------------

    def get_action(self, response: str):
        """Parse *response* and look up the corresponding Action."""
        invocation = self.agent_language.parse_response(response)
        action = self.actions.get_action(invocation["tool"])
        return action, invocation

    def should_terminate(self, response: str) -> bool:
        """Return ``True`` if the parsed action is terminal."""
        try:
            action_def, _ = self.get_action(response)
            return action_def is not None and action_def.terminal
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Memory helpers
    # ------------------------------------------------------------------

    def set_current_task(self, memory: Memory, task: str) -> None:
        memory.add_memory({"type": "user", "content": task})

    # ------------------------------------------------------------------
    # LLM call
    # ------------------------------------------------------------------

    def prompt_llm_for_action(self, prompt: Prompt) -> str:
        return self.generate_response(prompt)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(
        self,
        user_input: str,
        memory: Optional[Memory] = None,
        action_context_props: Optional[Dict] = None,
        max_iterations: Optional[int] = None,
    ) -> Memory:
        """
        Execute the GAME loop and return the final :class:`Memory`.

        Args:
            user_input:           The task to give the agent.
            memory:               Existing memory to continue from (e.g. for
                                  multi-agent hand-offs).  A fresh one is
                                  created when ``None``.
            action_context_props: Extra properties injected into
                                  :class:`ActionContext` and available to
                                  tools via ``_<key>`` parameters.
            max_iterations:       Override the instance-level default.
        """
        memory = memory or Memory()
        action_context_props = action_context_props or {}
        iterations = max_iterations if max_iterations is not None else self.max_iterations

        action_context = ActionContext({
            "memory": memory,
            "llm": self.generate_response,
            "action_registry": self.actions,
            **action_context_props,
        })

        # Initialise capabilities (runs once)
        for cap in self.capabilities:
            cap.init(self, action_context)

        self.set_current_task(memory, user_input)
        start_time = time.time()

        for _ in range(iterations):
            # Hard wall on execution time
            if time.time() - start_time > self.max_duration_seconds:
                logger.warning("Agent stopped: max_duration_seconds (%s) reached.", self.max_duration_seconds)
                break

            # start_agent_loop — any capability can halt by returning False
            if any(cap.start_agent_loop(self, action_context) is False for cap in self.capabilities):
                break

            # Build and augment prompt
            prompt = self.construct_prompt(self.goals, memory, self.actions)
            for cap in self.capabilities:
                prompt = cap.process_prompt(self, action_context, prompt)

            if self.verbose:
                print("Agent thinking…")

            # Call the LLM
            response = self.prompt_llm_for_action(prompt)

            if self.verbose:
                print(f"Agent Decision: {response}")

            # Capability post-processing on the raw response
            for cap in self.capabilities:
                response = cap.process_response(self, action_context, response)

            # Parse → look up action
            try:
                action_def, invocation = self.get_action(response)
            except Exception as exc:
                logger.warning("Failed to parse agent response: %s", exc)
                break

            if action_def is None:
                logger.warning("Unknown action in response, stopping: %s", response)
                break

            # Capability hook on the parsed invocation
            for cap in self.capabilities:
                invocation = cap.process_action(self, action_context, invocation)

            # Execute in environment
            result = self.environment.execute_action(
                self, action_context, action_def, invocation.get("args", {})
            )

            if self.verbose:
                print(f"Action Result: {result}")

            # Capability hook on the result
            for cap in self.capabilities:
                result = cap.process_result(
                    self, action_context, response, action_def, invocation, result
                )

            # Build memory entries and let capabilities modify them
            new_memories: List[Dict] = [
                {"type": "assistant", "content": response},
                {"type": "environment", "content": json.dumps(result)},
            ]
            for cap in self.capabilities:
                new_memories = cap.process_new_memories(
                    self, action_context, memory, response, result, new_memories
                )
            for m in new_memories:
                memory.add_memory(m)

            # End-of-loop hook
            for cap in self.capabilities:
                cap.end_agent_loop(self, action_context)

            # Termination checks
            if self.should_terminate(response):
                break
            if any(cap.should_terminate(self, action_context, response) for cap in self.capabilities):
                break

        # Shutdown hook
        for cap in self.capabilities:
            cap.terminate(self, action_context)

        return memory
