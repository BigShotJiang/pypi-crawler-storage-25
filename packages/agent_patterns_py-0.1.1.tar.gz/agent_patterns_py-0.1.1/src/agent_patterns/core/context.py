from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from agent_patterns.core.action import ActionRegistry
    from agent_patterns.core.memory import Memory
    from agent_patterns.multi_agent.registry import AgentRegistry


class ActionContext:
    """
    Runtime dependency-injection container threaded through the agent loop.

    Tools declare dependencies via parameter naming conventions:

    - ``action_context``  → receives the :class:`ActionContext` itself
    - ``action_agent``    → receives the :class:`~agent_patterns.core.agent.Agent`
    - ``_<key>``          → receives ``context.properties[key]``

    All ``_``-prefixed and ``action_*`` parameters are hidden from the LLM's
    tool schema — the agent only sees the "real" business parameters.

    Common keys stored in ``properties``:

    ============== ========================================================
    Key            Value
    ============== ========================================================
    ``memory``     :class:`~agent_patterns.core.memory.Memory` instance
    ``llm``        ``generate_response`` callable
    ``action_registry`` :class:`~agent_patterns.core.action.ActionRegistry`
    ``agent_registry``  :class:`~agent_patterns.multi_agent.registry.AgentRegistry` (optional)
    ``time_zone``  IANA timezone string (used by :class:`~agent_patterns.capabilities.time_aware.TimeAwareCapability`)
    ``auth_token`` Bearer token (example of request-scoped credential)
    ============== ========================================================
    """

    def __init__(self, properties: Optional[Dict[str, Any]] = None) -> None:
        self.context_id: str = str(uuid.uuid4())
        self.properties: Dict[str, Any] = properties or {}

    def get(self, key: str, default: Any = None) -> Any:
        """Return ``properties[key]`` or *default*."""
        return self.properties.get(key, default)

    def get_memory(self) -> Optional["Memory"]:
        return self.properties.get("memory")

    def get_action_registry(self) -> Optional["ActionRegistry"]:
        return self.properties.get("action_registry")

    def get_agent_registry(self) -> Optional["AgentRegistry"]:
        return self.properties.get("agent_registry")
