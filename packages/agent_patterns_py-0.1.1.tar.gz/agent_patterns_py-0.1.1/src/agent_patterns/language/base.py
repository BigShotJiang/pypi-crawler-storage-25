from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List

if TYPE_CHECKING:
    from agent_patterns.core.action import Action
    from agent_patterns.core.environment import Environment
    from agent_patterns.core.goal import Goal
    from agent_patterns.core.memory import Memory


@dataclass
class Prompt:
    """
    A fully-formed LLM request: a list of chat messages and optional
    tool schemas.

    Attributes:
        messages: Chat history in OpenAI / LiteLLM message format.
        tools:    Tool schemas in OpenAI function-calling format.
        metadata: Arbitrary key-value pairs for tracing or routing.
    """

    messages: List[Dict] = field(default_factory=list)
    tools: List[Dict] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)


class AgentLanguage(ABC):
    """
    Translates GAME components into LLM-ready :class:`Prompt` objects and
    parses LLM responses back into structured action invocations.

    Two responsibilities:

    1. **Prompt construction** — combine Goals, Actions, and Memory into a
       prompt the LLM can understand.
    2. **Response parsing** — turn the LLM's raw output into
       ``{"tool": str, "args": dict}``.

    Swap implementations to change the prompting strategy (function
    calling, JSON action blocks, natural language, etc.) without touching
    the agent loop.
    """

    @abstractmethod
    def construct_prompt(
        self,
        actions: List["Action"],
        environment: "Environment",
        goals: List["Goal"],
        memory: "Memory",
    ) -> Prompt:
        """Build a :class:`Prompt` from the current GAME state."""

    @abstractmethod
    def parse_response(self, response: str) -> Dict:
        """
        Parse a raw LLM response into an action invocation dict.

        Must return at minimum ``{"tool": str, "args": dict}``.
        Should fall back gracefully (e.g. synthetic terminate) on failure.
        """

    def adapt_prompt_after_parsing_error(
        self,
        prompt: Prompt,
        response: str,
        traceback_str: str,
        error: Exception,
        retries_left: int,
    ) -> Prompt:
        """
        Optional hook called when :meth:`parse_response` fails.

        Override to inject retry instructions into the prompt.
        Default: returns the prompt unchanged.
        """
        return prompt
