from __future__ import annotations

import json
from typing import TYPE_CHECKING, Dict, List

from agent_patterns.language.base import AgentLanguage, Prompt

if TYPE_CHECKING:
    from agent_patterns.core.action import Action
    from agent_patterns.core.environment import Environment
    from agent_patterns.core.goal import Goal
    from agent_patterns.core.memory import Memory


_ACTION_FORMAT_EXAMPLE = '''
<Stop and think step by step before acting.>

```action
{
    "tool": "tool_name",
    "args": { "param": "value" }
}
```'''


class AgentJsonActionLanguage(AgentLanguage):
    """
    Agent language where the LLM outputs free-form reasoning text and
    embeds its action choice in a fenced ```action … ``` block.

    Use this when:

    - Native function calling is unavailable.
    - You want to inspect the LLM's chain-of-thought in memory.
    - You need a model-agnostic prompting strategy.

    **Prompt construction**

    Goals and actions are both formatted as ``system`` messages.
    Memory items are appended as ``user`` / ``assistant`` turns.

    **Response parsing**

    Extracts the JSON from the innermost ```action … ``` block.
    Falls back to a synthetic ``terminate`` on failure.
    """

    def format_goals(self, goals: List["Goal"]) -> List[Dict]:
        sep = "\n-------------------\n"
        goal_text = "\n\n".join(
            f"{g.name}:{sep}{g.description}{sep}"
            for g in sorted(goals, key=lambda g: g.priority)
        )
        return [{"role": "system", "content": goal_text}]

    def format_memory(self, memory: "Memory") -> List[Dict]:
        mapped = []
        for item in memory.get_memories():
            content = item.get("content") or json.dumps(item, indent=2)
            role = "assistant" if item["type"] in ("assistant", "environment") else "user"
            mapped.append({"role": role, "content": content})
        return mapped

    def format_actions(self, actions: List["Action"]) -> List[Dict]:
        descriptions = [
            {
                "name": a.name,
                "description": a.description[:512],
                "args": a.parameters,
            }
            for a in actions
        ]
        content = (
            f"Available Tools:\n{json.dumps(descriptions, indent=2)}\n\n"
            f"Always respond using this format:{_ACTION_FORMAT_EXAMPLE}"
        )
        return [{"role": "system", "content": content}]

    def construct_prompt(
        self,
        actions: List["Action"],
        environment: "Environment",
        goals: List["Goal"],
        memory: "Memory",
    ) -> Prompt:
        messages: List[Dict] = []
        messages += self.format_goals(goals)
        messages += self.format_actions(actions)
        messages += self.format_memory(memory)
        # No tools list — we use the text block approach
        return Prompt(messages=messages, tools=[])

    def parse_response(self, response: str) -> Dict:
        try:
            stripped = response.strip()
            start = stripped.find("```action")
            end = stripped.rfind("```")
            if start == -1 or end <= start:
                raise ValueError("No ```action block found in response.")
            json_str = stripped[start + len("```action") : end].strip()
            return json.loads(json_str)
        except Exception:
            return {"tool": "terminate", "args": {"message": response}}
