from __future__ import annotations

import json
from typing import TYPE_CHECKING, Dict, List

from agent_patterns.language.base import AgentLanguage, Prompt

if TYPE_CHECKING:
    from agent_patterns.core.action import Action
    from agent_patterns.core.environment import Environment
    from agent_patterns.core.goal import Goal
    from agent_patterns.core.memory import Memory


class AgentFunctionCallingActionLanguage(AgentLanguage):
    """
    Agent language that leverages native LLM function / tool calling.

    **Prompt construction**

    - Goals  → a single ``system`` message (sorted by priority).
    - Memory → chat history mapped to ``user`` / ``assistant`` roles.
    - Actions → OpenAI-style ``tools`` list appended to the :class:`Prompt`.

    **Response parsing**

    Expects the LLM to return a JSON string::

        {"tool": "action_name", "args": {...}}

    On parse failure, falls back to a synthetic ``terminate`` invocation
    so the loop exits gracefully rather than crashing.
    """

    # ------------------------------------------------------------------
    # Formatting helpers
    # ------------------------------------------------------------------

    def format_goals(self, goals: List["Goal"]) -> List[Dict]:
        sep = "\n-------------------\n"
        goal_text = "\n\n".join(
            f"{g.name}:{sep}{g.description}{sep}"
            for g in sorted(goals, key=lambda g: g.priority)
        )
        return [{"role": "system", "content": goal_text}]

    def format_memory(self, memory: "Memory") -> List[Dict]:
        """Map typed memory items to chat message dicts."""
        mapped = []
        for item in memory.get_memories():
            content = item.get("content") or json.dumps(item, indent=2)
            role = "assistant" if item["type"] in ("assistant", "environment") else "user"
            mapped.append({"role": role, "content": content})
        return mapped

    def format_actions(self, actions: List["Action"]) -> List[Dict]:
        """Convert actions to OpenAI function-calling tool schemas."""
        return [
            {
                "type": "function",
                "function": {
                    "name": action.name,
                    "description": action.description[:1024],
                    "parameters": action.parameters,
                },
            }
            for action in actions
        ]

    # ------------------------------------------------------------------
    # AgentLanguage interface
    # ------------------------------------------------------------------

    def construct_prompt(
        self,
        actions: List["Action"],
        environment: "Environment",
        goals: List["Goal"],
        memory: "Memory",
    ) -> Prompt:
        messages: List[Dict] = []
        messages += self.format_goals(goals)
        messages += self.format_memory(memory)
        tools = self.format_actions(actions)
        return Prompt(messages=messages, tools=tools)

    def parse_response(self, response: str) -> Dict:
        try:
            return json.loads(response)
        except Exception:
            # Graceful fallback: treat the response text as a terminal message
            return {"tool": "terminate", "args": {"message": response}}
