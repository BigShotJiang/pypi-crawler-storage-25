"""
agent-patterns
==============

Production-ready boilerplate for common agentic AI patterns in Python.

Quick start::

    from agent_patterns import (
        Agent, Goal, Memory,
        PythonEnvironment,
        AgentFunctionCallingActionLanguage,
        PythonActionRegistry,
        register_tool,
        make_generate_response,
    )

    @register_tool(tags=["my_tools"], terminal=True)
    def terminate(message: str) -> str:
        \"\"\"End the session and return a final message.\"\"\"
        return message

    agent = Agent(
        goals=[Goal(1, "Task", "Complete the assigned task then terminate.")],
        agent_language=AgentFunctionCallingActionLanguage(),
        action_registry=PythonActionRegistry(tags=["my_tools"]),
        generate_response=make_generate_response("openai/gpt-4o"),
        environment=PythonEnvironment(),
    )

    memory = agent.run("Hello!")
"""

# Core GAME components
from agent_patterns.core.goal import Goal
from agent_patterns.core.memory import Memory
from agent_patterns.core.action import Action, ActionRegistry
from agent_patterns.core.context import ActionContext
from agent_patterns.core.environment import Environment, PythonEnvironment
from agent_patterns.core.agent import Agent

# Language strategies
from agent_patterns.language.base import AgentLanguage, Prompt
from agent_patterns.language.function_calling import AgentFunctionCallingActionLanguage
from agent_patterns.language.json_action import AgentJsonActionLanguage

# Tool system
from agent_patterns.tools.registry import register_tool, get_tool_metadata, PythonActionRegistry

# Utilities
from agent_patterns.utils.llm import make_generate_response, generate_response, prompt_llm

# Capabilities
from agent_patterns.capabilities.base import Capability
from agent_patterns.capabilities.plan_first import PlanFirstCapability
from agent_patterns.capabilities.progress_tracking import ProgressTrackingCapability

# Multi-agent
from agent_patterns.multi_agent.registry import AgentRegistry

# Safety
from agent_patterns.safety.reversible import ReversibleAction, ActionTransaction
from agent_patterns.safety.staged import StagedActionEnvironment

__all__ = [
    # Core
    "Goal",
    "Memory",
    "Action",
    "ActionRegistry",
    "ActionContext",
    "Environment",
    "PythonEnvironment",
    "Agent",
    # Language
    "AgentLanguage",
    "Prompt",
    "AgentFunctionCallingActionLanguage",
    "AgentJsonActionLanguage",
    # Tools
    "register_tool",
    "get_tool_metadata",
    "PythonActionRegistry",
    # Utils
    "make_generate_response",
    "generate_response",
    "prompt_llm",
    # Capabilities
    "Capability",
    "PlanFirstCapability",
    "ProgressTrackingCapability",
    # Multi-agent
    "AgentRegistry",
    # Safety
    "ReversibleAction",
    "ActionTransaction",
    "StagedActionEnvironment",
]
