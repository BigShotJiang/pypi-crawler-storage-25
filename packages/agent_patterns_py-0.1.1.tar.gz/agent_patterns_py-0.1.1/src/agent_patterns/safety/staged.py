from __future__ import annotations

import uuid
from typing import Any, Callable, Dict, Optional

from agent_patterns.core.environment import Environment
from agent_patterns.safety.reversible import ActionTransaction


class StagedActionEnvironment(Environment):
    """
    Environment that collects agent actions into named transactions for
    review before execution.

    Enables the *staged execution* safety pattern:

    1. Agent accumulates actions into a transaction via :meth:`stage_actions`.
    2. A reviewer (human or more-capable LLM) approves via :meth:`review_transaction`.
    3. On approval, the transaction executes atomically; on rejection, nothing happens.

    This pattern is valuable when:

    - Some actions are irreversible (sending emails, billing, etc.).
    - A human or governance layer must sign off before side-effects occur.
    - You want an audit trail of planned vs. executed actions.

    Example::

        env = StagedActionEnvironment()
        env.set_reviewer(my_llm_reviewer)

        tx = env.stage_actions(task_id="meeting-123")
        tx.add(create_event, title="Sync", time="2026-04-15T10:00")
        tx.add(send_invite, attendees=["alice@example.com"])

        if env.review_transaction("meeting-123"):
            tx.execute()
            tx.commit()
    """

    def __init__(self) -> None:
        self._transactions: Dict[str, ActionTransaction] = {}
        self._reviewer: Optional[Callable[[str, ActionTransaction], bool]] = None

    def set_reviewer(
        self, reviewer: Callable[[str, ActionTransaction], bool]
    ) -> None:
        """
        Register a reviewer callable.

        The reviewer receives ``(task_id, transaction)`` and returns
        ``True`` to approve or ``False`` to reject.
        """
        self._reviewer = reviewer

    def stage_actions(self, task_id: Optional[str] = None) -> ActionTransaction:
        """Create a new :class:`ActionTransaction` for *task_id*."""
        task_id = task_id or str(uuid.uuid4())
        tx = ActionTransaction()
        self._transactions[task_id] = tx
        return tx

    def review_transaction(self, task_id: str) -> bool:
        """
        Run the registered reviewer against the staged transaction.

        Returns ``False`` if no reviewer is set or the transaction is not found.
        """
        tx = self._transactions.get(task_id)
        if tx is None:
            raise KeyError(f"No staged transaction found for task_id='{task_id}'.")

        if self._reviewer is None:
            raise RuntimeError(
                "No reviewer configured.  Call set_reviewer() before reviewing."
            )

        return self._reviewer(task_id, tx)

    def get_transaction(self, task_id: str) -> Optional[ActionTransaction]:
        """Return the transaction for *task_id*, or ``None``."""
        return self._transactions.get(task_id)

    def execute_action(
        self,
        agent: Any,
        action_context: Any,
        action: Any,
        args: Dict,
    ) -> Dict:
        """
        Standard execution path (used when staging is not required).
        Delegates to the base :class:`~agent_patterns.core.environment.Environment`.
        """
        return super().execute_action(agent, action_context, action, args)
