from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple


class ReversibleAction:
    """
    Wraps a pair of (execute, reverse) callables so that an action can be
    cleanly undone after execution.

    The execution record captures the original arguments and result, making
    the reversal self-contained.

    Example::

        create_event = ReversibleAction(
            execute_func=calendar.create_event,
            reverse_func=lambda **rec: calendar.delete_event(rec["result"]["event_id"]),
        )
        create_event.run(title="Sync", attendees=["alice@example.com"])
        create_event.undo()  # deletes the event

    Args:
        execute_func: The callable that performs the action.
        reverse_func: A callable that undoes the action.  It receives the
                      execution record as keyword arguments.
    """

    def __init__(self, execute_func: Callable, reverse_func: Callable) -> None:
        self.execute_func = execute_func
        self.reverse_func = reverse_func
        self.execution_record: Optional[Dict] = None

    def run(self, **kwargs: Any) -> Any:
        """Execute the action and store a reversal record."""
        result = self.execute_func(**kwargs)
        self.execution_record = {
            "args": kwargs,
            "result": result,
            "timestamp": datetime.now().isoformat(),
        }
        return result

    def undo(self) -> Any:
        """Reverse the action using the stored execution record."""
        if self.execution_record is None:
            raise RuntimeError("No execution record — action has not been run yet.")
        return self.reverse_func(**self.execution_record)


class ActionTransaction:
    """
    Groups multiple :class:`ReversibleAction` executions into an atomic
    unit: either all succeed or all are rolled back.

    This mirrors database transaction semantics for real-world side-effects
    (calendar events, emails, API calls, etc.).

    Example::

        tx = ActionTransaction()
        tx.add(create_event, title="Sync", attendees=["alice@example.com"])
        tx.add(send_invite, event_id="abc123")
        tx.execute()   # runs both; rolls back on failure
        tx.commit()    # marks as final
    """

    def __init__(self) -> None:
        self.transaction_id: str = str(uuid.uuid4())
        self._pending: List[Tuple[ReversibleAction, Dict]] = []
        self._executed: List[ReversibleAction] = []
        self.committed: bool = False

    def add(self, action: ReversibleAction, **kwargs: Any) -> None:
        """Queue *action* with *kwargs* for execution."""
        if self.committed:
            raise RuntimeError("Cannot add actions to a committed transaction.")
        self._pending.append((action, kwargs))

    def execute(self) -> List[Any]:
        """
        Run all queued actions in order.

        On failure, rolls back every action already executed and re-raises
        the exception.
        """
        results = []
        for action, kwargs in self._pending:
            try:
                result = action.run(**kwargs)
                self._executed.append(action)
                results.append(result)
            except Exception as exc:
                self.rollback()
                raise exc
        return results

    def rollback(self) -> None:
        """Undo all executed actions in reverse order."""
        for action in reversed(self._executed):
            try:
                action.undo()
            except Exception:
                pass  # Best-effort rollback; log if needed
        self._executed.clear()

    def commit(self) -> None:
        """Mark the transaction as permanently committed."""
        self.committed = True
