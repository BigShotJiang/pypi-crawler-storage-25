from __future__ import annotations

import json
from typing import TYPE_CHECKING, Callable, List

from agent_patterns.language.base import Prompt

if TYPE_CHECKING:
    from agent_patterns.core.context import ActionContext


def to_openai_tools(tools_metadata: List[dict]) -> List[dict]:
    """
    Convert a list of tool-metadata dicts (from the global registry) to
    OpenAI / LiteLLM function-calling format.
    """
    return [
        {
            "type": "function",
            "function": {
                "name": t["tool_name"],
                "description": t.get("description", "")[:1024],
                "parameters": t.get("parameters", {}),
            },
        }
        for t in tools_metadata
    ]


def make_generate_response(model: str = "openai/gpt-4o") -> Callable[[Prompt], str]:
    """
    Factory that returns a ``generate_response`` callable bound to *model*.

    The returned function is the standard interface expected by
    :class:`~agent_patterns.core.agent.Agent` — it accepts a
    :class:`~agent_patterns.language.base.Prompt` and returns a string:

    - If the LLM made a tool call → JSON: ``{"tool": "…", "args": {…}}``
    - Otherwise → the raw text content

    Example::

        from agent_patterns.utils.llm import make_generate_response

        generate = make_generate_response("anthropic/claude-3-5-sonnet-20241022")
        agent = Agent(..., generate_response=generate, ...)

    Args:
        model: Any model string supported by LiteLLM
               (e.g. ``"openai/gpt-4o"``, ``"anthropic/claude-3-5-sonnet-20241022"``).
    """
    try:
        from litellm import completion as _completion
    except ImportError as exc:
        raise ImportError(
            "litellm is required.  Install with: uv add litellm"
        ) from exc

    def generate_response(prompt: Prompt) -> str:
        messages = prompt.messages
        prompt_tools = prompt.tools

        if not prompt_tools:
            resp = _completion(model=model, messages=messages, max_tokens=1024)
            return resp.choices[0].message.content or ""

        resp = _completion(model=model, messages=messages, tools=prompt_tools, max_tokens=1024)

        if resp.choices[0].message.tool_calls:
            tool = resp.choices[0].message.tool_calls[0]
            result = {
                "tool": tool.function.name,
                "args": json.loads(tool.function.arguments),
            }
            return json.dumps(result)

        return resp.choices[0].message.content or ""

    return generate_response


def prompt_llm(action_context: "ActionContext", prompt: str) -> str:
    """
    Convenience helper: call the LLM stored in *action_context* with a
    single user message and return the text response.

    Used internally by persona and planning tools.
    """
    generate_fn: Callable[[Prompt], str] | None = action_context.get("llm")
    if generate_fn is None:
        raise RuntimeError(
            "No 'llm' found in ActionContext.  "
            "Pass generate_response via action_context_props when calling agent.run()."
        )
    return generate_fn(Prompt(messages=[{"role": "user", "content": prompt}]))


# Default instance bound to GPT-4o.
# Override by constructing your own via make_generate_response().
generate_response = make_generate_response("openai/gpt-4o")
