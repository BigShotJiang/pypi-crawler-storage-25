from __future__ import annotations

from typing import Callable, Dict, Optional


class AgentRegistry:
    """
    Central directory of named agents for multi-agent coordination.

    Store an agent's ``run`` callable here and retrieve it by name
    inside ``call_agent`` tools.

    Example::

        registry = AgentRegistry()
        registry.register_agent("summariser", summariser_agent.run)

        # Later, inside a tool:
        run_fn = registry.get_agent("summariser")
        result_memory = run_fn(user_input="Summarise this…")
    """

    def __init__(self) -> None:
        self._agents: Dict[str, Callable] = {}

    def register_agent(self, name: str, run_function: Callable) -> None:
        """Register *run_function* under *name*."""
        self._agents[name] = run_function

    def get_agent(self, name: str) -> Optional[Callable]:
        """Return the run callable for *name*, or ``None``."""
        return self._agents.get(name)
