from agent_patterns.multi_agent.registry import AgentRegistry

__all__ = ["AgentRegistry"]
