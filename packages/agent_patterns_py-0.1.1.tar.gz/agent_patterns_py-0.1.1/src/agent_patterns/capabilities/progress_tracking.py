from __future__ import annotations

from typing import TYPE_CHECKING, Any

from agent_patterns.capabilities.base import Capability

if TYPE_CHECKING:
    from agent_patterns.core.context import ActionContext


class ProgressTrackingCapability(Capability):
    """
    Adds a progress report to memory at the end of every N iterations.

    After each tracked iteration, invokes
    :func:`~agent_patterns.tools.planning.track_progress` and stores the
    result so the agent can reflect on what it has accomplished and adjust
    its strategy accordingly.

    This is especially useful for long-running tasks where the agent needs
    to self-correct rather than continue executing a stale plan.

    Args:
        memory_type:      Type tag for progress report entries.
        track_frequency:  Generate a report every N iterations (default 1).
    """

    def __init__(
        self,
        memory_type: str = "system",
        track_frequency: int = 1,
    ) -> None:
        super().__init__(
            name="Progress Tracking",
            description="Adds an LLM-generated progress report to memory after each iteration.",
        )
        self.memory_type = memory_type
        self.track_frequency = track_frequency
        self._iteration = 0

    def end_agent_loop(self, agent: Any, action_context: "ActionContext") -> None:
        self._iteration += 1

        if self._iteration % self.track_frequency != 0:
            return

        from agent_patterns.tools.planning import track_progress

        memory = action_context.get_memory()
        action_registry = action_context.get_action_registry()

        if memory is None or action_registry is None:
            return

        report = track_progress(
            action_context=action_context,
            _memory=memory,
            _action_registry=action_registry,
        )

        memory.add_memory({
            "type": self.memory_type,
            "content": f"Progress Report (iteration {self._iteration}):\n\n{report}",
        })
