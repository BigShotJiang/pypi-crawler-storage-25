from __future__ import annotations

from abc import ABC
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from agent_patterns.core.action import Action
    from agent_patterns.core.context import ActionContext
    from agent_patterns.core.memory import Memory
    from agent_patterns.language.base import Prompt


class Capability(ABC):
    """
    Base class for agent loop extensions.

    Capabilities plug into eight lifecycle hooks in the agent loop,
    allowing rich extensions (time awareness, planning, logging, metrics,
    etc.) without modifying :class:`~agent_patterns.core.agent.Agent`.

    All methods have no-op defaults — override only what you need.

    Lifecycle (per ``agent.run()`` call)::

        init()
        ┌─ loop ─────────────────────────────────────────────────────┐
        │  start_agent_loop()   ← return False to stop               │
        │  process_prompt()                                           │
        │  [LLM call]                                                 │
        │  process_response()                                         │
        │  process_action()                                           │
        │  [Environment.execute_action()]                             │
        │  process_result()                                           │
        │  process_new_memories()                                     │
        │  end_agent_loop()                                           │
        │  should_terminate()   ← return True to stop                │
        └─────────────────────────────────────────────────────────────┘
        terminate()
    """

    def __init__(self, name: str, description: str) -> None:
        self.name = name
        self.description = description

    def init(self, agent: Any, action_context: "ActionContext") -> None:
        """Called once before the loop starts. Set up state here."""

    def start_agent_loop(
        self, agent: Any, action_context: "ActionContext"
    ) -> Optional[bool]:
        """
        Called at the start of each iteration.
        Return ``False`` to stop the loop immediately.
        """
        return True

    def process_prompt(
        self, agent: Any, action_context: "ActionContext", prompt: "Prompt"
    ) -> "Prompt":
        """Modify the prompt before it is sent to the LLM."""
        return prompt

    def process_response(
        self, agent: Any, action_context: "ActionContext", response: str
    ) -> str:
        """Modify the raw LLM response before it is parsed."""
        return response

    def process_action(
        self, agent: Any, action_context: "ActionContext", action: Dict
    ) -> Dict:
        """Modify the parsed action invocation before execution."""
        return action

    def process_result(
        self,
        agent: Any,
        action_context: "ActionContext",
        response: str,
        action_def: "Action",
        action: Dict,
        result: Any,
    ) -> Any:
        """Modify the action result before it is stored in memory."""
        return result

    def process_new_memories(
        self,
        agent: Any,
        action_context: "ActionContext",
        memory: "Memory",
        response: str,
        result: Any,
        memories: List[Dict],
    ) -> List[Dict]:
        """Add, remove, or modify memory entries before they are committed."""
        return memories

    def end_agent_loop(self, agent: Any, action_context: "ActionContext") -> None:
        """Called at the end of each iteration (after memory update)."""

    def should_terminate(
        self, agent: Any, action_context: "ActionContext", response: str
    ) -> bool:
        """Return ``True`` to stop the loop after the current iteration."""
        return False

    def terminate(self, agent: Any, action_context: "ActionContext") -> None:
        """Called once when the agent stops (cleanup, flushing, etc.)."""
