from __future__ import annotations

from typing import TYPE_CHECKING, Any

from agent_patterns.capabilities.base import Capability

if TYPE_CHECKING:
    from agent_patterns.core.context import ActionContext


class PlanFirstCapability(Capability):
    """
    Forces the agent to create a detailed execution plan before acting.

    On the first iteration, invokes
    :func:`~agent_patterns.tools.planning.create_plan` and stores the
    result in memory so every subsequent prompt includes the plan.

    This improves reliability for multi-step tasks by anchoring the agent
    to a structured strategy rather than improvising step-by-step.

    Args:
        plan_memory_type: Memory type tag for the plan entry.
                          ``"system"`` keeps it out of the visible
                          conversation while still influencing the prompt.
    """

    def __init__(self, plan_memory_type: str = "system") -> None:
        super().__init__(
            name="Plan First",
            description="Generates an execution plan before the agent takes its first action.",
        )
        self.plan_memory_type = plan_memory_type
        self._planned = False

    def init(self, agent: Any, action_context: "ActionContext") -> None:
        if self._planned:
            return
        self._planned = True

        # Import here to avoid circular imports at module load time
        from agent_patterns.tools.planning import create_plan

        memory = action_context.get_memory()
        action_registry = action_context.get_action_registry()

        if memory is None or action_registry is None:
            return

        plan = create_plan(
            action_context=action_context,
            _memory=memory,
            _action_registry=action_registry,
        )

        memory.add_memory({
            "type": self.plan_memory_type,
            "content": (
                "You must follow these instructions carefully to complete the task:\n\n"
                + plan
            ),
        })
