from __future__ import annotations

from typing import TYPE_CHECKING

from agent_patterns.language.base import Prompt
from agent_patterns.tools.registry import register_tool
from agent_patterns.utils.llm import prompt_llm

if TYPE_CHECKING:
    from agent_patterns.core.context import ActionContext


@register_tool()
def prompt_expert(
    action_context: "ActionContext",
    description_of_expert: str,
    prompt: str,
) -> str:
    """
    Generate a response from a described expert persona.

    The persona pattern activates the LLM's pre-trained knowledge about a
    specific role with remarkable token efficiency — a short expert
    description unlocks deep domain reasoning without spelling out every
    rule.

    Args:
        description_of_expert: Detailed background, specialisation, and
                                approach of the expert.
        prompt:                 The question or task for the expert.

    Returns:
        The expert's response as a string.
    """
    generate_fn = action_context.get("llm")
    return generate_fn(
        Prompt(
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Act as the following expert and respond accordingly:\n\n"
                        + description_of_expert
                    ),
                },
                {"role": "user", "content": prompt},
            ]
        )
    )


@register_tool()
def create_and_consult_expert(
    action_context: "ActionContext",
    expertise_domain: str,
    problem_description: str,
) -> str:
    """
    Dynamically generate an expert persona tailored to the problem, then
    consult it.

    Lets the LLM craft the ideal specialist for any niche domain at runtime
    rather than relying on pre-defined personas.

    Args:
        expertise_domain:    The field of expertise needed.
        problem_description: Detailed description of the problem.

    Returns:
        The dynamically created expert's insights and recommendations.
    """
    persona_description = prompt_llm(
        action_context,
        f"""Create a detailed description of an expert in {expertise_domain} ideally
suited to address this problem:

{problem_description}

Include:
- Background and years of experience
- Specific sub-specialisations within {expertise_domain}
- Problem-solving approach and methodology
- The unique perspective they bring""",
    )

    consultation_prompt = prompt_llm(
        action_context,
        f"""Create a detailed consultation prompt for an expert in {expertise_domain}
addressing this problem:

{problem_description}

The prompt should elicit comprehensive insights and actionable recommendations.""",
    )

    return prompt_expert(
        action_context=action_context,
        description_of_expert=persona_description,
        prompt=consultation_prompt,
    )
