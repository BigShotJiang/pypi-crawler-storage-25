from __future__ import annotations

import inspect
from typing import Any, Callable, Dict, List, Optional, get_type_hints

from agent_patterns.core.action import Action, ActionRegistry


# ---------------------------------------------------------------------------
# Global tool registry — populated by @register_tool at import time
# ---------------------------------------------------------------------------

#: All registered tools keyed by tool name.
tools: Dict[str, Dict] = {}

#: Tool names grouped by tag for quick filtering.
tools_by_tag: Dict[str, List[str]] = {}


# ---------------------------------------------------------------------------
# Type mapping
# ---------------------------------------------------------------------------

def _get_json_type(python_type: Any) -> str:
    """Map a Python type annotation to a JSON Schema type string."""
    _MAP: Dict[Any, str] = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
    }
    return _MAP.get(python_type, "string")


# ---------------------------------------------------------------------------
# Metadata extraction
# ---------------------------------------------------------------------------

def get_tool_metadata(
    func: Callable,
    tool_name: Optional[str] = None,
    description: Optional[str] = None,
    parameters_override: Optional[Dict] = None,
    terminal: bool = False,
    tags: Optional[List[str]] = None,
) -> Dict:
    """
    Introspect *func* and return a metadata dict ready for tool registration.

    The JSON Schema for ``parameters`` is built automatically from type
    hints and the function signature.  Pass *parameters_override* to supply
    a hand-crafted schema instead.

    Special parameters excluded from the schema (invisible to the LLM):

    - ``action_context`` — injected by :class:`~agent_patterns.core.environment.PythonEnvironment`
    - ``action_agent``   — injected by :class:`~agent_patterns.core.environment.PythonEnvironment`
    - Any parameter whose name starts with ``_`` (DI convention)
    """
    tool_name = tool_name or func.__name__
    description = description or (
        func.__doc__.strip() if func.__doc__ else "No description provided."
    )

    if parameters_override is not None:
        args_schema = parameters_override
    else:
        sig = inspect.signature(func)
        try:
            hints = get_type_hints(func)
        except Exception:
            hints = {}

        args_schema: Dict = {"type": "object", "properties": {}, "required": []}
        _SKIP = {"action_context", "action_agent"}

        for param_name, param in sig.parameters.items():
            if param_name in _SKIP or param_name.startswith("_"):
                continue

            param_type = hints.get(param_name, str)
            args_schema["properties"][param_name] = {"type": _get_json_type(param_type)}

            if param.default is inspect.Parameter.empty:
                args_schema["required"].append(param_name)

    return {
        "tool_name": tool_name,
        "description": description,
        "parameters": args_schema,
        "function": func,
        "terminal": terminal,
        "tags": tags or [],
    }


# ---------------------------------------------------------------------------
# Decorator
# ---------------------------------------------------------------------------

def register_tool(
    tool_name: Optional[str] = None,
    description: Optional[str] = None,
    parameters_override: Optional[Dict] = None,
    terminal: bool = False,
    tags: Optional[List[str]] = None,
) -> Callable:
    """
    Decorator that registers a function as an agent tool.

    Automatically extracts the tool name (from ``func.__name__``),
    description (from the docstring), and parameter schema (from type
    hints) — keeping code and documentation in sync.

    Example::

        @register_tool(tags=["file_ops"])
        def read_file(path: str) -> str:
            \"\"\"Read a file and return its contents.\"\"\"
            with open(path) as f:
                return f.read()

    Args:
        tool_name:           Override the function name as the tool name.
        description:         Override the docstring as the description.
        parameters_override: Supply a hand-crafted JSON Schema dict.
        terminal:            If ``True`` the agent loop stops after this tool.
        tags:                Categorisation tags for :class:`PythonActionRegistry`.
    """
    def decorator(func: Callable) -> Callable:
        meta = get_tool_metadata(
            func=func,
            tool_name=tool_name,
            description=description,
            parameters_override=parameters_override,
            terminal=terminal,
            tags=tags,
        )

        tools[meta["tool_name"]] = {
            "description": meta["description"],
            "parameters": meta["parameters"],
            "function": meta["function"],
            "terminal": meta["terminal"],
            "tags": meta["tags"],
        }

        for tag in meta["tags"]:
            tools_by_tag.setdefault(tag, []).append(meta["tool_name"])

        return func

    return decorator


# ---------------------------------------------------------------------------
# Tag-filtered ActionRegistry
# ---------------------------------------------------------------------------

class PythonActionRegistry(ActionRegistry):
    """
    :class:`~agent_patterns.core.action.ActionRegistry` populated
    automatically from the global ``tools`` dict at construction time.

    Filter by ``tags`` and / or ``tool_names``.  A tool is included when
    it matches *either* filter.  If neither is supplied **all** tools are
    registered.

    The special ``terminate`` tool is stored internally and must be
    explicitly added via :meth:`register_terminate_tool` (or it will be
    included automatically if it matches a tag / name filter).

    Example::

        # Include all tools tagged "file_ops" plus the terminate tool
        registry = PythonActionRegistry(tags=["file_ops"])
        registry.register_terminate_tool()
    """

    def __init__(
        self,
        tags: Optional[List[str]] = None,
        tool_names: Optional[List[str]] = None,
    ) -> None:
        super().__init__()
        self._terminate_meta: Optional[Dict] = None

        for name, tool_desc in tools.items():
            if name == "terminate":
                self._terminate_meta = tool_desc
                # Only auto-include if matched by filter; otherwise use
                # register_terminate_tool() for explicit control.

            tool_tags: List[str] = tool_desc.get("tags", [])
            name_match = bool(tool_names and name in tool_names)
            tag_match = bool(tags and any(t in tool_tags for t in tags))
            no_filter = tags is None and tool_names is None

            if not (name_match or tag_match or no_filter):
                continue

            self.register(
                Action(
                    name=name,
                    function=tool_desc["function"],
                    description=tool_desc["description"],
                    parameters=tool_desc.get("parameters", {}),
                    terminal=tool_desc.get("terminal", False),
                )
            )

    def register_terminate_tool(self) -> None:
        """Explicitly add the ``terminate`` tool to this registry."""
        if self._terminate_meta is None:
            raise RuntimeError(
                "No 'terminate' tool found in the global registry. "
                "Decorate a function with @register_tool(terminal=True)."
            )
        t = self._terminate_meta
        self.register(
            Action(
                name="terminate",
                function=t["function"],
                description=t["description"],
                parameters=t.get("parameters", {}),
                terminal=t.get("terminal", True),
            )
        )
