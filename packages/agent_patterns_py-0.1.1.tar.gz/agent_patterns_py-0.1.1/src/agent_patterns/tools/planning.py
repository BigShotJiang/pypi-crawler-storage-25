from __future__ import annotations

from typing import TYPE_CHECKING

from agent_patterns.tools.registry import register_tool
from agent_patterns.utils.llm import prompt_llm

if TYPE_CHECKING:
    from agent_patterns.core.action import ActionRegistry
    from agent_patterns.core.context import ActionContext
    from agent_patterns.core.memory import Memory


@register_tool(tags=["planning"])
def create_plan(
    action_context: "ActionContext",
    _memory: "Memory",
    _action_registry: "ActionRegistry",
) -> str:
    """
    Create a detailed step-by-step execution plan for the current task.

    Analyses the task in memory and available tools, then produces a
    numbered plan with tool assignments and expected outcomes for each step.

    Used directly by :class:`~agent_patterns.capabilities.plan_first.PlanFirstCapability`
    and optionally exposed as a tool agents can call themselves.

    Note: ``_memory`` and ``_action_registry`` are injected automatically by
    :class:`~agent_patterns.core.environment.PythonEnvironment` — the LLM
    never sees these parameters.
    """
    tool_descriptions = "\n".join(
        f"- {action.name}: {action.description}"
        for action in _action_registry.get_actions()
    )

    memory_content = "\n".join(
        f"{m['type']}: {m['content']}"
        for m in _memory.items
        if m.get("type") in ("user", "system")
    )

    return prompt_llm(
        action_context,
        f"""Given the task and available tools, create a detailed execution plan.

Think through this step by step:
1. Identify the key components of the task.
2. Consider which tools are relevant.
3. Break the task into logical, ordered steps.
4. For each step specify:
   - What needs to be done
   - Which tool(s) to use
   - What information is needed
   - The expected outcome

Write the plan as clear, numbered steps. Each step must be specific and actionable.

Available tools:
{tool_descriptions}

Task context from memory:
{memory_content}

Create a plan that accomplishes this task efficiently.""",
    )


@register_tool(tags=["planning"])
def track_progress(
    action_context: "ActionContext",
    _memory: "Memory",
    _action_registry: "ActionRegistry",
) -> str:
    """
    Generate a progress report for the current task.

    Reviews what has been accomplished, identifies blockers, and
    recommends next steps and relevant tools.

    Used by :class:`~agent_patterns.capabilities.progress_tracking.ProgressTrackingCapability`
    at the end of each agent loop iteration.

    Note: ``_memory`` and ``_action_registry`` are injected automatically.
    """
    tool_descriptions = "\n".join(
        f"- {action.name}: {action.description}"
        for action in _action_registry.get_actions()
    )

    memory_content = "\n".join(
        f"{m['type']}: {m['content']}"
        for m in _memory.items
        if m.get("type") in ("user", "system")
    )

    return prompt_llm(
        action_context,
        f"""Given the current task and available tools, generate a progress report.

Think through this step by step:
1. What is the intended outcome?
2. What progress has been made so far?
3. Are there any blockers or issues?
4. What are the recommended next steps?
5. Which tools would help complete the task?

Available tools:
{tool_descriptions}

Task context from memory:
{memory_content}

Provide a concise, structured progress report with clear next steps.""",
    )
