from __future__ import annotations

from typing import TYPE_CHECKING, Dict

from agent_patterns.core.memory import Memory
from agent_patterns.tools.registry import register_tool

if TYPE_CHECKING:
    from agent_patterns.core.context import ActionContext


@register_tool()
def call_agent(
    action_context: "ActionContext",
    agent_name: str,
    task: str,
) -> Dict:
    """
    Invoke a named agent to perform a sub-task and return its result.

    Enables multi-agent coordination: a primary agent can delegate
    specialised work to sub-agents registered in the
    :class:`~agent_patterns.multi_agent.registry.AgentRegistry`.

    Each invocation creates a **fresh** :class:`~agent_patterns.core.memory.Memory`
    instance for the called agent, preventing memory cross-contamination.
    Context properties are forwarded selectively — the ``agent_registry``
    is intentionally withheld to prevent infinite recursion.

    Args:
        agent_name: Name the sub-agent was registered under.
        task:       The task description to pass to the sub-agent.

    Returns:
        ``{"success": True, "agent": str, "result": str}``
        or ``{"success": False, "error": str}``
    """
    agent_registry = action_context.get_agent_registry()
    if agent_registry is None:
        return {"success": False, "error": "No agent_registry found in ActionContext."}

    agent_run = agent_registry.get_agent(agent_name)
    if agent_run is None:
        return {"success": False, "error": f"Agent '{agent_name}' not found in registry."}

    # Forward only safe context props — exclude agent_registry to prevent loops
    _EXCLUDE = {"agent_registry", "memory"}
    forwarded = {
        k: v for k, v in action_context.properties.items() if k not in _EXCLUDE
    }

    invoked_memory = Memory()

    try:
        result_memory = agent_run(
            user_input=task,
            memory=invoked_memory,
            action_context_props=forwarded,
        )

        if result_memory.items:
            last = result_memory.items[-1]
            return {
                "success": True,
                "agent": agent_name,
                "result": last.get("content", "No result content."),
            }

        return {"success": False, "error": "Agent produced no memory items."}

    except Exception as exc:
        return {"success": False, "error": str(exc)}
