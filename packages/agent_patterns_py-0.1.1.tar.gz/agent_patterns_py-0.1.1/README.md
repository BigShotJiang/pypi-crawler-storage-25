# agent-patterns

A Python framework for building production-ready AI agents using the GAME pattern (Goals, Actions, Memory, Environment).

---

## Install

```bash
pip install agent-patterns-py
```

Or clone to run the examples:

```bash
git clone https://github.com/abdul-moiz-cowlar/agent-patterns.git
cd agent-patterns
uv sync
cp .env.example .env  # add your API keys
```

---

## Quick start

```python
import os
from agent_patterns import (
    Agent, Goal,
    PythonEnvironment,
    AgentFunctionCallingActionLanguage,
    PythonActionRegistry,
    register_tool,
    make_generate_response,
)

@register_tool(tags=["files"])
def list_files() -> list:
    """List files in the current directory."""
    return os.listdir(".")

@register_tool(tags=["files"])
def read_file(name: str) -> str:
    """Read a file and return its contents."""
    with open(name) as f:
        return f.read()

@register_tool(tags=["system"], terminal=True)
def terminate(message: str) -> str:
    """End the session with a final message."""
    return message

agent = Agent(
    goals=[
        Goal(1, "Explore", "List and read files in the current directory."),
        Goal(2, "Terminate", "Call terminate with a summary when done."),
    ],
    agent_language=AgentFunctionCallingActionLanguage(),
    action_registry=PythonActionRegistry(tags=["files", "system"]),
    generate_response=make_generate_response("openai/gpt-4o"),
    environment=PythonEnvironment(),
)

memory = agent.run("What Python files are here and what do they do?")
```

---

## Docs

- [Switching models](https://github.com/moiz-09x/agent-patterns/blob/main/docs/models.md)
- [Agent language strategies](https://github.com/moiz-09x/agent-patterns/blob/main/docs/agent-language.md)
- [Capabilities](https://github.com/moiz-09x/agent-patterns/blob/main/docs/capabilities.md)
- [Dependency injection](https://github.com/moiz-09x/agent-patterns/blob/main/docs/dependency-injection.md)
- [Multi-agent](https://github.com/moiz-09x/agent-patterns/blob/main/docs/multi-agent.md)
- [Safety patterns](https://github.com/moiz-09x/agent-patterns/blob/main/docs/safety.md)

---

## License

MIT
