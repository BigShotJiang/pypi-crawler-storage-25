# Agent language strategies

`AgentLanguage` controls two things:

1. **How GAME components are formatted into a prompt** sent to the LLM
2. **How the LLM's response is parsed** back into an action

Swapping the language changes the prompting strategy without touching the agent loop.

---

## Function calling (recommended)

Uses the LLM's native tool/function calling API. The LLM returns a structured tool call — no text parsing needed.

```python
from agent_patterns import AgentFunctionCallingActionLanguage

agent = Agent(
    ...
    agent_language=AgentFunctionCallingActionLanguage(),
)
```

**When to use:** Almost always. More reliable, no prompt engineering needed to get structured output.

---

## JSON action blocks

The LLM outputs free-form reasoning text and embeds its action in a fenced ` ```action ``` ` block:

```
I'll start by listing the files.

```action
{
    "tool": "list_files",
    "args": {}
}
```

```python
from agent_patterns import AgentJsonActionLanguage

agent = Agent(
    ...
    agent_language=AgentJsonActionLanguage(),
)
```

**When to use:**
- The model doesn't support native function calling
- You want the agent's reasoning visible in memory
- You need a model-agnostic fallback

---

## Custom language

Subclass `AgentLanguage` and implement two methods:

```python
from agent_patterns import AgentLanguage, Prompt

class MyLanguage(AgentLanguage):
    def construct_prompt(self, actions, environment, goals, memory) -> Prompt:
        # build and return a Prompt however you like
        ...

    def parse_response(self, response: str) -> dict:
        # return {"tool": "...", "args": {...}}
        ...
```
