# Dependency injection

Tools often need access to things beyond their explicit arguments — a database connection, an auth token, the agent's memory. Rather than hardcoding these or passing them through the LLM, the framework injects them automatically based on parameter naming conventions.

---

## How it works

When `PythonEnvironment` executes a tool, it inspects the function's parameters and injects matching values before calling it. Three conventions are supported:

| Parameter name | What gets injected |
|---------------|-------------------|
| `action_context` | The live `ActionContext` for this run |
| `action_agent` | The `Agent` instance |
| `_<key>` | `action_context.properties[key]` |

These parameters are **hidden from the LLM** — they never appear in the tool's JSON schema.

---

## action_context

Use this when you need direct access to the context object:

```python
from agent_patterns import register_tool, ActionContext

@register_tool(tags=["llm"])
def summarise(action_context: ActionContext, text: str) -> str:
    """Summarise the given text."""
    generate = action_context.get("llm")
    return generate(Prompt(messages=[
        {"role": "user", "content": f"Summarise: {text}"}
    ]))
```

---

## _prefixed parameters

For injecting specific values from the context, prefix the parameter name with `_`:

```python
@register_tool(tags=["db"])
def query(action_context: ActionContext, sql: str, _db_conn) -> list:
    """Run a SQL query."""
    return _db_conn.execute(sql).fetchall()
```

Then pass `db_conn` (without the underscore) when running the agent:

```python
agent.run(
    "Find all users created this month.",
    action_context_props={"db_conn": my_db_connection},
)
```

`_db_conn` maps to `action_context.properties["db_conn"]` automatically.

---

## Common injected values

```python
agent.run(
    "Process the request.",
    action_context_props={
        "auth_token": "Bearer abc123",   # → _auth_token
        "db_conn": db,                   # → _db_conn
        "user_config": config,           # → _user_config
        "agent_registry": registry,      # → used by call_agent
    },
)
```

---

## Using base Environment

If you use the base `Environment` instead of `PythonEnvironment`, no injection happens — tools receive only the arguments the LLM explicitly provided.

```python
from agent_patterns import Environment  # no DI
from agent_patterns import PythonEnvironment  # with DI
```
