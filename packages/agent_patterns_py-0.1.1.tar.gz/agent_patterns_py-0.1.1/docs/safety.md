# Safety patterns

Three patterns for agents that take real-world actions (calendar events, emails, API calls, etc.).

---

## Reversible actions

Wrap any action so it can be undone:

```python
from agent_patterns import ReversibleAction

create_event = ReversibleAction(
    execute_func=calendar.create_event,
    reverse_func=lambda **record: calendar.delete_event(record["result"]["event_id"]),
)

# Execute
result = create_event.run(title="Sync", attendees=["alice@example.com"])

# Undo if needed
create_event.undo()
```

The `reverse_func` receives the full execution record as kwargs:

```python
{
    "args": {...},        # original arguments
    "result": {...},      # return value from execute_func
    "timestamp": "...",   # ISO timestamp
}
```

---

## Action transactions

Group multiple reversible actions into an atomic unit — all succeed or all roll back:

```python
from agent_patterns import ActionTransaction, ReversibleAction

tx = ActionTransaction()
tx.add(create_event, title="Sync", attendees=["alice@example.com"])
tx.add(send_invite, event_id="abc123")

try:
    tx.execute()   # runs both; rolls back automatically on failure
    tx.commit()    # marks as final
except Exception as e:
    print(f"Transaction failed and was rolled back: {e}")
```

---

## Staged execution

Collect actions for review before executing them. Useful when a human or a more capable model should sign off before side-effects occur:

```python
from agent_patterns import StagedActionEnvironment, ReversibleAction

env = StagedActionEnvironment()

# Register a reviewer — returns True to approve, False to reject
def my_reviewer(task_id, transaction):
    print(f"Approving {len(transaction._pending)} actions for task {task_id}")
    return True  # or False to reject

env.set_reviewer(my_reviewer)

# Stage actions
tx = env.stage_actions(task_id="meeting-setup")
tx.add(create_event, title="Team sync")
tx.add(send_invite, attendees=["team@example.com"])

# Review, then execute
if env.review_transaction("meeting-setup"):
    tx.execute()
    tx.commit()
```

The reviewer can be a human approval step, an LLM policy check, or any callable that returns a bool.
