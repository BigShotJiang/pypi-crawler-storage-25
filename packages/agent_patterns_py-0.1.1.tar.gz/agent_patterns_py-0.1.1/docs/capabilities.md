# Capabilities

Capabilities extend the agent loop at specific lifecycle points without modifying the `Agent` class. Pass a list of them when creating an agent:

```python
from agent_patterns import Agent, PlanFirstCapability, ProgressTrackingCapability

agent = Agent(
    ...
    capabilities=[
        PlanFirstCapability(),
        ProgressTrackingCapability(track_frequency=3),
    ],
)
```

---

## Built-in capabilities

### PlanFirstCapability

Before the agent takes its first action, generates a detailed step-by-step execution plan and stores it in memory. Every subsequent prompt includes the plan, keeping the agent on track for multi-step tasks.

```python
from agent_patterns import PlanFirstCapability

PlanFirstCapability(
    plan_memory_type="system",  # memory type for the plan entry (default: "system")
)
```

---

### ProgressTrackingCapability

At the end of every N iterations, generates a progress report (what's done, any blockers, recommended next steps) and adds it to memory. Useful for long-running tasks where the agent needs to self-correct.

```python
from agent_patterns import ProgressTrackingCapability

ProgressTrackingCapability(
    memory_type="system",    # memory type for report entries (default: "system")
    track_frequency=1,       # generate a report every N iterations (default: 1)
)
```

---

## Writing your own

Subclass `Capability` and override only the hooks you need:

```python
from agent_patterns import Capability

class LoggingCapability(Capability):
    def __init__(self):
        super().__init__(name="Logging", description="Logs every action taken.")

    def process_action(self, agent, action_context, action):
        print(f"[LOG] action={action['tool']} args={action.get('args')}")
        return action  # always return the (optionally modified) value
```

### Available hooks

| Method | Called when | Return |
|--------|------------|--------|
| `init` | Once, before the loop starts | — |
| `start_agent_loop` | Start of each iteration | `False` to stop the loop |
| `process_prompt` | Before the prompt is sent to the LLM | modified `Prompt` |
| `process_response` | After the LLM responds, before parsing | modified response `str` |
| `process_action` | After parsing, before execution | modified action `dict` |
| `process_result` | After execution | modified result |
| `process_new_memories` | Before memory entries are committed | modified `list[dict]` |
| `end_agent_loop` | End of each iteration | — |
| `should_terminate` | After memory update | `True` to stop the loop |
| `terminate` | Once, when the agent stops | — |
