# Multi-agent

One agent can delegate tasks to other agents using the built-in `call_agent` tool and `AgentRegistry`.

---

## Setup

### 1. Create your agents

```python
from agent_patterns import Agent, Goal, PythonEnvironment, AgentFunctionCallingActionLanguage, PythonActionRegistry, make_generate_response

summariser = Agent(
    goals=[Goal(1, "Summarise", "Summarise the provided text concisely then terminate.")],
    agent_language=AgentFunctionCallingActionLanguage(),
    action_registry=PythonActionRegistry(tags=["summariser", "system"]),
    generate_response=make_generate_response("openai/gpt-4o-mini"),
    environment=PythonEnvironment(),
)
```

### 2. Register them

```python
from agent_patterns import AgentRegistry

registry = AgentRegistry()
registry.register_agent("summariser", summariser.run)
```

### 3. Give the coordinator the call_agent tool

```python
# Import to register it in the global tool registry
import agent_patterns.tools.agent_tools  # noqa: F401

coordinator = Agent(
    goals=[Goal(1, "Coordinate", "Delegate tasks to specialist agents as needed.")],
    agent_language=AgentFunctionCallingActionLanguage(),
    action_registry=PythonActionRegistry(tags=["coordinator", "system"]),
    generate_response=make_generate_response("openai/gpt-4o"),
    environment=PythonEnvironment(),
)
```

### 4. Pass the registry at runtime

```python
memory = coordinator.run(
    "Summarise this report: ...",
    action_context_props={"agent_registry": registry},
)
```

---

## How call_agent works

When the coordinator calls `call_agent`:

- A **fresh memory** is created for the sub-agent (no memory leakage between agents)
- Context properties are forwarded, except `agent_registry` and `memory` (prevents infinite recursion)
- The sub-agent's final memory item is returned as the result

---

## Memory sharing patterns

Beyond basic message passing, you can control how much context a sub-agent receives by what you pass in `action_context_props`. Four patterns, in order of context shared:

| Pattern | How |
|---------|-----|
| Message passing | Default — fresh memory, task only |
| Memory handoff | Pass `memory=existing_memory` to `agent.run()` |
| Memory reflection | Copy sub-agent memories back to caller after the call |
| Selective sharing | Filter memories before passing them to the sub-agent |
