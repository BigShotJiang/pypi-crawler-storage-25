# Switching models

The framework uses [LiteLLM](https://docs.litellm.ai) under the hood, so any model LiteLLM supports works out of the box.

Use `make_generate_response` to create a callable bound to a specific model and pass it to your agent:

```python
from agent_patterns import make_generate_response, Agent

agent = Agent(
    ...
    generate_response=make_generate_response("openai/gpt-4o"),
)
```

## Examples

```python
# OpenAI
make_generate_response("openai/gpt-4o")
make_generate_response("openai/gpt-4o-mini")

# Anthropic
make_generate_response("anthropic/claude-opus-4-5")
make_generate_response("anthropic/claude-sonnet-4-5")

# Any other LiteLLM-supported provider
make_generate_response("groq/llama-3.1-70b-versatile")
```

## Different models per agent

Each agent gets its own `generate_response` callable, so you can mix models freely:

```python
fast_agent = Agent(
    ...
    generate_response=make_generate_response("openai/gpt-4o-mini"),
)

smart_agent = Agent(
    ...
    generate_response=make_generate_response("anthropic/claude-opus-4-5"),
)
```

## Using a custom LLM function

`generate_response` is just a callable with the signature `(Prompt) -> str`. You can pass anything that matches:

```python
def my_llm(prompt: Prompt) -> str:
    # call any API you want
    ...

agent = Agent(..., generate_response=my_llm)
```
