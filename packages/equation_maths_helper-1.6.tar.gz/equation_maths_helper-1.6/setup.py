from setuptools import setup, find_packages

import shutil
import sys


def readme():
  with open('README.md', 'r', encoding='utf-8') as file:
    shutil.copyfileobj(file, sys.stdout)


setup(
  name='equation_maths_helper',
  version='1.6',
  author='Danil1310',
  author_email='zdan131011@gmail.com',
  description= "ENG: A module that allows you to solve quadratic and linear equations. | RU: Модуль, позволяющий решать квадратные и линейные уравнения.",
  long_description=readme(),
  long_description_content_type='text/markdown',
  url='https://github.com/Danil1310/equation_maths_helper.git',
  packages=find_packages(),
  install_requires=['requests>=2.25.1'],
  classifiers=[
    'Programming Language :: Python :: 3.11',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent'
  ],
  keywords='equation ',
  project_urls={
    'GitHub': 'https://github.com/Danil1310/equation_maths_helper.git'
  },
  python_requires='>=3.6'
)