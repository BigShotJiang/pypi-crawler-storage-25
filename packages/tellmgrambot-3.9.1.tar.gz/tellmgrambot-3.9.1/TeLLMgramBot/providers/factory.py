from .base import LLMProvider
from .openai_provider import OpenAIProvider
from .anthropic_provider import AnthropicProvider

_providers: dict[str, LLMProvider] = {}

def get_provider(model: str) -> LLMProvider:
    """
    Return the appropriate LLM provider for the given model name.

    Provider is inferred from the model name prefix:
      - 'claude-' -> AnthropicProvider
      - anything else -> OpenAIProvider
    """
    if model.startswith('claude-'):
        key = 'anthropic'
        if key not in _providers:
            _providers[key] = AnthropicProvider()
        return _providers[key]
    else:
        key = 'openai'
        if key not in _providers:
            _providers[key] = OpenAIProvider()
        return _providers[key]
