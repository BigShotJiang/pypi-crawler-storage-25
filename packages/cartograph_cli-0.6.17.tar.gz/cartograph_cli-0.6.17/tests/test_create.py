"""
Tests for widget scaffolding via create().
create() returns {"status": "success", "path": ..., "item_id": ...}
or {"status": "error", "message": ...}
"""
import os
import json
import pytest


def _assert_scaffold(widget_dir, expected_paths):
    for rel_path in expected_paths:
        full = os.path.join(widget_dir, rel_path)
        assert os.path.exists(full), f"Expected scaffold path missing: {rel_path}"


def test_create_python_widget(carto, tmp_path):
    result = carto.create(
        "my-widget",
        language="python",
        name="My Widget",
        domain="backend",
        tags=["test"],
        target_dir=str(tmp_path),
    )
    assert result.get("status") == "success"
    _assert_scaffold(result["path"], ["widget.json", "src", "tests", "examples"])


def test_create_javascript_widget(carto, tmp_path):
    result = carto.create(
        "my-js-widget",
        language="javascript",
        name="My JS Widget",
        domain="frontend",
        tags=["ui"],
        target_dir=str(tmp_path),
    )
    assert result.get("status") == "success"
    _assert_scaffold(result["path"], ["widget.json", "src", "tests"])


def test_create_widget_manifest_valid(carto, tmp_path):
    result = carto.create(
        "manifest-widget",
        language="python",
        name="Manifest Widget",
        domain="backend",
        tags=["manifest", "test"],
        target_dir=str(tmp_path),
    )
    assert result.get("status") == "success"
    manifest_path = os.path.join(result["path"], "widget.json")
    assert os.path.exists(manifest_path)
    with open(manifest_path) as f:
        data = json.load(f)
    meta = data.get("meta", data)
    # create() appends the language to the id (e.g. "manifest-widget-python")
    assert "manifest-widget" in meta.get("id", "")
    assert "tags" in meta


def test_create_angular_widget(carto, tmp_path):
    result = carto.create(
        "my-ng-widget",
        language="angular",
        name="My Angular Widget",
        domain="frontend",
        tags=["ui"],
        target_dir=str(tmp_path),
    )
    assert result.get("status") == "success"
    # scaffolding/__init__.py converts hyphens to underscores in module_name
    _assert_scaffold(result["path"], [
        "widget.json",
        "angular.json",
        "package.json",
        "karma.conf.js",
        "ng-package.json",
        "tsconfig.json",
        "tsconfig.lib.json",
        "tsconfig.spec.json",
        "src/test.ts",
        "src/public-api.ts",
        "src/my_ng_widget.component.ts",
        "tests/test_my_ng_widget.component.ts",
        "examples/example_usage.ts",
    ])


def test_create_php_widget(carto, tmp_path):
    result = carto.create(
        "my-php-widget",
        language="php",
        name="My PHP Widget",
        domain="backend",
        tags=["utility"],
        target_dir=str(tmp_path),
    )
    assert result.get("status") == "success"
    _assert_scaffold(result["path"], [
        "widget.json",
        "composer.json",
        "phpunit.xml",
        "src/MyPhpWidget.php",
        "tests/MyPhpWidgetTest.php",
        "examples/example_usage.php",
    ])


def test_create_duplicate_widget_errors(carto, tmp_path):
    carto.create("dupe-widget", language="python", name="Dupe", domain="backend", tags=[], target_dir=str(tmp_path))
    result = carto.create("dupe-widget", language="python", name="Dupe", domain="backend", tags=[], target_dir=str(tmp_path))
    assert result.get("status") == "error"
