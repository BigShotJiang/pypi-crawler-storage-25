"""
Custom validation rules - user-defined checks that run during validation.

A rules file is a single script per language that receives the widget path
as its first argument and prints JSON to stdout:

    {"blocks": ["hard failure", ...], "warnings": ["soft warning", ...]}

Empty arrays or no output means all checks passed. Non-zero exit or
invalid JSON is treated as a block with the error details.

File locations (both run if both exist, project first):
    .cartograph/rules/rules.py       per-project rules
    <data_dir>/rules/rules.py        global rules

Fixed filenames per language:
    python        rules.py
    javascript    rules.js
    typescript    rules.typescript.js
    nim           rules.nim
    angular       rules.angular.js
    php           rules.php
    openscad      rules.openscad.py
    systemverilog rules.sv.py
    css           rules.css.js
"""

import json
import logging
import os
import subprocess
import sys

log = logging.getLogger("cartograph")

# Maps widget language -> (filename, runner command)
# Each language gets its own rules file so team conventions stay isolated.
_LANGUAGE_RULES = {
    "python":        ("rules.py",            [sys.executable]),
    "javascript":    ("rules.js",            ["node"]),
    "typescript":    ("rules.typescript.js", ["node"]),
    "nim":           ("rules.nim",           ["nim", "r", "--hints:off"]),
    "angular":       ("rules.angular.js",    ["node"]),
    "php":           ("rules.php",           ["php"]),
    "openscad":      ("rules.openscad.py",   [sys.executable]),
    "systemverilog": ("rules.sv.py",         [sys.executable]),
    "css":           ("rules.css.js",        ["node"]),
}


def _rules_file_paths(language: str) -> list[dict]:
    """Return rules files that exist for this language.

    Returns list of {"path": str, "scope": "project"|"global"}.
    Project first, then global.
    """
    info = _LANGUAGE_RULES.get(language)
    if not info:
        return []

    filename, _ = info
    results = []

    # Per-project
    project_path = os.path.join(os.getcwd(), ".cartograph", "rules", filename)
    if os.path.isfile(project_path):
        results.append({"path": project_path, "scope": "project"})

    # Global
    from .engine import _user_data_dir
    global_path = os.path.join(_user_data_dir(), "rules", filename)
    if os.path.isfile(global_path):
        results.append({"path": global_path, "scope": "global"})

    return results


def find_rules() -> list[dict]:
    """Find all rules files across all languages.

    Returns list of {"language": str, "path": str, "scope": str}.
    """
    results = []
    for lang, (filename, _) in _LANGUAGE_RULES.items():
        for entry in _rules_file_paths(lang):
            results.append({"language": lang, "filename": filename, **entry})
    return results


def _run_rules_file(path: str, widget_path: str, language: str) -> dict:
    """Execute a rules file and return {"blocks": [...], "warnings": [...]}.

    On error (bad exit code, invalid JSON, timeout), returns a clear
    error message explaining what went wrong and how to fix it.
    """
    info = _LANGUAGE_RULES.get(language)
    if not info:
        return {"blocks": [f"No runner configured for language '{language}'"], "warnings": []}

    _, runner = info
    cmd = runner + [path, os.path.abspath(widget_path)]
    scope = "project" if ".cartograph" in path else "global"
    label = f"{scope} rules ({os.path.basename(path)})"

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30, cwd=widget_path,
        )
    except FileNotFoundError:
        return {
            "blocks": [f"{label}: runner not found ({runner[0]}). Is {language} installed?"],
            "warnings": [],
        }
    except subprocess.TimeoutExpired:
        return {
            "blocks": [f"{label}: timed out after 30s"],
            "warnings": [],
        }

    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "unknown error").strip()
        return {
            "blocks": [
                f"{label}: script error (exit {result.returncode}):\n"
                f"  {detail[:500]}\n\n"
                f"  Your rules file must exit 0 and print valid JSON.\n"
                f"  File: {path}"
            ],
            "warnings": [],
        }

    stdout = result.stdout.strip()
    if not stdout:
        return {"blocks": [], "warnings": []}

    try:
        data = json.loads(stdout)
    except json.JSONDecodeError as e:
        return {
            "blocks": [
                f"{label}: invalid JSON output: {e}\n\n"
                f"  Your rules file must print a JSON object like:\n"
                f'  {{"blocks": [...], "warnings": [...]}}\n\n'
                f"  Got: {stdout[:200]}\n"
                f"  File: {path}"
            ],
            "warnings": [],
        }

    blocks = data.get("blocks", [])
    warnings = data.get("warnings", [])

    if not isinstance(blocks, list) or not isinstance(warnings, list):
        return {
            "blocks": [
                f"{label}: 'blocks' and 'warnings' must be JSON arrays.\n"
                f"  File: {path}"
            ],
            "warnings": [],
        }

    # Tag messages with scope for traceability
    tag = f"[{scope}]"
    blocks = [f"{tag} {msg}" for msg in blocks]
    warnings = [f"{tag} {msg}" for msg in warnings]

    return {"blocks": blocks, "warnings": warnings}


def run_all_rules(widget_path: str, language: str) -> dict:
    """Find and run all rules files for the language. Returns merged results."""
    files = _rules_file_paths(language)
    if not files:
        return {"blocks": [], "warnings": [], "rules_run": 0}

    all_blocks = []
    all_warnings = []

    for entry in files:
        log.debug("Running %s rules: %s", entry["scope"], entry["path"])
        result = _run_rules_file(entry["path"], widget_path, language)
        all_blocks.extend(result["blocks"])
        all_warnings.extend(result["warnings"])

    return {
        "blocks": all_blocks,
        "warnings": all_warnings,
        "rules_run": len(files),
    }


# ---------------------------------------------------------------------------
# Templates - used by `cartograph rules init`
# ---------------------------------------------------------------------------

_TEMPLATE_PYTHON = """\
\"\"\"
Custom validation rules for Python widgets.

HOW THIS WORKS
--------------
This file runs automatically during `cartograph validate` (and therefore
`cartograph checkin`). Cartograph calls it with the widget directory as
the first argument. Your job is to inspect the widget and report problems.

Print a JSON object to stdout with two keys:

    {"blocks": [...], "warnings": [...]}

  blocks    - hard failures. Checkin is rejected, no override possible.
              Use for things that must never ship (banned patterns, etc).
  warnings  - soft issues. Checkin pauses, but the user can override with
              --override-warnings --override-reason "why it's ok".
              Use for things that are usually wrong but sometimes intentional.

Empty arrays (or no output at all) means all checks passed.

WHAT YOU HAVE ACCESS TO
-----------------------
The widget_path argument points to a standard widget directory:

    widget_path/
      widget.json       metadata (id, name, domain, version, dependencies)
      src/              source code - this is what gets imported
      tests/            test files
      examples/         example usage files

You can read any of these with normal file operations. For example:

    - os.walk(os.path.join(widget_path, "src"))     scan source files
    - os.walk(os.path.join(widget_path, "tests"))   scan test files
    - json.load(open(os.path.join(widget_path, "widget.json")))
                                                     read widget metadata

This is just a Python script. Use any stdlib module you want - ast for
parsing, re for patterns, pathlib if you prefer it. No special APIs needed.

RUNNING EXTRA TESTS
-------------------
Cartograph runs your widget's tests with its own flags (80% coverage, etc).
If you want more from your test engine (extra pytest flags, markers, plugins),
call it again from here via subprocess. Tests will run twice - once
Cartograph's way (the quality guarantee), once yours (your preferences).

    import subprocess
    result = subprocess.run(
        ["python", "-m", "pytest", "tests/", "--timeout=120", "-x"],
        capture_output=True, text=True, cwd=widget_path,
    )
    if result.returncode != 0:
        blocks.append(f"Custom test run failed:\\n{result.stdout[-500:]}")
\"\"\"
import json
import os
import sys


def validate(widget_path):
    blocks = []
    warnings = []

    src_dir = os.path.join(widget_path, "src")
    test_dir = os.path.join(widget_path, "tests")
    examples_dir = os.path.join(widget_path, "examples")

    # --- Your checks go here ---
    #
    # The pattern is simple: check a condition, append a message.
    #
    #   if something_is_wrong:
    #       blocks.append("what's wrong and where")    # hard fail
    #
    #   if something_is_suspicious:
    #       warnings.append("what looks off")          # soft, overridable
    #
    # Examples (uncomment to use):

    # Block: ban specific imports in source code
    # BANNED = {"pickle", "subprocess", "eval"}
    # for root, _, files in os.walk(src_dir):
    #     for fname in files:
    #         if not fname.endswith(".py"): continue
    #         content = open(os.path.join(root, fname)).read()
    #         for banned in BANNED:
    #             if f"import {banned}" in content:
    #                 blocks.append(f"{fname} uses banned import: {banned}")

    # Warning: source files over 200 lines
    # for root, _, files in os.walk(src_dir):
    #     for fname in files:
    #         if not fname.endswith(".py"): continue
    #         count = sum(1 for _ in open(os.path.join(root, fname)))
    #         if count > 200:
    #             warnings.append(f"{fname} is {count} lines (max 200)")

    # Warning: fewer than 2 test files
    # tests = [f for f in os.listdir(test_dir) if f.startswith("test_")]
    # if len(tests) < 2:
    #     warnings.append(f"Only {len(tests)} test file(s) - consider more coverage")

    return {"blocks": blocks, "warnings": warnings}


if __name__ == "__main__":
    print(json.dumps(validate(sys.argv[1])))
"""

_TEMPLATE_JAVASCRIPT = """\
/**
 * Custom validation rules for JavaScript/TypeScript widgets.
 *
 * HOW THIS WORKS
 * --------------
 * This file runs automatically during `cartograph validate` (and therefore
 * `cartograph checkin`). Cartograph calls it with the widget directory as
 * a command-line argument. Your job is to inspect the widget and report problems.
 *
 * Print a JSON object to stdout with two keys:
 *
 *     {"blocks": [...], "warnings": [...]}
 *
 *   blocks    - hard failures. Checkin is rejected, no override possible.
 *   warnings  - soft issues. User can override with --override-warnings.
 *
 * Empty arrays (or no output at all) means all checks passed.
 *
 * WHAT YOU HAVE ACCESS TO
 * -----------------------
 * The widgetPath argument points to a standard widget directory:
 *
 *     widgetPath/
 *       widget.json       metadata (id, name, domain, version, dependencies)
 *       src/              source code
 *       tests/            test files
 *       examples/         example usage files
 *
 * Use normal fs operations to read any of these. This is just a Node script -
 * use any built-in module you want (fs, path, etc). No special APIs needed.
 *
 * RUNNING EXTRA TESTS
 * -------------------
 * Cartograph runs your widget's tests with its own flags. If you want more
 * from your test runner (extra jest flags, coverage config, etc), call it
 * again from here via child_process. Tests will run twice - once Cartograph's
 * way (the quality guarantee), once yours (your preferences).
 *
 *     const { execSync } = require("child_process");
 *     try {
 *         execSync("npx jest --coverage --coverageThreshold='{}'", { cwd: widgetPath });
 *     } catch (e) {
 *         blocks.push("Custom test run failed: " + e.stderr);
 *     }
 */
const fs = require("fs");
const path = require("path");

function validate(widgetPath) {
    const blocks = [];
    const warnings = [];

    const srcDir = path.join(widgetPath, "src");
    const testDir = path.join(widgetPath, "tests");
    const examplesDir = path.join(widgetPath, "examples");

    // --- Your checks go here ---
    //
    // The pattern is simple: check a condition, push a message.
    //
    //   if (somethingIsWrong) {
    //       blocks.push("what's wrong and where");    // hard fail
    //   }
    //   if (somethingIsSuspicious) {
    //       warnings.push("what looks off");          // soft, overridable
    //   }
    //
    // Examples (uncomment to use):

    // Block: ban specific patterns in source code
    // const BANNED = ["eval(", "document.write("];
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".js") && !fname.endsWith(".ts")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         for (const banned of BANNED) {
    //             if (content.includes(banned)) {
    //                 blocks.push(`${fname} uses banned pattern: ${banned}`);
    //             }
    //         }
    //     }
    // }

    // Warning: source files over 200 lines
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".js") && !fname.endsWith(".ts")) continue;
    //         const lines = fs.readFileSync(path.join(srcDir, fname), "utf8").split("\\n").length;
    //         if (lines > 200) {
    //             warnings.push(`${fname} is ${lines} lines (max 200)`);
    //         }
    //     }
    // }

    // Warning: fewer than 2 test files
    // if (fs.existsSync(testDir)) {
    //     const tests = fs.readdirSync(testDir).filter(f => f.startsWith("test"));
    //     if (tests.length < 2) {
    //         warnings.push(`Only ${tests.length} test file(s) - consider more coverage`);
    //     }
    // }

    return { blocks, warnings };
}

console.log(JSON.stringify(validate(process.argv[2])));
"""

_TEMPLATE_NIM = """\
## Custom validation rules for Nim widgets.
##
## HOW THIS WORKS
## --------------
## This file runs automatically during `cartograph validate` (and therefore
## `cartograph checkin`). Cartograph calls it with the widget directory as
## the first argument. Your job is to inspect the widget and report problems.
##
## Print a JSON object to stdout with two keys:
##
##     {"blocks": [...], "warnings": [...]}
##
##   blocks    - hard failures. Checkin is rejected, no override possible.
##   warnings  - soft issues. User can override with --override-warnings.
##
## Empty arrays (or no output at all) means all checks passed.
##
## WHAT YOU HAVE ACCESS TO
## -----------------------
## The widgetPath argument points to a standard widget directory:
##
##     widgetPath/
##       widget.json       metadata (id, name, domain, version, dependencies)
##       src/              source code
##       tests/            test files
##       examples/         example usage files
##
## Use standard library modules (os, json, strutils) to inspect files.
## This is just a Nim script - no special APIs needed.
##
## RUNNING EXTRA TESTS
## -------------------
## Cartograph runs your widget's tests via nimble test. If you want to use
## testament (--megatest, custom patterns, etc), call it from here via
## execCmdEx. Tests will run twice - once Cartograph's way (the quality
## guarantee), once yours (your preferences).
##
##   let res = execCmdEx("testament --megatest pattern tests/")
##   if res.exitCode != 0:
##     blocks.add(%*("Custom test run failed: " & res.output))

import std/[json, os, strutils]

proc validate(widgetPath: string): JsonNode =
  var blocks = newJArray()
  var warnings = newJArray()

  let srcDir = widgetPath / "src"
  let testDir = widgetPath / "tests"
  let examplesDir = widgetPath / "examples"

  # --- Your checks go here ---
  #
  # The pattern is simple: check a condition, add a message.
  #
  #   if somethingIsWrong:
  #     blocks.add(%*"what's wrong and where")     # hard fail
  #
  #   if somethingIsSuspicious:
  #     warnings.add(%*"what looks off")           # soft, overridable
  #
  # Examples (uncomment to use):

  # Block: ban specific imports in source code
  # if dirExists(srcDir):
  #   for fpath in walkDirRec(srcDir):
  #     if not fpath.endsWith(".nim"): continue
  #     let content = readFile(fpath)
  #     for banned in ["os.execShellCmd", "system("]:
  #       if banned in content:
  #         blocks.add(%*(extractFilename(fpath) & " uses banned: " & banned))

  # Warning: source files over 200 lines
  # if dirExists(srcDir):
  #   for fpath in walkDirRec(srcDir):
  #     if not fpath.endsWith(".nim"): continue
  #     let count = readFile(fpath).splitLines().len
  #     if count > 200:
  #       warnings.add(%*(extractFilename(fpath) & " is " & $count & " lines (max 200)"))

  # Warning: fewer than 2 test files
  # if dirExists(testDir):
  #   var testCount = 0
  #   for fpath in walkDir(testDir):
  #     if fpath.path.endsWith(".nim"): inc testCount
  #   if testCount < 2:
  #     warnings.add(%*("Only " & $testCount & " test file(s) - consider more coverage"))

  result = %*{"blocks": blocks, "warnings": warnings}

echo $validate(paramStr(1))
"""

_TEMPLATE_PHP = """\
<?php
/**
 * Custom validation rules for PHP widgets.
 *
 * HOW THIS WORKS
 * --------------
 * This file runs automatically during `cartograph validate` (and therefore
 * `cartograph checkin`). Cartograph calls it with the widget directory as
 * the first argument. Your job is to inspect the widget and report problems.
 *
 * Print a JSON object to stdout with two keys:
 *
 *     {"blocks": [...], "warnings": [...]}
 *
 *   blocks    - hard failures. Checkin is rejected, no override possible.
 *               Use for things that must never ship (banned patterns, etc).
 *   warnings  - soft issues. Checkin pauses, but the user can override with
 *               --override-warnings --override-reason "why it's ok".
 *               Use for things that are usually wrong but sometimes intentional.
 *
 * Empty arrays (or no output at all) means all checks passed.
 *
 * WHAT YOU HAVE ACCESS TO
 * -----------------------
 * The $widgetPath argument points to a standard widget directory:
 *
 *     widgetPath/
 *       widget.json       metadata (id, name, domain, version, dependencies)
 *       src/              source code
 *       tests/            test files
 *       examples/         example usage files
 *
 * Use standard PHP functions (file_get_contents, glob, json_decode) to
 * inspect files. This is just a PHP script - no special APIs needed.
 *
 * RUNNING EXTRA TESTS
 * -------------------
 * Cartograph runs your widget's tests via vendor/bin/phpunit. If you want
 * to run additional PHPUnit suites or enforce custom test patterns, call
 * phpunit from here:
 *
 *   $res = shell_exec("php vendor/bin/phpunit --testsuite custom 2>&1");
 *   if ($res === null || str_contains($res, 'FAILURES')) {
 *       $blocks[] = "Custom test suite failed";
 *   }
 */

$widgetPath = $argv[1] ?? '.';
$blocks = [];
$warnings = [];

$srcDir      = $widgetPath . '/src';
$testDir     = $widgetPath . '/tests';
$examplesDir = $widgetPath . '/examples';

// --- Your checks go here ---
//
// The pattern is simple: check a condition, add a message.
//
//   if (somethingIsWrong) {
//       $blocks[] = "what's wrong and where";     // hard fail
//   }
//
//   if (somethingIsSuspicious) {
//       $warnings[] = "what looks off";           // soft, overridable
//   }
//
// Examples (uncomment to use):

// Block: ban specific function calls in source code
// $phpFiles = glob($srcDir . '/*.php') ?: [];
// foreach ($phpFiles as $file) {
//     $content = file_get_contents($file);
//     foreach (['exec(', 'shell_exec(', 'system('] as $banned) {
//         if (str_contains($content, $banned)) {
//             $blocks[] = basename($file) . " uses banned function: $banned";
//         }
//     }
// }

// Warning: source files over 200 lines
// $phpFiles = glob($srcDir . '/*.php') ?: [];
// foreach ($phpFiles as $file) {
//     $count = count(file($file));
//     if ($count > 200) {
//         $warnings[] = basename($file) . " is $count lines (max 200)";
//     }
// }

// Warning: fewer than 2 test files
// $testFiles = glob($testDir . '/*Test.php') ?: [];
// if (count($testFiles) < 2) {
//     $warnings[] = "Only " . count($testFiles) . " test file(s) - consider more coverage";
// }

echo json_encode(['blocks' => $blocks, 'warnings' => $warnings]);
"""

_TEMPLATE_TYPESCRIPT = """\
/**
 * Custom validation rules for TypeScript widgets.
 *
 * HOW THIS WORKS
 * --------------
 * This file runs automatically during `cartograph validate` (and therefore
 * `cartograph checkin`). Cartograph calls it with the widget directory as
 * a command-line argument. Your job is to inspect the widget and report problems.
 *
 * Print a JSON object to stdout with two keys:
 *
 *     {"blocks": [...], "warnings": [...]}
 *
 *   blocks    - hard failures. Checkin is rejected, no override possible.
 *   warnings  - soft issues. User can override with --override-warnings.
 *
 * Empty arrays (or no output at all) means all checks passed.
 *
 * TYPESCRIPT-SPECIFIC CHECKS TO CONSIDER
 * ---------------------------------------
 * TypeScript has its own quality concerns beyond JavaScript:
 *
 *   - `any` type usage: weakens type safety, consider banning or warning
 *   - Missing return types on exported functions: harder to use as a library
 *   - `@ts-ignore` / `@ts-expect-error`: may hide real type errors
 *   - `as <Type>` casts: can silently break if types change
 *
 * WHAT YOU HAVE ACCESS TO
 * -----------------------
 * The widgetPath argument points to a standard widget directory:
 *
 *     widgetPath/
 *       widget.json       metadata (id, name, domain, version, dependencies)
 *       src/              source code
 *       tests/            test files
 *       examples/         example usage files
 *
 * Use normal fs operations to read any of these. No special APIs needed.
 */
const fs = require("fs");
const path = require("path");

function validate(widgetPath) {
    const blocks = [];
    const warnings = [];

    const srcDir = path.join(widgetPath, "src");

    // --- Your checks go here ---
    //
    // Examples (uncomment to use):

    // Warning: `any` type usage in source files
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".ts")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         const matches = (content.match(/: any\\b/g) || []).length;
    //         if (matches > 0) {
    //             warnings.push(fname + " uses `any` type " + matches + " time(s) - prefer explicit types");
    //         }
    //     }
    // }

    // Warning: `@ts-ignore` suppression
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".ts")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         if (content.includes("@ts-ignore") || content.includes("@ts-expect-error")) {
    //             warnings.push(`${fname} suppresses TypeScript errors - review before shipping`);
    //         }
    //     }
    // }

    return { blocks, warnings };
}

console.log(JSON.stringify(validate(process.argv[2])));
"""

_TEMPLATE_ANGULAR = """\
/**
 * Custom validation rules for Angular widgets.
 *
 * HOW THIS WORKS
 * --------------
 * This file runs automatically during `cartograph validate` (and therefore
 * `cartograph checkin`). Cartograph calls it with the widget directory as
 * a command-line argument. Your job is to inspect the widget and report problems.
 *
 * Print a JSON object to stdout with two keys:
 *
 *     {"blocks": [...], "warnings": [...]}
 *
 *   blocks    - hard failures. Checkin is rejected, no override possible.
 *   warnings  - soft issues. User can override with --override-warnings.
 *
 * Empty arrays (or no output at all) means all checks passed.
 *
 * ANGULAR-SPECIFIC CHECKS TO CONSIDER
 * ------------------------------------
 * Angular has naming and structural conventions worth enforcing:
 *
 *   - Component class names should end with `Component`
 *   - Service class names should end with `Service`
 *   - `console.log` left in production components
 *   - Direct DOM manipulation (document.querySelector) bypasses Angular's
 *     change detection - prefer ElementRef or Renderer2
 *
 * WHAT YOU HAVE ACCESS TO
 * -----------------------
 * The widgetPath argument points to a standard widget directory:
 *
 *     widgetPath/
 *       widget.json       metadata (id, name, domain, version, dependencies)
 *       src/              source code (Angular component files)
 *       tests/            test files
 *       examples/         example usage files
 *
 * Use normal fs operations to read any of these. No special APIs needed.
 */
const fs = require("fs");
const path = require("path");

function validate(widgetPath) {
    const blocks = [];
    const warnings = [];

    const srcDir = path.join(widgetPath, "src");

    // --- Your checks go here ---
    //
    // Examples (uncomment to use):

    // Warning: direct DOM manipulation (bypasses Angular change detection)
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".ts")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         if (content.includes("document.querySelector") || content.includes("document.getElementById")) {
    //             warnings.push(`${fname} uses direct DOM manipulation - prefer ElementRef/Renderer2`);
    //         }
    //     }
    // }

    // Warning: console.log in component source
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".ts")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         if (content.includes("console.log(")) {
    //             warnings.push(`${fname} contains console.log - remove before shipping`);
    //         }
    //     }
    // }

    return { blocks, warnings };
}

console.log(JSON.stringify(validate(process.argv[2])));
"""

_TEMPLATE_OPENSCAD = """\
\"\"\"
Custom validation rules for OpenSCAD widgets.

HOW THIS WORKS
--------------
This file runs automatically during `cartograph validate` (and therefore
`cartograph checkin`). Cartograph calls it with the widget directory as
the first argument. Your job is to inspect the widget and report problems.

Print a JSON object to stdout with two keys:

    {"blocks": [...], "warnings": [...]}

  blocks    - hard failures. Checkin is rejected, no override possible.
              Use for things that must never ship (banned patterns, etc).
  warnings  - soft issues. Checkin pauses, but the user can override with
              --override-warnings --override-reason "why it's ok".
              Use for things that are usually wrong but sometimes intentional.

Empty arrays (or no output at all) means all checks passed.

OPENSCAD-SPECIFIC CHECKS TO CONSIDER
--------------------------------------
OpenSCAD parametric models have their own quality concerns:

  - Magic numbers: hardcoded dimensions like `cube([25.4, 12.7, 6.35])` with
    no named variable make models hard to customize. Prefer `cube([width, height, depth])`.
  - Missing parameter validation: `assert(width > 0, "width must be positive")` prevents
    confusing geometry errors downstream.
  - echo() left in production: useful for debug, noisy in production widgets.
  - Very large $fn values: `$fn=360` makes renders unbearably slow; `$fn=100` is usually fine.

WHAT YOU HAVE ACCESS TO
-----------------------
The widget_path argument points to a standard widget directory:

    widget_path/
      widget.json       metadata (id, name, domain, version, dependencies)
      src/              .scad source files
      tests/            test files
      examples/         example_usage.scad

You can read any of these with normal file operations.
This is a Python script - use any stdlib module you want.
\"\"\"
import json
import os
import re
import sys


def validate(widget_path):
    blocks = []
    warnings = []

    src_dir = os.path.join(widget_path, "src")

    # --- Your checks go here ---
    #
    # Examples (uncomment to use):

    # Warning: echo() calls in source (debug output)
    # if os.path.isdir(src_dir):
    #     for fname in os.listdir(src_dir):
    #         if not fname.endswith(".scad"): continue
    #         content = open(os.path.join(src_dir, fname)).read()
    #         if re.search(r'\\becho\\s*\\(', content):
    #             warnings.append(f"{fname} contains echo() calls - remove before shipping")

    # Warning: very high $fn value (slow renders)
    # if os.path.isdir(src_dir):
    #     for fname in os.listdir(src_dir):
    #         if not fname.endswith(".scad"): continue
    #         content = open(os.path.join(src_dir, fname)).read()
    #         for m in re.finditer(r'\\$fn\\s*=\\s*(\\d+)', content):
    #             if int(m.group(1)) > 200:
    #                 warnings.append(f"{fname} sets $fn={m.group(1)} - values above 200 make renders very slow")

    return {"blocks": blocks, "warnings": warnings}


if __name__ == "__main__":
    print(json.dumps(validate(sys.argv[1])))
"""

_TEMPLATE_SYSTEMVERILOG = """\
\"\"\"
Custom validation rules for SystemVerilog widgets.

HOW THIS WORKS
--------------
This file runs automatically during `cartograph validate` (and therefore
`cartograph checkin`). Cartograph calls it with the widget directory as
the first argument. Your job is to inspect the widget and report problems.

Print a JSON object to stdout with two keys:

    {"blocks": [...], "warnings": [...]}

  blocks    - hard failures. Checkin is rejected, no override possible.
              Use for things that must never ship (banned patterns, etc).
  warnings  - soft issues. Checkin pauses, but the user can override with
              --override-warnings --override-reason "why it's ok".
              Use for things that are usually wrong but sometimes intentional.

Empty arrays (or no output at all) means all checks passed.

SYSTEMVERILOG-SPECIFIC CHECKS TO CONSIDER
------------------------------------------
RTL design has its own quality concerns:

  - Undriven outputs: a module output with no assignment silently drives X.
  - Blocking assignments (=) in always_ff blocks: should use non-blocking (<=).
  - Magic numbers in port widths: `input [7:0]` everywhere without a parameter
    makes designs hard to generalize.
  - `initial` blocks in synthesizable code: fine for simulation, may not synthesize.

WHAT YOU HAVE ACCESS TO
-----------------------
The widget_path argument points to a standard widget directory:

    widget_path/
      widget.json       metadata (id, name, domain, version, dependencies)
      src/              .sv source files
      tests/            testbench files
      examples/         example usage files

You can read any of these with normal file operations.
This is a Python script - use any stdlib module you want.
\"\"\"
import json
import os
import re
import sys


def validate(widget_path):
    blocks = []
    warnings = []

    src_dir = os.path.join(widget_path, "src")

    # --- Your checks go here ---
    #
    # Examples (uncomment to use):

    # Warning: blocking assignments in always_ff (should be non-blocking)
    # if os.path.isdir(src_dir):
    #     for fname in os.listdir(src_dir):
    #         if not fname.endswith(".sv"): continue
    #         content = open(os.path.join(src_dir, fname)).read()
    #         in_always_ff = False
    #         for line in content.splitlines():
    #             if "always_ff" in line:
    #                 in_always_ff = True
    #             if in_always_ff and re.search(r'\\w+\\s*=[^=<>!]', line):
    #                 warnings.append(f"{fname} may use blocking assignment in always_ff - use <= instead")
    #                 break

    # Warning: `initial` block in src/ (usually simulation-only)
    # if os.path.isdir(src_dir):
    #     for fname in os.listdir(src_dir):
    #         if not fname.endswith(".sv"): continue
    #         content = open(os.path.join(src_dir, fname)).read()
    #         if re.search(r'\\binitial\\b', content):
    #             warnings.append(f"{fname} contains `initial` block - verify it's synthesizable")

    return {"blocks": blocks, "warnings": warnings}


if __name__ == "__main__":
    print(json.dumps(validate(sys.argv[1])))
"""

_TEMPLATE_CSS = """\
/**
 * Custom validation rules for CSS widgets.
 *
 * HOW THIS WORKS
 * --------------
 * This file runs automatically during `cartograph validate` (and therefore
 * `cartograph checkin`). Cartograph calls it with the widget directory as
 * a command-line argument. Your job is to inspect the widget and report problems.
 *
 * Print a JSON object to stdout with two keys:
 *
 *     {"blocks": [...], "warnings": [...]}
 *
 *   blocks    - hard failures. Checkin is rejected, no override possible.
 *   warnings  - soft issues. User can override with --override-warnings.
 *
 * Empty arrays (or no output at all) means all checks passed.
 *
 * CSS-SPECIFIC CHECKS TO CONSIDER
 * --------------------------------
 * CSS widgets are often shared design system components. Common team conventions:
 *
 *   - Hardcoded colors (#fff, rgb(255,255,255)) instead of CSS variables (--color-white)
 *   - Hardcoded px font sizes instead of rem (breaks user font scaling)
 *   - `!important` usage (overrides cascade, makes theming harder)
 *   - Magic z-index values (100, 9999) instead of a defined z-index scale
 *   - Hardcoded breakpoint px values instead of a shared breakpoint variable
 *
 * These are warnings by default - upgrade to blocks if your team wants to enforce them.
 *
 * WHAT YOU HAVE ACCESS TO
 * -----------------------
 * The widgetPath argument points to a standard widget directory:
 *
 *     widgetPath/
 *       widget.json       metadata (id, name, domain, version, dependencies)
 *       src/              .css source files
 *       tests/            test files
 *       examples/         example usage files
 *
 * Use normal fs operations to read any of these. No special APIs needed.
 */
const fs = require("fs");
const path = require("path");

function validate(widgetPath) {
    const blocks = [];
    const warnings = [];

    const srcDir = path.join(widgetPath, "src");

    // --- Your checks go here ---
    //
    // Examples (uncomment to use):

    // Warning: hardcoded colors instead of CSS variables
    // const HEX_COLOR = /#[0-9a-fA-F]{3,8}\\b/g;
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".css")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         const matches = (content.match(HEX_COLOR) || []).length;
    //         if (matches > 0) {
    //             warnings.push(`${fname} has ${matches} hardcoded color(s) - prefer CSS custom properties (--color-name)`);
    //         }
    //     }
    // }

    // Warning: !important usage
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".css")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         const count = (content.match(/!important/g) || []).length;
    //         if (count > 0) {
    //             warnings.push(`${fname} uses !important ${count} time(s) - may cause cascade conflicts`);
    //         }
    //     }
    // }

    // Warning: px font sizes (prefer rem for user font scaling)
    // if (fs.existsSync(srcDir)) {
    //     for (const fname of fs.readdirSync(srcDir)) {
    //         if (!fname.endsWith(".css")) continue;
    //         const content = fs.readFileSync(path.join(srcDir, fname), "utf8");
    //         if (/font-size:\\s*\\d+px/.test(content)) {
    //             warnings.push(`${fname} uses px font-size - consider rem for better accessibility`);
    //         }
    //     }
    // }

    return { blocks, warnings };
}

console.log(JSON.stringify(validate(process.argv[2])));
"""

_TEMPLATES = {
    "python":        _TEMPLATE_PYTHON,
    "javascript":    _TEMPLATE_JAVASCRIPT,
    "typescript":    _TEMPLATE_TYPESCRIPT,
    "angular":       _TEMPLATE_ANGULAR,
    "nim":           _TEMPLATE_NIM,
    "php":           _TEMPLATE_PHP,
    "openscad":      _TEMPLATE_OPENSCAD,
    "systemverilog": _TEMPLATE_SYSTEMVERILOG,
    "css":           _TEMPLATE_CSS,
}


def get_template(language: str) -> str | None:
    """Return a rules file template for the language, or None if unsupported."""
    return _TEMPLATES.get(language)


def get_rules_filename(language: str) -> str | None:
    """Return the rules filename for this language."""
    info = _LANGUAGE_RULES.get(language)
    return info[0] if info else None
