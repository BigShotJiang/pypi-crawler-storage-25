#![allow(clippy::useless_conversion)]

mod wrappers;

use std::hash::Hasher;

use daft_core::{lit::Literal, python::PySchema};
use daft_logical_plan::PyLogicalPlanBuilder;
use indexmap::IndexMap;
use pyo3::{exceptions::PyIndexError, intern, prelude::*, types::PyDict};
pub use wrappers::{PyCatalogWrapper, PyTableWrapper};

use crate::{
    Catalog, CatalogRef, Identifier, Table, TableRef, TableSource,
    impls::memory::{MemoryCatalog, MemoryTable},
};

#[derive(Clone)]
#[pyclass(from_py_object)]
pub struct PyCatalog(pub CatalogRef);

#[pymethods]
impl PyCatalog {
    fn name(&self) -> String {
        self.0.name()
    }

    fn create_function(&self, ident: PyIdentifier, function: Bound<'_, PyAny>) -> PyResult<()> {
        let func_ref = crate::pyobj_to_function(function)?;
        Ok(self.0.create_function(&ident.0, func_ref)?)
    }

    fn create_namespace(&self, ident: PyIdentifier) -> PyResult<()> {
        Ok(self.0.create_namespace(&ident.0)?)
    }

    fn create_table(
        &self,
        ident: PyIdentifier,
        schema: PySchema,
        py: Python,
    ) -> PyResult<Py<PyAny>> {
        self.0.create_table(&ident.0, schema.schema)?.to_py(py)
    }

    fn drop_namespace(&self, ident: PyIdentifier) -> PyResult<()> {
        Ok(self.0.drop_namespace(&ident.0)?)
    }
    fn drop_table(&self, ident: PyIdentifier) -> PyResult<()> {
        Ok(self.0.drop_table(&ident.0)?)
    }

    fn get_function(&self, ident: PyIdentifier, py: Python) -> PyResult<Py<PyAny>> {
        self.0.get_function(&ident.0)?.to_py(py)
    }

    fn get_table(&self, ident: PyIdentifier, py: Python) -> PyResult<Py<PyAny>> {
        self.0.get_table(&ident.0)?.to_py(py)
    }

    fn has_namespace(&self, ident: PyIdentifier) -> PyResult<bool> {
        Ok(self.0.has_namespace(&ident.0)?)
    }

    fn has_table(&self, ident: PyIdentifier) -> PyResult<bool> {
        Ok(self.0.has_table(&ident.0)?)
    }

    #[pyo3(signature = (pattern=None))]
    fn list_namespaces(&self, pattern: Option<&str>) -> PyResult<Vec<PyIdentifier>> {
        Ok(self
            .0
            .list_namespaces(pattern)?
            .into_iter()
            .map(PyIdentifier)
            .collect())
    }

    #[pyo3(signature = (pattern=None))]
    fn list_tables(&self, pattern: Option<&str>) -> PyResult<Vec<PyIdentifier>> {
        Ok(self
            .0
            .list_tables(pattern)?
            .into_iter()
            .map(PyIdentifier)
            .collect())
    }

    #[staticmethod]
    fn new_memory_catalog(name: String, py: Python) -> PyResult<Py<PyAny>> {
        MemoryCatalog::new(name).to_py(py)
    }
}

#[derive(Clone)]
#[pyclass(from_py_object)]
pub struct PyTable(pub TableRef);

impl PyTable {
    fn pydict_to_options(options: Option<&Bound<PyDict>>) -> PyResult<IndexMap<String, Literal>> {
        if let Some(options) = options {
            options
                .iter()
                .map(|(key, val)| {
                    let key = key.extract()?;
                    let val = Literal::from_pyobj(&val, None)?;

                    Ok((key, val))
                })
                .collect()
        } else {
            Ok(IndexMap::new())
        }
    }
}

#[pymethods]
impl PyTable {
    fn name(&self) -> String {
        self.0.name()
    }

    fn schema(&self) -> PyResult<PySchema> {
        Ok(self.0.schema()?.into())
    }

    fn to_logical_plan(&self) -> PyResult<PyLogicalPlanBuilder> {
        Ok(self.0.to_logical_plan()?.into())
    }

    #[pyo3(signature = (plan, **options))]
    fn append(&self, plan: PyLogicalPlanBuilder, options: Option<&Bound<PyDict>>) -> PyResult<()> {
        let options = Self::pydict_to_options(options)?;

        Ok(self.0.append(plan.builder, options)?)
    }

    #[pyo3(signature = (plan, **options))]
    fn overwrite(
        &self,
        plan: PyLogicalPlanBuilder,
        options: Option<&Bound<PyDict>>,
    ) -> PyResult<()> {
        let options = Self::pydict_to_options(options)?;

        Ok(self.0.overwrite(plan.builder, options)?)
    }

    #[staticmethod]
    fn new_memory_table(name: String, schema: PySchema, py: Python) -> PyResult<Py<PyAny>> {
        MemoryTable::new(name, schema.schema)?.to_py(py)
    }
}

/// PyIdentifier maps identifier.py to identifier.rs
#[pyclass(sequence, from_py_object)]
#[derive(Clone)]
#[cfg_attr(debug_assertions, derive(Debug))]
pub struct PyIdentifier(Identifier);

#[pymethods]
impl PyIdentifier {
    #[new]
    pub fn new(parts: Vec<String>) -> Self {
        Identifier::new(parts).into()
    }

    #[staticmethod]
    pub fn from_sql(input: &str, normalize: bool) -> PyResult<Self> {
        Ok(Identifier::from_sql(input, normalize)?.into())
    }

    pub fn eq(&self, other: &Self) -> PyResult<bool> {
        Ok(self.0.eq(&other.0))
    }

    pub fn getitem(&self, index: isize) -> PyResult<String> {
        let mut i = index;
        let len = self.0.len();
        if i < 0 {
            // negative index
            i = (len as isize) + index;
        }
        if i < 0 || len <= i as usize {
            // out of range
            return Err(PyIndexError::new_err(i));
        }
        Ok(self.0.get(i as usize).to_string())
    }

    pub fn __len__(&self) -> PyResult<usize> {
        Ok(self.0.len())
    }

    pub fn __repr__(&self) -> PyResult<String> {
        Ok(format!("{}", self.0))
    }

    pub fn __hash__(&self) -> PyResult<u64> {
        use std::{collections::hash_map::DefaultHasher, hash::Hash};

        let mut hasher = DefaultHasher::new();
        self.0.hash(&mut hasher);
        Ok(hasher.finish())
    }
}

impl PyIdentifier {
    pub fn to_pyobj(self, py: Python) -> PyResult<Bound<PyAny>> {
        py.import(intern!(py, "daft.catalog"))?
            .getattr(intern!(py, "Identifier"))?
            .call_method1(intern!(py, "_from_pyidentifier"), (self,))
    }
}

impl From<Identifier> for PyIdentifier {
    fn from(value: Identifier) -> Self {
        Self(value)
    }
}

impl AsRef<Identifier> for PyIdentifier {
    fn as_ref(&self) -> &Identifier {
        &self.0
    }
}

/// PyTableSource wraps either a schema or dataframe.
#[pyclass]
pub struct PyTableSource(TableSource);

impl From<TableSource> for PyTableSource {
    fn from(source: TableSource) -> Self {
        Self(source)
    }
}

/// PyTableSource -> TableSource
impl AsRef<TableSource> for PyTableSource {
    fn as_ref(&self) -> &TableSource {
        &self.0
    }
}

#[pymethods]
impl PyTableSource {
    #[staticmethod]
    pub fn from_pyschema(schema: PySchema) -> Self {
        Self(TableSource::Schema(schema.schema))
    }

    #[staticmethod]
    pub fn from_pybuilder(view: &PyLogicalPlanBuilder) -> Self {
        Self(TableSource::View(view.builder.build()))
    }
}

pub fn register_modules(parent: &Bound<'_, PyModule>) -> PyResult<()> {
    parent.add_class::<PyCatalog>()?;
    parent.add_class::<PyTable>()?;
    parent.add_class::<PyIdentifier>()?;
    parent.add_class::<PyTableSource>()?;
    Ok(())
}
