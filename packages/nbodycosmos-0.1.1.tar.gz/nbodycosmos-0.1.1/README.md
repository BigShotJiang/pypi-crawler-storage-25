# Cosmological N-body Simulation

Cosmological N‑body simulation framework developed at the **National Institute of Technology, Calicut**.  
It reads an input `P(k)` from a CSV file, generates Zel'dovich initial conditions, and evolves the density field in a cosmological box.

## Installation

From PyPI (when published):

```bash
pip install nbodycosmos
```

From source (editable, for development):

```bash
git clone https://github.com/AstroAkshay/Cosmological-N-body-Simulation.git
cd Cosmological-N-body-Simulation
pip install -e .
```

## Usage

### From Python

```python
from nbodycosmos import run_simulation
from nbodysim.params import PyParams

run_simulation(
    params     = PyParams(N1=64, N2=64, N3=64, Nbin=10, LL=0.07, NF=1, vaa=0.047),
    csv_path   = "data/P_CDM.csv",
    output_dir = "output/",
)
```

### From command line

```bash
run-cosmos
```

With custom inputs:

```bash
run-cosmos --csv data/my_Pk.csv --output