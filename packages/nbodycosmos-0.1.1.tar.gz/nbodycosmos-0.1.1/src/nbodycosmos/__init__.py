"""Cosmological N-body simulation framework."""

from .simulation import run_simulation, __version__

__all__ = ["run_simulation", "__version__"]