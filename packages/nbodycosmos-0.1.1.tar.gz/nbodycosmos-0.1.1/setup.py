from setuptools import setup, find_packages

setup(
    name="nbodycosmos",
    version="0.1.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    package_data={
        "nbodycosmos": ["data/*.csv"],
        "nbodysim": ["*.pyd", "*.dll"]
    },
    include_package_data=True,
    install_requires=[
        "numpy>=1.24",
        "scipy>=1.10",
        "pandas>=2.0",
        "matplotlib>=3.7",
    ],
    author="Akshay B220011EP",
    description="Fast Cosmological N-body Simulation"
)