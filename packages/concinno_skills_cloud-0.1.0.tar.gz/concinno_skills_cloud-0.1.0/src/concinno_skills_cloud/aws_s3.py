"""concinno_skills_cloud.aws_s3 — AWS S3 object-storage Tool.

@module aws_s3
@responsibility Implement the Concinno :class:`Tool` protocol for
    AWS S3 upload / download / list / delete via the ``boto3>=1.34``
    SDK. Uses the ``boto3.client("s3", ...)`` low-level surface
    (the ``boto3.resource(...)`` high-level API was deprecated in
    favor of client calls per AWS docs 2026-04).
@dependencies boto3>=1.34 (Apache-2.0). Gated behind the
    ``concinno-skills-cloud[aws]`` extra.
@exports S3Object

API surface verified against boto3 docs 2026-04-23:

- ``boto3.client("s3", region_name=..., aws_access_key_id=...,
  aws_secret_access_key=..., aws_session_token=...)`` returns
  the client. Session token is optional for STS / temporary creds.
- Upload: ``client.put_object(Bucket=..., Key=..., Body=bytes)``
- Download: ``client.get_object(Bucket=..., Key=...)`` →
  ``{"Body": StreamingBody, "ContentType": ..., "ContentLength": ...}``.
- List: ``client.list_objects_v2(Bucket=..., Prefix=..., MaxKeys=...)``
  → ``{"Contents": [{"Key": ..., ...}, ...], "IsTruncated": ...}``.
- Delete: ``client.delete_object(Bucket=..., Key=...)``.

Concurrency
-----------
``is_concurrency_safe = True``. ``botocore`` low-level clients are
thread-safe per-call; we construct a fresh client on each ``call`` so
there's no shared-state hazard between agent turns.

IMDSv2 note
-----------
If the agent runs on an EC2 host and no explicit credentials are
supplied, boto3 will silently fall back to the instance metadata
service (IMDSv2). This is intentional — it's how AWS expects agents
on EC2 to authenticate — but it means a missing-creds mistake looks
like a no-op on-host and like an AuthError off-host. Agents should
always pass explicit creds or rely on the documented env-var
precedence if they care about the distinction.
"""

from __future__ import annotations

from typing import Any

from concinno_skills_cloud._executor import (
    encode_download,
    missing_driver,
    wrap_error,
)
from concinno_skills_cloud._safety import (
    check_action,
    check_content_bytes,
    check_download_size,
    check_max_keys,
    check_nonempty_str,
    check_optional_str,
)

_SUPPORTED_ACTIONS: tuple[str, ...] = ("upload", "download", "list", "delete")


def _build_s3_client(kwargs: dict[str, Any]) -> Any:
    """Construct a boto3 S3 client from the tool's kwargs.

    Returns ``(client, None)`` on success or ``(None, error_dict)``.
    Lazy-imports ``boto3`` so the missing-driver path produces a
    friendly ``missing_driver`` error instead of ModuleNotFoundError.
    """
    try:
        import boto3
    except ImportError as exc:
        return None, missing_driver(
            "S3Object",
            f"boto3 ({exc})",
            "pip install 'concinno-skills-cloud[aws]'",
        )

    client_kwargs: dict[str, Any] = {}
    for src, dst in (
        ("aws_region", "region_name"),
        ("aws_access_key_id", "aws_access_key_id"),
        ("aws_secret_access_key", "aws_secret_access_key"),
        ("aws_session_token", "aws_session_token"),
    ):
        v = kwargs.get(src)
        if v is None:
            continue
        if not isinstance(v, str) or not v:
            return None, {
                "error": f"{src} must be a non-empty string when provided"
            }
        client_kwargs[dst] = v

    try:
        client = boto3.client("s3", **client_kwargs)
    except Exception as exc:  # noqa: BLE001
        return None, wrap_error(exc, "S3Object", "client init")

    return client, None


class S3Object:
    """AWS S3 object upload / download / list / delete.

    Params accepted via ``call(**kwargs)``:
        action (str):   One of ``"upload"`` / ``"download"`` /
                        ``"list"`` / ``"delete"``.
        bucket (str):   S3 bucket name (required).
        key (str):      Object key (required for upload/download/delete).
        content (bytes|str): Upload payload (required for upload;
                             <= 1 MiB; str is UTF-8 encoded).
        prefix (str):   Optional key prefix (list only).
        max_keys (int): Max objects to return (list only;
                        default 100, max 1000).
        aws_access_key_id / aws_secret_access_key / aws_region /
            aws_session_token: Optional explicit creds. If omitted
            boto3's default credential chain is used (env, shared
            config, IMDSv2, etc.).

    Returns:
        upload → ``{"ok": True, "bucket": ..., "key": ..., "size": N}``
        download → ``{"ok": True, "bucket": ..., "key": ...,
                     "content": base64_str, "content_type": ...,
                     "size": N}``
        list → ``{"ok": True, "bucket": ..., "keys": [...],
                  "truncated": bool}``
        delete → ``{"ok": True, "bucket": ..., "key": ...}``
        any failure → ``{"error": "..."}``.
    """

    name: str = "s3_object"
    description: str = (
        "AWS S3 upload/download/list/delete via boto3. Params: "
        "action='upload'|'download'|'list'|'delete', bucket, key "
        "(upload/download/delete), content (bytes|str, <=1MiB, "
        "upload only), prefix (list), max_keys (list, <=1000), "
        "aws_access_key_id + aws_secret_access_key + aws_region + "
        "aws_session_token (all optional; falls back to boto3 default "
        "credential chain)."
    )
    is_concurrency_safe: bool = True

    def call(self, **kwargs: Any) -> Any:
        act_check = check_action(kwargs.get("action"), _SUPPORTED_ACTIONS)
        if isinstance(act_check, dict):
            return act_check
        action = act_check

        bucket_check = check_nonempty_str(kwargs.get("bucket"), "bucket")
        if isinstance(bucket_check, dict):
            return bucket_check
        bucket: str = bucket_check

        if action == "list":
            prefix_check = check_optional_str(kwargs.get("prefix"), "prefix")
            if isinstance(prefix_check, dict):
                return prefix_check
            prefix: str = prefix_check

            max_keys_check = check_max_keys(kwargs.get("max_keys"))
            if isinstance(max_keys_check, dict):
                return max_keys_check
            max_keys: int = max_keys_check
        else:
            key_check = check_nonempty_str(kwargs.get("key"), "key")
            if isinstance(key_check, dict):
                return key_check
            key: str = key_check

        if action == "upload":
            body_check = check_content_bytes(kwargs.get("content"))
            if isinstance(body_check, dict):
                return body_check
            body: bytes = body_check

        client, err = _build_s3_client(kwargs)
        if err is not None:
            return err

        if action == "upload":
            try:
                client.put_object(Bucket=bucket, Key=key, Body=body)
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "S3Object", "put_object")
            return {
                "ok": True,
                "bucket": bucket,
                "key": key,
                "size": len(body),
            }

        if action == "download":
            try:
                resp = client.get_object(Bucket=bucket, Key=key)
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "S3Object", "get_object")
            content_length = int(resp.get("ContentLength") or 0)
            size_check = check_download_size(content_length)
            if isinstance(size_check, dict):
                return size_check
            try:
                body_stream = resp["Body"]
                data: bytes = body_stream.read()
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "S3Object", "read body")
            # Re-check post-read — ContentLength is advisory.
            size_check = check_download_size(len(data))
            if isinstance(size_check, dict):
                return size_check
            return {
                "ok": True,
                "bucket": bucket,
                "key": key,
                "content": encode_download(data),
                "content_type": resp.get("ContentType") or "",
                "size": len(data),
            }

        if action == "list":
            list_kwargs: dict[str, Any] = {
                "Bucket": bucket,
                "MaxKeys": max_keys,
            }
            if prefix:
                list_kwargs["Prefix"] = prefix
            try:
                resp = client.list_objects_v2(**list_kwargs)
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "S3Object", "list_objects_v2")
            contents = resp.get("Contents") or []
            keys = [str(obj.get("Key") or "") for obj in contents]
            return {
                "ok": True,
                "bucket": bucket,
                "keys": keys,
                "truncated": bool(resp.get("IsTruncated")),
            }

        # action == "delete"
        try:
            client.delete_object(Bucket=bucket, Key=key)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "S3Object", "delete_object")
        return {"ok": True, "bucket": bucket, "key": key}


__all__ = ["S3Object"]
