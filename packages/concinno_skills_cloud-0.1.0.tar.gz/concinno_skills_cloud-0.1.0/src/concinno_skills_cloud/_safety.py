"""concinno_skills_cloud._safety — shared cloud-storage input guard.

@module _safety
@responsibility Central safety-check module used by every cloud-storage
    tool (``S3Object`` / ``GcsObject`` / ``AzureBlobObject``).

    Five separable checks:

    1. :func:`check_nonempty_str` — required string kwarg is non-empty.
    2. :func:`check_action` — reject bogus ``action`` values early with
       an enumeration of the supported ones.
    3. :func:`check_content_bytes` — upload content must be ``bytes``
       or ``str`` (coerced to UTF-8 bytes) and under
       :data:`MAX_CONTENT_BYTES`. This is the primary footgun guard —
       an agent that accidentally tries to round-trip a 100MiB file
       will get a clear refusal, not an OOM.
    4. :func:`check_max_keys` — pagination ceiling for ``list``
       actions; hard-caps at :data:`MAX_LIST_KEYS` so a bucket with
       a million keys cannot flood the agent context.
    5. :func:`check_int_positive` — generic positive-int guard
       shared by ``max_keys`` / ``max_results``.

Safety rationale
----------------
Cloud object storage does not have a "DDL" keyword to firewall. The
realistic agent footguns are:

- Unbounded upload (network waste / bucket quota exhaustion).
- Unbounded download into context window (blows token budget).
- Unbounded list (same; vendor APIs already default to 1000 but the
  caller must not silently raise that).
- Using truthy-but-wrong ``content`` types (dict / list) that vendor
  SDKs will either stringify wrongly or raise with a cryptic error.

We do NOT attempt to validate credential values themselves — the
vendor SDK's auth error surfaces via the tool's ``wrap_error`` path,
and we don't want to maintain a parallel regex for AWS key shapes.
"""

from __future__ import annotations

from typing import TypeAlias

# Return-type shape shared with the tool modules. Narrowing via
# ``isinstance(..., dict)`` in the tool ``call``.
SafeStrResult: TypeAlias = "str | dict[str, str]"
SafeBytesResult: TypeAlias = "bytes | dict[str, str]"
SafeIntResult: TypeAlias = "int | dict[str, str]"


# Hard caps. 1 MiB content round-trip and 1000 list-keys per call.
# Agents needing larger artifacts must call the vendor SDK directly
# or paginate. These numbers mirror the vendor defaults (S3 /
# ListObjectsV2 max-keys is 1000; GCS / Azure list_blobs default
# page size is ~5000 but we cap at 1000 for LLM-context sanity).
MAX_CONTENT_BYTES: int = 1 * 1024 * 1024  # 1 MiB
MAX_LIST_KEYS: int = 1000
DEFAULT_LIST_KEYS: int = 100


def check_nonempty_str(raw: object, field: str) -> SafeStrResult:
    """Validate a required non-empty string kwarg."""
    if not isinstance(raw, str) or not raw.strip():
        return {"error": f"{field} must be a non-empty string"}
    return raw


def check_optional_str(raw: object, field: str) -> SafeStrResult:
    """Validate an *optional* string kwarg.

    ``None`` → ``""`` (passthrough empty). Non-string → error.
    """
    if raw is None:
        return ""
    if not isinstance(raw, str):
        return {"error": f"{field} must be a string when provided"}
    return raw


def check_action(
    raw: object, supported: tuple[str, ...]
) -> SafeStrResult:
    """Validate the ``action`` kwarg against a tool-specific enum.

    Returns the lowercase action on success or ``{"error": ...}``.
    """
    if not isinstance(raw, str) or not raw.strip():
        return {
            "error": (
                f"action must be one of {list(supported)}, got empty/None"
            )
        }
    act = raw.strip().lower()
    if act not in supported:
        return {
            "error": (
                f"action must be one of {list(supported)}, got '{raw}'"
            )
        }
    return act


def check_content_bytes(raw: object) -> SafeBytesResult:
    """Validate and coerce upload content to bytes.

    Rules:
        1. ``bytes`` → passthrough.
        2. ``str`` → UTF-8 encode. Fail-closed on surrogates.
        3. Anything else (dict / list / int / None) → reject.
        4. Size must be <= :data:`MAX_CONTENT_BYTES` (1 MiB).
    """
    if isinstance(raw, bytes):
        data = raw
    elif isinstance(raw, str):
        try:
            data = raw.encode("utf-8")
        except UnicodeEncodeError as exc:
            return {
                "error": (
                    f"content str could not be UTF-8 encoded: {exc}"
                )
            }
    else:
        return {
            "error": (
                "content must be bytes or str, got "
                f"{type(raw).__name__}"
            )
        }
    if len(data) > MAX_CONTENT_BYTES:
        return {
            "error": (
                f"content size {len(data)} bytes exceeds "
                f"MAX_CONTENT_BYTES={MAX_CONTENT_BYTES} (1 MiB). "
                "Use the vendor SDK directly for larger artifacts."
            )
        }
    return data


def check_download_size(size: int) -> SafeIntResult:
    """Guard a post-download size against the 1 MiB round-trip cap.

    Called by ``download`` actions *after* the vendor fetched the
    object, before base64-encoding it into the tool response. Agents
    cannot rely on size pre-check via ``HEAD`` because not every
    vendor exposes size cheaply pre-fetch; the post-fetch guard is
    the defense that matters.
    """
    if not isinstance(size, int) or size < 0:
        return {"error": f"invalid object size {size!r}"}
    if size > MAX_CONTENT_BYTES:
        return {
            "error": (
                f"object size {size} bytes exceeds "
                f"MAX_CONTENT_BYTES={MAX_CONTENT_BYTES} (1 MiB). "
                "Use the vendor SDK directly for larger downloads."
            )
        }
    return size


def check_max_keys(raw: object) -> SafeIntResult:
    """Clamp the ``max_keys`` / ``max_results`` kwarg for list.

    Missing → :data:`DEFAULT_LIST_KEYS` (100).
    Int in ``[1, MAX_LIST_KEYS]`` → passthrough.
    Otherwise → ``{"error": "..."}``.
    """
    if raw is None:
        return DEFAULT_LIST_KEYS
    if not isinstance(raw, int) or isinstance(raw, bool):
        return {"error": "max_keys must be an integer when provided"}
    if raw <= 0:
        return {"error": "max_keys must be a positive integer"}
    if raw > MAX_LIST_KEYS:
        return {
            "error": (
                f"max_keys {raw} exceeds MAX_LIST_KEYS={MAX_LIST_KEYS}. "
                "Paginate with successive calls + prefix narrowing."
            )
        }
    return raw


__all__ = [
    "DEFAULT_LIST_KEYS",
    "MAX_CONTENT_BYTES",
    "MAX_LIST_KEYS",
    "SafeBytesResult",
    "SafeIntResult",
    "SafeStrResult",
    "check_action",
    "check_content_bytes",
    "check_download_size",
    "check_max_keys",
    "check_nonempty_str",
    "check_optional_str",
]
