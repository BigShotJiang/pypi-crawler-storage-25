"""concinno_skills_cloud.gcs — Google Cloud Storage object Tool.

@module gcs
@responsibility Implement the Concinno :class:`Tool` protocol for
    GCS upload / download / list / delete via the
    ``google-cloud-storage>=2.18`` SDK.
@dependencies google-cloud-storage>=2.18 (Apache-2.0). Gated behind
    the ``concinno-skills-cloud[gcp]`` extra.
@exports GcsObject

API surface verified against cloud.google.com/python/docs 2026-04-23:

- ``google.cloud.storage.Client(project=..., credentials=...)``
  returns the client. Credentials omitted → Application Default
  Credentials (``GOOGLE_APPLICATION_CREDENTIALS`` env pointing at
  a service-account JSON file).
- ``google.oauth2.service_account.Credentials.from_service_account_info(
  info_dict)`` accepts the JSON-parsed service-account dict directly,
  avoiding the "write creds to disk" footgun.
- ``client.bucket(name)`` returns a bucket handle.
- Upload: ``bucket.blob(name).upload_from_string(data, content_type=...)``.
- Download: ``bucket.blob(name).download_as_bytes()``.
- List: ``bucket.list_blobs(prefix=..., max_results=...)`` yields
  :class:`google.cloud.storage.Blob` with ``.name`` attr.
- Delete: ``bucket.blob(name).delete()``.

Concurrency
-----------
``is_concurrency_safe = True``. Like boto3, GCS clients are
thread-safe per call; we make a fresh client per ``call`` so there's
no shared state.

Workload Identity note
----------------------
On GKE / Cloud Run the agent likely has Workload Identity already
bound to a service account; in that case the caller passes neither
``gcs_credentials_json`` nor sets ``GOOGLE_APPLICATION_CREDENTIALS``
and ADC (Application Default Credentials) picks up the ambient
identity. That code path is not testable in unit tests but is the
primary production mode for GCP-native agents.
"""

from __future__ import annotations

from typing import Any

from concinno_skills_cloud._executor import (
    encode_download,
    missing_driver,
    wrap_error,
)
from concinno_skills_cloud._safety import (
    check_action,
    check_content_bytes,
    check_download_size,
    check_max_keys,
    check_nonempty_str,
    check_optional_str,
)

_SUPPORTED_ACTIONS: tuple[str, ...] = ("upload", "download", "list", "delete")


def _build_gcs_client(kwargs: dict[str, Any]) -> Any:
    """Construct a google.cloud.storage.Client from the tool's kwargs.

    Two paths:

    1. ``gcs_credentials_json`` (dict) →
       :func:`service_account.Credentials.from_service_account_info`.
    2. neither → Application Default Credentials (ADC).

    Returns ``(client, None)`` on success or ``(None, error_dict)``.
    """
    try:
        from google.cloud import storage
    except ImportError as exc:
        return None, missing_driver(
            "GcsObject",
            f"google-cloud-storage ({exc})",
            "pip install 'concinno-skills-cloud[gcp]'",
        )

    project = kwargs.get("gcs_project")
    if project is not None and (
        not isinstance(project, str) or not project
    ):
        return None, {
            "error": "gcs_project must be a non-empty string when provided"
        }

    credentials_info = kwargs.get("gcs_credentials_json")
    credentials: Any = None
    if credentials_info is not None:
        if not isinstance(credentials_info, dict):
            return None, {
                "error": (
                    "gcs_credentials_json must be a dict (parsed "
                    "service-account JSON)"
                )
            }
        try:
            from google.oauth2 import service_account
        except ImportError as exc:
            return None, missing_driver(
                "GcsObject",
                f"google-auth ({exc})",
                "pip install 'concinno-skills-cloud[gcp]'",
            )
        try:
            credentials = service_account.Credentials.from_service_account_info(
                credentials_info
            )
        except Exception as exc:  # noqa: BLE001
            return None, wrap_error(exc, "GcsObject", "credentials")

    try:
        client_kwargs: dict[str, Any] = {}
        if project is not None:
            client_kwargs["project"] = project
        if credentials is not None:
            client_kwargs["credentials"] = credentials
        client = storage.Client(**client_kwargs)
    except Exception as exc:  # noqa: BLE001
        return None, wrap_error(exc, "GcsObject", "client init")

    return client, None


class GcsObject:
    """Google Cloud Storage object upload / download / list / delete.

    Params accepted via ``call(**kwargs)``:
        action (str):   One of ``"upload"`` / ``"download"`` /
                        ``"list"`` / ``"delete"``.
        bucket (str):   GCS bucket name (required).
        blob_name (str): Blob name (required for upload/download/
                         delete).
        content (bytes|str): Upload payload (required for upload;
                             <= 1 MiB).
        content_type (str): Optional MIME type (upload only; defaults
                            to ``"application/octet-stream"``).
        prefix (str):   Optional blob-name prefix (list only).
        max_results (int): Max blobs to return (list only;
                           default 100, max 1000).
        gcs_project (str): Optional GCP project ID.
        gcs_credentials_json (dict): Parsed service-account JSON. If
                                     omitted, Application Default
                                     Credentials are used.

    Returns:
        upload → ``{"ok": True, "bucket": ..., "blob_name": ...,
                    "size": N}``
        download → ``{"ok": True, "bucket": ..., "blob_name": ...,
                      "content": base64_str, "size": N}``
        list → ``{"ok": True, "bucket": ..., "blob_names": [...]}``
        delete → ``{"ok": True, "bucket": ..., "blob_name": ...}``
        any failure → ``{"error": "..."}``.
    """

    name: str = "gcs_object"
    description: str = (
        "GCS upload/download/list/delete via google-cloud-storage. "
        "Params: action='upload'|'download'|'list'|'delete', bucket, "
        "blob_name (upload/download/delete), content (bytes|str, "
        "<=1MiB, upload only), content_type (upload, optional), "
        "prefix (list), max_results (list, <=1000), gcs_project "
        "(optional), gcs_credentials_json (dict, optional — service "
        "account JSON contents; falls back to Application Default "
        "Credentials)."
    )
    is_concurrency_safe: bool = True

    def call(self, **kwargs: Any) -> Any:
        act_check = check_action(kwargs.get("action"), _SUPPORTED_ACTIONS)
        if isinstance(act_check, dict):
            return act_check
        action = act_check

        bucket_check = check_nonempty_str(kwargs.get("bucket"), "bucket")
        if isinstance(bucket_check, dict):
            return bucket_check
        bucket_name: str = bucket_check

        if action == "list":
            prefix_check = check_optional_str(
                kwargs.get("prefix"), "prefix"
            )
            if isinstance(prefix_check, dict):
                return prefix_check
            prefix: str = prefix_check

            max_results_check = check_max_keys(kwargs.get("max_results"))
            if isinstance(max_results_check, dict):
                return max_results_check
            max_results: int = max_results_check
        else:
            name_check = check_nonempty_str(
                kwargs.get("blob_name"), "blob_name"
            )
            if isinstance(name_check, dict):
                return name_check
            blob_name: str = name_check

        if action == "upload":
            body_check = check_content_bytes(kwargs.get("content"))
            if isinstance(body_check, dict):
                return body_check
            body: bytes = body_check
            ct_check = check_optional_str(
                kwargs.get("content_type"), "content_type"
            )
            if isinstance(ct_check, dict):
                return ct_check
            content_type: str = ct_check or "application/octet-stream"

        client, err = _build_gcs_client(kwargs)
        if err is not None:
            return err

        try:
            bucket = client.bucket(bucket_name)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "GcsObject", "bucket handle")

        if action == "upload":
            try:
                blob = bucket.blob(blob_name)
                blob.upload_from_string(body, content_type=content_type)
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "GcsObject", "upload_from_string")
            return {
                "ok": True,
                "bucket": bucket_name,
                "blob_name": blob_name,
                "size": len(body),
            }

        if action == "download":
            try:
                blob = bucket.blob(blob_name)
                data: bytes = blob.download_as_bytes()
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "GcsObject", "download_as_bytes")
            size_check = check_download_size(len(data))
            if isinstance(size_check, dict):
                return size_check
            return {
                "ok": True,
                "bucket": bucket_name,
                "blob_name": blob_name,
                "content": encode_download(data),
                "size": len(data),
            }

        if action == "list":
            list_kwargs: dict[str, Any] = {"max_results": max_results}
            if prefix:
                list_kwargs["prefix"] = prefix
            try:
                iterator = bucket.list_blobs(**list_kwargs)
                blob_names = [str(getattr(b, "name", "")) for b in iterator]
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "GcsObject", "list_blobs")
            return {
                "ok": True,
                "bucket": bucket_name,
                "blob_names": blob_names,
            }

        # action == "delete"
        try:
            blob = bucket.blob(blob_name)
            blob.delete()
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "GcsObject", "delete")
        return {"ok": True, "bucket": bucket_name, "blob_name": blob_name}


__all__ = ["GcsObject"]
