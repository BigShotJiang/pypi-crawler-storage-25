"""concinno_skills_cloud.azure_blob — Azure Blob Storage object Tool.

@module azure_blob
@responsibility Implement the Concinno :class:`Tool` protocol for
    Azure Blob Storage upload / download / list / delete via the
    ``azure-storage-blob>=12.24`` SDK.
@dependencies azure-storage-blob>=12.24 (MIT). Gated behind the
    ``concinno-skills-cloud[azure]`` extra.
@exports AzureBlobObject

API surface verified against learn.microsoft.com/azure/storage 2026-04-23:

- Auth path A (recommended): ``BlobServiceClient.from_connection_string(
  connection_string)`` — carries the account + key in a single
  string.
- Auth path B: ``BlobServiceClient(account_url, credential=sas_token)``
  where ``account_url = "https://{account}.blob.core.windows.net"``
  and ``credential`` is a SAS token string or ``AzureSasCredential``.
- ``service_client.get_container_client(container_name)`` → container.
- Upload: ``container.upload_blob(name, data, overwrite=True,
  content_settings=ContentSettings(content_type=...))``.
- Download: ``container.download_blob(name).readall()``.
- List: ``container.list_blobs(name_starts_with=...)`` yields
  :class:`BlobProperties` with ``.name`` attr. Azure paginates
  server-side; we consume up to ``max_results`` names.
- Delete: ``container.delete_blob(name)``.

Concurrency
-----------
``is_concurrency_safe = True``. BlobServiceClient is
thread-safe for independent operations; we construct a fresh client
per ``call`` so there's no shared-state hazard.

Connection string vs SAS token trade-off
----------------------------------------
Connection strings include the account key → full admin capability.
SAS tokens are scoped (specific container / permissions / expiry).
Agents running in production should prefer SAS when possible; the
tool accepts both shapes but does not second-guess which. Handing a
SAS that doesn't cover the requested action (e.g., read-only SAS +
upload) surfaces as the vendor SDK's ``ClientAuthenticationError``
which we wrap via :func:`_executor.wrap_error`.
"""

from __future__ import annotations

import itertools
from typing import Any

from concinno_skills_cloud._executor import (
    encode_download,
    missing_driver,
    wrap_error,
)
from concinno_skills_cloud._safety import (
    check_action,
    check_content_bytes,
    check_download_size,
    check_max_keys,
    check_nonempty_str,
    check_optional_str,
)

_SUPPORTED_ACTIONS: tuple[str, ...] = ("upload", "download", "list", "delete")


def _build_azure_service_client(kwargs: dict[str, Any]) -> Any:
    """Construct an Azure ``BlobServiceClient`` from the tool's kwargs.

    Two mutually-exclusive auth paths:

    1. ``azure_storage_connection_string`` →
       :func:`BlobServiceClient.from_connection_string`.
    2. ``azure_storage_account_url`` (+ optional
       ``azure_storage_sas_token``) →
       :class:`BlobServiceClient` constructor.

    Returns ``(service_client, None)`` on success or
    ``(None, error_dict)``.
    """
    try:
        from azure.storage.blob import BlobServiceClient
    except ImportError as exc:
        return None, missing_driver(
            "AzureBlobObject",
            f"azure-storage-blob ({exc})",
            "pip install 'concinno-skills-cloud[azure]'",
        )

    conn_str = kwargs.get("azure_storage_connection_string")
    account_url = kwargs.get("azure_storage_account_url")
    sas_token = kwargs.get("azure_storage_sas_token")

    if conn_str is not None and account_url is not None:
        return None, {
            "error": (
                "AzureBlobObject: specify either "
                "azure_storage_connection_string OR "
                "azure_storage_account_url (+ optional "
                "azure_storage_sas_token), not both"
            )
        }

    try:
        if conn_str is not None:
            if not isinstance(conn_str, str) or not conn_str:
                return None, {
                    "error": (
                        "azure_storage_connection_string must be a "
                        "non-empty string"
                    )
                }
            service = BlobServiceClient.from_connection_string(conn_str)
        elif account_url is not None:
            if not isinstance(account_url, str) or not account_url:
                return None, {
                    "error": (
                        "azure_storage_account_url must be a non-empty "
                        "string"
                    )
                }
            cred: Any = None
            if sas_token is not None:
                if not isinstance(sas_token, str) or not sas_token:
                    return None, {
                        "error": (
                            "azure_storage_sas_token must be a "
                            "non-empty string when provided"
                        )
                    }
                cred = sas_token
            service = BlobServiceClient(
                account_url=account_url, credential=cred
            )
        else:
            return None, {
                "error": (
                    "AzureBlobObject: supply "
                    "azure_storage_connection_string OR "
                    "azure_storage_account_url (+ optional "
                    "azure_storage_sas_token)"
                )
            }
    except Exception as exc:  # noqa: BLE001
        return None, wrap_error(exc, "AzureBlobObject", "client init")

    return service, None


class AzureBlobObject:
    """Azure Blob Storage upload / download / list / delete.

    Params accepted via ``call(**kwargs)``:
        action (str):   One of ``"upload"`` / ``"download"`` /
                        ``"list"`` / ``"delete"``.
        container (str): Container name (required).
        blob_name (str): Blob name (required for upload/download/
                         delete).
        content (bytes|str): Upload payload (required for upload;
                             <= 1 MiB).
        content_type (str): Optional MIME type (upload only).
        name_starts_with (str): Optional prefix (list only).
        max_results (int): Max blobs to return (list only;
                           default 100, max 1000).
        azure_storage_connection_string (str): Full connection string
                                               (preferred).
        azure_storage_account_url (str): Alternative — account URL like
                                         ``https://acct.blob.core.
                                         windows.net``.
        azure_storage_sas_token (str): SAS token (used with
                                       ``account_url``).

    Returns:
        upload → ``{"ok": True, "container": ..., "blob_name": ...,
                    "size": N}``
        download → ``{"ok": True, "container": ..., "blob_name": ...,
                      "content": base64_str, "size": N}``
        list → ``{"ok": True, "container": ..., "blob_names": [...]}``
        delete → ``{"ok": True, "container": ..., "blob_name": ...}``
        any failure → ``{"error": "..."}``.
    """

    name: str = "azure_blob_object"
    description: str = (
        "Azure Blob Storage upload/download/list/delete via "
        "azure-storage-blob. Params: action='upload'|'download'|"
        "'list'|'delete', container, blob_name (upload/download/"
        "delete), content (bytes|str, <=1MiB, upload only), "
        "content_type (upload, optional), name_starts_with (list), "
        "max_results (list, <=1000), azure_storage_connection_string "
        "OR azure_storage_account_url (+ azure_storage_sas_token)."
    )
    is_concurrency_safe: bool = True

    def call(self, **kwargs: Any) -> Any:
        act_check = check_action(kwargs.get("action"), _SUPPORTED_ACTIONS)
        if isinstance(act_check, dict):
            return act_check
        action = act_check

        container_check = check_nonempty_str(
            kwargs.get("container"), "container"
        )
        if isinstance(container_check, dict):
            return container_check
        container_name: str = container_check

        if action == "list":
            prefix_check = check_optional_str(
                kwargs.get("name_starts_with"), "name_starts_with"
            )
            if isinstance(prefix_check, dict):
                return prefix_check
            name_prefix: str = prefix_check

            max_results_check = check_max_keys(kwargs.get("max_results"))
            if isinstance(max_results_check, dict):
                return max_results_check
            max_results: int = max_results_check
        else:
            name_check = check_nonempty_str(
                kwargs.get("blob_name"), "blob_name"
            )
            if isinstance(name_check, dict):
                return name_check
            blob_name: str = name_check

        if action == "upload":
            body_check = check_content_bytes(kwargs.get("content"))
            if isinstance(body_check, dict):
                return body_check
            body: bytes = body_check
            ct_check = check_optional_str(
                kwargs.get("content_type"), "content_type"
            )
            if isinstance(ct_check, dict):
                return ct_check
            content_type: str = ct_check

        service, err = _build_azure_service_client(kwargs)
        if err is not None:
            return err

        try:
            container = service.get_container_client(container_name)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "AzureBlobObject", "container handle")

        if action == "upload":
            upload_kwargs: dict[str, Any] = {
                "name": blob_name,
                "data": body,
                "overwrite": True,
            }
            if content_type:
                try:
                    from azure.storage.blob import ContentSettings
                except ImportError as exc:
                    return missing_driver(
                        "AzureBlobObject",
                        f"azure-storage-blob ContentSettings ({exc})",
                        "pip install 'concinno-skills-cloud[azure]'",
                    )
                upload_kwargs["content_settings"] = ContentSettings(
                    content_type=content_type
                )
            try:
                container.upload_blob(**upload_kwargs)
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "AzureBlobObject", "upload_blob")
            return {
                "ok": True,
                "container": container_name,
                "blob_name": blob_name,
                "size": len(body),
            }

        if action == "download":
            try:
                stream = container.download_blob(blob_name)
                data: bytes = stream.readall()
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "AzureBlobObject", "download_blob")
            size_check = check_download_size(len(data))
            if isinstance(size_check, dict):
                return size_check
            return {
                "ok": True,
                "container": container_name,
                "blob_name": blob_name,
                "content": encode_download(data),
                "size": len(data),
            }

        if action == "list":
            list_kwargs: dict[str, Any] = {}
            if name_prefix:
                list_kwargs["name_starts_with"] = name_prefix
            try:
                iterator = container.list_blobs(**list_kwargs)
                # Azure SDK paginates on the server; slice client-side.
                blob_names = [
                    str(getattr(b, "name", ""))
                    for b in itertools.islice(iterator, max_results)
                ]
            except Exception as exc:  # noqa: BLE001
                return wrap_error(exc, "AzureBlobObject", "list_blobs")
            return {
                "ok": True,
                "container": container_name,
                "blob_names": blob_names,
            }

        # action == "delete"
        try:
            container.delete_blob(blob_name)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "AzureBlobObject", "delete_blob")
        return {
            "ok": True,
            "container": container_name,
            "blob_name": blob_name,
        }


__all__ = ["AzureBlobObject"]
