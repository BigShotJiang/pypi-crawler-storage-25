"""concinno_skills_cloud._executor — shared vendor-client call flow.

@module _executor
@responsibility All three tools (``S3Object`` / ``GcsObject`` /
    ``AzureBlobObject``) share the same error-wrap shape and the same
    lazy vendor-import pattern. A missing driver package surfaces as
    a friendly ``{"error": "..."}`` payload instead of a raw
    ``ModuleNotFoundError`` bubbling to the agent and poisoning its
    next turn.

Why a separate module
---------------------
Each vendor SDK (``boto3`` / ``google-cloud-storage`` /
``azure-storage-blob``) has its own init surface and is only lazy-
imported inside the dispatch call (the ``pip install
concinno-skills-cloud[aws]`` extras gate is the whole point of this
package). Centralising the ``{"error":…}`` shape here means the three
adapter files read the same way and reviewers can diff them quickly
— same philosophy as ``concinno-skills-vector._executor`` that this
module is modelled on.

Safety contract enforced by caller
----------------------------------
Each tool class is expected to have already run the relevant
:mod:`_safety` guards (``check_nonempty_str`` / ``check_action`` /
``check_content_bytes`` / ``check_max_keys``) before reaching here.
This module does not re-run them; it assumes a pre-validated payload.

Error wrap
----------
All vendor exceptions (auth failed, bucket not found, network, …)
surface as ``{"error": "<ToolName>: <phase>: <first line>"}``. We
trim the traceback because dumping full vendor SDK tracebacks (often
multi-kilobyte XML-wrapped botocore stacks) into the LLM context
window is almost never useful.
"""

from __future__ import annotations

import base64
import logging

logger = logging.getLogger("concinno_skills_cloud._executor")


def first_line(exc: BaseException) -> str:
    """Return the first non-empty line of ``str(exc)``.

    Keeps vendor SDK tracebacks out of the agent's context. Bots
    like botocore's ClientError include XML payloads on failure;
    only the first line is useful to the LLM.
    """
    text = str(exc)
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return text or exc.__class__.__name__


def wrap_error(
    exc: BaseException, tool_name: str, phase: str
) -> dict[str, str]:
    """Produce the standard ``{"error": "..."}`` payload + log at WARNING.

    All three vendors' tools share this helper so the agent-visible
    error shape is consistent.
    """
    msg = first_line(exc)
    logger.warning("%s %s failed: %s", tool_name, phase, msg)
    return {"error": f"{tool_name}: {phase}: {msg}"}


def missing_driver(
    tool_name: str, module_name: str, install_hint: str
) -> dict[str, str]:
    """Friendly error when a vendor SDK is missing.

    The concinno-skills-cloud package intentionally does NOT pin the
    three vendor SDKs as hard dependencies — they're under
    ``[project.optional-dependencies]``. When an agent tries to call
    a tool without the corresponding extra installed, we want a
    single-line message telling them exactly what to pip-install,
    not a raw ModuleNotFoundError traceback.
    """
    return {
        "error": (
            f"{tool_name}: missing_driver: {module_name} not installed. "
            f"Run: {install_hint}"
        )
    }


def encode_download(data: bytes) -> str:
    """Base64-encode a downloaded object for JSON-safe return.

    Agents consume tool results as JSON; raw bytes aren't JSON. Base64
    keeps the byte exactness round-trip (agents can round-trip back
    via ``base64.b64decode`` if they need the payload, and the `ok`
    envelope stays a single plain string field).
    """
    return base64.b64encode(data).decode("ascii")


__all__ = [
    "encode_download",
    "first_line",
    "missing_driver",
    "wrap_error",
]
