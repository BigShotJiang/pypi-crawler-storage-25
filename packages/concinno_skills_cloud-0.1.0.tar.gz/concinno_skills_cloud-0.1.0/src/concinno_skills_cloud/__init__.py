"""concinno-skills-cloud — Cloud object-storage skills for Concinno.

Opt-in plugin package. When installed alongside ``concinno>=2.15.1`` and
the consumer env sets ``CONCINNO_LOAD_PLUGINS=1``, the tools here
auto-mount into :class:`concinno.tools.registry.ToolRegistry` via the
``[project.entry-points."concinno.tools"]`` table in ``pyproject.toml``.

MVP surface
-----------
- :class:`S3Object` — AWS S3 upload / download / list / delete via
  ``boto3>=1.34`` (Apache-2.0). Install with ``[aws]`` extra.
- :class:`GcsObject` — Google Cloud Storage upload / download / list /
  delete via ``google-cloud-storage>=2.18`` (Apache-2.0). Install with
  ``[gcp]`` extra.
- :class:`AzureBlobObject` — Azure Blob Storage upload / download /
  list / delete via ``azure-storage-blob>=12.24`` (MIT). Install with
  ``[azure]`` extra.

Optional-extras rationale
-------------------------
The cloud SDK trio is **~65MB** of transitive deps (boto3 ~30MB,
google-cloud-storage ~15MB, azure-storage-blob ~20MB). A typical agent
only needs one of the three, so each vendor is gated behind an extra:

- ``pip install concinno-skills-cloud[aws]`` → boto3 only
- ``pip install concinno-skills-cloud[gcp]`` → google-cloud-storage only
- ``pip install concinno-skills-cloud[azure]`` → azure-storage-blob only
- ``pip install concinno-skills-cloud[all]`` → all three

Each tool lazy-imports its vendor SDK at first call. If the extra was
not installed the tool returns a clear ``{"error": "S3Object:
missing_driver: ..."}`` payload with the ``pip install`` command to
remediate — the agent sees one message and does not trip an exception
into the next turn.

Safety
------
All three tools route through :mod:`concinno_skills_cloud._safety`:

1. :func:`check_nonempty_str` — required string kwargs are non-empty.
2. :func:`check_action` — reject bogus ``action`` values early with an
   enumeration of the supported ones.
3. :func:`check_content_size` — upload / download payloads hard-capped
   at 1MiB. Anything larger must use pagination or the vendor SDK
   directly; we do not want a single ``call`` to dump 100MiB into the
   LLM context window.
4. :func:`check_max_keys` — listing results hard-capped at 1000.

The caps mirror ``concinno-skills-vector``'s philosophy: keep the one-
call surface bounded so a stray agent cannot exhaust context or
bandwidth.

Credentials
-----------
Every ``call`` accepts explicit credential kwargs. Callers wanting
indirection resolve upstream via env or
:class:`concinno.core.credentials.CredentialStore`:

- AWS: ``aws_access_key_id``, ``aws_secret_access_key``,
  ``aws_region`` (optional), ``aws_session_token`` (optional STS).
- GCS: ``gcs_credentials_json`` (service-account info dict) OR
  ``GOOGLE_APPLICATION_CREDENTIALS`` env pointing at a JSON file.
- Azure: ``azure_storage_connection_string`` (preferred) OR
  ``azure_storage_account_url`` + ``azure_storage_sas_token``.

License notes
-------------
- ``boto3`` — Apache-2.0.
- ``google-cloud-storage`` — Apache-2.0.
- ``azure-storage-blob`` — MIT (Apache-2.0 compatible).

All permissive; same licence-compatibility posture as
``concinno-skills-vector``.
"""

from __future__ import annotations

from concinno_skills_cloud.aws_s3 import S3Object
from concinno_skills_cloud.azure_blob import AzureBlobObject
from concinno_skills_cloud.gcs import GcsObject

__version__ = "0.1.0"
__all__ = [
    "AzureBlobObject",
    "GcsObject",
    "S3Object",
    "__version__",
]
