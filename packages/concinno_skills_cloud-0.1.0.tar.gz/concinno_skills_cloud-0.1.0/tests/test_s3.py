"""Unit tests for concinno_skills_cloud.aws_s3.

Uses ``moto>=5``'s ``mock_aws`` decorator to spin up an in-memory S3
— no real AWS account / no network / no persistence. moto is MIT-
licensed (Apache-2.0 compatible) and part of the ``dev`` extra.
"""

from __future__ import annotations

import base64
import sys
from typing import Any

import boto3
import pytest
from moto import mock_aws

from concinno_skills_cloud import S3Object

# Standard moto creds — accept anything, just need non-empty.
_CREDS = {
    "aws_access_key_id": "testing",
    "aws_secret_access_key": "testing",
    "aws_region": "us-east-1",
}


# ── Protocol surface ─────────────────────────────────────────────


def test_s3_protocol() -> None:
    assert S3Object.name == "s3_object"
    assert S3Object.is_concurrency_safe is True
    assert "S3" in S3Object.description


# ── Action validation ────────────────────────────────────────────


def test_s3_bad_action() -> None:
    out = S3Object().call(action="teleport", bucket="b", key="k")
    assert "error" in out
    assert "upload" in out["error"]


def test_s3_missing_bucket() -> None:
    out = S3Object().call(action="upload", key="k", content=b"x")
    assert "error" in out
    assert "bucket" in out["error"]


def test_s3_missing_key_on_upload() -> None:
    out = S3Object().call(action="upload", bucket="b", content=b"x")
    assert "error" in out
    assert "key" in out["error"]


def test_s3_content_too_large() -> None:
    oversized = b"x" * (1 * 1024 * 1024 + 1)
    out = S3Object().call(
        action="upload",
        bucket="b",
        key="k",
        content=oversized,
        **_CREDS,
    )
    assert "error" in out
    assert "MAX_CONTENT_BYTES" in out["error"]


def test_s3_content_wrong_type() -> None:
    out = S3Object().call(
        action="upload",
        bucket="b",
        key="k",
        content={"not": "bytes"},
        **_CREDS,
    )
    assert "error" in out
    assert "content must be bytes or str" in out["error"]


def test_s3_max_keys_out_of_range() -> None:
    out = S3Object().call(
        action="list",
        bucket="b",
        max_keys=10_000,
        **_CREDS,
    )
    assert "error" in out
    assert "MAX_LIST_KEYS" in out["error"]


# ── Happy path via moto ──────────────────────────────────────────


@mock_aws
def test_s3_upload_then_download_roundtrip() -> None:
    boto3.client("s3", region_name="us-east-1").create_bucket(
        Bucket="mybucket"
    )

    up = S3Object().call(
        action="upload",
        bucket="mybucket",
        key="hello.txt",
        content="hello world",
        **_CREDS,
    )
    assert up == {
        "ok": True,
        "bucket": "mybucket",
        "key": "hello.txt",
        "size": len(b"hello world"),
    }

    down = S3Object().call(
        action="download",
        bucket="mybucket",
        key="hello.txt",
        **_CREDS,
    )
    assert down["ok"] is True
    assert down["size"] == len(b"hello world")
    assert base64.b64decode(down["content"]) == b"hello world"


@mock_aws
def test_s3_list_with_prefix() -> None:
    boto3.client("s3", region_name="us-east-1").create_bucket(
        Bucket="listbucket"
    )
    tool = S3Object()
    for k in ("a/1", "a/2", "b/1"):
        tool.call(
            action="upload",
            bucket="listbucket",
            key=k,
            content=b"x",
            **_CREDS,
        )

    all_keys = tool.call(
        action="list",
        bucket="listbucket",
        **_CREDS,
    )
    assert all_keys["ok"] is True
    assert set(all_keys["keys"]) == {"a/1", "a/2", "b/1"}

    a_only = tool.call(
        action="list",
        bucket="listbucket",
        prefix="a/",
        **_CREDS,
    )
    assert set(a_only["keys"]) == {"a/1", "a/2"}


@mock_aws
def test_s3_delete_removes_key() -> None:
    boto3.client("s3", region_name="us-east-1").create_bucket(
        Bucket="delbucket"
    )
    tool = S3Object()
    tool.call(
        action="upload",
        bucket="delbucket",
        key="doomed",
        content=b"bye",
        **_CREDS,
    )
    resp = tool.call(
        action="delete",
        bucket="delbucket",
        key="doomed",
        **_CREDS,
    )
    assert resp == {
        "ok": True,
        "bucket": "delbucket",
        "key": "doomed",
    }
    listing = tool.call(
        action="list",
        bucket="delbucket",
        **_CREDS,
    )
    assert listing["keys"] == []


# ── Vendor error wrap ────────────────────────────────────────────


@mock_aws
def test_s3_download_missing_key() -> None:
    boto3.client("s3", region_name="us-east-1").create_bucket(
        Bucket="erbucket"
    )
    out = S3Object().call(
        action="download",
        bucket="erbucket",
        key="nope",
        **_CREDS,
    )
    assert "error" in out
    assert "S3Object" in out["error"]


# ── Missing driver ───────────────────────────────────────────────


def test_s3_missing_driver(monkeypatch: pytest.MonkeyPatch) -> None:
    """Shadow boto3 with ``None`` in ``sys.modules`` so the lazy
    import inside :func:`_build_s3_client` raises ImportError → the
    tool should surface a friendly ``missing_driver`` error."""
    monkeypatch.setitem(sys.modules, "boto3", None)
    out = S3Object().call(
        action="upload",
        bucket="b",
        key="k",
        content=b"x",
    )
    assert "error" in out
    assert "missing_driver" in out["error"]
    assert "concinno-skills-cloud[aws]" in out["error"]


# ── Creds wiring ─────────────────────────────────────────────────


@mock_aws
def test_s3_bad_region_type() -> None:
    out = S3Object().call(
        action="upload",
        bucket="b",
        key="k",
        content=b"x",
        aws_region=42,  # type: ignore[arg-type]
        aws_access_key_id="k",
        aws_secret_access_key="s",
    )
    assert "error" in out
    assert "aws_region" in out["error"]


def _noop(*_args: Any, **_kwargs: Any) -> None:
    return None
