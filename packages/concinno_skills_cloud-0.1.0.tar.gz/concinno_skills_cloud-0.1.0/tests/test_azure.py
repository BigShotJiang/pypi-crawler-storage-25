"""Unit tests for concinno_skills_cloud.azure_blob.

Azure SDK does not ship an in-memory mock. We install a fake
``azure.storage.blob`` module tree in ``sys.modules`` so the tool's
lazy import picks up our stubs. Tests cover param validation, error
paths, and call shapes — not on-wire protocol.
"""

from __future__ import annotations

import base64
import sys
import types
from collections.abc import Iterator
from typing import Any

import pytest

from concinno_skills_cloud import AzureBlobObject

# ── Protocol surface ─────────────────────────────────────────────


def test_azure_protocol() -> None:
    assert AzureBlobObject.name == "azure_blob_object"
    assert AzureBlobObject.is_concurrency_safe is True
    assert "Azure" in AzureBlobObject.description


# ── Action validation ────────────────────────────────────────────


def test_azure_bad_action() -> None:
    out = AzureBlobObject().call(
        action="zip", container="c", blob_name="x"
    )
    assert "error" in out
    assert "upload" in out["error"]


def test_azure_missing_container() -> None:
    out = AzureBlobObject().call(
        action="upload", blob_name="x", content=b"y"
    )
    assert "error" in out
    assert "container" in out["error"]


def test_azure_missing_blob_name_on_upload() -> None:
    out = AzureBlobObject().call(
        action="upload", container="c", content=b"y"
    )
    assert "error" in out
    assert "blob_name" in out["error"]


def test_azure_conn_and_url_mutually_exclusive() -> None:
    out = AzureBlobObject().call(
        action="upload",
        container="c",
        blob_name="x",
        content=b"y",
        azure_storage_connection_string="DefaultEndpointsProtocol=https;x",
        azure_storage_account_url="https://acct.blob.core.windows.net",
    )
    assert "error" in out
    assert "not both" in out["error"]


def test_azure_no_creds_provided() -> None:
    _install_azure_mock()
    try:
        out = AzureBlobObject().call(
            action="upload",
            container="c",
            blob_name="x",
            content=b"y",
        )
        assert "error" in out
        assert "supply" in out["error"]
    finally:
        _uninstall_azure_mock()


def test_azure_content_too_large() -> None:
    oversized = b"x" * (1 * 1024 * 1024 + 1)
    out = AzureBlobObject().call(
        action="upload",
        container="c",
        blob_name="x",
        content=oversized,
        azure_storage_connection_string="x",
    )
    assert "error" in out
    assert "MAX_CONTENT_BYTES" in out["error"]


# ── Mock Azure SDK ───────────────────────────────────────────────


class _FakeDownloadStream:
    def __init__(self, data: bytes) -> None:
        self._data = data

    def readall(self) -> bytes:
        return self._data


class _FakeContainerClient:
    def __init__(self, name: str, store: dict[str, bytes]) -> None:
        self.name = name
        self._store = store

    def upload_blob(
        self,
        name: str,
        data: bytes,
        overwrite: bool = False,  # noqa: ARG002
        content_settings: Any = None,  # noqa: ARG002
    ) -> None:
        self._store[name] = bytes(data)

    def download_blob(self, name: str) -> _FakeDownloadStream:
        if name not in self._store:
            raise KeyError(f"blob {name} not found")
        return _FakeDownloadStream(self._store[name])

    def list_blobs(
        self, name_starts_with: str | None = None
    ) -> Iterator[Any]:
        for k in sorted(self._store):
            if name_starts_with and not k.startswith(name_starts_with):
                continue
            yield _FakeBlobProps(k)

    def delete_blob(self, name: str) -> None:
        if name not in self._store:
            raise KeyError(f"blob {name} not found")
        del self._store[name]


class _FakeBlobProps:
    def __init__(self, name: str) -> None:
        self.name = name


# Module-level shared container store across ``BlobServiceClient``
# instances (tool builds a fresh client per call).
_SHARED_CONTAINERS: dict[str, dict[str, bytes]] = {}


class _FakeBlobServiceClient:
    def __init__(
        self, account_url: str = "", credential: Any = None  # noqa: ARG002
    ) -> None:
        pass

    @classmethod
    def from_connection_string(cls, conn_str: str) -> Any:  # noqa: ARG003
        return cls(account_url="fake", credential=None)

    def get_container_client(self, name: str) -> _FakeContainerClient:
        if name not in _SHARED_CONTAINERS:
            _SHARED_CONTAINERS[name] = {}
        return _FakeContainerClient(name, _SHARED_CONTAINERS[name])


class _FakeContentSettings:
    def __init__(self, content_type: str = "") -> None:
        self.content_type = content_type


def _install_azure_mock() -> None:
    _SHARED_CONTAINERS.clear()

    azure_mod = types.ModuleType("azure")
    storage_mod = types.ModuleType("azure.storage")
    blob_mod = types.ModuleType("azure.storage.blob")
    blob_mod.BlobServiceClient = _FakeBlobServiceClient  # type: ignore[attr-defined]
    blob_mod.ContentSettings = _FakeContentSettings  # type: ignore[attr-defined]

    sys.modules["azure"] = azure_mod
    sys.modules["azure.storage"] = storage_mod
    sys.modules["azure.storage.blob"] = blob_mod


def _uninstall_azure_mock() -> None:
    for mod in ("azure", "azure.storage", "azure.storage.blob"):
        sys.modules.pop(mod, None)


@pytest.fixture
def azure_mock() -> Any:
    _install_azure_mock()
    try:
        yield
    finally:
        _uninstall_azure_mock()


# ── Happy path via mock SDK ──────────────────────────────────────


def test_azure_upload_then_download_roundtrip(
    azure_mock: None,
) -> None:
    conn = "DefaultEndpointsProtocol=https;AccountName=x;AccountKey=y;"
    up = AzureBlobObject().call(
        action="upload",
        container="mycontainer",
        blob_name="hello.txt",
        content="hello world",
        content_type="text/plain",
        azure_storage_connection_string=conn,
    )
    assert up["ok"] is True
    assert up["container"] == "mycontainer"
    assert up["blob_name"] == "hello.txt"
    assert up["size"] == len(b"hello world")

    down = AzureBlobObject().call(
        action="download",
        container="mycontainer",
        blob_name="hello.txt",
        azure_storage_connection_string=conn,
    )
    assert down["ok"] is True
    assert base64.b64decode(down["content"]) == b"hello world"


def test_azure_list_with_prefix(azure_mock: None) -> None:
    conn = "DefaultEndpointsProtocol=https;AccountName=x;AccountKey=y;"
    tool = AzureBlobObject()
    for n in ("a/1", "a/2", "b/1"):
        tool.call(
            action="upload",
            container="lc",
            blob_name=n,
            content=b"x",
            azure_storage_connection_string=conn,
        )
    all_blobs = tool.call(
        action="list",
        container="lc",
        azure_storage_connection_string=conn,
    )
    assert set(all_blobs["blob_names"]) == {"a/1", "a/2", "b/1"}

    a_only = tool.call(
        action="list",
        container="lc",
        name_starts_with="a/",
        azure_storage_connection_string=conn,
    )
    assert set(a_only["blob_names"]) == {"a/1", "a/2"}


def test_azure_delete(azure_mock: None) -> None:
    conn = "DefaultEndpointsProtocol=https;AccountName=x;AccountKey=y;"
    tool = AzureBlobObject()
    tool.call(
        action="upload",
        container="dc",
        blob_name="doomed",
        content=b"bye",
        azure_storage_connection_string=conn,
    )
    resp = tool.call(
        action="delete",
        container="dc",
        blob_name="doomed",
        azure_storage_connection_string=conn,
    )
    assert resp == {
        "ok": True,
        "container": "dc",
        "blob_name": "doomed",
    }
    listing = tool.call(
        action="list",
        container="dc",
        azure_storage_connection_string=conn,
    )
    assert listing["blob_names"] == []


def test_azure_download_missing_blob(azure_mock: None) -> None:
    conn = "DefaultEndpointsProtocol=https;AccountName=x;AccountKey=y;"
    out = AzureBlobObject().call(
        action="download",
        container="mc",
        blob_name="ghost",
        azure_storage_connection_string=conn,
    )
    assert "error" in out
    assert "AzureBlobObject" in out["error"]


def test_azure_account_url_with_sas(azure_mock: None) -> None:
    """Alternate auth path: account URL + SAS token."""
    out = AzureBlobObject().call(
        action="upload",
        container="sasc",
        blob_name="x",
        content=b"y",
        azure_storage_account_url="https://acct.blob.core.windows.net",
        azure_storage_sas_token="sv=2022-11-02&sig=...",
    )
    assert out["ok"] is True


# ── Missing driver ───────────────────────────────────────────────


def test_azure_missing_driver(monkeypatch: pytest.MonkeyPatch) -> None:
    """If ``azure.storage.blob`` is absent, surface friendly error."""
    monkeypatch.setitem(sys.modules, "azure.storage.blob", None)
    out = AzureBlobObject().call(
        action="upload",
        container="c",
        blob_name="x",
        content=b"y",
        azure_storage_connection_string="x",
    )
    assert "error" in out
    assert "missing_driver" in out["error"]
    assert "concinno-skills-cloud[azure]" in out["error"]
