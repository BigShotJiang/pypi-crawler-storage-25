"""Unit tests for concinno_skills_cloud.gcs.

GCS has no zero-network in-memory mock on par with moto, so we use
:mod:`unittest.mock` to install a fake ``google.cloud.storage``
module in ``sys.modules`` before the tool's lazy import runs. Tests
focus on param validation, error paths, and the upload/download/
list/delete call shapes — not on the real GCS network protocol.
"""

from __future__ import annotations

import base64
import sys
import types
from typing import Any

import pytest

from concinno_skills_cloud import GcsObject

# ── Protocol surface ─────────────────────────────────────────────


def test_gcs_protocol() -> None:
    assert GcsObject.name == "gcs_object"
    assert GcsObject.is_concurrency_safe is True
    assert "GCS" in GcsObject.description


# ── Action validation ────────────────────────────────────────────


def test_gcs_bad_action() -> None:
    out = GcsObject().call(action="sync", bucket="b", blob_name="x")
    assert "error" in out
    assert "upload" in out["error"]


def test_gcs_missing_bucket() -> None:
    out = GcsObject().call(action="upload", blob_name="x", content=b"y")
    assert "error" in out
    assert "bucket" in out["error"]


def test_gcs_missing_blob_name_on_upload() -> None:
    out = GcsObject().call(action="upload", bucket="b", content=b"y")
    assert "error" in out
    assert "blob_name" in out["error"]


def test_gcs_bad_credentials_type() -> None:
    """``gcs_credentials_json`` must be a dict, not a JSON string."""
    # Install a mock module first so the missing-driver guard doesn't
    # short-circuit before the credentials type-check.
    _install_gcs_mock()
    try:
        out = GcsObject().call(
            action="upload",
            bucket="b",
            blob_name="x",
            content=b"y",
            gcs_credentials_json='{"client_email": "x"}',  # str, not dict
        )
        assert "error" in out
        assert "gcs_credentials_json" in out["error"]
    finally:
        _uninstall_gcs_mock()


def test_gcs_content_too_large() -> None:
    oversized = b"x" * (1 * 1024 * 1024 + 1)
    out = GcsObject().call(
        action="upload",
        bucket="b",
        blob_name="x",
        content=oversized,
    )
    assert "error" in out
    assert "MAX_CONTENT_BYTES" in out["error"]


# ── Mock GCS SDK ─────────────────────────────────────────────────


class _FakeBlob:
    def __init__(self, name: str, store: dict[str, bytes]) -> None:
        self.name = name
        self._store = store

    def upload_from_string(
        self, data: bytes, content_type: str = ""
    ) -> None:
        self._store[self.name] = bytes(data)
        self.last_content_type = content_type

    def download_as_bytes(self) -> bytes:
        if self.name not in self._store:
            raise KeyError(f"no blob {self.name}")
        return self._store[self.name]

    def delete(self) -> None:
        if self.name in self._store:
            del self._store[self.name]
        else:
            raise KeyError(f"no blob {self.name}")


class _FakeBucket:
    def __init__(self, name: str) -> None:
        self.name = name
        self._store: dict[str, bytes] = {}

    def blob(self, name: str) -> _FakeBlob:
        return _FakeBlob(name, self._store)

    def list_blobs(
        self,
        prefix: str | None = None,
        max_results: int | None = None,
    ) -> list[_FakeBlob]:
        keys = sorted(self._store.keys())
        if prefix:
            keys = [k for k in keys if k.startswith(prefix)]
        if max_results is not None:
            keys = keys[:max_results]
        return [_FakeBlob(k, self._store) for k in keys]


class _FakeGcsClient:
    def __init__(self, **_kwargs: Any) -> None:
        self._buckets: dict[str, _FakeBucket] = {}

    def bucket(self, name: str) -> _FakeBucket:
        if name not in self._buckets:
            self._buckets[name] = _FakeBucket(name)
        return self._buckets[name]


# Module-level shared bucket store across `_FakeGcsClient` instances —
# each tool `call` builds a fresh client so instances would otherwise
# not see each other's state.
_SHARED_BUCKETS: dict[str, _FakeBucket] = {}


class _SharedFakeGcsClient(_FakeGcsClient):
    def bucket(self, name: str) -> _FakeBucket:
        if name not in _SHARED_BUCKETS:
            _SHARED_BUCKETS[name] = _FakeBucket(name)
        return _SHARED_BUCKETS[name]


def _install_gcs_mock() -> None:
    """Install a fake ``google.cloud.storage`` module tree in
    ``sys.modules``.

    Tool call creates a fresh client per call so we share state
    across clients via the module-level ``_SHARED_BUCKETS`` dict.
    """
    _SHARED_BUCKETS.clear()

    google_mod = types.ModuleType("google")
    cloud_mod = types.ModuleType("google.cloud")
    storage_mod = types.ModuleType("google.cloud.storage")
    storage_mod.Client = _SharedFakeGcsClient  # type: ignore[attr-defined]

    oauth2_mod = types.ModuleType("google.oauth2")
    svc_mod = types.ModuleType("google.oauth2.service_account")

    class _FakeCreds:
        @classmethod
        def from_service_account_info(cls, info: dict[str, Any]) -> Any:
            return f"fake_creds:{info.get('client_email', '?')}"

    svc_mod.Credentials = _FakeCreds  # type: ignore[attr-defined]

    sys.modules["google"] = google_mod
    sys.modules["google.cloud"] = cloud_mod
    sys.modules["google.cloud.storage"] = storage_mod
    sys.modules["google.oauth2"] = oauth2_mod
    sys.modules["google.oauth2.service_account"] = svc_mod


def _uninstall_gcs_mock() -> None:
    for mod in (
        "google",
        "google.cloud",
        "google.cloud.storage",
        "google.oauth2",
        "google.oauth2.service_account",
    ):
        sys.modules.pop(mod, None)


@pytest.fixture
def gcs_mock() -> Any:
    _install_gcs_mock()
    try:
        yield
    finally:
        _uninstall_gcs_mock()


# ── Happy path via mock SDK ──────────────────────────────────────


def test_gcs_upload_then_download_roundtrip(gcs_mock: None) -> None:
    up = GcsObject().call(
        action="upload",
        bucket="mybucket",
        blob_name="hello.txt",
        content="hello world",
    )
    assert up["ok"] is True
    assert up["bucket"] == "mybucket"
    assert up["blob_name"] == "hello.txt"
    assert up["size"] == len(b"hello world")

    down = GcsObject().call(
        action="download",
        bucket="mybucket",
        blob_name="hello.txt",
    )
    assert down["ok"] is True
    assert base64.b64decode(down["content"]) == b"hello world"
    assert down["size"] == len(b"hello world")


def test_gcs_list_with_prefix(gcs_mock: None) -> None:
    tool = GcsObject()
    for name in ("a/1", "a/2", "b/1"):
        tool.call(
            action="upload", bucket="lb", blob_name=name, content=b"x"
        )

    all_blobs = tool.call(action="list", bucket="lb")
    assert all_blobs["ok"] is True
    assert set(all_blobs["blob_names"]) == {"a/1", "a/2", "b/1"}

    a_only = tool.call(action="list", bucket="lb", prefix="a/")
    assert set(a_only["blob_names"]) == {"a/1", "a/2"}


def test_gcs_delete(gcs_mock: None) -> None:
    tool = GcsObject()
    tool.call(action="upload", bucket="db", blob_name="x", content=b"y")
    resp = tool.call(action="delete", bucket="db", blob_name="x")
    assert resp == {"ok": True, "bucket": "db", "blob_name": "x"}
    listing = tool.call(action="list", bucket="db")
    assert listing["blob_names"] == []


def test_gcs_download_missing_blob(gcs_mock: None) -> None:
    out = GcsObject().call(
        action="download", bucket="mb", blob_name="ghost"
    )
    assert "error" in out
    assert "GcsObject" in out["error"]


def test_gcs_with_service_account_info(gcs_mock: None) -> None:
    """Passing ``gcs_credentials_json`` dict routes through the
    :class:`service_account.Credentials` factory."""
    out = GcsObject().call(
        action="upload",
        bucket="sab",
        blob_name="x",
        content=b"y",
        gcs_credentials_json={
            "client_email": "bot@proj.iam.gserviceaccount.com",
            "private_key": "---",
            "project_id": "proj",
            "type": "service_account",
        },
        gcs_project="proj",
    )
    assert out["ok"] is True


# ── Missing driver ───────────────────────────────────────────────


def test_gcs_missing_driver(monkeypatch: pytest.MonkeyPatch) -> None:
    """If ``google.cloud.storage`` is absent, surface friendly error."""
    monkeypatch.setitem(sys.modules, "google.cloud.storage", None)
    out = GcsObject().call(
        action="upload", bucket="b", blob_name="x", content=b"y"
    )
    assert "error" in out
    assert "missing_driver" in out["error"]
    assert "concinno-skills-cloud[gcp]" in out["error"]
