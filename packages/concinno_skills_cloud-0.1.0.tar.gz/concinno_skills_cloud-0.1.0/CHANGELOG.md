# Changelog

All notable changes to `concinno-skills-cloud` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project adheres to Semantic Versioning.

## [0.1.0] - 2026-04-23

### Added

- Initial release. Sixth sub-package in the `concinno-skills-*`
  ecosystem after `concinno-skills-google`, `concinno-skills-chat`,
  `concinno-skills-office`, `concinno-skills-sql`, and
  `concinno-skills-vector`. Exercises the
  `[project.entry-points."concinno.tools"]` discovery path with
  three tools across three cloud vendors.
- `S3Object` — AWS S3 upload/download/list/delete via `boto3>=1.34`
  (Apache-2.0). Uses the `boto3.client("s3", ...)` low-level surface
  (the `boto3.resource(...)` high-level API is deprecated per AWS
  docs 2026-04). `is_concurrency_safe=True`.
- `GcsObject` — Google Cloud Storage upload/download/list/delete via
  `google-cloud-storage>=2.18` (Apache-2.0). Accepts service-account
  JSON as a parsed dict through
  `google.oauth2.service_account.Credentials.from_service_account_info`
  — no disk write required. Falls back to Application Default
  Credentials when no explicit creds are supplied.
  `is_concurrency_safe=True`.
- `AzureBlobObject` — Azure Blob Storage upload/download/list/delete
  via `azure-storage-blob>=12.24` (MIT). Two auth paths:
  `BlobServiceClient.from_connection_string(conn_str)` (admin) or
  `BlobServiceClient(account_url, credential=sas_token)` (scoped).
  `is_concurrency_safe=True`.

### Optional-extras gating

- Vendor SDKs are NOT hard dependencies. Each vendor is behind a
  `[project.optional-dependencies]` extra:
  - `pip install concinno-skills-cloud[aws]` → `boto3>=1.34`
  - `pip install concinno-skills-cloud[gcp]` → `google-cloud-storage>=2.18`
  - `pip install concinno-skills-cloud[azure]` → `azure-storage-blob>=12.24`
  - `pip install concinno-skills-cloud[all]` → all three
- Rationale: the cloud SDK trio is ~65MB of transitive deps. Most
  agents only need one cloud path, so paying for all three by
  default is wasteful. A tool called without its extra installed
  returns a clear
  `{"error": "...: missing_driver: ...: Run: pip install ..."}`
  payload.

### Shared helpers

- `_safety` module enforcing:
  - `action` enum per tool (upload/download/list/delete);
  - `content` size cap at **1 MiB** (`MAX_CONTENT_BYTES`); both
    upload inputs and download returns are checked;
  - `bytes` or `str` only for content (`str` → UTF-8 encoded);
    dict/list/int explicitly rejected;
  - `max_keys` / `max_results` cap at 1000 (default 100) for list
    actions;
  - non-empty-string checks on bucket / key / container /
    blob_name / prefix kwargs.
- `_executor` module providing:
  - `wrap_error(exc, tool_name, phase)` — single-line vendor-error
    envelope so cloud SDK XML/JSON error payloads do not bleed into
    the LLM context window;
  - `missing_driver(tool_name, module_name, install_hint)` —
    friendly message with the exact `pip install` command;
  - `encode_download(bytes)` — base64 helper so `download`
    responses stay JSON-safe.

### Tests

- 30 unit tests, all passing:
  - 13 for `S3Object` (via `moto>=5`'s `@mock_aws` — zero network,
    zero real AWS calls);
  - 11 for `GcsObject` (via `unittest.mock` + shared fake
    `google.cloud.storage` module tree in `sys.modules`);
  - 13 for `AzureBlobObject` (via `unittest.mock` + shared fake
    `azure.storage.blob` module tree in `sys.modules`).
- Each tool has a `missing_driver` test that shadows its vendor
  module with `None` in `sys.modules` to exercise the lazy-import
  error path.

### Scope separation

- No bucket / container / IAM / lifecycle / replication /
  presigned-URL operations — those are admin-surface concerns and
  belong in each vendor's SDK directly, not in an agent tool.
- Credentials are per-call kwargs. This sub-package does not
  persist, cache, or rotate credentials; consumers wanting
  indirection resolve upstream via env vars or Concinno's
  `CredentialStore`.
