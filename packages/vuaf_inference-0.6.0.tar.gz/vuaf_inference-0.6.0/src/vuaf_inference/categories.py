"""Category registry: persisted with each checkpoint."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


CATEGORY_TOKEN_FMT = "<|cat:{name}|>"
CATEGORY_RESERVED = "<|cat:_reserved_{i}|>"


@dataclass
class CategoryRegistry:
    names: List[str] = field(default_factory=list)
    max_categories: int = 32

    def __post_init__(self) -> None:
        if len(self.names) > self.max_categories:
            raise ValueError(
                f"More categories ({len(self.names)}) than max slots "
                f"({self.max_categories})"
            )

    def all_special_tokens(self) -> List[str]:
        out: list[str] = []
        for n in self.names:
            out.append(CATEGORY_TOKEN_FMT.format(name=n))
        for i in range(len(self.names), self.max_categories):
            out.append(CATEGORY_RESERVED.format(i=i))
        return out

    def token_for(self, name: str) -> str:
        if name not in self.names:
            raise KeyError(f"Unknown category '{name}'")
        return CATEGORY_TOKEN_FMT.format(name=name)

    def index(self, name: str) -> int:
        return self.names.index(name)

    def save(self, path: str | Path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps(
                {"names": self.names, "max_categories": self.max_categories},
                indent=2, ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        return p

    @classmethod
    def load(cls, path: str | Path) -> "CategoryRegistry":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(
            names=list(data["names"]),
            max_categories=int(data["max_categories"]),
        )

    @classmethod
    def from_raw_dir(
        cls, raw_dir: str | Path, max_categories: int = 32
    ) -> "CategoryRegistry":
        """Build registry from first-level subdirectory names."""
        raw = Path(raw_dir)
        if not raw.is_dir():
            raise FileNotFoundError(f"raw dir not found: {raw}")
        names = sorted(
            p.name for p in raw.iterdir()
            if p.is_dir() and not p.name.startswith(".")
        )
        return cls(names=names, max_categories=max_categories)
