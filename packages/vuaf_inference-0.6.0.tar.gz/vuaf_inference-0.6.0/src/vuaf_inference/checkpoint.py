"""Checkpoint save/load.

A checkpoint is a folder containing:
    config.json         the VUAFConfig used to build the model
    model.safetensors   model weights (safetensors is fast, safe, portable)
    spm.model           sentencepiece tokenizer
    spm.vocab
    categories.json     category registry
    tokenizer.json      tokenizer metadata
    metadata.json       version, training step, total params, train notes
    optimizer.pt        optional, only saved if explicitly requested
"""
from __future__ import annotations

import json
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import Any, Optional

import torch
from safetensors.torch import load_file, save_file

from vuaf_inference.configs import VUAFConfig
from vuaf_inference.model import VUAFModel


VUAF_FORMAT_VERSION = 1


def save_checkpoint(
    out_dir: str | Path,
    model: VUAFModel,
    tokenizer_dir: str | Path | None = None,
    optimizer: Optional[torch.optim.Optimizer] = None,
    metadata: Optional[dict[str, Any]] = None,
) -> Path:
    """Persist model + tokenizer artifacts to `out_dir`."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    cfg_dict = asdict(model.cfg)
    (out / "config.json").write_text(
        json.dumps(cfg_dict, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    state = {k: v.detach().cpu().contiguous() for k, v in model.state_dict().items()}
    save_file(state, str(out / "model.safetensors"))

    if tokenizer_dir is not None:
        tok = Path(tokenizer_dir)
        for name in ("spm.model", "spm.vocab", "categories.json", "tokenizer.json"):
            src = tok / name
            if src.exists():
                shutil.copy2(src, out / name)

    if optimizer is not None:
        torch.save(optimizer.state_dict(), out / "optimizer.pt")

    md: dict[str, Any] = {
        "format_version": VUAF_FORMAT_VERSION,
        "model_name": model.cfg.name,
        "n_parameters": model.num_parameters(),
        "vocab_size": model.cfg.vocab_size,
        "loop_steps": model.cfg.loop_steps,
    }
    if metadata:
        md.update(metadata)
    (out / "metadata.json").write_text(
        json.dumps(md, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out


def load_checkpoint(
    in_dir: str | Path,
    device: torch.device | str | None = None,
    strict: bool = True,
) -> tuple[VUAFModel, dict[str, Any]]:
    """Reconstruct a VUAFModel from a checkpoint dir.

    Returns (model, metadata).
    """
    p = Path(in_dir)
    cfg = VUAFConfig(**json.loads((p / "config.json").read_text(encoding="utf-8")))
    model = VUAFModel(cfg)

    state = load_file(str(p / "model.safetensors"))
    missing, unexpected = model.load_state_dict(state, strict=strict)
    if strict and (missing or unexpected):
        raise RuntimeError(
            f"State dict mismatch. missing={missing} unexpected={unexpected}"
        )
    if device is not None:
        model.to(device)

    md = {}
    md_path = p / "metadata.json"
    if md_path.exists():
        md = json.loads(md_path.read_text(encoding="utf-8"))
    return model, md
