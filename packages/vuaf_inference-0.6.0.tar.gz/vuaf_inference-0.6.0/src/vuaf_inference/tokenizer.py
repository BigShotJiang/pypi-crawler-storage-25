"""Load-only SentencePiece tokenizer wrapper.

This module deliberately omits `train_tokenizer`. Training a new
tokenizer is part of the private training pipeline; only loading and
encoding/decoding are needed at inference time.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List

import sentencepiece as spm

from vuaf_inference.categories import CategoryRegistry


@dataclass
class TokenizerMeta:
    vocab_size: int
    pad_id: int
    bos_id: int
    eos_id: int
    unk_id: int
    user_id: int
    assistant_id: int
    system_id: int
    turn_id: int
    doc_id: int
    meta_open_id: int
    meta_close_id: int
    category_first_id: int
    category_count: int
    max_categories: int


class VUAFTokenizer:
    """Load-only wrapper around a trained SentencePiece model."""

    def __init__(
        self,
        sp: spm.SentencePieceProcessor,
        registry: CategoryRegistry,
        meta: TokenizerMeta,
    ) -> None:
        self.sp = sp
        self.registry = registry
        self.meta = meta

    @property
    def vocab_size(self) -> int:
        return self.meta.vocab_size

    def category_token_id(self, name: str) -> int:
        tok = self.registry.token_for(name)
        return self.sp.piece_to_id(tok)

    def encode(self, text: str, add_bos: bool = False, add_eos: bool = False) -> List[int]:
        ids = self.sp.encode(text, out_type=int)
        if add_bos:
            ids = [self.meta.bos_id] + ids
        if add_eos:
            ids = ids + [self.meta.eos_id]
        return ids

    def decode(self, ids: List[int]) -> str:
        return self.sp.decode(ids)

    def save(self, out_dir: str | Path) -> Path:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        self.registry.save(out / "categories.json")
        (out / "tokenizer.json").write_text(
            json.dumps(asdict(self.meta), indent=2),
            encoding="utf-8",
        )
        return out

    @classmethod
    def load(cls, out_dir: str | Path) -> "VUAFTokenizer":
        out = Path(out_dir)
        sp = spm.SentencePieceProcessor()
        sp.load(str(out / "spm.model"))
        reg = CategoryRegistry.load(out / "categories.json")
        meta = TokenizerMeta(
            **json.loads((out / "tokenizer.json").read_text(encoding="utf-8"))
        )
        return cls(sp=sp, registry=reg, meta=meta)
