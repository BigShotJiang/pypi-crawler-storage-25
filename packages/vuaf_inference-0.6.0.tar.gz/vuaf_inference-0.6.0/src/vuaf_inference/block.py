"""One VUAF block: token mixer + channel mixer, both in sandwich norm.

A block is parameter-shared across loop steps. The token mixer kind
(rwkv7 / mamba2 / attn) and channel mixer kind (swiglu / moe) are
fixed at construction from the per-layer config patterns.
"""
from __future__ import annotations

import torch
import torch.nn as nn

from vuaf_inference.configs import VUAFConfig
from vuaf_inference.layers.mamba2 import Mamba2
from vuaf_inference.layers.moe import MoE
from vuaf_inference.layers.norm import SandwichNorm
from vuaf_inference.layers.rwkv7 import RWKV7TimeMix
from vuaf_inference.layers.sparse_attn import SparseAttention
from vuaf_inference.layers.swiglu import SwiGLU


def _build_token_mixer(cfg: VUAFConfig, kind: str) -> nn.Module:
    if kind == "rwkv7":
        return RWKV7TimeMix(
            d_model=cfg.d_model,
            n_heads=cfg.rwkv_n_heads,
            head_dim=cfg.rwkv_head_dim,
            lowrank=cfg.rwkv_lowrank,
        )
    if kind == "mamba2":
        return Mamba2(
            d_model=cfg.d_model,
            d_state=cfg.mamba_d_state,
            d_head=cfg.mamba_d_head,
            expand=cfg.mamba_expand,
            chunk_size=cfg.mamba_chunk_size,
            mode=cfg.mamba_mode,
        )
    if kind == "attn":
        return SparseAttention(
            d_model=cfg.d_model,
            n_heads=cfg.attn_n_heads,
            head_dim=cfg.attn_head_dim,
            max_seq_len=cfg.max_seq_len,
            rope_base=cfg.attn_rope_base,
        )
    raise ValueError(f"Unknown token mixer kind '{kind}'")


def _build_channel_mixer(cfg: VUAFConfig, kind: str) -> nn.Module:
    if kind == "swiglu":
        return SwiGLU(d_model=cfg.d_model, hidden=cfg.ffn_hidden)
    if kind == "moe":
        return MoE(
            d_model=cfg.d_model,
            hidden=cfg.ffn_hidden,
            n_experts=cfg.moe_n_experts,
            top_k=cfg.moe_top_k,
        )
    raise ValueError(f"Unknown channel mixer kind '{kind}'")


class VUAFBlock(nn.Module):
    """One block = sandwich(token_mix) + sandwich(channel_mix)."""

    def __init__(self, cfg: VUAFConfig, token_kind: str, channel_kind: str) -> None:
        super().__init__()
        self.token_kind = token_kind
        self.channel_kind = channel_kind

        self.token_mix = SandwichNorm(
            cfg.d_model, _build_token_mixer(cfg, token_kind)
        )
        self.channel_mix = SandwichNorm(
            cfg.d_model, _build_channel_mixer(cfg, channel_kind)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.token_mix(x)
        x = self.channel_mix(x)
        return x

    @property
    def moe_aux_loss(self) -> torch.Tensor | None:
        """Return MoE load-balance loss for the most recent forward, or None."""
        inner = self.channel_mix.module
        if isinstance(inner, MoE):
            return inner.last_aux_loss
        return None
