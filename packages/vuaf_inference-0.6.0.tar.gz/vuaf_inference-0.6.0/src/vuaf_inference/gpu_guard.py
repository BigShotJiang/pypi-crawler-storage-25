"""Hard GPU-only enforcement. No CPU fallback."""
from __future__ import annotations

import torch


class NoGPUError(RuntimeError):
    """Raised when no GPU is available. VUAF refuses to run on CPU."""


def require_gpu() -> torch.device:
    """Return the GPU device or raise NoGPUError."""
    if not torch.cuda.is_available():
        backend = "ROCm/HIP" if torch.version.hip else "CUDA"
        raise NoGPUError(
            f"VUAF is GPU-only. No {backend} device detected. "
            f"torch.cuda.is_available() == False. "
            f"Check ROCm install and `torch.version.hip` "
            f"(currently: {torch.version.hip})."
        )
    return torch.device("cuda:0")


def gpu_info() -> dict:
    """Return a small dict describing the active GPU build."""
    return {
        "torch": torch.__version__,
        "hip": torch.version.hip,
        "cuda": torch.version.cuda,
        "device_name": (
            torch.cuda.get_device_name(0)
            if torch.cuda.is_available() else None
        ),
        "device_count": (
            torch.cuda.device_count()
            if torch.cuda.is_available() else 0
        ),
    }
