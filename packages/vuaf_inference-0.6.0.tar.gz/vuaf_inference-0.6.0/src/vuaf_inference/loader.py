"""One-call loader: local dir or `user/repo` from Hugging Face Hub.

Examples
--------
    from vuaf_inference import load_pretrained
    model, tokenizer = load_pretrained("./vuaf-pico")          # local
    model, tokenizer = load_pretrained("Sqersters/vuaf-pico")  # HF Hub
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import torch

from vuaf_inference.checkpoint import load_checkpoint
from vuaf_inference.gpu_guard import require_gpu
from vuaf_inference.model import VUAFModel
from vuaf_inference.tokenizer import VUAFTokenizer


_HF_FILES = (
    "model.safetensors",
    "config.json",
    "spm.model",
    "spm.vocab",
    "categories.json",
    "tokenizer.json",
    "metadata.json",
)


def _looks_like_hub_id(s: str) -> bool:
    """Crude check: 'user/repo' shape, no path separators that go too deep."""
    if Path(s).exists():
        return False
    if "/" not in s:
        return False
    parts = s.split("/")
    return len(parts) == 2 and all(p and not p.startswith(".") for p in parts)


def _download_from_hub(
    repo_id: str,
    revision: Optional[str] = None,
    token: Optional[str] = None,
) -> Path:
    """Download all VUAF files from a HF Hub repo to the local cache."""
    try:
        from huggingface_hub import snapshot_download
    except ImportError as e:
        raise ImportError(
            "Loading from a Hugging Face Hub repo requires the "
            "`huggingface_hub` package. Install with: "
            "pip install huggingface_hub"
        ) from e
    local = snapshot_download(
        repo_id=repo_id,
        revision=revision,
        allow_patterns=list(_HF_FILES),
        token=token,
    )
    return Path(local)


def load_pretrained(
    name_or_path: str | os.PathLike,
    device: torch.device | str | None = None,
    revision: Optional[str] = None,
    token: Optional[str] = None,
    require_gpu_check: bool = True,
) -> tuple[VUAFModel, VUAFTokenizer]:
    """Load a VUAF model + tokenizer from a local dir or Hub repo.

    Parameters
    ----------
    name_or_path : either a local directory or a "user/repo" HF Hub id.
    device : optional torch device. Defaults to the GPU returned by
        `require_gpu()` when `require_gpu_check=True`.
    revision : optional Hub revision (branch / tag / commit).
    token : optional HF auth token (private repos).
    require_gpu_check : if True (default), VUAF refuses to load on CPU.

    Returns
    -------
    (model, tokenizer)
    """
    src = str(name_or_path)
    if _looks_like_hub_id(src):
        local_dir = _download_from_hub(src, revision=revision, token=token)
    else:
        local_dir = Path(src)
        if not local_dir.is_dir():
            raise FileNotFoundError(
                f"VUAF checkpoint dir not found: {local_dir}. "
                f"Pass a local path or a 'user/repo' HF id."
            )

    if device is None and require_gpu_check:
        device = require_gpu()

    model, _meta = load_checkpoint(local_dir, device=device)
    tokenizer = VUAFTokenizer.load(local_dir)
    return model, tokenizer
