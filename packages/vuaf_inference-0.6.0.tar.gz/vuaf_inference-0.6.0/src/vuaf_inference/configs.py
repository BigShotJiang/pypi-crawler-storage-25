"""VUAF model configuration registry."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class VUAFConfig:
    name: str
    vocab_size: int
    tie_embeddings: bool = True
    d_model: int = 128
    n_layers: int = 6
    token_mix_pattern: Tuple[str, ...] = (
        "rwkv7", "mamba2", "rwkv7", "attn", "rwkv7", "mamba2",
    )
    channel_mix_pattern: Tuple[str, ...] = (
        "swiglu", "moe", "swiglu", "moe", "swiglu", "moe",
    )
    rwkv_n_heads: int = 4
    rwkv_head_dim: int = 32
    rwkv_lowrank: int = 16
    mamba_d_state: int = 16
    mamba_d_head: int = 64
    mamba_expand: int = 1
    mamba_chunk_size: int = 64
    mamba_mode: str = "parallel"
    attn_n_heads: int = 4
    attn_head_dim: int = 32
    attn_rope_base: float = 10000.0
    ffn_hidden: int = 256
    moe_n_experts: int = 4
    moe_top_k: int = 1
    moe_lb_loss_coef: float = 0.01
    loop_steps: int = 4
    halt_init_bias: float = -2.0
    entropy_reg_coef: float = 0.01
    max_seq_len: int = 1024
    dropout: float = 0.0

    def __post_init__(self) -> None:
        if len(self.token_mix_pattern) != self.n_layers:
            raise ValueError(
                f"token_mix_pattern length {len(self.token_mix_pattern)} "
                f"!= n_layers {self.n_layers}"
            )
        if len(self.channel_mix_pattern) != self.n_layers:
            raise ValueError(
                f"channel_mix_pattern length {len(self.channel_mix_pattern)} "
                f"!= n_layers {self.n_layers}"
            )
        valid_token = {"rwkv7", "mamba2", "attn"}
        valid_chan = {"swiglu", "moe"}
        for kind in self.token_mix_pattern:
            if kind not in valid_token:
                raise ValueError(f"Unknown token mixer '{kind}'")
        for kind in self.channel_mix_pattern:
            if kind not in valid_chan:
                raise ValueError(f"Unknown channel mixer '{kind}'")
        if self.rwkv_n_heads * self.rwkv_head_dim != self.d_model:
            raise ValueError(
                "rwkv_n_heads * rwkv_head_dim must equal d_model"
            )
        if self.attn_n_heads * self.attn_head_dim != self.d_model:
            raise ValueError(
                "attn_n_heads * attn_head_dim must equal d_model"
            )
        if self.moe_top_k > self.moe_n_experts:
            raise ValueError("moe_top_k cannot exceed moe_n_experts")


_REGISTRY: dict[str, VUAFConfig] = {}


def _register(cfg: VUAFConfig) -> VUAFConfig:
    if cfg.name in _REGISTRY:
        raise ValueError(f"Config '{cfg.name}' already registered")
    _REGISTRY[cfg.name] = cfg
    return cfg


VUAF_PICO = _register(VUAFConfig(
    name="VUAF-Pico",
    vocab_size=4096,
))


def get_config(name: str) -> VUAFConfig:
    if name not in _REGISTRY:
        raise KeyError(
            f"Unknown VUAF config '{name}'. "
            f"Available: {sorted(_REGISTRY)}"
        )
    return _REGISTRY[name]


def list_configs() -> list[str]:
    return sorted(_REGISTRY)
