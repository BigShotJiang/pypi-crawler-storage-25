"""vuaf_inference: minimal package to load and run VUAF checkpoints.

Public API
----------
- `VUAFConfig`        model config dataclass
- `VUAFModel`         the model class
- `VUAFTokenizer`     load-only SentencePiece + special-tokens wrapper
- `CategoryRegistry`  category list persisted with each checkpoint
- `load_pretrained()` one-call loader: local dir or `user/repo` from HF Hub
- `load_checkpoint()` lower-level: loads from a local dir
- `save_checkpoint()` write a checkpoint folder
- `generate()`        adaptive-depth token generator
- `build_chat_prompt()` build a category-conditioned prompt
- `GenConfig`         generation knobs
- `require_gpu()`     hard-fail-on-CPU guard

This package contains *only* what's needed to run a trained VUAF
checkpoint. The training pipeline, dataset tooling, benchmarks, and
support utilities live in a separate (private) `vuaf` package.
"""
from vuaf_inference.configs import VUAFConfig, get_config, list_configs
from vuaf_inference.gpu_guard import NoGPUError, gpu_info, require_gpu
from vuaf_inference.categories import CategoryRegistry
from vuaf_inference.tokenizer import TokenizerMeta, VUAFTokenizer
from vuaf_inference.model import VUAFModel, VUAFOutput
from vuaf_inference.checkpoint import load_checkpoint, save_checkpoint
from vuaf_inference.generate import (
    GenConfig,
    build_chat_prompt,
    generate,
)
from vuaf_inference.loader import load_pretrained

__version__ = "0.6.0"

__all__ = [
    "VUAFConfig", "get_config", "list_configs",
    "NoGPUError", "gpu_info", "require_gpu",
    "CategoryRegistry",
    "TokenizerMeta", "VUAFTokenizer",
    "VUAFModel", "VUAFOutput",
    "load_checkpoint", "save_checkpoint",
    "GenConfig", "build_chat_prompt", "generate",
    "load_pretrained",
]
