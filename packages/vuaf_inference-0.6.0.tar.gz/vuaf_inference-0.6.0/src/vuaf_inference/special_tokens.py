"""VUAF special-token contract."""
from __future__ import annotations

from typing import List

from vuaf_inference.categories import CategoryRegistry


UNK = "<unk>"
PAD = "<pad>"
BOS = "<bos>"
EOS = "<eos>"
USER = "<|user|>"
ASSISTANT = "<|assistant|>"
SYSTEM = "<|system|>"
TURN = "<|turn|>"
DOC = "<|doc|>"
META_OPEN = "<|meta|>"
META_CLOSE = "<|/meta|>"

CORE_SPECIALS: list[str] = [
    UNK, PAD, BOS, EOS,
    USER, ASSISTANT, SYSTEM,
    TURN, DOC,
    META_OPEN, META_CLOSE,
]


def all_specials(reg: CategoryRegistry) -> List[str]:
    return CORE_SPECIALS + reg.all_special_tokens()


def n_reserved(reg: CategoryRegistry) -> int:
    return len(CORE_SPECIALS) + reg.max_categories
