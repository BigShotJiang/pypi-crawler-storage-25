"""Adaptive-depth generation + chat prompt construction.

The generator respects the halt head per token: at each prediction
position, it picks the loop step whose halt probability first crosses
`halt_threshold`, and uses the logits at that step.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator, List, Optional

import torch

from vuaf_inference.gpu_guard import require_gpu
from vuaf_inference.model import VUAFModel
from vuaf_inference.tokenizer import VUAFTokenizer
from vuaf_inference import special_tokens as st


@dataclass
class GenConfig:
    max_new_tokens: int = 128
    temperature: float = 1.0
    top_k: int = 0
    top_p: float = 1.0
    use_halt: bool = True
    halt_threshold: float = 0.5


def _sample_logits(
    logits: torch.Tensor, temp: float, top_k: int, top_p: float
) -> torch.Tensor:
    if temp <= 0:
        return logits.argmax(dim=-1, keepdim=True)
    logits = logits / temp
    if top_k and top_k < logits.size(-1):
        v, _ = torch.topk(logits, top_k)
        logits[logits < v[-1]] = float("-inf")
    if 0 < top_p < 1.0:
        sorted_logits, sorted_idx = torch.sort(logits, descending=True)
        probs = sorted_logits.softmax(dim=-1)
        cum = probs.cumsum(dim=-1)
        keep = cum <= top_p
        keep[..., 0] = True
        sorted_logits[~keep] = float("-inf")
        logits = torch.full_like(logits, float("-inf"))
        logits.scatter_(0, sorted_idx, sorted_logits)
    probs = logits.softmax(dim=-1)
    return torch.multinomial(probs, num_samples=1)


def _adaptive_forward(
    model: VUAFModel,
    input_ids: torch.Tensor,
    halt_threshold: float,
) -> tuple[torch.Tensor, int]:
    out = model(input_ids)
    R = len(out.step_logits)
    chosen = R - 1
    if out.halt_logits:
        for r, hl in enumerate(out.halt_logits):
            p_halt = torch.sigmoid(hl[:, -1]).item()
            if p_halt >= halt_threshold:
                chosen = r
                break
    return out.step_logits[chosen][:, -1, :], chosen


@torch.no_grad()
def generate(
    model: VUAFModel,
    tokenizer: VUAFTokenizer,
    prompt_ids: List[int],
    cfg: GenConfig | None = None,
) -> Iterator[tuple[int, int]]:
    """Stream (token_id, chosen_loop_step) pairs."""
    cfg = cfg or GenConfig()
    device = require_gpu()
    model.eval()
    model.to(device)

    ids = torch.tensor(prompt_ids, dtype=torch.long, device=device).unsqueeze(0)
    eos_id = tokenizer.meta.eos_id

    for _ in range(cfg.max_new_tokens):
        if cfg.use_halt:
            logits, chosen = _adaptive_forward(model, ids, cfg.halt_threshold)
        else:
            out = model(ids)
            logits = out.final_logits[:, -1, :]
            chosen = len(out.step_logits) - 1
        next_id = _sample_logits(
            logits.squeeze(0), cfg.temperature, cfg.top_k, cfg.top_p
        ).item()
        yield int(next_id), int(chosen)
        if next_id == eos_id:
            return
        ids = torch.cat(
            [ids, torch.tensor([[next_id]], device=device, dtype=torch.long)],
            dim=1,
        )


def build_chat_prompt(
    tokenizer: VUAFTokenizer,
    category: str,
    system: Optional[str],
    user_message: str,
    history: Optional[List[tuple[str, str]]] = None,
) -> List[int]:
    """Build a token-id prompt for chat generation."""
    cat_tok = tokenizer.registry.token_for(category)
    parts = [st.BOS, cat_tok]
    if system:
        parts.append(st.TURN + st.SYSTEM + system)
    if history:
        for role, content in history:
            role_tok = {"user": st.USER, "assistant": st.ASSISTANT}[role]
            parts.append(st.TURN + role_tok + content)
    parts.append(st.TURN + st.USER + user_message)
    parts.append(st.TURN + st.ASSISTANT)
    return tokenizer.encode("".join(parts))
