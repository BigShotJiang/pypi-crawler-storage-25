"""VUAF model: stacked blocks under an Ouro-style parameter-shared loop.

Forward returns logits for each loop step plus the per-step halt logits,
so the trainer can compute the PonderNet-style entropy-regularized loss
(Ouro Stage 1) or the adaptive-gating objective (Ouro Stage 2).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import torch
import torch.nn as nn

from vuaf_inference.block import VUAFBlock
from vuaf_inference.configs import VUAFConfig
from vuaf_inference.layers.halt import HaltHead
from vuaf_inference.layers.norm import RMSNorm


@dataclass
class VUAFOutput:
    """Container for a forward pass."""
    # Logits at every loop step: list of length R, each (B, T, V)
    step_logits: List[torch.Tensor]
    # Halt logits at every loop step: list of length R, each (B, T)
    # Last step has no halt (forced exit), so length = R-1.
    halt_logits: List[torch.Tensor]
    # MoE aux losses summed over MoE layers, for current forward.
    moe_aux_loss: torch.Tensor

    @property
    def final_logits(self) -> torch.Tensor:
        return self.step_logits[-1]


class VUAFModel(nn.Module):
    """VUAF base model.

    Architecture
    ------------
    Embedding -> [Block_0, Block_1, ..., Block_{L-1}]  (this stack is
    the parameter-shared core, applied R times) -> final norm -> LM head.
    """

    def __init__(self, cfg: VUAFConfig) -> None:
        super().__init__()
        self.cfg = cfg

        self.embed = nn.Embedding(cfg.vocab_size, cfg.d_model)

        self.blocks = nn.ModuleList(
            VUAFBlock(cfg, t_kind, c_kind)
            for t_kind, c_kind in zip(
                cfg.token_mix_pattern, cfg.channel_mix_pattern
            )
        )

        self.final_norm = RMSNorm(cfg.d_model)

        if cfg.tie_embeddings:
            self.lm_head = None  # use self.embed.weight transposed
        else:
            self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)

        # One halt head, applied at end of each loop step (except the last).
        self.halt_head = HaltHead(cfg.d_model, init_bias=cfg.halt_init_bias)

        # Init embedding (small).
        nn.init.normal_(self.embed.weight, mean=0.0, std=0.02)

    # ------------------------------------------------------------------
    def num_parameters(self, only_trainable: bool = True) -> int:
        n = 0
        for p in self.parameters():
            if only_trainable and not p.requires_grad:
                continue
            n += p.numel()
        return n

    # ------------------------------------------------------------------
    def _project_to_vocab(self, h: torch.Tensor) -> torch.Tensor:
        if self.cfg.tie_embeddings:
            # h: (B, T, D), embed.weight: (V, D)
            return torch.matmul(h, self.embed.weight.t())
        return self.lm_head(h)  # type: ignore[misc]

    # ------------------------------------------------------------------
    def _run_stack(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """One pass through the L blocks. Returns (h, summed_moe_aux)."""
        moe_aux = x.new_zeros(())
        for block in self.blocks:
            x = block(x)
            aux = block.moe_aux_loss
            if aux is not None:
                moe_aux = moe_aux + aux
        return x, moe_aux

    # ------------------------------------------------------------------
    def forward(
        self,
        input_ids: torch.Tensor,
        n_loops: Optional[int] = None,
    ) -> VUAFOutput:
        """
        Parameters
        ----------
        input_ids : (B, T) long
        n_loops : optional override of cfg.loop_steps. Use 1 for ablation.

        Returns
        -------
        VUAFOutput with step_logits, halt_logits, moe_aux_loss.
        """
        R = n_loops if n_loops is not None else self.cfg.loop_steps
        if R < 1:
            raise ValueError("n_loops must be >= 1")

        h = self.embed(input_ids)                  # (B, T, D)

        step_logits: List[torch.Tensor] = []
        halt_logits: List[torch.Tensor] = []
        total_aux = h.new_zeros(())

        for r in range(R):
            h, aux = self._run_stack(h)
            total_aux = total_aux + aux

            h_norm = self.final_norm(h)
            logits = self._project_to_vocab(h_norm)
            step_logits.append(logits)

            # Halt only for non-final steps (last step is forced exit).
            if r < R - 1:
                halt_logits.append(self.halt_head(h_norm))

        # Average MoE aux across loop steps so its scale is independent of R.
        total_aux = total_aux / R

        return VUAFOutput(
            step_logits=step_logits,
            halt_logits=halt_logits,
            moe_aux_loss=total_aux,
        )
