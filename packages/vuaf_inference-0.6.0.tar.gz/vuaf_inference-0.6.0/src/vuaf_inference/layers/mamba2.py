"""Mamba-2 SSD (Structured State-Space Duality) layer.

Implements the scalar-times-identity selective SSM from
  Dao & Gu 2024, "Transformers are SSMs: Generalized Models and Efficient
  Algorithms Through Structured State Space Duality"
  https://arxiv.org/abs/2405.21060

Recurrence (per channel of head):
    h_t = a_t * h_{t-1} + B_t * x_t        (a_t scalar, h_t in R^N)
    y_t = C_t^T h_t

A, B, C produced *in parallel* with X (Mamba-2 architectural change).

Two scan implementations are provided:
  - `mode="recurrent"` : reference Python time loop. O(T) Python ops,
                        used for inference (state-tracking) and parity
                        checks. Numerically simple.
  - `mode="parallel"` : matmul-friendly dual form. Builds the (B,T,T,H)
                        decay+CB matrix and uses one big einsum. ~5-10x
                        faster than the Python loop for moderate T,
                        memory grows as T^2 so it's appropriate for
                        training-time sequence lengths (T <= ~2048).

Default is `parallel` for training-mode forward; switch to `recurrent`
for autoregressive generation (where T is small but state must persist).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class Mamba2(nn.Module):
    def __init__(
        self,
        d_model: int,
        d_state: int = 16,
        d_head: int = 64,
        expand: int = 1,
        chunk_size: int = 64,
        mode: str = "parallel",
    ) -> None:
        super().__init__()
        if (d_model * expand) % d_head != 0:
            raise ValueError(
                "d_model * expand must be divisible by d_head"
            )
        if mode not in {"parallel", "recurrent"}:
            raise ValueError(f"Unknown mode '{mode}'")
        self.mode = mode
        self.d_model = d_model
        self.d_inner = d_model * expand
        self.d_state = d_state
        self.d_head = d_head
        self.n_heads = self.d_inner // d_head
        self.chunk_size = chunk_size

        # Single in-projection produces x, B, C, and a (the scalar decay
        # logit per head, per token).
        # Layout: [x : d_inner] [B : d_state] [C : d_state] [a : n_heads]
        self.in_proj = nn.Linear(
            d_model,
            self.d_inner + 2 * d_state + self.n_heads,
            bias=False,
        )

        # Per-head bias for a (initialized so a_t starts near 1, i.e. the
        # SSM remembers).
        self.A_log = nn.Parameter(
            torch.log(torch.linspace(1.0, 16.0, self.n_heads))
        )
        self.D = nn.Parameter(torch.ones(self.n_heads))  # skip connection

        # Output projection.
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=False)

        # Pre-output RMSNorm (Mamba-2 detail).
        self.norm = nn.LayerNorm(self.d_inner, eps=1e-5)

        nn.init.xavier_uniform_(self.in_proj.weight)
        nn.init.xavier_uniform_(self.out_proj.weight)

    # ------------------------------------------------------------------
    def forward(self, u: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        u : (B, T, d_model)

        Returns
        -------
        y : (B, T, d_model)
        """
        B, T, _ = u.shape
        H, P, N = self.n_heads, self.d_head, self.d_state

        proj = self.in_proj(u)  # (B, T, d_inner + 2N + H)
        x, Bp, Cp, dt = proj.split(
            [self.d_inner, N, N, H], dim=-1
        )
        # x: (B, T, d_inner) ; Bp, Cp: (B, T, N) ; dt: (B, T, H)

        # Compute scalar decay a_t per head per token.
        # Use softplus on (dt + A_log) so decay base is positive,
        # then a = exp(-softplus(...)) which lies in (0, 1).
        A = -torch.exp(self.A_log)               # (H,)  negative
        delta = F.softplus(dt + A.unsqueeze(0).unsqueeze(0))  # (B, T, H)
        # a_t in (0, 1): a = exp(-delta), so larger delta = more forgetting.
        a = torch.exp(-delta)                    # (B, T, H)

        # Reshape x to (B, T, H, P).
        x = x.view(B, T, H, P)

        # Run scan: parallel matmul form for training, recurrent for
        # inference / debugging.
        if self.mode == "parallel":
            y = self._ssd_parallel(x, Bp, Cp, a)
        else:
            y = self._ssd_recurrent(x, Bp, Cp, a)

        # Skip connection (D-term).
        y = y + x * self.D.view(1, 1, H, 1)

        y = y.reshape(B, T, self.d_inner)
        y = self.norm(y)
        return self.out_proj(y)

    # ------------------------------------------------------------------
    def _ssd_recurrent(
        self,
        x: torch.Tensor,   # (B, T, H, P)
        Bp: torch.Tensor,  # (B, T, N)
        Cp: torch.Tensor,  # (B, T, N)
        a: torch.Tensor,   # (B, T, H)
    ) -> torch.Tensor:
        """Reference recurrent scan, GPU-friendly via matmul on each step.

        State shape: (B, H, P, N) where P = head dim, N = state dim.
        h_t = a_t * h_{t-1} + outer(x_t, B_t)
        y_t = h_t @ C_t  along the N axis  -> (B, H, P)
        """
        B, T, H, P = x.shape
        N = Bp.size(-1)
        device = x.device
        dtype = x.dtype

        h = torch.zeros(B, H, P, N, device=device, dtype=dtype)
        outs = []
        for t in range(T):
            x_t = x[:, t]              # (B, H, P)
            B_t = Bp[:, t]             # (B, N)
            C_t = Cp[:, t]             # (B, N)
            a_t = a[:, t]              # (B, H)

            # Decay state: scale by a_t (broadcast over P, N).
            h = h * a_t.unsqueeze(-1).unsqueeze(-1)

            # Add x_t outer B_t: (B, H, P) outer (B, N) -> (B, H, P, N)
            update = torch.einsum("bhp,bn->bhpn", x_t, B_t)
            h = h + update

            # Read out: y_t = h @ C_t   -> (B, H, P)
            y_t = torch.einsum("bhpn,bn->bhp", h, C_t)
            outs.append(y_t)

        return torch.stack(outs, dim=1)  # (B, T, H, P)

    # ------------------------------------------------------------------
    def _ssd_parallel(
        self,
        x: torch.Tensor,   # (B, T, H, P)
        Bp: torch.Tensor,  # (B, T, N)
        Cp: torch.Tensor,  # (B, T, N)
        a: torch.Tensor,   # (B, T, H)
    ) -> torch.Tensor:
        """SSD dual-attention form. Matmul-friendly, GPU-fast.

        Identity used (per head h):
            y_t = sum_{s<=t} (prod_{k=s+1}^t a_k) * (C_t . B_s) * x_s

        Compute in three pieces:
          - CB[b, t, s] = C_t . B_s              (one matmul)
          - log_decay_diff[b, t, s, h] =
                log_a_cum[t,h] - log_a_cum[s,h]  (broadcast subtract)
          - mask: causal lower triangular
          - kernel: M[b,t,s,h] = exp(log_decay_diff) * CB[b,t,s] * mask
          - y[b,t,h,p] = einsum_s(M, x)

        Memory peak: O(B * T * T * H). For T<=2048 this is fine; for
        much longer T use the chunked algorithm (TODO).
        """
        B, T, H, P = x.shape

        # Promote to fp32 for the cumulative ops; cast back at the end.
        in_dtype = x.dtype
        a32 = a.float()
        x32 = x.float()
        Bp32 = Bp.float()
        Cp32 = Cp.float()

        # CB: (B, T, T)
        CB = torch.matmul(Cp32, Bp32.transpose(-2, -1))

        # log a-cumulative per head: (B, T, H)
        log_a_cum = torch.log(a32.clamp_min(1e-9)).cumsum(dim=1)

        # log_decay_diff[b, t, s, h] = log_a_cum[b, t, h] - log_a_cum[b, s, h]
        # Shape: (B, T, T, H)
        log_diff = log_a_cum.unsqueeze(2) - log_a_cum.unsqueeze(1)

        # Build causal mask: (T, T) lower triangular ones, else 0.
        causal = torch.tril(
            torch.ones(T, T, device=x.device, dtype=torch.bool)
        ).view(1, T, T, 1)
        # Where not causal, push log to -inf so exp -> 0.
        neg_inf = torch.finfo(log_diff.dtype).min
        log_diff = torch.where(causal, log_diff, log_diff.new_full((), neg_inf))
        decay = log_diff.exp()                      # (B, T, T, H)

        # Kernel: M[b,t,s,h] = decay[b,t,s,h] * CB[b,t,s]
        M = decay * CB.unsqueeze(-1)                # (B, T, T, H)

        # y[b,t,h,p] = sum_s M[b,t,s,h] * x[b,s,h,p]
        y = torch.einsum("btsh,bshp->bthp", M, x32)
        return y.to(in_dtype)
