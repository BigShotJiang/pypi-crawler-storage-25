"""Sparse Mixture-of-Experts FFN with top-1 routing.

Each expert is a SwiGLU. Top-1 router with auxiliary load-balancing
loss exposed via `last_aux_loss` for the trainer to add to total loss.

Parameter sketch (d_model=128, n_experts=4, hidden=256):
    router : 128*4 = 512
    experts : 4 * (128*256 + 128*256 + 256*128) = 4 * 98304 = 393216
    -> ~395K params per layer
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from vuaf_inference.layers.swiglu import SwiGLU


class MoE(nn.Module):
    def __init__(
        self,
        d_model: int,
        hidden: int,
        n_experts: int,
        top_k: int = 1,
    ) -> None:
        super().__init__()
        if top_k != 1:
            # Multi-expert routing path adds complexity for tiny gains
            # at this scale. Restrict to top-1 in v1.
            raise NotImplementedError("Only top_k=1 is implemented in v1")
        self.n_experts = n_experts
        self.top_k = top_k

        self.router = nn.Linear(d_model, n_experts, bias=False)
        self.experts = nn.ModuleList(
            SwiGLU(d_model, hidden) for _ in range(n_experts)
        )

        # Buffer to expose load-balancing loss for the current forward.
        # Marked non-persistent so it's not in the saved state_dict
        # (it's transient: only valid right after a forward pass).
        self.register_buffer(
            "last_aux_loss", torch.tensor(0.0), persistent=False
        )

        nn.init.xavier_uniform_(self.router.weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, T, D)
        B, T, D = x.shape
        N_tok = B * T
        E = self.n_experts
        x_flat = x.reshape(N_tok, D)

        logits = self.router(x_flat)                   # (N_tok, E)
        probs = F.softmax(logits, dim=-1)              # (N_tok, E)
        top_val, top_idx = probs.max(dim=-1)           # (N_tok,)

        # Aux load-balancing loss (Switch Transformer style):
        # E * sum_e (frac_tokens_to_e * mean_prob_e)
        # frac = number of tokens routed to expert e / total tokens
        # mean_prob = mean router prob mass on expert e
        with torch.no_grad():
            frac = torch.zeros(E, device=x.device, dtype=probs.dtype)
            frac.scatter_add_(
                0, top_idx, torch.ones_like(top_val)
            )
            frac = frac / max(N_tok, 1)
        mean_p = probs.mean(dim=0)                     # (E,)
        aux = E * (frac * mean_p).sum()
        self.last_aux_loss = aux

        # Dispatch tokens to experts.
        y_flat = torch.zeros_like(x_flat)
        for e in range(E):
            mask = (top_idx == e)
            if mask.any():
                y_flat[mask] = self.experts[e](x_flat[mask]) * top_val[mask].unsqueeze(-1)

        return y_flat.view(B, T, D)
