"""Rotary Position Embeddings (RoPE).

Standard Su et al. formulation. Applied to Q and K in sparse attention
only; RWKV-7 and Mamba2 carry positional info implicitly via state.
"""
from __future__ import annotations

import torch
import torch.nn as nn


def _build_inv_freq(head_dim: int, base: float, device: torch.device) -> torch.Tensor:
    half = head_dim // 2
    return 1.0 / (base ** (torch.arange(0, half, device=device).float() / half))


def _build_cos_sin(
    seq_len: int, head_dim: int, base: float, device: torch.device
) -> tuple[torch.Tensor, torch.Tensor]:
    inv_freq = _build_inv_freq(head_dim, base, device)
    t = torch.arange(seq_len, device=device).float()
    freqs = torch.outer(t, inv_freq)  # (T, half)
    cos = freqs.cos()
    sin = freqs.sin()
    return cos, sin


def _rotate_half(x: torch.Tensor) -> torch.Tensor:
    # x: (..., head_dim) ; split last dim into two halves and rotate
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat((-x2, x1), dim=-1)


def apply_rope(
    q: torch.Tensor,
    k: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Apply rotary embedding to q, k.

    q, k : (B, H, T, D) where D is head_dim
    cos, sin : (T, D/2) -> broadcast to (1, 1, T, D)
    """
    # Duplicate cos/sin to full head_dim along last axis.
    cos_full = torch.cat((cos, cos), dim=-1).unsqueeze(0).unsqueeze(0)
    sin_full = torch.cat((sin, sin), dim=-1).unsqueeze(0).unsqueeze(0)
    q_rot = (q * cos_full) + (_rotate_half(q) * sin_full)
    k_rot = (k * cos_full) + (_rotate_half(k) * sin_full)
    return q_rot, k_rot


class RotaryCache(nn.Module):
    """Cache cos/sin tables on-device, rebuild when length grows."""

    def __init__(self, head_dim: int, max_seq_len: int, base: float = 10000.0):
        super().__init__()
        self.head_dim = head_dim
        self.base = base
        self.register_buffer("_cos", torch.empty(0), persistent=False)
        self.register_buffer("_sin", torch.empty(0), persistent=False)
        self._cached_len = 0
        self._max_seq_len = max_seq_len

    def get(self, seq_len: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
        if seq_len > self._cached_len or self._cos.device != device:
            cos, sin = _build_cos_sin(
                max(seq_len, self._max_seq_len), self.head_dim, self.base, device
            )
            self._cos = cos
            self._sin = sin
            self._cached_len = cos.size(0)
        return self._cos[:seq_len], self._sin[:seq_len]
