"""VUAF layers (inference-side)."""
