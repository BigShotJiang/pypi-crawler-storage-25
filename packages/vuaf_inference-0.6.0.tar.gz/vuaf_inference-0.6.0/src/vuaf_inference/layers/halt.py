"""PonderNet-style halt head for Ouro-loop adaptive depth.

At each loop step r in 0..R-1, the halt head produces a per-token
probability lambda_r of stopping at step r. The exit distribution is:

    p_r = lambda_r * prod_{i<r} (1 - lambda_i)
    p_R = prod_{i<R} (1 - lambda_i)        # forced exit at last step

This module returns the *logit* of lambda; the loop runner converts to
probability and accumulates exit probs.
"""
from __future__ import annotations

import torch
import torch.nn as nn


class HaltHead(nn.Module):
    def __init__(self, d_model: int, init_bias: float = -2.0) -> None:
        super().__init__()
        self.proj = nn.Linear(d_model, 1, bias=True)
        # Initialize bias negative so initial lambda is small (model
        # prefers to keep iterating, especially early in training).
        nn.init.zeros_(self.proj.weight)
        nn.init.constant_(self.proj.bias, init_bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, T, D) -> halt logit (B, T)
        return self.proj(x).squeeze(-1)
