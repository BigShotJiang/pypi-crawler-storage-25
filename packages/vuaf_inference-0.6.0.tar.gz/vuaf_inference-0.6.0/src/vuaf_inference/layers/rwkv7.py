"""RWKV-7 'Goose' TimeMix layer.

Implements the generalized delta rule from
  Peng et al. 2025, "RWKV-7 Goose with Expressive Dynamic State Evolution"
  https://arxiv.org/abs/2503.14456

Per-head WKV recurrence (shapes per head, D = head_dim):
    S_t = S_{t-1} @ (diag(w_t) - kappa_t @ a_t^T) + v_t @ k_t^T
    out_t = S_t^T @ r_t

with vector-valued data-dependent decay w_t (sigmoid of low-rank proj),
in-context learning rate a_t (low-rank), gating g_t, separate removal key
kappa and replacement key k.

This file is a *reference* PyTorch implementation: the time loop is in
Python. It runs on GPU (matmuls dispatched to ROCm/CUDA) and produces
identical numerics to a future fused kernel; it is fast enough for a 3M
model on short sequences. Replace with a chunked / fused kernel later.

Parameter sketch (d_model=128, n_heads=4, head_dim=32, lowrank=16):
    r, k, v, kappa, g  : 5 * 128*128 = 81920
    w_low, a_low       : (128*16 + 16*128) + (128*16 + 16*4)
                       = 4096 + 2112 = 6208
    out_proj           : 128*128 = 16384
    group_norm         : 2 * 128
    -----------------------------------------
    ~105K params per TimeMix layer
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


class RWKV7TimeMix(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: int,
        lowrank: int = 16,
    ) -> None:
        super().__init__()
        if n_heads * head_dim != d_model:
            raise ValueError("n_heads * head_dim must equal d_model")

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = head_dim

        # Five token-shifted linear projections.
        # Receptance r, replacement key k, value v, removal key kappa, gate g.
        self.W_r = nn.Linear(d_model, d_model, bias=False)
        self.W_k = nn.Linear(d_model, d_model, bias=False)
        self.W_v = nn.Linear(d_model, d_model, bias=False)
        self.W_kappa = nn.Linear(d_model, d_model, bias=False)
        self.W_g = nn.Linear(d_model, d_model, bias=False)

        # Low-rank projection for vector-valued decay w (per-head, per-channel).
        # Output is per-head per-dim, i.e. shape (..., n_heads, head_dim).
        self.w_low_in = nn.Linear(d_model, lowrank, bias=False)
        self.w_low_out = nn.Linear(lowrank, d_model, bias=True)

        # Low-rank projection for in-context learning rate a (per-head scalar).
        self.a_low_in = nn.Linear(d_model, lowrank, bias=False)
        self.a_low_out = nn.Linear(lowrank, n_heads, bias=True)

        # Token-shift mix weights (per-channel scalar mixing of x_t and x_{t-1}).
        # Five separate mix vectors so the projections see slightly different
        # combinations, as in the RWKV reference impl.
        self.mix_r = nn.Parameter(torch.empty(d_model))
        self.mix_k = nn.Parameter(torch.empty(d_model))
        self.mix_v = nn.Parameter(torch.empty(d_model))
        self.mix_kappa = nn.Parameter(torch.empty(d_model))
        self.mix_g = nn.Parameter(torch.empty(d_model))

        # Output projection and per-head group norm on WKV output.
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        self.group_norm = nn.GroupNorm(
            num_groups=n_heads, num_channels=d_model, eps=1e-5
        )

        self._reset_parameters()

    # ------------------------------------------------------------------
    def _reset_parameters(self) -> None:
        # Standard small init for projections.
        for lin in [
            self.W_r, self.W_k, self.W_v, self.W_kappa, self.W_g,
            self.w_low_in, self.w_low_out,
            self.a_low_in, self.a_low_out,
            self.out_proj,
        ]:
            nn.init.xavier_uniform_(lin.weight, gain=1.0 / math.sqrt(2))
            if lin.bias is not None:
                nn.init.zeros_(lin.bias)

        # Token-shift mixes: linspace (1 -> 0) so first channels mostly
        # "current" token, last channels mostly "previous" token. This is
        # the RWKV reference convention.
        with torch.no_grad():
            ramp = torch.linspace(1.0, 0.0, self.d_model)
            for p in (self.mix_r, self.mix_k, self.mix_v,
                      self.mix_kappa, self.mix_g):
                p.copy_(ramp)

    # ------------------------------------------------------------------
    def _token_shift(self, x: torch.Tensor) -> torch.Tensor:
        """Return x_{t-1} (shifted by one along seq dim, zero pad at front)."""
        # x: (B, T, D)
        return F.pad(x[:, :-1, :], (0, 0, 1, 0))

    # ------------------------------------------------------------------
    def forward(
        self, x: torch.Tensor, state: torch.Tensor | None = None
    ) -> torch.Tensor:
        """
        Parameters
        ----------
        x : (B, T, d_model)
        state : optional (B, n_heads, head_dim, head_dim) WKV state.
            If None, initialized to zeros. State is *not* returned by
            default (training mode); inference helpers can be added later.

        Returns
        -------
        y : (B, T, d_model)
        """
        B, T, D = x.shape
        H, K = self.n_heads, self.head_dim

        # Token shift: mix current and previous token per-channel.
        x_prev = self._token_shift(x)
        xr = x + (x_prev - x) * (1.0 - self.mix_r)
        xk = x + (x_prev - x) * (1.0 - self.mix_k)
        xv = x + (x_prev - x) * (1.0 - self.mix_v)
        xkp = x + (x_prev - x) * (1.0 - self.mix_kappa)
        xg = x + (x_prev - x) * (1.0 - self.mix_g)

        r = self.W_r(xr).view(B, T, H, K)
        k = self.W_k(xk).view(B, T, H, K)
        v = self.W_v(xv).view(B, T, H, K)
        kappa = self.W_kappa(xkp).view(B, T, H, K)
        g = torch.sigmoid(self.W_g(xg)).view(B, T, H, K)

        # Vector-valued decay w in (0, 1) via sigmoid of low-rank proj,
        # then apply log1p-style transform: w_eff = exp(-exp(w_raw)) so
        # decay is bounded in (0, 1). The RWKV-7 paper uses a careful
        # parameterization; we use sigmoid for simplicity and stability.
        w_raw = self.w_low_out(torch.tanh(self.w_low_in(x))).view(B, T, H, K)
        w = torch.sigmoid(w_raw)  # (B, T, H, K), per-channel decay

        # In-context learning rate a in (0, 1), per-head scalar broadcast
        # over the head dim.
        a_raw = self.a_low_out(torch.tanh(self.a_low_in(x)))  # (B, T, H)
        a = torch.sigmoid(a_raw).unsqueeze(-1)  # (B, T, H, 1)

        # L2-normalize kappa so the rank-1 update is stable (paper trick).
        kappa = F.normalize(kappa, dim=-1)

        # WKV recurrence per head:
        #   S_t = S_{t-1} * (diag(w_t) - kappa_t @ (a_t * kappa_t)^T)
        #         + v_t @ k_t^T   (outer product, rank 1)
        #   out_t = S_t @ r_t
        # We use the "removal scaled by a" form: the effective removal
        # vector is (a * kappa).
        if state is None:
            S = torch.zeros(B, H, K, K, device=x.device, dtype=x.dtype)
        else:
            S = state

        outs = []
        for t in range(T):
            r_t = r[:, t]               # (B, H, K)
            k_t = k[:, t]               # (B, H, K)
            v_t = v[:, t]               # (B, H, K)
            kappa_t = kappa[:, t]       # (B, H, K)
            w_t = w[:, t]               # (B, H, K)
            a_t = a[:, t]               # (B, H, 1)
            g_t = g[:, t]               # (B, H, K)

            # Diag(w) applied to S: scale columns of S by w.
            # S has shape (B, H, K, K): rows index "from", cols index "to".
            # Convention: S_t row i represents the accumulated value when
            # query selects key dim i. We treat S as (B, H, K_in, K_out)
            # and update: S * diag(w) zeros nothing, just scales col-wise.
            S_decayed = S * w_t.unsqueeze(-2)  # broadcast w over K_in

            # Rank-1 removal: subtract S @ (kappa) outer (a * kappa).
            # S @ kappa : (B, H, K_in)  via einsum over K_out.
            S_kappa = torch.einsum("bhij,bhj->bhi", S_decayed, kappa_t)
            removal = torch.einsum(
                "bhi,bhj->bhij",
                S_kappa,
                a_t * kappa_t,  # (B, H, K)
            )
            S_new = S_decayed - removal

            # Rank-1 write: + v outer k (paper convention; we use
            # column = key, row = value so query r picks values).
            write = torch.einsum("bhi,bhj->bhij", v_t, k_t)
            S = S_new + write

            # Read out: out_t = S @ r along K_out axis -> (B, H, K_in)
            out_t = torch.einsum("bhij,bhj->bhi", S, r_t)
            outs.append(out_t)

        out = torch.stack(outs, dim=1)  # (B, T, H, K)
        out = out.reshape(B, T, D)

        # Per-head group norm, gate, output proj.
        # GroupNorm expects (B, C, *), so transpose T to last.
        out_n = self.group_norm(out.transpose(1, 2)).transpose(1, 2)
        out_n = out_n * g.reshape(B, T, D)
        return self.out_proj(out_n)
