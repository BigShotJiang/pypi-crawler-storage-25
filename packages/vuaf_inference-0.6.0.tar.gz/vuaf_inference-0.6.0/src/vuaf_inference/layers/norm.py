"""RMSNorm and sandwich norm wrapper."""
from __future__ import annotations

import torch
import torch.nn as nn


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x_f = x.float()
        rms = x_f.pow(2).mean(dim=-1, keepdim=True).add(self.eps).rsqrt()
        return (x_f * rms).to(dtype) * self.weight


class SandwichNorm(nn.Module):
    """Apply norm before AND after a wrapped module, with residual."""

    def __init__(self, dim: int, module: nn.Module, eps: float = 1e-6) -> None:
        super().__init__()
        self.pre = RMSNorm(dim, eps=eps)
        self.module = module
        self.post = RMSNorm(dim, eps=eps)

    def forward(self, x: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        h = self.module(self.pre(x), *args, **kwargs)
        return self.post(x + h)
