"""Sparse causal multi-head attention with RoPE.

"Rare strategic attention": only used in 1 out of N layers (Jamba-style).
Plain causal MHA, no flash attention dependency (ROCm flash support is
patchy across versions). Uses torch.nn.functional.scaled_dot_product_attention
which dispatches to the best available backend on GPU.

Parameter sketch (d_model=128, n_heads=4, head_dim=32):
    qkv_proj : 128 -> 384  = 49152
    out_proj : 128 -> 128  = 16384
    -> ~65K params per layer
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from vuaf_inference.layers.rope import RotaryCache, apply_rope


class SparseAttention(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: int,
        max_seq_len: int = 1024,
        rope_base: float = 10000.0,
    ) -> None:
        super().__init__()
        if n_heads * head_dim != d_model:
            raise ValueError("n_heads * head_dim must equal d_model")
        self.n_heads = n_heads
        self.head_dim = head_dim
        self.d_model = d_model

        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        self.rope = RotaryCache(head_dim, max_seq_len, base=rope_base)

        nn.init.xavier_uniform_(self.qkv.weight)
        nn.init.xavier_uniform_(self.out_proj.weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, T, D)
        B, T, D = x.shape
        H, K = self.n_heads, self.head_dim

        qkv = self.qkv(x)                                 # (B, T, 3D)
        q, k, v = qkv.split(D, dim=-1)
        q = q.view(B, T, H, K).transpose(1, 2)            # (B, H, T, K)
        k = k.view(B, T, H, K).transpose(1, 2)
        v = v.view(B, T, H, K).transpose(1, 2)

        cos, sin = self.rope.get(T, x.device)
        q, k = apply_rope(q, k, cos, sin)

        # Causal SDPA: dispatches to ROCm/CUDA backends automatically.
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        y = y.transpose(1, 2).contiguous().view(B, T, D)  # (B, T, D)
        return self.out_proj(y)
