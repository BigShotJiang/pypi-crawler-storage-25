# vuaf-inference

Inference-only runtime for VUAF (Void Ultimatus Architecture Fusion)
models. This is a small Python package that loads and runs trained VUAF
checkpoints. Training, dataset tooling, and the full reference
implementation are not part of this package.

> ⚠️ **Experimental research project.** VUAF is an architecture exploration.
> Outputs may be incoherent, biased, or wrong. Not for production.

## Install

```bash
pip install vuaf-inference

# Optional: load checkpoints directly from the Hugging Face Hub
pip install 'vuaf-inference[hub]'
```

You also need PyTorch with a working GPU build. VUAF is GPU-only and
will refuse to run on CPU.

```bash
# AMD ROCm (Linux + Windows for supported cards)
pip install --index-url https://download.pytorch.org/whl/rocm6.x torch

# NVIDIA CUDA
pip install --index-url https://download.pytorch.org/whl/cu121 torch
```

## Usage

```python
from vuaf_inference import (
    GenConfig, build_chat_prompt, generate, load_pretrained,
)

# Local directory or "user/repo" Hub id (requires the [hub] extra)
model, tokenizer = load_pretrained("Sqersters/vuaf-pico")

prompt = build_chat_prompt(
    tokenizer=tokenizer,
    category="stories",
    system=None,
    user_message="Once upon a time",
)
for tok_id, loop_step in generate(
    model, tokenizer, prompt, GenConfig(max_new_tokens=64)
):
    print(tokenizer.decode([tok_id]), end="", flush=True)
```

## Model card

See [Sqersters/vuaf-pico on Hugging Face](https://huggingface.co/Sqersters/vuaf-pico)
for architecture details, limitations, and citation info.

## License

Apache-2.0.
