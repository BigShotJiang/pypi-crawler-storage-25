"""Pydantic models for mock-me configuration schema."""

from typing import Any, Dict, List, Literal, Optional, Union
from pydantic import BaseModel, Field


class FakerRule(BaseModel):
    """A faker-based data generation rule."""
    type: str  # e.g. "name", "email", "uuid", "sentence", "int", "float", "date", "enum"
    # For int/float
    min: Optional[float] = None
    max: Optional[float] = None
    # For enum
    values: Optional[List[Any]] = None
    # For arrays
    min_items: Optional[int] = Field(None, alias="minItems")
    max_items: Optional[int] = Field(None, alias="maxItems")
    # For strings
    locale: Optional[str] = None
    # For dates
    start: Optional[str] = None
    end: Optional[str] = None
    format: Optional[str] = None  # e.g. "iso", "timestamp", "%Y-%m-%d"
    # For static override
    value: Optional[Any] = None
    # For template strings like "user_{{id}}"
    template: Optional[str] = None
    # Nested item schema for arrays
    items: Optional[Any] = None  # recursive

    class Config:
        populate_by_name = True


class FieldSchema(BaseModel):
    """Schema definition for a single response field."""
    type: str  # "string", "int", "float", "bool", "date", "uuid", "object", "array", "enum"
    faker: Optional[Union[str, FakerRule]] = None  # shorthand "email" or full rule
    value: Optional[Any] = None          # static override
    template: Optional[str] = None       # template string
    nullable: Optional[bool] = False
    # For objects
    properties: Optional[Dict[str, Any]] = None
    # For arrays
    items: Optional[Any] = None
    min_items: Optional[int] = Field(1, alias="minItems")
    max_items: Optional[int] = Field(5, alias="maxItems")
    # For enums
    values: Optional[List[Any]] = None
    # For numbers
    min: Optional[float] = None
    max: Optional[float] = None

    class Config:
        populate_by_name = True


class ResponseConfig(BaseModel):
    """Configuration for a mock response."""
    status: int = 200
    headers: Optional[Dict[str, str]] = None
    delay: Optional[float] = None  # seconds (overrides endpoint-level)
    body: Optional[Dict[str, Any]] = None   # schema-driven body
    raw: Optional[Any] = None               # static raw response (returned as-is)
    paginated: Optional[bool] = False       # wrap in pagination envelope


class ConditionalResponse(BaseModel):
    """Condition + response pair for conditional routing."""
    when: Dict[str, Any]       # e.g. {"query.status": "active", "body.role": "admin"}
    response: ResponseConfig


class ErrorCase(BaseModel):
    """A named error simulation scenario."""
    probability: Optional[float] = None    # 0.0–1.0 random trigger
    trigger: Optional[Dict[str, Any]] = None   # condition-based trigger (same syntax as ConditionalResponse.when)
    response: ResponseConfig


class ParameterSchema(BaseModel):
    """Schema for a request parameter (path, query, header, body field)."""
    type: str = "string"
    required: Optional[bool] = False
    default: Optional[Any] = None
    description: Optional[str] = None
    enum: Optional[List[Any]] = None


class EndpointConfig(BaseModel):
    """Full configuration for one endpoint."""
    path: str
    method: str = "GET"              # GET, POST, PUT, PATCH, DELETE
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    delay: Optional[float] = None    # seconds of artificial latency
    # Parameters
    path_params: Optional[Dict[str, ParameterSchema]] = Field(None, alias="pathParams")
    query_params: Optional[Dict[str, ParameterSchema]] = Field(None, alias="queryParams")
    header_params: Optional[Dict[str, ParameterSchema]] = Field(None, alias="headerParams")
    body_schema: Optional[Dict[str, FieldSchema]] = Field(None, alias="bodySchema")
    # Responses
    response: Optional[ResponseConfig] = None
    # Conditional responses evaluated in order; first match wins
    conditional_responses: Optional[List[ConditionalResponse]] = Field(None, alias="conditionalResponses")
    # Named error scenarios
    errors: Optional[List[ErrorCase]] = None

    class Config:
        populate_by_name = True


class PaginationConfig(BaseModel):
    """Global pagination defaults."""
    default_page_size: int = Field(10, alias="defaultPageSize")
    max_page_size: int = Field(100, alias="maxPageSize")
    page_param: str = Field("page", alias="pageParam")
    size_param: str = Field("size", alias="sizeParam")
    total_param: str = Field("total", alias="totalParam")
    data_param: str = Field("data", alias="dataParam")

    class Config:
        populate_by_name = True


class ServerConfig(BaseModel):
    """Top-level mock server configuration."""
    name: str = "mock-me server"
    description: Optional[str] = None
    version: str = "1.0.0"
    host: str = "0.0.0.0"
    port: int = 8000
    seed: Optional[int] = None           # for reproducible fake data
    environment: Optional[str] = "dev"
    global_delay: Optional[float] = Field(None, alias="globalDelay")   # seconds applied to all routes
    global_headers: Optional[Dict[str, str]] = Field(None, alias="globalHeaders")
    pagination: Optional[PaginationConfig] = None
    plugins: Optional[List[str]] = None  # paths to custom generator plugins
    endpoints: List[EndpointConfig] = []

    class Config:
        populate_by_name = True
