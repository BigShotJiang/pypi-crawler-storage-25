#!/usr/bin/env python3
"""
mock-me CLI
───────────
Usage:
  mock-me start config.json [--host HOST] [--port PORT] [--reload] [--seed SEED]
  mock-me validate config.json
  mock-me export config.json [--out server.py]
  mock-me init [--out config.json]
"""

from __future__ import annotations

import argparse
import json
import sys
import threading
from pathlib import Path

# ──────────────────────────────────────────────────────────────────────────────
# ANSI helpers
# ──────────────────────────────────────────────────────────────────────────────
R = "\033[0m"
BOLD = "\033[1m"
C = "\033[96m"
G = "\033[92m"
Y = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"

BANNER = f"""
{C}{BOLD}  ███╗   ███╗ ██████╗  ██████╗██╗  ██╗      ███╗   ███╗███████╗{R}
{C}{BOLD}  ████╗ ████║██╔═══██╗██╔════╝██║ ██╔╝      ████╗ ████║██╔════╝{R}
{C}{BOLD}  ██╔████╔██║██║   ██║██║     █████╔╝  ─── ██╔████╔██║█████╗  {R}
{C}{BOLD}  ██║╚██╔╝██║██║   ██║██║     ██╔═██╗      ██║╚██╔╝██║██╔══╝  {R}
{C}{BOLD}  ██║ ╚═╝ ██║╚██████╔╝╚██████╗██║  ██╗     ██║ ╚═╝ ██║███████╗{R}
{C}{BOLD}  ╚═╝     ╚═╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝     ╚═╝     ╚═╝╚══════╝{R}
{DIM}  Instant FastAPI mock servers from JSON – no backend required{R}
"""


def _print_banner() -> None:
    print(BANNER)


# ──────────────────────────────────────────────────────────────────────────────
# Commands
# ──────────────────────────────────────────────────────────────────────────────

def cmd_start(args: argparse.Namespace) -> None:
    """Start the mock server."""
    import uvicorn

    from mock_me.loader import ConfigWatcher, load_config
    from mock_me.server import build_app

    _print_banner()

    config_path = Path(args.config)

    try:
        config = load_config(config_path)
    except Exception as exc:
        print(f"{RED}❌ Config error: {exc}{R}")
        sys.exit(1)

    # CLI overrides
    if args.host:
        config.host = args.host
    if args.port:
        config.port = args.port
    if args.seed is not None:
        config.seed = args.seed

    app = build_app(config)

    # Hot-reload watcher
    if args.reload:
        def on_reload(new_config: "ServerConfig") -> None:  # type: ignore[name-defined]
            # We can't swap routes at runtime without restarting uvicorn;
            # signal the user to restart, or just rebuild the app in-place.
            print(f"{Y}⚡ Hot-reload detected – restarting routes…{R}")
            # Rebuild routes on the same app instance (limited; full restart preferred)
            # For production hot-reload, uvicorn --reload handles process restart.

        watcher = ConfigWatcher(config_path, on_reload)
        t = threading.Thread(target=watcher.start, daemon=True)
        t.start()

    print(f"  {G}{BOLD}Listening on{R} http://{config.host}:{config.port}\n")

    uvicorn.run(
        app,
        host=config.host,
        port=config.port,
        log_level="warning",  # suppress uvicorn noise; we do our own logging
        reload=False,
    )


def cmd_validate(args: argparse.Namespace) -> None:
    """Validate a config file without starting the server."""
    from .loader import load_config

    print(f"\n{C}{BOLD}mock-me validate{R}\n")
    try:
        config = load_config(args.config)
        print(f"{G}✅ Config is valid!{R}")
        print(f"   Name       : {config.name}")
        print(f"   Version    : {config.version}")
        print(f"   Environment: {config.environment}")
        print(f"   Endpoints  : {len(config.endpoints)}")
        for ep in config.endpoints:
            print(f"   {ep.method:<8} {ep.path}")
        print()
    except Exception as exc:
        print(f"{RED}❌ Validation failed:\n{exc}{R}")
        sys.exit(1)


def cmd_export(args: argparse.Namespace) -> None:
    """Export a standalone FastAPI server file."""
    from .exporter import export_server
    from .loader import load_config

    print(f"\n{C}{BOLD}mock-me export{R}\n")
    try:
        config = load_config(args.config)
        out = Path(args.out or "server_exported.py")
        export_server(config, out)
        print(f"{G}✅ Exported to:{R} {out.resolve()}")
        print(f"   Run with: python {out.name}")
        print()
    except Exception as exc:
        print(f"{RED}❌ Export failed: {exc}{R}")
        sys.exit(1)


def cmd_init(args: argparse.Namespace) -> None:
    """Write a starter config.json to disk."""
    out = Path(args.out or "config.json")
    # Copy the sample config from the package
    sample_path = Path(__file__).parent.parent / "sample_config.json"
    if sample_path.exists():
        out.write_text(sample_path.read_text(encoding="utf-8"), encoding="utf-8")
    else:
        # Minimal fallback
        minimal = {
            "name": "My Mock API",
            "port": 8000,
            "endpoints": [
                {
                    "path": "/hello",
                    "method": "GET",
                    "response": {
                        "status": 200,
                        "body": {
                            "message": {"type": "string", "value": "Hello from mock-me!"}
                        }
                    }
                }
            ]
        }
        out.write_text(json.dumps(minimal, indent=2), encoding="utf-8")

    print(f"\n{G}✅ Config created:{R} {out.resolve()}")
    print(f"   Edit it and run: mock-me start {out.name}\n")


# ──────────────────────────────────────────────────────────────────────────────
# Argument parser
# ──────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mock-me",
        description="Instantly generate and run local FastAPI mock servers from JSON schemas.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mock-me start config.json
  mock-me start config.json --port 9000 --reload
  mock-me validate config.json
  mock-me export config.json --out my_server.py
  mock-me init --out my_config.json
        """,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # start
    p_start = sub.add_parser("start", help="Start the mock server")
    p_start.add_argument("config", help="Path to JSON config file")
    p_start.add_argument("--host", help="Override host (default from config)")
    p_start.add_argument("--port", type=int, help="Override port (default from config)")
    p_start.add_argument("--reload", action="store_true", help="Watch config for changes and hot-reload")
    p_start.add_argument("--seed", type=int, help="Random seed for reproducible data")

    # validate
    p_val = sub.add_parser("validate", help="Validate a config file")
    p_val.add_argument("config", help="Path to JSON config file")

    # export
    p_exp = sub.add_parser("export", help="Export a standalone FastAPI server")
    p_exp.add_argument("config", help="Path to JSON config file")
    p_exp.add_argument("--out", help="Output file path (default: server_exported.py)")

    # init
    p_init = sub.add_parser("init", help="Create a starter config.json")
    p_init.add_argument("--out", help="Output file path (default: config.json)")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    dispatch = {
        "start": cmd_start,
        "validate": cmd_validate,
        "export": cmd_export,
        "init": cmd_init,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
