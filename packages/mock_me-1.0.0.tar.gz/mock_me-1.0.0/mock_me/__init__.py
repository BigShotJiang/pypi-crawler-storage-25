"""mock-me: Instantly generate and run local FastAPI mock servers from JSON schemas."""

__version__ = "1.0.0"
__author__ = "mock-me"
