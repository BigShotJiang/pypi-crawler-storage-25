"""
Mock Data Engine – schema-aware fake data generation with Faker + seeded randomness.
Supports: strings, emails, names, numbers, dates, UUIDs, booleans, enums, arrays, nested objects,
          templates, static overrides, and custom plugin generators.
"""

from __future__ import annotations

import importlib.util
import random
import re
import string
import sys
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

from faker import Faker

# ---------------------------------------------------------------------------
# Registry for custom plugin generators
# ---------------------------------------------------------------------------
_CUSTOM_GENERATORS: Dict[str, Callable[..., Any]] = {}


def register_generator(name: str, fn: Callable[..., Any]) -> None:
    """Register a custom data generator under `name`."""
    _CUSTOM_GENERATORS[name] = fn


def load_plugin(path: str) -> None:
    """Dynamically load a Python plugin file and register its generators."""
    spec = importlib.util.spec_from_file_location("mock_me_plugin", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load plugin: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules["mock_me_plugin"] = module
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    # Plugin must expose GENERATORS dict: {"type_name": callable}
    if hasattr(module, "GENERATORS"):
        for name, fn in module.GENERATORS.items():
            register_generator(name, fn)


# ---------------------------------------------------------------------------
# Core DataEngine
# ---------------------------------------------------------------------------

class DataEngine:
    """Generate realistic fake data from FieldSchema definitions."""

    def __init__(self, seed: Optional[int] = None, locale: str = "en_US"):
        self.seed = seed
        self._rng = random.Random(seed)
        self._faker = Faker(locale)
        if seed is not None:
            Faker.seed(seed)

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def generate(self, schema: Any, context: Optional[Dict[str, Any]] = None) -> Any:
        """
        Generate a value from a FieldSchema dict (or FieldSchema model instance).
        `context` carries request params for template interpolation.
        """
        if schema is None:
            return None

        # Accept raw dict or Pydantic model
        if hasattr(schema, "model_dump"):
            s = schema.model_dump(by_alias=False, exclude_none=False)
        elif isinstance(schema, dict):
            s = schema
        else:
            return schema  # already a scalar

        # Static override wins everything
        if s.get("value") is not None:
            return s["value"]

        # Template string
        if s.get("template"):
            return self._render_template(s["template"], context or {})

        # Nullable handling
        if s.get("nullable") and self._rng.random() < 0.1:
            return None

        dtype = (s.get("type") or "string").lower()
        faker_rule = s.get("faker")

        # Custom plugin generator
        if dtype in _CUSTOM_GENERATORS:
            return _CUSTOM_GENERATORS[dtype]()

        # Resolve faker shorthand string → rule dict
        if isinstance(faker_rule, str):
            faker_rule = {"type": faker_rule}

        return self._dispatch(dtype, s, faker_rule, context)

    # ------------------------------------------------------------------
    # Generate a full response body from a properties dict
    # ------------------------------------------------------------------

    def generate_body(
        self,
        properties: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        for key, field_schema in properties.items():
            result[key] = self.generate(field_schema, context)
        return result

    # ------------------------------------------------------------------
    # Type dispatch
    # ------------------------------------------------------------------

    def _dispatch(
        self,
        dtype: str,
        schema: Dict[str, Any],
        faker_rule: Optional[Dict[str, Any]],
        context: Optional[Dict[str, Any]],
    ) -> Any:
        if dtype == "object":
            return self._gen_object(schema, context)
        if dtype == "array":
            return self._gen_array(schema, context)
        if dtype in ("string", "str"):
            return self._gen_string(faker_rule, schema, context)
        if dtype in ("int", "integer"):
            return self._gen_int(faker_rule, schema)
        if dtype in ("float", "number", "decimal"):
            return self._gen_float(faker_rule, schema)
        if dtype in ("bool", "boolean"):
            return self._rng.choice([True, False])
        if dtype in ("date", "datetime"):
            return self._gen_date(faker_rule, schema)
        if dtype == "uuid":
            return str(self._faker.uuid4())
        if dtype == "enum":
            return self._gen_enum(schema)
        if dtype == "null":
            return None
        # Fallback: try faker method by name
        if faker_rule:
            return self._faker_call(faker_rule)
        return self._faker.word()

    # ------------------------------------------------------------------
    # Generators
    # ------------------------------------------------------------------

    def _gen_string(
        self,
        faker_rule: Optional[Dict[str, Any]],
        schema: Dict[str, Any],
        context: Optional[Dict[str, Any]],
    ) -> str:
        if schema.get("template"):
            return self._render_template(schema["template"], context or {})

        if not faker_rule:
            return self._faker.word()

        ftype = faker_rule.get("type", "word").lower()
        return str(self._faker_string(ftype, faker_rule))

    def _faker_string(self, ftype: str, rule: Dict[str, Any]) -> Any:
        mapping = {
            "name": self._faker.name,
            "first_name": self._faker.first_name,
            "last_name": self._faker.last_name,
            "email": self._faker.email,
            "username": self._faker.user_name,
            "password": self._faker.password,
            "phone": self._faker.phone_number,
            "address": self._faker.address,
            "street": self._faker.street_address,
            "city": self._faker.city,
            "state": self._faker.state,
            "country": self._faker.country,
            "zip": self._faker.postcode,
            "zipcode": self._faker.postcode,
            "url": self._faker.url,
            "domain": self._faker.domain_name,
            "ipv4": self._faker.ipv4,
            "ipv6": self._faker.ipv6,
            "mac": self._faker.mac_address,
            "uuid": self._faker.uuid4,
            "word": self._faker.word,
            "sentence": self._faker.sentence,
            "paragraph": self._faker.paragraph,
            "text": self._faker.text,
            "slug": self._faker.slug,
            "company": self._faker.company,
            "job": self._faker.job,
            "currency": self._faker.currency_code,
            "color": self._faker.color_name,
            "hex_color": self._faker.hex_color,
            "image_url": lambda: f"https://picsum.photos/seed/{self._faker.word()}/400/300",
            "lorem": self._faker.sentence,
            "iban": self._faker.iban,
            "ssn": self._faker.ssn,
            "license_plate": self._faker.license_plate,
            "user_agent": self._faker.user_agent,
            "mime_type": self._faker.mime_type,
            "file_name": self._faker.file_name,
            "file_extension": self._faker.file_extension,
        }
        fn = mapping.get(ftype)
        if fn:
            return fn()
        # Try direct faker attribute
        if hasattr(self._faker, ftype):
            return getattr(self._faker, ftype)()
        return self._faker.word()

    def _gen_int(self, faker_rule: Optional[Dict[str, Any]], schema: Dict[str, Any]) -> int:
        lo = int(schema.get("min") or (faker_rule or {}).get("min") or 0)
        hi = int(schema.get("max") or (faker_rule or {}).get("max") or 1000)
        return self._rng.randint(lo, hi)

    def _gen_float(self, faker_rule: Optional[Dict[str, Any]], schema: Dict[str, Any]) -> float:
        lo = float(schema.get("min") or (faker_rule or {}).get("min") or 0.0)
        hi = float(schema.get("max") or (faker_rule or {}).get("max") or 1000.0)
        val = self._rng.uniform(lo, hi)
        return round(val, 2)

    def _gen_date(self, faker_rule: Optional[Dict[str, Any]], schema: Dict[str, Any]) -> str:
        rule = faker_rule or {}
        fmt = rule.get("format") or schema.get("format") or "iso"
        start_str = rule.get("start") or schema.get("start")
        end_str = rule.get("end") or schema.get("end")

        start = datetime.fromisoformat(start_str) if start_str else datetime.now(timezone.utc) - timedelta(days=365)
        end = datetime.fromisoformat(end_str) if end_str else datetime.now(timezone.utc)

        delta = end - start
        secs = self._rng.randint(0, max(int(delta.total_seconds()), 1))
        dt = start + timedelta(seconds=secs)

        if fmt == "iso":
            return dt.isoformat()
        if fmt == "timestamp":
            return str(int(dt.timestamp()))
        return dt.strftime(fmt)

    def _gen_enum(self, schema: Dict[str, Any]) -> Any:
        values = schema.get("values") or []
        if not values:
            return None
        return self._rng.choice(values)

    def _gen_object(self, schema: Dict[str, Any], context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        props = schema.get("properties") or {}
        return {k: self.generate(v, context) for k, v in props.items()}

    def _gen_array(self, schema: Dict[str, Any], context: Optional[Dict[str, Any]]) -> List[Any]:
        lo = schema.get("min_items") or schema.get("minItems") or 1
        hi = schema.get("max_items") or schema.get("maxItems") or 5
        count = self._rng.randint(int(lo), int(hi))
        item_schema = schema.get("items") or {"type": "string"}
        return [self.generate(item_schema, context) for _ in range(count)]

    def _faker_call(self, rule: Dict[str, Any]) -> Any:
        ftype = rule.get("type", "word")
        return self._faker_string(ftype, rule)

    def _render_template(self, template: str, context: Dict[str, Any]) -> str:
        """Render a template like 'user_{{id}}' using context or fake data.
        
        Looks up keys in: path/query/body/header sections, then faker methods.
        """
        # Flatten nested context sections for easy lookup
        flat: Dict[str, Any] = {}
        for section in ("path", "query", "body", "header"):
            if isinstance(context.get(section), dict):
                flat.update(context[section])
        flat.update({k: v for k, v in context.items() if not isinstance(v, dict)})

        def replacer(m: re.Match) -> str:  # type: ignore[type-arg]
            key = m.group(1).strip()
            if key in flat:
                return str(flat[key])
            if hasattr(self._faker, key):
                return str(getattr(self._faker, key)())
            if key in ("int", "integer"):
                return str(self._rng.randint(1000, 9999))
            if key in ("float", "number"):
                return str(round(self._rng.uniform(0, 1000), 2))
            if key == "uuid":
                return str(self._faker.uuid4())
            return m.group(0)

        return re.sub(r"\{\{([^}]+)\}\}", replacer, template)
