"""Config loader: reads, validates, and watches JSON config files."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Callable, Optional

from .models import ServerConfig

# ANSI
_DIM = "\033[2m"
_RESET = "\033[0m"
_YELLOW = "\033[93m"
_RED = "\033[91m"
_GREEN = "\033[92m"


def load_config(path: str | Path) -> ServerConfig:
    """Load and validate a JSON config file into a ServerConfig model."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    if not p.suffix.lower() == ".json":
        raise ValueError(f"Config must be a .json file (got: {p.suffix})")

    with open(p, encoding="utf-8") as f:
        raw = json.load(f)

    try:
        return ServerConfig.model_validate(raw)
    except Exception as exc:
        raise ValueError(f"Invalid config schema:\n{exc}") from exc


class ConfigWatcher:
    """
    Watch a config file for changes and invoke a callback on reload.
    Uses polling (compatible with all OSes and Docker volumes).
    """

    def __init__(self, path: str | Path, callback: Callable[[ServerConfig], None], interval: float = 1.0):
        self.path = Path(path)
        self.callback = callback
        self.interval = interval
        self._last_mtime: Optional[float] = None
        self._running = False

    def _mtime(self) -> float:
        try:
            return self.path.stat().st_mtime
        except FileNotFoundError:
            return 0.0

    def start(self) -> None:
        """Start blocking watch loop (call from a thread)."""
        self._running = True
        self._last_mtime = self._mtime()
        ts = time.strftime("%H:%M:%S")
        print(f"{_DIM}[{ts}]{_RESET} {_GREEN}👀 Watching config for changes:{_RESET} {self.path}")

        while self._running:
            time.sleep(self.interval)
            mtime = self._mtime()
            if mtime != self._last_mtime:
                self._last_mtime = mtime
                ts = time.strftime("%H:%M:%S")
                print(f"\n{_DIM}[{ts}]{_RESET} {_YELLOW}🔄 Config changed – reloading…{_RESET}")
                try:
                    new_config = load_config(self.path)
                    self.callback(new_config)
                    ts = time.strftime("%H:%M:%S")
                    print(f"{_DIM}[{ts}]{_RESET} {_GREEN}✅ Config reloaded successfully{_RESET}\n")
                except Exception as exc:
                    ts = time.strftime("%H:%M:%S")
                    print(f"{_DIM}[{ts}]{_RESET} {_RED}❌ Reload failed: {exc}{_RESET}\n")

    def stop(self) -> None:
        self._running = False
