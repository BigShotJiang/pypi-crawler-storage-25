"""Tests for CorrectionService (RFC-0008 Step 8.1)."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.domain.mixins import DocStatus, SubmittableMixin, VersionedMixin
from framework_m_core.interfaces.audit import AuditLogProtocol
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.repository import RepositoryProtocol
from pydantic import ConfigDict

from framework_m.core.services.correction import CorrectionService


class Invoice(BaseDocType, SubmittableMixin):
    """Test invoice doctype for correction-flow tests."""

    customer: str = Field(description="Customer")
    amount: float = Field(default=0.0, description="Amount")


class VersionedInvoice(Invoice, VersionedMixin):
    """Versioned invoice doctype for in-place correction tests."""


class PlainDoc(BaseDocType):
    """Plain doc without SubmittableMixin for edge cases."""

    title: str = Field(default="Test")
    model_config = ConfigDict(extra="ignore")


class PlainVersionedDoc(PlainDoc, VersionedMixin):
    """Versioned plain doc for in-place edge cases."""


@pytest.fixture
def mock_repository() -> AsyncMock:
    """Repository mock implementing save semantics."""

    def _save(entity: BaseDocType, version: int | None = None) -> BaseDocType:
        _ = version
        return entity

    repo = AsyncMock(spec=RepositoryProtocol[BaseDocType])
    repo.save = AsyncMock(side_effect=_save)
    return repo


@pytest.fixture
def mock_audit_adapter() -> AsyncMock:
    """Audit adapter mock for correction-flow logging."""
    audit = AsyncMock(spec=AuditLogProtocol)
    audit.log = AsyncMock(return_value="audit-entry-001")
    return audit


@pytest.fixture
def service(
    mock_repository: AsyncMock,
    mock_audit_adapter: AsyncMock,
) -> CorrectionService:
    """CorrectionService under test."""
    return CorrectionService(
        repository=mock_repository,
        audit=mock_audit_adapter,
    )


@pytest.fixture
def user_context() -> UserContext:
    """User context fixture for audit metadata."""
    return UserContext(
        id="user-001",
        email="user-001@example.com",
        name="Test User",
        roles=["Employee"],
    )


@pytest.fixture
def submitted_invoice() -> Invoice:
    """Submitted invoice fixture for amend/restore tests."""
    return Invoice(
        name="INV-001",
        customer="Acme",
        amount=100.0,
        docstatus=DocStatus.SUBMITTED,
    )


@pytest.fixture
def versioned_submitted_invoice() -> VersionedInvoice:
    """Submitted versioned invoice fixture for in-place edit tests."""
    return VersionedInvoice(
        name="INV-001",
        customer="Acme",
        amount=100.0,
        docstatus=DocStatus.SUBMITTED,
    )


class TestCorrectionServiceAmend:
    """Amend flow tests."""

    @pytest.mark.asyncio
    async def test_amend_cancels_original_and_creates_new_draft(
        self,
        service: CorrectionService,
        mock_repository: AsyncMock,
        mock_audit_adapter: AsyncMock,
        submitted_invoice: Invoice,
        user_context: UserContext,
    ) -> None:
        result = await service.amend(
            doc=submitted_invoice,
            reason="Typo fix",
            user=user_context,
        )

        assert result.docstatus == DocStatus.DRAFT
        assert result.name == "INV-001-1"
        assert result.id != submitted_invoice.id

        assert mock_repository.save.await_count == 2

        cancelled_doc = mock_repository.save.await_args_list[0].args[0]
        amended_doc = mock_repository.save.await_args_list[1].args[0]

        assert cancelled_doc.docstatus == DocStatus.CANCELLED
        assert cancelled_doc.name == "INV-001"

        assert amended_doc.docstatus == DocStatus.DRAFT
        assert amended_doc.name == "INV-001-1"

        mock_audit_adapter.log.assert_awaited_once_with(
            user_id=user_context.id,
            action="amend",
            doctype="Invoice",
            document_id="INV-001",
            changes=None,
            metadata={"reason": "Typo fix"},
        )

    def test_amend_name_increments_correctly(self, service: CorrectionService) -> None:
        assert service._next_amended_name("INV-001") == "INV-001-1"
        assert service._next_amended_name("INV-001-1") == "INV-001-2"

    @pytest.mark.asyncio
    async def test_amend_raises_if_not_submitted(
        self,
        service: CorrectionService,
        mock_repository: AsyncMock,
        submitted_invoice: Invoice,
        user_context: UserContext,
    ) -> None:
        draft = submitted_invoice.model_copy(deep=True)
        draft.docstatus = DocStatus.DRAFT

        with pytest.raises(ValueError):
            await service.amend(
                doc=draft,
                reason="Need correction",
                user=user_context,
            )

        mock_repository.save.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_amend_audit_failure_propagates(
        self,
        service: CorrectionService,
        mock_audit_adapter: AsyncMock,
        submitted_invoice: Invoice,
        user_context: UserContext,
    ) -> None:
        mock_audit_adapter.log.side_effect = RuntimeError("audit write failed")

        with pytest.raises(RuntimeError, match="audit write failed"):
            await service.amend(
                doc=submitted_invoice,
                reason="Typo fix",
                user=user_context,
            )


class TestCorrectionServiceRestore:
    """Restore flow tests."""

    @pytest.mark.asyncio
    async def test_restore_cancels_original_and_creates_snapshot_doc(
        self,
        service: CorrectionService,
        mock_repository: AsyncMock,
        mock_audit_adapter: AsyncMock,
        submitted_invoice: Invoice,
        user_context: UserContext,
    ) -> None:
        snapshot_data: dict[str, Any] = {
            "customer": "Acme Restored",
            "amount": 120.0,
        }

        result = await service.restore(
            doc=submitted_invoice,
            snapshot_data=snapshot_data,
            reason="Rollback to prior snapshot",
            user=user_context,
        )

        assert result.name == "INV-001-1"
        assert result.docstatus == DocStatus.SUBMITTED

        assert mock_repository.save.await_count == 2

        cancelled_doc = mock_repository.save.await_args_list[0].args[0]
        restored_doc = mock_repository.save.await_args_list[1].args[0]

        assert cancelled_doc.docstatus == DocStatus.CANCELLED
        assert restored_doc.docstatus == DocStatus.SUBMITTED
        assert restored_doc.customer == "Acme Restored"

        mock_audit_adapter.log.assert_awaited_once_with(
            user_id=user_context.id,
            action="restore",
            doctype="Invoice",
            document_id="INV-001",
            changes=None,
            metadata={"reason": "Rollback to prior snapshot"},
        )

    @pytest.mark.asyncio
    async def test_restore_raises_if_not_submitted(
        self,
        service: CorrectionService,
        submitted_invoice: Invoice,
        user_context: UserContext,
    ) -> None:
        draft = submitted_invoice.model_copy(deep=True)
        draft.docstatus = DocStatus.DRAFT

        with pytest.raises(ValueError):
            await service.restore(
                doc=draft,
                snapshot_data={"customer": "Acme"},
                reason="Invalid state",
                user=user_context,
            )


class TestCorrectionServiceEdgeCases:
    """Coverage tests for defensive checks and edge cases."""

    def test_next_amended_name_unmatchable_pattern(
        self, service: CorrectionService
    ) -> None:
        """Cover branch where regex match is None."""
        assert service._next_amended_name("INV-001-A") == "INV-001-A-1"

    def test_ensure_submitted_without_docstatus(
        self, service: CorrectionService
    ) -> None:
        """Cover branch where doc has no docstatus attribute."""
        doc = PlainDoc(name="PLAIN-1")
        with pytest.raises(
            ValueError, match="Only submitted documents can be corrected"
        ):
            service._ensure_submitted(doc)

    def test_clone_with_updates_keep_id_and_no_docstatus(
        self, service: CorrectionService
    ) -> None:
        """Cover branches for drop_id=False and missing docstatus field."""
        doc = PlainDoc(name="PLAIN-1")
        cloned = service._clone_with_updates(
            source=doc,
            new_name="PLAIN-2",
            docstatus=DocStatus.DRAFT,
            drop_id=False,
        )
        assert cloned.id == doc.id
        assert cloned.name == "PLAIN-2"
        assert not hasattr(cloned, "docstatus")

    def test_document_ref_without_name(self, service: CorrectionService) -> None:
        """Cover branch where doc.name is None/empty."""
        doc = PlainDoc(name="")
        assert service._document_ref(doc) == str(doc.id)

    @pytest.mark.asyncio
    @patch.object(CorrectionService, "_ensure_submitted")
    async def test_amend_without_copied_docstatus(
        self,
        mock_ensure: Any,
        service: CorrectionService,
        mock_repository: AsyncMock,
        user_context: UserContext,
    ) -> None:
        """Cover hasattr(cancelled, 'docstatus') == False branch."""
        doc = PlainDoc(name="PLAIN-1")
        await service.amend(doc, "Test", user_context)
        cancelled_doc = mock_repository.save.await_args_list[0].args[0]
        assert not hasattr(cancelled_doc, "docstatus")

    @pytest.mark.asyncio
    @patch.object(CorrectionService, "_ensure_submitted")
    async def test_restore_without_copied_docstatus(
        self,
        mock_ensure: Any,
        service: CorrectionService,
        mock_repository: AsyncMock,
        user_context: UserContext,
    ) -> None:
        """Cover hasattr(cancelled, 'docstatus') == False branch."""
        doc = PlainDoc(name="PLAIN-1")
        await service.restore(doc, {"title": "Restored"}, "Test", user_context)
        cancelled_doc = mock_repository.save.await_args_list[0].args[0]
        assert not hasattr(cancelled_doc, "docstatus")

    @pytest.mark.asyncio
    @patch.object(CorrectionService, "_ensure_submitted")
    async def test_in_place_edit_without_copied_docstatus(
        self,
        mock_ensure: Any,
        service: CorrectionService,
        mock_repository: AsyncMock,
        user_context: UserContext,
    ) -> None:
        """Cover hasattr(editable, 'docstatus') == False branch."""
        doc = PlainVersionedDoc(name="PLAIN-1")
        await service.in_place_edit(doc, "Test", user_context)
        editable_doc = mock_repository.save.await_args_list[1].args[0]
        assert not hasattr(editable_doc, "docstatus")

    @pytest.mark.asyncio
    async def test_restore_raises_if_snapshot_empty(
        self,
        service: CorrectionService,
        submitted_invoice: Invoice,
        user_context: UserContext,
    ) -> None:
        with pytest.raises(ValueError, match="snapshot_data cannot be empty"):
            await service.restore(
                doc=submitted_invoice,
                snapshot_data={},
                reason="Missing snapshot",
                user=user_context,
            )


class TestCorrectionServiceInPlaceEdit:
    """In-place edit flow tests."""

    @pytest.mark.asyncio
    async def test_in_place_edit_copies_to_history_and_resets_to_draft(
        self,
        service: CorrectionService,
        mock_repository: AsyncMock,
        mock_audit_adapter: AsyncMock,
        versioned_submitted_invoice: VersionedInvoice,
        user_context: UserContext,
    ) -> None:
        result = await service.in_place_edit(
            doc=versioned_submitted_invoice,
            reason="Operational correction",
            user=user_context,
        )

        assert result.id == versioned_submitted_invoice.id
        assert result.name == versioned_submitted_invoice.name
        assert result.docstatus == DocStatus.DRAFT

        assert mock_repository.save.await_count == 2

        history_snapshot_doc = mock_repository.save.await_args_list[0].args[0]
        editable_doc = mock_repository.save.await_args_list[1].args[0]

        assert history_snapshot_doc.docstatus == DocStatus.SUBMITTED
        assert editable_doc.docstatus == DocStatus.DRAFT
        assert editable_doc.id == versioned_submitted_invoice.id
        assert editable_doc.name == versioned_submitted_invoice.name

        mock_audit_adapter.log.assert_awaited_once_with(
            user_id=user_context.id,
            action="in_place_edit",
            doctype="VersionedInvoice",
            document_id="INV-001",
            changes=None,
            metadata={"reason": "Operational correction"},
        )

    @pytest.mark.asyncio
    async def test_in_place_edit_raises_if_not_versioned(
        self,
        service: CorrectionService,
        submitted_invoice: Invoice,
        user_context: UserContext,
    ) -> None:
        with pytest.raises(ValueError, match="in_place_edit requires VersionedMixin"):
            await service.in_place_edit(
                doc=submitted_invoice,
                reason="Invalid flow",
                user=user_context,
            )

    @pytest.mark.asyncio
    async def test_in_place_edit_raises_if_not_submitted(
        self,
        service: CorrectionService,
        versioned_submitted_invoice: VersionedInvoice,
        user_context: UserContext,
    ) -> None:
        draft = versioned_submitted_invoice.model_copy(deep=True)
        draft.docstatus = DocStatus.DRAFT

        with pytest.raises(ValueError):
            await service.in_place_edit(
                doc=draft,
                reason="Invalid state",
                user=user_context,
            )
