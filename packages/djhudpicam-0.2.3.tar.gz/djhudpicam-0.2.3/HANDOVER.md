# djhudpicam v0.2.0 — Split Architecture Implementation Handover

**Date:** April 2026
**Status:** Implemented — ready for testing
**Previous version:** v0.1.9 (single-app, GUI+capture in one process)

---

## What Changed

djhudpicam has been split from a single GUI application into a split architecture with three entry points:

| Entry point | Runs on | Purpose |
|---|---|---|
| `djhudpicam` | Any (backward compat) | Standalone GUI — same as v0.1.x plus `--snapshot` and `--image` flags |
| `djhudpicam-node` | Pi Zero 2 W | Headless daemon — capture → composite → stream. Auto-starts on boot. |
| `djhudpicam-controller` | Windows | GUI controller — connects to node, live preview, region editor, push config |

---

## Architecture

```
WINDOWS PC                                    PI ZERO 2 W
─────────────────────────                      ─────────────────────────

djhudpicam-controller                          djhudpicam-node
┌─────────────────────┐                        ┌─────────────────────┐
│  tkinter GUI        │                        │  Headless daemon     │
│                     │                        │  (auto-starts)       │
│  Camera preview ◄───┼── ws://pi:8766/raw ────┼── Pi Camera capture  │
│  (live, local)      │   (dormant default)    │                      │
│                     │                        │  Region/warp engine  │
│  Region editor      │                        │  (from config.json)  │
│  Warp handles       │                        │                      │
│  Local composite    │                        │  HUD strip composite │
│  (instant preview)  │                        │      │               │
│                     │                        │      ▼               │
│  [Push Config] ─────┼── ws://pi:8767/ctrl ───┼──►  Config receiver  │
│  [Pull Config]      │   (command channel)    │      │               │
│  [Snapshot]         │                        │      ▼               │
│                     │                        │  WebSocket output ───┼──► djhud
│  Source selector:   │                        │  ws://pi:8765/stream │    (HUD strip)
│  Webcam | Pi Stream │                        │                      │
└─────────────────────┘                        └─────────────────────┘
```

---

## File Structure

```
src/djhudpicam/
├── __init__.py              # __version__ = "0.2.0"
├── __main__.py              # Standalone entry: --snapshot, --image, or GUI
├── app.py                   # Original standalone GUI (v0.1.x compat)
├── camera.py                # CameraCapture (picamera2 + OpenCV fallback)
├── region.py                # Region + RegionSet + composite()
├── output.py                # VpnStreamOutput, VirtualCamOutput, OutputManager
│
├── common/
│   ├── __init__.py
│   └── protocol.py          # Shared command/response JSON definitions
│
├── node/
│   ├── __init__.py          # Entry point: djhudpicam-node
│   ├── daemon.py            # Headless daemon — camera → composite → stream
│   ├── ctrl_server.py       # Command channel WebSocket server (port 8767)
│   └── raw_feed.py          # Raw camera feed WebSocket server (port 8766, dormant)
│
└── controller/
    ├── __init__.py           # Entry point: djhudpicam-controller
    ├── app.py                # GUI with source selector + Pi connection panel
    ├── ctrl_client.py        # Command channel WebSocket client
    └── stream_input.py       # Raw feed receiver (drop-in for CameraCapture)
```

---

## Key Design Decisions (Implemented)

1. **Single package, two entry points** — `pip install djhudpicam` with `[pi]`, `[controller]`, `[all]` extras. One version number, one repo.

2. **Node auto-starts streaming** — No controller needed to begin operation. Load config → start camera → stream HUD strip. Controller is optional, connect-when-needed.

3. **Raw feed dormant by default** — Port 8766 listens but doesn't send frames until controller sends `start_raw_feed`. Saves Pi CPU during normal streaming.

4. **Snapshot-first, continuous later** — Controller can request a single snapshot via the control channel (returned as base64 JPEG). Continuous raw feed available when needed for live preview.

5. **Local compositing on controller** — Controller receives raw camera frames, applies regions/warp locally using the same Region/RegionSet code, shows instant preview. Push Config sends the config to the Pi node for its own compositing.

6. **Backward compatible** — `djhudpicam` (no flags) still launches the standalone GUI, same as v0.1.x. Existing workflows unaffected.

---

## Command Protocol

JSON messages over WebSocket on port 8767 (`/ctrl`).

### Controller → Node

| Command | Purpose |
|---|---|
| `get_status` | Request node status (camera, streaming, CPU, memory) |
| `get_config` | Fetch current config from node |
| `push_config` | Push full config (regions, resolution, canvas size) — also saves to disk |
| `set_resolution` | Change camera resolution + FPS |
| `start_raw_feed` | Start streaming raw camera frames on port 8766 |
| `stop_raw_feed` | Stop raw feed |
| `snapshot` | Request single frame (returned as base64 JPEG) |

### Node → Controller

| Response type | Contents |
|---|---|
| `ack` | Command acknowledged with status |
| `error` | Command failed with message |
| `status` | Camera state, streaming state, resolution, FPS, region count, CPU%, memory |
| `config` | Full config dict |
| `snapshot` | Base64-encoded JPEG frame |

---

## Installation

### Pi Zero 2 W (node only)

```bash
pip install "djhudpicam[pi]"

# Install systemd service
sudo cp djhudpicam-node.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable djhudpicam-node
sudo systemctl start djhudpicam-node
```

### Windows (controller)

```bash
pip install "djhudpicam[controller]"
djhudpicam-controller
```

### Standalone (backward compatible)

```bash
pip install djhudpicam
djhudpicam                           # GUI mode
djhudpicam --snapshot /tmp/frame.jpg # Grab one frame, save, exit
djhudpicam --image /tmp/frame.jpg   # GUI with static image for editing
```

---

## Testing Checklist

### Phase 0 — Quick wins (test on any machine)

- [ ] `djhudpicam --snapshot /tmp/test.jpg` captures a frame and exits
- [ ] `djhudpicam --image /tmp/test.jpg` opens GUI with the static image
- [ ] Regions can be created and edited on the static image
- [ ] Config saves correctly from static image mode

### Phase 1 — Node (test on Pi)

- [ ] `djhudpicam-node` starts, loads config, starts camera
- [ ] HUD strip streams to djhud on ws://10.66.66.12:8765/stream
- [ ] Streaming starts automatically (no controller needed)
- [ ] `djhudpicam-node --port 9000` uses custom port
- [ ] Systemd service starts on boot, restarts on failure

### Phase 2 — Controller (test on Windows → Pi)

- [ ] `djhudpicam-controller` launches GUI
- [ ] Source selector: "webcam" works (local camera, same as v0.1.x)
- [ ] Source selector: "pi" + Connect → connects to Pi node
- [ ] Snapshot button → receives single frame, displays in preview
- [ ] Start Preview → receives continuous raw feed at ~5 FPS
- [ ] Regions can be created/edited on Pi camera preview
- [ ] Push Config → sends config to Pi, node applies it, strip updates
- [ ] Pull Config → fetches config from Pi, applies locally
- [ ] Disconnect → reverts to webcam source

### Phase 3 — End-to-end

- [ ] Pi boots → WireGuard connects → node starts → streams to djhud
- [ ] Controller connects → snapshots → edits regions → pushes config
- [ ] HUD strip in djhud updates with new region layout
- [ ] Controller disconnects → node continues streaming autonomously

---

## Modules Unchanged from v0.1.9

These files are identical — no modifications needed:

- `camera.py` — CameraCapture with double-buffered frame swap
- `region.py` — Region + RegionSet with pre-allocated strip buffer
- `output.py` — VpnStreamOutput, VirtualCamOutput, OutputManager

---

## Known Limitations / Future Work

1. **No authentication** on command channel — fine on private WireGuard VPN
2. **No auto-discovery** — controller requires manual Pi IP entry
3. **Single node only** — multi-Pi support planned for Phase 4
4. **Config sync** — no conflict detection if config edited manually on Pi while controller is connected
5. **Raw feed bandwidth** — 640×480 JPEG at 5 FPS ≈ 150 KB/s over VPN, should be fine

---

## Version Bump Workflow

Both files must be updated before building:

```
src/djhudpicam/__init__.py   →  __version__ = "0.2.0"
pyproject.toml                →  version = "0.2.0"
```

Build and upload:

```bash
python -m build
twine upload dist/*
```
