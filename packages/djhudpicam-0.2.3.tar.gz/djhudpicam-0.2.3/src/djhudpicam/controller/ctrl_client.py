"""
controller/ctrl_client.py — Command channel WebSocket client.

Connects to the node's control channel (ws://pi:8767/ctrl), sends
JSON commands, and receives responses. Runs its own asyncio event
loop in a background thread.
"""

from __future__ import annotations
import asyncio
import base64
import json
import logging
import threading
from typing import Callable, Optional

import numpy as np

from ..common.protocol import (
    DEFAULT_CTRL_PORT,
    cmd_get_status, cmd_get_config, cmd_push_config,
    cmd_set_resolution, cmd_start_raw_feed, cmd_stop_raw_feed, cmd_snapshot,
    cmd_set_camera_controls,
    parse_message,
)

log = logging.getLogger(__name__)


class CtrlClient:
    """
    WebSocket client for the node control channel.

    Runs in a background thread. Commands are fire-and-response:
    call a method, it sends the command and returns the parsed response
    dict (or None on error/timeout).

    Usage:
        ctrl = CtrlClient("10.66.66.12")
        ctrl.connect()
        status = ctrl.get_status()
        ctrl.push_config({...})
        ctrl.disconnect()
    """

    def __init__(self, host: str, port: int = DEFAULT_CTRL_PORT, timeout: float = 5.0):
        self.host = host
        self.port = port
        self.timeout = timeout

        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._ws = None
        self._connected = False
        self._running = False
        self._error: Optional[str] = None

        # Pending response: simple single-response model
        self._response_event: Optional[asyncio.Event] = None
        self._response_data: Optional[dict] = None

        # Callback for unsolicited status updates
        self.on_status: Optional[Callable[[dict], None]] = None

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def last_error(self) -> Optional[str]:
        return self._error

    # ------------------------------------------------------------------
    # Connect / disconnect
    # ------------------------------------------------------------------

    def connect(self):
        """Start background thread and connect to node."""
        if self._running:
            return
        self._running = True
        self._error = None
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def disconnect(self):
        """Disconnect and stop background thread."""
        self._running = False
        self._connected = False
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None

    # ------------------------------------------------------------------
    # Commands (blocking, called from GUI thread)
    # ------------------------------------------------------------------

    def get_status(self) -> Optional[dict]:
        return self._send_and_wait(cmd_get_status())

    def get_config(self) -> Optional[dict]:
        return self._send_and_wait(cmd_get_config())

    def push_config(self, config: dict) -> Optional[dict]:
        return self._send_and_wait(cmd_push_config(config))

    def set_resolution(self, width: int, height: int, fps: int) -> Optional[dict]:
        return self._send_and_wait(cmd_set_resolution(width, height, fps))

    def start_raw_feed(self, fps: int = 5) -> Optional[dict]:
        return self._send_and_wait(cmd_start_raw_feed(fps))

    def stop_raw_feed(self) -> Optional[dict]:
        return self._send_and_wait(cmd_stop_raw_feed())

    def set_camera_controls(self, controls: dict) -> Optional[dict]:
        return self._send_and_wait(cmd_set_camera_controls(controls))

    def request_snapshot(self) -> Optional[np.ndarray]:
        """Request a single frame snapshot. Returns BGR numpy array or None."""
        resp = self._send_and_wait(cmd_snapshot())
        if resp and resp.get("type") == "snapshot":
            b64 = resp.get("frame", "")
            try:
                import cv2
                jpeg_bytes = base64.b64decode(b64)
                arr = np.frombuffer(jpeg_bytes, dtype=np.uint8)
                return cv2.imdecode(arr, cv2.IMREAD_COLOR)
            except Exception as e:
                log.error("Failed to decode snapshot: %s", e)
        return None

    # ------------------------------------------------------------------
    # Internal send/receive
    # ------------------------------------------------------------------

    def _send_and_wait(self, message: str) -> Optional[dict]:
        """Send a command and wait for the response (with timeout)."""
        if not self._connected or not self._loop:
            self._error = "Not connected"
            return None

        future = asyncio.run_coroutine_threadsafe(
            self._async_send_and_wait(message), self._loop
        )
        try:
            return future.result(timeout=self.timeout)
        except Exception as e:
            self._error = str(e)
            log.error("Command failed: %s", e)
            return None

    async def _async_send_and_wait(self, message: str) -> Optional[dict]:
        """Send message and wait for next response."""
        if self._ws is None:
            return None
        self._response_event = asyncio.Event()
        self._response_data = None
        try:
            await self._ws.send_str(message)
            await asyncio.wait_for(self._response_event.wait(), timeout=self.timeout)
            return self._response_data
        except asyncio.TimeoutError:
            log.warning("Command timed out")
            return None
        finally:
            self._response_event = None

    # ------------------------------------------------------------------
    # Background event loop
    # ------------------------------------------------------------------

    def _run_loop(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._connect_loop())
        except Exception as e:
            self._error = str(e)
            log.error("Control client error: %s", e)
        finally:
            self._loop.close()
            self._connected = False

    async def _connect_loop(self):
        """Connect with auto-reconnect."""
        try:
            import aiohttp
        except ImportError:
            self._error = "aiohttp not installed"
            return

        url = f"ws://{self.host}:{self.port}/ctrl"

        while self._running:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(url, heartbeat=10) as ws:
                        self._ws = ws
                        self._connected = True
                        self._error = None
                        log.info("Connected to control channel: %s", url)

                        async for msg in ws:
                            if not self._running:
                                break
                            if msg.type == aiohttp.WSMsgType.TEXT:
                                data = parse_message(msg.data)
                                if data:
                                    self._handle_response(data)
                            elif msg.type in (aiohttp.WSMsgType.CLOSE,
                                              aiohttp.WSMsgType.ERROR):
                                break
            except Exception as e:
                self._connected = False
                self._ws = None
                self._error = str(e)
                log.warning("Control channel connection lost: %s — retrying in 2s", e)
                # Unblock any waiting command
                if self._response_event:
                    self._response_event.set()
                if self._running:
                    await asyncio.sleep(2)

    def _handle_response(self, data: dict):
        """Handle a response from the node."""
        # If we're waiting for a response, deliver it
        if self._response_event and not self._response_event.is_set():
            self._response_data = data
            self._response_event.set()
        else:
            # Unsolicited message (e.g. status broadcast)
            if self.on_status and data.get("type") == "status":
                self.on_status(data)
