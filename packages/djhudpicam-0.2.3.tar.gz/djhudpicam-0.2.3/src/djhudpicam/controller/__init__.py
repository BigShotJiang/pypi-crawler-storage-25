"""
djhudpicam.controller — GUI controller for djhudpicam.

Entry point: djhudpicam (default)
"""

import logging


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    from .app import App
    app = App()
    app.mainloop()
