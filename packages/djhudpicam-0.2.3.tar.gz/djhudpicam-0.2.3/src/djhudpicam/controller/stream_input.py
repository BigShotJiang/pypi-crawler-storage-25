"""
controller/stream_input.py — WebSocket frame receiver.

Connects to the node's raw camera feed (ws://pi:8766/raw) and exposes
get_frame() with the same interface as CameraCapture, making it a
drop-in source swap for the GUI.

Also supports single-frame snapshot via the control channel.
"""

from __future__ import annotations
import asyncio
import io
import logging
import threading
import time
from typing import Optional

import numpy as np

log = logging.getLogger(__name__)


class StreamInput:
    """
    Receives JPEG frames from a djhudpicam-node raw feed WebSocket.

    Same public API as CameraCapture:
        .start()       → begins receiving
        .stop()        → disconnects
        .get_frame()   → returns latest BGR numpy array or None

    Usage:
        source = StreamInput("10.66.66.12", raw_port=8766)
        source.start()
        frame = source.get_frame()
        source.stop()
    """

    def __init__(self, host: str, raw_port: int = 8766):
        self.host = host
        self.raw_port = raw_port
        self._read_frame: Optional[np.ndarray] = None
        self._lock = threading.Lock()
        self._running = False
        self._connected = False
        self._thread: Optional[threading.Thread] = None
        self._error: Optional[str] = None

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def last_error(self) -> Optional[str]:
        return self._error

    # ------------------------------------------------------------------
    # Public API (matches CameraCapture interface)
    # ------------------------------------------------------------------

    def start(self) -> str:
        """Start receiving frames. Returns backend name."""
        if self._running:
            return "stream"
        self._running = True
        self._error = None
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        return "stream"

    def stop(self):
        """Disconnect and stop receiving."""
        self._running = False
        self._connected = False
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None

    def get_frame(self) -> Optional[np.ndarray]:
        """Return latest BGR frame as numpy array, or None if not ready."""
        with self._lock:
            return self._read_frame

    # ------------------------------------------------------------------
    # Receive loop (runs in a thread with its own event loop)
    # ------------------------------------------------------------------

    def _run_loop(self):
        """Run asyncio event loop for WebSocket connection."""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(self._receive_loop())
        except Exception as e:
            self._error = str(e)
            log.error("Stream input error: %s", e)
        finally:
            loop.close()
            self._connected = False

    async def _receive_loop(self):
        """Connect to raw feed and receive JPEG frames."""
        try:
            import aiohttp
        except ImportError:
            self._error = "aiohttp not installed"
            log.error("aiohttp required for stream input")
            return

        url = f"ws://{self.host}:{self.raw_port}/raw"
        log.info("Connecting to raw feed: %s", url)

        while self._running:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(url, heartbeat=10) as ws:
                        self._connected = True
                        self._error = None
                        log.info("Connected to raw feed: %s", url)

                        async for msg in ws:
                            if not self._running:
                                break
                            if msg.type == aiohttp.WSMsgType.BINARY:
                                frame = self._decode_jpeg(msg.data)
                                if frame is not None:
                                    with self._lock:
                                        self._read_frame = frame
                            elif msg.type in (aiohttp.WSMsgType.CLOSE,
                                              aiohttp.WSMsgType.ERROR):
                                break
            except Exception as e:
                self._connected = False
                self._error = str(e)
                log.warning("Raw feed connection lost: %s — retrying in 2s", e)
                if self._running:
                    await asyncio.sleep(2)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _decode_jpeg(data: bytes) -> Optional[np.ndarray]:
        """Decode JPEG bytes to BGR numpy array."""
        try:
            import cv2
            arr = np.frombuffer(data, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            return frame
        except Exception:
            return None
