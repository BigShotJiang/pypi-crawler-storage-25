"""
node/daemon.py — Headless djhudpicam node daemon.

Core loop: camera capture → region composite → push to outputs.
Auto-starts HUD strip streaming on launch (no controller needed).
Controller is optional — connects to configure regions/warp.

Runs a single aiohttp Application hosting:
  - /stream  (port 8765) — HUD strip WebSocket (→ djhud)
  - /raw     (port 8766) — Raw camera feed WebSocket (→ controller, dormant)
  - /ctrl    (port 8767) — Command channel WebSocket (↔ controller)
"""

from __future__ import annotations
import asyncio
import json
import logging
import os
import signal
import threading
import time
from typing import Optional

import numpy as np

from ..camera import CameraCapture
from ..region import Region, RegionSet
from ..output import OutputManager, VpnStreamOutput
from ..common.protocol import DEFAULT_STREAM_PORT, DEFAULT_RAW_PORT, DEFAULT_CTRL_PORT
from .ctrl_server import CtrlServer
from .raw_feed import RawFeedServer

log = logging.getLogger(__name__)

CONFIG_FILE = os.path.expanduser("~/.djhudpicam_config.json")


class Daemon:
    """
    Headless djhudpicam node.

    Captures frames from the Pi camera, composites regions into a HUD strip,
    and streams the strip over WebSocket. Fully autonomous once started —
    the controller is only needed for setup.
    """

    def __init__(
        self,
        config_path: str = CONFIG_FILE,
        stream_port: int = DEFAULT_STREAM_PORT,
        ctrl_port: int = DEFAULT_CTRL_PORT,
        raw_port: int = DEFAULT_RAW_PORT,
    ):
        self.config_path = config_path
        self.stream_port = stream_port
        self.ctrl_port = ctrl_port
        self.raw_port = raw_port

        # Core components (same as app.py uses)
        self.camera = CameraCapture(width=640, height=480, fps=15)
        self.regions = RegionSet()
        self.outputs = OutputManager()

        # Servers
        self.ctrl_server: Optional[CtrlServer] = None
        self.raw_feed: Optional[RawFeedServer] = None

        # State
        self.camera_running = False
        self.streaming = False
        self._running = False
        self._capture_thread: Optional[threading.Thread] = None

        # Canvas size (from config)
        self._canvas_w = 640
        self._canvas_h = 100

    # ------------------------------------------------------------------
    # Config
    # ------------------------------------------------------------------

    def load_config(self):
        """Load config from JSON file. Safe to call if file doesn't exist."""
        if not os.path.exists(self.config_path):
            log.info("No config file found at %s — using defaults", self.config_path)
            return

        try:
            with open(self.config_path) as f:
                data = json.load(f)
            self._apply_config_data(data)
            log.info("Config loaded from %s (%d regions)",
                     self.config_path, len(self.regions.regions))
        except Exception as e:
            log.error("Failed to load config: %s", e)

    def save_config(self):
        """Save current config to JSON file."""
        data = self.get_config_dict()
        try:
            with open(self.config_path, "w") as f:
                json.dump(data, f, indent=2)
            log.info("Config saved to %s", self.config_path)
        except Exception as e:
            log.error("Failed to save config: %s", e)

    def get_config_dict(self) -> dict:
        """Return current config as a dict (same format as the JSON file)."""
        return {
            "resolution": f"{self.camera.width}x{self.camera.height}",
            "fps": str(self.camera.fps),
            "vpn_port": str(self.stream_port),
            "canvas_w": self._canvas_w,
            "canvas_h": self._canvas_h,
            "regions": [r.to_dict() for r in self.regions.regions],
        }

    def apply_config(self, config: dict):
        """Apply config from controller push. Also saves to disk."""
        self._apply_config_data(config)
        self.save_config()
        log.info("Config applied from controller (%d regions)",
                 len(self.regions.regions))

    def _apply_config_data(self, data: dict):
        """Parse config dict into internal state."""
        # Resolution
        res = data.get("resolution", "640x480")
        try:
            parts = res.replace("\u00d7", "x").split("x")
            w, h = int(parts[0]), int(parts[1])
            if w != self.camera.width or h != self.camera.height:
                self.camera.set_resolution(w, h)
        except (ValueError, IndexError):
            pass

        # FPS
        try:
            fps = int(data.get("fps", "15"))
            self.camera.fps = fps
        except ValueError:
            pass

        # Canvas size
        self._canvas_w = data.get("canvas_w", 640)
        self._canvas_h = data.get("canvas_h", 100)

        # Regions
        regions_data = data.get("regions", [])
        self.regions.regions = [Region.from_dict(d) for d in regions_data]

    # ------------------------------------------------------------------
    # Capture loop (runs in a thread)
    # ------------------------------------------------------------------

    def _start_camera(self):
        """Start the camera and capture thread."""
        if self.camera_running:
            return
        backend = self.camera.start()
        self.camera_running = True
        self._capture_thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._capture_thread.start()
        log.info("Camera started (%s) @ %dx%d %dfps",
                 backend, self.camera.width, self.camera.height, self.camera.fps)

    def _stop_camera(self):
        """Stop the camera and capture thread."""
        self.camera_running = False
        if self._capture_thread:
            self._capture_thread.join(timeout=3)
            self._capture_thread = None
        self.camera.stop()
        log.info("Camera stopped")

    def _capture_loop(self):
        """Grab frames, composite, push to outputs. Runs at camera FPS."""
        interval = 1.0 / max(1, self.camera.fps)
        while self.camera_running and self._running:
            t0 = time.monotonic()

            frame = self.camera.get_frame()
            if frame is not None:
                cw = max(100, self._canvas_w)
                ch = max(10, self._canvas_h)
                strip = self.regions.composite(frame, cw, ch)
                self.outputs.push_frame(strip)

            elapsed = time.monotonic() - t0
            sleep = interval - elapsed
            if sleep > 0:
                time.sleep(sleep)

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------

    def _start_streaming(self):
        """Start the HUD strip WebSocket stream."""
        if self.streaming:
            return
        self.outputs.vpn = VpnStreamOutput(port=self.stream_port)
        self.outputs.vpn.start()
        self.streaming = True
        log.info("HUD strip stream started on port %d", self.stream_port)

    def _stop_streaming(self):
        """Stop the HUD strip WebSocket stream."""
        if not self.streaming:
            return
        if self.outputs.vpn:
            self.outputs.vpn.stop()
            self.outputs.vpn = None
        self.streaming = False
        log.info("HUD strip stream stopped")

    # ------------------------------------------------------------------
    # Main entry — run the daemon
    # ------------------------------------------------------------------

    def run(self):
        """
        Start everything and run forever.

        Sequence:
          1. Load config
          2. Start camera
          3. Start HUD strip stream (autonomous — no controller needed)
          4. Start aiohttp servers (ctrl + raw feed)
          5. Block until shutdown signal
        """
        self._running = True

        # 1. Load config
        self.load_config()

        # 2. Start camera
        self._start_camera()

        # 3. Start HUD strip stream immediately
        self._start_streaming()

        # 4. Run async servers
        try:
            asyncio.run(self._run_servers())
        except KeyboardInterrupt:
            pass
        finally:
            self._shutdown()

    async def _run_servers(self):
        """Start aiohttp servers for control and raw feed channels."""
        from aiohttp import web

        # Control channel server (port 8767)
        self.ctrl_server = CtrlServer(self)
        ctrl_app = web.Application()
        self.ctrl_server.add_routes(ctrl_app)

        # Raw feed server (port 8766) — dormant until controller requests
        self.raw_feed = RawFeedServer()
        self.raw_feed.set_frame_getter(self.camera.get_frame)
        self.raw_feed.add_routes(ctrl_app)  # share the app for simplicity?

        # Actually — raw feed on its own port so we can have /raw on 8766
        raw_app = web.Application()
        self.raw_feed.add_routes(raw_app)

        # Start ctrl server
        ctrl_runner = web.AppRunner(ctrl_app)
        await ctrl_runner.setup()
        ctrl_site = web.TCPSite(ctrl_runner, "0.0.0.0", self.ctrl_port)
        await ctrl_site.start()
        log.info("Control channel listening on port %d", self.ctrl_port)

        # Start raw feed server
        raw_runner = web.AppRunner(raw_app)
        await raw_runner.setup()
        raw_site = web.TCPSite(raw_runner, "0.0.0.0", self.raw_port)
        await raw_site.start()
        log.info("Raw feed server listening on port %d (dormant)", self.raw_port)

        # Wait for shutdown
        stop_event = asyncio.Event()

        def _signal_handler():
            stop_event.set()

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, _signal_handler)
            except NotImplementedError:
                # Windows doesn't support add_signal_handler
                pass

        await stop_event.wait()

        # Cleanup
        await ctrl_runner.cleanup()
        await raw_runner.cleanup()

    def _shutdown(self):
        """Clean shutdown of all subsystems."""
        log.info("Shutting down...")
        self._running = False
        self._stop_streaming()
        self._stop_camera()
        self.outputs.stop_all()
        log.info("Shutdown complete")
