"""
node/ctrl_server.py — Command channel WebSocket server.

Listens on the control port (default 8767) for JSON commands from the
controller. Dispatches commands to the daemon's camera, region, and
output subsystems. Returns JSON ack/error/status responses.

Runs as an aiohttp route added to the node's shared web application.
"""

from __future__ import annotations
import base64
import logging
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from aiohttp import web
    from .daemon import Daemon

from ..common.protocol import (
    parse_message, resp_ack, resp_error, resp_status, resp_config, resp_snapshot,
    cmd_set_camera_controls,
)

log = logging.getLogger(__name__)


class CtrlServer:
    """
    Command channel WebSocket server.

    Not a standalone server — its routes are added to the node's shared
    aiohttp Application via add_routes().
    """

    def __init__(self, daemon: "Daemon"):
        self._daemon = daemon
        self._clients: set = set()

    def add_routes(self, app: "web.Application"):
        app.router.add_get("/ctrl", self._ws_handler)

    @property
    def client_count(self) -> int:
        return len(self._clients)

    # ------------------------------------------------------------------
    # WebSocket handler
    # ------------------------------------------------------------------

    async def _ws_handler(self, request: "web.Request"):
        from aiohttp import web, WSMsgType
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self._clients.add(ws)
        log.info("Controller connected: %s", request.remote)

        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    response = self._handle_command(msg.data)
                    if response:
                        await ws.send_str(response)
                elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                    break
        finally:
            self._clients.discard(ws)
            log.info("Controller disconnected (remaining: %d)", len(self._clients))

        return ws

    # ------------------------------------------------------------------
    # Command dispatch
    # ------------------------------------------------------------------

    def _handle_command(self, raw: str) -> Optional[str]:
        msg = parse_message(raw)
        if msg is None:
            return resp_error("unknown", "Invalid JSON")

        cmd = msg.get("cmd", "")
        log.info("Command received: %s", cmd)

        try:
            if cmd == "get_status":
                return self._do_get_status()
            elif cmd == "get_config":
                return self._do_get_config()
            elif cmd == "push_config":
                return self._do_push_config(msg.get("config", {}))
            elif cmd == "set_resolution":
                return self._do_set_resolution(
                    msg.get("width", 640),
                    msg.get("height", 480),
                    msg.get("fps", 15),
                )
            elif cmd == "start_raw_feed":
                return self._do_start_raw_feed(msg.get("fps", 5))
            elif cmd == "stop_raw_feed":
                return self._do_stop_raw_feed()
            elif cmd == "snapshot":
                return self._do_snapshot()
            elif cmd == "set_camera_controls":
                return self._do_set_camera_controls(msg.get("controls", {}))
            else:
                return resp_error(cmd, f"Unknown command: {cmd}")
        except Exception as e:
            log.exception("Error handling command %s", cmd)
            return resp_error(cmd, str(e))

    # ------------------------------------------------------------------
    # Command handlers
    # ------------------------------------------------------------------

    def _do_get_status(self) -> str:
        d = self._daemon
        res = f"{d.camera.width}x{d.camera.height}"
        stream_clients = d.outputs.vpn._clients if d.outputs.vpn else set()

        # CPU and memory (best-effort)
        cpu = 0.0
        mem = 0.0
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=0)
            mem = psutil.Process().memory_info().rss / (1024 * 1024)
        except ImportError:
            pass

        return resp_status(
            camera_running=d.camera_running,
            streaming=d.streaming,
            output_type="vpn" if d.outputs.vpn else "none",
            resolution=res,
            fps=d.camera.fps,
            regions_count=len(d.regions.regions),
            clients_connected=len(stream_clients),
            cpu_percent=cpu,
            memory_mb=mem,
            raw_feed_active=d.raw_feed.active if d.raw_feed else False,
        )

    def _do_get_config(self) -> str:
        return resp_config(self._daemon.get_config_dict())

    def _do_push_config(self, config: dict) -> str:
        try:
            self._daemon.apply_config(config)
            return resp_ack("push_config")
        except Exception as e:
            return resp_error("push_config", str(e))

    def _do_set_resolution(self, width: int, height: int, fps: int) -> str:
        self._daemon.camera.set_resolution(width, height)
        self._daemon.camera.fps = fps
        return resp_ack("set_resolution")

    def _do_start_raw_feed(self, fps: float) -> str:
        if self._daemon.raw_feed:
            self._daemon.raw_feed.start_feed(fps)
            return resp_ack("start_raw_feed")
        return resp_error("start_raw_feed", "Raw feed server not available")

    def _do_stop_raw_feed(self) -> str:
        if self._daemon.raw_feed:
            self._daemon.raw_feed.stop_feed()
            return resp_ack("stop_raw_feed")
        return resp_error("stop_raw_feed", "Raw feed server not available")

    def _do_set_camera_controls(self, controls: dict) -> str:
        try:
            self._daemon.camera.set_controls(controls)
            return resp_ack("set_camera_controls")
        except Exception as e:
            return resp_error("set_camera_controls", str(e))

    def _do_snapshot(self) -> str:
        if self._daemon.raw_feed:
            jpeg = self._daemon.raw_feed.get_snapshot_jpeg()
            if jpeg:
                b64 = base64.b64encode(jpeg).decode("ascii")
                return resp_snapshot(b64)
            return resp_error("snapshot", "No frame available")
        return resp_error("snapshot", "Raw feed server not available")
