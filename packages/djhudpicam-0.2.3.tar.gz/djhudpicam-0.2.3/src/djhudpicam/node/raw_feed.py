"""
node/raw_feed.py — Raw camera feed WebSocket server.

Serves full camera JPEG frames (not composited strip) to the controller
for region setup and preview. Dormant by default — only starts sending
frames when a controller connects and sends 'start_raw_feed' via the
control channel.

Also supports single-frame 'snapshot' requests (returned as base64 JPEG
on the control channel, not here).

Runs as an aiohttp route added to the node's shared web application.
"""

from __future__ import annotations
import asyncio
import logging
import numpy as np
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from aiohttp import web

log = logging.getLogger(__name__)


class RawFeedServer:
    """
    Manages raw camera frame streaming to connected controllers.

    Not a standalone server — its routes are added to the node's shared
    aiohttp Application via add_routes().
    """

    def __init__(self):
        self._clients: set = set()
        self._active = False
        self._fps: float = 5.0
        self._task: Optional[asyncio.Task] = None
        self._frame_getter = None   # callable returning np.ndarray | None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def set_frame_getter(self, getter):
        """Set the callable that returns the latest raw camera frame (BGR numpy)."""
        self._frame_getter = getter

    def add_routes(self, app: "web.Application"):
        app.router.add_get("/raw", self._ws_handler)

    @property
    def active(self) -> bool:
        return self._active

    @property
    def client_count(self) -> int:
        return len(self._clients)

    # ------------------------------------------------------------------
    # Control interface (called from ctrl_server command handlers)
    # ------------------------------------------------------------------

    def start_feed(self, fps: float = 5.0):
        """Start streaming raw frames to connected clients."""
        self._fps = max(1, min(30, fps))
        if self._active:
            log.info("Raw feed FPS changed to %.1f", self._fps)
            return
        self._active = True
        if self._loop and self._clients:
            self._ensure_broadcast_task()
        log.info("Raw feed started @ %.1f FPS", self._fps)

    def stop_feed(self):
        """Stop streaming raw frames."""
        self._active = False
        if self._task and not self._task.done():
            self._task.cancel()
            self._task = None
        log.info("Raw feed stopped")

    def get_snapshot_jpeg(self) -> Optional[bytes]:
        """Grab a single frame and return as JPEG bytes, or None."""
        if self._frame_getter is None:
            return None
        frame = self._frame_getter()
        if frame is None:
            return None
        return self._encode_jpeg(frame)

    # ------------------------------------------------------------------
    # WebSocket handler
    # ------------------------------------------------------------------

    async def _ws_handler(self, request: "web.Request"):
        from aiohttp import web, WSMsgType
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self._clients.add(ws)
        self._loop = asyncio.get_running_loop()
        log.info("Raw feed client connected: %s (total: %d)",
                 request.remote, len(self._clients))

        if self._active:
            self._ensure_broadcast_task()

        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    # Clients don't send data on this channel, but handle close
                    pass
                elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                    break
        finally:
            self._clients.discard(ws)
            log.info("Raw feed client disconnected (remaining: %d)", len(self._clients))
            if not self._clients:
                self.stop_feed()

        return ws

    # ------------------------------------------------------------------
    # Broadcast loop
    # ------------------------------------------------------------------

    def _ensure_broadcast_task(self):
        if self._task is None or self._task.done():
            self._task = asyncio.ensure_future(self._broadcast_loop())

    async def _broadcast_loop(self):
        """Send JPEG frames to all connected clients at configured FPS."""
        log.info("Raw feed broadcast loop started")
        try:
            while self._active and self._clients:
                interval = 1.0 / self._fps
                if self._frame_getter is None:
                    await asyncio.sleep(interval)
                    continue

                frame = self._frame_getter()
                if frame is None:
                    await asyncio.sleep(interval)
                    continue

                jpeg = self._encode_jpeg(frame)
                if not jpeg:
                    await asyncio.sleep(interval)
                    continue

                dead = set()
                for ws in list(self._clients):
                    try:
                        await ws.send_bytes(jpeg)
                    except Exception:
                        dead.add(ws)
                self._clients -= dead

                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            pass
        log.info("Raw feed broadcast loop ended")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _encode_jpeg(frame: np.ndarray, quality: int = 80) -> bytes:
        try:
            import cv2
            ret, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
            return bytes(buf) if ret else b""
        except ImportError:
            return b""
