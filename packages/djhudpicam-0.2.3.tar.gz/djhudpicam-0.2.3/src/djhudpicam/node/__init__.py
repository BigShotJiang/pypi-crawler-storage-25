"""
djhudpicam.node — Headless Pi camera node.

Entry point: djhudpicam-node
"""

import argparse
import logging

from ..common.protocol import DEFAULT_STREAM_PORT, DEFAULT_CTRL_PORT, DEFAULT_RAW_PORT


def main():
    parser = argparse.ArgumentParser(
        prog="djhudpicam-node",
        description="DJ HUD PiCam headless node — capture, composite, stream.",
    )
    parser.add_argument(
        "--port", type=int, default=DEFAULT_STREAM_PORT,
        help=f"HUD strip WebSocket port (default: {DEFAULT_STREAM_PORT})",
    )
    parser.add_argument(
        "--ctrl-port", type=int, default=DEFAULT_CTRL_PORT,
        help=f"Control channel WebSocket port (default: {DEFAULT_CTRL_PORT})",
    )
    parser.add_argument(
        "--raw-port", type=int, default=DEFAULT_RAW_PORT,
        help=f"Raw camera feed WebSocket port (default: {DEFAULT_RAW_PORT})",
    )
    parser.add_argument(
        "--config", type=str, default=None,
        help="Path to config JSON file (default: ~/.djhudpicam_config.json)",
    )
    parser.add_argument(
        "--log-level", type=str, default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level (default: INFO)",
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    from .daemon import Daemon

    kwargs = {
        "stream_port": args.port,
        "ctrl_port": args.ctrl_port,
        "raw_port": args.raw_port,
    }
    if args.config:
        kwargs["config_path"] = args.config

    daemon = Daemon(**kwargs)
    daemon.run()
