"""
controller/app.py — djhudpicam controller GUI (v0.2.0)

Evolved from the original standalone app.py. Adds:
  - Source selector: Local Webcam | Pi Camera Stream
  - Connection panel for Pi node IP/ports
  - Push Config / Get Snapshot buttons for remote control
  - Local compositing for instant region edit preview
"""

from __future__ import annotations
import json, logging, os, threading, time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Optional
import numpy as np

from .. import __version__
from ..camera import CameraCapture, RESOLUTIONS
from ..region import Region, RegionSet
from ..output import OutputManager, VpnStreamOutput, VirtualCamOutput
from ..common.protocol import DEFAULT_CTRL_PORT, DEFAULT_RAW_PORT
from .stream_input import StreamInput
from .ctrl_client import CtrlClient

try:
    from PIL import Image, ImageTk, ImageDraw
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

log = logging.getLogger(__name__)

PREVIEW_W = 640
PREVIEW_H = 360
STRIP_H = 100
STRIP_PADDING = 20
CONFIG_FILE = os.path.expanduser("~/.djhudpicam_config.json")
HANDLE_SIZE = 4
HANDLE_HIT = 6
CORNER_COLORS = ["#FF4444", "#44FF44", "#4488FF", "#FFFF44"]
CORNER_LABELS = ["TL", "TR", "BR", "BL"]
DOT_R = 7


class App(tk.Tk):
    def __init__(self, static_image: str = None):
        super().__init__()
        self.title(f"DJ HUD PiCam Controller v{__version__}")
        self.configure(bg="#1e1e2e")
        self.resizable(True, True)
        self.minsize(800, 400)

        self._static_image_path = static_image
        self.camera = CameraCapture(width=1280, height=720, fps=30)
        self.regions = RegionSet()
        self.outputs = OutputManager()

        # Source abstraction — either CameraCapture or StreamInput
        self._source_type = "webcam"  # "webcam" or "pi"
        self._source = self.camera    # current source (get_frame() interface)

        # Remote control clients
        self._stream_input: Optional[StreamInput] = None
        self._ctrl_client: Optional[CtrlClient] = None

        self._running = False
        self._streaming = False
        self._preview_thread: Optional[threading.Thread] = None
        self._latest_frame: Optional[np.ndarray] = None
        self._latest_strip: Optional[np.ndarray] = None
        self._frame_lock = threading.Lock()

        # Corner-pick mode
        self._picking = False
        self._pick_pts: list = []
        self._region_counter = 0

        # Perspective handle dragging
        self._warp_drag_idx: Optional[int] = None
        self._warp_drag_corner: Optional[int] = None
        self._warp_backup: Optional[list] = None

        # Strip drag state
        self._drag_idx: Optional[int] = None
        self._drag_mode: Optional[str] = None
        self._drag_mouse: tuple = (0, 0)
        self._drag_geom: tuple = (0, 0, 0, 0)

        self._strip_w = 1080
        self._strip_h = STRIP_H
        self._editor_loading = False

        # Display throttle — decouple GUI refresh from capture FPS
        self._frame_counter = 0           # incremented every capture frame
        self._display_skip_streaming = 6  # draw strip every Nth frame when streaming (~5fps at 30fps capture)
        self._display_skip_editing = 3    # draw strip every Nth frame when editing (~10fps at 30fps capture)

        # Grid/overlay cache — avoid redrawing static overlays every frame
        self._grid_cache: Optional[Image.Image] = None
        self._grid_cache_key: Optional[tuple] = None  # (snap, gsz, cw, ch, region_geom_tuple)

        self._build_ui()
        self._load_config()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Static image mode — load image as frozen frame for region editing
        if self._static_image_path:
            self._load_static_image(self._static_image_path)

    # ==================================================================
    # UI — scrollable main window
    # ==================================================================

    def _build_ui(self):
        s = ttk.Style(self); s.theme_use("clam")
        s.configure(".", background="#1e1e2e", foreground="#cdd6f4",
                    fieldbackground="#313244", troughcolor="#313244")
        s.configure("TButton", background="#313244", foreground="#cdd6f4", relief="flat", padding=4)
        s.map("TButton", background=[("active", "#45475a")])
        s.configure("Accent.TButton", background="#89b4fa", foreground="#1e1e2e")
        for w in ("TLabel", "TFrame"):
            s.configure(w, background="#1e1e2e", foreground="#cdd6f4")
        s.configure("TLabelframe", background="#1e1e2e", foreground="#89b4fa")
        s.configure("TLabelframe.Label", background="#1e1e2e", foreground="#89b4fa")

        # ── Scrollable wrapper ──
        outer = tk.Frame(self, bg="#1e1e2e")
        outer.pack(fill=tk.BOTH, expand=True)
        self._scroll_canvas = tk.Canvas(outer, bg="#1e1e2e", highlightthickness=0)
        self._vbar = ttk.Scrollbar(outer, orient="vertical", command=self._scroll_canvas.yview)
        self._scroll_canvas.configure(yscrollcommand=self._vbar.set)
        self._vbar.pack(side=tk.RIGHT, fill=tk.Y)
        self._scroll_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._inner = ttk.Frame(self._scroll_canvas)
        self._inner_id = self._scroll_canvas.create_window((0, 0), window=self._inner, anchor="nw")
        self._inner.bind("<Configure>", lambda e: self._scroll_canvas.configure(
            scrollregion=self._scroll_canvas.bbox("all")))
        self._scroll_canvas.bind("<Configure>", lambda e: self._scroll_canvas.itemconfigure(
            self._inner_id, width=e.width))
        # Mousewheel scrolling
        self._scroll_canvas.bind("<Enter>", lambda e: self._bind_scroll())
        self._scroll_canvas.bind("<Leave>", lambda e: self._unbind_scroll())

        container = self._inner  # everything packs into this

        # ── Toolbar ──
        tb = ttk.Frame(container, padding=4); tb.pack(fill=tk.X)
        ttk.Label(tb, text="Res:").pack(side=tk.LEFT)
        self._res_var = tk.StringVar(value="1280x720")
        res_vals = [f"{w}x{h}" for w, h in RESOLUTIONS]
        self._res_menu = tk.OptionMenu(tb, self._res_var, *res_vals,
                                       command=lambda _: self.after(50, self._on_setting_change))
        self._res_menu.config(width=10, bg="#313244", fg="#cdd6f4",
                              highlightthickness=0, activebackground="#45475a",
                              activeforeground="#cdd6f4")
        self._res_menu.pack(side=tk.LEFT, padx=4)
        ttk.Label(tb, text="FPS:").pack(side=tk.LEFT, padx=(6, 0))
        self._fps_var = tk.StringVar(value="30")
        fps_vals = ["10", "15", "20", "25", "30", "60"]
        self._fps_menu = tk.OptionMenu(tb, self._fps_var, *fps_vals,
                                       command=lambda _: self.after(50, self._on_setting_change))
        self._fps_menu.config(width=3, bg="#313244", fg="#cdd6f4",
                              highlightthickness=0, activebackground="#45475a",
                              activeforeground="#cdd6f4")
        self._fps_menu.pack(side=tk.LEFT, padx=4)
        self._start_btn = ttk.Button(tb, text="Start Camera", style="Accent.TButton",
                                     command=self._toggle_camera)
        self._start_btn.pack(side=tk.LEFT, padx=8)
        ttk.Button(tb, text="Save", command=self._save_config).pack(side=tk.LEFT, padx=2)
        ttk.Button(tb, text="Load", command=self._load_config_dialog).pack(side=tk.LEFT, padx=2)

        # ── Pi Connection Panel ──
        pf = ttk.LabelFrame(container, text="Pi Camera Node", padding=4)
        pf.pack(fill=tk.X, padx=4, pady=(4, 0))
        pr = ttk.Frame(pf); pr.pack(fill=tk.X)
        ttk.Label(pr, text="Source:").pack(side=tk.LEFT)
        self._source_var = tk.StringVar(value="webcam")
        tk.OptionMenu(pr, self._source_var, "webcam", "pi",
                       command=lambda _: self._on_source_change()
                       ).config(width=8, bg="#313244", fg="#cdd6f4",
                                highlightthickness=0, activebackground="#45475a",
                                activeforeground="#cdd6f4")
        # pack the option menu (it's the last widget created in pr)
        pr.winfo_children()[-1].pack(side=tk.LEFT, padx=4)
        ttk.Label(pr, text="Pi IP:").pack(side=tk.LEFT, padx=(8, 0))
        self._pi_ip_var = tk.StringVar(value="10.66.66.12")
        ttk.Entry(pr, textvariable=self._pi_ip_var, width=14).pack(side=tk.LEFT, padx=2)
        self._pi_connect_btn = ttk.Button(pr, text="Connect", command=self._toggle_pi_connection)
        self._pi_connect_btn.pack(side=tk.LEFT, padx=4)
        ttk.Button(pr, text="Snapshot", command=self._request_snapshot).pack(side=tk.LEFT, padx=2)
        ttk.Button(pr, text="Push Config", command=self._push_config_to_pi).pack(side=tk.LEFT, padx=2)
        ttk.Button(pr, text="Pull Config", command=self._pull_config_from_pi).pack(side=tk.LEFT, padx=2)
        self._pi_status_var = tk.StringVar(value="")
        ttk.Label(pr, textvariable=self._pi_status_var, foreground="#a6e3a1").pack(side=tk.LEFT, padx=8)

        # ── Main area ──
        main = ttk.Frame(container, padding=4); main.pack(fill=tk.BOTH, expand=True)

        # Camera preview
        pf = ttk.LabelFrame(main, text="Camera Preview (drag corners to edit warp)", padding=4)
        pf.grid(row=0, column=0, sticky="nsew", padx=(0, 4))
        self._cam_cv = tk.Canvas(pf, width=PREVIEW_W, height=PREVIEW_H,
                                 bg="#11111b", highlightthickness=0)
        self._cam_cv.pack()
        self._cam_cv.bind("<Button-1>", self._on_cam_click)
        self._cam_cv.bind("<B1-Motion>", self._on_cam_drag)
        self._cam_cv.bind("<ButtonRelease-1>", self._on_cam_release)
        self._cam_cv.bind("<Button-3>", self._on_cam_rclick)
        self.bind("<Return>", self._on_enter)
        self.bind("<Escape>", self._on_escape)

        # Right panel
        rp = ttk.Frame(main); rp.grid(row=0, column=1, sticky="nsew", padx=(4, 0))

        # Region list
        lf = ttk.LabelFrame(rp, text="Regions", padding=4); lf.pack(fill=tk.BOTH, expand=True)
        self._rlist = tk.Listbox(lf, width=28, height=8, bg="#313244", fg="#cdd6f4",
                                 selectbackground="#89b4fa", selectforeground="#1e1e2e",
                                 activestyle="none")
        self._rlist.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        self._rlist.bind("<<ListboxSelect>>", self._on_rlist_select)
        bb = ttk.Frame(lf); bb.pack(fill=tk.X)
        ttk.Button(bb, text="+ Add (4 clicks)", command=self._add_region).pack(side=tk.LEFT, padx=2)
        ttk.Button(bb, text="Del", command=self._del_region).pack(side=tk.LEFT, padx=2)
        ttk.Button(bb, text="Up", command=lambda: self._move(-1)).pack(side=tk.LEFT, padx=1)
        ttk.Button(bb, text="Dn", command=lambda: self._move(1)).pack(side=tk.LEFT, padx=1)

        # Simplified editor
        ed = ttk.LabelFrame(rp, text="Region Options", padding=6); ed.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(ed, text="Name").grid(row=0, column=0, sticky="w")
        self._ed_name = tk.StringVar()
        self._ed_name.trace_add("write", self._ed_apply)
        ttk.Entry(ed, textvariable=self._ed_name, width=16).grid(
            row=0, column=1, columnspan=3, sticky="ew", padx=(4, 0))
        self._ed_enabled = tk.BooleanVar(value=True)
        self._ed_enabled.trace_add("write", self._ed_apply)
        ttk.Checkbutton(ed, text="Enabled", variable=self._ed_enabled).grid(
            row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self._ed_locked = tk.BooleanVar()
        self._ed_locked.trace_add("write", self._ed_apply)
        ttk.Checkbutton(ed, text="Locked", variable=self._ed_locked).grid(
            row=1, column=2, columnspan=2, sticky="w", pady=(4, 0))
        # W / H read-only display
        ttk.Label(ed, text="W").grid(row=2, column=0, sticky="w", pady=(4, 0))
        self._ed_w = tk.StringVar(value="100")
        ttk.Label(ed, textvariable=self._ed_w, width=6, anchor="w",
                  relief="sunken", padding=(2, 0)).grid(
            row=2, column=1, sticky="ew", padx=(4, 8), pady=(4, 0))
        ttk.Label(ed, text="H").grid(row=2, column=2, sticky="w", pady=(4, 0))
        self._ed_h = tk.StringVar(value="100")
        ttk.Label(ed, textvariable=self._ed_h, width=6, anchor="w",
                  relief="sunken", padding=(2, 0)).grid(
            row=2, column=3, sticky="ew", padx=(4, 0), pady=(4, 0))
        # Aspect ratio lock checkbox
        self._lock_aspect = tk.BooleanVar(value=True)
        ttk.Checkbutton(ed, text="Lock aspect ratio", variable=self._lock_aspect).grid(
            row=3, column=0, columnspan=4, sticky="w", pady=(4, 0))
        ttk.Button(ed, text="Clear Warp", command=self._clear_warp).grid(
            row=4, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        ed.columnconfigure(1, weight=1)

        # Snap
        sr = ttk.Frame(rp); sr.pack(fill=tk.X, pady=(4, 0))
        self._snap = tk.BooleanVar(value=True)
        ttk.Checkbutton(sr, text="Snap to grid", variable=self._snap).pack(side=tk.LEFT)
        ttk.Label(sr, text="Size:").pack(side=tk.LEFT, padx=(8, 2))
        self._gsz = tk.IntVar(value=10)
        ttk.Spinbox(sr, from_=1, to=100, textvariable=self._gsz, width=4).pack(side=tk.LEFT)

        main.columnconfigure(0, weight=3)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=1)

        # ── Strip preview ──
        sf = ttk.LabelFrame(container, text="HUD Strip — drag to move, handles to scale, arrows to nudge", padding=4)
        sf.pack(fill=tk.X, padx=4, pady=4)
        szr = ttk.Frame(sf); szr.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(szr, text="Canvas W:").pack(side=tk.LEFT)
        self._cw = tk.IntVar(value=1080)
        ttk.Spinbox(szr, from_=100, to=8000, textvariable=self._cw, width=6).pack(side=tk.LEFT, padx=(2, 8))
        ttk.Label(szr, text="H:").pack(side=tk.LEFT)
        self._ch = tk.IntVar(value=STRIP_H)
        ttk.Spinbox(szr, from_=10, to=4000, textvariable=self._ch, width=6).pack(side=tk.LEFT, padx=(2, 0))
        self._strip_cv = tk.Canvas(sf, height=STRIP_H + STRIP_PADDING * 2, bg="#1b1b1b",
                                   highlightthickness=0, takefocus=True)
        self._strip_cv.pack(fill=tk.X)
        self._strip_cv.bind("<Button-1>", self._sc_click)
        self._strip_cv.bind("<B1-Motion>", self._sc_drag)
        self._strip_cv.bind("<ButtonRelease-1>", self._sc_release)
        for seq in ("<Left>", "<Right>", "<Up>", "<Down>",
                     "<Shift-Left>", "<Shift-Right>", "<Shift-Up>", "<Shift-Down>"):
            self._strip_cv.bind(seq, self._sc_arrow)

        # ── Camera Controls ──
        cc = ttk.LabelFrame(container, text="Camera Controls (Pi)", padding=6)
        cc.pack(fill=tk.X, padx=4, pady=4)

        # Auto exposure toggle
        self._ae_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(cc, text="Auto Exposure", variable=self._ae_var,
                        command=self._on_ae_toggle).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0,4))

        # Exposure slider (microseconds: 100us–200ms)
        ttk.Label(cc, text="Exposure (ms):").grid(row=1, column=0, sticky="w")
        self._exposure_var = tk.IntVar(value=10)
        self._exposure_slider = ttk.Scale(cc, from_=1, to=200, orient="horizontal",
                                          variable=self._exposure_var,
                                          command=self._on_exposure_change)
        self._exposure_slider.grid(row=1, column=1, sticky="ew", padx=(4,4))
        self._exposure_label = ttk.Label(cc, text="10 ms", width=8)
        self._exposure_label.grid(row=1, column=2, sticky="w")
        self._exposure_slider.config(state="disabled")

        # Gain slider (1.0–16.0)
        ttk.Label(cc, text="Gain:").grid(row=2, column=0, sticky="w", pady=(4,0))
        self._gain_var = tk.DoubleVar(value=1.0)
        self._gain_slider = ttk.Scale(cc, from_=1.0, to=16.0, orient="horizontal",
                                       variable=self._gain_var,
                                       command=self._on_gain_change)
        self._gain_slider.grid(row=2, column=1, sticky="ew", padx=(4,4), pady=(4,0))
        self._gain_label = ttk.Label(cc, text="1.0", width=8)
        self._gain_label.grid(row=2, column=2, sticky="w", pady=(4,0))

        # Focus slider (0.0=infinity, 10.0=very close)
        ttk.Label(cc, text="Focus:").grid(row=3, column=0, sticky="w", pady=(4,0))
        self._focus_var = tk.DoubleVar(value=0.0)
        self._af_var = tk.BooleanVar(value=True)
        self._focus_slider = ttk.Scale(cc, from_=0.0, to=10.0, orient="horizontal",
                                        variable=self._focus_var,
                                        command=self._on_focus_change)
        self._focus_slider.grid(row=3, column=1, sticky="ew", padx=(4,4), pady=(4,0))
        self._focus_label = ttk.Label(cc, text="Auto", width=8)
        self._focus_label.grid(row=3, column=2, sticky="w", pady=(4,0))
        ttk.Checkbutton(cc, text="Auto Focus", variable=self._af_var,
                        command=self._on_af_toggle).grid(row=3, column=3, sticky="w", padx=(4,0), pady=(4,0))
        self._focus_slider.config(state="disabled")

        cc.columnconfigure(1, weight=1)
        self._cam_ctrl_debounce = None

        # ── Outputs ──
        of = ttk.LabelFrame(container, text="Outputs", padding=6)
        of.pack(fill=tk.X, padx=4, pady=4)
        self._vpn_var = tk.BooleanVar()
        self._vcam_var = tk.BooleanVar()
        ttk.Checkbutton(of, text="VPN WebSocket", variable=self._vpn_var,
                        command=self._tog_vpn).grid(row=0, column=0, sticky="w", padx=8)
        ttk.Label(of, text="Port:").grid(row=0, column=1, sticky="e")
        self._vpn_port = tk.StringVar(value="8765")
        ttk.Entry(of, textvariable=self._vpn_port, width=6).grid(row=0, column=2, padx=4)
        self._vpn_url = ttk.Label(of, text="", foreground="#a6e3a1")
        self._vpn_url.grid(row=0, column=3, padx=8)
        ttk.Checkbutton(of, text="Virtual Camera (v4l2loopback)", variable=self._vcam_var,
                        command=self._tog_vcam).grid(row=1, column=0, sticky="w", padx=8, pady=2)

        # ── Status ──
        self._status_var = tk.StringVar(value="Ready.")
        ttk.Label(container, textvariable=self._status_var, foreground="#6c7086",
                  anchor="w").pack(fill=tk.X, padx=6, pady=(0, 4))

    def _bind_scroll(self):
        self._scroll_canvas.bind_all("<MouseWheel>",
            lambda e: self._scroll_canvas.yview_scroll(int(-e.delta / 120), "units"))

    def _unbind_scroll(self):
        self._scroll_canvas.unbind_all("<MouseWheel>")

    # ==================================================================
    # Source management
    # ==================================================================

    def _on_source_change(self):
        """Switch between webcam and Pi camera stream."""
        new_source = self._source_var.get()
        if new_source == self._source_type:
            return
        # Stop current source if running
        if self._running:
            self._stop_cam()
        self._source_type = new_source
        if new_source == "webcam":
            self._source = self.camera
            self._pi_status_var.set("")
        self._status(f"Source: {new_source}")

    def _toggle_pi_connection(self):
        """Connect/disconnect from Pi node."""
        if self._ctrl_client and self._ctrl_client.connected:
            self._disconnect_pi()
        else:
            self._connect_pi()

    def _connect_pi(self):
        """Connect to Pi node control channel and raw feed."""
        ip = self._pi_ip_var.get().strip()
        if not ip:
            messagebox.showwarning("No IP", "Enter the Pi node IP address.")
            return

        # Control client
        self._ctrl_client = CtrlClient(ip)
        self._ctrl_client.connect()

        # Stream input (for live preview)
        self._stream_input = StreamInput(ip)

        # Switch source to Pi
        self._source_var.set("pi")
        self._source_type = "pi"
        self._source = self._stream_input

        self._pi_connect_btn.config(text="Disconnect")
        self._pi_status_var.set(f"Connecting to {ip}...")
        self._status(f"Connecting to Pi node at {ip}...")

        # Check connection after a moment
        self.after(1500, self._check_pi_connection)

    def _check_pi_connection(self):
        if self._ctrl_client and self._ctrl_client.connected:
            self._pi_status_var.set("Connected")
            self._status("Connected to Pi node")
        elif self._ctrl_client:
            err = self._ctrl_client.last_error or "Timed out"
            self._pi_status_var.set(f"Error: {err}")
            self._status(f"Pi connection failed: {err}")

    def _disconnect_pi(self):
        """Disconnect from Pi node."""
        if self._running:
            self._stop_cam()
        if self._ctrl_client:
            self._ctrl_client.disconnect()
            self._ctrl_client = None
        if self._stream_input:
            self._stream_input.stop()
            self._stream_input = None

        # Revert to webcam
        self._source_var.set("webcam")
        self._source_type = "webcam"
        self._source = self.camera

        self._pi_connect_btn.config(text="Connect")
        self._pi_status_var.set("")
        self._status("Disconnected from Pi node")

    def _request_snapshot(self):
        """Request a single snapshot from the Pi node."""
        if not self._ctrl_client or not self._ctrl_client.connected:
            messagebox.showwarning("Not connected", "Connect to the Pi node first.")
            return

        self._status("Requesting snapshot...")
        # Run in thread to avoid blocking GUI
        def _do():
            frame = self._ctrl_client.request_snapshot()
            if frame is not None:
                with self._frame_lock:
                    self._latest_frame = frame
                    cw = max(100, self._cw.get())
                    ch = max(10, self._ch.get())
                    self._latest_strip = self.regions.composite(frame, cw, ch)
                    self._strip_w, self._strip_h = cw, ch
                self.after(0, lambda: self._status("Snapshot received"))
                self.after(0, lambda: self._draw_cam(frame))
                self.after(0, lambda: self._draw_strip(self._latest_strip))
            else:
                self.after(0, lambda: self._status("Snapshot failed"))
        threading.Thread(target=_do, daemon=True).start()

    def _push_config_to_pi(self):
        """Push current region config to the Pi node."""
        if not self._ctrl_client or not self._ctrl_client.connected:
            messagebox.showwarning("Not connected", "Connect to the Pi node first.")
            return

        config = {
            "resolution": self._res_var.get(),
            "fps": self._fps_var.get(),
            "vpn_port": self._vpn_port.get(),
            "canvas_w": self._cw.get(),
            "canvas_h": self._ch.get(),
            "regions": [r.to_dict() for r in self.regions.regions],
        }

        def _do():
            resp = self._ctrl_client.push_config(config)
            if resp and resp.get("status") == "ok":
                self.after(0, lambda: self._status("Config pushed to Pi node"))
            else:
                err = resp.get("message", "Unknown error") if resp else "No response"
                self.after(0, lambda: self._status(f"Push config failed: {err}"))
        threading.Thread(target=_do, daemon=True).start()

    def _pull_config_from_pi(self):
        """Pull config from the Pi node and apply locally."""
        if not self._ctrl_client or not self._ctrl_client.connected:
            messagebox.showwarning("Not connected", "Connect to the Pi node first.")
            return

        def _do():
            resp = self._ctrl_client.get_config()
            if resp and resp.get("type") == "config":
                config = resp.get("config", {})
                self.after(0, lambda: self._apply_pulled_config(config))
            else:
                self.after(0, lambda: self._status("Pull config failed"))
        threading.Thread(target=_do, daemon=True).start()

    def _apply_pulled_config(self, config: dict):
        """Apply config pulled from Pi node."""
        self._res_var.set(config.get("resolution", "640x480"))
        self._fps_var.set(config.get("fps", "15"))
        self._vpn_port.set(config.get("vpn_port", "8765"))
        self._cw.set(config.get("canvas_w", 640))
        self._ch.set(config.get("canvas_h", STRIP_H))
        self.regions.regions = [Region.from_dict(d) for d in config.get("regions", [])]
        self._region_counter = len(self.regions.regions)
        self._refresh()
        self._status("Config pulled from Pi node")

    # ==================================================================
    # Camera
    # ==================================================================

    def _toggle_camera(self):
        if self._running:
            self._stop_cam()
        else:
            self._start_cam()

    def _start_cam(self):
        if self._source_type == "pi":
            # Start receiving from Pi raw feed
            if self._stream_input:
                self._stream_input.start()
                # Also request the node to start sending raw frames
                if self._ctrl_client and self._ctrl_client.connected:
                    threading.Thread(
                        target=lambda: self._ctrl_client.start_raw_feed(5),
                        daemon=True,
                    ).start()
                self._running = True
                self._start_btn.config(text="Stop Preview")
                self._status("Receiving Pi camera stream...")
                self._preview_thread = threading.Thread(target=self._loop, daemon=True)
                self._preview_thread.start()
            else:
                messagebox.showwarning("Not connected", "Connect to Pi node first.")
        else:
            # Local webcam
            w, h = self._parse_res()
            fps = int(self._fps_var.get())
            self.camera.width, self.camera.height, self.camera.fps = w, h, fps
            backend = self.camera.start()
            self._running = True
            self._start_btn.config(text="Stop Camera")
            self._status(f"Camera started ({backend}) @ {w}x{h} {fps}fps")
            self._preview_thread = threading.Thread(target=self._loop, daemon=True)
            self._preview_thread.start()

    def _stop_cam(self):
        self._running = False
        if self._source_type == "pi":
            if self._stream_input:
                self._stream_input.stop()
            if self._ctrl_client and self._ctrl_client.connected:
                threading.Thread(
                    target=lambda: self._ctrl_client.stop_raw_feed(),
                    daemon=True,
                ).start()
            self._start_btn.config(text="Start Preview")
        else:
            self.camera.stop()
            self._start_btn.config(text="Start Camera")
        self._status("Stopped.")

    def _on_setting_change(self):
        """Called after res/fps combo selection — restart camera if running."""
        if self._running:
            self._stop_cam()
            self._start_cam()

    def _load_static_image(self, path: str):
        """Load a static image file as the camera frame for region editing."""
        if not HAS_CV2:
            messagebox.showerror("Error", "opencv-python required for --image mode")
            return
        import os
        if not os.path.exists(path):
            messagebox.showerror("Error", f"Image not found: {path}")
            return
        frame = cv2.imread(path)
        if frame is None:
            messagebox.showerror("Error", f"Could not read image: {path}")
            return
        h, w = frame.shape[:2]
        with self._frame_lock:
            self._latest_frame = frame
            cw = max(100, self._cw.get())
            ch = max(10, self._ch.get())
            self._latest_strip = self.regions.composite(frame, cw, ch)
            self._strip_w, self._strip_h = cw, ch
        self.title(f"DJ HUD PiCam v{__version__} — {os.path.basename(path)} ({w}x{h})")
        self._start_btn.config(text="Static Image", state="disabled")
        self._status(f"Static image loaded: {path} ({w}x{h}) — edit regions, then Save")
        # Trigger initial display
        self.after(100, self._refresh_static)

    def _refresh_static(self):
        """Redraw preview from static image — called on a timer during editing."""
        with self._frame_lock:
            frame = self._latest_frame
        if frame is None:
            return
        cw = max(100, self._cw.get())
        ch = max(10, self._ch.get())
        strip = self.regions.composite(frame, cw, ch)
        with self._frame_lock:
            self._latest_strip = strip
            self._strip_w, self._strip_h = cw, ch
        if HAS_PIL:
            self._draw_cam(frame)
            self._draw_strip(strip)
        # Keep refreshing so edits show up immediately
        if self._static_image_path:
            self.after(100, self._refresh_static)

    def _parse_res(self):
        t = self._res_var.get().replace("\u00d7", "x")
        parts = t.split("x")
        return int(parts[0]), int(parts[1])

    def _update_streaming_state(self):
        self._streaming = bool(self.outputs.vpn or self.outputs.virtualcam)

    # ==================================================================
    # Main loop
    # ==================================================================

    def _loop(self):
        while self._running:
            frame = self._source.get_frame()
            if frame is not None:
                cw = max(100, self._cw.get())
                ch = max(10, self._ch.get())
                strip = self.regions.composite(frame, cw, ch)
                with self._frame_lock:
                    self._latest_frame = frame
                    self._latest_strip = strip
                    self._strip_w, self._strip_h = cw, ch
                    self._frame_counter += 1
                self.after(0, self._update_display)
            time.sleep(1 / 30)

    def _update_display(self):
        with self._frame_lock:
            frame = self._latest_frame
            strip = self._latest_strip
            counter = self._frame_counter
        if frame is None:
            return

        # Always push frames to outputs at full speed
        if strip is not None:
            self.outputs.push_frame(strip)

        if not HAS_PIL:
            return

        # Camera preview: already frozen when streaming
        if not self._streaming:
            self._draw_cam(frame)

        # Strip preview: throttled based on mode
        if self._streaming:
            # During streaming: update strip preview at ~5fps
            if counter % self._display_skip_streaming == 0:
                self._draw_strip(strip)
        else:
            # During editing: update strip preview at ~10fps
            if counter % self._display_skip_editing == 0:
                self._draw_strip(strip)

    # ==================================================================
    # Camera preview
    # ==================================================================

    def _cam_scale(self):
        if self._latest_frame is None:
            return 1.0, 1.0
        fh, fw = self._latest_frame.shape[:2]
        return PREVIEW_W / fw, PREVIEW_H / fh

    def _draw_cam(self, frame):
        if not HAS_PIL:
            return
        # Use OpenCV for resize (SIMD-accelerated) then convert to PIL for overlays
        if HAS_CV2:
            resized = cv2.resize(frame, (PREVIEW_W, PREVIEW_H), interpolation=cv2.INTER_NEAREST)
            rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        else:
            rgb = frame
        img = Image.fromarray(rgb)
        if not HAS_CV2:
            img = img.resize((PREVIEW_W, PREVIEW_H), Image.NEAREST)
        draw = ImageDraw.Draw(img)
        sx, sy = self._cam_scale()
        si = self._sel_idx()

        for i, r in enumerate(self.regions.regions):
            c = "#f9e2af" if i == si else "#89b4fa"
            lw = 3 if i == si else 2
            if r.src_pts and len(r.src_pts) == 4:
                pts = [(int(x * sx), int(y * sy)) for x, y in r.src_pts]
                for j in range(4):
                    draw.line([pts[j], pts[(j + 1) % 4]], fill=c, width=lw)
                for j, (px, py) in enumerate(pts):
                    dr = DOT_R + 2 if i == si else DOT_R
                    draw.ellipse([px - dr, py - dr, px + dr, py + dr],
                                 fill=CORNER_COLORS[j], outline="white", width=2)
                    if i == si:
                        draw.text((px + dr + 2, py - dr), CORNER_LABELS[j],
                                  fill=CORNER_COLORS[j])
                draw.text((pts[0][0] + 6, pts[0][1] + DOT_R + 4), r.name, fill="#cdd6f4")
            else:
                x1 = int(r.crop_x * sx)
                y1 = int(r.crop_y * sy)
                x2 = int((r.crop_x + r.crop_w) * sx)
                y2 = int((r.crop_y + r.crop_h) * sy)
                draw.rectangle([x1, y1, x2, y2], outline=c, width=lw)
                draw.text((x1 + 4, y1 + 4), r.name, fill="#cdd6f4")

        # In-progress new region picks
        if self._picking and self._pick_pts:
            for j, (px, py) in enumerate(self._pick_pts):
                draw.ellipse([px - 6, py - 6, px + 6, py + 6],
                             fill=CORNER_COLORS[j], outline="white", width=2)
                draw.text((px + 8, py - 6), CORNER_LABELS[j], fill=CORNER_COLORS[j])
            for j in range(len(self._pick_pts) - 1):
                draw.line([tuple(self._pick_pts[j]), tuple(self._pick_pts[j + 1])],
                          fill="white", width=1)
            rem = 4 - len(self._pick_pts)
            draw.text((PREVIEW_W // 2 - 80, PREVIEW_H - 20),
                      f"Click {CORNER_LABELS[len(self._pick_pts)]}  ({rem} left)  |  Right-click: cancel",
                      fill="#f9e2af")

        if self._warp_drag_idx is not None:
            draw.text((10, PREVIEW_H - 20),
                      "Drag corners — Enter=confirm, Esc=revert", fill="#a6e3a1")

        ti = ImageTk.PhotoImage(img)
        self._cam_cv.create_image(0, 0, anchor=tk.NW, image=ti)
        self._cam_cv._img = ti

    # ==================================================================
    # Camera interaction — warp corner dragging
    # ==================================================================

    def _cam_hit_corner(self, ex, ey):
        sx, sy = self._cam_scale()
        si = self._sel_idx()
        order = []
        if si is not None:
            order.append(si)
        order.extend(i for i in range(len(self.regions.regions)) if i != si)
        for i in order:
            r = self.regions.regions[i]
            if not r.src_pts or len(r.src_pts) != 4:
                continue
            for j, (cx, cy) in enumerate(r.src_pts):
                ddx = ex - cx * sx
                ddy = ey - cy * sy
                if ddx * ddx + ddy * ddy <= (DOT_R + 4) ** 2:
                    return i, j
        return None

    def _on_cam_click(self, event):
        if self._latest_frame is None:
            return
        if self._picking:
            self._pick_pts.append([event.x, event.y])
            if len(self._pick_pts) < 4:
                self._status(f"Click {CORNER_LABELS[len(self._pick_pts)]}  ({4 - len(self._pick_pts)} left)")
            else:
                self._finish_pick()
            return

        hit = self._cam_hit_corner(event.x, event.y)
        if hit:
            ri, ci = hit
            self._sel(ri)
            r = self.regions.regions[ri]
            self._warp_drag_idx = ri
            self._warp_drag_corner = ci
            self._warp_backup = [list(p) for p in r.src_pts]
            self._status(f"Dragging {CORNER_LABELS[ci]} of '{r.name}'")
            return

        if HAS_CV2:
            sx, sy = self._cam_scale()
            cx = int(event.x / sx)
            cy = int(event.y / sy)
            for i, r in enumerate(self.regions.regions):
                if r.src_pts and len(r.src_pts) == 4:
                    pts = np.array(r.src_pts, dtype=np.float32)
                    if cv2.pointPolygonTest(pts, (float(cx), float(cy)), False) >= 0:
                        self._sel(i)
                        return

    def _on_cam_drag(self, event):
        if self._warp_drag_idx is None or self._warp_drag_corner is None:
            return
        r = self.regions.regions[self._warp_drag_idx]
        sx, sy = self._cam_scale()
        cam_x = max(0, int(event.x / sx))
        cam_y = max(0, int(event.y / sy))
        if self._latest_frame is not None:
            fh, fw = self._latest_frame.shape[:2]
            cam_x = min(fw - 1, cam_x)
            cam_y = min(fh - 1, cam_y)
        r.src_pts[self._warp_drag_corner] = [cam_x, cam_y]
        r.compute_homography()

    def _on_cam_release(self, event):
        if self._warp_drag_idx is not None:
            r = self.regions.regions[self._warp_drag_idx]
            # Only recompute homography, do NOT recalc out_w/out_h
            # The user may have manually scaled the region on the strip
            r.compute_homography()
            self._status("Corner placed — Enter=confirm, Esc=revert")
            self._warp_drag_corner = None

    def _on_cam_rclick(self, event):
        if self._picking:
            self._picking = False
            self._pick_pts = []
            self._cam_cv.config(cursor="arrow")
            self._status("Pick cancelled.")

    def _on_enter(self, event):
        if self._warp_drag_idx is not None:
            r = self.regions.regions[self._warp_drag_idx]
            self._warp_backup = None
            self._warp_drag_idx = None
            self._warp_drag_corner = None
            self._refresh()
            self._status(f"Warp confirmed for '{r.name}'")

    def _on_escape(self, event):
        if self._warp_drag_idx is not None and self._warp_backup is not None:
            r = self.regions.regions[self._warp_drag_idx]
            r.src_pts = self._warp_backup
            r.compute_homography()
            self._warp_backup = None
            self._warp_drag_idx = None
            self._warp_drag_corner = None
            self._status("Warp reverted.")

    def _recalc_size(self, r: Region):
        if not r.src_pts or len(r.src_pts) != 4:
            return
        p = r.src_pts
        tw = ((p[1][0] - p[0][0]) ** 2 + (p[1][1] - p[0][1]) ** 2) ** 0.5
        bw = ((p[2][0] - p[3][0]) ** 2 + (p[2][1] - p[3][1]) ** 2) ** 0.5
        lh = ((p[3][0] - p[0][0]) ** 2 + (p[3][1] - p[0][1]) ** 2) ** 0.5
        rh = ((p[2][0] - p[1][0]) ** 2 + (p[2][1] - p[1][1]) ** 2) ** 0.5
        avg = max(32, int((tw + bw + lh + rh) / 4))
        r.out_w = avg
        r.out_h = avg

    def _finish_pick(self):
        fh, fw = self._latest_frame.shape[:2]
        sx, sy = fw / PREVIEW_W, fh / PREVIEW_H
        pts = [[int(x * sx), int(y * sy)] for x, y in self._pick_pts]
        self._region_counter += 1
        name = f"R{self._region_counter}"
        ox = 0
        for r in self.regions.regions:
            ox = max(ox, r.out_x + r.out_w)
        if ox > 0:
            ox += 2
        r = Region(name=name, src_pts=pts,
                   crop_x=pts[0][0], crop_y=pts[0][1], crop_w=100, crop_h=100,
                   out_x=self._snp(ox), out_y=0, out_w=100, out_h=100)
        self._recalc_size(r)
        r.compute_homography()
        self.regions.add(r)
        self._refresh()
        self._sel(len(self.regions.regions) - 1)
        self._picking = False
        self._pick_pts = []
        self._cam_cv.config(cursor="arrow")
        self._status(f"Region '{name}' created ({r.out_w}x{r.out_h})")

    # ==================================================================
    # Strip preview
    # ==================================================================

    def _draw_strip(self, strip):
        if not HAS_PIL or strip is None:
            return
        cw, ch = self._strip_w, self._strip_h
        pad = STRIP_PADDING

        # Build the base image: background + strip frame data
        if HAS_CV2:
            rgb = cv2.cvtColor(strip, cv2.COLOR_BGR2RGB)
        else:
            rgb = strip
        ws = Image.new("RGB", (cw + pad * 2, ch + pad * 2), "#1b1b1b")
        ws.paste(Image.fromarray(rgb), (pad, pad))

        # Grid overlay — cached, only rebuilt when geometry changes
        snap_on = self._snap.get()
        gs = max(1, self._gsz.get()) if snap_on else 0
        si = self._sel_idx()
        region_geom = tuple(
            (r.out_x, r.out_y, r.out_w, r.out_h, r.enabled, r.name)
            for r in self.regions.regions
        )
        cache_key = (snap_on, gs, cw, ch, si, region_geom)

        if self._grid_cache_key != cache_key:
            # Rebuild the overlay (transparent layer with grid + outlines + handles)
            overlay = Image.new("RGBA", (cw + pad * 2, ch + pad * 2), (0, 0, 0, 0))
            draw = ImageDraw.Draw(overlay)

            # Canvas border
            draw.rectangle([pad, pad, pad + cw - 1, pad + ch - 1],
                           outline=(140, 140, 140, 255), width=2)

            # Grid lines (only outside region boxes)
            if snap_on and gs > 0:
                gc = (50, 50, 50, 255)
                rboxes = [(pad + r.out_x, pad + r.out_y,
                           pad + r.out_x + r.out_w, pad + r.out_y + r.out_h)
                          for r in self.regions.regions if r.enabled]
                for gx in range(0, cw + 1, gs):
                    lx = pad + gx
                    ss = pad
                    for rb in sorted(rboxes, key=lambda b: b[1]):
                        if lx < rb[0] or lx > rb[2]:
                            continue
                        if ss < rb[1]:
                            draw.line((lx, ss, lx, rb[1]), fill=gc)
                        ss = max(ss, rb[3])
                    if ss < pad + ch:
                        draw.line((lx, ss, lx, pad + ch), fill=gc)
                for gy in range(0, ch + 1, gs):
                    ly = pad + gy
                    ss = pad
                    for rb in sorted(rboxes, key=lambda b: b[0]):
                        if ly < rb[1] or ly > rb[3]:
                            continue
                        if ss < rb[0]:
                            draw.line((ss, ly, rb[0], ly), fill=gc)
                        ss = max(ss, rb[2])
                    if ss < pad + cw:
                        draw.line((ss, ly, pad + cw, ly), fill=gc)

            # Region outlines + handles
            hs = HANDLE_SIZE
            for i, r in enumerate(self.regions.regions):
                x1 = pad + r.out_x
                y1 = pad + r.out_y
                x2 = x1 + r.out_w
                y2 = y1 + r.out_h
                sel = (i == si)
                ol = ((255, 180, 0, 255) if sel
                      else ((0, 180, 255, 255) if r.enabled else (120, 120, 120, 255)))
                draw.rectangle([x1, y1, x2, y2], outline=ol, width=3 if sel else 2)
                draw.text((x1 + 4, y1 + 2), r.name, fill=(255, 255, 255, 255))
                if sel:
                    hc = (111, 199, 255, 255)
                    for px, py in [(x1, y1), ((x1 + x2) // 2, y1), (x2, y1),
                                   (x1, (y1 + y2) // 2), (x2, (y1 + y2) // 2),
                                   (x1, y2), ((x1 + x2) // 2, y2), (x2, y2)]:
                        draw.rectangle([px - hs, py - hs, px + hs - 1, py + hs - 1],
                                       outline=hc, fill=hc)

            self._grid_cache = overlay
            self._grid_cache_key = cache_key

        # Composite cached overlay onto the strip image
        ws.paste(self._grid_cache, (0, 0), self._grid_cache)

        ti = ImageTk.PhotoImage(ws)
        self._strip_cv.config(height=ch + pad * 2)
        self._strip_cv.delete("all")
        self._strip_cv.create_image(0, 0, anchor=tk.NW, image=ti)
        self._strip_cv._img = ti

    # ==================================================================
    # Strip interaction
    # ==================================================================

    def _s2c(self, event):
        return event.x - STRIP_PADDING, event.y - STRIP_PADDING

    def _s_hit(self, ax, ay):
        for i in reversed(range(len(self.regions.regions))):
            r = self.regions.regions[i]
            if r.out_x <= ax <= r.out_x + r.out_w and r.out_y <= ay <= r.out_y + r.out_h:
                return i
        return None

    def _s_handle(self, r, ax, ay):
        x1, y1 = r.out_x, r.out_y
        x2, y2 = x1 + r.out_w, y1 + r.out_h
        hh = HANDLE_HIT
        handles = {
            "nw": (x1 - hh, y1 - hh, x1 + hh, y1 + hh),
            "n": ((x1 + x2) // 2 - hh, y1 - hh, (x1 + x2) // 2 + hh, y1 + hh),
            "ne": (x2 - hh, y1 - hh, x2 + hh, y1 + hh),
            "w": (x1 - hh, (y1 + y2) // 2 - hh, x1 + hh, (y1 + y2) // 2 + hh),
            "e": (x2 - hh, (y1 + y2) // 2 - hh, x2 + hh, (y1 + y2) // 2 + hh),
            "sw": (x1 - hh, y2 - hh, x1 + hh, y2 + hh),
            "s": ((x1 + x2) // 2 - hh, y2 - hh, (x1 + x2) // 2 + hh, y2 + hh),
            "se": (x2 - hh, y2 - hh, x2 + hh, y2 + hh),
        }
        for name, (a, b, c, d) in handles.items():
            if a <= ax <= c and b <= ay <= d:
                return name
        return None

    def _snp(self, v):
        if not self._snap.get():
            return v
        gs = max(1, self._gsz.get())
        return int(round(v / gs) * gs)

    def _sc_click(self, event):
        self._strip_cv.focus_set()
        ax, ay = self._s2c(event)
        idx = self._s_hit(ax, ay)
        if idx is None:
            self._drag_idx = None
            self._drag_mode = None
            return
        self._sel(idx)
        r = self.regions.regions[idx]
        if getattr(r, 'locked', False):
            self._drag_mode = None
            return
        self._drag_idx = idx
        self._drag_mouse = (ax, ay)
        self._drag_geom = (r.out_x, r.out_y, r.out_w, r.out_h)
        h = self._s_handle(r, ax, ay)
        self._drag_mode = h if h else "move"

    def _sc_drag(self, event):
        if self._drag_idx is None or self._drag_mode is None:
            return
        ax, ay = self._s2c(event)
        dx = ax - self._drag_mouse[0]
        dy = ay - self._drag_mouse[1]
        r = self.regions.regions[self._drag_idx]
        ox, oy, ow, oh = self._drag_geom

        if self._drag_mode == "move":
            r.out_x = self._snp(ox + dx)
            r.out_y = self._snp(oy + dy)
        else:
            lock = getattr(self, '_lock_aspect', None) and self._lock_aspect.get()
            aspect = oh / max(1, ow)
            mode = self._drag_mode
            is_corner = mode in ("nw", "ne", "sw", "se")
            is_horiz = mode in ("e", "w")
            is_vert = mode in ("n", "s")

            if lock:
                # Proportional scale
                if is_corner:
                    if abs(dx) >= abs(dy):
                        nw = ow + dx if "e" in mode else ow - dx
                    else:
                        nh_raw = oh + dy if "s" in mode else oh - dy
                        nw = int(nh_raw / aspect) if aspect > 0 else ow
                elif is_horiz:
                    nw = ow + dx if mode == "e" else ow - dx
                elif is_vert:
                    nh_raw = oh + dy if mode == "s" else oh - dy
                    nw = int(nh_raw / aspect) if aspect > 0 else ow
                else:
                    nw = ow
                nw = max(10, nw)
                nh = max(10, int(nw * aspect))
            else:
                # Free scale — each axis independent
                if is_corner or is_horiz:
                    nw = max(10, ow + dx if "e" in mode else ow - dx)
                else:
                    nw = ow
                if is_corner or is_vert:
                    nh = max(10, oh + dy if "s" in mode else oh - dy)
                else:
                    nh = oh

            r.out_w = self._snp(nw)
            r.out_h = self._snp(nh)
            if "w" in mode:
                r.out_x = self._snp(ox + ow - r.out_w)
            if "n" in mode:
                r.out_y = self._snp(oy + oh - r.out_h)
            # Update W/H display
            self._ed_w.set(str(r.out_w))
            self._ed_h.set(str(r.out_h))
            # Recompute homography AFTER snap so output size matches out_w/out_h exactly
            if r.src_pts:
                r.compute_homography()
                r._H  # ensure dst uses snapped out_w/out_h

    def _sc_release(self, event):
        self._drag_idx = None
        self._drag_mode = None

    def _sc_arrow(self, event):
        idx = self._sel_idx()
        if idx is None:
            return "break"
        r = self.regions.regions[idx]
        if getattr(r, 'locked', False):
            return "break"
        step = max(1, self._gsz.get()) if self._snap.get() else 1
        if event.state & 0x0001:
            step *= 10
        if event.keysym == "Left":
            r.out_x -= step
        elif event.keysym == "Right":
            r.out_x += step
        elif event.keysym == "Up":
            r.out_y -= step
        elif event.keysym == "Down":
            r.out_y += step
        return "break"

    # ==================================================================
    # Region list
    # ==================================================================

    def _refresh(self):
        self._rlist.delete(0, tk.END)
        for r in self.regions.regions:
            ic = "\u2714" if r.enabled else "\u2718"
            w = " W" if r.src_pts else ""
            lk = " L" if getattr(r, 'locked', False) else ""
            self._rlist.insert(tk.END, f"{ic} {r.name}{w}{lk}")

    def _sel_idx(self):
        s = self._rlist.curselection()
        if not s:
            return None
        return s[0] if s[0] < len(self.regions.regions) else None

    def _sel(self, idx):
        self._rlist.selection_clear(0, tk.END)
        self._rlist.selection_set(idx)
        self._rlist.see(idx)
        self._load_ed(idx)

    def _on_rlist_select(self, event=None):
        idx = self._sel_idx()
        if idx is not None:
            self._load_ed(idx)

    def _add_region(self):
        if self._latest_frame is None:
            messagebox.showwarning("No frame", "Start the camera or use --image to load a snapshot.")
            return
        self._picking = True
        self._pick_pts = []
        self._cam_cv.config(cursor="crosshair")
        self._status("Click TL corner (4 clicks)  |  Right-click to cancel")

    def _del_region(self):
        idx = self._sel_idx()
        if idx is not None:
            self.regions.remove(idx)
            self._refresh()

    def _move(self, d):
        idx = self._sel_idx()
        if idx is None:
            return
        if d < 0 and idx > 0:
            self.regions.move_up(idx)
            self._refresh()
            self._sel(idx - 1)
        elif d > 0 and idx < len(self.regions.regions) - 1:
            self.regions.move_down(idx)
            self._refresh()
            self._sel(idx + 1)

    # ==================================================================
    # Editor (simplified: name, enabled, locked, clear warp)
    # ==================================================================

    def _load_ed(self, idx):
        if idx is None or idx >= len(self.regions.regions):
            return
        self._editor_loading = True
        r = self.regions.regions[idx]
        self._ed_name.set(r.name)
        self._ed_enabled.set(r.enabled)
        self._ed_locked.set(getattr(r, 'locked', False))
        self._ed_w.set(str(r.out_w))
        self._ed_h.set(str(r.out_h))
        self._editor_loading = False

    def _ed_apply(self, *_):
        if self._editor_loading:
            return
        idx = self._sel_idx()
        if idx is None or idx >= len(self.regions.regions):
            return
        r = self.regions.regions[idx]
        try:
            r.name = self._ed_name.get()
            r.enabled = self._ed_enabled.get()
            r.locked = self._ed_locked.get()
        except (tk.TclError, ValueError):
            pass
        # Rebuild listbox without triggering _load_ed
        self._editor_loading = True
        self._refresh()
        self._rlist.selection_clear(0, tk.END)
        self._rlist.selection_set(idx)
        self._editor_loading = False



    def _clear_warp(self):
        idx = self._sel_idx()
        if idx is None:
            return
        r = self.regions.regions[idx]
        r.src_pts = None
        r._H = None
        self._refresh()

    # ==================================================================
    # Outputs
    # ==================================================================

    # ==================================================================
    # Camera controls
    # ==================================================================

    def _send_cam_controls(self, controls: dict):
        """Send camera controls to Pi node, debounced 300ms."""
        if self._cam_ctrl_debounce:
            self.root.after_cancel(self._cam_ctrl_debounce)
        def _send():
            if self._ctrl_client and self._ctrl_client.connected:
                import threading
                threading.Thread(
                    target=self._ctrl_client.set_camera_controls,
                    args=(controls,), daemon=True
                ).start()
        self._cam_ctrl_debounce = self.root.after(300, _send)

    def _on_ae_toggle(self):
        ae = self._ae_var.get()
        if ae:
            self._exposure_slider.config(state="disabled")
            self._send_cam_controls({"AeEnable": True})
        else:
            self._exposure_slider.config(state="normal")
            ms = self._exposure_var.get()
            self._send_cam_controls({"AeEnable": False, "ExposureTime": ms * 1000})

    def _on_exposure_change(self, _=None):
        if self._ae_var.get():
            return
        ms = int(self._exposure_var.get())
        self._exposure_label.config(text=f"{ms} ms")
        self._send_cam_controls({"AeEnable": False, "ExposureTime": ms * 1000})

    def _on_gain_change(self, _=None):
        gain = round(self._gain_var.get(), 1)
        self._gain_label.config(text=str(gain))
        self._send_cam_controls({"AnalogueGain": gain})

    def _on_af_toggle(self):
        af = self._af_var.get()
        if af:
            self._focus_slider.config(state="disabled")
            self._focus_label.config(text="Auto")
            self._send_cam_controls({"AfMode": 2})  # continuous AF
        else:
            self._focus_slider.config(state="normal")
            pos = round(self._focus_var.get(), 1)
            self._focus_label.config(text=str(pos))
            self._send_cam_controls({"AfMode": 0, "LensPosition": pos})

    def _on_focus_change(self, _=None):
        if self._af_var.get():
            return
        pos = round(self._focus_var.get(), 2)
        self._focus_label.config(text=str(pos))
        self._send_cam_controls({"AfMode": 0, "LensPosition": pos})

    def _tog_vpn(self):
        if self._vpn_var.get():
            p = int(self._vpn_port.get())
            self.outputs.vpn = VpnStreamOutput(port=p)
            self.outputs.vpn.start()
            u = self.outputs.vpn.viewer_url
            self._vpn_url.config(text=u)
            self._status(f"VPN: {u}")
        else:
            if self.outputs.vpn:
                self.outputs.vpn.stop()
                self.outputs.vpn = None
            self._vpn_url.config(text="")
        self._update_streaming_state()
        if self._streaming:
            self._status("Streaming — cam preview frozen to save CPU")

    def _tog_vcam(self):
        if self._vcam_var.get():
            self.outputs.virtualcam = VirtualCamOutput()
            self.outputs.virtualcam.start()
        else:
            if self.outputs.virtualcam:
                self.outputs.virtualcam.stop()
                self.outputs.virtualcam = None
        self._update_streaming_state()

    # ==================================================================
    # Config
    # ==================================================================

    def _save_config(self, path=CONFIG_FILE):
        data = {
            "resolution": self._res_var.get(),
            "fps": self._fps_var.get(),
            "vpn_port": self._vpn_port.get(),
            "canvas_w": self._cw.get(),
            "canvas_h": self._ch.get(),
            "snap": self._snap.get(),
            "grid_size": self._gsz.get(),
            "regions": [r.to_dict() for r in self.regions.regions],
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        self._status(f"Saved -> {path}")

    def _load_config(self, path=CONFIG_FILE):
        if not os.path.exists(path):
            return
        try:
            with open(path) as f:
                data = json.load(f)
            self._res_var.set(data.get("resolution", "1280x720"))
            self._fps_var.set(data.get("fps", "30"))
            self._vpn_port.set(data.get("vpn_port", "8765"))
            self._cw.set(data.get("canvas_w", 1080))
            self._ch.set(data.get("canvas_h", STRIP_H))
            self._snap.set(data.get("snap", True))
            self._gsz.set(data.get("grid_size", 10))
            self.regions.regions = [Region.from_dict(d) for d in data.get("regions", [])]
            self._region_counter = len(self.regions.regions)
            self._refresh()
            self._status(f"Loaded <- {path}")
        except Exception as e:
            log.warning("Config load error: %s", e)

    def _load_config_dialog(self):
        p = filedialog.askopenfilename(filetypes=[("JSON", "*.json"), ("All", "*.*")])
        if p:
            self._load_config(p)

    # ==================================================================
    # Misc
    # ==================================================================

    def _status(self, msg):
        self._status_var.set(msg)
        log.info(msg)

    def _on_close(self):
        self._save_config()
        self._stop_cam()
        if self._ctrl_client:
            self._ctrl_client.disconnect()
        if self._stream_input:
            self._stream_input.stop()
        self.outputs.stop_all()
        self.destroy()
