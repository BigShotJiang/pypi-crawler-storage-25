"""
common/protocol.py — Shared command and response message definitions.

Used by both djhudpicam-node (server) and djhudpicam-controller (client)
to ensure consistent message formats on the control WebSocket channel.
"""

from __future__ import annotations
import json
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Default ports
# ---------------------------------------------------------------------------

DEFAULT_STREAM_PORT = 8765   # HUD strip WebSocket (Pi → djhud)
DEFAULT_RAW_PORT = 8766      # Raw camera feed WebSocket (Pi → controller)
DEFAULT_CTRL_PORT = 8767     # Command channel WebSocket (controller ↔ Pi)


# ---------------------------------------------------------------------------
# Controller → Node commands
# ---------------------------------------------------------------------------

def cmd_get_status() -> str:
    return json.dumps({"cmd": "get_status"})

def cmd_get_config() -> str:
    return json.dumps({"cmd": "get_config"})

def cmd_push_config(config: dict) -> str:
    return json.dumps({"cmd": "push_config", "config": config})

def cmd_set_resolution(width: int, height: int, fps: int) -> str:
    return json.dumps({"cmd": "set_resolution", "width": width, "height": height, "fps": fps})

def cmd_start_raw_feed(fps: int = 5) -> str:
    return json.dumps({"cmd": "start_raw_feed", "fps": fps})

def cmd_stop_raw_feed() -> str:
    return json.dumps({"cmd": "stop_raw_feed"})

def cmd_snapshot() -> str:
    return json.dumps({"cmd": "snapshot"})

def cmd_set_camera_controls(controls: dict) -> str:
    return json.dumps({"cmd": "set_camera_controls", "controls": controls})


# ---------------------------------------------------------------------------
# Node → Controller responses
# ---------------------------------------------------------------------------

def resp_ack(cmd: str, status: str = "ok") -> str:
    return json.dumps({"type": "ack", "cmd": cmd, "status": status})

def resp_error(cmd: str, message: str) -> str:
    return json.dumps({"type": "error", "cmd": cmd, "message": message})

def resp_status(
    camera_running: bool,
    streaming: bool,
    output_type: str,
    resolution: str,
    fps: int,
    regions_count: int,
    clients_connected: int,
    cpu_percent: float = 0.0,
    memory_mb: float = 0.0,
    raw_feed_active: bool = False,
) -> str:
    return json.dumps({
        "type": "status",
        "camera_running": camera_running,
        "streaming": streaming,
        "output_type": output_type,
        "resolution": resolution,
        "fps": fps,
        "regions_count": regions_count,
        "clients_connected": clients_connected,
        "cpu_percent": cpu_percent,
        "memory_mb": memory_mb,
        "raw_feed_active": raw_feed_active,
    })

def resp_config(config: dict) -> str:
    return json.dumps({"type": "config", "config": config})

def resp_snapshot(frame_b64: str) -> str:
    return json.dumps({"type": "snapshot", "frame": frame_b64})


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def parse_message(raw: str) -> Optional[dict]:
    """Parse a JSON message, return dict or None on error."""
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None
