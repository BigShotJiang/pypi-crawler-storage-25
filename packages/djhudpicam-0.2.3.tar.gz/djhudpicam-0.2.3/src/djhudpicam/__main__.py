"""djhudpicam entry point.

v0.1.10:
  --snapshot <path>   Capture one frame, save as JPEG, exit (no GUI).
  --image <path>      Open GUI with a static image instead of live camera.
"""
import argparse
import logging
import sys
import time

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

log = logging.getLogger(__name__)


def do_snapshot(output_path: str, width: int, height: int, fps: int):
    """Capture a single frame and save as JPEG. No GUI required."""
    from .camera import CameraCapture

    try:
        import cv2
    except ImportError:
        print("ERROR: opencv-python is required for --snapshot", file=sys.stderr)
        sys.exit(1)

    cam = CameraCapture(width=width, height=height, fps=fps)
    backend = cam.start()
    log.info("Camera started (%s) @ %dx%d — waiting for first frame...", backend, width, height)

    # Give the camera time to warm up and deliver a frame
    frame = None
    for attempt in range(50):  # up to ~5 seconds
        frame = cam.get_frame()
        if frame is not None:
            break
        time.sleep(0.1)

    cam.stop()

    if frame is None:
        print("ERROR: No frame captured after 5 seconds.", file=sys.stderr)
        sys.exit(1)

    cv2.imwrite(output_path, frame)
    h, w = frame.shape[:2]
    print(f"Saved {w}x{h} frame -> {output_path}")


def main():
    parser = argparse.ArgumentParser(
        prog="djhudpicam",
        description="DJ HUD Pi Camera — capture, warp, composite, stream.",
    )
    parser.add_argument(
        "--snapshot", metavar="PATH",
        help="Capture one frame, save as JPEG to PATH, then exit (no GUI).",
    )
    parser.add_argument(
        "--image", metavar="PATH",
        help="Open GUI with a static image file instead of live camera feed.",
    )
    parser.add_argument(
        "--width", type=int, default=1280,
        help="Camera capture width (default: 1280). Used with --snapshot.",
    )
    parser.add_argument(
        "--height", type=int, default=720,
        help="Camera capture height (default: 720). Used with --snapshot.",
    )
    parser.add_argument(
        "--fps", type=int, default=30,
        help="Camera FPS (default: 30). Used with --snapshot.",
    )

    args = parser.parse_args()

    if args.snapshot:
        do_snapshot(args.snapshot, args.width, args.height, args.fps)
        return

    # GUI mode — import app here so headless --snapshot doesn't need tkinter
    from .app import App
    app = App(static_image=args.image)
    app.mainloop()


if __name__ == "__main__":
    main()
