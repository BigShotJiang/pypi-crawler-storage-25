import pytest
import pygame
from unittest.mock import MagicMock

from tileforge import Renderer


class MockTileset:
    def __init__(self, tile_size=16):
        self.tile_size = tile_size

    def get_scaled_tiles(self, scale):
        return [pygame.Surface((self.tile_size * scale, self.tile_size * scale)) for _ in range(3)]

    def subscribe(self, callback):
        pass


class MockMap:
    def __init__(self):
        self.width = 2
        self.height = 2
        self.layers = [
            [
                [(0, 0), (1, 1)],
                [(2, 2), (0, 3)],
            ]
        ]


@pytest.fixture(autouse=True)
def pygame_init():
    pygame.init()
    yield
    pygame.quit()


def test_initialization():
    tileset = MockTileset()
    map_layout = MockMap()

    renderer = Renderer(tileset, map_layout, render_scale=2)

    assert renderer.render_tile_size == 32
    assert len(renderer.tiles) == 3
    assert renderer.layout == map_layout
    assert renderer.tileset == tileset


def test_set_render_scale():
    tileset = MockTileset()
    renderer = Renderer(tileset, MockMap(), render_scale=1)

    renderer.set_render_scale(3)

    assert renderer.render_tile_size == 48
    assert all(tile.get_width() == 48 for tile in renderer.tiles)


def test_render_calls_blit():
    tileset = MockTileset()
    map_layout = MockMap()
    renderer = Renderer(tileset, map_layout)

    surface = MagicMock()

    renderer.render(surface)

    assert surface.blit.call_count == 4


def test_render_with_offset():
    tileset = MockTileset()
    map_layout = MockMap()
    renderer = Renderer(tileset, map_layout, render_scale=1)

    surface = MagicMock()

    renderer.render(surface, offset=(10, 20))

    first_call = surface.blit.call_args_list[0]
    _, kwargs = first_call

    _, (x, y) = first_call[0]

    assert x == 10
    assert y == 20


def test_callback_called():
    tileset = MockTileset()
    map_layout = MockMap()
    renderer = Renderer(tileset, map_layout)

    surface = MagicMock()
    callback = MagicMock()

    renderer.render(surface, callback=callback)

    assert callback.call_count == 4


def test_callback_exception_handling(capfd):
    tileset = MockTileset()
    map_layout = MockMap()
    renderer = Renderer(tileset, map_layout)

    surface = MagicMock()

    def bad_callback(*args):
        raise ValueError("fail")

    renderer.render(surface, callback=bad_callback)

    captured = capfd.readouterr()
    assert "Error in callback for tile" in captured.out


def test_invalid_tile_index_skipped():
    tileset = MockTileset()
    map_layout = MockMap()

    map_layout.layers[0][0][0] = (999, 0)

    renderer = Renderer(tileset, map_layout)
    surface = MagicMock()

    renderer.render(surface)

    assert surface.blit.call_count == 3


def test_out_of_bounds_layer_skipped():
    tileset = MockTileset()
    map_layout = MockMap()

    map_layout.layers = [
        [[(0, 0)]],
    ]

    renderer = Renderer(tileset, map_layout)
    surface = MagicMock()

    renderer.render(surface)

    assert surface.blit.call_count == 1
