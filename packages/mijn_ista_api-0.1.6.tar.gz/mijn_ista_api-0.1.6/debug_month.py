"""Debug script: call MonthValues and print raw response."""

import asyncio
import json
import aiohttp

USERNAME = "alialaei"
PASSWORD = "aSt9jyZQ2NtRnkg~"

BASE_URL = "https://mijn.ista.nl"
TIMEOUT = aiohttp.ClientTimeout(total=30)


async def main() -> None:
    async with aiohttp.ClientSession() as session:
        # 1. Authenticate
        print("Authenticating...")
        async with session.post(
            f"{BASE_URL}/api/Authorization/Authorize",
            json={"username": USERNAME, "password": PASSWORD, "LANG": "nl-NL"},
            timeout=TIMEOUT,
        ) as resp:
            print(f"  Auth status: {resp.status}")
            auth_data = await resp.json()
            jwt = auth_data.get("JWT")
            if not jwt:
                print("  ERROR: no JWT in response")
                print(json.dumps(auth_data, indent=2))
                return
            print("  JWT obtained OK")

        # 2. Get user values to find Cuids
        print("\nFetching UserValues...")
        async with session.post(
            f"{BASE_URL}/api/Values/UserValues",
            json={"JWT": jwt, "LANG": "nl-NL"},
            timeout=TIMEOUT,
        ) as resp:
            print(f"  Status: {resp.status}")
            user_data = await resp.json()
            jwt = user_data.get("JWT", jwt)
            cuids = [c["Cuid"] for c in user_data.get("Cus", [])]
            print(f"  Cuids found: {cuids}")

        # 3. Call MonthValues for each Cuid, show raw response
        for cuid in cuids:
            print(f"\nFetching MonthValues for {cuid}...")
            for attempt in range(6):
                async with session.post(
                    f"{BASE_URL}/api/Consumption/MonthValues",
                    json={"JWT": jwt, "LANG": "nl-NL", "Cuid": cuid},
                    timeout=TIMEOUT,
                ) as resp:
                    print(f"  Attempt {attempt + 1}: HTTP {resp.status}")
                    raw = await resp.text()
                    try:
                        data = json.loads(raw)
                        jwt = data.get("JWT", jwt)
                        sh = data.get("sh", "MISSING")
                        hs = data.get("hs", "MISSING")
                        mc = data.get("mc", [])
                        print(f"    sh={sh}, hs={hs}, mc entries={len(mc)}")
                        if mc:
                            print(f"    First mc entry keys: {list(mc[0].keys())}")
                            print(f"    First mc entry: y={mc[0].get('y')}, m={mc[0].get('m')}")
                        if sh != "MISSING" and hs != "MISSING":
                            if sh == 0 or hs >= sh:
                                print("    -> Done (all shards loaded)")
                                break
                            else:
                                print(f"    -> Shard {hs}/{sh}, waiting 2s...")
                                await asyncio.sleep(2)
                        else:
                            print("    -> No shard fields, full response:")
                            print(json.dumps({k: v for k, v in data.items() if k != "JWT"}, indent=2))
                            break
                    except json.JSONDecodeError:
                        print(f"    Non-JSON body: {raw[:200]}")
                        break


asyncio.run(main())
