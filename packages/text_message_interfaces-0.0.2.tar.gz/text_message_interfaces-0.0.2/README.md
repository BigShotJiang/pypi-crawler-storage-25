# Text Message Interfaces

Provides a unified interface for programmatically sending and receiving text messages in across different platforms.

## Installation
```bash
pip install text-message-interfaces
```

## Usage
```python
from text_message_interfaces import MessageInterface, Meshtastic
from threading import Event

def handle_message(message, sender, interface: MessageInterface):
    print(f"{sender}: {message}")
    interface.send_message(f"Recieved: \"{message}\"", sender)

interface: MessageInterface = Meshtastic()
interface.add_message_handler(handle_message)

try:
    Event().wait()
except KeyboardInterrupt:
    print("stopping...")
    interface.close()
```