from meshtastic.serial_interface import SerialInterface
from pubsub import pub
from text_message_interfaces.interfaces import MessageInterface
import logging
import time


class Meshtastic(MessageInterface[int]):
    """MessageInterface implementation for Meshtastic radio devices over serial."""

    def __init__(self):
        super().__init__()

        try:
            self.interface = SerialInterface()
            self.my_node = self.interface.myInfo.my_node_num
        except:
            raise ConnectionError("No Meshtastic device connected. Check that a device is plugged in and accessible over serial.")

        pub.subscribe(self._on_receive, "meshtastic.receive")

        logging.info(f"connected to meshtastic device {self.my_node}")

    def send_message(self, message, recipient):
        """Calls _split_message() and sends each chunk to recipient"""
        msg_chunks = self._split_message(message)
        for i in range(len(msg_chunks)):
            chunk = f"{msg_chunks[i]} ({i+1}/{len(msg_chunks)})" if len(msg_chunks) > 1 else msg_chunks[0]
            self.interface.sendText(chunk, destinationId=recipient)
            time.sleep(2)

    def close(self):
        """Closes Meshtastic interface"""
        self.interface.close()
        logging.info(f"disconnected from meshtastic device {self.my_node}")

    def _on_receive(self, packet):
        """Handles incoming Meshtastic packets"""

        # Only process messages with 'decoded' section available
        decoded = packet.get("decoded")
        if not decoded:
            return

        # Ignore nodeinfo & telemetry - only text messages
        portnum = decoded.get("portnum")
        if portnum != "TEXT_MESSAGE_APP":
            return

        # Respond only when message is addressed directly to us (not group chats)
        recipient = packet.get("to")
        if recipient != self.my_node:
            return

        # Only respond to messages where we know the sender
        sender = packet.get("from")
        if not sender:
            return

        text = decoded.get("text", "")

        # Call each subscribed handler with message and direct response function
        for handler in self._message_handlers:
            handler(
                message=text,
                sender=sender,
                interface=self
            )

    def _split_message(self, message: str) -> list[str]:
        """Splits message into list of strings where len(str) < 200 characters to fit meshtastic standard"""
        words = message.split()
        chunks = []
        current = []

        for word in words:
            # If adding this word would exceed the limit, start a new chunk
            if current and len(" ".join(current + [word])) > 192:  # 200 char limit; up to 8 seq chars _(xx/xx)
                chunks.append(" ".join(current))
                current = [word]
            else:
                current.append(word)

        if current:
            chunks.append(" ".join(current))

        return chunks
