from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Callable, List, Protocol


class MessageHandler[T](Protocol):
    """Definition for functions that that processes an incoming message"""
    def __call__(self, message: str, sender: T, interface: MessageInterface[T]) -> None:
        pass


class MessageInterface[T](ABC):
    """Abstract base for text message-based communication interfaces."""

    @abstractmethod
    def __init__(self):
        self._message_handlers: List[MessageHandler[T]] = []

    @abstractmethod
    def send_message(self, message: str, recipient: T):
        """Send a message to the specified recipient."""
        raise NotImplementedError(f"send_message() not implemented on interface {self.__class__.__name__}")

    @abstractmethod
    def close(self):
        """Close the interface and release resources."""
        raise NotImplementedError(f"close() not implemented on interface {self.__class__.__name__}")

    def add_message_handler(self, handler: MessageHandler[T]):
        """Register a handler to be called on incoming messages."""
        self._message_handlers.append(handler)
