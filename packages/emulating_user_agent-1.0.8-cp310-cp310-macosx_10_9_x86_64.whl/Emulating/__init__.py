"""
Emulating User Agent - Generate realistic and diverse user agents for desktop, mobile, and web automation testing.
"""

from .AndroidUserAgent import (
    get_random_agent,
    get_android_user_agent,
    get_random_android_device,
    list_android_devices,
)
from .DeskTopUserAgent import USER_AGENTS
from .UserAgentV6 import get_random_device, generate_barcelona_version
from .tracker import (
    set_tracking_url,
    set_tracking_enabled,
)

__version__ = "1.0.8"
__author__ = "Raz Andr"
__all__ = [
    "get_random_agent",
    "get_android_user_agent",
    "get_random_android_device",
    "list_android_devices",
    "USER_AGENTS",
    "get_random_device",
    "generate_barcelona_version",
    "set_tracking_url",
    "set_tracking_enabled",
]
