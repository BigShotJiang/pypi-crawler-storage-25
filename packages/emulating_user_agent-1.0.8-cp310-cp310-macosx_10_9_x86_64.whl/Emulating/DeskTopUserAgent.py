USER_AGENTS = {
    # ── Windows 11 (Avril 2026) ──────────────────────────────────────
    "Windows 11 - Chrome": {
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
        "viewport": (1920, 1046),
        "mobile": False
    },
    "Windows 11 - Edge": {
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        "viewport": (1920, 1046),
        "mobile": False
    },
    "Windows 11 - Firefox": {
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0",
        "viewport": (1920, 1046),
        "mobile": False
    },
    "Windows 10 - Chrome": {
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
        "viewport": (1536, 864),
        "mobile": False
    },

    # ── macOS Sequoia 15.4 / Sonoma 14.7 (Avril 2026) ────────────────
    "MacBook Pro M4 - Safari": {
        "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15",
        "viewport": (1728, 1116),
        "mobile": False
    },
    "MacBook Pro M3 - Chrome": {
        "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
        "viewport": (1728, 1116),
        "mobile": False
    },
    "MacBook Air M3 - Safari": {
        "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15",
        "viewport": (1440, 893),
        "mobile": False
    },
    "MacBook Air M3 - Chrome": {
        "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
        "viewport": (1440, 893),
        "mobile": False
    },

    # ── iMac / Studio (2026) ─────────────────────────────────────────
    "iMac M4 24 - Safari": {
        "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15",
        "viewport": (2560, 1664),
        "mobile": False
    },
}