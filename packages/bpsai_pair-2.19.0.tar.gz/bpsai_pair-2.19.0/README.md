# bpsai-pair

> AI-augmented pair programming framework with 200+ CLI commands

[![PyPI version](https://img.shields.io/pypi/v/bpsai-pair)](https://pypi.org/project/bpsai-pair/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)

## Overview

**bpsai-pair** (PairCoder) is a comprehensive AI pair programming framework that provides structured workflows, enforcement gates, and integrations to ensure AI agents follow proper development practices.

- **Planning & Task Management** — Sprint planning, task lifecycle, Trello sync, and budget tracking
- **Skill-Based Workflows** — 9 built-in skills for TDD, code review, releases, architecture, and more
- **Integration Hub** — Trello, GitHub, MCP servers, and Toggl time tracking
- **Architecture Enforcement** — File size limits, function boundaries, import caps, and auto-split suggestions
- **Telemetry & Feedback** — Session telemetry, self-calibrating estimation, anomaly detection
- **Workspace Orchestration** — Multi-project workspaces, cross-repo contract detection, impact analysis
- **Intelligence Pipeline** — Usage snapshots, value extraction scoring, tamper detection
- **Interactive Setup Wizard** — Web-based project configuration with AI-guided setup
- **Licensing & Security** — Tiered feature gating, secret scanning, containment mode
- **Quality Control** — Browser-based QC with spec format, execution runtime, and gate enforcement
- **Containment Mode** — Tiered file access control via PreToolUse hooks

## Installation

```bash
# Core installation
pip install bpsai-pair

# With integrations
pip install bpsai-pair[trello]      # Trello board sync
pip install bpsai-pair[github]      # GitHub PR management
pip install bpsai-pair[mcp]         # MCP server support
pip install bpsai-pair[all]         # All extras
```

## Quick Start

```bash
# Initialize a new project
bpsai-pair init

# Or use the interactive wizard
bpsai-pair wizard

# Check project status
bpsai-pair status

# Create a sprint plan
bpsai-pair plan new my-feature --type feature

# Start a task (with Trello sync)
bpsai-pair ttask start TRELLO-123

# Run architecture checks
bpsai-pair arch check

# Pack context for AI assistants
bpsai-pair pack
```

## Key Command Groups

| Group | Commands | Description |
|-------|----------|-------------|
| `plan` | 8 | Sprint planning, task creation, Trello sync |
| `task` | 12 | Task lifecycle, status updates, archival |
| `trello` / `ttask` | 27 | Trello board management, card workflows |
| `github` | 8 | PR creation, merge, auto-archive |
| `skill` | 8 | Workflow skills, export to Cursor/Windsurf |
| `license` | 10 | License management, feature gating |
| `telemetry` | 3 | Session telemetry, privacy config, export |
| `feedback` | 4 | Calibration, accuracy, task-type estimates |
| `workspace` | 5 | Multi-project orchestration, impact analysis |
| `arch` | 2 | Architecture enforcement, split suggestions |
| `budget` | 3 | Token budget tracking, task cost estimates |
| `security` | 4 | Secret scanning, containment mode |
| `qc` | 6 | Quality check specs, execution, reporting |
| `query` | 3 | Cross-agent state and telemetry queries |
| `engage` | 1 | Autonomous sprint execution from backlog |
| `containment` | 2 | File access enforcement and status |

## License Tiers

| Feature | Solo | Pro | Enterprise |
|---------|:----:|:---:|:----------:|
| Planning & tasks | Y | Y | Y |
| Skills & enforcement | Y | Y | Y |
| Setup wizard | Y | Y | Y |
| Telemetry & feedback | Y | Y | Y |
| Trello integration | | Y | Y |
| GitHub integration | | Y | Y |
| MCP servers | | Y | Y |
| Token budget & cost tracking | | Y | Y |
| Workspace orchestration | | Y | Y |
| Remote access & SSO | | | Y |

Check your license: `bpsai-pair license status`

## What's New in v2.17.0

**SQLite Telemetry (Sprint 40):**
- SQLite-backed telemetry stores replace flat-file storage with indexed databases
- JSONL-to-SQLite migration engine for legacy data
- Containment enforcement gate — PreToolUse hook for file access control
- Query skills framework — five A2A skills for cross-agent queries
- Signal emission from session hooks for downstream monitoring

**Quality Control Framework (Sprint 41):**
- QC spec format with element discovery, fill rules, and validation
- QC CLI commands: `bpsai-pair qc list|validate|report|init`
- QC agent and `/run-qc` slash command
- Cross-repo workspace task state queries
- Subagent context injection

**QC Runtime & Monitoring (Sprint 42):**
- End-to-end QC execution runtime with result persistence
- A2A query skills adapter and CNS monitoring signals
- QC telemetry trends in SQLite
- StopFailure hook for abnormal termination capture

## Documentation

- [Website & Docs](https://paircoder.ai)
- [Quick Start Guide](https://paircoder.ai/docs/getting-started/)

## Requirements

- Python 3.10 or higher
- Git (for project management features)

## Support

- Email: support@bpsaisoftware.com
