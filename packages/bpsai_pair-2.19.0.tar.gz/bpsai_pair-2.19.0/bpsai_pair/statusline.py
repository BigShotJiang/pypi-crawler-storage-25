"""PairCoder Intelligence Status Line for Claude Code.

Copyright (c) 2026 BPS AI Software. All rights reserved.

Surfaces PairCoder's intelligence pipeline data in the Claude Code status bar:
  - Active task ID and state machine position
  - Agent role (Navigator / Driver / Reviewer)
  - Sprint progress with visual bar
  - Session economics (cost, duration, diff stats)
  - Git branch and dirty state

Invoked by Claude Code via statusLine config in .claude/settings.json.
Receives session JSON on stdin, prints one ANSI-colored line to stdout.

Install:  bpsai-pair init / wizard / upgrade (automatic)
Manual:   bpsai-pair setup statusline [--theme serpent|ocean|forge|wizard|slate|minimal]
Remove:   bpsai-pair setup statusline --remove
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import NamedTuple

# State readers and git helpers (extracted for architecture compliance)
from .statusline_state import (  # noqa: F401  — re-exported for backward compat
    find_active_task,
    find_project_root,
    read_active_task,
    read_sprint_progress,
    write_active_role,
    detect_agent_role,
    read_theme_from_config,
    _git_branch,
    _git_dirty_count,
)


# ─── Theme System ───────────────────────────────────────────────────────────

class Theme(NamedTuple):
    """ANSI color scheme for status line segments."""

    primary: str    # Brand color (wizard emoji, task ID)
    accent: str     # Secondary (role indicator, sprint bar mid)
    info: str       # Tertiary (model name)
    warn: str       # Warning (cost, dirty files)
    crit: str       # Critical (unused for now, reserved)


# ANSI escape helpers
RST = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

THEMES: dict[str, Theme] = {
    "serpent": Theme("\033[32m", "\033[33m", "\033[36m", "\033[33m", "\033[31m"),
    "ocean":  Theme("\033[34m", "\033[96m", "\033[94m", "\033[33m", "\033[31m"),
    "forge":  Theme("\033[91m", "\033[33m", "\033[93m", "\033[33m", "\033[31m"),
    "wizard": Theme("\033[35m", "\033[95m", "\033[36m", "\033[33m", "\033[31m"),
    "slate":  Theme("\033[37m", "\033[90m", "\033[37m", "\033[33m", "\033[31m"),
    "minimal": Theme("\033[90m", "\033[90m", "\033[90m", "\033[90m", "\033[31m"),
}

THEME_NAMES = list(THEMES.keys())
DEFAULT_THEME = "serpent"


# ─── Formatting Helpers ──────────────────────────────────────────────────────

def fmt_cost(usd: float) -> str | None:
    """Format USD cost, returns None if negligible."""
    return f"${usd:.2f}" if usd > 0.001 else None


def fmt_duration(ms: int) -> str | None:
    """Format milliseconds as Xm Ys or Xs."""
    if ms <= 0:
        return None
    mins, secs = divmod(ms // 1000, 60)
    if mins > 0:
        return f"{mins}m{secs}s"
    return f"{secs}s"


def sprint_bar(done: int, total: int) -> tuple[str, int]:
    """Build progress bar. Returns (bar_string, percentage)."""
    pct = (done * 100 // total) if total > 0 else 0
    filled = pct // 20
    empty = 5 - filled
    bar = "\u25a0" * filled + "\u25a1" * empty
    return bar, pct


ROLE_SYMBOLS = {
    "nav": "\u25c7Nav",
    "drv": "\u26a1Drv",
    "rev": "\u2298Rev",
}


# ─── Segment Builders ────────────────────────────────────────────────────────

def _build_identity_segments(
    pc_root: Path | None, t: Theme, segments: list[str],
) -> None:
    """Append PairCoder identity and sprint progress segments."""
    if pc_root:
        state_file = pc_root / ".paircoder" / "context" / "state.md"
        task_id = find_active_task(pc_root)
        role = detect_agent_role(pc_root)
        done, total = (
            read_sprint_progress(state_file) if state_file.is_file() else (0, 0)
        )

        seg = f"{t.primary}{BOLD}\U0001f40dPairCoder{RST}"
        if task_id:
            seg += f" {BOLD}{task_id}{RST}"
        role_sym = ROLE_SYMBOLS.get(role or "", "")
        if role_sym:
            seg += f" {t.accent}{role_sym}{RST}"
        segments.append(seg)

        if total > 0:
            bar, pct = sprint_bar(done, total)
            bar_color = t.primary if pct >= 80 else t.accent if pct >= 40 else DIM
            segments.append(f"{bar_color}{bar}{RST} {DIM}{done}/{total}{RST}")
    else:
        segments.append(f"{DIM}\U0001f40dPairCoder{RST}")


def _build_git_segment(cwd: str, dir_name: str, t: Theme) -> str:
    """Build the directory + git branch/dirty segment."""
    work_dir = Path(cwd) if cwd else Path(".")
    git_seg = f"\U0001f4c1 {dir_name}"
    branch = _git_branch(work_dir)
    if branch:
        dirty = _git_dirty_count(work_dir)
        git_seg += f" {DIM}on{RST} {branch}"
        if dirty > 0:
            git_seg += f" {t.warn}{dirty}\u0394{RST}"
    return git_seg


def _build_econ_segment(
    cost_usd: float, duration_ms: int,
    lines_added: int, lines_removed: int, t: Theme,
) -> str | None:
    """Build session economics segment, or None if empty."""
    parts: list[str] = []
    cost_str = fmt_cost(cost_usd)
    if cost_str:
        parts.append(f"{t.warn}{cost_str}{RST}")
    dur_str = fmt_duration(duration_ms)
    if dur_str:
        parts.append(f"{DIM}\u23f1{dur_str}{RST}")
    if lines_added > 0 or lines_removed > 0:
        parts.append(f"{DIM}+{lines_added}/-{lines_removed}{RST}")
    return " ".join(parts) if parts else None


# ─── Main ────────────────────────────────────────────────────────────────────

def build_status_line(session_json: dict) -> str:
    """Build the full status line string from Claude Code session data."""
    model = session_json.get("model", {}).get("display_name", "\u2014")
    cwd = session_json.get("workspace", {}).get("current_dir", "")
    project_dir = session_json.get("workspace", {}).get("project_dir", "")
    cost_data = session_json.get("cost", {})
    cost_usd = float(cost_data.get("total_cost_usd", 0))
    duration_ms = int(cost_data.get("total_duration_ms", 0))
    lines_added = int(cost_data.get("total_lines_added", 0))
    lines_removed = int(cost_data.get("total_lines_removed", 0))
    dir_name = os.path.basename(cwd) if cwd else "?"

    pc_root = find_project_root(cwd or project_dir or ".")

    theme_name = os.environ.get("PAIRCODER_THEME", "")
    if not theme_name and pc_root:
        theme_name = read_theme_from_config(pc_root) or ""
    if theme_name not in THEMES:
        theme_name = DEFAULT_THEME
    t = THEMES[theme_name]

    segments: list[str] = []
    _build_identity_segments(pc_root, t, segments)
    segments.append(f"{t.info}{model}{RST}")
    segments.append(_build_git_segment(cwd, dir_name, t))
    econ = _build_econ_segment(cost_usd, duration_ms, lines_added, lines_removed, t)
    if econ:
        segments.append(econ)

    sep = f" {DIM}\u2502{RST} "
    return sep.join(segments)


def main() -> None:
    """Entry point: read JSON from stdin, print status line to stdout."""
    try:
        session_data = json.load(sys.stdin)
    except (json.JSONDecodeError, ValueError):
        print(f"{DIM}\U0001f40dPairCoder{RST}")
        return

    line = build_status_line(session_data)
    print(line)


if __name__ == "__main__":
    main()
