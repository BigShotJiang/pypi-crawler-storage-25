"""PairCoder state readers and git helpers for status line.

Extracted from statusline.py to stay within architecture function limits.
Functions here read/write PairCoder project state (state.md, session.json,
config.yaml) and query git for branch/dirty information.
"""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path


# ─── Regex Patterns ──────────────────────────────────────────────────────────

TASK_ID_RE = re.compile(
    r"(?:CLI-|API-|WEB-)?T\d+\.\d+(?:\.\d+)?|TRELLO-[A-Za-z0-9]+"
)

ACTIVE_MARKERS_RE = re.compile(
    r"in.progress|🔨|working\s+on", re.IGNORECASE
)

CHECKBOX_RE = re.compile(r"^\s*-\s*\[[ x]\]", re.MULTILINE)
CHECKED_RE = re.compile(r"^\s*-\s*\[x\]", re.MULTILINE)


# ─── PairCoder State Readers ─────────────────────────────────────────────────

def find_project_root(start: str) -> Path | None:
    """Walk upward from start to find .paircoder/ directory."""
    current = Path(start).resolve()
    while current != current.parent:
        if (current / ".paircoder").is_dir():
            return current
        current = current.parent
    return None


def read_active_task(state_path: Path) -> str | None:
    """Extract the active task ID from state.md."""
    try:
        text = state_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None

    for line in text.splitlines():
        if ACTIVE_MARKERS_RE.search(line):
            match = TASK_ID_RE.search(line)
            if match:
                return match.group()
    return None


def find_active_task(project_root: Path) -> str | None:
    """Find active task ID: task files first, then state.md fallback.

    Scans .paircoder/tasks/*.task.md for status: in_progress in YAML
    frontmatter. Falls back to read_active_task(state.md) if no task
    files match.
    """
    pc = project_root / ".paircoder"
    tasks_dir = pc / "tasks"

    # Primary: scan task files for in_progress status, sorted by mtime desc
    if tasks_dir.is_dir():
        active: list[tuple[float, str]] = []
        for task_file in sorted(
            tasks_dir.glob("*.task.md"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        ):
            try:
                content = task_file.read_text(encoding="utf-8")
                if "status: in_progress" in content:
                    for line in content.splitlines():
                        stripped = line.strip()
                        if stripped.startswith("id:"):
                            tid = stripped.split(":", 1)[1].strip()
                            active.append((task_file.stat().st_mtime, tid))
                            break
            except (OSError, UnicodeDecodeError):
                continue
        if active:
            newest_id = active[0][1]
            extra = len(active) - 1
            return f"{newest_id} +{extra}" if extra else newest_id

    # Fallback: scan state.md with marker regex
    state_file = pc / "context" / "state.md"
    if state_file.is_file():
        return read_active_task(state_file)

    return None


def find_in_progress_tasks(project_root: Path) -> list[str]:
    """Find all task IDs with status: in_progress in task files.

    Scans .paircoder/tasks/*.task.md for YAML frontmatter containing
    ``status: in_progress``. Returns a list of task IDs (may be empty).
    """
    tasks_dir = project_root / ".paircoder" / "tasks"
    if not tasks_dir.is_dir():
        return []

    result: list[str] = []
    for task_file in sorted(tasks_dir.glob("*.task.md")):
        try:
            content = task_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if "status: in_progress" not in content:
            continue
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("id:"):
                task_id = stripped.split(":", 1)[1].strip()
                if task_id:
                    result.append(task_id)
                break
    return result


def read_sprint_progress(state_path: Path) -> tuple[int, int]:
    """Count (done, total) checkbox tasks in state.md."""
    try:
        text = state_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return 0, 0

    total = len(CHECKBOX_RE.findall(text))
    done = len(CHECKED_RE.findall(text))
    return done, total


def write_active_role(project_root: Path, role: str | None) -> None:
    """Write active agent role to session.json for status line display."""
    session_file = project_root / ".paircoder" / "session.json"
    session_file.parent.mkdir(parents=True, exist_ok=True)

    data: dict = {}
    if session_file.is_file():
        try:
            data = json.loads(session_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    if role:
        data["active_role"] = role
    else:
        data.pop("active_role", None)

    session_file.write_text(json.dumps(data, indent=2), encoding="utf-8")


def detect_agent_role(project_root: Path) -> str | None:
    """Detect active agent role from session state or branch name."""
    session_file = project_root / ".paircoder" / "session.json"
    if session_file.is_file():
        try:
            data = json.loads(session_file.read_text(encoding="utf-8"))
            role = data.get("active_role", "")
            if role:
                return role
        except (json.JSONDecodeError, OSError):
            pass

    branch = _git_branch(project_root)
    if not branch:
        return None

    if any(kw in branch for kw in ("plan", "design", "spike", "research")):
        return "nav"
    elif any(kw in branch for kw in ("review", "pr/", "hotfix")):
        return "rev"
    elif any(kw in branch for kw in ("feature/", "fix/", "refactor/")):
        return "drv"
    return None


def read_theme_from_config(project_root: Path) -> str | None:
    """Read statusline theme from config.yaml (simple grep, no yaml dep)."""
    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.is_file():
        return None
    try:
        text = config_path.read_text(encoding="utf-8")
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("theme:") and "statusline" in text[:text.index(line)]:
                return stripped.split(":", 1)[1].strip().strip("'\"")
    except (OSError, ValueError):
        pass
    return None


# ─── Git Helpers ─────────────────────────────────────────────────────────────

def _git_branch(cwd: Path) -> str | None:
    """Get current git branch name without triggering index refresh."""
    try:
        result = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=str(cwd), capture_output=True, text=True, timeout=2,
        )
        branch = result.stdout.strip()
        return branch if branch else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def _git_dirty_count(cwd: Path) -> int:
    """Count files with changes (staged + unstaged), skip untracked."""
    try:
        result = subprocess.run(
            ["git", "--no-optional-locks", "status", "--porcelain", "-uno"],
            cwd=str(cwd), capture_output=True, text=True, timeout=2,
        )
        return len([l for l in result.stdout.splitlines() if l.strip()])
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return 0
