"""Init commands — re-export shim for backward compatibility.

Tests mock at ``bpsai_pair.commands.init_commands.XXX``, so all public names
must remain importable from this module.
"""
from .init_repo import (  # noqa: F401
    init_command,
    repo_root,
    console,
    get_tier,
    get_current_tier_display_name,
    _check_wizard_dependencies,
    _launch_wizard,
    _select_ci_workflow,
    _has_unrendered_cookiecutter_template,
    ensure_v2_config,
    Config,
)
from .init_feature import feature_command  # noqa: F401
from ..core.presets import get_preset, get_preset_names, list_presets  # noqa: F401
