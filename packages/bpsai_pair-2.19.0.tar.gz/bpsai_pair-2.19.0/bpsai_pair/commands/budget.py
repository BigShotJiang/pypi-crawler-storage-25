"""Budget commands for token estimation and checking.

Part of Sprint 25 Token Budget System (EPIC-003 continuation).
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..licensing import require_feature

_budget_logger = logging.getLogger(__name__)

# Initialize Rich console
console = Console()


def print_json(data: dict) -> None:
    """Print JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


# Try relative imports first, fall back to absolute
try:
    from ..core import ops
    from ..tokens import (
        count_file_tokens,
        estimate_task_tokens,
        estimate_from_task_file,
        get_budget_status,
        MODEL_LIMITS,
        DEFAULT_THRESHOLDS,
        load_thresholds_from_config,
    )
except ImportError:
    from bpsai_pair.core import ops
    from bpsai_pair.tokens import (
        count_file_tokens,
        estimate_from_task_file,
        get_budget_status,
        MODEL_LIMITS,
        DEFAULT_THRESHOLDS,
        load_thresholds_from_config,
    )

# Default model fallback when config not available
_DEFAULT_MODEL = "claude-sonnet-4-6"


def _load_default_model() -> str:
    """Load default model from config.yaml if available.

    Returns models.driver from config, falling back to claude-sonnet-4-6.
    """
    try:
        import yaml
        root = ops.find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            return config.get("models", {}).get("driver", _DEFAULT_MODEL)
    except Exception:
        pass
    return _DEFAULT_MODEL


def _get_default_threshold() -> int:
    """Get default warning threshold from config.yaml if available."""
    thresholds = load_thresholds_from_config()
    return thresholds.get("warning", 75)


def repo_root() -> Path:
    """Get repo root with better error message."""
    p = ops.find_project_root()
    if not ops.GitOps.is_repo(p):
        console.print(
            "[red]Error: Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists)."
        )
        raise typer.Exit(1)
    return p


def _find_task_file(task_id: str, root: Path) -> Optional[Path]:
    """Find task file by ID.

    Searches in order:
    1. Exact filename match (``{task_id}.task.md``)
    2. Filename substring match (case-insensitive)
    3. YAML frontmatter ``id:`` field scan (format-agnostic)
    """
    tasks_dir = root / ".paircoder" / "tasks"

    # Quick exact-name checks
    for name in (task_id, f"TASK-{task_id}", task_id.upper()):
        path = tasks_dir / f"{name}.task.md"
        if path.exists():
            return path

    if not tasks_dir.exists():
        return None

    # Filename substring match (fast)
    for f in tasks_dir.glob("*.task.md"):
        if task_id.lower() in f.stem.lower():
            return f

    # Frontmatter id: field scan (catches mismatched filenames)
    _budget_logger.debug(
        "Frontmatter fallback: scanning all task files for id=%s", task_id,
    )
    from ..core.constants import discover_task_ids
    id_map = discover_task_ids(tasks_dir)
    return id_map.get(task_id)


_MODEL_COST_PER_1K = {
    "opus": 0.005,    # Opus 4.5/4.6: $5/MTok input
    "sonnet": 0.003,  # Sonnet 4.0/4.5: $3/MTok input
    "haiku": 0.001,   # Haiku 4.5: $1/MTok input
}


def _estimate_cost(tokens: int, model: str = "sonnet") -> float:
    """Estimate cost based on model. Uses input pricing as a conservative proxy."""
    model_lower = (model or "sonnet").lower()
    for key, rate in _MODEL_COST_PER_1K.items():
        if key in model_lower:
            return (tokens / 1000) * rate
    return (tokens / 1000) * _MODEL_COST_PER_1K["sonnet"]


def _format_tokens(tokens: int) -> str:
    """Format token count with thousands separator."""
    return f"{tokens:,}"


def _status_icon(status: str) -> str:
    """Get status icon for display."""
    icons = {
        "ok": "[green]OK[/green]",
        "info": "[blue]INFO[/blue]",
        "warning": "[yellow]WARNING[/yellow]",
        "critical": "[red]CRITICAL[/red]",
    }
    return icons.get(status, status)


# Budget sub-app
app = typer.Typer(
    help="Token budget estimation and checking",
    context_settings={"help_option_names": ["-h", "--help"]}
)


@app.command("estimate")
@require_feature("token_budget")
def budget_estimate(
    task_id: Optional[str] = typer.Argument(None, help="Task ID to estimate"),
    files: list[str] = typer.Option([], "-f", "--file", help="Specific files to include"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model for limit (default: from config)"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Estimate token usage for a task or files.

    Examples:
        bpsai-pair budget estimate T25.8
        bpsai-pair budget estimate -f src/main.py -f src/utils.py
        bpsai-pair budget estimate T25.8 --json
    """
    root = repo_root()

    # Resolve model from config if not specified
    if model is None:
        model = _load_default_model()

    if task_id:
        # Estimate from task file
        task_path = _find_task_file(task_id, root)
        if not task_path:
            console.print(f"[red]Error: Task {task_id} not found[/red]")
            raise typer.Exit(2)

        estimate = estimate_from_task_file(task_path)
        if not estimate:
            console.print(f"[red]Error: Could not parse task file {task_path}[/red]")
            raise typer.Exit(2)

        # Get task title from file
        task_title = task_id
        try:
            content = task_path.read_text(encoding="utf-8")
            for line in content.split('\n'):
                if line.startswith('title:'):
                    task_title = f"{task_id} - {line.split(':', 1)[1].strip()}"
                    break
        except Exception:
            pass

        status = get_budget_status(estimate.total, model)

        if json_out:
            print_json({
                "task_id": task_id,
                "task_title": task_title,
                "breakdown": {
                    "base_context": estimate.base_context,
                    "task_file": estimate.task_file,
                    "source_files": estimate.source_files,
                    "estimated_output": estimate.estimated_output,
                    "total": estimate.total,
                },
                "budget": {
                    "percent": estimate.budget_percent,
                    "status": status.status,
                    "limit": status.limit,
                    "remaining": status.remaining,
                },
            })
        else:
            console.print(f"\n[bold]Task:[/bold] {task_title}")
            console.print()

            table = Table(title="Token Breakdown", show_header=False, box=None)
            table.add_column("Component", style="dim")
            table.add_column("Tokens", justify="right")

            table.add_row("Base context", _format_tokens(estimate.base_context))
            table.add_row("Task file", _format_tokens(estimate.task_file))
            table.add_row("Source files", _format_tokens(estimate.source_files))
            table.add_row("Est. output", _format_tokens(estimate.estimated_output))
            table.add_row("─" * 20, "─" * 10)
            table.add_row(
                "[bold]Total[/bold]",
                f"[bold]{_format_tokens(estimate.total)}[/bold] ({estimate.budget_percent}%)"
            )

            console.print(table)
            console.print()
            console.print(f"Status: {_status_icon(status.status)} - {status.message}")

    elif files:
        # Estimate from specific files
        file_paths = [Path(f) for f in files]
        total_tokens = sum(count_file_tokens(root / f) for f in file_paths)
        status = get_budget_status(total_tokens, model)

        if json_out:
            file_breakdown = {
                str(f): count_file_tokens(root / f) for f in file_paths
            }
            print_json({
                "files": file_breakdown,
                "total": total_tokens,
                "budget": {
                    "percent": status.percent,
                    "status": status.status,
                },
            })
        else:
            console.print("\n[bold]File Token Estimate[/bold]\n")

            table = Table(show_header=True, header_style="bold")
            table.add_column("File")
            table.add_column("Tokens", justify="right")

            for f in file_paths:
                tokens = count_file_tokens(root / f)
                table.add_row(str(f), _format_tokens(tokens))

            table.add_row("─" * 30, "─" * 10, style="dim")
            table.add_row("[bold]Total[/bold]", f"[bold]{_format_tokens(total_tokens)}[/bold]")

            console.print(table)
            console.print()
            console.print(f"Status: {_status_icon(status.status)}")

    else:
        console.print("[yellow]Please provide a task ID or files to estimate.[/yellow]")
        console.print("\nExamples:")
        console.print("  bpsai-pair budget estimate T25.8")
        console.print("  bpsai-pair budget estimate -f src/main.py -f src/utils.py")
        raise typer.Exit(1)


@app.command("status")
@require_feature("token_budget")
def budget_status(
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model for limit (default: from config)"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show current session budget status.

    Displays the model's context limit and current thresholds.
    Model and thresholds are loaded from config.yaml if available.
    """
    # Resolve model from config if not specified
    if model is None:
        model = _load_default_model()

    limit = MODEL_LIMITS.get(model, 200000)

    # Load thresholds from config (falls back to defaults if not found)
    thresholds = load_thresholds_from_config()

    if json_out:
        print_json({
            "model": model,
            "limit": limit,
            "thresholds": thresholds,
        })
    else:
        console.print("\n[bold]Budget Status[/bold]")
        console.print(f"\n  Model: {model}")
        console.print(f"  Context limit: {_format_tokens(limit)} tokens")
        console.print()
        console.print("  [bold]Thresholds:[/bold]")
        console.print(f"    Info:     {thresholds['info']}% ({_format_tokens(int(limit * thresholds['info'] / 100))} tokens)")
        console.print(f"    Warning:  {thresholds['warning']}% ({_format_tokens(int(limit * thresholds['warning'] / 100))} tokens)")
        console.print(f"    Critical: {thresholds['critical']}% ({_format_tokens(int(limit * thresholds['critical'] / 100))} tokens)")


@app.command("check")
@require_feature("token_budget")
def budget_check(
    task_id: str = typer.Argument(..., help="Task ID to check"),
    threshold: Optional[int] = typer.Option(None, "--threshold", "-t", help="Warning threshold % (default: from config)"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model for limit (default: from config)"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Pre-flight budget check for a task.

    Exit codes:
        0: Under threshold
        1: Over threshold
        2: Task not found or error
    """
    root = repo_root()

    # Resolve model and threshold from config if not specified
    if model is None:
        model = _load_default_model()
    if threshold is None:
        threshold = _get_default_threshold()

    task_path = _find_task_file(task_id, root)
    if not task_path:
        if json_out:
            print_json({"error": f"Task {task_id} not found", "exit_code": 2})
        else:
            console.print(f"[red]Error: Task {task_id} not found[/red]")
        raise typer.Exit(2)

    estimate = estimate_from_task_file(task_path)
    if not estimate:
        if json_out:
            print_json({"error": f"Could not parse task {task_id}", "exit_code": 2})
        else:
            console.print(f"[red]Error: Could not parse task {task_id}[/red]")
        raise typer.Exit(2)

    status = get_budget_status(estimate.total, model)
    over_threshold = estimate.budget_percent >= threshold

    cost = _estimate_cost(estimate.total, model)

    if json_out:
        print_json({
            "task_id": task_id,
            "estimated_tokens": estimate.total,
            "estimated_cost_usd": round(cost, 2),
            "budget_percent": estimate.budget_percent,
            "threshold": threshold,
            "over_threshold": over_threshold,
            "status": status.status,
            "exit_code": 1 if over_threshold else 0,
        })
    else:
        if over_threshold:
            console.print(f"[red]OVER THRESHOLD[/red]: {task_id}")
            console.print(f"  Estimated: {_format_tokens(estimate.total)} tokens ({estimate.budget_percent}%) ~${cost:.2f}")
            console.print(f"  Threshold: {threshold}%")
            console.print()
            console.print("[yellow]Consider breaking this task into smaller parts.[/yellow]")
        else:
            console.print(f"[green]OK[/green]: {task_id}")
            console.print(f"  Estimated: {_format_tokens(estimate.total)} tokens ({estimate.budget_percent}%) ~${cost:.2f}")
            console.print(f"  Threshold: {threshold}%")

    raise typer.Exit(1 if over_threshold else 0)
