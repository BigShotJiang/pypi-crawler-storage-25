"""Containment commands — re-export shim.

Session entry logic lives in containment_session.py.
Checkpoint management lives in containment_checkpoint.py.
"""
from .containment_session import (
    contained_auto,
    claude666,
    _cleanup_containment,
    _active_containment_manager,  # noqa: mutable — accessed via _cmds indirection, not direct import
    repo_root,
    ROBOT_DEVIL_ART,
    console,
)
import subprocess  # noqa: F401 — re-exported for test mock compatibility
from ..core import ops  # noqa: F401 — re-exported for test mock compatibility
from .containment_checkpoint import (
    containment_app,
    containment_rollback,
    containment_list,
    containment_cleanup,
)

__all__ = [
    "contained_auto",
    "claude666",
    "containment_app",
    "containment_rollback",
    "containment_list",
    "containment_cleanup",
    "_cleanup_containment",
    "_active_containment_manager",
    "repo_root",
    "ROBOT_DEVIL_ART",
    "console",
]
