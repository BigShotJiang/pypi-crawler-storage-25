"""Subscription management commands.

Commands for managing PairCoder subscriptions via Stripe Billing Portal.
"""

from __future__ import annotations

import json
import webbrowser
from typing import Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table

from bpsai_pair.licensing import (
    DEFAULT_API_URL,
    load_license,
)
from bpsai_pair.licensing.machine import get_machine_id

console = Console()

app = typer.Typer(
    help="Manage your PairCoder subscription",
    no_args_is_help=True,
)


def _get_license_and_machine() -> tuple[dict, str] | None:
    """Get license data and machine ID.

    Returns:
        Tuple of (license_dict, machine_id) or None if license not found.
    """
    signed_license = load_license()
    if not signed_license:
        console.print("[red]No license installed.[/red]")
        console.print("[dim]Run: bpsai-pair license install <path>[/dim]")
        return None

    # Convert to dict format expected by API
    license_data = {
        "payload": signed_license.payload.model_dump(),
        "signature": signed_license.signature,
    }

    machine_id = get_machine_id()
    return license_data, machine_id


def _call_portal_api(
    license_id: str,
    machine_id: str,
    return_url: str = "https://paircoder.ai",
    api_url: str = DEFAULT_API_URL,
) -> dict | None:
    """Call the billing portal API endpoint.

    Args:
        license_id: The license UUID.
        machine_id: The machine ID.
        return_url: URL to return to after portal session.
        api_url: API base URL.

    Returns:
        API response dict or None on error.
    """
    url = f"{api_url}/subscriptions/portal-session"
    payload = {
        "license_id": license_id,
        "machine_id": machine_id,
        "return_url": return_url,
    }

    try:
        with httpx.Client(timeout=10) as client:
            response = client.post(url, json=payload)
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                console.print("[red]Machine not activated for this license.[/red]")
                console.print("[dim]Run: bpsai-pair license activate[/dim]")
                return None
            elif response.status_code == 400:
                error = response.json().get("detail", "Unknown error")
                console.print(f"[red]Error: {error}[/red]")
                return None
            else:
                console.print(f"[red]API error: {response.status_code}[/red]")
                return None
    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        console.print("[dim]Check your internet connection and try again.[/dim]")
        return None


def _call_status_api(
    license_id: str,
    machine_id: str,
    api_url: str = DEFAULT_API_URL,
) -> dict | None:
    """Call the subscription status API endpoint.

    Args:
        license_id: The license UUID.
        machine_id: The machine ID.
        api_url: API base URL.

    Returns:
        API response dict or None on error.
    """
    url = f"{api_url}/subscriptions/status"
    payload = {
        "license_id": license_id,
        "machine_id": machine_id,
    }

    try:
        with httpx.Client(timeout=10) as client:
            response = client.post(url, json=payload)
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                console.print("[red]Machine not activated for this license.[/red]")
                console.print("[dim]Run: bpsai-pair license activate[/dim]")
                return None
            else:
                console.print(f"[red]API error: {response.status_code}[/red]")
                return None
    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        return None


@app.command("manage")
def manage_subscription(
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Don't open browser, just print URL"
    ),
    return_url: str = typer.Option(
        "https://paircoder.ai", "--return-url", help="URL to return to after portal"
    ),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Open the Stripe Billing Portal to manage your subscription.

    In the portal you can:
    - Update your payment method
    - View invoices and billing history
    - Cancel your subscription
    - Download receipts

    Example:
        bpsai-pair subscription manage
    """
    result = _get_license_and_machine()
    if not result:
        raise typer.Exit(1)

    license_data, machine_id = result
    license_id = license_data.get("payload", {}).get("license_id")

    if not license_id:
        console.print("[red]Invalid license format - missing license_id[/red]")
        raise typer.Exit(1)

    console.print("[dim]Requesting billing portal session...[/dim]")

    response = _call_portal_api(str(license_id), machine_id, return_url)
    if not response:
        raise typer.Exit(1)

    portal_url = response.get("portal_url")
    if not portal_url:
        console.print("[red]No portal URL returned[/red]")
        raise typer.Exit(1)

    if as_json:
        console.print(json.dumps({"portal_url": portal_url}, indent=2))
        return

    if no_browser:
        console.print(f"\n[bold]Billing Portal URL:[/bold]\n{portal_url}")
        return

    # Open in browser
    console.print("[green]Opening billing portal in your browser...[/green]")
    try:
        webbrowser.open(portal_url)
        console.print(f"\n[dim]If browser didn't open, visit:[/dim]\n{portal_url}")
    except Exception:
        console.print(f"\n[yellow]Could not open browser. Visit:[/yellow]\n{portal_url}")


@app.command("status")
def subscription_status(
    as_json: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show your subscription status.

    Displays:
    - Current tier and license type
    - Subscription status (active, cancelled, etc.)
    - Renewal/expiration date
    - Machine slot usage

    Example:
        bpsai-pair subscription status
    """
    result = _get_license_and_machine()
    if not result:
        raise typer.Exit(1)

    license_data, machine_id = result
    license_id = license_data.get("payload", {}).get("license_id")

    if not license_id:
        console.print("[red]Invalid license format - missing license_id[/red]")
        raise typer.Exit(1)

    response = _call_status_api(str(license_id), machine_id)
    if not response:
        # Fall back to local license data
        console.print("[yellow]Could not fetch live status, showing local data:[/yellow]\n")
        payload = license_data.get("payload", {})
        response = {
            "tier": payload.get("tier", "unknown"),
            "type": payload.get("type", "unknown"),
            "status": "unknown",
            "renewal_date": payload.get("expires_at"),
            "cancel_at_period_end": False,
            "machines_used": len(payload.get("activated_machines", [])),
            "machines_allowed": payload.get("max_machines", 1),
        }

    if as_json:
        console.print(json.dumps(response, indent=2))
        return

    # Display as table
    table = Table(title="Subscription Status", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="white")

    # Tier with styling
    tier = response.get("tier", "unknown").title()
    tier_style = {
        "Solo": "[white]",
        "Pro": "[green]",
        "Enterprise": "[magenta]",
    }.get(tier, "[white]")
    table.add_row("Tier", f"{tier_style}{tier}[/]")

    # Type
    license_type = response.get("type", "unknown").replace("_", " ").title()
    table.add_row("Type", license_type)

    # Status with styling
    status = response.get("status", "unknown")
    status_style = {
        "active": "[green]Active[/]",
        "cancelled": "[yellow]Cancelled[/]",
        "past_due": "[red]Past Due[/]",
        "expired": "[red]Expired[/]",
        "revoked": "[red]Revoked[/]",
    }.get(status, status)
    table.add_row("Status", status_style)

    # Cancellation notice
    if response.get("cancel_at_period_end"):
        table.add_row("", "[yellow]⚠ Cancels at period end[/]")

    # Renewal date
    renewal = response.get("renewal_date")
    if renewal:
        # Parse ISO date and format nicely
        try:
            from datetime import datetime
            dt = datetime.fromisoformat(renewal.replace("Z", "+00:00"))
            formatted = dt.strftime("%B %d, %Y")
            if response.get("cancel_at_period_end"):
                table.add_row("Expires", formatted)
            else:
                table.add_row("Renews", formatted)
        except Exception:
            table.add_row("Renewal Date", renewal)

    # Machine slots
    used = response.get("machines_used", 0)
    allowed = response.get("machines_allowed", 1)
    slots_text = f"{used}/{allowed}"
    if used >= allowed:
        slots_text = f"[yellow]{slots_text}[/] (at limit)"
    table.add_row("Machine Slots", slots_text)

    console.print(table)

    # Show management hint
    console.print("\n[dim]To manage your subscription:[/dim]")
    console.print("  bpsai-pair subscription manage")


@app.callback(invoke_without_command=True)
def subscription_callback(ctx: typer.Context):
    """Subscription management commands."""
    if ctx.invoked_subcommand is None:
        # Show help when no subcommand
        console.print(ctx.get_help())
