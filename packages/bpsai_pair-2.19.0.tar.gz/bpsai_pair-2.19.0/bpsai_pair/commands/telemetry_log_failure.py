"""Telemetry log-failure command -- called by StopFailure hook."""

from __future__ import annotations

import logging

import typer

from ..core.ops import find_paircoder_dir

logger = logging.getLogger(__name__)


def _normalize_trigger(raw: str) -> str:
    """Strip whitespace, cap length, remove non-printable chars.

    isprintable() rejects control characters including ESC (0x1B),
    preventing ANSI escape injection in persisted signals.
    """
    cleaned = raw.strip()[:256]
    return "".join(c for c in cleaned if c.isprintable())


def register_log_failure(app: typer.Typer) -> None:
    """Register log-failure subcommand on telemetry app."""

    @app.command("log-failure")
    def log_failure(
        trigger: str = typer.Option(
            "", "--trigger", help="Stop reason from $CLAUDE_STOP_REASON"
        ),
        quiet: bool = typer.Option(False, "--quiet", help="Suppress output"),
    ) -> None:
        """Log an API failure signal to telemetry. Called by StopFailure hook."""
        try:
            from ..telemetry.signal_emitter import SignalEmitter

            trigger = _normalize_trigger(trigger)
            pd = find_paircoder_dir()
            project_root = pd.parent
            emitter = SignalEmitter(project_root)
            emitter.emit_api_failure(
                stop_reason=trigger,
                error_detail="StopFailure hook triggered",
                session_id="",
            )
            if not quiet:
                typer.echo(f"Logged api_failure signal: {trigger}")
        except Exception as e:
            logger.debug("Failed to log API failure: %s", e)
            if not quiet:
                typer.echo(f"Warning: Could not log failure: {e}", err=True)
