"""bpsai-pair engage — autonomous sprint execution command."""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any

import typer

from bpsai_pair.orchestration.backlog_parser import BacklogParser
from bpsai_pair.orchestration.backlog_materializer import materialize

logger = logging.getLogger(__name__)


def engage(
    backlog: str = typer.Argument(..., help="Path to backlog markdown file"),
    sprint: str = typer.Option("", "--sprint", "-s", help="Sprint number"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show plan without executing"),
    json_out: bool = typer.Option(False, "--json", help="JSON output"),
    max_parallel: int = typer.Option(3, "--max-parallel", help="Max parallel tasks"),
) -> None:
    """Parse a backlog and autonomously execute the sprint."""
    backlog_path = Path(backlog)
    if not backlog_path.exists():
        typer.echo(f"Error: Backlog file not found: {backlog}", err=True)
        raise typer.Exit(1)

    parsed = BacklogParser.parse(backlog_path)

    if not parsed.tasks:
        typer.echo("No tasks found in backlog.")
        raise typer.Exit(1)

    if dry_run:
        _show_dry_run(parsed, json_out)
        return

    if not sprint:
        sprint = _infer_sprint(parsed)

    result = _run_engage(backlog_path, parsed, sprint, max_parallel)

    if json_out:
        typer.echo(json.dumps(result, indent=2))
    else:
        _show_result(result)


def _show_dry_run(parsed: Any, json_out: bool) -> None:
    """Display dry run plan without executing."""
    total_cx = sum(t.complexity for t in parsed.tasks)
    phases = {t.phase for t in parsed.tasks}

    if json_out:
        typer.echo(json.dumps({
            "dry_run": True,
            "tasks": len(parsed.tasks),
            "total_complexity": total_cx,
            "phases": len(phases),
        }, indent=2))
    else:
        typer.echo(f"Dry run — {len(parsed.tasks)} tasks, {total_cx} cx, "
                   f"{len(phases)} phase(s)")
        for task in parsed.tasks:
            typer.echo(f"  Phase {task.phase}: {task.id} — {task.title} "
                       f"(Cx: {task.complexity}, {task.priority})")


def _run_engage(
    backlog_path: Path, parsed: Any, sprint: str, max_parallel: int,
) -> dict[str, Any]:
    """Execute the full engage pipeline."""
    from bpsai_pair.orchestration.sprint_executor import (
        SprintConfig, SprintExecutor,
    )
    from bpsai_pair.orchestration.plan_graph import PlanGraphBuilder
    from bpsai_pair.orchestration.headless_runner import _make_headless_runner
    from bpsai_pair.core.utils import repo_root

    project_root = repo_root()
    plan_path = materialize(project_root, parsed, sprint)
    plan_id = plan_path.stem.replace(".plan", "")

    graph = PlanGraphBuilder(project_root).build(plan_id)
    config = SprintConfig(max_parallel=max_parallel)
    task_runner = _make_headless_runner(
        project_root, permission_mode="bypassPermissions",
    )
    executor = SprintExecutor(
        project_root, graph, config, task_runner=task_runner,
    )
    result = executor.execute()

    return {
        "completed": result.completed_tasks,
        "failed": result.failed_tasks,
        "blocked": result.blocked_tasks,
        "phases_completed": result.phases_completed,
        "pr_url": None,
    }


def _show_result(result: dict[str, Any]) -> None:
    """Display engage result to terminal."""
    done = len(result["completed"])
    failed = len(result["failed"])
    blocked = len(result["blocked"])
    typer.echo(f"Sprint complete: {done} done, {failed} failed, "
               f"{blocked} blocked")
    if result.get("pr_url"):
        typer.echo(f"PR: {result['pr_url']}")


def _infer_sprint(parsed: Any) -> str:
    """Infer sprint number from first task ID."""
    import re

    if parsed.tasks:
        # Strip alpha prefix, keep sprint number only (not task seq)
        match = re.match(r"[A-Za-z]+(\d+)", parsed.tasks[0].id)
        if match:
            return match.group(1)
    return "0"
