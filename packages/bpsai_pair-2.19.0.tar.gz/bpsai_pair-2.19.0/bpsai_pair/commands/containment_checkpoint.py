"""Containment checkpoint management: rollback, list, cleanup commands."""
from __future__ import annotations

import os
import subprocess
from typing import Optional

import typer
from rich.console import Console

from .containment_session import repo_root

console = Console()

containment_app = typer.Typer(
    help="Containment checkpoint management",
    context_settings={"help_option_names": ["-h", "--help"]},
)


@containment_app.command("rollback")
def containment_rollback(
    checkpoint: Optional[str] = typer.Argument(
        None, help="Checkpoint to rollback to (default: latest)"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", "-n", help="Preview without executing"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    pop_stash: bool = typer.Option(True, "--pop-stash/--no-pop-stash", help="Pop stashed changes"),
):
    """Rollback to a containment checkpoint."""
    from ..security.checkpoint import GitCheckpoint, CheckpointNotFoundError, format_rollback_preview

    root = repo_root()
    git_checkpoint = GitCheckpoint(root)

    target = checkpoint
    if not target:
        latest = git_checkpoint.get_latest_containment_checkpoint()
        if not latest:
            console.print("[yellow]No containment checkpoints found[/yellow]")
            raise typer.Exit(1)
        target = latest["tag"]

    try:
        preview = git_checkpoint.preview_rollback(target)
    except CheckpointNotFoundError:
        console.print(f"[red]Checkpoint not found:[/red] {target}")
        raise typer.Exit(1)

    console.print(format_rollback_preview(preview))
    console.print()

    if dry_run:
        console.print("[dim]Dry run - no changes made[/dim]")
        return

    if not force and (preview["commits_to_revert"] > 0 or preview["files_changed"]):
        if not typer.confirm("Proceed with rollback?"):
            raise typer.Abort()

    stash_ref = _find_stash_ref(root) if pop_stash else None
    _execute_rollback(git_checkpoint, target, pop_stash, stash_ref)


def _execute_rollback(git_checkpoint, target, pop_stash, stash_ref):
    """Execute the rollback and optionally restore stashed changes."""
    try:
        git_checkpoint.rollback_to(target, stash_uncommitted=True)
        console.print(f"[green]\u2713 Rolled back to:[/green] {target}")

        if pop_stash and stash_ref:
            if git_checkpoint.pop_stash(stash_ref):
                console.print("[green]\u2713 Restored stashed changes[/green]")
            else:
                console.print("[yellow]Warning: Could not restore stashed changes[/yellow]")
    except Exception as e:
        console.print(f"[red]Rollback failed:[/red] {e}")
        raise typer.Exit(1)


def _find_stash_ref(root) -> Optional[str]:
    """Find the stash reference for containment auto-stash."""
    stash_ref = os.environ.get("PAIRCODER_CONTAINMENT_STASH")
    if stash_ref:
        return stash_ref
    result = subprocess.run(
        ["git", "stash", "list"], cwd=root,
        capture_output=True, text=True, check=False,
    )
    for line in result.stdout.strip().split("\n"):
        if "Auto-stash before containment checkpoint" in line:
            return "Auto-stash before containment checkpoint"
    return None


@containment_app.command("list")
def containment_list():
    """List containment checkpoints."""
    from ..security.checkpoint import GitCheckpoint

    root = repo_root()
    checkpoints = GitCheckpoint(root).list_containment_checkpoints()

    if not checkpoints:
        console.print("[dim]No containment checkpoints found[/dim]")
        return

    console.print(f"[cyan]Containment Checkpoints ({len(checkpoints)}):[/cyan]")
    console.print()

    for cp in sorted(checkpoints, key=lambda c: c["timestamp"], reverse=True):
        console.print(f"  [bold]{cp['tag']}[/bold]")
        console.print(f"    Commit:  {cp['commit']}")
        console.print(f"    Time:    {cp['timestamp']}")
        if cp.get("message"):
            console.print(f"    Message: {cp['message'][:50]}...")
        console.print()


@containment_app.command("cleanup")
def containment_cleanup(
    keep: int = typer.Option(5, "--keep", "-k", help="Number of checkpoints to keep"),
):
    """Remove old containment checkpoints. Keeps the most recent N."""
    from ..security.checkpoint import GitCheckpoint

    root = repo_root()
    checkpoints = GitCheckpoint(root).list_containment_checkpoints()

    if len(checkpoints) <= keep:
        console.print(f"[dim]Only {len(checkpoints)} checkpoint(s) - nothing to remove[/dim]")
        return

    sorted_cps = sorted(checkpoints, key=lambda c: c["timestamp"])
    removed = 0
    failed = 0
    for cp in sorted_cps[:-keep]:
        try:
            GitCheckpoint(root).delete_checkpoint(cp["tag"])
            removed += 1
        except Exception as e:
            failed += 1
            console.print(f"[yellow]Warning: Could not remove {cp['tag']}: {e}[/yellow]")

    if removed > 0:
        console.print(f"[green]Removed {removed} old checkpoint(s)[/green]")
    else:
        console.print("[dim]No checkpoints removed[/dim]")
