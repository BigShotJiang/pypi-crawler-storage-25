"""Helper functions extracted from TelemetryCollector for architectural compliance.

Module-level functions that support telemetry collection but don't require
access to collector state (or take explicit args).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import yaml

from bpsai_pair.telemetry.schema import TelemetryRecord

logger = logging.getLogger(__name__)


def read_routing_decision(project_root: Path, task_id: str) -> str | None:
    """Read the per-task routing decision file and clean up after read."""
    from bpsai_pair.core.cache_paths import routing_decision_path
    path = routing_decision_path(project_root / ".paircoder", task_id)
    try:
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        model = data.get("routed_model")
        try:
            path.unlink()
        except OSError:
            pass
        return model
    except Exception:
        logger.debug("Could not read routing decision for %s", task_id)
    return None


def detect_active_integrations(project_root: Path) -> list[str]:
    """Detect active integrations from project config.

    Returns list of integration/feature strings like "int:trello", "feat:hooks".
    """
    config_path = project_root / ".paircoder" / "config.yaml"
    try:
        if not config_path.exists():
            return []
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return []
    detected: list[str] = []
    for key in ("trello", "github"):
        if data.get(key):
            detected.append(f"int:{key}")
    for key in (
        "hooks", "metrics", "architecture", "containment",
        "estimation", "enforcement",
    ):
        if data.get(key):
            detected.append(f"feat:{key}")
    return detected


def build_friction_signals(
    record: TelemetryRecord,
    explicit: dict[str, int] | None,
) -> dict[str, int]:
    """Build friction_signals by merging explicit values with auto-derived."""
    signals: dict[str, int] = dict(explicit or {})
    if record.compactions > 0:
        signals.setdefault("compactions", record.compactions)
    if record.human_interventions > 0:
        signals.setdefault("human_interventions", record.human_interventions)
    return signals


def extract_repo_name(project_path: str | None, fallback: str) -> str:
    """Extract repository name from project path, with fallback."""
    if not project_path:
        return fallback
    path = Path(project_path)
    return path.name or fallback


def merge_features(explicit: list[str], detected: list[str]) -> list[str]:
    """Merge explicit and detected features, deduplicating."""
    seen: set[str] = set()
    merged: list[str] = []
    for f in explicit + detected:
        if f not in seen:
            seen.add(f)
            merged.append(f)
    return merged
