"""Specialized data collectors for usage snapshots.

Three collectors that gather anonymized usage data at different privacy tiers:
- EnvironmentCollector: OS, Python, CLI version (MINIMAL)
- FeatureUsageCollector: task type distribution, model usage (STANDARD)
- PerformanceCollector: cache hit rate, durations (STANDARD)
"""

from __future__ import annotations

import importlib.metadata
import logging
import platform
import sys
from collections import Counter

from bpsai_pair.telemetry.schema import Outcome
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)

MAX_DISTRIBUTION_ENTRIES = 15


class EnvironmentCollector:
    """Collects anonymized environment information.

    Gathers OS, Python version, and CLI version. No PII is collected —
    no usernames, hostnames, or paths.
    """

    def collect(self) -> dict:
        """Collect environment data.

        Returns:
            Dict with os_info, python_version, cli_version.
        """
        return {
            "os_info": self._get_os_info(),
            "python_version": self._get_python_version(),
            "cli_version": self._get_cli_version(),
        }

    def _get_os_info(self) -> str:
        """Get OS name and version."""
        return f"{platform.system()} {platform.release()}"

    def _get_python_version(self) -> str:
        """Get Python version string."""
        return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

    def _get_cli_version(self) -> str | None:
        """Get bpsai-pair CLI version from package metadata."""
        try:
            return importlib.metadata.version("bpsai-pair")
        except Exception:
            return None


class FeatureUsageCollector:
    """Collects feature usage data from telemetry records.

    Analyzes TelemetryStore records to build task type distribution,
    model usage, and outcome distribution. Limited to top 15 entries.
    """

    def __init__(self, store: TelemetryStore) -> None:
        self._store = store

    def collect(self) -> dict:
        """Collect feature usage data.

        Returns:
            Dict with task_type_distribution, model_usage,
            outcome_distribution, features_used_distribution.
        """
        records = self._store.query(limit=10000)

        task_types: Counter[str] = Counter()
        models: Counter[str] = Counter()
        outcomes: Counter[str] = Counter()
        features: Counter[str] = Counter()

        for record in records:
            task_types[record.task_type] += 1
            models[record.model] += 1
            outcomes[record.outcome.value] += 1
            for feat in getattr(record, "features_used", []):
                features[feat] += 1

        return {
            "task_type_distribution": dict(task_types.most_common(MAX_DISTRIBUTION_ENTRIES)),
            "model_usage": dict(models.most_common(MAX_DISTRIBUTION_ENTRIES)),
            "outcome_distribution": dict(outcomes),
            "features_used_distribution": dict(features.most_common(MAX_DISTRIBUTION_ENTRIES)),
        }


class PerformanceCollector:
    """Collects performance metrics from telemetry records.

    Analyzes TelemetryStore records to compute cache hit rate,
    error counts, average duration, and average tokens per session.
    """

    def __init__(self, store: TelemetryStore) -> None:
        self._store = store

    def collect(self) -> dict:
        """Collect performance data.

        Returns:
            Dict with cache_hit_rate, error_count, avg_duration_seconds,
            avg_tokens_per_session.
        """
        records = self._store.query(limit=10000)

        if not records:
            return {
                "cache_hit_rate": 0.0,
                "error_count": 0,
                "avg_duration_seconds": 0.0,
                "avg_tokens_per_session": 0.0,
            }

        total_cache_read = sum(r.tokens.cache_read for r in records)
        total_input = sum(r.tokens.input for r in records)
        error_count = sum(1 for r in records if r.outcome == Outcome.FAIL)
        total_duration = sum(r.duration_seconds for r in records)
        total_tokens = sum(r.tokens.total for r in records)

        cache_hit_rate = total_cache_read / total_input if total_input > 0 else 0.0

        return {
            "cache_hit_rate": cache_hit_rate,
            "error_count": error_count,
            "avg_duration_seconds": total_duration / len(records),
            "avg_tokens_per_session": total_tokens / len(records),
        }
