"""Telemetry collector: collects metrics on task completion with privacy filtering."""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.telemetry.audit import AuditLog
from bpsai_pair.telemetry.collector_helpers import (
    build_friction_signals,
    detect_active_integrations,
    extract_repo_name,
    merge_features,
    read_routing_decision,
)
from bpsai_pair.telemetry.config import TelemetryConfig
from bpsai_pair.telemetry.parser import ClaudeSessionParser
from bpsai_pair.telemetry.privacy import PrivacyFilter
from bpsai_pair.telemetry.schema import (
    Outcome,
    TelemetryRecord,
    TokenUsage,
    classify_fail_detail,
    classify_token_type,
)
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)

SNAPSHOT_FILENAME = "session_snapshot.json"


def _safe_int(obj: Any, attr: str) -> int:
    """Extract an int attribute safely, returning 0 for missing or non-int."""
    val = getattr(obj, attr, None)
    return val if isinstance(val, int) else 0


def _resolve_model(session_model: str | None) -> str:
    """Resolve model name through fallback chain.

    Order: session data -> ANTHROPIC_MODEL -> CLAUDE_MODEL -> "unknown".
    Never returns a bare family name like "sonnet".
    Empty strings are treated as missing (explicit check, not just truthiness).
    """
    if session_model is not None and session_model != "":
        return session_model
    anthropic_model = os.environ.get("ANTHROPIC_MODEL")
    if anthropic_model:
        return anthropic_model
    claude_model = os.environ.get("CLAUDE_MODEL")
    if claude_model:
        return claude_model
    return "unknown"


class TelemetryCollector:
    """Collects and stores telemetry data for completed tasks."""

    def __init__(
        self, project_root: Path, config: TelemetryConfig | None = None
    ) -> None:
        self.project_root = project_root
        self.config = config or TelemetryConfig.load(project_root)

        self.parser = ClaudeSessionParser()
        self.store = TelemetryStore(project_root)
        self._telemetry_dir = project_root / ".paircoder" / "telemetry"
        self.audit = AuditLog(self._telemetry_dir / "audit.jsonl")
        self.filter = PrivacyFilter(self.config.privacy_level)
        self._snapshot = self._load_snapshot()
        self._cached_integrations: list[str] | None = None

    def collect_for_task(
        self,
        task_id: str,
        task_type: str,
        outcome: Outcome,
        estimated_tokens: int | None = None,
        error_context: str | None = None,
        estimated_hours: float | None = None,
        actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        features_used: list[str] | None = None,
        friction_signals: dict[str, int] | None = None,
        sprint: str | None = None,
        complexity: int | None = None,
    ) -> TelemetryRecord | None:
        """Collect telemetry for a completed task. Never raises."""
        try:
            return self._collect_internal(
                task_id, task_type, outcome, estimated_tokens, error_context,
                estimated_hours, actual_hours, estimated_complexity,
                features_used, friction_signals, sprint, complexity,
            )
        except Exception as e:
            logger.warning("Telemetry collection failed (non-blocking): %s", e)
            return None

    def _collect_internal(
        self,
        task_id: str, task_type: str, outcome: Outcome,
        estimated_tokens: int | None = None, error_context: str | None = None,
        estimated_hours: float | None = None, actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        features_used: list[str] | None = None,
        friction_signals: dict[str, int] | None = None,
        sprint: str | None = None, complexity: int | None = None,
    ) -> TelemetryRecord | None:
        """Internal collection logic that may raise exceptions."""
        if not self.config.enabled:
            return None

        # Guard: flag phantom task IDs (no matching task file)
        tasks_dir = self.project_root / ".paircoder" / "tasks"
        if not list(tasks_dir.glob(f"**/{task_id}.task.md")):
            friction_signals = dict(friction_signals or {})
            friction_signals["phantom_task"] = 1
            logger.warning("Phantom task detected: %s (no task file found)", task_id)

        session_metrics = self._get_session_metrics()
        is_sessionless = session_metrics is None
        if not is_sessionless:
            record = self._create_record(
                task_id, task_type, outcome, session_metrics,
                estimated_tokens, error_context,
                estimated_hours, actual_hours, estimated_complexity,
                sprint, complexity,
            )
            self._save_snapshot(session_metrics)  # advance delta baseline
            if record.duration_seconds < 1 and record.tokens.input == 0:  # session boundary
                is_sessionless = True
        if is_sessionless:
            record = self._create_sessionless_record(
                task_id, task_type, outcome, estimated_tokens,
                error_context, estimated_hours, actual_hours,
                estimated_complexity, sprint, complexity,
            )

        if record is None:
            return None
        self._enrich_record(record, task_id, features_used, friction_signals)
        if is_sessionless:
            record.friction_signals["sessionless"] = 1
        elif record.duration_seconds < 1:
            logger.warning("Rejecting record for %s: duration %ds < 1s", task_id, record.duration_seconds)
            return None

        return self._filter_and_store(record)

    def _enrich_record(
        self, record: TelemetryRecord, task_id: str,
        features_used: list[str] | None, friction_signals: dict[str, int] | None,
    ) -> None:
        """Enrich record with routing, features, and friction data."""
        record.routed_model = read_routing_decision(self.project_root, task_id)
        if self._cached_integrations is None:
            self._cached_integrations = detect_active_integrations(self.project_root)
        record.features_used = merge_features(
            features_used or [], self._cached_integrations,
        )
        record.friction_signals = build_friction_signals(record, friction_signals)

    def _filter_and_store(self, record: TelemetryRecord) -> TelemetryRecord | None:
        """Apply privacy filter, store record, and create audit entry."""
        filtered = self.filter.filter(record)
        if filtered is None:
            return None
        self.store.append(filtered)
        self.audit.append("record_added", {"task_id": filtered.task_id,
                          "task_type": filtered.task_type, "outcome": filtered.outcome.value})
        return filtered

    def _get_session_metrics(self):
        """Find and parse the most recent session for this project."""
        project_path = str(self.project_root.resolve())
        sessions = self.parser.find_sessions(project_path)

        if not sessions:
            return None

        # Use the most recent session (first in sorted list)
        most_recent = sessions[0]
        entries = self.parser.parse_session(most_recent)

        if not entries:
            return None

        return self.parser.extract_metrics(entries)

    def _create_record(
        self, task_id: str, task_type: str, outcome: Outcome, metrics,
        estimated_tokens: int | None = None, error_context: str | None = None,
        estimated_hours: float | None = None, actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        sprint: str | None = None, complexity: int | None = None,
    ) -> TelemetryRecord:
        """Create a TelemetryRecord from session metrics (delta-aware)."""
        repo = extract_repo_name(metrics.project_path, self.project_root.name)
        (inp, out, duration, interventions,
         compactions, cache_read, cache_write) = self._compute_deltas(metrics)
        tokens = TokenUsage(input=inp, output=out, cache_read=cache_read, cache_write=cache_write)
        session_id = (
            metrics.session_id or os.environ.get("CLAUDE_SESSION_ID")
            or f"{task_id}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}"
        )
        outcome_detail = classify_fail_detail(error_context) if outcome == Outcome.FAIL else None

        return TelemetryRecord(
            task_id=task_id, task_type=task_type, repo=repo,
            model=_resolve_model(metrics.model), tokens=tokens,
            duration_seconds=int(duration),
            human_interventions=interventions, compactions=compactions,
            outcome=outcome, outcome_detail=outcome_detail,
            token_type=classify_token_type(task_type),
            timestamp=datetime.now(timezone.utc),
            privacy_level=self.config.privacy_level,
            estimated_tokens=estimated_tokens, error_context=error_context,
            session_id=session_id,
            estimated_hours=estimated_hours, actual_hours=actual_hours,
            estimated_complexity=estimated_complexity,
            sprint=sprint, complexity=complexity,
        )

    def _create_sessionless_record(
        self,
        task_id: str, task_type: str, outcome: Outcome,
        estimated_tokens: int | None = None, error_context: str | None = None,
        estimated_hours: float | None = None, actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        sprint: str | None = None, complexity: int | None = None,
    ) -> TelemetryRecord:
        """Create a TelemetryRecord without session data (in-session fallback)."""
        model = _resolve_model(None)
        session_id = (
            os.environ.get("CLAUDE_SESSION_ID")
            or f"{task_id}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}"
        )
        input_tok = 0
        output_tok = 0
        duration = 0
        try:
            from bpsai_pair.core.cache_paths import time_tracking_cache_path
            cache_path = time_tracking_cache_path(self.project_root / ".paircoder")
            if cache_path.exists():
                from bpsai_pair.integrations.time_tracking import LocalTimeCache
                td = LocalTimeCache(cache_path).get_total(task_id)
                duration = max(0, int(td.total_seconds()))
        except Exception:
            logger.debug("Could not read timer duration for %s", task_id)

        outcome_detail = classify_fail_detail(error_context) if outcome == Outcome.FAIL else None
        token_type = classify_token_type(task_type)

        return TelemetryRecord(
            task_id=task_id, task_type=task_type,
            repo=self.project_root.name,
            model=model, tokens=TokenUsage(input=input_tok, output=output_tok),
            duration_seconds=duration,
            human_interventions=0, compactions=0,
            outcome=outcome, outcome_detail=outcome_detail,
            token_type=token_type,
            timestamp=datetime.now(timezone.utc),
            privacy_level=self.config.privacy_level,
            estimated_tokens=estimated_tokens, error_context=error_context,
            session_id=session_id,
            estimated_hours=estimated_hours, actual_hours=actual_hours,
            estimated_complexity=estimated_complexity,
            sprint=sprint, complexity=complexity,
            is_estimate=True,
        )

    def _compute_deltas(
        self, metrics,
    ) -> tuple[int, int, float, int, int, int, int]:
        """Compute per-task deltas from cumulative session metrics.

        Returns:
            (input_tokens, output_tokens, duration, interventions, compactions,
             cache_read, cache_write)
        """
        compactions = _safe_int(metrics, "compactions")
        cache_read = _safe_int(metrics, "cache_read_tokens")
        cache_write = _safe_int(metrics, "cache_write_tokens")
        snap = self._snapshot
        if not snap or snap.get("session_id") != metrics.session_id:
            logger.debug(
                "Session boundary: no delta available (snap=%s, session=%s)",
                snap.get("session_id") if snap else None,
                metrics.session_id,
            )
            return (0, 0, 0.0, 0, 0, 0, 0)

        return (
            max(0, metrics.total_input_tokens - snap.get("total_input_tokens", 0)),
            max(0, metrics.total_output_tokens - snap.get("total_output_tokens", 0)),
            max(0, metrics.duration_seconds - snap.get("duration_seconds", 0)),
            max(0, metrics.message_counts.user - snap.get("user_messages", 0)),
            max(0, compactions - snap.get("compactions", 0)),
            max(0, cache_read - snap.get("cache_read_tokens", 0)),
            max(0, cache_write - snap.get("cache_write_tokens", 0)),
        )

    def _load_snapshot(self) -> dict[str, Any] | None:
        """Load the session snapshot from disk."""
        path = self._telemetry_dir / SNAPSHOT_FILENAME
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if "session_id" in data and "total_input_tokens" in data:
                    return data
        except Exception:
            logger.debug("Could not load session snapshot, starting fresh")
        return None

    def _save_snapshot(self, metrics) -> None:
        """Save the current cumulative metrics as a snapshot for next delta."""
        self._telemetry_dir.mkdir(parents=True, exist_ok=True)
        snapshot = {
            "session_id": metrics.session_id,
            "total_input_tokens": metrics.total_input_tokens,
            "total_output_tokens": metrics.total_output_tokens,
            "duration_seconds": metrics.duration_seconds,
            "user_messages": metrics.message_counts.user,
            "compactions": _safe_int(metrics, "compactions"),
            "cache_read_tokens": _safe_int(metrics, "cache_read_tokens"),
            "cache_write_tokens": _safe_int(metrics, "cache_write_tokens"),
        }
        path = self._telemetry_dir / SNAPSHOT_FILENAME
        try:
            path.write_text(json.dumps(snapshot), encoding="utf-8")
            self._snapshot = snapshot
        except Exception:
            logger.debug("Could not save session snapshot")

