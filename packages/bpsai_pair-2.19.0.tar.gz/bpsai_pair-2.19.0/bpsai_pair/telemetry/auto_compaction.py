"""Auto-compaction trigger for telemetry data.

Checks whether telemetry.jsonl needs compaction based on file size
and record age thresholds, and runs compaction as a background task.
"""

from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.telemetry.batch_submit import build_and_submit_on_compaction
from bpsai_pair.telemetry.compaction import CompactionEngine
from bpsai_pair.telemetry.config import TelemetryConfig
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)

_COMPACTION_META = "compaction_meta.json"

# Thresholds
SIZE_THRESHOLD_BYTES = 200 * 1024  # 200 KB
AGE_THRESHOLD_DAYS = 30


def should_auto_compact(
    project_root: Path,
    oldest_record_ts: datetime | None = None,
) -> bool:
    """Check whether auto-compaction should trigger.

    Returns True if:
    - telemetry.jsonl exceeds SIZE_THRESHOLD_BYTES, OR
    - oldest_record_ts is older than AGE_THRESHOLD_DAYS

    Args:
        project_root: Path to the project root directory
        oldest_record_ts: Timestamp of the oldest record (optional)

    Returns:
        True if compaction should run
    """
    telemetry_file = (
        project_root / ".paircoder" / "telemetry" / "telemetry.jsonl"
    )

    if not telemetry_file.exists():
        return False

    # Check file size threshold
    file_size = telemetry_file.stat().st_size
    if file_size > SIZE_THRESHOLD_BYTES:
        logger.info(
            "Auto-compaction triggered: file size %d > %d bytes",
            file_size,
            SIZE_THRESHOLD_BYTES,
        )
        return True

    # Check record age threshold
    if oldest_record_ts is not None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=AGE_THRESHOLD_DAYS)
        if oldest_record_ts < cutoff:
            logger.info(
                "Auto-compaction triggered: oldest record %s older than %d days",
                oldest_record_ts.isoformat(),
                AGE_THRESHOLD_DAYS,
            )
            return True

    return False


def _save_compaction_meta(
    project_root: Path, result: Any,
) -> None:
    """Save compaction result metadata for status display."""
    meta_file = (
        project_root / ".paircoder" / "telemetry" / _COMPACTION_META
    )
    meta_file.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "last_compaction": datetime.now(timezone.utc).isoformat(),
        "records_compacted": result.records_compacted,
        "aggregates_created": result.aggregates_created,
        "records_retained": result.records_retained,
    }
    meta_file.write_text(json.dumps(data), encoding="utf-8")


def get_last_compaction_info(
    project_root: Path,
) -> dict[str, Any] | None:
    """Read the last compaction metadata.

    Returns:
        Dict with last_compaction, records_compacted, etc. or None.
    """
    meta_file = (
        project_root / ".paircoder" / "telemetry" / _COMPACTION_META
    )
    if not meta_file.exists():
        return None
    try:
        return json.loads(meta_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _run_compaction(project_root: Path) -> None:
    """Execute compaction synchronously (called from thread)."""
    try:
        store = TelemetryStore(project_root)
        config = TelemetryConfig.load(project_root)
        engine = CompactionEngine(store, config)
        result = engine.run()
        _save_compaction_meta(project_root, result)
        logger.info(
            "Auto-compaction complete: %d compacted, %d retained",
            result.records_compacted,
            result.records_retained,
        )
        build_and_submit_on_compaction(project_root)
    except Exception:
        logger.debug("Auto-compaction failed", exc_info=True)


def run_auto_compact(project_root: Path) -> threading.Thread:
    """Run compaction in a background daemon thread.

    Returns the thread so callers can join() in tests.
    """
    thread = threading.Thread(
        target=_run_compaction,
        args=(project_root,),
        daemon=True,
        name="telemetry-auto-compact",
    )
    thread.start()
    return thread


def maybe_auto_compact(project_root: Path) -> None:
    """Check thresholds and trigger background compaction if needed.

    This is the entry point called from session_check on session start.
    """
    if should_auto_compact(project_root):
        logger.info("Starting background telemetry compaction")
        run_auto_compact(project_root)
