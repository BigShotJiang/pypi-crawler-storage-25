"""Detect consecutive task failure patterns from state transition history.

Reads task_state_log via TaskStateIndex and identifies streaks of
failures (blocked transitions) that meet the configured threshold.
"""
from __future__ import annotations

import logging
from pathlib import Path

from bpsai_pair.telemetry.signal_thresholds import SignalThresholds

logger = logging.getLogger(__name__)

_FAILURE_STATES = {"blocked"}


class FailurePatternDetector:
    """Detect consecutive task failures from task state history."""

    def __init__(
        self,
        paircoder_dir: Path,
        thresholds: SignalThresholds | None = None,
    ) -> None:
        self._paircoder_dir = paircoder_dir
        self._thresholds = thresholds or SignalThresholds()

    def detect(self) -> list[str] | None:
        """Check recent transitions for consecutive failure streak.

        Returns list of failed task IDs if threshold met, else None.
        """
        transitions = self._load_recent_transitions()
        if not transitions:
            return None

        streak = self._find_trailing_failure_streak(transitions)
        threshold = self._thresholds.consecutive_failure_threshold

        if len(streak) >= threshold:
            return streak
        return None

    def _load_recent_transitions(self) -> list[dict]:
        """Load recent terminal transitions (done or blocked)."""
        try:
            from bpsai_pair.telemetry.task_state_index import TaskStateIndex

            db_path = self._paircoder_dir / "data" / "store.db"
            idx = TaskStateIndex(db_path, read_only=True)
            rows = idx.query_transitions(limit=100)
            return self._dedupe_latest_per_task(rows)
        except Exception:
            logger.debug("Could not load task transitions", exc_info=True)
            return []

    def _dedupe_latest_per_task(self, rows: list[dict]) -> list[dict]:
        """Keep only the latest transition per task, ordered by time."""
        seen: dict[str, dict] = {}
        for row in rows:
            tid = row["task_id"]
            if tid not in seen:
                seen[tid] = row
        # rows come DESC from query; reverse for chronological order
        return list(reversed(list(seen.values())))

    def _find_trailing_failure_streak(
        self, transitions: list[dict]
    ) -> list[str]:
        """Walk transitions from most recent, collect failures until success."""
        streak: list[str] = []
        for t in reversed(transitions):
            if t["new_state"] in _FAILURE_STATES:
                streak.append(t["task_id"])
            else:
                break
        streak.reverse()
        return streak


def detect_and_emit_failure_pattern(
    paircoder_dir: Path,
    thresholds: SignalThresholds | None = None,
) -> "EmittedSignal | None":
    """Detect consecutive failures and emit signal if threshold met.

    Convenience function combining detection and emission.
    Returns the emitted signal, or None if no pattern found.
    """
    from bpsai_pair.telemetry.signal_emitter import EmittedSignal, SignalEmitter

    detector = FailurePatternDetector(paircoder_dir, thresholds=thresholds)
    failed_tasks = detector.detect()
    if failed_tasks is None:
        return None

    count = len(failed_tasks)
    emitter = SignalEmitter(paircoder_dir, thresholds=thresholds)
    return emitter.emit_task_failure_pattern(
        failed_tasks=failed_tasks,
        pattern_description=f"{count} consecutive task failures detected",
    )
