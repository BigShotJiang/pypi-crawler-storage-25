"""Telemetry module for collecting and analyzing Claude Code session data.

This module provides tools for parsing Claude Code session transcripts
and extracting execution metrics for product intelligence.
"""

from bpsai_pair.telemetry.parser import (
    ClaudeSessionParser,
    MessageCounts,
    SessionMetrics,
)
from bpsai_pair.telemetry.schema import (
    Outcome,
    PrivacyLevel,
    TelemetryRecord,
    TokenUsage,
    ValidationError,
)
from bpsai_pair.telemetry.store import (
    TelemetryStats,
    TelemetryStore,
)
from bpsai_pair.telemetry.audit import (
    AuditEntry,
    AuditLog,
)
from bpsai_pair.telemetry.config import TelemetryConfig
from bpsai_pair.telemetry.privacy import PrivacyFilter
from bpsai_pair.telemetry.collector import TelemetryCollector
from bpsai_pair.telemetry.collectors import (
    EnvironmentCollector,
    FeatureUsageCollector,
    PerformanceCollector,
)
from bpsai_pair.telemetry.snapshot import (
    UsageSnapshot,
    build_usage_snapshot,
)
from bpsai_pair.telemetry.hooks_schema import (
    CollectionLevel,
    HookEventSchema,
    HookType,
    TelemetryHookConfig,
)
from bpsai_pair.telemetry.aggregates import (
    AggregateRecord,
    ModelAggregate,
    TaskTypeAggregate,
)
from bpsai_pair.telemetry.compaction import (
    CompactionEngine,
    CompactionResult,
)

__all__ = [
    # Parser
    "ClaudeSessionParser",
    "MessageCounts",
    "SessionMetrics",
    # Schema
    "Outcome",
    "PrivacyLevel",
    "TelemetryRecord",
    "TokenUsage",
    "ValidationError",
    # Store
    "TelemetryStats",
    "TelemetryStore",
    # Audit
    "AuditEntry",
    "AuditLog",
    # Config & Privacy
    "TelemetryConfig",
    "PrivacyFilter",
    # Collector
    "TelemetryCollector",
    # Collectors
    "EnvironmentCollector",
    "FeatureUsageCollector",
    "PerformanceCollector",
    # Snapshot
    "UsageSnapshot",
    "build_usage_snapshot",
    # Hook schemas
    "CollectionLevel",
    "HookEventSchema",
    "HookType",
    "TelemetryHookConfig",
    # Aggregates
    "AggregateRecord",
    "ModelAggregate",
    "TaskTypeAggregate",
    # Compaction
    "CompactionEngine",
    "CompactionResult",
]
