"""Telemetry compaction engine.

Compacts raw telemetry JSONL records older than the retention window
into weekly aggregate summaries, reducing storage while preserving
statistical value.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

from bpsai_pair.feedback.stats import mean, percentile, std_dev
from bpsai_pair.telemetry.aggregates import (
    AggregateRecord,
    ModelAggregate,
    TaskTypeAggregate,
)
from bpsai_pair.telemetry.config import TelemetryConfig
from bpsai_pair.telemetry.schema import Outcome, TelemetryRecord, TokenUsage
from bpsai_pair.telemetry.store import TelemetryStore


@dataclass
class CompactionResult:
    """Result of a compaction cycle."""

    records_compacted: int
    aggregates_created: int
    records_retained: int
    dry_run: bool


def _iso_week_bounds(dt: datetime) -> tuple[str, str]:
    """Return (monday, sunday) ISO date strings for the week containing dt."""
    d = dt.date() if isinstance(dt, datetime) else dt
    weekday = d.isoweekday()  # Monday=1, Sunday=7
    monday = d - timedelta(days=weekday - 1)
    sunday = monday + timedelta(days=6)
    return monday.isoformat(), sunday.isoformat()


def bucket_by_week(
    records: list[TelemetryRecord],
) -> dict[tuple[str, str], list[TelemetryRecord]]:
    """Group records into ISO week buckets.

    Key is (period_start, period_end) where period_start is the Monday
    and period_end is the Sunday of the ISO week.
    """
    buckets: dict[tuple[str, str], list[TelemetryRecord]] = {}
    for record in records:
        key = _iso_week_bounds(record.timestamp)
        buckets.setdefault(key, []).append(record)
    return buckets


def _build_task_type_aggregate(
    task_type: str, type_records: list[TelemetryRecord],
) -> TaskTypeAggregate:
    """Build a TaskTypeAggregate from records of one task type."""
    tokens_list = [float(r.tokens.total) for r in type_records]
    durations = [float(r.duration_seconds) for r in type_records]
    return TaskTypeAggregate(
        task_type=task_type,
        record_count=len(type_records),
        total_input=sum(r.tokens.input for r in type_records),
        total_output=sum(r.tokens.output for r in type_records),
        total_cache_read=sum(r.tokens.cache_read for r in type_records),
        total_cache_write=sum(r.tokens.cache_write for r in type_records),
        total_duration_seconds=sum(durations),
        success_count=sum(1 for r in type_records if r.outcome == Outcome.SUCCESS),
        fail_count=sum(1 for r in type_records if r.outcome == Outcome.FAIL),
        avg_tokens=mean(tokens_list),
        std_dev_tokens=std_dev(tokens_list),
        p80_tokens=percentile(tokens_list, 80),
        avg_duration_seconds=mean(durations),
    )


def _build_model_aggregate(
    model_name: str, model_records: list[TelemetryRecord],
) -> ModelAggregate:
    """Build a ModelAggregate from records of one model."""
    return ModelAggregate(
        model=model_name,
        record_count=len(model_records),
        total_input=sum(r.tokens.input for r in model_records),
        total_output=sum(r.tokens.output for r in model_records),
        total_cache_read=sum(r.tokens.cache_read for r in model_records),
        total_cache_write=sum(r.tokens.cache_write for r in model_records),
        total_duration_seconds=sum(float(r.duration_seconds) for r in model_records),
    )


def _group_by_key(
    records: list[TelemetryRecord], key: str,
) -> dict[str, list[TelemetryRecord]]:
    """Group records by a string attribute."""
    groups: dict[str, list[TelemetryRecord]] = {}
    for r in records:
        groups.setdefault(getattr(r, key), []).append(r)
    return groups


def compact_records(
    records: list[TelemetryRecord],
    period_start: str,
    period_end: str,
) -> AggregateRecord:
    """Compact a list of raw records into a single aggregate for the period."""
    from bpsai_pair import __version__

    task_type_stats = {
        tt: _build_task_type_aggregate(tt, recs)
        for tt, recs in _group_by_key(records, "task_type").items()
    }
    model_stats = {
        m: _build_model_aggregate(m, recs)
        for m, recs in _group_by_key(records, "model").items()
    }

    return AggregateRecord(
        period_start=period_start,
        period_end=period_end,
        record_count=len(records),
        task_type_stats=task_type_stats,
        model_stats=model_stats,
        total_tokens=TokenUsage(
            input=sum(r.tokens.input for r in records),
            output=sum(r.tokens.output for r in records),
            cache_read=sum(r.tokens.cache_read for r in records),
            cache_write=sum(r.tokens.cache_write for r in records),
        ),
        total_duration_seconds=sum(float(r.duration_seconds) for r in records),
        success_count=sum(1 for r in records if r.outcome == Outcome.SUCCESS),
        fail_count=sum(1 for r in records if r.outcome == Outcome.FAIL),
        estimate_count=sum(
            1 for r in records if getattr(r, "is_estimate", False)
        ),
        compacted_at=datetime.now(timezone.utc).isoformat(),
        source_version=__version__,
    )


class CompactionEngine:
    """Runs compaction cycles on telemetry data."""

    def __init__(self, store: TelemetryStore, config: TelemetryConfig) -> None:
        self._store = store
        self._config = config

    def run(
        self,
        retention_days: int | None = None,
        dry_run: bool = False,
    ) -> CompactionResult:
        """Run compaction cycle.

        Identifies old records, compacts by week, saves aggregates,
        and optionally removes raw records.
        """
        days = retention_days if retention_days is not None else self._config.retention_days
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)

        all_records = self._store._read_all_records()

        recent = [r for r in all_records if r.timestamp >= cutoff]
        old = [r for r in all_records if r.timestamp < cutoff]

        if not old:
            return CompactionResult(
                records_compacted=0,
                aggregates_created=0,
                records_retained=len(recent),
                dry_run=dry_run,
            )

        buckets = bucket_by_week(old)
        aggregates_created = 0

        for (period_start, period_end), bucket_records in buckets.items():
            aggregate = compact_records(bucket_records, period_start, period_end)
            if not dry_run:
                self._store.save_aggregate(aggregate)
            aggregates_created += 1

        if not dry_run:
            self._store._write_records(recent)

        return CompactionResult(
            records_compacted=len(old),
            aggregates_created=aggregates_created,
            records_retained=len(recent),
            dry_run=dry_run,
        )
