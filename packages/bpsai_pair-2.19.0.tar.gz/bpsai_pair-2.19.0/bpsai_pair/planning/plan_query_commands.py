"""Plan query commands — list, show, tasks.

These functions are registered on plan_app by the plan_commands shim.
Uses late imports from plan_commands for mockable dependencies.
"""

from typing import Optional
import json

import typer
from rich.table import Table


def plan_list(
    status: Optional[str] = typer.Option(
        None, "--status", "-s",
        help="Filter: planned|in_progress|complete|archived"
    ),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List all plans."""
    import bpsai_pair.planning.plan_commands as pc

    paircoder_dir = pc.find_paircoder_dir()
    plan_parser = pc.PlanParser(paircoder_dir / "plans")
    task_parser = pc.TaskParser(paircoder_dir / "tasks")

    plans = plan_parser.parse_all()

    if status:
        plans = [p for p in plans if p.status.value == status]

    if json_out:
        data = [p.to_dict() for p in plans]
        pc.console.print(json.dumps(data, indent=2, default=str))
        return

    if not plans:
        pc.console.print("[dim]No plans found.[/dim]")
        return

    table = Table(title=f"Plans ({len(plans)})")
    table.add_column("ID", style="cyan")
    table.add_column("Title")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Tasks", justify="right")

    for plan in plans:
        task_count = len(task_parser.get_tasks_for_plan(plan.id))
        table.add_row(
            plan.id,
            plan.title,
            plan.type.value,
            f"{plan.status_emoji} {plan.status.value}",
            str(task_count),
        )

    pc.console.print(table)


def plan_show(
    plan_id: str = typer.Argument(..., help="Plan ID"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show details of a specific plan."""
    import bpsai_pair.planning.plan_commands as pc

    paircoder_dir = pc.find_paircoder_dir()
    plan_parser = pc.PlanParser(paircoder_dir / "plans")
    task_parser = pc.TaskParser(paircoder_dir / "tasks")

    plan = plan_parser.get_plan_by_id(plan_id)

    if not plan:
        pc.console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    if json_out:
        pc.console.print(json.dumps(plan.to_dict(), indent=2, default=str))
        return

    pc.console.print(f"[bold]{plan.status_emoji} {plan.id}[/bold]")
    pc.console.print(f"{'=' * 60}")
    pc.console.print(f"[cyan]Title:[/cyan] {plan.title}")
    pc.console.print(f"[cyan]Type:[/cyan] {plan.type.value}")
    pc.console.print(f"[cyan]Status:[/cyan] {plan.status.value}")

    if plan.owner:
        pc.console.print(f"[cyan]Owner:[/cyan] {plan.owner}")
    if plan.created_at:
        pc.console.print(f"[cyan]Created:[/cyan] {plan.created_at.strftime('%Y-%m-%d')}")

    if plan.skills:
        pc.console.print(f"\n[cyan]Skills:[/cyan] {', '.join(plan.skills)}")
    elif plan.flows:
        pc.console.print(f"\n[cyan]Flows:[/cyan] {', '.join(plan.flows)} [dim](deprecated)[/dim]")

    if plan.goals:
        pc.console.print("\n[cyan]Goals:[/cyan]")
        for goal in plan.goals:
            pc.console.print(f"  - {goal}")

    if plan.sprints:
        pc.console.print("\n[cyan]Sprints:[/cyan]")
        for sprint in plan.sprints:
            pc.console.print(f"  [{sprint.id}] {sprint.title}")
            if sprint.goal:
                pc.console.print(f"       Goal: {sprint.goal}")
            pc.console.print(f"       Tasks: {len(sprint.task_ids)}")

    tasks = task_parser.parse_all(plan.slug)
    if tasks:
        pc.console.print("\n[cyan]Tasks:[/cyan]")
        for task in tasks:
            pc.console.print(f"  {task.status_emoji} {task.id}: {task.title}")
            pc.console.print(f"       Priority: {task.priority} | Complexity: {task.complexity}")

        pc.display_plan_intelligence(paircoder_dir, tasks)


def plan_tasks(
    plan_id: str = typer.Argument(..., help="Plan ID"),
    status: Optional[str] = typer.Option(
        None, "--status", "-s",
        help="Filter: pending|in_progress|review|done|blocked"
    ),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List tasks for a specific plan."""
    import bpsai_pair.planning.plan_commands as pc

    paircoder_dir = pc.find_paircoder_dir()
    plan_parser = pc.PlanParser(paircoder_dir / "plans")
    task_parser = pc.TaskParser(paircoder_dir / "tasks")

    plan = plan_parser.get_plan_by_id(plan_id)
    if not plan:
        pc.console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    tasks = task_parser.parse_all(plan.slug)

    if status:
        tasks = [t for t in tasks if t.status.value == status]

    if json_out:
        data = [t.to_dict() for t in tasks]
        pc.console.print(json.dumps(data, indent=2, default=str))
        return

    if not tasks:
        pc.console.print(f"[dim]No tasks found for plan: {plan_id}[/dim]")
        return

    table = Table(title=f"Tasks for {plan_id}")
    table.add_column("Status", width=3)
    table.add_column("ID", style="cyan")
    table.add_column("Title")
    table.add_column("Priority")
    table.add_column("Complexity", justify="right")
    table.add_column("Sprint")

    for task in tasks:
        table.add_row(
            task.status_emoji,
            task.id,
            task.title,
            task.priority,
            str(task.complexity),
            task.sprint or "-",
        )

    pc.console.print(table)
