"""Skill recommend command — surfaces intelligent skill recommendations.

Uses IntelligentSkillRecommender to suggest skills based on
intelligence signals (telemetry, gaps, gates, sessions).
"""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from bpsai_pair.intelligence import (
    IntelligentSkillRecommender,
    RecommendationSet,
)

console = Console()


def _build_recommender() -> IntelligentSkillRecommender:
    """Create a recommender with all available mappers.

    Tries to load each mapper; skips any that fail to initialize.
    """
    from bpsai_pair.intelligence import (
        GapMapper,
        GateMapper,
        ScorerMapper,
        SessionMapper,
        TelemetryMapper,
    )

    mappers = []
    for mapper_cls in [GapMapper, GateMapper, ScorerMapper, SessionMapper, TelemetryMapper]:
        try:
            mappers.append(mapper_cls())
        except Exception:
            pass
    return IntelligentSkillRecommender(mappers=mappers)


def _build_context() -> dict:
    """Build context dict for the recommender from project state."""
    from bpsai_pair.skills.display_helpers import find_project_root

    ctx: dict = {}
    try:
        ctx["project_root"] = str(find_project_root())
    except (FileNotFoundError, Exception):
        ctx["project_root"] = "."
    return ctx


def _display_text(result_set: RecommendationSet, verbose: bool) -> None:
    """Display recommendations as a Rich table."""
    if not result_set.recommendations:
        console.print("[dim]No recommendations available.[/dim]")
        console.print("[dim]Run some tasks to generate intelligence signals.[/dim]")
        return

    table = Table(title="Skill Recommendations")
    table.add_column("#", style="dim", width=3)
    table.add_column("Skill", style="cyan")
    table.add_column("Score", justify="right")
    table.add_column("Confidence", justify="right")
    table.add_column("Top Reason", style="dim")

    for i, rec in enumerate(result_set.recommendations, 1):
        reason = rec.reasons[0] if rec.reasons else "-"
        table.add_row(
            str(i),
            rec.skill_name,
            f"{rec.score:.2f}",
            f"{rec.confidence:.2f}",
            reason,
        )

    console.print(table)
    console.print(
        f"\n[dim]{result_set.signal_count} signals from "
        f"{result_set.mapper_count} mappers[/dim]",
    )

    if verbose:
        _display_verbose(result_set)


def _display_verbose(result_set: RecommendationSet) -> None:
    """Display detailed signal information for each recommendation."""
    console.print("\n[bold]Signal Details[/bold]\n")
    for rec in result_set.recommendations:
        console.print(f"[cyan]{rec.skill_name}[/cyan]")
        for sig in rec.signals:
            console.print(
                f"  {sig.source} {sig.category}: "
                f"value={sig.value:.2f}, confidence={sig.confidence:.2f}",
            )
        if not rec.signals:
            console.print("  [dim]No signals[/dim]")
        console.print()


def _display_json(result_set: RecommendationSet) -> None:
    """Display recommendations as JSON."""
    console.print(json.dumps(result_set.to_dict(), indent=2))


def skill_recommend(
    top: int = typer.Option(5, "--top", help="Number of recommendations"),
    fmt: str = typer.Option("text", "--format", help="Output format: text or json"),
    verbose: bool = typer.Option(False, "--verbose", help="Show signal details"),
) -> None:
    """Recommend skills based on intelligence signals.

    Analyzes telemetry, gaps, gates, and session patterns to suggest
    the most relevant skills for your current workflow.

    Examples:

        bpsai-pair skill recommend
        bpsai-pair skill recommend --top 3
        bpsai-pair skill recommend --format json
        bpsai-pair skill recommend --verbose
    """
    recommender = _build_recommender()
    context = _build_context()
    result_set = recommender.recommend(context, top_k=top)

    if fmt == "json":
        _display_json(result_set)
    else:
        _display_text(result_set, verbose=verbose)
