"""Skill score formatting for CLI display."""

from typing import List

from .scorer_models import SkillScore


def format_skill_score(score: SkillScore) -> str:
    """Format skill score for CLI display.

    Args:
        score: SkillScore to format

    Returns:
        Formatted string
    """
    # Grade color
    grade_colors = {
        "A": "green",
        "B": "cyan",
        "C": "yellow",
        "D": "red",
        "F": "red",
    }
    grade_color = grade_colors.get(score.grade, "white")

    lines = [
        f"Skill: {score.skill_name}",
        "=" * 50,
        f"Overall Score: {score.overall_score}/100 (Grade: [{grade_color}]{score.grade}[/{grade_color}])",
        "",
        "Dimension Scores:",
    ]

    for dim in score.dimensions:
        score_bar = "█" * int(dim.score * 10) + "░" * (10 - int(dim.score * 10))
        weight_pct = int(dim.weight * 100)
        lines.append(f"  {dim.name:18} [{score_bar}] {dim.score:.2f} (weight: {weight_pct}%)")
        lines.append(f"    {dim.reason}")

    if score.recommendations:
        lines.extend(["", "Recommendations:"])
        for i, rec in enumerate(score.recommendations, 1):
            lines.append(f"  {i}. {rec}")

    return "\n".join(lines)


def format_score_table(scores: List[SkillScore]) -> str:
    """Format scores as a table.

    Args:
        scores: List of scores

    Returns:
        Formatted table string
    """
    lines = [
        "Skill Quality Report",
        "=" * 70,
        "",
        f"{'Skill':<30} {'Score':>6} {'Grade':>6} {'Token':>6} {'Trigger':>7} {'Complete':>8}",
        "-" * 70,
    ]

    for score in scores:
        token = next((d for d in score.dimensions if d.name == "token_efficiency"), None)
        trigger = next((d for d in score.dimensions if d.name == "trigger_clarity"), None)
        complete = next((d for d in score.dimensions if d.name == "completeness"), None)

        token_score = f"{int(token.score * 100)}" if token else "-"
        trigger_score = f"{int(trigger.score * 100)}" if trigger else "-"
        complete_score = f"{int(complete.score * 100)}" if complete else "-"

        lines.append(
            f"{score.skill_name:<30} {score.overall_score:>6} {score.grade:>6} "
            f"{token_score:>6} {trigger_score:>7} {complete_score:>8}"
        )

    lines.extend([
        "-" * 70,
        f"Total: {len(scores)} skills scored",
    ])

    return "\n".join(lines)
