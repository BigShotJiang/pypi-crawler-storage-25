"""Gap Quality Gates — facade for quality gate evaluation.

Re-exports data types from gate_definitions and the evaluation
engine from gate_evaluator. Also provides top-level convenience
functions (evaluate_gap_quality, format_gate_result).
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Union

from .classifier import ClassifiedGap
from .gap_detector import SkillGap
from .gate_definitions import (
    GENERIC_COMMANDS,
    GENERIC_PATTERNS,
    TRIVIAL_PATTERN_PAIRS,
    GateResult,
    GateStatus,
    QualityGateResult,
)
from .gate_evaluator import GapQualityGate
from .subagent_detector import SubagentGap

# Re-export everything for backward compatibility
__all__ = [
    "GateStatus",
    "GateResult",
    "QualityGateResult",
    "GapQualityGate",
    "GENERIC_COMMANDS",
    "TRIVIAL_PATTERN_PAIRS",
    "GENERIC_PATTERNS",
    "evaluate_gap_quality",
    "format_gate_result",
]


def evaluate_gap_quality(
    gap: Union[SkillGap, SubagentGap, ClassifiedGap],
    skills_dir: Optional[Path] = None,
) -> QualityGateResult:
    """High-level function to evaluate gap quality."""
    existing_skills: List[str] = []
    if skills_dir and skills_dir.exists():
        for skill_dir in skills_dir.iterdir():
            if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                existing_skills.append(skill_dir.name)

    gate = GapQualityGate(existing_skills=existing_skills, skills_dir=skills_dir)
    return gate.evaluate(gap)


def format_gate_result(result: QualityGateResult) -> str:
    """Format gate result for CLI display."""
    if result.overall_status == GateStatus.PASS:
        status_icon, status_text = "✅", "PASS"
    elif result.overall_status == GateStatus.WARN:
        status_icon, status_text = "⚠️", "WARN"
    else:
        status_icon, status_text = "❌", "BLOCKED"

    lines = [
        f"Quality Gate Results: {result.gap_name}",
        "=" * 50,
        f"Overall: {status_icon} {status_text}",
        "",
        "Gate Results:",
    ]

    for gate in result.gate_results:
        if gate.status == GateStatus.PASS:
            icon = "✅"
        elif gate.status == GateStatus.WARN:
            icon = "⚠️"
        else:
            icon = "❌"

        score_bar = "█" * int(gate.score * 10) + "░" * (10 - int(gate.score * 10))
        lines.append(f"  {icon} {gate.gate_name:12} [{score_bar}] {gate.score:.2f}")
        lines.append(f"     {gate.reason}")
        if gate.details:
            lines.append(f"     [dim]{gate.details}[/dim]")

    lines.extend(["", f"Recommendation: {result.recommendation}"])
    return "\n".join(lines)
