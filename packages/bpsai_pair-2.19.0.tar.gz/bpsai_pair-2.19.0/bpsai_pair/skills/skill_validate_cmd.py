"""Skill validate and score commands.

Extracted from skill_commands.py. Dependencies imported lazily
from skill_commands to preserve existing mock paths.
"""

from pathlib import Path
from typing import Optional

import typer

from .display_helpers import (
    console,
    display_result,
    display_skill_score,
    display_score_table,
)
from .validator import SkillValidator


def _get_deps():
    """Lazy-import find_skills_dir and SkillScorer from skill_commands.

    Preserves mock paths at ``bpsai_pair.skills.skill_commands.*``.
    """
    from . import skill_commands as _cmds
    return _cmds.find_skills_dir, _cmds.SkillScorer


def _load_telemetry_store():
    """Try to load a TelemetryStore from the project's .paircoder dir.

    Returns None if the store doesn't exist or can't be loaded.
    """
    try:
        from .display_helpers import find_project_root
        from ..telemetry.store import TelemetryStore

        project_root = find_project_root()
        store = TelemetryStore(project_root)
        if not store._telemetry_file.exists():
            return None
        return store
    except Exception:
        return None

def _validate_single(
    validator: SkillValidator,
    skills_dir,
    skill_name: str,
    fix: bool,
    json_out: bool,
) -> None:
    """Validate a single skill."""
    import json

    skill_dir = skills_dir / skill_name
    if not skill_dir.exists():
        console.print(f"[red]Skill not found: {skill_name}[/red]")
        raise typer.Exit(1)

    if fix:
        fixed = validator.fix_skill(skill_dir)
        if fixed:
            console.print(f"[green]Fixed issues in {skill_name}[/green]")

    result = validator.validate_skill(skill_dir)
    if json_out:
        console.print(json.dumps(result, indent=2))
    else:
        display_result(skill_name, result)
    raise typer.Exit(0 if result["valid"] else 1)

def _validate_all(
    validator: SkillValidator,
    skills_dir,
    fix: bool,
    json_out: bool,
) -> None:
    """Validate all skills."""
    import json

    results = validator.validate_all()

    if not results:
        console.print("[dim]No skills found in .claude/skills/[/dim]")
        return

    if fix:
        console.print("[cyan]Attempting to fix issues...[/cyan]\n")
        for skill_name_key in results:
            skill_dir = skills_dir / skill_name_key
            fixed = validator.fix_skill(skill_dir)
            if fixed:
                console.print(f"  [green]Fixed: {skill_name_key}[/green]")
        console.print()
        results = validator.validate_all()

    if json_out:
        console.print(json.dumps(results, indent=2))
        return

    console.print(f"\n[bold]Validating {len(results)} skills...[/bold]\n")

    for skill_name_key, result in sorted(results.items()):
        display_result(skill_name_key, result)

    summary = validator.get_summary(results)
    console.print(
        f"\n[bold]Summary:[/bold] {summary['passed']} pass, "
        f"{summary['with_warnings']} warnings, {summary['failed']} errors"
    )

    if summary["failed"] > 0:
        raise typer.Exit(1)


def skill_validate(
    skill_name: Optional[str] = typer.Argument(None, help="Specific skill to validate"),
    fix: bool = typer.Option(False, "--fix", help="Auto-correct simple issues"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Validate skills against Anthropic specs.

    Checks:
    - Frontmatter has only 'name' and 'description' fields
    - Description under 1024 characters
    - 3rd-person voice (warns on 2nd person)
    - File under 500 lines
    - Name matches directory name

    Use --fix to auto-correct simple issues.
    """
    find_skills_dir, _ = _get_deps()

    try:
        skills_dir = find_skills_dir()
    except FileNotFoundError:
        console.print("[red]Could not find .claude/skills directory[/red]")
        raise typer.Exit(1)

    validator = SkillValidator(skills_dir)

    if skill_name:
        _validate_single(validator, skills_dir, skill_name, fix, json_out)
        return

    _validate_all(validator, skills_dir, fix, json_out)


def _score_single(scorer, skill_name: str, json_out: bool) -> None:
    """Score a single skill and display results."""
    import json

    score = scorer.score_skill(skill_name)
    if not score:
        console.print(f"[red]Skill not found: {skill_name}[/red]")
        raise typer.Exit(1)

    if json_out:
        console.print(json.dumps(score.to_dict(), indent=2))
        return
    display_skill_score(score)


def _score_all(scorer, json_out: bool) -> None:
    """Score all skills and display results."""
    import json

    scores = scorer.score_all()
    if not scores:
        console.print("[dim]No skills found to score.[/dim]")
        return

    if json_out:
        output = {
            "skills": [s.to_dict() for s in scores],
            "total": len(scores),
            "average_score": sum(s.overall_score for s in scores) // len(scores),
        }
        console.print(json.dumps(output, indent=2))
        return
    display_score_table(scores)


def skill_score_cmd(
    skill_name: Optional[str] = typer.Argument(None, help="Specific skill to score"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Score skills on quality dimensions.

    Evaluates skills on token efficiency, trigger clarity, completeness,
    usage frequency, and portability.

    Examples:

        # Score all skills
        bpsai-pair skill score

        # Score specific skill
        bpsai-pair skill score implementing-with-tdd

        # Output as JSON
        bpsai-pair skill score --json
    """
    find_skills_dir, SkillScorer = _get_deps()

    try:
        skills_dir = find_skills_dir()
    except FileNotFoundError:
        console.print("[red]Could not find .claude/skills directory[/red]")
        raise typer.Exit(1)

    telemetry_store = _load_telemetry_store()
    scorer = SkillScorer(skills_dir, telemetry_store=telemetry_store)

    if skill_name:
        _score_single(scorer, skill_name, json_out)
    else:
        _score_all(scorer, json_out)
