"""Telemetry integration for skill scorer.

Extracts skill usage frequency data from TelemetryStore records
to feed into SkillScorer usage_data.
"""

from collections import Counter
from typing import Any, Dict


def extract_skill_usage(telemetry_store: Any) -> Dict[str, int]:
    """Extract skill usage counts from telemetry store features_used.

    Args:
        telemetry_store: A TelemetryStore instance with query() method

    Returns:
        Dict mapping feature/skill names to usage counts
    """
    records = telemetry_store.query(limit=10000)
    counts: Counter[str] = Counter()
    for record in records:
        for feat in getattr(record, "features_used", []):
            counts[feat] += 1
    return dict(counts)
