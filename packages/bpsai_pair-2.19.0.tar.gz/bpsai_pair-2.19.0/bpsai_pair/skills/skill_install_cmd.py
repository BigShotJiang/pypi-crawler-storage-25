"""Skill install command.

Extracted from skill_commands.py to keep modules under 200 lines.
Dependencies (install_skill) are imported lazily from skill_commands
to preserve existing mock paths.
"""

from typing import Optional

import typer

from .display_helpers import console
from .installer import (
    SkillInstallerError,
    SkillSource,
    parse_source,
    get_target_dir,
    extract_skill_name,
)


def _get_install_skill():
    """Lazy-import install_skill from skill_commands.

    This preserves mock paths: tests patch at
    ``bpsai_pair.skills.skill_commands.install_skill``.
    """
    from . import skill_commands as _cmds
    return _cmds.install_skill


def _display_source_info(source: str, source_type, parsed, skill_name: str) -> None:
    """Print source and target info for install."""
    console.print(f"\n[bold]Installing skill: {skill_name}[/bold]")
    if source_type == SkillSource.PATH:
        console.print(f"  Source: [dim]{parsed}[/dim]")
    else:
        console.print(f"  Source: [dim]{source}[/dim]")


def _run_install(source, source_type, do_install, project, personal, name, overwrite):
    """Execute install and display results."""
    target_dir = get_target_dir(project=project, personal=personal)
    console.print(f"  Target: [dim]{target_dir}[/dim]\n")

    console.print(
        "[cyan]Downloading...[/cyan]"
        if source_type == SkillSource.URL
        else "[cyan]Copying...[/cyan]"
    )

    result = do_install(
        source, project=project, personal=personal, name=name, force=overwrite,
    )

    console.print("[cyan]Validating...[/cyan]")
    console.print("  [green]\u2713[/green] Frontmatter valid")
    console.print("  [green]\u2713[/green] Description under 1024 chars")
    console.print(
        "  [green]\u2713[/green] No conflicts with existing skills"
        if not overwrite
        else "  [yellow]\u2713[/yellow] Overwrote existing skill"
    )
    console.print(
        f"\n[green]\u2705 Installed {result['skill_name']} to "
        f"{result['installed_to']}/[/green]"
    )


def skill_install(
    source: str = typer.Argument(..., help="Source URL or local path to skill"),
    project: bool = typer.Option(
        False, "--project", help="Install to project .claude/skills/"
    ),
    personal: bool = typer.Option(
        False, "--personal", help="Install to ~/.claude/skills/"
    ),
    name: Optional[str] = typer.Option(
        None, "--name", "-n", help="Install with different name"
    ),
    overwrite: bool = typer.Option(
        False, "--overwrite", "-o", help="Overwrite existing skill"
    ),
) -> None:
    """Install a skill from URL or local path.

    Examples:
        bpsai-pair skill install ~/my-skills/custom-review
        bpsai-pair skill install ./my-skill --name renamed-skill
        bpsai-pair skill install ./my-skill --personal --overwrite
    """
    do_install = _get_install_skill()

    try:
        source_type, parsed = parse_source(source)
        skill_name = name or extract_skill_name(source)
        _display_source_info(source, source_type, parsed, skill_name)

        if not project and not personal:
            project = True

        _run_install(source, source_type, do_install, project, personal, name, overwrite)

    except SkillInstallerError as e:
        console.print(f"\n[red]\u274c Installation failed: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"\n[red]\u274c Unexpected error: {e}[/red]")
        raise typer.Exit(1)
