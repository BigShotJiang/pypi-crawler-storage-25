"""Skill suggestion generation from detected patterns.

Extracted from suggestion.py for modular architecture.
"""

import re
import logging
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


class SkillSuggester:
    """Generates skill suggestions from detected patterns."""

    # Mapping of command types to gerund verbs
    COMMAND_VERBS = {
        "pytest": "testing",
        "test": "testing",
        "git": "managing-git",
        "commit": "committing",
        "diff": "reviewing",
        "review": "reviewing",
        "read": "reading",
        "edit": "editing",
        "debug": "debugging",
        "fix": "fixing",
        "build": "building",
        "deploy": "deploying",
        "lint": "linting",
        "format": "formatting",
    }

    def __init__(self, skills_dir: Optional[Path] = None):
        self.skills_dir = skills_dir
        self._existing_skills = self._load_existing_skills()

    def _load_existing_skills(self) -> Dict[str, str]:
        """Load existing skill names and descriptions."""
        skills = {}
        if not self.skills_dir or not self.skills_dir.exists():
            return skills

        for skill_dir in self.skills_dir.iterdir():
            if skill_dir.is_dir():
                skill_file = skill_dir / "SKILL.md"
                if skill_file.exists():
                    try:
                        content = skill_file.read_text(encoding="utf-8")
                        if content.startswith("---"):
                            end_idx = content.find("---", 3)
                            if end_idx > 0:
                                yaml_content = content[3:end_idx]
                                fm = yaml.safe_load(yaml_content) or {}
                                skills[skill_dir.name] = fm.get("description", "")
                    except Exception as e:
                        logger.warning(f"Error loading skill {skill_dir.name}: {e}")

        return skills

    def generate_suggestions(self, patterns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate skill suggestions from patterns."""
        suggestions = []

        for pattern in patterns:
            suggestion = self._pattern_to_suggestion(pattern)
            if suggestion:
                overlaps = self._check_overlap(suggestion)
                if overlaps:
                    suggestion["overlaps_with"] = overlaps
                suggestions.append(suggestion)

        return suggestions

    def _pattern_to_suggestion(self, pattern: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert a pattern to a skill suggestion."""
        sequence = pattern.get("sequence", [])
        if not sequence:
            return None

        name = self._generate_name(sequence)
        description = self._generate_description(sequence, pattern)
        estimated_savings = self._estimate_savings(pattern)

        return {
            "name": name,
            "description": description,
            "confidence": pattern.get("confidence", 0),
            "pattern": sequence,
            "occurrences": pattern.get("occurrences", 0),
            "estimated_savings": estimated_savings,
        }

    def _generate_name(self, sequence: List[str]) -> str:
        """Generate a skill name from a command sequence."""
        primary_verb = None
        for cmd in sequence:
            cmd_lower = cmd.lower()
            for key, verb in self.COMMAND_VERBS.items():
                if key in cmd_lower:
                    primary_verb = verb
                    break
            if primary_verb:
                break

        if not primary_verb:
            primary_verb = "managing"

        context_words = []
        for cmd in sequence:
            cmd_lower = cmd.lower()
            words = re.findall(r"[a-z]+", cmd_lower)
            for word in words:
                if word not in self.COMMAND_VERBS and len(word) > 2:
                    context_words.append(word)

        if context_words:
            context = Counter(context_words).most_common(1)[0][0]
            name = f"{primary_verb}-{context}"
        else:
            name = f"{primary_verb}-workflows"

        return name.lower()

    def _generate_description(self, sequence: List[str], pattern: Dict[str, Any]) -> str:
        """Generate a description for the skill."""
        action_words = []
        for cmd in sequence[:3]:
            cmd_lower = cmd.lower()
            for key, verb in self.COMMAND_VERBS.items():
                if key in cmd_lower:
                    action_words.append(verb.replace("-", " "))
                    break

        if action_words:
            actions = ", ".join(action_words[:-1])
            if len(action_words) > 1:
                actions += f", and {action_words[-1]}"
            else:
                actions = action_words[0]
            return f"Automates {actions} workflows for improved efficiency."

        return "Automates a repeated workflow pattern."

    def _estimate_savings(self, pattern: Dict[str, Any]) -> str:
        """Estimate time savings from automating this pattern."""
        occurrences = pattern.get("occurrences", 0)
        sequence_length = pattern.get("sequence_length", 2)

        estimated_seconds = occurrences * sequence_length * 20

        if estimated_seconds < 60:
            return f"~{estimated_seconds} seconds per cycle"
        else:
            minutes = estimated_seconds // 60
            return f"~{minutes} minutes per cycle"

    def _check_overlap(self, suggestion: Dict[str, Any]) -> List[str]:
        """Check if suggestion overlaps with existing skills."""
        overlaps = []
        suggestion_name = suggestion.get("name", "").lower()
        suggestion_pattern = suggestion.get("pattern", [])

        for skill_name, skill_desc in self._existing_skills.items():
            if self._names_similar(suggestion_name, skill_name):
                overlaps.append(skill_name)
                continue

            pattern_keywords = set()
            for cmd in suggestion_pattern:
                pattern_keywords.update(re.findall(r"[a-z]+", cmd.lower()))

            desc_lower = skill_desc.lower()
            matching_keywords = sum(1 for kw in pattern_keywords if kw in desc_lower)
            if matching_keywords >= len(pattern_keywords) * 0.5:
                overlaps.append(skill_name)

        return overlaps

    def _names_similar(self, name1: str, name2: str) -> bool:
        """Check if two skill names are similar."""
        words1 = set(name1.split("-"))
        words2 = set(name2.split("-"))

        common = words1 & words2
        if len(common) >= min(len(words1), len(words2)) * 0.5:
            return True

        return False
