"""Skill export command.

Extracted from skill_commands.py to keep modules under 200 lines.
Dependencies (find_skills_dir, find_project_root) are imported lazily
from skill_commands to preserve existing mock paths.
"""

from typing import Optional

import typer

from .display_helpers import console
from .exporter import (
    export_skill,
    export_all_skills,
    check_portability,
    ExportFormat,
    SkillExporterError,
)


def _get_dirs():
    """Lazy-import find_skills_dir/find_project_root from skill_commands.

    This preserves mock paths: tests patch at
    ``bpsai_pair.skills.skill_commands.find_skills_dir`` and this function
    resolves through that same namespace at call time.
    """
    from . import skill_commands as _cmds
    return _cmds.find_skills_dir, _cmds.find_project_root


def _display_all_skills_results(
    results: list[dict], dry_run: bool
) -> None:
    """Display results for exporting all skills."""
    success_count = sum(1 for r in results if r.get("success"))
    for result in results:
        if result.get("success"):
            path_key = "would_create" if dry_run else "path"
            console.print(
                f"  [green]\u2713[/green] {result['skill_name']} \u2192 "
                f"{result.get(path_key, 'N/A')}"
            )
            for warning in result.get("warnings", []):
                console.print(f"    [yellow]\u26a0 {warning}[/yellow]")
        else:
            console.print(
                f"  [red]\u274c {result['skill_name']}: "
                f"{result.get('error', 'Unknown error')}[/red]"
            )
    console.print(f"\n[bold]Exported {success_count}/{len(results)} skills[/bold]")


def _display_single_result(result: dict, dry_run: bool) -> None:
    """Display result for exporting a single skill."""
    if result.get("format") == "all":
        exported_to = result.get("exported_to", {})
        for fmt_name, path in exported_to.items():
            console.print(f"  [green]\u2713[/green] {fmt_name}: {path}")
        for warning in result.get("warnings", []):
            console.print(f"\n[yellow]\u26a0 {warning}[/yellow]")
        console.print(f"\n{result.get('summary', 'Export complete')}")
    elif dry_run:
        console.print(f"[dim]Would create: {result.get('would_create')}[/dim]")
    else:
        console.print(f"[green]\u2705 Exported to {result.get('path')}[/green]")


def _resolve_export_args(skill_name, all_skills, format):
    """Validate inputs and resolve directories for export."""
    if not skill_name and not all_skills:
        console.print("[red]Error: Specify a skill name or use --all[/red]")
        raise typer.Exit(1)

    try:
        export_format = ExportFormat(format.lower())
    except ValueError:
        console.print(
            f"[red]Error: Invalid format '{format}'. "
            "Use: cursor, continue, windsurf, codex, chatgpt, all[/red]"
        )
        raise typer.Exit(1)

    find_skills_dir, find_project_root = _get_dirs()
    try:
        skills_dir = find_skills_dir()
        project_dir = find_project_root()
    except FileNotFoundError:
        console.print("[red]Could not find .claude/skills directory[/red]")
        raise typer.Exit(1)

    return export_format, skills_dir, project_dir


def skill_export(
    skill_name: Optional[str] = typer.Argument(
        None, help="Skill to export (or use --all)"
    ),
    format: str = typer.Option(
        "cursor",
        "--format",
        "-f",
        help="Export format: cursor, continue, windsurf, codex, chatgpt, all",
    ),
    all_skills: bool = typer.Option(False, "--all", "-a", help="Export all skills"),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n", help="Show what would be created without creating"
    ),
) -> None:
    """Export skills to other AI coding tool formats.

    Formats: cursor, continue, windsurf, codex, chatgpt, all.

    Examples:
        bpsai-pair skill export my-skill --format cursor
        bpsai-pair skill export my-skill --format all
        bpsai-pair skill export --all --format continue
        bpsai-pair skill export my-skill --format windsurf --dry-run
    """
    export_format, skills_dir, project_dir = _resolve_export_args(
        skill_name, all_skills, format
    )

    if dry_run:
        console.print("[yellow]Dry run mode - no files will be created[/yellow]\n")

    try:
        if all_skills:
            _export_all(export_format, format, skills_dir, project_dir, dry_run)
        else:
            _export_single(
                skill_name, export_format, skills_dir, project_dir, format, dry_run
            )
    except SkillExporterError as e:
        console.print(f"\n[red]\u274c Export failed: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"\n[red]\u274c Unexpected error: {e}[/red]")
        raise typer.Exit(1)


def _export_all(export_format, format, skills_dir, project_dir, dry_run):
    """Handle --all export path."""
    console.print(f"[bold]Exporting all skills to {format}...[/bold]\n")
    results = export_all_skills(
        format=export_format,
        skills_dir=skills_dir,
        project_dir=project_dir,
        dry_run=dry_run,
    )
    if not results:
        console.print("[dim]No skills found to export.[/dim]")
        return
    _display_all_skills_results(results, dry_run)


def _export_single(skill_name, export_format, skills_dir, project_dir, format, dry_run):
    """Handle single-skill export path."""
    console.print(f"[bold]Exporting {skill_name} to {format}...[/bold]\n")

    skill_dir = skills_dir / skill_name
    if skill_dir.exists() and export_format != ExportFormat.ALL:
        warnings = check_portability(skill_dir)
        for warning in warnings:
            console.print(f"[yellow]\u26a0 {warning}[/yellow]")
        if warnings:
            console.print()

    result = export_skill(
        skill_name=skill_name,
        format=export_format,
        skills_dir=skills_dir,
        project_dir=project_dir,
        dry_run=dry_run,
    )
    _display_single_result(result, dry_run)
