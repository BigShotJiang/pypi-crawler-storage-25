"""Generator I/O — Save and orchestrate skill generation from gap IDs."""

import logging
from pathlib import Path
from typing import Any, Dict

from .generator_models import GeneratedSkill, SkillGeneratorError
from .suggestion import BLOCKED_SKILL_NAMES
from .validator import SkillValidator

logger = logging.getLogger(__name__)


def save_generated_skill(
    skill: GeneratedSkill,
    skills_dir: Path,
    force: bool = False,
    auto_approve: bool = False,
) -> Dict[str, Any]:
    """Save a generated skill to the skills directory.

    Args:
        skill: The generated skill
        skills_dir: Path to skills directory
        force: Overwrite existing skill
        auto_approve: Skip confirmation (same as saving directly)

    Returns:
        Result dict with success status

    Raises:
        SkillGeneratorError: If skill exists and force=False
    """
    # Check blocked skill names (permanent blocklist)
    if skill.name.lower() in BLOCKED_SKILL_NAMES:
        raise SkillGeneratorError(
            f"Skill name '{skill.name}' is permanently blocked. "
            f"This pattern is too trivial to be a skill."
        )

    skill_dir = skills_dir / skill.name
    skill_file = skill_dir / "SKILL.md"

    # Check if exists
    if skill_dir.exists() and not force:
        raise SkillGeneratorError(
            f"Skill '{skill.name}' already exists. Use --force to overwrite."
        )

    # Create directory and write file
    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file.write_text(skill.content, encoding="utf-8")

    # Validate the generated skill
    validator = SkillValidator(skills_dir)
    validation = validator.validate_skill(skill_dir)

    if not validation["valid"]:
        # Try to fix common issues
        validator.fix_skill(skill_dir)
        validation = validator.validate_skill(skill_dir)

    return {
        "success": True,
        "path": str(skill_file),
        "name": skill.name,
        "validation": validation,
        "requires_review": skill.requires_review,
    }


def generate_skill_from_gap_id(
    gap_id: int,
    history_dir: Path,
    skills_dir: Path,
    force: bool = False,
    auto_approve: bool = False,
) -> Dict[str, Any]:
    """Generate a skill from a gap ID.
    ...
    """
    from .gap_detector import GapPersistence
    from .gates import evaluate_gap_quality, GateStatus
    from .generator_engine import SkillGenerator

    # Load gaps
    persistence = GapPersistence(history_dir=history_dir)
    gaps = persistence.load_gaps()

    if not gaps:
        raise SkillGeneratorError("No skill gaps found. Run `skill gaps --analyze` first.")

    if gap_id < 1 or gap_id > len(gaps):
        raise SkillGeneratorError(f"Invalid gap ID: {gap_id}. Valid range: 1-{len(gaps)}")

    gap = gaps[gap_id - 1]

    # ENFORCEMENT: Run quality gates before generation
    gate_result = evaluate_gap_quality(gap, skills_dir=skills_dir)

    if not gate_result.can_generate and not force:
        blocked_gates = [g.gate_name for g in gate_result.gate_results
                         if g.status == GateStatus.BLOCK]
        raise SkillGeneratorError(
            f"Quality gates blocked generation: {', '.join(blocked_gates)}. "
            f"Reason: {gate_result.recommendation}\n"
            f"Use --force to override (not recommended)."
        )

    if gate_result.overall_status == GateStatus.WARN and not force:
        # Log warning but proceed
        logger.warning(f"Quality gate warnings for '{gap.suggested_name}': {gate_result.recommendation}")

    # Generate skill
    generator = SkillGenerator()
    generated = generator.generate_from_gap(gap)

    # Save if auto_approve
    if auto_approve:
        return save_generated_skill(generated, skills_dir, force=force, auto_approve=True)

    # Return generated content for review
    return {
        "success": True,
        "generated": generated,
        "preview": generated.content,
        "requires_confirmation": True,
    }
