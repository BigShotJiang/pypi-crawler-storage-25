"""Skill CLI commands — hub module.

Re-exports all command functions and shared dependencies so that
existing mock paths (``bpsai_pair.skills.skill_commands.X``) continue
to work after decomposition.

Command implementations live in:
- skill_validate_cmd.py  (validate, score)
- skill_install_cmd.py   (install)
- skill_export_cmd.py    (export)
- skill_gap_commands.py  (suggest, gaps, generate)
"""

import typer

# -- Re-exports that tests mock at ``skill_commands.*`` --
from .display_helpers import (  # noqa: F401
    console,
    find_project_root,
    display_result,
    display_skill_score,
    display_score_table,
)
from .validator import SkillValidator, find_skills_dir  # noqa: F401
from .installer import (  # noqa: F401
    install_skill,
    SkillInstallerError,
    SkillSource,
    parse_source,
    get_target_dir,
    extract_skill_name,
)
from .exporter import (  # noqa: F401
    export_skill,
    export_all_skills,
    check_portability,
    ExportFormat,
    SkillExporterError,
)
from .scorer import (  # noqa: F401
    SkillScorer,
    SkillScore,
)

# -- Import command functions from extracted modules --
from .skill_gap_commands import register_gap_commands
from .skill_install_cmd import skill_install
from .skill_export_cmd import skill_export
from .skill_validate_cmd import skill_validate, skill_score_cmd
from .skill_recommend_cmd import skill_recommend

# -- Build Typer app and register all commands --
skill_app = typer.Typer(
    help="Manage and validate Claude Code skills",
    context_settings={"help_option_names": ["-h", "--help"]},
)

register_gap_commands(skill_app)
skill_app.command("validate")(skill_validate)
skill_app.command("score")(skill_score_cmd)
skill_app.command("install")(skill_install)
skill_app.command("export")(skill_export)
skill_app.command("recommend")(skill_recommend)


@skill_app.command("list")
def skill_list() -> None:
    """List all skills in .claude/skills/."""
    from rich.table import Table

    try:
        skills_dir = find_skills_dir()
    except FileNotFoundError:
        console.print("[red]Could not find .claude/skills directory[/red]")
        raise typer.Exit(1)

    skills = []
    for skill_dir in skills_dir.iterdir():
        if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
            skills.append(skill_dir.name)

    if not skills:
        console.print("[dim]No skills found.[/dim]")
        return

    table = Table(title=f"Skills ({len(skills)})")
    table.add_column("Name", style="cyan")
    table.add_column("Path", style="dim")

    for name in sorted(skills):
        table.add_row(name, f".claude/skills/{name}/")

    console.print(table)
