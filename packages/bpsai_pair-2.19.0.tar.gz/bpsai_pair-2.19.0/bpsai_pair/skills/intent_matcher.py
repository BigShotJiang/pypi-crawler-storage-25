"""
Intent-to-capability matching for skill discovery.

Scans the skill registry for keyword matches against a user's description.
Surfaces matching skills before plan creation so users know about existing
capabilities.
"""

from __future__ import annotations

import re
from pathlib import Path

# Keyword → skill name mapping for MVP matching
_SKILL_KEYWORDS: dict[str, list[str]] = {
    "implementing-with-tdd": [
        "fix", "bug", "implement", "feature", "test", "tdd", "broken", "error",
    ],
    "reviewing-code": [
        "review", "check", "look at", "inspect", "pr", "code review",
    ],
    "releasing-versions": [
        "release", "version", "bump", "publish", "deploy", "ship",
    ],
    "designing-and-implementing": [
        "build", "create", "add", "design", "architect", "new feature",
    ],
    "finishing-branches": [
        "done", "finish", "merge", "complete", "ready",
    ],
    "planning-with-trello": [
        "plan", "sprint", "trello", "backlog", "roadmap",
    ],
    "architecting-modules": [
        "split", "decompose", "too large", "refactor", "extract",
    ],
    "creating-skills": [
        "skill", "workflow", "automate", "template",
    ],
}


def match_intent(description: str, skills_dir: Path) -> list[str]:
    """Match a user's description against available skills.

    Returns a list of skill names that match keywords in the description.
    Only returns skills that actually exist in skills_dir.
    """
    if not description or not skills_dir.exists():
        return []

    lower = description.lower()
    available = {d.name for d in skills_dir.iterdir() if d.is_dir()}
    matches: list[str] = []

    for skill_name, keywords in _SKILL_KEYWORDS.items():
        if skill_name not in available:
            continue
        if any(_word_match(kw, lower) for kw in keywords):
            matches.append(skill_name)

    return matches


def _word_match(keyword: str, text: str) -> bool:
    """Check if keyword appears as a whole word/phrase in text."""
    return bool(re.search(rf"\b{re.escape(keyword)}\b", text))


def suggest_skills(description: str, skills_dir: Path) -> str:
    """Generate a user-facing suggestion string for matching skills.

    Returns empty string if no matches found. Non-blocking.
    """
    matches = match_intent(description, skills_dir)
    if not matches:
        return ""

    lines = ["Did you know PairCoder has skills for this?"]
    for name in matches:
        lines.append(f"  - {name}")
    return "\n".join(lines)
