"""Sprint executor — runs tasks phase-by-phase with circuit breaker.

Takes an ExecutionGraph and executes tasks through each phase,
respecting sequential/parallel execution modes and stopping
early if the circuit breaker threshold is exceeded.
"""

from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import typer

from bpsai_pair.orchestration.plan_graph_models import (
    ExecutionGraph,
    ExecutionMode,
    ExecutionPhase,
)

logger = logging.getLogger(__name__)


@dataclass
class SprintConfig:
    """Configuration for sprint execution."""

    max_parallel: int = 3
    task_timeout_minutes: int = 30
    circuit_breaker_threshold: float = 0.5


@dataclass
class SprintResult:
    """Result of a sprint execution."""

    completed_tasks: list[str] = field(default_factory=list)
    failed_tasks: list[str] = field(default_factory=list)
    blocked_tasks: list[str] = field(default_factory=list)
    phases_completed: int = 0
    total_complexity: int = 0
    circuit_breaker_triggered: bool = False
    review_dispatches: list[dict[str, Any]] = field(default_factory=list)


def _default_task_runner(task_id: str) -> bool:
    """Placeholder runner — real implementation wired via DI."""
    logger.warning("No task runner configured, skipping %s", task_id)
    return False


class SprintExecutor:
    """Executes an ExecutionGraph phase-by-phase with circuit breaker."""

    def __init__(
        self,
        project_root: Path,
        graph: ExecutionGraph,
        config: SprintConfig | None = None,
        task_runner: Callable[[str], bool] | None = None,
        review_hook: Callable[[Path, list[str]], dict[str, Any]] | None = None,
    ) -> None:
        self._project_root = project_root
        self._graph = graph
        self._config = config or SprintConfig()
        self._task_runner = task_runner or _default_task_runner
        self._review_hook = review_hook

    def execute(self) -> SprintResult:
        """Run all phases, returning aggregate result."""
        result = SprintResult(
            total_complexity=self._graph.total_complexity(),
        )

        for phase in self._graph.phases:
            mode = "parallel" if phase.execution == ExecutionMode.PARALLEL else "sequential"
            typer.echo(f"\n--- Phase {phase.name} ({len(phase.task_ids)} tasks, {mode}) ---")
            completed, failed = self._execute_phase(phase)
            result.completed_tasks.extend(completed)
            result.failed_tasks.extend(failed)
            result.phases_completed += 1
            typer.echo(f"Phase {phase.name}: {len(completed)} done, {len(failed)} failed")

            # Dispatch review hook after phase if there are completions
            if completed and self._review_hook:
                try:
                    review_meta = self._review_hook(self._project_root, completed)
                    result.review_dispatches.append(review_meta)
                except Exception:
                    logger.warning("Review hook failed for phase %s", phase.name, exc_info=True)
                    result.review_dispatches.append({"dispatched": False, "error": "hook_exception"})

            total = len(completed) + len(failed)
            if total > 0 and self._check_circuit_breaker(
                len(completed), len(failed),
            ):
                result.circuit_breaker_triggered = True
                typer.echo(f"Circuit breaker triggered after phase {phase.name}")
                break

        return result

    def _execute_phase(
        self, phase: ExecutionPhase,
    ) -> tuple[list[str], list[str]]:
        """Execute a single phase. Returns (completed, failed) task IDs."""
        completed: list[str] = []
        failed: list[str] = []

        if phase.execution == ExecutionMode.PARALLEL:
            self._run_parallel(phase.task_ids, completed, failed)
        else:
            self._run_sequential(phase.task_ids, completed, failed)

        return completed, failed

    def _run_sequential(
        self,
        task_ids: list[str],
        completed: list[str],
        failed: list[str],
    ) -> None:
        """Run tasks one at a time in order."""
        for task_id in task_ids:
            self._run_single(task_id, completed, failed)

    def _run_parallel(
        self,
        task_ids: list[str],
        completed: list[str],
        failed: list[str],
    ) -> None:
        """Run tasks in parallel up to max_parallel."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        max_workers = min(self._config.max_parallel, len(task_ids))
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {
                pool.submit(self._task_runner, tid): tid
                for tid in task_ids
            }
            for future in as_completed(futures):
                tid = futures[future]
                try:
                    success = future.result()
                except Exception as exc:
                    logger.error("Task %s raised: %s", tid, exc)
                    failed.append(tid)
                    continue
                if success:
                    self._graph.mark_done(tid)
                    completed.append(tid)
                    self._commit_task(tid)
                else:
                    failed.append(tid)

    def _run_single(
        self,
        task_id: str,
        completed: list[str],
        failed: list[str],
    ) -> None:
        """Run a single task and classify result."""
        logger.info("Running task %s", task_id)
        success = self._task_runner(task_id)
        if success:
            self._graph.mark_done(task_id)
            completed.append(task_id)
            self._commit_task(task_id)
        else:
            failed.append(task_id)

    def _commit_task(self, task_id: str) -> None:
        """Git add + commit after a successful task."""
        node = self._graph.nodes.get(task_id)
        title = node.title if node else ""
        suffix = f" \u2014 {title}" if title else ""
        msg = f"task(engage): {task_id}{suffix}"
        cmd = f"git add -A && git commit -m {msg!r}"
        try:
            subprocess.run(
                cmd, shell=True, cwd=self._project_root,
                capture_output=True, check=False,
            )
        except Exception as exc:
            logger.warning("Commit failed for %s: %s", task_id, exc)

    def _check_circuit_breaker(self, completed: int, failed: int) -> bool:
        """Return True if breaker should trip (failure ratio >= threshold)."""
        total = completed + failed
        if total == 0:
            return False
        failure_ratio = failed / total
        return failure_ratio >= self._config.circuit_breaker_threshold
