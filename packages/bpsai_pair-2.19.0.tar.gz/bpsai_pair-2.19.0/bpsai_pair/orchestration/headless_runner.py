"""Headless runner — bridges engage command to HeadlessSession execution.

Factory function that returns a task_runner callback compatible with
SprintExecutor's Callable[[str], bool] interface.

Emits telemetry records for every headless task invocation.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from bpsai_pair.orchestration.headless import HeadlessResponse, HeadlessSession, PermissionMode
from bpsai_pair.planning.task_parser import parse_frontmatter
from bpsai_pair.telemetry.schema import (
    Outcome,
    PrivacyLevel,
    TelemetryRecord,
    TokenUsage,
    classify_fail_detail,
)
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)


def _build_task_prompt(task_id: str, task_content: str) -> str:
    """Build the prompt that invokes /start-task with the task file content."""
    return f"/start-task {task_id}\n\n## Task File\n\n{task_content}"


def _build_telemetry_record(
    task_id: str,
    response: HeadlessResponse,
    frontmatter: dict[str, Any],
    repo: str,
) -> TelemetryRecord:
    """Build a TelemetryRecord from a HeadlessResponse and task frontmatter."""
    outcome = Outcome.FAIL if response.is_error else Outcome.SUCCESS
    outcome_detail = classify_fail_detail(response.error_message) if response.is_error else None
    return TelemetryRecord(
        task_id=task_id,
        task_type=frontmatter.get("type", "unknown"),
        repo=repo,
        model="headless",
        tokens=TokenUsage(input=response.input_tokens, output=response.output_tokens),
        duration_seconds=int(response.duration_seconds),
        human_interventions=0,
        compactions=0,
        outcome=outcome,
        timestamp=datetime.now(timezone.utc),
        privacy_level=PrivacyLevel.STANDARD,
        error_context=response.error_message if response.is_error else None,
        session_id=response.session_id,
        sprint=frontmatter.get("sprint"),
        complexity=frontmatter.get("complexity"),
        outcome_detail=outcome_detail,
        features_used=["headless_runner"],
    )


def _emit_sprint_summary(
    store: TelemetryStore,
    sprint: str,
    results: list[dict[str, Any]],
    repo: str,
) -> None:
    """Emit a sprint-level summary telemetry record."""
    total_duration = sum(r["duration"] for r in results)
    passed = sum(1 for r in results if r["success"])
    total = len(results)

    if passed == total:
        outcome = Outcome.SUCCESS
    elif passed == 0:
        outcome = Outcome.FAIL
    else:
        outcome = Outcome.PARTIAL

    record = TelemetryRecord(
        task_id=f"sprint:{sprint}",
        task_type="sprint_summary",
        repo=repo,
        model="headless",
        tokens=TokenUsage(input=0, output=0),
        duration_seconds=int(total_duration),
        human_interventions=0,
        compactions=0,
        outcome=outcome,
        timestamp=datetime.now(timezone.utc),
        privacy_level=PrivacyLevel.STANDARD,
        sprint=sprint,
        features_used=["headless_runner"],
    )
    store.append(record)


def _make_headless_runner(
    project_root: Path,
    permission_mode: "PermissionMode" = "plan",
) -> Callable[[str], bool]:
    """Return a callback that executes a task via headless Claude Code.

    The callback: loads .task.md → builds /start-task prompt → invokes
    HeadlessSession → emits telemetry → returns success/failure.

    Args:
        project_root: Path to the project root (contains .paircoder/).
        permission_mode: HeadlessSession permission mode. Use
            "bypassPermissions" for autonomous execution.
            Default "plan" requires approval for writes.

    Returns:
        Callable[[str], bool] suitable for SprintExecutor.task_runner.
    """
    tasks_dir = project_root / ".paircoder" / "tasks"

    def _run_task(task_id: str) -> bool:
        import typer

        task_path = tasks_dir / f"{task_id}.task.md"
        if not task_path.exists():
            typer.echo(f"Task {task_id} ERROR: task file not found: {task_path}")
            return False

        task_content = task_path.read_text()
        frontmatter, _ = parse_frontmatter(task_content)
        prompt = _build_task_prompt(task_id, task_content)

        typer.echo(f"Task {task_id} running with {permission_mode}")
        session = HeadlessSession(
            permission_mode=permission_mode,
            working_dir=project_root,
        )
        response = session.invoke(prompt)

        # Emit telemetry for every headless task
        _emit_task_telemetry(project_root, task_id, response, frontmatter)

        if response.is_error:
            typer.echo(f"Task {task_id} FAILED: {response.error_message}")
            return False

        typer.echo(f"Task {task_id} DONE")
        return True

    return _run_task


def _emit_task_telemetry(
    project_root: Path,
    task_id: str,
    response: HeadlessResponse,
    frontmatter: dict[str, Any],
) -> None:
    """Emit a telemetry record for a headless task invocation."""
    try:
        store = TelemetryStore(project_root)
        repo = project_root.name or "unknown"
        record = _build_telemetry_record(task_id, response, frontmatter, repo)
        store.append(record)
        logger.debug("Telemetry emitted for task %s", task_id)
    except Exception as e:
        logger.warning("Telemetry emission failed (non-blocking): %s", e)
