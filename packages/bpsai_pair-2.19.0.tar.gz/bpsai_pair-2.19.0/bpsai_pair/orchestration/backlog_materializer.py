"""Materialize parsed backlog into plan YAML and task markdown files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .backlog_parser import ParsedBacklog, ParsedTask


def materialize(
    project_root: Path, backlog: ParsedBacklog, sprint: str
) -> Path:
    """Write plan YAML and task .md files from a parsed backlog."""
    plans_dir = project_root / ".paircoder" / "plans"
    tasks_dir = project_root / ".paircoder" / "tasks"
    plans_dir.mkdir(parents=True, exist_ok=True)
    tasks_dir.mkdir(parents=True, exist_ok=True)

    plan_id = f"plan-sprint-{sprint}-engage"
    plan_data = {
        "id": plan_id,
        "title": f"Sprint {sprint}",
        "type": "feature",
        "status": "planned",
        "phases": _build_phases(backlog),
    }

    plan_path = plans_dir / f"{plan_id}.plan.yaml"
    with open(plan_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(plan_data, f, default_flow_style=False)

    for task in backlog.tasks:
        _write_task_file(tasks_dir, task, plan_id, sprint)

    return plan_path


def _build_phases(backlog: ParsedBacklog) -> list[dict[str, Any]]:
    """Group tasks into phase structures."""
    phases: dict[int, list[str]] = {}
    for task in backlog.tasks:
        phases.setdefault(task.phase, []).append(task.id)
    return [
        {"id": pid, "tasks": tids}
        for pid, tids in sorted(phases.items())
    ]


def _write_task_file(
    tasks_dir: Path, task: ParsedTask, plan_id: str, sprint: str
) -> None:
    """Write a single task .md file with frontmatter and AC."""
    task_id = task.id
    frontmatter = yaml.safe_dump({
        "id": task_id,
        "title": task.title,
        "plan": plan_id,
        "type": "feature",
        "priority": task.priority,
        "complexity": task.complexity,
        "status": "pending",
        "sprint": sprint,
        "depends_on": list(task.depends_on),
    }, default_flow_style=False, sort_keys=False).strip()

    body_lines = [f"# {task.title}", ""]
    if task.description:
        body_lines.extend([task.description, ""])
    body_lines.append("# Acceptance Criteria")
    body_lines.append("")
    for ac in task.ac_items:
        body_lines.append(f"- [ ] {ac}")
    body_lines.append("")

    content = f"---\n{frontmatter}\n---\n\n" + "\n".join(body_lines)
    (tasks_dir / f"{task_id}.task.md").write_text(content)
