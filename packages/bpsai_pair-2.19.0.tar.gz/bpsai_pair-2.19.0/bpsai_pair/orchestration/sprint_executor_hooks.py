"""Hooks for sprint executor — review dispatch and security detection.

These hooks are called after phase completion to trigger reviews
and flag security-relevant changes. Dispatches reviewer and
security-auditor agents via AgentInvoker with exception handling
and input sanitization.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path, PurePosixPath
from typing import Any, Optional

from .invoker import AgentInvoker

logger = logging.getLogger(__name__)

SECURITY_PATTERNS = [
    "/security/", "/auth/", "auth_", "_auth.",
    "credential", "secret_", "_secret", "/secrets/",
]

MAX_FILE_PATH_LENGTH = 500

# Characters that must never appear in file paths passed to agent prompts
_DANGEROUS_CHARS = re.compile(r"[\x00-\x1f]")


def sanitize_file_path(raw: str) -> Optional[str]:
    """Sanitize a file path for safe inclusion in agent prompts.

    Returns the cleaned path, or None if the path is unsafe.
    """
    # Strip dangerous control characters (null bytes, newlines, etc.)
    cleaned = _DANGEROUS_CHARS.sub("", raw)

    # Normalize backslashes to forward slashes
    cleaned = cleaned.replace("\\", "/")

    # Reject absolute paths
    if cleaned.startswith("/"):
        return None

    # Reject path traversal
    try:
        parts = PurePosixPath(cleaned).parts
    except (ValueError, TypeError):
        return None

    if ".." in parts:
        return None

    # Reject overly long paths
    if len(cleaned) > MAX_FILE_PATH_LENGTH:
        return None

    return cleaned if cleaned else None


def _build_review_prompt(changed_files: list[str]) -> str:
    """Build the review prompt from sanitized file paths."""
    files_list = "\n".join(f"- {f}" for f in changed_files)
    return (
        f"Review the following {len(changed_files)} changed files "
        f"for quality, correctness, and best practices:\n\n{files_list}"
    )


def _build_security_prompt(changed_files: list[str]) -> str:
    """Build the security audit prompt from sanitized file paths."""
    files_list = "\n".join(f"- {f}" for f in changed_files)
    return (
        f"Security audit the following {len(changed_files)} changed files "
        f"for vulnerabilities and compliance issues:\n\n{files_list}"
    )


def _invoke_agent_safe(
    invoker: AgentInvoker, agent_name: str, prompt: str,
) -> tuple[Optional[dict[str, Any]], Optional[str]]:
    """Invoke an agent, returning (result_dict, error_str).

    Never raises — all exceptions are captured and returned as error_str.
    """
    try:
        result = invoker.invoke(agent_name, prompt)
        return result.to_dict(), None
    except Exception as exc:
        logger.error("%s agent failed: %s", agent_name, exc)
        return None, str(exc)


def dispatch_review(
    project_root: Path, changed_files: list[str],
) -> dict[str, Any]:
    """Dispatch reviewer (and optionally security-auditor) after a phase.

    Sanitizes file paths, invokes agents via AgentInvoker, and wraps
    all invocations in exception handling so agent failures never crash
    the sprint executor.
    """
    safe_files = [
        c for raw in changed_files
        if (c := sanitize_file_path(raw)) is not None
    ]
    if not safe_files:
        return {"dispatched": False, "file_count": 0}

    security_relevant = detect_security_relevant(safe_files)
    metadata: dict[str, Any] = {
        "dispatched": True,
        "file_count": len(safe_files),
        "security_relevant": security_relevant,
        "reviewer_result": None,
        "reviewer_error": None,
        "security_error": None,
    }

    try:
        invoker = AgentInvoker(working_dir=project_root)
    except Exception as exc:
        logger.error("Failed to create AgentInvoker: %s", exc)
        metadata["reviewer_error"] = str(exc)
        return metadata

    # Reviewer
    res, err = _invoke_agent_safe(
        invoker, "reviewer", _build_review_prompt(safe_files),
    )
    metadata["reviewer_result"] = res
    metadata["reviewer_error"] = err

    # Security-auditor (only for security-relevant changes)
    if security_relevant:
        sec_res, sec_err = _invoke_agent_safe(
            invoker, "security-auditor", _build_security_prompt(safe_files),
        )
        metadata["security_result"] = sec_res
        metadata["security_error"] = sec_err

    return metadata


def detect_security_relevant(changed_files: list[str]) -> bool:
    """Check if any changed files are security-relevant."""
    for filepath in changed_files:
        lower = filepath.replace("\\", "/").lower()
        if any(pattern in lower for pattern in SECURITY_PATTERNS):
            return True
    return False
