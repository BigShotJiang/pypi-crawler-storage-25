"""Post-sprint review dispatch.

Detects changed source files after all plan tasks complete and
creates a review handoff JSON for the reviewer agent.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

# Files/dirs to exclude from review scope
_EXCLUDE_PATTERNS = {
    ".paircoder/",
    "MEMORY.md",
    ".task.md",
    "state.md",
    "compaction_meta",
}


@dataclass
class ReviewDispatch:
    """Result of a review dispatch attempt."""

    files: list[str] = field(default_factory=list)
    handoff_path: Path | None = None
    plan_id: str = ""


def should_dispatch_review(project_root: Path, plan_id: str) -> bool:
    """Check if all tasks in *plan_id* are done."""
    tasks_dir = project_root / ".paircoder" / "tasks"
    if not tasks_dir.exists():
        return False
    for path in tasks_dir.glob("*.task.md"):
        content = path.read_text(encoding="utf-8")
        if f"plan: {plan_id}\n" in content and "status: done" not in content:
            return False
    return True


def dispatch_review(project_root: Path, plan_id: str) -> ReviewDispatch:
    """Create review handoff with changed source files."""
    changed = _get_changed_files(project_root)
    source_files = [f for f in changed if not _is_excluded(f)]

    if not source_files:
        return ReviewDispatch(plan_id=plan_id)

    handoff = _create_review_handoff(project_root, plan_id, source_files)
    return ReviewDispatch(files=source_files, handoff_path=handoff, plan_id=plan_id)


def _get_changed_files(project_root: Path) -> list[str]:
    """Get files changed since branch diverged from dev."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "dev...HEAD"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=10,
        )
        return [f for f in result.stdout.strip().split("\n") if f]
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return []


def _is_excluded(filepath: str) -> bool:
    """Check if file should be excluded from review."""
    return any(pat in filepath for pat in _EXCLUDE_PATTERNS)


def _create_review_handoff(
    root: Path, plan_id: str, files: list[str]
) -> Path:
    """Write review handoff JSON."""
    handoffs_dir = root / ".paircoder" / "handoffs"
    handoffs_dir.mkdir(parents=True, exist_ok=True)
    handoff = {
        "type": "review",
        "plan_id": plan_id,
        "files": files,
        "file_count": len(files),
        "created_at": datetime.now().isoformat(),
    }
    path = handoffs_dir / f"review_{plan_id}.json"
    path.write_text(json.dumps(handoff, indent=2))
    return path
