"""Sprint summary generation from task completion data.

Builds summaries from TaskParser data for PR bodies and state.md updates.
"""
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from bpsai_pair.planning.task_parser import TaskParser


@dataclass
class SprintSummary:
    """Aggregated sprint summary data."""

    plan_id: str
    total_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0
    pending_tasks: int = 0
    total_complexity: int = 0
    completed_complexity: int = 0
    task_details: list[dict] = field(default_factory=list)


class SprintSummaryBuilder:
    """Builds sprint summaries from task files."""

    def __init__(self, project_root: Path, plan_id: str) -> None:
        self._project_root = Path(project_root)
        self._plan_id = plan_id
        self._tasks_dir = self._project_root / ".paircoder" / "tasks"
        self._summary: SprintSummary | None = None

    def build(self) -> SprintSummary:
        """Gather task data and build summary."""
        parser = TaskParser(self._tasks_dir)
        tasks = parser.parse_all()
        matched = [t for t in tasks if t.plan_id and self._plan_id in t.plan_id]

        summary = SprintSummary(plan_id=self._plan_id)
        for task in matched:
            detail = {
                "id": task.id,
                "title": task.title,
                "status": str(task.status.value)
                if hasattr(task.status, "value")
                else str(task.status),
                "complexity": task.complexity,
            }
            summary.task_details.append(detail)
            summary.total_tasks += 1
            summary.total_complexity += task.complexity

            status_val = detail["status"]
            if status_val == "done":
                summary.completed_tasks += 1
                summary.completed_complexity += task.complexity
            elif status_val in ("blocked", "cancelled"):
                summary.failed_tasks += 1
            else:
                summary.pending_tasks += 1

        self._summary = summary
        return summary

    def to_markdown(self) -> str:
        """Produce state.md 'What Was Just Done' format."""
        s = self._get_summary()
        today = date.today().isoformat()
        lines = [
            f"- **Sprint {s.plan_id} complete** ({today}): "
            f"{s.completed_tasks}/{s.total_tasks} tasks done, "
            f"{s.completed_complexity} cx delivered",
        ]
        for detail in s.task_details:
            marker = "done" if detail["status"] == "done" else detail["status"]
            lines.append(f"  - {detail['id']}: {detail['title']} [{marker}]")
        return "\n".join(lines) + "\n"

    def to_pr_body(self) -> str:
        """Produce PR-ready markdown with test plan section."""
        s = self._get_summary()
        lines = [
            "## Summary",
            f"- {s.completed_tasks} tasks completed ({s.completed_complexity} complexity points)",
            f"- {s.total_tasks} total tasks in sprint",
            "",
            "## Task Details",
            "| ID | Title | Status | Cx |",
            "|---|---|---|---|",
        ]
        for detail in s.task_details:
            lines.append(
                f"| {detail['id']} | {detail['title']} "
                f"| {detail['status']} | {detail['complexity']} |"
            )
        lines.extend(["", "## Test plan", "- [ ] All tests pass", ""])
        return "\n".join(lines)

    def _get_summary(self) -> SprintSummary:
        """Return cached summary or build one."""
        if self._summary is None:
            self.build()
        return self._summary  # type: ignore[return-value]
