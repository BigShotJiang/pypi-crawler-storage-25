"""Configuration presets for PairCoder initialization.

Provides pre-built configurations for different project types,
making it easy to bootstrap new projects with sensible defaults.

This module is the public API facade. Preset data lives in
preset_definitions.py and config builders in preset_config.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import yaml

from .config_defaults import CURRENT_CONFIG_VERSION
from .preset_config import (
    build_containment_section,
    build_default_trello_section,
    build_estimation_section,
    build_hooks_section,
    build_metrics_section,
    build_models_section,
    build_pm_section,
    build_routing_section,
    build_token_budget_section,
    build_token_estimates_section,
    convert_trello_config,
)


@dataclass
class Preset:
    """A configuration preset for a specific project type."""

    name: str
    description: str
    project_type: str

    # Project settings
    coverage_target: int = 80

    # Workflow settings
    default_branch_type: str = "feature"
    main_branch: str = "main"

    # Pack excludes (project-type specific)
    pack_excludes: List[str] = field(default_factory=list)

    # CI settings
    python_formatter: str = "ruff"
    node_formatter: str = "prettier"
    ci_type: str = "fullstack"  # "node", "python", or "fullstack"

    # Flow settings
    enabled_flows: List[str] = field(default_factory=lambda: [
        "design-plan-implement",
        "tdd-implement",
        "review",
        "finish-branch"
    ])

    # Model routing (optional complexity-based routing)
    model_routing: Optional[Dict[str, Any]] = None

    # Trello configuration (optional)
    trello_config: Optional[Dict[str, Any]] = None

    # Hooks configuration (optional)
    hooks_config: Optional[Dict[str, Any]] = None

    # Estimation configuration (optional)
    estimation_config: Optional[Dict[str, Any]] = None

    # Metrics configuration (optional)
    metrics_config: Optional[Dict[str, Any]] = None

    # Security configuration (optional)
    security_config: Optional[Dict[str, Any]] = None

    def to_config_dict(
        self, project_name: str, primary_goal: str, description: str = ""
    ) -> Dict[str, Any]:
        """Convert preset to a config dictionary (v2.9.3 format)."""
        config: Dict[str, Any] = {
            "version": CURRENT_CONFIG_VERSION,
            "project": {
                "name": project_name,
                "description": description or f"{project_name} project",
                "primary_goal": primary_goal,
                "coverage_target": self.coverage_target,
            },
            "workflow": {
                "default_branch_type": self.default_branch_type,
                "main_branch": self.main_branch,
                "context_dir": ".paircoder/context",
                "plans_dir": ".paircoder/plans",
                "tasks_dir": ".paircoder/tasks",
            },
            "pack": {
                "default_name": "agent_pack.tgz",
                "excludes": self.pack_excludes,
            },
        }
        config["models"] = build_models_section()
        config["routing"] = build_routing_section(self.model_routing)
        if self.trello_config:
            config["trello"] = convert_trello_config(self.trello_config)
        else:
            config["trello"] = build_default_trello_section(project_name)
        config["estimation"] = build_estimation_section(self.estimation_config)
        config["token_estimates"] = build_token_estimates_section()
        config["token_budget"] = build_token_budget_section()
        config["metrics"] = build_metrics_section(self.metrics_config)
        config["hooks"] = build_hooks_section(self.hooks_config)
        config["pm"] = build_pm_section()
        config["containment"] = build_containment_section()
        return config

    def to_yaml(
        self, project_name: str, primary_goal: str, description: str = ""
    ) -> str:
        """Convert preset to YAML string."""
        config = self.to_config_dict(project_name, primary_goal, description)
        return yaml.dump(config, default_flow_style=False, sort_keys=False)


class PresetManager:
    """Manager for configuration presets."""

    def __init__(self, custom_presets: Optional[Dict[str, Preset]] = None):
        """Initialize preset manager."""
        from .preset_definitions import PRESETS
        self.presets = dict(PRESETS)
        if custom_presets:
            self.presets.update(custom_presets)

    def get(self, name: str) -> Optional[Preset]:
        """Get preset by name."""
        return self.presets.get(name)

    def list(self) -> List[Preset]:
        """List all presets."""
        return list(self.presets.values())

    def names(self) -> List[str]:
        """Get all preset names."""
        return list(self.presets.keys())

    def add(self, preset: Preset) -> None:
        """Add a custom preset."""
        self.presets[preset.name] = preset

    def remove(self, name: str) -> bool:
        """Remove a preset."""
        if name in self.presets:
            del self.presets[name]
            return True
        return False

    def describe(self, name: str) -> Optional[str]:
        """Get a formatted description of a preset."""
        preset = self.get(name)
        if not preset:
            return None

        return f"""Preset: {preset.name}
Description: {preset.description}
Project Type: {preset.project_type}
Coverage Target: {preset.coverage_target}%
Branch Type: {preset.default_branch_type}
Flows: {', '.join(preset.enabled_flows)}
Pack Excludes: {len(preset.pack_excludes)} patterns"""


# Backward-compatible re-exports from preset_definitions.
# Uses __getattr__ to avoid circular imports (preset_definitions imports Preset).
def __getattr__(name: str):
    _re_exports = {
        "COMMON_EXCLUDES", "PRESETS",
        "get_preset", "list_presets", "get_preset_names",
    }
    if name in _re_exports:
        from . import preset_definitions
        return getattr(preset_definitions, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
