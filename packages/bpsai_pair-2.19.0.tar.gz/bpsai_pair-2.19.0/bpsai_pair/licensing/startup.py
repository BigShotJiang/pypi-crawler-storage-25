"""Startup license validation.

This module handles license validation during CLI startup:
- Validates license against API (with offline fallback)
- Caches result for session (avoids re-validation per command)
- Uses file-based cache to avoid redundant API calls across processes
- Supports --offline flag and PAIRCODER_OFFLINE env var
- Provides warning/error messages for display
- Detects and handles tier changes (upgrade/downgrade)
"""

import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from .core import clear_license_cache, load_license
from .online import (
    LicenseRevoked,
    NetworkError,
    OfflineValidationExpired,
    ValidationResult,
    is_online_validation_enabled,
    validate_with_fallback,
)
from .tier_change import (
    TierChangeResult,
    get_tier_change_message,
    handle_tier_change,
)

logger = logging.getLogger(__name__)

# Session-level cache to avoid re-validation per command
_session_validation_result: Optional[ValidationResult] = None
_session_tier_change_result: Optional[TierChangeResult] = None


def _get_paircoder_dir() -> Path:
    """Get the .paircoder directory path."""
    return Path.home() / ".paircoder"


def _get_telemetry_dir() -> Path:
    """Get the telemetry directory for file-based validation cache."""
    return _get_paircoder_dir() / "telemetry"


def is_offline_flag_set() -> bool:
    """Check if --offline flag is in command line args."""
    return "--offline" in sys.argv


def clear_session_cache() -> None:
    """Clear the session validation cache."""
    global _session_validation_result, _session_tier_change_result
    _session_validation_result = None
    _session_tier_change_result = None


def _create_error_result(message: str, from_cache: bool = False) -> ValidationResult:
    """Create a validation result for error cases."""
    return ValidationResult(
        valid=False,
        revoked=False,
        machine_activated=False,
        machines_used=0,
        machines_allowed=0,
        message=message,
        from_cache=from_cache,
    )


def _create_revoked_result(
    message: str, reason: str | None = None, revoked_at=None
) -> ValidationResult:
    """Create a validation result for revoked licenses."""
    return ValidationResult(
        valid=False,
        revoked=True,
        revoked_at=revoked_at,
        revoked_reason=reason,
        machine_activated=False,
        machines_used=0,
        machines_allowed=0,
        message=message,
        from_cache=True,
    )


# Number of days before expiration to start warning
EXPIRATION_WARNING_DAYS = 7


def _get_expiration_warning(expires_at: Optional[datetime]) -> Optional[str]:
    """Get warning message if license is expiring soon.

    Args:
        expires_at: License expiration datetime, or None for perpetual.

    Returns:
        Warning message if expiring within 7 days, None otherwise.
    """
    if expires_at is None:
        return None

    now = datetime.now(timezone.utc)
    days_remaining = (expires_at - now).days

    if days_remaining > EXPIRATION_WARNING_DAYS:
        return None

    if days_remaining <= 0:
        return "License has expired. Renew at https://paircoder.ai/pricing"
    elif days_remaining == 1:
        return "License expires tomorrow. Renew at https://paircoder.ai/pricing"
    else:
        return f"License expires in {days_remaining} days. Renew at https://paircoder.ai/pricing"


def _should_skip_validation() -> bool:
    """Check if validation should be skipped."""
    if not is_online_validation_enabled() or is_offline_flag_set():
        logger.debug("Skipping online validation (offline mode)")
        return True
    return False


def _get_license_info():
    """Get the license ID and tier from the installed license.

    Returns:
        Tuple of (license_id, tier) or (None, None) if no license.
    """
    try:
        signed_license = load_license()
    except Exception:
        signed_license = None

    if signed_license is None:
        logger.debug("Skipping online validation (no license)")
        return None, None

    return signed_license.payload.license_id, signed_license.payload.tier


def _cache_and_return(result: ValidationResult) -> ValidationResult:
    """Cache and return the validation result."""
    global _session_validation_result
    _session_validation_result = result
    return result


def _handle_tier_change_if_needed(
    license_id, local_tier: str, api_tier: str | None
) -> None:
    """Check for and handle tier changes.

    Args:
        license_id: The license UUID.
        local_tier: The tier from the local license file.
        api_tier: The tier from the API validation response.
    """
    global _session_tier_change_result

    change = handle_tier_change(license_id, local_tier, api_tier)
    _session_tier_change_result = change

    if change and change.changed and change.license_updated:
        # Clear license cache so the new license is loaded on next access
        clear_license_cache()
        logger.info(f"Tier changed from {change.previous_tier} to {change.new_tier}")


def _check_file_cache() -> Optional[ValidationResult]:
    """Check the file-based validation cache for a recent result.

    Returns:
        A ValidationResult with from_cache=True if cache is valid, None otherwise.
    """
    try:
        from .validation_cache import read_validation_cache

        telemetry_dir = _get_telemetry_dir()
        cached = read_validation_cache(telemetry_dir)
        if cached is not None:
            logger.debug("Using file-based validation cache")
            return ValidationResult(
                valid=cached["valid"],
                revoked=False,
                machine_activated=True,
                machines_used=0,
                machines_allowed=0,
                from_cache=True,
            )
    except Exception as e:
        logger.debug("File cache check failed: %s", e)
    return None


def _write_file_cache(result: ValidationResult) -> None:
    """Write validation result to the file-based cache (best-effort)."""
    try:
        from .validation_cache import write_validation_cache

        telemetry_dir = _get_telemetry_dir()
        write_validation_cache(telemetry_dir, valid=result.valid)
    except Exception as e:
        logger.debug("Failed to write file cache: %s", e)


def run_startup_validation(force: bool = False) -> Optional[ValidationResult]:
    """Run license validation on CLI startup.

    Args:
        force: If True, bypass file cache and always call API.
            Used at task-done boundaries for a fresh check.

    Returns:
        ValidationResult if validation was performed, None if skipped.
        The result is cached for the session.
    """
    global _session_validation_result

    if _session_validation_result is not None and not force:
        return _session_validation_result

    if _should_skip_validation():
        return None

    license_id, local_tier = _get_license_info()
    if license_id is None:
        return None

    # Check file-based cache (skip when force=True for task-done boundaries)
    if not force:
        file_cached = _check_file_cache()
        if file_cached is not None:
            return _cache_and_return(file_cached)

    try:
        result = validate_with_fallback(license_id)

        # Check for tier changes (only when online validation succeeded)
        if not result.from_cache and result.valid:
            _handle_tier_change_if_needed(license_id, local_tier, result.tier)

        # Write to file cache for subsequent CLI invocations
        _write_file_cache(result)

        return _cache_and_return(result)
    except LicenseRevoked as e:
        # Revoked licenses fail immediately - create result with revoked flag
        return _cache_and_return(_create_revoked_result(str(e), e.reason, e.revoked_at))
    except OfflineValidationExpired as e:
        return _cache_and_return(_create_error_result(str(e), from_cache=True))
    except NetworkError as e:
        logger.warning(f"Startup validation failed: {e}")
        return _cache_and_return(_create_error_result(str(e), from_cache=False))


def run_task_boundary_validation() -> None:
    """Run a fresh license validation at task lifecycle boundaries.

    Called by task done / ttask done commands. Forces a fresh API call
    (bypasses file cache) to ensure license is still valid when work
    is being completed. Non-blocking: errors are swallowed.
    """
    try:
        import sys

        result = run_startup_validation(force=True)
        if result is not None and result.revoked:
            reason = result.revoked_reason or "No reason provided"
            sys.stderr.write(f"License revoked: {reason}\n")
    except Exception as e:
        logger.debug("Task boundary validation failed: %s", e)


def get_validation_warning(result: ValidationResult) -> Optional[str]:
    """Get a warning message for the validation result.

    Args:
        result: The validation result to check.

    Returns:
        Warning message string, or None if no warning needed.
    """
    if result.revoked:
        reason = result.revoked_reason or "No reason provided"
        return f"License revoked: {reason}"

    if not result.valid:
        return result.message or "License validation failed"

    if result.from_cache:
        return "Using cached license validation (offline mode)"

    if not result.machine_activated:
        if result.machines_used >= (result.machines_allowed or 0):
            return "Machine not activated. No slots available."
        return "Machine not activated on this license."

    # Check for approaching expiration (7 days warning)
    expiration_warning = _get_expiration_warning(result.expires_at)
    if expiration_warning:
        return expiration_warning

    return None


def get_tier_change_warning(change: Optional[TierChangeResult]) -> Optional[str]:
    """Get a warning message for a tier change.

    Args:
        change: The tier change result, or None if no change.

    Returns:
        Warning message string, or None if no change.
    """
    if change is None or not change.changed:
        return None

    return get_tier_change_message(change)


def get_session_tier_change() -> Optional[TierChangeResult]:
    """Get the tier change result from the current session.

    Returns:
        TierChangeResult if a tier change was detected, None otherwise.
    """
    return _session_tier_change_result
