"""HTTP client for support ticket operations.

Wraps the bpsai-support ticket endpoints with JWT authentication.
Auth is handled by paircoder_api (see auth.py); ticket CRUD goes
to bpsai-support.
"""

from __future__ import annotations

import json
import os
from typing import Optional

import httpx

DEFAULT_SUPPORT_URL = os.environ.get(
    "PAIRCODER_SUPPORT_URL",
    "https://app-bpsaisupport-cus-prod-api.azurewebsites.net",
)
DEFAULT_TIMEOUT = 10


class SupportClient:
    """Authenticated client for support ticket API (bpsai-support)."""

    def __init__(self, jwt_token: str, support_url: str = DEFAULT_SUPPORT_URL):
        self._jwt = jwt_token
        self._base = support_url.rstrip("/")

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self._jwt}",
            "app-id": "paircoder-cus",
        }

    def create_ticket(
        self,
        title: str,
        ticket_type: str,
        description: str = "",
        system_info: Optional[dict] = None,
    ) -> Optional[dict]:
        """Create a support ticket. Returns ticket dict or None on failure."""
        url = f"{self._base}/api/v1/tickets"
        fields: dict = {
            "title": title,
            "ticket_type": ticket_type,
            "description": description,
        }
        if system_info:
            fields["ticket_metadata"] = json.dumps(system_info)
        try:
            with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
                resp = client.post(url, files=[(k, (None, v)) for k, v in fields.items()], headers=self._headers())
                if resp.status_code in (200, 201):
                    return resp.json()
                return None
        except httpx.RequestError:
            return None

    def list_tickets(self, status: Optional[str] = None) -> Optional[list]:
        """List support tickets. Returns list or None on failure."""
        url = f"{self._base}/api/v1/tickets"
        params = {}
        if status:
            params["status"] = status
        try:
            with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
                resp = client.get(url, params=params, headers=self._headers())
                if resp.status_code == 200:
                    return resp.json()
                return None
        except httpx.RequestError:
            return None

    def get_ticket(self, ticket_id: str) -> Optional[dict]:
        """Get a single ticket by ID. Returns ticket dict or None."""
        url = f"{self._base}/api/v1/tickets/{ticket_id}"
        try:
            with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
                resp = client.get(url, headers=self._headers())
                if resp.status_code == 200:
                    return resp.json()
                return None
        except httpx.RequestError:
            return None
