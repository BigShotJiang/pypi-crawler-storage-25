#!/bin/bash
set -euo pipefail
DIR=$(dirname "$(readlink -f "$0")")
cd "$DIR"

echo "=== Cleaning previous builds ==="
rm -rf dist/ build/ src/*.egg-info src/casher/*.egg-info

echo "=== Building package ==="
uv run python -m build

echo "=== Uploading to PyPI ==="
uv run python -m twine upload dist/*

echo "=== Cleaning build artifacts ==="
rm -rf dist/ build/ src/*.egg-info src/casher/*.egg-info

echo "=== Done ==="
