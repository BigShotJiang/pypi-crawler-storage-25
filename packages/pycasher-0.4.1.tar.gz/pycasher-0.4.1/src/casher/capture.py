import shutil
import sys
from pathlib import Path

from casher.config import OUTPUT_FILES_DIR
from casher.store import CacheEntry


def replay_side_effects(entry: CacheEntry, entry_dir: Path) -> None:
    """Replay cached side effects:
    - print stdout to sys.stdout
    - print stderr to sys.stderr
    - restore output files from cache to their original paths
    """
    if entry.stdout:
        sys.stdout.write(entry.stdout)

    if entry.stderr:
        sys.stderr.write(entry.stderr)

    output_dir = entry_dir / OUTPUT_FILES_DIR
    for rel_path in entry.output_files:
        safe_path = rel_path.lstrip("/")
        cached_path = output_dir / safe_path
        if not cached_path.exists():
            continue
        target = Path(rel_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(cached_path), str(target))
