import os
import shutil
from pathlib import Path

from loguru import logger

from casher.config import (
    META_FILENAME,
    resolve_start_removing_pct,
    resolve_stop_caching_pct,
)


def get_disk_usage_pct(cache_dir: Path) -> float:
    """Return disk usage percentage (0–100) for the filesystem containing cache_dir."""
    usage = shutil.disk_usage(cache_dir)
    return (usage.used / usage.total) * 100


def is_disk_full(cache_dir: Path) -> bool:
    """Return True if disk usage >= stop_caching threshold."""
    pct = get_disk_usage_pct(cache_dir)
    stop_pct = resolve_stop_caching_pct()
    if pct >= stop_pct:
        logger.warning(
            "Disk {}% full (threshold {}%) — skipping cache write on {}",
            f"{pct:.1f}",
            stop_pct,
            cache_dir,
        )
        return True
    return False


def evict_for_disk_pressure(cache_dir: Path) -> int:
    """Evict oldest entries until disk usage drops below stop_caching threshold.
    Only triggers when usage >= start_removing threshold.
    Returns number of entries evicted."""
    start_pct = resolve_start_removing_pct()
    stop_pct = resolve_stop_caching_pct()

    pct = get_disk_usage_pct(cache_dir)
    if pct < start_pct:
        return 0

    logger.warning(
        "Disk {}% full (remove-threshold {}%) — evicting cache entries to reach {}%",
        f"{pct:.1f}",
        start_pct,
        stop_pct,
    )

    entries = _collect_entries(cache_dir)
    entries.sort(key=lambda e: e[2])  # oldest first

    evicted = 0
    for entry_dir, entry_size, _ in entries:
        pct = get_disk_usage_pct(cache_dir)
        if pct < stop_pct:
            break
        shutil.rmtree(entry_dir)
        evicted += 1

        parent = entry_dir.parent
        if parent.is_dir() and not any(parent.iterdir()):
            parent.rmdir()

    if evicted:
        final_pct = get_disk_usage_pct(cache_dir)
        logger.warning(
            "Disk-pressure eviction: removed {} entries, disk now {}% full",
            evicted,
            f"{final_pct:.1f}",
        )

    return evicted


def evict_if_needed(cache_dir: Path, max_bytes: int) -> int:
    """Evict oldest entries until total size <= max_bytes.
    Returns number of entries evicted. Does nothing if max_bytes <= 0."""
    if max_bytes <= 0:
        return 0

    entries = _collect_entries(cache_dir)
    total_size = sum(size for _, size, _ in entries)

    if total_size <= max_bytes:
        return 0

    # Sort by mtime ascending (oldest first)
    entries.sort(key=lambda e: e[2])

    evicted = 0
    for entry_dir, entry_size, _ in entries:
        if total_size <= max_bytes:
            break
        shutil.rmtree(entry_dir)
        total_size -= entry_size
        evicted += 1

        # Clean up empty parent directory
        parent = entry_dir.parent
        if parent.is_dir() and not any(parent.iterdir()):
            parent.rmdir()

    if evicted:
        logger.info(
            "LRU eviction: removed {} entries, cache now {} bytes",
            evicted,
            total_size,
        )

    return evicted


def get_cache_size(cache_dir: Path) -> int:
    """Return total size of all cache entries in bytes."""
    entries = _collect_entries(cache_dir)
    return sum(size for _, size, _ in entries)


def get_entry_size(entry_dir: Path) -> int:
    """Return total size of a single cache entry directory in bytes."""
    total = 0
    for dirpath, _, filenames in os.walk(entry_dir):
        for f in filenames:
            total += os.path.getsize(os.path.join(dirpath, f))
    return total


def _collect_entries(cache_dir: Path) -> list[tuple[Path, int, float]]:
    """Walk cache dir and collect (entry_dir, size_bytes, mtime) tuples."""
    entries: list[tuple[Path, int, float]] = []
    if not cache_dir.is_dir():
        return entries

    for partial_dir in cache_dir.iterdir():
        if not partial_dir.is_dir() or partial_dir.name.startswith("."):
            continue
        for entry_dir in partial_dir.iterdir():
            if not entry_dir.is_dir():
                continue
            meta_path = entry_dir / META_FILENAME
            if not meta_path.exists():
                continue
            size = get_entry_size(entry_dir)
            mtime = meta_path.stat().st_mtime
            entries.append((entry_dir, size, mtime))

    return entries
