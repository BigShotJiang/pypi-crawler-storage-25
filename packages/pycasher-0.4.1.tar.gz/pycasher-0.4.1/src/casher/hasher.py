import hashlib
import os
from pathlib import Path

from casher.config import HASH_ALGORITHM


def compute_partial_key(
    func_module: str,
    func_name: str,
    dep_hash: str,
    args_hash: str,
    env_vars: list[str],
) -> str:
    """Key from everything known before execution."""
    h = hashlib.new(HASH_ALGORITHM)
    h.update(f"{func_module}:{func_name}".encode())
    h.update(dep_hash.encode())
    h.update(args_hash.encode())
    sorted_env = sorted(env_vars)
    for var in sorted_env:
        val = os.environ.get(var, "")
        h.update(f"{var}={val}".encode())
    return h.hexdigest()


def compute_file_hash(file_paths: list[Path]) -> str:
    """Hash the contents of a sorted list of file paths."""
    h = hashlib.new(HASH_ALGORITHM)
    for path in sorted(file_paths):
        file_h = hashlib.new(HASH_ALGORITHM)
        file_h.update(path.read_bytes())
        h.update(f"{path}:{file_h.hexdigest()}".encode())
    return h.hexdigest()


def compute_full_key(partial_key: str, file_hash: str) -> str:
    """Combine partial key with file content hash."""
    h = hashlib.new(HASH_ALGORITHM)
    h.update(partial_key.encode())
    h.update(file_hash.encode())
    return h.hexdigest()
