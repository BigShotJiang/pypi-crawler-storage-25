import argparse
import hashlib
import shutil
import sys
import time
from pathlib import Path

from loguru import logger

from casher.config import (
    HASH_ALGORITHM,
    OUTPUT_FILES_DIR,
    TMP_SUBDIR,
    resolve_cache_dir,
    resolve_max_cache_bytes,
)
from casher.hasher import compute_file_hash
from casher.store import CacheEntry, find_cached, store_result
from casher.strace import is_strace_available, run_with_strace


def _compute_command_partial_key(cmd: list[str]) -> str:
    h = hashlib.new(HASH_ALGORITHM)
    h.update(" ".join(cmd).encode())
    return h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Cache results of arbitrary CLI programs using strace.",
        usage="acache [--cache-dir DIR] [--max-cache-bytes N] -- command...",
    )
    parser.add_argument("--cache-dir", type=Path, default=None)
    parser.add_argument("--max-cache-bytes", type=int, default=None)

    # Split on -- to separate acache args from the command
    argv = sys.argv[1:]
    if "--" in argv:
        split_idx = argv.index("--")
        acache_args = argv[:split_idx]
        cmd = argv[split_idx + 1 :]
    else:
        acache_args = []
        cmd = argv

    if not cmd:
        raise SystemExit("No command provided. Usage: acache [options] -- command...")

    args = parser.parse_args(acache_args)
    cache_dir = resolve_cache_dir(args.cache_dir)
    max_bytes = resolve_max_cache_bytes(args.max_cache_bytes)

    logger.info("acache: cmd={} | cache_dir={}", " ".join(cmd), cache_dir)

    if not is_strace_available():
        raise SystemExit(
            "strace is required for acache. "
            "Install it (e.g., 'sudo pacman -S strace') or use the Python decorator API."
        )

    partial_key = _compute_command_partial_key(cmd)

    # Phase 1: cache lookup
    cached_result = find_cached(cache_dir, partial_key)
    if cached_result is not None:
        entry, entry_dir = cached_result
        logger.info("acache cache HIT: key={}…", partial_key[:12])

        # Replay stdout/stderr
        if entry.stdout:
            sys.stdout.write(entry.stdout)
        if entry.stderr:
            sys.stderr.write(entry.stderr)

        # Restore output files
        output_dir = entry_dir / OUTPUT_FILES_DIR
        for rel_path in entry.output_files:
            safe_path = rel_path.lstrip("/")
            cached_path = output_dir / safe_path
            if not cached_path.exists():
                continue
            target = Path(rel_path)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(cached_path), str(target))

        sys.exit(int(entry.return_value))

    # Phase 2: trace and store
    logger.info("acache cache MISS: key={}… | tracing with strace", partial_key[:12])
    tmp_root = cache_dir / TMP_SUBDIR
    tmp_root.mkdir(parents=True, exist_ok=True)
    strace_result = run_with_strace(cmd, tmp_dir=tmp_root)

    # Classify files
    read_files = [p for p in strace_result.read_files if p.is_file()]
    write_files = [p for p in strace_result.write_files if p.is_file()]

    # Compute file hash from read files
    if read_files:
        file_hash = compute_file_hash(read_files)
    else:
        file_hash = "none"

    # Build input_files dict
    input_files_dict: dict[str, str] = {}
    for p in read_files:
        input_files_dict[str(p)] = compute_file_hash([p])

    # Build output_files dict
    output_files_dict: dict[str, Path] = {}
    for p in write_files:
        output_files_dict[str(p)] = p

    entry = CacheEntry(
        return_value=strace_result.returncode,
        stdout=strace_result.stdout,
        stderr=strace_result.stderr,
        output_files=output_files_dict,
        input_files=input_files_dict,
        created_at=time.time(),
        func_module="acache",
        func_name=" ".join(cmd),
    )

    store_result(cache_dir, partial_key, file_hash, entry, max_bytes=max_bytes)

    # Output stdout/stderr
    if strace_result.stdout:
        sys.stdout.write(strace_result.stdout)
    if strace_result.stderr:
        sys.stderr.write(strace_result.stderr)

    sys.exit(strace_result.returncode)


if __name__ == "__main__":
    main()
