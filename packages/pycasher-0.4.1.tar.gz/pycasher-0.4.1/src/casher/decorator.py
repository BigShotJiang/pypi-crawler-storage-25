import contextlib
import fnmatch
import functools
import hashlib
import io
import json
import os
import pickle
import shutil
import sys
import tempfile
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from loguru import logger

from casher import capture, strace
from casher.audit_hook import track_file_io
from casher.config import (
    HASH_ALGORITHM,
    PLATFORM_SUPPORTED,
    TMP_SUBDIR,
    resolve_cache_dir,
    resolve_max_cache_bytes,
)
from casher.deps import compute_dep_hash
from casher.hasher import compute_file_hash, compute_partial_key
from casher.serializer import hash_value
from casher.store import CacheEntry, find_cached, store_result

_PLATFORM_WARNING_LOGGED = False


def cached(
    _fn: Callable | None = None,
    *,
    cache_dir: Path | str | None = None,
    env_vars: list[str] | None = None,
    dep_roots: list[str | Path] | None = None,
    max_cache_bytes: int | None = None,
    enabled: bool = True,
    subprocess: bool = True,
    input_files: list[str | Path] | Callable[..., list[Path]] | None = None,
    output_files: list[str | Path] | Callable[..., list[Path]] | None = None,
    ignore_files: list[str] | None = None,
) -> Callable:
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if not enabled:
                return fn(*args, **kwargs)

            if not PLATFORM_SUPPORTED:
                global _PLATFORM_WARNING_LOGGED
                if not _PLATFORM_WARNING_LOGGED:
                    logger.warning(
                        "casher: caching disabled on {} (only Linux is supported)",
                        sys.platform,
                    )
                    _PLATFORM_WARNING_LOGGED = True
                return fn(*args, **kwargs)

            resolved_cache_dir = resolve_cache_dir(cache_dir)
            resolved_max_bytes = resolve_max_cache_bytes(max_cache_bytes)
            resolved_dep_roots = [Path(r) for r in dep_roots] if dep_roots else None
            mode = "subprocess" if subprocess else "in-process"

            logger.info(
                "casher call: {}.{}() | mode={} | cache_dir={}",
                fn.__module__,
                fn.__qualname__,
                mode,
                resolved_cache_dir,
            )

            # Compute cache key components
            dep_hash = compute_dep_hash(fn, resolved_dep_roots)

            args_hash = _compute_args_hash(args, kwargs)

            partial_key = compute_partial_key(
                func_module=fn.__module__,
                func_name=fn.__qualname__,
                dep_hash=dep_hash,
                args_hash=args_hash,
                env_vars=env_vars or [],
            )

            # Phase 1: cache lookup
            cached_result = find_cached(resolved_cache_dir, partial_key)
            if cached_result is not None:
                entry, entry_dir = cached_result
                logger.info(
                    "cache HIT: {}.{}() | key={}…",
                    fn.__module__,
                    fn.__qualname__,
                    partial_key[:12],
                )
                capture.replay_side_effects(entry, entry_dir)
                return entry.return_value

            logger.info(
                "cache MISS: {}.{}() | key={}… | executing {}",
                fn.__module__,
                fn.__qualname__,
                partial_key[:12],
                mode,
            )

            # Phase 2: execute and store
            if subprocess:
                return _execute_subprocess(
                    fn,
                    args,
                    kwargs,
                    resolved_cache_dir,
                    partial_key,
                    resolved_max_bytes,
                    input_files,
                    output_files,
                    ignore_files,
                    env_vars,
                )
            else:
                return _execute_inprocess(
                    fn,
                    args,
                    kwargs,
                    resolved_cache_dir,
                    partial_key,
                    resolved_max_bytes,
                    input_files,
                    output_files,
                    ignore_files,
                    env_vars,
                )

        return wrapper

    if _fn is not None:
        return decorator(_fn)
    return decorator


def _compute_args_hash(args: tuple, kwargs: dict) -> str:
    h = hashlib.new(HASH_ALGORITHM)
    for arg in args:
        h.update(hash_value(arg))
    for key in sorted(kwargs.keys()):
        h.update(key.encode())
        h.update(hash_value(kwargs[key]))
    return h.hexdigest()


def _resolve_file_list(
    spec: list[str | Path] | Callable[..., list[Path]] | None,
    args: tuple,
    kwargs: dict,
) -> list[Path]:
    if spec is None:
        return []
    if callable(spec):
        return [Path(p) for p in spec(*args, **kwargs)]
    return [Path(p) for p in spec]


_NOISE_PREFIXES = (
    "/dev/",
    "/proc/",
    "/sys/",
    "/usr/lib/",
    "/lib/",
    "/usr/local/lib/",
    "/usr/share/",
    "/etc/",
)
_NOISE_SUFFIXES = (".pyc", ".pyo", ".so", ".dll", ".pth")
_NOISE_CONTAINS = ("__pycache__", "site-packages", "/python3.")


def _is_noise(path: Path, cache_dir_resolved: Path) -> bool:
    s = str(path)
    if any(s.startswith(p) for p in _NOISE_PREFIXES):
        return True
    if any(s.endswith(p) for p in _NOISE_SUFFIXES):
        return True
    if any(c in s for c in _NOISE_CONTAINS):
        return True
    try:
        path.resolve().relative_to(cache_dir_resolved)
        return True
    except ValueError:
        pass
    return False


def _filter_ignored(paths: list[Path], ignore_patterns: list[str] | None) -> list[Path]:
    if not ignore_patterns:
        return paths
    result = []
    for p in paths:
        p_str = str(p)
        if not any(
            fnmatch.fnmatch(p_str, pat) or fnmatch.fnmatch(p.name, pat)
            for pat in ignore_patterns
        ):
            result.append(p)
    return result


def _execute_inprocess(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    cache_dir: Path,
    partial_key: str,
    max_bytes: int,
    input_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    output_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    ignore_files: list[str] | None,
    env_vars: list[str] | None,
) -> Any:
    explicit_input = _resolve_file_list(input_files_spec, args, kwargs)
    explicit_output = _resolve_file_list(output_files_spec, args, kwargs)

    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()

    with (
        contextlib.redirect_stdout(stdout_buf),
        contextlib.redirect_stderr(stderr_buf),
        track_file_io() as tracker,
    ):
        result = fn(*args, **kwargs)

    # Merge auto-discovered files with explicit files
    discovered_read = tracker.read_files
    discovered_write = tracker.write_files

    # Filter out cache dir files and common noise from auto-discovered files
    resolved_cache = cache_dir.resolve()
    discovered_read = [p for p in discovered_read if not _is_noise(p, resolved_cache)]
    discovered_write = [p for p in discovered_write if not _is_noise(p, resolved_cache)]

    all_read = list(dict.fromkeys(explicit_input + discovered_read))
    all_write = list(dict.fromkeys(explicit_output + discovered_write))

    # Filter ignored patterns
    all_read = _filter_ignored(all_read, ignore_files)
    all_write = _filter_ignored(all_write, ignore_files)

    # Only keep files that actually exist for hashing
    existing_read = [p for p in all_read if p.exists()]

    # Compute file hash from read files
    if existing_read:
        file_hash = compute_file_hash(existing_read)
    else:
        file_hash = "none"

    # Build input_files dict: path → content hash
    input_files_dict: dict[str, str] = {}
    for p in existing_read:
        input_files_dict[str(p)] = compute_file_hash([p])

    # Build output_files dict: relative_path → actual path
    output_files_dict: dict[str, Path] = {}
    existing_write = [p for p in all_write if p.exists()]
    for p in existing_write:
        output_files_dict[str(p)] = p

    entry = CacheEntry(
        return_value=result,
        stdout=stdout_buf.getvalue(),
        stderr=stderr_buf.getvalue(),
        output_files=output_files_dict,
        input_files=input_files_dict,
        created_at=time.time(),
        func_module=fn.__module__,
        func_name=fn.__qualname__,
    )

    store_result(cache_dir, partial_key, file_hash, entry, max_bytes=max_bytes)

    # Print captured stdout/stderr to real streams (they were redirected during execution)
    if entry.stdout:
        sys.stdout.write(entry.stdout)
    if entry.stderr:
        sys.stderr.write(entry.stderr)

    return result


def _execute_subprocess(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    cache_dir: Path,
    partial_key: str,
    max_bytes: int,
    input_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    output_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    ignore_files: list[str] | None,
    env_vars: list[str] | None,
) -> Any:
    explicit_input = _resolve_file_list(input_files_spec, args, kwargs)
    explicit_output = _resolve_file_list(output_files_spec, args, kwargs)

    tmp_root = cache_dir / TMP_SUBDIR
    tmp_root.mkdir(parents=True, exist_ok=True)
    work_dir = Path(tempfile.mkdtemp(prefix="casher-", dir=tmp_root))
    try:
        # Write args for the runner
        with open(work_dir / "args.pkl", "wb") as f:
            pickle.dump(
                {
                    "module": fn.__module__,
                    "function": fn.__qualname__,
                    "args": args,
                    "kwargs": kwargs,
                },
                f,
            )

        # Run under strace — ensure subprocess can find the same modules
        cmd = [sys.executable, "-m", "casher._runner", str(work_dir)]
        env = os.environ.copy()
        # Propagate parent sys.path via PYTHONPATH so the runner can import
        # the decorated function's module
        env["PYTHONPATH"] = os.pathsep.join(sys.path)
        # Prevent .pyc generation — the runner is one-shot, and stale .pyc
        # files can cause the subprocess to use outdated bytecode
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        strace_result = strace.run_with_strace(cmd, tmp_dir=tmp_root, env=env)

        # Read status
        status_path = work_dir / "status.json"
        assert status_path.exists(), (
            f"Runner did not write status.json. returncode={strace_result.returncode}, "
            f"stderr={strace_result.stderr[:500]}"
        )
        status = json.loads(status_path.read_text())

        if not status["success"]:
            exc_path = work_dir / "exception.pkl"
            assert exc_path.exists(), "Runner failed but did not write exception.pkl"
            with open(exc_path, "rb") as f:
                exc = pickle.load(f)  # noqa: S301
            raise exc

        # Read result
        result_path = work_dir / "result.pkl"
        assert result_path.exists(), "Runner succeeded but did not write result.pkl"
        with open(result_path, "rb") as f:
            result = pickle.load(f)  # noqa: S301

        # Get files from strace, filter noise
        resolved_cache = cache_dir.resolve()
        work_dir_resolved = work_dir.resolve()

        def _is_work_dir(p: Path) -> bool:
            try:
                p.resolve().relative_to(work_dir_resolved)
                return True
            except ValueError:
                return False

        discovered_read = [
            p
            for p in strace_result.read_files
            if not _is_noise(p, resolved_cache) and not _is_work_dir(p) and p.is_file()
        ]
        discovered_write = [
            p
            for p in strace_result.write_files
            if not _is_noise(p, resolved_cache) and not _is_work_dir(p) and p.is_file()
        ]

        # Merge with explicit files
        all_read = list(dict.fromkeys(explicit_input + discovered_read))
        all_write = list(dict.fromkeys(explicit_output + discovered_write))

        # Filter ignored patterns
        all_read = _filter_ignored(all_read, ignore_files)
        all_write = _filter_ignored(all_write, ignore_files)

        # Only keep files that actually exist
        existing_read = [p for p in all_read if p.exists()]

        # Compute file hash from read files
        if existing_read:
            file_hash = compute_file_hash(existing_read)
        else:
            file_hash = "none"

        # Build input_files dict
        input_files_dict: dict[str, str] = {}
        for p in existing_read:
            input_files_dict[str(p)] = compute_file_hash([p])

        # Build output_files dict
        output_files_dict: dict[str, Path] = {}
        existing_write = [p for p in all_write if p.exists()]
        for p in existing_write:
            output_files_dict[str(p)] = p

        entry = CacheEntry(
            return_value=result,
            stdout=strace_result.stdout,
            stderr=strace_result.stderr,
            output_files=output_files_dict,
            input_files=input_files_dict,
            created_at=time.time(),
            func_module=fn.__module__,
            func_name=fn.__qualname__,
        )

        store_result(cache_dir, partial_key, file_hash, entry, max_bytes=max_bytes)

        # Print stdout/stderr from subprocess
        if entry.stdout:
            sys.stdout.write(entry.stdout)
        if entry.stderr:
            sys.stderr.write(entry.stderr)

        return result
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)
