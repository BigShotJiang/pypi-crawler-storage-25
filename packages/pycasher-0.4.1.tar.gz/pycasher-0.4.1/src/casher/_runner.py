"""Subprocess entry point for casher.

Invoked as: python -m casher._runner <work_dir>

Protocol:
  - Reads args.pkl from work_dir (dict with module, function, args, kwargs)
  - Imports the module, gets the function (unwraps @cached if needed)
  - Executes the function
  - Writes result.pkl, status.json, and exception.pkl (on failure) to work_dir
"""

import importlib
import json
import pickle
import sys
from pathlib import Path


def _unwrap_cached(fn):
    """If fn is wrapped by @cached, return the raw function."""
    return getattr(fn, "__wrapped__", fn)


def _resolve_function(module_name: str, qualname: str):
    """Import module and resolve the function by qualname."""
    mod = importlib.import_module(module_name)
    obj = mod
    for attr in qualname.split("."):
        obj = getattr(obj, attr)
    return _unwrap_cached(obj)


def run(work_dir: Path) -> None:
    work_dir = Path(work_dir)

    # Read args
    with open(work_dir / "args.pkl", "rb") as f:
        payload = pickle.load(f)  # noqa: S301

    module_name = payload["module"]
    func_name = payload["function"]
    args = payload["args"]
    kwargs = payload["kwargs"]

    try:
        fn = _resolve_function(module_name, func_name)
        result = fn(*args, **kwargs)

        # Serialize result
        with open(work_dir / "result.pkl", "wb") as f:
            pickle.dump(result, f)

        (work_dir / "status.json").write_text(json.dumps({"success": True}))

    except Exception as exc:
        (work_dir / "status.json").write_text(json.dumps({"success": False}))
        try:
            with open(work_dir / "exception.pkl", "wb") as f:
                pickle.dump(exc, f)
        except Exception:
            # Fallback for unpicklable exceptions
            with open(work_dir / "exception.pkl", "wb") as f:
                pickle.dump(RuntimeError(repr(exc)), f)


if __name__ == "__main__":
    assert (
        len(sys.argv) == 2
    ), f"Usage: python -m casher._runner <work_dir>, got {sys.argv}"
    run(Path(sys.argv[1]))
