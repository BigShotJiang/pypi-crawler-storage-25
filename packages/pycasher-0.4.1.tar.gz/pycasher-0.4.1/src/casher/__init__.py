# casher — Python function result caching with side-effect capture

from casher.config import configure, get_config
from casher.decorator import cached

__all__ = ["cached", "configure", "get_config"]
