import contextvars
import sys
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path


_active_tracker: contextvars.ContextVar["FileIOTracker | None"] = (
    contextvars.ContextVar("casher_file_tracker", default=None)
)
_hook_installed = False

_READ_MODES = {"r", "rb", "rt"}
_WRITE_MODES = {"w", "wb", "wt", "a", "ab", "at", "x", "xb", "xt"}


class FileIOTracker:
    def __init__(self) -> None:
        self.read_files: list[Path] = []
        self.write_files: list[Path] = []
        self._seen_read: set[str] = set()
        self._seen_write: set[str] = set()

    def record(self, path: str, mode: str) -> None:
        if mode in _WRITE_MODES:
            if path not in self._seen_write:
                self._seen_write.add(path)
                self.write_files.append(Path(path))
        elif mode in _READ_MODES:
            if path not in self._seen_read:
                self._seen_read.add(path)
                self.read_files.append(Path(path))


def _audit_hook(event: str, args: tuple) -> None:
    if event != "open":
        return
    tracker = _active_tracker.get()
    if tracker is None:
        return
    # args for "open" event: (path, mode, flags)
    path = args[0]
    mode = args[1]
    if not isinstance(path, str) or not isinstance(mode, str):
        return
    tracker.record(path, mode)


def _ensure_hook_installed() -> None:
    global _hook_installed
    if _hook_installed:
        return
    sys.addaudithook(_audit_hook)
    _hook_installed = True


@contextmanager
def track_file_io() -> Generator[FileIOTracker, None, None]:
    _ensure_hook_installed()
    tracker = FileIOTracker()
    token = _active_tracker.set(tracker)
    try:
        yield tracker
    finally:
        _active_tracker.reset(token)
