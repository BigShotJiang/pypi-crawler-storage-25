import hashlib
import io
import pickle
from pathlib import Path
from typing import Any

from casher.config import HASH_ALGORITHM


def _is_polars_dataframe(val: Any) -> bool:
    return (
        type(val).__module__.startswith("polars") and type(val).__name__ == "DataFrame"
    )


def _is_polars_lazyframe(val: Any) -> bool:
    return (
        type(val).__module__.startswith("polars") and type(val).__name__ == "LazyFrame"
    )


def _is_pandas_dataframe(val: Any) -> bool:
    return (
        type(val).__module__.startswith("pandas") and type(val).__name__ == "DataFrame"
    )


def hash_value(val: Any) -> bytes:
    """Compute a deterministic hash of a value for cache key purposes."""
    h = hashlib.new(HASH_ALGORITHM)
    _hash_into(h, val)
    return h.digest()


def _hash_into(h: "hashlib._Hash", val: Any) -> None:
    if val is None or isinstance(val, (int, float, str, bool)):
        h.update(repr(val).encode())
    elif isinstance(val, bytes):
        h.update(val)
    elif isinstance(val, (list, tuple)):
        h.update(type(val).__name__.encode())
        for item in val:
            _hash_into(h, item)
    elif isinstance(val, dict):
        h.update(b"dict")
        for key in sorted(val.keys(), key=repr):
            _hash_into(h, key)
            _hash_into(h, val[key])
    elif isinstance(val, (set, frozenset)):
        h.update(type(val).__name__.encode())
        for item in sorted(val, key=repr):
            _hash_into(h, item)
    elif isinstance(val, Path):
        if val.is_file():
            h.update(val.read_bytes())
        else:
            h.update(repr(val).encode())
    elif _is_polars_lazyframe(val):
        buf = io.BytesIO()
        val.collect().write_ipc(buf)
        h.update(buf.getvalue())
    elif _is_polars_dataframe(val):
        buf = io.BytesIO()
        val.write_ipc(buf)
        h.update(buf.getvalue())
    elif _is_pandas_dataframe(val):
        import pyarrow as pa

        table = pa.Table.from_pandas(val)
        sink = pa.BufferOutputStream()
        writer = pa.ipc.new_stream(sink, table.schema)
        writer.write_table(table)
        writer.close()
        h.update(sink.getvalue().to_pybytes())
    else:
        h.update(repr(val).encode())


def serialize_value(val: Any, dest: Path) -> dict:
    """Serialize a value to disk. Returns metadata dict for deserialization."""
    if _is_polars_dataframe(val) or _is_polars_lazyframe(val):
        if _is_polars_lazyframe(val):
            val = val.collect()
        path = dest / "result.ipc"
        val.write_ipc(path)
        return {"type": "polars.DataFrame", "file": "result.ipc"}
    elif _is_pandas_dataframe(val):
        import pyarrow as pa

        path = dest / "result.ipc"
        table = pa.Table.from_pandas(val)
        writer = pa.ipc.new_file(str(path), table.schema)
        writer.write_table(table)
        writer.close()
        return {"type": "pandas.DataFrame", "file": "result.ipc"}
    else:
        path = dest / "result.pkl"
        with open(path, "wb") as f:
            pickle.dump(val, f)
        return {"type": "pickle", "file": "result.pkl"}


def deserialize_value(meta: dict, src: Path) -> Any:
    """Deserialize a value from disk using metadata dict."""
    val_type = meta["type"]
    file_path = src / meta["file"]

    if val_type == "polars.DataFrame":
        import polars as pl

        return pl.read_ipc(file_path)
    elif val_type == "pandas.DataFrame":
        import pyarrow as pa

        table = pa.ipc.open_file(str(file_path)).read_all()
        return table.to_pandas()
    elif val_type == "pickle":
        with open(file_path, "rb") as f:
            return pickle.load(f)  # noqa: S301
    else:
        assert False, f"Unknown serialized type: {val_type}"
