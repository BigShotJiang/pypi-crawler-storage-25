import argparse
import inspect
import sys
from collections.abc import Callable
from pathlib import Path


_TYPE_MAP = {
    str: str,
    int: int,
    float: float,
    Path: Path,
}


def run(func: Callable) -> None:
    """Generate CLI from function signature and run it."""
    sig = inspect.signature(func)
    parser = argparse.ArgumentParser(description=func.__doc__ or "")

    for name, param in sig.parameters.items():
        annotation = (
            param.annotation if param.annotation != inspect.Parameter.empty else str
        )

        if param.default is inspect.Parameter.empty:
            # Positional argument
            parser.add_argument(name, type=_TYPE_MAP.get(annotation, str))
        else:
            cli_name = f"--{name.replace('_', '-')}"
            if annotation is bool:
                if param.default is False:
                    parser.add_argument(cli_name, action="store_true", dest=name)
                else:
                    parser.add_argument(cli_name, action="store_false", dest=name)
            else:
                parser.add_argument(
                    cli_name,
                    type=_TYPE_MAP.get(annotation, str),
                    default=param.default,
                    dest=name,
                )

    args = parser.parse_args()
    result = func(**vars(args))
    if result is None:
        return
    module = type(result).__module__
    if module.startswith("polars") or module.startswith("pandas"):
        sys.stdout.write(result.to_csv())
    else:
        print(result)
