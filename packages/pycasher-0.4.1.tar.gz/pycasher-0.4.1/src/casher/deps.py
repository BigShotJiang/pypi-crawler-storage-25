import hashlib
import inspect
import sys
from collections.abc import Callable
from pathlib import Path

from casher.config import HASH_ALGORITHM


def compute_dep_hash(func: Callable, dep_roots: list[Path] | None = None) -> str:
    mod = inspect.getmodule(func)
    assert mod is not None, f"Cannot determine module for {func}"
    assert (
        hasattr(mod, "__file__") and mod.__file__ is not None
    ), f"Module {mod.__name__} has no __file__"

    if dep_roots is None:
        dep_roots = _auto_detect_roots(mod)

    dep_roots_resolved = [Path(r).resolve() for r in dep_roots]

    # Collect all currently loaded modules whose source files fall under dep_roots
    file_hashes: list[tuple[str, str]] = []

    for name, m in sys.modules.items():
        src_file = getattr(m, "__file__", None)
        if src_file is None:
            continue
        src_path = Path(src_file).resolve()
        if not src_path.suffix == ".py":
            continue
        if not any(_is_under(src_path, root) for root in dep_roots_resolved):
            continue
        content_hash = hashlib.new(HASH_ALGORITHM, src_path.read_bytes()).hexdigest()
        file_hashes.append((str(src_path), content_hash))

    file_hashes.sort(key=lambda x: x[0])

    combined = "\n".join(f"{path}:{h}" for path, h in file_hashes)
    return hashlib.new(HASH_ALGORITHM, combined.encode()).hexdigest()


def _is_under(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _auto_detect_roots(mod) -> list[Path]:
    mod_file = Path(mod.__file__).resolve()
    # Walk up to find the top-level package directory
    parts = mod.__name__.split(".")
    pkg_dir = mod_file.parent
    for _ in range(len(parts) - 1):
        pkg_dir = pkg_dir.parent
    if len(parts) == 1:
        # Single-file module (no package) — use its directory as root
        return [pkg_dir]
    # Package module — root is the parent of the package directory
    return [pkg_dir.parent]
