import os
import sys
import textwrap

import pytest

from casher.decorator import cached
from casher.strace import is_strace_available

requires_strace = pytest.mark.skipif(
    not is_strace_available(), reason="strace not available"
)


@pytest.mark.timeout(10)
def test_pure_function_miss_then_hit(tmp_path):
    call_count_file = tmp_path / "call_count.txt"
    call_count_file.write_text("0")

    @cached(cache_dir=tmp_path / "cache", subprocess=False)
    def double(x: int) -> int:
        count = int(call_count_file.read_text())
        call_count_file.write_text(str(count + 1))
        return x * 2

    # First call: miss
    result1 = double(5)
    assert result1 == 10
    assert int(call_count_file.read_text()) == 1

    # Second call: hit
    result2 = double(5)
    assert result2 == 10
    assert int(call_count_file.read_text()) == 1  # not called again


@pytest.mark.timeout(10)
def test_file_read_auto_discovered_inprocess(tmp_path):
    data_file = tmp_path / "data.txt"
    data_file.write_text("version1")

    @cached(cache_dir=tmp_path / "cache", subprocess=False)
    def read_data(path: str) -> str:
        with open(path) as f:
            return f.read()

    # Miss
    result1 = read_data(str(data_file))
    assert result1 == "version1"

    # Hit (file unchanged)
    result2 = read_data(str(data_file))
    assert result2 == "version1"

    # Modify file → miss
    data_file.write_text("version2")
    result3 = read_data(str(data_file))
    assert result3 == "version2"


@pytest.mark.timeout(10)
def test_output_file_auto_captured_inprocess(tmp_path):
    output_file = tmp_path / "output.txt"

    @cached(
        cache_dir=tmp_path / "cache", subprocess=False, output_files=[str(output_file)]
    )
    def write_output() -> str:
        output_file.write_text("generated output")
        return "done"

    # Miss — creates output file
    result1 = write_output()
    assert result1 == "done"
    assert output_file.read_text() == "generated output"

    # Delete output file
    output_file.unlink()
    assert not output_file.exists()

    # Hit — output file restored from cache
    result2 = write_output()
    assert result2 == "done"
    assert output_file.exists()
    assert output_file.read_text() == "generated output"


@pytest.mark.timeout(10)
def test_stdout_stderr_captured(tmp_path, capsys):
    call_count_file = tmp_path / "count.txt"
    call_count_file.write_text("0")

    @cached(cache_dir=tmp_path / "cache", subprocess=False)
    def noisy() -> int:
        count = int(call_count_file.read_text())
        call_count_file.write_text(str(count + 1))
        print("hello stdout")
        import sys

        print("hello stderr", file=sys.stderr)
        return 42

    # Miss — captures stdout/stderr
    result1 = noisy()
    assert result1 == 42
    captured1 = capsys.readouterr()
    assert "hello stdout" in captured1.out
    assert "hello stderr" in captured1.err

    # Hit — replays stdout/stderr
    result2 = noisy()
    assert result2 == 42
    captured2 = capsys.readouterr()
    assert "hello stdout" in captured2.out
    assert "hello stderr" in captured2.err
    assert int(call_count_file.read_text()) == 1  # only called once


@pytest.mark.timeout(10)
def test_enabled_false(tmp_path):
    call_count_file = tmp_path / "count.txt"
    call_count_file.write_text("0")

    @cached(cache_dir=tmp_path / "cache", enabled=False)
    def always_runs(x: int) -> int:
        count = int(call_count_file.read_text())
        call_count_file.write_text(str(count + 1))
        return x + 1

    result1 = always_runs(5)
    assert result1 == 6
    assert int(call_count_file.read_text()) == 1

    result2 = always_runs(5)
    assert result2 == 6
    assert int(call_count_file.read_text()) == 2  # called again


@pytest.mark.timeout(10)
def test_env_vars(tmp_path, monkeypatch):
    call_count_file = tmp_path / "count.txt"
    call_count_file.write_text("0")

    @cached(cache_dir=tmp_path / "cache", subprocess=False, env_vars=["MY_TEST_VAR"])
    def env_sensitive(x: int) -> str:
        count = int(call_count_file.read_text())
        call_count_file.write_text(str(count + 1))
        return f"{x}:{os.environ.get('MY_TEST_VAR', '')}"

    monkeypatch.setenv("MY_TEST_VAR", "alpha")
    result1 = env_sensitive(1)
    assert result1 == "1:alpha"
    assert int(call_count_file.read_text()) == 1

    # Same env var → hit
    result2 = env_sensitive(1)
    assert result2 == "1:alpha"
    assert int(call_count_file.read_text()) == 1

    # Change env var → miss
    monkeypatch.setenv("MY_TEST_VAR", "beta")
    result3 = env_sensitive(1)
    assert result3 == "1:beta"
    assert int(call_count_file.read_text()) == 2


@pytest.mark.timeout(10)
def test_function_returns_none(tmp_path, capsys):
    call_count_file = tmp_path / "count.txt"
    call_count_file.write_text("0")

    @cached(cache_dir=tmp_path / "cache", subprocess=False)
    def returns_none() -> None:
        count = int(call_count_file.read_text())
        call_count_file.write_text(str(count + 1))
        print("side effect")

    # Miss
    result1 = returns_none()
    assert result1 is None
    captured1 = capsys.readouterr()
    assert "side effect" in captured1.out

    # Hit — replays stdout, returns None
    result2 = returns_none()
    assert result2 is None
    captured2 = capsys.readouterr()
    assert "side effect" in captured2.out
    assert int(call_count_file.read_text()) == 1


@pytest.mark.timeout(10)
def test_max_cache_bytes_eviction(tmp_path):
    cache_dir = tmp_path / "cache"

    @cached(cache_dir=cache_dir, subprocess=False, max_cache_bytes=3000)
    def make_data(x: int) -> str:
        return "x" * 500  # each entry will be a few hundred bytes

    # Create several entries with different args to fill cache
    for i in range(10):
        make_data(i)

    # Cache should have been evicted to stay under 3000 bytes
    from casher.eviction import get_cache_size

    total = get_cache_size(cache_dir)
    assert total <= 3000


# ── subprocess=True tests ────────────────────────────────────────────


def _write_importable_module(tmp_path, module_name, source):
    """Write a .py file and add tmp_path to sys.path so it can be imported."""
    mod_file = tmp_path / f"{module_name}.py"
    mod_file.write_text(textwrap.dedent(source))
    if str(tmp_path) not in sys.path:
        sys.path.insert(0, str(tmp_path))
    # Ensure clean import
    if module_name in sys.modules:
        del sys.modules[module_name]
    return mod_file


@requires_strace
@pytest.mark.timeout(30)
def test_file_read_auto_discovered(tmp_path):
    data_file = tmp_path / "data.txt"
    data_file.write_text("version1")

    mod_name = f"_casher_test_read_{os.getpid()}"
    _write_importable_module(
        tmp_path,
        mod_name,
        f"""\
        from casher import cached

        @cached(cache_dir="{tmp_path / 'cache'}", subprocess=True)
        def read_data(path: str) -> str:
            with open(path) as f:
                return f.read()
    """,
    )

    try:
        import importlib

        mod = importlib.import_module(mod_name)

        result1 = mod.read_data(str(data_file))
        assert result1 == "version1"

        result2 = mod.read_data(str(data_file))
        assert result2 == "version1"

        # Modify file → miss
        data_file.write_text("version2")
        result3 = mod.read_data(str(data_file))
        assert result3 == "version2"
    finally:
        sys.modules.pop(mod_name, None)
        sys.path.remove(str(tmp_path))


@requires_strace
@pytest.mark.timeout(30)
def test_output_file_auto_captured(tmp_path):
    output_file = tmp_path / "output.txt"

    mod_name = f"_casher_test_output_{os.getpid()}"
    _write_importable_module(
        tmp_path,
        mod_name,
        f"""\
        from casher import cached

        @cached(cache_dir="{tmp_path / 'cache'}", subprocess=True)
        def write_output(out_path: str) -> str:
            with open(out_path, "w") as f:
                f.write("generated output")
            return "done"
    """,
    )

    try:
        import importlib

        mod = importlib.import_module(mod_name)

        result1 = mod.write_output(str(output_file))
        assert result1 == "done"
        assert output_file.read_text() == "generated output"

        # Delete output file
        output_file.unlink()
        assert not output_file.exists()

        # Hit — output file restored from cache
        result2 = mod.write_output(str(output_file))
        assert result2 == "done"
        assert output_file.exists()
        assert output_file.read_text() == "generated output"
    finally:
        sys.modules.pop(mod_name, None)
        sys.path.remove(str(tmp_path))


@requires_strace
@pytest.mark.timeout(30)
def test_dependency_invalidation(tmp_path):
    # Create helper module
    helper_file = _write_importable_module(
        tmp_path,
        f"_casher_helper_{os.getpid()}",
        """\
        def transform(x):
            return x * 2
    """,
    )
    helper_mod_name = f"_casher_helper_{os.getpid()}"

    mod_name = f"_casher_test_dep_{os.getpid()}"
    _write_importable_module(
        tmp_path,
        mod_name,
        f"""\
        from casher import cached
        from {helper_mod_name} import transform

        @cached(cache_dir="{tmp_path / 'cache'}", subprocess=True,
                dep_roots=["{tmp_path}"])
        def run_transform(x: int) -> int:
            return transform(x)
    """,
    )

    try:
        import importlib

        mod = importlib.import_module(mod_name)

        result1 = mod.run_transform(5)
        assert result1 == 10

        # Same call → hit
        result2 = mod.run_transform(5)
        assert result2 == 10

        # Modify helper → dep hash changes → miss
        helper_file.write_text("def transform(x):\n    return x * 3\n")
        # Remove __pycache__ so Python doesn't use stale bytecode
        import shutil

        pycache = tmp_path / "__pycache__"
        if pycache.exists():
            shutil.rmtree(pycache)
        # Must reload both modules for the parent to pick up changes
        sys.modules.pop(helper_mod_name, None)
        sys.modules.pop(mod_name, None)
        mod = importlib.import_module(mod_name)

        result3 = mod.run_transform(5)
        assert result3 == 15
    finally:
        sys.modules.pop(mod_name, None)
        sys.modules.pop(helper_mod_name, None)
        if str(tmp_path) in sys.path:
            sys.path.remove(str(tmp_path))


@requires_strace
@pytest.mark.timeout(30)
def test_polars_df_arg(tmp_path):
    polars = pytest.importorskip("polars")

    mod_name = f"_casher_test_polars_{os.getpid()}"
    _write_importable_module(
        tmp_path,
        mod_name,
        f"""\
        import polars as pl
        from casher import cached

        @cached(cache_dir="{tmp_path / 'cache'}", subprocess=True)
        def filter_df(df: pl.DataFrame, threshold: int) -> pl.DataFrame:
            return df.filter(pl.col("value") > threshold)
    """,
    )

    try:
        import importlib

        mod = importlib.import_module(mod_name)

        df = polars.DataFrame({"value": [1, 2, 3, 4, 5]})
        result1 = mod.filter_df(df, 2)
        assert len(result1) == 3
        assert result1["value"].to_list() == [3, 4, 5]

        # Same call → hit
        result2 = mod.filter_df(df, 2)
        assert len(result2) == 3
        assert result2["value"].to_list() == [3, 4, 5]
    finally:
        sys.modules.pop(mod_name, None)
        if str(tmp_path) in sys.path:
            sys.path.remove(str(tmp_path))


@requires_strace
@pytest.mark.timeout(30)
def test_pandas_df_arg(tmp_path):
    pandas = pytest.importorskip("pandas")

    mod_name = f"_casher_test_pandas_{os.getpid()}"
    _write_importable_module(
        tmp_path,
        mod_name,
        f"""\
        import pandas as pd
        from casher import cached

        @cached(cache_dir="{tmp_path / 'cache'}", subprocess=True)
        def sum_by_group(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
            return df.groupby(group_col).sum().reset_index()
    """,
    )

    try:
        import importlib

        mod = importlib.import_module(mod_name)

        df = pandas.DataFrame({"group": ["a", "b", "a", "b"], "val": [1, 2, 3, 4]})
        result1 = mod.sum_by_group(df, "group")
        assert len(result1) == 2
        assert list(result1["val"]) == [4, 6]

        # Same call → hit
        result2 = mod.sum_by_group(df, "group")
        assert len(result2) == 2
        assert list(result2["val"]) == [4, 6]
    finally:
        sys.modules.pop(mod_name, None)
        if str(tmp_path) in sys.path:
            sys.path.remove(str(tmp_path))


@requires_strace
@pytest.mark.timeout(30)
def test_explicit_input_files_supplement(tmp_path):
    data_file = tmp_path / "data.txt"
    data_file.write_text("main data")
    extra_file = tmp_path / "extra.cfg"
    extra_file.write_text("config_v1")

    mod_name = f"_casher_test_explicit_{os.getpid()}"
    _write_importable_module(
        tmp_path,
        mod_name,
        f"""\
        from casher import cached

        @cached(cache_dir="{tmp_path / 'cache'}", subprocess=True,
                input_files=["{extra_file}"])
        def process(path: str) -> str:
            with open(path) as f:
                return f.read()
    """,
    )

    try:
        import importlib

        mod = importlib.import_module(mod_name)

        result1 = mod.process(str(data_file))
        assert result1 == "main data"

        # Same call → hit
        result2 = mod.process(str(data_file))
        assert result2 == "main data"

        # Modify extra.cfg → miss (explicit input changed)
        extra_file.write_text("config_v2")
        result3 = mod.process(str(data_file))
        assert result3 == "main data"  # Same return, but cache was invalidated
    finally:
        sys.modules.pop(mod_name, None)
        if str(tmp_path) in sys.path:
            sys.path.remove(str(tmp_path))


@requires_strace
@pytest.mark.timeout(30)
def test_ignore_files(tmp_path):
    data_file = tmp_path / "data.txt"
    data_file.write_text("important")
    log_file = tmp_path / "debug.log"
    log_file.write_text("log_v1")

    mod_name = f"_casher_test_ignore_{os.getpid()}"
    _write_importable_module(
        tmp_path,
        mod_name,
        f"""\
        from casher import cached

        @cached(cache_dir="{tmp_path / 'cache'}", subprocess=True,
                ignore_files=["*.log"])
        def read_both(data_path: str, log_path: str) -> str:
            with open(data_path) as f:
                data = f.read()
            with open(log_path) as f:
                _ = f.read()  # read but ignored for caching
            return data
    """,
    )

    try:
        import importlib

        mod = importlib.import_module(mod_name)

        result1 = mod.read_both(str(data_file), str(log_file))
        assert result1 == "important"

        # Modify log file → still a hit (ignored)
        log_file.write_text("log_v2")
        result2 = mod.read_both(str(data_file), str(log_file))
        assert result2 == "important"

        # Modify data file → miss
        data_file.write_text("updated")
        result3 = mod.read_both(str(data_file), str(log_file))
        assert result3 == "updated"
    finally:
        sys.modules.pop(mod_name, None)
        if str(tmp_path) in sys.path:
            sys.path.remove(str(tmp_path))
