import pytest

from casher.audit_hook import track_file_io


@pytest.mark.timeout(10)
def test_captures_read(tmp_path):
    f = tmp_path / "read_me.txt"
    f.write_text("hello")

    with track_file_io() as tracker:
        with open(str(f)) as fh:
            fh.read()

    assert any(str(f) == str(rf) for rf in tracker.read_files)


@pytest.mark.timeout(10)
def test_captures_write(tmp_path):
    f = tmp_path / "write_me.txt"

    with track_file_io() as tracker:
        with open(str(f), "w") as fh:
            fh.write("data")

    assert any(str(f) == str(wf) for wf in tracker.write_files)


@pytest.mark.timeout(10)
def test_classifies_mode_correctly(tmp_path):
    read_file = tmp_path / "r_file.txt"
    read_file.write_text("content")
    rb_file = tmp_path / "rb_file.txt"
    rb_file.write_text("binary content")
    write_file = tmp_path / "w_file.txt"
    append_file = tmp_path / "a_file.txt"

    with track_file_io() as tracker:
        with open(str(read_file)) as fh:
            fh.read()
        with open(str(rb_file), "rb") as fh:
            fh.read()
        with open(str(write_file), "w") as fh:
            fh.write("out")
        with open(str(append_file), "a") as fh:
            fh.write("appended")

    read_paths = {str(p) for p in tracker.read_files}
    write_paths = {str(p) for p in tracker.write_files}

    assert str(read_file) in read_paths
    assert str(rb_file) in read_paths
    assert str(write_file) in write_paths
    assert str(append_file) in write_paths


@pytest.mark.timeout(10)
def test_scoped_tracking(tmp_path):
    outside_file = tmp_path / "outside.txt"
    outside_file.write_text("before scope")
    inside_file = tmp_path / "inside.txt"
    inside_file.write_text("in scope")

    # Read outside the tracking context
    with open(str(outside_file)) as fh:
        fh.read()

    with track_file_io() as tracker:
        with open(str(inside_file)) as fh:
            fh.read()

    tracked_paths = {str(p) for p in tracker.read_files}
    assert str(inside_file) in tracked_paths
    assert str(outside_file) not in tracked_paths


@pytest.mark.timeout(10)
def test_multiple_files(tmp_path):
    read_files = []
    for i in range(3):
        f = tmp_path / f"read_{i}.txt"
        f.write_text(f"read content {i}")
        read_files.append(f)

    write_files = []
    for i in range(2):
        write_files.append(tmp_path / f"write_{i}.txt")

    with track_file_io() as tracker:
        for f in read_files:
            with open(str(f)) as fh:
                fh.read()
        for f in write_files:
            with open(str(f), "w") as fh:
                fh.write("output")

    tracked_reads = {str(p) for p in tracker.read_files}
    tracked_writes = {str(p) for p in tracker.write_files}

    for f in read_files:
        assert str(f) in tracked_reads
    for f in write_files:
        assert str(f) in tracked_writes
