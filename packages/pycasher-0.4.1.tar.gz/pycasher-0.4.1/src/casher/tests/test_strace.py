import sys
import textwrap
from pathlib import Path

import pytest

from casher.strace import (
    is_strace_available,
    parse_strace_log,
    run_with_strace,
)


_skip_no_strace = pytest.mark.skipif(
    not is_strace_available(), reason="strace not installed"
)


@pytest.mark.timeout(10)
def test_parse_strace_log(tmp_path):
    log = tmp_path / "trace.log"
    log.write_text(
        textwrap.dedent(
            """\
        1234  openat(AT_FDCWD, "/home/user/data.csv", O_RDONLY) = 3
        1234  openat(AT_FDCWD, "/home/user/out.txt", O_WRONLY|O_CREAT|O_TRUNC, 0666) = 4
    """
        )
    )
    read_files, write_files = parse_strace_log(log)
    assert Path("/home/user/data.csv") in read_files
    assert Path("/home/user/out.txt") in write_files


@pytest.mark.timeout(10)
def test_filter_noise(tmp_path):
    log = tmp_path / "trace.log"
    log.write_text(
        textwrap.dedent(
            """\
        1234  openat(AT_FDCWD, "/dev/null", O_RDONLY) = 3
        1234  openat(AT_FDCWD, "/proc/self/maps", O_RDONLY) = 4
        1234  openat(AT_FDCWD, "/usr/lib/python3.12/site-packages/numpy/__init__.py", O_RDONLY) = 5
        1234  openat(AT_FDCWD, "/home/user/real_data.txt", O_RDONLY) = 6
        1234  openat(AT_FDCWD, "/home/user/module.pyc", O_RDONLY) = 7
    """
        )
    )
    read_files, write_files = parse_strace_log(log)
    assert read_files == [Path("/home/user/real_data.txt")]
    assert write_files == []


@pytest.mark.timeout(10)
def test_read_vs_write_classification(tmp_path):
    log = tmp_path / "trace.log"
    log.write_text(
        textwrap.dedent(
            """\
        1234  openat(AT_FDCWD, "/home/user/input.csv", O_RDONLY) = 3
        1234  openat(AT_FDCWD, "/home/user/output.parquet", O_WRONLY|O_CREAT|O_TRUNC, 0666) = 4
        1234  openat(AT_FDCWD, "/home/user/log.txt", O_RDWR|O_CREAT, 0644) = 5
    """
        )
    )
    read_files, write_files = parse_strace_log(log)
    assert read_files == [Path("/home/user/input.csv")]
    assert Path("/home/user/output.parquet") in write_files
    assert Path("/home/user/log.txt") in write_files


@pytest.mark.timeout(10)
def test_is_strace_available():
    result = is_strace_available()
    assert isinstance(result, bool)


@_skip_no_strace
@pytest.mark.timeout(30)
def test_run_with_strace_reads_file(tmp_path):
    input_file = tmp_path / "input.txt"
    input_file.write_text("hello from strace test")

    script = tmp_path / "reader.py"
    script.write_text(
        textwrap.dedent(
            f"""\
        with open("{input_file}") as f:
            print(f.read(), end="")
    """
        )
    )

    result = run_with_strace([sys.executable, str(script)])
    assert result.returncode == 0
    assert result.stdout.strip() == "hello from strace test"
    assert any(str(input_file) == str(rf) for rf in result.read_files)


@_skip_no_strace
@pytest.mark.timeout(30)
def test_run_with_strace_writes_file(tmp_path):
    output_file = tmp_path / "output.txt"

    script = tmp_path / "writer.py"
    script.write_text(
        textwrap.dedent(
            f"""\
        with open("{output_file}", "w") as f:
            f.write("written by strace test")
    """
        )
    )

    result = run_with_strace([sys.executable, str(script)])
    assert result.returncode == 0
    assert output_file.read_text() == "written by strace test"
    assert any(str(output_file) == str(wf) for wf in result.write_files)


@_skip_no_strace
@pytest.mark.timeout(30)
def test_run_with_strace_reads_and_writes(tmp_path):
    input_file = tmp_path / "in.txt"
    input_file.write_text("source data")
    output_file = tmp_path / "out.txt"

    script = tmp_path / "rw.py"
    script.write_text(
        textwrap.dedent(
            f"""\
        with open("{input_file}") as f:
            data = f.read()
        with open("{output_file}", "w") as f:
            f.write(data.upper())
    """
        )
    )

    result = run_with_strace([sys.executable, str(script)])
    assert result.returncode == 0
    assert output_file.read_text() == "SOURCE DATA"
    assert any(str(input_file) == str(rf) for rf in result.read_files)
    assert any(str(output_file) == str(wf) for wf in result.write_files)
