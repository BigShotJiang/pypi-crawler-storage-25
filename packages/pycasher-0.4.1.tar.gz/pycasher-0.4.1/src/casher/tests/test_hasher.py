import pytest

from casher.hasher import compute_partial_key, compute_file_hash, compute_full_key
from casher.tests.config import (
    TEST_FUNC_MODULE,
    TEST_FUNC_NAME,
    TEST_DEP_HASH,
    TEST_ARGS_HASH,
)


@pytest.mark.timeout(10)
def test_partial_key_deterministic():
    key1 = compute_partial_key(
        TEST_FUNC_MODULE, TEST_FUNC_NAME, TEST_DEP_HASH, TEST_ARGS_HASH, []
    )
    key2 = compute_partial_key(
        TEST_FUNC_MODULE, TEST_FUNC_NAME, TEST_DEP_HASH, TEST_ARGS_HASH, []
    )
    assert key1 == key2


@pytest.mark.timeout(10)
def test_partial_key_differs_on_args():
    key1 = compute_partial_key(
        TEST_FUNC_MODULE, TEST_FUNC_NAME, TEST_DEP_HASH, "args_a", []
    )
    key2 = compute_partial_key(
        TEST_FUNC_MODULE, TEST_FUNC_NAME, TEST_DEP_HASH, "args_b", []
    )
    assert key1 != key2


@pytest.mark.timeout(10)
def test_file_hash_changes_with_content(tmp_path):
    f = tmp_path / "data.txt"
    f.write_text("version 1")
    hash1 = compute_file_hash([f])

    f.write_text("version 2")
    hash2 = compute_file_hash([f])
    assert hash1 != hash2


@pytest.mark.timeout(10)
def test_file_hash_stable(tmp_path):
    f = tmp_path / "data.txt"
    f.write_text("stable content")
    hash1 = compute_file_hash([f])
    hash2 = compute_file_hash([f])
    assert hash1 == hash2


@pytest.mark.timeout(10)
def test_full_key_combines():
    full1 = compute_full_key("partial_a", "file_a")
    full2 = compute_full_key("partial_a", "file_a")
    assert full1 == full2

    full3 = compute_full_key("partial_a", "file_b")
    assert full1 != full3

    full4 = compute_full_key("partial_b", "file_a")
    assert full1 != full4


@pytest.mark.timeout(10)
def test_env_var_changes_key(monkeypatch):
    monkeypatch.setenv("CASHER_TEST_VAR", "value_a")
    key1 = compute_partial_key(
        TEST_FUNC_MODULE,
        TEST_FUNC_NAME,
        TEST_DEP_HASH,
        TEST_ARGS_HASH,
        ["CASHER_TEST_VAR"],
    )

    monkeypatch.setenv("CASHER_TEST_VAR", "value_b")
    key2 = compute_partial_key(
        TEST_FUNC_MODULE,
        TEST_FUNC_NAME,
        TEST_DEP_HASH,
        TEST_ARGS_HASH,
        ["CASHER_TEST_VAR"],
    )

    assert key1 != key2
