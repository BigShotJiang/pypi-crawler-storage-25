import subprocess
import sys
import textwrap

import pytest

from casher.strace import is_strace_available

pytestmark = pytest.mark.skipif(
    not is_strace_available(), reason="strace not available"
)


@pytest.mark.timeout(30)
def test_miss_then_hit(tmp_path):
    """Run a script via acache, verify miss then hit."""
    cache_dir = tmp_path / "cache"
    input_file = tmp_path / "input.txt"
    output_file = tmp_path / "output.txt"
    input_file.write_text("hello from input")

    script = tmp_path / "process.py"
    script.write_text(
        textwrap.dedent(
            f"""\
        with open("{input_file}") as f:
            data = f.read()
        with open("{output_file}", "w") as f:
            f.write(data.upper())
        print("processed")
    """
        )
    )

    # First run — miss
    result1 = subprocess.run(
        [
            sys.executable,
            "-m",
            "casher.acache",
            "--cache-dir",
            str(cache_dir),
            "--",
            sys.executable,
            str(script),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result1.returncode == 0
    assert "processed" in result1.stdout
    assert output_file.read_text() == "HELLO FROM INPUT"

    # Delete output file
    output_file.unlink()
    assert not output_file.exists()

    # Second run — hit (output restored)
    result2 = subprocess.run(
        [
            sys.executable,
            "-m",
            "casher.acache",
            "--cache-dir",
            str(cache_dir),
            "--",
            sys.executable,
            str(script),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result2.returncode == 0
    assert output_file.exists()
    assert output_file.read_text() == "HELLO FROM INPUT"


@pytest.mark.timeout(30)
def test_cache_miss_on_input_change(tmp_path):
    """Modify input file → cache miss."""
    cache_dir = tmp_path / "cache"
    input_file = tmp_path / "input.txt"
    input_file.write_text("original content")

    script = tmp_path / "reader.py"
    script.write_text(
        textwrap.dedent(
            f"""\
        with open("{input_file}") as f:
            print(f.read().strip())
    """
        )
    )

    # First run
    result1 = subprocess.run(
        [
            sys.executable,
            "-m",
            "casher.acache",
            "--cache-dir",
            str(cache_dir),
            "--",
            sys.executable,
            str(script),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result1.returncode == 0
    assert "original content" in result1.stdout

    # Modify input
    input_file.write_text("modified content")

    # Second run — miss (input changed)
    result2 = subprocess.run(
        [
            sys.executable,
            "-m",
            "casher.acache",
            "--cache-dir",
            str(cache_dir),
            "--",
            sys.executable,
            str(script),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result2.returncode == 0
    assert "modified content" in result2.stdout


@pytest.mark.timeout(30)
def test_stdout_stderr_replayed(tmp_path):
    """Verify stdout/stderr replay on hit."""
    cache_dir = tmp_path / "cache"

    script = tmp_path / "chatty.py"
    script.write_text(
        textwrap.dedent(
            """\
        import sys
        print("hello stdout")
        print("hello stderr", file=sys.stderr)
    """
        )
    )

    # First run — miss
    result1 = subprocess.run(
        [
            sys.executable,
            "-m",
            "casher.acache",
            "--cache-dir",
            str(cache_dir),
            "--",
            sys.executable,
            str(script),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result1.returncode == 0
    assert "hello stdout" in result1.stdout
    assert "hello stderr" in result1.stderr

    # Second run — hit (stdout/stderr replayed)
    result2 = subprocess.run(
        [
            sys.executable,
            "-m",
            "casher.acache",
            "--cache-dir",
            str(cache_dir),
            "--",
            sys.executable,
            str(script),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result2.returncode == 0
    assert "hello stdout" in result2.stdout
    assert "hello stderr" in result2.stderr


@pytest.mark.timeout(30)
def test_custom_cache_dir(tmp_path):
    """Verify custom cache directory."""
    cache_dir = tmp_path / "custom_cache"

    script = tmp_path / "simple.py"
    script.write_text('print("custom dir test")\n')

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "casher.acache",
            "--cache-dir",
            str(cache_dir),
            "--",
            sys.executable,
            str(script),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result.returncode == 0
    assert cache_dir.is_dir()
    entries = [e for e in cache_dir.iterdir() if not e.name.startswith(".")]
    assert len(entries) > 0
