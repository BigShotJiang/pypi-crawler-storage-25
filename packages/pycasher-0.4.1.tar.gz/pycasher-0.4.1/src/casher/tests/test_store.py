import time

import pytest

from casher.hasher import compute_file_hash
from casher.store import CacheEntry, find_cached, store_result, invalidate, clear_cache
from casher.tests.config import TEST_FILE_HASH


def _make_entry(**overrides) -> CacheEntry:
    defaults = dict(
        return_value=42,
        stdout="hello stdout",
        stderr="",
        output_files={},
        input_files={},
        created_at=time.time(),
        func_module="test_mod",
        func_name="test_fn",
    )
    defaults.update(overrides)
    return CacheEntry(**defaults)


@pytest.mark.timeout(10)
def test_store_and_find(tmp_path):
    cache_dir = tmp_path / "cache"
    input_file = tmp_path / "input.txt"
    input_file.write_text("input data")
    file_hash_val = compute_file_hash([input_file])

    entry = _make_entry(
        input_files={str(input_file): file_hash_val},
        return_value={"result": 99},
        stdout="some output",
        stderr="some error",
    )
    partial_key = "pk_test_store"
    store_result(cache_dir, partial_key, file_hash_val, entry)

    result = find_cached(cache_dir, partial_key)
    assert result is not None
    found, found_dir = result
    assert found.return_value == {"result": 99}
    assert found.stdout == "some output"
    assert found.stderr == "some error"


@pytest.mark.timeout(10)
def test_find_returns_none_missing(tmp_path):
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    assert find_cached(cache_dir, "nonexistent") is None


@pytest.mark.timeout(10)
def test_find_returns_none_file_changed(tmp_path):
    cache_dir = tmp_path / "cache"
    input_file = tmp_path / "input.txt"
    input_file.write_text("original")
    file_hash_val = compute_file_hash([input_file])

    entry = _make_entry(input_files={str(input_file): file_hash_val})
    store_result(cache_dir, "pk_change", file_hash_val, entry)

    # Modify the input file
    input_file.write_text("modified")
    assert find_cached(cache_dir, "pk_change") is None


@pytest.mark.timeout(10)
def test_multiple_entries_same_partial_key(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_multi"

    # Entry 1 with file content "v1"
    input_file = tmp_path / "input.txt"
    input_file.write_text("v1")
    fh1 = compute_file_hash([input_file])
    entry1 = _make_entry(return_value="result_v1", input_files={str(input_file): fh1})
    store_result(cache_dir, partial_key, fh1, entry1)

    # Entry 2 with file content "v2"
    input_file.write_text("v2")
    fh2 = compute_file_hash([input_file])
    entry2 = _make_entry(return_value="result_v2", input_files={str(input_file): fh2})
    store_result(cache_dir, partial_key, fh2, entry2)

    # Current file is "v2" — should find entry2
    result = find_cached(cache_dir, partial_key)
    assert result is not None
    found, _ = result
    assert found.return_value == "result_v2"

    # Switch back to "v1" — should find entry1
    input_file.write_text("v1")
    result = find_cached(cache_dir, partial_key)
    assert result is not None
    found, _ = result
    assert found.return_value == "result_v1"


@pytest.mark.timeout(10)
def test_corrupted_meta_json(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_corrupt"

    entry = _make_entry()
    store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)

    # Corrupt meta.json
    meta_path = cache_dir / partial_key / TEST_FILE_HASH / "meta.json"
    meta_path.write_text("not valid json{{{")

    result = find_cached(cache_dir, partial_key)
    assert result is None
    # Corrupted dir should be cleaned up
    assert not (cache_dir / partial_key / TEST_FILE_HASH).exists()


@pytest.mark.timeout(10)
def test_invalidate(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_invalidate"

    entry = _make_entry()
    store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)
    assert find_cached(cache_dir, partial_key) is not None

    assert invalidate(cache_dir, partial_key) is True
    assert find_cached(cache_dir, partial_key) is None


@pytest.mark.timeout(10)
def test_clear_cache(tmp_path):
    cache_dir = tmp_path / "cache"

    for i in range(3):
        entry = _make_entry(return_value=i)
        store_result(cache_dir, f"pk_{i}", f"fh_{i}", entry)

    count = clear_cache(cache_dir)
    assert count == 3
    # Only lock file and similar should remain
    remaining_dirs = [
        d for d in cache_dir.iterdir() if d.is_dir() and not d.name.startswith(".")
    ]
    assert len(remaining_dirs) == 0


@pytest.mark.timeout(10)
def test_mtime_updated_on_hit(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_mtime"

    entry = _make_entry()
    store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)

    meta_path = cache_dir / partial_key / TEST_FILE_HASH / "meta.json"
    mtime_before = meta_path.stat().st_mtime

    # Ensure measurable time difference
    time.sleep(0.05)

    result = find_cached(cache_dir, partial_key)
    assert result is not None

    mtime_after = meta_path.stat().st_mtime
    assert mtime_after > mtime_before


@pytest.mark.timeout(10)
def test_output_files_stored(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_output"

    # Create a real output file
    output_file = tmp_path / "output.txt"
    output_file.write_text("output content")

    entry = _make_entry(output_files={"output.txt": output_file})
    result_dir = store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)

    cached_output = result_dir / "output_files" / "output.txt"
    assert cached_output.exists()
    assert cached_output.read_text() == "output content"
