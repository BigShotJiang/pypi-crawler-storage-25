import polars as pl
import pandas as pd
import pytest

from casher.serializer import hash_value, serialize_value, deserialize_value


@pytest.mark.timeout(10)
def test_hash_primitives():
    results = [
        hash_value(42),
        hash_value("hello"),
        hash_value(3.14),
        hash_value(None),
        hash_value(True),
    ]
    # Each produces bytes
    for r in results:
        assert isinstance(r, bytes)
        assert len(r) > 0
    # Same input = same output
    assert hash_value(42) == hash_value(42)
    assert hash_value("hello") == hash_value("hello")
    # Different inputs = different outputs
    assert hash_value(42) != hash_value(43)


@pytest.mark.timeout(10)
def test_hash_collections():
    h_list = hash_value([1, 2, 3])
    h_dict = hash_value({"a": 1, "b": 2})
    h_tuple = hash_value((1, 2))
    assert isinstance(h_list, bytes)
    assert isinstance(h_dict, bytes)
    assert isinstance(h_tuple, bytes)
    # Deterministic
    assert hash_value([1, 2, 3]) == h_list
    assert hash_value({"a": 1, "b": 2}) == h_dict


@pytest.mark.timeout(10)
def test_hash_set_deterministic():
    hashes = [hash_value({3, 1, 2}) for _ in range(100)]
    assert all(h == hashes[0] for h in hashes)


@pytest.mark.timeout(10)
def test_hash_polars_df():
    df1 = pl.DataFrame({"a": [1, 2, 3], "b": [4.0, 5.0, 6.0]})
    h1 = hash_value(df1)
    h2 = hash_value(df1)
    assert h1 == h2

    df2 = pl.DataFrame({"a": [1, 2, 99], "b": [4.0, 5.0, 6.0]})
    h3 = hash_value(df2)
    assert h1 != h3


@pytest.mark.timeout(10)
def test_hash_pandas_df():
    df1 = pd.DataFrame({"a": [1, 2, 3], "b": [4.0, 5.0, 6.0]})
    h1 = hash_value(df1)
    h2 = hash_value(df1)
    assert h1 == h2

    df2 = pd.DataFrame({"a": [1, 2, 99], "b": [4.0, 5.0, 6.0]})
    h3 = hash_value(df2)
    assert h1 != h3


@pytest.mark.timeout(10)
def test_roundtrip_primitives(tmp_path):
    for val in [42, "hello", 3.14, [1, 2, 3], {"key": "value"}]:
        meta = serialize_value(val, tmp_path)
        restored = deserialize_value(meta, tmp_path)
        assert restored == val


@pytest.mark.timeout(10)
def test_roundtrip_polars_df(tmp_path):
    df = pl.DataFrame({"x": [10, 20, 30], "y": ["a", "b", "c"]})
    meta = serialize_value(df, tmp_path)
    restored = deserialize_value(meta, tmp_path)
    assert df.equals(restored)


@pytest.mark.timeout(10)
def test_roundtrip_pandas_df(tmp_path):
    df = pd.DataFrame({"x": [10, 20, 30], "y": ["a", "b", "c"]})
    meta = serialize_value(df, tmp_path)
    restored = deserialize_value(meta, tmp_path)
    pd.testing.assert_frame_equal(df, restored)


@pytest.mark.timeout(10)
def test_hash_path_directory(tmp_path):
    """hash_value on a directory Path must not crash (no read_bytes on dirs)."""
    d = tmp_path / "subdir"
    d.mkdir()
    # Should not raise IsADirectoryError
    h = hash_value(d)
    assert isinstance(h, bytes)
    assert len(h) > 0
    # Deterministic
    assert hash_value(d) == hash_value(d)


@pytest.mark.timeout(10)
def test_hash_path_file_vs_dir(tmp_path):
    """File Path hashes content; directory Path hashes repr — they differ."""
    f = tmp_path / "file.txt"
    f.write_text("hello")
    d = tmp_path / "dir"
    d.mkdir()
    assert hash_value(f) != hash_value(d)
