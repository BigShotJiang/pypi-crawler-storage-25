import subprocess
import sys
import textwrap

import pytest


@pytest.mark.timeout(30)
def test_cli_generation(tmp_path):
    """Write a script with @cached + auto_cli.run(), run --help, verify param names."""
    script = tmp_path / "transform.py"
    script.write_text(
        textwrap.dedent(
            """\
        from casher import cached
        from casher.auto_cli import run

        @cached(enabled=False)
        def transform(input_path: str, output_path: str, threshold: float = 0.5) -> str:
            return "done"

        if __name__ == "__main__":
            run(transform)
    """
        )
    )

    result = subprocess.run(
        [sys.executable, str(script), "--help"],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result.returncode == 0
    assert "input_path" in result.stdout
    assert "output_path" in result.stdout
    assert "--threshold" in result.stdout


@pytest.mark.timeout(30)
def test_cli_invocation(tmp_path):
    """Write a script, create input data, run it, verify output."""
    script = tmp_path / "greet.py"
    script.write_text(
        textwrap.dedent(
            """\
        from casher import cached
        from casher.auto_cli import run

        @cached(enabled=False)
        def greet(name: str, times: int = 1) -> str:
            return (name + " ") * times

        if __name__ == "__main__":
            run(greet)
    """
        )
    )

    result = subprocess.run(
        [sys.executable, str(script), "Alice", "--times", "3"],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result.returncode == 0
    assert "Alice Alice Alice" in result.stdout


@pytest.mark.timeout(30)
def test_cli_with_cache_dir(tmp_path):
    """Verify cache entries appear in specified directory when using @cached with cache_dir."""
    cache_dir = tmp_path / "my_cache"
    input_file = tmp_path / "data.txt"
    input_file.write_text("hello world")

    script = tmp_path / "reader.py"
    script.write_text(
        textwrap.dedent(
            f"""\
        from casher import cached
        from casher.auto_cli import run

        @cached(cache_dir="{cache_dir}", subprocess=False)
        def reader(input_path: str) -> str:
            with open(input_path) as f:
                return f.read().strip()

        if __name__ == "__main__":
            run(reader)
    """
        )
    )

    result = subprocess.run(
        [sys.executable, str(script), str(input_file)],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result.returncode == 0
    assert "hello world" in result.stdout
    assert cache_dir.is_dir()
    # Cache dir should have at least one entry
    entries = list(cache_dir.iterdir())
    # Filter out lock files
    entries = [e for e in entries if not e.name.startswith(".")]
    assert len(entries) > 0
