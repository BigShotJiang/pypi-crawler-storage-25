import sys

import pytest

from casher.deps import compute_dep_hash


@pytest.fixture
def clean_modules(tmp_path):
    """Save sys.path and sys.modules, restore after test."""
    orig_path = sys.path[:]
    orig_modules = set(sys.modules.keys())
    sys.path.insert(0, str(tmp_path))
    yield tmp_path
    sys.path[:] = orig_path
    # Remove any modules added during the test
    for name in list(sys.modules.keys()):
        if name not in orig_modules:
            del sys.modules[name]


@pytest.mark.timeout(10)
def test_single_module(clean_modules):
    tmp_path = clean_modules
    mod_file = tmp_path / "single_mod_test.py"
    mod_file.write_text("def my_func():\n    return 42\n")

    import single_mod_test

    hash1 = compute_dep_hash(single_mod_test.my_func, dep_roots=[tmp_path])
    hash2 = compute_dep_hash(single_mod_test.my_func, dep_roots=[tmp_path])
    assert hash1 == hash2
    assert isinstance(hash1, str)
    assert len(hash1) == 64  # sha256 hex


@pytest.mark.timeout(10)
def test_transitive_deps(clean_modules):
    tmp_path = clean_modules

    (tmp_path / "dep_c_trans.py").write_text("C_VAL = 100\n")
    (tmp_path / "dep_b_trans.py").write_text(
        "from dep_c_trans import C_VAL\nB_VAL = C_VAL + 1\n"
    )
    (tmp_path / "dep_a_trans.py").write_text(
        "from dep_b_trans import B_VAL\ndef compute():\n    return B_VAL + 1\n"
    )

    import dep_a_trans

    h = compute_dep_hash(dep_a_trans.compute, dep_roots=[tmp_path])
    assert isinstance(h, str)
    assert len(h) == 64


@pytest.mark.timeout(10)
def test_dep_change_invalidates(clean_modules):
    tmp_path = clean_modules

    c_file = tmp_path / "dep_c_change.py"
    c_file.write_text("C_VAL = 100\n")
    (tmp_path / "dep_b_change.py").write_text(
        "from dep_c_change import C_VAL\nB_VAL = C_VAL + 1\n"
    )
    (tmp_path / "dep_a_change.py").write_text(
        "from dep_b_change import B_VAL\ndef compute():\n    return B_VAL + 1\n"
    )

    import dep_a_change

    hash1 = compute_dep_hash(dep_a_change.compute, dep_roots=[tmp_path])

    # Modify the transitive dependency
    c_file.write_text("C_VAL = 999\n")
    hash2 = compute_dep_hash(dep_a_change.compute, dep_roots=[tmp_path])
    assert hash1 != hash2


@pytest.mark.timeout(10)
def test_stdlib_excluded(clean_modules):
    tmp_path = clean_modules

    (tmp_path / "uses_stdlib.py").write_text(
        "import os\nimport json\ndef my_func():\n    return os.getcwd()\n"
    )

    import uses_stdlib

    # dep_roots pointing to tmp_path — stdlib modules should be excluded
    h = compute_dep_hash(uses_stdlib.my_func, dep_roots=[tmp_path])
    assert isinstance(h, str)
    assert len(h) == 64


@pytest.mark.timeout(10)
def test_dep_roots_filtering(clean_modules):
    tmp_path = clean_modules

    dir_a = tmp_path / "pkg_a"
    dir_a.mkdir()
    (dir_a / "mod_a.py").write_text("A_VAL = 1\n")

    dir_b = tmp_path / "pkg_b"
    dir_b.mkdir()
    (dir_b / "mod_b.py").write_text("B_VAL = 2\n")

    # Create a module that imports from both
    (tmp_path / "importer_filter.py").write_text(
        "import sys\nsys.path.insert(0, r'{dir_a}')\nsys.path.insert(0, r'{dir_b}')\n".format(
            dir_a=dir_a, dir_b=dir_b
        )
        + "from mod_a import A_VAL\nfrom mod_b import B_VAL\ndef combine():\n    return A_VAL + B_VAL\n"
    )

    # Add both dirs to sys.path so imports work
    sys.path.insert(0, str(dir_a))
    sys.path.insert(0, str(dir_b))

    import importer_filter

    # Only include dir_a in dep_roots
    hash_a_only = compute_dep_hash(importer_filter.combine, dep_roots=[dir_a])

    # Modify mod_b (not in dep_roots) — hash should NOT change
    (dir_b / "mod_b.py").write_text("B_VAL = 999\n")
    hash_a_only_2 = compute_dep_hash(importer_filter.combine, dep_roots=[dir_a])
    assert hash_a_only == hash_a_only_2

    # Modify mod_a (in dep_roots) — hash SHOULD change
    (dir_a / "mod_a.py").write_text("A_VAL = 999\n")
    hash_a_only_3 = compute_dep_hash(importer_filter.combine, dep_roots=[dir_a])
    assert hash_a_only != hash_a_only_3
