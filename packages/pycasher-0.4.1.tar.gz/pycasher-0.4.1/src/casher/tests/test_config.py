import pytest

from casher.config import (
    _overrides,
    configure,
    get_config,
    resolve_cache_dir,
    resolve_max_cache_bytes,
    resolve_start_removing_pct,
    resolve_stop_caching_pct,
)


@pytest.fixture(autouse=True)
def _clean_overrides():
    _overrides.clear()
    yield
    _overrides.clear()


def test_configure_cache_dir(tmp_path):
    configure(cache_dir=tmp_path / "custom")
    assert resolve_cache_dir(None) == tmp_path / "custom"


def test_configure_creates_nested_dirs(tmp_path):
    nested = tmp_path / "a" / "b" / "c" / "cache"
    assert not nested.exists()
    configure(cache_dir=nested)
    assert nested.is_dir()


def test_configure_max_cache_bytes():
    configure(max_cache_bytes=999)
    assert resolve_max_cache_bytes(None) == 999


def test_configure_clears_on_none(tmp_path):
    configure(cache_dir=tmp_path / "some_path")
    assert resolve_cache_dir(None) == tmp_path / "some_path"
    # Calling configure without cache_dir clears the override
    configure(cache_dir=None)
    # Falls back to env or default — just check it's no longer our path
    assert resolve_cache_dir(None) != tmp_path / "some_path"


def test_explicit_arg_beats_configure(tmp_path):
    configure(cache_dir=tmp_path / "configured")
    assert resolve_cache_dir(tmp_path / "explicit") == tmp_path / "explicit"


def test_configure_beats_env_var(tmp_path, monkeypatch):
    monkeypatch.setenv("CASHER_CACHE_DIR", str(tmp_path / "env"))
    configure(cache_dir=tmp_path / "configured")
    assert resolve_cache_dir(None) == tmp_path / "configured"


def test_env_var_used_when_no_configure(tmp_path, monkeypatch):
    monkeypatch.setenv("CASHER_CACHE_DIR", str(tmp_path / "env"))
    assert resolve_cache_dir(None) == tmp_path / "env"


def test_get_config_returns_effective(tmp_path):
    configure(cache_dir=tmp_path, max_cache_bytes=42)
    cfg = get_config()
    assert cfg["cache_dir"] == tmp_path
    assert cfg["max_cache_bytes"] == 42


@pytest.mark.timeout(10)
def test_configure_used_by_decorator(tmp_path):
    """configure() before first call → decorator uses configured cache_dir."""
    configure(cache_dir=tmp_path / "cache")

    from casher import cached

    @cached(subprocess=False)
    def add(a: int, b: int) -> int:
        return a + b

    result = add(1, 2)
    assert result == 3
    assert (tmp_path / "cache").is_dir()
    entries = [e for e in (tmp_path / "cache").iterdir() if not e.name.startswith(".")]
    assert len(entries) > 0


@pytest.mark.timeout(10)
def test_stop_caching_pct_default():
    assert resolve_stop_caching_pct() == 95


@pytest.mark.timeout(10)
def test_start_removing_pct_default():
    assert resolve_start_removing_pct() == 97


@pytest.mark.timeout(10)
def test_configure_stop_caching_pct():
    configure(stop_caching_pct=80)
    assert resolve_stop_caching_pct() == 80


@pytest.mark.timeout(10)
def test_configure_start_removing_pct():
    configure(start_removing_pct=90)
    assert resolve_start_removing_pct() == 90


@pytest.mark.timeout(10)
def test_stop_caching_pct_env_var(monkeypatch):
    monkeypatch.setenv("CASHER_STOP_CACHING", "85")
    assert resolve_stop_caching_pct() == 85


@pytest.mark.timeout(10)
def test_start_removing_pct_env_var(monkeypatch):
    monkeypatch.setenv("CASHER_START_REMOVING", "92")
    assert resolve_start_removing_pct() == 92


@pytest.mark.timeout(10)
def test_get_config_includes_disk_thresholds(tmp_path):
    configure(cache_dir=tmp_path, stop_caching_pct=80, start_removing_pct=90)
    cfg = get_config()
    assert cfg["stop_caching_pct"] == 80
    assert cfg["start_removing_pct"] == 90
