import os
import shutil
import time
from unittest import mock

import pytest

from casher.config import META_FILENAME, _overrides
from casher.eviction import (
    evict_for_disk_pressure,
    evict_if_needed,
    get_cache_size,
    get_disk_usage_pct,
    get_entry_size,
    is_disk_full,
)
from casher.store import CacheEntry, store_result


def _make_entry(size_bytes: int = 100, **overrides) -> CacheEntry:
    """Create a cache entry whose serialized return value is approximately size_bytes."""
    defaults = dict(
        return_value="x" * size_bytes,
        stdout="",
        stderr="",
        output_files={},
        input_files={},
        created_at=time.time(),
        func_module="test_mod",
        func_name="test_fn",
    )
    defaults.update(overrides)
    return CacheEntry(**defaults)


def _store_entry(cache_dir, partial_key, file_hash, size_bytes=100, mtime=None):
    """Store an entry and optionally set its meta.json mtime."""
    entry = _make_entry(size_bytes=size_bytes)
    result_dir = store_result(cache_dir, partial_key, file_hash, entry, max_bytes=0)
    if mtime is not None:
        meta_path = result_dir / META_FILENAME
        os.utime(meta_path, (mtime, mtime))
    return result_dir


@pytest.mark.timeout(10)
def test_no_eviction_under_limit(tmp_path):
    cache_dir = tmp_path / "cache"
    for i in range(3):
        _store_entry(cache_dir, f"pk_{i}", f"fh_{i}", size_bytes=100)

    evicted = evict_if_needed(cache_dir, max_bytes=100000)
    assert evicted == 0
    # All entries still exist
    for i in range(3):
        assert (cache_dir / f"pk_{i}" / f"fh_{i}" / META_FILENAME).exists()


@pytest.mark.timeout(10)
def test_eviction_removes_oldest(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 300

    _store_entry(cache_dir, "pk_old", "fh_old", size_bytes=500, mtime=base_time)
    _store_entry(cache_dir, "pk_mid", "fh_mid", size_bytes=500, mtime=base_time + 100)
    _store_entry(cache_dir, "pk_new", "fh_new", size_bytes=500, mtime=base_time + 200)

    total = get_cache_size(cache_dir)
    # Set limit so only ~2 entries fit
    limit = total - 100

    evicted = evict_if_needed(cache_dir, max_bytes=limit)
    assert evicted >= 1
    # Oldest should be gone
    assert not (cache_dir / "pk_old" / "fh_old").exists()
    # Newest should survive
    assert (cache_dir / "pk_new" / "fh_new" / META_FILENAME).exists()


@pytest.mark.timeout(10)
def test_eviction_removes_multiple(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 500

    for i in range(5):
        _store_entry(
            cache_dir, f"pk_{i}", f"fh_{i}", size_bytes=500, mtime=base_time + i * 100
        )

    # Set limit so only ~2 entries fit
    single_size = get_entry_size(cache_dir / "pk_0" / "fh_0")
    limit = single_size * 2 + 50

    evicted = evict_if_needed(cache_dir, max_bytes=limit)
    assert evicted == 3
    # Oldest 3 gone
    for i in range(3):
        assert not (cache_dir / f"pk_{i}" / f"fh_{i}").exists()
    # Newest 2 survive
    for i in range(3, 5):
        assert (cache_dir / f"pk_{i}" / f"fh_{i}" / META_FILENAME).exists()


@pytest.mark.timeout(10)
def test_eviction_unlimited(tmp_path):
    cache_dir = tmp_path / "cache"
    for i in range(3):
        _store_entry(cache_dir, f"pk_{i}", f"fh_{i}", size_bytes=1000)

    evicted = evict_if_needed(cache_dir, max_bytes=0)
    assert evicted == 0


@pytest.mark.timeout(10)
def test_get_cache_size(tmp_path):
    cache_dir = tmp_path / "cache"
    _store_entry(cache_dir, "pk_a", "fh_a", size_bytes=200)
    _store_entry(cache_dir, "pk_b", "fh_b", size_bytes=300)

    total = get_cache_size(cache_dir)
    assert total > 0

    size_a = get_entry_size(cache_dir / "pk_a" / "fh_a")
    size_b = get_entry_size(cache_dir / "pk_b" / "fh_b")
    assert total == size_a + size_b


@pytest.mark.timeout(10)
def test_empty_partial_key_dir_cleaned(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 100

    _store_entry(cache_dir, "pk_solo", "fh_solo", size_bytes=500, mtime=base_time)

    single_size = get_entry_size(cache_dir / "pk_solo" / "fh_solo")
    # Evict with limit smaller than entry
    evicted = evict_if_needed(cache_dir, max_bytes=single_size - 1)
    assert evicted == 1
    assert not (cache_dir / "pk_solo").exists()


@pytest.mark.timeout(10)
def test_eviction_triggered_by_store(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 200

    # Store an initial entry
    _store_entry(cache_dir, "pk_old", "fh_old", size_bytes=500, mtime=base_time)
    old_size = get_entry_size(cache_dir / "pk_old" / "fh_old")

    # Store a new entry with max_bytes small enough that old entry must be evicted
    entry = _make_entry(size_bytes=500)
    store_result(cache_dir, "pk_new", "fh_new", entry, max_bytes=old_size + 100)

    # Old entry should be evicted
    assert not (cache_dir / "pk_old" / "fh_old").exists()
    # New entry should exist
    assert (cache_dir / "pk_new" / "fh_new" / META_FILENAME).exists()


# --- Disk space tests ---


@pytest.fixture(autouse=True)
def _clean_overrides():
    _overrides.clear()
    yield
    _overrides.clear()


@pytest.mark.timeout(10)
def test_get_disk_usage_pct(tmp_path):
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    pct = get_disk_usage_pct(cache_dir)
    assert 0 < pct < 100


def _fake_disk_usage(pct):
    """Return a shutil.disk_usage result tuple faking the given percentage."""
    total = 100 * 1024 * 1024 * 1024  # 100 GB
    used = int(total * pct / 100)
    free = total - used
    return shutil._ntuple_diskusage(total, used, free)


@pytest.mark.timeout(10)
def test_is_disk_full_below_threshold(tmp_path):
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    with mock.patch(
        "casher.eviction.shutil.disk_usage", return_value=_fake_disk_usage(90)
    ):
        assert not is_disk_full(cache_dir)


@pytest.mark.timeout(10)
def test_is_disk_full_above_threshold(tmp_path):
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    with mock.patch(
        "casher.eviction.shutil.disk_usage", return_value=_fake_disk_usage(96)
    ):
        assert is_disk_full(cache_dir)


@pytest.mark.timeout(10)
def test_is_disk_full_custom_threshold(tmp_path):
    from casher.config import configure

    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    configure(stop_caching_pct=80)
    with mock.patch(
        "casher.eviction.shutil.disk_usage", return_value=_fake_disk_usage(85)
    ):
        assert is_disk_full(cache_dir)


@pytest.mark.timeout(10)
def test_is_disk_full_env_var(tmp_path, monkeypatch):
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    monkeypatch.setenv("CASHER_STOP_CACHING", "80")
    with mock.patch(
        "casher.eviction.shutil.disk_usage", return_value=_fake_disk_usage(85)
    ):
        assert is_disk_full(cache_dir)


@pytest.mark.timeout(10)
def test_evict_for_disk_pressure_no_action_below_threshold(tmp_path):
    cache_dir = tmp_path / "cache"
    _store_entry(cache_dir, "pk_0", "fh_0", size_bytes=100)
    with mock.patch(
        "casher.eviction.shutil.disk_usage", return_value=_fake_disk_usage(90)
    ):
        evicted = evict_for_disk_pressure(cache_dir)
    assert evicted == 0
    assert (cache_dir / "pk_0" / "fh_0" / META_FILENAME).exists()


@pytest.mark.timeout(10)
def test_evict_for_disk_pressure_removes_entries(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 300
    for i in range(3):
        _store_entry(
            cache_dir, f"pk_{i}", f"fh_{i}", size_bytes=100, mtime=base_time + i * 100
        )

    call_count = 0

    def _usage_shrinking(path):
        nonlocal call_count
        call_count += 1
        # First call: 98% (triggers eviction), subsequent calls drop
        if call_count <= 2:
            return _fake_disk_usage(98)
        return _fake_disk_usage(90)

    with mock.patch("casher.eviction.shutil.disk_usage", side_effect=_usage_shrinking):
        evicted = evict_for_disk_pressure(cache_dir)

    assert evicted >= 1
    # Oldest should be gone
    assert not (cache_dir / "pk_0" / "fh_0").exists()


@pytest.mark.timeout(10)
def test_store_result_skips_when_disk_full(tmp_path):
    cache_dir = tmp_path / "cache"
    entry = _make_entry(size_bytes=100)

    with mock.patch(
        "casher.eviction.shutil.disk_usage", return_value=_fake_disk_usage(96)
    ):
        store_result(cache_dir, "pk_skip", "fh_skip", entry, max_bytes=0)

    # Entry should NOT be written
    assert not (cache_dir / "pk_skip" / "fh_skip" / META_FILENAME).exists()
