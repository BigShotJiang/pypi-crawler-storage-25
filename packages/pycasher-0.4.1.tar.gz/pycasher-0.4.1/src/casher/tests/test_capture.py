import time

import pytest

from casher.capture import replay_side_effects
from casher.config import OUTPUT_FILES_DIR
from casher.store import CacheEntry


def _make_entry(**overrides) -> CacheEntry:
    defaults = dict(
        return_value=None,
        stdout="",
        stderr="",
        output_files={},
        input_files={},
        created_at=time.time(),
        func_module="test_mod",
        func_name="test_fn",
    )
    defaults.update(overrides)
    return CacheEntry(**defaults)


@pytest.mark.timeout(10)
def test_replay_stdout(tmp_path, capsys):
    entry = _make_entry(stdout="hello from cache\n")
    entry_dir = tmp_path / "entry"
    entry_dir.mkdir()

    replay_side_effects(entry, entry_dir)

    captured = capsys.readouterr()
    assert captured.out == "hello from cache\n"


@pytest.mark.timeout(10)
def test_replay_stderr(tmp_path, capsys):
    entry = _make_entry(stderr="warning from cache\n")
    entry_dir = tmp_path / "entry"
    entry_dir.mkdir()

    replay_side_effects(entry, entry_dir)

    captured = capsys.readouterr()
    assert captured.err == "warning from cache\n"


@pytest.mark.timeout(10)
def test_replay_output_files(tmp_path):
    entry_dir = tmp_path / "entry"
    output_dir = entry_dir / OUTPUT_FILES_DIR
    output_dir.mkdir(parents=True)

    # Create cached output file
    target_path = tmp_path / "restored" / "output.txt"
    rel_path = str(target_path)
    cached_file = output_dir / rel_path
    cached_file.parent.mkdir(parents=True, exist_ok=True)
    cached_file.write_text("cached output content")

    entry = _make_entry(output_files={rel_path: cached_file})

    replay_side_effects(entry, entry_dir)

    assert target_path.exists()
    assert target_path.read_text() == "cached output content"


@pytest.mark.timeout(10)
def test_replay_creates_parent_dirs(tmp_path):
    entry_dir = tmp_path / "entry"
    output_dir = entry_dir / OUTPUT_FILES_DIR
    output_dir.mkdir(parents=True)

    target_path = tmp_path / "deep" / "sub" / "dir" / "file.txt"
    rel_path = str(target_path)
    cached_file = output_dir / rel_path
    cached_file.parent.mkdir(parents=True, exist_ok=True)
    cached_file.write_text("nested content")

    entry = _make_entry(output_files={rel_path: cached_file})

    replay_side_effects(entry, entry_dir)

    assert target_path.exists()
    assert target_path.read_text() == "nested content"
    assert target_path.parent.is_dir()
