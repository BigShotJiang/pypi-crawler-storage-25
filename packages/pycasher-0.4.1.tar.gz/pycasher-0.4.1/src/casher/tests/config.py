# Test-only configuration for casher tests
# Tests must NOT depend on production config values

TEST_TIMEOUT = 10
TEST_FUNC_MODULE = "test_module"
TEST_FUNC_NAME = "test_function"
TEST_DEP_HASH = "abc123"
TEST_ARGS_HASH = "def456"
TEST_FILE_HASH = "file789"
TEST_MAX_CACHE_BYTES = 10000
