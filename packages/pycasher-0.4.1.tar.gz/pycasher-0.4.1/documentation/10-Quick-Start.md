# Quick Start

## Installation

```bash
pip install pycasher
# Optional DataFrame support:
pip install pycasher[polars]
```

## Decorator usage

```python
from casher import cached

@cached
def transform(input_path: str, output_path: str, threshold: float = 0.5) -> int:
    import polars as pl
    df = pl.read_csv(input_path)
    df = df.filter(pl.col("score") > threshold)
    df.write_parquet(output_path)
    return len(df)

# First call — runs the function, caches result + side effects
result = transform("data.csv", "output.parquet", threshold=0.3)

# Second call — cache hit, restores output.parquet from cache
result = transform("data.csv", "output.parquet", threshold=0.3)
```

## Decorator options

```python
@cached(
    cache_dir="~/.cache/casher",     # default cache location
    subprocess=True,                  # True=strace (default), False=audit hooks
    enabled=True,                     # set False to bypass caching
    dep_roots=None,                   # directories to scan for dependency changes
    input_files=None,                 # extra files to include in cache key
    ignore_files=None,                # glob patterns to exclude from tracking
    env_vars=None,                    # environment variables to include in cache key
    max_cache_bytes=0,                # 0=unlimited, default 32 GB via env var
)
```

## In-process mode

When strace is unavailable or overhead matters, use audit hooks:

```python
@cached(subprocess=False)
def process(path: str) -> str:
    with open(path) as f:
        return f.read().upper()
```

File I/O is tracked via `sys.addaudithook`. No subprocess is spawned.

## CLI caching with acache

Cache any shell command:

```bash
# First run — traces file I/O, caches result
acache -- python train.py --data train.csv

# Second run — cache hit if train.csv unchanged
acache -- python train.py --data train.csv

# Custom cache directory
acache --cache-dir /tmp/mycache -- python train.py --data train.csv
```

## Auto-CLI from decorated functions

```python
# transform.py
from casher import cached
from casher.auto_cli import run

@cached
def transform(input_path: str, output_path: str, threshold: float = 0.5) -> int:
    ...

if __name__ == "__main__":
    run(transform)
```

```bash
python transform.py data.csv output.parquet --threshold 0.3
```

## Running tests

```bash
cd casher
./test.sh
```
