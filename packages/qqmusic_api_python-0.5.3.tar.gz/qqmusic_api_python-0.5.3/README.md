<div align="center">
    <a>
        <img src="https://socialify.git.ci/L-1124/QQMusicApi/image?font=JetBrains+Mono&language=1&name=1&pattern=Transparent&theme=Auto&logo=https%3A%2F%2Fraw.githubusercontent.com%2FL-1124%2FQQMusicApi%2Frefs%2Fheads%2Fmain%2Fassets%2Fqq-music.svg" alt="QQMusicApi" width="640" height="320" />
    </a>
    <br/>
    <a href="https://www.python.org">
        <img src="https://img.shields.io/badge/Python-3.10|3.11|3.12|3.13|3.14-blue" alt="Python">
    </a>
    <a href="https://github.com/l-1124/QQMusicApi/blob/main/LICENSE">
        <img src="https://img.shields.io/github/license/l-1124/QQMusicApi" alt="GitHub license">
    </a>
    <a href="https://github.com/l-1124/QQMusicApi/stargazers">
        <img src="https://img.shields.io/github/stars/l-1124/QQMusicApi?color=yellow&label=Github%20Stars" alt="STARS">
    </a>
    <a href="https://github.com/l-1124/QQMusicApi/actions/workflows/testing.yml">
        <img src="https://github.com/l-1124/QQMusicApi/actions/workflows/testing.yml/badge.svg?branch=main" alt="Testing">
    </a>
</div>

---

> [!IMPORTANT]
> **音乐平台不易, 请尊重版权, 支持正版**。

---

## 📚 快速链接

* **[📖 完整文档](https://l-1124.github.io/QQMusicApi)**

## 📖 介绍

使用 Python 编写的用于调用 [QQ音乐](https://y.qq.com/) 各种 API 的库。

## ✨ 项目特色

* 🎵 涵盖常见 API
* 🚀 调用简便，函数命名易懂，代码注释详细
* ⚡ 完全异步操作

## 📄 许可证

本项目当前采用 **[GNU General Public License v3.0 or later](https://github.com/l-1124/QQMusicApi/blob/main/LICENSE)**。

本项目仅用于对技术可行性的探索及研究，请勿将其用于任何商业用途或侵犯版权的行为。

## ⚠️ 免责声明

由于使用本项目产生的包括由于本协议或由于使用或无法使用本项目而引起的任何性质的任何直接、间接、特殊、偶然或结果性损害（包括但不限于因商誉损失、停工、计算机故障或故障引起的损害赔偿，或任何及所有其他商业损害或损失）由使用者负责。

## 👥 贡献者

[![Contributor](https://contrib.rocks/image?repo=l-1124/QQMusicApi)](https://github.com/l-1124/QQMusicApi/graphs/contributors)
