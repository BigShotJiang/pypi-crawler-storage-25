# LyricApi

::: modules.lyric.LyricApi
