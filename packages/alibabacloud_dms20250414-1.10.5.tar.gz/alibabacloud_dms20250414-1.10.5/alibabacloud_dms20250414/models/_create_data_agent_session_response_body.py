# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_dms20250414 import models as main_models
from darabonba.model import DaraModel

class CreateDataAgentSessionResponseBody(DaraModel):
    def __init__(
        self,
        data: main_models.CreateDataAgentSessionResponseBodyData = None,
        error_code: str = None,
        error_message: str = None,
        request_id: str = None,
        success: bool = None,
    ):
        self.data = data
        self.error_code = error_code
        self.error_message = error_message
        # Id of the request
        self.request_id = request_id
        self.success = success

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.data is not None:
            result['Data'] = self.data.to_map()

        if self.error_code is not None:
            result['ErrorCode'] = self.error_code

        if self.error_message is not None:
            result['ErrorMessage'] = self.error_message

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.success is not None:
            result['Success'] = self.success

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Data') is not None:
            temp_model = main_models.CreateDataAgentSessionResponseBodyData()
            self.data = temp_model.from_map(m.get('Data'))

        if m.get('ErrorCode') is not None:
            self.error_code = m.get('ErrorCode')

        if m.get('ErrorMessage') is not None:
            self.error_message = m.get('ErrorMessage')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('Success') is not None:
            self.success = m.get('Success')

        return self

class CreateDataAgentSessionResponseBodyData(DaraModel):
    def __init__(
        self,
        agent_id: str = None,
        agent_status: str = None,
        create_time: int = None,
        file: str = None,
        saved: bool = None,
        session_config: main_models.CreateDataAgentSessionResponseBodyDataSessionConfig = None,
        session_id: str = None,
        session_status: str = None,
        title: str = None,
    ):
        # Agent Id
        self.agent_id = agent_id
        self.agent_status = agent_status
        self.create_time = create_time
        self.file = file
        self.saved = saved
        self.session_config = session_config
        self.session_id = session_id
        self.session_status = session_status
        self.title = title

    def validate(self):
        if self.session_config:
            self.session_config.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.agent_id is not None:
            result['AgentId'] = self.agent_id

        if self.agent_status is not None:
            result['AgentStatus'] = self.agent_status

        if self.create_time is not None:
            result['CreateTime'] = self.create_time

        if self.file is not None:
            result['File'] = self.file

        if self.saved is not None:
            result['Saved'] = self.saved

        if self.session_config is not None:
            result['SessionConfig'] = self.session_config.to_map()

        if self.session_id is not None:
            result['SessionId'] = self.session_id

        if self.session_status is not None:
            result['SessionStatus'] = self.session_status

        if self.title is not None:
            result['Title'] = self.title

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AgentId') is not None:
            self.agent_id = m.get('AgentId')

        if m.get('AgentStatus') is not None:
            self.agent_status = m.get('AgentStatus')

        if m.get('CreateTime') is not None:
            self.create_time = m.get('CreateTime')

        if m.get('File') is not None:
            self.file = m.get('File')

        if m.get('Saved') is not None:
            self.saved = m.get('Saved')

        if m.get('SessionConfig') is not None:
            temp_model = main_models.CreateDataAgentSessionResponseBodyDataSessionConfig()
            self.session_config = temp_model.from_map(m.get('SessionConfig'))

        if m.get('SessionId') is not None:
            self.session_id = m.get('SessionId')

        if m.get('SessionStatus') is not None:
            self.session_status = m.get('SessionStatus')

        if m.get('Title') is not None:
            self.title = m.get('Title')

        return self

class CreateDataAgentSessionResponseBodyDataSessionConfig(DaraModel):
    def __init__(
        self,
        custom_agent_id: str = None,
        custom_agent_stage: str = None,
        enable_search: bool = None,
        encrypt_key: str = None,
        encrypt_type: str = None,
        kb_uuid_list: List[str] = None,
        language: str = None,
        mcp_server_ids: List[str] = None,
        mode: str = None,
        report_page_width: int = None,
        report_water_mark: str = None,
        user_oss_bucket: str = None,
    ):
        self.custom_agent_id = custom_agent_id
        self.custom_agent_stage = custom_agent_stage
        self.enable_search = enable_search
        self.encrypt_key = encrypt_key
        self.encrypt_type = encrypt_type
        self.kb_uuid_list = kb_uuid_list
        self.language = language
        self.mcp_server_ids = mcp_server_ids
        self.mode = mode
        self.report_page_width = report_page_width
        self.report_water_mark = report_water_mark
        self.user_oss_bucket = user_oss_bucket

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.custom_agent_id is not None:
            result['CustomAgentId'] = self.custom_agent_id

        if self.custom_agent_stage is not None:
            result['CustomAgentStage'] = self.custom_agent_stage

        if self.enable_search is not None:
            result['EnableSearch'] = self.enable_search

        if self.encrypt_key is not None:
            result['EncryptKey'] = self.encrypt_key

        if self.encrypt_type is not None:
            result['EncryptType'] = self.encrypt_type

        if self.kb_uuid_list is not None:
            result['KbUuidList'] = self.kb_uuid_list

        if self.language is not None:
            result['Language'] = self.language

        if self.mcp_server_ids is not None:
            result['McpServerIds'] = self.mcp_server_ids

        if self.mode is not None:
            result['Mode'] = self.mode

        if self.report_page_width is not None:
            result['ReportPageWidth'] = self.report_page_width

        if self.report_water_mark is not None:
            result['ReportWaterMark'] = self.report_water_mark

        if self.user_oss_bucket is not None:
            result['UserOssBucket'] = self.user_oss_bucket

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CustomAgentId') is not None:
            self.custom_agent_id = m.get('CustomAgentId')

        if m.get('CustomAgentStage') is not None:
            self.custom_agent_stage = m.get('CustomAgentStage')

        if m.get('EnableSearch') is not None:
            self.enable_search = m.get('EnableSearch')

        if m.get('EncryptKey') is not None:
            self.encrypt_key = m.get('EncryptKey')

        if m.get('EncryptType') is not None:
            self.encrypt_type = m.get('EncryptType')

        if m.get('KbUuidList') is not None:
            self.kb_uuid_list = m.get('KbUuidList')

        if m.get('Language') is not None:
            self.language = m.get('Language')

        if m.get('McpServerIds') is not None:
            self.mcp_server_ids = m.get('McpServerIds')

        if m.get('Mode') is not None:
            self.mode = m.get('Mode')

        if m.get('ReportPageWidth') is not None:
            self.report_page_width = m.get('ReportPageWidth')

        if m.get('ReportWaterMark') is not None:
            self.report_water_mark = m.get('ReportWaterMark')

        if m.get('UserOssBucket') is not None:
            self.user_oss_bucket = m.get('UserOssBucket')

        return self

