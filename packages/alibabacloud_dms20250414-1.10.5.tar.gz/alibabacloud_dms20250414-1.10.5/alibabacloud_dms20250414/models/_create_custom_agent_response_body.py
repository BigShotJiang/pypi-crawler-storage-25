# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_dms20250414 import models as main_models
from darabonba.model import DaraModel

class CreateCustomAgentResponseBody(DaraModel):
    def __init__(
        self,
        data: main_models.CreateCustomAgentResponseBodyData = None,
        error_code: str = None,
        error_message: str = None,
        request_id: str = None,
        success: bool = None,
    ):
        self.data = data
        self.error_code = error_code
        self.error_message = error_message
        # Id of the request
        self.request_id = request_id
        self.success = success

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.data is not None:
            result['Data'] = self.data.to_map()

        if self.error_code is not None:
            result['ErrorCode'] = self.error_code

        if self.error_message is not None:
            result['ErrorMessage'] = self.error_message

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.success is not None:
            result['Success'] = self.success

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Data') is not None:
            temp_model = main_models.CreateCustomAgentResponseBodyData()
            self.data = temp_model.from_map(m.get('Data'))

        if m.get('ErrorCode') is not None:
            self.error_code = m.get('ErrorCode')

        if m.get('ErrorMessage') is not None:
            self.error_message = m.get('ErrorMessage')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('Success') is not None:
            self.success = m.get('Success')

        return self

class CreateCustomAgentResponseBodyData(DaraModel):
    def __init__(
        self,
        aliyun_parent_uid: str = None,
        aliyun_uid: str = None,
        callback_config: main_models.CreateCustomAgentResponseBodyDataCallbackConfig = None,
        creator_user_name: str = None,
        custom_agent_id: str = None,
        dmsunit: str = None,
        data_json: str = None,
        description: str = None,
        dms_unit: str = None,
        execution_config: main_models.CreateCustomAgentResponseBodyDataExecutionConfig = None,
        gmt_created: str = None,
        gmt_modified: str = None,
        instruction: str = None,
        is_schedule_task: bool = None,
        knowledge: str = None,
        knowledge_config_list: List[main_models.CreateCustomAgentResponseBodyDataKnowledgeConfigList] = None,
        modifier: str = None,
        modifier_user_name: str = None,
        name: str = None,
        next_runtime: int = None,
        offline_time: str = None,
        region: str = None,
        release_time: str = None,
        schedule_task_config: main_models.CreateCustomAgentResponseBodyDataScheduleTaskConfig = None,
        status: str = None,
        text_report_config: str = None,
        web_report_config: str = None,
        workspace_id: str = None,
    ):
        self.aliyun_parent_uid = aliyun_parent_uid
        self.aliyun_uid = aliyun_uid
        self.callback_config = callback_config
        self.creator_user_name = creator_user_name
        self.custom_agent_id = custom_agent_id
        self.dmsunit = dmsunit
        self.data_json = data_json
        self.description = description
        self.dms_unit = dms_unit
        self.execution_config = execution_config
        self.gmt_created = gmt_created
        self.gmt_modified = gmt_modified
        self.instruction = instruction
        self.is_schedule_task = is_schedule_task
        self.knowledge = knowledge
        self.knowledge_config_list = knowledge_config_list
        self.modifier = modifier
        self.modifier_user_name = modifier_user_name
        self.name = name
        self.next_runtime = next_runtime
        self.offline_time = offline_time
        self.region = region
        self.release_time = release_time
        self.schedule_task_config = schedule_task_config
        self.status = status
        self.text_report_config = text_report_config
        self.web_report_config = web_report_config
        self.workspace_id = workspace_id

    def validate(self):
        if self.callback_config:
            self.callback_config.validate()
        if self.execution_config:
            self.execution_config.validate()
        if self.knowledge_config_list:
            for v1 in self.knowledge_config_list:
                 if v1:
                    v1.validate()
        if self.schedule_task_config:
            self.schedule_task_config.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.aliyun_parent_uid is not None:
            result['AliyunParentUid'] = self.aliyun_parent_uid

        if self.aliyun_uid is not None:
            result['AliyunUid'] = self.aliyun_uid

        if self.callback_config is not None:
            result['CallbackConfig'] = self.callback_config.to_map()

        if self.creator_user_name is not None:
            result['CreatorUserName'] = self.creator_user_name

        if self.custom_agent_id is not None:
            result['CustomAgentId'] = self.custom_agent_id

        if self.dmsunit is not None:
            result['DMSUnit'] = self.dmsunit

        if self.data_json is not None:
            result['DataJson'] = self.data_json

        if self.description is not None:
            result['Description'] = self.description

        if self.dms_unit is not None:
            result['DmsUnit'] = self.dms_unit

        if self.execution_config is not None:
            result['ExecutionConfig'] = self.execution_config.to_map()

        if self.gmt_created is not None:
            result['GmtCreated'] = self.gmt_created

        if self.gmt_modified is not None:
            result['GmtModified'] = self.gmt_modified

        if self.instruction is not None:
            result['Instruction'] = self.instruction

        if self.is_schedule_task is not None:
            result['IsScheduleTask'] = self.is_schedule_task

        if self.knowledge is not None:
            result['Knowledge'] = self.knowledge

        result['KnowledgeConfigList'] = []
        if self.knowledge_config_list is not None:
            for k1 in self.knowledge_config_list:
                result['KnowledgeConfigList'].append(k1.to_map() if k1 else None)

        if self.modifier is not None:
            result['Modifier'] = self.modifier

        if self.modifier_user_name is not None:
            result['ModifierUserName'] = self.modifier_user_name

        if self.name is not None:
            result['Name'] = self.name

        if self.next_runtime is not None:
            result['NextRuntime'] = self.next_runtime

        if self.offline_time is not None:
            result['OfflineTime'] = self.offline_time

        if self.region is not None:
            result['Region'] = self.region

        if self.release_time is not None:
            result['ReleaseTime'] = self.release_time

        if self.schedule_task_config is not None:
            result['ScheduleTaskConfig'] = self.schedule_task_config.to_map()

        if self.status is not None:
            result['Status'] = self.status

        if self.text_report_config is not None:
            result['TextReportConfig'] = self.text_report_config

        if self.web_report_config is not None:
            result['WebReportConfig'] = self.web_report_config

        if self.workspace_id is not None:
            result['WorkspaceId'] = self.workspace_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AliyunParentUid') is not None:
            self.aliyun_parent_uid = m.get('AliyunParentUid')

        if m.get('AliyunUid') is not None:
            self.aliyun_uid = m.get('AliyunUid')

        if m.get('CallbackConfig') is not None:
            temp_model = main_models.CreateCustomAgentResponseBodyDataCallbackConfig()
            self.callback_config = temp_model.from_map(m.get('CallbackConfig'))

        if m.get('CreatorUserName') is not None:
            self.creator_user_name = m.get('CreatorUserName')

        if m.get('CustomAgentId') is not None:
            self.custom_agent_id = m.get('CustomAgentId')

        if m.get('DMSUnit') is not None:
            self.dmsunit = m.get('DMSUnit')

        if m.get('DataJson') is not None:
            self.data_json = m.get('DataJson')

        if m.get('Description') is not None:
            self.description = m.get('Description')

        if m.get('DmsUnit') is not None:
            self.dms_unit = m.get('DmsUnit')

        if m.get('ExecutionConfig') is not None:
            temp_model = main_models.CreateCustomAgentResponseBodyDataExecutionConfig()
            self.execution_config = temp_model.from_map(m.get('ExecutionConfig'))

        if m.get('GmtCreated') is not None:
            self.gmt_created = m.get('GmtCreated')

        if m.get('GmtModified') is not None:
            self.gmt_modified = m.get('GmtModified')

        if m.get('Instruction') is not None:
            self.instruction = m.get('Instruction')

        if m.get('IsScheduleTask') is not None:
            self.is_schedule_task = m.get('IsScheduleTask')

        if m.get('Knowledge') is not None:
            self.knowledge = m.get('Knowledge')

        self.knowledge_config_list = []
        if m.get('KnowledgeConfigList') is not None:
            for k1 in m.get('KnowledgeConfigList'):
                temp_model = main_models.CreateCustomAgentResponseBodyDataKnowledgeConfigList()
                self.knowledge_config_list.append(temp_model.from_map(k1))

        if m.get('Modifier') is not None:
            self.modifier = m.get('Modifier')

        if m.get('ModifierUserName') is not None:
            self.modifier_user_name = m.get('ModifierUserName')

        if m.get('Name') is not None:
            self.name = m.get('Name')

        if m.get('NextRuntime') is not None:
            self.next_runtime = m.get('NextRuntime')

        if m.get('OfflineTime') is not None:
            self.offline_time = m.get('OfflineTime')

        if m.get('Region') is not None:
            self.region = m.get('Region')

        if m.get('ReleaseTime') is not None:
            self.release_time = m.get('ReleaseTime')

        if m.get('ScheduleTaskConfig') is not None:
            temp_model = main_models.CreateCustomAgentResponseBodyDataScheduleTaskConfig()
            self.schedule_task_config = temp_model.from_map(m.get('ScheduleTaskConfig'))

        if m.get('Status') is not None:
            self.status = m.get('Status')

        if m.get('TextReportConfig') is not None:
            self.text_report_config = m.get('TextReportConfig')

        if m.get('WebReportConfig') is not None:
            self.web_report_config = m.get('WebReportConfig')

        if m.get('WorkspaceId') is not None:
            self.workspace_id = m.get('WorkspaceId')

        return self

class CreateCustomAgentResponseBodyDataScheduleTaskConfig(DaraModel):
    def __init__(
        self,
        cron_expression: str = None,
        query: str = None,
        related_session_id: str = None,
    ):
        self.cron_expression = cron_expression
        self.query = query
        self.related_session_id = related_session_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.cron_expression is not None:
            result['CronExpression'] = self.cron_expression

        if self.query is not None:
            result['Query'] = self.query

        if self.related_session_id is not None:
            result['RelatedSessionId'] = self.related_session_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CronExpression') is not None:
            self.cron_expression = m.get('CronExpression')

        if m.get('Query') is not None:
            self.query = m.get('Query')

        if m.get('RelatedSessionId') is not None:
            self.related_session_id = m.get('RelatedSessionId')

        return self

class CreateCustomAgentResponseBodyDataKnowledgeConfigList(DaraModel):
    def __init__(
        self,
        access_type: str = None,
        kb_uuid: str = None,
        mcp_server_id: str = None,
    ):
        self.access_type = access_type
        self.kb_uuid = kb_uuid
        self.mcp_server_id = mcp_server_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.access_type is not None:
            result['AccessType'] = self.access_type

        if self.kb_uuid is not None:
            result['KbUuid'] = self.kb_uuid

        if self.mcp_server_id is not None:
            result['McpServerId'] = self.mcp_server_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AccessType') is not None:
            self.access_type = m.get('AccessType')

        if m.get('KbUuid') is not None:
            self.kb_uuid = m.get('KbUuid')

        if m.get('McpServerId') is not None:
            self.mcp_server_id = m.get('McpServerId')

        return self

class CreateCustomAgentResponseBodyDataExecutionConfig(DaraModel):
    def __init__(
        self,
        skip_ask_human: bool = None,
        skip_plan: bool = None,
        skip_sql_confirm: bool = None,
        skip_web_report_confirm: bool = None,
    ):
        self.skip_ask_human = skip_ask_human
        self.skip_plan = skip_plan
        self.skip_sql_confirm = skip_sql_confirm
        self.skip_web_report_confirm = skip_web_report_confirm

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.skip_ask_human is not None:
            result['SkipAskHuman'] = self.skip_ask_human

        if self.skip_plan is not None:
            result['SkipPlan'] = self.skip_plan

        if self.skip_sql_confirm is not None:
            result['SkipSqlConfirm'] = self.skip_sql_confirm

        if self.skip_web_report_confirm is not None:
            result['SkipWebReportConfirm'] = self.skip_web_report_confirm

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SkipAskHuman') is not None:
            self.skip_ask_human = m.get('SkipAskHuman')

        if m.get('SkipPlan') is not None:
            self.skip_plan = m.get('SkipPlan')

        if m.get('SkipSqlConfirm') is not None:
            self.skip_sql_confirm = m.get('SkipSqlConfirm')

        if m.get('SkipWebReportConfirm') is not None:
            self.skip_web_report_confirm = m.get('SkipWebReportConfirm')

        return self

class CreateCustomAgentResponseBodyDataCallbackConfig(DaraModel):
    def __init__(
        self,
        callback_args: str = None,
        callback_prompt: str = None,
        callback_time: int = None,
        tool_id: str = None,
        type: str = None,
    ):
        self.callback_args = callback_args
        self.callback_prompt = callback_prompt
        self.callback_time = callback_time
        self.tool_id = tool_id
        self.type = type

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.callback_args is not None:
            result['CallbackArgs'] = self.callback_args

        if self.callback_prompt is not None:
            result['CallbackPrompt'] = self.callback_prompt

        if self.callback_time is not None:
            result['CallbackTime'] = self.callback_time

        if self.tool_id is not None:
            result['ToolId'] = self.tool_id

        if self.type is not None:
            result['Type'] = self.type

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CallbackArgs') is not None:
            self.callback_args = m.get('CallbackArgs')

        if m.get('CallbackPrompt') is not None:
            self.callback_prompt = m.get('CallbackPrompt')

        if m.get('CallbackTime') is not None:
            self.callback_time = m.get('CallbackTime')

        if m.get('ToolId') is not None:
            self.tool_id = m.get('ToolId')

        if m.get('Type') is not None:
            self.type = m.get('Type')

        return self

