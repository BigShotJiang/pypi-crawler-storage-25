"""
Hybrid Memory Search Engine -- Biological Memory Model.

Combines vector similarity (ChromaDB) with keyword matching (BM25-style)
and applies a biologically-inspired scoring pipeline:

    1. Temporal decay (Ebbinghaus forgetting curve)
    2. Evergreen exemptions (consolidated long-term memory)
    3. Salience weighting (amygdala tagging -- important files decay slower)
    4. Retrieval strengthening (spaced repetition -- accessed files get boosted)
    5. Consolidation bonus (files referenced in periodic notes are "consolidated")

Can be used as a library or run directly:
    python -m claude_memory.search "your query"
"""

import os
import re
import math
import json
import datetime
import chromadb

from .config import get_config


def safe_print(text):
    """Console-safe print that handles CP1252 encoding on Windows."""
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode("cp1252", errors="replace").decode("cp1252"))


# ============================================================
# Mechanism 2: Evergreen Detection (Long-term Memory)
# ============================================================

def is_evergreen(filepath, patterns):
    """Check if a file matches any evergreen pattern (exempt from decay)."""
    if not filepath:
        return True
    fp = filepath.replace("\\", "/").lower()
    for pattern in patterns:
        if pattern.lower() in fp:
            return True
    return False


# ============================================================
# Mechanism 3: Salience Scoring (Amygdala Tagging)
# ============================================================

def get_salience(filepath, salience_patterns):
    """Get salience multiplier for a file.

    Higher salience = decays slower. A file with salience 3.0 that is
    30 days old decays as if 10 days old.
    """
    if not filepath or not salience_patterns:
        return 1.0
    fp = filepath.replace("\\", "/").lower()
    for pattern, salience in salience_patterns.items():
        if pattern.lower() in fp:
            return salience
    return 1.0


# ============================================================
# Mechanism 4: Retrieval Strengthening (Spaced Repetition)
# ============================================================

def _access_log_path(config):
    """Path to the retrieval access log."""
    return os.path.join(config.get("data_dir", ""), "access_log.json")


def load_access_log(config):
    """Load the access frequency log."""
    path = _access_log_path(config)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def save_access_log(log, config):
    """Save the access frequency log."""
    path = _access_log_path(config)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)


def record_access(filepath, config):
    """Record that a file was accessed (retrieved in search results)."""
    log = load_access_log(config)
    fp = filepath.replace("\\", "/")
    if fp not in log:
        log[fp] = []
    log[fp].append(datetime.datetime.now().isoformat())
    cutoff = (datetime.datetime.now() - datetime.timedelta(days=30)).isoformat()
    log[fp] = [ts for ts in log[fp] if ts > cutoff]
    save_access_log(log, config)


def get_retrieval_boost(filepath, config):
    """Calculate retrieval strengthening boost.

    Each access within the retrieval window adds a boost, capped at max.
    """
    retrieval_cfg = config.get("retrieval_strengthening", {})
    boost_per = retrieval_cfg.get("boost_per_access", 0.05)
    window_days = retrieval_cfg.get("window_days", 7)
    max_boost = retrieval_cfg.get("max_boost", 0.30)

    log = load_access_log(config)
    fp = filepath.replace("\\", "/")
    if fp not in log:
        return 0.0

    cutoff = (datetime.datetime.now() - datetime.timedelta(days=window_days)).isoformat()
    recent_accesses = sum(1 for ts in log[fp] if ts > cutoff)
    return min(recent_accesses * boost_per, max_boost)


# ============================================================
# Mechanism 5: Consolidation Detection
# ============================================================

_consolidation_cache = None


def get_consolidation_index(config):
    """Build an index of filenames mentioned in periodic notes."""
    global _consolidation_cache
    if _consolidation_cache is not None:
        return _consolidation_cache

    mentioned_files = {}
    periodic_dirs = {
        "weekly": config.get("weekly_dir", ""),
        "monthly": config.get("monthly_dir", ""),
        "quarterly": config.get("quarterly_dir", ""),
        "yearly": config.get("yearly_dir", ""),
    }

    for period, period_path in periodic_dirs.items():
        if not period_path or not os.path.exists(period_path):
            continue
        for fname in os.listdir(period_path):
            if not fname.endswith(".md"):
                continue
            fpath = os.path.join(period_path, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read().lower()
                for word in re.findall(r"[\w\-\.]+\.md", content):
                    if word not in mentioned_files:
                        mentioned_files[word] = set()
                    mentioned_files[word].add(period)
            except OSError:
                continue

    _consolidation_cache = mentioned_files
    return mentioned_files


def clear_consolidation_cache():
    """Clear the consolidation cache (for testing or after synthesis)."""
    global _consolidation_cache
    _consolidation_cache = None


def get_consolidation_boost(filepath, config):
    """Calculate consolidation bonus for a file."""
    if not filepath:
        return 0.0

    consolidation_cfg = config.get("consolidation", {})
    bonus_per_level = consolidation_cfg.get("bonus_per_level", 0.15)
    max_bonus = consolidation_cfg.get("max_bonus", 0.50)

    fname = os.path.basename(filepath).lower()
    index = get_consolidation_index(config)
    if fname in index:
        levels = len(index[fname])
        return min(levels * bonus_per_level, max_bonus)
    return 0.0


# ============================================================
# Mechanism 1: Temporal Decay (Forgetting Curve)
# ============================================================

def get_file_age_days(filepath):
    """Get file age in days from its last modification time."""
    try:
        mtime = os.path.getmtime(filepath)
        age = datetime.datetime.now() - datetime.datetime.fromtimestamp(mtime)
        return max(0, age.days)
    except (OSError, ValueError):
        return 0


def biological_score(base_score, filepath, config, apply_decay=True):
    """Apply the full biological memory model to a base search score.

    Pipeline:
        1. Temporal decay with salience-modified age
        2. Retrieval strengthening boost
        3. Consolidation bonus
    """
    if not apply_decay:
        return base_score

    decay_lambda = config.get("decay_lambda", math.log(2) / 30)
    evergreen_patterns = config.get("evergreen_patterns", [])
    salience_patterns = config.get("salience_patterns", {})

    if is_evergreen(filepath, evergreen_patterns):
        score = base_score
    else:
        raw_age = get_file_age_days(filepath)
        salience = get_salience(filepath, salience_patterns)
        effective_age = raw_age / salience
        decay = math.exp(-decay_lambda * effective_age)
        score = base_score * decay

    retrieval_boost = get_retrieval_boost(filepath, config)
    score = score * (1.0 + retrieval_boost)

    consolidation = get_consolidation_boost(filepath, config)
    score = score * (1.0 + consolidation)

    return score


# Legacy function for backward compatibility
def temporal_decay_score(base_score, filepath, decay_lambda, evergreen_patterns,
                         apply_decay=True):
    """Apply exponential temporal decay (legacy interface).

    For new code, use biological_score() instead.
    """
    if not apply_decay:
        return base_score
    if is_evergreen(filepath, evergreen_patterns):
        return base_score
    age_days = get_file_age_days(filepath)
    decay = math.exp(-decay_lambda * age_days)
    return base_score * decay


def keyword_score(query, document):
    """BM25-inspired keyword scoring."""
    query_terms = set(re.findall(r"\w+", query.lower()))
    doc_terms = re.findall(r"\w+", document.lower())

    if len(doc_terms) == 0 or len(query_terms) == 0:
        return 0.0

    k1 = 1.5
    score = 0.0
    term_counts = {}
    for t in doc_terms:
        term_counts[t] = term_counts.get(t, 0) + 1

    for qt in query_terms:
        tf = term_counts.get(qt, 0)
        if tf > 0:
            score += tf / (tf + k1)

    max_possible = len(query_terms)
    return min(1.0, score / max_possible) if max_possible > 0 else 0.0


def hybrid_search(query, n_results=None, category=None, vector_only=False,
                  keyword_only=False, apply_decay=True, json_output=False,
                  config=None):
    """Run hybrid vector + keyword search with biological memory model."""
    if config is None:
        config = get_config()

    if n_results is None:
        n_results = config.get("default_n_results", 8)

    vector_weight = config.get("vector_weight", 0.70)
    keyword_weight = config.get("keyword_weight", 0.30)
    candidate_multiplier = config.get("candidate_multiplier", 3)
    chroma_dir = config["chroma_dir"]
    collection_name = config["collection_name"]

    client = chromadb.PersistentClient(path=chroma_dir)

    try:
        collection = client.get_collection(collection_name)
    except Exception:
        safe_print("No index found. Run: claude-memory index")
        return []

    n_candidates = n_results * candidate_multiplier
    where_filter = {"category": category} if category else None

    # --- Vector search ---
    vector_results = {}
    if not keyword_only:
        try:
            vr = collection.query(
                query_texts=[query],
                n_results=min(n_candidates, collection.count()),
                where=where_filter,
            )
            for i, (doc, meta, dist) in enumerate(zip(
                vr["documents"][0], vr["metadatas"][0], vr["distances"][0],
            )):
                doc_id = vr["ids"][0][i]
                vscore = max(0, 1 - dist)
                vector_results[doc_id] = {
                    "document": doc, "metadata": meta,
                    "vector_score": vscore, "keyword_score": 0.0,
                }
        except Exception as e:
            safe_print(f"Vector search error: {e}")

    # --- Keyword search ---
    if not vector_only:
        if keyword_only:
            try:
                all_docs = collection.get(
                    include=["documents", "metadatas"],
                    where=where_filter,
                    limit=min(500, collection.count()),
                )
                for i, (doc_id, doc, meta) in enumerate(zip(
                    all_docs["ids"], all_docs["documents"], all_docs["metadatas"],
                )):
                    ks = keyword_score(query, doc)
                    if ks > 0:
                        if doc_id not in vector_results:
                            vector_results[doc_id] = {
                                "document": doc, "metadata": meta,
                                "vector_score": 0.0, "keyword_score": ks,
                            }
                        else:
                            vector_results[doc_id]["keyword_score"] = ks
            except Exception as e:
                safe_print(f"Keyword search error: {e}")
        else:
            for doc_id, entry in vector_results.items():
                entry["keyword_score"] = keyword_score(query, entry["document"])

    # --- Merge with biological scoring ---
    ranked = []
    salience_patterns = config.get("salience_patterns", {})
    evergreen_patterns = config.get("evergreen_patterns", [])

    for doc_id, entry in vector_results.items():
        if vector_only:
            raw_score = entry["vector_score"]
        elif keyword_only:
            raw_score = entry["keyword_score"]
        else:
            raw_score = (vector_weight * entry["vector_score"] +
                         keyword_weight * entry["keyword_score"])

        filepath = entry["metadata"].get("source", "")
        final_score = biological_score(raw_score, filepath, config, apply_decay)

        salience = get_salience(filepath, salience_patterns)
        retrieval = get_retrieval_boost(filepath, config) if apply_decay else 0.0
        consolidation = get_consolidation_boost(filepath, config) if apply_decay else 0.0

        ranked.append({
            "id": doc_id, "score": final_score, "raw_score": raw_score,
            "vector_score": entry["vector_score"],
            "keyword_score": entry["keyword_score"],
            "document": entry["document"], "metadata": entry["metadata"],
            "filepath": filepath,
            "age_days": get_file_age_days(filepath) if filepath else 0,
            "evergreen": is_evergreen(filepath, evergreen_patterns),
            "salience": salience,
            "retrieval_boost": retrieval,
            "consolidation_boost": consolidation,
        })

    ranked.sort(key=lambda x: x["score"], reverse=True)
    top = ranked[:n_results]

    if apply_decay:
        for r in top:
            if r["filepath"]:
                record_access(r["filepath"], config)

    # --- Output ---
    if json_output:
        output = []
        for r in top:
            output.append({
                "score": round(r["score"], 4),
                "raw_score": round(r["raw_score"], 4),
                "vector_score": round(r["vector_score"], 4),
                "keyword_score": round(r["keyword_score"], 4),
                "age_days": r["age_days"],
                "evergreen": r["evergreen"],
                "salience": r["salience"],
                "retrieval_boost": round(r["retrieval_boost"], 3),
                "consolidation_boost": round(r["consolidation_boost"], 3),
                "category": r["metadata"].get("category", "?"),
                "source": r["metadata"].get("source", ""),
                "filename": r["metadata"].get("filename", ""),
                "preview": r["document"][:500],
            })
        print(json.dumps(output, indent=2, default=str))
        return output

    if not top:
        safe_print(f"No results for: {query}")
        return []

    safe_print(f'\n=== Hybrid Search: "{query}" ===')
    mode = "HYBRID" if not vector_only and not keyword_only else ("VECTOR" if vector_only else "KEYWORD")
    decay_str = "ON (biological)" if apply_decay else "OFF"
    safe_print(f"    Mode: {mode} | Decay: {decay_str} | Results: {len(top)}\n")

    for i, r in enumerate(top):
        source = r["metadata"].get("rel_path", r["metadata"].get("source", "?"))
        cat = r["metadata"].get("category", "?").upper()
        age = r["age_days"]
        eg = " [EVERGREEN]" if r["evergreen"] else ""
        bio_markers = []
        if r["salience"] > 1.0:
            bio_markers.append(f"S:{r['salience']:.0f}x")
        if r["retrieval_boost"] > 0:
            bio_markers.append(f"R:+{r['retrieval_boost']:.0%}")
        if r["consolidation_boost"] > 0:
            bio_markers.append(f"C:+{r['consolidation_boost']:.0%}")
        bio_str = " " + " ".join(bio_markers) if bio_markers else ""

        preview = r["document"][:350].replace("\n", " ").strip()
        if len(r["document"]) > 350:
            preview += "..."

        safe_print(
            f"[{i+1}] Score: {r['score']:.3f} "
            f"(V:{r['vector_score']:.2f} K:{r['keyword_score']:.2f}) "
            f"[{cat}] {age}d old{eg}{bio_str}"
        )
        safe_print(f"    {source}")
        safe_print(f"    {preview}")
        safe_print("")

    return top


def show_access_stats(config=None):
    """Show retrieval frequency and consolidation statistics."""
    if config is None:
        config = get_config()

    log = load_access_log(config)
    if not log:
        safe_print("No access history yet. Run some searches first.")
        return

    retrieval_cfg = config.get("retrieval_strengthening", {})
    boost_per = retrieval_cfg.get("boost_per_access", 0.05)
    max_boost = retrieval_cfg.get("max_boost", 0.30)
    window_days = retrieval_cfg.get("window_days", 7)

    safe_print(f"\n=== Retrieval Strengthening Stats ===")
    safe_print(f"  Tracked files: {len(log)}")

    cutoff = (datetime.datetime.now() - datetime.timedelta(days=window_days)).isoformat()
    stats = []
    for fp, timestamps in log.items():
        recent = sum(1 for ts in timestamps if ts > cutoff)
        boost = min(recent * boost_per, max_boost)
        fname = os.path.basename(fp.replace("\\", "/"))
        stats.append((fname, recent, boost, len(timestamps)))

    stats.sort(key=lambda x: x[1], reverse=True)
    safe_print(f"\n  {'File':<40s} {'Recent':>6s} {'Boost':>7s} {'Total':>6s}")
    safe_print(f"  {'-'*40} {'-'*6} {'-'*7} {'-'*6}")
    for fname, recent, boost, total in stats[:20]:
        boost_str = f"+{boost:.0%}" if boost > 0 else "-"
        safe_print(f"  {fname:<40s} {recent:>6d} {boost_str:>7s} {total:>6d}")

    consolidation_index = get_consolidation_index(config)
    if consolidation_index:
        consolidation_cfg = config.get("consolidation", {})
        bonus_per_level = consolidation_cfg.get("bonus_per_level", 0.15)
        max_bonus = consolidation_cfg.get("max_bonus", 0.50)
        safe_print(f"\n=== Consolidation Index ===")
        safe_print(f"  Files consolidated: {len(consolidation_index)}")
        for fname, periods in sorted(
            consolidation_index.items(), key=lambda x: len(x[1]), reverse=True
        )[:15]:
            period_str = ", ".join(sorted(periods))
            boost = min(len(periods) * bonus_per_level, max_bonus)
            safe_print(f"  {fname:<40s} [{period_str}] +{boost:.0%}")
