"""
Delta-Sync Memory Indexer.

Indexes markdown files into ChromaDB for vector search. Uses SHA-256 hash
comparison to only re-index files that have actually changed, making
repeated runs fast (delta sync).

Adds metadata for temporal decay, category filtering, and source tracking.

Can be used as a library or run directly:
    python -m claude_memory.indexer
"""

import os
import json
import hashlib
import datetime
import chromadb

from .config import get_config
from .search import safe_print


def file_hash(filepath):
    """SHA-256 hash of file content."""
    try:
        with open(filepath, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return None


def load_hash_cache(cache_path):
    """Load previous file hashes for delta comparison."""
    if os.path.exists(cache_path):
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def save_hash_cache(cache, cache_path):
    """Save file hashes after indexing."""
    os.makedirs(os.path.dirname(cache_path), exist_ok=True)
    with open(cache_path, "w", encoding="utf-8") as f:
        json.dump(cache, f, indent=2)


def chunk_text(text, chunk_size=400, overlap=80):
    """Split text into overlapping word-level chunks.

    Uses ~400 word chunks with ~80 word overlap, similar to the approach
    described in the ACP spec for memory systems.
    """
    words = text.split()
    chunks = []
    start = 0
    while start < len(words):
        end = start + chunk_size
        chunk = " ".join(words[start:end])
        if chunk.strip():
            chunks.append(chunk)
        start = end - overlap
    return chunks


def categorize_file(filepath, config):
    """Determine category from filepath using configured rules.

    Rules are checked in order; first match wins. If no rule matches,
    the default_category from config is used.
    """
    fp = filepath.replace("\\", "/").lower()
    rules = config.get("category_rules", [])
    for rule in rules:
        pattern = rule.get("pattern", "").lower()
        if pattern and pattern in fp:
            return rule.get("category", config.get("default_category", "other"))
    return config.get("default_category", "other")


def get_file_mtime_iso(filepath):
    """Get file modification time as ISO string."""
    try:
        mtime = os.path.getmtime(filepath)
        return datetime.datetime.fromtimestamp(mtime).isoformat()
    except OSError:
        return datetime.datetime.now().isoformat()


def collect_files(index_paths, config):
    """Collect all indexable files from configured directories.

    Args:
        index_paths: List of {"path": str, "depth": int} dicts.
        config: Configuration dict.

    Returns:
        List of absolute file paths.
    """
    extensions = config.get("index_extensions", [".md"])
    skip_dirs = set(config.get("skip_dirs", []))
    files = []

    for entry in index_paths:
        directory = entry.get("path", "")
        max_depth = entry.get("depth", 3)

        if not os.path.isdir(directory):
            continue

        for root, dirs, filenames in os.walk(directory):
            depth = root.replace(directory, "").count(os.sep)
            if depth >= max_depth:
                dirs.clear()
                continue
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for f in filenames:
                if any(f.endswith(ext) for ext in extensions):
                    files.append(os.path.join(root, f))

    return files


def delta_index(full_rebuild=False, dry_run=False, config=None):
    """Index files into ChromaDB, only re-processing changed ones.

    Args:
        full_rebuild: Delete and rebuild the entire index.
        dry_run: Show what would change without actually indexing.
        config: Configuration dict. Loaded from defaults if None.
    """
    if config is None:
        config = get_config()

    chroma_dir = config["chroma_dir"]
    collection_name = config["collection_name"]
    cache_path = config["hash_cache_file"]
    chunk_size = config.get("chunk_size_words", 400)
    chunk_overlap = config.get("chunk_overlap_words", 80)
    min_size = config.get("min_file_size", 50)

    os.makedirs(chroma_dir, exist_ok=True)
    client = chromadb.PersistentClient(path=chroma_dir)

    if full_rebuild:
        safe_print("FULL REBUILD -- deleting existing index...")
        try:
            client.delete_collection(collection_name)
        except Exception:
            pass

    try:
        collection = client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
    except Exception as e:
        safe_print(f"ERROR creating collection: {e}")
        return

    old_hashes = {} if full_rebuild else load_hash_cache(cache_path)
    new_hashes = {}

    index_paths = config.get("index_paths", [])
    if not index_paths:
        safe_print("No index paths configured. Run: claude-memory init")
        safe_print("Then add paths to ~/.claude-memory/config.json")
        return

    all_files = collect_files(index_paths, config)
    safe_print(f"Found {len(all_files)} files across {len(index_paths)} directories")

    # Determine what changed
    to_index = []
    unchanged = 0
    for fp in all_files:
        h = file_hash(fp)
        if h is None:
            continue
        new_hashes[fp] = h
        if fp in old_hashes and old_hashes[fp] == h:
            unchanged += 1
        else:
            to_index.append(fp)

    deleted_files = set(old_hashes.keys()) - set(new_hashes.keys())

    safe_print(f"  Unchanged: {unchanged}")
    safe_print(f"  To index:  {len(to_index)}")
    safe_print(f"  Deleted:   {len(deleted_files)}")

    if dry_run:
        if to_index:
            safe_print("\nFiles to re-index:")
            for fp in to_index:
                safe_print(f"  + {os.path.basename(fp)}")
        if deleted_files:
            safe_print("\nFiles to remove from index:")
            for fp in deleted_files:
                safe_print(f"  - {os.path.basename(fp)}")
        return

    # Remove deleted files from index
    for fp in deleted_files:
        try:
            results = collection.get(where={"source": fp})
            if results["ids"]:
                collection.delete(ids=results["ids"])
                safe_print(f"  Removed {len(results['ids'])} chunks: {os.path.basename(fp)}")
        except Exception:
            pass

    # Remove old chunks for changed files
    for fp in to_index:
        try:
            results = collection.get(where={"source": fp})
            if results["ids"]:
                collection.delete(ids=results["ids"])
        except Exception:
            pass

    # Index new/changed files
    total_chunks = 0
    indexed = 0
    errors = 0

    for fp in to_index:
        try:
            with open(fp, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()

            if len(content.strip()) < min_size:
                continue

            chunks = chunk_text(content, chunk_size, chunk_overlap)
            mtime_iso = get_file_mtime_iso(fp)
            category = categorize_file(fp, config)

            chunk_ids = []
            chunk_docs = []
            chunk_metas = []

            for i, chunk_text_content in enumerate(chunks):
                doc_id = hashlib.md5(f"{fp}:{i}".encode()).hexdigest()
                chunk_ids.append(doc_id)
                chunk_docs.append(chunk_text_content)
                chunk_metas.append({
                    "source": fp,
                    "filename": os.path.basename(fp),
                    "chunk": i,
                    "total_chunks": len(chunks),
                    "category": category,
                    "last_modified": mtime_iso,
                    "file_hash": new_hashes.get(fp, ""),
                })

            if chunk_ids:
                collection.add(
                    ids=chunk_ids,
                    documents=chunk_docs,
                    metadatas=chunk_metas,
                )
                total_chunks += len(chunks)
                indexed += 1

                if indexed % 20 == 0:
                    safe_print(f"  ...indexed {indexed}/{len(to_index)} files ({total_chunks} chunks)")

        except Exception as e:
            safe_print(f"  ERROR {os.path.basename(fp)}: {str(e)[:80]}")
            errors += 1

    save_hash_cache(new_hashes, cache_path)

    safe_print(f"\nINDEX SYNC COMPLETE")
    safe_print(f"  Files re-indexed: {indexed}")
    safe_print(f"  New chunks added: {total_chunks}")
    safe_print(f"  Errors:           {errors}")
    safe_print(f"  Total in index:   {collection.count()}")


def show_stats(config=None):
    """Show detailed index statistics."""
    if config is None:
        config = get_config()

    chroma_dir = config["chroma_dir"]
    collection_name = config["collection_name"]
    cache_path = config["hash_cache_file"]
    categories = config.get("categories", [])

    client = chromadb.PersistentClient(path=chroma_dir)
    try:
        collection = client.get_collection(collection_name)
    except Exception:
        safe_print("No index found. Run: claude-memory index")
        return

    count = collection.count()
    safe_print(f"\n=== Memory Index Stats ===")
    safe_print(f"  Collection:    {collection_name}")
    safe_print(f"  Total chunks:  {count}")
    safe_print(f"  Database:      {chroma_dir}")

    safe_print(f"\n  Categories:")
    for cat in categories:
        try:
            cat_results = collection.get(where={"category": cat})
            cat_count = len(cat_results["ids"])
            if cat_count > 0:
                safe_print(f"    {cat.upper():15s}: {cat_count} chunks")
        except Exception:
            pass

    cache = load_hash_cache(cache_path)
    safe_print(f"\n  Tracked files: {len(cache)}")

    safe_print(f"\n  Recent files in cache:")
    sorted_files = sorted(
        cache.keys(),
        key=lambda f: os.path.getmtime(f) if os.path.exists(f) else 0,
        reverse=True,
    )
    for fp in sorted_files[:10]:
        age = "?"
        if os.path.exists(fp):
            mtime = datetime.datetime.fromtimestamp(os.path.getmtime(fp))
            age = (datetime.datetime.now() - mtime).days
        safe_print(f"    [{age}d] {os.path.basename(fp)}")
