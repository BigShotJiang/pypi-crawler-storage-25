"""
CLI entry point for claude-memory.

Usage:
    claude-memory search "query"              # hybrid search
    claude-memory search "query" -c category  # filtered by category
    claude-memory search "query" --json       # JSON output (for piping)
    claude-memory index                       # delta sync
    claude-memory index --full                # full rebuild
    claude-memory index --stats               # show stats
    claude-memory index --check               # dry run
    claude-memory daily --load                # today + yesterday
    claude-memory daily --append "message"    # log event
    claude-memory daily --today               # show today's log
    claude-memory daily --init                # create today's log
    claude-memory weekly                      # show/create this week's note
    claude-memory monthly                     # show/create this month's note
    claude-memory quarterly                   # show/create this quarter's note
    claude-memory yearly                      # show/create this year's note
    claude-memory periodic --load             # load week + month context
    claude-memory periodic --all              # show all current period notes
    claude-memory init                        # initialize config + directories

Optional modules (extras):
    claude-memory compaction --watch          # watch for compaction events
    claude-memory compaction --scan           # scan past conversations
    claude-memory compaction --stats          # compaction statistics
    claude-memory compaction --log            # show compaction log
    claude-memory ccl --encode file.md        # compress with CCL
    claude-memory ccl --decode file.md        # expand CCL back to English
    claude-memory ccl --analyze file.md       # show token savings
    claude-memory ccl --dict                  # show compression dictionary
    claude-memory vault --status              # show sync status
    claude-memory vault --push                # push local to vault
    claude-memory vault --pull                # pull vault to local
    claude-memory vault --sync                # bidirectional sync
    claude-memory vault --init /path          # set vault path
"""

import sys
import os
import json

from .config import get_config, save_config, init_dirs, DEFAULT_CONFIG_FILE
from .search import safe_print, hybrid_search, show_access_stats
from .indexer import delta_index, show_stats
from .daily import load_recent, append_to_log, show_today, init_daily_log
from .periodic import (
    PERIODS, init_period, append_to_period, show_period,
    list_periods, synthesize_period, load_periodic_context, show_all_current,
)


def cmd_init(args):
    """Initialize claude-memory configuration and directories."""
    config = get_config()
    init_dirs(config)

    config_path = config.get("_config_path", DEFAULT_CONFIG_FILE)

    if not os.path.exists(config_path):
        save_config(config, config_path)
        safe_print(f"Created config: {config_path}")
    else:
        safe_print(f"Config exists:  {config_path}")

    safe_print(f"Data directory: {config['data_dir']}")
    safe_print(f"ChromaDB:       {config['chroma_dir']}")
    safe_print(f"Daily logs:     {config['daily_log_dir']}")
    safe_print("")
    safe_print("Next steps:")
    safe_print(f"  1. Edit {config_path}")
    safe_print('  2. Add your directories to "index_paths":')
    safe_print('       [{"path": "/path/to/notes", "depth": 3}]')
    safe_print("  3. Run: claude-memory index")


def cmd_access_stats(args):
    """Handle the access-stats subcommand."""
    config = get_config()
    show_access_stats(config)


# --- Optional module commands ---

def cmd_compaction(args):
    """Handle the compaction subcommand (optional module)."""
    from .extras.compaction_watcher import (
        scan_for_compactions, watch_compactions,
        show_compaction_stats, show_compaction_log,
    )
    config = get_config()

    if "--watch" in args:
        watch_compactions(config=config)
    elif "--scan" in args:
        events = scan_for_compactions(config=config)
        if events:
            safe_print(f"Found {len(events)} compaction events:")
            for e in events:
                safe_print(f"  [{e['timestamp'][:19]}] {e['project']} -- {e['type']}")
        else:
            safe_print("No compaction events found in conversation files.")
    elif "--stats" in args:
        show_compaction_stats(config=config)
    elif "--log" in args:
        show_compaction_log(config=config)
    else:
        safe_print("Usage: claude-memory compaction [--watch|--scan|--stats|--log]")
        safe_print("")
        safe_print("  --watch    Monitor for compaction events in real-time")
        safe_print("  --scan     Scan conversation files for past compaction events")
        safe_print("  --stats    Show compaction statistics")
        safe_print("  --log      Show the compaction event log")


def cmd_ccl(args):
    """Handle the ccl subcommand (optional module)."""
    from .extras.ccl import encode_file, decode_file, show_analysis, show_dictionary

    tier = 2
    if "--tier" in args:
        idx = args.index("--tier")
        if idx + 1 < len(args):
            tier = int(args[idx + 1])
            args.pop(idx)
            args.pop(idx)

    if "--encode" in args:
        idx = args.index("--encode")
        if idx + 1 < len(args):
            input_path = args[idx + 1]
            output_path = None
            if "-o" in args:
                oidx = args.index("-o")
                if oidx + 1 < len(args):
                    output_path = args[oidx + 1]
            encode_file(input_path, output_path, tier=tier)
        else:
            safe_print("Usage: claude-memory ccl --encode file.md [--tier 0-3] [-o output.md]")
    elif "--decode" in args:
        idx = args.index("--decode")
        if idx + 1 < len(args):
            input_path = args[idx + 1]
            output_path = None
            if "-o" in args:
                oidx = args.index("-o")
                if oidx + 1 < len(args):
                    output_path = args[oidx + 1]
            decode_file(input_path, output_path)
        else:
            safe_print("Usage: claude-memory ccl --decode file.md [-o output.md]")
    elif "--analyze" in args:
        idx = args.index("--analyze")
        if idx + 1 < len(args):
            show_analysis(args[idx + 1], tier=tier)
        else:
            safe_print("Usage: claude-memory ccl --analyze file.md [--tier 0-3]")
    elif "--dict" in args:
        show_dictionary()
    else:
        safe_print("Usage: claude-memory ccl [--encode|--decode|--analyze|--dict]")
        safe_print("")
        safe_print("  --encode file.md [--tier 0-3] [-o out.md]  Compress a file")
        safe_print("  --decode file.md [-o out.md]               Expand back to English")
        safe_print("  --analyze file.md [--tier 0-3]             Show token savings")
        safe_print("  --dict                                     Show compression dictionary")


def cmd_vault(args):
    """Handle the vault subcommand (optional module)."""
    from .extras.vault_sync import (
        init_vault, show_sync_status,
        sync_to_vault, sync_from_vault, bidirectional_sync,
    )
    config = get_config()

    if "--init" in args:
        idx = args.index("--init")
        if idx + 1 < len(args):
            init_vault(args[idx + 1], config=config)
        else:
            safe_print("Usage: claude-memory vault --init /path/to/cloud/folder")
    elif "--status" in args:
        show_sync_status(config=config)
    elif "--push" in args:
        dry_run = "--dry-run" in args
        sync_to_vault(config=config, dry_run=dry_run)
    elif "--pull" in args:
        dry_run = "--dry-run" in args
        sync_from_vault(config=config, dry_run=dry_run)
    elif "--sync" in args:
        dry_run = "--dry-run" in args
        bidirectional_sync(config=config, dry_run=dry_run)
    else:
        safe_print("Usage: claude-memory vault [--status|--push|--pull|--sync|--init]")
        safe_print("")
        safe_print("  --init /path     Set vault path (OneDrive, Dropbox, etc.)")
        safe_print("  --status         Show sync status between local and vault")
        safe_print("  --push           Push local changes to vault")
        safe_print("  --pull           Pull vault changes to local")
        safe_print("  --sync           Bidirectional sync (newer wins)")
        safe_print("  --dry-run        Add to --push/--pull/--sync to preview")


def cmd_search(args):
    """Handle the search subcommand."""
    if not args:
        safe_print("Usage: claude-memory search \"query\" [options]")
        safe_print("  --vector-only    Vector search only")
        safe_print("  --keyword-only   Keyword search only")
        safe_print("  --no-decay       Disable temporal decay")
        safe_print("  --json           JSON output")
        safe_print("  -c CATEGORY      Filter category")
        safe_print("  -n NUM           Number of results (default 8)")
        sys.exit(1)

    vector_only = "--vector-only" in args
    keyword_only = "--keyword-only" in args
    no_decay = "--no-decay" in args
    json_out = "--json" in args

    for flag in ["--vector-only", "--keyword-only", "--no-decay", "--json"]:
        while flag in args:
            args.remove(flag)

    category = None
    if "-c" in args:
        idx = args.index("-c")
        if idx + 1 < len(args):
            category = args[idx + 1]
            args.pop(idx)
            args.pop(idx)

    n_results = None
    if "-n" in args:
        idx = args.index("-n")
        if idx + 1 < len(args):
            n_results = int(args[idx + 1])
            args.pop(idx)
            args.pop(idx)

    query = " ".join(args)
    if not query:
        safe_print("No query provided.")
        sys.exit(1)

    config = get_config()
    hybrid_search(
        query,
        n_results=n_results,
        category=category,
        vector_only=vector_only,
        keyword_only=keyword_only,
        apply_decay=not no_decay,
        json_output=json_out,
        config=config,
    )


def cmd_index(args):
    """Handle the index subcommand."""
    config = get_config()

    if "--stats" in args:
        show_stats(config)
    elif "--full" in args:
        delta_index(full_rebuild=True, config=config)
    elif "--check" in args:
        delta_index(dry_run=True, config=config)
    else:
        delta_index(config=config)


def cmd_daily(args):
    """Handle the daily subcommand."""
    config = get_config()

    if "--load" in args:
        safe_print(load_recent(config))
    elif "--append" in args:
        idx = args.index("--append")
        message_parts = args[idx + 1:]
        if message_parts:
            append_to_log(" ".join(message_parts), config)
        else:
            safe_print("Usage: claude-memory daily --append \"your message\"")
    elif "--today" in args:
        show_today(config)
    elif "--init" in args:
        init_daily_log(config)
    else:
        safe_print("Usage: claude-memory daily [--load|--append|--today|--init]")


def cmd_periodic_period(period, args):
    """Handle a specific periodic subcommand (weekly/monthly/quarterly/yearly)."""
    config = get_config()

    if not args:
        # Show/create the current period note
        init_period(period, config=config)
        show_period(period, config=config)
    elif args[0] == "--synthesize":
        synthesize_period(period, config=config)
    elif args[0] == "--append" and len(args) > 1:
        append_to_period(period, " ".join(args[1:]), config=config)
    elif args[0] == "--list":
        list_periods(period, config=config)
    else:
        safe_print(f"Usage: claude-memory {period} [--synthesize|--append \"note\"|--list]")


def cmd_periodic(args):
    """Handle the periodic meta-command (--load, --all)."""
    config = get_config()

    if "--load" in args:
        safe_print(load_periodic_context(config))
    elif "--all" in args:
        show_all_current(config)
    else:
        safe_print("Usage: claude-memory periodic [--load|--all]")
        safe_print("")
        safe_print("Or use a specific period:")
        safe_print("  claude-memory weekly                      # Show this week's note")
        safe_print("  claude-memory monthly --synthesize        # Synthesize from weekly notes")
        safe_print("  claude-memory quarterly --append \"note\"   # Append to quarter note")
        safe_print("  claude-memory yearly --list               # List all yearly notes")


def main():
    """Main CLI entry point."""
    if len(sys.argv) < 2:
        safe_print("claude-memory -- Persistent hybrid memory for AI coding assistants")
        safe_print("")
        safe_print("Commands:")
        safe_print("  init                        Initialize config + directories")
        safe_print('  search "query" [options]    Hybrid vector + keyword search')
        safe_print("  index [--full|--stats]      Index or re-index files")
        safe_print("  daily [--load|--append]     Daily log management")
        safe_print("  weekly [--synthesize|...]   Weekly periodic notes")
        safe_print("  monthly [--synthesize|...]  Monthly periodic notes")
        safe_print("  quarterly [--synthesize|...] Quarterly periodic notes")
        safe_print("  yearly [--synthesize|...]   Yearly periodic notes")
        safe_print("  periodic [--load|--all]     Load/show all periodic context")
        safe_print("  access-stats                Show retrieval & consolidation stats")
        safe_print("")
        safe_print("Optional modules:")
        safe_print("  compaction [--watch|...]    Monitor context compaction events")
        safe_print("  ccl [--encode|...]          Context Compression Language tools")
        safe_print("  vault [--status|...]        Multi-machine vault sync")
        safe_print("")
        safe_print("Run 'claude-memory <command>' for detailed usage.")
        sys.exit(0)

    command = sys.argv[1]
    args = sys.argv[2:]

    if command == "init":
        cmd_init(args)
    elif command == "search":
        cmd_search(args)
    elif command == "index":
        cmd_index(args)
    elif command == "daily":
        cmd_daily(args)
    elif command in PERIODS:
        cmd_periodic_period(command, args)
    elif command == "periodic":
        cmd_periodic(args)
    elif command == "access-stats":
        cmd_access_stats(args)
    elif command == "compaction":
        cmd_compaction(args)
    elif command == "ccl":
        cmd_ccl(args)
    elif command == "vault":
        cmd_vault(args)
    else:
        safe_print(f"Unknown command: {command}")
        safe_print("Run 'claude-memory' for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
