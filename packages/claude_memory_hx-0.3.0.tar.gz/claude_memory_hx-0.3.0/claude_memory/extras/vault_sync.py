"""
Vault Sync -- Multi-machine memory synchronization via cloud folders.

The problem: AI coding assistants run on multiple machines (work laptop, home
desktop, etc.) but their memory is local. You teach Claude your architecture
on Monday at work, then Tuesday at home it has no idea.

The solution: Designate a cloud-synced folder (OneDrive, Dropbox, Google Drive,
iCloud) as your "vault" -- the shared source of truth. This module handles
syncing local memory files to the vault and loading vault content back.

Architecture:
    Local (per-machine)           Vault (cloud-synced)
    +-----------------+          +------------------+
    | L1: MEMORY.md   |   sync   | conversations/   |
    | L2: topic files  | ------> | decisions/       |
    | daily logs       |          | projects/        |
    | periodic notes   |          | changelog.md     |
    +-----------------+          +------------------+
                                        |
                                   OneDrive/Dropbox
                                        |
                                 +------+------+
                                 |             |
                              Home PC      Work PC

Usage (CLI):
    claude-memory vault --status               # Show sync status
    claude-memory vault --push                 # Push local changes to vault
    claude-memory vault --pull                 # Pull vault changes to local
    claude-memory vault --sync                 # Bidirectional sync
    claude-memory vault --init /path/to/vault  # Set vault path
    claude-memory vault --diff                 # Show differences

Usage (Python):
    from claude_memory.extras.vault_sync import (
        sync_to_vault, sync_from_vault, get_sync_status,
    )
"""

import os
import json
import shutil
import hashlib
import datetime

from ..config import get_config, save_config
from ..search import safe_print


DEFAULT_VAULT_SUBFOLDERS = [
    "conversations",
    "decisions",
    "projects",
    "infrastructure",
    "intelligence",
    "people",
    "skills",
    "briefings",
    "intel",
]

# Files/dirs to sync from local data_dir to vault
SYNC_DIRS = ["daily", "weekly", "monthly", "quarterly", "yearly"]
SYNC_FILES = ["access_log.json", "compaction_log.json"]


def _file_hash(filepath):
    """SHA-256 hash of file content."""
    try:
        with open(filepath, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return None


def _file_mtime(filepath):
    """Get file modification time as datetime."""
    try:
        return datetime.datetime.fromtimestamp(os.path.getmtime(filepath))
    except OSError:
        return None


def _ensure_dir(path):
    """Create directory if it doesn't exist."""
    os.makedirs(path, exist_ok=True)


def get_vault_path(config=None):
    """Get the configured vault path.

    Returns:
        Vault path string, or None if not configured.
    """
    if config is None:
        config = get_config()

    # Check config first
    vault = config.get("vault_path", "")
    if vault and os.path.isdir(vault):
        return vault

    # Check environment variable
    env_vault = os.environ.get("CLAUDE_MEMORY_VAULT_PATH", "")
    if env_vault and os.path.isdir(env_vault):
        return env_vault

    return None


def init_vault(vault_path, config=None):
    """Initialize a vault directory and save the path to config.

    Args:
        vault_path: Path to the vault directory.
        config: Configuration dict.
    """
    if config is None:
        config = get_config()

    _ensure_dir(vault_path)

    for subfolder in DEFAULT_VAULT_SUBFOLDERS:
        _ensure_dir(os.path.join(vault_path, subfolder))

    # Save vault path to config
    config["vault_path"] = vault_path
    save_config(config)

    # Create changelog if it doesn't exist
    changelog = os.path.join(vault_path, "changelog.md")
    if not os.path.exists(changelog):
        with open(changelog, "w", encoding="utf-8") as f:
            f.write("# Changelog\n\n")
            f.write(f"Vault initialized: {datetime.datetime.now().isoformat()}\n\n")

    safe_print(f"Vault initialized: {vault_path}")
    safe_print(f"Subfolders created: {', '.join(DEFAULT_VAULT_SUBFOLDERS)}")
    safe_print(f"Vault path saved to config.")


def get_sync_status(config=None):
    """Compare local files with vault to determine sync status.

    Returns:
        Dict with:
            - local_only: files only in local
            - vault_only: files only in vault
            - modified_local: files newer locally
            - modified_vault: files newer in vault
            - in_sync: files that match
    """
    if config is None:
        config = get_config()

    vault_path = get_vault_path(config)
    if not vault_path:
        return {"error": "No vault configured. Run: claude-memory vault --init /path"}

    data_dir = config.get("data_dir", "")

    status = {
        "vault_path": vault_path,
        "data_dir": data_dir,
        "local_only": [],
        "vault_only": [],
        "modified_local": [],
        "modified_vault": [],
        "in_sync": [],
    }

    # Compare sync directories
    for sync_dir in SYNC_DIRS:
        local_dir = os.path.join(data_dir, sync_dir)
        vault_dir = os.path.join(vault_path, sync_dir)

        local_files = set()
        vault_files = set()

        if os.path.isdir(local_dir):
            local_files = {f for f in os.listdir(local_dir) if f.endswith(".md")}
        if os.path.isdir(vault_dir):
            vault_files = {f for f in os.listdir(vault_dir) if f.endswith(".md")}

        # Local only
        for f in local_files - vault_files:
            status["local_only"].append(os.path.join(sync_dir, f))

        # Vault only
        for f in vault_files - local_files:
            status["vault_only"].append(os.path.join(sync_dir, f))

        # Both exist -- compare
        for f in local_files & vault_files:
            local_path = os.path.join(local_dir, f)
            vault_fpath = os.path.join(vault_dir, f)

            local_hash = _file_hash(local_path)
            vault_hash = _file_hash(vault_fpath)

            rel_path = os.path.join(sync_dir, f)

            if local_hash == vault_hash:
                status["in_sync"].append(rel_path)
            else:
                local_mtime = _file_mtime(local_path)
                vault_mtime = _file_mtime(vault_fpath)

                if local_mtime and vault_mtime:
                    if local_mtime > vault_mtime:
                        status["modified_local"].append(rel_path)
                    else:
                        status["modified_vault"].append(rel_path)
                else:
                    status["modified_local"].append(rel_path)

    return status


def sync_to_vault(config=None, dry_run=False):
    """Push local memory files to the vault.

    Copies new and modified local files to the vault directory.

    Args:
        config: Configuration dict.
        dry_run: If True, show what would be copied without doing it.

    Returns:
        Number of files synced.
    """
    if config is None:
        config = get_config()

    vault_path = get_vault_path(config)
    if not vault_path:
        safe_print("No vault configured. Run: claude-memory vault --init /path")
        return 0

    data_dir = config.get("data_dir", "")
    synced = 0

    for sync_dir in SYNC_DIRS:
        local_dir = os.path.join(data_dir, sync_dir)
        vault_dir = os.path.join(vault_path, sync_dir)

        if not os.path.isdir(local_dir):
            continue

        _ensure_dir(vault_dir)

        for fname in os.listdir(local_dir):
            if not fname.endswith(".md"):
                continue

            local_path = os.path.join(local_dir, fname)
            vault_fpath = os.path.join(vault_dir, fname)

            # Skip if identical
            if os.path.exists(vault_fpath):
                if _file_hash(local_path) == _file_hash(vault_fpath):
                    continue

            if dry_run:
                safe_print(f"  Would copy: {sync_dir}/{fname}")
            else:
                shutil.copy2(local_path, vault_fpath)
                safe_print(f"  Pushed: {sync_dir}/{fname}")
            synced += 1

    # Sync individual files
    for sync_file in SYNC_FILES:
        local_path = os.path.join(data_dir, sync_file)
        vault_fpath = os.path.join(vault_path, sync_file)

        if not os.path.exists(local_path):
            continue
        if os.path.exists(vault_fpath):
            if _file_hash(local_path) == _file_hash(vault_fpath):
                continue

        if dry_run:
            safe_print(f"  Would copy: {sync_file}")
        else:
            shutil.copy2(local_path, vault_fpath)
            safe_print(f"  Pushed: {sync_file}")
        synced += 1

    action = "Would push" if dry_run else "Pushed"
    safe_print(f"\n{action} {synced} files to vault.")
    return synced


def sync_from_vault(config=None, dry_run=False):
    """Pull vault files to local memory.

    Copies new and modified vault files to the local data directory.

    Args:
        config: Configuration dict.
        dry_run: If True, show what would be copied without doing it.

    Returns:
        Number of files synced.
    """
    if config is None:
        config = get_config()

    vault_path = get_vault_path(config)
    if not vault_path:
        safe_print("No vault configured. Run: claude-memory vault --init /path")
        return 0

    data_dir = config.get("data_dir", "")
    synced = 0

    for sync_dir in SYNC_DIRS:
        local_dir = os.path.join(data_dir, sync_dir)
        vault_dir = os.path.join(vault_path, sync_dir)

        if not os.path.isdir(vault_dir):
            continue

        _ensure_dir(local_dir)

        for fname in os.listdir(vault_dir):
            if not fname.endswith(".md"):
                continue

            local_path = os.path.join(local_dir, fname)
            vault_fpath = os.path.join(vault_dir, fname)

            if os.path.exists(local_path):
                if _file_hash(local_path) == _file_hash(vault_fpath):
                    continue

            if dry_run:
                safe_print(f"  Would pull: {sync_dir}/{fname}")
            else:
                shutil.copy2(vault_fpath, local_path)
                safe_print(f"  Pulled: {sync_dir}/{fname}")
            synced += 1

    action = "Would pull" if dry_run else "Pulled"
    safe_print(f"\n{action} {synced} files from vault.")
    return synced


def bidirectional_sync(config=None, dry_run=False):
    """Full bidirectional sync between local and vault.

    Strategy: newer file wins. If only one side has it, copy to the other.

    Args:
        config: Configuration dict.
        dry_run: If True, show what would be synced.

    Returns:
        Total files synced.
    """
    if config is None:
        config = get_config()

    vault_path = get_vault_path(config)
    if not vault_path:
        safe_print("No vault configured. Run: claude-memory vault --init /path")
        return 0

    status = get_sync_status(config)
    data_dir = config.get("data_dir", "")
    total = 0

    # Local-only files -> push to vault
    for rel_path in status.get("local_only", []):
        local_path = os.path.join(data_dir, rel_path)
        vault_fpath = os.path.join(vault_path, rel_path)
        if dry_run:
            safe_print(f"  Would push (new): {rel_path}")
        else:
            _ensure_dir(os.path.dirname(vault_fpath))
            shutil.copy2(local_path, vault_fpath)
            safe_print(f"  Pushed (new): {rel_path}")
        total += 1

    # Vault-only files -> pull to local
    for rel_path in status.get("vault_only", []):
        local_path = os.path.join(data_dir, rel_path)
        vault_fpath = os.path.join(vault_path, rel_path)
        if dry_run:
            safe_print(f"  Would pull (new): {rel_path}")
        else:
            _ensure_dir(os.path.dirname(local_path))
            shutil.copy2(vault_fpath, local_path)
            safe_print(f"  Pulled (new): {rel_path}")
        total += 1

    # Modified locally -> push
    for rel_path in status.get("modified_local", []):
        local_path = os.path.join(data_dir, rel_path)
        vault_fpath = os.path.join(vault_path, rel_path)
        if dry_run:
            safe_print(f"  Would push (modified): {rel_path}")
        else:
            shutil.copy2(local_path, vault_fpath)
            safe_print(f"  Pushed (modified): {rel_path}")
        total += 1

    # Modified in vault -> pull
    for rel_path in status.get("modified_vault", []):
        local_path = os.path.join(data_dir, rel_path)
        vault_fpath = os.path.join(vault_path, rel_path)
        if dry_run:
            safe_print(f"  Would pull (modified): {rel_path}")
        else:
            shutil.copy2(vault_fpath, local_path)
            safe_print(f"  Pulled (modified): {rel_path}")
        total += 1

    action = "Would sync" if dry_run else "Synced"
    in_sync = len(status.get("in_sync", []))
    safe_print(f"\n{action} {total} files. {in_sync} already in sync.")
    return total


def show_sync_status(config=None):
    """Print sync status to console."""
    if config is None:
        config = get_config()

    vault_path = get_vault_path(config)
    if not vault_path:
        safe_print("No vault configured.")
        safe_print("Run: claude-memory vault --init /path/to/cloud/folder")
        return

    status = get_sync_status(config)

    safe_print(f"\n=== Vault Sync Status ===")
    safe_print(f"  Vault:     {status['vault_path']}")
    safe_print(f"  Local:     {status['data_dir']}")

    in_sync = len(status.get("in_sync", []))
    local_only = len(status.get("local_only", []))
    vault_only = len(status.get("vault_only", []))
    mod_local = len(status.get("modified_local", []))
    mod_vault = len(status.get("modified_vault", []))

    safe_print(f"\n  In sync:          {in_sync}")
    safe_print(f"  Local only:       {local_only}")
    safe_print(f"  Vault only:       {vault_only}")
    safe_print(f"  Modified locally: {mod_local}")
    safe_print(f"  Modified in vault:{mod_vault}")

    if local_only > 0:
        safe_print(f"\n  Local-only files (need push):")
        for f in status["local_only"][:10]:
            safe_print(f"    + {f}")

    if vault_only > 0:
        safe_print(f"\n  Vault-only files (need pull):")
        for f in status["vault_only"][:10]:
            safe_print(f"    + {f}")

    if mod_local > 0:
        safe_print(f"\n  Modified locally (need push):")
        for f in status["modified_local"][:10]:
            safe_print(f"    ~ {f}")

    if mod_vault > 0:
        safe_print(f"\n  Modified in vault (need pull):")
        for f in status["modified_vault"][:10]:
            safe_print(f"    ~ {f}")

    total_pending = local_only + vault_only + mod_local + mod_vault
    if total_pending == 0:
        safe_print(f"\n  Everything is in sync!")
    else:
        safe_print(f"\n  Run 'claude-memory vault --sync' to synchronize.")


def append_to_changelog(message, config=None):
    """Append an entry to the vault changelog.

    Args:
        message: Entry text.
        config: Configuration dict.
    """
    if config is None:
        config = get_config()

    vault_path = get_vault_path(config)
    if not vault_path:
        return

    changelog = os.path.join(vault_path, "changelog.md")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    with open(changelog, "a", encoding="utf-8") as f:
        f.write(f"- [{timestamp}] {message}\n")
