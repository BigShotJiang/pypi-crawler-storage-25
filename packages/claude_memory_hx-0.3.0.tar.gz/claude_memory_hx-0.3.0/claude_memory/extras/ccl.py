"""
Context Compression Language (CCL) -- Reduce token usage in system prompts.

CCL is a shorthand notation system that compresses natural language instructions
into a compact format that LLMs can still interpret. This is especially useful
for system prompts, CLAUDE.md files, and other context that gets loaded into
every conversation.

Compression tiers:
    T0 -- Full English (no compression)
    T1 -- Light: abbreviations, dropped articles (30-40% savings)
    T2 -- Medium: symbols, arrows, compressed structure (50-60% savings)
    T3 -- Heavy: maximum density, telegraphic (65-75% savings)

The key insight: LLMs are trained on enough internet text that they can decode
most common abbreviations and shorthand. "wr->VLT" is unambiguous to Claude
when it appears in context with "vault" defined earlier.

Usage (CLI):
    claude-memory ccl --encode input.md              # Compress to T2 (default)
    claude-memory ccl --encode input.md --tier 3     # Maximum compression
    claude-memory ccl --decode input.md              # Expand back to English
    claude-memory ccl --analyze input.md             # Show token savings estimate
    claude-memory ccl --dict                         # Show compression dictionary

Usage (Python):
    from claude_memory.extras.ccl import encode, decode, analyze, DICTIONARY
"""

import re
import os

from ..search import safe_print


# --- Compression Dictionary ---
# Maps full phrases to compressed forms. Applied in order (longer matches first).

DICTIONARY = {
    # Structural
    "important": "[!]",
    "IMPORTANT": "[!]",
    "remember": "[!]",
    "never": "!",
    "always": "@",
    "should": "shd",
    "would": "wd",
    "could": "cd",
    "before": "b4",
    "after": "aft",
    "between": "btw",
    "without": "w/o",
    "with": "w/",
    "and": "+",
    "or": "|",
    "the": "",
    "this": "",
    "that": "",
    "which": "",
    "a ": " ",
    "an ": " ",

    # Actions
    "write": "wr",
    "read": "rd",
    "update": "upd",
    "delete": "del",
    "create": "cr",
    "check": "chk",
    "execute": "exec",
    "return": "ret",
    "function": "fn",
    "variable": "var",
    "parameter": "param",
    "configuration": "cfg",
    "configure": "cfg",
    "config": "cfg",
    "directory": "dir",
    "file": "f",
    "files": "fs",
    "information": "info",
    "application": "app",
    "database": "db",
    "environment": "env",
    "repository": "repo",
    "message": "msg",
    "messages": "msgs",
    "response": "resp",
    "request": "req",

    # Connectors
    "because": "bc",
    "therefore": "=>",
    "however": "but",
    "for example": "eg.",
    "such as": "eg.",
    "including": "incl.",
    "especially": "esp.",
    "approximately": "~",
    "immediately": "NOW",
    "required": "req'd",
    "necessary": "req'd",
    "available": "avail",
    "following": "foll",

    # Technical
    "conversation": "conv",
    "compaction": "CMP",
    "compression": "comp",
    "context window": "CW",
    "system prompt": "sysprompt",
    "instructions": "instr",
    "narrative": "narr",
    "session": "sess",
    "portable drive": "PD",
    "vault": "VLT",
    "memory": "mem",
    "changelog": "chlog",
    "timestamp": "ts",
    "document": "doc",
    "documents": "docs",
}

# Reverse dictionary for decoding
REVERSE_DICTIONARY = {}
for full, short in DICTIONARY.items():
    if short and short not in ("", " "):
        REVERSE_DICTIONARY[short] = full


def _word_count(text):
    """Rough word/token count."""
    return len(text.split())


def _char_count(text):
    """Character count excluding whitespace."""
    return len(text.replace(" ", "").replace("\n", ""))


def encode(text, tier=2):
    """Compress text using CCL notation.

    Args:
        text: Input text to compress.
        tier: Compression level (0-3).
            0 = no compression
            1 = light (drop articles, common abbreviations)
            2 = medium (symbols, arrows, structural compression)
            3 = heavy (telegraphic, maximum density)

    Returns:
        Compressed text string.
    """
    if tier == 0:
        return text

    result = text

    if tier >= 1:
        # T1: Drop articles, basic abbreviations
        light_subs = {
            "important": "[!]",
            "remember": "[!]",
            "configuration": "config",
            "application": "app",
            "information": "info",
            "environment": "env",
            "repository": "repo",
            "directory": "dir",
            "database": "db",
            "for example": "eg.",
            "such as": "eg.",
            "approximately": "~",
            "immediately": "NOW",
            "including": "incl.",
            "especially": "esp.",
        }
        for full, short in light_subs.items():
            result = re.sub(re.escape(full), short, result, flags=re.IGNORECASE)

        # Drop articles (careful: only standalone words)
        result = re.sub(r'\bthe\b\s*', '', result, flags=re.IGNORECASE)
        result = re.sub(r'\ba\b\s+', ' ', result)
        result = re.sub(r'\ban\b\s+', ' ', result)

    if tier >= 2:
        # T2: Symbols and structural compression
        medium_subs = {
            "write": "wr",
            "read": "rd",
            "update": "upd",
            "delete": "del",
            "create": "cr",
            "check": "chk",
            "execute": "exec",
            "return": "ret",
            "function": "fn",
            "variable": "var",
            "parameter": "param",
            "message": "msg",
            "response": "resp",
            "request": "req",
            "document": "doc",
            "session": "sess",
            "narrative": "narr",
            "conversation": "conv",
            "compaction": "CMP",
            "compression": "comp",
            "context window": "CW",
            "timestamp": "ts",
            "changelog": "chlog",
            "because": "bc",
            "therefore": "=>",
            "however": "but",
            "without": "w/o",
            "required": "req'd",
            "necessary": "req'd",
            "available": "avail",
        }
        for full, short in medium_subs.items():
            result = re.sub(
                r'\b' + re.escape(full) + r'\b',
                short, result, flags=re.IGNORECASE
            )

        # Arrow notation for flows
        result = result.replace(" to ", "->")
        result = result.replace(" into ", "->")

    if tier >= 3:
        # T3: Telegraphic -- strip all unnecessary words
        telegraphic_drops = [
            r'\bthat\b\s*',
            r'\bwhich\b\s*',
            r'\bthis\b\s*',
            r'\bwhen\b\s*',
            r'\bis\b\s+',
            r'\bare\b\s+',
            r'\bwas\b\s+',
            r'\bwere\b\s+',
            r'\bbeen\b\s+',
            r'\bbeing\b\s+',
            r'\bhave\b\s+',
            r'\bhas\b\s+',
            r'\bhad\b\s+',
            r'\bwill\b\s+',
            r'\bshould\b\s+',
            r'\bwould\b\s+',
            r'\bcould\b\s+',
            r'\bmust\b\s+',
            r'\bcan\b\s+',
            r'\bmay\b\s+',
            r'\bmight\b\s+',
            r'\bdo\b\s+',
            r'\bdoes\b\s+',
            r'\bdid\b\s+',
        ]
        for pattern in telegraphic_drops:
            result = re.sub(pattern, '', result, flags=re.IGNORECASE)

        # Replace "and" with "+"
        result = re.sub(r'\band\b', '+', result, flags=re.IGNORECASE)
        result = re.sub(r'\bor\b', '|', result, flags=re.IGNORECASE)

        # Collapse bullet points
        result = re.sub(r'\n\s*[-*]\s+', '\n- ', result)

    # Clean up multiple spaces
    result = re.sub(r'  +', ' ', result)
    result = re.sub(r'\n +', '\n', result)
    result = re.sub(r'\n{3,}', '\n\n', result)

    return result.strip()


def decode(text):
    """Expand CCL-compressed text back to readable English.

    Note: This is a best-effort expansion. Some context may be lost
    in heavy compression that can't be perfectly reversed.

    Args:
        text: CCL-compressed text.

    Returns:
        Expanded text string.
    """
    result = text

    # Expand symbols first
    symbol_expansions = [
        ("[!]", "IMPORTANT"),
        ("=>", "therefore"),
        ("->", " to "),
        ("w/o", "without"),
        ("w/", "with "),
        ("@", "always"),
        ("eg.", "for example"),
        ("~", "approximately"),
        ("bc", "because"),
        ("esp.", "especially"),
        ("incl.", "including"),
    ]
    for short, full in symbol_expansions:
        result = result.replace(short, full)

    # Expand abbreviations (word-boundary aware)
    abbrev_expansions = [
        ("wr", "write"),
        ("rd", "read"),
        ("upd", "update"),
        ("del", "delete"),
        ("cr", "create"),
        ("chk", "check"),
        ("fn", "function"),
        ("var", "variable"),
        ("param", "parameter"),
        ("cfg", "config"),
        ("dir", "directory"),
        ("db", "database"),
        ("env", "environment"),
        ("repo", "repository"),
        ("msg", "message"),
        ("resp", "response"),
        ("req", "request"),
        ("doc", "document"),
        ("sess", "session"),
        ("narr", "narrative"),
        ("conv", "conversation"),
        ("CMP", "compaction"),
        ("comp", "compression"),
        ("CW", "context window"),
        ("ts", "timestamp"),
        ("chlog", "changelog"),
        ("VLT", "vault"),
        ("mem", "memory"),
        ("PD", "portable drive"),
    ]
    for short, full in abbrev_expansions:
        result = re.sub(r'\b' + re.escape(short) + r'\b', full, result)

    return result.strip()


def analyze(text, tier=2):
    """Analyze potential compression savings.

    Args:
        text: Input text to analyze.
        tier: Compression tier to test.

    Returns:
        Dict with original_words, compressed_words, savings_percent, etc.
    """
    compressed = encode(text, tier=tier)

    orig_words = _word_count(text)
    comp_words = _word_count(compressed)
    orig_chars = _char_count(text)
    comp_chars = _char_count(compressed)

    # Rough token estimate (1 token ~ 4 chars or 0.75 words)
    orig_tokens = max(orig_words, orig_chars // 4)
    comp_tokens = max(comp_words, comp_chars // 4)

    word_savings = (1 - comp_words / orig_words) * 100 if orig_words > 0 else 0
    char_savings = (1 - comp_chars / orig_chars) * 100 if orig_chars > 0 else 0
    token_savings = (1 - comp_tokens / orig_tokens) * 100 if orig_tokens > 0 else 0

    return {
        "tier": tier,
        "original_words": orig_words,
        "compressed_words": comp_words,
        "original_chars": orig_chars,
        "compressed_chars": comp_chars,
        "estimated_original_tokens": orig_tokens,
        "estimated_compressed_tokens": comp_tokens,
        "word_savings_percent": round(word_savings, 1),
        "char_savings_percent": round(char_savings, 1),
        "token_savings_percent": round(token_savings, 1),
    }


def show_analysis(filepath, tier=2):
    """Analyze a file and print compression savings."""
    if not os.path.exists(filepath):
        safe_print(f"File not found: {filepath}")
        return

    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()

    safe_print(f"\n=== CCL Analysis: {os.path.basename(filepath)} ===\n")

    for t in range(4):
        stats = analyze(text, tier=t)
        label = ["T0 (none)", "T1 (light)", "T2 (medium)", "T3 (heavy)"][t]
        marker = " <--" if t == tier else ""
        safe_print(
            f"  {label}: {stats['original_words']} -> "
            f"{stats['compressed_words']} words "
            f"({stats['word_savings_percent']}% saved, "
            f"~{stats['estimated_compressed_tokens']} tokens){marker}"
        )

    safe_print(f"\n  Selected tier: T{tier}")
    compressed = encode(text, tier=tier)
    safe_print(f"\n--- Preview (first 500 chars) ---")
    safe_print(compressed[:500])
    if len(compressed) > 500:
        safe_print("...")


def show_dictionary():
    """Print the compression dictionary."""
    safe_print("\n=== CCL Compression Dictionary ===\n")
    safe_print(f"  {'Full Form':<30s} {'Compressed':>15s}")
    safe_print(f"  {'-'*30} {'-'*15}")

    for full, short in sorted(DICTIONARY.items(), key=lambda x: x[0].lower()):
        if short:
            safe_print(f"  {full:<30s} {short:>15s}")
        else:
            safe_print(f"  {full:<30s} {'(dropped)':>15s}")

    safe_print(f"\n  Total entries: {len(DICTIONARY)}")


def encode_file(input_path, output_path=None, tier=2):
    """Compress a file using CCL notation.

    Args:
        input_path: Path to input file.
        output_path: Path for output. If None, prints to console.
        tier: Compression tier (0-3).

    Returns:
        Compressed text string.
    """
    with open(input_path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()

    compressed = encode(text, tier=tier)

    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(compressed)
        stats = analyze(text, tier=tier)
        safe_print(f"Compressed: {input_path}")
        safe_print(f"  Output:  {output_path}")
        safe_print(f"  Savings: {stats['word_savings_percent']}% "
                    f"({stats['original_words']} -> {stats['compressed_words']} words)")
    else:
        safe_print(compressed)

    return compressed


def decode_file(input_path, output_path=None):
    """Expand a CCL-compressed file back to readable English.

    Args:
        input_path: Path to compressed file.
        output_path: Path for output. If None, prints to console.

    Returns:
        Expanded text string.
    """
    with open(input_path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()

    expanded = decode(text)

    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(expanded)
        safe_print(f"Expanded: {input_path} -> {output_path}")
    else:
        safe_print(expanded)

    return expanded
