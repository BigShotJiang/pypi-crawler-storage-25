"""
Compaction Watcher -- Monitor Claude Code context compaction events.

Claude Code periodically compresses its conversation context when the window
fills up. This module detects those compaction events by monitoring the JSONL
conversation files for size drops, and logs each event with timestamp and
metadata.

Why this matters: Context compaction is the #1 cause of AI amnesia. By tracking
when compactions happen, you can correlate lost context with specific sessions,
build dashboards, and train yourself to file important information before the
window fills up.

Usage (CLI):
    claude-memory compaction --watch          # Watch for compaction events (blocking)
    claude-memory compaction --scan           # Scan recent conversations for past events
    claude-memory compaction --stats          # Show compaction statistics
    claude-memory compaction --log            # Show compaction log

Usage (Python):
    from claude_memory.extras.compaction_watcher import (
        scan_for_compactions, watch_compactions, get_compaction_stats,
    )
"""

import os
import json
import time
import datetime
import hashlib

from ..config import get_config
from ..search import safe_print


DEFAULT_COMPACTION_LOG = "compaction_log.json"
DEFAULT_STATE_FILE = "compaction_state.json"

# Claude Code stores conversations here
CLAUDE_PROJECTS_DIR = os.path.join(os.path.expanduser("~"), ".claude", "projects")


def _compaction_log_path(config):
    """Path to the compaction event log."""
    return os.path.join(config.get("data_dir", ""), DEFAULT_COMPACTION_LOG)


def _state_path(config):
    """Path to the watcher state file (tracks file sizes between runs)."""
    return os.path.join(config.get("data_dir", ""), DEFAULT_STATE_FILE)


def _load_json(path):
    """Load a JSON file, returning empty dict/list on failure."""
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_json(data, path):
    """Save data as JSON."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


def find_conversation_files(projects_dir=None):
    """Find all Claude Code JSONL conversation files.

    Returns:
        List of (project_key, filepath) tuples.
    """
    if projects_dir is None:
        projects_dir = CLAUDE_PROJECTS_DIR

    results = []
    if not os.path.isdir(projects_dir):
        return results

    for project_dir in os.listdir(projects_dir):
        project_path = os.path.join(projects_dir, project_dir)
        if not os.path.isdir(project_path):
            continue
        for fname in os.listdir(project_path):
            if fname.endswith(".jsonl"):
                fpath = os.path.join(project_path, fname)
                results.append((project_dir, fpath))

    return results


def detect_compaction_in_file(filepath):
    """Check a JSONL file for compaction markers.

    Claude Code compaction events can be detected by:
    1. A 'summary' message type appearing in the conversation
    2. A significant drop in line count between reads

    Returns:
        List of detected compaction events with timestamps.
    """
    events = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # Look for compaction markers in the message content
                msg_type = entry.get("type", "")
                role = entry.get("role", "")
                content = ""

                if isinstance(entry.get("content"), str):
                    content = entry["content"]
                elif isinstance(entry.get("content"), list):
                    for block in entry["content"]:
                        if isinstance(block, dict) and block.get("type") == "text":
                            content += block.get("text", "")

                content_lower = content.lower()

                # Detect compaction summary messages
                if ("summary" in msg_type or
                    "context" in msg_type and "compress" in content_lower or
                    "conversation that ran out of context" in content_lower or
                    "previous conversation" in content_lower and "summary" in content_lower):
                    events.append({
                        "line": line_num,
                        "type": msg_type or role,
                        "preview": content[:200] if content else "(no content)",
                    })

    except OSError:
        pass

    return events


def scan_for_compactions(config=None, projects_dir=None):
    """Scan all conversation files for compaction events.

    Args:
        config: Configuration dict.
        projects_dir: Override for Claude projects directory.

    Returns:
        List of compaction event dicts.
    """
    if config is None:
        config = get_config()

    conversations = find_conversation_files(projects_dir)
    all_events = []

    for project_key, filepath in conversations:
        events = detect_compaction_in_file(filepath)
        if events:
            fsize = os.path.getsize(filepath)
            mtime = datetime.datetime.fromtimestamp(
                os.path.getmtime(filepath)
            ).isoformat()

            for event in events:
                all_events.append({
                    "timestamp": mtime,
                    "project": project_key,
                    "file": os.path.basename(filepath),
                    "file_size": fsize,
                    "line": event["line"],
                    "type": event["type"],
                    "preview": event["preview"],
                })

    return all_events


def watch_compactions(config=None, interval=30, callback=None):
    """Watch for new compaction events by monitoring file sizes.

    This runs in a loop, checking conversation file sizes every `interval`
    seconds. A significant size drop (>20%) indicates a compaction event.

    Args:
        config: Configuration dict.
        interval: Seconds between checks.
        callback: Optional function called with each new event dict.
    """
    if config is None:
        config = get_config()

    state_path = _state_path(config)
    log_path = _compaction_log_path(config)

    state = _load_json(state_path)
    if not isinstance(state, dict):
        state = {}

    safe_print(f"Compaction watcher started (checking every {interval}s)")
    safe_print(f"Monitoring: {CLAUDE_PROJECTS_DIR}")
    safe_print(f"Log file:   {log_path}")
    safe_print("Press Ctrl+C to stop.\n")

    try:
        while True:
            conversations = find_conversation_files()

            for project_key, filepath in conversations:
                try:
                    current_size = os.path.getsize(filepath)
                except OSError:
                    continue

                prev_size = state.get(filepath, {}).get("size", 0)

                # Detect compaction: file size dropped significantly
                if prev_size > 0 and current_size < prev_size * 0.80:
                    drop_pct = (1 - current_size / prev_size) * 100
                    now = datetime.datetime.now().isoformat()

                    event = {
                        "timestamp": now,
                        "project": project_key,
                        "file": os.path.basename(filepath),
                        "prev_size": prev_size,
                        "new_size": current_size,
                        "drop_percent": round(drop_pct, 1),
                    }

                    # Log it
                    log = _load_json(log_path)
                    if not isinstance(log, list):
                        log = []
                    log.append(event)
                    _save_json(log, log_path)

                    safe_print(
                        f"[COMPACTION] {now[:19]} | {project_key} | "
                        f"{prev_size:,} -> {current_size:,} bytes "
                        f"(-{drop_pct:.0f}%)"
                    )

                    if callback:
                        callback(event)

                state[filepath] = {
                    "size": current_size,
                    "checked": datetime.datetime.now().isoformat(),
                }

            _save_json(state, state_path)
            time.sleep(interval)

    except KeyboardInterrupt:
        safe_print("\nWatcher stopped.")
        _save_json(state, state_path)


def get_compaction_stats(config=None):
    """Get summary statistics from the compaction log.

    Returns:
        Dict with total_events, events_by_project, avg_drop_percent, etc.
    """
    if config is None:
        config = get_config()

    log_path = _compaction_log_path(config)
    log = _load_json(log_path)

    if not isinstance(log, list) or not log:
        return {"total_events": 0}

    by_project = {}
    drops = []

    for event in log:
        proj = event.get("project", "unknown")
        by_project[proj] = by_project.get(proj, 0) + 1
        if "drop_percent" in event:
            drops.append(event["drop_percent"])

    return {
        "total_events": len(log),
        "events_by_project": by_project,
        "avg_drop_percent": round(sum(drops) / len(drops), 1) if drops else 0,
        "max_drop_percent": max(drops) if drops else 0,
        "first_event": log[0].get("timestamp", "?"),
        "last_event": log[-1].get("timestamp", "?"),
    }


def show_compaction_log(config=None, limit=20):
    """Print the compaction log to console."""
    if config is None:
        config = get_config()

    log_path = _compaction_log_path(config)
    log = _load_json(log_path)

    if not isinstance(log, list) or not log:
        safe_print("No compaction events recorded yet.")
        safe_print("Run: claude-memory compaction --watch")
        return

    safe_print(f"\n=== Compaction Log ({len(log)} events) ===\n")

    for event in log[-limit:]:
        ts = event.get("timestamp", "?")[:19]
        proj = event.get("project", "?")
        drop = event.get("drop_percent", "?")

        if "prev_size" in event:
            prev = event["prev_size"]
            new = event["new_size"]
            safe_print(f"  [{ts}] {proj}")
            safe_print(f"    {prev:,} -> {new:,} bytes (-{drop}%)")
        else:
            safe_print(f"  [{ts}] {proj} -- {event.get('type', '?')}")
            preview = event.get("preview", "")[:100]
            if preview:
                safe_print(f"    {preview}")
        safe_print("")


def show_compaction_stats(config=None):
    """Print compaction statistics to console."""
    if config is None:
        config = get_config()

    stats = get_compaction_stats(config)

    if stats["total_events"] == 0:
        safe_print("No compaction events recorded yet.")
        return

    safe_print(f"\n=== Compaction Statistics ===")
    safe_print(f"  Total events:     {stats['total_events']}")
    safe_print(f"  Avg size drop:    {stats['avg_drop_percent']}%")
    safe_print(f"  Max size drop:    {stats['max_drop_percent']}%")
    safe_print(f"  First event:      {stats['first_event'][:19]}")
    safe_print(f"  Last event:       {stats['last_event'][:19]}")

    if stats.get("events_by_project"):
        safe_print(f"\n  By project:")
        for proj, count in sorted(
            stats["events_by_project"].items(),
            key=lambda x: x[1], reverse=True
        ):
            safe_print(f"    {proj}: {count}")
