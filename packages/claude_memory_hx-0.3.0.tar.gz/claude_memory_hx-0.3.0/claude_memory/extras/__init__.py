"""
Optional modules for claude-memory.

These extend the core memory system with additional capabilities:

- compaction_watcher: Monitor Claude Code context compaction events
- ccl: Context Compression Language for reducing token usage
- vault_sync: Multi-machine memory synchronization via cloud folders
"""
