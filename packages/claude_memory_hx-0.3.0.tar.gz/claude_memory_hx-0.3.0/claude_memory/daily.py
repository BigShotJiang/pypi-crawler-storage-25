"""
Daily Log Manager.

Creates and manages daily log files. On boot, loads today's and yesterday's
logs to give a new AI instance immediate context about recent work.

Can be used as a library or run directly:
    python -m claude_memory.daily --load
"""

import os
import datetime

from .config import get_config
from .search import safe_print


def today_str():
    """Today's date as ISO string (YYYY-MM-DD)."""
    return datetime.date.today().isoformat()


def yesterday_str():
    """Yesterday's date as ISO string (YYYY-MM-DD)."""
    return (datetime.date.today() - datetime.timedelta(days=1)).isoformat()


def log_path(date_str, config=None):
    """Get the file path for a given date's log."""
    if config is None:
        config = get_config()
    daily_dir = config["daily_log_dir"]
    return os.path.join(daily_dir, f"{date_str}.md")


def init_daily_log(config=None):
    """Create today's log file if it doesn't exist.

    Returns:
        Path to today's log file.
    """
    if config is None:
        config = get_config()

    daily_dir = config["daily_log_dir"]
    os.makedirs(daily_dir, exist_ok=True)

    path = log_path(today_str(), config)
    if not os.path.exists(path):
        d = today_str()
        day_name = datetime.date.today().strftime("%A")
        # ISO week for linking
        iso = datetime.date.today().isocalendar()
        week_link = f"{iso[0]}-W{iso[1]:02d}"
        with open(path, "w", encoding="utf-8") as f:
            f.write(f'---\ntitle: "Daily Log - {d}"\n')
            f.write(f'type: journal\ncategory: daily\nstatus: active\n')
            f.write(f'created: "{d}"\nupdated: "{d}"\n')
            f.write(f'tags:\n  - type/timeline/daily\n  - time/daily\n  - status/active\n')
            f.write(f'week: "[[{week_link}]]"\nday: "{day_name}"\n')
            f.write(f'---\n\n# Daily Log -- {d}\n\n')
        safe_print(f"Created: {path}")
    else:
        safe_print(f"Already exists: {path}")
    return path


def append_to_log(message, config=None):
    """Append a timestamped entry to today's log.

    Args:
        message: Text to append.
        config: Configuration dict. Loaded from defaults if None.
    """
    if config is None:
        config = get_config()

    path = init_daily_log(config)
    timestamp = datetime.datetime.now().strftime("%H:%M")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"\n**{timestamp}** -- {message}\n")
    safe_print(f"Logged to {today_str()}.md")


def load_recent(config=None):
    """Load today's and yesterday's logs.

    Returns:
        Combined text of recent logs, suitable for injecting into
        an AI assistant's context window.
    """
    if config is None:
        config = get_config()

    output = []
    for label, date_str in [("YESTERDAY", yesterday_str()), ("TODAY", today_str())]:
        path = log_path(date_str, config)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read().strip()
            if content:
                output.append(f"--- {label} ({date_str}) ---\n{content}")

    if not output:
        return "No recent daily logs found."

    return "\n\n".join(output)


def show_today(config=None):
    """Print today's log to console."""
    if config is None:
        config = get_config()

    path = log_path(today_str(), config)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            safe_print(f.read())
    else:
        safe_print(f"No log for today ({today_str()}). Use: claude-memory daily --init")
