"""
Periodic Log Manager -- Weekly, Monthly, Quarterly, and Yearly notes.

Synthesizes daily logs into higher-level summaries at each time horizon.

Usage (via CLI):
    claude-memory weekly                    # Show/create this week's note
    claude-memory monthly                   # Show/create this month's note
    claude-memory quarterly                 # Show/create this quarter's note
    claude-memory yearly                    # Show/create this year's note

    claude-memory weekly --synthesize       # Generate from daily logs
    claude-memory monthly --synthesize      # Generate from weekly notes
    claude-memory quarterly --synthesize    # Generate from monthly notes
    claude-memory yearly --synthesize       # Generate from quarterly notes

    claude-memory weekly --append "note"    # Append to this week's note
    claude-memory monthly --append "note"   # Append to this month's note

    claude-memory periodic --load           # Load current week + month context
    claude-memory periodic --all            # Show all current period notes

    claude-memory weekly --list             # List all weekly notes
    claude-memory monthly --list            # List all monthly notes

File structure under data_dir:
    weekly/       2026-W11.md
    monthly/      2026-03.md
    quarterly/    2026-Q1.md
    yearly/       2026.md
"""

import os
import glob
import datetime

from .config import get_config
from .search import safe_print

# Valid period names
PERIODS = ("weekly", "monthly", "quarterly", "yearly")

# Config key mapping: period name -> config key for that directory
PERIOD_DIR_KEYS = {
    "daily": "daily_log_dir",
    "weekly": "weekly_dir",
    "monthly": "monthly_dir",
    "quarterly": "quarterly_dir",
    "yearly": "yearly_dir",
}


# --- Date helpers ---

def today():
    return datetime.date.today()


def current_week_str():
    """ISO week: 2026-W11"""
    d = today()
    return f"{d.isocalendar()[0]}-W{d.isocalendar()[1]:02d}"


def current_month_str():
    """2026-03"""
    return today().strftime("%Y-%m")


def current_quarter_str():
    """2026-Q1"""
    d = today()
    q = (d.month - 1) // 3 + 1
    return f"{d.year}-Q{q}"


def current_year_str():
    """2026"""
    return str(today().year)


def previous_week_str():
    d = today() - datetime.timedelta(weeks=1)
    return f"{d.isocalendar()[0]}-W{d.isocalendar()[1]:02d}"


def previous_month_str():
    d = today().replace(day=1) - datetime.timedelta(days=1)
    return d.strftime("%Y-%m")


def week_date_range(week_str):
    """Given '2026-W11', return (start_date, end_date) for that ISO week."""
    year, week_num = week_str.split("-W")
    year = int(year)
    week_num = int(week_num)
    # Monday of that ISO week
    jan4 = datetime.date(year, 1, 4)
    start = jan4 + datetime.timedelta(weeks=week_num - 1, days=-jan4.weekday())
    end = start + datetime.timedelta(days=6)
    return start, end


def month_date_range(month_str):
    """Given '2026-03', return (start_date, end_date)."""
    year, month = month_str.split("-")
    year = int(year)
    month = int(month)
    start = datetime.date(year, month, 1)
    if month == 12:
        end = datetime.date(year + 1, 1, 1) - datetime.timedelta(days=1)
    else:
        end = datetime.date(year, month + 1, 1) - datetime.timedelta(days=1)
    return start, end


def quarter_months(quarter_str):
    """Given '2026-Q1', return list of month strings ['2026-01', '2026-02', '2026-03']."""
    year, q = quarter_str.split("-Q")
    year = int(year)
    q = int(q)
    start_month = (q - 1) * 3 + 1
    return [f"{year}-{m:02d}" for m in range(start_month, start_month + 3)]


def year_quarters(year_str):
    """Given '2026', return quarter strings."""
    return [f"{year_str}-Q{q}" for q in range(1, 5)]


# --- Period key for each level ---

def period_key(period):
    """Get the current period identifier string."""
    if period == "weekly":
        return current_week_str()
    elif period == "monthly":
        return current_month_str()
    elif period == "quarterly":
        return current_quarter_str()
    elif period == "yearly":
        return current_year_str()
    return None


def get_period_dir(period, config=None):
    """Get the directory for a given period level from config."""
    if config is None:
        config = get_config()
    dir_key = PERIOD_DIR_KEYS.get(period)
    if dir_key and dir_key in config:
        return config[dir_key]
    # Fallback: period subdir under data_dir
    return os.path.join(config["data_dir"], period)


def period_path(period, key=None, config=None):
    """Full path to a period's note file."""
    if key is None:
        key = period_key(period)
    d = get_period_dir(period, config)
    return os.path.join(d, f"{key}.md")


# --- Template headers ---

def frontmatter(period, key):
    """Generate YAML frontmatter for Obsidian/Dataview compatibility."""
    today_iso = today().isoformat()
    tag_period = period.rstrip("ly")  # weekly -> week, monthly -> month, etc.
    if period == "quarterly":
        tag_period = "quarterly"
    elif period == "yearly":
        tag_period = "yearly"
    fm = f'---\ntitle: "{period.title()} Note - {key}"\n'
    fm += f'type: journal\ncategory: {period}\nstatus: active\n'
    fm += f'created: "{today_iso}"\nupdated: "{today_iso}"\n'
    fm += f'tags:\n  - type/timeline/{period}\n  - time/{tag_period}\n  - status/active\n'
    fm += f'period: "{key}"\n---\n\n'
    return fm


def period_header(period, key):
    """Generate a template header for a new period note."""
    fm = frontmatter(period, key)
    if period == "weekly":
        start, end = week_date_range(key)
        return f"{fm}# Weekly Note -- {key}\n**Period:** {start.isoformat()} to {end.isoformat()}\n"
    elif period == "monthly":
        start, end = month_date_range(key)
        return f"{fm}# Monthly Note -- {key}\n**Period:** {start.isoformat()} to {end.isoformat()}\n"
    elif period == "quarterly":
        months = quarter_months(key)
        return f"{fm}# Quarterly Note -- {key}\n**Months:** {', '.join(months)}\n"
    elif period == "yearly":
        return f"{fm}# Yearly Note -- {key}\n**Year:** {key}\n"
    return f"{fm}# {period.title()} Note -- {key}\n"


def synthesis_template(period, key):
    """Generate the full template for a synthesized note."""
    header = period_header(period, key)

    if period == "weekly":
        return f"""{header}
## Key Accomplishments


## Decisions Made


## Open Items


## Patterns & Observations


## Next Week Focus

"""
    elif period == "monthly":
        return f"""{header}
## Summary


## Key Accomplishments


## Decisions Made


## Projects Status


## Patterns & Observations


## Wins


## Lessons Learned


## Next Month Focus

"""
    elif period == "quarterly":
        return f"""{header}
## Quarter Summary


## Major Milestones


## Project Status


## Key Decisions


## Metrics / Progress


## Patterns & Themes


## Next Quarter Objectives

"""
    elif period == "yearly":
        return f"""{header}
## Year in Review


## Major Milestones


## Projects Completed


## Projects In Progress


## Key Decisions & Pivots


## Growth & Learning


## Next Year Vision

"""
    return header + "\n"


# --- Core operations ---

def init_period(period, key=None, config=None):
    """Create a period note if it doesn't exist.

    Args:
        period: One of 'weekly', 'monthly', 'quarterly', 'yearly'.
        key: Period identifier (e.g., '2026-W11'). Defaults to current.
        config: Configuration dict. Loaded from defaults if None.

    Returns:
        Path to the period note file.
    """
    if config is None:
        config = get_config()
    if key is None:
        key = period_key(period)
    d = get_period_dir(period, config)
    os.makedirs(d, exist_ok=True)
    path = period_path(period, key, config)
    if not os.path.exists(path):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(synthesis_template(period, key))
        safe_print(f"Created: {path}")
    else:
        safe_print(f"Already exists: {path}")
    return path


def append_to_period(period, message, key=None, config=None):
    """Append a timestamped entry to a period note.

    Args:
        period: One of 'weekly', 'monthly', 'quarterly', 'yearly'.
        message: Text to append.
        key: Period identifier. Defaults to current.
        config: Configuration dict. Loaded from defaults if None.
    """
    if config is None:
        config = get_config()
    path = init_period(period, key, config)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    with open(path, 'a', encoding='utf-8') as f:
        f.write(f"\n**{timestamp}** -- {message}\n")
    k = key or period_key(period)
    safe_print(f"Logged to {k}.md")


def show_period(period, key=None, config=None):
    """Print a period note.

    Args:
        period: One of 'weekly', 'monthly', 'quarterly', 'yearly'.
        key: Period identifier. Defaults to current.
        config: Configuration dict. Loaded from defaults if None.
    """
    if config is None:
        config = get_config()
    if key is None:
        key = period_key(period)
    path = period_path(period, key, config)
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            safe_print(f.read())
    else:
        safe_print(f"No {period} note for {key}. Use: claude-memory {period}")


def list_periods(period, config=None):
    """List all notes for a given period level.

    Args:
        period: One of 'weekly', 'monthly', 'quarterly', 'yearly'.
        config: Configuration dict. Loaded from defaults if None.
    """
    if config is None:
        config = get_config()
    d = get_period_dir(period, config)
    if not os.path.exists(d):
        safe_print(f"No {period} notes yet.")
        return
    files = sorted(glob.glob(os.path.join(d, "*.md")))
    if not files:
        safe_print(f"No {period} notes yet.")
        return
    safe_print(f"\n=== {period.title()} Notes ===")
    for f in files:
        name = os.path.basename(f)[:-3]  # strip .md
        size = os.path.getsize(f)
        mtime = datetime.datetime.fromtimestamp(os.path.getmtime(f)).strftime("%Y-%m-%d")
        safe_print(f"  {name}  ({size} bytes, modified {mtime})")


# --- Synthesis: pull from lower-level logs ---

def collect_lower_level_content(period, key=None, config=None):
    """Gather content from the level below for synthesis.

    weekly  <- daily logs from that week
    monthly <- weekly notes from that month
    quarterly <- monthly notes from that quarter
    yearly  <- quarterly notes from that year

    Args:
        period: One of 'weekly', 'monthly', 'quarterly', 'yearly'.
        key: Period identifier. Defaults to current.
        config: Configuration dict. Loaded from defaults if None.

    Returns:
        List of content strings from lower-level notes.
    """
    if config is None:
        config = get_config()
    if key is None:
        key = period_key(period)

    content_parts = []
    daily_dir = get_period_dir("daily", config)
    weekly_dir = get_period_dir("weekly", config)
    monthly_dir = get_period_dir("monthly", config)
    quarterly_dir = get_period_dir("quarterly", config)

    if period == "weekly":
        # Collect daily logs for this week
        start, end = week_date_range(key)
        current = start
        while current <= end:
            daily_path = os.path.join(daily_dir, f"{current.isoformat()}.md")
            if os.path.exists(daily_path):
                with open(daily_path, 'r', encoding='utf-8', errors='replace') as f:
                    text = f.read().strip()
                if text:
                    content_parts.append(f"### {current.isoformat()} ({current.strftime('%A')})\n{text}")
            current += datetime.timedelta(days=1)

    elif period == "monthly":
        # Collect weekly notes that fall in this month
        start, end = month_date_range(key)
        if os.path.exists(weekly_dir):
            for wf in sorted(glob.glob(os.path.join(weekly_dir, "*.md"))):
                wkey = os.path.basename(wf)[:-3]
                try:
                    ws, we = week_date_range(wkey)
                    # Include if any part of the week overlaps this month
                    if ws <= end and we >= start:
                        with open(wf, 'r', encoding='utf-8', errors='replace') as f:
                            text = f.read().strip()
                        if text:
                            content_parts.append(f"### {wkey}\n{text}")
                except (ValueError, IndexError):
                    pass

        # Also grab daily logs if no weekly notes exist
        if not content_parts:
            current = start
            while current <= end:
                daily_path = os.path.join(daily_dir, f"{current.isoformat()}.md")
                if os.path.exists(daily_path):
                    with open(daily_path, 'r', encoding='utf-8', errors='replace') as f:
                        text = f.read().strip()
                    if text:
                        content_parts.append(f"### {current.isoformat()}\n{text}")
                current += datetime.timedelta(days=1)

    elif period == "quarterly":
        # Collect monthly notes for this quarter
        months = quarter_months(key)
        for m in months:
            mpath = os.path.join(monthly_dir, f"{m}.md")
            if os.path.exists(mpath):
                with open(mpath, 'r', encoding='utf-8', errors='replace') as f:
                    text = f.read().strip()
                if text:
                    content_parts.append(f"### {m}\n{text}")

    elif period == "yearly":
        # Collect quarterly notes for this year
        quarters = year_quarters(key)
        for q in quarters:
            qpath = os.path.join(quarterly_dir, f"{q}.md")
            if os.path.exists(qpath):
                with open(qpath, 'r', encoding='utf-8', errors='replace') as f:
                    text = f.read().strip()
                if text:
                    content_parts.append(f"### {q}\n{text}")

    return content_parts


def synthesize_period(period, key=None, config=None):
    """Create a synthesis note by collecting lower-level content.

    This creates the note with the template + collected raw content.
    The Claude instance is expected to then edit it into a proper summary.

    Args:
        period: One of 'weekly', 'monthly', 'quarterly', 'yearly'.
        key: Period identifier. Defaults to current.
        config: Configuration dict. Loaded from defaults if None.

    Returns:
        Path to the synthesis note, or None if no source material found.
    """
    if config is None:
        config = get_config()
    if key is None:
        key = period_key(period)

    content_parts = collect_lower_level_content(period, key, config)

    if not content_parts:
        lower = {
            "weekly": "daily",
            "monthly": "weekly",
            "quarterly": "monthly",
            "yearly": "quarterly",
        }
        safe_print(f"No lower-level content found for {period} {key}.")
        safe_print(f"Make sure you have {lower.get(period, 'lower-level')} notes first.")
        return None

    # Build the synthesis note
    path = init_period(period, key, config)

    # Read existing template
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        existing = f.read()

    # Append the source material
    source_section = f"\n---\n\n## Source Material\n\n"
    source_section += "\n\n".join(content_parts)
    source_section += f"\n\n---\n*Synthesized on {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} from {len(content_parts)} source notes.*\n"

    with open(path, 'w', encoding='utf-8') as f:
        f.write(existing + source_section)

    safe_print(f"Synthesized {period} note: {key}")
    safe_print(f"  Sources: {len(content_parts)} notes collected")
    safe_print(f"  File: {path}")
    safe_print(f"\n  >> Now edit the template sections above the source material.")
    safe_print(f"  >> The source material is your raw input -- summarize it into the template.")

    return path


def load_periodic_context(config=None):
    """Load current week + month notes for instance boot context.

    Args:
        config: Configuration dict. Loaded from defaults if None.

    Returns:
        Combined text of current periodic notes.
    """
    if config is None:
        config = get_config()

    output = []

    for period, key_func in [("weekly", current_week_str), ("monthly", current_month_str)]:
        key = key_func()
        path = period_path(period, key, config)
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read().strip()
            if content:
                output.append(f"--- {period.upper()} ({key}) ---\n{content}")

    # Also load previous week if current is sparse
    prev_week = previous_week_str()
    prev_path = period_path("weekly", prev_week, config)
    if os.path.exists(prev_path):
        with open(prev_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read().strip()
        if content and len(content) > 100:
            output.append(f"--- LAST WEEK ({prev_week}) ---\n{content}")

    if not output:
        return "No weekly/monthly notes yet."

    return "\n\n".join(output)


def show_all_current(config=None):
    """Show all current period notes.

    Args:
        config: Configuration dict. Loaded from defaults if None.
    """
    if config is None:
        config = get_config()

    for period, key_func in [
        ("weekly", current_week_str),
        ("monthly", current_month_str),
        ("quarterly", current_quarter_str),
        ("yearly", current_year_str),
    ]:
        key = key_func()
        path = period_path(period, key, config)
        if os.path.exists(path):
            safe_print(f"\n{'='*60}")
            safe_print(f"  {period.upper()} -- {key}")
            safe_print(f"{'='*60}")
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                safe_print(f.read())
        else:
            safe_print(f"\n  {period.upper()} -- {key}: (not created yet)")
