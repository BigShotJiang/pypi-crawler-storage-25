"""
claude-memory: Persistent hybrid memory for AI coding assistants.

Provides vector + keyword search with temporal decay, delta-sync indexing,
daily log management, and a biological memory model (salience weighting,
retrieval strengthening, consolidation bonus).

Designed to give AI agents persistent context across sessions.
"""

__version__ = "0.3.0"

from .config import get_config, load_config, save_config, init_dirs
from .search import (
    hybrid_search,
    keyword_score,
    safe_print,
    biological_score,
    get_salience,
    get_retrieval_boost,
    get_consolidation_boost,
    record_access,
    show_access_stats,
    load_access_log,
    save_access_log,
    clear_consolidation_cache,
)
from .indexer import delta_index, show_stats
from .daily import load_recent, append_to_log, init_daily_log, show_today
from .periodic import (
    init_period, append_to_period, show_period, list_periods,
    synthesize_period, load_periodic_context, show_all_current,
    current_week_str, current_month_str, current_quarter_str, current_year_str,
    frontmatter,
)
