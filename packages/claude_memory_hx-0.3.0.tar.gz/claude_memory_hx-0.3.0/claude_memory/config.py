"""
Configuration management for claude-memory.

Loads settings from (in priority order):
1. Environment variables (CLAUDE_MEMORY_*)
2. Config file (~/.claude-memory/config.json or custom path)
3. Built-in defaults

All paths, weights, categories, and evergreen patterns are configurable.
"""

import os
import json
import math

# --- Defaults ---

DEFAULT_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".claude-memory")
DEFAULT_DATA_DIR = os.path.join(DEFAULT_CONFIG_DIR, "data")
DEFAULT_CONFIG_FILE = os.path.join(DEFAULT_CONFIG_DIR, "config.json")

DEFAULTS = {
    # Paths
    "config_dir": DEFAULT_CONFIG_DIR,
    "data_dir": DEFAULT_DATA_DIR,
    "chroma_dir": os.path.join(DEFAULT_DATA_DIR, "chromadb"),
    "hash_cache_file": os.path.join(DEFAULT_DATA_DIR, "index_hashes.json"),
    "daily_log_dir": os.path.join(DEFAULT_DATA_DIR, "daily"),
    "weekly_dir": os.path.join(DEFAULT_DATA_DIR, "weekly"),
    "monthly_dir": os.path.join(DEFAULT_DATA_DIR, "monthly"),
    "quarterly_dir": os.path.join(DEFAULT_DATA_DIR, "quarterly"),
    "yearly_dir": os.path.join(DEFAULT_DATA_DIR, "yearly"),
    "collection_name": "claude_memory",

    # Index paths: list of {"path": "/some/dir", "depth": 3}
    "index_paths": [],

    # File extensions to index
    "index_extensions": [".md"],

    # Directories to skip during indexing
    "skip_dirs": ["chromadb", ".git", "node_modules", "__pycache__", ".obsidian"],

    # Minimum file size (bytes of stripped content) to index
    "min_file_size": 50,

    # Chunk settings (match OpenClaw: ~400 tokens target, 80 token overlap)
    "chunk_size_words": 400,
    "chunk_overlap_words": 80,

    # Search weights
    "vector_weight": 0.70,
    "keyword_weight": 0.30,

    # Temporal decay: score * e^(-lambda * age_days)
    # Half-life of 30 days means a 30-day-old file scores 50% of a fresh one
    "decay_half_life_days": 30,

    # Evergreen patterns: files matching these never decay
    "evergreen_patterns": [
        "README.md",
        "CLAUDE.md",
        "preferences.md",
        "config.json",
        "known_issues.md",
        "decisions/",
        "people/",
    ],

    # Categories for filtering (used in search and stats)
    "categories": [
        "project", "reference", "daily", "config", "archive", "other"
    ],

    # Category rules: map path substrings to categories
    # Matched in order; first match wins. Paths are normalized to forward slashes.
    "category_rules": [
        {"pattern": "/daily/", "category": "daily"},
        {"pattern": "config", "category": "config"},
        {"pattern": "archive", "category": "archive"},
        {"pattern": "reference", "category": "reference"},
    ],

    # Default category when no rule matches
    "default_category": "other",

    # Default number of search results
    "default_n_results": 8,

    # Candidate multiplier for re-ranking (pull N * multiplier candidates)
    "candidate_multiplier": 3,

    # --- Biological Memory Model ---

    # Salience weighting: pattern -> multiplier
    # Higher salience = slower decay (effective_age = raw_age / salience)
    "salience_patterns": {
        "WELCOME.md": 5.0,
        "BRIEFING.md": 5.0,
        "CLAUDE.md": 4.0,
        "decisions/": 4.0,
        "people/": 4.0,
        "Playbooks/": 3.5,
        "session_log": 3.0,
        "yearly/": 4.0,
        "quarterly/": 3.5,
        "monthly/": 3.0,
        "weekly/": 2.5,
        "daily/": 2.0,
        "paths.json": 3.0,
        "known_issues": 3.0,
        "config": 2.0,
    },

    # Retrieval strengthening (spaced repetition)
    # Each search hit within the window gives a boost, up to max
    "retrieval_strengthening": {
        "boost_per_access": 0.05,       # 5% boost per access
        "window_days": 7,               # only count accesses within this window
        "max_boost": 0.30,              # cap at 30%
        "access_log_file": "access_log.json",  # relative to data_dir
    },

    # Consolidation bonus: files mentioned in periodic notes get boosted
    # Higher period levels = bigger bonus
    "consolidation": {
        "bonus_per_level": 0.15,        # 15% boost per period level
        "max_bonus": 0.50,              # cap at 50%
        "period_levels": ["weekly", "monthly", "quarterly", "yearly"],
    },
}


def _env_override(key):
    """Check for CLAUDE_MEMORY_<KEY> environment variable."""
    env_key = f"CLAUDE_MEMORY_{key.upper()}"
    return os.environ.get(env_key)


def load_config(config_path=None):
    """Load configuration, merging file settings over defaults.

    Args:
        config_path: Explicit path to config.json. If None, uses
                     CLAUDE_MEMORY_CONFIG env var or the default location.

    Returns:
        dict with all configuration values.
    """
    config = dict(DEFAULTS)

    # Determine config file location
    if config_path is None:
        config_path = _env_override("config") or DEFAULT_CONFIG_FILE

    # Load from file if it exists
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                file_config = json.load(f)
            config.update(file_config)
        except (json.JSONDecodeError, OSError) as e:
            pass  # Silently fall back to defaults

    # Environment variable overrides for key paths
    for key in ["config_dir", "data_dir", "chroma_dir", "daily_log_dir",
                "weekly_dir", "monthly_dir", "quarterly_dir", "yearly_dir",
                "collection_name"]:
        env_val = _env_override(key)
        if env_val:
            config[key] = env_val

    # Compute derived values
    config["decay_lambda"] = math.log(2) / max(1, config["decay_half_life_days"])

    return config


def save_config(config, config_path=None):
    """Save configuration to disk.

    Only saves non-default values to keep the file clean.
    """
    if config_path is None:
        config_path = config.get("_config_path", DEFAULT_CONFIG_FILE)

    # Filter out computed/internal keys
    skip_keys = {"decay_lambda", "_config_path"}
    saveable = {k: v for k, v in config.items() if k not in skip_keys}

    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(saveable, f, indent=2)


def init_dirs(config):
    """Create all required directories."""
    for key in ["config_dir", "data_dir", "chroma_dir", "daily_log_dir",
                "weekly_dir", "monthly_dir", "quarterly_dir", "yearly_dir"]:
        path = config.get(key)
        if path:
            os.makedirs(path, exist_ok=True)


def get_config(config_path=None):
    """Convenience: load config and ensure directories exist.

    This is the main entry point most modules should use.
    """
    config = load_config(config_path)
    config["_config_path"] = config_path or DEFAULT_CONFIG_FILE
    return config
