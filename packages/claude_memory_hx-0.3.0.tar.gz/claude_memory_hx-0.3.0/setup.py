from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="claude-memory-hx",
    version="0.3.0",
    author="Sean (Haustorium12)",
    description="Persistent hybrid memory for AI coding assistants",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Haustorium12/claude-memory",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "chromadb>=0.4.0",
    ],
    entry_points={
        "console_scripts": [
            "claude-memory=claude_memory.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="ai memory vector-search chromadb claude coding-assistant",
)
