"""Tests for the biological memory model (salience, retrieval, consolidation)."""

import json
import math
import os
import tempfile
import time

from claude_memory.search import (
    biological_score,
    get_salience,
    get_retrieval_boost,
    get_consolidation_boost,
    record_access,
    load_access_log,
    save_access_log,
    show_access_stats,
    clear_consolidation_cache,
    is_evergreen,
    get_file_age_days,
)
from claude_memory.config import get_config, DEFAULTS


def _make_bio_config(tmpdir):
    """Create a test config with biological model settings."""
    return {
        "config_dir": tmpdir,
        "data_dir": tmpdir,
        "chroma_dir": os.path.join(tmpdir, "chromadb"),
        "hash_cache_file": os.path.join(tmpdir, "hashes.json"),
        "daily_log_dir": os.path.join(tmpdir, "daily"),
        "weekly_dir": os.path.join(tmpdir, "weekly"),
        "monthly_dir": os.path.join(tmpdir, "monthly"),
        "quarterly_dir": os.path.join(tmpdir, "quarterly"),
        "yearly_dir": os.path.join(tmpdir, "yearly"),
        "collection_name": "test_memory",
        "decay_lambda": math.log(2) / 30,
        "evergreen_patterns": ["README.md", "CLAUDE.md", "decisions/"],
        "salience_patterns": {
            "WELCOME.md": 5.0,
            "BRIEFING.md": 5.0,
            "session_log": 3.0,
            "daily/": 2.0,
        },
        "retrieval_strengthening": {
            "boost_per_access": 0.05,
            "window_days": 7,
            "max_boost": 0.30,
            "access_log_file": "access_log.json",
        },
        "consolidation": {
            "bonus_per_level": 0.15,
            "max_bonus": 0.50,
            "period_levels": ["weekly", "monthly", "quarterly", "yearly"],
        },
    }


class TestSalience:
    """Tests for salience weighting."""

    def test_default_salience_is_one(self):
        patterns = {"WELCOME.md": 5.0, "daily/": 2.0}
        assert get_salience("/some/random/file.md", patterns) == 1.0

    def test_exact_filename_match(self):
        patterns = {"WELCOME.md": 5.0}
        assert get_salience("/project/WELCOME.md", patterns) == 5.0

    def test_directory_pattern_match(self):
        patterns = {"daily/": 2.0}
        assert get_salience("/memory/daily/2026-03-11.md", patterns) == 2.0

    def test_highest_match_wins(self):
        patterns = {"WELCOME.md": 5.0, ".md": 2.0}
        # Both match, but WELCOME.md has higher salience
        sal = get_salience("/project/WELCOME.md", patterns)
        assert sal == 5.0

    def test_backslash_paths(self):
        patterns = {"daily/": 2.0}
        assert get_salience("C:\\memory\\daily\\2026-03-11.md", patterns) == 2.0

    def test_case_insensitive(self):
        patterns = {"welcome.md": 5.0}
        assert get_salience("/project/WELCOME.md", patterns) == 5.0


class TestRetrievalStrengthening:
    """Tests for retrieval boost (spaced repetition)."""

    def test_no_access_log_returns_zero(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            boost = get_retrieval_boost("/some/file.md", config)
            assert boost == 0.0

    def test_record_and_retrieve_boost(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            filepath = "/some/file.md"
            record_access(filepath, config)
            boost = get_retrieval_boost(filepath, config)
            assert boost == 0.05  # 1 access * 0.05

    def test_multiple_accesses_stack(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            filepath = "/some/file.md"
            for _ in range(3):
                record_access(filepath, config)
            boost = get_retrieval_boost(filepath, config)
            assert abs(boost - 0.15) < 0.001  # 3 * 0.05

    def test_boost_caps_at_max(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            filepath = "/some/file.md"
            for _ in range(20):  # Way more than max
                record_access(filepath, config)
            boost = get_retrieval_boost(filepath, config)
            assert boost == 0.30  # Capped at max_boost

    def test_access_log_persistence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            filepath = "/some/file.md"
            record_access(filepath, config)

            # Load from disk
            log = load_access_log(config)
            assert filepath in log
            assert len(log[filepath]) == 1

    def test_different_files_tracked_separately(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            record_access("/file1.md", config)
            record_access("/file1.md", config)
            record_access("/file2.md", config)

            boost1 = get_retrieval_boost("/file1.md", config)
            boost2 = get_retrieval_boost("/file2.md", config)
            assert boost1 > boost2


class TestConsolidation:
    """Tests for consolidation bonus (periodic note mentions)."""

    def test_no_periodic_notes_returns_zero(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            clear_consolidation_cache()
            bonus = get_consolidation_boost("/some/file.md", config)
            assert bonus == 0.0

    def test_mentioned_in_weekly_gets_bonus(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            clear_consolidation_cache()

            # Create a weekly note that mentions a file
            weekly_dir = config["weekly_dir"]
            os.makedirs(weekly_dir, exist_ok=True)
            with open(os.path.join(weekly_dir, "2026-W11.md"), "w") as f:
                f.write("# Weekly\n\nWorked on /project/auth.md this week.\n")

            bonus = get_consolidation_boost("/project/auth.md", config)
            assert bonus >= 0.15  # At least weekly bonus

    def test_mentioned_in_multiple_levels_stacks(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            clear_consolidation_cache()

            # Create weekly and monthly notes mentioning same file
            for period in ["weekly", "monthly"]:
                d = config[f"{period}_dir"]
                os.makedirs(d, exist_ok=True)
                key = "2026-W11" if period == "weekly" else "2026-03"
                with open(os.path.join(d, f"{key}.md"), "w") as f:
                    f.write(f"# {period}\n\nWorked on important_file.md\n")

            bonus = get_consolidation_boost("important_file.md", config)
            assert bonus >= 0.30  # weekly (0.15) + monthly (0.15)

    def test_consolidation_caps_at_max(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            clear_consolidation_cache()

            # Create notes at all 4 levels mentioning same file
            for period, key in [("weekly", "2026-W11"), ("monthly", "2026-03"),
                                ("quarterly", "2026-Q1"), ("yearly", "2026")]:
                d = config[f"{period}_dir"]
                os.makedirs(d, exist_ok=True)
                with open(os.path.join(d, f"{key}.md"), "w") as f:
                    f.write(f"# {period}\n\nMentions core_file.md everywhere\n")

            bonus = get_consolidation_boost("core_file.md", config)
            assert bonus <= 0.50  # Capped at max_bonus


class TestBiologicalScore:
    """Tests for the combined biological scoring pipeline."""

    def test_no_decay_returns_base(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            score = biological_score(1.0, "/some/file.md", config, apply_decay=False)
            assert score == 1.0

    def test_evergreen_no_decay(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            score = biological_score(1.0, "/project/README.md", config, apply_decay=True)
            # Evergreen files skip decay but still get retrieval/consolidation
            assert score >= 1.0

    def test_fresh_file_minimal_decay(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            # Create a fresh temp file
            temp_file = os.path.join(tmpdir, "fresh.md")
            with open(temp_file, "w") as f:
                f.write("fresh content")
            score = biological_score(1.0, temp_file, config, apply_decay=True)
            # Fresh file should have near-zero decay
            assert score > 0.90

    def test_salience_slows_decay(self):
        """High-salience files should decay slower than low-salience ones."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)

            # Create two files with same age
            high_sal = os.path.join(tmpdir, "daily", "old.md")
            low_sal = os.path.join(tmpdir, "random.md")
            os.makedirs(os.path.dirname(high_sal), exist_ok=True)

            for path in [high_sal, low_sal]:
                with open(path, "w") as f:
                    f.write("content")
                # Set mtime to 30 days ago
                old_time = time.time() - (30 * 86400)
                os.utime(path, (old_time, old_time))

            score_high = biological_score(1.0, high_sal, config, apply_decay=True)
            score_low = biological_score(1.0, low_sal, config, apply_decay=True)

            # daily/ has salience 2.0, so effective age = 15 days
            # random file has salience 1.0, so effective age = 30 days
            assert score_high > score_low

    def test_retrieval_boost_increases_score(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            temp_file = os.path.join(tmpdir, "boosted.md")
            with open(temp_file, "w") as f:
                f.write("content")

            score_before = biological_score(1.0, temp_file, config, apply_decay=True)
            record_access(temp_file, config)
            score_after = biological_score(1.0, temp_file, config, apply_decay=True)

            assert score_after > score_before


class TestShowAccessStats:
    """Tests for the access stats display."""

    def test_no_crash_on_empty(self, capsys):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            show_access_stats(config)
            captured = capsys.readouterr()
            # Should produce some output without crashing
            assert len(captured.out) > 0

    def test_shows_recorded_accesses(self, capsys):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_bio_config(tmpdir)
            record_access("/project/auth.md", config)
            record_access("/project/auth.md", config)
            show_access_stats(config)
            captured = capsys.readouterr()
            assert "auth.md" in captured.out


class TestDefaultConfig:
    """Tests that default config includes biological model keys."""

    def test_salience_patterns_in_defaults(self):
        assert "salience_patterns" in DEFAULTS
        assert isinstance(DEFAULTS["salience_patterns"], dict)
        assert "WELCOME.md" in DEFAULTS["salience_patterns"]

    def test_retrieval_strengthening_in_defaults(self):
        assert "retrieval_strengthening" in DEFAULTS
        rs = DEFAULTS["retrieval_strengthening"]
        assert "boost_per_access" in rs
        assert "window_days" in rs
        assert "max_boost" in rs

    def test_consolidation_in_defaults(self):
        assert "consolidation" in DEFAULTS
        c = DEFAULTS["consolidation"]
        assert "bonus_per_level" in c
        assert "max_bonus" in c
        assert "period_levels" in c
