"""Tests for the search module."""

import math
import os
import tempfile
import time

from claude_memory.search import (
    keyword_score,
    is_evergreen,
    get_file_age_days,
    temporal_decay_score,
    safe_print,
)


class TestKeywordScore:
    """Tests for BM25-style keyword scoring."""

    def test_exact_match_single_term(self):
        score = keyword_score("python", "python is a programming language")
        assert score > 0

    def test_no_match(self):
        score = keyword_score("javascript", "python is a programming language")
        assert score == 0.0

    def test_multiple_term_match(self):
        score = keyword_score(
            "python programming",
            "python is a programming language for programming tasks",
        )
        assert score > 0

    def test_partial_match_less_than_full(self):
        partial = keyword_score("python javascript", "python is great")
        full = keyword_score("python", "python is great")
        # Partial match (1/2 terms) should score less than full match
        assert partial < full

    def test_empty_query(self):
        assert keyword_score("", "some document") == 0.0

    def test_empty_document(self):
        assert keyword_score("query", "") == 0.0

    def test_case_insensitive(self):
        score1 = keyword_score("Python", "python programming")
        score2 = keyword_score("python", "Python Programming")
        assert score1 == score2

    def test_term_frequency_saturation(self):
        """Repeated terms should have diminishing returns (BM25 k1 saturation)."""
        once = keyword_score("test", "test document")
        many = keyword_score("test", "test test test test test document")
        # Both should be positive, but many should not be proportionally higher
        assert many > once
        assert many < once * 5  # Saturation prevents linear scaling

    def test_score_bounded_zero_to_one(self):
        score = keyword_score("a b c", "a b c d e f")
        assert 0.0 <= score <= 1.0


class TestEvergreenDetection:
    """Tests for evergreen file detection."""

    def test_readme_is_evergreen(self):
        patterns = ["README.md", "CLAUDE.md", "decisions/"]
        assert is_evergreen("/project/README.md", patterns)

    def test_decisions_dir_is_evergreen(self):
        patterns = ["README.md", "decisions/"]
        assert is_evergreen("/project/decisions/adr-001.md", patterns)

    def test_regular_file_not_evergreen(self):
        patterns = ["README.md", "decisions/"]
        assert not is_evergreen("/project/notes/todo.md", patterns)

    def test_none_filepath_is_evergreen(self):
        """Files with no path default to evergreen (no decay penalty)."""
        assert is_evergreen(None, ["README.md"])
        assert is_evergreen("", ["README.md"])

    def test_case_insensitive(self):
        patterns = ["README.md"]
        assert is_evergreen("/project/readme.md", patterns)

    def test_backslash_paths(self):
        patterns = ["decisions/"]
        assert is_evergreen("C:\\project\\decisions\\adr.md", patterns)


class TestTemporalDecay:
    """Tests for temporal decay scoring."""

    def test_no_decay_flag(self):
        score = temporal_decay_score(
            1.0, "/some/file.md", math.log(2) / 30, ["README.md"],
            apply_decay=False,
        )
        assert score == 1.0

    def test_evergreen_no_decay(self):
        score = temporal_decay_score(
            1.0, "/project/README.md", math.log(2) / 30, ["README.md"],
            apply_decay=True,
        )
        assert score == 1.0

    def test_decay_applied_to_temp_file(self):
        """A file with known age should have reduced score."""
        with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as f:
            f.write(b"test content")
            temp_path = f.name

        try:
            # File was just created, age ~ 0 days, decay ~ 1.0
            score = temporal_decay_score(
                1.0, temp_path, math.log(2) / 30, [],
                apply_decay=True,
            )
            # Fresh file should have minimal decay
            assert score > 0.95
        finally:
            os.unlink(temp_path)

    def test_nonexistent_file_no_decay(self):
        """Files that can't be stat'd get age 0 (no penalty)."""
        score = temporal_decay_score(
            1.0, "/nonexistent/file.md", math.log(2) / 30, [],
            apply_decay=True,
        )
        assert score == 1.0


class TestSafePrint:
    """Tests for CP1252-safe print."""

    def test_ascii_text(self, capsys):
        safe_print("hello world")
        captured = capsys.readouterr()
        assert "hello world" in captured.out

    def test_does_not_crash_on_unicode(self, capsys):
        # Should not raise, regardless of console encoding
        safe_print("Hello \u2603 snowman")
