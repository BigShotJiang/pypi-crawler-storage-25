"""Tests for the indexer module."""

import json
import os
import tempfile

from claude_memory.indexer import (
    file_hash,
    load_hash_cache,
    save_hash_cache,
    chunk_text,
    categorize_file,
    collect_files,
)


class TestFileHash:
    """Tests for SHA-256 file hashing."""

    def test_hash_returns_hex_string(self):
        with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as f:
            f.write(b"test content")
            path = f.name
        try:
            h = file_hash(path)
            assert h is not None
            assert len(h) == 64  # SHA-256 hex digest length
        finally:
            os.unlink(path)

    def test_same_content_same_hash(self):
        paths = []
        for _ in range(2):
            with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as f:
                f.write(b"identical content")
                paths.append(f.name)
        try:
            assert file_hash(paths[0]) == file_hash(paths[1])
        finally:
            for p in paths:
                os.unlink(p)

    def test_different_content_different_hash(self):
        paths = []
        for content in [b"content A", b"content B"]:
            with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as f:
                f.write(content)
                paths.append(f.name)
        try:
            assert file_hash(paths[0]) != file_hash(paths[1])
        finally:
            for p in paths:
                os.unlink(p)

    def test_nonexistent_file_returns_none(self):
        assert file_hash("/nonexistent/file.md") is None


class TestHashCache:
    """Tests for hash cache persistence."""

    def test_save_and_load(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache_path = os.path.join(tmpdir, "hashes.json")
            data = {"/some/file.md": "abc123", "/other/file.md": "def456"}
            save_hash_cache(data, cache_path)
            loaded = load_hash_cache(cache_path)
            assert loaded == data

    def test_load_missing_file(self):
        assert load_hash_cache("/nonexistent/hashes.json") == {}

    def test_load_corrupt_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("not valid json{{{")
            path = f.name
        try:
            assert load_hash_cache(path) == {}
        finally:
            os.unlink(path)


class TestChunkText:
    """Tests for text chunking."""

    def test_short_text_single_chunk(self):
        text = "This is a short document."
        chunks = chunk_text(text, chunk_size=100, overlap=20)
        assert len(chunks) == 1
        assert chunks[0] == text

    def test_long_text_multiple_chunks(self):
        words = ["word"] * 1000
        text = " ".join(words)
        chunks = chunk_text(text, chunk_size=400, overlap=80)
        assert len(chunks) > 1

    def test_overlap_exists(self):
        words = [f"w{i}" for i in range(100)]
        text = " ".join(words)
        chunks = chunk_text(text, chunk_size=40, overlap=10)
        assert len(chunks) >= 2
        # Last words of chunk 0 should appear in chunk 1
        chunk0_words = chunks[0].split()
        chunk1_words = chunks[1].split()
        overlap_words = chunk0_words[-10:]
        assert overlap_words == chunk1_words[:10]

    def test_empty_text(self):
        assert chunk_text("") == []

    def test_whitespace_only(self):
        assert chunk_text("   \n\n  ") == []


class TestCategorizeFile:
    """Tests for file categorization."""

    def test_matching_rule(self):
        config = {
            "category_rules": [
                {"pattern": "/daily/", "category": "daily"},
                {"pattern": "/docs/", "category": "reference"},
            ],
            "default_category": "other",
        }
        assert categorize_file("/project/daily/2024-01-01.md", config) == "daily"
        assert categorize_file("/project/docs/arch.md", config) == "reference"

    def test_default_category(self):
        config = {
            "category_rules": [{"pattern": "/daily/", "category": "daily"}],
            "default_category": "other",
        }
        assert categorize_file("/project/random/note.md", config) == "other"

    def test_first_rule_wins(self):
        config = {
            "category_rules": [
                {"pattern": "daily", "category": "daily"},
                {"pattern": "daily", "category": "journal"},
            ],
            "default_category": "other",
        }
        assert categorize_file("/daily/note.md", config) == "daily"

    def test_backslash_paths(self):
        config = {
            "category_rules": [{"pattern": "/daily/", "category": "daily"}],
            "default_category": "other",
        }
        # Windows paths should be normalized
        assert categorize_file("C:\\project\\daily\\note.md", config) == "daily"


class TestCollectFiles:
    """Tests for file collection."""

    def test_collects_markdown_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some test files
            for name in ["note.md", "readme.md", "script.py", "data.txt"]:
                with open(os.path.join(tmpdir, name), "w") as f:
                    f.write("content")

            config = {
                "index_extensions": [".md"],
                "skip_dirs": [],
            }
            index_paths = [{"path": tmpdir, "depth": 3}]
            files = collect_files(index_paths, config)
            basenames = [os.path.basename(f) for f in files]
            assert "note.md" in basenames
            assert "readme.md" in basenames
            assert "script.py" not in basenames
            assert "data.txt" not in basenames

    def test_respects_depth_limit(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create nested structure
            deep = os.path.join(tmpdir, "a", "b", "c")
            os.makedirs(deep)
            with open(os.path.join(tmpdir, "top.md"), "w") as f:
                f.write("top level")
            with open(os.path.join(deep, "deep.md"), "w") as f:
                f.write("deep level")

            config = {"index_extensions": [".md"], "skip_dirs": []}
            shallow = collect_files([{"path": tmpdir, "depth": 1}], config)
            assert any("top.md" in f for f in shallow)
            assert not any("deep.md" in f for f in shallow)

    def test_skips_configured_dirs(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            git_dir = os.path.join(tmpdir, ".git")
            os.makedirs(git_dir)
            with open(os.path.join(git_dir, "config.md"), "w") as f:
                f.write("git config")
            with open(os.path.join(tmpdir, "note.md"), "w") as f:
                f.write("regular note")

            config = {"index_extensions": [".md"], "skip_dirs": [".git"]}
            files = collect_files([{"path": tmpdir, "depth": 3}], config)
            assert any("note.md" in f for f in files)
            assert not any("config.md" in f for f in files)

    def test_nonexistent_directory(self):
        config = {"index_extensions": [".md"], "skip_dirs": []}
        files = collect_files([{"path": "/nonexistent/dir", "depth": 3}], config)
        assert files == []
