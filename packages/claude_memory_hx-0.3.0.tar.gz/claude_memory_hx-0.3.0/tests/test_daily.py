"""Tests for the daily log module."""

import os
import tempfile
import datetime

from claude_memory.daily import (
    today_str,
    yesterday_str,
    log_path,
    init_daily_log,
    append_to_log,
    load_recent,
)
from claude_memory.config import get_config


def _make_config(tmpdir):
    """Create a test config pointing to a temp directory."""
    daily_dir = os.path.join(tmpdir, "daily")
    return {
        "config_dir": tmpdir,
        "data_dir": tmpdir,
        "chroma_dir": os.path.join(tmpdir, "chromadb"),
        "hash_cache_file": os.path.join(tmpdir, "hashes.json"),
        "daily_log_dir": daily_dir,
        "collection_name": "test_memory",
    }


class TestDateStrings:
    """Tests for date string helpers."""

    def test_today_is_iso_format(self):
        t = today_str()
        # Should be YYYY-MM-DD
        assert len(t) == 10
        assert t[4] == "-"
        assert t[7] == "-"

    def test_yesterday_is_one_day_before_today(self):
        t = datetime.date.fromisoformat(today_str())
        y = datetime.date.fromisoformat(yesterday_str())
        assert (t - y).days == 1


class TestLogPath:
    """Tests for log path generation."""

    def test_uses_date_in_filename(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            path = log_path("2024-01-15", config)
            assert path.endswith("2024-01-15.md")
            assert config["daily_log_dir"] in path


class TestInitDailyLog:
    """Tests for daily log initialization."""

    def test_creates_log_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            path = init_daily_log(config)
            assert os.path.exists(path)
            with open(path, "r") as f:
                content = f.read()
            assert "Daily Log" in content
            assert today_str() in content

    def test_idempotent(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            path1 = init_daily_log(config)
            # Write something extra
            with open(path1, "a") as f:
                f.write("extra content\n")
            # Init again should not overwrite
            path2 = init_daily_log(config)
            assert path1 == path2
            with open(path2, "r") as f:
                content = f.read()
            assert "extra content" in content


class TestAppendToLog:
    """Tests for appending to daily logs."""

    def test_appends_message(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            append_to_log("Test message", config)
            path = log_path(today_str(), config)
            with open(path, "r") as f:
                content = f.read()
            assert "Test message" in content

    def test_includes_timestamp(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            append_to_log("Timestamped entry", config)
            path = log_path(today_str(), config)
            with open(path, "r") as f:
                content = f.read()
            # Should contain HH:MM format
            assert "**" in content  # Bold timestamp markers

    def test_multiple_appends(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            append_to_log("First entry", config)
            append_to_log("Second entry", config)
            path = log_path(today_str(), config)
            with open(path, "r") as f:
                content = f.read()
            assert "First entry" in content
            assert "Second entry" in content


class TestLoadRecent:
    """Tests for loading recent context."""

    def test_no_logs_returns_message(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            os.makedirs(config["daily_log_dir"], exist_ok=True)
            result = load_recent(config)
            assert "No recent" in result

    def test_loads_today(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            append_to_log("Today's work", config)
            result = load_recent(config)
            assert "TODAY" in result
            assert "Today's work" in result

    def test_loads_yesterday(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            os.makedirs(config["daily_log_dir"], exist_ok=True)
            # Create yesterday's log manually
            ypath = log_path(yesterday_str(), config)
            with open(ypath, "w") as f:
                f.write(f"# Daily Log -- {yesterday_str()}\n\nYesterday's work\n")
            result = load_recent(config)
            assert "YESTERDAY" in result
            assert "Yesterday's work" in result
