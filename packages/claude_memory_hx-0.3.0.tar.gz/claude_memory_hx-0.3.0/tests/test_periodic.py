"""Tests for the periodic log module."""

import os
import tempfile
import datetime

from claude_memory.periodic import (
    PERIODS,
    current_week_str,
    current_month_str,
    current_quarter_str,
    current_year_str,
    previous_week_str,
    previous_month_str,
    week_date_range,
    month_date_range,
    quarter_months,
    year_quarters,
    period_key,
    get_period_dir,
    period_path,
    period_header,
    synthesis_template,
    init_period,
    append_to_period,
    show_period,
    list_periods,
    collect_lower_level_content,
    synthesize_period,
    load_periodic_context,
    show_all_current,
)


def _make_config(tmpdir):
    """Create a test config pointing to a temp directory."""
    return {
        "config_dir": tmpdir,
        "data_dir": tmpdir,
        "chroma_dir": os.path.join(tmpdir, "chromadb"),
        "hash_cache_file": os.path.join(tmpdir, "hashes.json"),
        "daily_log_dir": os.path.join(tmpdir, "daily"),
        "weekly_dir": os.path.join(tmpdir, "weekly"),
        "monthly_dir": os.path.join(tmpdir, "monthly"),
        "quarterly_dir": os.path.join(tmpdir, "quarterly"),
        "yearly_dir": os.path.join(tmpdir, "yearly"),
        "collection_name": "test_memory",
    }


class TestDateHelpers:
    """Tests for date string helpers."""

    def test_current_week_str_format(self):
        w = current_week_str()
        # Should be YYYY-Wnn
        assert "-W" in w
        parts = w.split("-W")
        assert len(parts) == 2
        assert len(parts[0]) == 4
        assert 1 <= int(parts[1]) <= 53

    def test_current_month_str_format(self):
        m = current_month_str()
        # YYYY-MM
        assert len(m) == 7
        assert m[4] == "-"
        assert 1 <= int(m[5:]) <= 12

    def test_current_quarter_str_format(self):
        q = current_quarter_str()
        assert "-Q" in q
        qnum = int(q.split("-Q")[1])
        assert 1 <= qnum <= 4

    def test_current_year_str_format(self):
        y = current_year_str()
        assert len(y) == 4
        assert int(y) >= 2024

    def test_previous_week_is_before_current(self):
        # Previous week number should generally be less (with year wrap handling)
        pw = previous_week_str()
        cw = current_week_str()
        # Both should be valid format
        assert "-W" in pw
        assert "-W" in cw

    def test_previous_month_is_before_current(self):
        pm = previous_month_str()
        cm = current_month_str()
        assert pm < cm or pm[:4] < cm[:4]  # handles year boundary

    def test_week_date_range(self):
        start, end = week_date_range("2026-W11")
        assert start.weekday() == 0  # Monday
        assert end.weekday() == 6    # Sunday
        assert (end - start).days == 6

    def test_month_date_range(self):
        start, end = month_date_range("2026-03")
        assert start == datetime.date(2026, 3, 1)
        assert end == datetime.date(2026, 3, 31)

    def test_month_date_range_february(self):
        start, end = month_date_range("2026-02")
        assert start == datetime.date(2026, 2, 1)
        assert end == datetime.date(2026, 2, 28)

    def test_month_date_range_december(self):
        start, end = month_date_range("2026-12")
        assert start == datetime.date(2026, 12, 1)
        assert end == datetime.date(2026, 12, 31)

    def test_quarter_months(self):
        assert quarter_months("2026-Q1") == ["2026-01", "2026-02", "2026-03"]
        assert quarter_months("2026-Q2") == ["2026-04", "2026-05", "2026-06"]
        assert quarter_months("2026-Q3") == ["2026-07", "2026-08", "2026-09"]
        assert quarter_months("2026-Q4") == ["2026-10", "2026-11", "2026-12"]

    def test_year_quarters(self):
        assert year_quarters("2026") == ["2026-Q1", "2026-Q2", "2026-Q3", "2026-Q4"]


class TestPeriodKey:
    """Tests for period_key function."""

    def test_weekly_returns_week_str(self):
        assert period_key("weekly") == current_week_str()

    def test_monthly_returns_month_str(self):
        assert period_key("monthly") == current_month_str()

    def test_quarterly_returns_quarter_str(self):
        assert period_key("quarterly") == current_quarter_str()

    def test_yearly_returns_year_str(self):
        assert period_key("yearly") == current_year_str()

    def test_unknown_returns_none(self):
        assert period_key("unknown") is None


class TestGetPeriodDir:
    """Tests for get_period_dir function."""

    def test_uses_config_keys(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            assert get_period_dir("weekly", config) == config["weekly_dir"]
            assert get_period_dir("monthly", config) == config["monthly_dir"]
            assert get_period_dir("quarterly", config) == config["quarterly_dir"]
            assert get_period_dir("yearly", config) == config["yearly_dir"]
            assert get_period_dir("daily", config) == config["daily_log_dir"]

    def test_fallback_to_data_dir(self):
        config = {"data_dir": "/some/path"}
        # Unknown period falls back to data_dir/period
        result = get_period_dir("custom", config)
        assert result == os.path.join("/some/path", "custom")


class TestPeriodPath:
    """Tests for period_path function."""

    def test_returns_md_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            path = period_path("weekly", "2026-W11", config)
            assert path.endswith("2026-W11.md")
            assert config["weekly_dir"] in path


class TestTemplates:
    """Tests for period headers and templates."""

    def test_weekly_header_has_date_range(self):
        header = period_header("weekly", "2026-W11")
        assert "Weekly Note" in header
        assert "2026-W11" in header

    def test_monthly_header_has_date_range(self):
        header = period_header("monthly", "2026-03")
        assert "Monthly Note" in header
        assert "2026-03" in header

    def test_quarterly_header_has_months(self):
        header = period_header("quarterly", "2026-Q1")
        assert "Quarterly Note" in header
        assert "2026-01" in header

    def test_yearly_header(self):
        header = period_header("yearly", "2026")
        assert "Yearly Note" in header
        assert "2026" in header

    def test_weekly_template_has_sections(self):
        tmpl = synthesis_template("weekly", "2026-W11")
        assert "Key Accomplishments" in tmpl
        assert "Next Week Focus" in tmpl

    def test_monthly_template_has_sections(self):
        tmpl = synthesis_template("monthly", "2026-03")
        assert "Lessons Learned" in tmpl
        assert "Next Month Focus" in tmpl

    def test_quarterly_template_has_sections(self):
        tmpl = synthesis_template("quarterly", "2026-Q1")
        assert "Major Milestones" in tmpl
        assert "Next Quarter Objectives" in tmpl

    def test_yearly_template_has_sections(self):
        tmpl = synthesis_template("yearly", "2026")
        assert "Year in Review" in tmpl
        assert "Next Year Vision" in tmpl


class TestInitPeriod:
    """Tests for init_period function."""

    def test_creates_note_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            path = init_period("weekly", "2026-W11", config)
            assert os.path.exists(path)
            with open(path, "r") as f:
                content = f.read()
            assert "Weekly Note" in content

    def test_idempotent(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            path1 = init_period("monthly", "2026-03", config)
            with open(path1, "a") as f:
                f.write("extra stuff\n")
            path2 = init_period("monthly", "2026-03", config)
            assert path1 == path2
            with open(path2, "r") as f:
                content = f.read()
            assert "extra stuff" in content

    def test_creates_directory(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            # Directory shouldn't exist yet
            assert not os.path.exists(config["quarterly_dir"])
            init_period("quarterly", "2026-Q1", config)
            assert os.path.exists(config["quarterly_dir"])


class TestAppendToPeriod:
    """Tests for append_to_period function."""

    def test_appends_message(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            append_to_period("weekly", "Test note", "2026-W11", config)
            path = period_path("weekly", "2026-W11", config)
            with open(path, "r") as f:
                content = f.read()
            assert "Test note" in content

    def test_includes_timestamp(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            append_to_period("monthly", "Timestamped entry", "2026-03", config)
            path = period_path("monthly", "2026-03", config)
            with open(path, "r") as f:
                content = f.read()
            assert "**" in content  # Bold timestamp markers

    def test_multiple_appends(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            append_to_period("weekly", "First", "2026-W11", config)
            append_to_period("weekly", "Second", "2026-W11", config)
            path = period_path("weekly", "2026-W11", config)
            with open(path, "r") as f:
                content = f.read()
            assert "First" in content
            assert "Second" in content


class TestListPeriods:
    """Tests for list_periods function."""

    def test_no_notes_message(self, capsys):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            list_periods("weekly", config)
            captured = capsys.readouterr()
            assert "No weekly notes" in captured.out

    def test_lists_existing_notes(self, capsys):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            init_period("weekly", "2026-W10", config)
            init_period("weekly", "2026-W11", config)
            list_periods("weekly", config)
            captured = capsys.readouterr()
            assert "2026-W10" in captured.out
            assert "2026-W11" in captured.out


class TestCollectLowerLevelContent:
    """Tests for synthesis content collection."""

    def test_weekly_collects_daily(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            daily_dir = config["daily_log_dir"]
            os.makedirs(daily_dir, exist_ok=True)
            # Create a daily log for a known date in W11 2026
            # W11 2026 is March 9 (Mon) to March 15 (Sun)
            with open(os.path.join(daily_dir, "2026-03-10.md"), "w") as f:
                f.write("# Daily Log\n\nDid some work\n")
            parts = collect_lower_level_content("weekly", "2026-W11", config)
            assert len(parts) == 1
            assert "Did some work" in parts[0]

    def test_monthly_collects_weekly(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            weekly_dir = config["weekly_dir"]
            os.makedirs(weekly_dir, exist_ok=True)
            with open(os.path.join(weekly_dir, "2026-W10.md"), "w") as f:
                f.write("# Weekly Note\n\nWeek 10 stuff\n")
            with open(os.path.join(weekly_dir, "2026-W11.md"), "w") as f:
                f.write("# Weekly Note\n\nWeek 11 stuff\n")
            parts = collect_lower_level_content("monthly", "2026-03", config)
            assert len(parts) >= 1
            found = " ".join(parts)
            assert "Week" in found

    def test_monthly_falls_back_to_daily(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            daily_dir = config["daily_log_dir"]
            os.makedirs(daily_dir, exist_ok=True)
            # No weekly notes, but daily exists
            with open(os.path.join(daily_dir, "2026-03-05.md"), "w") as f:
                f.write("# Daily\n\nSome daily work\n")
            parts = collect_lower_level_content("monthly", "2026-03", config)
            assert len(parts) >= 1
            assert "daily work" in " ".join(parts)

    def test_quarterly_collects_monthly(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            monthly_dir = config["monthly_dir"]
            os.makedirs(monthly_dir, exist_ok=True)
            with open(os.path.join(monthly_dir, "2026-01.md"), "w") as f:
                f.write("# January\n\nJan work\n")
            with open(os.path.join(monthly_dir, "2026-02.md"), "w") as f:
                f.write("# February\n\nFeb work\n")
            parts = collect_lower_level_content("quarterly", "2026-Q1", config)
            assert len(parts) == 2

    def test_yearly_collects_quarterly(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            quarterly_dir = config["quarterly_dir"]
            os.makedirs(quarterly_dir, exist_ok=True)
            with open(os.path.join(quarterly_dir, "2026-Q1.md"), "w") as f:
                f.write("# Q1\n\nQ1 work\n")
            parts = collect_lower_level_content("yearly", "2026", config)
            assert len(parts) == 1
            assert "Q1 work" in parts[0]

    def test_empty_returns_empty_list(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            parts = collect_lower_level_content("weekly", "2026-W11", config)
            assert parts == []


class TestSynthesizePeriod:
    """Tests for synthesize_period function."""

    def test_synthesize_creates_note_with_source(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            daily_dir = config["daily_log_dir"]
            os.makedirs(daily_dir, exist_ok=True)
            with open(os.path.join(daily_dir, "2026-03-10.md"), "w") as f:
                f.write("# Daily\n\nBuilt the widget\n")
            path = synthesize_period("weekly", "2026-W11", config)
            assert path is not None
            with open(path, "r") as f:
                content = f.read()
            assert "Source Material" in content
            assert "Built the widget" in content
            assert "Weekly Note" in content

    def test_synthesize_no_content_returns_none(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            result = synthesize_period("weekly", "2026-W50", config)
            assert result is None


class TestLoadPeriodicContext:
    """Tests for load_periodic_context function."""

    def test_no_notes_returns_message(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            result = load_periodic_context(config)
            assert "No weekly/monthly notes" in result

    def test_loads_current_week(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            init_period("weekly", config=config)
            append_to_period("weekly", "This week's work", config=config)
            result = load_periodic_context(config)
            assert "WEEKLY" in result
            assert "This week's work" in result

    def test_loads_current_month(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _make_config(tmpdir)
            init_period("monthly", config=config)
            append_to_period("monthly", "This month's work", config=config)
            result = load_periodic_context(config)
            assert "MONTHLY" in result
            assert "This month's work" in result
