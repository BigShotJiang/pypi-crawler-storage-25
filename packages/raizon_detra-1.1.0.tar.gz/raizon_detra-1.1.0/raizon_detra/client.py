"""
raizon-detra: Official Python SDK for rAizon_detra x402 AI APIs
Supports both EVM (Base via eth-account) and Solana (via solders/solana) payment flows.

Quick start (EVM):
    from raizon_detra import RaizonClient
    client = RaizonClient(wallet_private_key="0x...")
    result = client.research(query="AI agent trends 2026")

Quick start (Solana):
    from raizon_detra import RaizonClient
    from solders.keypair import Keypair
    client = RaizonClient(solana_keypair=Keypair.from_base58_string("..."))
    result = client.research(query="AI agent trends 2026")
"""

from typing import Any, Dict, List, Optional, Union
import time
import json
import base64 as b64

import requests

# Optional EVM support
try:
    from eth_account import Account
    from eth_account.signers.local import LocalAccount
    HAS_EVM = True
except ImportError:
    HAS_EVM = False

# Optional Solana support
try:
    from solders.keypair import Keypair as SolanaKeypair
    from solders.pubkey import Pubkey as SolanaPubkey
    from solders.transaction import Transaction as SolanaTransaction
    from solders.instruction import Instruction as SolanaInstruction
    from solana.rpc.api import Client as SolanaClient
    from solana.rpc.commitment import Confirmed
    HAS_SOLANA = True
except ImportError:
    HAS_SOLANA = False


# ============================================================================
# Constants
# ============================================================================

SOLANA_USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
ASSOCIATED_TOKEN_PROGRAM_ID = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"

DEFAULT_BASE_URL = "https://api.rzndtra.com"
DEFAULT_MAX_POLLS = 30
DEFAULT_POLL_INTERVAL = 2.0
DEFAULT_TIMEOUT = 30.0


# ============================================================================
# Errors
# ============================================================================

class RaizonError(Exception):
    """Base error for rAizon_detra SDK."""
    def __init__(self, message: str, status_code: int = None, response: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class PaymentRequiredError(RaizonError):
    """Raised when a 402 Payment Required response is received."""
    def __init__(self, payment: Dict, response: Any = None):
        self.payment = payment
        amount = payment.get("amount", "unknown")
        currency = payment.get("currency", "USDC")
        network = payment.get("network", "unknown")
        super().__init__(
            f"Payment required: {amount} {currency} on {network}",
            402, response
        )


class PollingTimeoutError(RaizonError):
    """Raised when async polling exceeds max attempts."""
    def __init__(self, request_id: str, polls: int):
        super().__init__(
            f"Polling timed out after {polls} attempts for request {request_id}",
            408
        )


# ============================================================================
# Solana payment builder
# ============================================================================

def _build_solana_payment_x402(
    keypair: "SolanaKeypair",
    amount: str,
    pay_to: str,
    rpc_url: str = "https://api.mainnet-beta.solana.com",
) -> str:
    """Build an x402-compatible payment header for Solana USDC transfer.

    Creates a signed SPL Token transfer instruction, serializes it,
    and wraps it in the x402 payment header format.
    """
    if not HAS_SOLANA:
        raise RaizonError(
            "Solana support not installed. pip install solders solana spl-token"
        )

    connection = SolanaClient(rpc_url, commitment=Confirmed)

    from solders.system_program import get_associated_token_address
    from spl.token.instructions import transfer_checked, TransferCheckedParams

    sender_pubkey = keypair.pubkey()
    receiver_pubkey = SolanaPubkey.from_string(pay_to)
    mint_pubkey = SolanaPubkey.from_string(SOLANA_USDC_MINT)

    sender_ata = get_associated_token_address(sender_pubkey, mint_pubkey)
    receiver_ata = get_associated_token_address(receiver_pubkey, mint_pubkey)

    # USDC has 6 decimals
    amount_raw = int(float(amount) * 1_000_000)

    transfer_ix = transfer_checked(
        TransferCheckedParams(
            program_id=SolanaPubkey.from_string(TOKEN_PROGRAM_ID),
            source=sender_ata,
            mint=mint_pubkey,
            dest=receiver_ata,
            owner=sender_pubkey,
            amount=amount_raw,
            decimals=6,
        )
    )

    # Get recent blockhash
    blockhash_resp = connection.get_latest_blockhash()
    recent_blockhash = blockhash_resp.value.blockhash

    tx = SolanaTransaction.from_keypairs(
        [transfer_ix],
        [keypair],
        recent_blockhash,
    )
    tx.sign([keypair], recent_blockhash)

    serialized = b64.b64encode(bytes(tx)).decode("ascii")

    payment_payload = {
        "x402Version": 1,
        "scheme": "payTo",
        "network": "solana",
        "payload": {
            "serializedTransaction": serialized,
            "fromPubkey": str(sender_pubkey),
            "toPubkey": str(receiver_pubkey),
            "amount": str(amount_raw),
            "mint": SOLANA_USDC_MINT,
        },
    }

    return b64.b64encode(json.dumps(payment_payload).encode()).decode()


def _build_evm_payment_x402(
    account: "LocalAccount",
    payment: Dict,
) -> str:
    """Build an x402-compatible payment header for EVM USDC transfer."""
    if not HAS_EVM:
        raise RaizonError("EVM support not installed. pip install eth-account")

    from eth_account.messages import encode_typed_data

    chain_id = payment.get("chainId", 8453)
    verifying_contract = payment.get(
        "asset", "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
    )
    pay_to = "0x94b32b5118962a5be0c453aad2ee00c2d5a9545a"

    domain = {
        "name": "USD Coin",
        "version": "2",
        "chainId": chain_id,
        "verifyingContract": verifying_contract,
    }

    types = {
        "TransferWithAuthorization": [
            {"name": "from", "type": "address"},
            {"name": "to", "type": "address"},
            {"name": "value", "type": "uint256"},
            {"name": "validAfter", "type": "uint256"},
            {"name": "validBefore", "type": "uint256"},
            {"name": "nonce", "type": "bytes32"},
        ],
    }

    import secrets
    import time as _time

    nonce = secrets.token_bytes(32).hex()
    now = int(_time.time())

    message = {
        "from": account.address,
        "to": pay_to,
        "value": payment["amount"],
        "validAfter": "0",
        "validBefore": str(now + 3600),
        "nonce": "0x" + nonce,
    }

    full_message = encode_typed_data(
        domain_data=domain,
        message_types={"TransferWithAuthorization": types["TransferWithAuthorization"]},
        message_data=message,
    )
    signed = account.sign_message(full_message)

    payment_payload = {
        "x402Version": 2,
        "scheme": "exact",
        "network": payment.get("network", "eip155:8453"),
        "payload": {
            "signature": signed.signature.hex(),
            "authorization": message,
        },
    }

    return b64.b64encode(json.dumps(payment_payload).encode()).decode()


# ============================================================================
# Client
# ============================================================================

class RaizonClient:
    """Official Python SDK for rAizon_detra x402 AI APIs.

    Supports both EVM (Base) and Solana wallets for automatic payment.

    Args:
        base_url: API base URL. Default: https://api.rzndtra.com
        wallet_private_key: EVM private key (0x...) for Base chain payments
        solana_keypair: Solders Keypair for Solana payments
        solana_rpc_url: Solana RPC URL. Default: mainnet-beta
        max_poll: Max polling attempts for async endpoints
        poll_interval: Initial polling interval in seconds
        timeout: Request timeout in seconds

    Example (EVM):
        client = RaizonClient(wallet_private_key="0x...")
        result = client.research(query="AI trends 2026")

    Example (Solana):
        from solders.keypair import Keypair
        kp = Keypair.from_base58_string("...")
        client = RaizonClient(solana_keypair=kp)
        result = client.research(query="AI trends 2026")
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        wallet_private_key: Optional[str] = None,
        solana_keypair: Optional["SolanaKeypair"] = None,
        solana_rpc_url: str = "https://api.mainnet-beta.solana.com",
        max_poll: int = DEFAULT_MAX_POLLS,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.base_url = base_url.rstrip("/")
        self.solana_rpc_url = solana_rpc_url
        self.max_poll = max_poll
        self.poll_interval = poll_interval
        self.timeout = timeout

        # EVM setup
        self._evm_account: Optional["LocalAccount"] = None
        if wallet_private_key:
            if not HAS_EVM:
                raise RaizonError("eth-account not installed. pip install eth-account")
            self._evm_account = Account.from_key(wallet_private_key)

        # Solana setup
        self._solana_keypair = solana_keypair
        if solana_keypair and not HAS_SOLANA:
            raise RaizonError(
                "solders not installed. pip install solders solana spl-token"
            )

    @property
    def wallet_type(self) -> str:
        """Returns 'evm', 'solana', or 'none'."""
        if self._evm_account:
            return "evm"
        if self._solana_keypair:
            return "solana"
        return "none"

    @property
    def address(self) -> Optional[str]:
        """Returns the wallet address."""
        if self._evm_account:
            return self._evm_account.address
        if self._solana_keypair:
            return str(self._solana_keypair.pubkey())
        return None

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        body: Any = None,
        retry_with_payment: bool = True,
    ) -> Any:
        url = f"{self.base_url}{path}"
        headers = {"Content-Type": "application/json", "Accept": "application/json"}

        resp = requests.request(
            method, url, headers=headers,
            json=body, timeout=self.timeout,
        )

        if resp.status_code == 402 and retry_with_payment:
            payment_info = self._parse_payment_headers(resp)
            if payment_info:
                return self._pay_and_retry(method, path, body, payment_info)

        if resp.status_code == 402:
            payment_info = self._parse_payment_headers(resp)
            raise PaymentRequiredError(
                payment_info or {"amount": "unknown", "currency": "USDC", "network": "eip155:8453"},
                resp,
            )

        if not resp.ok:
            raise RaizonError(
                f"HTTP {resp.status_code}: {resp.text}", resp.status_code, resp
            )

        return resp.json()

    def _parse_payment_headers(self, resp) -> Optional[Dict]:
        # Primary: standard x402 payment-required header
        payment_required = resp.headers.get("payment-required")
        if payment_required:
            try:
                decoded = json.loads(b64.b64decode(payment_required).decode())
                if decoded.get("accepts"):
                    accept = decoded["accepts"][0]
                    return {
                        "amount": accept["amount"],
                        "currency": "USDC",
                        "network": accept.get("network", "eip155:8453"),
                        "asset": accept.get("asset"),
                        "chainId": accept.get("extra", {}).get("chainId", 8453),
                        "verifyingContract": accept.get("extra", {}).get(
                            "verifyingContract", accept.get("asset")
                        ),
                    }
            except Exception:
                pass

        # Fallback: custom headers
        amount = resp.headers.get("X-Payment-Amount")
        if amount:
            return {
                "amount": amount,
                "currency": resp.headers.get("X-Payment-Asset", "USDC"),
                "network": resp.headers.get("X-Payment-Network", "eip155:8453"),
                "asset": resp.headers.get("X-Payment-Asset"),
            }

        return None

    def _pay_and_retry(
        self, method: str, path: str, body: Any, payment: Dict
    ) -> Any:
        network = payment.get("network", "")

        if "solana" in network:
            payment_header = _build_solana_payment_x402(
                keypair=self._solana_keypair,
                amount=payment["amount"],
                pay_to=payment.get("payTo", "YOUR_SOLANA_PAYMENT_ADDRESS"),
                rpc_url=self.solana_rpc_url,
            )
        elif self._evm_account:
            payment_header = _build_evm_payment_x402(self._evm_account, payment)
        else:
            raise RaizonError(
                f"Wallet required for {network} payment but none configured"
            )

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Payment": payment_header,
        }
        url = f"{self.base_url}{path}"
        resp = requests.request(
            method, url, headers=headers,
            json=body, timeout=self.timeout,
        )

        if not resp.ok:
            raise RaizonError(
                f"HTTP {resp.status_code}: {resp.text}", resp.status_code, resp
            )

        return resp.json()

    def _poll_for_result(self, request_id: str) -> Dict:
        interval = self.poll_interval
        max_interval = 30.0

        for _ in range(self.max_poll):
            time.sleep(interval)
            result = self._request(
                "GET", f"/api/v1/response/{request_id}", retry_with_payment=False
            )
            if result.get("status") in ("completed", "failed"):
                return result
            interval = min(interval * 2, max_interval)

        raise PollingTimeoutError(request_id, self.max_poll)

    def _async_call(self, service: str, body: Any) -> Any:
        response = self._request("POST", f"/api/v1/{service}", body)
        result = self._poll_for_result(response["id"])
        if result.get("status") == "failed":
            raise RaizonError(result.get("error", "Request failed"))
        return result

    # -----------------------------------------------------------------------
    # AI Endpoints (async, auto-poll)
    # -----------------------------------------------------------------------

    def research(self, query: str, depth: str = "standard") -> Dict:
        """AI research & analysis."""
        return self._async_call("research", {"query": query, "depth": depth})

    def content(
        self, prompt: str, type: str = "article", tone: str = "", length: str = ""
    ) -> Dict:
        """AI content generation."""
        return self._async_call(
            "content", {"prompt": prompt, "type": type, "tone": tone, "length": length}
        )

    def code_review(self, code: str, language: str = "") -> Dict:
        """AI code review."""
        return self._async_call("code-review", {"code": code, "language": language})

    def scrape(self, url: str, format: str = "markdown") -> Dict:
        """Web scraping."""
        return self._async_call("scrape", {"url": url, "format": format})

    def signals(
        self, topic: str, sources: List[str] = None, timeframe: str = "24h"
    ) -> Dict:
        """Real-time signals."""
        body: Dict = {"topic": topic, "timeframe": timeframe}
        if sources:
            body["sources"] = sources
        return self._async_call("signals", body)

    def signals_enhanced(
        self, topic: str, sources: List[str] = None, timeframe: str = "24h"
    ) -> Dict:
        """Enhanced signals with X/Twitter data."""
        body: Dict = {"topic": topic, "timeframe": timeframe}
        if sources:
            body["sources"] = sources
        return self._async_call("signals-enhanced", body)

    def enrich(self, data: str, fields: str = "") -> Dict:
        """Data enrichment."""
        return self._async_call("enrich", {"data": data, "fields": fields})

    def verify(self, claim: str, context: str = "") -> Dict:
        """Compliance verification."""
        return self._async_call("verify", {"claim": claim, "context": context})

    def inference(self, prompt: str, model: str = "", max_tokens: int = 0) -> Dict:
        """LLM inference."""
        body: Dict = {"prompt": prompt}
        if model:
            body["model"] = model
        if max_tokens:
            body["max_tokens"] = max_tokens
        return self._async_call("inference", body)

    def wiki(self, **kwargs) -> Dict:
        """Wiki generation from X profiles or URLs."""
        return self._async_call("wiki", kwargs)

    def enrich_x(self, **kwargs) -> Dict:
        """X/Twitter profile enrichment."""
        return self._async_call("enrich-x", kwargs)

    # -----------------------------------------------------------------------
    # Intelligence Endpoints (sync)
    # -----------------------------------------------------------------------

    def market_intelligence(self, **kwargs) -> Any:
        params = "&".join(f"{k}={v}" for k, v in kwargs.items())
        qs = f"?{params}" if params else ""
        return self._request("GET", f"/api/v1/intelligence{qs}")

    def pricing_intelligence(self, category: str = "") -> Any:
        qs = f"?{category}" if category else ""
        return self._request("GET", f"/api/v1/intelligence/pricing{qs}")

    def agent_intelligence(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/agents")

    def raw_trends(self, window: int = 24) -> Any:
        return self._request("GET", f"/api/v1/intelligence/trends?window={window}")

    def wallet_intelligence(self, limit: int = 50) -> Any:
        return self._request("GET", f"/api/v1/intelligence/wallets?limit={limit}")

    def endpoint_intelligence(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/endpoints")

    def demand_forecast(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/forecast")

    def security_intelligence(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/security")

    def competitive_intelligence(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/competitive")

    def full_intelligence(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/full")

    # -----------------------------------------------------------------------
    # Free Endpoints
    # -----------------------------------------------------------------------

    def get_prices(self) -> Dict:
        return self._request("GET", "/api/v1/prices")

    def get_services(self) -> Dict:
        return self._request("GET", "/services")

    def health(self) -> Dict:
        return self._request("GET", "/health")

    def stats(self) -> Dict:
        return self._request("GET", "/api/v1/json-stats")

    def agent_summary(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/agents/summary")

    def endpoint_summary(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/endpoints/summary")

    def market_summary(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/market/summary")

    def forecast_summary(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/forecast/summary")

    def security_summary(self) -> Any:
        return self._request("GET", "/api/v1/intelligence/security/summary")

    def transactions(self, limit: int = 20) -> Any:
        return self._request("GET", f"/api/v1/transactions?limit={limit}")

    def feed(self, limit: int = 20) -> Any:
        return self._request("GET", f"/api/v1/feed?limit={limit}")

    def volume(self, window: str = "24h") -> Any:
        return self._request("GET", f"/api/v1/volume?window={window}")

    def volume_by_niche(self, niche: str, window: str = "24h") -> Any:
        return self._request("GET", f"/api/v1/volume/{niche}?window={window}")

    def all_volumes(self, window: str = "24h") -> Any:
        return self._request("GET", f"/api/v1/volumes?window={window}")

    def get_open_api_spec(self) -> Any:
        return self._request("GET", "/openapi.json")

    def get_agent_card(self) -> Any:
        return self._request("GET", "/.well-known/agent-card.json")

    def get_bazaar_info(self) -> Any:
        return self._request("GET", "/.well-known/x402-bazaar.json")


def create_client(**kwargs) -> RaizonClient:
    """Convenience factory. Same as RaizonClient(**kwargs)."""
    return RaizonClient(**kwargs)
