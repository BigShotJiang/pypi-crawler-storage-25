# raizon-detra

Official Python SDK for [rAizon_detra](https://api.rzndtra.com) — x402 AI APIs for agents.

## Install

```bash
pip install raizon-detra
```

## Quick Start

```python
from raizon_detra import RaizonClient

client = RaizonClient()

# Free endpoints
prices = client.get_prices()
health = client.health()

# AI endpoints (async — auto-polls)
result = client.research(query="AI agent trends 2026")
print(result)

# Intelligence endpoints
intel = client.market_intelligence(window="24h")
print(intel)
```

## With Wallet (auto-payment)

```python
from raizon_detra import RaizonClient

client = RaizonClient(wallet_private_key="0x...")

# Automatically handles 402 → sign payment → retry → poll
result = client.research(query="AI agent trends 2026")
print(result)
```

## API

### AI Endpoints (async — auto-polls)

| Method | Description |
|--------|-------------|
| `client.research(query, depth)` | AI research & analysis |
| `client.content(prompt, type, tone)` | AI content generation |
| `client.code_review(code, language)` | AI code review |
| `client.scrape(url, format)` | Web scraping |
| `client.signals(topic, sources, timeframe)` | Real-time signals |
| `client.signals_enhanced(topic, sources, timeframe)` | Enhanced signals |
| `client.enrich(data, fields)` | Data enrichment |
| `client.verify(claim, context)` | Compliance verification |
| `client.inference(prompt, model, max_tokens)` | LLM inference |
| `client.wiki(**kwargs)` | Wiki generation |
| `client.enrich_x(**kwargs)` | X/Twitter profile enrichment |

### Intelligence Endpoints (sync)

| Method | Description |
|--------|-------------|
| `client.market_intelligence(**kwargs)` | Market trend intelligence |
| `client.pricing_intelligence(category)` | Pricing intelligence |
| `client.agent_intelligence()` | Agent behavior analytics |
| `client.raw_trends(window)` | Raw trend data |
| `client.wallet_intelligence(limit)` | Wallet profiles + RFM scoring |
| `client.endpoint_intelligence()` | Endpoint popularity index |
| `client.demand_forecast()` | Demand forecasting |
| `client.security_intelligence()` | Wash detection |
| `client.competitive_intelligence()` | Competitive intelligence |
| `client.full_intelligence()` | Full intelligence report |

### Free Endpoints

| Method | Description |
|--------|-------------|
| `client.get_prices()` | Live service prices |
| `client.get_services()` | Service catalog |
| `client.health()` | Health check |
| `client.stats()` | Server stats |
| `client.agent_summary()` | Free agent summary |
| `client.endpoint_summary()` | Free endpoint summary |
| `client.market_summary()` | Free market summary |
| `client.forecast_summary()` | Free forecast summary |
| `client.security_summary()` | Free security summary |
| `client.transactions(limit)` | Recent transactions |
| `client.feed(limit)` | Live transaction ticker |
| `client.volume(window)` | Volume data |
| `client.volume_by_niche(niche, window)` | Volume by niche |
| `client.all_volumes(window)` | All niche volumes |

## Error Handling

```python
from raizon_detra import RaizonClient, PaymentRequiredError, PollingTimeoutError

try:
    result = client.research(query="test")
except PaymentRequiredError as e:
    print(f"Payment required: {e.payment.amount} {e.payment.currency}")
except PollingTimeoutError as e:
    print(f"Still processing, check back later: {e.request_id}")
except Exception as e:
    print(f"Error: {e}")
```

## Configuration

```python
client = RaizonClient(
    base_url="https://api.rzndtra.com",  # default
    wallet_private_key="0x...",           # for auto-payment
    max_polls=30,                         # default: 30
    poll_interval=2.0,                    # seconds, default: 2
    timeout=30.0,                         # seconds, default: 30
)
```

## License

MIT
