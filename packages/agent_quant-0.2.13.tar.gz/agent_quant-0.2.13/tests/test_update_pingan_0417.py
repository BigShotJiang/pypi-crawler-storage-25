# -*- coding: utf-8 -*-
"""
Agent测试: 更新平安银行4月17日数据
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.api import StockAPI

print("=" * 60)
print("Agent: 更新平安银行4月17日数据")
print("=" * 60)

# 初始化API
api = StockAPI()

# 检查数据库连接
print("\n[步骤1] 检查数据库连接...")
if not api.ping():
    print("  [FAIL] 数据库服务器未启动")
    print("  请先运行: start_db_server.bat")
    sys.exit(1)
print("  [OK] 数据库连接成功")

# 更新平安银行4月17日数据
print("\n[步骤2] 更新平安银行(000001.SZ) 2026-04-17数据...")
result = api.update_daily(
    codes=['000001.SZ'],
    target_date=date(2026, 4, 17)
)

print(f"\n[结果]")
print(f"  成功: {result['success']}")
print(f"  保存记录数: {result['saved_count']}")
print(f"  消息: {result['message']}")

if result['success']:
    print("\n[步骤3] 验证更新结果...")
    df = api.get_daily('000001.SZ', date(2026, 4, 17), date(2026, 4, 17))
    if not df.empty:
        print(f"  [OK] 数据验证成功")
        print(f"  股票: {df['code'].iloc[0]}")
        print(f"  日期: {df['trade_date'].iloc[0]}")
        print(f"  开盘: {df['open'].iloc[0]}")
        print(f"  收盘: {df['close'].iloc[0]}")
        print(f"  最高: {df['high'].iloc[0]}")
        print(f"  最低: {df['low'].iloc[0]}")
        print(f"  成交量: {df['volume'].iloc[0]}")
    else:
        print("  [WARN] 未查询到数据")
    
    print("\n" + "=" * 60)
    print("Agent: 任务完成！平安银行4月17日数据已更新")
    print("=" * 60)
else:
    print("\n" + "=" * 60)
    print(f"Agent: 更新失败 - {result['message']}")
    print("=" * 60)
