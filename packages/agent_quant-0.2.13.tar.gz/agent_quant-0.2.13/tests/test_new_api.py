# -*- coding: utf-8 -*-
"""
测试新的StockAPI
"""

import sys
import os
# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.api import StockAPI

print("=" * 60)
print("测试新的 StockAPI")
print("=" * 60)

# 初始化API
api = StockAPI()

# 1. 测试连接
print("\n[1] 测试连接...")
if api.ping():
    print("  [OK] 数据库连接成功")
else:
    print("  [FAIL] 数据库连接失败")
    sys.exit(1)

# 2. 查询股票列表
print("\n[2] 查询股票列表...")
stocks = api.get_all_stocks()
print(f"  [OK] 共有 {len(stocks)} 只股票")

# 3. 查询单只股票
print("\n[3] 查询单只股票...")
test_code = '000001.SZ'
test_date = date(2026, 4, 17)
df = api.get_daily(test_code, test_date, test_date)
if not df.empty:
    print(f"  [OK] {test_code}: 收盘={df['close'].iloc[0]}, 成交量={df['volume'].iloc[0]}")
else:
    print(f"  [WARN] {test_code}: 无数据")

# 4. 批量查询
print("\n[4] 批量查询...")
codes = ['000001.SZ', '000002.SZ', '600000.SH']
df = api.get_daily_multi(codes, test_date, test_date)
print(f"  [OK] 查询到 {len(df)} 条记录")

# 5. 获取最新日期
print("\n[5] 获取最新日期...")
latest = api.get_latest_date()
print(f"  [OK] 最新日期: {latest}")

# 6. 更新单只股票（测试API接口，不实际执行更新）
print("\n[6] 测试更新接口...")
print(f"  update_daily方法存在: {hasattr(api, 'update_daily')}")

print("\n" + "=" * 60)
print("所有测试通过！新的StockAPI工作正常")
print("=" * 60)
