# -*- coding: utf-8 -*-
"""
检查2026-04-20是星期几
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
import calendar

print("=" * 60)
print("检查2026-04-20日期信息")
print("=" * 60)

d = date(2026, 4, 20)
weekday = d.weekday()
weekday_name = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'][weekday]

print(f"\n日期: {d}")
print(f"星期: {weekday_name} (weekday={weekday})")
print(f"是否周末: {'是' if weekday >= 5 else '否'}")

# 检查4月17-22日的星期
print("\n" + "-" * 60)
print("4月17-22日星期对照:")
for day in range(17, 23):
    d = date(2026, 4, day)
    weekday_name = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'][d.weekday()]
    print(f"  4月{day}日: {weekday_name}")

print("\n" + "=" * 60)
