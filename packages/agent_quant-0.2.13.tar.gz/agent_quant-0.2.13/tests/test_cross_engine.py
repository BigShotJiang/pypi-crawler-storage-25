# -*- coding: utf-8 -*-
"""
跨引擎回测对比测试
对比CSKhQuant和JQData的回测结果
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.backtest.api import get_backtest_api


def test_cross_engine_comparison():
    """测试跨引擎对比"""
    print("\n=== 跨引擎回测对比测试 ===")
    print("对比CSKhQuant和JQData的回测结果\n")
    
    api = get_backtest_api()
    
    # 运行跨引擎验证
    report = api.validate_cross_engine(
        factor_name='CROSS',
        start_date='2024-01-01',
        end_date='2024-06-30',
        factor_params={'short_window': 5, 'long_window': 20}
    )
    
    print(f"\n参与引擎: {', '.join(report.engine_names)}")
    print(f"一致性得分: {report.consistency_score:.1f}/100")
    print(f"结果一致: {'是' if report.is_consistent else '否'}")
    
    print("\n指标对比:")
    print(report.metrics_comparison.to_string())
    
    if report.warnings:
        print("\n警告:")
        for warning in report.warnings:
            print(f"  - {warning}")
    else:
        print("\n✓ 所有引擎结果一致，数据可信！")
    
    recommended = api._validator.recommend_engine()
    print(f"\n推荐引擎: {recommended}")
    
    return report.is_consistent


def main():
    """运行测试"""
    print("="*60)
    print("跨引擎回测对比测试")
    print("="*60)
    
    try:
        is_consistent = test_cross_engine_comparison()
        
        print("\n" + "="*60)
        if is_consistent:
            print("✓ 测试通过：各引擎结果一致")
            return 0
        else:
            print("⚠ 测试警告：引擎结果存在差异")
            return 1
            
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
