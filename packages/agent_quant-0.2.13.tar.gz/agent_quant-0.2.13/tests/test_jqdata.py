# -*- coding: utf-8 -*-
"""
JQData引擎测试
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.backtest.base import BacktestConfig
from claw_quant.backtest.engines.jqdata_engine import JQDataEngine


def test_jqdata_connection():
    """测试JQData连接"""
    print("\n=== 测试JQData连接 ===")
    
    # JQData账号信息
    username = "13318366015"
    password = "8301953Aa"
    
    config = BacktestConfig(
        start_date=date(2024, 1, 1),
        end_date=date(2024, 3, 31),
        init_capital=100000,
        universe=['000001.SZ']
    )
    
    engine = JQDataEngine(config, username=username, password=password)
    
    # 检查是否可用
    if not engine.is_available():
        print("✗ JQData SDK未安装")
        return False
    
    print("✓ JQData SDK已安装")
    
    try:
        # 测试连接
        engine._connect()
        print("✓ JQData登录成功")
        
        # 测试获取数据
        import jqdatasdk as jq
        df = jq.get_price('000001.XSHE', start_date='2024-01-01', end_date='2024-01-10', frequency='daily')
        print(f"✓ 数据获取成功，共{len(df)}条记录")
        print(f"  数据列: {list(df.columns)}")
        print(f"  前5行:\n{df.head()}")
        
        return True
        
    except Exception as e:
        print(f"✗ 连接失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_jqdata_backtest():
    """测试JQData回测"""
    print("\n=== 测试JQData回测 ===")
    
    username = "13318366015"
    password = "8301953Aa"
    
    config = BacktestConfig(
        start_date=date(2024, 1, 1),
        end_date=date(2024, 6, 30),
        init_capital=100000,
        universe=['000001.SZ']
    )
    
    engine = JQDataEngine(config, username=username, password=password)
    
    try:
        # 运行CROSS因子回测
        result = engine.run('CROSS', factor_params={'short_window': 5, 'long_window': 20})
        
        print(f"✓ 回测完成")
        print(f"  总收益率: {result.total_return:.2%}")
        print(f"  年化收益率: {result.annual_return:.2%}")
        print(f"  最大回撤: {result.max_drawdown:.2%}")
        print(f"  夏普比率: {result.sharpe_ratio:.2f}")
        print(f"  交易次数: {result.total_trades}")
        print(f"  胜率: {result.win_rate:.2%}")
        
        if result.trades:
            print(f"\n  交易记录（前3条）:")
            for t in result.trades[:3]:
                print(f"    {t.trade_date} {t.direction.value} {t.code} @ {t.price:.2f}")
        
        return True
        
    except Exception as e:
        print(f"✗ 回测失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """运行所有测试"""
    print("="*60)
    print("JQData引擎测试")
    print("="*60)
    
    results = []
    
    # 测试连接
    results.append(("连接测试", test_jqdata_connection()))
    
    # 测试回测
    results.append(("回测测试", test_jqdata_backtest()))
    
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)
    
    for name, passed in results:
        status = "✓ 通过" if passed else "✗ 失败"
        print(f"{name}: {status}")
    
    all_passed = all(r[1] for r in results)
    
    if all_passed:
        print("\n所有测试通过！")
        return 0
    else:
        print("\n部分测试失败")
        return 1


if __name__ == '__main__':
    sys.exit(main())
