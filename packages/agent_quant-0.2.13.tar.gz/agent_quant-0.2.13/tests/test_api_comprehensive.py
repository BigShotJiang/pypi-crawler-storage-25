# -*- coding: utf-8 -*-
"""
API全面测试脚本
测试内容包括:
1. 单个API调用测试
2. 多进程并发调用测试
3. 数据库server调度能力测试
"""

import sys
import os
import time
import random
import concurrent.futures
from datetime import date, datetime, timedelta
from multiprocessing import Pool, Process, Manager
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from claw_quant.skills.stock_data.stock_api import StockAPI


class Colors:
    """终端颜色"""
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RESET = '\033[0m'


def log_success(msg):
    print(f"{Colors.GREEN}[OK]{Colors.RESET} {msg}")


def log_error(msg):
    print(f"{Colors.RED}[FAIL]{Colors.RESET} {msg}")


def log_info(msg):
    print(f"{Colors.BLUE}[INFO]{Colors.RESET} {msg}")


def log_warning(msg):
    print(f"{Colors.YELLOW}[WARN]{Colors.RESET} {msg}")


def log_section(title):
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.CYAN}{title}{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")


# ==================== 测试1: 基础连接测试 ====================

def test_basic_connection():
    """测试基础连接"""
    log_section("测试1: 基础连接测试")
    
    api = StockAPI()
    
    try:
        if api.ping():
            log_success("服务器连接正常")
            return True
        else:
            log_error("服务器连接失败")
            return False
    except Exception as e:
        log_error(f"连接异常: {e}")
        return False


# ==================== 测试2: 股票列表API测试 ====================

def test_stock_list_api():
    """测试股票列表API"""
    log_section("测试2: 股票列表API测试")
    
    api = StockAPI()
    
    try:
        stocks = api.get_all_stocks()
        if not stocks.empty:
            log_success(f"获取股票列表成功，共 {len(stocks)} 只股票")
            log_info(f"列名: {list(stocks.columns)}")
            log_info(f"前5条:\n{stocks.head()}")
            return True, stocks
        else:
            log_error("获取股票列表为空")
            return False, None
    except Exception as e:
        log_error(f"获取股票列表异常: {e}")
        return False, None


# ==================== 测试3: 单只股票日线数据API测试 ====================

def test_single_stock_daily():
    """测试单只股票日线数据API"""
    log_section("测试3: 单只股票日线数据API测试")
    
    api = StockAPI()
    test_code = '000001.SZ'  # 平安银行
    
    try:
        # 获取最新日期
        latest_date = api.get_latest_date()
        log_info(f"数据库最新日期: {latest_date}")
        
        # 查询最近10天的数据
        end_date = latest_date
        start_date = end_date - timedelta(days=20)
        
        df = api.get_daily(test_code, start_date, end_date)
        
        if not df.empty:
            log_success(f"获取 {test_code} 日线数据成功，共 {len(df)} 条")
            log_info(f"列名: {list(df.columns)}")
            log_info(f"数据样例:\n{df.head(3)}")
            return True
        else:
            log_warning(f"获取 {test_code} 日线数据为空，可能是该股票无数据")
            return True  # 空数据不一定是错误
    except Exception as e:
        log_error(f"获取单只股票日线数据异常: {e}")
        return False


# ==================== 测试4: 多只股票批量查询API测试 ====================

def test_multi_stock_daily():
    """测试多只股票批量查询API"""
    log_section("测试4: 多只股票批量查询API测试")
    
    api = StockAPI()
    test_codes = ['000001.SZ', '000002.SZ', '000063.SZ', '000333.SZ', '000858.SZ']
    
    try:
        latest_date = api.get_latest_date()
        end_date = latest_date
        start_date = end_date - timedelta(days=10)
        
        df = api.get_daily_multi(test_codes, start_date, end_date)
        
        if not df.empty:
            log_success(f"批量获取日线数据成功，共 {len(df)} 条")
            if 'code' in df.columns:
                code_counts = df['code'].value_counts()
                log_info(f"各股票数据条数:\n{code_counts}")
            return True
        else:
            log_warning("批量获取日线数据为空")
            return True
    except Exception as e:
        log_error(f"批量获取日线数据异常: {e}")
        return False


# ==================== 测试5: 多线程并发测试 ====================

def worker_thread_task(task_id, results_list):
    """工作线程任务"""
    api = StockAPI()
    test_codes = ['000001.SZ', '000002.SZ', '000063.SZ', '000333.SZ', '000858.SZ']
    
    try:
        latest_date = api.get_latest_date()
        code = random.choice(test_codes)
        start_date = latest_date - timedelta(days=random.randint(5, 30))
        end_date = latest_date
        
        start_time = time.time()
        df = api.get_daily(code, start_date, end_date)
        elapsed = time.time() - start_time
        
        results_list.append({
            'task_id': task_id,
            'success': True,
            'code': code,
            'rows': len(df),
            'time': elapsed
        })
        return True
    except Exception as e:
        results_list.append({
            'task_id': task_id,
            'success': False,
            'error': str(e)
        })
        return False


def test_multithread_concurrent():
    """测试多线程并发"""
    log_section("测试5: 多线程并发测试 (20线程)")
    
    num_threads = 20
    results_list = []
    threads = []
    
    start_time = time.time()
    
    for i in range(num_threads):
        t = threading.Thread(target=worker_thread_task, args=(i, results_list))
        threads.append(t)
        t.start()
    
    for t in threads:
        t.join()
    
    total_time = time.time() - start_time
    
    # 统计结果
    success_count = sum(1 for r in results_list if r.get('success'))
    fail_count = num_threads - success_count
    
    log_info(f"总耗时: {total_time:.2f}秒")
    log_info(f"成功: {success_count}/{num_threads}")
    log_info(f"失败: {fail_count}/{num_threads}")
    
    if success_count == num_threads:
        log_success("多线程并发测试通过")
        return True
    else:
        log_error(f"多线程并发测试失败，有 {fail_count} 个任务失败")
        for r in results_list:
            if not r.get('success'):
                log_error(f"  任务 {r['task_id']}: {r.get('error')}")
        return False


# ==================== 测试6: 多进程并发测试 ====================

def worker_process_task(args):
    """工作进程任务"""
    task_id, test_codes = args
    
    # 每个进程创建自己的API实例
    api = StockAPI()
    
    try:
        latest_date = api.get_latest_date()
        code = random.choice(test_codes)
        start_date = latest_date - timedelta(days=random.randint(5, 30))
        end_date = latest_date
        
        start_time = time.time()
        df = api.get_daily(code, start_date, end_date)
        elapsed = time.time() - start_time
        
        return {
            'task_id': task_id,
            'success': True,
            'code': code,
            'rows': len(df),
            'time': elapsed
        }
    except Exception as e:
        return {
            'task_id': task_id,
            'success': False,
            'error': str(e)
        }


def test_multiprocess_concurrent():
    """测试多进程并发"""
    log_section("测试6: 多进程并发测试 (10进程)")
    
    num_processes = 10
    test_codes = ['000001.SZ', '000002.SZ', '000063.SZ', '000333.SZ', '000858.SZ',
                  '600000.SH', '600001.SH', '600519.SH', '601318.SH', '000725.SZ']
    
    tasks = [(i, test_codes) for i in range(num_processes)]
    
    start_time = time.time()
    
    with Pool(processes=num_processes) as pool:
        results = pool.map(worker_process_task, tasks)
    
    total_time = time.time() - start_time
    
    # 统计结果
    success_count = sum(1 for r in results if r.get('success'))
    fail_count = num_processes - success_count
    
    log_info(f"总耗时: {total_time:.2f}秒")
    log_info(f"成功: {success_count}/{num_processes}")
    log_info(f"失败: {fail_count}/{num_processes}")
    
    if success_count == num_processes:
        log_success("多进程并发测试通过")
        return True
    else:
        log_error(f"多进程并发测试失败，有 {fail_count} 个任务失败")
        for r in results:
            if not r.get('success'):
                log_error(f"  任务 {r['task_id']}: {r.get('error')}")
        return False


# ==================== 测试7: 高并发压力测试 ====================

def stress_test_worker(task_id):
    """压力测试工作函数"""
    api = StockAPI()
    test_codes = ['000001.SZ', '000002.SZ', '000063.SZ', '000333.SZ', '000858.SZ',
                  '600000.SH', '600519.SH', '601318.SH', '000725.SZ', '002415.SZ']
    
    results = []
    num_requests = 10  # 每个worker发起10个请求
    
    for i in range(num_requests):
        try:
            latest_date = api.get_latest_date()
            code = random.choice(test_codes)
            start_date = latest_date - timedelta(days=random.randint(1, 60))
            end_date = latest_date
            
            start_time = time.time()
            df = api.get_daily(code, start_date, end_date)
            elapsed = time.time() - start_time
            
            results.append({
                'request_id': f"{task_id}-{i}",
                'success': True,
                'time': elapsed
            })
        except Exception as e:
            results.append({
                'request_id': f"{task_id}-{i}",
                'success': False,
                'error': str(e)
            })
        
        # 小延迟，模拟真实场景
        time.sleep(0.01)
    
    return results


def test_stress_concurrent():
    """高并发压力测试"""
    log_section("测试7: 高并发压力测试 (20进程 x 10请求 = 200请求)")
    
    num_workers = 20
    total_expected = num_workers * 10
    
    start_time = time.time()
    
    with Pool(processes=num_workers) as pool:
        all_results = pool.map(stress_test_worker, range(num_workers))
    
    total_time = time.time() - start_time
    
    # 扁平化结果
    flat_results = [r for worker_results in all_results for r in worker_results]
    
    success_count = sum(1 for r in flat_results if r.get('success'))
    fail_count = len(flat_results) - success_count
    avg_time = sum(r['time'] for r in flat_results if r.get('success')) / max(success_count, 1)
    
    log_info(f"总耗时: {total_time:.2f}秒")
    log_info(f"总请求数: {len(flat_results)}")
    log_info(f"成功: {success_count}")
    log_info(f"失败: {fail_count}")
    log_info(f"平均响应时间: {avg_time*1000:.2f}ms")
    log_info(f"QPS: {len(flat_results)/total_time:.2f}")
    
    if fail_count == 0:
        log_success("高并发压力测试通过，无请求失败")
        return True
    else:
        log_warning(f"高并发压力测试有 {fail_count} 个请求失败")
        # 显示前几个错误
        for r in flat_results:
            if not r.get('success'):
                log_error(f"  请求 {r['request_id']}: {r.get('error')}")
                break
        return fail_count < 5  # 允许少量失败


# ==================== 测试8: 混合操作测试 ====================

def mixed_operation_worker(task_id):
    """混合操作工作函数"""
    api = StockAPI()
    test_codes = ['000001.SZ', '000002.SZ', '000063.SZ', '000333.SZ', '000858.SZ']
    
    results = []
    
    try:
        # 操作1: 获取股票列表
        stocks = api.get_all_stocks()
        results.append({'op': 'get_all_stocks', 'success': True, 'rows': len(stocks)})
        
        # 操作2: 获取最新日期
        latest_date = api.get_latest_date()
        results.append({'op': 'get_latest_date', 'success': True, 'date': str(latest_date)})
        
        # 操作3: 单只股票查询
        code = random.choice(test_codes)
        df = api.get_daily(code, latest_date - timedelta(days=10), latest_date)
        results.append({'op': 'get_daily', 'success': True, 'code': code, 'rows': len(df)})
        
        # 操作4: 批量查询
        codes = random.sample(test_codes, 3)
        df = api.get_daily_multi(codes, latest_date - timedelta(days=5), latest_date)
        results.append({'op': 'get_daily_multi', 'success': True, 'rows': len(df)})
        
    except Exception as e:
        results.append({'op': 'mixed', 'success': False, 'error': str(e)})
    
    return results


def test_mixed_operations():
    """测试混合操作"""
    log_section("测试8: 混合操作并发测试 (10进程，每进程4种操作)")
    
    num_workers = 10
    
    start_time = time.time()
    
    with Pool(processes=num_workers) as pool:
        all_results = pool.map(mixed_operation_worker, range(num_workers))
    
    total_time = time.time() - start_time
    
    # 统计
    flat_results = [r for worker_results in all_results for r in worker_results]
    success_count = sum(1 for r in flat_results if r.get('success'))
    fail_count = len(flat_results) - success_count
    
    log_info(f"总耗时: {total_time:.2f}秒")
    log_info(f"总操作数: {len(flat_results)}")
    log_info(f"成功: {success_count}")
    log_info(f"失败: {fail_count}")
    
    # 按操作类型统计
    op_stats = {}
    for r in flat_results:
        op = r.get('op', 'unknown')
        if op not in op_stats:
            op_stats[op] = {'success': 0, 'fail': 0}
        if r.get('success'):
            op_stats[op]['success'] += 1
        else:
            op_stats[op]['fail'] += 1
    
    log_info("各操作类型统计:")
    for op, stats in op_stats.items():
        log_info(f"  {op}: 成功 {stats['success']}, 失败 {stats['fail']}")
    
    if fail_count == 0:
        log_success("混合操作测试通过")
        return True
    else:
        log_error(f"混合操作测试有 {fail_count} 个操作失败")
        return False


# ==================== 主函数 ====================

def run_all_tests():
    """运行所有测试"""
    print(f"\n{Colors.CYAN}{'#'*60}{Colors.RESET}")
    print(f"{Colors.CYAN}#{'':^58}#{Colors.RESET}")
    print(f"{Colors.CYAN}#{'API全面测试':^56}#{Colors.RESET}")
    print(f"{Colors.CYAN}#{'':^58}#{Colors.RESET}")
    print(f"{Colors.CYAN}{'#'*60}{Colors.RESET}\n")
    
    print(f"测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"测试目标: http://127.0.0.1:9529\n")
    
    results = {}
    
    # 基础测试
    results['basic_connection'] = test_basic_connection()
    
    if not results['basic_connection']:
        log_error("基础连接失败，终止后续测试")
        return results
    
    # API功能测试
    success, stocks_df = test_stock_list_api()
    results['stock_list_api'] = success
    
    if success and stocks_df is not None:
        results['single_stock_daily'] = test_single_stock_daily()
        results['multi_stock_daily'] = test_multi_stock_daily()
        
        # 并发测试
        results['multithread'] = test_multithread_concurrent()
        results['multiprocess'] = test_multiprocess_concurrent()
        results['stress'] = test_stress_concurrent()
        results['mixed_operations'] = test_mixed_operations()
    
    # 测试报告
    log_section("测试报告汇总")
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        status = f"{Colors.GREEN}通过{Colors.RESET}" if result else f"{Colors.RED}失败{Colors.RESET}"
        print(f"  {test_name:.<40} {status}")
    
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"总计: {passed}/{total} 项测试通过")
    
    if passed == total:
        print(f"{Colors.GREEN}所有测试通过！数据库server工作正常。{Colors.RESET}")
    else:
        print(f"{Colors.YELLOW}部分测试未通过，请检查日志。{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")
    
    return results


if __name__ == '__main__':
    run_all_tests()
