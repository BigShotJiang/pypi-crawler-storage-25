# -*- coding: utf-8 -*-
"""
回测框架测试
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
from datetime import date

from claw_quant.factor import FactorRegistry, MAFactor, CrossFactor
from claw_quant.backtest.base import BacktestConfig, BacktestResult
from claw_quant.backtest.api import BacktestAPI


def test_factor_registry():
    """测试因子注册表"""
    print("\n=== 测试因子注册表 ===")
    
    factors = FactorRegistry.list_factors()
    print(f"可用因子: {factors}")
    
    # 测试创建因子
    cross_factor = FactorRegistry.create('CROSS', {'short_window': 5, 'long_window': 20})
    assert cross_factor is not None
    print(f"CROSS因子创建成功: {cross_factor.get_info()}")
    
    print("✓ 因子注册表测试通过")


def test_factor_calculation():
    """测试因子计算"""
    print("\n=== 测试因子计算 ===")
    
    # 创建测试数据
    dates = pd.date_range('2024-01-01', periods=30, freq='D')
    np.random.seed(42)
    data = pd.DataFrame({
        'open': 10 + np.random.randn(30).cumsum() * 0.5,
        'high': 11 + np.random.randn(30).cumsum() * 0.5,
        'low': 9 + np.random.randn(30).cumsum() * 0.5,
        'close': 10 + np.random.randn(30).cumsum() * 0.5,
        'volume': np.random.randint(100000, 1000000, 30),
    }, index=dates)
    
    # 测试MA因子
    ma_factor = MAFactor(window=5)
    ma_values = ma_factor.calculate(data)
    print(f"MA5计算结果（前5个）: {ma_values.head().tolist()}")
    assert not ma_values.isna().all()
    
    # 测试CROSS因子
    cross_factor = CrossFactor(short_window=3, long_window=10)
    cross_signals = cross_factor.calculate(data)
    print(f"CROSS信号（非零）: {cross_signals[cross_signals != 0].tolist()}")
    
    print("✓ 因子计算测试通过")


def test_backtest_api():
    """测试回测API"""
    print("\n=== 测试回测API ===")
    
    api = BacktestAPI()
    
    # 测试列出因子
    factors = api.list_factors()
    print(f"API返回因子数: {len(factors)}")
    assert len(factors) > 0
    
    # 测试获取因子信息
    info = api.get_factor_info('CROSS')
    print(f"CROSS因子信息: {info}")
    assert info is not None
    
    print("✓ 回测API测试通过")


def test_backtest_config():
    """测试回测配置"""
    print("\n=== 测试回测配置 ===")
    
    config = BacktestConfig(
        start_date=date(2024, 1, 1),
        end_date=date(2024, 12, 31),
        init_capital=1000000,
        universe=['000001.SZ', '000002.SZ']
    )
    
    config_dict = config.to_dict()
    print(f"配置: {config_dict}")
    
    assert config_dict['init_capital'] == 1000000
    assert len(config_dict['universe']) == 2
    
    print("✓ 回测配置测试通过")


def test_cross_factor_logic():
    """测试交叉因子逻辑"""
    print("\n=== 测试交叉因子逻辑 ===")
    
    # 创建测试数据 - 模拟金叉死叉
    dates = pd.date_range('2024-01-01', periods=10, freq='D')
    data = pd.DataFrame({
        'close': [10, 11, 12, 11, 10, 9, 10, 11, 12, 13]  # 先涨后跌再涨
    }, index=dates)
    
    cross_factor = CrossFactor(short_window=2, long_window=5)
    signals = cross_factor.calculate(data)
    
    print(f"价格序列: {data['close'].tolist()}")
    print(f"交叉信号: {signals.tolist()}")
    
    # 检查信号值只能是 -1, 0, 1
    assert all(s in [-1, 0, 1] for s in signals.values)
    
    print("✓ 交叉因子逻辑测试通过")


def main():
    """运行所有测试"""
    print("="*60)
    print("回测框架测试")
    print("="*60)
    
    try:
        test_factor_registry()
        test_factor_calculation()
        test_backtest_api()
        test_backtest_config()
        test_cross_factor_logic()
        
        print("\n" + "="*60)
        print("所有测试通过！")
        print("="*60)
        return 0
        
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
