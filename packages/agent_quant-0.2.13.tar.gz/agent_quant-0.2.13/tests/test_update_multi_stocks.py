# -*- coding: utf-8 -*-
"""
测试更新多只股票数据
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from datetime import date
from claw_quant.database.db_http_client import DBHttpClient

print("=" * 60)
print("测试更新多只股票")
print("=" * 60)

# 创建客户端
client = DBHttpClient()

# 检查连接
if not client.ping():
    print("[FAIL] 无法连接到API服务器")
    sys.exit(1)

print("[OK] API服务器连接成功")

# 测试更新多只股票
test_codes = ['000001.SZ', '000002.SZ', '600000.SH']
test_date = date(2026, 4, 17)

print(f"\n测试更新 {len(test_codes)} 只股票")
print(f"股票: {', '.join(test_codes)}")
print(f"日期: {test_date}")
print("-" * 60)

import time
start = time.time()

try:
    result = client.update_daily(
        codes=test_codes,
        start_date=test_date,
        end_date=test_date
    )
    
    elapsed = time.time() - start
    
    print(f"\n更新结果:")
    print(f"  成功: {result.get('success')}")
    print(f"  保存数量: {result.get('saved_count')}")
    print(f"  消息: {result.get('message')}")
    print(f"  耗时: {elapsed:.2f}秒")
    
    if result.get('success'):
        print(f"\n[OK] {len(test_codes)}只股票更新成功！")
        
        # 验证数据
        print("\n验证数据:")
        for code in test_codes:
            df = client.get_market_data_daily(code, test_date, test_date)
            if not df.empty:
                print(f"  {code}: 收盘={df['close'].iloc[0]}, 成交量={df['volume'].iloc[0]}")
            else:
                print(f"  {code}: [无数据]")
    else:
        print(f"\n[FAIL] 更新失败: {result.get('message')}")
        
except Exception as e:
    print(f"\n[ERROR] 测试异常: {e}")
    import traceback
    traceback.print_exc()
