# -*- coding: utf-8 -*-
"""
测试QMT日期映射行为
验证请求某一天是否会返回前一天的交易日数据
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.data_source import QMTDataSource

print("=" * 60)
print("测试QMT日期映射行为")
print("=" * 60)

qmt = QMTDataSource()

# 测试请求4月21日，看是否返回4月20日数据
print("\n[测试1] 请求4月21日数据...")
df = qmt.get_market_data_batch(['000001.SZ'], '1d', date(2026, 4, 21), date(2026, 4, 21))
if not df.empty:
    actual_date = df['trade_date'].iloc[0]
    print(f"  请求日期: 2026-04-21")
    print(f"  返回日期: {actual_date}")
    print(f"  匹配: {'是' if actual_date == '2026-04-21' else '否 (返回的是前一日数据)'}")
    print(f"  数据: {df[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  无数据")

# 测试请求4月22日
print("\n[测试2] 请求4月22日数据...")
df = qmt.get_market_data_batch(['000001.SZ'], '1d', date(2026, 4, 22), date(2026, 4, 22))
if not df.empty:
    actual_date = df['trade_date'].iloc[0]
    print(f"  请求日期: 2026-04-22")
    print(f"  返回日期: {actual_date}")
    print(f"  匹配: {'是' if actual_date == '2026-04-22' else '否 (返回的是前一日数据)'}")
    print(f"  数据: {df[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  无数据")

# 测试请求4月23日
print("\n[测试3] 请求4月23日数据...")
df = qmt.get_market_data_batch(['000001.SZ'], '1d', date(2026, 4, 23), date(2026, 4, 23))
if not df.empty:
    actual_date = df['trade_date'].iloc[0]
    print(f"  请求日期: 2026-04-23")
    print(f"  返回日期: {actual_date}")
    print(f"  匹配: {'是' if actual_date == '2026-04-23' else '否 (返回的是前一日数据)'}")
    print(f"  数据: {df[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  无数据")

# 测试请求4月24日
print("\n[测试4] 请求4月24日数据...")
df = qmt.get_market_data_batch(['000001.SZ'], '1d', date(2026, 4, 24), date(2026, 4, 24))
if not df.empty:
    actual_date = df['trade_date'].iloc[0]
    print(f"  请求日期: 2026-04-24")
    print(f"  返回日期: {actual_date}")
    print(f"  匹配: {'是' if actual_date == '2026-04-24' else '否 (返回的是前一日数据)'}")
    print(f"  数据: {df[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  无数据")

print("\n" + "=" * 60)
