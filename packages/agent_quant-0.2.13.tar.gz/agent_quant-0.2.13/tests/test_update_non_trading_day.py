# -*- coding: utf-8 -*-
"""
测试非交易日更新
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.api import StockAPI

print("=" * 60)
print("测试非交易日更新提示")
print("=" * 60)

api = StockAPI()

# 测试更新4月20日（周日，非交易日）
print("\n[测试] 更新4月20日（非交易日）...")
result = api.update_daily(
    codes=['000001.SZ'],
    target_date=date(2026, 4, 20)
)

print(f"\n结果:")
print(f"  success: {result['success']}")
print(f"  message: {result['message']}")

if not result['success']:
    print("\n[OK] 正确提示非交易日！")
else:
    print("\n[WARN] 应该返回失败")

# 测试更新4月19日（交易日）
print("\n" + "-" * 60)
print("\n[测试] 更新4月19日（交易日）...")
result = api.update_daily(
    codes=['000001.SZ'],
    target_date=date(2026, 4, 19)
)

print(f"\n结果:")
print(f"  success: {result['success']}")
print(f"  message: {result['message']}")

if result['success']:
    print("\n[OK] 交易日更新成功！")
else:
    print("\n[WARN] 交易日应该成功")

print("\n" + "=" * 60)
