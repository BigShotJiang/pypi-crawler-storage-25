# -*- coding: utf-8 -*-
"""
统一回测引擎测试脚本

测试多引擎回测架构的各个组件
"""

import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from claw_quant.backtest.engines import (
    EngineType,
    BacktestInput,
    LocalEngineAdapter,
    UnifiedBacktestEngine,
    get_unified_engine
)
from claw_quant.skills.backtest.tools.backtest_api import BacktestToolAPI


def test_unified_engine():
    """测试统一回测引擎"""
    print("=" * 60)
    print("测试统一回测引擎架构")
    print("=" * 60)
    
    # 创建统一引擎
    engine = UnifiedBacktestEngine(
        default_engine=EngineType.LOCAL,
        engine_config={'host': '127.0.0.1', 'port': 9529}
    )
    
    # 注册本地引擎适配器
    engine.register_adapter(EngineType.LOCAL, lambda cfg: LocalEngineAdapter(cfg))
    
    # 获取可用引擎
    print("\n可用引擎列表:")
    engines = engine.get_available_engines()
    for e in engines:
        print(f"  - {e['type']}: {e['name']} (可用: {e['available']}, 默认: {e['is_default']})")
    
    return engine


def test_backtest_input():
    """测试回测输入参数"""
    print("\n" + "=" * 60)
    print("测试回测输入参数")
    print("=" * 60)
    
    # 创建输入参数
    input_params = BacktestInput(
        factor_name='CROSS',
        code='000001.SZ',
        start_date='2024-01-01',
        end_date='2024-06-01',
        init_capital=100000.0,
        factor_params={'short_window': 5, 'long_window': 20}
    )
    
    print(f"\n因子名称: {input_params.factor_name}")
    print(f"股票代码: {input_params.code}")
    print(f"开始日期: {input_params.start_date}")
    print(f"结束日期: {input_params.end_date}")
    print(f"初始资金: {input_params.init_capital}")
    print(f"因子参数: {input_params.factor_params}")
    
    # 测试标准化
    input_params.normalize()
    print(f"\n标准化后日期类型: {type(input_params.start_date)}")
    
    return input_params


def test_local_adapter():
    """测试本地引擎适配器"""
    print("\n" + "=" * 60)
    print("测试本地引擎适配器")
    print("=" * 60)
    
    # 创建适配器
    adapter = LocalEngineAdapter({'host': '127.0.0.1', 'port': 9529})
    
    # 检查可用性
    available = adapter.is_available()
    print(f"\n本地引擎可用: {available}")
    
    if available:
        print("数据库连接正常")
    else:
        print("数据库连接失败，请确保DuckDBServer正在运行")
    
    return adapter


def test_backtest_api():
    """测试回测API"""
    print("\n" + "=" * 60)
    print("测试回测API")
    print("=" * 60)
    
    # 创建API实例
    api = BacktestToolAPI(
        host='127.0.0.1',
        port=9529,
        default_engine='local'
    )
    
    # 检查连接
    print(f"\n数据库连接: {api.ping()}")
    
    # 获取可用引擎
    print("\n可用引擎:")
    engines = api.get_available_engines()
    for e in engines:
        print(f"  - {e['type']}: {e['description']}")
    
    # 获取可用因子
    print("\n可用因子:")
    factors = api.get_available_factors()
    for f in factors:
        print(f"  - {f['name']}: {f['description'][:50]}...")
    
    return api


def test_run_backtest():
    """测试运行回测"""
    print("\n" + "=" * 60)
    print("测试运行回测")
    print("=" * 60)
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print("\n数据库未连接，跳过回测测试")
        print("请先启动DuckDBServer并确保数据已加载")
        return None
    
    print("\n运行均线交叉回测 (CROSS):")
    result = api.run_backtest(
        factor_name='CROSS',
        code='000001.SZ',
        start_date='2024-01-01',
        end_date='2024-06-01',
        init_capital=100000,
        factor_params={'short_window': 5, 'long_window': 20},
        engine='local'
    )
    
    if result.get('success'):
        print(f"\n回测成功!")
        print(f"  引擎: {result['engine_name']}")
        print(f"  总收益率: {result['total_return']:.2%}")
        print(f"  年化收益率: {result['annual_return']:.2%}")
        print(f"  最大回撤: {result['max_drawdown']:.2%}")
        print(f"  夏普比率: {result['sharpe_ratio']:.2f}")
        print(f"  交易次数: {result['total_trades']}")
        print(f"  胜率: {result['win_rate']:.2%}")
    else:
        print(f"\n回测失败: {result.get('error')}")
    
    return result


def test_multi_engine():
    """测试多引擎对比"""
    print("\n" + "=" * 60)
    print("测试多引擎对比")
    print("=" * 60)
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print("\n数据库未连接，跳过多引擎测试")
        return
    
    engines_to_test = ['local']
    
    # 检查其他引擎是否可用
    available_engines = api.get_available_engines()
    for e in available_engines:
        if e['available'] and e['type'] != 'local':
            engines_to_test.append(e['type'])
    
    print(f"\n测试引擎: {engines_to_test}")
    
    results = {}
    for engine_name in engines_to_test:
        print(f"\n使用引擎 '{engine_name}' 运行回测...")
        try:
            result = api.run_backtest(
                factor_name='CROSS',
                code='000001.SZ',
                start_date='2024-01-01',
                end_date='2024-06-01',
                init_capital=100000,
                factor_params={'short_window': 5, 'long_window': 20},
                engine=engine_name
            )
            
            if result.get('success'):
                results[engine_name] = result
                print(f"  成功 - 总收益: {result['total_return']:.2%}")
            else:
                print(f"  失败 - {result.get('error')}")
        except Exception as e:
            print(f"  异常 - {e}")
    
    # 对比结果
    if len(results) > 1:
        print("\n引擎对比:")
        print(f"{'引擎':<15} {'总收益':<10} {'年化收益':<10} {'最大回撤':<10} {'夏普比率':<10}")
        print("-" * 60)
        for engine_name, result in results.items():
            print(f"{engine_name:<15} {result['total_return']:<10.2%} {result['annual_return']:<10.2%} "
                  f"{result['max_drawdown']:<10.2%} {result['sharpe_ratio']:<10.2f}")


def main():
    """主函数"""
    print("\n" + "=" * 60)
    print("统一回测引擎架构测试")
    print("=" * 60)
    
    try:
        # 测试各个组件
        engine = test_unified_engine()
        input_params = test_backtest_input()
        adapter = test_local_adapter()
        api = test_backtest_api()
        
        # 测试回测执行
        result = test_run_backtest()
        
        # 测试多引擎
        test_multi_engine()
        
        print("\n" + "=" * 60)
        print("测试完成!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
