# -*- coding: utf-8 -*-
"""
检查4月19日数据状态
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.api import StockAPI
from claw_quant.data_source import QMTDataSource

print("=" * 60)
print("检查4月19日数据状态")
print("=" * 60)

# 检查数据库
print("\n[1] 检查数据库...")
api = StockAPI()
df = api.get_daily('000001.SZ', date(2026, 4, 19), date(2026, 4, 19))
if not df.empty:
    print(f"  [OK] 数据库中已有4月19日数据")
    print(f"    {df[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  [INFO] 数据库中无4月19日数据")

# 检查QMT
print("\n[2] 检查QMT...")
qmt = QMTDataSource()
if qmt.is_connected():
    print("  [OK] QMT已连接")
    df_qmt = qmt.get_market_data_batch(['000001.SZ'], '1d', date(2026, 4, 19), date(2026, 4, 19))
    if not df_qmt.empty:
        print(f"  [OK] QMT返回数据:")
        print(f"    日期: {df_qmt['trade_date'].iloc[0]}")
        print(f"    收盘: {df_qmt['close'].iloc[0]}")
    else:
        print("  [INFO] QMT返回空数据（可能已下载过）")
else:
    print("  [FAIL] QMT未连接")

print("\n" + "=" * 60)
