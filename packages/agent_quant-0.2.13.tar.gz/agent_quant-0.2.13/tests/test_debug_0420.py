# -*- coding: utf-8 -*-
"""
调试4月20日数据更新问题
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.api import StockAPI
from claw_quant.data_source import QMTDataSource

print("=" * 60)
print("调试4月20日数据更新")
print("=" * 60)

# 1. 先检查QMT是否有4月20日的数据
print("\n[步骤1] 检查QMT是否有4月20日数据...")
try:
    qmt = QMTDataSource()
    if qmt.is_connected():
        print("  [OK] QMT已连接")
        
        # 尝试获取平安银行4月20日数据
        df_qmt = qmt.get_market_data_batch(
            ['000001.SZ'], '1d', date(2026, 4, 20), date(2026, 4, 20)
        )
        
        if df_qmt.empty:
            print("  [WARN] QMT中没有4月20日的数据！")
            print("  可能原因：4月20日不是交易日，或QMT未下载该日数据")
        else:
            print(f"  [OK] QMT中有数据：")
            print(f"    股票: {df_qmt['code'].iloc[0] if 'code' in df_qmt.columns else 'N/A'}")
            print(f"    日期: {df_qmt['trade_date'].iloc[0] if 'trade_date' in df_qmt.columns else 'N/A'}")
            print(f"    列名: {list(df_qmt.columns)}")
    else:
        print("  [FAIL] QMT未连接")
except Exception as e:
    print(f"  [ERROR] {e}")

# 2. 检查4月17日数据（已知有数据）
print("\n[步骤2] 对比检查4月17日数据...")
try:
    df_qmt_0417 = qmt.get_market_data_batch(
        ['000001.SZ'], '1d', date(2026, 4, 17), date(2026, 4, 17)
    )
    if df_qmt_0417.empty:
        print("  [WARN] QMT中也没有4月17日数据")
    else:
        print(f"  [OK] 4月17日有数据")
        print(f"    列名: {list(df_qmt_0417.columns)}")
        print(f"    数据:\n{df_qmt_0417}")
except Exception as e:
    print(f"  [ERROR] {e}")

# 3. 尝试更新4月20日数据并检查返回值
print("\n[步骤3] 尝试更新4月20日数据...")
api = StockAPI()

if api.ping():
    print("  [OK] 数据库连接成功")
    
    result = api.update_daily(
        codes=['000001.SZ'],
        target_date=date(2026, 4, 20)
    )
    
    print(f"\n  更新结果:")
    print(f"    success: {result['success']}")
    print(f"    saved_count: {result['saved_count']}")
    print(f"    message: {result['message']}")
    
    # 4. 查询数据库验证
    print("\n[步骤4] 查询数据库验证...")
    df_db = api.get_daily('000001.SZ', date(2026, 4, 20), date(2026, 4, 20))
    if df_db.empty:
        print("  [WARN] 数据库中查询不到4月20日数据")
    else:
        print(f"  [OK] 数据库中有数据:")
        print(f"    {df_db[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  [FAIL] 数据库连接失败")

print("\n" + "=" * 60)
