# -*- coding: utf-8 -*-
"""
调试4月20日数据问题 - 验证日期映射
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date
from claw_quant.api import StockAPI

print("=" * 60)
print("验证日期映射问题")
print("=" * 60)

api = StockAPI()

# 查询4月19日（可能是实际保存的日期）
print("\n[查询1] 查询4月19日数据...")
df = api.get_daily('000001.SZ', date(2026, 4, 19), date(2026, 4, 19))
if not df.empty:
    print(f"  [OK] 4月19日有数据:")
    print(f"    {df[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  [INFO] 4月19日无数据")

# 查询4月20日
print("\n[查询2] 查询4月20日数据...")
df = api.get_daily('000001.SZ', date(2026, 4, 20), date(2026, 4, 20))
if not df.empty:
    print(f"  [OK] 4月20日有数据:")
    print(f"    {df[['code', 'trade_date', 'close']].to_string()}")
else:
    print("  [INFO] 4月20日无数据")

# 查询最新日期
print("\n[查询3] 查询数据库最新日期...")
latest = api.get_latest_date()
print(f"  最新日期: {latest}")

# 检查4月17-20日的数据
print("\n[查询4] 检查4月17-20日所有数据...")
for d in [17, 18, 19, 20]:
    check_date = date(2026, 4, d)
    df = api.get_daily('000001.SZ', check_date, check_date)
    status = "有数据" if not df.empty else "无数据"
    print(f"  4月{d}日: {status}")

print("\n" + "=" * 60)
print("结论: 如果4月20日不是交易日，QMT会返回前一个交易日的数据")
print("      但trade_date字段保存的是实际交易日期（如4月19日）")
print("      所以查询4月20日会返回空")
print("=" * 60)
