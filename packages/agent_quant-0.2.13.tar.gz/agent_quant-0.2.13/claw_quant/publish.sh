#!/bin/bash

# Publish agent-quant to PyPI
# Usage: ./publish.sh

set -e

# Change to parent directory (project root)
cd "$(dirname "$0")/.."

echo "=========================================="
echo "Publish agent-quant to PyPI"
echo "=========================================="
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 not found!"
    exit 1
fi

# Check environment variable
if [ -z "$PYPI_TOKEN" ]; then
    echo "[ERROR] PYPI_TOKEN environment variable not set!"
    echo ""
    echo "Please set the environment variable first:"
    echo "  export PYPI_TOKEN='pypi-xxxxxxxx'"
    echo ""
    exit 1
fi

echo "[OK] PYPI_TOKEN found"
echo ""

# Auto increment version
echo "[0/4] Updating version..."
python3 claw_quant/update_version.py
echo "[OK] Version updated"
echo ""

# Clean old builds
echo "[1/4] Cleaning old builds..."
rm -rf dist build *.egg-info
echo "[OK] Cleaned"
echo ""

# Build package
echo "[2/4] Building package..."
python3 -m build
if [ $? -ne 0 ]; then
    echo "[ERROR] Build failed!"
    exit 1
fi
echo "[OK] Build successful"
echo ""

# Check built files
echo "[3/4] Checking built files..."
if [ ! -f dist/*.whl ]; then
    echo "[ERROR] No .whl file found in dist/"
    exit 1
fi
if [ ! -f dist/*.tar.gz ]; then
    echo "[ERROR] No .tar.gz file found in dist/"
    exit 1
fi
echo "[OK] Package files found"
echo ""

# Upload to PyPI
echo "[4/4] Uploading to PyPI..."
echo ""

export TWINE_USERNAME=__token__
export TWINE_PASSWORD=$PYPI_TOKEN

python3 -m twine upload dist/*

if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] Upload failed!"
    exit 1
fi

echo ""
echo "=========================================="
echo "[SUCCESS] Published to PyPI!"
echo "=========================================="
