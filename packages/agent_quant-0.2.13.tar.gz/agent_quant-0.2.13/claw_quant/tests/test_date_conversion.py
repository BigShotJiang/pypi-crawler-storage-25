#!/usr/bin/env python
"""测试日期转换"""
import pandas as pd
from datetime import date

# 模拟QMT返回的数据
test_data = [
    {'time': 20250401, 'open': 11.27, 'close': 11.30},
    {'time': 20250402, 'open': 11.25, 'close': 11.41},
    {'time': 20250403, 'open': 11.31, 'close': 11.39},
]

df = pd.DataFrame(test_data)
print("原始数据:")
print(df)
print(f"\ntime列类型: {df['time'].dtype}")

# 测试新的转换方法
print("\n" + "="*50)
print("测试新的转换方法:")
df['trade_date'] = df['time'].apply(
    lambda x: pd.to_datetime(str(int(x)), format='%Y%m%d').date() if pd.notna(x) else None
)
print(f"转换后的trade_date: {df['trade_date'].tolist()}")
print(f"trade_date类型: {df['trade_date'].dtype}")

# 验证日期是否正确
for i, row in df.iterrows():
    print(f"  {row['time']} -> {row['trade_date']} (类型: {type(row['trade_date'])})")

# 测试查询
print("\n" + "="*50)
print("测试日期查询:")
start = date(2025, 4, 1)
end = date(2025, 4, 30)
print(f"查询范围: {start} 到 {end}")

# 将trade_date转换为date对象进行比较
df['trade_date_obj'] = pd.to_datetime(df['trade_date']).dt.date
result = df[(df['trade_date_obj'] >= start) & (df['trade_date_obj'] <= end)]
print(f"查询结果: {len(result)} 条")
print(result)
