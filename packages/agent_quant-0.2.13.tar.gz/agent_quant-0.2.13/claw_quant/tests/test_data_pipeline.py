#!/usr/bin/env python
"""
数据管道测试脚本 - 独立测试下载和查询功能
不依赖GUI，直接测试底层函数
"""
import os
import sys
import pandas as pd
from datetime import date, datetime

# 添加项目路径
sys.path.insert(0, os.path.dirname(__file__))

from database import DuckDBManager

# 使用独立的数据库文件测试，避免与GUI冲突
TEST_DB_PATH = 'data/test_quant_system.db'


def test_database_basic():
    """测试数据库基本操作"""
    print("=" * 60)
    print("测试1: 数据库连接和表创建")
    print("=" * 60)

    # 删除旧测试数据库
    if os.path.exists(TEST_DB_PATH):
        os.remove(TEST_DB_PATH)
        print(f"删除旧测试数据库: {TEST_DB_PATH}")

    # 创建新数据库
    db = DuckDBManager(TEST_DB_PATH)
    print(f"✓ 数据库连接成功: {TEST_DB_PATH}")

    # 检查表是否存在
    tables = db.conn.execute("SHOW TABLES").fetchdf()
    print(f"✓ 创建的表: {tables['name'].tolist()}")

    db.close()
    print("✓ 数据库关闭成功\n")
    return True


def test_save_and_query_stock_info():
    """测试保存和查询股票基础信息"""
    print("=" * 60)
    print("测试2: 股票基础信息保存和查询")
    print("=" * 60)

    db = DuckDBManager(TEST_DB_PATH)

    # 创建测试数据
    test_stocks = pd.DataFrame({
        'code': ['000001.SZ', '000002.SZ', '600000.SH'],
        'name': ['平安银行', '万科A', '浦发银行'],
        'market': ['SZ', 'SZ', 'SH'],
        'industry': ['银行', '房地产', '银行'],
        'list_date': [date(1991, 4, 3), date(1991, 1, 29), date(1999, 11, 10)],
        'status': ['active', 'active', 'active']
    })

    # 保存
    db.save_stocks(test_stocks)
    print(f"✓ 保存 {len(test_stocks)} 只股票信息")

    # 查询
    result = db.get_all_stocks()
    print(f"✓ 查询返回 {len(result)} 只股票")
    print("\n股票列表:")
    print(result[['code', 'name', 'market']])

    db.close()
    print("✓ 测试通过\n")
    return True


def test_save_and_query_market_data():
    """测试保存和查询行情数据"""
    print("=" * 60)
    print("测试3: 行情数据保存和查询")
    print("=" * 60)

    db = DuckDBManager(TEST_DB_PATH)

    # 创建测试数据 - 模拟日线数据
    test_data = pd.DataFrame({
        'trade_date': [date(2025, 4, 1), date(2025, 4, 2), date(2025, 4, 3)],
        'code': ['000001.SZ', '000001.SZ', '000001.SZ'],
        'open': [10.5, 10.6, 10.4],
        'high': [10.8, 10.7, 10.5],
        'low': [10.3, 10.5, 10.2],
        'close': [10.6, 10.4, 10.3],
        'volume': [1000000, 1200000, 900000],
        'amount': [10600000, 12480000, 9270000],
        'turnover_rate': [0.5, 0.6, 0.45],
        'pe_ratio': [5.2, 5.1, 5.0],
        'pb_ratio': [0.8, 0.79, 0.78],
        'market_cap': [1000000000, 980000000, 970000000]
    })

    print(f"测试数据:\n{test_data}")
    print(f"\ntrade_date 类型: {test_data['trade_date'].dtype}")

    # 保存
    db.save_market_data_daily(test_data)
    print(f"✓ 保存 {len(test_data)} 条行情数据")

    # 查询
    result = db.get_market_data_daily('000001.SZ', date(2025, 4, 1), date(2025, 4, 30))
    print(f"✓ 查询返回 {len(result)} 条数据")

    if not result.empty:
        print("\n查询结果:")
        print(result)
        print(f"\ntrade_date 类型: {result['trade_date'].dtype}")
    else:
        print("✗ 查询返回空!")

        # 调试: 检查表中所有数据
        print("\n调试: 检查表中的所有数据")
        all_data = db.conn.execute("SELECT * FROM market_data_daily").fetchdf()
        print(f"表中共有 {len(all_data)} 条数据")
        if not all_data.empty:
            print(all_data)
            print(f"\ntrade_date 类型: {all_data['trade_date'].dtype}")
            print(f"trade_date 示例值: {all_data['trade_date'].iloc[0]} (类型: {type(all_data['trade_date'].iloc[0])})")

    db.close()
    print()
    return len(result) == 3


def test_date_query():
    """测试日期范围查询"""
    print("=" * 60)
    print("测试4: 日期范围查询")
    print("=" * 60)

    db = DuckDBManager(TEST_DB_PATH)

    # 测试不同的日期范围
    test_cases = [
        (date(2025, 4, 1), date(2025, 4, 3)),
        (date(2025, 4, 1), date(2025, 4, 2)),
        (date(2025, 3, 1), date(2025, 5, 1)),
    ]

    for start, end in test_cases:
        result = db.get_market_data_daily('000001.SZ', start, end)
        print(f"查询 {start} 到 {end}: 返回 {len(result)} 条")

    db.close()
    print("✓ 测试通过\n")
    return True


def test_download_function():
    """测试从QMT下载数据功能"""
    print("=" * 60)
    print("测试5: 从QMT下载数据 (需要xtquant)")
    print("=" * 60)

    try:
        from data_updater import MarketDataUpdater

        db = DuckDBManager(TEST_DB_PATH)
        updater = MarketDataUpdater(db)
        print("✓ 连接到QMT")

        # 下载一只股票的数据
        code = '000001.SZ'
        start_date = date(2025, 4, 1)
        end_date = date(2025, 4, 14)

        print(f"下载 {code} 从 {start_date} 到 {end_date}")

        # 下载到QMT缓存
        updater.download_history_data(code, '1d', start_date, end_date)
        print("✓ 下载到QMT缓存")

        # 获取数据
        df = updater.get_market_data(code, '1d', start_date, end_date)
        print(f"✓ 获取到 {len(df)} 条数据")

        if not df.empty:
            print("\n数据预览:")
            print(df.head())
            print(f"\n列名: {df.columns.tolist()}")
            print(f"time列类型: {df['time'].dtype if 'time' in df.columns else 'N/A'}")

            # 保存到数据库
            # 列名转换
            if 'time' in df.columns:
                try:
                    df['trade_date'] = pd.to_datetime(df['time'], format='%Y%m%d').dt.date
                except:
                    df['trade_date'] = pd.to_datetime(df['time']).dt.date

            df['code'] = code

            # 确保所有列存在
            for col in ['turnover_rate', 'pe_ratio', 'pb_ratio', 'market_cap']:
                if col not in df.columns:
                    df[col] = None

            db.save_market_data_daily(df)
            print(f"✓ 保存到数据库")

            # 验证查询
            result = db.get_market_data_daily(code, start_date, end_date)
            print(f"✓ 查询验证: 返回 {len(result)} 条数据")

        db.close()
        print("✓ 测试通过\n")
        return True

    except ImportError as e:
        print(f"✗ 未安装xtquant: {e}")
        print("  跳过此测试\n")
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}\n")
        return False


def cleanup():
    """清理测试数据库"""
    if os.path.exists(TEST_DB_PATH):
        os.remove(TEST_DB_PATH)
        print(f"✓ 清理测试数据库: {TEST_DB_PATH}")


def main():
    """主函数"""
    print("\n" + "=" * 60)
    print("数据管道测试")
    print("=" * 60 + "\n")

    results = []

    try:
        results.append(("数据库基本操作", test_database_basic()))
        results.append(("股票基础信息", test_save_and_query_stock_info()))
        results.append(("行情数据保存查询", test_save_and_query_market_data()))
        results.append(("日期范围查询", test_date_query()))
        results.append(("QMT下载", test_download_function()))

    finally:
        cleanup()

    # 打印结果
    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)
    for name, passed in results:
        status = "✓ 通过" if passed else "✗ 失败"
        print(f"{name}: {status}")

    all_passed = all(r[1] for r in results)
    print("\n" + ("所有测试通过!" if all_passed else "部分测试失败!"))


if __name__ == '__main__':
    main()
