"""
DataAPI 单元测试
"""
import unittest
import sys
import os
import tempfile
import shutil
from datetime import date, datetime, timedelta
import pandas as pd
import numpy as np

# 添加项目路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from api.data_implement import DataAPIImpl, QMTDataSource, DuckDBDataSource
from database.db_manager import DuckDBManager


class MockQMTDataSource:
    """Mock QMT数据源，用于测试"""

    def __init__(self):
        self._connected = True

    def is_connected(self) -> bool:
        return self._connected

    def get_stock_list(self, market: str = 'all') -> list:
        """模拟股票列表"""
        return ['000001.SZ', '000002.SZ', '600000.SH', '600001.SH']

    def get_market_data(self, code: str, period: str = '1d',
                        start_date=None, end_date=None) -> pd.DataFrame:
        """模拟行情数据"""
        dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='B')
        data = {
            'time': dates,
            'open': np.random.uniform(10, 12, len(dates)),
            'high': np.random.uniform(11, 13, len(dates)),
            'low': np.random.uniform(9, 11, len(dates)),
            'close': np.random.uniform(10, 12, len(dates)),
            'volume': np.random.randint(1000000, 10000000, len(dates)),
            'amount': np.random.uniform(10000000, 100000000, len(dates)),
            'turnoverrate': np.random.uniform(0.01, 0.05, len(dates)),
            'pe': np.random.uniform(10, 30, len(dates)),
            'pb': np.random.uniform(1, 5, len(dates)),
            'totalcapital': np.random.uniform(1000000000, 10000000000, len(dates)),
        }
        df = pd.DataFrame(data)
        df['code'] = code
        return df

    def get_realtime_quotes(self, codes: list) -> pd.DataFrame:
        """模拟实时行情"""
        data = []
        for code in codes:
            data.append({
                'code': code,
                'price': 10.5,
                'open': 10.2,
                'high': 10.8,
                'low': 10.1,
                'pre_close': 10.0,
                'volume': 5000000,
                'amount': 50000000,
                'bid1_price': 10.4,
                'bid1_volume': 1000,
                'ask1_price': 10.6,
                'ask1_volume': 1000,
            })
        return pd.DataFrame(data)

    def get_market_data_batch(self, codes: list, period: str = '1d',
                              start_date=None, end_date=None) -> pd.DataFrame:
        """模拟批量获取行情数据"""
        dfs = []
        target = start_date or date.today()
        for code in codes:
            data = {
                'time': [target],
                'open': [np.random.uniform(10, 12)],
                'high': [np.random.uniform(11, 13)],
                'low': [np.random.uniform(9, 11)],
                'close': [np.random.uniform(10, 12)],
                'volume': [np.random.randint(1000000, 10000000)],
                'amount': [np.random.uniform(10000000, 100000000)],
                'turnoverrate': [np.random.uniform(0.01, 0.05)],
                'pe': [np.random.uniform(10, 30)],
                'pb': [np.random.uniform(1, 5)],
                'totalcapital': [np.random.uniform(1e9, 1e10)],
            }
            df = pd.DataFrame(data)
            df['code'] = code
            dfs.append(df)
        return pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()


class TestDataAPIImpl(unittest.TestCase):
    """测试DataAPIImpl类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.temp_dir = tempfile.mkdtemp()
        cls.db_path = os.path.join(cls.temp_dir, 'test.db')

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        shutil.rmtree(cls.temp_dir, ignore_errors=True)

    def setUp(self):
        """每个测试用例前执行"""
        self.config = {
            'data_source': 'duckdb',
            'db_path': self.db_path,
            'db_mode': 'direct',
            'qmt_path': None
        }
        # 创建新的数据库连接
        self.db = DuckDBManager(self.db_path)
        self.api = DataAPIImpl(self.config)
        # 替换QMT为Mock
        self.api._qmt = MockQMTDataSource()

    def tearDown(self):
        """每个测试用例后执行"""
        if self.db:
            self.db.close()
        # 删除测试数据库文件
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_is_connected(self):
        """测试连接状态"""
        self.assertTrue(self.api.is_connected())

    def test_get_daily_single_stock(self):
        """测试获取单只股票日线数据"""
        df = self.api.get_daily(
            '000001.SZ',
            start='20240101',
            end='20240131'
        )

        self.assertIsInstance(df, pd.DataFrame)
        self.assertFalse(df.empty)
        self.assertIn('code', df.columns)
        self.assertIn('trade_date', df.columns)
        self.assertIn('open', df.columns)
        self.assertIn('close', df.columns)
        self.assertEqual(df['code'].iloc[0], '000001.SZ')

    def test_get_daily_multiple_stocks(self):
        """测试获取多只股票日线数据"""
        codes = ['000001.SZ', '000002.SZ']
        df = self.api.get_daily(
            codes,
            start='20240101',
            end='20240131'
        )

        self.assertIsInstance(df, pd.DataFrame)
        self.assertFalse(df.empty)
        self.assertIn('code', df.columns)
        # 应该包含多只股票的数据
        unique_codes = df['code'].unique()
        self.assertGreaterEqual(len(unique_codes), 1)

    def test_get_daily_with_fields(self):
        """测试获取指定字段的日线数据"""
        df = self.api.get_daily(
            '000001.SZ',
            start='20240101',
            end='20240131',
            fields=['open', 'close', 'volume']
        )

        self.assertIsInstance(df, pd.DataFrame)
        # 检查是否包含指定字段
        self.assertIn('open', df.columns)
        self.assertIn('close', df.columns)
        self.assertIn('volume', df.columns)

    def test_get_daily_date_formats(self):
        """测试不同日期格式"""
        # 字符串日期
        df1 = self.api.get_daily('000001.SZ', start='20240101', end='20240131')
        self.assertIsInstance(df1, pd.DataFrame)

        # date对象日期
        start_date = date(2024, 1, 1)
        end_date = date(2024, 1, 31)
        df2 = self.api.get_daily('000001.SZ', start=start_date, end=end_date)
        self.assertIsInstance(df2, pd.DataFrame)

    def test_get_realtime(self):
        """测试获取实时行情"""
        codes = ['000001.SZ', '000002.SZ']
        df = self.api.get_realtime(codes)

        self.assertIsInstance(df, pd.DataFrame)
        self.assertFalse(df.empty)
        self.assertIn('code', df.columns)
        self.assertIn('price', df.columns)

    def test_get_stock_list(self):
        """测试获取股票列表"""
        df = self.api.get_stock_list()

        self.assertIsInstance(df, pd.DataFrame)

    def test_get_stock_info(self):
        """测试获取股票信息"""
        info = self.api.get_stock_info('000001.SZ')

        self.assertIsInstance(info, dict)

    def test_get_index_components(self):
        """测试获取指数成分股"""
        components = self.api.get_index_components('000001.SH')

        self.assertIsInstance(components, list)

    def test_download(self):
        """测试数据下载功能"""
        result = self.api.download(
            ['000001.SZ', '000002.SZ'],
            period='1d',
            start='20240101',
            end='20240131'
        )

        self.assertIsInstance(result, dict)
        self.assertIn('total', result)
        self.assertIn('success', result)
        self.assertIn('failed', result)

    def test_standardize_columns(self):
        """测试数据标准化"""
        # 创建测试数据
        df = pd.DataFrame({
            'time': ['2024-01-01', '2024-01-02'],
            'open': [10.0, 11.0],
            'high': [11.0, 12.0],
            'low': [9.0, 10.0],
            'close': [10.5, 11.5],
            'volume': [1000000, 2000000],
        })

        standardized = self.api._standardize_columns(df)

        self.assertIn('trade_date', standardized.columns)
        self.assertIn('open', standardized.columns)

    def test_empty_result(self):
        """测试空结果处理"""
        # 使用不存在的股票代码
        df = self.api.get_daily('999999.XY', start='20240101', end='20240131')

        self.assertIsInstance(df, pd.DataFrame)

    def test_update_daily(self):
        """测试日更新功能"""
        # 先插入一些股票到数据库
        stocks_df = pd.DataFrame({
            'code': ['000001.SZ', '000002.SZ', '600000.SH'],
            'name': ['平安银行', '万科A', '浦发银行'],
            'market': ['SZ', 'SZ', 'SH'],
            'industry': [None, None, None],
            'list_date': [None, None, None],
            'status': ['active', 'active', 'active'],
        })
        self.db.save_stocks(stocks_df)

        # 执行日更新
        result = self.api.update_daily(
            target_date='20240115',
            batch_size=2  # 小批次测试分批逻辑
        )

        self.assertIsInstance(result, dict)
        self.assertIn('total', result)
        self.assertIn('success', result)
        self.assertIn('records', result)
        self.assertEqual(result['total'], 3)
        self.assertEqual(result['success'], 3)
        self.assertEqual(result['records'], 3)  # 每只股票1条
        self.assertEqual(result['target_date'], '2024-01-15')

    def test_update_daily_with_progress(self):
        """测试日更新进度回调"""
        stocks_df = pd.DataFrame({
            'code': ['000001.SZ', '000002.SZ'],
            'name': ['平安银行', '万科A'],
            'market': ['SZ', 'SZ'],
            'industry': [None, None],
            'list_date': [None, None],
            'status': ['active', 'active'],
        })
        self.db.save_stocks(stocks_df)

        progress_calls = []
        def on_progress(batch_num, total_batches, success, records):
            progress_calls.append((batch_num, total_batches, success, records))

        result = self.api.update_daily(
            target_date='20240115',
            batch_size=1,  # 每批1只，这样有2次回调
            progress_callback=on_progress
        )

        self.assertEqual(result['success'], 2)
        self.assertEqual(len(progress_calls), 2)  # 2批 = 2次回调
        # 最后一次回调应该显示全部完成
        self.assertEqual(progress_calls[-1][0], 2)  # batch_num
        self.assertEqual(progress_calls[-1][1], 2)  # total_batches


class TestDuckDBDataSource(unittest.TestCase):
    """测试DuckDBDataSource类"""

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp()
        cls.db_path = os.path.join(cls.temp_dir, 'test_duckdb.db')

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.temp_dir, ignore_errors=True)

    def setUp(self):
        self.db = DuckDBManager(self.db_path)
        self.source = DuckDBDataSource(self.db)

        # 插入测试数据
        test_data = pd.DataFrame({
            'trade_date': [date(2024, 1, 1), date(2024, 1, 2)],
            'code': ['000001.SZ', '000001.SZ'],
            'open': [10.0, 11.0],
            'high': [11.0, 12.0],
            'low': [9.0, 10.0],
            'close': [10.5, 11.5],
            'volume': [1000000, 2000000],
            'amount': [10000000, 20000000],
            'turnover_rate': [0.02, 0.03],
            'pe_ratio': [15.0, 16.0],
            'pb_ratio': [2.0, 2.1],
            'market_cap': [5000000000.0, 5100000000.0],
        })
        self.db.save_market_data_daily(test_data)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_get_daily(self):
        """测试从DuckDB获取日线数据"""
        df = self.source.get_daily(
            '000001.SZ',
            start=date(2024, 1, 1),
            end=date(2024, 1, 31)
        )

        self.assertIsInstance(df, pd.DataFrame)
        self.assertFalse(df.empty)

    def test_get_stock_list(self):
        """测试获取股票列表"""
        df = self.source.get_stock_list()

        self.assertIsInstance(df, pd.DataFrame)


class TestQMTDataSource(unittest.TestCase):
    """测试QMTDataSource类"""

    def test_detect_qmt_path(self):
        """测试QMT路径检测"""
        # 这个测试在没有QMT安装的环境下会失败，需要跳过
        try:
            source = QMTDataSource()
            # 如果QMT连接失败，is_connected应该返回False
            if not source.is_connected():
                self.skipTest("QMT连接失败，跳过测试")
            self.assertTrue(source.is_connected())
        except FileNotFoundError:
            self.skipTest("未安装QMT，跳过测试")
        except ImportError:
            self.skipTest("未安装xtquant模块，跳过测试")


class TestDataIntegration(unittest.TestCase):
    """集成测试"""

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp()
        cls.db_path = os.path.join(cls.temp_dir, 'integration_test.db')

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.temp_dir, ignore_errors=True)

    def test_full_workflow(self):
        """测试完整工作流程"""
        config = {
            'data_source': 'duckdb',
            'db_path': self.db_path,
            'db_mode': 'direct',
            'qmt_path': None
        }

        # 创建API实例
        api = DataAPIImpl(config)
        api._qmt = MockQMTDataSource()

        # 1. 获取股票列表
        stocks = api.get_stock_list()
        self.assertIsInstance(stocks, pd.DataFrame)

        # 2. 下载数据
        result = api.download(['000001.SZ'], start='20240101', end='20240131')
        self.assertIn('success', result)

        # 3. 查询数据
        df = api.get_daily('000001.SZ', start='20240101', end='20240131')
        self.assertIsInstance(df, pd.DataFrame)

        # 4. 获取实时行情
        rt = api.get_realtime(['000001.SZ'])
        self.assertIsInstance(rt, pd.DataFrame)

        # 5. 日更新
        # 先插入股票列表
        stocks_df = pd.DataFrame({
            'code': ['000001.SZ'],
            'name': ['平安银行'],
            'market': ['SZ'],
            'industry': [None],
            'list_date': [None],
            'status': ['active'],
        })
        api._db.save_stocks(stocks_df)
        update_result = api.update_daily(target_date='20240115')
        self.assertIn('success', update_result)
        self.assertEqual(update_result['success'], 1)


def run_tests():
    """运行所有测试"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # 添加测试类
    suite.addTests(loader.loadTestsFromTestCase(TestDataAPIImpl))
    suite.addTests(loader.loadTestsFromTestCase(TestDuckDBDataSource))
    suite.addTests(loader.loadTestsFromTestCase(TestQMTDataSource))
    suite.addTests(loader.loadTestsFromTestCase(TestDataIntegration))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)
