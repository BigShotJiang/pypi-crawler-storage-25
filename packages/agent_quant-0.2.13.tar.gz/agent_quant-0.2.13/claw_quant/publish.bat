@echo off
chcp 65001 >nul
title Publish to PyPI
echo ==========================================
echo Publish agent-quant to PyPI
echo ==========================================
echo.

REM Save original directory
set "ORIGINAL_DIR=%CD%"

REM Change to parent directory (project root)
cd /d "%~dp0\.."

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    pause
    exit /b 1
)

REM Check environment variable
if "%PYPI_TOKEN%"=="" (
    echo [ERROR] PYPI_TOKEN environment variable not set!
    echo.
    echo Please set the environment variable first:
    echo   set PYPI_TOKEN=pypi-xxxxxxxx
    echo.
    pause
    exit /b 1
)

echo [OK] PYPI_TOKEN found
echo.

REM Auto increment version
echo [0/4] Updating version...
python claw_quant\update_version.py
if errorlevel 1 (
    echo [ERROR] Version update failed!
    pause
    exit /b 1
)
echo [OK] Version updated
echo.

REM Clean old builds
echo [1/4] Cleaning old builds...
if exist "dist" rmdir /s /q dist
if exist "build" rmdir /s /q build
if exist "*.egg-info" rmdir /s /q *.egg-info
echo [OK] Cleaned
echo.

REM Build package
echo [2/4] Building package...
python -m build
if errorlevel 1 (
    echo [ERROR] Build failed!
    pause
    exit /b 1
)
echo [OK] Build successful
echo.

REM Check built files
echo [3/4] Checking built files...
if not exist "dist\*.whl" (
    echo [ERROR] No .whl file found in dist/
    pause
    exit /b 1
)
if not exist "dist\*.tar.gz" (
    echo [ERROR] No .tar.gz file found in dist/
    pause
    exit /b 1
)
echo [OK] Package files found
echo.

REM Upload to PyPI
echo [4/4] Uploading to PyPI...
echo.

set TWINE_USERNAME=__token__
set TWINE_PASSWORD=%PYPI_TOKEN%

python -m twine upload dist/*

if errorlevel 1 (
    echo.
    echo [ERROR] Upload failed!
    pause
    exit /b 1
)

echo.
echo ==========================================
echo [SUCCESS] Published to PyPI!
echo ==========================================
echo.

REM Restore original directory
cd /d "%ORIGINAL_DIR%"

pause
