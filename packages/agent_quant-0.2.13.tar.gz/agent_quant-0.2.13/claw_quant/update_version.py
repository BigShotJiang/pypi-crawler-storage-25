#!/usr/bin/env python3
"""Auto increment version in pyproject.toml"""

import re
import sys

# Read pyproject.toml
with open('pyproject.toml', 'r', encoding='utf-8') as f:
    content = f.read()

# Find and increment version
version_match = re.search(r'version = "(\d+)\.(\d+)\.(\d+)"', content)
if version_match:
    major, minor, patch = map(int, version_match.groups())
    new_version = f'{major}.{minor}.{patch + 1}'
    content = content.replace(
        f'version = "{major}.{minor}.{patch}"',
        f'version = "{new_version}"'
    )
    with open('pyproject.toml', 'w', encoding='utf-8') as f:
        f.write(content)
    print(f'Version updated: {major}.{minor}.{patch} -> {new_version}')
else:
    print('Version not found in pyproject.toml')
    sys.exit(1)
