"""
StockClaw 异常类定义
"""


class StockClawError(Exception):
    """基础异常类"""
    
    def __init__(self, message: str, code: str = None, details: dict = None):
        super().__init__(message)
        self.message = message
        self.code = code or 'UNKNOWN_ERROR'
        self.details = details or {}
    
    def __str__(self):
        if self.details:
            return f"[{self.code}] {self.message} - Details: {self.details}"
        return f"[{self.code}] {self.message}"


class PluginError(StockClawError):
    """插件相关异常"""
    pass


class DataSourceError(StockClawError):
    """数据源相关异常"""
    pass


class TradeError(StockClawError):
    """交易相关异常"""
    pass


class BacktestError(StockClawError):
    """回测相关异常"""
    pass


class ConfigError(StockClawError):
    """配置相关异常"""
    pass


class ValidationError(StockClawError):
    """数据验证异常"""
    pass
