"""
依赖注入容器

实现服务定位器模式，管理所有组件的生命周期和依赖关系

使用示例:
    >>> from api.core import container
    >>> 
    >>> # 注册服务
    >>> container.register('database', DuckDBManager, singleton=True)
    >>> 
    >>> # 获取服务
    >>> db = container.resolve('database')
    >>> 
    >>> # 注册实例
    >>> container.register_instance('config', config)
"""
from typing import Dict, Type, Any, Optional, Callable, List
import inspect
import logging

logger = logging.getLogger(__name__)


class ServiceDefinition:
    """服务定义"""
    
    def __init__(
        self,
        name: str,
        factory: Callable,
        singleton: bool = False,
        args: tuple = None,
        kwargs: dict = None
    ):
        self.name = name
        self.factory = factory
        self.singleton = singleton
        self.args = args or ()
        self.kwargs = kwargs or {}
        self.instance = None


class Container:
    """
    依赖注入容器
    
    支持:
    - 服务注册和解析
    - 单例和瞬态生命周期
    - 构造函数自动注入
    - 别名支持
    """
    
    def __init__(self):
        self._services: Dict[str, ServiceDefinition] = {}
        self._aliases: Dict[str, str] = {}
        self._instances: Dict[str, Any] = {}
        self._providers: Dict[str, Callable] = {}
    
    def register(
        self,
        name: str,
        factory: Callable,
        singleton: bool = False,
        *args,
        **kwargs
    ) -> 'Container':
        """
        注册服务
        
        Args:
            name: 服务名称
            factory: 工厂函数或类
            singleton: 是否为单例
            *args, **kwargs: 构造参数
        
        Returns:
            self
        """
        self._services[name] = ServiceDefinition(
            name=name,
            factory=factory,
            singleton=singleton,
            args=args,
            kwargs=kwargs
        )
        logger.debug(f"Registered service: {name}")
        return self
    
    def register_instance(self, name: str, instance: Any) -> 'Container':
        """
        注册实例
        
        Args:
            name: 服务名称
            instance: 实例对象
        """
        self._instances[name] = instance
        logger.debug(f"Registered instance: {name}")
        return self
    
    def register_provider(self, name: str, provider: Callable) -> 'Container':
        """
        注册提供者
        
        Args:
            name: 服务名称
            provider: 提供者函数，接收容器参数返回实例
        """
        self._providers[name] = provider
        return self
    
    def alias(self, alias: str, name: str) -> 'Container':
        """
        注册别名
        
        Args:
            alias: 别名
            name: 实际服务名
        """
        self._aliases[alias] = name
        return self
    
    def resolve(self, name: str) -> Any:
        """
        解析服务
        
        Args:
            name: 服务名称或别名
        
        Returns:
            服务实例
        """
        # 解析别名
        if name in self._aliases:
            name = self._aliases[name]
        
        # 检查已注册实例
        if name in self._instances:
            return self._instances[name]
        
        # 检查服务定义
        if name not in self._services:
            # 检查提供者
            if name in self._providers:
                return self._providers[name](self)
            raise KeyError(f"Service not found: {name}")
        
        definition = self._services[name]
        
        # 单例模式
        if definition.singleton:
            if definition.instance is None:
                definition.instance = self._create_instance(definition)
            return definition.instance
        
        # 瞬态模式
        return self._create_instance(definition)
    
    def _create_instance(self, definition: ServiceDefinition) -> Any:
        """创建实例"""
        factory = definition.factory
        args = definition.args
        kwargs = definition.kwargs
        
        # 如果工厂是类，尝试自动注入依赖
        if inspect.isclass(factory):
            kwargs = self._autowire(factory, kwargs)
        
        return factory(*args, **kwargs)
    
    def _autowire(self, cls: Type, kwargs: Dict) -> Dict:
        """自动注入依赖"""
        signature = inspect.signature(cls.__init__)
        
        for param_name, param in signature.parameters.items():
            if param_name in kwargs or param_name == 'self':
                continue
            
            # 尝试从类型注解解析
            if param.annotation != inspect.Parameter.empty:
                type_name = getattr(param.annotation, '__name__', str(param.annotation))
                if type_name in self._services or type_name in self._aliases:
                    try:
                        kwargs[param_name] = self.resolve(type_name)
                    except KeyError:
                        pass
            
            # 尝试按名称解析
            if param_name not in kwargs and param_name in self._services:
                kwargs[param_name] = self.resolve(param_name)
        
        return kwargs
    
    def has(self, name: str) -> bool:
        """检查服务是否存在"""
        return (
            name in self._services or
            name in self._instances or
            name in self._providers or
            name in self._aliases
        )
    
    def remove(self, name: str) -> bool:
        """移除服务"""
        if name in self._services:
            del self._services[name]
            return True
        if name in self._instances:
            del self._instances[name]
            return True
        return False
    
    def clear(self):
        """清空所有服务"""
        self._services.clear()
        self._aliases.clear()
        self._instances.clear()
        self._providers.clear()
    
    def list_services(self) -> List[str]:
        """列出所有服务名称"""
        services = set(self._services.keys())
        services.update(self._instances.keys())
        services.update(self._providers.keys())
        return sorted(services)
    
    def create_scope(self) -> 'ContainerScope':
        """创建作用域"""
        return ContainerScope(self)


class ContainerScope:
    """容器作用域 - 用于管理临时生命周期"""
    
    def __init__(self, parent: Container):
        self._parent = parent
        self._instances: Dict[str, Any] = {}
    
    def resolve(self, name: str) -> Any:
        """解析服务"""
        if name in self._instances:
            return self._instances[name]
        return self._parent.resolve(name)
    
    def register_instance(self, name: str, instance: Any):
        """在当前作用域注册实例"""
        self._instances[name] = instance
    
    def dispose(self):
        """释放作用域资源"""
        self._instances.clear()


# 全局容器实例
container = Container()
