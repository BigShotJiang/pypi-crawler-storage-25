"""
上下文模块 - 提供运行时上下文管理

上下文在组件之间共享状态和数据
"""
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
import threading


@dataclass
class Context:
    """
    运行时上下文
    
    用于在策略执行、回测、交易过程中共享状态
    
    Attributes:
        data: 上下文数据字典
        metadata: 元数据
        created_at: 创建时间
    """
    
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取值"""
        return self.data.get(key, default)
    
    def set(self, key: str, value: Any):
        """设置值"""
        self.data[key] = value
    
    def has(self, key: str) -> bool:
        """检查键是否存在"""
        return key in self.data
    
    def remove(self, key: str) -> bool:
        """删除键"""
        if key in self.data:
            del self.data[key]
            return True
        return False
    
    def clear(self):
        """清空数据"""
        self.data.clear()
    
    def merge(self, other: 'Context'):
        """合并另一个上下文"""
        self.data.update(other.data)
        self.metadata.update(other.metadata)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'data': self.data.copy(),
            'metadata': self.metadata.copy(),
            'created_at': self.created_at.isoformat()
        }


class ContextManager:
    """
    上下文管理器
    
    管理线程本地上下文
    """
    
    _local = threading.local()
    
    @classmethod
    def get_current(cls) -> Optional[Context]:
        """获取当前上下文"""
        return getattr(cls._local, 'context', None)
    
    @classmethod
    def set_current(cls, context: Context):
        """设置当前上下文"""
        cls._local.context = context
    
    @classmethod
    def clear_current(cls):
        """清除当前上下文"""
        if hasattr(cls._local, 'context'):
            delattr(cls._local, 'context')
    
    @classmethod
    def create_scope(cls, **kwargs) -> 'ContextScope':
        """创建上下文作用域"""
        return ContextScope(**kwargs)


class ContextScope:
    """
    上下文作用域 - 上下文管理器
    
    使用示例:
        >>> with ContextScope() as ctx:
        ...     ctx.set('key', 'value')
        ...     # do something
    """
    
    def __init__(self, parent: Optional[Context] = None, **kwargs):
        self.parent = parent
        self.context = Context(data=kwargs)
        self.previous_context: Optional[Context] = None
    
    def __enter__(self) -> Context:
        self.previous_context = ContextManager.get_current()
        ContextManager.set_current(self.context)
        return self.context
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.previous_context:
            ContextManager.set_current(self.previous_context)
        else:
            ContextManager.clear_current()
