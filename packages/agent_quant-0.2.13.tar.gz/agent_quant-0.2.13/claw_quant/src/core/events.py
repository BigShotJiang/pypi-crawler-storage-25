"""
事件总线模块 - 支持事件驱动架构

使用示例:
    >>> from api.core import EventBus, Event
    >>> 
    >>> # 订阅事件
    >>> @EventBus.on('trade.filled')
    ... def on_trade_filled(event):
    ...     print(f"Trade filled: {event.data}")
    >>> 
    >>> # 发布事件
    >>> EventBus.emit(Event('trade.filled', {'code': '000001.SZ', 'volume': 100}))
"""
from typing import Dict, List, Callable, Any, Optional
from dataclasses import dataclass
from collections import defaultdict
import threading
import logging

logger = logging.getLogger(__name__)


@dataclass
class Event:
    """事件对象"""
    name: str
    data: Any = None
    source: str = ''
    timestamp: Optional[float] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            import time
            self.timestamp = time.time()


class EventBus:
    """
    事件总线
    
    支持同步和异步事件处理
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._async_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._middleware: List[Callable] = []
        self._initialized = True
        self._executor = None
    
    @classmethod
    def on(cls, event_name: str, async_mode: bool = False):
        """
        事件订阅装饰器
        
        Args:
            event_name: 事件名称
            async_mode: 是否异步处理
        """
        def decorator(handler: Callable):
            instance = cls()
            if async_mode:
                instance._async_handlers[event_name].append(handler)
            else:
                instance._handlers[event_name].append(handler)
            return handler
        return decorator
    
    @classmethod
    def emit(cls, event: Event, async_mode: bool = False):
        """
        发布事件
        
        Args:
            event: 事件对象
            async_mode: 是否异步处理
        """
        instance = cls()
        
        # 执行中间件
        for middleware in instance._middleware:
            try:
                event = middleware(event)
                if event is None:
                    return  # 中间件阻止事件传播
            except Exception as e:
                logger.error(f"Event middleware error: {e}")
        
        handlers = instance._async_handlers.get(event.name, []) if async_mode else instance._handlers.get(event.name, [])
        
        for handler in handlers:
            try:
                if async_mode:
                    instance._execute_async(handler, event)
                else:
                    handler(event)
            except Exception as e:
                logger.error(f"Event handler error for {event.name}: {e}")
    
    @classmethod
    def off(cls, event_name: str, handler: Callable = None):
        """
        取消订阅
        
        Args:
            event_name: 事件名称
            handler: 处理器，None表示取消所有
        """
        instance = cls()
        
        if handler is None:
            instance._handlers.pop(event_name, None)
            instance._async_handlers.pop(event_name, None)
        else:
            if event_name in instance._handlers:
                instance._handlers[event_name] = [
                    h for h in instance._handlers[event_name] if h != handler
                ]
            if event_name in instance._async_handlers:
                instance._async_handlers[event_name] = [
                    h for h in instance._async_handlers[event_name] if h != handler
                ]
    
    @classmethod
    def use(cls, middleware: Callable):
        """
        注册中间件
        
        Args:
            middleware: 中间件函数，接收并返回Event对象，返回None则阻止事件
        """
        instance = cls()
        instance._middleware.append(middleware)
    
    def _execute_async(self, handler: Callable, event: Event):
        """异步执行处理器"""
        if self._executor is None:
            from concurrent.futures import ThreadPoolExecutor
            self._executor = ThreadPoolExecutor(max_workers=4)
        
        self._executor.submit(handler, event)
    
    @classmethod
    def shutdown(cls):
        """关闭事件总线"""
        instance = cls()
        if instance._executor:
            instance._executor.shutdown(wait=True)


# 预定义事件类型
class Events:
    """标准事件类型"""
    
    # 数据事件
    DATA_UPDATED = 'data.updated'
    DATA_DOWNLOADED = 'data.downloaded'
    
    # 交易事件
    ORDER_SUBMITTED = 'order.submitted'
    ORDER_FILLED = 'order.filled'
    ORDER_CANCELLED = 'order.cancelled'
    ORDER_REJECTED = 'order.rejected'
    TRADE_FILLED = 'trade.filled'
    POSITION_UPDATED = 'position.updated'
    ACCOUNT_UPDATED = 'account.updated'
    
    # 回测事件
    BACKTEST_STARTED = 'backtest.started'
    BACKTEST_PROGRESS = 'backtest.progress'
    BACKTEST_FINISHED = 'backtest.finished'
    BACKTEST_ERROR = 'backtest.error'
    
    # 策略事件
    STRATEGY_STARTED = 'strategy.started'
    STRATEGY_STOPPED = 'strategy.stopped'
    STRATEGY_SIGNAL = 'strategy.signal'
    
    # 系统事件
    SYSTEM_READY = 'system.ready'
    SYSTEM_ERROR = 'system.error'
    PLUGIN_LOADED = 'plugin.loaded'
    PLUGIN_UNLOADED = 'plugin.unloaded'
