"""
插件系统模块 - 支持动态加载扩展

使用示例:
    >>> from api.core import Plugin, PluginManager
    >>> 
    >>> # 定义插件
    >>> class MyPlugin(Plugin):
    ...     name = 'my_plugin'
    ...     version = '1.0.0'
    ...     
    ...     def register(self, container):
    ...         container.register('my_service', MyService)
    ...     
    ...     def boot(self, container):
    ...         print("Plugin booted!")
    >>> 
    >>> # 加载插件
    >>> PluginManager.load(MyPlugin)
    >>> PluginManager.load_from_directory('plugins')
"""
from typing import Dict, Type, List, Optional, Any, Callable
from abc import ABC, abstractmethod
from pathlib import Path
import importlib.util
import inspect
import logging

from .container import Container
from .events import EventBus, Events

logger = logging.getLogger(__name__)


class Plugin(ABC):
    """
    插件基类
    
    所有插件必须继承此类并实现 register 和 boot 方法
    """
    
    # 插件元数据
    name: str = ''
    version: str = '1.0.0'
    description: str = ''
    author: str = ''
    dependencies: List[str] = []
    
    # 插件状态
    _enabled: bool = False
    _container: Optional[Container] = None
    
    @abstractmethod
    def register(self, container: Container):
        """
        注册插件服务
        
        在此方法中注册插件提供的服务到容器
        """
        pass
    
    @abstractmethod
    def boot(self, container: Container):
        """
        启动插件
        
        在此方法中执行插件初始化逻辑
        """
        pass
    
    def shutdown(self):
        """
        关闭插件
        
        在此方法中执行清理逻辑
        """
        pass
    
    def enable(self):
        """启用插件"""
        self._enabled = True
        EventBus.emit(Events.PluginEvent.PLUGIN_ENABLED, {
            'name': self.name,
            'plugin': self
        })
    
    def disable(self):
        """禁用插件"""
        self._enabled = False
        EventBus.emit(Events.PluginEvent.PLUGIN_DISABLED, {
            'name': self.name,
            'plugin': self
        })
    
    def is_enabled(self) -> bool:
        """检查插件是否启用"""
        return self._enabled
    
    def get_container(self) -> Optional[Container]:
        """获取容器"""
        return self._container


class PluginManager:
    """
    插件管理器
    
    负责插件的加载、注册、启动和卸载
    """
    
    _plugins: Dict[str, Plugin] = {}
    _hooks: Dict[str, List[Callable]] = {}
    _container: Optional[Container] = None
    
    @classmethod
    def set_container(cls, container: Container):
        """设置容器"""
        cls._container = container
    
    @classmethod
    def load(cls, plugin_class: Type[Plugin]) -> Plugin:
        """
        加载插件类
        
        Args:
            plugin_class: 插件类
        
        Returns:
            插件实例
        """
        if not issubclass(plugin_class, Plugin):
            raise TypeError(f"Plugin class must inherit from Plugin: {plugin_class}")
        
        plugin = plugin_class()
        
        if plugin.name in cls._plugins:
            logger.warning(f"Plugin already loaded: {plugin.name}")
            return cls._plugins[plugin.name]
        
        # 检查依赖
        for dep in plugin.dependencies:
            if dep not in cls._plugins:
                raise RuntimeError(f"Plugin dependency not found: {dep} (required by {plugin.name})")
        
        cls._plugins[plugin.name] = plugin
        plugin._container = cls._container
        
        # 注册服务
        if cls._container:
            plugin.register(cls._container)
        
        EventBus.emit(Events.PluginEvent.PLUGIN_LOADED, {
            'name': plugin.name,
            'plugin': plugin
        })
        
        logger.info(f"Plugin loaded: {plugin.name} v{plugin.version}")
        return plugin
    
    @classmethod
    def load_from_directory(cls, directory: str, pattern: str = '*.py'):
        """
        从目录加载插件
        
        Args:
            directory: 插件目录
            pattern: 文件匹配模式
        """
        path = Path(directory)
        if not path.exists():
            logger.warning(f"Plugin directory not found: {directory}")
            return
        
        for file_path in path.glob(pattern):
            try:
                cls.load_from_file(str(file_path))
            except Exception as e:
                logger.error(f"Failed to load plugin from {file_path}: {e}")
    
    @classmethod
    def load_from_file(cls, file_path: str) -> Optional[Plugin]:
        """
        从文件加载插件
        
        Args:
            file_path: 插件文件路径
        
        Returns:
            插件实例或None
        """
        module_name = Path(file_path).stem
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # 查找插件类
        for name, obj in inspect.getmembers(module):
            if (inspect.isclass(obj) and 
                issubclass(obj, Plugin) and 
                obj is not Plugin and
                not inspect.isabstract(obj)):
                return cls.load(obj)
        
        logger.warning(f"No plugin class found in {file_path}")
        return None
    
    @classmethod
    def boot_all(cls):
        """启动所有已加载的插件"""
        if cls._container is None:
            raise RuntimeError("Container not set. Call set_container() first.")
        
        for name, plugin in cls._plugins.items():
            if not plugin.is_enabled():
                try:
                    plugin.boot(cls._container)
                    plugin.enable()
                    logger.info(f"Plugin booted: {name}")
                except Exception as e:
                    logger.error(f"Failed to boot plugin {name}: {e}")
    
    @classmethod
    def get(cls, name: str) -> Optional[Plugin]:
        """获取插件"""
        return cls._plugins.get(name)
    
    @classmethod
    def list_plugins(cls) -> List[Dict[str, Any]]:
        """列出所有插件"""
        return [
            {
                'name': p.name,
                'version': p.version,
                'description': p.description,
                'author': p.author,
                'enabled': p.is_enabled()
            }
            for p in cls._plugins.values()
        ]
    
    @classmethod
    def unload(cls, name: str) -> bool:
        """卸载插件"""
        if name not in cls._plugins:
            return False
        
        plugin = cls._plugins[name]
        plugin.shutdown()
        del cls._plugins[name]
        
        EventBus.emit(Events.PluginEvent.PLUGIN_UNLOADED, {
            'name': name,
            'plugin': plugin
        })
        
        logger.info(f"Plugin unloaded: {name}")
        return True
    
    @classmethod
    def unload_all(cls):
        """卸载所有插件"""
        for name in list(cls._plugins.keys()):
            cls.unload(name)
    
    @classmethod
    def add_hook(cls, event: str, handler: Callable):
        """添加钩子"""
        if event not in cls._hooks:
            cls._hooks[event] = []
        cls._hooks[event].append(handler)
    
    @classmethod
    def run_hooks(cls, event: str, *args, **kwargs):
        """运行钩子"""
        for handler in cls._hooks.get(event, []):
            try:
                handler(*args, **kwargs)
            except Exception as e:
                logger.error(f"Hook error for {event}: {e}")


class PluginMixin:
    """
    插件混入类
    
    为其他类提供插件功能支持
    """
    
    _plugin_hooks: Dict[str, List[Callable]] = {}
    
    def apply_plugin_hooks(self, hook_name: str, *args, **kwargs):
        """应用插件钩子"""
        for handler in self._plugin_hooks.get(hook_name, []):
            try:
                handler(self, *args, **kwargs)
            except Exception as e:
                logger.error(f"Plugin hook error: {e}")
    
    def register_hook(self, hook_name: str, handler: Callable):
        """注册钩子"""
        if hook_name not in self._plugin_hooks:
            self._plugin_hooks[hook_name] = []
        self._plugin_hooks[hook_name].append(handler)


# 扩展事件类型
class Events:
    """扩展事件类型"""
    
    class PluginEvent:
        """插件事件"""
        PLUGIN_LOADED = 'plugin.loaded'
        PLUGIN_UNLOADED = 'plugin.unloaded'
        PLUGIN_ENABLED = 'plugin.enabled'
        PLUGIN_DISABLED = 'plugin.disabled'
