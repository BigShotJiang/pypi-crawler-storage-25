"""
配置管理模块

支持多种配置来源:
1. 配置文件 (JSON/YAML)
2. 环境变量
3. 代码中直接设置
4. 配置文件热更新
"""
from typing import Any, Dict, Optional, Union, List
from pathlib import Path
import os
import json


class Config:
    """
    配置管理类
    
    使用示例:
        >>> config = Config()
        >>> config.load_file('config.json')
        >>> 
        >>> # 获取配置
        >>> db_path = config.get('database.path', 'data/quant.db')
        >>> 
        >>> # 设置配置
        >>> config.set('database.path', 'new/path.db')
        >>> 
        >>> # 从环境变量加载
        >>> config.load_env(prefix='CLAW_')
    """
    
    def __init__(self, data: Optional[Dict] = None):
        self._data = data or {}
        self._defaults = {}
        self._validators = {}
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值
        
        Args:
            key: 配置键，支持点号分隔，如 'database.path'
            default: 默认值
        
        Returns:
            配置值
        """
        keys = key.split('.')
        value = self._data
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """
        设置配置值
        
        Args:
            key: 配置键
            value: 配置值
        """
        keys = key.split('.')
        target = self._data
        
        for k in keys[:-1]:
            if k not in target:
                target[k] = {}
            target = target[k]
        
        target[keys[-1]] = value
    
    def load_file(self, path: Union[str, Path]) -> 'Config':
        """
        从文件加载配置
        
        Args:
            path: 配置文件路径，支持 .json 和 .yaml
        
        Returns:
            self
        """
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        
        if path.suffix == '.json':
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        elif path.suffix in ['.yaml', '.yml']:
            try:
                import yaml
                with open(path, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
            except ImportError:
                raise ImportError("PyYAML is required for YAML config files")
        else:
            raise ValueError(f"Unsupported config file format: {path.suffix}")
        
        self._data.update(data)
        return self
    
    def load_env(self, prefix: str = 'CLAW_') -> 'Config':
        """
        从环境变量加载配置
        
        Args:
            prefix: 环境变量前缀
        
        Returns:
            self
        """
        for key, value in os.environ.items():
            if key.startswith(prefix):
                config_key = key[len(prefix):].lower().replace('__', '.')
                
                # 尝试解析为数字或布尔值
                if value.lower() in ('true', 'false'):
                    value = value.lower() == 'true'
                else:
                    try:
                        value = float(value)
                        if value.is_integer():
                            value = int(value)
                    except ValueError:
                        pass
                
                self.set(config_key, value)
        
        return self
    
    def set_default(self, key: str, value: Any):
        """设置默认值"""
        self._defaults[key] = value
    
    def get_with_default(self, key: str) -> Any:
        """获取配置值，如果不存在返回默认值"""
        value = self.get(key)
        if value is None and key in self._defaults:
            return self._defaults[key]
        return value
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return self._data.copy()
    
    def merge(self, other: Union['Config', Dict]) -> 'Config':
        """合并另一个配置"""
        if isinstance(other, Config):
            other = other.to_dict()
        
        def deep_merge(base: Dict, update: Dict):
            for key, value in update.items():
                if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                    deep_merge(base[key], value)
                else:
                    base[key] = value
        
        deep_merge(self._data, other)
        return self
    
    def validate(self) -> List[str]:
        """验证配置，返回错误列表"""
        errors = []
        
        for key, validator in self._validators.items():
            value = self.get(key)
            try:
                validator(value)
            except Exception as e:
                errors.append(f"{key}: {e}")
        
        return errors
    
    def register_validator(self, key: str, validator: callable):
        """注册配置验证器"""
        self._validators[key] = validator
    
    def __getitem__(self, key: str) -> Any:
        return self.get(key)
    
    def __setitem__(self, key: str, value: Any):
        self.set(key, value)
    
    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None
