#!/usr/bin/env python
"""检查数据库中的数据"""
import duckdb

# 使用只读模式连接，避免与GUI冲突
import os
db_path = os.path.join(os.path.dirname(__file__), 'data', 'quant_system.db')
conn = duckdb.connect(db_path, read_only=True)

# 检查股票列表
print('=== 股票列表 ===')
result = conn.execute('SELECT COUNT(*) FROM stock_info').fetchone()
print(f'股票数量: {result[0]}')

# 检查日线数据
print('\n=== 日线数据 ===')
result = conn.execute('SELECT COUNT(*) FROM daily_kline').fetchone()
print(f'日线数据条数: {result[0]}')

# 检查600051的数据
print('\n=== 600051.SH 数据 ===')
result = conn.execute("SELECT COUNT(*) FROM daily_kline WHERE code = '600051.SH'").fetchone()
print(f'600051.SH 数据条数: {result[0]}')

if result[0] > 0:
    df = conn.execute("SELECT * FROM daily_kline WHERE code = '600051.SH' ORDER BY trade_date LIMIT 5").fetchdf()
    print(df)
else:
    print('没有数据')

conn.close()
