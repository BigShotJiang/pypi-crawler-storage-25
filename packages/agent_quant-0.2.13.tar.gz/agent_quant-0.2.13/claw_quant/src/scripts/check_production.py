#!/usr/bin/env python
"""检查生产数据库的内容 - 使用只读模式"""
import os
import duckdb

DB_PATH = 'data/quant_system.db'

def check_db():
    if not os.path.exists(DB_PATH):
        print(f"数据库不存在: {DB_PATH}")
        return
    
    try:
        # 尝试只读连接
        conn = duckdb.connect(DB_PATH, read_only=True)
        print(f"✓ 成功连接数据库 (只读模式)")
        
        # 检查股票列表
        print("\n=== 股票列表 ===")
        result = conn.execute("SELECT code, name FROM stocks LIMIT 10").fetchdf()
        print(result)
        count = conn.execute("SELECT COUNT(*) FROM stocks").fetchone()[0]
        print(f"总计: {count} 只股票")
        
        # 检查日线数据
        print("\n=== 日线数据统计 ===")
        count = conn.execute("SELECT COUNT(*) FROM market_data_daily").fetchone()[0]
        print(f"总计: {count} 条数据")
        
        # 各股票数据量
        print("\n=== 各股票数据量 ===")
        result = conn.execute("""
            SELECT code, COUNT(*) as count,
                   MIN(trade_date) as min_date,
                   MAX(trade_date) as max_date
            FROM market_data_daily 
            GROUP BY code 
            ORDER BY count DESC
            LIMIT 10
        """).fetchdf()
        print(result)
        
        # 检查000001.SZ的数据
        print("\n=== 000001.SZ 数据详情 ===")
        result = conn.execute("""
            SELECT trade_date, code, open, high, low, close, volume
            FROM market_data_daily 
            WHERE code = '000001.SZ'
            ORDER BY trade_date
            LIMIT 5
        """).fetchdf()
        print(result)
        print(f"\ntrade_date 类型: {result['trade_date'].dtype if not result.empty else 'N/A'}")
        if not result.empty:
            print(f"trade_date 示例: {result['trade_date'].iloc[0]} (类型: {type(result['trade_date'].iloc[0])})")
        
        # 检查日期查询
        print("\n=== 日期查询测试 ===")
        from datetime import date
        start = date(2025, 4, 1)
        end = date(2025, 4, 30)
        result = conn.execute("""
            SELECT COUNT(*) 
            FROM market_data_daily 
            WHERE code = '000001.SZ'
              AND trade_date BETWEEN ? AND ?
        """, [start, end]).fetchone()[0]
        print(f"查询 000001.SZ 从 {start} 到 {end}: {result} 条")
        
        conn.close()
        
    except Exception as e:
        print(f"✗ 错误: {e}")
        print("\n数据库可能被其他程序占用，请关闭GUI后重试")

if __name__ == '__main__':
    check_db()
