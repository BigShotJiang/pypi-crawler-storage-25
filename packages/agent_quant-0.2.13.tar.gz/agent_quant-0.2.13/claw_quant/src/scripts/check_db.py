#!/usr/bin/env python
"""检查数据库内容"""
import duckdb
import os

db_path = os.path.join(os.path.dirname(__file__), 'data', 'quant_system.db')
conn = duckdb.connect(db_path, read_only=True)

print('=== 股票列表 (stocks表) ===')
result = conn.execute("SELECT code, name, market FROM stocks LIMIT 10").fetchdf()
print(result)
print(f"总计: {conn.execute('SELECT COUNT(*) FROM stocks').fetchone()[0]} 只股票\n")

print('=== 日线数据 (market_data_daily表) ===')
count = conn.execute("SELECT COUNT(*) FROM market_data_daily").fetchone()[0]
print(f"总计: {count} 条数据\n")

print('=== 各股票数据量 ===')
result = conn.execute("""
    SELECT code, COUNT(*) as count 
    FROM market_data_daily 
    GROUP BY code 
    ORDER BY count DESC
    LIMIT 10
""").fetchdf()
print(result)

print('\n=== 000001.SZ 数据 ===')
result = conn.execute("""
    SELECT * FROM market_data_daily 
    WHERE code = '000001.SZ' 
    ORDER BY trade_date 
    LIMIT 5
""").fetchdf()
print(result)

conn.close()
