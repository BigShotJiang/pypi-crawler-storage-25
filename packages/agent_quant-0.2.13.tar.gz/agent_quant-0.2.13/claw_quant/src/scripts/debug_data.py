"""
调试数据问题
通过HTTP API访问数据库
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from database.db_http_client import DBHttpClient

def main():
    print("="*60)
    print("调试数据问题")
    print("="*60)
    
    # 连接数据库API服务器
    db = DBHttpClient(host='127.0.0.1', port=9529)
    if not db.ping():
        print("错误: 无法连接到数据库API服务器")
        print("请确保服务器已启动: python -m database.db_api_server")
        sys.exit(1)
    
    print("✅ 已连接到数据库API服务器\n")
    
    # 检查000001.SZ的记录数
    try:
        df = db.execute_query(
            "SELECT COUNT(*) as cnt FROM market_data_daily WHERE code = '000001.SZ'"
        )
        count = df['cnt'].iloc[0] if not df.empty else 0
        print(f'000001.SZ 记录数: {count}')
    except Exception as e:
        print(f'查询记录数失败: {e}')
    
    # 检查是否有重复数据
    try:
        df = db.execute_query('''
            SELECT code, trade_date, COUNT(*) as cnt
            FROM market_data_daily
            GROUP BY code, trade_date
            HAVING COUNT(*) > 1
            LIMIT 5
        ''')
        print(f'\n重复记录:')
        print(df.to_string() if not df.empty else "无重复记录")
    except Exception as e:
        print(f'查询重复记录失败: {e}')
    
    # 查看实际记录分布
    try:
        df = db.execute_query('''
            SELECT code, COUNT(*) as cnt
            FROM market_data_daily
            GROUP BY code
            ORDER BY cnt DESC
            LIMIT 10
        ''')
        print('\n记录最多的10只股票:')
        print(df.to_string() if not df.empty else "无数据")
    except Exception as e:
        print(f'查询记录分布失败: {e}')
    
    # 查看记录最少的
    try:
        df = db.execute_query('''
            SELECT code, COUNT(*) as cnt
            FROM market_data_daily
            GROUP BY code
            ORDER BY cnt ASC
            LIMIT 10
        ''')
        print('\n记录最少的10只股票:')
        print(df.to_string() if not df.empty else "无数据")
    except Exception as e:
        print(f'查询记录分布失败: {e}')
    
    print('\n' + '='*60)


if __name__ == '__main__':
    main()
