"""
初始化数据脚本 - 首次运行时使用
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from database import DuckDBManager
from data_updater import MarketDataUpdater
from datetime import date, timedelta
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)


def init_data():
    """初始化数据"""
    logger.info("=" * 60)
    logger.info("开始初始化数据")
    logger.info("=" * 60)
    
    # 1. 连接数据库
    logger.info("\n1. 连接数据库...")
    # 检查是否有GUI占用数据库，如果有使用临时数据库
    db_path = "data/quant_system.db"
    import os
    lock_file = db_path + ".lock"
    if os.path.exists(lock_file) or os.path.exists(db_path):
        # 尝试连接，如果失败使用临时数据库
        try:
            db = DuckDBManager(db_path)
            logger.info("✓ 数据库连接成功")
        except Exception as e:
            logger.warning(f"主数据库被占用，使用临时数据库: {e}")
            db = DuckDBManager("data/quant_system_temp.db")
            logger.info("✓ 临时数据库连接成功")
    else:
        db = DuckDBManager(db_path)
        logger.info("✓ 数据库连接成功")
    
    # 2. 创建数据更新器
    logger.info("\n2. 初始化数据更新器...")
    updater = MarketDataUpdater(db)
    logger.info("✓ 数据更新器初始化成功")
    
    # 3. 更新股票列表
    logger.info("\n3. 更新股票列表...")
    try:
        updater.update_stock_info()
        stocks = db.get_all_stocks()
        logger.info(f"✓ 股票列表更新完成，共 {len(stocks)} 只股票")
    except Exception as e:
        logger.error(f"✗ 更新股票列表失败: {e}")
        return
    
    # 4. 更新日线数据（最近30天）
    logger.info("\n4. 更新日线数据...")
    end_date = date.today()
    start_date = end_date - timedelta(days=30)
    
    logger.info(f"   时间范围: {start_date} ~ {end_date}")
    
    try:
        # 先测试几只股票
        test_codes = ['000001.SZ', '000002.SZ', '600000.SH']
        logger.info(f"   先测试 {len(test_codes)} 只股票...")
        
        stats = updater.update_daily_data(
            codes=test_codes,
            start_date=start_date,
            end_date=end_date
        )
        
        logger.info(f"✓ 测试数据更新完成: 成功 {stats['success']}, 记录 {stats['records']}")
        
        # 询问是否更新全部
        logger.info("\n5. 是否更新全部股票数据？")
        logger.info("   全部更新可能需要较长时间（30分钟以上）")
        
        # 这里先不自动更新全部，让用户决定
        logger.info("   提示: 可以在GUI中手动更新全部数据")
        
    except Exception as e:
        logger.error(f"✗ 更新日线数据失败: {e}")
        import traceback
        traceback.print_exc()
    
    logger.info("\n" + "=" * 60)
    logger.info("数据初始化完成！")
    logger.info("=" * 60)
    
    # 显示统计
    logger.info("\n数据概览:")
    logger.info(f"  - 股票数量: {db.get_table_count('stocks')}")
    logger.info(f"  - 日线记录: {db.get_table_count('market_data_daily')}")
    
    db.close()


if __name__ == '__main__':
    init_data()
