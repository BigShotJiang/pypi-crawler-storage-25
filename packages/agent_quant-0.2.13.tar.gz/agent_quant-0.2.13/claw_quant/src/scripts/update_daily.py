"""
每日数据更新脚本

用途：每天收盘后运行，获取所有A股当天的日线数据并更新到数据库

用法：
  # 更新今天的数据
  python scripts/update_daily.py

  # 更新指定日期的数据
  python scripts/update_daily.py --date 20260415

  # 补全最近几天的数据（如周末后补周五的）
  python scripts/update_daily.py --date 20260411

  # 指定数据库服务器地址
  python scripts/update_daily.py --host 127.0.0.1 --port 9529

  # 调整批次大小（默认500，内存不够可调小）
  python scripts/update_daily.py --batch-size 200
"""

import os
import sys
import argparse
import logging
from datetime import datetime, date

# 添加项目根目录到 path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


def print_progress(batch_num: int, total_batches: int, success: int, records: int):
    """进度回调"""
    progress = (batch_num / total_batches) * 100
    print(
        f"\r[{batch_num}/{total_batches}] {progress:.0f}% | "
        f"成功: {success} 只 | 记录: {records} 条",
        end='', flush=True
    )


def main():
    parser = argparse.ArgumentParser(description='每日数据更新')
    parser.add_argument('--date', type=str, default=None,
                        help='目标日期 YYYYMMDD，默认今天')
    parser.add_argument('--host', type=str, default='127.0.0.1',
                        help='数据库服务器地址，默认127.0.0.1')
    parser.add_argument('--port', type=int, default=9529,
                        help='数据库服务器端口，默认9529')
    parser.add_argument('--batch-size', type=int, default=500,
                        help='每批获取的股票数量')
    args = parser.parse_args()

    # 切换工作目录
    os.chdir(project_root)

    target_date = args.date
    if target_date:
        display_date = f"{target_date[:4]}-{target_date[4:6]}-{target_date[6:]}"
    else:
        display_date = date.today().strftime('%Y-%m-%d')

    print(f"{'=' * 50}")
    print(f"  每日数据更新")
    print(f"  目标日期: {display_date}")
    print(f"  数据库服务器: {args.host}:{args.port}")
    print(f"  批次大小: {args.batch_size}")
    print(f"{'=' * 50}")

    from api.data import DataAPI
    api = DataAPI({
        'db_host': args.host,
        'db_port': args.port,
        'data_source': 'auto'
    })

    if not api.is_connected():
        print("错误: 数据库未连接，请确保数据库API服务器已启动")
        print(f"  启动命令: python -m database.db_api_server")
        sys.exit(1)

    start_time = datetime.now()
    result = api.update_daily(
        target_date=target_date,
        batch_size=args.batch_size,
        progress_callback=print_progress
    )

    elapsed = (datetime.now() - start_time).total_seconds()
    print()  # 换行
    print(f"{'=' * 50}")
    print(f"  更新完成!")
    print(f"  目标日期: {result.get('target_date', display_date)}")
    print(f"  总股票数: {result.get('total', 0)}")
    print(f"  成功: {result.get('success', 0)}")
    print(f"  失败: {result.get('failed', 0)}")
    print(f"  总记录数: {result.get('records', 0)}")
    print(f"  耗时: {elapsed:.1f} 秒")
    print(f"{'=' * 50}")

    if result.get('error'):
        print(f"  错误: {result['error']}")
        sys.exit(1)


if __name__ == '__main__':
    main()
