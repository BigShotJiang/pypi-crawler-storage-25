# -*- coding: utf-8 -*-
"""
ClawQuant 功能模块

包含所有核心功能实现：
- backtest: 回测引擎
- core: 核心组件
- factor: 因子库
- gui: 图形界面
- strategy: 策略库
- trade: 交易接口
- utils: 工具函数

注意：数据管理模块(database)已移至根目录，作为独立模块
"""

__version__ = "0.1.0"
