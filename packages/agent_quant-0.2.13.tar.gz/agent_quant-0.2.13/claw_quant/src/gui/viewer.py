"""
股票数据浏览器 - 查看股票列表和K线图
"""
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QComboBox, QDateEdit,
    QSplitter, QGroupBox, QLineEdit, QMessageBox, QHeaderView
)
from PyQt5.QtCore import Qt, QDate
from datetime import date, timedelta
import pandas as pd
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import logging

# 设置中文字体 - 尝试多种字体
try:
    import matplotlib.font_manager as fm
    # 查找系统中的中文字体
    fonts = [f.name for f in fm.fontManager.ttflist]
    chinese_fonts = ['SimHei', 'Microsoft YaHei', 'SimSun', 'NSimSun', 'FangSong', 'KaiTi', 'Arial Unicode MS']
    font_found = None
    for font in chinese_fonts:
        if font in fonts:
            font_found = font
            break
    if font_found:
        plt.rcParams['font.sans-serif'] = [font_found, 'DejaVu Sans']
    else:
        plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
except:
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans']

plt.rcParams['axes.unicode_minus'] = False

logger = logging.getLogger(__name__)


class MplCanvas(FigureCanvas):
    """Matplotlib画布"""
    def __init__(self, parent=None, width=10, height=6, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)


class StockViewerWidget(QWidget):
    """股票数据浏览器"""

    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.canvas = None

        self.init_ui()
        self.load_stock_list()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # 创建分割器
        splitter = QSplitter(Qt.Vertical)

        # 上半部分：股票列表
        top_widget = QWidget()
        top_layout = QVBoxLayout(top_widget)

        # 筛选和按钮
        filter_layout = QHBoxLayout()

        filter_layout.addWidget(QLabel("筛选:"))
        self.input_filter = QLineEdit()
        self.input_filter.setPlaceholderText("输入股票代码或名称...")
        self.input_filter.textChanged.connect(self.filter_stocks)
        filter_layout.addWidget(self.input_filter)

        filter_layout.addWidget(QLabel("市场:"))
        self.combo_market = QComboBox()
        self.combo_market.addItems(["全部", "上海", "深圳", "北京"])
        self.combo_market.currentTextChanged.connect(self.load_stock_list)
        filter_layout.addWidget(self.combo_market)

        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.load_stock_list)
        filter_layout.addWidget(btn_refresh)

        filter_layout.addStretch()
        top_layout.addLayout(filter_layout)

        # 股票表格
        self.table_stocks = QTableWidget()
        self.table_stocks.setColumnCount(6)
        self.table_stocks.setHorizontalHeaderLabels([
            '代码', '名称', '市场', '行业', '上市日期', '状态'
        ])
        self.table_stocks.horizontalHeader().setStretchLastSection(True)
        self.table_stocks.setSelectionBehavior(QTableWidget.SelectRows)
        self.table_stocks.setSelectionMode(QTableWidget.SingleSelection)
        self.table_stocks.itemSelectionChanged.connect(self.on_stock_selected)
        top_layout.addWidget(self.table_stocks)

        # 统计
        self.label_stats = QLabel("共 0 只股票")
        top_layout.addWidget(self.label_stats)

        splitter.addWidget(top_widget)

        # 下半部分：K线图
        bottom_widget = QWidget()
        bottom_layout = QVBoxLayout(bottom_widget)

        # K线控制
        kline_control = QHBoxLayout()

        kline_control.addWidget(QLabel("开始日期:"))
        self.date_start = QDateEdit()
        # 默认从2024-01-01开始，确保能显示历史数据
        self.date_start.setDate(QDate(2024, 1, 1))
        self.date_start.setCalendarPopup(True)
        kline_control.addWidget(self.date_start)

        kline_control.addWidget(QLabel("结束日期:"))
        self.date_end = QDateEdit()
        self.date_end.setDate(QDate.currentDate())
        self.date_end.setCalendarPopup(True)
        kline_control.addWidget(self.date_end)

        btn_plot = QPushButton("绘制K线")
        btn_plot.clicked.connect(self.plot_kline)
        kline_control.addWidget(btn_plot)

        self.label_selected = QLabel("选中: 无")
        kline_control.addWidget(self.label_selected)

        kline_control.addStretch()
        bottom_layout.addLayout(kline_control)

        # K线图
        self.canvas = MplCanvas(self, width=10, height=5)
        bottom_layout.addWidget(self.canvas)

        splitter.addWidget(bottom_widget)
        splitter.setSizes([300, 400])

        layout.addWidget(splitter)

    def load_stock_list(self):
        """加载股票列表"""
        try:
            # 获取所有股票
            df = self.db.get_all_stocks()

            if df.empty:
                self.label_stats.setText("数据库中没有股票数据")
                return

            # 市场筛选
            market_filter = self.combo_market.currentText()
            if market_filter == "上海":
                df = df[df['market'] == 'SH']
            elif market_filter == "深圳":
                df = df[df['market'] == 'SZ']
            elif market_filter == "北京":
                df = df[df['market'] == 'BJ']

            # 填充表格
            self.table_stocks.setRowCount(len(df))
            self.stock_data = df

            for i, row in df.iterrows():
                self.table_stocks.setItem(i, 0, QTableWidgetItem(str(row['code'])))
                self.table_stocks.setItem(i, 1, QTableWidgetItem(str(row.get('name', ''))))
                self.table_stocks.setItem(i, 2, QTableWidgetItem(str(row.get('market', ''))))
                self.table_stocks.setItem(i, 3, QTableWidgetItem(str(row.get('industry', ''))))

                list_date = row.get('list_date')
                if list_date and not pd.isna(list_date):
                    self.table_stocks.setItem(i, 4, QTableWidgetItem(str(list_date)))
                else:
                    self.table_stocks.setItem(i, 4, QTableWidgetItem("-"))

                self.table_stocks.setItem(i, 5, QTableWidgetItem(str(row.get('status', ''))))

            self.label_stats.setText(f"共 {len(df)} 只股票")

        except Exception as e:
            logger.error(f"加载股票列表失败: {e}")
            QMessageBox.critical(self, "错误", f"加载股票列表失败: {e}")

    def filter_stocks(self, text):
        """筛选股票"""
        text = text.lower()
        for i in range(self.table_stocks.rowCount()):
            code = self.table_stocks.item(i, 0).text().lower()
            name = self.table_stocks.item(i, 1).text().lower()

            if text in code or text in name:
                self.table_stocks.setRowHidden(i, False)
            else:
                self.table_stocks.setRowHidden(i, True)

    def on_stock_selected(self):
        """股票选中事件"""
        row = self.table_stocks.currentRow()
        if row >= 0:
            code = self.table_stocks.item(row, 0).text()
            name = self.table_stocks.item(row, 1).text()
            self.label_selected.setText(f"选中: {code} {name}")
            self.current_code = code
            # 自动绘制K线图
            self.plot_kline()

    def plot_kline(self):
        """绘制K线图"""
        if not hasattr(self, 'current_code'):
            return

        code = self.current_code
        start_date = self.date_start.date().toPyDate()
        end_date = self.date_end.date().toPyDate()

        try:
            # 获取数据
            df = self.db.get_market_data_daily(code, start_date, end_date)

            if df.empty:
                # 清空画布并显示无数据提示
                self.canvas.axes.clear()
                self.canvas.axes.text(0.5, 0.5, f'{code}\nNo Data', 
                                     ha='center', va='center', fontsize=14)
                self.canvas.axes.set_xlim(0, 1)
                self.canvas.axes.set_ylim(0, 1)
                self.canvas.axes.axis('off')
                self.canvas.draw()
                return

            # 转换日期
            df['trade_date'] = pd.to_datetime(df['trade_date'])

            # 清空画布
            self.canvas.axes.clear()

            # 绘制K线图
            self._plot_candlestick(df)

            # 设置标题和格式 - 使用英文避免字体问题
            name = self.table_stocks.item(self.table_stocks.currentRow(), 1).text()
            self.canvas.axes.set_title(f"{code} K-Line", fontsize=14)
            self.canvas.axes.set_xlabel("Date", fontsize=10)
            self.canvas.axes.set_ylabel("Price", fontsize=10)

            # 旋转x轴标签
            self.canvas.axes.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
            self.canvas.axes.xaxis.set_major_locator(mdates.WeekdayLocator(interval=5))
            self.canvas.fig.autofmt_xdate()

            # 添加网格
            self.canvas.axes.grid(True, alpha=0.3)

            self.canvas.draw()

        except Exception as e:
            logger.error(f"绘制K线图失败: {e}")
            QMessageBox.critical(self, "错误", f"绘制K线图失败: {e}")

    def _plot_candlestick(self, df):
        """绘制蜡烛图"""
        width = 0.6
        width2 = 0.05

        for i, row in df.iterrows():
            date = row['trade_date']
            open_price = row['open']
            high = row['high']
            low = row['low']
            close = row['close']

            if close >= open_price:
                color = 'red'  # 上涨
                self.canvas.axes.bar(date, close - open_price, width, bottom=open_price, color=color)
                self.canvas.axes.bar(date, high - close, width2, bottom=close, color=color)
                self.canvas.axes.bar(date, low - open_price, width2, bottom=open_price, color=color)
            else:
                color = 'green'  # 下跌
                self.canvas.axes.bar(date, open_price - close, width, bottom=close, color=color)
                self.canvas.axes.bar(date, high - open_price, width2, bottom=open_price, color=color)
                self.canvas.axes.bar(date, low - close, width2, bottom=close, color=color)
