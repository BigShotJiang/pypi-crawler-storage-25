"""
多任务回测对话框
"""
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QComboBox, QDateEdit,
    QSpinBox, QDoubleSpinBox, QLineEdit, QCheckBox, QGroupBox,
    QTabWidget, QTextEdit, QProgressBar, QMessageBox, QSplitter,
    QHeaderView, QMenu, QAction
)
from PyQt5.QtCore import Qt, QDate, QThread, pyqtSignal
from datetime import date, datetime
import pandas as pd
import logging

from backtest import BacktestTaskManager, TaskStatus

logger = logging.getLogger(__name__)


class TaskMonitorThread(QThread):
    """任务监控线程"""
    task_updated = pyqtSignal()
    
    def __init__(self, task_manager):
        super().__init__()
        self.task_manager = task_manager
        self._is_running = True
        
    def run(self):
        while self._is_running:
            self.task_updated.emit()
            self.msleep(1000)  # 每秒更新一次
            
    def stop(self):
        self._is_running = False


class BacktestTaskDialog(QDialog):
    """回测任务管理对话框"""
    
    def __init__(self, db_manager, strategy_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.strategy_manager = strategy_manager
        self.task_manager = BacktestTaskManager(db_manager, strategy_manager)
        
        self.setWindowTitle("回测任务管理")
        self.setGeometry(100, 100, 1200, 800)
        
        self.init_ui()
        self.task_manager.start_worker(max_concurrent=2)
        
        # 启动监控线程
        self.monitor_thread = TaskMonitorThread(self.task_manager)
        self.monitor_thread.task_updated.connect(self.refresh_task_list)
        self.monitor_thread.start()
        
        # 设置回调
        self.task_manager.on_task_start = self.on_task_start
        self.task_manager.on_task_complete = self.on_task_complete
        self.task_manager.on_task_failed = self.on_task_failed
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 创建标签页
        tabs = QTabWidget()
        
        # 任务列表页
        tabs.addTab(self.create_task_list_tab(), "任务列表")
        
        # 创建任务页
        tabs.addTab(self.create_new_task_tab(), "创建任务")
        
        # 批量任务页
        tabs.addTab(self.create_batch_task_tab(), "批量任务")
        
        # 任务调度页
        tabs.addTab(self.create_schedule_tab(), "定时调度")
        
        layout.addWidget(tabs)
        
        # 关闭按钮
        btn_close = QPushButton("关闭")
        btn_close.clicked.connect(self.close_dialog)
        layout.addWidget(btn_close)
        
    def create_task_list_tab(self):
        """创建任务列表页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 统计信息
        stats_layout = QHBoxLayout()
        self.label_stats = QLabel("总任务: 0 | 等待中: 0 | 运行中: 0 | 已完成: 0 | 失败: 0")
        stats_layout.addWidget(self.label_stats)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)
        
        # 任务表格
        self.table_tasks = QTableWidget()
        self.table_tasks.setColumnCount(10)
        self.table_tasks.setHorizontalHeaderLabels([
            '任务ID', '任务名称', '策略', '开始日期', '结束日期', '状态', 
            '进度', '总收益', '夏普比率', '操作'
        ])
        self.table_tasks.horizontalHeader().setStretchLastSection(True)
        self.table_tasks.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table_tasks.customContextMenuRequested.connect(self.show_task_menu)
        layout.addWidget(self.table_tasks)
        
        # 按钮
        btn_layout = QHBoxLayout()
        
        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.refresh_task_list)
        btn_layout.addWidget(btn_refresh)
        
        btn_batch_submit = QPushButton("批量提交等待任务")
        btn_batch_submit.clicked.connect(self.batch_submit_pending)
        btn_layout.addWidget(btn_batch_submit)
        
        btn_delete_completed = QPushButton("删除已完成")
        btn_delete_completed.clicked.connect(self.delete_completed)
        btn_layout.addWidget(btn_delete_completed)
        
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        # 详情
        self.text_task_detail = QTextEdit()
        self.text_task_detail.setMaximumHeight(150)
        self.text_task_detail.setPlaceholderText("选择任务查看详情...")
        layout.addWidget(self.text_task_detail)
        
        return widget
        
    def create_new_task_tab(self):
        """创建新任务页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 基本配置
        config_group = QGroupBox("基本配置")
        config_layout = QGridLayout(config_group)
        
        config_layout.addWidget(QLabel("任务名称:"), 0, 0)
        self.input_task_name = QLineEdit()
        self.input_task_name.setPlaceholderText("输入任务名称")
        config_layout.addWidget(self.input_task_name, 0, 1)
        
        config_layout.addWidget(QLabel("选择策略:"), 1, 0)
        self.combo_strategy = QComboBox()
        self.load_strategies()
        config_layout.addWidget(self.combo_strategy, 1, 1)
        
        config_layout.addWidget(QLabel("开始日期:"), 2, 0)
        self.task_start_date = QDateEdit()
        self.task_start_date.setDate(QDate.currentDate().addDays(-365))
        self.task_start_date.setCalendarPopup(True)
        config_layout.addWidget(self.task_start_date, 2, 1)
        
        config_layout.addWidget(QLabel("结束日期:"), 3, 0)
        self.task_end_date = QDateEdit()
        self.task_end_date.setDate(QDate.currentDate())
        self.task_end_date.setCalendarPopup(True)
        config_layout.addWidget(self.task_end_date, 3, 1)
        
        config_layout.addWidget(QLabel("初始资金:"), 4, 0)
        self.spin_capital = QSpinBox()
        self.spin_capital.setRange(100000, 100000000)
        self.spin_capital.setValue(1000000)
        self.spin_capital.setSingleStep(100000)
        config_layout.addWidget(self.spin_capital, 4, 1)
        
        layout.addWidget(config_group)
        
        # 高级配置
        advanced_group = QGroupBox("高级配置")
        advanced_layout = QGridLayout(advanced_group)
        
        self.check_scheduled = QCheckBox("启用定时调度")
        advanced_layout.addWidget(self.check_scheduled, 0, 0)
        
        advanced_layout.addWidget(QLabel("调度类型:"), 1, 0)
        self.combo_schedule_type = QComboBox()
        self.combo_schedule_type.addItems(["每天", "每周", "每月"])
        advanced_layout.addWidget(self.combo_schedule_type, 1, 1)
        
        advanced_layout.addWidget(QLabel("运行时间:"), 2, 0)
        self.input_schedule_time = QLineEdit("15:30")
        advanced_layout.addWidget(self.input_schedule_time, 2, 1)
        
        layout.addWidget(advanced_group)
        
        # 创建按钮
        btn_create = QPushButton("创建任务")
        btn_create.clicked.connect(self.create_task)
        layout.addWidget(btn_create)
        
        layout.addStretch()
        
        return widget
        
    def create_batch_task_tab(self):
        """创建批量任务页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        layout.addWidget(QLabel("批量创建多个时间段的回测任务"))
        
        # 策略选择
        strategy_layout = QHBoxLayout()
        strategy_layout.addWidget(QLabel("策略:"))
        self.batch_combo_strategy = QComboBox()
        self.load_strategies_to_combo(self.batch_combo_strategy)
        strategy_layout.addWidget(self.batch_combo_strategy)
        layout.addLayout(strategy_layout)
        
        # 时间段配置
        period_group = QGroupBox("时间段配置")
        period_layout = QVBoxLayout(period_group)
        
        self.check_2024 = QCheckBox("2024年全年 (2024-01-01 至 2024-12-31)")
        self.check_2024.setChecked(True)
        period_layout.addWidget(self.check_2024)
        
        self.check_2023 = QCheckBox("2023年全年 (2023-01-01 至 2023-12-31)")
        period_layout.addWidget(self.check_2023)
        
        self.check_2022 = QCheckBox("2022年全年 (2022-01-01 至 2022-12-31)")
        period_layout.addWidget(self.check_2022)
        
        self.check_recent_1y = QCheckBox("最近1年")
        self.check_recent_1y.setChecked(True)
        period_layout.addWidget(self.check_recent_1y)
        
        self.check_recent_6m = QCheckBox("最近6个月")
        period_layout.addWidget(self.check_recent_6m)
        
        layout.addWidget(period_group)
        
        # 创建按钮
        btn_create_batch = QPushButton("批量创建任务")
        btn_create_batch.clicked.connect(self.create_batch_tasks)
        layout.addWidget(btn_create_batch)
        
        # 日志
        self.text_batch_log = QTextEdit()
        self.text_batch_log.setMaximumHeight(200)
        layout.addWidget(self.text_batch_log)
        
        layout.addStretch()
        
        return widget
        
    def create_schedule_tab(self):
        """创建定时调度页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        layout.addWidget(QLabel("定时调度配置 - 每日自动运行回测任务"))
        
        # 调度列表
        self.table_scheduled = QTableWidget()
        self.table_scheduled.setColumnCount(6)
        self.table_scheduled.setHorizontalHeaderLabels([
            '任务ID', '任务名称', '策略', '调度类型', '运行时间', '状态'
        ])
        layout.addWidget(self.table_scheduled)
        
        # 按钮
        btn_layout = QHBoxLayout()
        
        btn_refresh_schedule = QPushButton("刷新")
        btn_refresh_schedule.clicked.connect(self.refresh_schedule_list)
        btn_layout.addWidget(btn_refresh_schedule)
        
        btn_enable_schedule = QPushButton("启用调度")
        btn_enable_schedule.clicked.connect(self.enable_schedule)
        btn_layout.addWidget(btn_enable_schedule)
        
        btn_disable_schedule = QPushButton("禁用调度")
        btn_disable_schedule.clicked.connect(self.disable_schedule)
        btn_layout.addWidget(btn_disable_schedule)
        
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        return widget
        
    def load_strategies(self):
        """加载策略列表"""
        strategies = self.strategy_manager.list_strategies()
        for strategy in strategies:
            self.combo_strategy.addItem(strategy.config.name, strategy.config.code)
            
    def load_strategies_to_combo(self, combo):
        """加载策略到指定combo"""
        strategies = self.strategy_manager.list_strategies()
        for strategy in strategies:
            combo.addItem(strategy.config.name, strategy.config.code)
            
    def refresh_task_list(self):
        """刷新任务列表"""
        try:
            df = self.task_manager.get_all_tasks()
            
            self.table_tasks.setRowCount(len(df))
            
            for i, row in df.iterrows():
                self.table_tasks.setItem(i, 0, QTableWidgetItem(str(row['task_id'])))
                self.table_tasks.setItem(i, 1, QTableWidgetItem(str(row['task_name'])))
                self.table_tasks.setItem(i, 2, QTableWidgetItem(str(row['strategy_code'])))
                self.table_tasks.setItem(i, 3, QTableWidgetItem(str(row['start_date'])))
                self.table_tasks.setItem(i, 4, QTableWidgetItem(str(row['end_date'])))
                self.table_tasks.setItem(i, 5, QTableWidgetItem(str(row['status'])))
                self.table_tasks.setItem(i, 6, QTableWidgetItem(f"{row['progress']:.1f}%"))
                
                total_return = row.get('total_return', 0)
                if total_return is not None:
                    return_item = QTableWidgetItem(f"{total_return:.2%}")
                    if total_return > 0:
                        return_item.setForeground(Qt.red)
                    elif total_return < 0:
                        return_item.setForeground(Qt.green)
                    self.table_tasks.setItem(i, 7, return_item)
                else:
                    self.table_tasks.setItem(i, 7, QTableWidgetItem("-"))
                    
                sharpe = row.get('sharpe_ratio', 0)
                self.table_tasks.setItem(i, 8, QTableWidgetItem(f"{sharpe:.2f}" if sharpe else "-"))
                
                # 操作按钮
                btn_widget = QWidget()
                btn_layout = QHBoxLayout(btn_widget)
                btn_layout.setContentsMargins(0, 0, 0, 0)
                
                if row['status'] == 'pending':
                    btn_run = QPushButton("运行")
                    btn_run.clicked.connect(lambda checked, tid=row['task_id']: self.run_task(tid))
                    btn_layout.addWidget(btn_run)
                    
                btn_delete = QPushButton("删除")
                btn_delete.clicked.connect(lambda checked, tid=row['task_id']: self.delete_task(tid))
                btn_layout.addWidget(btn_delete)
                
                self.table_tasks.setCellWidget(i, 9, btn_widget)
                
            # 更新统计
            stats = self.task_manager.get_task_statistics()
            self.label_stats.setText(
                f"总任务: {stats['total']} | "
                f"等待中: {stats['pending']} | "
                f"运行中: {stats['running']} | "
                f"已完成: {stats['completed']} | "
                f"失败: {stats['failed']}"
            )
            
        except Exception as e:
            logger.error(f"刷新任务列表失败: {e}")
            
    def show_task_menu(self, position):
        """显示任务右键菜单"""
        menu = QMenu()
        
        action_run = QAction("运行", self)
        action_run.triggered.connect(self.run_selected_task)
        menu.addAction(action_run)
        
        action_clone = QAction("克隆", self)
        action_clone.triggered.connect(self.clone_selected_task)
        menu.addAction(action_clone)
        
        action_delete = QAction("删除", self)
        action_delete.triggered.connect(self.delete_selected_task)
        menu.addAction(action_delete)
        
        menu.exec_(self.table_tasks.viewport().mapToGlobal(position))
        
    def create_task(self):
        """创建单个任务"""
        try:
            config = {
                'task_name': self.input_task_name.text() or f"回测_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'strategy_code': self.combo_strategy.currentData(),
                'start_date': self.task_start_date.date().toPyDate(),
                'end_date': self.task_end_date.date().toPyDate(),
                'initial_capital': self.spin_capital.value(),
                'is_scheduled': self.check_scheduled.isChecked(),
                'schedule_type': ['daily', 'weekly', 'monthly'][self.combo_schedule_type.currentIndex()],
                'schedule_time': self.input_schedule_time.text()
            }
            
            task_id = self.task_manager.create_task(config)
            QMessageBox.information(self, "成功", f"任务创建成功: {task_id}")
            
            # 清空输入
            self.input_task_name.clear()
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"创建任务失败: {e}")
            
    def create_batch_tasks(self):
        """批量创建任务"""
        try:
            strategy_code = self.batch_combo_strategy.currentData()
            configs = []
            
            if self.check_2024.isChecked():
                configs.append({
                    'task_name': f'{strategy_code}_2024',
                    'strategy_code': strategy_code,
                    'start_date': date(2024, 1, 1),
                    'end_date': date(2024, 12, 31),
                    'initial_capital': 1000000
                })
                
            if self.check_2023.isChecked():
                configs.append({
                    'task_name': f'{strategy_code}_2023',
                    'strategy_code': strategy_code,
                    'start_date': date(2023, 1, 1),
                    'end_date': date(2023, 12, 31),
                    'initial_capital': 1000000
                })
                
            if self.check_recent_1y.isChecked():
                end = date.today()
                start = end.replace(year=end.year - 1)
                configs.append({
                    'task_name': f'{strategy_code}_最近1年',
                    'strategy_code': strategy_code,
                    'start_date': start,
                    'end_date': end,
                    'initial_capital': 1000000
                })
                
            task_ids = self.task_manager.batch_create_tasks(configs)
            
            self.text_batch_log.append(f"批量创建完成，共 {len(task_ids)} 个任务")
            for tid in task_ids:
                self.text_batch_log.append(f"  - {tid}")
                
            QMessageBox.information(self, "成功", f"批量创建完成: {len(task_ids)} 个任务")
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"批量创建失败: {e}")
            
    def run_task(self, task_id):
        """运行任务"""
        self.task_manager.submit_task(task_id)
        QMessageBox.information(self, "提示", f"任务已提交: {task_id}")
        
    def run_selected_task(self):
        """运行选中的任务"""
        row = self.table_tasks.currentRow()
        if row >= 0:
            task_id = self.table_tasks.item(row, 0).text()
            self.run_task(task_id)
            
    def clone_selected_task(self):
        """克隆选中的任务"""
        row = self.table_tasks.currentRow()
        if row >= 0:
            task_id = self.table_tasks.item(row, 0).text()
            new_id = self.task_manager.clone_task(task_id)
            QMessageBox.information(self, "成功", f"任务已克隆: {new_id}")
            self.refresh_task_list()
            
    def delete_task(self, task_id):
        """删除任务"""
        reply = QMessageBox.question(self, "确认", f"确定删除任务 {task_id}?")
        if reply == QMessageBox.Yes:
            self.task_manager.delete_task(task_id)
            self.refresh_task_list()
            
    def delete_selected_task(self):
        """删除选中的任务"""
        row = self.table_tasks.currentRow()
        if row >= 0:
            task_id = self.table_tasks.item(row, 0).text()
            self.delete_task(task_id)
            
    def batch_submit_pending(self):
        """批量提交等待中的任务"""
        df = self.task_manager.get_all_tasks('pending')
        for _, row in df.iterrows():
            self.task_manager.submit_task(row['task_id'])
        QMessageBox.information(self, "提示", f"已提交 {len(df)} 个任务")
        
    def delete_completed(self):
        """删除已完成的任务"""
        df = self.task_manager.get_all_tasks('completed')
        for _, row in df.iterrows():
            self.task_manager.delete_task(row['task_id'])
        self.refresh_task_list()
        
    def refresh_schedule_list(self):
        """刷新调度列表"""
        # TODO: 实现调度列表刷新
        pass
        
    def enable_schedule(self):
        """启用调度"""
        QMessageBox.information(self, "提示", "调度功能开发中...")
        
    def disable_schedule(self):
        """禁用调度"""
        QMessageBox.information(self, "提示", "调度功能开发中...")
        
    def on_task_start(self, config):
        """任务开始回调"""
        logger.info(f"任务开始: {config.task_name}")
        
    def on_task_complete(self, config, results):
        """任务完成回调"""
        logger.info(f"任务完成: {config.task_name}, 收益: {results.get('total_return', 0):.2%}")
        
    def on_task_failed(self, config, error):
        """任务失败回调"""
        logger.error(f"任务失败: {config.task_name}, 错误: {error}")
        
    def close_dialog(self):
        """关闭对话框"""
        self.monitor_thread.stop()
        self.task_manager.stop_worker()
        self.accept()
        
    def closeEvent(self, event):
        """关闭事件"""
        self.monitor_thread.stop()
        self.task_manager.stop_worker()
        event.accept()
