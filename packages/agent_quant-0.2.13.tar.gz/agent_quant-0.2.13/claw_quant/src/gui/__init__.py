"""
GUI模块
"""
from .main import MainWindow

__all__ = ['MainWindow']
