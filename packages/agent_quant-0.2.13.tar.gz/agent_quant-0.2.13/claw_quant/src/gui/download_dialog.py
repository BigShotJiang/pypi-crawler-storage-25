"""
数据下载对话框 - 类似CSkhQuant的股票数据下载功能
"""
from PyQt5.QtWidgets import (
    QDialog, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QCheckBox, QComboBox,
    QDateEdit, QProgressBar, QTextEdit, QGroupBox, QSplitter,
    QHeaderView, QMessageBox, QLineEdit, QTabWidget
)
from PyQt5.QtCore import Qt, QDate, QThread, pyqtSignal
from datetime import date, timedelta
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class DataDownloadThread(QThread):
    """数据下载线程"""
    progress = pyqtSignal(int)
    message = pyqtSignal(str)
    stock_progress = pyqtSignal(str, int, int)  # code, current, total
    finished_signal = pyqtSignal(bool)

    def __init__(self, updater, db_manager, codes, start_date, end_date, data_types):
        super().__init__()
        self.updater = updater
        self.db = db_manager
        self.codes = codes
        self.start_date = start_date
        self.end_date = end_date
        self.data_types = data_types
        self._is_running = True
        
    def run(self):
        try:
            total = len(self.codes)
            success_count = 0
            failed_count = 0
            total_records = 0

            for i, code in enumerate(self.codes):
                if not self._is_running:
                    self.message.emit("下载已取消")
                    break

                self.stock_progress.emit(code, i + 1, total)

                try:
                    # 下载日线数据
                    if 'daily' in self.data_types:
                        # 1. 先下载到QMT缓存
                        self.updater.download_history_data(
                            code, '1d', self.start_date, self.end_date
                        )

                        # 2. 从QMT获取数据
                        df = self.updater.get_market_data(
                            code, '1d', self.start_date, self.end_date
                        )

                        # 3. 列名转换 (QMT格式 -> 数据库格式)
                        if not df.empty:
                            # QMT返回的列名: time, open, high, low, close, volume, amount
                            # 数据库需要的列名: trade_date, code, open, high, low, close, volume, amount
                            if 'time' in df.columns:
                                # QMT的time是Unix时间戳(毫秒)，如1743436800000
                                # 需要转换为date对象
                                try:
                                    # 将毫秒时间戳转换为datetime
                                    df['trade_date'] = pd.to_datetime(df['time'], unit='ms').dt.date
                                except Exception as e:
                                    self.message.emit(f"  日期转换错误: {e}")
                                    continue
                            df['code'] = code

                            # 确保所有需要的列都存在
                            required_cols = ['trade_date', 'code', 'open', 'high', 'low', 'close', 'volume']
                            for col in required_cols:
                                if col not in df.columns:
                                    df[col] = 0

                            # 数据库还需要这些列，但QMT可能不返回，填充默认值
                            optional_cols = ['turnover_rate', 'pe_ratio', 'pb_ratio', 'market_cap']
                            for col in optional_cols:
                                if col not in df.columns:
                                    df[col] = None

                            self.db.save_market_data_daily(df)
                            total_records += len(df)
                            self.message.emit(f"  {code}: 保存了 {len(df)} 条数据")

                            # 同时保存股票基础信息到stocks表
                            try:
                                self.db.conn.execute("""
                                    INSERT INTO stocks (code, name, market, list_date, status)
                                    VALUES (?, ?, ?, ?, ?)
                                    ON CONFLICT (code) DO NOTHING
                                """, [code, code, 'SH' if '.SH' in code else 'SZ', None, 'active'])
                            except Exception as e:
                                pass  # 忽略重复插入的错误
                        else:
                            self.message.emit(f"  {code}: 没有数据")

                    success_count += 1

                except Exception as e:
                    failed_count += 1
                    self.message.emit(f"下载失败 {code}: {e}")

                progress = int((i + 1) / total * 100)
                self.progress.emit(progress)

            self.message.emit(f"下载完成: 成功 {success_count}只股票, 共 {total_records} 条数据, 失败 {failed_count}")
            self.finished_signal.emit(True)
            
        except Exception as e:
            self.message.emit(f"下载出错: {e}")
            self.finished_signal.emit(False)
            
    def stop(self):
        self._is_running = False


class DataDownloadDialog(QDialog):
    """数据下载对话框"""
    
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.updater = None
        self.download_thread = None
        
        self.setWindowTitle("数据下载")
        self.setGeometry(100, 100, 1000, 700)
        
        self.init_ui()
        self.load_stock_list()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 创建分割器
        splitter = QSplitter(Qt.Vertical)
        
        # 上半部分：配置和股票列表
        top_widget = QWidget()
        top_layout = QVBoxLayout(top_widget)
        
        # 下载配置
        config_group = QGroupBox("下载配置")
        config_layout = QHBoxLayout(config_group)
        
        config_layout.addWidget(QLabel("开始日期:"))
        self.date_start = QDateEdit()
        self.date_start.setDate(QDate.currentDate().addDays(-365))
        self.date_start.setCalendarPopup(True)
        config_layout.addWidget(self.date_start)
        
        config_layout.addWidget(QLabel("结束日期:"))
        self.date_end = QDateEdit()
        self.date_end.setDate(QDate.currentDate())
        self.date_end.setCalendarPopup(True)
        config_layout.addWidget(self.date_end)
        
        config_layout.addWidget(QLabel("数据类型:"))
        self.combo_data_type = QComboBox()
        self.combo_data_type.addItems(["日线数据", "分钟数据"])
        config_layout.addWidget(self.combo_data_type)
        
        config_layout.addStretch()
        top_layout.addWidget(config_group)
        
        # 股票列表
        stock_group = QGroupBox("股票列表")
        stock_layout = QVBoxLayout(stock_group)
        
        # 筛选和选择按钮
        btn_layout = QHBoxLayout()
        
        self.input_filter = QLineEdit()
        self.input_filter.setPlaceholderText("筛选股票代码或名称...")
        self.input_filter.textChanged.connect(self.filter_stocks)
        btn_layout.addWidget(self.input_filter)
        
        btn_select_all = QPushButton("全选")
        btn_select_all.clicked.connect(self.select_all)
        btn_layout.addWidget(btn_select_all)
        
        btn_select_none = QPushButton("全不选")
        btn_select_none.clicked.connect(self.select_none)
        btn_layout.addWidget(btn_select_none)
        
        btn_select_sz = QPushButton("选择深圳")
        btn_select_sz.clicked.connect(lambda: self.select_by_market('SZ'))
        btn_layout.addWidget(btn_select_sz)
        
        btn_select_sh = QPushButton("选择上海")
        btn_select_sh.clicked.connect(lambda: self.select_by_market('SH'))
        btn_layout.addWidget(btn_select_sh)
        
        stock_layout.addLayout(btn_layout)
        
        # 股票表格
        self.table_stocks = QTableWidget()
        self.table_stocks.setColumnCount(4)
        self.table_stocks.setHorizontalHeaderLabels(['选择', '代码', '名称', '市场'])
        self.table_stocks.horizontalHeader().setStretchLastSection(True)
        self.table_stocks.setSelectionBehavior(QTableWidget.SelectRows)
        stock_layout.addWidget(self.table_stocks)
        
        # 统计
        self.label_stats = QLabel("已选择: 0 / 0")
        stock_layout.addWidget(self.label_stats)
        
        top_layout.addWidget(stock_group)
        
        splitter.addWidget(top_widget)
        
        # 下半部分：进度和日志
        bottom_widget = QWidget()
        bottom_layout = QVBoxLayout(bottom_widget)
        
        # 进度
        progress_group = QGroupBox("下载进度")
        progress_layout = QVBoxLayout(progress_group)
        
        self.progress_bar = QProgressBar()
        progress_layout.addWidget(self.progress_bar)
        
        self.label_current = QLabel("就绪")
        progress_layout.addWidget(self.label_current)
        
        bottom_layout.addWidget(progress_group)
        
        # 日志
        log_group = QGroupBox("下载日志")
        log_layout = QVBoxLayout(log_group)
        
        self.text_log = QTextEdit()
        self.text_log.setMaximumHeight(150)
        log_layout.addWidget(self.text_log)
        
        bottom_layout.addWidget(log_group)
        
        splitter.addWidget(bottom_widget)
        splitter.setSizes([400, 300])
        
        layout.addWidget(splitter)
        
        # 按钮
        btn_layout = QHBoxLayout()
        
        self.btn_start = QPushButton("开始下载")
        self.btn_start.clicked.connect(self.start_download)
        btn_layout.addWidget(self.btn_start)
        
        self.btn_stop = QPushButton("停止")
        self.btn_stop.clicked.connect(self.stop_download)
        self.btn_stop.setEnabled(False)
        btn_layout.addWidget(self.btn_stop)
        
        btn_close = QPushButton("关闭")
        btn_close.clicked.connect(self.close)
        btn_layout.addWidget(btn_close)
        
        layout.addLayout(btn_layout)
        
    def load_stock_list(self):
        """加载股票列表"""
        try:
            # 先尝试初始化updater（用于下载）
            try:
                from data_updater import MarketDataUpdater
                self.updater = MarketDataUpdater(self.db)
            except ImportError:
                self.updater = None
                QMessageBox.warning(self, "提示", "未安装xtquant，只能使用示例数据\n请先在命令行运行: pip install xtquant")

            # 尝试从数据库加载股票列表
            stocks_df = self.db.get_all_stocks()

            if not stocks_df.empty:
                codes = stocks_df['code'].tolist()
            elif self.updater:
                # 数据库为空，从QMT获取
                codes = self.updater.get_stock_list('all')
            else:
                # 使用示例数据
                codes = ['000001.SZ', '000002.SZ', '600000.SH', '600001.SH']
            
            # 填充表格
            self.table_stocks.setRowCount(len(codes))
            self.stock_codes = codes
            
            for i, code in enumerate(codes):
                # 复选框
                checkbox = QCheckBox()
                self.table_stocks.setCellWidget(i, 0, checkbox)
                
                # 代码
                self.table_stocks.setItem(i, 1, QTableWidgetItem(code))
                
                # 名称（暂时为空）
                self.table_stocks.setItem(i, 2, QTableWidgetItem(""))
                
                # 市场
                market = 'SZ' if '.SZ' in code else 'SH' if '.SH' in code else 'BJ'
                self.table_stocks.setItem(i, 3, QTableWidgetItem(market))
                
            self.update_stats()
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载股票列表失败: {e}")
            
    def filter_stocks(self, text):
        """筛选股票"""
        text = text.lower()
        for i in range(self.table_stocks.rowCount()):
            code = self.table_stocks.item(i, 1).text().lower()
            name = self.table_stocks.item(i, 2).text().lower()
            
            if text in code or text in name:
                self.table_stocks.setRowHidden(i, False)
            else:
                self.table_stocks.setRowHidden(i, True)
                
    def select_all(self):
        """全选"""
        for i in range(self.table_stocks.rowCount()):
            if not self.table_stocks.isRowHidden(i):
                checkbox = self.table_stocks.cellWidget(i, 0)
                if checkbox:
                    checkbox.setChecked(True)
        self.update_stats()
        
    def select_none(self):
        """全不选"""
        for i in range(self.table_stocks.rowCount()):
            checkbox = self.table_stocks.cellWidget(i, 0)
            if checkbox:
                checkbox.setChecked(False)
        self.update_stats()
        
    def select_by_market(self, market):
        """按市场选择"""
        for i in range(self.table_stocks.rowCount()):
            code = self.table_stocks.item(i, 1).text()
            checkbox = self.table_stocks.cellWidget(i, 0)
            if checkbox:
                if market in code:
                    checkbox.setChecked(True)
                else:
                    checkbox.setChecked(False)
        self.update_stats()
        
    def get_selected_codes(self):
        """获取选中的股票代码"""
        codes = []
        for i in range(self.table_stocks.rowCount()):
            checkbox = self.table_stocks.cellWidget(i, 0)
            if checkbox and checkbox.isChecked():
                code = self.table_stocks.item(i, 1).text()
                codes.append(code)
        return codes
        
    def update_stats(self):
        """更新统计"""
        selected = len(self.get_selected_codes())
        total = self.table_stocks.rowCount()
        self.label_stats.setText(f"已选择: {selected} / {total}")
        
    def start_download(self):
        """开始下载"""
        codes = self.get_selected_codes()
        
        if not codes:
            QMessageBox.warning(self, "警告", "请先选择股票")
            return
            
        # 检查是否有updater
        if not self.updater:
            QMessageBox.warning(self, "警告", "未安装xtquant，无法下载数据\n请先运行: pip install xtquant")
            return
            
        start_date = self.date_start.date().toPyDate()
        end_date = self.date_end.date().toPyDate()
        
        # 确定数据类型
        data_types = ['daily']
        if self.combo_data_type.currentText() == "分钟数据":
            data_types = ['1m']
            
        # 启动下载线程
        self.download_thread = DataDownloadThread(
            self.updater, self.db, codes, start_date, end_date, data_types
        )
        self.download_thread.progress.connect(self.progress_bar.setValue)
        self.download_thread.message.connect(self.text_log.append)
        self.download_thread.stock_progress.connect(self.on_stock_progress)
        self.download_thread.finished_signal.connect(self.on_download_finished)
        
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.text_log.clear()
        
        self.download_thread.start()
        
    def on_stock_progress(self, code, current, total):
        """股票下载进度"""
        self.label_current.setText(f"正在下载: {code} ({current}/{total})")
        
    def stop_download(self):
        """停止下载"""
        if self.download_thread:
            self.download_thread.stop()
            self.text_log.append("正在停止...")
            
    def on_download_finished(self, success):
        """下载完成"""
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.label_current.setText("下载完成" if success else "下载失败")

        if success:
            # 查询数据库中的数据量
            try:
                count = self.db.conn.execute("SELECT COUNT(*) FROM market_data_daily").fetchone()[0]
                QMessageBox.information(self, "完成", f"数据下载完成！\n数据库中共有 {count} 条日线数据")
            except:
                QMessageBox.information(self, "完成", "数据下载完成！")
