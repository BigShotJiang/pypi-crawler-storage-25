"""
绩效分析器
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from datetime import date


class PerformanceAnalyzer:
    """绩效分析器"""
    
    def __init__(self):
        self.results: Dict = {}
        
    def analyze(self, 
                nav_df: pd.DataFrame,
                trades_df: pd.DataFrame,
                benchmark_df: Optional[pd.DataFrame] = None) -> Dict:
        """
        分析回测绩效
        
        Args:
            nav_df: 净值DataFrame
            trades_df: 交易记录DataFrame
            benchmark_df: 基准净值DataFrame
            
        Returns:
            绩效指标
        """
        if nav_df.empty:
            return {}
            
        results = {}
        
        # 基本收益指标
        results['returns'] = self._calculate_returns(nav_df)
        
        # 风险指标
        results['risks'] = self._calculate_risks(nav_df)
        
        # 交易统计
        results['trades'] = self._analyze_trades(trades_df)
        
        # 与基准对比
        if benchmark_df is not None:
            results['benchmark'] = self._compare_benchmark(nav_df, benchmark_df)
            
        self.results = results
        return results
        
    def _calculate_returns(self, nav_df: pd.DataFrame) -> Dict:
        """计算收益指标"""
        returns = {}
        
        # 总收益
        returns['total_return'] = nav_df['nav'].iloc[-1] / nav_df['nav'].iloc[0] - 1
        
        # 年化收益
        days = len(nav_df)
        years = days / 252
        if years > 0:
            returns['annual_return'] = (1 + returns['total_return']) ** (1 / years) - 1
        else:
            returns['annual_return'] = 0
            
        # 日收益率统计
        daily_returns = nav_df['daily_return'].dropna()
        returns['daily_return_mean'] = daily_returns.mean()
        returns['daily_return_std'] = daily_returns.std()
        
        # 胜率（日收益为正的比例）
        returns['win_rate_daily'] = (daily_returns > 0).sum() / len(daily_returns) if len(daily_returns) > 0 else 0
        
        return returns
        
    def _calculate_risks(self, nav_df: pd.DataFrame) -> Dict:
        """计算风险指标"""
        risks = {}
        
        daily_returns = nav_df['daily_return'].dropna()
        
        # 波动率
        risks['volatility'] = daily_returns.std() * np.sqrt(252)
        
        # 夏普比率 (假设无风险利率3%)
        risk_free_rate = 0.03
        if risks['volatility'] > 0:
            excess_return = daily_returns.mean() * 252 - risk_free_rate
            risks['sharpe_ratio'] = excess_return / risks['volatility']
        else:
            risks['sharpe_ratio'] = 0
            
        # 最大回撤
        risks['max_drawdown'] = nav_df['drawdown'].min()
        
        # 回撤持续时间
        in_drawdown = False
        max_dd_duration = 0
        current_dd_duration = 0
        
        for _, row in nav_df.iterrows():
            if row['drawdown'] < 0:
                if not in_drawdown:
                    in_drawdown = True
                    current_dd_duration = 1
                else:
                    current_dd_duration += 1
            else:
                if in_drawdown:
                    in_drawdown = False
                    max_dd_duration = max(max_dd_duration, current_dd_duration)
                    current_dd_duration = 0
                    
        risks['max_drawdown_duration'] = max_dd_duration
        
        # 索提诺比率
        downside_returns = daily_returns[daily_returns < 0]
        downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0
        if downside_std > 0:
            risks['sortino_ratio'] = (daily_returns.mean() * 252 - risk_free_rate) / downside_std
        else:
            risks['sortino_ratio'] = 0
            
        # Calmar比率
        if risks['max_drawdown'] != 0:
            risks['calmar_ratio'] = (daily_returns.mean() * 252) / abs(risks['max_drawdown'])
        else:
            risks['calmar_ratio'] = 0
            
        return risks
        
    def _analyze_trades(self, trades_df: pd.DataFrame) -> Dict:
        """分析交易"""
        if trades_df.empty:
            return {
                'total_trades': 0,
                'buy_trades': 0,
                'sell_trades': 0,
                'win_trades': 0,
                'loss_trades': 0,
                'win_rate': 0,
                'avg_profit': 0,
                'avg_loss': 0,
                'profit_loss_ratio': 0
            }
            
        trades = {}
        
        trades['total_trades'] = len(trades_df)
        trades['buy_trades'] = len(trades_df[trades_df['trade_type'] == 'buy'])
        trades['sell_trades'] = len(trades_df[trades_df['trade_type'] == 'sell'])
        
        # 计算每笔交易的盈亏
        # 这里简化处理，实际需要匹配买卖对
        trades['win_trades'] = 0
        trades['loss_trades'] = 0
        trades['win_rate'] = 0
        trades['avg_profit'] = 0
        trades['avg_loss'] = 0
        trades['profit_loss_ratio'] = 0
        
        # 换手率
        total_amount = trades_df['amount'].sum()
        # 需要知道总资产才能计算换手率
        trades['turnover'] = 0
        
        return trades
        
    def _compare_benchmark(self, 
                           nav_df: pd.DataFrame,
                           benchmark_df: pd.DataFrame) -> Dict:
        """与基准对比"""
        comparison = {}
        
        # 对齐日期
        merged = nav_df.merge(
            benchmark_df[['date', 'nav']],
            on='date',
            suffixes=('', '_benchmark')
        )
        
        if merged.empty:
            return comparison
            
        # 超额收益
        strategy_return = merged['nav'].iloc[-1] / merged['nav'].iloc[0] - 1
        benchmark_return = merged['nav_benchmark'].iloc[-1] / merged['nav_benchmark'].iloc[0] - 1
        comparison['excess_return'] = strategy_return - benchmark_return
        
        # 日超额收益
        merged['excess_daily'] = merged['daily_return'] - merged['daily_return_benchmark']
        comparison['excess_return_mean'] = merged['excess_daily'].mean()
        comparison['excess_return_std'] = merged['excess_daily'].std()
        
        # 信息比率
        if comparison['excess_return_std'] > 0:
            comparison['information_ratio'] = comparison['excess_return_mean'] / comparison['excess_return_std'] * np.sqrt(252)
        else:
            comparison['information_ratio'] = 0
            
        # Beta
        cov = merged['daily_return'].cov(merged['daily_return_benchmark'])
        var = merged['daily_return_benchmark'].var()
        comparison['beta'] = cov / var if var > 0 else 0
        
        # Alpha
        comparison['alpha'] = merged['daily_return'].mean() - comparison['beta'] * merged['daily_return_benchmark'].mean()
        
        return comparison
        
    def generate_report(self) -> str:
        """生成文字报告"""
        if not self.results:
            return "无回测结果"
            
        report = []
        report.append("=" * 50)
        report.append("回测绩效报告")
        report.append("=" * 50)
        
        # 收益指标
        if 'returns' in self.results:
            r = self.results['returns']
            report.append("\n【收益指标】")
            report.append(f"总收益率: {r.get('total_return', 0):.2%}")
            report.append(f"年化收益率: {r.get('annual_return', 0):.2%}")
            report.append(f"日胜率: {r.get('win_rate_daily', 0):.2%}")
            
        # 风险指标
        if 'risks' in self.results:
            r = self.results['risks']
            report.append("\n【风险指标】")
            report.append(f"年化波动率: {r.get('volatility', 0):.2%}")
            report.append(f"夏普比率: {r.get('sharpe_ratio', 0):.2f}")
            report.append(f"索提诺比率: {r.get('sortino_ratio', 0):.2f}")
            report.append(f"最大回撤: {r.get('max_drawdown', 0):.2%}")
            report.append(f"Calmar比率: {r.get('calmar_ratio', 0):.2f}")
            
        # 交易统计
        if 'trades' in self.results:
            t = self.results['trades']
            report.append("\n【交易统计】")
            report.append(f"总交易次数: {t.get('total_trades', 0)}")
            report.append(f"买入次数: {t.get('buy_trades', 0)}")
            report.append(f"卖出次数: {t.get('sell_trades', 0)}")
            report.append(f"交易胜率: {t.get('win_rate', 0):.2%}")
            
        # 基准对比
        if 'benchmark' in self.results:
            b = self.results['benchmark']
            report.append("\n【基准对比】")
            report.append(f"超额收益: {b.get('excess_return', 0):.2%}")
            report.append(f"信息比率: {b.get('information_ratio', 0):.2f}")
            report.append(f"Beta: {b.get('beta', 0):.2f}")
            report.append(f"Alpha: {b.get('alpha', 0):.4f}")
            
        report.append("\n" + "=" * 50)
        
        return "\n".join(report)
        
    def plot_results(self, nav_df: pd.DataFrame, benchmark_df: Optional[pd.DataFrame] = None):
        """绘制结果图表"""
        try:
            import matplotlib.pyplot as plt
            
            fig, axes = plt.subplots(3, 1, figsize=(12, 10))
            
            # 净值曲线
            ax1 = axes[0]
            ax1.plot(nav_df['date'], nav_df['nav'], label='Strategy', linewidth=2)
            if benchmark_df is not None:
                ax1.plot(benchmark_df['date'], benchmark_df['nav'], label='Benchmark', linewidth=1, alpha=0.7)
            ax1.set_title('Net Value Curve')
            ax1.set_xlabel('Date')
            ax1.set_ylabel('Net Value')
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            
            # 回撤
            ax2 = axes[1]
            ax2.fill_between(nav_df['date'], nav_df['drawdown'], 0, color='red', alpha=0.3)
            ax2.set_title('Drawdown')
            ax2.set_xlabel('Date')
            ax2.set_ylabel('Drawdown')
            ax2.grid(True, alpha=0.3)
            
            # 日收益分布
            ax3 = axes[2]
            daily_returns = nav_df['daily_return'].dropna()
            ax3.hist(daily_returns, bins=50, edgecolor='black', alpha=0.7)
            ax3.axvline(daily_returns.mean(), color='red', linestyle='--', label=f'Mean: {daily_returns.mean():.4f}')
            ax3.set_title('Daily Return Distribution')
            ax3.set_xlabel('Daily Return')
            ax3.set_ylabel('Frequency')
            ax3.legend()
            ax3.grid(True, alpha=0.3)
            
            plt.tight_layout()
            return fig
            
        except ImportError:
            print("matplotlib not installed, skipping plot")
            return None
