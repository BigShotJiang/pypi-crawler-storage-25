"""
回测任务管理器 - 支持多任务批量管理和自动调度
"""
import pandas as pd
import uuid
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, asdict
from enum import Enum
import logging
import threading
import queue

from .engine import BacktestEngine

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"           # 等待中
    RUNNING = "running"           # 运行中
    COMPLETED = "completed"       # 已完成
    FAILED = "failed"             # 失败
    CANCELLED = "cancelled"       # 已取消
    SCHEDULED = "scheduled"       # 已调度


@dataclass
class BacktestTaskConfig:
    """回测任务配置"""
    task_id: str
    task_name: str
    strategy_code: str
    start_date: date
    end_date: date
    initial_capital: float = 1000000.0
    
    # 自动调度配置
    is_scheduled: bool = False           # 是否定时运行
    schedule_type: str = "once"          # once/daily/weekly/monthly
    schedule_time: str = "15:30"         # 运行时间
    
    # 参数优化配置
    enable_optimization: bool = False    # 是否启用参数优化
    param_grid: Optional[Dict] = None    # 参数网格
    
    # 对比基准
    benchmark_code: str = "000001.SH"    # 对比基准
    
    created_at: datetime = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()


class BacktestTaskManager:
    """回测任务管理器"""
    
    def __init__(self, db_manager, strategy_manager):
        """
        初始化任务管理器
        
        Args:
            db_manager: 数据库管理器
            strategy_manager: 策略管理器
        """
        self.db = db_manager
        self.strategy_manager = strategy_manager
        
        # 任务队列
        self.task_queue: queue.Queue = queue.Queue()
        self.running_tasks: Dict[str, threading.Thread] = {}
        self.task_results: Dict[str, Dict] = {}
        
        # 回调函数
        self.on_task_start: Optional[Callable] = None
        self.on_task_complete: Optional[Callable] = None
        self.on_task_failed: Optional[Callable] = None
        
        # 停止标志
        self._stop_flag = threading.Event()
        
        # 工作线程
        self._worker_thread: Optional[threading.Thread] = None
        
    def start_worker(self, max_concurrent: int = 2):
        """启动任务处理工作线程"""
        self._stop_flag.clear()
        self._worker_thread = threading.Thread(
            target=self._process_tasks,
            args=(max_concurrent,),
            daemon=True
        )
        self._worker_thread.start()
        logger.info(f"任务处理器启动，最大并发: {max_concurrent}")
        
    def stop_worker(self):
        """停止任务处理"""
        self._stop_flag.set()
        if self._worker_thread:
            self._worker_thread.join(timeout=5)
        logger.info("任务处理器已停止")
        
    def _process_tasks(self, max_concurrent: int):
        """处理任务队列"""
        while not self._stop_flag.is_set():
            try:
                # 获取任务
                task_config = self.task_queue.get(timeout=1)
                
                # 检查并发限制
                while len(self.running_tasks) >= max_concurrent:
                    self._stop_flag.wait(0.5)
                    if self._stop_flag.is_set():
                        return
                
                # 启动任务线程
                thread = threading.Thread(
                    target=self._run_task,
                    args=(task_config,),
                    daemon=True
                )
                self.running_tasks[task_config.task_id] = thread
                thread.start()
                
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"任务处理错误: {e}")
                
    def _run_task(self, config: BacktestTaskConfig):
        """运行单个任务"""
        task_id = config.task_id
        
        try:
            logger.info(f"开始执行任务: {config.task_name} ({task_id})")
            
            # 更新状态
            self._update_task_status(task_id, TaskStatus.RUNNING)
            
            # 回调
            if self.on_task_start:
                self.on_task_start(config)
            
            # 创建回测引擎
            engine = BacktestEngine(self.db, self.strategy_manager)
            
            # 设置回测
            engine.setup(
                strategy_code=config.strategy_code,
                start_date=config.start_date,
                end_date=config.end_date,
                initial_capital=config.initial_capital
            )
            
            # 运行回测
            results = engine.run()
            
            # 保存结果
            self.task_results[task_id] = results
            
            # 更新状态
            self._update_task_status(task_id, TaskStatus.COMPLETED, results)
            
            # 回调
            if self.on_task_complete:
                self.on_task_complete(config, results)
                
            logger.info(f"任务完成: {config.task_name}")
            
        except Exception as e:
            logger.error(f"任务失败 {task_id}: {e}")
            self._update_task_status(task_id, TaskStatus.FAILED, {'error': str(e)})
            
            if self.on_task_failed:
                self.on_task_failed(config, str(e))
                
        finally:
            # 从运行列表移除
            if task_id in self.running_tasks:
                del self.running_tasks[task_id]
                
    def _update_task_status(self, task_id: str, status: TaskStatus, results: Optional[Dict] = None):
        """更新任务状态"""
        try:
            if results:
                self.db.conn.execute("""
                    UPDATE backtest_tasks 
                    SET status = ?, progress = ?, completed_at = ?,
                        total_return = ?, annual_return = ?, sharpe_ratio = ?,
                        max_drawdown = ?, win_rate = ?
                    WHERE task_id = ?
                """, [
                    status.value,
                    100 if status == TaskStatus.COMPLETED else 0,
                    datetime.now() if status in [TaskStatus.COMPLETED, TaskStatus.FAILED] else None,
                    results.get('total_return'),
                    results.get('annual_return'),
                    results.get('sharpe_ratio'),
                    results.get('max_drawdown'),
                    results.get('win_rate'),
                    task_id
                ])
            else:
                self.db.conn.execute("""
                    UPDATE backtest_tasks SET status = ? WHERE task_id = ?
                """, [status.value, task_id])
                
        except Exception as e:
            logger.error(f"更新任务状态失败: {e}")
            
    def create_task(self, config: Dict) -> str:
        """
        创建回测任务
        
        Args:
            config: 任务配置字典
            
        Returns:
            任务ID
        """
        task_id = str(uuid.uuid4())[:8]
        
        # 创建配置对象
        task_config = BacktestTaskConfig(
            task_id=task_id,
            task_name=config.get('task_name', f'回测_{datetime.now().strftime("%Y%m%d_%H%M%S")}'),
            strategy_code=config['strategy_code'],
            start_date=config['start_date'],
            end_date=config['end_date'],
            initial_capital=config.get('initial_capital', 1000000.0),
            is_scheduled=config.get('is_scheduled', False),
            schedule_type=config.get('schedule_type', 'once'),
            schedule_time=config.get('schedule_time', '15:30'),
            enable_optimization=config.get('enable_optimization', False),
            param_grid=config.get('param_grid'),
            benchmark_code=config.get('benchmark_code', '000001.SH')
        )
        
        # 保存到数据库
        self.db.conn.execute("""
            INSERT INTO backtest_tasks 
            (task_id, task_name, strategy_code, start_date, end_date, initial_capital,
             status, progress, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            task_config.task_id,
            task_config.task_name,
            task_config.strategy_code,
            task_config.start_date,
            task_config.end_date,
            task_config.initial_capital,
            TaskStatus.PENDING.value,
            0,
            task_config.created_at
        ])
        
        logger.info(f"创建任务: {task_config.task_name} ({task_id})")
        return task_id
        
    def submit_task(self, task_id: str):
        """提交任务到队列"""
        # 获取任务配置
        task = self.get_task(task_id)
        if not task:
            logger.error(f"任务不存在: {task_id}")
            return False
            
        # 加入队列
        self.task_queue.put(task)
        logger.info(f"任务已提交: {task_id}")
        return True
        
    def create_and_submit(self, config: Dict) -> str:
        """创建并提交任务"""
        task_id = self.create_task(config)
        self.submit_task(task_id)
        return task_id
        
    def get_task(self, task_id: str) -> Optional[BacktestTaskConfig]:
        """获取任务配置"""
        df = self.db.conn.execute("""
            SELECT * FROM backtest_tasks WHERE task_id = ?
        """, [task_id]).fetchdf()
        
        if df.empty:
            return None
            
        row = df.iloc[0]
        return BacktestTaskConfig(
            task_id=row['task_id'],
            task_name=row['task_name'],
            strategy_code=row['strategy_code'],
            start_date=row['start_date'],
            end_date=row['end_date'],
            initial_capital=row['initial_capital'],
            created_at=row['created_at']
        )
        
    def get_all_tasks(self, status: Optional[str] = None) -> pd.DataFrame:
        """获取所有任务"""
        if status:
            return self.db.conn.execute("""
                SELECT * FROM backtest_tasks WHERE status = ? ORDER BY created_at DESC
            """, [status]).fetchdf()
        else:
            return self.db.conn.execute("""
                SELECT * FROM backtest_tasks ORDER BY created_at DESC
            """).fetchdf()
            
    def get_scheduled_tasks(self) -> List[BacktestTaskConfig]:
        """获取定时任务列表"""
        # 从数据库查询标记为定时任务的任务
        df = self.db.conn.execute("""
            SELECT * FROM backtest_tasks 
            WHERE status = 'scheduled' OR is_scheduled = TRUE
            ORDER BY created_at DESC
        """).fetchdf()
        
        tasks = []
        for _, row in df.iterrows():
            tasks.append(BacktestTaskConfig(
                task_id=row['task_id'],
                task_name=row['task_name'],
                strategy_code=row['strategy_code'],
                start_date=row['start_date'],
                end_date=row['end_date'],
                initial_capital=row['initial_capital'],
                is_scheduled=True
            ))
        return tasks
        
    def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        try:
            self._update_task_status(task_id, TaskStatus.CANCELLED)
            logger.info(f"任务已取消: {task_id}")
            return True
        except Exception as e:
            logger.error(f"取消任务失败: {e}")
            return False
            
    def delete_task(self, task_id: str) -> bool:
        """删除任务"""
        try:
            self.db.conn.execute("DELETE FROM backtest_tasks WHERE task_id = ?", [task_id])
            self.db.conn.execute("DELETE FROM backtest_trades WHERE task_id = ?", [task_id])
            self.db.conn.execute("DELETE FROM backtest_nav WHERE task_id = ?", [task_id])
            logger.info(f"任务已删除: {task_id}")
            return True
        except Exception as e:
            logger.error(f"删除任务失败: {e}")
            return False
            
    def clone_task(self, task_id: str, new_dates: Optional[Dict] = None) -> str:
        """
        克隆任务
        
        Args:
            task_id: 原任务ID
            new_dates: 新的日期范围 {'start_date': ..., 'end_date': ...}
            
        Returns:
            新任务ID
        """
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"任务不存在: {task_id}")
            
        config = {
            'task_name': f"{task.task_name}_克隆",
            'strategy_code': task.strategy_code,
            'start_date': new_dates.get('start_date', task.start_date) if new_dates else task.start_date,
            'end_date': new_dates.get('end_date', task.end_date) if new_dates else task.end_date,
            'initial_capital': task.initial_capital
        }
        
        return self.create_task(config)
        
    def batch_create_tasks(self, configs: List[Dict]) -> List[str]:
        """批量创建任务"""
        task_ids = []
        for config in configs:
            task_id = self.create_task(config)
            task_ids.append(task_id)
        return task_ids
        
    def batch_submit(self, task_ids: List[str]):
        """批量提交任务"""
        for task_id in task_ids:
            self.submit_task(task_id)
            
    def get_task_statistics(self) -> Dict:
        """获取任务统计"""
        df = self.db.conn.execute("""
            SELECT status, COUNT(*) as count FROM backtest_tasks GROUP BY status
        """).fetchdf()
        
        stats = {
            'total': 0,
            'pending': 0,
            'running': 0,
            'completed': 0,
            'failed': 0,
            'cancelled': 0
        }
        
        for _, row in df.iterrows():
            status = row['status']
            count = row['count']
            stats[status] = count
            stats['total'] += count
            
        return stats
        
    def compare_tasks(self, task_ids: List[str]) -> pd.DataFrame:
        """对比多个任务结果"""
        results = []
        
        for task_id in task_ids:
            df = self.db.conn.execute("""
                SELECT task_id, task_name, strategy_code, total_return, 
                       annual_return, sharpe_ratio, max_drawdown, win_rate
                FROM backtest_tasks WHERE task_id = ?
            """, [task_id]).fetchdf()
            
            if not df.empty:
                results.append(df)
                
        if results:
            return pd.concat(results, ignore_index=True)
        return pd.DataFrame()
