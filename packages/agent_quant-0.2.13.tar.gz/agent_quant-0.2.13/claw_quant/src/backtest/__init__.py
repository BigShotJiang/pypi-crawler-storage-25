# -*- coding: utf-8 -*-
"""
回测模块
提供多引擎回测支持和结果对比功能
"""

from .base import BacktestEngine, BacktestResult, TradeRecord
from .engines import (
    CSKhQuantEngine,
    JQDataEngine,
    # 统一引擎架构
    EngineType,
    BacktestInput,
    BacktestOutput,
    BaseEngineAdapter,
    UnifiedBacktestEngine,
    get_unified_engine,
    # 适配器
    LocalEngineAdapter,
    CSKhQuantEngineAdapter,
    JQDataEngineAdapter,
    VNPYEngineAdapter,
)
from .comparison import CrossEngineValidator

__all__ = [
    'BacktestEngine',
    'BacktestResult',
    'TradeRecord',
    'CSKhQuantEngine',
    'JQDataEngine',
    # 统一架构
    'EngineType',
    'BacktestInput',
    'BacktestOutput',
    'BaseEngineAdapter',
    'UnifiedBacktestEngine',
    'get_unified_engine',
    # 适配器
    'LocalEngineAdapter',
    'CSKhQuantEngineAdapter',
    'JQDataEngineAdapter',
    'VNPYEngineAdapter',
    'CrossEngineValidator',
]
