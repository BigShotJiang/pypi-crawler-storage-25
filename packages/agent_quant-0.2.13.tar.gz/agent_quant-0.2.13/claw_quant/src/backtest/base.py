# -*- coding: utf-8 -*-
"""
回测引擎基类和通用数据结构
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import date, datetime
from enum import Enum
import pandas as pd
import numpy as np


class TradeDirection(Enum):
    """交易方向"""
    BUY = "buy"
    SELL = "sell"


class OrderType(Enum):
    """订单类型"""
    MARKET = "market"
    LIMIT = "limit"


@dataclass
class TradeRecord:
    """交易记录"""
    trade_id: str
    code: str
    direction: TradeDirection
    price: float
    volume: int
    amount: float
    trade_date: date
    trade_time: Optional[str] = None
    order_type: OrderType = OrderType.MARKET
    commission: float = 0.0
    slippage: float = 0.0
    reason: str = ""


@dataclass
class BacktestResult:
    """
    回测结果
    
    标准化的回测结果格式，各引擎都需要转换为此格式
    """
    # 基本信息
    engine_name: str
    start_date: date
    end_date: date
    init_capital: float
    
    # 收益指标
    final_capital: float
    total_return: float  # 总收益率
    annual_return: float  # 年化收益率
    max_drawdown: float  # 最大回撤
    sharpe_ratio: float  # 夏普比率
    
    # 交易统计
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    avg_profit: float
    avg_loss: float
    profit_factor: float
    
    # 详细数据
    trades: List[TradeRecord] = field(default_factory=list)
    daily_returns: pd.Series = field(default_factory=pd.Series)
    equity_curve: pd.Series = field(default_factory=pd.Series)
    
    # 原始结果（保留引擎特定数据）
    raw_result: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'engine_name': self.engine_name,
            'start_date': self.start_date.isoformat(),
            'end_date': self.end_date.isoformat(),
            'init_capital': self.init_capital,
            'final_capital': self.final_capital,
            'total_return': self.total_return,
            'annual_return': self.annual_return,
            'max_drawdown': self.max_drawdown,
            'sharpe_ratio': self.sharpe_ratio,
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'win_rate': self.win_rate,
            'avg_profit': self.avg_profit,
            'avg_loss': self.avg_loss,
            'profit_factor': self.profit_factor,
        }


@dataclass
class BacktestConfig:
    """回测配置"""
    start_date: date
    end_date: date
    init_capital: float = 1000000.0
    commission_rate: float = 0.0001
    min_commission: float = 5.0
    stamp_tax_rate: float = 0.0005  # 卖出时收取
    slippage: float = 0.001
    
    # 策略参数
    universe: List[str] = field(default_factory=list)  # 股票池
    benchmark: str = "000300.SH"  # 基准指数
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'start_date': self.start_date.isoformat(),
            'end_date': self.end_date.isoformat(),
            'init_capital': self.init_capital,
            'commission_rate': self.commission_rate,
            'min_commission': self.min_commission,
            'stamp_tax_rate': self.stamp_tax_rate,
            'slippage': self.slippage,
            'universe': self.universe,
            'benchmark': self.benchmark,
        }


class BacktestEngine(ABC):
    """
    回测引擎基类
    
    所有回测引擎都应该继承此类
    """
    
    def __init__(self, name: str, config: BacktestConfig):
        self.name = name
        self.config = config
        
    @abstractmethod
    def run(self, strategy_code: str, **kwargs) -> BacktestResult:
        """
        运行回测
        
        Args:
            strategy_code: 策略代码（因子名称或策略逻辑）
            **kwargs: 额外参数
            
        Returns:
            回测结果
        """
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """检查引擎是否可用"""
        pass
    
    def calculate_metrics(self, returns: pd.Series) -> Dict[str, float]:
        """
        计算绩效指标
        
        Args:
            returns: 日收益率序列
            
        Returns:
            指标字典
        """
        if len(returns) == 0:
            return {
                'total_return': 0.0,
                'annual_return': 0.0,
                'max_drawdown': 0.0,
                'sharpe_ratio': 0.0,
            }
        
        # 总收益率
        total_return = (1 + returns).prod() - 1
        
        # 年化收益率
        n_days = len(returns)
        annual_return = (1 + total_return) ** (252 / n_days) - 1
        
        # 最大回撤
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # 夏普比率（假设无风险利率为0）
        if returns.std() > 0:
            sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252)
        else:
            sharpe_ratio = 0.0
        
        return {
            'total_return': total_return,
            'annual_return': annual_return,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe_ratio,
        }
