"""
投资组合管理
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from datetime import datetime
import pandas as pd


@dataclass
class Position:
    """持仓"""
    code: str
    volume: int = 0              # 持仓数量
    avg_price: float = 0.0       # 平均成本
    current_price: float = 0.0   # 当前价格
    market_value: float = 0.0    # 市值
    unrealized_pnl: float = 0.0  # 浮动盈亏
    realized_pnl: float = 0.0    # 已实现盈亏
    entry_date: datetime = None  # 建仓日期
    
    def update_price(self, price: float):
        """更新价格"""
        self.current_price = price
        self.market_value = self.volume * price
        self.unrealized_pnl = self.volume * (price - self.avg_price)
        
    def add(self, volume: int, price: float, date: datetime):
        """加仓"""
        total_cost = self.volume * self.avg_price + volume * price
        self.volume += volume
        self.avg_price = total_cost / self.volume if self.volume > 0 else 0
        self.current_price = price
        self.market_value = self.volume * price
        
        if self.entry_date is None:
            self.entry_date = date
            
    def reduce(self, volume: int, price: float) -> float:
        """
        减仓
        
        Returns:
            实现盈亏
        """
        if volume > self.volume:
            volume = self.volume
            
        realized = volume * (price - self.avg_price)
        self.realized_pnl += realized
        
        self.volume -= volume
        self.current_price = price
        self.market_value = self.volume * price
        
        if self.volume == 0:
            self.avg_price = 0
            self.entry_date = None
            
        return realized
        
    def close(self, price: float) -> float:
        """清仓"""
        return self.reduce(self.volume, price)
        
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'code': self.code,
            'volume': self.volume,
            'avg_price': self.avg_price,
            'current_price': self.current_price,
            'market_value': self.market_value,
            'unrealized_pnl': self.unrealized_pnl,
            'realized_pnl': self.realized_pnl,
            'entry_date': self.entry_date
        }


@dataclass
class Trade:
    """交易记录"""
    date: datetime
    code: str
    trade_type: str      # buy/sell
    volume: int
    price: float
    amount: float
    commission: float
    reason: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'date': self.date,
            'code': self.code,
            'trade_type': self.trade_type,
            'volume': self.volume,
            'price': self.price,
            'amount': self.amount,
            'commission': self.commission,
            'reason': self.reason
        }


class Portfolio:
    """投资组合"""
    
    def __init__(self, initial_capital: float = 1000000.0):
        """
        初始化投资组合
        
        Args:
            initial_capital: 初始资金
        """
        self.initial_capital = initial_capital
        self.cash = initial_capital
        self.positions: Dict[str, Position] = {}
        self.trades: List[Trade] = []
        
        # 历史记录
        self.nav_history: List[Dict] = []
        
    @property
    def total_value(self) -> float:
        """总资产"""
        return self.cash + self.market_value
        
    @property
    def market_value(self) -> float:
        """持仓市值"""
        return sum(p.market_value for p in self.positions.values())
        
    @property
    def total_pnl(self) -> float:
        """总盈亏"""
        return self.total_value - self.initial_capital
        
    @property
    def total_return(self) -> float:
        """总收益率"""
        return self.total_pnl / self.initial_capital
        
    def buy(self,
            code: str,
            volume: int,
            price: float,
            date: datetime,
            commission_rate: float = 0.0003,
            reason: str = "") -> bool:
        """
        买入
        
        Args:
            code: 股票代码
            volume: 数量
            price: 价格
            date: 日期
            commission_rate: 佣金率
            reason: 原因
            
        Returns:
            是否成功
        """
        amount = volume * price
        commission = max(amount * commission_rate, 5)  # 最低5元
        total_cost = amount + commission
        
        if total_cost > self.cash:
            # 资金不足，调整数量
            max_amount = self.cash - commission
            volume = int(max_amount / price / 100) * 100  # 取整到100股
            
            if volume <= 0:
                return False
                
            amount = volume * price
            commission = max(amount * commission_rate, 5)
            total_cost = amount + commission
            
        # 扣除现金
        self.cash -= total_cost
        
        # 更新持仓
        if code not in self.positions:
            self.positions[code] = Position(code=code)
            
        self.positions[code].add(volume, price, date)
        
        # 记录交易
        self.trades.append(Trade(
            date=date,
            code=code,
            trade_type='buy',
            volume=volume,
            price=price,
            amount=amount,
            commission=commission,
            reason=reason
        ))
        
        return True
        
    def sell(self,
             code: str,
             volume: int,
             price: float,
             date: datetime,
             commission_rate: float = 0.0003,
             stamp_duty_rate: float = 0.001,
             reason: str = "") -> bool:
        """
        卖出
        
        Args:
            code: 股票代码
            volume: 数量，0表示全部
            price: 价格
            date: 日期
            commission_rate: 佣金率
            stamp_duty_rate: 印花税率
            reason: 原因
            
        Returns:
            是否成功
        """
        if code not in self.positions or self.positions[code].volume <= 0:
            return False
            
        position = self.positions[code]
        
        if volume <= 0 or volume > position.volume:
            volume = position.volume
            
        amount = volume * price
        commission = max(amount * commission_rate, 5)
        stamp_duty = amount * stamp_duty_rate  # 卖出印花税
        total_cost = commission + stamp_duty
        
        # 实现盈亏
        realized_pnl = position.reduce(volume, price)
        
        # 增加现金
        self.cash += amount - total_cost
        
        # 记录交易
        self.trades.append(Trade(
            date=date,
            code=code,
            trade_type='sell',
            volume=volume,
            price=price,
            amount=amount,
            commission=commission + stamp_duty,
            reason=reason
        ))
        
        # 清仓后删除持仓
        if position.volume == 0:
            del self.positions[code]
            
        return True
        
    def update_prices(self, prices: Dict[str, float]):
        """更新持仓价格"""
        for code, position in self.positions.items():
            if code in prices:
                position.update_price(prices[code])
                
    def record_nav(self, date: datetime):
        """记录净值"""
        nav = self.total_value / self.initial_capital
        
        # 计算当日收益
        daily_return = 0
        if self.nav_history:
            prev_nav = self.nav_history[-1]['nav']
            daily_return = nav / prev_nav - 1
            
        self.nav_history.append({
            'date': date,
            'nav': nav,
            'total_value': self.total_value,
            'cash': self.cash,
            'market_value': self.market_value,
            'daily_return': daily_return,
            'drawdown': 0  # 稍后计算
        })
        
    def get_position(self, code: str) -> Optional[Position]:
        """获取持仓"""
        return self.positions.get(code)
        
    def get_all_positions(self) -> pd.DataFrame:
        """获取所有持仓"""
        if not self.positions:
            return pd.DataFrame()
            
        data = [p.to_dict() for p in self.positions.values()]
        return pd.DataFrame(data)
        
    def get_trades(self) -> pd.DataFrame:
        """获取交易记录"""
        if not self.trades:
            return pd.DataFrame()
            
        data = [t.to_dict() for t in self.trades]
        return pd.DataFrame(data)
        
    def get_nav_history(self) -> pd.DataFrame:
        """获取净值历史"""
        if not self.nav_history:
            return pd.DataFrame()
            
        df = pd.DataFrame(self.nav_history)
        
        # 计算回撤
        df['cummax'] = df['nav'].cummax()
        df['drawdown'] = (df['nav'] - df['cummax']) / df['cummax']
        
        return df
        
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'initial_capital': self.initial_capital,
            'cash': self.cash,
            'total_value': self.total_value,
            'market_value': self.market_value,
            'total_pnl': self.total_pnl,
            'total_return': self.total_return,
            'position_count': len(self.positions),
            'trade_count': len(self.trades)
        }
