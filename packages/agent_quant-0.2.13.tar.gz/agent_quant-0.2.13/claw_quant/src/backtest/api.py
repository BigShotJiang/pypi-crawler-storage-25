# -*- coding: utf-8 -*-
"""
回测API - 对外提供统一的回测接口
"""

from typing import Dict, List, Optional, Any, Union
from datetime import date
import json

from .base import BacktestConfig, BacktestResult
from .engines import CSKhQuantEngine
from .comparison import CrossEngineValidator, ComparisonReport
from ..src.factor import FactorRegistry


class BacktestAPI:
    """
    回测API主类
    
    提供统一的回测接口，支持多引擎对比验证
    """
    
    def __init__(self):
        self._engines = {}
        self._validator = CrossEngineValidator()
        
    def list_factors(self) -> List[str]:
        """列出所有可用因子"""
        return FactorRegistry.list_factors()
    
    def get_factor_info(self, factor_name: str) -> Optional[Dict[str, Any]]:
        """获取因子信息"""
        factor_class = FactorRegistry.get(factor_name)
        if factor_class:
            # 创建临时实例获取信息
            try:
                instance = factor_class()
                return instance.get_info()
            except:
                return {'name': factor_name, 'type': factor_class.__name__}
        return None
    
    def run_backtest(
        self,
        factor_name: str,
        start_date: Union[str, date],
        end_date: Union[str, date],
        universe: List[str] = None,
        init_capital: float = 1000000.0,
        factor_params: Dict[str, Any] = None,
        engines: List[str] = None,
        cskhquant_config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        运行回测
        
        Args:
            factor_name: 因子名称，如 'CROSS', 'MACD', 'RSI'
            start_date: 开始日期
            end_date: 结束日期
            universe: 股票池，默认 ['000001.SZ']
            init_capital: 初始资金，默认100万
            factor_params: 因子参数
            engines: 使用的引擎列表，默认 ['CSKhQuant']
            cskhquant_config: CSKhQuant引擎配置
            
        Returns:
            回测结果字典
        """
        # 转换日期格式
        if isinstance(start_date, str):
            start_date = date.fromisoformat(start_date)
        if isinstance(end_date, str):
            end_date = date.fromisoformat(end_date)
        
        # 默认股票池
        if not universe:
            universe = ['000001.SZ']
        
        # 默认引擎
        if not engines:
            engines = ['CSKhQuant']
        
        # 创建回测配置
        config = BacktestConfig(
            start_date=start_date,
            end_date=end_date,
            init_capital=init_capital,
            universe=universe
        )
        
        # 运行各引擎回测
        results = {}
        for engine_name in engines:
            try:
                if engine_name == 'CSKhQuant':
                    # 优先使用简化版引擎（不依赖PyQt5）
                    from .engines.cskhquant_simple_engine import CSKhQuantSimpleEngine
                    engine = CSKhQuantSimpleEngine(config)
                    if engine.is_available():
                        result = engine.run(factor_name, factor_params=factor_params or {})
                        results[engine_name] = result
                        self._validator.add_result(engine_name, result)
                    else:
                        # 回退到完整版引擎
                        cskhquant_cfg = cskhquant_config or {}
                        engine = CSKhQuantEngine(config, **cskhquant_cfg)
                        result = engine.run(factor_name, factor_params=factor_params or {})
                        results[engine_name] = result
                        self._validator.add_result(engine_name, result)
                elif engine_name == 'JQData':
                    from .engines.jqdata_engine import JQDataEngine
                    # 从环境变量或配置中获取账号
                    import os
                    username = os.environ.get('JQDATA_USERNAME', '13318366015')
                    password = os.environ.get('JQDATA_PASSWORD', '8301953Aa')
                    engine = JQDataEngine(config, username=username, password=password)
                    result = engine.run(factor_name, factor_params=factor_params or {})
                    results[engine_name] = result
                    self._validator.add_result(engine_name, result)
                else:
                    results[engine_name] = {'error': f'不支持的引擎: {engine_name}'}
            except Exception as e:
                results[engine_name] = {'error': str(e)}
        
        # 如果只使用一个引擎，直接返回结果
        if len(engines) == 1:
            engine_name = engines[0]
            result = results[engine_name]
            if isinstance(result, BacktestResult):
                return {
                    'success': True,
                    'engine': engine_name,
                    'result': result.to_dict(),
                    'trades_count': len(result.trades)
                }
            else:
                return {
                    'success': False,
                    'engine': engine_name,
                    'error': result.get('error', '未知错误')
                }
        
        # 多引擎对比
        comparison = self._validator.compare()
        
        return {
            'success': comparison.is_consistent,
            'comparison': comparison.to_dict(),
            'results': {k: v.to_dict() if isinstance(v, BacktestResult) else v 
                       for k, v in results.items()},
            'recommended_engine': self._validator.recommend_engine()
        }
    
    def validate_cross_engine(
        self,
        factor_name: str,
        start_date: Union[str, date],
        end_date: Union[str, date],
        factor_params: Dict[str, Any] = None
    ) -> ComparisonReport:
        """
        跨引擎验证
        
        在多个引擎上运行同一策略，验证结果一致性
        """
        # 转换日期格式
        if isinstance(start_date, str):
            start_date = date.fromisoformat(start_date)
        if isinstance(end_date, str):
            end_date = date.fromisoformat(end_date)
        
        # 重置验证器
        self._validator = CrossEngineValidator()
        
        config = BacktestConfig(
            start_date=start_date,
            end_date=end_date,
            universe=['000001.SZ']
        )
        
        # 运行CSKhQuant
        try:
            from .engines.cskhquant_simple_engine import CSKhQuantSimpleEngine
            engine = CSKhQuantSimpleEngine(config)
            result = engine.run(factor_name, factor_params=factor_params or {})
            self._validator.add_result('CSKhQuant', result)
        except Exception as e:
            print(f"CSKhQuant引擎运行失败: {e}")
        
        # 运行JQData
        try:
            from .engines.jqdata_engine import JQDataEngine
            import os
            username = os.environ.get('JQDATA_USERNAME', '13318366015')
            password = os.environ.get('JQDATA_PASSWORD', '8301953Aa')
            engine = JQDataEngine(config, username=username, password=password)
            result = engine.run(factor_name, factor_params=factor_params or {})
            self._validator.add_result('JQData', result)
        except Exception as e:
            print(f"JQData引擎运行失败: {e}")
        
        # 返回对比报告
        return self._validator.compare()


# 全局API实例
_backtest_api = None

def get_backtest_api() -> BacktestAPI:
    """获取回测API实例"""
    global _backtest_api
    if _backtest_api is None:
        _backtest_api = BacktestAPI()
    return _backtest_api
