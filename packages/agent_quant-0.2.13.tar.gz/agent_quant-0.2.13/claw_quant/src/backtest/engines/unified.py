# -*- coding: utf-8 -*-
"""
统一回测引擎架构

提供多引擎支持的回测框架，包含：
1. 统一的数据输入结构 (BacktestInput)
2. 统一的数据输出结构 (BacktestOutput)
3. 引擎适配器基类 (BaseEngineAdapter)
4. 各平台具体适配器实现

所有引擎都通过DuckDBServer读取本地数据，各适配器负责：
- 参数转换：将统一参数转换为目标引擎格式
- 数据转换：从DuckDBServer读取数据并转换为目标引擎所需格式
- 结果转换：将引擎输出转换为统一格式
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Union, Tuple
import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)


class EngineType(Enum):
    """回测引擎类型"""
    LOCAL = "local"           # 本地轻量级引擎（默认）
    CSKHQUANT = "cskhquant"   # CSKhQuant框架
    JQDATA = "jqdata"         # 聚宽JQData
    VNPY = "vnpy"             # VNPY框架


@dataclass
class BacktestInput:
    """
    统一的回测输入参数结构
    
    所有引擎都使用此结构作为输入
    """
    # 基本参数
    factor_name: str                          # 因子名称
    code: str                                 # 股票代码
    start_date: Union[str, date, datetime]    # 开始日期
    end_date: Union[str, date, datetime]      # 结束日期
    
    # 资金参数
    init_capital: float = 1000000.0           # 初始资金
    
    # 因子参数
    factor_params: Optional[Dict[str, Any]] = field(default_factory=dict)
    
    # 交易成本参数
    commission_rate: float = 0.0003           # 佣金率
    min_commission: float = 5.0               # 最低佣金
    stamp_tax_rate: float = 0.001             # 印花税率（卖出）
    slippage: float = 0.001                   # 滑点
    
    # 回测控制参数
    benchmark: str = "000300.SH"              # 基准指数
    
    def normalize(self) -> 'BacktestInput':
        """标准化参数"""
        # 转换日期格式
        if isinstance(self.start_date, str):
            self.start_date = date.fromisoformat(self.start_date.replace('/', '-'))
        if isinstance(self.end_date, str):
            self.end_date = date.fromisoformat(self.end_date.replace('/', '-'))
        
        # 确保factor_params不为None
        if self.factor_params is None:
            self.factor_params = {}
            
        return self
    
    def get_date_range(self) -> Tuple[date, date]:
        """获取日期范围"""
        self.normalize()
        start = self.start_date
        end = self.end_date
        
        # 转换datetime为date
        if isinstance(start, datetime):
            start = start.date()
        if isinstance(end, datetime):
            end = end.date()
            
        return start, end


@dataclass
class TradeRecord:
    """交易记录"""
    trade_id: int
    date: str
    type: str  # 'buy' or 'sell'
    price: float
    shares: int
    amount: float
    commission: float
    reason: str
    profit: Optional[float] = None  # 卖出时记录盈亏
    stamp_tax: Optional[float] = None  # 卖出时记录印花税


@dataclass
class BacktestOutput:
    """
    统一的回测输出结果结构
    
    所有引擎都必须返回此结构
    """
    # 引擎信息
    engine_name: str                          # 使用的引擎名称
    
    # 输入参数（回显）
    factor_name: str
    code: str
    start_date: date
    end_date: date
    init_capital: float
    factor_params: Dict[str, Any]
    
    # 收益指标
    final_capital: float                      # 最终资金
    total_return: float                       # 总收益率
    annual_return: float                      # 年化收益率
    max_drawdown: float                       # 最大回撤
    sharpe_ratio: float                       # 夏普比率
    
    # 交易统计
    total_trades: int                         # 总交易次数
    winning_trades: int                       # 盈利次数
    losing_trades: int                        # 亏损次数
    win_rate: float                           # 胜率
    avg_profit: float = 0.0                   # 平均盈利
    avg_loss: float = 0.0                     # 平均亏损
    profit_factor: float = 0.0                # 盈亏比
    
    # 详细数据
    trades: List[Dict[str, Any]] = field(default_factory=list)
    daily_returns: Optional[pd.Series] = None
    equity_curve: Optional[pd.Series] = None
    
    # 原始结果（保留引擎特定数据，用于调试）
    raw_result: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式（用于返回给Agent）"""
        result = {
            'success': True,
            'engine_name': self.engine_name,
            'factor_name': self.factor_name,
            'code': self.code,
            'start_date': self.start_date.isoformat() if isinstance(self.start_date, date) else str(self.start_date),
            'end_date': self.end_date.isoformat() if isinstance(self.end_date, date) else str(self.end_date),
            'init_capital': self.init_capital,
            'factor_params': self.factor_params,
            'final_capital': round(self.final_capital, 2),
            'total_return': round(self.total_return, 4),
            'annual_return': round(self.annual_return, 4),
            'max_drawdown': round(self.max_drawdown, 4),
            'sharpe_ratio': round(self.sharpe_ratio, 2),
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'win_rate': round(self.win_rate, 4),
            'avg_profit': round(self.avg_profit, 2) if self.avg_profit else 0,
            'avg_loss': round(self.avg_loss, 2) if self.avg_loss else 0,
            'profit_factor': round(self.profit_factor, 2) if self.profit_factor else 0,
            'trades': self.trades,
        }
        return result


class BaseEngineAdapter(ABC):
    """
    回测引擎适配器基类
    
    所有具体引擎适配器都需要继承此类，实现：
    1. 参数转换：将BacktestInput转换为目标引擎格式
    2. 数据读取：从DuckDBServer读取数据并转换
    3. 执行回测：调用目标引擎
    4. 结果转换：将引擎输出转换为BacktestOutput
    """
    
    def __init__(self, name: str, engine_type: EngineType):
        self.name = name
        self.engine_type = engine_type
        self.logger = logging.getLogger(f"{__name__}.{name}")
    
    @abstractmethod
    def is_available(self) -> bool:
        """检查引擎是否可用"""
        pass
    
    @abstractmethod
    def run(self, input_params: BacktestInput) -> BacktestOutput:
        """
        运行回测
        
        Args:
            input_params: 统一的回测输入参数
            
        Returns:
            统一的回测输出结果
        """
        pass
    
    def _calculate_metrics(
        self,
        init_capital: float,
        final_capital: float,
        trades: List[Dict],
        daily_returns: List[float],
        dates: List[date]
    ) -> Dict[str, Any]:
        """
        计算绩效指标
        
        各引擎可以复用此方法进行指标计算
        """
        # 计算收益率
        total_return = (final_capital - init_capital) / init_capital if init_capital > 0 else 0
        
        # 计算年化收益率
        n_days = len(dates) if dates else 1
        annual_return = (1 + total_return) ** (252 / n_days) - 1 if n_days > 0 else 0
        
        # 计算最大回撤和夏普比率
        if daily_returns:
            returns_series = pd.Series(daily_returns, index=dates[:len(daily_returns)])
            cumulative = (1 + returns_series).cumprod()
            running_max = cumulative.expanding().max()
            drawdown = (cumulative - running_max) / running_max
            max_drawdown = drawdown.min()
            
            if returns_series.std() > 0:
                sharpe_ratio = returns_series.mean() / returns_series.std() * np.sqrt(252)
            else:
                sharpe_ratio = 0.0
        else:
            max_drawdown = 0.0
            sharpe_ratio = 0.0
        
        # 统计交易
        sell_trades = [t for t in trades if t.get('type') == 'sell']
        winning_trades_list = [t for t in sell_trades if t.get('profit', 0) > 0]
        losing_trades_list = [t for t in sell_trades if t.get('profit', 0) <= 0]
        
        win_rate = len(winning_trades_list) / len(sell_trades) if sell_trades else 0
        
        # 计算平均盈利和亏损
        profits = [t.get('profit', 0) for t in winning_trades_list]
        losses = [abs(t.get('profit', 0)) for t in losing_trades_list]
        
        avg_profit = np.mean(profits) if profits else 0
        avg_loss = np.mean(losses) if losses else 0
        profit_factor = sum(profits) / sum(losses) if losses and sum(losses) > 0 else float('inf') if profits else 0
        
        return {
            'final_capital': final_capital,
            'total_return': total_return,
            'annual_return': annual_return,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe_ratio,
            'total_trades': len(sell_trades),
            'winning_trades': len(winning_trades_list),
            'losing_trades': len(losing_trades_list),
            'win_rate': win_rate,
            'avg_profit': avg_profit,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
        }
    
    def _build_output(
        self,
        input_params: BacktestInput,
        trades: List[Dict],
        equity_curve: List[float],
        daily_returns: List[float],
        dates: List[date],
        raw_result: Optional[Dict] = None
    ) -> BacktestOutput:
        """
        构建统一输出结果
        """
        start_date, end_date = input_params.get_date_range()
        
        metrics = self._calculate_metrics(
            input_params.init_capital,
            equity_curve[-1] if equity_curve else input_params.init_capital,
            trades,
            daily_returns,
            dates
        )
        
        return BacktestOutput(
            engine_name=self.name,
            factor_name=input_params.factor_name,
            code=input_params.code,
            start_date=start_date,
            end_date=end_date,
            init_capital=input_params.init_capital,
            factor_params=input_params.factor_params or {},
            final_capital=metrics['final_capital'],
            total_return=metrics['total_return'],
            annual_return=metrics['annual_return'],
            max_drawdown=metrics['max_drawdown'],
            sharpe_ratio=metrics['sharpe_ratio'],
            total_trades=metrics['total_trades'],
            winning_trades=metrics['winning_trades'],
            losing_trades=metrics['losing_trades'],
            win_rate=metrics['win_rate'],
            avg_profit=metrics['avg_profit'],
            avg_loss=metrics['avg_loss'],
            profit_factor=metrics['profit_factor'],
            trades=trades,
            daily_returns=pd.Series(daily_returns) if daily_returns else None,
            equity_curve=pd.Series(equity_curve, index=dates[:len(equity_curve)]) if equity_curve else None,
            raw_result=raw_result
        )


class UnifiedBacktestEngine:
    """
    统一回测引擎管理器
    
    管理所有回测引擎适配器，提供统一的调用接口
    """
    
    def __init__(
        self,
        default_engine: EngineType = EngineType.LOCAL,
        engine_config: Optional[Dict[str, Any]] = None
    ):
        """
        初始化统一回测引擎
        
        Args:
            default_engine: 默认回测引擎类型
            engine_config: 引擎配置参数
        """
        self.default_engine = default_engine
        self.engine_config = engine_config or {}
        self._adapters: Dict[EngineType, BaseEngineAdapter] = {}
        
        # 延迟初始化适配器
        self._adapter_classes: Dict[EngineType, type] = {}
    
    def register_adapter(self, engine_type: EngineType, adapter_class: type):
        """
        注册引擎适配器
        
        Args:
            engine_type: 引擎类型
            adapter_class: 适配器类
        """
        self._adapter_classes[engine_type] = adapter_class
    
    def _get_adapter(self, engine_type: EngineType) -> Optional[BaseEngineAdapter]:
        """获取或创建适配器实例"""
        if engine_type not in self._adapters:
            adapter_class = self._adapter_classes.get(engine_type)
            if adapter_class:
                self._adapters[engine_type] = adapter_class(self.engine_config)
        
        return self._adapters.get(engine_type)
    
    def run(
        self,
        input_params: BacktestInput,
        engine_type: Optional[EngineType] = None
    ) -> BacktestOutput:
        """
        运行回测
        
        Args:
            input_params: 回测输入参数
            engine_type: 指定引擎类型（None则使用默认引擎）
            
        Returns:
            回测结果
        """
        # 标准化输入参数
        input_params.normalize()
        
        # 确定使用的引擎
        target_engine = engine_type or self.default_engine
        
        # 获取适配器
        adapter = self._get_adapter(target_engine)
        if not adapter:
            raise ValueError(f"未找到引擎适配器: {target_engine.value}")
        
        # 检查引擎可用性
        if not adapter.is_available():
            raise RuntimeError(f"引擎不可用: {target_engine.value}")
        
        # 运行回测
        return adapter.run(input_params)
    
    def get_available_engines(self) -> List[Dict[str, Any]]:
        """获取可用引擎列表"""
        engines = []
        
        for engine_type in EngineType:
            adapter = self._get_adapter(engine_type)
            if adapter:
                engines.append({
                    'type': engine_type.value,
                    'name': engine_type.name,
                    'available': adapter.is_available(),
                    'is_default': engine_type == self.default_engine
                })
        
        return engines


# 全局引擎实例
_unified_engine: Optional[UnifiedBacktestEngine] = None


def get_unified_engine(
    default_engine: EngineType = EngineType.LOCAL,
    engine_config: Optional[Dict[str, Any]] = None
) -> UnifiedBacktestEngine:
    """
    获取统一回测引擎实例（单例模式）
    """
    global _unified_engine
    
    if _unified_engine is None:
        _unified_engine = UnifiedBacktestEngine(default_engine, engine_config)
    
    return _unified_engine
