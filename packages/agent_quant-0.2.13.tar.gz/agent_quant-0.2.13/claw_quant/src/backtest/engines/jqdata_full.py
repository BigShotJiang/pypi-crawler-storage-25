# -*- coding: utf-8 -*-
"""
JQData回测引擎适配器
"""

import os
from typing import Dict, List, Optional, Any
from datetime import date, datetime
import pandas as pd
import numpy as np

from ..base import (
    BacktestEngine, 
    BacktestConfig, 
    BacktestResult, 
    TradeRecord,
    TradeDirection,
    OrderType
)


class JQDataEngine(BacktestEngine):
    """
    JQData回测引擎适配器
    
    使用聚宽(JQData)进行回测
    """
    
    def __init__(self, config: BacktestConfig, 
                 username: str = None, 
                 password: str = None):
        """
        初始化JQData引擎
        
        Args:
            config: 回测配置
            username: JQData账号
            password: JQData密码
        """
        super().__init__('JQData', config)
        self.username = username or os.environ.get('JQDATA_USERNAME')
        self.password = password or os.environ.get('JQDATA_PASSWORD')
        self._jq = None
        self._connected = False
        
    def is_available(self) -> bool:
        """检查JQData是否可用"""
        try:
            import jqdatasdk
            return True
        except ImportError:
            return False
    
    def _connect(self):
        """连接JQData"""
        if self._connected:
            return
            
        try:
            import jqdatasdk as jq
            self._jq = jq
            
            # 登录
            jq.auth(self.username, self.password)
            self._connected = True
            print(f"JQData登录成功: {self.username}")
            
        except Exception as e:
            raise RuntimeError(f"JQData登录失败: {e}")
    
    def _convert_code(self, code: str) -> str:
        """
        转换股票代码格式
        
        从 000001.SZ 转换为 000001.XSHE
        从 000001.SH 转换为 000001.XSHG
        """
        if '.' in code:
            symbol, exchange = code.split('.')
            if exchange.upper() == 'SZ':
                return f"{symbol}.XSHE"
            elif exchange.upper() == 'SH':
                return f"{symbol}.XSHG"
        return code
    
    def _convert_code_back(self, jq_code: str) -> str:
        """转换回标准格式"""
        if '.XSHE' in jq_code:
            return jq_code.replace('.XSHE', '.SZ')
        elif '.XSHG' in jq_code:
            return jq_code.replace('.XSHG', '.SH')
        return jq_code
    
    def run(self, strategy_code: str, **kwargs) -> BacktestResult:
        """
        运行回测
        
        Args:
            strategy_code: 策略代码（因子名称）
            **kwargs: 额外参数
        """
        if not self.is_available():
            raise RuntimeError("JQData SDK未安装，请运行: pip install jqdatasdk")
        
        # 连接
        self._connect()
        
        # 获取因子参数
        factor_params = kwargs.get('factor_params', {})
        
        # 转换日期格式
        start_date = self.config.start_date.strftime('%Y-%m-%d')
        end_date = self.config.end_date.strftime('%Y-%m-%d')
        
        # 获取股票池
        universe = self.config.universe if self.config.universe else ['000001.SZ']
        jq_codes = [self._convert_code(c) for c in universe]
        
        # 根据因子类型执行回测
        if strategy_code == 'CROSS':
            return self._run_cross_strategy(jq_codes, start_date, end_date, factor_params)
        elif strategy_code == 'MACD':
            return self._run_macd_strategy(jq_codes, start_date, end_date, factor_params)
        else:
            raise ValueError(f"不支持的因子类型: {strategy_code}")
    
    def _run_cross_strategy(self, codes: List[str], start_date: str, end_date: str, 
                           params: Dict[str, Any]) -> BacktestResult:
        """运行双均线交叉策略"""
        short_window = params.get('short_window', 5)
        long_window = params.get('long_window', 20)
        
        # 获取历史数据
        df = self._jq.get_price(
            codes[0],
            start_date=start_date,
            end_date=end_date,
            frequency='daily',
            fields=['open', 'high', 'low', 'close', 'volume']
        )
        
        if df.empty:
            raise RuntimeError(f"无法获取数据: {codes[0]}")
        
        # 计算均线
        df['ma_short'] = df['close'].rolling(window=short_window).mean()
        df['ma_long'] = df['close'].rolling(window=long_window).mean()
        
        # 生成信号
        df['signal'] = 0
        df.loc[df['ma_short'] > df['ma_long'], 'position'] = 1
        df.loc[df['ma_short'] <= df['ma_long'], 'position'] = 0
        df['position'] = df['position'].shift(1).fillna(0)  # 次日开盘执行
        
        # 计算收益
        df['returns'] = df['close'].pct_change()
        df['strategy_returns'] = df['position'] * df['returns']
        
        # 计算交易成本
        df['trade'] = df['position'].diff().abs()
        commission = self.config.commission_rate + self.config.stamp_tax_rate
        df['cost'] = df['trade'] * commission
        df['strategy_returns'] = df['strategy_returns'] - df['cost']
        
        # 计算累计收益
        df['cumulative'] = (1 + df['strategy_returns'].fillna(0)).cumprod()
        
        # 生成交易记录
        trades = []
        for idx, row in df.iterrows():
            if row['trade'] > 0:
                direction = TradeDirection.BUY if row['position'] > 0 else TradeDirection.SELL
                trades.append(TradeRecord(
                    trade_id=f"T{idx.strftime('%Y%m%d')}",
                    code=self._convert_code_back(codes[0]),
                    direction=direction,
                    price=row['open'],
                    volume=100,  # 简化处理，固定100股
                    amount=row['open'] * 100,
                    trade_date=idx.date(),
                    trade_time="09:30:00",
                    order_type=OrderType.MARKET,
                    commission=row['cost'] * self.config.init_capital if not pd.isna(row['cost']) else 0,
                    reason=f"{'金叉' if direction == TradeDirection.BUY else '死叉'}信号"
                ))
        
        # 计算绩效指标
        total_return = df['cumulative'].iloc[-1] - 1 if len(df) > 0 else 0
        daily_returns = df['strategy_returns'].dropna()
        
        # 年化收益率
        n_days = len(df)
        annual_return = (1 + total_return) ** (252 / n_days) - 1 if n_days > 0 else 0
        
        # 最大回撤
        cumulative = df['cumulative']
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # 夏普比率
        if daily_returns.std() > 0:
            sharpe_ratio = daily_returns.mean() / daily_returns.std() * np.sqrt(252)
        else:
            sharpe_ratio = 0
        
        # 交易统计
        total_trades = len(trades)
        winning_trades = 0
        for i, t in enumerate(trades):
            if t.direction == TradeDirection.SELL and i > 0:
                buy_price = trades[i-1].price if trades[i-1].direction == TradeDirection.BUY else 0
                if buy_price > 0 and t.price > buy_price:
                    winning_trades += 1
        
        return BacktestResult(
            engine_name=self.name,
            start_date=self.config.start_date,
            end_date=self.config.end_date,
            init_capital=self.config.init_capital,
            final_capital=self.config.init_capital * (1 + total_return),
            total_return=total_return,
            annual_return=annual_return,
            max_drawdown=max_drawdown,
            sharpe_ratio=sharpe_ratio,
            total_trades=total_trades,
            winning_trades=winning_trades,
            losing_trades=total_trades - winning_trades,
            win_rate=winning_trades / total_trades if total_trades > 0 else 0,
            avg_profit=0,  # 简化处理
            avg_loss=0,
            profit_factor=0,
            trades=trades,
            daily_returns=daily_returns,
            equity_curve=df['cumulative'] * self.config.init_capital,
            raw_result={'source': 'JQData', 'code': codes[0]}
        )
    
    def _run_macd_strategy(self, codes: List[str], start_date: str, end_date: str,
                          params: Dict[str, Any]) -> BacktestResult:
        """运行MACD策略"""
        fast = params.get('fast', 12)
        slow = params.get('slow', 26)
        signal = params.get('signal', 9)
        
        # 获取历史数据
        df = self._jq.get_price(
            codes[0],
            start_date=start_date,
            end_date=end_date,
            frequency='daily',
            fields=['open', 'high', 'low', 'close', 'volume']
        )
        
        if df.empty:
            raise RuntimeError(f"无法获取数据: {codes[0]}")
        
        # 计算MACD
        ema_fast = df['close'].ewm(span=fast, adjust=False).mean()
        ema_slow = df['close'].ewm(span=slow, adjust=False).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal, adjust=False).mean()
        histogram = macd_line - signal_line
        
        # 生成信号：MACD柱状图从负变正买入，从正变负卖出
        df['signal'] = 0
        df.loc[histogram > 0, 'position'] = 1
        df.loc[histogram <= 0, 'position'] = 0
        df['position'] = df['position'].shift(1).fillna(0)
        
        # 计算收益
        df['returns'] = df['close'].pct_change()
        df['strategy_returns'] = df['position'] * df['returns']
        
        # 计算成本
        df['trade'] = df['position'].diff().abs()
        commission = self.config.commission_rate + self.config.stamp_tax_rate
        df['cost'] = df['trade'] * commission
        df['strategy_returns'] = df['strategy_returns'] - df['cost']
        
        # 累计收益
        df['cumulative'] = (1 + df['strategy_returns'].fillna(0)).cumprod()
        
        # 生成交易记录
        trades = []
        for idx, row in df.iterrows():
            if row['trade'] > 0:
                direction = TradeDirection.BUY if row['position'] > 0 else TradeDirection.SELL
                trades.append(TradeRecord(
                    trade_id=f"T{idx.strftime('%Y%m%d')}",
                    code=self._convert_code_back(codes[0]),
                    direction=direction,
                    price=row['open'],
                    volume=100,
                    amount=row['open'] * 100,
                    trade_date=idx.date(),
                    trade_time="09:30:00",
                    order_type=OrderType.MARKET,
                    commission=row['cost'] * self.config.init_capital if not pd.isna(row['cost']) else 0,
                    reason=f"{'MACD金叉' if direction == TradeDirection.BUY else 'MACD死叉'}"
                ))
        
        # 计算绩效指标
        total_return = df['cumulative'].iloc[-1] - 1 if len(df) > 0 else 0
        daily_returns = df['strategy_returns'].dropna()
        
        n_days = len(df)
        annual_return = (1 + total_return) ** (252 / n_days) - 1 if n_days > 0 else 0
        
        cumulative = df['cumulative']
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_drawdown = drawdown.min()
        
        if daily_returns.std() > 0:
            sharpe_ratio = daily_returns.mean() / daily_returns.std() * np.sqrt(252)
        else:
            sharpe_ratio = 0
        
        total_trades = len(trades)
        winning_trades = 0
        for i, t in enumerate(trades):
            if t.direction == TradeDirection.SELL and i > 0:
                buy_price = trades[i-1].price if trades[i-1].direction == TradeDirection.BUY else 0
                if buy_price > 0 and t.price > buy_price:
                    winning_trades += 1
        
        return BacktestResult(
            engine_name=self.name,
            start_date=self.config.start_date,
            end_date=self.config.end_date,
            init_capital=self.config.init_capital,
            final_capital=self.config.init_capital * (1 + total_return),
            total_return=total_return,
            annual_return=annual_return,
            max_drawdown=max_drawdown,
            sharpe_ratio=sharpe_ratio,
            total_trades=total_trades,
            winning_trades=winning_trades,
            losing_trades=total_trades - winning_trades,
            win_rate=winning_trades / total_trades if total_trades > 0 else 0,
            avg_profit=0,
            avg_loss=0,
            profit_factor=0,
            trades=trades,
            daily_returns=daily_returns,
            equity_curve=df['cumulative'] * self.config.init_capital,
            raw_result={'source': 'JQData', 'code': codes[0]}
        )
