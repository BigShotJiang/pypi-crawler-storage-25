# -*- coding: utf-8 -*-
"""
CSKhQuant回测引擎适配器
"""

import os
import sys
import json
import tempfile
from typing import Dict, List, Optional, Any
from datetime import date
import pandas as pd
import numpy as np

from ..base import (
    BacktestEngine, 
    BacktestConfig, 
    BacktestResult, 
    TradeRecord,
    TradeDirection,
    OrderType
)


class CSKhQuantEngine(BacktestEngine):
    """
    CSKhQuant回测引擎适配器
    
    将CSKhQuant框架适配到我们的标准化回测接口
    """
    
    def __init__(self, config: BacktestConfig, 
                 cskhquant_path: str = None,
                 data_source: str = 'duckdb',
                 duckdb_path: str = None):
        """
        初始化CSKhQuant引擎
        
        Args:
            config: 回测配置
            cskhquant_path: CSKhQuant框架路径
            data_source: 数据源 ('xtdata' 或 'duckdb')
            duckdb_path: DuckDB数据库路径
        """
        super().__init__('CSKhQuant', config)
        self.cskhquant_path = cskhquant_path or os.path.join(
            os.path.dirname(__file__), '..', '..', '..', 'CSkhQuant'
        )
        self.data_source = data_source
        self.duckdb_path = duckdb_path
        self._framework = None
        
    def is_available(self) -> bool:
        """检查CSKhQuant是否可用"""
        try:
            sys.path.insert(0, self.cskhquant_path)
            from khFrame import KhQuantFramework
            return True
        except ImportError:
            return False
    
    def _create_strategy_file(self, factor_name: str, params: Dict[str, Any]) -> str:
        """
        创建策略文件
        
        根据因子名称和参数生成CSKhQuant策略代码
        """
        # 根据因子类型生成策略代码
        if factor_name == 'CROSS':
            short_window = params.get('short_window', 5)
            long_window = params.get('long_window', 20)
            
            strategy_code = f'''
# coding: utf-8
from khQuantImport import *

params = {{
    'short_window': {short_window},
    'long_window': {long_window},
}}

def init(stocks=None, data=None):
    logging.info(f"=== 双均线交叉策略启动 ===")
    logging.info(f"参数: 短期={{params['short_window']}}日, 长期={{params['long_window']}}日")

def khHandlebar(data: Dict) -> List[Dict]:
    signals = []
    stock_code = khGet(data, "first_stock")
    current_price = khPrice(data, stock_code, "open")
    current_date_str = khGet(data, "date_num")
    
    short_win = params['short_window']
    long_win = params['long_window']
    
    ma_short = khMA(stock_code, short_win, end_time=current_date_str)
    ma_long = khMA(stock_code, long_win, end_time=current_date_str)
    
    has_position = khHas(data, stock_code)
    
    if ma_short > ma_long and not has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'buy', 
                                  f"{{short_win}}日线上穿{{long_win}}日线，全仓买入")
    elif ma_short < ma_long and has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'sell',
                                  f"{{short_win}}日线下穿{{long_win}}日线，全仓卖出")
    
    return signals
'''
        elif factor_name == 'MACD':
            fast = params.get('fast', 12)
            slow = params.get('slow', 26)
            signal = params.get('signal', 9)
            
            strategy_code = f'''
# coding: utf-8
from khQuantImport import *

params = {{
    'fast': {fast},
    'slow': {slow},
    'signal': {signal},
}}

def init(stocks=None, data=None):
    logging.info(f"=== MACD策略启动 ===")

def khHandlebar(data: Dict) -> List[Dict]:
    signals = []
    stock_code = khGet(data, "first_stock")
    current_price = khPrice(data, stock_code, "open")
    current_date_str = khGet(data, "date_num")
    
    # 获取MACD指标
    hist = khMACD(stock_code, params['fast'], params['slow'], params['signal'], 
                  end_time=current_date_str)
    hist_prev = khMACD(stock_code, params['fast'], params['slow'], params['signal'],
                       end_time=current_date_str, offset=1)
    
    has_position = khHas(data, stock_code)
    
    # MACD金叉：hist从负变正
    if hist > 0 and hist_prev <= 0 and not has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'buy',
                                  "MACD金叉，全仓买入")
    # MACD死叉：hist从正变负
    elif hist < 0 and hist_prev >= 0 and has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'sell',
                                  "MACD死叉，全仓卖出")
    
    return signals
'''
        else:
            raise ValueError(f"不支持的因子类型: {factor_name}")
        
        # 写入临时文件
        fd, path = tempfile.mkstemp(suffix='.py')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(strategy_code)
        return path
    
    def _create_config_file(self, strategy_file: str) -> str:
        """创建回测配置文件"""
        config = {
            "system": {
                "userdata_path": os.environ.get('QMT_PATH', 'C:/国金证券QMT交易端/userdata_mini')
            },
            "run_mode": "backtest",
            "account": {
                "account_id": "88888888",
                "account_type": "STOCK"
            },
            "strategy_file": strategy_file,
            "data_mode": "custom",
            "backtest": {
                "start_time": self.config.start_date.strftime('%Y%m%d'),
                "end_time": self.config.end_date.strftime('%Y%m%d'),
                "init_capital": self.config.init_capital,
                "min_volume": 100,
                "benchmark": self.config.benchmark.replace('.SH', '.000300').replace('.SZ', '.399001'),
                "trade_cost": {
                    "min_commission": self.config.min_commission,
                    "commission_rate": self.config.commission_rate,
                    "stamp_tax_rate": self.config.stamp_tax_rate,
                    "flow_fee": 0.0,
                    "slippage": {
                        "type": "ratio",
                        "tick_size": 0.01,
                        "tick_count": 2,
                        "ratio": self.config.slippage
                    }
                },
                "trigger": {
                    "type": "1d",
                    "custom_times": ["09:30:00"],
                    "start_time": "09:30:00",
                    "end_time": "15:00:00",
                    "interval": 300
                }
            },
            "data": {
                "kline_period": "1d",
                "dividend_type": "front",
                "fields": ["open", "high", "low", "close", "volume", "amount"]
            },
            "universe": self.config.universe if self.config.universe else ["000001.SZ"]
        }
        
        fd, path = tempfile.mkstemp(suffix='.kh')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return path
    
    def run(self, strategy_code: str, **kwargs) -> BacktestResult:
        """
        运行回测
        
        Args:
            strategy_code: 策略代码（因子名称，如 'CROSS', 'MACD'）
            **kwargs: 额外参数，如 factor_params 等
        """
        if not self.is_available():
            raise RuntimeError("CSKhQuant框架不可用")
        
        # 导入CSKhQuant
        sys.path.insert(0, self.cskhquant_path)
        from khFrame import KhQuantFramework, MyTraderCallback
        
        # 获取因子参数
        factor_params = kwargs.get('factor_params', {})
        
        # 创建策略文件
        strategy_file = self._create_strategy_file(strategy_code, factor_params)
        
        try:
            # 创建配置文件
            config_file = self._create_config_file(strategy_file)
            
            try:
                # 设置回测参数
                ui_settings = {
                    'backtest_data_source': self.data_source,
                    'duckdb_data_path': self.duckdb_path or 'I:/khData',
                    'init_data_enabled': False,
                    'volume_limit_enabled': False,
                    'participation_rate': 0.1,
                    'allow_partial_fill': True,
                }
                
                # 运行回测
                callback = MyTraderCallback(gui=None)
                framework = KhQuantFramework(
                    config_file,
                    strategy_file,
                    trader_callback=callback,
                    ui_settings=ui_settings
                )
                framework.run()
                
                # 解析回测结果
                return self._parse_result(framework)
                
            finally:
                os.unlink(config_file)
        finally:
            os.unlink(strategy_file)
    
    def _parse_result(self, framework) -> BacktestResult:
        """解析CSKhQuant回测结果"""
        # 从framework获取回测结果
        # 这里需要根据实际CSKhQuant的输出格式调整
        
        # 获取回测目录
        import glob
        backtest_dirs = glob.glob(os.path.join("backtest_results", "*"))
        if not backtest_dirs:
            raise RuntimeError("未找到回测结果目录")
        
        latest_dir = max(backtest_dirs, key=os.path.getmtime)
        
        # 读取summary
        summary_path = os.path.join(latest_dir, "summary.csv")
        if os.path.exists(summary_path):
            summary = pd.read_csv(summary_path).iloc[0].to_dict()
        else:
            summary = {}
        
        # 读取交易记录
        trades_path = os.path.join(latest_dir, "trades.csv")
        trades = []
        if os.path.exists(trades_path):
            trades_df = pd.read_csv(trades_path)
            for _, row in trades_df.iterrows():
                trades.append(TradeRecord(
                    trade_id=str(row.get('trade_id', '')),
                    code=row.get('code', ''),
                    direction=TradeDirection.BUY if row.get('direction') == 'buy' else TradeDirection.SELL,
                    price=row.get('price', 0.0),
                    volume=int(row.get('volume', 0)),
                    amount=row.get('amount', 0.0),
                    trade_date=pd.to_datetime(row.get('trade_date')).date(),
                    trade_time=row.get('trade_time'),
                    commission=row.get('commission', 0.0),
                    reason=row.get('reason', '')
                ))
        
        # 读取权益曲线
        equity_path = os.path.join(latest_dir, "equity_curve.csv")
        equity_curve = pd.Series()
        if os.path.exists(equity_path):
            equity_df = pd.read_csv(equity_path)
            equity_curve = pd.Series(
                equity_df['equity'].values,
                index=pd.to_datetime(equity_df['date'])
            )
        
        # 计算日收益率
        daily_returns = equity_curve.pct_change().dropna() if len(equity_curve) > 0 else pd.Series()
        
        # 构建结果
        return BacktestResult(
            engine_name=self.name,
            start_date=self.config.start_date,
            end_date=self.config.end_date,
            init_capital=self.config.init_capital,
            final_capital=summary.get('final_capital', self.config.init_capital),
            total_return=summary.get('total_return', 0.0),
            annual_return=summary.get('annual_return', 0.0),
            max_drawdown=summary.get('max_drawdown', 0.0),
            sharpe_ratio=summary.get('sharpe_ratio', 0.0),
            total_trades=int(summary.get('total_trades', 0)),
            winning_trades=int(summary.get('winning_trades', 0)),
            losing_trades=int(summary.get('losing_trades', 0)),
            win_rate=summary.get('win_rate', 0.0),
            avg_profit=summary.get('avg_profit', 0.0),
            avg_loss=summary.get('avg_loss', 0.0),
            profit_factor=summary.get('profit_factor', 0.0),
            trades=trades,
            daily_returns=daily_returns,
            equity_curve=equity_curve,
            raw_result=summary
        )
