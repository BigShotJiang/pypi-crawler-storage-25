# -*- coding: utf-8 -*-
"""
CSKhQuant简化回测引擎

不依赖khFrame/PyQt5，直接使用StockAPI从数据库获取数据进行回测
"""

import os
import sys
from typing import Dict, List, Optional, Any
from datetime import date, datetime
import pandas as pd
import numpy as np

from ..base import (
    BacktestEngine, 
    BacktestConfig, 
    BacktestResult, 
    TradeRecord,
    TradeDirection,
    OrderType
)


class CSKhQuantSimpleEngine(BacktestEngine):
    """
    CSKhQuant简化回测引擎
    
    直接使用StockAPI从数据库获取数据进行回测，不依赖khFrame
    """
    
    def __init__(self, config: BacktestConfig):
        """
        初始化简化引擎
        
        Args:
            config: 回测配置
        """
        super().__init__('CSKhQuant', config)
        self._api = None
        
    def is_available(self) -> bool:
        """检查是否可用（需要StockAPI和数据库连接）"""
        try:
            from ....database.api import StockAPI
             api = StockAPI()
             return api.ping()
         except Exception:
             return False
     
     def _get_api(self):
         """获取StockAPI实例"""
         if self._api is None:
             from ....database.api import StockAPI
             self._api = StockAPI()
        return self._api
    
    def _get_stock_data(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """从数据库获取股票数据"""
        api = self._get_api()
        
        # 使用StockAPI获取数据
        df = api.get_daily(code, start_date, end_date)
        
        if df is None or len(df) == 0:
            raise ValueError(f"无法获取股票{code}的数据")
        
        # 确保日期列为索引
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
        
        return df
    
    def _run_cross_strategy(self, code: str, start_date: date, end_date: date, 
                           params: Dict) -> BacktestResult:
        """运行均线交叉策略"""
        short_window = params.get('short_window', 5)
        long_window = params.get('long_window', 20)
        
        # 获取数据（需要额外获取历史数据用于计算均线）
        # 扩展日期范围以计算均线
        extended_start = date.fromordinal(start_date.toordinal() - long_window * 2)
        df = self._get_stock_data(code, extended_start, end_date)
        
        if len(df) < long_window + 5:
            raise ValueError(f"数据不足，需要至少{long_window + 5}个交易日")
        
        # 计算均线
        df['ma_short'] = df['close'].rolling(window=short_window).mean()
        df['ma_long'] = df['close'].rolling(window=long_window).mean()
        
        # 截取回测期间的数据
        df = df[df.index >= pd.Timestamp(start_date)]
        
        if len(df) == 0:
            raise ValueError(f"回测期间没有数据")
        
        # 生成信号
        df['signal'] = 0
        df['position'] = 0
        df['trade'] = 0
        
        position = 0
        trades = []
        trade_id = 0
        
        for i in range(1, len(df)):
            date_idx = df.index[i]
            prev_date_idx = df.index[i-1]
            
            ma_short_curr = df['ma_short'].iloc[i]
            ma_long_curr = df['ma_long'].iloc[i]
            ma_short_prev = df['ma_short'].iloc[i-1]
            ma_long_prev = df['ma_long'].iloc[i-1]
            
            # 跳过NaN值
            if pd.isna(ma_short_curr) or pd.isna(ma_long_curr):
                continue
            
            price = df['open'].iloc[i]
            
            # 金叉：短期上穿长期
            if ma_short_prev <= ma_long_prev and ma_short_curr > ma_long_curr and position == 0:
                position = 1
                trade_id += 1
                trades.append(TradeRecord(
                    trade_id=f"T{trade_id:03d}",
                    code=code,
                    direction=TradeDirection.BUY,
                    price=price,
                    volume=100,
                    amount=price * 100,
                    trade_date=date_idx.date(),
                    trade_time="09:30:00",
                    order_type=OrderType.MARKET,
                    commission=price * 100 * 0.0003,
                    reason=f"{short_window}日线上穿{long_window}日线，金叉买入"
                ))
                df.loc[date_idx, 'trade'] = 1
            
            # 死叉：短期下穿长期
            elif ma_short_prev >= ma_long_prev and ma_short_curr < ma_long_curr and position == 1:
                position = 0
                trade_id += 1
                trades.append(TradeRecord(
                    trade_id=f"T{trade_id:03d}",
                    code=code,
                    direction=TradeDirection.SELL,
                    price=price,
                    volume=100,
                    amount=price * 100,
                    trade_date=date_idx.date(),
                    trade_time="09:30:00",
                    order_type=OrderType.MARKET,
                    commission=price * 100 * 0.0003 + price * 100 * 0.001,  # 佣金+印花税
                    reason=f"{short_window}日线下穿{long_window}日线，死叉卖出"
                ))
                df.loc[date_idx, 'trade'] = -1
            
            df.loc[date_idx, 'position'] = position
        
        # 计算策略收益
        df['returns'] = df['close'].pct_change()
        df['strategy_returns'] = df['returns'] * df['position'].shift(1)
        df['cumulative'] = (1 + df['strategy_returns']).cumprod()
        df['cumulative'] = df['cumulative'].fillna(1)
        
        # 计算绩效指标
        total_return = df['cumulative'].iloc[-1] - 1 if len(df) > 0 else 0
        daily_returns = df['strategy_returns'].dropna()
        
        n_days = len(df)
        annual_return = (1 + total_return) ** (252 / n_days) - 1 if n_days > 0 else 0
        
        cumulative = df['cumulative']
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_drawdown = drawdown.min()
        
        if daily_returns.std() > 0:
            sharpe_ratio = daily_returns.mean() / daily_returns.std() * np.sqrt(252)
        else:
            sharpe_ratio = 0
        
        # 交易统计
        total_trades = len(trades)
        winning_trades = 0
        for i, t in enumerate(trades):
            if t.direction == TradeDirection.SELL and i > 0:
                buy_price = trades[i-1].price if trades[i-1].direction == TradeDirection.BUY else 0
                if buy_price > 0 and t.price > buy_price:
                    winning_trades += 1
        
        return BacktestResult(
            engine_name=self.name,
            start_date=self.config.start_date,
            end_date=self.config.end_date,
            init_capital=self.config.init_capital,
            final_capital=self.config.init_capital * (1 + total_return),
            total_return=total_return,
            annual_return=annual_return,
            max_drawdown=max_drawdown,
            sharpe_ratio=sharpe_ratio,
            total_trades=total_trades,
            winning_trades=winning_trades,
            losing_trades=total_trades - winning_trades,
            win_rate=winning_trades / total_trades if total_trades > 0 else 0,
            avg_profit=0,
            avg_loss=0,
            profit_factor=0,
            trades=trades,
            daily_returns=daily_returns,
            equity_curve=df['cumulative'] * self.config.init_capital,
            raw_result={'source': 'CSKhQuant-Simple', 'code': code}
        )
    
    def run(self, strategy_code: str, **kwargs) -> BacktestResult:
        """
        运行回测
        
        Args:
            strategy_code: 策略代码（因子名称）
            **kwargs: 额外参数
        """
        if not self.is_available():
            raise RuntimeError("数据库连接失败，请确保数据库服务已启动")
        
        factor_params = kwargs.get('factor_params', {})
        
        # 获取股票池
        universe = self.config.universe if self.config.universe else ['000001.SZ']
        code = universe[0]
        
        # 根据因子类型执行回测
        if strategy_code == 'CROSS':
            return self._run_cross_strategy(code, self.config.start_date, self.config.end_date, factor_params)
        else:
            raise ValueError(f"不支持的因子类型: {strategy_code}")
