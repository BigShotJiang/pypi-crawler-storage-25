# -*- coding: utf-8 -*-
"""
本地回测引擎适配器

基于StockAPI的轻量级回测引擎，直接从DuckDBServer读取数据
作为默认引擎使用
"""

from datetime import date, timedelta
from typing import Dict, Any, List
import pandas as pd
import numpy as np

from .unified import BaseEngineAdapter, BacktestInput, BacktestOutput, EngineType
from ....database.api import StockAPI


class LocalEngineAdapter(BaseEngineAdapter):
    """
    本地回测引擎适配器
    
    特点：
    - 基于StockAPI直接读取DuckDBServer数据
    - 轻量级，无需外部依赖
    - 支持CROSS、MACD、MA、RSI等因子
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__('local', EngineType.LOCAL)
        config = config or {}
        host = config.get('host', '127.0.0.1')
        port = config.get('port', 9529)
        self.stock_api = StockAPI(host=host, port=port)
    
    def get_name(self) -> str:
        """获取引擎名称"""
        return "本地回测引擎"
    
    def get_description(self) -> str:
        """获取引擎描述"""
        return "基于StockAPI的轻量级回测引擎，直接从DuckDBServer读取数据"
    
    def is_available(self) -> bool:
        """检查本地引擎是否可用"""
        try:
            return self.stock_api.ping()
        except:
            return False
    
    def run(self, input_params: BacktestInput) -> BacktestOutput:
        """运行本地回测"""
        start_date, end_date = input_params.get_date_range()
        factor_name = input_params.factor_name
        factor_params = input_params.factor_params or {}
        
        # 根据因子类型调用对应的回测方法
        if factor_name == 'CROSS':
            return self._run_cross(input_params, start_date, end_date, factor_params)
        elif factor_name == 'MACD':
            return self._run_macd(input_params, start_date, end_date, factor_params)
        elif factor_name == 'MA':
            return self._run_ma(input_params, start_date, end_date, factor_params)
        elif factor_name == 'RSI':
            return self._run_rsi(input_params, start_date, end_date, factor_params)
        else:
            raise ValueError(f"本地引擎不支持的因子类型: {factor_name}")
    
    def _run_cross(
        self,
        input_params: BacktestInput,
        start_date: date,
        end_date: date,
        params: Dict[str, Any]
    ) -> BacktestOutput:
        """运行均线交叉回测"""
        short_window = params.get('short_window', 5)
        long_window = params.get('long_window', 20)
        code = input_params.code
        init_capital = input_params.init_capital
        
        # 扩展日期范围以计算均线
        extended_start = date.fromordinal(start_date.toordinal() - long_window * 2)
        
        # 从DuckDBServer获取数据
        df = self.stock_api.get_daily(code, extended_start, end_date)
        
        if df is None or len(df) < long_window + 5:
            raise ValueError(f"数据不足，需要至少{long_window + 5}个交易日")
        
        # 确保日期列为索引
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
        
        # 计算均线
        df['ma_short'] = df['close'].rolling(window=short_window).mean()
        df['ma_long'] = df['close'].rolling(window=long_window).mean()
        
        # 截取回测期间的数据
        df_backtest = df[df.index >= pd.Timestamp(start_date)].copy()
        
        if len(df_backtest) == 0:
            raise ValueError("回测期间没有数据")
        
        # 生成交易信号
        trades = []
        trade_id = 0
        equity = init_capital
        position = 0
        position_shares = 0
        equity_curve = [equity]
        daily_returns = []
        dates = [df_backtest.index[0]]
        
        for i in range(1, len(df_backtest)):
            date_idx = df_backtest.index[i]
            
            # 获取当前和前一天的均线值
            curr_idx = df.index.get_loc(date_idx)
            ma_short_curr = df['ma_short'].iloc[curr_idx]
            ma_long_curr = df['ma_long'].iloc[curr_idx]
            ma_short_prev = df['ma_short'].iloc[curr_idx - 1]
            ma_long_prev = df['ma_long'].iloc[curr_idx - 1]
            
            # 跳过NaN值
            if pd.isna(ma_short_curr) or pd.isna(ma_long_curr):
                self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
                continue
            
            price = df_backtest['open'].iloc[i]
            
            # 金叉买入
            if ma_short_prev <= ma_long_prev and ma_short_curr > ma_long_curr and position == 0:
                position, trade_id, position_shares, equity = self._execute_buy(
                    trades, trade_id, date_idx, price, equity, input_params,
                    f'{short_window}日线上穿{long_window}日线，金叉买入'
                )
            
            # 死叉卖出
            elif ma_short_prev >= ma_long_prev and ma_short_curr < ma_long_curr and position == 1:
                position, trade_id, position_shares, equity = self._execute_sell(
                    trades, trade_id, date_idx, price, equity, position_shares, input_params,
                    f'{short_window}日线下穿{long_window}日线，死叉卖出'
                )
            
            self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
        
        return self._build_output(input_params, trades, equity_curve, daily_returns, dates)
    
    def _run_macd(
        self,
        input_params: BacktestInput,
        start_date: date,
        end_date: date,
        params: Dict[str, Any]
    ) -> BacktestOutput:
        """运行MACD回测"""
        fast = params.get('fast', 12)
        slow = params.get('slow', 26)
        signal_period = params.get('signal', 9)
        code = input_params.code
        init_capital = input_params.init_capital
        
        # 扩展日期范围
        extended_start = date.fromordinal(start_date.toordinal() - slow * 2)
        
        # 从DuckDBServer获取数据
        df = self.stock_api.get_daily(code, extended_start, end_date)
        
        if df is None or len(df) < slow + 10:
            raise ValueError(f"数据不足，需要至少{slow + 10}个交易日")
        
        # 确保日期列为索引
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
        
        # 计算MACD
        exp1 = df['close'].ewm(span=fast, adjust=False).mean()
        exp2 = df['close'].ewm(span=slow, adjust=False).mean()
        df['macd'] = exp1 - exp2
        df['signal'] = df['macd'].ewm(span=signal_period, adjust=False).mean()
        df['hist'] = df['macd'] - df['signal']
        
        # 截取回测期间的数据
        df_backtest = df[df.index >= pd.Timestamp(start_date)].copy()
        
        if len(df_backtest) == 0:
            raise ValueError("回测期间没有数据")
        
        # 生成交易信号
        trades = []
        trade_id = 0
        equity = init_capital
        position = 0
        position_shares = 0
        equity_curve = [equity]
        daily_returns = []
        dates = [df_backtest.index[0]]
        
        for i in range(1, len(df_backtest)):
            date_idx = df_backtest.index[i]
            
            # 获取当前和前一天的MACD值
            curr_idx = df.index.get_loc(date_idx)
            hist_curr = df['hist'].iloc[curr_idx]
            hist_prev = df['hist'].iloc[curr_idx - 1]
            
            # 跳过NaN值
            if pd.isna(hist_curr) or pd.isna(hist_prev):
                self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
                continue
            
            price = df_backtest['open'].iloc[i]
            
            # MACD金叉（hist由负转正）
            if hist_prev <= 0 and hist_curr > 0 and position == 0:
                position, trade_id, position_shares, equity = self._execute_buy(
                    trades, trade_id, date_idx, price, equity, input_params, 'MACD金叉买入'
                )
            
            # MACD死叉（hist由正转负）
            elif hist_prev >= 0 and hist_curr < 0 and position == 1:
                position, trade_id, position_shares, equity = self._execute_sell(
                    trades, trade_id, date_idx, price, equity, position_shares, input_params, 'MACD死叉卖出'
                )
            
            self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
        
        return self._build_output(input_params, trades, equity_curve, daily_returns, dates)
    
    def _run_ma(
        self,
        input_params: BacktestInput,
        start_date: date,
        end_date: date,
        params: Dict[str, Any]
    ) -> BacktestOutput:
        """运行MA回测（价格突破均线）"""
        window = params.get('window', 20)
        field = params.get('field', 'close')
        code = input_params.code
        init_capital = input_params.init_capital
        
        # 扩展日期范围
        extended_start = date.fromordinal(start_date.toordinal() - window * 2)
        
        # 从DuckDBServer获取数据
        df = self.stock_api.get_daily(code, extended_start, end_date)
        
        if df is None or len(df) < window + 5:
            raise ValueError(f"数据不足，需要至少{window + 5}个交易日")
        
        # 确保日期列为索引
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
        
        # 计算均线
        df['ma'] = df[field].rolling(window=window).mean()
        
        # 截取回测期间的数据
        df_backtest = df[df.index >= pd.Timestamp(start_date)].copy()
        
        if len(df_backtest) == 0:
            raise ValueError("回测期间没有数据")
        
        # 生成交易信号
        trades = []
        trade_id = 0
        equity = init_capital
        position = 0
        position_shares = 0
        equity_curve = [equity]
        daily_returns = []
        dates = [df_backtest.index[0]]
        
        for i in range(1, len(df_backtest)):
            date_idx = df_backtest.index[i]
            
            # 获取当前和前一天的值
            curr_idx = df.index.get_loc(date_idx)
            price_curr = df[field].iloc[curr_idx]
            ma_curr = df['ma'].iloc[curr_idx]
            price_prev = df[field].iloc[curr_idx - 1]
            ma_prev = df['ma'].iloc[curr_idx - 1]
            
            # 跳过NaN值
            if pd.isna(ma_curr):
                self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
                continue
            
            price = df_backtest['open'].iloc[i]
            
            # 价格上穿均线买入
            if price_prev <= ma_prev and price_curr > ma_curr and position == 0:
                position, trade_id, position_shares, equity = self._execute_buy(
                    trades, trade_id, date_idx, price, equity, input_params,
                    f'价格突破{window}日均线买入'
                )
            
            # 价格下穿均线卖出
            elif price_prev >= ma_prev and price_curr < ma_curr and position == 1:
                position, trade_id, position_shares, equity = self._execute_sell(
                    trades, trade_id, date_idx, price, equity, position_shares, input_params,
                    f'价格跌破{window}日均线卖出'
                )
            
            self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
        
        return self._build_output(input_params, trades, equity_curve, daily_returns, dates)
    
    def _run_rsi(
        self,
        input_params: BacktestInput,
        start_date: date,
        end_date: date,
        params: Dict[str, Any]
    ) -> BacktestOutput:
        """运行RSI回测"""
        window = params.get('window', 14)
        overbought = params.get('overbought', 70)
        oversold = params.get('oversold', 30)
        code = input_params.code
        init_capital = input_params.init_capital
        
        # 扩展日期范围
        extended_start = date.fromordinal(start_date.toordinal() - window * 2)
        
        # 从DuckDBServer获取数据
        df = self.stock_api.get_daily(code, extended_start, end_date)
        
        if df is None or len(df) < window + 5:
            raise ValueError(f"数据不足，需要至少{window + 5}个交易日")
        
        # 确保日期列为索引
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
        
        # 计算RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # 截取回测期间的数据
        df_backtest = df[df.index >= pd.Timestamp(start_date)].copy()
        
        if len(df_backtest) == 0:
            raise ValueError("回测期间没有数据")
        
        # 生成交易信号
        trades = []
        trade_id = 0
        equity = init_capital
        position = 0
        position_shares = 0
        equity_curve = [equity]
        daily_returns = []
        dates = [df_backtest.index[0]]
        
        for i in range(1, len(df_backtest)):
            date_idx = df_backtest.index[i]
            
            # 获取当前和前一天的RSI值
            curr_idx = df.index.get_loc(date_idx)
            rsi_curr = df['rsi'].iloc[curr_idx]
            rsi_prev = df['rsi'].iloc[curr_idx - 1]
            
            # 跳过NaN值
            if pd.isna(rsi_curr):
                self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
                continue
            
            price = df_backtest['open'].iloc[i]
            
            # RSI从超卖区回升买入
            if rsi_prev <= oversold and rsi_curr > oversold and position == 0:
                position, trade_id, position_shares, equity = self._execute_buy(
                    trades, trade_id, date_idx, price, equity, input_params,
                    f'RSI({window})从超卖区({oversold})回升买入'
                )
            
            # RSI从超买区回落卖出
            elif rsi_prev >= overbought and rsi_curr < overbought and position == 1:
                position, trade_id, position_shares, equity = self._execute_sell(
                    trades, trade_id, date_idx, price, equity, position_shares, input_params,
                    f'RSI({window})从超买区({overbought})回落卖出'
                )
            
            self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df_backtest, i, date_idx)
        
        return self._build_output(input_params, trades, equity_curve, daily_returns, dates)
    
    def _execute_buy(
        self,
        trades: List[Dict],
        trade_id: int,
        date_idx: pd.Timestamp,
        price: float,
        equity: float,
        input_params: BacktestInput,
        reason: str
    ) -> tuple:
        """执行买入操作"""
        trade_id += 1
        shares = int(equity / price / 100) * 100  # 整手买入
        cost = shares * price * (1 + input_params.commission_rate)
        
        if cost <= equity:
            trades.append({
                'id': trade_id,
                'date': date_idx.strftime('%Y-%m-%d'),
                'type': 'buy',
                'price': round(price, 2),
                'shares': shares,
                'amount': round(shares * price, 2),
                'commission': round(shares * price * input_params.commission_rate, 2),
                'reason': reason
            })
            equity -= cost
            return 1, trade_id, shares, equity
        
        return 0, trade_id, 0, equity
    
    def _execute_sell(
        self,
        trades: List[Dict],
        trade_id: int,
        date_idx: pd.Timestamp,
        price: float,
        equity: float,
        position_shares: int,
        input_params: BacktestInput,
        reason: str
    ) -> tuple:
        """执行卖出操作"""
        trade_id += 1
        if position_shares > 0:
            revenue = position_shares * price * (1 - input_params.commission_rate - input_params.stamp_tax_rate)
            commission = position_shares * price * input_params.commission_rate
            stamp_tax = position_shares * price * input_params.stamp_tax_rate
            
            # 查找对应的买入记录计算盈亏
            buy_trade = None
            for t in reversed(trades):
                if t['type'] == 'buy':
                    buy_trade = t
                    break
            
            if buy_trade:
                profit = revenue - (position_shares * buy_trade['price']) - buy_trade['commission'] - commission - stamp_tax
            else:
                profit = 0
            
            trades.append({
                'id': trade_id,
                'date': date_idx.strftime('%Y-%m-%d'),
                'type': 'sell',
                'price': round(price, 2),
                'shares': position_shares,
                'amount': round(position_shares * price, 2),
                'commission': round(commission, 2),
                'stamp_tax': round(stamp_tax, 2),
                'profit': round(profit, 2),
                'reason': reason
            })
            equity += revenue
            return 0, trade_id, 0, equity
        
        return 0, trade_id, 0, equity
    
    def _update_equity(
        self,
        equity_curve: List[float],
        daily_returns: List[float],
        dates: List[date],
        equity: float,
        position: int,
        position_shares: int,
        df_backtest: pd.DataFrame,
        i: int,
        date_idx: pd.Timestamp
    ):
        """更新权益曲线"""
        # 计算当前权益
        if position == 1 and position_shares > 0:
            current_equity = equity + position_shares * df_backtest['close'].iloc[i]
        else:
            current_equity = equity
        
        equity_curve.append(current_equity)
        
        # 计算日收益率
        if len(equity_curve) > 1:
            daily_return = (equity_curve[-1] - equity_curve[-2]) / equity_curve[-2] if equity_curve[-2] > 0 else 0
            daily_returns.append(daily_return)
        else:
            daily_returns.append(0)
        
        dates.append(date_idx)
