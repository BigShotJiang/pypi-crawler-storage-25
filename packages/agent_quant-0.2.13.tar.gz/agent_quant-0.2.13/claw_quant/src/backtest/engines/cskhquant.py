# -*- coding: utf-8 -*-
"""
CSKhQuant回测引擎适配器

将统一参数转换为CSKhQuant格式，从DuckDBServer读取数据
"""

import sys
import os
import tempfile
import json
from datetime import date, datetime
from typing import Dict, Any, List
import pandas as pd
import numpy as np

from .unified import BaseEngineAdapter, BacktestInput, BacktestOutput, EngineType
from ....database.api import StockAPI


class CSKhQuantEngineAdapter(BaseEngineAdapter):
    """
    CSKhQuant回测引擎适配器
    
    特点：
    - 使用CSKhQuant框架进行回测
    - 从DuckDBServer读取数据
    - 支持CROSS、MACD等因子
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__('cskhquant', EngineType.CSKHQUANT)
        config = config or {}
        
        # CSKhQuant路径配置
        self.cskhquant_path = config.get('cskhquant_path', 
            os.path.join(os.path.dirname(__file__), '..', '..', '..', 'CSkhQuant'))
        
        # 数据库连接配置
        host = config.get('host', '127.0.0.1')
        port = config.get('port', 9529)
        self.stock_api = StockAPI(host=host, port=port)
        
        # CSKhQuant组件（延迟加载）
        self._cskhquant_imported = False
        self.KhQuantFramework = None
    
    def _import_cskhquant(self):
        """导入CSKhQuant模块"""
        if self._cskhquant_imported:
            return
        
        try:
            if self.cskhquant_path not in sys.path:
                sys.path.insert(0, self.cskhquant_path)
            from khFrame import KhQuantFramework
            self.KhQuantFramework = KhQuantFramework
            self._cskhquant_imported = True
        except ImportError as e:
            raise ImportError(f"无法导入CSKhQuant模块: {e}")
    
    def get_name(self) -> str:
        """获取引擎名称"""
        return "CSKhQuant回测引擎"
    
    def get_description(self) -> str:
        """获取引擎描述"""
        return "基于CSKhQuant框架的回测引擎"
    
    def is_available(self) -> bool:
        """检查CSKhQuant是否可用"""
        try:
            self._import_cskhquant()
            return True
        except:
            return False
    
    def run(self, input_params: BacktestInput) -> BacktestOutput:
        """运行CSKhQuant回测"""
        self._import_cskhquant()
        
        start_date, end_date = input_params.get_date_range()
        
        # 从DuckDBServer获取数据
        df = self._fetch_data(input_params.code, start_date, end_date)
        
        # 创建策略文件
        strategy_file = self._create_strategy_file(input_params)
        
        # 创建配置文件
        config_file = self._create_config_file(strategy_file, input_params)
        
        # 运行CSKhQuant回测
        result = self._run_cskhquant_backtest(config_file, df)
        
        # 转换为统一输出格式
        return self._convert_output(input_params, result)
    
    def _fetch_data(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """从DuckDBServer获取数据"""
        df = self.stock_api.get_daily(code, start_date, end_date)
        
        if df is None or len(df) == 0:
            raise ValueError(f"无法获取股票 {code} 的数据")
        
        return df
    
    def _create_strategy_file(self, input_params: BacktestInput) -> str:
        """创建CSKhQuant策略文件"""
        factor_name = input_params.factor_name
        params = input_params.factor_params or {}
        
        if factor_name == 'CROSS':
            short_window = params.get('short_window', 5)
            long_window = params.get('long_window', 20)
            
            strategy_code = f'''
# coding: utf-8
from khQuantImport import *

params = {{
    'short_window': {short_window},
    'long_window': {long_window},
}}

def init(stocks=None, data=None):
    logging.info(f"=== 双均线交叉策略启动 ===")
    logging.info(f"参数: 短期={{params['short_window']}}日, 长期={{params['long_window']}}日")

def khHandlebar(data: Dict) -> List[Dict]:
    signals = []
    stock_code = khGet(data, "first_stock")
    current_price = khPrice(data, stock_code, "open")
    current_date_str = khGet(data, "date_num")
    
    short_win = params['short_window']
    long_win = params['long_window']
    
    ma_short = khMA(stock_code, short_win, end_time=current_date_str)
    ma_long = khMA(stock_code, long_win, end_time=current_date_str)
    
    has_position = khHas(data, stock_code)
    
    if ma_short > ma_long and not has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'buy', 
                                  f"{{short_win}}日线上穿{{long_win}}日线，全仓买入")
    elif ma_short < ma_long and has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'sell',
                                  f"{{short_win}}日线下穿{{long_win}}日线，全仓卖出")
    
    return signals
'''
        elif factor_name == 'MACD':
            fast = params.get('fast', 12)
            slow = params.get('slow', 26)
            signal = params.get('signal', 9)
            
            strategy_code = f'''
# coding: utf-8
from khQuantImport import *

params = {{
    'fast': {fast},
    'slow': {slow},
    'signal': {signal},
}}

def init(stocks=None, data=None):
    logging.info(f"=== MACD策略启动 ===")

def khHandlebar(data: Dict) -> List[Dict]:
    signals = []
    stock_code = khGet(data, "first_stock")
    current_price = khPrice(data, stock_code, "open")
    current_date_str = khGet(data, "date_num")
    
    # 获取MACD指标
    hist = khMACD(stock_code, params['fast'], params['slow'], params['signal'], 
                  end_time=current_date_str)
    hist_prev = khMACD(stock_code, params['fast'], params['slow'], params['signal'],
                       end_time=current_date_str, offset=1)
    
    has_position = khHas(data, stock_code)
    
    # MACD金叉：hist从负变正
    if hist > 0 and hist_prev <= 0 and not has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'buy',
                                  "MACD金叉，全仓买入")
    # MACD死叉：hist从正变负
    elif hist < 0 and hist_prev >= 0 and has_position:
        signals = generate_signal(data, stock_code, current_price, 1.0, 'sell',
                                  "MACD死叉，全仓卖出")
    
    return signals
'''
        else:
            raise ValueError(f"CSKhQuant引擎不支持的因子类型: {factor_name}")
        
        # 写入临时文件
        fd, path = tempfile.mkstemp(suffix='.py')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(strategy_code)
        return path
    
    def _create_config_file(self, strategy_file: str, input_params: BacktestInput) -> str:
        """创建CSKhQuant配置文件"""
        start_date, end_date = input_params.get_date_range()
        
        config = {
            "system": {
                "userdata_path": os.environ.get('QMT_PATH', 'C:/国金证券QMT交易端/userdata_mini')
            },
            "run_mode": "backtest",
            "account": {
                "account_id": "88888888",
                "account_type": "STOCK"
            },
            "strategy_file": strategy_file,
            "data_mode": "custom",
            "backtest": {
                "start_time": start_date.strftime('%Y%m%d'),
                "end_time": end_date.strftime('%Y%m%d'),
                "init_capital": input_params.init_capital,
                "min_volume": 100,
                "benchmark": input_params.benchmark.replace('.SH', '.000300').replace('.SZ', '.399001'),
                "trade_cost": {
                    "min_commission": input_params.min_commission,
                    "commission_rate": input_params.commission_rate,
                    "stamp_tax_rate": input_params.stamp_tax_rate,
                    "flow_fee": 0.0,
                    "slippage": {
                        "type": "ratio",
                        "tick_size": 0.01,
                        "tick_count": 2,
                        "ratio": input_params.slippage
                    }
                },
                "trigger": {
                    "type": "1d",
                    "custom_times": ["09:30:00"],
                    "start_time": "09:30:00",
                    "end_time": "15:00:00",
                    "interval": 300
                }
            },
            "stocks": [input_params.code]
        }
        
        # 写入临时文件
        fd, path = tempfile.mkstemp(suffix='.json')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        return path
    
    def _run_cskhquant_backtest(self, config_file: str, df: pd.DataFrame) -> Dict[str, Any]:
        """运行CSKhQuant回测"""
        # TODO: 实现CSKhQuant回测调用
        # 这里需要根据CSKhQuant的实际API进行实现
        raise NotImplementedError("CSKhQuant回测执行需要根据实际情况实现")
    
    def _convert_output(self, input_params: BacktestInput, result: Dict[str, Any]) -> BacktestOutput:
        """将CSKhQuant输出转换为统一格式"""
        start_date, end_date = input_params.get_date_range()
        
        # TODO: 根据CSKhQuant的实际输出格式进行转换
        return BacktestOutput(
            engine_name=self.name,
            factor_name=input_params.factor_name,
            code=input_params.code,
            start_date=start_date,
            end_date=end_date,
            init_capital=input_params.init_capital,
            factor_params=input_params.factor_params or {},
            final_capital=result.get('final_capital', input_params.init_capital),
            total_return=result.get('total_return', 0),
            annual_return=result.get('annual_return', 0),
            max_drawdown=result.get('max_drawdown', 0),
            sharpe_ratio=result.get('sharpe_ratio', 0),
            total_trades=result.get('total_trades', 0),
            winning_trades=result.get('winning_trades', 0),
            losing_trades=result.get('losing_trades', 0),
            win_rate=result.get('win_rate', 0),
            trades=result.get('trades', []),
            raw_result=result
        )
