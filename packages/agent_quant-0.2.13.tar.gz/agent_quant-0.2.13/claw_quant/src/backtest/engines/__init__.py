# -*- coding: utf-8 -*-
"""
回测引擎实现 - 统一多引擎架构

提供以下引擎适配器：
- LocalEngineAdapter: 本地轻量级引擎（默认）
- CSKhQuantEngineAdapter: CSKhQuant框架
- JQDataEngineAdapter: 聚宽JQData
- VNPYEngineAdapter: VNPY框架

统一接口：
- BacktestInput: 统一的输入参数结构
- BacktestOutput: 统一的输出结果结构
- BaseEngineAdapter: 引擎适配器基类
- UnifiedBacktestEngine: 统一回测引擎管理器
"""

# 统一引擎架构
from .unified import (
    EngineType,
    BacktestInput,
    BacktestOutput,
    BaseEngineAdapter,
    UnifiedBacktestEngine,
    get_unified_engine
)

# 本地引擎适配器
from .local import LocalEngineAdapter

# 其他引擎适配器（可选导入）
try:
    from .cskhquant import CSKhQuantEngineAdapter
except ImportError:
    CSKhQuantEngineAdapter = None

try:
    from .jqdata import JQDataEngineAdapter
except ImportError:
    JQDataEngineAdapter = None

try:
    from .vnpy import VNPYEngineAdapter
except ImportError:
    VNPYEngineAdapter = None

# 向后兼容：保留旧引擎导入
try:
    from .cskhquant_full import CSKhQuantEngine
except ImportError:
    CSKhQuantEngine = None

try:
    from .jqdata_full import JQDataEngine
except ImportError:
    JQDataEngine = None

__all__ = [
    # 统一架构
    'EngineType',
    'BacktestInput',
    'BacktestOutput',
    'BaseEngineAdapter',
    'UnifiedBacktestEngine',
    'get_unified_engine',
    # 适配器
    'LocalEngineAdapter',
    'CSKhQuantEngineAdapter',
    'JQDataEngineAdapter',
    'VNPYEngineAdapter',
    # 向后兼容
    'CSKhQuantEngine',
    'JQDataEngine',
]
