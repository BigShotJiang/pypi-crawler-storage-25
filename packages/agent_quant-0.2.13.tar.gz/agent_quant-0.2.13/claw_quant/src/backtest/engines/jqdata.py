# -*- coding: utf-8 -*-
"""
JQData回测引擎适配器

将统一参数转换为JQData格式，从DuckDBServer读取数据
"""

import os
from datetime import date, datetime
from typing import Dict, Any, List
import pandas as pd
import numpy as np

from .unified import BaseEngineAdapter, BacktestInput, BacktestOutput, EngineType
from ....database.api import StockAPI


class JQDataEngineAdapter(BaseEngineAdapter):
    """
    JQData回测引擎适配器
    
    特点：
    - 使用聚宽JQData进行回测
    - 从DuckDBServer读取数据（而非直接调用JQData API）
    - 支持CROSS、MACD、MA、RSI等因子
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__('jqdata', EngineType.JQDATA)
        config = config or {}
        
        # JQData认证信息
        self.username = config.get('jqdata_username') or os.environ.get('JQDATA_USERNAME')
        self.password = config.get('jqdata_password') or os.environ.get('JQDATA_PASSWORD')
        
        # 数据库连接配置
        host = config.get('host', '127.0.0.1')
        port = config.get('port', 9529)
        self.stock_api = StockAPI(host=host, port=port)
        
        # JQData组件（延迟加载）
        self._jqdata_imported = False
        self.jq = None
    
    def _import_jqdata(self):
        """导入JQData模块"""
        if self._jqdata_imported:
            return
        
        try:
            import jqdatasdk as jq
            self.jq = jq
            
            # 登录
            if self.username and self.password:
                jq.auth(self.username, self.password)
            
            self._jqdata_imported = True
        except ImportError as e:
            raise ImportError(f"无法导入JQData模块: {e}")
    
    def get_name(self) -> str:
        """获取引擎名称"""
        return "JQData回测引擎"
    
    def get_description(self) -> str:
        """获取引擎描述"""
        return "基于聚宽JQData的回测引擎"
    
    def is_available(self) -> bool:
        """检查JQData是否可用"""
        try:
            self._import_jqdata()
            return True
        except:
            return False
    
    def run(self, input_params: BacktestInput) -> BacktestOutput:
        """运行JQData回测"""
        # 注意：这里我们使用DuckDBServer的数据，而不是直接调用JQData
        # 这样可以保持数据一致性
        
        start_date, end_date = input_params.get_date_range()
        
        # 从DuckDBServer获取数据
        df = self._fetch_data(input_params.code, start_date, end_date)
        
        # 执行回测逻辑（使用本地计算）
        result = self._run_backtest_logic(input_params, df)
        
        # 转换为统一输出格式
        return self._convert_output(input_params, result)
    
    def _fetch_data(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """从DuckDBServer获取数据"""
        df = self.stock_api.get_daily(code, start_date, end_date)
        
        if df is None or len(df) == 0:
            raise ValueError(f"无法获取股票 {code} 的数据")
        
        # 确保日期列为索引
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
        
        return df
    
    def _run_backtest_logic(self, input_params: BacktestInput, df: pd.DataFrame) -> Dict[str, Any]:
        """执行回测逻辑"""
        factor_name = input_params.factor_name
        factor_params = input_params.factor_params or {}
        
        if factor_name == 'CROSS':
            return self._run_cross(df, input_params, factor_params)
        elif factor_name == 'MACD':
            return self._run_macd(df, input_params, factor_params)
        elif factor_name == 'MA':
            return self._run_ma(df, input_params, factor_params)
        elif factor_name == 'RSI':
            return self._run_rsi(df, input_params, factor_params)
        else:
            raise ValueError(f"JQData引擎不支持的因子类型: {factor_name}")
    
    def _run_cross(self, df: pd.DataFrame, input_params: BacktestInput, params: Dict[str, Any]) -> Dict[str, Any]:
        """运行均线交叉回测"""
        short_window = params.get('short_window', 5)
        long_window = params.get('long_window', 20)
        
        # 计算均线
        df['ma_short'] = df['close'].rolling(window=short_window).mean()
        df['ma_long'] = df['close'].rolling(window=long_window).mean()
        
        return self._execute_trades(df, input_params, 'ma_short', 'ma_long', 
                                    f'{short_window}日线上穿{long_window}日线，金叉买入',
                                    f'{short_window}日线下穿{long_window}日线，死叉卖出')
    
    def _run_macd(self, df: pd.DataFrame, input_params: BacktestInput, params: Dict[str, Any]) -> Dict[str, Any]:
        """运行MACD回测"""
        fast = params.get('fast', 12)
        slow = params.get('slow', 26)
        signal_period = params.get('signal', 9)
        
        # 计算MACD
        exp1 = df['close'].ewm(span=fast, adjust=False).mean()
        exp2 = df['close'].ewm(span=slow, adjust=False).mean()
        df['macd'] = exp1 - exp2
        df['signal'] = df['macd'].ewm(span=signal_period, adjust=False).mean()
        df['hist'] = df['macd'] - df['signal']
        
        return self._execute_trades(df, input_params, 'hist', 'hist',
                                    'MACD金叉买入', 'MACD死叉卖出', use_zero_cross=True)
    
    def _run_ma(self, df: pd.DataFrame, input_params: BacktestInput, params: Dict[str, Any]) -> Dict[str, Any]:
        """运行MA回测"""
        window = params.get('window', 20)
        field = params.get('field', 'close')
        
        # 计算均线
        df['ma'] = df[field].rolling(window=window).mean()
        
        return self._execute_trades(df, input_params, field, 'ma',
                                    f'价格突破{window}日均线买入',
                                    f'价格跌破{window}日均线卖出')
    
    def _run_rsi(self, df: pd.DataFrame, input_params: BacktestInput, params: Dict[str, Any]) -> Dict[str, Any]:
        """运行RSI回测"""
        window = params.get('window', 14)
        overbought = params.get('overbought', 70)
        oversold = params.get('oversold', 30)
        
        # 计算RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        trades = []
        trade_id = 0
        equity = input_params.init_capital
        position = 0
        position_shares = 0
        equity_curve = [equity]
        daily_returns = []
        dates = [df.index[0]]
        
        for i in range(1, len(df)):
            date_idx = df.index[i]
            rsi_curr = df['rsi'].iloc[i]
            rsi_prev = df['rsi'].iloc[i-1]
            
            if pd.isna(rsi_curr):
                self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df, i, date_idx)
                continue
            
            price = df['open'].iloc[i]
            
            # RSI从超卖区回升买入
            if rsi_prev <= oversold and rsi_curr > oversold and position == 0:
                position, trade_id, position_shares, equity = self._execute_buy(
                    trades, trade_id, date_idx, price, equity, input_params,
                    f'RSI({window})从超卖区({oversold})回升买入'
                )
            
            # RSI从超买区回落卖出
            elif rsi_prev >= overbought and rsi_curr < overbought and position == 1:
                position, trade_id, position_shares, equity = self._execute_sell(
                    trades, trade_id, date_idx, price, equity, position_shares, input_params,
                    f'RSI({window})从超买区({overbought})回落卖出'
                )
            
            self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df, i, date_idx)
        
        return {
            'trades': trades,
            'equity_curve': equity_curve,
            'daily_returns': daily_returns,
            'dates': dates
        }
    
    def _execute_trades(self, df: pd.DataFrame, input_params: BacktestInput, 
                        fast_col: str, slow_col: str, 
                        buy_reason: str, sell_reason: str,
                        use_zero_cross: bool = False) -> Dict[str, Any]:
        """执行交易逻辑"""
        trades = []
        trade_id = 0
        equity = input_params.init_capital
        position = 0
        position_shares = 0
        equity_curve = [equity]
        daily_returns = []
        dates = [df.index[0]]
        
        for i in range(1, len(df)):
            date_idx = df.index[i]
            
            fast_curr = df[fast_col].iloc[i]
            slow_curr = df[slow_col].iloc[i]
            fast_prev = df[fast_col].iloc[i-1]
            slow_prev = df[slow_col].iloc[i-1]
            
            if pd.isna(fast_curr) or pd.isna(slow_curr):
                self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df, i, date_idx)
                continue
            
            price = df['open'].iloc[i]
            
            if use_zero_cross:
                # 用于MACD（与0比较）
                if fast_prev <= 0 and fast_curr > 0 and position == 0:
                    position, trade_id, position_shares, equity = self._execute_buy(
                        trades, trade_id, date_idx, price, equity, input_params, buy_reason
                    )
                elif fast_prev >= 0 and fast_curr < 0 and position == 1:
                    position, trade_id, position_shares, equity = self._execute_sell(
                        trades, trade_id, date_idx, price, equity, position_shares, input_params, sell_reason
                    )
            else:
                # 用于均线交叉
                if fast_prev <= slow_prev and fast_curr > slow_curr and position == 0:
                    position, trade_id, position_shares, equity = self._execute_buy(
                        trades, trade_id, date_idx, price, equity, input_params, buy_reason
                    )
                elif fast_prev >= slow_prev and fast_curr < slow_curr and position == 1:
                    position, trade_id, position_shares, equity = self._execute_sell(
                        trades, trade_id, date_idx, price, equity, position_shares, input_params, sell_reason
                    )
            
            self._update_equity(equity_curve, daily_returns, dates, equity, position, position_shares, df, i, date_idx)
        
        return {
            'trades': trades,
            'equity_curve': equity_curve,
            'daily_returns': daily_returns,
            'dates': dates
        }
    
    def _execute_buy(self, trades, trade_id, date_idx, price, equity, input_params, reason):
        """执行买入"""
        trade_id += 1
        shares = int(equity / price / 100) * 100
        cost = shares * price * (1 + input_params.commission_rate)
        
        if cost <= equity:
            trades.append({
                'id': trade_id,
                'date': date_idx.strftime('%Y-%m-%d'),
                'type': 'buy',
                'price': round(price, 2),
                'shares': shares,
                'amount': round(shares * price, 2),
                'commission': round(shares * price * input_params.commission_rate, 2),
                'reason': reason
            })
            equity -= cost
            return 1, trade_id, shares, equity
        
        return 0, trade_id, 0, equity
    
    def _execute_sell(self, trades, trade_id, date_idx, price, equity, position_shares, input_params, reason):
        """执行卖出"""
        trade_id += 1
        if position_shares > 0:
            revenue = position_shares * price * (1 - input_params.commission_rate - input_params.stamp_tax_rate)
            commission = position_shares * price * input_params.commission_rate
            stamp_tax = position_shares * price * input_params.stamp_tax_rate
            
            buy_trade = None
            for t in reversed(trades):
                if t['type'] == 'buy':
                    buy_trade = t
                    break
            
            if buy_trade:
                profit = revenue - (position_shares * buy_trade['price']) - buy_trade['commission'] - commission - stamp_tax
            else:
                profit = 0
            
            trades.append({
                'id': trade_id,
                'date': date_idx.strftime('%Y-%m-%d'),
                'type': 'sell',
                'price': round(price, 2),
                'shares': position_shares,
                'amount': round(position_shares * price, 2),
                'commission': round(commission, 2),
                'stamp_tax': round(stamp_tax, 2),
                'profit': round(profit, 2),
                'reason': reason
            })
            equity += revenue
            return 0, trade_id, 0, equity
        
        return 0, trade_id, 0, equity
    
    def _update_equity(self, equity_curve, daily_returns, dates, equity, position, position_shares, df, i, date_idx):
        """更新权益曲线"""
        if position == 1 and position_shares > 0:
            current_equity = equity + position_shares * df['close'].iloc[i]
        else:
            current_equity = equity
        
        equity_curve.append(current_equity)
        
        if len(equity_curve) > 1:
            daily_return = (equity_curve[-1] - equity_curve[-2]) / equity_curve[-2] if equity_curve[-2] > 0 else 0
            daily_returns.append(daily_return)
        else:
            daily_returns.append(0)
        
        dates.append(date_idx)
    
    def _convert_output(self, input_params: BacktestInput, result: Dict[str, Any]) -> BacktestOutput:
        """转换为统一输出格式"""
        start_date, end_date = input_params.get_date_range()
        
        trades = result['trades']
        equity_curve = result['equity_curve']
        daily_returns = result['daily_returns']
        dates = result['dates']
        
        return self._build_output(
            input_params, trades, equity_curve, daily_returns, dates
        )
