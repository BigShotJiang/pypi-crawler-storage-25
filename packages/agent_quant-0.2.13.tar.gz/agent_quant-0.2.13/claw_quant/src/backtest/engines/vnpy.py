# -*- coding: utf-8 -*-
"""
VNPY回测引擎适配器

将统一参数转换为VNPY格式，从DuckDBServer读取数据并转换为VNPY BarData格式
"""

import sys
import os
from datetime import date, datetime, timedelta
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np

from .unified import BaseEngineAdapter, BacktestInput, BacktestOutput, EngineType
from ....database.api import StockAPI


class VNPYEngineAdapter(BaseEngineAdapter):
    """
    VNPY回测引擎适配器
    
    特点：
    - 使用vnpy_ctastrategy的回测引擎
    - 从DuckDBServer读取数据并转换为BarData格式
    - 支持CROSS、MACD、MA、RSI等因子
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__('vnpy', EngineType.VNPY)
        config = config or {}
        
        # 尝试多个可能的VNPY路径
        possible_paths = [
            config.get('vnpy_path'),
            os.path.join(os.path.dirname(__file__), '..', '..', '..', 'vnpy'),
            os.path.join(os.path.dirname(__file__), '..', '..', '..', 'VNPY'),
            'c:\\vnpy',
            'C:\\vnpy',
        ]
        
        self.vnpy_path = None
        for path in possible_paths:
            if path and os.path.exists(path):
                self.vnpy_path = path
                break
        
        if self.vnpy_path and self.vnpy_path not in sys.path:
            sys.path.insert(0, self.vnpy_path)
        
        # 数据库连接配置
        host = config.get('host', '127.0.0.1')
        port = config.get('port', 9529)
        self.stock_api = StockAPI(host=host, port=port)
        
        # VNPY组件（延迟加载）
        self._vnpy_imported = False
        self._import_error = None
        self.BacktestingEngine = None
        self.BacktestingMode = None
        self.Interval = None
        self.Exchange = None
        self.BarData = None
    
    def _import_vnpy(self):
        """导入VNPY模块"""
        if self._vnpy_imported:
            return
        
        if self._import_error:
            raise self._import_error
        
        try:
            from vnpy_ctastrategy.backtesting import BacktestingEngine
            from vnpy_ctastrategy.base import BacktestingMode
            from vnpy.trader.constant import Interval, Exchange
            from vnpy.trader.object import BarData
            
            self.BacktestingEngine = BacktestingEngine
            self.BacktestingMode = BacktestingMode
            self.Interval = Interval
            self.Exchange = Exchange
            self.BarData = BarData
            self._vnpy_imported = True
        except ImportError as e:
            self._import_error = ImportError(f"无法导入VNPY模块: {e}. 请确保vnpy已安装: pip install vnpy vnpy_ctastrategy")
            raise self._import_error
    
    def get_name(self) -> str:
        """获取引擎名称"""
        return "VNPY回测引擎"
    
    def get_description(self) -> str:
        """获取引擎描述"""
        return "基于VNPY框架的回测引擎"
    
    def is_available(self) -> bool:
        """检查VNPY是否可用"""
        try:
            self._import_vnpy()
            return True
        except Exception as e:
            self._import_error = e
            return False
    
    def get_availability_info(self) -> Dict[str, Any]:
        """获取可用性详细信息"""
        info = {
            'available': self.is_available(),
            'path': self.vnpy_path,
            'error': str(self._import_error) if self._import_error else None
        }
        return info
    
    def run(self, input_params: BacktestInput) -> BacktestOutput:
        """运行VNPY回测"""
        self._import_vnpy()
        
        start_date, end_date = input_params.get_date_range()
        factor_name = input_params.factor_name
        factor_params = input_params.factor_params or {}
        
        # 从DuckDBServer获取数据
        df = self._fetch_data(input_params.code, start_date, end_date)
        
        # 转换为VNPY BarData格式
        bars = self._convert_to_bars(df, input_params.code)
        
        # 根据因子类型创建策略
        strategy_class, strategy_params = self._create_strategy(factor_name, factor_params)
        
        # 设置VNPY回测引擎
        engine = self._setup_engine(input_params, bars, strategy_class, strategy_params)
        
        # 运行回测
        engine.run_backtesting()
        
        # 计算结果
        df_result = engine.calculate_result()
        statistics = engine.calculate_statistics()
        
        # 转换为统一输出格式
        return self._convert_output(input_params, engine, statistics, df_result)
    
    def _fetch_data(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """从DuckDBServer获取数据"""
        # 扩展日期范围以确保有足够的历史数据计算指标
        extended_start = start_date - timedelta(days=60)
        df = self.stock_api.get_daily(code, extended_start, end_date)
        
        if df is None or len(df) == 0:
            raise ValueError(f"无法获取股票 {code} 的数据")
        
        # 确保日期列为索引
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
        
        return df
    
    def _convert_to_bars(self, df: pd.DataFrame, code: str) -> List[Any]:
        """将DataFrame转换为VNPY BarData列表"""
        bars = []
        
        # 解析股票代码和交易所
        symbol, exchange_str = self._parse_code(code)
        exchange = getattr(self.Exchange, exchange_str, self.Exchange.SZSE)
        
        for idx, row in df.iterrows():
            bar = self.BarData(
                symbol=symbol,
                exchange=exchange,
                datetime=idx if isinstance(idx, datetime) else pd.to_datetime(idx),
                interval=self.Interval.DAILY,
                volume=float(row.get('volume', 0)),
                open_price=float(row.get('open', 0)),
                high_price=float(row.get('high', 0)),
                low_price=float(row.get('low', 0)),
                close_price=float(row.get('close', 0)),
                gateway_name="DB"
            )
            bars.append(bar)
        
        return bars
    
    def _parse_code(self, code: str) -> tuple:
        """解析股票代码和交易所"""
        if '.' in code:
            parts = code.split('.')
            symbol = parts[0]
            exchange_suffix = parts[1].upper()
            if exchange_suffix == 'SZ':
                exchange = 'SZSE'
            elif exchange_suffix == 'SH':
                exchange = 'SSE'
            elif exchange_suffix == 'BJ':
                exchange = 'BSE'
            else:
                exchange = 'SZSE'
        else:
            symbol = code
            # 根据代码前缀判断交易所
            if code.startswith('6'):
                exchange = 'SSE'
            elif code.startswith('0') or code.startswith('3'):
                exchange = 'SZSE'
            elif code.startswith('8') or code.startswith('4'):
                exchange = 'BSE'
            else:
                exchange = 'SZSE'
        
        return symbol, exchange
    
    def _create_strategy(self, factor_name: str, factor_params: Dict[str, Any]) -> tuple:
        """根据因子类型创建策略类和参数"""
        from vnpy_ctastrategy import CtaTemplate
        
        if factor_name == 'CROSS':
            short_window = factor_params.get('short_window', 5)
            long_window = factor_params.get('long_window', 20)
            
            # 使用闭包来捕获参数
            _short_window = short_window
            _long_window = long_window
            
            class CrossStrategy(CtaTemplate):
                """均线交叉策略"""
                author = "ClawQuant"
                
                # 使用默认值，实际值通过setting传递
                short_window = 5
                long_window = 20
                
                short_ma = 0.0
                long_ma = 0.0
                
                parameters = ["short_window", "long_window"]
                variables = ["short_ma", "long_ma"]
                
                def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
                    super().__init__(cta_engine, strategy_name, vt_symbol, setting)
                    self.bars = []
                
                def on_init(self):
                    self.write_log("策略初始化")
                    self.load_bar(10)
                
                def on_start(self):
                    self.write_log("策略启动")
                
                def on_stop(self):
                    self.write_log("策略停止")
                
                def on_bar(self, bar):
                    self.bars.append(bar)
                    if len(self.bars) < self.long_window:
                        return
                    
                    # 计算均线
                    closes = [b.close_price for b in self.bars[-self.long_window:]]
                    self.short_ma = sum(closes[-self.short_window:]) / self.short_window
                    self.long_ma = sum(closes) / self.long_window
                    
                    # 交易信号
                    if self.short_ma > self.long_ma and self.pos == 0:
                        self.buy(bar.close_price, 1)
                    elif self.short_ma < self.long_ma and self.pos > 0:
                        self.sell(bar.close_price, 1)
            
            # 返回策略类和设置
            settings = {'short_window': short_window, 'long_window': long_window}
            return CrossStrategy, settings
        
        elif factor_name == 'MACD':
            fast = factor_params.get('fast', 12)
            slow = factor_params.get('slow', 26)
            signal = factor_params.get('signal', 9)
            
            class MACDStrategy(CtaTemplate):
                """MACD策略"""
                author = "ClawQuant"
                
                fast_period = 12
                slow_period = 26
                signal_period = 9
                
                macd = 0.0
                signal_line = 0.0
                histogram = 0.0
                
                parameters = ["fast_period", "slow_period", "signal_period"]
                variables = ["macd", "signal_line", "histogram"]
                
                def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
                    super().__init__(cta_engine, strategy_name, vt_symbol, setting)
                    self.bars = []
                
                def on_init(self):
                    self.write_log("策略初始化")
                    self.load_bar(30)
                
                def on_start(self):
                    self.write_log("策略启动")
                
                def on_stop(self):
                    self.write_log("策略停止")
                
                def on_bar(self, bar):
                    self.bars.append(bar)
                    if len(self.bars) < self.slow_period + self.signal_period:
                        return
                    
                    closes = [b.close_price for b in self.bars]
                    
                    # 计算EMA
                    ema_fast = self._ema(closes, self.fast_period)
                    ema_slow = self._ema(closes, self.slow_period)
                    
                    self.macd = ema_fast - ema_slow
                    self.signal_line = self._ema([self.macd] * len(closes), self.signal_period)
                    self.histogram = self.macd - self.signal_line
                    
                    # 交易信号
                    if self.histogram > 0 and self.pos == 0:
                        self.buy(bar.close_price, 1)
                    elif self.histogram < 0 and self.pos > 0:
                        self.sell(bar.close_price, 1)
                
                def _ema(self, data, period):
                    multiplier = 2 / (period + 1)
                    ema = data[0]
                    for price in data[1:]:
                        ema = (price - ema) * multiplier + ema
                    return ema
            
            settings = {'fast_period': fast, 'slow_period': slow, 'signal_period': signal}
            return MACDStrategy, settings
        
        elif factor_name == 'MA':
            window = factor_params.get('window', 20)
            
            class MAStrategy(CtaTemplate):
                """均线突破策略"""
                author = "ClawQuant"
                
                window = 20
                ma_value = 0.0
                
                parameters = ["window"]
                variables = ["ma_value"]
                
                def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
                    super().__init__(cta_engine, strategy_name, vt_symbol, setting)
                    self.bars = []
                
                def on_init(self):
                    self.write_log("策略初始化")
                    self.load_bar(10)
                
                def on_start(self):
                    self.write_log("策略启动")
                
                def on_stop(self):
                    self.write_log("策略停止")
                
                def on_bar(self, bar):
                    self.bars.append(bar)
                    if len(self.bars) < self.window:
                        return
                    
                    closes = [b.close_price for b in self.bars[-self.window:]]
                    self.ma_value = sum(closes) / self.window
                    
                    if bar.close_price > self.ma_value and self.pos == 0:
                        self.buy(bar.close_price, 1)
                    elif bar.close_price < self.ma_value and self.pos > 0:
                        self.sell(bar.close_price, 1)
            
            settings = {'window': window}
            return MAStrategy, settings
        
        elif factor_name == 'RSI':
            window = factor_params.get('window', 14)
            overbought = factor_params.get('overbought', 70)
            oversold = factor_params.get('oversold', 30)
            
            class RSIStrategy(CtaTemplate):
                """RSI策略"""
                author = "ClawQuant"
                
                window = 14
                overbought = 70
                oversold = 30
                rsi_value = 50.0
                
                parameters = ["window", "overbought", "oversold"]
                variables = ["rsi_value"]
                
                def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
                    super().__init__(cta_engine, strategy_name, vt_symbol, setting)
                    self.bars = []
                
                def on_init(self):
                    self.write_log("策略初始化")
                    self.load_bar(20)
                
                def on_start(self):
                    self.write_log("策略启动")
                
                def on_stop(self):
                    self.write_log("策略停止")
                
                def on_bar(self, bar):
                    self.bars.append(bar)
                    if len(self.bars) < self.window + 1:
                        return
                    
                    closes = [b.close_price for b in self.bars[-self.window-1:]]
                    self.rsi_value = self._calculate_rsi(closes)
                    
                    if self.rsi_value < self.oversold and self.pos == 0:
                        self.buy(bar.close_price, 1)
                    elif self.rsi_value > self.overbought and self.pos > 0:
                        self.sell(bar.close_price, 1)
                
                def _calculate_rsi(self, prices):
                    gains = []
                    losses = []
                    for i in range(1, len(prices)):
                        change = prices[i] - prices[i-1]
                        if change > 0:
                            gains.append(change)
                            losses.append(0)
                        else:
                            gains.append(0)
                            losses.append(abs(change))
                    
                    avg_gain = sum(gains) / len(gains) if gains else 0
                    avg_loss = sum(losses) / len(losses) if losses else 0
                    
                    if avg_loss == 0:
                        return 100
                    rs = avg_gain / avg_loss
                    return 100 - (100 / (1 + rs))
            
            settings = {'window': window, 'overbought': overbought, 'oversold': oversold}
            return RSIStrategy, settings
        
        else:
            raise ValueError(f"VNPY引擎不支持的因子类型: {factor_name}")
    
    def _setup_engine(self, input_params: BacktestInput, bars: List[Any], 
                      strategy_class, strategy_params: Dict[str, Any]) -> Any:
        """设置VNPY回测引擎"""
        engine = self.BacktestingEngine()
        
        start_date, end_date = input_params.get_date_range()
        # VNPY需要datetime对象
        from datetime import datetime
        start_datetime = datetime.combine(start_date, datetime.min.time())
        end_datetime = datetime.combine(end_date, datetime.min.time())
        
        symbol, exchange_str = self._parse_code(input_params.code)
        vt_symbol = f"{symbol}.{exchange_str}"
        
        # 设置回测参数
        engine.set_parameters(
            vt_symbol=vt_symbol,
            interval=self.Interval.DAILY,
            start=start_datetime,
            end=end_datetime,
            rate=input_params.commission_rate,
            slippage=input_params.slippage,
            size=1,
            pricetick=0.01,
            capital=input_params.init_capital,
            mode=self.BacktestingMode.BAR
        )
        
        # 添加策略
        engine.add_strategy(strategy_class, strategy_params)
        
        # 加载数据（通过自定义方式）
        engine.history_data = bars
        
        return engine
    
    def _convert_output(self, input_params: BacktestInput, engine: Any, 
                        statistics: Dict[str, Any], df_result: Optional[pd.DataFrame]) -> BacktestOutput:
        """将VNPY输出转换为统一格式"""
        start_date, end_date = input_params.get_date_range()
        
        # 获取交易记录
        trades = []
        for trade in engine.trades.values():
            trades.append({
                'id': str(trade.tradeid),
                'date': trade.datetime.strftime('%Y-%m-%d'),
                'type': 'buy' if trade.direction.value == '多' else 'sell',
                'price': round(float(trade.price), 2),
                'volume': int(trade.volume),
                'amount': round(float(trade.price) * int(trade.volume), 2)
            })
        
        # 辅助函数：将numpy类型转换为Python原生类型
        def to_native(val):
            if hasattr(val, 'item'):  # numpy scalar
                return val.item()
            return val
        
        # 计算指标
        total_return = to_native(statistics.get('total_return', 0))
        annual_return = to_native(statistics.get('annual_return', 0))
        max_drawdown = to_native(statistics.get('max_ddpercent', 0))
        sharpe_ratio = to_native(statistics.get('sharpe_ratio', 0))
        total_trades = int(to_native(statistics.get('total_trade_count', 0)))
        win_rate = to_native(statistics.get('win_percent', 0))
        
        # 最终资金
        final_capital = input_params.init_capital * (1 + total_return)
        
        # 转换statistics中的所有值为原生Python类型
        clean_statistics = {}
        for k, v in statistics.items():
            if hasattr(v, 'item'):
                clean_statistics[k] = v.item()
            elif isinstance(v, (int, float, str, bool, type(None))):
                clean_statistics[k] = v
            else:
                clean_statistics[k] = str(v)
        
        return BacktestOutput(
            engine_name=self.name,
            factor_name=input_params.factor_name,
            code=input_params.code,
            start_date=start_date,
            end_date=end_date,
            init_capital=input_params.init_capital,
            factor_params=input_params.factor_params or {},
            final_capital=float(final_capital),
            total_return=float(total_return),
            annual_return=float(annual_return),
            max_drawdown=float(max_drawdown),
            sharpe_ratio=float(sharpe_ratio),
            total_trades=total_trades,
            winning_trades=int(total_trades * win_rate) if total_trades > 0 else 0,
            losing_trades=int(total_trades * (1 - win_rate)) if total_trades > 0 else 0,
            win_rate=float(win_rate),
            trades=trades,
            raw_result=clean_statistics
        )
