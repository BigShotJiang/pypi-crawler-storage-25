"""
回测引擎
"""
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Callable
import logging

from .portfolio import Portfolio, Trade
from .analyzer import PerformanceAnalyzer

logger = logging.getLogger(__name__)


class BacktestEngine:
    """回测引擎"""
    
    def __init__(self, db_manager, strategy_manager):
        """
        初始化回测引擎
        
        Args:
            db_manager: 数据库管理器
            strategy_manager: 策略管理器
        """
        self.db = db_manager
        self.strategy_manager = strategy_manager
        
        self.task_id: Optional[str] = None
        self.portfolio: Optional[Portfolio] = None
        self.analyzer: Optional[PerformanceAnalyzer] = None
        
        # 回测参数
        self.start_date: Optional[date] = None
        self.end_date: Optional[date] = None
        self.initial_capital: float = 1000000.0
        
        # 手续费
        self.commission_rate: float = 0.0003      # 佣金
        self.stamp_duty_rate: float = 0.001       # 印花税(卖出)
        
        # 进度回调
        self.progress_callback: Optional[Callable] = None
        
    def setup(self,
              strategy_code: str,
              start_date: date,
              end_date: date,
              initial_capital: float = 1000000.0,
              commission_rate: float = 0.0003,
              progress_callback: Optional[Callable] = None):
        """
        设置回测参数
        
        Args:
            strategy_code: 策略代码
            start_date: 开始日期
            end_date: 结束日期
            initial_capital: 初始资金
            commission_rate: 佣金率
            progress_callback: 进度回调函数
        """
        self.strategy_code = strategy_code
        self.start_date = start_date
        self.end_date = end_date
        self.initial_capital = initial_capital
        self.commission_rate = commission_rate
        self.progress_callback = progress_callback
        
        # 创建回测任务
        self.task_id = self.db.create_backtest_task({
            'task_name': f"{strategy_code}_{start_date}_{end_date}",
            'strategy_code': strategy_code,
            'start_date': start_date,
            'end_date': end_date,
            'initial_capital': initial_capital
        })
        
        # 初始化组合
        self.portfolio = Portfolio(initial_capital)
        self.analyzer = PerformanceAnalyzer()
        
        logger.info(f"回测设置完成: {strategy_code} [{start_date} ~ {end_date}]")
        
    def run(self) -> Dict:
        """
        运行回测
        
        Returns:
            回测结果
        """
        if not self.task_id:
            raise ValueError("请先调用setup设置回测参数")
            
        logger.info(f"开始回测: {self.task_id}")
        
        # 获取策略
        strategy = self.strategy_manager.get_strategy(self.strategy_code)
        if not strategy:
            raise ValueError(f"策略不存在: {self.strategy_code}")
            
        # 获取交易日历
        trade_dates = self._get_trade_dates()
        total_days = len(trade_dates)
        
        logger.info(f"交易日数量: {total_days}")
        
        # 逐日回测
        for i, current_date in enumerate(trade_dates):
            try:
                self._run_day(current_date, strategy)
                
                # 更新进度
                progress = (i + 1) / total_days * 100
                self.db.update_backtest_progress(self.task_id, progress)
                
                if self.progress_callback:
                    self.progress_callback(progress)
                    
            except Exception as e:
                logger.error(f"回测失败 {current_date}: {e}")
                
        # 计算结果
        results = self._calculate_results()
        
        # 保存结果
        self._save_results(results)
        
        logger.info(f"回测完成: {self.task_id}")
        
        return results
        
    def _get_trade_dates(self) -> List[date]:
        """获取交易日列表"""
        # 从数据库获取实际交易日期
        df = self.db.conn.execute("""
            SELECT DISTINCT trade_date 
            FROM market_data_daily 
            WHERE trade_date BETWEEN ? AND ?
            ORDER BY trade_date
        """, [self.start_date, self.end_date]).fetchdf()
        
        if df.empty:
            # 没有数据，生成所有日期
            dates = []
            current = self.start_date
            while current <= self.end_date:
                dates.append(current)
                current += timedelta(days=1)
            return dates
            
        return df['trade_date'].tolist()
        
    def _run_day(self, current_date: date, strategy):
        """运行单日回测"""
        # 获取当日行情
        market_data = self._get_market_data(current_date)
        
        # 更新持仓价格
        if self.portfolio.positions:
            prices = {}
            for code in self.portfolio.positions.keys():
                code_data = market_data[market_data['code'] == code]
                if not code_data.empty:
                    prices[code] = code_data.iloc[0]['close']
            self.portfolio.update_prices(prices)
            
        # 检查止损止盈
        self._check_stop_loss_take_profit(current_date, market_data)
        
        # 获取因子数据
        factor_codes = strategy.config.factor_codes
        factor_data = pd.DataFrame()
        
        if factor_codes:
            factor_data = self.db.get_factor_values(
                factor_codes,
                current_date,
                list(self.portfolio.positions.keys())
            )
            
        # 生成信号
        signals = strategy.generate_signals(
            datetime.combine(current_date, datetime.min.time()),
            market_data,
            factor_data,
            {code: pos.to_dict() for code, pos in self.portfolio.positions.items()}
        )
        
        # 执行信号
        for signal in signals:
            self._execute_signal(signal, current_date, market_data)
            
        # 记录净值
        self.portfolio.record_nav(datetime.combine(current_date, datetime.min.time()))
        
    def _get_market_data(self, current_date: date) -> pd.DataFrame:
        """获取市场数据"""
        # 获取当日所有股票数据
        df = self.db.conn.execute("""
            SELECT * FROM market_data_daily 
            WHERE trade_date = ?
        """, [current_date]).fetchdf()
        
        return df
        
    def _check_stop_loss_take_profit(self, current_date: date, market_data: pd.DataFrame):
        """检查止损止盈"""
        strategy = self.strategy_manager.get_strategy(self.strategy_code)
        
        for code, position in list(self.portfolio.positions.items()):
            code_data = market_data[market_data['code'] == code]
            if code_data.empty:
                continue
                
            current_price = code_data.iloc[0]['close']
            
            # 检查止损
            if strategy.check_stop_loss(code, position.avg_price, current_price):
                self.portfolio.sell(
                    code, 0, current_price,
                    datetime.combine(current_date, datetime.min.time()),
                    self.commission_rate,
                    self.stamp_duty_rate,
                    "止损"
                )
                logger.info(f"止损卖出: {code} @ {current_price}")
                
            # 检查止盈
            elif strategy.check_take_profit(code, position.avg_price, current_price):
                self.portfolio.sell(
                    code, 0, current_price,
                    datetime.combine(current_date, datetime.min.time()),
                    self.commission_rate,
                    self.stamp_duty_rate,
                    "止盈"
                )
                logger.info(f"止盈卖出: {code} @ {current_price}")
                
    def _execute_signal(self, signal, current_date: date, market_data: pd.DataFrame):
        """执行交易信号"""
        code = signal.code
        
        # 获取价格
        code_data = market_data[market_data['code'] == code]
        if code_data.empty:
            return
            
        price = code_data.iloc[0]['close']
        
        # 计算数量
        strategy = self.strategy_manager.get_strategy(self.strategy_code)
        volume = strategy.calculate_position_size(
            signal,
            self.portfolio.total_value,
            {c: p.to_dict() for c, p in self.portfolio.positions.items()}
        )
        
        if signal.signal_type.value == 'buy' and volume > 0:
            self.portfolio.buy(
                code, volume, price,
                datetime.combine(current_date, datetime.min.time()),
                self.commission_rate,
                signal.reason
            )
            logger.info(f"买入: {code} {volume}股 @ {price}")
            
        elif signal.signal_type.value == 'sell':
            self.portfolio.sell(
                code, 0, price,
                datetime.combine(current_date, datetime.min.time()),
                self.commission_rate,
                self.stamp_duty_rate,
                signal.reason
            )
            logger.info(f"卖出: {code} @ {price}")
            
    def _calculate_results(self) -> Dict:
        """计算回测结果"""
        nav_df = self.portfolio.get_nav_history()
        
        if nav_df.empty:
            return {
                'total_return': 0,
                'annual_return': 0,
                'sharpe_ratio': 0,
                'max_drawdown': 0,
                'win_rate': 0,
                'trade_count': 0
            }
            
        # 计算指标
        total_return = self.portfolio.total_return
        
        # 年化收益
        days = (self.end_date - self.start_date).days
        years = days / 365
        annual_return = (1 + total_return) ** (1 / years) - 1 if years > 0 else 0
        
        # 夏普比率
        daily_returns = nav_df['daily_return'].dropna()
        sharpe_ratio = 0
        if len(daily_returns) > 1 and daily_returns.std() > 0:
            sharpe_ratio = (daily_returns.mean() / daily_returns.std()) * np.sqrt(252)
            
        # 最大回撤
        max_drawdown = nav_df['drawdown'].min()
        
        # 胜率
        trades_df = self.portfolio.get_trades()
        win_rate = 0
        if not trades_df.empty:
            # 计算每笔交易的盈亏
            sell_trades = trades_df[trades_df['trade_type'] == 'sell']
            # 简化计算，实际需要匹配买卖对
            
        return {
            'total_return': total_return,
            'annual_return': annual_return,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'trade_count': len(trades_df),
            'final_value': self.portfolio.total_value,
            'total_pnl': self.portfolio.total_pnl
        }
        
    def _save_results(self, results: Dict):
        """保存回测结果"""
        # 完成任务
        self.db.complete_backtest_task(self.task_id, results)
        
        # 保存交易记录
        trades_df = self.portfolio.get_trades()
        for _, trade in trades_df.iterrows():
            self.db.save_backtest_trade(self.task_id, trade.to_dict())
            
        # 保存净值
        nav_df = self.portfolio.get_nav_history()
        for _, row in nav_df.iterrows():
            self.db.save_backtest_nav(self.task_id, {
                'date': row['date'],
                'nav': row['nav'],
                'total_value': row['total_value'],
                'cash': row['cash'],
                'market_value': row['market_value'],
                'daily_return': row['daily_return'],
                'drawdown': row['drawdown']
            })
            
    def get_results(self) -> Dict:
        """获取回测结果"""
        if not self.task_id:
            return {}
            
        return self.db.get_backtest_results(self.task_id)
