# -*- coding: utf-8 -*-
"""
跨引擎回测结果对比验证
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import pandas as pd
import numpy as np

from .base import BacktestResult


@dataclass
class ComparisonReport:
    """对比报告"""
    engine_names: List[str]
    metrics_comparison: pd.DataFrame
    consistency_score: float  # 一致性得分 0-100
    warnings: List[str]
    is_consistent: bool
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'engine_names': self.engine_names,
            'metrics_comparison': self.metrics_comparison.to_dict(),
            'consistency_score': self.consistency_score,
            'warnings': self.warnings,
            'is_consistent': self.is_consistent,
        }


class CrossEngineValidator:
    """
    跨引擎验证器
    
    用于验证不同回测引擎的结果是否一致
    """
    
    # 各指标的容差阈值
    TOLERANCE = {
        'total_return': 0.01,  # 1%
        'annual_return': 0.01,
        'max_drawdown': 0.02,  # 2%
        'sharpe_ratio': 0.1,
        'total_trades': 0,     # 交易次数必须完全一致
        'win_rate': 0.05,      # 5%
    }
    
    def __init__(self):
        self.results: Dict[str, BacktestResult] = {}
        
    def add_result(self, name: str, result: BacktestResult):
        """添加回测结果"""
        self.results[name] = result
        
    def compare(self) -> ComparisonReport:
        """
        对比各引擎的回测结果
        
        Returns:
            对比报告
        """
        if len(self.results) < 2:
            return ComparisonReport(
                engine_names=list(self.results.keys()),
                metrics_comparison=pd.DataFrame(),
                consistency_score=0.0,
                warnings=["至少需要2个引擎的结果进行对比"],
                is_consistent=False
            )
        
        # 提取关键指标
        metrics_data = []
        for name, result in self.results.items():
            metrics_data.append({
                'engine': name,
                'total_return': result.total_return,
                'annual_return': result.annual_return,
                'max_drawdown': result.max_drawdown,
                'sharpe_ratio': result.sharpe_ratio,
                'total_trades': result.total_trades,
                'win_rate': result.win_rate,
            })
        
        df = pd.DataFrame(metrics_data)
        df.set_index('engine', inplace=True)
        
        # 检查一致性
        warnings = []
        is_consistent = True
        
        for metric, tolerance in self.TOLERANCE.items():
            values = df[metric].values
            if len(values) < 2:
                continue
                
            max_val = np.max(values)
            min_val = np.min(values)
            
            if metric == 'total_trades':
                # 交易次数必须完全一致
                if max_val != min_val:
                    warnings.append(f"交易次数不一致: {df[metric].to_dict()}")
                    is_consistent = False
            else:
                # 检查是否在容差范围内
                if max_val != 0:
                    diff_pct = abs(max_val - min_val) / abs(max_val)
                else:
                    diff_pct = abs(max_val - min_val)
                    
                if diff_pct > tolerance:
                    warnings.append(f"{metric} 差异过大 ({diff_pct:.2%}): {df[metric].to_dict()}")
                    is_consistent = False
        
        # 计算一致性得分
        if len(warnings) == 0:
            consistency_score = 100.0
        else:
            consistency_score = max(0, 100 - len(warnings) * 20)
        
        return ComparisonReport(
            engine_names=list(self.results.keys()),
            metrics_comparison=df,
            consistency_score=consistency_score,
            warnings=warnings,
            is_consistent=is_consistent
        )
    
    def recommend_engine(self) -> Optional[str]:
        """
        推荐最佳引擎
        
        基于结果一致性推荐最可靠的引擎
        """
        if not self.results:
            return None
        
        # 如果有多个引擎，优先选择CSKhQuant（基于QMT数据）
        if 'CSKhQuant' in self.results:
            return 'CSKhQuant'
        
        # 否则返回第一个
        return list(self.results.keys())[0]
    
    def print_report(self, report: ComparisonReport):
        """打印对比报告"""
        print("\n" + "="*80)
        print("跨引擎回测结果对比报告")
        print("="*80)
        
        print(f"\n参与对比的引擎: {', '.join(report.engine_names)}")
        print(f"一致性得分: {report.consistency_score:.1f}/100")
        print(f"结果是否一致: {'是' if report.is_consistent else '否'}")
        
        print("\n指标对比:")
        print(report.metrics_comparison.to_string())
        
        if report.warnings:
            print("\n警告:")
            for warning in report.warnings:
                print(f"  - {warning}")
        else:
            print("\n所有引擎结果一致，数据可信！")
        
        print("="*80)
