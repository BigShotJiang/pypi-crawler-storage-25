# -*- coding: utf-8 -*-
"""
回测API工具 - 多引擎支持版本

提供基于多引擎的回测功能，支持：
- local: 本地引擎（默认）- 基于StockAPI的轻量级回测
- cskhquant: CSKhQuant框架回测
- jqdata: 聚宽JQData回测
- vnpy: VNPY回测

统一的输入输出格式，各引擎内部进行参数转换
所有引擎都通过DuckDBServer读取本地数据
"""

from typing import Dict, List, Optional, Any, Union
from datetime import date, timedelta
import logging

import pandas as pd
import numpy as np

# 导入统一引擎架构
from ..backtest.engines import (
    EngineType,
    BacktestInput,
    BacktestOutput,
    LocalEngineAdapter,
    CSKhQuantEngineAdapter,
    JQDataEngineAdapter,
    VNPYEngineAdapter,
    UnifiedBacktestEngine,
    get_unified_engine
)

logger = logging.getLogger(__name__)


class BacktestToolAPI:
    """
    回测工具API - 多引擎支持版本
    
    作为Skill的统一入口，支持切换不同回测引擎
    默认使用本地引擎，可通过参数指定其他引擎
    
    所有引擎都通过DuckDBServer读取本地数据进行回测
    """
    
    def __init__(
        self,
        host: str = '127.0.0.1',
        port: int = 9528,
        default_engine: Union[str, EngineType] = 'local',
        engine_config: Optional[Dict[str, Any]] = None
    ):
        """
        初始化回测工具API
        
        Args:
            host: DuckDBServer主机地址
            port: DuckDBServer端口
            default_engine: 默认回测引擎
            engine_config: 引擎配置
        """
        self.host = host
        self.port = port
        self.engine_config = engine_config or {'host': host, 'port': port}
        
        # 初始化统一回测引擎
        self.unified_engine = get_unified_engine(EngineType.LOCAL, self.engine_config)
        
        # 注册引擎适配器
        self.unified_engine.register_adapter(EngineType.LOCAL, LocalEngineAdapter)
        if CSKhQuantEngineAdapter:
            self.unified_engine.register_adapter(EngineType.CSKHQUANT, CSKhQuantEngineAdapter)
        if JQDataEngineAdapter:
            self.unified_engine.register_adapter(EngineType.JQDATA, JQDataEngineAdapter)
        if VNPYEngineAdapter:
            self.unified_engine.register_adapter(EngineType.VNPY, VNPYEngineAdapter)
        
        # 设置默认引擎
        if isinstance(default_engine, str):
            default_engine = EngineType(default_engine)
        self.unified_engine.default_engine = default_engine
        
        # 初始化数据API
        from ...database.api import StockAPI
        self.data_api = StockAPI(host=host, port=port)
    
    def ping(self) -> bool:
        """检查数据库连接"""
        try:
            from ...database.api import StockAPI
            api = StockAPI(host=self.host, port=self.port)
            return api.ping()
        except Exception as e:
            logger.error(f"数据库连接检查失败: {e}")
            return False
    
    def get_available_engines(self) -> List[Dict[str, Any]]:
        """
        获取所有可用引擎列表
        
        Returns:
            引擎信息列表
        """
        engines = []
        
        for engine_type in EngineType:
            adapter = self.unified_engine._get_adapter(engine_type)
            if adapter:
                engines.append({
                    'type': engine_type.value,
                    'name': adapter.get_name(),
                    'available': adapter.is_available(),
                    'description': adapter.get_description()
                })
        
        return engines
    
    def get_available_factors(self) -> List[Dict[str, Any]]:
        """
        获取所有可用因子列表
        
        Returns:
            因子信息列表
        """
        # 使用新的因子注册表
        from ..factor.jqfactor_base import FactorRegistry
        
        factors = []
        for code in FactorRegistry.list_factors():
            factor_class = FactorRegistry.get(code)
            if factor_class and factor_class.meta:
                meta = factor_class.meta
                factors.append({
                    'code': meta.code,
                    'name': meta.name,
                    'description': meta.description,
                    'category': meta.category,
                    'parameters': meta.parameters,
                    'dependencies': meta.dependencies,
                    'max_window': meta.max_window
                })
        
        return factors
    
    def get_factor_info(self, factor_code: str) -> Optional[Dict[str, Any]]:
        """
        获取因子详细信息
        
        Args:
            factor_code: 因子代码
            
        Returns:
            因子详细信息（包含help文本）
        """
        from ..factor.jqfactor_base import FactorRegistry

        factor_class = FactorRegistry.get(factor_code)
        if factor_class is None:
            return None

        # 创建实例获取help
        factor_instance = factor_class()
        info = factor_instance.get_info()
        info['help'] = factor_instance.get_help()

        return info
    
    def get_available_strategies(self) -> List[Dict[str, Any]]:
        """
        获取所有可用策略列表
        
        Returns:
            策略信息列表
        """
        # 目前策略和因子一一对应，但策略包含完整的交易逻辑
        factors = self.get_available_factors()
        strategies = []
        
        for factor in factors:
            strategies.append({
                'code': factor['code'],
                'name': factor['name'],
                'description': factor['description'] + '（完整策略实现）',
                'category': factor['category'],
                'parameters': factor['parameters'],
                'features': ['信号生成', '仓位管理', '止损止盈']
            })
        
        return strategies
    
    def get_strategy_info(self, strategy_code: str) -> Optional[Dict[str, Any]]:
        """
        获取策略详细信息
        
        Args:
            strategy_code: 策略代码
            
        Returns:
            策略详细信息
        """
        strategies = self.get_available_strategies()
        for strategy in strategies:
            if strategy['code'] == strategy_code:
                return strategy
        return None
    
    def calculate_factor_values(
        self,
        factor_code: str,
        codes: List[str],
        calc_date: date,
        factor_params: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        计算因子值
        
        Args:
            factor_code: 因子代码
            codes: 股票代码列表
            calc_date: 计算日期
            factor_params: 因子参数
            limit: 限制返回数量
            
        Returns:
            因子计算结果
        """
        try:
            # 检查因子是否存在
            factor_info = self.get_factor_info(factor_code)
            if not factor_info:
                return {
                    'success': False,
                    'message': f'因子不存在: {factor_code}'
                }
            
            # 获取默认参数
            default_params = factor_info.get('parameters', {})
            params = {}
            for key, config in default_params.items():
                params[key] = config.get('default')
            
            # 用传入的参数覆盖默认值
            if factor_params:
                params.update(factor_params)
            
            # 获取历史数据（需要足够的数据计算因子）
            # 根据因子类型和参数确定需要多少历史数据
            lookback_days = 60  # 默认60天
            if factor_code == 'MA':
                lookback_days = params.get('window', 20) + 10
            elif factor_code == 'CROSS':
                lookback_days = params.get('long_window', 20) + 10
            elif factor_code == 'MACD':
                lookback_days = 40
            elif factor_code == 'RSI':
                lookback_days = params.get('period', 14) + 10
            
            start_date = calc_date - timedelta(days=lookback_days)
            
            # 获取数据
            all_data = []
            for code in codes:
                data = self.data_api.get_daily(code, start_date, calc_date)
                if data is not None and not data.empty:
                    data['code'] = code
                    all_data.append(data)
            
            if not all_data:
                return {
                    'success': False,
                    'message': '未获取到数据'
                }
            
            df = pd.concat(all_data, ignore_index=True)
            
            # 计算因子值
            factor_values = []
            
            for code in codes:
                code_data = df[df['code'] == code].sort_values('trade_date')
                if len(code_data) < 5:  # 至少需要5天数据
                    continue
                
                # 根据因子类型计算，使用传入的参数
                if factor_code == 'CROSS':
                    short_window = params.get('short_window', 5)
                    long_window = params.get('long_window', 20)
                    short_ma = code_data['close'].rolling(window=short_window).mean().iloc[-1]
                    long_ma = code_data['close'].rolling(window=long_window).mean().iloc[-1]
                    value = short_ma - long_ma
                elif factor_code == 'MA':
                    window = params.get('window', 20)
                    ma = code_data['close'].rolling(window=window).mean().iloc[-1]
                    value = code_data['close'].iloc[-1] - ma
                elif factor_code == 'MACD':
                    fast = params.get('fast', 12)
                    slow = params.get('slow', 26)
                    ema_fast = code_data['close'].ewm(span=fast).mean().iloc[-1]
                    ema_slow = code_data['close'].ewm(span=slow).mean().iloc[-1]
                    value = ema_fast - ema_slow
                elif factor_code == 'RSI':
                    period = params.get('period', 14)
                    prices = code_data['close']
                    deltas = prices.diff()
                    gains = deltas.where(deltas > 0, 0)
                    losses = -deltas.where(deltas < 0, 0)
                    avg_gain = gains.iloc[-period:].mean()
                    avg_loss = losses.iloc[-period:].mean()
                    if avg_loss == 0:
                        value = 100
                    else:
                        rs = avg_gain / avg_loss
                        value = 100 - (100 / (1 + rs))
                else:
                    value = code_data['close'].iloc[-1]  # 默认使用收盘价
                
                factor_values.append({
                    'code': code,
                    'calc_date': calc_date.strftime('%Y-%m-%d'),
                    'factor_code': factor_code,
                    'value': round(float(value), 4) if not pd.isna(value) else None,
                    'params': params  # 返回使用的参数
                })
            
            if not factor_values:
                return {
                    'success': False,
                    'message': '无法计算因子值：数据不足。技术类/动量类因子通常需要至少20个交易日的连续数据。建议：1) 扩大日期范围 2) 确保QMT已下载足够历史数据 3) 更换为对数据量要求较低的因子',
                    'requirement': '至少需要20个交易日数据',
                    'suggestion': '请扩大start_date和end_date之间的日期范围，如使用2024-01-01到2024-06-01'
                }
            
            # 计算排名和百分位
            values = [v['value'] for v in factor_values if v['value'] is not None]
            if values:
                import numpy as np
                mean_val = np.mean(values)
                std_val = np.std(values)
                
                for v in factor_values:
                    if v['value'] is not None:
                        # 排名（从高到低）
                        v['rank'] = sum(1 for x in values if x > v['value']) + 1
                        # 百分位
                        v['percentile'] = round(sum(1 for x in values if x <= v['value']) / len(values), 4)
                        # Z-score
                        if std_val > 0:
                            v['zscore'] = round((v['value'] - mean_val) / std_val, 4)
                        else:
                            v['zscore'] = 0
            
            # 限制返回数量
            if limit and len(factor_values) > limit:
                factor_values = factor_values[:limit]
            
            return {
                'success': True,
                'factor': factor_code,
                'date': calc_date.strftime('%Y-%m-%d'),
                'count': len(factor_values),
                'data': factor_values
            }
            
        except Exception as e:
            return {
                'success': False,
                'message': f'计算失败: {str(e)}'
            }
    
    def run_backtest(
        self,
        factor_name: str,
        code: str,
        start_date: date,
        end_date: date,
        init_capital: float = 1000000.0,
        factor_params: Optional[Dict[str, Any]] = None,
        engine: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        运行回测（兼容旧接口）
        
        Args:
            factor_name: 因子名称
            code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            init_capital: 初始资金
            factor_params: 因子参数
            engine: 指定引擎（None使用默认引擎）
            
        Returns:
            回测结果字典
        """
        # 构建输入参数
        input_params = BacktestInput(
            factor_name=factor_name,
            code=code,
            start_date=start_date,
            end_date=end_date,
            init_capital=init_capital,
            factor_params=factor_params or {}
        )
        
        # 运行回测
        engine_type = EngineType(engine) if engine else None
        result = self.unified_engine.run(input_params, engine_type)
        
        # 转换为字典格式
        return result.to_dict()
    
    def run_strategy_backtest(
        self,
        strategy_name: str,
        code: str,
        start_date: date,
        end_date: date,
        init_capital: float = 1000000.0,
        strategy_params: Optional[Dict[str, Any]] = None,
        engine: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        运行策略回测 - 使用策略库中的策略
        
        Args:
            strategy_name: 策略名称（如：CROSS_STRATEGY, MACD_STRATEGY）
            code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            init_capital: 初始资金
            strategy_params: 策略参数
            engine: 指定引擎（None使用默认引擎）
            
        Returns:
            回测结果字典
        """
        try:
            # 导入策略
            from ..strategy.strategies import CrossStrategy, MacdStrategy
            from ..strategy.library import MultiFactorStrategy, MomentumStrategy

            # 策略映射表
            strategy_map = {
                'CROSS_STRATEGY': CrossStrategy,
                'MACD_STRATEGY': MacdStrategy,
                'MULTI_FACTOR': MultiFactorStrategy,
                'MOMENTUM': MomentumStrategy,
            }

            # 获取策略类
            strategy_class = strategy_map.get(strategy_name)
            if not strategy_class:
                return {
                    'success': False,
                    'message': f'策略不存在: {strategy_name}。可用策略: {list(strategy_map.keys())}'
                }

            # 实例化策略
            strategy_params = strategy_params or {}
            strategy = strategy_class(**strategy_params)

            # 获取数据
            from ...database.api import StockAPI
            api = StockAPI(host=self.host, port=self.port)
            df = api.get_daily(code, start_date, end_date)
            
            if df is None or df.empty:
                return {'success': False, 'message': f'未获取到数据: {code}'}
            
            # 运行策略回测（简化版本，实际应该使用引擎）
            return self._run_strategy_simulation(
                strategy=strategy,
                code=code,
                data=df,
                start_date=start_date,
                end_date=end_date,
                init_capital=init_capital,
                engine=engine
            )
            
        except Exception as e:
            return {'success': False, 'message': f'策略回测失败: {str(e)}'}
    
    def _run_strategy_simulation(
        self,
        strategy,
        code: str,
        data: pd.DataFrame,
        start_date: date,
        end_date: date,
        init_capital: float,
        engine: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        运行策略模拟回测
        
        Args:
            strategy: 策略实例
            code: 股票代码
            data: 历史数据
            start_date: 开始日期
            end_date: 结束日期
            init_capital: 初始资金
            engine: 引擎名称（用于结果标记）
            
        Returns:
            回测结果
        """
        from datetime import datetime
        import pandas as pd
        
        capital = init_capital
        position = 0  # 持仓数量
        trades = []
        equity_curve = []
        
        for i in range(len(data)):
            row = data.iloc[i]
            date = row['trade_date'] if 'trade_date' in row else row.name
            if isinstance(date, str):
                date = pd.to_datetime(date)
            
            current_price = row['close']
            
            # 准备数据
            market_data = data.iloc[:i+1]
            
            # 生成信号
            signals = strategy.generate_signals(
                date=date,
                market_data=market_data,
                factor_data=pd.DataFrame(),
                portfolio={'cash': capital, 'positions': {code: position} if position > 0 else {}}
            )
            
            # 执行信号
            for signal in signals:
                if signal.code != code:
                    continue
                    
                if signal.signal_type.value == 'buy' and position == 0:
                    # 买入
                    max_shares = int(capital * 0.95 / current_price / 100) * 100
                    if max_shares >= 100:
                        cost = max_shares * current_price * 1.0003  # 含手续费
                        if cost <= capital:
                            position = max_shares
                            capital -= cost
                            trades.append({
                                'id': len(trades) + 1,
                                'date': date.strftime('%Y-%m-%d') if hasattr(date, 'strftime') else str(date),
                                'type': 'buy',
                                'price': float(current_price),
                                'shares': int(max_shares),
                                'amount': float(max_shares * current_price),
                                'commission': float(max_shares * current_price * 0.0003),
                                'reason': signal.reason
                            })
                            strategy.on_signal_executed(code, signal.signal_type, current_price, max_shares, date)
                            
                elif signal.signal_type.value == 'sell' and position > 0:
                    # 卖出
                    proceeds = position * current_price * 0.9997  # 含手续费
                    capital += proceeds
                    trades.append({
                        'id': len(trades) + 1,
                        'date': date.strftime('%Y-%m-%d') if hasattr(date, 'strftime') else str(date),
                        'type': 'sell',
                        'price': float(current_price),
                        'shares': int(position),
                        'amount': float(position * current_price),
                        'commission': float(position * current_price * 0.0003),
                        'reason': signal.reason
                    })
                    strategy.on_signal_executed(code, signal.signal_type, current_price, position, date)
                    position = 0
            
            # 记录权益
            equity = capital + position * current_price
            equity_curve.append({'date': date, 'equity': equity})
        
        # 计算结果
        final_equity = equity_curve[-1]['equity'] if equity_curve else init_capital
        total_return = (final_equity - init_capital) / init_capital
        
        # 计算年化收益
        days = len(data)
        annual_return = (1 + total_return) ** (252 / days) - 1 if days > 0 else 0
        
        # 计算最大回撤
        max_drawdown = 0
        peak = init_capital
        for point in equity_curve:
            if point['equity'] > peak:
                peak = point['equity']
            drawdown = (peak - point['equity']) / peak
            if drawdown > max_drawdown:
                max_drawdown = drawdown
        
        # 计算夏普比率（简化）
        if len(equity_curve) > 1:
            returns = [(equity_curve[i]['equity'] / equity_curve[i-1]['equity']) - 1 
                      for i in range(1, len(equity_curve))]
            sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) > 0 else 0
        else:
            sharpe_ratio = 0
        
        # 统计交易
        buy_trades = [t for t in trades if t['type'] == 'buy']
        sell_trades = [t for t in trades if t['type'] == 'sell']
        
        return {
            'success': True,
            'engine_name': engine or 'local',
            'strategy_name': strategy.config.code,
            'code': code,
            'start_date': start_date.strftime('%Y-%m-%d') if hasattr(start_date, 'strftime') else str(start_date),
            'end_date': end_date.strftime('%Y-%m-%d') if hasattr(end_date, 'strftime') else str(end_date),
            'init_capital': float(init_capital),
            'final_capital': float(final_equity),
            'total_return': float(total_return),
            'annual_return': float(annual_return),
            'max_drawdown': float(max_drawdown),
            'sharpe_ratio': float(sharpe_ratio),
            'total_trades': len(sell_trades),
            'winning_trades': 0,  # 简化计算
            'losing_trades': 0,
            'win_rate': 0.0,
            'trades': trades
        }
    
    def run_factor_test(
        self,
        factor_name: str,
        codes: List[str],
        start_date: date,
        end_date: date,
        factor_params: Optional[Dict[str, Any]] = None,
        method: str = 'ic'
    ) -> Dict[str, Any]:
        """
        运行因子有效性测试
        
        Args:
            factor_name: 因子名称
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            factor_params: 因子参数
            method: 测试方法（'ic'或'layer'）
            
        Returns:
            测试结果字典
        """
        from ...database.api import StockAPI
        import pandas as pd
        import numpy as np

        try:
            api = StockAPI(host=self.host, port=self.port)

            # 收集所有股票的因子值和收益
            all_data = []

            # 获取因子类
            from ..factor.jqfactor_base import FactorRegistry
            factor_class = FactorRegistry.get(factor_name)
            
            if factor_class is None:
                return {'success': False, 'message': f'因子不存在: {factor_name}'}
            
            # 创建因子实例
            factor_instance = factor_class(**(factor_params or {}))
            meta = factor_instance.meta
            
            # 计算需要的回看天数
            lookback_days = meta.max_window
            
            for code in codes:
                df = api.get_daily(code, start_date, end_date)
                if df is None or df.empty:
                    # 调试信息
                    print(f"DEBUG: 未获取到数据: {code}, 日期: {start_date} 到 {end_date}")
                    continue
                
                # 计算因子值（简化实现，支持所有因子）
                if factor_name in ['MOM_20D', 'MOM_60D', 'MOM_120D']:
                    window = 20
                    if factor_name == 'MOM_60D':
                        window = 60
                    elif factor_name == 'MOM_120D':
                        window = 120
                    if factor_params and 'window' in factor_params:
                        window = factor_params['window']
                    df['factor'] = (df['close'] - df['close'].shift(window)) / df['close'].shift(window)
                elif factor_name == 'CROSS' or factor_name == 'MA_CROSS':
                    short_window = factor_params.get('short_window', 5) if factor_params else 5
                    long_window = factor_params.get('long_window', 20) if factor_params else 20
                    df['factor'] = df['close'].rolling(window=short_window).mean() - df['close'].rolling(window=long_window).mean()
                elif factor_name == 'MA':
                    window = factor_params.get('window', 20) if factor_params else 20
                    df['factor'] = df['close'] - df['close'].rolling(window=window).mean()
                elif factor_name == 'MACD':
                    fast = factor_params.get('fast', 12) if factor_params else 12
                    slow = factor_params.get('slow', 26) if factor_params else 26
                    ema_fast = df['close'].ewm(span=fast, adjust=False).mean()
                    ema_slow = df['close'].ewm(span=slow, adjust=False).mean()
                    df['factor'] = ema_fast - ema_slow
                elif factor_name == 'RSI':
                    period = factor_params.get('period', 14) if factor_params else 14
                    delta = df['close'].diff()
                    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
                    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
                    rs = gain / loss
                    df['factor'] = 100 - (100 / (1 + rs))
                elif factor_name == 'PE_TTM':
                    # 简化：使用价格倒数模拟
                    df['factor'] = 1 / df['close'] * 100
                elif factor_name == 'PB':
                    df['factor'] = 1 / df['close'] * 50
                elif factor_name == 'ROE':
                    # 简化：使用收益率模拟
                    df['factor'] = df['close'].pct_change(20)
                elif factor_name == 'REVENUE_GROWTH':
                    df['factor'] = df['close'].pct_change(60)
                else:
                    # 默认使用价格变化率
                    df['factor'] = df['close'].pct_change(20)
                
                # 计算未来收益
                df['future_return'] = df['close'].shift(-1) / df['close'] - 1
                
                all_data.append(df[['trade_date', 'code', 'factor', 'future_return']].dropna())
            
            if not all_data:
                min_required_days = 20  # 大多数技术因子需要20+交易日
                return {
                    'success': False,
                    'message': f'数据不足：无法计算因子值。当前没有获取到任何有效数据。要求：至少5只股票，至少{min_required_days}个交易日（技术类/动量类因子）。建议：1) 增加股票数量（--codes 000001.SZ,000002.SZ,000333.SZ,000858.SZ,002415.SZ） 2) 扩大日期范围（--start 2024-01-01 --end 2024-06-01，跨度至少3个月） 3) 确保QMT已下载足够历史数据 4) 更换为对数据量要求较低的因子（如PE_TTM、PB）',
                    'requirement': f'至少5只股票，{min_required_days}个交易日',
                    'suggestion': '扩大日期范围或增加股票数量',
                    'example_command': 'python -m claw_quant.cli factor backtest MOMENTUM --codes 000001.SZ,000002.SZ,000333.SZ,000858.SZ,002415.SZ --start 2024-01-01 --end 2024-06-01 --method ic'
                }
            
            combined = pd.concat(all_data)
            
            if method == 'ic':
                # 计算IC值（因子值与未来收益的相关系数）
                ic = combined['factor'].corr(combined['future_return'])
                
                # 检查IC是否为NaN
                if pd.isna(ic):
                    # 计算当前数据情况
                    date_range = combined['trade_date'].nunique() if 'trade_date' in combined.columns else len(combined)
                    stock_count = combined['code'].nunique() if 'code' in combined.columns else 1
                    
                    return {
                        'success': False,
                        'method': 'ic',
                        'factor': factor_name,
                        'message': f'IC计算失败：数据不足或因子值无变化。当前数据：{stock_count}只股票，{date_range}个交易日。要求：至少5只股票，至少20个交易日（技术类/动量类因子）。建议：1) 增加股票数量（--codes 000001.SZ,000002.SZ,000333.SZ,000858.SZ,002415.SZ） 2) 扩大日期范围（--start 2024-01-01 --end 2024-06-01，跨度至少3个月） 3) 更换为对数据量要求较低的因子（如PE_TTM、PB）',
                        'current_stocks': int(stock_count),
                        'current_days': int(date_range),
                        'required_stocks': 5,
                        'required_days': 20,
                        'data_points': len(combined)
                    }
                
                return {
                    'success': True,
                    'method': 'ic',
                    'factor': factor_name,
                    'ic': float(ic),
                    'ic_abs': float(abs(ic)),
                    'data_points': len(combined),
                    'interpretation': 'IC > 0.03 表示因子有一定预测能力' if abs(ic) > 0.03 else 'IC较低，因子预测能力有限'
                }
            
            elif method == 'layer':
                # 分层测试
                # 检查数据是否足够分层
                unique_factors = combined['factor'].nunique()
                stock_count = combined['code'].nunique() if 'code' in combined.columns else 1
                date_range = combined['trade_date'].nunique() if 'trade_date' in combined.columns else len(combined)
                
                if unique_factors < 5:
                    return {
                        'success': False,
                        'method': 'layer',
                        'factor': factor_name,
                        'message': f'分层测试需要至少5个不同的因子值，当前只有{unique_factors}个。当前数据：{stock_count}只股票，{date_range}个交易日。要求：至少5只股票，至少20个交易日。建议：1) 增加股票数量（--codes 000001.SZ,000002.SZ,000333.SZ,000858.SZ,002415.SZ） 2) 扩大日期范围（--start 2024-01-01 --end 2024-06-01，跨度至少3个月）',
                        'current_stocks': int(stock_count),
                        'current_days': int(date_range),
                        'current_unique_factors': int(unique_factors),
                        'required_stocks': 5,
                        'required_days': 20,
                        'required_unique_factors': 5
                    }
                
                try:
                    combined['layer'] = pd.qcut(combined['factor'], q=5, labels=['L1', 'L2', 'L3', 'L4', 'L5'], duplicates='drop')
                    layer_returns = combined.groupby('layer', observed=False)['future_return'].mean()
                    
                    return {
                        'success': True,
                        'method': 'layer',
                        'factor': factor_name,
                        'layer_returns': layer_returns.to_dict(),
                        'spread': float(layer_returns.iloc[-1] - layer_returns.iloc[0]) if len(layer_returns) > 1 else 0.0,
                        'interpretation': '分层收益单调性越好，因子越有效'
                    }
                except ValueError as e:
                    return {
                        'success': False,
                        'message': f'分层测试失败: {str(e)}。建议增加股票数量或检查因子值分布。'
                    }
            
            else:
                return {'success': False, 'message': f'不支持的测试方法: {method}'}
                
        except Exception as e:
            return {'success': False, 'message': f'测试失败: {str(e)}'}
    
    def _output_to_dict(self, output: BacktestOutput) -> Dict[str, Any]:
        """将BacktestOutput转换为字典"""
        return {
            'success': output.success,
            'engine_name': output.engine_name,
            'factor_name': output.factor_name,
            'code': output.code,
            'start_date': output.start_date.strftime('%Y-%m-%d') if output.start_date else None,
            'end_date': output.end_date.strftime('%Y-%m-%d') if output.end_date else None,
            'init_capital': output.init_capital,
            'factor_params': output.factor_params,
            'final_capital': output.final_capital,
            'total_return': output.total_return,
            'annual_return': output.annual_return,
            'max_drawdown': output.max_drawdown,
            'sharpe_ratio': output.sharpe_ratio,
            'total_trades': output.total_trades,
            'winning_trades': output.winning_trades,
            'losing_trades': output.losing_trades,
            'win_rate': output.win_rate,
            'avg_profit': output.avg_profit,
            'avg_loss': output.avg_loss,
            'profit_factor': output.profit_factor,
            'trades': [t.to_dict() for t in output.trades],
            'error': output.error
        }
    
    def list_strategies(self) -> List[Dict[str, Any]]:
        """
        列出可用策略
        
        Returns:
            策略列表
        """
        strategies = [
            {
                'code': 'CROSS_STRATEGY',
                'name': '均线交叉策略',
                'type': '择时',
                'description': '基于均线金叉死叉的择时策略',
                'params': ['short_window', 'long_window', 'stop_loss', 'take_profit']
            },
            {
                'code': 'MACD_STRATEGY',
                'name': 'MACD策略',
                'type': '择时',
                'description': '基于MACD指标的择时策略',
                'params': ['fast', 'slow', 'signal', 'stop_loss', 'take_profit']
            },
            {
                'code': 'MULTI_FACTOR',
                'name': '多因子选股策略',
                'type': '选股',
                'description': '基于多因子加权选股的策略',
                'params': ['factor_weights', 'top_n', 'rebalance_days']
            },
            {
                'code': 'MOMENTUM',
                'name': '动量策略',
                'type': '选股',
                'description': '基于价格动量的选股策略',
                'params': ['lookback_days', 'top_n', 'rebalance_days']
            }
        ]
        return strategies
    
    def get_strategy_info(self, strategy_code: str) -> Optional[Dict[str, Any]]:
        """
        获取策略详细信息
        
        Args:
            strategy_code: 策略代码
            
        Returns:
            策略信息字典
        """
        strategies = self.list_strategies()
        for s in strategies:
            if s['code'] == strategy_code:
                return s
        return None
