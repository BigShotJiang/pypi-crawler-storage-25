# -*- coding: utf-8 -*-
"""
API 模块 - 对外提供统一的接口

该模块提供 CLI 和外部工具调用的统一 API 接口
"""

from .backtest_api import BacktestToolAPI

__all__ = ['BacktestToolAPI']
