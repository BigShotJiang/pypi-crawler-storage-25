"""
策略管理器
"""
import pandas as pd
from typing import List, Dict, Optional, Any
from datetime import datetime, date
import logging

from .base import BaseStrategy, StrategyConfig, Signal
from .strategies import PREDEFINED_STRATEGIES, get_strategy_by_code

logger = logging.getLogger(__name__)


class StrategyManager:
    """策略管理器"""
    
    def __init__(self, db_manager):
        """
        初始化策略管理器
        
        Args:
            db_manager: 数据库管理器
        """
        self.db = db_manager
        self.strategies: Dict[str, BaseStrategy] = {}
        
        # 注册预定义策略
        self._register_predefined_strategies()
        
    def _register_predefined_strategies(self):
        """注册预定义策略"""
        for strategy in PREDEFINED_STRATEGIES:
            self.register_strategy(strategy)
            
    def register_strategy(self, strategy: BaseStrategy):
        """注册策略"""
        self.strategies[strategy.config.code] = strategy
        
        # 保存到数据库
        self.db.conn.execute("""
            INSERT INTO strategy_definitions 
            (strategy_code, strategy_name, strategy_type, description, factor_codes, 
             entry_conditions, exit_conditions, position_sizing, status, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', now())
            ON CONFLICT (strategy_code) DO UPDATE SET
                strategy_name = EXCLUDED.strategy_name,
                strategy_type = EXCLUDED.strategy_type,
                description = EXCLUDED.description,
                factor_codes = EXCLUDED.factor_codes,
                entry_conditions = EXCLUDED.entry_conditions,
                exit_conditions = EXCLUDED.exit_conditions,
                position_sizing = EXCLUDED.position_sizing,
                updated_at = now()
        """, [
            strategy.config.code,
            strategy.config.name,
            strategy.config.strategy_type,
            strategy.config.description,
            strategy.config.factor_codes,
            str(strategy.config.entry_conditions),
            str(strategy.config.exit_conditions),
            str(strategy.config.position_sizing)
        ])
        
        logger.info(f"注册策略: {strategy.config.code}")
        
    def get_strategy(self, code: str) -> Optional[BaseStrategy]:
        """获取策略"""
        return self.strategies.get(code)
        
    def list_strategies(self, strategy_type: Optional[str] = None) -> List[BaseStrategy]:
        """列出所有策略"""
        if strategy_type:
            return [s for s in self.strategies.values() if s.config.strategy_type == strategy_type]
        return list(self.strategies.values())
        
    def generate_signals(self,
                         strategy_code: str,
                         current_date: datetime,
                         codes: Optional[List[str]] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            strategy_code: 策略代码
            current_date: 当前日期
            codes: 股票代码列表
            
        Returns:
            信号列表
        """
        strategy = self.strategies.get(strategy_code)
        if not strategy:
            logger.error(f"策略不存在: {strategy_code}")
            return []
            
        logger.info(f"生成信号: {strategy_code} @ {current_date}")
        
        # 获取股票列表
        if codes is None:
            stocks_df = self.db.get_all_stocks()
            codes = stocks_df['code'].tolist()[:100]  # 限制数量
            
        # 获取市场数据
        from datetime import timedelta
        start_date = current_date - timedelta(days=60)
        market_data = self.db.get_market_data_daily_multi(codes, start_date, current_date)
        
        # 获取因子数据
        factor_codes = strategy.config.factor_codes
        if factor_codes:
            factor_data = self.db.get_factor_values(factor_codes, current_date, codes)
        else:
            factor_data = pd.DataFrame()
            
        # 生成信号
        signals = strategy.generate_signals(current_date, market_data, factor_data)
        
        # 保存信号
        for signal in signals:
            self.db.save_strategy_signal(signal.to_dict())
            
        logger.info(f"生成 {len(signals)} 个信号")
        return signals
        
    def generate_all_signals(self,
                             current_date: datetime,
                             codes: Optional[List[str]] = None) -> Dict[str, List[Signal]]:
        """
        生成所有策略的信号
        
        Args:
            current_date: 当前日期
            codes: 股票代码列表
            
        Returns:
            {strategy_code: [signals]}
        """
        all_signals = {}
        
        for strategy_code in self.strategies.keys():
            try:
                signals = self.generate_signals(strategy_code, current_date, codes)
                all_signals[strategy_code] = signals
            except Exception as e:
                logger.error(f"生成信号失败 {strategy_code}: {e}")
                all_signals[strategy_code] = []
                
        return all_signals
        
    def get_signals(self,
                    strategy_code: Optional[str] = None,
                    start_date: Optional[date] = None,
                    end_date: Optional[date] = None,
                    executed: Optional[bool] = None) -> pd.DataFrame:
        """
        获取历史信号
        
        Args:
            strategy_code: 策略代码
            start_date: 开始日期
            end_date: 结束日期
            executed: 是否已执行
            
        Returns:
            DataFrame
        """
        query = "SELECT * FROM strategy_signals WHERE 1=1"
        params = []
        
        if strategy_code:
            query += " AND strategy_code = ?"
            params.append(strategy_code)
            
        if start_date:
            query += " AND DATE(signal_time) >= ?"
            params.append(start_date)
            
        if end_date:
            query += " AND DATE(signal_time) <= ?"
            params.append(end_date)
            
        if executed is not None:
            query += " AND executed = ?"
            params.append(executed)
            
        query += " ORDER BY signal_time DESC"
        
        return self.db.conn.execute(query, params).fetchdf()
        
    def create_strategy(self,
                        code: str,
                        name: str,
                        strategy_type: str,
                        factor_codes: List[str],
                        entry_conditions: Dict,
                        exit_conditions: Dict,
                        position_sizing: Optional[Dict] = None) -> BaseStrategy:
        """
        创建新策略
        
        Args:
            code: 策略代码
            name: 策略名称
            strategy_type: 策略类型
            factor_codes: 因子代码列表
            entry_conditions: 入场条件
            exit_conditions: 出场条件
            position_sizing: 仓位管理
            
        Returns:
            策略实例
        """
        config = StrategyConfig(
            code=code,
            name=name,
            strategy_type=strategy_type,
            factor_codes=factor_codes,
            entry_conditions=entry_conditions,
            exit_conditions=exit_conditions,
            position_sizing=position_sizing or {'type': 'equal', 'max_position': 0.1}
        )
        
        # 创建策略类
        class CustomStrategy(BaseStrategy):
            def generate_signals(self, date, market_data, factor_data, portfolio=None):
                signals = []
                
                # 简化实现：基于因子值生成信号
                if factor_data.empty:
                    return signals
                    
                # 按因子加权排序
                if self.config.factor_codes:
                    factor_values = factor_data[factor_data['factor_code'].isin(self.config.factor_codes)]
                    
                    if not factor_values.empty:
                        # 按code分组计算平均因子值
                        avg_factors = factor_values.groupby('code')['value'].mean()
                        
                        # 买入前N
                        top_n = avg_factors.nlargest(10)
                        for code, value in top_n.items():
                            if value > 0:
                                signals.append(Signal(
                                    strategy_code=self.config.code,
                                    code=code,
                                    signal_type=SignalType.BUY,
                                    signal_time=date,
                                    strength=min(value, 1.0),
                                    reason=f"因子得分: {value:.2f}"
                                ))
                                
                return signals
        
        strategy = CustomStrategy(config)
        self.register_strategy(strategy)
        
        return strategy
        
    def update_strategy_status(self, strategy_code: str, status: str):
        """更新策略状态"""
        self.db.conn.execute("""
            UPDATE strategy_definitions 
            SET status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE strategy_code = ?
        """, [status, strategy_code])
        
        logger.info(f"更新策略状态: {strategy_code} -> {status}")
        
    def delete_strategy(self, strategy_code: str):
        """删除策略"""
        if strategy_code in self.strategies:
            del self.strategies[strategy_code]
            
        self.db.conn.execute(
            "DELETE FROM strategy_definitions WHERE strategy_code = ?",
            [strategy_code]
        )
        
        logger.info(f"删除策略: {strategy_code}")
        
    def get_strategy_performance(self, 
                                  strategy_code: str,
                                  days: int = 30) -> Dict:
        """
        获取策略表现统计
        
        Args:
            strategy_code: 策略代码
            days: 统计天数
            
        Returns:
            统计信息
        """
        from datetime import timedelta
        
        start_date = date.today() - timedelta(days=days)
        
        # 获取信号
        signals_df = self.get_signals(
            strategy_code=strategy_code,
            start_date=start_date
        )
        
        if signals_df.empty:
            return {
                'total_signals': 0,
                'buy_signals': 0,
                'sell_signals': 0,
                'executed_rate': 0
            }
            
        total = len(signals_df)
        buy_count = len(signals_df[signals_df['signal_type'] == 'buy'])
        sell_count = len(signals_df[signals_df['signal_type'] == 'sell'])
        executed = len(signals_df[signals_df['executed'] == True])
        
        return {
            'total_signals': total,
            'buy_signals': buy_count,
            'sell_signals': sell_count,
            'executed_rate': executed / total if total > 0 else 0
        }
