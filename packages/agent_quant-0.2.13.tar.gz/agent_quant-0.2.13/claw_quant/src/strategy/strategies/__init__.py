# -*- coding: utf-8 -*-
"""
策略库

存放用户自定义策略
"""

from .cross_strategy import CrossStrategy
from .macd_strategy import MacdStrategy

__all__ = [
    'CrossStrategy',
    'MacdStrategy',
]
