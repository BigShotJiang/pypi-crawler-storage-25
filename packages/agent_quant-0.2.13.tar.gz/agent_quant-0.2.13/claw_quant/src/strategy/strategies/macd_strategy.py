# -*- coding: utf-8 -*-
"""
MACD策略示例

基于MACD指标的完整交易策略，包含：
- 信号生成：MACD金叉买入，死叉卖出
- 仓位管理：等权重仓位
- 风控：止损止盈
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from datetime import datetime

from ..base import BaseStrategy, StrategyConfig, Signal, SignalType


class MacdStrategy(BaseStrategy):
    """
    MACD策略
    
    使用MACD指标生成交易信号：
    - DIF上穿DEA（金叉）→ 买入
    - DIF下穿DEA（死叉）→ 卖出
    
    参数:
        fast: 快线周期，默认12
        slow: 慢线周期，默认26
        signal: 信号线周期，默认9
    """
    
    def __init__(self, 
                 fast: int = 12,
                 slow: int = 26,
                 signal: int = 9,
                 stop_loss: float = 0.08,
                 take_profit: float = 0.15):
        """
        初始化MACD策略
        
        Args:
            fast: 快线周期
            slow: 慢线周期
            signal: 信号线周期
            stop_loss: 止损比例
            take_profit: 止盈比例
        """
        config = StrategyConfig(
            code='MACD_STRATEGY',
            name='MACD策略',
            strategy_type='择时',
            description='基于MACD指标的择时策略',
            factor_codes=['MACD'],
            position_sizing={'type': 'equal', 'max_position': 0.2},
            risk_management={'stop_loss': stop_loss, 'take_profit': take_profit}
        )
        super().__init__(config)
        
        self.fast = fast
        self.slow = slow
        self.signal = signal
        
        # 记录持仓状态
        self.positions: Dict[str, Dict] = {}
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            date: 当前日期
            market_data: 市场数据
            factor_data: 因子数据
            portfolio: 当前持仓
            
        Returns:
            交易信号列表
        """
        signals = []
        
        if market_data.empty or len(market_data) < self.slow:
            return signals
        
        # 计算MACD
        data = market_data.copy()
        exp1 = data['close'].ewm(span=self.fast, adjust=False).mean()
        exp2 = data['close'].ewm(span=self.slow, adjust=False).mean()
        data['macd'] = exp1 - exp2
        data['signal'] = data['macd'].ewm(span=self.signal, adjust=False).mean()
        data['histogram'] = data['macd'] - data['signal']
        
        # 计算金叉死叉
        data['cross'] = 0
        data.loc[data['macd'] > data['signal'], 'cross'] = 1
        data['cross_signal'] = data['cross'].diff()
        
        # 获取最新数据
        latest = data.iloc[-1]
        code = latest.get('code', 'unknown')
        current_price = latest['close']
        
        # 检查是否有持仓
        has_position = code in self.positions
        
        # 金叉信号 - 买入
        if latest['cross_signal'] == 1 and not has_position:
            signals.append(Signal(
                strategy_code=self.config.code,
                code=code,
                signal_type=SignalType.BUY,
                signal_time=date,
                price=current_price,
                strength=0.8,
                reason=f"MACD金叉，DIF({latest['macd']:.3f})上穿DEA({latest['signal']:.3f})"
            ))
            
        # 死叉信号 - 卖出
        elif latest['cross_signal'] == -1 and has_position:
            signals.append(Signal(
                strategy_code=self.config.code,
                code=code,
                signal_type=SignalType.SELL,
                signal_time=date,
                price=current_price,
                strength=0.8,
                reason=f"MACD死叉，DIF({latest['macd']:.3f})下穿DEA({latest['signal']:.3f})"
            ))
            
        # 检查止损止盈
        if has_position:
            pos = self.positions[code]
            entry_price = pos['entry_price']
            
            if self.check_stop_loss(code, entry_price, current_price):
                signals.append(Signal(
                    strategy_code=self.config.code,
                    code=code,
                    signal_type=SignalType.SELL,
                    signal_time=date,
                    price=current_price,
                    strength=1.0,
                    reason=f"触发止损，亏损{(current_price - entry_price) / entry_price:.2%}"
                ))
            elif self.check_take_profit(code, entry_price, current_price):
                signals.append(Signal(
                    strategy_code=self.config.code,
                    code=code,
                    signal_type=SignalType.SELL,
                    signal_time=date,
                    price=current_price,
                    strength=1.0,
                    reason=f"触发止盈，盈利{(current_price - entry_price) / entry_price:.2%}"
                ))
        
        return signals
    
    def on_signal_executed(self, code: str, signal_type: SignalType, 
                          price: float, volume: int, date: datetime):
        """信号执行回调"""
        if signal_type == SignalType.BUY:
            self.positions[code] = {
                'entry_price': price,
                'volume': volume,
                'entry_date': date
            }
        elif signal_type in [SignalType.SELL, SignalType.CLOSE]:
            if code in self.positions:
                del self.positions[code]
