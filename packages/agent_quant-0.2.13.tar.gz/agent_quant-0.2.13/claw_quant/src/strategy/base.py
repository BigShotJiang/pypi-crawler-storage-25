"""
策略基类
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from datetime import datetime
from enum import Enum
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class SignalType(Enum):
    """信号类型"""
    BUY = "buy"           # 买入
    SELL = "sell"         # 卖出
    HOLD = "hold"         # 持有
    CLOSE = "close"       # 平仓
    ADD = "add"           # 加仓
    REDUCE = "reduce"     # 减仓


@dataclass
class Signal:
    """交易信号"""
    strategy_code: str          # 策略代码
    code: str                   # 股票代码
    signal_type: SignalType     # 信号类型
    signal_time: datetime       # 信号时间
    price: float = 0.0          # 参考价格
    volume: int = 0             # 建议数量
    strength: float = 0.5       # 信号强度 0-1
    reason: str = ""            # 信号原因
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'strategy_code': self.strategy_code,
            'code': self.code,
            'signal_type': self.signal_type.value,
            'signal_time': self.signal_time,
            'price': self.price,
            'volume': self.volume,
            'strength': self.strength,
            'reason': self.reason
        }


@dataclass
class StrategyConfig:
    """策略配置"""
    code: str                   # 策略代码
    name: str                   # 策略名称
    strategy_type: str          # 策略类型: 选股/择时/套利
    description: str = ""       # 策略描述
    factor_codes: List[str] = None      # 使用的因子
    entry_conditions: Dict = None       # 入场条件
    exit_conditions: Dict = None        # 出场条件
    position_sizing: Dict = None        # 仓位管理
    risk_management: Dict = None        # 风险管理
    
    def __post_init__(self):
        if self.factor_codes is None:
            self.factor_codes = []
        if self.entry_conditions is None:
            self.entry_conditions = {}
        if self.exit_conditions is None:
            self.exit_conditions = {}
        if self.position_sizing is None:
            self.position_sizing = {'type': 'equal', 'max_position': 0.1}
        if self.risk_management is None:
            self.risk_management = {'stop_loss': 0.08, 'take_profit': 0.2}


class BaseStrategy(ABC):
    """策略基类"""
    
    def __init__(self, config: StrategyConfig):
        self.config = config
        self.logger = logging.getLogger(f"strategy.{config.code}")
        
    @abstractmethod
    def generate_signals(self, 
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            date: 当前日期
            market_data: 市场数据
            factor_data: 因子数据
            portfolio: 当前持仓
            
        Returns:
            信号列表
        """
        pass
    
    def calculate_position_size(self, 
                                 signal: Signal,
                                 total_capital: float,
                                 current_positions: Dict) -> int:
        """
        计算仓位大小
        
        Args:
            signal: 交易信号
            total_capital: 总资金
            current_positions: 当前持仓
            
        Returns:
            建议买入数量
        """
        sizing_config = self.config.position_sizing
        sizing_type = sizing_config.get('type', 'equal')
        max_position = sizing_config.get('max_position', 0.1)
        
        # 计算单只股票最大仓位金额
        max_amount = total_capital * max_position
        
        if sizing_type == 'equal':
            # 等权重
            position_amount = max_amount
        elif sizing_type == 'kelly':
            # Kelly公式
            win_rate = sizing_config.get('win_rate', 0.5)
            win_loss_ratio = sizing_config.get('win_loss_ratio', 1.0)
            kelly = win_rate - (1 - win_rate) / win_loss_ratio
            position_amount = total_capital * kelly * signal.strength
        elif sizing_type == 'volatility':
            # 波动率调整
            position_amount = max_amount * signal.strength
        else:
            position_amount = max_amount
            
        # 计算数量
        volume = int(position_amount / signal.price) if signal.price > 0 else 0
        
        # 取整到100股
        volume = (volume // 100) * 100
        
        return volume
    
    def check_stop_loss(self,
                        code: str,
                        entry_price: float,
                        current_price: float) -> bool:
        """检查是否触发止损"""
        stop_loss_pct = self.config.risk_management.get('stop_loss', 0.08)
        loss_pct = (current_price - entry_price) / entry_price
        return loss_pct <= -stop_loss_pct
    
    def check_take_profit(self,
                          code: str,
                          entry_price: float,
                          current_price: float) -> bool:
        """检查是否触发止盈"""
        take_profit_pct = self.config.risk_management.get('take_profit', 0.2)
        profit_pct = (current_price - entry_price) / entry_price
        return profit_pct >= take_profit_pct
    
    def filter_stocks(self,
                      stocks: pd.DataFrame,
                      min_price: float = 3.0,
                      max_price: float = 500.0,
                      min_volume: int = 1000000) -> pd.DataFrame:
        """
        过滤股票
        
        Args:
            stocks: 股票数据
            min_price: 最低价格
            max_price: 最高价格
            min_volume: 最小成交量
            
        Returns:
            过滤后的股票
        """
        # 价格过滤
        mask = (stocks['close'] >= min_price) & (stocks['close'] <= max_price)
        
        # 成交量过滤
        if 'volume' in stocks.columns:
            mask &= (stocks['volume'] >= min_volume)
            
        # ST股票过滤
        if 'name' in stocks.columns:
            mask &= ~stocks['name'].str.contains('ST', na=False)
            
        return stocks[mask]
    
    def rank_stocks(self,
                    stocks: pd.DataFrame,
                    factor_weights: Dict[str, float]) -> pd.DataFrame:
        """
        股票排序
        
        Args:
            stocks: 股票数据
            factor_weights: 因子权重
            
        Returns:
            排序后的股票
        """
        # 计算综合得分
        scores = pd.Series(0.0, index=stocks.index)
        
        for factor_code, weight in factor_weights.items():
            if factor_code in stocks.columns:
                # 标准化
                factor_values = stocks[factor_code]
                factor_mean = factor_values.mean()
                factor_std = factor_values.std()
                
                if factor_std > 0:
                    normalized = (factor_values - factor_mean) / factor_std
                    scores += normalized * weight
                    
        stocks['score'] = scores
        
        return stocks.sort_values('score', ascending=False)
    
    def get_name(self) -> str:
        """获取策略名称"""
        return self.config.name
    
    def get_type(self) -> str:
        """获取策略类型"""
        return self.config.strategy_type
