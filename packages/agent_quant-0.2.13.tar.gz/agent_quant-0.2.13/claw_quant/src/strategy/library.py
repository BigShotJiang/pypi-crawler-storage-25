"""
预定义策略实现
"""
import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from datetime import datetime

from .base import BaseStrategy, StrategyConfig, Signal, SignalType


# ============================================
# 多因子选股策略
# ============================================

class MultiFactorStrategy(BaseStrategy):
    """多因子选股策略"""
    
    def __init__(self, 
                 factor_weights: Optional[Dict[str, float]] = None,
                 top_n: int = 20,
                 rebalance_days: int = 20):
        """
        初始化多因子策略
        
        Args:
            factor_weights: 因子权重
            top_n: 持仓数量
            rebalance_days: 调仓周期(天)
        """
        config = StrategyConfig(
            code='MULTI_FACTOR',
            name='多因子选股策略',
            strategy_type='选股',
            description='基于多因子加权选股的策略',
            factor_codes=['PE_TTM', 'PB', 'MOM_20D', 'VOL_20D'],
            position_sizing={'type': 'equal', 'max_position': 0.05}
        )
        super().__init__(config)
        
        self.factor_weights = factor_weights or {
            'PE_TTM': 0.25,
            'PB': 0.25,
            'MOM_20D': 0.3,
            'VOL_20D': 0.2
        }
        self.top_n = top_n
        self.rebalance_days = rebalance_days
        self.last_rebalance = None
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """生成交易信号"""
        signals = []
        
        # 检查是否需要调仓
        if self.last_rebalance is not None:
            days_since = (date - self.last_rebalance).days
            if days_since < self.rebalance_days:
                return signals
                
        self.last_rebalance = date
        
        # 合并数据
        if factor_data.empty:
            return signals
            
        # 按code分组，获取最新因子值
        latest_factors = factor_data.groupby('code').last().reset_index()
        
        # 过滤和排序
        filtered = self.filter_stocks(latest_factors)
        ranked = self.rank_stocks(filtered, self.factor_weights)
        
        # 选top_n
        selected = ranked.head(self.top_n)
        
        # 生成买入信号
        for _, row in selected.iterrows():
            signals.append(Signal(
                strategy_code=self.config.code,
                code=row['code'],
                signal_type=SignalType.BUY,
                signal_time=date,
                price=row.get('close', 0),
                strength=0.7,
                reason=f"多因子得分排名: {row.get('score', 0):.2f}"
            ))
            
        return signals


# ============================================
# 动量策略
# ============================================

class MomentumStrategy(BaseStrategy):
    """动量策略 - 追涨杀跌"""
    
    def __init__(self,
                 lookback_days: int = 20,
                 top_n: int = 10):
        """
        初始化动量策略
        
        Args:
            lookback_days: 回看天数
            top_n: 持仓数量
        """
        config = StrategyConfig(
            code='MOMENTUM',
            name='动量策略',
            strategy_type='择时',
            description='基于价格动量的趋势跟踪策略',
            factor_codes=['MOM_20D', 'MOM_60D'],
            entry_conditions={'momentum_threshold': 0.05},
            exit_conditions={'momentum_threshold': -0.03},
            position_sizing={'type': 'equal', 'max_position': 0.1}
        )
        super().__init__(config)
        
        self.lookback_days = lookback_days
        self.top_n = top_n
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """生成交易信号"""
        signals = []
        
        if factor_data.empty:
            return signals
            
        # 获取动量因子
        mom_data = factor_data[factor_data['factor_code'] == 'MOM_20D']
        
        if mom_data.empty:
            return signals
            
        # 排序选最强动量
        ranked = mom_data.sort_values('value', ascending=False)
        
        # 买入信号 - 动量最强的
        for _, row in ranked.head(self.top_n).iterrows():
            if row['value'] > 0.05:  # 动量大于5%
                signals.append(Signal(
                    strategy_code=self.config.code,
                    code=row['code'],
                    signal_type=SignalType.BUY,
                    signal_time=date,
                    strength=min(row['value'] * 5, 1.0),  # 动量越大信号越强
                    reason=f"20日动量: {row['value']:.2%}"
                ))
                
        # 卖出信号 - 动量转弱
        if portfolio:
            for code, pos in portfolio.items():
                code_mom = mom_data[mom_data['code'] == code]
                if not code_mom.empty:
                    mom_value = code_mom.iloc[0]['value']
                    if mom_value < -0.03:  # 动量小于-3%
                        signals.append(Signal(
                            strategy_code=self.config.code,
                            code=code,
                            signal_type=SignalType.SELL,
                            signal_time=date,
                            strength=0.8,
                            reason=f"动量转弱: {mom_value:.2%}"
                        ))
                        
        return signals


# ============================================
# 均值回归策略
# ============================================

class MeanReversionStrategy(BaseStrategy):
    """均值回归策略 - 高抛低吸"""
    
    def __init__(self,
                 rsi_period: int = 14,
                 rsi_buy: float = 30,
                 rsi_sell: float = 70):
        """
        初始化均值回归策略
        
        Args:
            rsi_period: RSI周期
            rsi_buy: RSI买入阈值
            rsi_sell: RSI卖出阈值
        """
        config = StrategyConfig(
            code='MEAN_REVERSION',
            name='均值回归策略',
            strategy_type='择时',
            description='基于RSI的均值回归策略',
            factor_codes=['RSI_14'],
            entry_conditions={'rsi_buy': rsi_buy},
            exit_conditions={'rsi_sell': rsi_sell},
            position_sizing={'type': 'equal', 'max_position': 0.08}
        )
        super().__init__(config)
        
        self.rsi_period = rsi_period
        self.rsi_buy = rsi_buy
        self.rsi_sell = rsi_sell
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """生成交易信号"""
        signals = []
        
        if factor_data.empty:
            return signals
            
        # 获取RSI因子
        rsi_data = factor_data[factor_data['factor_code'] == f'RSI_{self.rsi_period}']
        
        if rsi_data.empty:
            return signals
            
        # 买入信号 - RSI超卖
        oversold = rsi_data[rsi_data['value'] < self.rsi_buy]
        for _, row in oversold.iterrows():
            signals.append(Signal(
                strategy_code=self.config.code,
                code=row['code'],
                signal_type=SignalType.BUY,
                signal_time=date,
                strength=(self.rsi_buy - row['value']) / self.rsi_buy,
                reason=f"RSI超卖: {row['value']:.1f}"
            ))
            
        # 卖出信号 - RSI超买或持仓超卖恢复
        if portfolio:
            for code in portfolio.keys():
                code_rsi = rsi_data[rsi_data['code'] == code]
                if not code_rsi.empty:
                    rsi_value = code_rsi.iloc[0]['value']
                    if rsi_value > self.rsi_sell:
                        signals.append(Signal(
                            strategy_code=self.config.code,
                            code=code,
                            signal_type=SignalType.SELL,
                            signal_time=date,
                            strength=(rsi_value - self.rsi_sell) / (100 - self.rsi_sell),
                            reason=f"RSI超买: {rsi_value:.1f}"
                        ))
                        
        return signals


# ============================================
# 价值策略
# ============================================

class ValueStrategy(BaseStrategy):
    """价值投资策略"""
    
    def __init__(self,
                 pe_max: float = 20,
                 pb_max: float = 2,
                 top_n: int = 15):
        """
        初始化价值策略
        
        Args:
            pe_max: 最大市盈率
            pb_max: 最大市净率
            top_n: 持仓数量
        """
        config = StrategyConfig(
            code='VALUE',
            name='价值投资策略',
            strategy_type='选股',
            description='低估值价值投资策略',
            factor_codes=['PE_TTM', 'PB'],
            position_sizing={'type': 'equal', 'max_position': 0.06}
        )
        super().__init__(config)
        
        self.pe_max = pe_max
        self.pb_max = pb_max
        self.top_n = top_n
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """生成交易信号"""
        signals = []
        
        if factor_data.empty:
            return signals
            
        # 获取PE和PB因子
        pe_data = factor_data[factor_data['factor_code'] == 'PE_TTM']
        pb_data = factor_data[factor_data['factor_code'] == 'PB']
        
        if pe_data.empty or pb_data.empty:
            return signals
            
        # 合并数据
        merged = pe_data.merge(
            pb_data[['code', 'value']],
            on='code',
            suffixes=('_pe', '_pb')
        )
        
        # 过滤低估值股票
        value_stocks = merged[
            (merged['value_pe'] > 0) & (merged['value_pe'] < self.pe_max) &
            (merged['value_pb'] > 0) & (merged['value_pb'] < self.pb_max)
        ]
        
        # 按PE+PB综合排序
        value_stocks['score'] = value_stocks['value_pe'] + value_stocks['value_pb']
        selected = value_stocks.nsmallest(self.top_n, 'score')
        
        for _, row in selected.iterrows():
            signals.append(Signal(
                strategy_code=self.config.code,
                code=row['code'],
                signal_type=SignalType.BUY,
                signal_time=date,
                strength=0.6,
                reason=f"低估值: PE={row['value_pe']:.1f}, PB={row['value_pb']:.1f}"
            ))
            
        return signals


# ============================================
# 趋势跟踪策略
# ============================================

class TrendFollowingStrategy(BaseStrategy):
    """趋势跟踪策略"""
    
    def __init__(self,
                 short_ma: int = 10,
                 long_ma: int = 30):
        """
        初始化趋势策略
        
        Args:
            short_ma: 短期均线
            long_ma: 长期均线
        """
        config = StrategyConfig(
            code='TREND',
            name='趋势跟踪策略',
            strategy_type='择时',
            description='均线交叉趋势跟踪策略',
            entry_conditions={'ma_cross': 'golden'},
            exit_conditions={'ma_cross': 'dead'},
            position_sizing={'type': 'equal', 'max_position': 0.1}
        )
        super().__init__(config)
        
        self.short_ma = short_ma
        self.long_ma = long_ma
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """生成交易信号"""
        signals = []
        
        if market_data.empty:
            return signals
            
        # 按code分组计算均线
        for code, group in market_data.groupby('code'):
            if len(group) < self.long_ma:
                continue
                
            # 计算均线
            short = group['close'].rolling(self.short_ma).mean().iloc[-1]
            long = group['close'].rolling(self.long_ma).mean().iloc[-1]
            
            prev_short = group['close'].rolling(self.short_ma).mean().iloc[-2]
            prev_long = group['close'].rolling(self.long_ma).mean().iloc[-2]
            
            current_price = group['close'].iloc[-1]
            
            # 金叉买入
            if prev_short <= prev_long and short > long:
                signals.append(Signal(
                    strategy_code=self.config.code,
                    code=code,
                    signal_type=SignalType.BUY,
                    signal_time=date,
                    price=current_price,
                    strength=0.7,
                    reason=f"均线金叉: MA{self.short_ma}上穿MA{self.long_ma}"
                ))
                
            # 死叉卖出
            elif prev_short >= prev_long and short < long:
                if portfolio and code in portfolio:
                    signals.append(Signal(
                        strategy_code=self.config.code,
                        code=code,
                        signal_type=SignalType.SELL,
                        signal_time=date,
                        price=current_price,
                        strength=0.8,
                        reason=f"均线死叉: MA{self.short_ma}下穿MA{self.long_ma}"
                    ))
                    
        return signals


# ============================================
# 预定义策略列表
# ============================================

PREDEFINED_STRATEGIES = [
    MultiFactorStrategy(),
    MomentumStrategy(),
    MeanReversionStrategy(),
    ValueStrategy(),
    TrendFollowingStrategy(),
]


def get_strategy_by_code(code: str) -> Optional[BaseStrategy]:
    """根据代码获取策略"""
    for strategy in PREDEFINED_STRATEGIES:
        if strategy.config.code == code:
            return strategy
    return None
