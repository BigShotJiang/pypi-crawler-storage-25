"""
预定义因子实现
"""
import pandas as pd
import numpy as np
from typing import Optional, Dict, List

from .library_base import BaseFactor, FactorConfig


# ============================================
# 估值因子
# ============================================

class PE_TTM_Factor(BaseFactor):
    """市盈率TTM因子 - 低PE越好"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='PE_TTM',
            name='市盈率TTM',
            category='估值',
            description='市盈率Trailing Twelve Months，低估值因子',
            formula='1 / PE_TTM'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'pe_ratio' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        # 取倒数，低PE得高分
        pe = stock_data['pe_ratio']
        pe = pe[pe > 0]  # 过滤负值
        
        factor = 1 / pe
        return self.postprocess(factor)


class PB_Factor(BaseFactor):
    """市净率因子 - 低PB越好"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='PB',
            name='市净率',
            category='估值',
            description='市净率，低估值因子',
            formula='1 / PB'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'pb_ratio' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        pb = stock_data['pb_ratio']
        pb = pb[pb > 0]
        
        factor = 1 / pb
        return self.postprocess(factor)


# ============================================
# 成长因子
# ============================================

class ROE_Factor(BaseFactor):
    """净资产收益率因子"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='ROE',
            name='净资产收益率',
            category='成长',
            description='ROE，高盈利质量因子',
            formula='ROE'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        # 使用收益/市值作为ROE代理
        if 'close' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        # 这里简化处理，实际应该从财务数据获取ROE
        # 使用价格变化作为代理
        factor = stock_data.get('roe', pd.Series(index=stock_data.index))
        
        return self.postprocess(factor)


class Momentum_20D_Factor(BaseFactor):
    """20日动量因子"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='MOM_20D',
            name='20日动量',
            category='动量',
            description='20日收益率动量',
            formula='(close - close_20d_ago) / close_20d_ago'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'close' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        # 计算20日动量
        # 假设stock_data包含历史数据，按code分组计算
        momentum = stock_data.groupby(level=0)['close'].apply(
            lambda x: x.iloc[-1] / x.iloc[-20] - 1 if len(x) >= 20 else np.nan
        )
        
        return self.postprocess(momentum)


class Momentum_60D_Factor(BaseFactor):
    """60日动量因子"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='MOM_60D',
            name='60日动量',
            category='动量',
            description='60日收益率动量',
            formula='(close - close_60d_ago) / close_60d_ago'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'close' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        momentum = stock_data.groupby(level=0)['close'].apply(
            lambda x: x.iloc[-1] / x.iloc[-60] - 1 if len(x) >= 60 else np.nan
        )
        
        return self.postprocess(momentum)


# ============================================
# 波动因子
# ============================================

class Volatility_20D_Factor(BaseFactor):
    """20日波动率因子 - 低波动越好"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='VOL_20D',
            name='20日波动率',
            category='波动',
            description='20日收益率标准差，低波动因子',
            formula='-std(returns_20d)'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'close' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        # 计算20日波动率（取负，低波动得高分）
        volatility = stock_data.groupby(level=0)['close'].apply(
            lambda x: -x.pct_change().iloc[-20:].std() if len(x) >= 20 else np.nan
        )
        
        return self.postprocess(volatility)


class Turnover_Factor(BaseFactor):
    """换手率因子"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='TURNOVER',
            name='换手率',
            category='情绪',
            description='换手率，情绪指标',
            formula='turnover_rate'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'turnover_rate' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        turnover = stock_data['turnover_rate']
        return self.postprocess(turnover)


# ============================================
# 技术因子
# ============================================

class RSI_Factor(BaseFactor):
    """RSI相对强弱指标"""
    
    def __init__(self, period: int = 14):
        super().__init__(FactorConfig(
            code=f'RSI_{period}',
            name=f'RSI{period}',
            category='技术',
            description=f'{period}日RSI指标',
            formula=f'RSI({period})',
            parameters={'period': period}
        ))
        self.period = period
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'close' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        def calc_rsi(prices):
            if len(prices) < self.period + 1:
                return np.nan
            
            deltas = prices.diff()
            gains = deltas.where(deltas > 0, 0)
            losses = -deltas.where(deltas < 0, 0)
            
            avg_gain = gains.iloc[-self.period:].mean()
            avg_loss = losses.iloc[-self.period:].mean()
            
            if avg_loss == 0:
                return 100
            
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            # 反转，低RSI买入
            return 100 - rsi
        
        rsi = stock_data.groupby(level=0)['close'].apply(calc_rsi)
        return self.postprocess(rsi)


class MACD_Factor(BaseFactor):
    """MACD因子"""
    
    def __init__(self):
        super().__init__(FactorConfig(
            code='MACD',
            name='MACD',
            category='技术',
            description='MACD指标',
            formula='EMA12 - EMA26'
        ))
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        if 'close' not in stock_data.columns:
            return pd.Series(index=stock_data.index)
        
        def calc_macd(prices):
            if len(prices) < 26:
                return np.nan
            
            ema12 = prices.ewm(span=12).mean().iloc[-1]
            ema26 = prices.ewm(span=26).mean().iloc[-1]
            
            return ema12 - ema26
        
        macd = stock_data.groupby(level=0)['close'].apply(calc_macd)
        return self.postprocess(macd)


# ============================================
# 复合因子
# ============================================

class CompositeFactor(BaseFactor):
    """复合因子 - 多因子加权"""
    
    def __init__(self, weights: Dict[str, float]):
        """
        初始化复合因子
        
        Args:
            weights: 因子权重字典 {factor_code: weight}
        """
        super().__init__(FactorConfig(
            code='COMPOSITE',
            name='复合因子',
            category='复合',
            description='多因子加权复合',
            formula='sum(weight_i * factor_i)'
        ))
        self.weights = weights
    
    def calculate(self, stock_data: pd.DataFrame, market_data=None) -> pd.Series:
        """
        计算复合因子值
        
        注意：这里假设stock_data已经包含了各因子的值
        """
        composite = pd.Series(0, index=stock_data.index)
        
        for factor_code, weight in self.weights.items():
            if factor_code in stock_data.columns:
                composite += stock_data[factor_code] * weight
        
        return self.postprocess(composite)


# ============================================
# 预定义因子列表
# ============================================

PREDEFINED_FACTORS = [
    # 估值因子
    PE_TTM_Factor(),
    PB_Factor(),
    
    # 动量因子
    Momentum_20D_Factor(),
    Momentum_60D_Factor(),
    
    # 波动因子
    Volatility_20D_Factor(),
    
    # 情绪因子
    Turnover_Factor(),
    
    # 技术因子
    RSI_Factor(14),
    MACD_Factor(),
]


def get_factor_by_code(code: str) -> Optional[BaseFactor]:
    """根据代码获取因子"""
    for factor in PREDEFINED_FACTORS:
        if factor.config.code == code:
            return factor
    return None


def get_factors_by_category(category: str) -> List[BaseFactor]:
    """根据分类获取因子"""
    return [f for f in PREDEFINED_FACTORS if f.config.category == category]
