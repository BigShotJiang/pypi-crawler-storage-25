# -*- coding: utf-8 -*-
"""
因子库模块 - 聚宽风格
提供因子的定义、计算和管理功能

因子分类:
- 估值类: PE_TTM, PB, PS, PCF, 股息率等
- 质量类: ROE, ROA, 毛利率, 净利率等
- 成长类: 营收增长率, 净利润增长率, ROE增长率等
- 动量类: 20日/60日/120日动量, 波动率, Beta等
- 情绪类: 换手率, PSY, VR, OBV等
- 技术类: MACD, RSI, KDJ, 布林带等
"""

# 基类
from .jqfactor_base import (
    JQFactor,
    FactorMeta,
    FactorRegistry,
    register_factor
)

# 兼容旧版
from .jqfactor_base import JQFactor as Factor
FactorRegistry = FactorRegistry

# 导入所有因子（自动注册）
# 估值类
from . import valuation_factors

# 质量类
from . import quality_factors

# 成长类
from . import growth_factors

# 动量类
from . import momentum_factors

# 情绪类
from . import sentiment_factors

# 技术类
from . import technical_factors

# 旧版兼容
from .base import (
    Factor as LegacyFactor,
    FactorRegistry as LegacyFactorRegistry,
    register_factor as legacy_register_factor
)

__all__ = [
    # 基类
    'JQFactor',
    'Factor',
    'FactorMeta',
    'FactorRegistry',
    'register_factor',
    
    # 旧版兼容
    'LegacyFactor',
    'LegacyFactorRegistry',
    'legacy_register_factor',
]


def get_all_factors():
    """获取所有已注册因子"""
    return FactorRegistry.get_all_info()


def list_factor_categories():
    """列出所有因子分类"""
    return ['估值', '质量', '成长', '动量', '情绪', '技术']


def get_factors_by_category(category: str):
    """获取指定分类的因子"""
    codes = FactorRegistry.list_factors(category=category)
    return [FactorRegistry.get(code).meta.__dict__ for code in codes]
