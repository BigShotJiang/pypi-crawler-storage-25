# -*- coding: utf-8 -*-
"""
因子基类和注册器
兼容旧版导入
"""

from typing import Dict, List, Optional, Any, Callable
import pandas as pd
import logging

logger = logging.getLogger(__name__)

# 因子注册表
_factor_registry: Dict[str, Any] = {}


def register_factor(code: str):
    """
    因子注册装饰器
    
    用法:
        @register_factor('MA')
        class MAFactor(Factor):
            ...
    """
    def decorator(cls):
        _factor_registry[code] = cls
        cls._factor_code = code
        return cls
    return decorator


def get_factor_class(code: str) -> Optional[Any]:
    """获取因子类"""
    return _factor_registry.get(code)


def list_registered_factors() -> List[str]:
    """列出所有已注册因子"""
    return list(_factor_registry.keys())


class Factor:
    """
    因子基类（兼容旧版）
    """
    
    def __init__(self, name: str, params: Dict[str, Any] = None):
        """
        初始化因子
        
        Args:
            name: 因子名称
            params: 因子参数
        """
        self.name = name
        self.params = params or {}
        self.logger = logging.getLogger(f"factor.{name}")
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """
        计算因子值
        
        Args:
            data: 股票数据 DataFrame
            
        Returns:
            因子值 Series
        """
        raise NotImplementedError("子类必须实现calculate方法")
        
    def get_name(self) -> str:
        """获取因子名称"""
        return self.name
        
    def get_params(self) -> Dict[str, Any]:
        """获取因子参数"""
        return self.params.copy()


class FactorRegistry:
    """因子注册表（兼容旧版）"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._factors = {}
        return cls._instance
    
    def register(self, code: str, factor_class: Any):
        """注册因子"""
        self._factors[code] = factor_class
        
    def get(self, code: str) -> Optional[Any]:
        """获取因子类"""
        return self._factors.get(code)
        
    def list_factors(self) -> List[str]:
        """列出所有因子"""
        return list(self._factors.keys())


# 导出
__all__ = [
    'Factor',
    'FactorRegistry',
    'register_factor',
    'get_factor_class',
    'list_registered_factors',
]
