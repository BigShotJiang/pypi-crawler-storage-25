# -*- coding: utf-8 -*-
"""
质量类因子
参考聚宽因子库设计
"""

import pandas as pd
import numpy as np
from .jqfactor_base import JQFactor, FactorMeta, register_factor


@register_factor
class ROE_Factor(JQFactor):
    """净资产收益率 - 高ROE表示质量好"""
    
    meta = FactorMeta(
        code='ROE',
        name='净资产收益率',
        category='质量',
        description='ROE，高盈利质量因子',
        formula='净利润 / 净资产',
        dependencies=['roe'],
        max_window=1
    )
    
    def calc(self, data):
        roe = data['roe'].iloc[-1]
        # 过滤异常值
        roe = roe[(roe > -1) & (roe < 2)]
        return roe


@register_factor
class ROA_Factor(JQFactor):
    """总资产收益率 - 高ROA表示质量好"""
    
    meta = FactorMeta(
        code='ROA',
        name='总资产收益率',
        category='质量',
        description='ROA，资产利用效率因子',
        formula='净利润 / 总资产',
        dependencies=['roa'],
        max_window=1
    )
    
    def calc(self, data):
        roa = data['roa'].iloc[-1]
        roa = roa[(roa > -1) & (roa < 2)]
        return roa


@register_factor
class GrossMargin_Factor(JQFactor):
    """毛利率 - 高毛利率表示竞争力强"""
    
    meta = FactorMeta(
        code='GROSS_MARGIN',
        name='毛利率',
        category='质量',
        description='毛利率，盈利能力因子',
        formula='(营收 - 成本) / 营收',
        dependencies=['gross_profit_margin'],
        max_window=1
    )
    
    def calc(self, data):
        margin = data['gross_profit_margin'].iloc[-1]
        margin = margin[(margin > -1) & (margin < 2)]
        return margin


@register_factor
class NetMargin_Factor(JQFactor):
    """净利率 - 高净利率表示盈利能力强"""
    
    meta = FactorMeta(
        code='NET_MARGIN',
        name='净利率',
        category='质量',
        description='净利率，盈利能力因子',
        formula='净利润 / 营收',
        dependencies=['net_profit_margin'],
        max_window=1
    )
    
    def calc(self, data):
        margin = data['net_profit_margin'].iloc[-1]
        margin = margin[(margin > -1) & (margin < 2)]
        return margin


@register_factor
class OperatingCycle_Factor(JQFactor):
    """营业周期 - 短周期表示运营效率高"""
    
    meta = FactorMeta(
        code='OPERATING_CYCLE',
        name='营业周期',
        category='质量',
        description='营业周期，运营效率因子（取负值，越短越好）',
        formula='-(存货周转天数 + 应收账款周转天数)',
        dependencies=['operating_cycle'],
        max_window=1
    )
    
    def calc(self, data):
        cycle = data['operating_cycle'].iloc[-1]
        cycle = cycle[(cycle > 0) & (cycle < 1000)]
        return -cycle  # 取负值，越短越好


@register_factor
class DebtToAsset_Factor(JQFactor):
    """资产负债率 - 低负债表示财务稳健"""
    
    meta = FactorMeta(
        code='DEBT_TO_ASSET',
        name='资产负债率',
        category='质量',
        description='资产负债率，财务稳健因子（取负值，越低越好）',
        formula='-负债 / 资产',
        dependencies=['debt_to_asset_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        debt = data['debt_to_asset_ratio'].iloc[-1]
        debt = debt[(debt > 0) & (debt < 2)]
        return -debt  # 取负值，越低越好


@register_factor
class CurrentRatio_Factor(JQFactor):
    """流动比率 - 高比率表示短期偿债能力强"""
    
    meta = FactorMeta(
        code='CURRENT_RATIO',
        name='流动比率',
        category='质量',
        description='流动比率，短期偿债能力因子',
        formula='流动资产 / 流动负债',
        dependencies=['current_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        ratio = data['current_ratio'].iloc[-1]
        ratio = ratio[(ratio > 0) & (ratio < 20)]
        return ratio


@register_factor
class CashRatio_Factor(JQFactor):
    """现金比率 - 高比率表示现金充裕"""
    
    meta = FactorMeta(
        code='CASH_RATIO',
        name='现金比率',
        category='质量',
        description='现金比率，现金充裕度因子',
        formula='现金及等价物 / 流动负债',
        dependencies=['cash_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        ratio = data['cash_ratio'].iloc[-1]
        ratio = ratio[(ratio > 0) & (ratio < 20)]
        return ratio
