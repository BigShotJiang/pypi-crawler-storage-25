# -*- coding: utf-8 -*-
"""
动量类因子
参考聚宽因子库设计
"""

import pandas as pd
import numpy as np
from .jqfactor_base import JQFactor, FactorMeta, register_factor


@register_factor
class Momentum_20D_Factor(JQFactor):
    """20日价格动量"""
    
    meta = FactorMeta(
        code='MOM_20D',
        name='20日动量',
        category='动量',
        description='20日收益率动量',
        formula='(close - close_20d_ago) / close_20d_ago',
        dependencies=['close'],
        max_window=25,
        parameters={
            'window': {'type': 'int', 'default': 20, 'description': '动量窗口'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.window = self.params.get('window', 20)
    
    def calc(self, data):
        close = data['close']
        momentum = (close.iloc[-1] - close.iloc[-self.window-1]) / close.iloc[-self.window-1]
        momentum = momentum[momentum.abs() < 2]  # 过滤极端值
        return momentum


@register_factor
class Momentum_60D_Factor(JQFactor):
    """60日价格动量"""
    
    meta = FactorMeta(
        code='MOM_60D',
        name='60日动量',
        category='动量',
        description='60日收益率动量',
        formula='(close - close_60d_ago) / close_60d_ago',
        dependencies=['close'],
        max_window=65
    )
    
    def calc(self, data):
        close = data['close']
        momentum = (close.iloc[-1] - close.iloc[-61]) / close.iloc[-61]
        momentum = momentum[momentum.abs() < 3]
        return momentum


@register_factor
class Momentum_120D_Factor(JQFactor):
    """120日价格动量"""
    
    meta = FactorMeta(
        code='MOM_120D',
        name='120日动量',
        category='动量',
        description='120日收益率动量',
        formula='(close - close_120d_ago) / close_120d_ago',
        dependencies=['close'],
        max_window=125
    )
    
    def calc(self, data):
        close = data['close']
        momentum = (close.iloc[-1] - close.iloc[-121]) / close.iloc[-121]
        momentum = momentum[momentum.abs() < 5]
        return momentum


@register_factor
class Volatility_20D_Factor(JQFactor):
    """20日波动率 - 低波动因子"""
    
    meta = FactorMeta(
        code='VOL_20D',
        name='20日波动率',
        category='动量',
        description='20日收益率标准差，低波动因子（取负值）',
        formula='-std(returns_20d)',
        dependencies=['close'],
        max_window=25
    )
    
    def calc(self, data):
        close = data['close']
        returns = close.pct_change().iloc[-20:]
        vol = returns.std()
        vol = vol[vol < 0.5]  # 过滤极端值
        return -vol  # 取负值，低波动得高分


@register_factor
class Volatility_60D_Factor(JQFactor):
    """60日波动率 - 低波动因子"""
    
    meta = FactorMeta(
        code='VOL_60D',
        name='60日波动率',
        category='动量',
        description='60日收益率标准差，低波动因子（取负值）',
        formula='-std(returns_60d)',
        dependencies=['close'],
        max_window=65
    )
    
    def calc(self, data):
        close = data['close']
        returns = close.pct_change().iloc[-60:]
        vol = returns.std()
        vol = vol[vol < 0.5]
        return -vol


@register_factor
class Beta_Factor(JQFactor):
    """Beta因子 - 相对市场波动"""
    
    meta = FactorMeta(
        code='BETA',
        name='Beta',
        category='动量',
        description='相对于市场的Beta值，低Beta防御因子（取负值）',
        formula='-cov(stock, market) / var(market)',
        dependencies=['close', 'index_close'],
        max_window=65
    )
    
    def calc(self, data):
        stock_close = data['close']
        market_close = data['index_close']
        
        # 计算收益率
        stock_returns = stock_close.pct_change().iloc[-60:]
        market_returns = market_close.pct_change().iloc[-60:]
        
        # 计算Beta
        beta = pd.Series(index=stock_returns.columns, dtype=float)
        for col in stock_returns.columns:
            s_ret = stock_returns[col]
            m_ret = market_returns
            
            # 计算协方差和方差
            cov = s_ret.cov(m_ret)
            var = m_ret.var()
            
            if var > 0:
                beta[col] = cov / var
        
        beta = beta[beta.abs() < 5]
        return -beta  # 取负值，低Beta得高分


@register_factor
class MaxDrawdown_Factor(JQFactor):
    """最大回撤 - 低风险因子"""
    
    meta = FactorMeta(
        code='MAX_DRAWDOWN',
        name='最大回撤',
        category='动量',
        description='60日最大回撤，低风险因子（取负值）',
        formula='-max_drawdown_60d',
        dependencies=['close'],
        max_window=65
    )
    
    def calc(self, data):
        close = data['close'].iloc[-60:]
        
        # 计算最大回撤
        cummax = close.cummax()
        drawdown = (close - cummax) / cummax
        max_dd = drawdown.min()
        
        max_dd = max_dd[max_dd > -0.8]  # 过滤极端值
        return max_dd  # 已经是负值，越小表示回撤越大


@register_factor
class ReturnVariance_Factor(JQFactor):
    """收益方差 - 低风险因子"""
    
    meta = FactorMeta(
        code='RETURN_VAR',
        name='收益方差',
        category='动量',
        description='120日收益方差，低风险因子（取负值）',
        formula='-var(returns_120d)',
        dependencies=['close'],
        max_window=125
    )
    
    def calc(self, data):
        close = data['close']
        returns = close.pct_change().iloc[-120:]
        var = returns.var()
        var = var[var < 0.5]
        return -var
