# -*- coding: utf-8 -*-
"""
估值类因子
参考聚宽因子库设计
"""

import pandas as pd
import numpy as np
from .jqfactor_base import JQFactor, FactorMeta, register_factor


@register_factor
class PE_TTM_Factor(JQFactor):
    """市盈率TTM - 低PE表示估值低"""
    
    meta = FactorMeta(
        code='PE_TTM',
        name='市盈率TTM',
        category='估值',
        description='市盈率Trailing Twelve Months，低估值因子',
        formula='1 / PE_TTM',
        dependencies=['pe_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        pe = data['pe_ratio'].iloc[-1]
        # 过滤负值和极端值
        pe = pe[(pe > 0) & (pe < 500)]
        # 取倒数，低PE得高分
        return 1 / pe


@register_factor
class PB_Factor(JQFactor):
    """市净率 - 低PB表示估值低"""
    
    meta = FactorMeta(
        code='PB',
        name='市净率',
        category='估值',
        description='市净率，低估值因子',
        formula='1 / PB',
        dependencies=['pb_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        pb = data['pb_ratio'].iloc[-1]
        pb = pb[(pb > 0) & (pb < 100)]
        return 1 / pb


@register_factor
class PS_Factor(JQFactor):
    """市销率 - 低PS表示估值低"""
    
    meta = FactorMeta(
        code='PS',
        name='市销率',
        category='估值',
        description='市销率，低估值因子',
        formula='1 / PS',
        dependencies=['ps_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        ps = data['ps_ratio'].iloc[-1]
        ps = ps[(ps > 0) & (ps < 100)]
        return 1 / ps


@register_factor
class PCF_Factor(JQFactor):
    """市现率 - 低PCF表示估值低"""
    
    meta = FactorMeta(
        code='PCF',
        name='市现率',
        category='估值',
        description='市现率（股价/现金流），低估值因子',
        formula='1 / PCF',
        dependencies=['pcf_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        pcf = data['pcf_ratio'].iloc[-1]
        pcf = pcf[(pcf > 0) & (pcf < 500)]
        return 1 / pcf


@register_factor
class DividendYield_Factor(JQFactor):
    """股息率 - 高股息率表示价值高"""
    
    meta = FactorMeta(
        code='DIVIDEND_YIELD',
        name='股息率',
        category='估值',
        description='股息率，高股息价值因子',
        formula='股息 / 股价',
        dependencies=['dividend_yield'],
        max_window=1
    )
    
    def calc(self, data):
        dy = data['dividend_yield'].iloc[-1]
        # 过滤异常值
        dy = dy[(dy >= 0) & (dy < 0.5)]
        return dy


@register_factor
class EP_Factor(JQFactor):
    """盈利收益率 - PE的倒数"""
    
    meta = FactorMeta(
        code='EP',
        name='盈利收益率',
        category='估值',
        description='盈利收益率（净利润/市值），高EP表示估值低',
        formula='EPS / 股价',
        dependencies=['pe_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        pe = data['pe_ratio'].iloc[-1]
        pe = pe[(pe > 0) & (pe < 500)]
        return 1 / pe


@register_factor
class BP_Factor(JQFactor):
    """账面市值比 - PB的倒数"""
    
    meta = FactorMeta(
        code='BP',
        name='账面市值比',
        category='估值',
        description='账面市值比（净资产/市值），高BP表示估值低',
        formula='1 / PB',
        dependencies=['pb_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        pb = data['pb_ratio'].iloc[-1]
        pb = pb[(pb > 0) & (pb < 100)]
        return 1 / pb


@register_factor
class SP_Factor(JQFactor):
    """营收市值比 - PS的倒数"""
    
    meta = FactorMeta(
        code='SP',
        name='营收市值比',
        category='估值',
        description='营收市值比（营收/市值），高SP表示估值低',
        formula='1 / PS',
        dependencies=['ps_ratio'],
        max_window=1
    )
    
    def calc(self, data):
        ps = data['ps_ratio'].iloc[-1]
        ps = ps[(ps > 0) & (ps < 100)]
        return 1 / ps
