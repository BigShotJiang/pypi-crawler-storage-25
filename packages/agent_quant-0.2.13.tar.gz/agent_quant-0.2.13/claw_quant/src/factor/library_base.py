"""
因子基类
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from dataclasses import dataclass
import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)


@dataclass
class FactorConfig:
    """因子配置"""
    code: str                           # 因子代码
    name: str                           # 因子名称
    category: str                       # 分类: 估值/成长/质量/动量/波动/情绪
    description: str = ""               # 描述
    formula: str = ""                   # 计算公式
    parameters: Dict = None             # 参数
    frequency: str = 'daily'            # 更新频率
    
    def __post_init__(self):
        if self.parameters is None:
            self.parameters = {}


class BaseFactor(ABC):
    """因子基类"""
    
    def __init__(self, config: FactorConfig):
        self.config = config
        self.logger = logging.getLogger(f"factor.{config.code}")
        
    @abstractmethod
    def calculate(self, 
                  stock_data: pd.DataFrame,
                  market_data: Optional[pd.DataFrame] = None) -> pd.Series:
        """
        计算因子值
        
        Args:
            stock_data: 股票数据 DataFrame
                       index: code
                       columns: open, high, low, close, volume, etc.
            market_data: 市场数据 (用于计算相对指标)
            
        Returns:
            因子值 Series (index=code, values=factor_value)
        """
        pass
    
    def preprocess(self, data: pd.DataFrame) -> pd.DataFrame:
        """数据预处理"""
        # 删除缺失值
        data = data.dropna(subset=['close'])
        return data
    
    def postprocess(self, values: pd.Series) -> pd.Series:
        """
        后处理 (去极值、标准化)
        
        1. MAD去极值
        2. Z-score标准化
        """
        if values.empty:
            return values
            
        # MAD去极值
        median = values.median()
        mad = (values - median).abs().median()
        
        if mad > 0:
            upper = median + 3 * 1.4826 * mad
            lower = median - 3 * 1.4826 * mad
            values = values.clip(lower, upper)
        
        # Z-score标准化
        std = values.std()
        if std > 0:
            values = (values - values.mean()) / std
        
        return values
    
    def calculate_rank(self, values: pd.Series) -> pd.Series:
        """计算排名"""
        return values.rank(ascending=False)
    
    def calculate_percentile(self, values: pd.Series) -> pd.Series:
        """计算百分位"""
        return values.rank(pct=True)
    
    def get_name(self) -> str:
        """获取因子名称"""
        return self.config.name
    
    def get_category(self) -> str:
        """获取因子分类"""
        return self.config.category
