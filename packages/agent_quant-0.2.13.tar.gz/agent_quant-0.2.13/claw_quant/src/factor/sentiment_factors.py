# -*- coding: utf-8 -*-
"""
情绪类因子
参考聚宽因子库设计
"""

import pandas as pd
import numpy as np
from .jqfactor_base import JQFactor, FactorMeta, register_factor


@register_factor
class Turnover_20D_Factor(JQFactor):
    """20日平均换手率"""
    
    meta = FactorMeta(
        code='TURNOVER_20D',
        name='20日平均换手率',
        category='情绪',
        description='20日平均换手率，情绪指标（取负值，低换手表示筹码稳定）',
        formula='-mean(turnover_20d)',
        dependencies=['turnover_ratio'],
        max_window=25
    )
    
    def calc(self, data):
        turnover = data['turnover_ratio'].iloc[-20:]
        avg_turnover = turnover.mean()
        avg_turnover = avg_turnover[avg_turnover < 0.5]  # 过滤极端值
        return -avg_turnover  # 取负值，低换手得高分


@register_factor
class TurnoverRatio_5D_20D_Factor(JQFactor):
    """5日/20日换手率比 - 短期情绪变化"""
    
    meta = FactorMeta(
        code='TURNOVER_RATIO_5D_20D',
        name='换手率比5日/20日',
        category='情绪',
        description='5日换手率与20日换手率之比，短期情绪变化（取负值）',
        formula='-(turnover_5d / turnover_20d)',
        dependencies=['turnover_ratio'],
        max_window=25
    )
    
    def calc(self, data):
        turnover = data['turnover_ratio']
        turnover_5d = turnover.iloc[-5:].mean()
        turnover_20d = turnover.iloc[-20:].mean()
        
        ratio = turnover_5d / turnover_20d
        ratio = ratio[(ratio > 0) & (ratio < 10)]
        return -ratio  # 取负值，低比率得高分


@register_factor
class PSY_Factor(JQFactor):
    """心理线指标 PSY"""
    
    meta = FactorMeta(
        code='PSY',
        name='心理线指标',
        category='情绪',
        description='PSY心理线指标，衡量市场情绪（取负值，避免过度乐观）',
        formula='-count(close > close_1d, 12) / 12',
        dependencies=['close'],
        max_window=15,
        parameters={
            'period': {'type': 'int', 'default': 12, 'description': '计算周期'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.period = self.params.get('period', 12)
    
    def calc(self, data):
        close = data['close'].iloc[-self.period-1:]
        returns = close.pct_change().iloc[1:]
        
        # 计算上涨天数比例
        psy = (returns > 0).sum() / self.period
        return -psy  # 取负值，避免过度乐观


@register_factor
class VR_Factor(JQFactor):
    """成交量比率 Volume Ratio"""
    
    meta = FactorMeta(
        code='VR',
        name='成交量比率',
        category='情绪',
        description='VR成交量比率，衡量买卖气势',
        formula='(up_volume + 0.5*same_volume) / (down_volume + 0.5*same_volume)',
        dependencies=['volume', 'close'],
        max_window=30,
        parameters={
            'period': {'type': 'int', 'default': 26, 'description': '计算周期'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.period = self.params.get('period', 26)
    
    def calc(self, data):
        volume = data['volume'].iloc[-self.period-1:]
        close = data['close'].iloc[-self.period-1:]
        
        # 计算涨跌
        price_change = close.diff().iloc[1:]
        vol = volume.iloc[1:]
        
        # 分类成交量
        up_vol = vol[price_change > 0].sum()
        down_vol = vol[price_change < 0].sum()
        same_vol = vol[price_change == 0].sum()
        
        # 计算VR
        vr = (up_vol + 0.5 * same_vol) / (down_vol + 0.5 * same_vol)
        vr = vr[(vr > 0) & (vr < 10)]
        return vr


@register_factor
class OBV_Factor(JQFactor):
    """能量潮 OBV"""
    
    meta = FactorMeta(
        code='OBV',
        name='能量潮',
        category='情绪',
        description='OBV能量潮，量价配合指标',
        formula='cumsum(sign(close - close_1d) * volume)',
        dependencies=['volume', 'close'],
        max_window=30
    )
    
    def calc(self, data):
        volume = data['volume']
        close = data['close']
        
        # 计算价格变化方向
        price_change = close.diff().iloc[-20:]
        vol = volume.iloc[-20:]
        
        # 计算OBV变化
        obv_change = pd.Series(index=vol.columns, dtype=float)
        for col in vol.columns:
            p_change = price_change[col]
            v = vol[col]
            
            # 上涨累加成交量，下跌累减成交量
            obv_val = v[p_change > 0].sum() - v[p_change < 0].sum()
            obv_change[col] = obv_val
        
        # 标准化
        obv_change = obv_change[obv_change.abs() < 1e12]
        return obv_change


@register_factor
class MoneyFlow_Factor(JQFactor):
    """资金流向 - 简化版"""
    
    meta = FactorMeta(
        code='MONEY_FLOW',
        name='资金流向',
        category='情绪',
        description='资金流向指标，正表示资金流入',
        formula='sign(close - open) * volume * (close + open) / 2',
        dependencies=['open', 'close', 'volume'],
        max_window=10
    )
    
    def calc(self, data):
        open_price = data['open'].iloc[-5:]
        close = data['close'].iloc[-5:]
        volume = data['volume'].iloc[-5:]
        
        # 计算典型价格
        typical_price = (close + open_price) / 2
        
        # 计算资金流向
        money_flow = pd.Series(index=close.columns, dtype=float)
        for col in close.columns:
            direction = np.sign(close[col].iloc[-1] - open_price[col].iloc[0])
            mf = direction * volume[col].sum() * typical_price[col].mean()
            money_flow[col] = mf
        
        money_flow = money_flow[money_flow.abs() < 1e12]
        return money_flow
