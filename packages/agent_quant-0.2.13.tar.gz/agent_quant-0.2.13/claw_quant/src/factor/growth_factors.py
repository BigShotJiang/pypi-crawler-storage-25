# -*- coding: utf-8 -*-
"""
成长类因子
参考聚宽因子库设计
"""

import pandas as pd
import numpy as np
from .jqfactor_base import JQFactor, FactorMeta, register_factor


@register_factor
class RevenueGrowth_Factor(JQFactor):
    """营业收入增长率"""
    
    meta = FactorMeta(
        code='REVENUE_GROWTH',
        name='营收增长率',
        category='成长',
        description='营业收入同比增长率',
        formula='(本期营收 - 上期营收) / 上期营收',
        dependencies=['operating_revenue', 'operating_revenue_1'],
        max_window=1
    )
    
    def calc(self, data):
        current = data['operating_revenue'].iloc[-1]
        previous = data['operating_revenue_1'].iloc[-1]
        
        # 计算增长率
        growth = (current - previous) / previous.abs()
        growth = growth[(growth > -2) & (growth < 10)]  # 过滤极端值
        return growth


@register_factor
class ProfitGrowth_Factor(JQFactor):
    """净利润增长率"""
    
    meta = FactorMeta(
        code='PROFIT_GROWTH',
        name='净利润增长率',
        category='成长',
        description='净利润同比增长率',
        formula='(本期净利润 - 上期净利润) / 上期净利润',
        dependencies=['net_profit', 'net_profit_1'],
        max_window=1
    )
    
    def calc(self, data):
        current = data['net_profit'].iloc[-1]
        previous = data['net_profit_1'].iloc[-1]
        
        # 处理负值情况
        growth = pd.Series(index=current.index, dtype=float)
        mask = (previous > 0) & (current > 0)
        growth[mask] = (current[mask] - previous[mask]) / previous[mask]
        
        # 上期亏损本期盈利，给予高分
        mask_turnaround = (previous < 0) & (current > 0)
        growth[mask_turnaround] = 2.0
        
        growth = growth[(growth > -5) & (growth < 20)]
        return growth


@register_factor
class ROEGrowth_Factor(JQFactor):
    """ROE增长率"""
    
    meta = FactorMeta(
        code='ROE_GROWTH',
        name='ROE增长率',
        category='成长',
        description='ROE同比增长率',
        formula='(本期ROE - 上期ROE) / 上期ROE',
        dependencies=['roe', 'roe_1'],
        max_window=1
    )
    
    def calc(self, data):
        current = data['roe'].iloc[-1]
        previous = data['roe_1'].iloc[-1]
        
        growth = pd.Series(index=current.index, dtype=float)
        mask = previous > 0
        growth[mask] = (current[mask] - previous[mask]) / previous[mask]
        
        growth = growth[(growth > -5) & (growth < 20)]
        return growth


@register_factor
class AssetGrowth_Factor(JQFactor):
    """总资产增长率"""
    
    meta = FactorMeta(
        code='ASSET_GROWTH',
        name='总资产增长率',
        category='成长',
        description='总资产同比增长率',
        formula='(本期资产 - 上期资产) / 上期资产',
        dependencies=['total_assets', 'total_assets_1'],
        max_window=1
    )
    
    def calc(self, data):
        current = data['total_assets'].iloc[-1]
        previous = data['total_assets_1'].iloc[-1]
        
        growth = (current - previous) / previous.abs()
        growth = growth[(growth > -1) & (growth < 5)]
        return growth


@register_factor
class EPSGrowth_Factor(JQFactor):
    """每股收益增长率"""
    
    meta = FactorMeta(
        code='EPS_GROWTH',
        name='每股收益增长率',
        category='成长',
        description='EPS同比增长率',
        formula='(本期EPS - 上期EPS) / 上期EPS',
        dependencies=['eps', 'eps_1'],
        max_window=1
    )
    
    def calc(self, data):
        current = data['eps'].iloc[-1]
        previous = data['eps_1'].iloc[-1]
        
        growth = pd.Series(index=current.index, dtype=float)
        mask = previous > 0
        growth[mask] = (current[mask] - previous[mask]) / previous[mask]
        
        growth = growth[(growth > -5) & (growth < 20)]
        return growth


@register_factor
class OperatingCashFlowGrowth_Factor(JQFactor):
    """经营现金流增长率"""
    
    meta = FactorMeta(
        code='OCF_GROWTH',
        name='经营现金流增长率',
        category='成长',
        description='经营现金流同比增长率',
        formula='(本期OCF - 上期OCF) / 上期OCF',
        dependencies=['net_operate_cash_flow', 'net_operate_cash_flow_1'],
        max_window=1
    )
    
    def calc(self, data):
        current = data['net_operate_cash_flow'].iloc[-1]
        previous = data['net_operate_cash_flow_1'].iloc[-1]
        
        growth = pd.Series(index=current.index, dtype=float)
        mask = previous != 0
        growth[mask] = (current[mask] - previous[mask]) / previous[mask].abs()
        
        # 上期负本期正，给予高分
        mask_improve = (previous < 0) & (current > 0)
        growth[mask_improve] = 2.0
        
        growth = growth[(growth > -10) & (growth < 20)]
        return growth
