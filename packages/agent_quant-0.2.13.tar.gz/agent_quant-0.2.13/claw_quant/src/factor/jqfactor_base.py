# -*- coding: utf-8 -*-
"""
聚宽风格因子基类
参考 jqfactor 设计
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)


@dataclass
class FactorMeta:
    """因子元数据"""
    code: str                           # 因子代码
    name: str                           # 因子名称
    category: str                       # 分类: 估值/质量/成长/动量/情绪/风险/技术
    description: str = ""               # 描述
    formula: str = ""                   # 计算公式
    unit: str = ""                      # 单位
    
    # 参数定义
    parameters: Dict[str, Dict] = field(default_factory=dict)
    
    # 数据依赖
    dependencies: List[str] = field(default_factory=list)
    
    # 最大回看窗口（交易日）
    max_window: int = 20
    
    # 是否支持动态参数
    support_params: bool = True


class JQFactor(ABC):
    """
    聚宽风格因子基类
    
    使用方式:
        class PE_TTM_Factor(JQFactor):
            meta = FactorMeta(
                code='PE_TTM',
                name='市盈率TTM',
                category='估值',
                dependencies=['pe_ratio'],
                max_window=1
            )
            
            def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
                pe = data['pe_ratio']
                return 1 / pe  # 低PE得高分
    """
    
    meta: FactorMeta = None
    
    def __init__(self, **params):
        """
        初始化因子
        
        Args:
            **params: 动态参数，覆盖meta中的默认值
        """
        if self.meta is None:
            raise ValueError(f"{self.__class__.__name__} 必须定义 meta 属性")
        
        self.params = self._get_default_params()
        self.params.update(params)
        self.logger = logging.getLogger(f"factor.{self.meta.code}")
    
    def _get_default_params(self) -> Dict[str, Any]:
        """获取默认参数"""
        defaults = {}
        for key, config in self.meta.parameters.items():
            defaults[key] = config.get('default')
        return defaults
    
    @abstractmethod
    def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        """
        计算因子值
        
        Args:
            data: 依赖数据字典，key是dependency名称，value是DataFrame
                  DataFrame的index是日期，columns是股票代码
        
        Returns:
            因子值 Series，index是股票代码，value是因子值
        """
        pass
    
    def pre_process(self, data: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """
        数据预处理
        
        子类可以重写此方法进行自定义预处理
        """
        return data
    
    def post_process(self, values: pd.Series) -> pd.Series:
        """
        结果后处理（去极值、标准化）
        
        1. MAD去极值
        2. Z-score标准化
        """
        if values.empty:
            return values
        
        # MAD去极值
        median = values.median()
        mad = (values - median).abs().median()
        
        if mad > 0:
            upper = median + 3 * 1.4826 * mad
            lower = median - 3 * 1.4826 * mad
            values = values.clip(lower, upper)
        
        # Z-score标准化
        std = values.std()
        if std > 0:
            values = (values - values.mean()) / std
        
        return values
    
    def calculate(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        """
        完整的计算流程
        
        Args:
            data: 原始数据字典
        
        Returns:
            处理后的因子值
        """
        # 预处理
        data = self.pre_process(data)
        
        # 计算因子值
        values = self.calc(data)
        
        # 后处理
        values = self.post_process(values)
        
        return values
    
    def get_info(self) -> Dict[str, Any]:
        """获取因子信息"""
        return {
            'code': self.meta.code,
            'name': self.meta.name,
            'category': self.meta.category,
            'description': self.meta.description,
            'formula': self.meta.formula,
            'parameters': self.meta.parameters,
            'dependencies': self.meta.dependencies,
            'max_window': self.meta.max_window
        }
    
    def get_help(self) -> str:
        """
        生成因子的help文本
        
        Returns:
            格式化的help字符串
        """
        lines = []
        lines.append(f"{'='*60}")
        lines.append(f"因子: {self.meta.code} - {self.meta.name}")
        lines.append(f"{'='*60}")
        lines.append("")
        lines.append(f"【分类】{self.meta.category}")
        lines.append("")
        lines.append(f"【描述】{self.meta.description}")
        lines.append("")
        
        if self.meta.formula:
            lines.append(f"【公式】{self.meta.formula}")
            lines.append("")
        
        if self.meta.unit:
            lines.append(f"【单位】{self.meta.unit}")
            lines.append("")
        
        lines.append(f"【数据依赖】{', '.join(self.meta.dependencies) if self.meta.dependencies else '无'}")
        lines.append("")
        lines.append(f"【最大回看窗口】{self.meta.max_window} 个交易日")
        lines.append("")
        
        if self.meta.parameters:
            lines.append("【参数说明】")
            for param_name, param_config in self.meta.parameters.items():
                param_type = param_config.get('type', 'unknown')
                default = param_config.get('default')
                desc = param_config.get('description', '')
                lines.append(f"  --{param_name}")
                lines.append(f"    类型: {param_type}")
                lines.append(f"    默认值: {default}")
                lines.append(f"    说明: {desc}")
                lines.append("")
        else:
            lines.append("【参数】无")
            lines.append("")
        
        lines.append("【使用示例】")
        lines.append(f"  # 使用默认参数")
        lines.append(f"  python -m claw_quant.cli factor calc {self.meta.code} --date 2024-06-01 --codes 000001.SZ")
        lines.append("")
        
        if self.meta.parameters:
            lines.append("  # 使用自定义参数（Windows PowerShell 用双引号包裹）")
            param_examples = []
            for param_name, param_config in self.meta.parameters.items():
                default = param_config.get('default')
                if isinstance(default, str):
                    param_examples.append(f'{param_name}:{default}')
                else:
                    param_examples.append(f'{param_name}:{default}')
            params_str = ",".join(param_examples)
            lines.append(f'  python -m claw_quant.cli factor calc {self.meta.code} --date 2024-06-01 --codes 000001.SZ --params "{{{params_str}}}"')
            lines.append("")
        
        lines.append("【返回值说明】")
        lines.append("  - value: 因子原始值")
        lines.append("  - rank: 排名（从高到低）")
        lines.append("  - percentile: 百分位（0-1）")
        lines.append("  - zscore: Z-score标准化值")
        lines.append("")
        lines.append(f"{'='*60}")
        
        return "\n".join(lines)


class FactorRegistry:
    """因子注册表"""
    
    _factors: Dict[str, type] = {}
    _dynamic_loaded: bool = False
    
    @classmethod
    def register(cls, factor_class: type):
        """注册因子"""
        if not issubclass(factor_class, JQFactor):
            raise ValueError("因子类必须继承自 JQFactor")
        
        code = factor_class.meta.code
        cls._factors[code] = factor_class
        logger.info(f"注册因子: {code}")
        return factor_class
    
    @classmethod
    def get(cls, code: str) -> Optional[type]:
        """获取因子类"""
        # 先检查静态注册的因子
        factor_class = cls._factors.get(code)
        if factor_class is not None:
            return factor_class
        
        # 如果没有找到，尝试加载动态因子
        if not cls._dynamic_loaded:
            cls._load_dynamic_factors()
            factor_class = cls._factors.get(code)
        
        return factor_class
    
    @classmethod
    def list_factors(cls, category: Optional[str] = None) -> List[str]:
        """列出所有因子代码"""
        # 确保动态因子已加载
        if not cls._dynamic_loaded:
            cls._load_dynamic_factors()
        
        if category is None:
            return list(cls._factors.keys())
        
        return [
            code for code, factor_class in cls._factors.items()
            if factor_class.meta.category == category
        ]
    
    @classmethod
    def get_all_info(cls) -> List[Dict[str, Any]]:
        """获取所有因子信息"""
        # 确保动态因子已加载
        if not cls._dynamic_loaded:
            cls._load_dynamic_factors()
        
        return [factor_class.meta.__dict__ for factor_class in cls._factors.values()]
    
    @classmethod
    def create_factor(cls, code: str, **params) -> Optional[JQFactor]:
        """创建因子实例"""
        factor_class = cls.get(code)
        if factor_class is None:
            return None
        return factor_class(**params)
    
    @classmethod
    def _load_dynamic_factors(cls):
        """加载动态因子"""
        try:
            from .dynamic import get_dynamic_factor_manager
            manager = get_dynamic_factor_manager()
            manager.load_and_register_all()
            cls._dynamic_loaded = True
        except Exception as e:
            logger.warning(f"加载动态因子失败: {e}")


def register_factor(factor_class: type = None):
    """
    因子注册装饰器
    
    用法:
        @register_factor
        class MyFactor(JQFactor):
            ...
    """
    def decorator(cls):
        FactorRegistry.register(cls)
        return cls
    
    if factor_class is None:
        return decorator
    else:
        return decorator(factor_class)
