"""
因子管理器
"""
import pandas as pd
import numpy as np
from datetime import date, timedelta
from typing import List, Dict, Optional
import logging

from .library_base import BaseFactor
from .library import PREDEFINED_FACTORS, get_factor_by_code

logger = logging.getLogger(__name__)


class FactorManager:
    """因子管理器"""
    
    def __init__(self, db_manager):
        """
        初始化因子管理器
        
        Args:
            db_manager: 数据库管理器实例
        """
        self.db = db_manager
        self.factors: Dict[str, BaseFactor] = {}
        
        # 注册预定义因子
        self._register_predefined_factors()
        
    def _register_predefined_factors(self):
        """注册预定义因子"""
        for factor in PREDEFINED_FACTORS:
            self.register_factor(factor)
            
    def register_factor(self, factor: BaseFactor):
        """注册因子"""
        self.factors[factor.config.code] = factor
        
        # 保存到数据库
        self.db.save_factor_definition({
            'code': factor.config.code,
            'name': factor.config.name,
            'category': factor.config.category,
            'description': factor.config.description,
            'formula': factor.config.formula,
            'parameters': factor.config.parameters,
            'frequency': factor.config.frequency
        })
        
        logger.info(f"注册因子: {factor.config.code}")
        
    def get_factor(self, code: str) -> Optional[BaseFactor]:
        """获取因子"""
        return self.factors.get(code)
        
    def list_factors(self, category: Optional[str] = None) -> List[BaseFactor]:
        """列出所有因子"""
        if category:
            return [f for f in self.factors.values() if f.config.category == category]
        return list(self.factors.values())
        
    def calculate_factor(self, 
                         factor_code: str,
                         calc_date: date,
                         codes: Optional[List[str]] = None) -> pd.DataFrame:
        """
        计算单个因子
        
        Args:
            factor_code: 因子代码
            calc_date: 计算日期
            codes: 股票代码列表，None则计算所有股票
            
        Returns:
            DataFrame包含因子值
        """
        factor = self.factors.get(factor_code)
        if not factor:
            raise ValueError(f"因子不存在: {factor_code}")
            
        logger.info(f"计算因子 {factor_code} for {calc_date}")
        
        # 获取股票列表
        if codes is None:
            stocks_df = self.db.get_all_stocks()
            codes = stocks_df['code'].tolist()
            
        # 获取历史数据（过去120天）
        start_date = calc_date - timedelta(days=120)
        
        # 批量获取行情数据
        market_data = self.db.get_market_data_daily_multi(codes, start_date, calc_date)
        
        if market_data.empty:
            logger.warning(f"无行情数据: {calc_date}")
            return pd.DataFrame()
            
        # 按code分组，计算因子值
        results = []
        
        for code in codes:
            code_data = market_data[market_data['code'] == code]
            
            if len(code_data) < 20:  # 至少需要20天数据
                continue
                
            try:
                # 计算因子值
                factor_value = factor.calculate(code_data)
                
                if not factor_value.empty:
                    results.append({
                        'calc_date': calc_date,
                        'code': code,
                        'factor_code': factor_code,
                        'value': factor_value.iloc[-1] if isinstance(factor_value, pd.Series) else factor_value
                    })
            except Exception as e:
                logger.error(f"计算因子失败 {code}: {e}")
                
        if not results:
            return pd.DataFrame()
            
        # 构建DataFrame
        df = pd.DataFrame(results)
        
        # 计算排名和百分位
        df['rank_value'] = df['value'].rank(ascending=False)
        df['percentile'] = df['value'].rank(pct=True)
        
        # Z-score
        mean = df['value'].mean()
        std = df['value'].std()
        df['zscore'] = (df['value'] - mean) / std if std > 0 else 0
        
        return df
        
    def calculate_all_factors(self, 
                              calc_date: date,
                              codes: Optional[List[str]] = None) -> Dict[str, pd.DataFrame]:
        """
        计算所有因子
        
        Args:
            calc_date: 计算日期
            codes: 股票代码列表
            
        Returns:
            {factor_code: DataFrame}
        """
        results = {}
        
        for factor_code in self.factors.keys():
            try:
                df = self.calculate_factor(factor_code, calc_date, codes)
                if not df.empty:
                    results[factor_code] = df
                    
                    # 保存到数据库
                    self.db.save_factor_values(df)
                    
            except Exception as e:
                logger.error(f"计算因子失败 {factor_code}: {e}")
                
        logger.info(f"因子计算完成: {len(results)} 个因子")
        return results
        
    def calculate_factor_history(self,
                                  factor_code: str,
                                  code: str,
                                  start_date: date,
                                  end_date: date) -> pd.DataFrame:
        """
        计算因子历史值
        
        优先从数据库读取，没有则计算
        """
        # 先从数据库读取
        df = self.db.get_factor_values_range(factor_code, code, start_date, end_date)
        
        if not df.empty:
            return df
            
        # 数据库没有，需要计算
        logger.info(f"数据库无数据，计算因子历史值: {factor_code} {code}")
        
        # 获取行情数据
        market_data = self.db.get_market_data_daily(code, start_date - timedelta(days=60), end_date)
        
        if market_data.empty:
            return pd.DataFrame()
            
        factor = self.factors.get(factor_code)
        if not factor:
            return pd.DataFrame()
            
        # 滚动计算
        results = []
        for i in range(20, len(market_data)):
            window = market_data.iloc[:i+1]
            calc_date = window['trade_date'].iloc[-1]
            
            try:
                value = factor.calculate(window)
                if not value.empty:
                    results.append({
                        'calc_date': calc_date,
                        'code': code,
                        'factor_code': factor_code,
                        'value': value.iloc[-1] if isinstance(value, pd.Series) else value
                    })
            except Exception as e:
                logger.error(f"计算失败 {calc_date}: {e}")
                
        return pd.DataFrame(results)
        
    def get_factor_values(self,
                          factor_codes: List[str],
                          calc_date: date,
                          codes: Optional[List[str]] = None) -> pd.DataFrame:
        """
        获取因子值
        
        优先从数据库读取
        """
        # 从数据库读取
        df = self.db.get_factor_values(factor_codes, calc_date, codes)
        
        if not df.empty:
            return df
            
        # 数据库没有，计算并保存
        logger.info(f"数据库无数据，计算因子值")
        
        all_results = []
        for factor_code in factor_codes:
            result = self.calculate_factor(factor_code, calc_date, codes)
            if not result.empty:
                all_results.append(result)
                self.db.save_factor_values(result)
                
        if all_results:
            return pd.concat(all_results, ignore_index=True)
        return pd.DataFrame()
        
    def get_factor_correlation(self, 
                               factor_codes: List[str],
                               calc_date: date) -> pd.DataFrame:
        """获取因子相关性矩阵"""
        # 获取因子值
        factor_values = {}
        
        for code in factor_codes:
            df = self.db.get_factor_values([code], calc_date)
            if not df.empty:
                factor_values[code] = df.set_index('code')['value']
                
        if not factor_values:
            return pd.DataFrame()
            
        # 构建DataFrame并计算相关性
        df = pd.DataFrame(factor_values)
        return df.corr()
        
    def calculate_ic(self,
                     factor_code: str,
                     forward_return_days: int = 5,
                     start_date: date = None,
                     end_date: date = None) -> Dict:
        """
        计算因子IC (信息系数)
        
        IC = corr(factor_value, forward_return)
        """
        if start_date is None:
            start_date = date.today() - timedelta(days=252)
        if end_date is None:
            end_date = date.today()
            
        # 获取因子值和收益率
        ics = []
        
        current_date = start_date
        while current_date <= end_date:
            # 获取当日因子值
            factor_df = self.db.get_factor_values([factor_code], current_date)
            
            if factor_df.empty:
                current_date += timedelta(days=1)
                continue
                
            # 获取未来收益
            forward_date = current_date + timedelta(days=forward_return_days)
            
            # 简化处理，实际需要计算收益率
            # 这里仅示例
            
            current_date += timedelta(days=1)
            
        if not ics:
            return {'ic_mean': 0, 'ic_std': 0, 'ir': 0}
            
        ic_mean = np.mean(ics)
        ic_std = np.std(ics)
        ir = ic_mean / ic_std if ic_std > 0 else 0
        
        return {
            'ic_mean': ic_mean,
            'ic_std': ic_std,
            'ir': ir,
            'ic_series': ics
        }
        
    def create_composite_factor(self, 
                                 name: str,
                                 weights: Dict[str, float]) -> 'CompositeFactor':
        """创建复合因子"""
        from .factors import CompositeFactor
        
        composite = CompositeFactor(weights)
        composite.config.code = name
        composite.config.name = name
        
        self.register_factor(composite)
        
        return composite
