# -*- coding: utf-8 -*-
"""
技术指标类因子
参考聚宽因子库设计
"""

import pandas as pd
import numpy as np
from .jqfactor_base import JQFactor, FactorMeta, register_factor


@register_factor
class MA_Cross_Factor(JQFactor):
    """均线交叉因子"""
    
    meta = FactorMeta(
        code='MA_CROSS',
        name='均线交叉',
        category='技术',
        description='短期均线上穿长期均线为正，下穿为负',
        formula='MA_short - MA_long',
        dependencies=['close'],
        max_window=30,
        parameters={
            'short_window': {'type': 'int', 'default': 5, 'description': '短期均线窗口'},
            'long_window': {'type': 'int', 'default': 20, 'description': '长期均线窗口'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.short_window = self.params.get('short_window', 5)
        self.long_window = self.params.get('long_window', 20)
    
    def calc(self, data):
        close = data['close']
        ma_short = close.iloc[-self.short_window:].mean()
        ma_long = close.iloc[-self.long_window:].mean()
        return ma_short - ma_long


@register_factor
class MACD_Factor(JQFactor):
    """MACD因子"""
    
    meta = FactorMeta(
        code='MACD',
        name='MACD',
        category='技术',
        description='MACD柱状线值',
        formula='EMA_fast - EMA_slow',
        dependencies=['close'],
        max_window=40,
        parameters={
            'fast': {'type': 'int', 'default': 12, 'description': '快线周期'},
            'slow': {'type': 'int', 'default': 26, 'description': '慢线周期'},
            'signal': {'type': 'int', 'default': 9, 'description': '信号线周期'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.fast = self.params.get('fast', 12)
        self.slow = self.params.get('slow', 26)
        self.signal = self.params.get('signal', 9)
    
    def calc(self, data):
        close = data['close']
        
        # 计算EMA
        ema_fast = close.ewm(span=self.fast, adjust=False).mean().iloc[-1]
        ema_slow = close.ewm(span=self.slow, adjust=False).mean().iloc[-1]
        
        # MACD线
        macd_line = ema_fast - ema_slow
        
        # 信号线（简化计算）
        macd_series = close.ewm(span=self.fast, adjust=False).mean() - close.ewm(span=self.slow, adjust=False).mean()
        signal_line = macd_series.ewm(span=self.signal, adjust=False).mean().iloc[-1]
        
        # 柱状线
        histogram = macd_line - signal_line
        return histogram


@register_factor
class RSI_Factor(JQFactor):
    """RSI相对强弱指标"""
    
    meta = FactorMeta(
        code='RSI',
        name='RSI',
        category='技术',
        description='RSI相对强弱指标（反转，低RSI得高分）',
        formula='100 - RSI_period',
        dependencies=['close'],
        max_window=20,
        parameters={
            'period': {'type': 'int', 'default': 14, 'description': 'RSI周期'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.period = self.params.get('period', 14)
    
    def calc(self, data):
        close = data['close'].iloc[-self.period-1:]
        
        # 计算价格变化
        delta = close.diff().iloc[1:]
        
        # 计算上涨和下跌
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        # 计算平均上涨和下跌
        avg_gain = gain.mean()
        avg_loss = loss.mean()
        
        # 计算RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        # 反转，低RSI得高分（超卖买入）
        return 100 - rsi


@register_factor
class KDJ_Factor(JQFactor):
    """KDJ随机指标"""
    
    meta = FactorMeta(
        code='KDJ',
        name='KDJ',
        category='技术',
        description='KDJ随机指标J值（反转，低J值得高分）',
        formula='100 - J_value',
        dependencies=['close', 'high', 'low'],
        max_window=15,
        parameters={
            'n': {'type': 'int', 'default': 9, 'description': ' RSV周期'},
            'm1': {'type': 'int', 'default': 3, 'description': 'K平滑系数'},
            'm2': {'type': 'int', 'default': 3, 'description': 'D平滑系数'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.n = self.params.get('n', 9)
        self.m1 = self.params.get('m1', 3)
        self.m2 = self.params.get('m2', 3)
    
    def calc(self, data):
        close = data['close'].iloc[-self.n:]
        high = data['high'].iloc[-self.n:]
        low = data['low'].iloc[-self.n:]
        
        # 计算RSV
        rsv = (close.iloc[-1] - low.min()) / (high.max() - low.min()) * 100
        
        # 简化计算K、D、J（假设前一日K=50, D=50）
        k = 2/3 * 50 + 1/3 * rsv
        d = 2/3 * 50 + 1/3 * k
        j = 3 * k - 2 * d
        
        # 反转，低J值得高分
        return 100 - j


@register_factor
class Bollinger_Factor(JQFactor):
    """布林带因子"""
    
    meta = FactorMeta(
        code='BOLLINGER',
        name='布林带',
        category='技术',
        description='布林带位置（反转，低于下轨得高分）',
        formula='-(close - MA) / (2 * std)',
        dependencies=['close'],
        max_window=25,
        parameters={
            'window': {'type': 'int', 'default': 20, 'description': '布林带周期'},
            'num_std': {'type': 'float', 'default': 2.0, 'description': '标准差倍数'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.window = self.params.get('window', 20)
        self.num_std = self.params.get('num_std', 2.0)
    
    def calc(self, data):
        close = data['close'].iloc[-self.window:]
        
        # 计算中轨和带宽
        ma = close.mean()
        std = close.std()
        
        # 计算当前价格在布林带中的位置
        position = (close.iloc[-1] - ma) / (self.num_std * std)
        
        # 反转，低于下轨得高分
        return -position


@register_factor
class CCI_Factor(JQFactor):
    """CCI顺势指标"""
    
    meta = FactorMeta(
        code='CCI',
        name='CCI',
        category='技术',
        description='CCI顺势指标（反转，低CCI得高分）',
        formula='-(TP - MA_TP) / (0.015 * mean_deviation)',
        dependencies=['close', 'high', 'low'],
        max_window=25,
        parameters={
            'period': {'type': 'int', 'default': 14, 'description': 'CCI周期'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.period = self.params.get('period', 14)
    
    def calc(self, data):
        close = data['close'].iloc[-self.period:]
        high = data['high'].iloc[-self.period:]
        low = data['low'].iloc[-self.period:]
        
        # 计算典型价格
        tp = (high + low + close) / 3
        
        # 计算CCI
        ma_tp = tp.mean()
        mean_dev = (tp - ma_tp).abs().mean()
        cci = (tp.iloc[-1] - ma_tp) / (0.015 * mean_dev)
        
        # 反转，低CCI得高分
        return -cci


@register_factor
class Williams_R_Factor(JQFactor):
    """威廉指标"""
    
    meta = FactorMeta(
        code='WILLIAMS_R',
        name='威廉指标',
        category='技术',
        description='威廉指标（反转，低WR得高分）',
        formula='-(high_n - close) / (high_n - low_n) * 100',
        dependencies=['close', 'high', 'low'],
        max_window=20,
        parameters={
            'period': {'type': 'int', 'default': 14, 'description': '威廉周期'}
        }
    )
    
    def __init__(self, **params):
        super().__init__(**params)
        self.period = self.params.get('period', 14)
    
    def calc(self, data):
        close = data['close'].iloc[-self.period:]
        high = data['high'].iloc[-self.period:]
        low = data['low'].iloc[-self.period:]
        
        # 计算威廉指标
        highest_high = high.max()
        lowest_low = low.min()
        
        wr = (highest_high - close.iloc[-1]) / (highest_high - lowest_low) * 100
        
        # 已经是负向指标，低WR表示超卖
        return wr
