# -*- coding: utf-8 -*-
"""
技术指标因子
"""

from typing import Dict, List, Optional, Any
import pandas as pd
import numpy as np
from .base import Factor, register_factor


@register_factor('MA')
class MAFactor(Factor):
    """
    移动平均线因子
    
    参数:
        window: 窗口期，默认20
        field: 计算字段，默认'close'
    """
    
    def __init__(self, window: int = 20, field: str = 'close'):
        super().__init__(f'MA{window}', {'window': window, 'field': field})
        self.window = window
        self.field = field
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """计算移动平均"""
        return data[self.field].rolling(window=self.window).mean()


@register_factor('MACD')
class MACDFactor(Factor):
    """
    MACD因子
    
    参数:
        fast: 快线周期，默认12
        slow: 慢线周期，默认26
        signal: 信号线周期，默认9
    """
    
    def __init__(self, fast: int = 12, slow: int = 26, signal: int = 9):
        super().__init__('MACD', {'fast': fast, 'slow': slow, 'signal': signal})
        self.fast = fast
        self.slow = slow
        self.signal = signal
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """计算MACD柱状图"""
        ema_fast = data['close'].ewm(span=self.fast, adjust=False).mean()
        ema_slow = data['close'].ewm(span=self.slow, adjust=False).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=self.signal, adjust=False).mean()
        histogram = macd_line - signal_line
        return histogram


@register_factor('RSI')
class RSIFactor(Factor):
    """
    RSI相对强弱指标
    
    参数:
        window: 窗口期，默认14
    """
    
    def __init__(self, window: int = 14):
        super().__init__(f'RSI{window}', {'window': window})
        self.window = window
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """计算RSI"""
        delta = data['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=self.window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=self.window).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi


@register_factor('CROSS')
class CrossFactor(Factor):
    """
    均线交叉因子（金叉/死叉信号）
    
    参数:
        short_window: 短期均线窗口，默认5
        long_window: 长期均线窗口，默认20
        
    返回值:
        1: 金叉（短期上穿长期）
        -1: 死叉（短期下穿长期）
        0: 无信号
    """
    
    def __init__(self, short_window: int = 5, long_window: int = 20):
        super().__init__(f'CROSS_{short_window}_{long_window}', 
                        {'short_window': short_window, 'long_window': long_window})
        self.short_window = short_window
        self.long_window = long_window
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """计算交叉信号"""
        ma_short = data['close'].rolling(window=self.short_window).mean()
        ma_long = data['close'].rolling(window=self.long_window).mean()
        
        # 当前和前一期的均线位置（转换为布尔值，处理NaN）
        short_above = (ma_short > ma_long).fillna(False)
        short_above_prev = short_above.shift(1).fillna(False)
        
        # 金叉：前期短期<长期，本期短期>长期
        golden_cross = short_above & (~short_above_prev)
        
        # 死叉：前期短期>长期，本期短期<长期
        death_cross = (~short_above) & short_above_prev
        
        # 生成信号
        signal = pd.Series(0, index=data.index, dtype=int)
        signal[golden_cross] = 1
        signal[death_cross] = -1
        
        return signal


@register_factor('MOM')
class MomentumFactor(Factor):
    """
    动量因子
    
    参数:
        window: 窗口期，默认20
    """
    
    def __init__(self, window: int = 20):
        super().__init__(f'MOM{window}', {'window': window})
        self.window = window
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """计算动量（当前价格/N周期前价格 - 1）"""
        return data['close'] / data['close'].shift(self.window) - 1


@register_factor('ATR')
class ATRFactor(Factor):
    """
    平均真实波幅因子
    
    参数:
        window: 窗口期，默认14
    """
    
    def __init__(self, window: int = 14):
        super().__init__(f'ATR{window}', {'window': window})
        self.window = window
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """计算ATR"""
        high_low = data['high'] - data['low']
        high_close = np.abs(data['high'] - data['close'].shift())
        low_close = np.abs(data['low'] - data['close'].shift())
        
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr = tr.rolling(window=self.window).mean()
        
        return atr


@register_factor('VOLATILITY')
class VolatilityFactor(Factor):
    """
    波动率因子（收益率标准差）
    
    参数:
        window: 窗口期，默认20
    """
    
    def __init__(self, window: int = 20):
        super().__init__(f'VOL{window}', {'window': window})
        self.window = window
        
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """计算波动率"""
        returns = data['close'].pct_change()
        return returns.rolling(window=self.window).std()
