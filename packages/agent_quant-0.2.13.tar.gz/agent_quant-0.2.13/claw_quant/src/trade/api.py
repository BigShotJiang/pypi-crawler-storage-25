"""
交易API - 提供实盘/模拟交易接口
"""
from typing import Dict, List, Optional, Union, Any
from datetime import datetime
from dataclasses import dataclass
from enum import Enum
from abc import ABC, abstractmethod


class OrderType(Enum):
    """订单类型"""
    MARKET = 'market'          # 市价单
    LIMIT = 'limit'            # 限价单
    STOP = 'stop'              # 止损单
    STOP_LIMIT = 'stop_limit'  # 止损限价单


class OrderSide(Enum):
    """买卖方向"""
    BUY = 'buy'
    SELL = 'sell'


class OrderStatus(Enum):
    """订单状态"""
    PENDING = 'pending'           # 待报
    SUBMITTED = 'submitted'       # 已报
    PARTIAL_FILLED = 'partial'    # 部分成交
    FILLED = 'filled'             # 全部成交
    CANCELLED = 'cancelled'       # 已撤单
    REJECTED = 'rejected'         # 已拒绝
    EXPIRED = 'expired'           # 已过期


@dataclass
class Order:
    """订单对象"""
    order_id: str
    code: str
    side: OrderSide
    order_type: OrderType
    price: float
    volume: int
    filled_volume: int = 0
    avg_price: float = 0.0
    status: OrderStatus = OrderStatus.PENDING
    create_time: Optional[datetime] = None
    update_time: Optional[datetime] = None
    memo: str = ''


@dataclass
class Trade:
    """成交记录"""
    trade_id: str
    order_id: str
    code: str
    side: OrderSide
    price: float
    volume: int
    amount: float
    time: datetime
    commission: float = 0.0
    tax: float = 0.0


@dataclass
class Account:
    """账户信息"""
    account_id: str
    account_type: str  # 'stock'|'credit'|'future'
    total_assets: float
    cash: float
    market_value: float
    frozen_cash: float
    available_cash: float
    profit_loss: float
    profit_loss_pct: float


@dataclass
class Position:
    """持仓信息"""
    code: str
    name: str
    volume: int
    available_volume: int
    cost_price: float
    current_price: float
    market_value: float
    profit_loss: float
    profit_loss_pct: float


class Trader(ABC):
    """交易接口抽象基类"""
    
    @abstractmethod
    def connect(self) -> bool:
        """连接交易服务器"""
        pass
    
    @abstractmethod
    def disconnect(self):
        """断开连接"""
        pass
    
    @abstractmethod
    def is_connected(self) -> bool:
        """检查连接状态"""
        pass
    
    @abstractmethod
    def order(
        self,
        code: str,
        side: OrderSide,
        volume: int,
        price: Optional[float] = None,
        order_type: OrderType = OrderType.MARKET
    ) -> Optional[Order]:
        """下单"""
        pass
    
    @abstractmethod
    def cancel(self, order_id: str) -> bool:
        """撤单"""
        pass
    
    @abstractmethod
    def get_orders(self, status: Optional[OrderStatus] = None) -> List[Order]:
        """查询订单"""
        pass
    
    @abstractmethod
    def get_trades(self, start: Optional[datetime] = None, end: Optional[datetime] = None) -> List[Trade]:
        """查询成交"""
        pass
    
    @abstractmethod
    def get_account(self) -> Account:
        """查询账户"""
        pass
    
    @abstractmethod
    def get_positions(self, code: Optional[str] = None) -> List[Position]:
        """查询持仓"""
        pass


class TradeAPI:
    """
    交易API类
    
    提供实盘/模拟交易功能
    
    Examples:
        >>> sdk = StockClaw()
        >>> 
        >>> # 连接QMT实盘
        >>> trader = sdk.trade.connect_qmt(
        ...     account_id='123456',
        ...     account_type='stock'
        ... )
        >>> 
        >>> # 查询账户
        >>> account = trader.get_account()
        >>> print(f"总资产: {account.total_assets}")
        >>> 
        >>> # 查询持仓
        >>> positions = trader.get_positions()
        >>> 
        >>> # 下单
        >>> order = trader.order('000001.SZ', OrderSide.BUY, 100, price=10.5)
        >>> 
        >>> # 撤单
        >>> trader.cancel(order.order_id)
        >>> 
        >>> # 模拟交易
        >>> paper = sdk.trade.create_paper_account(
        ...     name='模拟账户1',
        ...     initial_capital=1000000
        ... )
        >>> paper.order('000001.SZ', OrderSide.BUY, 100)
    """
    
    def __init__(self, config: Dict[str, Any]):
        self._config = config
        self._traders: Dict[str, Trader] = {}
        self._paper_accounts: Dict[str, Dict] = {}
    
    def is_connected(self) -> bool:
        """检查是否有连接的交易接口"""
        return any(t.is_connected() for t in self._traders.values())
    
    # ==================== QMT实盘接口 ====================
    
    def connect_qmt(
        self,
        account_id: str,
        account_type: str = 'stock',
        qmt_path: Optional[str] = None
    ) -> Trader:
        """
        连接QMT实盘交易
        
        Args:
            account_id: 资金账号
            account_type: 账号类型，'stock'|'credit'
            qmt_path: QMT安装路径
        
        Returns:
            Trader对象
        """
        raise NotImplementedError()
    
    def connect_miniqmt(
        self,
        account_id: str,
        account_type: str = 'stock'
    ) -> Trader:
        """
        连接miniQMT（极简模式）
        
        Args:
            account_id: 资金账号
            account_type: 账号类型
        
        Returns:
            Trader对象
        """
        raise NotImplementedError()
    
    # ==================== 模拟交易接口 ====================
    
    def create_paper_account(
        self,
        name: str,
        initial_capital: float = 1000000.0,
        commission_rate: float = 0.0003,
        slippage: float = 0.001
    ) -> Trader:
        """
        创建模拟交易账户
        
        Args:
            name: 账户名称
            initial_capital: 初始资金
            commission_rate: 佣金费率
            slippage: 滑点
        
        Returns:
            Trader对象
        """
        raise NotImplementedError()
    
    def get_paper_accounts(self) -> List[Dict[str, Any]]:
        """获取所有模拟账户列表"""
        raise NotImplementedError()
    
    def delete_paper_account(self, account_id: str) -> bool:
        """删除模拟账户"""
        raise NotImplementedError()
    
    # ==================== 交易监控接口 ====================
    
    def subscribe_order_update(self, callback: callable, account_id: Optional[str] = None):
        """
        订阅订单状态更新
        
        Args:
            callback: 回调函数，接收Order对象
            account_id: 账号ID，None表示订阅所有
        """
        raise NotImplementedError()
    
    def subscribe_trade_update(self, callback: callable, account_id: Optional[str] = None):
        """
        订阅成交更新
        
        Args:
            callback: 回调函数，接收Trade对象
            account_id: 账号ID，None表示订阅所有
        """
        raise NotImplementedError()
    
    def subscribe_position_update(self, callback: callable, account_id: Optional[str] = None):
        """
        订阅持仓更新
        
        Args:
            callback: 回调函数，接收Position列表
            account_id: 账号ID，None表示订阅所有
        """
        raise NotImplementedError()
    
    # ==================== 风险控制接口 ====================
    
    def set_risk_control(
        self,
        account_id: str,
        max_position_pct: Optional[float] = None,
        max_single_stock_pct: Optional[float] = None,
        max_drawdown_pct: Optional[float] = None,
        daily_loss_limit: Optional[float] = None
    ):
        """
        设置风险控制参数
        
        Args:
            account_id: 账号ID
            max_position_pct: 最大仓位比例
            max_single_stock_pct: 单只股票最大仓位
            max_drawdown_pct: 最大回撤限制
            daily_loss_limit: 日亏损限制
        """
        raise NotImplementedError()
