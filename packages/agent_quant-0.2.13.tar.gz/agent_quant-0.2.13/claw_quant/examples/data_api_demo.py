"""
DataAPI 使用示例

演示如何使用claw_quant的DataAPI获取股票数据
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from api.data_implement import DataAPIImpl
from datetime import date, datetime, timedelta


def demo_basic_usage():
    """基础使用示例"""
    print("=" * 60)
    print("DataAPI 基础使用示例")
    print("=" * 60)

    # 初始化API
    config = {
        'data_source': 'duckdb',
        'db_path': '../data/demo.db',
        'qmt_path': None  # 如果有QMT，可以指定路径
    }

    api = DataAPIImpl(config)

    if not api.is_connected():
        print("数据库连接失败，请检查配置")
        return

    print(f"✓ 数据库连接成功")
    print()

    # 1. 获取股票列表
    print("1. 获取股票列表")
    stocks = api.get_stock_list()
    print(f"   股票数量: {len(stocks)}")
    if not stocks.empty:
        print(f"   前5只股票:")
        print(stocks.head()[['code', 'name', 'market']].to_string(index=False))
    print()

    # 2. 下载单只股票数据
    print("2. 下载单只股票数据")
    print("   正在下载 000001.SZ (平安银行) 过去1年数据...")
    result = api.download(
        '000001.SZ',
        period='1d',
        start=(date.today() - timedelta(days=365)).strftime('%Y%m%d'),
        end=date.today().strftime('%Y%m%d')
    )
    print(f"   下载结果: 成功 {result.get('success', 0)} 条记录")
    print()

    # 3. 查询日线数据
    print("3. 查询日线数据")
    df = api.get_daily(
        '000001.SZ',
        start=(date.today() - timedelta(days=30)).strftime('%Y%m%d'),
        end=date.today().strftime('%Y%m%d')
    )
    print(f"   获取到 {len(df)} 条记录")
    if not df.empty:
        print("   最近5天数据:")
        print(df[['trade_date', 'open', 'high', 'low', 'close', 'volume']].tail().to_string(index=False))
    print()

    # 4. 获取实时行情（需要QMT连接）
    print("4. 获取实时行情")
    try:
        rt = api.get_realtime(['000001.SZ', '000002.SZ'])
        if not rt.empty:
            print("   实时行情:")
            print(rt[['code', 'price', 'change_pct']].to_string(index=False))
        else:
            print("   未获取到实时行情（可能需要连接QMT）")
    except Exception as e:
        print(f"   获取实时行情失败: {e}")
    print()

    print("=" * 60)
    print("示例运行完成")
    print("=" * 60)


def demo_batch_download():
    """批量下载示例"""
    print("\n" + "=" * 60)
    print("批量数据下载示例")
    print("=" * 60)

    config = {
        'data_source': 'duckdb',
        'db_path': '../data/demo.db',
        'qmt_path': None
    }

    api = DataAPIImpl(config)

    # 批量下载多只股票
    codes = ['000001.SZ', '000002.SZ', '600000.SH']
    print(f"批量下载 {len(codes)} 只股票数据...")

    result = api.download(
        codes,
        period='1d',
        start='20240101',
        end=date.today().strftime('%Y%m%d')
    )

    print(f"下载完成:")
    print(f"  - 总股票数: {result.get('total', 0)}")
    print(f"  - 成功: {result.get('success', 0)}")
    print(f"  - 失败: {result.get('failed', 0)}")
    print(f"  - 总记录数: {result.get('records', 0)}")


def demo_query_multiple_stocks():
    """查询多只股票示例"""
    print("\n" + "=" * 60)
    print("查询多只股票示例")
    print("=" * 60)

    config = {
        'data_source': 'duckdb',
        'db_path': '../data/demo.db',
        'qmt_path': None
    }

    api = DataAPIImpl(config)

    # 先下载一些数据
    codes = ['000001.SZ', '000002.SZ']
    api.download(codes, start='20240101', end=date.today().strftime('%Y%m%d'))

    # 查询多只股票
    df = api.get_daily(
        codes,
        start='20240101',
        end=date.today().strftime('%Y%m%d')
    )

    print(f"查询到 {len(df)} 条记录")
    if not df.empty:
        print("\n按股票分组统计:")
        stats = df.groupby('code').agg({
            'close': ['mean', 'min', 'max'],
            'volume': 'mean'
        })
        print(stats)


if __name__ == '__main__':
    # 运行示例
    try:
        demo_basic_usage()
    except Exception as e:
        print(f"基础示例运行失败: {e}")
        import traceback
        traceback.print_exc()

    # 注意：批量下载需要QMT连接
    # demo_batch_download()
    # demo_query_multiple_stocks()
