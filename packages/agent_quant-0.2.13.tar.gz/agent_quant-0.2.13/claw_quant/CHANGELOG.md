# 更新日志

所有重要的变更都会记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
并且本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [Unreleased]

### Added
- 项目初始开源版本
- 数据管理模块：支持 DuckDB 本地存储和 HTTP API 访问
- 因子分析模块：包含 20+ 常用技术指标和情绪因子
- 策略回测模块：支持 Local、CSKhQuant、JQData、VNPY 多引擎
- 图形界面：数据查看器和回测界面
- CLI 工具：完整的命令行接口
- Skill 接口：AI Agent 调用支持

## [0.1.0] - 2024-04-24

### Added
- 项目初始版本发布
- 基础架构搭建
- 数据库模块实现
  - DuckDB 存储引擎
  - HTTP API 服务
  - 数据更新调度器
- 回测引擎实现
  - 本地轻量级引擎
  - CSKhQuant 引擎适配
  - JQData 引擎适配
  - VNPY 引擎适配
  - 统一回测接口
- 因子库实现
  - 技术指标因子（MA、MACD、RSI、KDJ 等）
  - 情绪指标因子（PSY、VR、OBV 等）
  - 质量因子
  - 估值因子
  - 成长因子
- 策略库实现
  - 均线交叉策略
  - MACD 策略
  - 多因子选股策略
  - 动量策略
- CLI 工具实现
  - 数据管理命令
  - 因子管理命令
  - 策略管理命令
  - 回测命令
- GUI 实现
  - 数据查看器
  - 回测对话框
  - 批量下载器
- 文档和示例

### Changed
- 项目结构重构，采用 src 布局
- 优化导入路径

### Fixed
- 修复数据库连接错误提示
- 修复多引擎回测结果对比问题

[Unreleased]: https://github.com/clawquant/claw_quant/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/clawquant/claw_quant/releases/tag/v0.1.0
