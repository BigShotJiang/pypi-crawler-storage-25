@echo off
title Install Stock Query System Requirements
echo ==========================================
echo Install A-Share Stock Query Dependencies
echo ==========================================
echo.

REM Set Python path
set PYTHON_PATH=C:\Python312\python.exe

echo [1/3] Checking Python installation...
if not exist "%PYTHON_PATH%" (
    echo [ERROR] Python not found at %PYTHON_PATH%!
    echo Please install Python 3.10+ or modify PYTHON_PATH in this script
    pause
    exit /b 1
)

echo [OK] Python found:
"%PYTHON_PATH%" --version
echo.

REM Upgrade pip
echo [2/3] Upgrading pip...
"%PYTHON_PATH%" -m pip install --upgrade pip -q
echo [OK] pip upgraded
echo.

REM Install requirements
echo [3/3] Installing dependencies...
cd /d "%~dp0\.."
"%PYTHON_PATH%" -m pip install -r requirements.txt
echo [OK] Dependencies installed
echo.

echo ==========================================
echo Installation Complete!
echo ==========================================
pause
