"""
DuckDB 数据库客户端 V3 - 对应 db_service_v3

特点：
1. 支持长连接
2. 自动重连
3. 更长的超时时间
"""
import socket
import struct
import pickle
import logging
from typing import Optional, Any
import pandas as pd
from datetime import date

logger = logging.getLogger(__name__)

DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 9528
HEADER_SIZE = 4
MAX_MSG_SIZE = 256 * 1024 * 1024


def _send_message(sock: socket.socket, data: Any):
    """发送消息"""
    payload = pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL)
    msg_len = len(payload)
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes")
    header = struct.pack('>I', msg_len)
    sock.sendall(header + payload)


def _recv_message(sock: socket.socket) -> Optional[Any]:
    """接收消息"""
    header = _recv_exact(sock, HEADER_SIZE)
    if header is None:
        return None
    msg_len = struct.unpack('>I', header)[0]
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes")
    payload = _recv_exact(sock, msg_len)
    if payload is None:
        return None
    return pickle.loads(payload)


def _recv_exact(sock: socket.socket, n: int) -> Optional[bytes]:
    """精确读取n字节"""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 65536))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


class DBClient:
    """数据库客户端 V3"""

    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT,
                 timeout: float = 60.0, max_retries: int = 3):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.max_retries = max_retries
        self._sock: Optional[socket.socket] = None

    def _connect(self):
        """建立连接"""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(self.timeout)
        self._sock.connect((self.host, self.port))
        logger.debug(f"已连接到数据库服务: {self.host}:{self.port}")

    def close(self):
        """关闭连接"""
        if self._sock:
            try:
                self._sock.close()
            except:
                pass
            self._sock = None

    def _call(self, method_name: str, *args, **kwargs) -> Any:
        """调用远程方法（带自动重连）"""
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                if self._sock is None:
                    self._connect()

                request = (method_name, args, kwargs)
                _send_message(self._sock, request)
                response = _recv_message(self._sock)

                if response is None:
                    raise ConnectionError("服务端断开连接")

                if response['ok']:
                    return response['result']
                else:
                    raise RuntimeError(f"数据库操作失败: {response['error']}")

            except (ConnectionError, BrokenPipeError, OSError, socket.timeout) as e:
                last_error = e
                logger.warning(f"连接异常 (尝试 {attempt + 1}/{self.max_retries}): {e}")
                self._sock = None
                if attempt < self.max_retries - 1:
                    import time
                    time.sleep(0.5)

        raise ConnectionError(f"数据库服务连接失败 (已重试{self.max_retries}次): {last_error}")

    def ping(self) -> bool:
        """测试连接"""
        try:
            result = self._call('__ping__')
            return result == 'pong'
        except:
            return False

    # ==================== 股票列表操作 ====================

    def get_all_stocks(self) -> pd.DataFrame:
        """获取所有股票列表"""
        result = self._call('get_all_stocks')
        return result if result is not None else pd.DataFrame()

    def save_stock_list(self, df: pd.DataFrame):
        """保存股票列表"""
        return self._call('save_stock_list', df)

    # ==================== 日线数据操作 ====================

    def save_market_data_daily(self, df: pd.DataFrame):
        """保存日线数据"""
        if df.empty:
            return
        return self._call('save_market_data_daily', df)

    def get_market_data_daily(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """获取单只股票日线数据"""
        result = self._call('get_market_data_daily', code, start_date, end_date)
        return result if result is not None else pd.DataFrame()

    def get_market_data_daily_multi(self, codes: list, start_date: date, end_date: date) -> pd.DataFrame:
        """获取多只股票日线数据"""
        result = self._call('get_market_data_daily_multi', codes, start_date, end_date)
        return result if result is not None else pd.DataFrame()

    def get_latest_trade_date(self) -> Optional[date]:
        """获取最新交易日期"""
        return self._call('get_latest_trade_date')

    def get_date_range(self, code: str) -> tuple:
        """获取股票数据日期范围"""
        return self._call('get_date_range', code)

    # ==================== 因子数据操作 ====================

    def save_factor_data(self, df: pd.DataFrame):
        """保存因子数据"""
        if df.empty:
            return
        return self._call('save_factor_data', df)

    def get_factor_data(self, factor_name: str, trade_date: date) -> pd.DataFrame:
        """获取某一天的因子数据"""
        result = self._call('get_factor_data', factor_name, trade_date)
        return result if result is not None else pd.DataFrame()

    def get_factor_data_multi(self, factor_name: str, start_date: date, end_date: date) -> pd.DataFrame:
        """获取因子时间序列数据"""
        result = self._call('get_factor_data_multi', factor_name, start_date, end_date)
        return result if result is not None else pd.DataFrame()

    def get_factor_names(self) -> list:
        """获取所有因子名称"""
        result = self._call('get_factor_names')
        return result if result is not None else []

    def get_factor_dates(self, factor_name: str) -> list:
        """获取因子的所有日期"""
        result = self._call('get_factor_dates', factor_name)
        return result if result is not None else []
