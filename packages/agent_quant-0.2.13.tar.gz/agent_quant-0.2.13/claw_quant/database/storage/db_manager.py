"""
DuckDB 数据库管理器
"""
import duckdb
import pandas as pd
from datetime import date, datetime
from typing import Optional, List, Dict, Any
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DuckDBManager:
    """DuckDB 数据库管理器 - 单文件管理所有数据"""
    
    def __init__(self, db_path: str = "data/quant_system.db"):
        """
        初始化数据库管理器
        
        Args:
            db_path: 数据库文件路径
        """
        self.db_path = db_path
        self.conn = None
        
        # 确保目录存在
        db_dir = os.path.dirname(db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        
        self.connect()
        self.init_tables()
        
    def connect(self):
        """连接数据库"""
        try:
            self.conn = duckdb.connect(self.db_path)
            logger.info(f"已连接数据库: {self.db_path}")
        except Exception as e:
            logger.error(f"连接数据库失败: {e}")
            raise
            
    def close(self):
        """关闭连接"""
        if self.conn:
            self.conn.close()
            logger.info("数据库连接已关闭")
            
    def init_tables(self):
        """初始化所有表"""
        schema_path = os.path.join(os.path.dirname(__file__), 'schema.sql')
        
        if not os.path.exists(schema_path):
            logger.warning(f"Schema文件不存在: {schema_path}")
            return
            
        with open(schema_path, 'r', encoding='utf-8') as f:
            schema_sql = f.read()
            
        # 分割并执行每个语句
        statements = [s.strip() for s in schema_sql.split(';') if s.strip()]
        
        for stmt in statements:
            try:
                self.conn.execute(stmt)
            except Exception as e:
                # 表/索引已存在会报错，忽略
                if 'already exists' not in str(e).lower():
                    logger.warning(f"执行SQL失败: {e}")
                    
        logger.info("数据库表初始化完成")
    
    # ============================================
    # 股票基础信息操作
    # ============================================
    
    def save_stocks(self, df: pd.DataFrame):
        """
        保存股票基础信息
        
        Args:
            df: DataFrame包含code, name, market, industry等列
        """
        if df.empty:
            return
            
        # 注册临时表
        self.conn.register('temp_stocks', df)
        
        self.conn.execute("""
            INSERT INTO stocks
            SELECT code, name, market, industry, list_date, status,
                   now(), now()
            FROM temp_stocks
            ON CONFLICT (code) DO UPDATE SET
                name = EXCLUDED.name,
                market = EXCLUDED.market,
                industry = EXCLUDED.industry,
                list_date = EXCLUDED.list_date,
                status = EXCLUDED.status,
                updated_at = now()
        """)
        
        self.conn.unregister('temp_stocks')
        logger.info(f"保存股票信息: {len(df)} 条")
        
    def get_all_stocks(self) -> pd.DataFrame:
        """获取所有活跃股票"""
        return self.conn.execute(
            "SELECT * FROM stocks WHERE status = 'active' ORDER BY code"
        ).fetchdf()
    
    def get_stock_info(self, code: str) -> Optional[Dict]:
        """获取单只股票信息"""
        result = self.conn.execute(
            "SELECT * FROM stocks WHERE code = ?", [code]
        ).fetchdf()
        
        if result.empty:
            return None
        return result.iloc[0].to_dict()
    
    # ============================================
    # 行情数据操作
    # ============================================
    
    def save_market_data_daily(self, df: pd.DataFrame):
        """
        保存日线数据

        Args:
            df: DataFrame包含trade_date, code, open, high, low, close, volume等列
        """
        if df.empty:
            return

        # 确保列名正确
        required_cols = ['trade_date', 'code', 'open', 'high', 'low', 'close', 'volume']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"缺少必要列: {missing_cols}")

        # 确保可选列存在，不存在则填充NULL
        optional_cols = ['amount', 'turnover_rate', 'pe_ratio', 'pb_ratio', 'market_cap']
        for col in optional_cols:
            if col not in df.columns:
                df[col] = None

        # 使用唯一的临时表名避免冲突
        import uuid
        temp_table = f"temp_data_{uuid.uuid4().hex[:8]}"
        
        try:
            self.conn.register(temp_table, df)

            self.conn.execute(f"""
                INSERT INTO market_data_daily
                SELECT trade_date, code, open, high, low, close, volume,
                       amount, turnover_rate, pe_ratio, pb_ratio, market_cap,
                       now()
                FROM {temp_table}
                ON CONFLICT (trade_date, code) DO UPDATE SET
                    open = EXCLUDED.open,
                    high = EXCLUDED.high,
                    low = EXCLUDED.low,
                    close = EXCLUDED.close,
                    volume = EXCLUDED.volume,
                    amount = EXCLUDED.amount,
                    turnover_rate = EXCLUDED.turnover_rate,
                    pe_ratio = EXCLUDED.pe_ratio,
                    pb_ratio = EXCLUDED.pb_ratio,
                    market_cap = EXCLUDED.market_cap,
                    created_at = now()
            """)
        finally:
            try:
                self.conn.unregister(temp_table)
            except:
                pass
        
        logger.info(f"保存日线数据: {len(df)} 条")
        
    def get_market_data_daily(self, 
                              code: str,
                              start_date: date,
                              end_date: date) -> pd.DataFrame:
        """
        获取日线数据
        
        Args:
            code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame
        """
        return self.conn.execute("""
            SELECT * FROM market_data_daily
            WHERE code = ?
              AND trade_date BETWEEN ? AND ?
            ORDER BY trade_date
        """, [code, start_date, end_date]).fetchdf()
    
    def get_market_data_daily_multi(self,
                                     codes: List[str],
                                     start_date: date,
                                     end_date: date) -> pd.DataFrame:
        """
        获取多只股票日线数据
        
        Args:
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame
        """
        placeholders = ','.join([f"'{c}'" for c in codes])
        return self.conn.execute(f"""
            SELECT * FROM market_data_daily
            WHERE code IN ({placeholders})
              AND trade_date BETWEEN ? AND ?
            ORDER BY trade_date, code
        """, [start_date, end_date]).fetchdf()
    
    def get_latest_trade_date(self) -> Optional[date]:
        """获取最新交易日期"""
        result = self.conn.execute(
            "SELECT MAX(trade_date) as max_date FROM market_data_daily"
        ).fetchdf()
        
        if result.empty or pd.isna(result.iloc[0]['max_date']):
            return None
        return result.iloc[0]['max_date']
    
    def save_realtime_quotes(self, df: pd.DataFrame):
        """保存实时行情快照"""
        if df.empty:
            return
            
        self.conn.register('temp_rt', df)
        
        self.conn.execute("""
            INSERT INTO market_data_realtime 
            SELECT code, trade_time, price, open, high, low, pre_close,
                   volume, amount, bid1_price, bid1_volume, ask1_price, ask1_volume,
                   CURRENT_TIMESTAMP
            FROM temp_rt
            ON CONFLICT (code) DO UPDATE SET
                trade_time = EXCLUDED.trade_time,
                price = EXCLUDED.price,
                open = EXCLUDED.open,
                high = EXCLUDED.high,
                low = EXCLUDED.low,
                pre_close = EXCLUDED.pre_close,
                volume = EXCLUDED.volume,
                amount = EXCLUDED.amount,
                bid1_price = EXCLUDED.bid1_price,
                bid1_volume = EXCLUDED.bid1_volume,
                ask1_price = EXCLUDED.ask1_price,
                ask1_volume = EXCLUDED.ask1_volume,
                updated_at = CURRENT_TIMESTAMP
        """)
        
        self.conn.unregister('temp_rt')
        
    def get_realtime_quotes(self, codes: Optional[List[str]] = None) -> pd.DataFrame:
        """获取实时行情"""
        if codes:
            placeholders = ','.join([f"'{c}'" for c in codes])
            return self.conn.execute(f"""
                SELECT * FROM market_data_realtime
                WHERE code IN ({placeholders})
            """).fetchdf()
        else:
            return self.conn.execute(
                "SELECT * FROM market_data_realtime"
            ).fetchdf()
    
    # ============================================
    # 新闻数据操作
    # ============================================
    
    def save_news(self, news_list: List[Dict]):
        """保存新闻"""
        if not news_list:
            return
            
        df = pd.DataFrame(news_list)
        self.conn.register('temp_news', df)
        
        self.conn.execute("""
            INSERT INTO news (code, title, content, source, publish_time, 
                            sentiment_score, importance, tags, is_processed)
            SELECT code, title, content, source, publish_time,
                   sentiment_score, importance, tags, is_processed
            FROM temp_news
        """)
        
        self.conn.unregister('temp_news')
        logger.info(f"保存新闻: {len(news_list)} 条")
        
    def get_unprocessed_news(self, limit: int = 100) -> pd.DataFrame:
        """获取未处理的新闻"""
        return self.conn.execute("""
            SELECT * FROM news 
            WHERE is_processed = FALSE
            ORDER BY publish_time DESC
            LIMIT ?
        """, [limit]).fetchdf()
    
    def mark_news_processed(self, news_ids: List[int]):
        """标记新闻已处理"""
        if not news_ids:
            return
            
        placeholders = ','.join([str(i) for i in news_ids])
        self.conn.execute(f"""
            UPDATE news SET is_processed = TRUE WHERE id IN ({placeholders})
        """)
    
    def get_news_by_code(self, code: str, days: int = 30) -> pd.DataFrame:
        """获取某只股票近期新闻"""
        return self.conn.execute("""
            SELECT * FROM news 
            WHERE code = ? 
              AND publish_time >= CURRENT_DATE - INTERVAL '? days'
            ORDER BY publish_time DESC
        """, [code, days]).fetchdf()
    
    # ============================================
    # 因子数据操作
    # ============================================
    
    def save_factor_values(self, df: pd.DataFrame):
        """保存因子值"""
        if df.empty:
            return
            
        self.conn.register('temp_factors', df)
        
        self.conn.execute("""
            INSERT INTO factor_values
            SELECT calc_date, code, factor_code, value, rank_value, percentile, zscore,
                   CURRENT_TIMESTAMP
            FROM temp_factors
            ON CONFLICT (calc_date, code, factor_code) DO UPDATE SET
                value = EXCLUDED.value,
                rank_value = EXCLUDED.rank_value,
                percentile = EXCLUDED.percentile,
                zscore = EXCLUDED.zscore,
                created_at = CURRENT_TIMESTAMP
        """)
        
        self.conn.unregister('temp_factors')
        logger.info(f"保存因子值: {len(df)} 条")
        
    def get_factor_values(self,
                          factor_codes: List[str],
                          calc_date: date,
                          codes: Optional[List[str]] = None) -> pd.DataFrame:
        """获取因子值"""
        placeholders = ','.join([f"'{f}'" for f in factor_codes])
        
        query = f"""
            SELECT * FROM factor_values
            WHERE factor_code IN ({placeholders})
              AND calc_date = ?
        """
        params = [calc_date]
        
        if codes:
            code_placeholders = ','.join([f"'{c}'" for c in codes])
            query += f" AND code IN ({code_placeholders})"
            
        return self.conn.execute(query, params).fetchdf()
    
    def get_factor_values_range(self,
                                 factor_code: str,
                                 code: str,
                                 start_date: date,
                                 end_date: date) -> pd.DataFrame:
        """获取因子历史值"""
        return self.conn.execute("""
            SELECT * FROM factor_values
            WHERE factor_code = ?
              AND code = ?
              AND calc_date BETWEEN ? AND ?
            ORDER BY calc_date
        """, [factor_code, code, start_date, end_date]).fetchdf()
    
    def save_factor_definition(self, factor: Dict):
        """保存因子定义"""
        import json
        self.conn.execute("""
            INSERT INTO factor_definitions 
            (factor_code, factor_name, category, description, formula, parameters, frequency)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (factor_code) DO UPDATE SET
                factor_name = EXCLUDED.factor_name,
                category = EXCLUDED.category,
                description = EXCLUDED.description,
                formula = EXCLUDED.formula,
                parameters = EXCLUDED.parameters,
                frequency = EXCLUDED.frequency
        """, [
            factor['code'],
            factor['name'],
            factor['category'],
            factor.get('description', ''),
            factor.get('formula', ''),
            json.dumps(factor.get('parameters', {})),
            factor.get('frequency', 'daily')
        ])
    
    def get_factor_definitions(self, category: Optional[str] = None) -> pd.DataFrame:
        """获取因子定义"""
        if category:
            return self.conn.execute(
                "SELECT * FROM factor_definitions WHERE category = ? AND is_active = TRUE",
                [category]
            ).fetchdf()
        else:
            return self.conn.execute(
                "SELECT * FROM factor_definitions WHERE is_active = TRUE"
            ).fetchdf()
    
    # ============================================
    # 策略信号操作
    # ============================================
    
    def save_strategy_signal(self, signal: Dict):
        """保存策略信号"""
        self.conn.execute("""
            INSERT INTO strategy_signals 
            (strategy_code, signal_time, code, signal_type, strength, price, volume, reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            signal['strategy_code'],
            signal.get('signal_time', datetime.now()),
            signal['code'],
            signal['signal_type'],
            signal.get('strength', 0.5),
            signal.get('price'),
            signal.get('volume'),
            signal.get('reason', '')
        ])
        
    def get_unexecuted_signals(self, strategy_code: Optional[str] = None) -> pd.DataFrame:
        """获取未执行信号"""
        query = "SELECT * FROM strategy_signals WHERE executed = FALSE"
        params = []
        
        if strategy_code:
            query += " AND strategy_code = ?"
            params.append(strategy_code)
            
        query += " ORDER BY signal_time"
        
        return self.conn.execute(query, params).fetchdf()
    
    def mark_signal_executed(self, signal_id: int):
        """标记信号已执行"""
        self.conn.execute(
            "UPDATE strategy_signals SET executed = TRUE WHERE id = ?",
            [signal_id]
        )
    
    # ============================================
    # 回测数据操作
    # ============================================
    
    def create_backtest_task(self, config: Dict) -> str:
        """创建回测任务"""
        import uuid
        task_id = str(uuid.uuid4())[:8]
        
        self.conn.execute("""
            INSERT INTO backtest_tasks 
            (task_id, task_name, strategy_code, start_date, end_date, initial_capital, status)
            VALUES (?, ?, ?, ?, ?, ?, 'pending')
        """, [
            task_id,
            config.get('task_name', f'回测_{datetime.now().strftime("%Y%m%d_%H%M%S")}'),
            config['strategy_code'],
            config['start_date'],
            config['end_date'],
            config.get('initial_capital', 1000000)
        ])
        
        return task_id
    
    def update_backtest_progress(self, task_id: str, progress: float):
        """更新回测进度"""
        self.conn.execute("""
            UPDATE backtest_tasks 
            SET progress = ?, status = 'running'
            WHERE task_id = ?
        """, [progress, task_id])
        
    def complete_backtest_task(self, task_id: str, results: Dict):
        """完成回测任务"""
        self.conn.execute("""
            UPDATE backtest_tasks 
            SET status = 'completed',
                progress = 100,
                total_return = ?,
                annual_return = ?,
                sharpe_ratio = ?,
                max_drawdown = ?,
                win_rate = ?,
                completed_at = CURRENT_TIMESTAMP
            WHERE task_id = ?
        """, [
            results.get('total_return'),
            results.get('annual_return'),
            results.get('sharpe_ratio'),
            results.get('max_drawdown'),
            results.get('win_rate'),
            task_id
        ])
        
    def save_backtest_trade(self, task_id: str, trade: Dict):
        """保存回测交易记录"""
        self.conn.execute("""
            INSERT INTO backtest_trades 
            (task_id, trade_date, code, trade_type, price, volume, amount, commission, reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            task_id,
            trade['date'],
            trade['code'],
            trade['trade_type'],
            trade['price'],
            trade['volume'],
            trade['amount'],
            trade['commission'],
            trade.get('reason', '')
        ])
        
    def save_backtest_nav(self, task_id: str, nav_data: Dict):
        """保存回测净值"""
        self.conn.execute("""
            INSERT INTO backtest_nav 
            (task_id, trade_date, nav, total_value, cash, market_value, daily_return, drawdown)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            task_id,
            nav_data['date'],
            nav_data['nav'],
            nav_data['total_value'],
            nav_data['cash'],
            nav_data['market_value'],
            nav_data['daily_return'],
            nav_data['drawdown']
        ])
        
    def get_backtest_results(self, task_id: str) -> Dict:
        """获取回测结果"""
        # 任务信息
        task = self.conn.execute(
            "SELECT * FROM backtest_tasks WHERE task_id = ?",
            [task_id]
        ).fetchdf()
        
        # 交易记录
        trades = self.conn.execute(
            "SELECT * FROM backtest_trades WHERE task_id = ? ORDER BY trade_date",
            [task_id]
        ).fetchdf()
        
        # 净值曲线
        nav = self.conn.execute(
            "SELECT * FROM backtest_nav WHERE task_id = ? ORDER BY trade_date",
            [task_id]
        ).fetchdf()
        
        return {
            'task': task,
            'trades': trades,
            'nav': nav
        }
    
    def get_backtest_tasks(self, status: Optional[str] = None) -> pd.DataFrame:
        """获取回测任务列表"""
        if status:
            return self.conn.execute(
                "SELECT * FROM backtest_tasks WHERE status = ? ORDER BY created_at DESC",
                [status]
            ).fetchdf()
        else:
            return self.conn.execute(
                "SELECT * FROM backtest_tasks ORDER BY created_at DESC"
            ).fetchdf()
    
    # ============================================
    # 股票评分操作
    # ============================================
    
    def save_stock_scores(self, df: pd.DataFrame):
        """保存股票评分"""
        if df.empty:
            return
            
        self.conn.register('temp_scores', df)
        
        self.conn.execute("""
            INSERT INTO stock_scores
            SELECT calc_date, code, fundamental_score, technical_score, sentiment_score,
                   capital_flow_score, total_score, rank_in_market, tags, summary,
                   CURRENT_TIMESTAMP
            FROM temp_scores
            ON CONFLICT (calc_date, code) DO UPDATE SET
                fundamental_score = EXCLUDED.fundamental_score,
                technical_score = EXCLUDED.technical_score,
                sentiment_score = EXCLUDED.sentiment_score,
                capital_flow_score = EXCLUDED.capital_flow_score,
                total_score = EXCLUDED.total_score,
                rank_in_market = EXCLUDED.rank_in_market,
                tags = EXCLUDED.tags,
                summary = EXCLUDED.summary,
                created_at = CURRENT_TIMESTAMP
        """)
        
        self.conn.unregister('temp_scores')
        logger.info(f"保存股票评分: {len(df)} 条")
        
    def get_stock_scores(self, calc_date: date, min_score: Optional[float] = None) -> pd.DataFrame:
        """获取股票评分"""
        if min_score:
            return self.conn.execute("""
                SELECT * FROM stock_scores
                WHERE calc_date = ? AND total_score >= ?
                ORDER BY total_score DESC
            """, [calc_date, min_score]).fetchdf()
        else:
            return self.conn.execute("""
                SELECT * FROM stock_scores
                WHERE calc_date = ?
                ORDER BY total_score DESC
            """, [calc_date]).fetchdf()
    
    # ============================================
    # 系统配置操作
    # ============================================
    
    def set_config(self, key: str, value: str, description: str = ""):
        """设置配置"""
        self.conn.execute("""
            INSERT INTO system_config (config_key, config_value, description)
            VALUES (?, ?, ?)
            ON CONFLICT (config_key) DO UPDATE SET
                config_value = EXCLUDED.config_value,
                description = EXCLUDED.description,
                updated_at = CURRENT_TIMESTAMP
        """, [key, value, description])
        
    def get_config(self, key: str, default: str = "") -> str:
        """获取配置"""
        result = self.conn.execute(
            "SELECT config_value FROM system_config WHERE config_key = ?",
            [key]
        ).fetchdf()
        
        if result.empty:
            return default
        return result.iloc[0]['config_value']
    
    # ============================================
    # 数据更新日志
    # ============================================
    
    def log_data_update(self, data_type: str, records_count: int, 
                        status: str, message: str = "", duration_ms: int = 0):
        """记录数据更新日志"""
        self.conn.execute("""
            INSERT INTO data_update_log 
            (data_type, update_date, records_count, status, message, duration_ms)
            VALUES (?, CURRENT_DATE, ?, ?, ?, ?)
        """, [data_type, records_count, status, message, duration_ms])
    
    def get_update_logs(self, days: int = 7) -> pd.DataFrame:
        """获取最近更新日志"""
        return self.conn.execute("""
            SELECT * FROM data_update_log
            WHERE update_date >= CURRENT_DATE - INTERVAL '? days'
            ORDER BY created_at DESC
        """, [days]).fetchdf()
    
    # ============================================
    # 实用工具方法
    # ============================================
    
    def execute_query(self, query: str, params: Optional[List] = None) -> pd.DataFrame:
        """执行自定义查询"""
        if params:
            return self.conn.execute(query, params).fetchdf()
        return self.conn.execute(query).fetchdf()
    
    def get_table_info(self, table_name: str) -> pd.DataFrame:
        """获取表信息"""
        return self.conn.execute(f"DESCRIBE {table_name}").fetchdf()
    
    def get_all_tables(self) -> List[str]:
        """获取所有表名"""
        result = self.conn.execute("SHOW TABLES").fetchdf()
        return result['name'].tolist()
    
    def get_table_count(self, table_name: str) -> int:
        """获取表记录数"""
        result = self.conn.execute(f"SELECT COUNT(*) as cnt FROM {table_name}").fetchdf()
        return result.iloc[0]['cnt']
    
    def backup(self, backup_path: Optional[str] = None):
        """备份数据库"""
        if not backup_path:
            backup_path = f"{self.db_path}.{datetime.now().strftime('%Y%m%d_%H%M%S')}.backup"
        
        # 使用 EXPORT DATABASE 备份
        self.conn.execute(f"EXPORT DATABASE '{backup_path}' (FORMAT PARQUET)")
        logger.info(f"数据库已备份到: {backup_path}")
        
    def vacuum(self):
        """压缩数据库"""
        self.conn.execute("CHECKPOINT")
        self.conn.execute("VACUUM")
        logger.info("数据库已压缩")
        
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
