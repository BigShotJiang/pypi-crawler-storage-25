"""
DuckDB HTTP API 客户端

通过HTTP API访问DuckDB数据库
"""
import os
import sys
import requests
import pandas as pd
from datetime import date
from typing import Optional, List, Union
import logging

logger = logging.getLogger(__name__)

DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 9529
DEFAULT_TIMEOUT = 120


class DBHttpClient:
    """DuckDB HTTP客户端"""
    
    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT,
                 timeout: int = DEFAULT_TIMEOUT):
        self.base_url = f"http://{host}:{port}"
        self.timeout = timeout
        self.session = requests.Session()
    
    def _request(self, method: str, endpoint: str, **kwargs) -> dict:
        """发送HTTP请求"""
        url = f"{self.base_url}{endpoint}"
        kwargs['timeout'] = self.timeout
        
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.ConnectionError:
            raise ConnectionError(f"无法连接到数据库API服务器: {self.base_url}")
        except requests.exceptions.Timeout:
            raise TimeoutError(f"请求超时")
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"请求失败: {e}")
    
    def ping(self) -> bool:
        """测试连接"""
        try:
            result = self._request('GET', '/ping')
            return result.get('success', False)
        except:
            return False
    
    # ==================== 股票列表操作 ====================
    
    def get_all_stocks(self) -> pd.DataFrame:
        """获取所有股票列表"""
        result = self._request('GET', '/stocks')
        if result.get('success'):
            return pd.DataFrame(result.get('data', []))
        return pd.DataFrame()
    
    def save_stocks(self, df: pd.DataFrame):
        """保存股票列表"""
        # 转换日期格式为字符串
        df = df.copy()
        for col in df.columns:
            if df[col].dtype == 'object':
                # 检查是否是日期类型
                try:
                    if len(df) > 0 and isinstance(df[col].iloc[0], date):
                        df[col] = df[col].apply(lambda x: x.isoformat() if x else None)
                except:
                    pass
        
        data = df.to_dict('records')
        result = self._request('POST', '/stocks', json=data)
        if not result.get('success'):
            raise RuntimeError(result.get('error', '保存失败'))
    
    # ==================== 日线数据操作 ====================
    
    def get_market_data_daily(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """获取单只股票日线数据"""
        params = {
            'code': code,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat()
        }
        result = self._request('GET', '/market_data/daily', params=params)
        if result.get('success'):
            df = pd.DataFrame(result.get('data', []))
            if 'trade_date' in df.columns:
                df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
            return df
        return pd.DataFrame()
    
    def get_market_data_daily_multi(self, codes: List[str], start_date: date, end_date: date) -> pd.DataFrame:
        """获取多只股票日线数据"""
        params = {
            'codes': codes,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat()
        }
        result = self._request('GET', '/market_data/daily', params=params)
        if result.get('success'):
            df = pd.DataFrame(result.get('data', []))
            if 'trade_date' in df.columns:
                df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
            return df
        return pd.DataFrame()
    
    def save_market_data_daily(self, df: pd.DataFrame):
        """保存日线数据"""
        if df.empty:
            return
        
        # 分批保存，每批500条
        batch_size = 500
        total = len(df)
        
        for i in range(0, total, batch_size):
            batch = df.iloc[i:i+batch_size].copy()
            
            # 处理NaN和Inf值，使其可JSON序列化
            for col in batch.columns:
                if batch[col].dtype in ['float64', 'float32']:
                    # 将NaN替换为None，Inf替换为None
                    batch[col] = batch[col].replace([float('inf'), float('-inf')], None)
                    batch[col] = batch[col].where(batch[col].notna(), None)
            
            data = batch.to_dict('records')
            
            # 转换日期格式
            for item in data:
                if 'trade_date' in item and isinstance(item['trade_date'], date):
                    item['trade_date'] = item['trade_date'].isoformat()
                # 确保所有float都是JSON兼容的
                for key, value in item.items():
                    if isinstance(value, float):
                        if value != value or value == float('inf') or value == float('-inf'):  # NaN check
                            item[key] = None
            
            result = self._request('POST', '/market_data/daily', json=data)
            if not result.get('success'):
                raise RuntimeError(result.get('error', '保存失败'))
            
            logger.debug(f"已保存批次: {min(i+batch_size, total)}/{total}")
    
    def get_latest_trade_date(self) -> Optional[date]:
        """获取最新交易日期"""
        result = self._request('GET', '/market_data/latest_date')
        if result.get('success'):
            date_str = result.get('data')
            if date_str:
                # 处理带时间的格式
                if 'T' in date_str:
                    from datetime import datetime
                    return datetime.fromisoformat(date_str).date()
                return date.fromisoformat(date_str)
        return None
    
    # ==================== 因子数据操作 ====================
    
    def get_factor_names(self) -> List[str]:
        """获取所有因子名称"""
        result = self._request('GET', '/factors')
        if result.get('success'):
            return result.get('data', [])
        return []
    
    def get_factor_data(self, factor_name: str, trade_date: date) -> pd.DataFrame:
        """获取某一天的因子数据"""
        params = {'date': trade_date.isoformat()}
        result = self._request('GET', f'/factors/{factor_name}', params=params)
        if result.get('success'):
            df = pd.DataFrame(result.get('data', []))
            if 'trade_date' in df.columns:
                df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
            return df
        return pd.DataFrame()
    
    def get_factor_data_multi(self, factor_name: str, start_date: date, end_date: date) -> pd.DataFrame:
        """获取因子时间序列数据"""
        params = {
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat()
        }
        result = self._request('GET', f'/factors/{factor_name}', params=params)
        if result.get('success'):
            df = pd.DataFrame(result.get('data', []))
            if 'trade_date' in df.columns:
                df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
            return df
        return pd.DataFrame()
    
    def save_factor_data(self, df: pd.DataFrame, factor_name: str = None):
        """保存因子数据"""
        if df.empty:
            return
        
        data = df.to_dict('records')
        
        # 转换日期格式
        for item in data:
            if 'trade_date' in item and isinstance(item['trade_date'], date):
                item['trade_date'] = item['trade_date'].isoformat()
        
        endpoint = f'/factors/{factor_name}' if factor_name else '/factors/data'
        result = self._request('POST', endpoint, json=data)
        if not result.get('success'):
            raise RuntimeError(result.get('error', '保存失败'))


    def update_daily(self, codes: List[str] = None, start_date: date = None, end_date: date = None) -> dict:
        """
        更新日线数据
        
        Args:
            codes: 股票代码列表，默认None表示更新所有股票
            start_date: 开始日期，默认None表示今天
            end_date: 结束日期，默认None表示今天（目前只支持单日更新）
            
        Returns:
            dict: 包含更新结果的字典
            {
                'success': bool,
                'saved_count': int,
                'message': str
            }
        """
        import subprocess
        import sys
        import os
        import json
        
        # 设置默认日期
        if start_date is None:
            start_date = date.today()
        if end_date is None:
            end_date = start_date
        
        # 目前只支持单日更新
        target_date = start_date
        date_str = target_date.strftime('%Y%m%d')
        
        # 构建命令
        script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'update_daily_http.py')
        
        if codes:
            logger.info(f"开始更新日线数据: {len(codes)} 只股票, 日期: {date_str}")
        else:
            logger.info(f"开始更新日线数据: 全部股票, 日期: {date_str}")
        
        try:
            # 构建命令参数
            cmd = [sys.executable, script_path, date_str]
            
            # 如果指定了codes，通过环境变量传递
            env = os.environ.copy()
            if codes:
                env['UPDATE_CODES'] = json.dumps(codes)
            
            # 调用更新脚本
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=3600,  # 1小时超时
                env=env
            )
            
            if result.returncode == 0:
                # 解析输出获取成功数量
                output = result.stdout
                
                # 尝试从输出中解析成功数量
                saved_count = len(codes) if codes else 0  # 简化处理
                
                return {
                    'success': True,
                    'saved_count': saved_count,
                    'message': f'成功更新 {len(codes) if codes else "全部"} 只股票的数据'
                }
            else:
                error_msg = result.stderr or "未知错误"
                logger.error(f"更新失败: {error_msg}")
                return {
                    'success': False,
                    'saved_count': 0,
                    'message': f'更新失败: {error_msg}'
                }
                
        except subprocess.TimeoutExpired:
            logger.error("更新超时")
            return {
                'success': False,
                'saved_count': 0,
                'message': '更新超时，请检查QMT连接'
            }
        except Exception as e:
            logger.error(f"更新异常: {e}")
            return {
                'success': False,
                'saved_count': 0,
                'message': f'更新异常: {str(e)}'
            }


# 兼容旧版客户端接口
class DBClient(DBHttpClient):
    """兼容旧版接口"""
    pass
