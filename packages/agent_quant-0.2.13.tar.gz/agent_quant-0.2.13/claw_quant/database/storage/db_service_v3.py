"""
DuckDB 数据库服务 V3 - 使用队列实现真正的串行化访问

核心设计：
1. 单线程处理所有数据库操作（避免DuckDB并发问题）
2. 使用队列接收请求
3. 每个请求有独立的响应队列
4. 大数据分批处理
"""
import socket
import struct
import pickle
import threading
import logging
import signal
import sys
import os
import time
import queue
from typing import Optional, Any, Tuple
from datetime import date
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.db_manager import DuckDBManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger('db_service_v3')

# 默认配置
DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 9528
HEADER_SIZE = 4
MAX_MSG_SIZE = 256 * 1024 * 1024  # 256MB


def send_message(sock: socket.socket, data: Any):
    """发送消息"""
    payload = pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL)
    msg_len = len(payload)
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes")
    header = struct.pack('>I', msg_len)
    sock.sendall(header + payload)


def recv_message(sock: socket.socket) -> Optional[Any]:
    """接收消息"""
    header = _recv_exact(sock, HEADER_SIZE)
    if header is None:
        return None
    msg_len = struct.unpack('>I', header)[0]
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes")
    payload = _recv_exact(sock, msg_len)
    if payload is None:
        return None
    return pickle.loads(payload)


def _recv_exact(sock: socket.socket, n: int) -> Optional[bytes]:
    """精确读取n字节"""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 65536))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


class Request:
    """请求对象"""
    def __init__(self, method: str, args: tuple, kwargs: dict):
        self.method = method
        self.args = args
        self.kwargs = kwargs
        self.response_queue = queue.Queue(maxsize=1)


class DBService:
    """数据库服务 V3 - 队列版"""

    def __init__(self, db_path: str, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
        self.db_path = db_path
        self.host = host
        self.port = port
        self.db: Optional[DuckDBManager] = None
        self.server_socket: Optional[socket.socket] = None
        self._running = False
        self._request_queue: queue.Queue[Request] = queue.Queue()
        self._db_thread: Optional[threading.Thread] = None

    def start(self):
        """启动服务"""
        logger.info("=" * 60)
        logger.info("数据库服务 V3 启动中...")
        logger.info("=" * 60)

        # 启动数据库工作线程
        self._db_thread = threading.Thread(target=self._db_worker, daemon=True)
        self._db_thread.start()
        logger.info("数据库工作线程已启动")

        # 启动TCP服务
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(32)
        self.server_socket.settimeout(1.0)
        self._running = True

        logger.info(f"数据库服务已启动: {self.host}:{self.port}")
        logger.info("=" * 60)

        # 主循环 - 只负责接收连接
        while self._running:
            try:
                client_sock, addr = self.server_socket.accept()
                t = threading.Thread(
                    target=self._handle_client,
                    args=(client_sock, addr),
                    daemon=True
                )
                t.start()
            except socket.timeout:
                continue
            except OSError:
                if self._running:
                    logger.error("accept错误", exc_info=True)
                break

    def stop(self):
        """停止服务"""
        logger.info("正在停止服务...")
        self._running = False
        if self.server_socket:
            self.server_socket.close()
        # 发送停止信号到工作线程
        stop_req = Request('__stop__', (), {})
        self._request_queue.put(stop_req)
        if self._db_thread:
            self._db_thread.join(timeout=5)
        logger.info("服务已停止")

    def _db_worker(self):
        """数据库工作线程 - 单线程串行处理所有数据库操作"""
        logger.info("数据库工作线程: 初始化数据库连接...")
        
        try:
            self.db = DuckDBManager(self.db_path)
            logger.info("数据库工作线程: 数据库连接成功")
        except Exception as e:
            logger.error(f"数据库工作线程: 连接失败: {e}")
            return

        while True:
            try:
                req = self._request_queue.get(timeout=1)
            except queue.Empty:
                continue

            if req.method == '__stop__':
                logger.info("数据库工作线程: 收到停止信号")
                break

            try:
                result = self._execute_db_operation(req.method, req.args, req.kwargs)
                req.response_queue.put({'ok': True, 'result': result})
            except Exception as e:
                logger.error(f"执行 {req.method} 失败: {e}")
                req.response_queue.put({'ok': False, 'error': str(e)})

        # 关闭数据库
        if self.db:
            self.db.close()
            logger.info("数据库工作线程: 数据库连接已关闭")

    def _execute_db_operation(self, method: str, args: tuple, kwargs: dict) -> Any:
        """执行数据库操作"""
        if method == '__ping__':
            return 'pong'

        if not hasattr(self.db, method):
            raise AttributeError(f"方法不存在: {method}")

        if method.startswith('_'):
            raise PermissionError(f"不允许调用私有方法: {method}")

        # 特殊处理：大数据保存分批
        if method == 'save_market_data_daily' and args:
            df = args[0]
            if len(df) > 500:
                return self._save_large_data(df)

        method_obj = getattr(self.db, method)
        return method_obj(*args, **kwargs)

    def _save_large_data(self, df: pd.DataFrame) -> None:
        """分批保存大数据"""
        batch_size = 500
        total = len(df)
        saved = 0

        for i in range(0, total, batch_size):
            batch = df.iloc[i:i+batch_size]
            self.db.save_market_data_daily(batch)
            saved += len(batch)
            logger.debug(f"分批保存: {saved}/{total}")

        logger.info(f"大数据分批保存完成: {total} 条")

    def _handle_client(self, client_sock: socket.socket, addr):
        """处理客户端连接"""
        logger.debug(f"客户端连接: {addr}")
        try:
            while self._running:
                request_data = recv_message(client_sock)
                if request_data is None:
                    break

                method_name, args, kwargs = request_data
                
                # 创建请求对象
                req = Request(method_name, args, kwargs)
                
                # 放入队列等待处理
                self._request_queue.put(req)
                
                # 等待响应（带超时）
                try:
                    response = req.response_queue.get(timeout=60)
                    send_message(client_sock, response)
                except queue.Empty:
                    logger.warning(f"请求 {method_name} 超时")
                    send_message(client_sock, {'ok': False, 'error': '请求超时'})

        except Exception as e:
            logger.warning(f"客户端 {addr} 处理异常: {e}")
        finally:
            client_sock.close()
            logger.debug(f"客户端断开: {addr}")


def main():
    import argparse
    parser = argparse.ArgumentParser(description='DuckDB 数据库服务 V3')
    parser.add_argument('--db-path', type=str, default='data/quant_system_new.db')
    parser.add_argument('--host', type=str, default=DEFAULT_HOST)
    parser.add_argument('--port', type=int, default=DEFAULT_PORT)
    args = parser.parse_args()

    service = DBService(args.db_path, args.host, args.port)

    def on_signal(signum, frame):
        service.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)

    service.start()


if __name__ == '__main__':
    main()
