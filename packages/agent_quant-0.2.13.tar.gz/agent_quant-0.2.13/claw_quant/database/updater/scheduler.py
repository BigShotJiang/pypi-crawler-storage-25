"""
数据更新调度器
"""
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.events import EVENT_JOB_EXECUTED, EVENT_JOB_ERROR
from typing import Callable, Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class UpdateTask:
    """更新任务定义"""
    name: str
    task_type: str          # 'interval' | 'cron' | 'date'
    trigger: str            # 触发器配置
    handler: Callable       # 处理函数
    priority: int = 5       # 优先级 1-10
    timeout: int = 300      # 超时时间(秒)
    retry_count: int = 3    # 重试次数
    enabled: bool = True    # 是否启用


class DataUpdateScheduler:
    """数据更新调度器"""
    
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.tasks: Dict[str, UpdateTask] = {}
        self.job_stats: Dict[str, Dict] = {}
        
        # 添加事件监听
        self.scheduler.add_listener(
            self._on_job_executed,
            EVENT_JOB_EXECUTED | EVENT_JOB_ERROR
        )
        
    def register_task(self, task: UpdateTask):
        """注册更新任务"""
        if not task.enabled:
            logger.info(f"任务 {task.name} 已禁用，跳过注册")
            return
            
        self.tasks[task.name] = task
        
        try:
            if task.task_type == 'interval':
                # 间隔触发: "5m", "1h", "1d"
                seconds = self._parse_interval(task.trigger)
                self.scheduler.add_job(
                    task.handler,
                    IntervalTrigger(seconds=seconds),
                    id=task.name,
                    replace_existing=True,
                    max_instances=1,
                    misfire_grace_time=60
                )
                
            elif task.task_type == 'cron':
                # Cron触发: "0 9 * * 1-5" (工作日9点)
                self.scheduler.add_job(
                    task.handler,
                    CronTrigger.from_crontab(task.trigger),
                    id=task.name,
                    replace_existing=True,
                    max_instances=1,
                    misfire_grace_time=300
                )
                
            elif task.task_type == 'date':
                # 一次性任务
                run_date = datetime.strptime(task.trigger, '%Y-%m-%d %H:%M:%S')
                self.scheduler.add_job(
                    task.handler,
                    'date',
                    run_date=run_date,
                    id=task.name,
                    replace_existing=True
                )
                
            logger.info(f"注册任务: {task.name} ({task.task_type}: {task.trigger})")
            
        except Exception as e:
            logger.error(f"注册任务失败 {task.name}: {e}")
            
    def _on_job_executed(self, event):
        """任务执行回调"""
        job_id = event.job_id
        
        if event.exception:
            logger.error(f"任务执行失败 {job_id}: {event.exception}")
            self.job_stats[job_id] = {
                'last_status': 'failed',
                'last_error': str(event.exception),
                'last_run': datetime.now()
            }
        else:
            logger.debug(f"任务执行成功 {job_id}")
            self.job_stats[job_id] = {
                'last_status': 'success',
                'last_run': datetime.now()
            }
            
    def start(self):
        """启动调度器"""
        self.scheduler.start()
        logger.info("数据更新调度器已启动")
        
        # 打印所有任务
        jobs = self.scheduler.get_jobs()
        logger.info(f"当前任务数: {len(jobs)}")
        for job in jobs:
            logger.info(f"  - {job.id}: {job.trigger}")
            
    def shutdown(self):
        """关闭调度器"""
        self.scheduler.shutdown()
        logger.info("数据更新调度器已关闭")
        
    def pause_task(self, task_name: str):
        """暂停任务"""
        self.scheduler.pause_job(task_name)
        logger.info(f"暂停任务: {task_name}")
        
    def resume_task(self, task_name: str):
        """恢复任务"""
        self.scheduler.resume_job(task_name)
        logger.info(f"恢复任务: {task_name}")
        
    def remove_task(self, task_name: str):
        """移除任务"""
        self.scheduler.remove_job(task_name)
        if task_name in self.tasks:
            del self.tasks[task_name]
        logger.info(f"移除任务: {task_name}")
        
    def run_task_now(self, task_name: str):
        """立即执行任务"""
        job = self.scheduler.get_job(task_name)
        if job:
            job.modify(next_run_time=datetime.now())
            logger.info(f"任务已触发立即执行: {task_name}")
        else:
            logger.warning(f"任务不存在: {task_name}")
            
    def get_task_status(self, task_name: str) -> Optional[Dict]:
        """获取任务状态"""
        job = self.scheduler.get_job(task_name)
        if not job:
            return None
            
        return {
            'name': task_name,
            'next_run': job.next_run_time,
            'trigger': str(job.trigger),
            'stats': self.job_stats.get(task_name, {})
        }
        
    def list_tasks(self) -> List[Dict]:
        """列出所有任务"""
        jobs = self.scheduler.get_jobs()
        result = []
        
        for job in jobs:
            result.append({
                'name': job.id,
                'next_run': job.next_run_time,
                'trigger': str(job.trigger),
                'stats': self.job_stats.get(job.id, {})
            })
            
        return result
        
    def _parse_interval(self, trigger: str) -> int:
        """解析间隔时间"""
        unit = trigger[-1].lower()
        value = int(trigger[:-1])
        
        if unit == 's':
            return value
        elif unit == 'm':
            return value * 60
        elif unit == 'h':
            return value * 60 * 60
        elif unit == 'd':
            return value * 60 * 60 * 24
        else:
            raise ValueError(f"未知时间单位: {unit}")


# ============================================
# 预定义任务配置
# ============================================

def create_default_scheduler(db_manager, qmt_path: Optional[str] = None) -> DataUpdateScheduler:
    """
    创建默认调度器配置
    
    Args:
        db_manager: 数据库管理器
        qmt_path: QMT路径
        
    Returns:
        配置好的调度器
    """
    from .market_updater import MarketDataUpdater
    
    scheduler = DataUpdateScheduler()
    updater = MarketDataUpdater(db_manager, qmt_path)
    
    # 1. 实时行情更新 (每5秒)
    scheduler.register_task(UpdateTask(
        name='realtime_quotes',
        task_type='interval',
        trigger='5s',
        handler=lambda: updater.update_realtime_quotes(),
        priority=10
    ))
    
    # 2. 日线数据更新 (收盘后 15:10)
    scheduler.register_task(UpdateTask(
        name='daily_kline',
        task_type='cron',
        trigger='10 15 * * 1-5',  # 工作日15:10
        handler=lambda: updater.update_daily_data(),
        priority=9
    ))
    
    # 3. 股票信息更新 (每周一早上)
    scheduler.register_task(UpdateTask(
        name='stock_info',
        task_type='cron',
        trigger='0 8 * * 1',  # 周一8:00
        handler=updater.update_stock_info,
        priority=5
    ))
    
    return scheduler
