"""
行情数据更新器 - 从QMT获取数据
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pandas as pd
from datetime import date, datetime, timedelta
from typing import List, Optional, Dict
import logging
import time

logger = logging.getLogger(__name__)


class MarketDataUpdater:
    """行情数据更新器"""
    
    def __init__(self, db_manager, qmt_path: Optional[str] = None):
        """
        初始化更新器
        
        Args:
            db_manager: 数据库管理器实例
            qmt_path: QMT安装路径，如果为None则尝试自动检测
        """
        self.db = db_manager
        self.qmt_path = qmt_path or self._detect_qmt_path()
        self.xtdata = None
        self._connect_qmt()
        
    def _detect_qmt_path(self) -> str:
        """自动检测QMT安装路径"""
        possible_paths = [
            r"C:\国金证券QMT交易端",
            r"C:\workspace\国金证券QMT交易端",
            r"C:\Program Files (x86)\国金证券QMT交易端",
            r"D:\国金证券QMT交易端",
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                logger.info(f"检测到QMT路径: {path}")
                return path
                
        raise FileNotFoundError("未找到QMT安装路径，请手动指定")
    
    def _connect_qmt(self):
        """连接QMT"""
        try:
            # 设置QMT路径环境变量
            os.environ['QMT_PATH'] = self.qmt_path
            
            # 导入xtquant
            from xtquant import xtdata
            self.xtdata = xtdata
            
            # 设置数据目录
            data_dir = os.path.join(self.qmt_path, 'userdata_mini', 'datadir')
            self.xtdata.data_dir = data_dir
            
            logger.info(f"已连接QMT，数据目录: {data_dir}")
            
        except ImportError as e:
            logger.error(f"导入xtquant失败: {e}")
            logger.error("请确保已安装xtquant: pip install xtquant")
            raise
        except Exception as e:
            logger.error(f"连接QMT失败: {e}")
            raise
    
    def get_stock_list(self, market: str = 'all') -> List[str]:
        """
        获取股票列表
        
        Args:
            market: 'all'/'SH'/'SZ'
            
        Returns:
            股票代码列表
        """
        try:
            if market == 'all':
                stocks = self.xtdata.get_stock_list_in_sector('沪深A股')
            elif market == 'SH':
                stocks = self.xtdata.get_stock_list_in_sector('上证A股')
            elif market == 'SZ':
                stocks = self.xtdata.get_stock_list_in_sector('深证A股')
            else:
                stocks = self.xtdata.get_stock_list_in_sector(market)
                
            return list(stocks)
        except Exception as e:
            logger.error(f"获取股票列表失败: {e}")
            return []
    
    def update_stock_info(self):
        """更新股票基础信息"""
        try:
            logger.info("开始更新股票基础信息...")
            
            # 获取所有股票
            all_stocks = self.get_stock_list('all')
            
            # 构建DataFrame
            stock_data = []
            for code in all_stocks:
                # 解析市场和代码
                if '.SH' in code:
                    market = 'SH'
                elif '.SZ' in code:
                    market = 'SZ'
                elif '.BJ' in code:
                    market = 'BJ'
                else:
                    market = 'Unknown'
                    
                stock_data.append({
                    'code': code,
                    'name': '',  # QMT不直接提供名称，需要另外获取
                    'market': market,
                    'industry': '',
                    'list_date': None,
                    'status': 'active'
                })
            
            df = pd.DataFrame(stock_data)
            self.db.save_stocks(df)
            
            logger.info(f"更新股票信息完成: {len(df)} 只")
            
        except Exception as e:
            logger.error(f"更新股票信息失败: {e}")
            raise
    
    def download_history_data(self, 
                              code: str, 
                              period: str = '1d',
                              start_date: Optional[date] = None,
                              end_date: Optional[date] = None) -> bool:
        """
        下载历史数据
        
        Args:
            code: 股票代码
            period: 周期 '1d'/'1m'/'5m'等
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            是否成功
        """
        try:
            if start_date is None:
                start_date = date.today() - timedelta(days=365)
            if end_date is None:
                end_date = date.today()
                
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')
            
            # 下载数据
            result = self.xtdata.download_history_data(
                code, 
                period=period,
                start_time=start_str,
                end_time=end_str
            )
            
            return result is not None
            
        except Exception as e:
            logger.error(f"下载历史数据失败 {code}: {e}")
            return False
    
    def get_market_data(self, 
                        code: str,
                        period: str = '1d',
                        start_date: Optional[date] = None,
                        end_date: Optional[date] = None) -> pd.DataFrame:
        """
        获取行情数据
        
        Args:
            code: 股票代码
            period: 周期
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame
        """
        try:
            if start_date is None:
                start_date = date.today() - timedelta(days=365)
            if end_date is None:
                end_date = date.today()
                
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')
            
            # 先下载数据
            self.download_history_data(code, period, start_date, end_date)
            
            # 获取数据
            data = self.xtdata.get_market_data_ex(
                field_list=['time', 'open', 'high', 'low', 'close', 'volume', 'amount'],
                stock_list=[code],
                period=period,
                start_time=start_str,
                end_time=end_str
            )
            
            if data and code in data:
                df = data[code]
                df['code'] = code
                return df
            else:
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"获取行情数据失败 {code}: {e}")
            return pd.DataFrame()
    
    def update_daily_data(self, 
                         codes: Optional[List[str]] = None,
                         start_date: Optional[date] = None,
                         end_date: Optional[date] = None,
                         batch_size: int = 100) -> Dict:
        """
        更新日线数据
        
        Args:
            codes: 股票代码列表，None则更新所有股票
            start_date: 开始日期
            end_date: 结束日期
            batch_size: 批处理大小
            
        Returns:
            更新统计
        """
        if codes is None:
            codes = self.get_stock_list('all')
            
        if start_date is None:
            # 从数据库获取最新日期
            latest_date = self.db.get_latest_trade_date()
            if latest_date:
                start_date = latest_date
            else:
                start_date = date.today() - timedelta(days=365)
                
        if end_date is None:
            end_date = date.today()
            
        logger.info(f"开始更新日线数据: {len(codes)} 只股票, {start_date} ~ {end_date}")
        
        stats = {
            'total': len(codes),
            'success': 0,
            'failed': 0,
            'records': 0
        }
        
        # 分批处理
        for i in range(0, len(codes), batch_size):
            batch = codes[i:i+batch_size]
            logger.info(f"处理批次 {i//batch_size + 1}/{(len(codes)-1)//batch_size + 1}: {len(batch)} 只")
            
            for code in batch:
                try:
                    # 下载并获取数据
                    df = self.get_market_data(code, '1d', start_date, end_date)
                    
                    if not df.empty:
                        # 转换列名
                        df = df.rename(columns={
                            'time': 'trade_date'
                        })
                        
                        # 转换日期格式
                        if 'trade_date' in df.columns:
                            df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
                        
                        # 保存到数据库
                        self.db.save_market_data_daily(df)
                        stats['records'] += len(df)
                        stats['success'] += 1
                    else:
                        stats['failed'] += 1
                        
                except Exception as e:
                    logger.error(f"更新失败 {code}: {e}")
                    stats['failed'] += 1
                    
            # 批次间休息，避免请求过快
            time.sleep(0.5)
            
        logger.info(f"日线数据更新完成: 成功 {stats['success']}, 失败 {stats['failed']}, 记录 {stats['records']}")
        
        # 记录更新日志
        self.db.log_data_update(
            'market_data_daily',
            stats['records'],
            'success' if stats['failed'] == 0 else 'partial',
            f"成功:{stats['success']}, 失败:{stats['failed']}"
        )
        
        return stats
    
    def update_realtime_quotes(self, codes: Optional[List[str]] = None) -> Dict:
        """
        更新实时行情
        
        Args:
            codes: 股票代码列表
            
        Returns:
            更新统计
        """
        try:
            if codes is None:
                # 获取关注的股票列表
                codes = self.get_stock_list('all')[:500]  # 限制数量
                
            logger.info(f"更新实时行情: {len(codes)} 只股票")
            
            # 获取全市场快照
            quotes = self.xtdata.get_full_tick()
            
            # 筛选需要的股票
            data = []
            for code in codes:
                if code in quotes:
                    quote = quotes[code]
                    data.append({
                        'code': code,
                        'trade_time': datetime.now(),
                        'price': quote.get('lastPrice', 0),
                        'open': quote.get('open', 0),
                        'high': quote.get('high', 0),
                        'low': quote.get('low', 0),
                        'pre_close': quote.get('lastClose', 0),
                        'volume': quote.get('volume', 0),
                        'amount': quote.get('amount', 0),
                        'bid1_price': quote.get('bid1', 0),
                        'bid1_volume': quote.get('bid1_vol', 0),
                        'ask1_price': quote.get('ask1', 0),
                        'ask1_volume': quote.get('ask1_vol', 0),
                    })
            
            if data:
                df = pd.DataFrame(data)
                self.db.save_realtime_quotes(df)
                
            logger.info(f"实时行情更新完成: {len(data)} 只")
            
            return {'success': len(data), 'failed': len(codes) - len(data)}
            
        except Exception as e:
            logger.error(f"更新实时行情失败: {e}")
            return {'success': 0, 'failed': 0, 'error': str(e)}
    
    def get_realtime_quotes(self, codes: List[str]) -> pd.DataFrame:
        """获取实时行情数据"""
        try:
            quotes = self.xtdata.get_full_tick()
            
            data = []
            for code in codes:
                if code in quotes:
                    quote = quotes[code]
                    data.append({
                        'code': code,
                        'price': quote.get('lastPrice', 0),
                        'change_pct': (quote.get('lastPrice', 0) / quote.get('lastClose', 1) - 1) * 100,
                        'volume': quote.get('volume', 0),
                        'amount': quote.get('amount', 0),
                    })
                    
            return pd.DataFrame(data)
            
        except Exception as e:
            logger.error(f"获取实时行情失败: {e}")
            return pd.DataFrame()
