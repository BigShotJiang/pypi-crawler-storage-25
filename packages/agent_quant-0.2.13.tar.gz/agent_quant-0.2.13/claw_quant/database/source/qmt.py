# -*- coding: utf-8 -*-
"""
QMT数据源实现
提供从QMT获取实时行情数据的功能
"""

from typing import List, Dict, Optional, Union, Any
from datetime import date, datetime
import pandas as pd
import numpy as np
import logging
import os
import sys

logger = logging.getLogger(__name__)


class QMTDataSource:
    """
    QMT数据源
    
    负责从QMT客户端获取实时行情数据
    """
    
    def __init__(self, qmt_path: Optional[str] = None):
        """
        初始化QMT数据源
        
        Args:
            qmt_path: QMT安装路径，默认自动检测
        """
        self.qmt_path = qmt_path or self._detect_qmt_path()
        self.xtdata = None
        self._connected = False
        self._connect()
        
    def _detect_qmt_path(self) -> str:
        """自动检测QMT安装路径"""
        possible_paths = [
            r"C:\国金证券QMT交易端",
            r"C:\workspace\国金证券QMT交易端",
            r"C:\Program Files (x86)\国金证券QMT交易端",
            r"D:\国金证券QMT交易端",
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                logger.info(f"检测到QMT路径: {path}")
                return path
                
        raise FileNotFoundError("未找到QMT安装路径，请手动指定")
    
    def _connect(self):
        """连接QMT"""
        try:
            os.environ['QMT_PATH'] = self.qmt_path
            sys.path.insert(0, os.path.join(self.qmt_path, 'python'))
            
            from xtquant import xtdata
            self.xtdata = xtdata
            
            # 尝试设置数据路径（某些版本的xtdata可能没有这个函数）
            data_dir = os.path.join(self.qmt_path, 'userdata_mini', 'datadir')
            if os.path.exists(data_dir):
                try:
                    if hasattr(self.xtdata, 'set_data_path'):
                        self.xtdata.set_data_path(data_dir)
                except:
                    pass  # 忽略设置路径的错误
                
            self._connected = True
            logger.info(f"已连接QMT，数据目录: {data_dir}")
            
        except Exception as e:
            logger.error(f"连接QMT失败: {e}")
            self._connected = False
            raise
    
    def is_connected(self) -> bool:
        """检查是否已连接"""
        return self._connected
    
    def get_stock_list(self, market: str = 'all') -> List[str]:
        """
        获取股票列表
        
        Args:
            market: 市场类型 ('all', 'sh', 'sz')
            
        Returns:
            股票代码列表
        """
        if not self._connected:
            raise RuntimeError("QMT未连接")
            
        try:
            if market == 'all':
                stocks = self.xtdata.get_stock_list_in_sector('沪深A股')
            elif market == 'sh':
                stocks = self.xtdata.get_stock_list_in_sector('上证A股')
            elif market == 'sz':
                stocks = self.xtdata.get_stock_list_in_sector('深证A股')
            else:
                stocks = self.xtdata.get_stock_list_in_sector(market)
                
            return list(stocks) if stocks else []
            
        except Exception as e:
            logger.error(f"获取股票列表失败: {e}")
            return []
    
    def get_market_data_batch(
        self,
        codes: List[str],
        period: str = '1d',
        start_date: date = None,
        end_date: date = None
    ) -> pd.DataFrame:
        """
        批量获取行情数据
        
        Args:
            codes: 股票代码列表
            period: 周期 ('1d', '1m', '5m', 'tick')
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame包含行情数据
        """
        if not self._connected:
            raise RuntimeError("QMT未连接")
            
        if not codes:
            return pd.DataFrame()
            
        try:
            # QMT日期偏移补偿：QMT请求日期N会返回N-1的数据
            # 所以请求时需要+1天来补偿这个偏移
            from datetime import timedelta
            
            if start_date:
                start_date = start_date + timedelta(days=1)
            if end_date:
                end_date = end_date + timedelta(days=1)
            
            # 转换日期格式
            start_time = start_date.strftime('%Y%m%d') if start_date else None
            end_time = end_date.strftime('%Y%m%d') if end_date else None
            
            # 下载历史数据
            for code in codes:
                self.xtdata.download_history_data(code, period, start_time, end_time)
            
            # 获取数据
            data = self.xtdata.get_market_data_ex(
                field_list=[],
                stock_list=codes,
                period=period,
                start_time=start_time,
                end_time=end_time,
                count=-1
            )
            
            if not data:
                return pd.DataFrame()
                
            # 转换为DataFrame
            dfs = []
            for code, df in data.items():
                if df is not None and not df.empty:
                    df = df.copy()
                    df['code'] = code
                    dfs.append(df)
                    
            if not dfs:
                return pd.DataFrame()
                
            result = pd.concat(dfs, ignore_index=True)
            return self._standardize_columns(result)
            
        except Exception as e:
            logger.error(f"获取行情数据失败: {e}")
            return pd.DataFrame()
    
    def _standardize_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """标准化列名"""
        column_mapping = {
            'time': 'trade_date',
            'open': 'open',
            'high': 'high',
            'low': 'low',
            'close': 'close',
            'volume': 'volume',
            'amount': 'amount',
            'turnoverrate': 'turnover_rate',
            'pe': 'pe_ratio',
            'pb': 'pb_ratio',
            'totalcapital': 'market_cap',
        }
        
        # 重命名列
        df = df.rename(columns=column_mapping)
        
        # 转换日期
        if 'trade_date' in df.columns:
            if pd.api.types.is_numeric_dtype(df['trade_date']):
                df['trade_date'] = pd.to_datetime(df['trade_date'], unit='ms').dt.date
            else:
                df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
                
        return df
