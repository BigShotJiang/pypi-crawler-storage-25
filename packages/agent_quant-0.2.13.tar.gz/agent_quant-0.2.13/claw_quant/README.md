# ClawQuant

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

**中文** | [English](./README.en.md)

> **注意**: ClawQuant 是专门为 [OpenClaw](https://github.com/openclaw/openclaw) 定制的量化交易 Skill 框架，推荐通过 OpenClaw 自动安装使用。

ClawQuant 是一个基于 Python 的开源量化交易系统开发框架，专注于 A 股市场。它提供了从数据获取、因子计算、策略回测到交易执行的完整量化交易解决方案。

## 安装方式

### 方式一：通过 OpenClaw 自动安装（推荐）

在 OpenClaw 中添加 Skill 即可自动完成安装：

```bash
# OpenClaw 会自动完成以下操作：
# 1. pip install claw_quant
# 2. 安装依赖
# 3. 配置环境
```

### 方式二：手动 pip 安装

```bash
pip install claw_quant
```

### 方式三：从源码安装

```bash
git clone https://github.com/clawquant/claw_quant.git
cd claw_quant
pip install -e .
```

## 快速开始

### 1. 启动数据库服务

**Windows:**
```bash
# 前台运行
start_db_server.bat

# 后台运行
start_db_server.bat --bg
```

**Linux/Mac:**
```bash
# 添加执行权限
chmod +x start_db_server.sh

# 前台运行
./start_db_server.sh

# 后台运行
./start_db_server.sh --bg
```

### 2. 使用 CLI 工具

```bash
# 查看帮助
python -m claw_quant.cli --help

# 更新数据
python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01

# 查询数据
python -m claw_quant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01

# 查看可用因子
python -m claw_quant.cli factor list

# 策略回测
python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
```

### 3. 使用 Python API

```python
from claw_quant.database.api import StockAPI

# 创建 API 实例
api = StockAPI()

# 获取日线数据
df = api.get_daily('000001.SZ', '2024-01-01', '2024-06-01')
print(df)

# 获取股票列表
stocks = api.get_all_stocks()
print(stocks)
```

## 功能特性

### 📊 数据管理
- **多数据源支持**：通过 QMT (XtQuant) 获取实时行情数据
- **本地数据存储**：基于 DuckDB 的高性能本地数据存储
- **HTTP API 服务**：提供标准化的数据访问接口
- **自动数据更新**：支持定时任务自动更新数据

### 🔬 因子分析
- **内置因子库**：包含技术指标、情绪指标、质量因子等 20+ 常用因子
- **自定义因子**：支持用户自定义因子计算
- **因子回测**：支持 IC 测试、分层收益测试等

### 📈 策略回测
- **多引擎支持**：
  - Local：本地轻量级回测引擎
  - CSKhQuant：基于 CSKhQuant 框架的回测
  - JQData：聚宽数据回测引擎
  - VNPY：基于 VNPY 框架的回测
- **统一接口**：所有引擎使用统一的输入输出格式
- **策略库**：内置均线交叉、MACD 等经典策略

### 🖥️ 图形界面
- **数据查看器**：可视化查看股票数据和因子数据
- **回测界面**：图形化策略回测和结果展示
- **批量下载**：支持批量数据下载和管理

### 🤖 AI 支持
- **Skill 接口**：提供标准化的 AI Agent 调用接口
- **CLI 工具**：命令行工具支持自动化操作

## 项目结构

```
claw_quant/
├── database/          # 数据管理模块
│   ├── api.py         # 数据访问接口
│   ├── storage/       # 数据存储（DuckDB）
│   ├── updater/       # 数据更新
│   └── source/        # 数据源（QMT）
├── src/               # 核心功能模块
│   ├── backtest/      # 回测引擎
│   ├── factor/        # 因子库
│   ├── strategy/      # 策略库
│   ├── gui/           # 图形界面
│   └── utils/         # 工具函数
├── skills/            # AI Skill 接口
│   └── claw_quant/    # Skill 定义
├── tests/             # 测试代码
├── cli.py             # 命令行工具
├── examples/          # 示例代码
└── docs/              # 文档
```

## 依赖说明

### 核心依赖
- Python >= 3.8
- DuckDB >= 0.9.0
- Pandas >= 2.0.0
- NumPy >= 1.24.0
- PyQt5 >= 5.15.0

### 可选依赖
- **数据接口**：xtquant (QMT 数据接口)
- **回测引擎**：
  - CSKhQuant：需要单独安装
  - JQData：需要聚宽账号
  - VNPY：需要安装 vnpy 包

### 关于 QMT

QMT (迅投) 是本项目的主要数据源，用于获取 A 股实时行情数据。由于 QMT 不在开源社区，需要用户自行安装：

1. 下载并安装 QMT 客户端
2. 安装 xtquant Python 包
3. 配置 QMT 路径

详细配置请参考 [QMT 配置文档](./docs/qmt_setup.md)

## 文档

- [快速开始指南](./docs/quickstart.md)
- [API 文档](./docs/api.md)
- [因子使用说明](./docs/factors.md)
- [策略开发指南](./docs/strategy.md)
- [QMT 配置说明](./docs/qmt_setup.md)
- [OpenClaw 集成指南](./docs/openclaw_integration.md)

## 贡献指南

我们欢迎所有形式的贡献，包括但不限于：

- 提交 Bug 报告
- 提交功能建议
- 提交代码改进
- 完善文档

请参考 [CONTRIBUTING.md](./CONTRIBUTING.md) 了解详细贡献流程。

## 社区与支持

- **GitHub Issues**: [提交问题](https://github.com/clawquant/claw_quant/issues)
- **讨论区**: [GitHub Discussions](https://github.com/clawquant/claw_quant/discussions)
- **邮箱**: clawquant@example.com

## 许可证

本项目采用 [MIT 许可证](./LICENSE) 开源。

## 免责声明

本项目仅供学习和研究使用，不构成任何投资建议。使用本项目进行实盘交易的风险由用户自行承担。

## 致谢

感谢以下开源项目的贡献：
- [DuckDB](https://duckdb.org/) - 高性能嵌入式数据库
- [Pandas](https://pandas.pydata.org/) - 数据分析库
- [VNPY](https://www.vnpy.com/) - 量化交易框架
- [CSKhQuant](https://github.com/) - 量化回测框架
- [OpenClaw](https://github.com/openclaw/openclaw) - AI Agent 框架
