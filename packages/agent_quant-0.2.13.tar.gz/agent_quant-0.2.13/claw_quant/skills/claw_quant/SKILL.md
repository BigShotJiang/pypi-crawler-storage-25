---
name: "stock-data"
description: "A-share stock market data management and backtesting. Supports data query/update, factor analysis, and multi-engine strategy backtesting."
---

# 股票数据管理与回测 Skill

## 快速开始

### 数据库服务管理（重要）

**数据库服务是数据查询和回测的前提**，必须先启动数据库服务。

```bash
# 启动数据库服务（同步启动，等待3-5秒）
python -m claw_quant.cli db start

# 停止数据库服务
python -m claw_quant.cli db stop

# 检查数据库状态
python -m claw_quant.cli db status
```

**重要提示：**
1. **重复启动处理**：如果数据库已在运行，`db start` 会返回 `status: "already_running"`，此时无需重复启动，可以直接使用
2. **同步启动**：`db start` 会同步等待服务启动完成（最多10秒），启动成功后才返回
3. **后台保持**：数据库服务以系统服务方式启动，即使关闭终端也会保持运行
4. **启动时间**：通常需要 3-5 秒完成启动

**Agent使用建议：**
```bash
# 1. 先尝试启动数据库（如果已在运行会返回 already_running）
python -m claw_quant.cli db start

# 2. 检查数据库状态确认正常运行
python -m claw_quant.cli db status

# 3. 现在可以正常使用数据查询和回测功能
```

## 功能模块

| 命令 | 功能 | 使用场景 |
|------|------|----------|
| `selftest` | 运行完整的自动化测试 | 验证所有 CLI 功能是否正常 |
| `doctor` | 系统诊断 | 检查版本、数据库、QMT、回测引擎状态 |
| `update` | 从QMT更新数据到本地数据库 | 首次获取数据、更新今日行情 |
| `query` | 查询本地数据库已有数据 | 查看股票历史价格 |
| `factor` | 因子管理（list/info/calc/backtest） | 因子计算、回测 |
| `strategy` | 策略管理（list/info/backtest） | 策略回测 |
| `engines` | 查看可用回测引擎 | 查看支持的回测引擎列表 |
| `dynamic-factor` | 动态因子管理 | 创建、查看、删除存储在数据库中的因子 |
| `dynamic-strategy` | 动态策略管理 | 创建、查看、删除存储在数据库中的策略 |

## 常用命令

```bash
# 查看所有可用命令
python -m claw_quant.cli --help

# 系统诊断（检查数据库、QMT、引擎状态）
python -m claw_quant.cli doctor

# 运行完整测试
python -m claw_quant.cli selftest

# 查看因子列表
python -m claw_quant.cli factor list

# 查看策略列表
python -m claw_quant.cli strategy list

# 查看可用回测引擎
python -m claw_quant.cli engines
```

## 模块说明

### 数据管理

**update** - 从QMT获取实时数据并保存到本地数据库
- 前提：数据库服务已启动、QMT客户端已登录
- 使用 `--help` 查看详细参数

**query** - 从本地DuckDB数据库查询已有股票数据
- 前提：数据已存在于数据库（需先update）
- 使用 `--help` 查看详细参数

### 因子管理 (factor)

因子是纯数据计算，输出信号值。

**因子分类**（参考聚宽因子库，共44个因子）：
- **估值类**: PE_TTM, PB, PS, PCF, 股息率, EP, BP, SP
- **质量类**: ROE, ROA, 毛利率, 净利率, 营业周期, 资产负债率, 流动比率, 现金比率
- **成长类**: 营收增长率, 净利润增长率, ROE增长率, 总资产增长率, EPS增长率, 经营现金流增长率
- **动量类**: 20日/60日/120日动量, 20日/60日波动率, Beta, 最大回撤, 收益方差
- **情绪类**: 20日平均换手率, 换手率比(5日/20日), PSY心理线, VR成交量比率, OBV能量潮, 资金流向
- **技术类**: MA_CROSS均线交叉, MACD, RSI, KDJ, 布林带, CCI, 威廉指标

**每个因子都有独立的help信息**，包含参数说明和使用示例：
```bash
# 查看特定因子的详细help（包含参数说明、示例）
python -m claw_quant.cli factor info <因子代码>

# 示例：查看MACD因子的help
python -m claw_quant.cli factor info MACD
```

子命令：
- `factor list` - 列出所有可用因子
- `factor info <name>` - 查看因子详细help（参数、示例、返回值说明）
- `factor calc <name> --date YYYY-MM-DD` - 计算因子值
- `factor backtest <name> --start YYYY-MM-DD --end YYYY-MM-DD` - 因子回测（IC/分层）

### 策略管理 (strategy)

策略是完整的交易系统，包含信号生成、仓位管理、风控等。

子命令：
- `strategy list` - 列出所有可用策略
- `strategy info <name>` - 查看策略详情
- `strategy backtest <name> --start YYYY-MM-DD --end YYYY-MM-DD` - 策略回测

### 回测引擎 (engines)

查看可用的回测引擎列表及其状态。

## 典型工作流程

### 数据准备
```bash
# 1. 更新数据
python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01

# 2. 查询验证
python -m claw_quant.cli query --code 000001.SZ --start 2024-06-01 --end 2024-06-01
```

### 因子研发流程
```bash
# 1. 查看可用因子
python -m claw_quant.cli factor list

# 2. 查看因子详细help（包含参数说明、使用示例）
python -m claw_quant.cli factor info MACD

# 3. 计算因子值（使用默认参数）
python -m claw_quant.cli factor calc MACD --date 2024-06-01 --codes 000001.SZ

# 4. 计算因子值（使用自定义参数，Windows用双引号包裹）
python -m claw_quant.cli factor calc MA_CROSS --date 2024-06-01 --codes 000001.SZ --params "{short_window:10,long_window:30}"

# 5. 因子回测（IC测试）
python -m claw_quant.cli factor backtest MOM_20D --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

# 6. 因子回测（分层收益）
python -m claw_quant.cli factor backtest MOM_20D --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer
```

### 策略研发流程
```bash
# 1. 查看可用策略
python -m claw_quant.cli strategy list

# 2. 查看策略详情
python -m claw_quant.cli strategy info CROSS_STRATEGY

# 3. 策略回测
python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
```

## 系统诊断与测试

**doctor** - 系统诊断命令，检查运行环境
```bash
# 检查系统状态（版本、数据库、QMT、回测引擎）
python -m claw_quant.cli doctor
```

诊断项目：
- 系统信息（操作系统、Python版本）
- 包信息（安装路径、版本）
- 数据库诊断（路径、运行状态、连接测试）
- QMT客户端诊断（连接状态、读取测试）
- 回测引擎依赖（vnpy, jqdata, backtrader等）

**selftest** - 运行完整的自动化测试
```bash
# 执行完整的测试流程
python -m claw_quant.cli selftest
```

测试流程：
1. 测试所有 --help 命令
2. 检查数据库状态
3. 启动数据库服务器
4. 检查 QMT 连接状态
5. 更新股票数据（如果 QMT 可用）
6. 查询股票数据
7. 获取最新交易日期
8. 获取股票列表
9. 因子列表、详情、计算、回测
10. 策略列表、详情、回测
11. 查看回测引擎
12. 停止数据库服务器

### 动态因子/策略开发

支持将因子和策略代码存储在数据库中，运行时动态编译执行。

**动态因子管理：**
```bash
# 列出所有动态因子
python -m claw_quant.cli dynamic-factor list

# 查看动态因子详情（包含源代码）
python -m claw_quant.cli dynamic-factor get --code MY_FACTOR

# 保存动态因子（从文件）
python -m claw_quant.cli dynamic-factor save --code MY_FACTOR --name "我的因子" \
  --category "技术" --file my_factor.py \
  --meta '{"parameters": {"window": {"default": 20}}}'

# 保存动态因子（直接代码）
python -m claw_quant.cli dynamic-factor save --code MY_FACTOR --name "我的因子" \
  --category "技术" --code-text "class MyFactor(JQFactor): ..." \
  --meta '{"parameters": {}}'

# 测试因子编译
python -m claw_quant.cli dynamic-factor test --code MY_FACTOR

# 删除动态因子
python -m claw_quant.cli dynamic-factor delete --code MY_FACTOR
```

**动态策略管理：**
```bash
# 列出所有动态策略
python -m claw_quant.cli dynamic-strategy list

# 查看动态策略详情
python -m claw_quant.cli dynamic-strategy get --code MY_STRATEGY

# 保存动态策略
python -m claw_quant.cli dynamic-strategy save --code MY_STRATEGY --name "我的策略" \
  --file my_strategy.py --meta '{"author": "agent"}'

# 删除动态策略
python -m claw_quant.cli dynamic-strategy delete --code MY_STRATEGY
```

**动态因子示例代码：**
```python
from claw_quant.src.factor.jqfactor_base import JQFactor, FactorMeta
import pandas as pd
import numpy as np

class MyCustomFactor(JQFactor):
    meta = FactorMeta(
        code='MY_CUSTOM',
        name='自定义因子',
        category='技术',
        description='这是一个示例自定义因子',
        parameters={
            'window': {'default': 20, 'type': 'int', 'description': '计算窗口'}
        },
        dependencies=['close'],
        max_window=30
    )
    
    def calc(self, data):
        close = data['close']
        window = self.params.get('window', 20)
        return close.rolling(window=window).mean().iloc[-1]
```

## 故障排查

| 问题 | 解决方法 |
|------|----------|
| 查询返回空数据 | 先运行update更新数据 |
| 更新失败 | 确认QMT已登录且数据已下载 |
| 回测失败 | 确认数据已更新，使用--help检查参数 |
| 引擎不可用 | 运行 `engines` 命令查看状态 |
| 系统环境问题 | 运行 `doctor` 命令诊断 |
| 动态因子编译失败 | 检查代码语法，确认继承自JQFactor |

## 注意

所有命令的详细参数请使用 `--help` 查看，例如：
```bash
python -m claw_quant.cli update --help
python -m claw_quant.cli query --help
python -m claw_quant.cli factor --help
python -m claw_quant.cli factor calc --help
python -m claw_quant.cli factor backtest --help
python -m claw_quant.cli strategy --help
python -m claw_quant.cli dynamic-factor --help
python -m claw_quant.cli dynamic-strategy --help
python -m claw_quant.cli strategy backtest --help
```
