#!/bin/bash
# -*- coding: utf-8 -*-
#
# ClawQuant Skill 启动脚本
# 自动完成：安装依赖 → 启动数据库 → 检查状态
# 支持快速模式：如果已安装且数据库已运行，则跳过重复步骤
#

set -e

echo "=========================================="
echo "ClawQuant Skill 启动脚本"
echo "=========================================="

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 快速模式标志
QUICK_MODE=false

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}错误: 未找到 python3，请先安装 Python 3.8+${NC}"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo -e "${BLUE}ℹ Python 版本: $PYTHON_VERSION${NC}"

# 步骤 1: 检查 agent-quant 是否已安装
echo ""
echo "[1/4] 检查依赖..."
if python3 -c "import claw_quant" 2>/dev/null; then
    echo -e "${GREEN}✓ agent-quant 已安装${NC}"
    QUICK_MODE=true
else
    echo "正在安装 agent-quant..."
    pip3 install agent-quant
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ agent-quant 安装成功${NC}"
    else
        echo -e "${RED}✗ agent-quant 安装失败${NC}"
        exit 1
    fi
fi

# 检查其他关键依赖
python3 -c "import pandas, numpy, flask" 2>/dev/null
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 所有依赖已就绪${NC}"
else
    echo "正在安装依赖..."
    pip3 install pandas numpy flask
    QUICK_MODE=false
fi

# 步骤 2: 检查数据库状态
echo ""
echo "[2/4] 检查数据库状态..."

# 使用 doctor 命令检查数据库状态
DB_CHECK=$(python3 -m claw_quant.cli doctor 2>/dev/null)
DB_STATUS=$(echo "$DB_CHECK" | grep -o '"status": "[^"]*"' | grep -o 'running\|stopped' | head -1)

if [ "$DB_STATUS" == "running" ]; then
    echo -e "${GREEN}✓ 数据库已在运行${NC}"
    QUICK_MODE=true
else
    echo "数据库未运行，正在启动..."
    python3 -m claw_quant.cli db start
    sleep 2
    # 再次检查
    DB_CHECK=$(python3 -m claw_quant.cli doctor 2>/dev/null)
    DB_STATUS=$(echo "$DB_CHECK" | grep -o '"status": "[^"]*"' | grep -o 'running\|stopped' | head -1)
    if [ "$DB_STATUS" == "running" ]; then
        echo -e "${GREEN}✓ 数据库启动成功${NC}"
    else
        echo -e "${YELLOW}! 数据库启动可能失败，请手动检查${NC}"
    fi
    QUICK_MODE=false
fi

# 快速模式：如果都已就绪，直接显示结果
if [ "$QUICK_MODE" == "true" ]; then
    echo ""
    echo -e "${GREEN}==========================================${NC}"
    echo -e "${GREEN}ClawQuant 已就绪（快速模式）${NC}"
    echo -e "${GREEN}==========================================${NC}"
    echo ""
    echo "可用命令:"
    echo "  python3 -m claw_quant.cli factor list       # 查看因子列表"
    echo "  python3 -m claw_quant.cli strategy list     # 查看策略列表"
    echo "  python3 -m claw_quant.cli engines           # 查看回测引擎"
    echo "  python3 -m claw_quant.cli selftest          # 运行完整测试"
    echo ""
    exit 0
fi

# 步骤 3: 运行系统诊断（仅非快速模式）
echo ""
echo "[3/4] 运行系统诊断..."
python3 -m claw_quant.cli doctor

# 步骤 4: 显示可用命令
echo ""
echo "=========================================="
echo -e "${GREEN}ClawQuant 已就绪！${NC}"
echo "=========================================="
echo ""
echo "可用命令:"
echo "  python3 -m claw_quant.cli factor list       # 查看因子列表"
echo "  python3 -m claw_quant.cli strategy list     # 查看策略列表"
echo "  python3 -m claw_quant.cli engines           # 查看回测引擎"
echo "  python3 -m claw_quant.cli selftest          # 运行完整测试"
echo ""
echo "数据更新（需要 QMT）:"
echo "  python3 -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01"
echo ""
echo "回测示例:"
echo "  python3 -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01"
echo ""
