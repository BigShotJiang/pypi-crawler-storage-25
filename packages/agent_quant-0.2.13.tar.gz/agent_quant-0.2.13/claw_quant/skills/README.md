# Skills 目录说明

## 统一入口

**所有Skill统一使用 `stock_data` 作为入口**（注意是下划线，不是横线），不要创建其他skill目录。

## 目录结构

```
skills/
├── README.md              # 本文件
├── stock_data/            # 统一Skill入口（Python模块，使用下划线）
│   ├── SKILL.md           # 股票数据管理与回测Skill文档
│   └── tools/             # 工具模块
│       └── backtest_api.py
└── backtest/              # 【废弃】准备删除，不要更新
    └── SKILL.md
```

## 功能范围

`stock_data` Skill 包含以下功能：

1. **数据管理**
   - `update` - 从QMT更新数据到本地数据库
   - `query` - 查询本地数据库已有数据

2. **因子分析**
   - `factor --list` - 列出可用因子
   - `factor --info` - 查看因子详情

3. **策略回测**
   - `backtest` - 策略回测（支持多引擎）

4. **引擎管理**
   - `engines` - 查看可用回测引擎

## 注意事项

- 所有新功能都添加到 `stock_data/SKILL.md`
- `backtest/` 目录准备废弃删除，不要更新
- CLI命令统一通过 `python -m claw_quant.cli` 调用
- 目录名使用 `stock_data`（下划线），不是 `stock-data`（横线）
