# -*- coding: utf-8 -*-
"""
ClawQuant 量化交易系统

系统级模块（根目录）:
- docs: 文档
- examples: 示例代码
- scripts: 脚本工具
- skills: Skill定义
- tests: 测试代码
- cli.py: 命令行入口
- main.py: 主程序入口

功能模块（src目录）:
- src.backtest: 回测引擎
- src.core: 核心组件
- src.data: 数据管理
- src.factor: 因子库
- src.gui: 图形界面
- src.strategy: 策略库
- src.trade: 交易接口
- src.utils: 工具函数
"""

__version__ = "0.1.0"
