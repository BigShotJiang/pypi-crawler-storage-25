"""
This file is auto-generated.
This file should never be manually modified, and must stay FROZEN.
"""
from .v1 import Relation_v1
from .v2 import Relation_v2
from .v3 import Relation_v3
from .v4 import Relation_v4
from .v5 import Relation_v5


class Relation(Relation_v5):
    """Latest version alias for Relation_v5."""
    pass

__all__ = ['Relation_v1', 'Relation_v2', 'Relation_v3', 'Relation_v4', 'Relation_v5', 'Relation']
