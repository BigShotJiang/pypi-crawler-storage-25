"""CLI dispatcher: routes to TUI or subcommands."""

import argparse
import asyncio


def _ensure_setup() -> None:
    """Run interactive setup if setup_done is not set."""
    from .user_settings import load_settings
    if not load_settings().get("setup_done"):
        from .cli_setup import cmd_setup
        cmd_setup()


def run():
    from .user_settings import apply_settings_to_env
    apply_settings_to_env()

    parser = argparse.ArgumentParser(prog="aipa", description="AIPriceAction terminal")
    sub = parser.add_subparsers(dest="command")

    # aipa analyze VCB [tickers...] [--interval 1D] [--limit N]
    #   [--source vn] [--start-date] [--end-date] [--reference-ticker VNINDEX]
    #   [--lang en] [--ma-type ema] [--question TEXT] [--questions] [--context-only]
    p_analyze = sub.add_parser("analyze", help="AI analysis for ticker(s)")
    p_analyze.add_argument("tickers", nargs="+", help="Ticker symbol(s)")
    p_analyze.add_argument("--interval", default="1D")
    p_analyze.add_argument("--limit", type=int, default=None)
    p_analyze.add_argument("--source", default=None)
    p_analyze.add_argument("--start-date", default=None)
    p_analyze.add_argument("--end-date", default=None)
    p_analyze.add_argument("--reference-ticker", default="VNINDEX")
    p_analyze.add_argument("--lang", default=None, choices=["en", "vn"])
    p_analyze.add_argument("--ma-type", default="ema", choices=["ema", "sma"])
    p_analyze.add_argument("--question", default=None, help="Custom analysis question")
    p_analyze.add_argument("--questions", action="store_true", help="List available question templates and exit")
    p_analyze.add_argument("--context-only", action="store_true", help="Dump raw context without calling LLM (no API key needed)")
    p_analyze.add_argument("--no-system-prompt", action="store_true", help="Exclude system prompt from context output")

    # aipa get-ohlcv-data TICKER [--interval 1D] [--limit N]
    #   [--start-date] [--end-date] [--source] [--ma] [--ema]
    p_ohlcv = sub.add_parser("get-ohlcv-data", help="Fetch raw OHLCV data")
    p_ohlcv.add_argument("ticker", help="Ticker symbol")
    p_ohlcv.add_argument("--interval", default="1D")
    p_ohlcv.add_argument("--limit", type=int, default=None)
    p_ohlcv.add_argument("--start-date", default=None)
    p_ohlcv.add_argument("--end-date", default=None)
    p_ohlcv.add_argument("--source", default=None)
    p_ohlcv.add_argument("--ma", action="store_true", default=True)
    p_ohlcv.add_argument("--no-ma", dest="ma", action="store_false")
    p_ohlcv.add_argument("--ema", action="store_true", default=False)
    p_ohlcv.add_argument("--no-system-prompt", action="store_true", help="Exclude persona header from output")

    # aipa deep-research [question]
    p_deep = sub.add_parser("deep-research", help="Multi-agent deep research")
    p_deep.add_argument("question", nargs="*", help="Research question")
    p_deep.add_argument("--resume", default=None, help="Resume from checkpoint session ID")
    p_deep.add_argument("--output", default=None, help="Save final report to file")
    p_deep.add_argument("--lang", default=None, choices=["en", "vn"], help="Override language")

    # aipa setup
    sub.add_parser("setup", help="Interactive first-run setup")

    # aipa resume [session_id|index]
    p_resume = sub.add_parser("resume", help="Open TUI with a resumed chat session")
    p_resume.add_argument("session", nargs="?", default=None, help="Session ID prefix or list index (default: most recent)")

    args = parser.parse_args()

    if args.command == "setup":
        from .cli_setup import cmd_setup
        cmd_setup()
    elif args.command == "analyze":
        if not getattr(args, "context_only", False) and not getattr(args, "questions", False):
            _ensure_setup()
        from .cli_commands import cmd_analyze
        asyncio.run(cmd_analyze(args))
    elif args.command == "get-ohlcv-data":
        from .cli_commands import cmd_get_ohlcv
        cmd_get_ohlcv(args)
    elif args.command == "deep-research":
        _ensure_setup()
        from .cli_commands import cmd_deep_research
        cmd_deep_research(
            question=" ".join(args.question) if args.question else "",
            resume=args.resume,
            output=args.output,
            lang=args.lang,
        )
    elif args.command == "resume":
        from .cli_commands import cmd_resume
        cmd_resume(args)
    else:
        _ensure_setup()
        from .app import main
        main()
