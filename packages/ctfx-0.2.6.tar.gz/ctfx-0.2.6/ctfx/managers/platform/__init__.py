"""Platform adapters."""
