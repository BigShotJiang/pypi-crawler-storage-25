# -*- coding: utf-8 -*-
# Kuasarr
# Project by Ritedt (Fork von https://github.com/rix1337/Quasarr)

import threading
from typing import Dict, Optional
from urllib.parse import urlencode, urlparse

import requests
from bs4 import BeautifulSoup

from kuasarr.constants import (
    DOWNLOAD_REQUEST_TIMEOUT_SECONDS,
    SESSION_REQUEST_TIMEOUT_SECONDS,
    FLARESOLVERR_REQUEST_TIMEOUT_SECONDS,
    FLARESOLVERR_CHECK_TIMEOUT_SECONDS,
    get_timeout,
    get_flaresolverr_max_timeout,
)
from kuasarr.providers.log import debug, info


def _is_valid_flaresolverr_url(url: str) -> bool:
    """Reject non-http(s) schemes to prevent unintended network access."""
    try:
        parsed = urlparse(url)
        return parsed.scheme in ('http', 'https') and bool(parsed.netloc)
    except Exception:
        return False


def _get_flaresolverr_url(shared_state) -> Optional[str]:
    """Get and validate FlareSolverr URL from shared state."""
    flaresolverr_url = shared_state.values["config"]('FlareSolverr').get('url')
    if not flaresolverr_url:
        return None
    if not _is_valid_flaresolverr_url(flaresolverr_url):
        info(f'FlareSolverr URL invalid or unsupported scheme: "{flaresolverr_url}"')
        return None
    return flaresolverr_url


def _check_flaresolverr_availability(flaresolverr_url):
    if not _is_valid_flaresolverr_url(flaresolverr_url):
        info(f'FlareSolverr URL invalid or unsupported scheme: "{flaresolverr_url}"')
        return
    payload = {
        "cmd": "request.get",
        "url": "http://www.google.com/",
        "maxTimeout": 30000,
    }
    try:
        resp = requests.post(
            flaresolverr_url,
            headers={"Content-Type": "application/json"},
            json=payload,
            timeout=get_timeout(FLARESOLVERR_CHECK_TIMEOUT_SECONDS),
        )
        if resp.status_code == 200:
            info(f'FlareSolverr reachable at "{flaresolverr_url}"')
        else:
            info(f'FlareSolverr returned unexpected status {resp.status_code} at "{flaresolverr_url}"')
    except Exception as e:
        info(f'FlareSolverr not reachable at "{flaresolverr_url}": {e}')


def check_flaresolverr_availability_async(flaresolverr_url):
    """Start a background daemon thread to check FlareSolverr availability without blocking startup."""
    threading.Thread(
        target=_check_flaresolverr_availability,
        args=(flaresolverr_url,),
        daemon=True,
    ).start()


def is_cloudflare_challenge(html: str) -> bool:
    soup = BeautifulSoup(html, "html.parser")

    # Check <title>
    title = (soup.title.string or "").strip().lower() if soup.title else ""
    if "just a moment" in title or "attention required" in title:
        return True

    # Check known Cloudflare elements
    if soup.find(id="challenge-form"):
        return True
    if soup.find("div", {"class": "cf-browser-verification"}):
        return True
    if soup.find("div", {"id": "cf-challenge-running"}):
        return True

    # Check scripts referencing Cloudflare
    for script in soup.find_all("script", src=True):
        if "cdn-cgi/challenge-platform" in script["src"]:
            return True

    # Optional: look for Cloudflare comment or beacon
    if "data-cf-beacon" in html or "<!-- cloudflare -->" in html.lower():
        return True

    return False


def update_session_via_flaresolverr(
    info,
    shared_state,
    sess,
    target_url: str,
    timeout: int = None
):
    flaresolverr_url = _get_flaresolverr_url(shared_state)
    if not flaresolverr_url:
        info("Cannot proceed without FlareSolverr. Please set it up to try again!")
        return False

    # Apply slow mode to timeout
    effective_timeout = get_timeout(timeout or FLARESOLVERR_REQUEST_TIMEOUT_SECONDS)

    fs_payload = {
        "cmd": "request.get",
        "url": target_url,
        "maxTimeout": effective_timeout * 1000,
    }

    # Send the JSON request to FlareSolverr
    fs_headers = {"Content-Type": "application/json"}
    try:
        resp = requests.post(
            flaresolverr_url,
            headers=fs_headers,
            json=fs_payload,
            timeout=effective_timeout + 10
        )
        resp.raise_for_status()
    except requests.exceptions.RequestException as e:
        info(f"Could not reach FlareSolverr: {e}")
        return {
            "status_code": None,
            "headers": {},
            "json": None,
            "text": "",
            "cookies": [],
            "error": f"FlareSolverr request failed: {e}"
        }
    except Exception as e:
        raise RuntimeError(f"Could not reach FlareSolverr: {e}")

    fs_json = resp.json()
    if fs_json.get("status") != "ok" or "solution" not in fs_json:
        raise RuntimeError(f"FlareSolverr did not return a valid solution: {fs_json.get('message', '<no message>')}")

    solution = fs_json["solution"]

    # Replace our requests.Session cookies with whatever FlareSolverr solved
    sess.cookies.clear()
    for ck in solution.get("cookies", []):
        sess.cookies.set(
            ck.get("name"),
            ck.get("value"),
            domain=ck.get("domain"),
            path=ck.get("path", "/")
        )
    return {"session": sess, "user_agent": solution.get("userAgent", None)}


def ensure_session_cf_bypassed(
    info,
    shared_state,
    session,
    url,
    headers,
    timeout: Optional[int] = None
):
    """Performs a GET and, if Cloudflare challenge or 403 is present, tries FlareSolverr."""
    # Apply slow mode to timeout
    effective_timeout = get_timeout(timeout or DOWNLOAD_REQUEST_TIMEOUT_SECONDS)

    try:
        resp = session.get(url, headers=headers, timeout=effective_timeout)
        debug(f"Initial GET: status={resp.status_code}, CF challenge={is_cloudflare_challenge(resp.text)}")
    except requests.RequestException as e:
        info(f"Initial GET failed: {e}")
        return None, None, None

    # If page is protected, try FlareSolverr
    if resp.status_code == 403 or is_cloudflare_challenge(resp.text):
        debug("Encountered Cloudflare protection. Solving challenge with FlareSolverr...")
        flaresolverr_result = update_session_via_flaresolverr(info, shared_state, session, url, timeout=effective_timeout)
        if not flaresolverr_result or flaresolverr_result.get("error"):
            error_msg = flaresolverr_result.get("error") if flaresolverr_result else "No result"
            info(f"FlareSolverr failed: {error_msg}")
            return None, None, None

        # update session and possibly user-agent
        session = flaresolverr_result.get("session", session)
        user_agent = flaresolverr_result.get("user_agent")
        if user_agent and user_agent != shared_state.values.get("user_agent"):
            info("Updating User-Agent from FlareSolverr solution: " + user_agent)
            shared_state.update("user_agent", user_agent)
            headers = {'User-Agent': shared_state.values["user_agent"]}

        # re-fetch using the new session/headers
        try:
            resp = session.get(url, headers=headers, timeout=effective_timeout)
        except requests.RequestException as e:
            info(f"GET after FlareSolverr failed: {e}")
            return None, None, None

        if resp.status_code == 403 or is_cloudflare_challenge(resp.text):
            info("Could not bypass Cloudflare protection with FlareSolverr!")
            return None, None, None

    return session, headers, resp


class FlareSolverrResponse:
    """
    Minimal Response-like object so it behaves like requests.Response.
    """

    def __init__(self, url, status_code, headers, text):
        self.url = url
        self.status_code = status_code
        self.headers = headers or {}
        self.text = text or ""
        self.content = self.text.encode("utf-8")

        # Cloudflare cookies are irrelevant here, but keep attribute for compatibility
        self.cookies = requests.cookies.RequestsCookieJar()

    def raise_for_status(self):
        if 400 <= self.status_code:
            raise requests.HTTPError(f"{self.status_code} Error for URL: {self.url}")


def flaresolverr_get(
    shared_state,
    url: str,
    timeout: Optional[int] = None,
    session_id: Optional[str] = None
) -> FlareSolverrResponse:
    """Core function for performing a GET request via FlareSolverr only."""
    # Apply slow mode to timeout
    effective_timeout = get_timeout(timeout or FLARESOLVERR_REQUEST_TIMEOUT_SECONDS)

    flaresolverr_url = _get_flaresolverr_url(shared_state)
    if not flaresolverr_url:
        raise RuntimeError("FlareSolverr URL not configured in shared_state.")

    payload = {
        "cmd": "request.get",
        "url": url,
        "maxTimeout": effective_timeout * 1000
    }
    if session_id:
        payload["session"] = session_id

    try:
        resp = requests.post(
            flaresolverr_url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=effective_timeout + 10
        )
        resp.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Error communicating with FlareSolverr: {e}") from e

    data = resp.json()

    if data.get("status") != "ok":
        raise RuntimeError(f"FlareSolverr returned error: {data.get('message')}")

    solution = data.get("solution", {})
    html = solution.get("response", "")
    status_code = solution.get("status", 200)
    url = solution.get("url", url)

    # headers → convert list-of-keyvals to dict
    fs_headers = {h["name"]: h["value"] for h in solution.get("headers", [])}

    # Update global UA if provided
    user_agent = solution.get("userAgent")
    if user_agent and user_agent != shared_state.values.get("user_agent"):
        shared_state.update("user_agent", user_agent)

    return FlareSolverrResponse(
        url=url,
        status_code=status_code,
        headers=fs_headers,
        text=html
    )


def flaresolverr_post(
    shared_state,
    url: str,
    data: Optional[Dict] = None,
    headers: Optional[Dict] = None,
    timeout: Optional[int] = None,
    session_id: Optional[str] = None
) -> FlareSolverrResponse:
    """Make POST request via FlareSolverr."""
    # Apply slow mode to timeout
    effective_timeout = get_timeout(timeout or FLARESOLVERR_REQUEST_TIMEOUT_SECONDS)

    flaresolverr_url = _get_flaresolverr_url(shared_state)
    if not flaresolverr_url:
        raise RuntimeError("FlareSolverr URL not configured in shared_state.")

    # Encode POST data
    if isinstance(data, dict):
        post_data = urlencode(data)
    else:
        post_data = data or ""

    payload = {
        "cmd": "request.post",
        "url": url,
        "postData": post_data,
        "maxTimeout": effective_timeout * 1000,
    }
    if session_id:
        payload["session"] = session_id

    if headers:
        payload["headers"] = headers

    try:
        resp = requests.post(
            flaresolverr_url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=effective_timeout + 10
        )
        resp.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Error communicating with FlareSolverr: {e}") from e

    data = resp.json()

    if data.get("status") != "ok":
        raise RuntimeError(f"FlareSolverr returned error: {data.get('message')}")

    solution = data.get("solution", {})
    html = solution.get("response", "")
    status_code = solution.get("status", 200)
    url = solution.get("url", url)

    fs_headers = {h["name"]: h["value"] for h in solution.get("headers", [])}

    user_agent = solution.get("userAgent")
    if user_agent and user_agent != shared_state.values.get("user_agent"):
        shared_state.update("user_agent", user_agent)

    return FlareSolverrResponse(
        url=url,
        status_code=status_code,
        headers=fs_headers,
        text=html
    )


def flaresolverr_create_session(shared_state, session_id: str) -> bool:
    """Create persistent FlareSolverr session."""
    flaresolverr_url = _get_flaresolverr_url(shared_state)
    if not flaresolverr_url:
        return False

    payload = {"cmd": "sessions.create"}
    if session_id:
        payload["session"] = session_id

    try:
        resp = requests.post(
            flaresolverr_url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=get_timeout(SESSION_REQUEST_TIMEOUT_SECONDS)
        )
        resp.raise_for_status()
        data = resp.json()
        if data.get("status") == "ok":
            return True
    except Exception as e:
        debug(f"Failed to create FlareSolverr session: {e}")
    return False


def flaresolverr_destroy_session(shared_state, session_id: str) -> bool:
    """Destroy FlareSolverr session."""
    flaresolverr_url = _get_flaresolverr_url(shared_state)
    if not flaresolverr_url:
        return False

    payload = {"cmd": "sessions.destroy", "session": session_id}

    try:
        resp = requests.post(
            flaresolverr_url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=get_timeout(SESSION_REQUEST_TIMEOUT_SECONDS)
        )
        resp.raise_for_status()
        return True
    except Exception as e:
        debug(f"Failed to destroy FlareSolverr session: {e}")
    return False
