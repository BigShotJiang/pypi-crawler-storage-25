import unittest
import json
from pydantic import BaseModel
from soprano_sdk.guardrails.functional_guardrail import StructuredOutputGuardrail

class MessageSchema(BaseModel):
    message: str | None = None
    user_id: str | None = None
    options: list[dict] | None = None

class BotResponseSchema(BaseModel):
    bot_response: str | None = None
    order_id: int | None = None
    options: list[dict] | None = None

class TestStructuredOutputGuardrailUnit(unittest.TestCase):

    def setUp(self):
        self.guardrail = StructuredOutputGuardrail(error_message="Check failed.")

    def test_plain_text_fails(self):
        """Plain text (non-dict) should fail the guardrail."""
        result = self.guardrail.check("I am not a JSON.")
        self.assertFalse(result.passed)
        # Verify default field detection in feedback
        feedback = self.guardrail.regeneration_feedback
        self.assertIn("'bot_response' or 'message'", feedback)

    def test_schema_aware_field_detection_message(self):
        """Should detect 'message' field from MessageSchema."""
        response = json.dumps({"message": "Hello"})
        result = self.guardrail.check(response, output_schema=MessageSchema)
        self.assertTrue(result.passed)
        
        # Verify feedback uses 'message'
        # We need to trigger a failure to see the updated feedback fields
        # Triggering Rule 4 (options without message)
        response_fail = json.dumps({"options": [{"text": "A"}]})
        self.guardrail.check(response_fail, output_schema=MessageSchema)
        feedback = self.guardrail.regeneration_feedback
        self.assertIn("'message'", feedback)
        self.assertNotIn("'bot_response'", feedback)

    def test_schema_aware_field_detection_bot_response(self):
        """Should detect 'bot_response' field from BotResponseSchema."""
        response = json.dumps({"bot_response": "Hi"})
        result = self.guardrail.check(response, output_schema=BotResponseSchema)
        self.assertTrue(result.passed)
        
        # Trigger failure (Rule 4)
        response_fail = json.dumps({"options": [{"text": "A"}]})
        self.guardrail.check(response_fail, output_schema=BotResponseSchema)
        feedback = self.guardrail.regeneration_feedback
        self.assertIn("'bot_response'", feedback)
        self.assertNotIn("'message'", feedback)

    def test_rule_1_schema_validation_failure(self):
        """Fails if data doesn't match schema types."""
        # order_id should be int, but we provide str
        response = json.dumps({"bot_response": "Hi", "order_id": "abc"})
        result = self.guardrail.check(response, output_schema=BotResponseSchema)
        self.assertFalse(result.passed)
        self.assertIn("validation error", self.guardrail.regeneration_feedback.lower())

    def test_rule_2_routing_fields_bypass(self):
        """Routing fields like 'intent_change' or 'restart' should pass even without message."""
        # No bot_response/message, but intent_change is present
        response = json.dumps({"intent_change": "some_node"})
        result = self.guardrail.check(response, output_schema=BotResponseSchema)
        self.assertTrue(result.passed)

        response_restart = json.dumps({"restart": True})
        result_restart = self.guardrail.check(response_restart, output_schema=BotResponseSchema)
        self.assertTrue(result_restart.passed)

    def test_rule_3_required_fields_check(self):
        """Fails if required fields are missing and no Rule 2 fields are present."""
        # No message, missing required 'user_id'
        response = json.dumps({})
        result = self.guardrail.check(
            response, 
            output_schema=MessageSchema, 
            required_fields=["user_id"]
        )
        self.assertFalse(result.passed)

        # Passes if required field is present
        response_ok = json.dumps({"user_id": "123"})
        result_ok = self.guardrail.check(
            response_ok, 
            output_schema=MessageSchema, 
            required_fields=["user_id"]
        )
        self.assertTrue(result_ok.passed)

    def test_rule_4_options_alone_passes(self):
        """Providing options without a conversational response should now PASS (per user feedback)."""
        response = json.dumps({"options": [{"text": "Choose A"}]})
        # For MessageSchema, 'message' is the conversational field.
        result = self.guardrail.check(response, output_schema=MessageSchema)
        self.assertTrue(result.passed)

        # Passes if message is added (obviously)
        response_ok = json.dumps({"message": "Please pick", "options": [{"text": "A"}]})
        result_ok = self.guardrail.check(response_ok, output_schema=MessageSchema)
        self.assertTrue(result_ok.passed)

    def test_rule_empty_response_passes_if_nothing_required(self):
        """Empty dict with no schema/required fields should PASS (per user feedback)."""
        response = json.dumps({})
        result = self.guardrail.check(response)
        self.assertTrue(result.passed)
        self.assertIn("empty or incomplete", self.guardrail.regeneration_feedback)

if __name__ == "__main__":
    unittest.main()
