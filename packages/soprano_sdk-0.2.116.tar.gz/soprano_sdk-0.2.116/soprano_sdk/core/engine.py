from __future__ import annotations
from typing import Optional, Dict, Any, Tuple, List

import re
import json
import yaml
from datetime import date
from jinja2 import Environment
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.constants import START
from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledStateGraph
from pydantic import BaseModel, Field

from .constants import (
    COLLECT_INPUT_METADATA_FIELDS,
    WorkflowKeys,
    MFAConfig,
    DEFAULT_HUMANIZATION_ENABLED,
    DEFAULT_HUMANIZATION_SYSTEM_PROMPT,
    HUMANIZATION_URL_PRESERVATION_EXAMPLES,
    build_humanization_options_guidance,
    HumanizationKeys,
    LocalizationKeys,
    OutcomePrefix,
    MAX_OPTION_TEXT_LENGTH,
    DEFAULT_OPTION_CHAR_LIMIT_ENABLED,
)
from .localization import LocalizationManager, LocalizationRule
from .models import MessagePayload
from ..agents.factory import AgentFactory
from ..guardrails import GuardrailViolationError
from .state import create_state_model
from ..nodes.factory import NodeFactory
from ..routing.router import WorkflowRouter
from ..guardrails import GuardrailFactory, GuardrailsConnectionError
from ..utils.function import FunctionRepository
from ..utils.logger import logger
from ..utils.tool import ToolRepository
from ..utils.tracing import trace_agent_invocation
from ..validation import validate_workflow


class HumanizedResponse(BaseModel):
    """Structured output for humanized messages."""

    class _OptionSchema(BaseModel):
        """Pydantic schema for LLM structured output only."""
        text: str = Field(description="Primary display text for the option (button label or list item heading)")
        subtext: str = Field(
            default='',
            description="Secondary descriptive text. Only populate when additional context is needed to distinguish the option; leave empty otherwise."
        )
    message: str = Field(
        description="The humanized message without any preambles, explanations, or meta-commentary"
    )
    options: Optional[List[_OptionSchema]] = Field(
        default=None,
        description=(
            "Array of option objects for the user. Only populate when the reference message "
            "contains a single question with explicit options. Each option has 'text' (display text) "
            "and 'subtext' (secondary text) fields. Preserve provided options exactly. "
            "Return [] when the message has multiple questions or no options."
        )
    )
    is_selectable: Optional[bool] = Field(
        default=None,
        description="Whether user must select from options (true) or can also type freely (false)"
    )


_YAML_SCHEMA_KEYS: frozenset = frozenset({
    'name', 'description', 'version', 'agent_framework', 'humanization_agent',
    'localization', 'data', 'inputs', 'failure_message', 'steps', 'outcomes',
    'metadata', 'tool_config', 'follow_up', 'guardrails', 'rollback_strategy',
})


def _merge_lists(base: list, override: list) -> list:
    """Merge two lists, trying to match items by identity key (id / name / action).

    If every item in *override* is a dict that carries an identity key, same-keyed
    items in *base* are deep-merged (override wins); unmatched override items are
    appended.  If that condition is not met the override list replaces base entirely.
    """
    if not override:
        return list(base)
    if not base:
        return list(override)

    identity_key: Optional[str] = None
    for candidate in ('id', 'name', 'action'):
        if all(isinstance(item, dict) and candidate in item for item in override):
            identity_key = candidate
            break

    if identity_key is None:
        return list(override)

    order: list = []
    indexed: Dict[str, Any] = {}
    for item in base:
        if isinstance(item, dict) and identity_key in item:
            key = item[identity_key]
            indexed[key] = dict(item)
            order.append(key)

    for override_item in override:
        if not isinstance(override_item, dict) or identity_key not in override_item:
            continue
        item_key = override_item[identity_key]
        if item_key in indexed:
            indexed[item_key] = _deep_merge_config(indexed[item_key], override_item)
        else:
            indexed[item_key] = override_item
            order.append(item_key)

    return [indexed[k] for k in order if k in indexed]


def _deep_merge_config(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge *override* on top of *base*. Override always wins.

    - dicts  → recursive merge
    - lists  → :func:`_merge_lists` (identity-key merge or full replacement)
    - scalars → override replaces base
    """
    result = dict(base)
    for key, override_val in override.items():
        base_val = result.get(key)
        if isinstance(override_val, dict) and isinstance(base_val, dict):
            result[key] = _deep_merge_config(base_val, override_val)
        elif isinstance(override_val, list) and isinstance(base_val, list):
            result[key] = _merge_lists(base_val, override_val)
        else:
            result[key] = override_val
    return result


class WorkflowEngine:

    def __init__(self, yaml_path: str, configs: dict, mfa_config: Optional[MFAConfig] = None):
        self.yaml_path = yaml_path
        self.configs = configs or {}
        logger.info(f"Loading workflow from: {yaml_path}")

        try:
            # Initialize config from file
            with open(yaml_path, 'r') as f:
                self.config: dict = yaml.safe_load(f)

            logger.info("Validating workflow configuration")
            validate_workflow(self.config, mfa_config=mfa_config or MFAConfig())

            # Apply runtime overrides
            yaml_overrides = {k: v for k, v in self.configs.items() if k in _YAML_SCHEMA_KEYS}
            if yaml_overrides:
                self.config = _deep_merge_config(self.config, yaml_overrides)
                override_summary = json.dumps(yaml_overrides, indent=2, default=str)
                logger.info(f"Applied runtime config overrides:\n{override_summary}")
                logger.info("Validating merged config after runtime overrides")
                validate_workflow(self.config, mfa_config=mfa_config or MFAConfig())

            self.localization_manager = self.get_localization_manager()
            self.workflow_name = self.config['name']
            self.workflow_description = self.config['description']
            self.workflow_version = self.config['version']
            self.mfa_validator_steps: set[str] = set()
            self.steps: list = self.load_steps()
            self.step_map = {step['id']: step for step in self.steps}
            self.guardrail_registry = self._build_guardrail_registry()
            self.humanizer_guardrails = self._resolve_humanizer_guardrails()
            self.mfa_config = (mfa_config or MFAConfig())
            self.data_fields = self.load_data()
            self.outcomes = self.load_outcomes()
            self.metadata = self.config.get('metadata', {})
            self.failure_message: Optional[str] = self.config.get('failure_message')

            self.StateType = create_state_model(self.data_fields)

            self.outcome_map = {outcome['id']: outcome for outcome in self.outcomes}

            self.follow_up_config: Dict[str, Any] = self.config.get('follow_up', {})
            self.follow_up_enabled: bool = self.follow_up_config.get('enabled', False)
            self.follow_up_node_id = self._build_follow_up_node_id()

            self.function_repository = FunctionRepository()
            self.tool_repository = None
            if tool_config := self.config.get("tool_config"):
                self.tool_repository = ToolRepository(tool_config)

            self.context_store = {}
            self.collect_input_fields = self._get_collect_input_fields()

            logger.info(
                f"Workflow loaded: {self.workflow_name} v{self.workflow_version} "
                f"({len(self.steps)} steps, {len(self.outcomes)} outcomes, "
                f"{len(self.collector_node_field_map)} collector nodes)"
            )

        except Exception as e:
            raise e

    def get_config_value(self, key, default_value: Optional[Any]=None):
        if value := self.configs.get(key) :
            return value

        if value := self.config.get(key) :
            return value

        return default_value

    def _build_guardrail_registry(self) -> Dict[str, Any]:
        """Build a registry of guardrail instances from top-level YAML config.

        Reads the top-level ``guardrails`` list, where each entry uses ``action``
        as both the reference name and the factory type (e.g. ``thought_action_check``).
        Steps reference guardrails by their action name in ``agent.guardrails``.
        """
        registry: Dict[str, Any] = {}
        failure_message = self.config.get('failure_message')
        for guardrail_config in self.config.get('guardrails', []):
            action = guardrail_config.get('action')
            if not action:
                logger.warning(f"Guardrail config missing 'action' key, skipping: {guardrail_config}")
                continue
            factory_config = {k: v for k, v in guardrail_config.items() if k != 'action'}
            factory_config['type'] = action
            factory_config['is_enabled'] = factory_config.pop('enabled', True)
            # Precedence: guardrail error_message > YAML failure_message > GuardrailFactory default
            if failure_message and 'error_message' not in factory_config:
                factory_config['error_message'] = failure_message
            # Merge bedrock_config from WorkflowTool config (YAML takes precedence)
            if action == "grounding_check":
                bedrock_config = self.configs.get("bedrock_config", {})
                if bedrock_config.get("guardrail_id") and "bedrock_guardrail_id" not in factory_config:
                    factory_config["bedrock_guardrail_id"] = bedrock_config["guardrail_id"]
                if bedrock_config.get("version") and "bedrock_guardrail_version" not in factory_config:
                    factory_config["bedrock_guardrail_version"] = bedrock_config["version"]
            try:
                instance = GuardrailFactory.create(factory_config)
                registry[action] = instance
                logger.info(f"Registered guardrail '{action}'")
            except ValueError as exc:
                logger.warning(f"Failed to create guardrail '{action}': {exc}")
        return registry

    def _resolve_humanizer_guardrails(self) -> list:
        """Resolve guardrail instances for the humanizer from the workflow registry."""
        humanization_config = self._get_humanization_config()
        guardrail_names = humanization_config.get(HumanizationKeys.GUARDRAILS, [])
        guardrails = [
            self.guardrail_registry[name] for name in guardrail_names
            if name in self.guardrail_registry
        ]
        if guardrails:
            logger.info(f"Humanizer: loaded {len(guardrails)} guardrail(s)")
        return guardrails

    def _build_follow_up_node_id(self) -> str:
        """Return a safe LangGraph node ID for the follow-up node."""
        base_name = self.follow_up_config.get('name') or self.workflow_name
        return re.sub(r'[^a-zA-Z0-9]', '_', base_name).lower() + '_follow_up'

    def filter_initial_context(
        self, initial_context: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Return initial_context with all collector-node fields stripped out.

        On workflow resume, initial_context must not override fields that are
        owned by collector nodes — those are collected interactively. This
        method is the single source of truth for that filtering logic and is
        shared by WorkflowTool and WorkflowStreamer.
        """
        if not initial_context:
            return {}

        collector_fields: set = set()
        for field_or_fields in self.collector_node_field_map.values():
            if isinstance(field_or_fields, list):
                collector_fields.update(field_or_fields)
            else:
                collector_fields.add(field_or_fields)

        filtered = {k: v for k, v in initial_context.items() if k not in collector_fields}

        excluded = set(initial_context.keys()) & collector_fields
        if excluded:
            logger.info(f"filter_initial_context: excluded collector fields {excluded}")

        return filtered

    def _get_collect_input_fields(self) -> set:
        fields = set()
        for step in self.steps:
            if step.get('action') == 'collect_input_with_agent':
                if field := step.get('field'):
                    fields.add(field)
                if field_list := step.get('fields'):
                    fields.update(field_list)
        return fields

    def update_context(self, context: Dict[str, Any]):
        self.context_store.update(context)
        logger.info(f"Context updated: {context}")

    def remove_context_field(self, field_name: str):
        if field_name in self.context_store:
            del self.context_store[field_name]
            logger.info(f"Removed context field: {field_name}")
    
    def get_context_value(self, field_name: str):
        value = self.context_store.get(field_name, None)
        if value is not None:
            logger.info(f"Retrieved context value for '{field_name}': {value}")
        return value

    def build_graph(self, checkpointer=None):
        logger.info("Building workflow graph")

        try:
            builder = StateGraph(self.StateType)

            collector_nodes = []

            logger.info("Adding nodes to graph")
            for step in self.steps:
                step_id = step['id']
                action = step['action']

                if action == 'collect_input_with_agent':
                    collector_nodes.append(step_id)

                node_fn = NodeFactory.create(step, engine_context=self)
                builder.add_node(step_id, node_fn)

                logger.info(f"Added node: {step_id} (action: {action})")

            first_step_id = self.steps[0]['id']
            builder.add_edge(START, first_step_id)
            logger.info(f"Set entry point: {first_step_id}")

            logger.info("Adding routing edges")
            for step in self.steps:
                step_id = step['id']

                router = WorkflowRouter(step, self.step_map, self.outcome_map)
                route_fn = router.create_route_function()
                routing_map = router.get_routing_map(collector_nodes)

                builder.add_conditional_edges(step_id, route_fn, routing_map)

                logger.info(
                    f"Added routing for {step_id}: {len(routing_map)} destinations"
                )

            self._add_outcome_nodes(builder)

            if self.follow_up_enabled:
                self._add_follow_up_node(builder, first_step_id)

            if checkpointer is None:
                checkpointer = InMemorySaver()
                logger.info("Using InMemorySaver for state persistence")
            else:
                logger.info(f"Using custom checkpointer: {type(checkpointer).__name__}")

            graph = builder.compile(checkpointer=checkpointer)

            logger.info("Workflow graph built successfully")
            return graph

        except Exception as e:
            raise RuntimeError(f"Failed to build workflow graph: {e}")

    def _add_outcome_nodes(self, builder: StateGraph) -> None:
        from ..nodes.outcome import OutcomeNode
        from langgraph.constants import END

        # Default outcome node
        outcomes_to_add = list(self.outcomes)
        if WorkflowKeys.ERROR not in self.outcome_map:
            logger.info(f"Adding default error outcome node '{WorkflowKeys.ERROR}'")
            default_error_outcome = {
                'id': WorkflowKeys.ERROR,
                'type': 'failure',
                'follow_up': self.follow_up_enabled
            }
            outcomes_to_add.append(default_error_outcome)

            self.outcome_map[WorkflowKeys.ERROR] = default_error_outcome

        for outcome in outcomes_to_add:
            outcome_id = outcome['id']
            follow_up_enabled_for_outcome = self.follow_up_enabled and outcome.get('follow_up', True)
            outcome_node = OutcomeNode(
                outcome_id=outcome_id,
                engine_context=self,
                follow_up_enabled=follow_up_enabled_for_outcome,
            )
            builder.add_node(outcome_id, outcome_node.get_node_function())

            dest = self.follow_up_node_id if follow_up_enabled_for_outcome else END
            router = WorkflowRouter(
                step_config={'id': outcome_id, 'action': 'outcome', 'next': dest},
                step_map=self.step_map,
                outcome_map=self.outcome_map,
            )
            route_fn = router.create_route_function()
            # Provide routing map manually: follow_up_node_id is not in step_map/outcome_map
            # so get_routing_map() would map it to END, which is wrong.
            builder.add_conditional_edges(outcome_id, route_fn, {dest: dest})
            logger.info(f"Added outcome node '{outcome_id}' -> '{dest}'")

    def _add_follow_up_node(self, builder: StateGraph, first_step_id: str) -> None:
        from ..nodes.follow_up import FollowUpStrategy

        follow_up_node = FollowUpStrategy(
            follow_up_config=self.follow_up_config,
            engine_context=self,
            first_step_id=first_step_id,
            node_id=self.follow_up_node_id,
        )
        builder.add_node(self.follow_up_node_id, follow_up_node.get_node_function())

        router = WorkflowRouter(
            step_config={'id': self.follow_up_node_id, 'action': 'follow_up'},
            step_map=self.step_map,
            outcome_map=self.outcome_map,
            restart_step=first_step_id,
        )
        excluded_nodes = self.follow_up_config.get('excluded_nodes', [])
        collector_nodes = [s['id'] for s in self.steps if s['id'] not in excluded_nodes]
        route_fn = router.create_route_function()
        routing_map = router.get_routing_map(collector_nodes)
        builder.add_conditional_edges(self.follow_up_node_id, route_fn, routing_map)
        logger.info(f"Added follow-up node '{self.follow_up_node_id}' with {len(routing_map)} routing destinations")

    def _aggregate_conversation_history(self, state: Dict[str, Any]) -> List[Dict[str, str]]:
        """Aggregate all conversations from collector nodes in execution order."""
        conversations = state.get(WorkflowKeys.CONVERSATIONS, {})
        node_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
        node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})

        aggregated = []
        for node_id in node_order:
            field = node_field_map.get(node_id)
            if field:
                primary = field[0] if isinstance(field, list) else field
                conv_key = f"{primary}_conversation"
                if conv_messages := conversations.get(conv_key):
                    aggregated.extend(conv_messages)

        return aggregated

    def _get_humanization_config(self) -> Dict[str, Any]:
        """Get humanization agent configuration from workflow config."""
        return self.config.get('humanization_agent', {})

    def _should_humanize_outcome(self, outcome: Dict[str, Any]) -> bool:
        """Determine if an outcome should be humanized."""
        # Check workflow-level setting (default: enabled)
        workflow_humanization = self._get_humanization_config()
        workflow_enabled = workflow_humanization.get(
            HumanizationKeys.ENABLED,
            DEFAULT_HUMANIZATION_ENABLED
        )

        if not workflow_enabled:
            return False

        # Check per-outcome setting (default: True, inherit from workflow)
        return outcome.get('humanize', True)

    def _get_humanization_model_config(self) -> Optional[Dict[str, Any]]:
        """Get model config for humanization, with overrides applied."""
        model_config = self.get_config_value('model_config')
        if not model_config:
            return None

        humanization_config = self._get_humanization_config()
        model_config = model_config.copy()  # Don't mutate original

        # Apply overrides from humanization_agent config
        if model := humanization_config.get(HumanizationKeys.MODEL):
            model_config['model_name'] = model
        if base_url := humanization_config.get(HumanizationKeys.BASE_URL):
            model_config['base_url'] = base_url

        return model_config

    def _get_localization_config(self) -> Dict[str, Any]:
        """Get localization configuration from workflow config."""
        return self.config.get('localization', {})

    def get_localization_manager(self) -> LocalizationManager:
        """Initialize LocalizationManager with rules from current config."""
        localization_config = self._get_localization_config()
        custom_rules_data = localization_config.get('rules', [])
        custom_localization_rules = []
        for rule_data in custom_rules_data:
            custom_localization_rules.append(LocalizationRule(
                language=rule_data['language'],
                script=rule_data['script'],
                instructions=rule_data.get('instructions', ''),
                examples=rule_data.get('examples', ''),
                wait_phrases=rule_data.get('wait_phrases', [])
            ))
        return LocalizationManager(custom_rules=custom_localization_rules)

    def _resolve_localization_params(self, state: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
        """Resolve language and script from state or YAML config."""
        language = state.get(WorkflowKeys.TARGET_LANGUAGE)
        script = state.get(WorkflowKeys.TARGET_SCRIPT)

        # Fall back to YAML defaults
        yaml_config = self._get_localization_config()
        if not language:
            language = yaml_config.get(LocalizationKeys.LANGUAGE)
        if not script:
            script = yaml_config.get(LocalizationKeys.SCRIPT)
            
        return language, script

    def get_base_localization_instructions(self, state: Dict[str, Any]) -> str:
        """Get the base localization requirement and generic custom instructions.
        
        Composed of:
        1. Language/script requirement (e.g. "MUST respond in Hindi")
        2. Generic localization instructions from YAML (not language-specific)
        """
        language, script = self._resolve_localization_params(state)
        base_instructions = self.localization_manager.get_base_instructions(language, script)

        yaml_config = self._get_localization_config()
        custom_instructions = yaml_config.get(LocalizationKeys.INSTRUCTIONS)

        instruction_parts = []
        if base_instructions:
            instruction_parts.append(base_instructions)
        if custom_instructions:
            instruction_parts.append(custom_instructions)

        return "\n".join(instruction_parts)

    def get_localization_instructions(self, state: Dict[str, Any]) -> str:
        """Get the full localization instructions for agent prompts.

        Combines base instructions, generic custom instructions, and language/script specific rules.
        """
        language, script = self._resolve_localization_params(state)
        
        composed_base_instructions = self.get_base_localization_instructions(state)
        specific_guidelines = self.localization_manager.get_specific_instructions(language, script)
        
        instruction_parts = [composed_base_instructions]
        if specific_guidelines:
            instruction_parts.append(specific_guidelines)

        return "\n".join([part for part in instruction_parts if part])

    def get_localization_wait_phrases(self, state: Dict[str, Any]) -> List[str]:
        """Get wait/pause phrases based on the target language/script.

        Used to customize intent detection logic in collector nodes.
        """
        language, script = self._resolve_localization_params(state)
        return self.localization_manager.get_wait_phrases(language, script)

    def get_localization_rule(self, state: Dict[str, Any]) -> LocalizationRule:
        """Utility method to get the full LocalizationRule from engine context."""
        language, script = self._resolve_localization_params(state)
        return self.localization_manager.get_rule(language, script)

    def _humanize_message(
        self,
        reference_message: str,
        state: Dict[str, Any],
        options: Optional[List[Dict[str, Any]]] = None,
        is_selectable: Optional[bool] = None
    ) -> MessagePayload:
        """Use LLM to humanize the reference message using conversation context.

        Args:
            reference_message: Message to humanize
            state: Current workflow state
            options: Optional list of options
            is_selectable: Whether options are selectable

        Returns:
            MessagePayload containing the humanized message with optional options
        """
        try:
            model_config = self._get_humanization_model_config()
            if not model_config:
                logger.warning("No model_config found, skipping humanization")
                return MessagePayload(reference_message, options, is_selectable or False)

            humanization_config = self._get_humanization_config()

            # Build system prompt (without reference message)
            custom_instructions = humanization_config.get(HumanizationKeys.INSTRUCTIONS)
            if custom_instructions:
                system_prompt = custom_instructions
            else:
                system_prompt = DEFAULT_HUMANIZATION_SYSTEM_PROMPT

            # Always append OPTIONS guidance (works with both default and custom prompts)
            option_char_limit_enabled = humanization_config.get(
                HumanizationKeys.OPTION_CHAR_LIMIT, DEFAULT_OPTION_CHAR_LIMIT_ENABLED
            )
            max_chars = MAX_OPTION_TEXT_LENGTH if option_char_limit_enabled else None
            system_prompt += build_humanization_options_guidance(max_chars=max_chars)

            # Always append URL preservation examples (works with both default and custom prompts)
            system_prompt += HUMANIZATION_URL_PRESERVATION_EXAMPLES

            # Inject localization instructions if specified
            localization_instructions = self.get_localization_instructions(state)
            if localization_instructions:
                system_prompt = f"{localization_instructions}\n\n{system_prompt}"

            # Inject current date at the very end to preserve prefix caching
            system_prompt += f"\n\nCurrent date: {date.today().isoformat()}"

            # Aggregate conversation history and embed it into the system prompt so the
            # agent receives a single, clean user turn (the draft to humanize). This avoids
            # consecutive same-role messages, which cause silent merges on Anthropic and hard
            # errors on AWS Bedrock, and also avoids synthetic assistant prefilling which is
            # deprecated on Claude Sonnet 4.5+ / Opus 4.6+.
            conversation_history = self._aggregate_conversation_history(state)
            if conversation_history:
                history_text = "\n".join(
                    f"[{'Human' if m['role'] == 'user' else 'Assistant'}]: {m['content']}"
                    for m in conversation_history
                )
                system_prompt += f"\n\n<conversation_history>\n{history_text}\n</conversation_history>"

            user_query = (
                f"Humanize the following draft response. "
                f"Use the conversation history in your instructions for tone only — do NOT add, remove, or alter any content.\n\n"
                f"<draft>\n{reference_message}\n</draft>"
            )

            # Add options information if provided
            if options:
                user_query += f"\n\nSelectable options: {options}"
                user_query += f"\nMust select from options: {is_selectable}"
                user_query += f"\n\nReturn these options in your structured response with the same is_selectable value. Do NOT add or remove options. If any option text exceeds {MAX_OPTION_TEXT_LENGTH} characters, shorten it to fit while keeping the meaning clear. Use 'compute' tool to determine the character length"
            else:
                user_query += "\n\nOnly include options if the reference message contains a single question with explicit choices. If multiple questions are present, return options as an empty list."

            # Single clean user turn — no role-alternation issues across any provider
            invoke_messages = [{"role": "user", "content": user_query}]

            # Determine retry budget from humanizer guardrails
            max_retries = max((g.max_retries for g in self.humanizer_guardrails), default=0) if self.humanizer_guardrails else 0

            framework = self.get_config_value('agent_framework', 'langgraph')
            agent = AgentFactory.create_agent(
                framework=framework,
                name="HumanizationAgent",
                model_config=model_config,
                tools=[],
                system_prompt=system_prompt,
                structured_output_model=HumanizedResponse,
                guardrails=self.humanizer_guardrails,
                max_retry_limit=max_retries,
            )

            # Provide grounding context so guardrails can validate against reference material
            if self.humanizer_guardrails:
                agent.guardrail_context = {
                    "grounding_source": self._build_humanizer_grounding_source(
                        system_prompt, conversation_history, reference_message
                    ),
                    "query": next(
                        (m['content'] for m in reversed(invoke_messages) if m['role'] == 'user'), ""
                    ),
                    "function_outputs": [],
                    "output_schema": HumanizedResponse,
                    "required_fields": ["message"],
                }

            try:
                with trace_agent_invocation(
                    agent_name="HumanizationAgent",
                    model=model_config.get('model_name', 'unknown'),
                    structured_output=True
                ) as span:
                    humanized_response: HumanizedResponse = agent.invoke(invoke_messages)

                    if span and span.is_recording():
                        span.set_attribute("input.value", str(reference_message))
                        span.set_attribute("humanization.input_length", len(reference_message))
                        span.set_attribute("humanization.structured_output", True)

            except GuardrailViolationError:
                logger.warning("Humanizer guardrail failed after all retries, using original message")
                return MessagePayload(reference_message, options, is_selectable or False)

            if isinstance(humanized_response, dict):
                humanized_message = humanized_response.get("message")
                raw_options = humanized_response.get("options")
                humanized_is_selectable = humanized_response.get("is_selectable")
            else:
                humanized_message = humanized_response.message
                raw_options = humanized_response.options
                humanized_is_selectable = humanized_response.is_selectable
            humanized_options = [opt.model_dump() if hasattr(opt, 'model_dump') else opt for opt in raw_options] if raw_options is not None else options
            if humanized_is_selectable is None:
                humanized_is_selectable = is_selectable

            # Validate we got a meaningful response
            if not humanized_message or humanized_message.strip() == '':
                logger.warning("Humanization returned empty response, using original message")
                return MessagePayload(reference_message, options, is_selectable or False)

            logger.info(f"Message humanized successfully: {humanized_message[:100]}...")
            return MessagePayload(humanized_message, humanized_options, humanized_is_selectable or False)

        except Exception as e:
            logger.exception(f"Humanization failed, using original message: {e}")
            return MessagePayload(reference_message, options, is_selectable or False)

    def _check_humanizer_guardrails(
        self,
        humanized_message: str,
        system_prompt: str,
        conversation_history: Optional[List[Dict[str, str]]],
        reference_message: str,
        state: Dict[str, Any],
    ) -> bool:
        """Run guardrails on humanized output. Returns True if all pass."""
        grounding_source = self._build_humanizer_grounding_source(
            system_prompt, conversation_history, reference_message
        )
        # Use last user message from conversation history as query
        query = ""
        if conversation_history:
            query = next(
                (msg['content'] for msg in reversed(conversation_history) if msg['role'] == 'user'),
                ""
            )

        for guardrail in self.humanizer_guardrails:
            try:
                result = guardrail.check(
                    humanized_message,
                    grounding_source=grounding_source,
                    query=query,
                )
                if not result.passed:
                    logger.warning(f"Humanizer guardrail failed: {result.error_message}")
                    return False
            except GuardrailsConnectionError as e:
                logger.warning(f"Humanizer guardrail connection error (fail-open): {e}")
        return True

    def _build_humanizer_grounding_source(
        self,
        system_prompt: str,
        conversation_history: Optional[List[Dict[str, str]]],
        reference_message: str,
    ) -> str:
        """Assemble grounding source for humanizer validation."""
        parts = [f"HUMANIZATION INSTRUCTIONS:\n{system_prompt}"]

        if conversation_history:
            history_text = "\n".join(
                f"{msg['role'].upper()}: {msg['content']}" for msg in conversation_history
            )
            parts.append(f"CONVERSATION HISTORY:\n{history_text}")

        parts.append(f"REFERENCE MESSAGE:\n{reference_message}")

        return "\n\n".join(parts)

    def get_outcome_message(self, state: Dict[str, Any]) -> MessagePayload:
        """Get outcome message with options support.

        Returns:
            MessagePayload containing the outcome message with optional options
        """
        outcome_id = state.get(WorkflowKeys.OUTCOME_ID)
        step_id = state.get(WorkflowKeys.STEP_ID)

        outcome = self.outcome_map.get(outcome_id)
        if outcome and 'message' in outcome:
            outcome_type = outcome.get('type')
            message = outcome['message']
            template_loader: Environment = self.get_config_value("template_loader", Environment())
            rendered_message = template_loader.from_string(message).render(state)           
            # Apply humanization if enabled for this outcome
            message = MessagePayload(rendered_message)
            if self._should_humanize_outcome(outcome):
                result = self._humanize_message(rendered_message, state)
                message.message = result.message
                message.options = result.options
                message.is_selectable = result.is_selectable

            # Handle redirect outcome type
            if outcome_type == 'redirect':
                redirect_to = outcome.get('redirect_to', '')
                rendered_redirect_to = template_loader.from_string(redirect_to).render(state)
                # Return redirect format: __REDIRECT__|thread_id|workflow_name|redirect_to|message
                thread_id = state.get(WorkflowKeys.THREAD_ID, "")
                workflow_name = state.get(WorkflowKeys.WORKFLOW_NAME, "")
                logger.info(f"Redirect outcome in step {step_id} to {rendered_redirect_to}")
                message.message = f"{OutcomePrefix.REDIRECT}|{thread_id}|{workflow_name}|{rendered_redirect_to}|{message.message}"

            logger.info(f"Outcome message generated in step {step_id}: {(message.message, message.options, message.is_selectable)}")
            return message

        if error := state.get("error"):
            logger.info(f"Outcome error found in step {step_id}: {error}")
            # Apply humanization to error message if enabled at workflow level
            humanization_config = self._get_humanization_config()
            if humanization_config.get(HumanizationKeys.ENABLED, DEFAULT_HUMANIZATION_ENABLED):
                return self._humanize_message(error, state)
            return MessagePayload(f"{error}")

        if message := state.get(WorkflowKeys.MESSAGES):
            logger.info(f"Outcome message found in step {step_id}: {message}")
            text = "\n".join(message) if isinstance(message, list) else str(message)
            return MessagePayload(text)

        logger.error(f"No outcome message found in step {step_id}")
        return MessagePayload("{'error': 'Unable to complete the request'}")


    def get_model_config(self, agent_config: Dict[str, Any]) -> Dict[str, Any]:
        """Return the effective model config, applying any per-agent overrides.

        Reads the base model_config from engine context and applies model, base_url,
        and api_key overrides from the given agent config dict when present.
        """
        model_config = self.get_config_value('model_config')
        if not model_config:
            raise ValueError("model_config not found in engine context")

        overrides = {
            k: v for k, v in {
                'model_name': agent_config.get('model'),
                'base_url': agent_config.get('base_url'),
                'api_key': agent_config.get('api_key'),
            }.items() if v
        }
        if overrides:
            model_config = {**model_config, **overrides}
        return model_config

    def reset_workflow_state(self, state: Dict[str, Any]) -> None:
        """Reset all workflow state in-place, clearing collected data and tracking fields.

        Clears all data fields, follow-up state, and workflow tracking keys.
        Used by the follow-up node on restart to wipe everything before routing
        back to the first step.
        """
        # Collector-owned fields are cleared from both state and context_store.
        # Non-collector fields (initial context) stay in context_store so they can be
        # re-applied to state after the reset.
        collector_fields: set = set()
        for field_or_fields in self.collector_node_field_map.values():
            if isinstance(field_or_fields, list):
                collector_fields.update(field_or_fields)
            else:
                collector_fields.add(field_or_fields)

        for field in self.data_fields:
            name = field['name']
            state[name] = None
            if name in collector_fields:
                self.remove_context_field(name)

        state[WorkflowKeys.OUTCOME_ID] = None
        state[WorkflowKeys.FOLLOW_UP_ACTIVE] = None
        state[WorkflowKeys.FOLLOW_UP_ATTEMPTS] = None
        state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = None
        state[WorkflowKeys.NODE_EXECUTION_ORDER] = []
        state[WorkflowKeys.ATTEMPT_COUNTS] = {}
        state[WorkflowKeys.PARTIAL_DATA] = {}
        state[WorkflowKeys.NODE_FIELD_MAP] = {}
        state[WorkflowKeys.MESSAGES] = []
        state[WorkflowKeys.CONVERSATIONS] = {}
        state[WorkflowKeys.STATE_HISTORY] = []
        state[WorkflowKeys.COLLECTOR_NODES] = {}

        # Re-apply initial context fields (non-collector) from context_store into state.
        data_field_names = {f['name'] for f in self.data_fields}
        for key, val in self.context_store.items():
            if key in data_field_names:
                state[key] = val

    def get_step_info(self, step_id: str) -> Optional[Dict[str, Any]]:
        return self.step_map.get(step_id)

    def get_outcome_info(self, outcome_id: str) -> Optional[Dict[str, Any]]:
        return self.outcome_map.get(outcome_id)

    def list_steps(self) -> list:
        return [step['id'] for step in self.steps]

    def list_outcomes(self) -> list:
        return [outcome['id'] for outcome in self.outcomes]

    def get_workflow_info(self) -> Dict[str, Any]:
        return {
            'name': self.workflow_name,
            'description': self.workflow_description,
            'version': self.workflow_version,
            'steps': len(self.steps),
            'outcomes': len(self.outcomes),
            'data_fields': [f['name'] for f in self.data_fields],
            'metadata': self.metadata
        }

    def build_field_details(self, state: Dict[str, Any], node_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Build a snapshot of collector node fields with values and validation errors.

        Args:
            state: Current workflow state
            node_id: Optional specific node ID. If not provided, uses current node from state STATUS.

        Returns:
            List of dicts for the fields belonging to the collector node:
            [{"name": "email", "value": "bad@", "label": "Email Address", "error": "Invalid email format"}, ...]

            For fields that failed validation, the value is the one that failed (not None).
            The label field is optional and included only if present in the field definition.

            For dict fields with structured output, the value is a list of sub-field objects
            with name, label, and value.
        """
        # Get fields from specified node or current node from state
        if node_id:
            field_or_fields = self.collector_node_field_map.get(node_id)
            if not field_or_fields:
                return []

            if isinstance(field_or_fields, str):
                current_fields = [field_or_fields]
            else:
                current_fields = field_or_fields
        else:
            current_fields = self._get_current_node_fields(state)
            if current_fields is None:
                return []

        # Build field details
        data_field_map = {f['name']: f for f in self.data_fields}
        validation_errors = state.get(WorkflowKeys.VALIDATION_ERRORS, {})
        field_details = []

        for name in current_fields:
            field_def = data_field_map.get(name)
            if not field_def:
                continue

            field_value = state.get(name)
            entry = {"name": name}

            if label := field_def.get('label'):
                entry["label"] = label

            structured_fields = self._get_structured_output_fields(name, state, node_id=node_id)

            if structured_fields is not None and len(structured_fields) > 0:
                structured_value = []

                for struct_field in structured_fields:
                    struct_name = struct_field.get('name')

                    if struct_name in COLLECT_INPUT_METADATA_FIELDS:
                        continue

                    field_obj = {"name": struct_name}

                    if struct_label := struct_field.get('label'):
                        field_obj["label"] = struct_label

                    # Use helper method to retrieve partial field value with backward compatibility
                    val = self._get_partial_field_value(state, name, struct_name)

                    field_obj["value"] = val

                    structured_value.append(field_obj)

                if structured_value:
                    entry["value"] = structured_value
                elif name in validation_errors:
                    entry["value"] = validation_errors[name]["value"]
                    entry["error"] = validation_errors[name]["error"]
                else:
                    entry["value"] = field_value

                field_details.append(entry)
                continue

            if name in validation_errors:
                entry["value"] = validation_errors[name]["value"]
                entry["error"] = validation_errors[name]["error"]
            else:
                entry["value"] = field_value

            field_details.append(entry)

        return field_details

    def _get_structured_output_fields(self, field_name: str, state: Dict[str, Any], node_id: Optional[str] = None) -> Optional[List[Dict[str, Any]]]:
        """Get structured output field definitions for a given field if they exist.
        
        Args:
            field_name: Name of the field to check
            state: Current state (used if node_id not provided)
            node_id: Optional node ID to check directly (bypasses STATUS lookup)
        """

        if node_id:
            current_node_id = node_id
        else:
            status = state.get(WorkflowKeys.STATUS, "")
            current_node_id = None
            
            for collector_node_id in self.collector_node_field_map:
                if status.startswith(f"{collector_node_id}_"):
                    current_node_id = collector_node_id
                    break
        
        if not current_node_id:
            return None
        
        step_config = self.step_map.get(current_node_id)
        if not step_config:
            return None
        
        agent_config = step_config.get('agent', {})
        structured_output_config = agent_config.get('structured_output', {})
        
        if not structured_output_config.get('enabled'):
            return None
        
        return structured_output_config.get('fields', [])

    def _get_current_node_fields(self, state: Dict[str, Any]) -> Optional[List[str]]:
        """Determine which fields belong to the currently active collector node."""
        status = state.get(WorkflowKeys.STATUS, "")
        for node_id, fields in self.collector_node_field_map.items():
            if status.startswith(f"{node_id}_"):
                if isinstance(fields, list):
                    return fields
                return [fields]
        return None

    def _store_partial_data(
        self,
        state: Dict[str, Any],
        primary_field: str,
        field_values: Dict[str, Any] | None
    ) -> None:
        """Store partial data in nested dict format."""
        if WorkflowKeys.PARTIAL_DATA not in state:
            state[WorkflowKeys.PARTIAL_DATA] = {}

        if primary_field not in state[WorkflowKeys.PARTIAL_DATA]:
            state[WorkflowKeys.PARTIAL_DATA][primary_field] = {}
        
        if field_values:
            state[WorkflowKeys.PARTIAL_DATA][primary_field].update(field_values)
        else:
            state[WorkflowKeys.PARTIAL_DATA][primary_field] = {}

    def _get_partial_field_value(
        self,
        state: Dict[str, Any],
        primary_field: str,
        sub_field: str
    ) -> Any:
        """Retrieve sub-field value with fallback for backward compatibility.

        Tries multiple sources in order:
        1. New nested format: _partial_data[primary_field][sub_field]
        2. Old flat format: _partial_data[f"{primary_field}_{sub_field}"]
        3. Direct state: state[sub_field]
        4. Dict container: state[primary_field][sub_field]

        Args:
            state: The workflow state dictionary
            primary_field: The primary field name (e.g., 'user_info')
            sub_field: The sub-field name (e.g., 'name')

        Returns:
            The field value if found, None otherwise
        """
        partial_data = state.get(WorkflowKeys.PARTIAL_DATA, {})
        field_value = state.get(primary_field)

        # 1. Try new nested pattern first
        if isinstance(partial_data.get(primary_field), dict):
            val = partial_data[primary_field].get(sub_field)
            if val is not None:
                return val

        # 2. Try old flat pattern (backward compatibility)
        renamed_key = f"{primary_field}_{sub_field}"
        val = partial_data.get(renamed_key)
        if val is not None:
            return val

        # 3. Fallback to old pattern: check sub_field directly in state
        val = state.get(sub_field)
        if val is not None:
            return val

        # 4. Fallback to dict container pattern
        if isinstance(field_value, dict):
            val = field_value.get(sub_field)
            if val is not None:
                return val

        return None

    def get_tool_policy(self) -> str:
        tool_config = self.config.get('tool_config')
        if not tool_config:
            raise ValueError("Tool config is not provided in the YAML")
        return tool_config.get('usage_policy')


    def load_steps(self):
        self.collector_node_field_map: Dict[str, Any] = {}  # node_id -> field (str) or fields (List[str])

        # Build collector node -> field(s) map
        for step in self.config['steps']:
            if step.get('action') == 'collect_input_with_agent':
                node_id = step.get('id')
                if field := step.get('field'):
                    self.collector_node_field_map[node_id] = field
                elif fields := step.get('fields'):
                    self.collector_node_field_map[node_id] = fields  # Store as list


        return self.config['steps']

    def load_data(self):
        data: list = self.config['data']
        return data

    def load_outcomes(self):
        outcomes: list = self.config['outcomes']
        # MFA cancellation is handled by on_cancel redirect in MFA step config
        return outcomes


def load_workflow(yaml_path: str, checkpointer=None, config=None, mfa_config: Optional[MFAConfig] = None) -> Tuple[CompiledStateGraph, WorkflowEngine]:
    """
    Load a workflow from YAML configuration.

    This is the main entry point for using the framework.

    Args:
        yaml_path: Path to the workflow YAML file
        checkpointer: Optional checkpointer for state persistence.
                     Defaults to InMemorySaver() if not provided.
                     Example: MongoDBSaver for production persistence.
        config: Optional configuration dictionary
        mfa_config: Optional MFA configuration. If not provided, will load from environment variables.

    Returns:
        Tuple of (compiled_graph, engine) where:
        - compiled_graph: LangGraph ready for execution
        - engine: WorkflowEngine instance for introspection

    Example:
        ```python
        # Load with environment variables
        graph, engine = load_workflow("workflow.yaml")

        # Or provide MFA configuration explicitly
        from soprano_sdk.core.constants import MFAConfig
        mfa_config = MFAConfig(
            generate_token_base_url="https://api.example.com",
            generate_token_path="/v1/mfa/generate"
        )
        graph, engine = load_workflow("workflow.yaml", mfa_config=mfa_config)

        result = graph.invoke({}, config={"configurable": {"thread_id": "123"}})
        message = engine.get_outcome_message(result)
        ```
    """
    engine = WorkflowEngine(yaml_path, configs=config, mfa_config=mfa_config)
    graph = engine.build_graph(checkpointer=checkpointer)
    return graph, engine
