from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class CornerCase:
    id: str
    rule_id: str
    detection_pattern: str
    resolution: str
    affected_documents: list[str] = field(default_factory=list)
    discovery_date: str = ""
    status: str = "active"  # active | resolved | obsolete

    def __post_init__(self) -> None:
        if not self.discovery_date:
            self.discovery_date = datetime.now(timezone.utc).isoformat()


class CornerCaseRegistry:
    """Structural component: first-class data structure for edge cases.

    Corner cases (<10% failure rate) are stored here instead of patching
    main workflows. The EvolutionController routes failures here automatically.

    Persists to workspace/corner_cases.json.
    """

    def __init__(self, workspace_path: Path) -> None:
        self._path = workspace_path / "corner_cases.json"
        self._cases: list[CornerCase] = []
        self._load()

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            self._cases = [CornerCase(**entry) for entry in data]
        except (json.JSONDecodeError, TypeError, KeyError):
            self._cases = []

    def _save(self) -> None:
        self._path.write_text(
            json.dumps([asdict(c) for c in self._cases], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def add(self, case: CornerCase) -> None:
        """Add a corner case. Deduplicates by id."""
        existing = self.get(case.id)
        if existing:
            # Update in place
            idx = next(i for i, c in enumerate(self._cases) if c.id == case.id)
            self._cases[idx] = case
        else:
            self._cases.append(case)
        self._save()

    def get(self, case_id: str) -> CornerCase | None:
        return next((c for c in self._cases if c.id == case_id), None)

    def get_by_rule(self, rule_id: str) -> list[CornerCase]:
        return [c for c in self._cases if c.rule_id == rule_id and c.status == "active"]

    def all_active(self) -> list[CornerCase]:
        return [c for c in self._cases if c.status == "active"]

    def count(self) -> int:
        return len(self._cases)

    def match(self, document_name: str, rule_id: str) -> list[CornerCase]:
        """Check if a document matches any known corner case patterns for a rule."""
        matches = []
        for case in self.get_by_rule(rule_id):
            # Simple substring match on detection pattern
            if case.detection_pattern and case.detection_pattern.lower() in document_name.lower():
                matches.append(case)
        return matches
