from __future__ import annotations

import json
from pathlib import Path
from typing import Any, AsyncIterator

from openai import AsyncOpenAI

from app.config import Settings
from .context import ContextAssembler
from .events import AgentEvent
from .history import ConversationHistory
from .tools.registry import ToolRegistry
from .pipelines import Phase, PipelineEvent
from .pipelines.distillation import DistillationEngine
from .pipelines.extraction import RuleExtractionPipeline
from .pipelines.initializer import ProjectInitializer
from .pipelines.production_qc import ProductionQCPipeline
from .pipelines.skill_authoring import SkillAuthoringPipeline
from .pipelines.skill_testing import SkillTestingPipeline
from .confidence_scorer import ConfidenceScorer
from .corner_case_registry import CornerCaseRegistry
from .tools.agent_tool import AgentTool
from .tools.dashboard_render import DashboardRenderTool
from .tools.document_parse import DocumentParseTool
from .tools.document_search import DocumentSearchTool
from .tools.evolution_cycle import EvolutionCycleTool
from .tools.qc_sample import QCSampleTool
from .tools.rule_catalog import RuleCatalogTool
from .tools.sandbox_exec import SandboxExecTool
from .tools.tier_downgrade import TierDowngradeTool
from .tools.worker_llm_call import WorkerLLMCallTool
from .tools.workflow_run import WorkflowRunTool
from .tools.workspace_file import WorkspaceFileTool
from .version_manager import VersionManager
from .workspace import Workspace


class AgentEngine:
    """The KC Agent conversation engine.

    Core loop: user message -> context assembly -> LLM API (streaming) ->
    tool execution (if any) -> repeat until no tool calls -> turn complete.

    Uses OpenAI-compatible API (SiliconFlow) for the conductor LLM.
    Yields AgentEvent objects. Transport-agnostic.
    """

    def __init__(self, client: AsyncOpenAI, config: Settings, session_id: str | None = None) -> None:
        self.client = client
        self.config = config
        self.context = ContextAssembler()
        self.tool_registry = ToolRegistry()

        # Workspace + structural components
        self._workspace_root = Path(config.kc_workspace_root).expanduser()
        self.workspace = Workspace(root=self._workspace_root, session_id=session_id)
        self.history = ConversationHistory(workspace_path=self.workspace.cwd)
        self.version_manager = VersionManager(self.workspace.cwd)
        self.corner_cases = CornerCaseRegistry(self.workspace.cwd)
        self.confidence = ConfidenceScorer(self.workspace.cwd, corner_cases=self.corner_cases)

        # Tools
        self.tool_registry.register(SandboxExecTool(self.workspace, timeout=config.kc_exec_timeout))
        self.tool_registry.register(WorkspaceFileTool(self.workspace, version_manager=self.version_manager))
        self.tool_registry.register(DocumentParseTool(
            self.workspace,
            mineru_api_url=config.mineru_api_url,
            mineru_api_key=config.mineru_api_key,
            siliconflow_api_key=config.siliconflow_api_key,
            siliconflow_base_url=config.siliconflow_base_url,
            ocr_model_tier1=config.ocr_model_tier1,
        ))
        worker_llm = WorkerLLMCallTool(
            self.workspace,
            api_key=config.siliconflow_api_key,
            base_url=config.siliconflow_base_url,
        )
        self.tool_registry.register(worker_llm)
        self.tool_registry.register(WorkflowRunTool(
            self.workspace, self.version_manager, self.confidence, timeout=config.kc_exec_timeout,
        ))
        self.tool_registry.register(TierDowngradeTool(self.workspace, worker_llm))
        self.tool_registry.register(EvolutionCycleTool(self.workspace, self.corner_cases))
        self.tool_registry.register(DocumentSearchTool(self.workspace))
        self.tool_registry.register(RuleCatalogTool(self.workspace))
        self.tool_registry.register(QCSampleTool(self.workspace))
        self.tool_registry.register(DashboardRenderTool(self.workspace))
        self.tool_registry.register(AgentTool(
            self.workspace,
            engine_factory=lambda sid: AgentEngine(self.client, self.config, session_id=sid),
        ))

        # Pipeline system (meta-meta skills as code)
        self.current_phase = Phase.BOOTSTRAP
        self.pipelines = {
            Phase.BOOTSTRAP: ProjectInitializer(self.workspace),
            Phase.EXTRACTION: RuleExtractionPipeline(self.workspace),
            Phase.SKILL_AUTHORING: SkillAuthoringPipeline(self.workspace),
            Phase.SKILL_TESTING: SkillTestingPipeline(self.workspace),
            Phase.DISTILLATION: DistillationEngine(self.workspace),
            Phase.PRODUCTION_QC: ProductionQCPipeline(self.workspace),
        }

    async def run_turn(self, user_message: str) -> AsyncIterator[AgentEvent]:
        self.history.add_user(user_message)

        # Pipeline Injector: get current pipeline state for context
        pipeline = self.pipelines.get(self.current_phase)
        pipeline_state = pipeline.describe_state() if pipeline else None

        system_prompt = self.context.build(
            pipeline_state=pipeline_state,
            workspace_state=f"Your workspace directory is: {self.workspace.cwd}",
        )
        tools = self.tool_registry.schemas_openai()

        while True:
            messages = [{"role": "system", "content": system_prompt}] + self.history.messages

            kwargs: dict[str, Any] = {
                "model": self.config.kc_model,
                "max_tokens": self.config.kc_max_tokens,
                "messages": messages,
                "stream": True,
            }
            if tools:
                kwargs["tools"] = tools

            try:
                collected_text = ""
                tool_calls_acc: dict[int, dict[str, Any]] = {}

                stream = await self.client.chat.completions.create(**kwargs)
                async for chunk in stream:
                    delta = chunk.choices[0].delta if chunk.choices else None
                    if delta is None:
                        continue

                    # Stream text content
                    if delta.content:
                        yield AgentEvent(type="text_delta", text=delta.content)
                        collected_text += delta.content

                    # Accumulate tool calls from deltas
                    if delta.tool_calls:
                        for tc_delta in delta.tool_calls:
                            idx = tc_delta.index
                            if idx not in tool_calls_acc:
                                tool_calls_acc[idx] = {
                                    "id": tc_delta.id or "",
                                    "name": "",
                                    "arguments": "",
                                }
                            if tc_delta.id:
                                tool_calls_acc[idx]["id"] = tc_delta.id
                            if tc_delta.function:
                                if tc_delta.function.name:
                                    tool_calls_acc[idx]["name"] = tc_delta.function.name
                                if tc_delta.function.arguments:
                                    tool_calls_acc[idx]["arguments"] += tc_delta.function.arguments

            except Exception as e:
                yield AgentEvent(type="error", message=str(e))
                return

            # Build assistant message for history
            assistant_msg: dict[str, Any] = {"role": "assistant", "content": collected_text or None}
            if tool_calls_acc:
                assistant_msg["tool_calls"] = [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {"name": tc["name"], "arguments": tc["arguments"]},
                    }
                    for tc in tool_calls_acc.values()
                ]
            self.history.add_raw(assistant_msg)

            if not tool_calls_acc:
                yield AgentEvent(type="turn_complete")
                return

            # Tool execution loop
            for tc in tool_calls_acc.values():
                name = tc["name"]
                try:
                    input_data = json.loads(tc["arguments"]) if tc["arguments"] else {}
                except json.JSONDecodeError:
                    input_data = {}

                yield AgentEvent(type="tool_start", name=name, input=input_data)
                result = await self.tool_registry.execute(name, input_data)
                yield AgentEvent(
                    type="tool_result",
                    name=name,
                    output=result.content,
                    is_error=result.is_error,
                )
                # Add tool result message
                self.history.add_raw({
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": result.content,
                })

                # Pipeline Controller: update state after tool execution
                if pipeline:
                    p_event = pipeline.on_tool_result(name, input_data, result)
                    if p_event:
                        # Advance phase if pipeline signals ready
                        if p_event.type == "phase_ready" and p_event.next_phase:
                            self.current_phase = p_event.next_phase
                            pipeline = self.pipelines.get(self.current_phase)
                        yield AgentEvent(
                            type="pipeline_event",
                            data=p_event.to_dict(),
                        )

            # Loop continues -- send tool results back to LLM
