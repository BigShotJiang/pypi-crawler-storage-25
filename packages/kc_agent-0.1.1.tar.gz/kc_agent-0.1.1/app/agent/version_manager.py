from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# Directories whose files get versioned
VERSIONED_DIRS = {"workflows", "rule_skills", "rules"}
# File extensions that get versioned
VERSIONED_EXTS = {".py", ".json", ".md", ".txt"}


class VersionManager:
    """Structural component: every write to versioned directories gets tracked.

    - Immutable version copies: workflow_v1.py, workflow_v2.py, ...
    - Manifest at versions.json: tracks lineage, timestamps, change reasons
    - Trace ID generation: {timestamp}_{rule_id}_{version}
    Cannot be bypassed — hooks into WorkspaceFileTool.
    """

    def __init__(self, workspace_path: Path) -> None:
        self._workspace = workspace_path
        self._manifest_path = workspace_path / "versions.json"
        self._manifest = self._load_manifest()

    def _load_manifest(self) -> dict[str, Any]:
        if self._manifest_path.exists():
            try:
                return json.loads(self._manifest_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, KeyError):
                pass
        return {"version": "0.1.0", "entries": []}

    def _save_manifest(self) -> None:
        self._manifest_path.write_text(
            json.dumps(self._manifest, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def should_version(self, rel_path: str) -> bool:
        """Check if a path falls within versioned directories."""
        parts = Path(rel_path).parts
        if not parts:
            return False
        top_dir = parts[0]
        ext = Path(rel_path).suffix
        return top_dir in VERSIONED_DIRS and ext in VERSIONED_EXTS

    def on_write(self, rel_path: str, content: str) -> str | None:
        """Called before a file write. Returns trace ID if versioned, None otherwise.

        Does NOT create the version copy — just records in manifest.
        The actual file write is done by WorkspaceFileTool as normal.
        """
        if not self.should_version(rel_path):
            return None

        version = self._next_version(rel_path)
        now = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

        # Extract rule_id from path if possible (e.g., rule_skills/R001/SKILL.md → R001)
        parts = Path(rel_path).parts
        rule_id = parts[1] if len(parts) > 1 else "global"

        trace_id = f"{now}_{rule_id}_v{version}"

        entry = {
            "file": rel_path,
            "version": version,
            "trace_id": trace_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "rule_id": rule_id,
            "size_chars": len(content),
        }

        self._manifest["entries"].append(entry)
        self._save_manifest()

        return trace_id

    def _next_version(self, rel_path: str) -> int:
        """Get the next version number for a file path."""
        existing = [
            e["version"]
            for e in self._manifest["entries"]
            if e["file"] == rel_path
        ]
        return max(existing, default=0) + 1

    def get_versions(self, rel_path: str) -> list[dict[str, Any]]:
        """Get all version entries for a file."""
        return [e for e in self._manifest["entries"] if e["file"] == rel_path]

    def latest_version(self, rel_path: str) -> dict[str, Any] | None:
        """Get the most recent version entry for a file."""
        versions = self.get_versions(rel_path)
        return versions[-1] if versions else None

    def generate_trace_id(self, rule_id: str, label: str = "") -> str:
        """Generate a standalone trace ID for results, QC records, etc."""
        now = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        suffix = f"_{label}" if label else ""
        return f"{now}_{rule_id}{suffix}"
