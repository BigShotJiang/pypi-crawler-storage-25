from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentEvent:
    """A single event emitted by the agent engine during a turn.

    The engine yields these as an async iterator. The transport layer
    (WebSocket handler) serializes them to JSON for the client.
    """

    type: str
    # text_delta
    text: str | None = None
    # tool_start / tool_result
    name: str | None = None
    input: dict[str, Any] | None = None
    output: str | None = None
    is_error: bool = False
    # error
    message: str | None = None
    # generic payload for future event types
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self.type}
        if self.text is not None:
            d["text"] = self.text
        if self.name is not None:
            d["name"] = self.name
        if self.input is not None:
            d["input"] = self.input
        if self.output is not None:
            d["output"] = self.output
        if self.is_error:
            d["is_error"] = self.is_error
        if self.message is not None:
            d["message"] = self.message
        if self.data:
            d["data"] = self.data
        return d
