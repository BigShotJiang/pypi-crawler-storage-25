from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ConversationHistory:
    """Manages the message list for the OpenAI-compatible API.

    Persists to workspace/conversation.json on every write.
    Loads existing history when workspace_path is provided.
    """

    def __init__(self, workspace_path: Path | None = None) -> None:
        self._messages: list[dict[str, Any]] = []
        self._display_log: list[dict[str, Any]] = []
        self._workspace_path = workspace_path

        if workspace_path:
            self._load()

    @property
    def messages(self) -> list[dict[str, Any]]:
        return self._messages

    @property
    def display_log(self) -> list[dict[str, Any]]:
        """Flat list of display entries for frontend replay."""
        return self._display_log

    def add_user(self, text: str) -> None:
        self._messages.append({"role": "user", "content": text})
        self._display_log.append({"role": "user", "content": text})
        self._save()

    def add_raw(self, message: dict[str, Any]) -> None:
        """Add a pre-built message dict (assistant with tool_calls, tool results, etc.)."""
        self._messages.append(message)

        # Build display entries from raw message
        role = message.get("role", "")
        if role == "assistant":
            content = message.get("content") or ""
            if content:
                self._display_log.append({"role": "agent", "content": content})
            # Log tool calls
            for tc in message.get("tool_calls", []):
                fn = tc.get("function", {})
                try:
                    tool_input = json.loads(fn.get("arguments", "{}"))
                except (json.JSONDecodeError, TypeError):
                    tool_input = {}
                self._display_log.append({
                    "role": "tool",
                    "toolName": fn.get("name", ""),
                    "toolInput": tool_input,
                })
        elif role == "tool":
            # Update the last tool entry with output
            content = message.get("content", "")
            for i in range(len(self._display_log) - 1, -1, -1):
                if self._display_log[i].get("role") == "tool" and "toolOutput" not in self._display_log[i]:
                    self._display_log[i]["toolOutput"] = content
                    break

        self._save()

    def _save(self) -> None:
        if not self._workspace_path:
            return
        conv_dir = self._workspace_path / "logs" / "conversation"
        conv_dir.mkdir(parents=True, exist_ok=True)

        # Save LLM history (for API continuity)
        (conv_dir / "messages.json").write_text(
            json.dumps(self._messages, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        # Save display log (for frontend replay)
        (conv_dir / "display.json").write_text(
            json.dumps(self._display_log, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _load(self) -> None:
        if not self._workspace_path:
            return
        conv_dir = self._workspace_path / "logs" / "conversation"

        msg_path = conv_dir / "messages.json"
        if msg_path.exists():
            try:
                self._messages = json.loads(msg_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, KeyError):
                self._messages = []

        display_path = conv_dir / "display.json"
        if display_path.exists():
            try:
                self._display_log = json.loads(display_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, KeyError):
                self._display_log = []
