from __future__ import annotations

import os
from pathlib import Path
from uuid import uuid4


class Workspace:
    """Per-session workspace directory with path traversal protection.

    Each agent session gets its own directory under the workspace root.
    All file operations by tools must go through resolve_path().
    """

    def __init__(self, root: Path, session_id: str | None = None) -> None:
        self.root = root.resolve()
        self.session_id = session_id or uuid4().hex[:12]
        self.path = (self.root / self.session_id).resolve()
        self.path.mkdir(parents=True, exist_ok=True)

    @property
    def cwd(self) -> Path:
        return self.path

    def resolve_path(self, user_path: str) -> Path:
        """Resolve a user-supplied relative path against the workspace.

        Rejects absolute paths and any path that escapes the workspace via .. or symlinks.
        """
        if os.path.isabs(user_path):
            raise ValueError(f"Absolute paths not allowed: {user_path}")
        resolved = (self.path / user_path).resolve()
        if not resolved.is_relative_to(self.path.resolve()):
            raise ValueError(f"Path escapes workspace: {user_path}")
        return resolved

    def rename(self, new_name: str) -> str:
        """Rename the workspace folder. Returns the new session_id."""
        new_name = new_name.strip().replace(" ", "_").replace("/", "_")
        if not new_name:
            raise ValueError("Name cannot be empty")
        new_path = self.root / new_name
        if new_path.exists() and new_path != self.path:
            raise ValueError(f"Session '{new_name}' already exists")
        if new_path != self.path:
            self.path.rename(new_path)
            self.path = new_path.resolve()
            self.session_id = new_name
        return self.session_id

    @staticmethod
    def list_sessions(root: Path) -> list[dict[str, str]]:
        """List all workspace sessions with names and metadata."""
        root = root.resolve()
        if not root.exists():
            return []
        sessions = []
        for item in sorted(root.iterdir()):
            if item.is_dir() and not item.name.startswith("."):
                sessions.append({"id": item.name})
        return sessions
