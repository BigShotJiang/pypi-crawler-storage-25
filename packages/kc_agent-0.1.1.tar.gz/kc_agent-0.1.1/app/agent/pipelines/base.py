from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..tools.base import ToolResult
from . import PipelineEvent


class Pipeline(ABC):
    """Base class for all pipeline components.

    Each pipeline hard-codes one meta-meta skill's methodology as structural code.
    The LLM operates WITHIN the pipeline — the pipeline provides structure,
    the LLM provides intelligence.
    """

    @abstractmethod
    def describe_state(self) -> str:
        """Return context injected into the system prompt before each LLM call.

        Tells the agent: current phase, what's done, what's pending, what to do next.
        This is the Pipeline Injector's data source.
        """
        ...

    @abstractmethod
    def on_tool_result(
        self, tool_name: str, tool_input: dict[str, Any], result: ToolResult
    ) -> PipelineEvent | None:
        """Called after each tool execution. Updates pipeline state.

        Returns a PipelineEvent if a milestone is reached or phase transition
        is available. Returns None if no state change occurred.
        This is the Pipeline Controller's callback.
        """
        ...

    @abstractmethod
    def exit_criteria_met(self) -> bool:
        """Whether all requirements for leaving this phase are satisfied."""
        ...
