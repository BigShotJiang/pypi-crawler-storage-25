from __future__ import annotations

import json
from typing import Any

from ..workspace import Workspace
from ..tools.base import ToolResult
from . import Phase, PipelineEvent
from .base import Pipeline

DEFAULT_WORKFLOW_ACCURACY = 0.9


class DistillationEngine(Pipeline):
    """Hard-codes the skill-to-workflow meta-meta skill at the structural level.

    Tracks the transition from Skill Mode (agent does verification) to Workflow
    Mode (worker LLMs do verification at scale). Enforces: tier-downgrade
    testing protocol, workflow file structure, accuracy tracking vs. skill
    ground truth.

    Does NOT constrain: prompt engineering, context narrowing strategy, or
    cost/accuracy trade-off decisions — the agent freestyles those.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace
        self.skills_to_distill: list[str] = []
        self.workflows_created: dict[str, int] = {}      # rule_id → latest version
        self.workflows_tested: dict[str, float] = {}      # rule_id → accuracy
        self.workflows_passing: list[str] = []
        self.tier_assignments: dict[str, str] = {}        # rule_id → tier
        self._workflow_accuracy = DEFAULT_WORKFLOW_ACCURACY
        self._scan_workspace()

    def _scan_workspace(self) -> None:
        self._load_config()
        self._load_skills()
        self._scan_workflows()

    def _load_config(self) -> None:
        env_path = self._workspace.cwd / ".env"
        if not env_path.exists():
            return
        for line in env_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("WORKFLOW_ACCURACY="):
                try:
                    self._workflow_accuracy = float(line.split("=", 1)[1].strip())
                except ValueError:
                    pass

    def _load_skills(self) -> None:
        """Get skills that passed testing (candidates for distillation)."""
        self.skills_to_distill = []
        skill_dir = self._workspace.cwd / "rule_skills"
        if not skill_dir.exists():
            return
        for item in skill_dir.iterdir():
            if item.is_dir() and not item.name.startswith("__"):
                if (item / "SKILL.md").exists() or any(item.glob("*.py")):
                    self.skills_to_distill.append(item.name)

    def _scan_workflows(self) -> None:
        """Scan workflows/ for created workflows and their test results."""
        self.workflows_created = {}
        self.workflows_tested = {}
        self.workflows_passing = []
        self.tier_assignments = {}

        wf_dir = self._workspace.cwd / "workflows"
        if not wf_dir.exists():
            return

        for item in wf_dir.iterdir():
            if not item.is_dir():
                # Check top-level workflow files too (agent might not use subdirs)
                if item.suffix == ".py":
                    name = item.stem
                    self.workflows_created[name] = 1
                continue

            rule_id = item.name

            # Count versions
            versions = sorted(item.glob("workflow_v*.py"))
            if versions:
                self.workflows_created[rule_id] = len(versions)
            elif any(item.glob("*.py")):
                self.workflows_created[rule_id] = 1

            # Read config.json for tier assignments
            config_path = item / "config.json"
            if config_path.exists():
                try:
                    cfg = json.loads(config_path.read_text(encoding="utf-8"))
                    if "tier" in cfg:
                        self.tier_assignments[rule_id] = cfg["tier"]
                    if "accuracy" in cfg:
                        acc = float(cfg["accuracy"])
                        self.workflows_tested[rule_id] = acc
                        if acc >= self._workflow_accuracy:
                            self.workflows_passing.append(rule_id)
                except (json.JSONDecodeError, ValueError):
                    pass

        # Also check output/ for workflow test results
        output_dir = self._workspace.cwd / "output"
        if output_dir.exists():
            for f in output_dir.iterdir():
                if f.is_file() and f.suffix == ".json" and "workflow" in f.name.lower():
                    try:
                        data = json.loads(f.read_text(encoding="utf-8"))
                        if isinstance(data, dict) and "accuracy" in data:
                            rule_id = data.get("rule_id", f.stem)
                            acc = float(data["accuracy"])
                            self.workflows_tested[rule_id] = max(
                                self.workflows_tested.get(rule_id, 0), acc
                            )
                            if acc >= self._workflow_accuracy and rule_id not in self.workflows_passing:
                                self.workflows_passing.append(rule_id)
                    except (json.JSONDecodeError, ValueError):
                        pass

    def describe_state(self) -> str:
        self._scan_workspace()

        total = len(self.skills_to_distill)
        created = len(self.workflows_created)
        tested = len(self.workflows_tested)
        passing = len(self.workflows_passing)

        parts = ["## Current Phase: DISTILLATION"]

        progress = []
        progress.append(f"- Skills to distill: {total}")
        progress.append(f"- Workflows created: {created}")
        progress.append(f"- Workflows tested: {tested}")
        progress.append(f"- Workflows passing (≥{self._workflow_accuracy}): {passing}")
        if self.tier_assignments:
            progress.append(f"- Tier assignments: {dict(list(self.tier_assignments.items())[:5])}")
        parts.append("### Progress\n" + "\n".join(progress))

        if self.exit_criteria_met():
            parts.append(
                "### Ready\n"
                "All workflows passing accuracy threshold. Ready to move to "
                "PRODUCTION_QC phase — deploy workflows on production documents."
            )
        elif created == 0:
            parts.append(
                "### What to do now\n"
                "Convert proven skills into worker LLM workflows.\n\n"
                "For each skill, create a workflow in workflows/{rule_id}/:\n"
                "1. **Decision tree**: For each verification step, decide:\n"
                "   - Can regex/Python handle it? (cost=0, use this first)\n"
                "   - Needs language understanding? → worker LLM call\n"
                "   - Hybrid: cheap check first, LLM fallback\n"
                "2. **Write workflow**: Python script that processes a document\n"
                "3. **Write prompts**: Worker LLM prompts in prompts/ (narrow context, JSON output)\n"
                "4. **Test vs. ground truth**: Compare workflow results to your skill results\n"
                "5. **Tier downgrade**: Test at TIER1 → TIER2 → TIER3 → TIER4. "
                "Select cheapest tier meeting accuracy threshold."
            )
        else:
            not_passing = [rid for rid in self.workflows_created if rid not in self.workflows_passing]
            not_created = [rid for rid in self.skills_to_distill if rid not in self.workflows_created]
            guidance = "### What to do now\n"
            if not_created:
                guidance += f"Create workflows for: {', '.join(not_created[:10])}\n"
            if not_passing:
                guidance += (
                    f"Improve accuracy for: {', '.join(not_passing[:10])}\n"
                    "Try: narrower context, better prompts, or upgrade to higher tier.\n"
                )
            guidance += (
                "\nTier downgrade protocol: test at current tier, then try one tier "
                "lower. If accuracy drops >5 percentage points, stay at current tier."
            )
            parts.append(guidance)

        # Exit criteria
        criteria = []
        criteria.append(f"- [{'x' if created >= total and total > 0 else ' '}] All skills have workflows")
        criteria.append(f"- [{'x' if tested >= created and created > 0 else ' '}] All workflows tested vs. skill ground truth")
        criteria.append(f"- [{'x' if passing >= total and total > 0 else ' '}] All workflows meet accuracy threshold (≥{self._workflow_accuracy})")
        parts.append("### Exit criteria\n" + "\n".join(criteria))

        return "\n\n".join(parts)

    def on_tool_result(
        self, tool_name: str, tool_input: dict[str, Any], result: ToolResult
    ) -> PipelineEvent | None:
        if result.is_error:
            return None

        was_ready = self.exit_criteria_met()

        if tool_name == "workspace_file":
            op = tool_input.get("operation", "")
            path = tool_input.get("path", "")
            if op == "write" and ("workflows/" in path or "output/" in path):
                self._scan_workflows()

        if not was_ready and self.exit_criteria_met():
            return PipelineEvent(
                type="phase_ready",
                message="Distillation complete. Ready to move to PRODUCTION_QC phase.",
                next_phase=Phase.PRODUCTION_QC,
            )

        return None

    def exit_criteria_met(self) -> bool:
        total = len(self.skills_to_distill)
        if total == 0:
            return False
        return (
            len(self.workflows_created) >= total
            and len(self.workflows_passing) >= total
        )
