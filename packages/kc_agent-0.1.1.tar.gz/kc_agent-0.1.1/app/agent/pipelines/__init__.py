from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Phase(str, Enum):
    BOOTSTRAP = "bootstrap"
    EXTRACTION = "extraction"
    SKILL_AUTHORING = "skill_authoring"
    SKILL_TESTING = "skill_testing"
    DISTILLATION = "distillation"
    PRODUCTION_QC = "production_qc"


@dataclass
class PipelineEvent:
    """Emitted by pipelines when a milestone or phase transition occurs."""

    type: str  # "milestone", "phase_ready", "error"
    message: str = ""
    next_phase: Phase | None = None
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self.type, "message": self.message}
        if self.next_phase is not None:
            d["next_phase"] = self.next_phase.value
        if self.data:
            d["data"] = self.data
        return d
