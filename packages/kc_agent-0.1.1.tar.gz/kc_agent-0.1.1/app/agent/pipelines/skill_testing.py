from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from ..workspace import Workspace
from ..tools.base import ToolResult
from . import Phase, PipelineEvent
from .base import Pipeline

DEFAULT_SKILL_ACCURACY = 0.9
DEFAULT_MAX_ITERATIONS = 20


@dataclass
class EvolutionCycle:
    """Record of one diagnose-classify-fix iteration."""

    iteration: int
    rule_id: str
    accuracy_before: float
    failures: list[dict] = field(default_factory=list)
    classification: str = ""  # "systemic" or "corner_case"
    fix_applied: str = ""
    accuracy_after: float | None = None
    regressions: int = 0


class SkillTestingPipeline(Pipeline):
    """Hard-codes the evolution-loop meta-meta skill at the structural level.

    Tracks skill testing progress and evolution cycles. The agent freestyles
    HOW to test and fix — the pipeline tracks WHAT happened and enforces
    convergence criteria and classification thresholds.

    The evolution cycle (test → diagnose → classify → fix → retest → log)
    is guided by describe_state(), not enforced as a state machine. The agent
    follows the cycle methodology; the pipeline tracks results.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace
        self.skills_to_test: list[str] = []
        self.skills_tested: dict[str, float] = {}  # rule_id → best accuracy
        self.skills_passing: list[str] = []
        self.iteration_count: int = 0
        self.evolution_log: list[EvolutionCycle] = []
        self._accuracy_threshold = DEFAULT_SKILL_ACCURACY
        self._max_iterations = DEFAULT_MAX_ITERATIONS
        self._scan_workspace()

    def _scan_workspace(self) -> None:
        """Load config and scan for existing test results."""
        self._load_config()
        self._load_skills()
        self._load_test_results()
        self._load_evolution_log()

    def _load_config(self) -> None:
        """Read accuracy threshold and max iterations from .env."""
        env_path = self._workspace.cwd / ".env"
        if not env_path.exists():
            return
        content = env_path.read_text(encoding="utf-8")
        for line in content.splitlines():
            if line.startswith("SKILL_ACCURACY="):
                try:
                    self._accuracy_threshold = float(line.split("=", 1)[1].strip())
                except ValueError:
                    pass
            elif line.startswith("MAX_ITERATIONS="):
                try:
                    self._max_iterations = int(line.split("=", 1)[1].strip())
                except ValueError:
                    pass

    def _load_skills(self) -> None:
        """Get list of skills to test from rule_skills/."""
        self.skills_to_test = []
        skill_dir = self._workspace.cwd / "rule_skills"
        if not skill_dir.exists():
            return
        for item in skill_dir.iterdir():
            if item.is_dir() and not item.name.startswith("__"):
                if (item / "SKILL.md").exists() or any(item.glob("*.py")):
                    self.skills_to_test.append(item.name)

    def _load_test_results(self) -> None:
        """Scan output/ for test results and extract accuracy per skill."""
        self.skills_tested = {}
        self.skills_passing = []
        output_dir = self._workspace.cwd / "output"
        if not output_dir.exists():
            return

        for f in output_dir.iterdir():
            if not f.is_file() or not f.suffix == ".json":
                continue
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                # Handle various result formats the agent might produce
                if isinstance(data, dict):
                    # Look for accuracy or results summary
                    if "accuracy" in data:
                        rule_id = data.get("rule_id", f.stem)
                        acc = float(data["accuracy"])
                        self.skills_tested[rule_id] = max(self.skills_tested.get(rule_id, 0), acc)
                    elif "results" in data and isinstance(data["results"], list):
                        # Count pass/fail
                        results = data["results"]
                        if results:
                            passed = sum(1 for r in results if r.get("confidence", "") in ("高", "high", "High"))
                            acc = passed / len(results)
                            rule_id = data.get("rule_id", f.stem)
                            self.skills_tested[rule_id] = max(self.skills_tested.get(rule_id, 0), acc)
            except (json.JSONDecodeError, ValueError, KeyError):
                pass

        self.skills_passing = [
            rid for rid, acc in self.skills_tested.items()
            if acc >= self._accuracy_threshold
        ]

    def _load_evolution_log(self) -> None:
        """Load evolution log from logs/evolution/."""
        log_dir = self._workspace.cwd / "logs" / "evolution"
        if not log_dir.exists():
            return
        log_files = sorted(log_dir.glob("*.json"))
        self.iteration_count = len(log_files)
        # Load last few entries for context
        self.evolution_log = []
        for f in log_files[-5:]:  # Keep last 5 for context
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                self.evolution_log.append(EvolutionCycle(
                    iteration=data.get("iteration", 0),
                    rule_id=data.get("rule_id", ""),
                    accuracy_before=data.get("accuracy_before", 0),
                    failures=data.get("failures", []),
                    classification=data.get("classification", ""),
                    fix_applied=data.get("fix_applied", ""),
                    accuracy_after=data.get("accuracy_after"),
                    regressions=data.get("regressions", 0),
                ))
            except (json.JSONDecodeError, KeyError):
                pass

    def _check_convergence(self) -> bool:
        """Check if evolution has converged (from evolution-loop methodology)."""
        if len(self.evolution_log) < 2:
            return False
        last = self.evolution_log[-1]
        return (
            last.accuracy_after is not None
            and last.accuracy_after >= self._accuracy_threshold
            and last.regressions == 0
        )

    def describe_state(self) -> str:
        self._scan_workspace()

        parts = ["## Current Phase: SKILL_TESTING"]

        total = len(self.skills_to_test)
        tested = len(self.skills_tested)
        passing = len(self.skills_passing)

        progress = []
        progress.append(f"- Skills to test: {total}")
        progress.append(f"- Skills tested: {tested}")
        progress.append(f"- Skills passing (≥{self._accuracy_threshold}): {passing}")
        progress.append(f"- Evolution iterations: {self.iteration_count} (max: {self._max_iterations})")
        parts.append("### Progress\n" + "\n".join(progress))

        # Failing skills
        failing = [
            rid for rid in self.skills_tested
            if self.skills_tested[rid] < self._accuracy_threshold
        ]
        untested = [rid for rid in self.skills_to_test if rid not in self.skills_tested]

        if self.exit_criteria_met():
            parts.append(
                "### Ready\n"
                f"Skill testing complete. Accuracy threshold met (≥{self._accuracy_threshold}).\n"
                "You can proceed to DISTILLATION phase — convert proven skills into "
                "worker LLM workflows."
            )
        elif self.iteration_count >= self._max_iterations:
            parts.append(
                f"### Escalation\n"
                f"MAX_ITERATIONS ({self._max_iterations}) reached. "
                f"Escalate remaining failing skills to the developer user:\n"
                + "\n".join(f"- {rid}: accuracy {self.skills_tested.get(rid, 0):.2f}" for rid in failing)
            )
        elif untested:
            parts.append(
                "### What to do now\n"
                f"Test these skills against sample documents: {', '.join(untested[:10])}\n"
                "Run each skill on samples/, record results in output/ as JSON with "
                "accuracy metrics."
            )
        elif failing:
            parts.append(
                "### What to do now — Evolution Cycle\n"
                f"These skills are below the {self._accuracy_threshold} threshold:\n"
                + "\n".join(f"- {rid}: {self.skills_tested[rid]:.2f}" for rid in failing)
                + "\n\n"
                "Follow the evolution cycle:\n"
                "1. **Diagnose**: Is the failure parsing, extraction, judgment, or scope?\n"
                "2. **Classify**: Does it affect >10% of docs (systemic) or <10% (corner case)?\n"
                "3. **Fix**: Systemic → rewrite component. Corner case → add to corner_cases.json\n"
                "4. **Retest**: Run the skill again, check for regressions\n"
                "5. **Log**: Save iteration to logs/evolution/ as JSON\n\n"
                "Do NOT patch the main workflow for corner cases."
            )
        else:
            parts.append(
                "### What to do now\n"
                "All skills tested and passing. Review results with developer user."
            )

        # Recent evolution log
        if self.evolution_log:
            recent = self.evolution_log[-1]
            parts.append(
                f"### Last evolution cycle\n"
                f"- Rule: {recent.rule_id}\n"
                f"- Accuracy: {recent.accuracy_before:.2f} → {recent.accuracy_after or '?'}\n"
                f"- Classification: {recent.classification or 'pending'}\n"
                f"- Regressions: {recent.regressions}"
            )

        # Exit criteria
        passing_pct = (passing / total * 100) if total > 0 else 0
        criteria = []
        criteria.append(f"- [{'x' if tested >= total and total > 0 else ' '}] All skills tested at least once")
        passing_target = self._accuracy_threshold * 100
        criteria.append(f"- [{'x' if passing_pct >= passing_target else ' '}] ≥{passing_target:.0f}% of skills meet accuracy threshold ({passing_pct:.0f}% currently)")
        parts.append("### Exit criteria\n" + "\n".join(criteria))

        return "\n\n".join(parts)

    def on_tool_result(
        self, tool_name: str, tool_input: dict[str, Any], result: ToolResult
    ) -> PipelineEvent | None:
        if result.is_error:
            return None

        was_ready = self.exit_criteria_met()

        if tool_name == "workspace_file":
            op = tool_input.get("operation", "")
            path = tool_input.get("path", "")
            if op == "write":
                if path.startswith("output/") and path.endswith(".json"):
                    self._load_test_results()
                elif "logs/evolution" in path:
                    self._load_evolution_log()
                    self.iteration_count = max(self.iteration_count, len(self.evolution_log))

        if not was_ready and self.exit_criteria_met():
            return PipelineEvent(
                type="phase_ready",
                message="Skill testing complete. Ready to move to DISTILLATION phase.",
                next_phase=Phase.DISTILLATION,
            )

        return None

    def exit_criteria_met(self) -> bool:
        total = len(self.skills_to_test)
        if total == 0:
            return False
        tested = len(self.skills_tested)
        passing = len(self.skills_passing)
        return (
            tested >= total
            and passing >= total * self._accuracy_threshold
        )
