from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..workspace import Workspace
from ..tools.base import ToolResult
from . import Phase, PipelineEvent
from .base import Pipeline

# Directories the workspace must have (hard-coded from bootstrap-workspace methodology)
REQUIRED_DIRS = ["rules", "samples", "input", "output", "logs", "workflows", "rule_skills"]

DEFAULT_ENV = """\
# === KC Agent Project Configuration ===

# Language: en | zh
LANGUAGE=en

# === Worker LLM API (SiliconFlow) ===
SILICONFLOW_API_KEY=
SILICONFLOW_BASE_URL=https://api.siliconflow.cn/v1

# === Worker LLM Tiers (highest capability to lowest) ===
TIER1=Pro/zai-org/GLM-5, Pro/moonshotai/Kimi-K2.5
TIER2=Pro/deepseek-ai/DeepSeek-V3.2, Pro/MiniMaxAI/MiniMax-M2.5, Qwen/Qwen3.5-397B-A17B
TIER3=Qwen/Qwen3.5-122B-A10B
TIER4=Qwen/Qwen3.5-35B-A3B

# === OCR Model Tiers ===
OCR_MODEL_TIER1=zai-org/GLM-4.6V
OCR_MODEL_TIER2=Qwen/Qwen3.5-397B-A17B
OCR_MODEL_TIER3=PaddlePaddle/PaddleOCR-VL-1.5

# === Quality Thresholds ===
SKILL_ACCURACY=0.9
WORKFLOW_ACCURACY=0.9
MONITOR_FREQUENCY=mid

# === Evolution Control ===
MAX_ITERATIONS=20
"""


class ProjectInitializer(Pipeline):
    """Hard-codes the bootstrap-workspace meta-meta skill.

    Auto-creates workspace structure on init (code, not LLM judgment).
    Tracks state to know when bootstrap is complete.
    Provides structured context telling the agent what to do next.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace

        # State tracking
        self.workspace_created = False
        self.config_ready = False
        self.has_regulations = False
        self.has_samples = False

        # Auto-create structure on init
        self._setup_workspace()

    def _setup_workspace(self) -> None:
        """Create workspace directories and default config. Pure code — no LLM involved."""
        for d in REQUIRED_DIRS:
            (self._workspace.cwd / d).mkdir(parents=True, exist_ok=True)

        # Write .env — merge global config (from kc onboard) into template
        env_path = self._workspace.cwd / ".env"
        if not env_path.exists():
            env_content = DEFAULT_ENV
            gc = self._load_global_config()
            if gc.get("api_key"):
                env_content = env_content.replace(
                    "SILICONFLOW_API_KEY=",
                    f"SILICONFLOW_API_KEY={gc['api_key']}",
                )
            if gc.get("base_url"):
                env_content = env_content.replace(
                    "SILICONFLOW_BASE_URL=https://api.siliconflow.cn/v1",
                    f"SILICONFLOW_BASE_URL={gc['base_url']}",
                )
            if gc.get("accuracy_threshold"):
                env_content = env_content.replace(
                    "SKILL_ACCURACY=0.9",
                    f"SKILL_ACCURACY={gc['accuracy_threshold']}",
                )
                env_content = env_content.replace(
                    "WORKFLOW_ACCURACY=0.9",
                    f"WORKFLOW_ACCURACY={gc['accuracy_threshold']}",
                )
            # Apply tier overrides
            tiers = gc.get("tiers", {})
            for tier_key in ("tier1", "tier2", "tier3", "tier4"):
                if tiers.get(tier_key):
                    tag = tier_key.upper()
                    # Replace the line starting with that tier
                    lines = env_content.splitlines()
                    for i, line in enumerate(lines):
                        if line.startswith(f"{tag}="):
                            lines[i] = f"{tag}={tiers[tier_key]}"
                    env_content = "\n".join(lines)
            env_path.write_text(env_content, encoding="utf-8")

        # Initialize versions manifest
        manifest_path = self._workspace.cwd / "versions.json"
        if not manifest_path.exists():
            manifest_path.write_text(
                json.dumps({"version": "0.1.0", "entries": []}, indent=2),
                encoding="utf-8",
            )

        self.workspace_created = True

        # Check initial state
        self._check_regulations()
        self._check_samples()
        self._check_config()

    def _check_regulations(self) -> None:
        rules_dir = self._workspace.cwd / "rules"
        self.has_regulations = any(
            f.is_file() for f in rules_dir.iterdir()
        ) if rules_dir.exists() else False

    def _check_samples(self) -> None:
        samples_dir = self._workspace.cwd / "samples"
        self.has_samples = any(
            f.is_file() for f in samples_dir.iterdir()
        ) if samples_dir.exists() else False

    def _check_config(self) -> None:
        # Check workspace .env first
        env_path = self._workspace.cwd / ".env"
        if env_path.exists():
            content = env_path.read_text(encoding="utf-8")
            for line in content.splitlines():
                if line.startswith("SILICONFLOW_API_KEY=") and line.split("=", 1)[1].strip():
                    self.config_ready = True
                    return

        # Fall back to global config from kc onboard
        gc = self._load_global_config()
        if gc.get("api_key"):
            self.config_ready = True
            return

        self.config_ready = False

    def describe_state(self) -> str:
        completed = []
        pending = []

        if self.workspace_created:
            completed.append("Workspace structure created (rules/, samples/, input/, output/, ...)")
        else:
            pending.append("Create workspace structure")

        if self.config_ready:
            completed.append("Configuration ready (API keys set)")
        else:
            pending.append("Configure .env (SILICONFLOW_API_KEY needed)")

        if self.has_regulations:
            completed.append("Regulation documents available in rules/")
        else:
            pending.append("Regulation documents needed in rules/")

        if self.has_samples:
            completed.append("Sample documents available in samples/")
        else:
            pending.append("Sample documents needed in samples/")

        parts = ["## Current Phase: BOOTSTRAP"]

        # Show global config (from kc onboard)
        gc = self._load_global_config()
        if gc:
            parts.append(
                "### Global Configuration (from kc onboard)\n"
                f"- Provider: {gc.get('provider', 'unknown')}\n"
                f"- Model: {gc.get('conductor_model', 'unknown')}\n"
                f"- Accuracy: {gc.get('accuracy_threshold', 0.9)}\n\n"
                "Confirm with the developer user if these settings are correct for this project. "
                "They can override per-project in the workspace .env."
            )

        if completed:
            parts.append("### Completed\n" + "\n".join(f"- [x] {c}" for c in completed))
        if pending:
            parts.append("### Pending\n" + "\n".join(f"- [ ] {p}" for p in pending))

        if self.exit_criteria_met():
            parts.append(
                "### Ready\n"
                "All bootstrap requirements met. You can proceed to the EXTRACTION phase.\n"
                "Summarize what you know about the project, then move forward with rule extraction."
            )
        else:
            parts.append(
                "### What to do now\n"
                "Talk to the developer user about their verification scenario:\n"
                "- What documents do they verify? (contracts, filings, reports, etc.)\n"
                "- What regulations apply?\n"
                "- How many rules to extract? Rough estimate.\n"
                "- What accuracy is acceptable? (default: 0.9)\n\n"
                "Ask them to provide regulation documents (save to rules/) "
                "and sample documents (save to samples/).\n"
                "Use workspace_file to write documents the user provides.\n"
                "Use document_parse to read and understand uploaded PDFs."
            )

        return "\n\n".join(parts)

    @staticmethod
    def _load_global_config() -> dict:
        import json
        gc_path = Path.home() / ".kc_agent" / "config.json"
        if gc_path.exists():
            try:
                return json.loads(gc_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, KeyError):
                pass
        return {}

    def on_tool_result(
        self, tool_name: str, tool_input: dict[str, Any], result: ToolResult
    ) -> PipelineEvent | None:
        if result.is_error:
            return None

        was_ready = self.exit_criteria_met()

        # Track file operations that affect bootstrap state
        if tool_name == "workspace_file":
            op = tool_input.get("operation", "")
            path = tool_input.get("path", "")

            if op == "write":
                if path.startswith("rules/"):
                    self.has_regulations = True
                elif path.startswith("samples/"):
                    self.has_samples = True
                elif path == ".env":
                    self._check_config()

            elif op == "list":
                if path in ("rules", "rules/", "."):
                    self._check_regulations()
                if path in ("samples", "samples/", "."):
                    self._check_samples()

        # Check if we just became ready
        if not was_ready and self.exit_criteria_met():
            return PipelineEvent(
                type="phase_ready",
                message="Bootstrap complete. Ready to move to EXTRACTION phase.",
                next_phase=Phase.EXTRACTION,
            )

        return None

    def exit_criteria_met(self) -> bool:
        return (
            self.workspace_created
            and self.config_ready
            and self.has_regulations
            and self.has_samples
        )
