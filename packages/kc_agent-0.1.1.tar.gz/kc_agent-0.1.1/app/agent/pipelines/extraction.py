from __future__ import annotations

import json
from typing import Any

from ..workspace import Workspace
from ..tools.base import ToolResult
from . import Phase, PipelineEvent
from .base import Pipeline


class RuleExtractionPipeline(Pipeline):
    """Hard-codes the rule-extraction meta-meta skill at the structural level.

    Provides: state tracking, exit criteria, structured guidance.
    Does NOT constrain: how the agent reads regulations, what methods it uses
    to extract rules, or how it structures the output. The agent freestyles
    the implementation — the pipeline ensures the right things get done.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace

        # State tracking
        self.regulations_scanned = False
        self.rules_extracted: list[str] = []
        self.rules_with_tests: list[str] = []
        self.coverage_audited = False
        self._test_coverage_threshold = 0.8  # configurable: fraction of rules needing test stubs

        # Scan initial state
        self._scan_workspace()

    def _scan_workspace(self) -> None:
        """Check workspace for existing rules and test cases."""
        rules_dir = self._workspace.cwd / "rules"
        rule_skills_dir = self._workspace.cwd / "rule_skills"

        # Check if regulations exist (they should — bootstrap put them there)
        if rules_dir.exists():
            reg_files = [f for f in rules_dir.iterdir() if f.is_file() and not f.name.endswith(".json")]
            self.regulations_scanned = len(reg_files) > 0

        # Check for existing extracted rules
        self._scan_rules()

        # Check for test cases
        self._scan_tests()

        # Check for coverage audit
        self._check_coverage_audit()

    def _scan_rules(self) -> None:
        """Look for rule definitions in rules/ and rule_skills/."""
        self.rules_extracted = []

        # Check for rules JSON
        rules_json = self._workspace.cwd / "rules" / "trust_rules.json"
        if rules_json.exists():
            try:
                data = json.loads(rules_json.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    self.rules_extracted = [r.get("id", r.get("name", f"rule_{i}")) for i, r in enumerate(data)]
                elif isinstance(data, dict) and "rules" in data:
                    self.rules_extracted = [r.get("id", r.get("name", f"rule_{i}")) for i, r in enumerate(data["rules"])]
            except (json.JSONDecodeError, KeyError):
                pass

        # Also check rule_skills/ subdirectories
        rule_skills_dir = self._workspace.cwd / "rule_skills"
        if rule_skills_dir.exists():
            for item in rule_skills_dir.iterdir():
                if item.is_dir() and item.name not in ("__pycache__",):
                    rule_id = item.name
                    if rule_id not in self.rules_extracted:
                        self.rules_extracted.append(rule_id)

    def _scan_tests(self) -> None:
        """Look for test cases associated with rules."""
        self.rules_with_tests = []

        # Check for test_cases/ directories inside rule_skills/
        rule_skills_dir = self._workspace.cwd / "rule_skills"
        if rule_skills_dir.exists():
            for item in rule_skills_dir.iterdir():
                if item.is_dir():
                    test_dir = item / "test_cases"
                    if test_dir.exists() and any(test_dir.iterdir()):
                        self.rules_with_tests.append(item.name)

        # Check for output/ test results
        output_dir = self._workspace.cwd / "output"
        if output_dir.exists():
            for f in output_dir.iterdir():
                if f.is_file() and "result" in f.name.lower():
                    # If there are extraction results, some testing has been done
                    if not self.rules_with_tests:
                        self.rules_with_tests = ["_has_results"]

    def _check_coverage_audit(self) -> None:
        """Check if a coverage audit file exists."""
        coverage_file = self._workspace.cwd / "rules" / "coverage_audit.md"
        if not coverage_file.exists():
            coverage_file = self._workspace.cwd / "rules" / "coverage_audit.json"
        self.coverage_audited = coverage_file.exists()

    def describe_state(self) -> str:
        # Refresh state
        self._scan_workspace()
        self._check_coverage_audit()

        rules_dir = self._workspace.cwd / "rules"
        reg_count = len([f for f in rules_dir.iterdir() if f.is_file() and not f.name.endswith(".json")]) if rules_dir.exists() else 0

        parts = ["## Current Phase: EXTRACTION"]

        # Progress
        progress = []
        progress.append(f"- Regulations scanned: {'yes' if self.regulations_scanned else 'no'} ({reg_count} document(s) in rules/)")
        progress.append(f"- Rules extracted: {len(self.rules_extracted)}")
        progress.append(f"- Rules with test cases: {len(self.rules_with_tests)}")
        progress.append(f"- Coverage audit: {'done' if self.coverage_audited else 'not yet'}")
        parts.append("### Progress\n" + "\n".join(progress))

        # What to do
        if not self.regulations_scanned:
            parts.append(
                "### What to do now\n"
                "Read and parse the regulation documents in rules/. Understand the "
                "structure, scope, and requirements before extracting individual rules."
            )
        elif len(self.rules_extracted) == 0:
            parts.append(
                "### What to do now\n"
                "Decompose the regulations into atomic, testable rules.\n"
                "- One rule = one pass/fail outcome\n"
                "- Work top-down: major areas → chapters → sections → atomic rules\n"
                "- Each rule needs: unique ID, source reference, description\n"
                "- Save rules to rules/ as structured JSON"
            )
        elif len(self.rules_with_tests) < len(self.rules_extracted) * 0.5:
            parts.append(
                "### What to do now\n"
                "Create test cases for extracted rules.\n"
                "- Pick sample documents and extract expected values manually\n"
                "- Store test cases in rule_skills/{rule_id}/test_cases/\n"
                f"- {len(self.rules_extracted) - len(self.rules_with_tests)} rules still need test cases"
            )
        elif not self.coverage_audited:
            parts.append(
                "### What to do now\n"
                "Run a coverage audit: which sections of the regulation are NOT covered "
                "by any rule? Save the audit to rules/coverage_audit.md"
            )
        else:
            parts.append(
                "### Ready\n"
                "All extraction exit criteria met. You can proceed to SKILL_AUTHORING phase.\n"
                "Review the extracted rules with the developer user before moving on."
            )

        # Exit criteria
        criteria = []
        criteria.append(f"- [{'x' if self.regulations_scanned else ' '}] All regulation documents read and understood")
        criteria.append(f"- [{'x' if len(self.rules_extracted) > 0 else ' '}] Rules decomposed into atomic, testable units")
        pct = int(self._test_coverage_threshold * 100)
        criteria.append(f"- [{'x' if len(self.rules_with_tests) >= len(self.rules_extracted) * self._test_coverage_threshold else ' '}] ≥{pct}% of rules have test case stubs")
        criteria.append(f"- [{'x' if self.coverage_audited else ' '}] Coverage audit completed")
        parts.append("### Exit criteria\n" + "\n".join(criteria))

        return "\n\n".join(parts)

    def on_tool_result(
        self, tool_name: str, tool_input: dict[str, Any], result: ToolResult
    ) -> PipelineEvent | None:
        if result.is_error:
            return None

        was_ready = self.exit_criteria_met()

        if tool_name == "workspace_file":
            op = tool_input.get("operation", "")
            path = tool_input.get("path", "")

            if op == "write":
                # Track rule file creation
                if "rules" in path and path.endswith(".json"):
                    self._scan_rules()
                # Track test case creation
                if "rule_skills" in path and "test_case" in path:
                    self._scan_tests()
                # Track coverage audit
                if "coverage_audit" in path:
                    self.coverage_audited = True

        # Check if we just became ready
        if not was_ready and self.exit_criteria_met():
            return PipelineEvent(
                type="phase_ready",
                message="Rule extraction complete. Ready to move to SKILL_AUTHORING phase.",
                next_phase=Phase.SKILL_AUTHORING,
            )

        return None

    def exit_criteria_met(self) -> bool:
        return (
            self.regulations_scanned
            and len(self.rules_extracted) > 0
            and len(self.rules_with_tests) >= max(len(self.rules_extracted) * 0.8, 1)
            and self.coverage_audited
        )
