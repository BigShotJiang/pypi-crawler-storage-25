from __future__ import annotations

import json
from typing import Any

from ..workspace import Workspace
from ..tools.base import ToolResult
from . import Phase, PipelineEvent
from .base import Pipeline

# MONITOR_FREQUENCY from .env maps to initial sampling rates
FREQUENCY_MAP = {
    "high": 1.0,   # review 100% initially
    "mid": 0.5,    # review 50% initially
    "low": 0.2,    # review 20% initially
}


class ProductionQCPipeline(Pipeline):
    """Hard-codes the quality-control meta-meta skill at the structural level.

    Tracks production execution, adaptive sampling, accuracy monitoring.
    This phase doesn't "exit" in the traditional sense — it's ongoing
    monitoring that transitions from active review to stable spot-checking.

    Thresholds come from .env (MONITOR_FREQUENCY, WORKFLOW_ACCURACY).
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace
        self.batches_processed: int = 0
        self.total_documents: int = 0
        self.documents_reviewed: int = 0
        self.accuracy_by_rule: dict[str, float] = {}
        self.confidence_distribution: dict[str, int] = {"low": 0, "medium": 0, "high": 0}
        self.issues_found: list[dict] = []
        self.monitoring_phase: str = "initial"  # initial → active → stable
        self._sampling_rate: float = 0.5
        self._accuracy_threshold = 0.9
        self._scan_workspace()

    def _scan_workspace(self) -> None:
        self._load_config()
        self._scan_qc_results()

    def _load_config(self) -> None:
        env_path = self._workspace.cwd / ".env"
        if not env_path.exists():
            return
        for line in env_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("MONITOR_FREQUENCY="):
                freq = line.split("=", 1)[1].strip().lower()
                self._sampling_rate = FREQUENCY_MAP.get(freq, 0.5)
            elif line.startswith("WORKFLOW_ACCURACY="):
                try:
                    self._accuracy_threshold = float(line.split("=", 1)[1].strip())
                except ValueError:
                    pass

    def _scan_qc_results(self) -> None:
        """Scan output/ and output/qc/ for production results."""
        self.batches_processed = 0
        self.total_documents = 0
        self.documents_reviewed = 0
        self.accuracy_by_rule = {}
        self.confidence_distribution = {"low": 0, "medium": 0, "high": 0}
        self.issues_found = []

        qc_dir = self._workspace.cwd / "output" / "qc"
        if not qc_dir.exists():
            return

        for f in sorted(qc_dir.glob("*.json")):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                if not isinstance(data, dict):
                    continue

                self.batches_processed += 1
                docs = data.get("documents", data.get("total", 0))
                reviewed = data.get("reviewed", 0)
                self.total_documents += docs if isinstance(docs, int) else 0
                self.documents_reviewed += reviewed if isinstance(reviewed, int) else 0

                # Accuracy per rule
                if "accuracy_by_rule" in data:
                    for rid, acc in data["accuracy_by_rule"].items():
                        try:
                            self.accuracy_by_rule[rid] = float(acc)
                        except (ValueError, TypeError):
                            pass

                # Confidence distribution
                if "confidence" in data:
                    for band in ("low", "medium", "high"):
                        self.confidence_distribution[band] += data["confidence"].get(band, 0)

                # Issues
                if "issues" in data and isinstance(data["issues"], list):
                    self.issues_found.extend(data["issues"])

            except (json.JSONDecodeError, KeyError):
                pass

        # Determine monitoring phase
        self._update_monitoring_phase()

    def _update_monitoring_phase(self) -> None:
        """Transition monitoring phase based on batch count and accuracy."""
        if self.batches_processed == 0:
            self.monitoring_phase = "initial"
        elif self.batches_processed < 3:
            self.monitoring_phase = "initial"
        elif self.issues_found:
            self.monitoring_phase = "active"
        elif all(acc >= self._accuracy_threshold for acc in self.accuracy_by_rule.values()):
            self.monitoring_phase = "stable"
        else:
            self.monitoring_phase = "active"

    def describe_state(self) -> str:
        self._scan_workspace()

        parts = ["## Current Phase: PRODUCTION_QC"]

        progress = []
        progress.append(f"- Batches processed: {self.batches_processed}")
        progress.append(f"- Total documents: {self.total_documents}")
        progress.append(f"- Documents reviewed: {self.documents_reviewed}")
        progress.append(f"- Monitoring phase: {self.monitoring_phase}")
        progress.append(f"- Sampling rate: {self._sampling_rate:.0%}")
        parts.append("### Progress\n" + "\n".join(progress))

        # Confidence distribution
        if any(v > 0 for v in self.confidence_distribution.values()):
            conf = self.confidence_distribution
            parts.append(
                f"### Confidence distribution\n"
                f"- Low: {conf['low']} | Medium: {conf['medium']} | High: {conf['high']}"
            )

        # Accuracy by rule
        if self.accuracy_by_rule:
            lines = [f"- {rid}: {acc:.2f}" for rid, acc in sorted(self.accuracy_by_rule.items())]
            failing = [rid for rid, acc in self.accuracy_by_rule.items() if acc < self._accuracy_threshold]
            parts.append("### Accuracy by rule\n" + "\n".join(lines))
            if failing:
                parts.append(
                    f"### Action needed\n"
                    f"Rules below threshold ({self._accuracy_threshold}): {', '.join(failing)}\n"
                    "Trigger evolution cycle on affected rules — diagnose, classify, fix."
                )

        # Issues
        if self.issues_found:
            parts.append(f"### Issues ({len(self.issues_found)} flagged)\n"
                         "Review flagged results. Issues may indicate workflow degradation.")

        # Guidance
        if self.monitoring_phase == "initial":
            parts.append(
                "### What to do now\n"
                "Run workflows on documents in input/. Save results to output/.\n"
                "Review results — check all low-confidence, sample medium/high.\n"
                "Save QC reviews to output/qc/ as JSON with: documents, reviewed, "
                "accuracy_by_rule, confidence, issues."
            )
        elif self.monitoring_phase == "stable":
            parts.append(
                "### Status: Stable\n"
                "Workflows running reliably. Spot-check only.\n"
                "Monitor for: new document types, regulation changes, accuracy drift."
            )

        return "\n\n".join(parts)

    def on_tool_result(
        self, tool_name: str, tool_input: dict[str, Any], result: ToolResult
    ) -> PipelineEvent | None:
        if result.is_error:
            return None

        was_stable = self.monitoring_phase == "stable"

        if tool_name == "workspace_file":
            op = tool_input.get("operation", "")
            path = tool_input.get("path", "")
            if op == "write" and "output/" in path:
                self._scan_qc_results()

        # Notify when transitioning to stable
        if not was_stable and self.monitoring_phase == "stable":
            return PipelineEvent(
                type="milestone",
                message="Production QC reached stable monitoring phase.",
            )

        return None

    def exit_criteria_met(self) -> bool:
        """Production QC is 'done' when monitoring reaches stable phase."""
        return self.monitoring_phase == "stable"
