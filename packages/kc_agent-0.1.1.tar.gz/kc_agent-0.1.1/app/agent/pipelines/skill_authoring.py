from __future__ import annotations

import json
from typing import Any

from ..workspace import Workspace
from ..tools.base import ToolResult
from . import Phase, PipelineEvent
from .base import Pipeline


class SkillAuthoringPipeline(Pipeline):
    """Hard-codes the skill-authoring meta-meta skill at the structural level.

    Tracks whether each extracted rule has been written into a skill folder
    with the required structure (SKILL.md, scripts/, references/, assets/).
    Does NOT constrain how the agent writes the skill content — just ensures
    the right artifacts exist.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace
        self.total_rules: list[str] = []
        self.skills_authored: list[str] = []
        self.skills_with_scripts: list[str] = []
        self._scripts_threshold = 0.5  # configurable: fraction of skills needing scripts/
        self._scan_workspace()

    def _scan_workspace(self) -> None:
        """Discover rules from extraction phase and scan skill folders."""
        # Get rule list from extraction output
        self._load_rules()
        # Scan existing skill folders
        self._scan_skills()

    def _load_rules(self) -> None:
        """Load rule IDs from rules/ JSON files."""
        self.total_rules = []
        rules_dir = self._workspace.cwd / "rules"
        if not rules_dir.exists():
            return
        for f in rules_dir.iterdir():
            if f.suffix == ".json" and f.is_file():
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    if isinstance(data, list):
                        for i, r in enumerate(data):
                            self.total_rules.append(r.get("id", r.get("name", f"rule_{i}")))
                    elif isinstance(data, dict) and "rules" in data:
                        for i, r in enumerate(data["rules"]):
                            self.total_rules.append(r.get("id", r.get("name", f"rule_{i}")))
                except (json.JSONDecodeError, KeyError):
                    pass

    def _scan_skills(self) -> None:
        """Check which rules have skill folders with required files."""
        self.skills_authored = []
        self.skills_with_scripts = []
        skill_dir = self._workspace.cwd / "rule_skills"
        if not skill_dir.exists():
            return
        for item in skill_dir.iterdir():
            if not item.is_dir() or item.name.startswith("__"):
                continue
            # Has SKILL.md or any .py/.md file = authored
            has_skill_doc = (item / "SKILL.md").exists()
            has_any_py = any(item.glob("*.py"))
            if has_skill_doc or has_any_py:
                self.skills_authored.append(item.name)
            # Has scripts/ with content
            scripts_dir = item / "scripts"
            if scripts_dir.exists() and any(scripts_dir.iterdir()):
                self.skills_with_scripts.append(item.name)

    def describe_state(self) -> str:
        self._scan_workspace()

        parts = ["## Current Phase: SKILL_AUTHORING"]

        # Progress
        total = len(self.total_rules)
        authored = len(self.skills_authored)
        with_scripts = len(self.skills_with_scripts)

        progress = []
        progress.append(f"- Rules from extraction: {total}")
        progress.append(f"- Skills authored (have SKILL.md or code): {authored}")
        progress.append(f"- Skills with scripts/: {with_scripts}")
        parts.append("### Progress\n" + "\n".join(progress))

        # Guidance
        if authored == 0:
            parts.append(
                "### What to do now\n"
                "Write a SKILL.md for each rule in rule_skills/{rule_id}/.\n"
                "Each skill should describe:\n"
                "1. What this rule checks (regulatory source + intent)\n"
                "2. Where to look in the document (sections/chapters)\n"
                "3. What to extract (entities, format, normalization)\n"
                "4. How to judge (pass/fail logic, edge cases)\n\n"
                "Add deterministic scripts where possible (regex, calculations) "
                "in scripts/. Use LLM only when semantic understanding is required.\n\n"
                "You can author skills for multiple rules at once if they share patterns."
            )
        elif authored < total:
            remaining = set(self.total_rules) - set(self.skills_authored)
            remaining_list = list(remaining)[:10]
            parts.append(
                f"### What to do now\n"
                f"Continue authoring skills. {total - authored} rules still need skills.\n"
                f"Remaining: {', '.join(remaining_list)}{'...' if len(remaining) > 10 else ''}"
            )
        elif self.exit_criteria_met():
            parts.append(
                "### Ready\n"
                "All rules have skills authored. Present a summary to the developer user "
                "for review, then proceed to SKILL_TESTING phase."
            )
        else:
            parts.append(
                "### Almost ready\n"
                "All rules have skills, but more need deterministic scripts. "
                "Add regex/calculation scripts where the extraction logic is predictable."
            )

        # Exit criteria
        criteria = []
        criteria.append(f"- [{'x' if authored >= total and total > 0 else ' '}] Every rule has a skill in rule_skills/")
        pct = int(self._scripts_threshold * 100)
        criteria.append(f"- [{'x' if with_scripts >= authored * self._scripts_threshold else ' '}] ≥{pct}% of skills have scripts/")
        parts.append("### Exit criteria\n" + "\n".join(criteria))

        return "\n\n".join(parts)

    def on_tool_result(
        self, tool_name: str, tool_input: dict[str, Any], result: ToolResult
    ) -> PipelineEvent | None:
        if result.is_error:
            return None

        was_ready = self.exit_criteria_met()

        if tool_name == "workspace_file":
            op = tool_input.get("operation", "")
            path = tool_input.get("path", "")
            if op == "write" and "rule_skills/" in path:
                self._scan_skills()

        if not was_ready and self.exit_criteria_met():
            return PipelineEvent(
                type="phase_ready",
                message="Skill authoring complete. Ready to move to SKILL_TESTING phase.",
                next_phase=Phase.SKILL_TESTING,
            )

        return None

    def exit_criteria_met(self) -> bool:
        if not self.total_rules:
            return False
        authored = len(self.skills_authored)
        with_scripts = len(self.skills_with_scripts)
        return (
            authored >= len(self.total_rules)
            and with_scripts >= authored * self._scripts_threshold
        )
