from __future__ import annotations

import asyncio
import json
from typing import Any

from ..confidence_scorer import ConfidenceScorer
from ..version_manager import VersionManager
from ..workspace import Workspace
from .base import BaseTool, ToolResult


class WorkflowRunTool(BaseTool):
    """Execute a distilled workflow script against a document.

    Runs the workflow Python script in sandbox, attaches ConfidenceScorer
    result and trace ID automatically. Saves structured result to output/results/.
    """

    def __init__(
        self,
        workspace: Workspace,
        version_manager: VersionManager,
        confidence_scorer: ConfidenceScorer,
        *,
        timeout: int = 120,
    ) -> None:
        self._workspace = workspace
        self._version_mgr = version_manager
        self._confidence = confidence_scorer
        self._timeout = timeout

    @property
    def name(self) -> str:
        return "workflow_run"

    @property
    def description(self) -> str:
        return (
            "Execute a distilled workflow against a document. Runs the workflow "
            "Python script, attaches confidence scores and trace IDs automatically. "
            "Results saved to output/results/."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "rule_id": {
                    "type": "string",
                    "description": "Rule ID whose workflow to execute",
                },
                "document_path": {
                    "type": "string",
                    "description": "Relative path to document in workspace",
                },
                "workflow_version": {
                    "type": "integer",
                    "description": "Workflow version to run (default: latest)",
                },
            },
            "required": ["rule_id", "document_path"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        rule_id = input.get("rule_id", "")
        doc_path = input.get("document_path", "")
        wf_version = input.get("workflow_version")

        if not rule_id or not doc_path:
            return ToolResult(content="rule_id and document_path required", is_error=True)

        # Find workflow script
        wf_dir = self._workspace.cwd / "workflows" / rule_id
        if not wf_dir.is_dir():
            # Also check for top-level workflow files
            wf_dir = self._workspace.cwd / "workflows"

        wf_script = self._find_workflow(wf_dir, rule_id, wf_version)
        if not wf_script:
            return ToolResult(
                content=f"No workflow found for {rule_id} in workflows/",
                is_error=True,
            )

        # Resolve document path
        try:
            doc_resolved = self._workspace.resolve_path(doc_path)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)
        if not doc_resolved.is_file():
            return ToolResult(content=f"Document not found: {doc_path}", is_error=True)

        # Run workflow in subprocess
        cmd = f"python {wf_script} {doc_resolved}"
        try:
            proc = await asyncio.create_subprocess_shell(
                cmd,
                cwd=str(self._workspace.cwd),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=self._timeout)
            output = stdout.decode("utf-8", errors="replace") if stdout else ""
        except asyncio.TimeoutError:
            return ToolResult(content=f"Workflow timed out after {self._timeout}s", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Workflow execution error: {e}", is_error=True)

        # Try to parse output as JSON for structured result
        try:
            result_data = json.loads(output.strip().split("\n")[-1])
        except (json.JSONDecodeError, IndexError):
            result_data = {"raw_output": output[:5000]}

        # Attach confidence score
        extracted_value = str(result_data.get("extracted_value", result_data.get("value", "")))
        method = result_data.get("extraction_method", "llm")
        confidence = self._confidence.score(
            rule_id=rule_id,
            extracted_value=extracted_value,
            extraction_method=method,
            document_name=doc_resolved.name,
        )
        result_data["confidence"] = confidence
        result_data["confidence_band"] = self._confidence.get_band(confidence)

        # Attach trace ID
        trace_id = self._version_mgr.generate_trace_id(rule_id, "workflow_result")
        result_data["trace_id"] = trace_id
        result_data["rule_id"] = rule_id
        result_data["document"] = doc_path

        # Save result
        results_dir = self._workspace.cwd / "output" / "results"
        results_dir.mkdir(parents=True, exist_ok=True)
        result_file = results_dir / f"{rule_id}_{doc_resolved.stem}.json"
        result_file.write_text(json.dumps(result_data, ensure_ascii=False, indent=2), encoding="utf-8")

        return ToolResult(content=json.dumps(result_data, ensure_ascii=False, indent=2))

    def _find_workflow(self, wf_dir: Any, rule_id: str, version: int | None) -> Any | None:
        """Find the workflow script to run."""
        if not wf_dir.is_dir():
            return None

        if version:
            target = wf_dir / f"workflow_v{version}.py"
            if target.is_file():
                return target

        # Find latest versioned workflow
        versions = sorted(wf_dir.glob("workflow_v*.py"))
        if versions:
            return versions[-1]

        # Fallback: any .py file with "workflow" in name
        for f in wf_dir.iterdir():
            if f.suffix == ".py" and "workflow" in f.name.lower():
                return f

        # Fallback: any .py file
        py_files = list(wf_dir.glob("*.py"))
        if py_files:
            return py_files[0]

        return None
