from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult


class AgentTool(BaseTool):
    """Spawn a sub-agent for parallel work.

    Creates a child AgentEngine with the same tools and pipelines,
    running on a self-contained task description. The child shares the
    workspace filesystem but has its own conversation history.

    Results arrive via workspace files — the main agent reads them.
    Sub-agents cannot talk to the user directly.
    """

    def __init__(self, workspace: Workspace, engine_factory: Any) -> None:
        """
        engine_factory: callable(session_id) -> AgentEngine
        Passed from the parent engine so sub-agents get the same config.
        """
        self._workspace = workspace
        self._engine_factory = engine_factory
        self._running_tasks: dict[str, asyncio.Task] = {}

    @property
    def name(self) -> str:
        return "agent_tool"

    @property
    def description(self) -> str:
        return (
            "Spawn a sub-agent for an independent task. Give it a complete, "
            "self-contained task description. The sub-agent works in the same "
            "workspace and writes results to files. Use this for parallel rule "
            "processing, batch testing, or any work that can run independently."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_description": {
                    "type": "string",
                    "description": "Complete task description for the sub-agent. Be specific — it has no conversation context from the parent.",
                },
                "task_id": {
                    "type": "string",
                    "description": "Optional task identifier (auto-generated if omitted)",
                },
            },
            "required": ["task_description"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        task_desc = input.get("task_description", "")
        task_id = input.get("task_id", "") or f"task_{uuid.uuid4().hex[:8]}"

        if not task_desc:
            return ToolResult(content="No task_description provided", is_error=True)

        # Create sub-agent output directory
        task_dir = self._workspace.cwd / "sub_agents" / task_id
        task_dir.mkdir(parents=True, exist_ok=True)

        # Save task description
        (task_dir / "task.md").write_text(task_desc, encoding="utf-8")

        # Create child engine sharing the same workspace
        try:
            child_engine = self._engine_factory(self._workspace.session_id)
        except Exception as e:
            return ToolResult(content=f"Failed to create sub-agent: {e}", is_error=True)

        # Run the sub-agent asynchronously
        async def _run_child():
            result_events = []
            try:
                async for event in child_engine.run_turn(task_desc):
                    result_events.append(event.to_dict())

                # Save sub-agent output
                (task_dir / "result.json").write_text(
                    json.dumps(result_events, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )

                # Extract text content for easy reading
                text_parts = [e.get("text", "") for e in result_events if e.get("type") == "text_delta"]
                (task_dir / "output.md").write_text("".join(text_parts), encoding="utf-8")

                (task_dir / "status.txt").write_text("completed", encoding="utf-8")
            except Exception as e:
                (task_dir / "status.txt").write_text(f"failed: {e}", encoding="utf-8")

        task = asyncio.create_task(_run_child())
        self._running_tasks[task_id] = task

        return ToolResult(
            content=json.dumps({
                "task_id": task_id,
                "status": "started",
                "output_dir": f"sub_agents/{task_id}/",
                "message": (
                    f"Sub-agent started. It will write results to sub_agents/{task_id}/. "
                    "Check status.txt for completion, output.md for text, result.json for full events."
                ),
            }, indent=2)
        )
