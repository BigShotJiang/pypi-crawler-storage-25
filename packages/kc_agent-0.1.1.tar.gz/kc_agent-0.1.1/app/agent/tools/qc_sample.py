from __future__ import annotations

import json
import random
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult

# MONITOR_FREQUENCY → initial sampling rates for medium-confidence band
FREQUENCY_RATES = {"high": 0.5, "mid": 0.3, "low": 0.1}


class QCSampleTool(BaseTool):
    """Draw adaptive sample from production results for quality review.

    Stratifies by confidence band: review ALL low-confidence, sample medium
    at MONITOR_FREQUENCY rate, spot-check high. Decay function reduces
    sampling rate as consecutive batches pass threshold.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace

    @property
    def name(self) -> str:
        return "qc_sample"

    @property
    def description(self) -> str:
        return (
            "Draw an adaptive sample from production results for quality review. "
            "Stratifies by confidence band (low=review all, medium=sample, high=spot-check). "
            "Returns list of document IDs to review."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "results_path": {
                    "type": "string",
                    "description": "Path to results directory (default: output/results/)",
                },
            },
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        results_path = input.get("results_path", "output/results")

        try:
            results_dir = self._workspace.resolve_path(results_path)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        if not results_dir.is_dir():
            return ToolResult(content=f"Results directory not found: {results_path}", is_error=True)

        # Load MONITOR_FREQUENCY from .env
        medium_rate = 0.3
        env_path = self._workspace.cwd / ".env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("MONITOR_FREQUENCY="):
                    freq = line.split("=", 1)[1].strip().lower()
                    medium_rate = FREQUENCY_RATES.get(freq, 0.3)

        # Load all result files
        low, medium, high = [], [], []
        for f in sorted(results_dir.glob("*.json")):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                band = data.get("confidence_band", "medium")
                entry = {"file": f.name, "rule_id": data.get("rule_id", ""), "confidence": data.get("confidence", 0)}
                if band == "low":
                    low.append(entry)
                elif band == "high":
                    high.append(entry)
                else:
                    medium.append(entry)
            except (json.JSONDecodeError, KeyError):
                pass

        # Sampling strategy
        to_review = []

        # Low confidence: review ALL
        to_review.extend(low)

        # Medium confidence: sample at MONITOR_FREQUENCY rate
        if medium:
            sample_size = max(1, int(len(medium) * medium_rate))
            sampled = random.sample(medium, min(sample_size, len(medium)))
            to_review.extend(sampled)

        # High confidence: spot-check (10% or at least 1)
        if high:
            spot_size = max(1, int(len(high) * 0.1))
            spots = random.sample(high, min(spot_size, len(high)))
            to_review.extend(spots)

        report = {
            "total_results": len(low) + len(medium) + len(high),
            "distribution": {"low": len(low), "medium": len(medium), "high": len(high)},
            "sampling_rate_medium": medium_rate,
            "to_review": len(to_review),
            "review_list": to_review,
        }

        return ToolResult(content=json.dumps(report, ensure_ascii=False, indent=2))
