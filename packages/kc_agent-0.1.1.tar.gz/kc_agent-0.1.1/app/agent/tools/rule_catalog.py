from __future__ import annotations

import json
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult

REQUIRED_FIELDS = {"id", "source_ref", "description"}
RECOMMENDED_FIELDS = {"falsifiability_statement", "test_case_stub", "applicable_sections"}


class RuleCatalogTool(BaseTool):
    """CRUD on the rule registry with schema enforcement.

    Enforces required fields (id, source_ref, description) on create/update.
    Warns on missing recommended fields. Persists to rules/catalog.json.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace
        self._catalog_path = workspace.cwd / "rules" / "catalog.json"

    def _load(self) -> list[dict[str, Any]]:
        if not self._catalog_path.exists():
            return []
        try:
            data = json.loads(self._catalog_path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, KeyError):
            return []

    def _save(self, rules: list[dict[str, Any]]) -> None:
        self._catalog_path.parent.mkdir(parents=True, exist_ok=True)
        self._catalog_path.write_text(
            json.dumps(rules, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    @property
    def name(self) -> str:
        return "rule_catalog"

    @property
    def description(self) -> str:
        return (
            "CRUD on the rule registry. Operations: create, read, update, delete, list. "
            "Enforces required fields (id, source_ref, description) on create/update. "
            "Persists to rules/catalog.json."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["create", "read", "update", "delete", "list"],
                    "description": "Operation to perform",
                },
                "rule_id": {
                    "type": "string",
                    "description": "Rule ID (for read/update/delete)",
                },
                "data": {
                    "type": "object",
                    "description": "Rule data (for create/update). Must include: id, source_ref, description",
                },
            },
            "required": ["operation"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        op = input.get("operation", "")
        rule_id = input.get("rule_id", "")
        data = input.get("data", {})

        if op == "list":
            return self._list()
        elif op == "read":
            return self._read(rule_id or data.get("id", ""))
        elif op == "create":
            return self._create(data)
        elif op == "update":
            return self._update(rule_id or data.get("id", ""), data)
        elif op == "delete":
            return self._delete(rule_id or data.get("id", ""))
        else:
            return ToolResult(content=f"Unknown operation: {op}", is_error=True)

    def _list(self) -> ToolResult:
        rules = self._load()
        if not rules:
            return ToolResult(content="Catalog is empty. Use create to add rules.")
        summary = [f"- {r.get('id', '?')}: {r.get('description', '(no description)')[:80]}" for r in rules]
        return ToolResult(content=f"{len(rules)} rule(s):\n" + "\n".join(summary))

    def _read(self, rule_id: str) -> ToolResult:
        if not rule_id:
            return ToolResult(content="rule_id required for read", is_error=True)
        rules = self._load()
        rule = next((r for r in rules if r.get("id") == rule_id), None)
        if not rule:
            return ToolResult(content=f"Rule not found: {rule_id}", is_error=True)
        return ToolResult(content=json.dumps(rule, ensure_ascii=False, indent=2))

    def _create(self, data: dict[str, Any]) -> ToolResult:
        missing = REQUIRED_FIELDS - set(data.keys())
        if missing:
            return ToolResult(content=f"Missing required fields: {', '.join(missing)}", is_error=True)

        rules = self._load()
        if any(r.get("id") == data["id"] for r in rules):
            return ToolResult(content=f"Rule already exists: {data['id']}. Use update.", is_error=True)

        # Warn on missing recommended fields
        warnings = []
        missing_rec = RECOMMENDED_FIELDS - set(data.keys())
        if missing_rec:
            warnings.append(f"Missing recommended fields: {', '.join(missing_rec)}")

        rules.append(data)
        self._save(rules)

        msg = f"Created rule: {data['id']}"
        if warnings:
            msg += "\n" + "\n".join(warnings)
        return ToolResult(content=msg)

    def _update(self, rule_id: str, data: dict[str, Any]) -> ToolResult:
        if not rule_id:
            return ToolResult(content="rule_id required for update", is_error=True)
        rules = self._load()
        idx = next((i for i, r in enumerate(rules) if r.get("id") == rule_id), None)
        if idx is None:
            return ToolResult(content=f"Rule not found: {rule_id}", is_error=True)

        rules[idx].update(data)
        rules[idx]["id"] = rule_id  # Prevent ID change
        self._save(rules)
        return ToolResult(content=f"Updated rule: {rule_id}")

    def _delete(self, rule_id: str) -> ToolResult:
        if not rule_id:
            return ToolResult(content="rule_id required for delete", is_error=True)
        rules = self._load()
        new_rules = [r for r in rules if r.get("id") != rule_id]
        if len(new_rules) == len(rules):
            return ToolResult(content=f"Rule not found: {rule_id}", is_error=True)
        self._save(new_rules)
        return ToolResult(content=f"Deleted rule: {rule_id}")
