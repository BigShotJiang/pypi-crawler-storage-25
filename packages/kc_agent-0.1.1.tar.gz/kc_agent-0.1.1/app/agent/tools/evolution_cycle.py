from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from ..corner_case_registry import CornerCaseRegistry, CornerCase
from ..workspace import Workspace
from .base import BaseTool, ToolResult


class EvolutionCycleTool(BaseTool):
    """Run one structured iteration of the evolution loop.

    Enforces the cycle: diagnose → classify → fix instructions → log.
    Classification is CODE: counts failure rate, applies threshold.
    Routes corner cases to CornerCaseRegistry automatically.
    Checks evolution log for repeated patterns (anti-pattern detection).
    """

    def __init__(self, workspace: Workspace, corner_cases: CornerCaseRegistry) -> None:
        self._workspace = workspace
        self._corner_cases = corner_cases

    @property
    def name(self) -> str:
        return "evolution_cycle"

    @property
    def description(self) -> str:
        return (
            "Run one structured iteration of diagnose → classify → fix → log. "
            "Provide test results with failures. The tool classifies failures as "
            "systemic (>10%) or corner case (<10%), routes corner cases to the "
            "registry, and saves a structured evolution log entry."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "rule_id": {
                    "type": "string",
                    "description": "Rule being evolved",
                },
                "total_test_docs": {
                    "type": "integer",
                    "description": "Total number of documents tested",
                },
                "failed_docs": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "doc_id": {"type": "string"},
                            "diagnosis": {
                                "type": "string",
                                "enum": ["parsing", "extraction", "judgment", "scope"],
                            },
                            "root_cause": {"type": "string"},
                        },
                    },
                    "description": "List of failed documents with diagnosis",
                },
                "accuracy_before": {
                    "type": "number",
                    "description": "Accuracy before this cycle",
                },
                "fix_applied": {
                    "type": "string",
                    "description": "Description of the fix applied (or planned)",
                },
            },
            "required": ["rule_id", "total_test_docs", "failed_docs", "accuracy_before"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        rule_id = input.get("rule_id", "")
        total = input.get("total_test_docs", 0)
        failures = input.get("failed_docs", [])
        accuracy_before = input.get("accuracy_before", 0)
        fix_applied = input.get("fix_applied", "")

        if not rule_id or total <= 0:
            return ToolResult(content="rule_id and total_test_docs required", is_error=True)

        # Read systemic threshold from .env (default 10%)
        systemic_threshold = 0.10
        env_path = self._workspace.cwd / ".env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("SYSTEMIC_THRESHOLD="):
                    try:
                        systemic_threshold = float(line.split("=", 1)[1].strip())
                    except ValueError:
                        pass

        # CLASSIFY (code, not LLM judgment)
        failure_rate = len(failures) / total
        classification = "systemic" if failure_rate >= systemic_threshold else "corner_case"

        # Check for repeated patterns in evolution log
        repeated_patterns = self._check_repeated_patterns(rule_id, failures)

        # Route corner cases to registry
        corner_cases_added = []
        if classification == "corner_case":
            for f in failures:
                case = CornerCase(
                    id=f"CC_{rule_id}_{f.get('doc_id', 'unknown')}",
                    rule_id=rule_id,
                    detection_pattern=f.get("root_cause", "unknown pattern"),
                    resolution=fix_applied or "pending fix",
                    affected_documents=[f.get("doc_id", "")],
                )
                self._corner_cases.add(case)
                corner_cases_added.append(case.id)

        # Count iteration
        log_dir = self._workspace.cwd / "logs" / "evolution"
        log_dir.mkdir(parents=True, exist_ok=True)
        existing = list(log_dir.glob(f"{rule_id}_iter_*.json"))
        iteration = len(existing) + 1

        # Build log entry
        log_entry = {
            "iteration": iteration,
            "rule_id": rule_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "accuracy_before": accuracy_before,
            "total_docs": total,
            "failed_docs": len(failures),
            "failure_rate": round(failure_rate, 3),
            "classification": classification,
            "failures": failures,
            "fix_applied": fix_applied,
            "corner_cases_added": corner_cases_added,
            "repeated_patterns": repeated_patterns,
        }

        # Save log
        log_path = log_dir / f"{rule_id}_iter_{iteration:03d}.json"
        log_path.write_text(json.dumps(log_entry, ensure_ascii=False, indent=2), encoding="utf-8")

        # Build response
        response = {
            "iteration": iteration,
            "classification": classification,
            "failure_rate": f"{failure_rate:.1%}",
            "action": (
                "REWRITE component — systemic issue affecting >10% of documents"
                if classification == "systemic"
                else f"Recorded {len(corner_cases_added)} corner case(s) — do NOT patch main workflow"
            ),
            "repeated_patterns": repeated_patterns,
            "log_saved": str(log_path.relative_to(self._workspace.cwd)),
        }

        if repeated_patterns:
            response["warning"] = (
                "Repeated failure patterns detected from previous iterations. "
                "Consider escalating approach (e.g., prompt tweak → logic rewrite)."
            )

        return ToolResult(content=json.dumps(response, ensure_ascii=False, indent=2))

    def _check_repeated_patterns(self, rule_id: str, failures: list[dict]) -> list[str]:
        """Check if current failures match patterns from previous iterations."""
        log_dir = self._workspace.cwd / "logs" / "evolution"
        if not log_dir.exists():
            return []

        current_causes = {f.get("root_cause", "").lower() for f in failures if f.get("root_cause")}
        repeated = []

        for log_file in sorted(log_dir.glob(f"{rule_id}_iter_*.json")):
            try:
                data = json.loads(log_file.read_text(encoding="utf-8"))
                prev_causes = {
                    f.get("root_cause", "").lower()
                    for f in data.get("failures", [])
                    if f.get("root_cause")
                }
                overlap = current_causes & prev_causes
                for cause in overlap:
                    if cause and cause not in repeated:
                        repeated.append(cause)
            except (json.JSONDecodeError, KeyError):
                pass

        return repeated
