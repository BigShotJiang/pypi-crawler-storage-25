from __future__ import annotations

from typing import Any

from .base import BaseTool, ToolResult


class ToolRegistry:
    """Manages tool registration and dispatch.

    In Block 1 this is empty. Adding a tool later:
        registry.register(SandboxExecTool(workspace))
    The engine loop needs zero changes.
    """

    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        self._tools[tool.name] = tool

    def schemas_openai(self) -> list[dict[str, Any]]:
        """Return tool schemas in OpenAI function-calling format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.input_schema,
                },
            }
            for t in self._tools.values()
        ]

    async def execute(self, name: str, input: dict[str, Any]) -> ToolResult:
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(content=f"Unknown tool: {name}", is_error=True)
        return await tool.execute(input)
