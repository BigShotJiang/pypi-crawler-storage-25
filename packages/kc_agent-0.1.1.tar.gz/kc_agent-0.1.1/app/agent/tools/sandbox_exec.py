from __future__ import annotations

import asyncio
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult

MAX_OUTPUT = 10_000


class SandboxExecTool(BaseTool):
    """Execute shell commands in the workspace directory.

    Uses asyncio.create_subprocess_shell so pipes, redirects, && all work.
    Output (stdout + stderr combined) is capped at 10K chars.
    """

    def __init__(self, workspace: Workspace, timeout: int = 30) -> None:
        self._workspace = workspace
        self._timeout = timeout

    @property
    def name(self) -> str:
        return "sandbox_exec"

    @property
    def description(self) -> str:
        return (
            "Execute a shell command in the workspace directory. "
            "Use for running Python scripts, installing packages, listing files, etc. "
            "Pipes, redirects, and chained commands (&&) are supported."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute (e.g. 'python script.py', 'ls -la')",
                },
            },
            "required": ["command"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        command = input.get("command", "")
        if not command.strip():
            return ToolResult(content="No command provided", is_error=True)

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                cwd=str(self._workspace.cwd),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            try:
                stdout, _ = await asyncio.wait_for(
                    proc.communicate(), timeout=self._timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                return ToolResult(
                    content=f"Command timed out after {self._timeout}s",
                    is_error=True,
                )

            output = stdout.decode("utf-8", errors="replace") if stdout else ""
            truncated = len(output) > MAX_OUTPUT
            if truncated:
                output = output[:MAX_OUTPUT] + "\n[truncated]"

            exit_code = proc.returncode
            result = output
            if exit_code != 0:
                result += f"\n[exit code: {exit_code}]"

            return ToolResult(content=result, is_error=exit_code != 0)

        except Exception as e:
            return ToolResult(content=f"Execution error: {e}", is_error=True)
