from __future__ import annotations

import re
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult

MAX_RESULTS = 20
CONTEXT_CHARS = 200


class DocumentSearchTool(BaseTool):
    """Full-text search across parsed documents in the workspace.

    Searches text files and parsed document outputs. Returns passages
    with source coordinates (file, approximate line). Agent can do
    semantic search via SandboxExec + embeddings if needed — this tool
    covers the common case of keyword/regex search.
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace

    @property
    def name(self) -> str:
        return "document_search"

    @property
    def description(self) -> str:
        return (
            "Search for text across documents in the workspace. Returns matching "
            "passages with file path and context. Supports plain text and regex queries."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query (plain text or regex pattern)",
                },
                "path": {
                    "type": "string",
                    "description": "Subdirectory to search in (default: entire workspace)",
                },
                "max_results": {
                    "type": "integer",
                    "description": f"Maximum results to return (default: {MAX_RESULTS})",
                },
                "regex": {
                    "type": "boolean",
                    "description": "Treat query as regex pattern (default: false)",
                },
            },
            "required": ["query"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        query = input.get("query", "")
        search_path = input.get("path", ".")
        max_results = input.get("max_results", MAX_RESULTS)
        use_regex = input.get("regex", False)

        if not query:
            return ToolResult(content="No query provided", is_error=True)

        try:
            search_dir = self._workspace.resolve_path(search_path)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        if not search_dir.is_dir():
            return ToolResult(content=f"Not a directory: {search_path}", is_error=True)

        # Compile pattern
        try:
            if use_regex:
                pattern = re.compile(query, re.IGNORECASE)
            else:
                pattern = re.compile(re.escape(query), re.IGNORECASE)
        except re.error as e:
            return ToolResult(content=f"Invalid regex: {e}", is_error=True)

        # Search files
        results = []
        text_extensions = {".txt", ".md", ".json", ".py", ".csv", ".env", ".log"}

        for file_path in sorted(search_dir.rglob("*")):
            if not file_path.is_file():
                continue
            if file_path.suffix.lower() not in text_extensions:
                continue
            if "__pycache__" in str(file_path):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            for match in pattern.finditer(content):
                start = max(0, match.start() - CONTEXT_CHARS)
                end = min(len(content), match.end() + CONTEXT_CHARS)
                context = content[start:end].strip()

                # Find line number
                line_num = content[:match.start()].count("\n") + 1

                rel_path = file_path.relative_to(self._workspace.cwd)
                results.append({
                    "file": str(rel_path),
                    "line": line_num,
                    "match": match.group(),
                    "context": context,
                })

                if len(results) >= max_results:
                    break

            if len(results) >= max_results:
                break

        if not results:
            return ToolResult(content=f"No matches found for: {query}")

        lines = []
        for r in results:
            lines.append(f"--- {r['file']}:{r['line']} ---")
            lines.append(r["context"])
            lines.append("")

        return ToolResult(content=f"Found {len(results)} match(es):\n\n" + "\n".join(lines))
