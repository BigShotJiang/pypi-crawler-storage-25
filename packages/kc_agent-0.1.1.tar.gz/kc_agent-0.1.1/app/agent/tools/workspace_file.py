from __future__ import annotations

from typing import Any

from ..version_manager import VersionManager
from ..workspace import Workspace
from .base import BaseTool, ToolResult

MAX_READ = 50_000


class WorkspaceFileTool(BaseTool):
    """Read, write, or list files in the workspace directory.

    All paths are resolved relative to the workspace root with
    traversal protection — absolute paths and .. escapes are rejected.
    VersionManager hooks into writes for automatic versioning.
    """

    def __init__(self, workspace: Workspace, version_manager: VersionManager | None = None) -> None:
        self._workspace = workspace
        self._version_manager = version_manager

    @property
    def name(self) -> str:
        return "workspace_file"

    @property
    def description(self) -> str:
        return (
            "Read, write, or list files in the workspace directory. "
            "Operations: read (returns file content), write (creates/overwrites a file), "
            "list (shows directory contents)."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["read", "write", "list"],
                    "description": "The file operation to perform",
                },
                "path": {
                    "type": "string",
                    "description": "Relative path within the workspace. Defaults to '.' for list.",
                },
                "content": {
                    "type": "string",
                    "description": "File content to write (required for write operation)",
                },
            },
            "required": ["operation"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        op = input.get("operation", "")
        path = input.get("path", ".")
        content = input.get("content", "")

        try:
            if op == "read":
                return self._read(path)
            elif op == "write":
                return self._write(path, content)
            elif op == "list":
                return self._list(path)
            else:
                return ToolResult(content=f"Unknown operation: {op}", is_error=True)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)
        except Exception as e:
            return ToolResult(content=f"File error: {e}", is_error=True)

    def _read(self, path: str) -> ToolResult:
        resolved = self._workspace.resolve_path(path)
        if not resolved.is_file():
            return ToolResult(content=f"File not found: {path}", is_error=True)
        text = resolved.read_text(encoding="utf-8", errors="replace")
        if len(text) > MAX_READ:
            text = text[:MAX_READ] + "\n[truncated]"
        return ToolResult(content=text)

    def _write(self, path: str, content: str) -> ToolResult:
        if not path or path == ".":
            return ToolResult(content="Path required for write operation", is_error=True)
        resolved = self._workspace.resolve_path(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        resolved.write_text(content, encoding="utf-8")

        # Version tracking (structural — cannot be bypassed)
        trace_id = None
        if self._version_manager:
            trace_id = self._version_manager.on_write(path, content)

        msg = f"Wrote {len(content)} chars to {path}"
        if trace_id:
            msg += f" [trace: {trace_id}]"
        return ToolResult(content=msg)

    def _list(self, path: str) -> ToolResult:
        resolved = self._workspace.resolve_path(path)
        if not resolved.is_dir():
            return ToolResult(content=f"Not a directory: {path}", is_error=True)
        entries = sorted(resolved.iterdir(), key=lambda p: (not p.is_dir(), p.name))
        if not entries:
            return ToolResult(content="(empty directory)")
        lines = []
        for entry in entries:
            rel = entry.relative_to(self._workspace.cwd)
            marker = "[dir] " if entry.is_dir() else "      "
            lines.append(f"{marker}{rel}")
        return ToolResult(content="\n".join(lines))
