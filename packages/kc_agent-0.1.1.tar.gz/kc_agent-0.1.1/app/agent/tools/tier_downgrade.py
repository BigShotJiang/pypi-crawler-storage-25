from __future__ import annotations

import json
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult
from .worker_llm_call import WorkerLLMCallTool


class TierDowngradeTool(BaseTool):
    """Test a workflow step at a lower worker LLM tier.

    Compares accuracy at the target tier against the current baseline.
    Reports accuracy delta and recommendation (keep or downgrade).
    Used during distillation to find the minimum viable tier.
    """

    def __init__(self, workspace: Workspace, worker_llm: WorkerLLMCallTool) -> None:
        self._workspace = workspace
        self._worker = worker_llm

    @property
    def name(self) -> str:
        return "tier_downgrade"

    @property
    def description(self) -> str:
        return (
            "Test a workflow step at a lower worker LLM tier. Compares accuracy "
            "against baseline. Use during distillation to find the cheapest tier "
            "that meets accuracy threshold."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "rule_id": {
                    "type": "string",
                    "description": "Rule ID being tested",
                },
                "prompt": {
                    "type": "string",
                    "description": "The extraction/judgment prompt to test",
                },
                "test_inputs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of document text chunks to test against",
                },
                "expected_outputs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Expected correct outputs for each test input",
                },
                "current_tier": {
                    "type": "string",
                    "description": "Current tier (baseline)",
                },
                "target_tier": {
                    "type": "string",
                    "description": "Lower tier to test",
                },
            },
            "required": ["rule_id", "prompt", "test_inputs", "expected_outputs", "current_tier", "target_tier"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        rule_id = input.get("rule_id", "")
        prompt = input.get("prompt", "")
        test_inputs = input.get("test_inputs", [])
        expected = input.get("expected_outputs", [])
        current_tier = input.get("current_tier", "tier1")
        target_tier = input.get("target_tier", "tier2")

        if not test_inputs or not expected or len(test_inputs) != len(expected):
            return ToolResult(
                content="test_inputs and expected_outputs must be non-empty and same length",
                is_error=True,
            )

        # Test at both tiers
        current_results = await self._run_tier(current_tier, prompt, test_inputs)
        target_results = await self._run_tier(target_tier, prompt, test_inputs)

        if current_results is None:
            return ToolResult(content=f"Failed to run at {current_tier}", is_error=True)
        if target_results is None:
            return ToolResult(content=f"Failed to run at {target_tier}", is_error=True)

        # Compare accuracy
        current_acc = self._accuracy(current_results, expected)
        target_acc = self._accuracy(target_results, expected)
        delta = current_acc - target_acc

        # Read threshold from .env
        threshold = 0.9
        env_path = self._workspace.cwd / ".env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("WORKFLOW_ACCURACY="):
                    try:
                        threshold = float(line.split("=", 1)[1].strip())
                    except ValueError:
                        pass

        recommend = "downgrade" if target_acc >= threshold and delta <= 0.05 else "keep_current"

        report = {
            "rule_id": rule_id,
            "current_tier": current_tier,
            "target_tier": target_tier,
            "current_accuracy": round(current_acc, 3),
            "target_accuracy": round(target_acc, 3),
            "accuracy_delta": round(delta, 3),
            "threshold": threshold,
            "recommendation": recommend,
            "test_count": len(test_inputs),
        }

        return ToolResult(content=json.dumps(report, ensure_ascii=False, indent=2))

    async def _run_tier(self, tier: str, prompt: str, inputs: list[str]) -> list[str] | None:
        results = []
        for text in inputs:
            full_prompt = f"{prompt}\n\nDocument text:\n{text}"
            result = await self._worker.execute({"tier": tier, "prompt": full_prompt, "max_tokens": 2048})
            if result.is_error:
                return None
            try:
                data = json.loads(result.content)
                results.append(data.get("response", ""))
            except json.JSONDecodeError:
                results.append(result.content)
        return results

    @staticmethod
    def _accuracy(outputs: list[str], expected: list[str]) -> float:
        if not expected:
            return 0.0
        matches = sum(
            1 for o, e in zip(outputs, expected)
            if e.strip().lower() in o.strip().lower()
        )
        return matches / len(expected)
