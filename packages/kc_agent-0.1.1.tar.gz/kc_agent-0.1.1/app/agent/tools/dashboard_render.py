from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult


class DashboardRenderTool(BaseTool):
    """Generate a self-contained HTML dashboard from project metrics.

    Aggregates: accuracy by rule, confidence distribution, evolution timeline,
    QC results. Uses inline CSS/JS (no external dependencies).
    """

    def __init__(self, workspace: Workspace) -> None:
        self._workspace = workspace

    @property
    def name(self) -> str:
        return "dashboard_render"

    @property
    def description(self) -> str:
        return (
            "Generate a self-contained HTML dashboard from project metrics. "
            "Aggregates accuracy, confidence distribution, evolution history, "
            "and QC results. Saves to output/dashboards/."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "output_path": {
                    "type": "string",
                    "description": "Output file path (default: output/dashboards/dashboard.html)",
                },
            },
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        output_path = input.get("output_path", "output/dashboards/dashboard.html")

        metrics = self._collect_metrics()
        html = self._render_html(metrics)

        try:
            resolved = self._workspace.resolve_path(output_path)
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.write_text(html, encoding="utf-8")
            return ToolResult(content=f"Dashboard saved to {output_path} ({len(html)} bytes)")
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

    def _collect_metrics(self) -> dict[str, Any]:
        metrics: dict[str, Any] = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "rules": [],
            "confidence_distribution": {"low": 0, "medium": 0, "high": 0},
            "evolution_iterations": 0,
            "qc_batches": 0,
        }

        # Rules from catalog
        catalog = self._workspace.cwd / "rules" / "catalog.json"
        if catalog.exists():
            try:
                rules = json.loads(catalog.read_text(encoding="utf-8"))
                if isinstance(rules, list):
                    metrics["rules"] = [{"id": r.get("id", "?"), "description": r.get("description", "")[:60]} for r in rules]
            except json.JSONDecodeError:
                pass

        # Results for confidence distribution
        results_dir = self._workspace.cwd / "output" / "results"
        if results_dir.exists():
            for f in results_dir.glob("*.json"):
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    band = data.get("confidence_band", "medium")
                    if band in metrics["confidence_distribution"]:
                        metrics["confidence_distribution"][band] += 1
                except (json.JSONDecodeError, KeyError):
                    pass

        # Evolution iterations
        evo_dir = self._workspace.cwd / "logs" / "evolution"
        if evo_dir.exists():
            metrics["evolution_iterations"] = len(list(evo_dir.glob("*.json")))

        # QC batches
        qc_dir = self._workspace.cwd / "output" / "qc"
        if qc_dir.exists():
            metrics["qc_batches"] = len(list(qc_dir.glob("*.json")))

        return metrics

    def _render_html(self, metrics: dict[str, Any]) -> str:
        rules_html = ""
        for r in metrics.get("rules", []):
            rules_html += f"<tr><td>{r['id']}</td><td>{r['description']}</td></tr>\n"

        conf = metrics.get("confidence_distribution", {})
        total_results = sum(conf.values())

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>KC Agent Dashboard</title>
<style>
body {{ font-family: -apple-system, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #0a0a0a; color: #e5e5e5; }}
h1 {{ color: #a3a3a3; font-size: 1.5em; }}
h2 {{ color: #737373; font-size: 1.1em; margin-top: 2em; }}
.card {{ background: #171717; border: 1px solid #262626; border-radius: 8px; padding: 16px; margin: 12px 0; }}
.metric {{ display: inline-block; margin-right: 32px; }}
.metric .value {{ font-size: 2em; font-weight: bold; color: #22c55e; }}
.metric .label {{ font-size: 0.85em; color: #737373; }}
table {{ width: 100%; border-collapse: collapse; }}
th, td {{ text-align: left; padding: 8px; border-bottom: 1px solid #262626; }}
th {{ color: #737373; font-size: 0.85em; }}
.bar {{ height: 20px; border-radius: 4px; display: inline-block; }}
.bar-low {{ background: #ef4444; }}
.bar-med {{ background: #eab308; }}
.bar-high {{ background: #22c55e; }}
.timestamp {{ color: #525252; font-size: 0.8em; }}
</style>
</head>
<body>
<h1>KC Agent Dashboard</h1>
<p class="timestamp">Generated: {metrics.get('generated_at', '')}</p>

<div class="card">
<div class="metric"><span class="value">{len(metrics.get('rules', []))}</span><br><span class="label">Rules</span></div>
<div class="metric"><span class="value">{total_results}</span><br><span class="label">Results</span></div>
<div class="metric"><span class="value">{metrics.get('evolution_iterations', 0)}</span><br><span class="label">Evolution Cycles</span></div>
<div class="metric"><span class="value">{metrics.get('qc_batches', 0)}</span><br><span class="label">QC Batches</span></div>
</div>

<h2>Confidence Distribution</h2>
<div class="card">
<div>Low: {conf.get('low', 0)} &nbsp; <span class="bar bar-low" style="width:{conf.get('low',0)*5}px"></span></div>
<div>Medium: {conf.get('medium', 0)} &nbsp; <span class="bar bar-med" style="width:{conf.get('medium',0)*5}px"></span></div>
<div>High: {conf.get('high', 0)} &nbsp; <span class="bar bar-high" style="width:{conf.get('high',0)*5}px"></span></div>
</div>

<h2>Rules</h2>
<div class="card">
<table>
<tr><th>ID</th><th>Description</th></tr>
{rules_html if rules_html else '<tr><td colspan="2">No rules in catalog yet</td></tr>'}
</table>
</div>

</body>
</html>"""
