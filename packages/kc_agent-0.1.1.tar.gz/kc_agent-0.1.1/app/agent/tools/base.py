from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class ToolResult:
    content: str
    is_error: bool = False


class BaseTool(ABC):
    """Abstract base for all KC Agent tools.

    Subclass this to add a new tool. Register it with ToolRegistry.
    The engine's tool-use loop will discover it automatically via schemas()
    and dispatch to execute() when the LLM invokes it.
    """

    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def description(self) -> str: ...

    @property
    @abstractmethod
    def input_schema(self) -> dict[str, Any]: ...

    @abstractmethod
    async def execute(self, input: dict[str, Any]) -> ToolResult: ...
