from __future__ import annotations

import io
import logging
from pathlib import Path
from typing import Any

from ..workspace import Workspace
from .base import BaseTool, ToolResult

logger = logging.getLogger(__name__)

MAX_OUTPUT = 50_000
MIN_CHARS_PER_PAGE = 50  # Below this → likely image-based, escalate


class DocumentParseTool(BaseTool):
    """Parse documents through a hard-coded escalation chain.

    The document-parsing meta skill's methodology is baked into this tool:
      Level 1: PyMuPDF (free, fast, local) — works for most text-based PDFs
      Level 2: MineRU API (if configured) — for scanned/complex documents
      Level 3: OCR models from SiliconFlow — fallback via vision models

    The agent doesn't choose the method. The tool starts cheap and escalates
    only when quality is insufficient. The agent calls document_parse(path=...)
    and gets structured text back with metadata about which method succeeded.

    For future deployments, developer users can configure local VLMs or
    custom parsers — the escalation chain is extensible.
    """

    def __init__(
        self,
        workspace: Workspace,
        *,
        mineru_api_url: str = "",
        mineru_api_key: str = "",
        siliconflow_api_key: str = "",
        siliconflow_base_url: str = "https://api.siliconflow.cn/v1",
        ocr_model_tier1: str = "",
    ) -> None:
        self._workspace = workspace
        self._mineru_api_url = mineru_api_url
        self._mineru_api_key = mineru_api_key
        self._sf_api_key = siliconflow_api_key
        self._sf_base_url = siliconflow_base_url
        self._ocr_model = ocr_model_tier1

    @property
    def name(self) -> str:
        return "document_parse"

    @property
    def description(self) -> str:
        return (
            "Parse a document (PDF, DOCX, TXT) and extract its text content. "
            "Internally uses an escalation chain: text extraction (PyMuPDF) → "
            "API parser (MineRU) → OCR models. Starts cheap, escalates if needed. "
            "Use force_method to skip the chain and use a specific parser."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Relative path to the document in the workspace",
                },
                "pages": {
                    "type": "string",
                    "description": "Page range to extract, e.g. '1-5', '3', '10-20'. Omit for all pages.",
                },
                "force_method": {
                    "type": "string",
                    "enum": ["pymupdf", "mineru", "ocr"],
                    "description": "Force a specific parsing method, skipping the escalation chain.",
                },
            },
            "required": ["path"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        path_str = input.get("path", "")
        pages = input.get("pages")
        force = input.get("force_method")

        if not path_str:
            return ToolResult(content="No path provided", is_error=True)

        try:
            resolved = self._workspace.resolve_path(path_str)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        if not resolved.is_file():
            return ToolResult(content=f"File not found: {path_str}", is_error=True)

        page_range = self._parse_page_range(pages)

        # Forced method — skip escalation
        if force:
            return await self._run_method(force, resolved, page_range)

        # Escalation chain
        # Level 1: PyMuPDF
        result = await self._try_pymupdf(resolved, page_range)
        if result and self._quality_ok(result, resolved, page_range):
            return ToolResult(content=self._format_output(result, "pymupdf", resolved))

        # Level 2: MineRU API
        if self._mineru_api_url:
            result = await self._try_mineru(resolved, page_range)
            if result and self._quality_ok(result, resolved, page_range):
                return ToolResult(content=self._format_output(result, "mineru", resolved))

        # Level 3: OCR via SiliconFlow
        if self._sf_api_key and self._ocr_model:
            result = await self._try_ocr(resolved, page_range)
            if result:
                return ToolResult(content=self._format_output(result, "ocr", resolved))

        # Fallback: return whatever Level 1 got (even if low quality)
        if result:
            return ToolResult(
                content=self._format_output(result, "pymupdf (low quality)", resolved)
            )

        return ToolResult(
            content=f"Could not extract text from {path_str}. "
            "The document may be image-only. Configure MineRU API or OCR models in .env.",
            is_error=True,
        )

    async def _run_method(
        self, method: str, path: Path, page_range: tuple[int, int] | None
    ) -> ToolResult:
        if method == "pymupdf":
            result = await self._try_pymupdf(path, page_range)
        elif method == "mineru":
            result = await self._try_mineru(path, page_range)
        elif method == "ocr":
            result = await self._try_ocr(path, page_range)
        else:
            return ToolResult(content=f"Unknown method: {method}", is_error=True)

        if result:
            return ToolResult(content=self._format_output(result, method, path))
        return ToolResult(content=f"Method '{method}' failed for this document", is_error=True)

    async def _try_pymupdf(
        self, path: Path, page_range: tuple[int, int] | None
    ) -> str | None:
        try:
            import fitz

            doc = fitz.open(str(path))
            pages = []
            start, end = page_range if page_range else (0, len(doc) - 1)
            for i in range(max(0, start), min(end + 1, len(doc))):
                page = doc[i]
                text = page.get_text()
                if text.strip():
                    pages.append(f"--- Page {i + 1} ---\n{text.strip()}")
            doc.close()
            return "\n\n".join(pages) if pages else ""
        except Exception as e:
            logger.warning(f"PyMuPDF failed: {e}")
            return None

    async def _try_mineru(
        self, path: Path, page_range: tuple[int, int] | None
    ) -> str | None:
        """Call MineRU API for document parsing. Placeholder — implement when API is available."""
        # TODO: Implement MineRU API call
        # POST to self._mineru_api_url with file upload
        # Parse response for extracted text
        logger.info("MineRU API not yet implemented")
        return None

    async def _try_ocr(
        self, path: Path, page_range: tuple[int, int] | None
    ) -> str | None:
        """Use OCR vision models via OpenAI-compatible API (SiliconFlow/Aliyun)."""
        if not self._sf_api_key or not self._ocr_model:
            logger.info("OCR not configured (no API key or model)")
            return None

        try:
            import base64
            import fitz
            import httpx

            doc = fitz.open(str(path))
            start, end = page_range if page_range else (0, len(doc) - 1)
            pages = []

            async with httpx.AsyncClient(timeout=120) as client:
                for i in range(max(0, start), min(end + 1, len(doc))):
                    page = doc[i]
                    pix = page.get_pixmap(dpi=150)
                    img_b64 = base64.b64encode(pix.tobytes("png")).decode()

                    resp = await client.post(
                        f"{self._sf_base_url}/chat/completions",
                        headers={"Authorization": f"Bearer {self._sf_api_key}"},
                        json={
                            "model": self._ocr_model,
                            "messages": [{
                                "role": "user",
                                "content": [
                                    {"type": "text", "text": "Extract all text from this image. Output the text only, preserving original layout."},
                                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
                                ],
                            }],
                            "max_tokens": 4000,
                        },
                    )
                    if resp.status_code == 200:
                        text = resp.json()["choices"][0]["message"]["content"]
                        if text.strip():
                            pages.append(f"--- Page {i + 1} ---\n{text.strip()}")
                    else:
                        logger.warning(f"OCR page {i+1} failed: {resp.status_code}")

            doc.close()
            return "\n\n".join(pages) if pages else None

        except Exception as e:
            logger.warning(f"OCR failed: {e}")
            return None

    def _quality_ok(
        self, text: str, path: Path, page_range: tuple[int, int] | None
    ) -> bool:
        """Hard-coded quality heuristics from document-parsing methodology."""
        if not text or not text.strip():
            return False

        # Estimate expected page count
        try:
            import fitz

            doc = fitz.open(str(path))
            total_pages = len(doc)
            doc.close()
        except Exception:
            total_pages = 1

        if page_range:
            expected_pages = page_range[1] - page_range[0] + 1
        else:
            expected_pages = total_pages

        # Check: less than 50 chars per page → likely image-based
        chars_per_page = len(text) / max(expected_pages, 1)
        if chars_per_page < MIN_CHARS_PER_PAGE:
            return False

        # Check: high ratio of replacement characters → garbled
        replacement_ratio = text.count("\ufffd") / max(len(text), 1)
        if replacement_ratio > 0.1:
            return False

        return True

    def _format_output(self, text: str, method: str, path: Path) -> str:
        if len(text) > MAX_OUTPUT:
            text = text[:MAX_OUTPUT] + "\n[truncated]"
        return f"[Parsed via {method}]\n\n{text}"

    @staticmethod
    def _parse_page_range(pages: str | None) -> tuple[int, int] | None:
        if not pages:
            return None
        pages = pages.strip()
        if "-" in pages:
            parts = pages.split("-", 1)
            try:
                return (int(parts[0]) - 1, int(parts[1]) - 1)  # 0-indexed
            except ValueError:
                return None
        try:
            p = int(pages) - 1
            return (p, p)
        except ValueError:
            return None
