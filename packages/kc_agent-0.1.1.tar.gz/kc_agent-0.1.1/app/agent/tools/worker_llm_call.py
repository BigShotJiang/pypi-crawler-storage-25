from __future__ import annotations

import json
from typing import Any

import httpx

from ..workspace import Workspace
from .base import BaseTool, ToolResult


class WorkerLLMCallTool(BaseTool):
    """Call a worker LLM at a specified tier for verification tasks.

    Reads tier-to-model mapping from the workspace .env. Routes through
    the configured API provider. Returns response with token count and cost.
    Used for distillation testing and workflow execution.
    """

    def __init__(
        self,
        workspace: Workspace,
        *,
        api_key: str = "",
        base_url: str = "https://api.siliconflow.cn/v1",
    ) -> None:
        self._workspace = workspace
        self._api_key = api_key
        self._base_url = base_url
        self._tier_models: dict[str, list[str]] = {}
        self._load_tiers()

    def _load_tiers(self) -> None:
        """Load tier→model mapping from workspace .env."""
        env_path = self._workspace.cwd / ".env"
        if not env_path.exists():
            return
        for line in env_path.read_text(encoding="utf-8").splitlines():
            for tier in ("TIER1", "TIER2", "TIER3", "TIER4"):
                if line.startswith(f"{tier}="):
                    models = [m.strip() for m in line.split("=", 1)[1].split(",") if m.strip()]
                    self._tier_models[tier.lower()] = models

    @property
    def name(self) -> str:
        return "worker_llm_call"

    @property
    def description(self) -> str:
        return (
            "Call a worker LLM at a specified tier (tier1-tier4) for extraction, "
            "judgment, or other verification tasks. Tier1 is most capable/expensive, "
            "tier4 is cheapest. Returns response with model used and token counts."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "tier": {
                    "type": "string",
                    "enum": ["tier1", "tier2", "tier3", "tier4"],
                    "description": "Worker LLM tier to use",
                },
                "prompt": {
                    "type": "string",
                    "description": "The user/task prompt to send",
                },
                "system_prompt": {
                    "type": "string",
                    "description": "Optional system prompt for context",
                },
                "max_tokens": {
                    "type": "integer",
                    "description": "Maximum tokens in response (default 4096)",
                },
            },
            "required": ["tier", "prompt"],
        }

    async def execute(self, input: dict[str, Any]) -> ToolResult:
        tier = input.get("tier", "tier2")
        prompt = input.get("prompt", "")
        system_prompt = input.get("system_prompt")
        max_tokens = input.get("max_tokens", 4096)

        if not prompt:
            return ToolResult(content="No prompt provided", is_error=True)

        if not self._api_key:
            return ToolResult(content="Worker LLM API key not configured", is_error=True)

        # Reload tiers (may have changed)
        self._load_tiers()
        models = self._tier_models.get(tier, [])
        if not models:
            return ToolResult(
                content=f"No models configured for {tier}. Check .env TIER1-TIER4 settings.",
                is_error=True,
            )

        messages: list[dict[str, Any]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        # Try models in order for the tier
        last_error = ""
        for model in models:
            try:
                async with httpx.AsyncClient(timeout=120) as client:
                    resp = await client.post(
                        f"{self._base_url}/chat/completions",
                        headers={"Authorization": f"Bearer {self._api_key}"},
                        json={
                            "model": model,
                            "messages": messages,
                            "max_tokens": max_tokens,
                        },
                    )
                    if resp.status_code == 200:
                        data = resp.json()
                        choice = data["choices"][0]
                        usage = data.get("usage", {})
                        response_text = choice["message"]["content"]

                        result = {
                            "response": response_text,
                            "model_used": model,
                            "tier": tier,
                            "tokens_in": usage.get("prompt_tokens", 0),
                            "tokens_out": usage.get("completion_tokens", 0),
                        }
                        return ToolResult(content=json.dumps(result, ensure_ascii=False, indent=2))
                    else:
                        last_error = f"{model}: HTTP {resp.status_code}"
            except Exception as e:
                last_error = f"{model}: {e}"

        return ToolResult(
            content=f"All models for {tier} failed. Last error: {last_error}",
            is_error=True,
        )
