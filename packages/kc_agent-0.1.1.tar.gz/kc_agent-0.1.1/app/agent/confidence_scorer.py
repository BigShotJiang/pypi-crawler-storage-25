from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .corner_case_registry import CornerCaseRegistry


# Default method priors — configurable via .env CONFIDENCE_PRIORS
DEFAULT_PRIORS = {
    "regex": 0.95,
    "python": 0.90,
    "llm": 0.75,
    "ocr": 0.65,
    "fallback": 0.50,
}


class ConfidenceScorer:
    """Structural component: composite confidence scoring for verification results.

    Formula: confidence = method_prior × source_presence × historical_accuracy × (1 - corner_case_proximity)

    - method_prior: configurable per extraction method
    - source_presence: 1.0 if extracted value found in source text, 0.7 if not
    - historical_accuracy: running average from QC reviews per rule
    - corner_case_proximity: checks CornerCaseRegistry for matching patterns

    Weights configurable in .env. Auto-calibrates after QC cycles.
    """

    def __init__(
        self,
        workspace_path: Path,
        corner_cases: CornerCaseRegistry | None = None,
    ) -> None:
        self._workspace = workspace_path
        self._corner_cases = corner_cases
        self._priors = dict(DEFAULT_PRIORS)
        self._historical: dict[str, float] = {}  # rule_id → accuracy
        self._calibration_path = workspace_path / "confidence_calibration.json"
        self._load_config()
        self._load_calibration()

    def _load_config(self) -> None:
        """Read custom priors from .env if present."""
        env_path = self._workspace / ".env"
        if not env_path.exists():
            return
        for line in env_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("CONFIDENCE_PRIORS="):
                try:
                    custom = json.loads(line.split("=", 1)[1].strip())
                    if isinstance(custom, dict):
                        self._priors.update(custom)
                except (json.JSONDecodeError, ValueError):
                    pass

    def _load_calibration(self) -> None:
        """Load historical accuracy from calibration file."""
        if self._calibration_path.exists():
            try:
                data = json.loads(self._calibration_path.read_text(encoding="utf-8"))
                self._historical = data.get("historical_accuracy", {})
            except (json.JSONDecodeError, KeyError):
                pass

    def score(
        self,
        *,
        rule_id: str,
        extracted_value: str,
        source_text: str = "",
        extraction_method: str = "llm",
        document_name: str = "",
    ) -> float:
        """Compute composite confidence score (0.0 - 1.0)."""
        # 1. Method prior
        method_prior = self._priors.get(extraction_method, self._priors["fallback"])

        # 2. Source presence
        source_presence = 1.0
        if source_text and extracted_value:
            source_presence = 1.0 if extracted_value in source_text else 0.7

        # 3. Historical accuracy
        historical = self._historical.get(rule_id, 0.8)  # default 0.8 for new rules

        # 4. Corner case proximity
        corner_proximity = 0.0
        if self._corner_cases and document_name:
            matches = self._corner_cases.match(document_name, rule_id)
            if matches:
                corner_proximity = min(0.3, 0.1 * len(matches))

        confidence = method_prior * source_presence * historical * (1.0 - corner_proximity)
        return round(max(0.0, min(1.0, confidence)), 3)

    def calibrate(self, qc_results: dict[str, dict[str, float]]) -> None:
        """Auto-calibrate after QC cycle.

        qc_results: {rule_id: {"predicted_avg": 0.85, "actual_accuracy": 0.78}}
        Adjusts historical accuracy based on observed vs predicted.
        """
        for rule_id, data in qc_results.items():
            actual = data.get("actual_accuracy")
            if actual is not None:
                # Weighted average: 70% new observation, 30% historical
                old = self._historical.get(rule_id, 0.8)
                self._historical[rule_id] = round(0.7 * actual + 0.3 * old, 3)

        self._save_calibration()

    def _save_calibration(self) -> None:
        self._calibration_path.write_text(
            json.dumps({"historical_accuracy": self._historical}, indent=2),
            encoding="utf-8",
        )

    def get_band(self, confidence: float) -> str:
        """Classify confidence into low/medium/high band."""
        if confidence >= 0.8:
            return "high"
        elif confidence >= 0.5:
            return "medium"
        else:
            return "low"
