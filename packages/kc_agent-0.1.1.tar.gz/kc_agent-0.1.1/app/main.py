from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from openai import AsyncOpenAI

from app.config import settings
from app.ws.handler import agent_ws


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.llm_client = AsyncOpenAI(
        api_key=settings.llm_api_key,
        base_url=settings.llm_base_url,
    )
    yield


app = FastAPI(title="KC Agent", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.websocket("/ws/agent")
async def ws_agent(websocket: WebSocket):
    await agent_ws(websocket)
