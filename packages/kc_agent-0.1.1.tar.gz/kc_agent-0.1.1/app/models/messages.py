from __future__ import annotations

from pydantic import BaseModel


class ClientMessage(BaseModel):
    type: str  # "user_message"
    text: str = ""
