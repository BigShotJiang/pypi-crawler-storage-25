from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

from fastapi import WebSocket, WebSocketDisconnect

from app.agent.engine import AgentEngine
from app.agent.history import ConversationHistory
from app.agent.tools.dashboard_render import DashboardRenderTool
from app.agent.workspace import Workspace
from app.config import settings

logger = logging.getLogger(__name__)


class Session:
    """Mutable wrapper so slash commands can swap the engine."""

    def __init__(self, engine: AgentEngine) -> None:
        self.engine = engine
        self.message_queue: list[str] = []


async def agent_ws(websocket: WebSocket) -> None:
    """WebSocket endpoint: one connection = one agent session.

    Supports concurrent input: user can send messages while the agent is
    streaming. Messages are queued and processed after the current turn.
    """
    await websocket.accept()

    client = websocket.app.state.llm_client
    session = Session(AgentEngine(client=client, config=settings))

    await _send_session_info(websocket, session.engine)

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "message": "Invalid JSON"})
                continue

            if msg.get("type") != "user_message" or not msg.get("text", "").strip():
                await websocket.send_json({"type": "error", "message": "Send {type: 'user_message', text: '...'}"})
                continue

            text = msg["text"].strip()

            # Handle slash commands (may swap session.engine)
            if text.startswith("/"):
                handled = await _handle_slash_command(websocket, session, text)
                if handled:
                    continue

            # Run turn as a task so we can keep receiving messages
            await _run_turn_with_queue(websocket, session, text)

    except WebSocketDisconnect:
        logger.info("Client disconnected")


async def _run_turn_with_queue(websocket: WebSocket, session: Session, text: str) -> None:
    """Run a turn while accepting queued messages from the client."""

    async def _stream_turn(turn_text: str) -> None:
        async for event in session.engine.run_turn(turn_text):
            await websocket.send_json(event.to_dict())

    # Start the turn
    turn_task = asyncio.create_task(_stream_turn(text))

    # While turn is running, keep receiving messages and queue them
    while not turn_task.done():
        try:
            raw = await asyncio.wait_for(websocket.receive_text(), timeout=0.1)
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if msg.get("type") == "user_message" and msg.get("text", "").strip():
                queued_text = msg["text"].strip()
                if queued_text.startswith("/"):
                    await _handle_slash_command(websocket, session, queued_text)
                else:
                    session.message_queue.append(queued_text)
        except asyncio.TimeoutError:
            continue
        except WebSocketDisconnect:
            turn_task.cancel()
            raise

    await turn_task  # propagate any exceptions

    # Process queued messages one at a time
    while session.message_queue:
        next_text = session.message_queue.pop(0)
        async for event in session.engine.run_turn(next_text):
            await websocket.send_json(event.to_dict())


async def _send_session_info(websocket: WebSocket, engine: AgentEngine) -> None:
    await websocket.send_json({
        "type": "session_info",
        "session_id": engine.workspace.session_id,
        "phase": engine.current_phase.value,
    })


async def _handle_slash_command(websocket: WebSocket, session: Session, text: str) -> bool:
    """Handle slash commands. Returns True if handled."""
    parts = text.split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""
    engine = session.engine

    if cmd == "/rename":
        if not arg:
            await websocket.send_json({"type": "system_message", "message": "Usage: /rename <new_name>"})
            return True
        try:
            new_id = engine.workspace.rename(arg)
            await websocket.send_json({"type": "system_message", "message": f"Session renamed to: {new_id}"})
            await _send_session_info(websocket, engine)
        except ValueError as e:
            await websocket.send_json({"type": "system_message", "message": f"Rename failed: {e}"})
        return True

    elif cmd == "/resume":
        if not arg:
            await _list_sessions(websocket, engine)
            return True

        root = Path(settings.kc_workspace_root).expanduser()
        target = root / arg
        if not target.is_dir():
            await websocket.send_json({
                "type": "system_message",
                "message": f"Session '{arg}' not found. Use /resume to list sessions.",
            })
            return True

        # Swap engine to the resumed session (loads history from workspace)
        session.engine = AgentEngine(client=engine.client, config=engine.config, session_id=arg)
        await websocket.send_json({"type": "system_message", "message": f"Resumed session: {arg}"})
        await _send_session_info(websocket, session.engine)

        # Replay conversation history to frontend
        display_log = session.engine.history.display_log
        if display_log:
            await websocket.send_json({
                "type": "history_load",
                "messages": display_log,
            })
        return True

    elif cmd == "/sessions":
        await _list_sessions(websocket, engine)
        return True

    elif cmd == "/help":
        await websocket.send_json({
            "type": "system_message",
            "message": (
                "Commands:\n"
                "  /help                Show this help\n"
                "  /status              Show session info, model, phase, workspace\n"
                "  /clear               Clear conversation history (keep workspace)\n"
                "  /compact             Clear history but keep a summary\n"
                "  /dashboard           Generate HTML dashboard from project metrics\n"
                "  /sessions            List all sessions\n"
                "  /resume <name>       Resume a previous session\n"
                "  /rename <name>       Rename current session\n"
                "  /exit                Quit"
            ),
        })
        return True

    elif cmd == "/clear":
        engine.history = ConversationHistory(workspace_path=engine.workspace.cwd)
        await websocket.send_json({
            "type": "system_message",
            "message": "Conversation cleared. Workspace and pipeline state preserved.",
        })
        return True

    elif cmd == "/compact":
        # Summarize conversation via LLM, then clear and inject summary
        display_log = engine.history.display_log
        if not display_log:
            await websocket.send_json({"type": "system_message", "message": "Nothing to compact."})
            return True

        # Build summary request from conversation
        conv_text = []
        for entry in display_log[-50:]:  # Last 50 entries max
            role = entry.get("role", "")
            if role == "user":
                conv_text.append(f"User: {entry.get('content', '')[:200]}")
            elif role == "agent":
                conv_text.append(f"Agent: {entry.get('content', '')[:200]}")
            elif role == "tool":
                conv_text.append(f"Tool({entry.get('toolName', '')}): {(entry.get('toolOutput') or '')[:100]}")

        await websocket.send_json({"type": "system_message", "message": "Compacting conversation..."})

        try:
            summary_resp = await engine.client.chat.completions.create(
                model=engine.config.kc_model,
                max_tokens=1024,
                messages=[{
                    "role": "user",
                    "content": (
                        "Summarize this conversation in 3-5 bullet points. "
                        "Focus on: what was accomplished, current state, pending work.\n\n"
                        + "\n".join(conv_text)
                    ),
                }],
            )
            summary = summary_resp.choices[0].message.content
        except Exception as e:
            await websocket.send_json({"type": "system_message", "message": f"Compact failed: {e}"})
            return True

        # Clear and inject summary
        engine.history = ConversationHistory(workspace_path=engine.workspace.cwd)
        engine.history.add_user("[Previous conversation summary]")
        engine.history.add_raw({"role": "assistant", "content": summary})

        await websocket.send_json({
            "type": "system_message",
            "message": f"Conversation compacted. Summary:\n\n{summary}",
        })
        return True

    elif cmd == "/status":
        workspace_path = str(engine.workspace.cwd)
        rules_count = len(list((engine.workspace.cwd / "rules").glob("*"))) if (engine.workspace.cwd / "rules").exists() else 0
        tools_count = len(engine.tool_registry._tools)

        await websocket.send_json({
            "type": "system_message",
            "message": (
                f"Session:   {engine.workspace.session_id}\n"
                f"Phase:     {engine.current_phase.value.upper()}\n"
                f"Model:     {engine.config.kc_model}\n"
                f"LLM URL:   {engine.config.llm_base_url}\n"
                f"Workspace: {workspace_path}\n"
                f"Tools:     {tools_count} registered\n"
                f"Rules:     {rules_count} file(s) in rules/\n"
                f"History:   {len(engine.history.messages)} messages"
            ),
        })
        return True

    elif cmd == "/dashboard":
        tool = DashboardRenderTool(engine.workspace)
        result = await tool.execute({})
        await websocket.send_json({
            "type": "system_message",
            "message": result.content,
        })
        return True

    elif cmd in ("/exit", "/quit"):
        await websocket.send_json({"type": "system_message", "message": "Goodbye."})
        await websocket.close()
        return True

    return False


async def _list_sessions(websocket: WebSocket, engine: AgentEngine) -> None:
    root = Path(settings.kc_workspace_root).expanduser()
    sessions = Workspace.list_sessions(root)
    if not sessions:
        await websocket.send_json({"type": "system_message", "message": "No sessions found."})
        return
    current = engine.workspace.session_id
    lines = []
    for s in sessions:
        marker = " ← current" if s["id"] == current else ""
        lines.append(f"  {s['id']}{marker}")
    await websocket.send_json({
        "type": "system_message",
        "message": "Sessions:\n" + "\n".join(lines),
    })
