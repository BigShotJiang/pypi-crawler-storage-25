"""Entry point for kc-agent-server console script (installed via pip)."""

import uvicorn


def main():
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000)


if __name__ == "__main__":
    main()
