from __future__ import annotations

import json
from pathlib import Path

from pydantic_settings import BaseSettings

# Global config from `kc onboard` — lowest priority, overridden by .env
_global_config_path = Path.home() / ".kc_agent" / "config.json"


def _load_global_config() -> dict:
    if _global_config_path.exists():
        try:
            return json.loads(_global_config_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, KeyError):
            pass
    return {}


_gc = _load_global_config()


class Settings(BaseSettings):
    # LLM for the conductor agent
    llm_api_key: str = _gc.get("api_key", "")
    llm_base_url: str = _gc.get("base_url", "https://api.siliconflow.cn/v1")
    kc_model: str = _gc.get("conductor_model", "glm-5")
    kc_max_tokens: int = 65536

    # Worker LLMs (SiliconFlow)
    siliconflow_api_key: str = _gc.get("api_key", "")
    siliconflow_base_url: str = _gc.get("base_url", "https://api.siliconflow.cn/v1")

    # Workspace
    kc_workspace_root: str = "~/.kc_agent/workspaces"
    kc_exec_timeout: int = 30

    # Document parsing
    mineru_api_url: str = ""
    mineru_api_key: str = ""
    ocr_model_tier1: str = "zai-org/GLM-4.6V"

    model_config = {"env_file": ".env", "extra": "ignore"}


settings = Settings()
