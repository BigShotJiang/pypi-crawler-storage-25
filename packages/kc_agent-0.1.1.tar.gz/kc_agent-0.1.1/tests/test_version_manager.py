import json
import pytest
from pathlib import Path

from app.agent.version_manager import VersionManager


def _setup(tmp_path):
    ws = tmp_path / "ws"
    ws.mkdir()
    (ws / "versions.json").write_text(json.dumps({"version": "0.1.0", "entries": []}))
    return ws


def test_should_version_workflows(tmp_path):
    ws = _setup(tmp_path)
    vm = VersionManager(ws)
    assert vm.should_version("workflows/R001/workflow.py")
    assert vm.should_version("rule_skills/R001/SKILL.md")
    assert vm.should_version("rules/trust_rules.json")
    assert not vm.should_version("output/results.json")
    assert not vm.should_version("logs/conversation/messages.json")
    assert not vm.should_version(".env")


def test_on_write_creates_entry(tmp_path):
    ws = _setup(tmp_path)
    vm = VersionManager(ws)
    trace_id = vm.on_write("workflows/R001/workflow.py", "def verify(): pass")
    assert trace_id is not None
    assert "R001" in trace_id
    assert "v1" in trace_id

    # Check manifest
    manifest = json.loads((ws / "versions.json").read_text())
    assert len(manifest["entries"]) == 1
    assert manifest["entries"][0]["file"] == "workflows/R001/workflow.py"
    assert manifest["entries"][0]["version"] == 1


def test_increments_version(tmp_path):
    ws = _setup(tmp_path)
    vm = VersionManager(ws)
    vm.on_write("rules/trust_rules.json", "v1 content")
    vm.on_write("rules/trust_rules.json", "v2 content")

    versions = vm.get_versions("rules/trust_rules.json")
    assert len(versions) == 2
    assert versions[0]["version"] == 1
    assert versions[1]["version"] == 2


def test_latest_version(tmp_path):
    ws = _setup(tmp_path)
    vm = VersionManager(ws)
    vm.on_write("rule_skills/R001/SKILL.md", "first")
    vm.on_write("rule_skills/R001/SKILL.md", "second")

    latest = vm.latest_version("rule_skills/R001/SKILL.md")
    assert latest is not None
    assert latest["version"] == 2


def test_no_version_for_untracked(tmp_path):
    ws = _setup(tmp_path)
    vm = VersionManager(ws)
    result = vm.on_write("output/results.json", "data")
    assert result is None


def test_generate_trace_id(tmp_path):
    ws = _setup(tmp_path)
    vm = VersionManager(ws)
    tid = vm.generate_trace_id("R001", "extraction")
    assert "R001" in tid
    assert "extraction" in tid


def test_persists_across_instances(tmp_path):
    ws = _setup(tmp_path)
    vm1 = VersionManager(ws)
    vm1.on_write("workflows/R001/w.py", "content")

    vm2 = VersionManager(ws)
    assert len(vm2.get_versions("workflows/R001/w.py")) == 1
