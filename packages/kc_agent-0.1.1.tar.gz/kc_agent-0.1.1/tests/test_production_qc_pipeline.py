import json
import pytest

from app.agent.workspace import Workspace
from app.agent.tools.base import ToolResult
from app.agent.pipelines.production_qc import ProductionQCPipeline


def _setup(tmp_path, sid, monitor_freq="mid"):
    ws = Workspace(root=tmp_path, session_id=sid)
    for d in ["output/qc", "input"]:
        (ws.cwd / d).mkdir(parents=True, exist_ok=True)
    (ws.cwd / ".env").write_text(
        f"MONITOR_FREQUENCY={monitor_freq}\nWORKFLOW_ACCURACY=0.9\n"
    )
    return ws


def test_initial_state(tmp_path):
    ws = _setup(tmp_path, "qc1")
    pipe = ProductionQCPipeline(ws)
    assert pipe.batches_processed == 0
    assert pipe.monitoring_phase == "initial"
    assert not pipe.exit_criteria_met()


def test_reads_monitor_frequency(tmp_path):
    ws = _setup(tmp_path, "qc2", "high")
    pipe = ProductionQCPipeline(ws)
    assert pipe._sampling_rate == 1.0


def test_tracks_qc_results(tmp_path):
    ws = _setup(tmp_path, "qc3")
    (ws.cwd / "output" / "qc" / "batch1.json").write_text(json.dumps({
        "documents": 50,
        "reviewed": 25,
        "accuracy_by_rule": {"R000": 0.95, "R001": 0.88},
        "confidence": {"low": 5, "medium": 20, "high": 25},
        "issues": [],
    }))

    pipe = ProductionQCPipeline(ws)
    assert pipe.batches_processed == 1
    assert pipe.total_documents == 50
    assert pipe.documents_reviewed == 25
    assert pipe.accuracy_by_rule["R000"] == 0.95
    assert pipe.confidence_distribution["medium"] == 20


def test_detects_failing_rules(tmp_path):
    ws = _setup(tmp_path, "qc4")
    (ws.cwd / "output" / "qc" / "batch1.json").write_text(json.dumps({
        "documents": 10,
        "reviewed": 10,
        "accuracy_by_rule": {"R000": 0.7},
        "confidence": {"low": 3, "medium": 4, "high": 3},
        "issues": [{"rule": "R000", "doc": "doc1", "problem": "wrong value"}],
    }))

    pipe = ProductionQCPipeline(ws)
    state = pipe.describe_state()
    assert "Action needed" in state or "below threshold" in state.lower()
    assert len(pipe.issues_found) == 1


def test_stable_phase(tmp_path):
    ws = _setup(tmp_path, "qc5")
    # 3 clean batches with no issues
    for i in range(3):
        (ws.cwd / "output" / "qc" / f"batch{i}.json").write_text(json.dumps({
            "documents": 20,
            "reviewed": 10,
            "accuracy_by_rule": {"R000": 0.95},
            "confidence": {"low": 1, "medium": 5, "high": 14},
            "issues": [],
        }))

    pipe = ProductionQCPipeline(ws)
    assert pipe.monitoring_phase == "stable"
    assert pipe.exit_criteria_met()


def test_milestone_event_on_stable(tmp_path):
    ws = _setup(tmp_path, "qc6")
    # Start with 2 batches (still initial)
    for i in range(2):
        (ws.cwd / "output" / "qc" / f"batch{i}.json").write_text(json.dumps({
            "documents": 10, "reviewed": 5,
            "accuracy_by_rule": {"R000": 0.95},
            "confidence": {"low": 0, "medium": 2, "high": 8}, "issues": [],
        }))

    pipe = ProductionQCPipeline(ws)
    assert pipe.monitoring_phase != "stable"

    # Add 3rd clean batch → should transition to stable
    (ws.cwd / "output" / "qc" / "batch2.json").write_text(json.dumps({
        "documents": 10, "reviewed": 5,
        "accuracy_by_rule": {"R000": 0.96},
        "confidence": {"low": 0, "medium": 1, "high": 9}, "issues": [],
    }))

    event = pipe.on_tool_result(
        "workspace_file",
        {"operation": "write", "path": "output/qc/batch2.json"},
        ToolResult(content="ok"),
    )
    assert event is not None
    assert event.type == "milestone"
    assert "stable" in event.message.lower()


def test_describe_state_shows_phase(tmp_path):
    ws = _setup(tmp_path, "qc7")
    pipe = ProductionQCPipeline(ws)
    state = pipe.describe_state()
    assert "PRODUCTION_QC" in state
    assert "initial" in state
