import json
import pytest

from app.agent.workspace import Workspace
from app.agent.tools.base import ToolResult
from app.agent.pipelines import Phase
from app.agent.pipelines.distillation import DistillationEngine


def _setup(tmp_path, sid, num_skills=2, workflow_accuracy=0.9):
    ws = Workspace(root=tmp_path, session_id=sid)
    for d in ["rules", "rule_skills", "workflows", "output"]:
        (ws.cwd / d).mkdir(parents=True, exist_ok=True)
    for i in range(num_skills):
        sd = ws.cwd / "rule_skills" / f"R{i:03d}"
        sd.mkdir(parents=True, exist_ok=True)
        (sd / "SKILL.md").write_text(f"# R{i:03d}")
    (ws.cwd / ".env").write_text(f"WORKFLOW_ACCURACY={workflow_accuracy}\n")
    return ws


def test_loads_skills(tmp_path):
    ws = _setup(tmp_path, "d1", 3)
    pipe = DistillationEngine(ws)
    assert len(pipe.skills_to_distill) == 3


def test_no_workflows_initially(tmp_path):
    ws = _setup(tmp_path, "d2")
    pipe = DistillationEngine(ws)
    assert len(pipe.workflows_created) == 0
    assert not pipe.exit_criteria_met()


def test_tracks_workflow_creation(tmp_path):
    ws = _setup(tmp_path, "d3", 1)
    wf_dir = ws.cwd / "workflows" / "R000"
    wf_dir.mkdir(parents=True)
    (wf_dir / "workflow_v1.py").write_text("def verify(): pass")
    (wf_dir / "config.json").write_text(json.dumps({"tier": "TIER2", "accuracy": 0.95}))

    pipe = DistillationEngine(ws)
    assert "R000" in pipe.workflows_created
    assert pipe.workflows_tested.get("R000") == 0.95
    assert "R000" in pipe.workflows_passing
    assert pipe.tier_assignments.get("R000") == "TIER2"


def test_exit_criteria(tmp_path):
    ws = _setup(tmp_path, "d4", 2)
    for i in range(2):
        wf_dir = ws.cwd / "workflows" / f"R{i:03d}"
        wf_dir.mkdir(parents=True)
        (wf_dir / "workflow_v1.py").write_text("pass")
        (wf_dir / "config.json").write_text(json.dumps({"tier": "TIER3", "accuracy": 0.92}))

    pipe = DistillationEngine(ws)
    assert pipe.exit_criteria_met()


def test_phase_ready_event(tmp_path):
    ws = _setup(tmp_path, "d5", 1)
    pipe = DistillationEngine(ws)

    wf_dir = ws.cwd / "workflows" / "R000"
    wf_dir.mkdir(parents=True)
    (wf_dir / "workflow_v1.py").write_text("pass")
    (wf_dir / "config.json").write_text(json.dumps({"tier": "TIER2", "accuracy": 0.95}))

    event = pipe.on_tool_result(
        "workspace_file",
        {"operation": "write", "path": "workflows/R000/config.json"},
        ToolResult(content="ok"),
    )
    assert event is not None
    assert event.type == "phase_ready"
    assert event.next_phase == Phase.PRODUCTION_QC


def test_reads_threshold_from_env(tmp_path):
    ws = _setup(tmp_path, "d6", 1, workflow_accuracy=0.8)
    wf_dir = ws.cwd / "workflows" / "R000"
    wf_dir.mkdir(parents=True)
    (wf_dir / "workflow_v1.py").write_text("pass")
    (wf_dir / "config.json").write_text(json.dumps({"accuracy": 0.85}))

    pipe = DistillationEngine(ws)
    assert pipe._workflow_accuracy == 0.8
    assert "R000" in pipe.workflows_passing


def test_describe_state(tmp_path):
    ws = _setup(tmp_path, "d7")
    pipe = DistillationEngine(ws)
    state = pipe.describe_state()
    assert "DISTILLATION" in state
    assert "Decision tree" in state or "decision tree" in state.lower() or "regex" in state.lower()
