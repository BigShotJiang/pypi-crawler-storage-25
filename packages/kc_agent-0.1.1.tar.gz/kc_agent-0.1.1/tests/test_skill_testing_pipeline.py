import json
import pytest
from pathlib import Path

from app.agent.workspace import Workspace
from app.agent.tools.base import ToolResult
from app.agent.pipelines import Phase
from app.agent.pipelines.skill_testing import SkillTestingPipeline, EvolutionCycle


def _setup(tmp_path, session_id, num_skills=3, accuracy_threshold=0.9):
    ws = Workspace(root=tmp_path, session_id=session_id)
    for d in ["rules", "rule_skills", "output", "logs/evolution"]:
        (ws.cwd / d).mkdir(parents=True, exist_ok=True)

    # Create skill folders
    for i in range(num_skills):
        skill_dir = ws.cwd / "rule_skills" / f"R{i:03d}"
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text(f"# R{i:03d}")

    # Write .env with threshold
    (ws.cwd / ".env").write_text(
        f"SKILL_ACCURACY={accuracy_threshold}\nMAX_ITERATIONS=20\n"
    )
    return ws


def test_loads_skills_to_test(tmp_path):
    ws = _setup(tmp_path, "st1", 5)
    pipe = SkillTestingPipeline(ws)
    assert len(pipe.skills_to_test) == 5


def test_no_tests_initially(tmp_path):
    ws = _setup(tmp_path, "st2")
    pipe = SkillTestingPipeline(ws)
    assert len(pipe.skills_tested) == 0
    assert not pipe.exit_criteria_met()


def test_tracks_test_results(tmp_path):
    ws = _setup(tmp_path, "st3", 2)
    # Write a test result
    (ws.cwd / "output" / "R000_results.json").write_text(json.dumps({
        "rule_id": "R000",
        "accuracy": 0.95,
    }))
    pipe = SkillTestingPipeline(ws)
    assert "R000" in pipe.skills_tested
    assert pipe.skills_tested["R000"] == 0.95
    assert "R000" in pipe.skills_passing


def test_exit_criteria_all_passing(tmp_path):
    ws = _setup(tmp_path, "st4", 2)
    for i in range(2):
        (ws.cwd / "output" / f"R{i:03d}_results.json").write_text(json.dumps({
            "rule_id": f"R{i:03d}",
            "accuracy": 0.95,
        }))
    pipe = SkillTestingPipeline(ws)
    assert pipe.exit_criteria_met()


def test_exit_criteria_some_failing(tmp_path):
    ws = _setup(tmp_path, "st5", 3)
    (ws.cwd / "output" / "R000.json").write_text(json.dumps({"rule_id": "R000", "accuracy": 0.95}))
    (ws.cwd / "output" / "R001.json").write_text(json.dumps({"rule_id": "R001", "accuracy": 0.95}))
    (ws.cwd / "output" / "R002.json").write_text(json.dumps({"rule_id": "R002", "accuracy": 0.5}))
    pipe = SkillTestingPipeline(ws)
    # 2/3 passing = 66%, need ≥90%
    assert not pipe.exit_criteria_met()


def test_describe_state_shows_failing_skills(tmp_path):
    ws = _setup(tmp_path, "st6", 2)
    (ws.cwd / "output" / "R000.json").write_text(json.dumps({"rule_id": "R000", "accuracy": 0.5}))
    (ws.cwd / "output" / "R001.json").write_text(json.dumps({"rule_id": "R001", "accuracy": 0.95}))
    pipe = SkillTestingPipeline(ws)
    state = pipe.describe_state()
    assert "Evolution Cycle" in state
    assert "R000" in state


def test_reads_accuracy_from_env(tmp_path):
    ws = _setup(tmp_path, "st7", 1, accuracy_threshold=0.8)
    (ws.cwd / "output" / "R000.json").write_text(json.dumps({"rule_id": "R000", "accuracy": 0.85}))
    pipe = SkillTestingPipeline(ws)
    assert pipe._accuracy_threshold == 0.8
    assert "R000" in pipe.skills_passing


def test_phase_ready_event(tmp_path):
    ws = _setup(tmp_path, "st8", 1)
    pipe = SkillTestingPipeline(ws)

    # Write passing result
    (ws.cwd / "output" / "R000.json").write_text(json.dumps({"rule_id": "R000", "accuracy": 0.95}))
    event = pipe.on_tool_result(
        "workspace_file",
        {"operation": "write", "path": "output/R000.json"},
        ToolResult(content="ok"),
    )
    assert event is not None
    assert event.type == "phase_ready"
    assert event.next_phase == Phase.DISTILLATION


def test_evolution_log_tracking(tmp_path):
    ws = _setup(tmp_path, "st9", 1)
    pipe = SkillTestingPipeline(ws)

    # Write evolution log entry
    log_entry = {
        "iteration": 1,
        "rule_id": "R000",
        "accuracy_before": 0.6,
        "failures": [{"case_id": "doc1", "diagnosis": "extraction"}],
        "classification": "systemic",
        "fix_applied": "Rewrote regex",
        "accuracy_after": 0.85,
        "regressions": 0,
    }
    (ws.cwd / "logs" / "evolution" / "iter_001.json").write_text(json.dumps(log_entry))

    pipe.on_tool_result(
        "workspace_file",
        {"operation": "write", "path": "logs/evolution/iter_001.json"},
        ToolResult(content="ok"),
    )
    assert pipe.iteration_count >= 1
    assert len(pipe.evolution_log) >= 1
    assert pipe.evolution_log[-1].rule_id == "R000"


def test_evolution_cycle_dataclass():
    cycle = EvolutionCycle(
        iteration=1,
        rule_id="R001",
        accuracy_before=0.7,
        classification="systemic",
        fix_applied="rewrote parser",
        accuracy_after=0.92,
        regressions=0,
    )
    assert cycle.iteration == 1
    assert cycle.accuracy_after == 0.92
