import json
import pytest

from app.agent.workspace import Workspace
from app.agent.tools.worker_llm_call import WorkerLLMCallTool


def _setup(tmp_path, sid="wlc1"):
    ws = Workspace(root=tmp_path, session_id=sid)
    (ws.cwd / ".env").write_text(
        "TIER1=Pro/zai-org/GLM-5\n"
        "TIER2=Pro/deepseek-ai/DeepSeek-V3\n"
        "TIER3=Qwen/Qwen3.5-122B\n"
        "TIER4=Qwen/Qwen3.5-35B\n"
    )
    return ws


@pytest.mark.asyncio
async def test_no_api_key(tmp_path):
    ws = _setup(tmp_path)
    tool = WorkerLLMCallTool(ws, api_key="")
    result = await tool.execute({"tier": "tier1", "prompt": "test"})
    assert result.is_error
    assert "not configured" in result.content


@pytest.mark.asyncio
async def test_no_models_for_tier(tmp_path):
    ws = _setup(tmp_path, "wlc2")
    # Empty .env
    (ws.cwd / ".env").write_text("")
    tool = WorkerLLMCallTool(ws, api_key="test-key")
    result = await tool.execute({"tier": "tier1", "prompt": "test"})
    assert result.is_error
    assert "No models configured" in result.content


@pytest.mark.asyncio
async def test_empty_prompt(tmp_path):
    ws = _setup(tmp_path, "wlc3")
    tool = WorkerLLMCallTool(ws, api_key="test-key")
    result = await tool.execute({"tier": "tier1", "prompt": ""})
    assert result.is_error


def test_loads_tiers(tmp_path):
    ws = _setup(tmp_path, "wlc4")
    tool = WorkerLLMCallTool(ws, api_key="test-key")
    assert "tier1" in tool._tier_models
    assert "Pro/zai-org/GLM-5" in tool._tier_models["tier1"]


def test_schema(tmp_path):
    ws = _setup(tmp_path, "wlc5")
    tool = WorkerLLMCallTool(ws)
    assert tool.name == "worker_llm_call"
    schema = tool.input_schema
    assert "tier" in schema["properties"]
    assert "prompt" in schema["properties"]
