import json
import pytest
from pathlib import Path

from app.agent.corner_case_registry import CornerCaseRegistry, CornerCase


def _setup(tmp_path):
    ws = tmp_path / "ws"
    ws.mkdir()
    return ws


def test_add_and_get(tmp_path):
    ws = _setup(tmp_path)
    reg = CornerCaseRegistry(ws)
    case = CornerCase(
        id="CC001",
        rule_id="R001",
        detection_pattern="stamped document",
        resolution="Use OCR instead of text extraction",
        affected_documents=["doc1.pdf"],
    )
    reg.add(case)

    retrieved = reg.get("CC001")
    assert retrieved is not None
    assert retrieved.rule_id == "R001"
    assert retrieved.detection_pattern == "stamped document"


def test_get_by_rule(tmp_path):
    ws = _setup(tmp_path)
    reg = CornerCaseRegistry(ws)
    reg.add(CornerCase(id="CC001", rule_id="R001", detection_pattern="p1", resolution="r1"))
    reg.add(CornerCase(id="CC002", rule_id="R001", detection_pattern="p2", resolution="r2"))
    reg.add(CornerCase(id="CC003", rule_id="R002", detection_pattern="p3", resolution="r3"))

    r001_cases = reg.get_by_rule("R001")
    assert len(r001_cases) == 2


def test_match_document(tmp_path):
    ws = _setup(tmp_path)
    reg = CornerCaseRegistry(ws)
    reg.add(CornerCase(id="CC001", rule_id="R001", detection_pattern="scanned", resolution="use ocr"))

    matches = reg.match("trust_contract_scanned.pdf", "R001")
    assert len(matches) == 1

    no_match = reg.match("trust_contract_digital.pdf", "R001")
    assert len(no_match) == 0


def test_persists_to_json(tmp_path):
    ws = _setup(tmp_path)
    reg = CornerCaseRegistry(ws)
    reg.add(CornerCase(id="CC001", rule_id="R001", detection_pattern="p", resolution="r"))

    # Load fresh
    reg2 = CornerCaseRegistry(ws)
    assert reg2.count() == 1
    assert reg2.get("CC001") is not None


def test_update_existing(tmp_path):
    ws = _setup(tmp_path)
    reg = CornerCaseRegistry(ws)
    reg.add(CornerCase(id="CC001", rule_id="R001", detection_pattern="old", resolution="old"))
    reg.add(CornerCase(id="CC001", rule_id="R001", detection_pattern="new", resolution="new"))

    assert reg.count() == 1
    assert reg.get("CC001").detection_pattern == "new"


def test_status_filter(tmp_path):
    ws = _setup(tmp_path)
    reg = CornerCaseRegistry(ws)
    reg.add(CornerCase(id="CC001", rule_id="R001", detection_pattern="p", resolution="r", status="active"))
    reg.add(CornerCase(id="CC002", rule_id="R001", detection_pattern="p", resolution="r", status="obsolete"))

    active = reg.get_by_rule("R001")
    assert len(active) == 1  # Only active ones
