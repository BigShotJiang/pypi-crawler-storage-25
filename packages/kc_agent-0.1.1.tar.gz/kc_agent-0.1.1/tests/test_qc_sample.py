import json
import pytest

from app.agent.workspace import Workspace
from app.agent.tools.qc_sample import QCSampleTool


def _setup(tmp_path, sid="qs1", num_results=10):
    ws = Workspace(root=tmp_path, session_id=sid)
    results_dir = ws.cwd / "output" / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    (ws.cwd / ".env").write_text("MONITOR_FREQUENCY=mid\n")

    for i in range(num_results):
        if i < 2:
            band = "low"
            conf = 0.3
        elif i < 6:
            band = "medium"
            conf = 0.6
        else:
            band = "high"
            conf = 0.9
        (results_dir / f"result_{i}.json").write_text(json.dumps({
            "rule_id": f"R{i:03d}",
            "confidence": conf,
            "confidence_band": band,
        }))
    return ws


@pytest.mark.asyncio
async def test_samples_correctly(tmp_path):
    ws = _setup(tmp_path)
    tool = QCSampleTool(ws)
    result = await tool.execute({})
    assert not result.is_error
    data = json.loads(result.content)
    assert data["total_results"] == 10
    assert data["distribution"]["low"] == 2
    assert data["distribution"]["medium"] == 4
    assert data["distribution"]["high"] == 4
    # All low-confidence should be in review list
    low_in_review = [r for r in data["review_list"] if r.get("confidence", 0) < 0.5]
    assert len(low_in_review) == 2


@pytest.mark.asyncio
async def test_empty_results(tmp_path):
    ws = Workspace(root=tmp_path, session_id="qs2")
    (ws.cwd / "output" / "results").mkdir(parents=True, exist_ok=True)
    tool = QCSampleTool(ws)
    result = await tool.execute({})
    data = json.loads(result.content)
    assert data["total_results"] == 0


@pytest.mark.asyncio
async def test_no_results_dir(tmp_path):
    ws = Workspace(root=tmp_path, session_id="qs3")
    tool = QCSampleTool(ws)
    result = await tool.execute({})
    assert result.is_error
