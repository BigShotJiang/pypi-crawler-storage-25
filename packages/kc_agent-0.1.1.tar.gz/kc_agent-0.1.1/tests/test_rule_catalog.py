import json
import pytest

from app.agent.workspace import Workspace
from app.agent.tools.rule_catalog import RuleCatalogTool


def _setup(tmp_path, sid="rc1"):
    ws = Workspace(root=tmp_path, session_id=sid)
    (ws.cwd / "rules").mkdir(parents=True, exist_ok=True)
    return ws


@pytest.mark.asyncio
async def test_create_rule(tmp_path):
    ws = _setup(tmp_path)
    tool = RuleCatalogTool(ws)
    result = await tool.execute({
        "operation": "create",
        "data": {"id": "R001", "source_ref": "Article 1", "description": "Capital ratio >= 8%"},
    })
    assert not result.is_error
    assert "Created" in result.content


@pytest.mark.asyncio
async def test_create_missing_fields(tmp_path):
    ws = _setup(tmp_path, "rc2")
    tool = RuleCatalogTool(ws)
    result = await tool.execute({
        "operation": "create",
        "data": {"id": "R001"},
    })
    assert result.is_error
    assert "Missing required" in result.content


@pytest.mark.asyncio
async def test_read_rule(tmp_path):
    ws = _setup(tmp_path, "rc3")
    tool = RuleCatalogTool(ws)
    await tool.execute({"operation": "create", "data": {"id": "R001", "source_ref": "s", "description": "d"}})
    result = await tool.execute({"operation": "read", "rule_id": "R001"})
    assert not result.is_error
    data = json.loads(result.content)
    assert data["id"] == "R001"


@pytest.mark.asyncio
async def test_list_rules(tmp_path):
    ws = _setup(tmp_path, "rc4")
    tool = RuleCatalogTool(ws)
    await tool.execute({"operation": "create", "data": {"id": "R001", "source_ref": "s", "description": "first"}})
    await tool.execute({"operation": "create", "data": {"id": "R002", "source_ref": "s", "description": "second"}})
    result = await tool.execute({"operation": "list"})
    assert "2 rule" in result.content
    assert "R001" in result.content


@pytest.mark.asyncio
async def test_update_rule(tmp_path):
    ws = _setup(tmp_path, "rc5")
    tool = RuleCatalogTool(ws)
    await tool.execute({"operation": "create", "data": {"id": "R001", "source_ref": "s", "description": "old"}})
    await tool.execute({"operation": "update", "rule_id": "R001", "data": {"description": "new desc"}})
    result = await tool.execute({"operation": "read", "rule_id": "R001"})
    data = json.loads(result.content)
    assert data["description"] == "new desc"


@pytest.mark.asyncio
async def test_delete_rule(tmp_path):
    ws = _setup(tmp_path, "rc6")
    tool = RuleCatalogTool(ws)
    await tool.execute({"operation": "create", "data": {"id": "R001", "source_ref": "s", "description": "d"}})
    result = await tool.execute({"operation": "delete", "rule_id": "R001"})
    assert not result.is_error
    result = await tool.execute({"operation": "read", "rule_id": "R001"})
    assert result.is_error


@pytest.mark.asyncio
async def test_warns_missing_recommended(tmp_path):
    ws = _setup(tmp_path, "rc7")
    tool = RuleCatalogTool(ws)
    result = await tool.execute({
        "operation": "create",
        "data": {"id": "R001", "source_ref": "s", "description": "d"},
    })
    assert "Missing recommended" in result.content
