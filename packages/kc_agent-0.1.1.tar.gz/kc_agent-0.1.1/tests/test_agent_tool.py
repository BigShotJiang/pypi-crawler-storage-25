import json
import asyncio
import pytest

from app.agent.workspace import Workspace
from app.agent.tools.agent_tool import AgentTool
from app.agent.events import AgentEvent


class FakeChildEngine:
    """Minimal engine that yields a text response."""

    def __init__(self, response: str = "Done."):
        self._response = response

    async def run_turn(self, message: str):
        for char in self._response:
            yield AgentEvent(type="text_delta", text=char)
        yield AgentEvent(type="turn_complete")


def _setup(tmp_path, sid="at1"):
    ws = Workspace(root=tmp_path, session_id=sid)
    return ws


@pytest.mark.asyncio
async def test_spawns_subagent(tmp_path):
    ws = _setup(tmp_path)
    tool = AgentTool(ws, engine_factory=lambda sid: FakeChildEngine("Hello from child"))
    result = await tool.execute({"task_description": "Do something useful"})
    assert not result.is_error
    data = json.loads(result.content)
    assert data["status"] == "started"
    task_id = data["task_id"]

    # Wait for async task to complete
    await asyncio.sleep(0.1)

    # Check output files
    task_dir = ws.cwd / "sub_agents" / task_id
    assert (task_dir / "task.md").exists()
    assert (task_dir / "task.md").read_text() == "Do something useful"
    assert (task_dir / "status.txt").read_text() == "completed"
    assert (task_dir / "output.md").read_text() == "Hello from child"


@pytest.mark.asyncio
async def test_custom_task_id(tmp_path):
    ws = _setup(tmp_path, "at2")
    tool = AgentTool(ws, engine_factory=lambda sid: FakeChildEngine())
    result = await tool.execute({"task_description": "test", "task_id": "my_task"})
    data = json.loads(result.content)
    assert data["task_id"] == "my_task"
    assert "my_task" in data["output_dir"]


@pytest.mark.asyncio
async def test_no_task_description(tmp_path):
    ws = _setup(tmp_path, "at3")
    tool = AgentTool(ws, engine_factory=lambda sid: FakeChildEngine())
    result = await tool.execute({"task_description": ""})
    assert result.is_error


@pytest.mark.asyncio
async def test_saves_result_json(tmp_path):
    ws = _setup(tmp_path, "at4")
    tool = AgentTool(ws, engine_factory=lambda sid: FakeChildEngine("OK"))
    result = await tool.execute({"task_description": "work"})
    data = json.loads(result.content)
    task_id = data["task_id"]

    await asyncio.sleep(0.1)

    result_file = ws.cwd / "sub_agents" / task_id / "result.json"
    assert result_file.exists()
    events = json.loads(result_file.read_text())
    types = [e["type"] for e in events]
    assert "text_delta" in types
    assert "turn_complete" in types
