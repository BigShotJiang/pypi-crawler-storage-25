"""Unit tests for AgentEngine with mocked OpenAI-compatible API."""

import pytest

from app.agent.engine import AgentEngine
from app.config import Settings


class FakeDelta:
    def __init__(self, content=None, tool_calls=None):
        self.content = content
        self.tool_calls = tool_calls


class FakeChoice:
    def __init__(self, delta):
        self.delta = delta


class FakeChunk:
    def __init__(self, content=None):
        self.choices = [FakeChoice(FakeDelta(content=content))]


class FakeStream:
    def __init__(self, text: str):
        self._chunks = [FakeChunk(content=c) for c in text]

    def __aiter__(self):
        return self._iter()

    async def _iter(self):
        for chunk in self._chunks:
            yield chunk


class FakeCompletions:
    def __init__(self, text: str):
        self._text = text

    async def create(self, **kwargs):
        return FakeStream(self._text)


class FakeChat:
    def __init__(self, text: str):
        self.completions = FakeCompletions(text)


class FakeClient:
    def __init__(self, text: str = "Hello!"):
        self.chat = FakeChat(text)


@pytest.mark.asyncio
async def test_run_turn_streams_text():
    client = FakeClient("Hi")
    config = Settings(siliconflow_api_key="test", kc_model="test", kc_max_tokens=100)
    engine = AgentEngine(client=client, config=config)

    events = []
    async for event in engine.run_turn("hello"):
        events.append(event)

    text_events = [e for e in events if e.type == "text_delta"]
    assert len(text_events) == 2  # "H" and "i"
    assert text_events[0].text == "H"
    assert text_events[1].text == "i"
    assert events[-1].type == "turn_complete"


@pytest.mark.asyncio
async def test_conversation_history_grows():
    client = FakeClient("World")
    config = Settings(siliconflow_api_key="test", kc_model="test", kc_max_tokens=100)
    engine = AgentEngine(client=client, config=config)

    async for _ in engine.run_turn("hello"):
        pass

    assert len(engine.history.messages) == 2
    assert engine.history.messages[0]["role"] == "user"
    assert engine.history.messages[1]["role"] == "assistant"
