import pytest
from pathlib import Path

from app.agent.workspace import Workspace
from app.agent.tools.document_parse import DocumentParseTool


def _create_text_pdf(path: Path, text: str = "Hello world. This is a test document with enough text.") -> None:
    """Create a simple text-based PDF using PyMuPDF."""
    import fitz

    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), text, fontsize=12)
    doc.save(str(path))
    doc.close()


@pytest.mark.asyncio
async def test_parse_text_pdf(tmp_path):
    ws = Workspace(root=tmp_path, session_id="doc1")
    (ws.cwd / "rules").mkdir()
    pdf_path = ws.cwd / "rules" / "test.pdf"
    _create_text_pdf(pdf_path)

    tool = DocumentParseTool(ws)
    result = await tool.execute({"path": "rules/test.pdf"})

    assert not result.is_error
    assert "pymupdf" in result.content.lower()
    assert "Hello world" in result.content


@pytest.mark.asyncio
async def test_parse_specific_page(tmp_path):
    ws = Workspace(root=tmp_path, session_id="doc2")
    pdf_path = ws.cwd / "test.pdf"

    import fitz

    doc = fitz.open()
    for i in range(3):
        page = doc.new_page()
        page.insert_text((72, 72), f"Content of page {i + 1} with enough text for quality check.", fontsize=12)
    doc.save(str(pdf_path))
    doc.close()

    tool = DocumentParseTool(ws)
    result = await tool.execute({"path": "test.pdf", "pages": "2"})

    assert not result.is_error
    assert "page 2" in result.content.lower()


@pytest.mark.asyncio
async def test_parse_file_not_found(tmp_path):
    ws = Workspace(root=tmp_path, session_id="doc3")
    tool = DocumentParseTool(ws)
    result = await tool.execute({"path": "nonexistent.pdf"})

    assert result.is_error
    assert "not found" in result.content.lower()


@pytest.mark.asyncio
async def test_parse_path_traversal_rejected(tmp_path):
    ws = Workspace(root=tmp_path, session_id="doc4")
    tool = DocumentParseTool(ws)
    result = await tool.execute({"path": "../../etc/passwd"})

    assert result.is_error


@pytest.mark.asyncio
async def test_parse_txt_file(tmp_path):
    ws = Workspace(root=tmp_path, session_id="doc5")
    txt_path = ws.cwd / "rules" / "regulation.txt"
    txt_path.parent.mkdir(parents=True, exist_ok=True)
    txt_path.write_text("Article 1: Capital adequacy ratio must be >= 8%")

    tool = DocumentParseTool(ws)
    result = await tool.execute({"path": "rules/regulation.txt"})

    # PyMuPDF won't parse .txt well but won't crash
    # The tool should still return something
    assert not result.is_error or "Could not extract" in result.content


@pytest.mark.asyncio
async def test_force_method(tmp_path):
    ws = Workspace(root=tmp_path, session_id="doc6")
    pdf_path = ws.cwd / "test.pdf"
    _create_text_pdf(pdf_path)

    tool = DocumentParseTool(ws)
    result = await tool.execute({"path": "test.pdf", "force_method": "pymupdf"})

    assert not result.is_error
    assert "pymupdf" in result.content.lower()
