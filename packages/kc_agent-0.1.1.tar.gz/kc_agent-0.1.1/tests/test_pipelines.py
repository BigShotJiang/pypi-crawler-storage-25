import pytest
from pathlib import Path

from app.agent.workspace import Workspace
from app.agent.tools.base import ToolResult
from app.agent.pipelines import Phase
from app.agent.pipelines.initializer import ProjectInitializer, REQUIRED_DIRS


def test_creates_workspace_structure(tmp_path):
    ws = Workspace(root=tmp_path, session_id="pipe1")
    pi = ProjectInitializer(ws)

    for d in REQUIRED_DIRS:
        assert (ws.cwd / d).is_dir(), f"Missing directory: {d}"

    assert (ws.cwd / ".env").is_file()
    assert (ws.cwd / "versions.json").is_file()
    assert pi.workspace_created


def test_initial_state_no_docs(tmp_path):
    ws = Workspace(root=tmp_path, session_id="pipe2")
    pi = ProjectInitializer(ws)

    assert pi.workspace_created
    # config_ready depends on whether global config (kc onboard) has an API key
    # Either way, no docs = not ready to exit bootstrap
    assert not pi.has_regulations
    assert not pi.has_samples
    assert not pi.exit_criteria_met()


def test_exit_criteria_all_met(tmp_path):
    ws = Workspace(root=tmp_path, session_id="pipe3")
    pi = ProjectInitializer(ws)

    # Set API key
    env_path = ws.cwd / ".env"
    env_path.write_text("SILICONFLOW_API_KEY=sk-test123\n")
    pi._check_config()
    assert pi.config_ready

    # Add regulation
    (ws.cwd / "rules" / "reg1.txt").write_text("Some regulation")
    pi._check_regulations()
    assert pi.has_regulations

    # Add sample
    (ws.cwd / "samples" / "sample1.pdf").write_bytes(b"fake pdf")
    pi._check_samples()
    assert pi.has_samples

    assert pi.exit_criteria_met()


def test_on_tool_result_tracks_writes(tmp_path):
    ws = Workspace(root=tmp_path, session_id="pipe4")
    pi = ProjectInitializer(ws)

    assert not pi.has_regulations

    # Simulate workspace_file write to rules/
    result = ToolResult(content="Wrote 100 chars to rules/reg.txt")
    event = pi.on_tool_result("workspace_file", {"operation": "write", "path": "rules/reg.txt"}, result)

    assert pi.has_regulations
    # Not ready yet (no samples, no config)
    assert event is None


def test_phase_ready_event(tmp_path):
    ws = Workspace(root=tmp_path, session_id="pipe5")
    pi = ProjectInitializer(ws)

    # Set up everything
    env_path = ws.cwd / ".env"
    env_path.write_text("SILICONFLOW_API_KEY=sk-test123\n")
    pi._check_config()
    (ws.cwd / "samples" / "s1.txt").write_text("sample")
    pi._check_samples()

    # The final write to rules/ should trigger phase_ready
    result = ToolResult(content="Wrote file")
    event = pi.on_tool_result("workspace_file", {"operation": "write", "path": "rules/r1.txt"}, result)

    assert event is not None
    assert event.type == "phase_ready"
    assert event.next_phase == Phase.EXTRACTION


def test_describe_state_shows_pending(tmp_path):
    ws = Workspace(root=tmp_path, session_id="pipe6")
    pi = ProjectInitializer(ws)

    state = pi.describe_state()
    assert "BOOTSTRAP" in state
    assert "Completed" in state
    assert "Pending" in state
    assert "rules/" in state.lower()


def test_no_event_on_error_result(tmp_path):
    ws = Workspace(root=tmp_path, session_id="pipe7")
    pi = ProjectInitializer(ws)

    result = ToolResult(content="File not found", is_error=True)
    event = pi.on_tool_result("workspace_file", {"operation": "write", "path": "rules/r.txt"}, result)

    assert event is None
    assert not pi.has_regulations
