import pytest
from pathlib import Path

from app.agent.workspace import Workspace
from app.agent.tools.sandbox_exec import SandboxExecTool
from app.agent.tools.workspace_file import WorkspaceFileTool


# --- SandboxExec ---

@pytest.mark.asyncio
async def test_sandbox_echo(tmp_path):
    ws = Workspace(root=tmp_path, session_id="exec1")
    tool = SandboxExecTool(ws, timeout=5)
    result = await tool.execute({"command": "echo hello"})
    assert not result.is_error
    assert "hello" in result.content


@pytest.mark.asyncio
async def test_sandbox_cwd(tmp_path):
    ws = Workspace(root=tmp_path, session_id="exec2")
    tool = SandboxExecTool(ws, timeout=5)
    result = await tool.execute({"command": "pwd"})
    assert not result.is_error
    assert str(ws.cwd) in result.content


@pytest.mark.asyncio
async def test_sandbox_timeout(tmp_path):
    ws = Workspace(root=tmp_path, session_id="exec3")
    tool = SandboxExecTool(ws, timeout=1)
    result = await tool.execute({"command": "sleep 10"})
    assert result.is_error
    assert "timed out" in result.content


@pytest.mark.asyncio
async def test_sandbox_nonzero_exit(tmp_path):
    ws = Workspace(root=tmp_path, session_id="exec4")
    tool = SandboxExecTool(ws, timeout=5)
    result = await tool.execute({"command": "false"})
    assert result.is_error
    assert "exit code" in result.content


@pytest.mark.asyncio
async def test_sandbox_pipe(tmp_path):
    ws = Workspace(root=tmp_path, session_id="exec5")
    tool = SandboxExecTool(ws, timeout=5)
    result = await tool.execute({"command": "echo 'a b c' | wc -w"})
    assert not result.is_error
    assert "3" in result.content


@pytest.mark.asyncio
async def test_sandbox_empty_command(tmp_path):
    ws = Workspace(root=tmp_path, session_id="exec6")
    tool = SandboxExecTool(ws, timeout=5)
    result = await tool.execute({"command": ""})
    assert result.is_error


# --- WorkspaceFile ---

@pytest.mark.asyncio
async def test_file_write_read_roundtrip(tmp_path):
    ws = Workspace(root=tmp_path, session_id="file1")
    tool = WorkspaceFileTool(ws)
    w = await tool.execute({"operation": "write", "path": "test.txt", "content": "hello world"})
    assert not w.is_error
    r = await tool.execute({"operation": "read", "path": "test.txt"})
    assert not r.is_error
    assert r.content == "hello world"


@pytest.mark.asyncio
async def test_file_write_creates_dirs(tmp_path):
    ws = Workspace(root=tmp_path, session_id="file2")
    tool = WorkspaceFileTool(ws)
    result = await tool.execute({"operation": "write", "path": "sub/deep/test.py", "content": "x=1"})
    assert not result.is_error
    assert (ws.cwd / "sub" / "deep" / "test.py").read_text() == "x=1"


@pytest.mark.asyncio
async def test_file_list(tmp_path):
    ws = Workspace(root=tmp_path, session_id="file3")
    tool = WorkspaceFileTool(ws)
    await tool.execute({"operation": "write", "path": "a.txt", "content": "a"})
    await tool.execute({"operation": "write", "path": "b.txt", "content": "b"})
    result = await tool.execute({"operation": "list"})
    assert not result.is_error
    assert "a.txt" in result.content
    assert "b.txt" in result.content


@pytest.mark.asyncio
async def test_file_read_nonexistent(tmp_path):
    ws = Workspace(root=tmp_path, session_id="file4")
    tool = WorkspaceFileTool(ws)
    result = await tool.execute({"operation": "read", "path": "nope.txt"})
    assert result.is_error
    assert "not found" in result.content.lower()


@pytest.mark.asyncio
async def test_file_traversal_rejected(tmp_path):
    ws = Workspace(root=tmp_path, session_id="file5")
    tool = WorkspaceFileTool(ws)
    result = await tool.execute({"operation": "read", "path": "../../etc/passwd"})
    assert result.is_error
    assert "escapes" in result.content.lower() or "traversal" in result.content.lower()
