import pytest
from pathlib import Path

from app.agent.workspace import Workspace


def test_creates_directory(tmp_path):
    ws = Workspace(root=tmp_path, session_id="test1")
    assert ws.cwd.exists()
    assert ws.cwd == (tmp_path / "test1").resolve()


def test_resolve_relative_path(tmp_path):
    ws = Workspace(root=tmp_path, session_id="test2")
    resolved = ws.resolve_path("foo.py")
    assert resolved == (ws.cwd / "foo.py").resolve()


def test_resolve_nested_path(tmp_path):
    ws = Workspace(root=tmp_path, session_id="test3")
    resolved = ws.resolve_path("sub/bar.py")
    assert resolved == (ws.cwd / "sub" / "bar.py").resolve()


def test_rejects_absolute_path(tmp_path):
    ws = Workspace(root=tmp_path, session_id="test4")
    with pytest.raises(ValueError, match="Absolute paths"):
        ws.resolve_path("/etc/passwd")


def test_rejects_traversal(tmp_path):
    ws = Workspace(root=tmp_path, session_id="test5")
    with pytest.raises(ValueError, match="escapes workspace"):
        ws.resolve_path("../../../etc/passwd")


def test_rejects_dot_dot(tmp_path):
    ws = Workspace(root=tmp_path, session_id="test6")
    with pytest.raises(ValueError, match="escapes workspace"):
        ws.resolve_path("..")


def test_auto_session_id(tmp_path):
    ws = Workspace(root=tmp_path)
    assert len(ws.session_id) == 12
    assert ws.cwd.exists()
