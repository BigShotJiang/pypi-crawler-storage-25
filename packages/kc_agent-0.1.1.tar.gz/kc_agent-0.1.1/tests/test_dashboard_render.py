import json
import pytest

from app.agent.workspace import Workspace
from app.agent.tools.dashboard_render import DashboardRenderTool


def _setup(tmp_path, sid="dr1"):
    ws = Workspace(root=tmp_path, session_id=sid)
    for d in ["rules", "output/results", "output/qc", "output/dashboards", "logs/evolution"]:
        (ws.cwd / d).mkdir(parents=True, exist_ok=True)
    # Add some data
    (ws.cwd / "rules" / "catalog.json").write_text(json.dumps([
        {"id": "R001", "description": "Capital ratio check"},
        {"id": "R002", "description": "Liquidity coverage"},
    ]))
    (ws.cwd / "output" / "results" / "r1.json").write_text(json.dumps({"confidence_band": "high"}))
    (ws.cwd / "output" / "results" / "r2.json").write_text(json.dumps({"confidence_band": "medium"}))
    return ws


@pytest.mark.asyncio
async def test_generates_html(tmp_path):
    ws = _setup(tmp_path)
    tool = DashboardRenderTool(ws)
    result = await tool.execute({})
    assert not result.is_error
    assert "dashboard" in result.content.lower()

    html_path = ws.cwd / "output" / "dashboards" / "dashboard.html"
    assert html_path.exists()
    html = html_path.read_text()
    assert "KC Agent Dashboard" in html
    assert "R001" in html
    assert "Capital ratio" in html


@pytest.mark.asyncio
async def test_custom_output_path(tmp_path):
    ws = _setup(tmp_path, "dr2")
    tool = DashboardRenderTool(ws)
    result = await tool.execute({"output_path": "output/my_report.html"})
    assert not result.is_error
    assert (ws.cwd / "output" / "my_report.html").exists()


@pytest.mark.asyncio
async def test_empty_project(tmp_path):
    ws = Workspace(root=tmp_path, session_id="dr3")
    (ws.cwd / "output" / "dashboards").mkdir(parents=True, exist_ok=True)
    tool = DashboardRenderTool(ws)
    result = await tool.execute({})
    assert not result.is_error
