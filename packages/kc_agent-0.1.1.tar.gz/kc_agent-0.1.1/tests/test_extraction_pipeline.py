import json
import pytest
from pathlib import Path

from app.agent.workspace import Workspace
from app.agent.tools.base import ToolResult
from app.agent.pipelines import Phase
from app.agent.pipelines.extraction import RuleExtractionPipeline


def _setup_workspace(tmp_path, session_id):
    ws = Workspace(root=tmp_path, session_id=session_id)
    for d in ["rules", "samples", "input", "output", "rule_skills"]:
        (ws.cwd / d).mkdir(parents=True, exist_ok=True)
    return ws


def test_initial_state_no_regulations(tmp_path):
    ws = _setup_workspace(tmp_path, "ext1")
    pipe = RuleExtractionPipeline(ws)
    assert not pipe.regulations_scanned
    assert len(pipe.rules_extracted) == 0
    assert not pipe.exit_criteria_met()


def test_scans_regulations(tmp_path):
    ws = _setup_workspace(tmp_path, "ext2")
    (ws.cwd / "rules" / "regulation.xlsx").write_bytes(b"fake")
    pipe = RuleExtractionPipeline(ws)
    assert pipe.regulations_scanned


def test_scans_existing_rules_json(tmp_path):
    ws = _setup_workspace(tmp_path, "ext3")
    (ws.cwd / "rules" / "reg.pdf").write_bytes(b"fake")
    rules = [{"id": "R001", "name": "test rule"}, {"id": "R002", "name": "another"}]
    (ws.cwd / "rules" / "trust_rules.json").write_text(json.dumps(rules))
    pipe = RuleExtractionPipeline(ws)
    assert len(pipe.rules_extracted) == 2
    assert "R001" in pipe.rules_extracted


def test_on_tool_result_tracks_rule_writes(tmp_path):
    ws = _setup_workspace(tmp_path, "ext4")
    (ws.cwd / "rules" / "reg.pdf").write_bytes(b"fake")
    rules = [{"id": "R001"}, {"id": "R002"}, {"id": "R003"}]
    (ws.cwd / "rules" / "trust_rules.json").write_text(json.dumps(rules))
    pipe = RuleExtractionPipeline(ws)

    # Simulate writing an updated rules file
    updated = rules + [{"id": "R004"}]
    (ws.cwd / "rules" / "trust_rules.json").write_text(json.dumps(updated))
    result = ToolResult(content="Wrote rules")
    pipe.on_tool_result("workspace_file", {"operation": "write", "path": "rules/trust_rules.json"}, result)

    assert "R004" in pipe.rules_extracted


def test_describe_state_shows_phase(tmp_path):
    ws = _setup_workspace(tmp_path, "ext5")
    (ws.cwd / "rules" / "reg.pdf").write_bytes(b"fake")
    pipe = RuleExtractionPipeline(ws)
    state = pipe.describe_state()
    assert "EXTRACTION" in state
    assert "Exit criteria" in state


def test_exit_criteria_full(tmp_path):
    ws = _setup_workspace(tmp_path, "ext6")
    (ws.cwd / "rules" / "reg.pdf").write_bytes(b"fake")
    rules = [{"id": f"R{i:03d}"} for i in range(10)]
    (ws.cwd / "rules" / "trust_rules.json").write_text(json.dumps(rules))

    # Create test cases for 8/10 rules (80%)
    for i in range(8):
        test_dir = ws.cwd / "rule_skills" / f"R{i:03d}" / "test_cases"
        test_dir.mkdir(parents=True)
        (test_dir / "test1.json").write_text('{"expected": "value"}')

    # Create coverage audit
    (ws.cwd / "rules" / "coverage_audit.md").write_text("# Coverage: 100%")

    pipe = RuleExtractionPipeline(ws)
    assert pipe.exit_criteria_met()


def test_phase_ready_event(tmp_path):
    ws = _setup_workspace(tmp_path, "ext7")
    (ws.cwd / "rules" / "reg.pdf").write_bytes(b"fake")
    rules = [{"id": "R001"}]
    (ws.cwd / "rules" / "trust_rules.json").write_text(json.dumps(rules))

    # Set up test cases
    test_dir = ws.cwd / "rule_skills" / "R001" / "test_cases"
    test_dir.mkdir(parents=True)
    (test_dir / "test1.json").write_text("{}")

    pipe = RuleExtractionPipeline(ws)

    # Write coverage audit — should trigger phase_ready
    (ws.cwd / "rules" / "coverage_audit.md").write_text("done")
    result = ToolResult(content="Wrote coverage audit")
    event = pipe.on_tool_result("workspace_file", {"operation": "write", "path": "rules/coverage_audit.md"}, result)

    assert event is not None
    assert event.type == "phase_ready"
    assert event.next_phase == Phase.SKILL_AUTHORING
