import json
import pytest
from pathlib import Path

from app.agent.workspace import Workspace
from app.agent.tools.base import ToolResult
from app.agent.pipelines import Phase
from app.agent.pipelines.skill_authoring import SkillAuthoringPipeline


def _setup(tmp_path, session_id, num_rules=3):
    ws = Workspace(root=tmp_path, session_id=session_id)
    for d in ["rules", "samples", "rule_skills"]:
        (ws.cwd / d).mkdir(parents=True, exist_ok=True)
    rules = [{"id": f"R{i:03d}"} for i in range(num_rules)]
    (ws.cwd / "rules" / "rules.json").write_text(json.dumps(rules))
    return ws


def test_loads_rules_from_json(tmp_path):
    ws = _setup(tmp_path, "sa1", 5)
    pipe = SkillAuthoringPipeline(ws)
    assert len(pipe.total_rules) == 5


def test_no_skills_initially(tmp_path):
    ws = _setup(tmp_path, "sa2")
    pipe = SkillAuthoringPipeline(ws)
    assert len(pipe.skills_authored) == 0
    assert not pipe.exit_criteria_met()


def test_tracks_skill_creation(tmp_path):
    ws = _setup(tmp_path, "sa3", 2)
    pipe = SkillAuthoringPipeline(ws)

    # Create skill for R000
    skill_dir = ws.cwd / "rule_skills" / "R000"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("# Rule R000")
    scripts_dir = skill_dir / "scripts"
    scripts_dir.mkdir()
    (scripts_dir / "check.py").write_text("pass")

    pipe.on_tool_result("workspace_file", {"operation": "write", "path": "rule_skills/R000/SKILL.md"}, ToolResult(content="ok"))
    assert "R000" in pipe.skills_authored


def test_exit_criteria(tmp_path):
    ws = _setup(tmp_path, "sa4", 2)

    # Create both skills with scripts
    for rid in ["R000", "R001"]:
        d = ws.cwd / "rule_skills" / rid
        d.mkdir(parents=True)
        (d / "SKILL.md").write_text(f"# {rid}")
        s = d / "scripts"
        s.mkdir()
        (s / "check.py").write_text("pass")

    pipe = SkillAuthoringPipeline(ws)
    assert pipe.exit_criteria_met()


def test_phase_ready_event(tmp_path):
    ws = _setup(tmp_path, "sa5", 1)
    pipe = SkillAuthoringPipeline(ws)

    # Create skill
    d = ws.cwd / "rule_skills" / "R000"
    d.mkdir(parents=True)
    (d / "SKILL.md").write_text("# R000")
    s = d / "scripts"
    s.mkdir()
    (s / "check.py").write_text("pass")

    event = pipe.on_tool_result("workspace_file", {"operation": "write", "path": "rule_skills/R000/SKILL.md"}, ToolResult(content="ok"))
    assert event is not None
    assert event.type == "phase_ready"
    assert event.next_phase == Phase.SKILL_TESTING


def test_describe_state(tmp_path):
    ws = _setup(tmp_path, "sa6")
    pipe = SkillAuthoringPipeline(ws)
    state = pipe.describe_state()
    assert "SKILL_AUTHORING" in state
    assert "Rules from extraction: 3" in state
