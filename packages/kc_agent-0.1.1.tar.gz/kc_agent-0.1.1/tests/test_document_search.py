import pytest

from app.agent.workspace import Workspace
from app.agent.tools.document_search import DocumentSearchTool


def _setup(tmp_path, sid="ds1"):
    ws = Workspace(root=tmp_path, session_id=sid)
    (ws.cwd / "rules").mkdir(parents=True, exist_ok=True)
    (ws.cwd / "rules" / "reg.txt").write_text("Article 1: Capital adequacy ratio must be >= 8%\nArticle 2: Liquidity coverage ratio must be >= 100%")
    (ws.cwd / "rules" / "notes.md").write_text("# Notes\nThe capital ratio is critical for compliance.")
    return ws


@pytest.mark.asyncio
async def test_basic_search(tmp_path):
    ws = _setup(tmp_path)
    tool = DocumentSearchTool(ws)
    result = await tool.execute({"query": "capital"})
    assert not result.is_error
    assert "capital" in result.content.lower()
    assert "2 match" in result.content.lower()


@pytest.mark.asyncio
async def test_search_scoped_path(tmp_path):
    ws = _setup(tmp_path, "ds2")
    (ws.cwd / "samples").mkdir()
    (ws.cwd / "samples" / "s.txt").write_text("no capital here, just sample data")
    tool = DocumentSearchTool(ws)
    result = await tool.execute({"query": "capital", "path": "rules"})
    assert "2 match" in result.content.lower()


@pytest.mark.asyncio
async def test_regex_search(tmp_path):
    ws = _setup(tmp_path, "ds3")
    tool = DocumentSearchTool(ws)
    result = await tool.execute({"query": r">=\s*\d+%", "regex": True})
    assert not result.is_error
    assert ">=" in result.content


@pytest.mark.asyncio
async def test_no_matches(tmp_path):
    ws = _setup(tmp_path, "ds4")
    tool = DocumentSearchTool(ws)
    result = await tool.execute({"query": "xyznonexistent"})
    assert "no matches" in result.content.lower()


@pytest.mark.asyncio
async def test_max_results(tmp_path):
    ws = _setup(tmp_path, "ds5")
    tool = DocumentSearchTool(ws)
    result = await tool.execute({"query": "Article", "max_results": 1})
    assert "1 match" in result.content.lower()
