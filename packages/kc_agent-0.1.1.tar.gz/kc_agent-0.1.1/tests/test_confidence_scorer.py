import json
import pytest
from pathlib import Path

from app.agent.confidence_scorer import ConfidenceScorer
from app.agent.corner_case_registry import CornerCaseRegistry, CornerCase


def _setup(tmp_path):
    ws = tmp_path / "ws"
    ws.mkdir()
    (ws / ".env").write_text("")
    return ws


def test_default_score(tmp_path):
    ws = _setup(tmp_path)
    scorer = ConfidenceScorer(ws)
    score = scorer.score(rule_id="R001", extracted_value="test", extraction_method="llm")
    assert 0.0 < score <= 1.0


def test_regex_higher_than_llm(tmp_path):
    ws = _setup(tmp_path)
    scorer = ConfidenceScorer(ws)
    regex_score = scorer.score(rule_id="R001", extracted_value="v", extraction_method="regex")
    llm_score = scorer.score(rule_id="R001", extracted_value="v", extraction_method="llm")
    assert regex_score > llm_score


def test_source_presence_boost(tmp_path):
    ws = _setup(tmp_path)
    scorer = ConfidenceScorer(ws)
    present = scorer.score(rule_id="R001", extracted_value="hello", source_text="say hello world", extraction_method="llm")
    absent = scorer.score(rule_id="R001", extracted_value="hello", source_text="nothing here", extraction_method="llm")
    assert present > absent


def test_corner_case_reduces_confidence(tmp_path):
    ws = _setup(tmp_path)
    reg = CornerCaseRegistry(ws)
    reg.add(CornerCase(id="CC1", rule_id="R001", detection_pattern="scanned", resolution="use ocr"))

    scorer = ConfidenceScorer(ws, corner_cases=reg)
    normal = scorer.score(rule_id="R001", extracted_value="v", document_name="digital.pdf")
    corner = scorer.score(rule_id="R001", extracted_value="v", document_name="scanned_doc.pdf")
    assert corner < normal


def test_calibration(tmp_path):
    ws = _setup(tmp_path)
    scorer = ConfidenceScorer(ws)

    scorer.calibrate({"R001": {"actual_accuracy": 0.6}})
    after = scorer.score(rule_id="R001", extracted_value="v", extraction_method="llm")

    # Score should be lower after calibration with low accuracy
    scorer2 = ConfidenceScorer(ws)  # reload
    assert scorer2._historical.get("R001", 0.8) < 0.8


def test_bands(tmp_path):
    ws = _setup(tmp_path)
    scorer = ConfidenceScorer(ws)
    assert scorer.get_band(0.9) == "high"
    assert scorer.get_band(0.6) == "medium"
    assert scorer.get_band(0.3) == "low"
