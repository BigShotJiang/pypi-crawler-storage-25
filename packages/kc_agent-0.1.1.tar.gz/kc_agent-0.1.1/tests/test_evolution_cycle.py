import json
import pytest

from app.agent.workspace import Workspace
from app.agent.corner_case_registry import CornerCaseRegistry
from app.agent.tools.evolution_cycle import EvolutionCycleTool


def _setup(tmp_path, sid="ev1"):
    ws = Workspace(root=tmp_path, session_id=sid)
    for d in ["logs/evolution", "output"]:
        (ws.cwd / d).mkdir(parents=True, exist_ok=True)
    (ws.cwd / ".env").write_text("SKILL_ACCURACY=0.9\n")
    reg = CornerCaseRegistry(ws.cwd)
    return ws, reg


@pytest.mark.asyncio
async def test_systemic_classification(tmp_path):
    ws, reg = _setup(tmp_path)
    tool = EvolutionCycleTool(ws, reg)

    result = await tool.execute({
        "rule_id": "R001",
        "total_test_docs": 10,
        "failed_docs": [
            {"doc_id": "d1", "diagnosis": "extraction", "root_cause": "wrong field"},
            {"doc_id": "d2", "diagnosis": "extraction", "root_cause": "wrong field"},
        ],
        "accuracy_before": 0.8,
    })
    assert not result.is_error
    data = json.loads(result.content)
    assert data["classification"] == "systemic"
    assert "REWRITE" in data["action"]


@pytest.mark.asyncio
async def test_corner_case_classification(tmp_path):
    ws, reg = _setup(tmp_path, "ev2")
    tool = EvolutionCycleTool(ws, reg)

    result = await tool.execute({
        "rule_id": "R001",
        "total_test_docs": 100,
        "failed_docs": [
            {"doc_id": "d1", "diagnosis": "parsing", "root_cause": "stamp overlay"},
        ],
        "accuracy_before": 0.99,
    })
    data = json.loads(result.content)
    assert data["classification"] == "corner_case"
    assert "corner case" in data["action"].lower()
    # Corner case should be added to registry
    assert reg.count() == 1


@pytest.mark.asyncio
async def test_saves_log(tmp_path):
    ws, reg = _setup(tmp_path, "ev3")
    tool = EvolutionCycleTool(ws, reg)

    await tool.execute({
        "rule_id": "R001",
        "total_test_docs": 10,
        "failed_docs": [{"doc_id": "d1", "diagnosis": "extraction", "root_cause": "bad regex"}],
        "accuracy_before": 0.9,
        "fix_applied": "Updated regex pattern",
    })

    log_dir = ws.cwd / "logs" / "evolution"
    logs = list(log_dir.glob("R001_iter_*.json"))
    assert len(logs) == 1
    data = json.loads(logs[0].read_text())
    assert data["fix_applied"] == "Updated regex pattern"


@pytest.mark.asyncio
async def test_detects_repeated_patterns(tmp_path):
    ws, reg = _setup(tmp_path, "ev4")
    tool = EvolutionCycleTool(ws, reg)

    # First iteration
    await tool.execute({
        "rule_id": "R001",
        "total_test_docs": 10,
        "failed_docs": [{"doc_id": "d1", "diagnosis": "extraction", "root_cause": "date format wrong"}],
        "accuracy_before": 0.9,
    })

    # Second iteration with same pattern
    result = await tool.execute({
        "rule_id": "R001",
        "total_test_docs": 10,
        "failed_docs": [{"doc_id": "d2", "diagnosis": "extraction", "root_cause": "date format wrong"}],
        "accuracy_before": 0.9,
    })
    data = json.loads(result.content)
    assert len(data["repeated_patterns"]) > 0
    assert "warning" in data


@pytest.mark.asyncio
async def test_increments_iteration(tmp_path):
    ws, reg = _setup(tmp_path, "ev5")
    tool = EvolutionCycleTool(ws, reg)

    await tool.execute({
        "rule_id": "R001", "total_test_docs": 10,
        "failed_docs": [{"doc_id": "d1", "diagnosis": "parsing", "root_cause": "x"}],
        "accuracy_before": 0.8,
    })
    result = await tool.execute({
        "rule_id": "R001", "total_test_docs": 10,
        "failed_docs": [{"doc_id": "d2", "diagnosis": "parsing", "root_cause": "y"}],
        "accuracy_before": 0.85,
    })
    data = json.loads(result.content)
    assert data["iteration"] == 2
