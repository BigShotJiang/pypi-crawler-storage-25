# kc-agent

Python backend for KC Agent — a document verification coding agent.

This is the backend engine. Install the CLI for the full experience:

```bash
npm install -g @kitchen-engineer42/kc-agent-cli
kc onboard
kc
```

Or run the backend directly:

```bash
pip install kc-agent
kc-agent-server
```

See https://github.com/kitchen-engineer42/kc-reborn for full documentation.
