# Changelog

All notable changes to the LaunchDarkly Python AI OpenAI provider package will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org).

## [0.6.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.6.0...launchdarkly-server-sdk-ai-openai-0.6.1) (2026-05-14)


### Bug Fixes

* Make judge runners non-multi-turn ([#185](https://github.com/launchdarkly/python-server-sdk-ai/issues/185)) ([5c21bd0](https://github.com/launchdarkly/python-server-sdk-ai/commit/5c21bd08bebfbdc5672afa93ad99099202955c92))

## [0.6.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.5.0...launchdarkly-server-sdk-ai-openai-0.6.0) (2026-05-13)


### ⚠ BREAKING CHANGES

* Narrow AgentGraphRunner.run input from Any to str ([#177](https://github.com/launchdarkly/python-server-sdk-ai/issues/177))
* Rename LDAIMetrics.usage and AIGraphMetrics.usage to .tokens ([#175](https://github.com/launchdarkly/python-server-sdk-ai/issues/175))
* rename GraphMetrics/GraphMetricSummary to AIGraphMetrics/AIGraphMetricSummary ([#173](https://github.com/launchdarkly/python-server-sdk-ai/issues/173))

### Features

* Narrow AgentGraphRunner.run input from Any to str ([#177](https://github.com/launchdarkly/python-server-sdk-ai/issues/177)) ([cc7a0fe](https://github.com/launchdarkly/python-server-sdk-ai/commit/cc7a0fe64549337c71036cd67973bf0af91c7a42))
* rename GraphMetrics/GraphMetricSummary to AIGraphMetrics/AIGraphMetricSummary ([#173](https://github.com/launchdarkly/python-server-sdk-ai/issues/173)) ([583939d](https://github.com/launchdarkly/python-server-sdk-ai/commit/583939dbe5c11c3c11ed960ee0b46ec377f1bb70))
* Rename LDAIMetrics.usage and AIGraphMetrics.usage to .tokens ([#175](https://github.com/launchdarkly/python-server-sdk-ai/issues/175)) ([d8c4a70](https://github.com/launchdarkly/python-server-sdk-ai/commit/d8c4a702d4b68f146de7ca520bc35f2aa0b155f6))


### Bug Fixes

* Always return ModelSettings from _build_model_settings ([#169](https://github.com/launchdarkly/python-server-sdk-ai/issues/169)) ([6d1ce4c](https://github.com/launchdarkly/python-server-sdk-ai/commit/6d1ce4c921a0ef4ea483316dcb8dd6fe7766b59e))

## [0.5.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.4.0...launchdarkly-server-sdk-ai-openai-0.5.0) (2026-05-05)


### ⚠ BREAKING CHANGES

* `OpenAIModelRunner` no longer exposes `invoke_model()` or `invoke_structured_model()`. It now implements the unified `Runner` protocol — use `run(input: str)` instead. The return type is `RunnerResult` (replacing `ModelResponse` / `StructuredResponse`). ([#149](https://github.com/launchdarkly/python-server-sdk-ai/issues/149))


### Features

* Add judge evaluation support to agent graphs ([#142](https://github.com/launchdarkly/python-server-sdk-ai/issues/142)) ([3d5a6a9](https://github.com/launchdarkly/python-server-sdk-ai/commit/3d5a6a91a87c7475a83a7e440cd4b71337cfd56f))
* Support conversation history directly in AI Provider model runners ([#166](https://github.com/launchdarkly/python-server-sdk-ai/issues/166)) ([4bb3e78](https://github.com/launchdarkly/python-server-sdk-ai/commit/4bb3e7813f7c087302ba8446dea6a4a41f012c2e))
* Update OpenAI graph runner to return AgentGraphRunnerResult with GraphMetrics ([#155](https://github.com/launchdarkly/python-server-sdk-ai/issues/155)) ([388b7af](https://github.com/launchdarkly/python-server-sdk-ai/commit/388b7af70c23180607764a0fc4783ae4d0cd096d))
* Update OpenAI runners to implement Runner protocol returning RunnerResult ([#149](https://github.com/launchdarkly/python-server-sdk-ai/issues/149)) ([382e662](https://github.com/launchdarkly/python-server-sdk-ai/commit/382e662af00b224f7269397beea94c70c2872b9a))


### Bug Fixes

* build judge input as string; strip legacy judge config messages ([#165](https://github.com/launchdarkly/python-server-sdk-ai/issues/165)) ([e6942a6](https://github.com/launchdarkly/python-server-sdk-ai/commit/e6942a6e2d4db17ae1fa6191521f8ac4fb48f30d))

## [0.4.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.3.0...launchdarkly-server-sdk-ai-openai-0.4.0) (2026-04-21)


### Features

* Updated to use per-execution tracker lifecycle via `create_tracker()` instead of static tracker instances
* Renamed graph metrics method from `track_latency()` to `track_duration()` for consistency
* Moved graph_key configuration from graph tracker instantiation to node tracker initialization
* Cached node trackers during graph execution to ensure consistent runId across node-level events

### Dependencies

* Updated for compatibility with `launchdarkly-server-sdk-ai` 0.18.0

## [0.3.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.2.1...launchdarkly-server-sdk-ai-openai-0.3.0) (2026-04-02)


### ⚠ BREAKING CHANGES

* Restructure provider factory and support additional create methods ([#102](https://github.com/launchdarkly/python-server-sdk-ai/issues/102))
* Extract shared utilities to openai_helper

### Features

* Add OpenAIAgentRunner with agentic tool-calling loop ([53fd95e](https://github.com/launchdarkly/python-server-sdk-ai/commit/53fd95e2cfb66f4c53c6844cc41170077e6eee8c))
* Add OpenAIAgentGraphRunner ([56ce0fd](https://github.com/launchdarkly/python-server-sdk-ai/commit/56ce0fd63b4301b58f33c17c55c4ecd47e9f8559))
* Extract shared utilities to openai_helper ([453c71c](https://github.com/launchdarkly/python-server-sdk-ai/commit/453c71c84adcc6b8a3e316a98907dcb511bc9d41))
* Add get_ai_usage_from_response to openai_helper ([4fab18f](https://github.com/launchdarkly/python-server-sdk-ai/commit/4fab18fa62375b6c97cb12a89225805c81ca4ee8))
* Drop support for python 3.9 ([#114](https://github.com/launchdarkly/python-server-sdk-ai/issues/114)) ([dc592c5](https://github.com/launchdarkly/python-server-sdk-ai/commit/dc592c5a2e2bf3bf679af14a9aa63e81678a69ab))

## [0.2.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.2.0...launchdarkly-server-sdk-ai-openai-0.2.1) (2026-03-16)


### Bug Fixes

* Update comments for setting default ([#99](https://github.com/launchdarkly/python-server-sdk-ai/issues/99)) ([a14761d](https://github.com/launchdarkly/python-server-sdk-ai/commit/a14761d0f832e2fd07323f1f5322c76a1d7d7bf6))

## [0.2.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.1.1...launchdarkly-server-sdk-ai-openai-0.2.0) (2026-03-09)


### ⚠ BREAKING CHANGES

* Rename default_value args to default

### Bug Fixes

* Make default optional with a disabled config default ([#97](https://github.com/launchdarkly/python-server-sdk-ai/issues/97)) ([39e09c6](https://github.com/launchdarkly/python-server-sdk-ai/commit/39e09c616bcb36af56983094039ee72a97bd1a19))
* Rename default_value args to default ([39e09c6](https://github.com/launchdarkly/python-server-sdk-ai/commit/39e09c616bcb36af56983094039ee72a97bd1a19))

## [0.1.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-openai-0.1.0...launchdarkly-server-sdk-ai-openai-0.1.1) (2026-02-23)


### Bug Fixes

* Update pre-release usage guidance ([#90](https://github.com/launchdarkly/python-server-sdk-ai/issues/90)) ([4f986c4](https://github.com/launchdarkly/python-server-sdk-ai/commit/4f986c4b4f74f001e5487892509129bdc9aa091c))

## 0.1.0 (2026-01-02)


### ⚠ BREAKING CHANGES

* Bump requirement of launchdarkly-server-sdk-ai to 0.12.0

### Features

* Add OpenAI provider package ([#78](https://github.com/launchdarkly/python-server-sdk-ai/issues/78)) ([ec2272e](https://github.com/launchdarkly/python-server-sdk-ai/commit/ec2272ef91203343f112e7262510117fc69207bd))


### Bug Fixes

* Bump requirement of launchdarkly-server-sdk-ai to 0.12.0 ([ec2272e](https://github.com/launchdarkly/python-server-sdk-ai/commit/ec2272ef91203343f112e7262510117fc69207bd))
