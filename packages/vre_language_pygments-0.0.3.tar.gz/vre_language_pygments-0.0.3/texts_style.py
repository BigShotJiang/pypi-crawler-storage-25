"""Pygments plugin style for textS/textM"""
from pygments.style import Style
from pygments.styles.default import DefaultStyle
from pygments.token import Keyword, Token


class TextSStyle(Style):
    """This style merely highlights keywords in red"""
    styles = {
        Keyword: '#f00',
    }


class VMLangStyle(DefaultStyle):
    """Extends the Pygments default style with VRE-Language CLI tweaks"""
    # tweaks from jupyter_console/ptshell.py:526-533 to be consistent
    styles = {
        **DefaultStyle.styles,
        Token.Number:         '#007700',
        Token.Operator:       'noinherit',
        Token.String:         '#BB6622',
        Token.Name.Function:  '#2080D0',
        Token.Name.Class:     'bold #2080D0',
        Token.Name.Namespace: 'bold #2080D0',
    }
