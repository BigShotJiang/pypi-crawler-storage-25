# thaillm

Python SDK for ThaiLLM API

## Installation

```bash
pip install thaillm
```

## Usage

```python
from thaillm import ThaiLLM

client = ThaiLLM(
    api_key="YOUR_API_KEY"
)

reply = client.chat("สวัสดี")

print(reply)
```