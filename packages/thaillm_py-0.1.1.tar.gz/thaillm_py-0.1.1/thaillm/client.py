import requests


class ThaiLLM:
    def __init__(
        self,
        api_key,
        model="typhoon-s-thaillm-8b-instruct",
        base_url="http://thaillm.or.th/api/v1/chat/completions"
    ):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url

    def chat(
        self,
        message,
        max_tokens=2048,
        temperature=0.3
    ):
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": message
                }
            ],
            "max_tokens": max_tokens,
            "temperature": temperature
        }

        response = requests.post(
            self.base_url,
            headers=headers,
            json=payload,
            timeout=60
        )

        response.raise_for_status()

        data = response.json()

        if "choices" not in data:
            raise Exception(f"Invalid response: {data}")

        return data["choices"][0]["message"]["content"]