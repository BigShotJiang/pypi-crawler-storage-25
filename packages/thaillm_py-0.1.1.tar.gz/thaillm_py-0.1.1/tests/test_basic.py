from thaillm import ThaiLLM


def test_client_creation():
    client = ThaiLLM(api_key="test-key")

    assert client.api_key == "test-key"
    assert client.model == "typhoon-s-thaillm-8b-instruct"


def test_chat_method_exists():
    client = ThaiLLM(api_key="test-key")

    assert callable(client.chat)