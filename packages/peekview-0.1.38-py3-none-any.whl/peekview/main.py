"""FastAPI application factory and main entry point."""

import logging
import os
import shutil
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from peekview import __version__
from peekview.config import PeekConfig
from peekview.database import init_db
from peekview.exceptions import PeekError
from peekview.api.rate_limit import limiter
from slowapi.errors import RateLimitExceeded
from sqlalchemy import text

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager.

    Handles startup and shutdown events.
    """
    # Startup
    config: PeekConfig = app.state.config
    logger.info(f"Starting PeekView server v{app.version}")
    logger.info(f"Data directory: {config.data_dir}")
    logger.info(f"Database: {config.db_path}")

    # Initialize database
    init_db(config.db_path)

    yield

    # Shutdown
    logger.info("Shutting down PeekView server")


def create_app(
    data_dir: Path | None = None,
    db_path: Path | None = None,
    base_url: str | None = None,
    rate_limit_enabled: bool | None = None,
) -> FastAPI:
    """Create and configure the FastAPI application.

    This factory function creates a new app instance with all
    configurations, middleware, and routes. Use this in tests
    with custom data_dir/db_path.

    Args:
        data_dir: Optional data directory override
        db_path: Optional database path override
        base_url: Optional external base URL override

    Returns:
        Configured FastAPI application
    """
    app = FastAPI(
        title="PeekView",
        description="A lightweight code & document formatting display service",
        version=__version__,
        lifespan=lifespan,
    )

    # Load configuration
    config = PeekConfig()
    if data_dir:
        config.storage.data_dir = data_dir
    if db_path:
        config.storage.db_path = db_path
    if base_url:
        config.server.base_url = base_url
    if rate_limit_enabled is not None:
        config.server.rate_limit_enabled = rate_limit_enabled
    app.state.config = config

    # Ensure directories exist
    config.data_dir.mkdir(parents=True, exist_ok=True)

    # Initialize database and services
    engine = init_db(config.db_path)
    app.state.engine = engine

    from peekview.storage import StorageManager
    from peekview.services.entry_service import EntryService
    from peekview.services.apikey_service import ApiKeyService
    storage = StorageManager(config=config)
    entry_service = EntryService(engine=engine, storage=storage, config=config)
    apikey_service = ApiKeyService(engine=engine)
    app.state.entry_service = entry_service
    app.state.apikey_service = apikey_service

    # Setup CORS - use config or default
    cors_origins = getattr(config, 'cors_origins', ["http://localhost:5173"])
    if isinstance(cors_origins, str):
        cors_origins = cors_origins.split(",")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins or ["http://localhost:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Security headers middleware (API and health only, not static files)
    @app.middleware("http")
    async def add_security_headers(request: Request, call_next):
        response = await call_next(request)
        if request.url.path.startswith("/api") or request.url.path == "/health":
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["Cache-Control"] = "no-store"
            response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
            response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
        return response

    # API key auth middleware (if configured)
    api_key = getattr(config.server, 'api_key', '') or getattr(config, 'api_key', '')
    if api_key:
        @app.middleware("http")
        async def api_key_auth(request: Request, call_next):
            # Skip auth for health check
            if request.url.path == "/health":
                return await call_next(request)

            # Skip auth for static files
            if request.url.path.startswith("/assets") or request.url.path == "/":
                return await call_next(request)

            # Skip auth for auth endpoints (JWT handles these)
            if request.url.path.startswith("/api/v1/auth"):
                return await call_next(request)

            # Skip auth for API key management endpoints (require JWT)
            if request.url.path.startswith("/api/v1/apikeys"):
                return await call_next(request)

            # Pass through user-level API keys (pv_ prefix) — handled by get_current_user
            x_api_key = request.headers.get("X-API-Key", "")
            if x_api_key.startswith("pv_"):
                return await call_next(request)

            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
                if token.startswith("pv_"):
                    return await call_next(request)

            # Check X-API-Key header (global master key)
            if x_api_key == api_key:
                return await call_next(request)

            # Check Authorization: Bearer (backward compat, only for non-JWT tokens)
            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
                # If token looks like JWT (3 segments), skip — it's user auth
                if len(token.split(".")) != 3 and token == api_key:
                    return await call_next(request)

            return JSONResponse(
                status_code=401,
                content={"error": {"code": "UNAUTHORIZED", "message": "Invalid or missing API key", "details": None}},
            )

    # Request logging middleware
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        start = time.time()
        response = await call_next(request)
        duration = (time.time() - start) * 1000
        logger.info(
            "%s %s → %d (%.1fms)",
            request.method, request.url.path, response.status_code, duration,
        )
        return response

    # Configure rate limiter (no default limits — only decorator-based per-route limits)
    app.state.limiter = limiter
    limiter.enabled = config.server.rate_limit_enabled

    # Rate limit exception handler
    @app.exception_handler(RateLimitExceeded)
    async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
        return JSONResponse(
            status_code=429,
            content={"error": {"code": "RATE_LIMITED", "message": str(exc.detail), "details": None}},
        )

    # Add SlowAPIMiddleware for decorator-based rate limiting
    from slowapi.middleware import SlowAPIMiddleware
    app.add_middleware(SlowAPIMiddleware)

    # Register API routes
    from peekview.api.auth import router as auth_router
    from peekview.api.apikeys import router as apikeys_router
    from peekview.api.entries import router as entries_router
    from peekview.api.files import router as files_router
    app.include_router(auth_router)
    app.include_router(apikeys_router)
    app.include_router(entries_router)
    app.include_router(files_router)

    # Health check (must be before static files to avoid catch-all route)
    @app.get("/health")
    async def health_check(request: Request):
        config = request.app.state.config
        engine = request.app.state.engine
        checks = {}
        warnings = []

        # Database connectivity
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            checks["database"] = "ok"
        except Exception as e:
            checks["database"] = f"error: {e}"
            warnings.append("database_error")

        # Storage directory accessibility
        data_dir = config.storage.data_dir
        if data_dir.exists() and os.access(data_dir, os.W_OK):
            checks["storage"] = "ok"
        else:
            checks["storage"] = "error: data_dir not accessible"
            warnings.append("storage_error")

        # Disk space
        try:
            usage = shutil.disk_usage(data_dir)
            free_mb = usage.free // (1024 * 1024)
            checks["disk_space_mb"] = free_mb
            if free_mb < config.storage.health_disk_warning_mb:
                warnings.append("disk_space_low")
        except Exception:
            checks["disk_space_mb"] = "unknown"

        status = "ok" if not warnings else "degraded"
        result = {"status": status, "version": app.version, "checks": checks}
        if warnings:
            result["warnings"] = warnings
        return result

    # Add global exception handler for PeekError
    @app.exception_handler(PeekError)
    async def peek_error_handler(request: Request, exc: PeekError):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": {
                    "code": exc.error_code,
                    "message": str(exc),
                    "details": None,
                }
            },
        )

    # Add generic exception handler
    @app.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception):
        logger.exception("Unhandled exception")
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "An unexpected error occurred",
                    "details": None,
                }
            },
        )

    # Static file serving for production SPA build
    _setup_static_files(app)

    return app


def _setup_static_files(app: FastAPI) -> None:
    """Mount static file serving for production SPA build if the dist directory exists."""
    try:
        from fastapi.staticfiles import StaticFiles

        # Look for frontend build in standard locations (in order of preference)
        possible_paths = [
            # Development: frontend-v3/dist (current frontend)
            Path(__file__).parent.parent.parent / "frontend-v3" / "dist",
            # Installed package: peekview/static (package directory)
            Path(__file__).parent / "static",
        ]

        frontend_dist = None
        for path in possible_paths:
            if path.exists() and path.is_dir() and (path / "index.html").exists():
                frontend_dist = path
                break

        if frontend_dist:
            assets_dir = frontend_dist / "assets"
            if assets_dir.exists():
                app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

            @app.get("/")
            async def serve_spa():
                from fastapi.responses import FileResponse
                return FileResponse(frontend_dist / "index.html")

            @app.get("/{path:path}")
            async def serve_spa_catchall(request: Request, path: str):
                """Catch-all for SPA routing — serve index.html for unknown paths."""
                from fastapi.responses import FileResponse

                # Skip API routes - they should be handled by the API routers
                if path.startswith("api/") or path.startswith("health"):
                    # Return 404 so FastAPI continues to try other routes
                    from fastapi import HTTPException
                    raise HTTPException(status_code=404, detail="Not found")

                # First try to serve the actual file
                file_path = frontend_dist / path
                if file_path.exists() and file_path.is_file():
                    return FileResponse(file_path)
                # Otherwise serve index.html for SPA routing
                return FileResponse(frontend_dist / "index.html")

            logger.info("Serving frontend SPA from %s", frontend_dist)
    except Exception:
        # Frontend not built yet, that's ok
        pass


def get_app() -> FastAPI:
    """Lazy app factory for uvicorn.

    Use this with uvicorn's factory mode to avoid import-time side effects:
        uvicorn peekview.main:get_app --factory

    Returns:
        FastAPI application instance
    """
    return create_app()
