#include "test_framework.hpp"
#include "test_helpers.hpp"

#include <array>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_set>
#include <vector>

#include "termflow/analysis/ascii_folding_filter.hpp"
#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/analysis/english_possessive_filter.hpp"
#include "termflow/analysis/lower_case_filter.hpp"
#include "termflow/analysis/porter_stem_filter.hpp"
#include "termflow/analysis/standard_tokenizer.hpp"
#include "termflow/analysis/stop_filter.hpp"
#include "termflow/analysis/unicode_normalize_filter.hpp"

using termflow::test::position_increments;
using termflow::test::positions;
using termflow::test::token_texts;

namespace {

void apply_manual_pre_stem_filters(std::vector<termflow::Token>& tokens,
                                   const termflow::EnglishAnalyzerOptions& options) {
  if (options.unicode_normalization) {
    termflow::UnicodeNormalizeFilter{}.apply(tokens);
  }
  if (options.english_possessive) {
    termflow::EnglishPossessiveFilter{}.apply(tokens);
  }
  if (options.lowercase) {
    termflow::LowerCaseFilter{}.apply(tokens);
  }
}

std::unordered_set<std::string> resolve_stop_words(const termflow::EnglishAnalyzerOptions& options) {
  if (!options.stop_filter) {
    return {};
  }
  if (options.use_default_stop_words) {
    return termflow::EnglishAnalyzer::default_stop_words();
  }
  return options.stop_words;
}

std::string normalize_term_with_public_filters(std::string_view text,
                                               const termflow::EnglishAnalyzerOptions& options) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = std::string(text)},
  };
  apply_manual_pre_stem_filters(tokens, options);
  return tokens.front().text;
}

std::unordered_set<std::string> normalize_term_set_with_public_filters(
    const std::unordered_set<std::string>& values, const termflow::EnglishAnalyzerOptions& options) {
  std::unordered_set<std::string> normalized;
  normalized.reserve(values.size());
  for (const auto& value : values) {
    normalized.insert(normalize_term_with_public_filters(value, options));
  }
  return normalized;
}

void mark_keywords(std::vector<termflow::Token>& tokens,
                   const std::unordered_set<std::string>& stem_exclusion_set) {
  for (auto& token : tokens) {
    if (stem_exclusion_set.contains(token.text)) {
      token.keyword = true;
    }
  }
}

std::vector<termflow::Token> manual_english_pipeline(
    std::string_view input, const termflow::EnglishAnalyzerOptions& options) {
  termflow::StandardTokenizer tokenizer;
  auto tokens = tokenizer.tokenize(input);

  apply_manual_pre_stem_filters(tokens, options);
  termflow::StopFilter(normalize_term_set_with_public_filters(resolve_stop_words(options), options))
      .apply(tokens);
  mark_keywords(tokens, normalize_term_set_with_public_filters(options.stem_exclusion_set, options));

  if (options.stemming) {
    termflow::PorterStemFilter{}.apply(tokens);
  }
  if (options.ascii_folding) {
    termflow::AsciiFoldingFilter{}.apply(tokens);
  }
  return tokens;
}

std::string manual_normalize(std::string_view input,
                             const termflow::EnglishAnalyzerOptions& options) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = std::string(input)},
  };

  if (options.unicode_normalization) {
    termflow::UnicodeNormalizeFilter{}.apply(tokens);
  }
  if (options.lowercase) {
    termflow::LowerCaseFilter{}.apply(tokens);
  }
  if (options.ascii_folding) {
    termflow::AsciiFoldingFilter{}.apply(tokens);
  }
  return tokens.front().text;
}

}  // namespace

TF_TEST(english_analyzer_applies_default_pipeline) {
  termflow::EnglishAnalyzer analyzer;
  const auto tokens = analyzer.analyze("The Running Cars");

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"run", "car"}));
  TF_EXPECT_EQ(position_increments(tokens), std::vector<std::size_t>({2, 1}));
  TF_EXPECT_EQ(positions(tokens), std::vector<std::size_t>({1, 2}));
}

TF_TEST(english_analyzer_can_disable_pipeline_steps) {
  termflow::EnglishAnalyzerOptions options;
  options.use_default_stop_words = false;
  options.unicode_normalization = false;
  options.lowercase = false;
  options.english_possessive = false;
  options.stemming = false;

  termflow::EnglishAnalyzer analyzer(options);
  const auto tokens = analyzer.analyze("The coﬀee Runner's");

  TF_EXPECT_EQ(token_texts(tokens),
               std::vector<std::string>({"The", "coﬀee", "Runner's"}));
  TF_EXPECT_EQ(analyzer.normalize("Running Café"), std::string("Running Café"));
}

TF_TEST(english_analyzer_normalizes_custom_stop_words_with_enabled_pre_stem_steps) {
  termflow::EnglishAnalyzerOptions options;
  options.use_default_stop_words = false;
  options.stemming = false;
  options.stop_words = {"THE", "Runner's"};

  termflow::EnglishAnalyzer analyzer(options);
  const auto tokens = analyzer.analyze("The runner's car");

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"car"}));
}

TF_TEST(english_analyzer_exposes_string_oriented_analysis_helpers) {
  termflow::EnglishAnalyzer analyzer;

  TF_EXPECT_EQ(analyzer.analyze_terms("The Running Cars"),
               std::vector<std::string>({"run", "car"}));
  TF_EXPECT_EQ(analyzer.analyze_term("Running"), std::optional<std::string>("run"));
  TF_EXPECT_EQ(analyzer.analyze_term(""), std::nullopt);
  TF_EXPECT_EQ(analyzer.analyze_to_string("The Running Cars"), std::string("run car"));
  TF_EXPECT_EQ(analyzer.analyze_to_string("The Running Cars", "|"), std::string("run|car"));
}

TF_TEST(english_analyzer_honors_stem_exclusion_and_ascii_folding) {
  termflow::EnglishAnalyzerOptions options;
  options.ascii_folding = true;
  options.use_default_stop_words = false;
  options.stem_exclusion_set.insert("running");

  termflow::EnglishAnalyzer analyzer(options);
  const auto tokens = analyzer.analyze("Running Café");

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"running", "cafe"}));
  TF_EXPECT_EQ(tokens[0].keyword, true);
  TF_EXPECT_EQ(tokens[1].keyword, false);
}

TF_TEST(english_analyzer_normalizes_stem_exclusion_set_with_enabled_pre_stem_steps) {
  termflow::EnglishAnalyzerOptions options;
  options.use_default_stop_words = false;
  options.stem_exclusion_set.insert("RUNNING");

  termflow::EnglishAnalyzer analyzer(options);
  const auto tokens = analyzer.analyze("Running runner");

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"running", "runner"}));
  TF_EXPECT_EQ(tokens[0].keyword, true);
  TF_EXPECT_EQ(tokens[1].keyword, false);
}

TF_TEST(english_analyzer_normalize_is_lighter_than_analyze) {
  termflow::EnglishAnalyzerOptions options;
  options.ascii_folding = true;

  termflow::EnglishAnalyzer analyzer(options);

  TF_EXPECT_EQ(analyzer.normalize("Running Café"), std::string("running cafe"));
  TF_EXPECT_EQ(token_texts(analyzer.analyze("Running Café")),
               std::vector<std::string>({"run", "cafe"}));
}

TF_TEST(english_analyzer_matches_explicit_public_pipeline_for_default_options) {
  const termflow::EnglishAnalyzerOptions options;
  termflow::EnglishAnalyzer analyzer(options);

  const std::array<std::string_view, 5> inputs = {
      "The Running Cars",
      "coﬀee Runner's",
      "CAFÉ résumé",
      "Contact [mailto:jeb@jeb.org] now",
      "msexch:ims:fcwd:op:mail from:terry.l.ric",
  };

  for (const auto input : inputs) {
    TF_EXPECT_EQ(analyzer.analyze(input), manual_english_pipeline(input, options));
  }
}

TF_TEST(english_analyzer_matches_explicit_public_pipeline_for_custom_options) {
  termflow::EnglishAnalyzerOptions options;
  options.use_default_stop_words = false;
  options.stop_words = {"THE", "Runner's"};
  options.stem_exclusion_set = {"RUNNING"};
  options.ascii_folding = true;

  termflow::EnglishAnalyzer analyzer(options);
  const std::string_view input = "The Running Runner's CAFÉ";

  TF_EXPECT_EQ(analyzer.analyze(input), manual_english_pipeline(input, options));
}

TF_TEST(english_analyzer_normalize_matches_documented_lightweight_stages) {
  termflow::EnglishAnalyzerOptions options;
  options.lowercase = false;
  options.ascii_folding = true;

  termflow::EnglishAnalyzer analyzer(options);
  const std::string_view input = "Runner's Café";

  TF_EXPECT_EQ(analyzer.normalize(input), manual_normalize(input, options));
}
