#include "test_framework.hpp"
#include "test_helpers.hpp"

#include <string>
#include <unordered_set>
#include <vector>

#include "termflow/analysis/ascii_folding_filter.hpp"
#include "termflow/analysis/english_possessive_filter.hpp"
#include "termflow/analysis/lower_case_filter.hpp"
#include "termflow/analysis/porter_stem_filter.hpp"
#include "termflow/analysis/stop_filter.hpp"
#include "termflow/analysis/token.hpp"
#include "termflow/analysis/unicode_normalize_filter.hpp"

using termflow::test::position_increments;
using termflow::test::positions;
using termflow::test::token_texts;

TF_TEST(unicode_normalize_filter_applies_nfkc) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = "coﬀee"},
  };

  termflow::UnicodeNormalizeFilter filter;
  filter.apply(tokens);

  TF_EXPECT_EQ(tokens[0].text, std::string("coffee"));
}

TF_TEST(lower_case_filter_lowercases_unicode_text) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = "MiXeD"},
      termflow::Token{.text = "CAFÉ"},
  };

  termflow::LowerCaseFilter filter;
  filter.apply(tokens);

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"mixed", "café"}));
}

TF_TEST(english_possessive_filter_removes_supported_suffixes) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = "Runner's"},
      termflow::Token{.text = "DOG’S"},
      termflow::Token{.text = "cars"},
  };

  termflow::EnglishPossessiveFilter filter;
  filter.apply(tokens);

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"Runner", "DOG", "cars"}));
}

TF_TEST(stop_filter_removes_tokens_and_preserves_position_gaps) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = "the", .position = 0, .position_increment = 1},
      termflow::Token{.text = "quick", .position = 1, .position_increment = 1},
      termflow::Token{.text = "and", .position = 2, .position_increment = 1},
      termflow::Token{.text = "fox", .position = 3, .position_increment = 1},
  };

  termflow::StopFilter filter(std::unordered_set<std::string>{"the", "and"});
  filter.apply(tokens);

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"quick", "fox"}));
  TF_EXPECT_EQ(position_increments(tokens), std::vector<std::size_t>({2, 2}));
  TF_EXPECT_EQ(positions(tokens), std::vector<std::size_t>({1, 3}));
}

TF_TEST(porter_stem_filter_stems_expected_english_terms) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = "caresses"},
      termflow::Token{.text = "ponies"},
      termflow::Token{.text = "running"},
      termflow::Token{.text = "need"},
      termflow::Token{.text = "feed"},
      termflow::Token{.text = "agreed"},
      termflow::Token{.text = "disabled"},
      termflow::Token{.text = "meeting"},
      termflow::Token{.text = "argument"},
      termflow::Token{.text = "document"},
      termflow::Token{.text = "testament"},
      termflow::Token{.text = "o'reilly"},
      termflow::Token{.text = "sky", .keyword = true},
  };

  termflow::PorterStemFilter filter;
  filter.apply(tokens);

  TF_EXPECT_EQ(token_texts(tokens),
               std::vector<std::string>({"caress",   "poni",     "run",      "need",
                                         "feed",     "agre",     "disabl",   "meet",
                                         "argument", "document", "testament","o'reilli",
                                         "sky"}));
}

TF_TEST(ascii_folding_filter_folds_accents) {
  std::vector<termflow::Token> tokens = {
      termflow::Token{.text = "café"},
      termflow::Token{.text = "résumé"},
  };

  termflow::AsciiFoldingFilter filter;
  filter.apply(tokens);

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"cafe", "resume"}));
}
