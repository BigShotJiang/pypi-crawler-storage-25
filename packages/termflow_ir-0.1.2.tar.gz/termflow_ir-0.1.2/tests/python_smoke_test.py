import json
import subprocess
import sys

from termflow import (
    EnglishAnalyzer,
    EnglishAnalyzerOptions,
    TermCharacterPolicy,
    TermExtractionOptions,
    TermExtractor,
    query,
)


def run_cli(*args: str) -> dict:
    completed = subprocess.run(
        [sys.executable, "-m", "termflow.cli", *args],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(completed.stdout)


def main() -> None:
    analyzer_options = EnglishAnalyzerOptions()
    analyzer_options.use_default_stop_words = False

    analyzer = EnglishAnalyzer(analyzer_options)

    tokens = analyzer.analyze("The Running Cars")
    assert [token.text for token in tokens] == ["the", "run", "car"]
    assert analyzer.analyze_terms("The Running Cars") == ["the", "run", "car"]
    assert analyzer.analyze_term("Running") == "run"
    assert analyzer.analyze_to_string("The Running Cars") == "the run car"
    assert analyzer.normalize("Running Café") == "running café"

    raw_options = EnglishAnalyzerOptions()
    raw_options.use_default_stop_words = False
    raw_options.unicode_normalization = False
    raw_options.lowercase = False
    raw_options.english_possessive = False
    raw_options.stemming = False
    raw_analyzer = EnglishAnalyzer(raw_options)
    assert [token.text for token in raw_analyzer.analyze("The coﬀee Runner's")] == [
        "The",
        "coﬀee",
        "Runner's",
    ]

    extraction_options = TermExtractionOptions()
    extraction_options.min_term_length = 2
    extraction_options.keep_numeric_terms = False
    extraction_options.character_policy = TermCharacterPolicy.ASCII_ALPHABETIC

    extractor = TermExtractor(analyzer, extraction_options)
    assert extractor.extract("Running beaches 2024 e-mail CAFÉ") == ["run", "beach", "mail"]
    assert extractor.extract_one("2024 Running") == "run"
    assert extractor.extract_joined("Running beaches 2024 e-mail", "|") == "run|beach|mail"

    parser = query.QueryParser()
    parsed = parser.parse('+rental -"expired listing" "car rentals"')
    assert [clause.text for clause in parsed.clauses] == [
        "rental",
        "expired listing",
        "car rentals",
    ]
    assert [clause.occur for clause in parsed.clauses] == [
        query.ClauseOccur.MUST,
        query.ClauseOccur.MUST_NOT,
        query.ClauseOccur.SHOULD,
    ]
    assert [clause.quoted for clause in parsed.clauses] == [False, True, True]

    rewrite_loader = query.RewriteLoader()
    query_options = query.QueryAnalysisOptions()
    query_options.rewrites = rewrite_loader.parse(
        """
        tv -> television;
        car rentals => automobile rentals;
        """
    )
    validator = query.RewriteValidator(analyzer)
    validation = validator.validate(query_options)
    assert not validation.has_errors()
    assert not validation.has_warnings()

    invalid_validation = validator.validate(
        [
            query.RewriteDefinition(
                match="!!!",
                rewrite="topic",
                kind=query.RewriteKind.CANONICAL,
            )
        ]
    )
    assert invalid_validation.has_errors()
    assert invalid_validation.issues[0].code == query.RewriteValidationCode.EMPTY_MATCH_TERMS

    query_analyzer = query.QueryAnalyzer(analyzer, query_options)
    analyzed_query = query_analyzer.analyze('tv +"car rentals"')

    assert [clause.terms for clause in analyzed_query.clauses] == [
        ["televis"],
        ["car", "rental"],
    ]
    assert analyzed_query.clauses[1].alternatives[0].terms == ["automobil", "rental"]
    assert analyzed_query.clauses[1].alternatives[0].kind == query.RewriteKind.EQUIVALENT

    analyzed_cli = run_cli("analyze", "The Running Cars", "--json")
    assert analyzed_cli["terms"] == ["run", "car"]
    assert analyzed_cli["normalized"] == "the running cars"
    assert [token["text"] for token in analyzed_cli["tokens"]] == ["run", "car"]

    extracted_cli = run_cli(
        "extract",
        "Running beaches 2024 e-mail CAFÉ",
        "--no-default-stop-words",
        "--min-term-length",
        "2",
        "--drop-numeric-terms",
        "--character-policy",
        "ascii-alphabetic",
        "--json",
    )
    assert extracted_cli["terms"] == ["run", "beach", "mail"]

    analyzed_query_cli = run_cli(
        "analyze-query",
        'tv +"car rentals"',
        "--rewrites",
        "tv -> television; car rentals => automobile rentals;",
        "--json",
    )
    assert [clause["terms"] for clause in analyzed_query_cli["clauses"]] == [
        ["televis"],
        ["car", "rental"],
    ]
    assert analyzed_query_cli["clauses"][1]["alternatives"][0]["terms"] == [
        "automobil",
        "rental",
    ]
    assert analyzed_query_cli["clauses"][1]["alternatives"][0]["kind"] == "equivalent"


if __name__ == "__main__":
    main()
