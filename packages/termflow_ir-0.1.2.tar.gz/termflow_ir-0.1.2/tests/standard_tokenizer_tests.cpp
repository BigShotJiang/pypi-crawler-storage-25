#include "test_framework.hpp"
#include "test_helpers.hpp"

#include <string>
#include <vector>

#include "termflow/analysis/standard_tokenizer.hpp"

using termflow::test::positions;
using termflow::test::token_texts;

TF_TEST(standard_tokenizer_splits_words_and_numbers) {
  termflow::StandardTokenizer tokenizer;
  const auto tokens = tokenizer.tokenize("Cats, dogs 123");

  TF_EXPECT_EQ(tokens.size(), std::size_t{3});
  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"Cats", "dogs", "123"}));
  TF_EXPECT_EQ(tokens[0].start_offset, std::size_t{0});
  TF_EXPECT_EQ(tokens[0].end_offset, std::size_t{4});
  TF_EXPECT_EQ(tokens[1].start_offset, std::size_t{6});
  TF_EXPECT_EQ(tokens[1].end_offset, std::size_t{10});
  TF_EXPECT_EQ(tokens[2].start_offset, std::size_t{11});
  TF_EXPECT_EQ(tokens[2].end_offset, std::size_t{14});
  TF_EXPECT_EQ(positions(tokens), std::vector<std::size_t>({0, 1, 2}));
}

TF_TEST(standard_tokenizer_merges_mailto_local_part) {
  termflow::StandardTokenizer tokenizer;
  const auto tokens = tokenizer.tokenize("Contact [mailto:jeb@jeb.org] now");

  TF_EXPECT_EQ(token_texts(tokens),
               std::vector<std::string>({"Contact", "mailto:jeb", "jeb.org", "now"}));
}

TF_TEST(standard_tokenizer_merges_general_alpha_colon_sequences) {
  termflow::StandardTokenizer tokenizer;
  const auto tokens = tokenizer.tokenize("msexch:ims:fcwd:op:mail from:terry.l.ric");

  TF_EXPECT_EQ(token_texts(tokens),
               std::vector<std::string>({"msexch:ims:fcwd:op:mail", "from:terry.l.ric"}));
}

TF_TEST(standard_tokenizer_does_not_merge_numeric_colon_sequences) {
  termflow::StandardTokenizer tokenizer;
  const auto tokens = tokenizer.tokenize("Meet at 6:23 pm");

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"Meet", "at", "6", "23", "pm"}));
}

TF_TEST(standard_tokenizer_chunks_long_tokens_at_default_max_length) {
  termflow::StandardTokenizer tokenizer;
  const std::string input(260, 'a');
  const auto tokens = tokenizer.tokenize(input);

  TF_EXPECT_EQ(tokens.size(), std::size_t{2});
  TF_EXPECT_EQ(tokens[0].text, std::string(255, 'a'));
  TF_EXPECT_EQ(tokens[0].start_offset, std::size_t{0});
  TF_EXPECT_EQ(tokens[0].end_offset, std::size_t{255});
  TF_EXPECT_EQ(tokens[0].position, std::size_t{0});
  TF_EXPECT_EQ(tokens[0].position_increment, std::size_t{1});
  TF_EXPECT_EQ(tokens[1].text, std::string(5, 'a'));
  TF_EXPECT_EQ(tokens[1].start_offset, std::size_t{255});
  TF_EXPECT_EQ(tokens[1].end_offset, std::size_t{260});
  TF_EXPECT_EQ(tokens[1].position, std::size_t{1});
  TF_EXPECT_EQ(tokens[1].position_increment, std::size_t{1});
}

TF_TEST(standard_tokenizer_honors_custom_max_token_length) {
  termflow::StandardTokenizer tokenizer;
  tokenizer.set_max_token_length(4);
  const auto tokens = tokenizer.tokenize("abcdefghij");

  TF_EXPECT_EQ(tokenizer.max_token_length(), std::size_t{4});
  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"abcd", "efgh", "ij"}));
}

TF_TEST(standard_tokenizer_drops_underscore_only_runs) {
  termflow::StandardTokenizer tokenizer;
  const auto tokens = tokenizer.tokenize("alpha _____ beta");

  TF_EXPECT_EQ(token_texts(tokens), std::vector<std::string>({"alpha", "beta"}));
}
