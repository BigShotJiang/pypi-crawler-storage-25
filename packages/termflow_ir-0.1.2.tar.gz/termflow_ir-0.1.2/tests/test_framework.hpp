#pragma once

#include <functional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

namespace termflow::test {

struct TestCase {
  std::string name;
  std::function<void()> run;
};

std::vector<TestCase>& registry();

struct Registrar {
  Registrar(std::string name, std::function<void()> run);
};

[[noreturn]] void fail(const std::string& message, const char* file, int line);

template <typename T>
concept StreamInsertable = requires(std::ostringstream& stream, const T& value) {
  stream << value;
};

template <typename T>
std::string render_value(const T& value) {
  if constexpr (StreamInsertable<T>) {
    std::ostringstream stream;
    stream << value;
    return stream.str();
  } else if constexpr (std::is_same_v<T, bool>) {
    return value ? "true" : "false";
  } else {
    return "<unprintable>";
  }
}

inline void expect_true(bool condition,
                        const char* expression,
                        const char* file,
                        int line) {
  if (!condition) {
    fail(std::string("expected true: ") + expression, file, line);
  }
}

template <typename Left, typename Right>
void expect_eq(const Left& actual,
               const Right& expected,
               const char* actual_expression,
               const char* expected_expression,
               const char* file,
               int line) {
  if (!(actual == expected)) {
    std::ostringstream message;
    message << "expected equality: " << actual_expression << " == " << expected_expression
            << ", actual=" << render_value(actual)
            << ", expected=" << render_value(expected);
    fail(message.str(), file, line);
  }
}

}  // namespace termflow::test

#define TF_TEST(name)                                                              \
  static void name();                                                              \
  static ::termflow::test::Registrar name##_registrar(#name, [] { name(); });      \
  static void name()

#define TF_EXPECT(condition) \
  ::termflow::test::expect_true((condition), #condition, __FILE__, __LINE__)

#define TF_EXPECT_EQ(actual, expected) \
  ::termflow::test::expect_eq((actual), (expected), #actual, #expected, __FILE__, __LINE__)
