#include "test_framework.hpp"

#include <optional>
#include <string>
#include <vector>

#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/analysis/term_extractor.hpp"

TF_TEST(term_extractor_filters_analyzed_terms_with_public_options) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);

  termflow::TermExtractionOptions options;
  options.min_term_length = 2;
  options.keep_numeric_terms = false;
  options.character_policy = termflow::TermCharacterPolicy::ascii_alphabetic;

  termflow::TermExtractor extractor(analyzer, options);

  TF_EXPECT_EQ(extractor.extract("Running beaches 2024 e-mail"),
               std::vector<std::string>({"run", "beach", "mail"}));
  TF_EXPECT_EQ(extractor.extract_one("2024 Running"), std::optional<std::string>("run"));
  TF_EXPECT_EQ(extractor.extract_joined("Running beaches 2024 e-mail", "|"),
               std::string("run|beach|mail"));
}

TF_TEST(term_extractor_supports_unicode_alphabetic_filtering) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);

  termflow::TermExtractionOptions options;
  options.character_policy = termflow::TermCharacterPolicy::alphabetic;

  termflow::TermExtractor extractor(analyzer, options);
  const auto tokens = analyzer.analyze("CAFÉ résumé 123");

  TF_EXPECT_EQ(extractor.extract(tokens), std::vector<std::string>({"café", "résumé"}));
  TF_EXPECT_EQ(extractor.extract_one(tokens), std::optional<std::string>("café"));
}
