#include "test_framework.hpp"

#include <chrono>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <vector>

#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/query/query_analyzer.hpp"
#include "termflow/query/query_parser.hpp"
#include "termflow/query/rewrite_loader.hpp"
#include "termflow/query/rewrite_validator.hpp"

namespace {

std::filesystem::path make_temp_directory() {
  const auto unique_suffix =
      std::to_string(std::chrono::steady_clock::now().time_since_epoch().count());
  const auto directory =
      std::filesystem::temp_directory_path() / ("termflow-query-tests-" + unique_suffix);
  std::filesystem::create_directories(directory);
  return directory;
}

void write_text_file(const std::filesystem::path& path, std::string_view text) {
  std::ofstream output(path);
  output << text;
}

const termflow::query::RewriteValidationIssue* find_issue(
    const termflow::query::RewriteValidationResult& result,
    termflow::query::RewriteValidationCode code) {
  for (const auto& issue : result.issues) {
    if (issue.code == code) {
      return &issue;
    }
  }
  return nullptr;
}

std::size_t count_issues(const termflow::query::RewriteValidationResult& result,
                         termflow::query::RewriteValidationCode code) {
  std::size_t count = 0;
  for (const auto& issue : result.issues) {
    if (issue.code == code) {
      ++count;
    }
  }
  return count;
}

}  // namespace

TF_TEST(query_parser_parses_occurs_and_quotes) {
  termflow::query::QueryParser parser;
  const auto query = parser.parse(R"(car +rental -"expired listing" "auto loans")");

  TF_EXPECT_EQ(query.text, std::string(R"(car +rental -"expired listing" "auto loans")"));
  TF_EXPECT_EQ(query.clauses.size(), std::size_t{4});
  const auto expected_clause_0 = termflow::query::ParsedClause{
      .occur = termflow::query::ClauseOccur::should,
      .text = "car",
      .quoted = false,
  };
  const auto expected_clause_1 = termflow::query::ParsedClause{
      .occur = termflow::query::ClauseOccur::must,
      .text = "rental",
      .quoted = false,
  };
  const auto expected_clause_2 = termflow::query::ParsedClause{
      .occur = termflow::query::ClauseOccur::must_not,
      .text = "expired listing",
      .quoted = true,
  };
  const auto expected_clause_3 = termflow::query::ParsedClause{
      .occur = termflow::query::ClauseOccur::should,
      .text = "auto loans",
      .quoted = true,
  };

  TF_EXPECT_EQ(query.clauses[0], expected_clause_0);
  TF_EXPECT_EQ(query.clauses[1], expected_clause_1);
  TF_EXPECT_EQ(query.clauses[2], expected_clause_2);
  TF_EXPECT_EQ(query.clauses[3], expected_clause_3);
}

TF_TEST(query_analyzer_uses_existing_analyzer_pipeline) {
  termflow::EnglishAnalyzer analyzer;
  termflow::query::QueryAnalyzer query_analyzer(analyzer);

  const auto query = query_analyzer.analyze(R"(Running +Cars -"Expired listing")");

  TF_EXPECT_EQ(query.clauses.size(), std::size_t{3});
  TF_EXPECT_EQ(query.clauses[0].terms, std::vector<std::string>({"run"}));
  TF_EXPECT_EQ(query.clauses[1].terms, std::vector<std::string>({"car"}));
  TF_EXPECT_EQ(query.clauses[2].terms, std::vector<std::string>({"expir", "list"}));
}

TF_TEST(query_analyzer_applies_canonical_rewrites) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);

  termflow::query::QueryAnalysisOptions options;
  options.rewrites.push_back(
      {.match = "tv", .rewrite = "television", .kind = termflow::query::RewriteKind::canonical});

  termflow::query::QueryAnalyzer query_analyzer(analyzer, options);
  const auto query = query_analyzer.analyze("tv rental");

  TF_EXPECT_EQ(query.clauses.size(), std::size_t{2});
  TF_EXPECT_EQ(query.clauses[0].terms, std::vector<std::string>({"televis"}));
  TF_EXPECT_EQ(query.clauses[0].alternatives.size(), std::size_t{0});
  TF_EXPECT_EQ(query.clauses[1].terms, std::vector<std::string>({"rental"}));
}

TF_TEST(query_analyzer_attaches_equivalent_and_expansion_alternatives) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);

  termflow::query::QueryAnalysisOptions options;
  options.rewrites.push_back({.match = "car rentals",
                              .rewrite = "automobile rentals",
                              .kind = termflow::query::RewriteKind::equivalent});
  options.rewrites.push_back({.match = "car rentals",
                              .rewrite = "vehicle rentals",
                              .kind = termflow::query::RewriteKind::expansion});

  termflow::query::QueryAnalyzer query_analyzer(analyzer, options);
  const auto query = query_analyzer.analyze(R"(+"car rentals")");

  TF_EXPECT_EQ(query.clauses.size(), std::size_t{1});
  TF_EXPECT_EQ(query.clauses[0].occur, termflow::query::ClauseOccur::must);
  TF_EXPECT_EQ(query.clauses[0].quoted, true);
  TF_EXPECT_EQ(query.clauses[0].terms, std::vector<std::string>({"car", "rental"}));
  TF_EXPECT_EQ(query.clauses[0].alternatives.size(), std::size_t{2});
  const auto expected_alternative_0 = termflow::query::AnalyzedAlternative{
      .terms = {"automobil", "rental"},
      .kind = termflow::query::RewriteKind::equivalent,
  };
  const auto expected_alternative_1 = termflow::query::AnalyzedAlternative{
      .terms = {"vehicl", "rental"},
      .kind = termflow::query::RewriteKind::expansion,
  };

  TF_EXPECT_EQ(query.clauses[0].alternatives[0], expected_alternative_0);
  TF_EXPECT_EQ(query.clauses[0].alternatives[1], expected_alternative_1);
}

TF_TEST(query_analyzer_deduplicates_alternatives_by_default) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);

  termflow::query::QueryAnalysisOptions options;
  options.rewrites.push_back({.match = "car rentals",
                              .rewrite = "automobile rentals",
                              .kind = termflow::query::RewriteKind::equivalent});
  options.rewrites.push_back({.match = "car rentals",
                              .rewrite = "automobile rentals",
                              .kind = termflow::query::RewriteKind::expansion});

  termflow::query::QueryAnalyzer query_analyzer(analyzer, options);
  const auto query = query_analyzer.analyze(R"("car rentals")");

  TF_EXPECT_EQ(query.clauses[0].alternatives.size(), std::size_t{1});
}

TF_TEST(rewrite_loader_parses_rewrite_statements_from_text) {
  termflow::query::RewriteLoader loader;
  const auto rewrites = loader.parse(R"(
      # Canonical rewrites
      lotr -> lord of the rings;
      colour -> color;

      # Query-time alternatives
      car rentals => automobile rentals;
      car rentals ~> vehicle rentals;
  )");

  TF_EXPECT_EQ(rewrites.size(), std::size_t{4});
  const auto expected_0 = termflow::query::RewriteDefinition{
      .match = "lotr",
      .rewrite = "lord of the rings",
      .kind = termflow::query::RewriteKind::canonical,
  };
  const auto expected_1 = termflow::query::RewriteDefinition{
      .match = "colour",
      .rewrite = "color",
      .kind = termflow::query::RewriteKind::canonical,
  };
  const auto expected_2 = termflow::query::RewriteDefinition{
      .match = "car rentals",
      .rewrite = "automobile rentals",
      .kind = termflow::query::RewriteKind::equivalent,
  };
  const auto expected_3 = termflow::query::RewriteDefinition{
      .match = "car rentals",
      .rewrite = "vehicle rentals",
      .kind = termflow::query::RewriteKind::expansion,
  };

  TF_EXPECT_EQ(rewrites[0], expected_0);
  TF_EXPECT_EQ(rewrites[1], expected_1);
  TF_EXPECT_EQ(rewrites[2], expected_2);
  TF_EXPECT_EQ(rewrites[3], expected_3);
}

TF_TEST(rewrite_loader_loads_included_files) {
  const auto directory = make_temp_directory();
  try {
    const auto included_path = directory / "brands.tfq";
    const auto main_path = directory / "main.tfq";

    write_text_file(included_path, R"(
        audi -> skoda;
        car rentals ~> vehicle rentals;
    )");
    write_text_file(main_path, R"(
        lotr -> lord of the rings;
        include "brands.tfq";
        colour -> color;
    )");

    termflow::query::RewriteLoader loader;
    const auto rewrites = loader.load_file(main_path);

    TF_EXPECT_EQ(rewrites.size(), std::size_t{4});
    TF_EXPECT_EQ(rewrites[0].match, std::string("lotr"));
    TF_EXPECT_EQ(rewrites[1].match, std::string("audi"));
    TF_EXPECT_EQ(rewrites[2].match, std::string("car rentals"));
    TF_EXPECT_EQ(rewrites[3].match, std::string("colour"));
  } catch (...) {
    std::filesystem::remove_all(directory);
    throw;
  }

  std::filesystem::remove_all(directory);
}

TF_TEST(rewrite_loader_rejects_include_in_inline_text) {
  termflow::query::RewriteLoader loader;

  bool threw = false;
  try {
    static_cast<void>(loader.parse(R"(include "common.tfq";)"));
  } catch (const std::invalid_argument&) {
    threw = true;
  }

  TF_EXPECT(threw);
}

TF_TEST(rewrite_validator_reports_empty_analysis_rules) {
  termflow::EnglishAnalyzer analyzer;
  termflow::query::RewriteValidator validator(analyzer);

  const auto result = validator.validate(std::vector<termflow::query::RewriteDefinition>{
      {.match = "the", .rewrite = "topic", .kind = termflow::query::RewriteKind::canonical},
      {.match = "tv", .rewrite = "the", .kind = termflow::query::RewriteKind::canonical},
  });

  TF_EXPECT(result.has_errors());
  const auto* empty_match_issue =
      find_issue(result, termflow::query::RewriteValidationCode::empty_match_terms);
  const auto* empty_rewrite_issue =
      find_issue(result, termflow::query::RewriteValidationCode::empty_rewrite_terms);
  TF_EXPECT(empty_match_issue != nullptr);
  TF_EXPECT(empty_rewrite_issue != nullptr);
}

TF_TEST(rewrite_validator_reports_conflicting_canonical_targets) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);
  termflow::query::RewriteValidator validator(analyzer);

  const auto result = validator.validate(std::vector<termflow::query::RewriteDefinition>{
      {.match = "tv", .rewrite = "television", .kind = termflow::query::RewriteKind::canonical},
      {.match = "tv", .rewrite = "television set", .kind = termflow::query::RewriteKind::canonical},
  });

  TF_EXPECT(result.has_errors());
  const auto* issue =
      find_issue(result, termflow::query::RewriteValidationCode::conflicting_canonical_target);
  TF_EXPECT(issue != nullptr);
  TF_EXPECT_EQ(issue->rule_indices, std::vector<std::size_t>({0, 1}));
}

TF_TEST(rewrite_validator_reports_canonical_cycles) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);
  termflow::query::RewriteValidator validator(analyzer);

  const auto result = validator.validate(std::vector<termflow::query::RewriteDefinition>{
      {.match = "tv", .rewrite = "television", .kind = termflow::query::RewriteKind::canonical},
      {.match = "television", .rewrite = "tv", .kind = termflow::query::RewriteKind::canonical},
  });

  TF_EXPECT(result.has_errors());
  const auto* issue = find_issue(result, termflow::query::RewriteValidationCode::canonical_cycle);
  TF_EXPECT(issue != nullptr);
  TF_EXPECT_EQ(issue->rule_indices, std::vector<std::size_t>({0, 1}));
}

TF_TEST(rewrite_validator_reports_shadowed_rules) {
  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);
  termflow::query::RewriteValidator validator(analyzer);

  termflow::query::QueryAnalysisOptions options;
  options.rewrites = {
      {.match = "tv", .rewrite = "television", .kind = termflow::query::RewriteKind::canonical},
      {.match = "tv", .rewrite = "television", .kind = termflow::query::RewriteKind::canonical},
      {.match = "car rentals", .rewrite = "automobile rentals", .kind = termflow::query::RewriteKind::equivalent},
      {.match = "car rentals", .rewrite = "automobile rentals", .kind = termflow::query::RewriteKind::equivalent},
      {.match = "car rentals", .rewrite = "automobile rentals", .kind = termflow::query::RewriteKind::expansion},
      {.match = "vehicle", .rewrite = "vehicle", .kind = termflow::query::RewriteKind::equivalent},
  };

  const auto result = validator.validate(options);

  TF_EXPECT(result.has_warnings());
  TF_EXPECT_EQ(count_issues(result, termflow::query::RewriteValidationCode::shadowed_canonical_rule),
               std::size_t{1});
  TF_EXPECT_EQ(count_issues(result, termflow::query::RewriteValidationCode::duplicate_alternative_rule),
               std::size_t{1});
  TF_EXPECT_EQ(count_issues(result, termflow::query::RewriteValidationCode::shadowed_alternative_rule),
               std::size_t{2});
}
