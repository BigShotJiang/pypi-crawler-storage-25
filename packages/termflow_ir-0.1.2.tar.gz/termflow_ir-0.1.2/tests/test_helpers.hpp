#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "termflow/analysis/token.hpp"

namespace termflow::test {

inline std::vector<std::string> token_texts(const std::vector<Token>& tokens) {
  std::vector<std::string> texts;
  texts.reserve(tokens.size());
  for (const auto& token : tokens) {
    texts.push_back(token.text);
  }
  return texts;
}

inline std::vector<std::size_t> positions(const std::vector<Token>& tokens) {
  std::vector<std::size_t> values;
  values.reserve(tokens.size());
  for (const auto& token : tokens) {
    values.push_back(token.position);
  }
  return values;
}

inline std::vector<std::size_t> position_increments(const std::vector<Token>& tokens) {
  std::vector<std::size_t> values;
  values.reserve(tokens.size());
  for (const auto& token : tokens) {
    values.push_back(token.position_increment);
  }
  return values;
}

}  // namespace termflow::test
