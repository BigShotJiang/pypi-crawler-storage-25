#include "test_framework.hpp"

#include <sstream>

namespace termflow::test {

std::vector<TestCase>& registry() {
  static std::vector<TestCase> tests;
  return tests;
}

Registrar::Registrar(std::string name, std::function<void()> run) {
  registry().push_back(TestCase{std::move(name), std::move(run)});
}

[[noreturn]] void fail(const std::string& message, const char* file, int line) {
  std::ostringstream stream;
  stream << file << ":" << line << ": " << message;
  throw std::runtime_error(stream.str());
}

}  // namespace termflow::test
