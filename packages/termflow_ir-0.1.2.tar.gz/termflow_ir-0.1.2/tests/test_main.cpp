#include "test_framework.hpp"

#include <exception>
#include <iostream>

int main() {
  int passed = 0;
  int failed = 0;

  for (const auto& test : termflow::test::registry()) {
    try {
      test.run();
      ++passed;
      std::cout << "[PASS] " << test.name << '\n';
    } catch (const std::exception& error) {
      ++failed;
      std::cerr << "[FAIL] " << test.name << ": " << error.what() << '\n';
    }
  }

  std::cout << "passed=" << passed << " failed=" << failed << '\n';
  return failed == 0 ? 0 : 1;
}
