#pragma once

#include <string>
#include <unordered_set>
#include <vector>

#include "termflow/analysis/analyzer.hpp"
#include "termflow/analysis/ascii_folding_filter.hpp"
#include "termflow/analysis/porter_stem_filter.hpp"
#include "termflow/analysis/standard_tokenizer.hpp"
#include "termflow/analysis/stop_filter.hpp"

namespace termflow {

/**
 * Configuration for `EnglishAnalyzer`.
 *
 * `analyze()` applies stages in this order:
 * 1. `StandardTokenizer`
 * 2. optional Unicode normalization
 * 3. optional English possessive stripping
 * 4. optional lowercasing
 * 5. optional stop-word filtering
 * 6. keyword marking using `stem_exclusion_set`
 * 7. optional Porter stemming
 * 8. optional ASCII folding
 *
 * `normalize()` is intentionally lighter-weight. It honors only
 * `unicode_normalization`, `lowercase`, and `ascii_folding`. It does not
 * tokenize, strip possessives, remove stop words, mark keywords, or stem.
 *
 * Stage toggles are explicit. For example, if `lowercase` is disabled but
 * `stemming` is enabled, stemming runs on the token text produced by the earlier
 * enabled stages without forcing lowercase.
 */
struct EnglishAnalyzerOptions {
  /** Apply NFKC normalization before token-level English processing. */
  bool unicode_normalization{true};
  /** Lowercase tokens before stop-word matching and stemming. */
  bool lowercase{true};
  /** Strip a terminal English possessive suffix like `'s` or `’s`. */
  bool english_possessive{true};
  /** Enable stop-word filtering using either default or custom stop words. */
  bool stop_filter{true};
  /** Enable Porter stemming after keyword marking. */
  bool stemming{true};
  /** Apply ASCII folding after stemming. */
  bool ascii_folding{false};
  /** Use the built-in English stop-word set when `stop_filter` is enabled. */
  bool use_default_stop_words{true};
  /** Custom stop-word set used when `use_default_stop_words` is false. */
  std::unordered_set<std::string> stop_words;
  /** Terms that should be marked as keywords before stemming. */
  std::unordered_set<std::string> stem_exclusion_set;
};

/**
 * Opinionated English analyzer built from the public tokenizer and filter model.
 *
 * Instances are safe for concurrent const use after construction. Do not mutate
 * configuration on the same object concurrently with analysis.
 */
class EnglishAnalyzer final : public Analyzer {
 public:
  EnglishAnalyzer();
  explicit EnglishAnalyzer(EnglishAnalyzerOptions options);

  [[nodiscard]] static const std::unordered_set<std::string>& default_stop_words();

 protected:
  [[nodiscard]] std::vector<Token> create_tokens(std::string_view text) const override;
  void apply_token_filters(std::vector<Token>& tokens) const override;
  [[nodiscard]] std::string normalize_text(std::string_view text) const override;

 private:
  void mark_keywords(std::vector<Token>& tokens) const;

  bool unicode_normalization_{true};
  bool lowercase_{true};
  bool english_possessive_{true};
  bool stemming_{true};
  bool ascii_folding_{false};
  StandardTokenizer tokenizer_;
  StopFilter stop_filter_;
  PorterStemFilter porter_stem_filter_;
  AsciiFoldingFilter ascii_folding_filter_;
  std::unordered_set<std::string> stem_exclusion_set_;
};

}  // namespace termflow
