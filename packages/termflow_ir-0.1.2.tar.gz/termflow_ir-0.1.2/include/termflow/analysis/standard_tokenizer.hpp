#pragma once

#include <cstddef>

#include "termflow/analysis/tokenizer.hpp"

namespace termflow {

/**
 * ICU-based word tokenizer used by the built-in English analyzer.
 *
 * Token boundaries are derived from ICU root-locale word breaks and returned
 * offsets are measured in UTF-16 code units. Tokens longer than
 * `max_token_length()` are split into consecutive chunks, each with its own
 * offsets and position.
 */
class StandardTokenizer final : public Tokenizer {
 public:
  static constexpr std::size_t default_max_token_length = 255;

  StandardTokenizer() = default;
  explicit StandardTokenizer(std::size_t max_token_length);

  /** Throws `std::invalid_argument` if `max_token_length` is zero. */
  void set_max_token_length(std::size_t max_token_length);
  [[nodiscard]] std::size_t max_token_length() const noexcept { return max_token_length_; }

  [[nodiscard]] std::vector<Token> tokenize(std::string_view input) const override;

 private:
  std::size_t max_token_length_{default_max_token_length};
};

}  // namespace termflow
