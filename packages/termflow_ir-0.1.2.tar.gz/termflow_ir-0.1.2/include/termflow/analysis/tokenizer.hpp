#pragma once

#include <string_view>
#include <vector>

#include "termflow/analysis/token.hpp"

namespace termflow {

/**
 * Tokenizer that materializes all tokens for an input string.
 *
 * Offsets in returned tokens are measured relative to the input text passed to
 * `tokenize()`. This interface is batch-oriented; it does not expose a streaming
 * token API in v1.
 */
class Tokenizer {
 public:
  virtual ~Tokenizer() = default;

  [[nodiscard]] virtual std::vector<Token> tokenize(std::string_view input) const = 0;
};

}  // namespace termflow
