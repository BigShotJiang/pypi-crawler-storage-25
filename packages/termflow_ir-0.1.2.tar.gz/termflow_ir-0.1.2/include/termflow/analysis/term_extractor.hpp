#pragma once

#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

#include "termflow/analysis/analyzer.hpp"
#include "termflow/analysis/token.hpp"

namespace termflow {

enum class TermCharacterPolicy {
  any,
  alphabetic,
  ascii_alphabetic,
};

struct TermExtractionOptions {
  std::size_t min_term_length{1};
  bool keep_numeric_terms{true};
  TermCharacterPolicy character_policy{TermCharacterPolicy::any};
};

/**
 * Convenience helper for consumers that want finalized term strings rather than
 * full `Token` objects.
 *
 * `TermExtractor` never changes analyzer behavior. It applies post-analysis
 * filtering to either analyzer output or an existing token vector.
 */
class TermExtractor {
 public:
  explicit TermExtractor(const Analyzer& analyzer, TermExtractionOptions options = {});

  [[nodiscard]] std::vector<std::string> extract(std::string_view text) const;
  [[nodiscard]] std::optional<std::string> extract_one(std::string_view text) const;
  [[nodiscard]] std::string extract_joined(std::string_view text,
                                           std::string_view separator = " ") const;

  [[nodiscard]] std::vector<std::string> extract(const std::vector<Token>& tokens) const;
  [[nodiscard]] std::optional<std::string> extract_one(const std::vector<Token>& tokens) const;

  [[nodiscard]] const Analyzer& analyzer() const noexcept { return *analyzer_; }
  [[nodiscard]] const TermExtractionOptions& options() const noexcept { return options_; }

 private:
  [[nodiscard]] bool keep_term(std::string_view term) const;

  const Analyzer* analyzer_;
  TermExtractionOptions options_;
};

}  // namespace termflow
