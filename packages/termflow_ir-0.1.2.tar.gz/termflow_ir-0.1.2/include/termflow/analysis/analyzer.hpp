#pragma once

#include <optional>
#include <string>
#include <string_view>
#include <vector>

#include "termflow/analysis/token.hpp"

namespace termflow {

/**
 * Batch-oriented analyzer interface.
 *
 * `analyze()` runs the full analysis pipeline and materializes every token in a
 * `std::vector<Token>`. `normalize()` is intentionally lighter-weight: it does
 * not tokenize and may apply only a subset of the full analysis stages.
 *
 * Implementations in this repository may throw `std::runtime_error` when an
 * underlying dependency such as ICU cannot be initialized or fails while
 * processing text.
 *
 * Analyzer implementations in this repository are intended to be safe for
 * concurrent const use after construction. A common pattern is to share one
 * configured analyzer across worker threads and call `analyze()` or
 * `normalize()` concurrently on distinct input texts.
 */
class Analyzer {
 public:
  virtual ~Analyzer() = default;

  /** Runs the full analysis pipeline and returns all resulting tokens. */
  [[nodiscard]] std::vector<Token> analyze(std::string_view text) const;
  /** Convenience wrapper that returns only finalized token texts. */
  [[nodiscard]] std::vector<std::string> analyze_terms(std::string_view text) const;
  /** Returns the first analyzed term, or `std::nullopt` if analysis yields none. */
  [[nodiscard]] std::optional<std::string> analyze_term(std::string_view text) const;
  /** Joins analyzed terms with `separator`. */
  [[nodiscard]] std::string analyze_to_string(std::string_view text,
                                              std::string_view separator = " ") const;
  /** Runs the analyzer's lighter-weight normalization path without tokenization. */
  [[nodiscard]] std::string normalize(std::string_view text) const;

 protected:
  [[nodiscard]] virtual std::string apply_char_filters(std::string_view text) const;
  [[nodiscard]] virtual std::vector<Token> create_tokens(std::string_view text) const = 0;
  virtual void apply_token_filters(std::vector<Token>& tokens) const = 0;
  [[nodiscard]] virtual std::string normalize_text(std::string_view text) const = 0;

  static void recompute_positions(std::vector<Token>& tokens);
};

}  // namespace termflow
