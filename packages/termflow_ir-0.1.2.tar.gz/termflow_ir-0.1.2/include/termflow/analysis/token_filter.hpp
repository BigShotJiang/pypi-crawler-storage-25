#pragma once

#include <vector>

#include "termflow/analysis/token.hpp"

namespace termflow {

/**
 * In-place token transformation stage.
 *
 * Filters may modify token text, positions, keyword flags, or remove tokens
 * entirely by rewriting the input vector.
 */
class TokenFilter {
 public:
  virtual ~TokenFilter() = default;

  virtual void apply(std::vector<Token>& tokens) const = 0;
};

}  // namespace termflow
