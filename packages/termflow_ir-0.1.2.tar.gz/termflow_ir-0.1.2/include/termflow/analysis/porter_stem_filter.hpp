#pragma once

#include "termflow/analysis/token_filter.hpp"

namespace termflow {

class PorterStemFilter final : public TokenFilter {
 public:
  void apply(std::vector<Token>& tokens) const override;
};

}  // namespace termflow
