#pragma once

#include <cstddef>
#include <string>

namespace termflow {

/**
 * Analysis token produced by a tokenizer or analyzer.
 *
 * Offsets are measured in UTF-16 code units relative to the text seen by the
 * tokenizer after any char filtering. `position` is the absolute token position
 * after all preceding filters have run. `position_increment` is the gap from the
 * previous token position and is primarily relevant when filters remove tokens.
 */
struct Token {
  std::string text;
  std::size_t start_offset{0};
  std::size_t end_offset{0};
  std::size_t position{0};
  std::size_t position_increment{1};
  bool keyword{false};

  friend bool operator==(const Token&, const Token&) noexcept = default;
};

}  // namespace termflow
