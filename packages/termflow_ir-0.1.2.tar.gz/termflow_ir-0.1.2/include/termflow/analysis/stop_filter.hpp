#pragma once

#include <string>
#include <unordered_set>

#include "termflow/analysis/token_filter.hpp"

namespace termflow {

class StopFilter final : public TokenFilter {
 public:
  StopFilter() = default;
  explicit StopFilter(std::unordered_set<std::string> stop_words);

  [[nodiscard]] const std::unordered_set<std::string>& stop_words() const noexcept;
  void apply(std::vector<Token>& tokens) const override;

 private:
  std::unordered_set<std::string> stop_words_;
};

}  // namespace termflow
