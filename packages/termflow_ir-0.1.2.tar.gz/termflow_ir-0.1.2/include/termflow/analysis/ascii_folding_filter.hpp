#pragma once

#include "termflow/analysis/token_filter.hpp"

namespace termflow {

class AsciiFoldingFilter final : public TokenFilter {
 public:
  void apply(std::vector<Token>& tokens) const override;
};

}  // namespace termflow
