#pragma once

#include <string>
#include <string_view>

namespace termflow {

/**
 * Character-level text transformation applied before tokenization.
 *
 * v1 exposes only the transformed string. Offset correction is therefore the
 * responsibility of the concrete analyzer or tokenizer that uses a CharFilter.
 */
class CharFilter {
 public:
  virtual ~CharFilter() = default;

  [[nodiscard]] virtual std::string apply(std::string_view input) const = 0;
};

}  // namespace termflow
