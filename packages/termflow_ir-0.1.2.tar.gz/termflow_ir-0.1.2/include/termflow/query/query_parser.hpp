#pragma once

#include <string_view>

#include "termflow/query/query_types.hpp"

namespace termflow::query {

/**
 * Lightweight query parser for optional `+`, `-`, and quoted groups.
 *
 * Supported syntax:
 * - `term`
 * - `+required`
 * - `-excluded`
 * - `"quoted group"`
 * - `+"quoted group"`
 * - `-"quoted group"`
 *
 * The parser is intentionally small. It does not implement escaping, boolean
 * operator precedence, field syntax, boosts, or wildcard parsing. Quoted groups
 * preserve user grouping in the parsed query model but do not imply executable
 * phrase semantics on their own.
 */
class QueryParser {
 public:
  [[nodiscard]] ParsedQuery parse(std::string_view text) const;
};

}  // namespace termflow::query
