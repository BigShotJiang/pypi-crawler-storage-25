#pragma once

#include <string_view>
#include <vector>

#include "termflow/analysis/analyzer.hpp"
#include "termflow/query/query_parser.hpp"
#include "termflow/query/query_types.hpp"

namespace termflow::query {

/**
 * Parses query text, analyzes each clause with an existing analyzer, and
 * optionally attaches query-time rewrite alternatives.
 *
 * Canonical rewrites replace the primary analyzed term sequence for a clause.
 * Equivalent and expansion rewrites are attached as alternatives on that
 * clause. Rewrite matching is exact at the analyzed clause-term level.
 *
 * This class intentionally stops at text processing. It does not score,
 * retrieve, or execute queries, and it does not build token graphs or
 * executable phrase queries from quoted clauses.
 */
class QueryAnalyzer {
 public:
  explicit QueryAnalyzer(const termflow::Analyzer& analyzer,
                         QueryAnalysisOptions options = {});

  [[nodiscard]] ParsedQuery parse(std::string_view text) const;
  [[nodiscard]] AnalyzedQuery analyze(std::string_view text) const;
  [[nodiscard]] AnalyzedQuery analyze(const ParsedQuery& query) const;

  [[nodiscard]] const termflow::Analyzer& analyzer() const noexcept { return *analyzer_; }
  [[nodiscard]] const QueryAnalysisOptions& options() const noexcept { return options_; }

 private:
  struct PreparedRewrite {
    std::vector<std::string> match_terms;
    std::vector<std::string> rewrite_terms;
    RewriteKind kind{RewriteKind::equivalent};
  };

  [[nodiscard]] std::vector<std::string> apply_canonical_rewrites(
      const std::vector<std::string>& terms) const;
  void append_rewrite_alternatives(AnalyzedClause& clause) const;

  const termflow::Analyzer* analyzer_;
  QueryAnalysisOptions options_;
  QueryParser parser_;
  std::vector<PreparedRewrite> rewrites_;
};

}  // namespace termflow::query
