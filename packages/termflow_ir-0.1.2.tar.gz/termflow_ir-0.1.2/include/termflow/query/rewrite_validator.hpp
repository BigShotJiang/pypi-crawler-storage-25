#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "termflow/analysis/analyzer.hpp"
#include "termflow/query/query_types.hpp"

namespace termflow::query {

enum class RewriteValidationSeverity {
  warning,
  error,
};

enum class RewriteValidationCode {
  empty_match_terms,
  empty_rewrite_terms,
  no_op_canonical_rule,
  conflicting_canonical_target,
  canonical_cycle,
  shadowed_canonical_rule,
  duplicate_alternative_rule,
  shadowed_alternative_rule,
};

struct ValidatedRewrite {
  std::size_t rule_index{};
  RewriteDefinition definition;
  std::vector<std::string> analyzed_match_terms;
  std::vector<std::string> analyzed_rewrite_terms;

  friend bool operator==(const ValidatedRewrite&, const ValidatedRewrite&) noexcept = default;
};

struct RewriteValidationIssue {
  RewriteValidationSeverity severity{RewriteValidationSeverity::warning};
  RewriteValidationCode code{RewriteValidationCode::duplicate_alternative_rule};
  std::vector<std::size_t> rule_indices;
  std::string message;

  friend bool operator==(const RewriteValidationIssue&,
                         const RewriteValidationIssue&) noexcept = default;
};

struct RewriteValidationResult {
  std::vector<ValidatedRewrite> rewrites;
  std::vector<RewriteValidationIssue> issues;

  [[nodiscard]] bool has_errors() const noexcept;
  [[nodiscard]] bool has_warnings() const noexcept;
};

/**
 * Validates query-time rewrite rules after analyzer normalization.
 *
 * The validator reports rules that analyze to no terms, canonical conflicts and
 * cycles, and alternatives that are duplicated or shadowed by the configured
 * deduplication policy. It is intentionally a reporting tool: it does not
 * modify or reorder the supplied rewrites.
 */
class RewriteValidator {
 public:
  explicit RewriteValidator(const termflow::Analyzer& analyzer);

  [[nodiscard]] RewriteValidationResult validate(
      const QueryAnalysisOptions& options) const;
  [[nodiscard]] RewriteValidationResult validate(
      const std::vector<RewriteDefinition>& rewrites) const;

  [[nodiscard]] const termflow::Analyzer& analyzer() const noexcept { return *analyzer_; }

 private:
  const termflow::Analyzer* analyzer_;
};

}  // namespace termflow::query
