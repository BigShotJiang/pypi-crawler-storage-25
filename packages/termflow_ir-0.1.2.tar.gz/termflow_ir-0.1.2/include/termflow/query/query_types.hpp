#pragma once

#include <string>
#include <vector>

namespace termflow::query {

enum class ClauseOccur {
  should,
  must,
  must_not,
};

enum class RewriteKind {
  canonical,
  equivalent,
  expansion,
};

/**
 * Parsed query clause produced by the lightweight query parser.
 *
 * `text` contains the raw clause text without any leading `+` / `-` marker and
 * without surrounding quotes. `quoted` records whether the clause was parsed
 * from a quoted group.
 */
struct ParsedClause {
  ClauseOccur occur{ClauseOccur::should};
  std::string text;
  bool quoted{false};

  friend bool operator==(const ParsedClause&, const ParsedClause&) noexcept = default;
};

struct ParsedQuery {
  std::string text;
  std::vector<ParsedClause> clauses;

  friend bool operator==(const ParsedQuery&, const ParsedQuery&) noexcept = default;
};

/**
 * Raw query-time rewrite rule.
 *
 * Both `match` and `rewrite` are analyzed through the configured analyzer when a
 * `QueryAnalyzer` is constructed. This keeps rewrite definitions in user-facing
 * text rather than forcing callers to precompute analyzed term sequences.
 */
struct RewriteDefinition {
  std::string match;
  std::string rewrite;
  RewriteKind kind{RewriteKind::equivalent};

  friend bool operator==(const RewriteDefinition&, const RewriteDefinition&) noexcept = default;
};

struct QueryAnalysisOptions {
  std::vector<RewriteDefinition> rewrites;
  bool deduplicate_alternatives{true};

  friend bool operator==(const QueryAnalysisOptions&,
                         const QueryAnalysisOptions&) noexcept = default;
};

/**
 * An analyzed alternative term sequence attached to a clause.
 *
 * `canonical` rewrites are applied to the primary `terms` field of a clause and
 * are therefore not represented as alternatives.
 */
struct AnalyzedAlternative {
  std::vector<std::string> terms;
  RewriteKind kind{RewriteKind::equivalent};

  friend bool operator==(const AnalyzedAlternative&,
                         const AnalyzedAlternative&) noexcept = default;
};

struct AnalyzedClause {
  ClauseOccur occur{ClauseOccur::should};
  std::string text;
  bool quoted{false};
  std::vector<std::string> terms;
  std::vector<AnalyzedAlternative> alternatives;

  friend bool operator==(const AnalyzedClause&, const AnalyzedClause&) noexcept = default;
};

struct AnalyzedQuery {
  std::string text;
  std::vector<AnalyzedClause> clauses;

  friend bool operator==(const AnalyzedQuery&, const AnalyzedQuery&) noexcept = default;
};

}  // namespace termflow::query
