#pragma once

#include <filesystem>
#include <string_view>
#include <vector>

#include "termflow/query/query_types.hpp"

namespace termflow::query {

/**
 * Loads query-time rewrite rules from text or files.
 *
 * Supported statement forms:
 * - `lhs -> rhs;` for canonical rewrites
 * - `lhs => rhs;` for equivalent alternatives
 * - `lhs ~> rhs;` for expansion alternatives
 * - `include "other-rules.tfq";` for file inclusion
 *
 * Lines may contain `#` comments. Statements are terminated by `;`.
 *
 * This loader is intentionally limited to query-time text rewrites. It does
 * not implement field routing, conditional macros, boosts, or stop-word
 * directives.
 */
class RewriteLoader {
 public:
  [[nodiscard]] std::vector<RewriteDefinition> parse(std::string_view text) const;
  [[nodiscard]] std::vector<RewriteDefinition> load_file(
      const std::filesystem::path& path) const;
};

}  // namespace termflow::query
