#include <iostream>
#include <sstream>
#include <string>

#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/analysis/term_extractor.hpp"

namespace {

std::string read_all_stdin() {
  std::ostringstream buffer;
  buffer << std::cin.rdbuf();
  return buffer.str();
}

}  // namespace

int main(int argc, char** argv) {
  std::string input;
  if (argc > 1) {
    input = argv[1];
  } else {
    input = read_all_stdin();
  }

  termflow::EnglishAnalyzerOptions analyzer_options;
  analyzer_options.use_default_stop_words = false;
  termflow::EnglishAnalyzer analyzer(analyzer_options);

  termflow::TermExtractionOptions extraction_options;
  extraction_options.min_term_length = 2;
  extraction_options.keep_numeric_terms = false;
  extraction_options.character_policy = termflow::TermCharacterPolicy::ascii_alphabetic;

  termflow::TermExtractor extractor(analyzer, extraction_options);
  const auto terms = extractor.extract(input);

  std::cout << "terms:\n";
  for (const auto& term : terms) {
    std::cout << "  " << term << '\n';
  }

  return 0;
}
