#include <iostream>

#include "termflow/analysis/english_analyzer.hpp"

int main() {
  termflow::EnglishAnalyzer analyzer;
  const auto terms = analyzer.analyze_terms("The Running Cars");

  std::cout << "terms:\n";
  for (const auto& term : terms) {
    std::cout << "  " << term << '\n';
  }

  return 0;
}
