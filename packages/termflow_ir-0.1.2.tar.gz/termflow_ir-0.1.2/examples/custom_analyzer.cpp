#include <algorithm>
#include <cctype>
#include <iostream>
#include <string>
#include <string_view>
#include <vector>

#include "termflow/analysis/analyzer.hpp"
#include "termflow/analysis/lower_case_filter.hpp"
#include "termflow/analysis/standard_tokenizer.hpp"
#include "termflow/analysis/stop_filter.hpp"

namespace {

class SimpleTitleAnalyzer final : public termflow::Analyzer {
 public:
  SimpleTitleAnalyzer() : stop_filter_({"a", "an", "the"}) {}

 protected:
  std::vector<termflow::Token> create_tokens(std::string_view text) const override {
    return tokenizer_.tokenize(text);
  }

  void apply_token_filters(std::vector<termflow::Token>& tokens) const override {
    lower_case_filter_.apply(tokens);
    stop_filter_.apply(tokens);
  }

  std::string normalize_text(std::string_view text) const override {
    // Custom analyzers define their own lighter-weight normalization path.
    std::string normalized(text);
    std::transform(normalized.begin(), normalized.end(), normalized.begin(),
                   [](unsigned char character) {
                     return static_cast<char>(std::tolower(character));
                   });
    return normalized;
  }

 private:
  termflow::StandardTokenizer tokenizer_;
  termflow::LowerCaseFilter lower_case_filter_;
  termflow::StopFilter stop_filter_;
};

}  // namespace

int main(int argc, char** argv) {
  std::string input;
  if (argc > 1) {
    input = argv[1];
  } else {
    std::getline(std::cin, input);
  }

  const SimpleTitleAnalyzer analyzer;
  const auto tokens = analyzer.analyze(input);

  std::cout << "normalized: " << analyzer.normalize(input) << '\n';
  std::cout << "tokens:\n";
  for (const auto& token : tokens) {
    std::cout << "  [" << token.position << "] " << token.text << " (" << token.start_offset << ", "
              << token.end_offset << ")\n";
  }

  return 0;
}
