#include <iostream>
#include <sstream>
#include <string>

#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/query/query_analyzer.hpp"
#include "termflow/query/rewrite_loader.hpp"

namespace {

std::string read_all_stdin() {
  std::ostringstream buffer;
  buffer << std::cin.rdbuf();
  return buffer.str();
}

std::string occur_name(termflow::query::ClauseOccur occur) {
  switch (occur) {
    case termflow::query::ClauseOccur::should:
      return "should";
    case termflow::query::ClauseOccur::must:
      return "must";
    case termflow::query::ClauseOccur::must_not:
      return "must_not";
  }
  return "unknown";
}

std::string rewrite_name(termflow::query::RewriteKind kind) {
  switch (kind) {
    case termflow::query::RewriteKind::canonical:
      return "canonical";
    case termflow::query::RewriteKind::equivalent:
      return "equivalent";
    case termflow::query::RewriteKind::expansion:
      return "expansion";
  }
  return "unknown";
}

void print_terms(const std::vector<std::string>& terms) {
  std::cout << "[";
  for (std::size_t index = 0; index < terms.size(); ++index) {
    if (index > 0) {
      std::cout << ", ";
    }
    std::cout << terms[index];
  }
  std::cout << "]";
}

}  // namespace

int main(int argc, char** argv) {
  std::string input;
  if (argc > 1) {
    input = argv[1];
  } else {
    input = read_all_stdin();
  }

  termflow::EnglishAnalyzer analyzer;
  termflow::query::RewriteLoader loader;

  termflow::query::QueryAnalysisOptions options;
  if (argc > 2) {
    options.rewrites = loader.load_file(argv[2]);
  } else {
    options.rewrites = loader.parse(R"(
        car rentals => automobile rentals;
        tv -> television;
    )");
  }

  termflow::query::QueryAnalyzer query_analyzer(analyzer, options);
  const auto analyzed = query_analyzer.analyze(input);

  std::cout << "query: " << analyzed.text << '\n';
  for (const auto& clause : analyzed.clauses) {
    std::cout << "clause occur=" << occur_name(clause.occur)
              << " quoted=" << (clause.quoted ? "true" : "false")
              << " text=\"" << clause.text << "\" terms=";
    print_terms(clause.terms);
    std::cout << '\n';

    for (const auto& alternative : clause.alternatives) {
      std::cout << "  alternative kind=" << rewrite_name(alternative.kind) << " terms=";
      print_terms(alternative.terms);
      std::cout << '\n';
    }
  }

  return 0;
}
