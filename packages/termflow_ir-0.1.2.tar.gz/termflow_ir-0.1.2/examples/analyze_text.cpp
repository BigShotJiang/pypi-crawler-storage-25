#include <iostream>
#include <sstream>
#include <string>
#include <string_view>

#include "termflow/analysis/english_analyzer.hpp"

namespace {

std::string read_all_stdin() {
  std::ostringstream buffer;
  buffer << std::cin.rdbuf();
  return buffer.str();
}

}  // namespace

int main(int argc, char** argv) {
  std::string input;
  if (argc > 1) {
    input = argv[1];
  } else {
    input = read_all_stdin();
  }

  termflow::EnglishAnalyzer analyzer;
  const auto tokens = analyzer.analyze(input);

  std::cout << "normalized: " << analyzer.normalize(input) << '\n';
  std::cout << "tokens:\n";
  for (const auto& token : tokens) {
    std::cout << "  text=" << token.text << " start=" << token.start_offset
              << " end=" << token.end_offset << " pos=" << token.position
              << " pos_inc=" << token.position_increment
              << " keyword=" << (token.keyword ? "true" : "false") << '\n';
  }

  return 0;
}
