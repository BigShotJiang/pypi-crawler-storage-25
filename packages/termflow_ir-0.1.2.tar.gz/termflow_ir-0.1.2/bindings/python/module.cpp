#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <string_view>

#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/analysis/term_extractor.hpp"
#include "termflow/query/query_analyzer.hpp"
#include "termflow/query/rewrite_loader.hpp"
#include "termflow/query/rewrite_validator.hpp"

namespace py = pybind11;

PYBIND11_MODULE(_termflow, module) {
  module.doc() = "Python bindings for the termflow English analysis library";

  py::class_<termflow::Token>(module, "Token")
      .def_property_readonly("text", [](const termflow::Token& token) { return token.text; })
      .def_property_readonly("start_offset",
                             [](const termflow::Token& token) { return token.start_offset; })
      .def_property_readonly("end_offset",
                             [](const termflow::Token& token) { return token.end_offset; })
      .def_property_readonly("position", [](const termflow::Token& token) { return token.position; })
      .def_property_readonly("position_increment",
                             [](const termflow::Token& token) { return token.position_increment; })
      .def_property_readonly("keyword", [](const termflow::Token& token) { return token.keyword; });

  py::enum_<termflow::TermCharacterPolicy>(module, "TermCharacterPolicy")
      .value("ANY", termflow::TermCharacterPolicy::any)
      .value("ALPHABETIC", termflow::TermCharacterPolicy::alphabetic)
      .value("ASCII_ALPHABETIC", termflow::TermCharacterPolicy::ascii_alphabetic)
      .export_values();

  py::class_<termflow::Analyzer>(module, "Analyzer");

  py::class_<termflow::EnglishAnalyzerOptions>(module, "EnglishAnalyzerOptions")
      .def(py::init<>())
      .def_readwrite("unicode_normalization",
                     &termflow::EnglishAnalyzerOptions::unicode_normalization)
      .def_readwrite("lowercase", &termflow::EnglishAnalyzerOptions::lowercase)
      .def_readwrite("english_possessive", &termflow::EnglishAnalyzerOptions::english_possessive)
      .def_readwrite("stop_filter", &termflow::EnglishAnalyzerOptions::stop_filter)
      .def_readwrite("stemming", &termflow::EnglishAnalyzerOptions::stemming)
      .def_readwrite("ascii_folding", &termflow::EnglishAnalyzerOptions::ascii_folding)
      .def_readwrite("use_default_stop_words",
                     &termflow::EnglishAnalyzerOptions::use_default_stop_words)
      .def_readwrite("stop_words", &termflow::EnglishAnalyzerOptions::stop_words)
      .def_readwrite("stem_exclusion_set", &termflow::EnglishAnalyzerOptions::stem_exclusion_set);

  py::class_<termflow::EnglishAnalyzer, termflow::Analyzer>(module, "EnglishAnalyzer")
      .def(py::init<>())
      .def(py::init<termflow::EnglishAnalyzerOptions>())
      .def("analyze",
           [](const termflow::EnglishAnalyzer& analyzer, std::string_view text) {
             return analyzer.analyze(text);
           })
      .def("analyze_terms",
           [](const termflow::EnglishAnalyzer& analyzer, std::string_view text) {
             return analyzer.analyze_terms(text);
           })
      .def("analyze_term",
           [](const termflow::EnglishAnalyzer& analyzer, std::string_view text) {
             return analyzer.analyze_term(text);
           })
      .def("analyze_to_string",
           [](const termflow::EnglishAnalyzer& analyzer, std::string_view text,
              std::string_view separator) { return analyzer.analyze_to_string(text, separator); },
           py::arg("text"),
           py::arg("separator") = " ")
      .def("normalize",
           [](const termflow::EnglishAnalyzer& analyzer, std::string_view text) {
             return analyzer.normalize(text);
           })
      .def_static("default_stop_words", &termflow::EnglishAnalyzer::default_stop_words);

  py::class_<termflow::TermExtractionOptions>(module, "TermExtractionOptions")
      .def(py::init<>())
      .def_readwrite("min_term_length", &termflow::TermExtractionOptions::min_term_length)
      .def_readwrite("keep_numeric_terms", &termflow::TermExtractionOptions::keep_numeric_terms)
      .def_readwrite("character_policy", &termflow::TermExtractionOptions::character_policy);

  py::class_<termflow::TermExtractor>(module, "TermExtractor")
      .def(py::init<const termflow::Analyzer&, termflow::TermExtractionOptions>(),
           py::arg("analyzer"),
           py::arg("options") = termflow::TermExtractionOptions{},
           py::keep_alive<1, 2>())
      .def("extract",
           [](const termflow::TermExtractor& extractor, std::string_view text) {
             return extractor.extract(text);
           })
      .def("extract_one",
           [](const termflow::TermExtractor& extractor, std::string_view text) {
             return extractor.extract_one(text);
           })
      .def("extract_joined",
           [](const termflow::TermExtractor& extractor, std::string_view text,
              std::string_view separator) { return extractor.extract_joined(text, separator); },
           py::arg("text"),
           py::arg("separator") = " ");

  auto query_module = module.def_submodule("query", "Query parsing and analysis helpers");

  py::enum_<termflow::query::ClauseOccur>(query_module, "ClauseOccur")
      .value("SHOULD", termflow::query::ClauseOccur::should)
      .value("MUST", termflow::query::ClauseOccur::must)
      .value("MUST_NOT", termflow::query::ClauseOccur::must_not)
      .export_values();

  py::enum_<termflow::query::RewriteKind>(query_module, "RewriteKind")
      .value("CANONICAL", termflow::query::RewriteKind::canonical)
      .value("EQUIVALENT", termflow::query::RewriteKind::equivalent)
      .value("EXPANSION", termflow::query::RewriteKind::expansion)
      .export_values();

  py::enum_<termflow::query::RewriteValidationSeverity>(query_module,
                                                        "RewriteValidationSeverity")
      .value("WARNING", termflow::query::RewriteValidationSeverity::warning)
      .value("ERROR", termflow::query::RewriteValidationSeverity::error)
      .export_values();

  py::enum_<termflow::query::RewriteValidationCode>(query_module, "RewriteValidationCode")
      .value("EMPTY_MATCH_TERMS", termflow::query::RewriteValidationCode::empty_match_terms)
      .value("EMPTY_REWRITE_TERMS", termflow::query::RewriteValidationCode::empty_rewrite_terms)
      .value("NO_OP_CANONICAL_RULE",
             termflow::query::RewriteValidationCode::no_op_canonical_rule)
      .value("CONFLICTING_CANONICAL_TARGET",
             termflow::query::RewriteValidationCode::conflicting_canonical_target)
      .value("CANONICAL_CYCLE", termflow::query::RewriteValidationCode::canonical_cycle)
      .value("SHADOWED_CANONICAL_RULE",
             termflow::query::RewriteValidationCode::shadowed_canonical_rule)
      .value("DUPLICATE_ALTERNATIVE_RULE",
             termflow::query::RewriteValidationCode::duplicate_alternative_rule)
      .value("SHADOWED_ALTERNATIVE_RULE",
             termflow::query::RewriteValidationCode::shadowed_alternative_rule)
      .export_values();

  py::class_<termflow::query::ParsedClause>(query_module, "ParsedClause")
      .def(py::init<>())
      .def(py::init<termflow::query::ClauseOccur, std::string, bool>(),
           py::arg("occur") = termflow::query::ClauseOccur::should,
           py::arg("text") = "",
           py::arg("quoted") = false)
      .def_readwrite("occur", &termflow::query::ParsedClause::occur)
      .def_readwrite("text", &termflow::query::ParsedClause::text)
      .def_readwrite("quoted", &termflow::query::ParsedClause::quoted);

  py::class_<termflow::query::ParsedQuery>(query_module, "ParsedQuery")
      .def(py::init<>())
      .def(py::init<std::string, std::vector<termflow::query::ParsedClause>>(),
           py::arg("text") = "",
           py::arg("clauses") = std::vector<termflow::query::ParsedClause>{})
      .def_readwrite("text", &termflow::query::ParsedQuery::text)
      .def_readwrite("clauses", &termflow::query::ParsedQuery::clauses);

  py::class_<termflow::query::RewriteDefinition>(query_module, "RewriteDefinition")
      .def(py::init<>())
      .def(py::init<std::string, std::string, termflow::query::RewriteKind>(),
           py::arg("match") = "",
           py::arg("rewrite") = "",
           py::arg("kind") = termflow::query::RewriteKind::equivalent)
      .def_readwrite("match", &termflow::query::RewriteDefinition::match)
      .def_readwrite("rewrite", &termflow::query::RewriteDefinition::rewrite)
      .def_readwrite("kind", &termflow::query::RewriteDefinition::kind);

  py::class_<termflow::query::QueryAnalysisOptions>(query_module, "QueryAnalysisOptions")
      .def(py::init<>())
      .def(py::init<std::vector<termflow::query::RewriteDefinition>, bool>(),
           py::arg("rewrites") = std::vector<termflow::query::RewriteDefinition>{},
           py::arg("deduplicate_alternatives") = true)
      .def_readwrite("rewrites", &termflow::query::QueryAnalysisOptions::rewrites)
      .def_readwrite("deduplicate_alternatives",
                     &termflow::query::QueryAnalysisOptions::deduplicate_alternatives);

  py::class_<termflow::query::AnalyzedAlternative>(query_module, "AnalyzedAlternative")
      .def(py::init<>())
      .def(py::init<std::vector<std::string>, termflow::query::RewriteKind>(),
           py::arg("terms") = std::vector<std::string>{},
           py::arg("kind") = termflow::query::RewriteKind::equivalent)
      .def_readwrite("terms", &termflow::query::AnalyzedAlternative::terms)
      .def_readwrite("kind", &termflow::query::AnalyzedAlternative::kind);

  py::class_<termflow::query::AnalyzedClause>(query_module, "AnalyzedClause")
      .def(py::init<>())
      .def(py::init<termflow::query::ClauseOccur, std::string, bool,
                    std::vector<std::string>, std::vector<termflow::query::AnalyzedAlternative>>(),
           py::arg("occur") = termflow::query::ClauseOccur::should,
           py::arg("text") = "",
           py::arg("quoted") = false,
           py::arg("terms") = std::vector<std::string>{},
           py::arg("alternatives") =
               std::vector<termflow::query::AnalyzedAlternative>{})
      .def_readwrite("occur", &termflow::query::AnalyzedClause::occur)
      .def_readwrite("text", &termflow::query::AnalyzedClause::text)
      .def_readwrite("quoted", &termflow::query::AnalyzedClause::quoted)
      .def_readwrite("terms", &termflow::query::AnalyzedClause::terms)
      .def_readwrite("alternatives", &termflow::query::AnalyzedClause::alternatives);

  py::class_<termflow::query::AnalyzedQuery>(query_module, "AnalyzedQuery")
      .def(py::init<>())
      .def(py::init<std::string, std::vector<termflow::query::AnalyzedClause>>(),
           py::arg("text") = "",
           py::arg("clauses") = std::vector<termflow::query::AnalyzedClause>{})
      .def_readwrite("text", &termflow::query::AnalyzedQuery::text)
      .def_readwrite("clauses", &termflow::query::AnalyzedQuery::clauses);

  py::class_<termflow::query::ValidatedRewrite>(query_module, "ValidatedRewrite")
      .def(py::init<>())
      .def(py::init<std::size_t, termflow::query::RewriteDefinition, std::vector<std::string>,
                    std::vector<std::string>>(),
           py::arg("rule_index") = 0,
           py::arg("definition") = termflow::query::RewriteDefinition{},
           py::arg("analyzed_match_terms") = std::vector<std::string>{},
           py::arg("analyzed_rewrite_terms") = std::vector<std::string>{})
      .def_readwrite("rule_index", &termflow::query::ValidatedRewrite::rule_index)
      .def_readwrite("definition", &termflow::query::ValidatedRewrite::definition)
      .def_readwrite("analyzed_match_terms",
                     &termflow::query::ValidatedRewrite::analyzed_match_terms)
      .def_readwrite("analyzed_rewrite_terms",
                     &termflow::query::ValidatedRewrite::analyzed_rewrite_terms);

  py::class_<termflow::query::RewriteValidationIssue>(query_module, "RewriteValidationIssue")
      .def(py::init<>())
      .def(py::init<termflow::query::RewriteValidationSeverity,
                    termflow::query::RewriteValidationCode, std::vector<std::size_t>,
                    std::string>(),
           py::arg("severity") = termflow::query::RewriteValidationSeverity::warning,
           py::arg("code") =
               termflow::query::RewriteValidationCode::duplicate_alternative_rule,
           py::arg("rule_indices") = std::vector<std::size_t>{},
           py::arg("message") = "")
      .def_readwrite("severity", &termflow::query::RewriteValidationIssue::severity)
      .def_readwrite("code", &termflow::query::RewriteValidationIssue::code)
      .def_readwrite("rule_indices", &termflow::query::RewriteValidationIssue::rule_indices)
      .def_readwrite("message", &termflow::query::RewriteValidationIssue::message);

  py::class_<termflow::query::RewriteValidationResult>(query_module, "RewriteValidationResult")
      .def(py::init<>())
      .def_readwrite("rewrites", &termflow::query::RewriteValidationResult::rewrites)
      .def_readwrite("issues", &termflow::query::RewriteValidationResult::issues)
      .def("has_errors", &termflow::query::RewriteValidationResult::has_errors)
      .def("has_warnings", &termflow::query::RewriteValidationResult::has_warnings);

  py::class_<termflow::query::QueryParser>(query_module, "QueryParser")
      .def(py::init<>())
      .def("parse",
           [](const termflow::query::QueryParser& parser, std::string_view text) {
             return parser.parse(text);
           });

  py::class_<termflow::query::RewriteLoader>(query_module, "RewriteLoader")
      .def(py::init<>())
      .def("parse",
           [](const termflow::query::RewriteLoader& loader, std::string_view text) {
             return loader.parse(text);
           })
      .def("load_file",
           [](const termflow::query::RewriteLoader& loader, const std::string& path) {
             return loader.load_file(path);
           });

  py::class_<termflow::query::RewriteValidator>(query_module, "RewriteValidator")
      .def(py::init<const termflow::Analyzer&>(),
           py::arg("analyzer"),
           py::keep_alive<1, 2>())
      .def("validate",
           py::overload_cast<const termflow::query::QueryAnalysisOptions&>(
               &termflow::query::RewriteValidator::validate, py::const_))
      .def("validate",
           py::overload_cast<const std::vector<termflow::query::RewriteDefinition>&>(
               &termflow::query::RewriteValidator::validate, py::const_))
      .def_property_readonly("analyzer",
                             [](const termflow::query::RewriteValidator& validator)
                                 -> const termflow::Analyzer& {
                               return validator.analyzer();
                             },
                             py::return_value_policy::reference_internal);

  py::class_<termflow::query::QueryAnalyzer>(query_module, "QueryAnalyzer")
      .def(py::init<const termflow::Analyzer&, termflow::query::QueryAnalysisOptions>(),
           py::arg("analyzer"),
           py::arg("options") = termflow::query::QueryAnalysisOptions{},
           py::keep_alive<1, 2>())
      .def("parse",
           [](const termflow::query::QueryAnalyzer& analyzer, std::string_view text) {
             return analyzer.parse(text);
           })
      .def("analyze",
           py::overload_cast<std::string_view>(&termflow::query::QueryAnalyzer::analyze, py::const_))
      .def("analyze",
           py::overload_cast<const termflow::query::ParsedQuery&>(
               &termflow::query::QueryAnalyzer::analyze, py::const_))
      .def_property_readonly("options",
                             [](const termflow::query::QueryAnalyzer& analyzer) {
                               return analyzer.options();
                             });
}
