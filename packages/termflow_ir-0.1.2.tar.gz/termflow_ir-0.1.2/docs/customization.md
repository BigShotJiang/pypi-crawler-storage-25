# Customization Guide

This guide covers the supported ways to adapt `termflow` without guessing at internal behavior.

Use the lightest customization level that fits:

1. Change `EnglishAnalyzerOptions` when the built-in English pipeline is close to what you want.
2. Add a `TermExtractor` when you only need post-analysis term filtering.
3. Add query rewrites when customization belongs at query time.
4. Implement a custom `Analyzer` in C++ when you need a different tokenization or token-filter pipeline.

## Customize The Built-In English Analyzer

`EnglishAnalyzer` is configurable through `EnglishAnalyzerOptions`.

Available toggles:

- `unicode_normalization`
- `lowercase`
- `english_possessive`
- `stop_filter`
- `stemming`
- `ascii_folding`
- `use_default_stop_words`
- `stop_words`
- `stem_exclusion_set`

Example:

```cpp
termflow::EnglishAnalyzerOptions options;
options.lowercase = true;
options.stop_filter = true;
options.use_default_stop_words = false;
options.stop_words = {"and", "or", "the"};
options.stemming = false;
options.ascii_folding = true;
options.stem_exclusion_set = {"cafe"};

termflow::EnglishAnalyzer analyzer(options);
```

Key details:

- disabling a stage disables only that stage
- `normalize()` only applies Unicode normalization, lowercasing, and ASCII folding
- stop words and stem exclusions are normalized using the enabled pre-stem stages
- `ascii_folding` runs after stemming

That means you can often get the behavior you want without creating a new analyzer type.

## Post-Filter Terms With `TermExtractor`

If the analyzer output is already correct and you only want to decide which terms to keep, use `TermExtractor`.

```cpp
termflow::TermExtractionOptions options;
options.min_term_length = 3;
options.keep_numeric_terms = false;
options.character_policy = termflow::TermCharacterPolicy::alphabetic;

termflow::TermExtractor extractor(analyzer, options);
const auto terms = extractor.extract(text);
```

This is the right tool when you want:

- minimum term length filtering
- numeric-term removal
- alphabetic-only or ASCII-only term policies

It is not the right tool when you need different tokenization, stemming, or stop-word behavior. That belongs in the analyzer.

## Add Query-Time Rewrites

If the analyzer should stay stable but the query side needs aliases, canonicalization, or expansions, customize the query layer instead of the analyzer.

```cpp
termflow::query::RewriteLoader loader;

termflow::query::QueryAnalysisOptions options;
options.deduplicate_alternatives = true;
options.rewrites = loader.parse(R"(
  tv -> television;
  car rentals => automobile rentals;
  car rentals ~> vehicle rentals;
)");

termflow::query::RewriteValidator validator(analyzer);
const auto validation = validator.validate(options);

termflow::query::QueryAnalyzer query_analyzer(analyzer, options);
```

Use:

- canonical rewrites for one preferred analyzed term sequence
- equivalent rewrites for synonyms with equal standing
- expansion rewrites for broader recall-oriented alternatives

Validate rewrite packs before you rely on them. `RewriteValidator` reports empty analyzed rules, canonical conflicts, cycles, and shadowed or duplicate alternatives.

## Build A Custom Analyzer In C++

If the built-in English analyzer is not the right model, implement your own `Analyzer`.

The base flow is:

1. `apply_char_filters(text)`
2. `create_tokens(filtered_text)`
3. `apply_token_filters(tokens)`
4. position recomputation

`normalize(text)` runs:

1. `apply_char_filters(text)`
2. `normalize_text(filtered_text)`

The key virtual methods are:

- `apply_char_filters(std::string_view)` if you want character-level preprocessing
- `create_tokens(std::string_view)` to tokenize text into `Token` objects
- `apply_token_filters(std::vector<Token>&)` for in-place token processing
- `normalize_text(std::string_view)` for the analyzer's lighter-weight normalization path

### Example

```cpp
#include <algorithm>
#include <cctype>
#include <string>
#include <string_view>
#include <vector>

#include "termflow/analysis/analyzer.hpp"
#include "termflow/analysis/lower_case_filter.hpp"
#include "termflow/analysis/standard_tokenizer.hpp"
#include "termflow/analysis/stop_filter.hpp"

class SimpleTitleAnalyzer final : public termflow::Analyzer {
 public:
  SimpleTitleAnalyzer() : stop_filter_({"a", "an", "the"}) {}

 protected:
  std::vector<termflow::Token> create_tokens(std::string_view text) const override {
    return tokenizer_.tokenize(text);
  }

  void apply_token_filters(std::vector<termflow::Token>& tokens) const override {
    lower_case_filter_.apply(tokens);
    stop_filter_.apply(tokens);
  }

  std::string normalize_text(std::string_view text) const override {
    std::string normalized(text);
    std::transform(normalized.begin(), normalized.end(), normalized.begin(),
                   [](unsigned char ch) { return static_cast<char>(std::tolower(ch)); });
    return normalized;
  }

 private:
  termflow::StandardTokenizer tokenizer_;
  termflow::LowerCaseFilter lower_case_filter_;
  termflow::StopFilter stop_filter_;
};
```

The full runnable version is in [examples/custom_analyzer.cpp](../examples/custom_analyzer.cpp).

### When To Override `apply_char_filters`

Most custom analyzers can ignore `apply_char_filters()` and rely only on tokenization and token filters.

Override it when you need character-level preprocessing before tokenization, for example:

- mapping or stripping input characters before tokenization
- applying a custom normalization pass shared by both `analyze()` and `normalize()`

Important limitation:

- v1 exposes only the transformed string from `CharFilter`
- offset correction is your responsibility if your character-level transform changes offsets
- there are no concrete `CharFilter` implementations in the repo yet

### Reusing Public Components

The public extension model is intentionally explicit. You can compose your analyzer out of:

- `StandardTokenizer`
- `LowerCaseFilter`
- `StopFilter`
- `EnglishPossessiveFilter`
- `PorterStemFilter`
- `UnicodeNormalizeFilter`
- `AsciiFoldingFilter`

The tokenizer and filter interfaces are batch-oriented:

- `Tokenizer::tokenize()` materializes all tokens
- `TokenFilter::apply()` mutates a token vector in place

## Python Customization Limits

Python currently supports configuring and using the built-in pieces:

- `EnglishAnalyzerOptions`
- `EnglishAnalyzer`
- `TermExtractor`
- `termflow.query`

Python does not currently expose the C++ extension model for:

- subclassing `Analyzer`
- writing custom tokenizers or token filters
- plugging in custom char filters

If you need a custom analysis pipeline, implement it in C++ and bind it separately.

## Design Constraints To Keep In Mind

Several docs and interfaces assume the following:

- APIs are batch-oriented, not streaming
- offsets are UTF-16 code-unit offsets
- quoted query clauses remain grouped, but `termflow` does not execute phrase queries
- analyzers and query helpers are intended for concurrent const use after construction

Those constraints are part of the public contract, so custom components should fit that model.
