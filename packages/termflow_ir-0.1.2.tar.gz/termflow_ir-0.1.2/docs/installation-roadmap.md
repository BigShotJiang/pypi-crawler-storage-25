# Installation Roadmap

This roadmap focuses on reducing adoption friction for both Python and C++ consumers.

## Primary Goal

Make `termflow` easy to adopt in an application without requiring users to reverse-engineer build prerequisites.

## Current Friction

- Python installation is zero-build on supported wheel platforms, but unsupported platforms still fall back to native builds.
- C++ consumers need to know how to install and discover the exported CMake package.
- ICU is a visible dependency in the current source and C++ install paths.
- There is no package-manager story yet for C++ consumers.
- The CLI exists now, but it still needs to stay aligned with the core library behavior.

## Priority Order

1. Keep the wheel/release path green in CI.
2. Keep the install and consumer path green in CI, not just the repo build.
3. Add C++ package-manager support.
4. Reduce the visibility of build prerequisites in remaining source-build paths.
5. Keep the tiny CLI useful for quick validation.

## Phase 1: Keep Python Installation Zero-Build

Target outcome:

```bash
python3 -m pip install termflow-ir
```

Work:

- keep the GitHub wheel workflow building supported Python versions and platforms
- publish wheels and an sdist to PyPI on each release
- verify import and smoke usage from a fresh virtual environment

Success condition:

- most Python users do not need a compiler, CMake, or ICU knowledge to get started

## Phase 2: Make C++ Consumption Obvious

Target outcome:

- `cmake --install` is documented
- `find_package(termflow CONFIG REQUIRED)` is documented and demonstrated
- a consumer example is kept in the repo

Work:

- keep [installation.md](installation.md) current
- keep [examples/find_package_consumer/CMakeLists.txt](../examples/find_package_consumer/CMakeLists.txt) working
- add a CI job that installs `termflow` to a prefix and builds the external consumer example against it

Success condition:

- a C++ user can copy a minimal CMake example and link successfully without reading the library internals

## Phase 3: Add A Package-Manager Story For C++

Recommended order:

1. `vcpkg`
2. Conan
3. Homebrew if you want a simple local install path on macOS

Work:

- define package metadata
- verify transitive ICU handling in each ecosystem
- document one blessed path first instead of several half-supported paths

Success condition:

- C++ consumers can install `termflow` through their existing dependency manager instead of building from source manually

## Phase 4: Reduce Dependency Friction

Possible directions:

- ensure Python wheels bundle what they need so ICU is not a user concern
- document exact system prerequisites for source builds
- make clean failure messages part of the install experience

Success condition:

- users understand immediately whether they are on a wheel path or a source-build path

## Phase 5: Keep The Tiny CLI Useful

The CLI is now installed with the Python package. It helps users validate installation quickly before writing integration code.

Current commands:

- `termflow analyze`
- `termflow extract`
- `termflow analyze-query`

Success condition:

- users can validate the install and core behavior before integrating code, and CLI behavior stays covered by smoke tests

## CI Checks To Add

- build and test the repo itself
- build and install the C++ package to a clean prefix
- build the external C++ consumer example against that installed prefix
- create a fresh virtual environment and verify Python import plus a smoke analysis call
- run `twine check` on release artifacts

## Suggested Near-Term Sequence

1. Keep the new install docs and consumer example in the repo.
2. Add a CI job for installed-package consumption.
3. Add wheel build and publish automation.
4. Add one C++ package-manager integration.
