# Installation Guide

This guide covers the current installation paths for `termflow` in both C++ and Python applications.

For usage examples after installation, see [usage.md](usage.md). For extension points, see [customization.md](customization.md).

## Choose The Right Install Path

- Use the Python package if your application is Python-first and you want the built-in analyzer, term extractor, and query helpers.
- Use the C++ install if your application is native C++ or another build uses CMake and links directly against the library.

## Python Installation

### Best Case: Install A Published Wheel

If a published wheel exists for the target platform, the ideal install looks like:

```bash
python3 -m pip install termflow-ir
```

That is the easiest path for Python consumers because it avoids a local native build. The Python package also installs a small `termflow` CLI:

```bash
termflow analyze "The Running Cars"
termflow extract "Running beaches 2024 e-mail"
termflow analyze-query 'tv +"car rentals"'
```

If you already built a wheel locally, installation can also be:

```bash
python3 -m pip install dist/*.whl
```

The repository now includes automated wheel builds for:

- Linux `x86_64`
- Linux `aarch64`
- macOS `x86_64`
- macOS `arm64`
- CPython 3.10, 3.11, and 3.12

Those wheels are built in [python-package.yml](../.github/workflows/python-package.yml) and are intended to bundle the ICU runtime dependencies so Python users do not need to install ICU separately.

### Maintainer Release Path

The release workflow publishes to PyPI when a GitHub release is published.

Current workflow expectations:

- workflow file: [python-package.yml](../.github/workflows/python-package.yml)
- GitHub environment: `pypi`
- release trigger: GitHub release published

The published package is now intended to live on PyPI as `termflow-ir`.

### Current Reality: Source Builds May Be Required

If a wheel is not available for the target platform, installation falls back to building from source. In that case, the machine needs:

- a C++20-capable compiler
- CMake 3.24+
- ICU development libraries
- a working Python build environment

Installing from the repo root looks like:

```bash
python3 -m pip install .
```

Or for editable local development:

```bash
python3 -m pip install -e .
```

Notes:

- the Python package builds the native extension with `scikit-build-core`
- Python consumers currently get the built-in analyzer, query module, and CLI, not the full C++ extension model
- if installation falls back to source, native toolchain and ICU availability become the main sources of friction

## C++ Installation From Source

`termflow` already supports installation as a CMake package. The installed package exports `termflow::termflow`.

### Build And Install

From the repository root:

```bash
cmake -S . -B build -G Ninja \
  -DTERMFLOW_BUILD_TESTS=OFF \
  -DTERMFLOW_BUILD_EXAMPLES=OFF \
  -DTERMFLOW_BUILD_PYTHON=OFF \
  -DTERMFLOW_INSTALL_CPP_ARTIFACTS=ON

cmake --build build
cmake --install build --prefix "$HOME/.local"
```

If `Ninja` is not installed, use another generator such as `Unix Makefiles`.

### Consume From Another CMake Project

Point CMake at the install prefix:

```bash
cmake -S consumer -B consumer/build -DCMAKE_PREFIX_PATH="$HOME/.local"
cmake --build consumer/build
```

Minimal consumer `CMakeLists.txt`:

```cmake
cmake_minimum_required(VERSION 3.24)

project(termflow_consumer LANGUAGES CXX)

find_package(termflow CONFIG REQUIRED)

add_executable(termflow_consumer main.cpp)
target_link_libraries(termflow_consumer PRIVATE termflow::termflow)
target_compile_features(termflow_consumer PRIVATE cxx_std_20)
```

Minimal `main.cpp`:

```cpp
#include <iostream>
#include "termflow/analysis/english_analyzer.hpp"

int main() {
  termflow::EnglishAnalyzer analyzer;
  const auto terms = analyzer.analyze_terms("The Running Cars");

  for (const auto& term : terms) {
    std::cout << term << '\n';
  }
}
```

There is also a runnable external consumer example at [examples/find_package_consumer/CMakeLists.txt](../examples/find_package_consumer/CMakeLists.txt).

### How CMake Finds `termflow`

The installed package config lives under the install prefix and exports `termflow::termflow`. If `CMAKE_PREFIX_PATH` is not convenient, you can point directly at the package config directory:

```bash
cmake -S consumer -B consumer/build \
  -Dtermflow_DIR="$HOME/.local/lib/cmake/termflow"
```

### ICU Requirement

The installed CMake package currently declares ICU as a required dependency. That means C++ consumers need ICU available in their build environment so `find_package(termflow CONFIG REQUIRED)` can resolve its transitive dependency.

## Recommended App Integration Patterns

### C++ Applications

Typical C++ usage looks like:

- analyze text at ingest time with `EnglishAnalyzer`
- use `TermExtractor` when the app wants final index terms instead of raw tokens
- use `termflow::query::QueryAnalyzer` at query time so query normalization matches document normalization

This fits:

- search backends
- indexing pipelines
- document preprocessing
- deduplication and normalization services

### Python Applications

Typical Python usage looks like:

- preprocessing corpora offline
- notebook experiments
- feature extraction pipelines
- lightweight services that need the same analysis behavior as a C++ backend

## Current Installation Gaps

Today, the main sources of installation friction are:

- no package-manager distribution for C++ consumers such as `vcpkg` or Conan
- ICU is still a visible dependency for local and C++ installs
- source builds still require native toolchain setup on unsupported platforms

The maintainer roadmap for reducing that friction is in [installation-roadmap.md](installation-roadmap.md).
