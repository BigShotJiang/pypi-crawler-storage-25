# Usage Guide

`termflow` is a batch-oriented text analysis library. The normal entry points are:

- `termflow::EnglishAnalyzer` for full token analysis
- `termflow::TermExtractor` for finalized term strings
- `termflow::query::*` for lightweight query parsing and query-time rewrites
- `termflow` Python bindings for the same built-in analyzer and query module

This guide focuses on using the existing public API. For extension points and custom analyzers, see [customization.md](customization.md).

## Before You Start

For installation paths, see [installation.md](installation.md). Build instructions for working directly from the repo also live in the main [README](../README.md#building). The runnable examples referenced below are built by default in a normal CMake build:

- `termflow_analyze`
- `termflow_extract_terms`
- `termflow_custom_analyzer`
- `termflow_analyze_query`

## C++ Quick Start

The simplest entry point is `EnglishAnalyzer`.

```cpp
#include <iostream>
#include "termflow/analysis/english_analyzer.hpp"

int main() {
  termflow::EnglishAnalyzer analyzer;

  const auto tokens = analyzer.analyze("The Running Cars");
  const auto terms = analyzer.analyze_terms("The Running Cars");
  const auto first = analyzer.analyze_term("Running");
  const auto joined = analyzer.analyze_to_string("The Running Cars");
  const auto normalized = analyzer.normalize("Running Cafe");

  std::cout << "term count: " << terms.size() << "\n";
  std::cout << "joined: " << joined << "\n";
  std::cout << "normalized: " << normalized << "\n";
}
```

Important behavior:

- `analyze()` returns full `Token` objects with text, offsets, positions, and keyword flags.
- `analyze_terms()` returns only finalized token text.
- `normalize()` is intentionally lighter-weight than `analyze()`. It does not tokenize.

The default English pipeline runs in this order:

1. `StandardTokenizer`
2. Unicode normalization
3. English possessive stripping
4. Lowercasing
5. Stop-word filtering
6. Keyword marking from `stem_exclusion_set`
7. Porter stemming
8. ASCII folding

See [examples/analyze_text.cpp](../examples/analyze_text.cpp) for a runnable version.

## Configuring `EnglishAnalyzer`

Use `EnglishAnalyzerOptions` when you want to tune the built-in analyzer without writing a new one.

```cpp
#include "termflow/analysis/english_analyzer.hpp"

termflow::EnglishAnalyzerOptions options;
options.unicode_normalization = true;
options.lowercase = true;
options.english_possessive = true;
options.stop_filter = true;
options.stemming = true;
options.ascii_folding = false;
options.use_default_stop_words = false;
options.stop_words = {"a", "an", "the"};
options.stem_exclusion_set = {"running"};

termflow::EnglishAnalyzer analyzer(options);
```

Notes:

- Set `use_default_stop_words = false` if you want to use only your own `stop_words`.
- `stem_exclusion_set` marks matching terms as keywords before stemming.
- Custom stop words and stem exclusions are normalized using the enabled pre-stem stages so they match analyzed token text.

## Extracting Final Terms

`TermExtractor` applies post-analysis filtering to an analyzer result. It does not change analyzer behavior.

```cpp
#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/analysis/term_extractor.hpp"

termflow::EnglishAnalyzer analyzer;

termflow::TermExtractionOptions options;
options.min_term_length = 2;
options.keep_numeric_terms = false;
options.character_policy = termflow::TermCharacterPolicy::ascii_alphabetic;

termflow::TermExtractor extractor(analyzer, options);

const auto terms = extractor.extract("Running beaches 2024 e-mail");
const auto first = extractor.extract_one("2024 Running");
const auto joined = extractor.extract_joined("Running beaches 2024 e-mail", "|");
```

Use `TermExtractor` when:

- you want minimum term length filtering
- you want to drop numeric terms
- you want a character policy such as `alphabetic` or `ascii_alphabetic`

See [examples/extract_terms.cpp](../examples/extract_terms.cpp) for a runnable example.

## Query Analysis

The query module gives you a small query-intent layer on top of an existing analyzer. It parses clauses, analyzes each clause with your analyzer, and optionally attaches query-time rewrites.

```cpp
#include "termflow/analysis/english_analyzer.hpp"
#include "termflow/query/query_analyzer.hpp"
#include "termflow/query/rewrite_loader.hpp"
#include "termflow/query/rewrite_validator.hpp"

termflow::EnglishAnalyzer analyzer;
termflow::query::RewriteLoader loader;

termflow::query::QueryAnalysisOptions options;
options.rewrites = loader.parse(R"(
  tv -> television;
  car rentals => automobile rentals;
  car rentals ~> vehicle rentals;
)");

termflow::query::RewriteValidator validator(analyzer);
const auto validation = validator.validate(options);

termflow::query::QueryAnalyzer query_analyzer(analyzer, options);
const auto analyzed = query_analyzer.analyze(R"(tv +"car rentals" -expired)");
```

Supported clause forms:

- bare terms
- `+required`
- `-excluded`
- quoted groups

Supported rewrite forms:

- `lhs -> rhs;` for canonical rewrites
- `lhs => rhs;` for equivalent alternatives
- `lhs ~> rhs;` for expansion alternatives
- `include "other-rules.tfq";`

Notes:

- canonical rewrites replace the primary analyzed term sequence
- equivalent and expansion rewrites are attached as alternatives
- rewrite matching is exact at the analyzed clause-term level
- quoted clauses stay grouped, but `termflow` does not implement executable phrase logic

See [examples/analyze_query.cpp](../examples/analyze_query.cpp) for a runnable example.

## Python Quick Start

The Python bindings expose the built-in analyzer, term extractor, and query module.

```python
from termflow import (
    EnglishAnalyzer,
    EnglishAnalyzerOptions,
    TermCharacterPolicy,
    TermExtractionOptions,
    TermExtractor,
    query,
)

options = EnglishAnalyzerOptions()
options.use_default_stop_words = False
options.stop_words = {"a", "an", "the"}

analyzer = EnglishAnalyzer(options)
print(analyzer.analyze_terms("The Running Cars"))
print(analyzer.normalize("Running Cafe"))

extract_options = TermExtractionOptions()
extract_options.min_term_length = 2
extract_options.keep_numeric_terms = False
extract_options.character_policy = TermCharacterPolicy.ASCII_ALPHABETIC

extractor = TermExtractor(analyzer, extract_options)
print(extractor.extract("Running beaches 2024 e-mail"))

loader = query.RewriteLoader()
query_options = query.QueryAnalysisOptions()
query_options.rewrites = loader.parse("tv -> television;")

query_analyzer = query.QueryAnalyzer(analyzer, query_options)
parsed = query_analyzer.analyze('tv +"car rentals"')
print(parsed.clauses[0].terms)
```

Python surface notes:

- enums use uppercase names such as `TermCharacterPolicy.ASCII_ALPHABETIC`
- the query API is exposed under `termflow.query`
- the Python bindings mirror the built-in analyzer APIs, not the full C++ extension model

The smoke test in [tests/python_smoke_test.py](../tests/python_smoke_test.py) is also a useful reference.

## CLI Quick Checks

The Python package also installs a small `termflow` CLI for quick validation:

```bash
termflow analyze "The Running Cars"
termflow extract "Running beaches 2024 e-mail"
termflow analyze-query 'tv +"car rentals"'
```

Useful options:

- `--json` for machine-readable output
- `--no-default-stop-words` to disable the built-in English stop-word set
- `termflow extract --min-term-length 2 --drop-numeric-terms --character-policy ascii-alphabetic`
- `termflow analyze-query --rewrites-file rewrites.tfq`
- `termflow analyze-query --rewrites 'tv -> television; car rentals => automobile rentals;'`

## Next Steps

If you want to go beyond the built-in English pipeline, see [customization.md](customization.md).
