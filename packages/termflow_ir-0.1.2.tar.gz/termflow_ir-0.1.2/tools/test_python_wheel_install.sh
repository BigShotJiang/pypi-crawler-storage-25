#!/usr/bin/env bash
set -euo pipefail

source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ -n "${VENV_DIR:-}" ]]; then
  venv_dir="${VENV_DIR}"
  cleanup=0
else
  venv_dir="$(mktemp -d "${TMPDIR:-/tmp}/termflow-wheel-venv.XXXXXX")/venv"
  cleanup=1
fi

trap 'if [[ "${cleanup}" == "1" ]]; then rm -rf "${venv_dir%/venv}"; fi' EXIT

if [[ -n "${WHEEL_PATH:-}" ]]; then
  wheel_path="${WHEEL_PATH}"
else
  shopt -s nullglob
  wheel_candidates=("${source_dir}"/dist/*.whl)
  shopt -u nullglob

  if [[ "${#wheel_candidates[@]}" -eq 0 ]]; then
    echo "no wheel found under ${source_dir}/dist" >&2
    exit 1
  fi

  wheel_path="${wheel_candidates[0]}"
fi

python3 -m venv "${venv_dir}"
"${venv_dir}/bin/python" -m pip install --upgrade pip
"${venv_dir}/bin/python" -m pip install "${wheel_path}"
"${venv_dir}/bin/python" "${source_dir}/tests/python_smoke_test.py"
"${venv_dir}/bin/termflow" analyze "The Running Cars" --json >/dev/null
