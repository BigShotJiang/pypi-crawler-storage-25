#!/usr/bin/env bash
set -euo pipefail

python3 -m build --sdist --wheel "$@"
python3 -m twine check dist/*
