#!/usr/bin/env bash
set -euo pipefail

source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

generator="${CMAKE_GENERATOR:-Ninja}"
build_dir="${BUILD_DIR:-${source_dir}/build}"

cmake_args=(
  -S "${source_dir}"
  -B "${build_dir}"
  -G "${generator}"
  -DTERMFLOW_BUILD_TESTS=ON
  -DTERMFLOW_BUILD_EXAMPLES=ON
  -DTERMFLOW_BUILD_PYTHON=ON
)

if [[ -n "${PYBIND11_DIR:-}" ]]; then
  cmake_args+=("-Dpybind11_DIR=${PYBIND11_DIR}")
fi

cmake "${cmake_args[@]}"
cmake --build "${build_dir}"
ctest --test-dir "${build_dir}" --output-on-failure

(
  cd "${source_dir}"
  rm -rf dist
  python3 -m build --sdist --wheel --no-isolation
  python3 -m twine check dist/*
)
