#!/usr/bin/env bash
set -euo pipefail

source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
generator="${CMAKE_GENERATOR:-Ninja}"

if [[ -n "${WORK_ROOT:-}" ]]; then
  work_root="${WORK_ROOT}"
  cleanup=0
else
  work_root="$(mktemp -d "${TMPDIR:-/tmp}/termflow-installed-consumer.XXXXXX")"
  cleanup=1
fi

trap 'if [[ "${cleanup}" == "1" ]]; then rm -rf "${work_root}"; fi' EXIT

install_prefix="${INSTALL_PREFIX:-${work_root}/prefix}"
lib_build_dir="${LIB_BUILD_DIR:-${work_root}/build-lib}"
consumer_build_dir="${CONSUMER_BUILD_DIR:-${work_root}/build-consumer}"
consumer_source_dir="${CONSUMER_SOURCE_DIR:-${source_dir}/examples/find_package_consumer}"

cmake -S "${source_dir}" -B "${lib_build_dir}" -G "${generator}" \
  -DTERMFLOW_BUILD_TESTS=OFF \
  -DTERMFLOW_BUILD_EXAMPLES=OFF \
  -DTERMFLOW_BUILD_PYTHON=OFF \
  -DTERMFLOW_INSTALL_CPP_ARTIFACTS=ON

cmake --build "${lib_build_dir}"
cmake --install "${lib_build_dir}" --prefix "${install_prefix}"

cmake -S "${consumer_source_dir}" -B "${consumer_build_dir}" -G "${generator}" \
  -DCMAKE_PREFIX_PATH="${install_prefix}"

cmake --build "${consumer_build_dir}"

consumer_output="$("${consumer_build_dir}/termflow_consumer")"
printf '%s\n' "${consumer_output}"

if ! printf '%s\n' "${consumer_output}" | grep -Fx '  run' >/dev/null; then
  echo "installed consumer output did not contain the expected term 'run'" >&2
  exit 1
fi

if ! printf '%s\n' "${consumer_output}" | grep -Fx '  car' >/dev/null; then
  echo "installed consumer output did not contain the expected term 'car'" >&2
  exit 1
fi
