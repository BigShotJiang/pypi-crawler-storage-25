#!/usr/bin/env bash
set -euo pipefail

if [ ! -d dist ] || ! compgen -G "dist/*" > /dev/null; then
  echo "dist/ is empty; build distributions first" >&2
  exit 1
fi

python3 -m twine upload "$@" dist/*
