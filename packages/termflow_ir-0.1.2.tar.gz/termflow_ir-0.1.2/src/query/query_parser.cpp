#include "termflow/query/query_parser.hpp"

#include <cctype>
#include <string>

namespace termflow::query {

ParsedQuery QueryParser::parse(std::string_view text) const {
  ParsedQuery query;
  query.text = std::string(text);

  std::size_t index = 0;
  while (index < text.size()) {
    while (index < text.size() &&
           std::isspace(static_cast<unsigned char>(text[index])) != 0) {
      ++index;
    }
    if (index >= text.size()) {
      break;
    }

    ClauseOccur occur = ClauseOccur::should;
    if (text[index] == '+') {
      occur = ClauseOccur::must;
      ++index;
    } else if (text[index] == '-') {
      occur = ClauseOccur::must_not;
      ++index;
    }

    while (index < text.size() &&
           std::isspace(static_cast<unsigned char>(text[index])) != 0) {
      ++index;
    }
    if (index >= text.size()) {
      break;
    }

    ParsedClause clause;
    clause.occur = occur;

    if (text[index] == '"') {
      clause.quoted = true;
      ++index;
      const std::size_t start = index;
      while (index < text.size() && text[index] != '"') {
        ++index;
      }
      clause.text = std::string(text.substr(start, index - start));
      if (index < text.size() && text[index] == '"') {
        ++index;
      }
    } else {
      const std::size_t start = index;
      while (index < text.size() &&
             std::isspace(static_cast<unsigned char>(text[index])) == 0) {
        ++index;
      }
      clause.text = std::string(text.substr(start, index - start));
    }

    if (!clause.text.empty()) {
      query.clauses.push_back(std::move(clause));
    }
  }

  return query;
}

}  // namespace termflow::query
