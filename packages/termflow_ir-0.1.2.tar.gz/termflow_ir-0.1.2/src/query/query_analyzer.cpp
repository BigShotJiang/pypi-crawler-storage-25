#include "termflow/query/query_analyzer.hpp"

#include <algorithm>

#include "rewrite_internal.hpp"

namespace termflow::query {

namespace {

bool contains_terms(const std::vector<AnalyzedAlternative>& alternatives,
                    const std::vector<std::string>& terms) {
  return std::any_of(alternatives.begin(), alternatives.end(),
                     [&terms](const AnalyzedAlternative& alternative) {
                       return alternative.terms == terms;
                     });
}

}  // namespace

QueryAnalyzer::QueryAnalyzer(const termflow::Analyzer& analyzer, QueryAnalysisOptions options)
    : analyzer_(&analyzer), options_(std::move(options)) {
  rewrites_.reserve(options_.rewrites.size());
  for (std::size_t index = 0; index < options_.rewrites.size(); ++index) {
    const auto prepared = detail::prepare_rewrite(*analyzer_, options_.rewrites[index], index);
    if (!prepared.match_terms.empty() && !prepared.rewrite_terms.empty()) {
      rewrites_.push_back(PreparedRewrite{.match_terms = prepared.match_terms,
                                          .rewrite_terms = prepared.rewrite_terms,
                                          .kind = prepared.definition.kind});
    }
  }
}

ParsedQuery QueryAnalyzer::parse(std::string_view text) const {
  return parser_.parse(text);
}

AnalyzedQuery QueryAnalyzer::analyze(std::string_view text) const {
  return analyze(parse(text));
}

AnalyzedQuery QueryAnalyzer::analyze(const ParsedQuery& query) const {
  AnalyzedQuery analyzed;
  analyzed.text = query.text;
  analyzed.clauses.reserve(query.clauses.size());

  for (const auto& parsed_clause : query.clauses) {
    AnalyzedClause clause;
    clause.occur = parsed_clause.occur;
    clause.text = parsed_clause.text;
    clause.quoted = parsed_clause.quoted;
    clause.terms = apply_canonical_rewrites(analyzer_->analyze_terms(parsed_clause.text));
    append_rewrite_alternatives(clause);
    analyzed.clauses.push_back(std::move(clause));
  }

  return analyzed;
}

std::vector<std::string> QueryAnalyzer::apply_canonical_rewrites(
    const std::vector<std::string>& terms) const {
  std::vector<std::string> rewritten = terms;
  if (rewritten.empty()) {
    return rewritten;
  }

  for (std::size_t iteration = 0; iteration < rewrites_.size(); ++iteration) {
    bool changed = false;
    for (const auto& rewrite : rewrites_) {
      if (rewrite.kind == RewriteKind::canonical && rewrite.match_terms == rewritten &&
          rewrite.rewrite_terms != rewritten) {
        rewritten = rewrite.rewrite_terms;
        changed = true;
        break;
      }
    }
    if (!changed) {
      break;
    }
  }

  return rewritten;
}

void QueryAnalyzer::append_rewrite_alternatives(AnalyzedClause& clause) const {
  if (clause.terms.empty()) {
    return;
  }

  for (const auto& rewrite : rewrites_) {
    if (rewrite.kind == RewriteKind::canonical || rewrite.match_terms != clause.terms) {
      continue;
    }
    if (options_.deduplicate_alternatives &&
        (rewrite.rewrite_terms == clause.terms ||
         contains_terms(clause.alternatives, rewrite.rewrite_terms))) {
      continue;
    }

    clause.alternatives.push_back(
        AnalyzedAlternative{.terms = rewrite.rewrite_terms, .kind = rewrite.kind});
  }
}

}  // namespace termflow::query
