#include "termflow/query/rewrite_loader.hpp"

#include <cctype>
#include <fstream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_set>

namespace termflow::query {

namespace {

std::string_view trim(std::string_view text) {
  std::size_t start = 0;
  while (start < text.size() &&
         std::isspace(static_cast<unsigned char>(text[start])) != 0) {
    ++start;
  }

  std::size_t end = text.size();
  while (end > start && std::isspace(static_cast<unsigned char>(text[end - 1])) != 0) {
    --end;
  }

  return text.substr(start, end - start);
}

std::string strip_comments(std::string_view text) {
  std::string result;
  result.reserve(text.size());

  std::size_t line_start = 0;
  while (line_start < text.size()) {
    std::size_t line_end = text.find('\n', line_start);
    if (line_end == std::string_view::npos) {
      line_end = text.size();
    }

    const std::string_view line = text.substr(line_start, line_end - line_start);
    const std::size_t comment = line.find('#');
    if (comment == std::string_view::npos) {
      result.append(line);
    } else {
      result.append(line.substr(0, comment));
    }
    result.push_back('\n');

    if (line_end == text.size()) {
      break;
    }
    line_start = line_end + 1;
  }

  return result;
}

bool starts_with_include(std::string_view statement) {
  constexpr std::string_view keyword = "include";
  if (!statement.starts_with(keyword)) {
    return false;
  }

  if (statement.size() == keyword.size()) {
    return true;
  }

  const char next = statement[keyword.size()];
  return std::isspace(static_cast<unsigned char>(next)) != 0 || next == '"';
}

std::string parse_include_target(std::string_view text) {
  text = trim(text);
  if (text.empty()) {
    throw std::invalid_argument("rewrite include statement is missing a path");
  }

  if (text.front() == '"') {
    if (text.size() < 2 || text.back() != '"') {
      throw std::invalid_argument("rewrite include path must end with a quote");
    }
    return std::string(text.substr(1, text.size() - 2));
  }

  return std::string(text);
}

struct StatementOperator {
  std::string_view token;
  RewriteKind kind;
};

RewriteDefinition parse_rewrite_statement(std::string_view statement) {
  constexpr StatementOperator operators[] = {
      {.token = "=>", .kind = RewriteKind::equivalent},
      {.token = "~>", .kind = RewriteKind::expansion},
      {.token = "->", .kind = RewriteKind::canonical},
  };

  std::size_t best_position = std::string_view::npos;
  const StatementOperator* best_operator = nullptr;
  for (const auto& candidate : operators) {
    const std::size_t position = statement.find(candidate.token);
    if (position != std::string_view::npos &&
        (best_operator == nullptr || position < best_position)) {
      best_position = position;
      best_operator = &candidate;
    }
  }

  if (best_operator == nullptr) {
    throw std::invalid_argument("invalid rewrite statement: " + std::string(statement));
  }

  const std::string_view match = trim(statement.substr(0, best_position));
  const std::string_view rewrite =
      trim(statement.substr(best_position + best_operator->token.size()));

  if (match.empty() || rewrite.empty()) {
    throw std::invalid_argument("rewrite statements require non-empty match and rewrite text");
  }

  return RewriteDefinition{
      .match = std::string(match),
      .rewrite = std::string(rewrite),
      .kind = best_operator->kind,
  };
}

void parse_text(std::string_view text,
                const std::filesystem::path* base_directory,
                std::unordered_set<std::string>& active_files,
                std::vector<RewriteDefinition>& rewrites);

void load_file_impl(const std::filesystem::path& path,
                    std::unordered_set<std::string>& active_files,
                    std::vector<RewriteDefinition>& rewrites) {
  const auto normalized_path = std::filesystem::absolute(path).lexically_normal();
  const std::string key = normalized_path.string();

  if (!active_files.insert(key).second) {
    throw std::invalid_argument("cyclic rewrite include detected for file: " + key);
  }

  try {
    std::ifstream input(normalized_path);
    if (!input) {
      throw std::runtime_error("failed to open rewrite file: " + key);
    }

    std::string text((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    const auto base_directory = normalized_path.parent_path();
    parse_text(text, &base_directory, active_files, rewrites);
  } catch (...) {
    active_files.erase(key);
    throw;
  }

  active_files.erase(key);
}

void parse_text(std::string_view text,
                const std::filesystem::path* base_directory,
                std::unordered_set<std::string>& active_files,
                std::vector<RewriteDefinition>& rewrites) {
  const std::string content = strip_comments(text);

  std::size_t start = 0;
  while (start < content.size()) {
    std::size_t end = content.find(';', start);
    if (end == std::string::npos) {
      end = content.size();
    }

    const std::string_view statement = trim(
        std::string_view(content).substr(start, end - start));
    if (!statement.empty()) {
      if (starts_with_include(statement)) {
        if (base_directory == nullptr) {
          throw std::invalid_argument(
              "rewrite include statements are only supported when loading from a file");
        }
        const auto include_target =
            parse_include_target(statement.substr(std::string_view("include").size()));
        load_file_impl(*base_directory / include_target, active_files, rewrites);
      } else {
        rewrites.push_back(parse_rewrite_statement(statement));
      }
    }

    if (end == content.size()) {
      break;
    }
    start = end + 1;
  }
}

}  // namespace

std::vector<RewriteDefinition> RewriteLoader::parse(std::string_view text) const {
  std::unordered_set<std::string> active_files;
  std::vector<RewriteDefinition> rewrites;
  parse_text(text, nullptr, active_files, rewrites);
  return rewrites;
}

std::vector<RewriteDefinition> RewriteLoader::load_file(const std::filesystem::path& path) const {
  std::unordered_set<std::string> active_files;
  std::vector<RewriteDefinition> rewrites;
  load_file_impl(path, active_files, rewrites);
  return rewrites;
}

}  // namespace termflow::query
