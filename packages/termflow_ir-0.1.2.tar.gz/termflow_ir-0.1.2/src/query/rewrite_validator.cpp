#include "termflow/query/rewrite_validator.hpp"

#include <algorithm>
#include <functional>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "rewrite_internal.hpp"

namespace termflow::query {

namespace {

void add_issue(RewriteValidationResult& result,
               RewriteValidationSeverity severity,
               RewriteValidationCode code,
               std::vector<std::size_t> rule_indices,
               std::string message) {
  result.issues.push_back(RewriteValidationIssue{
      .severity = severity,
      .code = code,
      .rule_indices = std::move(rule_indices),
      .message = std::move(message),
  });
}

std::string format_rule_index(std::size_t rule_index) {
  return "rule " + std::to_string(rule_index);
}

std::string format_rule_indices(const std::vector<std::size_t>& rule_indices) {
  std::ostringstream stream;
  for (std::size_t index = 0; index < rule_indices.size(); ++index) {
    if (index > 0) {
      stream << ", ";
    }
    stream << rule_indices[index];
  }
  return stream.str();
}

std::string alternative_key(const std::vector<std::string>& match_terms,
                            const std::vector<std::string>& rewrite_terms) {
  return detail::terms_key(match_terms) + "\x1e" + detail::terms_key(rewrite_terms);
}

std::string exact_alternative_key(const detail::PreparedRewrite& rewrite) {
  return std::to_string(static_cast<int>(rewrite.definition.kind)) + "\x1d" +
         alternative_key(rewrite.match_terms, rewrite.rewrite_terms);
}

}  // namespace

bool RewriteValidationResult::has_errors() const noexcept {
  return std::any_of(issues.begin(), issues.end(), [](const RewriteValidationIssue& issue) {
    return issue.severity == RewriteValidationSeverity::error;
  });
}

bool RewriteValidationResult::has_warnings() const noexcept {
  return std::any_of(issues.begin(), issues.end(), [](const RewriteValidationIssue& issue) {
    return issue.severity == RewriteValidationSeverity::warning;
  });
}

RewriteValidator::RewriteValidator(const termflow::Analyzer& analyzer) : analyzer_(&analyzer) {}

RewriteValidationResult RewriteValidator::validate(
    const std::vector<RewriteDefinition>& rewrites) const {
  QueryAnalysisOptions options;
  options.rewrites = rewrites;
  return validate(options);
}

RewriteValidationResult RewriteValidator::validate(const QueryAnalysisOptions& options) const {
  RewriteValidationResult result;
  result.rewrites.reserve(options.rewrites.size());

  std::vector<detail::PreparedRewrite> prepared_rewrites;
  prepared_rewrites.reserve(options.rewrites.size());

  for (std::size_t index = 0; index < options.rewrites.size(); ++index) {
    const auto prepared = detail::prepare_rewrite(*analyzer_, options.rewrites[index], index);

    result.rewrites.push_back(ValidatedRewrite{
        .rule_index = prepared.rule_index,
        .definition = prepared.definition,
        .analyzed_match_terms = prepared.match_terms,
        .analyzed_rewrite_terms = prepared.rewrite_terms,
    });

    bool valid = true;
    if (prepared.match_terms.empty()) {
      add_issue(result, RewriteValidationSeverity::error,
                RewriteValidationCode::empty_match_terms, {prepared.rule_index},
                format_rule_index(prepared.rule_index) +
                    " analyzes to no match terms and can never trigger");
      valid = false;
    }
    if (prepared.rewrite_terms.empty()) {
      add_issue(result, RewriteValidationSeverity::error,
                RewriteValidationCode::empty_rewrite_terms, {prepared.rule_index},
                format_rule_index(prepared.rule_index) +
                    " analyzes to no rewrite terms and would produce no output");
      valid = false;
    }
    if (!valid) {
      continue;
    }

    if (prepared.definition.kind == RewriteKind::canonical &&
        prepared.match_terms == prepared.rewrite_terms) {
      add_issue(result, RewriteValidationSeverity::warning,
                RewriteValidationCode::no_op_canonical_rule, {prepared.rule_index},
                format_rule_index(prepared.rule_index) +
                    " is a no-op after analysis and has no effect");
    }

    prepared_rewrites.push_back(prepared);
  }

  std::unordered_map<std::string, std::vector<const detail::PreparedRewrite*>> canonical_groups;
  for (const auto& rewrite : prepared_rewrites) {
    if (rewrite.definition.kind != RewriteKind::canonical ||
        rewrite.match_terms == rewrite.rewrite_terms) {
      continue;
    }
    canonical_groups[detail::terms_key(rewrite.match_terms)].push_back(&rewrite);
  }

  std::unordered_map<std::string, const detail::PreparedRewrite*> active_canonical;
  for (const auto& [key, group] : canonical_groups) {
    const auto* first = group.front();
    bool conflicting = false;
    std::vector<std::size_t> indices;
    indices.reserve(group.size());
    for (const auto* rewrite : group) {
      indices.push_back(rewrite->rule_index);
      if (rewrite->rewrite_terms != first->rewrite_terms) {
        conflicting = true;
      }
    }

    if (conflicting) {
      add_issue(result, RewriteValidationSeverity::error,
                RewriteValidationCode::conflicting_canonical_target, indices,
                "canonical rewrites " + format_rule_indices(indices) +
                    " share analyzed match terms '" + detail::render_terms(first->match_terms) +
                    "' but rewrite to different analyzed targets");
      continue;
    }

    if (group.size() > 1) {
      for (std::size_t index = 1; index < group.size(); ++index) {
        add_issue(result, RewriteValidationSeverity::warning,
                  RewriteValidationCode::shadowed_canonical_rule,
                  {first->rule_index, group[index]->rule_index},
                  format_rule_index(group[index]->rule_index) +
                      " is shadowed by earlier canonical " +
                      format_rule_index(first->rule_index));
      }
    }

    active_canonical[key] = first;
  }

  std::unordered_map<std::string, int> state;
  std::vector<std::string> stack_keys;
  std::vector<const detail::PreparedRewrite*> stack_rewrites;
  std::unordered_set<std::string> reported_cycles;

  std::function<void(const std::string&)> visit = [&](const std::string& key) {
    state[key] = 1;
    stack_keys.push_back(key);
    stack_rewrites.push_back(active_canonical.at(key));

    const auto next_key = detail::terms_key(active_canonical.at(key)->rewrite_terms);
    if (const auto next = active_canonical.find(next_key); next != active_canonical.end()) {
      if (state[next_key] == 0) {
        visit(next_key);
      } else if (state[next_key] == 1) {
        auto begin = std::find(stack_keys.begin(), stack_keys.end(), next_key);
        if (begin != stack_keys.end()) {
          const auto offset =
              static_cast<std::size_t>(std::distance(stack_keys.begin(), begin));
          std::vector<std::size_t> cycle_indices;
          for (std::size_t index = offset; index < stack_rewrites.size(); ++index) {
            cycle_indices.push_back(stack_rewrites[index]->rule_index);
          }

          auto sorted_indices = cycle_indices;
          std::sort(sorted_indices.begin(), sorted_indices.end());
          const std::string cycle_key = format_rule_indices(sorted_indices);
          if (reported_cycles.insert(cycle_key).second) {
            add_issue(result, RewriteValidationSeverity::error,
                      RewriteValidationCode::canonical_cycle, sorted_indices,
                      "canonical rewrites " + format_rule_indices(sorted_indices) +
                          " form a cycle");
          }
        }
      }
    }

    stack_keys.pop_back();
    stack_rewrites.pop_back();
    state[key] = 2;
  };

  for (const auto& entry : active_canonical) {
    const auto& key = entry.first;
    if (state[key] == 0) {
      visit(key);
    }
  }

  std::unordered_map<std::string, std::vector<const detail::PreparedRewrite*>>
      exact_alternative_groups;
  std::unordered_map<std::string, std::vector<const detail::PreparedRewrite*>>
      deduplicated_alternative_groups;

  for (const auto& rewrite : prepared_rewrites) {
    if (rewrite.definition.kind == RewriteKind::canonical) {
      continue;
    }

    exact_alternative_groups[exact_alternative_key(rewrite)].push_back(&rewrite);

    if (options.deduplicate_alternatives) {
      if (rewrite.match_terms == rewrite.rewrite_terms) {
        add_issue(result, RewriteValidationSeverity::warning,
                  RewriteValidationCode::shadowed_alternative_rule, {rewrite.rule_index},
                  format_rule_index(rewrite.rule_index) +
                      " rewrites to the same analyzed terms and is suppressed by deduplication");
      }
      deduplicated_alternative_groups[alternative_key(rewrite.match_terms, rewrite.rewrite_terms)]
          .push_back(&rewrite);
    }
  }

  for (const auto& [_, group] : exact_alternative_groups) {
    if (group.size() <= 1) {
      continue;
    }
    std::vector<std::size_t> indices;
    indices.reserve(group.size());
    for (const auto* rewrite : group) {
      indices.push_back(rewrite->rule_index);
    }
    add_issue(result, RewriteValidationSeverity::warning,
              RewriteValidationCode::duplicate_alternative_rule, indices,
              "alternative rewrites " + format_rule_indices(indices) +
                  " are exact analyzed duplicates");
  }

  if (options.deduplicate_alternatives) {
    for (const auto& [_, group] : deduplicated_alternative_groups) {
      if (group.size() <= 1) {
        continue;
      }

      bool mixed_kinds = false;
      const auto first_kind = group.front()->definition.kind;
      for (const auto* rewrite : group) {
        if (rewrite->definition.kind != first_kind) {
          mixed_kinds = true;
          break;
        }
      }

      if (!mixed_kinds) {
        continue;
      }

      std::vector<std::size_t> indices;
      indices.reserve(group.size());
      for (const auto* rewrite : group) {
        indices.push_back(rewrite->rule_index);
      }
      add_issue(result, RewriteValidationSeverity::warning,
                RewriteValidationCode::shadowed_alternative_rule, indices,
                "alternative rewrites " + format_rule_indices(indices) +
                    " collapse to one analyzed alternative when deduplication is enabled");
    }
  }

  return result;
}

}  // namespace termflow::query
