#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "termflow/analysis/analyzer.hpp"
#include "termflow/query/query_types.hpp"

namespace termflow::query::detail {

struct PreparedRewrite {
  std::size_t rule_index{};
  RewriteDefinition definition;
  std::vector<std::string> match_terms;
  std::vector<std::string> rewrite_terms;
};

inline PreparedRewrite prepare_rewrite(const termflow::Analyzer& analyzer,
                                       const RewriteDefinition& definition,
                                       std::size_t rule_index) {
  PreparedRewrite prepared;
  prepared.rule_index = rule_index;
  prepared.definition = definition;
  prepared.match_terms = analyzer.analyze_terms(definition.match);
  prepared.rewrite_terms = analyzer.analyze_terms(definition.rewrite);
  return prepared;
}

inline std::string terms_key(const std::vector<std::string>& terms) {
  std::string key;
  for (const auto& term : terms) {
    key.push_back('\x1f');
    key.append(term);
  }
  return key;
}

inline std::string render_terms(const std::vector<std::string>& terms) {
  std::string text;
  for (std::size_t index = 0; index < terms.size(); ++index) {
    if (index > 0) {
      text.push_back(' ');
    }
    text.append(terms[index]);
  }
  return text;
}

}  // namespace termflow::query::detail
