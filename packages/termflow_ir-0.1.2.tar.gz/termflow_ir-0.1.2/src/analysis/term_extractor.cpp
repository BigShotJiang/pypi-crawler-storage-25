#include "termflow/analysis/term_extractor.hpp"

#include <algorithm>
#include <stdexcept>
#include <utility>

#include <unicode/stringpiece.h>
#include <unicode/unistr.h>
#include <unicode/uchar.h>

namespace termflow {

namespace {

icu::UnicodeString to_unicode_string(std::string_view input) {
  icu::StringPiece piece(input.data(), static_cast<int32_t>(input.size()));
  return icu::UnicodeString::fromUTF8(piece);
}

bool is_ascii_alphabetic(std::string_view term) {
  return !term.empty() &&
         std::all_of(term.begin(), term.end(), [](unsigned char character) {
           return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z');
         });
}

bool is_unicode_alphabetic(std::string_view term) {
  if (term.empty()) {
    return false;
  }

  const icu::UnicodeString value = to_unicode_string(term);
  for (int32_t offset = 0; offset < value.length();) {
    const UChar32 code_point = value.char32At(offset);
    if (!u_isalpha(code_point)) {
      return false;
    }
    offset += U16_LENGTH(code_point);
  }
  return true;
}

bool is_unicode_numeric(std::string_view term) {
  if (term.empty()) {
    return false;
  }

  const icu::UnicodeString value = to_unicode_string(term);
  for (int32_t offset = 0; offset < value.length();) {
    const UChar32 code_point = value.char32At(offset);
    if (!u_isdigit(code_point)) {
      return false;
    }
    offset += U16_LENGTH(code_point);
  }
  return true;
}

std::size_t utf8_code_point_length(std::string_view term) {
  return static_cast<std::size_t>(to_unicode_string(term).countChar32());
}

std::string join_terms(const std::vector<std::string>& terms, std::string_view separator) {
  if (terms.empty()) {
    return {};
  }

  std::size_t output_size = 0;
  for (const auto& term : terms) {
    output_size += term.size();
  }
  output_size += separator.size() * (terms.size() - 1);

  std::string joined;
  joined.reserve(output_size);
  for (std::size_t index = 0; index < terms.size(); ++index) {
    if (index > 0) {
      joined.append(separator);
    }
    joined.append(terms[index]);
  }
  return joined;
}

}  // namespace

TermExtractor::TermExtractor(const Analyzer& analyzer, TermExtractionOptions options)
    : analyzer_(&analyzer), options_(std::move(options)) {
  if (options_.min_term_length == 0) {
    throw std::invalid_argument("term extractor min_term_length must be greater than zero");
  }
}

std::vector<std::string> TermExtractor::extract(std::string_view text) const {
  return extract(analyzer_->analyze(text));
}

std::optional<std::string> TermExtractor::extract_one(std::string_view text) const {
  return extract_one(analyzer_->analyze(text));
}

std::string TermExtractor::extract_joined(std::string_view text, std::string_view separator) const {
  return join_terms(extract(text), separator);
}

std::vector<std::string> TermExtractor::extract(const std::vector<Token>& tokens) const {
  std::vector<std::string> terms;
  terms.reserve(tokens.size());

  for (const auto& token : tokens) {
    if (keep_term(token.text)) {
      terms.push_back(token.text);
    }
  }

  return terms;
}

std::optional<std::string> TermExtractor::extract_one(const std::vector<Token>& tokens) const {
  for (const auto& token : tokens) {
    if (keep_term(token.text)) {
      return token.text;
    }
  }
  return std::nullopt;
}

bool TermExtractor::keep_term(std::string_view term) const {
  if (utf8_code_point_length(term) < options_.min_term_length) {
    return false;
  }

  if (!options_.keep_numeric_terms && is_unicode_numeric(term)) {
    return false;
  }

  switch (options_.character_policy) {
    case TermCharacterPolicy::any:
      return true;
    case TermCharacterPolicy::alphabetic:
      return is_unicode_alphabetic(term);
    case TermCharacterPolicy::ascii_alphabetic:
      return is_ascii_alphabetic(term);
  }

  return true;
}

}  // namespace termflow
