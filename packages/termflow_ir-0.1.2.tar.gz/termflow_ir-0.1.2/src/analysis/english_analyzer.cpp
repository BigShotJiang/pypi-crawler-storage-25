#include "termflow/analysis/english_analyzer.hpp"

#include <utility>

#include "util/unicode.hpp"

namespace termflow {

namespace {

std::unordered_set<std::string> resolve_stop_words(const EnglishAnalyzerOptions& options) {
  if (!options.stop_filter) {
    return {};
  }

  if (options.use_default_stop_words) {
    return EnglishAnalyzer::default_stop_words();
  }
  return options.stop_words;
}

std::unordered_set<std::string> normalize_pre_stem_set(std::unordered_set<std::string> values,
                                                       const EnglishAnalyzerOptions& options) {
  std::unordered_set<std::string> normalized;
  normalized.reserve(values.size());
  for (const auto& value : values) {
    normalized.insert(detail::normalize_english_token_utf8(
        value, options.unicode_normalization, options.english_possessive, options.lowercase));
  }
  return normalized;
}

}  // namespace

EnglishAnalyzer::EnglishAnalyzer() : EnglishAnalyzer(EnglishAnalyzerOptions{}) {}

EnglishAnalyzer::EnglishAnalyzer(EnglishAnalyzerOptions options)
    : unicode_normalization_(options.unicode_normalization),
      lowercase_(options.lowercase),
      english_possessive_(options.english_possessive),
      stemming_(options.stemming),
      ascii_folding_(options.ascii_folding),
      stop_filter_(normalize_pre_stem_set(resolve_stop_words(options), options)),
      stem_exclusion_set_(normalize_pre_stem_set(std::move(options.stem_exclusion_set), options)) {}

const std::unordered_set<std::string>& EnglishAnalyzer::default_stop_words() {
  static const std::unordered_set<std::string> stop_words = {
      "a",     "an",    "and",   "are",   "as",    "at",   "be",   "but", "by",
      "for",   "if",    "in",    "into",  "is",    "it",   "no",   "not", "of",
      "on",    "or",    "such",  "that",  "the",   "their","then", "there",
      "these", "they",  "this",  "to",    "was",   "will", "with"};
  return stop_words;
}

std::vector<Token> EnglishAnalyzer::create_tokens(std::string_view text) const {
  return tokenizer_.tokenize(text);
}

void EnglishAnalyzer::apply_token_filters(std::vector<Token>& tokens) const {
  // Keep this fused pre-stem path logically equivalent to applying the public
  // UnicodeNormalizeFilter, EnglishPossessiveFilter, and LowerCaseFilter in order.
  // The analyzer tests compare this fast path against an explicitly composed
  // public-filter pipeline to keep the behaviors aligned over time.
  for (auto& token : tokens) {
    token.text = detail::normalize_english_token_utf8(token.text, unicode_normalization_,
                                                      english_possessive_, lowercase_);
  }

  stop_filter_.apply(tokens);
  mark_keywords(tokens);
  if (stemming_) {
    porter_stem_filter_.apply(tokens);
  }
  if (ascii_folding_) {
    ascii_folding_filter_.apply(tokens);
  }
}

std::string EnglishAnalyzer::normalize_text(std::string_view text) const {
  std::string normalized(text);
  if (unicode_normalization_) {
    normalized = detail::normalize_nfkc_utf8(normalized);
  }
  if (lowercase_) {
    normalized = detail::lowercase_utf8(normalized);
  }
  if (ascii_folding_) {
    normalized = detail::ascii_fold_utf8(normalized);
  }
  return normalized;
}

void EnglishAnalyzer::mark_keywords(std::vector<Token>& tokens) const {
  if (stem_exclusion_set_.empty()) {
    return;
  }

  for (auto& token : tokens) {
    if (stem_exclusion_set_.contains(token.text)) {
      token.keyword = true;
    }
  }
}

}  // namespace termflow
