#include "termflow/analysis/standard_tokenizer.hpp"

#include <algorithm>
#include <memory>
#include <stdexcept>

#include <unicode/brkiter.h>
#include <unicode/locid.h>
#include <unicode/stringpiece.h>
#include <unicode/unistr.h>
#include <unicode/utypes.h>

namespace termflow {

namespace {

icu::UnicodeString to_unicode_string(std::string_view input) {
  icu::StringPiece piece(input.data(), static_cast<int32_t>(input.size()));
  return icu::UnicodeString::fromUTF8(piece);
}

std::string to_utf8(const icu::UnicodeString& value) {
  std::string output;
  value.toUTF8String(output);
  return output;
}

std::unique_ptr<icu::BreakIterator> make_word_iterator() {
  UErrorCode status = U_ZERO_ERROR;
  std::unique_ptr<icu::BreakIterator> iterator(
      icu::BreakIterator::createWordInstance(icu::Locale::getRoot(), status));

  if (U_FAILURE(status) || iterator == nullptr) {
    throw std::runtime_error("failed to create ICU word break iterator");
  }
  return iterator;
}

icu::BreakIterator& word_iterator() {
  thread_local std::unique_ptr<icu::BreakIterator> iterator = make_word_iterator();
  return *iterator;
}

bool is_word_token(int32_t rule_status) {
  return !(rule_status >= UBRK_WORD_NONE && rule_status < UBRK_WORD_NONE_LIMIT);
}

bool is_all_underscores(const icu::UnicodeString& value) {
  if (value.isEmpty()) {
    return false;
  }

  for (int32_t index = 0; index < value.length(); ++index) {
    if (value.charAt(index) != '_') {
      return false;
    }
  }
  return true;
}

bool contains_ascii_alpha(std::string_view value) {
  return std::any_of(value.begin(), value.end(), [](unsigned char character) {
    return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z');
  });
}

void recompute_positions(std::vector<Token>& tokens) {
  long long absolute_position = -1;
  for (auto& token : tokens) {
    absolute_position += static_cast<long long>(token.position_increment);
    token.position = absolute_position < 0 ? 0U : static_cast<std::size_t>(absolute_position);
  }
}

void merge_colon_sequences(std::vector<Token>& tokens, const icu::UnicodeString& text) {
  if (tokens.size() < 2 || text.isEmpty()) {
    return;
  }

  std::vector<Token> merged;
  merged.reserve(tokens.size());

  for (std::size_t index = 0; index < tokens.size(); ++index) {
    Token token = tokens[index];
    while (index + 1 < tokens.size()) {
      const Token& next = tokens[index + 1];
      const auto colon_offset = static_cast<int32_t>(token.end_offset);
      const auto next_start = static_cast<int32_t>(next.start_offset);

      if (colon_offset < 0 || colon_offset >= text.length() || next_start != colon_offset + 1 ||
          text.charAt(colon_offset) != ':' || !contains_ascii_alpha(token.text) ||
          !contains_ascii_alpha(next.text)) {
        break;
      }

      token.text.append(":").append(next.text);
      token.end_offset = next.end_offset;
      ++index;
    }
    merged.push_back(std::move(token));
  }

  for (std::size_t index = 0; index < merged.size(); ++index) {
    merged[index].position_increment = index == 0 ? merged[index].position_increment : 1;
  }

  tokens = std::move(merged);
  recompute_positions(tokens);
}

void split_long_tokens(std::vector<Token>& tokens, const icu::UnicodeString& text,
                       std::size_t max_token_length) {
  if (tokens.empty()) {
    return;
  }

  const auto max_length = static_cast<int32_t>(max_token_length);
  std::vector<Token> split;
  split.reserve(tokens.size());

  for (const auto& token : tokens) {
    const auto token_start = static_cast<int32_t>(token.start_offset);
    const auto token_end = static_cast<int32_t>(token.end_offset);

    if (token_end - token_start <= max_length) {
      split.push_back(token);
      continue;
    }

    bool first_chunk = true;
    for (int32_t chunk_start = token_start; chunk_start < token_end; chunk_start += max_length) {
      const int32_t chunk_end = std::min(token_end, chunk_start + max_length);

      Token chunk;
      chunk.text = to_utf8(text.tempSubStringBetween(chunk_start, chunk_end));
      chunk.start_offset = static_cast<std::size_t>(chunk_start);
      chunk.end_offset = static_cast<std::size_t>(chunk_end);
      chunk.position_increment = first_chunk ? token.position_increment : 1;
      chunk.keyword = false;
      split.push_back(std::move(chunk));
      first_chunk = false;
    }
  }

  tokens = std::move(split);
  recompute_positions(tokens);
}

}  // namespace

StandardTokenizer::StandardTokenizer(std::size_t max_token_length) {
  set_max_token_length(max_token_length);
}

void StandardTokenizer::set_max_token_length(std::size_t max_token_length) {
  if (max_token_length == 0) {
    throw std::invalid_argument("standard tokenizer max token length must be greater than zero");
  }
  max_token_length_ = max_token_length;
}

std::vector<Token> StandardTokenizer::tokenize(std::string_view input) const {
  const icu::UnicodeString text = to_unicode_string(input);
  auto& iterator = word_iterator();
  iterator.setText(text);

  std::vector<Token> tokens;
  int32_t start = iterator.first();
  for (int32_t end = iterator.next(); end != icu::BreakIterator::DONE;
       start = end, end = iterator.next()) {
    const int32_t rule_status = iterator.getRuleStatus();
    if (!is_word_token(rule_status)) {
      continue;
    }

    const icu::UnicodeString slice = text.tempSubStringBetween(start, end);
    if (slice.isEmpty()) {
      continue;
    }
    if (is_all_underscores(slice)) {
      continue;
    }

    Token token;
    token.text = to_utf8(slice);
    token.start_offset = static_cast<std::size_t>(start);
    token.end_offset = static_cast<std::size_t>(end);
    token.position = tokens.size();
    token.position_increment = 1;
    token.keyword = false;
    tokens.push_back(std::move(token));
  }

  merge_colon_sequences(tokens, text);
  split_long_tokens(tokens, text, max_token_length_);
  return tokens;
}

}  // namespace termflow
