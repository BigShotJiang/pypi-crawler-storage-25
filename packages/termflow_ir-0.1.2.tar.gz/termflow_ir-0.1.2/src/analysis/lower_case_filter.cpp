#include "termflow/analysis/lower_case_filter.hpp"

#include "util/unicode.hpp"

namespace termflow {

void LowerCaseFilter::apply(std::vector<Token>& tokens) const {
  for (auto& token : tokens) {
    token.text = detail::lowercase_utf8(token.text);
  }
}

}  // namespace termflow
