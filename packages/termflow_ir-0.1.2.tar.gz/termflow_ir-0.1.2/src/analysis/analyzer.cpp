#include "termflow/analysis/analyzer.hpp"

namespace termflow {

std::vector<Token> Analyzer::analyze(std::string_view text) const {
  std::string filtered = apply_char_filters(text);
  std::vector<Token> tokens = create_tokens(filtered);
  apply_token_filters(tokens);
  recompute_positions(tokens);
  return tokens;
}

std::vector<std::string> Analyzer::analyze_terms(std::string_view text) const {
  const std::vector<Token> tokens = analyze(text);

  std::vector<std::string> terms;
  terms.reserve(tokens.size());
  for (const auto& token : tokens) {
    terms.push_back(token.text);
  }
  return terms;
}

std::optional<std::string> Analyzer::analyze_term(std::string_view text) const {
  std::vector<Token> tokens = analyze(text);
  if (tokens.empty()) {
    return std::nullopt;
  }
  return tokens.front().text;
}

std::string Analyzer::analyze_to_string(std::string_view text, std::string_view separator) const {
  const std::vector<std::string> terms = analyze_terms(text);
  if (terms.empty()) {
    return {};
  }

  std::size_t output_size = 0;
  for (const auto& term : terms) {
    output_size += term.size();
  }
  output_size += separator.size() * (terms.size() - 1);

  std::string joined;
  joined.reserve(output_size);
  for (std::size_t index = 0; index < terms.size(); ++index) {
    if (index > 0) {
      joined.append(separator);
    }
    joined.append(terms[index]);
  }
  return joined;
}

std::string Analyzer::normalize(std::string_view text) const {
  return normalize_text(apply_char_filters(text));
}

std::string Analyzer::apply_char_filters(std::string_view text) const {
  return std::string(text);
}

void Analyzer::recompute_positions(std::vector<Token>& tokens) {
  long long position = -1;
  for (auto& token : tokens) {
    position += static_cast<long long>(token.position_increment);
    token.position = position < 0 ? 0U : static_cast<std::size_t>(position);
  }
}

}  // namespace termflow
