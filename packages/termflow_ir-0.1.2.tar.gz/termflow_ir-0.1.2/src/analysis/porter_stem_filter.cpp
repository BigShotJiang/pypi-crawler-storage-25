#include "termflow/analysis/porter_stem_filter.hpp"

#include "util/porter_stemmer.hpp"

namespace termflow {

void PorterStemFilter::apply(std::vector<Token>& tokens) const {
  for (auto& token : tokens) {
    if (!token.keyword) {
      token.text = detail::porter_stem(token.text);
    }
  }
}

}  // namespace termflow
