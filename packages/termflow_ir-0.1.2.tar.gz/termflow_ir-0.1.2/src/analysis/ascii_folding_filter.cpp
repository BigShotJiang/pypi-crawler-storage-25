#include "termflow/analysis/ascii_folding_filter.hpp"

#include "util/unicode.hpp"

namespace termflow {

void AsciiFoldingFilter::apply(std::vector<Token>& tokens) const {
  for (auto& token : tokens) {
    token.text = detail::ascii_fold_utf8(token.text);
  }
}

}  // namespace termflow
