#include "termflow/analysis/stop_filter.hpp"

namespace termflow {

StopFilter::StopFilter(std::unordered_set<std::string> stop_words)
    : stop_words_(std::move(stop_words)) {}

const std::unordered_set<std::string>& StopFilter::stop_words() const noexcept {
  return stop_words_;
}

void StopFilter::apply(std::vector<Token>& tokens) const {
  if (stop_words_.empty()) {
    return;
  }

  std::vector<Token> filtered;
  filtered.reserve(tokens.size());

  std::size_t skipped_position_increment = 0;
  long long absolute_position = -1;

  for (auto token : tokens) {
    if (stop_words_.contains(token.text)) {
      skipped_position_increment += token.position_increment;
      continue;
    }

    token.position_increment += skipped_position_increment;
    skipped_position_increment = 0;
    absolute_position += static_cast<long long>(token.position_increment);
    token.position = absolute_position < 0 ? 0U : static_cast<std::size_t>(absolute_position);
    filtered.push_back(std::move(token));
  }

  tokens = std::move(filtered);
}

}  // namespace termflow
