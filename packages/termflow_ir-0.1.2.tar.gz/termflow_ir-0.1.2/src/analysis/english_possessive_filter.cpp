#include "termflow/analysis/english_possessive_filter.hpp"

#include "util/unicode.hpp"

namespace termflow {

void EnglishPossessiveFilter::apply(std::vector<Token>& tokens) const {
  for (auto& token : tokens) {
    token.text = detail::strip_english_possessive_suffix(token.text);
  }
}

}  // namespace termflow
