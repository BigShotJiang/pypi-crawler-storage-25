#include "termflow/analysis/unicode_normalize_filter.hpp"

#include "util/unicode.hpp"

namespace termflow {

void UnicodeNormalizeFilter::apply(std::vector<Token>& tokens) const {
  for (auto& token : tokens) {
    token.text = detail::normalize_nfkc_utf8(token.text);
  }
}

}  // namespace termflow
