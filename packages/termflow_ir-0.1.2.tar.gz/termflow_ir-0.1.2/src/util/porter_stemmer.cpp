#include "util/porter_stemmer.hpp"

#include <algorithm>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>

namespace termflow::detail {

namespace {

class PorterStemmer {
 public:
  PorterStemmer() : buffer_(kIncrement) {}

  void reset() {
    i_ = 0;
    dirty_ = false;
  }

  void add(char character) {
    if (static_cast<int>(buffer_.size()) <= i_ + kExtra) {
      buffer_.resize(buffer_.size() + kIncrement);
    }
    buffer_[i_++] = character;
  }

  [[nodiscard]] std::string to_string() const {
    return std::string(buffer_.data(), static_cast<std::size_t>(i_));
  }

  [[nodiscard]] int result_length() const {
    return i_;
  }

  [[nodiscard]] const char* result_buffer() const {
    return buffer_.data();
  }

  [[nodiscard]] std::string stem(std::string_view input) {
    if (stem(input.data(), 0, static_cast<int>(input.size()))) {
      return to_string();
    }
    return std::string(input);
  }

  bool stem(const char* word, int word_length) {
    return stem(word, 0, word_length);
  }

  bool stem(const char* word_buffer, int offset, int word_length) {
    reset();
    if (word_length <= 0) {
      return false;
    }
    if (static_cast<int>(buffer_.size()) < word_length + kExtra) {
      buffer_.resize(static_cast<std::size_t>(word_length + kExtra));
    }

    std::memcpy(buffer_.data(), word_buffer + offset, static_cast<std::size_t>(word_length));
    i_ = word_length;
    return stem(0);
  }

  bool stem() {
    return stem(0);
  }

  bool stem(int i0) {
    k_ = i_ - 1;
    k0_ = i0;
    if (k_ > k0_ + 1) {
      step1();
      step2();
      step3();
      step4();
      step5();
      step6();
    }

    if (i_ != k_ + 1) {
      dirty_ = true;
    }
    i_ = k_ + 1;
    return dirty_;
  }

 private:
  [[nodiscard]] bool cons(int index) const {
    switch (buffer_[index]) {
      case 'a':
      case 'e':
      case 'i':
      case 'o':
      case 'u':
        return false;
      case 'y':
        return index == k0_ ? true : !cons(index - 1);
      default:
        return true;
    }
  }

  [[nodiscard]] int m() const {
    int count = 0;
    int index = k0_;
    while (true) {
      if (index > j_) {
        return count;
      }
      if (!cons(index)) {
        break;
      }
      ++index;
    }
    ++index;
    while (true) {
      while (true) {
        if (index > j_) {
          return count;
        }
        if (cons(index)) {
          break;
        }
        ++index;
      }
      ++index;
      ++count;
      while (true) {
        if (index > j_) {
          return count;
        }
        if (!cons(index)) {
          break;
        }
        ++index;
      }
      ++index;
    }
  }

  [[nodiscard]] bool vowel_in_stem() const {
    for (int index = k0_; index <= j_; ++index) {
      if (!cons(index)) {
        return true;
      }
    }
    return false;
  }

  [[nodiscard]] bool doublec(int index) const {
    if (index < k0_ + 1) {
      return false;
    }
    if (buffer_[index] != buffer_[index - 1]) {
      return false;
    }
    return cons(index);
  }

  [[nodiscard]] bool cvc(int index) const {
    if (index < k0_ + 2 || !cons(index) || cons(index - 1) || !cons(index - 2)) {
      return false;
    }

    const int character = buffer_[index];
    if (character == 'w' || character == 'x' || character == 'y') {
      return false;
    }
    return true;
  }

  [[nodiscard]] bool ends(std::string_view suffix) {
    const int length = static_cast<int>(suffix.size());
    const int offset = k_ - length + 1;
    if (offset < k0_) {
      return false;
    }

    for (int index = 0; index < length; ++index) {
      if (buffer_[offset + index] != suffix[static_cast<std::size_t>(index)]) {
        return false;
      }
    }
    j_ = k_ - length;
    return true;
  }

  void setto(std::string_view suffix) {
    const int length = static_cast<int>(suffix.size());
    const int offset = j_ + 1;
    for (int index = 0; index < length; ++index) {
      buffer_[offset + index] = suffix[static_cast<std::size_t>(index)];
    }
    k_ = j_ + length;
    dirty_ = true;
  }

  void r(std::string_view suffix) {
    if (m() > 0) {
      setto(suffix);
    }
  }

  void step1() {
    if (buffer_[k_] == 's') {
      if (ends("sses")) {
        k_ -= 2;
      } else if (ends("ies")) {
        setto("i");
      } else if (buffer_[k_ - 1] != 's') {
        --k_;
      }
    }

    if (ends("eed")) {
      if (m() > 0) {
        --k_;
      }
    } else if ((ends("ed") || ends("ing")) && vowel_in_stem()) {
      k_ = j_;
      if (ends("at")) {
        setto("ate");
      } else if (ends("bl")) {
        setto("ble");
      } else if (ends("iz")) {
        setto("ize");
      } else if (doublec(k_)) {
        const int character = buffer_[k_--];
        if (character == 'l' || character == 's' || character == 'z') {
          ++k_;
        }
      } else if (m() == 1 && cvc(k_)) {
        setto("e");
      }
    }
  }

  void step2() {
    if (ends("y") && vowel_in_stem()) {
      buffer_[k_] = 'i';
      dirty_ = true;
    }
  }

  void step3() {
    if (k_ == k0_) {
      return;
    }

    switch (buffer_[k_ - 1]) {
      case 'a':
        if (ends("ational")) {
          r("ate");
          break;
        }
        if (ends("tional")) {
          r("tion");
          break;
        }
        break;
      case 'c':
        if (ends("enci")) {
          r("ence");
          break;
        }
        if (ends("anci")) {
          r("ance");
          break;
        }
        break;
      case 'e':
        if (ends("izer")) {
          r("ize");
          break;
        }
        break;
      case 'l':
        if (ends("bli")) {
          r("ble");
          break;
        }
        if (ends("alli")) {
          r("al");
          break;
        }
        if (ends("entli")) {
          r("ent");
          break;
        }
        if (ends("eli")) {
          r("e");
          break;
        }
        if (ends("ousli")) {
          r("ous");
          break;
        }
        break;
      case 'o':
        if (ends("ization")) {
          r("ize");
          break;
        }
        if (ends("ation")) {
          r("ate");
          break;
        }
        if (ends("ator")) {
          r("ate");
          break;
        }
        break;
      case 's':
        if (ends("alism")) {
          r("al");
          break;
        }
        if (ends("iveness")) {
          r("ive");
          break;
        }
        if (ends("fulness")) {
          r("ful");
          break;
        }
        if (ends("ousness")) {
          r("ous");
          break;
        }
        break;
      case 't':
        if (ends("aliti")) {
          r("al");
          break;
        }
        if (ends("iviti")) {
          r("ive");
          break;
        }
        if (ends("biliti")) {
          r("ble");
          break;
        }
        break;
      case 'g':
        if (ends("logi")) {
          r("log");
          break;
        }
        break;
      default:
        break;
    }
  }

  void step4() {
    switch (buffer_[k_]) {
      case 'e':
        if (ends("icate")) {
          r("ic");
          break;
        }
        if (ends("ative")) {
          r("");
          break;
        }
        if (ends("alize")) {
          r("al");
          break;
        }
        break;
      case 'i':
        if (ends("iciti")) {
          r("ic");
          break;
        }
        break;
      case 'l':
        if (ends("ical")) {
          r("ic");
          break;
        }
        if (ends("ful")) {
          r("");
          break;
        }
        break;
      case 's':
        if (ends("ness")) {
          r("");
          break;
        }
        break;
      default:
        break;
    }
  }

  void step5() {
    if (k_ == k0_) {
      return;
    }

    switch (buffer_[k_ - 1]) {
      case 'a':
        if (ends("al")) {
          break;
        }
        return;
      case 'c':
        if (ends("ance")) {
          break;
        }
        if (ends("ence")) {
          break;
        }
        return;
      case 'e':
        if (ends("er")) {
          break;
        }
        return;
      case 'i':
        if (ends("ic")) {
          break;
        }
        return;
      case 'l':
        if (ends("able")) {
          break;
        }
        if (ends("ible")) {
          break;
        }
        return;
      case 'n':
        if (ends("ant")) {
          break;
        }
        if (ends("ement")) {
          break;
        }
        if (ends("ment")) {
          break;
        }
        if (ends("ent")) {
          break;
        }
        return;
      case 'o':
        if (ends("ion") && j_ >= 0 && (buffer_[j_] == 's' || buffer_[j_] == 't')) {
          break;
        }
        if (ends("ou")) {
          break;
        }
        return;
      case 's':
        if (ends("ism")) {
          break;
        }
        return;
      case 't':
        if (ends("ate")) {
          break;
        }
        if (ends("iti")) {
          break;
        }
        return;
      case 'u':
        if (ends("ous")) {
          break;
        }
        return;
      case 'v':
        if (ends("ive")) {
          break;
        }
        return;
      case 'z':
        if (ends("ize")) {
          break;
        }
        return;
      default:
        return;
    }

    if (m() > 1) {
      k_ = j_;
    }
  }

  void step6() {
    j_ = k_;
    if (buffer_[k_] == 'e') {
      const int measure = m();
      if (measure > 1 || (measure == 1 && !cvc(k_ - 1))) {
        --k_;
      }
    }
    if (buffer_[k_] == 'l' && doublec(k_) && m() > 1) {
      --k_;
    }
  }

  static constexpr int kIncrement = 50;
  static constexpr int kExtra = 1;

  std::vector<char> buffer_;
  int i_{0};
  int j_{0};
  int k_{0};
  int k0_{0};
  bool dirty_{false};
};

}  // namespace

std::string porter_stem(std::string_view input) {
  if (input.empty()) {
    return {};
  }
  PorterStemmer stemmer;
  return stemmer.stem(input);
}

}  // namespace termflow::detail
