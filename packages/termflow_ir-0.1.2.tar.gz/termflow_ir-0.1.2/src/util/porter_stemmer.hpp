#pragma once

#include <string>
#include <string_view>

namespace termflow::detail {

[[nodiscard]] std::string porter_stem(std::string_view input);

}  // namespace termflow::detail
