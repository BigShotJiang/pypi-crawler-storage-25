#pragma once

#include <string>
#include <string_view>

namespace termflow::detail {

[[nodiscard]] std::string ascii_fold_utf8(std::string_view input);
[[nodiscard]] std::string lowercase_utf8(std::string_view input);
[[nodiscard]] std::string normalize_english_token_utf8(std::string_view input,
                                                       bool unicode_normalization,
                                                       bool english_possessive,
                                                       bool lowercase);
[[nodiscard]] std::string normalize_nfkc_utf8(std::string_view input);
[[nodiscard]] std::string strip_english_possessive_suffix(std::string_view input);

}  // namespace termflow::detail
