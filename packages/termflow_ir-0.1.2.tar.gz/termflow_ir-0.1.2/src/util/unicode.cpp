#include "util/unicode.hpp"

#include <algorithm>
#include <memory>
#include <stdexcept>

#include <unicode/locid.h>
#include <unicode/normalizer2.h>
#include <unicode/parseerr.h>
#include <unicode/stringpiece.h>
#include <unicode/translit.h>
#include <unicode/unistr.h>
#include <unicode/utypes.h>

namespace termflow::detail {

namespace {

icu::UnicodeString to_unicode_string(std::string_view input) {
  icu::StringPiece piece(input.data(), static_cast<int32_t>(input.size()));
  return icu::UnicodeString::fromUTF8(piece);
}

std::string to_utf8(const icu::UnicodeString& value) {
  std::string output;
  value.toUTF8String(output);
  return output;
}

const icu::Normalizer2* nfkc_normalizer() {
  UErrorCode status = U_ZERO_ERROR;
  const icu::Normalizer2* normalizer =
      icu::Normalizer2::getInstance(nullptr, "nfkc", UNORM2_COMPOSE, status);
  if (U_FAILURE(status) || normalizer == nullptr) {
    throw std::runtime_error("failed to load ICU NFKC normalizer");
  }
  return normalizer;
}

std::unique_ptr<icu::Transliterator> make_ascii_transliterator() {
  UErrorCode status = U_ZERO_ERROR;
  UParseError parse_error;
  std::unique_ptr<icu::Transliterator> transliterator(
      icu::Transliterator::createInstance(
          icu::UnicodeString::fromUTF8("NFKD; [:Nonspacing Mark:] Remove; Latin-ASCII; NFC"),
          UTRANS_FORWARD,
          parse_error,
          status));

  if (U_FAILURE(status) || transliterator == nullptr) {
    throw std::runtime_error("failed to create ICU ASCII folding transliterator");
  }

  return transliterator;
}

bool is_apostrophe(UChar32 code_point) {
  return code_point == 0x0027 || code_point == 0x2019 || code_point == 0xFF07;
}

bool is_ascii(std::string_view input) {
  return std::all_of(input.begin(), input.end(),
                     [](unsigned char character) { return character <= 0x7F; });
}

}  // namespace

std::string normalize_nfkc_utf8(std::string_view input) {
  if (is_ascii(input)) {
    return std::string(input);
  }

  UErrorCode status = U_ZERO_ERROR;
  icu::UnicodeString normalized;
  nfkc_normalizer()->normalize(to_unicode_string(input), normalized, status);
  if (U_FAILURE(status)) {
    throw std::runtime_error("failed to normalize UTF-8 text with ICU");
  }
  return to_utf8(normalized);
}

std::string lowercase_utf8(std::string_view input) {
  if (is_ascii(input)) {
    std::string lowered(input);
    for (char& character : lowered) {
      if (character >= 'A' && character <= 'Z') {
        character = static_cast<char>(character - 'A' + 'a');
      }
    }
    return lowered;
  }

  icu::UnicodeString lowered = to_unicode_string(input);
  lowered.toLower(icu::Locale::getRoot());
  return to_utf8(lowered);
}

std::string normalize_english_token_utf8(std::string_view input, bool unicode_normalization,
                                         bool english_possessive, bool lowercase) {
  if (!unicode_normalization && !english_possessive && !lowercase) {
    return std::string(input);
  }

  if (is_ascii(input)) {
    std::string normalized(input);
    if (english_possessive && normalized.size() >= 2) {
      const char last = normalized[normalized.size() - 1];
      const char before_last = normalized[normalized.size() - 2];
      if ((last == 's' || last == 'S') && before_last == '\'') {
        normalized.resize(normalized.size() - 2);
      }
    }

    if (lowercase) {
      for (char& character : normalized) {
        if (character >= 'A' && character <= 'Z') {
          character = static_cast<char>(character - 'A' + 'a');
        }
      }
    }
    return normalized;
  }

  icu::UnicodeString normalized;
  if (unicode_normalization) {
    UErrorCode status = U_ZERO_ERROR;
    nfkc_normalizer()->normalize(to_unicode_string(input), normalized, status);
    if (U_FAILURE(status)) {
      throw std::runtime_error("failed to normalize UTF-8 text with ICU");
    }
  } else {
    normalized = to_unicode_string(input);
  }

  const int32_t length = normalized.length();
  if (english_possessive && length >= 2) {
    const UChar32 last = normalized.char32At(length - 1);
    const UChar32 before_last = normalized.char32At(length - 2);
    if ((last == 's' || last == 'S') && is_apostrophe(before_last)) {
      normalized.truncate(length - 2);
    }
  }

  if (lowercase) {
    normalized.toLower(icu::Locale::getRoot());
  }
  return to_utf8(normalized);
}

std::string ascii_fold_utf8(std::string_view input) {
  if (is_ascii(input)) {
    return std::string(input);
  }

  icu::UnicodeString folded = to_unicode_string(input);
  auto transliterator = make_ascii_transliterator();
  transliterator->transliterate(folded);
  return to_utf8(folded);
}

std::string strip_english_possessive_suffix(std::string_view input) {
  if (input.size() < 2) {
    return std::string(input);
  }

  if (is_ascii(input)) {
    const char last = input[input.size() - 1];
    const char before_last = input[input.size() - 2];
    if ((last == 's' || last == 'S') && before_last == '\'') {
      return std::string(input.substr(0, input.size() - 2));
    }
    return std::string(input);
  }

  icu::UnicodeString value = to_unicode_string(input);
  const int32_t length = value.length();
  if (length < 2) {
    return std::string(input);
  }

  const UChar32 last = value.char32At(length - 1);
  const UChar32 before_last = value.char32At(length - 2);
  if ((last == 's' || last == 'S') && is_apostrophe(before_last)) {
    value.truncate(length - 2);
  }

  return to_utf8(value);
}

}  // namespace termflow::detail
