import sys as _sys

from . import _termflow as _native
from ._termflow import (
    ALPHABETIC,
    ANY,
    ASCII_ALPHABETIC,
    Analyzer,
    EnglishAnalyzer,
    EnglishAnalyzerOptions,
    TermCharacterPolicy,
    TermExtractionOptions,
    TermExtractor,
    Token,
)

query = _native.query
_sys.modules[__name__ + ".query"] = query

__all__ = [
    "ALPHABETIC",
    "ANY",
    "ASCII_ALPHABETIC",
    "Analyzer",
    "EnglishAnalyzer",
    "EnglishAnalyzerOptions",
    "TermCharacterPolicy",
    "TermExtractionOptions",
    "TermExtractor",
    "Token",
    "query",
]
