from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Sequence

import termflow


_CHARACTER_POLICIES = {
    "any": termflow.TermCharacterPolicy.ANY,
    "alphabetic": termflow.TermCharacterPolicy.ALPHABETIC,
    "ascii-alphabetic": termflow.TermCharacterPolicy.ASCII_ALPHABETIC,
}

_OCCUR_NAMES = {
    termflow.query.ClauseOccur.SHOULD: "should",
    termflow.query.ClauseOccur.MUST: "must",
    termflow.query.ClauseOccur.MUST_NOT: "must_not",
}

_REWRITE_NAMES = {
    termflow.query.RewriteKind.CANONICAL: "canonical",
    termflow.query.RewriteKind.EQUIVALENT: "equivalent",
    termflow.query.RewriteKind.EXPANSION: "expansion",
}


def _read_text(text: str | None) -> str:
    if text is not None:
        return text
    return sys.stdin.read()


def _build_analyzer(no_default_stop_words: bool) -> termflow.EnglishAnalyzer:
    if not no_default_stop_words:
        return termflow.EnglishAnalyzer()

    options = termflow.EnglishAnalyzerOptions()
    options.use_default_stop_words = False
    return termflow.EnglishAnalyzer(options)


def _token_to_dict(token: termflow.Token) -> dict[str, Any]:
    return {
        "text": token.text,
        "start_offset": token.start_offset,
        "end_offset": token.end_offset,
        "position": token.position,
        "position_increment": token.position_increment,
        "keyword": token.keyword,
    }


def _alternative_to_dict(alternative: Any) -> dict[str, Any]:
    return {
        "kind": _REWRITE_NAMES[alternative.kind],
        "terms": list(alternative.terms),
    }


def _clause_to_dict(clause: Any) -> dict[str, Any]:
    return {
        "occur": _OCCUR_NAMES[clause.occur],
        "quoted": clause.quoted,
        "text": clause.text,
        "terms": list(clause.terms),
        "alternatives": [_alternative_to_dict(alternative) for alternative in clause.alternatives],
    }


def _print_json(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def _format_terms(terms: Sequence[str]) -> str:
    return json.dumps(list(terms), ensure_ascii=False)


def _handle_analyze(args: argparse.Namespace) -> int:
    text = _read_text(args.text)
    analyzer = _build_analyzer(args.no_default_stop_words)
    tokens = analyzer.analyze(text)
    payload = {
        "text": text,
        "normalized": analyzer.normalize(text),
        "terms": analyzer.analyze_terms(text),
        "tokens": [_token_to_dict(token) for token in tokens],
    }

    if args.json:
        _print_json(payload)
        return 0

    print(f"normalized: {payload['normalized']}")
    print(f"terms: {_format_terms(payload['terms'])}")
    print("tokens:")
    for token in payload["tokens"]:
        print(
            "  - "
            f"text={token['text']} "
            f"start={token['start_offset']} "
            f"end={token['end_offset']} "
            f"pos={token['position']} "
            f"pos_inc={token['position_increment']} "
            f"keyword={'true' if token['keyword'] else 'false'}"
        )
    return 0


def _handle_extract(args: argparse.Namespace) -> int:
    text = _read_text(args.text)
    analyzer = _build_analyzer(args.no_default_stop_words)
    options = termflow.TermExtractionOptions()
    options.min_term_length = args.min_term_length
    options.keep_numeric_terms = not args.drop_numeric_terms
    options.character_policy = _CHARACTER_POLICIES[args.character_policy]
    extractor = termflow.TermExtractor(analyzer, options)

    payload = {
        "text": text,
        "terms": extractor.extract(text),
    }

    if args.json:
        _print_json(payload)
        return 0

    print(f"terms: {_format_terms(payload['terms'])}")
    return 0


def _build_query_options(args: argparse.Namespace) -> Any:
    options = termflow.query.QueryAnalysisOptions()
    loader = termflow.query.RewriteLoader()

    if args.rewrites is not None:
        options.rewrites = loader.parse(args.rewrites)
    elif args.rewrites_file is not None:
        options.rewrites = loader.load_file(args.rewrites_file)

    return options


def _handle_analyze_query(args: argparse.Namespace) -> int:
    text = _read_text(args.text)
    analyzer = _build_analyzer(args.no_default_stop_words)
    query_analyzer = termflow.query.QueryAnalyzer(analyzer, _build_query_options(args))
    analyzed = query_analyzer.analyze(text)
    payload = {
        "text": analyzed.text,
        "clauses": [_clause_to_dict(clause) for clause in analyzed.clauses],
    }

    if args.json:
        _print_json(payload)
        return 0

    print(f"query: {payload['text']}")
    for clause in payload["clauses"]:
        print(
            "- "
            f"occur={clause['occur']} "
            f"quoted={'true' if clause['quoted'] else 'false'} "
            f'text="{clause["text"]}" '
            f"terms={_format_terms(clause['terms'])}"
        )
        for alternative in clause["alternatives"]:
            print(
                "  - "
                f"alternative kind={alternative['kind']} "
                f"terms={_format_terms(alternative['terms'])}"
            )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="termflow")
    subparsers = parser.add_subparsers(dest="command", required=True)

    analyze_parser = subparsers.add_parser("analyze", help="Analyze text with the built-in English analyzer.")
    analyze_parser.add_argument("text", nargs="?", help="Text to analyze. Reads stdin when omitted.")
    analyze_parser.add_argument(
        "--no-default-stop-words",
        action="store_true",
        help="Disable the built-in English stop-word set.",
    )
    analyze_parser.add_argument("--json", action="store_true", help="Print JSON output.")
    analyze_parser.set_defaults(handler=_handle_analyze)

    extract_parser = subparsers.add_parser("extract", help="Extract finalized terms from analyzed text.")
    extract_parser.add_argument("text", nargs="?", help="Text to extract terms from. Reads stdin when omitted.")
    extract_parser.add_argument(
        "--no-default-stop-words",
        action="store_true",
        help="Disable the built-in English stop-word set.",
    )
    extract_parser.add_argument(
        "--min-term-length",
        type=int,
        default=1,
        help="Minimum Unicode code-point length for extracted terms.",
    )
    extract_parser.add_argument(
        "--drop-numeric-terms",
        action="store_true",
        help="Drop terms that are entirely numeric.",
    )
    extract_parser.add_argument(
        "--character-policy",
        choices=sorted(_CHARACTER_POLICIES),
        default="any",
        help="Character policy to apply after analysis.",
    )
    extract_parser.add_argument("--json", action="store_true", help="Print JSON output.")
    extract_parser.set_defaults(handler=_handle_extract)

    query_parser = subparsers.add_parser(
        "analyze-query",
        help="Parse and analyze query clauses with the built-in English analyzer.",
    )
    query_parser.add_argument("text", nargs="?", help="Query text to analyze. Reads stdin when omitted.")
    query_parser.add_argument(
        "--no-default-stop-words",
        action="store_true",
        help="Disable the built-in English stop-word set.",
    )
    rewrite_group = query_parser.add_mutually_exclusive_group()
    rewrite_group.add_argument(
        "--rewrites",
        help="Inline rewrite definitions using the .tfq syntax.",
    )
    rewrite_group.add_argument(
        "--rewrites-file",
        help="Path to a rewrite file using the .tfq syntax.",
    )
    query_parser.add_argument("--json", action="store_true", help="Print JSON output.")
    query_parser.set_defaults(handler=_handle_analyze_query)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        return args.handler(args)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"termflow: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
