.. automodule:: nanopy.rpc
   :members:
