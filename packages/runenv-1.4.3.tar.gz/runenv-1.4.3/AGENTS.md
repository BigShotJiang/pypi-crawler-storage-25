# runenv projects
## Important files

- ROADMAP.md - used to daily work
- IMPROVEMENTS.md - to capture future improvements - needs to be also added to the ROADMAP.md
- PROBLEMS.md - to capture current problems - needs to be also added to the ROADMAP.md
- CHANGELOG.md - its a GENERATED from git log (commit.txt) do not edit
- IDEAS.md - random early stage ideas
- README.md - main documentation/description document

## Workflow
- use `uv` to test/run this project
- when i say `pick next item` then pick next not done item from ROADMAP.md, work interactivelly with me then end back consulting technical decisions, till the item is done, then mark it as done in the ROADMAP.md. then create commit.txt file with the proper but concise commit message using conventonal commits format, which i can edit and use to commit the changes.
- all changes must be BACKWARD COMPATIBLE, if not decided and confirmed by ME to be different.
- for all changes generate proper but consice tests
- do not add any comments to the code
- !IMPORTANT: keep code clean, simple and well architected, propose refactors if the code quality drifted from these requirements during adding new features or code fixes
- the CHANGELOG.md is generated from commit messages using https://github.com/onjin/mkchangelog. Make sure that commit.txt messages are suitable for `mkchangelog generate` command.
