import pytest

from runenv.parser import (
    EnvParser,
    ParseOptions,
    _json_line_numbers,
    _normalize_structured_value,
    _process_escape_sequences,
    _toml_line_numbers,
    _yaml_line_numbers,
    lint_env_file,
    parse_env_file,
    substitute_variables,
)


class TestPosixNameValidation:
    def test_dotted_key_warns(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("app.debug=1\n")
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if "POSIX" in m.message]
        assert len(warnings) == 1
        assert "app.debug" in warnings[0].message

    def test_digit_leading_key_warns(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("1FOO=bar\n")
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if "POSIX" in m.message]
        assert len(warnings) == 1

    def test_valid_key_no_warning(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("FOO=bar\n_FOO=baz\nFOO_123=qux\n")
        messages = lint_env_file(env_file, ParseOptions())
        assert not any("POSIX" in m.message for m in messages)

    def test_dotted_key_still_loaded(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("app.debug=1\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["app.debug"] == "1"

    def test_json_dotted_key_warns(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{"app.debug": "1"}')
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if "POSIX" in m.message]
        assert len(warnings) == 1

    def test_posix_warning_checked_after_prefix_strip(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("APP_foo.bar=1\n")
        messages = lint_env_file(env_file, ParseOptions(prefix="APP_", strip_prefix=True))
        warnings = [m for m in messages if "POSIX" in m.message]
        assert len(warnings) == 1
        assert "foo.bar" in warnings[0].message


class TestQuotedValues:
    def test_double_quoted_value_parsed_without_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="hello world"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "hello world"

    def test_single_quoted_value_parsed_without_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY='hello world'\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "hello world"

    def test_unquoted_value_unchanged(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=hello\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "hello"


class TestStripPrefixEqualsPrefix:
    def test_key_equal_to_prefix_is_skipped(self, tmp_path):
        env_file = tmp_path / "test.env"
        env_file.write_text("APP_=should_be_skipped\nAPP_FOO=bar\n")
        result = parse_env_file(env_file, ParseOptions(prefix="APP_", strip_prefix=True))
        assert "APP_" not in result
        assert "FOO" in result
        assert result["FOO"] == "bar"


class TestDuplicateKey:
    def test_last_value_wins(self, tmp_path):
        env_file = tmp_path / "test.env"
        env_file.write_text("TEST=3\nTEST=2\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["TEST"] == "2"

    def test_duplicate_key_warning_message(self, tmp_path):
        env_file = tmp_path / "test.env"
        env_file.write_text("TEST=3\nTEST=2\n")
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if m.level == "warning"]
        assert len(warnings) >= 1
        assert any("last value wins" in m.message for m in warnings)


class TestStructuredLoaders:
    def test_empty_json_file_raises(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text("")
        with pytest.raises(Exception):
            parse_env_file(env_file, ParseOptions())

    def test_malformed_json_raises_exception(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text("{invalid json}")
        with pytest.raises(Exception):
            parse_env_file(env_file, ParseOptions())

    def test_json_null_root_returns_empty_dict(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text("null")
        result = parse_env_file(env_file, ParseOptions())
        assert result == {}

    def test_json_list_root_raises_value_error(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text("[1,2,3]")
        with pytest.raises(ValueError, match="mapping"):
            parse_env_file(env_file, ParseOptions())

    def test_json_null_value_becomes_empty_string(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{"KEY": null}')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == ""

    def test_json_null_value_lint_warning(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{"KEY": null}')
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if m.level == "warning"]
        assert len(warnings) >= 1
        assert any("null value" in m.message for m in warnings)

    def test_json_string_value_is_unchanged(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{"HOST": "localhost"}')
        result = parse_env_file(env_file, ParseOptions())
        assert result["HOST"] == "localhost"

    def test_empty_yaml_returns_empty_dict(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("")
        result = parse_env_file(env_file, ParseOptions())
        assert result == {}

    def test_yaml_list_root_raises_value_error(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("- foo\n- bar\n")
        with pytest.raises(ValueError, match="mapping"):
            parse_env_file(env_file, ParseOptions())

    def test_yaml_null_value_becomes_empty_string(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("KEY:\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == ""

    def test_yaml_null_keyword_becomes_empty_string(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("KEY: null\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == ""

    def test_yaml_tilde_null_becomes_empty_string(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("KEY: ~\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == ""

    def test_yaml_null_value_lint_warning(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("KEY: null\n")
        messages = lint_env_file(env_file, ParseOptions())
        assert any("null value" in m.message for m in messages if m.level == "warning")

    def test_yaml_folded_multiline_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("KEY: >\n  hello\n  world\n")
        result = parse_env_file(env_file, ParseOptions())
        assert "KEY" in result
        assert "hello" in result["KEY"]

    def test_yaml_literal_multiline_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("KEY: |\n  hello\n  world\n")
        result = parse_env_file(env_file, ParseOptions())
        assert "KEY" in result
        assert "hello" in result["KEY"]

    def test_yaml_string_value_is_unchanged(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("HOST: localhost\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["HOST"] == "localhost"

    def test_empty_toml_returns_empty_dict(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_bytes(b"")
        result = parse_env_file(env_file, ParseOptions())
        assert result == {}

    def test_malformed_toml_raises_exception(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_bytes(b"[invalid\n")
        with pytest.raises(Exception):
            parse_env_file(env_file, ParseOptions())

    def test_toml_string_value_is_unchanged(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_text('HOST = "localhost"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["HOST"] == "localhost"

    def test_toml_int_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_text("PORT = 8080\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["PORT"] == "8080"

    def test_toml_float_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_text("RATE = 1.5\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["RATE"] == "1.5"

    def test_toml_datetime_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_text("CREATED = 2024-05-16T12:00:00\n")
        result = parse_env_file(env_file, ParseOptions())
        assert "CREATED" in result
        assert "2024" in result["CREATED"]

    def test_yaml_int_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("PORT: 8080\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["PORT"] == "8080"

    def test_yaml_float_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("RATE: 1.5\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["RATE"] == "1.5"


class TestNormalizeStructuredValue:
    def test_true_becomes_lowercase_string(self):
        assert _normalize_structured_value(True) == "true"

    def test_false_becomes_lowercase_string(self):
        assert _normalize_structured_value(False) == "false"

    def test_int_becomes_string(self):
        assert _normalize_structured_value(8080) == "8080"

    def test_float_becomes_string(self):
        assert _normalize_structured_value(1.5) == "1.5"

    def test_string_passthrough(self):
        assert _normalize_structured_value("hello") == "hello"

    def test_json_bool_true_normalized(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{"DEBUG": true, "VERBOSE": false}')
        result = parse_env_file(env_file, ParseOptions())
        assert result["DEBUG"] == "true"
        assert result["VERBOSE"] == "false"

    def test_yaml_bool_true_normalized(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("DEBUG: true\nVERBOSE: false\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["DEBUG"] == "true"
        assert result["VERBOSE"] == "false"

    def test_toml_bool_true_normalized(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_text("DEBUG = true\nVERBOSE = false\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["DEBUG"] == "true"
        assert result["VERBOSE"] == "false"

    def test_json_int_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{"PORT": 8080}')
        result = parse_env_file(env_file, ParseOptions())
        assert result["PORT"] == "8080"

    def test_json_float_becomes_string(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{"RATE": 1.5}')
        result = parse_env_file(env_file, ParseOptions())
        assert result["RATE"] == "1.5"


class TestStructuredLoaderLineNumbers:
    def test_json_null_value_warning_has_real_line_number(self, tmp_path):
        env_file = tmp_path / "test.json"
        env_file.write_text('{\n  "A": "hello",\n  "B": null,\n  "C": "world"\n}')
        messages = lint_env_file(env_file, ParseOptions())
        null_warnings = [m for m in messages if "null value" in m.message]
        assert len(null_warnings) == 1
        assert null_warnings[0].line_number == 3

    def test_yaml_null_value_warning_has_real_line_number(self, tmp_path):
        env_file = tmp_path / "test.yaml"
        env_file.write_text("A: hello\nB: ~\nC: world\n")
        messages = lint_env_file(env_file, ParseOptions())
        null_warnings = [m for m in messages if "null value" in m.message]
        assert len(null_warnings) == 1
        assert null_warnings[0].line_number == 2

    def test_toml_prefix_skip_has_real_line_number(self, tmp_path):
        env_file = tmp_path / "test.toml"
        env_file.write_text('APP_FOO = "bar"\nAPP_BAR = "baz"\nOTHER = "x"\n')
        messages = lint_env_file(env_file, ParseOptions(prefix="APP_"))
        skip_infos = [m for m in messages if "skip OTHER" in m.message]
        assert len(skip_infos) == 1
        assert skip_infos[0].line_number == 3

    def test_json_line_numbers_helper(self):
        content = '{\n  "FOO": "bar",\n  "BAZ": 42\n}'
        result = _json_line_numbers(content, ["FOO", "BAZ"])
        assert result == {"FOO": 2, "BAZ": 3}

    def test_toml_line_numbers_helper(self):
        content = 'FOO = "bar"\nBAZ = 42\n'
        result = _toml_line_numbers(content, ["FOO", "BAZ"])
        assert result == {"FOO": 1, "BAZ": 2}

    def test_yaml_line_numbers_helper(self):
        content = "FOO: bar\nBAZ: 42\n"
        result = _yaml_line_numbers(content)
        assert result == {"FOO": 1, "BAZ": 2}

    def test_yaml_line_numbers_empty_returns_empty(self):
        assert _yaml_line_numbers("") == {}

    def test_yaml_line_numbers_non_mapping_returns_empty(self):
        assert _yaml_line_numbers("- foo\n- bar\n") == {}


class TestVariableSubstitution:
    def test_var_resolved_from_env_file(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("BASE=hello\nDERIVED=${BASE}_world\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["DERIVED"] == "hello_world"

    def test_var_falls_back_to_os_environ(self, tmp_path, monkeypatch):
        monkeypatch.setenv("PARENT_VAR", "from-shell")
        env_file = tmp_path / ".env"
        env_file.write_text("CHILD=${PARENT_VAR}\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["CHILD"] == "from-shell"

    def test_env_file_var_takes_precedence_over_os_environ(self, tmp_path, monkeypatch):
        monkeypatch.setenv("MYVAR", "from-shell")
        env_file = tmp_path / ".env"
        env_file.write_text("MYVAR=from-file\nCHILD=${MYVAR}\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["CHILD"] == "from-file"

    def test_undefined_var_expands_to_empty_string(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("CHILD=${TOTALLY_UNDEFINED_XYZ}\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["CHILD"] == ""

    def test_substitute_variables_directly(self):
        env_vars = {"FOO": "bar"}
        assert substitute_variables("${FOO}", env_vars) == "bar"
        assert substitute_variables("${MISSING}", env_vars) == ""
        assert substitute_variables("no-refs", env_vars) == "no-refs"


class TestCircularReferences:
    def test_direct_cycle_reported_as_warning(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("A=${B}\nB=${A}\n")
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if m.level == "warning" and "circular" in m.message]
        assert len(warnings) == 1
        assert "A" in warnings[0].message
        assert "B" in warnings[0].message

    def test_self_reference_reported_as_warning(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("A=${A}\n")
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if m.level == "warning" and "circular" in m.message]
        assert len(warnings) == 1
        assert "A" in warnings[0].message

    def test_longer_cycle_reported(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("A=${B}\nB=${C}\nC=${A}\n")
        messages = lint_env_file(env_file, ParseOptions())
        warnings = [m for m in messages if m.level == "warning" and "circular" in m.message]
        assert len(warnings) == 1

    def test_no_cycle_produces_no_warning(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("BASE=hello\nDERIVED=${BASE}_world\n")
        messages = lint_env_file(env_file, ParseOptions())
        circular = [m for m in messages if "circular" in m.message]
        assert circular == []

    def test_parse_still_succeeds_despite_cycle(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("A=${B}\nB=${A}\nSAFE=ok\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["SAFE"] == "ok"


class TestParameterExpansion:
    # ${VAR:-default} — use default if unset or empty
    def test_colon_dash_uses_default_when_unset(self):
        assert substitute_variables("${VAR:-fallback}", {}) == "fallback"

    def test_colon_dash_uses_default_when_empty(self):
        assert substitute_variables("${VAR:-fallback}", {"VAR": ""}) == "fallback"

    def test_colon_dash_uses_value_when_set(self):
        assert substitute_variables("${VAR:-fallback}", {"VAR": "hello"}) == "hello"

    def test_colon_dash_uses_value_when_set_to_zero(self):
        assert substitute_variables("${VAR:-fallback}", {"VAR": "0"}) == "0"

    # ${VAR-default} — use default only when unset
    def test_dash_uses_default_when_unset(self):
        assert substitute_variables("${VAR-fallback}", {}) == "fallback"

    def test_dash_keeps_empty_value(self):
        assert substitute_variables("${VAR-fallback}", {"VAR": ""}) == ""

    def test_dash_uses_value_when_set(self):
        assert substitute_variables("${VAR-fallback}", {"VAR": "hello"}) == "hello"

    # ${VAR:?msg} — fail if unset or empty
    def test_colon_question_passes_when_set(self):
        assert substitute_variables("${VAR:?must be set}", {"VAR": "hello"}) == "hello"

    def test_colon_question_raises_when_unset(self):
        with pytest.raises(ValueError, match="must be set"):
            substitute_variables("${VAR:?must be set}", {})

    def test_colon_question_raises_when_empty(self):
        with pytest.raises(ValueError, match="required"):
            substitute_variables("${VAR:?required}", {"VAR": ""})

    def test_colon_question_default_message_when_no_msg(self):
        with pytest.raises(ValueError, match="VAR"):
            substitute_variables("${VAR:?}", {})

    # ${VAR:+alt} — emit alt only when set and non-empty
    def test_colon_plus_uses_alt_when_set(self):
        assert substitute_variables("${VAR:+alt}", {"VAR": "hello"}) == "alt"

    def test_colon_plus_empty_when_unset(self):
        assert substitute_variables("${VAR:+alt}", {}) == ""

    def test_colon_plus_empty_when_var_empty(self):
        assert substitute_variables("${VAR:+alt}", {"VAR": ""}) == ""

    # os.environ fallback for all operators
    def test_colon_dash_falls_back_to_os_environ(self, monkeypatch):
        monkeypatch.setenv("OS_VAR", "from-shell")
        assert substitute_variables("${OS_VAR:-fallback}", {}) == "from-shell"

    def test_colon_question_passes_with_os_environ(self, monkeypatch):
        monkeypatch.setenv("OS_VAR", "from-shell")
        assert substitute_variables("${OS_VAR:?missing}", {}) == "from-shell"

    # Integration: parser-level :? error becomes error-level message
    def test_parser_error_message_on_required_unset(self, tmp_path, monkeypatch):
        monkeypatch.delenv("REQUIRED_VAR", raising=False)
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${REQUIRED_VAR:?must be set}\n")
        messages = lint_env_file(env_file, ParseOptions())
        errors = [m for m in messages if m.level == "error"]
        assert len(errors) == 1
        assert "must be set" in errors[0].message

    def test_parser_raises_for_required_unset(self, tmp_path, monkeypatch):
        monkeypatch.delenv("REQUIRED_VAR", raising=False)
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${REQUIRED_VAR:?must be set}\n")
        with pytest.raises(ValueError, match="must be set"):
            parse_env_file(env_file, ParseOptions())

    def test_parser_error_line_number_tracked(self, tmp_path, monkeypatch):
        monkeypatch.delenv("MISSING", raising=False)
        env_file = tmp_path / ".env"
        env_file.write_text("A=1\nB=2\nC=${MISSING:?missing var}\n")
        messages = lint_env_file(env_file, ParseOptions())
        errors = [m for m in messages if m.level == "error"]
        assert errors[0].line_number == 3

    # Integration: full parse with defaults in env file
    def test_default_resolved_in_file(self, tmp_path, monkeypatch):
        monkeypatch.delenv("HOST", raising=False)
        env_file = tmp_path / ".env"
        env_file.write_text("URL=http://${HOST:-localhost}:8080\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["URL"] == "http://localhost:8080"


class TestExportKeyword:
    def test_export_with_value(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("export FOO=bar\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["FOO"] == "bar"

    def test_export_with_double_quoted_value(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('export BAR="hello world"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["BAR"] == "hello world"

    def test_export_with_single_quoted_value(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("export BAZ='secret'\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["BAZ"] == "secret"

    def test_export_bare_skipped_silently(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("export ALREADY_SET\nFOO=bar\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result == {"FOO": "bar"}
        messages = lint_env_file(env_file, ParseOptions())
        assert not any(m.message == "line not matched" for m in messages)

    def test_mixed_export_and_plain(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("export A=1\nB=2\nexport C=3\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result == {"A": "1", "B": "2", "C": "3"}

    def test_export_with_inline_comment(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("export HOST=localhost # dev only\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["HOST"] == "localhost"


class TestProcessEscapeSequences:
    def test_newline_escape(self):
        assert _process_escape_sequences(r"line1\nline2") == "line1\nline2"

    def test_tab_escape(self):
        assert _process_escape_sequences(r"col1\tcol2") == "col1\tcol2"

    def test_carriage_return_escape(self):
        assert _process_escape_sequences(r"text\rmore") == "text\rmore"

    def test_backslash_escape(self):
        assert _process_escape_sequences(r"path\\to\\file") == r"path\to\file"

    def test_double_quote_escape(self):
        assert _process_escape_sequences(r'say \"hello\"') == 'say "hello"'

    def test_unknown_escape_preserved(self):
        assert _process_escape_sequences(r"\x41") == r"\x41"

    def test_trailing_backslash_preserved(self):
        assert _process_escape_sequences("abc\\") == "abc\\"

    def test_empty_string(self):
        assert _process_escape_sequences("") == ""

    def test_no_escapes(self):
        assert _process_escape_sequences("hello world") == "hello world"


class TestEscapeSequences:
    def test_double_quoted_newline(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="line1\\nline2"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "line1\nline2"

    def test_double_quoted_tab(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="col1\\tcol2"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "col1\tcol2"

    def test_double_quoted_backslash(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="path\\\\to\\\\file"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "path\\to\\file"

    def test_double_quoted_escaped_quote(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="say \\"hello\\""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == 'say "hello"'

    def test_single_quoted_no_escape_processing(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY='no\\nprocessing'\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "no\\nprocessing"

    def test_unquoted_no_escape_processing(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=no\\nprocessing\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "no\\nprocessing"

    def test_double_quoted_multiple_escapes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="a\\tb\\nc"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "a\tb\nc"


class TestTripleQuotedValues:
    def test_triple_double_quote_multiline(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="""\nline1\nline2\n"""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "line1\nline2\n"

    def test_triple_single_quote_multiline(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY='''\nline1\nline2\n'''\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "line1\nline2\n"

    def test_triple_double_quote_single_line(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="""hello"""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "hello"

    def test_triple_single_quote_single_line(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY='''hello'''\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "hello"

    def test_triple_double_quote_empty(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY=""""""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == ""

    def test_triple_double_quote_with_escape(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="""line1\\nline2"""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "line1\nline2"

    def test_triple_single_quote_no_escapes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY='''line1\\nline2'''\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "line1\\nline2"

    def test_triple_double_quote_internal_single_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="""say \'hello\' there"""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "say 'hello' there"

    def test_triple_single_quote_internal_double_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY=\'\'\'say "hello" there\'\'\'\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == 'say "hello" there'

    def test_triple_double_quote_with_export(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('export KEY="""\nvalue\n"""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "value\n"

    def test_triple_double_quote_multiline_pem_like(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('CERT="""\n-----BEGIN CERT-----\nABCDEF\n-----END CERT-----\n"""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["CERT"] == "-----BEGIN CERT-----\nABCDEF\n-----END CERT-----\n"

    def test_triple_quote_unclosed_emits_error(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="""\nno closing quote\n')
        messages = lint_env_file(env_file, ParseOptions())
        errors = [m for m in messages if m.level == "error"]
        assert len(errors) == 1
        assert "unclosed" in errors[0].message
        assert "KEY" in errors[0].message

    def test_triple_quote_unclosed_key_not_in_result(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('OTHER=ok\nKEY="""\nno closing\n')
        result = parse_env_file(env_file, ParseOptions())
        assert "KEY" not in result
        assert result.get("OTHER") == "ok"

    def test_multiple_triple_quoted_keys(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('A="""\nfoo\n"""\nB=bar\nC="""\nbaz\n"""\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["A"] == "foo\n"
        assert result["B"] == "bar"
        assert result["C"] == "baz\n"


class TestDollarEscape:
    def test_double_dollar_becomes_literal_dollar(self):
        assert substitute_variables("$$HOME", {}) == "$HOME"

    def test_double_dollar_at_end(self):
        assert substitute_variables("value$$", {}) == "value$"

    def test_double_dollar_only(self):
        assert substitute_variables("$$", {}) == "$"

    def test_double_dollar_before_braced_var(self):
        assert substitute_variables("$${HOME}", {}) == "${HOME}"

    def test_double_dollar_mixed_with_expansion(self):
        assert substitute_variables("${VAR}$$${OTHER}", {"VAR": "a", "OTHER": "b"}) == "a$b"

    def test_double_dollar_path_like(self):
        assert substitute_variables("$$HOME/.config", {}) == "$HOME/.config"

    def test_single_dollar_unaffected(self):
        assert substitute_variables("${FOO}", {"FOO": "bar"}) == "bar"

    def test_no_dollars_unaffected(self):
        assert substitute_variables("plain value", {}) == "plain value"

    def test_double_dollar_in_env_file(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=$$HOME/.config\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "$HOME/.config"

    def test_double_dollar_in_double_quoted(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="prefix-$$VAR-suffix"\n')
        result = parse_env_file(env_file, ParseOptions())
        assert result["KEY"] == "prefix-$VAR-suffix"

    def test_double_dollar_with_expansion_in_file(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("HOST=localhost\nURL=http://${HOST}/$$path\n")
        result = parse_env_file(env_file, ParseOptions())
        assert result["URL"] == "http://localhost/$path"


class TestStrictMode:
    def test_undefined_ref_warns_in_strict(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${UNDEFINED_VAR}\n")
        messages = lint_env_file(env_file, ParseOptions(strict=True))
        warnings = [m for m in messages if "undefined" in m.message]
        assert len(warnings) == 1
        assert "UNDEFINED_VAR" in warnings[0].message
        assert warnings[0].level == "warning"

    def test_undefined_ref_silent_without_strict(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${UNDEFINED_VAR}\n")
        messages = lint_env_file(env_file, ParseOptions(strict=False))
        assert not any("undefined" in m.message for m in messages)

    def test_ambient_os_environ_ref_warns_in_strict(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AMBIENT_VAR", "ambient_value")
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${AMBIENT_VAR}\n")
        messages = lint_env_file(env_file, ParseOptions(strict=True))
        warnings = [m for m in messages if "resolved from environment" in m.message]
        assert len(warnings) == 1
        assert "AMBIENT_VAR" in warnings[0].message
        assert warnings[0].level == "warning"

    def test_ambient_os_environ_ref_silent_without_strict(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AMBIENT_VAR", "ambient_value")
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${AMBIENT_VAR}\n")
        messages = lint_env_file(env_file, ParseOptions(strict=False))
        assert not any("resolved from environment" in m.message for m in messages)

    def test_in_file_ref_no_warning_in_strict(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("BASE=hello\nKEY=${BASE}\n")
        messages = lint_env_file(env_file, ParseOptions(strict=True))
        assert not any("undefined" in m.message or "resolved from environment" in m.message for m in messages)

    def test_duplicate_key_is_error_in_strict(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=first\nKEY=second\n")
        messages = lint_env_file(env_file, ParseOptions(strict=True))
        dup_messages = [m for m in messages if "duplicated" in m.message]
        assert len(dup_messages) == 1
        assert dup_messages[0].level == "error"

    def test_duplicate_key_is_warning_without_strict(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=first\nKEY=second\n")
        messages = lint_env_file(env_file, ParseOptions(strict=False))
        dup_messages = [m for m in messages if "duplicated" in m.message]
        assert len(dup_messages) == 1
        assert dup_messages[0].level == "warning"

    def test_strict_value_still_resolves(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${UNDEFINED_VAR}\n")
        result = parse_env_file(env_file, ParseOptions(strict=True))
        assert result["KEY"] == ""

    def test_substitute_variables_strict_undefined(self):
        from runenv.parser import ParseMessage
        messages = []
        result = substitute_variables("${NOVAR}", {}, strict=True, messages=messages, line_number=1)
        assert result == ""
        assert len(messages) == 1
        assert "NOVAR" in messages[0].message
        assert messages[0].level == "warning"

    def test_substitute_variables_strict_ambient(self, monkeypatch):
        monkeypatch.setenv("AMBIENT", "val")
        from runenv.parser import ParseMessage
        messages = []
        result = substitute_variables("${AMBIENT}", {}, strict=True, messages=messages, line_number=1)
        assert result == "val"
        assert len(messages) == 1
        assert "AMBIENT" in messages[0].message
        assert "resolved from environment" in messages[0].message

    def test_substitute_variables_non_strict_no_messages(self, monkeypatch):
        monkeypatch.setenv("AMBIENT", "val")
        messages = []
        substitute_variables("${AMBIENT}", {}, strict=False, messages=messages)
        assert messages == []

    def test_default_operators_no_warning_in_strict(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=${MISSING:-fallback}\n")
        messages = lint_env_file(env_file, ParseOptions(strict=True))
        assert not any("undefined" in m.message or "resolved from environment" in m.message for m in messages)
