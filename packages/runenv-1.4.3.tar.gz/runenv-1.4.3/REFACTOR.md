# Refactor Analysis

Scope: `src/runenv/` source files and `tests/`. API surface (`create_env`, `load_env`,
`lint_env`, `find_env_file`) is frozen — no signature changes.

Priority tiers: **A** = correctness / dead code, **B** = duplication, **C** = readability.

---

## A — Correctness & Dead Code

### A1. `fail()` writes to stdout instead of stderr (`cli.py:102`)

```python
# current
def fail(msg: str, returncode: int = 1) -> None:
    sys.stdout.write(f"{msg}\n")
    sys.exit(returncode)
```

Error messages must go to `sys.stderr`. Every `fail()` call (missing env file,
non-executable, etc.) goes to stdout today, breaking `runenv list | grep …` pipelines.

```python
# fix
def fail(msg: str, returncode: int = 1) -> None:
    sys.stderr.write(f"{msg}\n")
    sys.exit(returncode)
```

---

### A2. Dead `_LEVEL_BY_ORDER` dict (`cli.py:27`)

`_LEVEL_BY_ORDER = {v: k for k, v in LEVEL_ORDER.items()}` was used by the
original `_strict_lint_settings` implementation but is no longer referenced after
`_strict_clamp` was introduced. Remove it.

---

### A3. `find_env_file` called twice per command (`cli.py:394-453`, `api.py:41-44`, `api.py:81-83`)

Inside `run()`, `find_env_file` is called to check existence and fail-fast:

```python
env_file = find_env_file(Path.cwd(), args.search_parent, args.env_file)
if not env_file:
    fail(...)
```

The resolved `env_file` path is then **discarded** — opts are built with
`env_file=args.env_file` (the raw, unresolved value). This causes `find_env_file`
to run a second time inside `lint_env` / `create_env`. Three subcommands × two calls
= six `find_env_file` executions per command. The resolved path should be passed
through opts to avoid the redundant lookups.

---

### A4. `load_env` calls `create_env` which calls `find_env_file` again (`api.py:57-68`)

```python
# load_env already resolved the path:
env_file = find_env_file(...)        # resolved Path
...
os.environ.update(create_env(env_file, ...))  # create_env calls find_env_file again
```

`create_env` always calls `find_env_file(Path.cwd(), search_parent, filename=env_file)`.
When `env_file` is an absolute `Path`, Python's path division (`cwd / abs_path`) happens
to return the absolute path unchanged — so it works, but accidentally. The fix is to
call `parse_env_file` directly in `load_env` after the file is resolved:

```python
os.environ.update(parse_env_file(env_file, ParseOptions(prefix=prefix, strip_prefix=strip_prefix)))
```

---

## B — Duplication

### B1. `add_stdout_handler` is copy-pasted in `cli.py:43` and `legacy.py:21`

Identical function defined in two modules. Should live in one place. Since `legacy.py`
already imports from `runenv.api` and `runenv.__about__`, it can import
`add_stdout_handler` from `runenv.cli` instead (or move it to a small `_utils.py`
that both import).

---

### B2. Shared `CMDOptions` fields duplicated across three dataclasses (`cli.py:67-99`)

`RunCMDOptions`, `ListCMDOptions`, `LintCMDOptions` all carry:
`env_file`, `prefix`, `strip_prefix`, `search_parent`, `lint_level`, `fail_on`, `strict`.

`CLIOptions` only holds `verbosity`. An intermediate base captures the shared shape:

```python
@dataclass
class EnvCMDOptions(CLIOptions):
    env_file: str
    prefix: Union[str, None]
    strip_prefix: bool
    search_parent: int
    lint_level: str
    fail_on: str
    strict: bool

@dataclass
class RunCMDOptions(EnvCMDOptions):
    command: List[str]

@dataclass
class ListCMDOptions(EnvCMDOptions):
    pass

@dataclass
class LintCMDOptions(EnvCMDOptions):
    as_json: bool
```

Handlers that share the lint pre-check can be typed against `EnvCMDOptions`.

---

### B3. Lint pre-check block copy-pasted in `handle_run_subcommand` and `handle_list_subcommand` (`cli.py:135-142`, `cli.py:167-174`)

```python
# appears twice, verbatim:
if options.lint_level != "none" or options.fail_on != "none":
    messages = lint_env(
        options.env_file, prefix=options.prefix, strip_prefix=options.strip_prefix,
        search_parent=options.search_parent, strict=options.strict,
    )
    rc = apply_lint_policy(messages, options.lint_level, options.fail_on)
    if rc != 0:
        return rc
```

Extract:

```python
def _run_lint_check(options: EnvCMDOptions) -> int:
    if options.lint_level == "none" and options.fail_on == "none":
        return 0
    messages = lint_env(
        options.env_file, prefix=options.prefix, strip_prefix=options.strip_prefix,
        search_parent=options.search_parent, strict=options.strict,
    )
    return apply_lint_policy(messages, options.lint_level, options.fail_on)
```

---

### B4. `find_env_file` error handling copy-pasted three times in `run()` (`cli.py:395-399`, `cli.py:414-419`, `cli.py:433-438`)

```python
# repeated three times with only the variable binding changing:
env_file = find_env_file(Path.cwd(), args.search_parent, args.env_file)
if not env_file:
    if args.env_file:
        fail(f"ERROR!!! Environment file `{args.env_file}` does not exist", 1)
    else:
        fail(f"No .env / .env.json / .env.toml / .env.yaml found in {Path.cwd()}", 1)
```

Extract to a helper that returns the resolved `Path` or exits:

```python
def _require_env_file(search_parent: int, env_file: Optional[str]) -> Path:
    resolved = find_env_file(Path.cwd(), search_parent, env_file)
    if not resolved:
        if env_file:
            fail(f"ERROR!!! Environment file `{env_file}` does not exist", 1)
        else:
            fail(f"No .env / .env.json / .env.toml / .env.yaml found in {Path.cwd()}", 1)
    return resolved  # type: ignore[return-value]  — fail() calls sys.exit
```

---

### B5. Argparse argument definitions copy-pasted across three subparsers (`cli.py:244-379`)

`--env-file`, `--prefix`, `--strip-prefix`, `--search-parent`, `--lint-level`,
`--fail-on`, `--strict` are registered on all three subparsers with identical
`add_argument` calls. Two helpers eliminate the repetition:

```python
def _add_env_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--env-file", ...)
    p.add_argument("-p", "--prefix", ...)
    p.add_argument("-s", "--strip-prefix", ...)
    p.add_argument("--search-parent", ...)

def _add_lint_args(p: argparse.ArgumentParser, *, default_lint_level: str, default_fail_on: str) -> None:
    p.add_argument("--lint-level", ..., default=default_lint_level)
    p.add_argument("--fail-on", ..., default=default_fail_on)
    p.add_argument("--strict", ...)
```

---

### B6. `load_json_file`, `load_yaml_file`, `load_toml_file` share identical structure (`parser.py:327-360`)

All three methods follow the same pattern:
1. open file & read content
2. parse to dict
3. `_check_structured_root`
4. `_iter_structured` with format-specific line-number extraction

Only the parsing call and line-number function differ. Extract a template:

```python
def _load_structured(
    self,
    env_file: Union[str, Path],
    fmt: str,
    parse: Callable[[str], object],
    line_numbers: Callable[[str], Dict[str, int]],
) -> List[Tuple[int, str, str]]:
    with open(env_file) as f:
        content = f.read()
    root = self._check_structured_root(parse(content), fmt)
    return self._iter_structured(root, fmt, line_numbers(content))
```

Each loader becomes a one-liner delegating to `_load_structured`.

---

### B7. `LOADERS` dict rebuilt on every `EnvParser.parse()` call (`parser.py:114-120`)

```python
# inside parse(), runs on every call:
LOADERS = {
    ".json": self.load_json_file,
    ".yaml": self.load_yaml_file,
    ".toml": self.load_toml_file,
}
```

The dict is a constant mapping of extensions to bound methods. Building it per-call
wastes allocation. Move it to a class-level dict of unbound method names resolved at
lookup time, or just inline the dispatch with an `if/elif` (which is also more explicit):

```python
_EXTENSION_LOADERS: Dict[str, str] = {
    ".json": "load_json_file",
    ".yaml": "load_yaml_file",
    ".toml": "load_toml_file",
}

# in parse():
loader_name = _EXTENSION_LOADERS.get(extension, "load_env_file")
loader = getattr(self, loader_name)
```

Or simply store the class methods as a class-level dict:

```python
# After class definition — methods are defined by then:
EnvParser._LOADERS = {".json": EnvParser.load_json_file, ...}
```

The cleanest path: move `LOADERS` to a class variable (as a `ClassVar`) populated
after all methods are defined.

---

## C — Readability

### C1. Fragile group index in `load_env_file` (`parser.py:285`)

```python
value = next(g for g in match.groups()[1:] if g is not None)
```

`match.groups()[1:]` yields groups 2, 3, 4 of the regex. Group 2 is already handled
in the `if match.group(2) is not None` branch, so this iterates groups that include
the already-excluded group 2. Relies on the generator skipping it because it's `None`
in the `else` branch — true, but non-obvious. Prefer explicit:

```python
value = match.group(3) if match.group(3) is not None else (match.group(4) or "")
```

---

### C2. `logger.debug` f-string in `substitute_variables` (`parser.py:414`)

```python
logger.debug(f"VALUE: {value} , type {type(value)}")
```

f-strings evaluate eagerly. For logger calls, use lazy formatting to avoid the
allocation when debug logging is off:

```python
logger.debug("VALUE: %s, type %s", value, type(value))
```

---

### C3. Extension resolved via `.name` instead of `Path(env_file).suffix` (`parser.py:112-113`)

```python
filename = env_file if isinstance(env_file, str) else env_file.name
extension = Path(filename).suffix
```

`env_file.name` gives only the basename, losing directory context (irrelevant for
`.suffix`, but confusing). Simplify:

```python
extension = Path(env_file).suffix
```

`Path(str)` and `Path(Path)` both work, so the `isinstance` guard is unnecessary.

---

### C4. Inconsistent stat access in `legacy.py:121` vs `cli.py:158`

```python
# legacy.py — old tuple-index style:
if not (stat.S_IXUSR & os.stat(cmd)[stat.ST_MODE]):

# cli.py — modern attribute style:
if not (os.stat(executable).st_mode & stat.S_IXUSR):
```

Standardise on the `.st_mode` attribute form throughout.

---

### C5. `cast("int", args.verbosity)` uses string form (`cli.py:383`)

```python
add_stdout_handler(cast("int", args.verbosity))
```

`cast` with a string argument is a forward-reference form for types not yet defined;
it provides no type-checker benefit here. Use the direct form:

```python
add_stdout_handler(cast(int, args.verbosity))
```

---

### C6. Trailing `return` at end of `load_env` (`api.py:70`)

A `return` at the end of a `-> None` function is noise. Remove it.

---

### C7. Prose comment in `api.py:59` violates no-comments rule

```python
# In `load_env` we will not fail if file does not exists
```

This explains *what* the code does (which is visible from reading it), not *why*.
Remove it.

---

## Summary Table

| ID  | File         | Lines      | Category    | Effort |
|-----|--------------|------------|-------------|--------|
| A1  | cli.py       | 102-104    | Correctness | XS     |
| A2  | cli.py       | 27         | Dead code   | XS     |
| A3  | cli.py       | 392-453    | Correctness | S      |
| A4  | api.py       | 57-68      | Correctness | S      |
| B1  | cli/legacy   | 43, 21     | Duplication | XS     |
| B2  | cli.py       | 67-99      | Duplication | S      |
| B3  | cli.py       | 135-142    | Duplication | XS     |
| B4  | cli.py       | 394-438    | Duplication | XS     |
| B5  | cli.py       | 244-379    | Duplication | S      |
| B6  | parser.py    | 327-360    | Duplication | S      |
| B7  | parser.py    | 114-120    | Duplication | XS     |
| C1  | parser.py    | 285        | Readability | XS     |
| C2  | parser.py    | 414        | Readability | XS     |
| C3  | parser.py    | 112-113    | Readability | XS     |
| C4  | legacy.py    | 121        | Readability | XS     |
| C5  | cli.py       | 383        | Readability | XS     |
| C6  | api.py       | 70         | Readability | XS     |
| C7  | api.py       | 59         | Readability | XS     |
