# PROBLEMS

A list of bugs, errors, and misconceptions found while reviewing the
`runenv` codebase. Items are grouped by component and severity.

Severity legend:
- **[BUG]** — produces wrong behavior or a crash under realistic input.
- **[LOGIC]** — code works for happy paths but contains incorrect/dead logic.
- **[DOC]** — documentation contradicts or under-specifies actual behavior.
- **[POLISH]** — minor issues, typos, or quality concerns.

---

## src/runenv/legacy.py

### P1. [BUG] AttributeError in legacy error path
**File/line:** `src/runenv/legacy.py:116`
```python
sys.stdout.write(f"[legacy] File `{args.cmd} is not executable\n")
```
`args.cmd` does not exist on the parsed `Namespace` — the attribute is
named `command`. Whenever a legacy invocation hits the "not executable"
branch the process crashes with `AttributeError` instead of printing a
helpful message and exiting 1.

### P2. [BUG] Missing closing backtick in user-facing error messages
**Files/lines:** `src/runenv/legacy.py:113,116`, `src/runenv/cli.py:98,101`
```python
fail(f"File `{executable} does not exist", 1)
fail(f"File `{executable} is not executable")
```
Every "file does not exist / is not executable" message is missing the
closing backtick, leaking the formatting into the rest of the line.

### P3. [BUG] `create_env` ignores `search_parent` in legacy path
**File/line:** `src/runenv/legacy.py:97`
```python
loaded_env = create_env(args.env_file, prefix=args.prefix, strip_prefix=args.strip_prefix)
```
The legacy CLI advertises `--search-parent` in its README but never
threads that option into `create_env`. The flag is silently ignored
when using the legacy `runenv .env <cmd>` form.

### P4. [BUG] `cmd is None` path crashes in legacy
**File/line:** `src/runenv/legacy.py:108-112`
```python
if not cmd.startswith(("/", ".")):
    cmd = shutil.which(cmd)
...
if cmd is None or not os.path.exists(cmd):
```
If `shutil.which(cmd)` returns `None`, the subsequent
`os.path.exists(cmd)` is short-circuited — fine. But the error message
prints `args.command` (the original string), then `sys.exit(1)` runs
and we never return a value. Same issue: missing closing backtick.

---

## src/runenv/cli.py

### P5. [BUG] `fail()` is called but a `return` follows
**File/line:** `src/runenv/cli.py:96-102`
```python
if executable is None or not os.path.exists(executable):
    fail(f"File `{executable} does not exist", 1)
    return 1
```
`fail()` calls `sys.exit()`, so the `return 1` is dead code. Either
keep `fail()` *or* `return`. Minor, but it's confusing and hides bug
P2 in plain sight.

### P6. [BUG] "Environment file None does not exist" error message
**File/line:** `src/runenv/cli.py:275,288,300`
```python
if not env_file:
    fail(f"ERROR!!! Environment file {args.env_file} does not exist", 1)
```
When `--env-file` is omitted and autodetection fails, the user sees:
> ERROR!!! Environment file None does not exist

Rather than something like "no .env / .env.json / .env.toml / .env.yaml
found in <cwd>".

### P7. [BUG] No subcommand crashes with `parser.error("Unknown subcommand")`
**File/line:** `src/runenv/cli.py:309-310`
Subparsers are configured with `required=False`. If the user runs bare
`runenv` (no args, no legacy file), `args.subcommand` is `None` and we
fall into the else branch which exits with an unhelpful error. It
should print `--help` instead.

### P8. [LOGIC] Legacy detection is heuristic and fragile
**File/line:** `src/runenv/cli.py:136-141`
```python
params = (" ".join(argv).split(" -- ", 1))[0].split(" ")
if "-h" not in params and "--help" not in params:
    _, l_argv = run_legacy_parser(argv, only_params=True)
    if len(l_argv) > 0 and Path(l_argv[0]).is_file():
        return run_legacy()
```
Two issues:
1. `" ".join(argv).split(" ")` corrupts any argument that contains
   spaces (e.g., `--prefix "MY APP_"`).
2. The legacy fallback triggers whenever the first positional looks
   like an existing file. A user who has a local file accidentally
   matching a subcommand name (or vice versa) gets wildly different
   behavior. There is no explicit opt-in for legacy mode.

### P9. [LOGIC] `lint` exits 0 even when errors are reported
**File/line:** `src/runenv/cli.py:116-124`
```python
def handle_lint_subcommand(options: LintCMDOptions) -> None:
    messages = lint_env(...)
    if options.as_json: ...
    else: ...
```
The lint subcommand never returns a non-zero exit code, even on
`level=="error"` messages. This breaks CI / pre-commit usage, which is
the primary reason to have a linter at all. Lint output should also be
written to **stderr**, not stdout, when in plain mode.

### P10. [LOGIC] `argparse.REMAINDER` for `command`
**File/line:** `src/runenv/cli.py:179`
`nargs=argparse.REMAINDER` is documented as a deprecated, fragile
feature. Combined with the manual `--` strip on line 82, the parsing
path is duplicative and breaks for `runenv run python -c "import x"`
unless the user remembers the `--` separator.

### P11. [LOGIC] `find_env_file` is called twice per command
**File/line:** `src/runenv/cli.py:273,286,298` + `api.py:41,56,79`
For every subcommand, `cli.py` calls `find_env_file` for validation
and then `create_env`/`load_env`/`lint_env` calls it again internally.
The pre-check uses `args.env_file` for the error message which
disagrees with the resolved path used downstream.

### P12. [DOC] `--help-legacy` flag is declared but unused
**File/line:** `src/runenv/cli.py:169-173`
The CLI advertises a `--help-legacy` flag, but `args.help_legacy` is
never read or acted upon. It looks like a feature that was started
and not finished.

---

## src/runenv/parser.py

### P13. [BUG] TOML import error message says "YAML"
**File/line:** `src/runenv/parser.py:158`
```python
sys.stderr.write("ERROR!!! To use YAML install runenv[toml]\n")
```
Should read "To use TOML install runenv[toml]". A user diagnosing a
TOML import failure is told to install YAML support.

### P14. [BUG] Strip-prefix branch skips the only key that exactly matches the prefix
**File/line:** `src/runenv/parser.py:52-66`
```python
if self.options.prefix and key != self.options.prefix and not key.startswith(self.options.prefix):
    ...  # skip
if self.options.prefix and key != self.options.prefix and self.options.strip_prefix:
    key = key[len(self.options.prefix):]
```
The double-guard `key != self.options.prefix` allows a variable whose
name *exactly equals* the prefix to slip through the skip filter,
**and** to bypass the strip step. It then gets inserted into the
output with its original name — i.e., the prefix string itself
becomes an env var. That's almost certainly unintentional.

### P15. [BUG] Variable interpolation silently swallows undefined references
**File/line:** `src/runenv/parser.py:174-181`
```python
def replace_match(match: re.Match[str]) -> str:
    var_name = match.group(1)
    return str(env_vars.get(var_name, os.environ.get(var_name, "")))
```
- An undefined `${FOO}` becomes the empty string with no warning.
- Falling back to `os.environ` leaks parent-process state into parsed
  values; this is undocumented and surprising in `create_env`, which
  is supposed to be side-effect free.
- Circular references (`A=${B}` / `B=${A}`) are resolved with a
  single pass and end up as `${A}` / `${B}` literals.

### P16. [BUG] Duplicate keys overwrite silently while reporting "error"
**File/line:** `src/runenv/parser.py:68-78`
A duplicate key is reported as `level="error"` but the code then
unconditionally overwrites `raw_environ[key]`. Either the report
should be a warning (and the value kept), or the duplicate should
abort parsing. Right now lint and runtime disagree about whether the
file is valid.

### P17. [BUG] JSON / YAML / TOML loaders fake line numbers
**File/lines:** `src/runenv/parser.py:128-166`
```python
line_number = 1
for key, value in json.loads(...).items():
    environ.append((line_number, key, value))
    line_number += 1
```
The "line number" is just a counter of keys, not the actual line in
the source file. `lint` results pointing at line N in a JSON file
have no relationship to the real source line.

### P18. [BUG] Non-string values lose their type
**File/lines:** `src/runenv/parser.py:177,181`
`substitute_variables` does `str(value)` unconditionally. For JSON
`{"PORT": 8080}` the loaded value becomes the string `"8080"`. For
YAML/TOML booleans it becomes `"True"` / `"False"` (Python repr), not
the more conventional `"true"` / `"false"`. Downstream consumers
expecting JSON-typed values get strings.

### P19. [BUG] YAML/JSON/TOML loaders crash on `null` / missing dict values
**File/line:** `src/runenv/parser.py:128-166`
```python
for key, value in yaml.safe_load(...).items():
```
- A YAML file with a top-level scalar or list crashes with
  `AttributeError: 'list' object has no attribute 'items'`.
- A YAML key with no value yields `value=None`, which later becomes
  the literal string `"None"`.
- An empty JSON/YAML/TOML file produces `None`, again crashing on
  `.items()`.

### P20. [LOGIC] Dead quote-stripping after regex already strips quotes
**File/line:** `src/runenv/parser.py:107-111`
```python
if (value.startswith('"') and value.endswith('"')) or (
    value.startswith("'") and value.endswith("'")
):
    value = value[1:-1]
```
The regex captures quoted values into groups 2/3 (inside the quotes)
and the unquoted case into group 4. Groups 2/3 never contain quotes;
group 4 only contains quotes for malformed input. This code is dead
or, worse, masks malformed quoting.

### P21. [LOGIC] Regex allows `.` in variable names
**File/line:** `src/runenv/parser.py:15`
```python
VARIABLE_LINE_REGEX = re.compile(r'^\s*([\w.]+)\s*=\s*...')
```
POSIX env var names are `[A-Za-z_][A-Za-z0-9_]*`. Allowing `.` lets
keys like `app.debug=1` parse, which can never be exported as an
environment variable to a subprocess.

### P22. [LOGIC] No support for `export VAR=...` prefix
Common `.env` dialects accept `export FOO=bar` so the same file can
be `source`-d from a shell. The regex rejects it as malformed.

### P23. [LOGIC] No escaping inside quoted values
There is no way to embed a literal `"` in a `"…"` value, no
backslash-escape support, and no multi-line / heredoc support.

### P24. [LOGIC] Inline comments aren't stripped consistently
For `KEY=value # comment` the regex captures `value` (ok). But for
`KEY="value # not a comment"` the trailing `#` is also fine. However
`KEY=value with # hash` is silently truncated at the `#` because the
regex's group 4 stops at `#`. Documenting or escaping this is
necessary.

### P25. [POLISH] `LOADERS` dict rebuilt on every parse call
**File/line:** `src/runenv/parser.py:43-48`
Trivial; could be a class attribute.

---

## src/runenv/api.py

### P26. [BUG] `lint_env`/`create_env` raise `ValueError` that CLI doesn't catch
**Files/lines:** `src/runenv/api.py:43,81` + `src/runenv/cli.py:117`
If the CLI pre-check passes but the file disappears between then and
the API call, an uncaught `ValueError("No env file found")` traceback
hits the user.

### P27. [LOGIC] `create_env` re-searches even when given an absolute path
**File/line:** `src/runenv/api.py:41`
```python
env_file = find_env_file(Path.cwd(), search_parent, filename=env_file)
```
When the caller already resolved the absolute path, `find_env_file`
re-evaluates it from `cwd`. Works because `pathlib` `/` absorbs
absolute paths, but it's surprising behavior masked by an
implementation accident.

### P28. [LOGIC] `find_env_file` recursion drops the search list when filename is set
**File/line:** `src/runenv/api.py:16-31`
When `filename` is supplied, the search list is just `[filename]` and
the parent-walk only looks for that exact name. That's fine, but the
function then never falls back to the default list. The doc string
should make it clear that "autodetection" *and* "explicit filename"
behave differently for parent search.

### P29. [DOC] `_RUNENV_WRAPPED` is an undocumented public contract
**Files:** `src/runenv/cli.py:90`, `src/runenv/api.py:64`, `tests/...`
`_RUNENV_WRAPPED` is the user-visible mechanism that prevents
double-loading, but it's not in the README, not exported, and not
namespaced. A user who sets it for their own purpose gets surprising
behavior.

### P30. [DOC] README contradicts code on default for `strip_prefix`
**README.md:79-87** vs **src/runenv/api.py:37**
README shows `strip_prefix=True` is the default but documents it as
a configurable option. CLI `-s/--strip-prefix` defaults to `False`
(it's a flag), so library and CLI default disagree. Pick one.

---

## Tests

### P31. [BUG] No tests for `lint` subcommand
There are zero tests for `handle_lint_subcommand`, `lint_env`, or
`lint_env_file`. Given the parser is the most defect-dense file in
the project, that is a hole.

### P32. [BUG] No tests for JSON / YAML / TOML loaders
Only `env.test` (plain dotenv) is exercised. None of the issues in
P17 / P18 / P19 are caught by the suite.

### P33. [BUG] `test_run_from_path` is not skipped on Windows
**File/line:** `tests/test_legacy_cli.py:24-27`
Uses `true` and `false` from PATH. On Windows neither command
exists; the recent "tests work on mac/windows" commit added a
`skipif` for `test_run` but not for `test_run_from_path`.

### P34. [POLISH] Tests rely on mutating `os.chdir` without restoring it
**File/line:** `tests/test_api.py` (multiple)
`os.chdir(...)` is called without a `monkeypatch.chdir` or
`try/finally`. Tests that run after these inherit the new cwd, which
is order-dependent and surprising in CI logs.

---

## Packaging & ops

### P35. [DOC] `requires-python = ">=3.7"` despite EOL
**File/line:** `pyproject.toml:6`
Python 3.7 has been EOL since June 2023. Carrying it forward forces
old `typing.List/Dict/Union`, the `tomli` backport, and pinning of
old test-deps. Dropping it would remove ~20% of the conditional
import / typing noise in this codebase.

### P36. [DOC] CHANGELOG references `--strip_prefix` typo and a `--dry-run` in CLI that no longer exists
The new subcommand CLI removed `--dry-run` from `run`, but
documentation in CHANGELOG still references it and there is no
replacement (`list` is close but not identical: it doesn't show what
*would* be set, including `_RUNENV_WRAPPED`).

### P37. [POLISH] Optional dependency extras `[toml]` and `[yaml]` aren't required for the matching loader
The loader silently `sys.exit(1)` on missing import. An install-time
hint, e.g., `pip install runenv[toml]`, is shown but the program
dies hard with stderr instead of raising an exception the caller
can recover from.

### P38. [POLISH] No signal forwarding in `run`
`subprocess.check_call` waits on the child but doesn't forward
`SIGTERM`/`SIGINT`/`SIGHUP` cleanly — interrupting `runenv run` may
leave the child orphaned on some platforms. Comparable tools
(`dotenv-cli`, `direnv exec`) install signal handlers.

### P39. [POLISH] Repository contains stray artifacts
`.coverage`, `coverage.xml`, `dist/`, `site/`, `.mypy_cache/`,
`.ruff_cache/`, `.pytest_cache/`, plus a development `.env`,
`.env.json`, `.env.toml`, `.env.yaml`, `.envrc`, `message.txt` and
`uv.lock` are all checked in / untracked. The repo would benefit
from a tighter `.gitignore` and a clean checkout.

### P40. [POLISH] `subprocess.check_call(..., env=os.environ)` passes the live mapping
**File/line:** `src/runenv/cli.py:103`
Passing `os.environ` (the mapping) rather than `dict(os.environ)` is
fine for CPython but documented to be unspecified. Convert to a dict
for portability.
