# IMPROVEMENTS

Feature and performance improvements that would make `runenv` a more
versatile, dev/ops-friendly tool — closer in scope and ergonomics to
established tools like `direnv`, `dotenv-cli`, `chamber`,
`envsubst`, `sops`, and `doppler`.

Sections are ordered from "core ergonomics" outward to "ecosystem".

---

## 1. .env dialect & parser

### I1. `${VAR:-default}` / `${VAR:?error}` expansion
Adopt Bash-style parameter expansion:
- `${VAR:-default}` — use `default` if `VAR` is unset/empty.
- `${VAR-default}` — use `default` if `VAR` is unset.
- `${VAR:?msg}` — fail with `msg` if unset/empty (great for required vars).
- `${VAR:+alt}` — emit `alt` only when set.

This single change closes most of the "silent empty string" footguns
(P15) and brings runenv to feature parity with `envsubst`.

### I2. Support `export VAR=...`
Accept (and discard) the `export` keyword so the same `.env` file is
loadable by `source .env` in a shell. This is a near-universal
convention in `dotenv` dialects.

### I3. Multi-line and escaped values
- `KEY="line1\nline2"` with conventional `\n`, `\t`, `\\`, `\"` escapes.
- Triple-quoted / heredoc-style multi-line values:
  ```
  PRIVATE_KEY="""
  -----BEGIN ...
  -----END ...
  """
  ```
  Useful for TLS keys, JWT secrets, GPG keys.

### I4. `${VAR}` escaping (`$$`)
Allow `$$` to emit a literal `$`. Needed when values include
shell-style placeholders for downstream tools (e.g., Postgres
`PGSERVICEFILE=$$HOME/...`).

### I5. Schema-aware values (typed)
Optional in-file annotations or a sidecar `.env.schema`:
```
PORT:int=8080
DEBUG:bool=true
HOSTS:list=a,b,c
```
The Python API then returns typed values; the CLI can validate.
Compare: `pydantic-settings`, `viper`, `koanf`.

### I6. Required-variable declarations
`# @required PORT, DATABASE_URL` directives (or schema-based) that
fail `runenv run` / `runenv lint` if missing. Currently misconfigured
deployments fail at first use, deep in application code.

### I7. Including other env files
`# @include common.env` or `# @extends .env.base`. This is the
"layered config" pattern (`.env` → `.env.<profile>` →
`.env.<profile>.local`) used by Next.js, Rails, Django, Symfony.

### I8. Real source line numbers for JSON/TOML/YAML
Use `json` with `object_pairs_hook` + custom parser, or `ruamel.yaml`,
or `tomlkit` to retain source line numbers — fixes P17 and makes lint
output actionable.

### I9. Native type preservation for structured formats
Stop forcing `str(value)`. Return `Dict[str, Any]` from `create_env`
and convert to strings only when exporting to `os.environ`. Booleans
should map to `"true"`/`"false"` (lowercase, conventional).

---

## 2. CLI ergonomics

### I10. Profiles directory (`.runenv/`)
Adopt the convention `~/.runenv/<profile>.env` and project-local
`.runenv/<profile>.env`, with `runenv run -p prod -- …`.
Already foreshadowed in IDEAS.md.

### I11. `runenv export` (render)
Render the resolved environment in a number of output formats:
- `runenv export --format=dotenv > .env.rendered`
- `runenv export --format=docker` (for `docker run --env-file`)
- `runenv export --format=k8s-configmap`
- `runenv export --format=json` / `--format=yaml`
- `runenv export --format=shell` (eval'able by sh/bash/zsh)
- `runenv export --format=fish` / `--format=nushell`

This makes runenv interoperable with CI, containers, and
orchestration tooling.

### I12. `runenv diff`
Show the diff between two env files / profiles:
```
$ runenv diff .env.dev .env.prod
- DEBUG=1
+ DEBUG=0
+ SENTRY_DSN=https://...
```

### I13. `runenv check` (CI mode)
Combine lint + schema + required-vars + drift-from-`.env.example`
into a single CI-friendly command with non-zero exit and JSON output.

### I14. `runenv init` / `runenv scaffold`
Generate a starter `.env`, `.env.example`, schema file, and
`.gitignore` lines. Inspired by `direnv` and `doppler init`.

### I15. `runenv shell`
Drop into an interactive subshell with the env loaded, the
spiritual equivalent of `direnv exec` for ad-hoc usage.

### I16. `runenv set` / `runenv get` / `runenv unset`
Programmatic edit of `.env` files that preserves comments and order:
```
runenv set DEBUG=1 --env-file .env.dev
runenv get DEBUG  --env-file .env.dev
runenv unset DEBUG --env-file .env.dev
```

### I17. Pass-through unknown args without `--`
Reduce reliance on `argparse.REMAINDER` (P10). `runenv run python -V`
should Just Work. `--` should remain optional but supported.

### I18. `--strict` mode
Fail on undefined `${VAR}` references, duplicate keys, or unknown
schema fields, instead of warning. Pairs well with I6.

### I19. Better autodetect override
A single `--env=` argument that accepts `dev` → resolves to
`.env.dev`. Reduces the `--env-file .env.dev` boilerplate.

### I20. Quieter / structured output
- `-q` / `--quiet` to silence INFO logs in `run`.
- `--log-format=json` for structured logs (CI/log aggregator friendly).
- Default `lint` output should be `<file>:<line>:<col> <severity> <msg>`
  (the format editors and `gcc -fdiagnostics-format` understand).

### I21. Signal forwarding & exec
- Use `os.execvpe` on POSIX (replace the current process — same as
  `direnv exec` and `dotenv-cli` do). No orphaned subprocesses, no
  intermediate Python process holding memory.
- On Windows, install a `signal.SIGINT/SIGTERM` forwarder around
  `subprocess.Popen`.

---

## 3. Secrets, encryption, key management

### I22. Built-in encryption of values (`age` / `sops`)
- `runenv encrypt --key age1...` / `runenv decrypt`
- Per-value encryption (`SECRET=age:<armored>`) so the .env stays
  diff-friendly and partially readable.
- Whole-file encryption mode for the paranoid.
- Pluggable backends: `age`, `sops`, `gpg`, KMS (AWS, GCP, Azure),
  HashiCorp Vault.

### I23. Cloud secret-manager backends
A value like `SECRET=@aws:secretsmanager:/prod/db_password` resolves
at load time. Backends: AWS SM, GCP Secret Manager, Azure Key Vault,
Vault, 1Password, Doppler. Compare: `chamber`, `summon`, `berglas`.

### I24. `.env.sops` / `.env.age` auto-detection
If `.env.sops.yaml` exists alongside `.env`, automatically decrypt
on load if `SOPS_AGE_KEY` etc. are available.

### I25. Secret redaction in `list` / `export`
Mark variables as `# @secret PASSWORD, DATABASE_URL`; `runenv list`
shows `PASSWORD=****` unless `--reveal` is passed. Useful for
running `runenv list` in shared terminals or screen-sharing.

### I26. `runenv audit`
Detect accidentally committed secrets, print a report, support
`pre-commit`/`pre-push` hook integration. Compare: `gitleaks`,
`detect-secrets`.

---

## 4. Performance

### I27. Stream-based parser
Current parser reads the entire file then iterates. For ≤1k-line
`.env` files this is irrelevant, but JSON/YAML/TOML files in a
monorepo or with embedded blobs benefit from streaming + early-exit
on first parse error.

### I28. Compile-once class-level `LOADERS` and regexes
P25 — trivially make `LOADERS`/regexes class attributes. ~5% parse
time saved on hot paths (CLI startup).

### I29. Lazy import of `yaml` / `tomli`
Already done in the loaders. Extend: lazy-import `subprocess` only
in `run` paths; defer `argparse` subparser construction when running
in a tight loop (e.g., shell completion). Bigger payoff: cold-start
of `runenv --version` should be <30ms.

### I30. Cache resolved env per (file, mtime, args)
For repeated `runenv list` / `lint` / `run` in dev loops, cache to
`$XDG_CACHE_HOME/runenv/<hash>.json`. Invalidate on mtime or content
hash change. Cheap, big win for `pre-commit`/IDE integrations.

### I31. C/Rust accelerated parser (optional)
Pure-Python regex is fine. But once the dialect grows (I1-I4), a
PEG/regex-based parser (e.g., `lark` or a small Rust extension via
`maturin`) would scale to large files cleanly.

---

## 5. API improvements (Python)

### I32. Typed config object
```python
from runenv import settings

class AppSettings(settings.BaseSettings):
    debug: bool = False
    port: int = 8000
    database_url: str

cfg = AppSettings.load(".env")
```
This is the niche `pydantic-settings` owns; runenv can occupy the
"stdlib-only, no pydantic dependency" sweet spot (`dataclasses` +
type hints + `os.environ`).

### I33. `load_env` returns the loaded mapping
Currently returns `None`. Returning the mapping is consistent with
`dict.update` semantics and removes a `create_env` + `load_env`
double-call pattern users do today.

### I34. Context-manager API
```python
with runenv.activated(".env.test"):
    pytest.main(...)
```
Restores `os.environ` on exit. Useful in tests and notebooks; mirrors
`monkeypatch`/`pytest-env` semantics.

### I35. `find_env_file` accepts a list of names
Allow `find_env_file(path, names=[".env.local", ".env"])`. Today the
priority and ability to override is baked in.

### I36. Strict typing in API
- Replace `Union[str, None]` with `Optional[str]`, drop `Tuple` /
  `List` / `Dict` from `typing` once 3.7 is dropped (I44).
- Export `ParseMessage`, `ParseOptions`, `EnvParser` from the
  package root.

---

## 6. Framework / ecosystem integrations

### I37. First-class hooks for popular frameworks
Examples that "just work":
- Django: `runenv.django.setup()` that calls `load_env` and
  `django.setup()` in one go.
- FastAPI / Starlette: dependency providing the typed settings.
- pytest: a `runenv_envfile` fixture and a `pytest-runenv` plugin.
- Hypercorn / uvicorn: `--env-file` shim.

### I38. Direnv integration
Provide a `use runenv` stdlib helper for `.envrc`:
```
use runenv .env.dev
```
Compares favorably with the awkward `dotenv` direnv pattern.

### I39. Docker / Kubernetes recipes
- `runenv export --format=docker` (I11) feeds `docker run --env-file`.
- A small Helm/K8s ConfigMap render via `runenv export --format=k8s-configmap`.
- A `--env-file` adapter for `docker compose`.

### I40. Shell completion & init hooks
- `runenv completion bash|zsh|fish` (autogenerated argparse comps).
- `eval "$(runenv shellenv)"` similar to `direnv hook bash` for
  per-directory auto-loading.

### I41. Pre-commit hook
Ship a `.pre-commit-hooks.yaml` so users can wire `runenv lint` and
`runenv audit` into commits.

### I42. GitHub Action
A reusable action: `uses: onjin/runenv-action@v1 with: env-file:
.env.ci` that loads the env into subsequent steps via
`$GITHUB_ENV`.

### I43. JSON Schema / `.env.example` generator
`runenv schema --from .env > .env.schema.json` and the reverse:
`runenv example --from schema > .env.example`. Lets repos document
expected env shape without a custom format.

---

## 7. Project hygiene

### I44. Drop Python 3.7 / 3.8
EOL — see P35. Frees up `match`, `tomllib`, modern typing.

### I45. Tighten `.gitignore`, remove artifacts
Stop checking in `coverage.xml`, `.coverage`, `dist/`, `site/`, and
local `.env*` development files (P39).

### I46. Add an `examples/` directory
A handful of end-to-end recipes:
- Django + runenv profile switching
- FastAPI + sops-encrypted secrets
- docker compose + `runenv export`
- pytest with `runenv` activated context manager

### I47. Better docs site
README is a good start; surface the rest as a hosted mkdocs site
(the `.readthedocs.yaml` and `requirements-docs.txt` are already
there). Document the dialect formally — escape rules, precedence,
search algorithm.

### I48. Property-based parser tests
Use `hypothesis` to fuzz the env parser. Most P13-P24 bugs are
exactly the kind property-based testing catches.

### I49. Benchmark harness
`pytest-benchmark` against a representative `.env` (e.g., 500 keys,
mixed quoting, interpolation). Lock perf regressions out via CI.

### I50. SBOM + signed releases
For a tool that holds secrets, ship a Sigstore-signed release plus a
CycloneDX SBOM. Increases trust for ops users adopting it.

---

## 8. Multi-language vision (long-term)

(From IDEAS.md — kept for the roadmap.)

### I51. Rewrite CLI in Go (or Rust) — distribute as a static binary
Removes the "needs Python" footgun for ops users who want
`runenv` available in minimal containers. Python remains the SDK
target for the API.

### I52. SDKs in other languages
Same `.env` dialect, language-idiomatic config objects:
- Node.js / TypeScript
- Go
- Rust
- Ruby
- Java / Kotlin

Common test suite (a "dialect conformance" file set) ensures the
parsers stay in sync. Compare: `dotenvx` is doing this for JS;
runenv can do it cross-language.
