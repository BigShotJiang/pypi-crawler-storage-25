"""Tests for module discovery and module-related functionality."""

from __future__ import annotations

from pathlib import Path

import yaml
from click.testing import CliRunner

from tenzir_ship.cli import cli
from tenzir_ship.config import Config
from tenzir_ship.modules import discover_modules, discover_modules_from_config
from tenzir_ship.validate import validate_modules, run_validation_with_modules


def write_yaml(path: Path, content: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(content, sort_keys=False), encoding="utf-8")


def create_module(base: Path, module_id: str, module_name: str) -> Path:
    """Create a minimal module directory with config."""
    module_root = base / module_id / "changelog"
    module_root.mkdir(parents=True)
    write_yaml(
        module_root / "config.yaml",
        {"id": module_id, "name": module_name},
    )
    (module_root / "unreleased").mkdir()
    return module_root


def create_entry(module_root: Path, title: str, entry_type: str = "feature") -> Path:
    """Create a minimal changelog entry."""
    slug = title.lower().replace(" ", "-")
    entry_path = module_root / "unreleased" / f"{slug}.md"
    entry_path.write_text(
        f"---\ntitle: {title}\ntype: {entry_type}\ncreated: 2025-01-01T00:00:00Z\n---\n\nBody.\n",
        encoding="utf-8",
    )
    return entry_path


# --- Module Discovery Tests ---


def test_discover_modules_finds_matching_projects(tmp_path: Path) -> None:
    """Modules matching the glob pattern are discovered."""
    packages = tmp_path / "packages"
    create_module(packages, "foo", "Foo Package")
    create_module(packages, "bar", "Bar Package")

    parent_root = tmp_path / "changelog"
    parent_root.mkdir()

    modules = list(discover_modules(parent_root, "../packages/*/changelog"))

    assert len(modules) == 2
    ids = {m.config.id for m in modules}
    assert ids == {"foo", "bar"}


def test_discover_modules_empty_when_no_matches(tmp_path: Path) -> None:
    """Empty list when glob pattern matches nothing."""
    parent_root = tmp_path / "changelog"
    parent_root.mkdir()

    modules = list(discover_modules(parent_root, "../packages/*/changelog"))

    assert modules == []


def test_discover_modules_from_config_empty_when_no_glob(tmp_path: Path) -> None:
    """Returns empty list when config has no modules field."""
    parent_root = tmp_path / "changelog"
    parent_root.mkdir()
    config = Config(id="parent", name="Parent Project")

    modules = discover_modules_from_config(parent_root, config)

    assert modules == []


def test_discover_modules_skips_invalid_configs(tmp_path: Path) -> None:
    """Directories without valid config.yaml are skipped."""
    packages = tmp_path / "packages"
    create_module(packages, "valid", "Valid Package")

    # Create invalid module (missing id)
    invalid_root = packages / "invalid" / "changelog"
    invalid_root.mkdir(parents=True)
    write_yaml(invalid_root / "config.yaml", {"name": "Missing ID"})

    parent_root = tmp_path / "changelog"
    parent_root.mkdir()

    modules = list(discover_modules(parent_root, "../packages/*/changelog"))

    assert len(modules) == 1
    assert modules[0].config.id == "valid"


def test_discover_modules_handles_relative_paths(tmp_path: Path) -> None:
    """Module relative_path is set correctly for display."""
    packages = tmp_path / "packages"
    create_module(packages, "foo", "Foo Package")

    parent_root = tmp_path / "changelog"
    parent_root.mkdir()

    modules = list(discover_modules(parent_root, "../packages/*/changelog"))

    assert len(modules) == 1
    # relative_path should contain the ../ prefix
    assert "../" in modules[0].relative_path or "packages" in modules[0].relative_path


def test_discover_modules_sorted_by_id(tmp_path: Path) -> None:
    """Modules are returned sorted by ID."""
    packages = tmp_path / "packages"
    create_module(packages, "zebra", "Zebra Package")
    create_module(packages, "alpha", "Alpha Package")
    create_module(packages, "middle", "Middle Package")

    parent_root = tmp_path / "changelog"
    parent_root.mkdir()
    config = Config(id="parent", name="Parent", modules="../packages/*/changelog")

    modules = discover_modules_from_config(parent_root, config)

    ids = [m.config.id for m in modules]
    assert ids == ["alpha", "middle", "zebra"]


# --- Validation Tests ---


def test_validate_modules_detects_duplicate_ids(tmp_path: Path) -> None:
    """Duplicate module IDs are reported as validation issues."""
    packages = tmp_path / "packages"
    create_module(packages, "foo", "Foo Package")

    # Create another module with same ID
    dup_root = packages / "foo-dup" / "changelog"
    dup_root.mkdir(parents=True)
    write_yaml(dup_root / "config.yaml", {"id": "foo", "name": "Duplicate Foo"})
    (dup_root / "unreleased").mkdir()

    parent_root = tmp_path / "changelog"
    parent_root.mkdir()
    config = Config(id="parent", name="Parent", modules="../packages/*/changelog")

    modules = discover_modules_from_config(parent_root, config)
    issues = validate_modules(parent_root, config, modules)

    assert len(issues) == 1
    assert "Duplicate module ID 'foo'" in issues[0].message


def test_validate_modules_detects_parent_id_collision(tmp_path: Path) -> None:
    """Module ID colliding with parent ID is reported."""
    packages = tmp_path / "packages"
    # Create module with same ID as parent
    create_module(packages, "parent", "Collision Package")

    parent_root = tmp_path / "changelog"
    parent_root.mkdir()
    config = Config(id="parent", name="Parent", modules="../packages/*/changelog")

    modules = discover_modules_from_config(parent_root, config)
    issues = validate_modules(parent_root, config, modules)

    assert len(issues) == 1
    assert "Duplicate module ID 'parent'" in issues[0].message


def test_run_validation_with_modules_prefixes_issues(tmp_path: Path) -> None:
    """Module validation issues are prefixed with module ID."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")

    # Create invalid entry (missing type)
    entry_path = mod_root / "unreleased" / "bad-entry.md"
    entry_path.write_text(
        "---\ntitle: Bad Entry\ncreated: 2025-01-01T00:00:00Z\n---\n\nBody.\n",
        encoding="utf-8",
    )

    parent_root = tmp_path / "changelog"
    parent_root.mkdir()
    write_yaml(parent_root / "config.yaml", {"id": "parent", "name": "Parent"})
    (parent_root / "unreleased").mkdir()

    config = Config(id="parent", name="Parent", modules="../packages/*/changelog")
    modules = discover_modules_from_config(parent_root, config)

    issues = run_validation_with_modules(parent_root, config, modules)

    # Find the module issue
    module_issues = [i for i in issues if "[mymod]" in i.message]
    assert len(module_issues) >= 1
    assert "Unknown type" in module_issues[0].message


# --- CLI Tests ---


def test_cli_stats_command_shows_parent(tmp_path: Path) -> None:
    """stats command shows parent project even without modules."""
    runner = CliRunner()
    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(project_dir / "config.yaml", {"id": "test", "name": "Test"})

    result = runner.invoke(cli, ["--root", str(project_dir), "stats"])

    assert result.exit_code == 0
    assert "test" in result.output
    assert "📛" in result.output  # vertical view shows project info


def test_cli_stats_command_lists_modules(tmp_path: Path) -> None:
    """stats command lists discovered modules with their IDs."""
    packages = tmp_path / "packages"
    create_module(packages, "foo", "Foo Package")
    create_module(packages, "bar", "Bar Package")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()

    runner = CliRunner()
    result = runner.invoke(cli, ["--root", str(project_dir), "stats"])

    assert result.exit_code == 0
    # IDs may be truncated in narrow terminals, so check for prefix
    assert "pa" in result.output  # parent
    assert "foo" in result.output
    assert "bar" in result.output


def test_cli_stats_vertical_view_for_single_project(tmp_path: Path) -> None:
    """stats command uses vertical view for projects without modules."""
    runner = CliRunner()
    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(project_dir / "config.yaml", {"id": "myproject", "name": "My Project"})
    (project_dir / "unreleased").mkdir()

    result = runner.invoke(cli, ["--root", str(project_dir), "stats"])

    assert result.exit_code == 0
    # Vertical view shows project info with emoji indicators
    # Text may be truncated in narrow test terminal, but emojis survive
    assert "📛" in result.output  # Name row
    assert "🔖" in result.output  # Version row


def test_cli_stats_table_flag_forces_table_view(tmp_path: Path) -> None:
    """stats --table forces table view even for single project."""
    runner = CliRunner()
    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(project_dir / "config.yaml", {"id": "myproject", "name": "My Project"})
    (project_dir / "unreleased").mkdir()

    result = runner.invoke(cli, ["--root", str(project_dir), "stats", "--table"])

    assert result.exit_code == 0
    # Table view has emoji headers (📛 for name/ID column)
    assert "📛" in result.output
    # Table shows project ID in data row
    assert "myproject" in result.output


def test_cli_stats_json_output(tmp_path: Path) -> None:
    """stats --json produces valid JSON output."""
    import json

    runner = CliRunner()
    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(project_dir / "config.yaml", {"id": "myproject", "name": "My Project"})
    (project_dir / "unreleased").mkdir()

    result = runner.invoke(cli, ["--root", str(project_dir), "stats", "--json"])

    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "project_root" in data
    assert "parent" in data
    assert data["parent"]["id"] == "myproject"
    assert "releases" in data["parent"]
    assert "entries" in data["parent"]


def test_cli_show_includes_modules_by_default(tmp_path: Path) -> None:
    """show command includes module entries by default."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_entry(mod_root, "Module Feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    # Create parent entry
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    result = runner.invoke(cli, ["--root", str(project_dir), "show"])

    assert result.exit_code == 0
    assert "Module Feature" in result.output
    assert "Parent Feature" in result.output


def test_cli_validate_with_modules(tmp_path: Path) -> None:
    """validate command checks parent and modules."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_entry(mod_root, "Valid Entry")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Entry")

    runner = CliRunner()
    result = runner.invoke(cli, ["--root", str(project_dir), "validate"])

    assert result.exit_code == 0
    assert "all changelog files look good" in result.output


def test_show_warns_on_module_structure_violation(tmp_path: Path) -> None:
    """Non-release commands warn when module changelog layout is invalid."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_entry(mod_root, "Module Entry")
    (mod_root / "next").mkdir()

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Entry")

    runner = CliRunner()
    result = runner.invoke(cli, ["--root", str(project_dir), "show"])

    assert result.exit_code == 0, result.output
    assert "changelog structure issues detected; release commands may fail." in result.output
    assert "[mymod] Unexpected item in changelog root: 'next'" in result.output


def test_release_create_fails_on_module_structure_violation(tmp_path: Path) -> None:
    """Release creation hard-fails when a module changelog layout is invalid."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_entry(mod_root, "Module Entry")
    (mod_root / "next").mkdir()

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Entry")

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v1.0.0", "--yes"],
    )

    assert result.exit_code != 0
    assert "Cannot create a release: changelog structure is invalid." in result.output
    assert "[mymod] Unexpected item in changelog root: 'next'" in result.output
    assert not (project_dir / "releases" / "v1.0.0").exists()


# --- Release Notes with Modules Tests ---


def create_released_entry(
    module_root: Path, title: str, version: str, entry_type: str = "feature"
) -> Path:
    """Create a changelog entry in a release directory."""
    slug = title.lower().replace(" ", "-")
    release_dir = module_root / "releases" / version / "entries"
    release_dir.mkdir(parents=True, exist_ok=True)
    entry_path = release_dir / f"{slug}.md"
    entry_path.write_text(
        f"---\ntitle: {title}\ntype: {entry_type}\ncreated: 2025-01-01T00:00:00Z\nauthors:\n  - testuser\n---\n\nEntry body text.\n",
        encoding="utf-8",
    )
    # Also create the manifest
    manifest_path = module_root / "releases" / version / "manifest.yaml"
    if not manifest_path.exists():
        write_yaml(
            manifest_path,
            {
                "created": "2025-01-01",
                "title": f"Release {version}",
                "entries": [slug],
            },
        )
    else:
        # Append entry to existing manifest
        manifest = yaml.safe_load(manifest_path.read_text())
        if slug not in manifest["entries"]:
            manifest["entries"].append(slug)
            write_yaml(manifest_path, manifest)
    return entry_path


def test_show_release_includes_module_sections(tmp_path: Path) -> None:
    """show --release includes module sections with released entries."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Feature One", "v1.0.0", "feature")
    create_released_entry(mod_root, "Module Bugfix", "v1.0.0", "bugfix")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    result = runner.invoke(
        cli, ["--root", str(project_dir), "show", "--release", "-m", "unreleased"]
    )

    assert result.exit_code == 0
    # Main project entry with full body
    assert "Parent Feature" in result.output
    assert "Body." in result.output  # Full body for main project
    # Module section appears
    assert "## My Module" in result.output
    # Module entries are compact (title only, no body)
    assert "Module Feature One" in result.output
    assert "Module Bugfix" in result.output
    # Separator between main and modules
    assert "---" in result.output


def test_show_release_module_entries_are_compact(tmp_path: Path) -> None:
    """Module entries show title and attribution, not body."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Some Feature", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    result = runner.invoke(
        cli, ["--root", str(project_dir), "show", "--release", "-m", "unreleased"]
    )

    assert result.exit_code == 0
    # Module entry appears as bullet with emoji prefix and title
    assert "- 🚀 Some Feature" in result.output
    # Attribution appears
    assert "testuser" in result.output
    # Body text should NOT appear in module section
    # (The body "Entry body text." should not be in the module section)
    lines = result.output.split("## My Module")[1] if "## My Module" in result.output else ""
    assert "Entry body text" not in lines


def test_show_release_excludes_unreleased_module_entries(tmp_path: Path) -> None:
    """Only released module entries are included, not unreleased."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_entry(mod_root, "Unreleased Module Feature")  # Unreleased

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    result = runner.invoke(
        cli, ["--root", str(project_dir), "show", "--release", "-m", "unreleased"]
    )

    assert result.exit_code == 0
    # Parent entry is included
    assert "Parent Feature" in result.output
    # Module with no released entries should not have a section
    assert "## My Module" not in result.output
    # Unreleased module entry should not appear
    assert "Unreleased Module Feature" not in result.output


def test_release_create_from_release_candidate_preserves_module_snapshot(tmp_path: Path) -> None:
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Stable One", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    rc_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v2.0.0", "--rc", "--yes"],
    )
    assert rc_result.exit_code == 0, rc_result.output

    create_released_entry(mod_root, "Module Stable Two", "v1.1.0", "feature")

    promote_result = runner.invoke(
        cli,
        [
            "--root",
            str(project_dir),
            "release",
            "create",
            "--yes",
        ],
    )
    assert promote_result.exit_code == 0, promote_result.output

    manifest_data = yaml.safe_load(
        (project_dir / "releases" / "v2.0.0" / "manifest.yaml").read_text(encoding="utf-8")
    )
    assert manifest_data["modules"] == {"mymod": "v1.0.0"}

    notes = (project_dir / "releases" / "v2.0.0" / "notes.md").read_text(encoding="utf-8")
    assert "## My Module v1.0.0" in notes
    assert "## My Module v1.1.0" not in notes
    assert "Module Stable One" in notes
    assert "Module Stable Two" not in notes

    show_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "v2.0.0", "--release", "-m"],
    )
    assert show_result.exit_code == 0, show_result.output
    assert "## My Module v1.0.0" in show_result.output
    assert "Module Stable One" in show_result.output
    assert "Module Stable Two" not in show_result.output


def test_release_create_from_release_candidate_preserves_empty_module_snapshot(
    tmp_path: Path,
) -> None:
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Stable One", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    rc_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v2.0.0", "--rc", "--yes"],
    )
    assert rc_result.exit_code == 0, rc_result.output

    rc_manifest_path = project_dir / "releases" / "v2.0.0-rc.1" / "manifest.yaml"
    rc_manifest_data = yaml.safe_load(rc_manifest_path.read_text(encoding="utf-8"))
    rc_manifest_data["modules"] = {}
    rc_manifest_path.write_text(yaml.safe_dump(rc_manifest_data, sort_keys=False), encoding="utf-8")

    create_released_entry(mod_root, "Module Stable Two", "v1.1.0", "feature")

    promote_result = runner.invoke(
        cli,
        [
            "--root",
            str(project_dir),
            "release",
            "create",
            "--yes",
        ],
    )
    assert promote_result.exit_code == 0, promote_result.output

    manifest_data = yaml.safe_load(
        (project_dir / "releases" / "v2.0.0" / "manifest.yaml").read_text(encoding="utf-8")
    )
    assert "modules" not in manifest_data

    notes = (project_dir / "releases" / "v2.0.0" / "notes.md").read_text(encoding="utf-8")
    assert "## My Module" not in notes
    assert "Module Stable One" not in notes
    assert "Module Stable Two" not in notes


def test_release_create_edit_existing_release_preserves_module_snapshot(tmp_path: Path) -> None:
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Stable One", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent One")

    runner = CliRunner()
    first_release = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v1.0.0", "--yes"],
    )
    assert first_release.exit_code == 0, first_release.output

    create_released_entry(mod_root, "Module Stable Two", "v1.1.0", "feature")
    create_entry(project_dir, "Parent Two")
    second_release = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v1.1.0", "--yes"],
    )
    assert second_release.exit_code == 0, second_release.output

    edit_release = runner.invoke(
        cli,
        [
            "--root",
            str(project_dir),
            "release",
            "create",
            "v1.0.0",
            "--intro",
            "Updated intro.",
            "--yes",
        ],
    )
    assert edit_release.exit_code == 0, edit_release.output

    notes = (project_dir / "releases" / "v1.0.0" / "notes.md").read_text(encoding="utf-8")
    assert notes.startswith("Updated intro.")
    assert "## My Module v1.0.0" in notes
    assert "Module Stable One" in notes
    assert "## My Module v1.1.0" not in notes
    assert "Module Stable Two" not in notes

    show_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "v1.0.0", "--release", "-m"],
    )
    assert show_result.exit_code == 0, show_result.output
    assert "## My Module v1.0.0" in show_result.output
    assert "Module Stable One" in show_result.output
    assert "## My Module v1.1.0" not in show_result.output
    assert "Module Stable Two" not in show_result.output


def test_release_create_edit_existing_release_preserves_empty_module_snapshot(
    tmp_path: Path,
) -> None:
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Stable One", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent One")

    runner = CliRunner()
    first_release = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v1.0.0", "--yes"],
    )
    assert first_release.exit_code == 0, first_release.output

    manifest_path = project_dir / "releases" / "v1.0.0" / "manifest.yaml"
    manifest_data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    manifest_data["modules"] = {}
    manifest_path.write_text(yaml.safe_dump(manifest_data, sort_keys=False), encoding="utf-8")

    create_released_entry(mod_root, "Module Stable Two", "v1.1.0", "feature")

    edit_release = runner.invoke(
        cli,
        [
            "--root",
            str(project_dir),
            "release",
            "create",
            "v1.0.0",
            "--intro",
            "Updated intro.",
            "--yes",
        ],
    )
    assert edit_release.exit_code == 0, edit_release.output

    updated_manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    assert "modules" not in updated_manifest

    notes = (project_dir / "releases" / "v1.0.0" / "notes.md").read_text(encoding="utf-8")
    assert notes.startswith("Updated intro.")
    assert "## My Module" not in notes
    assert "Module Stable One" not in notes
    assert "Module Stable Two" not in notes


def test_release_create_ignores_module_release_candidates_for_stable_parent(tmp_path: Path) -> None:
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Stable Module Feature", "v1.0.0", "feature")
    create_released_entry(mod_root, "RC Module Feature", "v1.1.0-rc.1", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    release_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v2.0.0", "--yes"],
    )
    assert release_result.exit_code == 0, release_result.output

    notes = (project_dir / "releases" / "v2.0.0" / "notes.md").read_text(encoding="utf-8")
    assert "## My Module v1.0.0" in notes
    assert "Stable Module Feature" in notes
    assert "RC Module Feature" not in notes

    show_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "v2.0.0", "--release", "-m"],
    )
    assert show_result.exit_code == 0, show_result.output
    assert "## My Module v1.0.0" in show_result.output
    assert "Stable Module Feature" in show_result.output
    assert "RC Module Feature" not in show_result.output


def test_release_create_release_candidate_includes_module_release_candidates(
    tmp_path: Path,
) -> None:
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Stable Module Feature", "v1.0.0", "feature")
    create_released_entry(mod_root, "RC Module Feature", "v1.1.0-rc.1", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    rc_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v2.0.0", "--rc", "--yes"],
    )
    assert rc_result.exit_code == 0, rc_result.output

    rc_manifest_data = yaml.safe_load(
        (project_dir / "releases" / "v2.0.0-rc.1" / "manifest.yaml").read_text(encoding="utf-8")
    )
    assert rc_manifest_data["modules"] == {"mymod": "v1.1.0-rc.1"}

    rc_notes = (project_dir / "releases" / "v2.0.0-rc.1" / "notes.md").read_text(encoding="utf-8")
    assert "## My Module v1.1.0-rc.1" in rc_notes
    assert "RC Module Feature" in rc_notes

    rc_show_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "v2.0.0-rc.1", "--release", "-m"],
    )
    assert rc_show_result.exit_code == 0, rc_show_result.output
    assert "## My Module v1.1.0-rc.1" in rc_show_result.output
    assert "RC Module Feature" in rc_show_result.output

    promote_result = runner.invoke(
        cli,
        [
            "--root",
            str(project_dir),
            "release",
            "create",
            "--yes",
        ],
    )
    assert promote_result.exit_code == 0, promote_result.output

    stable_manifest_data = yaml.safe_load(
        (project_dir / "releases" / "v2.0.0" / "manifest.yaml").read_text(encoding="utf-8")
    )
    assert stable_manifest_data["modules"] == {"mymod": "v1.1.0-rc.1"}

    stable_notes = (project_dir / "releases" / "v2.0.0" / "notes.md").read_text(encoding="utf-8")
    assert "## My Module v1.1.0-rc.1" in stable_notes
    assert "RC Module Feature" in stable_notes

    stable_show_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "v2.0.0", "--release", "-m"],
    )
    assert stable_show_result.exit_code == 0, stable_show_result.output
    assert "## My Module v1.1.0-rc.1" in stable_show_result.output
    assert "RC Module Feature" in stable_show_result.output


def test_show_latest_release_includes_modules(tmp_path: Path) -> None:
    """Released-scope show output includes module sections for the latest release."""
    import json

    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Feature", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    release_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v2.0.0", "--yes"],
    )
    assert release_result.exit_code == 0, release_result.output

    markdown_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "latest", "--release", "-m"],
    )
    assert markdown_result.exit_code == 0, markdown_result.output
    assert "v2.0.0" in markdown_result.output
    assert "## My Module v1.0.0" in markdown_result.output
    assert "Module Feature" in markdown_result.output

    json_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "latest", "--release", "-j"],
    )
    assert json_result.exit_code == 0, json_result.output
    data = json.loads(json_result.output)
    assert len(data) == 1
    release = data[0]
    assert release["version"] == "v2.0.0"
    assert release["modules"][0]["id"] == "mymod"
    assert release["modules"][0]["entries"][0]["title"] == "Module Feature"


def test_show_release_preserves_empty_module_snapshot(tmp_path: Path) -> None:
    """Historical show output keeps empty module snapshots empty."""
    import json

    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Stable One", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    release_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "release", "create", "v2.0.0", "--yes"],
    )
    assert release_result.exit_code == 0, release_result.output

    manifest_path = project_dir / "releases" / "v2.0.0" / "manifest.yaml"
    manifest_data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    manifest_data["modules"] = {}
    manifest_path.write_text(yaml.safe_dump(manifest_data, sort_keys=False), encoding="utf-8")

    create_released_entry(mod_root, "Module Stable Two", "v1.1.0", "feature")

    markdown_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "v2.0.0", "--release", "-m"],
    )
    assert markdown_result.exit_code == 0, markdown_result.output
    assert "## My Module" not in markdown_result.output
    assert "Module Stable One" not in markdown_result.output
    assert "Module Stable Two" not in markdown_result.output

    json_result = runner.invoke(
        cli,
        ["--root", str(project_dir), "show", "v2.0.0", "--release", "-j"],
    )
    assert json_result.exit_code == 0, json_result.output
    data = json.loads(json_result.output)
    assert len(data) == 1
    release = data[0]
    assert "modules" not in release


def test_show_release_json_includes_modules(tmp_path: Path) -> None:
    """JSON output includes modules array with released entries."""
    import json

    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")
    create_released_entry(mod_root, "Module Feature", "v1.0.0", "feature")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Parent Feature")

    runner = CliRunner()
    result = runner.invoke(
        cli, ["--root", str(project_dir), "show", "--release", "-j", "unreleased"]
    )

    assert result.exit_code == 0
    data = json.loads(result.output)
    # With --release, output is array
    assert isinstance(data, list)
    assert len(data) == 1
    release = data[0]
    assert "modules" in release
    assert len(release["modules"]) == 1
    assert release["modules"][0]["id"] == "mymod"
    assert release["modules"][0]["name"] == "My Module"
    assert len(release["modules"][0]["entries"]) == 1
    assert release["modules"][0]["entries"][0]["title"] == "Module Feature"


def test_show_release_no_modules_no_separator(tmp_path: Path) -> None:
    """When no modules exist, no separator is added."""
    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(project_dir / "config.yaml", {"id": "test", "name": "Test"})
    (project_dir / "unreleased").mkdir()
    create_entry(project_dir, "Test Feature")

    runner = CliRunner()
    result = runner.invoke(
        cli, ["--root", str(project_dir), "show", "--release", "-m", "unreleased"]
    )

    assert result.exit_code == 0
    assert "Test Feature" in result.output
    # No separator when no modules
    assert "---" not in result.output


def create_entry_with_timestamp(
    module_root: Path, title: str, timestamp: str, entry_type: str = "feature"
) -> Path:
    """Create a changelog entry with a specific timestamp."""
    slug = title.lower().replace(" ", "-")
    entry_path = module_root / "unreleased" / f"{slug}.md"
    entry_path.write_text(
        f"---\ntitle: {title}\ntype: {entry_type}\ncreated: {timestamp}\n---\n\nBody.\n",
        encoding="utf-8",
    )
    return entry_path


def test_cli_show_multi_project_sorts_entries_oldest_first(tmp_path: Path) -> None:
    """Multi-project show command sorts entries oldest-first within each project."""
    packages = tmp_path / "packages"
    mod_root = create_module(packages, "mymod", "My Module")

    # Create module entries with different timestamps (out of order)
    create_entry_with_timestamp(mod_root, "Newest Module Entry", "2025-01-03T00:00:00Z")
    create_entry_with_timestamp(mod_root, "Oldest Module Entry", "2025-01-01T00:00:00Z")
    create_entry_with_timestamp(mod_root, "Middle Module Entry", "2025-01-02T00:00:00Z")

    project_dir = tmp_path / "changelog"
    project_dir.mkdir()
    write_yaml(
        project_dir / "config.yaml",
        {"id": "parent", "name": "Parent", "modules": "../packages/*/changelog"},
    )
    (project_dir / "unreleased").mkdir()

    # Create parent entries with different timestamps (out of order)
    create_entry_with_timestamp(project_dir, "Newest Parent Entry", "2025-01-03T00:00:00Z")
    create_entry_with_timestamp(project_dir, "Oldest Parent Entry", "2025-01-01T00:00:00Z")
    create_entry_with_timestamp(project_dir, "Middle Parent Entry", "2025-01-02T00:00:00Z")

    runner = CliRunner()
    result = runner.invoke(cli, ["--root", str(project_dir), "show"])

    assert result.exit_code == 0

    # Find positions of entries in output to verify ordering
    output = result.output
    parent_oldest = output.find("Oldest Parent Entry")
    parent_middle = output.find("Middle Parent Entry")
    parent_newest = output.find("Newest Parent Entry")
    module_oldest = output.find("Oldest Module Entry")
    module_middle = output.find("Middle Module Entry")
    module_newest = output.find("Newest Module Entry")

    # Verify all entries are present
    assert parent_oldest != -1, "Oldest Parent Entry not found"
    assert parent_middle != -1, "Middle Parent Entry not found"
    assert parent_newest != -1, "Newest Parent Entry not found"
    assert module_oldest != -1, "Oldest Module Entry not found"
    assert module_middle != -1, "Middle Module Entry not found"
    assert module_newest != -1, "Newest Module Entry not found"

    # Within parent project: oldest should appear before middle, middle before newest
    assert parent_oldest < parent_middle < parent_newest, "Parent entries not sorted oldest-first"

    # Within module project: oldest should appear before middle, middle before newest
    assert module_oldest < module_middle < module_newest, "Module entries not sorted oldest-first"
