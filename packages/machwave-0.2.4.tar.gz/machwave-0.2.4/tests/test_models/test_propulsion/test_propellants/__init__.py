"""Tests for propellant module."""
