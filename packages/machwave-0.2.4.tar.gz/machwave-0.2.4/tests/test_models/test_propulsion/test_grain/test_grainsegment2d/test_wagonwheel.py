import pytest

from machwave.models.grain import GrainGeometryError
from machwave.models.grain.geometries import (
    WagonWheelGrainSegment,
)


def test_star_segment_geometry_validation():
    # Control group:
    _ = WagonWheelGrainSegment(
        outer_diameter=41e-3,
        length=0.5,
        core_diameter=8e-3,
        number_of_ports=6,
        port_inner_diameter=15e-3,
        port_outer_diameter=35e-3,
        port_angular_width=45,
    )

    # Negative core diameter:
    with pytest.raises(GrainGeometryError):
        _ = WagonWheelGrainSegment(
            outer_diameter=41e-3,
            length=0.5,
            core_diameter=-8e-3,
            number_of_ports=-1,
            port_inner_diameter=15e-3,
            port_outer_diameter=35e-3,
            port_angular_width=45,
        )

    # Port inner diameter smaller than core diameter:
    with pytest.raises(GrainGeometryError):
        _ = WagonWheelGrainSegment(
            outer_diameter=41e-3,
            length=0.5,
            core_diameter=8e-3,
            number_of_ports=-1,
            port_inner_diameter=7e-3,
            port_outer_diameter=35e-3,
            port_angular_width=45,
        )

    # Port outer diameter smaller than inner diameter:
    with pytest.raises(GrainGeometryError):
        _ = WagonWheelGrainSegment(
            outer_diameter=41e-3,
            length=0.5,
            core_diameter=8e-3,
            number_of_ports=-1,
            port_inner_diameter=15e-3,
            port_outer_diameter=12e-3,
            port_angular_width=45,
        )

    # Negative number of ports:
    with pytest.raises(GrainGeometryError):
        _ = WagonWheelGrainSegment(
            outer_diameter=41e-3,
            length=0.5,
            core_diameter=8e-3,
            number_of_ports=-1,
            port_inner_diameter=15e-3,
            port_outer_diameter=35e-3,
            port_angular_width=45,
        )

    # Too many points:
    with pytest.raises(GrainGeometryError):
        _ = WagonWheelGrainSegment(
            outer_diameter=41e-3,
            length=0.5,
            core_diameter=8e-3,
            number_of_ports=13,
            port_inner_diameter=15e-3,
            port_outer_diameter=35e-3,
            port_angular_width=45,
        )

    # Negative port angle:
    with pytest.raises(GrainGeometryError):
        _ = WagonWheelGrainSegment(
            outer_diameter=41e-3,
            length=0.5,
            core_diameter=8e-3,
            number_of_ports=6,
            port_inner_diameter=15e-3,
            port_outer_diameter=35e-3,
            port_angular_width=-1,
        )

    # Port angle too large:
    with pytest.raises(GrainGeometryError):
        _ = WagonWheelGrainSegment(
            outer_diameter=41e-3,
            length=0.5,
            core_diameter=8e-3,
            number_of_ports=6,
            port_inner_diameter=15e-3,
            port_outer_diameter=35e-3,
            port_angular_width=61,
        )
