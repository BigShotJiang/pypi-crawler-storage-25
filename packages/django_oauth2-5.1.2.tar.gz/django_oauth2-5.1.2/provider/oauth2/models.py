"""
Default model implementations. Custom database or OAuth backends need to
implement these models with fields and and methods to be compatible with the
views in :attr:`provider.views`.
"""
from base64 import urlsafe_b64encode
from hashlib import sha256

from django.db import models
from django.db.models import Q
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import check_password
from django.utils import timezone

from provider import constants
from provider.constants import CLIENT_TYPES, TOKEN_PREFIX_LENGTH
from provider.utils import (
    now, short_token, long_token, get_code_expiry, client_secret_description,
    get_token_expiry, make_client_secret,
)


class Client(models.Model):
    """
    Default client implementation.

    Expected fields:

    * :attr:`user`
    * :attr:`name`
    * :attr:`url`
    * :attr:`redirect_url`
    * :attr:`client_id`
    * :attr:`client_secret`
    * :attr:`client_type`

    Clients are outlined in the :rfc:`2` and its subsections.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, models.DO_NOTHING, related_name='oauth2_client',
        blank=True, null=True)
    name = models.CharField(max_length=255, blank=True)
    url = models.URLField(help_text="Your application's URL.")
    redirect_uri = models.URLField(help_text="Your application's callback URL")
    client_id = models.CharField(max_length=255, default=short_token)
    client_secret = models.CharField(max_length=255, default=long_token)
    client_type = models.IntegerField(choices=CLIENT_TYPES)
    auto_authorize = models.BooleanField(default=False, blank=True)
    authorize_every_time = models.BooleanField(default=False, blank=True)
    allow_public_token = models.BooleanField(default=False, blank=True,
                                             help_text="Allow public client tokens with only client_id and code")
    allow_plain_pkce = models.BooleanField(default=False, blank=True,
                                           help_text="Allow code_challenge_method=plain for PKCE")
    token_expiry = models.IntegerField(blank=True, null=True,
                                       help_text="Token expiration timeout. Defaults to OAUTH_EXPIRE_DELTA_PUBLIC or OAUTH_EXPIRE_DELTA")

    def __str__(self):
        return self.redirect_uri

    def get_default_token_expiry(self):
        public = (self.client_type == constants.PUBLIC)
        expiration = self.token_expiry or get_token_expiry(public)
        if isinstance(expiration, timezone.timedelta):
            return now() + expiration
        elif isinstance(expiration, int):
            return now() + timezone.timedelta(seconds=expiration)
        elif isinstance(expiration, timezone.datetime):
            return expiration
        else:
            raise ValueError("Invalid token_expiry value for client %s: %s" % (self.client_id, expiration))

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_client'


class ClientSecretManager(models.Manager):
    def new_random_secret(self, client, expiration_date=None):
        new_secret, prefix, secret_hash = make_client_secret()
        client_secret = self.create(
            client=client,
            secret_prefix=prefix,
            secret_hash=secret_hash,
            expiration_date=expiration_date,
        )
        return client_secret, new_secret


    def get_by_secret(self, client, secret):
        if not secret or not client:
            return self.none().get()

        if isinstance(client, Client):
            client_pk=client.pk
        else:
            client_pk=client

        prefix = secret[:6]
        selector = Q(client__client_id=client_pk, secret_prefix=prefix)
        not_expired = Q(expiration_date__isnull=True) | Q(expiration_date__gte=now().date())
        for record in self.filter(selector & not_expired):
            if check_password(secret, record.secret_hash):
                return record

        # Get from an empty queryset to raise a DoesNotExist exception
        return self.none().get()


class ClientSecret(models.Model):
    description = models.CharField(max_length=255, default=client_secret_description)
    client = models.ForeignKey('Client', models.CASCADE)
    secret_prefix = models.CharField(max_length=6, db_index=True)
    secret_hash = models.CharField(max_length=255)
    expiration_date = models.DateField(null=True, blank=True)

    objects = ClientSecretManager()

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_clientsecret'

    def __str__(self):
        return f"{self.client.client_id}: {self.secret_prefix}..."


class Scope(models.Model):
    name = models.CharField(max_length=50, primary_key=True)
    description = models.CharField(max_length=256, default='', blank=True)

    def __str__(self):
        return self.name

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_scope'


class AuthorizedClientManager(models.Manager):
    def get_authorization(self, user, client):
        return self.get(user=user, client=client)

    def check_authorization_scope(self, user, client, scope_list):
        try:
            authorization = self.get_authorization(user, client)
        except AuthorizedClient.DoesNotExist:
            return None
        authorized_scopes = {s.name for s in authorization.scope.all()}
        if set(scope_list) <= authorized_scopes:
            return authorization
        return None

    def set_authorization_scope(self, user, client, scope_list):
        try:
            authorization = self.get_authorization(user, client)
        except AuthorizedClient.DoesNotExist:
            authorization = self.create(user=user, client=client)
            authorization.save()
        for s in scope_list:
            authorization.scope.add(s)
        return authorization


class AuthorizedClient(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, models.DO_NOTHING,
                             related_name='oauth2_authorized_client')
    client = models.ForeignKey('Client', models.DO_NOTHING)
    scope = models.ManyToManyField('Scope')
    authorized_at = models.DateTimeField(auto_now_add=True, blank=True)

    objects = AuthorizedClientManager()

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_authorizedclient'
        unique_together = ['user', 'client']


class Grant(models.Model):
    """
    Default grant implementation. A grant is a code that can be swapped for an
    access token. Grants have a limited lifetime as defined by
    :attr:`provider.constants.EXPIRE_CODE_DELTA` and outlined in
    :rfc:`4.1.2`

    Expected fields:

    * :attr:`user`
    * :attr:`client` - :class:`Client`
    * :attr:`code`
    * :attr:`expires` - :attr:`datetime.datetime`
    * :attr:`redirect_uri`
    * :attr:`scope`
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, models.DO_NOTHING)
    client = models.ForeignKey('Client', models.DO_NOTHING)
    code = models.CharField(max_length=255, default=long_token)
    expires = models.DateTimeField(default=get_code_expiry)
    redirect_uri = models.CharField(max_length=255, blank=True)
    scope = models.ManyToManyField('Scope')
    code_challenge = models.CharField(max_length=255, blank=True, null=True)
    code_challenge_method = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return self.code

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_grant'

    def verify_code_challenge(self, code_verifier):
        if not code_verifier:
            return False
        if self.code_challenge_method == 'plain':
            return code_verifier == self.code_challenge
        else:
            verifier_digest = sha256(code_verifier.encode('ASCII')).digest()
            expected = urlsafe_b64encode(verifier_digest).decode()
            return expected == self.code_challenge


class AccessTokenManager(models.Manager):
    def get_token(self, token):
        filters = dict(expires__gt=now())
        for candidate in self.filter(token_prefix=token[:TOKEN_PREFIX_LENGTH], **filters):
            if check_password(token, candidate.token):
                return self.get(pk=candidate.pk)

        return self.none().get()


class AccessToken(models.Model):
    """
    Default access token implementation. An access token is a time limited
    token to access a user's resources.

    Access tokens are outlined :rfc:`5`.

    Expected fields:

    * :attr:`user`
    * :attr:`token`
    * :attr:`client` - :class:`Client`
    * :attr:`expires` - :attr:`datetime.datetime`
    * :attr:`scope`

    Expected methods:

    * :meth:`get_expire_delta` - returns an integer representing seconds to
        expiry
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, models.DO_NOTHING)
    token_prefix = models.CharField(max_length=10, null=True, blank=True, db_index=True)
    token = models.CharField(max_length=255, default=long_token, db_index=True)
    client = models.ForeignKey('Client', models.DO_NOTHING)
    expires = models.DateTimeField()
    scope = models.ManyToManyField('Scope')

    objects = AccessTokenManager()

    def __str__(self):
        return f"{self.token_prefix}:{self.token[:25]}"

    def save(self, *args, **kwargs):
        if not self.expires:
            self.expires = self.client.get_default_token_expiry()
        super(AccessToken, self).save(*args, **kwargs)

    def get_expire_delta(self, reference=None):
        """
        Return the number of seconds until this token expires.
        """
        if reference is None:
            reference = now()
        expiration = self.expires

        if timezone:
            if timezone.is_aware(reference) and timezone.is_naive(expiration):
                # MySQL doesn't support timezone for datetime fields
                # so we assume that the date was stored in the UTC timezone
                expiration = timezone.make_aware(expiration, timezone.utc)
            elif timezone.is_naive(reference) and timezone.is_aware(expiration):
                reference = timezone.make_aware(reference, timezone.utc)

        timedelta = expiration - reference
        return timedelta.days*86400 + timedelta.seconds

    def get_scope_string(self):
        names = [s.name for s in self.scope.all()]
        names.sort()
        return ' '.join(names)

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_accesstoken'


class RefreshTokenManager(models.Manager):
    def create(self, scope=None, *args, **kwargs):
        obj = super(RefreshTokenManager, self).create(*args, **kwargs)
        obj.save()
        if not scope:
            scope = list()
        for s in scope:
            obj.scope.add(s)
        return obj

    def get_token(self, token, **filters):
        for candidate in self.filter(token_prefix=token[:TOKEN_PREFIX_LENGTH], **filters):
            if check_password(token, candidate.token):
                return self.get(pk=candidate.pk)
        return self.none().get()


class RefreshToken(models.Model):
    """
    Default refresh token implementation. A refresh token can be swapped for a
    new access token when said token expires.

    Expected fields:

    * :attr:`user`
    * :attr:`token`
    * :attr:`access_token` - :class:`AccessToken`
    * :attr:`client` - :class:`Client`
    * :attr:`expired` - ``boolean``
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, models.DO_NOTHING)
    token_prefix = models.CharField(max_length=10, null=True, blank=True, db_index=True)
    token = models.CharField(max_length=255, default=long_token)
    access_token = models.OneToOneField('AccessToken', models.DO_NOTHING,
            related_name='refresh_token')
    client = models.ForeignKey('Client', models.DO_NOTHING)
    expired = models.BooleanField(default=False)

    objects = RefreshTokenManager()

    def __str__(self):
        return f"{self.token_prefix}:{self.token[:25]}"

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_refreshtoken'


class AwsAccount(models.Model):
    arn = models.CharField(max_length=255, unique=True, help_text="AWS User or Role ARN")
    general_type = models.CharField(max_length=15, blank=True, null=True)
    account_id = models.CharField(max_length=12, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)

    client = models.ForeignKey('Client', models.DO_NOTHING)
    autoprovision_user = models.BooleanField(default=True, help_text="Automatically create acting user on first use")
    acting_user = models.ForeignKey(settings.AUTH_USER_MODEL, models.DO_NOTHING, blank=True, null=True)
    max_token_lifetime = models.IntegerField(default=3600, blank=True, help_text="Maximum access token lifetime in seconds")
    scope = models.ManyToManyField("Scope", help_text="Scopes to be applied to tokens")

    class Meta:
        app_label = 'oauth2'
        db_table = 'oauth2_awsaccount'
        unique_together = (
            ('general_type', 'account_id', 'name'),
        )

    def get_or_create_user(self):
        if self.acting_user is not None:
            return self.acting_user

        if self.autoprovision_user:
            username = f"{self.name}_{self.general_type}_{self.account_id}"
            User = get_user_model()
            self.acting_user, _ = User.objects.get_or_create(username=username)
            self.save()
            return self.acting_user
