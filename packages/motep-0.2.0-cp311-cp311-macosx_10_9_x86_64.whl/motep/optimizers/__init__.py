"""Module for `Optimizer` classes."""

from motep.optimizers.base import ParallelOptimizerBase
from motep.optimizers.ga import GeneticAlgorithmOptimizer
from motep.optimizers.ideal import NoInteractionOptimizer
from motep.optimizers.level2mtp import Level2MTPOptimizer
from motep.optimizers.lls import LLSOptimizer
from motep.optimizers.randomizer import Randomizer
from motep.optimizers.scipy import (
    ScipyDifferentialEvolutionOptimizer,
    ScipyDualAnnealingOptimizer,
    ScipyMinimizeOptimizer,
)


def make_optimizer(optimizer: str) -> type[ParallelOptimizerBase]:
    """Make an `Optimizer` class.

    Returns
    -------
    type[ParallelOptimizerBase]

    """
    return {
        "GA": GeneticAlgorithmOptimizer,
        "NI": NoInteractionOptimizer,
        "Level2MTP": Level2MTPOptimizer,
        "minimize": ScipyMinimizeOptimizer,
        "DA": ScipyDualAnnealingOptimizer,
        "DE": ScipyDifferentialEvolutionOptimizer,
        "LLS": LLSOptimizer,
        "randomize": Randomizer,
    }[optimizer]
