import numba as nb
import numpy as np
import numpy.typing as npt


@nb.njit((nb.int32, nb.float64[:, :], nb.float64[:]))
def update_mbd_vatoms(
    i: np.int32,
    mbd_vatoms: npt.NDArray[np.float64],
    basis_values: npt.NDArray[np.float64],
) -> None:
    for iamc in range(mbd_vatoms.shape[0]):
        mbd_vatoms[iamc, i] += basis_values[iamc]


@nb.njit((nb.int32, nb.int32[:], nb.float64[:, :, :], nb.float64[:, :, :]))
def update_mbd_dbdris(
    i: np.int32,
    js: npt.NDArray[np.int32],
    mbd_dbdris: npt.NDArray[np.float64],
    basis_jac_rs: npt.NDArray[np.float64],
) -> None:
    for iamc in range(mbd_dbdris.shape[0]):
        for k, j in enumerate(js):
            for ixyz0 in range(3):
                mbd_dbdris[iamc, i, ixyz0] -= basis_jac_rs[iamc, k, ixyz0]
                mbd_dbdris[iamc, j, ixyz0] += basis_jac_rs[iamc, k, ixyz0]


@nb.njit((nb.int32[:], nb.float64[:, :], nb.float64[:, :, :], nb.float64[:, :, :]))
def update_mbd_dbdeps(
    js: npt.NDArray[np.int32],
    r_ijs: npt.NDArray[np.float64],
    mbd_dbdeps: npt.NDArray[np.float64],
    basis_jac_rs: npt.NDArray[np.float64],
) -> None:
    for iamc in range(mbd_dbdeps.shape[0]):
        for k in range(js.size):
            for ixyz0 in range(3):
                for ixyz1 in range(3):
                    mbd_dbdeps[iamc, ixyz0, ixyz1] += (
                        r_ijs[k, ixyz0] * basis_jac_rs[iamc, k, ixyz1]
                    )


@nb.njit((nb.int32, nb.int32, nb.float64[:, :, :, :, :], nb.float64[:, :, :]))
def update_mbd_dvdcs(
    i: np.int32,
    itype: np.int32,
    mbd_dvdcs: npt.NDArray[np.float64],
    tmp_dvdcs: npt.NDArray[np.float64],
) -> None:
    _, s1, s2, s3, _ = mbd_dvdcs.shape
    for i1 in range(s1):
        for i2 in range(s2):
            for i3 in range(s3):
                mbd_dvdcs[itype, i1, i2, i3, i] += tmp_dvdcs[i1, i2, i3]


@nb.njit(
    (
        nb.int32,
        nb.int32,
        nb.int32[:],
        nb.float64[:, :, :, :, :, :],
        nb.float64[:, :, :, :, :],
    ),
)
def update_mbd_dgdcs(
    i: np.int32,
    itype: np.int32,
    js: npt.NDArray[np.int32],
    mbd_dgdcs: npt.NDArray[np.float64],
    tmp_dgdcs: npt.NDArray[np.float64],
) -> None:
    s1, s2, s3 = mbd_dgdcs.shape[1:4]
    for i1 in range(s1):
        for i2 in range(s2):
            for i3 in range(s3):
                for k, j in enumerate(js):
                    for ixyz0 in range(3):
                        v = tmp_dgdcs[i1, i2, i3, k, ixyz0]
                        mbd_dgdcs[itype, i1, i2, i3, i, ixyz0] -= v
                        mbd_dgdcs[itype, i1, i2, i3, j, ixyz0] += v


@nb.njit(
    (
        nb.int32,
        nb.int32[:],
        nb.float64[:, :],
        nb.float64[:, :, :, :, :, :],
        nb.float64[:, :, :, :, :],
    ),
)
def update_mbd_dsdcs(
    itype: np.int32,
    js: npt.NDArray[np.int32],
    r_ijs: npt.NDArray[np.float64],
    mbd_dsdcs: npt.NDArray[np.float64],
    tmp_dgdcs: npt.NDArray[np.float64],
) -> None:
    s1, s2, s3 = mbd_dsdcs.shape[1:4]
    for i1 in range(s1):  # noqa: PLR1702
        for i2 in range(s2):
            for i3 in range(s3):
                for k in range(js.size):
                    for ixyz0 in range(3):
                        for ixyz1 in range(3):
                            v = r_ijs[k, ixyz0] * tmp_dgdcs[i1, i2, i3, k, ixyz1]
                            mbd_dsdcs[itype, i1, i2, i3, ixyz0, ixyz1] += v


@nb.njit
def _calc_r_unit_pows(r_unit: np.ndarray, max_pow: int) -> np.ndarray:
    number_of_js = r_unit.shape[0]
    r_unit_pows = np.ones((max_pow + 1, number_of_js, 3))
    for pow in range(1, max_pow + 1):
        for j in range(number_of_js):
            for k in range(3):
                r_unit_pows[pow, j, k] = r_unit_pows[pow - 1, j, k] * r_unit[j, k]
    return r_unit_pows


@nb.njit(
    (
        nb.float64[:],
        nb.float64[:, :],
        nb.int32[:, :],
        nb.float64[:, :],
        nb.float64[:, :],
        nb.float64[:],
        nb.float64[:, :, :],
    ),
)
def _calc_moment_basic(
    r_abs,
    r_ijs_unit,
    alpha_index_basic,
    rb_values,
    rb_derivs,
    moment_values,
    moment_jac_rs,
) -> None:
    """Compute basic moment components and its jacobian wrt `r_ijs`."""
    # Precompute powers
    max_pow = int(np.max(alpha_index_basic))
    r_unit_pows = _calc_r_unit_pows(r_ijs_unit, max_pow)

    for i_aib, aib in enumerate(alpha_index_basic):
        mu, xpow, ypow, zpow = aib
        xyzpow = xpow + ypow + zpow
        for j in range(r_abs.size):
            mult0 = 1.0
            mult0 *= r_unit_pows[xpow, j, 0]
            mult0 *= r_unit_pows[ypow, j, 1]
            mult0 *= r_unit_pows[zpow, j, 2]
            moment_values[i_aib] += rb_values[mu, j] * mult0
            for k in range(3):
                moment_jac_rs[i_aib, j, k] = (
                    r_ijs_unit[j, k]
                    * mult0
                    * (rb_derivs[mu, j] - xyzpow * rb_values[mu, j] / r_abs[j])
                )
            if xpow != 0:
                moment_jac_rs[i_aib, j, 0] += (
                    rb_values[mu, j]
                    * (xpow * r_unit_pows[xpow - 1, j, 0])
                    * r_unit_pows[ypow, j, 1]
                    * r_unit_pows[zpow, j, 2]
                    / r_abs[j]
                )
            if ypow != 0:
                moment_jac_rs[i_aib, j, 1] += (
                    rb_values[mu, j]
                    * r_unit_pows[xpow, j, 0]
                    * (ypow * r_unit_pows[ypow - 1, j, 1])
                    * r_unit_pows[zpow, j, 2]
                    / r_abs[j]
                )
            if zpow != 0:
                moment_jac_rs[i_aib, j, 2] += (
                    rb_values[mu, j]
                    * r_unit_pows[xpow, j, 0]
                    * r_unit_pows[ypow, j, 1]
                    * (zpow * r_unit_pows[zpow - 1, j, 2])
                    / r_abs[j]
                )


@nb.njit((nb.int32[:, :], nb.float64[:], nb.float64[:, :, :]))
def _contract_moments(
    alpha_index_times: npt.NDArray[np.int32],
    moment_values: npt.NDArray[np.float64],
    moment_jac_rs: npt.NDArray[np.float64],
) -> None:
    """Compute moment contractions."""
    # Contract the moment values
    for ait in alpha_index_times:
        i1, i2, mult, i3 = ait
        moment_values[i3] += mult * moment_values[i1] * moment_values[i2]

    # Contract the jacobians of all moment components
    for ait in alpha_index_times:
        i1, i2, mult, i3 = ait
        for j in range(moment_jac_rs.shape[1]):
            for k in range(3):
                moment_jac_rs[i3, j, k] += mult * (
                    moment_jac_rs[i1, j, k] * moment_values[i2]
                    + moment_values[i1] * moment_jac_rs[i2, j, k]
                )


@nb.njit(
    nb.float64[:, :](
        nb.int32[:, :],
        nb.int32[:, :],
        nb.int32[:],
        nb.float64[:],
        nb.float64[:],
        nb.float64[:, :, :],
    ),
)
def _contract_moments_backwards(
    alpha_index_basic,
    alpha_index_times,
    alpha_moment_mapping,
    moment_coeffs,
    moment_values,
    moment_jac_rs,
):
    """Compute moment contractions.

    Propagates backwards for the gradient and returns it without computing all
    moment jacobians. This speeds up around 4 times for level 20.

    """
    # First do the values as usual.
    for i1, i2, mult, i3 in alpha_index_times:
        moment_values[i3] += mult * moment_values[i1] * moment_values[i2]

    amc, njs, _ = moment_jac_rs.shape
    # Now go backwards for the jacobians/gradient
    tmp_moment_ders = np.zeros(amc)
    tmp_moment_ders[alpha_moment_mapping] = moment_coeffs
    for i1, i2, mult, i3 in alpha_index_times[::-1]:
        tmp_moment_ders[i2] += tmp_moment_ders[i3] * mult * moment_values[i1]
        tmp_moment_ders[i1] += tmp_moment_ders[i3] * mult * moment_values[i2]

    gradient = np.zeros((njs, 3))
    for aib_i in range(alpha_index_basic.shape[0]):
        for j in range(njs):
            for k in range(3):
                gradient[j, k] += tmp_moment_ders[aib_i] * moment_jac_rs[aib_i, j, k]

    return gradient


@nb.njit(
    nb.types.Tuple((nb.float64[:], nb.float64[:, :]))(
        nb.float64[:, :],
        nb.float64[:],
        nb.float64[:, :],
        nb.float64[:, :],
        nb.int32,
        nb.int32[:],
        nb.int32[:, :],
        nb.int32[:, :],
        nb.float64[:],
    ),
)
def calc_moments_run(
    r_ijs_unit: npt.NDArray[np.float64],
    r_abs: npt.NDArray[np.float64],
    rb_values: npt.NDArray[np.float64],
    rb_derivs: npt.NDArray[np.float64],
    alpha_moments_count: np.int32,
    alpha_moment_mapping: npt.NDArray[np.int32],
    alpha_index_basic: npt.NDArray[np.int32],
    alpha_index_times: npt.NDArray[np.int32],
    moment_coeffs: npt.NDArray[np.float64],
) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64]]:
    amc = alpha_moments_count
    moment_values = np.zeros(amc)
    moment_jac_rs = np.zeros((amc, *r_ijs_unit.shape))

    _calc_moment_basic(
        r_abs,
        r_ijs_unit,
        alpha_index_basic,
        rb_values,
        rb_derivs,
        moment_values,
        moment_jac_rs,
    )

    gradient = _contract_moments_backwards(
        alpha_index_basic,
        alpha_index_times,
        alpha_moment_mapping,
        moment_coeffs,
        moment_values,
        moment_jac_rs,
    )

    return moment_values[alpha_moment_mapping], gradient


@nb.njit(
    (
        nb.int32,
        nb.int32[:],
        nb.float64[:],
        nb.float64[:, :],
        nb.int32[:, :],
        nb.float64[:, :],
        nb.float64[:, :],
        nb.float64[:, :, :, :],
        nb.float64[:],
        nb.float64[:, :, :],
        nb.float64[:, :, :, :],
        nb.float64[:, :, :, :, :, :],
    ),
)
def _calc_moment_basic_with_jacobian_radial_coeffs(
    itype,
    jtypes,
    r_abs: np.ndarray,
    r_ijs_unit: np.ndarray,
    alpha_index_basic: np.ndarray,
    rb_values: np.ndarray,
    rb_derivs: np.ndarray,
    rb_coeffs: np.ndarray,
    moment_values: np.ndarray,
    moment_jac_rs: np.ndarray,
    moment_jac_cs: np.ndarray,
    moment_jac_rc: np.ndarray,
) -> None:
    """Compute basic moment components and its jacobian wrt `r_ijs`."""
    # Precompute powers
    max_pow = int(np.max(alpha_index_basic))
    r_unit_pows = _calc_r_unit_pows(r_ijs_unit, max_pow)

    rbs = rb_coeffs.shape[3]
    der = np.zeros(3)
    for i_aib, aib in enumerate(alpha_index_basic):
        mu, xpow, ypow, zpow = aib
        xyzpow = xpow + ypow + zpow
        for j, jtype in enumerate(jtypes):
            mult0 = 1.0
            mult0 *= r_unit_pows[xpow, j, 0]
            mult0 *= r_unit_pows[ypow, j, 1]
            mult0 *= r_unit_pows[zpow, j, 2]
            for i_rb in range(rbs):
                val = rb_values[i_rb, j] * mult0
                for k in range(3):
                    der[k] = (
                        r_ijs_unit[j, k]
                        * mult0
                        * (rb_derivs[i_rb, j] - xyzpow * rb_values[i_rb, j] / r_abs[j])
                    )
                if xpow != 0:
                    der[0] += (
                        rb_values[i_rb, j]
                        * (xpow * r_unit_pows[xpow - 1, j, 0])
                        * r_unit_pows[ypow, j, 1]
                        * r_unit_pows[zpow, j, 2]
                        / r_abs[j]
                    )
                if ypow != 0:
                    der[1] += (
                        rb_values[i_rb, j]
                        * r_unit_pows[xpow, j, 0]
                        * (ypow * r_unit_pows[ypow - 1, j, 1])
                        * r_unit_pows[zpow, j, 2]
                        / r_abs[j]
                    )
                if zpow != 0:
                    der[2] += (
                        rb_values[i_rb, j]
                        * r_unit_pows[xpow, j, 0]
                        * r_unit_pows[ypow, j, 1]
                        * (zpow * r_unit_pows[zpow - 1, j, 2])
                        / r_abs[j]
                    )
                c = rb_coeffs[itype, jtype, mu, i_rb]

                moment_values[i_aib] += c * val
                for k in range(3):
                    moment_jac_rs[i_aib, j, k] += c * der[k]
                moment_jac_cs[i_aib, jtype, mu, i_rb] += val
                for k in range(3):
                    moment_jac_rc[i_aib, jtype, mu, i_rb, j, k] += der[k]


@nb.njit(nb.float64[:, :, :](nb.int32[:], nb.float64[:], nb.float64[:, :, :, :]))
def _calc_dvdcs(
    alpha_moment_mapping: np.ndarray,
    moment_coeffs: np.ndarray,
    moment_jac_cs: np.ndarray,
) -> np.ndarray:
    spc, rfc, rbs = moment_jac_cs.shape[1:]
    dvdcs = np.zeros((spc, rfc, rbs))
    for i, j in enumerate(alpha_moment_mapping):
        for ispc in range(spc):
            for irfc in range(rfc):
                for irbs in range(rbs):
                    dvdcs[ispc, irfc, irbs] += (
                        moment_jac_cs[j, ispc, irfc, irbs] * moment_coeffs[i]
                    )
    return dvdcs


@nb.njit(
    nb.types.Tuple((nb.float64[:, :, :], nb.float64[:, :, :, :, :]))(
        nb.int32,
        nb.int32[:, :],
        nb.int32[:],
        nb.float64[:],
        nb.float64[:],
        nb.float64[:, :, :],
        nb.float64[:, :, :, :],
        nb.float64[:, :, :, :, :, :],
    ),
)
def _calc_dvdcs_and_dgdcs(
    alpha_index_basic_count: np.int32,
    alpha_index_times: np.ndarray,
    alpha_moment_mapping: np.ndarray,
    moment_coeffs: np.ndarray,
    moment_values: np.ndarray,
    moment_jac_rs: np.ndarray,
    moment_jac_cs: np.ndarray,
    moment_jac_rc: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Calculate dV/dc and d(dV/dr)/dc.

    - dV/dc: Jacobian of site energy to radial basis coefficients
    - d(dV/dr)/dc: Jacobians of site energy gradients to radial basis coefficients

    Returns
    -------
    dvdcs : np.ndarray
        dV/dc.
    dgdcs : np.ndarray
        d(dV/dr)/dc.

    """
    _, spc, rfc, rbs, nns, _ = moment_jac_rc.shape

    dedmb = np.zeros_like(moment_values)
    dgdmb = np.zeros_like(moment_jac_rs)
    dedmb[alpha_moment_mapping] = moment_coeffs  # dV/dB
    for ait in alpha_index_times[::-1]:
        i1, i2, mult, i3 = ait
        dedmb[i1] += mult * dedmb[i3] * moment_values[i2]
        dedmb[i2] += mult * dedmb[i3] * moment_values[i1]
    for ait in alpha_index_times:
        i1, i2, mult, i3 = ait
        for j in range(nns):
            for ixyz0 in range(3):
                dgdmb[i1, j, ixyz0] += mult * dedmb[i3] * moment_jac_rs[i2, j, ixyz0]
                dgdmb[i2, j, ixyz0] += mult * dedmb[i3] * moment_jac_rs[i1, j, ixyz0]
    for ait in alpha_index_times[::-1]:
        i1, i2, mult, i3 = ait
        for j in range(nns):
            for ixyz0 in range(3):
                dgdmb[i1, j, ixyz0] += mult * dgdmb[i3, j, ixyz0] * moment_values[i2]
                dgdmb[i2, j, ixyz0] += mult * dgdmb[i3, j, ixyz0] * moment_values[i1]

    dvdcs = np.zeros((spc, rfc, rbs))
    for iamc in range(alpha_index_basic_count):
        v1 = dedmb[iamc]
        for ispc in range(spc):
            for irfc in range(rfc):
                for irbs in range(rbs):
                    v0 = moment_jac_cs[iamc, ispc, irfc, irbs]
                    dvdcs[ispc, irfc, irbs] += v0 * v1

    dgdcs = np.zeros(moment_jac_rc.shape[1:])
    for iamc in range(alpha_index_basic_count):
        v1 = dedmb[iamc]
        for ispc in range(spc):
            for irfc in range(rfc):
                for irbs in range(rbs):
                    for j in range(nns):
                        for ixyz in range(3):
                            v0 = moment_jac_rc[iamc, ispc, irfc, irbs, j, ixyz]
                            dgdcs[ispc, irfc, irbs, j, ixyz] += v0 * v1
    for iamc in range(alpha_index_basic_count):
        for ispc in range(spc):
            for irfc in range(rfc):
                for irbs in range(rbs):
                    v0 = moment_jac_cs[iamc, ispc, irfc, irbs]
                    for j in range(nns):
                        for ixyz in range(3):
                            v1 = dgdmb[iamc, j, ixyz]
                            dgdcs[ispc, irfc, irbs, j, ixyz] += v0 * v1

    return dvdcs, dgdcs


@nb.njit(
    nb.types.Tuple(
        (
            nb.float64[:],
            nb.float64[:, :, :],
            nb.float64[:, :, :],
            nb.float64[:, :, :, :, :],
        ),
    )(
        nb.int32,
        nb.int32[:],
        nb.float64[:],
        nb.float64[:, :],
        nb.float64[:, :],
        nb.float64[:, :],
        nb.float64[:, :, :, :],
        nb.int32,
        nb.int32[:],
        nb.int32[:, :],
        nb.int32[:, :],
        nb.float64[:],
    ),
)
def calc_moments_train(
    itype,
    jtypes,
    r_abs: np.ndarray,
    r_ijs_unit: np.ndarray,
    rb_values: np.ndarray,
    rb_derivs: np.ndarray,
    rb_coeffs: np.ndarray,
    alpha_moments_count: np.int32,
    alpha_moment_mapping: np.ndarray,
    alpha_index_basic: np.ndarray,
    alpha_index_times: np.ndarray,
    moment_coeffs: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    _, species_count, rfs, rbs = rb_coeffs.shape
    amc = alpha_moments_count
    moment_values = np.zeros(amc)
    moment_jac_rs = np.zeros((amc, *r_ijs_unit.shape))
    moment_jac_cs = np.zeros((amc, species_count, rfs, rbs))
    moment_jac_rc = np.zeros((amc, species_count, rfs, rbs, *r_ijs_unit.shape))

    _calc_moment_basic_with_jacobian_radial_coeffs(
        itype,
        jtypes,
        r_abs,
        r_ijs_unit,
        alpha_index_basic,
        rb_values,
        rb_derivs,
        rb_coeffs,
        moment_values,
        moment_jac_rs,
        moment_jac_cs,
        moment_jac_rc,
    )

    _contract_moments(alpha_index_times, moment_values, moment_jac_rs)

    dvdcs, dgdcs = _calc_dvdcs_and_dgdcs(
        alpha_index_basic.shape[0],
        alpha_index_times,
        alpha_moment_mapping,
        moment_coeffs,
        moment_values,
        moment_jac_rs,
        moment_jac_cs,
        moment_jac_rc,
    )

    return (
        moment_values[alpha_moment_mapping],
        moment_jac_rs[alpha_moment_mapping],
        dvdcs,
        dgdcs,
    )


@nb.njit
def store_radial_basis(
    i: np.int32,
    itype: np.int32,
    js: np.ndarray,
    jtypes: np.ndarray,
    r_ijs: np.ndarray,
    r_ijs_unit: np.ndarray,
    basis_vs: np.ndarray,
    basis_ds: np.ndarray,
    values: np.ndarray,
    dqdris: np.ndarray,
    dqdeps: np.ndarray,
) -> None:
    radial_basis_size = basis_vs.shape[0]
    for ib in range(radial_basis_size):
        for k, j in enumerate(js):
            jtype = jtypes[k]
            values[itype, jtype, ib] += basis_vs[ib, k]
            for ixyz0 in range(3):
                tmp = basis_ds[ib, k] * r_ijs_unit[k, ixyz0]
                dqdris[itype, jtype, ib, i, ixyz0] -= tmp
                dqdris[itype, jtype, ib, j, ixyz0] += tmp
                for ixyz1 in range(3):
                    dqdeps[itype, jtype, ib, ixyz0, ixyz1] += tmp * r_ijs[k, ixyz1]
