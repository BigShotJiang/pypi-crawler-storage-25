"""Jax implementation of MTP."""

from functools import partial

import jax
import jax.numpy as jnp
import numpy as np
import numpy.typing as npt
from ase import Atoms

from motep.potentials.mtp.base import EngineBase
from motep.potentials.mtp.data import MTPData, get_types

from .conversion import BasisConverter, moments_count_to_level_map
from .moment import MomentBasis

jax.config.update("jax_enable_x64", True)  # noqa: FBT003


class JaxMTPEngine(EngineBase):
    """MTP Engine in 'full tensor' version based on jax."""

    def __init__(self, *args, **kwargs) -> None:
        """Intialize the engine."""
        self.moment_basis = None
        self.basis_converter = None
        super().__init__(*args, **kwargs)

    def update(self, mtp_data: MTPData) -> None:
        """Update MTP parameters.

        Raises
        ------
        ValueError: If `level` is updated after initialization.

        """
        super().update(mtp_data)
        if self.mtp_data.alpha_moments_count is not None:
            level = moments_count_to_level_map[mtp_data.alpha_moments_count]
            if self.moment_basis is None:
                self.moment_basis = MomentBasis(level)
                self.moment_basis.init_moment_mappings()
                self.basis_converter = BasisConverter(self.moment_basis)
            elif self.moment_basis.max_level != level:
                msg = "Changing level is not allowed, use a new instance instead."
                raise ValueError(msg)
            self.basis_converter.remap_mlip_moment_coeffs(self.mtp_data)

    def _calculate(self, atoms: Atoms) -> tuple:
        mtp_data = self.mtp_data
        itypes = jnp.array(get_types(atoms, mtp_data.species))
        js = jnp.array(self._neighbors)
        rijs = jnp.array(self._get_interatomic_vectors(atoms))
        jtypes = itypes[js]

        energies, gradients = _calc_local_energy_and_derivs(
            rijs,
            itypes,
            jtypes,
            mtp_data.species_coeffs,
            self.basis_converter.remapped_coeffs,
            mtp_data.radial_coeffs,
            mtp_data.scaling,
            mtp_data.radial_basis.min,
            mtp_data.radial_basis.max,
            # Static parameters:
            mtp_data.radial_coeffs.shape[3],
            self.moment_basis.basic_moments,
            self.moment_basis.pair_contractions,
            self.moment_basis.scalar_contractions,
        )

        forces = np.array(gradients.sum(axis=1))
        np.subtract.at(forces, js, gradients)

        stress = np.array((rijs.transpose((0, 2, 1)) @ gradients).sum(axis=0))

        return energies, forces, stress


@partial(jax.jit, static_argnums=(9, 10, 11, 12))
@partial(jax.vmap, in_axes=(0,) * 3 + (None,) * 10, out_axes=0)
def _calc_local_energy_and_derivs(
    r_ijs: npt.NDArray[np.float64],
    itype: npt.NDArray[np.int32],
    jtypes: npt.NDArray[np.int32],
    species_coeffs: npt.NDArray[np.float64],
    moment_coeffs: npt.NDArray[np.float64],
    radial_coeffs: npt.NDArray[np.float64],
    scaling: np.float64,
    min_dist: np.float64,
    max_dist: np.float64,
    # Static parameters:
    rb_size: int,
    basic_moments: tuple,
    pair_contractions: tuple,
    scalar_contractions: tuple,
) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64]]:
    energy = _calc_local_energy(
        r_ijs,
        itype,
        jtypes,
        species_coeffs,
        moment_coeffs,
        radial_coeffs,
        scaling,
        min_dist,
        max_dist,
        # Static parameters:
        rb_size,
        basic_moments,
        pair_contractions,
        scalar_contractions,
    )
    derivs = jax.jacobian(_calc_local_energy)(
        r_ijs,
        itype,
        jtypes,
        species_coeffs,
        moment_coeffs,
        radial_coeffs,
        scaling,
        min_dist,
        max_dist,
        # Static parameters:
        rb_size,
        basic_moments,
        pair_contractions,
        scalar_contractions,
    )
    return energy, derivs


def _calc_local_energy(
    r_ijs: npt.NDArray[np.float64],
    itype: npt.NDArray[np.int32],
    jtypes: npt.NDArray[np.int32],
    species_coeffs: npt.NDArray[np.float64],
    moment_coeffs: npt.NDArray[np.float64],
    radial_coeffs: npt.NDArray[np.float64],
    scaling: np.float64,
    min_dist: np.float64,
    max_dist: np.float64,
    # Static parameters:
    rb_size: int,
    basic_moments: tuple,
    pair_contractions: tuple,
    scalar_contractions: tuple,
) -> npt.NDArray[np.float64]:
    r_abs = jnp.linalg.norm(r_ijs, axis=1)
    smoothing = jnp.where(r_abs < max_dist, (max_dist - r_abs) ** 2, 0)
    radial_basis = _chebyshev_basis(r_abs, min_dist, max_dist, rb_size)
    # j, rb_size
    rb_values = (
        scaling
        * smoothing
        * jnp.einsum("jmn, jn -> mj", radial_coeffs[itype, jtypes], radial_basis)
    )
    basis = _calc_basis(
        r_ijs,
        r_abs,
        rb_values,
        basic_moments,
        pair_contractions,
        scalar_contractions,
    )
    return species_coeffs[itype] + jnp.dot(moment_coeffs, basis)


def _calc_basis(
    r_ijs: npt.NDArray[np.float64],
    r_abs: npt.NDArray[np.float64],
    rb_values: npt.NDArray[np.float64],
    # Static parameters:
    basic_moments: tuple,
    pair_contractions: tuple,
    scalar_contractions: tuple,
):
    calculated_moments = _calc_moments(r_ijs, r_abs, rb_values, basic_moments)
    for contraction in pair_contractions:
        m1 = calculated_moments[contraction[0]]
        m2 = calculated_moments[contraction[1]]
        calculated_moments[contraction] = _contract_over_axes(m1, m2, contraction[3])
    basis = []
    for contraction in scalar_contractions:
        b = calculated_moments[contraction]
        basis.append(b)
    return jnp.array(basis)


@partial(jax.vmap, in_axes=(0, None, None, None), out_axes=0)
def _chebyshev_basis(
    r: npt.NDArray[np.float64],
    min_dist: np.float64,
    max_dist: np.float64,
    # Static parameters:
    size: np.int32,
) -> npt.NDArray[np.float64]:
    r_scaled = (2 * r - (min_dist + max_dist)) / (max_dist - min_dist)
    rb = [1, r_scaled]
    for i in range(2, size):
        rb.append(2 * r_scaled * rb[i - 1] - rb[i - 2])
    return jnp.array(rb)


def _calc_moments(
    r_ijs: npt.NDArray[np.float64],
    r_abs: npt.NDArray[np.float64],
    rb_values: npt.NDArray[np.float64],
    # Static parameters:
    moments: tuple[tuple[np.int32]],
) -> dict[tuple, npt.NDArray[np.float64]]:
    calculated_moments = {}
    r_ijs_unit = (r_ijs.T / r_abs).T
    for moment in moments:
        mu = moment[0]
        nu = moment[1]
        m = _make_tensor(r_ijs_unit, nu)
        m = (m.T * rb_values[mu]).sum(axis=-1)
        calculated_moments[moment] = m
    return calculated_moments


@partial(jax.vmap, in_axes=(0, None), out_axes=0)
def _make_tensor(
    r: npt.NDArray[np.float64],
    nu: np.int32,
) -> npt.NDArray[np.float64]:
    m = 1
    for _ in range(nu):
        m = jnp.tensordot(r, m, axes=0)
    return m


def _contract_over_axes(
    m1: npt.NDArray[np.float64],
    m2: npt.NDArray[np.float64],
    axes: tuple[np.int32],
) -> npt.NDArray[np.float64]:
    return jnp.tensordot(m1, m2, axes=axes)
