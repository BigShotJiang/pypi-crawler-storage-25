"""
╔══════════════════════════════════════════════════════════════════════════╗
║   🏆 NEVIT LIBRARY - کتابخانه ساده و قدرتمند بله/تلگرام 🏆                ║
║   نسخه: 6.0.3 - Async + Middleware + Error Handler                      ║
║   ساخته شده با ❤️                                                       ║
╚══════════════════════════════════════════════════════════════════════════╝
📚 مستندات کامل:
    • NevitBot: کلاس اصلی ربات (هم سینک و هم آسینک)
    • NevitAsyncBot: کلاس کاملاً آسینک برای استفاده با asyncio
    • Middleware: سیستم میان‌افزار برای پردازش پیام‌ها
    • ErrorHandler: مدیریت متمرکز خطاها
    • Filters: فیلترهای آماده برای پردازش پیام‌ها
🚀 مثال استفاده:
    # نسخه سینک:
    bot = NevitBot("TOKEN")
    @bot.command(["start"])
    def start(msg): bot.reply(msg, "سلام!")
    bot.run()
    # نسخه آسینک:
    bot = NevitAsyncBot("TOKEN")
    @bot.command(["start"])
    async def start(msg): await bot.reply(msg, "سلام!")
    await bot.run()
"""
import requests
import aiohttp
import asyncio
import json
import logging
import os
import re
import time
import traceback
from typing import Optional, List, Union, Dict, Any, Callable, Awaitable
from enum import Enum
from dataclasses import dataclass, field
from functools import wraps
# ==================== تنظیمات اولیه ====================
logging.basicConfig(
    level=logging.INFO,
    format='\033[92m[nevit]\033[0m %(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("nevit")
VERSION = "6.0.4"
# ==================== Enums ====================
class ChatType(Enum):
    """نوع چت"""
    PRIVATE = "private"
    GROUP = "group"
    SUPERGROUP = "supergroup"
    CHANNEL = "channel"
class ParseMode(Enum):
    """حالت پارس کردن متن"""
    MARKDOWN = "Markdown"
    MARKDOWN_V2 = "MarkdownV2"
    HTML = "HTML"
class ChatAction(Enum):
    """اکشن‌های ارسالی به چت"""
    TYPING = "typing"
    UPHOTO = "upload_photo"
    UVIDEO = "upload_video"
    UVOICE = "upload_voice"
    UDOCUMENT = "upload_document"
class DiceEmoji(Enum):
    """ایموجی‌های تاس"""
    DICE = "🎲"
    DART = "🎯"
    BASKETBALL = "🏀"
    FOOTBALL = "⚽"
    SLOT_MACHINE = "🎰"
    BOWLING = "🎳"
# ==================== دیتاسنترها ====================
@dataclass
class User:
    """کاربر"""
    id: int
    first_name: str
    last_name: Optional[str] = None
    username: Optional[str] = None
    language_code: Optional[str] = None
    is_bot: bool = False
@dataclass
class Chat:
    """چت"""
    id: int
    type: str
    title: Optional[str] = None
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
@dataclass
class Message:
    """پیام"""
    message_id: int
    date: int
    chat: Chat
    from_user: Optional[User] = None
    text: Optional[str] = None
    caption: Optional[str] = None
    # فیلدهای اضافی که به صورت داینامیک اضافه می‌شوند
    _extra_data: Dict[str, Any] = field(default_factory=dict)
@dataclass
class Message:
    """پیام"""
    message_id: int
    date: int
    chat: Chat
    from_user: Optional[User] = None
    text: Optional[str] = None
    caption: Optional[str] = None
    _extra_data: Dict[str, Any] = field(default_factory=dict)
    def __getattr__(self, name: str):
        if name in self._extra_data:
            return self._extra_data.get(name)
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
    def __setattr__(self, name: str, value: Any):
        if name in ['message_id', 'date', 'chat', 'from_user', 'text', 'caption', '_extra_data']:
            super().__setattr__(name, value)
        else:
            self._extra_data[name] = value
# ==================== کیبوردها ====================
class InlineKeyboardButton:
    """دکمه اینلاین کیبورد"""
    def __init__(self, text: str, url: str = None, callback_data: str = None,
                 web_app: dict = None, switch_inline_query: str = None,
                 login_url: dict = None, callback_game: dict = None):
        """
        ایجاد دکمه اینلاین
        Args:
            text: متن دکمه
            url: لینک خارجی
            callback_data: داده برای کال‌بک
            web_app: آدرس وب‌اپ
            switch_inline_query: جستجوی اینلاین
            login_url: لینک ورود
            callback_game: بازی کال‌بک
        """
        self.text = text
        self.url = url
        self.callback_data = callback_data
        self.web_app = web_app
        self.switch_inline_query = switch_inline_query
        self.login_url = login_url
        self.callback_game = callback_game
    def to_dict(self) -> dict:
        """تبدیل به دیکشنری"""
        data = {"text": self.text}
        if self.url: data["url"] = self.url
        if self.callback_data: data["callback_data"] = self.callback_data
        if self.web_app: data["web_app"] = self.web_app
        if self.switch_inline_query: data["switch_inline_query"] = self.switch_inline_query
        if self.login_url: data["login_url"] = self.login_url
        if self.callback_game: data["callback_game"] = self.callback_game
        return data
class InlineKeyboardMarkup:
    """کیبورد اینلاین"""
    def __init__(self):
        self.buttons: List[List[InlineKeyboardButton]] = []
    def add(self, *buttons: InlineKeyboardButton) -> 'InlineKeyboardMarkup':
        """اضافه کردن دکمه‌ها در یک ردیف"""
        self.buttons.append(list(buttons))
        return self
    def row(self, *buttons: InlineKeyboardButton) -> 'InlineKeyboardMarkup':
        """اضافه کردن دکمه‌ها در یک ردیف (مانند add)"""
        self.buttons.append(list(buttons))
        return self
    def url(self, text: str, url: str) -> 'InlineKeyboardMarkup':
        """اضافه کردن دکمه لینک"""
        btn = InlineKeyboardButton(text, url=url)
        if not self.buttons:
            self.buttons.append([])
        self.buttons[-1].append(btn)
        return self
    def callback(self, text: str, callback_data: str) -> 'InlineKeyboardMarkup':
        """اضافه کردن دکمه کال‌بک"""
        btn = InlineKeyboardButton(text, callback_data=callback_data)
        if not self.buttons:
            self.buttons.append([])
        self.buttons[-1].append(btn)
        return self
    def web_app(self, text: str, url: str) -> 'InlineKeyboardMarkup':
        """اضافه کردن دکمه وب‌اپ"""
        btn = InlineKeyboardButton(text, web_app={"url": url})
        if not self.buttons:
            self.buttons.append([])
        self.buttons[-1].append(btn)
        return self
    def switch_inline(self, text: str, query: str = "") -> 'InlineKeyboardMarkup':
        """اضافه کردن دکمه جستجوی اینلاین"""
        btn = InlineKeyboardButton(text, switch_inline_query=query)
        if not self.buttons:
            self.buttons.append([])
        self.buttons[-1].append(btn)
        return self
    def to_dict(self) -> dict:
        """تبدیل به دیکشنری"""
        return {"inline_keyboard": [[btn.to_dict() for btn in row] for row in self.buttons]}
class ReplyKeyboardMarkup:
    """کیبورد ریپلای"""
    def __init__(self, resize_keyboard: bool = True, one_time_keyboard: bool = False,
                 selective: bool = False):
        """
        ایجاد کیبورد ریپلای
        Args:
            resize_keyboard: تغییر اندازه کیبورد
            one_time_keyboard: مخفی کردن بعد از استفاده
            selective: اعمال فقط برای کاربران انتخابی
        """
        self.resize_keyboard = resize_keyboard
        self.one_time_keyboard = one_time_keyboard
        self.selective = selective
        self.buttons: List[List[dict]] = []
    def add(self, *labels: str) -> 'ReplyKeyboardMarkup':
        """اضافه کردن دکمه‌ها"""
        self.buttons.append([{"text": label} for label in labels])
        return self
    def row(self, *labels: str) -> 'ReplyKeyboardMarkup':
        """اضافه کردن دکمه‌ها در ردیف جدید"""
        self.buttons.append([{"text": label} for label in labels])
        return self
    def to_dict(self) -> dict:
        """تبدیل به دیکشنری"""
        return {
            "keyboard": self.buttons,
            "resize_keyboard": self.resize_keyboard,
            "one_time_keyboard": self.one_time_keyboard,
            "selective": self.selective
        }
class ReplyKeyboardRemove:
    """حذف کیبورد"""
    def __init__(self, selective: bool = False):
        """
        حذف کیبورد
        Args:
            selective: اعمال فقط برای کاربر انتخابی
        """
        self.selective = selective
    def to_dict(self) -> dict:
        """تبدیل به دیکشنری"""
        return {"remove_keyboard": True, "selective": self.selective}
class KeyboardButton:
    """دکمه کیبورد"""
    def __init__(self, text: str, request_contact: bool = False,
                 request_location: bool = False, request_poll: dict = None):
        """
        ایجاد دکمه کیبورد
        Args:
            text: متن دکمه
            request_contact: درخواست شماره تماس
            request_location: درخواست موقعیت
            request_poll: درخواست نظرسنجی
        """
        self.text = text
        self.request_contact = request_contact
        self.request_location = request_location
        self.request_poll = request_poll
    def to_dict(self) -> dict:
        """تبدیل به دیکشنری"""
        data = {"text": self.text}
        if self.request_contact: data["request_contact"] = self.request_contact
        if self.request_location: data["request_location"] = self.request_location
        if self.request_poll: data["request_poll"] = self.request_poll
        return data
# ==================== فیلترها ====================
class Filters:
    """
    فیلترهای آماده برای پردازش پیام‌ها
    مثال استفاده:
        @bot.message(Filters.text)
        def handle_text(msg): ...
        @bot.message(Filters.regex(r"^hello"))
        def handle_hello(msg): ...
    """
    @staticmethod
    def text(message: Message) -> bool:
        """فیلتر پیام متنی"""
        return message.text is not None
    @staticmethod
    def photo(message: Message) -> bool:
        """فیلتر عکس"""
        return hasattr(message, 'photo') and message.photo is not None
    @staticmethod
    def video(message: Message) -> bool:
        """فیلتر ویدیو"""
        return hasattr(message, 'video') and message.video is not None
    @staticmethod
    def audio(message: Message) -> bool:
        """فیلتر صوتی"""
        return hasattr(message, 'audio') and message.audio is not None
    @staticmethod
    def voice(message: Message) -> bool:
        """فیلتر ویس"""
        return hasattr(message, 'voice') and message.voice is not None
    @staticmethod
    def document(message: Message) -> bool:
        """فیلتر سند"""
        return hasattr(message, 'document') and message.document is not None
    @staticmethod
    def sticker(message: Message) -> bool:
        """فیلتر استیکر"""
        return hasattr(message, 'sticker') and message.sticker is not None
    @staticmethod
    def location(message: Message) -> bool:
        """فیلتر موقعیت"""
        return hasattr(message, 'location') and message.location is not None
    @staticmethod
    def venue(message: Message) -> bool:
        """فیلتر مکان"""
        return hasattr(message, 'venue') and message.venue is not None
    @staticmethod
    def contact(message: Message) -> bool:
        """فیلتر مخاطب"""
        return hasattr(message, 'contact') and message.contact is not None
    @staticmethod
    def poll(message: Message) -> bool:
        """فیلتر نظرسنجی"""
        return hasattr(message, 'poll') and message.poll is not None
    @staticmethod
    def dice(message: Message) -> bool:
        """فیلتر تاس"""
        return hasattr(message, 'dice') and message.dice is not None
    @staticmethod
    def game(message: Message) -> bool:
        """فیلتر بازی"""
        return hasattr(message, 'game') and message.game is not None
    @staticmethod
    def invoice(message: Message) -> bool:
        """فیلتر فاکتور"""
        return hasattr(message, 'invoice') and message.invoice is not None
    @staticmethod
    def channel(message: Message) -> bool:
        """فیلتر کانال"""
        return message.chat.type == "channel"
    @staticmethod
    def group(message: Message) -> bool:
        """فیلتر گروه"""
        return message.chat.type in ["group", "supergroup"]
    @staticmethod
    def private(message: Message) -> bool:
        """فیلتر چت خصوصی"""
        return message.chat.type == "private"
    @staticmethod
    def command(message: Message) -> bool:
        """فیلتر دستور"""
        return message.text is not None and message.text.startswith("/")
    @staticmethod
    def forwarded(message: Message) -> bool:
        """فیلتر پیام فوروارد شده"""
        return hasattr(message, 'forward_date') and message.forward_date is not None
    @staticmethod
    def new_chat_members(message: Message) -> bool:
        """فیلتر عضو جدید"""
        return hasattr(message, 'new_chat_members') and message.new_chat_members is not None
    @staticmethod
    def left_chat_member(message: Message) -> bool:
        """فیلتر عضو خارج شده"""
        return hasattr(message, 'left_chat_member') and message.left_chat_member is not None
    @staticmethod
    def regex(pattern: str):
        """فیلتر با استفاده از عبارات منظم"""
        def check(message: Message) -> bool:
            return message.text is not None and bool(re.search(pattern, message.text))
        return check
    @staticmethod
    def equals(text: str):
        """فیلتر متن مساوی"""
        def check(message: Message) -> bool:
            return message.text == text
        return check
    @staticmethod
    def contains(text: str):
        """فیلتر شامل متن"""
        def check(message: Message) -> bool:
            return message.text and text in message.text
        return check
    @staticmethod
    def startswith(text: str):
        """فیلتر شروع با متن"""
        def check(message: Message) -> bool:
            return message.text and message.text.startswith(text)
        return check
    @staticmethod
    def endswith(text: str):
        """فیلتر پایان با متن"""
        def check(message: Message) -> bool:
            return message.text and message.text.endswith(text)
        return check
    @staticmethod
    def length(min_length: int = None, max_length: int = None):
        """فیلتر طول پیام"""
        def check(message: Message) -> bool:
            if not message.text:
                return False
            length = len(message.text)
            if min_length is not None and length < min_length:
                return False
            if max_length is not None and length > max_length:
                return False
            return True
        return check
    @staticmethod
    def from_user(user_id: int):
        """فیلتر کاربر خاص"""
        def check(message: Message) -> bool:
            return message.from_user and message.from_user.id == user_id
        return check
    @staticmethod
    def chat_type(chat_type: Union[str, List[str]]):
        """فیلتر نوع چت"""
        if isinstance(chat_type, str):
            chat_type = [chat_type]
        def check(message: Message) -> bool:
            return message.chat.type in chat_type
        return check
    @staticmethod
    def callback(message: Message) -> bool:
        """فیلتر کال‌بک"""
        return hasattr(message, 'callback_query') and message.callback_query is not None
# ==================== سیستم Error Handler ====================
class ErrorHandler:
    """
    سیستم مدیریت خطا
    مثال استفاده:
        @bot.error_handler()
        def handle_error(error, context):
            print(f"خطا: {error}")
            print(f"کانتکست: {context}")
    """
    def __init__(self):
        self.handlers: List[Callable] = []
        self._default_handler: Optional[Callable] = None
    def __call__(self, func: Callable = None):
        """دکوراتور برای ثبت هندلر خطا"""
        if func:
            self.handlers.append(func)
            return func
        return func
    def handler(self, func: Callable):
        """دکوراتور جایگزین برای ثبت هندلر"""
        self.handlers.append(func)
        return func
    def default(self, func: Callable):
        """ثبت هندلر پیش‌فرض"""
        self._default_handler = func
        return func
    async def emit(self, error: Exception, context: dict):
        """اجرای همه هندلرهای خطا"""
        # اضافه کردن اطلاعات زمان
        context['timestamp'] = time.time()
        context['error_type'] = type(error).__name__
        context['traceback'] = traceback.format_exc()
        # اجرای همه هندلرها
        for handler in self.handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(error, context)
                else:
                    handler(error, context)
            except Exception as e:
                logger.error(f"خطا در هندلر خطا: {e}")
        # اجرای هندلر پیش‌فرض
        if self._default_handler:
            try:
                if asyncio.iscoroutinefunction(self._default_handler):
                    await self._default_handler(error, context)
                else:
                    self._default_handler(error, context)
            except Exception as e:
                logger.error(f"خطا در هندلر پیش‌فرض: {e}")
# ==================== سیستم Middleware ====================
class Middleware:
    """
    سیستم میان‌افزار برای پردازش پیام‌ها
    مثال استفاده:
        class LogMiddleware(Middleware):
            async def pre_process(self, message, data):
                logger.info(f"پیام جدید: {message.text}")
                return message
            async def post_process(self, message, data, result):
                logger.info(f"پاسخ ارسال شد")
        bot.add_middleware(LogMiddleware())
    """
    async def pre_process(self, message: Message, data: dict) -> Optional[Message]:
        """
        پردازش قبل از هندلر اصلی
        Args:
            message: پیام دریافتی
            data: داده‌های اضافی
        Returns:
            پیام پردازش شده یا None برای ادامه
        """
        return message
    async def post_process(self, message: Message, data: dict, result: Any):
        """
        پردازش بعد از هندلر اصلی
        Args:
            message: پیام اصلی
            data: داده‌های اضافی
            result: نتیجه هندلر
        """
        pass
class MiddlewareManager:
    """مدیریت میان‌افزارها"""
    def __init__(self):
        self.middlewares: List[Middleware] = []
    def add(self, middleware: Middleware):
        """اضافه کردن میان‌افزار"""
        self.middlewares.append(middleware)
    async def pre_process(self, message: Message, data: dict) -> Message:
        """پردازش قبلی همه میان‌افزارها"""
        for middleware in self.middlewares:
            try:
                result = await middleware.pre_process(message, data)
                if result is None:
                    return None
                message = result
            except Exception as e:
                logger.error(f"خطا در pre_process میان‌افزار: {e}")
        return message
    async def post_process(self, message: Message, data: dict, result: Any):
        """پردازش پسین همه میان‌افزارها"""
        for middleware in reversed(self.middlewares):
            try:
                await middleware.post_process(message, data, result)
            except Exception as e:
                logger.error(f"خطا در post_process میان‌افزار: {e}")
# ==================== میان‌افزارهای آماده ====================
class LoggingMiddleware(Middleware):
    """میان‌افزار لاگ کردن پیام‌ها"""
    def __init__(self, log_text: bool = True, log_user: bool = True):
        self.log_text = log_text
        self.log_user = log_user
    async def pre_process(self, message: Message, data: dict) -> Message:
        if self.log_user and message.from_user:
            logger.info(f"📩 پیام از {message.from_user.first_name} (@{message.from_user.username or 'بدون یوزرنیم'})")
        if self.log_text and message.text:
            logger.info(f"💬 متن: {message.text[:50]}...")
        return message
class RateLimitMiddleware(Middleware):
    """میان‌افزار محدودیت تعداد درخواست"""
    def __init__(self, max_requests: int = 10, time_window: int = 60):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests: Dict[int, List[float]] = {}
    async def pre_process(self, message: Message, data: dict) -> Optional[Message]:
        if not message.from_user:
            return message
        user_id = message.from_user.id
        now = time.time()
        # پاک کردن درخواست‌های قدیمی
        if user_id in self.requests:
            self.requests[user_id] = [t for t in self.requests[user_id] if now - t < self.time_window]
        else:
            self.requests[user_id] = []
        # چک کردن محدودیت
        if len(self.requests[user_id]) >= self.max_requests:
            logger.warning(f"⛔ کاربر {user_id} محدود شد")
            return None
        self.requests[user_id].append(now)
        return message
class AntiSpamMiddleware(Middleware):
    """میان‌افزار ضد اسپم"""
    def __init__(self, blocked_words: List[str] = None, max_length: int = 4096):
        self.blocked_words = blocked_words or []
        self.max_length = max_length
    async def pre_process(self, message: Message, data: dict) -> Optional[Message]:
        if not message.text:
            return message
        # چک کردن طول پیام
        if len(message.text) > self.max_length:
            logger.warning(f"⛔ پیام طولانی از کاربر {message.from_user.id}")
            return None
        # چک کردن کلمات ممنوعه
        text_lower = message.text.lower()
        for word in self.blocked_words:
            if word.lower() in text_lower:
                logger.warning(f"⛔ پیام حاوی کلمه ممنوعه: {word}")
                return None
        return message
# ==================== کلاینت API سینک ====================
class NevitClient:
    """
    کلاینت ارتباط با API (نسخه سینک)
    این کلاس برای ارتباط مستقیم با API تلگرام/بله استفاده می‌شود.
    """
    def __init__(self, token: str, request_timeout: int = 30):
        """
        ایجاد کلاینت API
        Args:
            token: توکن ربات
            request_timeout: زمان انتظار درخواست (ثانیه)
        """
        self.token = token
        self.base_url = f"https://tapi.bale.ai/bot{token}"
        self.request_timeout = request_timeout
        self._session = requests.Session()
    def _request(self, method: str, data: dict = None, files: dict = None) -> dict:
        """ارسال درخواست به API"""
        url = f"{self.base_url}/{method}"
        try:
            if files:
                response = self._session.post(url, data=data, files=files, timeout=self.request_timeout)
            else:
                response = self._session.post(url, json=data, timeout=self.request_timeout)
            return response.json()
        except Exception as e:
            logger.error(f"Request error: {e}")
            return {"ok": False, "error": str(e)}
    def _send_file(self, method: str, data: dict, file_key: str, file_value: str) -> dict:
        """ارسال فایل به API"""
        url = f"{self.base_url}/{method}"
        try:
            if os.path.isfile(file_value):
                files = {file_key: open(file_value, 'rb')}
            else:
                files = {file_key: file_value}
            response = self._session.post(url, data=data, files=files, timeout=self.request_timeout)
            return response.json()
        except Exception as e:
            logger.error(f"File upload error: {e}")
            return {"ok": False, "error": str(e)}
    # ---------- متدهای پایه ----------
    def get_me(self) -> dict:
        """دریافت اطلاعات ربات"""
        return self._request("getMe")
    def get_updates(self, offset: int = None, limit: int = 100, timeout: int = 60) -> dict:
        """دریافت آپدیت‌ها"""
        data = {"timeout": timeout, "limit": limit}
        if offset is not None:
            data["offset"] = offset
        return self._request("getUpdates", data)
    def get_webhook_info(self) -> dict:
        """دریافت اطلاعات وب‌هوک"""
        return self._request("getWebhookInfo")
    def set_webhook(self, url: str, max_connections: int = 40,
                    allowed_updates: List[str] = None) -> dict:
        """تنظیم وب‌هوک"""
        data = {"url": url, "max_connections": max_connections}
        if allowed_updates:
            data["allowed_updates"] = allowed_updates
        return self._request("setWebhook", data)
    def delete_webhook(self) -> dict:
        """حذف وب‌هوک"""
        return self._request("deleteWebhook")
    # ---------- ارسال پیام ----------
    def send_message(self, chat_id: int, text: str, parse_mode: str = None,
                     disable_web_page_preview: bool = None,
                     disable_notification: bool = None,
                     reply_to_message_id: int = None,
                     reply_markup: dict = None) -> dict:
        """ارسال پیام متنی"""
        data = {"chat_id": chat_id, "text": text}
        if parse_mode: data["parse_mode"] = parse_mode
        if disable_web_page_preview: data["disable_web_page_preview"] = disable_web_page_preview
        if disable_notification: data["disable_notification"] = disable_notification
        if reply_to_message_id: data["reply_to_message_id"] = reply_to_message_id
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendMessage", data)
    def send_photo(self, chat_id: int, photo: str, caption: str = None,
                   parse_mode: str = None, reply_markup: dict = None) -> dict:
        """ارسال عکس"""
        data = {"chat_id": chat_id}
        if os.path.isfile(photo):
            return self._send_file("sendPhoto", data, "photo", photo)
        data["photo"] = photo
        if caption: data["caption"] = caption
        if parse_mode: data["parse_mode"] = parse_mode
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendPhoto", data)
    def send_audio(self, chat_id: int, audio: str, caption: str = None,
                   duration: int = None, performer: str = None, title: str = None,
                   reply_markup: dict = None) -> dict:
        """ارسال صوتی"""
        data = {"chat_id": chat_id}
        if os.path.isfile(audio):
            return self._send_file("sendAudio", data, "audio", audio)
        data["audio"] = audio
        if caption: data["caption"] = caption
        if duration: data["duration"] = duration
        if performer: data["performer"] = performer
        if title: data["title"] = title
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendAudio", data)
    def send_voice(self, chat_id: int, voice: str, caption: str = None,
                   duration: int = None, reply_markup: dict = None) -> dict:
        """ارسال ویس"""
        data = {"chat_id": chat_id}
        if os.path.isfile(voice):
            return self._send_file("sendVoice", data, "voice", voice)
        data["voice"] = voice
        if caption: data["caption"] = caption
        if duration: data["duration"] = duration
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendVoice", data)
    def send_video(self, chat_id: int, video: str, caption: str = None,
                   duration: int = None, reply_markup: dict = None) -> dict:
        """ارسال ویدیو"""
        data = {"chat_id": chat_id}
        if os.path.isfile(video):
            return self._send_file("sendVideo", data, "video", video)
        data["video"] = video
        if caption: data["caption"] = caption
        if duration: data["duration"] = duration
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendVideo", data)
    def send_document(self, chat_id: int, document: str, caption: str = None,
                     reply_markup: dict = None) -> dict:
        """ارسال سند"""
        data = {"chat_id": chat_id}
        if os.path.isfile(document):
            return self._send_file("sendDocument", data, "document", document)
        data["document"] = document
        if caption: data["caption"] = caption
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendDocument", data)
    def send_sticker(self, chat_id: int, sticker: str, reply_markup: dict = None) -> dict:
        """ارسال استیکر"""
        data = {"chat_id": chat_id}
        if os.path.isfile(sticker):
            return self._send_file("sendSticker", data, "sticker", sticker)
        data["sticker"] = sticker
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendSticker", data)
    def send_location(self, chat_id: int, latitude: float, longitude: float,
                      live_period: int = None, reply_markup: dict = None) -> dict:
        """ارسال موقعیت"""
        data = {"chat_id": chat_id, "latitude": latitude, "longitude": longitude}
        if live_period: data["live_period"] = live_period
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendLocation", data)
    def send_venue(self, chat_id: int, latitude: float, longitude: float,
                  title: str, address: str, reply_markup: dict = None) -> dict:
        """ارسال مکان"""
        data = {"chat_id": chat_id, "latitude": latitude, "longitude": longitude,
                "title": title, "address": address}
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendVenue", data)
    def send_contact(self, chat_id: int, phone_number: str, first_name: str,
                    last_name: str = None, reply_markup: dict = None) -> dict:
        """ارسال مخاطب"""
        data = {"chat_id": chat_id, "phone_number": phone_number, "first_name": first_name}
        if last_name: data["last_name"] = last_name
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendContact", data)
    def send_poll(self, chat_id: int, question: str, options: List[str],
                 is_anonymous: bool = True, type: str = "regular",
                 allows_multiple_answers: bool = None, reply_markup: dict = None) -> dict:
        """ارسال نظرسنجی"""
        data = {"chat_id": chat_id, "question": question, "options": options,
                "is_anonymous": is_anonymous, "type": type}
        if allows_multiple_answers is not None:
            data["allows_multiple_answers"] = allows_multiple_answers
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendPoll", data)
    def send_dice(self, chat_id: int, emoji: str = None, reply_markup: dict = None) -> dict:
        """ارسال تاس"""
        data = {"chat_id": chat_id}
        if emoji: data["emoji"] = emoji
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendDice", data)
    def send_game(self, chat_id: int, game_short_name: str, reply_markup: dict = None) -> dict:
        """ارسال بازی"""
        data = {"chat_id": chat_id, "game_short_name": game_short_name}
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendGame", data)
    def send_media_group(self, chat_id: int, media: List[dict]) -> dict:
        """ارسال گروه مدیا"""
        return self._request("sendMediaGroup", {"chat_id": chat_id, "media": json.dumps(media)})
    def send_chat_action(self, chat_id: int, action: str) -> dict:
        """ارسال اکشن چت"""
        return self._request("sendChatAction", {"chat_id": chat_id, "action": action})
    # ---------- فوروارد و کپی ----------
    def forward_message(self, chat_id: int, from_chat_id: int, message_id: int) -> dict:
        """فوروارد پیام"""
        return self._request("forwardMessage", {
            "chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id
        })
    def copy_message(self, chat_id: int, from_chat_id: int, message_id: int,
                    caption: str = None, reply_markup: dict = None) -> dict:
        """کپی پیام"""
        data = {"chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id}
        if caption: data["caption"] = caption
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("copyMessage", data)
    # ---------- حذف ----------
    def delete_message(self, chat_id: int, message_id: int) -> dict:
        """حذف پیام"""
        return self._request("deleteMessage", {"chat_id": chat_id, "message_id": message_id})
    # ---------- ویرایش ----------
    def edit_message_text(self, chat_id: int, message_id: int, text: str,
                         parse_mode: str = None, reply_markup: dict = None) -> dict:
        """ویرایش متن پیام"""
        data = {"chat_id": chat_id, "message_id": message_id, "text": text}
        if parse_mode: data["parse_mode"] = parse_mode
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("editMessageText", data)
    def edit_message_reply_markup(self, chat_id: int, message_id: int, reply_markup: dict = None) -> dict:
        """ویرایش کیبورد پیام"""
        data = {"chat_id": chat_id, "message_id": message_id}
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("editMessageReplyMarkup", data)
    # ---------- کال‌بک ----------
    def answer_callback_query(self, callback_query_id: str, text: str = None,
                            show_alert: bool = False) -> dict:
        """پاسخ به کال‌بک"""
        data = {"callback_query_id": callback_query_id}
        if text: data["text"] = text
        if show_alert: data["show_alert"] = show_alert
        return self._request("answerCallbackQuery", data)
    # ---------- مدیریت چت ----------
    def get_chat(self, chat_id: int) -> dict:
        """دریافت اطلاعات چت"""
        return self._request("getChat", {"chat_id": chat_id})
    def get_chat_administrators(self, chat_id: int) -> dict:
        """دریافت لیست ادمین‌ها"""
        return self._request("getChatAdministrators", {"chat_id": chat_id})
    def get_chat_member(self, chat_id: int, user_id: int) -> dict:
        """دریافت اطلاعات عضو"""
        return self._request("getChatMember", {"chat_id": chat_id, "user_id": user_id})
    def get_chat_members_count(self, chat_id: int) -> dict:
        """دریافت تعداد اعضا"""
        return self._request("getChatMembersCount", {"chat_id": chat_id})
    def kick_chat_member(self, chat_id: int, user_id: int) -> dict:
        """اخراج کاربر"""
        return self._request("kickChatMember", {"chat_id": chat_id, "user_id": user_id})
    def unban_chat_member(self, chat_id: int, user_id: int) -> dict:
        """حذف بن کاربر"""
        return self._request("unbanChatMember", {"chat_id": chat_id, "user_id": user_id})
    def restrict_chat_member(self, chat_id: int, user_id: int, permissions: dict) -> dict:
        """محدود کردن کاربر"""
        return self._request("restrictChatMember", {
            "chat_id": chat_id, "user_id": user_id, "permissions": permissions
        })
    def promote_chat_member(self, chat_id: int, user_id: int, **kwargs) -> dict:
        """ارتقای کاربر"""
        data = {"chat_id": chat_id, "user_id": user_id}
        data.update(kwargs)
        return self._request("promoteChatMember", data)
    def set_chat_title(self, chat_id: int, title: str) -> dict:
        """تنظیم عنوان چت"""
        return self._request("setChatTitle", {"chat_id": chat_id, "title": title})
    def set_chat_description(self, chat_id: int, description: str) -> dict:
        """تنظیم توضیحات چت"""
        return self._request("setChatDescription", {"chat_id": chat_id, "description": description})
    def set_chat_photo(self, chat_id: int, photo: str) -> dict:
        """تنظیم عکس چت"""
        return self._send_file("setChatPhoto", {"chat_id": chat_id}, "photo", photo)
    def delete_chat_photo(self, chat_id: int) -> dict:
        """حذف عکس چت"""
        return self._request("deleteChatPhoto", {"chat_id": chat_id})
    def export_chat_invite_link(self, chat_id: int) -> dict:
        """دریافت لینک دعوت"""
        return self._request("exportChatInviteLink", {"chat_id": chat_id})
    def create_chat_invite_link(self, chat_id: int, expire_date: int = None,
                                 member_limit: int = None) -> dict:
        """ایجاد لینک دعوت"""
        data = {"chat_id": chat_id}
        if expire_date: data["expire_date"] = expire_date
        if member_limit: data["member_limit"] = member_limit
        return self._request("createChatInviteLink", data)
    def leave_chat(self, chat_id: int) -> dict:
        """خروج از چت"""
        return self._request("leaveChat", {"chat_id": chat_id})
    def pin_chat_message(self, chat_id: int, message_id: int,
                        disable_notification: bool = None) -> dict:
        """پین کردن پیام"""
        data = {"chat_id": chat_id, "message_id": message_id}
        if disable_notification: data["disable_notification"] = disable_notification
        return self._request("pinChatMessage", data)
    def unpin_chat_message(self, chat_id: int, message_id: int = None) -> dict:
        """آنپین کردن پیام"""
        data = {"chat_id": chat_id}
        if message_id: data["message_id"] = message_id
        return self._request("unpinChatMessage", data)
    # ---------- فایل ----------
    def get_file(self, file_id: str) -> dict:
        """دریافت فایل"""
        return self._request("getFile", {"file_id": file_id})
    def get_file_url(self, file_id: str) -> Optional[str]:
        """دریافت لینک فایل"""
        result = self.get_file(file_id)
        if result.get("ok"):
            file_path = result["result"]["file_path"]
            return f"https://tapi.bale.ai/file/bot{self.token}/{file_path}"
        return None
    def download_file(self, file_id: str, destination: str = None) -> Optional[bytes]:
        """دانلود فایل"""
        url = self.get_file_url(file_id)
        if url:
            response = self._session.get(url)
            if destination:
                with open(destination, 'wb') as f:
                    f.write(response.content)
            return response.content
        return None
    # ---------- دستورات ربات ----------
    def set_my_commands(self, commands: List[dict]) -> dict:
        """تنظیم دستورات ربات"""
        return self._request("setMyCommands", {"commands": commands})
    def get_my_commands(self) -> dict:
        """دریافت دستورات ربات"""
        return self._request("getMyCommands")
    def delete_my_commands(self) -> dict:
        """حذف دستورات ربات"""
        return self._request("deleteMyCommands")
    # ---------- اینلاین ----------
    def answer_inline_query(self, inline_query_id: str, results: List[dict],
                           cache_time: int = 300, next_offset: str = None) -> dict:
        """پاسخ به اینلاین کوئری"""
        data = {"inline_query_id": inline_query_id, "results": results, "cache_time": cache_time}
        if next_offset: data["next_offset"] = next_offset
        return self._request("answerInlineQuery", data)
    # ---------- پرداخت ----------
    def send_invoice(self, chat_id: int, title: str, description: str,
                    payload: str, provider_token: str, currency: str,
                    prices: List[dict], reply_markup: dict = None) -> dict:
        """ارسال فاکتور"""
        data = {"chat_id": chat_id, "title": title, "description": description,
                "payload": payload, "provider_token": provider_token, "currency": currency,
                "prices": prices}
        if reply_markup: data["reply_markup"] = reply_markup
        return self._request("sendInvoice", data)
    def answer_shipping_query(self, shipping_query_id: str, ok: bool,
                             shipping_options: List[dict] = None,
                             error_message: str = None) -> dict:
        """پاسخ به shipping query"""
        data = {"shipping_query_id": shipping_query_id, "ok": ok}
        if shipping_options: data["shipping_options"] = shipping_options
        if error_message: data["error_message"] = error_message
        return self._request("answerShippingQuery", data)
    def answer_pre_checkout_query(self, pre_checkout_query_id: str, ok: bool,
                                  error_message: str = None) -> dict:
        """پاسخ به pre checkout query"""
        data = {"pre_checkout_query_id": pre_checkout_query_id, "ok": ok}
        if error_message: data["error_message"] = error_message
        return self._request("answerPreCheckoutQuery", data)
    # ---------- استیکر ----------
    def create_invoice_link(self, title: str, description: str, payload: str,
                           provider_token: str, currency: str, prices: List[dict]) -> dict:
        """ایجاد لینک فاکتور"""
        return self._request("createInvoiceLink", {
            "title": title, "description": description, "payload": payload,
            "provider_token": provider_token, "currency": currency, "prices": prices
        })
    def create_new_sticker_set(self, user_id: int, name: str, title: str,
                              png_sticker: str = None, emojis: str = None) -> dict:
        """ایجاد استیکر ست جدید"""
        data = {"user_id": user_id, "name": name, "title": title}
        if png_sticker:
            if os.path.isfile(png_sticker):
                return self._send_file("createNewStickerSet", data, "png_sticker", png_sticker)
            data["png_sticker"] = png_sticker
        if emojis: data["emojis"] = emojis
        return self._request("createNewStickerSet", data)
    def add_sticker_to_set(self, user_id: int, name: str, png_sticker: str,
                           emojis: str = None) -> dict:
        """اضافه کردن استیکر به ست"""
        data = {"user_id": user_id, "name": name}
        if os.path.isfile(png_sticker):
            return self._send_file("addStickerToSet", data, "png_sticker", png_sticker)
        data["png_sticker"] = png_sticker
        if emojis: data["emojis"] = emojis
        return self._request("addStickerToSet", data)
    def set_sticker_position_in_set(self, sticker: str, position: int) -> dict:
        """تنظیم موقعیت استیکر"""
        return self._request("setStickerPositionInSet", {"sticker": sticker, "position": position})
    def delete_sticker_from_set(self, sticker: str) -> dict:
        """حذف استیکر از ست"""
        return self._request("deleteStickerFromSet", {"sticker": sticker})
    # ---------- مدیریت تاپیک ----------
    def create_forum_topic(self, chat_id: int, name: str, icon_color: int = None) -> dict:
        """ایجاد تاپیک"""
        data = {"chat_id": chat_id, "name": name}
        if icon_color: data["icon_color"] = icon_color
        return self._request("createForumTopic", data)
    def edit_forum_topic(self, chat_id: int, message_thread_id: int,
                         name: str = None) -> dict:
        """ویرایش تاپیک"""
        data = {"chat_id": chat_id, "message_thread_id": message_thread_id}
        if name: data["name"] = name
        return self._request("editForumTopic", data)
    def close_forum_topic(self, chat_id: int, message_thread_id: int) -> dict:
        """بستن تاپیک"""
        return self._request("closeForumTopic", {"chat_id": chat_id, "message_thread_id": message_thread_id})
    def delete_forum_topic(self, chat_id: int, message_thread_id: int) -> dict:
        """حذف تاپیک"""
        return self._request("deleteForumTopic", {"chat_id": chat_id, "message_thread_id": message_thread_id})
    # ---------- واکنش ----------
    def set_message_reaction(self, chat_id: int, message_id: int, emoji: str = None) -> dict:
        """تنظیم واکنش پیام"""
        reaction = []
        if emoji:
            reaction = [{"type": "emoji", "emoji": emoji}]
        return self._request("setMessageReaction", {
            "chat_id": chat_id, "message_id": message_id, "reaction": reaction
        })
    # ---------- گزارش ----------
    def report_spam_chat(self, chat_id: int) -> dict:
        """گزارش اسپم چت"""
        return self._request("reportSpamChat", {"chat_id": chat_id})
    def report_spam_message(self, chat_id: int, message_id: int) -> dict:
        """گزارش اسپم پیام"""
        return self._request("reportSpamMessage", {"chat_id": chat_id, "message_id": message_id})
# ==================== کلاینت API آسینک ====================
class NevitAsyncClient:
    """
    کلاینت ارتباط با API (نسخه آسینک)
    این کلاس برای ارتباط غیرهمزمان با API تلگرام/بله استفاده می‌شود.
    """
    def __init__(self, token: str, request_timeout: int = 30):
        self.token = token
        self.base_url = f"https://tapi.bale.ai/bot{token}"
        self.request_timeout = request_timeout
    async def _request(self, method: str, data: dict = None, files: dict = None) -> dict:
        """ارسال درخواست غیرهمزمان به API"""
        import aiohttp
        url = f"{self.base_url}/{method}"
        try:
            async with aiohttp.ClientSession() as session:
                if files:
                    async with session.post(url, data=data, files=files,
                                           timeout=aiohttp.ClientTimeout(total=self.request_timeout)) as response:
                        return await response.json()
                else:
                    async with session.post(url, json=data,
                                           timeout=aiohttp.ClientTimeout(total=self.request_timeout)) as response:
                        return await response.json()
        except Exception as e:
            logger.error(f"Async request error: {e}")
            return {"ok": False, "error": str(e)}
    async def _send_file(self, method: str, data: dict, file_key: str, file_value: str) -> dict:
        """ارسال فایل غیرهمزمان"""
        import aiohttp
        url = f"{self.base_url}/{method}"
        try:
            if os.path.isfile(file_value):
                with open(file_value, 'rb') as f:
                    files = {file_key: f.read()}
            else:
                files = {file_key: file_value}
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=data, files=files,
                                       timeout=aiohttp.ClientTimeout(total=self.request_timeout)) as response:
                    return await response.json()
        except Exception as e:
            logger.error(f"Async file upload error: {e}")
            return {"ok": False, "error": str(e)}
    # ---------- متدهای پایه ----------
    async def get_me(self) -> dict:
        return await self._request("getMe")
    async def get_updates(self, offset: int = None, limit: int = 100, timeout: int = 60) -> dict:
        data = {"timeout": timeout, "limit": limit}
        if offset is not None:
            data["offset"] = offset
        return await self._request("getUpdates", data)
    async def get_webhook_info(self) -> dict:
        return await self._request("getWebhookInfo")
    async def set_webhook(self, url: str, max_connections: int = 40) -> dict:
        return await self._request("setWebhook", {"url": url, "max_connections": max_connections})
    async def delete_webhook(self) -> dict:
        return await self._request("deleteWebhook")
    # ---------- ارسال پیام ----------
    async def send_message(self, chat_id: int, text: str, parse_mode: str = None,
                          disable_web_page_preview: bool = None,
                          disable_notification: bool = None,
                          reply_to_message_id: int = None,
                          reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "text": text}
        if parse_mode: data["parse_mode"] = parse_mode
        if disable_web_page_preview: data["disable_web_page_preview"] = disable_web_page_preview
        if disable_notification: data["disable_notification"] = disable_notification
        if reply_to_message_id: data["reply_to_message_id"] = reply_to_message_id
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendMessage", data)
    async def send_photo(self, chat_id: int, photo: str, caption: str = None,
                         parse_mode: str = None, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id}
        if os.path.isfile(photo):
            return await self._send_file("sendPhoto", data, "photo", photo)
        data["photo"] = photo
        if caption: data["caption"] = caption
        if parse_mode: data["parse_mode"] = parse_mode
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendPhoto", data)
    async def send_audio(self, chat_id: int, audio: str, caption: str = None,
                         duration: int = None, performer: str = None, title: str = None,
                         reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id}
        if os.path.isfile(audio):
            return await self._send_file("sendAudio", data, "audio", audio)
        data["audio"] = audio
        if caption: data["caption"] = caption
        if duration: data["duration"] = duration
        if performer: data["performer"] = performer
        if title: data["title"] = title
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendAudio", data)
    async def send_voice(self, chat_id: int, voice: str, caption: str = None,
                         duration: int = None, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id}
        if os.path.isfile(voice):
            return await self._send_file("sendVoice", data, "voice", voice)
        data["voice"] = voice
        if caption: data["caption"] = caption
        if duration: data["duration"] = duration
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendVoice", data)
    async def send_video(self, chat_id: int, video: str, caption: str = None,
                         duration: int = None, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id}
        if os.path.isfile(video):
            return await self._send_file("sendVideo", data, "video", video)
        data["video"] = video
        if caption: data["caption"] = caption
        if duration: data["duration"] = duration
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendVideo", data)
    async def send_document(self, chat_id: int, document: str, caption: str = None,
                           reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id}
        if os.path.isfile(document):
            return await self._send_file("sendDocument", data, "document", document)
        data["document"] = document
        if caption: data["caption"] = caption
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendDocument", data)
    async def send_sticker(self, chat_id: int, sticker: str, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id}
        if os.path.isfile(sticker):
            return await self._send_file("sendSticker", data, "sticker", sticker)
        data["sticker"] = sticker
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendSticker", data)
    async def send_location(self, chat_id: int, latitude: float, longitude: float,
                            live_period: int = None, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "latitude": latitude, "longitude": longitude}
        if live_period: data["live_period"] = live_period
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendLocation", data)
    async def send_venue(self, chat_id: int, latitude: float, longitude: float,
                        title: str, address: str, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "latitude": latitude, "longitude": longitude,
                "title": title, "address": address}
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendVenue", data)
    async def send_contact(self, chat_id: int, phone_number: str, first_name: str,
                          last_name: str = None, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "phone_number": phone_number, "first_name": first_name}
        if last_name: data["last_name"] = last_name
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendContact", data)
    async def send_poll(self, chat_id: int, question: str, options: List[str],
                       is_anonymous: bool = True, type: str = "regular",
                       allows_multiple_answers: bool = None,
                       reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "question": question, "options": options,
                "is_anonymous": is_anonymous, "type": type}
        if allows_multiple_answers is not None:
            data["allows_multiple_answers"] = allows_multiple_answers
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendPoll", data)
    async def send_dice(self, chat_id: int, emoji: str = None,
                       reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id}
        if emoji: data["emoji"] = emoji
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendDice", data)
    async def send_game(self, chat_id: int, game_short_name: str,
                       reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "game_short_name": game_short_name}
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("sendGame", data)
    async def send_media_group(self, chat_id: int, media: List[dict]) -> dict:
        return await self._request("sendMediaGroup", {"chat_id": chat_id, "media": json.dumps(media)})
    async def send_chat_action(self, chat_id: int, action: str) -> dict:
        return await self._request("sendChatAction", {"chat_id": chat_id, "action": action})
    # ---------- فوروارد و کپی ----------
    async def forward_message(self, chat_id: int, from_chat_id: int,
                             message_id: int) -> dict:
        return await self._request("forwardMessage", {
            "chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id
        })
    async def copy_message(self, chat_id: int, from_chat_id: int, message_id: int,
                          caption: str = None, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id}
        if caption: data["caption"] = caption
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("copyMessage", data)
    # ---------- حذف ----------
    async def delete_message(self, chat_id: int, message_id: int) -> dict:
        return await self._request("deleteMessage", {"chat_id": chat_id, "message_id": message_id})
    # ---------- ویرایش ----------
    async def edit_message_text(self, chat_id: int, message_id: int, text: str,
                               parse_mode: str = None, reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "message_id": message_id, "text": text}
        if parse_mode: data["parse_mode"] = parse_mode
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("editMessageText", data)
    async def edit_message_reply_markup(self, chat_id: int, message_id: int,
                                        reply_markup: dict = None) -> dict:
        data = {"chat_id": chat_id, "message_id": message_id}
        if reply_markup: data["reply_markup"] = reply_markup
        return await self._request("editMessageReplyMarkup", data)
    # ---------- کال‌بک ----------
    async def answer_callback_query(self, callback_query_id: str, text: str = None,
                                   show_alert: bool = False) -> dict:
        data = {"callback_query_id": callback_query_id}
        if text: data["text"] = text
        if show_alert: data["show_alert"] = show_alert
        return await self._request("answerCallbackQuery", data)
    # ---------- مدیریت چت ----------
    async def get_chat(self, chat_id: int) -> dict:
        return await self._request("getChat", {"chat_id": chat_id})
    async def get_chat_administrators(self, chat_id: int) -> dict:
        return await self._request("getChatAdministrators", {"chat_id": chat_id})
    async def get_chat_member(self, chat_id: int, user_id: int) -> dict:
        return await self._request("getChatMember", {"chat_id": chat_id, "user_id": user_id})
    async def get_chat_members_count(self, chat_id: int) -> dict:
        return await self._request("getChatMembersCount", {"chat_id": chat_id})
    async def kick_chat_member(self, chat_id: int, user_id: int) -> dict:
        return await self._request("kickChatMember", {"chat_id": chat_id, "user_id": user_id})
    async def unban_chat_member(self, chat_id: int, user_id: int) -> dict:
        return await self._request("unbanChatMember", {"chat_id": chat_id, "user_id": user_id})
    async def restrict_chat_member(self, chat_id: int, user_id: int,
                                    permissions: dict) -> dict:
        return await self._request("restrictChatMember", {
            "chat_id": chat_id, "user_id": user_id, "permissions": permissions
        })
    async def promote_chat_member(self, chat_id: int, user_id: int, **kwargs) -> dict:
        data = {"chat_id": chat_id, "user_id": user_id}
        data.update(kwargs)
        return await self._request("promoteChatMember", data)
    async def set_chat_title(self, chat_id: int, title: str) -> dict:
        return await self._request("setChatTitle", {"chat_id": chat_id, "title": title})
    async def set_chat_description(self, chat_id: int, description: str) -> dict:
        return await self._request("setChatDescription", {"chat_id": chat_id, "description": description})
    async def set_chat_photo(self, chat_id: int, photo: str) -> dict:
        return await self._send_file("setChatPhoto", {"chat_id": chat_id}, "photo", photo)
    async def delete_chat_photo(self, chat_id: int) -> dict:
        return await self._request("deleteChatPhoto", {"chat_id": chat_id})
    async def export_chat_invite_link(self, chat_id: int) -> dict:
        return await self._request("exportChatInviteLink", {"chat_id": chat_id})
    async def create_chat_invite_link(self, chat_id: int, expire_date: int = None,
                                       member_limit: int = None) -> dict:
        data = {"chat_id": chat_id}
        if expire_date: data["expire_date"] = expire_date
        if member_limit: data["member_limit"] = member_limit
        return await self._request("createChatInviteLink", data)
    async def leave_chat(self, chat_id: int) -> dict:
        return await self._request("leaveChat", {"chat_id": chat_id})
    async def pin_chat_message(self, chat_id: int, message_id: int,
                               disable_notification: bool = None) -> dict:
        data = {"chat_id": chat_id, "message_id": message_id}
        if disable_notification: data["disable_notification"] = disable_notification
        return await self._request("pinChatMessage", data)
    async def unpin_chat_message(self, chat_id: int, message_id: int = None) -> dict:
        data = {"chat_id": chat_id}
        if message_id: data["message_id"] = message_id
        return await self._request("unpinChatMessage", data)
    # ---------- فایل ----------
    async def get_file(self, file_id: str) -> dict:
        return await self._request("getFile", {"file_id": file_id})
    async def get_file_url(self, file_id: str) -> Optional[str]:
        result = await self.get_file(file_id)
        if result.get("ok"):
            file_path = result["result"]["file_path"]
            return f"https://tapi.bale.ai/file/bot{self.token}/{file_path}"
        return None
    # ---------- دستورات ربات ----------
    async def set_my_commands(self, commands: List[dict]) -> dict:
        return await self._request("setMyCommands", {"commands": commands})
    async def get_my_commands(self) -> dict:
        return await self._request("getMyCommands")
    async def delete_my_commands(self) -> dict:
        return await self._request("deleteMyCommands")
    # ---------- اینلاین ----------
    async def answer_inline_query(self, inline_query_id: str, results: List[dict],
                                  cache_time: int = 300, next_offset: str = None) -> dict:
        data = {"inline_query_id": inline_query_id, "results": results, "cache_time": cache_time}
        if next_offset: data["next_offset"] = next_offset
        return await self._request("answerInlineQuery", data)
    # ---------- واکنش ----------
    async def set_message_reaction(self, chat_id: int, message_id: int,
                                   emoji: str = None) -> dict:
        reaction = []
        if emoji:
            reaction = [{"type": "emoji", "emoji": emoji}]
        return await self._request("setMessageReaction", {
            "chat_id": chat_id, "message_id": message_id, "reaction": reaction
        })
# ==================== ربات سینک ====================
class NevitBot:
    """
    🏆 کلاس اصلی ربات نوا (نسخه سینک) 🏆
    این کلاس هم از متدهای سینک و هم آسینک پشتیبانی می‌کند.
    📚 مثال استفاده:
        bot = NevitBot("TOKEN")
        @bot.command(["start", "help"])
        def start(msg):
            bot.reply(msg, "سلام! خوش آمدید")
        @bot.message(Filters.text)
        def handle_text(msg):
            bot.reply(msg, f"پیام دریافتی: {msg.text}")
        bot.run()
    """
    def __init__(self, token: str):
        """
        ایجاد ربات
        Args:
            token: توکن ربات از BotFather
        """
        self.client = NevitClient(token)
        self.offset = 0
        self.commands: Dict[str, Callable] = {}
        self.messages: List[tuple] = []
        self.callbacks: Dict[str, Callable] = {}
        self.default_message_handler: Optional[Callable] = None
        self.default_callback_handler: Optional[Callable] = None
        self.inline_handler: Optional[Callable] = None
        self.callback_query_handler: Optional[Callable] = None
        # سیستم Middleware
        self.middleware_manager = MiddlewareManager()
        # سیستم Error Handler
        self.error_handler = ErrorHandler()
        # تست اتصال
        me = self.client.get_me()
        if me.get("ok"):
            self._bot_info = me["result"]
            logger.info(f"✅ ربات {self._bot_info['first_name']} متصل شد!")
            logger.info(f"📚 کتابخانه Nevit آماده است - نسخه {VERSION}")
        else:
            logger.error("❌ خطا در اتصال به ربات")
            raise Exception("توکن نامعتبر است!")
    @property
    def bot_info(self):
        """اطلاعات ربات"""
        return self._bot_info
    # ---------- متدهای کمکی برای ارسال پیام ----------
    def reply(self, message: Message, text: str, **kwargs) -> dict:
        """پاسخ به پیام"""
        return self.send_message(message.chat.id, text, reply_to_message_id=message.message_id, **kwargs)
    def send_message(self, chat_id: int, text: str, **kwargs) -> dict:
        """ارسال پیام"""
        return self.client.send_message(chat_id, text, **kwargs)
    def send_photo(self, chat_id: int, photo: str, **kwargs) -> dict:
        """ارسال عکس"""
        return self.client.send_photo(chat_id, photo, **kwargs)
    def send_video(self, chat_id: int, video: str, **kwargs) -> dict:
        """ارسال ویدیو"""
        return self.client.send_video(chat_id, video, **kwargs)
    def send_audio(self, chat_id: int, audio: str, **kwargs) -> dict:
        """ارسال صوتی"""
        return self.client.send_audio(chat_id, audio, **kwargs)
    def send_voice(self, chat_id: int, voice: str, **kwargs) -> dict:
        """ارسال ویس"""
        return self.client.send_voice(chat_id, voice, **kwargs)
    def send_document(self, chat_id: int, document: str, **kwargs) -> dict:
        """ارسال سند"""
        return self.client.send_document(chat_id, document, **kwargs)
    def send_sticker(self, chat_id: int, sticker: str, **kwargs) -> dict:
        """ارسال استیکر"""
        return self.client.send_sticker(chat_id, sticker, **kwargs)
    def send_location(self, chat_id: int, latitude: float, longitude: float, **kwargs) -> dict:
        """ارسال موقعیت"""
        return self.client.send_location(chat_id, latitude, longitude, **kwargs)
    def send_contact(self, chat_id: int, phone_number: str, first_name: str, **kwargs) -> dict:
        """ارسال مخاطب"""
        return self.client.send_contact(chat_id, phone_number, first_name, **kwargs)
    def send_poll(self, chat_id: int, question: str, options: List[str], **kwargs) -> dict:
        """ارسال نظرسنجی"""
        return self.client.send_poll(chat_id, question, options, **kwargs)
    def send_dice(self, chat_id: int, emoji: str = None, **kwargs) -> dict:
        """ارسال تاس"""
        return self.client.send_dice(chat_id, emoji, **kwargs)
    def forward_message(self, chat_id: int, from_chat_id: int, message_id: int) -> dict:
        """فوروارد پیام"""
        return self.client.forward_message(chat_id, from_chat_id, message_id)
    def copy_message(self, chat_id: int, from_chat_id: int, message_id: int, **kwargs) -> dict:
        """کپی پیام"""
        return self.client.copy_message(chat_id, from_chat_id, message_id, **kwargs)
    def delete_message(self, chat_id: int, message_id: int) -> dict:
        """حذف پیام"""
        return self.client.delete_message(chat_id, message_id)
    def edit_message_text(self, chat_id: int, message_id: int, text: str, **kwargs) -> dict:
        """ویرایش متن پیام"""
        return self.client.edit_message_text(chat_id, message_id, text, **kwargs)
    def edit_message_reply_markup(self, chat_id: int, message_id: int, **kwargs) -> dict:
        """ویرایش کیبورد پیام"""
        return self.client.edit_message_reply_markup(chat_id, message_id, **kwargs)
    def answer_callback(self, callback_query_id: str, text: str = None,
                       show_alert: bool = False) -> dict:
        """پاسخ به کال‌بک"""
        return self.client.answer_callback_query(callback_query_id, text, show_alert)
    # ---------- متدهای مدیریت چت ----------
    def get_chat(self, chat_id: int) -> dict:
        return self.client.get_chat(chat_id)
    def get_chat_administrators(self, chat_id: int) -> dict:
        return self.client.get_chat_administrators(chat_id)
    def get_chat_member(self, chat_id: int, user_id: int) -> dict:
        return self.client.get_chat_member(chat_id, user_id)
    def get_chat_members_count(self, chat_id: int) -> dict:
        return self.client.get_chat_members_count(chat_id)
    def kick_member(self, chat_id: int, user_id: int) -> dict:
        return self.client.kick_chat_member(chat_id, user_id)
    def unban_member(self, chat_id: int, user_id: int) -> dict:
        return self.client.unban_chat_member(chat_id, user_id)
    def leave_chat(self, chat_id: int) -> dict:
        return self.client.leave_chat(chat_id)
    def pin_message(self, chat_id: int, message_id: int, **kwargs) -> dict:
        return self.client.pin_chat_message(chat_id, message_id, **kwargs)
    def unpin_message(self, chat_id: int, message_id: int = None) -> dict:
        return self.client.unpin_chat_message(chat_id, message_id)
    # ---------- دکوراتورها ----------
    def command(self, commands: List[str]):
        """
        دکوراتور برای ثبت دستور
        مثال:
            @bot.command(["start", "help"])
            def start(msg): ...
        """
        def decorator(func: Callable):
            for cmd in commands:
                self.commands[cmd] = func
            return func
        return decorator
    def message(self, filters=None):
        """
        دکوراتور برای ثبت هندلر پیام
        مثال:
            @bot.message(Filters.text)
            def handle(msg): ...
        """
        def decorator(func: Callable):
            self.messages.append((filters, func))
            return func
        return decorator
    def callback(self, pattern: str = None):
        """
        دکوراتور برای ثبت هندلر کال‌بک
        مثال:
            @bot.callback("confirm")
            def handle_callback(msg, data): ...
        """
        def decorator(func: Callable):
            if pattern:
                self.callbacks[pattern] = func
            else:
                self.default_callback_handler = func
            return func
        return decorator
    def inline(self, func: Callable):
        """دکوراتور برای ثبت هندلر اینلاین"""
        self.inline_handler = func
        return func
    def message_handler(self, filters=None):
        """دکوراتور جایگزین برای message"""
        return self.message(filters)
    def error_handler(self, func: Callable = None):
        """
        دکوراتور برای ثبت هندلر خطا
        مثال:
            @bot.error_handler()
            def handle_error(error, context):
                print(f"خطا: {error}")
        """
        if func:
            self.error_handler.handlers.append(func)
            return func
        return func
    # ---------- مدیریت Middleware ----------
    def add_middleware(self, middleware: Middleware):
        """
        اضافه کردن میان‌افزار
        مثال:
            bot.add_middleware(LoggingMiddleware())
            bot.add_middleware(RateLimitMiddleware())
        """
        self.middleware_manager.add(middleware)
    # ---------- اجرای ربات ----------
    def run(self):
        """
        اجرای ربات (حلقه اصلی)
        این متد ربات را در حالت سینک اجرا می‌کند.
        """
        logger.info("🤖 ربات Nevit فعال شد...\n")
        while True:
            try:
                updates = self.client.get_updates(offset=self.offset, timeout=60)
                if updates.get("ok"):
                    for result in updates.get("result", []):
                        update = result.get("update_id", 0)
                        # هندلر کال‌بک
                        if "callback_query" in result:
                            try:
                                self._handle_callback(result["callback_query"])
                            except Exception as e:
                                asyncio.get_event_loop().run_until_complete(
                                    self.error_handler.emit(e, {"update": result})
                                )
                            self.offset = update + 1
                            continue
                        # هندلر اینلاین
                        if "inline_query" in result:
                            if self.inline_handler:
                                try:
                                    self.inline_handler(result["inline_query"])
                                except Exception as e:
                                    asyncio.get_event_loop().run_until_complete(
                                        self.error_handler.emit(e, {"update": result})
                                    )
                            self.offset = update + 1
                            continue
                        # پیام معمولی
                        if "message" in result:
                            try:
                                msg = self._parse_message(result["message"])
                                self._handle_message(msg)
                            except Exception as e:
                                asyncio.get_event_loop().run_until_complete(
                                    self.error_handler.emit(e, {"update": result})
                                )
                            self.offset = update + 1
                            continue
            except Exception as e:
                logger.error(f"⚠️ خطا: {e}")
                time.sleep(1)
    def _handle_message(self, message: Message):
        """پردازش پیام دریافتی"""
        # اجرای Middleware pre_process
        message = asyncio.get_event_loop().run_until_complete(
            self.middleware_manager.pre_process(message, {})
        )
        if message is None:
            return
        # چک کردن دستور
        if message.text and message.text.startswith("/"):
            cmd = message.text[1:].split()[0]
            if cmd in self.commands:
                try:
                    self.commands[cmd](message)
                except Exception as e:
                    asyncio.get_event_loop().run_until_complete(
                        self.error_handler.emit(e, {"message": message, "command": cmd})
                    )
                return
        # چک کردن فیلترها
        for filter_func, handler in self.messages:
            try:
                if filter_func is None or filter_func(message):
                    handler(message)
                    return
            except Exception as e:
                asyncio.get_event_loop().run_until_complete(
                    self.error_handler.emit(e, {"message": message})
                )
        # هندلر پیش‌فرض
        if self.default_message_handler:
            self.default_message_handler(message)
    def _handle_callback(self, callback_data: dict):
        """پردازش کال‌بک"""
        query_id = callback_data.get("id", "")
        data = callback_data.get("data", "")
        # ساخت پیام موقت
        msg_data = callback_data.get("message", {})
        if msg_data:
            chat_data = msg_data.get("chat", {})
            user_data = callback_data.get("from", {})
            chat = Chat(
                id=chat_data.get("id", 0),
                type=chat_data.get("type", "private"),
                title=chat_data.get("title"),
                username=chat_data.get("username")
            )
            user = User(
                id=user_data.get("id", 0),
                first_name=user_data.get("first_name", ""),
                username=user_data.get("username")
            )
            message = Message(
                message_id=msg_data.get("message_id", 0),
                date=msg_data.get("date", 0),
                chat=chat,
                from_user=user,
                text=msg_data.get("text")
            )
            message.callback_query = callback_data
            # هندلر کال‌بک
            found = False
            for pattern, handler in self.callbacks.items():
                if pattern == data:
                    try:
                        handler(message, data)
                    except Exception as e:
                        asyncio.get_event_loop().run_until_complete(
                            self.error_handler.emit(e, {"callback": callback_data})
                        )
                    found = True
                    break
            if not found and self.default_callback_handler:
                try:
                    self.default_callback_handler(message, data)
                except Exception as e:
                    asyncio.get_event_loop().run_until_complete(
                        self.error_handler.emit(e, {"callback": callback_data})
                    )
        # پاسخ به کال‌بک
        self.client.answer_callback_query(query_id)
    def _parse_message(self, data: dict) -> Message:
        """پارس کردن پیام JSON"""
        user_data = data.get("from", {})
        user = None
        if user_data:
            user = User(
                id=user_data.get("id", 0),
                first_name=user_data.get("first_name", ""),
                last_name=user_data.get("last_name"),
                username=user_data.get("username"),
                language_code=user_data.get("language_code"),
                is_bot=user_data.get("is_bot", False)
            )
        chat_data = data.get("chat", {})
        chat = Chat(
            id=chat_data.get("id", 0),
            type=chat_data.get("type", "private"),
            title=chat_data.get("title"),
            username=chat_data.get("username"),
            first_name=chat_data.get("first_name"),
            last_name=chat_data.get("last_name")
        )
        message = Message(
            message_id=data.get("message_id", 0),
            date=data.get("date", 0),
            chat=chat,
            from_user=user,
            text=data.get("text"),
            caption=data.get("caption")
        )
        # اضافه کردن فیلدهای اضافی
        for key in ['photo', 'video', 'audio', 'voice', 'document', 'sticker',
                   'location', 'venue', 'contact', 'poll', 'dice', 'game',
                   'invoice', 'new_chat_members', 'left_chat_member',
                   'forward_date', 'forward_from', 'edit_date', 'game']:
            if key in data:
                setattr(message, key, data[key])
        return message
    def stop(self):
        """توقف ربات"""
        logger.info("🛑 ربات متوقف شد")
        exit(0)
# ==================== ربات آسینک ====================
class NevitAsyncBot:
    """
    🏆 کلاس اصلی ربات نوا (نسخه کاملاً آسینک) 🏆
    این کلاس برای استفاده با asyncio طراحی شده است.
    📚 مثال استفاده:
        bot = NevitAsyncBot("TOKEN")
        @bot.command(["start", "help"])
        async def start(msg):
            await bot.reply(msg, "سلام! خوش آمدید")
        @bot.message(Filters.text)
        async def handle_text(msg):
            await bot.reply(msg, f"پیام دریافتی: {msg.text}")
        await bot.run()
        # یا با main:
        # asyncio.run(bot.run())
    """
    def __init__(self, token: str):
        """
        ایجاد ربات آسینک
        Args:
            token: توکن ربات از BotFather
        """
        self.client = NevitAsyncClient(token)
        self.offset = 0
        self.commands: Dict[str, Callable] = {}
        self.messages: List[tuple] = []
        self.callbacks: Dict[str, Callable] = {}
        self.default_message_handler: Optional[Callable] = None
        self.default_callback_handler: Optional[Callable] = None
        self.inline_handler: Optional[Callable] = None
        # سیستم Middleware
        self.middleware_manager = MiddlewareManager()
        # سیستم Error Handler
        self.error_handler = ErrorHandler()
        # تست اتصال
        import asyncio
        loop = asyncio.get_event_loop()
        me = loop.run_until_complete(self.client.get_me())
        if me.get("ok"):
            self._bot_info = me["result"]
            logger.info(f"✅ ربات {self._bot_info['first_name']} متصل شد!")
            logger.info(f"📚 کتابخانه Nevit آماده است - نسخه {VERSION}")
        else:
            logger.error("❌ خطا در اتصال به ربات")
            raise Exception("توکن نامعتبر است!")
    @property
    def bot_info(self):
        """اطلاعات ربات"""
        return self._bot_info
    # ---------- متدهای کمکی برای ارسال پیام (آسینک) ----------
    async def reply(self, message: Message, text: str, **kwargs) -> dict:
        """پاسخ به پیام"""
        return await self.send_message(message.chat.id, text,
                                       reply_to_message_id=message.message_id, **kwargs)
    async def send_message(self, chat_id: int, text: str, **kwargs) -> dict:
        """ارسال پیام"""
        return await self.client.send_message(chat_id, text, **kwargs)
    async def send_photo(self, chat_id: int, photo: str, **kwargs) -> dict:
        """ارسال عکس"""
        return await self.client.send_photo(chat_id, photo, **kwargs)
    async def send_video(self, chat_id: int, video: str, **kwargs) -> dict:
        """ارسال ویدیو"""
        return await self.client.send_video(chat_id, video, **kwargs)
    async def send_audio(self, chat_id: int, audio: str, **kwargs) -> dict:
        """ارسال صوتی"""
        return await self.client.send_audio(chat_id, audio, **kwargs)
    async def send_voice(self, chat_id: int, voice: str, **kwargs) -> dict:
        """ارسال ویس"""
        return await self.client.send_voice(chat_id, voice, **kwargs)
    async def send_document(self, chat_id: int, document: str, **kwargs) -> dict:
        """ارسال سند"""
        return await self.client.send_document(chat_id, document, **kwargs)
    async def send_sticker(self, chat_id: int, sticker: str, **kwargs) -> dict:
        """ارسال استیکر"""
        return await self.client.send_sticker(chat_id, sticker, **kwargs)
    async def send_location(self, chat_id: int, latitude: float, longitude: float, **kwargs) -> dict:
        """ارسال موقعیت"""
        return await self.client.send_location(chat_id, latitude, longitude, **kwargs)
    async def send_contact(self, chat_id: int, phone_number: str, first_name: str, **kwargs) -> dict:
        """ارسال مخاطب"""
        return await self.client.send_contact(chat_id, phone_number, first_name, **kwargs)
    async def send_poll(self, chat_id: int, question: str, options: List[str], **kwargs) -> dict:
        """ارسال نظرسنجی"""
        return await self.client.send_poll(chat_id, question, options, **kwargs)
    async def send_dice(self, chat_id: int, emoji: str = None, **kwargs) -> dict:
        """ارسال تاس"""
        return await self.client.send_dice(chat_id, emoji, **kwargs)
    async def send_media_group(self, chat_id: int, media: List[dict]) -> dict:
        """ارسال گروه مدیا"""
        return await self.client.send_media_group(chat_id, media)
    async def send_chat_action(self, chat_id: int, action: str) -> dict:
        """ارسال اکشن"""
        return await self.client.send_chat_action(chat_id, action)
    async def forward_message(self, chat_id: int, from_chat_id: int, message_id: int) -> dict:
        """فوروارد پیام"""
        return await self.client.forward_message(chat_id, from_chat_id, message_id)
    async def copy_message(self, chat_id: int, from_chat_id: int, message_id: int, **kwargs) -> dict:
        """کپی پیام"""
        return await self.client.copy_message(chat_id, from_chat_id, message_id, **kwargs)
    async def delete_message(self, chat_id: int, message_id: int) -> dict:
        """حذف پیام"""
        return await self.client.delete_message(chat_id, message_id)
    async def edit_message_text(self, chat_id: int, message_id: int, text: str, **kwargs) -> dict:
        """ویرایش متن پیام"""
        return await self.client.edit_message_text(chat_id, message_id, text, **kwargs)
    async def edit_message_reply_markup(self, chat_id: int, message_id: int, **kwargs) -> dict:
        """ویرایش کیبورد پیام"""
        return await self.client.edit_message_reply_markup(chat_id, message_id, **kwargs)
    async def answer_callback(self, callback_query_id: str, text: str = None,
                              show_alert: bool = False) -> dict:
        """پاسخ به کال‌بک"""
        return await self.client.answer_callback_query(callback_query_id, text, show_alert)
    # ---------- متدهای مدیریت چت (آسینک) ----------
    async def get_chat(self, chat_id: int) -> dict:
        return await self.client.get_chat(chat_id)
    async def get_chat_administrators(self, chat_id: int) -> dict:
        return await self.client.get_chat_administrators(chat_id)
    async def get_chat_member(self, chat_id: int, user_id: int) -> dict:
        return await self.client.get_chat_member(chat_id, user_id)
    async def get_chat_members_count(self, chat_id: int) -> dict:
        return await self.client.get_chat_members_count(chat_id)
    async def kick_member(self, chat_id: int, user_id: int) -> dict:
        return await self.client.kick_chat_member(chat_id, user_id)
    async def unban_member(self, chat_id: int, user_id: int) -> dict:
        return await self.client.unban_chat_member(chat_id, user_id)
    async def leave_chat(self, chat_id: int) -> dict:
        return await self.client.leave_chat(chat_id)
    async def pin_message(self, chat_id: int, message_id: int, **kwargs) -> dict:
        return await self.client.pin_chat_message(chat_id, message_id, **kwargs)
    async def unpin_message(self, chat_id: int, message_id: int = None) -> dict:
        return await self.client.unpin_chat_message(chat_id, message_id)
    # ---------- دکوراتورها ----------
    def command(self, commands: List[str]):
        """
        دکوراتور برای ثبت دستور
        مثال:
            @bot.command(["start", "help"])
            async def start(msg): ...
        """
        def decorator(func: Callable):
            for cmd in commands:
                self.commands[cmd] = func
            return func
        return decorator
    def message(self, filters=None):
        """
        دکوراتور برای ثبت هندلر پیام
        مثال:
            @bot.message(Filters.text)
            async def handle(msg): ...
        """
        def decorator(func: Callable):
            self.messages.append((filters, func))
            return func
        return decorator
    def callback(self, pattern: str = None):
        """
        دکوراتور برای ثبت هندلر کال‌بک
        مثال:
            @bot.callback("confirm")
            async def handle_callback(msg, data): ...
        """
        def decorator(func: Callable):
            if pattern:
                self.callbacks[pattern] = func
            else:
                self.default_callback_handler = func
            return func
        return decorator
    def inline(self, func: Callable):
        """دکوراتور برای ثبت هندلر اینلاین"""
        self.inline_handler = func
        return func
    def message_handler(self, filters=None):
        """دکوراتور جایگزین برای message"""
        return self.message(filters)
    def error_handler(self, func: Callable = None):
        """
        دکوراتور برای ثبت هندلر خطا
        مثال:
            @bot.error_handler()
            async def handle_error(error, context):
                print(f"خطا: {error}")
        """
        if func:
            self.error_handler.handlers.append(func)
            return func
        return func
    # ---------- مدیریت Middleware ----------
    def add_middleware(self, middleware: Middleware):
        """
        اضافه کردن میان‌افزار
        مثال:
            bot.add_middleware(LoggingMiddleware())
            bot.add_middleware(RateLimitMiddleware())
        """
        self.middleware_manager.add(middleware)
    # ---------- اجرای ربات ----------
    async def run(self):
        """
        اجرای ربات (حلقه اصلی آسینک)
        این متد ربات را در حالت آسینک اجرا می‌کند.
        """
        logger.info("🤖 ربات Nevit (آسینک) فعال شد...\n")
        while True:
            try:
                updates = await self.client.get_updates(offset=self.offset, timeout=60)
                if updates.get("ok"):
                    for result in updates.get("result", []):
                        update = result.get("update_id", 0)
                        # هندلر کال‌بک
                        if "callback_query" in result:
                            try:
                                await self._handle_callback(result["callback_query"])
                            except Exception as e:
                                await self.error_handler.emit(e, {"update": result})
                            self.offset = update + 1
                            continue
                        # هندلر اینلاین
                        if "inline_query" in result:
                            if self.inline_handler:
                                try:
                                    await self.inline_handler(result["inline_query"])
                                except Exception as e:
                                    await self.error_handler.emit(e, {"update": result})
                            self.offset = update + 1
                            continue
                        # پیام معمولی
                        if "message" in result:
                            try:
                                msg = self._parse_message(result["message"])
                                await self._handle_message(msg)
                            except Exception as e:
                                await self.error_handler.emit(e, {"update": result})
                            self.offset = update + 1
                            continue
            except Exception as e:
                logger.error(f"⚠️ خطا: {e}")
                await asyncio.sleep(1)
    async def _handle_message(self, message: Message):
        """پردازش پیام دریافتی"""
        # اجرای Middleware pre_process
        message = await self.middleware_manager.pre_process(message, {})
        if message is None:
            return
        # چک کردن دستور
        if message.text and message.text.startswith("/"):
            cmd = message.text[1:].split()[0]
            if cmd in self.commands:
                try:
                    await self.commands[cmd](message)
                except Exception as e:
                    await self.error_handler.emit(e, {"message": message, "command": cmd})
                return
        # چک کردن فیلترها
        for filter_func, handler in self.messages:
            try:
                if filter_func is None or filter_func(message):
                    await handler(message)
                    return
            except Exception as e:
                await self.error_handler.emit(e, {"message": message})
        # هندلر پیش‌فرض
        if self.default_message_handler:
            await self.default_message_handler(message)
    async def _handle_callback(self, callback_data: dict):
        """پردازش کال‌بک"""
        query_id = callback_data.get("id", "")
        data = callback_data.get("data", "")
        # ساخت پیام موقت
        msg_data = callback_data.get("message", {})
        if msg_data:
            chat_data = msg_data.get("chat", {})
            user_data = callback_data.get("from", {})
            chat = Chat(
                id=chat_data.get("id", 0),
                type=chat_data.get("type", "private"),
                title=chat_data.get("title"),
                username=chat_data.get("username")
            )
            user = User(
                id=user_data.get("id", 0),
                first_name=user_data.get("first_name", ""),
                username=user_data.get("username")
            )
            message = Message(
                message_id=msg_data.get("message_id", 0),
                date=msg_data.get("date", 0),
                chat=chat,
                from_user=user,
                text=msg_data.get("text")
            )
            message.callback_query = callback_data
            # هندلر کال‌بک
            found = False
            for pattern, handler in self.callbacks.items():
                if pattern == data:
                    try:
                        await handler(message, data)
                    except Exception as e:
                        await self.error_handler.emit(e, {"callback": callback_data})
                    found = True
                    break
            if not found and self.default_callback_handler:
                try:
                    await self.default_callback_handler(message, data)
                except Exception as e:
                    await self.error_handler.emit(e, {"callback": callback_data})
        # پاسخ به کال‌بک
        await self.client.answer_callback_query(query_id)
    def _parse_message(self, data: dict) -> Message:
        """پارس کردن پیام JSON"""
        user_data = data.get("from", {})
        user = None
        if user_data:
            user = User(
                id=user_data.get("id", 0),
                first_name=user_data.get("first_name", ""),
                last_name=user_data.get("last_name"),
                username=user_data.get("username"),
                language_code=user_data.get("language_code"),
                is_bot=user_data.get("is_bot", False)
            )
        chat_data = data.get("chat", {})
        chat = Chat(
            id=chat_data.get("id", 0),
            type=chat_data.get("type", "private"),
            title=chat_data.get("title"),
            username=chat_data.get("username"),
            first_name=chat_data.get("first_name"),
            last_name=chat_data.get("last_name")
        )
        message = Message(
            message_id=data.get("message_id", 0),
            date=data.get("date", 0),
            chat=chat,
            from_user=user,
            text=data.get("text"),
            caption=data.get("caption")
        )
        # اضافه کردن فیلدهای اضافی
        for key in ['photo', 'video', 'audio', 'voice', 'document', 'sticker',
                   'location', 'venue', 'contact', 'poll', 'dice', 'game',
                   'invoice', 'new_chat_members', 'left_chat_member',
                   'forward_date', 'forward_from', 'edit_date', 'game']:
            if key in data:
                setattr(message, key, data[key])
        return message
    async def stop(self):
        """توقف ربات"""
        logger.info("🛑 ربات متوقف شد")
# ==================== صادرات ====================
__version__ = VERSION
__all__ = [
    # کلاس‌های اصلی
    "NevitBot",
    "NevitAsyncBot",
    "NevitClient",
    "NevitAsyncClient",
    # دیتاسنترها
    "User",
    "Chat",
    "Message",
    # کیبوردها
    "InlineKeyboardButton",
    "InlineKeyboardMarkup",
    "ReplyKeyboardMarkup",
    "ReplyKeyboardRemove",
    "KeyboardButton",
    # فیلترها
    "Filters",
    # Enums
    "ChatType",
    "ParseMode",
    "ChatAction",
    "DiceEmoji",
    # سیستم Middleware
    "Middleware",
    "MiddlewareManager",
    "LoggingMiddleware",
    "RateLimitMiddleware",
    "AntiSpamMiddleware",
    # سیستم Error Handler
    "ErrorHandler",
]
# ==================== مثال‌های استفاده ====================
if __name__ == "__main__":
    """
    📚 مثال‌های استفاده از کتابخانه Nevit
    مثال ۱: ربات ساده
    --------------------
    from nevit import NevitBot, Filters
    bot = NevitBot("TOKEN")
    @bot.command(["start", "help"])
    def start(msg):
        bot.reply(msg, "سلام! خوش آمدید")
    @bot.message(Filters.text)
    def handle(msg):
        bot.reply(msg, f"پیام شما: {msg.text}")
    bot.run()
    مثال ۲: ربات آسینک
    --------------------
    import asyncio
    from nevit import NevitAsyncBot, Filters
    bot = NevitAsyncBot("TOKEN")
    @bot.command(["start"])
    async def start(msg):
        await bot.reply(msg, "سلام! خوش آمدید")
    asyncio.run(bot.run())
    مثال ۳: استفاده از Middleware
    --------------------
    from nevit import NevitBot, Filters, LoggingMiddleware, RateLimitMiddleware
    bot = NevitBot("TOKEN")
    # اضافه کردن میان‌افزار
    bot.add_middleware(LoggingMiddleware())
    bot.add_middleware(RateLimitMiddleware(max_requests=5, time_window=60))
    @bot.command(["start"])
    def start(msg):
        bot.reply(msg, "سلام!")
    bot.run()
    مثال ۴: استفاده از Error Handler
    --------------------
    from nevit import NevitBot
    bot = NevitBot("TOKEN")
    @bot.error_handler()
    def handle_error(error, context):
        print(f"❌ خطا رخ داد: {error}")
        print(f"📋 کانتکست: {context}")
    @bot.command(["start"])
    def start(msg):
        # این خطا تولید می‌کند
        raise Exception("تست خطا")
    bot.run()
    مثال ۵: کیبوردهای مختلف
    --------------------
    from nevit import NevitBot, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup
    bot = NevitBot("TOKEN")
    @bot.command(["start"])
    def start(msg):
        # کیبورد اینلاین
        keyboard = InlineKeyboardMarkup()
        keyboard.add(
            InlineKeyboardButton("🔗 لینک", url="https://example.com"),
            InlineKeyboardButton("⚙️ تنظیمات", callback_data="settings")
        )
        bot.reply(msg, "یک گزینه انتخاب کنید:", reply_markup=keyboard.to_dict())
    @bot.callback("settings")
    def settings(msg, data):
        bot.reply(msg, "تنظیمات ربات")
    bot.run()
    """
    print(f"""
╔══════════════════════════════════════════════════════════════════════════╗
║   🏆 NEVIT LIBRARY v{VERSION} - کتابخانه ربات تلگرام/بله 🏆                ║
╠══════════════════════════════════════════════════════════════════════════╣
║                                                                          ║
║   ✅ Async Support - پشتیبانی کامل از asyncio                          ║
║   ✅ Middleware System - سیستم میان‌افزار                                ║
║   ✅ Error Handler - مدیریت متمرکز خطاها                                ║
║   ✅ Filters - فیلترهای قدرتمند                                         ║
║   ✅ Inline Keyboards - کیبوردهای اینلاین                                ║
║   ✅ Callback Queries - پشتیبانی کامل از کال‌بک                          ║
║                                                                          ║
╠══════════════════════════════════════════════════════════════════════════╣
║   📚 مستندات: https://github.com/nevit-library/docs                      ║
║   💻 مثال‌ها: در انتهای فایل کد ببینید                                    ║
╚══════════════════════════════════════════════════════════════════════════╝
    """)