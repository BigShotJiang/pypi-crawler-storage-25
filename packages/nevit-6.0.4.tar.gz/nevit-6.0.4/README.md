# NAVA Library
کتابخانه ساده و قدرتمند برای ساخت ربات بله/تلگرام

## نصب
pip install nevit

## استفاده
from nava import nevitBot
...