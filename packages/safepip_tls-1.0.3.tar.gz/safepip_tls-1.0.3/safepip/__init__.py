﻿"""SafePip - Secure Python dependency management with encrypted connections"""

__version__ = "1.0.0"
__author__ = "GitHub Community Tool"

from .cli import cli

def main():
    import sys
    return cli.main()

if __name__ == "__main__":
    sys.exit(main())