﻿"""Main CLI interface for SafePip with encrypted connections"""

import click
import json
import sys
import subprocess
import venv
from pathlib import Path
from typing import Dict
import requests
import certifi

class SafePip:
    def __init__(self, project_dir: str = "."):
        self.project_dir = Path(project_dir).resolve()
        self.lock_file = self.project_dir / "safepip.lock"
        
    def load_lock(self) -> Dict:
        if not self.lock_file.exists():
            return {"packages": {}}
        with open(self.lock_file, 'r') as f:
            return json.load(f)
    
    def save_lock(self, data: Dict):
        with open(self.lock_file, 'w') as f:
            json.dump(data, f, indent=2)

@click.group()
@click.option("--project-dir", default=".", help="Project directory")
@click.pass_context
def cli(ctx, project_dir):
    """SafePip - Secure Python dependency management"""
    ctx.obj = SafePip(project_dir)

@cli.command()
@click.pass_obj
def init(safepip):
    """Initialize a new Python project"""
    config_path = safepip.project_dir / "safepip.toml"
    
    if config_path.exists():
        if not click.confirm("safepip.toml already exists. Overwrite?"):
            return
    
    config_content = f'''[project]
name = "{safepip.project_dir.name}"
version = "0.1.0"
python_version = ">=3.8"

[dependencies]
requests = "^2.31.0"

[security]
encrypt_connections = true
'''
    
    with open(config_path, 'w') as f:
        f.write(config_content)
    
    venv_path = safepip.project_dir / ".venv"
    if not venv_path.exists():
        click.echo("Creating virtual environment...")
        venv.create(venv_path, with_pip=True)
        click.secho("✅ Virtual environment created", fg="green")
    
    click.secho("\n✅ Project initialized successfully!", fg="green")
    click.secho("🔧 Run 'safepip install' to install packages", fg="blue")

@cli.command()
@click.argument("packages", nargs=-1)
@click.pass_obj
def install(safepip, packages):
    """Install dependencies"""
    
    config_path = safepip.project_dir / "safepip.toml"
    if not config_path.exists():
        click.secho("❌ No safepip.toml found. Run 'safepip init' first", fg="red")
        return 1
    
    install_packages = list(packages) if packages else ["requests"]
    
    venv_path = safepip.project_dir / ".venv"
    if not venv_path.exists():
        click.secho("❌ Virtual environment not found. Run 'safepip init' first", fg="red")
        return 1
    
    if sys.platform == "win32":
        pip_path = venv_path / "Scripts" / "pip.exe"
    else:
        pip_path = venv_path / "bin" / "pip"
    
    click.secho(f"\n📦 Installing {len(install_packages)} packages...", fg="cyan")
    
    for package in install_packages:
        click.echo(f"  Installing {package}...")
        try:
            subprocess.run([str(pip_path), "install", package], check=True, capture_output=True)
            click.secho(f"    ✅ {package} installed", fg="green")
        except subprocess.CalledProcessError as e:
            click.secho(f"    ❌ Failed to install {package}", fg="red")
    
    click.secho("\n✅ Installation complete", fg="green")
    return 0

@cli.command()
@click.pass_obj
def list(safepip):
    """List installed packages"""
    lock_data = safepip.load_lock()
    packages = lock_data.get("packages", {})
    
    if not packages:
        click.secho("No packages installed. Run 'safepip install'", fg="yellow")
        return
    
    click.secho("\n📦 Installed Packages:", fg="cyan")
    for name in packages.keys():
        click.secho(f"  • {name}", fg="white")

@cli.command()
@click.pass_obj
def audit(safepip):
    """Check for security vulnerabilities"""
    lock_data = safepip.load_lock()
    packages = lock_data.get("packages", {})
    
    if not packages:
        click.secho("No packages installed. Run 'safepip install' first", fg="yellow")
        return 1
    
    click.secho("\n🔍 Scanning for vulnerabilities...", fg="cyan")
    
    for pkg_name in packages.keys():
        try:
            response = requests.post(
                "https://api.osv.dev/v1/query",
                json={"package": {"name": pkg_name}},
                timeout=10
            )
            result = response.json()
            if result.get("vulns"):
                click.secho(f"  ⚠️ {pkg_name} has vulnerabilities", fg="yellow")
            else:
                click.secho(f"  ✅ {pkg_name} is safe", fg="green")
        except Exception:
            click.secho(f"  ⚠️ Could not scan {pkg_name}", fg="yellow")
    
    click.secho("\n✅ Scan complete", fg="green")
    return 0

@cli.command()
def test_connection():
    """Test encrypted connection to PyPI"""
    click.secho("\n🔐 Testing Secure Connection", fg="cyan", bold=True)
    try:
        response = requests.get("https://pypi.org", timeout=10, verify=certifi.where())
        click.secho(f"✅ Connected to PyPI", fg="green")
        click.secho(f"🔒 HTTPS Encrypted", fg="green")
        return 0
    except Exception as e:
        click.secho(f"❌ Failed: {e}", fg="red")
        return 1

def main():
    try:
        return cli()
    except KeyboardInterrupt:
        click.secho("\n⚠️ Interrupted", fg="yellow")
        return 130
    except Exception as e:
        click.secho(f"\n❌ Error: {e}", fg="red")
        return 1

if __name__ == "__main__":
    sys.exit(main())
