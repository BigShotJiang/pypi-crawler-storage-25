﻿from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path("README.md")
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="safepip-tls",  # Changed to unique name
    version="1.0.3",
    description="Secure Python package manager with TLS 1.3 encryption",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="GitHub Community Tool",
    author_email="safepip@security.com",
    url="https://github.com/community/safepip",
    packages=find_packages(),
    install_requires=[
        "click>=8.0.0",
        "requests>=2.28.0",
        "packaging>=23.0",
        "tomli>=2.0.0",
        "tomli-w>=1.0.0",
        "certifi>=2023.0.0",
        "urllib3>=2.0.0",
        "cryptography>=41.0.0",
    ],
    entry_points={
        "console_scripts": [
            "safepip=safepip.cli:main",  # Keeps the same command name
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
)



