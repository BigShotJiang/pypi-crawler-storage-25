#!/usr/bin/env python3
"""Generate 'TEST SUITE DETAILS' as a styled HTML + PDF.

Usage:
    python docs/test_suite_details.py [--out <dir>]

Produces:
    test_suite_details.html   — standalone HTML (open in browser, print to PDF)
    test_suite_details.pdf    — generated via weasyprint if installed

This document is written so that a client engineer can verify all test logic
and mathematics by cross-referencing with the source files in
dk_test_suite/tests/*.py.
"""

from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

_DEFAULT_OUT = Path(__file__).resolve().parent / "output"

# ── Shared DK CSS (same as how_to_use.py) ─────────────────────
_BASE_CSS = """
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
  @page { size: A4; margin: 20mm 18mm 22mm 18mm; }

  :root {
    --bg:#1A1C1D; --surface:#222527; --surface-alt:#292D2E;
    --border:#363B3C; --accent:#DF2B3B; --accent-dim:#B91C1C;
    --success:#00D084; --warning:#F59E0B; --error:#EF4444;
    --text:#FFFFFF; --text-sec:#AAB8C8; --text-muted:#72798A;
  }
  *, *::before, *::after { box-sizing: border-box; margin:0; padding:0; }

  body {
    font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;
    background:var(--bg); color:var(--text); font-size:13.5px;
    line-height:1.65; -webkit-font-smoothing:antialiased;
  }

  .cover {
    min-height:100vh; display:flex; flex-direction:column;
    padding:64px 72px; page-break-after:always;
  }
  .cover-logo { display:flex; align-items:center; gap:12px; margin-bottom:auto; }
  .logo-mark {
    width:40px; height:40px; background:var(--accent); border-radius:4px;
    display:flex; align-items:center; justify-content:center;
    font-weight:800; font-size:16px; color:white; letter-spacing:-1px;
  }
  .cover-brand { font-size:18px; font-weight:700; color:var(--text); }
  .cover-body { flex:1; display:flex; flex-direction:column; justify-content:center; }
  .cover-label {
    font-size:11px; font-weight:600; text-transform:uppercase;
    letter-spacing:1.6px; color:var(--accent); margin-bottom:16px;
  }
  .cover h1 {
    font-size:40px; font-weight:800; line-height:1.1; color:var(--text);
    margin-bottom:16px; letter-spacing:-1px;
  }
  .cover h1 span { color:var(--accent); }
  .cover-sub { font-size:15px; color:var(--text-sec); max-width:520px; margin-bottom:48px; }
  .cover-meta { display:flex; gap:32px; flex-wrap:wrap; }
  .cover-meta-item { display:flex; flex-direction:column; gap:4px; }
  .cover-meta-label { font-size:10px; font-weight:600; text-transform:uppercase;
    letter-spacing:1.2px; color:var(--text-muted); }
  .cover-meta-val { font-size:14px; font-weight:600; color:var(--text-sec); }
  .cover-footer {
    display:flex; justify-content:space-between; align-items:center;
    padding-top:32px; border-top:1px solid var(--border);
    font-size:11px; color:var(--text-muted);
  }
  .conf-badge {
    font-size:10px; font-weight:700; text-transform:uppercase;
    letter-spacing:1px; color:var(--accent);
    border:1px solid rgba(223,43,59,0.4); border-radius:4px; padding:3px 10px;
  }

  .toc-page { padding:64px 72px; page-break-after:always; }
  .toc-title { font-size:11px; font-weight:600; text-transform:uppercase;
    letter-spacing:1.4px; color:var(--accent); margin-bottom:12px; }
  .toc-heading { font-size:24px; font-weight:700; color:var(--text); margin-bottom:32px; }
  .toc-list { list-style:none; }
  .toc-list li {
    display:flex; align-items:baseline; gap:8px;
    padding:9px 0; border-bottom:1px solid var(--border); font-size:13px;
  }
  .toc-list li:last-child { border-bottom:none; }
  .toc-num { font-size:10px; font-weight:700; color:var(--accent);
    text-transform:uppercase; letter-spacing:1px; min-width:24px; }
  .toc-name { color:var(--text); font-weight:500; flex:1; }
  .toc-dots { flex:1; border-bottom:1px dotted var(--border); min-width:20px; }
  .toc-page-num { font-size:12px; font-weight:700; color:var(--text-sec); }

  .section { padding:48px 72px; }
  .section-break { page-break-before:always; }

  .section-label { font-size:10px; font-weight:600; text-transform:uppercase;
    letter-spacing:1.4px; color:var(--accent); margin-bottom:8px; }
  h2 { font-size:24px; font-weight:700; color:var(--text);
    margin-bottom:14px; letter-spacing:-0.5px; line-height:1.2;
    page-break-after:avoid; break-after:avoid; }
  .lead { font-size:14px; color:var(--text-sec); margin-bottom:28px; line-height:1.65; }
  h3 { font-size:15px; font-weight:700; color:var(--text);
    margin-top:28px; margin-bottom:10px;
    padding-left:12px; border-left:3px solid var(--accent);
    page-break-after:avoid; break-after:avoid; }
  h4 { font-size:12px; font-weight:700; color:var(--text-sec);
    text-transform:uppercase; letter-spacing:1px;
    margin-top:18px; margin-bottom:8px; }
  p { color:var(--text-sec); margin-bottom:12px; line-height:1.65; }
  strong { color:var(--text); font-weight:600; }

  /* Test block cards */
  .test-block {
    background:var(--surface); border:1px solid var(--border);
    border-radius:4px; padding:20px 24px; margin-bottom:16px;
    page-break-inside:avoid;
  }
  .test-block-header {
    display:flex; align-items:center; gap:12px; margin-bottom:14px;
    padding-bottom:12px; border-bottom:1px solid var(--border);
  }
  .test-id {
    font-size:12px; font-weight:800; color:var(--accent);
    text-transform:uppercase; letter-spacing:1px;
    border:1px solid rgba(223,43,59,0.4); border-radius:4px;
    padding:3px 10px; white-space:nowrap;
  }
  .test-id.sec { border-color:rgba(239,68,68,0.4); color:var(--error); }
  .test-id.serv { border-color:rgba(0,208,132,0.4); color:var(--success); }
  .test-id.scale { color:var(--text-sec); border-color:var(--border); }
  .test-id.acc { color:var(--text-sec); border-color:var(--border); }
  .test-name { font-size:15px; font-weight:700; color:var(--text); }
  .test-source {
    margin-left:auto; font-size:11px; color:var(--text-muted);
    font-family:'Courier New',monospace;
  }

  .field-row { display:flex; gap:24px; flex-wrap:wrap; margin-bottom:10px; }
  .field { display:flex; flex-direction:column; gap:3px; min-width:140px; }
  .field-label { font-size:10px; font-weight:600; text-transform:uppercase;
    letter-spacing:1.2px; color:var(--text-muted); }
  .field-val { font-size:13px; font-weight:500; color:var(--text-sec); }

  /* Math formula */
  .formula {
    background:var(--surface-alt); border:1px solid var(--border);
    border-radius:4px; padding:14px 20px;
    font-family:'Courier New',Courier,monospace;
    font-size:13px; color:var(--success);
    margin:10px 0 14px; white-space:pre-wrap; line-height:1.7;
  }
  .formula-label { font-size:10px; font-weight:600; text-transform:uppercase;
    letter-spacing:1.2px; color:var(--text-muted); margin-bottom:4px; }

  pre {
    background:var(--surface-alt); border:1px solid var(--border);
    border-radius:4px; padding:14px 18px;
    font-family:'Courier New',Courier,monospace;
    font-size:11.5px; color:var(--text-sec);
    white-space:pre-wrap; word-break:break-word;
    margin-bottom:14px; line-height:1.6;
    page-break-inside:avoid; break-inside:avoid;
  }
  code {
    font-family:'Courier New',Courier,monospace; font-size:12px;
    background:var(--surface-alt); border:1px solid var(--border);
    border-radius:3px; padding:1px 6px; color:var(--accent);
  }

  table { width:100%; border-collapse:collapse; margin-bottom:16px;
    page-break-inside:auto; }
  thead { display:table-header-group; }
  tr { page-break-inside:avoid; break-inside:avoid; }
  th { background:var(--surface-alt); padding:9px 14px;
    font-size:10px; font-weight:700; text-transform:uppercase;
    letter-spacing:1px; color:var(--text-muted);
    border-bottom:1px solid var(--border); text-align:left; }
  td { padding:10px 14px; font-size:12.5px; color:var(--text-sec);
    border-bottom:1px solid var(--border); vertical-align:top; }
  tr:last-child td { border-bottom:none; }

  ul, ol { color:var(--text-sec); padding-left:20px; margin-bottom:12px; }
  li { margin-bottom:5px; }

  .card { background:var(--surface); border:1px solid var(--border);
    border-radius:4px; padding:16px 20px; margin-bottom:12px;
    page-break-inside:avoid; break-inside:avoid; }
  .card-accent { border-left:3px solid var(--accent); }
  .card-success { border-left:3px solid var(--success); }
  .card-error { border-left:3px solid var(--error); }
  .card-warn { border-left:3px solid var(--warning); }

  .pass-badge {
    display:inline-block; padding:2px 10px; border-radius:4px;
    font-size:10px; font-weight:700; letter-spacing:1px; text-transform:uppercase;
    background:rgba(0,208,132,0.12); color:var(--success);
    border:1px solid rgba(0,208,132,0.25);
  }
  .meas-badge {
    display:inline-block; padding:2px 10px; border-radius:4px;
    font-size:10px; font-weight:700; letter-spacing:1px; text-transform:uppercase;
    background:rgba(148,163,184,0.10); color:var(--text-sec);
    border:1px solid var(--border);
  }
  .fail-badge {
    display:inline-block; padding:2px 10px; border-radius:4px;
    font-size:10px; font-weight:700; letter-spacing:1px; text-transform:uppercase;
    background:rgba(239,68,68,0.12); color:var(--error);
    border:1px solid rgba(239,68,68,0.25);
  }

  .divider { border:none; border-top:1px solid var(--border); margin:20px 0; }

  .tag { display:inline-block; padding:2px 8px; border-radius:4px;
    font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:0.8px; }
  .tag-red   { background:rgba(223,43,59,0.15); color:var(--accent); border:1px solid rgba(223,43,59,0.3); }
  .tag-green { background:rgba(0,208,132,0.12); color:var(--success); border:1px solid rgba(0,208,132,0.25); }
  .tag-gray  { background:rgba(148,163,184,0.10); color:var(--text-sec); border:1px solid var(--border); }

  .two-col { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:14px;
    page-break-inside:avoid; break-inside:avoid; }
  .note { background:rgba(245,158,11,0.07); border:1px solid rgba(245,158,11,0.3);
    border-radius:4px; padding:10px 14px; font-size:12.5px; color:var(--text-sec); margin-bottom:12px;
    page-break-inside:avoid; break-inside:avoid; }
  .note strong { color:var(--warning); }

  @media print {
    body { background:#fff; color:#000; }
    :root { --bg:#fff; --surface:#f8f8f8; --surface-alt:#f0f0f0;
      --border:#d0d0d0; --text:#000; --text-sec:#444; --text-muted:#888; }
    .cover { min-height:auto; padding:40px 0; }
    pre { background:#f0f0f0; color:#333; border-color:#ccc; }
    .formula { background:#f0f0f0; color:#006600; border-color:#ccc; }
    .test-block { background:#f8f8f8; }
    .card { background:#f8f8f8; }
  }
"""

# ── HTML ───────────────────────────────────────────────────────
_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FHEnom for AI™ — Test Suite Technical Details</title>
<style>__BASE_CSS__</style>
</head>
<body>

<!-- ── COVER ──────────────────────────────────────────────────── -->
<div class="cover">
  <div class="cover-logo">
    <svg width="36" height="36" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="32" height="32" rx="4" fill="#DF2B3B"/>
      <path d="M8 10.5C8 9.12 9.12 8 10.5 8H16C19.87 8 23 11.13 23 15V17C23 20.87 19.87 24 16 24H10.5C9.12 24 8 22.88 8 21.5V10.5Z" fill="white" fill-opacity="0.25"/>
      <path d="M11 13C11 12.45 11.45 12 12 12H15.5C17.43 12 19 13.57 19 15.5C19 17.43 17.43 19 15.5 19H12C11.45 19 11 18.55 11 18V13Z" fill="white" fill-opacity="0.9"/>
    </svg>
    <span class="cover-brand">DataKrypto — FHEnom for AI™</span>
  </div>
  <div class="cover-body">
    <div class="cover-label">Technical Reference</div>
    <h1>Test Suite<br><span>Technical Details</span></h1>
    <p class="cover-sub">
      Precise methodology, formulae, and implementation details for every test
      in the <strong>dk-test-suite</strong>. Written for client engineers who
      wish to verify the correctness of each measurement and security check.
    </p>
    <div class="cover-meta">
      <div class="cover-meta-item">
        <span class="cover-meta-label">Document</span>
        <span class="cover-meta-val">DK-POC-TECH-001</span>
      </div>
      <div class="cover-meta-item">
        <span class="cover-meta-label">Suite Version</span>
        <span class="cover-meta-val">v0.1.0</span>
      </div>
      <div class="cover-meta-item">
        <span class="cover-meta-label">Date</span>
        <span class="cover-meta-val">April 2026</span>
      </div>
      <div class="cover-meta-item">
        <span class="cover-meta-label">Source file</span>
        <span class="cover-meta-val">dk_test_suite/tests/*.py</span>
      </div>
    </div>
  </div>
  <div class="cover-footer">
    <span>DataKrypto — FHEnom for AI™ &nbsp;·&nbsp; POC Validation Framework</span>
    <span class="conf-badge">Confidential</span>
  </div>
</div>

<!-- ── TABLE OF CONTENTS ──────────────────────────────────────── -->
<div class="toc-page">
  <div class="toc-title">Contents</div>
  <div class="toc-heading">Table of Contents</div>
  <ul class="toc-list">
    <li><span class="toc-num">1</span><span class="toc-name">Complete Pipeline Flow</span><span class="toc-dots"></span><span class="toc-page-num">3</span></li>
    <li><span class="toc-num">2</span><span class="toc-name">Performance Tests — PERF-1 to PERF-5</span><span class="toc-dots"></span><span class="toc-page-num">5</span></li>
    <li><span class="toc-num">3</span><span class="toc-name">Accuracy Tests — ACC-1 to ACC-5</span><span class="toc-dots"></span><span class="toc-page-num">7</span></li>
    <li><span class="toc-num">4</span><span class="toc-name">Scalability Tests — SCALE-1 to SCALE-4</span><span class="toc-dots"></span><span class="toc-page-num">10</span></li>
    <li><span class="toc-num">5</span><span class="toc-name">Security Tests — SEC-1 to SEC-6</span><span class="toc-dots"></span><span class="toc-page-num">12</span></li>
    <li><span class="toc-num">6</span><span class="toc-name">Serving Tests — SERV-1 to SERV-7</span><span class="toc-dots"></span><span class="toc-page-num">15</span></li>
    <li><span class="toc-num">7</span><span class="toc-name">Training Tests — T-1 to T-3</span><span class="toc-dots"></span><span class="toc-page-num">19</span></li>
    <li><span class="toc-num">8</span><span class="toc-name">Mathematics Summary</span><span class="toc-dots"></span><span class="toc-page-num">20</span></li>
  </ul>
</div>

<!-- ── SECTION 1: COMPLETE PIPELINE FLOW ─────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 1</div>
  <h2>Complete Pipeline Flow</h2>
  <p class="lead">
    The following describes the exact execution order of <code>runner.py → TestRunner.run()</code>.
    Each phase is clearly demarcated in the source. Source file: <code>dk_test_suite/runner.py</code>.
  </p>

  <h3>Phase 0 — Initialisation</h3>
  <p>The runner opens two SSH connections (GPU and TEE), loads the YAML configuration,
  and creates the output directory.</p>

  <h3>Phase 1 — Prompt Generation</h3>
  <p>A deterministic set of benchmark prompts is generated once and reused across all
  test categories. The seed is fixed (default: 42) to ensure reproducibility across runs.</p>
  <pre>prompts = generate_prompt_set(n=cfg["num_prompts"], seed=cfg["seed"])</pre>

  <h3>Phase 2 (conditional) — Start Clear vLLM</h3>
  <p>If <code>--skip-clear-vllm</code> is NOT set, the runner starts a Docker container named
  <code>dk_vllm_bench</code> on the GPU, mounting the clear model weights. It polls
  <code>/health</code> until the server is ready.</p>

  <h3>Phase 3 (conditional) — Clear model inference</h3>
  <p>All test suites that need clear-model data run sequentially against the single
  vLLM instance on port 8000:</p>
  <ul>
    <li><code>performance.run_clear()</code> — streaming inference for PERF metrics</li>
    <li><code>accuracy.run_clear()</code> — non-streaming inference + lm-eval-harness</li>
    <li><code>scalability.run_clear()</code> — concurrent, context-length, batch, sustained tests</li>
    <li><code>serving.run_clear()</code> — 3 probe prompts collected for SERV-6 fidelity comparison</li>
  </ul>

  <h3>Phase 4 (conditional) — Stop Clear vLLM / Start Encrypted vLLM</h3>
  <p>The clear vLLM container is stopped. The encrypted model container is started with
  the FHE-encrypted weights. The runner waits for <code>/health</code>.</p>

  <h3>Phase 5 (conditional) — TEE model registration</h3>
  <p>If the encrypted model is not already registered with the TEE, the runner calls:</p>
  <pre>POST https://TEE:9099/api/v1/models
Body: { "model_id": "&lt;uuid&gt;", "name": "...", "vllm_url": "http://GPU:8000" }
Headers: X-Auth-Token: &lt;admin_token&gt;</pre>
  <p>The runner then calls <code>fhenomai serve start</code> on the TEE via SSH,
  and polls the TEE completions endpoint every 10 s (up to 150 s) until the TEE
  returns a non-error response — confirming the FHE pipeline has fully initialised.</p>

  <h3>Phase 6 — Encrypted model inference</h3>
  <ul>
    <li><code>performance.run_encrypted()</code> — streaming inference against TEE</li>
    <li><code>accuracy.run_encrypted()</code> — non-streaming inference + lm-eval against TEE</li>
    <li><code>scalability.run_encrypted()</code> — concurrent/batch/context tests against TEE</li>
  </ul>

  <h3>Phase 7 — Security tests</h3>
  <p>All SEC-1 to SEC-6 tests run. These tests do NOT require separate clear/encrypted
  inference — they inspect the already-running encrypted deployment.</p>

  <h3>Phase 8 — Serving tests (encrypted side only)</h3>
  <p>The serving test suite runs only against the encrypted deployment at this point.
  Clear-model reference probes were already collected in Phase 3.</p>
  <ol>
    <li><code>serv.run_encrypted()</code> — SERV-1 to SERV-5 against the encrypted deployment + TEE</li>
    <li><code>serv.compare()</code> — SERV-6 and SERV-7 compare encrypted outputs vs Phase 3 clear outputs</li>
  </ol>

  <h3>Phase 9 — Training tests (optional)</h3>
  <p>Training tests launch a LoRA fine-tuning job on the GPU with both clear and
  encrypted model backends and compare convergence curves.</p>

  <h3>Phase 10 — Compare + Report</h3>
  <p>All test suites call their <code>compare()</code> method, which computes the
  final diff values and determines PASS/FAIL. The HTML report and JSON results file
  are written to the output directory.</p>

  <h3>Execution diagram</h3>
  <pre>
┌── runner.run() ──────────────────────────────────────────────────────────┐
│                                                                          │
│  init SSH ──► generate prompts                                           │
│                    │                                                     │
│                    ▼                                                     │
│  [optional] start_clear_vllm ──► wait_health                            │
│                    │                                                     │
│                    ├──► perf.run_clear()   ──────┐                      │
│                    ├──► acc.run_clear()    ──────┤  (clear model)       │
│                    └──► scale.run_clear()  ──────┘                      │
│                                                                          │
│  [optional] stop_clear ──► start_enc_vllm ──► wait_health               │
│  [optional] tee.register_model() ──► tee.start_serving()                │
│             wait_tee_ready()                                             │
│                    │                                                     │
│                    ├──► perf.run_encrypted()  ───┐                      │
│                    ├──► acc.run_encrypted()   ───┤  (encrypted via TEE) │
│                    └──► scale.run_encrypted() ───┘                      │
│                                                                          │
│  security.run_all()  (inspects live encrypted deployment)               │
│  serving.run_all()   (3-way probe: TEE + clear + bypass)                │
│  [optional] training.run_all()                                          │
│                                                                          │
│  compare_all() ──► generate_report() ──► results/poc_report_*.html     │
└──────────────────────────────────────────────────────────────────────────┘</pre>
</div>

<!-- ── SECTION 2: PERFORMANCE TESTS ──────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 2</div>
  <h2>Performance Tests — PERF-1 to PERF-5</h2>
  <p class="lead">
    Source: <code>dk_test_suite/tests/performance.py</code><br>
    Purpose: Measure the computational overhead introduced by FHE encryption.
    All PERF tests are <span class="meas-badge">Measurement Only</span> — they always PASS.
    The difference column uses the signed convention described in Section 8.
  </p>

  <h3>Data collection</h3>
  <p>The runner sends <code>num_prompts</code> (default: 100) deterministic prompts to both
  models using streaming inference (<code>VLLMManager.completions_streaming()</code> and
  <code>TEEManager.completions_streaming()</code>). For each response, the following
  timing values are recorded in a <code>InferenceResult</code> object:</p>
  <ul>
    <li><strong>ttft_ms</strong> — Time-to-First-Token: elapsed time from request send to receipt of
        the first token chunk, measured with <code>time.perf_counter()</code>.</li>
    <li><strong>total_time_ms</strong> — End-to-end response time: elapsed time from request send
        to receipt of the final token.</li>
    <li><strong>output_tokens</strong> — number of tokens in the response (from the usage field).</li>
    <li><strong>tokens_per_sec</strong> — computed as <code>output_tokens / (total_time_ms / 1000)</code>.</li>
  </ul>
  <p>Averages are computed over all successful prompts:</p>
  <div class="formula-label">BenchmarkMetrics aggregation (metrics.py)</div>
  <div class="formula">avg_ttft_ms        = mean(r.ttft_ms for r in results)
avg_total_time_ms  = mean(r.total_time_ms for r in results)
avg_tokens_per_sec = mean(r.tokens_per_sec for r in results)</div>

  <!-- PERF-1 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id">PERF-1</span>
      <span class="test-name">Latency per Token (TTFT)</span>
      <span class="test-source">performance.py → compare()</span>
    </div>
    <div class="field-row">
      <div class="field"><span class="field-label">Metric</span><span class="field-val">Average Time-to-First-Token (ms)</span></div>
      <div class="field"><span class="field-label">Pass condition</span><span class="field-val">Always PASS (measurement)</span></div>
    </div>
    <div class="formula-label">Formula (latency: lower is better)</div>
    <div class="formula">diff_pct = (clear_ttft - enc_ttft) / clear_ttft × 100

Where:
  clear_ttft = avg_ttft_ms  measured on clear vLLM (port 8000, Phase 1)
  enc_ttft   = avg_ttft_ms  measured through TEE → vLLM:8000 (Phase 2)

diff_pct > 0  ⟹  encrypted is faster (lower TTFT)
diff_pct < 0  ⟹  encrypted is slower (higher TTFT)</div>
  </div>

  <!-- PERF-2 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id">PERF-2</span>
      <span class="test-name">Throughput (Tokens/sec)</span>
      <span class="test-source">performance.py → compare()</span>
    </div>
    <div class="formula-label">Formula (throughput: higher is better)</div>
    <div class="formula">tp_diff = (enc_tp - clear_tp) / clear_tp × 100

Where:
  clear_tp = avg_tokens_per_sec  for clear model
  enc_tp   = avg_tokens_per_sec  through TEE

tp_diff > 0  ⟹  encrypted achieves higher throughput
tp_diff < 0  ⟹  encrypted achieves lower throughput</div>
  </div>

  <!-- PERF-3 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id">PERF-3</span>
      <span class="test-name">End-to-End Response Time</span>
      <span class="test-source">performance.py → compare()</span>
    </div>
    <div class="formula-label">Formula (latency: lower is better)</div>
    <div class="formula">e2e_diff = (clear_e2e - enc_e2e) / clear_e2e × 100

Where:
  clear_e2e = avg_total_time_ms  for clear model
  enc_e2e   = avg_total_time_ms  through TEE</div>
  </div>

  <!-- PERF-4 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id">PERF-4</span>
      <span class="test-name">Model Footprint</span>
      <span class="test-source">performance.py → compare()</span>
    </div>
    <div class="formula-label">Formula</div>
    <div class="formula">footprint_ratio = enc_model_size_bytes / clear_model_size_bytes

Measured via SSH: du -sb &lt;model_path&gt;</div>
    <p>A ratio &gt; 1.0 means the encrypted model is larger on disk.
    Typical values: 1.0–1.2× depending on the FHEnom format.</p>
  </div>

  <!-- PERF-5 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id">PERF-5</span>
      <span class="test-name">GPU Memory Utilization</span>
      <span class="test-source">performance.py → compare()</span>
    </div>
    <p>VRAM usage is sampled via <code>nvidia-smi --query-compute-apps=pid,used_memory</code>
    immediately before the inference run on each model. The difference is reported in MB.</p>
    <div class="formula-label">Formula</div>
    <div class="formula">vram_diff_mb = enc_vram_used_mb - clear_vram_used_mb</div>
  </div>
</div>

<!-- ── SECTION 3: ACCURACY TESTS ──────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 3</div>
  <h2>Accuracy Tests — ACC-1 to ACC-5</h2>
  <p class="lead">
    Source: <code>dk_test_suite/tests/accuracy.py</code><br>
    Purpose: Validate that FHEnom encryption does not degrade model output quality.
    All ACC tests are <span class="meas-badge">Measurement Only</span>.
    200 prompts are used (constant, independent of <code>num_prompts</code>).
  </p>

  <!-- ACC-1 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">ACC-1</span>
      <span class="test-name">Deterministic Equivalence (FP32)</span>
      <span class="test-source">accuracy.py → compare()</span>
    </div>
    <div class="field-row">
      <div class="field"><span class="field-label">Inference mode</span><span class="field-val">temperature = 0 (greedy)</span></div>
      <div class="field"><span class="field-label">Comparison</span><span class="field-val">Exact string match</span></div>
    </div>
    <div class="formula-label">Formula</div>
    <div class="formula">exact_match_rate = |{i : output_clear[i] == output_enc[i]}| / N × 100%

Where N = min(len(clear_outputs), len(enc_outputs))</div>
    <p>Two outputs are considered identical if and only if the complete token sequence
    (decoded to a string) is character-for-character equal. A rate of 100% at
    temperature=0 would indicate bit-exact equivalence.</p>
  </div>

  <!-- ACC-2 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">ACC-2</span>
      <span class="test-name">Functional Equivalence (FP16/BF16) via lm-eval-harness</span>
      <span class="test-source">accuracy.py → _run_lm_eval(), _compare_lm_eval()</span>
    </div>
    <p>lm-evaluation-harness is run against <em>both</em> the clear vLLM endpoint
    (port 8000, Phase 1) and the TEE endpoint (port 9999, Phase 2) using the
    <code>local-completions</code> backend.</p>
    <pre>lm_eval --model local-completions \\
  --model_args "model=&lt;name&gt;,base_url=&lt;url&gt;/v1/completions,num_concurrent=4" \\
  --tasks hellaswag,arc_easy \\
  --batch_size auto</pre>
    <div class="formula-label">Score difference (per task/metric)</div>
    <div class="formula">diff = enc_score - clear_score

diff > 0  ⟹  encrypted model scores higher (better)
diff < 0  ⟹  encrypted model scores lower</div>
    <p>Tolerance threshold: ±<code>accuracy.fp16_rounding_tolerance</code> (default: 0.01).
    Scores within ±1% are considered functionally equivalent.</p>
  </div>

  <!-- ACC-3 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">ACC-3</span>
      <span class="test-name">Semantic Consistency (BERTScore F1)</span>
      <span class="test-source">accuracy.py → _compute_bertscore()</span>
    </div>
    <p>BERTScore measures semantic similarity using contextualised BERT embeddings.
    The clear outputs are used as references; encrypted outputs as candidates.</p>
    <div class="formula-label">BERTScore precision, recall, F1</div>
    <div class="formula">For each token t in candidate C, reference R:

P = (1/|C|) Σ_{t∈C} max_{r∈R} cosine_sim(embed(t), embed(r))
R = (1/|R|) Σ_{r∈R} max_{t∈C} cosine_sim(embed(t), embed(r))
F1 = 2PR / (P + R)

Reported: avg F1 over all prompt pairs</div>
    <p>If the <code>bert_score</code> package is not installed, the suite falls back to
    a character-overlap F1:</p>
    <div class="formula">char_P = |chars(cand) ∩ chars(ref)| / |chars(cand)|
char_R = |chars(cand) ∩ chars(ref)| / |chars(ref)|
char_F1 = 2 × char_P × char_R / (char_P + char_R)</div>
  </div>

  <!-- ACC-4 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">ACC-4</span>
      <span class="test-name">Response Length Consistency (Welch's t-test)</span>
      <span class="test-source">accuracy.py → compare()</span>
    </div>
    <p>Two-sample Welch's t-test comparing the character-length distributions of
    clear vs. encrypted responses (via <code>scipy.stats.ttest_ind</code>).</p>
    <div class="formula-label">Welch's t-statistic</div>
    <div class="formula">t = (x̄₁ - x̄₂) / sqrt(s₁²/n₁ + s₂²/n₂)

Where:
  x̄₁, s₁², n₁ = mean, variance, count of clear response lengths
  x̄₂, s₂², n₂ = mean, variance, count of encrypted response lengths

Reported: t-statistic and two-tailed p-value
p > 0.05  ⟹  no statistically significant length difference</div>
  </div>

  <!-- ACC-5 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">ACC-5</span>
      <span class="test-name">Perplexity / Log-Likelihood</span>
      <span class="test-source">accuracy.py → _compute_perplexity()</span>
    </div>
    <div class="formula-label">Perplexity from logprobs</div>
    <div class="formula">For each response with log-probability sequence {lp₁, lp₂, …, lpₙ}:

  ppl(response) = exp(-1/n × Σᵢ lpᵢ)

avg_perplexity = mean(ppl(r) for r in outputs
                       where r.logprobs is not None)

ppl_diff_pct = (clear_ppl - enc_ppl) / clear_ppl × 100

ppl_diff_pct > 0  ⟹  encrypted model has lower (better) perplexity
ppl_diff_pct < 0  ⟹  encrypted model has higher (worse) perplexity</div>
    <div class="note">
      <strong>Known limitation:</strong> The FHEnom TEE does not support the
      <code>logprobs</code> field in its completion API. When <code>enc_ppl == 0</code>
      and encrypted outputs are present, the test reports this as a known limitation
      and still marks the test as PASS (measurement only).
    </div>
  </div>
</div>

<!-- ── SECTION 4: SCALABILITY TESTS ──────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 4</div>
  <h2>Scalability Tests — SCALE-1 to SCALE-4</h2>
  <p class="lead">
    Source: <code>dk_test_suite/tests/scalability.py</code><br>
    Purpose: Assess whether FHE encryption introduces constraints on scaling behaviour.
    All SCALE tests are <span class="meas-badge">Measurement Only</span>.
    Diff convention matches PERF: <strong>+ = encrypted is better</strong>.
  </p>
  <p>Scale parameters are read from the <code>scalability</code> block in the config:
  <code>concurrent_levels</code>, <code>context_lengths</code>, <code>batch_sizes</code>,
  <code>sustained_abbreviated_minutes</code>.</p>

  <!-- SCALE-1 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id scale">SCALE-1</span>
      <span class="test-name">Concurrent User Load</span>
      <span class="test-source">scalability.py → _concurrent_test()</span>
    </div>
    <p>For each concurrency level <em>n</em> in <code>concurrent_levels</code>, the runner sends
    <em>n</em> requests simultaneously using a <code>ThreadPoolExecutor</code>:</p>
    <pre>with ThreadPoolExecutor(max_workers=n_concurrent) as ex:
    futures = [ex.submit(inference_fn, prompt, max_tokens) for _ in range(n)]
    results = [f.result() for f in as_completed(futures)]</pre>
    <div class="formula-label">Metrics per concurrency level</div>
    <div class="formula">total_tokens = Σ output_tokens across all requests
wall_time_s  = max_total_time_ms / 1000   (slowest request)
throughput   = total_tokens / wall_time_s  (tokens/sec aggregate)
avg_latency  = mean(total_time_ms for r in results)

diff = (enc_tp - clear_tp) / clear_tp × 100  [throughput: higher=better]</div>
  </div>

  <!-- SCALE-2 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id scale">SCALE-2</span>
      <span class="test-name">Context Length Scaling</span>
      <span class="test-source">scalability.py → _context_length_test()</span>
    </div>
    <p>For each <code>ctx_len</code> in <code>context_lengths</code>, a prompt of approximately
    that many tokens is generated and sent as a single request. The inference function
    receives <code>max_tokens=128</code>.</p>
    <div class="formula-label">Latency diff (lower is better)</div>
    <div class="formula">diff = (clear_lat - enc_lat) / clear_lat × 100

diff > 0  ⟹  encrypted is faster at this context length</div>
  </div>

  <!-- SCALE-3 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id scale">SCALE-3</span>
      <span class="test-name">Batch Processing</span>
      <span class="test-source">scalability.py → _batch_test()</span>
    </div>
    <p>For each <code>batch_size</code>, sends that many requests to the endpoint in a single
    batch (using vLLM's native batching if supported, otherwise concurrent dispatch).</p>
    <div class="formula-label">Throughput diff (higher is better)</div>
    <div class="formula">diff = (enc_tp - clear_tp) / clear_tp × 100</div>
  </div>

  <!-- SCALE-4 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id scale">SCALE-4</span>
      <span class="test-name">Sustained Operation</span>
      <span class="test-source">scalability.py → _sustained_test()</span>
    </div>
    <p>Runs continuous inference for <code>sustained_abbreviated_minutes</code> (default: 3 min
    in the standard run; 24 h for the full endurance test).</p>
    <div class="formula-label">Degradation metric</div>
    <div class="formula">throughput_window_i = tokens produced in window i / window_duration_s
degradation_pct = (tp_window_0 - tp_window_last) / tp_window_0 × 100</div>
    <p>A degradation near 0% means throughput is stable over time. Positive degradation
    indicates the server is slowing down (e.g. memory pressure, GC pauses).</p>
  </div>
</div>

<!-- ── SECTION 5: SECURITY TESTS ─────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 5</div>
  <h2>Security Tests — SEC-1 to SEC-6</h2>
  <p class="lead">
    Source: <code>dk_test_suite/tests/security.py</code><br>
    These tests are <span class="fail-badge">Pass / Fail</span> — not measurement-only.
    They run entirely against the encrypted deployment. No clear model involvement.
  </p>

  <!-- SEC-1 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id sec">SEC-1</span>
      <span class="test-name">Encryption at Rest</span>
      <span class="test-source">security.py → _test_sec1_encryption_at_rest()</span>
    </div>
    <p><strong>What is tested:</strong> The safetensors weight files in <code>model_path_encrypted</code>
    must not contain plaintext PyTorch floats or named weight tensors in their <em>data section</em>
    (the bytes past the JSON header).</p>

    <h4>Step 1 — skip the safetensors header</h4>
    <p>The safetensors format stores a variable-length JSON header at the start of the file.
    The first 8 bytes are a little-endian <code>uint64</code> that encodes the header length.
    All pattern matching and entropy is computed on bytes <em>after</em> this header only,
    so that legitimate tensor names in the header do not trigger false positives.</p>
    <pre>header_offset = struct.unpack('&lt;Q', first_8_bytes)[0]   # header length
data_start = header_offset + 8                              # +8 for the length itself</pre>

    <h4>Step 2 — plaintext pattern scan</h4>
    <p>Six regex patterns are searched in the data section. A hit means plaintext model
    data is present (FAIL):</p>
    <table>
      <thead><tr><th>Pattern</th><th>Indicates</th></tr></thead>
      <tbody>
        <tr><td>torch.FloatTensor</td><td>Unencrypted PyTorch tensor type string</td></tr>
        <tr><td>weight.*[</td><td>Named weight array in plaintext</td></tr>
        <tr><td>model.layers.</td><td>Transformer layer identifier in plaintext</td></tr>
        <tr><td>lm_head.weight</td><td>Language model head weight in plaintext</td></tr>
        <tr><td>embed_tokens</td><td>Token embedding table in plaintext</td></tr>
        <tr><td>self_attn</td><td>Attention weight name in plaintext</td></tr>
      </tbody>
    </table>

    <h4>Step 3 — Shannon entropy</h4>
    <div class="formula-label">Shannon entropy on first 1 MiB of data section</div>
    <div class="formula">H = -Σ_{b=0..255} (count[b]/N) × log₂(count[b]/N)

Where N = total bytes sampled (= 1 048 576)

H ≥ 7.5  ⟹  high entropy (expected for encrypted/compressed data)
H &lt; 7.5  ⟹  WARNING: low entropy (data may not be fully encrypted)</pre></div>
    <p>Random ciphertext should approach H = 8.0. AES-CTR mode with random keys
    typically yields H ≈ 7.95 – 7.99 per byte.</p>
  </div>

  <!-- SEC-2 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id sec">SEC-2</span>
      <span class="test-name">Encrypted Execution (Runtime Memory Scan)</span>
      <span class="test-source">security.py → _test_sec2_encrypted_execution()</span>
    </div>
    <p><strong>What is tested:</strong> The vLLM container process must not have
    plaintext model weight identifiers mapped in its address space during inference.</p>

    <h4>Step 1 — find the container PID</h4>
    <p>The runner tries container names in order:
    <code>vllm_enc_container</code> (from config, default <code>vllm_enc_server</code>),
    then <code>vllm_enc_server</code>, then <code>dk_vllm_bench</code>.</p>
    <pre>docker inspect --format '{{.State.Pid}}' &lt;container&gt;</pre>

    <h4>Step 2 — scan /proc/&lt;PID&gt;/maps</h4>
    <p>The Linux kernel memory map file lists all mapped regions of the process.
    The first 3 plaintext patterns from SEC-1 are searched here. A count &gt; 0 means
    the model string appeared in a mapped region (WARN).</p>
    <pre>grep -c '&lt;pattern&gt;' /proc/&lt;pid&gt;/maps</pre>

    <h4>Step 3 — GPU compute processes</h4>
    <p>Verifies that the container PID is actively using the GPU by checking
    <code>nvidia-smi --query-compute-apps=pid,used_memory</code>.</p>
  </div>

  <!-- SEC-3 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id sec">SEC-3</span>
      <span class="test-name">Secure Transport</span>
      <span class="test-source">security.py → _test_sec3_secure_transport()</span>
    </div>
    <p>Verifies that the TEE user endpoint (port 9999) is served over TLS:</p>
    <ul>
      <li>Sends an HTTP (plain) request to port 9999 — expects connection refused or redirect.</li>
      <li>Sends an HTTPS request to port 9999 — expects a valid TLS handshake.</li>
      <li>Uses <code>ssl.get_server_certificate()</code> to verify a certificate is presented.</li>
      <li>Checks for <code>Content-Type: application/json</code> in the HTTPS response.</li>
    </ul>
    <p>PASS requires: HTTPS succeeds with a valid certificate and the TEE responds
    to the completions endpoint with a JSON body.</p>
  </div>

  <!-- SEC-4 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id sec">SEC-4</span>
      <span class="test-name">Model Binding</span>
      <span class="test-source">security.py → _test_sec4_model_binding()</span>
    </div>
    <p>Verifies that the TEE refuses to serve a request for a model UUID that
    has not been registered.</p>
    <ul>
      <li>Generates a random fake UUID.</li>
      <li>Sends a completions request to the TEE with the fake model ID.</li>
      <li>PASS: TEE returns a 4xx error or the response text indicates "unknown model".</li>
    </ul>
    <p>Additionally checks that <code>encrypted_model_id</code> is accepted and returns
    a coherent response.</p>
  </div>

  <!-- SEC-5 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id sec">SEC-5</span>
      <span class="test-name">Key Isolation</span>
      <span class="test-source">security.py → _test_sec5_key_isolation()</span>
    </div>
    <p>Checks that FHE key material is not exposed on the GPU filesystem or in
    environment variables:</p>
    <ul>
      <li>Searches <code>/tmp</code>, <code>/home</code>, <code>/root</code> for files named
          <code>*.key</code>, <code>*.pem</code>, or <code>secret*</code>.</li>
      <li>Checks <code>env</code> output on the GPU for variables containing
          <code>key</code>, <code>secret</code>, or <code>token</code> (excluding
          SSH_AUTH_SOCK and PATH).</li>
      <li>Inspects <code>docker inspect &lt;container&gt;</code> output for JSON fields
          containing <code>key</code> or <code>secret</code>.</li>
    </ul>
    <p>PASS: No key material found outside the TEE's protected memory.</p>
  </div>

  <!-- SEC-6 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id sec">SEC-6</span>
      <span class="test-name">Logging Safety</span>
      <span class="test-source">security.py → _test_sec6_logging_safety()</span>
    </div>
    <p>Verifies that container logs and system journals do not contain plaintext
    model weights or decrypted intermediates:</p>
    <ul>
      <li>Fetches the last 500 lines of the vLLM container log:
          <code>docker logs &lt;container&gt; --tail 500</code>.</li>
      <li>Searches logs for the strings: <code>plaintext</code>, <code>decrypted</code>,
          <code>weight.*tensor</code>.</li>
      <li>Checks <code>journalctl -n 200</code> with the same patterns.</li>
    </ul>
    <p>PASS: None of the patterns found in logs.</p>
  </div>
</div>

<!-- ── SECTION 6: SERVING TESTS ──────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 6</div>
  <h2>Serving Tests — SERV-1 to SERV-7</h2>
  <p class="lead">
    Source: <code>dk_test_suite/tests/serving.py</code><br>
    These tests validate the end-to-end FHE-encrypted serving pipeline.
    SERV-1 to SERV-5 are <span class="pass-badge">Pass / Fail</span>.
    SERV-6 and SERV-7 are <span class="pass-badge">Pass / Fail</span> with thresholds.
  </p>

  <h3>Probe prompts</h3>
  <p>All SERV tests use the same three deterministic probe prompts (hard-coded in
  <code>_PROBE_PROMPTS</code>):</p>
  <table>
    <thead><tr><th>ID</th><th>Prompt</th><th>max_tokens</th></tr></thead>
    <tbody>
      <tr><td>geo</td><td>"The capital of France is"</td><td>40</td></tr>
      <tr><td>sci</td><td>"The boiling point of water is"</td><td>40</td></tr>
      <tr><td>prog</td><td>"Python is a programming language that"</td><td>40</td></tr>
    </tbody>
  </table>

  <!-- SERV-1 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id serv">SERV-1</span>
      <span class="test-name">Encrypted Model File Integrity</span>
      <span class="test-source">serving.py → _test_serv1_file_integrity()</span>
    </div>
    <p>Checks on the GPU via SSH:</p>
    <ul>
      <li>Directory <code>model_path_encrypted</code> exists.</li>
      <li>At least one <code>.safetensors</code> file is present.</li>
      <li>All required files exist: <code>config.json</code>, <code>tokenizer.json</code>,
          <code>tokenizer_config.json</code>, <code>special_tokens_map.json</code>.</li>
      <li>Total model size ≥ 2 GB (sanity check for a 1B-parameter model).</li>
    </ul>
    <p>PASS: All checks pass.</p>
  </div>

  <!-- SERV-2 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id serv">SERV-2</span>
      <span class="test-name">vLLM Server Health</span>
      <span class="test-source">serving.py → _test_serv2_server_health()</span>
    </div>
    <p>Queries <code>http://GPU:8000/health</code> via SSH curl from the GPU (to avoid firewall).
    PASS: HTTP 200 response received within 5 seconds.</p>
    <pre>curl -s --max-time 5 http://localhost:8000/health</pre>
  </div>

  <!-- SERV-3 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id serv">SERV-3</span>
      <span class="test-name">TEE Serving Status</span>
      <span class="test-source">serving.py → _test_serv3_tee_serving_status()</span>
    </div>
    <p>Queries the TEE admin API for the model list:</p>
    <pre>GET https://TEE:9099/api/v1/models
Headers: X-Auth-Token: &lt;admin_token&gt;</pre>
    <p>PASS: The response contains a model entry matching <code>encrypted_model_id</code>
    with <code>status == "ONLINE"</code>.</p>
  </div>

  <!-- SERV-4 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id serv">SERV-4</span>
      <span class="test-name">TEE Inference Coherence</span>
      <span class="test-source">serving.py → _test_serv4_tee_coherence()</span>
    </div>
    <p>Sends each probe prompt through the TEE and checks that the response is
    coherent English (not garbled base64/binary).</p>
    <div class="formula-label">Coherence metric</div>
    <div class="formula">space_ratio = count(' ', text) / len(text)

Coherent text (English):  space_ratio ≥ 0.08  (≥ 1 space per 12.5 chars)
Garbled ciphertext:        space_ratio ≤ 0.04  (essentially no spaces)

Threshold: _COHERENT_SPACE_RATIO = 0.08</div>
    <p>PASS: space_ratio ≥ 0.08 for all probes through the TEE path.</p>
    <p>The clear-model reference outputs (collected in Phase 1 while the clear model
    ran on port 8000) are also scored to confirm they are coherent. If both
    meet the threshold, SERV-4 confirms the TEE is correctly routing and
    decrypting inference through the FHE pipeline.</p>
  </div>

  <!-- SERV-5 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id serv">SERV-5</span>
      <span class="test-name">Encryption Reality Proof (Bypass Test)</span>
      <span class="test-source">serving.py → _test_serv5_encryption_proof()</span>
    </div>
    <p>This is the cryptographic proof that the encryption is genuine. Each probe
    prompt is sent <em>directly</em> to the encrypted vLLM (port 8000, without going
    through the TEE decryption proxy):</p>
    <pre>POST http://GPU:8000/v1/completions   ← bypasses TEE entirely</pre>
    <div class="formula-label">Proof logic</div>
    <div class="formula">bypass_ratio = space_ratio(text from vLLM:8000 direct)
tee_ratio    = space_ratio(text from TEE:9999)

PASS condition for each probe:
  bypass_ratio ≤ _GARBLED_SPACE_RATIO  (= 0.04)
  AND
  tee_ratio    ≥ _COHERENT_SPACE_RATIO (= 0.08)

This proves:
  1. The weights ARE encrypted (bypass = garbled)
  2. The TEE DOES decrypt correctly (TEE path = coherent)</div>
    <p>A bypass space_ratio above 0.04 would indicate the model weights are NOT
    properly encrypted — a critical security failure.</p>
  </div>

  <!-- SERV-6 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id serv">SERV-6</span>
      <span class="test-name">TEE vs Clear Model Output Fidelity</span>
      <span class="test-source">serving.py → _test_serv6_output_fidelity()</span>
    </div>
    <p>Compares the TEE outputs against the clear model outputs for each probe prompt
    using Python's standard library <code>difflib.SequenceMatcher</code>.</p>
    <div class="formula-label">Similarity metric</div>
    <div class="formula">ratio = SequenceMatcher(None, tee_text.lower(), clear_text.lower()).ratio()

SequenceMatcher ratio is defined as:
  ratio = 2 × M / T
Where:
  M = number of matching characters
  T = total characters in both strings

Threshold: _FIDELITY_RATIO = 0.70

PASS: ratio ≥ 0.70 for all probes where both outputs are available
FAIL: ratio &lt; 0.70 for any probe, OR all probes skipped (no data)</div>
    <p>Additionally, the first divergence character index is reported for debugging:</p>
    <pre>first_diff = next(i for i in range(min(len(a), len(b))) if a[i] != b[i])</pre>
  </div>

  <!-- SERV-7 -->
  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id serv">SERV-7</span>
      <span class="test-name">FHE Overhead Measurement</span>
      <span class="test-source">serving.py → _test_serv7_fhe_overhead()</span>
    </div>
    <p>Measures the time added by FHE encryption/decryption operations within the TEE,
    separate from the neural network inference time.</p>
    <p>The TEE includes a <code>fhenom_usage</code> field in every response body:</p>
    <pre>{
  "choices": [...],
  "fhenom_usage": {
    "enc_ms": 0.50,    // time to encrypt the request inputs
    "dec_ms": 0.19     // time to decrypt the model outputs
  }
}</pre>
    <div class="formula-label">Aggregation and PASS condition</div>
    <div class="formula">avg_enc_ms = mean(fhenom_usage.enc_ms for each probe response)
avg_dec_ms = mean(fhenom_usage.dec_ms for each probe response)

PASS: avg_enc_ms &lt; fhe_enc_overhead_threshold_ms  (default: 10 ms)
  AND avg_dec_ms &lt; fhe_dec_overhead_threshold_ms  (default:  5 ms)

FAIL: If fhenom_usage is absent from all responses
      (older TEE version that does not expose timing metadata)</div>
    <p>These thresholds are intentionally generous (10 ms / 5 ms) because the
    FHE overhead is negligible compared to the neural network inference latency
    (typically 500 ms – 5000 ms).</p>
  </div>
</div>

<!-- ── SECTION 7: TRAINING TESTS ─────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 7</div>
  <h2>Training Tests — T-1 to T-3</h2>
  <p class="lead">
    Source: <code>dk_test_suite/tests/training.py</code><br>
    Purpose: Validate that fine-tuning (LoRA / MoE adapters) on an FHE-encrypted
    model produces the same convergence behaviour as on the clear model.
    Training tests are <span class="meas-badge">Measurement Only</span>.
  </p>

  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">T-1</span>
      <span class="test-name">Convergence Equivalence</span>
    </div>
    <p>Runs a short LoRA fine-tuning job (identical hyperparameters) on both the
    clear and encrypted models. Records training loss at each step.
    Reports the area between the two loss curves as the divergence metric.</p>
    <div class="formula-label">Loss curve divergence</div>
    <div class="formula">divergence = (1/N) × Σᵢ |loss_clear(step_i) - loss_enc(step_i)|</div>
  </div>

  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">T-2</span>
      <span class="test-name">Gradient Consistency</span>
    </div>
    <p>Checks that the gradient norms at each training step are within tolerance
    of each other. A large gradient norm divergence would indicate the FHE
    approximation is affecting backpropagation.</p>
    <div class="formula-label">Gradient norm difference</div>
    <div class="formula">grad_diff_pct = (clear_grad_norm - enc_grad_norm) / clear_grad_norm × 100</div>
  </div>

  <div class="test-block">
    <div class="test-block-header">
      <span class="test-id acc">T-3</span>
      <span class="test-name">LoRA / MoE Adapter Equivalence</span>
    </div>
    <p>After training, loads the LoRA adapter weights from both runs and compares
    them element-wise. Reports the mean absolute error and cosine similarity
    between corresponding adapter tensors.</p>
    <div class="formula-label">Adapter weight comparison</div>
    <div class="formula">MAE = (1/|W|) × Σ |W_clear - W_enc|
cosine_sim = (W_clear · W_enc) / (|W_clear| × |W_enc|)</div>
  </div>
</div>

<!-- ── SECTION 8: MATHEMATICS SUMMARY ────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 8</div>
  <h2>Mathematics Summary</h2>
  <p class="lead">
    Complete list of all formulae used in the test suite, with the signed
    convention that governs the <em>Difference</em> column in every report.
  </p>

  <h3>Signed Difference Convention</h3>
  <div class="card card-accent">
    <strong>Interpretation:</strong><br>
    <strong>+ (positive diff)</strong> = FHE-encrypted model is <em>better</em> than the clear model on this metric<br>
    <strong>− (negative diff)</strong> = FHE-encrypted model is <em>worse</em> (slower, higher error, etc.)
  </div>

  <h3>All formulae</h3>
  <table>
    <thead>
      <tr>
        <th>Test</th>
        <th>Metric type</th>
        <th>Formula</th>
        <th>Unit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>PERF-1, PERF-3, SCALE-2</td>
        <td>Latency (lower=better)</td>
        <td><code>(clear − enc) / clear × 100</code></td>
        <td>%</td>
      </tr>
      <tr>
        <td>PERF-2, SCALE-1, SCALE-3</td>
        <td>Throughput (higher=better)</td>
        <td><code>(enc − clear) / clear × 100</code></td>
        <td>%</td>
      </tr>
      <tr>
        <td>PERF-4</td>
        <td>File size ratio</td>
        <td><code>enc_size / clear_size</code></td>
        <td>ratio (×)</td>
      </tr>
      <tr>
        <td>PERF-5</td>
        <td>VRAM delta</td>
        <td><code>enc_vram − clear_vram</code></td>
        <td>MB</td>
      </tr>
      <tr>
        <td>ACC-1</td>
        <td>Exact match rate</td>
        <td><code>|{i: out_c[i]==out_e[i]}| / N × 100</code></td>
        <td>%</td>
      </tr>
      <tr>
        <td>ACC-2</td>
        <td>lm-eval score (higher=better)</td>
        <td><code>enc_score − clear_score</code></td>
        <td>abs. diff</td>
      </tr>
      <tr>
        <td>ACC-3</td>
        <td>BERTScore F1</td>
        <td><code>2PR / (P + R)</code> over BERT embeddings</td>
        <td>0–1</td>
      </tr>
      <tr>
        <td>ACC-4</td>
        <td>Response length (Welch t-test)</td>
        <td><code>(x̄₁ − x̄₂) / √(s₁²/n₁ + s₂²/n₂)</code></td>
        <td>t, p-value</td>
      </tr>
      <tr>
        <td>ACC-5</td>
        <td>Perplexity (lower=better)</td>
        <td><code>(clear_ppl − enc_ppl) / clear_ppl × 100</code></td>
        <td>%</td>
      </tr>
      <tr>
        <td>SCALE-4</td>
        <td>Throughput degradation</td>
        <td><code>(tp₀ − tpₙ) / tp₀ × 100</code></td>
        <td>%</td>
      </tr>
      <tr>
        <td>SEC-1</td>
        <td>Shannon entropy</td>
        <td><code>H = −Σ p(b) log₂ p(b)</code>, b = byte value</td>
        <td>bits/byte (0–8)</td>
      </tr>
      <tr>
        <td>SERV-4, SERV-5</td>
        <td>Coherence (space ratio)</td>
        <td><code>count(' ', text) / len(text)</code></td>
        <td>ratio [0,1]</td>
      </tr>
      <tr>
        <td>SERV-6</td>
        <td>SequenceMatcher similarity</td>
        <td><code>2M / (len(a) + len(b))</code>, M = matching chars</td>
        <td>ratio [0,1]</td>
      </tr>
      <tr>
        <td>SERV-7</td>
        <td>FHE enc/dec overhead</td>
        <td><code>mean(fhenom_usage.enc_ms)</code>, <code>mean(fhenom_usage.dec_ms)</code></td>
        <td>ms</td>
      </tr>
      <tr>
        <td>T-1</td>
        <td>Loss curve divergence</td>
        <td><code>(1/N) Σ |loss_c(i) − loss_e(i)|</code></td>
        <td>abs. diff</td>
      </tr>
      <tr>
        <td>T-2</td>
        <td>Gradient norm diff (latency)</td>
        <td><code>(clear_grad − enc_grad) / clear_grad × 100</code></td>
        <td>%</td>
      </tr>
      <tr>
        <td>T-3</td>
        <td>Adapter MAE, cosine sim</td>
        <td><code>MAE = Σ|W_c − W_e| / |W|</code></td>
        <td>abs. / ratio</td>
      </tr>
    </tbody>
  </table>

  <h3>Source file reference</h3>
  <table>
    <thead><tr><th>Module</th><th>Tests covered</th></tr></thead>
    <tbody>
      <tr><td>dk_test_suite/tests/performance.py</td><td>PERF-1 to PERF-5</td></tr>
      <tr><td>dk_test_suite/tests/accuracy.py</td><td>ACC-1 to ACC-5</td></tr>
      <tr><td>dk_test_suite/tests/scalability.py</td><td>SCALE-1 to SCALE-4</td></tr>
      <tr><td>dk_test_suite/tests/security.py</td><td>SEC-1 to SEC-6</td></tr>
      <tr><td>dk_test_suite/tests/serving.py</td><td>SERV-1 to SERV-7</td></tr>
      <tr><td>dk_test_suite/tests/training.py</td><td>T-1 to T-3</td></tr>
      <tr><td>dk_test_suite/runner.py</td><td>Orchestration and pipeline flow</td></tr>
      <tr><td>dk_test_suite/report.py</td><td>HTML report generation</td></tr>
      <tr><td>dk_test_suite/utils/metrics.py</td><td>BenchmarkMetrics, InferenceResult</td></tr>
    </tbody>
  </table>
</div>

</body>
</html>
"""


def _generate_html(out_dir: Path) -> Path:
    html = _HTML.replace("__BASE_CSS__", _BASE_CSS)
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path = out_dir / "test_suite_details.html"
    html_path.write_text(html, encoding="utf-8")
    print(f"  HTML → {html_path}")
    return html_path


def _html_to_pdf(html_path: Path) -> Path | None:
    pdf_path = html_path.with_suffix(".pdf")
    try:
        from weasyprint import HTML as WH  # type: ignore
        WH(filename=str(html_path)).write_pdf(str(pdf_path))
        print(f"  PDF  → {pdf_path}  [weasyprint]")
        return pdf_path
    except ImportError:
        pass
    for browser in ("chromium-browser", "chromium", "google-chrome", "google-chrome-stable"):
        try:
            result = subprocess.run(
                [browser, "--headless", "--no-sandbox",
                 f"--print-to-pdf={pdf_path}", str(html_path)],
                capture_output=True, timeout=60,
            )
            if result.returncode == 0:
                print(f"  PDF  → {pdf_path}  [{browser}]")
                return pdf_path
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    print("  PDF  → SKIPPED (install weasyprint: pip install weasyprint)")
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate TEST SUITE TECHNICAL DETAILS document")
    parser.add_argument("--out", default=str(_DEFAULT_OUT), help="Output directory")
    args = parser.parse_args()

    out_dir = Path(args.out)
    print("Generating: TEST SUITE TECHNICAL DETAILS")
    html_path = _generate_html(out_dir)
    _html_to_pdf(html_path)
    print("Done.")


if __name__ == "__main__":
    main()
