#!/usr/bin/env python3
"""Generate 'HOW TO USE THE TEST SUITE' as a styled HTML + PDF.

Usage:
    python docs/how_to_use.py [--out <dir>]

Produces:
    how_to_use.html   — standalone HTML (open in browser, print to PDF)
    how_to_use.pdf    — generated via weasyprint if installed
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

# ── Output path ────────────────────────────────────────────────
_DEFAULT_OUT = Path(__file__).resolve().parent / "output"

# ── DK theme shared CSS ────────────────────────────────────────
_BASE_CSS = """
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
  @page { size: A4; margin: 20mm 18mm 20mm 18mm; }

  :root {
    --bg:         #1A1C1D;  --surface:  #222527;  --surface-alt: #292D2E;
    --border:     #363B3C;  --accent:   #DF2B3B;  --accent-dim:  #B91C1C;
    --success:    #00D084;  --warning:  #F59E0B;  --error:       #EF4444;
    --text:       #FFFFFF;  --text-sec: #AAB8C8;  --text-muted:  #72798A;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg);
    color: var(--text);
    font-size: 13.5px;
    line-height: 1.65;
    -webkit-font-smoothing: antialiased;
  }

  /* Cover page */
  .cover {
    min-height: 100vh;
    display: flex; flex-direction: column;
    padding: 64px 72px;
    page-break-after: always;
  }
  .cover-logo {
    display: flex; align-items: center; gap: 12px; margin-bottom: auto;
  }
  .logo-mark {
    width: 40px; height: 40px; background: var(--accent); border-radius: 4px;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 16px; color: white; letter-spacing: -1px;
  }
  .cover-brand { font-size: 18px; font-weight: 700; color: var(--text); }
  .cover-body { flex: 1; display: flex; flex-direction: column; justify-content: center; }
  .cover-label {
    font-size: 11px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.6px; color: var(--accent); margin-bottom: 16px;
  }
  .cover h1 {
    font-size: 42px; font-weight: 800; line-height: 1.1;
    color: var(--text); margin-bottom: 16px;
    letter-spacing: -1px;
  }
  .cover h1 span { color: var(--accent); }
  .cover-sub {
    font-size: 16px; color: var(--text-sec); max-width: 500px;
    margin-bottom: 48px; line-height: 1.6;
  }
  .cover-meta {
    display: flex; gap: 32px; flex-wrap: wrap;
  }
  .cover-meta-item { display: flex; flex-direction: column; gap: 4px; }
  .cover-meta-label { font-size: 10px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.2px; color: var(--text-muted); }
  .cover-meta-val { font-size: 14px; font-weight: 600; color: var(--text-sec); }

  .cover-footer {
    display: flex; justify-content: space-between; align-items: center;
    padding-top: 32px; border-top: 1px solid var(--border);
    font-size: 11px; color: var(--text-muted);
  }
  .conf-badge {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1px; color: var(--accent);
    border: 1px solid rgba(223,43,59,0.4); border-radius: 4px;
    padding: 3px 10px;
  }

  /* TOC */
  .toc-page { padding: 64px 72px; page-break-after: always; }
  .toc-title {
    font-size: 11px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.4px; color: var(--accent); margin-bottom: 12px;
  }
  .toc-heading { font-size: 24px; font-weight: 700; color: var(--text); margin-bottom: 32px; }
  .toc-list { list-style: none; }
  .toc-list li {
    display: flex; align-items: baseline; gap: 8px;
    padding: 9px 0; border-bottom: 1px solid var(--border);
    font-size: 13px;
  }
  .toc-list li:last-child { border-bottom: none; }
  .toc-num { font-size: 10px; font-weight: 700; color: var(--accent);
    text-transform: uppercase; letter-spacing: 1px; min-width: 24px; }
  .toc-name { color: var(--text); font-weight: 500; flex: 1; }
  .toc-dots { flex: 1; border-bottom: 1px dotted var(--border); min-width: 20px; }
  .toc-page-num { font-size: 12px; font-weight: 700; color: var(--text-sec); }

  /* Content pages */
  .section {
    padding: 56px 72px;
  }
  .section-break { page-break-before: always; }

  /* Section headers */
  .section-label {
    font-size: 10px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.4px; color: var(--accent); margin-bottom: 8px;
  }
  h2 {
    font-size: 26px; font-weight: 700; color: var(--text);
    margin-bottom: 16px; letter-spacing: -0.5px; line-height: 1.2;
    page-break-after: avoid; break-after: avoid;
  }
  h2 + p, h2 + .lead { margin-top: 0; }
  .lead { font-size: 15px; color: var(--text-sec); margin-bottom: 32px; line-height: 1.65; }
  h3 {
    font-size: 15px; font-weight: 700; color: var(--text);
    margin-top: 28px; margin-bottom: 10px;
    padding-left: 12px; border-left: 3px solid var(--accent);
    page-break-after: avoid; break-after: avoid;
  }
  h4 {
    font-size: 13px; font-weight: 600; color: var(--text-sec);
    text-transform: uppercase; letter-spacing: 1px;
    margin-top: 20px; margin-bottom: 8px;
  }
  p { color: var(--text-sec); margin-bottom: 14px; }
  strong { color: var(--text); font-weight: 600; }

  /* Cards */
  .card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 4px; padding: 20px 24px; margin-bottom: 16px;
    page-break-inside: avoid; break-inside: avoid;
  }
  .card-accent { border-left: 3px solid var(--accent); }
  .card-success { border-left: 3px solid var(--success); }
  .card-warn { border-left: 3px solid var(--warning); }

  /* Code blocks */
  pre {
    background: var(--surface-alt); border: 1px solid var(--border);
    border-radius: 4px; padding: 16px 20px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px; color: var(--text-sec);
    white-space: pre-wrap; word-break: break-word;
    margin-bottom: 16px; line-height: 1.6;
    page-break-inside: avoid; break-inside: avoid;
  }
  code {
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px; background: var(--surface-alt);
    border: 1px solid var(--border); border-radius: 3px;
    padding: 1px 6px; color: var(--accent);
  }

  /* Inline badge-styled tags */
  .tag {
    display: inline-block; padding: 2px 8px; border-radius: 4px;
    font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px;
  }
  .tag-red   { background: rgba(223,43,59,0.15); color: var(--accent); border: 1px solid rgba(223,43,59,0.3); }
  .tag-green { background: rgba(0,208,132,0.12); color: var(--success); border: 1px solid rgba(0,208,132,0.25); }
  .tag-blue  { background: rgba(148,163,184,0.10); color: var(--text-sec); border: 1px solid var(--border); }

  /* Lists */
  ul, ol { color: var(--text-sec); padding-left: 20px; margin-bottom: 14px; }
  li { margin-bottom: 5px; }
  li strong { color: var(--text); }

  /* Two-column grid */
  .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;
    page-break-inside: avoid; break-inside: avoid; }

  /* Step list */
  .steps { list-style: none; padding: 0; counter-reset: step-counter; }
  .steps li {
    counter-increment: step-counter;
    display: flex; gap: 16px; align-items: flex-start;
    padding: 14px 0; border-bottom: 1px solid var(--border);
  }
  .steps li:last-child { border-bottom: none; }
  .steps li::before {
    content: counter(step-counter);
    min-width: 28px; height: 28px; border-radius: 4px;
    background: var(--accent); color: white;
    font-size: 12px; font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .step-body { flex: 1; }
  .step-title { font-weight: 600; color: var(--text); margin-bottom: 4px; }
  .step-desc { font-size: 13px; color: var(--text-sec); margin: 0; }

  /* Table */
  table { width: 100%; border-collapse: collapse; margin-bottom: 16px;
    page-break-inside: auto; }
  thead { display: table-header-group; }
  tr { page-break-inside: avoid; break-inside: avoid; }
  th { background: var(--surface-alt); padding: 9px 14px;
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1px; color: var(--text-muted);
    border-bottom: 1px solid var(--border); text-align: left; }
  td { padding: 10px 14px; font-size: 13px; color: var(--text-sec);
    border-bottom: 1px solid var(--border); }
  tr:last-child td { border-bottom: none; }
  td:first-child { font-weight: 600; color: var(--text); font-family: 'Courier New', monospace; font-size: 12px; }

  /* Note boxes */
  .note {
    background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.3);
    border-radius: 4px; padding: 12px 16px;
    font-size: 13px; color: var(--text-sec); margin-bottom: 14px;
    page-break-inside: avoid; break-inside: avoid;
  }
  .note strong { color: var(--warning); }
  .info {
    background: rgba(148,163,184,0.08); border: 1px solid var(--border);
    border-radius: 4px; padding: 12px 16px;
    font-size: 13px; color: var(--text-sec); margin-bottom: 14px;
    page-break-inside: avoid; break-inside: avoid;
  }

  /* Divider */
  .divider { border: none; border-top: 1px solid var(--border); margin: 24px 0; }

  /* Print overrides */
  @media print {
    body { background: #fff; color: #000; }
    :root { --bg:#fff; --surface:#f8f8f8; --surface-alt:#f0f0f0;
      --border:#d0d0d0; --text:#000; --text-sec:#444; --text-muted:#888; }
    .cover { min-height: auto; padding: 40px 0; }
    h3 { border-left-color: #DF2B3B; }
    pre { background: #f0f0f0; color: #333; }
    .card { background: #f8f8f8; }
    a { color: inherit; text-decoration: none; }
    .conf-badge { border-color: rgba(223,43,59,0.5); }
  }
"""

# ── HTML document ──────────────────────────────────────────────
_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FHEnom for AI™ — How to Use the Test Suite</title>
<style>
__BASE_CSS__
</style>
</head>
<body>

<!-- ── COVER ─────────────────────────────────────────────────── -->
<div class="cover">
  <div class="cover-logo">
    <svg width="36" height="36" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="32" height="32" rx="4" fill="#DF2B3B"/>
      <path d="M8 10.5C8 9.12 9.12 8 10.5 8H16C19.87 8 23 11.13 23 15V17C23 20.87 19.87 24 16 24H10.5C9.12 24 8 22.88 8 21.5V10.5Z" fill="white" fill-opacity="0.25"/>
      <path d="M11 13C11 12.45 11.45 12 12 12H15.5C17.43 12 19 13.57 19 15.5C19 17.43 17.43 19 15.5 19H12C11.45 19 11 18.55 11 18V13Z" fill="white" fill-opacity="0.9"/>
    </svg>
    <span class="cover-brand">DataKrypto — FHEnom for AI™</span>
  </div>
  <div class="cover-body">
    <div class="cover-label">User Guide</div>
    <h1>How to Use the<br><span>Test Suite</span></h1>
    <p class="cover-sub">
      Step-by-step guide to installing, configuring, and running the
      <strong>dk-test-suite</strong> — the head-to-head validation framework for
      FHEnom-encrypted model deployments.
    </p>
    <div class="cover-meta">
      <div class="cover-meta-item">
        <span class="cover-meta-label">Document</span>
        <span class="cover-meta-val">DK-POC-GUIDE-001</span>
      </div>
      <div class="cover-meta-item">
        <span class="cover-meta-label">Suite Version</span>
        <span class="cover-meta-val">v0.1.0</span>
      </div>
      <div class="cover-meta-item">
        <span class="cover-meta-label">Date</span>
        <span class="cover-meta-val">April 2026</span>
      </div>
      <div class="cover-meta-item">
        <span class="cover-meta-label">Classification</span>
        <span class="cover-meta-val" style="color:var(--accent)">Confidential</span>
      </div>
    </div>
  </div>
  <div class="cover-footer">
    <span>DataKrypto — FHEnom for AI™ &nbsp;·&nbsp; POC Validation Framework</span>
    <span class="conf-badge">Confidential</span>
  </div>
</div>

<!-- ── TABLE OF CONTENTS ─────────────────────────────────────── -->
<div class="toc-page">
  <div class="toc-title">Contents</div>
  <div class="toc-heading">Table of Contents</div>
  <ul class="toc-list">
    <li><span class="toc-num">1</span><span class="toc-name">Overview</span><span class="toc-dots"></span><span class="toc-page-num">3</span></li>
    <li><span class="toc-num">2</span><span class="toc-name">Architecture</span><span class="toc-dots"></span><span class="toc-page-num">3</span></li>
    <li><span class="toc-num">3</span><span class="toc-name">Prerequisites</span><span class="toc-dots"></span><span class="toc-page-num">4</span></li>
    <li><span class="toc-num">4</span><span class="toc-name">Installation</span><span class="toc-dots"></span><span class="toc-page-num">4</span></li>
    <li><span class="toc-num">5</span><span class="toc-name">Configuration Reference</span><span class="toc-dots"></span><span class="toc-page-num">5</span></li>
    <li><span class="toc-num">6</span><span class="toc-name">Running the Suite</span><span class="toc-dots"></span><span class="toc-page-num">7</span></li>
    <li><span class="toc-num">7</span><span class="toc-name">Understanding the Report</span><span class="toc-dots"></span><span class="toc-page-num">8</span></li>
    <li><span class="toc-num">8</span><span class="toc-name">CLI Reference</span><span class="toc-dots"></span><span class="toc-page-num">9</span></li>
    <li><span class="toc-num">9</span><span class="toc-name">Troubleshooting</span><span class="toc-dots"></span><span class="toc-page-num">10</span></li>
  </ul>
</div>

<!-- ── SECTION 1: OVERVIEW ───────────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 1</div>
  <h2>Overview</h2>
  <p class="lead">
    The <strong>dk-test-suite</strong> is an automated validation framework that provides
    quantitative, side-by-side evidence that a FHEnom-encrypted model is equivalent to
    its clear (unencrypted) counterpart across performance, accuracy, scalability,
    security, and serving dimensions.
  </p>

  <div class="card card-accent">
    <strong>What it proves:</strong>
    <ul style="margin-top:8px;">
      <li>The encrypted model files are genuinely encrypted (no plaintext weights on disk or in RAM).</li>
      <li>The TEE proxy correctly decrypts and forwards inference — outputs match the clear model.</li>
      <li>Bypassing the TEE and querying the encrypted model directly produces garbled output.</li>
      <li>Performance overhead introduced by FHE encryption/decryption is measured and reported.</li>
    </ul>
  </div>

  <h3>Test Categories</h3>
  <div class="two-col">
    <div class="card">
      <span class="tag tag-red">PERF-1 to PERF-5</span>
      <h4 style="margin-top:10px;">Performance</h4>
      <p>TTFT, throughput, E2E response time, model footprint, GPU VRAM usage.</p>
    </div>
    <div class="card">
      <span class="tag tag-blue">ACC-1 to ACC-5</span>
      <h4 style="margin-top:10px;">Accuracy</h4>
      <p>Exact match, lm-eval benchmarks, BERTScore, response length, perplexity.</p>
    </div>
    <div class="card">
      <span class="tag tag-blue">SCALE-1 to SCALE-4</span>
      <h4 style="margin-top:10px;">Scalability</h4>
      <p>Concurrent load, context length, batch processing, sustained operation.</p>
    </div>
    <div class="card">
      <span class="tag tag-red">SEC-1 to SEC-6</span>
      <h4 style="margin-top:10px;">Security</h4>
      <p>Encryption at rest, runtime memory, transport, model binding, key isolation, logging.</p>
    </div>
    <div class="card">
      <span class="tag tag-green">SERV-1 to SERV-7</span>
      <h4 style="margin-top:10px;">Serving</h4>
      <p>File integrity, vLLM health, TEE status, coherence, encryption proof, fidelity, FHE overhead.</p>
    </div>
    <div class="card">
      <span class="tag tag-blue">T-1 to T-3</span>
      <h4 style="margin-top:10px;">Training</h4>
      <p>Convergence, gradient consistency, LoRA/MoE adapter equivalence.</p>
    </div>
  </div>
</div>

<!-- ── SECTION 2: ARCHITECTURE ───────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 2</div>
  <h2>Architecture</h2>
  <p class="lead">
    The test suite requires two machines — the <strong>GPU Server</strong> (hosts
    the vLLM container) and the <strong>TEE Machine</strong> (the FHEnom Trusted
    Execution Environment). The test runner runs on any third machine with SSH
    access to both.
  </p>

  <div class="note">
    <strong>Single-port sequential execution:</strong> the clear model and the
    encrypted model are never loaded into GPU VRAM at the same time.
    Both use port <code>8000</code>, but at different times — clear first, then
    encrypted. This keeps VRAM requirements at 1× model size regardless of model scale.
  </div>

  <h3>Three-Way Proof (Core of the Suite)</h3>
  <p>Every serving test uses three independent inference paths to construct the empirical proof:
  Paths 1 and 3 run when the <em>encrypted</em> model is on port 8000.
  Path 2 outputs are collected earlier in Phase 1 when the <em>clear</em> model is on port 8000.</p>

  <div class="card card-success" style="margin-bottom:12px;">
    <strong style="color:var(--success);">Path 1 — TEE (Encrypted)</strong><br>
    <code>User → TEE:9999 → FHE decrypt → vLLM:8000 (encrypted model) → TEE → User</code><br>
    <span style="font-size:12px;color:var(--text-sec);">Expected: coherent English output (e.g. "Paris. The Eiffel Tower...")</span>
  </div>

  <div class="card" style="margin-bottom:12px;">
    <strong>Path 2 — Clear Model (collected in Phase 1)</strong><br>
    <code>Phase 1: vLLM:8000 (clear model, SSH curl from GPU) → output stored for SERV-6</code><br>
    <span style="font-size:12px;color:var(--text-sec);">Expected: identical coherent output (fidelity ≥ 0.70)</span>
  </div>

  <div class="card card-accent" style="margin-bottom:12px;">
    <strong style="color:var(--accent);">Path 3 — Encrypted Bypass (Direct)</strong><br>
    <code>User → vLLM:8000 (encrypted model, no TEE decryption) → User</code><br>
    <span style="font-size:12px;color:var(--text-sec);">Expected: garbled output (e.g. "0Rbss7UvBM2RM2RM2R...") — proves encryption is real</span>
  </div>

  <h3>Infrastructure Topology</h3>
  <pre>
┌─────────────────────────────────────────────────────────────────────────┐
│                        TEST RUNNER MACHINE                              │
│   dk-test run --config config/default.yaml -t serving -t security      │
│   • SSH client to both GPU and TEE                                      │
│   • Generates HTML report + JSON results                                │
└───────────────┬────────────────────────┬────────────────────────────────┘
                │ SSH                    │ SSH
      ┌─────────▼──────────┐   ┌────────▼────────────────────────────┐
      │   TEE MACHINE       │   │         GPU SERVER                  │
      │   TEE:9099 (admin) │   │   vllm_enc_server   :8000           │
      │   TEE:9999 (user)  │   │   vllm:8000 (clear → stop → encrypted) │
      │   FHEnom ≥ 1.5.2   ◄──►   NVIDIA A100 (80 GB VRAM)            │
      └────────────────────┘   │   Docker Engine                        │
                                └────────────────────────────────────────┘
  </pre>
</div>
</div>

<!-- ── SECTION 3: PREREQUISITES ──────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 3</div>
  <h2>Prerequisites</h2>

  <h3>GPU Server</h3>
  <ul>
    <li>NVIDIA A100 (or compatible) GPU, VRAM ≥ 40 GB</li>
    <li>Docker Engine with NVIDIA Container Toolkit</li>
    <li>One vLLM container slot on port <code>8000</code> — shared sequentially:
      <ul>
        <li>Phase 1: clear model loaded as <code>dk_vllm_bench</code> on port 8000, collected, then stopped</li>
        <li>Phase 2: encrypted model loaded as <code>dk_vllm_bench</code> on port 8000</li>
      </ul>
      <em>Only one instance at a time — no 2× VRAM requirement.</em>
    </li>
    <li>SSH accessible as <code>root</code> with key-based auth</li>
    <li>Python 3.9+ in <code>/home/&lt;user&gt;/venv</code></li>
  </ul>

  <h3>TEE Machine</h3>
  <ul>
    <li>FHEnom for AI v1.5.2 or later installed via official installer</li>
    <li>At least one encrypted model registered and in <code>ONLINE</code> state</li>
    <li>Admin port 9099 accessible (for registration and status queries)</li>
    <li>User port 9999 accessible (for inference)</li>
    <li>Valid auth token (set in config: <code>tee_user_token</code>)</li>
  </ul>

  <h3>Test Runner Machine</h3>
  <ul>
    <li>Python 3.10+</li>
    <li>SSH private keys with access to GPU and (optionally) TEE</li>
    <li>Internet access for Google Fonts if viewing the HTML report in a browser</li>
  </ul>

  <div class="note">
    <strong>Note:</strong> The test runner can be the same machine as the GPU server.
    In that case set <code>gpu_host: localhost</code> in the config and use a local SSH key.
  </div>
</div>

<!-- ── SECTION 4: INSTALLATION ───────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 4</div>
  <h2>Installation</h2>

  <ol class="steps">
    <li>
      <div class="step-body">
        <div class="step-title">Clone or copy the test suite</div>
        <div class="step-desc">The suite lives in <code>POC_TEST_SUITE/dk_test_suite/</code>.</div>
        <pre>git clone &lt;repo&gt; || rsync -avz &lt;source&gt; &lt;dest&gt;</pre>
      </div>
    </li>
    <li>
      <div class="step-body">
        <div class="step-title">Create a virtual environment and install</div>
        <pre>cd POC_TEST_SUITE/dk_test_suite
python3 -m venv env
source env/bin/activate
pip install -e ".[dev]"</pre>
      </div>
    </li>
    <li>
      <div class="step-body">
        <div class="step-title">Verify the CLI is available</div>
        <pre>dk-test --version
# FHEnom for AI — POC Head-to-Head Test Suite, version 0.1.0</pre>
      </div>
    </li>
    <li>
      <div class="step-body">
        <div class="step-title">Place your SSH key</div>
        <div class="step-desc">Ensure the key has <code>chmod 600</code>.</div>
        <pre>chmod 600 /path/to/your/gpu-key.pem</pre>
      </div>
    </li>
    <li>
      <div class="step-body">
        <div class="step-title">Copy and edit the configuration file</div>
        <pre>cp config/default.yaml config/my_poc.yaml
# Edit at minimum: gpu_host, tee_host, gpu_ssh_key, tee_user_token</pre>
      </div>
    </li>
    <li>
      <div class="step-body">
        <div class="step-title">Run a smoke test (serving + security only)</div>
        <pre>dk-test run \\
  --config config/my_poc.yaml \\
  -t serving -t security \\
  --skip-clear-vllm --skip-encrypted-vllm</pre>
        <div class="step-desc">
          <code>--skip-clear-vllm</code> and <code>--skip-encrypted-vllm</code> tell the runner to
          use already-running vLLM containers instead of starting new ones.
        </div>
      </div>
    </li>
  </ol>
</div>

<!-- ── SECTION 5: CONFIGURATION REFERENCE ───────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 5</div>
  <h2>Configuration Reference</h2>
  <p class="lead">
    All settings are YAML. Copy <code>config/default.yaml</code> and override only what
    you need. CLI flags override config values which override defaults.
  </p>

  <h3>Machines</h3>
  <table>
    <thead><tr><th>Key</th><th>Type</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td>gpu_host</td><td>string (IP)</td><td>IP address of the GPU server</td></tr>
      <tr><td>tee_host</td><td>string (IP)</td><td>IP address of the TEE machine</td></tr>
      <tr><td>gpu_ssh_user</td><td>string</td><td>SSH user on the GPU (default: root)</td></tr>
      <tr><td>gpu_ssh_key</td><td>path</td><td>Path to SSH private key for the GPU</td></tr>
      <tr><td>tee_admin_port</td><td>integer</td><td>TEE admin API port (default: 9099)</td></tr>
      <tr><td>tee_user_port</td><td>integer</td><td>TEE inference port (default: 9999)</td></tr>
      <tr><td>tee_user_token</td><td>string</td><td>Bearer token for TEE inference auth</td></tr>
      <tr><td>tee_admin_token</td><td>string</td><td>X-Auth-Token for TEE admin API</td></tr>
    </tbody>
  </table>

  <h3>Models</h3>
  <table>
    <thead><tr><th>Key</th><th>Type</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td>model_name</td><td>string</td><td>HF model name for the clear model (e.g. <code>Llama-3.2-1B-Instruct</code>)</td></tr>
      <tr><td>encrypted_model_name</td><td>string</td><td>Name as served by vllm_enc_server</td></tr>
      <tr><td>encrypted_model_id</td><td>string</td><td>UUID returned by TEE model registration</td></tr>
      <tr><td>model_path_clear</td><td>path</td><td>Absolute path to clear model weights on GPU</td></tr>
      <tr><td>model_path_encrypted</td><td>path</td><td>Absolute path to encrypted model weights on GPU</td></tr>
    </tbody>
  </table>

  <h3>vLLM containers</h3>
  <table>
    <thead><tr><th>Key</th><th>Default</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td>vllm_port</td><td>8000</td><td>Single port reused for both clear (Phase 1) and encrypted (Phase 2) vLLM</td></tr>
      <tr><td>vllm_enc_container</td><td>vllm_enc_server</td><td>Docker container name (reused for both clear and encrypted)</td></tr>
    </tbody>
  </table>

  <h3>Benchmark parameters</h3>
  <table>
    <thead><tr><th>Key</th><th>Default</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td>num_prompts</td><td>100</td><td>Number of benchmark prompts for PERF/ACC tests</td></tr>
      <tr><td>seed</td><td>42</td><td>Random seed for prompt generation (reproducibility)</td></tr>
      <tr><td>temperature</td><td>0</td><td>Inference temperature (0 = deterministic greedy)</td></tr>
      <tr><td>accuracy_benchmarks</td><td>[hellaswag, arc_easy]</td><td>lm-eval-harness tasks for ACC-2</td></tr>
    </tbody>
  </table>

  <h3>Thresholds</h3>
  <table>
    <thead><tr><th>Key</th><th>Default</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td>fhe_enc_overhead_threshold_ms</td><td>10.0</td><td>SERV-7: max allowed FHE encryption overhead (ms)</td></tr>
      <tr><td>fhe_dec_overhead_threshold_ms</td><td>5.0</td><td>SERV-7: max allowed FHE decryption overhead (ms)</td></tr>
    </tbody>
  </table>
</div>

<!-- ── SECTION 6: RUNNING THE SUITE ─────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 6</div>
  <h2>Running the Suite</h2>

  <!-- ── Most Common Use Case ─────────────────────────────────── -->
  <div class="card card-accent" style="margin-bottom:24px;">
    <strong style="font-size:15px;">Most Common Setup: Running Directly from the GPU Machine</strong>
    <p style="margin-top:8px;">
      In most POC deployments the test suite runs <strong>on the GPU server itself</strong>,
      connecting out to the remote TEE machine over HTTPS.
      The steps below assume this topology.
    </p>
  </div>

  <h3>Step 1 — Create a local config</h3>
  <pre>cp config/default.yaml config/local_poc.yaml</pre>
  <p>Set <code>local_mode: true</code> — the runner will automatically use <code>127.0.0.1</code>
  for all vLLM HTTP calls and local subprocesses for all Docker/shell commands.
  No SSH key needed:</p>
  <pre>local_mode: true                              # no SSH key, gpu_host auto-set to 127.0.0.1
tee_host: "&lt;TEE_IP&gt;"                          # remote TEE machine IP
tee_user_token: "&lt;bearer-token&gt;"
model_name: "Llama-3.2-1B-Instruct"
encrypted_model_name: "Llama-3.2-1B-Instruct-encrypted"
encrypted_model_id: "&lt;UUID from fhenomai model list&gt;"
model_path_clear: "/home/&lt;user&gt;/models/Llama-3.2-1B-Instruct"
model_path_encrypted: "/home/&lt;user&gt;/models/Llama-3.2-1B-Instruct-encrypted"</pre>

  <div class="info">Get the <code>encrypted_model_id</code> UUID by running:
  <code>fhenomai model list --show-details</code> on the GPU machine.</div>

  <h3>Step 2 — Choose a run mode</h3>

  <div class="card card-success" style="margin-bottom:12px;">
    <strong style="color:var(--success);">Option A — vLLM already running (fastest)</strong>
    <p style="margin-top:6px;">If the serving tutorial containers are still up:</p>
    <pre style="margin-top:8px;margin-bottom:0;">dk-test run --config config/local_poc.yaml \\
  --skip-clear-vllm --skip-encrypted-vllm</pre>
  </div>

  <div class="card card-accent" style="margin-bottom:12px;">
    <strong>Option B — Full suite with managed containers (recommended for clean results)</strong>
    <p style="margin-top:6px;">Runner starts and stops vLLM containers automatically.
    Ensure no container is already bound to port 8000.</p>
    <pre style="margin-top:8px;margin-bottom:0;">docker rm -f dk_vllm_bench 2>/dev/null || true
dk-test run --config config/local_poc.yaml</pre>
  </div>

  <div class="card" style="margin-bottom:12px;">
    <strong>Option C — Quick smoke test (serving + security only, ~5–10 min)</strong>
    <pre style="margin-top:8px;margin-bottom:0;">dk-test run --config config/local_poc.yaml \\
  -t serving -t security \\
  --skip-clear-vllm --skip-encrypted-vllm</pre>
  </div>

  <h3>Step 3 — Retrieve the report</h3>
  <pre># The HTML report is written to:
ls results/poc_report_*.html

# Copy to your local machine for viewing:
scp root@&lt;GPU_IP&gt;:~/POC_TEST_SUITE/dk_test_suite/results/poc_report_*.html ./</pre>

  <hr class="divider">

  <h3>Remote Runner (Alternative Topology)</h3>
  <p>If the test suite runs on a <em>separate</em> machine, set <code>gpu_host</code>
  to the GPU&#8217;s external IP and provide an SSH key for the GPU. Do <strong>not</strong> set <code>local_mode</code>:</p>
  <pre>gpu_host: "&lt;GPU_IP&gt;"
gpu_ssh_user: "root"
gpu_ssh_key: "/path/to/gpu.key"
tee_host: "&lt;TEE_IP&gt;"
tee_user_token: "&lt;bearer-token&gt;"</pre>

  <hr class="divider">

  <h3>Run Specific Categories</h3>
  <pre># Only serving and security
dk-test run --config config/local_poc.yaml \\
  -t serving -t security \\
  --skip-clear-vllm --skip-encrypted-vllm

# All six categories (explicitly)
dk-test run --config config/local_poc.yaml \\
  -t performance -t accuracy -t scalability \\
  -t security -t serving -t training \\
  --skip-clear-vllm --skip-encrypted-vllm</pre>

  <h3>Override Config Values from CLI</h3>
  <pre>dk-test run --config config/local_poc.yaml \\
  --num-prompts 50 \\
  --output results/run_001/ \\
  -v    # verbose debug logging</pre>

  <h3>Output files</h3>
  <p>All outputs are written to <code>output_dir</code> (default: <code>results/</code>):</p>
  <div class="two-col">
    <div class="card">
      <strong>poc_report_&lt;timestamp&gt;.html</strong>
      <p style="margin-top:6px;font-size:12px;">Styled DataKrypto HTML report. Open in any browser.</p>
    </div>
    <div class="card">
      <strong>poc_results_&lt;timestamp&gt;.json</strong>
      <p style="margin-top:6px;font-size:12px;">Raw JSON array of all TestResult objects for programmatic use.</p>
    </div>
    <div class="card">
      <strong>security_results.json</strong>
      <p style="margin-top:6px;font-size:12px;">Intermediate results saved by the security test phase.</p>
    </div>
    <div class="card">
      <strong>serving_results.json</strong>
      <p style="margin-top:6px;font-size:12px;">Intermediate results from the serving test phase.</p>
    </div>
  </div>

  <h3>Execution time estimates</h3>
  <table>
    <thead><tr><th>Category</th><th>Typical Duration</th><th>Notes</th></tr></thead>
    <tbody>
      <tr><td>serving</td><td>2–5 min</td><td>3 probe prompts × 3 paths</td></tr>
      <tr><td>security</td><td>3–6 min</td><td>File entropy scan is the slowest step</td></tr>
      <tr><td>performance</td><td>10–20 min</td><td>Depends on num_prompts</td></tr>
      <tr><td>accuracy</td><td>20–60 min</td><td>lm-eval-harness can take 30–45 min</td></tr>
      <tr><td>scalability</td><td>15–30 min</td><td>Concurrent + context + batch + sustained</td></tr>
      <tr><td>training</td><td>30–120 min</td><td>Requires LoRA training run</td></tr>
    </tbody>
  </table>
</div>

<!-- ── SECTION 7: UNDERSTANDING THE REPORT ──────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 7</div>
  <h2>Understanding the Report</h2>

  <h3>Difference column convention</h3>
  <p>All "<strong>diff</strong>" values use a consistent signed convention:</p>
  <div class="card card-accent">
    <strong>+ (positive)</strong> = encrypted model is <em>faster</em> or <em>better</em> than clear<br>
    <strong>− (negative)</strong> = encrypted model is <em>slower</em> or <em>worse</em> than clear
  </div>

  <table style="margin-top:16px;">
    <thead><tr><th>Metric type</th><th>Formula</th><th>+ means</th></tr></thead>
    <tbody>
      <tr><td>Latency (lower=better): TTFT, E2E, latency</td>
          <td><code>(clear − enc) / clear × 100%</code></td>
          <td>Encrypted is faster</td></tr>
      <tr><td>Throughput (higher=better): tokens/sec</td>
          <td><code>(enc − clear) / clear × 100%</code></td>
          <td>Encrypted has higher throughput</td></tr>
      <tr><td>Perplexity (lower=better)</td>
          <td><code>(clear_ppl − enc_ppl) / clear_ppl × 100%</code></td>
          <td>Encrypted has lower (better) perplexity</td></tr>
      <tr><td>lm-eval score (higher=better)</td>
          <td><code>enc_score − clear_score</code></td>
          <td>Encrypted scores higher on benchmark</td></tr>
    </tbody>
  </table>

  <h3>PASS / FAIL logic</h3>
  <ul>
    <li><strong>PERF-*, ACC-*, SCALE-*, T-*</strong>: always PASS — these are measurement-only
        tests that document the overhead. There is no threshold to breach.</li>
    <li><strong>SEC-*</strong>: PASS = no plaintext weights found, no key material in logs,
        transport is TLS, container is isolated.</li>
    <li><strong>SERV-1 to SERV-3</strong>: PASS = infrastructure checks succeed (files present,
        server healthy, TEE online).</li>
    <li><strong>SERV-4</strong>: PASS = TEE output is coherent English (space ratio ≥ 0.08)
        and encrypted bypass is garbled (space ratio ≤ 0.04).</li>
    <li><strong>SERV-5</strong>: PASS = coherent score &gt; garbled score for every probe prompt.</li>
    <li><strong>SERV-6</strong>: PASS = SequenceMatcher ratio ≥ 0.70 for each probe where both
        outputs are available. FAIL if all probes are skipped.</li>
    <li><strong>SERV-7</strong>: PASS = average FHE encryption overhead &lt; threshold (default 10 ms)
        <em>and</em> decryption overhead &lt; threshold (default 5 ms). FAIL if timing metadata
        is not returned by the TEE.</li>
  </ul>

  <h3>Details toggle</h3>
  <p>Each row has a <strong>▶ Details</strong> button that expands verbatim output from the test,
  including full inference texts for SERV-6 and first-divergence character for diagnosis.</p>
</div>

<!-- ── SECTION 8: CLI REFERENCE ─────────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 8</div>
  <h2>CLI Reference</h2>

  <pre>dk-test run [OPTIONS]

  Run the full POC test suite (or selected categories).

Options:
  -c / --config PATH          Path to YAML config override file
  --gpu-host TEXT             Override gpu_host in config
  --tee-host TEXT             Override tee_host in config
  --model TEXT                Override model_name in config
  --output TEXT               Output directory for results (default: results/)
  -t / --categories TEXT      Category to run: performance, accuracy, scalability,
                              security, serving, training  [repeatable]
  --num-prompts INTEGER       Override num_prompts in config
  --skip-clear-vllm           Skip starting/stopping the clear vLLM container
  --skip-encrypted-vllm       Skip starting/stopping the encrypted vLLM container
  -v / --verbose              Enable DEBUG logging
  --help                      Show this message and exit</pre>

  <h3>Environment variables</h3>
  <table>
    <thead><tr><th>Variable</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td>DK_GPU_SSH_KEY</td><td>Path to GPU SSH key (overrides config)</td></tr>
      <tr><td>DK_TEE_TOKEN</td><td>TEE bearer token (overrides config)</td></tr>
    </tbody>
  </table>
</div>

<!-- ── SECTION 9: TROUBLESHOOTING ───────────────────────────── -->
<div class="section section-break">
  <div class="section-label">Section 9</div>
  <h2>Troubleshooting</h2>

  <h3>SEC-2 FAIL: "Could not find vLLM container PID"</h3>
  <div class="card card-warn">
    <p><strong>Cause:</strong> The vLLM container running the encrypted model has a name
    different from <code>vllm_enc_server</code> or <code>dk_vllm_bench</code>.</p>
    <p><strong>Fix:</strong> Set <code>vllm_enc_container: &lt;actual-container-name&gt;</code>
    in your config. The runner tries the config value first, then falls back to
    <code>vllm_enc_server</code> and <code>dk_vllm_bench</code>.</p>
  </div>

  <h3>SERV-6: similarity below 0.70 threshold</h3>
  <div class="card card-warn">
    <p><strong>Cause:</strong> FHE weight approximation introduces small floating-point
    differences that can flip the greedy sampler to a different token in
    knowledge-heavy retrieval prompts (e.g. geography/science).</p>
    <p><strong>Expected:</strong> Pattern-completion prompts (e.g. Python language description)
    typically match 100%. Factual prompts may diverge after token 25–30.</p>
    <p><strong>Fix:</strong> If you need stricter guarantees, reduce the FHE approximation
    level in the FHEnom configuration, or lower <code>_FIDELITY_RATIO</code> in
    <code>serving.py</code> if the divergence is acceptable for your use case.</p>
  </div>

  <h3>SERV-7 FAIL: "FHE timing metadata not returned"</h3>
  <div class="card card-warn">
    <p><strong>Cause:</strong> The TEE version does not return <code>fhenom_usage</code>
    in the response body.</p>
    <p><strong>Fix:</strong> Upgrade FHEnom to v1.5.2 or later, which adds the
    <code>fhenom_usage.enc_ms</code> and <code>fhenom_usage.dec_ms</code> fields.</p>
  </div>

  <h3>SSH: "Host key verification failed"</h3>
  <pre>ssh -o StrictHostKeyChecking=no -i /path/to/key root@&lt;host&gt; echo ok</pre>

  <h3>lm-eval not found (ACC-2)</h3>
  <pre>pip install lm-eval      # or
pip install "lm-eval[math,ifeval,multilingual]"</pre>

  <h3>bert_score not found (ACC-3)</h3>
  <pre>pip install bert-score</pre>
  <p>If not installed, the suite falls back to character-overlap similarity automatically.</p>

  <h3>Report HTML shows raw variable names</h3>
  <p>This means the Jinja2 template failed to render. Check that <code>jinja2</code>
  is installed:</p>
  <pre>pip install jinja2</pre>

  <hr class="divider">

  <div class="card card-success">
    <strong style="color:var(--success);">Support</strong><br>
    Contact DataKrypto engineering with logs from <code>dk-test run -v</code> and the
    <code>poc_results_*.json</code> file from your <code>results/</code> directory.
  </div>
</div>

</body>
</html>
"""


def _generate_html(out_dir: Path) -> Path:
    html = _HTML.replace("__BASE_CSS__", _BASE_CSS)
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path = out_dir / "how_to_use.html"
    html_path.write_text(html, encoding="utf-8")
    print(f"  HTML → {html_path}")
    return html_path


def _html_to_pdf(html_path: Path) -> Path | None:
    pdf_path = html_path.with_suffix(".pdf")
    # Try weasyprint first
    try:
        from weasyprint import HTML as WH  # type: ignore
        WH(filename=str(html_path)).write_pdf(str(pdf_path))
        print(f"  PDF  → {pdf_path}  [weasyprint]")
        return pdf_path
    except ImportError:
        pass
    # Try chromium/google-chrome headless
    for browser in ("chromium-browser", "chromium", "google-chrome", "google-chrome-stable"):
        try:
            result = subprocess.run(
                [browser, "--headless", "--no-sandbox",
                 f"--print-to-pdf={pdf_path}", str(html_path)],
                capture_output=True, timeout=60,
            )
            if result.returncode == 0:
                print(f"  PDF  → {pdf_path}  [{browser}]")
                return pdf_path
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    print("  PDF  → SKIPPED (install weasyprint: pip install weasyprint)")
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate HOW TO USE THE TEST SUITE document")
    parser.add_argument("--out", default=str(_DEFAULT_OUT), help="Output directory")
    args = parser.parse_args()

    out_dir = Path(args.out)
    print("Generating: HOW TO USE THE TEST SUITE")
    html_path = _generate_html(out_dir)
    _html_to_pdf(html_path)
    print("Done.")


if __name__ == "__main__":
    main()
