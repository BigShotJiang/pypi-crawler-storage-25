"""TEE manager — encrypt, register model, serve through TEE, query via TEE."""

from __future__ import annotations

import json
import logging
import time
from typing import Any

import httpx

from dk_test_suite.config import Config
from dk_test_suite.utils import RemoteHost
from dk_test_suite.utils.metrics import InferenceResult

log = logging.getLogger(__name__)


class TEEManager:
    """Manages interaction with the FHEnom TEE environment."""

    def __init__(self, cfg: Config, gpu: RemoteHost) -> None:
        self.cfg = cfg
        self.gpu = gpu
        self._user_url = cfg.tee_user_url
        self._admin_url = cfg.tee_admin_url
        self._user_headers = {"Authorization": f"Bearer {cfg['tee_user_token']}"}
        self._admin_headers = {"X-Auth-Token": cfg["tee_admin_token"]}
        self._http = httpx.Client(verify=False, timeout=120)

    def close(self) -> None:
        self._http.close()

    # ── Model registration with TEE ────────────────────────────
    def register_model(self, model_id: str | None = None) -> dict[str, Any]:
        """Register the encrypted model with the TEE for serving."""
        mid = model_id or self.cfg["encrypted_model_id"]
        url = f"{self._admin_url}/api/v1/models/{mid}/register"
        r = self._http.post(url, headers=self._admin_headers)
        r.raise_for_status()
        log.info("Model %s registered with TEE", mid)
        return r.json() if r.text else {}

    def start_serving(self) -> dict[str, Any]:
        """Register the vLLM backend with the TEE for encrypted serving."""
        url = f"{self._admin_url}/api/v1/serve"
        body = {
            "model_id": self.cfg["encrypted_model_id"],
            "backend_url": f"http://{self.cfg.gpu_host}:{self.cfg['vllm_port']}",
        }
        r = self._http.post(url, json=body, headers=self._admin_headers)
        r.raise_for_status()
        log.info("TEE serving started")
        return r.json() if r.text else {}

    # ── Inference through TEE ───────────────────────────────────
    def completions(self, prompt: str, max_tokens: int = 256,
                    temperature: float = 0, logprobs: bool = False,
                    **kwargs: Any) -> InferenceResult:
        """Call /v1/completions through the TEE proxy."""
        url = f"{self._user_url}/v1/completions"
        body: dict[str, Any] = {
            "model": self.cfg.encrypted_model_name,
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if logprobs:
            body["logprobs"] = 1
        body.update(kwargs)

        t0 = time.perf_counter()
        r = self._http.post(url, json=body, headers=self._user_headers)
        total_ms = (time.perf_counter() - t0) * 1000
        r.raise_for_status()
        data = r.json()

        choices = data.get("choices", [])
        if not choices or choices[0] is None:
            raise RuntimeError(f"TEE returned empty choices: {str(data)[:300]}")
        choice = choices[0]

        # Check for TEE error responses
        if choice.get("finish_reason") == "error":
            raise RuntimeError(f"TEE error: {choice.get('text', 'unknown')}")

        usage = data.get("usage") or {}
        lp_values: list[float] | None = None
        if logprobs and "logprobs" in choice and choice["logprobs"]:
            lp_values = [
                lp for lp in (choice["logprobs"].get("token_logprobs") or [])
                if lp is not None
            ]

        return InferenceResult(
            prompt_id="",
            prompt_text=prompt,
            output_text=choice.get("text", "") or "",
            tokens_generated=usage.get("completion_tokens", 0),
            total_time_ms=total_ms,
            logprobs=lp_values,
        )

    def chat(self, messages: list[dict[str, str]], max_tokens: int = 256,
             temperature: float = 0, **kwargs: Any) -> InferenceResult:
        """Chat completions through TEE."""
        url = f"{self._user_url}/v1/chat/completions"
        body: dict[str, Any] = {
            "model": self.cfg.encrypted_model_name,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        body.update(kwargs)

        t0 = time.perf_counter()
        r = self._http.post(url, json=body, headers=self._user_headers)
        total_ms = (time.perf_counter() - t0) * 1000
        r.raise_for_status()
        data = r.json()

        choices = data.get("choices", [])
        if not choices or choices[0] is None:
            raise RuntimeError(f"TEE chat returned empty choices: {str(data)[:300]}")
        choice = choices[0]

        if choice.get("finish_reason") == "error":
            raise RuntimeError(f"TEE chat error: {choice.get('text', 'unknown')}")

        usage = data.get("usage") or {}
        msg = choice.get("message") or {}
        return InferenceResult(
            prompt_id="",
            prompt_text=str(messages),
            output_text=msg.get("content", "") or "",
            tokens_generated=usage.get("completion_tokens", 0),
            total_time_ms=total_ms,
        )

    def completions_streaming(self, prompt: str, max_tokens: int = 256,
                              temperature: float = 0) -> InferenceResult:
        """Streaming completions through TEE — measures TTFT."""
        url = f"{self._user_url}/v1/completions"
        body = {
            "model": self.cfg.encrypted_model_name,
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }

        t0 = time.perf_counter()
        ttft: float = 0.0
        chunks: list[str] = []
        token_count = 0
        usage_tokens: int | None = None

        with self._http.stream("POST", url, json=body, headers=self._user_headers) as r:
            for line in r.iter_lines():
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if payload.strip() == "[DONE]":
                    break
                try:
                    chunk_data = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                choices = chunk_data.get("choices", [])
                if not choices:
                    continue
                choice = choices[0]
                if choice is None:
                    continue
                # Check for TEE error
                if choice.get("finish_reason") == "error":
                    raise RuntimeError(f"TEE stream error: {choice.get('text', 'unknown')}")
                # Extract usage from final chunk if available
                chunk_usage = chunk_data.get("usage")
                if chunk_usage and chunk_usage.get("completion_tokens"):
                    usage_tokens = chunk_usage["completion_tokens"]
                text = choice.get("text", "") or ""
                if text and ttft == 0.0:
                    ttft = (time.perf_counter() - t0) * 1000
                if text:
                    chunks.append(text)
                    token_count += 1

        total_ms = (time.perf_counter() - t0) * 1000
        final_token_count = usage_tokens if usage_tokens is not None else token_count
        return InferenceResult(
            prompt_id="",
            prompt_text=prompt,
            output_text="".join(chunks),
            time_to_first_token_ms=ttft,
            total_time_ms=total_ms,
            tokens_generated=final_token_count,
        )

    # ── Inspection helpers ──────────────────────────────────────
    def health_check(self) -> bool:
        try:
            r = self._http.get(f"{self._admin_url}/health", headers=self._admin_headers)
            return r.status_code == 200
        except httpx.HTTPError:
            return False

    def list_models(self) -> list[dict[str, Any]]:
        r = self._http.get(f"{self._admin_url}/api/v1/models", headers=self._admin_headers)
        r.raise_for_status()
        return r.json() if r.text else []
