"""Test runner / orchestrator.

Flow (single port 8000 — sequential, never two vLLM instances at once):
  1. Start vLLM (port 8000) with clear model → wait ready → run tests → save → stop
  2. Start vLLM (port 8000) with encrypted model → wait ready
     → fhenomai serve start → check model online → run tests → save
     → stop vLLM → fhenomai serve stop → check model offline
  3. Generate HTML comparison report

Design rationale: large models cannot fit two vLLM instances in GPU VRAM
simultaneously.  Clear and encrypted runs execute on the same port 8000,
but at different times.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.table import Table

from dk_test_suite.config import Config
from dk_test_suite.report import generate_report
from dk_test_suite.tee_manager import TEEManager
from dk_test_suite.tests.accuracy import AccuracyTests
from dk_test_suite.tests.base import TestResult
from dk_test_suite.tests.performance import PerformanceTests
from dk_test_suite.tests.scalability import ScalabilityTests
from dk_test_suite.tests.security import SecurityTests
from dk_test_suite.tests.serving import ServingTests
from dk_test_suite.tests.training import TrainingTests
from dk_test_suite.utils import LocalHost, RemoteHost
from dk_test_suite.utils.prompts import generate_prompt_set, save_prompt_set
from dk_test_suite.vllm_manager import VLLMManager

log = logging.getLogger(__name__)
console = Console()


class TestRunner:
    """Orchestrates the full POC test suite."""

    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.output_dir = cfg.output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # SSH connections (or local subprocess when local_mode is active)
        if cfg.get("local_mode", False):
            self.gpu: RemoteHost | LocalHost = LocalHost()
            log.info("Local mode: GPU commands run as local subprocesses")
        else:
            self.gpu = RemoteHost(
                host=cfg.gpu_host,
                user=cfg["gpu_ssh_user"],
                key_path=cfg["gpu_ssh_key"],
            )

        tee_key = cfg.get("tee_ssh_key")
        self.tee_host: RemoteHost | None = None
        if tee_key:
            self.tee_host = RemoteHost(
                host=cfg.tee_host,
                user=cfg["tee_ssh_user"],
                key_path=tee_key,
            )

        # Managers
        self.vllm = VLLMManager(cfg, self.gpu)
        self.tee = TEEManager(cfg, self.gpu)

        # Test suites
        self.perf = PerformanceTests(cfg, self.vllm, self.tee)
        self.acc = AccuracyTests(cfg, self.vllm, self.tee)
        self.scale = ScalabilityTests(cfg, self.vllm, self.tee)
        self.sec = SecurityTests(cfg, self.gpu, self.tee_host)
        self.train = TrainingTests(cfg, self.gpu)
        self.serv = ServingTests(cfg, self.gpu)

        self.all_results: list[TestResult] = []

    def run(self, categories: list[str] | None = None,
            skip_clear_vllm: bool = False,
            skip_encrypted_vllm: bool = False) -> Path:
        """Execute the full test suite and generate report.

        Flow:
          1. Start vLLM clear → wait ready → run tests → save → stop vLLM
          2. Start vLLM encrypted → wait ready → fhenomai serve start →
             check model online → run tests → save → stop vLLM →
             fhenomai serve stop → check model offline
          3. Generate report
        """
        cats = set(categories or ["performance", "accuracy", "scalability", "security", "training", "serving"])
        log.info("Starting POC test suite — categories: %s", cats)
        console.print(f"\n[bold blue]FHEnom for AI — POC Test Suite[/bold blue]")
        console.print(f"Model: {self.cfg.model_name} | GPU: {self.cfg.gpu_host} | TEE: {self.cfg.tee_host}\n")

        try:
            self.gpu.connect()
            if self.tee_host:
                self.tee_host.connect()

            # Generate and persist prompt set for reproducibility
            prompts = generate_prompt_set(n=self.cfg["num_prompts"], seed=self.cfg["seed"])
            save_prompt_set(prompts, self.output_dir / "prompt_set.json")

            # ════════════════════════════════════════════════════════
            # Phase 1: Clear model — start vLLM, wait, test, save, stop
            # ════════════════════════════════════════════════════════
            if cats & {"performance", "accuracy", "scalability", "serving"}:
                console.print("[bold]Phase 1: Clear model tests (port 8000)[/bold]")

                # 1a. Start vLLM with clear model
                if not skip_clear_vllm:
                    console.print("  Starting vLLM with clear model…")
                    self.vllm.start_clear()
                    console.print("  Waiting for vLLM to be ready (checking /v1/models via SSH)…")
                    self.vllm.wait_ready()
                    console.print("  [green]vLLM ready — clear model loaded[/green]")
                else:
                    self.vllm._base = f"http://{self.cfg.gpu_host}:{self.cfg['vllm_port']}"
                    console.print("  Using existing vLLM instance (clear model)")

                # 1b. Run clear model tests
                if "performance" in cats:
                    self.perf.run_clear(prompts=prompts)
                if "accuracy" in cats:
                    self.acc.run_clear(prompts=prompts[:200])
                if "scalability" in cats:
                    self.scale.run_clear()
                if "serving" in cats:
                    console.print("  Collecting SERV clear-model reference probes…")
                    self.serv.run_clear()

                # 1c. Save clear results immediately
                for suite in [self.perf, self.acc, self.scale, self.serv]:
                    if suite.results:
                        suite.save_results(self.output_dir)

                # 1d. Stop vLLM
                if not skip_clear_vllm:
                    console.print("  Stopping vLLM (clear model)…")
                    self.vllm.stop()
                    console.print("  [green]vLLM stopped[/green]")

            # ════════════════════════════════════════════════════════
            # Phase 2: Encrypted model — start vLLM, wait, start TEE
            #          serving, check online, test, save, stop vLLM,
            #          stop TEE serving, check offline
            # ════════════════════════════════════════════════════════
            if cats & {"performance", "accuracy", "scalability", "security", "serving"}:
                console.print("\n[bold]Phase 2: Encrypted model tests (via TEE)[/bold]")

                if not skip_encrypted_vllm:
                    # 2a. Start vLLM with encrypted model
                    console.print("  Starting vLLM with encrypted model…")
                    self.vllm.start_encrypted()
                    console.print("  Waiting for vLLM to be ready (checking /v1/models via SSH)…")
                    self.vllm.wait_ready()
                    console.print("  [green]vLLM ready — encrypted model loaded[/green]")

                    # 2b. Apply getpwuid fix
                    console.print("  Applying TEE getpwuid fix…")
                    self._apply_tee_getpwuid_fix()

                    # 2c. Initialize fhenomai config
                    console.print("  Initializing fhenomai config on GPU…")
                    self._init_fhenomai_config()

                    # 2d. Start TEE serving (fhenomai serve start)
                    console.print("  Starting TEE serving (fhenomai serve start)…")
                    self._start_tee_serving()

                    # 2e. Verify model is ONLINE (fhenomai model list --show-status)
                    console.print("  Checking TEE model status (must be online)…")
                    online = self._check_tee_model_status(expected="online", timeout=300)
                    if online:
                        console.print("  [green]TEE model is ONLINE[/green]")
                    else:
                        console.print("  [yellow]TEE model status check timed out — proceeding[/yellow]")

                    # 2f. Final health probe: ensure TEE inference works
                    console.print("  Final TEE inference health probe…")
                    self._wait_tee_inference_ready(timeout=120)
                else:
                    self.vllm._base = f"http://{self.cfg.gpu_host}:{self.cfg['vllm_port']}"
                    console.print("  Using existing vLLM instance (encrypted model)")

                # 2g. Run encrypted model tests
                if "performance" in cats:
                    self.perf.run_encrypted(prompts=prompts)
                if "accuracy" in cats:
                    self.acc.run_encrypted(prompts=prompts[:200])
                if "scalability" in cats:
                    self.scale.run_encrypted()

                # Phase 3: Security tests (need encrypted deployment running)
                if "security" in cats:
                    console.print("\n[bold]Phase 3: Security validation[/bold]")
                    self.sec.run_all()

                # Phase 4: Serving workflow tests (encrypted probes)
                if "serving" in cats:
                    console.print("\n[bold]Phase 4: Encrypted serving workflow (SERV-1…SERV-7)[/bold]")
                    self.serv.run_encrypted()
                    self.serv.compare()

                # 2h. Save encrypted results
                for suite in [self.perf, self.acc, self.scale, self.sec, self.serv]:
                    if suite.results:
                        suite.save_results(self.output_dir)

                # 2i. Stop vLLM (encrypted model)
                if not skip_encrypted_vllm:
                    console.print("\n  Stopping vLLM (encrypted model)…")
                    self.vllm.stop()
                    console.print("  [green]vLLM stopped[/green]")

                    # 2j. Stop TEE serving (fhenomai serve stop)
                    console.print("  Stopping TEE serving (fhenomai serve stop)…")
                    self._stop_tee_serving()

                    # 2k. Verify model is OFFLINE
                    console.print("  Checking TEE model status (must be offline)…")
                    offline = self._check_tee_model_status(expected="offline", timeout=60)
                    if offline:
                        console.print("  [green]TEE model is OFFLINE[/green]")
                    else:
                        console.print("  [yellow]TEE model may still be online — check manually[/yellow]")

            # ── Phase 5: Training tests ─────────────────────────
            if "training" in cats:
                console.print("\n[bold]Phase 5: Training tests (Extended POC)[/bold]")
                self.train.run_all()

            # ── Compare and collect results ─────────────────────
            console.print("\n[bold]Comparing results…[/bold]")
            if "performance" in cats:
                self.all_results.extend(self.perf.compare())
            if "accuracy" in cats:
                self.all_results.extend(self.acc.compare())
            if "scalability" in cats:
                self.all_results.extend(self.scale.compare())
            if "security" in cats:
                self.all_results.extend(self.sec.results)
            if "serving" in cats:
                self.all_results.extend(self.serv.results)
            if "training" in cats:
                self.all_results.extend(self.train.compare())

            # ── Save final per-category results ─────────────────
            for suite in [self.perf, self.acc, self.scale, self.sec, self.serv, self.train]:
                if suite.results:
                    suite.save_results(self.output_dir)

            # ── Generate report ─────────────────────────────────
            console.print("\n[bold]Generating HTML report…[/bold]")

            # Collect per-prompt response data for the response viewer
            response_data = self._collect_response_data(cats)

            report_path = generate_report(
                self.all_results, self.cfg, self.output_dir,
                response_data=response_data,
            )

            # ── Print summary table ─────────────────────────────
            self._print_summary()

            console.print(f"\n[bold green]Report saved to:[/bold green] {report_path}")
            return report_path

        finally:
            # Ensure cleanup regardless of errors
            if not skip_encrypted_vllm:
                try:
                    self.vllm.stop()
                except Exception:
                    pass
                try:
                    self._stop_tee_serving()
                except Exception:
                    pass
            self.tee.close()
            self.vllm.close()
            self.serv.close()
            self.gpu.close()
            if self.tee_host:
                self.tee_host.close()

    def _print_summary(self) -> None:
        """Print a rich summary table to console."""
        table = Table(title="POC Test Results Summary")
        table.add_column("ID", style="bold")
        table.add_column("Test", style="")
        table.add_column("Result", justify="center")

        for r in self.all_results:
            if r.skipped:
                status = "[yellow]SKIP[/yellow]"
            elif r.passed:
                status = "[green]PASS[/green]"
            else:
                status = "[red]FAIL[/red]"
            table.add_row(r.test_id, r.name, status)

        console.print(table)

        passed = sum(1 for r in self.all_results if r.passed and not r.skipped)
        skipped = sum(1 for r in self.all_results if r.skipped)
        total = len(self.all_results)
        pct = passed / total * 100 if total > 0 else 0
        console.print(f"\n  {passed}/{total} tests passed, {skipped} skipped ({pct:.0f}%)")

    def _collect_response_data(self, cats: set[str]) -> list[dict]:
        """Collect per-prompt clear/encrypted response pairs for the report viewer.

        Returns a list of dicts, each with:
          category, prompt_id, prompt_text, clear_response, encrypted_response
        """
        data: list[dict] = []

        # Accuracy tests — clear_outputs / enc_outputs
        if "accuracy" in cats and self.acc.clear_outputs:
            clear_map = {r.prompt_id: r for r in self.acc.clear_outputs if r.prompt_id}
            enc_map = {r.prompt_id: r for r in self.acc.enc_outputs if r.prompt_id}
            all_ids = sorted(set(clear_map) | set(enc_map))
            for pid in all_ids:
                cr = clear_map.get(pid)
                er = enc_map.get(pid)
                data.append({
                    "category": "accuracy",
                    "prompt_id": pid,
                    "prompt_text": (cr or er).prompt_text if (cr or er) else "",
                    "clear_response": cr.output_text if cr else "",
                    "encrypted_response": er.output_text if er else "",
                })

        # Performance tests — clear_metrics / enc_metrics
        if "performance" in cats and self.perf.clear_metrics.results:
            clear_map = {r.prompt_id: r for r in self.perf.clear_metrics.results if r.prompt_id}
            enc_map = {r.prompt_id: r for r in self.perf.enc_metrics.results if r.prompt_id}
            all_ids = sorted(set(clear_map) | set(enc_map))
            for pid in all_ids:
                cr = clear_map.get(pid)
                er = enc_map.get(pid)
                data.append({
                    "category": "performance",
                    "prompt_id": pid,
                    "prompt_text": (cr or er).prompt_text if (cr or er) else "",
                    "clear_response": cr.output_text if cr else "",
                    "encrypted_response": er.output_text if er else "",
                })

        # Serving tests — _clear_outputs / _tee_outputs
        if "serving" in cats and self.serv._clear_outputs:
            clear_map = dict(self.serv._clear_outputs)
            tee_map = dict(self.serv._tee_outputs)
            from dk_test_suite.tests.serving import _PROBE_PROMPTS
            for pid, prompt, _ in _PROBE_PROMPTS:
                data.append({
                    "category": "serving",
                    "prompt_id": pid,
                    "prompt_text": prompt,
                    "clear_response": clear_map.get(pid, ""),
                    "encrypted_response": tee_map.get(pid, ""),
                })

        return data

    # ── TEE helpers ──────────────────────────────────────────────
    def _apply_tee_getpwuid_fix(self) -> None:
        """Apply the getpwuid fix so fhenomai_admin user exists inside the TEE server container."""
        if not self.tee_host:
            log.warning("No TEE SSH connection — skipping getpwuid fix")
            return
        fix_cmd = (
            'docker exec --user root fhenom_ai_server bash -c '
            '"grep -q fhenomai_admin /etc/passwd || '
            "echo 'fhenomai_admin:x:1034:1038:FHEnomAI Admin:/:/bin/false' >> /etc/passwd\""
        )
        code, out, err = self.tee_host.run(fix_cmd, check=False)
        if code == 0:
            log.info("TEE getpwuid fix applied (or already present)")
        else:
            log.warning("getpwuid fix returned exit %d: %s", code, err)

    def _init_fhenomai_config(self) -> None:
        """Initialize fhenomai CLI config on the GPU host.

        Runs: yes | fhenomai config init --tee-ip ... --admin-api-port ... etc.
        This ensures the fhenomai CLI is configured before serve start/stop.
        """
        fhenomai_venv = self.cfg.get("fhenomai_venv", "/home/gianluca.pisaturo/venv")
        gpu_home = self.cfg.get("gpu_home", "/home/gianluca.pisaturo")
        tee_host = self.cfg.tee_host
        admin_port = self.cfg["tee_admin_port"]
        user_port = self.cfg["tee_user_port"]
        admin_token = self.cfg.get("tee_admin_token", "")
        workspace = f"{gpu_home}/test_suite_models"

        auth_flag = f'--auth-token "{admin_token}" ' if admin_token else ""
        init_cmd = (
            f"export PATH={fhenomai_venv}/bin:$PATH && "
            f"export HOME={gpu_home} && "
            f"yes | fhenomai config init "
            f'--tee-ip "{tee_host}" '
            f'--admin-api-port "{admin_port}" '
            f'--user-port "{user_port}" '
            f'--workspace "{workspace}" '
            f"--use-ssl "
            f"--skip-ssl-checks "
            f"{auth_flag}"
            f"2>&1"
        )
        try:
            code, out, err = self.gpu.run(init_cmd, timeout=30, check=False)
            log.info("fhenomai config init: exit=%d  out=%s", code, (out + err)[:300])
            if code == 0:
                console.print("  [green]fhenomai config initialized[/green]")
            else:
                log.warning("fhenomai config init exit %d — may already be configured", code)
        except Exception as e:
            log.warning("fhenomai config init failed: %s — continuing", e)

    def _start_tee_serving(self) -> None:
        """Start TEE serving via fhenomai CLI.

        Runs: fhenomai serve start MODEL_ID --server-url URL --display-model-name NAME
        """
        model_id = self.cfg["encrypted_model_id"]
        vllm_port = self.cfg["vllm_port"]
        model_name = self.cfg.encrypted_model_name
        fhenomai_venv = self.cfg.get("fhenomai_venv", "/home/gianluca.pisaturo/venv")
        gpu_home = self.cfg.get("gpu_home", "/home/gianluca.pisaturo")

        # Get the GPU machine's own IP
        try:
            _, ip_out, _ = self.gpu.run("hostname -I | awk '{print $1}'", timeout=10)
            gpu_ip = ip_out.strip()
        except Exception:
            gpu_ip = self.cfg.gpu_host  # fallback to config IP
        vllm_url = f"http://{gpu_ip}:{vllm_port}"

        # Stop any existing serving session first
        stop_cmd = (
            f"export PATH={fhenomai_venv}/bin:$PATH && "
            f"export HOME={gpu_home} && "
            f"fhenomai serve stop {model_id} 2>&1 || true"
        )
        try:
            self.gpu.run(stop_cmd, timeout=30, check=False)
            log.info("Stopped any previous serving session for %s", model_id)
            time.sleep(2)
        except Exception:
            pass

        # Start serving
        serve_cmd = (
            f"export PATH={fhenomai_venv}/bin:$PATH && "
            f"export HOME={gpu_home} && "
            f"fhenomai serve start {model_id} "
            f"--server-url {vllm_url} "
            f"--display-model-name {model_name} "
            f"2>&1"
        )

        log.info("Starting TEE serving: %s → %s", model_id, vllm_url)
        try:
            code, out, err = self.gpu.run(serve_cmd, timeout=120, check=False)
            combined = (out + err).strip()
            log.info("fhenomai serve start: exit=%d  output=%s", code, combined[:500])
            if code == 0:
                console.print(f"  [green]fhenomai serve start succeeded[/green]: {combined[:200]}")
            else:
                log.warning("fhenomai serve start exit %d — trying API fallback", code)
                console.print(f"  [yellow]fhenomai CLI returned exit {code} — trying API fallback[/yellow]")
                self._start_tee_serving_api()
        except Exception as e:
            log.warning("fhenomai serve start exception: %s — trying API fallback", e)
            self._start_tee_serving_api()

    def _start_tee_serving_api(self) -> None:
        """Fallback: use direct HTTP API calls to set up TEE serving."""
        try:
            self.tee.register_model()
            log.info("Model registered via API")
        except Exception as e:
            log.warning("TEE register_model API failed: %s", e)
        try:
            self.tee.start_serving()
            log.info("TEE serving started via API")
        except Exception as e:
            log.warning("TEE start_serving API failed: %s", e)

    def _stop_tee_serving(self) -> None:
        """Stop TEE serving via fhenomai CLI.

        Runs: fhenomai serve stop MODEL_ID
        """
        model_id = self.cfg["encrypted_model_id"]
        fhenomai_venv = self.cfg.get("fhenomai_venv", "/home/gianluca.pisaturo/venv")
        gpu_home = self.cfg.get("gpu_home", "/home/gianluca.pisaturo")

        stop_cmd = (
            f"export PATH={fhenomai_venv}/bin:$PATH && "
            f"export HOME={gpu_home} && "
            f"fhenomai serve stop {model_id} 2>&1"
        )
        try:
            code, out, err = self.gpu.run(stop_cmd, timeout=30, check=False)
            combined = (out + err).strip()
            if code == 0:
                log.info("TEE serving stopped: %s", combined[:200])
                console.print(f"  [green]fhenomai serve stop succeeded[/green]")
            else:
                log.warning("fhenomai serve stop exit %d: %s", code, combined[:200])
        except Exception as e:
            log.warning("fhenomai serve stop failed: %s", e)

    def _check_tee_model_status(self, expected: str = "online", timeout: int = 300) -> bool:
        """Poll fhenomai model list --show-status --format json until the model reaches the expected state.

        Uses JSON output for robust parsing instead of grepping table text.
        Returns True if the expected state is detected within the timeout.
        """
        model_id = self.cfg["encrypted_model_id"]
        fhenomai_venv = self.cfg.get("fhenomai_venv", "/home/gianluca.pisaturo/venv")
        gpu_home = self.cfg.get("gpu_home", "/home/gianluca.pisaturo")

        status_cmd = (
            f"export PATH={fhenomai_venv}/bin:$PATH && "
            f"export HOME={gpu_home} && "
            f"fhenomai model list --show-status --show-details --format json 2>&1"
        )

        deadline = time.time() + timeout
        attempt = 0
        while time.time() < deadline:
            attempt += 1
            try:
                code, out, err = self.gpu.run(status_cmd, timeout=30, check=False)
                combined = out + err
                log.debug("TEE status check attempt %d: %s", attempt, combined[:300])

                # Parse JSON for robust status extraction
                try:
                    import json as _json
                    data = _json.loads(combined)
                    for m in data.get("models", []):
                        if m.get("encrypted_model_id") == model_id:
                            if m.get("status", "").lower() == expected.lower():
                                log.info("TEE model status '%s' confirmed (attempt %d)", expected, attempt)
                                return True
                            else:
                                log.debug("Model status is '%s', waiting for '%s'", m.get("status"), expected)
                            break
                except (ValueError, KeyError):
                    # Fallback: grep the raw text (older CLI without --format json)
                    if expected.lower() in combined.lower():
                        log.info("TEE model status '%s' confirmed via text match (attempt %d)", expected, attempt)
                        return True
            except Exception as e:
                log.debug("TEE status check attempt %d failed: %s", attempt, e)

            time.sleep(10)

        log.warning("TEE model status '%s' not confirmed after %ds", expected, timeout)
        return False

    def _wait_tee_inference_ready(self, timeout: int = 120) -> None:
        """Poll TEE completions endpoint until it returns a valid (non-error) response.

        Final safety check after fhenomai serve start + status confirmation.
        """
        import httpx as _httpx

        url = f"{self.cfg.tee_user_url}/v1/completions"
        headers = {"Authorization": f"Bearer {self.cfg['tee_user_token']}"}
        body = {
            "model": self.cfg.encrypted_model_name,
            "prompt": "test",
            "max_tokens": 1,
            "temperature": 0,
        }
        deadline = time.time() + timeout
        attempt = 0
        while time.time() < deadline:
            attempt += 1
            try:
                r = _httpx.post(url, json=body, headers=headers, verify=False, timeout=20)
                data = r.json()
                choices = data.get("choices", [])
                if choices and choices[0].get("finish_reason") != "error":
                    console.print(f"  [green]TEE inference ready[/green] (attempt {attempt})")
                    log.info("TEE inference ready after %d attempts", attempt)
                    return
                err_text = choices[0].get("text", "") if choices else str(data)
                log.debug("TEE inference not ready (attempt %d): %s", attempt, err_text[:200])
            except Exception as e:
                log.debug("TEE inference probe attempt %d: %s", attempt, e)
            time.sleep(10)
        log.warning("TEE inference readiness timeout (%ds) — proceeding anyway", timeout)
        console.print(f"  [yellow]TEE inference readiness timeout ({timeout}s) — proceeding[/yellow]")
