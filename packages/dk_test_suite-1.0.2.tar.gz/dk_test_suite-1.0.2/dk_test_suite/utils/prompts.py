"""Prompt-set management for benchmarks."""

from __future__ import annotations

import hashlib
import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Prompt:
    """A single test prompt with optional metadata."""
    text: str
    id: str = ""
    category: str = "general"
    expected_max_tokens: int = 256
    metadata: dict[str, Any] = field(default_factory=dict)


# ── Built-in prompt sets ────────────────────────────────────────

_DOMAIN_PROMPTS: list[dict[str, str]] = [
    {"text": "Explain the difference between physical vapor deposition and chemical vapor deposition in semiconductor manufacturing.", "category": "domain"},
    {"text": "What are the key parameters that affect etch uniformity in plasma etching?", "category": "domain"},
    {"text": "Describe the role of atomic layer deposition in advanced node fabrication.", "category": "domain"},
    {"text": "What quality control measures are typically used in wafer inspection?", "category": "domain"},
    {"text": "Explain how thermal management impacts chip reliability.", "category": "domain"},
    {"text": "What is the purpose of chemical mechanical planarization in semiconductor processing?", "category": "domain"},
    {"text": "Describe the advantages of EUV lithography over DUV lithography.", "category": "domain"},
    {"text": "What factors influence the selection of dielectric materials in interconnects?", "category": "domain"},
    {"text": "Explain step coverage requirements in thin film deposition.", "category": "domain"},
    {"text": "What are the main challenges of scaling transistor gate length below 5nm?", "category": "domain"},
]

_GENERAL_PROMPTS: list[dict[str, str]] = [
    {"text": "Write a Python function to compute the Fibonacci sequence iteratively.", "category": "coding"},
    {"text": "Summarize the key principles of thermodynamics in three sentences.", "category": "science"},
    {"text": "What are the advantages and disadvantages of microservices architecture?", "category": "engineering"},
    {"text": "Explain the CAP theorem and its implications for distributed databases.", "category": "engineering"},
    {"text": "Translate the following to French: 'The meeting has been rescheduled to next Thursday.'", "category": "translation"},
    {"text": "What are the primary causes of supply chain disruptions in manufacturing?", "category": "business"},
    {"text": "Describe three methods for anomaly detection in time-series data.", "category": "data_science"},
    {"text": "Write a SQL query to find the top 5 customers by revenue in the last quarter.", "category": "coding"},
    {"text": "Explain the difference between supervised and unsupervised learning.", "category": "ml"},
    {"text": "What safety precautions should be taken when handling hydrofluoric acid?", "category": "safety"},
]


def generate_prompt_set(n: int = 1000, seed: int = 42,
                        max_tokens: int = 256) -> list[Prompt]:
    """Generate a deterministic prompt set of size *n* by cycling built-ins."""
    rng = random.Random(seed)
    pool = _DOMAIN_PROMPTS + _GENERAL_PROMPTS
    prompts: list[Prompt] = []
    for i in range(n):
        template = pool[i % len(pool)]
        # Add a unique suffix for prompts beyond the pool size
        suffix = f" (variation {i // len(pool)})" if i >= len(pool) else ""
        text = template["text"] + suffix
        prompt_id = hashlib.md5(text.encode()).hexdigest()[:12]
        prompts.append(Prompt(
            text=text,
            id=prompt_id,
            category=template["category"],
            expected_max_tokens=max_tokens,
        ))
    rng.shuffle(prompts)
    return prompts


def load_prompt_set(path: str | Path) -> list[Prompt]:
    """Load prompts from a JSON file. Expected format: list of {text, category?}."""
    with open(path) as f:
        data = json.load(f)
    prompts: list[Prompt] = []
    for i, item in enumerate(data):
        if isinstance(item, str):
            item = {"text": item}
        prompts.append(Prompt(
            text=item["text"],
            id=item.get("id", f"custom-{i}"),
            category=item.get("category", "custom"),
            expected_max_tokens=item.get("max_tokens", 256),
        ))
    return prompts


def save_prompt_set(prompts: list[Prompt], path: str | Path) -> None:
    """Persist prompt set to JSON."""
    data = [{"text": p.text, "id": p.id, "category": p.category,
             "expected_max_tokens": p.expected_max_tokens} for p in prompts]
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
