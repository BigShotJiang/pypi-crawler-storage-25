"""Metric computation helpers."""

from __future__ import annotations

import math
import statistics
from dataclasses import dataclass, field
from typing import Any


@dataclass
class InferenceResult:
    """Result of a single inference call."""
    prompt_id: str
    prompt_text: str
    output_text: str
    output_tokens: list[int] | None = None
    time_to_first_token_ms: float = 0.0
    total_time_ms: float = 0.0
    tokens_generated: int = 0
    logprobs: list[float] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def tokens_per_second(self) -> float:
        if self.total_time_ms <= 0 or self.tokens_generated <= 0:
            return 0.0
        return self.tokens_generated / (self.total_time_ms / 1000.0)


@dataclass
class BenchmarkMetrics:
    """Aggregated metrics from a benchmark run."""
    test_id: str
    model_type: str  # "clear" or "encrypted"
    results: list[InferenceResult] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)

    # ── Computed properties ─────────────────────────────────────
    @property
    def count(self) -> int:
        return len(self.results)

    @property
    def avg_ttft_ms(self) -> float:
        vals = [r.time_to_first_token_ms for r in self.results if r.time_to_first_token_ms > 0]
        return statistics.mean(vals) if vals else 0.0

    @property
    def p50_ttft_ms(self) -> float:
        vals = sorted(r.time_to_first_token_ms for r in self.results if r.time_to_first_token_ms > 0)
        return _percentile(vals, 50)

    @property
    def p99_ttft_ms(self) -> float:
        vals = sorted(r.time_to_first_token_ms for r in self.results if r.time_to_first_token_ms > 0)
        return _percentile(vals, 99)

    @property
    def avg_total_time_ms(self) -> float:
        vals = [r.total_time_ms for r in self.results if r.total_time_ms > 0]
        return statistics.mean(vals) if vals else 0.0

    @property
    def avg_tokens_per_sec(self) -> float:
        vals = [r.tokens_per_second for r in self.results if r.tokens_per_second > 0]
        return statistics.mean(vals) if vals else 0.0

    @property
    def total_tokens(self) -> int:
        return sum(r.tokens_generated for r in self.results)

    @property
    def sustained_throughput(self) -> float:
        """Total tokens / total wall time in seconds."""
        total_time = sum(r.total_time_ms for r in self.results)
        if total_time <= 0:
            return 0.0
        return self.total_tokens / (total_time / 1000.0)

    @property
    def avg_perplexity(self) -> float:
        """Average perplexity across results that have logprobs."""
        perplexities = []
        for r in self.results:
            if r.logprobs:
                avg_nll = -statistics.mean(r.logprobs)
                perplexities.append(math.exp(avg_nll))
        return statistics.mean(perplexities) if perplexities else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "test_id": self.test_id,
            "model_type": self.model_type,
            "count": self.count,
            "avg_ttft_ms": round(self.avg_ttft_ms, 2),
            "p50_ttft_ms": round(self.p50_ttft_ms, 2),
            "p99_ttft_ms": round(self.p99_ttft_ms, 2),
            "avg_total_time_ms": round(self.avg_total_time_ms, 2),
            "avg_tokens_per_sec": round(self.avg_tokens_per_sec, 2),
            "sustained_throughput": round(self.sustained_throughput, 2),
            "total_tokens": self.total_tokens,
            "avg_perplexity": round(self.avg_perplexity, 4),
            "extra": self.extra,
        }


def _percentile(sorted_vals: list[float], pct: float) -> float:
    if not sorted_vals:
        return 0.0
    k = (len(sorted_vals) - 1) * pct / 100.0
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_vals[int(k)]
    return sorted_vals[f] * (c - k) + sorted_vals[c] * (k - f)


def compare_metrics(clear: BenchmarkMetrics, encrypted: BenchmarkMetrics,
                    thresholds: dict[str, float]) -> dict[str, Any]:
    """Compare clear vs encrypted metrics and return pass/fail per criterion."""
    results: dict[str, Any] = {}

    # TTFT comparison
    if clear.avg_ttft_ms > 0:
        ttft_diff_pct = abs(encrypted.avg_ttft_ms - clear.avg_ttft_ms) / clear.avg_ttft_ms * 100
        results["ttft_diff_pct"] = round(ttft_diff_pct, 2)
        results["ttft_pass"] = ttft_diff_pct <= thresholds.get("ttft_tolerance_pct", 5.0)

    # Throughput comparison
    if clear.avg_tokens_per_sec > 0:
        tp_diff_pct = abs(encrypted.avg_tokens_per_sec - clear.avg_tokens_per_sec) / clear.avg_tokens_per_sec * 100
        results["throughput_diff_pct"] = round(tp_diff_pct, 2)
        results["throughput_pass"] = tp_diff_pct <= thresholds.get("throughput_tolerance_pct", 5.0)

    # E2E latency comparison
    if clear.avg_total_time_ms > 0:
        e2e_diff_pct = abs(encrypted.avg_total_time_ms - clear.avg_total_time_ms) / clear.avg_total_time_ms * 100
        results["e2e_latency_diff_pct"] = round(e2e_diff_pct, 2)
        results["e2e_latency_pass"] = e2e_diff_pct <= thresholds.get("e2e_latency_overhead_pct", 1.0)

    # Perplexity comparison
    if clear.avg_perplexity > 0 and encrypted.avg_perplexity > 0:
        ppl_diff_pct = abs(encrypted.avg_perplexity - clear.avg_perplexity) / clear.avg_perplexity * 100
        results["perplexity_diff_pct"] = round(ppl_diff_pct, 4)
        results["perplexity_pass"] = ppl_diff_pct <= thresholds.get("perplexity_tolerance_pct", 0.1)

    return results
