"""SSH / remote-execution helpers wrapping paramiko."""

from __future__ import annotations

import io
import logging
import time
from pathlib import Path
from typing import Any

import paramiko

log = logging.getLogger(__name__)


class RemoteHost:
    """Persistent SSH connection to a remote machine."""

    def __init__(self, host: str, user: str, key_path: str,
                 port: int = 22, timeout: int = 30) -> None:
        self.host = host
        self.user = user
        self.key_path = key_path
        self._client: paramiko.SSHClient | None = None
        self.port = port
        self.timeout = timeout

    # ── Connection management ───────────────────────────────────
    def connect(self) -> None:
        if self._client is not None:
            return
        self._client = paramiko.SSHClient()
        self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self._client.connect(
            hostname=self.host,
            username=self.user,
            key_filename=self.key_path,
            port=self.port,
            timeout=self.timeout,
        )
        log.info("SSH connected to %s@%s", self.user, self.host)

    def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self) -> "RemoteHost":
        self.connect()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # ── Execution ───────────────────────────────────────────────
    def run(self, cmd: str, timeout: int = 300, check: bool = True) -> tuple[int, str, str]:
        """Execute *cmd* and return (exit_code, stdout, stderr)."""
        self.connect()
        assert self._client is not None
        log.debug("[%s] %s", self.host, cmd)
        _, stdout_ch, stderr_ch = self._client.exec_command(cmd, timeout=timeout)
        exit_code = stdout_ch.channel.recv_exit_status()
        stdout = stdout_ch.read().decode(errors="replace")
        stderr = stderr_ch.read().decode(errors="replace")
        if check and exit_code != 0:
            raise RuntimeError(
                f"Command failed on {self.host} (exit {exit_code}):\n"
                f"  cmd: {cmd}\n  stderr: {stderr[:2000]}"
            )
        return exit_code, stdout, stderr

    def run_bg(self, cmd: str) -> None:
        """Launch *cmd* in the background (nohup + disown)."""
        self.connect()
        assert self._client is not None
        transport = self._client.get_transport()
        assert transport is not None
        channel = transport.open_session()
        channel.exec_command(f"nohup {cmd} </dev/null >/dev/null 2>&1 &")
        channel.close()

    # ── File operations ─────────────────────────────────────────
    def get_file_size(self, remote_path: str) -> int:
        """Return file size in bytes."""
        _, out, _ = self.run(f"stat -c%s {remote_path}")
        return int(out.strip())

    def read_file(self, remote_path: str) -> str:
        _, out, _ = self.run(f"cat {remote_path}")
        return out

    def file_exists(self, remote_path: str) -> bool:
        code, _, _ = self.run(f"test -e {remote_path}", check=False)
        return code == 0

    def dir_size_bytes(self, remote_path: str, exclude: str | None = None) -> int:
        """Total size of directory in bytes, optionally excluding a subdirectory."""
        if exclude:
            _, out, _ = self.run(f"du -sb --exclude='{exclude}' {remote_path} | cut -f1")
        else:
            _, out, _ = self.run(f"du -sb {remote_path} | cut -f1")
        return int(out.strip())

    # ── Docker helpers ──────────────────────────────────────────
    def docker_run(self, image: str, name: str, extra_args: str = "",
                   cmd: str = "", detach: bool = True) -> str:
        """Run a docker container and return stdout (container ID if detached)."""
        d_flag = "-d" if detach else ""
        full_cmd = f"docker run {d_flag} --name {name} {extra_args} {image} {cmd}"
        _, out, _ = self.run(full_cmd, timeout=120)
        return out.strip()

    def docker_stop(self, name: str, remove: bool = True) -> None:
        self.run(f"docker stop {name} 2>/dev/null || true", check=False)
        if remove:
            self.run(f"docker rm -f {name} 2>/dev/null || true", check=False)

    def docker_logs(self, name: str, tail: int = 50) -> str:
        _, out, _ = self.run(f"docker logs {name} --tail {tail} 2>&1", check=False)
        return out

    def docker_exec(self, name: str, cmd: str) -> tuple[int, str, str]:
        return self.run(f"docker exec {name} {cmd}", check=False)


class LocalHost(RemoteHost):
    """Execute commands on the local machine using subprocess.

    Drop-in replacement for :class:`RemoteHost` when the test suite is run
    directly on the GPU machine — no SSH key or connection required.
    All methods that ultimately call :meth:`run` (file helpers, docker helpers,
    etc.) are inherited unchanged and work transparently.
    """

    def __init__(self) -> None:  # noqa: D107
        # Bypass RemoteHost.__init__ — no SSH parameters needed.
        self.host = "localhost"
        self.user = ""
        self.key_path = ""
        self._client = None
        self.port = 0
        self.timeout = 0

    # ── No-op connection management ─────────────────────────────
    def connect(self) -> None:  # noqa: D102
        pass

    def close(self) -> None:  # noqa: D102
        pass

    # ── Local execution ─────────────────────────────────────────
    def run(self, cmd: str, timeout: int = 300,  # noqa: D102
            check: bool = True) -> tuple[int, str, str]:
        """Execute *cmd* locally and return (exit_code, stdout, stderr)."""
        import subprocess as _sp
        log.debug("[local] %s", cmd)
        try:
            result = _sp.run(
                cmd, shell=True, capture_output=True, text=True, timeout=timeout
            )
        except _sp.TimeoutExpired as exc:
            raise TimeoutError(f"Local command timed out after {timeout}s: {cmd}") from exc
        if check and result.returncode != 0:
            raise RuntimeError(
                f"Command failed locally (exit {result.returncode}):\n"
                f"  cmd: {cmd}\n  stderr: {result.stderr[:2000]}"
            )
        return result.returncode, result.stdout, result.stderr

    def run_bg(self, cmd: str) -> None:  # noqa: D102
        """Launch *cmd* locally in the background."""
        import subprocess as _sp
        _sp.Popen(
            f"nohup {cmd} </dev/null >/dev/null 2>&1 &",
            shell=True,
            start_new_session=True,
        )
