"""HTML report generator — DataKrypto-styled side-by-side comparison of clear vs encrypted."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Template

from dk_test_suite.config import Config
from dk_test_suite.tests.base import TestResult

log = logging.getLogger(__name__)

# ── Jinja2 HTML template ── DataKrypto design system ──────────────────────────
_HTML_TEMPLATE = Template("""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FHEnom for AI™ — POC Test Report</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  /* ── DataKrypto Design System ──────────────── */
  :root {
    --bg:          #1A1C1D;
    --surface:     #222527;
    --surface-alt: #292D2E;
    --border:      #363B3C;
    --accent:      #DF2B3B;
    --accent-dim:  #B91C1C;
    --success:     #00D084;
    --warning:     #F59E0B;
    --error:       #EF4444;
    --text:        #FFFFFF;
    --text-sec:    #94A3B8;
    --text-muted:  #52525B;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: var(--bg);
    color: var(--text);
    font-size: 14px;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
  }

  /* ── Layout ── */
  .page-wrap { max-width: 1280px; margin: 0 auto; padding: 0 32px 64px; }

  /* ── Top bar ── */
  .topbar {
    background: var(--bg);
    border-bottom: 1px solid var(--border);
    padding: 0 32px;
    height: 64px;
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 48px;
  }
  .topbar-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
  }
  .logo-mark {
    width: 32px; height: 32px;
    background: var(--accent);
    border-radius: 4px;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 14px; color: white; letter-spacing: -1px;
  }
  .topbar-brand { font-weight: 700; font-size: 15px; color: var(--text); letter-spacing: 0.3px; }
  .topbar-div { width: 1px; height: 28px; background: var(--border); }
  .topbar-label {
    font-size: 11px; font-weight: 600; color: var(--text-sec);
    text-transform: uppercase; letter-spacing: 1.2px;
  }
  .topbar-spacer { flex: 1; }
  .topbar-badge {
    font-size: 11px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase;
    padding: 4px 12px; border-radius: 4px;
    border: 1px solid var(--border); color: var(--text-sec);
  }

  /* ── Hero ── */
  .hero { margin-bottom: 40px; }
  .dk-label {
    font-size: 11px; font-weight: 600; color: var(--accent);
    text-transform: uppercase; letter-spacing: 1.4px; margin-bottom: 8px;
  }
  .hero h1 {
    font-size: 28px; font-weight: 700; color: var(--text);
    line-height: 1.2; margin-bottom: 8px;
  }
  .hero-meta {
    font-size: 13px; color: var(--text-sec);
    display: flex; flex-wrap: wrap; gap: 4px 20px; margin-bottom: 4px;
  }
  .hero-meta span { white-space: nowrap; }
  .hero-meta strong { color: var(--text); font-weight: 500; }

  /* ── Summary cards ── */
  .summary-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-bottom: 48px;
  }
  @media (max-width: 768px) { .summary-grid { grid-template-columns: repeat(2,1fr); } }
  .summary-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 20px 24px;
    position: relative;
  }
  .summary-card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 2px;
    border-radius: 4px 4px 0 0;
    background: var(--border);
  }
  .summary-card.accent::before { background: var(--accent); }
  .summary-card.success::before { background: var(--success); }
  .summary-card.error::before   { background: var(--error); }
  .summary-card .card-label {
    font-size: 11px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.2px; color: var(--text-sec); margin-bottom: 10px;
  }
  .summary-card .card-num {
    font-size: 36px; font-weight: 700; line-height: 1;
    color: var(--text);
  }
  .summary-card.success .card-num { color: var(--success); }
  .summary-card.error   .card-num { color: var(--error); }

  /* ── Section header ── */
  .section-header {
    display: flex; align-items: flex-end; gap: 12px;
    margin: 40px 0 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--border);
  }
  .section-header h2 {
    font-size: 16px; font-weight: 600; color: var(--text); flex: 1;
  }
  .section-tag {
    font-size: 11px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.2px; color: var(--text-muted);
  }
  .pass-count {
    font-size: 12px; font-weight: 600; color: var(--success);
    padding: 2px 10px; border-radius: 4px;
    background: rgba(0,208,132,0.10); border: 1px solid rgba(0,208,132,0.25);
  }
  .fail-count {
    font-size: 12px; font-weight: 600; color: var(--error);
    padding: 2px 10px; border-radius: 4px;
    background: rgba(239,68,68,0.10); border: 1px solid rgba(239,68,68,0.25);
  }

  /* ── Table ── */
  .table-wrap {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 8px;
  }
  table { width: 100%; border-collapse: collapse; }
  thead tr { background: var(--surface-alt); }
  th {
    padding: 10px 16px;
    font-size: 11px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.1px; color: var(--text-sec);
    text-align: left; border-bottom: 1px solid var(--border);
    white-space: nowrap;
  }
  td {
    padding: 12px 16px;
    font-size: 13px; color: var(--text-sec);
    border-bottom: 1px solid var(--border);
    vertical-align: top;
  }
  tbody tr:last-child td { border-bottom: none; }
  tbody tr:hover td { background: rgba(223,43,59,0.04); }
  td.id-cell { font-weight: 700; color: var(--text); font-size: 12px; white-space: nowrap; }
  td.name-cell { color: var(--text); font-weight: 500; }
  td.mono { font-family: 'Courier New', monospace; font-size: 12px; }
  td.diff-cell { font-weight: 600; font-family: 'Courier New', monospace; font-size: 12px; }
  td.diff-pos { color: var(--success); }
  td.diff-neg { color: var(--error); }
  td.diff-neu { color: var(--text-sec); }

  /* ── Badges ── */
  .badge {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 3px 10px; border-radius: 4px;
    font-size: 11px; font-weight: 700; letter-spacing: 1px;
    text-transform: uppercase; white-space: nowrap;
  }
  .badge::before { content: ''; width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
  .badge-pass {
    background: rgba(0,208,132,0.12); color: var(--success);
    border: 1px solid rgba(0,208,132,0.30);
  }
  .badge-pass::before { background: var(--success); }
  .badge-fail {
    background: rgba(239,68,68,0.12); color: var(--error);
    border: 1px solid rgba(239,68,68,0.30);
  }
  .badge-fail::before { background: var(--error); }

  /* ── Details toggle ── */
  .details-btn {
    cursor: pointer; color: var(--accent); font-size: 12px; font-weight: 600;
    letter-spacing: 0.5px;
    background: none; border: none; padding: 0;
    display: flex; align-items: center; gap: 4px;
    user-select: none;
  }
  .details-btn:hover { color: var(--accent-dim); }
  .details-arrow { transition: transform 0.2s ease; display: inline-block; }
  .details-btn.open .details-arrow { transform: rotate(90deg); }
  .details-content {
    display: none;
    margin-top: 8px;
    padding: 12px;
    background: var(--surface-alt);
    border: 1px solid var(--border);
    border-radius: 4px;
    font-size: 12px; font-family: 'Courier New', monospace;
    white-space: pre-wrap; word-break: break-word;
    color: var(--text-sec);
    line-height: 1.5;
    max-height: 400px; overflow-y: auto;
  }
  .details-content.open { display: block; }

  /* ── Category description ── */
  .category-desc {
    font-size: 13px; color: var(--text-sec); line-height: 1.75;
    margin-bottom: 16px;
    padding: 14px 18px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-left: 3px solid var(--accent);
    border-radius: 0 4px 4px 0;
  }
  .category-desc strong { color: var(--text); font-weight: 500; }
  .category-methodology {
    display: flex; flex-wrap: wrap; gap: 6px 16px;
    margin-top: 8px;
  }
  .method-chip {
    font-size: 11px; font-weight: 600; letter-spacing: 0.8px;
    text-transform: uppercase; color: var(--text-muted);
    padding: 2px 8px;
    border: 1px solid var(--border);
    border-radius: 3px;
    background: var(--surface-alt);
  }

  /* ── Test description (subtitle under test name) ── */
  .test-desc {
    font-size: 11px; color: var(--text-muted); font-weight: 400;
    margin-top: 3px; line-height: 1.45; max-width: 480px;
  }

  /* ── Config block ── */
  .config-section { margin-top: 48px; }
  .config-block {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 20px 24px;
    font-family: 'Courier New', monospace;
    font-size: 12px;
    white-space: pre-wrap;
    overflow-x: auto;
    color: var(--text-sec);
    line-height: 1.7;
    max-height: 400px;
    overflow-y: auto;
  }

  /* ── Pipeline diagram ── */
  .pipeline {
    display: flex; align-items: center; gap: 0;
    flex-wrap: wrap; margin: 16px 0 24px;
  }
  .pip-node {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 8px 14px;
    font-size: 12px; font-weight: 600; color: var(--text-sec);
    white-space: nowrap;
  }
  .pip-node.accent { border-color: var(--accent); color: var(--accent); }
  .pip-node.success { border-color: var(--success); color: var(--success); }
  .pip-arrow {
    font-size: 16px; color: var(--text-muted); padding: 0 6px;
    flex-shrink: 0;
  }

  /* ── Footer ── */
  footer {
    margin-top: 64px;
    padding-top: 20px;
    border-top: 1px solid var(--border);
    display: flex; justify-content: space-between; align-items: center;
    flex-wrap: wrap; gap: 8px;
  }
  footer .footer-brand {
    font-size: 12px; font-weight: 700; color: var(--text-sec); letter-spacing: 0.5px;
  }
  footer .footer-meta { font-size: 11px; color: var(--text-muted); }
  footer .footer-conf {
    font-size: 11px; font-weight: 600; color: var(--accent);
    text-transform: uppercase; letter-spacing: 1px;
    padding: 3px 10px; border: 1px solid rgba(223,43,59,0.4);
    border-radius: 4px;
  }
</style>
<script>
function toggleDetails(id) {
  var content = document.getElementById('det-' + id);
  var btn = document.getElementById('btn-' + id);
  content.classList.toggle('open');
  btn.classList.toggle('open');
}
function _diffClass(val) {
  if (typeof val !== 'string' || val === '—') return 'diff-neu';
  var n = parseFloat(val);
  if (isNaN(n)) return 'diff-neu';
  if (n > 0) return 'diff-pos';
  if (n < 0) return 'diff-neg';
  return 'diff-neu';
}
</script>
</head>
<body>

<!-- Top bar -->
<div class="topbar">
  <div class="topbar-logo">
    <div class="logo-mark">DK</div>
    <span class="topbar-brand">DataKrypto — FHEnom for AI™</span>
  </div>
  <div class="topbar-div"></div>
  <span class="topbar-label">POC Validation Report</span>
  <div class="topbar-spacer"></div>
  <span class="topbar-badge">{{ poc_id }}</span>
</div>

<div class="page-wrap">

<!-- Hero -->
<div class="hero">
  <div class="dk-label">Head-to-Head Test Report</div>
  <h1>FHEnom for AI™ — POC Validation Results</h1>
  <div class="hero-meta">
    <span><strong>Customer:</strong> {{ customer }}</span>
    <span><strong>Model:</strong> {{ model_name }}</span>
    <span><strong>Generated:</strong> {{ timestamp }}</span>
    <span><strong>Suite Version:</strong> v{{ version }}</span>
  </div>
</div>

<!-- Architecture pipeline -->
<div class="pipeline">
  <div class="pip-node">User Request</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node accent">TEE:9999</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node">FHE Decrypt</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node success">vLLM:8000 (Encrypted)</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node">TEE</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node">Response</div>
</div>

<!-- Summary cards -->
<div class="summary-grid">
  <div class="summary-card accent">
    <div class="card-label">Total Tests</div>
    <div class="card-num">{{ total_tests }}</div>
  </div>
  <div class="summary-card success">
    <div class="card-label">Passed</div>
    <div class="card-num">{{ passed_tests }}</div>
  </div>
  <div class="summary-card{% if failed_tests > 0 %} error{% endif %}">
    <div class="card-label">Failed</div>
    <div class="card-num">{{ failed_tests }}</div>
  </div>
  <div class="summary-card{% if pass_rate >= 100 %} success{% endif %}">
    <div class="card-label">Pass Rate</div>
    <div class="card-num">{{ pass_rate }}%</div>
  </div>
</div>

{% for category, tests in categories.items() %}
{% set cat_passed = tests | selectattr("passed", "equalto", true) | list | length %}
{% set cat_failed = tests | length - cat_passed %}

<div class="section-header">
  <h2>{{ category_labels[category] }}</h2>
  <span class="section-tag">{{ tests | length }} test{{ 's' if tests | length != 1 else '' }}</span>
  {% if cat_failed == 0 %}
  <span class="pass-count">{{ cat_passed }}/{{ tests | length }} Pass</span>
  {% else %}
  <span class="fail-count">{{ cat_failed }} Failed</span>
  {% endif %}
</div>

{% if category_descriptions[category] %}
<div class="category-desc">{{ category_descriptions[category] | safe }}</div>
{% endif %}

<div class="table-wrap">
<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Test Name</th>
      <th>Clear Model</th>
      <th>Encrypted</th>
      <th>Difference</th>
      <th>Threshold</th>
      <th>Result</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
  {% for t in tests %}
    <tr>
      <td class="id-cell">{{ t.test_id }}</td>
      <td class="name-cell">{{ t.name }}
        {% if test_descriptions[t.test_id] %}
        <div class="test-desc">{{ test_descriptions[t.test_id] }}</div>
        {% endif %}
      </td>
      <td class="mono">{{ t.clear_value if t.clear_value is not none else '—' }}</td>
      <td class="mono">{{ t.encrypted_value if t.encrypted_value is not none else '—' }}</td>
      <td class="diff-cell diff-neu">{{ t.diff_value if t.diff_value is not none else '—' }}</td>
      <td style="color:var(--text-muted); font-size:12px;">{{ t.threshold if t.threshold else '—' }}</td>
      <td>
        <span class="badge {{ 'badge-pass' if t.passed else 'badge-fail' }}">
          {{ 'Pass' if t.passed else 'Fail' }}
        </span>
      </td>
      <td>
        {% if t.details %}
        <button id="btn-{{ t.test_id }}" class="details-btn" onclick="toggleDetails('{{ t.test_id }}')">
          <span class="details-arrow">▶</span> Details
        </button>
        <div id="det-{{ t.test_id }}" class="details-content">{{ t.details }}</div>
        {% endif %}
      </td>
    </tr>
  {% endfor %}
  </tbody>
</table>
</div>
{% endfor %}

<!-- Config -->
<div class="config-section">
  <div class="section-header">
    <h2>Test Configuration</h2>
    <span class="section-tag">config/default.yaml</span>
  </div>
  <div class="config-block">{{ config_yaml }}</div>
</div>

</div><!-- /page-wrap -->

<footer>
  <span class="footer-brand">DataKrypto — FHEnom for AI™</span>
  <span class="footer-meta">Generated by dk-test-suite v{{ version }} · {{ timestamp }}</span>
  <span class="footer-conf">Confidential</span>
</footer>

</body>
</html>
""")

_CATEGORY_LABELS = {
    "performance": "Performance Metrics (PERF-1 — PERF-5)",
    "accuracy": "Accuracy Metrics (ACC-1 — ACC-5)",
    "scalability": "Scalability Metrics (SCALE-1 — SCALE-4)",
    "security": "Security Validation (SEC-1 — SEC-6)",
    "serving": "Encrypted Serving Workflow (SERV-1 — SERV-7)",
    "training": "Training Metrics (T-1 — T-3)",
}

# ── Category-level descriptions rendered above each result table ──────────────
_CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "performance": (
        "Each metric is captured independently on the <strong>clear model</strong> (plaintext vLLM, port 8000) "
        "and the <strong>encrypted model</strong> (FHEnom TEE proxy → encrypted vLLM, port 9999), "
        "then compared. The difference column shows the encrypted value minus the clear value — positive means "
        "the encrypted path is slower/larger, negative means faster/smaller. "
        "<strong>No pass/fail threshold is applied</strong>: all results are informational baselines."
    ),
    "accuracy": (
        "Standard LLM benchmarks and semantic-similarity metrics are run on identical prompt sets against both "
        "the clear and encrypted model. The goal is to confirm that FHEnom's encryption layer does "
        "<em>not</em> alter model behaviour — the decryption pipeline inside the TEE must reproduce the "
        "original weights bit-for-bit. <strong>No pass/fail threshold is applied</strong>: "
        "any divergence from 0% accuracy delta is flagged in the details panel."
    ),
    "scalability": (
        "The encrypted serving stack is stressed along four independent axes: "
        "<strong>concurrency</strong> (1–50 simultaneous users), "
        "<strong>context length</strong> (512–8 192 tokens), "
        "<strong>batch size</strong> (1–32), and "
        "<strong>sustained operation</strong> (24-hour endurance). "
        "Results quantify how throughput and latency degrade (or hold) under load, "
        "relative to the clear-model baseline at the same concurrency level."
    ),
    "security": (
        "Six independent checks verify that FHEnom enforces end-to-end secrecy of the model weights: "
        "ciphertext-only storage on disk, ciphertext-only execution in GPU VRAM, "
        "TLS-enforced transport with plaintext rejection, cryptographic model binding in the TEE, "
        "per-tenant key isolation, and sanitised container logs. "
        "Each test attempts the relevant attack or inspection technique; a <strong>PASS</strong> means "
        "no sensitive material was observable."
    ),
    "serving": (
        "End-to-end workflow validation of the complete FHEnom serving stack — "
        "from encrypted model file integrity through TEE proxy startup to output fidelity and latency overhead. "
        "The seven tests cover: file hash verification, vLLM health, TEE status, inference coherence, "
        "bypass-attempt (encryption reality proof), output quality parity, and per-token FHE crypto overhead. "
        "All seven must <strong>PASS</strong> for the POC to be considered successful."
    ),
    "training": (
        "LoRA fine-tuning is executed on both the clear and the FHEnom-encrypted model using the same dataset "
        "and hyper-parameters. The three tests verify that: the training loss converges within budget, "
        "the saved adapter checkpoint passes FHEnom signature verification, and the fine-tuned encrypted model "
        "achieves accuracy within the configured tolerance of the clear fine-tuned model. "
        "This confirms FHEnom supports full supervised fine-tuning workflows without weight exposure."
    ),
}

# ── Per-test descriptions rendered as subtitles in the test-name column ───────
_TEST_DESCRIPTIONS: dict[str, str] = {
    # Performance
    "PERF-1": "Time to first token (TTFT) — latency from request submission to the first generated token.",
    "PERF-2": "Throughput — sustained output tokens per second over the full benchmark prompt set.",
    "PERF-3": "End-to-end latency — total wall-clock time per request incl. FHE enc/dec overhead.",
    "PERF-4": "Model footprint — encrypted vs. clear model size on disk.",
    "PERF-5": "VRAM utilisation — GPU memory used by the encrypted and clear vLLM instances.",
    # Accuracy
    "ACC-1": "MMLU — 57-subject multiple-choice evaluation of broad world knowledge and reasoning.",
    "ACC-2": "HellaSwag — sentence-completion task measuring commonsense natural-language inference.",
    "ACC-3": "GSM8K — grade-school math word problems requiring multi-step arithmetic reasoning.",
    "ACC-4": "HumanEval — Python code generation correctness measured by pass@1.",
    "ACC-5": "Output similarity — BERTScore F1 between encrypted and clear model responses on the same prompts.",
    # Scalability
    "SCALE-1": "Concurrent users — throughput and latency at 1 / 5 / 10 / 20 / 50 simultaneous requests.",
    "SCALE-2": "Context length — performance sweep over prompts of 512 / 1K / 2K / 4K / 8K tokens.",
    "SCALE-3": "Batch size — throughput scaling for batch sizes 1 / 4 / 8 / 16 / 32.",
    "SCALE-4": "Sustained operation — 24-hour continuous load test measuring stability and error rate.",
    # Security
    "SEC-1": "Encryption at rest — model weights stored as FHE ciphertext on disk; no plaintext .safetensors accessible.",
    "SEC-2": "Encrypted execution — VRAM contains only ciphertext during inference; no plaintext weight pages observable.",
    "SEC-3": "Secure transport — all client traffic must use TLS; plaintext requests are rejected at the TEE boundary.",
    "SEC-4": "Model binding — TEE refuses to serve a model whose cryptographic signature does not match the registered ID.",
    "SEC-5": "Key isolation — tenant decryption keys are scoped per model ID; cross-model reuse returns an error.",
    "SEC-6": "Logging safety — no token, weight, or key material appears in any accessible container log.",
    # Serving
    "SERV-1": "Encrypted model file integrity — SHA-256 of the encrypted weights must match the registered digest.",
    "SERV-2": "vLLM server health — encrypted vLLM must respond HTTP 200 on /health before the TEE proxy starts.",
    "SERV-3": "TEE serving status — FHEnom admin API must report the model as SERVING after fhenomai serve start.",
    "SERV-4": "TEE inference coherence — TEE must return valid completions for geography, science, and code prompts.",
    "SERV-5": "Bypass test (encryption reality proof) — direct vLLM requests that skip the TEE must be refused or return garbled ciphertext.",
    "SERV-6": "Output fidelity — BERTScore similarity between TEE-routed and clear-model responses must exceed the threshold.",
    "SERV-7": "FHE overhead — per-token encryption and decryption latency at the TEE boundary must stay below configured limits.",
    # Training
    "T-1": "Training convergence — fine-tuning loss must reach the target threshold within the configured epoch budget.",
    "T-2": "Checkpoint integrity — the saved LoRA adapter weights must pass FHEnom signature verification.",
    "T-3": "Post-training accuracy — fine-tuned encrypted model must match the clear fine-tuned model within accuracy tolerance.",
}

# Keys to redact from the config block in the report
_REDACT_KEYS = {
    "tee_admin_token", "tee_user_token",
    "gpu_ssh_key", "tee_ssh_key",
}


def _fmt_cell(val: Any, max_len: int = 80) -> str:
    """Format a result value for a table cell.

    Dicts and lists are complex (e.g. scalability measurement maps) — the
    details toggle already shows the full data, so just emit a compact label
    for the cell to keep the table readable.
    """
    if val is None:
        return "—"
    if isinstance(val, dict):
        if not val:
            return "—"
        n = len(val)
        return f"{n} measurement{'s' if n != 1 else ''} (see details ▸)"
    if isinstance(val, list):
        if not val:
            return "—"
        return f"{len(val)} item{'s' if len(val) != 1 else ''} (see details ▸)"
    s = str(val)
    if len(s) > max_len:
        return s[:max_len - 1] + "…"
    return s


def _redact_cfg(raw: dict) -> dict:
    """Return a copy of the config dict with sensitive values masked."""
    import copy
    out = copy.deepcopy(raw)
    for key in _REDACT_KEYS:
        if key in out:
            out[key] = "***"
    return out


def generate_report(results: list[TestResult], cfg: Config,
                    output_dir: Path | str) -> Path:
    """Generate an HTML report from test results."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Group by category, formatting complex cell values
    categories: dict[str, list[dict]] = {}
    for r in results:
        cat = r.category
        if cat not in categories:
            categories[cat] = []
        d = r.to_dict()
        d["clear_value"] = _fmt_cell(d.get("clear_value"))
        d["encrypted_value"] = _fmt_cell(d.get("encrypted_value"))
        categories[cat].append(d)

    total = len(results)
    passed = sum(1 for r in results if r.passed)
    failed = total - passed

    import yaml
    config_yaml = yaml.dump(
        _redact_cfg(cfg.raw), default_flow_style=False, sort_keys=False
    )

    html = _HTML_TEMPLATE.render(
        customer=cfg.get("customer_name", ""),
        model_name=cfg.model_name,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC"),
        poc_id=cfg.get("poc_id", ""),
        total_tests=total,
        passed_tests=passed,
        failed_tests=failed,
        pass_rate=round(passed / total * 100, 1) if total > 0 else 0,
        categories=categories,
        category_labels=_CATEGORY_LABELS,
        category_descriptions=_CATEGORY_DESCRIPTIONS,
        test_descriptions=_TEST_DESCRIPTIONS,
        config_yaml=config_yaml,
        version="0.1.0",
    )

    report_path = output_dir / f"poc_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    report_path.write_text(html, encoding="utf-8")
    log.info("Report generated: %s", report_path)

    # Also save raw JSON
    json_path = output_dir / f"poc_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(json_path, "w") as f:
        json.dump([r.to_dict() for r in results], f, indent=2, default=str)
    log.info("Raw results saved: %s", json_path)

    return report_path
