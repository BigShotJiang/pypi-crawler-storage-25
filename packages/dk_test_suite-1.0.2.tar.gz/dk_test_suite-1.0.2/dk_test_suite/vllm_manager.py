"""vLLM lifecycle manager — start / stop / health-check / query."""

from __future__ import annotations

import json
import logging
import time
from typing import Any

import httpx

from dk_test_suite.config import Config
from dk_test_suite.utils import RemoteHost
from dk_test_suite.utils.metrics import InferenceResult

log = logging.getLogger(__name__)

_VLLM_CONTAINER = "dk_vllm_bench"


class VLLMManager:
    """Manages a remote vLLM Docker container and provides inference helpers."""

    def __init__(self, cfg: Config, gpu: RemoteHost) -> None:
        self.cfg = cfg
        self.gpu = gpu
        self._base: str = ""
        self._current_model_name: str = ""
        self._http = httpx.Client(timeout=cfg.get("vllm_request_timeout", 120))

    def close(self) -> None:
        self._http.close()

    # ── Lifecycle ───────────────────────────────────────────────
    def start_clear(self) -> None:
        """Start vLLM serving the plaintext (clear) model."""
        self._current_model_name = self.cfg.model_name
        self._start_container(
            model_path=self.cfg["model_path_clear"],
            model_name=self.cfg.model_name,
            container_name=_VLLM_CONTAINER,
        )
        self._base = f"http://{self.cfg.gpu_host}:{self.cfg['vllm_port']}"

    def start_encrypted(self) -> None:
        """Start vLLM serving the encrypted model with its encrypted tokenizer."""
        self._current_model_name = self.cfg.encrypted_model_name
        self._start_container(
            model_path=self.cfg["model_path_encrypted"],
            model_name=self.cfg.encrypted_model_name,
            container_name=_VLLM_CONTAINER,
        )
        self._base = f"http://{self.cfg.gpu_host}:{self.cfg['vllm_port']}"

    def stop(self) -> None:
        self.gpu.docker_stop(_VLLM_CONTAINER)
        log.info("vLLM container stopped")

    # ── Health ──────────────────────────────────────────────────
    def wait_ready(self, timeout: int | None = None, interval: int = 5,
                   model_name: str | None = None) -> None:
        """Poll /v1/models via SSH until vLLM is ready and serving the expected model.

        Uses SSH-based curl to avoid external firewall issues — port 8000
        is only reachable locally on the GPU.
        """
        port = self.cfg["vllm_port"]
        expected_model = model_name or self._current_model_name or self.cfg.model_name
        timeout = timeout if timeout is not None else self.cfg.get("vllm_startup_timeout", 300)
        deadline = time.time() + timeout
        attempt = 0
        while time.time() < deadline:
            attempt += 1

            # ── Detect container crash early ─────────────────────
            _, status_out, _ = self.gpu.run(
                f"docker inspect --format '{{{{.State.Status}}}}' {_VLLM_CONTAINER} 2>/dev/null",
                timeout=10, check=False,
            )
            if status_out.strip().lower() in ("exited", "dead", ""):
                logs = self.gpu.docker_logs(_VLLM_CONTAINER, tail=50)
                raise RuntimeError(
                    f"vLLM container exited before becoming ready.\n"
                    f"Last container logs:\n{logs}"
                )

            try:
                code, out, _ = self.gpu.run(
                    f"curl -s --max-time 5 http://localhost:{port}/v1/models",
                    timeout=15, check=False,
                )
                if code == 0 and out.strip():
                    # Check if the expected model name appears in the response
                    import json as _json
                    try:
                        data = _json.loads(out)
                        model_ids = [m.get("id", "") for m in data.get("data", [])]
                        if any(expected_model in mid for mid in model_ids):
                            log.info("vLLM ready — model '%s' loaded (attempt %d)", expected_model, attempt)
                            return
                        log.debug("vLLM /v1/models responded but model not found yet: %s", model_ids)
                    except _json.JSONDecodeError:
                        log.debug("vLLM /v1/models returned non-JSON: %s", out[:100])
            except Exception as e:
                log.debug("vLLM poll attempt %d: %s", attempt, e)
            time.sleep(interval)

        logs = self.gpu.docker_logs(_VLLM_CONTAINER, tail=50)
        raise TimeoutError(
            f"vLLM not ready after {timeout}s (model '{expected_model}' not found in /v1/models).\n"
            f"Last container logs:\n{logs}"
        )

    @property
    def base_url(self) -> str:
        return self._base

    # ── Inference ───────────────────────────────────────────────
    def completions(self, prompt: str, max_tokens: int = 256,
                    temperature: float = 0, logprobs: bool = False,
                    **kwargs: Any) -> InferenceResult:
        """Call /v1/completions and return structured result."""
        url = f"{self._base}/v1/completions"
        body: dict[str, Any] = {
            "model": self.cfg.model_name,
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if logprobs:
            body["logprobs"] = 1
        body.update(kwargs)

        req_timeout = self.cfg.get("vllm_request_timeout", 120)
        t0 = time.perf_counter()
        r = self._http.post(url, json=body, timeout=req_timeout)
        total_ms = (time.perf_counter() - t0) * 1000
        r.raise_for_status()
        data = r.json()

        choice = data["choices"][0]
        usage = data.get("usage", {})
        lp_values: list[float] | None = None
        if logprobs and "logprobs" in choice and choice["logprobs"]:
            lp_values = [
                lp for lp in (choice["logprobs"].get("token_logprobs") or [])
                if lp is not None
            ]

        return InferenceResult(
            prompt_id="",
            prompt_text=prompt,
            output_text=choice.get("text", ""),
            tokens_generated=usage.get("completion_tokens", 0),
            total_time_ms=total_ms,
            logprobs=lp_values,
        )

    def chat(self, messages: list[dict[str, str]], max_tokens: int = 256,
             temperature: float = 0, **kwargs: Any) -> InferenceResult:
        """Call /v1/chat/completions."""
        url = f"{self._base}/v1/chat/completions"
        body: dict[str, Any] = {
            "model": self.cfg.model_name,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        body.update(kwargs)

        req_timeout = self.cfg.get("vllm_request_timeout", 120)
        t0 = time.perf_counter()
        r = self._http.post(url, json=body, timeout=req_timeout)
        total_ms = (time.perf_counter() - t0) * 1000
        r.raise_for_status()
        data = r.json()

        choice = data["choices"][0]
        usage = data.get("usage", {})
        return InferenceResult(
            prompt_id="",
            prompt_text=str(messages),
            output_text=choice["message"]["content"],
            tokens_generated=usage.get("completion_tokens", 0),
            total_time_ms=total_ms,
        )

    def completions_streaming(self, prompt: str, max_tokens: int = 256,
                              temperature: float = 0) -> InferenceResult:
        """Streaming completions — measures TTFT."""
        url = f"{self._base}/v1/completions"
        body = {
            "model": self.cfg.model_name,
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }

        req_timeout = self.cfg.get("vllm_request_timeout", 120)
        t0 = time.perf_counter()
        ttft: float = 0.0
        chunks: list[str] = []
        token_count = 0
        usage_tokens: int | None = None

        with self._http.stream("POST", url, json=body, timeout=req_timeout) as r:
            for line in r.iter_lines():
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if payload.strip() == "[DONE]":
                    break
                chunk_data = json.loads(payload)
                text = chunk_data["choices"][0].get("text", "")
                # Extract usage from final chunk if vLLM provides it
                chunk_usage = chunk_data.get("usage")
                if chunk_usage and chunk_usage.get("completion_tokens"):
                    usage_tokens = chunk_usage["completion_tokens"]
                if text and ttft == 0.0:
                    ttft = (time.perf_counter() - t0) * 1000
                if text:
                    chunks.append(text)
                    token_count += 1

        total_ms = (time.perf_counter() - t0) * 1000
        final_token_count = usage_tokens if usage_tokens is not None else token_count
        return InferenceResult(
            prompt_id="",
            prompt_text=prompt,
            output_text="".join(chunks),
            time_to_first_token_ms=ttft,
            total_time_ms=total_ms,
            tokens_generated=final_token_count,
        )

    def get_model_info(self) -> dict[str, Any]:
        """GET /v1/models and return model info."""
        r = self._http.get(f"{self._base}/v1/models", timeout=30)
        r.raise_for_status()
        return r.json()

    def get_vram_usage(self) -> dict[str, Any]:
        """Query nvidia-smi on the GPU host.

        Supports multi-GPU: sums used/total VRAM across all GPUs and averages
        utilisation, so the result is correct regardless of tensor-parallel-size.
        """
        _, out, _ = self.gpu.run(
            "nvidia-smi --query-gpu=memory.used,memory.total,utilization.gpu "
            "--format=csv,noheader,nounits"
        )
        used_total = total_total = util_sum = count = 0
        for line in out.strip().splitlines():
            parts = line.split(",")
            if len(parts) < 3:
                continue
            used_total += int(parts[0].strip())
            total_total += int(parts[1].strip())
            util_sum += int(parts[2].strip())
            count += 1
        return {
            "vram_used_mb": used_total,
            "vram_total_mb": total_total,
            "gpu_util_pct": util_sum // count if count else 0,
        }

    # ── Internal ────────────────────────────────────────────────
    def _start_container(self, model_path: str, model_name: str,
                         container_name: str) -> None:
        self.gpu.docker_stop(container_name)
        gpu_mem = self.cfg["vllm_gpu_memory_utilization"]
        max_len = self.cfg["vllm_max_model_len"]
        port = self.cfg["vllm_port"]
        tp = self.cfg.get("vllm_tensor_parallel_size", 1)

        dtype = self.cfg.get("vllm_dtype", "auto")
        cmd = (
            f"docker run -d --name {container_name} "
            f"--gpus all --ipc=host "
            f"-v {model_path}:/model "
            f"-p {port}:{port} "
            f"{self.cfg['vllm_image']} "
            f"--model /model "
            f"--served-model-name {model_name} "
            f"--gpu-memory-utilization {gpu_mem} "
            f"--max-model-len {max_len} "
            f"--tensor-parallel-size {tp} "
            f"--port {port} "
            f"--dtype {dtype}"
        )
        _, cid, _ = self.gpu.run(cmd, timeout=60)
        log.info("vLLM container started: %s", cid[:12])
