"""HTML report generator — DataKrypto-styled side-by-side comparison of clear vs encrypted."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Template

from dk_test_suite.config import Config
from dk_test_suite.tests.base import TestResult

log = logging.getLogger(__name__)

# ── Jinja2 HTML template ── DataKrypto design system ──────────────────────────
_HTML_TEMPLATE = Template("""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FHEnom for AI™ — POC Test Report</title>
<link rel="icon" type="image/png" href="https://datakrypto.ai/wp-content/uploads/2025/02/ALL-RED_DataKrypto_Vector_Logo_20240911_V2-75x75.png" sizes="32x32">
<link rel="icon" type="image/png" href="https://datakrypto.ai/wp-content/uploads/2025/02/ALL-RED_DataKrypto_Vector_Logo_20240911_V2-300x300.png" sizes="192x192">
<link rel="apple-touch-icon" href="https://datakrypto.ai/wp-content/uploads/2025/02/ALL-RED_DataKrypto_Vector_Logo_20240911_V2-300x300.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<style>
  /* ── DataKrypto Design System ──────────────── */
  :root {
    --bg:          #1A1C1D;
    --surface:     #222527;
    --surface-alt: #292D2E;
    --border:      #363B3C;
    --accent:      #DF2B3B;
    --accent-dim:  #B91C1C;
    --success:     #00D084;
    --warning:     #F59E0B;
    --error:       #EF4444;
    --text:        #FFFFFF;
    --text-sec:    #AAB8C8;
    --text-muted:  #72798A;
    --skip:        #F59E0B;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: var(--bg);
    color: var(--text);
    font-size: 14px;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
  }

  /* ── Layout ── */
  .page-wrap { max-width: 1280px; margin: 0 auto; padding: 0 32px 64px; }

  /* ── Top bar ── */
  .topbar {
    background: var(--bg);
    border-bottom: 1px solid var(--border);
    padding: 0 32px;
    height: 64px;
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 48px;
  }
  .topbar-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
  }
  .topbar-brand { font-weight: 700; font-size: 15px; color: var(--text); letter-spacing: 0.3px; }
  .topbar-div { width: 1px; height: 28px; background: var(--border); }
  .topbar-label {
    font-size: 11px; font-weight: 600; color: var(--text-sec);
    text-transform: uppercase; letter-spacing: 1.2px;
  }
  .topbar-spacer { flex: 1; }
  .topbar-badge {
    font-size: 11px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase;
    padding: 4px 12px; border-radius: 4px;
    border: 1px solid var(--border); color: var(--text-sec);
  }

  /* ── Hero ── */
  .hero { margin-bottom: 40px; }
  .dk-label {
    font-size: 11px; font-weight: 700; color: var(--accent);
    text-transform: uppercase; letter-spacing: 1.6px; margin-bottom: 10px;
  }
  .hero h1 {
    font-size: 30px; font-weight: 800; color: var(--text);
    line-height: 1.2; margin-bottom: 10px;
  }
  .hero-meta {
    font-size: 13px; color: var(--text-sec);
    display: flex; flex-wrap: wrap; gap: 6px 24px; margin-bottom: 4px;
  }
  .hero-meta span { white-space: nowrap; }
  .hero-meta strong { color: var(--text); font-weight: 600; }

  /* ── Summary cards ── */
  .summary-grid {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 16px;
    margin-bottom: 48px;
  }
  @media (max-width: 768px) { .summary-grid { grid-template-columns: repeat(2,1fr); } }
  .summary-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 24px 28px;
    position: relative;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
  }
  .summary-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 20px rgba(0,0,0,0.25);
  }
  .summary-card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 3px;
    border-radius: 8px 8px 0 0;
    background: var(--border);
  }
  .summary-card.accent::before { background: var(--accent); }
  .summary-card.success::before { background: var(--success); }
  .summary-card.error::before   { background: var(--error); }
  .summary-card.warning::before { background: var(--skip); }
  .summary-card .card-label {
    font-size: 12px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1.4px; color: var(--text-sec); margin-bottom: 12px;
  }
  .summary-card .card-num {
    font-size: 42px; font-weight: 800; line-height: 1;
    color: var(--text);
  }
  .summary-card .card-sub {
    font-size: 12px; font-weight: 500; color: var(--text-muted);
    margin-top: 8px; letter-spacing: 0.3px;
  }
  .summary-card.success .card-num { color: var(--success); }
  .summary-card.error   .card-num { color: var(--error); }
  .summary-card.warning .card-num { color: var(--skip); }

  /* ── Section header ── */
  .section-header {
    display: flex; align-items: flex-end; gap: 12px;
    margin: 48px 0 16px;
    padding-bottom: 14px;
    border-bottom: 2px solid var(--border);
  }
  .section-header h2 {
    font-size: 18px; font-weight: 700; color: var(--text); flex: 1;
  }
  .section-tag {
    font-size: 11px; font-weight: 600; text-transform: uppercase;
    letter-spacing: 1.2px; color: var(--text-muted);
  }
  .pass-count {
    font-size: 12px; font-weight: 600; color: var(--success);
    padding: 2px 10px; border-radius: 4px;
    background: rgba(0,208,132,0.10); border: 1px solid rgba(0,208,132,0.25);
  }
  .fail-count {
    font-size: 12px; font-weight: 600; color: var(--error);
    padding: 2px 10px; border-radius: 4px;
    background: rgba(239,68,68,0.10); border: 1px solid rgba(239,68,68,0.25);
  }
  .skip-count {
    font-size: 12px; font-weight: 600; color: var(--skip);
    padding: 2px 10px; border-radius: 4px;
    background: rgba(245,158,11,0.10); border: 1px solid rgba(245,158,11,0.25);
  }

  /* ── Table ── */
  .table-wrap {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 8px;
  }
  table { width: 100%; border-collapse: collapse; }
  thead tr { background: var(--surface-alt); }
  th {
    padding: 12px 16px;
    font-size: 11px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1.2px; color: var(--text-sec);
    text-align: left; border-bottom: 2px solid var(--border);
    white-space: nowrap;
  }
  td {
    padding: 14px 16px;
    font-size: 13px; color: var(--text-sec);
    border-bottom: 1px solid var(--border);
    vertical-align: top;
  }
  tbody tr:last-child td { border-bottom: none; }
  tbody tr:hover td { background: rgba(223,43,59,0.04); }
  td.id-cell { font-weight: 700; color: var(--text); font-size: 13px; white-space: nowrap; }
  td.name-cell { color: var(--text); font-weight: 500; font-size: 14px; }
  td.mono { font-family: 'Courier New', monospace; font-size: 13px; color: var(--text); }
  td.diff-cell { font-weight: 700; font-family: 'Courier New', monospace; font-size: 13px; }
  td.diff-pos { color: var(--success); }
  td.diff-neg { color: var(--error); }
  td.diff-neu { color: var(--text-sec); }

  /* ── Badges ── */
  .badge {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 3px 10px; border-radius: 4px;
    font-size: 11px; font-weight: 700; letter-spacing: 1px;
    text-transform: uppercase; white-space: nowrap;
  }
  .badge::before { content: ''; width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
  .badge-pass {
    background: rgba(0,208,132,0.12); color: var(--success);
    border: 1px solid rgba(0,208,132,0.30);
  }
  .badge-pass::before { background: var(--success); }
  .badge-fail {
    background: rgba(239,68,68,0.12); color: var(--error);
    border: 1px solid rgba(239,68,68,0.30);
  }
  .badge-fail::before { background: var(--error); }
  .badge-skip {
    background: rgba(245,158,11,0.12); color: var(--skip);
    border: 1px solid rgba(245,158,11,0.30);
  }
  .badge-skip::before { background: var(--skip); }

  /* ── Details toggle ── */
  .details-btn {
    cursor: pointer; color: var(--accent); font-size: 12px; font-weight: 600;
    letter-spacing: 0.5px;
    background: none; border: none; padding: 0;
    display: flex; align-items: center; gap: 4px;
    user-select: none;
  }
  .details-btn:hover { color: var(--accent-dim); }
  .details-arrow { transition: transform 0.2s ease; display: inline-block; }
  .details-btn.open .details-arrow { transform: rotate(90deg); }
  .details-content {
    display: none;
    margin-top: 8px;
    padding: 12px;
    background: var(--surface-alt);
    border: 1px solid var(--border);
    border-radius: 4px;
    font-size: 12px; font-family: 'Courier New', monospace;
    white-space: pre-wrap; word-break: break-word;
    color: var(--text-sec);
    line-height: 1.5;
    max-height: 400px; overflow-y: auto;
  }
  .details-content.open { display: block; }

  /* ── Metric explanation toggle ── */
  .metric-explain-btn {
    cursor: pointer; color: var(--text-muted); font-size: 11px; font-weight: 600;
    letter-spacing: 0.5px;
    background: none; border: none; padding: 2px 0 0 0;
    display: inline-flex; align-items: center; gap: 4px;
    user-select: none;
  }
  .metric-explain-btn:hover { color: var(--text-sec); }
  .metric-explain-btn .me-arrow { transition: transform 0.2s ease; display: inline-block; font-size: 10px; }
  .metric-explain-btn.open .me-arrow { transform: rotate(90deg); }
  .metric-explain {
    display: none;
    margin-top: 8px;
    padding: 14px 16px;
    background: var(--surface-alt);
    border: 1px solid var(--border);
    border-left: 3px solid var(--accent);
    border-radius: 0 4px 4px 0;
    font-size: 12px; font-family: 'Inter', sans-serif;
    color: var(--text-sec);
    line-height: 1.7;
  }
  .metric-explain.open { display: block; }
  .metric-explain h4 {
    font-size: 13px; font-weight: 600; color: var(--text);
    margin-bottom: 8px;
  }
  .metric-explain .me-section {
    margin-bottom: 8px;
  }
  .metric-explain .me-label {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1px; color: var(--accent); margin-bottom: 2px;
  }
  .metric-explain code {
    background: rgba(255,255,255,0.06); padding: 1px 5px; border-radius: 3px;
    font-size: 11px; font-family: 'Courier New', monospace;
  }

  /* ── Category description ── */
  .category-desc {
    font-size: 13px; color: var(--text-sec); line-height: 1.75;
    margin-bottom: 16px;
    padding: 14px 18px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-left: 3px solid var(--accent);
    border-radius: 0 4px 4px 0;
  }
  .category-desc strong { color: var(--text); font-weight: 500; }
  .category-methodology {
    display: flex; flex-wrap: wrap; gap: 6px 16px;
    margin-top: 8px;
  }
  .method-chip {
    font-size: 11px; font-weight: 600; letter-spacing: 0.8px;
    text-transform: uppercase; color: var(--text-muted);
    padding: 2px 8px;
    border: 1px solid var(--border);
    border-radius: 3px;
    background: var(--surface-alt);
  }

  /* ── Test description (subtitle under test name) ── */
  .test-desc {
    font-size: 11px; color: var(--text-muted); font-weight: 400;
    margin-top: 3px; line-height: 1.45; max-width: 480px;
  }

  /* ── Chart section ── */
  .chart-section {
    margin: 16px 0 24px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
  }
  @media (max-width: 768px) { .chart-section { grid-template-columns: 1fr; } }
  .chart-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 24px;
  }
  .chart-card h3 {
    font-size: 14px; font-weight: 600; color: var(--text);
    margin-bottom: 14px;
  }
  .chart-card canvas {
    width: 100% !important;
    max-height: 280px;
  }
  .chart-card.full-width {
    grid-column: 1 / -1;
  }

  /* ── Experiment selector ── */
  .experiment-selector {
    display: flex; flex-wrap: wrap; gap: 8px;
    margin: 12px 0 16px; align-items: center;
  }
  .experiment-selector .exp-label {
    font-size: 12px; font-weight: 600; color: var(--text-sec);
    text-transform: uppercase; letter-spacing: 1px; margin-right: 4px;
  }
  .experiment-selector .exp-btn {
    cursor: pointer;
    font-size: 12px; font-weight: 600; letter-spacing: 0.5px;
    padding: 5px 14px; border-radius: 6px;
    border: 1px solid var(--border);
    background: var(--surface-alt);
    color: var(--text-sec);
    transition: all 0.15s ease;
    user-select: none;
  }
  .experiment-selector .exp-btn:hover {
    border-color: var(--accent); color: var(--text);
  }
  .experiment-selector .exp-btn.active {
    background: var(--accent); border-color: var(--accent);
    color: #fff;
  }

  /* ── Scalability detail cards (inline metric tiles) ── */
  .scale-metrics {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 10px;
    margin: 12px 0 20px;
  }
  .scale-tile {
    background: var(--surface-alt);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 14px 16px;
  }
  .scale-tile .tile-label {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1px; color: var(--text-muted); margin-bottom: 6px;
  }
  .scale-tile .tile-row {
    display: flex; justify-content: space-between; align-items: baseline;
    gap: 8px; margin-bottom: 2px;
  }
  .scale-tile .tile-key {
    font-size: 11px; font-weight: 500; color: var(--text-sec);
  }
  .scale-tile .tile-val {
    font-size: 14px; font-weight: 700; color: var(--text);
    font-family: 'Courier New', monospace;
  }
  .scale-tile .tile-val.positive { color: var(--success); }
  .scale-tile .tile-val.negative { color: var(--error); }

  /* ── Config block ── */
  .config-section { margin-top: 48px; }
  .config-block {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 20px 24px;
    font-family: 'Courier New', monospace;
    font-size: 12px;
    white-space: pre-wrap;
    overflow-x: auto;
    color: var(--text-sec);
    line-height: 1.7;
    max-height: 400px;
    overflow-y: auto;
  }

  /* ── Pipeline diagram ── */
  .pipeline {
    display: flex; align-items: center; gap: 0;
    flex-wrap: wrap; margin: 16px 0 24px;
  }
  .pip-node {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 8px 14px;
    font-size: 12px; font-weight: 600; color: var(--text-sec);
    white-space: nowrap;
  }
  .pip-node.accent { border-color: var(--accent); color: var(--accent); }
  .pip-node.success { border-color: var(--success); color: var(--success); }
  .pip-arrow {
    font-size: 16px; color: var(--text-muted); padding: 0 6px;
    flex-shrink: 0;
  }

  /* ── Footer ── */
  footer {
    margin-top: 64px;
    padding-top: 20px;
    border-top: 1px solid var(--border);
    display: flex; justify-content: space-between; align-items: center;
    flex-wrap: wrap; gap: 8px;
  }
  footer .footer-brand {
    font-size: 12px; font-weight: 700; color: var(--text-sec); letter-spacing: 0.5px;
  }
  footer .footer-meta { font-size: 11px; color: var(--text-muted); }
  footer .footer-conf {
    font-size: 11px; font-weight: 600; color: var(--accent);
    text-transform: uppercase; letter-spacing: 1px;
    padding: 3px 10px; border: 1px solid rgba(223,43,59,0.4);
    border-radius: 4px;
  }

  /* ── Inline DK logo mark ── */
  .topbar-dk-mark {
    width: 32px; height: 32px; background: var(--accent); border-radius: 5px;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Inter', sans-serif; font-weight: 800; font-size: 11px;
    color: white; letter-spacing: -0.5px; flex-shrink: 0; user-select: none;
  }

  /* ── Summary overview charts ── */
  .summary-charts {
    display: grid;
    grid-template-columns: 260px 1fr;
    gap: 16px;
    margin-bottom: 48px;
  }
  @media (max-width: 768px) { .summary-charts { grid-template-columns: 1fr; } }
  .summary-chart-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 24px;
  }
  .summary-chart-card h3 {
    font-size: 11px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1.3px; color: var(--text-sec); margin-bottom: 16px;
  }

  /* ── Security status grid ── */
  .sec-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
    gap: 12px;
    margin: 16px 0 24px;
  }
  .sec-tile {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px 18px;
    display: flex;
    gap: 14px;
    align-items: flex-start;
  }
  .sec-tile.t-pass { border-left: 3px solid var(--success); }
  .sec-tile.t-fail { border-left: 3px solid var(--error); }
  .sec-tile.t-skip { border-left: 3px solid var(--skip); }
  .sec-tile-icon {
    width: 28px; height: 28px; border-radius: 50%; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    font-size: 12px; font-weight: 800; margin-top: 2px;
  }
  .sec-tile.t-pass .sec-tile-icon { background: rgba(0,208,132,0.15); color: var(--success); }
  .sec-tile.t-fail .sec-tile-icon { background: rgba(239,68,68,0.15); color: var(--error); }
  .sec-tile.t-skip .sec-tile-icon { background: rgba(245,158,11,0.15); color: var(--skip); }
  .sec-tile-body { flex: 1; min-width: 0; }
  .sec-tile-id {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1px; color: var(--text-muted); margin-bottom: 3px;
  }
  .sec-tile-name { font-size: 13px; font-weight: 600; color: var(--text); margin-bottom: 4px; }
  .sec-tile-desc { font-size: 11px; color: var(--text-muted); line-height: 1.5; }

  /* ── Response Viewer ── */
  .rv-controls {
    display: flex; gap: 16px; align-items: flex-end; flex-wrap: wrap;
    margin: 16px 0;
  }
  .rv-select-group { display: flex; flex-direction: column; gap: 4px; flex: 1; min-width: 180px; }
  .rv-label {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1.2px; color: var(--text-sec);
  }
  .rv-select {
    background: var(--surface-alt); color: var(--text); border: 1px solid var(--border);
    border-radius: 6px; padding: 8px 12px; font-size: 13px; font-family: 'Inter', sans-serif;
    cursor: pointer; appearance: auto;
  }
  .rv-select:focus { outline: none; border-color: var(--accent); }
  .rv-counter { font-size: 12px; color: var(--text-muted); padding-bottom: 10px; }
  .rv-display { margin-top: 12px; }
  .rv-prompt-box {
    background: var(--surface); border: 1px solid var(--border); border-left: 3px solid var(--accent);
    border-radius: 0 6px 6px 0; padding: 16px 18px; margin-bottom: 12px;
  }
  .rv-box-label {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1.2px; color: var(--accent); margin-bottom: 8px;
  }
  .rv-text {
    font-size: 13px; color: var(--text-sec); line-height: 1.7;
    white-space: pre-wrap; word-break: break-word;
    font-family: 'Courier New', monospace;
    max-height: 400px; overflow-y: auto;
  }
  .rv-text-prompt { color: var(--text); font-family: 'Inter', sans-serif; font-size: 14px; }
  .rv-side-by-side {
    display: grid; grid-template-columns: 1fr 1fr; gap: 12px;
  }
  @media (max-width: 768px) { .rv-side-by-side { grid-template-columns: 1fr; } }
  .rv-response-box {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 6px; padding: 16px 18px; min-height: 120px;
  }
  .rv-response-clear .rv-box-label { color: var(--text-sec); }
  .rv-response-enc .rv-box-label { color: var(--accent); }
  .rv-diff-summary {
    margin-top: 12px; padding: 10px 14px;
    background: var(--surface-alt); border: 1px solid var(--border);
    border-radius: 6px; font-size: 12px; color: var(--text-sec);
  }
</style>
<script>
function toggleDetails(id) {
  var content = document.getElementById('det-' + id);
  var btn = document.getElementById('btn-' + id);
  content.classList.toggle('open');
  btn.classList.toggle('open');
}
function toggleExplain(id) {
  var content = document.getElementById('expl-' + id);
  var btn = document.getElementById('ebtn-' + id);
  content.classList.toggle('open');
  btn.classList.toggle('open');
}
</script>
</head>
<body>

<!-- Top bar -->
<div class="topbar">
  <div class="topbar-logo">
    <div class="topbar-dk-mark">DK</div>
    <span class="topbar-brand">FHEnom for AI™</span>
  </div>
  <div class="topbar-div"></div>
  <span class="topbar-label">POC Validation Report</span>
  <div class="topbar-spacer"></div>
  <span class="topbar-badge">{{ poc_id }}</span>
</div>

<div class="page-wrap">

<!-- Hero -->
<div class="hero">
  <div class="dk-label">Head-to-Head Test Report</div>
  <h1>FHEnom for AI™ — POC Validation Results</h1>
  <div class="hero-meta">
    <span><strong>Customer:</strong> {{ customer }}</span>
    <span><strong>Model:</strong> {{ model_name }}</span>
    <span><strong>Generated:</strong> {{ timestamp }}</span>
    <span><strong>Suite Version:</strong> v{{ version }}</span>
  </div>
</div>

<!-- Architecture pipeline -->
<div class="pipeline">
  <div class="pip-node">User Request</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node accent">TEE:9999</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node">Encrypt Prompt</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node success">vLLM:8000 (Encrypted Weights + Prompt)</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node accent">TEE</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node">Decrypt Response</div>
  <div class="pip-arrow">→</div>
  <div class="pip-node">Response</div>
</div>

<!-- Summary cards -->
<div class="summary-grid">
  <div class="summary-card accent">
    <div class="card-label">Total Tests</div>
    <div class="card-num">{{ total_tests }}</div>
    <div class="card-sub">Across all categories</div>
  </div>
  <div class="summary-card success">
    <div class="card-label">Passed</div>
    <div class="card-num">{{ passed_tests }}</div>
    <div class="card-sub">{{ '%.0f' | format(passed_tests / total_tests * 100) if total_tests > 0 else '0' }}% of total</div>
  </div>
  <div class="summary-card{% if failed_tests > 0 %} error{% endif %}">
    <div class="card-label">Failed</div>
    <div class="card-num">{{ failed_tests }}</div>
    <div class="card-sub">{% if failed_tests == 0 %}No failures{% else %}Needs attention{% endif %}</div>
  </div>
  <div class="summary-card{% if skipped_tests > 0 %} warning{% endif %}">
    <div class="card-label">Skipped</div>
    <div class="card-num">{{ skipped_tests }}</div>
    <div class="card-sub">{% if skipped_tests == 0 %}All tests ran{% else %}Dependencies missing{% endif %}</div>
  </div>
  <div class="summary-card{% if pass_rate >= 100 %} success{% endif %}">
    <div class="card-label">Pass Rate</div>
    <div class="card-num">{{ pass_rate }}%</div>
    <div class="card-sub">Excluding skipped tests</div>
  </div>
</div>

<!-- Summary overview charts -->
<div class="summary-charts">
  <div class="summary-chart-card">
    <h3>Overall Results</h3>
    <canvas id="chart-summary-donut" style="max-height:190px;"></canvas>
  </div>
  <div class="summary-chart-card">
    <h3>Pass Rate by Category</h3>
    <canvas id="chart-category-bars" style="max-height:190px;"></canvas>
  </div>
</div>

{% for category, tests in categories.items() %}
{% set cat_passed = tests | selectattr("passed", "equalto", true) | rejectattr("skipped", "equalto", true) | list | length %}
{% set cat_skipped = tests | selectattr("skipped", "equalto", true) | list | length %}
{% set cat_failed = tests | length - cat_passed - cat_skipped %}

<div class="section-header">
  <h2>{{ category_labels[category] }}</h2>
  <span class="section-tag">{{ tests | length }} test{{ 's' if tests | length != 1 else '' }}</span>
  {% if cat_skipped > 0 %}
  <span class="skip-count">{{ cat_skipped }} Skipped</span>
  {% endif %}
  {% if cat_failed == 0 and cat_skipped == 0 %}
  <span class="pass-count">{{ cat_passed }}/{{ tests | length }} Pass</span>
  {% elif cat_failed == 0 %}
  <span class="pass-count">{{ cat_passed }}/{{ tests | length - cat_skipped }} Pass</span>
  {% else %}
  <span class="fail-count">{{ cat_failed }} Failed</span>
  {% endif %}
</div>

{% if category_descriptions[category] %}
<div class="category-desc">{{ category_descriptions[category] | safe }}</div>
{% endif %}

<!-- Bar charts for performance tests -->
{% if category == "performance" and perf_chart_data %}
<div class="chart-section">
  <div class="chart-card">
    <h3>Latency & Response Time (ms) — Lower is Better</h3>
    <canvas id="chart-latency"></canvas>
  </div>
  <div class="chart-card">
    <h3>Throughput (tok/s) & Model Footprint (GB)</h3>
    <canvas id="chart-throughput"></canvas>
  </div>
</div>
{% endif %}

<!-- Scalability charts -->
{% if category == "scalability" and scale_chart_data %}
<div class="experiment-selector" id="scale-exp-selector">
  <span class="exp-label">Focus on:</span>
  <button class="exp-btn active" data-scale="all" onclick="filterScaleChart('all', this)">All Experiments</button>
  <button class="exp-btn" data-scale="concurrent" onclick="filterScaleChart('concurrent', this)">Concurrent Load</button>
  <button class="exp-btn" data-scale="context" onclick="filterScaleChart('context', this)">Context Length</button>
  <button class="exp-btn" data-scale="batch" onclick="filterScaleChart('batch', this)">Batch Size</button>
</div>

<div class="chart-section" id="scale-charts">
  <div class="chart-card" id="scale-concurrent-card">
    <h3>SCALE-1 — Concurrent Users: Throughput (tok/s)</h3>
    <canvas id="chart-scale-concurrent"></canvas>
  </div>
  <div class="chart-card" id="scale-concurrent-lat-card">
    <h3>SCALE-1 — Concurrent Users: Avg Latency (ms)</h3>
    <canvas id="chart-scale-concurrent-lat"></canvas>
  </div>
  <div class="chart-card" id="scale-context-card">
    <h3>SCALE-2 — Context Length: Avg Latency (ms)</h3>
    <canvas id="chart-scale-context"></canvas>
  </div>
  <div class="chart-card" id="scale-batch-card">
    <h3>SCALE-3 — Batch Size: Throughput (tok/s)</h3>
    <canvas id="chart-scale-batch"></canvas>
  </div>
</div>
{% endif %}

{% if category == "accuracy" and acc_chart_data %}
<div class="chart-section">
  <div class="chart-card full-width">
    <h3>Accuracy Metrics — Clear vs Encrypted Model</h3>
    <canvas id="chart-accuracy" style="max-height:260px;"></canvas>
  </div>
</div>
{% endif %}

{% if category == "security" %}
<div class="sec-grid">
{% for t in tests %}
  <div class="sec-tile {% if t.skipped %}t-skip{% elif t.passed %}t-pass{% else %}t-fail{% endif %}">
    <div class="sec-tile-icon">{% if t.skipped %}○{% elif t.passed %}✓{% else %}✗{% endif %}</div>
    <div class="sec-tile-body">
      <div class="sec-tile-id">{{ t.test_id }}</div>
      <div class="sec-tile-name">{{ t.name }}</div>
      {% if test_descriptions[t.test_id] %}<div class="sec-tile-desc">{{ test_descriptions[t.test_id] }}</div>{% endif %}
    </div>
  </div>
{% endfor %}
</div>
{% endif %}

<div class="table-wrap">
<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Test Name</th>
      <th>Clear Model</th>
      <th>Encrypted</th>
      <th>Difference</th>
      <th>Threshold</th>
      <th>Result</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
  {% for t in tests %}
    <tr>
      <td class="id-cell">{{ t.test_id }}</td>
      <td class="name-cell">{{ t.name }}
        {% if test_descriptions[t.test_id] %}
        <div class="test-desc">{{ test_descriptions[t.test_id] }}</div>
        {% endif %}
        {% if metric_explanations[t.test_id] %}
        <button id="ebtn-{{ t.test_id }}" class="metric-explain-btn" onclick="toggleExplain('{{ t.test_id }}')">
          <span class="me-arrow">▶</span> How this is measured
        </button>
        <div id="expl-{{ t.test_id }}" class="metric-explain">
          {{ metric_explanations[t.test_id] | safe }}
        </div>
        {% endif %}
      </td>
      <td class="mono">{{ t.clear_value if t.clear_value is not none else '—' }}</td>
      <td class="mono">{{ t.encrypted_value if t.encrypted_value is not none else '—' }}</td>
      <td class="diff-cell{% if t.diff_value is not none and t.diff_value is string and t.diff_value.startswith('+') %} diff-pos{% elif t.diff_value is not none and t.diff_value is string and t.diff_value.startswith('-') %} diff-neg{% else %} diff-neu{% endif %}">{{ t.diff_value if t.diff_value is not none else '—' }}</td>
      <td style="color:var(--text-muted); font-size:12px;">{{ t.threshold if t.threshold else '—' }}</td>
      <td>
        {% if t.skipped %}
        <span class="badge badge-skip">Skip</span>
        {% elif t.passed %}
        <span class="badge badge-pass">Pass</span>
        {% else %}
        <span class="badge badge-fail">Fail</span>
        {% endif %}
      </td>
      <td>
        {% if t.details %}
        <button id="btn-{{ t.test_id }}" class="details-btn" onclick="toggleDetails('{{ t.test_id }}')">
          <span class="details-arrow">▶</span> Details
        </button>
        <div id="det-{{ t.test_id }}" class="details-content">{{ t.details }}</div>
        {% endif %}
      </td>
    </tr>
  {% endfor %}
  </tbody>
</table>
</div>
{% endfor %}

<!-- Config -->
<div class="config-section">
  <div class="section-header">
    <h2>Test Configuration</h2>
    <span class="section-tag">config/default.yaml</span>
  </div>
  <div class="config-block">{{ config_yaml }}</div>
</div>

{% if response_viewer_data %}
<!-- Response Viewer -->
<div class="config-section">
  <div class="section-header">
    <h2>Response Viewer — Clear vs Encrypted</h2>
    <span class="section-tag">Per-prompt inspection</span>
  </div>
  <div class="category-desc">
    Browse the actual prompts and responses generated during non-batched inference tests.
    Select a <strong>category</strong> and a <strong>prompt</strong> to compare the clear model's response
    against the encrypted (TEE-proxied) model's response side-by-side.
  </div>
  <div class="rv-controls">
    <div class="rv-select-group">
      <label class="rv-label" for="rv-cat-select">Category</label>
      <select id="rv-cat-select" class="rv-select" onchange="rvFilterCategory()">
        <option value="all">All Categories</option>
      </select>
    </div>
    <div class="rv-select-group" style="flex:2;">
      <label class="rv-label" for="rv-prompt-select">Prompt</label>
      <select id="rv-prompt-select" class="rv-select" onchange="rvShowPrompt()">
        <option value="">— select a prompt —</option>
      </select>
    </div>
    <div class="rv-select-group">
      <span class="rv-label rv-counter" id="rv-counter"></span>
    </div>
  </div>
  <div id="rv-display" class="rv-display" style="display:none;">
    <div class="rv-prompt-box">
      <div class="rv-box-label">Prompt</div>
      <div id="rv-prompt-text" class="rv-text rv-text-prompt"></div>
    </div>
    <div class="rv-side-by-side">
      <div class="rv-response-box rv-response-clear">
        <div class="rv-box-label">Clear Model Response</div>
        <div id="rv-clear-text" class="rv-text"></div>
      </div>
      <div class="rv-response-box rv-response-enc">
        <div class="rv-box-label">Encrypted Model Response (via TEE)</div>
        <div id="rv-enc-text" class="rv-text"></div>
      </div>
    </div>
    <div id="rv-diff-summary" class="rv-diff-summary"></div>
  </div>
</div>
{% endif %}

</div><!-- /page-wrap -->

<footer>
  <div style="display:flex;align-items:center;gap:10px;">
    <div style="width:22px;height:22px;background:var(--accent);border-radius:3px;display:flex;align-items:center;justify-content:center;font-family:Inter,sans-serif;font-weight:800;font-size:8px;color:white;letter-spacing:-0.3px;flex-shrink:0;">DK</div>
    <span class="footer-brand">DataKrypto — FHEnom for AI™</span>
  </div>
  <span class="footer-meta">Generated by dk-test-suite v{{ version }} · {{ timestamp }}</span>
  <span class="footer-conf">Confidential</span>
</footer>

{% if perf_chart_data %}
<script>
document.addEventListener('DOMContentLoaded', function() {
  var chartColors = {
    clear: 'rgba(148, 163, 184, 0.85)',
    clearBorder: 'rgba(148, 163, 184, 1)',
    enc: 'rgba(223, 43, 59, 0.85)',
    encBorder: 'rgba(223, 43, 59, 1)',
  };
  var defaultOpts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: '#94A3B8', font: { family: 'Inter', size: 12, weight: 500 } } },
      tooltip: {
        titleFont: { family: 'Inter', size: 13 },
        bodyFont: { family: 'Inter', size: 12 },
        backgroundColor: 'rgba(34,37,39,0.95)',
        borderColor: 'rgba(54,59,60,0.8)',
        borderWidth: 1,
        padding: 12,
        cornerRadius: 6
      }
    },
    scales: {
      x: {
        ticks: { color: '#94A3B8', font: { family: 'Inter', size: 11 } },
        grid: { color: 'rgba(54,59,60,0.3)' }
      },
      y: {
        ticks: { color: '#94A3B8', font: { family: 'Inter', size: 11 } },
        grid: { color: 'rgba(54,59,60,0.3)' },
        beginAtZero: true
      }
    }
  };

  var pcd = {{ perf_chart_data | safe }};

  // Latency chart: TTFT and E2E
  new Chart(document.getElementById('chart-latency'), {
    type: 'bar',
    data: {
      labels: ['TTFT (PERF-1)', 'E2E Response (PERF-3)'],
      datasets: [
        { label: 'Clear (ms)', data: [pcd.ttft_clear, pcd.e2e_clear], backgroundColor: chartColors.clear, borderColor: chartColors.clearBorder, borderWidth: 1, borderRadius: 4 },
        { label: 'Encrypted (ms)', data: [pcd.ttft_enc, pcd.e2e_enc], backgroundColor: chartColors.enc, borderColor: chartColors.encBorder, borderWidth: 1, borderRadius: 4 }
      ]
    },
    options: defaultOpts
  });

  // Throughput + Footprint chart
  new Chart(document.getElementById('chart-throughput'), {
    type: 'bar',
    data: {
      labels: ['Throughput (tok/s) (PERF-2)', 'Model Size (GB) (PERF-4)', 'VRAM (GB) (PERF-5)'],
      datasets: [
        { label: 'Clear', data: [pcd.tp_clear, pcd.size_clear, pcd.vram_clear], backgroundColor: chartColors.clear, borderColor: chartColors.clearBorder, borderWidth: 1, borderRadius: 4 },
        { label: 'Encrypted', data: [pcd.tp_enc, pcd.size_enc, pcd.vram_enc], backgroundColor: chartColors.enc, borderColor: chartColors.encBorder, borderWidth: 1, borderRadius: 4 }
      ]
    },
    options: defaultOpts
  });
});
</script>
{% endif %}

{% if scale_chart_data %}
<script>
document.addEventListener('DOMContentLoaded', function() {
  var scd = {{ scale_chart_data | safe }};
  var chartColors = {
    clear: 'rgba(148, 163, 184, 0.85)',
    clearBorder: 'rgba(148, 163, 184, 1)',
    enc: 'rgba(223, 43, 59, 0.85)',
    encBorder: 'rgba(223, 43, 59, 1)',
  };
  var lineOpts = function(yLabel) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { labels: { color: '#94A3B8', font: { family: 'Inter', size: 12, weight: 500 } } },
        tooltip: {
          titleFont: { family: 'Inter', size: 13 },
          bodyFont: { family: 'Inter', size: 12 },
          backgroundColor: 'rgba(34,37,39,0.95)',
          borderColor: 'rgba(54,59,60,0.8)',
          borderWidth: 1, padding: 12, cornerRadius: 6
        }
      },
      scales: {
        x: {
          ticks: { color: '#94A3B8', font: { family: 'Inter', size: 11 } },
          grid: { color: 'rgba(54,59,60,0.3)' }
        },
        y: {
          title: { display: true, text: yLabel, color: '#94A3B8', font: { family: 'Inter', size: 11 } },
          ticks: { color: '#94A3B8', font: { family: 'Inter', size: 11 } },
          grid: { color: 'rgba(54,59,60,0.3)' },
          beginAtZero: true
        }
      }
    };
  };

  // SCALE-1: Concurrent — Throughput
  if (scd.concurrent && scd.concurrent.labels.length > 0) {
    new Chart(document.getElementById('chart-scale-concurrent'), {
      type: 'line',
      data: {
        labels: scd.concurrent.labels,
        datasets: [
          { label: 'Clear (tok/s)', data: scd.concurrent.clear_tp, borderColor: chartColors.clearBorder, backgroundColor: chartColors.clear, pointRadius: 5, pointHoverRadius: 7, fill: false, tension: 0.2 },
          { label: 'Encrypted (tok/s)', data: scd.concurrent.enc_tp, borderColor: chartColors.encBorder, backgroundColor: chartColors.enc, pointRadius: 5, pointHoverRadius: 7, fill: false, tension: 0.2 }
        ]
      },
      options: lineOpts('Throughput (tok/s)')
    });
  }

  // SCALE-1: Concurrent — Latency
  if (scd.concurrent && scd.concurrent.labels.length > 0) {
    new Chart(document.getElementById('chart-scale-concurrent-lat'), {
      type: 'line',
      data: {
        labels: scd.concurrent.labels,
        datasets: [
          { label: 'Clear (ms)', data: scd.concurrent.clear_lat, borderColor: chartColors.clearBorder, backgroundColor: chartColors.clear, pointRadius: 5, pointHoverRadius: 7, fill: false, tension: 0.2 },
          { label: 'Encrypted (ms)', data: scd.concurrent.enc_lat, borderColor: chartColors.encBorder, backgroundColor: chartColors.enc, pointRadius: 5, pointHoverRadius: 7, fill: false, tension: 0.2 }
        ]
      },
      options: lineOpts('Avg Latency (ms)')
    });
  }

  // SCALE-2: Context Length
  if (scd.context && scd.context.labels.length > 0) {
    new Chart(document.getElementById('chart-scale-context'), {
      type: 'line',
      data: {
        labels: scd.context.labels,
        datasets: [
          { label: 'Clear (ms)', data: scd.context.clear_lat, borderColor: chartColors.clearBorder, backgroundColor: chartColors.clear, pointRadius: 5, pointHoverRadius: 7, fill: false, tension: 0.2 },
          { label: 'Encrypted (ms)', data: scd.context.enc_lat, borderColor: chartColors.encBorder, backgroundColor: chartColors.enc, pointRadius: 5, pointHoverRadius: 7, fill: false, tension: 0.2 }
        ]
      },
      options: lineOpts('Latency (ms)')
    });
  }

  // SCALE-3: Batch Size
  if (scd.batch && scd.batch.labels.length > 0) {
    new Chart(document.getElementById('chart-scale-batch'), {
      type: 'bar',
      data: {
        labels: scd.batch.labels,
        datasets: [
          { label: 'Clear (tok/s)', data: scd.batch.clear_tp, backgroundColor: chartColors.clear, borderColor: chartColors.clearBorder, borderWidth: 1, borderRadius: 4 },
          { label: 'Encrypted (tok/s)', data: scd.batch.enc_tp, backgroundColor: chartColors.enc, borderColor: chartColors.encBorder, borderWidth: 1, borderRadius: 4 }
        ]
      },
      options: lineOpts('Throughput (tok/s)')
    });
  }

  // Experiment selector filter
  window.filterScaleChart = function(filter, btn) {
    // Toggle active button
    document.querySelectorAll('#scale-exp-selector .exp-btn').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');

    var cards = {
      concurrent: ['scale-concurrent-card', 'scale-concurrent-lat-card'],
      context: ['scale-context-card'],
      batch: ['scale-batch-card']
    };
    var allCards = [].concat(cards.concurrent, cards.context, cards.batch);

    if (filter === 'all') {
      allCards.forEach(function(id) { document.getElementById(id).style.display = ''; });
    } else {
      allCards.forEach(function(id) { document.getElementById(id).style.display = 'none'; });
      (cards[filter] || []).forEach(function(id) { document.getElementById(id).style.display = ''; });
    }
  };
});
</script>
{% endif %}

{% if acc_chart_data %}
<script>
document.addEventListener('DOMContentLoaded', function() {
  var acd = {{ acc_chart_data | safe }};
  var ctx = document.getElementById('chart-accuracy');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: acd.labels,
      datasets: [
        { label: 'Clear (reference)', data: acd.clear,
          backgroundColor: 'rgba(148,163,184,0.75)', borderColor: 'rgba(148,163,184,1)',
          borderWidth: 1, borderRadius: 4 },
        { label: 'Encrypted (via TEE)', data: acd.encrypted,
          backgroundColor: 'rgba(223,43,59,0.75)', borderColor: 'rgba(223,43,59,1)',
          borderWidth: 1, borderRadius: 4 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: '#AAB8C8', font: { family: 'Inter', size: 12, weight: 500 } } },
        tooltip: {
          backgroundColor: 'rgba(34,37,39,0.95)', borderColor: 'rgba(54,59,60,0.8)',
          borderWidth: 1, padding: 12, cornerRadius: 6,
          titleFont: { family: 'Inter', size: 13 }, bodyFont: { family: 'Inter', size: 12 }
        }
      },
      scales: {
        x: { ticks: { color: '#AAB8C8', font: { family: 'Inter', size: 11 } }, grid: { color: 'rgba(54,59,60,0.3)' } },
        y: { ticks: { color: '#AAB8C8', font: { family: 'Inter', size: 11 } }, grid: { color: 'rgba(54,59,60,0.3)' }, beginAtZero: true }
      }
    }
  });
});
</script>
{% endif %}

<script>
/* ── Summary charts: donut + category pass-rate bars ── */
document.addEventListener('DOMContentLoaded', function() {
  var passedN  = {{ passed_tests }};
  var failedN  = {{ failed_tests }};
  var skippedN = {{ skipped_tests }};

  var donutCtx = document.getElementById('chart-summary-donut');
  if (donutCtx && (passedN + failedN + skippedN) > 0) {
    new Chart(donutCtx, {
      type: 'doughnut',
      data: {
        labels: ['Pass', 'Fail', 'Skip'],
        datasets: [{
          data: [passedN, failedN, skippedN],
          backgroundColor: ['rgba(0,208,132,0.80)', 'rgba(239,68,68,0.80)', 'rgba(245,158,11,0.80)'],
          borderColor:      ['rgba(0,208,132,1)',    'rgba(239,68,68,1)',    'rgba(245,158,11,1)'],
          borderWidth: 2, hoverOffset: 6
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '68%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#AAB8C8', font: { family: 'Inter', size: 12 }, padding: 14,
              generateLabels: function(chart) {
                var ds = chart.data;
                return ds.labels.map(function(lbl, i) {
                  return { text: lbl + '  \u2014  ' + ds.datasets[0].data[i],
                    fillStyle: ds.datasets[0].backgroundColor[i],
                    strokeStyle: ds.datasets[0].borderColor[i],
                    lineWidth: 1, hidden: false, index: i };
                });
              }
            }
          },
          tooltip: {
            callbacks: { label: function(ctx) { return '  ' + ctx.label + ': ' + ctx.parsed; } },
            backgroundColor: 'rgba(34,37,39,0.95)', borderColor: 'rgba(54,59,60,0.8)',
            borderWidth: 1, padding: 10, cornerRadius: 6,
            titleFont: { family: 'Inter' }, bodyFont: { family: 'Inter', size: 12 }
          }
        }
      }
    });
  }

  /* Category horizontal bar chart */
  var catLabels = [{% for cat, tests in categories.items() %}"{{ category_labels[cat] | replace('"', '\\"') }}"{% if not loop.last %}, {% endif %}{% endfor %}];
  var catPass   = [{% for cat, tests in categories.items() %}{% set p = tests | selectattr("passed", "equalto", true) | rejectattr("skipped", "equalto", true) | list | length %}{% set s = tests | selectattr("skipped", "equalto", true) | list | length %}{% set den = (tests | length) - s %}{{ ((p / den * 100) | round(1)) if den > 0 else 0 }}{% if not loop.last %}, {% endif %}{% endfor %}];

  var barCtx = document.getElementById('chart-category-bars');
  if (barCtx && catLabels.length > 0) {
    new Chart(barCtx, {
      type: 'bar',
      data: {
        labels: catLabels,
        datasets: [{
          label: 'Pass Rate (%)',
          data: catPass,
          backgroundColor: catPass.map(function(v) {
            return v >= 100 ? 'rgba(0,208,132,0.75)' : v >= 70 ? 'rgba(245,158,11,0.75)' : 'rgba(239,68,68,0.75)';
          }),
          borderColor: catPass.map(function(v) {
            return v >= 100 ? 'rgba(0,208,132,1)' : v >= 70 ? 'rgba(245,158,11,1)' : 'rgba(239,68,68,1)';
          }),
          borderWidth: 1, borderRadius: 4
        }]
      },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: { label: function(ctx) { return '  Pass rate: ' + ctx.parsed.x.toFixed(1) + '%'; } },
            backgroundColor: 'rgba(34,37,39,0.95)', borderColor: 'rgba(54,59,60,0.8)',
            borderWidth: 1, padding: 10, cornerRadius: 6,
            titleFont: { family: 'Inter', size: 12 }, bodyFont: { family: 'Inter', size: 12 }
          }
        },
        scales: {
          x: {
            min: 0, max: 100,
            ticks: { color: '#AAB8C8', font: { family: 'Inter', size: 11 }, callback: function(v) { return v + '%'; } },
            grid: { color: 'rgba(54,59,60,0.3)' }
          },
          y: {
            ticks: { color: '#AAB8C8', font: { family: 'Inter', size: 11 } },
            grid: { display: false }
          }
        }
      }
    });
  }
});
</script>

{% if response_viewer_data %}
<script>
/* ── Response Viewer ── */
(function() {
  var rvData = {{ response_viewer_data | safe }};
  if (!rvData || rvData.length === 0) return;

  var catSelect = document.getElementById('rv-cat-select');
  var promptSelect = document.getElementById('rv-prompt-select');
  var counter = document.getElementById('rv-counter');
  var display = document.getElementById('rv-display');
  var promptBox = document.getElementById('rv-prompt-text');
  var clearBox = document.getElementById('rv-clear-text');
  var encBox = document.getElementById('rv-enc-text');
  var diffBox = document.getElementById('rv-diff-summary');

  // Build unique category list
  var cats = {};
  rvData.forEach(function(d) { cats[d.category] = true; });
  Object.keys(cats).sort().forEach(function(c) {
    var opt = document.createElement('option');
    opt.value = c;
    opt.textContent = c.charAt(0).toUpperCase() + c.slice(1);
    catSelect.appendChild(opt);
  });

  var filtered = rvData;

  window.rvFilterCategory = function() {
    var cat = catSelect.value;
    filtered = cat === 'all' ? rvData : rvData.filter(function(d) { return d.category === cat; });
    // Rebuild prompt dropdown
    promptSelect.innerHTML = '<option value="">— select a prompt (' + filtered.length + ' available) —</option>';
    filtered.forEach(function(d, i) {
      var opt = document.createElement('option');
      opt.value = i;
      var preview = d.prompt_text.substring(0, 80);
      if (d.prompt_text.length > 80) preview += '…';
      opt.textContent = '[' + d.category.toUpperCase().substring(0,4) + '] ' + d.prompt_id + ': ' + preview;
      promptSelect.appendChild(opt);
    });
    counter.textContent = filtered.length + ' prompts';
    display.style.display = 'none';
  };

  window.rvShowPrompt = function() {
    var idx = promptSelect.value;
    if (idx === '') { display.style.display = 'none'; return; }
    var d = filtered[parseInt(idx)];
    promptBox.textContent = d.prompt_text;
    clearBox.textContent = d.clear_response || '(no response)';
    encBox.textContent = d.encrypted_response || '(no response)';
    display.style.display = 'block';

    // Compute basic diff summary
    if (d.clear_response && d.encrypted_response) {
      var identical = d.clear_response === d.encrypted_response;
      if (identical) {
        diffBox.innerHTML = '<strong style="color:var(--success);">✓ Identical</strong> — clear and encrypted outputs match exactly.';
      } else {
        var cl = d.clear_response.length;
        var el = d.encrypted_response.length;
        // Find first difference position
        var minL = Math.min(cl, el);
        var firstDiff = minL;
        for (var j = 0; j < minL; j++) {
          if (d.clear_response[j] !== d.encrypted_response[j]) { firstDiff = j; break; }
        }
        diffBox.innerHTML =
          '<strong style="color:var(--warning);">≠ Different</strong> — ' +
          'clear length: ' + cl + ' chars, encrypted length: ' + el + ' chars. ' +
          'First difference at character ' + firstDiff + '.';
      }
      diffBox.style.display = 'block';
    } else {
      diffBox.style.display = 'none';
    }
  };

  // Initialize
  window.rvFilterCategory();
})();
</script>
{% endif %}

</body>
</html>
""")

_CATEGORY_LABELS = {
    "performance": "Performance Metrics (PERF-1 — PERF-5)",
    "accuracy": "Accuracy Metrics (ACC-1 — ACC-5)",
    "scalability": "Scalability Metrics (SCALE-1 — SCALE-4)",
    "security": "Security Validation (SEC-1 — SEC-6)",
    "serving": "Encrypted Serving Workflow (SERV-1 — SERV-7)",
    "training": "Training Metrics (T-1 — T-3)",
}

# ── Category-level descriptions rendered above each result table ──────────────
_CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "performance": (
        "Each metric is captured independently on the <strong>clear model</strong> (plaintext vLLM, port 8000) "
        "and the <strong>encrypted model</strong> (FHEnom TEE proxy &rarr; encrypted vLLM: TEE encrypts prompts, vLLM infers on encrypted data, TEE decrypts responses), "
        "then compared. The difference column shows the relative change — positive means "
        "the encrypted path is faster/better, negative means slower. "
        "<strong>No pass/fail threshold is applied</strong>: all results are informational baselines."
    ),
    "accuracy": (
        "Standard LLM benchmarks and semantic-similarity metrics are run on identical prompt sets against both "
        "the clear and encrypted model. The goal is to confirm that FHEnom's encryption layer does "
        "<em>not</em> alter model behaviour — the decryption pipeline inside the TEE must reproduce the "
        "original weights bit-for-bit. <strong>No pass/fail threshold is applied</strong>: "
        "any divergence from 0% accuracy delta is flagged in the details panel."
    ),
    "scalability": (
        "The encrypted serving stack is stressed along four independent axes: "
        "<strong>concurrency</strong> (1–50 simultaneous users), "
        "<strong>context length</strong> (512–8 192 tokens), "
        "<strong>batch size</strong> (1–32), and "
        "<strong>sustained operation</strong> (24-hour endurance). "
        "Results quantify how throughput and latency degrade (or hold) under load, "
        "relative to the clear-model baseline at the same concurrency level."
    ),
    "security": (
        "Six independent checks verify that FHEnom enforces end-to-end secrecy of the model weights: "
        "ciphertext-only storage on disk, ciphertext-only execution in GPU VRAM, "
        "TLS-enforced transport with plaintext rejection, cryptographic model binding in the TEE, "
        "per-tenant key isolation, and sanitised container logs. "
        "Each test attempts the relevant attack or inspection technique; a <strong>PASS</strong> means "
        "no sensitive material was observable."
    ),
    "serving": (
        "End-to-end workflow validation of the complete FHEnom serving stack — "
        "from encrypted model file integrity through TEE proxy startup to output fidelity and latency overhead. "
        "The seven tests cover: file hash verification, vLLM health, TEE status, inference coherence, "
        "bypass-attempt (encryption reality proof), output quality parity, and per-token FHE crypto overhead. "
        "All seven must <strong>PASS</strong> for the POC to be considered successful."
    ),
    "training": (
        "LoRA fine-tuning is executed on both the clear and the FHEnom-encrypted model using the same dataset "
        "and hyper-parameters. The three tests verify that: the training loss converges within budget, "
        "the saved adapter checkpoint passes FHEnom signature verification, and the fine-tuned encrypted model "
        "achieves accuracy within the configured tolerance of the clear fine-tuned model. "
        "This confirms FHEnom supports full supervised fine-tuning workflows without weight exposure."
    ),
}

# ── Per-test short descriptions (subtitle under the test name) ────────────────
_TEST_DESCRIPTIONS: dict[str, str] = {
    # Performance
    "PERF-1": "Time to first token (TTFT) — latency from request submission to the first generated token.",
    "PERF-2": "Throughput — sustained output tokens per second over the full benchmark prompt set.",
    "PERF-3": "End-to-end latency — total wall-clock time per request incl. FHE enc/dec overhead.",
    "PERF-4": "Model footprint — encrypted vs. clear model size on disk.",
    "PERF-5": "VRAM utilisation — GPU memory used by the encrypted and clear vLLM instances.",
    # Accuracy
    "ACC-1": "Deterministic equivalence — token-by-token exact match rate between clear and encrypted outputs on the same prompts.",
    "ACC-2": "lm-eval-harness benchmarks (MMLU, HellaSwag, GSM8K, HumanEval) — standard academic benchmarks run on both models.",
    "ACC-3": "Semantic consistency — BERTScore F1 between clear and encrypted model responses on identical prompts.",
    "ACC-4": "Response length consistency — statistical t-test comparing output character lengths between clear and encrypted.",
    "ACC-5": "Perplexity / log-likelihood — model confidence metric computed from token-level logprobs.",
    # Scalability
    "SCALE-1": "Concurrent users — throughput and latency at 1 / 5 / 10 / 20 / 50 simultaneous requests.",
    "SCALE-2": "Context length — performance sweep over prompts of 512 / 1K / 2K / 4K / 8K tokens.",
    "SCALE-3": "Batch size — throughput scaling for batch sizes 1 / 4 / 8 / 16 / 32.",
    "SCALE-4": "Sustained operation — 24-hour continuous load test measuring stability and error rate.",
    # Security
    "SEC-1": "Encryption at rest — model weights stored as FHE ciphertext on disk; no plaintext .safetensors accessible.",
    "SEC-2": "Encrypted execution — VRAM contains only ciphertext during inference; no plaintext weight pages observable.",
    "SEC-3": "Secure transport — all client traffic must use TLS; plaintext requests are rejected at the TEE boundary.",
    "SEC-4": "Model binding — TEE refuses to serve a model whose cryptographic signature does not match the registered ID.",
    "SEC-5": "Key isolation — tenant decryption keys are scoped per model ID; cross-model reuse returns an error.",
    "SEC-6": "Logging safety — no token, weight, or key material appears in any accessible container log.",
    # Serving
    "SERV-1": "Encrypted model file integrity — verifies presence of .safetensors, config.json, tokenizer files, and minimum size.",
    "SERV-2": "vLLM server health — encrypted vLLM must respond HTTP 200 on /health before the TEE proxy starts.",
    "SERV-3": "TEE serving status — FHEnom admin API must report the model as SERVING after fhenomai serve start.",
    "SERV-4": "TEE inference coherence — TEE must return valid completions for geography, science, and code prompts.",
    "SERV-5": "Bypass test (encryption reality proof) — direct vLLM requests that skip the TEE must return garbled ciphertext.",
    "SERV-6": "Output fidelity — SequenceMatcher similarity between TEE-routed and clear-model responses must exceed threshold.",
    "SERV-7": "FHE overhead — per-token encryption and decryption latency at the TEE boundary must stay below configured limits.",
    # Training
    "T-1": "Secure checkpoints — encrypted LoRA adapter weights must pass FHEnom signature verification.",
    "T-2": "Convergence — fine-tuning loss must reach the target threshold within the configured epoch budget.",
    "T-3": "Post-training inference quality — fine-tuned encrypted model must match the clear fine-tuned model within tolerance.",
}

# ── Per-test expandable metric explanations ───────────────────────────────────
_METRIC_EXPLANATIONS: dict[str, str] = {
    "PERF-1": (
        '<h4>Time to First Token (TTFT)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'TTFT captures the latency from the moment the HTTP request is dispatched '
        'to the instant the first generated token arrives in the streaming response. '
        'It reflects model initialization, KV-cache warm-up, and network round-trip overhead.</div>'
        '<div class="me-section"><div class="me-label">Clear model measurement</div>'
        'Streaming HTTP POST to <code>http://GPU:8000/v1/completions</code> with <code>stream: true</code>. '
        'A <code>time.perf_counter()</code> clock starts at request dispatch. '
        'The first SSE <code>data:</code> chunk containing non-empty text stops the clock. '
        'Result: <code>time_to_first_token_ms</code> per-request, averaged over all prompts.</div>'
        '<div class="me-section"><div class="me-label">Encrypted model measurement</div>'
        'Streaming HTTPS POST to <code>https://TEE:9999/v1/completions</code> (FHEnom TEE proxy). '
        'Identical timing method: request dispatch → first SSE chunk with text. '
        'The encrypted path includes: TLS handshake, TEE proxy processing, FHE encryption of the prompt, '
        'forwarding to the encrypted vLLM backend, and FHE decryption of the first response token.</div>'
        '<div class="me-section"><div class="me-label">Difference interpretation</div>'
        'Formula: <code>diff = (clear − encrypted) / clear × 100%</code>. '
        'Positive = encrypted is faster (lower TTFT); negative = encrypted is slower. '
        'A small negative value is expected due to the additional TEE network hop and FHE crypto overhead.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Both paths use the same streaming SSE parser, identical prompt set, matching <code>max_tokens</code> / '
        '<code>temperature</code> settings, and measure wall-clock time with <code>time.perf_counter()</code>. '
        'The encrypted path includes TEE network latency — this is intentional, as it represents the real-world '
        'experience for a client connecting through FHEnom.</div>'
    ),
    "PERF-2": (
        '<h4>Throughput (Tokens per Second)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Average output generation speed across all benchmark prompts, measured in tokens per second per request. '
        'This reflects the model\'s sustained generation rate including all pipeline overhead.</div>'
        '<div class="me-section"><div class="me-label">Clear model measurement</div>'
        'For each prompt, <code>tokens_per_second = tokens_generated / (total_time_ms / 1000)</code> '
        'where <code>tokens_generated</code> comes from the vLLM usage field and <code>total_time_ms</code> '
        'is wall-clock time of the full streaming response via <code>http://GPU:8000/v1/completions</code>. '
        'Final value: arithmetic mean across all prompts.</div>'
        '<div class="me-section"><div class="me-label">Encrypted model measurement</div>'
        'Identical formula, but requests go through <code>https://TEE:9999/v1/completions</code>. '
        'The TEE proxy adds FHE encryption of the prompt and decryption of the response, so total_time_ms includes crypto overhead. '
        'Token count comes from the TEE-proxied usage field.</div>'
        '<div class="me-section"><div class="me-label">Difference interpretation</div>'
        'Formula: <code>diff = (encrypted − clear) / clear × 100%</code>. '
        'Positive = encrypted is faster (higher throughput); negative = encrypted is slower. '
        'Values near zero indicate minimal FHE impact on generation speed.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Same prompt set, same max_tokens, same temperature, same measurement approach. '
        'Both measure per-request token rate. The encrypted path\'s total_time_ms naturally includes '
        'the FHE overhead, giving a fair comparison of real-world throughput.</div>'
    ),
    "PERF-3": (
        '<h4>End-to-End Response Time</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Total wall-clock time from sending the request to receiving the complete response (all tokens generated). '
        'This is the most important user-facing latency metric.</div>'
        '<div class="me-section"><div class="me-label">Clear model measurement</div>'
        'Timed with <code>time.perf_counter()</code> around the full streaming response from '
        '<code>http://GPU:8000/v1/completions</code>. Starts at request dispatch, ends when the '
        '<code>[DONE]</code> SSE event is received. Average across all prompts in the benchmark set.</div>'
        '<div class="me-section"><div class="me-label">Encrypted model measurement</div>'
        'Identical timing around the streaming response from <code>https://TEE:9999/v1/completions</code>. '
        'Includes the full chain: TLS → TEE proxy → FHE encrypt prompt → encrypted vLLM inference → FHE decrypt response → client.</div>'
        '<div class="me-section"><div class="me-label">Difference interpretation</div>'
        'Formula: <code>diff = (clear − encrypted) / clear × 100%</code>. '
        'Positive = encrypted is faster; negative = encrypted is slower. '
        'The E2E time integrates all latency sources: TTFT, token generation, network, and crypto.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Both use the same streaming pipeline, same prompts, same parameters. '
        'The difference isolates the total impact of FHEnom encryption on the complete request lifecycle.</div>'
    ),
    "PERF-4": (
        '<h4>Model Footprint (Disk Size)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Total size of the model directory on disk, comparing the plaintext model against the FHE-encrypted version.</div>'
        '<div class="me-section"><div class="me-label">Clear model measurement</div>'
        'Runs <code>du -sb</code> on the clear model directory (e.g., <code>Llama-3.2-1B-Instruct/</code>) '
        'on the GPU host via SSH. Includes all files: safetensors, config, tokenizer, etc.</div>'
        '<div class="me-section"><div class="me-label">Encrypted model measurement</div>'
        'Runs <code>du -sb</code> on the encrypted model directory (e.g., <code>Llama-3.2-1B-Instruct-encrypted/</code>). '
        'FHE ciphertext expansion typically makes the encrypted model 1.2–1.5× larger.</div>'
        '<div class="me-section"><div class="me-label">Difference interpretation</div>'
        'Shown as the ratio <code>encrypted_size / clear_size</code>. '
        'A value of 1.21 means the encrypted model is 21% larger. '
        'This overhead reflects the FHE ciphertext expansion factor.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Both measurements use the same <code>du -sb</code> command on the same GPU host. '
        'The same model architecture is used with identical configuration files — only the weight tensors differ.</div>'
    ),
    "PERF-5": (
        '<h4>GPU Memory (VRAM) Utilization</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'GPU memory consumed by the vLLM process when serving the model, '
        'comparing clear vs. encrypted model VRAM usage.</div>'
        '<div class="me-section"><div class="me-label">Clear model measurement</div>'
        'Runs <code>nvidia-smi --query-gpu=memory.used</code> on the GPU host via SSH '
        'while the clear model is loaded in vLLM. Reports total VRAM used (includes OS/driver overhead).</div>'
        '<div class="me-section"><div class="me-label">Encrypted model measurement</div>'
        'Same <code>nvidia-smi</code> query while the encrypted model is loaded. '
        'FHEnom operates at the weight level — the encrypted safetensors are loaded into vLLM as-is. '
        'The TEE encrypts the prompt before sending it to vLLM and decrypts the response on the way back, '
        'so VRAM usage should be similar to the clear model.</div>'
        '<div class="me-section"><div class="me-label">Difference interpretation</div>'
        'Shown as <code>encrypted_VRAM − clear_VRAM</code> in MB. '
        'Small differences (< 100 MB) are noise from driver/runtime allocation. '
        'Large differences would indicate the encrypted format requires significantly more GPU memory.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Both measurements taken with exactly one vLLM instance running, same GPU, same <code>nvidia-smi</code> call. '
        'The <code>--gpu-memory-utilization</code> vLLM flag is identical for both runs.</div>'
    ),
    "ACC-1": (
        '<h4>Deterministic Equivalence (FP32)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'The exact token-by-token match rate between clear and encrypted model outputs when given identical prompts. '
        'This validates that FHEnom encryption is transparent — the TEE encrypts the prompt, vLLM processes it '
        'against encrypted weights, and the TEE decrypts the response, yielding identical output to the clear model.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'The same prompt set is sent to both models with <code>temperature=0</code> (deterministic). '
        'For each prompt pair, the output text strings are compared character-by-character. '
        'If they match exactly, it counts as an "exact match".</div>'
        '<div class="me-section"><div class="me-label">Why it may not be 100%</div>'
        'With <code>temperature=0</code>, vLLM uses greedy decoding, but floating-point arithmetic order can differ '
        'between runs due to GPU parallelism, non-deterministic CUDA kernels, or batching differences. '
        'A 10–30% exact match rate is typical even for the same model across two separate runs.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Identical prompts, same temperature, same max_tokens. The clear model is queried via '
        '<code>/v1/completions</code> directly; the encrypted model via the TEE proxy. '
        'Both use the same vLLM engine and model architecture.</div>'
    ),
    "ACC-2": (
        '<h4>Functional Equivalence (lm-eval-harness)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Standard academic benchmarks (MMLU, HellaSwag, GSM8K, HumanEval) run against both models '
        'using the <code>lm-eval-harness</code> framework. This validates that encryption does not degrade '
        'the model\'s reasoning, knowledge, or code generation capabilities.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'The <code>lm_eval</code> CLI connects to the vLLM-compatible <code>/v1/completions</code> endpoint '
        '(clear: direct, encrypted: via TEE) and runs each benchmark task. '
        'Scores are reported per-task and compared.</div>'
        '<div class="me-section"><div class="me-label">When skipped</div>'
        'This test requires <code>pip install lm-eval</code> which is not always installed in the test environment. '
        'When skipped, the other accuracy tests (ACC-1, ACC-3, ACC-4, ACC-5) still provide comprehensive accuracy validation.</div>'
    ),
    "ACC-3": (
        '<h4>Semantic Consistency (BERTScore)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'BERTScore F1 measures how semantically similar the encrypted model\'s outputs are to the clear model\'s outputs. '
        'Unlike exact match, it captures meaning-preserving paraphrases and minor wording differences.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'Clear outputs are used as references; encrypted outputs as candidates. '
        'BERTScore computes precision, recall, and F1 using contextual embeddings from a pre-trained BERT model. '
        'If <code>bert_score</code> is not installed, a <code>SequenceMatcher</code>-based character-level similarity is used as fallback.</div>'
        '<div class="me-section"><div class="me-label">Difference interpretation</div>'
        'F1 ≥ 0.90 indicates high semantic similarity; F1 ≥ 0.95 indicates near-identical meaning. '
        'Values below 0.85 would suggest the encryption layer is altering model behaviour.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Same prompts, same generation parameters. Clear model queried directly; encrypted model via TEE proxy. '
        'Both outputs are generated independently with identical settings.</div>'
    ),
    "ACC-4": (
        '<h4>Response Length Consistency</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Whether the encrypted model produces responses of statistically similar length to the clear model, '
        'validating that the generation process (including stopping criteria) is unaffected by encryption.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'For each prompt, the character length of the output is recorded. '
        'A two-sample Welch\'s t-test (<code>scipy.stats.ttest_ind</code>) compares the length distributions. '
        'The test statistic <code>t</code> and p-value <code>p</code> are reported.</div>'
        '<div class="me-section"><div class="me-label">Difference interpretation</div>'
        'A high p-value (> 0.05) means there is no statistically significant difference in response lengths — '
        'the null hypothesis (same distribution) cannot be rejected. '
        'A low p-value would suggest systematic length differences caused by the encryption layer.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Same prompts, same max_tokens, same temperature. Both models use the same architecture and tokenizer.</div>'
    ),
    "ACC-5": (
        '<h4>Perplexity / Log-Likelihood</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Perplexity quantifies model confidence: lower perplexity means the model is more confident in its token predictions. '
        'Computed from token-level log-probabilities returned by the /v1/completions endpoint.</div>'
        '<div class="me-section"><div class="me-label">Clear model</div>'
        'Requests include <code>logprobs=1</code>. For each token, the log-probability is extracted. '
        'Perplexity = <code>exp(−mean(logprobs))</code> per prompt, then averaged across all prompts.</div>'
        '<div class="me-section"><div class="me-label">Encrypted model (TEE limitation)</div>'
        'The FHEnom TEE proxy does not currently support the <code>logprobs</code> parameter — its pydantic schema '
        'rejects non-None logprobs. Therefore, encrypted perplexity is reported as N/A. '
        'This is a known TEE limitation, not a failure of the encryption layer.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'When logprobs are available on both sides, the diff formula is: '
        '<code>(clear_ppl − enc_ppl) / clear_ppl × 100%</code>. Currently only clear-side perplexity is computed.</div>'
    ),
    "SCALE-1": (
        '<h4>Concurrent User Load</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'How throughput and latency scale as simultaneous users increase (1, 5, 10, 20, 50). '
        'Tests the system\'s ability to handle production-level load.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'For each concurrency level, N requests are dispatched in parallel using async HTTP. '
        'Wall time, total tokens, aggregate throughput (tok/s), and average per-request latency are recorded. '
        'Both clear and encrypted models are tested at the same concurrency levels.</div>'
        '<div class="me-section"><div class="me-label">Comparability</div>'
        'Same prompts, same concurrency levels, same max_tokens. The encrypted path includes '
        'TEE proxy overhead per request.</div>'
    ),
    "SCALE-2": (
        '<h4>Context Length Scaling</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'How performance changes as input prompt length increases (512, 1K, 2K, 4K, 8K tokens). '
        'Validates that the FHE overhead does not grow disproportionately with context size.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'Prompts are padded to target token counts. Each context length is tested on both models. '
        'Throughput and latency are measured per context length.</div>'
    ),
    "SCALE-3": (
        '<h4>Batch Processing</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Throughput scaling as batch size increases (1, 4, 8, 16, 32). '
        'Tests how efficiently vLLM batches requests for both clear and encrypted models.</div>'
    ),
    "SCALE-4": (
        '<h4>Sustained Operation</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Long-running stability test (24h full, abbreviated to ~3min for quick-run mode). '
        'Measures throughput degradation, error rate, and memory leaks over time.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'Continuous requests are sent at steady rate. Throughput is measured in windows and compared '
        'between start and end. A degradation > 20% would indicate stability issues.</div>'
    ),
    "SEC-1": (
        '<h4>Encryption at Rest</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Verifies that the encrypted model\'s weight data on disk is true ciphertext — '
        'no plaintext weight values, tensor names, or model architecture patterns are detectable '
        'in the binary data section of the .safetensors file.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'The safetensors header is parsed to find the data offset. '
        'Then <code>grep</code> searches the data section for patterns like '
        '<code>torch.FloatTensor</code>, <code>weight[</code>, <code>model.layers.</code>, '
        '<code>lm_head.weight</code>, <code>embed_tokens</code>, <code>self_attn</code>. '
        'Shannon entropy is also computed on the first 1 MB — high entropy (> 7.5) indicates encryption.</div>'
    ),
    "SEC-2": (
        '<h4>Encrypted Execution (RAM/GPU)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Checks that no plaintext model weights are visible in the vLLM process\'s memory maps '
        'or GPU VRAM while serving the encrypted model.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'Inspects <code>/proc/{pid}/maps</code> of the vLLM container process for tensor-related strings. '
        'Also checks <code>nvidia-smi</code> for GPU memory isolation.</div>'
    ),
    "SEC-3": (
        '<h4>Secure Transport</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Validates that the TEE endpoint uses HTTPS, and that no plaintext model data is visible in network traffic.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'Verifies the TEE user endpoint URL scheme is <code>https://</code>. '
        'Runs <code>tcpdump</code> to capture packets on port 9999 during inference and checks for plaintext patterns.</div>'
    ),
    "SEC-4": (
        '<h4>Model Binding</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Confirms the encrypted model cannot be loaded or used outside the FHEnom ecosystem — '
        'attempting to load it with standard HuggingFace <code>AutoModelForCausalLM</code> should fail.</div>'
    ),
    "SEC-5": (
        '<h4>Key Isolation</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Checks that no decryption keys, secrets, or tokens are exposed on the GPU host via '
        'environment variables, docker config, or accessible files.</div>'
    ),
    "SEC-6": (
        '<h4>Logging Safety</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Verifies container logs and system journals contain no plaintext weight data, token values, '
        'or decryption key material.</div>'
    ),
    "SERV-1": (
        '<h4>Encrypted Model File Integrity</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Verifies the encrypted model directory contains all required files: at least one .safetensors weight file, '
        'config.json, tokenizer.json, tokenizer_config.json, special_tokens_map.json, and minimum total size ≥ 1.5 GB.</div>'
    ),
    "SERV-2": (
        '<h4>vLLM Server Health</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Confirms the encrypted vLLM instance is responding to health checks (<code>/health</code> endpoint via SSH curl) '
        'before the TEE proxy begins routing inference traffic.</div>'
    ),
    "SERV-3": (
        '<h4>TEE Serving Status</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Verifies the FHEnom TEE proxy acknowledges the encrypted model and is ready to serve inference. '
        'Checks the user-facing <code>/v1/models</code> endpoint for the model name.</div>'
    ),
    "SERV-4": (
        '<h4>TEE Inference Coherence</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Validates that the TEE-proxied encrypted model produces coherent English text — not garbled bytes. '
        'Three domain-specific probes (geography, science, programming) are checked for a space ratio ≥ 0.08, '
        'which indicates readable English text.</div>'
    ),
    "SERV-5": (
        '<h4>Encryption Reality Proof (Bypass Test)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'The most important security validation: queries sent directly to the encrypted vLLM (bypassing the TEE) '
        'must return garbled, non-sensical output — proving the model weights are truly encrypted and unusable '
        'without the TEE to encrypt the prompt and decrypt the response.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'The same geography/science/programming prompts are sent to <code>http://GPU:8000/v1/completions</code> '
        'using the encrypted model name. The output\'s space ratio is checked: < 0.04 means garbled bytes (pass).</div>'
    ),
    "SERV-6": (
        '<h4>TEE vs Clear Model Output Fidelity</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Compares the TEE-proxied encrypted model\'s outputs against the clear model\'s outputs using '
        'Python\'s <code>difflib.SequenceMatcher</code>. A similarity ratio ≥ 0.7 indicates high fidelity.</div>'
        '<div class="me-section"><div class="me-label">How it works</div>'
        'During Phase 1, clear-model reference outputs are collected for 3 probes (geo, sci, prog). '
        'During Phase 4, the TEE model\'s outputs for the same prompts are compared character-by-character. '
        'The divergence point is shown in the details.</div>'
    ),
    "SERV-7": (
        '<h4>FHE Overhead (Encryption/Decryption Latency)</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'The per-token encryption and decryption time at the TEE boundary, measured by timing '
        'multiple completions and subtracting the vLLM processing time. '
        'Thresholds: enc < 10ms/token, dec < 5ms/token.</div>'
    ),
    "T-1": (
        '<h4>Secure Checkpoints</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Validates that fine-tuning checkpoints saved by the encrypted model are themselves encrypted, '
        'preventing weight exfiltration through training artifacts.</div>'
    ),
    "T-2": (
        '<h4>Convergence</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'Compares training loss curves between clear and encrypted fine-tuning runs to verify '
        'that the encrypted model converges at a similar rate.</div>'
    ),
    "T-3": (
        '<h4>Post-Training Inference Quality</h4>'
        '<div class="me-section"><div class="me-label">What it measures</div>'
        'After fine-tuning, compares inference quality between the clear and encrypted fine-tuned models '
        'to confirm encryption did not degrade the learned capabilities.</div>'
    ),
}

# Keys to redact from the config block in the report
_REDACT_KEYS = {
    "tee_admin_token", "tee_user_token",
    "gpu_ssh_key", "tee_ssh_key",
}


def _fmt_cell(val: Any, max_len: int = 80) -> str:
    """Format a result value for a table cell."""
    if val is None:
        return "—"
    if isinstance(val, dict):
        if not val:
            return "—"
        n = len(val)
        return f"{n} measurement{'s' if n != 1 else ''} (see details ▸)"
    if isinstance(val, list):
        if not val:
            return "—"
        return f"{len(val)} item{'s' if len(val) != 1 else ''} (see details ▸)"
    s = str(val)
    if len(s) > max_len:
        return s[:max_len - 1] + "…"
    return s


def _redact_cfg(raw: dict) -> dict:
    """Return a copy of the config dict with sensitive values masked."""
    import copy
    out = copy.deepcopy(raw)
    for key in _REDACT_KEYS:
        if key in out:
            out[key] = "***"
    return out


def _extract_perf_chart_data(results: list[TestResult]) -> dict | None:
    """Extract numeric values from PERF-1..5 results for Chart.js."""
    perf = {r.test_id: r for r in results if r.test_id.startswith("PERF-")}
    if not perf:
        return None

    def _num(val: Any) -> float:
        if val is None:
            return 0
        if isinstance(val, (int, float)):
            return float(val)
        s = str(val).replace(",", "").strip()
        for token in s.split():
            try:
                return float(token)
            except ValueError:
                continue
        return 0

    p1 = perf.get("PERF-1")
    p2 = perf.get("PERF-2")
    p3 = perf.get("PERF-3")
    p4 = perf.get("PERF-4")
    p5 = perf.get("PERF-5")

    return {
        "ttft_clear": round(_num(p1.clear_value), 1) if p1 else 0,
        "ttft_enc": round(_num(p1.encrypted_value), 1) if p1 else 0,
        "tp_clear": round(_num(p2.clear_value), 1) if p2 else 0,
        "tp_enc": round(_num(p2.encrypted_value), 1) if p2 else 0,
        "e2e_clear": round(_num(p3.clear_value), 1) if p3 else 0,
        "e2e_enc": round(_num(p3.encrypted_value), 1) if p3 else 0,
        "size_clear": round(_num(p4.clear_value), 2) if p4 else 0,
        "size_enc": round(_num(p4.encrypted_value), 2) if p4 else 0,
        "vram_clear": round(_num(p5.clear_value) / 1024, 1) if p5 else 0,
        "vram_enc": round(_num(p5.encrypted_value) / 1024, 1) if p5 else 0,
    }


def _extract_scale_chart_data(results: list[TestResult]) -> dict | None:
    """Extract scalability data from SCALE-1..3 raw results for Chart.js.

    Returns a dict with keys 'concurrent', 'context', 'batch', each containing
    'labels', 'clear_tp', 'enc_tp', 'clear_lat', 'enc_lat' arrays.
    """
    scale = {r.test_id: r for r in results if r.test_id.startswith("SCALE-")}
    if not scale:
        return None

    data: dict[str, Any] = {}

    # SCALE-1: Concurrent load — raw_data has clear_value/encrypted_value as dicts
    s1 = scale.get("SCALE-1")
    if s1 and isinstance(s1.clear_value, dict) and isinstance(s1.encrypted_value, dict):
        labels = sorted(set(s1.clear_value.keys()) | set(s1.encrypted_value.keys()))
        data["concurrent"] = {
            "labels": [str(n) for n in labels],
            "clear_tp": [round(s1.clear_value.get(n, {}).get("throughput", 0), 1) for n in labels],
            "enc_tp": [round(s1.encrypted_value.get(n, {}).get("throughput", 0), 1) for n in labels],
            "clear_lat": [round(s1.clear_value.get(n, {}).get("avg_latency_ms", 0), 1) for n in labels],
            "enc_lat": [round(s1.encrypted_value.get(n, {}).get("avg_latency_ms", 0), 1) for n in labels],
        }

    # SCALE-2: Context length
    s2 = scale.get("SCALE-2")
    if s2 and isinstance(s2.clear_value, dict) and isinstance(s2.encrypted_value, dict):
        labels = sorted(set(s2.clear_value.keys()) | set(s2.encrypted_value.keys()))
        data["context"] = {
            "labels": [str(n) for n in labels],
            "clear_lat": [round(s2.clear_value.get(n, {}).get("avg_latency_ms", 0), 1) for n in labels],
            "enc_lat": [round(s2.encrypted_value.get(n, {}).get("avg_latency_ms", 0), 1) for n in labels],
        }

    # SCALE-3: Batch size
    s3 = scale.get("SCALE-3")
    if s3 and isinstance(s3.clear_value, dict) and isinstance(s3.encrypted_value, dict):
        labels = sorted(set(s3.clear_value.keys()) | set(s3.encrypted_value.keys()))
        data["batch"] = {
            "labels": [str(n) for n in labels],
            "clear_tp": [round(s3.clear_value.get(n, {}).get("throughput", 0), 1) for n in labels],
            "enc_tp": [round(s3.encrypted_value.get(n, {}).get("throughput", 0), 1) for n in labels],
        }

    return data if data else None


def _extract_acc_chart_data(results: list[TestResult]) -> dict | None:
    """Extract accuracy test values for Chart.js bar chart.

    Returns a dict with 'labels', 'clear', 'encrypted' lists.
    All values are normalised to a common numeric scale per metric.
    """
    acc = {r.test_id: r for r in results if r.test_id.startswith("ACC-")}
    if not acc:
        return None

    labels: list[str] = []
    clear_vals: list[float] = []
    enc_vals: list[float] = []

    # ACC-1: Exact-match rate  (0–100 %)
    a1 = acc.get("ACC-1")
    if a1 and not a1.skipped and a1.clear_value is not None:
        try:
            cv = str(a1.clear_value)  # e.g. "3 outputs"
            ev = str(a1.encrypted_value or "0 exact matches")
            total = int(cv.split()[0]) if cv and cv[0].isdigit() else 0
            exact = int(ev.split()[0]) if ev and ev[0].isdigit() else 0
            if total > 0:
                labels.append("Exact Match %")
                clear_vals.append(100.0)  # clear vs clear = 100 %
                enc_vals.append(round(exact / total * 100, 1))
        except (ValueError, IndexError):
            pass

    # ACC-3: Semantic similarity F1  (0–1 expressed as 0–100 %)
    a3 = acc.get("ACC-3")
    if a3 and not a3.skipped and a3.encrypted_value is not None:
        try:
            ev = str(a3.encrypted_value)  # "BERTScore F1 = 0.8523" or "char-similarity = 0.7812"
            val = float(ev.split("=")[-1].strip())
            labels.append("Semantic Similarity (F1 ×100)")
            clear_vals.append(100.0)
            enc_vals.append(round(val * 100, 1))
        except (ValueError, IndexError):
            pass

    # ACC-4: Avg response length (chars)
    a4 = acc.get("ACC-4")
    if a4 and not a4.skipped and a4.clear_value and a4.encrypted_value:
        try:
            cv = str(a4.clear_value)   # "avg=150.3 chars"
            ev = str(a4.encrypted_value)  # "avg=12.0 chars"
            clear_avg = float(cv.split("=")[1].split()[0])
            enc_avg   = float(ev.split("=")[1].split()[0])
            if clear_avg > 0:
                labels.append("Avg Response Length (chars)")
                clear_vals.append(round(clear_avg, 1))
                enc_vals.append(round(enc_avg, 1))
        except (ValueError, IndexError):
            pass

    # ACC-5: Perplexity (lower = better; show clear only, 0 for encrypted N/A)
    a5 = acc.get("ACC-5")
    if a5 and not a5.skipped and a5.clear_value is not None:
        try:
            clear_ppl = float(str(a5.clear_value))
            ev = str(a5.encrypted_value or "")
            enc_ppl = 0.0 if "N/A" in ev else float(ev) if ev else 0.0
            labels.append("Perplexity (lower = better)")
            clear_vals.append(round(clear_ppl, 2))
            enc_vals.append(round(enc_ppl, 2))
        except (ValueError, TypeError):
            pass

    if not labels:
        return None
    return {"labels": labels, "clear": clear_vals, "encrypted": enc_vals}


def generate_report(results: list[TestResult], cfg: Config,
                    output_dir: Path | str, *,
                    response_data: list[dict] | None = None) -> Path:
    """Generate an HTML report from test results."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Group by category, formatting complex cell values
    categories: dict[str, list[dict]] = {}
    for r in results:
        cat = r.category
        if cat not in categories:
            categories[cat] = []
        d = r.to_dict()
        d["clear_value"] = _fmt_cell(d.get("clear_value"))
        d["encrypted_value"] = _fmt_cell(d.get("encrypted_value"))
        categories[cat].append(d)

    total = len(results)
    passed = sum(1 for r in results if r.passed and not r.skipped)
    skipped = sum(1 for r in results if r.skipped)
    failed = total - passed - skipped

    # Extract perf chart data
    perf_chart_data = _extract_perf_chart_data(results)

    # Extract scale chart data (needs raw TestResult objects, not formatted)
    scale_chart_data = _extract_scale_chart_data(results)

    # Extract accuracy chart data
    acc_chart_data = _extract_acc_chart_data(results)

    import yaml
    config_yaml = yaml.dump(
        _redact_cfg(cfg.raw), default_flow_style=False, sort_keys=False
    )

    html = _HTML_TEMPLATE.render(
        customer=cfg.get("customer_name", ""),
        model_name=cfg.model_name,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC"),
        poc_id=cfg.get("poc_id", ""),
        total_tests=total,
        passed_tests=passed,
        failed_tests=failed,
        skipped_tests=skipped,
        pass_rate=round(passed / (total - skipped) * 100, 1) if (total - skipped) > 0 else 0,
        categories=categories,
        category_labels=_CATEGORY_LABELS,
        category_descriptions=_CATEGORY_DESCRIPTIONS,
        test_descriptions=_TEST_DESCRIPTIONS,
        metric_explanations=_METRIC_EXPLANATIONS,
        config_yaml=config_yaml,
        perf_chart_data=json.dumps(perf_chart_data) if perf_chart_data else None,
        scale_chart_data=json.dumps(scale_chart_data) if scale_chart_data else None,
        acc_chart_data=json.dumps(acc_chart_data) if acc_chart_data else None,
        response_viewer_data=json.dumps(response_data) if response_data else None,
        version="0.1.0",
    )

    report_path = output_dir / f"poc_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    report_path.write_text(html, encoding="utf-8")
    log.info("Report generated: %s", report_path)

    # Also save raw JSON
    json_path = output_dir / f"poc_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(json_path, "w") as f:
        json.dump([r.to_dict() for r in results], f, indent=2, default=str)
    log.info("Raw results saved: %s", json_path)

    return report_path
