"""Configuration loader — merges default.yaml with overrides."""

from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any

import yaml


_DEFAULT_CFG = Path(__file__).resolve().parent / "data" / "default.yaml"


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base* (non-destructive)."""
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


class Config:
    """Immutable-ish wrapper around the YAML config dictionary."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    # ── Convenience accessors ───────────────────────────────────
    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    @property
    def gpu_host(self) -> str:
        return self._data["gpu_host"]

    @property
    def tee_host(self) -> str:
        return self._data["tee_host"]

    @property
    def model_name(self) -> str:
        return self._data["model_name"]

    @property
    def encrypted_model_name(self) -> str:
        """The served-model-name used for the encrypted vLLM + TEE display name."""
        return self._data.get("encrypted_model_name", self._data["model_name"])

    @property
    def vllm_base_url(self) -> str:
        return f"http://{self.gpu_host}:{self._data['vllm_port']}"

    @property
    def vllm_enc_url(self) -> str:
        """HTTP base URL for the vLLM instance serving the encrypted model."""
        return f"http://{self.gpu_host}:{self._data['vllm_port']}"

    @property
    def vllm_clear_url(self) -> str:
        """HTTP base URL for the vLLM instance serving the clear (plaintext) model.

        Both clear and encrypted models share port 8000 and are run sequentially,
        so this returns the same URL as vllm_enc_url.
        """
        return f"http://{self.gpu_host}:{self._data['vllm_port']}"

    @property
    def tee_user_url(self) -> str:
        return f"https://{self.tee_host}:{self._data['tee_user_port']}"

    @property
    def tee_admin_url(self) -> str:
        return f"https://{self.tee_host}:{self._data['tee_admin_port']}"

    @property
    def output_dir(self) -> Path:
        return Path(self._data["output_dir"])

    @property
    def raw(self) -> dict[str, Any]:
        return copy.deepcopy(self._data)

    def __repr__(self) -> str:
        return f"Config({self.model_name}@{self.gpu_host})"


def load_config(override_path: str | Path | None = None,
                cli_overrides: dict[str, Any] | None = None) -> Config:
    """Load configuration from default.yaml → optional user override → CLI flags."""
    with open(_DEFAULT_CFG) as f:
        base = yaml.safe_load(f)

    if override_path:
        with open(override_path) as f:
            user = yaml.safe_load(f) or {}
        base = _deep_merge(base, user)

    if cli_overrides:
        # Flatten dot-notation keys: "perf.ttft_tolerance_pct" → nested dict
        nested: dict[str, Any] = {}
        for key, value in cli_overrides.items():
            parts = key.split(".")
            d = nested
            for p in parts[:-1]:
                d = d.setdefault(p, {})
            d[parts[-1]] = value
        base = _deep_merge(base, nested)

    # Env-var overrides (DK_ prefix)
    env_map = {
        "DK_GPU_HOST": "gpu_host",
        "DK_TEE_HOST": "tee_host",
        "DK_MODEL_NAME": "model_name",
        "DK_OUTPUT_DIR": "output_dir",
    }
    for env_key, cfg_key in env_map.items():
        val = os.environ.get(env_key)
        if val is not None:
            base[cfg_key] = val

    # When local_mode is active the runner is ON the GPU machine — override
    # gpu_host to 127.0.0.1 so HTTP calls to vLLM hit localhost, not the
    # external IP that may be in default.yaml.
    if base.get("local_mode", False):
        base.setdefault("gpu_host", "127.0.0.1")
        if base.get("gpu_host") not in ("127.0.0.1", "localhost", "0.0.0.0"):
            base["gpu_host"] = "127.0.0.1"

    # Validate required fields — fail fast with a clear message rather than
    # letting empty strings cause cryptic errors deep in the test run.
    _REQUIRED_ALWAYS = [
        "tee_host",
        "tee_admin_token",
        "tee_user_token",
        "model_name",
        "model_path_clear",
        "model_path_encrypted",
        "encrypted_model_id",
        "encrypted_model_name",
        "fhenomai_venv",
        "gpu_home",
    ]
    _REQUIRED_REMOTE = [  # only when not running locally
        "gpu_host",
        "gpu_ssh_user",
        "gpu_ssh_key",
    ]

    missing: list[str] = [k for k in _REQUIRED_ALWAYS if not base.get(k)]
    if not base.get("local_mode", False):
        missing += [k for k in _REQUIRED_REMOTE if not base.get(k)]

    if missing:
        raise ValueError(
            "Missing required configuration values (set them in your YAML or via CLI overrides):\n"
            + "".join(f"  - {k}\n" for k in missing)
        )

    return Config(base)
