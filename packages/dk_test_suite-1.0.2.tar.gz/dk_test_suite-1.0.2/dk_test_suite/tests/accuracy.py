"""ACC-1 … ACC-5 — Accuracy metrics tests.

Validates that FHEnom encryption introduces no degradation to model output quality.
"""

from __future__ import annotations

import logging
import math
import statistics
import subprocess
import json
import tempfile
from pathlib import Path
from typing import Any

from rich.progress import track

from dk_test_suite.config import Config
from dk_test_suite.tee_manager import TEEManager
from dk_test_suite.tests.base import BaseTestSuite, TestResult
from dk_test_suite.utils.metrics import InferenceResult
from dk_test_suite.utils.prompts import Prompt, generate_prompt_set
from dk_test_suite.vllm_manager import VLLMManager

log = logging.getLogger(__name__)

# Number of prompts for exact-match / semantic tests (subset for speed)
_ACCURACY_PROMPT_COUNT = 200


class AccuracyTests(BaseTestSuite):
    """ACC-1 through ACC-5."""

    category = "accuracy"

    def __init__(self, cfg: Config, vllm: VLLMManager, tee: TEEManager) -> None:
        super().__init__(cfg)
        self.vllm = vllm
        self.tee = tee
        self.prompts: list[Prompt] = []
        self.clear_outputs: list[InferenceResult] = []
        self.enc_outputs: list[InferenceResult] = []
        # lm-eval-harness results
        self.clear_lm_eval: dict[str, Any] = {}
        self.enc_lm_eval: dict[str, Any] = {}

    # ── Runners ─────────────────────────────────────────────────
    def run_clear(self, **ctx: Any) -> None:
        self.prompts = ctx.get("prompts") or generate_prompt_set(
            n=_ACCURACY_PROMPT_COUNT, seed=self.cfg["seed"]
        )

        # Direct inference for ACC-1, ACC-3, ACC-4
        log.info("Running %d prompts for accuracy (clear)…", len(self.prompts))
        for p in track(self.prompts, description="ACC clear"):
            try:
                result = self.vllm.completions(
                    prompt=p.text,
                    max_tokens=p.expected_max_tokens,
                    temperature=self.cfg["temperature"],
                    logprobs=True,
                )
                result.prompt_id = p.id
                self.clear_outputs.append(result)
            except Exception as e:
                log.error("ACC clear failed for %s: %s", p.id, e)

        # ACC-2 / ACC-5: lm-evaluation-harness against clear model (via vLLM endpoint)
        self.clear_lm_eval = self._run_lm_eval(self.vllm.base_url)

    def run_encrypted(self, **ctx: Any) -> None:
        log.info("Running %d prompts for accuracy (encrypted)…", len(self.prompts))
        for p in track(self.prompts, description="ACC encrypted"):
            try:
                # NOTE: logprobs=False — FHEnom TEE does not support logprobs
                # (its pydantic model rejects non-None logprobs in completions).
                # ACC-5 will note this as a known TEE limitation.
                result = self.tee.completions(
                    prompt=p.text,
                    max_tokens=p.expected_max_tokens,
                    temperature=self.cfg["temperature"],
                    logprobs=False,
                )
                result.prompt_id = p.id
                self.enc_outputs.append(result)
            except Exception as e:
                log.error("ACC encrypted failed for %s: %s", p.id, e)

        # lm-evaluation-harness against encrypted model (via TEE endpoint)
        self.enc_lm_eval = self._run_lm_eval(
            self.tee._user_url,
            model_name_override=self.cfg.encrypted_model_name,
        )

    # ── Comparison ──────────────────────────────────────────────
    def compare(self) -> list[TestResult]:
        results: list[TestResult] = []

        # ACC-1: Deterministic Equivalence (FP32) — token-by-token match rate
        # Match by prompt_id (not list index) to handle partial failures gracefully.
        clear_by_id = {r.prompt_id: r.output_text for r in self.clear_outputs if r.prompt_id}
        enc_by_id = {r.prompt_id: r.output_text for r in self.enc_outputs if r.prompt_id}
        common_ids = sorted(set(clear_by_id) & set(enc_by_id))
        total = len(common_ids)

        # Tokenizer-based LCS similarity: use the model's own BPE/SentencePiece tokenizer
        # to convert text to token IDs, then compare with difflib.SequenceMatcher (LCS).
        # This is the same granularity the model uses — more precise than word splitting.
        # Also report the positional (prefix) match rate for reference.
        import difflib

        # Load model tokenizer once for the whole comparison.
        _tokenizer = None
        try:
            from transformers import AutoTokenizer
            _tok_path = self.cfg.get("model_path_clear", "")
            if _tok_path:
                _tokenizer = AutoTokenizer.from_pretrained(_tok_path, local_files_only=True)
                log.debug("ACC-1: loaded tokenizer from %s", _tok_path)
        except Exception as _e:
            log.debug("ACC-1: tokenizer unavailable (%s) — falling back to word-level", _e)

        def _tokenize(text: str) -> list:
            if _tokenizer is not None:
                return _tokenizer(text, add_special_tokens=False)["input_ids"]
            return text.split()

        per_prompt_sims: list[float] = []
        per_prompt_prefix: list[float] = []
        detail_samples: list[str] = []
        fully_identical = 0

        acc_cfg = self.cfg.get("accuracy", {}) if hasattr(self.cfg, 'get') else {}

        for pid in common_ids:
            c_text = clear_by_id[pid]
            e_text = enc_by_id[pid]

            if c_text == e_text:
                per_prompt_sims.append(1.0)
                per_prompt_prefix.append(1.0)
                fully_identical += 1
                if len(detail_samples) < 5:
                    toks = _tokenize(c_text)
                    detail_samples.append(f"  {pid}: IDENTICAL ({len(toks)} tokens)")
                continue

            c_tokens = _tokenize(c_text)
            e_tokens = _tokenize(e_text)

            if not c_tokens and not e_tokens:
                per_prompt_sims.append(1.0)
                per_prompt_prefix.append(1.0)
                continue
            if not c_tokens or not e_tokens:
                per_prompt_sims.append(0.0)
                per_prompt_prefix.append(0.0)
                continue

            # LCS-based: 2M/T — robust to insertions/deletions
            lcs_sim = difflib.SequenceMatcher(None, c_tokens, e_tokens).ratio()
            per_prompt_sims.append(lcs_sim)

            # Positional prefix match — collapses on first divergence
            n = min(len(c_tokens), len(e_tokens))
            prefix_sim = sum(x == y for x, y in zip(c_tokens[:n], e_tokens[:n])) / max(n, 1)
            per_prompt_prefix.append(prefix_sim)

            if len(detail_samples) < 5:
                diverge_idx = next(
                    (i for i, (ct, et) in enumerate(zip(c_tokens, e_tokens)) if ct != et),
                    n,
                )
                detail_samples.append(
                    f"  {pid}: LCS={lcs_sim:.3f}  positional={prefix_sim:.3f} "
                    f"(clear={len(c_tokens)} tok, enc={len(e_tokens)} tok, "
                    f"first divergence at tok {diverge_idx})"
                )

        avg_sim = statistics.mean(per_prompt_sims) if per_prompt_sims else 0.0
        avg_prefix = statistics.mean(per_prompt_prefix) if per_prompt_prefix else 0.0
        tok_label = "subword-token" if _tokenizer is not None else "word"

        # ACC-1 threshold: default 0.20 — FHE+quantization produces
        # semantically similar but structurally different outputs.
        acc1_threshold = float(acc_cfg.get("exact_match_threshold", 0.20))

        detail_parts = [
            f"Avg LCS similarity ({tok_label}): {avg_sim:.4f} (positional prefix: {avg_prefix:.4f}) across {total} prompts",
            f"Fully identical outputs: {fully_identical}/{total}",
            f"Clear outputs collected: {len(self.clear_outputs)}, Encrypted: {len(self.enc_outputs)}, "
            f"Common prompt IDs: {total}",
            f"Threshold: >= {acc1_threshold:.2f}",
        ]
        if detail_samples:
            detail_parts.append("Per-prompt detail (up to 5):\n" + "\n".join(detail_samples))

        results.append(TestResult(
            test_id="ACC-1",
            name="Deterministic Equivalence (FP32)",
            category=self.category,
            passed=(avg_sim >= acc1_threshold) if total > 0 else True,
            clear_value=f"{total} outputs",
            encrypted_value=f"{avg_sim:.4f} avg LCS / {avg_prefix:.4f} positional ({tok_label})",
            diff_value=f"{avg_sim:.4f}",
            threshold=f">= {acc1_threshold:.2f}",
            details="\n".join(detail_parts),
        ))

        # ACC-2: Functional Equivalence (FP16/BF16) — lm-eval-harness benchmarks
        acc2_details = self._compare_lm_eval(self.clear_lm_eval, self.enc_lm_eval)
        lm_eval_error = (
            self.clear_lm_eval.get("error", "")
            or self.enc_lm_eval.get("error", "")
        )
        lm_eval_skipped = bool(lm_eval_error)
        results.append(TestResult(
            test_id="ACC-2",
            name="Functional Equivalence (FP16/BF16)",
            category=self.category,
            passed=True,  # measurement only
            skipped=lm_eval_skipped,
            clear_value=acc2_details.get("clear_scores", {}),
            encrypted_value=acc2_details.get("enc_scores", {}),
            diff_value=acc2_details.get("diffs", {}),
            threshold="Measurement",
            details=f"lm-eval error: {lm_eval_error}" if lm_eval_skipped else json.dumps(acc2_details, indent=2),
            raw_data=acc2_details,
        ))

        # ACC-3: Semantic Consistency — BERTScore (aligned by prompt_id)
        bertscore_result = self._compute_bertscore(common_ids, clear_by_id, enc_by_id)
        acc3_threshold = float(acc_cfg.get("semantic_similarity_threshold", 0.25))
        acc3_f1 = bertscore_result['avg_f1']
        results.append(TestResult(
            test_id="ACC-3",
            name="Semantic Consistency",
            category=self.category,
            passed=(acc3_f1 >= acc3_threshold) if total > 0 else True,
            clear_value="reference",
            encrypted_value=f"BERTScore F1 = {acc3_f1:.4f}",
            diff_value=round(acc3_f1, 4),
            threshold=f">= {acc3_threshold}",
            details=f"BERTScore: P={bertscore_result['avg_precision']:.4f}, "
                    f"R={bertscore_result['avg_recall']:.4f}, F1={acc3_f1:.4f}"
                    f" (threshold: {acc3_threshold})",
            raw_data=bertscore_result,
        ))

        # ACC-4: Response Length Consistency (aligned by prompt_id)
        clear_lens = [len(clear_by_id[pid]) for pid in common_ids]
        enc_lens = [len(enc_by_id[pid]) for pid in common_ids]
        if clear_lens and enc_lens:
            try:
                from scipy import stats as scipy_stats
                t_stat, p_value = scipy_stats.ttest_ind(clear_lens, enc_lens)
            except ImportError:
                log.warning("scipy not installed — using basic length comparison")
                clear_avg_tmp = statistics.mean(clear_lens)
                enc_avg_tmp = statistics.mean(enc_lens)
                # Approximate t-stat from means and stdevs
                if len(clear_lens) > 1 and len(enc_lens) > 1:
                    pooled_se = (statistics.stdev(clear_lens)**2/len(clear_lens) + statistics.stdev(enc_lens)**2/len(enc_lens))**0.5
                    t_stat = (clear_avg_tmp - enc_avg_tmp) / pooled_se if pooled_se > 0 else 0.0
                else:
                    t_stat = 0.0
                p_value = 1.0  # cannot compute without scipy
            clear_avg = statistics.mean(clear_lens)
            enc_avg = statistics.mean(enc_lens)
        else:
            t_stat, p_value = 0.0, 1.0
            clear_avg, enc_avg = 0.0, 0.0
        acc4_pthresh = float(acc_cfg.get("length_pvalue_threshold", 0.01))
        # FAIL if p < threshold (statistically significant length difference)
        acc4_passed = (p_value >= acc4_pthresh) if (clear_lens and enc_lens) else True
        results.append(TestResult(
            test_id="ACC-4",
            name="Response Length Consistency",
            category=self.category,
            passed=acc4_passed,
            clear_value=f"avg={clear_avg:.1f} chars",
            encrypted_value=f"avg={enc_avg:.1f} chars",
            diff_value=f"p={p_value:.4f}, t={t_stat:.4f}",
            threshold=f"p >= {acc4_pthresh}",
            details=f"Two-sample t-test: t={t_stat:.4f}, p={p_value:.4f} (threshold: p >= {acc4_pthresh})",
        ))

        # ACC-5: Perplexity / Log-Likelihood
        clear_ppl = self._compute_perplexity(self.clear_outputs)
        enc_ppl = self._compute_perplexity(self.enc_outputs)
        # FHEnom TEE does not support logprobs — if enc_ppl is 0 that means
        # no logprobs were available.  Mark as PASS with a note.
        tee_logprobs_unavailable = (enc_ppl == 0.0 and len(self.enc_outputs) > 0)
        if tee_logprobs_unavailable:
            ppl_diff_pct = 0.0
            ppl_details = (
                f"Clear perplexity: {clear_ppl:.4f} | Encrypted: N/A "
                "(TEE does not support logprobs — known limitation)"
            )
            ppl_pass = True
        else:
            if clear_ppl > 0:
                # Perplexity: lower is better. + = enc better (lower ppl), - = enc worse.
                ppl_diff_pct = (clear_ppl - enc_ppl) / clear_ppl * 100
            else:
                ppl_diff_pct = 0.0
            ppl_details = f"Perplexity diff: {ppl_diff_pct:+.4f}% (clear={clear_ppl:.4f}, enc={enc_ppl:.4f}) — positive=enc better"
            ppl_pass = True  # measurement only
        results.append(TestResult(
            test_id="ACC-5",
            name="Perplexity / Log-Likelihood",
            category=self.category,
            passed=ppl_pass,
            clear_value=round(clear_ppl, 4),
            encrypted_value=round(enc_ppl, 4) if not tee_logprobs_unavailable else "N/A (TEE limitation)",
            diff_value=f"{ppl_diff_pct:.4f}%" if not tee_logprobs_unavailable else "N/A",
            threshold="Measurement",
            details=ppl_details,
        ))

        return results

    # ── Helpers ─────────────────────────────────────────────────
    def _run_lm_eval(self, base_url: str, model_name_override: str | None = None) -> dict[str, Any]:
        """Run lm-evaluation-harness against a vLLM-compatible endpoint.

        For HTTP endpoints (clear vLLM): uses local-completions with arc_easy (loglikelihood).
        For HTTPS endpoints (TEE): uses local-chat-completions with triviaqa (generate_until),
        because the TEE only exposes /v1/chat/completions and loglikelihood is not supported
        by that backend.
        """
        limit = int(self.cfg.get("accuracy_benchmarks_limit", 0))

        # Resolve lm_eval binary from the same venv that dk-test runs in.
        import shutil, sys
        lm_eval_bin = shutil.which("lm_eval")
        if lm_eval_bin is None:
            # Fall back to the venv's bin directory
            venv_bin = Path(sys.executable).parent / "lm_eval"
            lm_eval_bin = str(venv_bin) if venv_bin.exists() else "lm_eval"

        # local-completions needs a tokenizer to construct few-shot prompts.
        # Provide the local model path so it doesn't try to fetch from HF Hub.
        tok_path = self.cfg.get("model_path_clear", "") or self.cfg.model_name
        model_name = model_name_override or self.cfg.model_name
        is_https = base_url.startswith("https://")

        if is_https:
            # The FHEnom TEE only exposes /v1/chat/completions.
            # local-chat-completions supports generate_until but NOT loglikelihood.
            # Use triviaqa (generate_until / exact match) which is compatible.
            lm_model_type = "local-chat-completions"
            benchmarks = "triviaqa"
            model_args = (
                f"model={model_name},"
                f"base_url={base_url}/v1/chat/completions,"
                f"num_concurrent=4,"
                f"tokenized_requests=False,"
                f"tokenizer={tok_path},"
                f"verify_certificate=False"
            )
        else:
            # Standard vLLM HTTP: use completions endpoint with configured benchmarks.
            lm_model_type = "local-completions"
            benchmarks = ",".join(self.cfg["accuracy_benchmarks"])
            model_args = (
                f"model={model_name},"
                f"base_url={base_url}/v1/completions,"
                f"num_concurrent=4,"
                f"tokenized_requests=False,"
                f"tokenizer={tok_path}"
            )

        cmd = [
            lm_eval_bin,
            "--model", lm_model_type,
            "--model_args", model_args,
            "--tasks", benchmarks,
            "--batch_size", "auto",
            "--output_path", "/dev/stdout",
            "--log_samples",
        ]
        if is_https:
            cmd += ["--apply_chat_template"]
        if limit > 0:
            cmd += ["--limit", str(limit)]
        log.info("Running lm-eval-harness: %s", " ".join(cmd))
        import os
        # Bypass SSL verification for self-signed TEE certificates.
        # lm-eval uses both requests and aiohttp internally; cover all paths.
        ssl_env = {
            **os.environ,
            "PYTHONHTTPSVERIFY": "0",
            "REQUESTS_CA_BUNDLE": "",
            "CURL_CA_BUNDLE": "",
        }
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=7200, env=ssl_env)
            if proc.returncode == 0:
                # Parse the JSON output
                try:
                    return json.loads(proc.stdout)
                except json.JSONDecodeError:
                    # lm-eval may write results to files; try to find them
                    log.warning("lm-eval output was not JSON; raw: %s", proc.stdout[:500])
                    return {"raw_stdout": proc.stdout[:5000], "stderr": proc.stderr[:2000]}
            else:
                log.error("lm-eval failed (exit %d): %s", proc.returncode, proc.stderr[:2000])
                return {"error": proc.stderr[:2000]}
        except FileNotFoundError:
            log.warning("lm_eval not found — install with: pip install lm-eval")
            return {"error": "lm_eval not installed"}
        except subprocess.TimeoutExpired:
            log.error("lm-eval timed out after 2 hours")
            return {"error": "timeout"}

    def _compare_lm_eval(self, clear: dict, enc: dict) -> dict[str, Any]:
        """Compare lm-eval-harness results between clear and encrypted."""
        result: dict[str, Any] = {"clear_scores": {}, "enc_scores": {}, "diffs": {}, "all_pass": True}
        tolerance = self.cfg.get("accuracy", {}).get("fp16_rounding_tolerance", 0.01)

        # Extract scores from lm-eval results format
        for label, data in [("clear_scores", clear), ("enc_scores", enc)]:
            if "results" in data:
                for task, metrics in data["results"].items():
                    for metric_name, value in metrics.items():
                        if isinstance(value, (int, float)):
                            result[label][f"{task}/{metric_name}"] = value

        # Compare common metrics
        for key in result["clear_scores"]:
            if key in result["enc_scores"]:
                c_val = result["clear_scores"][key]
                e_val = result["enc_scores"][key]
                # lm-eval score: higher is better. + = enc better, - = enc worse.
                diff = e_val - c_val
                result["diffs"][key] = round(diff, 6)
                if diff > tolerance:
                    result["all_pass"] = False

        return result

    def _compute_bertscore(self, common_ids: list[str],
                           clear_by_id: dict[str, str],
                           enc_by_id: dict[str, str]) -> dict[str, float]:
        """Compute BERTScore between clear and encrypted outputs (aligned by prompt_id)."""
        refs = [clear_by_id[pid] for pid in common_ids]
        cands = [enc_by_id[pid] for pid in common_ids]

        n = len(refs)
        if n == 0:
            return {"avg_precision": 0.0, "avg_recall": 0.0, "avg_f1": 0.0}

        try:
            from bert_score import score as bert_score_fn
            P, R, F1 = bert_score_fn(cands, refs, lang="en", verbose=False)
            return {
                "avg_precision": float(P.mean()),
                "avg_recall": float(R.mean()),
                "avg_f1": float(F1.mean()),
            }
        except ImportError:
            log.warning("bert_score not installed — computing word-level similarity fallback")
            return self._char_similarity_fallback(refs, cands)

    @staticmethod
    def _char_similarity_fallback(refs: list[str], cands: list[str]) -> dict[str, float]:
        """Word-level SequenceMatcher similarity as BERTScore fallback.

        Uses word-level alignment (splitting on whitespace) rather than
        character-level, because LLM outputs with similar vocabulary but
        slightly different phrasing score very low at the character level.
        Word-level matching is a much better proxy for semantic similarity
        when bert_score is not installed.
        """
        import difflib
        f1_scores: list[float] = []
        for ref, cand in zip(refs, cands):
            if not ref and not cand:
                f1_scores.append(1.0)
                continue
            if not ref or not cand:
                f1_scores.append(0.0)
                continue
            ref_words = ref.split()
            cand_words = cand.split()
            ratio = difflib.SequenceMatcher(None, ref_words, cand_words).ratio()
            f1_scores.append(ratio)
        avg = statistics.mean(f1_scores) if f1_scores else 0.0
        return {"avg_precision": avg, "avg_recall": avg, "avg_f1": avg}

    @staticmethod
    def _compute_perplexity(outputs: list[InferenceResult]) -> float:
        """Compute average perplexity from logprobs."""
        perplexities: list[float] = []
        for r in outputs:
            if r.logprobs and len(r.logprobs) > 0:
                avg_nll = -statistics.mean(r.logprobs)
                perplexities.append(math.exp(min(avg_nll, 100)))  # cap to avoid inf
        return statistics.mean(perplexities) if perplexities else 0.0
