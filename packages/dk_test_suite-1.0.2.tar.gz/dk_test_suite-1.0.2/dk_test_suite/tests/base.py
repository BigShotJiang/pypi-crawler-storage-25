"""Base test class — shared interface for all POC test categories."""

from __future__ import annotations

import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dk_test_suite.config import Config

log = logging.getLogger(__name__)


@dataclass
class TestResult:
    """Result of a single test criterion."""
    test_id: str                            # e.g. "PERF-1"
    name: str                               # Human-readable name
    category: str                           # "performance" | "accuracy" | "scalability" | "security" | "training"
    passed: bool
    clear_value: Any = None                 # Metric from clear model
    encrypted_value: Any = None             # Metric from encrypted model
    diff_value: Any = None                  # Difference / comparison result
    threshold: Any = None                   # Pass condition
    details: str = ""                       # Extra explanation
    raw_data: dict[str, Any] = field(default_factory=dict)
    duration_s: float = 0.0
    skipped: bool = False                   # True when test was not executed

    def to_dict(self) -> dict[str, Any]:
        return {
            "test_id": self.test_id,
            "name": self.name,
            "category": self.category,
            "passed": self.passed,
            "skipped": self.skipped,
            "clear_value": _serialize(self.clear_value),
            "encrypted_value": _serialize(self.encrypted_value),
            "diff_value": _serialize(self.diff_value),
            "threshold": _serialize(self.threshold),
            "details": self.details,
            "duration_s": round(self.duration_s, 2),
        }


def _serialize(val: Any) -> Any:
    if isinstance(val, float):
        return round(val, 4)
    return val


class BaseTestSuite(ABC):
    """Abstract base for a category of tests (PERF, ACC, SCALE, SEC, T)."""

    category: str = "base"

    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.results: list[TestResult] = []

    @abstractmethod
    def run_clear(self, **ctx: Any) -> None:
        """Run tests against the clear (plaintext) model."""

    @abstractmethod
    def run_encrypted(self, **ctx: Any) -> None:
        """Run tests against the encrypted model (through TEE)."""

    @abstractmethod
    def compare(self) -> list[TestResult]:
        """Compare clear vs encrypted results and return TestResult list."""

    def run_all(self, **ctx: Any) -> list[TestResult]:
        """Convenience: run clear → run encrypted → compare."""
        log.info("▸ Running %s tests (clear model)…", self.category)
        self.run_clear(**ctx)
        log.info("▸ Running %s tests (encrypted model)…", self.category)
        self.run_encrypted(**ctx)
        log.info("▸ Comparing %s results…", self.category)
        self.results = self.compare()
        return self.results

    def save_results(self, output_dir: Path) -> Path:
        """Persist results to JSON."""
        out = output_dir / f"{self.category}_results.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, "w") as f:
            json.dump([r.to_dict() for r in self.results], f, indent=2)
        log.info("Results saved to %s", out)
        return out
