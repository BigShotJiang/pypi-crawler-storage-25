"""SCALE-1 … SCALE-4 — Scalability metrics tests.

Assesses whether FHEnom encryption introduces constraints on scaling behaviour.
"""

from __future__ import annotations

import asyncio
import logging
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from rich.progress import track

from dk_test_suite.config import Config
from dk_test_suite.tee_manager import TEEManager
from dk_test_suite.tests.base import BaseTestSuite, TestResult
from dk_test_suite.utils.metrics import InferenceResult
from dk_test_suite.utils.prompts import Prompt, generate_prompt_set
from dk_test_suite.vllm_manager import VLLMManager

log = logging.getLogger(__name__)


class ScalabilityTests(BaseTestSuite):
    """SCALE-1 through SCALE-4."""

    category = "scalability"

    def __init__(self, cfg: Config, vllm: VLLMManager, tee: TEEManager) -> None:
        super().__init__(cfg)
        self.vllm = vllm
        self.tee = tee
        self.scale_cfg = cfg["scalability"]
        # Results storage
        self.clear_concurrent: dict[int, dict[str, float]] = {}
        self.enc_concurrent: dict[int, dict[str, float]] = {}
        self.clear_context: dict[int, dict[str, float]] = {}
        self.enc_context: dict[int, dict[str, float]] = {}
        self.clear_batch: dict[int, dict[str, float]] = {}
        self.enc_batch: dict[int, dict[str, float]] = {}
        self.clear_sustained: dict[str, float] = {}
        self.enc_sustained: dict[str, float] = {}

    # ── Runners ─────────────────────────────────────────────────
    def run_clear(self, **ctx: Any) -> None:
        # Warmup: discard the first request to avoid cold-start artefacts
        log.info("SCALE clear warmup — discarding first vLLM request…")
        try:
            self._clear_inference("Warmup request — ignore this.", max_tokens=32)
            log.info("SCALE clear warmup complete")
        except Exception as e:
            log.warning("SCALE clear warmup failed (non-fatal): %s", e)

        log.info("SCALE clear — concurrent load test")
        for n in self.scale_cfg["concurrent_levels"]:
            self.clear_concurrent[n] = self._concurrent_test(
                n_concurrent=n, inference_fn=self._clear_inference
            )

        log.info("SCALE clear — context length scaling")
        for ctx_len in self.scale_cfg["context_lengths"]:
            self.clear_context[ctx_len] = self._context_length_test(
                ctx_len=ctx_len, inference_fn=self._clear_inference
            )

        log.info("SCALE clear — batch processing")
        for batch_size in self.scale_cfg["batch_sizes"]:
            self.clear_batch[batch_size] = self._batch_test(
                batch_size=batch_size, inference_fn=self._clear_inference
            )

        log.info("SCALE clear — sustained operation (abbreviated)")
        dur = self.scale_cfg.get("sustained_abbreviated_minutes", 3)
        self.clear_sustained = self._sustained_test(inference_fn=self._clear_inference, duration_minutes=dur)

    def run_encrypted(self, **ctx: Any) -> None:
        # Warmup: discard the first TEE request to avoid cold-start artefacts
        log.info("SCALE encrypted warmup — discarding first TEE request…")
        try:
            self._enc_inference("Warmup request — ignore this.", max_tokens=32)
            log.info("SCALE encrypted warmup complete")
        except Exception as e:
            log.warning("SCALE encrypted warmup failed (non-fatal): %s", e)

        log.info("SCALE encrypted — concurrent load test")
        for n in self.scale_cfg["concurrent_levels"]:
            self.enc_concurrent[n] = self._concurrent_test(
                n_concurrent=n, inference_fn=self._enc_inference
            )

        log.info("SCALE encrypted — context length scaling")
        for ctx_len in self.scale_cfg["context_lengths"]:
            self.enc_context[ctx_len] = self._context_length_test(
                ctx_len=ctx_len, inference_fn=self._enc_inference
            )

        log.info("SCALE encrypted — batch processing")
        for batch_size in self.scale_cfg["batch_sizes"]:
            self.enc_batch[batch_size] = self._batch_test(
                batch_size=batch_size, inference_fn=self._enc_inference
            )

        log.info("SCALE encrypted — sustained operation (abbreviated)")
        dur = self.scale_cfg.get("sustained_abbreviated_minutes", 3)
        self.enc_sustained = self._sustained_test(inference_fn=self._enc_inference, duration_minutes=dur)

    # ── Comparison ──────────────────────────────────────────────
    def compare(self) -> list[TestResult]:
        results: list[TestResult] = []

        # SCALE-1: Concurrent User Load
        scale1_detail: list[str] = []
        # diff convention: + = encrypted faster/better, - = encrypted slower/worse
        for n in self.scale_cfg["concurrent_levels"]:
            c = self.clear_concurrent.get(n, {})
            e = self.enc_concurrent.get(n, {})
            c_tp = c.get("throughput", 0)
            e_tp = e.get("throughput", 0)
            if c_tp > 0:
                diff = (e_tp - c_tp) / c_tp * 100  # throughput: higher enc = positive
                scale1_detail.append(f"n={n}: clear={c_tp:.1f} enc={e_tp:.1f} tok/s (diff={diff:+.1f}%)")
            else:
                scale1_detail.append(f"n={n}: no data")

        results.append(TestResult(
            test_id="SCALE-1",
            name="Concurrent User Load",
            category=self.category,
            passed=True,  # measurement only
            clear_value=self.clear_concurrent,
            encrypted_value=self.enc_concurrent,
            threshold="Measurement",
            details="\n".join(scale1_detail),
        ))

        # SCALE-2: Context Length Scaling
        scale2_detail: list[str] = []
        for ctx_len in self.scale_cfg["context_lengths"]:
            c = self.clear_context.get(ctx_len, {})
            e = self.enc_context.get(ctx_len, {})
            c_lat = c.get("avg_latency_ms", 0)
            e_lat = e.get("avg_latency_ms", 0)
            if c_lat > 0:
                diff = (c_lat - e_lat) / c_lat * 100  # latency: lower enc = positive
                scale2_detail.append(f"ctx={ctx_len}: clear={c_lat:.1f}ms enc={e_lat:.1f}ms (diff={diff:+.1f}%)")
            else:
                scale2_detail.append(f"ctx={ctx_len}: no data")

        results.append(TestResult(
            test_id="SCALE-2",
            name="Context Length Scaling",
            category=self.category,
            passed=True,  # measurement only
            clear_value=self.clear_context,
            encrypted_value=self.enc_context,
            threshold="Measurement",
            details="\n".join(scale2_detail),
        ))

        # SCALE-3: Batch Processing
        scale3_detail: list[str] = []
        for bs in self.scale_cfg["batch_sizes"]:
            c = self.clear_batch.get(bs, {})
            e = self.enc_batch.get(bs, {})
            c_tp = c.get("throughput", 0)
            e_tp = e.get("throughput", 0)
            if c_tp > 0:
                diff = (e_tp - c_tp) / c_tp * 100  # throughput: higher enc = positive
                scale3_detail.append(f"batch={bs}: clear={c_tp:.1f} enc={e_tp:.1f} tok/s (diff={diff:+.1f}%)")
            else:
                scale3_detail.append(f"batch={bs}: no data")

        results.append(TestResult(
            test_id="SCALE-3",
            name="Batch Processing",
            category=self.category,
            passed=True,  # measurement only
            clear_value=self.clear_batch,
            encrypted_value=self.enc_batch,
            diff_value=None,
            threshold="Measurement",
            details="\n".join(scale3_detail),
        ))

        # SCALE-4: Sustained Operation
        c_deg = self.clear_sustained.get("degradation_pct", 0)
        e_deg = self.enc_sustained.get("degradation_pct", 0)
        results.append(TestResult(
            test_id="SCALE-4",
            name="Sustained Operation",
            category=self.category,
            passed=True,  # measurement only
            clear_value=self.clear_sustained,
            encrypted_value=self.enc_sustained,
            threshold="Measurement",
            details=(
                f"Clear degradation: {c_deg:.1f}%, Encrypted degradation: {e_deg:.1f}%\n"
                f"Note: Full 24h test should be run separately with: dk-test scale4-sustained"
            ),
        ))

        return results

    # ── Test implementations ────────────────────────────────────
    def _clear_inference(self, prompt: str, max_tokens: int = 128) -> InferenceResult:
        return self.vllm.completions(prompt=prompt, max_tokens=max_tokens, temperature=0)

    def _enc_inference(self, prompt: str, max_tokens: int = 128) -> InferenceResult:
        return self.tee.completions(prompt=prompt, max_tokens=max_tokens, temperature=0)

    def _concurrent_test(self, n_concurrent: int,
                         inference_fn: Any) -> dict[str, float]:
        """Send n_concurrent requests in parallel and measure aggregate throughput."""
        prompts = generate_prompt_set(n=n_concurrent, seed=42 + n_concurrent)
        results: list[InferenceResult] = []

        with ThreadPoolExecutor(max_workers=n_concurrent) as executor:
            t0 = time.perf_counter()
            futures = {
                executor.submit(inference_fn, p.text, 128): p
                for p in prompts
            }
            for future in as_completed(futures):
                try:
                    results.append(future.result())
                except Exception as e:
                    log.error("Concurrent request failed: %s", e)
            wall_time = time.perf_counter() - t0

        total_tokens = sum(r.tokens_generated for r in results)
        avg_latency = statistics.mean([r.total_time_ms for r in results]) if results else 0

        return {
            "n_concurrent": n_concurrent,
            "wall_time_s": round(wall_time, 2),
            "total_tokens": total_tokens,
            "throughput": round(total_tokens / wall_time, 2) if wall_time > 0 else 0,
            "avg_latency_ms": round(avg_latency, 2),
            "completed": len(results),
        }

    def _context_length_test(self, ctx_len: int, inference_fn: Any,
                              iterations: int = 3) -> dict[str, float]:
        """Generate a prompt of approximately ctx_len tokens and measure latency.

        Runs `iterations` inferences and averages the results to reduce noise.
        """
        # Approximate: 1 token ≈ 4 characters; leave room for generation
        max_gen = min(64, max(16, 8192 - ctx_len - 128))  # Reserve space for generation
        filler = "test " * (ctx_len // 2)
        prompt = f"Summarize the following text:\n{filler[:ctx_len * 4]}\nSummary:"

        latencies: list[float] = []
        tokens_list: list[int] = []
        for i in range(iterations):
            try:
                result = inference_fn(prompt, max_tokens=max_gen)
                latencies.append(result.total_time_ms)
                tokens_list.append(result.tokens_generated)
            except Exception as e:
                log.error("Context length test failed for %d (iter %d): %s", ctx_len, i, e)

        if not latencies:
            return {"context_length": ctx_len, "avg_latency_ms": 0, "error": "all iterations failed"}

        return {
            "context_length": ctx_len,
            "avg_latency_ms": round(statistics.mean(latencies), 2),
            "tokens_generated": round(statistics.mean(tokens_list)),
            "iterations": len(latencies),
            "min_latency_ms": round(min(latencies), 2),
            "max_latency_ms": round(max(latencies), 2),
        }

    def _batch_test(self, batch_size: int, inference_fn: Any) -> dict[str, float]:
        """Process batch_size requests sequentially and measure throughput."""
        prompts = generate_prompt_set(n=batch_size, seed=42 + batch_size)
        t0 = time.perf_counter()
        total_tokens = 0
        for p in prompts:
            try:
                result = inference_fn(p.text, 128)
                total_tokens += result.tokens_generated
            except Exception as e:
                log.error("Batch request failed: %s", e)
        wall_time = time.perf_counter() - t0

        return {
            "batch_size": batch_size,
            "wall_time_s": round(wall_time, 2),
            "total_tokens": total_tokens,
            "throughput": round(total_tokens / wall_time, 2) if wall_time > 0 else 0,
        }

    def _sustained_test(self, inference_fn: Any,
                        duration_minutes: int = 10) -> dict[str, float]:
        """Abbreviated sustained test: run for duration_minutes, check for degradation.

        The full 24-hour test (SCALE-4) should be run with `dk-test scale4-sustained`.
        """
        prompts = generate_prompt_set(n=100, seed=42)
        throughputs: list[float] = []
        start = time.time()
        deadline = start + duration_minutes * 60
        interval_results: list[float] = []
        i = 0

        while time.time() < deadline:
            p = prompts[i % len(prompts)]
            try:
                result = inference_fn(p.text, 128)
                interval_results.append(result.tokens_per_second)
            except Exception:
                pass
            i += 1
            # Sample throughput every 60 seconds
            if len(interval_results) >= 20:
                throughputs.append(statistics.mean(interval_results))
                interval_results = []

        if interval_results:
            throughputs.append(statistics.mean(interval_results))

        # Check degradation: compare first and last intervals
        if len(throughputs) >= 2:
            degradation_pct = (throughputs[0] - throughputs[-1]) / throughputs[0] * 100
        else:
            degradation_pct = 0.0

        return {
            "duration_minutes": duration_minutes,
            "intervals": len(throughputs),
            "first_interval_tps": round(throughputs[0], 2) if throughputs else 0,
            "last_interval_tps": round(throughputs[-1], 2) if throughputs else 0,
            "degradation_pct": round(degradation_pct, 2),
            "total_requests": i,
        }
