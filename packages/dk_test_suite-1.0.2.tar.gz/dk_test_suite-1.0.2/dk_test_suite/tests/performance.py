"""PERF-1 … PERF-5 — Performance metrics tests.

Measures the computational overhead introduced by FHEnom encryption.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from rich.progress import track

from dk_test_suite.config import Config
from dk_test_suite.tee_manager import TEEManager
from dk_test_suite.tests.base import BaseTestSuite, TestResult
from dk_test_suite.utils.metrics import BenchmarkMetrics, InferenceResult
from dk_test_suite.utils.prompts import Prompt, generate_prompt_set
from dk_test_suite.vllm_manager import VLLMManager

log = logging.getLogger(__name__)


class PerformanceTests(BaseTestSuite):
    """PERF-1 through PERF-5."""

    category = "performance"

    def __init__(self, cfg: Config, vllm: VLLMManager, tee: TEEManager) -> None:
        super().__init__(cfg)
        self.vllm = vllm
        self.tee = tee
        self.prompts: list[Prompt] = []
        self.clear_metrics = BenchmarkMetrics(test_id="PERF", model_type="clear")
        self.enc_metrics = BenchmarkMetrics(test_id="PERF", model_type="encrypted")
        self.clear_vram: dict[str, Any] = {}
        self.enc_vram: dict[str, Any] = {}
        self.clear_model_size: int = 0
        self.enc_model_size: int = 0

    # ── Runners ─────────────────────────────────────────────────
    def run_clear(self, **ctx: Any) -> None:
        self.prompts = ctx.get("prompts") or generate_prompt_set(
            n=self.cfg["num_prompts"], seed=self.cfg["seed"]
        )
        # Model size on disk
        try:
            self.clear_model_size = self.vllm.gpu.dir_size_bytes(
                self.cfg["model_path_clear"], exclude="original"
            )
        except Exception as e:
            log.warning("Could not get clear model size: %s", e)

        # VRAM snapshot before inference
        try:
            self.clear_vram = self.vllm.get_vram_usage()
        except Exception as e:
            log.warning("Could not get VRAM usage: %s", e)

        # Warmup: discard the first request to avoid cold-start artefacts
        # (first vLLM inference triggers CUDA JIT compilation, KV cache alloc)
        log.info("PERF clear warmup — discarding first vLLM request…")
        try:
            self.vllm.completions_streaming(
                prompt="Warmup request — ignore this.",
                max_tokens=32,
                temperature=0,
            )
            log.info("PERF clear warmup complete")
        except Exception as e:
            log.warning("PERF clear warmup failed (non-fatal): %s", e)

        # Run inference
        log.info("Running %d prompts against clear model…", len(self.prompts))
        for p in track(self.prompts, description="PERF clear"):
            try:
                result = self.vllm.completions_streaming(
                    prompt=p.text,
                    max_tokens=p.expected_max_tokens,
                    temperature=self.cfg["temperature"],
                )
                result.prompt_id = p.id
                self.clear_metrics.results.append(result)
            except Exception as e:
                log.error("Clear inference failed for %s: %s", p.id, e)

    def run_encrypted(self, **ctx: Any) -> None:
        # Model size on disk
        try:
            self.enc_model_size = self.vllm.gpu.dir_size_bytes(self.cfg["model_path_encrypted"])
        except Exception as e:
            log.warning("Could not get encrypted model size: %s", e)

        # VRAM snapshot
        try:
            self.enc_vram = self.vllm.get_vram_usage()
        except Exception as e:
            log.warning("Could not get VRAM usage: %s", e)

        # Warmup: discard the first request to avoid cold-start artefacts
        # (TEE proxy first request often returns truncated output)
        log.info("PERF encrypted warmup — discarding first TEE request…")
        try:
            self.tee.completions_streaming(
                prompt="Warmup request — ignore this.",
                max_tokens=32,
                temperature=0,
            )
            log.info("PERF encrypted warmup complete")
        except Exception as e:
            log.warning("PERF encrypted warmup failed (non-fatal): %s", e)

        # Run inference through TEE
        log.info("Running %d prompts against encrypted model (via TEE)…", len(self.prompts))
        for p in track(self.prompts, description="PERF encrypted"):
            try:
                result = self.tee.completions_streaming(
                    prompt=p.text,
                    max_tokens=p.expected_max_tokens,
                    temperature=self.cfg["temperature"],
                )
                result.prompt_id = p.id
                self.enc_metrics.results.append(result)
            except Exception as e:
                log.error("Encrypted inference failed for %s: %s", p.id, e)

    # ── Comparison ──────────────────────────────────────────────
    def compare(self) -> list[TestResult]:
        """Compare clear vs encrypted metrics — measurement only, always PASS."""
        results: list[TestResult] = []

        # PERF-1: TTFT
        # diff convention: + = encrypted faster (better), - = encrypted slower (worse)
        # For latency (lower is better):  diff = (clear - enc) / clear * 100
        # For throughput (higher is better): diff = (enc - clear) / clear * 100
        clear_ttft = self.clear_metrics.avg_ttft_ms
        enc_ttft = self.enc_metrics.avg_ttft_ms
        diff_pct = (clear_ttft - enc_ttft) / clear_ttft * 100 if clear_ttft > 0 else 0.0
        results.append(TestResult(
            test_id="PERF-1",
            name="Latency per Token (TTFT)",
            category=self.category,
            passed=True,
            clear_value=f"{clear_ttft:.2f} ms",
            encrypted_value=f"{enc_ttft:.2f} ms",
            diff_value=f"{diff_pct:+.2f}%",
            threshold="Measurement",
            details=f"TTFT: clear={clear_ttft:.1f}ms, enc={enc_ttft:.1f}ms (diff={diff_pct:+.2f}% — positive=enc faster)",
        ))

        # PERF-2: Throughput (tokens/sec)
        clear_tp = self.clear_metrics.avg_tokens_per_sec
        enc_tp = self.enc_metrics.avg_tokens_per_sec
        tp_diff = (enc_tp - clear_tp) / clear_tp * 100 if clear_tp > 0 else 0.0
        results.append(TestResult(
            test_id="PERF-2",
            name="Throughput (Tokens/sec)",
            category=self.category,
            passed=True,
            clear_value=f"{clear_tp:.2f} tok/s",
            encrypted_value=f"{enc_tp:.2f} tok/s",
            diff_value=f"{tp_diff:+.2f}%",
            threshold="Measurement",
            details=f"Throughput: clear={clear_tp:.1f} enc={enc_tp:.1f} tok/s (diff={tp_diff:+.2f}% — positive=enc faster)",
        ))

        # PERF-3: E2E Response Time
        clear_e2e = self.clear_metrics.avg_total_time_ms
        enc_e2e = self.enc_metrics.avg_total_time_ms
        e2e_diff = (clear_e2e - enc_e2e) / clear_e2e * 100 if clear_e2e > 0 else 0.0
        results.append(TestResult(
            test_id="PERF-3",
            name="End-to-End Response Time",
            category=self.category,
            passed=True,
            clear_value=f"{clear_e2e:.2f} ms",
            encrypted_value=f"{enc_e2e:.2f} ms",
            diff_value=f"{e2e_diff:+.2f}%",
            threshold="Measurement",
            details=f"E2E: clear={clear_e2e:.1f}ms, enc={enc_e2e:.1f}ms (diff={e2e_diff:+.2f}% — positive=enc faster)",
        ))

        # PERF-4: Model Footprint
        ratio = self.enc_model_size / self.clear_model_size if self.clear_model_size > 0 and self.enc_model_size > 0 else 1.0
        results.append(TestResult(
            test_id="PERF-4",
            name="Model Footprint",
            category=self.category,
            passed=True,
            clear_value=f"{self.clear_model_size / 1e9:.2f} GB",
            encrypted_value=f"{self.enc_model_size / 1e9:.2f} GB",
            diff_value=f"{ratio:.4f}x",
            threshold="Measurement",
            details=f"Encrypted/Clear size ratio: {ratio:.4f}x",
        ))

        # PERF-5: GPU Memory Utilization
        clear_vram = self.clear_vram.get("vram_used_mb", 0)
        enc_vram = self.enc_vram.get("vram_used_mb", 0)
        vram_diff = enc_vram - clear_vram
        results.append(TestResult(
            test_id="PERF-5",
            name="GPU Memory Utilization",
            category=self.category,
            passed=True,
            clear_value=f"{clear_vram} MB",
            encrypted_value=f"{enc_vram} MB",
            diff_value=f"{vram_diff} MB",
            threshold="Measurement",
            details=f"VRAM: clear={clear_vram}MB, enc={enc_vram}MB (diff={vram_diff}MB)",
        ))

        return results
