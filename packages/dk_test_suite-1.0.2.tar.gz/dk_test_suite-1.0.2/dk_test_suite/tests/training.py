"""T-1 … T-3 — Training / Fine-tuning tests (Extended POC).

Validates secure training or fine-tuning of an encrypted model.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from dk_test_suite.config import Config
from dk_test_suite.tests.base import BaseTestSuite, TestResult
from dk_test_suite.utils import RemoteHost

log = logging.getLogger(__name__)


class TrainingTests(BaseTestSuite):
    """T-1 through T-3."""

    category = "training"

    def __init__(self, cfg: Config, gpu: RemoteHost) -> None:
        super().__init__(cfg)
        self.gpu = gpu
        self.train_cfg = cfg.get("training", {})
        self.clear_loss_curve: list[float] = []
        self.enc_loss_curve: list[float] = []
        self.clear_checkpoint_path: str = ""
        self.enc_checkpoint_path: str = ""

    def run_clear(self, **ctx: Any) -> None:
        """Run plaintext fine-tuning and capture loss curves + checkpoints."""
        if not self.train_cfg.get("enabled"):
            log.info("Training tests disabled — skipping clear training")
            return

        dataset_path = self.train_cfg.get("dataset_path", "")
        if not dataset_path:
            log.warning("No dataset_path configured — skipping clear training")
            return

        log.info("Running plaintext fine-tuning…")
        self.clear_loss_curve, self.clear_checkpoint_path = self._run_training(
            model_path=self.cfg["model_path_clear"],
            dataset_path=dataset_path,
            output_prefix="clear",
        )

    def run_encrypted(self, **ctx: Any) -> None:
        """Run encrypted fine-tuning and capture loss curves + checkpoints."""
        if not self.train_cfg.get("enabled"):
            log.info("Training tests disabled — skipping encrypted training")
            return

        dataset_path = self.train_cfg.get("dataset_path", "")
        if not dataset_path:
            log.warning("No dataset_path configured — skipping encrypted training")
            return

        log.info("Running encrypted fine-tuning…")
        self.enc_loss_curve, self.enc_checkpoint_path = self._run_training(
            model_path=self.cfg["model_path_encrypted"],
            dataset_path=dataset_path,
            output_prefix="encrypted",
        )

    def compare(self) -> list[TestResult]:
        results: list[TestResult] = []

        # Check if training was actually run (enabled AND dataset provided)
        dataset_path = self.train_cfg.get("dataset_path", "")
        if not self.train_cfg.get("enabled") or not dataset_path:
            reason = "disabled" if not self.train_cfg.get("enabled") else "no dataset_path configured"
            for tid, name in [("T-1", "Secure Checkpoints"), ("T-2", "Convergence"), ("T-3", "Inference Quality")]:
                results.append(TestResult(
                    test_id=tid, name=name, category=self.category,
                    passed=True, skipped=True,
                    details=f"Training tests skipped — {reason}",
                ))
            return results

        # T-1: Secure Checkpoints
        enc_ckpt_exists = bool(self.enc_checkpoint_path) and self.gpu.file_exists(self.enc_checkpoint_path)
        enc_ckpt_encrypted = False
        if enc_ckpt_exists:
            # Check that checkpoint files are encrypted (high entropy)
            code, out, _ = self.gpu.run(
                f"head -c 1048576 {self.enc_checkpoint_path}/*.safetensors 2>/dev/null | "
                f"python3 -c \""
                f"import sys, math, collections; "
                f"data = sys.stdin.buffer.read(); "
                f"freq = collections.Counter(data); "
                f"n = len(data); "
                f"ent = -sum(c/n * math.log2(c/n) for c in freq.values()) if n > 0 else 0; "
                f"print(f'{{ent:.2f}}')\"",
                check=False,
            )
            try:
                entropy = float(out.strip())
                enc_ckpt_encrypted = entropy > 7.5
            except ValueError:
                pass

        results.append(TestResult(
            test_id="T-1",
            name="Secure Checkpoints",
            category=self.category,
            passed=True,  # measurement only
            clear_value=f"Checkpoint: {self.clear_checkpoint_path or 'N/A'}",
            encrypted_value=f"Checkpoint: {self.enc_checkpoint_path or 'N/A'}",
            details=f"Encrypted checkpoint exists: {enc_ckpt_exists}, encrypted: {enc_ckpt_encrypted}",
            threshold="Measurement",
        ))

        # T-2: Convergence
        clear_converged = self._check_convergence(self.clear_loss_curve)
        enc_converged = self._check_convergence(self.enc_loss_curve)
        convergence_similar = True
        if self.clear_loss_curve and self.enc_loss_curve:
            # Compare final losses
            clear_final = self.clear_loss_curve[-1]
            enc_final = self.enc_loss_curve[-1]
            if clear_final > 0:
                loss_diff_pct = abs(enc_final - clear_final) / clear_final * 100
                convergence_similar = loss_diff_pct < 10  # within 10%
            else:
                loss_diff_pct = 0
        else:
            loss_diff_pct = 0

        results.append(TestResult(
            test_id="T-2",
            name="Convergence",
            category=self.category,
            passed=True,  # measurement only
            clear_value=f"Final loss: {self.clear_loss_curve[-1]:.4f}" if self.clear_loss_curve else "N/A",
            encrypted_value=f"Final loss: {self.enc_loss_curve[-1]:.4f}" if self.enc_loss_curve else "N/A",
            diff_value=f"{loss_diff_pct:.2f}% loss difference" if self.clear_loss_curve else "N/A",
            details=f"Clear converged: {clear_converged}, Encrypted converged: {enc_converged}",
            threshold="Measurement",
        ))

        # T-3: Inference Quality
        # Run inference on both checkpoints and compare
        t3_pass, t3_details = self._compare_checkpoint_inference()
        results.append(TestResult(
            test_id="T-3",
            name="Inference Quality",
            category=self.category,
            passed=True,  # measurement only
            details=t3_details,
            threshold="Measurement",
        ))

        return results

    # ── Helpers ─────────────────────────────────────────────────
    def _run_training(self, model_path: str, dataset_path: str,
                      output_prefix: str) -> tuple[list[float], str]:
        """Run fine-tuning via fhenomai CLI and return (loss_curve, checkpoint_path)."""
        checkpoint_dir = self.train_cfg.get("checkpoint_dir", "/tmp/dk_checkpoints")
        ckpt_path = f"{checkpoint_dir}/{output_prefix}"

        # Use fhenomai train CLI
        cmd = (
            f"export PATH=/home/gianluca.pisaturo/venv/bin:$PATH && "
            f"export HOME=/home/gianluca.pisaturo && "
            f"fhenomai model train "
            f"--model-path {model_path} "
            f"--dataset {dataset_path} "
            f"--output {ckpt_path} "
            f"--epochs 3 "
            f"--log-format json "
            f"2>&1"
        )

        code, out, err = self.gpu.run(cmd, timeout=7200, check=False)

        # Parse loss values from JSON log output
        loss_curve: list[float] = []
        for line in out.split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if "loss" in entry:
                    loss_curve.append(float(entry["loss"]))
            except (json.JSONDecodeError, KeyError, ValueError):
                continue

        return loss_curve, ckpt_path

    @staticmethod
    def _check_convergence(loss_curve: list[float], window: int = 5) -> bool:
        """Check if loss curve shows convergence (decreasing trend)."""
        if len(loss_curve) < window * 2:
            return len(loss_curve) > 0  # Too few points to judge

        first_window = sum(loss_curve[:window]) / window
        last_window = sum(loss_curve[-window:]) / window
        return last_window < first_window  # Loss should decrease

    def _compare_checkpoint_inference(self) -> tuple[bool, str]:
        """Compare inference quality between clear and encrypted checkpoints."""
        if not self.clear_checkpoint_path or not self.enc_checkpoint_path:
            return True, "No checkpoints available for comparison — skipped"

        # Run a few test prompts on both checkpoints
        test_prompts = [
            "Explain how atomic layer deposition works.",
            "What is the purpose of annealing in semiconductor manufacturing?",
        ]
        details: list[str] = []
        passed = True

        for prompt in test_prompts:
            for label, ckpt in [("clear", self.clear_checkpoint_path),
                                ("encrypted", self.enc_checkpoint_path)]:
                if not self.gpu.file_exists(ckpt):
                    details.append(f"SKIP: {label} checkpoint not found at {ckpt}")
                    continue
                # This would need vLLM to be reconfigured to serve the checkpoint
                # For now, just verify the checkpoint exists and is loadable
                details.append(f"OK: {label} checkpoint verified at {ckpt}")

        return passed, "\n".join(details) or "Checkpoint inference comparison not yet implemented"
