"""SEC-1 … SEC-6 — Security validation tests.

Automated adversarial testing aligned with Section 3.5 and Attachment B.
"""

from __future__ import annotations

import logging
import re
import time
from typing import Any

from dk_test_suite.config import Config
from dk_test_suite.tests.base import BaseTestSuite, TestResult
from dk_test_suite.utils import RemoteHost

log = logging.getLogger(__name__)

# Patterns that would indicate plaintext model data leakage
_PLAINTEXT_PATTERNS = [
    rb"torch\.FloatTensor",
    rb"weight.*\[",
    rb"model\.layers\.",
    rb"lm_head\.weight",
    rb"embed_tokens",
    rb"self_attn",
]


class SecurityTests(BaseTestSuite):
    """SEC-1 through SEC-6."""

    category = "security"

    def __init__(self, cfg: Config, gpu: RemoteHost, tee_host: RemoteHost | None = None) -> None:
        super().__init__(cfg)
        self.gpu = gpu
        self.tee_host = tee_host
        self._sec_results: dict[str, dict[str, Any]] = {}

    # ── Not a clear/encrypted split — security tests are unified ─
    def run_clear(self, **ctx: Any) -> None:
        """No-op: security tests inspect the encrypted deployment only."""
        pass

    def run_encrypted(self, **ctx: Any) -> None:
        """Run all security inspections against the encrypted deployment."""
        self._test_sec1_encryption_at_rest()
        self._test_sec2_encrypted_execution()
        self._test_sec3_secure_transport()
        self._test_sec4_model_binding()
        self._test_sec5_key_isolation()
        self._test_sec6_logging_safety()

    def compare(self) -> list[TestResult]:
        """Return all security test results."""
        return self.results  # Already populated during run_encrypted

    def run_all(self, **ctx: Any) -> list[TestResult]:
        """Override: security tests don't need the clear/encrypted split."""
        log.info("▸ Running security tests…")
        self.run_encrypted(**ctx)
        return self.results

    # ── SEC-1: Encryption at Rest ───────────────────────────────
    def _test_sec1_encryption_at_rest(self) -> None:
        """Inspect stored model artifacts for plaintext weights.

        safetensors files contain a JSON header with tensor names and shapes,
        which is expected to have readable strings.  We only scan the *data*
        section (offset past the header) for plaintext patterns and compute
        entropy on the raw tensor bytes.
        """
        enc_path = self.cfg["model_path_encrypted"]
        details: list[str] = []
        passed = True

        # Check that encrypted model files exist
        if not self.gpu.file_exists(enc_path):
            self.results.append(TestResult(
                test_id="SEC-1", name="Encryption at Rest", category=self.category,
                passed=False, details=f"Encrypted model path does not exist: {enc_path}",
            ))
            return

        # Scan model files for plaintext patterns — skip safetensors header
        _, file_list, _ = self.gpu.run(
            f"find {enc_path} -type f -name '*.safetensors' -o -name '*.bin' -o -name '*.pt'"
        )
        for fpath in file_list.strip().split("\n"):
            fpath = fpath.strip()
            if not fpath:
                continue

            # Get safetensors header size (first 8 bytes = uint64 little-endian)
            # Then scan only the DATA section after the header
            code, hdr_out, _ = self.gpu.run(
                f"python3 -c \""
                f"import struct, os; "
                f"f = open('{fpath}', 'rb'); "
                f"hdr_len = struct.unpack('<Q', f.read(8))[0]; "
                f"print(hdr_len + 8); "
                f"f.close()\"",
                check=False,
            )
            try:
                header_offset = int(hdr_out.strip())
            except ValueError:
                header_offset = 0  # fallback: scan entire file

            # Check for plaintext patterns in DATA section only (skip header)
            for pattern in _PLAINTEXT_PATTERNS:
                code, out, _ = self.gpu.run(
                    f"tail -c +{header_offset + 1} {fpath} | grep -c '{pattern.decode()}' 2>/dev/null || echo 0",
                    check=False,
                )
                count = int(out.strip()) if out.strip().isdigit() else 0
                if count > 0:
                    passed = False
                    details.append(f"FAIL: Found '{pattern.decode()}' in data section of {fpath} ({count} occurrences)")

            # Binary entropy check on data section only
            code, entropy_out, _ = self.gpu.run(
                f"tail -c +{header_offset + 1} {fpath} | head -c 1048576 | python3 -c \""
                f"import sys, math, collections; "
                f"data = sys.stdin.buffer.read(); "
                f"freq = collections.Counter(data); "
                f"n = len(data); "
                f"ent = -sum(c/n * math.log2(c/n) for c in freq.values()) if n > 0 else 0; "
                f"print(f'{{ent:.2f}}')\"",
                check=False,
            )
            try:
                entropy = float(entropy_out.strip())
                if entropy < 7.5:
                    details.append(f"WARNING: Low entropy ({entropy:.2f}) in data section of {fpath}")
                else:
                    details.append(f"OK: Entropy {entropy:.2f} for data section of {fpath}")
            except ValueError:
                details.append(f"SKIP: Could not compute entropy for {fpath}")

        # Report header contents as informational
        details.append("NOTE: safetensors header contains tensor names (expected, not a vulnerability)")

        self.results.append(TestResult(
            test_id="SEC-1",
            name="Encryption at Rest",
            category=self.category,
            passed=passed,
            details="\n".join(details) or "All model files appear encrypted",
            threshold="No plaintext weights or data on disk (data section only)",
        ))

    # ── SEC-2: Encrypted Execution ──────────────────────────────
    def _test_sec2_encrypted_execution(self) -> None:
        """Inspect runtime memory for plaintext model data during inference."""
        details: list[str] = []
        passed = True

        # Find the vLLM container PID — try multiple possible container names
        # (dk_vllm_bench = runner-managed, vllm_enc_server = manually started)
        _candidate_containers = [
            self.cfg.get("vllm_enc_container", "vllm_enc_server"),
            "vllm_enc_server",
            "dk_vllm_bench",
        ]
        pid_out = ""
        _found_container = ""
        for _cname in _candidate_containers:
            code, pid_out, _ = self.gpu.run(
                f"docker inspect --format '{{{{.State.Pid}}}}' {_cname} 2>/dev/null",
                check=False,
            )
            if code == 0 and pid_out.strip() and pid_out.strip() != "0":
                _found_container = _cname
                break
        if not pid_out.strip() or pid_out.strip() == "0":
            self.results.append(TestResult(
                test_id="SEC-2", name="Encrypted Execution", category=self.category,
                passed=False, details=f"Could not find vLLM container PID (tried: {_candidate_containers})",
            ))
            return
        details.append(f"Using container: {_found_container} (PID={pid_out.strip()})")

        pid = pid_out.strip()

        # Scan process memory maps for plaintext patterns
        for pattern in _PLAINTEXT_PATTERNS[:3]:  # Check subset for speed
            code, out, _ = self.gpu.run(
                f"grep -c '{pattern.decode()}' /proc/{pid}/maps 2>/dev/null || echo 0",
                check=False,
            )
            count = int(out.strip()) if out.strip().isdigit() else 0
            if count > 0:
                details.append(f"WARNING: Pattern '{pattern.decode()}' found in memory maps")
            else:
                details.append(f"OK: No '{pattern.decode()}' in memory maps")

        # Dump a small segment of GPU memory via nvidia-smi
        code, gpu_out, _ = self.gpu.run(
            "nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader 2>/dev/null",
            check=False,
        )
        details.append(f"GPU compute processes: {gpu_out.strip()}")

        self.results.append(TestResult(
            test_id="SEC-2",
            name="Encrypted Execution",
            category=self.category,
            passed=passed,
            details="\n".join(details),
            threshold="No plaintext exposure in RAM or GPU VRAM",
        ))

    # ── SEC-3: Secure Transport ─────────────────────────────────
    def _test_sec3_secure_transport(self) -> None:
        """Verify TLS is used and capture brief network traffic for analysis."""
        details: list[str] = []
        passed = True

        # Verify TEE uses HTTPS
        tee_url = self.cfg.tee_user_url
        if not tee_url.startswith("https://"):
            passed = False
            details.append(f"FAIL: TEE URL is not HTTPS: {tee_url}")
        else:
            details.append(f"OK: TEE endpoint uses HTTPS: {tee_url}")

        # Brief tcpdump to check for plaintext in transit
        tee_port = self.cfg["tee_user_port"]
        code, capture_out, _ = self.gpu.run(
            f"timeout 5 tcpdump -i any -A port {tee_port} -c 20 2>/dev/null | "
            f"grep -ci 'model\\|weight\\|tensor' || echo 0",
            check=False,
        )
        try:
            plaintext_lines = int(capture_out.strip())
        except ValueError:
            plaintext_lines = 0

        if plaintext_lines > 0:
            passed = False
            details.append(f"FAIL: Found {plaintext_lines} potential plaintext matches in network traffic")
        else:
            details.append("OK: No plaintext model data detected in network traffic")

        self.results.append(TestResult(
            test_id="SEC-3",
            name="Secure Transport",
            category=self.category,
            passed=passed,
            details="\n".join(details),
            threshold="No readable inputs, outputs, or model data in transit",
        ))

    # ── SEC-4: Model Binding ────────────────────────────────────
    def _test_sec4_model_binding(self) -> None:
        """Attempt to execute encrypted model outside FHEnom pipeline."""
        details: list[str] = []
        passed = True

        enc_path = self.cfg["model_path_encrypted"]

        # Try to load model directly with transformers (should fail or produce garbage)
        code, out, err = self.gpu.run(
            f"python3 -c \""
            f"from transformers import AutoModelForCausalLM; "
            f"try:\\n"
            f"    m = AutoModelForCausalLM.from_pretrained('{enc_path}')\\n"
            f"    print('LOADED_OK')\\n"
            f"except Exception as e:\\n"
            f"    print(f'LOAD_FAIL: {{e}}')\\n"
            f"\"",
            check=False,
            timeout=120,
        )

        if "LOADED_OK" in out:
            # Model loaded — check if it can generate meaningful output
            code2, out2, _ = self.gpu.run(
                f"python3 -c \""
                f"from transformers import AutoModelForCausalLM, AutoTokenizer; "
                f"import torch; "
                f"m = AutoModelForCausalLM.from_pretrained('{enc_path}'); "
                f"t = AutoTokenizer.from_pretrained('{self.cfg['model_path_clear']}'); "
                f"inp = t('Hello world', return_tensors='pt'); "
                f"out = m.generate(**inp, max_new_tokens=20); "
                f"print(t.decode(out[0]))\"",
                check=False,
                timeout=120,
            )
            if out2.strip() and "error" not in out2.lower():
                passed = False
                details.append(f"FAIL: Encrypted model produced output outside FHEnom: {out2[:200]}")
            else:
                details.append("OK: Encrypted model loaded but could not generate meaningful output")
        else:
            details.append(f"OK: Encrypted model cannot be loaded outside FHEnom: {out[:200]}")

        self.results.append(TestResult(
            test_id="SEC-4",
            name="Model Binding",
            category=self.category,
            passed=passed,
            details="\n".join(details),
            threshold="Model cannot execute correctly or produces non-meaningful outputs",
        ))

    # ── SEC-5: Key Isolation ────────────────────────────────────
    def _test_sec5_key_isolation(self) -> None:
        """Attempt to access key material from outside the TEE."""
        details: list[str] = []
        passed = True

        # Check GPU host for key material
        code, out, _ = self.gpu.run(
            "find /tmp /home /root -name '*.key' -o -name '*.pem' -o -name 'secret*' "
            "2>/dev/null | head -20",
            check=False,
        )
        key_files = [f for f in out.strip().split("\n") if f.strip() and "ssh" not in f.lower()]
        if key_files:
            details.append(f"WARNING: Found potential key files on GPU host: {key_files}")
        else:
            details.append("OK: No FHEnom key material found on GPU host")

        # Check for key material in environment variables
        code, out, _ = self.gpu.run(
            "env | grep -i 'key\\|secret\\|token' | grep -v SSH | grep -v PATH | head -10",
            check=False,
        )
        if out.strip():
            details.append(f"WARNING: Sensitive env vars found: {out.strip()[:200]}")
        else:
            details.append("OK: No sensitive key/secret env vars exposed")

        # Check for key material in docker inspect — try both container names
        enc_container = self.cfg.get("vllm_enc_container", "vllm_enc_server")
        code, out, _ = self.gpu.run(
            f"docker inspect {enc_container} dk_vllm_bench 2>/dev/null | grep -i 'key\\|secret' | head -5",
            check=False,
        )
        if out.strip():
            details.append(f"INFO: Docker config references: {out.strip()[:200]}")

        self.results.append(TestResult(
            test_id="SEC-5",
            name="Key Isolation",
            category=self.category,
            passed=passed,
            details="\n".join(details),
            threshold="No key material accessible outside TEE boundary",
        ))

    # ── SEC-6: Logging Safety ───────────────────────────────────
    def _test_sec6_logging_safety(self) -> None:
        """Inspect logs for plaintext model data or sensitive information."""
        details: list[str] = []
        passed = True

        # Check vLLM container logs — try configured name then dk_vllm_bench
        enc_container = self.cfg.get("vllm_enc_container", "vllm_enc_server")
        logs = self.gpu.docker_logs(enc_container, tail=500)
        if not logs.strip():
            logs = self.gpu.docker_logs("dk_vllm_bench", tail=500)

        # Look for plaintext model weights in logs
        sensitive_patterns = [
            r"weight\s*=\s*tensor",
            r"FloatTensor",
            r"model\.layers\.\d+",
            r"plaintext",
            r"decrypted",
        ]
        for pat in sensitive_patterns:
            matches = re.findall(pat, logs, re.IGNORECASE)
            if matches:
                passed = False
                details.append(f"FAIL: Pattern '{pat}' found {len(matches)} times in vLLM logs")

        # Check system logs on GPU host
        code, syslog, _ = self.gpu.run(
            "journalctl --no-pager -n 200 2>/dev/null | grep -ci 'plaintext\\|decrypted\\|weight.*tensor' || echo 0",
            check=False,
        )
        try:
            syslog_matches = int(syslog.strip())
        except ValueError:
            syslog_matches = 0
        if syslog_matches > 0:
            details.append(f"WARNING: {syslog_matches} potential plaintext references in system logs")
        else:
            details.append("OK: No plaintext data found in system logs")

        if not details or all("OK" in d for d in details):
            details.append("OK: No plaintext data or model information present in logs")

        self.results.append(TestResult(
            test_id="SEC-6",
            name="Logging Safety",
            category=self.category,
            passed=passed,
            details="\n".join(details),
            threshold="No plaintext data or model information present in logs",
        ))
