"""
dk-test-suite — DataKrypto FHEnom for AI™ POC Test Suite

Automated head-to-head validation framework for encrypted vs. plaintext model comparison.

Copyright © 2026 DataKrypto. All rights reserved.
"""

__version__ = "1.0.2"
__author__ = "DataKrypto"
__email__ = "support@datakrypto.ai"
