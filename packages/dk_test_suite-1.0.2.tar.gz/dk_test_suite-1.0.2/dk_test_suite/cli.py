"""dk-test — CLI entry point for the FHEnom POC test suite."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import click

from dk_test_suite import __version__
from dk_test_suite.config import load_config
from dk_test_suite.runner import TestRunner


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    # Suppress noisy libraries
    for lib in ("paramiko", "httpx", "httpcore", "urllib3"):
        logging.getLogger(lib).setLevel(logging.WARNING)


@click.group()
@click.version_option(version=__version__, prog_name="dk-test")
def main() -> None:
    """FHEnom for AI — POC Head-to-Head Test Suite."""
    pass


@main.command()
@click.option("-c", "--config", "config_path", type=click.Path(exists=True),
              help="Path to YAML config override file.")
@click.option("--gpu-host", help="Override GPU machine IP.")
@click.option("--tee-host", help="Override TEE machine IP.")
@click.option("--model", "model_name", help="Override model name.")
@click.option("--output", "output_dir", help="Output directory for results.")
@click.option("--categories", "-t", multiple=True,
              type=click.Choice(["performance", "accuracy", "scalability", "security", "serving", "training"]),
              help="Test categories to run (default: all).")
@click.option("--num-prompts", type=int, help="Number of benchmark prompts.")
@click.option("--skip-clear-vllm", is_flag=True,
              help="Assume vLLM is already running with clear model.")
@click.option("--skip-encrypted-vllm", is_flag=True,
              help="Assume vLLM is already running with encrypted model.")
@click.option("--local", "local_mode", is_flag=True,
              help="Run on this machine — GPU commands execute locally, no SSH key needed for GPU.")
@click.option("--gpu-ssh-key", help="Override path to SSH private key for the GPU.")
@click.option("--tee-ssh-key", help="Override path to SSH private key for the TEE.")
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging.")
def run(config_path: str | None, gpu_host: str | None, tee_host: str | None,
        model_name: str | None, output_dir: str | None,
        categories: tuple[str, ...], num_prompts: int | None,
        skip_clear_vllm: bool, skip_encrypted_vllm: bool,
        local_mode: bool, gpu_ssh_key: str | None, tee_ssh_key: str | None,
        verbose: bool) -> None:
    """Run the full POC test suite (or selected categories)."""
    _setup_logging(verbose)

    # Build CLI overrides
    overrides: dict[str, object] = {}
    if gpu_host:
        overrides["gpu_host"] = gpu_host
    if tee_host:
        overrides["tee_host"] = tee_host
    if model_name:
        overrides["model_name"] = model_name
    if output_dir:
        overrides["output_dir"] = output_dir
    if num_prompts:
        overrides["num_prompts"] = num_prompts
    if local_mode:
        overrides["local_mode"] = True
    if gpu_ssh_key:
        overrides["gpu_ssh_key"] = gpu_ssh_key
    if tee_ssh_key:
        overrides["tee_ssh_key"] = tee_ssh_key

    cfg = load_config(override_path=config_path, cli_overrides=overrides)

    runner = TestRunner(cfg)
    cats = list(categories) if categories else None
    report = runner.run(
        categories=cats,
        skip_clear_vllm=skip_clear_vllm,
        skip_encrypted_vllm=skip_encrypted_vllm,
    )
    click.echo(f"\nReport: {report}")


@main.command("scale4-sustained")
@click.option("-c", "--config", "config_path", type=click.Path(exists=True))
@click.option("--hours", type=int, default=24, help="Duration in hours (default: 24).")
@click.option("--local", "local_mode", is_flag=True,
              help="Run on this machine — no SSH to GPU.")
@click.option("-v", "--verbose", is_flag=True)
def scale4_sustained(config_path: str | None, hours: int, local_mode: bool, verbose: bool) -> None:
    """Run the full 24-hour sustained operation test (SCALE-4)."""
    _setup_logging(verbose)
    overrides: dict[str, object] = {}
    if local_mode:
        overrides["local_mode"] = True
    cfg = load_config(override_path=config_path, cli_overrides=overrides if overrides else None)
    click.echo(f"Running 24h sustained test for {hours} hours…")
    click.echo("NOTE: This runs the abbreviated sustained test in a loop.")
    click.echo("      Monitor the output directory for periodic results.")

    from dk_test_suite.utils import LocalHost, RemoteHost
    from dk_test_suite.vllm_manager import VLLMManager
    from dk_test_suite.tee_manager import TEEManager
    from dk_test_suite.tests.scalability import ScalabilityTests

    if cfg.get("local_mode", False):
        gpu: RemoteHost | LocalHost = LocalHost()
    else:
        gpu = RemoteHost(cfg.gpu_host, cfg["gpu_ssh_user"], cfg["gpu_ssh_key"])
    gpu.connect()
    vllm = VLLMManager(cfg, gpu)
    tee = TEEManager(cfg, gpu)

    # Run for clear
    vllm._base = f"http://{cfg.gpu_host}:{cfg['vllm_port']}"
    scale = ScalabilityTests(cfg, vllm, tee)

    # Override sustained duration
    scale.scale_cfg["sustained_duration_hours"] = hours

    click.echo("Phase 1: Clear model sustained test")
    scale.clear_sustained = scale._sustained_test(
        inference_fn=scale._clear_inference,
        duration_minutes=hours * 60,
    )

    click.echo("Phase 2: Encrypted model sustained test")
    scale.enc_sustained = scale._sustained_test(
        inference_fn=scale._enc_inference,
        duration_minutes=hours * 60,
    )

    results = scale.compare()
    for r in results:
        if r.test_id == "SCALE-4":
            status = "PASS" if r.passed else "FAIL"
            click.echo(f"\nSCALE-4: {status}")
            click.echo(r.details)

    gpu.close()
    tee.close()


@main.command("report")
@click.argument("results_dir", type=click.Path(exists=True))
@click.option("-c", "--config", "config_path", type=click.Path(exists=True))
def report_cmd(results_dir: str, config_path: str | None) -> None:
    """Regenerate HTML report from existing JSON results."""
    import json
    from dk_test_suite.report import generate_report
    from dk_test_suite.tests.base import TestResult

    _setup_logging(False)
    cfg = load_config(override_path=config_path)

    # Load all *_results.json files
    results: list[TestResult] = []
    results_path = Path(results_dir)
    for jf in sorted(results_path.glob("*_results.json")):
        with open(jf) as f:
            data = json.load(f)
        for item in data:
            results.append(TestResult(**item))

    if not results:
        click.echo("No result files found in " + results_dir)
        return

    report = generate_report(results, cfg, results_path)
    click.echo(f"Report: {report}")


@main.command("info")
@click.option("-c", "--config", "config_path", type=click.Path(exists=True))
@click.option("--local", "local_mode", is_flag=True,
              help="Show local configuration (no SSH connectivity check).")
def info_cmd(config_path: str | None, local_mode: bool) -> None:
    """Show current configuration and connectivity status."""
    import yaml

    overrides: dict[str, object] = {}
    if local_mode:
        overrides["local_mode"] = True
    cfg = load_config(override_path=config_path, cli_overrides=overrides if overrides else None)
    click.echo("═" * 60)
    click.echo("FHEnom for AI — POC Test Suite Configuration")
    click.echo("═" * 60)
    click.echo(yaml.dump(cfg.raw, default_flow_style=False, sort_keys=False))

    # Test connectivity
    click.echo("─" * 60)
    click.echo("Connectivity check:")
    from dk_test_suite.utils import LocalHost, RemoteHost
    if cfg.get("local_mode", False):
        try:
            gpu: RemoteHost | LocalHost = LocalHost()
            _, out, _ = gpu.run("nvidia-smi --query-gpu=name --format=csv,noheader")
            click.echo(f"  GPU (local): ✓ — {out.strip()}")
        except Exception as e:
            click.echo(f"  GPU (local): ✗ — {e}")
    else:
        try:
            gpu = RemoteHost(cfg.gpu_host, cfg["gpu_ssh_user"], cfg["gpu_ssh_key"])
            gpu.connect()
            _, out, _ = gpu.run("nvidia-smi --query-gpu=name --format=csv,noheader")
            click.echo(f"  GPU ({cfg.gpu_host}): ✓ — {out.strip()}")
            gpu.close()
        except Exception as e:
            click.echo(f"  GPU ({cfg.gpu_host}): ✗ — {e}")

    try:
        import httpx
        r = httpx.get(f"{cfg.tee_admin_url}/health",
                      headers={"X-Auth-Token": cfg["tee_admin_token"]},
                      verify=False, timeout=10)
        click.echo(f"  TEE ({cfg.tee_host}): ✓ — HTTP {r.status_code}")
    except Exception as e:
        click.echo(f"  TEE ({cfg.tee_host}): ✗ — {e}")


if __name__ == "__main__":
    main()
