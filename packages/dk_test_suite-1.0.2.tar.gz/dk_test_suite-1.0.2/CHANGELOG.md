# Changelog

## 1.0.2 (2025-04-16)

### Improvements

- **Production-quality README** — complete CLI reference, all 30 test descriptions, configuration reference, execution flow diagram
- **Version fix** — `dk-test --version` now reports the correct version from `__init__.py`
- **Package config** — `config/default.yaml` is now bundled inside the wheel (works with PyPI installs)
- **Code cleanup** — removed internal development references from source code

## 1.0.0 (2025-04-16)

### Initial PyPI Release

- **Performance Tests** (PERF-1 to PERF-5): TTFT, throughput, E2E latency, model footprint, GPU VRAM
- **Accuracy Tests** (ACC-1 to ACC-5): Exact match, lm-eval benchmarks, BERTScore, length t-test, perplexity
- **Scalability Tests** (SCALE-1 to SCALE-4): Concurrent load, context length, batch processing, sustained operation
- **Security Tests** (SEC-1 to SEC-6): Encryption at rest, memory inspection, TLS, model binding, key isolation, log safety
- **Serving Tests** (SERV-1 to SERV-7): File integrity, vLLM health, TEE status, inference coherence, bypass proof, output fidelity, FHE overhead
- **Training Tests** (T-1 to T-3): Secure checkpoints, convergence, post-training inference quality
- CLI entry point: `dk-test run`
- HTML report generation with side-by-side comparison tables
- Local and remote runner modes
- YAML-based configuration with CLI overrides
