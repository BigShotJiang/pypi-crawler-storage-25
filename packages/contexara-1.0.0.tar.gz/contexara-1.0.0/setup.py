from setuptools import setup
from setuptools.command.install import install


class PostInstall(install):
    def run(self):
        super().run()
        print("")
        print("  ──────────────────────────────────────────")
        print("   Contexara installed! Run setup next:")
        print("")
        print("     contexara setup")
        print("")
        print("   This configures your AWS Bedrock credentials.")
        print("  ──────────────────────────────────────────")
        print("")


setup(cmdclass={"install": PostInstall})
