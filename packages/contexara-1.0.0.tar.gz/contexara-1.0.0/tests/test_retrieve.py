import importlib

store_module = importlib.import_module("contexara.store")
from contexara.retrieve import _normalize, _tokenize, retrieve


def test_normalize_removes_punctuation_and_lowercases():
    assert _normalize("Hello, WORLD!! It's me.") == "hello world it s me"


def test_tokenize_removes_stopwords():
    tokens = _tokenize("What is my name right now")
    assert "what" not in tokens
    assert "my" not in tokens
    assert "name" in tokens


def test_retrieve_name_query_prioritizes_name_memory():
    store_module.store("My name is Prajwal and you can call me PJ")
    store_module.store("I use a Dell laptop with 8 GB RAM")

    results = retrieve("what is my name?")

    assert results
    assert "Prajwal" in results[0]


def test_retrieve_calendar_query_finds_date_memory():
    store_module.store("Today is April 14, 2026 Tuesday")
    store_module.store("I like dark mode")

    results = retrieve("today's date and day?")

    assert results
    assert "April 14, 2026" in results[0]


def test_retrieve_semantic_finds_preference_by_meaning():
    """RRF should surface a semantically related memory even without keyword overlap."""
    store_module.store("User enjoys working in low-light environments")
    store_module.store("User is building a CLI tool in Python")

    results = retrieve("does the user prefer dark mode?")

    assert results
    assert any("low-light" in r for r in results)


def test_retrieve_returns_results_for_unrelated_query():
    """RRF always returns top_k results — no hard fallback needed."""
    store_module.store("Older memory")
    store_module.store("Newest memory")

    results = retrieve("quantum banana waterfall", top_k=2)

    assert len(results) == 2


def test_retrieve_empty_query_returns_empty_list():
    store_module.store("Any memory")
    assert retrieve("   ") == []
