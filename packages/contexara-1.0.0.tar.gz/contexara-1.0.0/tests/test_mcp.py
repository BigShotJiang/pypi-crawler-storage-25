"""Tests for Contexara MCP server — all 13 tools, error contracts, result capping."""
from __future__ import annotations

import asyncio
import importlib
from pathlib import Path
from uuid import uuid4

import pytest

session_module = importlib.import_module("contexara.session")
store_module = importlib.import_module("contexara.store")
retrieve_module = importlib.import_module("contexara.retrieve")


@pytest.fixture(autouse=True)
def isolated_dbs(monkeypatch, tmp_path):
    """Isolated DBs per test — MCP tools must not touch production data."""
    mem_db = tmp_path / f"mem_{uuid4().hex}.db"
    sess_db = tmp_path / f"sess_{uuid4().hex}.db"

    monkeypatch.setattr(store_module, "DB_PATH", mem_db)
    monkeypatch.setattr(retrieve_module, "DB_PATH", mem_db)
    monkeypatch.setattr(session_module, "DB_PATH", sess_db)

    store_module._initialize_db()
    store_module.clear_all()
    session_module.initialize_session_db()
    yield


def _mock_embedder(monkeypatch):
    import numpy as np
    import hashlib

    def fake_embed(text: str) -> np.ndarray:
        seed = int(hashlib.md5(text.encode()).hexdigest(), 16) % (2**31)
        rng = np.random.default_rng(seed)
        v = rng.random(1536).astype(np.float32)
        v /= np.linalg.norm(v)
        return v

    monkeypatch.setattr(store_module, "embed", fake_embed)
    monkeypatch.setattr(retrieve_module, "embed", fake_embed)


def run(coro):
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Error contract — all tools must return {"ok": false} not raise
# ---------------------------------------------------------------------------

def test_memory_store_error_contract(monkeypatch):
    from contexara.mcp_server import memory_store
    monkeypatch.setattr(store_module, "upsert_memory", lambda **kw: (_ for _ in ()).throw(RuntimeError("boom")))
    result = run(memory_store(content="test"))
    assert result["ok"] is False
    assert "error" in result


def test_memory_search_error_contract(monkeypatch):
    from contexara.mcp_server import memory_search
    monkeypatch.setattr(retrieve_module, "retrieve", lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("boom")))
    result = run(memory_search(query="anything"))
    assert result["ok"] is False
    assert "error" in result


def test_chat_ingest_error_contract(monkeypatch):
    from contexara.mcp_server import chat_ingest
    monkeypatch.setattr(session_module, "get_or_create_session", lambda **kw: (_ for _ in ()).throw(RuntimeError("boom")))
    result = run(chat_ingest(user_text="hi", assistant_text="hello"))
    assert result["ok"] is False
    assert "error" in result


# ---------------------------------------------------------------------------
# chat_ingest
# ---------------------------------------------------------------------------

def test_chat_ingest_success(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import chat_ingest
    result = run(chat_ingest(user_text="what is 2+2?", assistant_text="It's 4.", namespace="default"))
    assert result["ok"] is True
    assert "session_id" in result


def test_chat_ingest_creates_turns(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import chat_ingest, chat_context
    run(chat_ingest(user_text="hello", assistant_text="hi", namespace="default"))
    ctx = run(chat_context(n=10, namespace="default"))
    assert ctx["ok"] is True
    assert ctx["count"] == 2


# ---------------------------------------------------------------------------
# chat_context
# ---------------------------------------------------------------------------

def test_chat_context_empty_on_new_session():
    from contexara.mcp_server import chat_context
    result = run(chat_context(n=10, namespace="fresh_ns"))
    assert result["ok"] is True
    assert result["count"] == 0
    assert result["turns"] == []


def test_chat_context_caps_at_50(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import chat_ingest, chat_context
    for i in range(5):
        run(chat_ingest(user_text=f"msg {i}", assistant_text=f"reply {i}", namespace="default"))
    result = run(chat_context(n=100, namespace="default"))
    assert result["ok"] is True
    # n is capped at 50 internally — with only 10 turns, all 10 are returned
    assert result["count"] <= 50


# ---------------------------------------------------------------------------
# memory_store
# ---------------------------------------------------------------------------

def test_memory_store_success(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store
    result = run(memory_store(content="user prefers Python", kind="preference", importance=3))
    assert result["ok"] is True
    assert result["result"] in ("inserted", "updated")
    assert result["kind"] == "preference"


def test_memory_store_idempotent(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store
    run(memory_store(content="user prefers Python", kind="preference"))
    result = run(memory_store(content="user prefers Python", kind="preference"))
    assert result["ok"] is True
    assert result["result"] == "updated"


def test_memory_store_namespace_isolated(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_search
    run(memory_store(content="secret fact", namespace="ns_a"))
    result = run(memory_search(query="secret fact", namespace="ns_b"))
    assert result["ok"] is True
    assert result["count"] == 0


# ---------------------------------------------------------------------------
# memory_search
# ---------------------------------------------------------------------------

def test_memory_search_returns_results(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_search
    run(memory_store(content="user loves dark mode", kind="preference"))
    result = run(memory_search(query="dark mode"))
    assert result["ok"] is True
    assert result["count"] >= 1
    assert any("dark mode" in m for m in result["memories"])


def test_memory_search_caps_at_20(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_search

    for i in range(25):
        run(memory_store(content=f"unique fact number {i} about the system"))

    result = run(memory_search(query="fact about system", top_k=25))
    assert result["ok"] is True
    assert result["count"] <= 20


def test_memory_search_more_results_flag(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_search

    for i in range(12):
        run(memory_store(content=f"searchable item {i} with unique content"))

    result = run(memory_search(query="searchable item", top_k=10))
    assert result["ok"] is True
    # With 12 items and top_k=10, more_results should be True
    assert result["more_results"] is True


# ---------------------------------------------------------------------------
# memory_list
# ---------------------------------------------------------------------------

def test_memory_list_returns_all(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_list
    run(memory_store(content="fact one"))
    run(memory_store(content="fact two"))
    result = run(memory_list(namespace="default"))
    assert result["ok"] is True
    assert result["count"] == 2


def test_memory_list_empty_namespace():
    from contexara.mcp_server import memory_list
    result = run(memory_list(namespace="empty_ns"))
    assert result["ok"] is True
    assert result["count"] == 0


# ---------------------------------------------------------------------------
# memory_forget
# ---------------------------------------------------------------------------

def test_memory_forget_deletes_by_id(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_list, memory_forget
    run(memory_store(content="to be deleted"))
    lst = run(memory_list(namespace="default"))
    mid = lst["memories"][0]["id"]

    result = run(memory_forget(memory_id=mid, namespace="default"))
    assert result["ok"] is True
    assert result["deleted"] is True

    after = run(memory_list(namespace="default"))
    assert after["count"] == 0


def test_memory_forget_returns_false_for_missing_id():
    from contexara.mcp_server import memory_forget
    result = run(memory_forget(memory_id=999999, namespace="default"))
    assert result["ok"] is True
    assert result["deleted"] is False


def test_memory_forget_namespace_scoped(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_list, memory_forget
    run(memory_store(content="ns_a fact", namespace="ns_a"))
    lst = run(memory_list(namespace="ns_a"))
    mid = lst["memories"][0]["id"]

    # Try to delete from wrong namespace — should not delete
    result = run(memory_forget(memory_id=mid, namespace="ns_b"))
    assert result["deleted"] is False

    remaining = run(memory_list(namespace="ns_a"))
    assert remaining["count"] == 1


# ---------------------------------------------------------------------------
# memory_deprecate
# ---------------------------------------------------------------------------

def test_memory_deprecate_soft_deletes(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_list, memory_deprecate
    run(memory_store(content="outdated info"))
    lst = run(memory_list(namespace="default"))
    mid = lst["memories"][0]["id"]

    result = run(memory_deprecate(memory_id=mid, namespace="default"))
    assert result["ok"] is True
    assert result["deprecated"] is True

    conn = store_module._get_connection()
    row = conn.execute("SELECT compression_level FROM memories WHERE id = ?", (mid,)).fetchone()
    conn.close()
    assert row["compression_level"] == 10


def test_memory_deprecate_returns_false_for_missing_id():
    from contexara.mcp_server import memory_deprecate
    result = run(memory_deprecate(memory_id=999999, namespace="default"))
    assert result["ok"] is True
    assert result["deprecated"] is False


# ---------------------------------------------------------------------------
# memory_stats
# ---------------------------------------------------------------------------

def test_memory_stats_correct_counts(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_stats
    run(memory_store(content="pref", kind="preference", namespace="stats_ns"))
    run(memory_store(content="task", kind="task", namespace="stats_ns"))

    result = run(memory_stats(namespace="stats_ns"))
    assert result["ok"] is True
    assert result["total"] == 2
    assert result["by_kind"]["preference"] == 1
    assert result["by_kind"]["task"] == 1


def test_memory_stats_excludes_deprecated(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.mcp_server import memory_store, memory_list, memory_deprecate, memory_stats
    run(memory_store(content="active", namespace="dep_stats_ns"))
    run(memory_store(content="deprecated", namespace="dep_stats_ns"))
    lst = run(memory_list(namespace="dep_stats_ns"))
    mid = lst["memories"][1]["id"]
    run(memory_deprecate(memory_id=mid, namespace="dep_stats_ns"))

    result = run(memory_stats(namespace="dep_stats_ns"))
    assert result["total"] == 1


# ---------------------------------------------------------------------------
# episodes_latest
# ---------------------------------------------------------------------------

def test_episodes_latest_returns_not_found_when_empty():
    from contexara.mcp_server import episodes_latest
    result = run(episodes_latest(namespace="empty_ep_ns"))
    assert result["ok"] is True
    assert result["found"] is False
    assert result["summary"] is None


def test_episodes_latest_returns_summary_when_exists():
    from contexara.mcp_server import episodes_latest
    conn = session_module._get_connection()
    conn.execute(
        "INSERT INTO episodes (session_id, summary, started_at, ended_at, created_at, namespace) VALUES (?, ?, ?, ?, ?, ?)",
        ("sess-1", "Built the MCP server", "2025-01-01T00:00:00+00:00", "2025-01-01T01:00:00+00:00", "2025-01-01T01:00:00+00:00", "default"),
    )
    conn.commit()
    conn.close()

    result = run(episodes_latest(namespace="default"))
    assert result["ok"] is True
    assert result["found"] is True
    assert result["summary"] == "Built the MCP server"


# ---------------------------------------------------------------------------
# session_checkpoint
# ---------------------------------------------------------------------------

def test_session_checkpoint_returns_false_when_no_open_session():
    from contexara.mcp_server import session_checkpoint
    result = run(session_checkpoint(namespace="no_session_ns"))
    assert result["ok"] is True
    assert result["crystallized"] is False


def test_session_checkpoint_success(monkeypatch):
    _mock_embedder(monkeypatch)
    import io, json
    from unittest.mock import MagicMock

    # Mock LLM for crystallization summary
    mock_client = MagicMock()
    mock_client.invoke_model.return_value = {
        "body": io.BytesIO(json.dumps({"content": [{"text": "Session summary: built features."}]}).encode())
    }
    llm = importlib.import_module("contexara.llm")
    monkeypatch.setattr(llm, "_get_client", lambda *a, **kw: mock_client)

    from contexara.mcp_server import chat_ingest, session_checkpoint
    run(chat_ingest(user_text="hello", assistant_text="hi", namespace="default"))

    result = run(session_checkpoint(namespace="default"))
    assert result["ok"] is True
    assert result["crystallized"] is True
    assert "session_id" in result


# ---------------------------------------------------------------------------
# namespace_list
# ---------------------------------------------------------------------------

def test_namespace_list_returns_all():
    from contexara.mcp_server import namespace_list
    session_module.create_namespace("agent_x")
    session_module.create_namespace("agent_y")

    result = run(namespace_list())
    assert result["ok"] is True
    names = [n["name"] for n in result["namespaces"]]
    assert "agent_x" in names
    assert "agent_y" in names


def test_namespace_list_empty():
    from contexara.mcp_server import namespace_list
    result = run(namespace_list())
    assert result["ok"] is True
    assert result["count"] == 0
