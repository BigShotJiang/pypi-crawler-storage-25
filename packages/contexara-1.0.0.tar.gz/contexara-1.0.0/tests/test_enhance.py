import pytest

from contexara.enhance import enhance


def test_enhance_includes_memory_context_when_available():
    prompt = enhance("What is my name?", ["My name is Prajwal"])

    assert "Relevant context:" in prompt
    assert "- My name is Prajwal" in prompt
    assert "User:\nWhat is my name?" in prompt
    assert prompt.endswith("Assistant:")


def test_enhance_without_memories_uses_generic_context():
    prompt = enhance("Hello", [])

    assert "Relevant context:" not in prompt
    assert "User:\nHello" in prompt


def test_enhance_rejects_empty_query():
    with pytest.raises(ValueError, match="cannot be empty"):
        enhance("   ", ["memory"])


def test_enhance_includes_episode_hits():
    prompt = enhance("What did I work on today?", [], episode_hits=["Session (2026-04-22): built archive module"])
    assert "Session history matching your query:" in prompt
    assert "built archive module" in prompt


def test_enhance_includes_recent_turns():
    turns = [{"role": "user", "content": "hello"}, {"role": "assistant", "content": "hi"}]
    prompt = enhance("What did I say?", [], recent_turns=turns)
    assert "Recent conversation:" in prompt
    assert "User: hello" in prompt


def test_enhance_includes_episode_anchor():
    prompt = enhance("Continue my work", [], episode_anchor="Built the archive module")
    assert "In your last session:" in prompt
    assert "Built the archive module" in prompt
