from unittest.mock import patch

from contexara.extract import extract_memories, _regex_extract


# ---------------------------------------------------------------------------
# LLM extraction tests (mocked Bedrock)
# ---------------------------------------------------------------------------

def _mock_llm_extraction(memories: list[dict]):
    """Patch _call_llm_for_extraction to return fixed memories."""
    return patch("contexara.extract._call_llm_for_extraction", return_value=memories)


def test_llm_extraction_stores_profile_preference_task():
    fake = [
        {"content": "User name is Prajwal", "kind": "profile", "importance": 5, "ttl_days": None},
        {"content": "User prefers concise answers", "kind": "preference", "importance": 4, "ttl_days": None},
        {"content": "User is building a memory engine", "kind": "task", "importance": 3, "ttl_days": None},
    ]
    with _mock_llm_extraction(fake):
        items = extract_memories("My name is Prajwal. I prefer concise answers. I am building a memory engine.", "")

    kinds = {item["kind"] for item in items}
    assert "profile" in kinds
    assert "preference" in kinds
    assert "task" in kinds


def test_llm_extraction_captures_past_tense_completion():
    fake = [
        {"content": "User built hybrid search for Contexara v2", "kind": "task", "importance": 3, "ttl_days": None},
    ]
    with _mock_llm_extraction(fake):
        items = extract_memories("I just built hybrid search, now testing it", "Great progress!")

    assert any("hybrid search" in item["content"].lower() for item in items)


def test_llm_extraction_uses_assistant_text():
    """LLM extractor receives assistant_text and existing_memories."""
    with patch("contexara.extract._call_llm_for_extraction", return_value=[]) as mock:
        extract_memories("hello", "You are working on Contexara.", existing_memories=["User is Prajwal"])
        mock.assert_called_once_with("hello", "You are working on Contexara.", ["User is Prajwal"])


def test_llm_extraction_deduplicates_within_turn():
    fake = [
        {"content": "User is building Contexara", "kind": "task", "importance": 3, "ttl_days": None},
        {"content": "User is building Contexara", "kind": "task", "importance": 3, "ttl_days": None},
    ]
    with _mock_llm_extraction(fake):
        items = extract_memories("I am building Contexara", "")

    assert len(items) == 1


# ---------------------------------------------------------------------------
# Regex fallback tests (LLM returns empty)
# ---------------------------------------------------------------------------

def test_regex_fallback_used_when_llm_returns_empty():
    with _mock_llm_extraction([]):
        items = extract_memories("My name is Prajwal", "")

    assert any("Prajwal" in item["content"] for item in items)


def test_regex_fallback_ignores_questions_and_low_signal():
    with _mock_llm_extraction([]):
        items = extract_memories("What is my name? thanks", "")

    assert items == []


def test_regex_extract_past_tense_task_patterns():
    items = _regex_extract("I just built hybrid search for Contexara.")
    assert any("hybrid search" in item["content"].lower() for item in items)


def test_regex_extract_testing_pattern():
    items = _regex_extract("I'm testing the new retrieval pipeline now.")
    assert any("retrieval pipeline" in item["content"].lower() for item in items)