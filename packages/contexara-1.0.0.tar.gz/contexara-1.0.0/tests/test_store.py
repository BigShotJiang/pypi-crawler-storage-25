import importlib
import pytest

store_module = importlib.import_module("contexara.store")


def test_store_and_list_all_returns_latest_first():
    store_module.store("first memory")
    store_module.store("second memory")

    items = store_module.list_all()

    assert len(items) == 2
    assert [item["content"] for item in items] == ["second memory", "first memory"]
    assert all("id" in item and "created_at" in item for item in items)


def test_store_strips_whitespace():
    store_module.store("  memory with spaces  ")
    items = store_module.list_all()

    assert items[0]["content"] == "memory with spaces"


def test_store_rejects_empty_memory():
    with pytest.raises(ValueError, match="cannot be empty"):
        store_module.store("   ")


def test_clear_all_removes_memories():
    store_module.store("persisted memory")
    assert len(store_module.list_all()) == 1
    store_module.clear_all()
    assert store_module.list_all() == []


def test_delete_memory_removes_by_id():
    store_module.store("memory to delete")
    items = store_module.list_all()
    mid = items[0]["id"]

    result = store_module.delete_memory(mid)

    assert result is True
    assert store_module.list_all() == []


def test_delete_memory_returns_false_for_missing_id():
    result = store_module.delete_memory(99999)
    assert result is False


def test_get_stats_returns_correct_counts():
    store_module.upsert_memory("User name is Prajwal", kind="profile", importance=5)
    store_module.upsert_memory("User prefers dark mode", kind="preference", importance=4)
    store_module.upsert_memory("User is building Contexara", kind="task", importance=3)

    stats = store_module.get_stats()

    assert stats["total"] == 3
    assert stats["by_kind"]["profile"] == 1
    assert stats["by_kind"]["preference"] == 1
    assert stats["by_kind"]["task"] == 1
    assert stats["oldest"] is not None
    assert stats["newest"] is not None


def test_upsert_semantic_dedup_merges_near_duplicates():
    store_module.upsert_memory("User shipped Contexara v1", kind="task", importance=3)
    store_module.upsert_memory("User previously shipped Contexara v1", kind="task", importance=3)

    tasks = [m for m in store_module.list_all() if m["kind"] == "task"]
    assert len(tasks) == 1


def test_upsert_cross_kind_dedup_merges_identical_fact():
    store_module.upsert_memory("User is an AI Engineer named Prajwal", kind="profile", importance=5)
    # Same fact, different kind — should be caught by cross-kind threshold
    store_module.upsert_memory("User is an AI Engineer named Prajwal", kind="note", importance=1)

    all_memories = store_module.list_all()
    assert len(all_memories) == 1


def _mock_llm_response(text: str):
    import io, json
    from unittest.mock import patch, MagicMock
    mock_client = MagicMock()
    mock_client.invoke_model.return_value = {
        "body": io.BytesIO(json.dumps({"content": [{"text": text}]}).encode())
    }
    return patch("contexara.llm._get_client", return_value=mock_client)


def test_consolidate_compresses_and_archives_originals():
    from unittest.mock import patch
    store_module.upsert_memory("User is Prajwal", kind="profile", importance=5)
    store_module.upsert_memory("User is an AI Engineer", kind="profile", importance=5)

    compressed = '[{"content": "User is Prajwal, an AI Engineer", "kind": "profile", "importance": 5}]'

    with _mock_llm_response(compressed), patch("contexara.store._validate_compression", return_value=True):
        result = store_module.consolidate()

    assert result["before"] == 2
    assert result["after"] == 1
    assert result["archived"] == 2

    # Active table has compressed memory
    memories = store_module.list_all()
    assert len(memories) == 1
    assert "Prajwal" in memories[0]["content"]

    # Originals are in archive
    import sqlite3
    from contexara.store import DB_PATH
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("SELECT content FROM memories_archive").fetchall()
    conn.close()
    assert len(rows) == 2


def test_compress_old_memories_skips_when_under_budget():
    store_module.upsert_memory("User is Prajwal", kind="profile", importance=5)
    result = store_module.compress_old_memories()
    assert result["compressed_groups"] == 0
    assert result["archived"] == 0


def test_compress_old_memories_skips_recent_memories():
    from unittest.mock import patch
    # Even if budget is exceeded, recent memories should not be compressed
    with patch("contexara.store._MEMORY_BUDGET", 0):
        store_module.upsert_memory("Very recent memory", kind="note", importance=1)
        result = store_module.compress_old_memories()
    # Recent memory (just inserted) is < 14 days old — should not be touched
    assert result["archived"] == 0