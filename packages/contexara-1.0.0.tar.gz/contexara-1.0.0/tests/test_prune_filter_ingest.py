"""Tests for features 5 (TTL prune), 6 (date filters), 7 (file ingest)."""
from __future__ import annotations

import importlib
import json
import sqlite3
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

store_module = importlib.import_module("contexara.store")


# ---------------------------------------------------------------------------
# Feature 5 — TTL expiry / prune
# ---------------------------------------------------------------------------

def _insert_with_expires(content: str, kind: str, expires_delta_days: int):
    """Insert a memory with an explicit expires_at offset from now."""
    store_module._initialize_db()
    conn = store_module._get_connection()
    cursor = conn.cursor()
    now = store_module._utc_now_iso()
    expires_at = (
        datetime.now(timezone.utc) + timedelta(days=expires_delta_days)
    ).isoformat()
    cursor.execute(
        """
        INSERT INTO memories (content, kind, importance, created_at, updated_at, expires_at, source)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (content, kind, 1, now, now, expires_at, "raw"),
    )
    conn.commit()
    conn.close()


def test_prune_expired_removes_expired_memory():
    _insert_with_expires("this memory expired yesterday", "note", -1)
    _insert_with_expires("this memory is still valid", "note", 10)

    count = store_module.prune_expired()

    assert count == 1
    remaining = store_module.list_all()
    assert len(remaining) == 1
    assert remaining[0]["content"] == "this memory is still valid"


def test_prune_expired_dry_run_does_not_delete():
    _insert_with_expires("expired but dry run", "note", -1)

    count = store_module.prune_expired(dry_run=True)

    assert count == 1
    assert len(store_module.list_all()) == 1  # still there


def test_prune_expired_archives_to_memories_archive():
    _insert_with_expires("archived expired memory", "note", -1)

    store_module.prune_expired()

    conn = sqlite3.connect(store_module.DB_PATH)
    rows = conn.execute(
        "SELECT content, reason FROM memories_archive WHERE reason = 'ttl_expired'"
    ).fetchall()
    conn.close()
    assert len(rows) == 1
    assert rows[0][0] == "archived expired memory"


def test_prune_expired_no_op_when_nothing_expired():
    _insert_with_expires("valid memory", "note", 30)
    count = store_module.prune_expired()
    assert count == 0
    assert len(store_module.list_all()) == 1


def test_expire_stale_runs_on_upsert():
    """_expire_stale is triggered after each upsert — expired memories are pruned automatically."""
    _insert_with_expires("stale auto sweep", "note", -5)
    # Upsert a new memory — triggers the sweep
    store_module.upsert_memory("trigger sweep", kind="note", importance=1)
    remaining = [m for m in store_module.list_all() if m["content"] == "stale auto sweep"]
    assert remaining == []


# ---------------------------------------------------------------------------
# Feature 6 — Date filters on list and search
# ---------------------------------------------------------------------------

def _insert_at(content: str, kind: str, created_at: str):
    store_module._initialize_db()
    conn = store_module._get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO memories (content, kind, importance, created_at, updated_at, source)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (content, kind, 1, created_at, created_at, "raw"),
    )
    conn.commit()
    conn.close()


def test_list_all_since_filters_old_memories():
    _insert_at("old memory", "note", "2024-01-15T10:00:00")
    _insert_at("new memory", "note", "2026-04-01T10:00:00")

    results = store_module.list_all(since="2026-01-01")
    assert len(results) == 1
    assert results[0]["content"] == "new memory"


def test_list_all_before_filters_new_memories():
    _insert_at("old memory", "note", "2024-01-15T10:00:00")
    _insert_at("new memory", "note", "2026-04-01T10:00:00")

    results = store_module.list_all(before="2025-01-01")
    assert len(results) == 1
    assert results[0]["content"] == "old memory"


def test_list_all_since_and_before_range():
    _insert_at("jan 2024", "note", "2024-01-15T10:00:00")
    _insert_at("jun 2024", "note", "2024-06-15T10:00:00")
    _insert_at("apr 2026", "note", "2026-04-01T10:00:00")

    results = store_module.list_all(since="2024-03-01", before="2025-01-01")
    assert len(results) == 1
    assert results[0]["content"] == "jun 2024"


def test_list_all_no_filters_returns_all():
    _insert_at("memory A", "note", "2024-01-15T10:00:00")
    _insert_at("memory B", "note", "2026-04-01T10:00:00")

    assert len(store_module.list_all()) == 2


# ---------------------------------------------------------------------------
# Feature 7 — File ingest
# ---------------------------------------------------------------------------

def _make_embed_noop(monkeypatch):
    """Patch embed and ingest_turn so tests don't need AWS or BERT."""
    import numpy as np
    from contexara import embedder as emb_mod
    monkeypatch.setattr(emb_mod, "embed", lambda _text: np.zeros(384, dtype="float32"))

    ingest_mod = importlib.import_module("contexara.ingest")
    extract_mod = importlib.import_module("contexara.extract")
    # Force fast-path by making should_extract return True but extract returns fixed memories
    monkeypatch.setattr(extract_mod, "should_extract", lambda _text: True)
    monkeypatch.setattr(
        extract_mod,
        "extract_memories",
        lambda user_text, assistant_text="", existing_memories=None: [
            {"content": user_text[:80].strip(), "kind": "note", "importance": 1, "ttl_days": None}
        ] if user_text.strip() else [],
    )


def test_ingest_txt_file(monkeypatch):
    _make_embed_noop(monkeypatch)
    from contexara.file_ingest import ingest_file

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("I am a software engineer.\n\nI prefer Python over Java.\n\nBuilding Contexara v2.")
        tmp = f.name

    stats = ingest_file(tmp)
    Path(tmp).unlink()

    assert stats["inserted"] + stats["updated"] > 0


def test_ingest_md_file(monkeypatch):
    _make_embed_noop(monkeypatch)
    from contexara.file_ingest import ingest_file

    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, encoding="utf-8") as f:
        f.write("# Notes\n\nUser prefers dark mode.\n\nUser built hybrid search.")
        tmp = f.name

    stats = ingest_file(tmp)
    Path(tmp).unlink()

    assert stats["inserted"] + stats["updated"] > 0


def test_ingest_jsonl_file(monkeypatch):
    _make_embed_noop(monkeypatch)
    from contexara.file_ingest import ingest_file

    lines = [
        json.dumps({"content": "User is Prajwal, an AI Engineer."}),
        json.dumps({"content": "User is building Contexara.", "assistant": "Got it."}),
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8") as f:
        f.write("\n".join(lines))
        tmp = f.name

    stats = ingest_file(tmp)
    Path(tmp).unlink()

    assert stats["inserted"] + stats["updated"] > 0


def test_ingest_file_not_found():
    from contexara.file_ingest import ingest_file
    with pytest.raises(FileNotFoundError):
        ingest_file("/nonexistent/path/file.txt")


def test_ingest_unsupported_extension():
    from contexara.file_ingest import ingest_file
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        tmp = f.name
    with pytest.raises(ValueError, match="Unsupported file type"):
        ingest_file(tmp)
    Path(tmp).unlink()


def test_ingest_jsonl_skips_malformed_lines(monkeypatch):
    _make_embed_noop(monkeypatch)
    from contexara.file_ingest import ingest_file

    lines = [
        "not valid json {{{",
        json.dumps({"content": "Valid memory line."}),
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8") as f:
        f.write("\n".join(lines))
        tmp = f.name

    stats = ingest_file(tmp)
    Path(tmp).unlink()

    assert stats["skipped"] >= 1
