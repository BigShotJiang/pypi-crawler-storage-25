from unittest.mock import patch

from contexara.ingest import ingest_turn
from contexara.store import list_all


def _mock_llm(memories):
    return patch("contexara.extract._call_llm_for_extraction", return_value=memories)


def test_ingest_turn_inserts_memories_from_turn():
    fake = [
        {"content": "User prefers dark UI", "kind": "preference", "importance": 4, "ttl_days": None},
        {"content": "User is building a travel app", "kind": "task", "importance": 3, "ttl_days": None},
    ]
    with _mock_llm(fake):
        stats = ingest_turn(
            user_text="I prefer dark UI and I am building a travel app.",
            assistant_text="Great.",
        )

    memories = list_all()
    assert stats["extracted"] == 2
    assert stats["inserted"] == 2
    assert any(m["kind"] == "preference" for m in memories)
    assert any(m["kind"] == "task" for m in memories)


def test_ingest_turn_dedupes_by_updating_existing_memory():
    fake = [{"content": "User prefers concise responses", "kind": "preference", "importance": 4, "ttl_days": None}]

    with _mock_llm(fake):
        first = ingest_turn(user_text="I prefer concise responses.", assistant_text="Noted.")

    with _mock_llm(fake):
        second = ingest_turn(user_text="I prefer concise responses.", assistant_text="Still noted.")

    memories = [m for m in list_all() if m["kind"] == "preference"]
    assert first["inserted"] == 1
    assert second["updated"] == 1
    assert len(memories) == 1


def test_ingest_turn_captures_past_tense_completion():
    fake = [
        {"content": "User built hybrid search for Contexara v2", "kind": "task", "importance": 3, "ttl_days": None},
    ]
    with _mock_llm(fake):
        stats = ingest_turn(
            user_text="I just built hybrid search, now testing it.",
            assistant_text="Great progress!",
        )

    memories = [m for m in list_all() if m["kind"] == "task"]
    assert stats["inserted"] >= 1
    assert any("hybrid search" in m["content"].lower() for m in memories)
