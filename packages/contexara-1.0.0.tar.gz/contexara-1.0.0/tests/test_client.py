"""Tests for ContexaraClient Python SDK — all four sub-clients."""
from __future__ import annotations

import asyncio
import importlib
from pathlib import Path
from uuid import uuid4

import pytest

session_module = importlib.import_module("contexara.session")
store_module = importlib.import_module("contexara.store")
retrieve_module = importlib.import_module("contexara.retrieve")


@pytest.fixture(autouse=True)
def isolated_dbs(monkeypatch, tmp_path):
    """Isolated memory DB + session DB per test."""
    mem_db = tmp_path / f"mem_{uuid4().hex}.db"
    sess_db = tmp_path / f"sess_{uuid4().hex}.db"

    monkeypatch.setattr(store_module, "DB_PATH", mem_db)
    monkeypatch.setattr(retrieve_module, "DB_PATH", mem_db)
    monkeypatch.setattr(session_module, "DB_PATH", sess_db)

    store_module._initialize_db()
    store_module.clear_all()
    session_module.initialize_session_db()
    yield


def _mock_embedder(monkeypatch):
    """Replace Bedrock embedder with deterministic numpy vectors."""
    import numpy as np
    import hashlib

    def fake_embed(text: str) -> np.ndarray:
        seed = int(hashlib.md5(text.encode()).hexdigest(), 16) % (2**31)
        rng = np.random.default_rng(seed)
        v = rng.random(1536).astype(np.float32)
        v /= np.linalg.norm(v)
        return v

    monkeypatch.setattr(store_module, "embed", fake_embed)
    monkeypatch.setattr(retrieve_module, "embed", fake_embed)


def _mock_llm(monkeypatch, response: str = "mock answer"):
    import io, json
    from unittest.mock import MagicMock, patch
    mock_client = MagicMock()
    mock_client.invoke_model.return_value = {
        "body": io.BytesIO(json.dumps({"content": [{"text": response}]}).encode())
    }
    llm = importlib.import_module("contexara.llm")
    monkeypatch.setattr(llm, "_get_client", lambda: mock_client)


# ---------------------------------------------------------------------------
# ContexaraClient construction
# ---------------------------------------------------------------------------

def test_client_instantiates_with_namespace():
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="test_ns")
    assert client.namespace == "test_ns"
    assert repr(client) == "ContexaraClient(namespace='test_ns')"


def test_client_rejects_empty_namespace():
    from contexara.client import ContexaraClient
    with pytest.raises(ValueError, match="empty"):
        ContexaraClient(namespace="   ")


def test_client_strips_whitespace_from_namespace():
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="  myns  ")
    assert client.namespace == "myns"


def test_client_has_all_sub_clients():
    from contexara.client import ContexaraClient, ChatClient, EpisodesClient, MemoryClient, ArchiveClient
    client = ContexaraClient(namespace="test_ns")
    assert isinstance(client.chat, ChatClient)
    assert isinstance(client.episodes, EpisodesClient)
    assert isinstance(client.memory, MemoryClient)
    assert isinstance(client.archive, ArchiveClient)


# ---------------------------------------------------------------------------
# MemoryClient
# ---------------------------------------------------------------------------

def test_memory_store_and_search(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="mem_ns")

    result = client.memory.store("user prefers dark mode", kind="preference", importance=3)
    assert result in ("inserted", "updated")

    hits = client.memory.search("dark mode preference")
    assert any("dark mode" in h for h in hits)


def test_memory_store_namespace_isolated(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient
    client_a = ContexaraClient(namespace="ns_a")
    client_b = ContexaraClient(namespace="ns_b")

    client_a.memory.store("secret for A only")
    hits_b = client_b.memory.search("secret for A only")
    assert hits_b == []


def test_memory_list_returns_stored(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="list_ns")
    client.memory.store("fact one")
    client.memory.store("fact two")

    memories = client.memory.list()
    assert len(memories) == 2


def test_memory_forget_hard_deletes(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="forget_ns")
    client.memory.store("temp fact")

    memories = client.memory.list()
    mid = memories[0]["id"]

    assert client.memory.forget(mid) is True
    assert client.memory.list() == []


def test_memory_forget_returns_false_for_missing_id(monkeypatch):
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="default")
    assert client.memory.forget(999999) is False


def test_memory_deprecate_soft_deletes(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="dep_ns")
    client.memory.store("outdated fact")

    memories = client.memory.list()
    mid = memories[0]["id"]

    assert client.memory.deprecate(mid) is True
    # Memory still exists in DB (soft delete) — verify via direct store query
    conn = store_module._get_connection()
    row = conn.execute("SELECT compression_level FROM memories WHERE id = ?", (mid,)).fetchone()
    conn.close()
    assert row["compression_level"] == 10


def test_memory_stats_returns_counts(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="stats_ns")
    client.memory.store("pref", kind="preference")
    client.memory.store("task", kind="task")

    stats = client.memory.stats()
    assert stats["total"] == 2
    assert stats["by_kind"]["preference"] == 1
    assert stats["by_kind"]["task"] == 1
    assert stats["namespace"] == "stats_ns"


# ---------------------------------------------------------------------------
# ChatClient
# ---------------------------------------------------------------------------

def test_chat_ingest_and_get_recent_turns(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="chat_ns")

    client.chat.ingest("hello", "hi there")
    turns = client.chat.get_recent_turns(n=5)

    assert len(turns) == 2
    assert turns[0]["role"] == "user"
    assert turns[1]["role"] == "assistant"


def test_chat_get_recent_turns_empty_on_new_session():
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="empty_chat_ns")
    turns = client.chat.get_recent_turns()
    assert turns == []


# ---------------------------------------------------------------------------
# EpisodesClient
# ---------------------------------------------------------------------------

def test_episodes_get_last_returns_none_when_empty():
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="ep_ns")
    assert client.episodes.get_last() is None


def test_episodes_list_returns_empty_list():
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="ep_list_ns")
    assert client.episodes.list() == []


def test_episodes_crystallize_returns_false_when_no_open_session():
    from contexara.client import ContexaraClient
    client = ContexaraClient(namespace="no_session_ns")
    assert client.episodes.crystallize() is False


# ---------------------------------------------------------------------------
# Async methods
# ---------------------------------------------------------------------------

def test_async_memory_store_and_search(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient

    async def _run():
        client = ContexaraClient(namespace="async_ns")
        result = await client.memory.astore("async preference", kind="preference")
        assert result in ("inserted", "updated")
        hits = await client.memory.asearch("async preference")
        assert any("async preference" in h for h in hits)

    asyncio.run(_run())


def test_async_chat_ingest(monkeypatch):
    _mock_embedder(monkeypatch)
    from contexara.client import ContexaraClient

    async def _run():
        client = ContexaraClient(namespace="async_chat_ns")
        await client.chat.aingest("async user", "async assistant")
        turns = client.chat.get_recent_turns()
        assert len(turns) == 2

    asyncio.run(_run())
