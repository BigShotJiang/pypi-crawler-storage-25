"""Tests for session management, namespace isolation, and session lifecycle."""
from __future__ import annotations

import importlib
from pathlib import Path
from uuid import uuid4

import pytest

session_module = importlib.import_module("contexara.session")


@pytest.fixture(autouse=True)
def isolated_session_db(monkeypatch, tmp_path):
    """Each test gets its own session DB — no cross-test contamination."""
    db_path = tmp_path / f"session_{uuid4().hex}.db"
    monkeypatch.setattr(session_module, "DB_PATH", db_path)
    session_module.initialize_session_db()
    yield
    if db_path.exists():
        db_path.unlink()


# ---------------------------------------------------------------------------
# Namespace CRUD
# ---------------------------------------------------------------------------

def test_create_namespace_returns_true_on_first_create():
    assert session_module.create_namespace("my_agent") is True


def test_create_namespace_returns_false_if_already_exists():
    session_module.create_namespace("my_agent")
    assert session_module.create_namespace("my_agent") is False


def test_create_namespace_rejects_empty_name():
    with pytest.raises(ValueError, match="empty"):
        session_module.create_namespace("   ")


def test_create_namespace_rejects_spaces_in_name():
    with pytest.raises(ValueError, match="spaces"):
        session_module.create_namespace("my agent")


def test_list_namespaces_returns_created_namespaces():
    session_module.create_namespace("agent_a")
    session_module.create_namespace("agent_b")
    names = [n["name"] for n in session_module.list_namespaces()]
    assert "agent_a" in names
    assert "agent_b" in names


def test_remove_namespace_rejects_default():
    with pytest.raises(ValueError, match="default"):
        session_module.remove_namespace("default")


def test_remove_namespace_deletes_all_data():
    ns = "to_remove"
    session_module.create_namespace(ns)
    sid = session_module.get_or_create_session(namespace=ns)
    session_module.save_turn(sid, "user", "hello", namespace=ns)

    counts = session_module.remove_namespace(ns)

    assert counts["namespaces"] == 1
    assert counts["raw_turns"] >= 1
    assert counts["active_sessions"] >= 1

    remaining = [n["name"] for n in session_module.list_namespaces()]
    assert ns not in remaining


def test_remove_namespace_does_not_affect_other_namespaces():
    session_module.create_namespace("keep_me")
    session_module.create_namespace("delete_me")
    sid = session_module.get_or_create_session(namespace="keep_me")
    session_module.save_turn(sid, "user", "kept turn", namespace="keep_me")

    session_module.remove_namespace("delete_me")

    turns = session_module.get_recent_turns(sid)
    assert any(t["content"] == "kept turn" for t in turns)


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------

def test_get_or_create_session_returns_string_id():
    sid = session_module.get_or_create_session(namespace="default")
    assert isinstance(sid, str)
    assert len(sid) == 36  # UUID format


def test_get_or_create_session_reuses_open_session():
    sid1 = session_module.get_or_create_session(namespace="default")
    sid2 = session_module.get_or_create_session(namespace="default")
    assert sid1 == sid2


def test_get_or_create_session_isolated_per_namespace():
    sid_a = session_module.get_or_create_session(namespace="ns_a")
    sid_b = session_module.get_or_create_session(namespace="ns_b")
    assert sid_a != sid_b


# ---------------------------------------------------------------------------
# Raw turn storage
# ---------------------------------------------------------------------------

def test_save_turn_stores_user_and_assistant():
    sid = session_module.get_or_create_session(namespace="default")
    session_module.save_turn(sid, "user", "what is 2+2?", namespace="default")
    session_module.save_turn(sid, "assistant", "It's 4.", namespace="default")

    turns = session_module.get_recent_turns(sid)
    assert len(turns) == 2
    assert turns[0]["role"] == "user"
    assert turns[1]["role"] == "assistant"


def test_save_turn_ignores_empty_content():
    sid = session_module.get_or_create_session(namespace="default")
    session_module.save_turn(sid, "user", "   ", namespace="default")
    assert session_module.get_recent_turns(sid) == []


def test_save_turn_ignores_llm_error_prefixes():
    sid = session_module.get_or_create_session(namespace="default")
    session_module.save_turn(sid, "assistant", "[LLM ERROR] timeout", namespace="default")
    assert session_module.get_recent_turns(sid) == []


def test_get_recent_turns_respects_n_limit():
    sid = session_module.get_or_create_session(namespace="default")
    for i in range(10):
        session_module.save_turn(sid, "user", f"turn {i}", namespace="default")

    turns = session_module.get_recent_turns(sid, n=3)
    assert len(turns) == 3


def test_turns_are_namespace_isolated():
    sid_a = session_module.get_or_create_session(namespace="alpha")
    sid_b = session_module.get_or_create_session(namespace="beta")
    session_module.save_turn(sid_a, "user", "alpha turn", namespace="alpha")
    session_module.save_turn(sid_b, "user", "beta turn", namespace="beta")

    turns_a = session_module.get_recent_turns(sid_a)
    turns_b = session_module.get_recent_turns(sid_b)

    assert all(t["content"] == "alpha turn" for t in turns_a)
    assert all(t["content"] == "beta turn" for t in turns_b)


# ---------------------------------------------------------------------------
# Episode retrieval
# ---------------------------------------------------------------------------

def test_get_last_episode_returns_none_when_no_episodes():
    result = session_module.get_last_episode(namespace="default")
    assert result is None


def test_get_last_episode_returns_latest_summary():
    conn = session_module._get_connection()
    conn.execute(
        "INSERT INTO episodes (session_id, summary, started_at, ended_at, created_at, namespace) VALUES (?, ?, ?, ?, ?, ?)",
        ("sess-1", "First session summary", "2025-01-01T00:00:00+00:00", "2025-01-01T01:00:00+00:00", "2025-01-01T01:00:00+00:00", "default"),
    )
    conn.execute(
        "INSERT INTO episodes (session_id, summary, started_at, ended_at, created_at, namespace) VALUES (?, ?, ?, ?, ?, ?)",
        ("sess-2", "Latest session summary", "2025-01-02T00:00:00+00:00", "2025-01-02T01:00:00+00:00", "2025-01-02T01:00:00+00:00", "default"),
    )
    conn.commit()
    conn.close()

    result = session_module.get_last_episode(namespace="default")
    assert result == "Latest session summary"


def test_get_last_episode_isolated_by_namespace():
    conn = session_module._get_connection()
    conn.execute(
        "INSERT INTO episodes (session_id, summary, started_at, ended_at, created_at, namespace) VALUES (?, ?, ?, ?, ?, ?)",
        ("sess-x", "NS-X summary", "2025-01-01T00:00:00+00:00", "2025-01-01T01:00:00+00:00", "2025-01-01T01:00:00+00:00", "ns_x"),
    )
    conn.commit()
    conn.close()

    assert session_module.get_last_episode(namespace="ns_y") is None
    assert session_module.get_last_episode(namespace="ns_x") == "NS-X summary"
