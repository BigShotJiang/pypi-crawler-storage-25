import argparse
import importlib

cli_module = importlib.import_module("contexara.cli")


def test_join_parts_combines_tokens():
    assert cli_module._join_parts(["hello", "world"]) == "hello world"


def test_main_without_command_shows_help_and_exits_zero(monkeypatch, capsys):
    monkeypatch.setattr(cli_module, "_build_parser", lambda: argparse.ArgumentParser(prog="contexara"))
    monkeypatch.setattr(cli_module.argparse.ArgumentParser, "parse_args", lambda _self: argparse.Namespace(command=None))

    exit_code = cli_module.main()
    output = capsys.readouterr().out

    assert exit_code == 0
    assert "usage:" in output.lower()


def test_cmd_ask_calls_ask_and_prints(monkeypatch, capsys):
    monkeypatch.setattr(cli_module, "ask", lambda _query, **kw: "answer")
    args = argparse.Namespace(query=["what", "is", "this"], namespace="default")

    exit_code = cli_module._cmd_ask(args)
    output = capsys.readouterr().out

    assert exit_code == 0
    assert "answer" in output
