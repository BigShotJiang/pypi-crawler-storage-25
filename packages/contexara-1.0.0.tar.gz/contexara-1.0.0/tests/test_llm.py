import io
import importlib
import json

import pytest

llm_module = importlib.import_module("contexara.llm")


def test_bedrock_config_supports_aws_access_key_alias(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("AWS_ACCESS_KEY_ID", raising=False)
    monkeypatch.setenv("AWS_ACCESS_KEY", "alias-key")

    config = llm_module.BedrockConfig.from_env()

    assert config.region
    assert config.model_id
    assert llm_module.os.getenv("AWS_ACCESS_KEY_ID") == "alias-key"


def test_build_request_body_formats_prompt_and_parameters():
    config = llm_module.BedrockConfig(
        region="us-east-1",
        model_id="model-id",
        max_tokens=321,
        temperature=0.25,
    )

    body = llm_module._build_request_body("  hello  ", config)

    assert body["anthropic_version"] == "bedrock-2023-05-31"
    assert body["max_tokens"] == 321
    assert body["temperature"] == 0.25
    assert body["messages"][0]["content"][0]["text"] == "hello"


def test_extract_text_returns_clean_string():
    result = {"content": [{"text": " response text "}]}
    assert llm_module._extract_text(result) == "response text"


def test_extract_text_raises_on_malformed_payload():
    with pytest.raises(ValueError, match="missing content list"):
        llm_module._extract_text({})


def test_call_llm_success(monkeypatch: pytest.MonkeyPatch):
    class FakeClient:
        def invoke_model(self, **_kwargs):
            payload = {"content": [{"text": " done "}]}
            return {"body": io.BytesIO(json.dumps(payload).encode("utf-8"))}

    cfg = llm_module.BedrockConfig(
        region="us-east-1",
        model_id="model",
        max_tokens=50,
        temperature=0.2,
    )
    monkeypatch.setattr(llm_module.BedrockConfig, "from_env", staticmethod(lambda: cfg))
    monkeypatch.setattr(llm_module, "_get_client", lambda _region: FakeClient())

    result = llm_module.call_llm("Hello")
    assert result == "done"


def test_call_llm_returns_error_string_on_exception(monkeypatch: pytest.MonkeyPatch):
    class FailingClient:
        def invoke_model(self, **_kwargs):
            raise RuntimeError("bedrock down")

    cfg = llm_module.BedrockConfig(
        region="us-east-1",
        model_id="model",
        max_tokens=50,
        temperature=0.2,
    )
    monkeypatch.setattr(llm_module.BedrockConfig, "from_env", staticmethod(lambda: cfg))
    monkeypatch.setattr(llm_module, "_get_client", lambda _region: FailingClient())

    result = llm_module.call_llm("Hello")
    assert result.startswith("[LLM ERROR]")
    assert "bedrock down" in result


def test_call_llm_rejects_empty_prompt():
    assert llm_module.call_llm("   ") == "[LLM ERROR] Prompt cannot be empty."
