"""
Contexara Python SDK — ContexaraClient

Usage:
    from contexara import ContexaraClient

    client = ContexaraClient(namespace="coding_agent")

    # Chat (Tier 1)
    response = client.chat.ask("what am I building?")
    client.chat.ingest("user message", "assistant reply")

    # Episodes (Tier 2)
    episodes = client.episodes.search("what did I work on today?")
    client.episodes.crystallize()  # force crystallize current session

    # Memory (Tier 3)
    client.memory.store("prefers Python", kind="preference")
    results = client.memory.search("python preferences")
    client.memory.forget(memory_id=42)
    client.memory.deprecate(memory_id=41)

    # Archive (cold FTS5 search)
    hits = client.archive.search("session detection bug")

Async equivalents available for all write operations:
    await client.memory.astore("prefers Python")
    await client.chat.aingest("user", "assistant")
"""
from __future__ import annotations

import asyncio
from typing import Any


class ChatClient:
    """Tier 1 — raw turn ingestion and context-aware Q&A."""

    def __init__(self, namespace: str) -> None:
        self._ns = namespace

    def ask(self, query: str) -> str:
        """Ask a memory-aware question. Returns assistant response."""
        from .main import ask_plain
        return ask_plain(query, namespace=self._ns)

    async def aask(self, query: str) -> str:
        """Async version of ask()."""
        return await asyncio.get_running_loop().run_in_executor(None, self.ask, query)

    def ingest(self, user_text: str, assistant_text: str) -> dict[str, int]:
        """Ingest a conversation turn into Tier 1 and Tier 3."""
        from .ingest import ingest_turn
        from .session import get_or_create_session
        session_id = get_or_create_session(namespace=self._ns)
        return ingest_turn(user_text, assistant_text, session_id=session_id, namespace=self._ns)

    async def aingest(self, user_text: str, assistant_text: str) -> dict[str, int]:
        """Async version of ingest()."""
        return await asyncio.get_running_loop().run_in_executor(
            None, self.ingest, user_text, assistant_text
        )

    def get_recent_turns(self, n: int = 20) -> list[dict]:
        """Return the last N turns from the current session."""
        from .session import get_or_create_session, get_recent_turns
        session_id = get_or_create_session(namespace=self._ns)
        return get_recent_turns(session_id, n=n)


class EpisodesClient:
    """Tier 2 — episodic memory, temporal retrieval, crystallization."""

    def __init__(self, namespace: str) -> None:
        self._ns = namespace

    def search(self, query: str, top_k: int = 3) -> list[str]:
        """
        Temporal episode search. Query must contain a time expression
        (e.g. 'today', 'yesterday', 'last week').
        Returns formatted episode summaries.
        """
        from .retrieve import retrieve_episodes
        return retrieve_episodes(query, top_k=top_k, namespace=self._ns)

    async def asearch(self, query: str, top_k: int = 3) -> list[str]:
        """Async version of search()."""
        return await asyncio.get_running_loop().run_in_executor(
            None, lambda: self.search(query, top_k)
        )

    def get_last(self) -> str | None:
        """Return the most recent crystallized episode summary, or None."""
        from .session import get_last_episode
        return get_last_episode(namespace=self._ns)

    def list(self, limit: int = 10) -> list[dict]:
        """Return the most recent N episodes as raw dicts."""
        from .session import _get_connection, initialize_session_db
        initialize_session_db()
        conn = _get_connection()
        try:
            rows = conn.execute(
                "SELECT id, session_id, summary, started_at, ended_at, created_at FROM episodes WHERE namespace = ? ORDER BY created_at DESC LIMIT ?",
                (self._ns, limit),
            ).fetchall()
        finally:
            conn.close()
        return [dict(r) for r in rows]

    def crystallize(self) -> bool:
        """
        Force crystallize the current open session immediately (synchronous).
        Returns True if a session was found and crystallized.
        """
        from .session import _get_connection, initialize_session_db
        from ._crystallize import _crystallize
        initialize_session_db()
        conn = _get_connection()
        try:
            row = conn.execute(
                "SELECT session_id FROM active_sessions WHERE status = 'open' AND namespace = ? ORDER BY last_action_at DESC LIMIT 1",
                (self._ns,),
            ).fetchone()
        finally:
            conn.close()
        if not row:
            return False
        _crystallize(row["session_id"])
        return True

    async def acrystallize(self) -> bool:
        """Async version of crystallize()."""
        return await asyncio.get_running_loop().run_in_executor(None, self.crystallize)


class MemoryClient:
    """Tier 3 — semantic memory CRUD."""

    def __init__(self, namespace: str) -> None:
        self._ns = namespace

    def store(
        self,
        content: str,
        kind: str = "note",
        importance: int = 1,
        ttl_days: int | None = None,
    ) -> str:
        """
        Store a semantic memory. Returns 'inserted' or 'updated'.

        Args:
            kind: One of 'note', 'task', 'preference', 'profile', 'constraint'
            importance: 1–5
            ttl_days: Optional expiry in days
        """
        from .store import upsert_memory
        return upsert_memory(
            content=content,
            kind=kind,
            importance=importance,
            ttl_days=ttl_days,
            namespace=self._ns,
        )

    async def astore(
        self,
        content: str,
        kind: str = "note",
        importance: int = 1,
        ttl_days: int | None = None,
    ) -> str:
        """Async version of store()."""
        return await asyncio.get_running_loop().run_in_executor(
            None, lambda: self.store(content, kind, importance, ttl_days)
        )

    def search(self, query: str, top_k: int = 5) -> list[str]:
        """Semantic search over memories. Returns ranked content strings."""
        from .retrieve import retrieve
        return retrieve(query, top_k=top_k, namespace=self._ns)

    async def asearch(self, query: str, top_k: int = 5) -> list[str]:
        """Async version of search()."""
        return await asyncio.get_running_loop().run_in_executor(
            None, lambda: self.search(query, top_k)
        )

    def list(
        self,
        since: str | None = None,
        before: str | None = None,
    ) -> list[dict]:
        """List all memories, optionally filtered by date."""
        from .store import list_all
        return list_all(since=since, before=before, namespace=self._ns)

    def forget(self, memory_id: int) -> bool:
        """Hard delete a memory by ID. Returns True if deleted."""
        from .store import _get_connection, _initialize_db
        _initialize_db()
        conn = _get_connection()
        cursor = conn.execute(
            "DELETE FROM memories WHERE id = ? AND namespace = ?",
            (memory_id, self._ns),
        )
        deleted = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return deleted

    async def aforget(self, memory_id: int) -> bool:
        """Async version of forget()."""
        return await asyncio.get_running_loop().run_in_executor(None, self.forget, memory_id)

    def deprecate(self, memory_id: int) -> bool:
        """
        Soft delete — memory is retained but heavily penalized in retrieval
        (compression_level set to 10, effectively never surfaces).
        Returns True if found and deprecated.
        """
        from .store import _get_connection, _initialize_db
        _initialize_db()
        conn = _get_connection()
        cursor = conn.execute(
            "UPDATE memories SET compression_level = 10 WHERE id = ? AND namespace = ?",
            (memory_id, self._ns),
        )
        updated = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return updated

    async def adeprecate(self, memory_id: int) -> bool:
        """Async version of deprecate()."""
        return await asyncio.get_running_loop().run_in_executor(None, self.deprecate, memory_id)

    def stats(self) -> dict:
        """Return memory statistics for this namespace."""
        from .store import _get_connection, _initialize_db
        _initialize_db()
        conn = _get_connection()
        rows = conn.execute(
            "SELECT kind, source, importance, created_at FROM memories WHERE namespace = ?",
            (self._ns,),
        ).fetchall()
        conn.close()

        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        total = len(rows)
        by_kind: dict[str, int] = {}
        by_source: dict[str, int] = {}
        for r in rows:
            by_kind[r["kind"]] = by_kind.get(r["kind"], 0) + 1
            by_source[r["source"]] = by_source.get(r["source"], 0) + 1

        return {"total": total, "by_kind": by_kind, "by_source": by_source, "namespace": self._ns}


class ArchiveClient:
    """Tier 4 — cold archive FTS5 full-text search."""

    def __init__(self, namespace: str) -> None:
        self._ns = namespace

    def search(self, query: str, limit: int = 10) -> list[dict]:
        """
        Full-text search across cold_archive.db using FTS5.
        Returns matching historical turns with metadata.
        """
        from .archive import search_cold_archive
        return search_cold_archive(query, limit=limit, namespace=self._ns)

    async def asearch(self, query: str, limit: int = 10) -> list[dict]:
        """Async version of search()."""
        return await asyncio.get_running_loop().run_in_executor(
            None, lambda: self.search(query, limit)
        )


class ContexaraClient:
    """
    Namespaced Python SDK client for Contexara.

    Example:
        client = ContexaraClient(namespace="coding_agent")
        response = client.chat.ask("what am I building?")
        client.memory.store("prefers Python", kind="preference")
        episodes = client.episodes.search("what did I work on today?")
        hits = client.archive.search("session detection")
    """

    def __init__(self, namespace: str = "default") -> None:
        if not namespace or not namespace.strip():
            raise ValueError("Namespace cannot be empty.")
        self.namespace = namespace.strip()
        self.chat = ChatClient(self.namespace)
        self.episodes = EpisodesClient(self.namespace)
        self.memory = MemoryClient(self.namespace)
        self.archive = ArchiveClient(self.namespace)

    def __repr__(self) -> str:
        return f"ContexaraClient(namespace={self.namespace!r})"
