from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from contexara.embedder import cosine_similarity, deserialize, embed

DB_PATH = Path("database/memory.db")

# RRF constant — 60 is the standard value from the original paper.
_RRF_K = 60

STOPWORDS = {
    "a", "am", "an", "and", "are", "as", "at", "be", "by", "for", "from",
    "how", "i", "in", "is", "it", "me", "my", "of", "on", "or", "that",
    "the", "this", "to", "was", "what", "when", "where", "which", "who",
    "why", "you", "your", "now", "currently",
}

CALENDAR_HINTS = {
    "date", "day", "time", "today", "tomorrow", "yesterday",
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
    "january", "february", "march", "april", "may", "june", "july", "august",
    "september", "october", "november", "december",
}


def _get_connection():
    return sqlite3.connect(DB_PATH)


def _normalize(text: str) -> str:
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    return " ".join(tokens)


def _tokenize(text: str) -> set[str]:
    normalized = _normalize(text)
    return {t for t in normalized.split() if t and t not in STOPWORDS}


def _keyword_score(query: str, content: str) -> int:
    query_tokens = _tokenize(query)
    content_tokens = _tokenize(content)

    score = len(query_tokens & content_tokens)

    normalized_query = _normalize(query)
    normalized_content = _normalize(content)

    if normalized_query and normalized_query in normalized_content:
        score += 3

    if "name" in query_tokens and ("name" in content_tokens or "call me" in normalized_content):
        score += 3

    if "work" in query_tokens and ("working" in normalized_content or "building" in normalized_content):
        score += 1

    if query_tokens & {"date", "day", "time"} and content_tokens & CALENDAR_HINTS:
        score += 3

    return score


def _rrf_score(rank_semantic: int, rank_keyword: int) -> float:
    return 1.0 / (_RRF_K + rank_semantic) + 1.0 / (_RRF_K + rank_keyword)


def _format_episode(ep: dict) -> str:
    """Convert a raw episode dict (with JSON summary) into readable text for LLM context."""
    import json as _json
    try:
        data = _json.loads(ep["summary"])
        lines = [f"Session ({ep.get('started_at', '')[:10]}): {data.get('title', '')}"]
        if data.get("actions"):
            lines.append("Actions: " + "; ".join(data["actions"]))
        if data.get("outcomes"):
            lines.append("Outcomes: " + "; ".join(data["outcomes"]))
        if data.get("open_items"):
            lines.append("Open items: " + "; ".join(data["open_items"]))
        return " | ".join(lines)
    except Exception:
        return ep.get("summary", "")


def retrieve_episodes(query: str, top_k: int = 3, namespace: str = "default") -> list[str]:
    """
    Temporal episode retrieval — Phase 5.
    1. Detect time intent in query.
    2. SQL filter episodes by time window (O(1) metadata scan).
    3. Optional cosine re-rank if query has semantic content beyond the time expression.
    Returns list of episode summary strings.
    """
    from .temporal import detect_temporal_intent
    from .session import retrieve_episodes_by_time
    from .embedder import cosine_similarity, deserialize, embed

    window = detect_temporal_intent(query)
    if not window:
        return []

    episodes = retrieve_episodes_by_time(window.start, window.end, namespace=namespace)
    if not episodes:
        return []

    if len(episodes) == 1:
        return [_format_episode(episodes[0])]

    try:
        query_vec = embed(query)
        scored = []
        for ep in episodes:
            if ep["embedding"]:
                vec = deserialize(ep["embedding"])
                sim = cosine_similarity(query_vec, vec)
            else:
                sim = 0.0
            scored.append((sim, ep))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [_format_episode(ep) for _, ep in scored[:top_k]]
    except Exception:
        return [_format_episode(ep) for ep in episodes[:top_k]]


def retrieve(query: str, top_k: int = 5, namespace: str = "default") -> list[str]:
    if not query or not query.strip():
        return []

    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT content, embedding, source, compression_level, kind, created_at FROM memories WHERE namespace = ? ORDER BY created_at DESC",
            (namespace,),
        )
        rows = cursor.fetchall()
        conn.close()
    except sqlite3.OperationalError:
        return []

    if not rows:
        return []

    query_vector = embed(query)
    now = datetime.now(timezone.utc)

    # --- Semantic ranking ---
    semantic_scored: list[tuple[float, str]] = []
    for content, blob, _, _, _, _ in rows:
        if blob is not None:
            vec = deserialize(blob)
            sim = cosine_similarity(query_vector, vec)
        else:
            sim = 0.0
        semantic_scored.append((sim, content))
    semantic_scored.sort(key=lambda x: x[0], reverse=True)

    # --- Keyword ranking ---
    keyword_scored: list[tuple[int, str]] = []
    for content, _, _, _, _, _ in rows:
        score = _keyword_score(query, content)
        keyword_scored.append((score, content))
    keyword_scored.sort(key=lambda x: x[0], reverse=True)

    # Build rank lookup (1-based)
    semantic_rank = {content: i + 1 for i, (_, content) in enumerate(semantic_scored)}
    keyword_rank = {content: i + 1 for i, (_, content) in enumerate(keyword_scored)}

    source_map = {content: source for content, _, source, _, _, _ in rows}
    level_map = {content: (level or 0) for content, _, _, level, _, _ in rows}
    kind_map = {content: kind for content, _, _, _, kind, _ in rows}

    # Temporal: kinds that decay fast vs kinds that are stable
    _DECAY_WEIGHT = {"task": 0.30, "constraint": 0.20, "note": 0.15, "preference": 0.05, "profile": 0.0}

    def _recency_score(created_at_str: str, kind: str) -> float:
        try:
            created = datetime.fromisoformat(created_at_str)
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            days_old = max(0, (now - created).days)
            decay = _DECAY_WEIGHT.get(kind, 0.10)
            if decay == 0.0:
                return 1.0
            return max(0.0, 1.0 - days_old / 365) * decay
        except Exception:
            return 0.0

    created_map = {content: created_at for content, _, _, _, _, created_at in rows}

    # --- RRF fusion with temporal weighting ---
    all_contents = {content for content, _, _, _, _, _ in rows}
    fused: list[tuple[float, str]] = []
    for content in all_contents:
        r_sem = semantic_rank.get(content, len(rows) + 1)
        r_kw = keyword_rank.get(content, len(rows) + 1)
        rrf = _rrf_score(r_sem, r_kw)

        # compression level penalty (5% per level)
        level = level_map.get(content, 0)
        if level > 0:
            rrf *= (0.95 ** level)

        # temporal boost — recent memories score higher for time-sensitive kinds
        recency = _recency_score(created_map.get(content, ""), kind_map.get(content, "note"))
        score = rrf + recency

        fused.append((score, content))

    fused.sort(key=lambda x: x[0], reverse=True)

    # #1: margin-based raw preference — raw wins only when scores are within epsilon
    _RAW_PREFERENCE_EPSILON = 0.03
    preferred: list[tuple[float, str]] = []
    for score, content in fused:
        if source_map.get(content) != "raw":
            # check if any raw result scores within epsilon of this compressed one
            raw_scores = [s for s, c in fused if source_map.get(c) == "raw"]
            if raw_scores and (raw_scores[0] - score) <= _RAW_PREFERENCE_EPSILON:
                continue  # skip this compressed entry; a raw alternative is close enough
        preferred.append((score, content))

    # #2: cap compressed results at 40% of top_k
    max_compressed = max(1, round(top_k * 0.4))
    result: list[str] = []
    compressed_count = 0
    for score, content in preferred:
        if len(result) >= top_k:
            break
        if source_map.get(content) == "compressed":
            if compressed_count >= max_compressed:
                continue
            compressed_count += 1
        result.append(content)

    return result
