"""Temporal intent detection and natural language date parsing."""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import NamedTuple


class TimeWindow(NamedTuple):
    start: datetime
    end: datetime
    label: str  # e.g. "yesterday", "last week"


# Patterns ordered most-specific first
_PATTERNS: list[tuple[str, str]] = [
    # Relative day offsets
    (r"\btoday\b", "today"),
    (r"\byesterday\b", "yesterday"),
    (r"\b(\d+)\s+days?\s+ago\b", "n_days_ago"),
    # Last N hours
    (r"\blast\s+(\d+)\s+hours?\b", "last_n_hours"),
    (r"\bpast\s+(\d+)\s+hours?\b", "last_n_hours"),
    # Last N days
    (r"\blast\s+(\d+)\s+days?\b", "last_n_days"),
    (r"\bpast\s+(\d+)\s+days?\b", "last_n_days"),
    # Named periods
    (r"\blast\s+week\b", "last_week"),
    (r"\bthis\s+week\b", "this_week"),
    (r"\blast\s+month\b", "last_month"),
    (r"\bthis\s+month\b", "this_month"),
    # Named weekdays
    (r"\blast\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", "last_weekday"),
    (r"\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", "this_weekday"),
    # Explicit date YYYY-MM-DD
    (r"\b(\d{4}-\d{2}-\d{2})\b", "iso_date"),
    # "a few hours ago", "few hours ago"
    (r"\ba?\s*few\s+hours?\s+ago\b", "few_hours_ago"),
    # "recently", "just now", "earlier"
    (r"\b(recently|just\s+now|earlier\s+today|earlier)\b", "recently"),
]

_WEEKDAY_MAP = {
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
    "friday": 4, "saturday": 5, "sunday": 6,
}


def detect_temporal_intent(query: str) -> TimeWindow | None:
    """
    Parse natural language time expressions from a query.
    Returns a TimeWindow if a temporal pattern is found, else None.
    """
    text = query.lower()
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    for pattern, kind in _PATTERNS:
        m = re.search(pattern, text)
        if not m:
            continue

        if kind == "today":
            return TimeWindow(today_start, now, "today")

        if kind == "yesterday":
            start = today_start - timedelta(days=1)
            end = today_start
            return TimeWindow(start, end, "yesterday")

        if kind == "n_days_ago":
            n = int(m.group(1))
            start = today_start - timedelta(days=n)
            end = start + timedelta(days=1)
            return TimeWindow(start, end, f"{n} days ago")

        if kind == "last_n_hours":
            n = int(m.group(1))
            start = now - timedelta(hours=n)
            return TimeWindow(start, now, f"last {n} hours")

        if kind == "last_n_days":
            n = int(m.group(1))
            start = today_start - timedelta(days=n)
            return TimeWindow(start, now, f"last {n} days")

        if kind == "last_week":
            # Previous Mon–Sun
            days_since_monday = now.weekday()
            last_mon = today_start - timedelta(days=days_since_monday + 7)
            last_sun = last_mon + timedelta(days=7)
            return TimeWindow(last_mon, last_sun, "last week")

        if kind == "this_week":
            days_since_monday = now.weekday()
            this_mon = today_start - timedelta(days=days_since_monday)
            return TimeWindow(this_mon, now, "this week")

        if kind == "last_month":
            first_of_this_month = today_start.replace(day=1)
            last_month_end = first_of_this_month
            last_month_start = (first_of_this_month - timedelta(days=1)).replace(day=1)
            return TimeWindow(last_month_start, last_month_end, "last month")

        if kind == "this_month":
            start = today_start.replace(day=1)
            return TimeWindow(start, now, "this month")

        if kind == "last_weekday":
            target_wd = _WEEKDAY_MAP[m.group(1)]
            days_back = (now.weekday() - target_wd) % 7 or 7
            start = today_start - timedelta(days=days_back)
            end = start + timedelta(days=1)
            return TimeWindow(start, end, f"last {m.group(1)}")

        if kind == "this_weekday":
            target_wd = _WEEKDAY_MAP[m.group(1)]
            days_back = (now.weekday() - target_wd) % 7
            start = today_start - timedelta(days=days_back)
            end = start + timedelta(days=1)
            return TimeWindow(start, end, m.group(1))

        if kind == "iso_date":
            start = datetime.fromisoformat(m.group(1)).replace(tzinfo=timezone.utc)
            end = start + timedelta(days=1)
            return TimeWindow(start, end, m.group(1))

        if kind == "few_hours_ago":
            start = now - timedelta(hours=3)
            return TimeWindow(start, now, "a few hours ago")

        if kind == "recently":
            start = now - timedelta(hours=6)
            return TimeWindow(start, now, "recently")

    return None
