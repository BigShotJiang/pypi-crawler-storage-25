"""
Detached background worker — crystallizes a session into an episode.
Invoked as: python -m contexara._crystallize <session_id>
"""
from __future__ import annotations

import json
import sys


def _crystallize(session_id: str) -> None:
    from .session import (
        _get_connection,
        _utc_now,
        get_recent_turns,
        get_session_time_range,
        initialize_session_db,
    )
    from .llm import call_llm
    from .embedder import embed, serialize

    initialize_session_db()

    # Pull all raw turns for this session
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT role, content, created_at FROM raw_turns WHERE session_id = ? ORDER BY created_at ASC",
        (session_id,),
    )
    turns = cursor.fetchall()
    conn.close()

    if not turns:
        _mark_crystallized(session_id)
        return

    # Build transcript
    transcript = "\n".join(
        f"{row['role'].upper()} [{row['created_at']}]: {row['content']}"
        for row in turns
    )

    # LLM summarization prompt
    prompt = f"""You are a technical memory crystallization engine.

Summarize the session below into a concise technical manifest.

Output a JSON object with these fields:
- "title": one short sentence describing the main task (max 10 words)
- "actions": list of concrete things done (max 5 bullet points)
- "outcomes": list of results achieved or decisions made (max 3 bullet points)
- "open_items": list of unresolved tasks or next steps (max 3 bullet points)

Rules:
- Be factual and technical. No narrative storytelling.
- Focus on WHAT was done and WHAT was decided, not HOW you felt.
- If nothing significant happened, return minimal output.
- Output ONLY valid JSON, no markdown, no explanation.

Session transcript:
{transcript}"""

    summary_raw = call_llm(prompt)

    # Strip markdown code fences if LLM wraps output
    cleaned = summary_raw.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1]
        cleaned = cleaned.rsplit("```", 1)[0].strip()

    # Validate JSON — fall back to plain text if LLM misbehaves
    try:
        parsed = json.loads(cleaned)
        summary = json.dumps(parsed)
    except (json.JSONDecodeError, TypeError):
        summary = json.dumps({"title": "Session summary", "actions": [cleaned], "outcomes": [], "open_items": []})

    # Embed the summary
    embed_text = summary_raw if len(summary_raw) < 2000 else summary_raw[:2000]
    try:
        vector = embed(embed_text)
        blob = serialize(vector)
    except Exception:
        blob = None

    # Get session time range
    time_range = get_session_time_range(session_id)
    started_at = time_range[0] if time_range else _utc_now()
    ended_at = time_range[1] if time_range else _utc_now()

    # Store episode
    conn = _get_connection()
    conn.execute(
        """
        INSERT INTO episodes (session_id, summary, started_at, ended_at, embedding, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (session_id, summary, started_at, ended_at, blob, _utc_now()),
    )
    conn.commit()
    conn.close()

    _mark_crystallized(session_id)
    _run_sweep_if_due()


def _run_sweep_if_due() -> None:
    """Run cold archive sweep if 7 days have passed since last sweep."""
    try:
        from .archive import run_sweep
        run_sweep()
    except Exception:
        pass


def _mark_crystallized(session_id: str) -> None:
    from .session import _get_connection, _utc_now
    conn = _get_connection()
    conn.execute(
        "UPDATE active_sessions SET status = 'crystallized', last_action_at = ? WHERE session_id = ?",
        (_utc_now(), session_id),
    )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(1)
    _crystallize(sys.argv[1])
