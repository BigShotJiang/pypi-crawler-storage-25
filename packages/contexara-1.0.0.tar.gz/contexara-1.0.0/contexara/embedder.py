from __future__ import annotations

import io
import json
import os

import numpy as np

_EMBED_MODEL_ID = "amazon.titan-embed-text-v2:0"
_EMBED_DIM = 1024


def embed(text: str) -> np.ndarray:
    """Return a normalized float32 embedding vector via Bedrock Titan V2."""
    import boto3
    from dotenv import load_dotenv
    load_dotenv()

    # same credential chain as llm.py
    if os.getenv("AWS_ACCESS_KEY") and not os.getenv("AWS_ACCESS_KEY_ID"):
        os.environ["AWS_ACCESS_KEY_ID"] = os.environ["AWS_ACCESS_KEY"]

    region = os.getenv("AWS_REGION", "us-east-1")
    client = boto3.client("bedrock-runtime", region_name=region)

    payload = json.dumps({"inputText": text.strip(), "dimensions": _EMBED_DIM, "normalize": True})
    response = client.invoke_model(
        modelId=_EMBED_MODEL_ID,
        body=payload,
        contentType="application/json",
        accept="application/json",
    )
    result = json.loads(response["body"].read())
    vector = np.array(result["embedding"], dtype="float32")
    return vector


def serialize(vector: np.ndarray) -> bytes:
    buf = io.BytesIO()
    np.save(buf, vector)
    return buf.getvalue()


def deserialize(blob: bytes) -> np.ndarray:
    buf = io.BytesIO(blob)
    return np.load(buf)


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity for pre-normalized vectors (dot product suffices)."""
    return float(np.dot(a, b))
