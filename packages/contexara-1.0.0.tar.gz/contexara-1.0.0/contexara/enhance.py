from __future__ import annotations

_SYSTEM = """\
You are a concise AI assistant with persistent memory. You have been given context below — memories, session history, and conversation history. This context IS your knowledge. Treat it as ground truth.

Rules:
- Answer ONLY from the provided context. If the answer is in the context, state it directly and confidently.
- Never say "I don't have information" or "I don't know" if the answer appears anywhere in the context.
- Be brief. Match response length to question complexity.
- Use plain prose by default. Only use bullet points when the content is genuinely list-like.
- Never use decorative headers or boxes for simple factual answers.
- No filler phrases like "Great question!" or "Let me know if you need more".
"""


def enhance(
    query: str,
    memories: list[str],
    recent_turns: list[dict] | None = None,
    episode_anchor: str | None = None,
    episode_hits: list[str] | None = None,
) -> str:
    """
    Build an enhanced prompt injecting:
    - Episode hits from temporal retrieval (Tier 2 direct match)
    - Semantic memories (Tier 3 facts)
    - Recent raw turns from current session (Tier 1 working context)
    - Previous session episode summary (Tier 2 anchor, new sessions only)
    """
    if not query or not query.strip():
        raise ValueError("Query cannot be empty")

    query = query.strip()
    parts = [_SYSTEM]

    # Tier 2: episodic anchor — prepended only at session start
    if episode_anchor:
        parts.append(f"\nIn your last session:\n{episode_anchor}\n")

    # Tier 2: direct episode hits from temporal query
    if episode_hits:
        ep_lines = "\n".join(f"- {e}" for e in episode_hits)
        parts.append(f"\nSession history matching your query:\n{ep_lines}\n")

    # Tier 3: semantic memories
    if memories:
        memory_lines = "\n".join(f"- {m}" for m in memories)
        parts.append(f"\nRelevant context:\n{memory_lines}\n")

    # Tier 1: recent turns from current session (conversation history)
    if recent_turns:
        history_lines = "\n".join(
            f"{t['role'].capitalize()}: {t['content']}" for t in recent_turns
        )
        parts.append(f"\nRecent conversation:\n{history_lines}\n")

    parts.append(f"\nUser:\n{query}\n\nAssistant:")
    return "".join(parts)
