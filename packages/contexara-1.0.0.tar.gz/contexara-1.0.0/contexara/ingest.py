from __future__ import annotations

from .extract import extract_memories, should_extract
from .retrieve import retrieve
from .store import upsert_memory

_EXISTING_MEMORY_CONTEXT_K = 20


def ingest_turn(
    user_text: str,
    assistant_text: str,
    session_id: str | None = None,
    namespace: str = "default",
) -> dict[str, int]:
    """
    Ingest one conversation turn:
    1. Save raw turns to Tier 1 (raw_turns) if session_id provided.
    2. Extract and upsert semantic memories to Tier 3 (fast-path skip for low-signal).

    Returns ingestion stats.
    """
    stats = {
        "extracted": 0,
        "inserted": 0,
        "updated": 0,
        "skipped": 0,
    }

    _BAD_RESPONSE_PREFIXES = ("[LLM ERROR]", "I don't have records", "I don't have information")

    # Tier 1: always save raw turns if we have a session
    if session_id:
        try:
            from .session import save_turn
            if user_text and user_text.strip():
                save_turn(session_id, "user", user_text, namespace=namespace)
            if assistant_text and assistant_text.strip():
                save_turn(session_id, "assistant", assistant_text, namespace=namespace)
        except Exception:
            pass

    # Tier 3: skip extraction if assistant response is a known failure
    if assistant_text and any(assistant_text.strip().startswith(p) for p in _BAD_RESPONSE_PREFIXES):
        return stats

    # Tier 3: fast-path skip for low-signal turns
    if not should_extract(user_text) and not should_extract(assistant_text):
        return stats

    existing = retrieve(user_text, top_k=_EXISTING_MEMORY_CONTEXT_K, namespace=namespace)
    candidates = extract_memories(
        user_text=user_text,
        assistant_text=assistant_text,
        existing_memories=existing,
    )
    stats["extracted"] = len(candidates)

    for memory in candidates:
        try:
            action = upsert_memory(
                content=memory["content"],
                kind=memory["kind"],
                importance=memory["importance"],
                ttl_days=memory.get("ttl_days"),
                namespace=namespace,
            )
            stats[action] += 1
        except Exception:
            stats["skipped"] += 1

    return stats
