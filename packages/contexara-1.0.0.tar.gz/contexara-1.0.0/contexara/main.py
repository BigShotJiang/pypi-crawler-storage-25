from __future__ import annotations

from .retrieve import retrieve, retrieve_episodes
from .enhance import enhance
from .ingest import ingest_turn
from .llm import call_llm

_DEFAULT_NAMESPACE = "default"


def ask(query: str, namespace: str = _DEFAULT_NAMESPACE) -> str:
    """Main entry point — full three-tier context injection with rich spinner."""
    return _ask(query, namespace=namespace, rich=True)


def ask_plain(query: str, namespace: str = _DEFAULT_NAMESPACE) -> str:
    """ask() without rich output — for programmatic / SDK use."""
    return _ask(query, namespace=namespace, rich=False)


def _ask(query: str, namespace: str, rich: bool) -> str:
    if not query or not query.strip():
        raise ValueError("Query cannot be empty")

    session_id = None
    recent_turns = None
    episode_anchor = None
    is_new_session = False

    try:
        from .session import get_recent_turns, get_last_episode, retry_pending_sessions
        retry_pending_sessions(namespace=namespace)
        session_id, is_new_session = _get_session_with_flag(namespace=namespace)
        recent_turns = get_recent_turns(session_id) if session_id else None
        episode_anchor = get_last_episode(namespace=namespace) if is_new_session else None
    except Exception:
        pass

    def _run_query() -> str:
        memories = retrieve(query, namespace=namespace)
        episode_hits = []
        try:
            episode_hits = retrieve_episodes(query, namespace=namespace)
        except Exception:
            pass
        prompt = enhance(query, memories, recent_turns=recent_turns, episode_anchor=episode_anchor, episode_hits=episode_hits)
        return call_llm(prompt)

    if rich:
        from rich.console import Console
        with Console().status("[cyan]Thinking…[/cyan]", spinner="dots"):
            response = _run_query()
    else:
        response = _run_query()

    try:
        ingest_turn(query, response, session_id=session_id, namespace=namespace)
    except Exception:
        pass

    return response


def _get_session_with_flag(namespace: str = _DEFAULT_NAMESPACE) -> tuple[str, bool]:
    """
    Returns (session_id, is_new_session).
    is_new_session=True means the previous session was just closed.
    """
    from .session import _get_connection, initialize_session_db, get_or_create_session, _minutes_since, _SESSION_TIMEOUT_MINUTES

    initialize_session_db()
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT session_id, last_action_at FROM active_sessions WHERE status = 'open' AND namespace = ? ORDER BY last_action_at DESC LIMIT 1",
        (namespace,),
    )
    row = cursor.fetchone()
    conn.close()

    if row:
        minutes_elapsed = _minutes_since(row["last_action_at"])
        is_new_session = minutes_elapsed > _SESSION_TIMEOUT_MINUTES
    else:
        is_new_session = True

    session_id = get_or_create_session(namespace=namespace)
    return session_id, is_new_session
