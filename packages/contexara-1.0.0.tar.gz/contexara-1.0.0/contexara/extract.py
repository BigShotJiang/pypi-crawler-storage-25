from __future__ import annotations

import json
import re
from typing import Any

_LOW_SIGNAL_TOKENS = {
    "ok", "okay", "sure", "yes", "no", "yeah", "yep", "nope",
    "thanks", "thank", "you", "great", "cool", "nice", "good",
    "got", "it", "fine", "alright", "right", "perfect", "sounds",
    "lol", "haha", "hmm", "ah", "oh", "wow", "awesome",
}


def should_extract(text: str) -> bool:
    """Return False for low-signal turns that are not worth sending to the LLM."""
    if not text or not text.strip():
        return False
    if len(text.strip()) < 15:
        return False
    tokens = set(text.lower().split())
    if tokens.issubset(_LOW_SIGNAL_TOKENS):
        return False
    return True


MEMORY_IMPORTANCE = {
    "profile": 5,
    "preference": 4,
    "constraint": 4,
    "task": 3,
}

VALID_KINDS = set(MEMORY_IMPORTANCE.keys()) | {"note"}

LOW_SIGNAL_PREFIXES = (
    "hi",
    "hello",
    "thanks",
    "thank you",
    "ok",
    "okay",
    "cool",
    "great",
)

_EXTRACTION_SYSTEM_PROMPT = """\
You are a memory extraction engine. Output ONLY a raw JSON array — no markdown, no prose, no explanation.

Extract the most important, distinct, long-term facts about the user from the conversation turn.
Be selective — prefer 1-4 high-quality memories over many overlapping ones.

Rules:
- Include: name, role, things built/completed/tested/shipped, stated preferences, hard constraints, current tasks.
- Skip: vague plans, filler, questions, anything already covered by the existing memories listed below.
- Do NOT paraphrase an existing memory — if the fact is already stored, skip it entirely.
- Third-person statements only (e.g. "User built hybrid search with RRF").
- kind: profile | preference | task | constraint | note
- importance: integer 1-5 (profile=5, preference/constraint=4, task=3, note=1)

Output format (strictly):
[{"content": "...", "kind": "...", "importance": N}, ...]

If nothing new is worth remembering output exactly: []
"""


def _call_llm_for_extraction(
    user_text: str,
    assistant_text: str,
    existing_memories: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Call Bedrock to extract memories from a conversation turn. Returns [] on any failure."""
    try:
        from contexara.llm import BedrockConfig, _get_client

        import json as _json

        existing_block = ""
        if existing_memories:
            items = "\n".join(f"- {m}" for m in existing_memories[:20])
            existing_block = f"\n\nAlready stored memories (do NOT re-extract these):\n{items}\n"

        turn = f"{existing_block}\nConversation turn:\nUser: {user_text.strip()}\nAssistant: {assistant_text.strip()}"
        payload = {
            "anthropic_version": "bedrock-2023-05-31",
            "system": _EXTRACTION_SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": [{"type": "text", "text": turn}]}],
            "max_tokens": 512,
            "temperature": 0.0,
        }

        config = BedrockConfig.from_env()
        client = _get_client(config.region)
        response = client.invoke_model(
            modelId=config.model_id,
            body=_json.dumps(payload),
            contentType="application/json",
            accept="application/json",
        )
        result = _json.loads(response["body"].read())
        raw_text = result["content"][0]["text"].strip()

        # Strip markdown code fences if model wraps output in ```json ... ```
        raw_text = re.sub(r"^```(?:json)?\s*", "", raw_text)
        raw_text = re.sub(r"\s*```$", "", raw_text).strip()

        candidates = json.loads(raw_text)
        if not isinstance(candidates, list):
            return []

        memories = []
        for item in candidates:
            if not isinstance(item, dict):
                continue
            content = str(item.get("content", "")).strip()
            kind = str(item.get("kind", "note")).strip().lower()
            importance = item.get("importance", 1)

            if not content:
                continue
            if kind not in VALID_KINDS:
                kind = "note"
            try:
                importance = max(1, min(5, int(importance)))
            except (TypeError, ValueError):
                importance = MEMORY_IMPORTANCE.get(kind, 1)

            memories.append({"content": content, "kind": kind, "importance": importance, "ttl_days": None})

        return memories

    except Exception:
        return []


# ---------------------------------------------------------------------------
# Regex fallback (V1 logic — used when LLM extraction fails)
# ---------------------------------------------------------------------------

def _clean_text(text: str) -> str:
    return " ".join(text.strip().split())


def _split_into_segments(text: str) -> list[str]:
    if not text:
        return []
    normalized = _clean_text(text)
    punctuation_parts = re.split(r"[.;]\s+|\n+", normalized)
    segments: list[str] = []
    for part in punctuation_parts:
        chunk = part.strip()
        if not chunk:
            continue
        chunk = re.sub(
            r"\s+and\s+(?=(i\s+(?:am|m|will)|my\s+|first\s+task|tomorrow\b))",
            " ||| ",
            chunk,
            flags=re.IGNORECASE,
        )
        sub_parts = [p.strip() for p in chunk.split("|||") if p.strip()]
        segments.extend(sub_parts)
    return segments


def _extract_profile(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    name_match = re.search(r"\bmy name is\s+([A-Za-z][A-Za-z'\-\s]{1,50})", text, re.IGNORECASE)
    if name_match:
        name = _clean_text(name_match.group(1)).rstrip(".,!?")
        items.append({"content": f"User name is {name}", "kind": "profile", "importance": 5, "ttl_days": None})
    role_match = re.search(r"\bi am\s+(a|an)\s+([A-Za-z][A-Za-z'\-\s]{1,80})", text, re.IGNORECASE)
    if role_match:
        role = _clean_text(role_match.group(2)).rstrip(".,!?")
        if len(role.split()) <= 8:
            items.append({"content": f"User role is {role}", "kind": "profile", "importance": 5, "ttl_days": None})
    return items


def _extract_preferences(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    patterns = [
        r"\bi prefer\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi like\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi love\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi dislike\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi hate\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            continue
        detail = _clean_text(match.group(1)).rstrip(".,!?")
        if not detail or detail.lower().startswith(LOW_SIGNAL_PREFIXES):
            continue
        items.append({"content": f"User preference: {detail}", "kind": "preference", "importance": 4, "ttl_days": None})
    return items


def _extract_tasks(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    task_patterns = [
        r"\bi am building\s+(.+)",
        r"\bi'?m building\s+(.+)",
        r"\bi am working on\s+(.+)",
        r"\bi'?m working on\s+(.+)",
        r"\bi am creating\s+(.+)",
        r"\bi'?m creating\s+(.+)",
        r"\bi (?:just\s+)?built\s+(.+)",
        r"\bi (?:just\s+)?finished\s+(.+)",
        r"\bi (?:just\s+)?completed\s+(.+)",
        r"\bi (?:just\s+)?shipped\s+(.+)",
        r"\bi(?:'?m|'m| am) (?:now\s+)?testing\s+(.+)",
        r"\bi will (?:start\s+)?(?:work on|build|implement|create)\s+(.+)",
        r"\btomorrow(?:\s+i)?\s+will\s+(?:start\s+)?(?:work on|build|implement|create)\s+(.+)",
        r"\bfirst task(?:\s+tomorrow)?\s+will\s+be\s+(?:implementing|building|creating|working on)\s+(.+)",
    ]
    for pattern in task_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            continue
        task = _clean_text(match.group(1)).rstrip(".,!?")
        if task:
            items.append({"content": f"User is working on {task}", "kind": "task", "importance": 3, "ttl_days": 30})
    return items


def _extract_constraints(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    if re.search(r"\b(i need|must|should|do not|don't|cannot|can't)\b", text, re.IGNORECASE):
        cleaned = _clean_text(text).rstrip(".,!?")
        if cleaned and not cleaned.endswith("?"):
            items.append({"content": f"User constraint: {cleaned}", "kind": "constraint", "importance": 4, "ttl_days": 14})
    return items


def _regex_extract(user_text: str) -> list[dict[str, Any]]:
    extracted: list[dict[str, Any]] = []
    for segment in _split_into_segments(user_text):
        cleaned = _clean_text(segment)
        if not cleaned or cleaned.endswith("?"):
            continue
        extracted.extend(_extract_profile(cleaned))
        extracted.extend(_extract_preferences(cleaned))
        extracted.extend(_extract_tasks(cleaned))
        extracted.extend(_extract_constraints(cleaned))
    return extracted


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_memories(
    user_text: str,
    assistant_text: str = "",
    existing_memories: list[str] | None = None,
) -> list[dict[str, Any]]:
    """
    Extract high-signal memories from a conversation turn.

    Strategy: LLM extraction (Bedrock) analysing both user and assistant text,
    with existing memories passed as context so the LLM skips already-known facts.
    Falls back to deterministic regex on user text if LLM call fails.
    """
    llm_results = _call_llm_for_extraction(user_text or "", assistant_text or "", existing_memories)

    if llm_results:
        candidates = llm_results
    else:
        candidates = _regex_extract(user_text or "")

    # Deduplicate within this extraction call
    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for item in candidates:
        key = (item["kind"], item["content"].lower())
        if key not in seen:
            seen.add(key)
            deduped.append(item)

    return deduped
