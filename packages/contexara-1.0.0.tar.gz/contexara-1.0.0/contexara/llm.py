"""
LLM adapter for Contexara using AWS Bedrock (Anthropic Claude).

This module exposes a single public function:
`call_llm(prompt: str) -> str`

Design goals:
- Keep a stable, simple interface for the rest of the app.
- Centralize Bedrock configuration and request formatting.
- Return human-readable error strings instead of raising, to match existing app flow.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Dict, List, TypedDict

import boto3
from botocore.client import BaseClient
from dotenv import load_dotenv

load_dotenv()


class _ContentBlock(TypedDict):
    type: str
    text: str


class _Message(TypedDict):
    role: str
    content: List[_ContentBlock]


@dataclass(frozen=True)
class BedrockConfig:
    """Runtime configuration for Bedrock calls."""

    region: str
    model_id: str
    max_tokens: int
    temperature: float

    @staticmethod
    def from_env() -> "BedrockConfig":
        """
        Build config from environment variables with sensible defaults.

        Notes:
        - `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` are handled by boto3
          credential chain and are not read directly here.
        - `AWS_ACCESS_KEY` is also supported as a fallback alias for teams that
          accidentally use the non-standard key name.
        """
        # Backward-compatible alias for a common typo in environment setup.
        if os.getenv("AWS_ACCESS_KEY") and not os.getenv("AWS_ACCESS_KEY_ID"):
            os.environ["AWS_ACCESS_KEY_ID"] = os.environ["AWS_ACCESS_KEY"]

        model_id = os.getenv("BEDROCK_MODEL_ID")
        if not model_id:
            raise EnvironmentError(
                "BEDROCK_MODEL_ID is not set. Run 'contexara setup' to configure."
            )

        return BedrockConfig(
            region=os.getenv("AWS_REGION", "us-east-1"),
            model_id=model_id,
            max_tokens=int(os.getenv("LLM_MAX_TOKENS", "512")),
            temperature=float(os.getenv("LLM_TEMPERATURE", "0.7")),
        )


@lru_cache(maxsize=1)
def _get_client(region: str) -> BaseClient:
    """Create and cache a Bedrock runtime client."""
    return boto3.client("bedrock-runtime", region_name=region)


def _build_request_body(prompt: str, config: BedrockConfig) -> Dict[str, Any]:
    """Create an Anthropic-compatible Bedrock request payload."""
    # Split system instructions from user content if delimiter present
    if "\n\nUser:\n" in prompt:
        system_part, user_part = prompt.split("\n\nUser:\n", 1)
        user_text = user_part.replace("\n\nAssistant:", "").strip()
    else:
        system_part = ""
        user_text = prompt.strip()

    message: _Message = {
        "role": "user",
        "content": [{"type": "text", "text": user_text}],
    }
    body: Dict[str, Any] = {
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [message],
        "max_tokens": config.max_tokens,
        "temperature": config.temperature,
    }
    if system_part.strip():
        body["system"] = system_part.strip()
    return body


def _extract_text(result: Dict[str, Any]) -> str:
    """
    Parse model response and return assistant text.

    Raises:
        ValueError: If response shape is unexpected.
    """
    content = result.get("content")
    if not isinstance(content, list) or not content:
        raise ValueError("Malformed Bedrock response: missing content list.")

    first_item = content[0]
    if not isinstance(first_item, dict):
        raise ValueError("Malformed Bedrock response: invalid content item.")

    text = first_item.get("text")
    if not isinstance(text, str):
        raise ValueError("Malformed Bedrock response: missing text.")

    return text.strip()


def call_llm(prompt: str) -> str:
    """
    Send a prompt to AWS Bedrock and return the model output text.

    Returns:
        str: Assistant response text on success, or a prefixed error string
        (`[LLM ERROR] ...`) on failure.
    """
    if not prompt or not prompt.strip():
        return "[LLM ERROR] Prompt cannot be empty."

    config = BedrockConfig.from_env()
    client = _get_client(config.region)
    payload = _build_request_body(prompt, config)

    try:
        response = client.invoke_model(
            modelId=config.model_id,
            body=json.dumps(payload),
            contentType="application/json",
            accept="application/json",
        )
        result = json.loads(response["body"].read())
        return _extract_text(result)
    except Exception as exc:
        return f"[LLM ERROR] {exc}"
