"""Interactive setup wizard for Contexara."""
from __future__ import annotations

import os
from pathlib import Path

from rich.console import Console
from rich.rule import Rule

console = Console()

_CONFIG_DIR = Path.home() / ".contexara"
_CONFIG_FILE = _CONFIG_DIR / ".env"

_BEDROCK_REGIONS = [
    "us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1", "ap-northeast-1"
]


def is_configured() -> bool:
    """Return True if all required creds are available."""
    # Already in environment (e.g. from local .env or shell)
    if (
        os.getenv("AWS_ACCESS_KEY_ID")
        and os.getenv("AWS_SECRET_ACCESS_KEY")
        and os.getenv("BEDROCK_MODEL_ID")
    ):
        return True
    # Or saved in ~/.contexara/.env
    if _CONFIG_FILE.exists():
        _load_config()
        return bool(
            os.getenv("AWS_ACCESS_KEY_ID")
            and os.getenv("AWS_SECRET_ACCESS_KEY")
            and os.getenv("BEDROCK_MODEL_ID")
        )
    return False


def _load_config() -> None:
    """Load ~/.contexara/.env into os.environ."""
    if not _CONFIG_FILE.exists():
        return
    for line in _CONFIG_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if key and value and not os.getenv(key):
            os.environ[key] = value


def load_config() -> None:
    """Public: load saved config into environment."""
    _load_config()


def run_setup() -> None:
    """Run the interactive setup wizard."""
    console.print()
    console.print(Rule("[bold bright_cyan]Contexara Setup[/bold bright_cyan]", style="cyan"))
    console.print()
    console.print("  This wizard saves your AWS credentials to [bright_cyan]~/.contexara/.env[/bright_cyan]")
    console.print()
    console.print("  You need an AWS IAM user with Bedrock permissions.")
    console.print("  [bright_cyan]Guide:[/bright_cyan] https://docs.aws.amazon.com/bedrock/latest/userguide/security-iam.html")
    console.print()
    console.print("  Enable model access in your AWS region:")
    console.print("  [bright_cyan]Console:[/bright_cyan] https://console.aws.amazon.com/bedrock/home#/modelaccess")
    console.print("  Required models:")
    console.print("    · amazon.titan-embed-text-v2:0")
    console.print("    · anthropic.claude-haiku-4-5-20251001-v1:0  [bright_cyan](or your preferred Claude model)[/bright_cyan]")
    console.print()
    console.print(Rule(style="cyan"))
    console.print("  [bright_cyan]Type 'exit' at any prompt to cancel.[/bright_cyan]")
    console.print()

    def _prompt(label: str, secret: bool = False) -> str | None:
        """Prompt for input. Returns None if user exits or interrupts."""
        try:
            if secret:
                import getpass
                value = getpass.getpass(f"  {label}: ").strip()
            else:
                value = console.input(f"  [bright_cyan]{label}[/bright_cyan]: ").strip()
            if value.lower() == "exit":
                return None
            return value
        except (KeyboardInterrupt, EOFError):
            return None

    # AWS_ACCESS_KEY_ID
    access_key = ""
    while not access_key:
        val = _prompt("AWS_ACCESS_KEY_ID")
        if val is None:
            console.print("\n  [bright_cyan]·[/bright_cyan]  Setup cancelled.")
            console.print()
            return
        if not val:
            console.print("  [bright_cyan]·[/bright_cyan]  Cannot be empty.")
        else:
            access_key = val

    # AWS_SECRET_ACCESS_KEY
    secret_key = ""
    while not secret_key:
        val = _prompt("AWS_SECRET_ACCESS_KEY", secret=True)
        if val is None:
            console.print("\n  [bright_cyan]·[/bright_cyan]  Setup cancelled.")
            console.print()
            return
        if not val:
            console.print("  [bright_cyan]·[/bright_cyan]  Cannot be empty.")
        else:
            secret_key = val

    # AWS_REGION
    val = _prompt("AWS_REGION [us-east-1]")
    if val is None:
        console.print("\n  [bright_cyan]·[/bright_cyan]  Setup cancelled.")
        console.print()
        return
    region = val if val else "us-east-1"

    # BEDROCK_MODEL_ID
    console.print()
    console.print("  [bright_cyan]BEDROCK_MODEL_ID[/bright_cyan] — paste your inference profile ARN or plain model ID.")
    console.print("  [bright_cyan]Example: arn:aws:bedrock:us-east-1:123456789:inference-profile/...[/bright_cyan]")
    console.print("  [bright_cyan]Or plain: anthropic.claude-haiku-4-5-20251001-v1:0[/bright_cyan]")
    console.print()
    model_id = ""
    while not model_id:
        val = _prompt("BEDROCK_MODEL_ID")
        if val is None:
            console.print("\n  [bright_cyan]·[/bright_cyan]  Setup cancelled.")
            console.print()
            return
        if not val:
            console.print("  [bright_cyan]·[/bright_cyan]  Cannot be empty.")
        else:
            model_id = val

    # Test connection
    console.print()
    with console.status("[cyan]Testing connection to AWS Bedrock…[/cyan]", spinner="dots"):
        error = _test_connection(access_key, secret_key, region, model_id)

    if error:
        console.print(f"  [bright_red]✗[/bright_red]  Connection failed: {error}")
        console.print("  [bright_cyan]·[/bright_cyan]  Check your credentials and model access, then run [bright_white]contexara setup[/bright_white] again.")
        console.print()
        return

    console.print("  [bright_green]✓[/bright_green]  Connected to AWS Bedrock.")

    # Save
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config_content = (
        f"AWS_ACCESS_KEY_ID={access_key}\n"
        f"AWS_SECRET_ACCESS_KEY={secret_key}\n"
        f"AWS_REGION={region}\n"
        f"BEDROCK_MODEL_ID={model_id}\n"
    )
    _CONFIG_FILE.write_text(config_content, encoding="utf-8")

    # Load into current process
    os.environ["AWS_ACCESS_KEY_ID"] = access_key
    os.environ["AWS_SECRET_ACCESS_KEY"] = secret_key
    os.environ["AWS_REGION"] = region
    os.environ["BEDROCK_MODEL_ID"] = model_id

    console.print(f"  [bright_green]✓[/bright_green]  Saved to [bright_cyan]~/.contexara/.env[/bright_cyan]")
    console.print()
    console.print("  Run [bright_white]contexara ask \"hello\"[/bright_white] to get started.")
    console.print()


def _test_connection(access_key: str, secret_key: str, region: str, model_id: str) -> str | None:
    """Try a minimal Bedrock call. Returns error string or None on success."""
    try:
        import boto3, json
        client = boto3.client(
            "bedrock-runtime",
            region_name=region,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
        )
        payload = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "messages": [{"role": "user", "content": [{"type": "text", "text": "hi"}]}],
            "max_tokens": 10,
            "temperature": 0.0,
        })
        client.invoke_model(
            modelId=model_id,
            body=payload,
            contentType="application/json",
            accept="application/json",
        )
        return None
    except Exception as e:
        return str(e)
