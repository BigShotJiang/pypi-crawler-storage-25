from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from .ingest import ingest_turn


def _split_text(text: str) -> list[str]:
    """Split plain text into paragraph-sized chunks."""
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    if not paragraphs:
        paragraphs = [line.strip() for line in text.splitlines() if line.strip()]
    return paragraphs


def ingest_file(
    path: str | Path,
    on_progress: Callable[[int, int], None] | None = None,
) -> dict[str, int]:
    """
    Ingest a .txt, .md, or .jsonl file into memory.

    .txt / .md: split on blank lines, each paragraph is one turn.
    .jsonl: each line is a JSON object with a required "content" key;
            optional "assistant" key for assistant text.

    Args:
        on_progress: optional callback(current, total) called after each chunk.

    Returns aggregated ingest stats.
    """
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    suffix = file_path.suffix.lower()
    if suffix not in {".txt", ".md", ".jsonl"}:
        raise ValueError(f"Unsupported file type: {suffix}. Use .txt, .md, or .jsonl")

    totals = {"extracted": 0, "inserted": 0, "updated": 0, "skipped": 0}

    if suffix == ".jsonl":
        raw_lines = file_path.read_text(encoding="utf-8").splitlines()
        chunks: list[tuple[str, str]] = []
        for line in raw_lines:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                totals["skipped"] += 1
                continue
            user_text = str(obj.get("content", "")).strip()
            assistant_text = str(obj.get("assistant", "")).strip()
            if not user_text:
                totals["skipped"] += 1
                continue
            chunks.append((user_text, assistant_text))

        total = len(chunks)
        for i, (user_text, assistant_text) in enumerate(chunks, 1):
            stats = ingest_turn(user_text, assistant_text)
            for k in totals:
                totals[k] += stats.get(k, 0)
            if on_progress:
                on_progress(i, total)
    else:
        text = file_path.read_text(encoding="utf-8")
        chunks_txt = _split_text(text)
        total = len(chunks_txt)
        for i, chunk in enumerate(chunks_txt, 1):
            stats = ingest_turn(chunk, "")
            for k in totals:
                totals[k] += stats.get(k, 0)
            if on_progress:
                on_progress(i, total)

    return totals
