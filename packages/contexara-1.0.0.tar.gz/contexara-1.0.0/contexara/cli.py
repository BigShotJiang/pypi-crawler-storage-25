"""Command-line interface for Contexara."""

from __future__ import annotations

import argparse
from typing import Iterable

from rich.console import Console
from rich.table import Table
from rich import box
from rich.text import Text
from rich.columns import Columns
from rich.padding import Padding
from rich.rule import Rule

from . import __version__
from .main import ask
from .setup_wizard import is_configured, load_config, run_setup
from .session import create_namespace, list_namespaces, remove_namespace
from .store import clear_all, consolidate, delete_memory, get_stats, list_all, prune_expired, search_memories, store

console = Console()

# Classic terminal theme: cyan (structure) · white (content) · green (success/raw) · red (errors only)

def _kind_text(kind: str) -> Text:
    return Text(kind, style="bright_white")


def _imp_text(imp) -> Text:
    val = int(imp) if imp else 0
    return Text(str(val), style="bright_white", justify="center")


def _src_text(src: str) -> Text:
    if src == "compressed":
        return Text(src, style="bright_cyan")
    return Text(src, style="bright_green")


def _build_memories_table(memories: list[dict], title: str | None = None) -> Table:
    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold bright_cyan",
        title=title,
        title_style="bold bright_white",
        border_style="bright_cyan",
        pad_edge=True,
        expand=False,
    )
    table.add_column("ID", style="bright_cyan", justify="right", no_wrap=True)
    table.add_column("Kind", no_wrap=True)
    table.add_column("Imp", justify="center", no_wrap=True)
    table.add_column("Source", no_wrap=True)
    table.add_column("Content", style="bright_white")

    for m in memories:
        content = m["content"]
        if len(content) > 72:
            content = content[:69] + "..."
        table.add_row(
            str(m["id"]),
            _kind_text(m.get("kind", "note")),
            _imp_text(m.get("importance", 1)),
            _src_text(m.get("source", "raw")),
            content,
        )
    return table


def _print_memories_table(memories: list[dict], title: str | None = None) -> None:
    if not memories:
        console.print("  [bright_cyan](no memories)[/bright_cyan]")
        return
    console.print(_build_memories_table(memories, title=title))


def _print_stats(stats: dict) -> None:
    total = stats["total"]
    oldest = stats.get("oldest") or "—"
    newest = stats.get("newest") or "—"

    console.print()
    console.print(f"  [bold bright_cyan]Memories[/bold bright_cyan]  [bright_white]{total} total[/bright_white]  ·  oldest [bright_cyan]{oldest}[/bright_cyan]  ·  newest [bright_cyan]{newest}[/bright_cyan]")
    console.print()

    # By kind
    kind_table = Table(box=None, show_header=False, pad_edge=False, padding=(0, 2, 0, 0))
    kind_table.add_column("kind")
    kind_table.add_column("count", justify="right")
    for kind, count in stats.get("by_kind", {}).items():
        kind_table.add_row(Text(kind, style="bright_white"), Text(str(count), style="bright_cyan"))

    # By source
    src_table = Table(box=None, show_header=False, pad_edge=False, padding=(0, 2, 0, 0))
    src_table.add_column("source")
    src_table.add_column("count", justify="right")
    src_table.add_column("avg_imp")
    src_table.add_column("avg_age")
    for source, count in stats.get("by_source", {}).items():
        ss = stats.get("source_stats", {}).get(source, {})
        avg_imp = ss.get("avg_importance", "—")
        avg_age = ss.get("avg_age_days", "—")
        src_table.add_row(
            _src_text(source),
            Text(str(count), style="bright_cyan"),
            Text(f"imp {avg_imp}", style="bright_white"),
            Text(f"age {avg_age}d", style="bright_white"),
        )

    console.print(Columns([
        Padding(kind_table, (0, 4, 0, 2)),
        Padding(src_table, (0, 0, 0, 2)),
    ]))
    console.print()


def _ok(msg: str) -> None:
    console.print(f"  [bright_green]✓[/bright_green]  [bright_white]{msg}[/bright_white]")


def _warn(msg: str) -> None:
    console.print(f"  [bright_cyan]~[/bright_cyan]  [bright_white]{msg}[/bright_white]")


def _err(msg: str) -> None:
    console.print(f"  [bright_red]✗[/bright_red]  [bright_white]{msg}[/bright_white]")


def _info(msg: str) -> None:
    console.print(f"  [bright_cyan]·[/bright_cyan]  [bright_white]{msg}[/bright_white]")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="contexara",
        description="CLI-first memory engine for LLM context management.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("setup", help="Configure AWS Bedrock credentials.").set_defaults(func=_cmd_setup)

    chat_parser = subparsers.add_parser("chat", help="Start interactive chat mode.")
    chat_parser.add_argument("--namespace", default="default", metavar="NS", help="Memory namespace (default: default).")
    chat_parser.set_defaults(func=_cmd_chat)

    ask_parser = subparsers.add_parser("ask", help="Ask a memory-aware question.")
    ask_parser.add_argument("query", nargs="+")
    ask_parser.add_argument("--namespace", default="default", metavar="NS", help="Memory namespace (default: default).")
    ask_parser.set_defaults(func=_cmd_ask)

    store_parser = subparsers.add_parser("store", help="Store a memory string.")
    store_parser.add_argument("content", nargs="+")
    store_parser.add_argument("--namespace", default="default", metavar="NS", help="Memory namespace (default: default).")
    store_parser.set_defaults(func=_cmd_store)

    list_parser = subparsers.add_parser("list", help="List all stored memories.")
    list_parser.add_argument("--since", metavar="YYYY-MM-DD", help="Only show memories created on or after this date.")
    list_parser.add_argument("--before", metavar="YYYY-MM-DD", help="Only show memories created on or before this date.")
    list_parser.add_argument("--namespace", default="default", metavar="NS", help="Memory namespace (default: default).")
    list_parser.set_defaults(func=_cmd_list)

    delete_parser = subparsers.add_parser("delete", help="Delete a memory by ID.")
    delete_parser.add_argument("id", type=int, help="Memory ID (from contexara list).")
    delete_parser.set_defaults(func=_cmd_delete)

    search_parser = subparsers.add_parser("search", help="Semantic search over memories.")
    search_parser.add_argument("query", nargs="+")
    search_parser.add_argument("--top", type=int, default=5, help="Number of results (default 5).")
    search_parser.add_argument("--since", metavar="YYYY-MM-DD", help="Only return memories created on or after this date.")
    search_parser.add_argument("--before", metavar="YYYY-MM-DD", help="Only return memories created on or before this date.")
    search_parser.add_argument("--namespace", default="default", metavar="NS", help="Memory namespace (default: default).")
    search_parser.set_defaults(func=_cmd_search)

    prune_parser = subparsers.add_parser("prune", help="Archive expired memories (TTL-based).")
    prune_parser.add_argument("--dry-run", action="store_true", help="Show count without making changes.")
    prune_parser.set_defaults(func=_cmd_prune)

    ingest_parser = subparsers.add_parser("ingest", help="Bulk-ingest memories from a file (.txt, .md, .jsonl).")
    ingest_parser.add_argument("file", help="Path to file to ingest.")
    ingest_parser.set_defaults(func=_cmd_ingest)

    subparsers.add_parser("stats", help="Show memory statistics.").set_defaults(func=_cmd_stats)

    subparsers.add_parser("consolidate", help="LLM-merge overlapping memories.").set_defaults(func=_cmd_consolidate)

    show_parser = subparsers.add_parser("show", help="Show full detail for a memory by ID.")
    show_parser.add_argument("id", type=int)
    show_parser.set_defaults(func=_cmd_show)

    clear_parser = subparsers.add_parser("clear", help="Delete all stored memories.")
    clear_parser.add_argument("--yes", action="store_true", help="Skip confirmation.")
    clear_parser.set_defaults(func=_cmd_clear)

    ns_parser = subparsers.add_parser("namespace", help="Manage memory namespaces.")
    ns_sub = ns_parser.add_subparsers(dest="ns_action")
    ns_sub.add_parser("list", help="List all namespaces.")
    ns_create = ns_sub.add_parser("create", help="Create a new namespace.")
    ns_create.add_argument("name", help="Namespace name to create.")
    ns_remove = ns_sub.add_parser("remove", help="Remove a namespace and all its data.")
    ns_remove.add_argument("name", help="Namespace to remove.")
    ns_remove.add_argument("--yes", action="store_true", help="Skip confirmation.")
    ns_parser.set_defaults(func=_cmd_namespace)

    mcp_parser = subparsers.add_parser("mcp", help="Start the Contexara MCP server.")
    mcp_parser.add_argument("--sse", action="store_true", help="Use SSE transport instead of stdio.")
    mcp_parser.add_argument("--port", type=int, default=8000, metavar="PORT", help="Port for SSE transport (default: 8000).")
    mcp_parser.set_defaults(func=_cmd_mcp)

    return parser


def _join_parts(parts: Iterable[str]) -> str:
    return " ".join(parts).strip()


def _print_show(m: dict) -> None:
    console.print()
    console.print(f"  [bold bright_cyan]ID[/bold bright_cyan]          [bright_white]{m['id']}[/bright_white]")
    console.print(f"  [bold bright_cyan]Kind[/bold bright_cyan]        [bright_white]{m.get('kind','note')}[/bright_white]")
    console.print(f"  [bold bright_cyan]Importance[/bold bright_cyan]  [bright_white]{m.get('importance', 1)}[/bright_white]")
    console.print(f"  [bold bright_cyan]Source[/bold bright_cyan]      {_src_text(m.get('source','raw'))}")
    console.print(f"  [bold bright_cyan]Level[/bold bright_cyan]       [bright_white]{m.get('compression_level', 0)}[/bright_white]")
    console.print(f"  [bold bright_cyan]Created[/bold bright_cyan]     [bright_white]{m.get('created_at', '—')}[/bright_white]")
    console.print(f"  [bold bright_cyan]Content[/bold bright_cyan]     [bright_white]{m['content']}[/bright_white]")
    console.print()


# ---------------------------------------------------------------------------
# Chat mode
# ---------------------------------------------------------------------------

def _cmd_setup(_args: argparse.Namespace) -> int:
    run_setup()
    return 0


def _cmd_chat(args: argparse.Namespace) -> int:
    from .session import list_namespaces
    namespace = getattr(args, "namespace", "default")

    console.print()
    console.print(f"  [bold bright_cyan]Contexara Chat[/bold bright_cyan]  [bright_white]type 'exit' to quit[/bright_white]  [bright_cyan]namespace: {namespace}[/bright_cyan]")
    console.print("  [bright_cyan]Commands: /store /list /show <id> /delete <id> /search /stats /consolidate /clear /namespace[/bright_cyan]")
    console.print()

    while True:
        try:
            user_input = console.input("[bold green]You[/bold green]: ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n  [bright_cyan]Goodbye.[/bright_cyan]")
            return 0

        if not user_input:
            continue

        if user_input.lower() == "exit":
            console.print("  [bright_cyan]Goodbye.[/bright_cyan]")
            return 0

        # /namespace commands
        if user_input == "/namespace":
            _info(f"Current namespace: [bright_cyan]{namespace}[/bright_cyan]")
            continue

        if user_input in ("/namespace list", "/namespace all"):
            nss = list_namespaces()
            if not nss:
                _info("No namespaces registered yet.")
            else:
                for ns in nss:
                    _info(f"[bright_cyan]{ns['name']}[/bright_cyan]  [bright_white]{ns['created_at'][:10]}[/bright_white]")
            continue

        if user_input.startswith("/namespace remove "):
            target = user_input[18:].strip().strip('"')
            if not target:
                _err("Usage: /namespace remove <name>")
            elif target == "default":
                _err("Cannot remove the 'default' namespace.")
            else:
                confirm = console.input(f"  [bright_red]Delete namespace '{target}' and all its data?[/bright_red] [bright_white](y/N)[/bright_white]: ").strip().lower()
                if confirm in {"y", "yes"}:
                    try:
                        counts = remove_namespace(target)
                        _ok(f"Removed namespace [bright_cyan]{target}[/bright_cyan]  (memories: {counts.get('memories',0)}, sessions: {counts.get('active_sessions',0)}, turns: {counts.get('raw_turns',0)}, episodes: {counts.get('episodes',0)})")
                        if namespace == target:
                            namespace = "default"
                            _info("Switched back to namespace: [bright_cyan]default[/bright_cyan]")
                    except ValueError as e:
                        _err(str(e))
                else:
                    _info("Cancelled.")
            continue

        if user_input.startswith("/namespace "):
            new_ns = user_input[11:].strip().strip('"')
            if new_ns:
                namespace = new_ns
                _ok(f"Switched to namespace: [bright_cyan]{namespace}[/bright_cyan]")
            else:
                _err("Usage: /namespace <name>")
            continue

        if user_input.startswith("/store "):
            store(user_input[7:].strip())
            _ok("Memory stored.")
            continue

        if user_input == "/list":
            _print_memories_table(list_all(namespace=namespace))
            continue

        if user_input.startswith("/delete "):
            try:
                mid = int(user_input[8:].strip())
                if delete_memory(mid):
                    _ok(f"Memory [cyan]{mid}[/cyan] deleted.")
                else:
                    _err(f"No memory with ID {mid}.")
            except ValueError:
                _err("Usage: /delete <id>")
            continue

        if user_input.startswith("/search "):
            query = user_input[8:].strip()
            results = search_memories(query, namespace=namespace)
            _print_memories_table(results, title=f'Search: "{query}"')
            continue

        if user_input.startswith("/show "):
            try:
                mid = int(user_input[6:].strip())
                match = next((m for m in list_all() if m["id"] == mid), None)
                if match:
                    _print_show(match)
                else:
                    _err(f"No memory with ID {mid}.")
            except ValueError:
                _err("Usage: /show <id>")
            continue

        if user_input == "/consolidate":
            _info("Consolidating memories…")
            result = consolidate()
            _ok(f"[cyan]{result['before']}[/cyan] memories → [cyan]{result['after']}[/cyan]  (archived {result['archived']})")
            continue

        if user_input == "/stats":
            _print_stats(get_stats())
            continue

        if user_input == "/clear":
            clear_all()
            _ok("All memories cleared.")
            continue

        from rich.markdown import Markdown
        response = ask(user_input, namespace=namespace)
        console.print(Rule(style="cyan"))
        console.print(Markdown(response))
        console.print(Rule(style="cyan"))

    return 0


# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def _cmd_ask(args: argparse.Namespace) -> int:
    from rich.markdown import Markdown
    response = ask(_join_parts(args.query), namespace=args.namespace)
    console.print()
    console.print(Rule(style="cyan"))
    console.print(Markdown(response))
    console.print(Rule(style="cyan"))
    return 0


def _cmd_store(args: argparse.Namespace) -> int:
    store(_join_parts(args.content))
    _ok("Memory stored.")
    return 0


def _cmd_list(args: argparse.Namespace) -> int:
    since = getattr(args, "since", None)
    before = getattr(args, "before", None)
    namespace = getattr(args, "namespace", "default")
    memories = list_all(since=since, before=before, namespace=namespace)
    label_parts = []
    if since:
        label_parts.append(f"since {since}")
    if before:
        label_parts.append(f"before {before}")
    title = "  ".join(label_parts) if label_parts else None
    _print_memories_table(memories, title=title)
    return 0


def _cmd_show(args: argparse.Namespace) -> int:
    match = next((m for m in list_all() if m["id"] == args.id), None)
    if match:
        _print_show(match)
    else:
        _err(f"No memory with ID {args.id}.")
    return 0


def _cmd_delete(args: argparse.Namespace) -> int:
    if delete_memory(args.id):
        _ok(f"Memory [cyan]{args.id}[/cyan] deleted.")
    else:
        _err(f"No memory with ID {args.id}.")
    return 0


def _cmd_search(args: argparse.Namespace) -> int:
    since = getattr(args, "since", None)
    before = getattr(args, "before", None)
    query = _join_parts(args.query)
    results = search_memories(query, top_k=args.top, since=since, before=before)
    _print_memories_table(results, title=f'Search: "{query}"')
    return 0


def _cmd_prune(args: argparse.Namespace) -> int:
    count = prune_expired(dry_run=args.dry_run)
    noun = "memory" if count == 1 else "memories"
    if args.dry_run:
        _warn(f"[bright_cyan]{count}[/bright_cyan] expired {noun} found  [cyan](--dry-run, no changes made)[/cyan]")
    elif count == 0:
        _info("Nothing to prune — no expired memories found.")
    else:
        _ok(f"Pruned [cyan]{count}[/cyan] expired {noun} → archived.")
    return 0


def _cmd_ingest(args: argparse.Namespace) -> int:
    from .file_ingest import ingest_file
    from rich.progress import Progress, BarColumn, TextColumn, TaskProgressColumn, TimeRemainingColumn

    _info(f"Ingesting [bright_cyan]{args.file}[/bright_cyan]")
    console.print()

    try:
        with Progress(
            TextColumn("  [cyan]Progress[/cyan]"),
            BarColumn(bar_width=32, complete_style="bright_cyan", finished_style="bright_green"),
            TaskProgressColumn(),
            TextColumn("[cyan]{task.completed}/{task.total} chunks[/cyan]"),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("ingest", total=None)

            def on_progress(current: int, total: int) -> None:
                progress.update(task, completed=current, total=total)

            stats = ingest_file(args.file, on_progress=on_progress)

    except (FileNotFoundError, ValueError) as e:
        _err(str(e))
        return 1

    console.print()
    _ok(f"extracted  [bright_cyan]{stats['extracted']}[/bright_cyan]")
    _ok(f"inserted   [bright_cyan]{stats['inserted']}[/bright_cyan]")
    _ok(f"updated    [bright_cyan]{stats['updated']}[/bright_cyan]")
    if stats["skipped"]:
        _warn(f"skipped    [bright_yellow]{stats['skipped']}[/bright_yellow]")
    else:
        _info(f"skipped    [cyan]{stats['skipped']}[/cyan]")
    console.print()
    return 0


def _cmd_stats(_args: argparse.Namespace) -> int:
    _print_stats(get_stats())
    return 0


def _cmd_consolidate(_args: argparse.Namespace) -> int:
    _info("Consolidating memories…")
    result = consolidate()
    _ok(f"[cyan]{result['before']}[/cyan] memories → [cyan]{result['after']}[/cyan]  [dim](archived {result['archived']})[/dim]")
    return 0


def _cmd_clear(args: argparse.Namespace) -> int:
    if not args.yes:
        confirm = console.input("  [bold bright_red]Delete all memories?[/bold bright_red] [bright_white][y/N][/bright_white]: ").strip().lower()
        if confirm not in {"y", "yes"}:
            _info("Cancelled.")
            return 0
    clear_all()
    _ok("All memories cleared.")
    return 0


def _cmd_mcp(args: argparse.Namespace) -> int:
    from .mcp_server import run_sse, run_stdio
    if args.sse:
        _info(f"Starting Contexara MCP server (SSE) on port [bright_cyan]{args.port}[/bright_cyan]")
        run_sse(port=args.port)
    else:
        run_stdio()
    return 0


def _cmd_namespace(args: argparse.Namespace) -> int:
    if args.ns_action == "list" or args.ns_action is None:
        nss = list_namespaces()
        if not nss:
            _info("No namespaces registered yet.")
        else:
            for ns in nss:
                _info(f"[bright_cyan]{ns['name']}[/bright_cyan]  [bright_white]{ns['created_at'][:10]}[/bright_white]")
        return 0

    if args.ns_action == "create":
        try:
            created = create_namespace(args.name)
            if created:
                _ok(f"Namespace [bright_cyan]{args.name}[/bright_cyan] created.")
            else:
                _warn(f"Namespace [bright_cyan]{args.name}[/bright_cyan] already exists.")
        except ValueError as e:
            _err(str(e))
            return 1
        return 0

    if args.ns_action == "remove":
        name = args.name
        if name == "default":
            _err("Cannot remove the 'default' namespace.")
            return 1
        if not args.yes:
            confirm = console.input(f"  [bright_red]Delete namespace '{name}' and all its data?[/bright_red] [bright_white](y/N)[/bright_white]: ").strip().lower()
            if confirm not in {"y", "yes"}:
                _info("Cancelled.")
                return 0
        try:
            counts = remove_namespace(name)
            _ok(f"Removed namespace [bright_cyan]{name}[/bright_cyan]  (memories: {counts.get('memories',0)}, sessions: {counts.get('active_sessions',0)}, turns: {counts.get('raw_turns',0)}, episodes: {counts.get('episodes',0)})")
        except ValueError as e:
            _err(str(e))
            return 1
        return 0

    return 0


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 0

    # Always load saved config first
    load_config()

    # Auto-trigger setup if creds missing (except for setup command itself)
    if args.command != "setup" and not is_configured():
        console.print()
        console.print("  [bright_cyan]·[/bright_cyan]  No credentials found. Let's get you set up first.")
        run_setup()
        if not is_configured():
            return 1

    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
