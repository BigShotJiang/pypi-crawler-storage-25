"""Module entrypoint for `python -m contexara`."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
