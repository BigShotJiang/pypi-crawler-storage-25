from __future__ import annotations

import hashlib
import json as _json
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from contexara.embedder import cosine_similarity, deserialize, embed, serialize

DB_PATH = Path("database/memory.db")

# Memories older than this and over budget get compressed, not deleted.
_MEMORY_BUDGET = 500
_COMPRESSION_AGE_DAYS = 14


def _get_connection():
    """Create DB connection and ensure directory exists."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _initialize_db():
    """Create table if it doesn't exist and migrate V1 schema forward."""
    conn = _get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        kind TEXT NOT NULL DEFAULT 'note',
        importance INTEGER NOT NULL DEFAULT 1,
        updated_at TIMESTAMP,
        expires_at TIMESTAMP,
        fingerprint TEXT,
        embedding BLOB,
        source TEXT NOT NULL DEFAULT 'raw',
        compression_level INTEGER NOT NULL DEFAULT 0
    )
    """)

    _ensure_column(cursor, "memories", "kind", "TEXT NOT NULL DEFAULT 'note'")
    _ensure_column(cursor, "memories", "importance", "INTEGER NOT NULL DEFAULT 1")
    _ensure_column(cursor, "memories", "updated_at", "TIMESTAMP")
    _ensure_column(cursor, "memories", "expires_at", "TIMESTAMP")
    _ensure_column(cursor, "memories", "fingerprint", "TEXT")
    _ensure_column(cursor, "memories", "embedding", "BLOB")
    _ensure_column(cursor, "memories", "source", "TEXT NOT NULL DEFAULT 'raw'")
    _ensure_column(cursor, "memories", "compression_level", "INTEGER NOT NULL DEFAULT 0")
    _ensure_column(cursor, "memories", "namespace", "TEXT NOT NULL DEFAULT 'default'")
    cursor.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_memories_fingerprint ON memories(fingerprint)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_memories_ns ON memories(namespace)"
    )

    # Archive table — compressed/consolidated memories are moved here, never deleted.
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS memories_archive (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        original_ids TEXT,
        content TEXT NOT NULL,
        kind TEXT NOT NULL DEFAULT 'note',
        importance INTEGER NOT NULL DEFAULT 1,
        archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        reason TEXT
    )
    """)

    conn.commit()
    _backfill_embeddings(conn)
    conn.close()


def _expire_stale(conn: sqlite3.Connection) -> int:
    """Archive memories whose expires_at has passed. Returns count archived."""
    cursor = conn.cursor()
    now = _utc_now_iso()
    cursor.execute(
        "SELECT id, content, kind, importance FROM memories WHERE expires_at IS NOT NULL AND expires_at < ?",
        (now,),
    )
    expired = cursor.fetchall()
    if not expired:
        return 0
    for row_id, content, kind, importance in expired:
        cursor.execute(
            """
            INSERT INTO memories_archive (original_ids, content, kind, importance, archived_at, reason)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (str(row_id), content, kind, importance, now, "ttl_expired"),
        )
    ids = [r[0] for r in expired]
    cursor.execute(
        "DELETE FROM memories WHERE id IN ({})".format(",".join("?" * len(ids))),
        ids,
    )
    conn.commit()
    return len(expired)


def _backfill_embeddings(conn: sqlite3.Connection):
    """Embed any memories that were stored before embeddings were introduced."""
    cursor = conn.cursor()
    cursor.execute("SELECT id, content FROM memories WHERE embedding IS NULL")
    rows = cursor.fetchall()
    for row_id, content in rows:
        blob = serialize(embed(content))
        cursor.execute("UPDATE memories SET embedding = ? WHERE id = ?", (blob, row_id))
    if rows:
        conn.commit()


def _ensure_column(cursor: sqlite3.Cursor, table: str, column: str, column_type: str):
    cursor.execute(f"PRAGMA table_info({table})")
    columns = {row[1] for row in cursor.fetchall()}
    if column not in columns:
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_type}")


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_for_fingerprint(content: str) -> str:
    tokens = re.findall(r"[a-z0-9]+", content.lower())
    return " ".join(tokens)


_SEMANTIC_DEDUP_THRESHOLD_SAME_KIND = 0.92
_SEMANTIC_DEDUP_THRESHOLD_CROSS_KIND = 0.88


def _find_semantic_duplicate(cursor: sqlite3.Cursor, new_vector, kind: str, namespace: str = "default") -> int | None:
    """
    Return the id of an existing memory that is semantically near-identical, or None.

    Same-kind threshold: 0.92 (tighter — allows related but distinct facts of the same type)
    Cross-kind threshold: 0.88 (catches the same fact stored under different kinds)
    """
    cursor.execute("SELECT id, kind, embedding FROM memories WHERE embedding IS NOT NULL AND namespace = ?", (namespace,))
    for row_id, row_kind, blob in cursor.fetchall():
        sim = cosine_similarity(new_vector, deserialize(blob))
        threshold = (
            _SEMANTIC_DEDUP_THRESHOLD_SAME_KIND
            if row_kind == kind
            else _SEMANTIC_DEDUP_THRESHOLD_CROSS_KIND
        )
        if sim >= threshold:
            return row_id
    return None


def _archive_memories(
    conn: sqlite3.Connection,
    ids: list[int],
    kind: str,
    importance: int,
    reason: str,
) -> None:
    """Move a group of memories to archive, replacing them with one compressed entry."""
    cursor = conn.cursor()

    # Archive each original
    cursor.execute(
        "SELECT id, content FROM memories WHERE id IN ({})".format(
            ",".join("?" * len(ids))
        ),
        ids,
    )
    for row_id, content in cursor.fetchall():
        cursor.execute(
            """
            INSERT INTO memories_archive (original_ids, content, kind, importance, archived_at, reason)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (str(row_id), content, kind, importance, _utc_now_iso(), reason),
        )

    # Delete originals from active table
    cursor.execute(
        "DELETE FROM memories WHERE id IN ({})".format(",".join("?" * len(ids))),
        ids,
    )


def _call_compression_llm(prompt: str) -> str | None:
    """Call Bedrock with a compression prompt. Returns raw text or None on failure."""
    try:
        from contexara.llm import BedrockConfig, _get_client
        config = BedrockConfig.from_env()
        client = _get_client(config.region)
        payload = {
            "anthropic_version": "bedrock-2023-05-31",
            "messages": [{"role": "user", "content": [{"type": "text", "text": prompt}]}],
            "max_tokens": 2048,
            "temperature": 0.0,
        }
        response = client.invoke_model(
            modelId=config.model_id,
            body=_json.dumps(payload),
            contentType="application/json",
            accept="application/json",
        )
        raw = _json.loads(response["body"].read())["content"][0]["text"].strip()
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw).strip()
        return raw
    except Exception:
        return None


_COMPRESSION_SIMILARITY_THRESHOLD = 0.75


def _validate_compression(originals: list[str], compressed_items: list[dict]) -> bool:
    """
    Reject compression if the compressed centroid drifts too far from the originals centroid.
    Threshold 0.60 — low enough to allow real compression, high enough to catch hallucinations.
    """
    if not originals or not compressed_items:
        return False
    try:
        import numpy as np
        orig_vecs = [embed(t) for t in originals]
        orig_centroid = np.mean(orig_vecs, axis=0).astype("float32")

        comp_texts = [str(item.get("content", "")) for item in compressed_items if item.get("content")]
        if not comp_texts:
            return False
        comp_vecs = [embed(t) for t in comp_texts]
        comp_centroid = np.mean(comp_vecs, axis=0).astype("float32")

        sim = cosine_similarity(orig_centroid, comp_centroid)
        return sim >= _COMPRESSION_SIMILARITY_THRESHOLD
    except Exception:
        return False


def _build_fingerprint(content: str, kind: str) -> str:
    normalized = _normalize_for_fingerprint(content)
    raw = f"{kind.strip().lower()}::{normalized}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def store(content: str):
    """
    Store a memory string into the database.
    """
    if not content or not content.strip():
        raise ValueError("Memory content cannot be empty")

    _initialize_db()

    conn = _get_connection()
    cursor = conn.cursor()

    now = _utc_now_iso()
    embedding_blob = serialize(embed(content.strip()))
    cursor.execute(
        """
        INSERT INTO memories (content, kind, importance, created_at, updated_at, expires_at, fingerprint, embedding, source)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            content.strip(),
            "note",
            1,
            now,
            now,
            None,
            None,
            embedding_blob,
            "raw",
        ),
    )

    conn.commit()
    conn.close()


def upsert_memory(
    content: str,
    kind: str,
    importance: int = 1,
    ttl_days: int | None = None,
    namespace: str = "default",
) -> str:
    """
    Insert new memory or refresh existing one based on fingerprint.

    Returns:
        str: One of {"inserted", "updated"}.
    """
    if not content or not content.strip():
        raise ValueError("Memory content cannot be empty")

    _initialize_db()

    normalized_content = content.strip()
    normalized_kind = kind.strip().lower() or "note"
    bounded_importance = max(1, min(5, int(importance)))
    fingerprint = _build_fingerprint(normalized_content, normalized_kind)

    now = _utc_now_iso()
    expires_at = (
        (datetime.now(timezone.utc) + timedelta(days=ttl_days)).isoformat()
        if ttl_days and ttl_days > 0
        else None
    )

    embedding_blob = serialize(embed(normalized_content))

    conn = _get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT id, importance FROM memories WHERE fingerprint = ? AND namespace = ?",
        (fingerprint, namespace),
    )
    existing = cursor.fetchone()

    # Semantic dedup: catch near-duplicates that differ in wording but not meaning
    if not existing:
        new_vector = deserialize(embedding_blob)
        sem_dup_id = _find_semantic_duplicate(cursor, new_vector, normalized_kind, namespace=namespace)
        if sem_dup_id is not None:
            existing = (sem_dup_id, bounded_importance)

    if existing:
        current_importance = int(existing[1]) if existing[1] is not None else 1
        new_importance = max(current_importance, bounded_importance)
        cursor.execute(
            """
            UPDATE memories
            SET content = ?, kind = ?, importance = ?, updated_at = ?, expires_at = ?, embedding = ?
            WHERE id = ?
            """,
            (normalized_content, normalized_kind, new_importance, now, expires_at, embedding_blob, existing[0]),
        )
        action = "updated"
    else:
        cursor.execute(
            """
            INSERT INTO memories (content, kind, importance, created_at, updated_at, expires_at, fingerprint, embedding, source, namespace)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (normalized_content, normalized_kind, bounded_importance, now, now, expires_at, fingerprint, embedding_blob, "raw", namespace),
        )
        action = "inserted"

    conn.commit()
    conn.close()

    # Auto-compress old memories if budget exceeded (runs async-safe after insert)
    if action == "inserted":
        try:
            compress_old_memories()
        except Exception:
            pass
        try:
            conn2 = _get_connection()
            _expire_stale(conn2)
            conn2.close()
        except Exception:
            pass

    return action


def list_all(since: str | None = None, before: str | None = None, namespace: str = "default"):
    """
    Return all stored memories, optionally filtered by date range and namespace.
    """
    _initialize_db()

    conn = _get_connection()
    cursor = conn.cursor()

    conditions: list[str] = ["namespace = ?"]
    params: list = [namespace]
    if since:
        conditions.append("created_at >= ?")
        params.append(since)
    if before:
        conditions.append("created_at <= ?")
        params.append(before + "T23:59:59")

    where = "WHERE " + " AND ".join(conditions)
    cursor.execute(
        f"""
        SELECT id, content, created_at, kind, importance, updated_at, expires_at, embedding, source, compression_level
        FROM memories
        {where}
        ORDER BY created_at DESC
        """,
        params,
    )
    rows = cursor.fetchall()

    conn.close()

    return [
        {
            "id": row[0],
            "content": row[1],
            "created_at": row[2],
            "kind": row[3],
            "importance": row[4],
            "updated_at": row[5],
            "expires_at": row[6],
            "embedding": row[7],
            "source": row[8],
            "compression_level": row[9],
        }
        for row in rows
    ]


def prune_expired(dry_run: bool = False) -> int:
    """
    Archive all memories whose TTL has expired.

    Args:
        dry_run: If True, return count without modifying the DB.
    Returns:
        Number of memories pruned (or that would be pruned).
    """
    _initialize_db()
    conn = _get_connection()
    now = _utc_now_iso()
    if dry_run:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT COUNT(*) FROM memories WHERE expires_at IS NOT NULL AND expires_at < ?",
            (now,),
        )
        count = cursor.fetchone()[0]
        conn.close()
        return count
    count = _expire_stale(conn)
    conn.close()
    return count


def delete_memory(memory_id: int) -> bool:
    """Delete a single memory by id. Returns True if a row was deleted."""
    _initialize_db()
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def search_memories(
    query: str,
    top_k: int = 5,
    since: str | None = None,
    before: str | None = None,
    namespace: str = "default",
) -> list[dict]:
    """
    Semantic search over stored memories. Returns ranked list.
    """
    from contexara.retrieve import retrieve
    contents = retrieve(query, top_k=top_k, namespace=namespace)
    if not contents:
        return []
    _initialize_db()
    conn = _get_connection()
    cursor = conn.cursor()
    results = []
    for content in contents:
        conditions = ["content = ?", "namespace = ?"]
        params: list = [content, namespace]
        if since:
            conditions.append("created_at >= ?")
            params.append(since)
        if before:
            conditions.append("created_at <= ?")
            params.append(before + "T23:59:59")
        where = " AND ".join(conditions)
        cursor.execute(
            f"SELECT id, content, kind, importance, created_at, source FROM memories WHERE {where}",
            params,
        )
        row = cursor.fetchone()
        if row:
            results.append({"id": row[0], "content": row[1], "kind": row[2], "importance": row[3], "created_at": row[4], "source": row[5]})
    conn.close()
    return results


def get_stats() -> dict:
    """Return summary statistics about stored memories."""
    _initialize_db()
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM memories")
    total = cursor.fetchone()[0]
    cursor.execute("SELECT kind, COUNT(*) FROM memories GROUP BY kind ORDER BY COUNT(*) DESC")
    by_kind = {row[0]: row[1] for row in cursor.fetchall()}
    cursor.execute("SELECT source, COUNT(*) FROM memories GROUP BY source")
    by_source = {row[0]: row[1] for row in cursor.fetchall()}
    cursor.execute("SELECT MIN(created_at), MAX(created_at) FROM memories")
    row = cursor.fetchone()
    oldest, newest = row[0], row[1]
    # avg importance and avg age (days) per source
    cursor.execute("""
        SELECT source,
               ROUND(AVG(importance), 2),
               ROUND(AVG((julianday('now') - julianday(created_at))), 1)
        FROM memories GROUP BY source
    """)
    source_stats = {
        r[0]: {"avg_importance": r[1], "avg_age_days": r[2]}
        for r in cursor.fetchall()
    }
    conn.close()
    return {
        "total": total,
        "by_kind": by_kind,
        "by_source": by_source,
        "source_stats": source_stats,
        "oldest": oldest,
        "newest": newest,
    }


def consolidate() -> dict[str, int]:
    """
    Compress all active memories into sharp facts, archiving originals.

    Originals are moved to memories_archive (never deleted).
    Active table is replaced with the compressed set.
    Returns {"before": N, "after": M, "archived": N}.
    """
    _initialize_db()
    memories = list_all()
    if len(memories) < 2:
        return {"before": len(memories), "after": len(memories), "archived": 0}

    memory_lines = "\n".join(
        f"{i+1}. [id={m['id']}, {m['kind']}, importance={m['importance']}] {m['content']}"
        for i, m in enumerate(memories)
    )

    prompt = f"""\
You are a memory compression engine. Output ONLY a raw JSON array — no markdown, no prose.

Compress the memories below into the sharpest possible facts.
Rules:
- Merge overlapping or redundant memories into one precise statement.
- Preserve ALL distinct facts — do not lose any unique information.
- Each output item: content (string), kind (profile|preference|task|constraint|note), importance (1-5).
- Target: reduce count by ~60-80% while retaining 100% of unique information.

Memories:
{memory_lines}

Output the compressed list as a JSON array.
"""

    raw = _call_compression_llm(prompt)
    if not raw:
        return {"before": len(memories), "after": len(memories), "archived": 0}

    try:
        compressed = _json.loads(raw)
        if not isinstance(compressed, list) or not compressed:
            return {"before": len(memories), "after": len(memories), "archived": 0}
    except Exception:
        return {"before": len(memories), "after": len(memories), "archived": 0}

    # Reject compression if semantic drift is too high (#8)
    original_texts = [m["content"] for m in memories]
    if not _validate_compression(original_texts, compressed):
        return {"before": len(memories), "after": len(memories), "archived": 0}

    all_ids = [m["id"] for m in memories]
    max_existing_level = max((m.get("compression_level") or 0) for m in memories)
    new_level = max_existing_level + 1

    conn = _get_connection()

    # Archive all originals grouped by kind
    by_kind: dict[str, list] = {}
    for m in memories:
        by_kind.setdefault(m["kind"], []).append(m)

    for kind, group in by_kind.items():
        ids = [m["id"] for m in group]
        _archive_memories(
            conn,
            ids=ids,
            kind=kind,
            importance=max(m["importance"] for m in group),
            reason="consolidate",
        )

    # Now insert the compressed set as new active memories
    cursor = conn.cursor()
    now = _utc_now_iso()
    for item in compressed:
        content = str(item.get("content", "")).strip()
        kind = str(item.get("kind", "note")).strip().lower()
        importance = max(1, min(5, int(item.get("importance", 1))))
        if not content:
            continue
        fingerprint = _build_fingerprint(content, kind)
        embedding_blob = serialize(embed(content))
        cursor.execute(
            """
            INSERT OR IGNORE INTO memories
                (content, kind, importance, created_at, updated_at, fingerprint, embedding, source, compression_level)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (content, kind, importance, now, now, fingerprint, embedding_blob, "compressed", new_level),
        )

    conn.commit()
    conn.close()
    return {"before": len(memories), "after": len(compressed), "archived": len(all_ids)}


def compress_old_memories() -> dict[str, int]:
    """
    Auto-compression triggered when total memories exceed budget.

    Only compresses memories older than _COMPRESSION_AGE_DAYS (14 days).
    Groups them by kind, compresses each group into sharp facts via LLM,
    archives originals. Recent memories are never touched.
    Returns {"checked": N, "compressed_groups": N, "archived": N}.
    """
    _initialize_db()
    conn = _get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM memories")
    total = cursor.fetchone()[0]

    if total <= _MEMORY_BUDGET:
        conn.close()
        return {"checked": total, "compressed_groups": 0, "archived": 0}

    cutoff = (datetime.now(timezone.utc) - timedelta(days=_COMPRESSION_AGE_DAYS)).isoformat()
    cursor.execute(
        """
        SELECT id, content, kind, importance, compression_level, created_at FROM memories
        WHERE created_at < ?
        ORDER BY kind, created_at ASC
        """,
        (cutoff,),
    )
    old_rows = cursor.fetchall()
    conn.close()

    if not old_rows:
        return {"checked": total, "compressed_groups": 0, "archived": 0}

    # Group by (kind, 30-day time bucket) to keep compression chronologically coherent
    def _time_bucket(created_at_str: str) -> int:
        try:
            dt = datetime.fromisoformat(created_at_str)
        except Exception:
            return 0
        epoch = datetime(2024, 1, 1, tzinfo=timezone.utc)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return (dt - epoch).days // 30

    by_bucket: dict[tuple[str, int], list[dict]] = {}
    for row_id, content, kind, importance, comp_level, created_at in old_rows:
        bucket = (kind, _time_bucket(created_at))
        by_bucket.setdefault(bucket, []).append(
            {"id": row_id, "content": content, "kind": kind, "importance": importance, "compression_level": comp_level or 0}
        )

    compressed_groups = 0
    total_archived = 0

    for (kind, _bucket), group in by_bucket.items():
        if len(group) < 2:
            continue

        memory_lines = "\n".join(
            f"{i+1}. {m['content']}" for i, m in enumerate(group)
        )
        prompt = f"""\
You are a memory compression engine. Output ONLY a raw JSON array — no markdown, no prose.

Compress these {kind} memories into the fewest sharp facts possible.
Preserve ALL distinct information. Merge redundant ones.
Each item: content (string), kind ("{kind}"), importance (1-5).

Memories:
{memory_lines}

Output compressed JSON array.
"""
        raw = _call_compression_llm(prompt)
        if not raw:
            continue

        try:
            compressed = _json.loads(raw)
            if not isinstance(compressed, list) or not compressed:
                continue
        except Exception:
            continue

        # Reject if semantic drift too high (#8)
        original_texts = [m["content"] for m in group]
        if not _validate_compression(original_texts, compressed):
            continue

        conn = _get_connection()
        ids = [m["id"] for m in group]
        max_importance = max(m["importance"] for m in group)
        new_level = max(m["compression_level"] for m in group) + 1

        # Archive originals, insert compressed
        _archive_memories(
            conn,
            ids=ids,
            kind=kind,
            importance=max_importance,
            reason="budget_compression",
        )

        cursor = conn.cursor()
        now = _utc_now_iso()
        for item in compressed:
            content = str(item.get("content", "")).strip()
            if not content:
                continue
            item_kind = str(item.get("kind", kind)).strip().lower()
            item_importance = max(1, min(5, int(item.get("importance", max_importance))))
            fingerprint = _build_fingerprint(content, item_kind)
            embedding_blob = serialize(embed(content))
            cursor.execute(
                """
                INSERT OR IGNORE INTO memories
                    (content, kind, importance, created_at, updated_at, fingerprint, embedding, source, compression_level)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (content, item_kind, item_importance, now, now, fingerprint, embedding_blob, "compressed", new_level),
            )

        conn.commit()
        conn.close()
        compressed_groups += 1
        total_archived += len(ids)

    return {"checked": total, "compressed_groups": compressed_groups, "archived": total_archived}


def clear_all():
    """
    Delete all memories.
    """
    _initialize_db()

    conn = _get_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM memories")

    conn.commit()
    conn.close()
