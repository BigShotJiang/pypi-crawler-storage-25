"""Session management for Contexara — Tier 1 (raw turns) and Tier 2 (episodes)."""
from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path("database/active_state.db")
_SESSION_TIMEOUT_MINUTES = 60
_LAST_N_TURNS = 20
_DEFAULT_NAMESPACE = "default"


# ── DB bootstrap ─────────────────────────────────────────────────────────────

def _get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_column(cursor: sqlite3.Cursor, table: str, column: str, column_type: str) -> None:
    cursor.execute(f"PRAGMA table_info({table})")
    columns = {row[1] for row in cursor.fetchall()}
    if column not in columns:
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_type}")


def initialize_session_db() -> None:
    """Create all session-related tables if they don't exist."""
    conn = _get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS namespaces (
        name TEXT PRIMARY KEY,
        created_at TEXT NOT NULL,
        description TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS active_sessions (
        session_id TEXT PRIMARY KEY,
        started_at TEXT NOT NULL,
        last_action_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'open',
        namespace TEXT NOT NULL DEFAULT 'default'
    )
    """)
    _ensure_column(cursor, "active_sessions", "namespace", "TEXT NOT NULL DEFAULT 'default'")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sessions_ns ON active_sessions(namespace)")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS raw_turns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        namespace TEXT NOT NULL DEFAULT 'default',
        FOREIGN KEY (session_id) REFERENCES active_sessions(session_id)
    )
    """)
    _ensure_column(cursor, "raw_turns", "namespace", "TEXT NOT NULL DEFAULT 'default'")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_raw_session ON raw_turns(session_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_raw_created ON raw_turns(created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_raw_ns ON raw_turns(namespace)")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS episodes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        summary TEXT NOT NULL,
        started_at TEXT NOT NULL,
        ended_at TEXT NOT NULL,
        embedding BLOB,
        created_at TEXT NOT NULL,
        namespace TEXT NOT NULL DEFAULT 'default'
    )
    """)
    _ensure_column(cursor, "episodes", "namespace", "TEXT NOT NULL DEFAULT 'default'")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_episodes_started ON episodes(started_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_episodes_ended ON episodes(ended_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_episodes_ns ON episodes(namespace)")

    conn.commit()
    conn.close()


# ── Time helpers ──────────────────────────────────────────────────────────────

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _minutes_since(iso_ts: str) -> float:
    then = datetime.fromisoformat(iso_ts)
    if then.tzinfo is None:
        then = then.replace(tzinfo=timezone.utc)
    delta = datetime.now(timezone.utc) - then
    return delta.total_seconds() / 60


# ── Namespace registry ────────────────────────────────────────────────────────

def _register_namespace(namespace: str) -> None:
    """Register a namespace on first use — silent no-op if already exists."""
    conn = _get_connection()
    conn.execute(
        "INSERT OR IGNORE INTO namespaces (name, created_at) VALUES (?, ?)",
        (namespace, _utc_now()),
    )
    conn.commit()
    conn.close()


def create_namespace(namespace: str) -> bool:
    """
    Explicitly create a namespace.
    Returns True if created, False if already existed.
    Raises ValueError if name is empty or contains spaces.
    """
    if not namespace or not namespace.strip():
        raise ValueError("Namespace name cannot be empty.")
    if " " in namespace:
        raise ValueError("Namespace name cannot contain spaces.")
    initialize_session_db()
    conn = _get_connection()
    cursor = conn.execute(
        "INSERT OR IGNORE INTO namespaces (name, created_at) VALUES (?, ?)",
        (namespace.strip(), _utc_now()),
    )
    created = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return created


def list_namespaces() -> list[dict]:
    """Return all registered namespaces ordered by creation time."""
    initialize_session_db()
    conn = _get_connection()
    rows = conn.execute(
        "SELECT name, created_at, description FROM namespaces ORDER BY created_at ASC"
    ).fetchall()
    conn.close()
    return [{"name": r["name"], "created_at": r["created_at"], "description": r["description"]} for r in rows]


def remove_namespace(namespace: str) -> dict:
    """
    Delete a namespace and all its data from active_state.db.
    Returns counts of deleted rows per table.
    Raises ValueError if namespace is 'default'.
    """
    if namespace == _DEFAULT_NAMESPACE:
        raise ValueError("Cannot remove the 'default' namespace.")

    initialize_session_db()
    conn = _get_connection()

    counts = {}
    for table, col in [("raw_turns", "namespace"), ("episodes", "namespace"), ("active_sessions", "namespace")]:
        cursor = conn.execute(f"DELETE FROM {table} WHERE {col} = ?", (namespace,))
        counts[table] = cursor.rowcount

    cursor = conn.execute("DELETE FROM namespaces WHERE name = ?", (namespace,))
    counts["namespaces"] = cursor.rowcount

    conn.commit()
    conn.close()

    # Also remove from memories.db
    try:
        from .store import _get_connection as _store_conn, _initialize_db
        _initialize_db()
        sconn = _store_conn()
        cursor = sconn.execute("DELETE FROM memories WHERE namespace = ?", (namespace,))
        counts["memories"] = cursor.rowcount
        sconn.commit()
        sconn.close()
    except Exception:
        counts["memories"] = 0

    return counts


# ── Session detection ─────────────────────────────────────────────────────────

def get_or_create_session(namespace: str = _DEFAULT_NAMESPACE) -> str:
    """
    JIT session detection — O(1) check scoped to namespace.
    If last action was >60 min ago, close old session and start a new one.
    Returns the active session_id.
    """
    initialize_session_db()
    _register_namespace(namespace)
    conn = _get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT session_id, last_action_at FROM active_sessions WHERE status = 'open' AND namespace = ? ORDER BY last_action_at DESC LIMIT 1",
        (namespace,),
    )
    row = cursor.fetchone()

    if row:
        session_id = row["session_id"]
        last_action_at = row["last_action_at"]
        minutes_elapsed = _minutes_since(last_action_at)

        if minutes_elapsed > _SESSION_TIMEOUT_MINUTES:
            cursor.execute(
                "UPDATE active_sessions SET status = 'pending', last_action_at = ? WHERE session_id = ?",
                (_utc_now(), session_id),
            )
            conn.commit()
            conn.close()
            _trigger_crystallization(session_id)
            return _new_session(namespace)
        else:
            cursor.execute(
                "UPDATE active_sessions SET last_action_at = ? WHERE session_id = ?",
                (_utc_now(), session_id),
            )
            conn.commit()
            conn.close()
            return session_id
    else:
        conn.close()
        return _new_session(namespace)


def _new_session(namespace: str = _DEFAULT_NAMESPACE) -> str:
    """Create a new session and return its session_id."""
    session_id = str(uuid.uuid4())
    now = _utc_now()
    conn = _get_connection()
    conn.execute(
        "INSERT INTO active_sessions (session_id, started_at, last_action_at, status, namespace) VALUES (?, ?, ?, 'open', ?)",
        (session_id, now, now, namespace),
    )
    conn.commit()
    conn.close()
    return session_id


# ── Raw turn storage ──────────────────────────────────────────────────────────

_LLM_ERROR_PREFIXES = ("[LLM ERROR]", "I don't have records", "I don't have information")


def save_turn(session_id: str, role: str, content: str, namespace: str = _DEFAULT_NAMESPACE) -> None:
    """Save a single raw turn (user or assistant) to raw_turns."""
    if not content or not content.strip():
        return
    if role == "assistant" and any(content.strip().startswith(p) for p in _LLM_ERROR_PREFIXES):
        return
    conn = _get_connection()
    conn.execute(
        "INSERT INTO raw_turns (session_id, role, content, created_at, namespace) VALUES (?, ?, ?, ?, ?)",
        (session_id, role, content.strip(), _utc_now(), namespace),
    )
    conn.execute(
        "UPDATE active_sessions SET last_action_at = ? WHERE session_id = ?",
        (_utc_now(), session_id),
    )
    conn.commit()
    conn.close()


def get_recent_turns(session_id: str, n: int = _LAST_N_TURNS) -> list[dict]:
    """Return the last N turns for the given session, oldest first."""
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT role, content, created_at FROM raw_turns
        WHERE session_id = ?
        ORDER BY created_at DESC LIMIT ?
        """,
        (session_id, n),
    )
    rows = cursor.fetchall()
    conn.close()
    return [{"role": r["role"], "content": r["content"], "created_at": r["created_at"]} for r in reversed(rows)]


# ── Episode retrieval ─────────────────────────────────────────────────────────

def get_last_episode(namespace: str = _DEFAULT_NAMESPACE) -> str | None:
    """Return the summary of the most recent crystallized episode for a namespace."""
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT summary FROM episodes WHERE namespace = ? ORDER BY created_at DESC LIMIT 1",
        (namespace,),
    )
    row = cursor.fetchone()
    conn.close()
    return row["summary"] if row else None


def retrieve_episodes_by_time(start: "datetime", end: "datetime", namespace: str = _DEFAULT_NAMESPACE) -> list[dict]:
    """Return episodes whose started_at falls within [start, end] for a namespace."""
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, session_id, summary, embedding, started_at, ended_at
        FROM episodes
        WHERE started_at >= ? AND started_at <= ? AND namespace = ?
        ORDER BY started_at DESC
        """,
        (start.isoformat(), end.isoformat(), namespace),
    )
    rows = cursor.fetchall()
    conn.close()
    return [
        {
            "id": r["id"],
            "session_id": r["session_id"],
            "summary": r["summary"],
            "embedding": r["embedding"],
            "started_at": r["started_at"],
            "ended_at": r["ended_at"],
        }
        for r in rows
    ]


def get_session_time_range(session_id: str) -> tuple[str, str] | None:
    """Return (started_at, last_action_at) for a session."""
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT started_at, last_action_at FROM active_sessions WHERE session_id = ?",
        (session_id,),
    )
    row = cursor.fetchone()
    conn.close()
    if row:
        return row["started_at"], row["last_action_at"]
    return None


def get_session_namespace(session_id: str) -> str:
    """Return the namespace for a given session_id."""
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT namespace FROM active_sessions WHERE session_id = ?",
        (session_id,),
    )
    row = cursor.fetchone()
    conn.close()
    return row["namespace"] if row else _DEFAULT_NAMESPACE


# ── Crystallization trigger ───────────────────────────────────────────────────

def _trigger_crystallization(session_id: str) -> None:
    """Spawn a detached background process to crystallize the session."""
    import subprocess
    import sys

    try:
        subprocess.Popen(
            [sys.executable, "-m", "contexara._crystallize", session_id],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def retry_pending_sessions(namespace: str = _DEFAULT_NAMESPACE) -> None:
    """Retry crystallization for sessions stuck in 'pending' for >5 min."""
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT session_id FROM active_sessions
        WHERE status = 'pending'
        AND namespace = ?
        AND last_action_at < datetime('now', '-5 minutes')
        """,
        (namespace,),
    )
    rows = cursor.fetchall()
    conn.close()
    for row in rows:
        _trigger_crystallization(row["session_id"])

