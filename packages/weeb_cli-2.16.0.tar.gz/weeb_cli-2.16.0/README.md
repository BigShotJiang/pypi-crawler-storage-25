<p align="center">
  <img src="https://8upload.com/image/a6cdd79fc5a25c99/wl-512x512.jpg" alt="Weeb CLI Logo" width="120">
</p>

<h1 align="center">Weeb CLI</h1>

<p align="center">
  <strong>No browser, no ads, no distractions. Just you and an unparalleled anime viewing experience.</strong>
</p>

<div align="center">
  <a href="README.md">English</a> | <a href="docs/md/tr/README.md">Türkçe</a> | <a href="docs/md/de/README.md">Deutsch</a> | <a href="docs/md/pl/README.md">Polski</a>
</div>
<br>

<p align="center">
  <a href="https://github.com/ewgsta/weeb-cli/releases"><img src="https://img.shields.io/github/v/release/ewgsta/weeb-cli?style=flat-square" alt="Release"></a>
  <a href="https://github.com/ewgsta/weeb-cli/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-GPL--3.0-blue?style=flat-square" alt="License"></a>
  <a href="https://github.com/ewgsta/weeb-cli/stargazers"><img src="https://img.shields.io/github/stars/ewgsta/weeb-cli?style=flat-square" alt="Stars"></a>
  <a href="https://github.com/ewgsta/weeb-cli/actions"><img src="https://img.shields.io/github/actions/workflow/status/ewgsta/weeb-cli/tests.yml?style=flat-square" alt="Tests"></a>
</p>

<p align="center">
  <a href="#installation">Installation</a> •
  <a href="#features">Features</a> •
  <a href="#usage">Usage</a> •
  <a href="#sources">Sources</a> •
  <a href="https://ewgsta.github.io/weeb-cli/">Documentation</a>
</p>

---

## Features

### Multiple Sources
- **Turkish**: Animecix, Turkanime, Anizle, Weeb
- **English**: HiAnime, AllAnime
- **German**: AniWorld
- **Polish**: Docchi

### Smart Streaming
- High-quality HLS/MP4 playback with MPV
- Resume from where you left off (timestamp-based)
- Watch history and statistics
- Completed (✓) and in-progress (●) episode markers

### Powerful Download System
- **Aria2** for multi-connection fast downloads
- **yt-dlp** for complex stream support
- Queue system with concurrent downloads
- Resume interrupted downloads
- Smart file naming (`Anime Name - S1E1.mp4`)

### Tracking & Sync
- **AniList** integration with OAuth
- **MyAnimeList** integration with OAuth
- **Kitsu** integration with email/password
- Automatic progress sync for online and offline viewing
- Offline queue for pending updates
- Smart anime title matching from filenames

### Local Library
- Auto-scan downloaded anime
- External drive support (USB, HDD)
- Offline anime indexing with automatic tracker sync
- Search across all sources
- **Recommended format**: `Anime Name - S1E1.mp4` for best tracker compatibility

### Additional Features
- SQLite database (fast and reliable)
- System notifications on download completion
- Discord RPC integration (show what you're watching on Discord)
- Search history
- Debug mode and logging
- Automatic update checks
- Non-interactive JSON API for scripts and AI agents
- Torznab server mode for Sonarr/*arr integration
- RESTful API server for web/mobile applications

---

## Installation

### PyPI (Universal)
```bash
pip install weeb-cli
```

### Arch Linux (AUR)
```bash
yay -S weeb-cli
```

### Portable
Download the appropriate file for your platform from [Releases](https://github.com/ewgsta/weeb-cli/releases).

### Developer Setup
```bash
git clone https://github.com/ewgsta/weeb-cli.git
cd weeb-cli
pip install -e .
```

---

## Usage

```bash
weeb-cli
```

### API Mode (Non-interactive)

For scripts, automation, and AI agents, weeb-cli provides JSON API commands that work headlessly without a database or TUI:

```bash
# List available providers
weeb-cli api providers

# Search for anime (returns IDs)
weeb-cli api search "Angel Beats" --provider hianime
# Returns: [{"id": "12345", "title": "Angel Beats!", ...}]

# List episodes (use ID from search)
weeb-cli api episodes 12345 --season 1 --provider hianime

# Get stream URLs for an episode
weeb-cli api streams 12345 --season 1 --episode 1 --provider hianime

# Get anime details
weeb-cli api details 12345 --provider hianime

# Download an episode
weeb-cli api download 12345 --season 1 --episode 1 --provider hianime --output ./downloads
```

**Provider Selection:**
All API commands support the `--provider` (or `-p`) option to select which anime source to use:
- Turkish: `animecix`, `turkanime`, `anizle`, `weeb`
- English: `hianime`, `allanime`
- German: `aniworld`
- Polish: `docchi`

Default provider is `animecix` if not specified. Use `weeb-cli api providers` to see all available providers with their language and region information.

All API commands output JSON to stdout.

### Python SDK (Programmatic Access)

For Python applications, weeb-cli provides a native SDK that doesn't require spawning processes:

```python
from weeb_cli import WeebSDK

# Initialize SDK
sdk = WeebSDK(default_provider="hianime")

# Search for anime
results = sdk.search("One Piece")
for anime in results:
    print(f"{anime.title} ({anime.year})")

# Get episodes
episodes = sdk.get_episodes(results[0].id, season=1)

# Get stream URLs
streams = sdk.get_streams(
    anime_id=results[0].id,
    episode_id=episodes[0].id
)

# Download episode
path = sdk.download_episode(
    anime_id=results[0].id,
    season=1,
    episode=1,
    output_dir="./downloads"
)
print(f"Downloaded to: {path}")
```

**SDK Features:**
- No subprocess overhead - direct Python API
- Type-safe with full type hints
- Automatic provider discovery
- Same caching as CLI mode
- Thread-safe operations
- Headless mode (no database/TUI dependencies)

See [SDK Documentation](https://ewgsta.github.io/weeb-cli/api/sdk/) for complete API reference.

### Sonarr/*arr Integration (Serve Mode)

weeb-cli can run as a Torznab-compatible server for Sonarr and other *arr applications:

```bash
pip install weeb-cli[serve]

weeb-cli serve --port 9876 \
  --watch-dir /downloads/watch \
  --completed-dir /downloads/completed \
  --sonarr-url http://sonarr:8989 \
  --sonarr-api-key YOUR_KEY
```

Then add `http://weeb-cli-host:9876` as a Torznab indexer in Sonarr with category 5070 (TV/Anime). The server includes a blackhole download worker that automatically processes grabbed episodes.

**Docker Support:**
```bash
docker-compose -f docs/docker-compose.torznab.yml up -d
```

See [Torznab Server Documentation](https://ewgsta.github.io/weeb-cli/cli/serve-mode/) for full details.

### RESTful API Server

For web/mobile applications and custom integrations, weeb-cli provides a RESTful API server:

```bash
pip install weeb-cli[serve-restful]

weeb-cli serve restful --port 8080 --cors
```

**API Endpoints:**
- `GET /health` - Health check
- `GET /api/providers` - List available providers
- `GET /api/search?q=naruto&provider=animecix` - Search anime
- `GET /api/anime/{id}?provider=animecix` - Get anime details
- `GET /api/anime/{id}/episodes?season=1` - List episodes
- `GET /api/anime/{id}/episodes/{ep_id}/streams` - Get stream URLs

All available providers are loaded automatically. Select which provider to use via the `provider` query parameter.

**Docker Support:**
```bash
docker-compose -f docs/docker-compose.restful.yml up -d
```

See [RESTful API Documentation](https://ewgsta.github.io/weeb-cli/cli/restful-api/) for full details.

#### Docker (Torznab)

```dockerfile
FROM python:3.13-slim
RUN apt-get update && apt-get install -y --no-install-recommends aria2 ffmpeg && rm -rf /var/lib/apt/lists/*
RUN pip install --no-cache-dir weeb-cli[serve] yt-dlp
EXPOSE 9876
CMD ["weeb-cli", "serve", "--port", "9876", "--watch-dir", "/downloads/watch", "--completed-dir", "/downloads/completed"]
```

### Keyboard Controls
| Key | Action |
|-----|--------|
| `↑` `↓` | Navigate menu |
| `Enter` | Select |
| `s` | Search Anime (Main menu) |
| `d` | Downloads (Main menu) |
| `w` | Watchlist (Main menu) |
| `c` | Settings (Main menu) |
| `q` | Exit (Main menu) |
| `Ctrl+C` | Go back / Exit |

**Note:** All shortcuts can be customized in Settings > Keyboard Shortcuts.

---

## Sources

| Source | Language |
|--------|----------|
| Animecix | Turkish |
| Turkanime | Turkish |
| Anizle | Turkish |
| Weeb | Turkish |
| HiAnime | English |
| AllAnime | English |
| AniWorld | German |
| Docchi | Polish |

---

## Configuration

Config location: `~/.weeb-cli/weeb.db` (SQLite)

### Available Settings

| Setting | Description | Default | Type |
|---------|-------------|---------|------|
| `language` | Interface language (tr/en/de/pl) | `null` (asks on first run) | string |
| `scraping_source` | Active anime source | `animecix` | string |
| `aria2_enabled` | Use Aria2 for downloads | `true` | boolean |
| `aria2_max_connections` | Max connections per download | `16` | integer |
| `ytdlp_enabled` | Use yt-dlp for HLS streams | `true` | boolean |
| `ytdlp_format` | yt-dlp format string | `bestvideo+bestaudio/best` | string |
| `max_concurrent_downloads` | Simultaneous downloads | `3` | integer |
| `download_dir` | Download folder path | `./weeb-downloads` | string |
| `download_max_retries` | Retry failed downloads | `3` | integer |
| `download_retry_delay` | Delay between retries (seconds) | `10` | integer |
| `show_description` | Show anime descriptions | `true` | boolean |
| `discord_rpc_enabled` | Discord Rich Presence | `false` | boolean |
| `shortcuts_enabled` | Keyboard shortcuts | `true` | boolean |
| `debug_mode` | Debug logging | `false` | boolean |

### Tracker Settings (stored separately)
- `anilist_token` - AniList OAuth token
- `anilist_user_id` - AniList user ID
- `mal_token` - MyAnimeList OAuth token
- `mal_refresh_token` - MAL refresh token
- `mal_username` - MAL username

### External Drives
Managed via Settings > External Drives menu. Each drive stores:
- Path (e.g., `D:\Anime`)
- Custom name/nickname
- Added timestamp

All settings can be modified through the interactive Settings menu.

---

## Roadmap

### Completed
- [x] Multiple source support (TR/EN/DE/PL)
- [x] MPV streaming
- [x] Watch history and progress tracking
- [x] Aria2/yt-dlp download integration
- [x] External drives and local library
- [x] SQLite database
- [x] Notification system
- [x] Debug mode
- [x] MAL/AniList integration
- [x] Database backup/restore
- [x] Keyboard shortcuts
- [x] Non-interactive API mode (JSON output)
- [x] Torznab server for Sonarr/*arr integration
- [x] RESTful API server for web/mobile apps


### Planned
- [ ] Anime recommendations
- [ ] Batch operations
- [ ] Watch statistics (graphs)
- [ ] Theme support
- [ ] Subtitle downloads
- [ ] Torrent support (nyaa.si)
- [ ] Watch party

---

## Project Structure

```
weeb-cli/
├── weeb_cli/                    # Main application package
│   ├── commands/                # CLI command handlers
│   │   ├── api.py               # Non-interactive JSON API commands
│   │   ├── downloads.py         # Download management commands
│   │   ├── search.py            # Anime search functionality
│   │   ├── serve.py             # Torznab server for *arr integration
│   │   ├── serve_restful.py     # RESTful API server
│   │   ├── settings.py          # Settings menu and configuration
│   │   ├── setup.py             # Initial setup wizard
│   │   └── watchlist.py         # Watch history and progress
│   │
│   ├── providers/               # Anime source integrations
│   │   ├── extractors/          # Video stream extractors
│   │   │   └── megacloud.py     # Megacloud extractor
│   │   ├── allanime.py          # AllAnime provider (EN)
│   │   ├── animecix.py          # Animecix provider (TR)
│   │   ├── anizle.py            # Anizle provider (TR)
│   │   ├── base.py              # Base provider interface
│   │   ├── hianime.py           # HiAnime provider (EN)
│   │   ├── registry.py          # Provider registration system
│   │   └── turkanime.py         # Turkanime provider (TR)
│   │
│   ├── services/                # Business logic layer
│   │   ├── cache.py             # File-based caching system
│   │   ├── database.py          # SQLite database manager
│   │   ├── dependency_manager.py # Auto-install FFmpeg, MPV, etc.
│   │   ├── details.py           # Anime details fetcher
│   │   ├── discord_rpc.py       # Discord Rich Presence
│   │   ├── downloader.py        # Queue-based download manager
│   │   ├── error_handler.py     # Global error handling
│   │   ├── headless_downloader.py # Headless download (no DB/TUI deps)
│   │   ├── local_library.py     # Local anime indexing
│   │   ├── logger.py            # Debug logging system
│   │   ├── notifier.py          # System notifications
│   │   ├── player.py            # MPV video player integration
│   │   ├── progress.py          # Watch progress tracking
│   │   ├── scraper.py           # Provider facade
│   │   ├── search.py            # Search service
│   │   ├── shortcuts.py         # Keyboard shortcuts manager
│   │   ├── tracker.py           # MAL/AniList integration
│   │   ├── updater.py           # Auto-update checker
│   │   ├── watch.py             # Streaming service
│   │   ├── _base.py             # Base service class
│   │   └── _tracker_base.py     # Base tracker interface
│   │
│   ├── ui/                      # Terminal UI components
│   │   ├── header.py            # Header display
│   │   ├── menu.py              # Main menu
│   │   └── prompt.py            # Custom prompts
│   │
│   ├── utils/                   # Utility functions
│   │   └── sanitizer.py         # Filename/path sanitization
│   │
│   ├── locales/                 # Internationalization
│   │   ├── de.json              # German translations
│   │   ├── en.json              # English translations
│   │   ├── pl.json              # Polish translations
│   │   └── tr.json              # Turkish translations
│   │
│   ├── templates/               # HTML templates
│   │   ├── anilist_error.html   # AniList OAuth error page
│   │   ├── anilist_success.html # AniList OAuth success page
│   │   ├── mal_error.html       # MAL OAuth error page
│   │   └── mal_success.html     # MAL OAuth success page
│   │
│   ├── config.py                # Configuration management
│   ├── exceptions.py            # Custom exception hierarchy
│   ├── i18n.py                  # Internationalization system
│   ├── main.py                  # CLI entry point
│   └── __main__.py              # Package execution entry
│
├── tests/                       # Test suite
│   ├── test_api.py              # API commands and headless downloader tests
│   ├── test_cache.py            # Cache manager tests
│   ├── test_exceptions.py       # Exception tests
│   ├── test_sanitizer.py        # Sanitizer tests
│   └── conftest.py              # Pytest fixtures
│
├── weeb_landing/                # Landing page assets
│   ├── logo/                    # Logo files (various sizes)
│   └── index.html               # Landing page
│
├── distribution/                # Build and distribution files
├── pyproject.toml               # Project metadata and dependencies
├── requirements.txt             # Python dependencies
├── pytest.ini                   # Pytest configuration
├── LICENSE                      # GPL License 
└── README.md                    # This file
```

---

[![Star History Chart](https://api.star-history.com/image?repos=ewgsta/weeb-cli&type=date&legend=top-left)](https://www.star-history.com/?repos=ewgsta%2Fweeb-cli&type=date&legend=top-left)

---

## License

This project is licensed under the **GNU General Public License v3.0**.  
See the [LICENSE](LICENSE) file for the full license text.

Weeb-CLI (C) 2026
