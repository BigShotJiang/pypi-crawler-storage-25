"""
S3Manager - Object Storage Capability for NeuronOS.

A provider-agnostic S3 object storage capability following hexagonal architecture
principles. Supports CRUD operations, listing, streaming, and multipart uploads.

Example:
    from neuronos_capabilities import S3Manager

    s3 = S3Manager({"region": "us-east-1"})

    # Upload
    s3.put_object("my-bucket", "hello.txt", b"Hello World")
    s3.upload_file("/tmp/data.csv", "my-bucket", "data/data.csv")

    # Download
    s3.download_file("my-bucket", "data/data.csv", "/tmp/downloaded.csv")

    # List
    for obj in s3.walk("my-bucket", "data/"):
        print(obj["Key"], obj["Size"])

    # Multipart
    upload_id = s3.create_multipart_upload("my-bucket", "large.bin")
    part = s3.upload_part("my-bucket", "large.bin", 1, upload_id, chunk)
    s3.complete_multipart_upload("my-bucket", "large.bin", upload_id, [part])
"""

from .s3_manager import S3Manager
from .config.s3_config import S3Config
from .exceptions.s3_exceptions import (
    S3ManagerError,
    ConfigurationError,
    ConnectionError,
    UploadError,
    DownloadError,
    DeleteError,
    ListError,
    MultipartError,
)

__all__ = [
    "S3Manager",
    "S3Config",
    "S3ManagerError",
    "ConfigurationError",
    "ConnectionError",
    "UploadError",
    "DownloadError",
    "DeleteError",
    "ListError",
    "MultipartError",
]

__version__ = "1.0.0"
