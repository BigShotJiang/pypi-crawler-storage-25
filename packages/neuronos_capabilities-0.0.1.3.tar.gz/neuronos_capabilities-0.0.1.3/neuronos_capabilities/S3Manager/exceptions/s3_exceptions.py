"""
Custom exceptions for S3Manager capability.
"""


class S3ManagerError(Exception):
    """Base exception for all S3Manager errors."""
    pass


class ConfigurationError(S3ManagerError):
    """Raised when configuration is invalid or incomplete."""
    pass


class ConnectionError(S3ManagerError):
    """Raised when S3 client connection fails."""
    pass


class UploadError(S3ManagerError):
    """Raised when an upload operation fails."""
    pass


class DownloadError(S3ManagerError):
    """Raised when a download operation fails."""
    pass


class DeleteError(S3ManagerError):
    """Raised when a delete operation fails."""
    pass


class ListError(S3ManagerError):
    """Raised when a listing operation fails."""
    pass


class MultipartError(S3ManagerError):
    """Raised when a multipart upload operation fails."""
    pass
