"""
S3Manager usage examples.
"""

import asyncio
from neuronos_capabilities import S3Manager


def sync_examples():
    # Initialize with default AWS credentials (env vars or IAM role)
    s3 = S3Manager({"region": "us-east-1"})

    bucket = "my-bucket"

    # --- Upload ---
    s3.put_object(bucket, "hello.txt", b"Hello World", ContentType="text/plain")
    s3.upload_file("/tmp/report.pdf", bucket, "reports/report.pdf")

    with open("/tmp/data.csv", "rb") as f:
        s3.upload_stream(f, bucket, "data/data.csv")

    # --- Download ---
    response = s3.get_object(bucket, "hello.txt")
    content = response["Body"].read()
    print(content)

    s3.download_file(bucket, "reports/report.pdf", "/tmp/downloaded.pdf")

    stream = s3.download_stream(bucket, "data/data.csv")
    print(stream.read(1024))

    # --- Metadata ---
    head = s3.head_object(bucket, "hello.txt")
    print(f"Size: {head['ContentLength']}, Type: {head['ContentType']}")

    metadata = s3.get_object_metadata(bucket, "hello.txt")
    print(f"User metadata: {metadata}")

    # --- Delete ---
    s3.delete_object(bucket, "hello.txt")
    s3.delete_objects(bucket, ["data/data.csv", "reports/report.pdf"])

    # --- Listing ---
    result = s3.list_objects_v2(bucket, prefix="data/")
    for obj in result.get("Contents", []):
        print(f"  {obj['Key']} ({obj['Size']} bytes)")

    # Recursive walk
    for obj in s3.walk(bucket, "data/"):
        print(f"  {obj['Key']}")

    # --- Multipart Upload ---
    upload_id = s3.create_multipart_upload(bucket, "large-file.bin")
    parts = []
    chunk_size = 8 * 1024 * 1024  # 8MB

    with open("/tmp/large-file.bin", "rb") as f:
        part_number = 1
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            part = s3.upload_part(bucket, "large-file.bin", part_number, upload_id, chunk)
            parts.append(part)
            part_number += 1

    s3.complete_multipart_upload(bucket, "large-file.bin", upload_id, parts)


async def async_examples():
    s3 = S3Manager({"region": "us-east-1"})
    bucket = "my-bucket"

    await s3.put_object_async(bucket, "async-hello.txt", b"Hello Async")
    await s3.download_file_async(bucket, "async-hello.txt", "/tmp/async-hello.txt")
    await s3.delete_object_async(bucket, "async-hello.txt")

    objects = await s3.walk_async(bucket, "data/")
    for obj in objects:
        print(f"  {obj['Key']}")


if __name__ == "__main__":
    # sync_examples()
    # asyncio.run(async_examples())
    print("Uncomment the examples you want to run.")
