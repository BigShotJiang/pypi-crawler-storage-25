# AuthManager tests
