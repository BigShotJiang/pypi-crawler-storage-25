"""
AuthManager - Authentication & Authorization Capability for NeuronOS.

A provider-agnostic auth capability following hexagonal architecture principles.
Provides FastAPI decorators for JWT-based authentication and role-based access control.

Example:
    from neuronos_capabilities import AuthManager

    auth = AuthManager({
        "provider": "clerk",
        "jwks_url": "https://your-app.clerk.accounts.dev/.well-known/jwks.json",
    })

    @app.get("/api/protected")
    def protected(user: dict = Depends(auth.require_auth())):
        return {"user_id": user["sub"]}

    @app.get("/api/admin")
    def admin(user: dict = Depends(auth.require_roles(["org:admin"]))):
        return {"message": "Admin access granted"}
"""

from .auth_manager import AuthManager
from .config.auth_config import AuthConfig
from .exceptions.auth_exceptions import (
    AuthManagerError,
    ConfigurationError,
    TokenError,
    AuthorizationError,
)

__all__ = [
    "AuthManager",
    "AuthConfig",
    "AuthManagerError",
    "ConfigurationError",
    "TokenError",
    "AuthorizationError",
]

__version__ = "1.0.0"
