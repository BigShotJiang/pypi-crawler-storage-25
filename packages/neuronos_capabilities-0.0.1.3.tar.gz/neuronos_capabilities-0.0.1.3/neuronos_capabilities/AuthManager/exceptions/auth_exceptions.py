"""
Custom exceptions for AuthManager capability.
"""


class AuthManagerError(Exception):
    """Base exception for all AuthManager errors."""
    pass


class ConfigurationError(AuthManagerError):
    """Raised when configuration is invalid or incomplete."""
    pass


class TokenError(AuthManagerError):
    """Raised when token verification fails (expired, malformed, invalid signature)."""
    pass


class AuthorizationError(AuthManagerError):
    """Raised when the user lacks required roles or permissions."""
    pass
