"""
NeuronOS Capabilities Library

A collection of provider-agnostic backend capabilities following hexagonal
architecture principles. Each capability exposes ports and adapters for
flexible backend infrastructure.

Available Capabilities:
    - SQLManager: Database management with ORM, migrations, and connection pooling
    - AuthManager: Authentication and authorization with FastAPI decorator support
    - S3Manager: Object storage with CRUD, listing, streaming, and multipart uploads

Example:
    from neuronos_capabilities import SQLManager

    config = {
        "host": "localhost",
        "database": "myapp",
        "user": "postgres",
        "password": "secret"
    }

    with SQLManager(config) as db:
        db.create_tables([User])
        user = db.insert(User, {"name": "Alice", "email": "alice@example.com"})

    from neuronos_capabilities import AuthManager

    auth = AuthManager({"jwks_url": os.getenv("NEURONOS_AUTH_JWKS_URL")})

    @app.get("/api/protected")
    def protected(user: dict = Depends(auth.require_auth())):
        return {"user_id": user["sub"]}
"""

from .__version__ import __version__
from .SQLManager import SQLManager
from .AuthManager import AuthManager
from .S3Manager import S3Manager

__all__ = ["SQLManager", "AuthManager", "S3Manager", "__version__"]
