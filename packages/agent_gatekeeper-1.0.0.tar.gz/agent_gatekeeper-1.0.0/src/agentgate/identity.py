"""Agent identity with HMAC verification."""

from __future__ import annotations

import hashlib
import hmac
import secrets
import uuid
from datetime import datetime, timezone

from pydantic import BaseModel, Field


class AgentIdentity(BaseModel):
    """Verifiable identity for an AI agent."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    capabilities: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    secret_key: str = Field(default_factory=lambda: secrets.token_hex(32))
    metadata: dict = Field(default_factory=dict)

    def sign(self, message: str) -> str:
        """Sign a message with this agent's secret key."""
        return hmac.new(
            self.secret_key.encode(),
            message.encode(),
            hashlib.sha256,
        ).hexdigest()

    def verify(self, message: str, signature: str) -> bool:
        """Verify a signature against this agent's key."""
        expected = self.sign(message)
        return hmac.compare_digest(expected, signature)

    @classmethod
    def create(cls, name: str, capabilities: list[str] = None) -> AgentIdentity:
        """Create a new agent identity."""
        return cls(name=name, capabilities=capabilities or [])
