"""Permission policies — YAML-defined, deny-by-default."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field


class Action(str, Enum):
    TOOL_USE = "tool_use"
    LLM_CALL = "llm_call"
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    NETWORK = "network"
    SHELL = "shell"
    DATA_ACCESS = "data_access"


class ActionRule(BaseModel):
    """Rule for a specific action type."""
    action: Action
    allowed: bool = False
    allowed_targets: list[str] = Field(default_factory=list)  # e.g., specific tool names, file paths
    denied_targets: list[str] = Field(default_factory=list)
    require_approval_above: Optional[int] = None  # escalate if usage exceeds this count
    hard_deny_above: Optional[int] = None  # deny outright above this count
    max_per_minute: Optional[int] = None


class PermissionPolicy(BaseModel):
    """Permission policy for an agent. Deny by default."""

    name: str
    description: str = ""
    rules: list[ActionRule] = Field(default_factory=list)
    default_deny: bool = True
    approval_timeout_seconds: int = 300
    approval_default: str = "deny"  # "deny" or "allow" when approval times out

    def get_rule(self, action: Action) -> Optional[ActionRule]:
        """Get the rule for a specific action type."""
        for rule in self.rules:
            if rule.action == action:
                return rule
        return None

    def check(self, action: Action, target: Optional[str] = None) -> str:
        """Check if an action is allowed. Returns 'allow', 'deny', or 'escalate'."""
        rule = self.get_rule(action)

        if rule is None:
            return "deny" if self.default_deny else "allow"

        if not rule.allowed:
            return "deny"

        if target:
            if rule.denied_targets and target in rule.denied_targets:
                return "deny"
            if rule.allowed_targets and target not in rule.allowed_targets:
                return "escalate"

        return "allow"

    @classmethod
    def from_yaml(cls, path: str | Path) -> PermissionPolicy:
        """Load a policy from a YAML file."""
        with open(path) as f:
            data = yaml.safe_load(f)

        rules = []
        for rule_data in data.get("rules", []):
            rule_data["action"] = Action(rule_data["action"])
            rules.append(ActionRule(**rule_data))

        return cls(
            name=data.get("name", "unnamed"),
            description=data.get("description", ""),
            rules=rules,
            default_deny=data.get("default_deny", True),
            approval_timeout_seconds=data.get("approval_timeout_seconds", 300),
            approval_default=data.get("approval_default", "deny"),
        )

    def to_yaml(self, path: str | Path) -> None:
        """Save policy to a YAML file."""
        data = {
            "name": self.name,
            "description": self.description,
            "default_deny": self.default_deny,
            "approval_timeout_seconds": self.approval_timeout_seconds,
            "approval_default": self.approval_default,
            "rules": [
                {
                    "action": r.action.value,
                    "allowed": r.allowed,
                    **({"allowed_targets": r.allowed_targets} if r.allowed_targets else {}),
                    **({"denied_targets": r.denied_targets} if r.denied_targets else {}),
                    **({"require_approval_above": r.require_approval_above} if r.require_approval_above is not None else {}),
                    **({"hard_deny_above": r.hard_deny_above} if r.hard_deny_above is not None else {}),
                    **({"max_per_minute": r.max_per_minute} if r.max_per_minute is not None else {}),
                }
                for r in self.rules
            ],
        }
        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
