"""GateKeeper — runtime enforcement with human-approval escalation."""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Optional

from pydantic import BaseModel, Field

from agentgate.identity import AgentIdentity
from agentgate.policy import Action, PermissionPolicy

logger = logging.getLogger(__name__)


class DecisionType(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    ESCALATE = "escalate"


class Decision(BaseModel):
    """Result of a gate check."""
    type: DecisionType
    agent_id: str
    action: Action
    target: Optional[str] = None
    reason: str = ""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    approved_by: Optional[str] = None  # set if human approved


class GateKeeper:
    """Runtime permission enforcement for AI agents."""

    def __init__(
        self,
        identity: AgentIdentity,
        policy: PermissionPolicy,
        approval_handler: Optional[Callable[[Decision], bool]] = None,
    ):
        self.identity = identity
        self.policy = policy
        self.approval_handler = approval_handler or self._default_approval_handler
        self._decisions: list[Decision] = []
        self._usage_counts: dict[str, int] = defaultdict(int)  # action -> total count
        self._usage_timestamps: dict[str, list[float]] = defaultdict(list)  # action -> timestamps for rate limiting

    def check(self, action: str | Action, target: Optional[str] = None) -> Decision:
        """Check if an action is permitted. Returns a Decision."""
        if isinstance(action, str):
            action = Action(action)

        result = self.policy.check(action, target)

        if result == "deny":
            decision = Decision(
                type=DecisionType.DENY,
                agent_id=self.identity.id,
                action=action,
                target=target,
                reason="Policy denies this action",
            )
        elif result == "escalate":
            decision = self._handle_escalation(action, target, reason="Action requires human approval")
        else:
            # result == "allow" — but check thresholds before allowing
            decision = self._check_thresholds(action, target)

        # Track usage for allowed actions
        if decision.type == DecisionType.ALLOW:
            key = action.value
            self._usage_counts[key] += 1
            self._usage_timestamps[key].append(time.monotonic())

        self._decisions.append(decision)
        logger.info("Gate decision: %s %s %s -> %s", self.identity.name, action.value, target or "", decision.type.value)
        return decision

    def is_allowed(self, action: str | Action, target: Optional[str] = None) -> bool:
        """Convenience: check and return bool."""
        return self.check(action, target).type == DecisionType.ALLOW

    def require(self, action: str | Action, target: Optional[str] = None) -> Decision:
        """Check and raise if denied."""
        decision = self.check(action, target)
        if decision.type == DecisionType.DENY:
            raise PermissionError(
                f"Agent '{self.identity.name}' denied: {action} "
                f"{'on ' + target if target else ''} — {decision.reason}"
            )
        return decision

    @property
    def decisions(self) -> list[Decision]:
        """History of all gate decisions."""
        return list(self._decisions)

    def _check_thresholds(self, action: Action, target: Optional[str]) -> Decision:
        """Check rate limits and usage thresholds. Returns allow, escalate, or deny."""
        rule = self.policy.get_rule(action)
        if rule is None:
            return Decision(
                type=DecisionType.ALLOW, agent_id=self.identity.id,
                action=action, target=target, reason="Policy allows this action",
            )

        key = action.value
        count = self._usage_counts.get(key, 0)

        # Hard deny above absolute limit
        if rule.hard_deny_above is not None and count >= rule.hard_deny_above:
            return Decision(
                type=DecisionType.DENY, agent_id=self.identity.id,
                action=action, target=target,
                reason=f"Hard limit exceeded: {count} >= {rule.hard_deny_above}",
            )

        # Escalate above approval threshold
        if rule.require_approval_above is not None and count >= rule.require_approval_above:
            return self._handle_escalation(action, target,
                reason=f"Usage threshold exceeded: {count} >= {rule.require_approval_above}")

        # Rate limit: deny if too many in the last minute
        if rule.max_per_minute is not None:
            now = time.monotonic()
            recent = [t for t in self._usage_timestamps.get(key, []) if now - t < 60]
            self._usage_timestamps[key] = recent  # prune old timestamps
            if len(recent) >= rule.max_per_minute:
                return Decision(
                    type=DecisionType.DENY, agent_id=self.identity.id,
                    action=action, target=target,
                    reason=f"Rate limit exceeded: {len(recent)} >= {rule.max_per_minute}/min",
                )

        return Decision(
            type=DecisionType.ALLOW, agent_id=self.identity.id,
            action=action, target=target, reason="Policy allows this action",
        )

    def _handle_escalation(self, action: Action, target: Optional[str], reason: str = "Action requires human approval") -> Decision:
        """Handle an escalated action — ask a human."""
        pending = Decision(
            type=DecisionType.ESCALATE,
            agent_id=self.identity.id,
            action=action,
            target=target,
            reason=reason,
        )

        approved = self.approval_handler(pending)

        if approved:
            return Decision(
                type=DecisionType.ALLOW,
                agent_id=self.identity.id,
                action=action,
                target=target,
                reason="Human approved",
                approved_by="human",
            )
        else:
            fallback = self.policy.approval_default
            return Decision(
                type=DecisionType.ALLOW if fallback == "allow" else DecisionType.DENY,
                agent_id=self.identity.id,
                action=action,
                target=target,
                reason=f"Human denied (fallback: {fallback})",
            )

    @staticmethod
    def _default_approval_handler(decision: Decision) -> bool:
        """Default: deny escalated actions (safe default)."""
        logger.warning("Escalated action denied (no approval handler): %s", decision)
        return False
