"""AgentGate — Identity and permission layer for AI agents."""
__version__ = "1.0.0"

from agentgate.identity import AgentIdentity
from agentgate.policy import PermissionPolicy, Action
from agentgate.gatekeeper import GateKeeper, Decision, DecisionType

__all__ = ["AgentIdentity", "PermissionPolicy", "Action", "GateKeeper", "Decision", "DecisionType"]
