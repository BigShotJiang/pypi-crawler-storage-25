"""Tests for AgentGate."""

import tempfile
from pathlib import Path

from agentgate.identity import AgentIdentity
from agentgate.policy import Action, ActionRule, PermissionPolicy
from agentgate.gatekeeper import GateKeeper, DecisionType


def _make_policy():
    return PermissionPolicy(
        name="test-policy",
        rules=[
            ActionRule(action=Action.TOOL_USE, allowed=True, allowed_targets=["search", "calculator"]),
            ActionRule(action=Action.LLM_CALL, allowed=True),
            ActionRule(action=Action.SHELL, allowed=False),
            ActionRule(action=Action.FILE_WRITE, allowed=True, denied_targets=["/etc/passwd"]),
        ],
    )


def test_identity_create_and_sign():
    agent = AgentIdentity.create("test-agent", capabilities=["search"])
    assert agent.name == "test-agent"
    sig = agent.sign("hello")
    assert agent.verify("hello", sig)
    assert not agent.verify("tampered", sig)


def test_policy_deny_by_default():
    policy = PermissionPolicy(name="empty", default_deny=True)
    assert policy.check(Action.TOOL_USE) == "deny"


def test_policy_allow_action():
    policy = _make_policy()
    assert policy.check(Action.LLM_CALL) == "allow"


def test_policy_deny_action():
    policy = _make_policy()
    assert policy.check(Action.SHELL) == "deny"


def test_policy_target_filtering():
    policy = _make_policy()
    assert policy.check(Action.TOOL_USE, target="search") == "allow"
    assert policy.check(Action.TOOL_USE, target="unknown_tool") == "escalate"
    assert policy.check(Action.FILE_WRITE, target="/etc/passwd") == "deny"


def test_policy_yaml_roundtrip():
    policy = _make_policy()
    with tempfile.NamedTemporaryFile(suffix=".yaml", delete=False, mode="w") as f:
        path = f.name
    policy.to_yaml(path)
    loaded = PermissionPolicy.from_yaml(path)
    assert loaded.name == policy.name
    assert len(loaded.rules) == len(policy.rules)
    assert loaded.check(Action.LLM_CALL) == "allow"
    assert loaded.check(Action.SHELL) == "deny"


def test_gatekeeper_allow():
    agent = AgentIdentity.create("agent-1")
    policy = _make_policy()
    gate = GateKeeper(identity=agent, policy=policy)

    decision = gate.check("llm_call")
    assert decision.type == DecisionType.ALLOW


def test_gatekeeper_deny():
    agent = AgentIdentity.create("agent-1")
    policy = _make_policy()
    gate = GateKeeper(identity=agent, policy=policy)

    decision = gate.check("shell")
    assert decision.type == DecisionType.DENY


def test_gatekeeper_escalation_with_handler():
    agent = AgentIdentity.create("agent-1")
    policy = _make_policy()

    # Custom handler that always approves
    gate = GateKeeper(
        identity=agent,
        policy=policy,
        approval_handler=lambda d: True,
    )

    decision = gate.check("tool_use", target="unknown_tool")
    assert decision.type == DecisionType.ALLOW
    assert decision.approved_by == "human"


def test_gatekeeper_escalation_denied():
    agent = AgentIdentity.create("agent-1")
    policy = _make_policy()

    # Default handler denies
    gate = GateKeeper(identity=agent, policy=policy)

    decision = gate.check("tool_use", target="unknown_tool")
    assert decision.type == DecisionType.DENY


def test_gatekeeper_require_raises():
    agent = AgentIdentity.create("agent-1")
    policy = _make_policy()
    gate = GateKeeper(identity=agent, policy=policy)

    try:
        gate.require("shell")
        assert False, "Should have raised"
    except PermissionError as e:
        assert "denied" in str(e).lower()


def test_gatekeeper_hard_deny_threshold():
    agent = AgentIdentity.create("agent-1")
    policy = PermissionPolicy(
        name="threshold-policy",
        rules=[ActionRule(action=Action.LLM_CALL, allowed=True, hard_deny_above=3)],
    )
    gate = GateKeeper(identity=agent, policy=policy)

    assert gate.check("llm_call").type == DecisionType.ALLOW
    assert gate.check("llm_call").type == DecisionType.ALLOW
    assert gate.check("llm_call").type == DecisionType.ALLOW
    # 4th call should be denied
    assert gate.check("llm_call").type == DecisionType.DENY


def test_gatekeeper_approval_threshold():
    agent = AgentIdentity.create("agent-1")
    policy = PermissionPolicy(
        name="approval-policy",
        rules=[ActionRule(action=Action.TOOL_USE, allowed=True, require_approval_above=2)],
    )

    # With approving handler
    gate = GateKeeper(identity=agent, policy=policy, approval_handler=lambda d: True)

    assert gate.check("tool_use").type == DecisionType.ALLOW  # 1st - below threshold
    assert gate.check("tool_use").type == DecisionType.ALLOW  # 2nd - below threshold
    d3 = gate.check("tool_use")  # 3rd - at threshold, escalated then approved
    assert d3.type == DecisionType.ALLOW
    assert d3.approved_by == "human"


def test_gatekeeper_rate_limit():
    agent = AgentIdentity.create("agent-1")
    policy = PermissionPolicy(
        name="rate-policy",
        rules=[ActionRule(action=Action.LLM_CALL, allowed=True, max_per_minute=2)],
    )
    gate = GateKeeper(identity=agent, policy=policy)

    assert gate.check("llm_call").type == DecisionType.ALLOW
    assert gate.check("llm_call").type == DecisionType.ALLOW
    # 3rd call within same minute should be denied
    d3 = gate.check("llm_call")
    assert d3.type == DecisionType.DENY
    assert "Rate limit" in d3.reason


def test_gatekeeper_decision_history():
    agent = AgentIdentity.create("agent-1")
    policy = _make_policy()
    gate = GateKeeper(identity=agent, policy=policy)

    gate.check("llm_call")
    gate.check("shell")
    gate.check("tool_use", target="search")

    assert len(gate.decisions) == 3
    assert gate.decisions[0].type == DecisionType.ALLOW
    assert gate.decisions[1].type == DecisionType.DENY
    assert gate.decisions[2].type == DecisionType.ALLOW
