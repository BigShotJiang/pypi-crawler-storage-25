# Changelog

## [0.7.37] — 2026-04-12

### Changed
- **Full tool metadata capture** — shell hook now stores complete `tool_input` and `tool_response` objects alongside display previews. Previously only extracted preview strings; raw data was discarded. Enables upstream graph analysis, causal edge building, and artifact tracking from tool events.
- **Enriched shell hook** — `PreToolUse` captures `tool_input_preview` per tool type (Bash→command, Read/Edit/Write→file_path, Grep→pattern+path, Glob→pattern, Agent→description). `PostToolUse` captures `result_preview` (Bash→stdout/stderr, Read→line count, Grep→file+line count, Glob→file count) plus `tool_input_preview` so results show what was done.
- **Journal gating removed** — all captured metadata is now persisted regardless of journal mode. No more field stripping in `emit()`. `JOURNAL_CONTENT_FIELDS` retained as a reference for TUI enrichment display.
- **`tool_result` TUI shows input + result** — e.g. `Grep ✓ def main /src 3 files, 15 lines` instead of just `Grep ✓`.

## [0.7.36] — 2026-04-12

### Added
- **`mp connect [session_id]`** — attach TUI to an active recording session. Defaults to the current active session. `mp start` with an active session now auto-connects instead of erroring.
- **Source tracking in TUI** — events display which AI tool session generated them (e.g. `claude`, `codex`). Session bar shows source name and conversation number (`claude #2`). Tracks across multiple AI sessions within one `mp start`.
- **End session from TUI (`x`)** — confirmation prompt (`y`/`n`) to stop the session and finalize from within the TUI. `q` now exits the TUI without stopping the daemon — reconnect later with `mp connect`.

### Fixed
- **Tree indentation invisible** — `gold_ember` (`#3d3118`) was near-invisible on dark background; switched to `gold_aged` (`#9a7b3a`).
- **Orphan tool_call events showed no tree** — `tool_call` after `agent_turn_end`/`agent_complete` fell through to flat rendering. Now implicitly opens a new chain.
- **`tool_name` field empty in TUI** — hook events store the tool name in `tool` not `tool_name`; formatters now check both fields.

## [0.7.35] — 2026-04-12

### Added
- **10 TUI controls for `mp start`** — `j` journal toggle, `f` event filter cycle (all/ai_input/ai_output/human/verify), `s` scroll lock, `/` feed search, `tab` sidebar cycle (stats/files/tools), `t` tree collapse (hides chain inners, shows `+N` on closer), `d` timestamp format cycle (clock/relative/elapsed), `c` copy last event to clipboard, `enter` event detail modal, `m` quiet mode (hides dim events). All modes shown as badges in the session bar.
- **Structural analysis summary on `user_prompt` events** — main line now shows `prompt_summary` from the 35-dimension analysis (e.g. `[instruction/synthesis] refactor auth — DI`) instead of just char count.
- **Multi-line journal output** — `user_prompt` shows full prompt text wrapped at 100 chars. `agent_complete` shows up to 500 chars / 8 lines preserving natural line breaks. Other event types remain single-line at 120 char cap.

## [0.7.34] — 2026-04-12

### Fixed
- **`mp push` after mid-session push was permanently blocked** — pushing an active session marked it as synced. After stopping, additional events existed locally but could never be uploaded. Now: if a session was pushed while active and is now completed, `mp push` automatically re-pushes the full session. For already-completed sessions, `mp push --force` re-uploads all events.

## [0.7.33] — 2026-04-12

### Added
- **KINMYAKU theme palette**: `Palette` frozen dataclass replaces flat hex constants in `tui/theme.py`. Dark-adjusted colors from METHODPROOF.md spec — purple, green, red, dim all shifted for proper contrast on dark backgrounds. Five semantic roles (`ai_input`, `ai_output`, `human`, `verify`, `moment`) so TUI code reads intent, not hex. Backward-compatible re-exports — all existing imports unchanged.
- **Rich structural formatting for all 42 event types**: `mp start` feed now shows curated one-liners for every event type. `tool_call` → `Edit  app/core/auth.py`, `tool_result` → `Edit  ✓`, `agent_launch` → `explorer  spawned`, etc. Previously only 8 types had formatters; the rest showed raw key dumps or nothing.
- **Causal chain tree indentation**: Prompt→tool_call→tool_result chains render with Unicode box-drawing characters (`├`, `│`, `└`) in gold-ember. Non-AI events (file edits, tests, commits) appear at root level. Mirrors the Neo4j graph structure during live capture.
- **Journal mode content enrichment**: When journal is ON, a second dim line appears below events carrying content fields — truncated prompt text, tool results, diffs. Quoted and indented with a `│` gutter. When journal is OFF, these lines don't exist.
- **Enriched session bar**: Now shows running event count and a gold `J` badge when journal mode is active.
- **Moment alert wiring**: `_show_moment()` (previously dead code) now fires when known moment types appear in the event stream.

## [0.7.32] — 2026-04-12

### Fixed
- **`mp start` no longer hard-fails on missing shell hook** — instead of `ERROR: Run methodproof init first` + exit, `mp start` now auto-installs the hook and continues. Prints a note that terminal capture won't work until the shell is restarted. Prevents the frustrating dead-end where auto-update + missing hook blocks the entire session.

## [0.7.31] — 2026-04-12

### Fixed
- **`mp push` rejected terminal events** — `command` field was in `JOURNAL_CONTENT_FIELDS`, so it was stripped when journal mode was off. Platform requires `command` on `terminal_cmd` events. Removed from journal gate — the command string is structural metadata (sensitive commands are already dropped by the `SENSITIVE` regex).

## [0.7.30] — 2026-04-12

### Changed
- **Removed Basic tier from journal entitlement** — tiers are Free and Pro+ only. Dropped the server-side credit fetch for Basic; `_journal_entitlement` now returns `"unlimited"` for Pro+ and local credit count for Free.

## [0.7.29] — 2026-04-12

### Changed
- **Journal mode output is now tier-aware** — Pro/Team/Admin/Superadmin users see "Unlimited journal entries (Pro plan)" everywhere journal credits are displayed (`mp journal on`, `mp journal status`, `mp start --journal`, session mode line, consent flow). Basic users get a live credit count fetched from `GET /auth/me` (falls back to local cache if offline). Free users see their local credit count as before. Credit deduction on `--journal` is skipped for unlimited tiers.

## [0.7.28] — 2026-04-12

### Added
- **`cwd` in terminal events** — shell hook (bash/zsh/PowerShell) now writes working directory to `commands.jsonl`; terminal agent reads it into `terminal_cmd` metadata. Requires re-running `mp init` to update the installed hook.
- **Git commit enrichment** — `git_commit` events now include `author`, `author_email`, `committed_at` (ISO 8601), `parent_hash`, and `body` (full commit message body when it differs from subject). Single `git log` call instead of multiple.
- **`language` on `file_delete`** — was always empty string; now extracted from file extension same as `file_create`.
- **`skipped` count in `test_run`** — pytest, jest, and go test output now parsed for skipped test count.

### Fixed
- **`agent_complete.last_message_preview` not journal-gated** — preview of agent's final message leaked content when journal mode was off. Now stripped with other content fields.
- **`git_commit.body` not journal-gated** — full commit body (multi-line messages) added to journal gate.

## [0.7.27] — 2026-04-12

### Fixed
- **`result_preview` was Python repr for structured tool responses** — `str([{"type": "text", "text": "..."}])` produced unreadable output for Read/Grep/Glob tools. `_extract_result_text` now handles all three shapes Claude Code sends: plain string (Bash/Write/Edit), content block list (Read/Grep/Glob), and dict.

## [0.7.26] — 2026-04-12

### Fixed
- **Journal mode missing tool and prompt content** — `tool_call`, `tool_result`, and `user_prompt` hook events never captured content even with journal mode on; the extractors never included it. `tool_call` now captures `tool_input_preview` (command/path/query smartly extracted), `tool_result` captures `result_preview` (500 char cap), `user_prompt` captures `prompt_text`. All three fields are added to `JOURNAL_CONTENT_FIELDS` so they're stripped when journal is off.

## [0.7.25] — 2026-04-12

### Fixed
- **TUI event metadata never rendered** — `_fmt_meta` read fields like `path`, `command`, `message` from the top-level event dict, but they live inside the `metadata` sub-dict. All event-type formatters now read from `ev["metadata"]`.
- **Tier hardcoded as "Pro" in session bar** — decoded from JWT on mount; now shows actual account type (Free / Basic / Pro / Team).
- **Unused `Worker`/`WorkerState` imports** removed from `tui/start.py`.

## [0.7.24] — 2026-04-12

### Fixed
- **TUI event feed was always empty** — `_poll_events` called `store.get_session_events` which did not exist; `except Exception: return` silently swallowed the `AttributeError`. Added `get_session_events(session_id, after_id="")` to store — uses SQLite `rowid` for monotonic pagination so the TUI feed populates in real time. Also surfaced poll errors to the Textual log instead of swallowing them.

## [0.7.23] — 2026-04-12

### Fixed
- **`mp` alias works immediately after `init`** — `_install_alias` now creates a real symlink (`mp → methodproof`) in the same bin directory instead of writing an rc alias. No shell restart or eval needed. Falls back to rc alias if symlinking fails (e.g. read-only bin dir).

## [0.7.22] — 2026-04-11

### Added
- **Username in session output** — `mp start` banner shows `Account: @username` (falls back to email). `mp stop` summary shows the same. Username fetched from `/auth/me` on login and stored in config profile.

### Fixed
- **`eval "$(methodproof shell-hook)"` missing `mp` alias** — `shell-hook` now emits both the command-logging hooks and `alias mp="methodproof"`, so eval fully activates the CLI without a shell restart.

## [0.7.20] — 2026-04-11

### Fixed
- **TUI init layout** — toggle rows now use `height: auto` so long capture descriptions don't clip; `width: 1fr` on `.row-label` overrides the 24-char truncation from base CSS; Switch widgets widened from 4→6 for correct rendering; Full Spectrum status no longer cut off at 1 line
- **TUI consent layout** — Switch widgets widened from 4→6 (same fix as init)
- **TUI status markup** — `_token_expiry()` was returning Rich markup strings into `Text.append()`, which treats input as plain text; tags now rendered literally (e.g. `[#d93326]expires soon[/#d93326]`). Fixed to return `(text, style)` tuple and apply styles at call site
- **Session complete timeout** — `mp push` was using 15s for the final `/complete` call, which times out on large sessions while the server drains the ingest queue and materializes stats. Raised to 90s. Timeout is now a configurable parameter on internal request helpers

## [0.7.6] — 2026-04-08

### Added
- **Metadata compression** — event metadata stored as zlib-compressed BLOBs in SQLite (~80% storage reduction for journal-mode sessions). Existing uncompressed rows are silently migrated on next startup.
- **Gzip transfer encoding** — `mp push` sends gzip-compressed request bodies to the platform. Reduces upload bandwidth ~70% for large batches.

## [0.7.1] — 2026-04-07

### Fixed
- **7 GB database bloat** — `artifacts` table lacked a UNIQUE constraint on `path`, causing `_ensure_artifact` to insert a duplicate row per `file_edit`. The `_link_action_artifacts` JOIN then produced a cartesian explosion (39.9M rows from 16K events). Added UNIQUE constraint + migration that deduplicates existing data on upgrade.
- **Stale PID after reboot** — `_is_daemon_alive()` only checked `os.kill(pid, 0)`, which succeeds if the OS reused the PID for an unrelated process. Now verifies the process name contains "methodproof" via `ps`. Prevents killing random processes and unblocks `mp stop`/`mp start` after a system restart.
- **SQLite hang on locked database** — `sqlite3.connect()` had no timeout, so a crashed daemon holding a WAL lock caused `mp stop` to hang forever. Added `timeout=10`.

### Added
- **Research consent sync** — `mp init`, `mp consent`, `mp login`, and `mp push` now sync research opt-in state between CLI and platform. Local changes are flagged with `_pending_research_sync` and pushed on next authenticated call; canonical state is always pulled from the platform.

## [0.7.0] — 2026-04-07

### Fixed
- **Runaway event logging** — watcher ignored only 7 patterns, tracking 35K+ files including `.venv/` (20K), `dist/build/` (23K). Expanded to 30+ ignore patterns covering Python, JS/TS, Rust, Go, Java, Ruby, PHP, .NET, Swift, and build artifacts. **138K → 1,442 files (99% reduction)**
- **Claude Code hook errors** — hook script pointed to deleted pyenv site-packages path; added pidfile guard (`exit 0` when no session active) to prevent bridge connection failures

### Added
- **Configurable local AI ports** — `mp init` now asks about local LLM servers (Ollama, LM Studio, vLLM, etc.) and adds user-specified ports to the proxy allowlist. Previously only 3 hardcoded ports (11434, 18789, 1234) were captured; custom ports were invisible to the proxy decoder.
- `mp start --streaming` — blocking foreground mode, streams every captured event to stdout in real-time with human-readable formatting
- `mp start --verbose` / `-v` — structured debug logging at each step (config, auth, session, anchor, daemon spawn); daemon log includes agent init and buffer/flush stats
- Step-by-step progress output on default `mp start` (`→ Loading config`, `→ Checking hooks`, etc.) so failures are immediately locatable

## [0.5.1] — 2026-04-06

### Fixed
- macOS daemon segfault: replaced `os.fork()` with `subprocess.Popen()` — CoreFoundation crash after fork killed all capture agents, producing 0 events
- Hook type mismatches: `task_created`→`task_start`, `task_completed`→`task_end`, added required `tool` field to all hook metadata
- Unmapped hook events dropped instead of sent as invalid `claude_code_event` type (rejected entire batch)
- Daemon output logged to `~/.methodproof/daemon.log` instead of `/dev/null`
- ~20 silent `except Exception: pass` blocks replaced with structured logging across bridge, hooks, live streaming, sync, keychain, MCP, and proxy

### Changed
- Daemon health check on startup — immediate error if daemon exits
- Extension status check shows actual error on failure

## [0.3.4] — 2026-04-05

### Added
- `mp log` shows session status: recording, stopped, pushed, empty, abandoned
- `mp log` prints sync reminder when unsynced sessions exist

## [0.3.3] — 2026-04-05

### Fixed
- macOS hook timestamp: `date +%s.%3N` produced invalid JSON (literal `.3N`), silently dropping all tool_call, tool_result, agent_launch, and agent_complete events
- Stale session recovery: `mp start` now detects dead daemons and cleans up instead of blocking
- Bridge events now route through `base.emit()` for consent gating, hash chain integrity, and live streaming

### Changed
- `mp view` replaced with terminal-based session audit (no HTTP server)
- Recording threads start after fork (fixes silent 0-event sessions on macOS)
- Hook errors logged to `~/.methodproof/hook_errors.log` for inspection
- Consent-blocked events logged at debug level

### Added
- Watch Scope section in README documenting directory scope and exclusion patterns
- `store.reset_connection()` for fork-safe SQLite WAL handling

## [0.3.2] — 2026-04-04

### Changed
- `websocket-client` is now a default dependency (no longer requires `pip install methodproof[live]`)
- `mp start --live` prints a clickable dashboard URL instead of the API host
- `live.start()` returns the dashboard URL from the platform handshake

## [0.3.1] — 2026-04-04

### Added
- `mp extension pair` — pair browser extension to active session
- `mp extension status` — check extension connection
- `mp extension install` — open Chrome Web Store listing
- Bridge auto-discovery: extension auto-connects when CLI session starts
- Bridge `/pair/auto` endpoint for extension auto-pairing
- Bridge `/pair/register` + `/pair/ack` for manual pairing flow
- `mp start` now runs in the background (daemon mode on Unix)
- Extension status check on session start (connected/not detected)
- `SO_REUSEADDR` on bridge socket for clean restarts

### Changed
- Bridge accepts API credentials for auto-discovery passthrough
- `_shutdown` handler wrapped in try/except for robust daemon cleanup

## [0.3.0] — 2026-04-03

### Added
- Prompt structural analysis: 35 metadata dimensions extracted from AI prompts
- Environment profiling: structural scan of AI dev environment (instruction files, tool configs)
- `environment_analysis` consent category (default on, structural metadata only)
- Outcome metrics: correlation between prompt patterns and session results
- Consent review prompt when new capture categories exist after update

### Changed
- README rebrand: OG dark banner, hero process graph, brand-colored badges

### Fixed
- Unused import, silent failures, operator precedence, magic numbers (code review)

## [0.2.0] — 2026-03-30

### Added
- Browser login via device auth flow (`mp login` opens browser)
- Three-section interactive consent (capture, research, redaction)
- `mp uninstall` — remove all hooks, data, and config
- Color-coded command reference (`mp help`)
- Auto-refresh expired API tokens
- `mp update` — self-update from PyPI
- AI Agent Graph branding for prompt/response events
- Code capture consent category (Pro only, encrypted, default off)
- Windows compatibility (stop sentinel, icacls permissions)
- `--live` flag streams events to platform in real-time over WebSocket
- `live` optional dependency (`pip install methodproof[live]`)
- Free-tier full-spectrum consent unlocks 30-day rolling live stream

## [0.1.1] — 2026-03-28

### Fixed
- Added pytest dev dependency

## [0.1.0] — 2026-03-27

### Added
- Initial release
- `mp init/start/stop/view/log/push/publish/review/consent/tag/delete`
- File watcher, terminal monitor, music agent
- Local bridge for browser extension events
- Hash-chained events + Ed25519 attestation
- Full Spectrum messaging (all 10 categories)
- `mp mcp-serve` — MCP server for Claude Code
