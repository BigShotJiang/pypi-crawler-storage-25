"""Data classes returned by :mod:`dipx.client`.

These are plain :class:`~dataclasses.dataclass` containers — every
attribute is documented below. All ``id`` fields are positive integers,
prices are floats (``₽``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class Profile:
    id: int
    username: str
    avatar: Optional[str] = None
    rating: float = 0.0
    sales: int = 0
    description: str = ""
    verified: bool = False
    trusted: bool = False
    raw: dict = field(default_factory=dict)


@dataclass
class Balance:
    total: float
    available: float
    frozen: float
    raw: dict = field(default_factory=dict)


@dataclass
class Transaction:
    type: str
    amount: float
    description: str
    created_at: str
    is_positive: bool
    balance_after: Optional[str] = None
    raw: dict = field(default_factory=dict)


@dataclass
class Product:
    id: int
    title: str
    price: float
    status: str  # "active" | "hidden" | "sold"
    views: int = 0
    sales: int = 0
    url: Optional[str] = None
    image: Optional[str] = None
    created_at: Optional[str] = None
    raw: dict = field(default_factory=dict)


@dataclass
class BumpInfo:
    free_available: bool
    paid_available: bool
    free_next_at: Optional[str] = None
    free_cooldown_hours: int = 0
    daily_used: int = 0
    daily_limit: int = 10
    daily_left: int = 10
    bump_price: int = 15
    next_price: int = 25
    bump_count: int = 0
    is_paid_active: bool = False
    paid_expires_hours: int = 0
    paid_duration: int = 12
    raw: dict = field(default_factory=dict)


@dataclass
class Order:
    id: int
    product_title: str
    amount: float
    status: str  # "completed" | "pending" | "refunded" | "disputed" | ...
    role: str  # "buyer" | "seller"
    partner: str = ""
    date: Optional[str] = None
    conversation_id: Optional[int] = None
    raw: dict = field(default_factory=dict)


@dataclass
class Conversation:
    id: int
    partner_id: int
    partner_name: str
    partner_avatar: Optional[str] = None
    partner_online: bool = False
    partner_verified: bool = False
    partner_trusted: bool = False
    partner_rating: float = 0.0
    partner_sales: int = 0
    last_message: Optional[str] = None
    last_message_at: Optional[str] = None
    last_message_ago: Optional[str] = None
    last_is_own: bool = False
    last_is_system: bool = False
    last_is_read: bool = True
    unread_count: int = 0
    active_order_count: int = 0
    active_order_amount: Optional[float] = None
    is_pinned: bool = False
    raw: dict = field(default_factory=dict)


@dataclass
class Message:
    id: int
    conv_id: int
    text: str
    is_own: bool
    is_system: bool = False
    created_at: Optional[str] = None
    attachment: Optional[str] = None
    product_id: Optional[int] = None
    raw: dict = field(default_factory=dict)


@dataclass
class NotificationSettings:
    telegram_linked: bool
    telegram_orders: bool
    telegram_messages: bool
    vk_linked: bool
    vk_orders: bool
    vk_messages: bool
    browser: bool
    push_orders: bool
    push_messages: bool
    push_deposits: bool
    push_subscribed: bool
    live_feed_hidden: bool
    bot_username: Optional[str] = None
    raw: dict = field(default_factory=dict)


@dataclass
class Review:
    id: int
    user_id: int
    rating: int
    text: str
    created_at: str
    reply: Optional[str] = None
    raw: dict = field(default_factory=dict)


@dataclass
class WishlistResult:
    success: bool
    added: bool
    count: int
    raw: dict = field(default_factory=dict)
