"""Internal HTTP helper: holds a :class:`requests.Session`, manages CSRF.

The marketplace authenticates with cookies (PHPSESSID) and rejects most
JSON endpoints that don't have an ``X-Requested-With: XMLHttpRequest``
header and a same-origin ``Referer``. CSRF tokens are required by all
state-mutating endpoints and refreshed on every full HTML page load.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Optional

import requests

from .exceptions import (
    AuthError,
    DipXError,
    InsufficientBalanceError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)

BASE_URL = "https://dip-x.store"

_CSRF_RE = re.compile(
    r'name="csrf_token"\s+value="([0-9a-f]{32,128})"', re.IGNORECASE
)


class _Http:
    def __init__(
        self,
        *,
        base_url: str = BASE_URL,
        timeout: float = 30.0,
        user_agent: Optional[str] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.csrf_token: Optional[str] = None
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": user_agent
                or (
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/130.0 Safari/537.36"
                ),
                "Accept-Language": "ru,en;q=0.9",
            }
        )

    # ── url helpers ──────────────────────────────────────────────
    def url(self, path: str) -> str:
        if path.startswith(("http://", "https://")):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return self.base_url + path

    # ── csrf ────────────────────────────────────────────────────
    def refresh_csrf(self, html: str) -> Optional[str]:
        m = _CSRF_RE.search(html)
        if m:
            self.csrf_token = m.group(1)
        return self.csrf_token

    def ensure_csrf(self, page_path: str = "/profile") -> str:
        """Make sure we have a CSRF token; load ``page_path`` if needed."""
        if self.csrf_token:
            return self.csrf_token
        resp = self.session.get(self.url(page_path), timeout=self.timeout)
        self.refresh_csrf(resp.text)
        if not self.csrf_token:
            raise AuthError(
                "Не удалось получить csrf_token (вы авторизованы?)",
                status_code=resp.status_code,
            )
        return self.csrf_token

    # ── core request ────────────────────────────────────────────
    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        params: Any = None,
        headers: Optional[Dict[str, str]] = None,
        referer: Optional[str] = None,
        allow_redirects: bool = True,
        as_json: bool = True,
        raise_status: bool = True,
    ) -> Any:
        url = self.url(path)
        hdrs: Dict[str, str] = {}
        if as_json:
            hdrs["X-Requested-With"] = "XMLHttpRequest"
            hdrs["Accept"] = "application/json, text/plain, */*"
        if referer:
            hdrs["Referer"] = self.url(referer)
        if headers:
            hdrs.update(headers)

        resp = self.session.request(
            method,
            url,
            json=json,
            data=data,
            files=files,
            params=params,
            headers=hdrs,
            timeout=self.timeout,
            allow_redirects=allow_redirects,
        )

        if raise_status:
            _raise_for_status(resp)

        if as_json:
            ct = resp.headers.get("Content-Type", "")
            if "application/json" in ct:
                try:
                    return resp.json()
                except Exception:
                    pass
        return resp

    def get_json(self, path: str, **kw) -> Any:
        return self.request("GET", path, **kw)

    def post_json(self, path: str, **kw) -> Any:
        return self.request("POST", path, **kw)

    def get_html(self, path: str, **kw) -> str:
        kw.setdefault("as_json", False)
        resp = self.request("GET", path, **kw)
        text = resp.text
        self.refresh_csrf(text)
        return text


# ── helpers ─────────────────────────────────────────────────────
def _payload(resp: requests.Response) -> Any:
    ct = resp.headers.get("Content-Type", "")
    if "application/json" in ct:
        try:
            return resp.json()
        except Exception:
            return None
    return None


def _raise_for_status(resp: requests.Response) -> None:
    code = resp.status_code
    if code < 400:
        return
    body = _payload(resp)
    msg: Any = None
    if isinstance(body, dict):
        msg = body.get("error") or body.get("message") or body.get("detail")
    msg = msg or resp.reason or "HTTP error"
    if code in (401, 403):
        raise AuthError(msg, status_code=code, payload=body)
    if code == 404:
        raise NotFoundError(msg, status_code=code, payload=body)
    if code == 429:
        raise RateLimitError(msg, status_code=code, payload=body)
    if code == 402:
        raise InsufficientBalanceError(msg, status_code=code, payload=body)
    if code in (400, 422):
        raise ValidationError(msg, status_code=code, payload=body)
    raise DipXError(msg, status_code=code, payload=body)
