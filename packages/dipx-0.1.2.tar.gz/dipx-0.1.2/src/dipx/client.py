"""High-level synchronous client for dip-x.store.

Example
-------

.. code-block:: python

    from dipx import DipXClient

    client = DipXClient()
    profile = client.login("Lincoln", "...")
    print(profile.username, profile.id)

    for p in client.get_my_products():
        print(p.id, p.title, p.price, p.status)

    client.logout()

All methods are synchronous (use :mod:`requests` under the hood). The
client keeps the session alive between calls; create separate
``DipXClient`` instances if you need parallel sessions for different
accounts.
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from ._http import _Http, BASE_URL
from ._parse import (
    parse_balance,
    parse_orders,
    parse_products,
    parse_profile,
    parse_profile_id_from_html,
)
from .exceptions import (
    AuthError,
    DipXError,
    InsufficientBalanceError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .models import (
    Balance,
    BumpInfo,
    Conversation,
    Message,
    NotificationSettings,
    Order,
    Product,
    Profile,
    Review,
    Transaction,
    WishlistResult,
)


# Map of payment_method → form action path / hidden-amount field name.
_DEPOSIT_METHODS: Dict[str, Dict[str, str]] = {
    "platega": {"action": "/profile/platega-deposit", "field": "platega_amount"},
    "platega_card": {
        "action": "/profile/platega-card-deposit",
        "field": "platega_card_amount",
    },
    "lolz": {"action": "/profile/lolz-deposit", "field": "lolz_amount"},
    "anypay": {"action": "/profile/anypay-deposit", "field": "anypay_amount"},
    "apays": {"action": "/profile/apays-deposit", "field": "apays_amount"},
    "digitalpay": {
        "action": "/profile/digitalpay-deposit",
        "field": "digitalpay_amount",
    },
    "streampay": {
        "action": "/profile/streampay-deposit",
        "field": "streampay_amount",
    },
    "cryptobot": {
        "action": "/profile/cryptobot-deposit",
        "field": "cryptobot_amount",
    },
    "crypto": {"action": "/profile/crypto-deposit", "field": "amount"},
}


class DipXClient:
    """Synchronous client for the dip-x.store marketplace."""

    # ------------------------------------------------------------------
    # construction / lifecycle
    # ------------------------------------------------------------------
    def __init__(
        self,
        *,
        base_url: str = BASE_URL,
        timeout: float = 30.0,
        user_agent: Optional[str] = None,
    ) -> None:
        self._http = _Http(
            base_url=base_url, timeout=timeout, user_agent=user_agent
        )
        self.profile: Optional[Profile] = None

    # ------------------------------------------------------------------
    # session
    # ------------------------------------------------------------------
    def login(
        self, username: str, password: str, *, remember: bool = True
    ) -> Profile:
        """Log in by username + password. Returns the :class:`Profile`."""
        html = self._http.get_html("/login")
        csrf = self._http.csrf_token or ""
        if not csrf:
            raise AuthError("Не удалось получить csrf_token со страницы /login")
        resp = self._http.request(
            "POST",
            "/login",
            data={
                "csrf_token": csrf,
                "_fp": "",
                "login": username,
                "password": password,
                "remember_me": "1" if remember else "",
            },
            referer="/login",
            allow_redirects=False,
            as_json=False,
            raise_status=False,
        )
        loc = resp.headers.get("Location", "")
        if resp.status_code != 302 or loc.endswith("/login"):
            raise AuthError("Неверный логин или пароль")
        # Hit /profile to populate CSRF, then /user/<name> to discover ID.
        prof_html = self._http.get_html("/profile")
        self.profile = parse_profile(prof_html, username=username)
        uid = parse_profile_id_from_html(prof_html) or 0
        if not uid:
            try:
                user_html = self._http.get_html(f"/user/{username}")
                uid = parse_profile_id_from_html(user_html) or 0
            except DipXError:
                pass
        if uid:
            self.profile.id = uid
        return self.profile

    def logout(self) -> None:
        """Terminate the server session."""
        try:
            self._http.request(
                "GET", "/logout", as_json=False, raise_status=False
            )
        finally:
            self._http.session.cookies.clear()
            self._http.csrf_token = None
            self.profile = None

    def me(self) -> Profile:
        """Return cached profile (login first if needed)."""
        if self.profile is None:
            html = self._http.get_html("/profile")
            username = self._guess_username() or ""
            self.profile = parse_profile(html, username=username)
            uid = parse_profile_id_from_html(html) or 0
            if not uid and username:
                try:
                    uh = self._http.get_html(f"/user/{username}")
                    uid = parse_profile_id_from_html(uh) or 0
                except DipXError:
                    pass
            if uid:
                self.profile.id = uid
        return self.profile

    def _guess_username(self) -> Optional[str]:
        # Best-effort: pull username from header avatar link.
        try:
            html = self._http.get_html("/profile")
        except Exception:
            return None
        m = re.search(r'href="https://dip-x\.store/user/([^"/?]+)"', html)
        return m.group(1) if m else None

    # ------------------------------------------------------------------
    # profile
    # ------------------------------------------------------------------
    def get_profile(self) -> Profile:
        return self.me()

    def update_profile(
        self,
        *,
        description: Optional[str] = None,
        avatar_path: Optional[str] = None,
    ) -> bool:
        csrf = self._http.ensure_csrf("/profile/edit")
        data: Dict[str, Any] = {"csrf_token": csrf}
        if description is not None:
            data["description"] = description
        files = None
        if avatar_path:
            files = {"avatar": (os.path.basename(avatar_path), open(avatar_path, "rb"))}
        self._http.request(
            "POST",
            "/profile/edit",
            data=data,
            files=files,
            referer="/profile/edit",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    def change_password(
        self, current_password: str, new_password: str
    ) -> bool:
        csrf = self._http.ensure_csrf("/profile/edit")
        self._http.request(
            "POST",
            "/profile/edit",
            data={
                "csrf_token": csrf,
                "current_password": current_password,
                "new_password": new_password,
                "confirm_password": new_password,
            },
            referer="/profile/edit",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    # ------------------------------------------------------------------
    # balance / transactions / deposit
    # ------------------------------------------------------------------
    def get_balance(self) -> Balance:
        html = self._http.get_html("/profile/balance")
        bal = parse_balance(html)
        if bal.total == 0.0:
            data = self._http.get_json(
                "/api/unread-count", referer="/profile"
            )
            if isinstance(data, Mapping) and "balance" in data:
                bal = Balance(
                    total=float(data["balance"]),
                    available=float(data["balance"]),
                    frozen=0.0,
                    raw=dict(data),
                )
        return bal

    def get_transactions(self, page: int = 1) -> List[Transaction]:
        data = self._http.get_json(
            f"/api/transactions?page={int(page)}", referer="/profile/balance"
        )
        items = (data or {}).get("items", []) if isinstance(data, Mapping) else []
        out: List[Transaction] = []
        for it in items:
            try:
                amount = float(it.get("amount", 0))
            except (TypeError, ValueError):
                amount = 0.0
            out.append(
                Transaction(
                    type=it.get("type", ""),
                    amount=amount,
                    description=it.get("description", ""),
                    created_at=it.get("created_at", ""),
                    is_positive=bool(it.get("is_positive", False)),
                    balance_after=it.get("balance_after"),
                    raw=dict(it),
                )
            )
        return out

    def create_deposit(
        self, amount: float, payment_method: str = "lolz"
    ) -> str:
        """Initiate a deposit. Returns the redirect URL to the payment gateway."""
        if payment_method not in _DEPOSIT_METHODS:
            raise ValidationError(
                f"Unknown payment_method '{payment_method}'. "
                f"Valid: {sorted(_DEPOSIT_METHODS)}"
            )
        meta = _DEPOSIT_METHODS[payment_method]
        csrf = self._http.ensure_csrf("/profile/balance")
        data = {
            "csrf_token": csrf,
            "payment_method": payment_method,
            "deposit_amount": str(int(amount)),
            "custom_amount": "",
            meta["field"]: str(amount),
        }
        resp = self._http.request(
            "POST",
            meta["action"],
            data=data,
            referer="/profile/balance",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        loc = resp.headers.get("Location")
        if loc:
            return loc
        # Some methods may render an interstitial HTML page. Return the URL.
        return resp.url

    def request_withdrawal(
        self,
        amount: float,
        *,
        method: str,
        details: str,
        description: str = "",
    ) -> bool:
        csrf = self._http.ensure_csrf("/profile/balance")
        self._http.request(
            "POST",
            "/profile/withdrawal",
            data={
                "csrf_token": csrf,
                "amount": str(amount),
                "method": method,
                "details": details,
                "description": description,
            },
            referer="/profile/balance",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    def withdraw_to_lolz(
        self,
        amount: float,
        lolz_username: str,
        *,
        description: str = "",
    ) -> bool:
        """Convenience wrapper: withdraw ``amount`` ₽ to a Lolz account.

        On dip-x.store the radio button has ``value="LOLZ Market"`` and
        ``details`` is the username on Lolz.
        """
        return self.request_withdrawal(
            amount=amount,
            method="LOLZ Market",
            details=lolz_username,
            description=description,
        )

    # ------------------------------------------------------------------
    # Telegram-account pool (category 20 / subcategory 58)
    # ------------------------------------------------------------------
    def tg_upload_files(self, *paths: str) -> Dict[str, Any]:
        """Upload one or more ``.session`` / ``.zip`` files to the TG pool.

        Returns the raw server JSON with keys: ``success``, ``items``,
        ``queued``, ``duplicates``, ``errors``, ``message``.
        """
        if not paths:
            raise ValidationError("no files provided")
        csrf = self._http.ensure_csrf("/product/create")
        files: List[Any] = []
        opened: List[Any] = []
        for p in paths:
            f = open(p, "rb")
            opened.append(f)
            files.append(("files[]", (os.path.basename(p), f, "application/octet-stream")))
        try:
            return self._http.request(
                "POST",
                "/api/tg/upload",
                data={"csrf_token": csrf},
                files=files,
                referer="/product/create",
            )
        finally:
            for f in opened:
                try:
                    f.close()
                except Exception:
                    pass

    def tg_get_pool(self) -> Dict[str, Any]:
        """Return current TG pool: ``{success, accounts, groups, ...}``."""
        return self._http.request(
            "GET",
            "/api/tg/pool",
            referer="/product/create",
        )

    def tg_validate(
        self,
        account_id: int,
        *,
        check_spambot: bool = True,
        check_gifts: bool = False,
    ) -> Dict[str, Any]:
        """Run server-side validation on a single TG-pool account.

        This is what the «🚫 Проверять спамблок» / «Проверить» button does.
        """
        csrf = self._http.ensure_csrf("/product/create")
        return self._http.request(
            "POST",
            "/api/tg/validate-one",
            json={
                "csrf_token": csrf,
                "account_id": int(account_id),
                "check_spambot": bool(check_spambot),
                "check_gifts": bool(check_gifts),
            },
            referer="/product/create",
        )

    def tg_delete(self, account_id: int) -> bool:
        csrf = self._http.ensure_csrf("/product/create")
        resp = self._http.request(
            "POST",
            "/api/tg/delete",
            json={"csrf_token": csrf, "id": int(account_id)},
            referer="/product/create",
            raise_status=False,
        )
        return bool(isinstance(resp, dict) and resp.get("success"))

    def tg_publish(
        self,
        *,
        groups: Sequence[Mapping[str, Any]],
        account_type: str = "autoreg",
        subcategory_id: int = 58,
        cropped_image: Optional[str] = None,
        card_style: str = "",
    ) -> Dict[str, Any]:
        """Publish TG-pool accounts as products.

        ``groups`` is a list of ``{account_ids: [..], price: N, title: str,
        description: str}``. Each group becomes a separate product.
        """
        csrf = self._http.ensure_csrf("/product/create")
        return self._http.request(
            "POST",
            "/api/tg/publish",
            json={
                "csrf_token": csrf,
                "subcategory_id": int(subcategory_id),
                "account_type": account_type,
                "cropped_image": cropped_image,
                "card_style": card_style,
                "groups": list(groups),
            },
            referer="/product/create",
        )

    def get_tg_active_listings(self) -> List[Product]:
        """Return *active* listings in the Telegram-Accounts category.

        Heuristic: matches products whose title starts with «Telegram аккаунт»
        and status == ``"active"``. Cheaper than re-fetching subcategory id
        on every call.
        """
        out: List[Product] = []
        for p in self.get_my_products(status="active"):
            title = (p.title or "").lower()
            if "telegram" in title and (
                "аккаунт" in title or "акк " in title
            ):
                out.append(p)
        return out

    # ------------------------------------------------------------------
    # products
    # ------------------------------------------------------------------
    def get_my_products(
        self, status: Optional[str] = None
    ) -> List[Product]:
        """List my products. ``status`` ∈ {"active","hidden","sold"} or ``None``."""
        path = "/profile/products"
        if status:
            path = f"{path}?status={status}"
        html = self._http.get_html(path)
        return parse_products(html)

    def get_product(self, product_id: int) -> Optional[Product]:
        items = self.get_my_products()
        for p in items:
            if p.id == int(product_id):
                return p
        return None

    def create_product(
        self,
        *,
        title: str,
        price: float,
        category_id: int,
        subcategory_id: int,
        delivery_content: str = "",
        description: str = "",
        image_path: Optional[str] = None,
        extra_images: Optional[Sequence[str]] = None,
        currency_code: str = "RUB",
        price_unit: str = "шт",
        min_qty: int = 1,
        quantity: int = 1,
        auto_delivery: bool = True,
        stock_type: str = "text",
        buyer_instruction: str = "",
        account_type: str = "",
        card_style: str = "",
        keywords: str = "",
    ) -> Product:
        csrf = self._http.ensure_csrf("/product/create")
        data = {
            "csrf_token": csrf,
            "title": title,
            "price": str(price),
            "category_id": str(category_id),
            "subcategory_id": str(subcategory_id),
            "description": description,
            "stock_content": delivery_content,
            "stock_type": stock_type,
            "currency_code": currency_code,
            "price_unit": price_unit,
            "min_qty": str(min_qty),
            "quantity": str(quantity),
            "auto_delivery": "1" if auto_delivery else "0",
            "buyer_instruction": buyer_instruction,
            "account_type": account_type,
            "card_style": card_style,
            "keywords": keywords,
        }
        files: Dict[str, Any] = {}
        if image_path:
            files["image"] = (os.path.basename(image_path), open(image_path, "rb"))
        if extra_images:
            for i, p in enumerate(list(extra_images)[:3], start=1):
                files[f"extra_image_{i}"] = (os.path.basename(p), open(p, "rb"))
        resp = self._http.request(
            "POST",
            "/product/create",
            data=data,
            files=files or None,
            referer="/product/create",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        loc = resp.headers.get("Location", "")
        m = re.search(r"/product/(\d+)", loc)
        new_id = int(m.group(1)) if m else 0
        return Product(id=new_id, title=title, price=price, status="active")

    def update_product(self, product_id: int, **fields: Any) -> bool:
        csrf = self._http.ensure_csrf(f"/product/{product_id}/edit")
        data = {"csrf_token": csrf}
        for k, v in fields.items():
            if v is None:
                continue
            data[k] = str(v) if not isinstance(v, (str, bytes)) else v
        self._http.request(
            "POST",
            f"/product/{product_id}/edit",
            data=data,
            referer=f"/product/{product_id}/edit",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    def delete_product(self, product_id: int) -> bool:
        csrf = self._http.ensure_csrf("/profile/products")
        self._http.request(
            "POST",
            f"/product/{product_id}/delete",
            data={"csrf_token": csrf},
            referer="/profile/products",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    def toggle_product_visibility(self, product_id: int) -> Dict[str, Any]:
        csrf = self._http.ensure_csrf("/profile/products")
        data = self._http.post_json(
            f"/api/product/{product_id}/toggle-visibility",
            json={"csrf_token": csrf},
            referer="/profile/products",
        )
        return data if isinstance(data, dict) else {"success": True}

    def hide_product(self, product_id: int) -> bool:
        p = self.get_product(product_id)
        if p and p.status == "hidden":
            return True
        self.toggle_product_visibility(product_id)
        return True

    def show_product(self, product_id: int) -> bool:
        p = self.get_product(product_id)
        if p and p.status != "hidden":
            return True
        self.toggle_product_visibility(product_id)
        return True

    def bulk_hide_products(
        self,
        ids: Optional[Sequence[int]] = None,
        *,
        all_active: bool = False,
    ) -> Dict[str, Any]:
        csrf = self._http.ensure_csrf("/profile/products")
        body: Dict[str, Any] = {"csrf_token": csrf}
        if all_active:
            body["all_active"] = True
        if ids:
            body["ids"] = list(ids)
        data = self._http.post_json(
            "/api/products/bulk-hide",
            json=body,
            referer="/profile/products",
        )
        return data if isinstance(data, dict) else {"success": True}

    def bulk_show_products(
        self,
        ids: Optional[Sequence[int]] = None,
        *,
        all_hidden: bool = False,
    ) -> Dict[str, Any]:
        csrf = self._http.ensure_csrf("/profile/products?status=hidden")
        body: Dict[str, Any] = {"csrf_token": csrf}
        if all_hidden:
            body["all_hidden"] = True
        if ids:
            body["ids"] = list(ids)
        data = self._http.post_json(
            "/api/products/bulk-show",
            json=body,
            referer="/profile/products?status=hidden",
        )
        return data if isinstance(data, dict) else {"success": True}

    # ------------------------------------------------------------------
    # bump
    # ------------------------------------------------------------------
    def get_bump_info(self, product_id: int) -> BumpInfo:
        data = self._http.get_json(
            f"/api/product/{product_id}/bump-info",
            referer="/profile/products",
        )
        if not isinstance(data, Mapping):
            raise DipXError("bump-info: unexpected response")
        return BumpInfo(
            free_available=bool(data.get("free_available", False)),
            paid_available=bool(data.get("paid_available", False)),
            free_next_at=data.get("free_next_at") or None,
            free_cooldown_hours=int(data.get("free_cooldown_hours", 0) or 0),
            daily_used=int(data.get("daily_used", 0) or 0),
            daily_limit=int(data.get("daily_limit", 10) or 10),
            daily_left=int(data.get("daily_left", 10) or 10),
            bump_price=int(data.get("bump_price", 15) or 15),
            next_price=int(data.get("next_price", 25) or 25),
            bump_count=int(data.get("bump_count", 0) or 0),
            is_paid_active=bool(data.get("is_paid_active", False)),
            paid_expires_hours=int(data.get("paid_expires_hours", 0) or 0),
            paid_duration=int(data.get("paid_duration", 12) or 12),
            raw=dict(data),
        )

    def bump_product(self, product_id: int, paid: bool = False) -> bool:
        csrf = self._http.ensure_csrf("/profile/products")
        body = {"csrf_token": csrf, "paid": bool(paid)}
        try:
            data = self._http.post_json(
                f"/api/product/{product_id}/bump",
                json=body,
                referer="/profile/products",
            )
        except (ValidationError, DipXError):
            return False
        if isinstance(data, Mapping):
            return bool(data.get("success", True))
        return True

    def bump_all_free(self) -> Dict[int, bool]:
        """Bump every product that has a free slot. Returns ``{id: ok}``."""
        result: Dict[int, bool] = {}
        for p in self.get_my_products(status="active"):
            try:
                info = self.get_bump_info(p.id)
            except DipXError:
                result[p.id] = False
                continue
            if info.free_available:
                result[p.id] = self.bump_product(p.id, paid=False)
            else:
                result[p.id] = False
        return result

    def setup_auto_bump(self, product_ids: Sequence[int]) -> bool:
        csrf = self._http.ensure_csrf("/profile/products")
        self._http.post_json(
            "/api/auto-bump/save",
            json={
                "csrf_token": csrf,
                "product_ids": [int(x) for x in product_ids],
            },
            referer="/profile/products",
        )
        return True

    def cancel_auto_bump(self) -> bool:
        csrf = self._http.ensure_csrf("/profile/products")
        self._http.post_json(
            "/api/auto-bump/cancel",
            json={"csrf_token": csrf},
            referer="/profile/products",
        )
        return True

    def resume_auto_bump(self) -> bool:
        csrf = self._http.ensure_csrf("/profile/products")
        self._http.post_json(
            "/api/auto-bump/resume",
            json={"csrf_token": csrf},
            referer="/profile/products",
        )
        return True

    def buy_auto_bump_plugin(self) -> bool:
        """Purchase the AutoBump plugin (plugin ID 7, 30 ₽/month)."""
        csrf = self._http.ensure_csrf("/plugins")
        self._http.request(
            "POST",
            "/plugins/7/purchase",
            data={"csrf_token": csrf},
            referer="/plugins",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    # ------------------------------------------------------------------
    # orders
    # ------------------------------------------------------------------
    def get_orders(
        self,
        role: str = "buyer",
        status: Optional[str] = None,
    ) -> List[Order]:
        """Return orders. ``role`` ∈ {"buyer","seller"}.

        ``status`` filters client-side (the site doesn't expose it as a query
        param).
        """
        qs = "purchases" if role == "buyer" else "sales"
        html = self._http.get_html(f"/profile/orders?type={qs}")
        orders = parse_orders(html, role=role)
        if status:
            orders = [o for o in orders if o.status == status]
        return orders

    def get_order(self, order_id: int) -> Optional[Order]:
        """Try to find the order in either tab."""
        for role in ("buyer", "seller"):
            for o in self.get_orders(role=role):
                if o.id == int(order_id):
                    return o
        return None

    def request_refund(self, order_id: int) -> bool:
        csrf = self._http.ensure_csrf("/profile/orders?type=sales")
        self._http.post_json(
            f"/api/order/{order_id}/refund",
            json={"csrf_token": csrf},
            referer="/profile/orders",
        )
        return True

    # Alias kept for parity with documented API.
    confirm_order = request_refund  # noqa: E305
    dispute_order = request_refund
    cancel_order = request_refund

    def file_complaint(
        self,
        *,
        order_id: Optional[int] = None,
        target_user_id: Optional[int] = None,
        target_product_id: Optional[int] = None,
        type: str = "fraud",
        description: str = "",
    ) -> bool:
        csrf = self._http.ensure_csrf("/profile")
        body: Dict[str, Any] = {
            "csrf_token": csrf,
            "type": type,
            "description": description,
        }
        if order_id:
            body["order_id"] = int(order_id)
        if target_user_id:
            body["target_user_id"] = int(target_user_id)
        if target_product_id:
            body["target_product_id"] = int(target_product_id)
        self._http.post_json(
            "/api/complaint", json=body, referer="/profile"
        )
        return True

    # ------------------------------------------------------------------
    # chat
    # ------------------------------------------------------------------
    def get_conversations(
        self,
        filter: str = "all",
        offset: int = 0,
    ) -> List[Conversation]:
        path = "/api/conversations"
        if filter and filter != "all":
            path = f"/api/conversations/more?offset={offset}&filter={filter}"
        elif offset:
            path = f"/api/conversations/more?offset={offset}"
        data = self._http.get_json(path, referer="/messages")
        items = (data or {}).get("conversations", []) if isinstance(data, Mapping) else []
        out: List[Conversation] = []
        for c in items:
            try:
                rating = float(c.get("partner_rating", 0))
            except (TypeError, ValueError):
                rating = 0.0
            out.append(
                Conversation(
                    id=int(c.get("id", 0)),
                    partner_id=int(c.get("partner_id", 0)),
                    partner_name=c.get("partner_name", ""),
                    partner_avatar=c.get("partner_avatar"),
                    partner_online=bool(c.get("partner_online", False)),
                    partner_verified=bool(c.get("partner_verified", False)),
                    partner_trusted=bool(c.get("partner_trusted", False)),
                    partner_rating=rating,
                    partner_sales=int(c.get("partner_sales", 0) or 0),
                    last_message=c.get("last_message"),
                    last_message_at=c.get("last_message_at"),
                    last_message_ago=c.get("last_message_ago"),
                    last_is_own=bool(c.get("last_is_own", False)),
                    last_is_system=bool(c.get("last_is_system", False)),
                    last_is_read=bool(c.get("last_is_read", True)),
                    unread_count=int(c.get("unread_count", 0) or 0),
                    active_order_count=int(c.get("active_order_count", 0) or 0),
                    active_order_amount=(
                        float(c["active_order_amount"])
                        if c.get("active_order_amount") is not None
                        else None
                    ),
                    is_pinned=bool(c.get("is_pinned", False)),
                    raw=dict(c),
                )
            )
        return out

    def get_unread_count(self) -> int:
        data = self._http.get_json("/api/unread-count", referer="/messages")
        return int((data or {}).get("count", 0)) if isinstance(data, Mapping) else 0

    def get_messages(
        self, conv_id: int, last_id: int = 0
    ) -> List[Message]:
        path = f"/api/private-messages/{int(conv_id)}?last_id={int(last_id)}"
        data = self._http.get_json(path, referer=f"/messages/{conv_id}")
        return _parse_messages(data, conv_id)

    def get_older_messages(
        self, conv_id: int, before_id: int
    ) -> List[Message]:
        path = (
            f"/api/private-messages/{int(conv_id)}/older?before_id={int(before_id)}"
        )
        data = self._http.get_json(path, referer=f"/messages/{conv_id}")
        return _parse_messages(data, conv_id)

    def get_media(
        self, conv_id: int, tab: str = "photo"
    ) -> List[Dict[str, Any]]:
        path = f"/api/private-messages/{int(conv_id)}/media?tab={tab}"
        data = self._http.get_json(path, referer=f"/messages/{conv_id}")
        if isinstance(data, Mapping):
            return list(data.get("items", []))
        return []

    def send_message(
        self,
        conv_id: int,
        text: str = "",
        *,
        attachment_path: Optional[str] = None,
        product_id: Optional[int] = None,
        reply_to_id: Optional[int] = None,
    ) -> Optional[Message]:
        csrf = self._http.ensure_csrf(f"/messages/{conv_id}")
        data: Dict[str, Any] = {"csrf_token": csrf, "message": text}
        if product_id is not None:
            data["product_id"] = str(product_id)
        if reply_to_id is not None:
            data["reply_to_id"] = str(reply_to_id)
        files = None
        if attachment_path:
            files = {
                "attachment": (
                    os.path.basename(attachment_path),
                    open(attachment_path, "rb"),
                )
            }
        body = self._http.post_json(
            f"/messages/{conv_id}/send",
            data=data,
            files=files,
            referer=f"/messages/{conv_id}",
        )
        if isinstance(body, Mapping) and body.get("message"):
            return _parse_messages({"messages": [body["message"]]}, conv_id)[0]
        return None

    def delete_conversation(self, conv_id: int) -> bool:
        csrf = self._http.ensure_csrf(f"/messages/{conv_id}")
        self._http.request(
            "POST",
            f"/messages/{conv_id}/delete",
            data={"csrf_token": csrf},
            referer=f"/messages/{conv_id}",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    def pin_conversation(self, conv_id: int) -> bool:
        csrf = self._http.ensure_csrf(f"/messages/{conv_id}")
        self._http.post_json(
            f"/api/conversation/{conv_id}/pin-toggle",
            json={"csrf_token": csrf},
            referer="/messages",
        )
        return True

    # ------------------------------------------------------------------
    # block / mute
    # ------------------------------------------------------------------
    def block_user(self, user_id: int) -> bool:
        csrf = self._http.ensure_csrf("/messages")
        self._http.post_json(
            "/api/user/block",
            json={"csrf_token": csrf, "user_id": int(user_id)},
            referer="/messages",
        )
        return True

    def mute_user(self, user_id: int) -> bool:
        csrf = self._http.ensure_csrf("/messages")
        self._http.post_json(
            "/api/user/mute",
            json={"csrf_token": csrf, "user_id": int(user_id)},
            referer="/messages",
        )
        return True

    def get_blocked_users(self) -> List[Dict[str, Any]]:
        data = self._http.get_json(
            "/api/user/blocked-list", referer="/messages"
        )
        if isinstance(data, Mapping):
            return list(data.get("items", []))
        return []

    # ------------------------------------------------------------------
    # wishlist
    # ------------------------------------------------------------------
    def check_wishlist(self, product_ids: Sequence[int]) -> List[int]:
        csrf = self._http.ensure_csrf("/profile/wishlist")
        data = self._http.post_json(
            "/api/wishlist/check",
            json={"csrf_token": csrf, "ids": [int(x) for x in product_ids]},
            referer="/profile/wishlist",
        )
        if isinstance(data, Mapping):
            return list(data.get("ids", data.get("in_wishlist", [])))
        return []

    def toggle_wishlist(self, product_id: int) -> WishlistResult:
        csrf = self._http.ensure_csrf("/profile/wishlist")
        data = self._http.post_json(
            f"/api/wishlist/{int(product_id)}/toggle",
            json={"csrf_token": csrf},
            referer="/profile/wishlist",
        )
        if isinstance(data, Mapping):
            return WishlistResult(
                success=bool(data.get("success", True)),
                added=bool(data.get("added", False)),
                count=int(data.get("count", 0) or 0),
                raw=dict(data),
            )
        return WishlistResult(success=True, added=False, count=0)

    def add_to_wishlist(self, product_id: int) -> bool:
        result = self.toggle_wishlist(product_id)
        if not result.added:
            # already in list — toggle once more would remove, so leave as-is
            pass
        return True

    def remove_from_wishlist(self, product_id: int) -> bool:
        result = self.toggle_wishlist(product_id)
        if result.added:
            # we accidentally added — toggle back
            self.toggle_wishlist(product_id)
        return True

    # ------------------------------------------------------------------
    # reviews
    # ------------------------------------------------------------------
    def leave_review(
        self, order_id: int, rating: int = 5, text: str = ""
    ) -> bool:
        csrf = self._http.ensure_csrf("/profile/orders")
        self._http.request(
            "POST",
            f"/review/create/{int(order_id)}",
            data={
                "csrf_token": csrf,
                "rating": str(int(rating)),
                "comment": text,
            },
            referer="/profile/orders",
            as_json=False,
            allow_redirects=False,
            raise_status=False,
        )
        return True

    def get_user_reviews(
        self, user_id: int, page: int = 1
    ) -> List[Review]:
        data = self._http.get_json(
            f"/api/user/{int(user_id)}/reviews?page={int(page)}",
            referer=f"/user/{user_id}",
        )
        out: List[Review] = []
        items = (data or {}).get("items", []) if isinstance(data, Mapping) else []
        for r in items:
            out.append(
                Review(
                    id=int(r.get("id", 0)),
                    user_id=int(r.get("user_id", 0) or 0),
                    rating=int(r.get("rating", 0) or 0),
                    text=r.get("comment", r.get("text", "")),
                    created_at=r.get("created_at", ""),
                    reply=r.get("reply"),
                    raw=dict(r),
                )
            )
        return out

    def reply_to_review(self, review_id: int, text: str) -> bool:
        csrf = self._http.ensure_csrf("/profile")
        self._http.post_json(
            f"/api/review/{int(review_id)}/reply",
            json={"csrf_token": csrf, "reply": text},
            referer="/profile",
        )
        return True

    def delete_review_reply(self, review_id: int) -> bool:
        csrf = self._http.ensure_csrf("/profile")
        self._http.post_json(
            f"/api/review/{int(review_id)}/reply/delete",
            json={"csrf_token": csrf},
            referer="/profile",
        )
        return True

    # ------------------------------------------------------------------
    # notifications
    # ------------------------------------------------------------------
    def get_notification_settings(self) -> NotificationSettings:
        data = self._http.get_json(
            "/api/notifications/settings", referer="/profile/edit"
        )
        if not isinstance(data, Mapping):
            raise DipXError("notifications/settings: unexpected response")
        return NotificationSettings(
            telegram_linked=bool(data.get("telegram_linked", False)),
            telegram_orders=bool(data.get("telegram_orders", False)),
            telegram_messages=bool(data.get("telegram_messages", False)),
            vk_linked=bool(data.get("vk_linked", False)),
            vk_orders=bool(data.get("vk_orders", False)),
            vk_messages=bool(data.get("vk_messages", False)),
            browser=bool(data.get("browser", False)),
            push_orders=bool(data.get("push_orders", False)),
            push_messages=bool(data.get("push_messages", False)),
            push_deposits=bool(data.get("push_deposits", False)),
            push_subscribed=bool(data.get("push_subscribed", False)),
            live_feed_hidden=bool(data.get("live_feed_hidden", False)),
            bot_username=data.get("bot_username"),
            raw=dict(data),
        )

    def update_notification_settings(self, **flags: bool) -> bool:
        csrf = self._http.ensure_csrf("/profile/edit")
        data: Dict[str, Any] = {"csrf_token": csrf}
        for k, v in flags.items():
            data[k] = "1" if v else "0"
        self._http.request(
            "POST",
            "/api/notifications/settings",
            data=data,
            referer="/profile/edit",
            as_json=False,
            raise_status=False,
        )
        return True

    # ------------------------------------------------------------------
    # integrations
    # ------------------------------------------------------------------
    def link_telegram(self, token: str) -> bool:
        csrf = self._http.ensure_csrf("/profile/edit")
        self._http.request(
            "POST",
            "/api/telegram/link",
            data={"csrf_token": csrf, "token": token},
            referer="/profile/edit",
            as_json=False,
            raise_status=False,
        )
        return True

    def unlink_telegram(self) -> bool:
        csrf = self._http.ensure_csrf("/profile/edit")
        self._http.request(
            "POST",
            "/api/telegram/unlink",
            data={"csrf_token": csrf},
            referer="/profile/edit",
            as_json=False,
            raise_status=False,
        )
        return True

    def unlink_vk(self) -> bool:
        csrf = self._http.ensure_csrf("/profile/edit")
        self._http.request(
            "POST",
            "/api/vk/unlink",
            data={"csrf_token": csrf},
            referer="/profile/edit",
            as_json=False,
            raise_status=False,
        )
        return True

    # ------------------------------------------------------------------
    # stats / analytics
    # ------------------------------------------------------------------
    def get_activity_heatmap(self) -> Dict[str, Any]:
        data = self._http.get_json(
            "/api/analytics/activity-heatmap", referer="/profile/analytics"
        )
        return data if isinstance(data, dict) else {}

    def get_today_earnings(self) -> float:
        """Sum every positive transaction whose ``created_at`` is today."""
        from datetime import datetime
        today = datetime.now().strftime("%d.%m.%Y")
        total = 0.0
        for tx in self.get_transactions(page=1):
            if tx.is_positive and tx.created_at.startswith(today):
                total += tx.amount
        return total

    def get_stats(self) -> Dict[str, Any]:
        """Aggregate quick stats for dashboards."""
        bal = self.get_balance()
        products = self.get_my_products()
        sales = self.get_orders(role="seller")
        purchases = self.get_orders(role="buyer")
        return {
            "balance": bal.__dict__,
            "products_total": len(products),
            "products_active": sum(1 for p in products if p.status == "active"),
            "products_hidden": sum(1 for p in products if p.status == "hidden"),
            "products_sold": sum(1 for p in products if p.status == "sold"),
            "sales_total": len(sales),
            "purchases_total": len(purchases),
            "earned_today": self.get_today_earnings(),
            "unread_messages": self.get_unread_count(),
        }


# ──────────────────────────────────────────────────────────────────────
# helpers
# ──────────────────────────────────────────────────────────────────────
def _parse_messages(data: Any, conv_id: int) -> List[Message]:
    if not isinstance(data, Mapping):
        return []
    items = data.get("messages", data.get("items", []))
    out: List[Message] = []
    for m in items:
        if not isinstance(m, Mapping):
            continue
        out.append(
            Message(
                id=int(m.get("id", 0)),
                conv_id=int(conv_id),
                text=m.get("text", m.get("message", "")),
                is_own=bool(m.get("is_own", False)),
                is_system=bool(m.get("is_system", False)),
                created_at=m.get("created_at"),
                attachment=m.get("attachment"),
                product_id=int(m["product_id"]) if m.get("product_id") else None,
                raw=dict(m),
            )
        )
    return out


__all__ = ["DipXClient"]
