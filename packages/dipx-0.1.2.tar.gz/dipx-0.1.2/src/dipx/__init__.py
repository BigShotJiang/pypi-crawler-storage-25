"""Python client for the dip-x.store marketplace.

Quick start::

    from dipx import DipXClient

    client = DipXClient()
    profile = client.login("Lincoln", "password")
    print(profile.username, profile.id)

    for p in client.get_my_products():
        print(p.id, p.title, p.price, p.status)

    client.logout()
"""

from .client import DipXClient
from .exceptions import (
    AuthError,
    DipXError,
    InsufficientBalanceError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .models import (
    Balance,
    BumpInfo,
    Conversation,
    Message,
    NotificationSettings,
    Order,
    Product,
    Profile,
    Review,
    Transaction,
    WishlistResult,
)

__version__ = "0.1.1"

__all__ = [
    "DipXClient",
    "AuthError",
    "DipXError",
    "InsufficientBalanceError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    "Balance",
    "BumpInfo",
    "Conversation",
    "Message",
    "NotificationSettings",
    "Order",
    "Product",
    "Profile",
    "Review",
    "Transaction",
    "WishlistResult",
]
