"""Exceptions for the ``dipx`` package."""

from __future__ import annotations

from typing import Any, Optional


class DipXError(Exception):
    """Base error for every problem raised by ``dipx``.

    Attributes:
        status_code: HTTP status code of the offending response (if any).
        payload: parsed JSON body of the response (if any).
    """

    def __init__(
        self,
        message: str = "DipX error",
        *,
        status_code: Optional[int] = None,
        payload: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload

    def __str__(self) -> str:  # pragma: no cover - trivial
        base = super().__str__()
        if self.status_code is not None:
            return f"[{self.status_code}] {base}"
        return base


class AuthError(DipXError):
    """Authentication failed or session expired."""


class NotFoundError(DipXError):
    """Server returned 404 / "not found"."""


class ValidationError(DipXError):
    """Server returned 400 / payload rejected."""


class InsufficientBalanceError(DipXError):
    """Operation requires more funds than user has."""


class RateLimitError(DipXError):
    """Server returned 429 / rate-limited."""
