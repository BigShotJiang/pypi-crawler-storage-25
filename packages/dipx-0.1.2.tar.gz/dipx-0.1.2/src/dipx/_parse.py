"""HTML scraping helpers — used wherever the site does not return JSON.

The marketplace renders many lists (products, orders, conversations) as
server-side HTML. We parse them with BeautifulSoup. Keep selectors as
small and tolerant as possible — the site changes its markup.
"""

from __future__ import annotations

import re
from typing import List, Optional

from bs4 import BeautifulSoup

from .models import Balance, Order, Product, Profile


_NUMBER_RE = re.compile(r"-?\d+(?:[.,]\d+)?")


def _to_float(text: Optional[str]) -> float:
    if not text:
        return 0.0
    m = _NUMBER_RE.search(text.replace("\u00a0", "").replace(" ", ""))
    return float(m.group(0).replace(",", ".")) if m else 0.0


def _to_int(text: Optional[str]) -> int:
    if not text:
        return 0
    m = _NUMBER_RE.search(text.replace("\u00a0", "").replace(" ", ""))
    return int(float(m.group(0).replace(",", "."))) if m else 0


def parse_profile_id_from_html(html: str) -> Optional[int]:
    """Extract user ID from various places it may be embedded."""
    for pat in (
        r'data-user-id="(\d+)"',
        r'"user_id":(\d+)',
        r'"id":(\d+),"username"',
        r'/user/[^"]+"[^>]*data-id="(\d+)"',
    ):
        m = re.search(pat, html)
        if m:
            return int(m.group(1))
    return None


def parse_profile(html: str, *, username: str) -> Profile:
    soup = BeautifulSoup(html, "html.parser")
    uid = parse_profile_id_from_html(html) or 0
    avatar = None
    img = soup.select_one(".profile-card__avatar img, .user-card__avatar img")
    if img and img.get("src"):
        avatar = img["src"]
    return Profile(id=uid, username=username, avatar=avatar)


def parse_balance(html: str) -> Balance:
    """Parse ``/profile/balance`` page into a :class:`Balance`."""
    soup = BeautifulSoup(html, "html.parser")
    total = 0.0
    available = 0.0
    frozen = 0.0
    bv = soup.select_one("#balanceValue, .profile-balance__value")
    if bv:
        total = _to_float(bv.get_text())
    # Some pages expose frozen/available in chips:
    for chip in soup.select(".balance-chip, .profile-balance__chip, .balance-block"):
        txt = chip.get_text(" ", strip=True).lower()
        if "доступ" in txt:
            available = _to_float(txt) or available
        elif "заморож" in txt or "холд" in txt:
            frozen = _to_float(txt) or frozen
    # Withdrawal form gives a hard upper bound on available
    inp = soup.select_one('form#withdrawalForm input[name="amount"]')
    if inp and inp.get("max"):
        try:
            available = max(available, float(inp["max"]))
        except ValueError:
            pass
    if available == 0.0 and frozen == 0.0:
        available = total
    return Balance(total=total, available=available, frozen=frozen)


def parse_products(html: str) -> List[Product]:
    soup = BeautifulSoup(html, "html.parser")
    out: List[Product] = []
    for row in soup.select(".product-row"):
        pid = row.get("data-id") or row.get("data-product-id") or "0"
        status = row.get("data-status") or "active"
        title_el = row.select_one(".product-row__title")
        price_el = row.select_one(".product-row__price")
        views_el = row.select_one(".product-row__views")
        sales_el = row.select_one(".product-row__sales")
        date_el = row.select_one(".product-row__date")
        link_el = row.select_one(".product-row__main, a[href*='/product/']")
        img_el = row.select_one(".product-row__image img")
        out.append(
            Product(
                id=int(pid) if str(pid).isdigit() else 0,
                title=title_el.get_text(strip=True) if title_el else "",
                price=_to_float(price_el.get_text() if price_el else ""),
                status=status,
                views=_to_int(views_el.get_text() if views_el else ""),
                sales=_to_int(sales_el.get_text() if sales_el else ""),
                url=link_el.get("href") if link_el else None,
                image=img_el.get("src") if img_el else None,
                created_at=date_el.get_text(strip=True) if date_el else None,
            )
        )
    return out


def parse_orders(html: str, *, role: str) -> List[Order]:
    soup = BeautifulSoup(html, "html.parser")
    out: List[Order] = []
    for row in soup.select(".order-row"):
        link = row.select_one("a[href*='/order/']")
        oid = 0
        if link and link.get("href"):
            m = re.search(r"/order/(\d+)", link["href"])
            if m:
                oid = int(m.group(1))
        title_el = row.select_one(".order-row__title")
        price_el = row.select_one(".order-row__price")
        date_el = row.select_one(".order-row__date")
        user_el = row.select_one(".order-row__user")
        badge_el = row.select_one(".badge, .order-row__status")
        status = "unknown"
        if badge_el:
            txt = badge_el.get_text(strip=True).lower()
            if "заверш" in txt or "выпол" in txt:
                status = "completed"
            elif "ожид" in txt or "пенд" in txt:
                status = "pending"
            elif "отмен" in txt:
                status = "cancelled"
            elif "возвр" in txt or "refund" in txt:
                status = "refunded"
            elif "спор" in txt or "dispute" in txt:
                status = "disputed"
            else:
                status = txt
        out.append(
            Order(
                id=oid,
                product_title=title_el.get_text(strip=True) if title_el else "",
                amount=_to_float(price_el.get_text() if price_el else ""),
                status=status,
                role=role,
                partner=user_el.get_text(strip=True) if user_el else "",
                date=date_el.get_text(strip=True) if date_el else None,
            )
        )
    return out
