# dipx

Python client for the [dip-x.store](https://dip-x.store) marketplace.

```bash
pip install dipx
```

```python
from dipx import DipXClient

client = DipXClient()
profile = client.login("Lincoln", "your_password")

print(profile.username)  # Lincoln
print(profile.id)        # 10434

bal = client.get_balance()
print(f"Total: {bal.total} ₽ (available {bal.available} ₽, frozen {bal.frozen} ₽)")

for p in client.get_my_products():
    print(f"[{p.id}] {p.title} — {p.price} ₽  ({p.status})")

client.logout()
```

See [the full method reference](#api-overview) below.

## Features

- 🔐 login / logout / profile / change password
- 💰 balance, transactions, deposit (lolz, platega, anypay, cryptobot, ...)
- 📦 products: list / create / update / delete / hide / show / bulk-ops
- 🚀 bump: free / paid + plugin-based auto-bump
- 🛒 orders: list, refund, complaint
- 💬 chat: list conversations, get/send/load older messages, media, pin, delete
- 🚫 block / mute users + blocklist
- ❤️ wishlist: check / toggle / add / remove
- ⭐ reviews: leave / reply / list
- 🔔 notifications: get / update settings
- 🔗 integrations: Telegram / VK link & unlink
- 📊 stats: heatmap, today's earnings, dashboard

## Exception types

```python
from dipx import (
    AuthError,
    NotFoundError,
    ValidationError,
    InsufficientBalanceError,
    RateLimitError,
    DipXError,
)
```

All exceptions carry a `status_code` (HTTP) and optional `payload` (parsed JSON
body).

## API overview

| Group           | Methods                                                                                                                                         |
|-----------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| Auth            | `login`, `logout`, `me`                                                                                                                         |
| Profile         | `get_profile`, `update_profile`, `change_password`                                                                                              |
| Balance         | `get_balance`, `get_transactions`, `create_deposit`, `request_withdrawal`                                                                       |
| Products        | `get_my_products`, `get_product`, `create_product`, `update_product`, `delete_product`, `hide_product`, `show_product`, `toggle_product_visibility`, `bulk_hide_products`, `bulk_show_products` |
| Bump            | `get_bump_info`, `bump_product`, `bump_all_free`, `setup_auto_bump`, `cancel_auto_bump`, `resume_auto_bump`, `buy_auto_bump_plugin`             |
| Orders          | `get_orders`, `get_order`, `request_refund`, `confirm_order`, `cancel_order`, `dispute_order`, `file_complaint`                                 |
| Chat            | `get_conversations`, `get_unread_count`, `get_messages`, `get_older_messages`, `send_message`, `get_media`, `pin_conversation`, `delete_conversation` |
| Block / Mute    | `block_user`, `mute_user`, `get_blocked_users`                                                                                                  |
| Wishlist        | `check_wishlist`, `toggle_wishlist`, `add_to_wishlist`, `remove_from_wishlist`                                                                  |
| Reviews         | `leave_review`, `reply_to_review`, `delete_review_reply`, `get_user_reviews`                                                                    |
| Notifications   | `get_notification_settings`, `update_notification_settings`                                                                                     |
| Integrations    | `link_telegram`, `unlink_telegram`, `unlink_vk`                                                                                                 |
| Stats           | `get_activity_heatmap`, `get_today_earnings`, `get_stats`                                                                                       |

## License

MIT
