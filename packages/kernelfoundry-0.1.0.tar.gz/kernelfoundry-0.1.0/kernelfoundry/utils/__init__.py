"""Utility helpers for kernelfoundry."""
