# Copyright (C) The Arvados Authors. All rights reserved.
#
# SPDX-License-Identifier: AGPL-3.0

import setuptools
import runpy

from pathlib import Path

versuffix = 'b1'
arvados_version = runpy.run_path(Path(__file__).with_name('arvados_version.py'))
arv_mod = arvados_version['ARVADOS_PYTHON_MODULES']['arvados-tools']
version = arv_mod.get_version().removesuffix(versuffix)
setuptools.setup(
    install_requires=[
        *arv_mod.iter_dependencies(version=version),
    ],
    version=f'{version}{versuffix}',
)
