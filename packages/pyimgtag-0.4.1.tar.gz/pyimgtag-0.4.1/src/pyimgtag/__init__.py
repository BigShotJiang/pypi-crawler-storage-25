"""pyimgtag — Tag macOS Photos library images using local Gemma model."""

__version__ = "0.4.1"

__all__ = ["__version__"]
