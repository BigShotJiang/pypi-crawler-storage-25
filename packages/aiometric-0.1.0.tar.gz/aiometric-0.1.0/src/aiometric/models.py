"""This module defines data models for representing the state and settings of LaMetric devices, as well as the structure of notifications and cloud-connected devices."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from ipaddress import IPv4Address

from awesomeversion import AwesomeVersion
from mashumaro import field_options
from mashumaro.config import BaseConfig
from mashumaro.mixins.orjson import DataClassORJSONMixin

from .const import (
    AlarmSound,
    CanvasFillType,
    CanvasRenderMode,
    CloudDeviceState,
    DeviceMode,
    DeviceModel,
    DisplayMode,
    DisplayType,
    EffectType,
    IconType,
    IpAddressMode,
    NotificationPriority,
    NotificationSound,
    NotificationType,
    PostProcessingType,
    SoundCategory,
    StreamingState,
    WifiEncryptionType,
)


@dataclass(kw_only=True)
class ValueRange(DataClassORJSONMixin):
    """Represents a range of values with a minimum and maximum."""

    min: int
    max: int


@dataclass(kw_only=True)
class AudioState(DataClassORJSONMixin):
    """Represents the audio settings for a LaMetric device."""

    available: bool
    volume: int | None = None
    volume_range: ValueRange | None = None
    volume_limit: ValueRange | None = None


@dataclass(kw_only=True)
class BluetoothState(DataClassORJSONMixin):
    """Represents the Bluetooth settings for a LaMetric device."""

    available: bool
    active: bool | None = None
    discoverable: bool | None = None
    pairable: bool | None = None
    name: str | None = None
    mac: str | None = None


@dataclass(kw_only=True)
class TimeBasedScreensaver(DataClassORJSONMixin):
    """Represents the time-based screensaver settings for a LaMetric device."""

    enabled: bool
    start_time: datetime
    end_time: datetime
    local_start_time: datetime
    local_end_time: datetime


@dataclass(kw_only=True)
class WhenDarkScreensaver(DataClassORJSONMixin):
    """Represents the when-dark screensaver settings for a LaMetric device."""

    enabled: bool


@dataclass(kw_only=True)
class Screensaver(DataClassORJSONMixin):
    """Represents the screensaver settings for a LaMetric device."""

    enabled: bool
    modes: list[TimeBasedScreensaver | WhenDarkScreensaver]
    widget: str


@dataclass(kw_only=True)
class DisplayState(DataClassORJSONMixin):
    """Represents the display settings for a LaMetric device."""

    brightness: int
    brightness_mode: DisplayMode
    width: int
    height: int
    type: DisplayType
    # API v2.0 and above
    on: bool | None = None
    screensaver: Screensaver | None = None
    brightness_range: ValueRange | None = None
    brightness_limit: ValueRange | None = None


@dataclass(kw_only=True)
class WifiState(DataClassORJSONMixin):
    """Represents the Wi-Fi settings for a LaMetric device."""

    available: bool
    active: bool
    encryption: WifiEncryptionType
    ipv4: IPv4Address
    mac: str
    mode: IpAddressMode
    netmask: IPv4Address
    signal_strength: int
    ssid: str


@dataclass(kw_only=True)
class Update(DataClassORJSONMixin):
    """Represents the update information for a LaMetric device."""

    version: AwesomeVersion


@dataclass(kw_only=True)
class DeviceState(DataClassORJSONMixin):
    """Represents a LaMetric device with its various settings."""

    id: int
    name: str
    serial_number: str
    os_version: AwesomeVersion
    model: DeviceModel
    mode: DeviceMode
    audio: AudioState
    bluetooth: BluetoothState
    display: DisplayState
    wifi: WifiState
    # API v2.3.0 and above
    update_available: Update | None = None


@dataclass(kw_only=True)
class ActionParameter(DataClassORJSONMixin):
    """Represents a parameter that can be used in an action for a LaMetric app."""

    data_type: str
    name: str
    required: bool | None = None
    format: str | None = None


@dataclass(kw_only=True)
class AppWidget(DataClassORJSONMixin):
    """Represents a widget that can be displayed by an app on a LaMetric device."""

    index: int
    package: str
    visible: bool | None = None
    settings: dict[str, str] | None = None


@dataclass(kw_only=True)
class App(DataClassORJSONMixin):
    """Represents an app installed on a LaMetric device."""

    package: str
    vendor: str
    version: AwesomeVersion
    version_code: int | str
    title: str | None = None
    actions: dict[str, dict[str, ActionParameter]] | None = None
    triggers: dict[str, dict[str, ActionParameter]] | None = None
    widgets: dict[str, AppWidget] | None = None


@dataclass(kw_only=True)
class SimpleFrame(DataClassORJSONMixin):
    """Represents a simple frame that can be used in a notification for a LaMetric device."""

    icon: int | str | None = None
    text: str | None = None


@dataclass(kw_only=True)
class GoalFrameData(DataClassORJSONMixin):
    """Represents the data for a goal frame that can be used in a notification for a LaMetric device."""

    start: int
    current: int
    end: int
    unit: str | None = None


@dataclass(kw_only=True)
class GoalFrame(DataClassORJSONMixin):
    """Represents a goal frame that can be used in a notification for a LaMetric device."""

    icon: int | str | None = None
    goal_data: GoalFrameData = field(metadata=field_options(alias="goalData"))

    class Config(BaseConfig):
        """Goal frame model configuration."""

        serialize_by_alias = True
        allow_deserialization_not_by_alias = True


@dataclass(kw_only=True)
class SpikeChartFrame(DataClassORJSONMixin):
    """Represents a spike chart frame that can be used in a notification for a LaMetric device."""

    chart_data: list[int] = field(metadata=field_options(alias="chartData"))

    class Config(BaseConfig):
        """Spike chart frame model configuration."""

        serialize_by_alias = True
        allow_deserialization_not_by_alias = True


@dataclass(kw_only=True)
class BuiltinSound(DataClassORJSONMixin):
    """Represents a built-in sound that can be used in a notification for a LaMetric device."""

    category: SoundCategory | None = None
    id: AlarmSound | NotificationSound | None = None

    def __post_init__(self) -> None:
        """Determines the sound category based on the sound ID if the category is not already set."""
        if self.category is not None:
            return

        if isinstance(self.id, AlarmSound):
            self.category = SoundCategory.ALARMS
        elif isinstance(self.id, NotificationSound):
            self.category = SoundCategory.NOTIFICATIONS


@dataclass(kw_only=True)
class WebSound(DataClassORJSONMixin):
    """Represents a web sound that can be used in a notification for a LaMetric device."""

    url: str
    type: str | None = None
    fallback: BuiltinSound | None = None


@dataclass(kw_only=True)
class NotificationModel(DataClassORJSONMixin):
    """Represents the model for a notification that can be sent to a LaMetric device."""

    frames: list[SimpleFrame | GoalFrame | SpikeChartFrame]
    sound: BuiltinSound | WebSound | None = None
    repeat: int = 1
    cycles: int = 1


@dataclass(kw_only=True)
class Notification(DataClassORJSONMixin):
    """Represents a notification that can be sent to a LaMetric device."""

    id: str | None = None
    type: NotificationType | None = None
    priority: NotificationPriority | None = None
    created: datetime | None = None
    expiration_date: datetime | None = None
    model: NotificationModel
    icon_type: IconType | None = None
    lifetime: int | None = None


@dataclass(kw_only=True)
class CloudUser(DataClassORJSONMixin):
    """Represents a user that is connected to the LaMetric cloud."""

    email: str
    name: str
    apps_count: int
    private_device_count: int
    private_apps_count: int


@dataclass(kw_only=True)
class CloudDevice(DataClassORJSONMixin):
    """Represents a LaMetric device that is connected to the cloud."""

    id: int
    name: str
    state: CloudDeviceState
    serial_number: str
    api_key: str
    ipv4_internal: IPv4Address
    mac: str
    wifi_ssid: str


# API v2.3.0 and above
@dataclass(kw_only=True)
class FadingPixelsParameter(DataClassORJSONMixin):
    """Represents the parameters for a fading pixels effect that can be used in post-processing settings when streaming content to a LaMetric device."""

    smooth: bool
    pixel_fill: float
    fade_speed: float
    pixel_base: float


@dataclass(kw_only=True)
class PostProcessingParameter(DataClassORJSONMixin):
    """Represents a parameter for post-processing settings when streaming content to a LaMetric device."""

    effect_type: EffectType
    effect_params: FadingPixelsParameter | None = None


@dataclass(kw_only=True)
class PostProcessing(DataClassORJSONMixin):
    """Represents the post-processing settings for streaming content to a LaMetric device."""

    type: PostProcessingType | None = None
    params: PostProcessingParameter | None = None


@dataclass(kw_only=True)
class CanvasArea(DataClassORJSONMixin):
    """Represents the area of a canvas for streaming content to a LaMetric device."""

    width: int
    height: int


@dataclass(kw_only=True)
class Canvas(DataClassORJSONMixin):
    """Represents the canvas for streaming content to a LaMetric device."""

    fill_type: CanvasFillType | None = None
    render_mode: CanvasRenderMode | None = None
    post_process: PostProcessing | None = None
    pixel: CanvasArea | None = None
    triangle: CanvasArea | None = None


@dataclass(kw_only=True)
class StreamState(DataClassORJSONMixin):
    """Represents the status of a stream being sent to a LaMetric device."""

    protocol: str | None = None
    version: AwesomeVersion | None = None
    port: int
    session_id: str | None = None
    status: StreamingState
    canvas: Canvas
