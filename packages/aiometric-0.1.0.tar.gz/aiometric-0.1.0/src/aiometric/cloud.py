"""This module defines the LaMetricCloud class, which provides methods for interacting with the LaMetric cloud API to retrieve user and device information."""

from __future__ import annotations

import asyncio
import socket
from dataclasses import dataclass
from typing import (
    Any,
    Self,
)

import aiohttp
import backoff
from aiohttp import hdrs
from yarl import URL

from .errors import (
    LaMetricAuthenticationError,
    LaMetricConnectionError,
    LaMetricConnectionTimeoutError,
    LaMetricError,
    LaMetricInvalidApiVersionError,
)
from .models import (
    CloudDevice,
    CloudUser,
)


@dataclass
class LaMetricCloud:
    """Represents a connection to the LaMetric cloud, allowing for retrieval of user and device information."""

    token: str
    request_timeout: int = 3
    session: aiohttp.client.ClientSession | None = None
    _close_session: bool = False

    @backoff.on_exception(
        backoff.expo, LaMetricConnectionError, max_tries=3, logger=None
    )
    async def _handle_request(
        self,
        uri: str = "",
    ) -> Any:
        """Handles a request to the LaMetric cloud, including error handling and retries for connection errors.

        Args:
            uri: The URI to append to the base URL of the cloud for the request.

        Returns:
            The JSON response from the cloud if the request is successful.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        url = URL.build(scheme="https", host="developer.lametric.com", path=uri)

        if self.session is None:
            self.session = aiohttp.ClientSession()
            self._close_session = True

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }

        try:
            async with asyncio.timeout(self.request_timeout):
                response = await self.session.request(
                    hdrs.METH_GET, url, headers=headers, raise_for_status=True
                )

            content_type = response.headers.get("Content-Type", "")

            if "application/json" not in content_type:
                raise LaMetricError(
                    response.status,
                    {"message": await response.text()},
                )

            return await response.json()

        except asyncio.TimeoutError as error:
            raise LaMetricConnectionTimeoutError(
                f"Request to {url} timed out after {self.request_timeout} seconds"
            ) from error

        except aiohttp.ClientResponseError as error:
            if error.status in (401, 403):
                raise LaMetricAuthenticationError(
                    f"Authentication failed when connecting to {url}"
                ) from error

            if error.status in (404, 405):
                raise LaMetricInvalidApiVersionError(
                    f"Unsupported API version when connecting to {url}"
                ) from error

            raise LaMetricError(
                error.status,
                {"message": error.message},
            ) from error

        except (aiohttp.ClientError, socket.gaierror) as error:
            raise LaMetricConnectionError(
                f"Connection error occurred when connecting to {url}"
            ) from error

    async def close(self) -> None:
        """Closes the aiohttp session if it was created by this instance."""
        if self._close_session and self.session is not None:
            await self.session.close()
            self.session = None

    async def __aenter__(self) -> Self:
        """Enters the asynchronous context manager, allowing the use of 'async with' syntax."""
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        """Exits the asynchronous context manager, ensuring that resources are cleaned up."""
        await self.close()

    async def get_current_user(self) -> CloudUser:
        """Retrieves the current user information from the LaMetric cloud.

        Returns:
            A CloudUser object containing the current user's information.

        """
        response = await self._handle_request("/api/v2/me")

        return CloudUser.from_dict(response)

    async def get_device(self, device_id: int) -> CloudDevice:
        """Retrieves information about a specific device connected to the LaMetric cloud.

        Args:
            device_id: The ID of the device to retrieve information for.

        Returns:
            A CloudDevice object representing the specified device.

        """
        response = await self._handle_request(f"/api/v2/users/me/devices/{device_id}")

        return CloudDevice.from_dict(response)

    async def get_devices(self) -> list[CloudDevice]:
        """Retrieves the list of devices connected to the LaMetric cloud.

        Returns:
            A list of CloudDevice objects representing the devices connected to the cloud.

        """
        response = await self._handle_request("/api/v2/users/me/devices")

        return [CloudDevice.from_dict(device) for device in response]
