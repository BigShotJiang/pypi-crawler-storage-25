"""This module defines the LaMetricDevice class, which represents a LaMetric device and provides methods to interact with it using the LaMetric API."""

from __future__ import annotations

import asyncio
import socket
import uuid
from dataclasses import dataclass
from typing import Any, Self, cast

import aiohttp
import backoff
from aiohttp import hdrs
from aiohttp.helpers import BasicAuth
from yarl import URL

from .const import DisplayMode
from .errors import (
    LaMetricAuthenticationError,
    LaMetricConnectionError,
    LaMetricConnectionTimeoutError,
    LaMetricError,
    LaMetricInvalidApiVersionError,
)
from .models import (
    App,
    AudioState,
    BluetoothState,
    Canvas,
    DeviceState,
    DisplayState,
    Notification,
    Screensaver,
    StreamState,
    WifiState,
)


@dataclass
class LaMetricDevice:  # pylint: disable=too-many-public-methods
    """Represents a LaMetric device and provides methods to interact with it."""

    host: str
    api_key: str
    request_timeout: int = 3
    session: aiohttp.client.ClientSession | None = None
    _close_session: bool = False

    @backoff.on_exception(
        backoff.expo,
        LaMetricConnectionError,
        max_tries=3,
        logger=None,
    )
    async def _handle_request(
        self,
        uri: str = "",
        method: str = hdrs.METH_GET,
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Handles a request to the LaMetric device, including error handling and retries for connection errors.

        Args:
            uri: The URI to append to the base URL of the device for the request.
            method: The HTTP method to use for the request (e.g., GET, POST).
            data: The JSON data to include in the request body (for POST requests).

        Returns:
            The JSON response from the device if the request is successful.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        url = URL.build(scheme="https", host=self.host, path=uri)

        if self.session is None:
            self.session = aiohttp.ClientSession()
            self._close_session = True

        try:
            async with asyncio.timeout(self.request_timeout):
                response = await self.session.request(
                    method,
                    url,
                    auth=BasicAuth("dev", self.api_key),
                    headers={"Accept": "application/json"},
                    json=data,
                    raise_for_status=True,
                    ssl=False,
                )

            content_type = response.headers.get("Content-Type", "")

            if "application/json" not in content_type:
                raise LaMetricError(
                    response.status,
                    {"message": await response.text()},
                )

            return await response.json()

        except asyncio.TimeoutError as error:
            raise LaMetricConnectionTimeoutError(
                f"Request to {url} timed out after {self.request_timeout} seconds"
            ) from error

        except aiohttp.ClientResponseError as error:
            if error.status in (401, 403):
                raise LaMetricAuthenticationError(
                    f"Authentication failed when connecting to {url}"
                ) from error

            if error.status in (404, 405):
                raise LaMetricInvalidApiVersionError(
                    f"Unsupported API version when connecting to {url}"
                ) from error

            raise LaMetricError(
                error.status,
                {"message": error.message},
            ) from error

        except (aiohttp.ClientError, socket.gaierror) as error:
            raise LaMetricConnectionError(
                f"Connection error occurred when connecting to {url}"
            ) from error

    async def close(self) -> None:
        """Closes the aiohttp session if it was created by this instance."""
        if self._close_session and self.session is not None:
            await self.session.close()
            self.session = None

    async def __aenter__(self) -> Self:
        """Enters the asynchronous context manager, allowing the use of 'async with' syntax."""
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        """Exits the asynchronous context manager, ensuring that resources are cleaned up."""
        await self.close()

    async def get_device_state(self) -> DeviceState:
        """Retrieves the current state of the LaMetric device.

        Returns:
            A DeviceState object representing the current state of the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(uri="/api/v2/device")

        return DeviceState.from_dict(response)

    async def get_or_set_display_state(
        self,
        *,
        brightness: int | None = None,
        brightness_mode: DisplayMode | None = None,
        screensaver: Screensaver | None = None,
        on: bool | None = None,
    ) -> DisplayState:
        """Retrieves or updates the display state of the LaMetric device.
        If any of the optional parameters are provided, the display state will be updated with the provided values.

        Args:
            brightness: The brightness level to set (0-100). If None, the current brightness level will be retrieved.
            brightness_mode: The brightness mode to set (auto or manual). If None, the current brightness mode will be retrieved.
            screensaver: The screensaver settings to set. If None, the current screensaver settings will be retrieved.
            on: Whether to turn the display on or off. If None, the current on/off state will be retrieved.

        Returns:
            A DisplayState object representing the current or updated display state of the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        if all(
            param is None for param in (brightness, brightness_mode, screensaver, on)
        ):
            response = await self._handle_request(uri="/api/v2/device/display")

            return DisplayState.from_dict(response)

        data: dict[str, Any] = {}

        if brightness is not None:
            data["brightness"] = brightness

        if brightness_mode is not None:
            data["brightness_mode"] = brightness_mode.value

        if screensaver is not None:
            data["screensaver"] = screensaver.to_dict()

        if on is not None:
            data["on"] = on

        response = await self._handle_request(
            uri="/api/v2/device/display",
            method=hdrs.METH_PUT,
            data=data,
        )

        return DisplayState.from_dict(response["success"]["data"])

    async def get_or_set_audio_state(
        self,
        *,
        volume: int | None = None,
    ) -> AudioState:
        """Retrieves or updates the audio state of the LaMetric device.
        If any of the optional parameters are provided, the audio state will be updated with the provided values.

        Args:
            volume: The volume level to set (0-100). If None, the current volume level will be retrieved.

        Returns:
            An AudioState object representing the current or updated audio state of the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        if volume is None:
            response = await self._handle_request(uri="/api/v2/device/audio")

            return AudioState.from_dict(response)

        data: dict[str, Any] = {"volume": volume}

        response = await self._handle_request(
            uri="/api/v2/device/audio",
            method=hdrs.METH_PUT,
            data=data,
        )

        return AudioState.from_dict(response["success"]["data"])

    async def get_or_set_bluetooth_state(
        self,
        *,
        active: bool | None = None,
    ) -> BluetoothState:
        """Retrieves or updates the Bluetooth state of the LaMetric device.
        If any of the optional parameters are provided, the Bluetooth state will be updated with the provided values.

        Args:
            active: Whether to turn Bluetooth visibility on or off. If None, the current Bluetooth visibility state will be retrieved.

        Returns:
            A BluetoothState object representing the current or updated Bluetooth state of the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        if active is None:
            response = await self._handle_request(uri="/api/v2/device/bluetooth")

            return BluetoothState.from_dict(response)

        data: dict[str, Any] = {"active": active}

        response = await self._handle_request(
            uri="/api/v2/device/bluetooth",
            method=hdrs.METH_PUT,
            data=data,
        )

        return BluetoothState.from_dict(response["success"]["data"])

    async def get_wifi_state(self) -> WifiState:
        """Retrieves the Wi-Fi state of the LaMetric device.

        Returns:
            A WifiState object representing the current Wi-Fi state of the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(uri="/api/v2/device/wifi")

        return WifiState.from_dict(response)

    async def get_apps(self) -> dict[str, App]:
        """Retrieves the list of installed apps on the LaMetric device.

        Returns:
            A dictionary of App objects representing the installed apps on the device, keyed by app ID.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(uri="/api/v2/device/apps")

        return {app_data["id"]: App.from_dict(app_data) for app_data in response}

    async def get_app(self, package: str) -> App:
        """Retrieves information about a specific app installed on the LaMetric device.

        Args:
            package: The package name of the app to retrieve information about.

        Returns:
            An App object representing the specified app.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(uri=f"/api/v2/device/apps/{package}")

        return App.from_dict(response)

    async def activate_next_app(self) -> None:
        """Activates the next app in the queue on the LaMetric device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        await self._handle_request(
            uri="/api/v2/device/apps/next",
            method=hdrs.METH_PUT,
        )

    async def activate_previous_app(self) -> None:
        """Activates the previous app in the queue on the LaMetric device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        await self._handle_request(
            uri="/api/v2/device/apps/prev",
            method=hdrs.METH_PUT,
        )

    async def activate_app_widget(self, package_id: str, widget_id: str) -> None:
        """Activates a specific app widget on the LaMetric device.

        Args:
            package_id: The package name of the app.
            widget_id: The ID of the app widget to activate.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        await self._handle_request(
            uri=f"/api/v2/device/apps/{package_id}/widgets/{widget_id}/activate",
            method=hdrs.METH_PUT,
        )

    async def activate_app_action(  # pylint: disable=too-many-arguments,too-many-positional-arguments
        self,
        package_id: str,
        widget_id: str,
        action_id: str,
        params: dict[str, Any] | None = None,
        activate: bool = True,
    ) -> None:
        """Activates a specific app action on the LaMetric device.

        Args:
            package_id: The package name of the app.
            widget_id: The ID of the app widget.
            action_id: The ID of the action to activate.
            params: Optional parameters to include in the action activation request.
            activate: Whether to activate (True) or deactivate (False) the action. Defaults to True.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        data: dict[str, Any] = {"id": action_id, "activate": activate}

        if params is not None:
            data["params"] = params

        await self._handle_request(
            uri=f"/api/v2/device/apps/{package_id}/widgets/{widget_id}/actions",
            method=hdrs.METH_POST,
            data=data,
        )

    async def get_notifications(self) -> list[Notification]:
        """Retrieves the list of notifications on the LaMetric device.

        Returns:
            A list of dictionaries representing the notifications on the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(uri="/api/v2/device/notifications")

        return [
            Notification.from_dict(notification_data) for notification_data in response
        ]

    async def get_current_notification(self) -> Notification | None:
        """Retrieves the currently active notification on the LaMetric device.

        Returns:
            A Notification object representing the currently active notification on the device, or None if there is no active notification.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(
            uri="/api/v2/device/notifications/current"
        )

        if response is None:
            return None

        return Notification.from_dict(response)

    async def notify(self, notification: Notification) -> str:
        """Sends a notification to the LaMetric device.

        Args:
            notification: A Notification object representing the notification to send to the device.

        Returns:
            The ID of the created notification on the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(
            uri="/api/v2/device/notifications",
            method=hdrs.METH_POST,
            data=notification.to_dict(),
        )

        return cast("str", response["success"]["id"])

    async def dismiss_notification(self, notification_id: str) -> None:
        """Dismisses a specific notification on the LaMetric device.

        Args:
            notification_id: The ID of the notification to dismiss.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        await self._handle_request(
            uri=f"/api/v2/device/notifications/{notification_id}",
            method=hdrs.METH_DELETE,
        )

    async def dismiss_current_notification(self) -> None:
        """Dismisses the currently active notification on the LaMetric device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        if (current_notification := await self.get_current_notification()) is None:
            return

        if current_notification.id is None:
            raise LaMetricError(
                "Current notification does not have an ID and cannot be dismissed"
            )

        await self.dismiss_notification(current_notification.id)

    async def dismiss_all_notifications(self) -> None:
        """Dismisses all notifications on the LaMetric device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        notifications = await self.get_notifications()

        for notification in reversed(notifications):
            if notification.id is not None:
                await self.dismiss_notification(notification.id)

    async def get_streaming_state(self) -> StreamState:
        """Retrieves the current streaming state of the LaMetric device.

        Returns:
            A StreamingState enum value representing the current streaming state of the device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(uri="/api/v2/device/stream")

        return StreamState.from_dict(response)

    async def start_stream(self, canvas: Canvas) -> StreamState:
        """Starts a stream to the LaMetric device with the specified canvas settings.

        Args:
            canvas: A Canvas object representing the canvas settings for the stream.

        Returns:
            A StreamState object representing the current streaming state of the device after starting the stream.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        response = await self._handle_request(
            uri="/api/v2/device/stream/start",
            method=hdrs.METH_PUT,
            data=canvas.to_dict(),
        )

        return StreamState.from_dict(response["success"]["data"])

    async def stop_stream(self) -> None:
        """Stops the current stream to the LaMetric device.

        Raises:
            LaMetricConnectionTimeoutError: If the request times out.
            LaMetricAuthenticationError: If authentication fails.
            LaMetricInvalidApiVersionError: If an unsupported API version is used.
            LaMetricError: For other types of errors that occur during the request.

        """
        await self._handle_request(
            uri="/api/v2/device/stream/stop",
            method=hdrs.METH_PUT,
        )

    async def send_stream_frame(  # pylint: disable=too-many-arguments,too-many-positional-arguments,too-many-locals
        self,
        state: StreamState,
        rgb888_data: bytes,
        *,
        x: int = 0,
        y: int = 0,
        width: int | None = None,
        height: int | None = None,
    ) -> None:
        """Sends one RGB888 frame via LMSP over UDP to the active stream port.

        `rgb888_data` must be in row-major RGB888 byte order: R,G,B,R,G,B,...
        """
        if state.session_id is None:
            raise LaMetricError("Stream state does not include a session_id")

        canvas_area = state.canvas.pixel or state.canvas.triangle
        if canvas_area is None and (width is None or height is None):
            raise LaMetricError(
                "Cannot determine frame size from stream canvas. Provide width and height explicitly."
            )

        if width is not None and height is not None:
            frame_width = width
            frame_height = height
        elif canvas_area is not None:
            frame_width = canvas_area.width
            frame_height = canvas_area.height
        else:
            raise LaMetricError(
                "Cannot determine frame size from stream canvas. Provide width and height explicitly."
            )

        if state.protocol is None:
            raise LaMetricError("Stream state does not include a protocol")

        if state.version is None:
            raise LaMetricError("Stream state does not include a protocol version")

        protocol_name = state.protocol.lower().encode("ascii")
        try:
            protocol_version = int(str(state.version).split(".", 1)[0])
        except ValueError as error:
            raise LaMetricError(
                f"Invalid stream protocol version: {state.version}"
            ) from error

        try:
            session_uuid = uuid.UUID(state.session_id)
        except ValueError as error:
            raise LaMetricError(
                f"Invalid stream session_id: {state.session_id}"
            ) from error

        packet = self._build_lmsp_packet(
            protocol_name=protocol_name,
            protocol_version=protocol_version,
            session_id=session_uuid.bytes,
            x=x,
            y=y,
            width=frame_width,
            height=frame_height,
            rgb888_data=rgb888_data,
        )

        port = state.port or 9999
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp_socket:
                udp_socket.sendto(packet, (self.host, port))
        except OSError as error:
            raise LaMetricConnectionError(
                f"Failed to send stream frame to {self.host}:{port}"
            ) from error

    @staticmethod
    def _build_lmsp_packet(  # pylint: disable=too-many-arguments,too-many-positional-arguments
        *,
        protocol_name: bytes,
        protocol_version: int,
        session_id: bytes,
        x: int,
        y: int,
        width: int,
        height: int,
        rgb888_data: bytes,
    ) -> bytes:
        """Builds one LMSP UDP packet for a single area in RGB888 format."""
        if len(session_id) != 16:
            raise ValueError("session_id must be exactly 16 bytes")

        if len(protocol_name) != 4:
            raise ValueError("protocol_name must be exactly 4 bytes")

        if not (0 <= protocol_version <= 0xFFFF):
            raise ValueError("protocol_version must be between 0 and 65535")

        if width <= 0 or height <= 0:
            raise ValueError("width and height must be > 0")

        expected_len = width * height * 3
        if len(rgb888_data) != expected_len:
            raise ValueError(
                f"rgb888_data has invalid length {len(rgb888_data)}, expected {expected_len}"
            )

        if not (0 <= x <= 0xFFFF and 0 <= y <= 0xFFFF):
            raise ValueError("x and y must be between 0 and 65535")

        header = bytearray()
        header.extend(protocol_name)
        header.extend(protocol_version.to_bytes(2, byteorder="little", signed=False))
        header.extend(session_id)
        header.extend((0).to_bytes(1, byteorder="little", signed=False))
        header.extend((0).to_bytes(1, byteorder="little", signed=False))
        header.extend((1).to_bytes(1, byteorder="little", signed=False))
        header.extend((0).to_bytes(1, byteorder="little", signed=False))
        header.extend(x.to_bytes(2, byteorder="little", signed=False))
        header.extend(y.to_bytes(2, byteorder="little", signed=False))
        header.extend(width.to_bytes(2, byteorder="little", signed=False))
        header.extend(height.to_bytes(2, byteorder="little", signed=False))
        header.extend(expected_len.to_bytes(2, byteorder="little", signed=False))

        return bytes(header) + rgb888_data
