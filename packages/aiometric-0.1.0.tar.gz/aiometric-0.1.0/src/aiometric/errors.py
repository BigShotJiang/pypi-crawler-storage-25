"""This module defines custom exceptions for handling errors related to LaMetric devices."""


class LaMetricError(Exception):
    """Base exception for LaMetric errors."""


class LaMetricConnectionError(LaMetricError):
    """Raised when a connection error occurs."""


class LaMetricConnectionTimeoutError(LaMetricError):
    """Raised when a connection times out."""


class LaMetricAuthenticationError(LaMetricError):
    """Raised when authentication fails."""


class LaMetricInvalidApiVersionError(LaMetricError):
    """Raised when an unsupported API version is used."""
