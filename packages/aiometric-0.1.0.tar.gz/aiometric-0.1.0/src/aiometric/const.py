"""This module defines enumerations for various LaMetric device settings and states."""

from enum import Enum


class DisplayMode(str, Enum):
    """Enumeration for LaMetric display brightness modes."""

    AUTO = "auto"
    MANUAL = "manual"


class DisplayType(str, Enum):
    """Enumeration for LaMetric display types."""

    MONOCHROME = "monochrome"
    GRAYSCALE = "grayscale"
    COLOR = "color"
    MIXED = "mixed"
    FULL_RGB = "full_rgb"


class WifiEncryptionType(str, Enum):
    """Enumeration for Wi-Fi encryption types."""

    OPEN = "OPEN"
    WEP = "WEP"
    WPA = "WPA"
    WPA2 = "WPA2"


class IpAddressMode(str, Enum):
    """Enumeration for IP address modes."""

    STATIC = "static"
    DHCP = "dhcp"


class DeviceModel(str, Enum):
    """Enumeration for LaMetric device models."""

    LEGACY_TIME = "LM 37X8"
    TIME = "sa8"
    SKY = "sa5"


class DeviceMode(str, Enum):
    """Enumeration for LaMetric device modes."""

    AUTO = "auto"
    MANUAL = "manual"
    SCHEDULE = "schedule"
    KIOSK = "kiosk"


class NotificationType(str, Enum):
    """Enumeration for LaMetric notification types."""

    INTERNAL = "internal"
    EXTERNAL = "external"


class NotificationPriority(str, Enum):
    """Enumeration for LaMetric notification priorities."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class IconType(str, Enum):
    """Enumeration for LaMetric notification icon types."""

    NONE = "none"
    INFO = "info"
    ALERT = "alert"


class SoundCategory(str, Enum):
    """Enumeration for LaMetric notification sound categories."""

    NOTIFICATIONS = "notifications"
    ALARMS = "alarms"


class AlarmSound(str, Enum):
    """Enumeration for LaMetric alarm sound IDs."""

    ALARM1 = "alarm1"
    ALARM2 = "alarm2"
    ALARM3 = "alarm3"
    ALARM4 = "alarm4"
    ALARM5 = "alarm5"
    ALARM6 = "alarm6"
    ALARM7 = "alarm7"
    ALARM8 = "alarm8"
    ALARM9 = "alarm9"
    ALARM10 = "alarm10"
    ALARM11 = "alarm11"
    ALARM12 = "alarm12"
    ALARM13 = "alarm13"


class NotificationSound(str, Enum):
    """Enumeration for LaMetric notification sound IDs."""

    BICYCLE = "bicycle"
    CAR = "car"
    CASH = "cash"
    CAT = "cat"
    DOG = "dog"
    DOG2 = "dog2"
    ENERGY = "energy"
    KNOCK_KNOCK = "knock-knock"
    LETTER_EMAIL = "letter_email"
    LOSE1 = "lose1"
    LOSE2 = "lose2"
    NEGATIVE1 = "negative1"
    NEGATIVE2 = "negative2"
    NEGATIVE3 = "negative3"
    NEGATIVE4 = "negative4"
    NEGATIVE5 = "negative5"
    NOTIFICATION = "notification"
    NOTIFICATION2 = "notification2"
    NOTIFICATION3 = "notification3"
    NOTIFICATION4 = "notification4"
    OPEN_DOOR = "open_door"
    POSITIVE1 = "positive1"
    POSITIVE2 = "positive2"
    POSITIVE3 = "positive3"
    POSITIVE4 = "positive4"
    POSITIVE5 = "positive5"
    POSITIVE6 = "positive6"
    STATISTIC = "statistic"
    THUNDER = "thunder"
    WATER1 = "water1"
    WATER2 = "water2"
    WIN = "win"
    WIN2 = "win2"
    WIND = "wind"
    WIND_SHORT = "wind_short"


class CloudDeviceState(str, Enum):
    """Enumeration for LaMetric cloud device states."""

    NEW = "new"
    CONFIGURED = "configured"
    BANNED = "banned"


# API v2.3.0 and above
class EffectType(str, Enum):
    """Enumeration for LaMetric effect types."""

    FADING_PIXELS = "fading_pixels"


class PostProcessingType(str, Enum):
    """Enumeration for LaMetric post-processing types."""

    NONE = "none"
    EFFECT = "effect"


class CanvasFillType(str, Enum):
    """Enumeration for LaMetric canvas fill types."""

    SCALE = "scale"
    TILE = "tile"


class CanvasRenderMode(str, Enum):
    """Enumeration for LaMetric canvas render modes."""

    PIXEL = "pixel"
    TRIANGLE = "triangle"


class StreamingState(str, Enum):
    """Enumeration for LaMetric streaming status."""

    STANDBY = "standby"
    RECEIVING = "receiving"
    STOPPED = "stopped"
