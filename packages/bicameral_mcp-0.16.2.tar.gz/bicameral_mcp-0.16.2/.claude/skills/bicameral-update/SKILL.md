---
name: bicameral-update
description: Check for and apply a new bicameral-mcp binary release. Upgrades the installed package (uv preferred, pipx fallback, pip last-resort), reinstalls skills and Claude hooks. NOTHING to do with git commits or ledger sync — those are handled by /bicameral-sync. Trigger on any user request containing "update", "upgrade", "new version", "latest version", or "install update".
---

# Bicameral Update

Check for a new `bicameral-mcp` release and apply it.

**This skill is about upgrading the installed binary.** It has nothing to do
with git commits, ledger sync, or compliance checks — those are `/bicameral-sync`.

## Telemetry

**At skill start**:
```
bicameral.skill_begin(skill_name="bicameral-update", session_id=<uuid4>)
```

**At skill end**:
```
bicameral.skill_end(skill_name="bicameral-update", session_id=<stored_id>,
  errored=<bool>, error_class="<if errored>")
```

## Step 1 — Check for a new version

```
bicameral.update(action="check", current_version=<SERVER_VERSION>)
```

- `status: "up_to_date"` → tell the user they are on the latest version. Done.
- `status: "update_available"` → proceed to Step 2.
- `status: "unknown"` → could not reach version endpoint; tell the user and stop.

Every response also carries `channel` (`"stable"` or `"nightly"`), resolved from `.bicameral/config.yaml`. The same call returns different recommendations depending on which channel the user opted into: stable tracks `RECOMMENDED_VERSION` on `main`; nightly tracks `RECOMMENDED_NIGHTLY_VERSION` on `dev` and serves PEP 440 dev releases.

## Step 2 — Confirm with the user

Tell the user:

> `bicameral-mcp v{recommended_version}` is available (you are on `v{current_version}`, channel=`{channel}`).
> Upgrade now?

If `channel` is `"nightly"`, also note that the recommended version is a pre-release build for design partners. Wait for explicit confirmation ("yes" / "no") before proceeding.

## Step 3 — Apply the update

```
bicameral.update(action="apply", current_version=<SERVER_VERSION>)
```

The server will:
1. Reinstall the package at `=={recommended_version}`. The installer is resolved in priority order: `uv tool install --force` if `uv` is on PATH, else `pipx install --force` if `pipx` is on PATH, else `pip install` as a venv/dev fallback. The chosen path is reported in error messages.
2. Reinstall skills into `.claude/skills/`
3. Reinstall Claude hooks in `.claude/settings.json`
4. Install git post-commit hook (Guided mode only)
5. Auto-apply any pending schema migration

**If `migration_applied: true` in the response**, tell the user:
> Schema migration ran automatically. Your ledger data was reset.
> Re-ingest the following to restore it:

Then list `migration_replay_plan` entries and ask: "Re-ingest now? (yes/no)"

## Step 3.5 — Migrate state layout (v0.16 onwards, #368)

After `bicameral.update(action="apply", ...)` returns successfully and BEFORE
reporting "update complete", run:

```
bicameral-mcp migrate-state --auto
```

via a Bash tool call. This relocates any pre-v0.16 ledger / code-graph /
bm25 / watermark / transcript-queue files out of `<repo>/.bicameral/` into
`~/.bicameral/projects/<id>/` and partitions pre-R4 `config.yaml` keys into
the team file and the operator file. The command is idempotent — on a
fresh-install repo it prints `Nothing to migrate.` and exits 0; on a
previously-installed repo it surfaces the planned moves before applying.

If the binary exits non-zero:
1. Surface the stderr verbatim to the user.
2. Abort Step 4 — do NOT report "update complete."
3. Tell the user the new binary is installed but state is in a mixed
   layout; offer to run `bicameral-mcp migrate-state --dry-run --auto` so
   they can see what the migration would do.

## Step 4 — Confirm success

Report: `bicameral-mcp updated to v{recommended_version}. {skills_updated} skill(s) reinstalled.`

Remind the user to **restart their Claude Code session** so the new server binary takes effect.
