---
name: bicameral-preflight
description: Pre-flight context check BEFORE implementing code. AUTO-FIRES on ANY prompt that involves writing, changing, or touching source code — including: "add", "build", "create", "implement", "modify", "refactor", "update", "fix", "change", "write", "edit", "move", "rename", "remove", "delete", "extract", "convert", "integrate", "deploy", "ship", "configure", "connect", "extend", "migrate", "wire up", "hook up", "set up", "complete", "finish", "continue". Also fires when user asks HOW to implement something (they are about to implement it). Surfaces prior decisions, drifted regions, divergences, and open questions BEFORE Claude writes any code. SKIP ONLY FOR — purely read-only questions with zero code intent, documentation-only typo fixes, dependency version bumps with no semantic change.
---

# Bicameral Preflight

> Tuning parameters for this skill are defined in `skills/CONSTANTS.md`.

The proactive context-surfacing skill. Bicameral notices when you're
about to implement something and pushes the relevant prior decisions,
drift, and open questions at you BEFORE Claude writes any code.

**The wow moment**: developer says *"add a Stripe webhook handler for
payment_intent.succeeded"* — without being asked, bicameral chimes in
with idempotency decisions from a sprint review, the drifted timestamp
handling from PR #287, and the unresolved deduplication question from
last week's Slack thread. The implementation that follows is informed
by all of it.

**The trust contract**: when there's nothing relevant to surface, this
skill produces ZERO output. No "I checked and found nothing" noise.
The empty path is silent.

## When to fire

Auto-fire on ANY prompt that involves writing, changing, or touching
source code. When in doubt, fire — a silent miss is worse than a
redundant check. Examples:

- *"add a Stripe webhook handler for payment_intent.succeeded"*
- *"refactor the rate limiting middleware to use sliding window"*
- *"build a notification system for retention nudges"*
- *"implement OAuth callback for Google Calendar"*
- *"modify the discount calculation to handle cents"*
- *"create a migration to add the audit_log table"*
- *"continue what we started yesterday on the email queue"* (use
  conversation context to extract the topic)
- *"how should I implement the retry logic?"* (asking HOW = about to implement)
- *"wire up the new endpoint to the frontend"*
- *"finish the auth middleware work"*
- *"migrate the payment flow to the new provider"*
- *"rename the function to snake_case"*
- *"remove the deprecated API call"*
- *"set up the webhook integration"*

## Tier-2 semantic relevance gate (#300)

> **Three-tier gating model.**
> - **Tier 1** (deterministic): `UserPromptSubmit` hook keyword match — fires or skips this skill.
> - **Tier 2** (caller LLM, NEW): You decide here — *"Does this prompt have a plausible code-implementation surface?"* If no, exit silently with no tool call.
> - **Tier 3** (deterministic): `bicameral.preflight` server call with region-anchored retrieval.

Before calling any tool, apply this one-line judgment:

> **Does this prompt have a plausible code-implementation surface?**

If the answer is clearly "no", exit the skill silently — do NOT call
`bicameral.preflight`. Record `exited_at_tier_2: true` in the
`skill_end` diagnostic (alongside the existing `g9_preflight_fired`).

### Out of scope — exit at tier 2 (no tool call)

These prompt categories have zero chance of surfacing decisions, drift,
or open questions. Exit silently:

1. **Pure docs/README/CHANGELOG edits with no source change** — e.g. *"rewrite the README quickstart section"*, *"add demo videos to the README"*, *"update CHANGELOG for the v2.1 release"*.
2. **Comment-only edits in source files** — e.g. *"add a docstring to the `calculate_total` function"*, *"update the copyright header in all files"*.
3. **Dependency version bumps with no API change** — e.g. *"bump lodash to 4.17.21"*, *"update the lockfile"*, *"run npm update"*.
4. **CI/config-only changes** — e.g. *"add a Node 20 matrix entry to the CI workflow"*, *"fix the eslint config to allow semicolons"*, *"update .gitignore to exclude dist/"*.
5. **Single-file rename or move with no logic change** — e.g. *"rename utils.js to helpers.js"*, *"move the tests into a __tests__ folder"*.
6. **Read-only questions with no code intent** — e.g. *"how does the rate limiter work?"*, *"explain the auth flow"*, *"what does this function do?"*.

### In scope — proceed to tier 3

These prompts have a plausible code-implementation surface. Call the
full `bicameral.preflight` tool:

1. **Any prompt that adds, modifies, or removes business logic** — e.g. *"add a Stripe webhook handler"*, *"refactor the rate limiter to sliding window"*.
2. **Feature implementation or integration** — e.g. *"implement OAuth callback"*, *"wire up the new endpoint"*, *"build a notification system"*.
3. **Bug fixes that change runtime behavior** — e.g. *"fix the off-by-one in the pagination"*, *"the discount calculation is wrong for cents"*.
4. **How-to-implement questions** — e.g. *"how should I implement the retry logic?"* (asking HOW = about to implement).
5. **Migration or conversion of logic** — e.g. *"migrate the payment flow to the new provider"*, *"convert the class component to hooks"*.
6. **Removing or extracting functional code** — e.g. *"remove the deprecated API call"*, *"extract the validation logic into a shared module"*.

### Edge cases — when in doubt, fire

If the prompt mixes code and non-code work (e.g. *"update the README
and add the endpoint"*), **fire** — the code portion justifies the
check. If you genuinely cannot tell, **fire** — the handler is gated
on actionable signal and will stay silent if nothing relevant is found.

**Do NOT use "why is this test failing?" as a skip trigger** — debugging
a test often precedes writing a fix. If the user asks to fix it, fire.

## When NOT to fire

**Only skip for these narrow cases** — when there is ZERO intent to write code:

- *"how does the rate limiter work?"* (purely read-only — but if they say "how should I build it", FIRE)
- *"fix the typo in the README"* (doc-only, no code change)
- *"bump lodash to 4.17.21"* (dependency version bump only, no semantic change)

**Do NOT use "why is this test failing?" as a skip trigger** — debugging
a test often precedes writing a fix. If the user asks to fix it, fire.

If uncertain whether the user will write code, **fire anyway** — the
handler is gated on actionable signal and will stay silent if nothing
relevant is found. The cost of a false fire is one silent no-op.

### Hook reinforcement

The trigger described above is reinforced by a `UserPromptSubmit` hook
configured in [`.claude/settings.json`](../../.claude/settings.json).
The hook reads the user prompt, runs a deterministic regex over the
canonical verb list at
[`scripts/hooks/preflight_intent.py`](../../scripts/hooks/preflight_intent.py),
and — on match — injects a `<system-reminder>` block elevating
`bicameral.preflight` above the agent's default tool-selection priority.

For v0 the verb list is duplicated by intent: the SKILL.md
`description` field above embeds the list as a string literal so
Claude Code skill discovery can read it, while the Python module is
the canonical source for the hook. Both must be edited together to
evolve the trigger surface; future configurability will deduplicate.

## Telemetry

> **Guard**: Only call `skill_begin` and `skill_end` if telemetry is enabled. Telemetry is enabled by default; disabled by setting `BICAMERAL_TELEMETRY=0` (or `false`/`off`/`no`). If disabled, skip both calls and omit all `diagnostic` tracking.

**At skill start** (before any tool calls):
```
bicameral.skill_begin(skill_name="bicameral-preflight", session_id=<uuid4>)
```

**At skill end**:

> ⚠ **USE THESE EXACT FIELD NAMES.** The dashboard queries on `g9_*` / `g10_*` / `g11_*` prefixes. Substituting natural-language names silently drops the event from every dashboard panel. Copy the names below verbatim.

```
bicameral.skill_end(skill_name="bicameral-preflight", session_id=<stored_id>,
  errored=<bool>, error_class="<if errored>",
  diagnostic={
    exited_at_tier_2: <bool>,  # true when tier-2 gate exited without tool call (#300)
    g9_history_features_count: N,
    g9_features_in_scope: N,
    g9_decisions_in_scope: N,
    g9_preflight_fired: <bool>,

    g10_findings_drift_total: N,
    g10_findings_drift_cosmetic_autopass: N,
    g10_findings_drift_ask: N,
    g10_questions_surfaced: N,
    g10_user_overrode: N,

    g11_corrections_turns_scanned: N,
    g11_corrections_prefilter_retained: N,
    g11_corrections_classified_ask: N,
    g11_corrections_classified_mechanical: N,
    g11_corrections_classified_not: N,
    g11_corrections_dedup_removed: N,
    g11_user_overrode: 0,  # always 0 in preflight (in-session mode, no batch confirmation)
  })
```

## Steps

### 1. Read the full decision ledger

Call `bicameral.history()` with no filters to get the complete picture:

```
bicameral.history()
```

This returns all decisions grouped by feature area, each with its current status
(`reflected`, `drifted`, `pending`, `ungrounded`) and signoff state. Scan the
returned `features` list and **identify which feature groups are relevant to the
current implementation task** using your own judgment — name overlap, decision
descriptions, or both. A feature group is relevant when at least one of its
decisions describes behavior the current task will touch or depend on.

**This replaces keyword search.** The LLM reads the full ledger and reasons about
relevance — no BM25 approximation.

Skip this step only if the ledger is empty (history returns 0 features) — in that
case proceed directly to step 2.

### 2. Call `bicameral.preflight` for region-anchored and HITL state

**Discover first, then preflight.** Before this call, use Read / Grep / Glob to
resolve the user's request to concrete file paths. The user often names a
*feature* ("the reorder feature", "the rate limiter") rather than a *file*; the
caller LLM is responsible for that mapping — the server does deterministic
retrieval, not semantic guessing. A topic-only call falls back to fuzzy text
similarity over decision descriptions; passing `file_paths` engages the
high-precision `binds_to` graph lookup.

```
bicameral.preflight(
  topic="<the 1-line topic>",
  file_paths=["<repo-relative path>", ...],  # discovered in step 1
)
```

This call handles two things the history read cannot:
- **Region-anchored lookup**: if you know which files the task will touch, the
  handler returns decisions pinned to those exact files (higher precision than
  feature-name matching).
- **HITL state**: returns any unresolved collision-pending or context-pending
  decisions that need attention regardless of topic.

The response carries `fired: bool`. When `fired=false`, skip to step 3 (you
already have context from history). When `fired=true` with region matches, merge
those into your in-scope set.

The response also carries an optional `sync_metrics` field — skip rendering it.
If `response.product_stage` is non-null, surface it verbatim to the user as a brief note (shown once per device only).

**`file_paths` may be omitted only** for genuinely abstract queries with no
file referent yet (e.g. *"how should I approach building a retry helper?"* —
no existing files to point at). For implementation prompts that name or imply
a feature backed by existing code, populate `file_paths` from your discovery.
The handler still runs sync and HITL checks either way; passing `file_paths`
just unlocks the precision channel.

The server expands caller-supplied `file_paths` by 1 hop along the
code-locator graph's **import edges** (file-level structural
dependency), so a decision bound to `app/src/lib/git/reorder.ts` still
surfaces when the caller passes the structurally-near
`app/src/ui/multi-commit-operation/reorder.tsx` (because the latter
imports the former). You should still pass concrete paths discovered
in step 1 — the expansion lifts the recall ceiling on near-misses, it
doesn't replace caller-side discovery. Decisions reached only via the
expansion carry `confidence=0.7` in the response (vs `0.9` for direct
pins), and `sources_chained` includes `"graph"` (alongside `"region"`)
when expansion contributed at least one hit. Caller can de-prioritize
expanded matches without losing them.

**Graph fallback signal (#243).** When `sources_chained` contains
`"graph_unavailable"`, the code-locator graph expansion couldn't run
this call (uninitialized symbol index, missing adapter, or transient
error). Render a one-line note to the user before the surfaced block:

> *Note: structural-neighbor lookup was unavailable this call — recall
> may be reduced until the symbol index is rebuilt. Decisions bound to
> files that import these may not have surfaced.*

The granular reason (`absent` / `missing_method` /
`exception:<type>`) is recorded in the local `preflight_events.jsonl`
telemetry counter for operator triage; the response shape stays
stable. Treat `"graph_unavailable"` as advisory — it doesn't block
the preflight surface; direct-pin matches are unaffected.

### 2.5 Resolve pending compliance checks if present

Before evaluating `response.fired`, check `response._pending_compliance_checks`.
If non-empty, a new commit was detected — **resolve compliance before proceeding
or status will be stale.** Use the `bicameral-sync` compliance resolution flow:

For each check: read `file_path` (use `code_body` if available; read directly if
truncated), evaluate code against `decision_description`, then batch all verdicts:

```
bicameral.resolve_compliance(
  phase="drift",
  flow_id="<response._pending_flow_id>",
  verdicts=[{
    decision_id:  "<check.decision_id>",
    region_id:    "<check.region_id>",
    content_hash: "<check.content_hash — echo exactly>",
    verdict:      "compliant" | "drifted" | "not_relevant",
    confidence:   "high" | "medium" | "low",
    explanation:  "<one sentence>"
  }, ...]
)
```

Then continue to step 3 as normal. **Silent when empty** — no output to user
about this step unless a drift is found.

### 3. Decide whether to render

Combine what you have from steps 1 and 2:

- **In-scope decisions** = relevant feature groups from history + region-anchored decisions from preflight (deduplicated by `decision_id`)
- **Actionable signal** = any in-scope decision with `status=drifted`, `status=ungrounded`, or with an open question; plus any HITL issues from preflight response

**If no in-scope decisions and no HITL issues** → produce **NO OUTPUT** about the preflight.
Do not say "I checked bicameral and found nothing." Just proceed silently.

**If `fired == false` and no relevant features from history** → same: silent skip.

The `reason` field on the preflight response is for debugging, never user-facing.
Possible reasons: `recently_checked` (same topic checked in last 5 min),
`preflight_disabled` (env override mute).

**Note on ephemeral commits**: when `bicameral.link_commit` is called on a
feature branch commit (one not yet in the authoritative branch), the response
includes `ephemeral: true` and any compliance verdicts are tagged as such.
These verdicts are still authoritative for status — `drifted`/`reflected` reflects
the branch state — but the dashboard renders them with a branch-delta indicator
so you can see what your branch changes relative to main.

- **`fired == true`** → render the surfaced block (next step) BEFORE
  doing any code work.

### 3.5 Scan recent user turns for uningested corrections

Before classifying server-returned findings, invoke
`/bicameral-capture-corrections` in **in-session mode**:

```
Skill("bicameral:capture-corrections", args="--mode in-session")
```

That skill owns the canonical scan-and-classify rubric (Steps A → B → C).
In in-session mode it scans the last ~10 user messages, auto-ingests
mechanical corrections silently, and returns ask-corrections for merging
into the stop-and-ask queue below.

**Merge outcomes into step 4:**
- Mechanical corrections → already ingested by capture-corrections, no
  output needed here.
- Ask corrections → add as `uningested_corrections` category (priority
  slot 3: after drift, before open questions). One question max.

**Queue drain (#156 PR B):** in-session mode also drains the pending-transcripts queue at `<repo>/.bicameral/pending-transcripts/` — transcripts from prior sessions whose corrections never surfaced (because that session ended without a follow-up preflight). Drained ask-corrections share the same ≤4-cap as in-session corrections; remaining pending files stay queued for the next preflight to pick up. The canonical drain rubric lives in `skills/bicameral-capture-corrections/SKILL.md` (Step 0 of the scan-and-classify rubric); preflight delegates to it via the in-session mode invocation.

### 4. Classify findings before surfacing

Before rendering anything, classify each finding as **mechanical** or
**ask** (see Stop-and-Ask Contract below). Auto-resolve mechanical
findings silently. For ask-findings, emit at most **one question per
category**, in this priority order: drift → divergence →
uningested_corrections → open questions → ungrounded.
Hard cap: ≤ 4 questions total per preflight call (if all 5 categories
have ask-findings, drop `ungrounded` — least urgent for correctness).

Categories with no ask-findings are silently skipped. If every
finding in every category is mechanical, produce NO output (same as
`fired=false` — silent).

**Cosmetic drift rule**: if a `drifted` entry has `cosmetic_hint=true`,
classify it as **mechanical** regardless of guided mode. The server has
verified via AST comparison that the change is whitespace-only and
semantically inert — the stored intent is still intact. Auto-resolve
silently; do NOT add it to the drift ask-queue and do NOT emit a
blocking hint. Render it with `~` prefix (not `⚠ DRIFTED:`) if you
render it at all — see the template in Step 5.

### 5. Render the surfaced block

When at least one ask-finding exists, surface the response using this
format. Lead with the `(bicameral surfaced)` attribution line.

```
(bicameral surfaced — checking <topic> context before implementing)

📌 N prior decisions in scope:
  ✓ <decision description>
    <file_path>:<symbol>:<lines>
    Source: <source_ref> · <source_type>

  ✓ <next decision...>

  ⚠ DRIFTED: <decision description>
    <file_path>:<symbol>:<lines>
    Source: <source_ref>
    Drift evidence: <drift_evidence verbatim>

  ~ REFORMATTED: <decision description>      ← cosmetic_hint=true only
    <file_path>:<symbol>:<lines>
    Source: <source_ref>
    (whitespace-only change — intent intact, no action needed)

⚠ N divergent decision pair(s) — pick a winner before continuing:
  • <symbol> (<file_path>): <summary>

⚠ N uningested correction(s) from this session:
  • "<user's correction, quoted or one-line paraphrase>"
    Proposed capture: <decision description>
    [Ingest now? Y/n]

⚠ N unresolved open question(s):
  • <description>
    Source: <source_ref>
```

Then, if `response.action_hints` is non-empty, render each hint
verbatim — never paraphrase the `message` field.

### 5.4 Telemetry + source attribution rendering

> **Telemetry note**: this skill emits `skill_begin` / `skill_end` events with `g9_*` / `g10_*` / `g11_*` diagnostic counters (counts only, no content). Set `BICAMERAL_TELEMETRY=0` to opt out before invoking.

**Source attribution rendering (#200 Phase 3)**: every `source_ref` field on surfaced decisions is already pre-filtered server-side per the operator's `render_source_attribution` setting in `.bicameral/config.yaml`. Modes: `full` (verbatim legacy), `redacted` (default — names + dates replaced with placeholders, structural shape preserved), `hidden` (blank). Render whatever the server returned verbatim — no further redaction needed at the skill layer, and do NOT attempt to recover original values from redacted forms. The deterministic gate is the config field, not this instruction.

### 5.5 Confirm finding relevance (ground truth for calibration)

> **Guard**: Only run this step if guided mode is enabled (`guided: true` in `.bicameral/config.yaml`). In normal mode, skip and set `g10_user_overrode = 0`.

After rendering the surfaced block, if any ask-findings were surfaced, call `AskUserQuestion` to let the user dismiss findings that are not relevant to the current task. Batch into groups of ≤ 4 findings per call; loop through batches if there are more than 4 total.

```python
AskUserQuestion({
  question: "Any of these finding(s) not relevant to your current task?",
  multiSelect: True,
  options: [
    { label: "<one-line summary>", description: "<category: drift | divergence | open_question | uningested>" },
    ...  # one entry per ask-finding
  ]
})
```

- User selects items → those are dismissed. `g10_user_overrode` += count of dismissed findings.
- User selects nothing → all findings treated as relevant. `g10_user_overrode = 0`.
- `g10_questions_surfaced` = total ask-findings shown across all batches.

After the surfaced block, **continue with the user's original request**.
A one-line forward narration helps:

> "Proceeding with implementation; pulling the Redis SETNX pattern
> from idempotency.ts. I'll flag the event.id deduplication question
> for you to answer before I commit."

### 5.6 Capture refinements — ask the user, then act mechanically

When preflight surfaced ≥1 decision and the user's request operates on or
near the same feature surface, **do not judge contradiction yourself.**
LLM contradiction detection has been observed to silently miss
structural-mismatch refinements (e.g. user asks for a "programmatic API
to reorder commits" while a prior decision describes "drag-to-reorder
UI" — the conflict is real but not lexical, and the agent rationalizes
"these can coexist"). Per #175, the judgment moves to the user.

#### 5.6.1 Disambiguate via `AskUserQuestion`

Fires whenever `response.fired == True` and `len(response.decisions) >= 1`,
regardless of guided mode (capture is the headline product behavior, not
opt-in). Ask once per surfaced decision the user's request plausibly
touches; skip for surfaced decisions that are clearly unrelated to the
prompt domain.

```python
AskUserQuestion({
  "question": (
      "Your request appears to operate on the same feature surface as "
      "surfaced decision <decision_id> ('<one-line description>'). "
      "Treat this work as a refinement of that prior plan?"
  ),
  "multiSelect": False,
  "options": [
    {
      "label": "Yes — supersede prior plan",
      "description": "<paraphrase user's direction; replaces the prior decision wholesale>",
    },
    {
      "label": "Yes — keep both (addition or scoping)",
      "description": "<paraphrase; adds to or narrows the prior decision; both remain>",
    },
    {
      "label": "No — unrelated to prior plan",
      "description": "Continue without capture",
    },
  ],
})
```

#### 5.6.2 Mechanical capture (after user disambiguation)

Based on the user's selection, branch:

- **"supersede"** → execute the two-call capture below with `action="supersede"`.
- **"keep both"** → execute the two-call capture below with `action="keep_both"`.
- **"unrelated"** → skip capture; proceed to implementation. Narrate one
  line ("noted — surfaced context isn't applicable here") and move on.

For the two "yes" branches:

1. **Ingest the refinement** with `source=agent_session`, scoped to the
   same `feature_group` as the surfaced decision:

```
bicameral.ingest(payload={
  "query": "<surfaced decision's topic>",
  "source": "agent_session",
  "title": "<short label, e.g. 'reorder-programmatic-api'>",
  "date": "<today ISO date>",
  "decisions": [{ "description": "<user's direction, stated as a decision>" }]
}, feature_group="<same feature group as the surfaced decision>")
```

2. **Wire it to the seeded decision** via `bicameral.resolve_collision`:

```
bicameral.resolve_collision(
  new_id="<just-ingested refinement id>",
  old_id="<surfaced decision id>",
  action="supersede" | "keep_both" | "link_parent"
)
```

`link_parent` is also available (selectable at the `AskUserQuestion`
step if the surfaced decision is an L1 parent and the user's direction
is an L2 child) — wires `parent_decision_id`, no supersede edge, no
status change.

The user has answered the disambiguation question, so capture is
mechanical from this point. PM ratifies in the inbox.

Narrate one line: *"Captured refinement: '<paraphrase>' — wired as
<action> of <feature> roadmap entry."*

#### Hook reinforcement

A PostToolUse hook scoped to `mcp__bicameral__bicameral_preflight` injects a
`<system-reminder>` after every preflight call that surfaces ≥1 decision. The
reminder templates Step 5.6.1's `AskUserQuestion` shape with the surfaced
`decision_id` + description filled in, so the question fires reliably even
when the agent's natural inclination would be to skip the disambiguation.
Source: `scripts/hooks/post_preflight_capture_reminder.py`; wired by
`setup_wizard._install_claude_hooks` and the e2e harness's
`materialize_settings_with_hooks`.

### 6. Honor blocking hints (guided mode vs normal mode)

The agent's `guided_mode` setting controls whether action hints are
blocking or advisory. The flag has two settings chosen at `bicameral setup`
time:

- **Normal mode** (`guided: false`, default) — hints fire with `blocking: false`
  and advisory tone ("heads up — N drifted decision(s) detected"). Mention
  the hint to the user and **continue with the implementation**. Normal
  mode is a heads-up, not a stop sign.
- **Guided mode** (`guided: true`) — hints fire with `blocking: true` and
  imperative tone ("N drifted decision(s) — review BEFORE making changes").
  When any hint has `blocking: true`, **MUST stop after the surfaced block
  and wait for user acknowledgment** before any write operation (file edit,
  commit, PR, `bicameral_ingest`). Surface the hint's `message` verbatim
  and ask the user to either resolve it or explicitly tell you to proceed.

**How to enable/disable:**

*Durable (setup time)*: `bicameral setup` prompts:
```
  Interaction intensity:
    1. Normal  — bicameral flags discrepancies as advisory hints (default)
    2. Guided  — bicameral stops you when it detects discrepancies
  Choice [1/2]:
```
Written to `.bicameral/config.yaml` as `guided: true` or `guided: false`.

*One-off override (env var)*: Set `BICAMERAL_GUIDED_MODE=1` (or `true`, `yes`,
`on`) on the MCP server process to force guided mode for one session without
touching the config file. Set to `0` / `false` to force normal mode.

**When to use guided mode:**
- Onboarding a new user to a repo with an existing bicameral ledger.
- Demos where you want the audience to see bicameral doing adversarial-audit work.
- Critical-path work — touching auth, billing, security, migrations.

**When normal mode is enough:**
- Day-to-day workflow on a codebase you know.
- Read-only exploration flows.
- Batch / headless ingest with no human-in-the-loop.

### 7. On stop-and-ask resolution — ingest the answer

When a blocking hint is resolved and the user answers an open question
or confirms a design decision, immediately capture it into the ledger:

```
bicameral.ingest(payload={
  "query": "<the feature topic preflight was scoped to>",
  "source": "agent_session",
  "title": "<short label for the decision, e.g. 'preflight-resolution-<topic>'>",
  "date": "<today ISO date>",
  "decisions": [{ "description": "<the user's answer as a decision statement>" }]
}, feature_group="<same feature group as the implementation task>")
```

Use `source="agent_session"` — a source type distinct from transcript/slack/document
that marks decisions resolved inline during an agent session. This ensures the
decision is recorded in the ledger and not lost when the session ends.

## Stop-and-Ask Contract

<!-- Copy of bicameral-ask-contract.md v1 — see source for canonical version -->

For every finding this skill surfaces, classify first:

- **mechanical** — one obvious correct answer (e.g., renamed symbol
  with identical signature; a decision whose code moved but semantics
  are intact; a `drifted` entry with `cosmetic_hint=true` — AST
  comparison confirmed whitespace-only change). Auto-apply the
  resolution silently. Do NOT ask the user.
- **ask** — reasonable people could disagree (e.g., drifted behavior
  where the old decision may still be valid; divergent decisions where
  no clear winner exists). Emit ONE question per finding, using the
  format below.

**Question format** — always:
1. **Re-ground:** repo + branch + one-sentence current task
2. **Simplify:** plain English, no raw symbol names
3. **Recommend:** `RECOMMENDATION: Choose X because Y` + Completeness
   X/10 per option
4. **Options:** A / B / C — one sentence each, pickable in < 5s

**Per-skill caps (preflight):**
- Max 1 question per category (drift / divergence /
  uningested_corrections / open questions / ungrounded)
- Hard cap 4 questions per preflight call
- If all 5 categories have ask-findings, drop `ungrounded` (least
  urgent for correctness) questions

**Advisory-mode override:** if `BICAMERAL_GUIDED_MODE=0`, emit
questions as informational notes (non-blocking); do not gate
downstream tool calls.

## Examples

### Hit — guided mode, drift + divergence found

**User**: "Add a Stripe webhook handler for payment_intent.succeeded"

**Topic extracted**: `Stripe webhook payment_intent succeeded`

**Tool call**: `bicameral.preflight(topic="Stripe webhook payment_intent succeeded")`

**Response** (fired=true, guided_mode=true):

```
(bicameral surfaced — checking Stripe webhook payment_intent succeeded
context before implementing)

📌 3 prior decisions in scope:

  ✓ Idempotency via Redis SETNX with 24h TTL
    src/middleware/idempotency.ts:checkIdempotencyKey:42-67
    Source: Sprint 14 architecture review · Ian, 2026-03-12

  ✓ Retry failed webhooks with exponential backoff (max 5 attempts)
    src/queue/webhook-retry.ts:scheduleRetry:18-45
    Source: PR #261 review · Brian, 2026-03-22

  ⚠ DRIFTED: Trust Stripe event.created timestamp, not server time
    src/handlers/webhook.ts:processEvent:80-92
    Source: arch review 2026-03-15
    Drift evidence: switched from event.created to Date.now() in PR #287

⚠ 1 unresolved open question:
  • "Should we deduplicate by event.id or by (account_id, event.id)?"
    Source: Slack #payments 2026-03-20

⚠ BLOCKING (guided mode): 1 matched decision(s) have drifted — review
the drifted regions and confirm the code still matches stored intent
BEFORE making changes.

I need you to resolve before I proceed:
1. Was the switch to Date.now() in PR #287 intentional, or should I
   revert to event.created?
2. Which deduplication key should I use — event.id or
   (account_id, event.id)?
```

(Then waits for user acknowledgment.)

### Miss — silent skip

**User**: "Fix the typo in the README"

**Topic extracted**: `typo README` (or skipped entirely if you decide
this is doc-only)

**Tool call**: skipped, OR `bicameral.preflight(topic="typo README")`

**Response** (fired=false, reason=topic_too_generic OR no_matches):

```
[no output about preflight at all]
```

Then continue with the typo fix. The user should not see any preflight
output for prompts that don't match anything.

### Hit — normal mode, advisory only

**User**: "Refactor the discount calculation to handle cents"

**Response** (fired=true, guided_mode=false):

```
(bicameral surfaced — checking discount calculation cents context
before implementing)

📌 1 prior decision in scope:
  ⚠ DRIFTED: Apply 10% discount on orders >= $100
    src/pricing/discount.py:calculate_discount:42-67
    Source: Sprint 14 planning · Ian, 2026-03-12
    Drift evidence: threshold raised 100 → 500, rate lowered 10% → 5%

Note: the discount logic is currently drifted from the original
intent. Worth confirming with Ian before changing it again. Proceeding
with the refactor — let me know if you want me to align it back to
the original 10% / $100 baseline or keep the current 5% / $500
behavior.
```

(Continues with the refactor — no blocking pause in normal mode.)

## Rules

1. **Honest empty path.** When `fired=false`, produce NO output about
   preflight. Silent skip. Period.
2. **Verbatim attribution.** Every cited decision includes its
   `source_ref` so the user can trace it.
3. **Never paraphrase hint messages.** Surface them as-is. The
   message tone (advisory vs imperative) is calibrated by guided mode
   and the user can read intent from it directly.
4. **Topic from prompt + context.** If the user's prompt is indirect
   ("continue what we started yesterday"), use the prior conversation
   to extract a meaningful topic. Don't pass the raw prompt verbatim.
5. **Forward narration after surfacing.** Tell the user what you're
   about to do with the surfaced context, not just what you found.
   "Proceeding with X; pulling pattern from Y; will flag Z for you to
   answer before commit."
6. **Skip the SKIP-FOR list.** Read-only, doc-only, and dependency-
   only prompts do not need preflight. Don't fire on them.

## How to disable

If preflight is too noisy for the current session, the user can set
`BICAMERAL_PREFLIGHT_MUTE=1` on the MCP server process to silence it
for one session. The handler will return `fired=false` with
`reason="preflight_disabled"` for every call.

For a permanent off-switch, edit `.bicameral/config.yaml` and remove
the preflight skill from the agent's skill set, OR set
`guided: false` (which dials preflight back to "actionable signal
only" — silent on plain matches).
