import requests
from efs_wrapper.v1.constants import CHUNK_SIZE, MB
from io import IOBase
from typing import Union

def _check_if_not_empty(file: IOBase) -> bool:
	if not isinstance(file, str) and not isinstance(file, bytes):
		pos = file.tell()
		file.seek(0, 2)
		size = file.tell()
		file.seek(pos)
		if size == 0:
			return True
	return False

class HumanDiskUsageObject:
	def __init__(self, total, used, free):
		self.total = round(total / MB)
		self.used = round(used / MB)
		self.free = round(free / MB)

class DiskUsageObject:
	def __init__(self, total, used, free):
		self.total = total
		self.used = used
		self.free = free
		self.human = HumanDiskUsageObject(total, used, free)

class FileMetadataPermissions:
	def __init__(self, *, is_readable, is_writable):
		self.is_readable = is_readable
		self.is_writable = is_writable

class FileMetadata:
	def __init__(self, *, file_name, file_path, file_size, last_modified, creation_time, mimetype, permissions: dict):
		self.file_name = file_name
		self.file_path = file_path
		self.file_size = file_size
		self.last_modified = last_modified
		self.creation_time = creation_time
		self.mimetype = mimetype
		self.permissions = FileMetadataPermissions(**permissions)

	def to_dict(self):
		return {
			"file_name": self.file_name,
			"file_path": self.file_path,
			"file_size": self.file_size,
			"last_modified": self.last_modified,
			"creation_time": self.creation_time,
			"mimetype": self.mimetype,
			"permissions": {
				"is_readable": self.permissions.is_readable,
				"is_writable": self.permissions.is_writable
			}
		}

class DirectoryMetadata:
	def __init__(self, *, size, last_modified, creation_time):
		self.size = size
		self.last_modified = last_modified
		self.creation_time = creation_time

	def to_dict(self):
		return {
			"size": self.size,
			"last_modified": self.last_modified,
			"creation_time": self.creation_time
		}

	def __str__(self):
		size = self.size
		last_modified = self.last_modified
		creation_time = self.creation_time
		return f"DirectoryMetadata({size=}, {last_modified=}, {creation_time=})"

	def __repr__(self):
		return str(self)

class EepyFileServerDirectory:
	def __init__(self, dirs, files, metadata: dict):
		self.directories = dirs
		self.files = files
		if metadata:
			self.size = metadata.get("size", -1)
			self.last_modified = metadata.get("last_modified", -1)
			self.creation_time = metadata.get("creation_time", -1)

		self.metadata = DirectoryMetadata(**metadata)

	def __str__(self):
		directories = self.directories
		files = self.files
		metadata = self.metadata
		return f"EepyFileServerDirectory({directories=}, {files=}, {metadata=})"

	def __repr__(self):
		return str(self)

class EepyFileServerFilePartial:
	def __init__(self, metadata: Union[dict | FileMetadata], instance):
		self.stream = "Please do .fetch_file() on this class instance"
		self.__instance = instance
		if isinstance(metadata, FileMetadata):
			metadata = metadata.to_dict()
		if metadata:
			self.name = metadata.get("file_name", None)
			self.path = metadata.get("file_path", None)
			self.file_size = metadata.get("file_size", -1)
			self.last_modified = metadata.get("last_modified", -1)
			self.creation_time = metadata.get("creation_time", -1)
			self.mimetype = metadata.get("mimetype", None)
			self.is_readable = metadata["permissions"].get("is_readable", None)
			self.is_writable = metadata["permissions"].get("is_writable", None)

		self.metadata = FileMetadata(**metadata)

	def fetch_file(self):
		return self.__instance.get_file(self)

	def __str__(self):
		mimetype = self.mimetype
		file_name = self.name
		file_size = self.file_size
		return f"EepyFileServerFilePartial({mimetype=}, {file_name=}, {file_size=})"

	def __repr__(self):
		file_name = self.name
		file_size = self.file_size
		last_modified = self.last_modified
		creation_time = self.creation_time
		mimetype = self.mimetype
		is_readable = self.is_readable
		is_writable = self.is_writable
		return f"EepyFileServerFilePartial({file_name=}, {file_size=}, {last_modified=}, {creation_time=}, {mimetype}, {is_readable=}, {is_writable=})"

class EepyFileServerFile:
	def __init__(self, stream, metadata: Union[dict | FileMetadata]):
		self.stream = stream
		if isinstance(metadata, FileMetadata):
			metadata = metadata.to_dict()
		if metadata:
			self.name = metadata.get("file_name", None)
			self.path = metadata.get("file_path", None)
			self.file_size = metadata.get("file_size", -1)
			self.last_modified = metadata.get("last_modified", -1)
			self.creation_time = metadata.get("creation_time", -1)
			self.mimetype = metadata.get("mimetype", None)
			self.is_readable = metadata["permissions"].get("is_readable", None)
			self.is_writable = metadata["permissions"].get("is_writable", None)

		self.metadata = FileMetadata(**metadata)

	def read(self):
		return self.stream

	def load(self) -> bytes:
		chunks = []
		for chunk in self.stream:
			chunks.append(chunk)
		return b"".join(chunks)

	def save(self, path = None) -> None:
		if not path:
			path = self.name
		with open(path, "wb") as f:
			for chunk in self.stream:
				f.write(chunk)

	def __str__(self):
		mimetype = self.mimetype
		file_name = self.name
		file_size = self.file_size
		return f"EepyFileServerFile({mimetype=}, {file_name=}, {file_size=})"

	def __repr__(self):
		file_name = self.name
		file_size = self.file_size
		last_modified = self.last_modified
		creation_time = self.creation_time
		mimetype = self.mimetype
		is_readable = self.is_readable
		is_writable = self.is_writable
		return f"EepyFileServerFile({file_name=}, {file_size=}, {last_modified=}, {creation_time=}, {mimetype}, {is_readable=}, {is_writable=})"

class EepyFileServerPublic:
	def __init__(self, base_url: str, api_path: str = "/api/v1"):
		self.base_url = f"{base_url}{api_path}"
		self._session = requests.Session()
		self.api_version = self.get_instance_info()["instance"]["version"]

	def get_instance_info(self) -> dict:
		url = f"{self.base_url}/instance"
		response = self._session.get(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def get_disk_usage(self) -> DiskUsageObject:
		diskusage = self.get_instance_info()["instance"]["disk_usage"]
		return DiskUsageObject(diskusage["total"], diskusage["used"], diskusage["free"])

	def get_tree(self, path = None) -> dict:
		url = f"{self.base_url}/public/tree"
		if path:
			if path.startswith("/"):
				path = path[1:]
			url = f"{self.base_url}/public/tree/{path}"
		response = self._session.get(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		result = {}
		for directory, values in data.items():
			result[directory] = EepyFileServerDirectory(**values)
		return result

	def get_filelist(self) -> dict:
		url = f"{self.base_url}/public/files"
		response = self._session.get(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def get_file(self, path: Union[str | EepyFileServerFilePartial]) -> Union[EepyFileServerFilePartial | EepyFileServerFile]:
		if isinstance(path, str):
			if path.startswith("/"):
				path = path[1:]
			url = f"{self.base_url}/public/metadata/{path}"
			response = self._session.get(url)
			data = response.json()
			if response.status_code != 200:
				raise Exception(data["error"], response.status_code)
			return EepyFileServerFilePartial(data["metadata"], self)
		elif isinstance(path, EepyFileServerFilePartial):
			url = f"{self.base_url}/public/files/{path.path}"
			response = self._session.get(url, stream = True)
			if response.status_code != 200:
				raise Exception(response.status_code)
			return EepyFileServerFile(response.iter_content(chunk_size = CHUNK_SIZE), path.metadata)

	def url_to_file(self, path, check_if_exists = False) -> str:
		if path.startswith("/"):
			path = path[1:]
		if check_if_exists:
			url = f"{self.base_url}/public/metadata/{path}"
			response = self._session.get(url)
			data = response.json()
			if response.status_code != 200:
				raise Exception(data["error"], response.status_code)
		return f"{self.base_url}/public/files/{path}"

	def _validate(self):
		url = f"{self.base_url}/instance"
		response = self._session.get(url)
		if response.status_code != 200:
			raise Exception(f"something went wrong: {response.status_code}")

class EepyFileServer:
	def __init__(self, base_url: str, password: str = None, api_path: str = "/api/v1"):
		self.base_url = f"{base_url}{api_path}"
		self.headers = None

		if password:
			self.headers = {"Authorization":  password}
		if not password:
			print("You can only use 'EepyFileServerPublic' methods, for example 'cls.public.get_file(...)'")

		self._session = requests.Session()
		self._session.headers = self.headers

		self._validate()
		self.api_version = self.get_instance_info()["instance"]["version"]
		if password:
			self.config = self.get_config()
		self.public = EepyFileServerPublic(base_url, api_path)

	def get_instance_info(self) -> dict:
		url = f"{self.base_url}/instance"
		response = self._session.get(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def get_disk_usage(self) -> DiskUsageObject:
		diskusage = self.get_instance_info()["instance"]["disk_usage"]
		return DiskUsageObject(diskusage["total"], diskusage["used"], diskusage["free"])

	def get_tree(self, path = None) -> dict:
		url = f"{self.base_url}/tree"
		if path:
			if path.startswith("/"):
				path = path[1:]
			url = f"{self.base_url}/tree/{path}"
		response = self._session.get(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		result = {}
		for directory, values in data.items():
			result[directory] = EepyFileServerDirectory(**values)
		return result

	def add_directory(self, path):
		if path.startswith("/"):
			path = path[1:]
		url = f"{self.base_url}/tree/{path}"
		response = self._session.post(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def remove_directory(self, path):
		if path.startswith("/"):
			path = path[1:]
		url = f"{self.base_url}/tree/{path}"
		response = self._session.delete(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def get_filelist(self) -> dict:
		url = f"{self.base_url}/files"
		response = self._session.get(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def get_file(self, path: Union[str | EepyFileServerFilePartial]) -> Union[EepyFileServerFilePartial | EepyFileServerFile]:
		if isinstance(path, str):
			if path.startswith("/"):
				path = path[1:]
			url = f"{self.base_url}/metadata/{path}"
			response = self._session.get(url)
			data = response.json()
			if response.status_code != 200:
				raise Exception(data["error"], response.status_code)
			return EepyFileServerFilePartial(data["metadata"], self)
		elif isinstance(path, EepyFileServerFilePartial):
			url = f"{self.base_url}/files/{path.path}"
			response = self._session.get(url, stream = True)
			if response.status_code != 200:
				raise Exception(response.status_code)
			return EepyFileServerFile(response.iter_content(chunk_size = CHUNK_SIZE), path.metadata)

	def upload_file(self, path, file: IOBase, *, ignore_empty_check: bool = False):
		headers = None
		if path.startswith("/"):
			path = path[1:]
		if not ignore_empty_check:
			if _check_if_not_empty(file):
				headers = {"Content-Length": "0"}
		url = f"{self.base_url}/files/{path}"
		try:
			response = self._session.post(url, data=file, headers=headers)
		except Exception as e:
			raise Exception(str(e), 400)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def overwrite_file(self, path, file: IOBase, *, ignore_empty_check: bool = False):
		headers = None
		if path.startswith("/"):
			path = path[1:]
		if not ignore_empty_check:
			if _check_if_not_empty(file):
				headers = {"Content-Length": "0"}
		url = f"{self.base_url}/files/{path}"
		try:
			response = self._session.patch(url, data=file, headers=headers)
		except Exception as e:
			raise Exception(str(e), 400)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def delete_file(self, path):
		if path.startswith("/"):
			path = path[1:]
		url = f"{self.base_url}/files/{path}"
		response = self._session.delete(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def rename_file(self, path, name):
		if path.startswith("/"):
			path = path[1:]
		url = f"{self.base_url}/files/rename/{path}"
		response = self._session.patch(url, json={"newname": name})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def rename_directory(self, path, name):
		if path.startswith("/"):
			path = path[1:]
		url = f"{self.base_url}/tree/rename/{path}"
		response = self._session.patch(url, json={"newname": name})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def move_file(self, from_path, to_path):
		if from_path.startswith("/"):
			from_path = from_path[1:]
		if to_path.startswith("/"):
			to_path = to_path[1:]
		url = f"{self.base_url}/files/move/{from_path}"
		response = self._session.post(url, json={"newpath": to_path})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data
	
	def move_directory(self, from_path, to_path):
		if from_path.startswith("/"):
			from_path = from_path[1:]
		if to_path.startswith("/"):
			to_path = to_path[1:]
		url = f"{self.base_url}/tree/move/{from_path}"
		response = self._session.post(url, json={"newpath": to_path})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def copy_file(self, from_path, to_path, _error_if_exists: bool = False):
		if from_path.startswith("/"):
			from_path = from_path[1:]
		if to_path.startswith("/"):
			to_path = to_path[1:]
		url = f"{self.base_url}/files/copy/{from_path}"
		response = self._session.post(url, json={"newpath": to_path, "err_if_exists": _error_if_exists})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def copy_directory(self, from_path, to_path):
		if from_path.startswith("/"):
			from_path = from_path[1:]
		if to_path.startswith("/"):
			to_path = to_path[1:]
		url = f"{self.base_url}/tree/copy/{from_path}"
		response = self._session.post(url, json={"newpath": to_path})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def bulk_copy_files(self, copy_to_path, file_paths: list, _error_if_exists: bool = False):
		normalized_file_paths = []
		if copy_to_path.startswith("/"):
			copy_to_path = copy_to_path[1:]
		for file in file_paths:
			if file.startswith("/"):
				file = file[1:]
			normalized_file_paths.append(file)
		url = f"{self.base_url}/bulk/copy/files/{copy_to_path}"
		response = self._session.post(url, json={"files": normalized_file_paths, "err_if_exists": _error_if_exists})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def bulk_delete_files(self, file_paths: list, _error_if_not_exists: bool = False):
		normalized_file_paths = []
		for file in file_paths:
			if file.startswith("/"):
				file = file[1:]
			normalized_file_paths.append(file)
		url = f"{self.base_url}/bulk/delete/files"
		response = self._session.delete(url, json={"files": normalized_file_paths, "err_if_not_exists": _error_if_not_exists})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def bulk_move_files(self, move_to_path, file_paths: list):
		normalized_file_paths = []
		if move_to_path.startswith("/"):
			move_to_path = move_to_path[1:]
		for file in file_paths:
			if file.startswith("/"):
				file = file[1:]
			normalized_file_paths.append(file)
		url = f"{self.base_url}/bulk/move/files/{move_to_path}"
		response = self._session.post(url, json={"files": normalized_file_paths})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data

	def get_config(self):
		url = f"{self.base_url}/config"
		response = self._session.get(url)
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		return data["config"]

	def update_config(self, config: dict, *, _print_warnings: bool = False):
		url = f"{self.base_url}/config"
		response = self._session.post(url, json={"config": config})
		data = response.json()
		if response.status_code != 200:
			raise Exception(data["error"], response.status_code)
		if "warnings" in data and _print_warnings:
			for warning in data["warnings"]:
				print(f"EepyFileServer.update_config(): {warning}")
		return data

	def url_to_file(self, path, *, check_if_exists = False) -> str:
		if path.startswith("/"):
			path = path[1:]
		if check_if_exists:
			url = f"{self.base_url}/metadata/{path}"
			response = self._session.get(url)
			data = response.json()
			if response.status_code != 200:
				raise Exception(data["error"], response.status_code)
		return f"{self.base_url}/files/{path}"

	def _validate(self):
		url = f"{self.base_url}/instance"
		response = self._session.get(url)
		if response.status_code != 200:
			raise Exception(f"something went wrong: {response.status_code}")
