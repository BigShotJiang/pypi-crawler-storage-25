# eepyfileserver-wrapper

make sure you have all the dependencies installed by running `pip install -r requirements.txt`

docs will be here when i uneep

## Examples

### Logging in and getting instance info

```python
from eepyfileserverwrapper import EepyFileServer

api = EepyFileServer(base_url="https://example.com", password="password")
print(api.get_instance_info()) # {'instance': {'version': ..., ...}, ...}
```

### Managing directories
```python
print(api.get_tree()) # prints the whole tree with EepyFileServerDirectory objects
print(api.get_tree("/path/somethinghere")) # prints the same as above but only for specified path

# -----

api.add_directory("/new_dir/something") # adds a new directory
api.remove_directory("/new_dir/something") # removes the right most directory
```

### Getting a list of files
```python
print(api.get_filelist()) # [working_path: ["file1.txt", "something.py"], ...]
```

### Getting a file
```python
filepartial = api.get_file("path/to/file1.txt") # returns a partial file
print(filepartial.metadata) # FileMetadata(...)

file = filepartial.fetch_file()
print(file.name) # "file1.txt"
for chunk in file.stream: #4096 byte chunks
	print(chunk)

loadedfile = file.load()
print(loadedfile) # returns every single chunk concatenated

file.save("local/path/to/file.txt")
```

### Renaming a file
```python
api.rename_file("path/to/file1.txt", "file6.txt")
```

### Uploading a file
```python
with open("path/to/file3.txt", "rb") as f:
	api.upload_file("path/to/file3.txt", f)
```

### Overwriting a file
```python
with open("path/to/file4.txt", "rb") as f:
	api.overwrite_file("path/to/file3.txt", f)
```

### Deleting a file
```python
api.delete_file("path/to/file1.txt")
```

### Moving a file
```python
api.move_file("old/path/to/file1.txt", "new/path/to/file1.txt")
```