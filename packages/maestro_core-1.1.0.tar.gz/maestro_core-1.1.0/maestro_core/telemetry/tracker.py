"""Tracker de télémétrie — identité client, profil de requête Anthropic,
événements structurés et persistance JSONL."""

from __future__ import annotations

import json
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

# ── Constantes par défaut ──

DEFAULT_ANTHROPIC_VERSION: str = "2023-06-01"
DEFAULT_APP_NAME: str = "claude-code"
DEFAULT_RUNTIME: str = "python"
DEFAULT_AGENTIC_BETA: str = "claude-code-20250219"
DEFAULT_PROMPT_CACHING_SCOPE_BETA: str = "prompt-caching-scope-2026-01-05"


# ── Identité client ──


@dataclass
class ClientIdentity:
    """Identifie le client auprès de l'API Anthropic."""

    app_name: str = DEFAULT_APP_NAME
    app_version: str = "0.1.0"
    runtime: str = DEFAULT_RUNTIME

    def with_runtime(self, runtime: str) -> ClientIdentity:
        self.runtime = runtime
        return self

    def user_agent(self) -> str:
        return f"{self.app_name}/{self.app_version}"


# ── Profil de requête Anthropic ──


@dataclass
class AnthropicRequestProfile:
    """Profil pour les requêtes vers l'API Anthropic : version, betas, body supplémentaire."""

    anthropic_version: str = DEFAULT_ANTHROPIC_VERSION
    client_identity: ClientIdentity = field(default_factory=ClientIdentity)
    betas: list[str] = field(default_factory=lambda: [
        DEFAULT_AGENTIC_BETA,
        DEFAULT_PROMPT_CACHING_SCOPE_BETA,
    ])
    extra_body: dict[str, Any] = field(default_factory=dict)

    def with_beta(self, beta: str) -> AnthropicRequestProfile:
        if beta not in self.betas:
            self.betas.append(beta)
        return self

    def with_extra_body(self, key: str, value: Any) -> AnthropicRequestProfile:
        self.extra_body[key] = value
        return self

    def header_pairs(self) -> list[tuple[str, str]]:
        """Retourne les en-têtes HTTP à envoyer avec chaque requête."""
        headers: list[tuple[str, str]] = [
            ("anthropic-version", self.anthropic_version),
            ("user-agent", self.client_identity.user_agent()),
        ]
        if self.betas:
            headers.append(("anthropic-beta", ",".join(self.betas)))
        return headers

    def render_json_body(self, request: dict[str, Any]) -> dict[str, Any]:
        """Fusionne le body de la requête avec les champs extra et betas."""
        body = dict(request)
        for key, value in self.extra_body.items():
            body[key] = value
        if self.betas:
            body["betas"] = list(self.betas)
        return body


# ── Événements de télémétrie ──


class TelemetryEventType(str, Enum):
    HTTP_REQUEST_STARTED = "http_request_started"
    HTTP_REQUEST_SUCCEEDED = "http_request_succeeded"
    HTTP_REQUEST_FAILED = "http_request_failed"
    ANALYTICS = "analytics"
    SESSION_TRACE = "session_trace"


@dataclass
class AnalyticsEvent:
    """Événement analytique avec namespace, action et propriétés."""

    namespace: str
    action: str
    properties: dict[str, Any] = field(default_factory=dict)

    def with_property(self, key: str, value: Any) -> AnalyticsEvent:
        self.properties[key] = value
        return self


@dataclass
class SessionTraceRecord:
    """Enregistrement de trace dans une session."""

    session_id: str
    sequence: int
    name: str
    timestamp_ms: int
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass
class TelemetryEvent:
    """Événement de télémétrie polymorphe — HTTP, analytics ou trace de session."""

    type: TelemetryEventType
    session_id: str = ""
    attempt: int = 0
    method: str = ""
    path: str = ""
    status: int = 0
    request_id: str | None = None
    error: str = ""
    retryable: bool = False
    attributes: dict[str, Any] = field(default_factory=dict)
    analytics: AnalyticsEvent | None = None
    trace: SessionTraceRecord | None = None

    def to_dict(self) -> dict[str, Any]:
        """Sérialise l'événement en dict pour JSON."""
        if self.type == TelemetryEventType.ANALYTICS and self.analytics:
            return {
                "type": "analytics",
                "namespace": self.analytics.namespace,
                "action": self.analytics.action,
                "properties": self.analytics.properties,
            }
        if self.type == TelemetryEventType.SESSION_TRACE and self.trace:
            return {
                "type": "session_trace",
                "session_id": self.trace.session_id,
                "sequence": self.trace.sequence,
                "name": self.trace.name,
                "timestamp_ms": self.trace.timestamp_ms,
                "attributes": self.trace.attributes,
            }
        base: dict[str, Any] = {
            "type": self.type.value,
            "session_id": self.session_id,
            "attempt": self.attempt,
            "method": self.method,
            "path": self.path,
        }
        if self.type == TelemetryEventType.HTTP_REQUEST_SUCCEEDED:
            base["status"] = self.status
            if self.request_id:
                base["request_id"] = self.request_id
        if self.type == TelemetryEventType.HTTP_REQUEST_FAILED:
            base["error"] = self.error
            base["retryable"] = self.retryable
        if self.attributes:
            base["attributes"] = self.attributes
        return base


# ── Sinks de télémétrie ──


class TelemetrySink(ABC):
    """Interface pour les sinks de télémétrie (thread-safe)."""

    @abstractmethod
    def record(self, event: TelemetryEvent) -> None: ...


class MemoryTelemetrySink(TelemetrySink):
    """Sink en mémoire — utile pour les tests."""

    def __init__(self) -> None:
        self._events: list[TelemetryEvent] = []
        self._lock = threading.Lock()

    def record(self, event: TelemetryEvent) -> None:
        with self._lock:
            self._events.append(event)

    def events(self) -> list[TelemetryEvent]:
        with self._lock:
            return list(self._events)


class JsonlTelemetrySink(TelemetrySink):
    """Sink qui persiste les événements en JSONL dans un fichier."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._file = open(self._path, "a", encoding="utf-8")  # noqa: SIM115
        self._lock = threading.Lock()

    @property
    def path(self) -> Path:
        return self._path

    def record(self, event: TelemetryEvent) -> None:
        try:
            line = json.dumps(event.to_dict(), ensure_ascii=False)
        except (TypeError, ValueError):
            return
        with self._lock:
            self._file.write(line + "\n")
            self._file.flush()


# ── Traceur de session ──


def _current_timestamp_ms() -> int:
    return int(time.time() * 1000)


def _merge_trace_fields(
    method: str, path: str, attempt: int, attributes: dict[str, Any]
) -> dict[str, Any]:
    merged = dict(attributes)
    merged["method"] = method
    merged["path"] = path
    merged["attempt"] = attempt
    return merged


class SessionTracer:
    """Traceur de session — enregistre les événements HTTP et analytics avec un numéro de séquence."""

    def __init__(self, session_id: str, sink: TelemetrySink) -> None:
        self._session_id = session_id
        self._sequence = 0
        self._sequence_lock = threading.Lock()
        self._sink = sink

    @property
    def session_id(self) -> str:
        return self._session_id

    def _next_sequence(self) -> int:
        with self._sequence_lock:
            seq = self._sequence
            self._sequence += 1
            return seq

    def record(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        """Enregistre un événement de trace de session."""
        trace = SessionTraceRecord(
            session_id=self._session_id,
            sequence=self._next_sequence(),
            name=name,
            timestamp_ms=_current_timestamp_ms(),
            attributes=attributes or {},
        )
        self._sink.record(TelemetryEvent(
            type=TelemetryEventType.SESSION_TRACE,
            trace=trace,
        ))

    def record_http_request_started(
        self,
        attempt: int,
        method: str,
        path: str,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        attrs = attributes or {}
        self._sink.record(TelemetryEvent(
            type=TelemetryEventType.HTTP_REQUEST_STARTED,
            session_id=self._session_id,
            attempt=attempt,
            method=method,
            path=path,
            attributes=dict(attrs),
        ))
        self.record("http_request_started", _merge_trace_fields(method, path, attempt, attrs))

    def record_http_request_succeeded(
        self,
        attempt: int,
        method: str,
        path: str,
        status: int,
        request_id: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        attrs = attributes or {}
        self._sink.record(TelemetryEvent(
            type=TelemetryEventType.HTTP_REQUEST_SUCCEEDED,
            session_id=self._session_id,
            attempt=attempt,
            method=method,
            path=path,
            status=status,
            request_id=request_id,
            attributes=dict(attrs),
        ))
        trace_attrs = _merge_trace_fields(method, path, attempt, attrs)
        trace_attrs["status"] = status
        if request_id:
            trace_attrs["request_id"] = request_id
        self.record("http_request_succeeded", trace_attrs)

    def record_http_request_failed(
        self,
        attempt: int,
        method: str,
        path: str,
        error: str,
        retryable: bool,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        attrs = attributes or {}
        self._sink.record(TelemetryEvent(
            type=TelemetryEventType.HTTP_REQUEST_FAILED,
            session_id=self._session_id,
            attempt=attempt,
            method=method,
            path=path,
            error=error,
            retryable=retryable,
            attributes=dict(attrs),
        ))
        trace_attrs = _merge_trace_fields(method, path, attempt, attrs)
        trace_attrs["error"] = error
        trace_attrs["retryable"] = retryable
        self.record("http_request_failed", trace_attrs)

    def record_analytics(self, event: AnalyticsEvent) -> None:
        """Enregistre un événement analytique et une trace de session associée."""
        attributes = dict(event.properties)
        attributes["namespace"] = event.namespace
        attributes["action"] = event.action
        self._sink.record(TelemetryEvent(
            type=TelemetryEventType.ANALYTICS,
            analytics=event,
        ))
        self.record("analytics", attributes)
