"""Compat harness — extraction des manifestes commands/tools/bootstrap
depuis les sources TypeScript upstream."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


# ── Types de registre ──


class CommandSource(str, Enum):
    BUILTIN = "builtin"
    INTERNAL_ONLY = "internal_only"
    FEATURE_GATED = "feature_gated"


class ToolSource(str, Enum):
    BASE = "base"
    CONDITIONAL = "conditional"


class BootstrapPhase(str, Enum):
    CLI_ENTRY = "CliEntry"
    FAST_PATH_VERSION = "FastPathVersion"
    STARTUP_PROFILER = "StartupProfiler"
    SYSTEM_PROMPT_FAST_PATH = "SystemPromptFastPath"
    CHROME_MCP_FAST_PATH = "ChromeMcpFastPath"
    DAEMON_WORKER_FAST_PATH = "DaemonWorkerFastPath"
    BRIDGE_FAST_PATH = "BridgeFastPath"
    DAEMON_FAST_PATH = "DaemonFastPath"
    BACKGROUND_SESSION_FAST_PATH = "BackgroundSessionFastPath"
    TEMPLATE_FAST_PATH = "TemplateFastPath"
    ENVIRONMENT_RUNNER_FAST_PATH = "EnvironmentRunnerFastPath"
    MAIN_RUNTIME = "MainRuntime"


@dataclass
class CommandManifestEntry:
    name: str
    source: CommandSource


@dataclass
class ToolManifestEntry:
    name: str
    source: ToolSource


@dataclass
class CommandRegistry:
    entries: list[CommandManifestEntry] = field(default_factory=list)


@dataclass
class ToolRegistry:
    entries: list[ToolManifestEntry] = field(default_factory=list)


@dataclass
class BootstrapPlan:
    phases: list[BootstrapPhase] = field(default_factory=list)

    @classmethod
    def from_phases(cls, phases: list[BootstrapPhase]) -> BootstrapPlan:
        return cls(phases=phases)

    @classmethod
    def claude_code_default(cls) -> BootstrapPlan:
        """Plan de bootstrap par défaut pour Claude Code."""
        return cls(phases=[
            BootstrapPhase.CLI_ENTRY,
            BootstrapPhase.FAST_PATH_VERSION,
            BootstrapPhase.STARTUP_PROFILER,
            BootstrapPhase.SYSTEM_PROMPT_FAST_PATH,
            BootstrapPhase.CHROME_MCP_FAST_PATH,
            BootstrapPhase.DAEMON_WORKER_FAST_PATH,
            BootstrapPhase.BRIDGE_FAST_PATH,
            BootstrapPhase.DAEMON_FAST_PATH,
            BootstrapPhase.BACKGROUND_SESSION_FAST_PATH,
            BootstrapPhase.TEMPLATE_FAST_PATH,
            BootstrapPhase.ENVIRONMENT_RUNNER_FAST_PATH,
            BootstrapPhase.MAIN_RUNTIME,
        ])


# ── Upstream paths ──


@dataclass
class UpstreamPaths:
    """Chemins vers les sources TypeScript upstream."""

    repo_root: Path

    @classmethod
    def from_repo_root(cls, repo_root: str | Path) -> UpstreamPaths:
        return cls(repo_root=Path(repo_root))

    @classmethod
    def from_workspace_dir(cls, workspace_dir: str | Path) -> UpstreamPaths:
        workspace = Path(workspace_dir)
        try:
            workspace = workspace.resolve()
        except OSError:
            pass
        primary = workspace.parent if workspace.parent else Path("..")
        repo_root = _resolve_upstream_repo_root(primary)
        return cls(repo_root=repo_root)

    @property
    def commands_path(self) -> Path:
        return self.repo_root / "src" / "commands.ts"

    @property
    def tools_path(self) -> Path:
        return self.repo_root / "src" / "tools.ts"

    @property
    def cli_path(self) -> Path:
        return self.repo_root / "src" / "entrypoints" / "cli.tsx"


@dataclass
class ExtractedManifest:
    """Manifeste extrait des sources upstream."""

    commands: CommandRegistry
    tools: ToolRegistry
    bootstrap: BootstrapPlan


# ── Résolution du repo root ──


def _upstream_repo_candidates(primary: Path) -> list[Path]:
    candidates = [primary]
    explicit = os.environ.get("CLAUDE_CODE_UPSTREAM")
    if explicit:
        candidates.append(Path(explicit))
    ancestors = list(primary.parents)[:3]
    for ancestor in [primary, *ancestors]:
        candidates.append(ancestor / "claw-code")
        candidates.append(ancestor / "clawd-code")
    candidates.append(primary / "reference-source" / "claw-code")
    candidates.append(primary / "vendor" / "claw-code")
    # Déduplication en préservant l'ordre
    seen: set[Path] = set()
    deduped: list[Path] = []
    for c in candidates:
        if c not in seen:
            seen.add(c)
            deduped.append(c)
    return deduped


def _resolve_upstream_repo_root(primary: Path) -> Path:
    for candidate in _upstream_repo_candidates(primary):
        if (candidate / "src" / "commands.ts").is_file():
            return candidate
    return primary


# ── Extraction ──


def extract_manifest(paths: UpstreamPaths) -> ExtractedManifest:
    """Extrait le manifeste complet depuis les fichiers upstream."""
    commands_source = paths.commands_path.read_text(encoding="utf-8")
    tools_source = paths.tools_path.read_text(encoding="utf-8")
    cli_source = paths.cli_path.read_text(encoding="utf-8")
    return ExtractedManifest(
        commands=extract_commands(commands_source),
        tools=extract_tools(tools_source),
        bootstrap=extract_bootstrap_plan(cli_source),
    )


def extract_commands(source: str) -> CommandRegistry:
    """Extrait les commandes depuis le source TypeScript commands.ts."""
    entries: list[CommandManifestEntry] = []
    in_internal_block = False

    for raw_line in source.splitlines():
        line = raw_line.strip()

        if line.startswith("export const INTERNAL_ONLY_COMMANDS = ["):
            in_internal_block = True
            continue

        if in_internal_block:
            if line.startswith("]"):
                in_internal_block = False
                continue
            name = _first_identifier(line)
            if name:
                entries.append(CommandManifestEntry(name=name, source=CommandSource.INTERNAL_ONLY))
            continue

        if line.startswith("import "):
            for imported in _imported_symbols(line):
                entries.append(CommandManifestEntry(name=imported, source=CommandSource.BUILTIN))

        if "feature('" in line and "./commands/" in line:
            name = _first_assignment_identifier(line)
            if name:
                entries.append(CommandManifestEntry(name=name, source=CommandSource.FEATURE_GATED))

    return _dedupe_commands(entries)


def extract_tools(source: str) -> ToolRegistry:
    """Extrait les tools depuis le source TypeScript tools.ts."""
    entries: list[ToolManifestEntry] = []

    for raw_line in source.splitlines():
        line = raw_line.strip()

        if line.startswith("import ") and "./tools/" in line:
            for imported in _imported_symbols(line):
                if imported.endswith("Tool"):
                    entries.append(ToolManifestEntry(name=imported, source=ToolSource.BASE))

        if "feature('" in line and "Tool" in line:
            name = _first_assignment_identifier(line)
            if name and (name.endswith("Tool") or name.endswith("Tools")):
                entries.append(ToolManifestEntry(name=name, source=ToolSource.CONDITIONAL))

    return _dedupe_tools(entries)


def extract_bootstrap_plan(source: str) -> BootstrapPlan:
    """Extrait le plan de bootstrap depuis le source TypeScript cli.tsx."""
    phases = [BootstrapPhase.CLI_ENTRY]

    phase_markers = [
        ("--version", BootstrapPhase.FAST_PATH_VERSION),
        ("startupProfiler", BootstrapPhase.STARTUP_PROFILER),
        ("--dump-system-prompt", BootstrapPhase.SYSTEM_PROMPT_FAST_PATH),
        ("--claude-in-chrome-mcp", BootstrapPhase.CHROME_MCP_FAST_PATH),
        ("--daemon-worker", BootstrapPhase.DAEMON_WORKER_FAST_PATH),
        ("remote-control", BootstrapPhase.BRIDGE_FAST_PATH),
        ("args[0] === 'daemon'", BootstrapPhase.DAEMON_FAST_PATH),
    ]

    for marker, phase in phase_markers:
        if marker in source:
            phases.append(phase)

    if "args[0] === 'ps'" in source or "args.includes('--bg')" in source:
        phases.append(BootstrapPhase.BACKGROUND_SESSION_FAST_PATH)

    if "args[0] === 'new' || args[0] === 'list' || args[0] === 'reply'" in source:
        phases.append(BootstrapPhase.TEMPLATE_FAST_PATH)

    if "environment-runner" in source:
        phases.append(BootstrapPhase.ENVIRONMENT_RUNNER_FAST_PATH)

    phases.append(BootstrapPhase.MAIN_RUNTIME)
    return BootstrapPlan.from_phases(phases)


# ── Helpers d'extraction ──


def _imported_symbols(line: str) -> list[str]:
    """Extrait les symboles importés d'une ligne `import {...} from '...'`."""
    after_import = line.removeprefix("import ") if line.startswith("import ") else None
    if after_import is None:
        return []

    before_from = after_import.split(" from ")[0].strip()
    if before_from.startswith("{"):
        content = before_from.strip("{}")
        symbols = []
        for part in content.split(","):
            trimmed = part.strip()
            if not trimmed:
                continue
            # Prend le premier mot (gère les alias `X as Y`)
            first_word = trimmed.split()[0] if trimmed else ""
            if first_word:
                symbols.append(first_word)
        return symbols

    first = before_from.split(",")[0].strip()
    return [first] if first else []


def _first_assignment_identifier(line: str) -> str | None:
    """Extrait le premier identifiant d'une assignation."""
    candidate = line.strip().split("=")[0].strip()
    return _first_identifier(candidate)


def _first_identifier(line: str) -> str | None:
    """Extrait le premier identifiant alphanumérique d'une ligne."""
    result: list[str] = []
    for ch in line:
        if ch.isalnum() or ch in ("_", "-"):
            result.append(ch)
        elif result:
            break
    name = "".join(result)
    return name if name else None


def _dedupe_commands(entries: list[CommandManifestEntry]) -> CommandRegistry:
    seen: set[tuple[str, CommandSource]] = set()
    deduped: list[CommandManifestEntry] = []
    for entry in entries:
        key = (entry.name, entry.source)
        if key not in seen:
            seen.add(key)
            deduped.append(entry)
    return CommandRegistry(entries=deduped)


def _dedupe_tools(entries: list[ToolManifestEntry]) -> ToolRegistry:
    seen: set[tuple[str, ToolSource]] = set()
    deduped: list[ToolManifestEntry] = []
    for entry in entries:
        key = (entry.name, entry.source)
        if key not in seen:
            seen.add(key)
            deduped.append(entry)
    return ToolRegistry(entries=deduped)
