"""
Registre de tâches en mémoire.

Traduit depuis task_registry.rs.
"""
from __future__ import annotations
import threading
import time
from dataclasses import dataclass, field
from enum import Enum

def _now_secs() -> int:
    return int(time.time())

class TaskStatus(Enum):
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"

@dataclass
class TaskMessage:
    role: str = ""
    content: str = ""
    timestamp: int = 0

@dataclass
class Task:
    task_id: str = ""
    prompt: str = ""
    description: str | None = None
    status: TaskStatus = TaskStatus.CREATED
    created_at: int = 0
    updated_at: int = 0
    messages: list[TaskMessage] = field(default_factory=list)
    output: str = ""
    team_id: str | None = None

class TaskRegistry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._tasks: dict[str, Task] = {}
        self._counter = 0

    def create(self, prompt: str, description: str | None = None) -> Task:
        with self._lock:
            self._counter += 1
            ts = _now_secs()
            task_id = f"task_{ts:08x}_{self._counter}"
            task = Task(task_id=task_id, prompt=prompt, description=description, created_at=ts, updated_at=ts)
            self._tasks[task_id] = task
            return task

    def get(self, task_id: str) -> Task | None:
        with self._lock:
            t = self._tasks.get(task_id)
            return t

    def list(self, status_filter: TaskStatus | None = None) -> list[Task]:
        with self._lock:
            return [t for t in self._tasks.values() if status_filter is None or t.status == status_filter]

    def stop(self, task_id: str) -> Task:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                raise ValueError(f"task not found: {task_id}")
            if task.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED):
                raise ValueError(f"task {task_id} is already in terminal state: {task.status.value}")
            task.status = TaskStatus.STOPPED
            task.updated_at = _now_secs()
            return task

    def update(self, task_id: str, message: str) -> Task:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                raise ValueError(f"task not found: {task_id}")
            task.messages.append(TaskMessage(role="user", content=message, timestamp=_now_secs()))
            task.updated_at = _now_secs()
            return task

    def set_status(self, task_id: str, status: TaskStatus) -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                raise ValueError(f"task not found: {task_id}")
            task.status = status
            task.updated_at = _now_secs()

    def append_output(self, task_id: str, output: str) -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                raise ValueError(f"task not found: {task_id}")
            task.output += output
            task.updated_at = _now_secs()

    def output(self, task_id: str) -> str:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                raise ValueError(f"task not found: {task_id}")
            return task.output

    def assign_team(self, task_id: str, team_id: str) -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                raise ValueError(f"task not found: {task_id}")
            task.team_id = team_id
            task.updated_at = _now_secs()

    def remove(self, task_id: str) -> Task | None:
        with self._lock:
            return self._tasks.pop(task_id, None)

    def len(self) -> int:
        with self._lock:
            return len(self._tasks)

    def is_empty(self) -> bool:
        return self.len() == 0

