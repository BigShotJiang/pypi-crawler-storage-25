"""
Recettes de récupération pour les scénarios de défaillance connus.

Traduit depuis recovery_recipes.rs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum

class FailureScenario(Enum):
    TRUST_PROMPT_UNRESOLVED = "trust_prompt_unresolved"
    PROMPT_MISDELIVERY = "prompt_misdelivery"
    STALE_BRANCH = "stale_branch"
    COMPILE_RED_CROSS_CRATE = "compile_red_cross_crate"
    MCP_HANDSHAKE_FAILURE = "mcp_handshake_failure"
    PARTIAL_PLUGIN_STARTUP = "partial_plugin_startup"

    @staticmethod
    def all() -> list[FailureScenario]:
        return list(FailureScenario)

@dataclass
class RecoveryStep:
    pass

class StepAcceptTrustPrompt(RecoveryStep):
    pass
class StepRedirectPromptToAgent(RecoveryStep):
    pass
class StepRebaseBranch(RecoveryStep):
    pass
class StepCleanBuild(RecoveryStep):
    pass

@dataclass
class StepRetryMcpHandshake(RecoveryStep):
    timeout: int = 5000

@dataclass
class StepRestartPlugin(RecoveryStep):
    name: str = ""

@dataclass
class StepEscalateToHuman(RecoveryStep):
    reason: str = ""

class EscalationPolicy(Enum):
    ALERT_HUMAN = "alert_human"
    LOG_AND_CONTINUE = "log_and_continue"
    ABORT = "abort"

@dataclass
class RecoveryRecipe:
    scenario: FailureScenario = FailureScenario.TRUST_PROMPT_UNRESOLVED
    steps: list[RecoveryStep] = field(default_factory=list)
    max_attempts: int = 1
    escalation_policy: EscalationPolicy = EscalationPolicy.ALERT_HUMAN

@dataclass
class RecoveryResult:
    pass

@dataclass
class RecoveryRecovered(RecoveryResult):
    steps_taken: int = 0

@dataclass
class RecoveryPartial(RecoveryResult):
    recovered: list[RecoveryStep] = field(default_factory=list)
    remaining: list[RecoveryStep] = field(default_factory=list)

@dataclass
class RecoveryEscalationRequired(RecoveryResult):
    reason: str = ""

@dataclass
class RecoveryEvent:
    pass
class RecoverySucceeded(RecoveryEvent):
    pass
class RecoveryFailed(RecoveryEvent):
    pass
class RecoveryEscalated(RecoveryEvent):
    pass

@dataclass
class RecoveryAttempted(RecoveryEvent):
    scenario: FailureScenario = FailureScenario.TRUST_PROMPT_UNRESOLVED
    recipe: RecoveryRecipe = field(default_factory=RecoveryRecipe)
    result: RecoveryResult = field(default_factory=RecoveryResult)

class RecoveryContext:
    def __init__(self) -> None:
        self._attempts: dict[FailureScenario, int] = {}
        self._events: list[RecoveryEvent] = []
        self._fail_at_step: int | None = None

    def with_fail_at_step(self, index: int) -> RecoveryContext:
        self._fail_at_step = index
        return self

    def events(self) -> list[RecoveryEvent]:
        return self._events

    def attempt_count(self, scenario: FailureScenario) -> int:
        return self._attempts.get(scenario, 0)

def recipe_for(scenario: FailureScenario) -> RecoveryRecipe:
    recipes = {
        FailureScenario.TRUST_PROMPT_UNRESOLVED: RecoveryRecipe(scenario=scenario, steps=[StepAcceptTrustPrompt()], max_attempts=1, escalation_policy=EscalationPolicy.ALERT_HUMAN),
        FailureScenario.PROMPT_MISDELIVERY: RecoveryRecipe(scenario=scenario, steps=[StepRedirectPromptToAgent()], max_attempts=1, escalation_policy=EscalationPolicy.ALERT_HUMAN),
        FailureScenario.STALE_BRANCH: RecoveryRecipe(scenario=scenario, steps=[StepRebaseBranch(), StepCleanBuild()], max_attempts=1, escalation_policy=EscalationPolicy.ALERT_HUMAN),
        FailureScenario.COMPILE_RED_CROSS_CRATE: RecoveryRecipe(scenario=scenario, steps=[StepCleanBuild()], max_attempts=1, escalation_policy=EscalationPolicy.ALERT_HUMAN),
        FailureScenario.MCP_HANDSHAKE_FAILURE: RecoveryRecipe(scenario=scenario, steps=[StepRetryMcpHandshake(timeout=5000)], max_attempts=1, escalation_policy=EscalationPolicy.ABORT),
        FailureScenario.PARTIAL_PLUGIN_STARTUP: RecoveryRecipe(scenario=scenario, steps=[StepRestartPlugin(name="stalled"), StepRetryMcpHandshake(timeout=3000)], max_attempts=1, escalation_policy=EscalationPolicy.LOG_AND_CONTINUE),
    }
    return recipes[scenario]

def attempt_recovery(scenario: FailureScenario, ctx: RecoveryContext) -> RecoveryResult:
    recipe = recipe_for(scenario)
    count = ctx._attempts.get(scenario, 0)
    if count >= recipe.max_attempts:
        result = RecoveryEscalationRequired(reason=f"max recovery attempts ({recipe.max_attempts}) exceeded for {scenario.value}")
        ctx._events.append(RecoveryAttempted(scenario=scenario, recipe=recipe, result=result))
        ctx._events.append(RecoveryEscalated())
        return result
    ctx._attempts[scenario] = count + 1
    executed: list[RecoveryStep] = []
    failed = False
    for i, step in enumerate(recipe.steps):
        if ctx._fail_at_step == i:
            failed = True
            break
        executed.append(step)
    if failed:
        remaining = recipe.steps[len(executed):]
        if not executed:
            result = RecoveryEscalationRequired(reason=f"recovery failed at first step for {scenario.value}")
        else:
            result = RecoveryPartial(recovered=executed, remaining=remaining)
    else:
        result = RecoveryRecovered(steps_taken=len(recipe.steps))
    ctx._events.append(RecoveryAttempted(scenario=scenario, recipe=recipe, result=result))
    if isinstance(result, RecoveryRecovered):
        ctx._events.append(RecoverySucceeded())
    elif isinstance(result, RecoveryPartial):
        ctx._events.append(RecoveryFailed())
    else:
        ctx._events.append(RecoveryEscalated())
    return result
