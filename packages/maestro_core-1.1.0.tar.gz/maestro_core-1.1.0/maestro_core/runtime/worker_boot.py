"""
Machine à états de démarrage des workers.

Traduit depuis worker_boot.rs.
"""
from __future__ import annotations
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

def _now_secs() -> int:
    return int(time.time())

class WorkerStatus(Enum):
    SPAWNING = "spawning"
    TRUST_REQUIRED = "trust_required"
    READY_FOR_PROMPT = "ready_for_prompt"
    PROMPT_ACCEPTED = "prompt_accepted"
    RUNNING = "running"
    BLOCKED = "blocked"
    FINISHED = "finished"
    FAILED = "failed"

class WorkerFailureKind(Enum):
    TRUST_GATE = "trust_gate"
    PROMPT_DELIVERY = "prompt_delivery"
    PROTOCOL = "protocol"

class WorkerEventKind(Enum):
    SPAWNING = "spawning"
    TRUST_REQUIRED = "trust_required"
    TRUST_RESOLVED = "trust_resolved"
    READY_FOR_PROMPT = "ready_for_prompt"
    PROMPT_ACCEPTED = "prompt_accepted"
    PROMPT_MISDELIVERY = "prompt_misdelivery"
    PROMPT_REPLAY_ARMED = "prompt_replay_armed"
    RUNNING = "running"
    RESTARTED = "restarted"
    FINISHED = "finished"
    FAILED = "failed"

@dataclass
class WorkerFailure:
    kind: WorkerFailureKind = WorkerFailureKind.PROTOCOL
    message: str = ""
    created_at: int = 0

@dataclass
class WorkerEvent:
    seq: int = 0
    kind: WorkerEventKind = WorkerEventKind.SPAWNING
    status: WorkerStatus = WorkerStatus.SPAWNING
    detail: str | None = None
    timestamp: int = 0

@dataclass
class Worker:
    worker_id: str = ""
    cwd: str = ""
    status: WorkerStatus = WorkerStatus.SPAWNING
    trust_auto_resolve: bool = False
    trust_gate_cleared: bool = False
    auto_recover_prompt_misdelivery: bool = False
    prompt_delivery_attempts: int = 0
    last_prompt: str | None = None
    replay_prompt: str | None = None
    last_error: WorkerFailure | None = None
    created_at: int = 0
    updated_at: int = 0
    events: list[WorkerEvent] = field(default_factory=list)

@dataclass
class WorkerReadySnapshot:
    worker_id: str = ""
    status: WorkerStatus = WorkerStatus.SPAWNING
    ready: bool = False
    blocked: bool = False
    replay_prompt_ready: bool = False
    last_error: WorkerFailure | None = None

class WorkerRegistry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._workers: dict[str, Worker] = {}
        self._counter = 0

    def create(self, cwd: str, trusted_roots: list[str] | None = None, auto_recover: bool = True) -> Worker:
        with self._lock:
            self._counter += 1
            ts = _now_secs()
            wid = f"worker_{ts:08x}_{self._counter}"
            trust_auto = any(_path_matches(cwd, r) for r in (trusted_roots or []))
            worker = Worker(worker_id=wid, cwd=cwd, trust_auto_resolve=trust_auto, auto_recover_prompt_misdelivery=auto_recover, created_at=ts, updated_at=ts)
            _push_event(worker, WorkerEventKind.SPAWNING, WorkerStatus.SPAWNING, "worker created")
            self._workers[wid] = worker
            return worker

    def get(self, worker_id: str) -> Worker | None:
        with self._lock:
            return self._workers.get(worker_id)

    def observe(self, worker_id: str, screen_text: str) -> Worker:
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                raise ValueError(f"worker not found: {worker_id}")
            lowered = screen_text.lower()
            if not worker.trust_gate_cleared and _detect_trust_prompt(lowered):
                worker.status = WorkerStatus.TRUST_REQUIRED
                worker.last_error = WorkerFailure(kind=WorkerFailureKind.TRUST_GATE, message="worker boot blocked on trust prompt", created_at=_now_secs())
                _push_event(worker, WorkerEventKind.TRUST_REQUIRED, WorkerStatus.TRUST_REQUIRED, "trust prompt detected")
                if worker.trust_auto_resolve:
                    worker.trust_gate_cleared = True
                    worker.last_error = None
                    worker.status = WorkerStatus.SPAWNING
                    _push_event(worker, WorkerEventKind.TRUST_RESOLVED, WorkerStatus.SPAWNING, "auto-resolved")
                else:
                    return worker
            if _detect_ready(screen_text, lowered) and worker.status not in (WorkerStatus.READY_FOR_PROMPT, WorkerStatus.RUNNING):
                worker.status = WorkerStatus.READY_FOR_PROMPT
                if worker.last_error and worker.last_error.kind == WorkerFailureKind.TRUST_GATE:
                    worker.last_error = None
                _push_event(worker, WorkerEventKind.READY_FOR_PROMPT, WorkerStatus.READY_FOR_PROMPT, "ready for prompt")
            return worker

    def resolve_trust(self, worker_id: str) -> Worker:
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                raise ValueError(f"worker not found: {worker_id}")
            if worker.status != WorkerStatus.TRUST_REQUIRED:
                raise ValueError(f"worker is not waiting on trust; status: {worker.status.value}")
            worker.trust_gate_cleared = True
            worker.last_error = None
            worker.status = WorkerStatus.SPAWNING
            _push_event(worker, WorkerEventKind.TRUST_RESOLVED, WorkerStatus.SPAWNING, "trust resolved manually")
            return worker

    def send_prompt(self, worker_id: str, prompt: str | None = None) -> Worker:
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                raise ValueError(f"worker not found: {worker_id}")
            if worker.status != WorkerStatus.READY_FOR_PROMPT:
                raise ValueError(f"worker is not ready for prompt delivery; status: {worker.status.value}")
            next_prompt = (prompt.strip() if prompt and prompt.strip() else None) or worker.replay_prompt
            if not next_prompt:
                raise ValueError(f"worker has no prompt to send or replay")
            worker.prompt_delivery_attempts += 1
            worker.last_prompt = next_prompt
            worker.replay_prompt = None
            worker.last_error = None
            worker.status = WorkerStatus.PROMPT_ACCEPTED
            _push_event(worker, WorkerEventKind.PROMPT_ACCEPTED, WorkerStatus.PROMPT_ACCEPTED, f"prompt accepted: {next_prompt[:48]}")
            return worker

    def await_ready(self, worker_id: str) -> WorkerReadySnapshot:
        worker = self.get(worker_id)
        if not worker:
            raise ValueError(f"worker not found: {worker_id}")
        return WorkerReadySnapshot(worker_id=worker.worker_id, status=worker.status, ready=worker.status == WorkerStatus.READY_FOR_PROMPT, blocked=worker.status in (WorkerStatus.TRUST_REQUIRED, WorkerStatus.BLOCKED), replay_prompt_ready=worker.replay_prompt is not None, last_error=worker.last_error)

    def restart(self, worker_id: str) -> Worker:
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                raise ValueError(f"worker not found: {worker_id}")
            worker.status = WorkerStatus.SPAWNING
            worker.trust_gate_cleared = False
            worker.last_prompt = None
            worker.replay_prompt = None
            worker.last_error = None
            worker.prompt_delivery_attempts = 0
            _push_event(worker, WorkerEventKind.RESTARTED, WorkerStatus.SPAWNING, "worker restarted")
            return worker

    def terminate(self, worker_id: str) -> Worker:
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                raise ValueError(f"worker not found: {worker_id}")
            worker.status = WorkerStatus.FINISHED
            _push_event(worker, WorkerEventKind.FINISHED, WorkerStatus.FINISHED, "terminated")
            return worker


def _push_event(worker: Worker, kind: WorkerEventKind, status: WorkerStatus, detail: str | None) -> None:
    ts = _now_secs()
    seq = len(worker.events) + 1
    worker.updated_at = ts
    worker.events.append(WorkerEvent(seq=seq, kind=kind, status=status, detail=detail, timestamp=ts))

def _path_matches(cwd: str, root: str) -> bool:
    try:
        c = Path(cwd).resolve()
        r = Path(root).resolve()
    except OSError:
        c = Path(cwd)
        r = Path(root)
    return c == r or str(c).startswith(str(r) + "/")

def _detect_trust_prompt(lowered: str) -> bool:
    cues = ["do you trust the files in this folder", "trust the files in this folder", "trust this folder", "allow and continue", "yes, proceed"]
    return any(c in lowered for c in cues)

def _detect_ready(screen_text: str, lowered: str) -> bool:
    cues = ["ready for input", "ready for your input", "ready for prompt", "send a message"]
    if any(c in lowered for c in cues):
        return True
    lines = [l for l in screen_text.split("\n") if l.strip()]
    if not lines:
        return False
    last = lines[-1].strip()
    if last.endswith("$") or last.endswith("%") or last.endswith("#"):
        return False
    return last in (">", ">>", ">>>") or last.startswith("> ") or "| >" in last

