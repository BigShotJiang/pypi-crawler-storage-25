"""
Politique de permissions et autorisation des outils.

Traduit depuis permissions.rs.
"""

from __future__ import annotations

import json as _json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Protocol


class PermissionMode(Enum):
    """Mode de permission actif."""
    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"
    DANGER_FULL_ACCESS = "danger-full-access"
    PROMPT = "prompt"
    ALLOW = "allow"

    def as_str(self) -> str:
        return self.value

    def __ge__(self, other: PermissionMode) -> bool:
        order = {
            PermissionMode.READ_ONLY: 0,
            PermissionMode.WORKSPACE_WRITE: 1,
            PermissionMode.DANGER_FULL_ACCESS: 2,
            PermissionMode.PROMPT: 3,
            PermissionMode.ALLOW: 4,
        }
        return order.get(self, 0) >= order.get(other, 0)

    def __gt__(self, other: PermissionMode) -> bool:
        return self >= other and self != other


class PermissionOverride(Enum):
    """Décision de remplacement par un hook."""
    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"


@dataclass
class PermissionContext:
    """Contexte additionnel fourni par les hooks."""
    override_decision: PermissionOverride | None = None
    override_reason: str | None = None


@dataclass
class PermissionRequest:
    """Requête de permission envoyée au prompteur."""
    tool_name: str = ""
    input: str = ""
    current_mode: PermissionMode = PermissionMode.READ_ONLY
    required_mode: PermissionMode = PermissionMode.DANGER_FULL_ACCESS
    reason: str | None = None


@dataclass
class PermissionPromptDecision:
    """Résultat d'un prompt interactif."""
    allowed: bool = True
    reason: str = ""

    @staticmethod
    def allow() -> PermissionPromptDecision:
        return PermissionPromptDecision(allowed=True)

    @staticmethod
    def deny(reason: str) -> PermissionPromptDecision:
        return PermissionPromptDecision(allowed=False, reason=reason)


class PermissionPrompter(ABC):
    """Interface pour demander une confirmation interactive."""
    @abstractmethod
    def decide(self, request: PermissionRequest) -> PermissionPromptDecision:
        ...


@dataclass
class PermissionOutcome:
    """Résultat de l'autorisation."""
    allowed: bool = True
    reason: str = ""

    @staticmethod
    def allow() -> PermissionOutcome:
        return PermissionOutcome(allowed=True)

    @staticmethod
    def deny(reason: str) -> PermissionOutcome:
        return PermissionOutcome(allowed=False, reason=reason)


@dataclass
class _PermissionRule:
    raw: str
    tool_name: str
    matcher: _PermissionRuleMatcher

    def matches(self, tool_name: str, input_str: str) -> bool:
        if self.tool_name != tool_name:
            return False
        if isinstance(self.matcher, _MatcherAny):
            return True
        subject = _extract_permission_subject(input_str)
        if subject is None:
            return False
        if isinstance(self.matcher, _MatcherExact):
            return subject == self.matcher.value
        if isinstance(self.matcher, _MatcherPrefix):
            return subject.startswith(self.matcher.prefix)
        return False

    @staticmethod
    def parse(raw: str) -> _PermissionRule:
        trimmed = raw.strip()
        open_idx = _find_first_unescaped(trimmed, "(")
        close_idx = _find_last_unescaped(trimmed, ")")
        if open_idx is not None and close_idx is not None and close_idx == len(trimmed) - 1 and open_idx < close_idx:
            tool_name = trimmed[:open_idx].strip()
            content = trimmed[open_idx + 1:close_idx]
            if tool_name:
                matcher = _parse_rule_matcher(content)
                return _PermissionRule(raw=trimmed, tool_name=tool_name, matcher=matcher)
        return _PermissionRule(raw=trimmed, tool_name=trimmed, matcher=_MatcherAny())


class _PermissionRuleMatcher:
    pass

@dataclass
class _MatcherAny(_PermissionRuleMatcher):
    pass

@dataclass
class _MatcherExact(_PermissionRuleMatcher):
    value: str = ""

@dataclass
class _MatcherPrefix(_PermissionRuleMatcher):
    prefix: str = ""


def _parse_rule_matcher(content: str) -> _PermissionRuleMatcher:
    unescaped = content.strip().replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\")
    if not unescaped or unescaped == "*":
        return _MatcherAny()
    if unescaped.endswith(":*"):
        return _MatcherPrefix(prefix=unescaped[:-2])
    return _MatcherExact(value=unescaped)


def _find_first_unescaped(value: str, needle: str) -> int | None:
    escaped = False
    for i, ch in enumerate(value):
        if ch == "\\":
            escaped = not escaped
            continue
        if ch == needle and not escaped:
            return i
        escaped = False
    return None


def _find_last_unescaped(value: str, needle: str) -> int | None:
    chars = list(enumerate(value))
    for pos in range(len(chars) - 1, -1, -1):
        idx, ch = chars[pos]
        if ch != needle:
            continue
        backslashes = 0
        for prev_pos in range(pos - 1, -1, -1):
            if chars[prev_pos][1] == "\\":
                backslashes += 1
            else:
                break
        if backslashes % 2 == 0:
            return idx
    return None


def _extract_permission_subject(input_str: str) -> str | None:
    try:
        parsed = _json.loads(input_str)
        if isinstance(parsed, dict):
            for key in ("command", "path", "file_path", "filePath", "notebook_path",
                        "notebookPath", "url", "pattern", "code", "message"):
                val = parsed.get(key)
                if isinstance(val, str):
                    return val
    except (ValueError, TypeError):
        pass
    if input_str.strip():
        return input_str
    return None


class PermissionPolicy:
    """Politique de permissions avec règles et mode actif."""

    def __init__(self, active_mode: PermissionMode) -> None:
        self._active_mode = active_mode
        self._tool_requirements: dict[str, PermissionMode] = {}
        self._allow_rules: list[_PermissionRule] = []
        self._deny_rules: list[_PermissionRule] = []
        self._ask_rules: list[_PermissionRule] = []

    def with_tool_requirement(self, tool_name: str, required_mode: PermissionMode) -> PermissionPolicy:
        self._tool_requirements[tool_name] = required_mode
        return self

    def with_permission_rules(self, config: object) -> PermissionPolicy:
        """Accepte un RuntimePermissionRuleConfig."""
        self._allow_rules = [_PermissionRule.parse(r) for r in getattr(config, "_allow", getattr(config, "allow", lambda: [])() if callable(getattr(config, "allow", None)) else [])]
        self._deny_rules = [_PermissionRule.parse(r) for r in getattr(config, "_deny", getattr(config, "deny", lambda: [])() if callable(getattr(config, "deny", None)) else [])]
        self._ask_rules = [_PermissionRule.parse(r) for r in getattr(config, "_ask", getattr(config, "ask", lambda: [])() if callable(getattr(config, "ask", None)) else [])]
        return self

    def active_mode(self) -> PermissionMode:
        return self._active_mode

    def required_mode_for(self, tool_name: str) -> PermissionMode:
        return self._tool_requirements.get(tool_name, PermissionMode.DANGER_FULL_ACCESS)

    def authorize(
        self, tool_name: str, input_str: str, prompter: PermissionPrompter | None = None
    ) -> PermissionOutcome:
        return self.authorize_with_context(tool_name, input_str, PermissionContext(), prompter)

    def authorize_with_context(
        self,
        tool_name: str,
        input_str: str,
        context: PermissionContext,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome:
        # Vérification des règles deny
        deny_rule = self._find_matching_rule(self._deny_rules, tool_name, input_str)
        if deny_rule:
            return PermissionOutcome.deny(
                f"Permission to use {tool_name} has been denied by rule \'{deny_rule.raw}\'"
            )

        current_mode = self.active_mode()
        required_mode = self.required_mode_for(tool_name)
        ask_rule = self._find_matching_rule(self._ask_rules, tool_name, input_str)
        allow_rule = self._find_matching_rule(self._allow_rules, tool_name, input_str)

        # Gestion des overrides par hooks
        if context.override_decision == PermissionOverride.DENY:
            reason = context.override_reason or f"tool \'{tool_name}\' denied by hook"
            return PermissionOutcome.deny(reason)
        if context.override_decision == PermissionOverride.ASK:
            reason = context.override_reason or f"tool \'{tool_name}\' requires approval due to hook guidance"
            return self._prompt_or_deny(tool_name, input_str, current_mode, required_mode, reason, prompter)
        if context.override_decision == PermissionOverride.ALLOW:
            if ask_rule:
                reason = f"tool \'{tool_name}\' requires approval due to ask rule \'{ask_rule.raw}\'"
                return self._prompt_or_deny(tool_name, input_str, current_mode, required_mode, reason, prompter)
            if allow_rule or current_mode == PermissionMode.ALLOW or current_mode >= required_mode:
                return PermissionOutcome.allow()

        # Règles ask
        if ask_rule:
            reason = f"tool \'{tool_name}\' requires approval due to ask rule \'{ask_rule.raw}\'"
            return self._prompt_or_deny(tool_name, input_str, current_mode, required_mode, reason, prompter)

        # Règles allow et vérification du mode
        if allow_rule or current_mode == PermissionMode.ALLOW or current_mode >= required_mode:
            return PermissionOutcome.allow()

        if current_mode == PermissionMode.PROMPT or (
            current_mode == PermissionMode.WORKSPACE_WRITE
            and required_mode == PermissionMode.DANGER_FULL_ACCESS
        ):
            reason = (
                f"tool \'{tool_name}\' requires approval to escalate from "
                f"{current_mode.as_str()} to {required_mode.as_str()}"
            )
            return self._prompt_or_deny(tool_name, input_str, current_mode, required_mode, reason, prompter)

        return PermissionOutcome.deny(
            f"tool \'{tool_name}\' requires {required_mode.as_str()} permission; "
            f"current mode is {current_mode.as_str()}"
        )

    @staticmethod
    def _prompt_or_deny(
        tool_name: str,
        input_str: str,
        current_mode: PermissionMode,
        required_mode: PermissionMode,
        reason: str | None,
        prompter: PermissionPrompter | None,
    ) -> PermissionOutcome:
        request = PermissionRequest(
            tool_name=tool_name,
            input=input_str,
            current_mode=current_mode,
            required_mode=required_mode,
            reason=reason,
        )
        if prompter is not None:
            decision = prompter.decide(request)
            if decision.allowed:
                return PermissionOutcome.allow()
            return PermissionOutcome.deny(decision.reason)
        return PermissionOutcome.deny(
            reason or f"tool \'{tool_name}\' requires approval to run while mode is {current_mode.as_str()}"
        )

    @staticmethod
    def _find_matching_rule(
        rules: list[_PermissionRule], tool_name: str, input_str: str
    ) -> _PermissionRule | None:
        for rule in rules:
            if rule.matches(tool_name, input_str):
                return rule
        return None
