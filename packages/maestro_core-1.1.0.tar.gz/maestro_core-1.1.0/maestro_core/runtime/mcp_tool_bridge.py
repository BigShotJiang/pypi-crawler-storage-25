"""
Pont entre la surface outil MCP et le runtime McpServerManager.

Traduit depuis mcp_tool_bridge.rs.
"""
from __future__ import annotations
import threading
from dataclasses import dataclass, field
from enum import Enum
from .mcp import mcp_tool_name

class McpConnectionStatus(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    AUTH_REQUIRED = "auth_required"
    ERROR = "error"

@dataclass
class McpResourceInfo:
    uri: str = ""
    name: str = ""
    description: str | None = None
    mime_type: str | None = None

@dataclass
class McpToolInfo:
    name: str = ""
    description: str | None = None
    input_schema: object | None = None

@dataclass
class McpServerState:
    server_name: str = ""
    status: McpConnectionStatus = McpConnectionStatus.DISCONNECTED
    tools: list[McpToolInfo] = field(default_factory=list)
    resources: list[McpResourceInfo] = field(default_factory=list)
    server_info: str | None = None
    error_message: str | None = None

class McpToolRegistry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._servers: dict[str, McpServerState] = {}

    def register_server(self, server_name: str, status: McpConnectionStatus, tools: list[McpToolInfo] | None = None, resources: list[McpResourceInfo] | None = None, server_info: str | None = None) -> None:
        with self._lock:
            self._servers[server_name] = McpServerState(server_name=server_name, status=status, tools=tools or [], resources=resources or [], server_info=server_info)

    def get_server(self, server_name: str) -> McpServerState | None:
        with self._lock:
            return self._servers.get(server_name)

    def list_servers(self) -> list[McpServerState]:
        with self._lock:
            return list(self._servers.values())

    def list_resources(self, server_name: str) -> list[McpResourceInfo]:
        with self._lock:
            state = self._servers.get(server_name)
            if not state:
                raise ValueError(f"server \'{server_name}\' not found")
            if state.status != McpConnectionStatus.CONNECTED:
                raise ValueError(f"server \'{server_name}\' is not connected (status: {state.status.value})")
            return list(state.resources)

    def list_tools(self, server_name: str) -> list[McpToolInfo]:
        with self._lock:
            state = self._servers.get(server_name)
            if not state:
                raise ValueError(f"server \'{server_name}\' not found")
            if state.status != McpConnectionStatus.CONNECTED:
                raise ValueError(f"server \'{server_name}\' is not connected")
            return list(state.tools)

    def disconnect(self, server_name: str) -> McpServerState | None:
        with self._lock:
            return self._servers.pop(server_name, None)

    def len(self) -> int:
        with self._lock:
            return len(self._servers)

    def is_empty(self) -> bool:
        return self.len() == 0
