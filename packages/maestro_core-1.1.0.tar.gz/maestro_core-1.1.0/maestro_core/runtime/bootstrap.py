"""
Plan de démarrage (bootstrap) de l'application.

Traduit depuis bootstrap.rs.
"""

from __future__ import annotations

from enum import Enum, auto


class BootstrapPhase(Enum):
    """Phases de démarrage de l'application."""
    CLI_ENTRY = auto()
    FAST_PATH_VERSION = auto()
    STARTUP_PROFILER = auto()
    SYSTEM_PROMPT_FAST_PATH = auto()
    CHROME_MCP_FAST_PATH = auto()
    DAEMON_WORKER_FAST_PATH = auto()
    BRIDGE_FAST_PATH = auto()
    DAEMON_FAST_PATH = auto()
    BACKGROUND_SESSION_FAST_PATH = auto()
    TEMPLATE_FAST_PATH = auto()
    ENVIRONMENT_RUNNER_FAST_PATH = auto()
    MAIN_RUNTIME = auto()


class BootstrapPlan:
    """Plan de bootstrap avec dédoublonnage des phases."""

    def __init__(self, phases: list[BootstrapPhase]) -> None:
        seen: set[BootstrapPhase] = set()
        deduped: list[BootstrapPhase] = []
        for phase in phases:
            if phase not in seen:
                seen.add(phase)
                deduped.append(phase)
        self._phases = deduped

    @staticmethod
    def claude_code_default() -> BootstrapPlan:
        """Plan de bootstrap par défaut pour Claude Code."""
        return BootstrapPlan([
            BootstrapPhase.CLI_ENTRY,
            BootstrapPhase.FAST_PATH_VERSION,
            BootstrapPhase.STARTUP_PROFILER,
            BootstrapPhase.SYSTEM_PROMPT_FAST_PATH,
            BootstrapPhase.CHROME_MCP_FAST_PATH,
            BootstrapPhase.DAEMON_WORKER_FAST_PATH,
            BootstrapPhase.BRIDGE_FAST_PATH,
            BootstrapPhase.DAEMON_FAST_PATH,
            BootstrapPhase.BACKGROUND_SESSION_FAST_PATH,
            BootstrapPhase.TEMPLATE_FAST_PATH,
            BootstrapPhase.ENVIRONMENT_RUNNER_FAST_PATH,
            BootstrapPhase.MAIN_RUNTIME,
        ])

    @staticmethod
    def from_phases(phases: list[BootstrapPhase]) -> BootstrapPlan:
        return BootstrapPlan(phases)

    def phases(self) -> list[BootstrapPhase]:
        return list(self._phases)
