"""
Validation de commandes bash avant exécution.

Traduit depuis bash_validation.rs -- pipeline de validation :
read-only, destructive, mode, sed, path, command semantics.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from .permissions import PermissionMode


class ValidationResult(Enum):
    """Résultat de la validation d'une commande."""
    ALLOW = "allow"


@dataclass
class ValidationBlock:
    """Commande bloquée avec raison."""
    reason: str


@dataclass
class ValidationWarn:
    """Avertissement sur une commande."""
    message: str


# Commandes d'écriture filesystem
WRITE_COMMANDS = frozenset([
    "cp", "mv", "rm", "mkdir", "rmdir", "touch", "chmod", "chown", "chgrp",
    "ln", "install", "tee", "truncate", "shred", "mkfifo", "mknod", "dd",
])

# Commandes modifiant l'état système
STATE_MODIFYING_COMMANDS = frozenset([
    "apt", "apt-get", "yum", "dnf", "pacman", "brew", "pip", "pip3", "npm",
    "yarn", "pnpm", "bun", "cargo", "gem", "go", "rustup", "docker",
    "systemctl", "service", "mount", "umount", "kill", "pkill", "killall",
    "reboot", "shutdown", "halt", "poweroff", "useradd", "userdel", "usermod",
    "groupadd", "groupdel", "crontab", "at",
])

WRITE_REDIRECTIONS = (">", ">>", ">&")

GIT_READ_ONLY_SUBCOMMANDS = frozenset([
    "status", "log", "diff", "show", "branch", "tag", "stash", "remote",
    "fetch", "ls-files", "ls-tree", "cat-file", "rev-parse", "describe",
    "shortlog", "blame", "bisect", "reflog", "config",
])

DESTRUCTIVE_PATTERNS = [
    ("rm -rf /", "Recursive forced deletion at root -- this will destroy the system"),
    ("rm -rf ~", "Recursive forced deletion of home directory"),
    ("rm -rf *", "Recursive forced deletion of all files in current directory"),
    ("rm -rf .", "Recursive forced deletion of current directory"),
    ("mkfs", "Filesystem creation will destroy existing data on the device"),
    ("dd if=", "Direct disk write -- can overwrite partitions or devices"),
    ("> /dev/sd", "Writing to raw disk device"),
    ("chmod -R 777", "Recursively setting world-writable permissions"),
    ("chmod -R 000", "Recursively removing all permissions"),
    (":(){ :|:& };:", "Fork bomb -- will crash the system"),
]

ALWAYS_DESTRUCTIVE_COMMANDS = frozenset(["shred", "wipefs"])

SEMANTIC_READ_ONLY_COMMANDS = frozenset([
    "ls", "cat", "head", "tail", "less", "more", "wc", "sort", "uniq", "grep",
    "egrep", "fgrep", "find", "which", "whereis", "whatis", "man", "info",
    "file", "stat", "du", "df", "free", "uptime", "uname", "hostname", "whoami",
    "id", "groups", "env", "printenv", "echo", "printf", "date", "cal", "bc",
    "expr", "test", "true", "false", "pwd", "tree", "diff", "cmp", "md5sum",
    "sha256sum", "sha1sum", "xxd", "od", "hexdump", "strings", "readlink",
    "realpath", "basename", "dirname", "seq", "yes", "tput", "column", "jq",
    "yq", "xargs", "tr", "cut", "paste", "awk", "sed",
])

NETWORK_COMMANDS = frozenset([
    "curl", "wget", "ssh", "scp", "rsync", "ftp", "sftp", "nc", "ncat",
    "telnet", "ping", "traceroute", "dig", "nslookup", "host", "whois",
    "ifconfig", "ip", "netstat", "ss", "nmap",
])

PROCESS_COMMANDS = frozenset([
    "kill", "pkill", "killall", "ps", "top", "htop", "bg", "fg", "jobs",
    "nohup", "disown", "wait", "nice", "renice",
])

PACKAGE_COMMANDS = frozenset([
    "apt", "apt-get", "yum", "dnf", "pacman", "brew", "pip", "pip3", "npm",
    "yarn", "pnpm", "bun", "cargo", "gem", "go", "rustup", "snap", "flatpak",
])

SYSTEM_ADMIN_COMMANDS = frozenset([
    "sudo", "su", "chroot", "mount", "umount", "fdisk", "parted", "lsblk",
    "blkid", "systemctl", "service", "journalctl", "dmesg", "modprobe",
    "insmod", "rmmod", "iptables", "ufw", "firewall-cmd", "sysctl", "crontab",
    "at", "useradd", "userdel", "usermod", "groupadd", "groupdel", "passwd", "visudo",
])

SYSTEM_PATHS = ["/etc/", "/usr/", "/var/", "/boot/", "/sys/", "/proc/", "/dev/", "/sbin/", "/lib/", "/opt/"]


class CommandIntent(Enum):
    """Classification sémantique de l'intention d'une commande."""
    READ_ONLY = "read_only"
    WRITE = "write"
    DESTRUCTIVE = "destructive"
    NETWORK = "network"
    PROCESS_MANAGEMENT = "process_management"
    PACKAGE_MANAGEMENT = "package_management"
    SYSTEM_ADMIN = "system_admin"
    UNKNOWN = "unknown"


def validate_read_only(command: str, mode: PermissionMode) -> ValidationResult | ValidationBlock:
    """Valide qu'une commande est autorisée en mode lecture seule."""
    if mode != PermissionMode.READ_ONLY:
        return ValidationResult.ALLOW

    first = _extract_first_command(command)
    if first in WRITE_COMMANDS:
        return ValidationBlock(reason=f"Command '{first}' modifies the filesystem and is not allowed in read-only mode")
    if first in STATE_MODIFYING_COMMANDS:
        return ValidationBlock(reason=f"Command '{first}' modifies system state and is not allowed in read-only mode")
    if first == "sudo":
        inner = _extract_sudo_inner(command)
        if inner:
            result = validate_read_only(inner, mode)
            if not isinstance(result, ValidationResult):
                return result
    for redir in WRITE_REDIRECTIONS:
        if redir in command:
            return ValidationBlock(reason=f"Command contains write redirection '{redir}' which is not allowed in read-only mode")
    if first == "git":
        return _validate_git_read_only(command)
    return ValidationResult.ALLOW


def check_destructive(command: str) -> ValidationResult | ValidationWarn:
    """Avertit si une commande semble destructive."""
    for pattern, warning in DESTRUCTIVE_PATTERNS:
        if pattern in command:
            return ValidationWarn(message=f"Destructive command detected: {warning}")
    first = _extract_first_command(command)
    if first in ALWAYS_DESTRUCTIVE_COMMANDS:
        return ValidationWarn(message=f"Command '{first}' is inherently destructive and may cause data loss")
    if "rm " in command and "-r" in command and "-f" in command:
        return ValidationWarn(message="Recursive forced deletion detected -- verify the target path is correct")
    return ValidationResult.ALLOW


def validate_mode(command: str, mode: PermissionMode) -> ValidationResult | ValidationBlock | ValidationWarn:
    """Valide qu'une commande est cohérente avec le mode de permission."""
    if mode == PermissionMode.READ_ONLY:
        return validate_read_only(command, mode)
    if mode == PermissionMode.WORKSPACE_WRITE:
        if _command_targets_outside_workspace(command):
            return ValidationWarn(message="Command appears to target files outside the workspace -- requires elevated permission")
    return ValidationResult.ALLOW


def validate_sed(command: str, mode: PermissionMode) -> ValidationResult | ValidationBlock:
    """Valide les expressions sed."""
    first = _extract_first_command(command)
    if first != "sed":
        return ValidationResult.ALLOW
    if mode == PermissionMode.READ_ONLY and " -i" in command:
        return ValidationBlock(reason="sed -i (in-place editing) is not allowed in read-only mode")
    return ValidationResult.ALLOW


def validate_paths(command: str, workspace: Path) -> ValidationResult | ValidationWarn:
    """Valide les chemins dans une commande."""
    if "../" in command:
        ws_str = str(workspace)
        if ws_str not in command:
            return ValidationWarn(message="Command contains directory traversal pattern '../' -- verify the target path resolves within the workspace")
    if "~/" in command or "$HOME" in command:
        return ValidationWarn(message="Command references home directory -- verify it stays within the workspace scope")
    return ValidationResult.ALLOW


def classify_command(command: str) -> CommandIntent:
    """Classifie l'intention sémantique d'une commande bash."""
    first = _extract_first_command(command)
    if first in SEMANTIC_READ_ONLY_COMMANDS:
        if first == "sed" and " -i" in command:
            return CommandIntent.WRITE
        return CommandIntent.READ_ONLY
    if first in ALWAYS_DESTRUCTIVE_COMMANDS or first == "rm":
        return CommandIntent.DESTRUCTIVE
    if first in WRITE_COMMANDS:
        return CommandIntent.WRITE
    if first in NETWORK_COMMANDS:
        return CommandIntent.NETWORK
    if first in PROCESS_COMMANDS:
        return CommandIntent.PROCESS_MANAGEMENT
    if first in PACKAGE_COMMANDS:
        return CommandIntent.PACKAGE_MANAGEMENT
    if first in SYSTEM_ADMIN_COMMANDS:
        return CommandIntent.SYSTEM_ADMIN
    if first == "git":
        parts = command.split()
        sub = next((p for p in parts[1:] if not p.startswith("-")), None)
        if sub and sub in GIT_READ_ONLY_SUBCOMMANDS:
            return CommandIntent.READ_ONLY
        return CommandIntent.WRITE
    return CommandIntent.UNKNOWN


def validate_command(command: str, mode: PermissionMode, workspace: Path) -> ValidationResult | ValidationBlock | ValidationWarn:
    """Pipeline complet de validation d'une commande bash."""
    result = validate_mode(command, mode)
    if not isinstance(result, ValidationResult):
        return result
    result = validate_sed(command, mode)
    if not isinstance(result, ValidationResult):
        return result
    result = check_destructive(command)
    if not isinstance(result, ValidationResult):
        return result
    return validate_paths(command, workspace)


def _extract_first_command(command: str) -> str:
    """Extrait la première commande brute d'un pipeline."""
    remaining = command.strip()
    while remaining:
        next_part = remaining.lstrip()
        eq_pos = next_part.find("=")
        if eq_pos > 0:
            before_eq = next_part[:eq_pos]
            if before_eq and all(c.isalnum() or c == "_" for c in before_eq):
                after_eq = next_part[eq_pos + 1:]
                space = _find_end_of_value(after_eq)
                if space is not None:
                    remaining = after_eq[space:]
                    continue
                return ""
        break
    parts = remaining.split()
    return parts[0] if parts else ""


def _extract_sudo_inner(command: str) -> str:
    """Extrait la commande après sudo."""
    parts = command.split()
    try:
        idx = parts.index("sudo")
    except ValueError:
        return ""
    rest = parts[idx + 1:]
    for part in rest:
        if not part.startswith("-"):
            offset = command.find(part)
            return command[offset:]
    return ""


def _find_end_of_value(s: str) -> int | None:
    s = s.lstrip()
    if not s:
        return None
    if s[0] in ('"', "'"):
        quote = s[0]
        i = 1
        while i < len(s):
            if s[i] == quote and (i == 0 or s[i - 1] != "\\"):
                i += 1
                while i < len(s) and not s[i].isspace():
                    i += 1
                return i if i < len(s) else None
            i += 1
        return None
    for i, c in enumerate(s):
        if c.isspace():
            return i
    return None


def _validate_git_read_only(command: str) -> ValidationResult | ValidationBlock:
    parts = command.split()
    sub = next((p for p in parts[1:] if not p.startswith("-")), None)
    if sub is None:
        return ValidationResult.ALLOW
    if sub in GIT_READ_ONLY_SUBCOMMANDS:
        return ValidationResult.ALLOW
    return ValidationBlock(reason=f"Git subcommand '{sub}' modifies repository state and is not allowed in read-only mode")


def _command_targets_outside_workspace(command: str) -> bool:
    first = _extract_first_command(command)
    is_write = first in WRITE_COMMANDS or first in STATE_MODIFYING_COMMANDS
    if not is_write:
        return False
    return any(sp in command for sp in SYSTEM_PATHS)
