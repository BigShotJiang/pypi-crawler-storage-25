"""
Parseur et rendeur JSON minimal sans dépendance externe.

Traduit depuis json.rs -- fournit un arbre JSON (JsonValue)
avec parsing et rendu, utilisé par session.py et config.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union


class JsonError(Exception):
    """Erreur de parsing ou de rendu JSON."""
    pass


# -- Types JSON ----------------------------------------------------------------

@dataclass
class JsonNull:
    """Représente null."""
    def render(self) -> str:
        return "null"


@dataclass
class JsonBool:
    """Représente un booléen."""
    value: bool

    def render(self) -> str:
        return "true" if self.value else "false"


@dataclass
class JsonNumber:
    """Représente un entier (i64 en Rust)."""
    value: int

    def render(self) -> str:
        return str(self.value)


@dataclass
class JsonString:
    """Représente une chaîne."""
    value: str

    def render(self) -> str:
        return _render_string(self.value)


@dataclass
class JsonArray:
    """Représente un tableau JSON."""
    values: list[JsonValue] = field(default_factory=list)

    def render(self) -> str:
        rendered = ",".join(v.render() for v in self.values)
        return f"[{rendered}]"


@dataclass
class JsonObject:
    """Représente un objet JSON (clés triées via dict ordonné)."""
    entries: dict[str, JsonValue] = field(default_factory=dict)

    def render(self) -> str:
        rendered = ",".join(
            f"{_render_string(k)}:{v.render()}"
            for k, v in sorted(self.entries.items())
        )
        return f"{{{rendered}}}"


# Union de tous les types JSON
JsonValue = Union[JsonNull, JsonBool, JsonNumber, JsonString, JsonArray, JsonObject]


# -- Accesseurs pratiques ------------------------------------------------------

def as_object(value: JsonValue) -> dict[str, JsonValue] | None:
    """Retourne les entrées si c'est un objet, sinon None."""
    return value.entries if isinstance(value, JsonObject) else None


def as_array(value: JsonValue) -> list[JsonValue] | None:
    """Retourne les éléments si c'est un tableau, sinon None."""
    return value.values if isinstance(value, JsonArray) else None


def as_str(value: JsonValue) -> str | None:
    """Retourne la chaîne si c'est un JsonString, sinon None."""
    return value.value if isinstance(value, JsonString) else None


def as_bool(value: JsonValue) -> bool | None:
    """Retourne le booléen si c'est un JsonBool, sinon None."""
    return value.value if isinstance(value, JsonBool) else None


def as_i64(value: JsonValue) -> int | None:
    """Retourne l'entier si c'est un JsonNumber, sinon None."""
    return value.value if isinstance(value, JsonNumber) else None


# -- Rendu de chaîne ----------------------------------------------------------

def _render_string(value: str) -> str:
    """Échappe une chaîne pour le rendu JSON."""
    rendered = ['"']
    for ch in value:
        if ch == '"':
            rendered.append('\\"')
        elif ch == '\\':
            rendered.append('\\\\')
        elif ch == '\n':
            rendered.append('\\n')
        elif ch == '\r':
            rendered.append('\\r')
        elif ch == '\t':
            rendered.append('\\t')
        elif ch == '\x08':
            rendered.append('\\b')
        elif ch == '\x0c':
            rendered.append('\\f')
        elif ord(ch) < 0x20:
            rendered.append(f"\\u{ord(ch):04x}")
        else:
            rendered.append(ch)
    rendered.append('"')
    return "".join(rendered)


# -- Parseur -------------------------------------------------------------------

class _Parser:
    """Parseur JSON récursif descendant."""

    def __init__(self, source: str) -> None:
        self._chars = list(source)
        self._index = 0

    def parse_value(self) -> JsonValue:
        self._skip_whitespace()
        ch = self._peek()
        if ch is None:
            raise JsonError("unexpected end of input")
        if ch == 'n':
            return self._parse_literal("null", JsonNull())
        if ch == 't':
            return self._parse_literal("true", JsonBool(True))
        if ch == 'f':
            return self._parse_literal("false", JsonBool(False))
        if ch == '"':
            return JsonString(self._parse_string())
        if ch == '[':
            return self._parse_array()
        if ch == '{':
            return self._parse_object()
        if ch == '-' or ch.isdigit():
            return JsonNumber(self._parse_number())
        raise JsonError(f"unexpected character: {ch}")

    def _parse_literal(self, expected: str, value: JsonValue) -> JsonValue:
        for expected_char in expected:
            actual = self._next()
            if actual != expected_char:
                raise JsonError(f"invalid literal: expected {expected}")
        return value

    def _parse_string(self) -> str:
        self._expect('"')
        result: list[str] = []
        while True:
            ch = self._next()
            if ch is None:
                raise JsonError("unterminated string")
            if ch == '"':
                return "".join(result)
            if ch == '\\':
                result.append(self._parse_escape())
            else:
                result.append(ch)

    def _parse_escape(self) -> str:
        ch = self._next()
        if ch == '"':
            return '"'
        if ch == '\\':
            return '\\'
        if ch == '/':
            return '/'
        if ch == 'b':
            return '\x08'
        if ch == 'f':
            return '\x0c'
        if ch == 'n':
            return '\n'
        if ch == 'r':
            return '\r'
        if ch == 't':
            return '\t'
        if ch == 'u':
            return self._parse_unicode_escape()
        raise JsonError(f"invalid escape sequence: {ch}")

    def _parse_unicode_escape(self) -> str:
        value = 0
        for _ in range(4):
            ch = self._next()
            if ch is None:
                raise JsonError("unexpected end of input in unicode escape")
            digit = int(ch, 16) if ch and ch in "0123456789abcdefABCDEF" else None
            if digit is None:
                raise JsonError("invalid unicode escape")
            value = (value << 4) | digit
        return chr(value)

    def _parse_array(self) -> JsonArray:
        self._expect('[')
        values: list[JsonValue] = []
        while True:
            self._skip_whitespace()
            if self._try_consume(']'):
                break
            values.append(self.parse_value())
            self._skip_whitespace()
            if self._try_consume(']'):
                break
            self._expect(',')
        return JsonArray(values)

    def _parse_object(self) -> JsonObject:
        self._expect('{')
        entries: dict[str, JsonValue] = {}
        while True:
            self._skip_whitespace()
            if self._try_consume('}'):
                break
            key = self._parse_string()
            self._skip_whitespace()
            self._expect(':')
            value = self.parse_value()
            entries[key] = value
            self._skip_whitespace()
            if self._try_consume('}'):
                break
            self._expect(',')
        return JsonObject(entries)

    def _parse_number(self) -> int:
        chars: list[str] = []
        if self._try_consume('-'):
            chars.append('-')
        while True:
            ch = self._peek()
            if ch is not None and ch.isdigit():
                chars.append(ch)
                self._index += 1
            else:
                break
        raw = "".join(chars)
        if not raw or raw == "-":
            raise JsonError("invalid number")
        try:
            return int(raw)
        except ValueError:
            raise JsonError("number out of range")

    def _expect(self, expected: str) -> None:
        actual = self._next()
        if actual != expected:
            if actual is None:
                raise JsonError(f"expected '{expected}', found end of input")
            raise JsonError(f"expected '{expected}', found '{actual}'")

    def _try_consume(self, expected: str) -> bool:
        if self._peek() == expected:
            self._index += 1
            return True
        return False

    def _skip_whitespace(self) -> None:
        while self._peek() in (' ', '\n', '\r', '\t'):
            self._index += 1

    def _peek(self) -> str | None:
        if self._index < len(self._chars):
            return self._chars[self._index]
        return None

    def _next(self) -> str | None:
        ch = self._peek()
        if ch is not None:
            self._index += 1
        return ch

    def is_eof(self) -> bool:
        return self._index >= len(self._chars)


def parse_json(source: str) -> JsonValue:
    """Parse une chaîne JSON et retourne un JsonValue."""
    parser = _Parser(source)
    value = parser.parse_value()
    parser._skip_whitespace()
    if not parser.is_eof():
        raise JsonError("unexpected trailing content")
    return value
