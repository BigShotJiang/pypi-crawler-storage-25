"""
Gestion des sessions de conversation avec persistance JSONL.

Traduit depuis session.rs.
"""
from __future__ import annotations
import json as _json
import os
import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from .usage import TokenUsage

SESSION_VERSION = 1
ROTATE_AFTER_BYTES = 256 * 1024
MAX_ROTATED_FILES = 3
_session_counter = 0
_counter_lock = threading.Lock()

class MessageRole(Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"

@dataclass
class ContentBlock:
    """Bloc de contenu dans un message."""
    pass

@dataclass
class TextBlock(ContentBlock):
    text: str = ""

@dataclass
class ToolUseBlock(ContentBlock):
    id: str = ""
    name: str = ""
    input: str = ""

@dataclass
class ToolResultBlock(ContentBlock):
    tool_use_id: str = ""
    tool_name: str = ""
    output: str = ""
    is_error: bool = False

@dataclass
class ConversationMessage:
    role: MessageRole = MessageRole.USER
    blocks: list[ContentBlock] = field(default_factory=list)
    usage: TokenUsage | None = None

    @staticmethod
    def user_text(text: str) -> ConversationMessage:
        return ConversationMessage(role=MessageRole.USER, blocks=[TextBlock(text=text)])

    @staticmethod
    def assistant(blocks: list[ContentBlock]) -> ConversationMessage:
        return ConversationMessage(role=MessageRole.ASSISTANT, blocks=blocks)

    @staticmethod
    def assistant_with_usage(blocks: list[ContentBlock], usage: TokenUsage | None) -> ConversationMessage:
        return ConversationMessage(role=MessageRole.ASSISTANT, blocks=blocks, usage=usage)

    @staticmethod
    def tool_result(tool_use_id: str, tool_name: str, output: str, is_error: bool) -> ConversationMessage:
        return ConversationMessage(
            role=MessageRole.TOOL,
            blocks=[ToolResultBlock(tool_use_id=tool_use_id, tool_name=tool_name, output=output, is_error=is_error)],
        )

    def to_dict(self) -> dict:
        blocks = []
        for block in self.blocks:
            if isinstance(block, TextBlock):
                blocks.append({"type": "text", "text": block.text})
            elif isinstance(block, ToolUseBlock):
                blocks.append({"type": "tool_use", "id": block.id, "name": block.name, "input": block.input})
            elif isinstance(block, ToolResultBlock):
                blocks.append({"type": "tool_result", "tool_use_id": block.tool_use_id, "tool_name": block.tool_name, "output": block.output, "is_error": block.is_error})
        d = {"role": self.role.value, "blocks": blocks}
        if self.usage:
            d["usage"] = {"input_tokens": self.usage.input_tokens, "output_tokens": self.usage.output_tokens, "cache_creation_input_tokens": self.usage.cache_creation_input_tokens, "cache_read_input_tokens": self.usage.cache_read_input_tokens}
        return d

    @staticmethod
    def from_dict(data: dict) -> ConversationMessage:
        role = MessageRole(data["role"])
        blocks: list[ContentBlock] = []
        for b in data.get("blocks", []):
            t = b.get("type", "")
            if t == "text":
                blocks.append(TextBlock(text=b["text"]))
            elif t == "tool_use":
                blocks.append(ToolUseBlock(id=b["id"], name=b["name"], input=b["input"]))
            elif t == "tool_result":
                blocks.append(ToolResultBlock(tool_use_id=b["tool_use_id"], tool_name=b["tool_name"], output=b["output"], is_error=b["is_error"]))
        usage = None
        if "usage" in data:
            u = data["usage"]
            usage = TokenUsage(input_tokens=u["input_tokens"], output_tokens=u["output_tokens"], cache_creation_input_tokens=u["cache_creation_input_tokens"], cache_read_input_tokens=u["cache_read_input_tokens"])
        return ConversationMessage(role=role, blocks=blocks, usage=usage)

@dataclass
class SessionCompaction:
    count: int = 0
    removed_message_count: int = 0
    summary: str = ""

@dataclass
class SessionFork:
    parent_session_id: str = ""
    branch_name: str | None = None

class SessionError(Exception):
    pass

def _current_time_millis() -> int:
    return int(time.time() * 1000)

def _generate_session_id() -> str:
    global _session_counter
    with _counter_lock:
        _session_counter += 1
        counter = _session_counter
    return f"session-{_current_time_millis()}-{counter}"

@dataclass
class Session:
    version: int = SESSION_VERSION
    session_id: str = field(default_factory=_generate_session_id)
    created_at_ms: int = field(default_factory=_current_time_millis)
    updated_at_ms: int = field(default_factory=_current_time_millis)
    messages: list[ConversationMessage] = field(default_factory=list)
    compaction: SessionCompaction | None = None
    fork: SessionFork | None = None
    _persistence_path: Path | None = None

    def with_persistence_path(self, path: Path) -> Session:
        self._persistence_path = path
        return self

    def persistence_path(self) -> Path | None:
        return self._persistence_path

    def save_to_path(self, path: Path | str) -> None:
        path = Path(path)
        snapshot = self._render_jsonl_snapshot()
        _rotate_session_file_if_needed(path)
        _write_atomic(path, snapshot)
        _cleanup_rotated_logs(path)

    @staticmethod
    def load_from_path(path: Path | str) -> Session:
        path = Path(path)
        contents = path.read_text()
        try:
            data = _json.loads(contents)
            if isinstance(data, dict) and "messages" in data:
                return Session._from_json(data)
        except _json.JSONDecodeError:
            pass
        return Session._from_jsonl(contents)

    def push_message(self, message: ConversationMessage) -> None:
        self._touch()
        self.messages.append(message)
        if self._persistence_path:
            needs_bootstrap = not self._persistence_path.exists() or self._persistence_path.stat().st_size == 0
            if needs_bootstrap:
                self.save_to_path(self._persistence_path)
            else:
                with open(self._persistence_path, "a") as f:
                    record = {"type": "message", "message": message.to_dict()}
                    f.write(_json.dumps(record) + "\n")

    def push_user_text(self, text: str) -> None:
        self.push_message(ConversationMessage.user_text(text))

    def record_compaction(self, summary: str, removed_message_count: int) -> None:
        self._touch()
        count = (self.compaction.count + 1) if self.compaction else 1
        self.compaction = SessionCompaction(count=count, removed_message_count=removed_message_count, summary=summary)

    def fork_session(self, branch_name: str | None = None) -> Session:
        now = _current_time_millis()
        trimmed = branch_name.strip() if branch_name else None
        if trimmed == "":
            trimmed = None
        return Session(
            version=self.version, session_id=_generate_session_id(),
            created_at_ms=now, updated_at_ms=now,
            messages=list(self.messages), compaction=self.compaction,
            fork=SessionFork(parent_session_id=self.session_id, branch_name=trimmed),
        )

    def _touch(self) -> None:
        self.updated_at_ms = _current_time_millis()

    def _render_jsonl_snapshot(self) -> str:
        lines = [_json.dumps(self._meta_record())]
        if self.compaction:
            lines.append(_json.dumps({"type": "compaction", "count": self.compaction.count, "removed_message_count": self.compaction.removed_message_count, "summary": self.compaction.summary}))
        for msg in self.messages:
            lines.append(_json.dumps({"type": "message", "message": msg.to_dict()}))
        return "\n".join(lines) + "\n"

    def _meta_record(self) -> dict:
        d: dict = {"type": "session_meta", "version": self.version, "session_id": self.session_id, "created_at_ms": self.created_at_ms, "updated_at_ms": self.updated_at_ms}
        if self.fork:
            d["fork"] = {"parent_session_id": self.fork.parent_session_id}
            if self.fork.branch_name:
                d["fork"]["branch_name"] = self.fork.branch_name
        return d

    @staticmethod
    def _from_json(data: dict) -> Session:
        messages = [ConversationMessage.from_dict(m) for m in data.get("messages", [])]
        now = _current_time_millis()
        return Session(
            version=data.get("version", SESSION_VERSION),
            session_id=data.get("session_id", _generate_session_id()),
            created_at_ms=data.get("created_at_ms", now),
            updated_at_ms=data.get("updated_at_ms", now),
            messages=messages,
        )

    @staticmethod
    def _from_jsonl(contents: str) -> Session:
        version = SESSION_VERSION
        session_id = None
        created_at_ms = None
        updated_at_ms = None
        messages: list[ConversationMessage] = []
        compaction = None
        fork = None

        for line_number, raw_line in enumerate(contents.split("\n"), 1):
            line = raw_line.strip()
            if not line:
                continue
            try:
                record = _json.loads(line)
            except _json.JSONDecodeError:
                raise SessionError(f"invalid JSONL record at line {line_number}")
            record_type = record.get("type", "")
            if record_type == "session_meta":
                version = record.get("version", SESSION_VERSION)
                session_id = record.get("session_id")
                created_at_ms = record.get("created_at_ms")
                updated_at_ms = record.get("updated_at_ms")
                fork_data = record.get("fork")
                if fork_data:
                    fork = SessionFork(parent_session_id=fork_data.get("parent_session_id", ""), branch_name=fork_data.get("branch_name"))
            elif record_type == "message":
                messages.append(ConversationMessage.from_dict(record["message"]))
            elif record_type == "compaction":
                compaction = SessionCompaction(count=record.get("count", 0), removed_message_count=record.get("removed_message_count", 0), summary=record.get("summary", ""))

        now = _current_time_millis()
        return Session(
            version=version, session_id=session_id or _generate_session_id(),
            created_at_ms=created_at_ms or now, updated_at_ms=updated_at_ms or (created_at_ms or now),
            messages=messages, compaction=compaction, fork=fork,
        )


def _write_atomic(path: Path, contents: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(f".tmp-{_current_time_millis()}")
    tmp.write_text(contents)
    tmp.rename(path)


def _rotate_session_file_if_needed(path: Path) -> None:
    try:
        if path.stat().st_size < ROTATE_AFTER_BYTES:
            return
    except FileNotFoundError:
        return
    stem = path.stem
    rotated = path.with_name(f"{stem}.rot-{_current_time_millis()}.jsonl")
    path.rename(rotated)


def _cleanup_rotated_logs(path: Path) -> None:
    parent = path.parent
    if not parent.exists():
        return
    stem = path.stem
    prefix = f"{stem}.rot-"
    rotated = sorted(
        [p for p in parent.iterdir() if p.name.startswith(prefix) and p.suffix == ".jsonl"],
        key=lambda p: p.stat().st_mtime,
    )
    remove_count = max(0, len(rotated) - MAX_ROTATED_FILES)
    for stale in rotated[:remove_count]:
        stale.unlink()
