"""
Exécution de commandes bash avec support sandbox et timeout.

Traduit depuis bash.rs.
"""

from __future__ import annotations

import asyncio
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from .sandbox import (
    SandboxConfig, SandboxStatus, FilesystemIsolationMode,
    build_linux_sandbox_command, resolve_sandbox_status_for_request,
)

# Taille max de sortie avant troncature (16 KiB)
MAX_OUTPUT_BYTES = 16_384


@dataclass
class BashCommandInput:
    """Entrée pour l'exécution d'une commande bash."""
    command: str = ""
    timeout: int | None = None
    description: str | None = None
    run_in_background: bool | None = None
    dangerously_disable_sandbox: bool | None = None
    namespace_restrictions: bool | None = None
    isolate_network: bool | None = None
    filesystem_mode: FilesystemIsolationMode | None = None
    allowed_mounts: list[str] | None = None


@dataclass
class BashCommandOutput:
    """Sortie d'une commande bash."""
    stdout: str = ""
    stderr: str = ""
    raw_output_path: str | None = None
    interrupted: bool = False
    is_image: bool | None = None
    background_task_id: str | None = None
    backgrounded_by_user: bool | None = None
    assistant_auto_backgrounded: bool | None = None
    dangerously_disable_sandbox: bool | None = None
    return_code_interpretation: str | None = None
    no_output_expected: bool | None = None
    structured_content: list | None = None
    persisted_output_path: str | None = None
    persisted_output_size: int | None = None
    sandbox_status: SandboxStatus | None = None


def execute_bash(input: BashCommandInput) -> BashCommandOutput:
    """Exécute une commande bash de manière synchrone."""
    cwd = Path.cwd()
    sandbox_status = _sandbox_status_for_input(input, cwd)

    # Mode background
    if input.run_in_background:
        process = subprocess.Popen(
            ["sh", "-lc", input.command],
            cwd=str(cwd),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return BashCommandOutput(
            background_task_id=str(process.pid),
            backgrounded_by_user=False,
            assistant_auto_backgrounded=False,
            dangerously_disable_sandbox=input.dangerously_disable_sandbox,
            no_output_expected=True,
            sandbox_status=sandbox_status,
        )

    # Mode synchrone avec timeout
    try:
        timeout_secs = input.timeout / 1000.0 if input.timeout else None
        env = _build_env(cwd, sandbox_status)
        _prepare_sandbox_dirs(cwd)

        result = subprocess.run(
            ["sh", "-lc", input.command],
            cwd=str(cwd),
            capture_output=True,
            timeout=timeout_secs,
            env=env,
        )

        stdout = _truncate_output(result.stdout.decode("utf-8", errors="replace"))
        stderr = _truncate_output(result.stderr.decode("utf-8", errors="replace"))
        no_output = not stdout.strip() and not stderr.strip()
        return_code_interp = None
        if result.returncode != 0:
            return_code_interp = f"exit_code:{result.returncode}"

        return BashCommandOutput(
            stdout=stdout,
            stderr=stderr,
            interrupted=False,
            dangerously_disable_sandbox=input.dangerously_disable_sandbox,
            return_code_interpretation=return_code_interp,
            no_output_expected=no_output,
            sandbox_status=sandbox_status,
        )

    except subprocess.TimeoutExpired:
        timeout_ms = input.timeout or 0
        return BashCommandOutput(
            stderr=f"Command exceeded timeout of {timeout_ms} ms",
            interrupted=True,
            dangerously_disable_sandbox=input.dangerously_disable_sandbox,
            return_code_interpretation="timeout",
            no_output_expected=True,
            sandbox_status=sandbox_status,
        )


def _sandbox_status_for_input(input: BashCommandInput, cwd: Path) -> SandboxStatus:
    """Calcule le statut sandbox pour une commande."""
    config = SandboxConfig()
    request = config.resolve_request(
        enabled_override=not input.dangerously_disable_sandbox if input.dangerously_disable_sandbox is not None else None,
        namespace_override=input.namespace_restrictions,
        network_override=input.isolate_network,
        filesystem_mode_override=input.filesystem_mode,
        allowed_mounts_override=input.allowed_mounts,
    )
    return resolve_sandbox_status_for_request(request, cwd)


def _build_env(cwd: Path, sandbox_status: SandboxStatus) -> dict[str, str] | None:
    """Construit l'environnement pour la commande."""
    if sandbox_status.filesystem_active:
        env = dict(os.environ)
        env["HOME"] = str(cwd / ".sandbox-home")
        env["TMPDIR"] = str(cwd / ".sandbox-tmp")
        return env
    return None


def _prepare_sandbox_dirs(cwd: Path) -> None:
    """Crée les répertoires sandbox si nécessaire."""
    (cwd / ".sandbox-home").mkdir(exist_ok=True)
    (cwd / ".sandbox-tmp").mkdir(exist_ok=True)


def _truncate_output(s: str) -> str:
    """Tronque la sortie si elle dépasse MAX_OUTPUT_BYTES."""
    if len(s.encode("utf-8")) <= MAX_OUTPUT_BYTES:
        return s
    # Trouver la dernière frontière UTF-8 valide
    encoded = s.encode("utf-8")[:MAX_OUTPUT_BYTES]
    truncated = encoded.decode("utf-8", errors="ignore")
    return truncated + "\n\n[output truncated — exceeded 16384 bytes]"
