"""
Registres Team et Cron en mémoire.

Traduit depuis team_cron_registry.rs.
"""
from __future__ import annotations
import threading
import time
from dataclasses import dataclass, field
from enum import Enum

def _now_secs() -> int:
    return int(time.time())

class TeamStatus(Enum):
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    DELETED = "deleted"

@dataclass
class Team:
    team_id: str = ""
    name: str = ""
    task_ids: list[str] = field(default_factory=list)
    status: TeamStatus = TeamStatus.CREATED
    created_at: int = 0
    updated_at: int = 0

class TeamRegistry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._teams: dict[str, Team] = {}
        self._counter = 0

    def create(self, name: str, task_ids: list[str] | None = None) -> Team:
        with self._lock:
            self._counter += 1
            ts = _now_secs()
            team_id = f"team_{ts:08x}_{self._counter}"
            team = Team(team_id=team_id, name=name, task_ids=task_ids or [], created_at=ts, updated_at=ts)
            self._teams[team_id] = team
            return team

    def get(self, team_id: str) -> Team | None:
        with self._lock:
            return self._teams.get(team_id)

    def list(self) -> list[Team]:
        with self._lock:
            return list(self._teams.values())

    def delete(self, team_id: str) -> Team:
        with self._lock:
            team = self._teams.get(team_id)
            if not team:
                raise ValueError(f"team not found: {team_id}")
            team.status = TeamStatus.DELETED
            team.updated_at = _now_secs()
            return team

    def remove(self, team_id: str) -> Team | None:
        with self._lock:
            return self._teams.pop(team_id, None)

    def len(self) -> int:
        with self._lock:
            return len(self._teams)

    def is_empty(self) -> bool:
        return self.len() == 0

@dataclass
class CronEntry:
    cron_id: str = ""
    schedule: str = ""
    prompt: str = ""
    description: str | None = None
    enabled: bool = True
    created_at: int = 0
    updated_at: int = 0
    last_run_at: int | None = None
    run_count: int = 0

class CronRegistry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: dict[str, CronEntry] = {}
        self._counter = 0

    def create(self, schedule: str, prompt: str, description: str | None = None) -> CronEntry:
        with self._lock:
            self._counter += 1
            ts = _now_secs()
            cron_id = f"cron_{ts:08x}_{self._counter}"
            entry = CronEntry(cron_id=cron_id, schedule=schedule, prompt=prompt, description=description, created_at=ts, updated_at=ts)
            self._entries[cron_id] = entry
            return entry

    def get(self, cron_id: str) -> CronEntry | None:
        with self._lock:
            return self._entries.get(cron_id)

    def list(self, enabled_only: bool = False) -> list[CronEntry]:
        with self._lock:
            return [e for e in self._entries.values() if not enabled_only or e.enabled]

    def delete(self, cron_id: str) -> CronEntry:
        with self._lock:
            entry = self._entries.pop(cron_id, None)
            if not entry:
                raise ValueError(f"cron not found: {cron_id}")
            return entry

    def disable(self, cron_id: str) -> None:
        with self._lock:
            entry = self._entries.get(cron_id)
            if not entry:
                raise ValueError(f"cron not found: {cron_id}")
            entry.enabled = False
            entry.updated_at = _now_secs()

    def record_run(self, cron_id: str) -> None:
        with self._lock:
            entry = self._entries.get(cron_id)
            if not entry:
                raise ValueError(f"cron not found: {cron_id}")
            entry.last_run_at = _now_secs()
            entry.run_count += 1
            entry.updated_at = _now_secs()

    def len(self) -> int:
        with self._lock:
            return len(self._entries)

    def is_empty(self) -> bool:
        return self.len() == 0

