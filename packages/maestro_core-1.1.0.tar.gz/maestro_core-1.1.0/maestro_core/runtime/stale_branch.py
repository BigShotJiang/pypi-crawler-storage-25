"""
Détection et politique de branches obsolètes.

Traduit depuis stale_branch.rs.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


@dataclass
class BranchFreshness:
    """Résultat de la vérification de fraîcheur d'une branche."""
    pass

class BranchFresh(BranchFreshness):
    pass

@dataclass
class BranchStale(BranchFreshness):
    commits_behind: int = 0
    missing_fixes: list[str] = field(default_factory=list)

@dataclass
class BranchDiverged(BranchFreshness):
    ahead: int = 0
    behind: int = 0


class StaleBranchPolicy(Enum):
    AUTO_REBASE = "auto_rebase"
    AUTO_MERGE_FORWARD = "auto_merge_forward"
    WARN_ONLY = "warn_only"
    BLOCK = "block"


@dataclass
class StaleBranchEvent:
    pass

@dataclass
class BranchStaleAgainstMain(StaleBranchEvent):
    branch: str = ""
    commits_behind: int = 0
    missing_fixes: list[str] = field(default_factory=list)

@dataclass
class RebaseAttempted(StaleBranchEvent):
    branch: str = ""
    result: str = ""

@dataclass
class MergeForwardAttempted(StaleBranchEvent):
    branch: str = ""
    result: str = ""


@dataclass
class StaleBranchAction:
    pass

class StaleBranchNoop(StaleBranchAction):
    pass

@dataclass
class StaleBranchWarn(StaleBranchAction):
    message: str = ""

@dataclass
class StaleBranchBlock(StaleBranchAction):
    message: str = ""

class StaleBranchRebase(StaleBranchAction):
    pass

class StaleBranchMergeForward(StaleBranchAction):
    pass


def check_freshness(branch: str, main_ref: str, repo_path: Path | None = None) -> BranchFreshness:
    """Vérifie la fraîcheur d'une branche par rapport à main."""
    cwd = repo_path or Path(".")
    behind = _rev_list_count(main_ref, branch, cwd)
    ahead = _rev_list_count(branch, main_ref, cwd)
    if behind == 0:
        return BranchFresh()
    if ahead > 0:
        return BranchDiverged(ahead=ahead, behind=behind)
    missing_fixes = _missing_fix_subjects(main_ref, branch, cwd)
    return BranchStale(commits_behind=behind, missing_fixes=missing_fixes)


def apply_policy(freshness: BranchFreshness, policy: StaleBranchPolicy) -> StaleBranchAction:
    """Applique la politique sur le résultat de fraîcheur."""
    if isinstance(freshness, BranchFresh):
        return StaleBranchNoop()
    if isinstance(freshness, BranchStale):
        if policy == StaleBranchPolicy.WARN_ONLY:
            fixes = "; ".join(freshness.missing_fixes) if freshness.missing_fixes else "(none)"
            return StaleBranchWarn(message=f"Branch is {freshness.commits_behind} commit(s) behind main. Missing fixes: {fixes}")
        if policy == StaleBranchPolicy.BLOCK:
            return StaleBranchBlock(message=f"Branch is {freshness.commits_behind} commit(s) behind main and must be updated before proceeding.")
        if policy == StaleBranchPolicy.AUTO_REBASE:
            return StaleBranchRebase()
        return StaleBranchMergeForward()
    if isinstance(freshness, BranchDiverged):
        if policy == StaleBranchPolicy.WARN_ONLY:
            return StaleBranchWarn(message=f"Branch has diverged: {freshness.ahead} commit(s) ahead, {freshness.behind} commit(s) behind main.")
        if policy == StaleBranchPolicy.BLOCK:
            return StaleBranchBlock(message=f"Branch has diverged ({freshness.ahead} ahead, {freshness.behind} behind) and must be reconciled before proceeding.")
        if policy == StaleBranchPolicy.AUTO_REBASE:
            return StaleBranchRebase()
        return StaleBranchMergeForward()
    return StaleBranchNoop()


def _rev_list_count(a: str, b: str, repo_path: Path) -> int:
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", f"{b}..{a}"],
            cwd=str(repo_path), capture_output=True, text=True,
        )
        if result.returncode == 0:
            return int(result.stdout.strip())
    except (OSError, ValueError):
        pass
    return 0


def _missing_fix_subjects(a: str, b: str, repo_path: Path) -> list[str]:
    try:
        result = subprocess.run(
            ["git", "log", "--format=%s", f"{b}..{a}"],
            cwd=str(repo_path), capture_output=True, text=True,
        )
        if result.returncode == 0:
            return [line for line in result.stdout.strip().split("\n") if line]
    except OSError:
        pass
    return []
