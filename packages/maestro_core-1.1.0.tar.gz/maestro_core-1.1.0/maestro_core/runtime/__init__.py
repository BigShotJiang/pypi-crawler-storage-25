"""
maestro_core.runtime -- Runtime modules for Maestro.

Exports key classes from the runtime subsystem.
"""

# -- permissions --
from .permissions import (
    PermissionContext,
    PermissionMode,
    PermissionOutcome,
    PermissionOverride,
    PermissionPolicy,
    PermissionPromptDecision,
    PermissionPrompter,
    PermissionRequest,
)

# -- permission_enforcer --
from .permission_enforcer import (
    EnforcementDenied,
    EnforcementResult,
    PermissionEnforcer,
)

# -- hooks --
from .hooks import (
    HookAbortSignal,
    HookEvent,
    HookProgressEvent,
    HookProgressReporter,
    HookRunResult,
    HookRunner,
)

# -- compact --
from .compact import (
    compact_session,
    CompactionConfig,
    CompactionResult,
    estimate_session_tokens,
    format_compact_summary,
    get_compact_continuation_message,
    should_compact,
)

# -- conversation --
from .conversation import (
    ApiClient,
    ApiRequest,
    AssistantEvent,
    AutoCompactionEvent,
    ConversationRuntime,
    PromptCacheEvent,
    StaticToolExecutor,
    ToolError,
    ToolExecutor,
    TurnSummary,
)

# -- config --
from .config import (
    ConfigEntry,
    ConfigError,
    ConfigLoader,
    ConfigSource,
    RuntimeConfig,
    RuntimeFeatureConfig,
    RuntimeHookConfig,
    RuntimePermissionRuleConfig,
    RuntimePluginConfig,
)

# -- bash --
from .bash import (
    BashCommandInput,
    BashCommandOutput,
    execute_bash,
)

# -- bash_validation --
from .bash_validation import (
    check_destructive,
    classify_command,
    CommandIntent,
    validate_command,
    validate_mode,
    validate_paths,
    validate_read_only,
    validate_sed,
    ValidationBlock,
    ValidationResult,
    ValidationWarn,
)

# -- bootstrap --
from .bootstrap import BootstrapPhase, BootstrapPlan

# -- file_ops --
from .file_ops import (
    edit_file,
    EditFileOutput,
    glob_search,
    GlobSearchOutput,
    grep_search,
    GrepSearchInput,
    GrepSearchOutput,
    read_file,
    ReadFileOutput,
    StructuredPatchHunk,
    TextFilePayload,
    write_file,
    WriteFileOutput,
)

# -- json --
from .json import (
    as_bool,
    as_i64,
    as_object,
    as_str,
    JsonArray,
    JsonBool,
    JsonError,
    JsonNull,
    JsonNumber,
    JsonObject,
    JsonString,
    JsonValue,
    parse_json,
)

# -- session --
from .session import (
    ContentBlock,
    ConversationMessage,
    MessageRole,
    Session,
    SessionCompaction,
    SessionError,
    SessionFork,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
)

# -- usage --
from .usage import (
    format_usd,
    ModelPricing,
    pricing_for_model,
    TokenUsage,
    UsageCostEstimate,
    UsageTracker,
)

# -- sandbox --
from .sandbox import (
    ContainerEnvironment,
    FilesystemIsolationMode,
    LinuxSandboxCommand,
    SandboxConfig,
    SandboxDetectionInputs,
    SandboxRequest,
    SandboxStatus,
)
