"""
Chargement et fusion de la configuration runtime.

Traduit depuis config.rs -- découverte de fichiers settings,
merge profond, parsing des hooks/plugins/MCP/OAuth/permissions.
"""

from __future__ import annotations

import json as _json
import os
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from .json import JsonValue, JsonObject, JsonString, JsonNumber, JsonBool, JsonNull, JsonArray, parse_json, as_object, as_str, as_i64, as_bool
from .sandbox import SandboxConfig, FilesystemIsolationMode

CLAW_SETTINGS_SCHEMA_NAME = "SettingsSchema"


class ConfigSource(Enum):
    USER = "user"
    PROJECT = "project"
    LOCAL = "local"


class ResolvedPermissionMode(Enum):
    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"
    DANGER_FULL_ACCESS = "danger-full-access"


@dataclass
class ConfigEntry:
    source: ConfigSource = ConfigSource.USER
    path: Path = field(default_factory=Path)


@dataclass
class RuntimeHookConfig:
    _pre_tool_use: list[str] = field(default_factory=list)
    _post_tool_use: list[str] = field(default_factory=list)
    _post_tool_use_failure: list[str] = field(default_factory=list)

    def pre_tool_use(self) -> list[str]:
        return self._pre_tool_use

    def post_tool_use(self) -> list[str]:
        return self._post_tool_use

    def post_tool_use_failure(self) -> list[str]:
        return self._post_tool_use_failure

    def merged(self, other: RuntimeHookConfig) -> RuntimeHookConfig:
        m = RuntimeHookConfig(
            _pre_tool_use=list(self._pre_tool_use),
            _post_tool_use=list(self._post_tool_use),
            _post_tool_use_failure=list(self._post_tool_use_failure),
        )
        m.extend(other)
        return m

    def extend(self, other: RuntimeHookConfig) -> None:
        _extend_unique(self._pre_tool_use, other.pre_tool_use())
        _extend_unique(self._post_tool_use, other.post_tool_use())
        _extend_unique(self._post_tool_use_failure, other.post_tool_use_failure())


@dataclass
class RuntimePermissionRuleConfig:
    _allow: list[str] = field(default_factory=list)
    _deny: list[str] = field(default_factory=list)
    _ask: list[str] = field(default_factory=list)

    def allow(self) -> list[str]:
        return self._allow

    def deny(self) -> list[str]:
        return self._deny

    def ask(self) -> list[str]:
        return self._ask


@dataclass
class RuntimePluginConfig:
    enabled_plugins: dict[str, bool] = field(default_factory=dict)
    external_directories: list[str] = field(default_factory=list)
    install_root: str | None = None
    registry_path: str | None = None
    bundled_root: str | None = None

    def state_for(self, plugin_id: str, default_enabled: bool) -> bool:
        return self.enabled_plugins.get(plugin_id, default_enabled)

    def set_plugin_state(self, plugin_id: str, enabled: bool) -> None:
        self.enabled_plugins[plugin_id] = enabled


class McpTransport(Enum):
    STDIO = "stdio"
    SSE = "sse"
    HTTP = "http"
    WS = "ws"
    SDK = "sdk"
    MANAGED_PROXY = "managed_proxy"


@dataclass
class McpStdioServerConfig:
    command: str = ""
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    tool_call_timeout_ms: int | None = None


@dataclass
class McpRemoteServerConfig:
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    headers_helper: str | None = None
    oauth: McpOAuthConfig | None = None


@dataclass
class McpWebSocketServerConfig:
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    headers_helper: str | None = None


@dataclass
class McpSdkServerConfig:
    name: str = ""


@dataclass
class McpManagedProxyServerConfig:
    url: str = ""
    id: str = ""


@dataclass
class McpOAuthConfig:
    client_id: str | None = None
    callback_port: int | None = None
    auth_server_metadata_url: str | None = None
    xaa: bool | None = None


@dataclass
class OAuthConfig:
    client_id: str = ""
    authorize_url: str = ""
    token_url: str = ""
    callback_port: int | None = None
    manual_redirect_url: str | None = None
    scopes: list[str] = field(default_factory=list)


@dataclass
class McpServerConfig:
    """Configuration d'un serveur MCP (union des types de transport)."""
    transport_type: McpTransport = McpTransport.STDIO
    stdio: McpStdioServerConfig | None = None
    sse: McpRemoteServerConfig | None = None
    http: McpRemoteServerConfig | None = None
    ws: McpWebSocketServerConfig | None = None
    sdk: McpSdkServerConfig | None = None
    managed_proxy: McpManagedProxyServerConfig | None = None

    def transport(self) -> McpTransport:
        return self.transport_type


@dataclass
class ScopedMcpServerConfig:
    scope: ConfigSource = ConfigSource.USER
    config: McpServerConfig = field(default_factory=McpServerConfig)

    def transport(self) -> McpTransport:
        return self.config.transport()


@dataclass
class McpConfigCollection:
    servers: dict[str, ScopedMcpServerConfig] = field(default_factory=dict)

    def get(self, name: str) -> ScopedMcpServerConfig | None:
        return self.servers.get(name)


@dataclass
class RuntimeFeatureConfig:
    hooks: RuntimeHookConfig = field(default_factory=RuntimeHookConfig)
    plugins: RuntimePluginConfig = field(default_factory=RuntimePluginConfig)
    mcp: McpConfigCollection = field(default_factory=McpConfigCollection)
    oauth: OAuthConfig | None = None
    model: str | None = None
    permission_mode: ResolvedPermissionMode | None = None
    permission_rules: RuntimePermissionRuleConfig = field(default_factory=RuntimePermissionRuleConfig)
    sandbox: SandboxConfig = field(default_factory=SandboxConfig)

    def with_hooks(self, hooks: RuntimeHookConfig) -> RuntimeFeatureConfig:
        self.hooks = hooks
        return self

    def with_plugins(self, plugins: RuntimePluginConfig) -> RuntimeFeatureConfig:
        self.plugins = plugins
        return self


class ConfigError(Exception):
    pass


@dataclass
class RuntimeConfig:
    _merged: dict[str, object] = field(default_factory=dict)
    _loaded_entries: list[ConfigEntry] = field(default_factory=list)
    _feature_config: RuntimeFeatureConfig = field(default_factory=RuntimeFeatureConfig)

    @staticmethod
    def empty() -> RuntimeConfig:
        return RuntimeConfig()

    def merged(self) -> dict[str, object]:
        return self._merged

    def loaded_entries(self) -> list[ConfigEntry]:
        return self._loaded_entries

    def get(self, key: str) -> object | None:
        return self._merged.get(key)

    def feature_config(self) -> RuntimeFeatureConfig:
        return self._feature_config

    def mcp(self) -> McpConfigCollection:
        return self._feature_config.mcp

    def hooks(self) -> RuntimeHookConfig:
        return self._feature_config.hooks

    def plugins(self) -> RuntimePluginConfig:
        return self._feature_config.plugins

    def oauth(self) -> OAuthConfig | None:
        return self._feature_config.oauth

    def model(self) -> str | None:
        return self._feature_config.model

    def permission_mode(self) -> ResolvedPermissionMode | None:
        return self._feature_config.permission_mode

    def permission_rules(self) -> RuntimePermissionRuleConfig:
        return self._feature_config.permission_rules

    def sandbox(self) -> SandboxConfig:
        return self._feature_config.sandbox

    def as_json(self) -> JsonValue:
        # Simplifié : retourne un objet vide si pas de données
        return JsonObject(entries={})


def default_config_home() -> Path:
    claw_home = os.environ.get("CLAW_CONFIG_HOME")
    if claw_home:
        return Path(claw_home)
    home = os.environ.get("HOME")
    if home:
        return Path(home) / ".claw"
    return Path(".claw")


class ConfigLoader:
    """Chargeur de configuration avec découverte de fichiers."""

    def __init__(self, cwd: Path, config_home: Path) -> None:
        self._cwd = cwd
        self._config_home = config_home

    @staticmethod
    def default_for(cwd: Path) -> ConfigLoader:
        return ConfigLoader(cwd, default_config_home())

    def config_home(self) -> Path:
        return self._config_home

    def discover(self) -> list[ConfigEntry]:
        parent = self._config_home.parent if self._config_home.parent else Path(".")
        return [
            ConfigEntry(source=ConfigSource.USER, path=parent / ".claw.json"),
            ConfigEntry(source=ConfigSource.USER, path=self._config_home / "settings.json"),
            ConfigEntry(source=ConfigSource.PROJECT, path=self._cwd / ".claw.json"),
            ConfigEntry(source=ConfigSource.PROJECT, path=self._cwd / ".claw" / "settings.json"),
            ConfigEntry(source=ConfigSource.LOCAL, path=self._cwd / ".claw" / "settings.local.json"),
        ]

    def load(self) -> RuntimeConfig:
        """Charge et fusionne tous les fichiers de config."""
        merged: dict[str, object] = {}
        loaded_entries: list[ConfigEntry] = []

        for entry in self.discover():
            try:
                content = entry.path.read_text()
            except (FileNotFoundError, OSError):
                continue
            if not content.strip():
                loaded_entries.append(entry)
                continue
            try:
                parsed = _json.loads(content)
            except _json.JSONDecodeError:
                continue
            if not isinstance(parsed, dict):
                continue
            _deep_merge(merged, parsed)
            loaded_entries.append(entry)

        feature_config = RuntimeFeatureConfig()
        if "hooks" in merged and isinstance(merged["hooks"], dict):
            hooks_data = merged["hooks"]
            feature_config.hooks = RuntimeHookConfig(
                _pre_tool_use=hooks_data.get("PreToolUse", []),
                _post_tool_use=hooks_data.get("PostToolUse", []),
                _post_tool_use_failure=hooks_data.get("PostToolUseFailure", []),
            )
        if "model" in merged and isinstance(merged["model"], str):
            feature_config.model = merged["model"]

        return RuntimeConfig(
            _merged=merged,
            _loaded_entries=loaded_entries,
            _feature_config=feature_config,
        )


def _deep_merge(target: dict, source: dict) -> None:
    for key, value in source.items():
        if key in target and isinstance(target[key], dict) and isinstance(value, dict):
            _deep_merge(target[key], value)
        else:
            target[key] = value


def _extend_unique(target: list[str], source: list[str]) -> None:
    existing = set(target)
    for item in source:
        if item not in existing:
            target.append(item)
            existing.add(item)
