"""
Moteur de politiques pour orchestration de lanes.

Traduit depuis policy_engine.rs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from datetime import timedelta

_STALE_BRANCH_THRESHOLD = timedelta(hours=1)

GreenLevel = int

class LaneBlocker(Enum):
    NONE = "none"
    STARTUP = "startup"
    EXTERNAL = "external"

class ReviewStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

class DiffScope(Enum):
    FULL = "full"
    SCOPED = "scoped"

@dataclass
class LaneContext:
    lane_id: str = ""
    green_level: int = 0
    branch_freshness: timedelta = field(default_factory=timedelta)
    blocker: LaneBlocker = LaneBlocker.NONE
    review_status: ReviewStatus = ReviewStatus.PENDING
    diff_scope: DiffScope = DiffScope.FULL
    completed: bool = False

@dataclass
class PolicyCondition:
    pass

@dataclass
class ConditionAnd(PolicyCondition):
    conditions: list[PolicyCondition] = field(default_factory=list)

@dataclass
class ConditionOr(PolicyCondition):
    conditions: list[PolicyCondition] = field(default_factory=list)

@dataclass
class ConditionGreenAt(PolicyCondition):
    level: int = 0

class ConditionStaleBranch(PolicyCondition):
    pass

class ConditionStartupBlocked(PolicyCondition):
    pass

class ConditionLaneCompleted(PolicyCondition):
    pass

class ConditionReviewPassed(PolicyCondition):
    pass

class ConditionScopedDiff(PolicyCondition):
    pass

@dataclass
class ConditionTimedOut(PolicyCondition):
    duration: timedelta = field(default_factory=timedelta)

def _condition_matches(cond: PolicyCondition, ctx: LaneContext) -> bool:
    if isinstance(cond, ConditionAnd):
        return all(_condition_matches(c, ctx) for c in cond.conditions)
    if isinstance(cond, ConditionOr):
        return any(_condition_matches(c, ctx) for c in cond.conditions)
    if isinstance(cond, ConditionGreenAt):
        return ctx.green_level >= cond.level
    if isinstance(cond, ConditionStaleBranch):
        return ctx.branch_freshness >= _STALE_BRANCH_THRESHOLD
    if isinstance(cond, ConditionStartupBlocked):
        return ctx.blocker == LaneBlocker.STARTUP
    if isinstance(cond, ConditionLaneCompleted):
        return ctx.completed
    if isinstance(cond, ConditionReviewPassed):
        return ctx.review_status == ReviewStatus.APPROVED
    if isinstance(cond, ConditionScopedDiff):
        return ctx.diff_scope == DiffScope.SCOPED
    if isinstance(cond, ConditionTimedOut):
        return ctx.branch_freshness >= cond.duration
    return False

@dataclass
class PolicyAction:
    pass

class ActionMergeToDev(PolicyAction):
    pass

class ActionMergeForward(PolicyAction):
    pass

class ActionRecoverOnce(PolicyAction):
    pass

@dataclass
class ActionEscalate(PolicyAction):
    reason: str = ""

class ActionCloseoutLane(PolicyAction):
    pass

class ActionCleanupSession(PolicyAction):
    pass

@dataclass
class ActionNotify(PolicyAction):
    channel: str = ""

@dataclass
class ActionBlock(PolicyAction):
    reason: str = ""

@dataclass
class ActionChain(PolicyAction):
    actions: list[PolicyAction] = field(default_factory=list)

def _flatten_action(action: PolicyAction, result: list[PolicyAction]) -> None:
    if isinstance(action, ActionChain):
        for a in action.actions:
            _flatten_action(a, result)
    else:
        result.append(action)

@dataclass
class PolicyRule:
    name: str = ""
    condition: PolicyCondition = field(default_factory=PolicyCondition)
    action: PolicyAction = field(default_factory=PolicyAction)
    priority: int = 0

    def matches(self, context: LaneContext) -> bool:
        return _condition_matches(self.condition, context)

class PolicyEngine:
    def __init__(self, rules: list[PolicyRule]) -> None:
        self._rules = sorted(rules, key=lambda r: r.priority)

    def rules(self) -> list[PolicyRule]:
        return self._rules

    def evaluate(self, context: LaneContext) -> list[PolicyAction]:
        return evaluate(self, context)

def evaluate(engine: PolicyEngine, context: LaneContext) -> list[PolicyAction]:
    actions: list[PolicyAction] = []
    for rule in engine._rules:
        if rule.matches(context):
            _flatten_action(rule.action, actions)
    return actions
