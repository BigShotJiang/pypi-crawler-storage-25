"""
Contexte de session distante et proxy upstream.

Traduit depuis remote.rs.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_REMOTE_BASE_URL = "https://api.anthropic.com"
DEFAULT_SESSION_TOKEN_PATH = "/run/ccr/session_token"
DEFAULT_SYSTEM_CA_BUNDLE = "/etc/ssl/certs/ca-certificates.crt"

UPSTREAM_PROXY_ENV_KEYS = [
    "HTTPS_PROXY", "https_proxy", "NO_PROXY", "no_proxy",
    "SSL_CERT_FILE", "NODE_EXTRA_CA_CERTS", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE",
]

NO_PROXY_HOSTS = [
    "localhost", "127.0.0.1", "::1", "169.254.0.0/16", "10.0.0.0/8",
    "172.16.0.0/12", "192.168.0.0/16", "anthropic.com", ".anthropic.com",
    "*.anthropic.com", "github.com", "api.github.com", "*.github.com",
    "*.githubusercontent.com", "registry.npmjs.org", "index.crates.io",
]


@dataclass
class RemoteSessionContext:
    enabled: bool = False
    session_id: str | None = None
    base_url: str = DEFAULT_REMOTE_BASE_URL

    @staticmethod
    def from_env() -> RemoteSessionContext:
        return RemoteSessionContext.from_env_map(dict(os.environ))

    @staticmethod
    def from_env_map(env_map: dict[str, str]) -> RemoteSessionContext:
        return RemoteSessionContext(
            enabled=_env_truthy(env_map.get("CLAUDE_CODE_REMOTE")),
            session_id=env_map.get("CLAUDE_CODE_REMOTE_SESSION_ID") or None,
            base_url=env_map.get("ANTHROPIC_BASE_URL") or DEFAULT_REMOTE_BASE_URL,
        )


@dataclass
class UpstreamProxyBootstrap:
    remote: RemoteSessionContext = field(default_factory=RemoteSessionContext)
    upstream_proxy_enabled: bool = False
    token_path: Path = field(default_factory=lambda: Path(DEFAULT_SESSION_TOKEN_PATH))
    ca_bundle_path: Path = field(default_factory=lambda: Path.home() / ".ccr" / "ca-bundle.crt")
    system_ca_path: Path = field(default_factory=lambda: Path(DEFAULT_SYSTEM_CA_BUNDLE))
    token: str | None = None

    @staticmethod
    def from_env() -> UpstreamProxyBootstrap:
        return UpstreamProxyBootstrap.from_env_map(dict(os.environ))

    @staticmethod
    def from_env_map(env_map: dict[str, str]) -> UpstreamProxyBootstrap:
        remote = RemoteSessionContext.from_env_map(env_map)
        token_path = Path(env_map.get("CCR_SESSION_TOKEN_PATH") or DEFAULT_SESSION_TOKEN_PATH)
        system_ca = Path(env_map.get("CCR_SYSTEM_CA_BUNDLE") or DEFAULT_SYSTEM_CA_BUNDLE)
        ca_bundle = Path(env_map.get("CCR_CA_BUNDLE_PATH", "")) if env_map.get("CCR_CA_BUNDLE_PATH") else Path.home() / ".ccr" / "ca-bundle.crt"
        token = read_token(token_path)
        return UpstreamProxyBootstrap(
            remote=remote,
            upstream_proxy_enabled=_env_truthy(env_map.get("CCR_UPSTREAM_PROXY_ENABLED")),
            token_path=token_path, ca_bundle_path=ca_bundle,
            system_ca_path=system_ca, token=token,
        )

    def should_enable(self) -> bool:
        return self.remote.enabled and self.upstream_proxy_enabled and self.remote.session_id is not None and self.token is not None

    def ws_url(self) -> str:
        return upstream_proxy_ws_url(self.remote.base_url)

    def state_for_port(self, port: int) -> UpstreamProxyState:
        if not self.should_enable():
            return UpstreamProxyState.disabled()
        return UpstreamProxyState(
            enabled=True, proxy_url=f"http://127.0.0.1:{port}",
            ca_bundle_path=self.ca_bundle_path, no_proxy=no_proxy_list(),
        )


@dataclass
class UpstreamProxyState:
    enabled: bool = False
    proxy_url: str | None = None
    ca_bundle_path: Path | None = None
    no_proxy: str = ""

    @staticmethod
    def disabled() -> UpstreamProxyState:
        return UpstreamProxyState(no_proxy=no_proxy_list())

    def subprocess_env(self) -> dict[str, str]:
        if not self.enabled or not self.proxy_url or not self.ca_bundle_path:
            return {}
        ca = str(self.ca_bundle_path)
        return {
            "HTTPS_PROXY": self.proxy_url, "https_proxy": self.proxy_url,
            "NO_PROXY": self.no_proxy, "no_proxy": self.no_proxy,
            "SSL_CERT_FILE": ca, "NODE_EXTRA_CA_CERTS": ca,
            "REQUESTS_CA_BUNDLE": ca, "CURL_CA_BUNDLE": ca,
        }


def read_token(path: Path) -> str | None:
    try:
        content = path.read_text().strip()
        return content if content else None
    except (FileNotFoundError, OSError):
        return None


def upstream_proxy_ws_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.startswith("https://"):
        ws_base = "wss://" + base[len("https://"):]
    elif base.startswith("http://"):
        ws_base = "ws://" + base[len("http://"):]
    else:
        ws_base = "wss://" + base
    return f"{ws_base}/v1/code/upstreamproxy/ws"


def no_proxy_list() -> str:
    hosts = list(NO_PROXY_HOSTS) + ["pypi.org", "files.pythonhosted.org", "proxy.golang.org"]
    return ",".join(hosts)


def inherited_upstream_proxy_env(env_map: dict[str, str]) -> dict[str, str]:
    if "HTTPS_PROXY" not in env_map or "SSL_CERT_FILE" not in env_map:
        return {}
    return {k: env_map[k] for k in UPSTREAM_PROXY_ENV_KEYS if k in env_map}


def _env_truthy(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in ("1", "true", "yes", "on")
