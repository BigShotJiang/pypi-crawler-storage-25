"""
Compaction de session (résumé + suppression des anciens messages).

Traduit depuis compact.rs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from .session import Session, ConversationMessage, ContentBlock, TextBlock, ToolUseBlock, ToolResultBlock, MessageRole, SessionCompaction
import re

_COMPACT_CONTINUATION_PREAMBLE = "This session is being continued from a previous conversation that ran out of context. The summary below covers the earlier portion of the conversation.\n\n"
_COMPACT_RECENT_MESSAGES_NOTE = "Recent messages are preserved verbatim."
_COMPACT_DIRECT_RESUME_INSTRUCTION = "Continue the conversation from where it left off without asking the user any further questions. Resume directly -- do not acknowledge the summary, do not recap what was happening, and do not preface with continuation text."

@dataclass
class CompactionConfig:
    preserve_recent_messages: int = 4
    max_estimated_tokens: int = 10_000

@dataclass
class CompactionResult:
    summary: str = ""
    formatted_summary: str = ""
    compacted_session: Session = field(default_factory=Session)
    removed_message_count: int = 0

def estimate_session_tokens(session: Session) -> int:
    return sum(_estimate_message_tokens(m) for m in session.messages)

def should_compact(session: Session, config: CompactionConfig) -> bool:
    start = _compacted_summary_prefix_len(session)
    compactable = session.messages[start:]
    return (len(compactable) > config.preserve_recent_messages and sum(_estimate_message_tokens(m) for m in compactable) >= config.max_estimated_tokens)

def format_compact_summary(summary: str) -> str:
    without_analysis = _strip_tag_block(summary, "analysis")
    content = _extract_tag_block(without_analysis, "summary")
    if content is not None:
        formatted = without_analysis.replace(f"<summary>{content}</summary>", f"Summary:\n{content.strip()}")
    else:
        formatted = without_analysis
    return _collapse_blank_lines(formatted).strip()

def get_compact_continuation_message(summary: str, suppress_follow_up: bool, recent_preserved: bool) -> str:
    base = f"{_COMPACT_CONTINUATION_PREAMBLE}{format_compact_summary(summary)}"
    if recent_preserved:
        base += f"\n\n{_COMPACT_RECENT_MESSAGES_NOTE}"
    if suppress_follow_up:
        base += f"\n{_COMPACT_DIRECT_RESUME_INSTRUCTION}"
    return base

def compact_session(session: Session, config: CompactionConfig) -> CompactionResult:
    if not should_compact(session, config):
        return CompactionResult(compacted_session=session)
    existing = _extract_existing_compacted_summary(session.messages[0]) if session.messages else None
    prefix_len = 1 if existing else 0
    keep_from = max(0, len(session.messages) - config.preserve_recent_messages)
    removed = session.messages[prefix_len:keep_from]
    preserved = list(session.messages[keep_from:])
    summary = _summarize_messages(removed)
    if existing:
        summary = _merge_compact_summaries(existing, summary)
    formatted = format_compact_summary(summary)
    continuation = get_compact_continuation_message(summary, True, bool(preserved))
    compacted_messages = [ConversationMessage(role=MessageRole.SYSTEM, blocks=[TextBlock(text=continuation)])] + preserved
    compacted = Session(version=session.version, session_id=session.session_id, created_at_ms=session.created_at_ms, updated_at_ms=session.updated_at_ms, messages=compacted_messages, compaction=session.compaction, fork=session.fork)
    compacted.record_compaction(summary, len(removed))
    return CompactionResult(summary=summary, formatted_summary=formatted, compacted_session=compacted, removed_message_count=len(removed))

def _compacted_summary_prefix_len(session: Session) -> int:
    if session.messages and _extract_existing_compacted_summary(session.messages[0]) is not None:
        return 1
    return 0

def _summarize_messages(messages: list[ConversationMessage]) -> str:
    user_count = sum(1 for m in messages if m.role == MessageRole.USER)
    assistant_count = sum(1 for m in messages if m.role == MessageRole.ASSISTANT)
    tool_count = sum(1 for m in messages if m.role == MessageRole.TOOL)
    lines = ["<summary>", "Conversation summary:", f"- Scope: {len(messages)} earlier messages compacted (user={user_count}, assistant={assistant_count}, tool={tool_count})."]
    tool_names = sorted(set(_block_tool_name(b) for m in messages for b in m.blocks if _block_tool_name(b)))
    if tool_names:
        lines.append(f"- Tools mentioned: {', '.join(tool_names)}.")
    lines.append("- Key timeline:")
    for m in messages:
        role = m.role.value
        content = " | ".join(_summarize_block(b) for b in m.blocks)
        lines.append(f"  - {role}: {content}")
    lines.append("</summary>")
    return "\n".join(lines)

def _merge_compact_summaries(existing: str, new: str) -> str:
    lines = ["<summary>", "Conversation summary:", "- Previously compacted context:", f"  {existing}", "- Newly compacted context:", f"  {format_compact_summary(new)}", "</summary>"]
    return "\n".join(lines)

def _block_tool_name(block: ContentBlock) -> str | None:
    if isinstance(block, ToolUseBlock):
        return block.name
    if isinstance(block, ToolResultBlock):
        return block.tool_name
    return None

def _summarize_block(block: ContentBlock) -> str:
    if isinstance(block, TextBlock):
        return _truncate_summary(block.text, 160)
    if isinstance(block, ToolUseBlock):
        return _truncate_summary(f"tool_use {block.name}({block.input})", 160)
    if isinstance(block, ToolResultBlock):
        err = "error " if block.is_error else ""
        return _truncate_summary(f"tool_result {block.tool_name}: {err}{block.output}", 160)
    return ""

def _truncate_summary(content: str, max_chars: int) -> str:
    if len(content) <= max_chars:
        return content
    return content[:max_chars] + "..."

def _estimate_message_tokens(message: ConversationMessage) -> int:
    total = 0
    for b in message.blocks:
        if isinstance(b, TextBlock):
            total += len(b.text) // 4 + 1
        elif isinstance(b, ToolUseBlock):
            total += (len(b.name) + len(b.input)) // 4 + 1
        elif isinstance(b, ToolResultBlock):
            total += (len(b.tool_name) + len(b.output)) // 4 + 1
    return total

def _extract_tag_block(content: str, tag: str) -> str | None:
    start = f"<{tag}>"
    end = f"</{tag}>"
    si = content.find(start)
    if si < 0:
        return None
    si += len(start)
    ei = content.find(end, si)
    if ei < 0:
        return None
    return content[si:ei]

def _strip_tag_block(content: str, tag: str) -> str:
    start = f"<{tag}>"
    end = f"</{tag}>"
    si = content.find(start)
    ei = content.find(end)
    if si >= 0 and ei >= 0:
        return content[:si] + content[ei + len(end):]
    return content

def _collapse_blank_lines(content: str) -> str:
    result: list[str] = []
    last_blank = False
    for line in content.split("\n"):
        is_blank = not line.strip()
        if is_blank and last_blank:
            continue
        result.append(line)
        last_blank = is_blank
    return "\n".join(result)

def _extract_existing_compacted_summary(message: ConversationMessage) -> str | None:
    if message.role != MessageRole.SYSTEM:
        return None
    for block in message.blocks:
        if isinstance(block, TextBlock) and block.text.startswith(_COMPACT_CONTINUATION_PREAMBLE):
            text = block.text[len(_COMPACT_CONTINUATION_PREAMBLE):]
            for sep in [f"\n\n{_COMPACT_RECENT_MESSAGES_NOTE}", f"\n{_COMPACT_DIRECT_RESUME_INSTRUCTION}"]:
                idx = text.find(sep)
                if idx >= 0:
                    text = text[:idx]
            return text.strip()
    return None
