"""
Compression de résumés de session.

Traduit depuis summary_compression.rs.
"""

from __future__ import annotations

from dataclasses import dataclass, field


_DEFAULT_MAX_CHARS = 1200
_DEFAULT_MAX_LINES = 24
_DEFAULT_MAX_LINE_CHARS = 160


@dataclass
class SummaryCompressionBudget:
    """Budget de compression."""
    max_chars: int = _DEFAULT_MAX_CHARS
    max_lines: int = _DEFAULT_MAX_LINES
    max_line_chars: int = _DEFAULT_MAX_LINE_CHARS


@dataclass
class SummaryCompressionResult:
    """Résultat de la compression."""
    summary: str = ""
    original_chars: int = 0
    compressed_chars: int = 0
    original_lines: int = 0
    compressed_lines: int = 0
    removed_duplicate_lines: int = 0
    omitted_lines: int = 0
    truncated: bool = False


def compress_summary(summary: str, budget: SummaryCompressionBudget | None = None) -> SummaryCompressionResult:
    """Compresse un résumé selon le budget donné."""
    if budget is None:
        budget = SummaryCompressionBudget()

    original_chars = len(summary)
    original_lines = summary.count("\n") + (1 if summary else 0)

    normalized = _normalize_lines(summary, budget.max_line_chars)
    if not normalized.lines or budget.max_chars == 0 or budget.max_lines == 0:
        return SummaryCompressionResult(
            summary="", original_chars=original_chars, original_lines=original_lines,
            removed_duplicate_lines=normalized.removed_duplicate_lines,
            omitted_lines=len(normalized.lines), truncated=original_chars > 0,
        )

    selected = _select_line_indexes(normalized.lines, budget)
    compressed_lines = [normalized.lines[i] for i in selected]
    if not compressed_lines:
        compressed_lines.append(_truncate_line(normalized.lines[0], budget.max_chars))
    omitted = len(normalized.lines) - len(compressed_lines)
    if omitted > 0:
        notice = f"- ... {omitted} additional line(s) omitted."
        candidate_chars = sum(len(l) for l in compressed_lines) + len(compressed_lines) + len(notice)
        if len(compressed_lines) + 1 <= budget.max_lines and candidate_chars <= budget.max_chars:
            compressed_lines.append(notice)

    compressed = "\n".join(compressed_lines)
    return SummaryCompressionResult(
        summary=compressed, original_chars=original_chars,
        compressed_chars=len(compressed), original_lines=original_lines,
        compressed_lines=len(compressed_lines),
        removed_duplicate_lines=normalized.removed_duplicate_lines,
        omitted_lines=omitted, truncated=compressed != summary.strip(),
    )


def compress_summary_text(summary: str) -> str:
    """Compresse un résumé et retourne le texte."""
    return compress_summary(summary).summary


@dataclass
class _NormalizedSummary:
    lines: list[str] = field(default_factory=list)
    removed_duplicate_lines: int = 0


def _normalize_lines(summary: str, max_line_chars: int) -> _NormalizedSummary:
    seen: set[str] = set()
    lines: list[str] = []
    removed = 0
    for raw_line in summary.split("\n"):
        normalized = " ".join(raw_line.split())
        if not normalized:
            continue
        truncated = _truncate_line(normalized, max_line_chars)
        key = truncated.lower()
        if key in seen:
            removed += 1
            continue
        seen.add(key)
        lines.append(truncated)
    return _NormalizedSummary(lines=lines, removed_duplicate_lines=removed)


def _select_line_indexes(lines: list[str], budget: SummaryCompressionBudget) -> list[int]:
    selected: set[int] = set()
    for priority in range(4):
        for i, line in enumerate(lines):
            if i in selected or _line_priority(line) != priority:
                continue
            candidate = [lines[j] for j in sorted(selected)] + [line]
            if len(candidate) > budget.max_lines:
                continue
            total = sum(len(l) for l in candidate) + len(candidate) - 1
            if total > budget.max_chars:
                continue
            selected.add(i)
    return sorted(selected)


def _line_priority(line: str) -> int:
    core_prefixes = [
        "- Scope:", "- Current work:", "- Pending work:", "- Key files referenced:",
        "- Tools mentioned:", "- Recent user requests:", "- Previously compacted context:",
        "- Newly compacted context:",
    ]
    if line in ("Summary:", "Conversation summary:") or any(line.startswith(p) for p in core_prefixes):
        return 0
    if line.endswith(":"):
        return 1
    if line.startswith("- ") or line.startswith("  - "):
        return 2
    return 3


def _truncate_line(line: str, max_chars: int) -> str:
    if max_chars == 0 or len(line) <= max_chars:
        return line
    if max_chars == 1:
        return "..."
    return line[:max_chars - 1] + "..."
