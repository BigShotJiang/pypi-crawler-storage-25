"""
Utilitaires MCP : normalisation de noms, signatures, hash de config.

Traduit depuis mcp.rs.
"""
from __future__ import annotations

_CLAUDEAI_SERVER_PREFIX = "claude.ai "
_CCR_PROXY_PATH_MARKERS = ["/v2/session_ingress/shttp/mcp/", "/v2/ccr-sessions/"]

def normalize_name_for_mcp(name: str) -> str:
    normalized = "".join(ch if ch.isalnum() or ch in ("_", "-") else "_" for ch in name)
    if name.startswith(_CLAUDEAI_SERVER_PREFIX):
        normalized = _collapse_underscores(normalized).strip("_")
    return normalized

def mcp_tool_prefix(server_name: str) -> str:
    return f"mcp__{normalize_name_for_mcp(server_name)}__"

def mcp_tool_name(server_name: str, tool_name: str) -> str:
    return f"{mcp_tool_prefix(server_name)}{normalize_name_for_mcp(tool_name)}"

def unwrap_ccr_proxy_url(url: str) -> str:
    if not any(marker in url for marker in _CCR_PROXY_PATH_MARKERS):
        return url
    q = url.find("?")
    if q < 0:
        return url
    query = url[q + 1:]
    for pair in query.split("&"):
        parts = pair.split("=", 1)
        if len(parts) == 2 and parts[0] == "mcp_url":
            return _percent_decode(parts[1])
    return url

def mcp_server_signature(config) -> str | None:
    from .config import McpTransport
    t = config.transport_type
    if t == McpTransport.STDIO and config.stdio:
        cmd = [config.stdio.command] + config.stdio.args
        joined = "|".join(cmd)
        return f"stdio:[{joined}]"
    if t in (McpTransport.SSE, McpTransport.HTTP) and (config.sse or config.http):
        remote = config.sse or config.http
        return f"url:{unwrap_ccr_proxy_url(remote.url)}"
    if t == McpTransport.WS and config.ws:
        return f"url:{unwrap_ccr_proxy_url(config.ws.url)}"
    if t == McpTransport.MANAGED_PROXY and config.managed_proxy:
        return f"url:{unwrap_ccr_proxy_url(config.managed_proxy.url)}"
    return None

def scoped_mcp_config_hash(config) -> str:
    return _stable_hex_hash(str(config))

def _collapse_underscores(value: str) -> str:
    result: list[str] = []
    last_was = False
    for ch in value:
        if ch == "_":
            if not last_was:
                result.append(ch)
            last_was = True
        else:
            result.append(ch)
            last_was = False
    return "".join(result)

def _percent_decode(value: str) -> str:
    result: list[int] = []
    i = 0
    b = value.encode("ascii", errors="replace")
    while i < len(b):
        if b[i:i+1] == b"%" and i + 2 < len(b):
            try:
                result.append(int(value[i+1:i+3], 16))
                i += 3
                continue
            except ValueError:
                pass
        if b[i:i+1] == b"+":
            result.append(32)
        else:
            result.append(b[i])
        i += 1
    return bytes(result).decode("utf-8", errors="replace")

def _stable_hex_hash(value: str) -> str:
    h = 0xcbf29ce484222325
    for byte in value.encode("utf-8"):
        h ^= byte
        h = (h * 0x00000100000001b3) & 0xffffffffffffffff
    return f"{h:016x}"
