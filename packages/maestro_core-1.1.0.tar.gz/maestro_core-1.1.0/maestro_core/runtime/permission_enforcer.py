"""
Couche d'enforcement des permissions pour l'exécution des outils.

Traduit depuis permission_enforcer.rs.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .permissions import PermissionMode, PermissionOutcome, PermissionPolicy


class EnforcementResult(Enum):
    """Résultat de l'enforcement."""
    ALLOWED = "allowed"


@dataclass
class EnforcementDenied:
    """Résultat d'un refus d'enforcement."""
    tool: str
    active_mode: str
    required_mode: str
    reason: str


class PermissionEnforcer:
    """Applique la politique de permissions avant l'exécution des outils."""

    def __init__(self, policy: PermissionPolicy) -> None:
        self._policy = policy

    def check(self, tool_name: str, input_str: str) -> EnforcementResult | EnforcementDenied:
        """Vérifie si un outil peut être exécuté."""
        # En mode Prompt, on délègue au flux interactif
        if self._policy.active_mode() == PermissionMode.PROMPT:
            return EnforcementResult.ALLOWED

        outcome = self._policy.authorize(tool_name, input_str, None)
        if outcome.allowed:
            return EnforcementResult.ALLOWED

        active_mode = self._policy.active_mode()
        required_mode = self._policy.required_mode_for(tool_name)
        return EnforcementDenied(
            tool=tool_name,
            active_mode=active_mode.as_str(),
            required_mode=required_mode.as_str(),
            reason=outcome.reason,
        )

    def is_allowed(self, tool_name: str, input_str: str) -> bool:
        result = self.check(tool_name, input_str)
        return result == EnforcementResult.ALLOWED

    def active_mode(self) -> PermissionMode:
        return self._policy.active_mode()

    def check_file_write(self, path: str, workspace_root: str) -> EnforcementResult | EnforcementDenied:
        """Vérifie si une écriture de fichier est autorisée."""
        mode = self._policy.active_mode()

        if mode == PermissionMode.READ_ONLY:
            return EnforcementDenied(
                tool="write_file",
                active_mode=mode.as_str(),
                required_mode=PermissionMode.WORKSPACE_WRITE.as_str(),
                reason=f"file writes are not allowed in '{mode.as_str()}' mode",
            )
        if mode == PermissionMode.WORKSPACE_WRITE:
            if _is_within_workspace(path, workspace_root):
                return EnforcementResult.ALLOWED
            return EnforcementDenied(
                tool="write_file",
                active_mode=mode.as_str(),
                required_mode=PermissionMode.DANGER_FULL_ACCESS.as_str(),
                reason=f"path '{path}' is outside workspace root '{workspace_root}'",
            )
        if mode in (PermissionMode.ALLOW, PermissionMode.DANGER_FULL_ACCESS):
            return EnforcementResult.ALLOWED
        # Mode Prompt
        return EnforcementDenied(
            tool="write_file",
            active_mode=mode.as_str(),
            required_mode=PermissionMode.WORKSPACE_WRITE.as_str(),
            reason="file write requires confirmation in prompt mode",
        )

    def check_bash(self, command: str) -> EnforcementResult | EnforcementDenied:
        """Vérifie si une commande bash est autorisée."""
        mode = self._policy.active_mode()

        if mode == PermissionMode.READ_ONLY:
            if _is_read_only_command(command):
                return EnforcementResult.ALLOWED
            return EnforcementDenied(
                tool="bash",
                active_mode=mode.as_str(),
                required_mode=PermissionMode.WORKSPACE_WRITE.as_str(),
                reason=f"command may modify state; not allowed in '{mode.as_str()}' mode",
            )
        if mode == PermissionMode.PROMPT:
            return EnforcementDenied(
                tool="bash",
                active_mode=mode.as_str(),
                required_mode=PermissionMode.DANGER_FULL_ACCESS.as_str(),
                reason="bash requires confirmation in prompt mode",
            )
        return EnforcementResult.ALLOWED


def _is_within_workspace(path: str, workspace_root: str) -> bool:
    """Vérifie si un chemin est dans le workspace."""
    normalized = path if path.startswith("/") else f"{workspace_root}/{path}"
    root = workspace_root if workspace_root.endswith("/") else f"{workspace_root}/"
    return normalized.startswith(root) or normalized == workspace_root.rstrip("/")


_READ_ONLY_COMMANDS = frozenset([
    "cat", "head", "tail", "less", "more", "wc", "ls", "find", "grep", "rg",
    "awk", "sed", "echo", "printf", "which", "where", "whoami", "pwd", "env",
    "printenv", "date", "cal", "df", "du", "free", "uptime", "uname", "file",
    "stat", "diff", "sort", "uniq", "tr", "cut", "paste", "tee", "xargs",
    "test", "true", "false", "type", "readlink", "realpath", "basename",
    "dirname", "sha256sum", "md5sum", "b3sum", "xxd", "hexdump", "od",
    "strings", "tree", "jq", "yq", "python3", "python", "node", "ruby",
    "cargo", "rustc", "git", "gh",
])


def _is_read_only_command(command: str) -> bool:
    """Heuristique conservative : la commande est-elle en lecture seule ?"""
    first_token = command.split()[0] if command.split() else ""
    # Extraire le nom de base si chemin complet
    first_token = first_token.rsplit("/", 1)[-1] if "/" in first_token else first_token

    if first_token not in _READ_ONLY_COMMANDS:
        return False
    if "-i " in command or "--in-place" in command or " > " in command or " >> " in command:
        return False
    return True
