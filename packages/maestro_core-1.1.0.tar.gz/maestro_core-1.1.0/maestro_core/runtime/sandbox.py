"""
Configuration et résolution du bac à sable (sandbox).

Traduit depuis sandbox.rs -- isolation filesystem, namespace, réseau.
"""

from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class FilesystemIsolationMode(Enum):
    """Mode d'isolation filesystem."""
    OFF = "off"
    WORKSPACE_ONLY = "workspace-only"
    ALLOW_LIST = "allow-list"


@dataclass
class SandboxConfig:
    """Configuration sandbox depuis settings.json."""
    enabled: bool | None = None
    namespace_restrictions: bool | None = None
    network_isolation: bool | None = None
    filesystem_mode: FilesystemIsolationMode | None = None
    allowed_mounts: list[str] = field(default_factory=list)

    def resolve_request(
        self,
        enabled_override: bool | None = None,
        namespace_override: bool | None = None,
        network_override: bool | None = None,
        filesystem_mode_override: FilesystemIsolationMode | None = None,
        allowed_mounts_override: list[str] | None = None,
    ) -> SandboxRequest:
        return SandboxRequest(
            enabled=enabled_override if enabled_override is not None else (self.enabled if self.enabled is not None else True),
            namespace_restrictions=namespace_override if namespace_override is not None else (self.namespace_restrictions if self.namespace_restrictions is not None else True),
            network_isolation=network_override if network_override is not None else (self.network_isolation if self.network_isolation is not None else False),
            filesystem_mode=filesystem_mode_override or self.filesystem_mode or FilesystemIsolationMode.WORKSPACE_ONLY,
            allowed_mounts=allowed_mounts_override if allowed_mounts_override is not None else list(self.allowed_mounts),
        )


@dataclass
class SandboxRequest:
    """Requête sandbox résolue."""
    enabled: bool = True
    namespace_restrictions: bool = True
    network_isolation: bool = False
    filesystem_mode: FilesystemIsolationMode = FilesystemIsolationMode.WORKSPACE_ONLY
    allowed_mounts: list[str] = field(default_factory=list)


@dataclass
class ContainerEnvironment:
    """Détection de l'environnement conteneur."""
    in_container: bool = False
    markers: list[str] = field(default_factory=list)


@dataclass
class SandboxStatus:
    """Statut complet du sandbox."""
    enabled: bool = False
    requested: SandboxRequest = field(default_factory=SandboxRequest)
    supported: bool = False
    active: bool = False
    namespace_supported: bool = False
    namespace_active: bool = False
    network_supported: bool = False
    network_active: bool = False
    filesystem_mode: FilesystemIsolationMode = FilesystemIsolationMode.WORKSPACE_ONLY
    filesystem_active: bool = False
    allowed_mounts: list[str] = field(default_factory=list)
    in_container: bool = False
    container_markers: list[str] = field(default_factory=list)
    fallback_reason: str | None = None


@dataclass
class SandboxDetectionInputs:
    """Entrées pour la détection conteneur."""
    env_pairs: list[tuple[str, str]] = field(default_factory=list)
    dockerenv_exists: bool = False
    containerenv_exists: bool = False
    proc_1_cgroup: str | None = None


@dataclass
class LinuxSandboxCommand:
    """Commande sandbox Linux (unshare)."""
    program: str = ""
    args: list[str] = field(default_factory=list)
    env: list[tuple[str, str]] = field(default_factory=list)


def detect_container_environment() -> ContainerEnvironment:
    """Détecte si on est dans un conteneur."""
    proc_1_cgroup = None
    try:
        proc_1_cgroup = Path("/proc/1/cgroup").read_text()
    except OSError:
        pass
    return detect_container_environment_from(SandboxDetectionInputs(
        env_pairs=list(os.environ.items()),
        dockerenv_exists=Path("/.dockerenv").exists(),
        containerenv_exists=Path("/run/.containerenv").exists(),
        proc_1_cgroup=proc_1_cgroup,
    ))


def detect_container_environment_from(inputs: SandboxDetectionInputs) -> ContainerEnvironment:
    """Détecte un environnement conteneur depuis des entrées explicites."""
    markers: list[str] = []
    if inputs.dockerenv_exists:
        markers.append("/.dockerenv")
    if inputs.containerenv_exists:
        markers.append("/run/.containerenv")
    for key, value in inputs.env_pairs:
        normalized = key.lower()
        if normalized in ("container", "docker", "podman", "kubernetes_service_host") and value:
            markers.append(f"env:{key}={value}")
    if inputs.proc_1_cgroup:
        for needle in ("docker", "containerd", "kubepods", "podman", "libpod"):
            if needle in inputs.proc_1_cgroup:
                markers.append(f"/proc/1/cgroup:{needle}")
    markers = sorted(set(markers))
    return ContainerEnvironment(in_container=len(markers) > 0, markers=markers)


def resolve_sandbox_status(config: SandboxConfig, cwd: Path) -> SandboxStatus:
    """Résout le statut sandbox depuis la config."""
    request = config.resolve_request()
    return resolve_sandbox_status_for_request(request, cwd)


def resolve_sandbox_status_for_request(request: SandboxRequest, cwd: Path) -> SandboxStatus:
    """Résout le statut sandbox depuis une requête."""
    container = detect_container_environment()
    import sys
    is_linux = sys.platform == "linux"
    namespace_supported = is_linux and _unshare_user_namespace_works()
    network_supported = namespace_supported
    filesystem_active = request.enabled and request.filesystem_mode != FilesystemIsolationMode.OFF
    fallback_reasons: list[str] = []

    if request.enabled and request.namespace_restrictions and not namespace_supported:
        fallback_reasons.append("namespace isolation unavailable (requires Linux with `unshare`)")
    if request.enabled and request.network_isolation and not network_supported:
        fallback_reasons.append("network isolation unavailable (requires Linux with `unshare`)")
    if (request.enabled
            and request.filesystem_mode == FilesystemIsolationMode.ALLOW_LIST
            and not request.allowed_mounts):
        fallback_reasons.append("filesystem allow-list requested without configured mounts")

    active = (
        request.enabled
        and (not request.namespace_restrictions or namespace_supported)
        and (not request.network_isolation or network_supported)
    )
    allowed_mounts = _normalize_mounts(request.allowed_mounts, cwd)

    return SandboxStatus(
        enabled=request.enabled,
        requested=request,
        supported=namespace_supported,
        active=active,
        namespace_supported=namespace_supported,
        namespace_active=request.enabled and request.namespace_restrictions and namespace_supported,
        network_supported=network_supported,
        network_active=request.enabled and request.network_isolation and network_supported,
        filesystem_mode=request.filesystem_mode,
        filesystem_active=filesystem_active,
        allowed_mounts=allowed_mounts,
        in_container=container.in_container,
        container_markers=container.markers,
        fallback_reason="; ".join(fallback_reasons) if fallback_reasons else None,
    )


def build_linux_sandbox_command(
    command: str, cwd: Path, status: SandboxStatus
) -> LinuxSandboxCommand | None:
    """Construit la commande unshare pour le sandbox Linux."""
    import sys
    if sys.platform != "linux" or not status.enabled or (not status.namespace_active and not status.network_active):
        return None

    args = ["--user", "--map-root-user", "--mount", "--ipc", "--pid", "--uts", "--fork"]
    if status.network_active:
        args.append("--net")
    args.extend(["sh", "-lc", command])

    sandbox_home = str(cwd / ".sandbox-home")
    sandbox_tmp = str(cwd / ".sandbox-tmp")
    env: list[tuple[str, str]] = [
        ("HOME", sandbox_home),
        ("TMPDIR", sandbox_tmp),
        ("CLAWD_SANDBOX_FILESYSTEM_MODE", status.filesystem_mode.value),
        ("CLAWD_SANDBOX_ALLOWED_MOUNTS", ":".join(status.allowed_mounts)),
    ]
    path = os.environ.get("PATH")
    if path:
        env.append(("PATH", path))

    return LinuxSandboxCommand(program="unshare", args=args, env=env)


def _normalize_mounts(mounts: list[str], cwd: Path) -> list[str]:
    result: list[str] = []
    for mount in mounts:
        p = Path(mount)
        if p.is_absolute():
            result.append(str(p))
        else:
            result.append(str(cwd / p))
    return result


_unshare_cached: bool | None = None

def _unshare_user_namespace_works() -> bool:
    """Vérifie si unshare --user fonctionne."""
    global _unshare_cached
    if _unshare_cached is not None:
        return _unshare_cached
    if not _command_exists("unshare"):
        _unshare_cached = False
        return False
    try:
        result = subprocess.run(
            ["unshare", "--user", "--map-root-user", "true"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        _unshare_cached = result.returncode == 0
    except OSError:
        _unshare_cached = False
    return _unshare_cached


def _command_exists(command: str) -> bool:
    path = os.environ.get("PATH", "")
    return any((Path(d) / command).exists() for d in path.split(os.pathsep))
