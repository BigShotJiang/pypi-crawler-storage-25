"""
Opérations fichiers : lecture, écriture, édition, glob, grep.

Traduit depuis file_ops.rs.
"""
from __future__ import annotations
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from fnmatch import fnmatch

MAX_READ_SIZE = 10 * 1024 * 1024
MAX_WRITE_SIZE = 10 * 1024 * 1024

@dataclass
class TextFilePayload:
    file_path: str = ""
    content: str = ""
    num_lines: int = 0
    start_line: int = 0
    total_lines: int = 0

@dataclass
class ReadFileOutput:
    kind: str = "text"
    file: TextFilePayload = field(default_factory=TextFilePayload)

@dataclass
class StructuredPatchHunk:
    old_start: int = 0
    old_lines: int = 0
    new_start: int = 0
    new_lines: int = 0
    lines: list[str] = field(default_factory=list)

@dataclass
class WriteFileOutput:
    kind: str = "create"
    file_path: str = ""
    content: str = ""
    structured_patch: list[StructuredPatchHunk] = field(default_factory=list)
    original_file: str | None = None
    git_diff: object | None = None

@dataclass
class EditFileOutput:
    file_path: str = ""
    old_string: str = ""
    new_string: str = ""
    original_file: str = ""
    structured_patch: list[StructuredPatchHunk] = field(default_factory=list)
    user_modified: bool = False
    replace_all: bool = False
    git_diff: object | None = None

@dataclass
class GlobSearchOutput:
    duration_ms: int = 0
    num_files: int = 0
    filenames: list[str] = field(default_factory=list)
    truncated: bool = False

@dataclass
class GrepSearchInput:
    pattern: str = ""
    path: str | None = None
    glob: str | None = None
    output_mode: str | None = None
    before: int | None = None
    after: int | None = None
    context_short: int | None = None
    context: int | None = None
    line_numbers: bool | None = None
    case_insensitive: bool | None = None
    file_type: str | None = None
    head_limit: int | None = None
    offset: int | None = None
    multiline: bool | None = None

@dataclass
class GrepSearchOutput:
    mode: str | None = None
    num_files: int = 0
    filenames: list[str] = field(default_factory=list)
    content: str | None = None
    num_lines: int | None = None
    num_matches: int | None = None
    applied_limit: int | None = None
    applied_offset: int | None = None

def _is_binary_file(path: Path) -> bool:
    try:
        with open(path, "rb") as f:
            chunk = f.read(8192)
            return b"\x00" in chunk
    except OSError:
        return False

def _validate_workspace_boundary(resolved: Path, workspace_root: Path) -> None:
    if not str(resolved).startswith(str(workspace_root)):
        raise PermissionError(f"path {resolved} escapes workspace boundary {workspace_root}")

def _normalize_path(path: str) -> Path:
    p = Path(path)
    if not p.is_absolute():
        p = Path.cwd() / p
    return p.resolve()

def _normalize_path_allow_missing(path: str) -> Path:
    p = Path(path)
    if not p.is_absolute():
        p = Path.cwd() / p
    try:
        return p.resolve()
    except OSError:
        if p.parent.exists():
            return p.parent.resolve() / p.name
        return p

def read_file(path: str, offset: int | None = None, limit: int | None = None) -> ReadFileOutput:
    absolute = _normalize_path(path)
    size = absolute.stat().st_size
    if size > MAX_READ_SIZE:
        raise ValueError(f"file is too large ({size} bytes, max {MAX_READ_SIZE} bytes)")
    if _is_binary_file(absolute):
        raise ValueError("file appears to be binary")
    content = absolute.read_text()
    lines = content.split("\n")
    start = min(offset or 0, len(lines))
    end = min(start + limit, len(lines)) if limit is not None else len(lines)
    selected = "\n".join(lines[start:end])
    return ReadFileOutput(kind="text", file=TextFilePayload(
        file_path=str(absolute), content=selected,
        num_lines=end - start, start_line=start + 1, total_lines=len(lines),
    ))

def write_file(path: str, content: str) -> WriteFileOutput:
    if len(content) > MAX_WRITE_SIZE:
        raise ValueError(f"content is too large ({len(content)} bytes, max {MAX_WRITE_SIZE} bytes)")
    absolute = _normalize_path_allow_missing(path)
    original = None
    try:
        original = absolute.read_text()
    except FileNotFoundError:
        pass
    absolute.parent.mkdir(parents=True, exist_ok=True)
    absolute.write_text(content)
    return WriteFileOutput(
        kind="update" if original is not None else "create",
        file_path=str(absolute), content=content,
        structured_patch=_make_patch(original or "", content),
        original_file=original,
    )

def edit_file(path: str, old_string: str, new_string: str, replace_all: bool = False) -> EditFileOutput:
    absolute = _normalize_path(path)
    original = absolute.read_text()
    if old_string == new_string:
        raise ValueError("old_string and new_string must differ")
    if old_string not in original:
        raise FileNotFoundError("old_string not found in file")
    updated = original.replace(old_string, new_string) if replace_all else original.replace(old_string, new_string, 1)
    absolute.write_text(updated)
    return EditFileOutput(
        file_path=str(absolute), old_string=old_string, new_string=new_string,
        original_file=original, structured_patch=_make_patch(original, updated),
        replace_all=replace_all,
    )

def glob_search(pattern: str, path: str | None = None) -> GlobSearchOutput:
    started = time.time()
    base = _normalize_path(path) if path else Path.cwd()
    if Path(pattern).is_absolute():
        search = pattern
    else:
        search = str(base / pattern)
    import glob as _glob_mod
    matches = [Path(m) for m in _glob_mod.glob(search, recursive=True) if Path(m).is_file()]
    matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    truncated = len(matches) > 100
    filenames = [str(m) for m in matches[:100]]
    elapsed = int((time.time() - started) * 1000)
    return GlobSearchOutput(duration_ms=elapsed, num_files=len(filenames), filenames=filenames, truncated=truncated)

def grep_search(input: GrepSearchInput) -> GrepSearchOutput:
    base = _normalize_path(input.path) if input.path else Path.cwd()
    flags = re.IGNORECASE if input.case_insensitive else 0
    if input.multiline:
        flags |= re.DOTALL
    regex = re.compile(input.pattern, flags)
    output_mode = input.output_mode or "files_with_matches"
    ctx = input.context or input.context_short or 0
    filenames: list[str] = []
    content_lines: list[str] = []
    total_matches = 0

    files = _collect_search_files(base)
    for fp in files:
        if not _matches_filters(fp, input.glob, input.file_type):
            continue
        try:
            text = fp.read_text()
        except (OSError, UnicodeDecodeError):
            continue
        if output_mode == "count":
            count = len(regex.findall(text))
            if count > 0:
                filenames.append(str(fp))
                total_matches += count
            continue
        file_lines = text.split("\n")
        matched_indices: list[int] = []
        for i, line in enumerate(file_lines):
            if regex.search(line):
                total_matches += 1
                matched_indices.append(i)
        if not matched_indices:
            continue
        filenames.append(str(fp))
        if output_mode == "content":
            for idx in matched_indices:
                start = max(0, idx - (input.before or ctx))
                end = min(len(file_lines), idx + (input.after or ctx) + 1)
                for cur in range(start, end):
                    prefix = f"{fp}:{cur + 1}:" if input.line_numbers is not False else f"{fp}:"
                    content_lines.append(f"{prefix}{file_lines[cur]}")

    filenames, applied_limit, applied_offset = _apply_limit(filenames, input.head_limit, input.offset)
    if output_mode == "content":
        content_lines, cl, co = _apply_limit(content_lines, input.head_limit, input.offset)
        return GrepSearchOutput(mode=output_mode, num_files=len(filenames), filenames=filenames, num_lines=len(content_lines), content="\n".join(content_lines), applied_limit=cl, applied_offset=co)
    return GrepSearchOutput(mode=output_mode, num_files=len(filenames), filenames=filenames, num_matches=total_matches if output_mode == "count" else None, applied_limit=applied_limit, applied_offset=applied_offset)

def read_file_in_workspace(path: str, offset: int | None, limit: int | None, workspace_root: Path) -> ReadFileOutput:
    absolute = _normalize_path(path)
    canonical_root = workspace_root.resolve() if workspace_root.exists() else workspace_root
    _validate_workspace_boundary(absolute, canonical_root)
    return read_file(path, offset, limit)

def write_file_in_workspace(path: str, content: str, workspace_root: Path) -> WriteFileOutput:
    absolute = _normalize_path_allow_missing(path)
    canonical_root = workspace_root.resolve() if workspace_root.exists() else workspace_root
    _validate_workspace_boundary(absolute, canonical_root)
    return write_file(path, content)

def edit_file_in_workspace(path: str, old_string: str, new_string: str, replace_all: bool, workspace_root: Path) -> EditFileOutput:
    absolute = _normalize_path(path)
    canonical_root = workspace_root.resolve() if workspace_root.exists() else workspace_root
    _validate_workspace_boundary(absolute, canonical_root)
    return edit_file(path, old_string, new_string, replace_all)

def is_symlink_escape(path: Path, workspace_root: Path) -> bool:
    if not path.is_symlink():
        return False
    resolved = path.resolve()
    canonical_root = workspace_root.resolve() if workspace_root.exists() else workspace_root
    return not str(resolved).startswith(str(canonical_root))

def _collect_search_files(base: Path) -> list[Path]:
    if base.is_file():
        return [base]
    files: list[Path] = []
    for root, dirs, fnames in os.walk(base):
        for fname in fnames:
            files.append(Path(root) / fname)
    return files

def _matches_filters(path: Path, glob_filter: str | None, file_type: str | None) -> bool:
    if glob_filter and not fnmatch(str(path), glob_filter) and not fnmatch(path.name, glob_filter):
        return False
    if file_type and path.suffix.lstrip(".") != file_type:
        return False
    return True

def _apply_limit(items: list, limit: int | None, offset: int | None) -> tuple[list, int | None, int | None]:
    off = offset or 0
    items = items[off:]
    explicit = limit if limit is not None else 250
    if explicit == 0:
        return items, None, off if off > 0 else None
    truncated = len(items) > explicit
    items = items[:explicit]
    return items, explicit if truncated else None, off if off > 0 else None

def _make_patch(original: str, updated: str) -> list[StructuredPatchHunk]:
    lines = [f"-{l}" for l in original.split("\n")] + [f"+{l}" for l in updated.split("\n")]
    return [StructuredPatchHunk(old_start=1, old_lines=original.count("\n") + 1, new_start=1, new_lines=updated.count("\n") + 1, lines=lines)]
