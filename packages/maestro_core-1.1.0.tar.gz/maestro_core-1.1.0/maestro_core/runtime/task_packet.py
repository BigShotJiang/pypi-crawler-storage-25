"""
Format de paquet de tâche typé.

Traduit depuis task_packet.rs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

@dataclass
class RepoConfig:
    repo_root: Path = field(default_factory=Path)
    worktree_root: Path | None = None
    def dispatch_root(self) -> Path:
        return self.worktree_root or self.repo_root

class TaskScope:
    pass

@dataclass
class TaskScopeSingleFile(TaskScope):
    path: Path = field(default_factory=Path)

@dataclass
class TaskScopeModule(TaskScope):
    crate_name: str = ""

class TaskScopeWorkspace(TaskScope):
    pass

@dataclass
class TaskScopeCustom(TaskScope):
    paths: list[Path] = field(default_factory=list)

class BranchPolicy:
    pass

@dataclass
class BranchPolicyCreateNew(BranchPolicy):
    prefix: str = ""

@dataclass
class BranchPolicyUseExisting(BranchPolicy):
    name: str = ""

class BranchPolicyWorktreeIsolated(BranchPolicy):
    pass

class CommitPolicy(Enum):
    COMMIT_PER_TASK = "commit_per_task"
    SQUASH_ON_MERGE = "squash_on_merge"
    NO_AUTO_COMMIT = "no_auto_commit"

class TaskGreenLevel(Enum):
    PACKAGE = "package"
    WORKSPACE = "workspace"
    MERGE_READY = "merge_ready"

class AcceptanceTest:
    pass

@dataclass
class AcceptanceTestCargoTest(AcceptanceTest):
    filter: str | None = None

@dataclass
class AcceptanceTestCustomCommand(AcceptanceTest):
    cmd: str = ""

@dataclass
class AcceptanceTestGreenLevel(AcceptanceTest):
    level: TaskGreenLevel = TaskGreenLevel.PACKAGE

class ReportingContract(Enum):
    EVENT_STREAM = "event_stream"
    SUMMARY = "summary"
    SILENT = "silent"

class TaskEscalationPolicy:
    pass

@dataclass
class EscalationRetryThenEscalate(TaskEscalationPolicy):
    max_retries: int = 1

class EscalationAutoEscalate(TaskEscalationPolicy):
    pass

class EscalationNeverEscalate(TaskEscalationPolicy):
    pass

@dataclass
class TaskPacket:
    id: str = ""
    objective: str = ""
    scope: TaskScope = field(default_factory=TaskScopeWorkspace)
    repo_config: RepoConfig = field(default_factory=RepoConfig)
    branch_policy: BranchPolicy = field(default_factory=BranchPolicyWorktreeIsolated)
    acceptance_tests: list[AcceptanceTest] = field(default_factory=list)
    commit_policy: CommitPolicy = CommitPolicy.COMMIT_PER_TASK
    reporting: ReportingContract = ReportingContract.EVENT_STREAM
    escalation: TaskEscalationPolicy = field(default_factory=EscalationNeverEscalate)
    created_at: int = 0
    metadata: dict = field(default_factory=dict)

    def resolve_scope_paths(self) -> list[Path]:
        root = self.repo_config.dispatch_root()
        if isinstance(self.scope, TaskScopeSingleFile):
            return [root / self.scope.path if not self.scope.path.is_absolute() else self.scope.path]
        if isinstance(self.scope, TaskScopeModule):
            return [root / "crates" / self.scope.crate_name]
        if isinstance(self.scope, TaskScopeWorkspace):
            return [root]
        if isinstance(self.scope, TaskScopeCustom):
            return [root / p if not p.is_absolute() else p for p in self.scope.paths]
        return [root]

class TaskPacketValidationError(Exception):
    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__("; ".join(errors))

@dataclass
class ValidatedPacket:
    _packet: TaskPacket = field(default_factory=TaskPacket)
    def packet(self) -> TaskPacket:
        return self._packet
    def into_inner(self) -> TaskPacket:
        return self._packet
    def resolve_scope_paths(self) -> list[Path]:
        return self._packet.resolve_scope_paths()

def validate_packet(packet: TaskPacket) -> ValidatedPacket:
    errors: list[str] = []
    if not packet.id.strip():
        errors.append("packet id must not be empty")
    if not packet.objective.strip():
        errors.append("packet objective must not be empty")
    if not str(packet.repo_config.repo_root):
        errors.append("repo_config repo_root must not be empty")
    if errors:
        raise TaskPacketValidationError(errors)
    return ValidatedPacket(_packet=packet)

