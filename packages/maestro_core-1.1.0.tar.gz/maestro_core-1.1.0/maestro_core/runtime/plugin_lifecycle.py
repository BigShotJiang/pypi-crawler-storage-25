"""
Cycle de vie des plugins MCP.

Traduit depuis plugin_lifecycle.rs.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
import time
from .mcp_tool_bridge import McpToolInfo, McpResourceInfo

def _now_secs() -> int:
    return int(time.time())

ToolInfo = McpToolInfo
ResourceInfo = McpResourceInfo

class ServerStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    FAILED = "failed"

@dataclass
class ServerHealth:
    server_name: str = ""
    status: ServerStatus = ServerStatus.HEALTHY
    capabilities: list[str] = field(default_factory=list)
    last_error: str | None = None

@dataclass
class PluginState:
    pass

class PluginUnconfigured(PluginState): pass
class PluginValidated(PluginState): pass
class PluginStarting(PluginState): pass
class PluginHealthy(PluginState): pass

@dataclass
class PluginDegraded(PluginState):
    healthy_servers: list[str] = field(default_factory=list)
    failed_servers: list[ServerHealth] = field(default_factory=list)

@dataclass
class PluginFailed(PluginState):
    reason: str = ""

class PluginShuttingDown(PluginState): pass
class PluginStopped(PluginState): pass

def plugin_state_from_servers(servers: list[ServerHealth]) -> PluginState:
    if not servers:
        return PluginFailed(reason="no servers available")
    healthy = [s.server_name for s in servers if s.status != ServerStatus.FAILED]
    failed = [s for s in servers if s.status == ServerStatus.FAILED]
    has_degraded = any(s.status == ServerStatus.DEGRADED for s in servers)
    if not failed and not has_degraded:
        return PluginHealthy()
    if not healthy:
        return PluginFailed(reason=f"all {len(failed)} servers failed")
    return PluginDegraded(healthy_servers=healthy, failed_servers=failed)

@dataclass
class PluginHealthcheck:
    plugin_name: str = ""
    state: PluginState = field(default_factory=PluginUnconfigured)
    servers: list[ServerHealth] = field(default_factory=list)
    last_check: int = field(default_factory=_now_secs)

    @staticmethod
    def new(plugin_name: str, servers: list[ServerHealth]) -> PluginHealthcheck:
        return PluginHealthcheck(plugin_name=plugin_name, state=plugin_state_from_servers(servers), servers=servers)

@dataclass
class DiscoveryResult:
    tools: list[ToolInfo] = field(default_factory=list)
    resources: list[ResourceInfo] = field(default_factory=list)
    partial: bool = False

@dataclass
class DegradedMode:
    available_tools: list[str] = field(default_factory=list)
    unavailable_tools: list[str] = field(default_factory=list)
    reason: str = ""

class PluginLifecycleEvent(Enum):
    CONFIG_VALIDATED = "config_validated"
    STARTUP_HEALTHY = "startup_healthy"
    STARTUP_DEGRADED = "startup_degraded"
    STARTUP_FAILED = "startup_failed"
    SHUTDOWN = "shutdown"

class PluginLifecycle(ABC):
    @abstractmethod
    def validate_config(self, config) -> None: ...
    @abstractmethod
    def healthcheck(self) -> PluginHealthcheck: ...
    @abstractmethod
    def discover(self) -> DiscoveryResult: ...
    @abstractmethod
    def shutdown(self) -> None: ...

