"""
Système de hooks pre/post exécution d'outils.

Traduit depuis hooks.rs.
"""
from __future__ import annotations
import json as _json
import os
import subprocess
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from .permissions import PermissionOverride

HookPermissionDecision = PermissionOverride

class HookEvent(Enum):
    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    POST_TOOL_USE_FAILURE = "PostToolUseFailure"

    def as_str(self) -> str:
        return self.value

@dataclass
class HookProgressEvent:
    pass

@dataclass
class HookProgressStarted(HookProgressEvent):
    event: HookEvent = HookEvent.PRE_TOOL_USE
    tool_name: str = ""
    command: str = ""

@dataclass
class HookProgressCompleted(HookProgressEvent):
    event: HookEvent = HookEvent.PRE_TOOL_USE
    tool_name: str = ""
    command: str = ""

@dataclass
class HookProgressCancelled(HookProgressEvent):
    event: HookEvent = HookEvent.PRE_TOOL_USE
    tool_name: str = ""
    command: str = ""

class HookProgressReporter(ABC):
    @abstractmethod
    def on_event(self, event: HookProgressEvent) -> None: ...

class HookAbortSignal:
    def __init__(self) -> None:
        self._aborted = threading.Event()
    def abort(self) -> None:
        self._aborted.set()
    def is_aborted(self) -> bool:
        return self._aborted.is_set()
    def clone(self) -> HookAbortSignal:
        sig = HookAbortSignal()
        sig._aborted = self._aborted
        return sig

@dataclass
class HookRunResult:
    denied: bool = False
    failed: bool = False
    cancelled: bool = False
    _messages: list[str] = field(default_factory=list)
    _permission_override: PermissionOverride | None = None
    _permission_reason: str | None = None
    _updated_input: str | None = None

    @staticmethod
    def allow(messages: list[str] | None = None) -> HookRunResult:
        return HookRunResult(_messages=messages or [])

    def is_denied(self) -> bool:
        return self.denied
    def is_failed(self) -> bool:
        return self.failed
    def is_cancelled(self) -> bool:
        return self.cancelled
    def messages(self) -> list[str]:
        return self._messages
    def permission_override(self) -> PermissionOverride | None:
        return self._permission_override
    def permission_reason(self) -> str | None:
        return self._permission_reason
    def updated_input(self) -> str | None:
        return self._updated_input

class HookRunner:
    def __init__(self, config=None) -> None:
        from .config import RuntimeHookConfig
        self._config: RuntimeHookConfig = config or RuntimeHookConfig()

    @staticmethod
    def from_feature_config(feature_config) -> HookRunner:
        return HookRunner(config=feature_config.hooks)

    def run_pre_tool_use(self, tool_name: str, tool_input: str) -> HookRunResult:
        return self.run_pre_tool_use_with_context(tool_name, tool_input, None, None)

    def run_pre_tool_use_with_context(self, tool_name: str, tool_input: str, abort_signal: HookAbortSignal | None = None, reporter: HookProgressReporter | None = None) -> HookRunResult:
        return self._run_commands(HookEvent.PRE_TOOL_USE, self._config.pre_tool_use(), tool_name, tool_input, None, False, abort_signal, reporter)

    def run_post_tool_use(self, tool_name: str, tool_input: str, tool_output: str, is_error: bool) -> HookRunResult:
        return self.run_post_tool_use_with_context(tool_name, tool_input, tool_output, is_error, None, None)

    def run_post_tool_use_with_context(self, tool_name: str, tool_input: str, tool_output: str, is_error: bool, abort_signal: HookAbortSignal | None = None, reporter: HookProgressReporter | None = None) -> HookRunResult:
        return self._run_commands(HookEvent.POST_TOOL_USE, self._config.post_tool_use(), tool_name, tool_input, tool_output, is_error, abort_signal, reporter)

    def run_post_tool_use_failure(self, tool_name: str, tool_input: str, tool_error: str) -> HookRunResult:
        return self.run_post_tool_use_failure_with_context(tool_name, tool_input, tool_error, None, None)

    def run_post_tool_use_failure_with_context(self, tool_name: str, tool_input: str, tool_error: str, abort_signal: HookAbortSignal | None = None, reporter: HookProgressReporter | None = None) -> HookRunResult:
        return self._run_commands(HookEvent.POST_TOOL_USE_FAILURE, self._config.post_tool_use_failure(), tool_name, tool_input, tool_error, True, abort_signal, reporter)

    def _run_commands(self, event: HookEvent, commands: list[str], tool_name: str, tool_input: str, tool_output: str | None, is_error: bool, abort_signal: HookAbortSignal | None, reporter: HookProgressReporter | None) -> HookRunResult:
        if not commands:
            return HookRunResult.allow()
        if abort_signal and abort_signal.is_aborted():
            return HookRunResult(cancelled=True, _messages=[f"{event.as_str()} hook cancelled before execution"])

        payload = _json.dumps({"hook_event_name": event.as_str(), "tool_name": tool_name, "tool_input_json": tool_input, "tool_output": tool_output, "tool_result_is_error": is_error})
        result = HookRunResult.allow()

        for command in commands:
            if reporter:
                reporter.on_event(HookProgressStarted(event=event, tool_name=tool_name, command=command))
            try:
                env = dict(os.environ)
                env.update({"HOOK_EVENT": event.as_str(), "HOOK_TOOL_NAME": tool_name, "HOOK_TOOL_INPUT": tool_input, "HOOK_TOOL_IS_ERROR": "1" if is_error else "0"})
                if tool_output is not None:
                    env["HOOK_TOOL_OUTPUT"] = tool_output

                proc = subprocess.Popen(["sh", "-lc", command], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)

                # Boucle d'attente avec vérification d'abort
                proc.stdin.write(payload.encode())
                proc.stdin.close()
                while proc.poll() is None:
                    if abort_signal and abort_signal.is_aborted():
                        proc.kill()
                        proc.wait()
                        if reporter:
                            reporter.on_event(HookProgressCancelled(event=event, tool_name=tool_name, command=command))
                        result.cancelled = True
                        result._messages.append(f"{event.as_str()} hook `{command}` cancelled while handling `{tool_name}`")
                        return result
                    time.sleep(0.02)

                stdout = proc.stdout.read().decode("utf-8", errors="replace").strip()
                stderr = proc.stderr.read().decode("utf-8", errors="replace").strip()
                parsed = _parse_hook_output(stdout)

                if reporter:
                    reporter.on_event(HookProgressCompleted(event=event, tool_name=tool_name, command=command))

                if proc.returncode == 0:
                    if parsed.get("deny"):
                        _merge_parsed(result, parsed)
                        result.denied = True
                        return result
                    _merge_parsed(result, parsed)
                elif proc.returncode == 2:
                    parsed.setdefault("messages", []).insert(0, f"{event.as_str()} hook denied tool `{tool_name}`")
                    _merge_parsed(result, parsed)
                    result.denied = True
                    return result
                else:
                    msg = f"Hook `{command}` exited with status {proc.returncode}"
                    if stdout:
                        msg += f": {stdout}"
                    elif stderr:
                        msg += f": {stderr}"
                    parsed.setdefault("messages", []).insert(0, msg)
                    _merge_parsed(result, parsed)
                    result.failed = True
                    return result
            except OSError as e:
                result.failed = True
                result._messages.append(f"{event.as_str()} hook `{command}` failed to start for `{tool_name}`: {e}")
                return result
        return result


def _parse_hook_output(stdout: str) -> dict:
    if not stdout:
        return {}
    try:
        root = _json.loads(stdout)
        if not isinstance(root, dict):
            return {"messages": [stdout]}
    except _json.JSONDecodeError:
        return {"messages": [stdout]}
    parsed: dict = {"messages": [], "deny": False}
    if "systemMessage" in root:
        parsed["messages"].append(root["systemMessage"])
    if "reason" in root:
        parsed["messages"].append(root["reason"])
    if root.get("continue") is False or root.get("decision") == "block":
        parsed["deny"] = True
    specific = root.get("hookSpecificOutput", {})
    if isinstance(specific, dict):
        if "additionalContext" in specific:
            parsed["messages"].append(specific["additionalContext"])
        decision = specific.get("permissionDecision")
        if decision == "allow":
            parsed["permission_override"] = PermissionOverride.ALLOW
        elif decision == "deny":
            parsed["permission_override"] = PermissionOverride.DENY
        elif decision == "ask":
            parsed["permission_override"] = PermissionOverride.ASK
        if "permissionDecisionReason" in specific:
            parsed["permission_reason"] = specific["permissionDecisionReason"]
        if "updatedInput" in specific:
            parsed["updated_input"] = _json.dumps(specific["updatedInput"])
    if not parsed["messages"]:
        parsed["messages"].append(stdout)
    return parsed


def _merge_parsed(result: HookRunResult, parsed: dict) -> None:
    result._messages.extend(parsed.get("messages", []))
    if "permission_override" in parsed:
        result._permission_override = parsed["permission_override"]
    if "permission_reason" in parsed:
        result._permission_reason = parsed["permission_reason"]
    if "updated_input" in parsed:
        result._updated_input = parsed["updated_input"]
