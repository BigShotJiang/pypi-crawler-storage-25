"""
Contrôle des sessions managées.

Traduit depuis session_control.rs.
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from pathlib import Path
from .session import Session, SessionError

PRIMARY_SESSION_EXTENSION = "jsonl"
LEGACY_SESSION_EXTENSION = "json"
LATEST_SESSION_REFERENCE = "latest"
_SESSION_REFERENCE_ALIASES = [LATEST_SESSION_REFERENCE, "last", "recent"]

class SessionControlError(Exception):
    pass

@dataclass
class SessionHandle:
    id: str = ""
    path: Path = field(default_factory=Path)

@dataclass
class ManagedSessionSummary:
    id: str = ""
    path: Path = field(default_factory=Path)
    modified_epoch_millis: int = 0
    message_count: int = 0
    parent_session_id: str | None = None
    branch_name: str | None = None

@dataclass
class LoadedManagedSession:
    handle: SessionHandle = field(default_factory=SessionHandle)
    session: Session = field(default_factory=Session)

@dataclass
class ForkedManagedSession:
    parent_session_id: str = ""
    handle: SessionHandle = field(default_factory=SessionHandle)
    session: Session = field(default_factory=Session)
    branch_name: str | None = None

def managed_sessions_dir_for(base_dir: Path) -> Path:
    path = base_dir / ".claw" / "sessions"
    path.mkdir(parents=True, exist_ok=True)
    return path

def create_managed_session_handle_for(base_dir: Path, session_id: str) -> SessionHandle:
    path = managed_sessions_dir_for(base_dir) / f"{session_id}.{PRIMARY_SESSION_EXTENSION}"
    return SessionHandle(id=session_id, path=path)

def list_managed_sessions_for(base_dir: Path) -> list[ManagedSessionSummary]:
    sessions_dir = managed_sessions_dir_for(base_dir)
    sessions: list[ManagedSessionSummary] = []
    for entry in sessions_dir.iterdir():
        if entry.suffix not in (f".{PRIMARY_SESSION_EXTENSION}", f".{LEGACY_SESSION_EXTENSION}"):
            continue
        modified = int(entry.stat().st_mtime * 1000)
        try:
            session = Session.load_from_path(entry)
            pid = session.fork.parent_session_id if session.fork else None
            bn = session.fork.branch_name if session.fork else None
            sessions.append(ManagedSessionSummary(id=session.session_id, path=entry, modified_epoch_millis=modified, message_count=len(session.messages), parent_session_id=pid, branch_name=bn))
        except Exception:
            sessions.append(ManagedSessionSummary(id=entry.stem, path=entry, modified_epoch_millis=modified))
    sessions.sort(key=lambda s: (-s.modified_epoch_millis, s.id))
    return sessions

def latest_managed_session_for(base_dir: Path) -> ManagedSessionSummary:
    sessions = list_managed_sessions_for(base_dir)
    if not sessions:
        raise SessionControlError("no managed sessions found")
    return sessions[0]

def resolve_session_reference_for(base_dir: Path, reference: str) -> SessionHandle:
    if is_session_reference_alias(reference):
        latest = latest_managed_session_for(base_dir)
        return SessionHandle(id=latest.id, path=latest.path)
    direct = Path(reference)
    candidate = direct if direct.is_absolute() else base_dir / direct
    if candidate.exists():
        return SessionHandle(id=candidate.stem, path=candidate)
    # Chercher dans sessions dir
    for ext in [PRIMARY_SESSION_EXTENSION, LEGACY_SESSION_EXTENSION]:
        path = managed_sessions_dir_for(base_dir) / f"{reference}.{ext}"
        if path.exists():
            return SessionHandle(id=reference, path=path)
    raise SessionControlError(f"session not found: {reference}")

def load_managed_session_for(base_dir: Path, reference: str) -> LoadedManagedSession:
    handle = resolve_session_reference_for(base_dir, reference)
    session = Session.load_from_path(handle.path)
    return LoadedManagedSession(handle=SessionHandle(id=session.session_id, path=handle.path), session=session)

def fork_managed_session_for(base_dir: Path, session: Session, branch_name: str | None = None) -> ForkedManagedSession:
    parent_id = session.session_id
    forked = session.fork(branch_name)
    handle = create_managed_session_handle_for(base_dir, forked.session_id)
    forked = forked.with_persistence_path(handle.path)
    forked.save_to_path(handle.path)
    bn = forked.fork.branch_name if forked.fork else None
    return ForkedManagedSession(parent_session_id=parent_id, handle=handle, session=forked, branch_name=bn)

def is_session_reference_alias(reference: str) -> bool:
    return reference.lower() in _SESSION_REFERENCE_ALIASES

