"""
Suivi de l'utilisation des tokens et estimation des coûts.

Traduit depuis usage.rs.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# -- Constantes de pricing par défaut (tier Sonnet) ---------------------------

_DEFAULT_INPUT_COST_PER_MILLION = 15.0
_DEFAULT_OUTPUT_COST_PER_MILLION = 75.0
_DEFAULT_CACHE_CREATION_COST_PER_MILLION = 18.75
_DEFAULT_CACHE_READ_COST_PER_MILLION = 1.5


@dataclass
class ModelPricing:
    """Grille tarifaire d'un modèle."""
    input_cost_per_million: float
    output_cost_per_million: float
    cache_creation_cost_per_million: float
    cache_read_cost_per_million: float

    @staticmethod
    def default_sonnet_tier() -> ModelPricing:
        return ModelPricing(
            input_cost_per_million=_DEFAULT_INPUT_COST_PER_MILLION,
            output_cost_per_million=_DEFAULT_OUTPUT_COST_PER_MILLION,
            cache_creation_cost_per_million=_DEFAULT_CACHE_CREATION_COST_PER_MILLION,
            cache_read_cost_per_million=_DEFAULT_CACHE_READ_COST_PER_MILLION,
        )


@dataclass
class TokenUsage:
    """Compteur de tokens pour un tour de conversation."""
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0

    def total_tokens(self) -> int:
        return (
            self.input_tokens
            + self.output_tokens
            + self.cache_creation_input_tokens
            + self.cache_read_input_tokens
        )

    def estimate_cost_usd(self) -> UsageCostEstimate:
        return self.estimate_cost_usd_with_pricing(ModelPricing.default_sonnet_tier())

    def estimate_cost_usd_with_pricing(self, pricing: ModelPricing) -> UsageCostEstimate:
        return UsageCostEstimate(
            input_cost_usd=_cost_for_tokens(self.input_tokens, pricing.input_cost_per_million),
            output_cost_usd=_cost_for_tokens(self.output_tokens, pricing.output_cost_per_million),
            cache_creation_cost_usd=_cost_for_tokens(
                self.cache_creation_input_tokens, pricing.cache_creation_cost_per_million
            ),
            cache_read_cost_usd=_cost_for_tokens(
                self.cache_read_input_tokens, pricing.cache_read_cost_per_million
            ),
        )

    def summary_lines(self, label: str) -> list[str]:
        return self.summary_lines_for_model(label, None)

    def summary_lines_for_model(self, label: str, model: str | None) -> list[str]:
        pricing = pricing_for_model(model) if model else None
        cost = (
            self.estimate_cost_usd_with_pricing(pricing)
            if pricing
            else self.estimate_cost_usd()
        )
        model_suffix = f" model={model}" if model else ""
        pricing_suffix = ""
        if pricing is None and model is not None:
            pricing_suffix = " pricing=estimated-default"
        return [
            (
                f"{label}: total_tokens={self.total_tokens()} "
                f"input={self.input_tokens} output={self.output_tokens} "
                f"cache_write={self.cache_creation_input_tokens} "
                f"cache_read={self.cache_read_input_tokens} "
                f"estimated_cost={format_usd(cost.total_cost_usd())}"
                f"{model_suffix}{pricing_suffix}"
            ),
            (
                f"  cost breakdown: input={format_usd(cost.input_cost_usd)} "
                f"output={format_usd(cost.output_cost_usd)} "
                f"cache_write={format_usd(cost.cache_creation_cost_usd)} "
                f"cache_read={format_usd(cost.cache_read_cost_usd)}"
            ),
        ]


@dataclass
class UsageCostEstimate:
    """Estimation du coût en USD."""
    input_cost_usd: float
    output_cost_usd: float
    cache_creation_cost_usd: float
    cache_read_cost_usd: float

    def total_cost_usd(self) -> float:
        return (
            self.input_cost_usd
            + self.output_cost_usd
            + self.cache_creation_cost_usd
            + self.cache_read_cost_usd
        )


def pricing_for_model(model: str) -> ModelPricing | None:
    """Retourne la grille tarifaire pour un modèle connu, ou None."""
    normalized = model.lower()
    if "haiku" in normalized:
        return ModelPricing(
            input_cost_per_million=1.0,
            output_cost_per_million=5.0,
            cache_creation_cost_per_million=1.25,
            cache_read_cost_per_million=0.1,
        )
    if "opus" in normalized:
        return ModelPricing(
            input_cost_per_million=15.0,
            output_cost_per_million=75.0,
            cache_creation_cost_per_million=18.75,
            cache_read_cost_per_million=1.5,
        )
    if "sonnet" in normalized:
        return ModelPricing.default_sonnet_tier()
    return None


def format_usd(amount: float) -> str:
    """Formate un montant en USD avec 4 décimales."""
    return f"${amount:.4f}"


def _cost_for_tokens(tokens: int, usd_per_million: float) -> float:
    return tokens / 1_000_000.0 * usd_per_million


# -- UsageTracker --------------------------------------------------------------

@dataclass
class UsageTracker:
    """Suit l'utilisation cumulée des tokens sur une session."""
    _latest_turn: TokenUsage = field(default_factory=TokenUsage)
    _cumulative: TokenUsage = field(default_factory=TokenUsage)
    _turns: int = 0

    def record(self, usage: TokenUsage) -> None:
        self._latest_turn = usage
        self._cumulative.input_tokens += usage.input_tokens
        self._cumulative.output_tokens += usage.output_tokens
        self._cumulative.cache_creation_input_tokens += usage.cache_creation_input_tokens
        self._cumulative.cache_read_input_tokens += usage.cache_read_input_tokens
        self._turns += 1

    def current_turn_usage(self) -> TokenUsage:
        return self._latest_turn

    def cumulative_usage(self) -> TokenUsage:
        return self._cumulative

    def turns(self) -> int:
        return self._turns

    @staticmethod
    def from_session(session: object) -> UsageTracker:
        """Reconstruit un tracker depuis les messages d'une session."""
        tracker = UsageTracker()
        # session.messages est une list[ConversationMessage]
        for message in getattr(session, "messages", []):
            usage = getattr(message, "usage", None)
            if usage is not None:
                tracker.record(usage)
        return tracker
