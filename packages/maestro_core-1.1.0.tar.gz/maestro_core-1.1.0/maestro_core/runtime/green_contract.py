"""
Contrat vert (green contract) pour la validation CI.

Traduit depuis green_contract.rs.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class GreenLevel(IntEnum):
    """Niveau de validation CI requis."""
    TARGETED_TESTS = 0
    PACKAGE = 1
    WORKSPACE = 2
    MERGE_READY = 3

    def as_str(self) -> str:
        return {
            GreenLevel.TARGETED_TESTS: "targeted_tests",
            GreenLevel.PACKAGE: "package",
            GreenLevel.WORKSPACE: "workspace",
            GreenLevel.MERGE_READY: "merge_ready",
        }[self]

    def __str__(self) -> str:
        return self.as_str()


@dataclass
class GreenContract:
    """Contrat spécifiant le niveau vert minimum requis."""
    required_level: GreenLevel

    def evaluate(self, observed_level: GreenLevel | None) -> GreenContractOutcome:
        """Évalue le contrat avec le niveau observé."""
        if observed_level is not None and observed_level >= self.required_level:
            return GreenContractOutcome(
                satisfied=True,
                required_level=self.required_level,
                observed_level=observed_level,
            )
        return GreenContractOutcome(
            satisfied=False,
            required_level=self.required_level,
            observed_level=observed_level,
        )

    def is_satisfied_by(self, observed_level: GreenLevel) -> bool:
        """Vérifie si le niveau observé satisfait le contrat."""
        return observed_level >= self.required_level


@dataclass
class GreenContractOutcome:
    """Résultat de l'évaluation d'un contrat vert."""
    satisfied: bool
    required_level: GreenLevel
    observed_level: GreenLevel | None

    def is_satisfied(self) -> bool:
        return self.satisfied
