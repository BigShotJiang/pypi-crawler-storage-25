"""
Parseur SSE (Server-Sent Events) incrémental.

Traduit depuis sse.rs.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SseEvent:
    """Événement SSE parsé."""
    event: str | None = None
    data: str = ""
    id: str | None = None
    retry: int | None = None


class IncrementalSseParser:
    """Parseur SSE incrémental qui accepte des chunks."""

    def __init__(self) -> None:
        self._buffer = ""
        self._event_name: str | None = None
        self._data_lines: list[str] = []
        self._id: str | None = None
        self._retry: int | None = None

    def push_chunk(self, chunk: str) -> list[SseEvent]:
        """Ajoute un chunk et retourne les événements complets."""
        self._buffer += chunk
        events: list[SseEvent] = []
        while "\n" in self._buffer:
            idx = self._buffer.index("\n")
            line = self._buffer[:idx]
            self._buffer = self._buffer[idx + 1:]
            if line.endswith("\r"):
                line = line[:-1]
            self._process_line(line, events)
        return events

    def finish(self) -> list[SseEvent]:
        """Flush le buffer restant."""
        events: list[SseEvent] = []
        if self._buffer:
            line = self._buffer.rstrip("\r")
            self._buffer = ""
            self._process_line(line, events)
        event = self._take_event()
        if event:
            events.append(event)
        return events

    def _process_line(self, line: str, events: list[SseEvent]) -> None:
        if not line:
            event = self._take_event()
            if event:
                events.append(event)
            return
        if line.startswith(":"):
            return
        if ":" in line:
            field_name, value = line.split(":", 1)
            if value.startswith(" "):
                value = value[1:]
        else:
            field_name = line
            value = ""
        if field_name == "event":
            self._event_name = value
        elif field_name == "data":
            self._data_lines.append(value)
        elif field_name == "id":
            self._id = value
        elif field_name == "retry":
            try:
                self._retry = int(value)
            except ValueError:
                pass

    def _take_event(self) -> SseEvent | None:
        if not self._data_lines and self._event_name is None and self._id is None and self._retry is None:
            return None
        data = "\n".join(self._data_lines)
        self._data_lines.clear()
        event = SseEvent(
            event=self._event_name,
            data=data,
            id=self._id,
            retry=self._retry,
        )
        self._event_name = None
        self._id = None
        self._retry = None
        return event
