"""Adapters — bridge entre le ConversationRuntime CC et maestro_core.

Connecte le vrai runtime CC (permissions, hooks, compaction) au provider
router multi-provider et au tool registry de maestro_core."""

from __future__ import annotations

import asyncio
import json
from typing import Any

from maestro_core.api.types import (
    InputMessage,
    MessageRequest,
    TextInputBlock,
    TextOutputBlock,
    ToolUseOutputBlock,
)
from maestro_core.provider_router import ProviderRouter
from maestro_core.tools.base import ToolRegistry

from .conversation import (
    ApiClient,
    ApiRequest,
    AssistantEvent,
    MessageStop,
    TextDelta,
    ToolError,
    ToolExecutor,
    ToolUse,
    UsageEvent,
)
from .session import ConversationMessage, MessageRole, TextBlock, ToolUseBlock, ToolResultBlock
from .usage import TokenUsage


# ── Retry configuration ──

MAX_RETRIES = 3
RETRY_DELAYS = [1, 3, 10]  # seconds
RETRYABLE_PATTERNS = ("rate_limit", "429", "500", "502", "503", "overloaded", "timeout")


class ProviderApiClient(ApiClient):
    """Bridge entre ConversationRuntime.ApiClient et ProviderRouter.

    Convertit les ApiRequest (format CC) en MessageRequest (format maestro_core),
    envoie via le ProviderRouter, et retourne des AssistantEvent.

    Supporte le streaming en temps réel via un callback optionnel."""

    def __init__(
        self,
        router: ProviderRouter,
        model: str = "",
        system_prompt: str = "",
        tool_registry: ToolRegistry | None = None,
    ) -> None:
        self._router = router
        self._model = model
        self._system_prompt = system_prompt
        self._tool_registry = tool_registry
        # Event loop persistant pour les appels async
        self._loop = asyncio.new_event_loop()
        # Callback pour le streaming en temps réel
        self._stream_callback = None

    def set_stream_callback(self, callback) -> None:
        """Set un callback qui sera appelé pour chaque TextDelta pendant le stream."""
        self._stream_callback = callback

    def __del__(self) -> None:
        if self._loop and not self._loop.is_closed():
            self._loop.close()

    def stream(self, request: ApiRequest) -> list[AssistantEvent]:
        """Envoie la requête au LLM et retourne les events.

        Note: synchrone car ConversationRuntime.run_turn est synchrone.
        On utilise asyncio.run() pour appeler le router async."""
        # Convertir les messages CC en messages maestro_core
        messages = self._convert_messages(request.messages)
        system = "\n".join(request.system_prompt) if request.system_prompt else self._system_prompt

        # Tool definitions pour le LLM
        tool_defs = None
        if self._tool_registry and len(self._tool_registry) > 0:
            from maestro_core.api.types import ToolDefinition as ApiToolDef
            tool_defs = [
                ApiToolDef(name=td.name, description=td.description, input_schema=td.input_schema)
                for td in self._tool_registry.get_definitions()
            ]

        # Construire la requête
        msg_request = MessageRequest(
            model=self._model,
            max_tokens=4096,
            messages=messages,
            system=system,
            tools=tool_defs,
        )

        # Extraire le texte user pour le routage
        user_text = ""
        for msg in reversed(request.messages):
            if msg.role == MessageRole.USER:
                for block in msg.blocks:
                    if isinstance(block, TextBlock):
                        user_text = block.text
                        break
                if user_text:
                    break

        # Essayer le streaming token-by-token d'abord, avec retry sur erreurs transitoires
        try:
            events = self._loop.run_until_complete(
                self._stream_request_with_retry(msg_request, user_text)
            )
        except ConnectionError as e:
            error_str = str(e).lower()
            if "ollama" in error_str or "11434" in error_str:
                raise RuntimeError(
                    "Ollama n'est pas démarré. Lance 'ollama serve' dans un autre terminal."
                ) from e
            raise
        return events

    async def _stream_request_with_retry(
        self, msg_request: MessageRequest, user_text: str
    ) -> list[AssistantEvent]:
        """Wrapper avec retry autour de _stream_request pour les erreurs transitoires."""
        last_error: Exception | None = None
        for attempt in range(MAX_RETRIES):
            try:
                return await self._stream_request(msg_request, user_text)
            except ConnectionError:
                # Connection errors (Ollama down, etc.) — remonter immédiatement
                raise
            except Exception as e:
                last_error = e
                error_str = str(e).lower()
                # Retryable errors only
                if any(pattern in error_str for pattern in RETRYABLE_PATTERNS):
                    if attempt < MAX_RETRIES - 1:
                        delay = RETRY_DELAYS[attempt]
                        if self._stream_callback:
                            self._stream_callback.on_text_delta(f"\n[Erreur transitoire, retry dans {delay}s...]\n")
                        await asyncio.sleep(delay)
                        continue
                # Non-retryable error — remonter immédiatement
                raise
        raise last_error  # type: ignore[misc]

    async def _stream_request(
        self, msg_request: MessageRequest, user_text: str
    ) -> list[AssistantEvent]:
        """Envoie la requête en mode streaming et collecte les events."""
        from maestro_core.api.types import (
            ContentBlockStartEvent,
            ContentBlockDeltaEvent,
            ContentBlockStopEvent,
            MessageStartEvent,
            MessageDeltaEvent,
            MessageStopEvent,
            TextDelta as ApiTextDelta,
            InputJsonDelta,
            TextOutputBlock as ApiTextBlock,
            ToolUseOutputBlock as ApiToolBlock,
        )

        # Résoudre le provider
        decision = self._router.route(user_text)
        target_model = msg_request.model or decision.model

        # Adapter le provider au modèle
        actual_provider = self._router._config.resolve_provider_for_model(target_model)
        if actual_provider != decision.provider_name:
            decision = self._router.route.__func__  # skip, just use model
            actual_provider = self._router._config.resolve_provider_for_model(target_model)

        client = await self._router.get_client(actual_provider)

        # Tenter le streaming
        try:
            stream = await client.stream_message(msg_request)
        except (AttributeError, NotImplementedError):
            # Fallback au mode batch si le client ne supporte pas le streaming
            return await self._batch_request(msg_request, user_text)

        # Collecter les events en streamant les TextDelta au callback
        events: list[AssistantEvent] = []
        text_buffer = ""
        tool_calls: list[dict] = []
        current_tool_args = ""
        current_tool_name = ""
        current_tool_id = ""
        in_tool = False
        usage_event = None

        while True:
            try:
                event = await stream.next_event()
            except KeyboardInterrupt:
                # Close stream gracefully on Ctrl+C
                if hasattr(stream, 'close'):
                    try:
                        await stream.close()
                    except Exception:
                        pass
                raise
            except Exception:
                break

            if event is None:
                break

            # TextDelta — stream au callback
            if isinstance(event, ContentBlockDeltaEvent):
                delta = event.delta
                if isinstance(delta, ApiTextDelta) and hasattr(delta, 'text'):
                    text = delta.text
                    text_buffer += text
                    events.append(TextDelta(text=text))
                    if self._stream_callback:
                        self._stream_callback.on_text_delta(text)
                elif isinstance(delta, InputJsonDelta) and hasattr(delta, 'partial_json'):
                    current_tool_args += delta.partial_json

            # Content block start (tool use)
            elif isinstance(event, ContentBlockStartEvent):
                block = event.content_block
                if isinstance(block, ApiToolBlock):
                    in_tool = True
                    current_tool_name = block.name
                    current_tool_id = block.id
                    current_tool_args = ""
                    if self._stream_callback:
                        self._stream_callback.on_tool_use_start(block.name, block.id)

            # Content block stop
            elif isinstance(event, ContentBlockStopEvent):
                if in_tool:
                    events.append(ToolUse(
                        id=current_tool_id,
                        name=current_tool_name,
                        input=current_tool_args,
                    ))
                    in_tool = False

            # Usage
            elif isinstance(event, MessageDeltaEvent):
                if hasattr(event, 'usage') and event.usage:
                    usage_event = UsageEvent(usage=TokenUsage(
                        input_tokens=getattr(event.usage, 'input_tokens', 0),
                        output_tokens=getattr(event.usage, 'output_tokens', 0),
                    ))

            elif isinstance(event, MessageStartEvent):
                if hasattr(event, 'message') and hasattr(event.message, 'usage'):
                    u = event.message.usage
                    if u:
                        usage_event = UsageEvent(usage=TokenUsage(
                            input_tokens=getattr(u, 'input_tokens', 0),
                            output_tokens=getattr(u, 'output_tokens', 0),
                        ))

        if usage_event:
            events.append(usage_event)
        events.append(MessageStop())
        return events

    async def _batch_request(
        self, msg_request: MessageRequest, user_text: str
    ) -> list[AssistantEvent]:
        """Fallback : mode batch (non-streaming)."""
        response, decision = await self._router.send_message(msg_request, user_text)

        events: list[AssistantEvent] = []
        for block in response.content:
            if isinstance(block, TextOutputBlock):
                events.append(TextDelta(text=block.text))
                if self._stream_callback:
                    self._stream_callback.on_text_delta(block.text)
            elif isinstance(block, ToolUseOutputBlock):
                events.append(ToolUse(
                    id=block.id,
                    name=block.name,
                    input=json.dumps(block.input) if isinstance(block.input, dict) else str(block.input),
                ))
                if self._stream_callback:
                    self._stream_callback.on_tool_use_start(block.name, block.id)

        if response.usage:
            events.append(UsageEvent(usage=TokenUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )))
        events.append(MessageStop())
        return events

    def _convert_messages(self, messages: list[ConversationMessage]) -> list[InputMessage]:
        """Convertit les messages CC en messages maestro_core."""
        result: list[InputMessage] = []

        for msg in messages:
            if msg.role == MessageRole.USER:
                content_blocks = []
                for block in msg.blocks:
                    if isinstance(block, TextBlock):
                        content_blocks.append(TextInputBlock(text=block.text))
                if content_blocks:
                    result.append(InputMessage(role="user", content=content_blocks))

            elif msg.role == MessageRole.ASSISTANT:
                content_blocks = []
                for block in msg.blocks:
                    if isinstance(block, TextBlock):
                        content_blocks.append(TextInputBlock(text=block.text))
                    elif isinstance(block, ToolUseBlock):
                        from maestro_core.api.types import ToolUseInputBlock
                        args = json.loads(block.input) if isinstance(block.input, str) else block.input
                        content_blocks.append(ToolUseInputBlock(
                            id=block.id, name=block.name, input=args
                        ))
                if content_blocks:
                    result.append(InputMessage(role="assistant", content=content_blocks))

            elif msg.role == MessageRole.TOOL:
                from maestro_core.api.types import ToolResultInputBlock, TextToolResultBlock
                for block in msg.blocks:
                    if isinstance(block, ToolResultBlock):
                        result.append(InputMessage(
                            role="user",
                            content=[ToolResultInputBlock(
                                tool_use_id=block.tool_use_id,
                                content=[TextToolResultBlock(text=block.output)],
                                is_error=block.is_error,
                            )],
                        ))

        return result


class RegistryToolExecutor(ToolExecutor):
    """Bridge entre ConversationRuntime.ToolExecutor et maestro_core.ToolRegistry.

    Convertit les appels tool du runtime CC en appels async sur le ToolRegistry."""

    def __init__(self, registry: ToolRegistry, loop: asyncio.AbstractEventLoop | None = None) -> None:
        self._registry = registry
        self._loop = loop or asyncio.new_event_loop()

    def execute(self, tool_name: str, input_str: str) -> str:
        """Exécute un tool via le registry (sync wrapper autour d'async)."""
        tool = self._registry.get(tool_name)
        if tool is None:
            raise ToolError(f"Tool '{tool_name}' not found in registry")

        # Parser les arguments
        try:
            args = json.loads(input_str) if input_str else {}
        except json.JSONDecodeError:
            args = {"input": input_str}

        # Exécuter via le loop persistant
        result = self._loop.run_until_complete(
            self._registry.execute(tool_name, args)
        )

        if result.is_error:
            raise ToolError(result.content)

        return result.content
