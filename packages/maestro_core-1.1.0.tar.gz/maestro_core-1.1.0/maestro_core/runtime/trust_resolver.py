"""
Résolution de confiance (trust) pour les répertoires de travail.

Traduit depuis trust_resolver.rs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


_TRUST_PROMPT_CUES = [
    "do you trust the files in this folder",
    "trust the files in this folder",
    "trust this folder",
    "allow and continue",
    "yes, proceed",
]


class TrustPolicy(Enum):
    AUTO_TRUST = "auto_trust"
    REQUIRE_APPROVAL = "require_approval"
    DENY = "deny"


@dataclass
class TrustEvent:
    pass

@dataclass
class TrustRequired(TrustEvent):
    cwd: str = ""

@dataclass
class TrustResolved(TrustEvent):
    cwd: str = ""
    policy: TrustPolicy = TrustPolicy.AUTO_TRUST

@dataclass
class TrustDenied(TrustEvent):
    cwd: str = ""
    reason: str = ""


@dataclass
class TrustConfig:
    """Configuration de confiance."""
    allowlisted: list[Path] = field(default_factory=list)
    denied: list[Path] = field(default_factory=list)

    def with_allowlisted(self, path: str | Path) -> TrustConfig:
        self.allowlisted.append(Path(path))
        return self

    def with_denied(self, path: str | Path) -> TrustConfig:
        self.denied.append(Path(path))
        return self


@dataclass
class TrustDecisionNotRequired:
    pass

@dataclass
class TrustDecisionRequired:
    policy: TrustPolicy = TrustPolicy.REQUIRE_APPROVAL
    events: list[TrustEvent] = field(default_factory=list)


TrustDecision = TrustDecisionNotRequired | TrustDecisionRequired


class TrustResolver:
    """Résout les décisions de confiance."""

    def __init__(self, config: TrustConfig) -> None:
        self._config = config

    def resolve(self, cwd: str, screen_text: str) -> TrustDecision:
        if not detect_trust_prompt(screen_text):
            return TrustDecisionNotRequired()

        events: list[TrustEvent] = [TrustRequired(cwd=cwd)]

        for root in self._config.denied:
            if _path_matches(cwd, root):
                reason = f"cwd matches denied trust root: {root}"
                events.append(TrustDenied(cwd=cwd, reason=reason))
                return TrustDecisionRequired(policy=TrustPolicy.DENY, events=events)

        if any(_path_matches(cwd, root) for root in self._config.allowlisted):
            events.append(TrustResolved(cwd=cwd, policy=TrustPolicy.AUTO_TRUST))
            return TrustDecisionRequired(policy=TrustPolicy.AUTO_TRUST, events=events)

        return TrustDecisionRequired(policy=TrustPolicy.REQUIRE_APPROVAL, events=events)

    def trusts(self, cwd: str) -> bool:
        if any(_path_matches(cwd, root) for root in self._config.denied):
            return False
        return any(_path_matches(cwd, root) for root in self._config.allowlisted)


def detect_trust_prompt(screen_text: str) -> bool:
    lowered = screen_text.lower()
    return any(needle in lowered for needle in _TRUST_PROMPT_CUES)


def path_matches_trusted_root(cwd: str, trusted_root: str) -> bool:
    return _path_matches(cwd, _normalize_path(Path(trusted_root)))


def _path_matches(candidate: str, root: Path) -> bool:
    c = _normalize_path(Path(candidate))
    r = _normalize_path(root)
    return c == r or str(c).startswith(str(r) + "/")


def _normalize_path(path: Path) -> Path:
    try:
        return path.resolve()
    except OSError:
        return path
