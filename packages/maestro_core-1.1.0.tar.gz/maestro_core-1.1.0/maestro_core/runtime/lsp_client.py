"""
Registre de clients LSP (Language Server Protocol).

Traduit depuis lsp_client.rs.
"""
from __future__ import annotations
import threading
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

class LspAction(Enum):
    DIAGNOSTICS = "diagnostics"
    HOVER = "hover"
    DEFINITION = "definition"
    REFERENCES = "references"
    COMPLETION = "completion"
    SYMBOLS = "symbols"
    FORMAT = "format"

    @staticmethod
    def from_str(s: str) -> LspAction | None:
        mapping = {"diagnostics": LspAction.DIAGNOSTICS, "hover": LspAction.HOVER, "definition": LspAction.DEFINITION, "goto_definition": LspAction.DEFINITION, "references": LspAction.REFERENCES, "find_references": LspAction.REFERENCES, "completion": LspAction.COMPLETION, "completions": LspAction.COMPLETION, "symbols": LspAction.SYMBOLS, "document_symbols": LspAction.SYMBOLS, "format": LspAction.FORMAT, "formatting": LspAction.FORMAT}
        return mapping.get(s)

@dataclass
class LspDiagnostic:
    path: str = ""
    line: int = 0
    character: int = 0
    severity: str = ""
    message: str = ""
    source: str | None = None

@dataclass
class LspLocation:
    path: str = ""
    line: int = 0
    character: int = 0
    end_line: int | None = None
    end_character: int | None = None
    preview: str | None = None

@dataclass
class LspHoverResult:
    content: str = ""
    language: str | None = None

@dataclass
class LspCompletionItem:
    label: str = ""
    kind: str | None = None
    detail: str | None = None
    insert_text: str | None = None

@dataclass
class LspSymbol:
    name: str = ""
    kind: str = ""
    path: str = ""
    line: int = 0
    character: int = 0

class LspServerStatus(Enum):
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    STARTING = "starting"
    ERROR = "error"

@dataclass
class LspServerState:
    language: str = ""
    status: LspServerStatus = LspServerStatus.DISCONNECTED
    root_path: str | None = None
    capabilities: list[str] = field(default_factory=list)
    diagnostics: list[LspDiagnostic] = field(default_factory=list)

_EXT_TO_LANG = {"rs": "rust", "ts": "typescript", "tsx": "typescript", "js": "javascript", "jsx": "javascript", "py": "python", "go": "go", "java": "java", "c": "c", "h": "c", "cpp": "cpp", "hpp": "cpp", "cc": "cpp", "rb": "ruby", "lua": "lua"}

class LspRegistry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._servers: dict[str, LspServerState] = {}

    def register(self, language: str, status: LspServerStatus, root_path: str | None = None, capabilities: list[str] | None = None) -> None:
        with self._lock:
            self._servers[language] = LspServerState(language=language, status=status, root_path=root_path, capabilities=capabilities or [])

    def get(self, language: str) -> LspServerState | None:
        with self._lock:
            return self._servers.get(language)

    def find_server_for_path(self, path: str) -> LspServerState | None:
        ext = Path(path).suffix.lstrip(".")
        language = _EXT_TO_LANG.get(ext)
        if language:
            return self.get(language)
        return None

    def list_servers(self) -> list[LspServerState]:
        with self._lock:
            return list(self._servers.values())

    def add_diagnostics(self, language: str, diagnostics: list[LspDiagnostic]) -> None:
        with self._lock:
            server = self._servers.get(language)
            if not server:
                raise ValueError(f"LSP server not found for language: {language}")
            server.diagnostics.extend(diagnostics)

    def get_diagnostics(self, path: str) -> list[LspDiagnostic]:
        with self._lock:
            result: list[LspDiagnostic] = []
            for server in self._servers.values():
                result.extend(d for d in server.diagnostics if d.path == path)
            return result

    def clear_diagnostics(self, language: str) -> None:
        with self._lock:
            server = self._servers.get(language)
            if server:
                server.diagnostics.clear()

    def disconnect(self, language: str) -> LspServerState | None:
        with self._lock:
            return self._servers.pop(language, None)

    def len(self) -> int:
        with self._lock:
            return len(self._servers)

    def is_empty(self) -> bool:
        return self.len() == 0
