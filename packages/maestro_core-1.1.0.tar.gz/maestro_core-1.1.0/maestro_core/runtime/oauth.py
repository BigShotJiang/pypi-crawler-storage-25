"""
Support OAuth (PKCE, tokens, credentials).

Traduit depuis oauth.rs.
"""
from __future__ import annotations
import hashlib
import json as _json
import os
import secrets
import base64
from dataclasses import dataclass, field
from pathlib import Path
from .config import OAuthConfig

@dataclass
class OAuthTokenSet:
    access_token: str = ""
    refresh_token: str | None = None
    expires_at: int | None = None
    scopes: list[str] = field(default_factory=list)

class PkceChallengeMethod:
    S256 = "S256"

@dataclass
class PkceCodePair:
    verifier: str = ""
    challenge: str = ""
    challenge_method: str = PkceChallengeMethod.S256

@dataclass
class OAuthAuthorizationRequest:
    authorize_url: str = ""
    client_id: str = ""
    redirect_uri: str = ""
    scopes: list[str] = field(default_factory=list)
    state: str = ""
    code_challenge: str = ""
    code_challenge_method: str = PkceChallengeMethod.S256
    extra_params: dict[str, str] = field(default_factory=dict)

    @staticmethod
    def from_config(config: OAuthConfig, redirect_uri: str, state: str, pkce: PkceCodePair) -> OAuthAuthorizationRequest:
        return OAuthAuthorizationRequest(authorize_url=config.authorize_url, client_id=config.client_id, redirect_uri=redirect_uri, scopes=list(config.scopes), state=state, code_challenge=pkce.challenge, code_challenge_method=pkce.challenge_method)

    def with_extra_param(self, key: str, value: str) -> OAuthAuthorizationRequest:
        self.extra_params[key] = value
        return self

    def build_url(self) -> str:
        params = [("response_type", "code"), ("client_id", self.client_id), ("redirect_uri", self.redirect_uri), ("scope", " ".join(self.scopes)), ("state", self.state), ("code_challenge", self.code_challenge), ("code_challenge_method", self.code_challenge_method)]
        params.extend(self.extra_params.items())
        query = "&".join(f"{_percent_encode(k)}={_percent_encode(v)}" for k, v in params)
        sep = "&" if "?" in self.authorize_url else "?"
        return f"{self.authorize_url}{sep}{query}"

@dataclass
class OAuthTokenExchangeRequest:
    grant_type: str = "authorization_code"
    code: str = ""
    redirect_uri: str = ""
    client_id: str = ""
    code_verifier: str = ""
    state: str = ""

    def form_params(self) -> dict[str, str]:
        return {"grant_type": self.grant_type, "code": self.code, "redirect_uri": self.redirect_uri, "client_id": self.client_id, "code_verifier": self.code_verifier, "state": self.state}

@dataclass
class OAuthRefreshRequest:
    grant_type: str = "refresh_token"
    refresh_token: str = ""
    client_id: str = ""
    scopes: list[str] = field(default_factory=list)

    def form_params(self) -> dict[str, str]:
        return {"grant_type": self.grant_type, "refresh_token": self.refresh_token, "client_id": self.client_id, "scope": " ".join(self.scopes)}

@dataclass
class OAuthCallbackParams:
    code: str | None = None
    state: str | None = None
    error: str | None = None
    error_description: str | None = None

def generate_pkce_pair() -> PkceCodePair:
    verifier = _generate_random_token(32)
    return PkceCodePair(verifier=verifier, challenge=code_challenge_s256(verifier))

def generate_state() -> str:
    return _generate_random_token(32)

def code_challenge_s256(verifier: str) -> str:
    digest = hashlib.sha256(verifier.encode("utf-8")).digest()
    return _base64url_encode(digest)

def loopback_redirect_uri(port: int) -> str:
    return f"http://localhost:{port}/callback"

def credentials_path() -> Path:
    return _credentials_home_dir() / "credentials.json"

def load_oauth_credentials() -> OAuthTokenSet | None:
    path = credentials_path()
    root = _read_credentials_root(path)
    oauth = root.get("oauth")
    if not oauth:
        return None
    return OAuthTokenSet(access_token=oauth.get("accessToken", ""), refresh_token=oauth.get("refreshToken"), expires_at=oauth.get("expiresAt"), scopes=oauth.get("scopes", []))

def save_oauth_credentials(token_set: OAuthTokenSet) -> None:
    path = credentials_path()
    root = _read_credentials_root(path)
    root["oauth"] = {"accessToken": token_set.access_token, "refreshToken": token_set.refresh_token, "expiresAt": token_set.expires_at, "scopes": token_set.scopes}
    _write_credentials_root(path, root)

def clear_oauth_credentials() -> None:
    path = credentials_path()
    root = _read_credentials_root(path)
    root.pop("oauth", None)
    _write_credentials_root(path, root)

def parse_oauth_callback_request_target(target: str) -> OAuthCallbackParams:
    path, _, query = target.partition("?")
    if path != "/callback":
        raise ValueError(f"unexpected callback path: {path}")
    return parse_oauth_callback_query(query)

def parse_oauth_callback_query(query: str) -> OAuthCallbackParams:
    params: dict[str, str] = {}
    for pair in query.split("&"):
        if not pair:
            continue
        k, _, v = pair.partition("=")
        params[_percent_decode_str(k)] = _percent_decode_str(v)
    return OAuthCallbackParams(code=params.get("code"), state=params.get("state"), error=params.get("error"), error_description=params.get("error_description"))

def _generate_random_token(n: int) -> str:
    return _base64url_encode(secrets.token_bytes(n))

def _credentials_home_dir() -> Path:
    claw = os.environ.get("CLAW_CONFIG_HOME")
    if claw:
        return Path(claw)
    home = os.environ.get("HOME", ".")
    return Path(home) / ".claw"

def _read_credentials_root(path: Path) -> dict:
    try:
        content = path.read_text().strip()
        if not content:
            return {}
        return _json.loads(content)
    except (FileNotFoundError, _json.JSONDecodeError):
        return {}

def _write_credentials_root(path: Path, root: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(_json.dumps(root, indent=2) + "\n")
    tmp.rename(path)

def _base64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")

def _percent_encode(value: str) -> str:
    safe = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~")
    return "".join(c if c in safe else f"%{ord(c):02X}" for c in value)

def _percent_decode_str(value: str) -> str:
    result: list[int] = []
    b = value.encode("ascii", errors="replace")
    i = 0
    while i < len(b):
        if b[i:i+1] == b"%" and i + 2 < len(b):
            try:
                result.append(int(value[i+1:i+3], 16))
                i += 3
                continue
            except ValueError:
                pass
        if b[i:i+1] == b"+":
            result.append(32)
        else:
            result.append(b[i])
        i += 1
    return bytes(result).decode("utf-8", errors="replace")
