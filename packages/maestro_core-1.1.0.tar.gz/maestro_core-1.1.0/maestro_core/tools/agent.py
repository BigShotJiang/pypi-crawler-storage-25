"""Agent tool — spawn sub-agents for parallel/complex tasks.

Supports optional worktree isolation to prevent file conflicts between
concurrent agents working on the same repo.

Also provides TeamTool for running multiple sub-agents concurrently."""
from __future__ import annotations
import asyncio
import os
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any
from maestro_core.tools.base import Tool, ToolResult, RiskLevel


class AgentTool(Tool):
    """Spawns a sub-agent to handle a complex task autonomously.

    The sub-agent gets its own conversation context, tools, and can
    work independently. Results are returned when complete.

    With isolation='worktree', the agent runs in a git worktree (isolated
    copy of the repo) to prevent file conflicts with the main workspace."""

    name = "agent"
    description = (
        "Launch a sub-agent to handle a complex, multi-step task autonomously. "
        "The agent gets its own context and tools. Use for tasks that require "
        "multiple tool calls or deep research. Returns the agent's final response. "
        "Set isolation='worktree' to run in an isolated git worktree."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "The task for the sub-agent to perform"
            },
            "description": {
                "type": "string",
                "description": "A short (3-5 word) description of what the agent will do"
            },
            "isolation": {
                "type": "string",
                "enum": ["none", "worktree"],
                "description": "Isolation mode. 'worktree' runs in a git worktree.",
                "default": "none"
            },
        },
        "required": ["prompt"]
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(self, parent_router=None, parent_tools=None, parent_system_prompt="", model=""):
        """Initialize with parent context for spawning sub-agents.

        Args:
            parent_router: ProviderRouter from parent
            parent_tools: ToolRegistry from parent (shared tools)
            parent_system_prompt: system prompt for sub-agents
            model: model to use for sub-agents
        """
        self._router = parent_router
        self._tools = parent_tools
        self._system_prompt = parent_system_prompt
        self._model = model

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        prompt = args.get("prompt", "")
        description = args.get("description", "agent task")
        isolation = args.get("isolation", "none")

        if not prompt:
            return ToolResult(content="prompt is required", is_error=True)

        if not self._router:
            return ToolResult(content="Agent tool not configured (no router)", is_error=True)

        # Setup worktree if requested
        worktree_path: Path | None = None
        branch_name: str | None = None
        original_cwd = os.getcwd()

        if isolation == "worktree":
            worktree_result = _create_worktree()
            if worktree_result.is_error:
                return ToolResult(content=worktree_result.error, is_error=True)
            worktree_path = worktree_result.path
            branch_name = worktree_result.branch
            os.chdir(str(worktree_path))

        try:
            result = await self._run_sub_agent(prompt, description)
        finally:
            if worktree_path:
                os.chdir(original_cwd)

        # Handle worktree cleanup
        if worktree_path and branch_name:
            has_changes = _worktree_has_changes(worktree_path)
            if has_changes:
                result.metadata = result.metadata or {}
                result.metadata["worktree_path"] = str(worktree_path)
                result.metadata["worktree_branch"] = branch_name
                result.content += (
                    f"\n\n[Worktree isolation: changes detected]\n"
                    f"  Branch: {branch_name}\n"
                    f"  Path: {worktree_path}\n"
                    f"  Review with: git diff {branch_name}\n"
                    f"  Merge with: git merge {branch_name}"
                )
            else:
                _cleanup_worktree(worktree_path)
                result.content += "\n\n[Worktree isolation: no changes, cleaned up]"

        return result

    async def _run_sub_agent(self, prompt: str, description: str) -> ToolResult:
        """Run the sub-agent engine and return the result."""
        try:
            # Import here to avoid circular imports
            from maestro_core.engine import ConversationEngine
            from maestro_core.tools.base import ToolRegistry

            # Create a sub-registry with all tools except 'agent' to prevent infinite recursion
            sub_tools = ToolRegistry()
            if self._tools:
                for name, tool in self._tools.tools.items():
                    if name != "agent":
                        sub_tools.register(tool)

            sub_engine = ConversationEngine(
                router=self._router,
                tools=sub_tools,
                max_tokens=4096,
                max_turns=15,  # Limit sub-agent turns
            )

            start = time.time()
            result = await sub_engine.run_turn(
                user_text=prompt,
                system_prompt=self._system_prompt,
                model=self._model,
            )
            elapsed = time.time() - start

            response = result.response_text or "<no response>"
            tools_used = len(result.tool_calls)

            summary = (
                f"[Agent: {description}]\n"
                f"Result ({result.turn_count} turns, {tools_used} tools, {elapsed:.1f}s):\n\n"
                f"{response}"
            )

            return ToolResult(
                content=summary,
                metadata={
                    "turns": result.turn_count,
                    "tools_used": tools_used,
                    "duration_s": elapsed,
                }
            )

        except Exception as e:
            return ToolResult(content=f"Agent error: {e}", is_error=True)


class TeamTool(Tool):
    """Create a team of agents that work on sub-tasks in parallel."""

    name = "team"
    description = (
        "Create a team of sub-agents that work on different sub-tasks simultaneously. "
        "Each agent gets its own context. Results are collected when all complete."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "tasks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "prompt": {"type": "string"},
                    },
                    "required": ["name", "prompt"]
                },
                "description": "List of tasks to distribute to agents"
            }
        },
        "required": ["tasks"]
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(self, parent_router=None, parent_tools=None, parent_system_prompt="", model=""):
        """Initialize with parent context for spawning sub-agents.

        Args:
            parent_router: ProviderRouter from parent
            parent_tools: ToolRegistry from parent (shared tools)
            parent_system_prompt: system prompt for sub-agents
            model: model to use for sub-agents
        """
        self._router = parent_router
        self._tools = parent_tools
        self._system_prompt = parent_system_prompt
        self._model = model

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        tasks = args.get("tasks", [])
        if not tasks:
            return ToolResult(content="tasks list is required and must not be empty", is_error=True)

        if not self._router:
            return ToolResult(content="Team tool not configured (no router)", is_error=True)

        start = time.time()

        # Run all tasks concurrently
        coros = [self._run_single(task) for task in tasks]
        results = await asyncio.gather(*coros, return_exceptions=True)

        elapsed = time.time() - start

        # Collect results into a combined summary
        parts: list[str] = []
        total_turns = 0
        total_tools = 0
        errors = 0

        for i, (task, result) in enumerate(zip(tasks, results)):
            task_name = task.get("name", f"task-{i}")
            if isinstance(result, Exception):
                parts.append(f"### {task_name}\n**Error:** {result}\n")
                errors += 1
            elif result.is_error:
                parts.append(f"### {task_name}\n**Error:** {result.content}\n")
                errors += 1
            else:
                parts.append(f"### {task_name}\n{result.content}\n")
                if result.metadata:
                    total_turns += result.metadata.get("turns", 0)
                    total_tools += result.metadata.get("tools_used", 0)

        summary = (
            f"[Team: {len(tasks)} agents, {elapsed:.1f}s, "
            f"{total_turns} total turns, {total_tools} total tools"
            f"{f', {errors} errors' if errors else ''}]\n\n"
            + "\n".join(parts)
        )

        return ToolResult(
            content=summary,
            metadata={
                "agent_count": len(tasks),
                "total_turns": total_turns,
                "total_tools": total_tools,
                "errors": errors,
                "duration_s": elapsed,
            }
        )

    async def _run_single(self, task: dict) -> ToolResult:
        """Run a single sub-agent for one task."""
        try:
            from maestro_core.engine import ConversationEngine
            from maestro_core.tools.base import ToolRegistry

            # Create a sub-registry without agent/team to prevent recursion
            sub_tools = ToolRegistry()
            if self._tools:
                for name, tool in self._tools.tools.items():
                    if name not in ("agent", "team"):
                        sub_tools.register(tool)

            sub_engine = ConversationEngine(
                router=self._router,
                tools=sub_tools,
                max_tokens=4096,
                max_turns=15,
            )

            task_name = task.get("name", "unnamed")
            prompt = task.get("prompt", "")

            start = time.time()
            result = await sub_engine.run_turn(
                user_text=prompt,
                system_prompt=self._system_prompt,
                model=self._model,
            )
            elapsed = time.time() - start

            response = result.response_text or "<no response>"
            tools_used = len(result.tool_calls)

            content = (
                f"Result ({result.turn_count} turns, {tools_used} tools, {elapsed:.1f}s):\n\n"
                f"{response}"
            )

            return ToolResult(
                content=content,
                metadata={
                    "turns": result.turn_count,
                    "tools_used": tools_used,
                    "duration_s": elapsed,
                }
            )
        except Exception as e:
            return ToolResult(content=f"Agent error ({task.get('name', 'unnamed')}): {e}", is_error=True)


# ── Worktree helpers ──


class _WorktreeResult:
    """Result of creating a git worktree."""
    def __init__(self, path: Path | None = None, branch: str | None = None, error: str | None = None):
        self.path = path
        self.branch = branch
        self.error = error
        self.is_error = error is not None


def _create_worktree() -> _WorktreeResult:
    """Create a temporary git worktree for isolated agent work."""
    uid = uuid.uuid4().hex[:8]
    branch_name = f"maestro-agent-{uid}"
    worktree_path = Path(f"/tmp/maestro-worktree-{uid}")

    try:
        # Verify we're in a git repo
        check = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True, text=True, timeout=5,
        )
        if check.returncode != 0:
            return _WorktreeResult(error="Not in a git repository. Worktree isolation requires git.")

        # Create worktree with new branch
        result = subprocess.run(
            ["git", "worktree", "add", str(worktree_path), "-b", branch_name],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            return _WorktreeResult(error=f"Failed to create worktree: {result.stderr.strip()}")

        return _WorktreeResult(path=worktree_path, branch=branch_name)

    except subprocess.TimeoutExpired:
        return _WorktreeResult(error="Git worktree creation timed out")
    except FileNotFoundError:
        return _WorktreeResult(error="git not found in PATH")


def _worktree_has_changes(worktree_path: Path) -> bool:
    """Check if a worktree has uncommitted or new changes."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=10,
            cwd=str(worktree_path),
        )
        return bool(result.stdout.strip())
    except Exception:
        return False


def _cleanup_worktree(worktree_path: Path) -> None:
    """Remove a worktree and its branch."""
    try:
        # Extract branch name from worktree path
        subprocess.run(
            ["git", "worktree", "remove", str(worktree_path), "--force"],
            capture_output=True, text=True, timeout=15,
        )
    except Exception:
        pass
