"""Tool execution dispatch — synchronous execution for all built-in tools.

Adapted from src/tools/execution.py with maestro_core imports.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any


def execute_tool_dispatch(name: str, input_data: dict[str, Any]) -> str:
    """Main dispatch for synchronous tool execution."""
    handlers = {
        "bash": _run_bash,
        "read_file": _run_read_file,
        "write_file": _run_write_file,
        "edit_file": _run_edit_file,
        "glob_search": _run_glob_search,
        "grep_search": _run_grep_search,
        "WebFetch": _run_web_fetch,
        "WebSearch": _run_web_search,
        "TodoWrite": _run_todo_write,
        "Skill": _run_skill,
        "Agent": _run_agent,
        "ToolSearch": _run_tool_search,
        "NotebookEdit": _run_notebook_edit,
        "Sleep": _run_sleep,
        "SendUserMessage": _run_brief,
        "Config": _run_config,
        "EnterPlanMode": _run_enter_plan_mode,
        "ExitPlanMode": _run_exit_plan_mode,
        "StructuredOutput": _run_structured_output,
        "REPL": _run_repl,
        "PowerShell": _run_powershell,
        "AskUserQuestion": _run_ask_user_question,
        "TaskCreate": _run_task_stub,
        "TaskGet": _run_task_stub,
        "TaskList": _run_task_stub,
        "TaskStop": _run_task_stub,
        "TaskUpdate": _run_task_stub,
        "TaskOutput": _run_task_stub,
        "WorkerCreate": _run_task_stub,
        "WorkerGet": _run_task_stub,
        "WorkerObserve": _run_task_stub,
        "WorkerResolveTrust": _run_task_stub,
        "WorkerAwaitReady": _run_task_stub,
        "WorkerSendPrompt": _run_task_stub,
        "WorkerRestart": _run_task_stub,
        "WorkerTerminate": _run_task_stub,
        "TeamCreate": _run_task_stub,
        "TeamDelete": _run_task_stub,
        "CronCreate": _run_task_stub,
        "CronDelete": _run_task_stub,
        "CronList": _run_task_stub,
        "LSP": _run_task_stub,
        "ListMcpResources": _run_task_stub,
        "ReadMcpResource": _run_task_stub,
        "McpAuth": _run_task_stub,
        "RemoteTrigger": _run_remote_trigger,
        "MCP": _run_task_stub,
        "TestingPermission": _run_testing_permission,
    }

    handler = handlers.get(name)
    if handler is None:
        raise ValueError(f"unsupported tool: {name}")
    return handler(input_data)


def _to_pretty_json(value: Any) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False)


# --- Implementations ---


def _run_bash(input_data: dict[str, Any]) -> str:
    command = input_data["command"]
    timeout = input_data.get("timeout")

    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=timeout, cwd=os.getcwd(),
        )
        return _to_pretty_json({
            "stdout": result.stdout,
            "stderr": result.stderr,
            "exit_code": result.returncode,
        })
    except subprocess.TimeoutExpired:
        return _to_pretty_json({
            "stdout": "", "stderr": f"Command timed out after {timeout}s", "exit_code": -1,
        })
    except Exception as e:
        return _to_pretty_json({"stdout": "", "stderr": str(e), "exit_code": -1})


def _run_read_file(input_data: dict[str, Any]) -> str:
    path = input_data["path"]
    offset = input_data.get("offset", 0)
    limit = input_data.get("limit")

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        if offset:
            lines = lines[offset:]
        if limit:
            lines = lines[:limit]

        numbered = ""
        for i, line in enumerate(lines, start=offset + 1):
            numbered += f"{i}\t{line}"

        return _to_pretty_json({"content": numbered, "path": path, "lines": len(lines)})
    except Exception as e:
        raise ValueError(str(e))


def _run_write_file(input_data: dict[str, Any]) -> str:
    path = input_data["path"]
    content = input_data["content"]

    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return _to_pretty_json({"path": path, "bytes_written": len(content.encode("utf-8"))})
    except Exception as e:
        raise ValueError(str(e))


def _run_edit_file(input_data: dict[str, Any]) -> str:
    path = input_data["path"]
    old_string = input_data["old_string"]
    new_string = input_data["new_string"]
    replace_all = input_data.get("replace_all", False)

    try:
        content = Path(path).read_text(encoding="utf-8")
        if old_string not in content:
            raise ValueError(f"old_string not found in {path}")

        if replace_all:
            new_content = content.replace(old_string, new_string)
            count = content.count(old_string)
        else:
            if content.count(old_string) > 1:
                raise ValueError(
                    f"old_string appears {content.count(old_string)} times in {path}; "
                    "use replace_all=true or provide a more specific string"
                )
            new_content = content.replace(old_string, new_string, 1)
            count = 1

        Path(path).write_text(new_content, encoding="utf-8")
        return _to_pretty_json({"path": path, "replacements": count})
    except Exception as e:
        raise ValueError(str(e))


def _run_glob_search(input_data: dict[str, Any]) -> str:
    import glob

    pattern = input_data["pattern"]
    base_path = input_data.get("path", ".")

    try:
        full_pattern = os.path.join(base_path, pattern) if not os.path.isabs(pattern) else pattern
        matches = sorted(glob.glob(full_pattern, recursive=True))
        return _to_pretty_json({"matches": matches, "count": len(matches)})
    except Exception as e:
        raise ValueError(str(e))


def _run_grep_search(input_data: dict[str, Any]) -> str:
    import re

    pattern = input_data["pattern"]
    path = input_data.get("path", ".")

    try:
        regex = re.compile(pattern, re.IGNORECASE if input_data.get("-i") else 0)
        matches: list[dict[str, Any]] = []
        base = Path(path)

        if base.is_file():
            files = [base]
        else:
            files = sorted(base.rglob("*"))

        for file_path in files:
            if not file_path.is_file():
                continue
            try:
                text = file_path.read_text(encoding="utf-8", errors="replace")
                for i, line in enumerate(text.splitlines(), 1):
                    if regex.search(line):
                        matches.append({"file": str(file_path), "line": i, "content": line})
            except (OSError, UnicodeDecodeError):
                continue

        head_limit = input_data.get("head_limit", 250)
        if head_limit:
            matches = matches[:head_limit]

        return _to_pretty_json({"matches": matches, "count": len(matches)})
    except Exception as e:
        raise ValueError(str(e))


def _run_web_fetch(input_data: dict[str, Any]) -> str:
    import urllib.request

    url = input_data["url"]
    prompt = input_data["prompt"]
    started = time.time()

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "maestro-tools/0.1"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            code = resp.status
    except Exception as e:
        return _to_pretty_json({"url": url, "error": str(e), "code": 0})

    duration_ms = int((time.time() - started) * 1000)
    preview = body[:900] if len(body) > 900 else body

    return _to_pretty_json({
        "url": url, "bytes": len(body), "code": code,
        "codeText": "OK" if 200 <= code < 300 else "Error",
        "result": f"Fetched {url}\nPrompt: {prompt}\n{preview}",
        "durationMs": duration_ms,
    })


def _run_web_search(input_data: dict[str, Any]) -> str:
    query = input_data["query"]
    return _to_pretty_json({
        "query": query, "results": [], "durationSeconds": 0.0,
        "message": f"Web search for: {query}",
    })


def _run_todo_write(input_data: dict[str, Any]) -> str:
    todos = input_data.get("todos", [])
    if not todos:
        raise ValueError("todos must not be empty")

    store_path = os.environ.get("CLAWD_TODO_STORE", os.path.join(os.getcwd(), ".clawd-todos.json"))
    old_todos: list[Any] = []
    if os.path.exists(store_path):
        try:
            old_todos = json.loads(Path(store_path).read_text())
        except (json.JSONDecodeError, OSError):
            pass

    all_done = all(t.get("status") == "completed" for t in todos)
    persisted = [] if all_done else todos
    Path(store_path).parent.mkdir(parents=True, exist_ok=True)
    Path(store_path).write_text(json.dumps(persisted, indent=2))

    return _to_pretty_json({"oldTodos": old_todos, "newTodos": todos})


def _run_skill(input_data: dict[str, Any]) -> str:
    skill = input_data["skill"]
    args = input_data.get("args")

    candidates = []
    codex_home = os.environ.get("CODEX_HOME")
    home = os.environ.get("HOME", "")

    if codex_home:
        candidates.append(os.path.join(codex_home, "skills"))
    if home:
        candidates.extend([
            os.path.join(home, ".codex", "skills"),
            os.path.join(home, ".claude", "skills"),
        ])

    requested = skill.strip().lstrip("/").lstrip("$")
    for root in candidates:
        direct = os.path.join(root, requested, "SKILL.md")
        if os.path.exists(direct):
            prompt = Path(direct).read_text(encoding="utf-8")
            return _to_pretty_json({"skill": skill, "path": direct, "args": args, "prompt": prompt})

    raise ValueError(f"unknown skill: {requested}")


def _run_agent(input_data: dict[str, Any]) -> str:
    description = input_data["description"]
    prompt = input_data["prompt"]

    if not description.strip():
        raise ValueError("description must not be empty")
    if not prompt.strip():
        raise ValueError("prompt must not be empty")

    agent_id = f"agent-{int(time.time() * 1e9)}"
    return _to_pretty_json({
        "agentId": agent_id,
        "name": description[:32].lower().replace(" ", "-"),
        "description": description,
        "status": "running",
        "createdAt": str(int(time.time())),
    })


def _run_tool_search(input_data: dict[str, Any]) -> str:
    from maestro_core.tools.registry import GlobalToolRegistry
    registry = GlobalToolRegistry.builtin()
    result = registry.search(input_data["query"], input_data.get("max_results", 5))
    return _to_pretty_json({
        "matches": result.matches,
        "query": result.query,
        "normalized_query": result.normalized_query,
        "total_deferred_tools": result.total_deferred_tools,
    })


def _run_notebook_edit(input_data: dict[str, Any]) -> str:
    path = input_data["notebook_path"]
    if not path.endswith(".ipynb"):
        raise ValueError("File must be a Jupyter notebook (.ipynb file).")

    original = Path(path).read_text()
    notebook = json.loads(original)
    return _to_pretty_json({
        "notebook_path": path,
        "edit_mode": input_data.get("edit_mode", "replace"),
        "original_file": original[:200],
    })


def _run_sleep(input_data: dict[str, Any]) -> str:
    duration_ms = input_data["duration_ms"]
    max_sleep = 300_000
    if duration_ms > max_sleep:
        raise ValueError(f"duration_ms {duration_ms} exceeds maximum allowed sleep of {max_sleep}ms")
    time.sleep(duration_ms / 1000.0)
    return _to_pretty_json({"duration_ms": duration_ms, "message": f"Slept for {duration_ms}ms"})


def _run_brief(input_data: dict[str, Any]) -> str:
    message = input_data["message"]
    if not message.strip():
        raise ValueError("message must not be empty")
    return _to_pretty_json({"message": message, "sentAt": str(int(time.time()))})


def _run_config(input_data: dict[str, Any]) -> str:
    setting = input_data["setting"].strip()
    if not setting:
        raise ValueError("setting must not be empty")
    value = input_data.get("value")

    if value is not None:
        return _to_pretty_json({"success": True, "operation": "set", "setting": setting, "value": value})
    return _to_pretty_json({"success": True, "operation": "get", "setting": setting, "value": None})


def _run_enter_plan_mode(input_data: dict[str, Any]) -> str:
    return _to_pretty_json({"success": True, "operation": "enter", "active": True})


def _run_exit_plan_mode(input_data: dict[str, Any]) -> str:
    return _to_pretty_json({"success": True, "operation": "exit", "active": False})


def _run_structured_output(input_data: dict[str, Any]) -> str:
    if not input_data:
        raise ValueError("structured output payload must not be empty")
    return _to_pretty_json({"data": "Structured output provided successfully", "structured_output": input_data})


def _run_repl(input_data: dict[str, Any]) -> str:
    code = input_data["code"].strip()
    language = input_data["language"].strip().lower()
    timeout_ms = input_data.get("timeout_ms")

    if not code:
        raise ValueError("code must not be empty")

    runtime_map = {
        "python": (["python3", "-c", code], ["python", "-c", code]),
        "py": (["python3", "-c", code], ["python", "-c", code]),
        "javascript": (["node", "-e", code],),
        "js": (["node", "-e", code],),
        "node": (["node", "-e", code],),
        "sh": (["bash", "-lc", code], ["sh", "-lc", code]),
        "bash": (["bash", "-lc", code],),
        "shell": (["bash", "-lc", code], ["sh", "-lc", code]),
    }

    cmds = runtime_map.get(language)
    if not cmds:
        raise ValueError(f"unsupported REPL language: {language}")

    started = time.time()
    timeout_s = timeout_ms / 1000.0 if timeout_ms else None

    for cmd in cmds:
        if shutil.which(cmd[0]) is None:
            continue
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
            duration_ms = int((time.time() - started) * 1000)
            return _to_pretty_json({
                "language": language, "stdout": result.stdout,
                "stderr": result.stderr, "exitCode": result.returncode,
                "durationMs": duration_ms,
            })
        except subprocess.TimeoutExpired:
            raise ValueError(f"REPL execution exceeded timeout of {timeout_ms} ms")

    raise ValueError(f"{language} runtime not found")


def _run_powershell(input_data: dict[str, Any]) -> str:
    command = input_data["command"]
    timeout = input_data.get("timeout")

    try:
        result = subprocess.run(
            ["pwsh", "-Command", command] if shutil.which("pwsh") else ["powershell", "-Command", command],
            capture_output=True, text=True, timeout=timeout,
        )
        return _to_pretty_json({"stdout": result.stdout, "stderr": result.stderr, "exit_code": result.returncode})
    except Exception as e:
        raise ValueError(str(e))


def _run_ask_user_question(input_data: dict[str, Any]) -> str:
    question = input_data["question"]
    options = input_data.get("options")

    print(f"\n[Question] {question}")
    if options:
        for i, opt in enumerate(options, 1):
            print(f"  {i}. {opt}")
        response = input(f"Enter choice (1-{len(options)}): ").strip()
    else:
        response = input("Your answer: ").strip()

    answer = response
    if options:
        try:
            idx = int(response)
            if 1 <= idx <= len(options):
                answer = options[idx - 1]
        except ValueError:
            pass

    return _to_pretty_json({"question": question, "answer": answer, "status": "answered"})


def _run_remote_trigger(input_data: dict[str, Any]) -> str:
    import urllib.request

    url = input_data["url"]
    method = input_data.get("method", "GET").upper()
    body = input_data.get("body")
    headers_dict = input_data.get("headers", {})

    try:
        data = body.encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, method=method)
        for k, v in headers_dict.items():
            if isinstance(v, str):
                req.add_header(k, v)

        with urllib.request.urlopen(req, timeout=30) as resp:
            response_body = resp.read().decode("utf-8", errors="replace")
            status_code = resp.status
    except Exception as e:
        return _to_pretty_json({"url": url, "method": method, "error": str(e), "success": False})

    truncated = response_body[:8192] if len(response_body) > 8192 else response_body
    return _to_pretty_json({
        "url": url, "method": method, "status_code": status_code,
        "body": truncated, "success": 200 <= status_code < 300,
    })


def _run_testing_permission(input_data: dict[str, Any]) -> str:
    return _to_pretty_json({
        "action": input_data.get("action", ""),
        "permitted": True,
        "message": "Testing permission tool stub",
    })


def _run_task_stub(input_data: dict[str, Any]) -> str:
    """Stub for tools that depend on the full runtime (task, worker, team, cron, etc.)."""
    return _to_pretty_json({
        "status": "not_implemented",
        "message": "This tool requires the full runtime registry. Input received.",
        "input": input_data,
    })
