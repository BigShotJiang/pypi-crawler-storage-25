"""WebFetchTool — fetches a URL and returns readable text."""

from __future__ import annotations

import time
import urllib.request
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class WebFetchTool(Tool):
    name = "web_fetch"
    description = (
        "Fetch a URL, convert it into readable text, and return the content. "
        "Returns up to 900 characters of preview."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "format": "uri",
                "description": "URL to fetch.",
            },
            "prompt": {
                "type": "string",
                "description": "What to look for in the page content.",
            },
        },
        "required": ["url", "prompt"],
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        url = args["url"]
        prompt = args["prompt"]
        started = time.time()

        try:
            req = urllib.request.Request(url, headers={"User-Agent": "maestro-tools/0.1"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                code = resp.status
        except Exception as e:
            return ToolResult(
                content=f"Failed to fetch {url}: {e}",
                is_error=True,
                metadata={"url": url, "code": 0},
            )

        duration_ms = int((time.time() - started) * 1000)
        preview = body[:900] if len(body) > 900 else body

        return ToolResult(
            content=f"Fetched {url}\nPrompt: {prompt}\n{preview}",
            metadata={"url": url, "bytes": len(body), "code": code, "durationMs": duration_ms},
        )
