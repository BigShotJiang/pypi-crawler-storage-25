"""MORPHEUS tools — intégration beads et snapshots dans Maestro.

Permet au LLM d'accéder aux beads MORPHEUS pour comprendre le contexte
des tâches en cours et marquer les beads comme terminés."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from maestro_core.tools.base import Tool, ToolResult, RiskLevel

# Chemin vers les roadmap beads
MORPHEUS_ROOT = Path.home() / "MORPHEUS"
BEAD_FILES = [
    MORPHEUS_ROOT / "roadmap" / "oke-beads-paie.md",
    MORPHEUS_ROOT / "roadmap" / "oke-beads-paie-v2.md",
    MORPHEUS_ROOT / "roadmap" / "oke-beads-paie-v3.md",
    MORPHEUS_ROOT / "roadmap" / "maestro-v1-final.md",
    MORPHEUS_ROOT / "roadmap" / "maestro-convergence.md",
]


class BeadListTool(Tool):
    """Liste les beads MORPHEUS (micro-tâches) avec leur statut."""

    name = "morpheus_beads"
    description = (
        "List MORPHEUS beads (micro-tasks) from the roadmap files. "
        "Shows pending, in-progress, and completed beads with priorities."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "project": {
                "type": "string",
                "description": "Filter by project (OKE, MORPHEUS, MAESTRO, all)",
                "default": "all",
            },
            "status": {
                "type": "string",
                "description": "Filter by status (pending, completed, all)",
                "default": "pending",
            },
        },
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        project_filter = args.get("project", "all").lower()
        status_filter = args.get("status", "pending").lower()

        beads = []
        for path in BEAD_FILES:
            if not path.exists():
                continue
            content = path.read_text()
            file_beads = _parse_beads_from_markdown(content, path.name)
            beads.extend(file_beads)

        # Filter
        if project_filter != "all":
            beads = [b for b in beads if project_filter in b["file"].lower()]
        if status_filter == "pending":
            beads = [b for b in beads if not b["done"]]
        elif status_filter == "completed":
            beads = [b for b in beads if b["done"]]

        if not beads:
            return ToolResult(content="Aucun bead trouvé avec ces filtres.")

        lines = [f"{len(beads)} beads ({status_filter}):"]
        for b in beads[:30]:
            status = "✓" if b["done"] else "○"
            lines.append(f"  {status} {b['id']} — {b['title']}")

        if len(beads) > 30:
            lines.append(f"  ... et {len(beads) - 30} de plus")

        return ToolResult(content="\n".join(lines))


class SnapshotTool(Tool):
    """Capture un snapshot de l'état du projet via le skill MORPHEUS."""

    name = "morpheus_snapshot"
    description = (
        "Capture a snapshot of the current project state using the MORPHEUS skill. "
        "Shows git status, running services, recent changes."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "project": {
                "type": "string",
                "description": "Project to snapshot (OKE, MORPHEUS, MAESTRO)",
                "default": "MORPHEUS",
            },
        },
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        project = args.get("project", "MORPHEUS")
        skill_path = MORPHEUS_ROOT / "skills" / "session-snapshot.sh"

        if not skill_path.exists():
            return ToolResult(
                content=f"Skill session-snapshot.sh not found at {skill_path}",
                is_error=True,
            )

        try:
            result = subprocess.run(
                ["bash", str(skill_path), project],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=str(MORPHEUS_ROOT),
            )
            output = result.stdout.strip()
            if result.returncode != 0:
                output += f"\nSTDERR: {result.stderr.strip()}"
            return ToolResult(content=output[:10000])
        except subprocess.TimeoutExpired:
            return ToolResult(content="Snapshot timeout (30s)", is_error=True)
        except Exception as e:
            return ToolResult(content=str(e), is_error=True)


def _parse_beads_from_markdown(content: str, filename: str) -> list[dict]:
    """Parse les beads depuis un fichier markdown (format checklist)."""
    beads = []
    for line in content.splitlines():
        line = line.strip()
        # Format: - [ ] **MAE-01** — Description
        # Format: - [x] **MAE-01** — Description
        if line.startswith("- ["):
            done = line[3] == "x"
            rest = line[6:].strip()

            # Extract bead ID (bold)
            bead_id = ""
            title = rest
            if "**" in rest:
                parts = rest.split("**")
                if len(parts) >= 3:
                    bead_id = parts[1]
                    title = "**".join(parts[2:]).strip()
                    if title.startswith("—") or title.startswith("-"):
                        title = title[1:].strip()

            beads.append({
                "id": bead_id or f"#{len(beads)+1}",
                "title": title[:200],
                "done": done,
                "file": filename,
            })
    return beads
