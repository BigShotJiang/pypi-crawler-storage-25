"""Tool specifications — ToolSpec dataclass and PermissionMode enum.

Translated from src/tools/registry.py, adapted to coexist with
the maestro_core Tool/ToolRegistry framework.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class PermissionMode(Enum):
    """Permission mode for a tool spec."""

    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"
    DANGER_FULL_ACCESS = "danger-full-access"


@dataclass
class ToolSpec:
    """Specification of a tool with its JSON schema and permission level."""

    name: str
    description: str
    input_schema: dict[str, Any]
    required_permission: PermissionMode
