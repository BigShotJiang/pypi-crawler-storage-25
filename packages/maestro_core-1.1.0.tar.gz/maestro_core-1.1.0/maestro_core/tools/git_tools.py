"""Git tools — provide git context to the LLM."""

from __future__ import annotations

import subprocess
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class GitStatusTool(Tool):
    name = "git_status"
    description = "Shows the current git status (branch, staged, unstaged, untracked files)"
    input_schema: dict[str, Any] = {"type": "object", "properties": {}, "required": []}
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain", "-b"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git status failed: {result.stderr.strip()}",
                    is_error=True,
                )

            lines = result.stdout.strip().splitlines()
            if not lines:
                return ToolResult(content="Not a git repository or empty output.")

            # Parse branch line
            branch_line = lines[0] if lines[0].startswith("## ") else ""
            file_lines = [l for l in lines if not l.startswith("## ")]

            staged = []
            unstaged = []
            untracked = []

            for line in file_lines:
                if len(line) < 2:
                    continue
                idx_status = line[0]
                wt_status = line[1]
                filename = line[3:]

                if idx_status == "?" and wt_status == "?":
                    untracked.append(filename)
                else:
                    if idx_status not in (" ", "?"):
                        staged.append(f"{idx_status} {filename}")
                    if wt_status not in (" ", "?"):
                        unstaged.append(f"{wt_status} {filename}")

            parts = []
            if branch_line:
                parts.append(f"Branch: {branch_line[3:]}")
            if staged:
                parts.append(f"\nStaged ({len(staged)}):")
                parts.extend(f"  {s}" for s in staged)
            if unstaged:
                parts.append(f"\nUnstaged ({len(unstaged)}):")
                parts.extend(f"  {u}" for u in unstaged)
            if untracked:
                parts.append(f"\nUntracked ({len(untracked)}):")
                parts.extend(f"  {u}" for u in untracked)
            if not staged and not unstaged and not untracked:
                parts.append("Working tree clean.")

            return ToolResult(content="\n".join(parts))

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git status timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitDiffTool(Tool):
    name = "git_diff"
    description = "Shows git diff of staged or unstaged changes"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "staged": {
                "type": "boolean",
                "description": "Show staged changes (--cached)",
                "default": False,
            },
            "file": {
                "type": "string",
                "description": "Specific file to diff (optional)",
            },
        },
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        try:
            cmd = ["git", "diff"]
            if args.get("staged", False):
                cmd.append("--cached")
            if args.get("file"):
                cmd.append("--")
                cmd.append(args["file"])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git diff failed: {result.stderr.strip()}",
                    is_error=True,
                )

            output = result.stdout.strip()
            if not output:
                label = "staged" if args.get("staged") else "unstaged"
                return ToolResult(content=f"No {label} changes.")

            # Truncate if very large
            if len(output) > 20_000:
                output = output[:20_000] + "\n\n... (truncated, diff too large)"

            return ToolResult(content=output)

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git diff timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitLogTool(Tool):
    name = "git_log"
    description = "Shows recent git commit history"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "count": {
                "type": "integer",
                "description": "Number of commits to show",
                "default": 10,
            },
            "oneline": {
                "type": "boolean",
                "description": "One line per commit",
                "default": True,
            },
        },
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        try:
            count = args.get("count", 10)
            oneline = args.get("oneline", True)

            cmd = ["git", "log", f"-{count}"]
            if oneline:
                cmd.append("--oneline")
            else:
                cmd.extend(["--format=%h %s (%an, %ar)"])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git log failed: {result.stderr.strip()}",
                    is_error=True,
                )

            output = result.stdout.strip()
            if not output:
                return ToolResult(content="No commits found.")

            return ToolResult(content=output)

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git log timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitAddTool(Tool):
    name = "git_add"
    description = "Stage files for the next git commit"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "files": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Files to stage. Use ['.'] to stage all changes.",
            },
        },
        "required": ["files"],
    }
    risk_level = RiskLevel.MEDIUM

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        files = args.get("files", [])
        if not files:
            return ToolResult(content="No files specified.", is_error=True)

        try:
            cmd = ["git", "add"] + files
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git add failed: {result.stderr.strip()}",
                    is_error=True,
                )

            # Show what was staged
            status = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            staged = [
                l[3:] for l in status.stdout.strip().splitlines()
                if len(l) >= 2 and l[0] not in (" ", "?")
            ]
            return ToolResult(
                content=f"Staged {len(staged)} file(s):\n" + "\n".join(f"  {f}" for f in staged),
            )

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git add timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitCommitTool(Tool):
    name = "git_commit"
    description = "Create a git commit with staged changes"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "message": {
                "type": "string",
                "description": "Commit message",
            },
            "files": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Files to stage before committing (optional, commits staged changes if empty)",
            },
        },
        "required": ["message"],
    }
    risk_level = RiskLevel.MEDIUM

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        message = args.get("message", "")
        files = args.get("files", [])

        if not message.strip():
            return ToolResult(content="Commit message cannot be empty.", is_error=True)

        try:
            # Stage files if specified
            if files:
                for f in files:
                    result = subprocess.run(
                        ["git", "add", f],
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )
                    if result.returncode != 0:
                        return ToolResult(
                            content=f"git add {f} failed: {result.stderr.strip()}",
                            is_error=True,
                        )

            # Commit
            result = subprocess.run(
                ["git", "commit", "-m", message],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return ToolResult(
                    content=f"git commit failed: {result.stderr.strip()}",
                    is_error=True,
                )

            return ToolResult(content=result.stdout.strip())

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git commit timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)
