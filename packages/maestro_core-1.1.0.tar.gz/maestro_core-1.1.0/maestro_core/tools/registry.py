"""Global tool registry with specs, search, and dispatch.

Adapted from src/tools/registry.py — uses maestro_core imports.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from maestro_core.tools.specs import ToolSpec, PermissionMode
from maestro_core.tools.spec_bash import BASH_TOOL_SPEC
from maestro_core.tools.spec_files import READ_FILE_SPEC, WRITE_FILE_SPEC, EDIT_FILE_SPEC
from maestro_core.tools.spec_search import GLOB_SEARCH_SPEC, GREP_SEARCH_SPEC
from maestro_core.tools.spec_mcp import (
    LIST_MCP_RESOURCES_SPEC, READ_MCP_RESOURCE_SPEC, MCP_AUTH_SPEC,
    MCP_TOOL_SPEC, REMOTE_TRIGGER_SPEC,
)
from maestro_core.tools.spec_task import (
    TASK_CREATE_SPEC, TASK_GET_SPEC, TASK_LIST_SPEC, TASK_STOP_SPEC,
    TASK_UPDATE_SPEC, TASK_OUTPUT_SPEC,
    WORKER_CREATE_SPEC, WORKER_GET_SPEC, WORKER_OBSERVE_SPEC,
    WORKER_RESOLVE_TRUST_SPEC, WORKER_AWAIT_READY_SPEC,
    WORKER_SEND_PROMPT_SPEC, WORKER_RESTART_SPEC, WORKER_TERMINATE_SPEC,
    TEAM_CREATE_SPEC, TEAM_DELETE_SPEC,
    CRON_CREATE_SPEC, CRON_DELETE_SPEC, CRON_LIST_SPEC,
)
from maestro_core.tools.spec_misc import (
    WEB_FETCH_SPEC, WEB_SEARCH_SPEC, TODO_WRITE_SPEC, SKILL_SPEC,
    AGENT_SPEC, TOOL_SEARCH_SPEC, NOTEBOOK_EDIT_SPEC, SLEEP_SPEC,
    SEND_USER_MESSAGE_SPEC, CONFIG_SPEC, ENTER_PLAN_MODE_SPEC,
    EXIT_PLAN_MODE_SPEC, STRUCTURED_OUTPUT_SPEC, REPL_SPEC,
    POWERSHELL_SPEC, ASK_USER_QUESTION_SPEC, LSP_SPEC,
    TESTING_PERMISSION_SPEC,
)


class ToolSource(Enum):
    """Source of a tool (base or conditional)."""

    BASE = "base"
    CONDITIONAL = "conditional"


@dataclass
class ToolManifestEntry:
    """Tool manifest entry."""

    name: str
    source: ToolSource


@dataclass
class RuntimeToolDefinition:
    """Runtime tool definition (for plugin / MCP tools)."""

    name: str
    description: Optional[str]
    input_schema: Any
    required_permission: PermissionMode


@dataclass
class ToolSearchOutput:
    """Result of a tool search."""

    matches: list[str]
    query: str
    normalized_query: str
    total_deferred_tools: int
    pending_mcp_servers: Optional[list[str]] = None


def mvp_tool_specs() -> list[ToolSpec]:
    """Return all MVP tool specifications (40+ tools)."""
    return [
        BASH_TOOL_SPEC,
        READ_FILE_SPEC,
        WRITE_FILE_SPEC,
        EDIT_FILE_SPEC,
        GLOB_SEARCH_SPEC,
        GREP_SEARCH_SPEC,
        WEB_FETCH_SPEC,
        WEB_SEARCH_SPEC,
        TODO_WRITE_SPEC,
        SKILL_SPEC,
        AGENT_SPEC,
        TOOL_SEARCH_SPEC,
        NOTEBOOK_EDIT_SPEC,
        SLEEP_SPEC,
        SEND_USER_MESSAGE_SPEC,
        CONFIG_SPEC,
        ENTER_PLAN_MODE_SPEC,
        EXIT_PLAN_MODE_SPEC,
        STRUCTURED_OUTPUT_SPEC,
        REPL_SPEC,
        POWERSHELL_SPEC,
        ASK_USER_QUESTION_SPEC,
        TASK_CREATE_SPEC,
        TASK_GET_SPEC,
        TASK_LIST_SPEC,
        TASK_STOP_SPEC,
        TASK_UPDATE_SPEC,
        TASK_OUTPUT_SPEC,
        WORKER_CREATE_SPEC, WORKER_GET_SPEC, WORKER_OBSERVE_SPEC,
        WORKER_RESOLVE_TRUST_SPEC, WORKER_AWAIT_READY_SPEC,
        WORKER_SEND_PROMPT_SPEC, WORKER_RESTART_SPEC, WORKER_TERMINATE_SPEC,
        TEAM_CREATE_SPEC, TEAM_DELETE_SPEC,
        CRON_CREATE_SPEC, CRON_DELETE_SPEC, CRON_LIST_SPEC,
        LSP_SPEC,
        LIST_MCP_RESOURCES_SPEC, READ_MCP_RESOURCE_SPEC, MCP_AUTH_SPEC,
        REMOTE_TRIGGER_SPEC, MCP_TOOL_SPEC,
        TESTING_PERMISSION_SPEC,
    ]


class GlobalToolRegistry:
    """Global registry including built-in, runtime, and plugin tools."""

    def __init__(self) -> None:
        self._plugin_tools: list[Any] = []
        self._runtime_tools: list[RuntimeToolDefinition] = []

    @classmethod
    def builtin(cls) -> GlobalToolRegistry:
        """Create a registry with only built-in tools."""
        return cls()

    def with_runtime_tools(self, tools: list[RuntimeToolDefinition]) -> GlobalToolRegistry:
        """Add runtime tools to the registry."""
        builtin_names = {spec.name for spec in mvp_tool_specs()}
        seen = set(builtin_names)
        for tool in tools:
            if tool.name in seen:
                raise ValueError(f"runtime tool `{tool.name}` conflicts with an existing tool name")
            seen.add(tool.name)
        self._runtime_tools = tools
        return self

    def definitions(self, allowed_tools: Optional[set[str]] = None) -> list[dict[str, Any]]:
        """Return tool definitions, optionally filtered."""
        results: list[dict[str, Any]] = []

        for spec in mvp_tool_specs():
            if allowed_tools is not None and spec.name not in allowed_tools:
                continue
            results.append({
                "name": spec.name,
                "description": spec.description,
                "input_schema": spec.input_schema,
            })

        for tool in self._runtime_tools:
            if allowed_tools is not None and tool.name not in allowed_tools:
                continue
            results.append({
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.input_schema,
            })

        return results

    def has_runtime_tool(self, name: str) -> bool:
        """Check if a runtime tool exists."""
        return any(t.name == name for t in self._runtime_tools)

    def search(
        self, query: str, max_results: int = 5, pending_mcp_servers: Optional[list[str]] = None
    ) -> ToolSearchOutput:
        """Search tools by name or description."""
        query = query.strip()
        normalized_query = _normalize_tool_search_query(query)
        specs = self._searchable_tool_specs()
        matches = _search_tool_specs(query, max(1, max_results), specs)
        return ToolSearchOutput(
            matches=matches,
            query=query,
            normalized_query=normalized_query,
            total_deferred_tools=len(specs),
            pending_mcp_servers=pending_mcp_servers,
        )

    def execute(self, name: str, input_data: dict[str, Any]) -> str:
        """Execute a tool by name (synchronous dispatch)."""
        if any(spec.name == name for spec in mvp_tool_specs()):
            return execute_tool(name, input_data)
        raise ValueError(f"unsupported tool: {name}")

    def normalize_allowed_tools(self, values: list[str]) -> Optional[set[str]]:
        """Normalize a list of allowed tool names."""
        if not values:
            return None

        canonical = {spec.name for spec in mvp_tool_specs()}
        canonical.update(t.name for t in self._runtime_tools)

        aliases = {
            "read": "read_file", "write": "write_file", "edit": "edit_file",
            "glob": "glob_search", "grep": "grep_search",
        }
        name_map: dict[str, str] = {}
        for name in canonical:
            name_map[_normalize_tool_name(name)] = name
        for alias, target in aliases.items():
            name_map[alias] = target

        allowed: set[str] = set()
        for value in values:
            for token in value.replace(",", " ").split():
                token = token.strip()
                if not token:
                    continue
                normalized = _normalize_tool_name(token)
                if normalized not in name_map:
                    raise ValueError(
                        f"unsupported tool in --allowedTools: {token} "
                        f"(expected one of: {', '.join(sorted(canonical))})"
                    )
                allowed.add(name_map[normalized])

        return allowed

    def _searchable_tool_specs(self) -> list[_SearchableToolSpec]:
        """Return all searchable tools."""
        specs: list[_SearchableToolSpec] = []
        for s in _deferred_tool_specs():
            specs.append(_SearchableToolSpec(name=s.name, description=s.description))
        for t in self._runtime_tools:
            specs.append(_SearchableToolSpec(name=t.name, description=t.description or ""))
        return specs


def execute_tool(name: str, input_data: dict[str, Any]) -> str:
    """Execute a built-in tool by name. Returns JSON result."""
    from maestro_core.tools.execution import execute_tool_dispatch
    return execute_tool_dispatch(name, input_data)


# --- Internal search helpers ---


@dataclass
class _SearchableToolSpec:
    name: str
    description: str


def _deferred_tool_specs() -> list[ToolSpec]:
    """Return searchable tools (excluding base tools)."""
    base_names = {"bash", "read_file", "write_file", "edit_file", "glob_search", "grep_search"}
    return [s for s in mvp_tool_specs() if s.name not in base_names]


def _normalize_tool_name(value: str) -> str:
    return value.strip().replace("-", "_").lower()


def _normalize_tool_search_query(query: str) -> str:
    tokens = query.strip().split()
    return " ".join(_canonical_tool_token(t) for t in tokens if t)


def _canonical_tool_token(value: str) -> str:
    canonical = "".join(ch.lower() for ch in value if ch.isalnum())
    if canonical.endswith("tool"):
        canonical = canonical[:-4]
    return canonical


def _search_tool_specs(query: str, max_results: int, specs: list[_SearchableToolSpec]) -> list[str]:
    """Search tools by term matching."""
    lowered = query.lower()

    # select: mode (exact by name)
    if lowered.startswith("select:"):
        selection = lowered[len("select:"):]
        wanted = [_canonical_tool_token(p.strip()) for p in selection.split(",") if p.strip()]
        results: list[str] = []
        for w in wanted:
            for spec in specs:
                if _canonical_tool_token(spec.name) == w:
                    results.append(spec.name)
                    break
            if len(results) >= max_results:
                break
        return results

    # Keyword search mode
    required: list[str] = []
    optional: list[str] = []
    for term in lowered.split():
        if term.startswith("+") and len(term) > 1:
            required.append(term[1:])
        else:
            optional.append(term)

    terms = (required + optional) if required else optional

    scored: list[tuple[int, str]] = []
    for spec in specs:
        name_lower = spec.name.lower()
        canonical_name = _canonical_tool_token(spec.name)
        haystack = f"{name_lower} {spec.description.lower()} {canonical_name}"

        if any(t not in haystack for t in required):
            continue

        score = 0
        for term in terms:
            ct = _canonical_tool_token(term)
            if term in haystack:
                score += 2
            if name_lower == term:
                score += 8
            if term in name_lower:
                score += 4
            if canonical_name == ct:
                score += 12

        if score == 0 and lowered:
            continue
        scored.append((score, spec.name))

    scored.sort(key=lambda x: (-x[0], x[1]))
    return [name for _, name in scored[:max_results]]
