"""File tool specs — JSON schemas for read_file, write_file, edit_file."""

from __future__ import annotations

from maestro_core.tools.specs import ToolSpec, PermissionMode

READ_FILE_SPEC = ToolSpec(
    name="read_file",
    description="Read a text file from the workspace.",
    input_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "offset": {"type": "integer", "minimum": 0},
            "limit": {"type": "integer", "minimum": 1},
        },
        "required": ["path"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

WRITE_FILE_SPEC = ToolSpec(
    name="write_file",
    description="Write a text file in the workspace.",
    input_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "content": {"type": "string"},
        },
        "required": ["path", "content"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.WORKSPACE_WRITE,
)

EDIT_FILE_SPEC = ToolSpec(
    name="edit_file",
    description="Replace text in a workspace file.",
    input_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "old_string": {"type": "string"},
            "new_string": {"type": "string"},
            "replace_all": {"type": "boolean"},
        },
        "required": ["path", "old_string", "new_string"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.WORKSPACE_WRITE,
)
