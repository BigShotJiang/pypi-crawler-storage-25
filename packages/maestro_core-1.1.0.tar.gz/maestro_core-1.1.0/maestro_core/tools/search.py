"""Spécifications des outils de recherche (grep, glob) — traduit de tools/lib.rs."""

from __future__ import annotations

from .registry import ToolSpec, PermissionMode

GLOB_SEARCH_SPEC = ToolSpec(
    name="glob_search",
    description="Find files by glob pattern.",
    input_schema={
        "type": "object",
        "properties": {
            "pattern": {"type": "string"},
            "path": {"type": "string"},
        },
        "required": ["pattern"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

GREP_SEARCH_SPEC = ToolSpec(
    name="grep_search",
    description="Search file contents with a regex pattern.",
    input_schema={
        "type": "object",
        "properties": {
            "pattern": {"type": "string"},
            "path": {"type": "string"},
            "glob": {"type": "string"},
            "output_mode": {"type": "string"},
            "-B": {"type": "integer", "minimum": 0},
            "-A": {"type": "integer", "minimum": 0},
            "-C": {"type": "integer", "minimum": 0},
            "context": {"type": "integer", "minimum": 0},
            "-n": {"type": "boolean"},
            "-i": {"type": "boolean"},
            "type": {"type": "string"},
            "head_limit": {"type": "integer", "minimum": 1},
            "offset": {"type": "integer", "minimum": 0},
            "multiline": {"type": "boolean"},
        },
        "required": ["pattern"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)
