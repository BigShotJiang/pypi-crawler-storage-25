"""Code intelligence tool — lightweight symbol search without LSP.

Provides CC CLI parity for code navigation (symbol search, definition lookup)
using ripgrep pattern matching instead of a full LSP server."""

from __future__ import annotations

import subprocess
from typing import Any

from maestro_core.tools.base import Tool, ToolResult, RiskLevel


class CodeIntelTool(Tool):
    """Search for code symbols (functions, classes, variables) in the codebase."""

    name = "code_search"
    description = (
        "Search for code symbols like function definitions, class declarations, "
        "imports, and variable assignments. Uses pattern matching on common code patterns."
    )
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "symbol": {
                "type": "string",
                "description": "Symbol name to search for (function, class, variable)",
            },
            "type": {
                "type": "string",
                "enum": ["function", "class", "import", "variable", "any"],
                "description": "Type of symbol to search for",
                "default": "any",
            },
            "path": {
                "type": "string",
                "description": "Directory to search in",
                "default": ".",
            },
            "language": {
                "type": "string",
                "enum": ["python", "typescript", "javascript", "rust", "go", "any"],
                "description": "Programming language",
                "default": "any",
            },
        },
        "required": ["symbol"],
    }
    risk_level = RiskLevel.READ

    PATTERNS: dict[str, dict[str, str]] = {
        "python": {
            "function": r"def\s+{symbol}\s*\(",
            "class": r"class\s+{symbol}\s*[\(:]",
            "import": r"(?:from|import)\s+.*{symbol}",
            "variable": r"{symbol}\s*=",
        },
        "typescript": {
            "function": r"(?:function|const|let|var)\s+{symbol}\s*[\(=]|{symbol}\s*\(",
            "class": r"class\s+{symbol}\s*[\{{]|interface\s+{symbol}",
            "import": r"import\s+.*{symbol}",
            "variable": r"(?:const|let|var)\s+{symbol}\s*[=:]",
        },
        "javascript": {
            "function": r"(?:function|const|let|var)\s+{symbol}\s*[\(=]|{symbol}\s*\(",
            "class": r"class\s+{symbol}\s*[\{{]",
            "import": r"(?:import|require)\s*.*{symbol}",
            "variable": r"(?:const|let|var)\s+{symbol}\s*[=:]",
        },
        "rust": {
            "function": r"fn\s+{symbol}\s*[\(<]",
            "class": r"(?:struct|enum|trait)\s+{symbol}",
            "import": r"use\s+.*{symbol}",
            "variable": r"(?:let|const|static)\s+(?:mut\s+)?{symbol}\s*[=:]",
        },
        "go": {
            "function": r"func\s+(?:\([^)]*\)\s+)?{symbol}\s*\(",
            "class": r"type\s+{symbol}\s+struct",
            "import": r"import\s+.*{symbol}",
            "variable": r"(?:var|const)\s+{symbol}\s",
        },
    }

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        symbol = args.get("symbol", "")
        symbol_type = args.get("type", "any")
        path = args.get("path", ".")
        language = args.get("language", "any")

        if not symbol:
            return ToolResult(content="symbol is required", is_error=True)

        # Build regex patterns based on type and language
        patterns = self._build_patterns(symbol, symbol_type, language)

        # Run ripgrep with each pattern
        results: list[str] = []
        for pattern in patterns:
            output = self._rg_search(pattern, path)
            if output:
                results.append(output)

        if not results:
            # Fallback: simple symbol grep
            output = self._rg_search(symbol, path, max_matches=20)
            if output:
                results.append(output)

        if not results:
            return ToolResult(content=f"No definitions found for '{symbol}'")

        combined = "\n".join(results)
        # Deduplicate lines
        seen: set[str] = set()
        unique_lines: list[str] = []
        for line in combined.splitlines():
            if line not in seen:
                seen.add(line)
                unique_lines.append(line)
        combined = "\n".join(unique_lines)

        # Truncate if too long
        if len(combined) > 5000:
            combined = combined[:5000] + "\n... (truncated)"

        return ToolResult(content=combined)

    def _build_patterns(self, symbol: str, symbol_type: str, language: str) -> list[str]:
        """Build regex patterns for the given symbol, type, and language."""
        patterns: list[str] = []

        if language != "any" and language in self.PATTERNS:
            lang_patterns = self.PATTERNS[language]
            if symbol_type != "any" and symbol_type in lang_patterns:
                patterns.append(lang_patterns[symbol_type].format(symbol=symbol))
            else:
                patterns.extend(p.format(symbol=symbol) for p in lang_patterns.values())
        else:
            # Generic: search across all language patterns for the given type
            if symbol_type != "any":
                for lang_patterns in self.PATTERNS.values():
                    if symbol_type in lang_patterns:
                        patterns.append(lang_patterns[symbol_type].format(symbol=symbol))
            else:
                # Broad search: common definition patterns
                patterns = [
                    rf"def\s+{symbol}\s*\(",
                    rf"class\s+{symbol}",
                    rf"function\s+{symbol}",
                    rf"const\s+{symbol}\s*=",
                    rf"fn\s+{symbol}\s*[\(<]",
                    rf"func\s+{symbol}\s*\(",
                    rf"type\s+{symbol}\s+struct",
                    rf"interface\s+{symbol}",
                ]

        return patterns

    @staticmethod
    def _rg_search(pattern: str, path: str, max_matches: int = 10) -> str:
        """Run ripgrep with the given pattern. Returns stdout or empty string."""
        try:
            proc = subprocess.run(
                ["rg", "-n", "--no-heading", "-m", str(max_matches), pattern, path],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return proc.stdout.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return ""
