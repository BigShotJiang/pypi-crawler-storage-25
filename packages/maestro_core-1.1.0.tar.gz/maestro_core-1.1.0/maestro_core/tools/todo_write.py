"""TodoWriteTool — manages a structured task list."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class TodoWriteTool(Tool):
    name = "todo_write"
    description = (
        "Update the structured task list for the current session. "
        "Persists todos to a JSON file. Clears the list when all items are completed."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "todos": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string"},
                        "status": {
                            "type": "string",
                            "enum": ["pending", "in_progress", "completed"],
                        },
                    },
                    "required": ["content", "status"],
                },
                "description": "List of todo items with content and status.",
            }
        },
        "required": ["todos"],
    }
    risk_level = RiskLevel.LOW

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        todos = args.get("todos", [])
        if not todos:
            return ToolResult(content="todos must not be empty", is_error=True)

        store_path = os.environ.get(
            "MAESTRO_TODO_STORE",
            os.path.join(os.getcwd(), ".maestro-todos.json"),
        )

        old_todos: list[Any] = []
        if os.path.exists(store_path):
            try:
                old_todos = json.loads(Path(store_path).read_text())
            except (json.JSONDecodeError, OSError):
                pass

        all_done = all(t.get("status") == "completed" for t in todos)
        persisted = [] if all_done else todos

        Path(store_path).parent.mkdir(parents=True, exist_ok=True)
        Path(store_path).write_text(json.dumps(persisted, indent=2))

        return ToolResult(
            content=f"Updated {len(todos)} todos ({sum(1 for t in todos if t.get('status') == 'completed')} completed)",
            metadata={"old_count": len(old_todos), "new_count": len(persisted)},
        )
