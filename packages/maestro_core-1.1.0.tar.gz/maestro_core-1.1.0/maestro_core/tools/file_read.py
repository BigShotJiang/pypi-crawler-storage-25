"""FileReadTool — reads files with line numbers, offset, and limit."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class FileReadTool(Tool):
    name = "file_read"
    description = (
        "Reads a file and returns its contents with line numbers (cat -n format). "
        "Supports offset and limit to read specific portions of large files."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute path to the file to read.",
            },
            "offset": {
                "type": "integer",
                "description": "Line number to start reading from (1-based). Default: 1.",
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of lines to read. Default: 2000.",
                "default": 2000,
            },
        },
        "required": ["path"],
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        file_path = Path(args["path"])
        offset = max(args.get("offset", 1) or 1, 1)
        limit = args.get("limit", 2000) or 2000

        if not file_path.exists():
            return ToolResult(
                content=f"File not found: {file_path}", is_error=True
            )

        if not file_path.is_file():
            return ToolResult(
                content=f"Not a file: {file_path}", is_error=True
            )

        try:
            text = file_path.read_text(encoding="utf-8", errors="replace")
        except PermissionError:
            return ToolResult(
                content=f"Permission denied: {file_path}", is_error=True
            )
        except Exception as e:
            return ToolResult(
                content=f"Error reading {file_path}: {e}", is_error=True
            )

        all_lines = text.splitlines()
        total_lines = len(all_lines)

        # offset is 1-based
        start_idx = offset - 1
        end_idx = start_idx + limit
        selected = all_lines[start_idx:end_idx]

        numbered_lines = [
            f"{start_idx + i + 1}\t{line}" for i, line in enumerate(selected)
        ]
        output = "\n".join(numbered_lines)

        return ToolResult(
            content=output if output else "(empty file)",
            metadata={
                "total_lines": total_lines,
                "lines_shown": len(selected),
                "offset": offset,
            },
        )
