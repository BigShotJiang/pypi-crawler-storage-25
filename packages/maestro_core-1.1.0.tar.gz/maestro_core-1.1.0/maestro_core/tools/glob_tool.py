"""GlobTool — finds files by glob pattern."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

MAX_RESULTS = 100


class GlobTool(Tool):
    name = "glob"
    description = (
        "Finds files matching a glob pattern. "
        "Returns up to 100 file paths sorted by modification time (most recent first)."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "pattern": {
                "type": "string",
                "description": "Glob pattern to match (e.g. '**/*.py', 'src/**/*.ts').",
            },
            "path": {
                "type": "string",
                "description": "Base directory to search in (default: current directory).",
                "default": ".",
            },
        },
        "required": ["pattern"],
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        pattern = args["pattern"]
        base_path = Path(args.get("path", "."))

        if not base_path.exists():
            return ToolResult(
                content=f"Directory not found: {base_path}", is_error=True
            )

        if not base_path.is_dir():
            return ToolResult(
                content=f"Not a directory: {base_path}", is_error=True
            )

        try:
            matches = [p for p in base_path.glob(pattern) if p.is_file()]
        except Exception as e:
            return ToolResult(
                content=f"Glob error: {e}", is_error=True
            )

        # Sort by modification time, most recent first
        matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)

        truncated = len(matches) > MAX_RESULTS
        matches = matches[:MAX_RESULTS]

        if not matches:
            return ToolResult(
                content="No files matched the pattern.",
                metadata={"match_count": 0},
            )

        output = "\n".join(str(p) for p in matches)
        if truncated:
            output += f"\n... (showing {MAX_RESULTS} of more results)"

        return ToolResult(
            content=output,
            metadata={
                "match_count": len(matches),
                "truncated": truncated,
            },
        )
