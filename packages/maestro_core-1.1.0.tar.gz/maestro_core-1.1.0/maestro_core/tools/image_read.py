"""Image reading tool — sends images to the LLM for analysis."""
from __future__ import annotations
import base64
import mimetypes
from pathlib import Path
from typing import Any
from maestro_core.tools.base import Tool, ToolResult, RiskLevel


class ImageReadTool(Tool):
    """Read an image file and return its base64 content for the LLM to analyze."""

    name = "image_read"
    description = (
        "Read an image file (PNG, JPG, GIF, WebP) and return its content. "
        "The image will be analyzed by the LLM for visual understanding."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to the image file"
            }
        },
        "required": ["path"]
    }
    risk_level = RiskLevel.READ

    SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"}
    MAX_SIZE_BYTES = 20 * 1024 * 1024  # 20MB max

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        file_path = Path(args.get("path", ""))

        if not file_path.exists():
            return ToolResult(content=f"File not found: {file_path}", is_error=True)

        ext = file_path.suffix.lower()
        if ext not in self.SUPPORTED_EXTENSIONS:
            return ToolResult(
                content=f"Unsupported image format: {ext}. Supported: {', '.join(self.SUPPORTED_EXTENSIONS)}",
                is_error=True,
            )

        size = file_path.stat().st_size
        if size > self.MAX_SIZE_BYTES:
            return ToolResult(
                content=f"Image too large: {size / 1024 / 1024:.1f}MB (max {self.MAX_SIZE_BYTES / 1024 / 1024}MB)",
                is_error=True,
            )

        try:
            data = file_path.read_bytes()
            b64 = base64.b64encode(data).decode("utf-8")
            mime = mimetypes.guess_type(str(file_path))[0] or "image/png"

            # Return as a data URI that the LLM can understand
            return ToolResult(
                content=f"[Image: {file_path.name} ({size / 1024:.0f}KB, {mime})]\ndata:{mime};base64,{b64[:100]}...",
                metadata={
                    "type": "image",
                    "path": str(file_path),
                    "mime_type": mime,
                    "size_bytes": size,
                    "base64_data": b64,  # Full data in metadata for providers that support it
                }
            )
        except Exception as e:
            return ToolResult(content=f"Error reading image: {e}", is_error=True)
