"""MCP tool specs — JSON schemas for MCP resource and tool operations."""

from __future__ import annotations

from maestro_core.tools.specs import ToolSpec, PermissionMode

LIST_MCP_RESOURCES_SPEC = ToolSpec(
    name="ListMcpResources",
    description="List available resources from connected MCP servers.",
    input_schema={
        "type": "object",
        "properties": {"server": {"type": "string"}},
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

READ_MCP_RESOURCE_SPEC = ToolSpec(
    name="ReadMcpResource",
    description="Read a specific resource from an MCP server by URI.",
    input_schema={
        "type": "object",
        "properties": {
            "server": {"type": "string"},
            "uri": {"type": "string"},
        },
        "required": ["uri"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

MCP_AUTH_SPEC = ToolSpec(
    name="McpAuth",
    description="Authenticate with an MCP server that requires OAuth or credentials.",
    input_schema={
        "type": "object",
        "properties": {"server": {"type": "string"}},
        "required": ["server"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

REMOTE_TRIGGER_SPEC = ToolSpec(
    name="RemoteTrigger",
    description="Trigger a remote action or webhook endpoint.",
    input_schema={
        "type": "object",
        "properties": {
            "url": {"type": "string"},
            "method": {"type": "string", "enum": ["GET", "POST", "PUT", "DELETE"]},
            "headers": {"type": "object"},
            "body": {"type": "string"},
        },
        "required": ["url"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

MCP_TOOL_SPEC = ToolSpec(
    name="MCP",
    description="Execute a tool provided by a connected MCP server.",
    input_schema={
        "type": "object",
        "properties": {
            "server": {"type": "string"},
            "tool": {"type": "string"},
            "arguments": {"type": "object"},
        },
        "required": ["server", "tool"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)
