"""NotebookEditTool — edits Jupyter notebook cells."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class NotebookEditTool(Tool):
    name = "notebook_edit"
    description = (
        "Replace, insert, or delete a cell in a Jupyter notebook (.ipynb). "
        "Supports code and markdown cell types."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "notebook_path": {
                "type": "string",
                "description": "Path to the .ipynb file.",
            },
            "cell_id": {
                "type": "string",
                "description": "ID of the cell to edit (optional for insert at end).",
            },
            "new_source": {
                "type": "string",
                "description": "New source content for the cell.",
            },
            "cell_type": {
                "type": "string",
                "enum": ["code", "markdown"],
                "description": "Type of cell (default: code).",
            },
            "edit_mode": {
                "type": "string",
                "enum": ["replace", "insert", "delete"],
                "description": "Edit mode (default: replace).",
            },
        },
        "required": ["notebook_path"],
    }
    risk_level = RiskLevel.LOW

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        nb_path = Path(args["notebook_path"])

        if not nb_path.suffix == ".ipynb":
            return ToolResult(
                content="File must be a Jupyter notebook (.ipynb).", is_error=True
            )

        if not nb_path.exists():
            return ToolResult(
                content=f"Notebook not found: {nb_path}", is_error=True
            )

        try:
            notebook = json.loads(nb_path.read_text(encoding="utf-8"))
        except Exception as e:
            return ToolResult(content=f"Error reading notebook: {e}", is_error=True)

        cells = notebook.get("cells", [])
        edit_mode = args.get("edit_mode", "replace")
        cell_id = args.get("cell_id")
        new_source = args.get("new_source", "")
        cell_type = args.get("cell_type", "code")

        if edit_mode == "insert":
            new_cell = {
                "cell_type": cell_type,
                "source": new_source.splitlines(keepends=True),
                "metadata": {},
            }
            if cell_type == "code":
                new_cell["outputs"] = []
                new_cell["execution_count"] = None
            cells.append(new_cell)
            notebook["cells"] = cells
            nb_path.write_text(json.dumps(notebook, indent=1, ensure_ascii=False), encoding="utf-8")
            return ToolResult(
                content=f"Inserted new {cell_type} cell at end of {nb_path}",
                metadata={"edit_mode": "insert", "cell_count": len(cells)},
            )

        if cell_id is None:
            return ToolResult(
                content="cell_id is required for replace/delete operations.",
                is_error=True,
            )

        # Find cell by id or index
        target_idx = None
        for idx, cell in enumerate(cells):
            cid = cell.get("id") or cell.get("metadata", {}).get("id")
            if cid == cell_id:
                target_idx = idx
                break
        if target_idx is None:
            try:
                target_idx = int(cell_id)
            except ValueError:
                return ToolResult(
                    content=f"Cell '{cell_id}' not found.", is_error=True
                )

        if target_idx < 0 or target_idx >= len(cells):
            return ToolResult(
                content=f"Cell index {target_idx} out of range (0-{len(cells)-1}).",
                is_error=True,
            )

        if edit_mode == "delete":
            cells.pop(target_idx)
            notebook["cells"] = cells
            nb_path.write_text(json.dumps(notebook, indent=1, ensure_ascii=False), encoding="utf-8")
            return ToolResult(
                content=f"Deleted cell {cell_id} from {nb_path}",
                metadata={"edit_mode": "delete", "cell_count": len(cells)},
            )

        # replace
        cells[target_idx]["source"] = new_source.splitlines(keepends=True)
        if cell_type:
            cells[target_idx]["cell_type"] = cell_type
        notebook["cells"] = cells
        nb_path.write_text(json.dumps(notebook, indent=1, ensure_ascii=False), encoding="utf-8")
        return ToolResult(
            content=f"Replaced cell {cell_id} in {nb_path}",
            metadata={"edit_mode": "replace", "cell_count": len(cells)},
        )
