"""MCPBridgeTool — bridge for executing MCP server tools."""

from __future__ import annotations

from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class MCPBridgeTool(Tool):
    name = "mcp_bridge"
    description = (
        "Execute a tool provided by a connected MCP server. "
        "Requires server name, tool name, and optional arguments."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "server": {
                "type": "string",
                "description": "Name of the MCP server.",
            },
            "tool": {
                "type": "string",
                "description": "Name of the tool to execute on the MCP server.",
            },
            "arguments": {
                "type": "object",
                "description": "Arguments to pass to the MCP tool.",
            },
        },
        "required": ["server", "tool"],
    }
    risk_level = RiskLevel.HIGH

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        server = args["server"]
        tool = args["tool"]
        arguments = args.get("arguments", {})

        # This is a bridge — actual MCP execution is handled by the runtime.
        # Return a structured stub that the orchestrator can dispatch.
        return ToolResult(
            content=f"MCP bridge: {server}/{tool} — requires runtime dispatch",
            metadata={
                "server": server,
                "tool": tool,
                "arguments": arguments,
                "requires_runtime": True,
            },
        )
