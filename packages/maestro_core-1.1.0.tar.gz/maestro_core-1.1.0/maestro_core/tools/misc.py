"""Spécifications des outils divers — traduit de tools/lib.rs."""

from __future__ import annotations

from .registry import ToolSpec, PermissionMode

WEB_FETCH_SPEC = ToolSpec(
    name="WebFetch",
    description="Fetch a URL, convert it into readable text, and answer a prompt about it.",
    input_schema={
        "type": "object",
        "properties": {
            "url": {"type": "string", "format": "uri"},
            "prompt": {"type": "string"},
        },
        "required": ["url", "prompt"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

WEB_SEARCH_SPEC = ToolSpec(
    name="WebSearch",
    description="Search the web for current information and return cited results.",
    input_schema={
        "type": "object",
        "properties": {
            "query": {"type": "string", "minLength": 2},
            "allowed_domains": {"type": "array", "items": {"type": "string"}},
            "blocked_domains": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["query"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

TODO_WRITE_SPEC = ToolSpec(
    name="TodoWrite",
    description="Update the structured task list for the current session.",
    input_schema={
        "type": "object",
        "properties": {
            "todos": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string"},
                        "activeForm": {"type": "string"},
                        "status": {"type": "string", "enum": ["pending", "in_progress", "completed"]},
                    },
                    "required": ["content", "activeForm", "status"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["todos"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.WORKSPACE_WRITE,
)

SKILL_SPEC = ToolSpec(
    name="Skill",
    description="Load a local skill definition and its instructions.",
    input_schema={
        "type": "object",
        "properties": {
            "skill": {"type": "string"},
            "args": {"type": "string"},
        },
        "required": ["skill"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

AGENT_SPEC = ToolSpec(
    name="Agent",
    description="Launch a specialized agent task and persist its handoff metadata.",
    input_schema={
        "type": "object",
        "properties": {
            "description": {"type": "string"},
            "prompt": {"type": "string"},
            "subagent_type": {"type": "string"},
            "name": {"type": "string"},
            "model": {"type": "string"},
        },
        "required": ["description", "prompt"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

TOOL_SEARCH_SPEC = ToolSpec(
    name="ToolSearch",
    description="Search for deferred or specialized tools by exact name or keywords.",
    input_schema={
        "type": "object",
        "properties": {
            "query": {"type": "string"},
            "max_results": {"type": "integer", "minimum": 1},
        },
        "required": ["query"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

NOTEBOOK_EDIT_SPEC = ToolSpec(
    name="NotebookEdit",
    description="Replace, insert, or delete a cell in a Jupyter notebook.",
    input_schema={
        "type": "object",
        "properties": {
            "notebook_path": {"type": "string"},
            "cell_id": {"type": "string"},
            "new_source": {"type": "string"},
            "cell_type": {"type": "string", "enum": ["code", "markdown"]},
            "edit_mode": {"type": "string", "enum": ["replace", "insert", "delete"]},
        },
        "required": ["notebook_path"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.WORKSPACE_WRITE,
)

SLEEP_SPEC = ToolSpec(
    name="Sleep",
    description="Wait for a specified duration without holding a shell process.",
    input_schema={
        "type": "object",
        "properties": {"duration_ms": {"type": "integer", "minimum": 0}},
        "required": ["duration_ms"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

SEND_USER_MESSAGE_SPEC = ToolSpec(
    name="SendUserMessage",
    description="Send a message to the user.",
    input_schema={
        "type": "object",
        "properties": {
            "message": {"type": "string"},
            "attachments": {"type": "array", "items": {"type": "string"}},
            "status": {"type": "string", "enum": ["normal", "proactive"]},
        },
        "required": ["message", "status"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

CONFIG_SPEC = ToolSpec(
    name="Config",
    description="Get or set Claude Code settings.",
    input_schema={
        "type": "object",
        "properties": {
            "setting": {"type": "string"},
            "value": {"type": ["string", "boolean", "number"]},
        },
        "required": ["setting"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.WORKSPACE_WRITE,
)

ENTER_PLAN_MODE_SPEC = ToolSpec(
    name="EnterPlanMode",
    description="Enable a worktree-local planning mode override and remember the previous local setting for ExitPlanMode.",
    input_schema={"type": "object", "properties": {}, "additionalProperties": False},
    required_permission=PermissionMode.WORKSPACE_WRITE,
)

EXIT_PLAN_MODE_SPEC = ToolSpec(
    name="ExitPlanMode",
    description="Restore or clear the worktree-local planning mode override created by EnterPlanMode.",
    input_schema={"type": "object", "properties": {}, "additionalProperties": False},
    required_permission=PermissionMode.WORKSPACE_WRITE,
)

STRUCTURED_OUTPUT_SPEC = ToolSpec(
    name="StructuredOutput",
    description="Return structured output in the requested format.",
    input_schema={"type": "object", "additionalProperties": True},
    required_permission=PermissionMode.READ_ONLY,
)

REPL_SPEC = ToolSpec(
    name="REPL",
    description="Execute code in a REPL-like subprocess.",
    input_schema={
        "type": "object",
        "properties": {
            "code": {"type": "string"},
            "language": {"type": "string"},
            "timeout_ms": {"type": "integer", "minimum": 1},
        },
        "required": ["code", "language"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

POWERSHELL_SPEC = ToolSpec(
    name="PowerShell",
    description="Execute a PowerShell command with optional timeout.",
    input_schema={
        "type": "object",
        "properties": {
            "command": {"type": "string"},
            "timeout": {"type": "integer", "minimum": 1},
            "description": {"type": "string"},
            "run_in_background": {"type": "boolean"},
        },
        "required": ["command"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

ASK_USER_QUESTION_SPEC = ToolSpec(
    name="AskUserQuestion",
    description="Ask the user a question and wait for their response.",
    input_schema={
        "type": "object",
        "properties": {
            "question": {"type": "string"},
            "options": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["question"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

LSP_SPEC = ToolSpec(
    name="LSP",
    description="Query Language Server Protocol for code intelligence (symbols, references, diagnostics).",
    input_schema={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["symbols", "references", "diagnostics", "definition", "hover"]},
            "path": {"type": "string"},
            "line": {"type": "integer", "minimum": 0},
            "character": {"type": "integer", "minimum": 0},
            "query": {"type": "string"},
        },
        "required": ["action"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

TESTING_PERMISSION_SPEC = ToolSpec(
    name="TestingPermission",
    description="Test-only tool for verifying permission enforcement behavior.",
    input_schema={
        "type": "object",
        "properties": {"action": {"type": "string"}},
        "required": ["action"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)
