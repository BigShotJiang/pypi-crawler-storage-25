"""Tool framework — base classes for all Maestro tools."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class RiskLevel(str, Enum):
    READ = "read"       # Lecture seule, toujours autorise
    LOW = "low"         # Ecriture locale, risque faible
    MEDIUM = "medium"   # Ecriture, demande confirmation
    HIGH = "high"       # Dangereux, toujours demander


@dataclass
class ToolResult:
    content: str
    is_error: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolDefinition:
    """Definition d'outil pour le LLM (format Anthropic)."""

    name: str
    description: str
    input_schema: dict[str, Any]


class Tool(ABC):
    """Base class for all tools."""

    name: str
    description: str
    input_schema: dict[str, Any]
    risk_level: RiskLevel = RiskLevel.READ

    def to_definition(self) -> ToolDefinition:
        return ToolDefinition(
            name=self.name,
            description=self.description,
            input_schema=self.input_schema,
        )

    @abstractmethod
    async def execute(self, args: dict[str, Any]) -> ToolResult:
        ...


class ToolRegistry:
    """Registry of available tools."""

    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def register_many(self, tools: list[Tool]) -> None:
        for t in tools:
            self.register(t)

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def get_definitions(self) -> list[ToolDefinition]:
        return [t.to_definition() for t in self._tools.values()]

    async def execute(self, name: str, args: dict[str, Any]) -> ToolResult:
        tool = self._tools.get(name)
        if not tool:
            return ToolResult(content=f"Tool '{name}' not found", is_error=True)
        try:
            return await tool.execute(args)
        except Exception as e:
            return ToolResult(content=f"Error executing {name}: {e}", is_error=True)

    @property
    def tools(self) -> dict[str, Tool]:
        return dict(self._tools)

    def __len__(self) -> int:
        return len(self._tools)
