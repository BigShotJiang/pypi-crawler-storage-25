"""PDF reading tool — extracts text from PDF files."""
from __future__ import annotations
from pathlib import Path
from typing import Any
from maestro_core.tools.base import Tool, ToolResult, RiskLevel


class PdfReadTool(Tool):
    """Read a PDF file and extract its text content."""

    name = "pdf_read"
    description = "Read a PDF file and extract text content. Returns the text from specified pages."
    input_schema = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Path to the PDF file"},
            "pages": {"type": "string", "description": "Page range (e.g. '1-5', '3', '10-20'). Default: all pages."},
        },
        "required": ["path"]
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        file_path = Path(args.get("path", ""))
        pages_str = args.get("pages", "")

        if not file_path.exists():
            return ToolResult(content=f"File not found: {file_path}", is_error=True)

        if file_path.suffix.lower() != ".pdf":
            return ToolResult(content=f"Not a PDF file: {file_path}", is_error=True)

        try:
            # Try pymupdf (fitz) first
            import fitz
            doc = fitz.open(str(file_path))

            # Parse page range
            page_indices = _parse_page_range(pages_str, len(doc)) if pages_str else range(len(doc))

            text_parts = []
            for i in page_indices:
                if 0 <= i < len(doc):
                    page = doc[i]
                    text = page.get_text()
                    if text.strip():
                        text_parts.append(f"--- Page {i + 1} ---\n{text}")

            doc.close()

            if not text_parts:
                return ToolResult(content="No text found in the specified pages.")

            full_text = "\n\n".join(text_parts)
            # Truncate if too long
            if len(full_text) > 50000:
                full_text = full_text[:50000] + "\n\n[...truncated...]"

            return ToolResult(content=full_text)

        except ImportError:
            # Fallback: try pdftotext CLI or just report
            try:
                import subprocess
                result = subprocess.run(
                    ["pdftotext", str(file_path), "-"],
                    capture_output=True, text=True, timeout=30
                )
                if result.returncode == 0:
                    return ToolResult(content=result.stdout[:50000])
                return ToolResult(content="Install pymupdf for PDF reading: pip install pymupdf", is_error=True)
            except FileNotFoundError:
                return ToolResult(content="Install pymupdf for PDF reading: pip install pymupdf", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error reading PDF: {e}", is_error=True)


def _parse_page_range(pages_str: str, total: int) -> list[int]:
    """Parse page range string like '1-5' or '3' into 0-based indices."""
    result = []
    for part in pages_str.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            start_i = max(0, int(start) - 1)
            end_i = min(total, int(end))
            result.extend(range(start_i, end_i))
        else:
            idx = int(part) - 1
            if 0 <= idx < total:
                result.append(idx)
    return result
