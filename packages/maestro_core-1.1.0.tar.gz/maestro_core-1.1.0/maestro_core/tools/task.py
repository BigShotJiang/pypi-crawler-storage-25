"""Spécifications des outils Task, Worker, Team, Cron — traduit de tools/lib.rs."""

from __future__ import annotations

from .registry import ToolSpec, PermissionMode

# --- Task tools ---

TASK_CREATE_SPEC = ToolSpec(
    name="TaskCreate",
    description="Create a background task that runs in a separate subprocess.",
    input_schema={
        "type": "object",
        "properties": {
            "prompt": {"type": "string"},
            "description": {"type": "string"},
        },
        "required": ["prompt"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

TASK_GET_SPEC = ToolSpec(
    name="TaskGet",
    description="Get the status and details of a background task by ID.",
    input_schema={
        "type": "object",
        "properties": {"task_id": {"type": "string"}},
        "required": ["task_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

TASK_LIST_SPEC = ToolSpec(
    name="TaskList",
    description="List all background tasks and their current status.",
    input_schema={"type": "object", "properties": {}, "additionalProperties": False},
    required_permission=PermissionMode.READ_ONLY,
)

TASK_STOP_SPEC = ToolSpec(
    name="TaskStop",
    description="Stop a running background task by ID.",
    input_schema={
        "type": "object",
        "properties": {"task_id": {"type": "string"}},
        "required": ["task_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

TASK_UPDATE_SPEC = ToolSpec(
    name="TaskUpdate",
    description="Send a message or update to a running background task.",
    input_schema={
        "type": "object",
        "properties": {
            "task_id": {"type": "string"},
            "message": {"type": "string"},
        },
        "required": ["task_id", "message"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

TASK_OUTPUT_SPEC = ToolSpec(
    name="TaskOutput",
    description="Retrieve the output produced by a background task.",
    input_schema={
        "type": "object",
        "properties": {"task_id": {"type": "string"}},
        "required": ["task_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

# --- Worker tools ---

WORKER_CREATE_SPEC = ToolSpec(
    name="WorkerCreate",
    description="Create a coding worker boot session with trust-gate and prompt-delivery guards.",
    input_schema={
        "type": "object",
        "properties": {
            "cwd": {"type": "string"},
            "trusted_roots": {"type": "array", "items": {"type": "string"}},
            "auto_recover_prompt_misdelivery": {"type": "boolean"},
        },
        "required": ["cwd"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

WORKER_GET_SPEC = ToolSpec(
    name="WorkerGet",
    description="Fetch the current worker boot state, last error, and event history.",
    input_schema={
        "type": "object",
        "properties": {"worker_id": {"type": "string"}},
        "required": ["worker_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

WORKER_OBSERVE_SPEC = ToolSpec(
    name="WorkerObserve",
    description="Feed a terminal snapshot into worker boot detection to resolve trust gates, ready handshakes, and prompt misdelivery.",
    input_schema={
        "type": "object",
        "properties": {
            "worker_id": {"type": "string"},
            "screen_text": {"type": "string"},
        },
        "required": ["worker_id", "screen_text"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

WORKER_RESOLVE_TRUST_SPEC = ToolSpec(
    name="WorkerResolveTrust",
    description="Resolve a detected trust prompt so worker boot can continue.",
    input_schema={
        "type": "object",
        "properties": {"worker_id": {"type": "string"}},
        "required": ["worker_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

WORKER_AWAIT_READY_SPEC = ToolSpec(
    name="WorkerAwaitReady",
    description="Return the current ready-handshake verdict for a coding worker.",
    input_schema={
        "type": "object",
        "properties": {"worker_id": {"type": "string"}},
        "required": ["worker_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.READ_ONLY,
)

WORKER_SEND_PROMPT_SPEC = ToolSpec(
    name="WorkerSendPrompt",
    description="Send a task prompt only after the worker reaches ready_for_prompt; can replay a recovered prompt.",
    input_schema={
        "type": "object",
        "properties": {
            "worker_id": {"type": "string"},
            "prompt": {"type": "string"},
        },
        "required": ["worker_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

WORKER_RESTART_SPEC = ToolSpec(
    name="WorkerRestart",
    description="Restart worker boot state after a failed or stale startup.",
    input_schema={
        "type": "object",
        "properties": {"worker_id": {"type": "string"}},
        "required": ["worker_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

WORKER_TERMINATE_SPEC = ToolSpec(
    name="WorkerTerminate",
    description="Terminate a worker and mark the lane finished from the control plane.",
    input_schema={
        "type": "object",
        "properties": {"worker_id": {"type": "string"}},
        "required": ["worker_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

# --- Team tools ---

TEAM_CREATE_SPEC = ToolSpec(
    name="TeamCreate",
    description="Create a team of sub-agents for parallel task execution.",
    input_schema={
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "tasks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "prompt": {"type": "string"},
                        "description": {"type": "string"},
                    },
                    "required": ["prompt"],
                },
            },
        },
        "required": ["name", "tasks"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

TEAM_DELETE_SPEC = ToolSpec(
    name="TeamDelete",
    description="Delete a team and stop all its running tasks.",
    input_schema={
        "type": "object",
        "properties": {"team_id": {"type": "string"}},
        "required": ["team_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

# --- Cron tools ---

CRON_CREATE_SPEC = ToolSpec(
    name="CronCreate",
    description="Create a scheduled recurring task.",
    input_schema={
        "type": "object",
        "properties": {
            "schedule": {"type": "string"},
            "prompt": {"type": "string"},
            "description": {"type": "string"},
        },
        "required": ["schedule", "prompt"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

CRON_DELETE_SPEC = ToolSpec(
    name="CronDelete",
    description="Delete a scheduled recurring task by ID.",
    input_schema={
        "type": "object",
        "properties": {"cron_id": {"type": "string"}},
        "required": ["cron_id"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)

CRON_LIST_SPEC = ToolSpec(
    name="CronList",
    description="List all scheduled recurring tasks.",
    input_schema={"type": "object", "properties": {}, "additionalProperties": False},
    required_permission=PermissionMode.READ_ONLY,
)
