"""Bash tool spec — JSON schema for the bash tool."""

from __future__ import annotations

from maestro_core.tools.specs import ToolSpec, PermissionMode

BASH_TOOL_SPEC = ToolSpec(
    name="bash",
    description="Execute a shell command in the current workspace.",
    input_schema={
        "type": "object",
        "properties": {
            "command": {"type": "string"},
            "timeout": {"type": "integer", "minimum": 1},
            "description": {"type": "string"},
            "run_in_background": {"type": "boolean"},
            "dangerouslyDisableSandbox": {"type": "boolean"},
            "namespaceRestrictions": {"type": "boolean"},
            "isolateNetwork": {"type": "boolean"},
            "filesystemMode": {
                "type": "string",
                "enum": ["off", "workspace-only", "allow-list"],
            },
            "allowedMounts": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["command"],
        "additionalProperties": False,
    },
    required_permission=PermissionMode.DANGER_FULL_ACCESS,
)
