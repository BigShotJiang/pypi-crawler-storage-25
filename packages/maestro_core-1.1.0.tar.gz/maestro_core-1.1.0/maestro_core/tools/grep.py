"""GrepTool — searches file contents using ripgrep (with grep fallback)."""

from __future__ import annotations

import asyncio
import shutil
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

MAX_MATCHES = 50


class GrepTool(Tool):
    name = "grep"
    description = (
        "Searches file contents for a regex pattern using ripgrep (rg). "
        "Falls back to grep -rn if rg is not available. "
        "Returns up to 50 matching lines."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "pattern": {
                "type": "string",
                "description": "Regex pattern to search for.",
            },
            "path": {
                "type": "string",
                "description": "Directory or file to search in (default: current directory).",
                "default": ".",
            },
            "glob": {
                "type": "string",
                "description": "Glob pattern to filter files (e.g. '*.py', '*.ts').",
            },
        },
        "required": ["pattern"],
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        pattern = args["pattern"]
        path = args.get("path", ".")
        glob_filter = args.get("glob")

        use_rg = shutil.which("rg") is not None

        if use_rg:
            cmd = ["rg", "-n", "--max-count", str(MAX_MATCHES), "--color", "never"]
            if glob_filter:
                cmd.extend(["--glob", glob_filter])
            cmd.extend(["--", pattern, path])
        else:
            cmd = ["grep", "-rn", "--color=never"]
            if glob_filter:
                cmd.extend(["--include", glob_filter])
            cmd.extend(["--", pattern, path])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return ToolResult(content="Search timed out after 30s", is_error=True)
        except FileNotFoundError:
            return ToolResult(
                content="Neither rg nor grep found on this system",
                is_error=True,
            )
        except Exception as e:
            return ToolResult(content=f"Search error: {e}", is_error=True)

        output = stdout.decode("utf-8", errors="replace") if stdout else ""

        # Limit to MAX_MATCHES lines
        lines = output.splitlines()
        truncated = len(lines) > MAX_MATCHES
        if truncated:
            lines = lines[:MAX_MATCHES]
            output = "\n".join(lines) + f"\n... ({len(lines)} matches shown, results truncated)"
        elif not output.strip():
            return ToolResult(
                content="No matches found.",
                metadata={"match_count": 0},
            )

        return ToolResult(
            content=output,
            metadata={
                "match_count": len(lines),
                "truncated": truncated,
                "engine": "rg" if use_rg else "grep",
            },
        )
