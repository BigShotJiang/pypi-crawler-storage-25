"""BashTool — executes shell commands with timeout and output truncation."""

from __future__ import annotations

import asyncio
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

MAX_OUTPUT_CHARS = 10_000


class BashTool(Tool):
    name = "bash"
    description = (
        "Executes a shell command and returns stdout + stderr. "
        "Output is truncated to 10000 characters. "
        "Use timeout parameter to adjust the max execution time in milliseconds."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute.",
            },
            "timeout": {
                "type": "integer",
                "description": "Max execution time in milliseconds (default 120000).",
                "default": 120000,
            },
        },
        "required": ["command"],
    }
    risk_level = RiskLevel.MEDIUM

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        command = args["command"]
        timeout_ms = args.get("timeout", 120000)
        timeout_s = timeout_ms / 1000.0

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_s
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return ToolResult(
                content=f"Command timed out after {timeout_ms}ms",
                is_error=True,
                metadata={"timeout": True},
            )
        except Exception as e:
            return ToolResult(content=f"Failed to execute command: {e}", is_error=True)

        output_parts: list[str] = []
        if stdout:
            output_parts.append(stdout.decode("utf-8", errors="replace"))
        if stderr:
            output_parts.append(stderr.decode("utf-8", errors="replace"))

        output = "\n".join(output_parts)

        truncated = False
        if len(output) > MAX_OUTPUT_CHARS:
            output = output[:MAX_OUTPUT_CHARS] + "\n... (output truncated)"
            truncated = True

        return ToolResult(
            content=output if output else "(no output)",
            is_error=proc.returncode != 0,
            metadata={
                "exit_code": proc.returncode,
                "truncated": truncated,
            },
        )
