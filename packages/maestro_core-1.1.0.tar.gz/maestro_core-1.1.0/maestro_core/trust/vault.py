"""Vault d'anonymisation — mapping bidirectionnel en RAM.

Stocke les associations valeur_originale <-> placeholder de manière
à pouvoir anonymiser et dé-anonymiser de façon déterministe au sein
d'une même session de conversation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .patterns import EntityCategory


@dataclass
class VaultEntry:
    """Entrée dans le vault : valeur originale, placeholder, catégorie."""

    original: str
    placeholder: str
    category: EntityCategory


class AnonymizationVault:
    """Mapping bidirectionnel RAM-only pour l'anonymisation.

    Chaque valeur sensible détectée reçoit un placeholder unique
    et déterministe (même valeur → même placeholder dans la session).

    Le vault est éphémère — il vit le temps de la conversation."""

    def __init__(self) -> None:
        # original → placeholder
        self._forward: dict[str, str] = {}
        # placeholder → original
        self._reverse: dict[str, str] = {}
        # Compteurs par catégorie pour générer des placeholders lisibles
        self._counters: dict[EntityCategory, int] = {}
        # Historique complet
        self._entries: list[VaultEntry] = []

    def get_or_create_placeholder(
        self, original: str, category: EntityCategory
    ) -> str:
        """Retourne le placeholder pour une valeur, en le créant si nécessaire."""
        if original in self._forward:
            return self._forward[original]

        placeholder = self._generate_placeholder(category)
        self._forward[original] = placeholder
        self._reverse[placeholder] = original
        self._entries.append(VaultEntry(
            original=original,
            placeholder=placeholder,
            category=category,
        ))
        return placeholder

    def resolve_placeholder(self, placeholder: str) -> Optional[str]:
        """Retourne la valeur originale pour un placeholder, ou None."""
        return self._reverse.get(placeholder)

    def resolve_original(self, original: str) -> Optional[str]:
        """Retourne le placeholder pour une valeur originale, ou None."""
        return self._forward.get(original)

    @property
    def entries(self) -> list[VaultEntry]:
        """Retourne toutes les entrées du vault."""
        return list(self._entries)

    @property
    def size(self) -> int:
        """Nombre d'entrées dans le vault."""
        return len(self._entries)

    def clear(self) -> None:
        """Vide le vault."""
        self._forward.clear()
        self._reverse.clear()
        self._counters.clear()
        self._entries.clear()

    def _generate_placeholder(self, category: EntityCategory) -> str:
        """Génère un placeholder lisible et unique par catégorie."""
        count = self._counters.get(category, 0) + 1
        self._counters[category] = count

        # Préfixes lisibles par catégorie
        prefix_map = {
            EntityCategory.NIR: "NIR",
            EntityCategory.SIRET: "SIRET",
            EntityCategory.SIREN: "SIREN",
            EntityCategory.IBAN: "IBAN",
            EntityCategory.EMAIL: "EMAIL",
            EntityCategory.PHONE: "PHONE",
            EntityCategory.API_KEY: "APIKEY",
            EntityCategory.JWT: "TOKEN",
            EntityCategory.CREDIT_CARD: "CARD",
            EntityCategory.PERSON_NAME: "PERSONNE",
            EntityCategory.IP_ADDRESS: "IP",
        }

        prefix = prefix_map.get(category, "ENTITY")
        # Format : [CATEGORY_N] pour être facilement identifiable et réversible
        return f"[{prefix}_{count}]"
