"""Patterns de détection d'entités sensibles — regex organisés par catégorie.

Pas de dépendance externe (spaCy, etc.) — tout en regex pur.
Optimisé pour le contexte français (NIR, SIRET, etc.) avec support international."""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Pattern


class EntityCategory(str, Enum):
    """Catégorie d'entité sensible détectée."""

    NIR = "nir"                  # Numéro de sécurité sociale français
    SIRET = "siret"              # Numéro SIRET (14 chiffres)
    SIREN = "siren"              # Numéro SIREN (9 chiffres)
    IBAN = "iban"                # Numéro IBAN
    EMAIL = "email"              # Adresse email
    PHONE = "phone"              # Numéro de téléphone
    API_KEY = "api_key"          # Clé API (divers formats)
    JWT = "jwt"                  # JSON Web Token
    CREDIT_CARD = "credit_card"  # Numéro de carte bancaire
    PERSON_NAME = "person_name"  # Nom de personne (heuristique)
    IP_ADDRESS = "ip_address"    # Adresse IP


@dataclass(frozen=True)
class EntityPattern:
    """Pattern de détection avec sa catégorie et son regex compilé."""

    category: EntityCategory
    pattern: Pattern[str]
    description: str


# --- Patterns par catégorie ---

# NIR (numéro de sécurité sociale français) : 1 ou 2 + 13 chiffres + clé 2 chiffres
_NIR_PATTERN = re.compile(
    r"\b[12]\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}\b"
)

# SIRET : 14 chiffres (peut être groupé par 3-3-3-5 ou 9-5)
_SIRET_PATTERN = re.compile(
    r"\b\d{3}\s?\d{3}\s?\d{3}\s?\d{5}\b"
)

# SIREN : 9 chiffres
_SIREN_PATTERN = re.compile(
    r"\b\d{3}\s?\d{3}\s?\d{3}\b"
)

# IBAN : code pays (2 lettres) + check (2 chiffres) + jusqu'à 30 alphanum
_IBAN_PATTERN = re.compile(
    r"\b[A-Z]{2}\d{2}\s?(?:\w{4}\s?){2,8}\w{1,4}\b",
    re.IGNORECASE,
)

# Email
_EMAIL_PATTERN = re.compile(
    r"\b[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}\b"
)

# Téléphone français et international
_PHONE_PATTERN = re.compile(
    r"(?:"
    r"(?:\+33|0033)\s?[1-9](?:[\s.\-]?\d{2}){4}"  # FR international
    r"|0[1-9](?:[\s.\-]?\d{2}){4}"                 # FR national
    r"|\+\d{1,3}[\s.\-]?\d{4,14}"                  # International générique
    r")"
)

# Clés API — patterns courants (sk-*, AKIA*, ghp_*, xoxb-*, etc.)
_API_KEY_PATTERN = re.compile(
    r"\b(?:"
    r"sk-[a-zA-Z0-9_\-]{10,}"                  # OpenAI, Anthropic, Stripe
    r"|AKIA[A-Z0-9]{16}"                       # AWS Access Key
    r"|ghp_[a-zA-Z0-9]{36}"                    # GitHub Personal Token
    r"|gho_[a-zA-Z0-9]{36}"                    # GitHub OAuth Token
    r"|github_pat_[a-zA-Z0-9_]{22,}"          # GitHub Fine-grained Token
    r"|xoxb-[a-zA-Z0-9\-]+"                   # Slack Bot Token
    r"|xoxp-[a-zA-Z0-9\-]+"                   # Slack User Token
    r"|AIza[a-zA-Z0-9_\-]{35}"               # Google API Key
    r"|ya29\.[a-zA-Z0-9_\-]+"                 # Google OAuth Token
    r"|glpat-[a-zA-Z0-9\-_]{20,}"            # GitLab Personal Token
    r"|npm_[a-zA-Z0-9]{36}"                    # npm Token
    r"|pypi-[a-zA-Z0-9]{16,}"                 # PyPI Token
    r"|sq0[a-z]{3}-[a-zA-Z0-9\-_]{22,}"      # Square
    r"|AC[a-f0-9]{32}"                         # Twilio Account SID
    r"|SG\.[a-zA-Z0-9_\-]{22}\.[a-zA-Z0-9_\-]{43}"  # SendGrid
    r")\b"
)

# JWT : header.payload.signature (chacun en base64url)
_JWT_PATTERN = re.compile(
    r"\beyJ[a-zA-Z0-9_\-]+\.eyJ[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+\b"
)

# Carte bancaire (Visa, Mastercard, Amex — séparateurs optionnels)
_CREDIT_CARD_PATTERN = re.compile(
    r"\b(?:"
    r"4\d{3}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}"  # Visa
    r"|5[1-5]\d{2}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}"  # Mastercard
    r"|3[47]\d{2}[\s\-]?\d{6}[\s\-]?\d{5}"  # Amex
    r")\b"
)

# Adresse IP v4
_IP_ADDRESS_PATTERN = re.compile(
    r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
)

# Noms de personnes — heuristique basée sur les mots-clés contextuels
# On cherche des mots capitalisés précédés de marqueurs
_PERSON_NAME_PREFIXES = (
    r"(?:Monsieur|Madame|Mademoiselle|M\.|Mme|Mlle|Mr|Mrs|Ms|Dr|Pr|Me)"
    r"|(?:salarié|salariée|employé|employée|dirigeant|dirigeante"
    r"|gérant|gérante|associé|associée|client|cliente"
    r"|bénéficiaire|titulaire|contact|responsable)"
)

# Pattern : marqueur + prénom (éventuellement composé) + nom (mots capitalisés)
# Supporte les prénoms composés avec trait d'union (Jean-Pierre, Marie-Claire, etc.)
_PERSON_NAME_PATTERN = re.compile(
    rf"(?:(?:{_PERSON_NAME_PREFIXES})\s+)"
    r"([A-ZÀ-ÖØ-Þ][a-zà-öø-ÿ]+(?:-[A-ZÀ-ÖØ-Þ][a-zà-öø-ÿ]+)*"
    r"(?:\s+[A-ZÀ-ÖØ-Þ][a-zà-öø-ÿ]+(?:-[A-ZÀ-ÖØ-Þ][a-zà-öø-ÿ]+)*)*"
    r"(?:\s+[A-ZÀ-ÖØ-Þ]{2,})?)",
    re.UNICODE,
)


# --- Registre de tous les patterns ---

ALL_PATTERNS: list[EntityPattern] = [
    EntityPattern(EntityCategory.JWT, _JWT_PATTERN, "JSON Web Token"),
    EntityPattern(EntityCategory.API_KEY, _API_KEY_PATTERN, "Clé API"),
    EntityPattern(EntityCategory.IBAN, _IBAN_PATTERN, "Numéro IBAN"),
    EntityPattern(EntityCategory.NIR, _NIR_PATTERN, "NIR (sécurité sociale)"),
    EntityPattern(EntityCategory.CREDIT_CARD, _CREDIT_CARD_PATTERN, "Carte bancaire"),
    EntityPattern(EntityCategory.SIRET, _SIRET_PATTERN, "Numéro SIRET"),
    EntityPattern(EntityCategory.EMAIL, _EMAIL_PATTERN, "Adresse email"),
    EntityPattern(EntityCategory.PHONE, _PHONE_PATTERN, "Numéro de téléphone"),
    EntityPattern(EntityCategory.IP_ADDRESS, _IP_ADDRESS_PATTERN, "Adresse IP"),
    # SIREN est exclu par défaut car il matche trop de faux positifs (9 chiffres)
    # On le garde disponible pour du matching ciblé
]

# Pattern de noms traité séparément car il utilise des groupes de capture
PERSON_NAME_PATTERN = EntityPattern(
    EntityCategory.PERSON_NAME,
    _PERSON_NAME_PATTERN,
    "Nom de personne (heuristique contextuelle)",
)
