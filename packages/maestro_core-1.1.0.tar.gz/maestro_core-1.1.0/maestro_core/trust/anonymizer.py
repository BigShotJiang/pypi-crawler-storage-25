"""Anonymizer — orchestrateur principal du trust layer.

Gère l'anonymisation et la dé-anonymisation de textes avec trois modes :
- FULL : anonymise tout (noms, identifiants, contacts, secrets)
- STANDARD : anonymise les secrets (API keys, JWT) et identifiants (NIR, IBAN, SIRET)
- OFF : pas d'anonymisation

S'intègre dans la boucle de conversation du harness."""

from __future__ import annotations

import re
from enum import Enum
from .detector import EntityDetector
from .patterns import EntityCategory
from .vault import AnonymizationVault


class TrustMode(str, Enum):
    """Mode de fonctionnement du trust layer."""

    FULL = "full"          # Tout anonymiser (max protection)
    STANDARD = "standard"  # Secrets + identifiants uniquement
    OFF = "off"            # Pas d'anonymisation


# Catégories par mode
_STANDARD_CATEGORIES: set[EntityCategory] = {
    EntityCategory.NIR,
    EntityCategory.SIRET,
    EntityCategory.SIREN,
    EntityCategory.IBAN,
    EntityCategory.API_KEY,
    EntityCategory.JWT,
    EntityCategory.CREDIT_CARD,
}

_FULL_CATEGORIES: set[EntityCategory] = {
    EntityCategory.NIR,
    EntityCategory.SIRET,
    EntityCategory.SIREN,
    EntityCategory.IBAN,
    EntityCategory.EMAIL,
    EntityCategory.PHONE,
    EntityCategory.API_KEY,
    EntityCategory.JWT,
    EntityCategory.CREDIT_CARD,
    EntityCategory.PERSON_NAME,
    EntityCategory.IP_ADDRESS,
}


class Anonymizer:
    """Anonymise et dé-anonymise les textes dans la boucle de conversation.

    Usage type :
        anon = Anonymizer(TrustMode.STANDARD)
        safe_text = anon.anonymize_text(user_message)
        # ... envoyer safe_text au LLM ...
        real_text = anon.deanonymize_text(llm_response)
    """

    def __init__(self, mode: TrustMode = TrustMode.STANDARD) -> None:
        self._mode = mode
        self._vault = AnonymizationVault()

        # Configurer le détecteur selon le mode
        if mode == TrustMode.OFF:
            self._detector = None
            self._categories: set[EntityCategory] = set()
        elif mode == TrustMode.STANDARD:
            self._categories = _STANDARD_CATEGORIES
            self._detector = EntityDetector(
                categories=self._categories,
                detect_names=False,
            )
        else:  # FULL
            self._categories = _FULL_CATEGORIES
            self._detector = EntityDetector(
                categories=self._categories,
                detect_names=True,
            )

    @property
    def mode(self) -> TrustMode:
        """Mode actuel du trust layer."""
        return self._mode

    @property
    def vault(self) -> AnonymizationVault:
        """Accès au vault (pour inspection/debug)."""
        return self._vault

    def anonymize_text(self, text: str) -> str:
        """Anonymise un texte en remplaçant les entités sensibles par des placeholders.

        Utilisé AVANT l'envoi au LLM pour protéger les données."""
        if self._mode == TrustMode.OFF or self._detector is None:
            return text
        if not text:
            return text

        entities = self._detector.detect(text)
        if not entities:
            return text

        # Filtrer par catégories autorisées dans le mode courant
        filtered = [e for e in entities if e.category in self._categories]
        if not filtered:
            return text

        # Remplacer de droite à gauche pour conserver les positions
        result = text
        for entity in reversed(filtered):
            placeholder = self._vault.get_or_create_placeholder(
                entity.value, entity.category
            )
            result = result[:entity.start] + placeholder + result[entity.end:]

        return result

    def deanonymize_text(self, text: str) -> str:
        """Dé-anonymise un texte en remplaçant les placeholders par les valeurs originales.

        Utilisé APRÈS la réception de la réponse du LLM."""
        if self._mode == TrustMode.OFF:
            return text
        if not text:
            return text

        # Chercher tous les placeholders dans le texte
        # Format : [CATEGORY_N]
        placeholder_pattern = re.compile(
            r"\[(?:NIR|SIRET|SIREN|IBAN|EMAIL|PHONE|APIKEY|TOKEN|CARD|PERSONNE|IP|ENTITY)_\d+\]"
        )

        def replace_placeholder(match: re.Match[str]) -> str:
            placeholder = match.group(0)
            original = self._vault.resolve_placeholder(placeholder)
            return original if original is not None else placeholder

        return placeholder_pattern.sub(replace_placeholder, text)

    def anonymize_messages(
        self, messages: list[dict[str, str]]
    ) -> list[dict[str, str]]:
        """Anonymise une liste de messages (format {role, content})."""
        return [
            {**msg, "content": self.anonymize_text(msg.get("content", ""))}
            for msg in messages
        ]

    def deanonymize_messages(
        self, messages: list[dict[str, str]]
    ) -> list[dict[str, str]]:
        """Dé-anonymise une liste de messages."""
        return [
            {**msg, "content": self.deanonymize_text(msg.get("content", ""))}
            for msg in messages
        ]

    def reset(self) -> None:
        """Réinitialise le vault (nouvelle conversation)."""
        self._vault.clear()

    def stats(self) -> dict[str, object]:
        """Retourne des statistiques sur le vault."""
        category_counts: dict[str, int] = {}
        for entry in self._vault.entries:
            key = entry.category.value
            category_counts[key] = category_counts.get(key, 0) + 1
        return {
            "total_entries": self._vault.size,
            "by_category": category_counts,
        }
