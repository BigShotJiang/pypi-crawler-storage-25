"""Trust Layer — anonymisation/dé-anonymisation pour la protection des données sensibles.

S'intègre dans la boucle de conversation :
- Avant envoi au LLM : anonymize les messages user + résultats d'outils
- Après réception du LLM : deanonymize la réponse + arguments d'outils"""

from .anonymizer import Anonymizer, TrustMode
from .detector import EntityDetector
from .vault import AnonymizationVault

__all__ = [
    "Anonymizer",
    "AnonymizationVault",
    "EntityDetector",
    "TrustMode",
]
