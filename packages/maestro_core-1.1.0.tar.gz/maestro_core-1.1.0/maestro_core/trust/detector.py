"""Détecteur d'entités sensibles — regex pur, sans spaCy.

Scanne un texte et retourne les entités détectées avec leur position,
catégorie et valeur originale."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .patterns import (
    ALL_PATTERNS,
    PERSON_NAME_PATTERN,
    EntityCategory,
    EntityPattern,
)


@dataclass(frozen=True)
class DetectedEntity:
    """Entité sensible détectée dans un texte."""

    category: EntityCategory
    value: str          # Valeur originale trouvée dans le texte
    start: int          # Position de début dans le texte
    end: int            # Position de fin dans le texte


class EntityDetector:
    """Détecteur d'entités sensibles par regex.

    Supporte la détection de : NIR, SIRET, IBAN, email, téléphone,
    clés API, JWT, cartes bancaires, adresses IP, et noms de personnes
    (par heuristique contextuelle)."""

    def __init__(
        self,
        categories: Optional[set[EntityCategory]] = None,
        detect_names: bool = True,
    ) -> None:
        """Initialise le détecteur.

        Args:
            categories: catégories à détecter (toutes si None)
            detect_names: activer la détection heuristique de noms
        """
        self._patterns = ALL_PATTERNS
        if categories is not None:
            self._patterns = [
                p for p in ALL_PATTERNS if p.category in categories
            ]
        self._detect_names = detect_names

    def detect(self, text: str) -> list[DetectedEntity]:
        """Détecte toutes les entités sensibles dans un texte.

        Les entités sont retournées triées par position de début.
        Les chevauchements sont résolus en faveur du match le plus long."""
        if not text:
            return []

        entities: list[DetectedEntity] = []

        # Patterns standards
        for ep in self._patterns:
            for match in ep.pattern.finditer(text):
                entities.append(DetectedEntity(
                    category=ep.category,
                    value=match.group(0),
                    start=match.start(),
                    end=match.end(),
                ))

        # Noms de personnes (groupe de capture séparé)
        if self._detect_names:
            for match in PERSON_NAME_PATTERN.pattern.finditer(text):
                # Le groupe 1 contient le nom (sans le préfixe)
                name = match.group(1)
                if name and len(name) > 2:
                    # Trouver la position du nom dans le match complet
                    name_start = match.start(1)
                    name_end = match.end(1)
                    entities.append(DetectedEntity(
                        category=EntityCategory.PERSON_NAME,
                        value=name,
                        start=name_start,
                        end=name_end,
                    ))

        # Trier par position et résoudre les chevauchements
        entities.sort(key=lambda e: (e.start, -(e.end - e.start)))
        return _resolve_overlaps(entities)

    def detect_categories(self, text: str) -> set[EntityCategory]:
        """Retourne uniquement les catégories d'entités présentes dans le texte."""
        return {e.category for e in self.detect(text)}

    def has_sensitive_data(self, text: str) -> bool:
        """Vérifie rapidement si le texte contient des données sensibles."""
        return len(self.detect(text)) > 0


def _resolve_overlaps(entities: list[DetectedEntity]) -> list[DetectedEntity]:
    """Résout les chevauchements en gardant le match le plus long."""
    if not entities:
        return entities

    resolved: list[DetectedEntity] = []
    last_end = -1

    for entity in entities:
        if entity.start >= last_end:
            resolved.append(entity)
            last_end = entity.end
        elif (entity.end - entity.start) > (resolved[-1].end - resolved[-1].start):
            # Le nouveau match est plus long, remplacer le précédent
            resolved[-1] = entity
            last_end = entity.end

    return resolved
