"""Parsing des slash commands — traduit de commands/lib.rs (partie parser)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .specs import slash_command_specs, SlashCommandSpec
from .help import render_slash_command_help_detail


class SlashCommandParseError(Exception):
    """Erreur de parsing d'une slash command."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)

    def __str__(self) -> str:
        return self.message


@dataclass
class SlashCommand:
    """Slash command parsée avec ses arguments."""

    name: str
    args: dict[str, Optional[str]]

    @classmethod
    def parse(cls, input_text: str) -> Optional[SlashCommand]:
        """Parse une ligne d'entrée en SlashCommand. Retourne None si pas une commande."""
        return validate_slash_command_input(input_text)


# --- Commandes parsées spécifiques ---


def validate_slash_command_input(input_text: str) -> Optional[SlashCommand]:
    """Parse et valide une entrée slash command.

    Retourne None si ce n'est pas une commande slash.
    Lève SlashCommandParseError si la commande est malformée.
    """
    trimmed = input_text.strip()
    if not trimmed.startswith("/"):
        return None

    parts = trimmed.lstrip("/").split()
    if not parts:
        raise SlashCommandParseError(
            "Slash command name is missing. Use /help to list available slash commands."
        )

    command = parts[0]
    if not command:
        raise SlashCommandParseError(
            "Slash command name is missing. Use /help to list available slash commands."
        )

    args = parts[1:]
    remainder = _remainder_after_command(trimmed, command)

    # Résoudre les alias
    resolved_command = _resolve_alias(command)

    # Commandes sans arguments
    no_arg_commands = {
        "help", "status", "sandbox", "compact", "commit", "cost", "memory",
        "init", "diff", "version", "doctor", "login", "logout", "vim",
        "upgrade", "stats", "share", "feedback", "files", "fast", "exit",
        "summary", "desktop", "brief", "advisor", "stickers", "insights",
        "thinkback", "release-notes", "security-review", "keybindings",
        "privacy-settings", "debug-tool-call",
    }

    if resolved_command in no_arg_commands:
        _validate_no_args(resolved_command, args)
        return SlashCommand(name=resolved_command, args={})

    # Commandes avec remainder optionnel
    remainder_commands = {
        "bughunter": "scope", "pr": "context", "issue": "context",
        "ultraplan": "task", "export": "path", "plan": "mode",
        "review": "scope", "tasks": "args", "theme": "name",
        "voice": "mode", "usage": "scope", "rename": "name",
        "copy": "target", "hooks": "args", "context": "action",
        "color": "scheme", "effort": "level", "branch": "name",
        "rewind": "steps", "ide": "target", "tag": "label",
        "output-style": "style", "add-dir": "path",
    }

    if resolved_command in remainder_commands:
        arg_name = remainder_commands[resolved_command]
        return SlashCommand(name=resolved_command, args={arg_name: remainder})

    # Commandes avec un seul argument optionnel
    if resolved_command == "model":
        model = _optional_single_arg("model", args, "[model]")
        return SlashCommand(name="model", args={"model": model})

    # Commandes avec logique spéciale
    if resolved_command == "teleport":
        target = _require_remainder("teleport", remainder, "<symbol-or-path>")
        return SlashCommand(name="teleport", args={"target": target})

    if resolved_command == "resume":
        path = _require_remainder("resume", remainder, "<session-path>")
        return SlashCommand(name="resume", args={"session_path": path})

    if resolved_command == "permissions":
        mode = _parse_permissions_mode(args)
        return SlashCommand(name="permissions", args={"mode": mode})

    if resolved_command == "clear":
        confirm = _parse_clear_args(args)
        return SlashCommand(name="clear", args={"confirm": str(confirm)})

    if resolved_command == "config":
        section = _parse_config_section(args)
        return SlashCommand(name="config", args={"section": section})

    if resolved_command == "mcp":
        return _parse_mcp_command(args)

    if resolved_command == "session":
        return _parse_session_command(args)

    if resolved_command in ("plugin", "plugins", "marketplace"):
        return _parse_plugin_command(args)

    if resolved_command == "agents":
        return SlashCommand(name="agents", args={"args": remainder})

    if resolved_command == "skills":
        return SlashCommand(name="skills", args={"args": remainder})

    # Commande inconnue — pas une erreur, juste marquée Unknown
    return SlashCommand(name=resolved_command, args={"raw": remainder})


def _resolve_alias(command: str) -> str:
    """Résout les alias de commandes."""
    aliases = {}
    for spec in slash_command_specs():
        for alias in spec.aliases:
            aliases[alias] = spec.name
    return aliases.get(command, command)


def _validate_no_args(command: str, args: list[str]) -> None:
    """Vérifie qu'il n'y a pas d'arguments."""
    if not args:
        return
    raise _command_error(
        f"Unexpected arguments for /{command}.", command, f"/{command}"
    )


def _optional_single_arg(
    command: str, args: list[str], hint: str
) -> Optional[str]:
    """Parse un argument optionnel unique."""
    if not args:
        return None
    if len(args) == 1:
        return args[0]
    raise _usage_error(command, hint)


def _require_remainder(
    command: str, remainder: Optional[str], hint: str
) -> str:
    """Exige un argument."""
    if remainder:
        return remainder
    raise _usage_error(command, hint)


def _parse_permissions_mode(args: list[str]) -> Optional[str]:
    mode = _optional_single_arg(
        "permissions", args, "[read-only|workspace-write|danger-full-access]"
    )
    if mode is not None:
        valid = {"read-only", "workspace-write", "danger-full-access"}
        if mode not in valid:
            raise _command_error(
                f"Unsupported /permissions mode '{mode}'. Use read-only, workspace-write, or danger-full-access.",
                "permissions",
                "/permissions [read-only|workspace-write|danger-full-access]",
            )
    return mode


def _parse_clear_args(args: list[str]) -> bool:
    if not args:
        return False
    if args == ["--confirm"]:
        return True
    raise _command_error(
        f"Unsupported /clear argument '{args[0]}'. Use /clear or /clear --confirm.",
        "clear", "/clear [--confirm]",
    )


def _parse_config_section(args: list[str]) -> Optional[str]:
    section = _optional_single_arg("config", args, "[env|hooks|model|plugins]")
    if section is not None:
        valid = {"env", "hooks", "model", "plugins"}
        if section not in valid:
            raise _command_error(
                f"Unsupported /config section '{section}'. Use env, hooks, model, or plugins.",
                "config", "/config [env|hooks|model|plugins]",
            )
    return section


def _parse_mcp_command(args: list[str]) -> SlashCommand:
    if not args:
        return SlashCommand(name="mcp", args={"action": None, "target": None})
    if args[0] == "list":
        if len(args) > 1:
            raise _usage_error("mcp list", "")
        return SlashCommand(name="mcp", args={"action": "list", "target": None})
    if args[0] == "show":
        if len(args) < 2:
            raise _usage_error("mcp show", "<server>")
        if len(args) > 2:
            raise _command_error(
                "Unexpected arguments for /mcp show.", "mcp", "/mcp show <server>"
            )
        return SlashCommand(name="mcp", args={"action": "show", "target": args[1]})
    if args[0] in ("help", "-h", "--help"):
        return SlashCommand(name="mcp", args={"action": "help", "target": None})
    raise _command_error(
        f"Unknown /mcp action '{args[0]}'. Use list, show <server>, or help.",
        "mcp", "/mcp [list|show <server>|help]",
    )


def _parse_session_command(args: list[str]) -> SlashCommand:
    if not args:
        return SlashCommand(name="session", args={"action": None, "target": None})
    if args[0] == "list":
        if len(args) > 1:
            raise _usage_error("session", "[list|switch <session-id>|fork [branch-name]]")
        return SlashCommand(name="session", args={"action": "list", "target": None})
    if args[0] == "switch":
        if len(args) < 2:
            raise _usage_error("session switch", "<session-id>")
        if len(args) > 2:
            raise _command_error(
                "Unexpected arguments for /session switch.",
                "session", "/session switch <session-id>",
            )
        return SlashCommand(name="session", args={"action": "switch", "target": args[1]})
    if args[0] == "fork":
        target = args[1] if len(args) > 1 else None
        if len(args) > 2:
            raise _command_error(
                "Unexpected arguments for /session fork.",
                "session", "/session fork [branch-name]",
            )
        return SlashCommand(name="session", args={"action": "fork", "target": target})
    raise _command_error(
        f"Unknown /session action '{args[0]}'. Use list, switch <session-id>, or fork [branch-name].",
        "session", "/session [list|switch <session-id>|fork [branch-name]]",
    )


def _parse_plugin_command(args: list[str]) -> SlashCommand:
    if not args:
        return SlashCommand(name="plugin", args={"action": None, "target": None})
    action = args[0]
    if action == "list":
        if len(args) > 1:
            raise _usage_error("plugin list", "")
        return SlashCommand(name="plugin", args={"action": "list", "target": None})
    if action == "install":
        if len(args) < 2:
            raise _usage_error("plugin install", "<path>")
        return SlashCommand(name="plugin", args={"action": "install", "target": " ".join(args[1:])})
    if action in ("enable", "disable", "uninstall", "update"):
        if len(args) < 2:
            raise _usage_error(f"plugin {action}", f"<{'name' if action in ('enable', 'disable') else 'id'}>")
        if len(args) > 2:
            raise _command_error(
                f"Unexpected arguments for /plugin {action}.",
                "plugin", f"/plugin {action} <{'name' if action in ('enable', 'disable') else 'id'}>",
            )
        return SlashCommand(name="plugin", args={"action": action, "target": args[1]})
    raise _command_error(
        f"Unknown /plugin action '{action}'. Use list, install <path>, enable <name>, disable <name>, uninstall <id>, or update <id>.",
        "plugin",
        "/plugin [list|install <path>|enable <name>|disable <name>|uninstall <id>|update <id>]",
    )


def _remainder_after_command(input_text: str, command: str) -> Optional[str]:
    """Extrait le reste après la commande."""
    stripped = input_text.strip()
    prefix = f"/{command}"
    if stripped.startswith(prefix):
        rest = stripped[len(prefix):].strip()
        return rest if rest else None
    return None


def _usage_error(command: str, hint: str) -> SlashCommandParseError:
    usage = f"/{command} {hint}".rstrip()
    root = command.split()[0] if " " in command else command
    detail = render_slash_command_help_detail(root)
    suffix = f"\n\n{detail}" if detail else ""
    return SlashCommandParseError(f"Usage: {usage}\n  Usage            {usage}{suffix}")


def _command_error(message: str, command: str, usage: str) -> SlashCommandParseError:
    detail = render_slash_command_help_detail(command)
    suffix = f"\n\n{detail}" if detail else ""
    return SlashCommandParseError(f"{message}\n  Usage            {usage}{suffix}")
