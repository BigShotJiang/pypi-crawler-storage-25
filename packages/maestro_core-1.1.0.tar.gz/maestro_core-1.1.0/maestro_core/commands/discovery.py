"""Découverte d'agents, skills et MCP — traduit de commands/lib.rs.

Parcourt les répertoires de configuration pour trouver les
définitions d'agents et de skills.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional


class DefinitionSource(Enum):
    """Source d'une définition (agent ou skill)."""

    PROJECT_CODEX = "Project (.codex)"
    PROJECT_CLAUDE = "Project (.claude)"
    USER_CODEX_HOME = "User ($CODEX_HOME)"
    USER_CODEX = "User (~/.codex)"
    USER_CLAUDE = "User (~/.claude)"


class SkillOrigin(Enum):
    """Origine d'un skill."""

    SKILLS_DIR = "skills"
    LEGACY_COMMANDS_DIR = "commands"


@dataclass
class AgentSummary:
    """Résumé d'un agent découvert."""

    name: str
    description: Optional[str] = None
    model: Optional[str] = None
    reasoning_effort: Optional[str] = None
    source: DefinitionSource = DefinitionSource.USER_CLAUDE
    shadowed_by: Optional[DefinitionSource] = None


@dataclass
class SkillSummary:
    """Résumé d'un skill découvert."""

    name: str
    description: Optional[str] = None
    source: DefinitionSource = DefinitionSource.USER_CLAUDE
    shadowed_by: Optional[DefinitionSource] = None
    origin: SkillOrigin = SkillOrigin.SKILLS_DIR


def discover_agents(cwd: str) -> list[AgentSummary]:
    """Découvre les agents dans les répertoires de configuration."""
    roots = _discover_definition_roots(cwd, "agents")
    return _load_agents_from_roots(roots)


def discover_skills(cwd: str) -> list[SkillSummary]:
    """Découvre les skills dans les répertoires de configuration."""
    roots = _discover_skill_roots(cwd)
    return _load_skills_from_roots(roots)


def render_agents_report(agents: list[AgentSummary]) -> str:
    """Génère un rapport des agents découverts."""
    if not agents:
        return "No agents found."

    active = sum(1 for a in agents if a.shadowed_by is None)
    lines = ["Agents", f"  {active} active agents", ""]

    for source in DefinitionSource:
        group = [a for a in agents if a.source == source]
        if not group:
            continue
        lines.append(f"{source.value}:")
        for agent in group:
            parts = [agent.name]
            if agent.description:
                parts.append(agent.description)
            if agent.model:
                parts.append(agent.model)
            if agent.reasoning_effort:
                parts.append(agent.reasoning_effort)
            detail = " · ".join(parts)
            if agent.shadowed_by:
                lines.append(f"  (shadowed by {agent.shadowed_by.value}) {detail}")
            else:
                lines.append(f"  {detail}")
        lines.append("")

    return "\n".join(lines).rstrip()


def render_skills_report(skills: list[SkillSummary]) -> str:
    """Génère un rapport des skills découverts."""
    if not skills:
        return "No skills found."

    active = sum(1 for s in skills if s.shadowed_by is None)
    lines = ["Skills", f"  {active} available skills", ""]

    for source in DefinitionSource:
        group = [s for s in skills if s.source == source]
        if not group:
            continue
        lines.append(f"{source.value}:")
        for skill in group:
            parts = [skill.name]
            if skill.description:
                parts.append(skill.description)
            if skill.origin == SkillOrigin.LEGACY_COMMANDS_DIR:
                parts.append("legacy /commands")
            detail = " · ".join(parts)
            if skill.shadowed_by:
                lines.append(f"  (shadowed by {skill.shadowed_by.value}) {detail}")
            else:
                lines.append(f"  {detail}")
        lines.append("")

    return "\n".join(lines).rstrip()


# --- Fonctions internes ---


def _discover_definition_roots(
    cwd: str, leaf: str
) -> list[tuple[DefinitionSource, Path]]:
    """Parcourt les ancêtres et les répertoires utilisateur pour trouver les racines."""
    roots: list[tuple[DefinitionSource, Path]] = []
    cwd_path = Path(cwd)

    for ancestor in [cwd_path, *cwd_path.parents]:
        _push_unique(roots, DefinitionSource.PROJECT_CODEX, ancestor / ".codex" / leaf)
        _push_unique(roots, DefinitionSource.PROJECT_CLAUDE, ancestor / ".claude" / leaf)

    codex_home = os.environ.get("CODEX_HOME")
    if codex_home:
        _push_unique(roots, DefinitionSource.USER_CODEX_HOME, Path(codex_home) / leaf)

    home = os.environ.get("HOME")
    if home:
        _push_unique(roots, DefinitionSource.USER_CODEX, Path(home) / ".codex" / leaf)
        _push_unique(roots, DefinitionSource.USER_CLAUDE, Path(home) / ".claude" / leaf)

    return roots


def _discover_skill_roots(cwd: str) -> list[tuple[DefinitionSource, Path, SkillOrigin]]:
    """Découvre les racines de skills (incluant les legacy /commands)."""
    roots: list[tuple[DefinitionSource, Path, SkillOrigin]] = []
    cwd_path = Path(cwd)

    for ancestor in [cwd_path, *cwd_path.parents]:
        for src in (DefinitionSource.PROJECT_CODEX, DefinitionSource.PROJECT_CLAUDE):
            base = ".codex" if "codex" in src.value.lower() else ".claude"
            _push_skill_root(roots, src, ancestor / base / "skills", SkillOrigin.SKILLS_DIR)
            _push_skill_root(roots, src, ancestor / base / "commands", SkillOrigin.LEGACY_COMMANDS_DIR)

    codex_home = os.environ.get("CODEX_HOME")
    if codex_home:
        ch = Path(codex_home)
        _push_skill_root(roots, DefinitionSource.USER_CODEX_HOME, ch / "skills", SkillOrigin.SKILLS_DIR)
        _push_skill_root(roots, DefinitionSource.USER_CODEX_HOME, ch / "commands", SkillOrigin.LEGACY_COMMANDS_DIR)

    home = os.environ.get("HOME")
    if home:
        h = Path(home)
        for src, base in [
            (DefinitionSource.USER_CODEX, ".codex"),
            (DefinitionSource.USER_CLAUDE, ".claude"),
        ]:
            _push_skill_root(roots, src, h / base / "skills", SkillOrigin.SKILLS_DIR)
            _push_skill_root(roots, src, h / base / "commands", SkillOrigin.LEGACY_COMMANDS_DIR)

    return roots


def _push_unique(
    roots: list[tuple[DefinitionSource, Path]],
    source: DefinitionSource,
    path: Path,
) -> None:
    if path.is_dir() and not any(p == path for _, p in roots):
        roots.append((source, path))


def _push_skill_root(
    roots: list[tuple[DefinitionSource, Path, SkillOrigin]],
    source: DefinitionSource,
    path: Path,
    origin: SkillOrigin,
) -> None:
    if path.is_dir() and not any(p == path for _, p, _ in roots):
        roots.append((source, path, origin))


def _load_agents_from_roots(
    roots: list[tuple[DefinitionSource, Path]]
) -> list[AgentSummary]:
    """Charge les agents depuis les racines découvertes."""
    agents: list[AgentSummary] = []
    active: dict[str, DefinitionSource] = {}

    for source, root in roots:
        root_agents: list[AgentSummary] = []
        try:
            for entry in sorted(root.iterdir()):
                if entry.suffix != ".toml":
                    continue
                try:
                    contents = entry.read_text(encoding="utf-8")
                except OSError:
                    continue
                fallback = entry.stem
                root_agents.append(AgentSummary(
                    name=_parse_toml_string(contents, "name") or fallback,
                    description=_parse_toml_string(contents, "description"),
                    model=_parse_toml_string(contents, "model"),
                    reasoning_effort=_parse_toml_string(contents, "model_reasoning_effort"),
                    source=source,
                ))
        except OSError:
            continue

        for agent in root_agents:
            key = agent.name.lower()
            if key in active:
                agent.shadowed_by = active[key]
            else:
                active[key] = agent.source
            agents.append(agent)

    return agents


def _load_skills_from_roots(
    roots: list[tuple[DefinitionSource, Path, SkillOrigin]]
) -> list[SkillSummary]:
    """Charge les skills depuis les racines découvertes."""
    skills: list[SkillSummary] = []
    active: dict[str, DefinitionSource] = {}

    for source, root, origin in roots:
        root_skills: list[SkillSummary] = []
        try:
            for entry in sorted(root.iterdir()):
                if origin == SkillOrigin.SKILLS_DIR:
                    if not entry.is_dir():
                        continue
                    skill_path = entry / "SKILL.md"
                    if not skill_path.is_file():
                        continue
                    try:
                        contents = skill_path.read_text(encoding="utf-8")
                    except OSError:
                        continue
                    name, description = _parse_skill_frontmatter(contents)
                    root_skills.append(SkillSummary(
                        name=name or entry.name,
                        description=description,
                        source=source,
                        origin=origin,
                    ))
                else:  # Legacy commands dir
                    md_path = entry
                    if entry.is_dir():
                        md_path = entry / "SKILL.md"
                        if not md_path.is_file():
                            continue
                    elif entry.suffix.lower() != ".md":
                        continue

                    try:
                        contents = md_path.read_text(encoding="utf-8")
                    except OSError:
                        continue
                    fallback = md_path.stem if md_path.suffix else entry.name
                    name, description = _parse_skill_frontmatter(contents)
                    root_skills.append(SkillSummary(
                        name=name or fallback,
                        description=description,
                        source=source,
                        origin=origin,
                    ))
        except OSError:
            continue

        for skill in root_skills:
            key = skill.name.lower()
            if key in active:
                skill.shadowed_by = active[key]
            else:
                active[key] = skill.source
            skills.append(skill)

    return skills


def _parse_toml_string(contents: str, key: str) -> Optional[str]:
    """Parse une valeur string d'un fichier TOML simplifié."""
    prefix = f"{key} ="
    for line in contents.splitlines():
        trimmed = line.strip()
        if trimmed.startswith("#"):
            continue
        if not trimmed.startswith(prefix):
            continue
        value = trimmed[len(prefix):].strip()
        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
            if value:
                return value
    return None


def _parse_skill_frontmatter(contents: str) -> tuple[Optional[str], Optional[str]]:
    """Parse le frontmatter YAML d'un fichier SKILL.md."""
    lines = contents.splitlines()
    if not lines or lines[0].strip() != "---":
        return None, None

    name: Optional[str] = None
    description: Optional[str] = None

    for line in lines[1:]:
        trimmed = line.strip()
        if trimmed == "---":
            break
        if trimmed.startswith("name:"):
            value = _unquote_frontmatter(trimmed[len("name:"):].strip())
            if value:
                name = value
        elif trimmed.startswith("description:"):
            value = _unquote_frontmatter(trimmed[len("description:"):].strip())
            if value:
                description = value

    return name, description


def _unquote_frontmatter(value: str) -> str:
    """Retire les guillemets d'une valeur frontmatter."""
    for quote in ('"', "'"):
        if value.startswith(quote) and value.endswith(quote) and len(value) >= 2:
            return value[1:-1].strip()
    return value.strip()
