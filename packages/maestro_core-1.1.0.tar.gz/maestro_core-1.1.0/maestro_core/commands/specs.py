"""Spécifications des slash commands — traduit de commands/lib.rs.

Contient les 141 commandes avec leurs métadonnées.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class SlashCommandSpec:
    """Spécification d'une slash command."""

    name: str
    summary: str
    aliases: tuple[str, ...] = ()
    argument_hint: Optional[str] = None
    resume_supported: bool = False


# Toutes les 141 slash commands, dans l'ordre du Rust
SLASH_COMMAND_SPECS: tuple[SlashCommandSpec, ...] = (
    SlashCommandSpec(name="help", summary="Show available slash commands", resume_supported=True),
    SlashCommandSpec(name="status", summary="Show current session status", resume_supported=True),
    SlashCommandSpec(name="sandbox", summary="Show sandbox isolation status", resume_supported=True),
    SlashCommandSpec(name="compact", summary="Compact local session history", resume_supported=True),
    SlashCommandSpec(name="model", summary="Show or switch the active model", argument_hint="[model]"),
    SlashCommandSpec(name="permissions", summary="Show or switch the active permission mode", argument_hint="[read-only|workspace-write|danger-full-access]"),
    SlashCommandSpec(name="clear", summary="Start a fresh local session", argument_hint="[--confirm]", resume_supported=True),
    SlashCommandSpec(name="cost", summary="Show cumulative token usage for this session", resume_supported=True),
    SlashCommandSpec(name="resume", summary="Load a saved session into the REPL", argument_hint="<session-path>"),
    SlashCommandSpec(name="config", summary="Inspect Claude config files or merged sections", argument_hint="[env|hooks|model|plugins]", resume_supported=True),
    SlashCommandSpec(name="mcp", summary="Inspect configured MCP servers", argument_hint="[list|show <server>|help]", resume_supported=True),
    SlashCommandSpec(name="memory", summary="Inspect loaded Claude instruction memory files", resume_supported=True),
    SlashCommandSpec(name="init", summary="Create a starter CLAUDE.md for this repo", resume_supported=True),
    SlashCommandSpec(name="diff", summary="Show git diff for current workspace changes", resume_supported=True),
    SlashCommandSpec(name="version", summary="Show CLI version and build information", resume_supported=True),
    SlashCommandSpec(name="bughunter", summary="Inspect the codebase for likely bugs", argument_hint="[scope]"),
    SlashCommandSpec(name="commit", summary="Generate a commit message and create a git commit"),
    SlashCommandSpec(name="pr", summary="Draft or create a pull request from the conversation", argument_hint="[context]"),
    SlashCommandSpec(name="issue", summary="Draft or create a GitHub issue from the conversation", argument_hint="[context]"),
    SlashCommandSpec(name="ultraplan", summary="Run a deep planning prompt with multi-step reasoning", argument_hint="[task]"),
    SlashCommandSpec(name="teleport", summary="Jump to a file or symbol by searching the workspace", argument_hint="<symbol-or-path>"),
    SlashCommandSpec(name="debug-tool-call", summary="Replay the last tool call with debug details"),
    SlashCommandSpec(name="export", summary="Export the current conversation to a file", argument_hint="[file]", resume_supported=True),
    SlashCommandSpec(name="session", summary="List, switch, or fork managed local sessions", argument_hint="[list|switch <session-id>|fork [branch-name]]"),
    SlashCommandSpec(name="plugin", summary="Manage Claw Code plugins", aliases=("plugins", "marketplace"), argument_hint="[list|install <path>|enable <name>|disable <name>|uninstall <id>|update <id>]"),
    SlashCommandSpec(name="agents", summary="List configured agents", argument_hint="[list|help]", resume_supported=True),
    SlashCommandSpec(name="skills", summary="List or install available skills", argument_hint="[list|install <path>|help]", resume_supported=True),
    SlashCommandSpec(name="doctor", summary="Diagnose setup issues and environment health", resume_supported=True),
    SlashCommandSpec(name="login", summary="Log in to the service"),
    SlashCommandSpec(name="logout", summary="Log out of the current session"),
    SlashCommandSpec(name="plan", summary="Toggle or inspect planning mode", argument_hint="[on|off]", resume_supported=True),
    SlashCommandSpec(name="review", summary="Run a code review on current changes", argument_hint="[scope]"),
    SlashCommandSpec(name="tasks", summary="List and manage background tasks", argument_hint="[list|get <id>|stop <id>]", resume_supported=True),
    SlashCommandSpec(name="theme", summary="Switch the terminal color theme", argument_hint="[theme-name]", resume_supported=True),
    SlashCommandSpec(name="vim", summary="Toggle vim keybinding mode", resume_supported=True),
    SlashCommandSpec(name="voice", summary="Toggle voice input mode", argument_hint="[on|off]"),
    SlashCommandSpec(name="upgrade", summary="Check for and install CLI updates"),
    SlashCommandSpec(name="usage", summary="Show detailed API usage statistics", resume_supported=True),
    SlashCommandSpec(name="stats", summary="Show workspace and session statistics", resume_supported=True),
    SlashCommandSpec(name="rename", summary="Rename the current session", argument_hint="<name>"),
    SlashCommandSpec(name="copy", summary="Copy conversation or output to clipboard", argument_hint="[last|all]", resume_supported=True),
    SlashCommandSpec(name="share", summary="Share the current conversation"),
    SlashCommandSpec(name="feedback", summary="Submit feedback about the current session"),
    SlashCommandSpec(name="hooks", summary="List and manage lifecycle hooks", argument_hint="[list|run <hook>]", resume_supported=True),
    SlashCommandSpec(name="files", summary="List files in the current context window", resume_supported=True),
    SlashCommandSpec(name="context", summary="Inspect or manage the conversation context", argument_hint="[show|clear]", resume_supported=True),
    SlashCommandSpec(name="color", summary="Configure terminal color settings", argument_hint="[scheme]", resume_supported=True),
    SlashCommandSpec(name="effort", summary="Set the effort level for responses", argument_hint="[low|medium|high]", resume_supported=True),
    SlashCommandSpec(name="fast", summary="Toggle fast/concise response mode", resume_supported=True),
    SlashCommandSpec(name="exit", summary="Exit the REPL session"),
    SlashCommandSpec(name="branch", summary="Create or switch git branches", argument_hint="[name]"),
    SlashCommandSpec(name="rewind", summary="Rewind the conversation to a previous state", argument_hint="[steps]"),
    SlashCommandSpec(name="summary", summary="Generate a summary of the conversation", resume_supported=True),
    SlashCommandSpec(name="desktop", summary="Open or manage the desktop app integration"),
    SlashCommandSpec(name="ide", summary="Open or configure IDE integration", argument_hint="[vscode|cursor]"),
    SlashCommandSpec(name="tag", summary="Tag the current conversation point", argument_hint="[label]", resume_supported=True),
    SlashCommandSpec(name="brief", summary="Toggle brief output mode", resume_supported=True),
    SlashCommandSpec(name="advisor", summary="Toggle advisor mode for guidance-only responses", resume_supported=True),
    SlashCommandSpec(name="stickers", summary="Browse and manage sticker packs", resume_supported=True),
    SlashCommandSpec(name="insights", summary="Show AI-generated insights about the session", resume_supported=True),
    SlashCommandSpec(name="thinkback", summary="Replay the thinking process of the last response", resume_supported=True),
    SlashCommandSpec(name="release-notes", summary="Generate release notes from recent changes"),
    SlashCommandSpec(name="security-review", summary="Run a security review on the codebase", argument_hint="[scope]"),
    SlashCommandSpec(name="keybindings", summary="Show or configure keyboard shortcuts", resume_supported=True),
    SlashCommandSpec(name="privacy-settings", summary="View or modify privacy settings", resume_supported=True),
    SlashCommandSpec(name="output-style", summary="Switch output formatting style", argument_hint="[style]", resume_supported=True),
    SlashCommandSpec(name="add-dir", summary="Add an additional directory to the context", argument_hint="<path>"),
    SlashCommandSpec(name="allowed-tools", summary="Show or modify the allowed tools list", argument_hint="[add|remove|list] [tool]", resume_supported=True),
    SlashCommandSpec(name="api-key", summary="Show or set the Anthropic API key", argument_hint="[key]"),
    SlashCommandSpec(name="approve", summary="Approve a pending tool execution", aliases=("yes", "y")),
    SlashCommandSpec(name="deny", summary="Deny a pending tool execution", aliases=("no", "n")),
    SlashCommandSpec(name="undo", summary="Undo the last file write or edit"),
    SlashCommandSpec(name="stop", summary="Stop the current generation"),
    SlashCommandSpec(name="retry", summary="Retry the last failed message"),
    SlashCommandSpec(name="paste", summary="Paste clipboard content as input"),
    SlashCommandSpec(name="screenshot", summary="Take a screenshot and add to conversation"),
    SlashCommandSpec(name="image", summary="Add an image file to the conversation", argument_hint="<path>"),
    SlashCommandSpec(name="terminal-setup", summary="Configure terminal integration settings", resume_supported=True),
    SlashCommandSpec(name="search", summary="Search files in the workspace", argument_hint="<query>"),
    SlashCommandSpec(name="listen", summary="Listen for voice input"),
    SlashCommandSpec(name="speak", summary="Read the last response aloud"),
    SlashCommandSpec(name="language", summary="Set the interface language", argument_hint="[language]", resume_supported=True),
    SlashCommandSpec(name="profile", summary="Show or switch user profile", argument_hint="[name]"),
    SlashCommandSpec(name="max-tokens", summary="Show or set the max output tokens", argument_hint="[count]", resume_supported=True),
    SlashCommandSpec(name="temperature", summary="Show or set the sampling temperature", argument_hint="[value]", resume_supported=True),
    SlashCommandSpec(name="system-prompt", summary="Show the active system prompt", resume_supported=True),
    SlashCommandSpec(name="tool-details", summary="Show detailed info about a specific tool", argument_hint="<tool-name>", resume_supported=True),
    SlashCommandSpec(name="format", summary="Format the last response in a different style", argument_hint="[markdown|plain|json]"),
    SlashCommandSpec(name="pin", summary="Pin a message to persist across compaction", argument_hint="[message-index]"),
    SlashCommandSpec(name="unpin", summary="Unpin a previously pinned message", argument_hint="[message-index]"),
    SlashCommandSpec(name="bookmarks", summary="List or manage conversation bookmarks", argument_hint="[add|remove|list]", resume_supported=True),
    SlashCommandSpec(name="workspace", summary="Show or change the working directory", aliases=("cwd",), argument_hint="[path]", resume_supported=True),
    SlashCommandSpec(name="history", summary="Show conversation history summary", argument_hint="[count]", resume_supported=True),
    SlashCommandSpec(name="tokens", summary="Show token count for the current conversation", resume_supported=True),
    SlashCommandSpec(name="cache", summary="Show prompt cache statistics", resume_supported=True),
    SlashCommandSpec(name="providers", summary="List available model providers", resume_supported=True),
    SlashCommandSpec(name="notifications", summary="Show or configure notification settings", argument_hint="[on|off|status]", resume_supported=True),
    SlashCommandSpec(name="changelog", summary="Show recent changes to the codebase", argument_hint="[count]", resume_supported=True),
    SlashCommandSpec(name="test", summary="Run tests for the current project", argument_hint="[filter]"),
    SlashCommandSpec(name="lint", summary="Run linting for the current project", argument_hint="[filter]"),
    SlashCommandSpec(name="build", summary="Build the current project", argument_hint="[target]"),
    SlashCommandSpec(name="run", summary="Run a command in the project context", argument_hint="<command>"),
    SlashCommandSpec(name="git", summary="Run a git command in the workspace", argument_hint="<subcommand>"),
    SlashCommandSpec(name="stash", summary="Stash or unstash workspace changes", argument_hint="[pop|list|apply]"),
    SlashCommandSpec(name="blame", summary="Show git blame for a file", argument_hint="<file> [line]", resume_supported=True),
    SlashCommandSpec(name="log", summary="Show git log for the workspace", argument_hint="[count]", resume_supported=True),
    SlashCommandSpec(name="cron", summary="Manage scheduled tasks", argument_hint="[list|add|remove]", resume_supported=True),
    SlashCommandSpec(name="team", summary="Manage agent teams", argument_hint="[list|create|delete]", resume_supported=True),
    SlashCommandSpec(name="benchmark", summary="Run performance benchmarks", argument_hint="[suite]"),
    SlashCommandSpec(name="migrate", summary="Run pending data migrations"),
    SlashCommandSpec(name="reset", summary="Reset configuration to defaults", argument_hint="[section]"),
    SlashCommandSpec(name="telemetry", summary="Show or configure telemetry settings", argument_hint="[on|off|status]", resume_supported=True),
    SlashCommandSpec(name="env", summary="Show environment variables visible to tools", resume_supported=True),
    SlashCommandSpec(name="project", summary="Show project detection info", resume_supported=True),
    SlashCommandSpec(name="templates", summary="List or apply prompt templates", argument_hint="[list|apply <name>]"),
    SlashCommandSpec(name="explain", summary="Explain a file or code snippet", argument_hint="<path> [line-range]"),
    SlashCommandSpec(name="refactor", summary="Suggest refactoring for a file or function", argument_hint="<path> [scope]"),
    SlashCommandSpec(name="docs", summary="Generate or show documentation", argument_hint="[path]"),
    SlashCommandSpec(name="fix", summary="Fix errors in a file or project", argument_hint="[path]"),
    SlashCommandSpec(name="perf", summary="Analyze performance of a function or file", argument_hint="<path>"),
    SlashCommandSpec(name="chat", summary="Switch to free-form chat mode"),
    SlashCommandSpec(name="focus", summary="Focus context on specific files or directories", argument_hint="<path> [path...]"),
    SlashCommandSpec(name="unfocus", summary="Remove focus from files or directories", argument_hint="[path...]"),
    SlashCommandSpec(name="web", summary="Fetch and summarize a web page", argument_hint="<url>"),
    SlashCommandSpec(name="map", summary="Show a visual map of the codebase structure", argument_hint="[depth]", resume_supported=True),
    SlashCommandSpec(name="symbols", summary="List symbols (functions, classes, etc.) in a file", argument_hint="<path>", resume_supported=True),
    SlashCommandSpec(name="references", summary="Find all references to a symbol", argument_hint="<symbol>"),
    SlashCommandSpec(name="definition", summary="Go to the definition of a symbol", argument_hint="<symbol>"),
    SlashCommandSpec(name="hover", summary="Show hover information for a symbol", argument_hint="<symbol>", resume_supported=True),
    SlashCommandSpec(name="diagnostics", summary="Show LSP diagnostics for a file", argument_hint="[path]", resume_supported=True),
    SlashCommandSpec(name="autofix", summary="Auto-fix all fixable diagnostics", argument_hint="[path]"),
    SlashCommandSpec(name="multi", summary="Execute multiple slash commands in sequence", argument_hint="<commands>"),
    SlashCommandSpec(name="macro", summary="Record or replay command macros", argument_hint="[record|stop|play <name>]"),
    SlashCommandSpec(name="alias", summary="Create a command alias", argument_hint="<name> <command>", resume_supported=True),
    SlashCommandSpec(name="parallel", summary="Run commands in parallel subagents", argument_hint="<count> <prompt>"),
    SlashCommandSpec(name="agent", summary="Manage sub-agents and spawned sessions", argument_hint="[list|spawn|kill]", resume_supported=True),
    SlashCommandSpec(name="subagent", summary="Control active subagent execution", argument_hint="[list|steer <target> <msg>|kill <id>]", resume_supported=True),
    SlashCommandSpec(name="reasoning", summary="Toggle extended reasoning mode", argument_hint="[on|off|stream]", resume_supported=True),
    SlashCommandSpec(name="budget", summary="Show or set token budget limits", argument_hint="[show|set <limit>]", resume_supported=True),
    SlashCommandSpec(name="rate-limit", summary="Configure API rate limiting", argument_hint="[status|set <rpm>]", resume_supported=True),
    SlashCommandSpec(name="metrics", summary="Show performance and usage metrics", resume_supported=True),
)


def slash_command_specs() -> tuple[SlashCommandSpec, ...]:
    """Retourne toutes les spécifications de slash commands."""
    return SLASH_COMMAND_SPECS


def resume_supported_slash_commands() -> list[SlashCommandSpec]:
    """Retourne les commandes supportant --resume."""
    return [spec for spec in SLASH_COMMAND_SPECS if spec.resume_supported]
