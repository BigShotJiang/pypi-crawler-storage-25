"""Aide et suggestions de slash commands — traduit de commands/lib.rs."""

from __future__ import annotations

from typing import Optional

from .specs import slash_command_specs, SlashCommandSpec


def render_slash_command_help() -> str:
    """Génère l'aide complète des slash commands."""
    lines = [
        "Slash commands",
        "  Start here        /status, /diff, /agents, /skills, /commit",
        "  [resume]          also works with --resume SESSION.jsonl",
        "",
    ]

    categories = [
        "Session & visibility",
        "Workspace & git",
        "Discovery & debugging",
        "Analysis & automation",
    ]

    for category in categories:
        lines.append(category)
        for spec in slash_command_specs():
            if _slash_command_category(spec.name) == category:
                lines.append(_format_slash_command_help_line(spec))
        lines.append("")

    # Retirer les lignes vides finales
    while lines and not lines[-1]:
        lines.pop()

    return "\n".join(lines)


def render_slash_command_help_detail(name: str) -> Optional[str]:
    """Génère l'aide détaillée pour une commande spécifique."""
    spec = _find_slash_command_spec(name)
    if spec is None:
        return None
    return "\n".join(_slash_command_detail_lines(spec))


def suggest_slash_commands(input_text: str, limit: int = 5) -> list[str]:
    """Suggère des commandes basées sur un input partiel."""
    query = input_text.strip().lstrip("/").lower()
    if not query or limit == 0:
        return []

    suggestions: list[tuple[int, int, int, str]] = []
    for spec in slash_command_specs():
        candidates = [spec.name] + list(spec.aliases)
        best = None
        for candidate in candidates:
            candidate_lower = candidate.lower()
            if candidate_lower.startswith(query) or query.startswith(candidate_lower):
                prefix_rank = 0
            elif query in candidate_lower or candidate_lower in query:
                prefix_rank = 1
            else:
                prefix_rank = 2
            distance = _levenshtein_distance(candidate_lower, query)
            score = (prefix_rank, distance)
            if best is None or score < best:
                best = score

        if best is not None:
            prefix_rank, distance = best
            if prefix_rank <= 1 or distance <= 2:
                suggestions.append((prefix_rank, distance, len(spec.name), spec.name))

    suggestions.sort()
    return [f"/{name}" for _, _, _, name in suggestions[:limit]]


# --- Helpers internes ---


def _find_slash_command_spec(name: str) -> Optional[SlashCommandSpec]:
    """Trouve une spécification par nom ou alias."""
    name_lower = name.lower()
    for spec in slash_command_specs():
        if spec.name.lower() == name_lower:
            return spec
        if any(alias.lower() == name_lower for alias in spec.aliases):
            return spec
    return None


def _slash_command_usage(spec: SlashCommandSpec) -> str:
    """Formate l'usage d'une commande."""
    if spec.argument_hint:
        return f"/{spec.name} {spec.argument_hint}"
    return f"/{spec.name}"


def _slash_command_detail_lines(spec: SlashCommandSpec) -> list[str]:
    """Génère les lignes de détail d'une commande."""
    lines = [f"/{spec.name}"]
    lines.append(f"  Summary          {spec.summary}")
    lines.append(f"  Usage            {_slash_command_usage(spec)}")
    lines.append(f"  Category         {_slash_command_category(spec.name)}")
    if spec.aliases:
        alias_str = ", ".join(f"/{a}" for a in spec.aliases)
        lines.append(f"  Aliases          {alias_str}")
    if spec.resume_supported:
        lines.append("  Resume           Supported with --resume SESSION.jsonl")
    return lines


def _format_slash_command_help_line(spec: SlashCommandSpec) -> str:
    """Formate une ligne d'aide pour une commande."""
    name = _slash_command_usage(spec)
    alias_suffix = ""
    if spec.aliases:
        alias_str = ", ".join(f"/{a}" for a in spec.aliases)
        alias_suffix = f" (aliases: {alias_str})"
    resume = " [resume]" if spec.resume_supported else ""
    return f"  {name:<66} {spec.summary}{alias_suffix}{resume}"


def _slash_command_category(name: str) -> str:
    """Retourne la catégorie d'une commande."""
    session_visibility = {
        "help", "status", "sandbox", "model", "permissions", "cost", "resume",
        "session", "version", "login", "logout", "usage", "stats", "rename",
        "privacy-settings",
    }
    workspace_git = {
        "compact", "clear", "config", "memory", "init", "diff", "commit", "pr",
        "issue", "export", "plugin", "branch", "add-dir", "files", "hooks",
        "release-notes",
    }
    discovery = {
        "agents", "skills", "teleport", "debug-tool-call", "mcp", "context",
        "tasks", "doctor", "ide", "desktop",
    }
    analysis = {
        "bughunter", "ultraplan", "review", "security-review", "advisor", "insights",
    }
    appearance = {
        "theme", "vim", "voice", "color", "effort", "fast", "brief",
        "output-style", "keybindings", "stickers",
    }
    communication = {
        "copy", "share", "feedback", "summary", "tag", "thinkback", "plan",
        "exit", "upgrade", "rewind",
    }

    if name in session_visibility:
        return "Session & visibility"
    if name in workspace_git:
        return "Workspace & git"
    if name in discovery:
        return "Discovery & debugging"
    if name in analysis:
        return "Analysis & automation"
    if name in appearance:
        return "Appearance & input"
    if name in communication:
        return "Communication & control"
    return "Other"


def _levenshtein_distance(left: str, right: str) -> int:
    """Calcule la distance de Levenshtein entre deux chaînes."""
    if left == right:
        return 0
    if not left:
        return len(right)
    if not right:
        return len(left)

    right_chars = list(right)
    previous = list(range(len(right_chars) + 1))
    current = [0] * (len(right_chars) + 1)

    for left_index, left_char in enumerate(left):
        current[0] = left_index + 1
        for right_index, right_char in enumerate(right_chars):
            substitution_cost = 0 if left_char == right_char else 1
            current[right_index + 1] = min(
                current[right_index] + 1,
                previous[right_index + 1] + 1,
                previous[right_index] + substitution_cost,
            )
        previous = list(current)

    return previous[len(right_chars)]
