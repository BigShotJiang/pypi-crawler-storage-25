"""Registre de commandes — traduit de commands/lib.rs (partie registre)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class CommandSource(Enum):
    """Source d'une commande."""

    BUILTIN = "builtin"
    INTERNAL_ONLY = "internal_only"
    FEATURE_GATED = "feature_gated"


@dataclass
class CommandManifestEntry:
    """Entrée du manifeste de commandes."""

    name: str
    source: CommandSource


@dataclass
class CommandRegistry:
    """Registre de commandes disponibles."""

    entries: list[CommandManifestEntry] = field(default_factory=list)
