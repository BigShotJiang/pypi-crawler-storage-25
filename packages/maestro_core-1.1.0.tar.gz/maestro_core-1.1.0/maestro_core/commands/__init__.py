"""Package commands — traduit de commands/lib.rs.

Fournit les slash commands, leur parsing, leur exécution,
et les commandes de gestion (plugins, agents, skills, MCP).
"""

from .specs import (
    SlashCommandSpec,
    SLASH_COMMAND_SPECS,
    slash_command_specs,
    resume_supported_slash_commands,
)
from .parser import (
    SlashCommand,
    SlashCommandParseError,
    validate_slash_command_input,
)
from .registry import (
    CommandManifestEntry,
    CommandRegistry,
    CommandSource,
)
from .help import (
    render_slash_command_help,
    render_slash_command_help_detail,
    suggest_slash_commands,
)
from .handler import (
    SlashCommandResult,
    handle_slash_command,
)

__all__ = [
    "CommandManifestEntry",
    "CommandRegistry",
    "CommandSource",
    "SlashCommand",
    "SlashCommandParseError",
    "SlashCommandResult",
    "SlashCommandSpec",
    "SLASH_COMMAND_SPECS",
    "handle_slash_command",
    "render_slash_command_help",
    "render_slash_command_help_detail",
    "resume_supported_slash_commands",
    "slash_command_specs",
    "suggest_slash_commands",
    "validate_slash_command_input",
]
