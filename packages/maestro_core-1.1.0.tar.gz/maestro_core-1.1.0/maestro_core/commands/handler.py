"""Handler des slash commands — traduit de commands/lib.rs (partie handle_slash_command)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from .parser import SlashCommand, SlashCommandParseError
from .help import render_slash_command_help


@dataclass
class SlashCommandResult:
    """Résultat de l'exécution d'une slash command."""

    message: str
    session: Any  # Session object


def handle_slash_command(
    input_text: str,
    session: Any,
    compaction_config: Optional[Any] = None,
) -> Optional[SlashCommandResult]:
    """Gère une slash command.

    Retourne None si la commande n'est pas gérée localement
    (elle sera transmise au runtime).
    """
    try:
        command = SlashCommand.parse(input_text)
    except SlashCommandParseError as error:
        return SlashCommandResult(message=str(error), session=session)

    if command is None:
        return None

    # Commandes gérées localement
    if command.name == "help":
        return SlashCommandResult(
            message=render_slash_command_help(),
            session=session,
        )

    if command.name == "compact":
        # La compaction dépend du runtime Session
        # Ici on fournit le dispatch
        try:
            if hasattr(session, "compact"):
                result = session.compact(compaction_config)
                if result.removed_message_count == 0:
                    message = "Compaction skipped: session is below the compaction threshold."
                else:
                    message = f"Compacted {result.removed_message_count} messages into a resumable system summary."
                return SlashCommandResult(message=message, session=result.compacted_session)
            return SlashCommandResult(
                message="Compaction requires a session with compact() method.",
                session=session,
            )
        except Exception as e:
            return SlashCommandResult(message=f"Compaction failed: {e}", session=session)

    # Commandes transmises au runtime (retournent None)
    handled_locally = {"help", "compact"}
    if command.name not in handled_locally:
        return None

    return None


# --- Gestion des plugins, agents, skills, MCP ---


def handle_agents_slash_command(args: Optional[str], cwd: str) -> str:
    """Gère la commande /agents."""
    from .discovery import discover_agents, render_agents_report
    return render_agents_report(discover_agents(cwd))


def handle_skills_slash_command(args: Optional[str], cwd: str) -> str:
    """Gère la commande /skills."""
    from .discovery import discover_skills, render_skills_report
    return render_skills_report(discover_skills(cwd))
