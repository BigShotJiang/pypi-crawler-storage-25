"""Mock Anthropic Service — serveur FastAPI simulant l'API Messages pour les tests de parité.

Le serveur détecte le scénario à partir du texte du message utilisateur
(préfixé par PARITY_SCENARIO:) et retourne la réponse appropriée :
texte simple, tool_use ou erreurs, en mode streaming (SSE) ou non."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import PlainTextResponse, StreamingResponse

SCENARIO_PREFIX = "PARITY_SCENARIO:"
DEFAULT_MODEL = "claude-sonnet-4-6"


# ── Scénarios ──


class Scenario(str, Enum):
    STREAMING_TEXT = "streaming_text"
    READ_FILE_ROUNDTRIP = "read_file_roundtrip"
    GREP_CHUNK_ASSEMBLY = "grep_chunk_assembly"
    WRITE_FILE_ALLOWED = "write_file_allowed"
    WRITE_FILE_DENIED = "write_file_denied"
    MULTI_TOOL_TURN_ROUNDTRIP = "multi_tool_turn_roundtrip"
    BASH_STDOUT_ROUNDTRIP = "bash_stdout_roundtrip"
    BASH_PERMISSION_PROMPT_APPROVED = "bash_permission_prompt_approved"
    BASH_PERMISSION_PROMPT_DENIED = "bash_permission_prompt_denied"
    PLUGIN_TOOL_ROUNDTRIP = "plugin_tool_roundtrip"
    AUTO_COMPACT_TRIGGERED = "auto_compact_triggered"
    TOKEN_COST_REPORTING = "token_cost_reporting"

    @classmethod
    def parse(cls, value: str) -> Scenario | None:
        try:
            return cls(value.strip())
        except ValueError:
            return None


REQUEST_IDS: dict[Scenario, str] = {
    Scenario.STREAMING_TEXT: "req_streaming_text",
    Scenario.READ_FILE_ROUNDTRIP: "req_read_file_roundtrip",
    Scenario.GREP_CHUNK_ASSEMBLY: "req_grep_chunk_assembly",
    Scenario.WRITE_FILE_ALLOWED: "req_write_file_allowed",
    Scenario.WRITE_FILE_DENIED: "req_write_file_denied",
    Scenario.MULTI_TOOL_TURN_ROUNDTRIP: "req_multi_tool_turn_roundtrip",
    Scenario.BASH_STDOUT_ROUNDTRIP: "req_bash_stdout_roundtrip",
    Scenario.BASH_PERMISSION_PROMPT_APPROVED: "req_bash_permission_prompt_approved",
    Scenario.BASH_PERMISSION_PROMPT_DENIED: "req_bash_permission_prompt_denied",
    Scenario.PLUGIN_TOOL_ROUNDTRIP: "req_plugin_tool_roundtrip",
    Scenario.AUTO_COMPACT_TRIGGERED: "req_auto_compact_triggered",
    Scenario.TOKEN_COST_REPORTING: "req_token_cost_reporting",
}


# ── Requêtes capturées ──


@dataclass
class CapturedRequest:
    method: str
    path: str
    headers: dict[str, str]
    scenario: str
    stream: bool
    raw_body: str


# ── Helpers d'extraction ──


def _detect_scenario(body: dict[str, Any]) -> Scenario | None:
    """Détecte le scénario de parité depuis le dernier message texte contenant le préfixe."""
    for message in reversed(body.get("messages", [])):
        for block in reversed(message.get("content", [])):
            if isinstance(block, dict) and block.get("type") == "text":
                for token in block.get("text", "").split():
                    if token.startswith(SCENARIO_PREFIX):
                        return Scenario.parse(token[len(SCENARIO_PREFIX):])
            elif isinstance(block, str):
                for token in block.split():
                    if token.startswith(SCENARIO_PREFIX):
                        return Scenario.parse(token[len(SCENARIO_PREFIX):])
    return None


def _latest_tool_result(body: dict[str, Any]) -> tuple[str, bool] | None:
    """Extrait le dernier tool_result du message."""
    for message in reversed(body.get("messages", [])):
        for block in reversed(message.get("content", [])):
            if isinstance(block, dict) and block.get("type") == "tool_result":
                content = block.get("content", [])
                text = _flatten_tool_result_content(content)
                is_error = block.get("is_error", False)
                return text, is_error
    return None


def _tool_results_by_name(body: dict[str, Any]) -> dict[str, tuple[str, bool]]:
    """Map tool_name -> (output, is_error) pour tous les tool_results."""
    tool_names_by_id: dict[str, str] = {}
    for message in body.get("messages", []):
        for block in message.get("content", []):
            if isinstance(block, dict) and block.get("type") == "tool_use":
                tool_names_by_id[block["id"]] = block["name"]

    results: dict[str, tuple[str, bool]] = {}
    for message in reversed(body.get("messages", [])):
        for block in reversed(message.get("content", [])):
            if isinstance(block, dict) and block.get("type") == "tool_result":
                tool_use_id = block.get("tool_use_id", "")
                tool_name = tool_names_by_id.get(tool_use_id, tool_use_id)
                if tool_name not in results:
                    content = _flatten_tool_result_content(block.get("content", []))
                    is_error = block.get("is_error", False)
                    results[tool_name] = (content, is_error)
    return results


def _flatten_tool_result_content(content: list[Any] | str) -> str:
    if isinstance(content, str):
        return content
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif "value" in block:
                parts.append(json.dumps(block["value"]))
        elif isinstance(block, str):
            parts.append(block)
    return "\n".join(parts)


def _extract_read_content(tool_output: str) -> str:
    try:
        data = json.loads(tool_output)
        return data.get("file", {}).get("content", tool_output.strip())
    except (json.JSONDecodeError, TypeError):
        return tool_output.strip()


def _extract_num_matches(tool_output: str) -> int:
    try:
        data = json.loads(tool_output)
        return int(data.get("numMatches", 0))
    except (json.JSONDecodeError, TypeError, ValueError):
        return 0


def _extract_file_path(tool_output: str) -> str:
    try:
        data = json.loads(tool_output)
        return data.get("filePath", tool_output.strip())
    except (json.JSONDecodeError, TypeError):
        return tool_output.strip()


def _extract_bash_stdout(tool_output: str) -> str:
    try:
        data = json.loads(tool_output)
        return data.get("stdout", tool_output.strip())
    except (json.JSONDecodeError, TypeError):
        return tool_output.strip()


def _extract_plugin_message(tool_output: str) -> str:
    try:
        data = json.loads(tool_output)
        return data.get("input", {}).get("message", tool_output.strip())
    except (json.JSONDecodeError, TypeError):
        return tool_output.strip()


def _unique_message_id() -> str:
    return f"msg_{int(time.time() * 1_000_000_000)}"


# ── Builders de réponse ──


def _usage_json(input_tokens: int = 10, output_tokens: int = 6) -> dict[str, int]:
    return {
        "input_tokens": input_tokens,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "output_tokens": output_tokens,
    }


def _text_message_response(
    msg_id: str,
    text: str,
    input_tokens: int = 10,
    output_tokens: int = 6,
) -> dict[str, Any]:
    return {
        "id": msg_id,
        "type": "message",
        "role": "assistant",
        "content": [{"type": "text", "text": text}],
        "model": DEFAULT_MODEL,
        "stop_reason": "end_turn",
        "stop_sequence": None,
        "usage": _usage_json(input_tokens, output_tokens),
    }


def _tool_message_response(
    msg_id: str,
    tool_id: str,
    tool_name: str,
    input_data: dict[str, Any],
) -> dict[str, Any]:
    return _tool_message_response_many(msg_id, [(tool_id, tool_name, input_data)])


def _tool_message_response_many(
    msg_id: str,
    tool_uses: list[tuple[str, str, dict[str, Any]]],
) -> dict[str, Any]:
    content = [
        {"type": "tool_use", "id": tid, "name": tname, "input": tinput}
        for tid, tname, tinput in tool_uses
    ]
    return {
        "id": msg_id,
        "type": "message",
        "role": "assistant",
        "content": content,
        "model": DEFAULT_MODEL,
        "stop_reason": "tool_use",
        "stop_sequence": None,
        "usage": _usage_json(10, 3),
    }


# ── SSE Builders ──


def _sse_event(event: str, data: Any) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def _streaming_text_sse() -> str:
    body = ""
    body += _sse_event("message_start", {
        "type": "message_start",
        "message": {
            "id": "msg_streaming_text", "type": "message", "role": "assistant",
            "content": [], "model": DEFAULT_MODEL, "stop_reason": None,
            "stop_sequence": None, "usage": _usage_json(11, 0),
        },
    })
    body += _sse_event("content_block_start", {
        "type": "content_block_start", "index": 0,
        "content_block": {"type": "text", "text": ""},
    })
    body += _sse_event("content_block_delta", {
        "type": "content_block_delta", "index": 0,
        "delta": {"type": "text_delta", "text": "Mock streaming "},
    })
    body += _sse_event("content_block_delta", {
        "type": "content_block_delta", "index": 0,
        "delta": {"type": "text_delta", "text": "says hello from the parity harness."},
    })
    body += _sse_event("content_block_stop", {"type": "content_block_stop", "index": 0})
    body += _sse_event("message_delta", {
        "type": "message_delta",
        "delta": {"stop_reason": "end_turn", "stop_sequence": None},
        "usage": _usage_json(11, 8),
    })
    body += _sse_event("message_stop", {"type": "message_stop"})
    return body


def _tool_use_sse(tool_id: str, tool_name: str, chunks: list[str]) -> str:
    return _tool_uses_sse([(tool_id, tool_name, chunks)])


def _tool_uses_sse(tool_uses: list[tuple[str, str, list[str]]]) -> str:
    body = ""
    msg_id = f"msg_{tool_uses[0][0]}" if tool_uses else "msg_tool_use"
    body += _sse_event("message_start", {
        "type": "message_start",
        "message": {
            "id": msg_id, "type": "message", "role": "assistant",
            "content": [], "model": DEFAULT_MODEL, "stop_reason": None,
            "stop_sequence": None, "usage": _usage_json(12, 0),
        },
    })
    for index, (tool_id, tool_name, chunks) in enumerate(tool_uses):
        body += _sse_event("content_block_start", {
            "type": "content_block_start", "index": index,
            "content_block": {"type": "tool_use", "id": tool_id, "name": tool_name, "input": {}},
        })
        for chunk in chunks:
            body += _sse_event("content_block_delta", {
                "type": "content_block_delta", "index": index,
                "delta": {"type": "input_json_delta", "partial_json": chunk},
            })
        body += _sse_event("content_block_stop", {"type": "content_block_stop", "index": index})
    body += _sse_event("message_delta", {
        "type": "message_delta",
        "delta": {"stop_reason": "tool_use", "stop_sequence": None},
        "usage": _usage_json(12, 4),
    })
    body += _sse_event("message_stop", {"type": "message_stop"})
    return body


def _final_text_sse(text: str, input_tokens: int = 14, output_tokens: int = 7) -> str:
    body = ""
    body += _sse_event("message_start", {
        "type": "message_start",
        "message": {
            "id": _unique_message_id(), "type": "message", "role": "assistant",
            "content": [], "model": DEFAULT_MODEL, "stop_reason": None,
            "stop_sequence": None, "usage": _usage_json(input_tokens, 0),
        },
    })
    body += _sse_event("content_block_start", {
        "type": "content_block_start", "index": 0,
        "content_block": {"type": "text", "text": ""},
    })
    body += _sse_event("content_block_delta", {
        "type": "content_block_delta", "index": 0,
        "delta": {"type": "text_delta", "text": text},
    })
    body += _sse_event("content_block_stop", {"type": "content_block_stop", "index": 0})
    body += _sse_event("message_delta", {
        "type": "message_delta",
        "delta": {"stop_reason": "end_turn", "stop_sequence": None},
        "usage": _usage_json(input_tokens, output_tokens),
    })
    body += _sse_event("message_stop", {"type": "message_stop"})
    return body


# ── Build response ──


def _build_stream_body(body: dict[str, Any], scenario: Scenario) -> str:
    """Construit le body SSE pour un scénario donné."""
    tr = _latest_tool_result(body)

    if scenario == Scenario.STREAMING_TEXT:
        return _streaming_text_sse()
    if scenario == Scenario.READ_FILE_ROUNDTRIP:
        if tr:
            return _final_text_sse(f"read_file roundtrip complete: {_extract_read_content(tr[0])}")
        return _tool_use_sse("toolu_read_fixture", "read_file", ['{"path":"fixture.txt"}'])
    if scenario == Scenario.GREP_CHUNK_ASSEMBLY:
        if tr:
            return _final_text_sse(f"grep_search matched {_extract_num_matches(tr[0])} occurrences")
        return _tool_use_sse("toolu_grep_fixture", "grep_search", [
            '{"pattern":"par', 'ity","path":"fixture.txt"', ',"output_mode":"count"}',
        ])
    if scenario == Scenario.WRITE_FILE_ALLOWED:
        if tr:
            return _final_text_sse(f"write_file succeeded: {_extract_file_path(tr[0])}")
        return _tool_use_sse("toolu_write_allowed", "write_file", [
            '{"path":"generated/output.txt","content":"created by mock service\\n"}',
        ])
    if scenario == Scenario.WRITE_FILE_DENIED:
        if tr:
            return _final_text_sse(f"write_file denied as expected: {tr[0]}")
        return _tool_use_sse("toolu_write_denied", "write_file", [
            '{"path":"generated/denied.txt","content":"should not exist\\n"}',
        ])
    if scenario == Scenario.MULTI_TOOL_TURN_ROUNDTRIP:
        results = _tool_results_by_name(body)
        read_result = results.get("read_file")
        grep_result = results.get("grep_search")
        if read_result and grep_result:
            return _final_text_sse(
                f"multi-tool roundtrip complete: {_extract_read_content(read_result[0])} / "
                f"{_extract_num_matches(grep_result[0])} occurrences"
            )
        return _tool_uses_sse([
            ("toolu_multi_read", "read_file", ['{"path":"fixture.txt"}']),
            ("toolu_multi_grep", "grep_search", [
                '{"pattern":"par', 'ity","path":"fixture.txt"', ',"output_mode":"count"}',
            ]),
        ])
    if scenario == Scenario.BASH_STDOUT_ROUNDTRIP:
        if tr:
            return _final_text_sse(f"bash completed: {_extract_bash_stdout(tr[0])}")
        return _tool_use_sse("toolu_bash_stdout", "bash", [
            '{"command":"printf \'alpha from bash\'","timeout":1000}',
        ])
    if scenario == Scenario.BASH_PERMISSION_PROMPT_APPROVED:
        if tr:
            if tr[1]:
                return _final_text_sse(f"bash approval unexpectedly failed: {tr[0]}")
            return _final_text_sse(f"bash approved and executed: {_extract_bash_stdout(tr[0])}")
        return _tool_use_sse("toolu_bash_prompt_allow", "bash", [
            '{"command":"printf \'approved via prompt\'","timeout":1000}',
        ])
    if scenario == Scenario.BASH_PERMISSION_PROMPT_DENIED:
        if tr:
            return _final_text_sse(f"bash denied as expected: {tr[0]}")
        return _tool_use_sse("toolu_bash_prompt_deny", "bash", [
            '{"command":"printf \'should not run\'","timeout":1000}',
        ])
    if scenario == Scenario.PLUGIN_TOOL_ROUNDTRIP:
        if tr:
            return _final_text_sse(f"plugin tool completed: {_extract_plugin_message(tr[0])}")
        return _tool_use_sse("toolu_plugin_echo", "plugin_echo", [
            '{"message":"hello from plugin parity"}',
        ])
    if scenario == Scenario.AUTO_COMPACT_TRIGGERED:
        return _final_text_sse("auto compact parity complete.", 50_000, 200)
    if scenario == Scenario.TOKEN_COST_REPORTING:
        return _final_text_sse("token cost reporting parity complete.", 1_000, 500)
    return _final_text_sse("unknown scenario")


def _build_message_response(body: dict[str, Any], scenario: Scenario) -> dict[str, Any]:
    """Construit la réponse JSON pour un scénario en mode non-streaming."""
    tr = _latest_tool_result(body)

    if scenario == Scenario.STREAMING_TEXT:
        return _text_message_response("msg_streaming_text", "Mock streaming says hello from the parity harness.")
    if scenario == Scenario.READ_FILE_ROUNDTRIP:
        if tr:
            return _text_message_response("msg_read_file_final", f"read_file roundtrip complete: {_extract_read_content(tr[0])}")
        return _tool_message_response("msg_read_file_tool", "toolu_read_fixture", "read_file", {"path": "fixture.txt"})
    if scenario == Scenario.GREP_CHUNK_ASSEMBLY:
        if tr:
            return _text_message_response("msg_grep_final", f"grep_search matched {_extract_num_matches(tr[0])} occurrences")
        return _tool_message_response("msg_grep_tool", "toolu_grep_fixture", "grep_search", {"pattern": "parity", "path": "fixture.txt", "output_mode": "count"})
    if scenario == Scenario.WRITE_FILE_ALLOWED:
        if tr:
            return _text_message_response("msg_write_allowed_final", f"write_file succeeded: {_extract_file_path(tr[0])}")
        return _tool_message_response("msg_write_allowed_tool", "toolu_write_allowed", "write_file", {"path": "generated/output.txt", "content": "created by mock service\n"})
    if scenario == Scenario.WRITE_FILE_DENIED:
        if tr:
            return _text_message_response("msg_write_denied_final", f"write_file denied as expected: {tr[0]}")
        return _tool_message_response("msg_write_denied_tool", "toolu_write_denied", "write_file", {"path": "generated/denied.txt", "content": "should not exist\n"})
    if scenario == Scenario.MULTI_TOOL_TURN_ROUNDTRIP:
        results = _tool_results_by_name(body)
        read_result = results.get("read_file")
        grep_result = results.get("grep_search")
        if read_result and grep_result:
            return _text_message_response("msg_multi_tool_final", f"multi-tool roundtrip complete: {_extract_read_content(read_result[0])} / {_extract_num_matches(grep_result[0])} occurrences")
        return _tool_message_response_many("msg_multi_tool_start", [
            ("toolu_multi_read", "read_file", {"path": "fixture.txt"}),
            ("toolu_multi_grep", "grep_search", {"pattern": "parity", "path": "fixture.txt", "output_mode": "count"}),
        ])
    if scenario == Scenario.BASH_STDOUT_ROUNDTRIP:
        if tr:
            return _text_message_response("msg_bash_stdout_final", f"bash completed: {_extract_bash_stdout(tr[0])}")
        return _tool_message_response("msg_bash_stdout_tool", "toolu_bash_stdout", "bash", {"command": "printf 'alpha from bash'", "timeout": 1000})
    if scenario == Scenario.BASH_PERMISSION_PROMPT_APPROVED:
        if tr:
            if tr[1]:
                return _text_message_response("msg_bash_prompt_allow_error", f"bash approval unexpectedly failed: {tr[0]}")
            return _text_message_response("msg_bash_prompt_allow_final", f"bash approved and executed: {_extract_bash_stdout(tr[0])}")
        return _tool_message_response("msg_bash_prompt_allow_tool", "toolu_bash_prompt_allow", "bash", {"command": "printf 'approved via prompt'", "timeout": 1000})
    if scenario == Scenario.BASH_PERMISSION_PROMPT_DENIED:
        if tr:
            return _text_message_response("msg_bash_prompt_deny_final", f"bash denied as expected: {tr[0]}")
        return _tool_message_response("msg_bash_prompt_deny_tool", "toolu_bash_prompt_deny", "bash", {"command": "printf 'should not run'", "timeout": 1000})
    if scenario == Scenario.PLUGIN_TOOL_ROUNDTRIP:
        if tr:
            return _text_message_response("msg_plugin_tool_final", f"plugin tool completed: {_extract_plugin_message(tr[0])}")
        return _tool_message_response("msg_plugin_tool_start", "toolu_plugin_echo", "plugin_echo", {"message": "hello from plugin parity"})
    if scenario == Scenario.AUTO_COMPACT_TRIGGERED:
        return _text_message_response("msg_auto_compact_triggered", "auto compact parity complete.", 50_000, 200)
    if scenario == Scenario.TOKEN_COST_REPORTING:
        return _text_message_response("msg_token_cost_reporting", "token cost reporting parity complete.", 1_000, 500)
    return _text_message_response("msg_unknown", "unknown scenario")


# ── Application FastAPI ──


class MockAnthropicService:
    """Service mock Anthropic avec capture des requêtes.

    Usage::

        service = MockAnthropicService()
        app = service.app  # FastAPI app à monter avec uvicorn

        # Après les requêtes :
        requests = service.captured_requests
    """

    def __init__(self) -> None:
        self.captured_requests: list[CapturedRequest] = []
        self.app = FastAPI(title="Mock Anthropic Service")
        self._base_url: str = ""
        self._setup_routes()

    @property
    def base_url(self) -> str:
        return self._base_url

    @base_url.setter
    def base_url(self, value: str) -> None:
        self._base_url = value

    def _setup_routes(self) -> None:
        @self.app.post("/v1/messages")
        async def messages(request: Request) -> PlainTextResponse | dict[str, Any]:
            raw_body = (await request.body()).decode("utf-8")
            body: dict[str, Any] = json.loads(raw_body)

            scenario = _detect_scenario(body)
            if scenario is None:
                return PlainTextResponse(
                    "missing parity scenario", status_code=400
                )

            headers: dict[str, str] = {}
            for key, value in request.headers.items():
                headers[key.lower()] = value

            self.captured_requests.append(CapturedRequest(
                method="POST",
                path="/v1/messages",
                headers=headers,
                scenario=scenario.value,
                stream=body.get("stream", False),
                raw_body=raw_body,
            ))

            request_id = REQUEST_IDS.get(scenario, "req_unknown")

            if body.get("stream", False):
                sse_body = _build_stream_body(body, scenario)
                return PlainTextResponse(
                    content=sse_body,
                    media_type="text/event-stream",
                    headers={"x-request-id": request_id},
                )

            response = _build_message_response(body, scenario)
            response["request_id"] = request_id
            return response

    @classmethod
    async def spawn(cls, bind_addr: str = "127.0.0.1:0") -> MockAnthropicService:
        """Crée et démarre le service mock. Pour les tests, utiliser TestClient de FastAPI."""
        service = cls()
        service.base_url = f"http://{bind_addr}"
        return service


def create_app() -> FastAPI:
    """Point d'entrée pour `uvicorn src.mock_service.server:create_app --factory`."""
    service = MockAnthropicService()
    return service.app
