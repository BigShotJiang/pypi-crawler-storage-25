"""Parseur SSE (Server-Sent Events) — traduit de sse.rs."""

from __future__ import annotations

import json
from typing import Optional

from .error import ApiError, JsonError
from .types import (
    ContentBlockDeltaEvent,
    ContentBlockStartEvent,
    ContentBlockStopEvent,
    MessageDeltaEvent,
    MessageStartEvent,
    MessageStopEvent,
    StreamEvent,
)


def _parse_stream_event(payload: str) -> StreamEvent:
    """Parse un payload JSON en StreamEvent."""
    data = json.loads(payload)
    event_type = data.get("type", "")

    if event_type == "message_start":
        return _parse_message_start(data)
    elif event_type == "message_delta":
        return _parse_message_delta(data)
    elif event_type == "content_block_start":
        return _parse_content_block_start(data)
    elif event_type == "content_block_delta":
        return _parse_content_block_delta(data)
    elif event_type == "content_block_stop":
        return ContentBlockStopEvent(index=data["index"])
    elif event_type == "message_stop":
        return MessageStopEvent()
    else:
        raise JsonError(ValueError(f"unknown stream event type: {event_type}"))


def _parse_message_start(data: dict) -> MessageStartEvent:
    """Parse un message_start event."""
    from .serialization import deserialize_message_response

    return MessageStartEvent(message=deserialize_message_response(data["message"]))


def _parse_message_delta(data: dict) -> MessageDeltaEvent:
    """Parse un message_delta event."""
    from .serialization import deserialize_message_delta, deserialize_usage

    return MessageDeltaEvent(
        delta=deserialize_message_delta(data["delta"]),
        usage=deserialize_usage(data["usage"]),
    )


def _parse_content_block_start(data: dict) -> ContentBlockStartEvent:
    """Parse un content_block_start event."""
    from .serialization import deserialize_output_content_block

    return ContentBlockStartEvent(
        index=data["index"],
        content_block=deserialize_output_content_block(data["content_block"]),
    )


def _parse_content_block_delta(data: dict) -> ContentBlockDeltaEvent:
    """Parse un content_block_delta event."""
    from .serialization import deserialize_content_block_delta

    return ContentBlockDeltaEvent(
        index=data["index"],
        delta=deserialize_content_block_delta(data["delta"]),
    )


class SseParser:
    """Parseur incrémental de flux SSE.

    Accumule les chunks reçus et extrait les frames complètes
    délimitées par des doubles sauts de ligne.
    """

    def __init__(self) -> None:
        self._buffer = bytearray()

    def push(self, chunk: bytes) -> list[StreamEvent]:
        """Ajoute un chunk au buffer et retourne les événements parsés."""
        self._buffer.extend(chunk)
        events: list[StreamEvent] = []

        while True:
            frame = self._next_frame()
            if frame is None:
                break
            parsed = parse_frame(frame)
            if parsed is not None:
                events.append(parsed)

        return events

    def finish(self) -> list[StreamEvent]:
        """Traite le contenu restant dans le buffer."""
        if not self._buffer:
            return []

        trailing = bytes(self._buffer)
        self._buffer.clear()
        frame_str = trailing.decode("utf-8", errors="replace")
        parsed = parse_frame(frame_str)
        if parsed is not None:
            return [parsed]
        return []

    def _next_frame(self) -> Optional[str]:
        """Extrait la prochaine frame complète du buffer."""
        # Chercher le séparateur \n\n
        buf = bytes(self._buffer)
        pos = buf.find(b"\n\n")
        sep_len = 2

        if pos == -1:
            # Chercher \r\n\r\n
            pos = buf.find(b"\r\n\r\n")
            sep_len = 4

        if pos == -1:
            return None

        # Extraire la frame
        frame_bytes = buf[:pos]
        self._buffer = bytearray(buf[pos + sep_len :])
        return frame_bytes.decode("utf-8", errors="replace")


def parse_frame(frame: str) -> Optional[StreamEvent]:
    """Parse une frame SSE individuelle en StreamEvent.

    Retourne None pour les pings, les frames vides et [DONE].
    """
    trimmed = frame.strip()
    if not trimmed:
        return None

    data_lines: list[str] = []
    event_name: Optional[str] = None

    for line in trimmed.splitlines():
        # Commentaires SSE
        if line.startswith(":"):
            continue
        # Nom de l'événement
        if line.startswith("event:"):
            event_name = line[len("event:") :].strip()
            continue
        # Ligne de données
        if line.startswith("data:"):
            data_lines.append(line[len("data:") :].lstrip())

    # Ignorer les pings
    if event_name == "ping":
        return None

    if not data_lines:
        return None

    payload = "\n".join(data_lines)
    if payload == "[DONE]":
        return None

    try:
        return _parse_stream_event(payload)
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        raise JsonError(exc) from exc
