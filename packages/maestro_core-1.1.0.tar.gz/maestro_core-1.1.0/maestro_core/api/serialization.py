"""Helpers de sérialisation / désérialisation JSON — types API."""

from __future__ import annotations

import json
from typing import Any, Optional

from .types import (
    ContentBlockDelta,
    InputContentBlock,
    InputJsonDelta,
    InputMessage,
    MessageDelta,
    MessageRequest,
    MessageResponse,
    OutputContentBlock,
    RedactedThinkingOutputBlock,
    SignatureDelta,
    TextDelta,
    TextInputBlock,
    TextOutputBlock,
    TextToolResultBlock,
    ThinkingDelta,
    ThinkingOutputBlock,
    ToolChoice,
    ToolChoiceType,
    ToolDefinition,
    ToolResultContentBlock,
    ToolResultInputBlock,
    ToolUseInputBlock,
    ToolUseOutputBlock,
    JsonToolResultBlock,
    Usage,
)


# --- Serialization (Python -> dict/JSON) ---


def serialize_message_request(request: MessageRequest) -> dict[str, Any]:
    """Convertit un MessageRequest en dict sérialisable JSON."""
    data: dict[str, Any] = {
        "model": request.model,
        "max_tokens": request.max_tokens,
        "messages": [_serialize_input_message(m) for m in request.messages],
    }
    if request.system is not None:
        data["system"] = request.system
    if request.tools is not None:
        data["tools"] = [_serialize_tool_definition(t) for t in request.tools]
    if request.tool_choice is not None:
        data["tool_choice"] = _serialize_tool_choice(request.tool_choice)
    if request.stream:
        data["stream"] = True
    return data


def _serialize_input_message(msg: InputMessage) -> dict[str, Any]:
    """Sérialise un InputMessage."""
    return {
        "role": msg.role,
        "content": [_serialize_input_content_block(b) for b in msg.content],
    }


def _serialize_input_content_block(block: InputContentBlock) -> dict[str, Any]:
    """Sérialise un InputContentBlock."""
    if isinstance(block, TextInputBlock):
        return {"type": "text", "text": block.text}
    elif isinstance(block, ToolUseInputBlock):
        return {"type": "tool_use", "id": block.id, "name": block.name, "input": block.input}
    elif isinstance(block, ToolResultInputBlock):
        result: dict[str, Any] = {
            "type": "tool_result",
            "tool_use_id": block.tool_use_id,
            "content": [_serialize_tool_result_content(c) for c in block.content],
        }
        if block.is_error:
            result["is_error"] = True
        return result
    return {"type": "unknown"}


def _serialize_tool_result_content(block: ToolResultContentBlock) -> dict[str, Any]:
    """Sérialise un bloc de résultat d'outil."""
    if isinstance(block, TextToolResultBlock):
        return {"type": "text", "text": block.text}
    elif isinstance(block, JsonToolResultBlock):
        return {"type": "json", "value": block.value}
    return {"type": "unknown"}


def _serialize_tool_definition(tool: ToolDefinition) -> dict[str, Any]:
    """Sérialise une ToolDefinition."""
    data: dict[str, Any] = {"name": tool.name, "input_schema": tool.input_schema}
    if tool.description is not None:
        data["description"] = tool.description
    return data


def _serialize_tool_choice(choice: ToolChoice) -> dict[str, Any]:
    """Sérialise un ToolChoice."""
    if choice.type == ToolChoiceType.AUTO:
        return {"type": "auto"}
    elif choice.type == ToolChoiceType.ANY:
        return {"type": "any"}
    elif choice.type == ToolChoiceType.TOOL:
        return {"type": "tool", "name": choice.name}
    return {"type": "auto"}


# --- Deserialization (dict/JSON -> Python) ---


def deserialize_message_response(data: dict[str, Any]) -> MessageResponse:
    """Convertit un dict JSON en MessageResponse."""
    return MessageResponse(
        id=data.get("id", ""),
        kind=data.get("type", "message"),
        role=data.get("role", "assistant"),
        content=[deserialize_output_content_block(b) for b in data.get("content", [])],
        model=data.get("model", ""),
        stop_reason=data.get("stop_reason"),
        stop_sequence=data.get("stop_sequence"),
        usage=deserialize_usage(data.get("usage", {})),
        request_id=data.get("request_id"),
    )


def deserialize_output_content_block(data: dict[str, Any]) -> OutputContentBlock:
    """Convertit un dict JSON en OutputContentBlock."""
    block_type = data.get("type", "")
    if block_type == "text":
        return TextOutputBlock(text=data.get("text", ""))
    elif block_type == "tool_use":
        return ToolUseOutputBlock(
            id=data.get("id", ""),
            name=data.get("name", ""),
            input=data.get("input"),
        )
    elif block_type == "thinking":
        return ThinkingOutputBlock(
            thinking=data.get("thinking", ""),
            signature=data.get("signature"),
        )
    elif block_type == "redacted_thinking":
        return RedactedThinkingOutputBlock(data=data.get("data"))
    return TextOutputBlock(text="")


def deserialize_usage(data: dict[str, Any]) -> Usage:
    """Convertit un dict JSON en Usage."""
    return Usage(
        input_tokens=data.get("input_tokens", 0),
        cache_creation_input_tokens=data.get("cache_creation_input_tokens", 0),
        cache_read_input_tokens=data.get("cache_read_input_tokens", 0),
        output_tokens=data.get("output_tokens", 0),
    )


def deserialize_message_delta(data: dict[str, Any]) -> MessageDelta:
    """Convertit un dict JSON en MessageDelta."""
    return MessageDelta(
        stop_reason=data.get("stop_reason"),
        stop_sequence=data.get("stop_sequence"),
    )


def deserialize_content_block_delta(data: dict[str, Any]) -> ContentBlockDelta:
    """Convertit un dict JSON en ContentBlockDelta."""
    delta_type = data.get("type", "")
    if delta_type == "text_delta":
        return TextDelta(text=data.get("text", ""))
    elif delta_type == "input_json_delta":
        return InputJsonDelta(partial_json=data.get("partial_json", ""))
    elif delta_type == "thinking_delta":
        return ThinkingDelta(thinking=data.get("thinking", ""))
    elif delta_type == "signature_delta":
        return SignatureDelta(signature=data.get("signature", ""))
    return TextDelta(text="")
