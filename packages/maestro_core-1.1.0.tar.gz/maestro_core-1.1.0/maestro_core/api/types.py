"""Types de l'API Messages — traduit de types.rs."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


# --- Request types ---


@dataclass
class MessageRequest:
    """Requête envoyée à l'API Messages."""

    model: str
    max_tokens: int
    messages: list[InputMessage]
    system: Optional[str] = None
    tools: Optional[list[ToolDefinition]] = None
    tool_choice: Optional[ToolChoice] = None
    stream: bool = False

    def with_streaming(self) -> MessageRequest:
        """Retourne une copie avec stream=True."""
        return MessageRequest(
            model=self.model,
            max_tokens=self.max_tokens,
            messages=list(self.messages),
            system=self.system,
            tools=list(self.tools) if self.tools else None,
            tool_choice=self.tool_choice,
            stream=True,
        )


@dataclass
class InputMessage:
    """Message d'entrée dans la conversation."""

    role: str
    content: list[InputContentBlock]

    @classmethod
    def user_text(cls, text: str) -> InputMessage:
        """Crée un message utilisateur texte simple."""
        return cls(role="user", content=[TextInputBlock(text=text)])

    @classmethod
    def user_tool_result(
        cls, tool_use_id: str, content: str, is_error: bool = False
    ) -> InputMessage:
        """Crée un message utilisateur avec résultat d'outil."""
        return cls(
            role="user",
            content=[
                ToolResultInputBlock(
                    tool_use_id=tool_use_id,
                    content=[TextToolResultBlock(text=content)],
                    is_error=is_error,
                )
            ],
        )


# --- Input content blocks (tagged union via sous-classes) ---


class InputContentBlock:
    """Bloc de contenu d'entrée (classe de base)."""

    block_type: str


@dataclass
class TextInputBlock(InputContentBlock):
    """Bloc texte d'entrée."""

    block_type: str = "text"
    text: str = ""


@dataclass
class ToolUseInputBlock(InputContentBlock):
    """Bloc d'appel d'outil dans le message."""

    block_type: str = "tool_use"
    id: str = ""
    name: str = ""
    input: Any = None


@dataclass
class ToolResultInputBlock(InputContentBlock):
    """Bloc de résultat d'outil."""

    block_type: str = "tool_result"
    tool_use_id: str = ""
    content: list[ToolResultContentBlock] = field(default_factory=list)
    is_error: bool = False


# --- Tool result content blocks ---


class ToolResultContentBlock:
    """Contenu d'un résultat d'outil (classe de base)."""

    block_type: str


@dataclass
class TextToolResultBlock(ToolResultContentBlock):
    """Résultat d'outil en texte."""

    block_type: str = "text"
    text: str = ""


@dataclass
class JsonToolResultBlock(ToolResultContentBlock):
    """Résultat d'outil en JSON."""

    block_type: str = "json"
    value: Any = None


# --- Tool definition ---


@dataclass
class ToolDefinition:
    """Définition d'un outil pour l'API."""

    name: str
    input_schema: Any
    description: Optional[str] = None


# --- Tool choice ---


class ToolChoiceType(Enum):
    """Type de sélection d'outil."""

    AUTO = "auto"
    ANY = "any"
    TOOL = "tool"


@dataclass
class ToolChoice:
    """Choix de sélection d'outil."""

    type: ToolChoiceType
    name: Optional[str] = None  # Seulement pour ToolChoiceType.TOOL


# --- Response types ---


@dataclass
class MessageResponse:
    """Réponse de l'API Messages."""

    id: str
    kind: str  # "type" en JSON, renommé pour éviter conflit Python
    role: str
    content: list[OutputContentBlock]
    model: str
    usage: Usage
    stop_reason: Optional[str] = None
    stop_sequence: Optional[str] = None
    request_id: Optional[str] = None

    def total_tokens(self) -> int:
        """Nombre total de tokens."""
        return self.usage.total_tokens()


# --- Output content blocks ---


class OutputContentBlock:
    """Bloc de contenu de sortie (classe de base)."""

    block_type: str


@dataclass
class TextOutputBlock(OutputContentBlock):
    """Bloc texte de sortie."""

    block_type: str = "text"
    text: str = ""


@dataclass
class ToolUseOutputBlock(OutputContentBlock):
    """Bloc d'appel d'outil dans la réponse."""

    block_type: str = "tool_use"
    id: str = ""
    name: str = ""
    input: Any = None


@dataclass
class ThinkingOutputBlock(OutputContentBlock):
    """Bloc de réflexion (thinking)."""

    block_type: str = "thinking"
    thinking: str = ""
    signature: Optional[str] = None


@dataclass
class RedactedThinkingOutputBlock(OutputContentBlock):
    """Bloc de réflexion masqué."""

    block_type: str = "redacted_thinking"
    data: Any = None


# --- Usage ---


@dataclass
class Usage:
    """Statistiques de consommation de tokens."""

    input_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    output_tokens: int = 0

    def total_tokens(self) -> int:
        """Nombre total de tokens (entrée + sortie + cache)."""
        return (
            self.input_tokens
            + self.output_tokens
            + self.cache_creation_input_tokens
            + self.cache_read_input_tokens
        )


# --- Stream events ---


@dataclass
class MessageStartEvent:
    """Début de message dans le stream."""

    message: MessageResponse


@dataclass
class MessageDeltaEvent:
    """Delta de message dans le stream."""

    delta: MessageDelta
    usage: Usage


@dataclass
class MessageDelta:
    """Contenu delta d'un message."""

    stop_reason: Optional[str] = None
    stop_sequence: Optional[str] = None


@dataclass
class ContentBlockStartEvent:
    """Début d'un bloc de contenu dans le stream."""

    index: int
    content_block: OutputContentBlock


@dataclass
class ContentBlockDeltaEvent:
    """Delta d'un bloc de contenu dans le stream."""

    index: int
    delta: ContentBlockDelta


# --- Content block deltas ---


class ContentBlockDelta:
    """Delta de contenu (classe de base)."""

    delta_type: str


@dataclass
class TextDelta(ContentBlockDelta):
    """Delta texte."""

    delta_type: str = "text_delta"
    text: str = ""


@dataclass
class InputJsonDelta(ContentBlockDelta):
    """Delta JSON partiel pour tool input."""

    delta_type: str = "input_json_delta"
    partial_json: str = ""


@dataclass
class ThinkingDelta(ContentBlockDelta):
    """Delta de thinking."""

    delta_type: str = "thinking_delta"
    thinking: str = ""


@dataclass
class SignatureDelta(ContentBlockDelta):
    """Delta de signature."""

    delta_type: str = "signature_delta"
    signature: str = ""


@dataclass
class ContentBlockStopEvent:
    """Fin d'un bloc de contenu dans le stream."""

    index: int


@dataclass
class MessageStopEvent:
    """Fin du message dans le stream."""

    pass


class StreamEventType(Enum):
    """Type d'événement dans le stream."""

    MESSAGE_START = "message_start"
    MESSAGE_DELTA = "message_delta"
    CONTENT_BLOCK_START = "content_block_start"
    CONTENT_BLOCK_DELTA = "content_block_delta"
    CONTENT_BLOCK_STOP = "content_block_stop"
    MESSAGE_STOP = "message_stop"


# Union type pour les stream events
StreamEvent = (
    MessageStartEvent
    | MessageDeltaEvent
    | ContentBlockStartEvent
    | ContentBlockDeltaEvent
    | ContentBlockStopEvent
    | MessageStopEvent
)
