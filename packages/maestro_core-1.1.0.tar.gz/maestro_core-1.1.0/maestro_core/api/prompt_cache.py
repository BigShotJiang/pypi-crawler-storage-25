"""Prompt cache — traduit de prompt_cache.rs.

Gère la mise en cache des réponses et le suivi des invalidations
de cache côté provider (cache_read_input_tokens).
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .types import MessageRequest, MessageResponse, Usage
from .serialization import serialize_message_request

_DEFAULT_COMPLETION_TTL_SECS = 30
_DEFAULT_PROMPT_TTL_SECS = 5 * 60
_DEFAULT_BREAK_MIN_DROP = 2_000
_MAX_SANITIZED_LENGTH = 80
_REQUEST_FINGERPRINT_VERSION = 1
_REQUEST_FINGERPRINT_PREFIX = "v1"
_FNV_OFFSET_BASIS = 0xCBF2_9CE4_8422_2325
_FNV_PRIME = 0x0000_0100_0000_01B3
_U64_MASK = (1 << 64) - 1


@dataclass
class PromptCacheConfig:
    """Configuration du prompt cache."""

    session_id: str = "default"
    completion_ttl: float = _DEFAULT_COMPLETION_TTL_SECS
    prompt_ttl: float = _DEFAULT_PROMPT_TTL_SECS
    cache_break_min_drop: int = _DEFAULT_BREAK_MIN_DROP


@dataclass
class PromptCachePaths:
    """Chemins du prompt cache pour une session."""

    root: Path
    session_dir: Path
    completion_dir: Path
    session_state_path: Path
    stats_path: Path

    @classmethod
    def for_session(cls, session_id: str) -> PromptCachePaths:
        root = _base_cache_root()
        session_dir = root / _sanitize_path_segment(session_id)
        completion_dir = session_dir / "completions"
        return cls(
            root=root,
            session_dir=session_dir,
            completion_dir=completion_dir,
            session_state_path=session_dir / "session-state.json",
            stats_path=session_dir / "stats.json",
        )

    def completion_entry_path(self, request_hash: str) -> Path:
        return self.completion_dir / f"{request_hash}.json"


@dataclass
class PromptCacheStats:
    """Statistiques du prompt cache."""

    tracked_requests: int = 0
    completion_cache_hits: int = 0
    completion_cache_misses: int = 0
    completion_cache_writes: int = 0
    expected_invalidations: int = 0
    unexpected_cache_breaks: int = 0
    total_cache_creation_input_tokens: int = 0
    total_cache_read_input_tokens: int = 0
    last_cache_creation_input_tokens: Optional[int] = None
    last_cache_read_input_tokens: Optional[int] = None
    last_request_hash: Optional[str] = None
    last_completion_cache_key: Optional[str] = None
    last_break_reason: Optional[str] = None
    last_cache_source: Optional[str] = None


@dataclass
class CacheBreakEvent:
    """Événement de rupture de cache."""

    unexpected: bool
    reason: str
    previous_cache_read_input_tokens: int
    current_cache_read_input_tokens: int
    token_drop: int


@dataclass
class PromptCacheRecord:
    """Enregistrement d'une opération de cache."""

    cache_break: Optional[CacheBreakEvent]
    stats: PromptCacheStats


@dataclass
class _TrackedPromptState:
    """État interne suivi pour la détection de cache breaks."""

    observed_at_unix_secs: int
    fingerprint_version: int
    model_hash: int
    system_hash: int
    tools_hash: int
    messages_hash: int
    cache_read_input_tokens: int


@dataclass
class _CompletionCacheEntry:
    """Entrée du cache de completions."""

    cached_at_unix_secs: int
    fingerprint_version: int
    response: dict[str, Any]  # MessageResponse sérialisé


class PromptCache:
    """Cache de prompt avec détection d'invalidation et stockage de completions."""

    def __init__(self, session_id: str = "default", config: Optional[PromptCacheConfig] = None) -> None:
        self._config = config or PromptCacheConfig(session_id=session_id)
        self._paths = PromptCachePaths.for_session(self._config.session_id)
        self._stats = _read_json(self._paths.stats_path, PromptCacheStats) or PromptCacheStats()
        self._previous: Optional[_TrackedPromptState] = _read_json_raw(self._paths.session_state_path)
        self._lock = threading.Lock()
        self._last_record: Optional[PromptCacheRecord] = None

    def paths(self) -> PromptCachePaths:
        return self._paths

    def stats(self) -> PromptCacheStats:
        with self._lock:
            return self._stats

    def take_last_record(self) -> Optional[PromptCacheRecord]:
        with self._lock:
            record = self._last_record
            self._last_record = None
            return record

    def lookup_completion(self, request: MessageRequest) -> Optional[MessageResponse]:
        """Cherche une réponse en cache. Retourne None si absente ou expirée."""
        request_hash = _request_hash_hex(request)
        entry_path = self._paths.completion_entry_path(request_hash)

        entry = _read_json_raw(entry_path)
        if entry is None:
            with self._lock:
                self._stats.completion_cache_misses += 1
                self._stats.last_completion_cache_key = request_hash
                _persist_state(self)
            return None

        if entry.get("fingerprint_version") != _REQUEST_FINGERPRINT_VERSION:
            with self._lock:
                self._stats.completion_cache_misses += 1
                self._stats.last_completion_cache_key = request_hash
                try:
                    entry_path.unlink(missing_ok=True)
                except OSError:
                    pass
                _persist_state(self)
            return None

        cached_at = entry.get("cached_at_unix_secs", 0)
        elapsed = _now_unix_secs() - cached_at
        if elapsed >= self._config.completion_ttl:
            with self._lock:
                self._stats.completion_cache_misses += 1
                self._stats.last_completion_cache_key = request_hash
                try:
                    entry_path.unlink(missing_ok=True)
                except OSError:
                    pass
                _persist_state(self)
            return None

        # Hit
        from .serialization import deserialize_message_response

        with self._lock:
            self._stats.completion_cache_hits += 1
            response = deserialize_message_response(entry["response"])
            _apply_usage_to_stats(self._stats, response.usage, request_hash, "completion-cache")
            _persist_state(self)
            return response

    def record_response(self, request: MessageRequest, response: MessageResponse) -> PromptCacheRecord:
        """Enregistre une réponse et écrit dans le cache."""
        return self._record_usage_internal(request, response.usage, response)

    def record_usage(self, request: MessageRequest, usage: Usage) -> PromptCacheRecord:
        """Enregistre l'usage sans sauvegarder la réponse."""
        return self._record_usage_internal(request, usage, None)

    def _record_usage_internal(
        self,
        request: MessageRequest,
        usage: Usage,
        response: Optional[MessageResponse],
    ) -> PromptCacheRecord:
        request_hash = _request_hash_hex(request)

        with self._lock:
            current = _tracked_state_from_usage(request, usage)
            cache_break = _detect_cache_break(self._config, self._previous, current)

            self._stats.tracked_requests += 1
            _apply_usage_to_stats(self._stats, usage, request_hash, "api-response")

            if cache_break is not None:
                if cache_break.unexpected:
                    self._stats.unexpected_cache_breaks += 1
                else:
                    self._stats.expected_invalidations += 1
                self._stats.last_break_reason = cache_break.reason

            self._previous = current

            if response is not None:
                _write_completion_entry(self._paths, request_hash, response)
                self._stats.completion_cache_writes += 1

            _persist_state(self)

            record = PromptCacheRecord(cache_break=cache_break, stats=self._stats)
            self._last_record = record
            return record


# --- Fonctions internes ---


def _tracked_state_from_usage(request: MessageRequest, usage: Usage) -> _TrackedPromptState:
    """Crée un état de suivi depuis une requête et son usage."""
    req_dict = serialize_message_request(request)
    return _TrackedPromptState(
        observed_at_unix_secs=_now_unix_secs(),
        fingerprint_version=_REQUEST_FINGERPRINT_VERSION,
        model_hash=_hash_serializable(req_dict.get("model", "")),
        system_hash=_hash_serializable(req_dict.get("system", "")),
        tools_hash=_hash_serializable(req_dict.get("tools", [])),
        messages_hash=_hash_serializable(req_dict.get("messages", [])),
        cache_read_input_tokens=usage.cache_read_input_tokens,
    )


def _detect_cache_break(
    config: PromptCacheConfig,
    previous: Optional[Any],
    current: _TrackedPromptState,
) -> Optional[CacheBreakEvent]:
    """Détecte si une rupture de cache s'est produite."""
    if previous is None:
        return None

    # Si c'est un dict (depuis JSON), convertir
    if isinstance(previous, dict):
        prev_version = previous.get("fingerprint_version", 0)
        prev_cache_read = previous.get("cache_read_input_tokens", 0)
        prev_model_hash = previous.get("model_hash", 0)
        prev_system_hash = previous.get("system_hash", 0)
        prev_tools_hash = previous.get("tools_hash", 0)
        prev_messages_hash = previous.get("messages_hash", 0)
        prev_observed_at = previous.get("observed_at_unix_secs", 0)
    else:
        prev_version = previous.fingerprint_version
        prev_cache_read = previous.cache_read_input_tokens
        prev_model_hash = previous.model_hash
        prev_system_hash = previous.system_hash
        prev_tools_hash = previous.tools_hash
        prev_messages_hash = previous.messages_hash
        prev_observed_at = previous.observed_at_unix_secs

    if prev_version != current.fingerprint_version:
        token_drop = max(0, prev_cache_read - current.cache_read_input_tokens)
        return CacheBreakEvent(
            unexpected=False,
            reason=f"fingerprint version changed (v{prev_version} -> v{current.fingerprint_version})",
            previous_cache_read_input_tokens=prev_cache_read,
            current_cache_read_input_tokens=current.cache_read_input_tokens,
            token_drop=token_drop,
        )

    token_drop = max(0, prev_cache_read - current.cache_read_input_tokens)
    if token_drop < config.cache_break_min_drop:
        return None

    reasons: list[str] = []
    if prev_model_hash != current.model_hash:
        reasons.append("model changed")
    if prev_system_hash != current.system_hash:
        reasons.append("system prompt changed")
    if prev_tools_hash != current.tools_hash:
        reasons.append("tool definitions changed")
    if prev_messages_hash != current.messages_hash:
        reasons.append("message payload changed")

    elapsed = current.observed_at_unix_secs - prev_observed_at

    if not reasons:
        if elapsed > config.prompt_ttl:
            return CacheBreakEvent(
                unexpected=False,
                reason=f"possible prompt cache TTL expiry after {elapsed}s",
                previous_cache_read_input_tokens=prev_cache_read,
                current_cache_read_input_tokens=current.cache_read_input_tokens,
                token_drop=token_drop,
            )
        else:
            return CacheBreakEvent(
                unexpected=True,
                reason="cache read tokens dropped while prompt fingerprint remained stable",
                previous_cache_read_input_tokens=prev_cache_read,
                current_cache_read_input_tokens=current.cache_read_input_tokens,
                token_drop=token_drop,
            )

    return CacheBreakEvent(
        unexpected=False,
        reason=", ".join(reasons),
        previous_cache_read_input_tokens=prev_cache_read,
        current_cache_read_input_tokens=current.cache_read_input_tokens,
        token_drop=token_drop,
    )


def _apply_usage_to_stats(
    stats: PromptCacheStats, usage: Usage, request_hash: str, source: str
) -> None:
    """Met à jour les statistiques avec l'usage."""
    stats.total_cache_creation_input_tokens += usage.cache_creation_input_tokens
    stats.total_cache_read_input_tokens += usage.cache_read_input_tokens
    stats.last_cache_creation_input_tokens = usage.cache_creation_input_tokens
    stats.last_cache_read_input_tokens = usage.cache_read_input_tokens
    stats.last_request_hash = request_hash
    stats.last_cache_source = source


def _persist_state(cache: PromptCache) -> None:
    """Persiste l'état du cache sur disque."""
    try:
        cache._paths.completion_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return

    _write_json(cache._paths.stats_path, _stats_to_dict(cache._stats))
    if cache._previous is not None:
        if isinstance(cache._previous, dict):
            _write_json(cache._paths.session_state_path, cache._previous)
        else:
            _write_json(cache._paths.session_state_path, {
                "observed_at_unix_secs": cache._previous.observed_at_unix_secs,
                "fingerprint_version": cache._previous.fingerprint_version,
                "model_hash": cache._previous.model_hash,
                "system_hash": cache._previous.system_hash,
                "tools_hash": cache._previous.tools_hash,
                "messages_hash": cache._previous.messages_hash,
                "cache_read_input_tokens": cache._previous.cache_read_input_tokens,
            })


def _write_completion_entry(paths: PromptCachePaths, request_hash: str, response: MessageResponse) -> None:
    """Écrit une entrée de cache de completion."""
    try:
        paths.completion_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return

    from .serialization import serialize_message_request

    entry = {
        "cached_at_unix_secs": _now_unix_secs(),
        "fingerprint_version": _REQUEST_FINGERPRINT_VERSION,
        "response": _response_to_dict(response),
    }
    _write_json(paths.completion_entry_path(request_hash), entry)


def _response_to_dict(response: MessageResponse) -> dict[str, Any]:
    """Sérialise un MessageResponse en dict."""
    content: list[dict[str, Any]] = []
    for block in response.content:
        from .types import TextOutputBlock, ToolUseOutputBlock, ThinkingOutputBlock, RedactedThinkingOutputBlock
        if isinstance(block, TextOutputBlock):
            content.append({"type": "text", "text": block.text})
        elif isinstance(block, ToolUseOutputBlock):
            content.append({"type": "tool_use", "id": block.id, "name": block.name, "input": block.input})
        elif isinstance(block, ThinkingOutputBlock):
            content.append({"type": "thinking", "thinking": block.thinking, "signature": block.signature})
        elif isinstance(block, RedactedThinkingOutputBlock):
            content.append({"type": "redacted_thinking", "data": block.data})

    return {
        "id": response.id,
        "type": response.kind,
        "role": response.role,
        "content": content,
        "model": response.model,
        "stop_reason": response.stop_reason,
        "stop_sequence": response.stop_sequence,
        "usage": {
            "input_tokens": response.usage.input_tokens,
            "cache_creation_input_tokens": response.usage.cache_creation_input_tokens,
            "cache_read_input_tokens": response.usage.cache_read_input_tokens,
            "output_tokens": response.usage.output_tokens,
        },
        "request_id": response.request_id,
    }


def _stats_to_dict(stats: PromptCacheStats) -> dict[str, Any]:
    return {k: v for k, v in stats.__dict__.items()}


# --- Hashing FNV-1a ---


def _stable_hash_bytes(data: bytes) -> int:
    """Hash FNV-1a 64 bits stable."""
    h = _FNV_OFFSET_BASIS
    for byte in data:
        h ^= byte
        h = (h * _FNV_PRIME) & _U64_MASK
    return h


def _hash_serializable(value: Any) -> int:
    """Hash d'une valeur sérialisable en JSON."""
    try:
        data = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError):
        data = b""
    return _stable_hash_bytes(data)


def _request_hash_hex(request: MessageRequest) -> str:
    """Hash hexadécimal d'un MessageRequest."""
    req_dict = serialize_message_request(request)
    h = _hash_serializable(req_dict)
    return f"{_REQUEST_FINGERPRINT_PREFIX}-{h:016x}"


def _sanitize_path_segment(value: str) -> str:
    """Assainit un segment de chemin."""
    sanitized = "".join(ch if ch.isalnum() else "-" for ch in value)
    if len(sanitized) <= _MAX_SANITIZED_LENGTH:
        return sanitized
    suffix = f"-{_stable_hash_bytes(value.encode('utf-8')):x}"
    return sanitized[: _MAX_SANITIZED_LENGTH - len(suffix)] + suffix


def _base_cache_root() -> Path:
    """Retourne le répertoire racine du cache."""
    config_home = os.environ.get("CLAUDE_CONFIG_HOME")
    if config_home:
        return Path(config_home) / "cache" / "prompt-cache"
    home = os.environ.get("HOME")
    if home:
        return Path(home) / ".claude" / "cache" / "prompt-cache"
    import tempfile
    return Path(tempfile.gettempdir()) / "claude-prompt-cache"


def _now_unix_secs() -> int:
    return int(time.time())


def _write_json(path: Path, value: Any) -> None:
    """Écrit un dict en JSON sur disque."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2))
    except OSError:
        pass


def _read_json(path: Path, cls: type) -> Optional[Any]:
    """Lit un fichier JSON et retourne une instance de cls."""
    data = _read_json_raw(path)
    if data is None:
        return None
    if cls == PromptCacheStats:
        stats = PromptCacheStats()
        for key, val in data.items():
            if hasattr(stats, key):
                setattr(stats, key, val)
        return stats
    return data


def _read_json_raw(path: Path) -> Optional[dict[str, Any]]:
    """Lit un fichier JSON brut."""
    try:
        text = path.read_text()
        return json.loads(text)
    except (OSError, json.JSONDecodeError):
        return None
