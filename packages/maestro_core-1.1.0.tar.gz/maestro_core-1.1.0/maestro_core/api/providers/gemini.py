"""Client Gemini API — provider pour Google Generative AI.

Utilise l'API REST directement via httpx pour rester léger en dépendances.
Traduit les schémas d'outils et réponses vers le format canonique du harness."""

from __future__ import annotations

import asyncio
import json
import os
from collections import deque
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from ..error import (
    ApiError,
    ApiResponseError,
    BackoffOverflowError,
    HttpError,
    MissingCredentialsError,
    RetriesExhaustedError,
    is_retryable_status,
)
from ..types import (
    ContentBlockDeltaEvent,
    ContentBlockStartEvent,
    ContentBlockStopEvent,
    InputContentBlock,
    InputJsonDelta,
    InputMessage,
    MessageDelta,
    MessageDeltaEvent,
    MessageRequest,
    MessageResponse,
    MessageStartEvent,
    MessageStopEvent,
    OutputContentBlock,
    StreamEvent,
    TextDelta,
    TextInputBlock,
    TextOutputBlock,
    TextToolResultBlock,
    ToolChoice,
    ToolChoiceType,
    ToolDefinition,
    ToolResultContentBlock,
    ToolResultInputBlock,
    ToolUseInputBlock,
    ToolUseOutputBlock,
    JsonToolResultBlock,
    Usage,
)

DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
_DEFAULT_INITIAL_BACKOFF_MS = 200
_DEFAULT_MAX_BACKOFF_MS = 2000
_DEFAULT_MAX_RETRIES = 2


class GeminiClient:
    """Client pour l'API Gemini (Google Generative AI)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
    ) -> None:
        self._api_key = api_key or _read_env_non_empty("GOOGLE_API_KEY")
        if not self._api_key:
            raise MissingCredentialsError(
                provider="Gemini",
                env_vars=("GOOGLE_API_KEY",),
            )
        self._base_url = os.environ.get("GEMINI_BASE_URL", DEFAULT_BASE_URL)
        self._max_retries = _DEFAULT_MAX_RETRIES
        self._initial_backoff_ms = _DEFAULT_INITIAL_BACKOFF_MS
        self._max_backoff_ms = _DEFAULT_MAX_BACKOFF_MS
        self._http = httpx.AsyncClient(timeout=120.0)

    @classmethod
    def from_env(cls) -> GeminiClient:
        """Crée un client depuis les variables d'environnement."""
        return cls()

    async def send_message(self, request: MessageRequest) -> MessageResponse:
        """Envoie un message et attend la réponse complète."""
        response = await self._send_with_retry(request, stream=False)
        data = response.json()
        return _normalize_response(request.model, data)

    async def stream_message(self, request: MessageRequest) -> GeminiMessageStream:
        """Envoie un message en mode streaming."""
        response = await self._send_with_retry(request, stream=True)
        return GeminiMessageStream(
            response=response,
            model=request.model,
        )

    async def _send_with_retry(
        self, request: MessageRequest, stream: bool
    ) -> httpx.Response:
        """Envoie avec retry et backoff exponentiel."""
        attempts = 0
        last_error: Optional[ApiError] = None

        while True:
            attempts += 1
            try:
                response = await self._send_raw_request(request, stream)
                return _expect_success(response)
            except ApiError as error:
                if _error_is_retryable(error) and attempts <= self._max_retries:
                    last_error = error
                else:
                    if attempts > self._max_retries and last_error is not None:
                        raise RetriesExhaustedError(
                            attempts=attempts, last_error=last_error
                        ) from error
                    raise

            if attempts > self._max_retries:
                break

            backoff = self._backoff_for_attempt(attempts)
            await asyncio.sleep(backoff / 1000.0)

        raise RetriesExhaustedError(
            attempts=attempts,
            last_error=last_error or ApiError("unknown error"),
        )

    async def _send_raw_request(
        self, request: MessageRequest, stream: bool
    ) -> httpx.Response:
        """Envoie une requête brute à l'API Gemini."""
        model = request.model
        # Endpoint : generateContent ou streamGenerateContent
        action = "streamGenerateContent" if stream else "generateContent"
        url = f"{self._base_url.rstrip('/')}/models/{model}:{action}"

        params = {"key": self._api_key}
        if stream:
            params["alt"] = "sse"

        body = _build_gemini_request(request)
        headers = {"content-type": "application/json"}

        try:
            if stream:
                # Pour le streaming, on utilise stream=True pour lire les chunks
                req = self._http.build_request(
                    "POST", url, params=params, json=body, headers=headers
                )
                response = await self._http.send(req, stream=True)
                return response
            else:
                response = await self._http.post(
                    url, params=params, json=body, headers=headers
                )
                return response
        except httpx.HTTPError as exc:
            raise HttpError(original=exc) from exc

    def _backoff_for_attempt(self, attempt: int) -> float:
        """Calcule le délai de backoff pour une tentative donnée."""
        try:
            multiplier = 1 << (attempt - 1)
        except (OverflowError, ValueError):
            raise BackoffOverflowError(
                attempt=attempt, base_delay_ms=self._initial_backoff_ms
            )
        delay = self._initial_backoff_ms * multiplier
        return min(delay, self._max_backoff_ms)

    async def close(self) -> None:
        """Ferme le client HTTP."""
        await self._http.aclose()


# --- Stream ---


class _GeminiStreamState:
    """État interne du stream Gemini."""

    def __init__(self, model: str) -> None:
        self.model = model
        self.message_started = False
        self.text_started = False
        self.text_finished = False
        self.finished = False
        self.stop_reason: Optional[str] = None
        self.usage: Optional[Usage] = None
        # Compteur pour les function calls en streaming
        self._tool_call_count = 0
        self._tool_calls_started: dict[int, bool] = {}
        self._tool_calls_stopped: dict[int, bool] = {}

    def ingest_chunk(self, data: dict[str, Any]) -> list[StreamEvent]:
        """Ingère un chunk Gemini et retourne les événements normalisés."""
        events: list[StreamEvent] = []

        if not self.message_started:
            self.message_started = True
            events.append(MessageStartEvent(
                message=MessageResponse(
                    id="",
                    kind="message",
                    role="assistant",
                    content=[],
                    model=self.model,
                    stop_reason=None,
                    stop_sequence=None,
                    usage=Usage(),
                    request_id=None,
                )
            ))

        # Usage metadata
        usage_meta = data.get("usageMetadata", {})
        if usage_meta:
            self.usage = Usage(
                input_tokens=usage_meta.get("promptTokenCount", 0),
                output_tokens=usage_meta.get("candidatesTokenCount", 0),
            )

        for candidate in data.get("candidates", []):
            content = candidate.get("content", {})
            finish_reason = candidate.get("finishReason")

            if finish_reason:
                self.stop_reason = _normalize_finish_reason(finish_reason)

            for part in content.get("parts", []):
                # Texte
                text = part.get("text")
                if text is not None:
                    if not self.text_started:
                        self.text_started = True
                        events.append(ContentBlockStartEvent(
                            index=0,
                            content_block=TextOutputBlock(text=""),
                        ))
                    events.append(ContentBlockDeltaEvent(
                        index=0,
                        delta=TextDelta(text=text),
                    ))

                # Function call
                fc = part.get("functionCall")
                if fc:
                    idx = self._tool_call_count
                    self._tool_call_count += 1
                    block_index = idx + 1  # Le texte est à l'index 0

                    call_id = f"gemini_call_{idx}"
                    name = fc.get("name", "")
                    args = fc.get("args", {})

                    self._tool_calls_started[idx] = True
                    events.append(ContentBlockStartEvent(
                        index=block_index,
                        content_block=ToolUseOutputBlock(
                            id=call_id, name=name, input={}
                        ),
                    ))
                    # Envoyer les arguments en un seul delta
                    events.append(ContentBlockDeltaEvent(
                        index=block_index,
                        delta=InputJsonDelta(
                            partial_json=json.dumps(args)
                        ),
                    ))
                    self._tool_calls_stopped[idx] = True
                    events.append(ContentBlockStopEvent(index=block_index))

        return events

    def finish(self) -> list[StreamEvent]:
        """Génère les événements de fin de stream."""
        if self.finished:
            return []
        self.finished = True

        events: list[StreamEvent] = []

        if self.text_started and not self.text_finished:
            self.text_finished = True
            events.append(ContentBlockStopEvent(index=0))

        if self.message_started:
            events.append(MessageDeltaEvent(
                delta=MessageDelta(
                    stop_reason=self.stop_reason or "end_turn",
                    stop_sequence=None,
                ),
                usage=self.usage or Usage(),
            ))
            events.append(MessageStopEvent())

        return events


class GeminiMessageStream:
    """Stream de messages Gemini normalisé au format canonique."""

    def __init__(
        self,
        response: httpx.Response,
        model: str,
    ) -> None:
        self._response = response
        self._buffer = bytearray()
        self._pending: deque[StreamEvent] = deque()
        self._done = False
        self._state = _GeminiStreamState(model)
        self._stream = response.aiter_bytes()

    def request_id(self) -> Optional[str]:
        return None

    async def next_event(self) -> Optional[StreamEvent]:
        while True:
            if self._pending:
                return self._pending.popleft()

            if self._done:
                self._pending.extend(self._state.finish())
                if self._pending:
                    return self._pending.popleft()
                return None

            try:
                chunk_bytes = await self._stream.__anext__()
                parsed_chunks = self._parse_sse_chunks(chunk_bytes)
                for parsed in parsed_chunks:
                    self._pending.extend(self._state.ingest_chunk(parsed))
            except StopAsyncIteration:
                self._done = True

    def _parse_sse_chunks(self, data: bytes) -> list[dict[str, Any]]:
        """Parse les chunks SSE de Gemini en dicts JSON."""
        self._buffer.extend(data)
        results: list[dict[str, Any]] = []

        while True:
            buf = bytes(self._buffer)
            # Gemini utilise le format SSE standard : data: {...}\n\n
            pos = buf.find(b"\n\n")
            sep_len = 2
            if pos == -1:
                pos = buf.find(b"\r\n\r\n")
                sep_len = 4
            if pos == -1:
                break

            frame_bytes = buf[:pos]
            self._buffer = bytearray(buf[pos + sep_len:])
            frame_str = frame_bytes.decode("utf-8", errors="replace")
            parsed = _parse_sse_frame(frame_str)
            if parsed is not None:
                results.append(parsed)

        return results


# --- Construction de la requête Gemini ---


def _build_gemini_request(request: MessageRequest) -> dict[str, Any]:
    """Construit la requête au format Gemini generateContent."""
    body: dict[str, Any] = {}

    # System instruction
    if request.system:
        body["systemInstruction"] = {
            "parts": [{"text": request.system}]
        }

    # Contenus (messages)
    contents = _translate_messages(request.messages)
    body["contents"] = contents

    # Outils (function declarations)
    if request.tools:
        declarations = [_gemini_function_declaration(t) for t in request.tools]
        body["tools"] = [{"functionDeclarations": declarations}]

    # Tool config (tool_choice)
    if request.tool_choice:
        body["toolConfig"] = _gemini_tool_config(request.tool_choice)

    # Config de génération
    body["generationConfig"] = {
        "maxOutputTokens": request.max_tokens,
    }

    return body


def _translate_messages(messages: list[InputMessage]) -> list[dict[str, Any]]:
    """Traduit les messages du format canonique vers le format Gemini."""
    contents: list[dict[str, Any]] = []

    for msg in messages:
        if msg.role == "assistant":
            parts = _translate_assistant_parts(msg.content)
            if parts:
                contents.append({"role": "model", "parts": parts})
        else:
            # user / tool results
            parts = _translate_user_parts(msg.content)
            if parts:
                contents.append({"role": "user", "parts": parts})

    return contents


def _translate_assistant_parts(
    blocks: list[InputContentBlock],
) -> list[dict[str, Any]]:
    """Traduit les blocs assistant vers des parts Gemini."""
    parts: list[dict[str, Any]] = []
    for block in blocks:
        if isinstance(block, TextInputBlock):
            parts.append({"text": block.text})
        elif isinstance(block, ToolUseInputBlock):
            # functionCall dans la réponse du modèle
            args = block.input if isinstance(block.input, dict) else {}
            parts.append({
                "functionCall": {
                    "name": block.name,
                    "args": args,
                }
            })
    return parts


def _translate_user_parts(
    blocks: list[InputContentBlock],
) -> list[dict[str, Any]]:
    """Traduit les blocs user/tool vers des parts Gemini."""
    parts: list[dict[str, Any]] = []
    for block in blocks:
        if isinstance(block, TextInputBlock):
            parts.append({"text": block.text})
        elif isinstance(block, ToolResultInputBlock):
            # functionResponse pour les résultats d'outils
            content_text = _flatten_tool_result_content(block.content)
            parts.append({
                "functionResponse": {
                    "name": block.tool_use_id,  # Gemini attend le nom, on passe l'id
                    "response": {
                        "content": content_text,
                        "is_error": block.is_error,
                    }
                }
            })
    return parts


def _flatten_tool_result_content(content: list[ToolResultContentBlock]) -> str:
    """Aplatit le contenu d'un résultat d'outil en texte."""
    parts: list[str] = []
    for block in content:
        if isinstance(block, TextToolResultBlock):
            parts.append(block.text)
        elif isinstance(block, JsonToolResultBlock):
            parts.append(json.dumps(block.value) if block.value is not None else "")
    return "\n".join(parts)


def _gemini_function_declaration(tool: ToolDefinition) -> dict[str, Any]:
    """Traduit une ToolDefinition vers une functionDeclaration Gemini."""
    decl: dict[str, Any] = {
        "name": tool.name,
    }
    if tool.description:
        decl["description"] = tool.description

    # Gemini attend un schéma OpenAPI pour les paramètres
    if tool.input_schema:
        # Nettoyer le schéma : Gemini n'accepte pas "additionalProperties" au top-level
        schema = dict(tool.input_schema)
        schema.pop("additionalProperties", None)
        # S'assurer que le type est "object" si non spécifié
        if "type" not in schema:
            schema["type"] = "object"
        decl["parameters"] = schema

    return decl


def _gemini_tool_config(tool_choice: ToolChoice) -> dict[str, Any]:
    """Traduit un ToolChoice vers un toolConfig Gemini."""
    if tool_choice.type == ToolChoiceType.AUTO:
        return {"functionCallingConfig": {"mode": "AUTO"}}
    elif tool_choice.type == ToolChoiceType.ANY:
        return {"functionCallingConfig": {"mode": "ANY"}}
    elif tool_choice.type == ToolChoiceType.TOOL:
        config: dict[str, Any] = {"functionCallingConfig": {"mode": "ANY"}}
        if tool_choice.name:
            config["functionCallingConfig"]["allowedFunctionNames"] = [
                tool_choice.name
            ]
        return config
    return {"functionCallingConfig": {"mode": "AUTO"}}


# --- Normalisation de la réponse ---


def _normalize_response(model: str, data: dict[str, Any]) -> MessageResponse:
    """Normalise une réponse Gemini au format canonique."""
    candidates = data.get("candidates", [])
    if not candidates:
        return MessageResponse(
            id="",
            kind="message",
            role="assistant",
            content=[],
            model=model,
            stop_reason="end_turn",
            stop_sequence=None,
            usage=_extract_usage(data),
            request_id=None,
        )

    candidate = candidates[0]
    content_obj = candidate.get("content", {})
    parts = content_obj.get("parts", [])
    finish_reason = candidate.get("finishReason")

    content: list[OutputContentBlock] = []
    tool_call_idx = 0

    for part in parts:
        # Texte
        text = part.get("text")
        if text is not None:
            content.append(TextOutputBlock(text=text))

        # Function call
        fc = part.get("functionCall")
        if fc:
            name = fc.get("name", "")
            args = fc.get("args", {})
            content.append(ToolUseOutputBlock(
                id=f"gemini_call_{tool_call_idx}",
                name=name,
                input=args,
            ))
            tool_call_idx += 1

    return MessageResponse(
        id="",
        kind="message",
        role="assistant",
        content=content,
        model=model,
        stop_reason=_normalize_finish_reason(finish_reason) if finish_reason else "end_turn",
        stop_sequence=None,
        usage=_extract_usage(data),
        request_id=None,
    )


def _extract_usage(data: dict[str, Any]) -> Usage:
    """Extrait les informations d'usage de la réponse."""
    usage_meta = data.get("usageMetadata", {})
    return Usage(
        input_tokens=usage_meta.get("promptTokenCount", 0),
        output_tokens=usage_meta.get("candidatesTokenCount", 0),
    )


def _normalize_finish_reason(value: str) -> str:
    """Normalise un finishReason Gemini vers le format canonique."""
    mapping = {
        "STOP": "end_turn",
        "MAX_TOKENS": "max_tokens",
        "SAFETY": "end_turn",
        "RECITATION": "end_turn",
        "OTHER": "end_turn",
        "FINISH_REASON_UNSPECIFIED": "end_turn",
    }
    return mapping.get(value, "end_turn")


def _parse_sse_frame(frame: str) -> Optional[dict[str, Any]]:
    """Parse une frame SSE en dict JSON."""
    trimmed = frame.strip()
    if not trimmed:
        return None

    data_lines: list[str] = []
    for line in trimmed.splitlines():
        if line.startswith(":"):
            continue
        if line.startswith("data:"):
            data_lines.append(line[len("data:"):].lstrip())

    if not data_lines:
        return None

    payload = "\n".join(data_lines)
    if payload == "[DONE]":
        return None

    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return None


def _expect_success(response: httpx.Response) -> httpx.Response:
    """Vérifie que la réponse est un succès."""
    if response.is_success:
        return response

    body = response.text
    error_type = None
    message = None

    try:
        parsed = response.json()
        error_obj = parsed.get("error", {})
        error_type = str(error_obj.get("code", ""))
        message = error_obj.get("message")
    except Exception:
        pass

    raise ApiResponseError(
        status=response.status_code,
        error_type=error_type,
        message=message,
        body=body,
        retryable=is_retryable_status(response.status_code),
    )


def _error_is_retryable(error: ApiError) -> bool:
    """Vérifie si une erreur est retryable."""
    if isinstance(error, HttpError):
        return True
    if isinstance(error, ApiResponseError):
        return error.retryable
    return False


def _read_env_non_empty(key: str) -> Optional[str]:
    """Lit une variable d'env, retourne None si vide ou absente."""
    value = os.environ.get(key, "")
    return value if value else None
