"""Client Anthropic API — traduit de providers/anthropic.rs."""

from __future__ import annotations

import asyncio
import json
import os
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

import httpx

from ..error import (
    ApiError,
    ApiResponseError,
    AuthError,
    BackoffOverflowError,
    ExpiredOAuthTokenError,
    HttpError,
    IoError,
    JsonError,
    MissingCredentialsError,
    RetriesExhaustedError,
    is_retryable_status,
)
from ..types import MessageRequest, MessageResponse, StreamEvent, Usage
from ..sse import SseParser
from ..serialization import serialize_message_request, deserialize_message_response

DEFAULT_BASE_URL = "https://api.anthropic.com"
_REQUEST_ID_HEADER = "request-id"
_ALT_REQUEST_ID_HEADER = "x-request-id"
_DEFAULT_INITIAL_BACKOFF_MS = 200
_DEFAULT_MAX_BACKOFF_MS = 2000
_DEFAULT_MAX_RETRIES = 2


class AuthSource:
    """Source d'authentification pour l'API Anthropic."""

    def api_key(self) -> Optional[str]:
        return None

    def bearer_token(self) -> Optional[str]:
        return None

    def apply_headers(self, headers: dict[str, str]) -> dict[str, str]:
        """Ajoute les headers d'auth."""
        result = dict(headers)
        if self.api_key():
            result["x-api-key"] = self.api_key()  # type: ignore
        if self.bearer_token():
            result["authorization"] = f"Bearer {self.bearer_token()}"
        return result


class NoAuth(AuthSource):
    """Pas d'authentification."""
    pass


@dataclass
class ApiKeyAuth(AuthSource):
    """Authentification par clé API."""

    _api_key: str = ""

    def api_key(self) -> Optional[str]:
        return self._api_key


@dataclass
class BearerTokenAuth(AuthSource):
    """Authentification par Bearer token."""

    _bearer_token: str = ""

    def bearer_token(self) -> Optional[str]:
        return self._bearer_token


@dataclass
class ApiKeyAndBearerAuth(AuthSource):
    """Authentification combinée clé API + Bearer token."""

    _api_key: str = ""
    _bearer_token: str = ""

    def api_key(self) -> Optional[str]:
        return self._api_key

    def bearer_token(self) -> Optional[str]:
        return self._bearer_token


@dataclass
class OAuthTokenSet:
    """Jeu de tokens OAuth."""

    access_token: str
    refresh_token: Optional[str] = None
    expires_at: Optional[int] = None
    scopes: list[str] = field(default_factory=list)


def auth_source_from_env() -> AuthSource:
    """Crée un AuthSource depuis les variables d'environnement."""
    api_key = _read_env_non_empty("ANTHROPIC_API_KEY")
    auth_token = _read_env_non_empty("ANTHROPIC_AUTH_TOKEN")

    if api_key and auth_token:
        return ApiKeyAndBearerAuth(_api_key=api_key, _bearer_token=auth_token)
    elif api_key:
        return ApiKeyAuth(_api_key=api_key)
    elif auth_token:
        return BearerTokenAuth(_bearer_token=auth_token)
    else:
        raise MissingCredentialsError(
            provider="Anthropic",
            env_vars=("ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_API_KEY"),
        )


def has_auth_from_env_or_saved() -> bool:
    """Vérifie si des credentials sont disponibles dans l'env."""
    return bool(
        _read_env_non_empty("ANTHROPIC_API_KEY")
        or _read_env_non_empty("ANTHROPIC_AUTH_TOKEN")
    )


def oauth_token_is_expired(token_set: OAuthTokenSet) -> bool:
    """Vérifie si un token OAuth est expiré."""
    if token_set.expires_at is None:
        return False
    return token_set.expires_at <= int(time.time())


def resolve_startup_auth_source() -> AuthSource:
    """Résout la source d'auth au démarrage."""
    api_key = _read_env_non_empty("ANTHROPIC_API_KEY")
    auth_token = _read_env_non_empty("ANTHROPIC_AUTH_TOKEN")

    if api_key and auth_token:
        return ApiKeyAndBearerAuth(_api_key=api_key, _bearer_token=auth_token)
    elif api_key:
        return ApiKeyAuth(_api_key=api_key)
    elif auth_token:
        return BearerTokenAuth(_bearer_token=auth_token)

    raise MissingCredentialsError(
        provider="Anthropic",
        env_vars=("ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_API_KEY"),
    )


def resolve_saved_oauth_token() -> Optional[OAuthTokenSet]:
    """Résout un token OAuth sauvegardé."""
    # Placeholder — la gestion du stockage OAuth dépend de runtime
    return None


def read_base_url() -> str:
    """Lit la base URL de l'API depuis l'environnement."""
    return os.environ.get("ANTHROPIC_BASE_URL", DEFAULT_BASE_URL)


class AnthropicClient:
    """Client pour l'API Anthropic Messages."""

    def __init__(
        self,
        auth: Optional[AuthSource] = None,
        api_key: Optional[str] = None,
    ) -> None:
        if auth is not None:
            self._auth = auth
        elif api_key is not None:
            self._auth = ApiKeyAuth(_api_key=api_key)
        else:
            self._auth = auth_source_from_env()

        self._base_url = read_base_url()
        self._max_retries = _DEFAULT_MAX_RETRIES
        self._initial_backoff_ms = _DEFAULT_INITIAL_BACKOFF_MS
        self._max_backoff_ms = _DEFAULT_MAX_BACKOFF_MS
        self._prompt_cache = None
        self._http = httpx.AsyncClient(timeout=60.0)

    @classmethod
    def from_env(cls) -> AnthropicClient:
        """Crée un client depuis les variables d'environnement."""
        return cls(auth=auth_source_from_env())

    @classmethod
    def from_auth(cls, auth: AuthSource) -> AnthropicClient:
        """Crée un client depuis un AuthSource."""
        return cls(auth=auth)

    def with_base_url(self, base_url: str) -> AnthropicClient:
        """Change la base URL."""
        self._base_url = base_url
        return self

    def with_prompt_cache(self, prompt_cache: Any) -> AnthropicClient:
        """Attache un prompt cache."""
        self._prompt_cache = prompt_cache
        return self

    def prompt_cache_stats(self) -> Optional[Any]:
        """Retourne les stats du prompt cache."""
        if self._prompt_cache is not None:
            return self._prompt_cache.stats()
        return None

    def take_last_prompt_cache_record(self) -> Optional[Any]:
        """Récupère et consomme le dernier record du prompt cache."""
        if self._prompt_cache is not None:
            return self._prompt_cache.take_last_record()
        return None

    def auth_source(self) -> AuthSource:
        """Retourne la source d'auth."""
        return self._auth

    async def send_message(self, request: MessageRequest) -> MessageResponse:
        """Envoie un message et attend la réponse complète."""
        req = MessageRequest(
            model=request.model,
            max_tokens=request.max_tokens,
            messages=request.messages,
            system=request.system,
            tools=request.tools,
            tool_choice=request.tool_choice,
            stream=False,
        )

        # Vérifier le cache
        if self._prompt_cache is not None:
            cached = self._prompt_cache.lookup_completion(req)
            if cached is not None:
                return cached

        response = await self._send_with_retry(req)
        request_id = _request_id_from_headers(response.headers)
        data = response.json()
        result = deserialize_message_response(data)
        if result.request_id is None:
            result.request_id = request_id

        # Enregistrer dans le cache
        if self._prompt_cache is not None:
            self._prompt_cache.record_response(req, result)

        return result

    async def stream_message(self, request: MessageRequest) -> AnthropicMessageStream:
        """Envoie un message en mode streaming."""
        streaming_request = request.with_streaming()
        response = await self._send_with_retry(streaming_request)
        return AnthropicMessageStream(
            request_id=_request_id_from_headers(response.headers),
            response=response,
            parser=SseParser(),
            pending=deque(),
            done=False,
        )

    async def _send_with_retry(self, request: MessageRequest) -> httpx.Response:
        """Envoie avec retry et backoff exponentiel."""
        attempts = 0
        last_error: Optional[ApiError] = None

        while True:
            attempts += 1
            try:
                response = await self._send_raw_request(request)
                checked = _expect_success(response)
                return checked
            except ApiError as error:
                if error_is_retryable(error) and attempts <= self._max_retries:
                    last_error = error
                else:
                    if attempts > self._max_retries and last_error is not None:
                        raise RetriesExhaustedError(
                            attempts=attempts, last_error=last_error
                        ) from error
                    raise

            if attempts > self._max_retries:
                break

            backoff = self._backoff_for_attempt(attempts)
            await asyncio.sleep(backoff / 1000.0)

        raise RetriesExhaustedError(
            attempts=attempts,
            last_error=last_error or ApiError("unknown error"),
        )

    async def _send_raw_request(self, request: MessageRequest) -> httpx.Response:
        """Envoie une requête brute à l'API."""
        url = f"{self._base_url.rstrip('/')}/v1/messages"
        headers = {"content-type": "application/json"}
        headers = self._auth.apply_headers(headers)

        body = serialize_message_request(request)

        try:
            response = await self._http.post(url, json=body, headers=headers)
            return response
        except httpx.HTTPError as exc:
            raise HttpError(original=exc) from exc

    def _backoff_for_attempt(self, attempt: int) -> float:
        """Calcule le délai de backoff pour une tentative donnée."""
        try:
            multiplier = 1 << (attempt - 1)
        except (OverflowError, ValueError):
            raise BackoffOverflowError(
                attempt=attempt, base_delay_ms=self._initial_backoff_ms
            )
        delay = self._initial_backoff_ms * multiplier
        return min(delay, self._max_backoff_ms)

    async def close(self) -> None:
        """Ferme le client HTTP."""
        await self._http.aclose()


class AnthropicMessageStream:
    """Stream de messages Anthropic avec parsing SSE."""

    def __init__(
        self,
        request_id: Optional[str],
        response: httpx.Response,
        parser: SseParser,
        pending: deque[StreamEvent],
        done: bool,
    ) -> None:
        self._request_id = request_id
        self._response = response
        self._parser = parser
        self._pending = pending
        self._done = done
        self._stream = response.aiter_bytes()

    def request_id(self) -> Optional[str]:
        """ID de la requête."""
        return self._request_id

    async def next_event(self) -> Optional[StreamEvent]:
        """Retourne le prochain événement du stream."""
        while True:
            if self._pending:
                return self._pending.popleft()

            if self._done:
                events = self._parser.finish()
                self._pending.extend(events)
                if self._pending:
                    return self._pending.popleft()
                return None

            try:
                chunk = await self._stream.__anext__()
                events = self._parser.push(chunk)
                self._pending.extend(events)
            except StopAsyncIteration:
                self._done = True


def error_is_retryable(error: ApiError) -> bool:
    """Vérifie si une erreur est retryable."""
    if isinstance(error, HttpError):
        return True
    if isinstance(error, ApiResponseError):
        return error.retryable
    return False


def _expect_success(response: httpx.Response) -> httpx.Response:
    """Vérifie que la réponse est un succès, sinon lève une erreur."""
    if response.is_success:
        return response

    body = response.text
    error_type = None
    message = None

    try:
        parsed = response.json()
        error_obj = parsed.get("error", {})
        error_type = error_obj.get("type")
        message = error_obj.get("message")
    except Exception:
        pass

    raise ApiResponseError(
        status=response.status_code,
        error_type=error_type,
        message=message,
        body=body,
        retryable=is_retryable_status(response.status_code),
    )


def _request_id_from_headers(headers: httpx.Headers) -> Optional[str]:
    """Extrait l'ID de requête des headers."""
    return headers.get(_REQUEST_ID_HEADER) or headers.get(_ALT_REQUEST_ID_HEADER)


def _read_env_non_empty(key: str) -> Optional[str]:
    """Lit une variable d'env, retourne None si vide ou absente."""
    value = os.environ.get(key, "")
    return value if value else None
