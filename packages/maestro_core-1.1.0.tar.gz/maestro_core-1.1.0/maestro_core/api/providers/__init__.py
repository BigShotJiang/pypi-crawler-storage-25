"""Providers API — registre et routeur de providers LLM.

Supporte : Anthropic, OpenAI, xAI, Gemini, Ollama.
Factory `create_provider()` pour auto-détection depuis le nom de modèle."""

from __future__ import annotations

import os
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional, Union

from .anthropic import DEFAULT_BASE_URL as ANTHROPIC_DEFAULT_BASE_URL, AnthropicClient
from .openai_compat import (
    DEFAULT_XAI_BASE_URL,
    DEFAULT_OPENAI_BASE_URL,
    OpenAiCompatClient,
    OpenAiCompatConfig,
)
from .gemini import GeminiClient
from .ollama import OllamaClient, DEFAULT_OLLAMA_BASE_URL


class ProviderKind(Enum):
    """Type de provider LLM."""

    ANTHROPIC = "anthropic"
    XAI = "xai"
    OPENAI = "openai"
    GEMINI = "gemini"
    OLLAMA = "ollama"


@dataclass(frozen=True)
class ProviderMetadata:
    """Métadonnées d'un provider."""

    provider: ProviderKind
    auth_env: str
    base_url_env: str
    default_base_url: str


# Registre des alias de modèles
_MODEL_REGISTRY: list[tuple[str, ProviderMetadata]] = [
    ("opus", ProviderMetadata(ProviderKind.ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ANTHROPIC_DEFAULT_BASE_URL)),
    ("sonnet", ProviderMetadata(ProviderKind.ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ANTHROPIC_DEFAULT_BASE_URL)),
    ("haiku", ProviderMetadata(ProviderKind.ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ANTHROPIC_DEFAULT_BASE_URL)),
    ("grok", ProviderMetadata(ProviderKind.XAI, "XAI_API_KEY", "XAI_BASE_URL", DEFAULT_XAI_BASE_URL)),
    ("grok-3", ProviderMetadata(ProviderKind.XAI, "XAI_API_KEY", "XAI_BASE_URL", DEFAULT_XAI_BASE_URL)),
    ("grok-mini", ProviderMetadata(ProviderKind.XAI, "XAI_API_KEY", "XAI_BASE_URL", DEFAULT_XAI_BASE_URL)),
    ("grok-3-mini", ProviderMetadata(ProviderKind.XAI, "XAI_API_KEY", "XAI_BASE_URL", DEFAULT_XAI_BASE_URL)),
    ("grok-2", ProviderMetadata(ProviderKind.XAI, "XAI_API_KEY", "XAI_BASE_URL", DEFAULT_XAI_BASE_URL)),
]

# Alias de modèles
_ANTHROPIC_ALIASES = {
    "opus": "claude-opus-4-6",
    "sonnet": "claude-sonnet-4-6",
    "haiku": "claude-haiku-4-5-20251213",
}
_XAI_ALIASES = {
    "grok": "grok-3",
    "grok-3": "grok-3",
    "grok-mini": "grok-3-mini",
    "grok-3-mini": "grok-3-mini",
    "grok-2": "grok-2",
}
_GEMINI_ALIASES = {
    "gemini": "gemini-2.0-flash",
    "gemini-flash": "gemini-2.0-flash",
    "gemini-pro": "gemini-2.0-pro",
    "gemini-ultra": "gemini-ultra",
}


def resolve_model_alias(model: str) -> str:
    """Résout un alias de modèle vers son nom canonique."""
    trimmed = model.strip()
    lower = trimmed.lower()

    if lower in _ANTHROPIC_ALIASES:
        return _ANTHROPIC_ALIASES[lower]
    if lower in _XAI_ALIASES:
        return _XAI_ALIASES[lower]
    if lower in _GEMINI_ALIASES:
        return _GEMINI_ALIASES[lower]
    return trimmed


def metadata_for_model(model: str) -> Optional[ProviderMetadata]:
    """Retourne les métadonnées du provider pour un modèle donné."""
    canonical = resolve_model_alias(model)

    if canonical.startswith("claude"):
        return ProviderMetadata(
            ProviderKind.ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL",
            ANTHROPIC_DEFAULT_BASE_URL,
        )
    if canonical.startswith("grok"):
        return ProviderMetadata(
            ProviderKind.XAI, "XAI_API_KEY", "XAI_BASE_URL", DEFAULT_XAI_BASE_URL,
        )
    if canonical.startswith("gpt") or canonical.startswith("o1") or canonical.startswith("o3"):
        return ProviderMetadata(
            ProviderKind.OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL",
            DEFAULT_OPENAI_BASE_URL,
        )
    if canonical.startswith("gemini"):
        return ProviderMetadata(
            ProviderKind.GEMINI, "GOOGLE_API_KEY", "GEMINI_BASE_URL",
            "https://generativelanguage.googleapis.com/v1beta",
        )
    # Ollama : modèles locaux (llama, mistral, codellama, etc.)
    _OLLAMA_PREFIXES = (
        "llama", "mistral", "mixtral", "codellama", "deepseek",
        "phi", "qwen", "starcoder", "vicuna", "command-r",
        "hermes", "orca", "neural", "wizardlm", "nous",
        "gemma", "yi", "dolphin", "openchat", "tinyllama",
    )
    if any(canonical.lower().startswith(p) for p in _OLLAMA_PREFIXES):
        return ProviderMetadata(
            ProviderKind.OLLAMA, "", "OLLAMA_BASE_URL", DEFAULT_OLLAMA_BASE_URL,
        )

    return None


def detect_provider_kind(model: str) -> ProviderKind:
    """Détecte le provider à partir du nom de modèle ou des variables d'environnement."""
    meta = metadata_for_model(model)
    if meta is not None:
        return meta.provider

    # Fallback : vérifier les clés API dans l'environnement
    if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"):
        return ProviderKind.ANTHROPIC
    if os.environ.get("OPENAI_API_KEY"):
        return ProviderKind.OPENAI
    if os.environ.get("GOOGLE_API_KEY"):
        return ProviderKind.GEMINI
    if os.environ.get("XAI_API_KEY"):
        return ProviderKind.XAI

    return ProviderKind.ANTHROPIC


def max_tokens_for_model(model: str) -> int:
    """Retourne le max_tokens par défaut pour un modèle."""
    canonical = resolve_model_alias(model)
    if "opus" in canonical:
        return 32_000
    if "gemini" in canonical:
        return 8_192
    return 64_000


# --- Type union pour tous les clients ---

ProviderClient = Union[
    AnthropicClient,
    OpenAiCompatClient,
    GeminiClient,
    OllamaClient,
]


def create_provider(
    name_or_model: str,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> ProviderClient:
    """Factory : crée le bon client provider depuis un nom de provider ou de modèle.

    Exemples :
        create_provider("anthropic")           → AnthropicClient
        create_provider("claude-sonnet-4-6")   → AnthropicClient
        create_provider("gpt-4o")              → OpenAiCompatClient
        create_provider("gemini-2.0-flash")    → GeminiClient
        create_provider("ollama")              → OllamaClient
        create_provider("llama3.2")            → OllamaClient
    """
    # D'abord essayer comme nom de provider direct
    provider_map = {
        "anthropic": ProviderKind.ANTHROPIC,
        "openai": ProviderKind.OPENAI,
        "xai": ProviderKind.XAI,
        "gemini": ProviderKind.GEMINI,
        "google": ProviderKind.GEMINI,
        "ollama": ProviderKind.OLLAMA,
        "local": ProviderKind.OLLAMA,
    }

    lower = name_or_model.lower().strip()
    kind = provider_map.get(lower)
    if kind is None:
        # Essayer comme nom de modèle
        kind = detect_provider_kind(name_or_model)

    return _instantiate_provider(kind, api_key=api_key, base_url=base_url)


def _instantiate_provider(
    kind: ProviderKind,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> ProviderClient:
    """Instancie le client pour un provider donné."""
    if kind == ProviderKind.ANTHROPIC:
        client = AnthropicClient(api_key=api_key)
        if base_url:
            client.with_base_url(base_url)
        return client

    elif kind == ProviderKind.OPENAI:
        config = OpenAiCompatConfig.openai()
        if api_key:
            client = OpenAiCompatClient(api_key, config)
        else:
            client = OpenAiCompatClient.from_env(config)
        if base_url:
            client.with_base_url(base_url)
        return client

    elif kind == ProviderKind.XAI:
        config = OpenAiCompatConfig.xai()
        if api_key:
            client = OpenAiCompatClient(api_key, config)
        else:
            client = OpenAiCompatClient.from_env(config)
        if base_url:
            client.with_base_url(base_url)
        return client

    elif kind == ProviderKind.GEMINI:
        return GeminiClient(api_key=api_key)

    elif kind == ProviderKind.OLLAMA:
        return OllamaClient(base_url=base_url)

    else:
        raise ValueError(f"Provider inconnu : {kind}")
