"""Client compatible OpenAI (xAI, OpenAI) — traduit de providers/openai_compat.rs."""

from __future__ import annotations

import asyncio
import json
import os
from collections import OrderedDict, deque
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx

from ..error import (
    ApiError,
    ApiResponseError,
    BackoffOverflowError,
    HttpError,
    JsonError,
    MissingCredentialsError,
    RetriesExhaustedError,
    is_retryable_status,
)
from ..types import (
    ContentBlockDelta,
    ContentBlockDeltaEvent,
    ContentBlockStartEvent,
    ContentBlockStopEvent,
    InputContentBlock,
    InputJsonDelta,
    InputMessage,
    MessageDelta,
    MessageDeltaEvent,
    MessageRequest,
    MessageResponse,
    MessageStartEvent,
    MessageStopEvent,
    OutputContentBlock,
    StreamEvent,
    TextDelta,
    TextInputBlock,
    TextOutputBlock,
    TextToolResultBlock,
    ToolChoice,
    ToolChoiceType,
    ToolDefinition,
    ToolResultContentBlock,
    ToolResultInputBlock,
    ToolUseInputBlock,
    ToolUseOutputBlock,
    JsonToolResultBlock,
    Usage,
)

DEFAULT_XAI_BASE_URL = "https://api.x.ai/v1"
DEFAULT_OPENAI_BASE_URL = "https://api.openai.com/v1"
_REQUEST_ID_HEADER = "request-id"
_ALT_REQUEST_ID_HEADER = "x-request-id"
_DEFAULT_INITIAL_BACKOFF_MS = 200
_DEFAULT_MAX_BACKOFF_MS = 2000
_DEFAULT_MAX_RETRIES = 2


@dataclass(frozen=True)
class OpenAiCompatConfig:
    """Configuration d'un provider compatible OpenAI."""

    provider_name: str
    api_key_env: str
    base_url_env: str
    default_base_url: str

    @classmethod
    def xai(cls) -> OpenAiCompatConfig:
        return cls("xAI", "XAI_API_KEY", "XAI_BASE_URL", DEFAULT_XAI_BASE_URL)

    @classmethod
    def openai(cls) -> OpenAiCompatConfig:
        return cls("OpenAI", "OPENAI_API_KEY", "OPENAI_BASE_URL", DEFAULT_OPENAI_BASE_URL)

    def credential_env_vars(self) -> tuple[str, ...]:
        if self.provider_name == "xAI":
            return ("XAI_API_KEY",)
        elif self.provider_name == "OpenAI":
            return ("OPENAI_API_KEY",)
        return ()


class OpenAiCompatClient:
    """Client compatible OpenAI pour xAI et OpenAI."""

    def __init__(self, api_key: str, config: OpenAiCompatConfig) -> None:
        self._api_key = api_key
        self._config = config
        self._base_url = read_base_url(config)
        self._max_retries = _DEFAULT_MAX_RETRIES
        self._initial_backoff_ms = _DEFAULT_INITIAL_BACKOFF_MS
        self._max_backoff_ms = _DEFAULT_MAX_BACKOFF_MS
        self._http = httpx.AsyncClient(timeout=60.0)

    @classmethod
    def from_env(cls, config: OpenAiCompatConfig) -> OpenAiCompatClient:
        """Crée un client depuis les variables d'environnement."""
        api_key = _read_env_non_empty(config.api_key_env)
        if api_key is None:
            raise MissingCredentialsError(
                provider=config.provider_name,
                env_vars=config.credential_env_vars(),
            )
        return cls(api_key, config)

    def with_base_url(self, base_url: str) -> OpenAiCompatClient:
        self._base_url = base_url
        return self

    async def send_message(self, request: MessageRequest) -> MessageResponse:
        """Envoie un message non-streaming."""
        req = MessageRequest(
            model=request.model,
            max_tokens=request.max_tokens,
            messages=request.messages,
            system=request.system,
            tools=request.tools,
            tool_choice=request.tool_choice,
            stream=False,
        )
        response = await self._send_with_retry(req)
        request_id = _request_id_from_headers(response.headers)
        payload = response.json()
        normalized = _normalize_response(req.model, payload)
        if normalized.request_id is None:
            normalized.request_id = request_id
        return normalized

    async def stream_message(self, request: MessageRequest) -> OpenAiMessageStream:
        """Envoie un message en mode streaming."""
        streaming_request = request.with_streaming()
        response = await self._send_with_retry(streaming_request)
        return OpenAiMessageStream(
            request_id=_request_id_from_headers(response.headers),
            response=response,
            model=request.model,
        )

    async def _send_with_retry(self, request: MessageRequest) -> httpx.Response:
        """Envoie avec retry et backoff."""
        attempts = 0
        last_error: Optional[ApiError] = None

        while True:
            attempts += 1
            try:
                response = await self._send_raw_request(request)
                return _expect_success(response)
            except ApiError as error:
                if _error_is_retryable(error) and attempts <= self._max_retries:
                    last_error = error
                else:
                    if attempts > self._max_retries and last_error is not None:
                        raise RetriesExhaustedError(
                            attempts=attempts, last_error=last_error
                        ) from error
                    raise

            if attempts > self._max_retries:
                break

            backoff = self._backoff_for_attempt(attempts)
            await asyncio.sleep(backoff / 1000.0)

        raise RetriesExhaustedError(
            attempts=attempts,
            last_error=last_error or ApiError("unknown error"),
        )

    async def _send_raw_request(self, request: MessageRequest) -> httpx.Response:
        """Envoie une requête brute."""
        url = _chat_completions_endpoint(self._base_url)
        headers = {
            "content-type": "application/json",
            "authorization": f"Bearer {self._api_key}",
        }
        body = _build_chat_completion_request(request, self._config)

        try:
            return await self._http.post(url, json=body, headers=headers)
        except httpx.HTTPError as exc:
            raise HttpError(original=exc) from exc

    def _backoff_for_attempt(self, attempt: int) -> float:
        try:
            multiplier = 1 << (attempt - 1)
        except (OverflowError, ValueError):
            raise BackoffOverflowError(
                attempt=attempt, base_delay_ms=self._initial_backoff_ms
            )
        delay = self._initial_backoff_ms * multiplier
        return min(delay, self._max_backoff_ms)

    async def close(self) -> None:
        await self._http.aclose()


# --- Stream ---


class _StreamState:
    """État interne du stream OpenAI compatible."""

    def __init__(self, model: str) -> None:
        self.model = model
        self.message_started = False
        self.text_started = False
        self.text_finished = False
        self.finished = False
        self.stop_reason: Optional[str] = None
        self.usage: Optional[Usage] = None
        self.tool_calls: dict[int, _ToolCallState] = {}

    def ingest_chunk(self, chunk: dict[str, Any]) -> list[StreamEvent]:
        """Ingère un chunk OpenAI et retourne les événements normalisés."""
        events: list[StreamEvent] = []

        if not self.message_started:
            self.message_started = True
            events.append(MessageStartEvent(
                message=MessageResponse(
                    id=chunk.get("id", ""),
                    kind="message",
                    role="assistant",
                    content=[],
                    model=chunk.get("model") or self.model,
                    stop_reason=None,
                    stop_sequence=None,
                    usage=Usage(),
                    request_id=None,
                )
            ))

        if "usage" in chunk and chunk["usage"]:
            u = chunk["usage"]
            self.usage = Usage(
                input_tokens=u.get("prompt_tokens", 0),
                output_tokens=u.get("completion_tokens", 0),
            )

        for choice in chunk.get("choices", []):
            delta = choice.get("delta", {})
            content = delta.get("content")

            if content:
                if not self.text_started:
                    self.text_started = True
                    events.append(ContentBlockStartEvent(
                        index=0,
                        content_block=TextOutputBlock(text=""),
                    ))
                events.append(ContentBlockDeltaEvent(
                    index=0,
                    delta=TextDelta(text=content),
                ))

            for tc in delta.get("tool_calls", []):
                idx = tc.get("index", 0)
                if idx not in self.tool_calls:
                    self.tool_calls[idx] = _ToolCallState(openai_index=idx)
                state = self.tool_calls[idx]
                state.apply(tc)
                block_index = state.block_index()

                if not state.started:
                    start_event = state.start_event()
                    if start_event:
                        state.started = True
                        events.append(start_event)
                    else:
                        continue

                delta_event = state.delta_event()
                if delta_event:
                    events.append(delta_event)

                if choice.get("finish_reason") == "tool_calls" and not state.stopped:
                    state.stopped = True
                    events.append(ContentBlockStopEvent(index=block_index))

            finish_reason = choice.get("finish_reason")
            if finish_reason:
                self.stop_reason = _normalize_finish_reason(finish_reason)
                if finish_reason == "tool_calls":
                    for state in self.tool_calls.values():
                        if state.started and not state.stopped:
                            state.stopped = True
                            events.append(ContentBlockStopEvent(index=state.block_index()))

        return events

    def finish(self) -> list[StreamEvent]:
        """Génère les événements de fin de stream."""
        if self.finished:
            return []
        self.finished = True

        events: list[StreamEvent] = []

        if self.text_started and not self.text_finished:
            self.text_finished = True
            events.append(ContentBlockStopEvent(index=0))

        for state in self.tool_calls.values():
            if not state.started:
                start_event = state.start_event()
                if start_event:
                    state.started = True
                    events.append(start_event)
                    delta_event = state.delta_event()
                    if delta_event:
                        events.append(delta_event)
            if state.started and not state.stopped:
                state.stopped = True
                events.append(ContentBlockStopEvent(index=state.block_index()))

        if self.message_started:
            events.append(MessageDeltaEvent(
                delta=MessageDelta(
                    stop_reason=self.stop_reason or "end_turn",
                    stop_sequence=None,
                ),
                usage=self.usage or Usage(),
            ))
            events.append(MessageStopEvent())

        return events


@dataclass
class _ToolCallState:
    """État d'un appel d'outil en streaming OpenAI."""

    openai_index: int = 0
    id: Optional[str] = None
    name: Optional[str] = None
    arguments: str = ""
    emitted_len: int = 0
    started: bool = False
    stopped: bool = False

    def apply(self, tool_call: dict[str, Any]) -> None:
        self.openai_index = tool_call.get("index", self.openai_index)
        if "id" in tool_call and tool_call["id"]:
            self.id = tool_call["id"]
        func = tool_call.get("function", {})
        if "name" in func and func["name"]:
            self.name = func["name"]
        if "arguments" in func and func["arguments"]:
            self.arguments += func["arguments"]

    def block_index(self) -> int:
        return self.openai_index + 1

    def start_event(self) -> Optional[ContentBlockStartEvent]:
        if self.name is None:
            return None
        call_id = self.id or f"tool_call_{self.openai_index}"
        return ContentBlockStartEvent(
            index=self.block_index(),
            content_block=ToolUseOutputBlock(
                id=call_id, name=self.name, input={}
            ),
        )

    def delta_event(self) -> Optional[ContentBlockDeltaEvent]:
        if self.emitted_len >= len(self.arguments):
            return None
        delta_text = self.arguments[self.emitted_len :]
        self.emitted_len = len(self.arguments)
        return ContentBlockDeltaEvent(
            index=self.block_index(),
            delta=InputJsonDelta(partial_json=delta_text),
        )


class OpenAiMessageStream:
    """Stream de messages normalisé au format Anthropic."""

    def __init__(
        self,
        request_id: Optional[str],
        response: httpx.Response,
        model: str,
    ) -> None:
        self._request_id = request_id
        self._response = response
        self._buffer = bytearray()
        self._pending: deque[StreamEvent] = deque()
        self._done = False
        self._state = _StreamState(model)
        self._stream = response.aiter_bytes()

    def request_id(self) -> Optional[str]:
        return self._request_id

    async def next_event(self) -> Optional[StreamEvent]:
        while True:
            if self._pending:
                return self._pending.popleft()

            if self._done:
                self._pending.extend(self._state.finish())
                if self._pending:
                    return self._pending.popleft()
                return None

            try:
                chunk_bytes = await self._stream.__anext__()
                parsed_chunks = self._parse_sse_chunks(chunk_bytes)
                for parsed in parsed_chunks:
                    self._pending.extend(self._state.ingest_chunk(parsed))
            except StopAsyncIteration:
                self._done = True

    def _parse_sse_chunks(self, data: bytes) -> list[dict[str, Any]]:
        """Parse les chunks SSE en dicts JSON."""
        self._buffer.extend(data)
        results: list[dict[str, Any]] = []

        while True:
            buf = bytes(self._buffer)
            pos = buf.find(b"\n\n")
            sep_len = 2
            if pos == -1:
                pos = buf.find(b"\r\n\r\n")
                sep_len = 4
            if pos == -1:
                break

            frame_bytes = buf[:pos]
            self._buffer = bytearray(buf[pos + sep_len :])
            frame_str = frame_bytes.decode("utf-8", errors="replace")
            parsed = _parse_sse_frame(frame_str)
            if parsed is not None:
                results.append(parsed)

        return results


# --- Fonctions utilitaires ---


def _build_chat_completion_request(
    request: MessageRequest, config: OpenAiCompatConfig
) -> dict[str, Any]:
    """Construit la requête au format OpenAI Chat Completions."""
    messages: list[dict[str, Any]] = []

    if request.system:
        messages.append({"role": "system", "content": request.system})

    for msg in request.messages:
        messages.extend(_translate_message(msg))

    payload: dict[str, Any] = {
        "model": request.model,
        "max_tokens": request.max_tokens,
        "messages": messages,
        "stream": request.stream,
    }

    if request.stream and config.provider_name == "OpenAI":
        payload["stream_options"] = {"include_usage": True}

    if request.tools:
        payload["tools"] = [_openai_tool_definition(t) for t in request.tools]

    if request.tool_choice:
        payload["tool_choice"] = _openai_tool_choice(request.tool_choice)

    return payload


def _translate_message(message: InputMessage) -> list[dict[str, Any]]:
    """Traduit un InputMessage au format OpenAI."""
    if message.role == "assistant":
        text = ""
        tool_calls: list[dict[str, Any]] = []
        for block in message.content:
            if isinstance(block, TextInputBlock):
                text += block.text
            elif isinstance(block, ToolUseInputBlock):
                tool_calls.append({
                    "id": block.id,
                    "type": "function",
                    "function": {
                        "name": block.name,
                        "arguments": json.dumps(block.input) if not isinstance(block.input, str) else block.input,
                    },
                })
        if not text and not tool_calls:
            return []
        msg: dict[str, Any] = {"role": "assistant"}
        if text:
            msg["content"] = text
        if tool_calls:
            msg["tool_calls"] = tool_calls
        return [msg]

    # user / tool messages
    results: list[dict[str, Any]] = []
    for block in message.content:
        if isinstance(block, TextInputBlock):
            results.append({"role": "user", "content": block.text})
        elif isinstance(block, ToolResultInputBlock):
            content_text = _flatten_tool_result_content(block.content)
            results.append({
                "role": "tool",
                "tool_call_id": block.tool_use_id,
                "content": content_text,
                "is_error": block.is_error,
            })
    return results


def _flatten_tool_result_content(content: list[ToolResultContentBlock]) -> str:
    """Aplatit le contenu d'un résultat d'outil en texte."""
    parts: list[str] = []
    for block in content:
        if isinstance(block, TextToolResultBlock):
            parts.append(block.text)
        elif isinstance(block, JsonToolResultBlock):
            parts.append(json.dumps(block.value) if block.value is not None else "")
    return "\n".join(parts)


def _openai_tool_definition(tool: ToolDefinition) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.input_schema,
        },
    }


def _openai_tool_choice(tool_choice: ToolChoice) -> Any:
    if tool_choice.type == ToolChoiceType.AUTO:
        return "auto"
    elif tool_choice.type == ToolChoiceType.ANY:
        return "required"
    elif tool_choice.type == ToolChoiceType.TOOL:
        return {"type": "function", "function": {"name": tool_choice.name}}
    return "auto"


def _normalize_response(model: str, data: dict[str, Any]) -> MessageResponse:
    """Normalise une réponse OpenAI au format Anthropic."""
    choices = data.get("choices", [])
    if not choices:
        raise JsonError(ValueError("chat completion response missing choices"))

    choice = choices[0]
    message = choice.get("message", {})
    content: list[OutputContentBlock] = []

    text = message.get("content")
    # Certains modèles (qwen3, deepseek-r1) utilisent "reasoning" au lieu de "content"
    reasoning = message.get("reasoning")
    if reasoning and not text:
        text = reasoning
    if text:
        content.append(TextOutputBlock(text=text))

    for tc in message.get("tool_calls", []):
        func = tc.get("function", {})
        arguments_str = func.get("arguments", "{}")
        try:
            input_value = json.loads(arguments_str)
        except json.JSONDecodeError:
            input_value = {"raw": arguments_str}
        content.append(ToolUseOutputBlock(
            id=tc.get("id", ""),
            name=func.get("name", ""),
            input=input_value,
        ))

    usage_data = data.get("usage", {})
    finish_reason = choice.get("finish_reason")

    return MessageResponse(
        id=data.get("id", ""),
        kind="message",
        role=message.get("role", "assistant"),
        content=content,
        model=data.get("model", "") or model,
        stop_reason=_normalize_finish_reason(finish_reason) if finish_reason else None,
        stop_sequence=None,
        usage=Usage(
            input_tokens=usage_data.get("prompt_tokens", 0),
            output_tokens=usage_data.get("completion_tokens", 0),
        ),
        request_id=None,
    )


def _normalize_finish_reason(value: str) -> str:
    """Normalise un finish_reason OpenAI vers le format Anthropic."""
    mapping = {"stop": "end_turn", "tool_calls": "tool_use"}
    return mapping.get(value, value)


def _parse_sse_frame(frame: str) -> Optional[dict[str, Any]]:
    """Parse une frame SSE en dict JSON."""
    trimmed = frame.strip()
    if not trimmed:
        return None

    data_lines: list[str] = []
    for line in trimmed.splitlines():
        if line.startswith(":"):
            continue
        if line.startswith("data:"):
            data_lines.append(line[len("data:") :].lstrip())

    if not data_lines:
        return None

    payload = "\n".join(data_lines)
    if payload == "[DONE]":
        return None

    return json.loads(payload)


def has_api_key(key: str) -> bool:
    """Vérifie si une clé API est présente dans l'environnement."""
    return bool(_read_env_non_empty(key))


def read_base_url(config: OpenAiCompatConfig) -> str:
    """Lit la base URL depuis l'environnement."""
    return os.environ.get(config.base_url_env, config.default_base_url)


def _chat_completions_endpoint(base_url: str) -> str:
    """Construit l'URL de l'endpoint chat/completions."""
    trimmed = base_url.rstrip("/")
    if trimmed.endswith("/chat/completions"):
        return trimmed
    return f"{trimmed}/chat/completions"


def _expect_success(response: httpx.Response) -> httpx.Response:
    """Vérifie le succès de la réponse HTTP."""
    if response.is_success:
        return response

    body = response.text
    error_type = None
    message = None

    try:
        parsed = response.json()
        error_obj = parsed.get("error", {})
        error_type = error_obj.get("type")
        message = error_obj.get("message")
    except Exception:
        pass

    raise ApiResponseError(
        status=response.status_code,
        error_type=error_type,
        message=message,
        body=body,
        retryable=is_retryable_status(response.status_code),
    )


def _request_id_from_headers(headers: httpx.Headers) -> Optional[str]:
    return headers.get(_REQUEST_ID_HEADER) or headers.get(_ALT_REQUEST_ID_HEADER)


def _read_env_non_empty(key: str) -> Optional[str]:
    value = os.environ.get(key, "")
    return value if value else None


def _error_is_retryable(error: ApiError) -> bool:
    if isinstance(error, HttpError):
        return True
    if isinstance(error, ApiResponseError):
        return error.retryable
    return False
