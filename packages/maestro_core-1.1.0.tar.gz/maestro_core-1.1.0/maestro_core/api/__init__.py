"""Package API — traduit de api/lib.rs.

Fournit les clients multi-provider (Anthropic, xAI, OpenAI),
le parsing SSE, le prompt cache et tous les types de l'API Messages.
"""

from .client import (
    MessageStream,
    ProviderClient,
    read_xai_base_url,
)
from .error import (
    ApiError,
    ApiResponseError,
    AuthError,
    BackoffOverflowError,
    ExpiredOAuthTokenError,
    HttpError,
    InvalidApiKeyEnvError,
    InvalidSseFrameError,
    IoError,
    JsonError,
    MissingCredentialsError,
    RetriesExhaustedError,
)
from .prompt_cache import (
    CacheBreakEvent,
    PromptCache,
    PromptCacheConfig,
    PromptCachePaths,
    PromptCacheRecord,
    PromptCacheStats,
)
from .providers import (
    ProviderKind,
    detect_provider_kind,
    max_tokens_for_model,
    resolve_model_alias,
)
from .providers.anthropic import (
    AnthropicClient,
    AuthSource,
    OAuthTokenSet,
    oauth_token_is_expired,
    read_base_url,
    resolve_saved_oauth_token,
    resolve_startup_auth_source,
)
from .providers.openai_compat import (
    OpenAiCompatClient,
    OpenAiCompatConfig,
)
from .sse import SseParser, parse_frame
from .types import (
    ContentBlockDelta,
    ContentBlockDeltaEvent,
    ContentBlockStartEvent,
    ContentBlockStopEvent,
    InputContentBlock,
    InputMessage,
    MessageDelta,
    MessageDeltaEvent,
    MessageRequest,
    MessageResponse,
    MessageStartEvent,
    MessageStopEvent,
    OutputContentBlock,
    StreamEvent,
    ToolChoice,
    ToolDefinition,
    ToolResultContentBlock,
    Usage,
)

__all__ = [
    # Client
    "ProviderClient",
    "MessageStream",
    "read_xai_base_url",
    # Error
    "ApiError",
    "ApiResponseError",
    "AuthError",
    "BackoffOverflowError",
    "ExpiredOAuthTokenError",
    "HttpError",
    "InvalidApiKeyEnvError",
    "InvalidSseFrameError",
    "IoError",
    "JsonError",
    "MissingCredentialsError",
    "RetriesExhaustedError",
    # Prompt cache
    "CacheBreakEvent",
    "PromptCache",
    "PromptCacheConfig",
    "PromptCachePaths",
    "PromptCacheRecord",
    "PromptCacheStats",
    # Providers
    "AnthropicClient",
    "AuthSource",
    "OAuthTokenSet",
    "OpenAiCompatClient",
    "OpenAiCompatConfig",
    "ProviderKind",
    "detect_provider_kind",
    "max_tokens_for_model",
    "oauth_token_is_expired",
    "read_base_url",
    "resolve_model_alias",
    "resolve_saved_oauth_token",
    "resolve_startup_auth_source",
    # SSE
    "SseParser",
    "parse_frame",
    # Types
    "ContentBlockDelta",
    "ContentBlockDeltaEvent",
    "ContentBlockStartEvent",
    "ContentBlockStopEvent",
    "InputContentBlock",
    "InputMessage",
    "MessageDelta",
    "MessageDeltaEvent",
    "MessageRequest",
    "MessageResponse",
    "MessageStartEvent",
    "MessageStopEvent",
    "OutputContentBlock",
    "StreamEvent",
    "ToolChoice",
    "ToolDefinition",
    "ToolResultContentBlock",
    "Usage",
]
