"""Erreurs de l'API — traduit de error.rs."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


class ApiError(Exception):
    """Classe de base pour toutes les erreurs API."""


@dataclass
class MissingCredentialsError(ApiError):
    """Identifiants manquants pour un provider."""

    provider: str
    env_vars: tuple[str, ...]

    def __str__(self) -> str:
        joined = " or ".join(self.env_vars)
        return (
            f"missing {self.provider} credentials; export {joined} "
            f"before calling the {self.provider} API"
        )


class ExpiredOAuthTokenError(ApiError):
    """Le token OAuth sauvegardé est expiré sans refresh token disponible."""

    def __str__(self) -> str:
        return "saved OAuth token is expired and no refresh token is available"


@dataclass
class AuthError(ApiError):
    """Erreur d'authentification."""

    message: str

    def __str__(self) -> str:
        return f"auth error: {self.message}"


@dataclass
class InvalidApiKeyEnvError(ApiError):
    """Variable d'environnement de credential invalide."""

    original: Exception

    def __str__(self) -> str:
        return f"failed to read credential environment variable: {self.original}"


@dataclass
class HttpError(ApiError):
    """Erreur HTTP (connexion, timeout, etc.)."""

    original: Exception

    def __str__(self) -> str:
        return f"http error: {self.original}"


@dataclass
class IoError(ApiError):
    """Erreur I/O."""

    original: Exception

    def __str__(self) -> str:
        return f"io error: {self.original}"


@dataclass
class JsonError(ApiError):
    """Erreur de parsing JSON."""

    original: Exception

    def __str__(self) -> str:
        return f"json error: {self.original}"


@dataclass
class ApiResponseError(ApiError):
    """Erreur retournée par l'API."""

    status: int
    error_type: Optional[str] = None
    message: Optional[str] = None
    body: str = ""
    retryable: bool = False

    def __str__(self) -> str:
        if self.error_type and self.message:
            return f"api returned {self.status} ({self.error_type}): {self.message}"
        return f"api returned {self.status}: {self.body}"

    def is_retryable(self) -> bool:
        return self.retryable


@dataclass
class RetriesExhaustedError(ApiError):
    """Nombre maximum de retries atteint."""

    attempts: int
    last_error: ApiError

    def __str__(self) -> str:
        return f"api failed after {self.attempts} attempts: {self.last_error}"

    def is_retryable(self) -> bool:
        return _is_retryable(self.last_error)


@dataclass
class InvalidSseFrameError(ApiError):
    """Frame SSE invalide."""

    detail: str

    def __str__(self) -> str:
        return f"invalid sse frame: {self.detail}"


@dataclass
class BackoffOverflowError(ApiError):
    """Dépassement du calcul de backoff exponentiel."""

    attempt: int
    base_delay_ms: float

    def __str__(self) -> str:
        return (
            f"retry backoff overflowed on attempt {self.attempt} "
            f"with base delay {self.base_delay_ms}ms"
        )


def _is_retryable(error: ApiError) -> bool:
    """Détermine si une erreur est retryable."""
    if isinstance(error, HttpError):
        return True
    if isinstance(error, ApiResponseError):
        return error.retryable
    if isinstance(error, RetriesExhaustedError):
        return _is_retryable(error.last_error)
    return False


def is_retryable_status(status: int) -> bool:
    """Vérifie si un code HTTP est retryable."""
    return status in (408, 409, 429, 500, 502, 503, 504)
