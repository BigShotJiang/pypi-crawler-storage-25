"""Client provider unifié — traduit de client.rs.

Abstraction qui route vers Anthropic, xAI ou OpenAI
selon le modèle demandé.
"""

from __future__ import annotations

from typing import Optional, Union

from .error import ApiError
from .prompt_cache import PromptCache, PromptCacheRecord, PromptCacheStats
from .providers import ProviderKind, detect_provider_kind, resolve_model_alias
from .providers.anthropic import (
    AnthropicClient,
    AnthropicMessageStream,
    AuthSource,
    OAuthTokenSet,
    oauth_token_is_expired,
    read_base_url,
    resolve_saved_oauth_token,
    resolve_startup_auth_source,
)
from .providers.openai_compat import (
    OpenAiCompatClient,
    OpenAiCompatConfig,
    OpenAiMessageStream,
)
from .types import MessageRequest, MessageResponse, StreamEvent


# Union des streams
MessageStream = Union[AnthropicMessageStream, OpenAiMessageStream]


class ProviderClient:
    """Client unifié multi-provider.

    Route automatiquement vers le bon provider (Anthropic, xAI, OpenAI)
    en fonction du modèle.
    """

    def __init__(
        self,
        kind: ProviderKind,
        anthropic: Optional[AnthropicClient] = None,
        openai_compat: Optional[OpenAiCompatClient] = None,
    ) -> None:
        self._kind = kind
        self._anthropic = anthropic
        self._openai_compat = openai_compat

    @classmethod
    def from_model(cls, model: str) -> ProviderClient:
        """Crée un client depuis un nom de modèle."""
        return cls.from_model_with_anthropic_auth(model, None)

    @classmethod
    def from_model_with_anthropic_auth(
        cls, model: str, anthropic_auth: Optional[AuthSource] = None
    ) -> ProviderClient:
        """Crée un client avec une source d'auth spécifique pour Anthropic."""
        resolved = resolve_model_alias(model)
        kind = detect_provider_kind(resolved)

        if kind == ProviderKind.ANTHROPIC:
            if anthropic_auth is not None:
                client = AnthropicClient.from_auth(anthropic_auth)
            else:
                client = AnthropicClient.from_env()
            return cls(kind=kind, anthropic=client)
        elif kind == ProviderKind.XAI:
            client = OpenAiCompatClient.from_env(OpenAiCompatConfig.xai())
            return cls(kind=kind, openai_compat=client)
        elif kind == ProviderKind.OPENAI:
            client = OpenAiCompatClient.from_env(OpenAiCompatConfig.openai())
            return cls(kind=kind, openai_compat=client)
        else:
            raise ApiError(f"unsupported provider kind: {kind}")

    @property
    def provider_kind(self) -> ProviderKind:
        """Type de provider utilisé."""
        return self._kind

    def with_prompt_cache(self, prompt_cache: PromptCache) -> ProviderClient:
        """Attache un prompt cache (Anthropic seulement)."""
        if self._anthropic is not None:
            self._anthropic = self._anthropic.with_prompt_cache(prompt_cache)
        return self

    def prompt_cache_stats(self) -> Optional[PromptCacheStats]:
        """Retourne les stats du prompt cache."""
        if self._anthropic is not None:
            return self._anthropic.prompt_cache_stats()
        return None

    def take_last_prompt_cache_record(self) -> Optional[PromptCacheRecord]:
        """Récupère le dernier record du prompt cache."""
        if self._anthropic is not None:
            return self._anthropic.take_last_prompt_cache_record()
        return None

    async def send_message(self, request: MessageRequest) -> MessageResponse:
        """Envoie un message et attend la réponse complète."""
        if self._anthropic is not None:
            return await self._anthropic.send_message(request)
        elif self._openai_compat is not None:
            return await self._openai_compat.send_message(request)
        raise ApiError("no provider client configured")

    async def stream_message(self, request: MessageRequest) -> MessageStream:
        """Envoie un message en mode streaming."""
        if self._anthropic is not None:
            return await self._anthropic.stream_message(request)
        elif self._openai_compat is not None:
            return await self._openai_compat.stream_message(request)
        raise ApiError("no provider client configured")

    async def close(self) -> None:
        """Ferme le client HTTP."""
        if self._anthropic is not None:
            await self._anthropic.close()
        if self._openai_compat is not None:
            await self._openai_compat.close()


def read_xai_base_url() -> str:
    """Lit la base URL de xAI depuis l'environnement."""
    from .providers.openai_compat import read_base_url

    return read_base_url(OpenAiCompatConfig.xai())
