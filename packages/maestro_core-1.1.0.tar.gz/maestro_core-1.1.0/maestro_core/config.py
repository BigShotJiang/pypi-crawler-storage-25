"""Configuration Maestro — ~/.maestro/config.yaml

Gère la configuration persistante : providers, trust mode, modèles par défaut."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


_CONFIG_DIR = Path.home() / ".maestro"
_CONFIG_FILE = _CONFIG_DIR / "config.yaml"


@dataclass
class ProviderConfig:
    """Configuration d'un provider LLM."""

    name: str
    api_key_env: str = ""
    base_url: str = ""
    default_model: str = ""
    enabled: bool = True


@dataclass
class TrustConfig:
    """Configuration du trust layer."""

    default_mode: str = "standard"  # full | standard | off
    detect_names: bool = True
    detect_amounts: bool = False  # seulement en mode full


@dataclass
class MaestroConfig:
    """Configuration globale Maestro."""

    # Provider par défaut
    default_provider: str = "anthropic"
    default_model: str = "claude-sonnet-4-20250514"

    # Trust layer
    trust: TrustConfig = field(default_factory=TrustConfig)

    # Providers configurés
    providers: dict[str, ProviderConfig] = field(default_factory=lambda: {
        "anthropic": ProviderConfig(
            name="anthropic",
            api_key_env="ANTHROPIC_API_KEY",
            default_model="claude-sonnet-4-20250514",
        ),
        "openai": ProviderConfig(
            name="openai",
            api_key_env="OPENAI_API_KEY",
            default_model="gpt-4.1",
        ),
        "gemini": ProviderConfig(
            name="gemini",
            api_key_env="GOOGLE_API_KEY",
            default_model="gemini-2.5-pro",
        ),
        "ollama": ProviderConfig(
            name="ollama",
            base_url="http://localhost:11434/v1",
            default_model="gemma4:26b-a4b",
        ),
    })

    # Session
    session_dir: str = str(_CONFIG_DIR / "sessions")
    max_context_tokens: int = 200_000
    compaction_threshold: float = 0.8

    @classmethod
    def load(cls) -> MaestroConfig:
        """Charge la config depuis ~/.maestro/config.yaml ou crée les défauts."""
        if _CONFIG_FILE.exists():
            try:
                raw = yaml.safe_load(_CONFIG_FILE.read_text())
                if raw and isinstance(raw, dict):
                    return cls._from_dict(raw)
            except (yaml.YAMLError, KeyError):
                pass
        return cls()

    def save(self) -> None:
        """Sauvegarde la config dans ~/.maestro/config.yaml."""
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = self._to_dict()
        _CONFIG_FILE.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))

    def get_provider_config(self, name: Optional[str] = None) -> ProviderConfig:
        """Retourne la config du provider demandé (ou le défaut)."""
        provider_name = name or self.default_provider
        return self.providers.get(provider_name, self.providers["anthropic"])

    def resolve_model(self, model: Optional[str] = None, provider: Optional[str] = None) -> str:
        """Résout le modèle à utiliser."""
        if model:
            return model
        pc = self.get_provider_config(provider)
        return pc.default_model or self.default_model

    def resolve_provider_for_model(self, model: str) -> str:
        """Déduit le provider à partir du nom du modèle."""
        model_lower = model.lower()
        if model_lower.startswith("claude") or model_lower.startswith("anthropic"):
            return "anthropic"
        if model_lower.startswith("gpt") or model_lower.startswith("o1") or model_lower.startswith("o3"):
            return "openai"
        if model_lower.startswith("gemini"):
            return "gemini"
        # Tout le reste → Ollama (local)
        return "ollama"

    @classmethod
    def _from_dict(cls, data: dict) -> MaestroConfig:
        config = cls()
        config.default_provider = data.get("default_provider", config.default_provider)
        config.default_model = data.get("default_model", config.default_model)

        if "trust" in data and isinstance(data["trust"], dict):
            config.trust = TrustConfig(
                default_mode=data["trust"].get("default_mode", "standard"),
                detect_names=data["trust"].get("detect_names", True),
                detect_amounts=data["trust"].get("detect_amounts", False),
            )

        if "providers" in data and isinstance(data["providers"], dict):
            for name, pdata in data["providers"].items():
                if isinstance(pdata, dict):
                    config.providers[name] = ProviderConfig(
                        name=name,
                        api_key_env=pdata.get("api_key_env", ""),
                        base_url=pdata.get("base_url", ""),
                        default_model=pdata.get("default_model", ""),
                        enabled=pdata.get("enabled", True),
                    )

        config.session_dir = data.get("session_dir", config.session_dir)
        config.max_context_tokens = data.get("max_context_tokens", config.max_context_tokens)
        config.compaction_threshold = data.get("compaction_threshold", config.compaction_threshold)
        return config

    def _to_dict(self) -> dict:
        return {
            "default_provider": self.default_provider,
            "default_model": self.default_model,
            "trust": {
                "default_mode": self.trust.default_mode,
                "detect_names": self.trust.detect_names,
                "detect_amounts": self.trust.detect_amounts,
            },
            "providers": {
                name: {
                    "api_key_env": p.api_key_env,
                    "base_url": p.base_url,
                    "default_model": p.default_model,
                    "enabled": p.enabled,
                }
                for name, p in self.providers.items()
            },
            "session_dir": self.session_dir,
            "max_context_tokens": self.max_context_tokens,
            "compaction_threshold": self.compaction_threshold,
        }
