"""Hook runner -- execution des hooks pre/post tool use via des commandes shell."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from maestro_core.plugins.registry import PluginHooks, PluginRegistry


# -- Types --


class HookEvent(str, Enum):
    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    POST_TOOL_USE_FAILURE = "PostToolUseFailure"


class HookCommandOutcome(Enum):
    ALLOW = "allow"
    DENY = "deny"
    FAILED = "failed"


@dataclass
class HookRunResult:
    """Resultat de l'execution d'une serie de hooks."""

    denied: bool = False
    failed: bool = False
    messages: list[str] = field(default_factory=list)

    @classmethod
    def allow(cls, messages: list[str] | None = None) -> HookRunResult:
        return cls(denied=False, failed=False, messages=messages or [])

    @property
    def is_denied(self) -> bool:
        return self.denied

    @property
    def is_failed(self) -> bool:
        return self.failed


# -- Hook Runner --


class HookRunner:
    """Executeur de hooks de plugins -- pre/post tool use."""

    def __init__(self, hooks: PluginHooks | None = None) -> None:
        from maestro_core.plugins.registry import PluginHooks as _PH

        self._hooks = hooks or _PH()

    @classmethod
    def from_registry(cls, registry: PluginRegistry) -> HookRunner:
        hooks = registry.aggregated_hooks()
        return cls(hooks=hooks)

    def run_pre_tool_use(self, tool_name: str, tool_input: str) -> HookRunResult:
        return self._run_commands(
            HookEvent.PRE_TOOL_USE,
            self._hooks.pre_tool_use,
            tool_name,
            tool_input,
            tool_output=None,
            is_error=False,
        )

    def run_post_tool_use(
        self,
        tool_name: str,
        tool_input: str,
        tool_output: str,
        is_error: bool,
    ) -> HookRunResult:
        return self._run_commands(
            HookEvent.POST_TOOL_USE,
            self._hooks.post_tool_use,
            tool_name,
            tool_input,
            tool_output=tool_output,
            is_error=is_error,
        )

    def run_post_tool_use_failure(
        self,
        tool_name: str,
        tool_input: str,
        tool_error: str,
    ) -> HookRunResult:
        return self._run_commands(
            HookEvent.POST_TOOL_USE_FAILURE,
            self._hooks.post_tool_use_failure,
            tool_name,
            tool_input,
            tool_output=tool_error,
            is_error=True,
        )

    def _run_commands(
        self,
        event: HookEvent,
        commands: list[str],
        tool_name: str,
        tool_input: str,
        tool_output: str | None,
        is_error: bool,
    ) -> HookRunResult:
        if not commands:
            return HookRunResult.allow()

        payload = _hook_payload(event, tool_name, tool_input, tool_output, is_error)
        payload_str = json.dumps(payload, ensure_ascii=False)
        messages: list[str] = []

        for command in commands:
            outcome, message = self._run_command(
                command, event, tool_name, tool_input, tool_output, is_error, payload_str
            )
            if outcome == HookCommandOutcome.ALLOW:
                if message:
                    messages.append(message)
            elif outcome == HookCommandOutcome.DENY:
                messages.append(
                    message
                    or f"{event.value} hook denied tool `{tool_name}`"
                )
                return HookRunResult(denied=True, failed=False, messages=messages)
            elif outcome == HookCommandOutcome.FAILED:
                messages.append(message or f"{event.value} hook `{command}` failed")
                return HookRunResult(denied=False, failed=True, messages=messages)

        return HookRunResult.allow(messages)

    def _run_command(
        self,
        command: str,
        event: HookEvent,
        tool_name: str,
        tool_input: str,
        tool_output: str | None,
        is_error: bool,
        payload: str,
    ) -> tuple[HookCommandOutcome, str | None]:
        env = dict(os.environ)
        env["HOOK_EVENT"] = event.value
        env["HOOK_TOOL_NAME"] = tool_name
        env["HOOK_TOOL_INPUT"] = tool_input
        env["HOOK_TOOL_IS_ERROR"] = "1" if is_error else "0"
        if tool_output is not None:
            env["HOOK_TOOL_OUTPUT"] = tool_output

        # Construire la commande shell
        cmd = _shell_command(command)

        try:
            result = subprocess.run(
                cmd,
                input=payload,
                capture_output=True,
                text=True,
                env=env,
                timeout=30,
            )
        except FileNotFoundError:
            return (
                HookCommandOutcome.FAILED,
                f"{event.value} hook `{command}` failed to start for `{tool_name}`: command not found",
            )
        except subprocess.TimeoutExpired:
            return (
                HookCommandOutcome.FAILED,
                f"{event.value} hook `{command}` timed out for `{tool_name}`",
            )

        stdout = result.stdout.strip()
        stderr = result.stderr.strip()
        message = stdout if stdout else None
        code = result.returncode

        if code == 0:
            return (HookCommandOutcome.ALLOW, message)
        elif code == 2:
            return (HookCommandOutcome.DENY, message)
        else:
            warning = _format_hook_warning(command, code, message, stderr)
            return (HookCommandOutcome.FAILED, warning)


# -- Helpers --


def _hook_payload(
    event: HookEvent,
    tool_name: str,
    tool_input: str,
    tool_output: str | None,
    is_error: bool,
) -> dict:
    """Construit le payload JSON envoye au hook via stdin."""
    parsed_input = _parse_tool_input(tool_input)

    if event == HookEvent.POST_TOOL_USE_FAILURE:
        return {
            "hook_event_name": event.value,
            "tool_name": tool_name,
            "tool_input": parsed_input,
            "tool_input_json": tool_input,
            "tool_error": tool_output,
            "tool_result_is_error": True,
        }
    return {
        "hook_event_name": event.value,
        "tool_name": tool_name,
        "tool_input": parsed_input,
        "tool_input_json": tool_input,
        "tool_output": tool_output,
        "tool_result_is_error": is_error,
    }


def _parse_tool_input(tool_input: str) -> dict | str:
    try:
        return json.loads(tool_input)
    except (json.JSONDecodeError, TypeError):
        return {"raw": tool_input}


def _format_hook_warning(
    command: str, code: int, stdout: str | None, stderr: str
) -> str:
    message = f"Hook `{command}` exited with status {code}"
    if stdout:
        message += f": {stdout}"
    elif stderr:
        message += f": {stderr}"
    return message


def _shell_command(command: str) -> list[str]:
    """Construit la commande shell a executer."""
    if sys.platform == "win32":
        return ["cmd", "/C", command]

    if Path(command).exists():
        return ["sh", command]
    return ["sh", "-lc", command]
