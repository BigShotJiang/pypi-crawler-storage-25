"""Plugin registry -- decouverte, installation, activation et gestion des plugins."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

# -- Constantes --

EXTERNAL_MARKETPLACE = "external"
BUILTIN_MARKETPLACE = "builtin"
BUNDLED_MARKETPLACE = "bundled"
SETTINGS_FILE_NAME = "settings.json"
REGISTRY_FILE_NAME = "installed.json"
MANIFEST_FILE_NAME = "plugin.json"
MANIFEST_RELATIVE_PATH = ".claude-plugin/plugin.json"


# -- Enums --


class PluginKind(str, Enum):
    BUILTIN = "builtin"
    BUNDLED = "bundled"
    EXTERNAL = "external"

    def marketplace(self) -> str:
        return {
            PluginKind.BUILTIN: BUILTIN_MARKETPLACE,
            PluginKind.BUNDLED: BUNDLED_MARKETPLACE,
            PluginKind.EXTERNAL: EXTERNAL_MARKETPLACE,
        }[self]


class PluginPermission(str, Enum):
    READ = "read"
    WRITE = "write"
    EXECUTE = "execute"

    @classmethod
    def parse(cls, value: str) -> PluginPermission | None:
        try:
            return cls(value)
        except ValueError:
            return None


class PluginToolPermission(str, Enum):
    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"
    DANGER_FULL_ACCESS = "danger-full-access"

    @classmethod
    def parse(cls, value: str) -> PluginToolPermission | None:
        try:
            return cls(value)
        except ValueError:
            return None


# -- Dataclasses --


@dataclass
class PluginMetadata:
    id: str
    name: str
    version: str
    description: str
    kind: PluginKind
    source: str
    default_enabled: bool = False
    root: Path | None = None


@dataclass
class PluginHooks:
    """Commandes de hooks pre/post tool use."""

    pre_tool_use: list[str] = field(default_factory=list)
    post_tool_use: list[str] = field(default_factory=list)
    post_tool_use_failure: list[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return not self.pre_tool_use and not self.post_tool_use and not self.post_tool_use_failure

    def merged_with(self, other: PluginHooks) -> PluginHooks:
        return PluginHooks(
            pre_tool_use=[*self.pre_tool_use, *other.pre_tool_use],
            post_tool_use=[*self.post_tool_use, *other.post_tool_use],
            post_tool_use_failure=[*self.post_tool_use_failure, *other.post_tool_use_failure],
        )


@dataclass
class PluginLifecycle:
    init: list[str] = field(default_factory=list)
    shutdown: list[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return not self.init and not self.shutdown


@dataclass
class PluginToolDefinition:
    name: str
    description: str | None = None
    input_schema: Any = field(default_factory=dict)


@dataclass
class PluginToolManifest:
    name: str
    description: str
    input_schema: Any
    command: str
    args: list[str] = field(default_factory=list)
    required_permission: PluginToolPermission = PluginToolPermission.DANGER_FULL_ACCESS


@dataclass
class PluginCommandManifest:
    name: str
    description: str
    command: str


@dataclass
class PluginManifest:
    name: str
    version: str
    description: str
    permissions: list[PluginPermission] = field(default_factory=list)
    default_enabled: bool = False
    hooks: PluginHooks = field(default_factory=PluginHooks)
    lifecycle: PluginLifecycle = field(default_factory=PluginLifecycle)
    tools: list[PluginToolManifest] = field(default_factory=list)
    commands: list[PluginCommandManifest] = field(default_factory=list)


# -- Erreurs --


class PluginManifestValidationError(Exception):
    """Erreur de validation du manifeste plugin."""


class PluginError(Exception):
    """Erreur generique du systeme de plugins."""


# -- Plugin Tool --


@dataclass
class PluginTool:
    """Outil de plugin executable via une commande externe."""

    plugin_id: str
    plugin_name: str
    definition: PluginToolDefinition
    command: str
    args: list[str] = field(default_factory=list)
    required_permission: PluginToolPermission = PluginToolPermission.DANGER_FULL_ACCESS
    root: Path | None = None

    def execute(self, input_data: dict[str, Any]) -> str:
        """Execute l'outil de plugin avec le JSON d'entree."""
        input_json = json.dumps(input_data, ensure_ascii=False)
        cmd = [self.command, *self.args]
        env = dict(os.environ)
        env["CLAWD_PLUGIN_ID"] = self.plugin_id
        env["CLAWD_PLUGIN_NAME"] = self.plugin_name
        env["CLAWD_TOOL_NAME"] = self.definition.name
        env["CLAWD_TOOL_INPUT"] = input_json
        if self.root:
            env["CLAWD_PLUGIN_ROOT"] = str(self.root)

        try:
            result = subprocess.run(
                cmd,
                input=input_json,
                capture_output=True,
                text=True,
                env=env,
                cwd=str(self.root) if self.root else None,
                timeout=60,
            )
        except FileNotFoundError as exc:
            raise PluginError(
                f"plugin tool `{self.definition.name}` from `{self.plugin_id}` "
                f"command not found: {self.command}"
            ) from exc

        if result.returncode == 0:
            return result.stdout.strip()
        stderr = result.stderr.strip()
        raise PluginError(
            f"plugin tool `{self.definition.name}` from `{self.plugin_id}` "
            f"failed for `{self.command}`: "
            f"{stderr if stderr else f'exit status {result.returncode}'}"
        )


# -- Source d'installation --


@dataclass
class PluginInstallSource:
    type: str  # "local_path" ou "git_url"
    path: Path | None = None
    url: str | None = None


@dataclass
class InstalledPluginRecord:
    kind: PluginKind
    id: str
    name: str
    version: str
    description: str
    install_path: Path
    source: PluginInstallSource
    installed_at_unix_ms: int = 0
    updated_at_unix_ms: int = 0


@dataclass
class InstalledPluginRegistry:
    plugins: dict[str, InstalledPluginRecord] = field(default_factory=dict)


# -- Plugin types concrets --


class Plugin(ABC):
    """Interface de plugin."""

    @abstractmethod
    def metadata(self) -> PluginMetadata: ...

    @abstractmethod
    def hooks(self) -> PluginHooks: ...

    @abstractmethod
    def lifecycle(self) -> PluginLifecycle: ...

    @abstractmethod
    def tools(self) -> list[PluginTool]: ...

    @abstractmethod
    def validate(self) -> None: ...

    @abstractmethod
    def initialize(self) -> None: ...

    @abstractmethod
    def shutdown(self) -> None: ...


@dataclass
class BuiltinPlugin:
    _metadata: PluginMetadata
    _hooks: PluginHooks = field(default_factory=PluginHooks)
    _lifecycle: PluginLifecycle = field(default_factory=PluginLifecycle)
    _tools: list[PluginTool] = field(default_factory=list)

    def metadata(self) -> PluginMetadata:
        return self._metadata

    def hooks(self) -> PluginHooks:
        return self._hooks

    def lifecycle(self) -> PluginLifecycle:
        return self._lifecycle

    def tools(self) -> list[PluginTool]:
        return self._tools

    def validate(self) -> None:
        pass

    def initialize(self) -> None:
        pass

    def shutdown(self) -> None:
        pass


@dataclass
class BundledPlugin:
    _metadata: PluginMetadata
    _hooks: PluginHooks = field(default_factory=PluginHooks)
    _lifecycle: PluginLifecycle = field(default_factory=PluginLifecycle)
    _tools: list[PluginTool] = field(default_factory=list)

    def metadata(self) -> PluginMetadata:
        return self._metadata

    def hooks(self) -> PluginHooks:
        return self._hooks

    def lifecycle(self) -> PluginLifecycle:
        return self._lifecycle

    def tools(self) -> list[PluginTool]:
        return self._tools

    def validate(self) -> None:
        _validate_hook_paths(self._metadata.root, self._hooks)
        _validate_lifecycle_paths(self._metadata.root, self._lifecycle)
        _validate_tool_paths(self._metadata.root, self._tools)

    def initialize(self) -> None:
        _run_lifecycle_commands(self._metadata, "init", self._lifecycle.init)

    def shutdown(self) -> None:
        _run_lifecycle_commands(self._metadata, "shutdown", self._lifecycle.shutdown)


@dataclass
class ExternalPlugin:
    _metadata: PluginMetadata
    _hooks: PluginHooks = field(default_factory=PluginHooks)
    _lifecycle: PluginLifecycle = field(default_factory=PluginLifecycle)
    _tools: list[PluginTool] = field(default_factory=list)

    def metadata(self) -> PluginMetadata:
        return self._metadata

    def hooks(self) -> PluginHooks:
        return self._hooks

    def lifecycle(self) -> PluginLifecycle:
        return self._lifecycle

    def tools(self) -> list[PluginTool]:
        return self._tools

    def validate(self) -> None:
        _validate_hook_paths(self._metadata.root, self._hooks)
        _validate_lifecycle_paths(self._metadata.root, self._lifecycle)
        _validate_tool_paths(self._metadata.root, self._tools)

    def initialize(self) -> None:
        _run_lifecycle_commands(self._metadata, "init", self._lifecycle.init)

    def shutdown(self) -> None:
        _run_lifecycle_commands(self._metadata, "shutdown", self._lifecycle.shutdown)


@dataclass
class PluginDefinition:
    """Enveloppe polymorphe pour un plugin (builtin, bundled ou external)."""

    _inner: BuiltinPlugin | BundledPlugin | ExternalPlugin

    def metadata(self) -> PluginMetadata:
        return self._inner.metadata()

    def hooks(self) -> PluginHooks:
        return self._inner.hooks()

    def lifecycle(self) -> PluginLifecycle:
        return self._inner.lifecycle()

    def tools(self) -> list[PluginTool]:
        return self._inner.tools()

    def validate(self) -> None:
        self._inner.validate()

    def initialize(self) -> None:
        self._inner.initialize()

    def shutdown(self) -> None:
        self._inner.shutdown()


# -- Registered Plugin --


@dataclass
class RegisteredPlugin:
    definition: PluginDefinition
    enabled: bool = True

    def metadata(self) -> PluginMetadata:
        return self.definition.metadata()

    def hooks(self) -> PluginHooks:
        return self.definition.hooks()

    def tools(self) -> list[PluginTool]:
        return self.definition.tools()

    @property
    def is_enabled(self) -> bool:
        return self.enabled

    def validate(self) -> None:
        self.definition.validate()

    def initialize(self) -> None:
        self.definition.initialize()

    def shutdown(self) -> None:
        self.definition.shutdown()

    def summary(self) -> PluginSummary:
        return PluginSummary(metadata=self.metadata(), enabled=self.enabled)


@dataclass
class PluginSummary:
    metadata: PluginMetadata
    enabled: bool


@dataclass
class PluginLoadFailure:
    plugin_root: Path
    kind: PluginKind
    source: str
    error: PluginError

    def __str__(self) -> str:
        return (
            f"failed to load {self.kind.value} plugin from `{self.plugin_root}` "
            f"(source: {self.source}): {self.error}"
        )


@dataclass
class PluginRegistryReport:
    registry: PluginRegistry
    failures: list[PluginLoadFailure] = field(default_factory=list)

    @property
    def has_failures(self) -> bool:
        return bool(self.failures)

    def summaries(self) -> list[PluginSummary]:
        return self.registry.summaries()

    def into_registry(self) -> PluginRegistry:
        if self.failures:
            messages = [str(f) for f in self.failures]
            raise PluginError("; ".join(messages))
        return self.registry


# -- Plugin Registry --


class PluginRegistry:
    """Registre de plugins -- agregation des hooks, outils et lifecycle."""

    def __init__(self, plugins: list[RegisteredPlugin] | None = None) -> None:
        self._plugins = sorted(plugins or [], key=lambda p: p.metadata().id)

    @property
    def plugins(self) -> list[RegisteredPlugin]:
        return self._plugins

    def get(self, plugin_id: str) -> RegisteredPlugin | None:
        return next((p for p in self._plugins if p.metadata().id == plugin_id), None)

    def contains(self, plugin_id: str) -> bool:
        return self.get(plugin_id) is not None

    def summaries(self) -> list[PluginSummary]:
        return [p.summary() for p in self._plugins]

    def aggregated_hooks(self) -> PluginHooks:
        """Agrege les hooks de tous les plugins actives."""
        result = PluginHooks()
        for plugin in self._plugins:
            if plugin.is_enabled:
                plugin.validate()
                result = result.merged_with(plugin.hooks())
        return result

    def aggregated_tools(self) -> list[PluginTool]:
        """Agrege les outils de tous les plugins actives (verifie les noms uniques)."""
        tools: list[PluginTool] = []
        seen_names: dict[str, str] = {}
        for plugin in self._plugins:
            if not plugin.is_enabled:
                continue
            plugin.validate()
            for tool in plugin.tools():
                if tool.definition.name in seen_names:
                    existing = seen_names[tool.definition.name]
                    raise PluginError(
                        f"plugin tool `{tool.definition.name}` is defined by both "
                        f"`{existing}` and `{tool.plugin_id}`"
                    )
                seen_names[tool.definition.name] = tool.plugin_id
                tools.append(tool)
        return tools

    def initialize(self) -> None:
        for plugin in self._plugins:
            if plugin.is_enabled:
                plugin.validate()
                plugin.initialize()

    def shutdown(self) -> None:
        for plugin in reversed(self._plugins):
            if plugin.is_enabled:
                plugin.shutdown()


# -- Plugin Manager Config --


@dataclass
class PluginManagerConfig:
    config_home: Path
    enabled_plugins: dict[str, bool] = field(default_factory=dict)
    external_dirs: list[Path] = field(default_factory=list)
    install_root: Path | None = None
    registry_path: Path | None = None
    bundled_root: Path | None = None


@dataclass
class InstallOutcome:
    plugin_id: str
    version: str
    install_path: Path


@dataclass
class UpdateOutcome:
    plugin_id: str
    old_version: str
    new_version: str
    install_path: Path


# -- Plugin Manager --


class PluginManager:
    """Gestionnaire de plugins -- installation, mise a jour, activation, suppression."""

    def __init__(self, config: PluginManagerConfig) -> None:
        self._config = config

    @staticmethod
    def bundled_root() -> Path:
        return Path(__file__).parent / "bundled"

    @property
    def install_root(self) -> Path:
        return self._config.install_root or (self._config.config_home / "plugins" / "installed")

    @property
    def registry_path(self) -> Path:
        return self._config.registry_path or (self._config.config_home / "plugins" / REGISTRY_FILE_NAME)

    @property
    def settings_path(self) -> Path:
        return self._config.config_home / SETTINGS_FILE_NAME

    def plugin_registry(self) -> PluginRegistry:
        report = self.plugin_registry_report()
        return report.into_registry()

    def plugin_registry_report(self) -> PluginRegistryReport:
        """Construit le registre complet incluant builtin, bundled et external."""
        self._sync_bundled_plugins()

        plugins: list[PluginDefinition] = []
        failures: list[PluginLoadFailure] = []

        # Plugins builtin
        plugins.extend(_builtin_plugins())

        # Plugins installes
        installed_discovery = self._discover_installed_plugins()
        plugins.extend(installed_discovery[0])
        failures.extend(installed_discovery[1])

        # Plugins de repertoires externes
        external_discovery = self._discover_external_directory_plugins(plugins)
        plugins.extend(external_discovery[0])
        failures.extend(external_discovery[1])

        return self._build_registry_report(plugins, failures)

    def list_plugins(self) -> list[PluginSummary]:
        return self.plugin_registry().summaries()

    def install(self, source: str) -> InstallOutcome:
        """Installe un plugin depuis un chemin local ou une URL git."""
        install_source = _parse_install_source(source)
        temp_root = self.install_root / ".tmp"
        staged_source = _materialize_source(install_source, temp_root)
        cleanup_source = install_source.type == "git_url"
        manifest = _load_plugin_from_directory(staged_source)

        pid = _plugin_id(manifest.name, EXTERNAL_MARKETPLACE)
        install_path = self.install_root / _sanitize_plugin_id(pid)
        if install_path.exists():
            shutil.rmtree(install_path)
        shutil.copytree(str(staged_source), str(install_path))
        if cleanup_source and staged_source.exists():
            shutil.rmtree(staged_source)

        now = _unix_time_ms()
        record = InstalledPluginRecord(
            kind=PluginKind.EXTERNAL,
            id=pid,
            name=manifest.name,
            version=manifest.version,
            description=manifest.description,
            install_path=install_path,
            source=install_source,
            installed_at_unix_ms=now,
            updated_at_unix_ms=now,
        )

        registry = self._load_registry()
        registry.plugins[pid] = record
        self._store_registry(registry)
        self._write_enabled_state(pid, True)
        self._config.enabled_plugins[pid] = True

        return InstallOutcome(plugin_id=pid, version=manifest.version, install_path=install_path)

    def enable(self, plugin_id: str) -> None:
        self._ensure_known_plugin(plugin_id)
        self._write_enabled_state(plugin_id, True)
        self._config.enabled_plugins[plugin_id] = True

    def disable(self, plugin_id: str) -> None:
        self._ensure_known_plugin(plugin_id)
        self._write_enabled_state(plugin_id, False)
        self._config.enabled_plugins[plugin_id] = False

    def uninstall(self, plugin_id: str) -> None:
        registry = self._load_registry()
        record = registry.plugins.pop(plugin_id, None)
        if record is None:
            raise PluginError(f"plugin `{plugin_id}` is not installed")
        if record.kind == PluginKind.BUNDLED:
            registry.plugins[plugin_id] = record
            raise PluginError(
                f"plugin `{plugin_id}` is bundled and managed automatically; disable it instead"
            )
        if record.install_path.exists():
            shutil.rmtree(record.install_path)
        self._store_registry(registry)
        self._write_enabled_state(plugin_id, None)
        self._config.enabled_plugins.pop(plugin_id, None)

    def update(self, plugin_id: str) -> UpdateOutcome:
        registry = self._load_registry()
        record = registry.plugins.get(plugin_id)
        if record is None:
            raise PluginError(f"plugin `{plugin_id}` is not installed")

        temp_root = self.install_root / ".tmp"
        staged_source = _materialize_source(record.source, temp_root)
        cleanup_source = record.source.type == "git_url"
        manifest = _load_plugin_from_directory(staged_source)

        if record.install_path.exists():
            shutil.rmtree(record.install_path)
        shutil.copytree(str(staged_source), str(record.install_path))
        if cleanup_source and staged_source.exists():
            shutil.rmtree(staged_source)

        old_version = record.version
        record.version = manifest.version
        record.description = manifest.description
        record.updated_at_unix_ms = _unix_time_ms()
        registry.plugins[plugin_id] = record
        self._store_registry(registry)

        return UpdateOutcome(
            plugin_id=plugin_id,
            old_version=old_version,
            new_version=manifest.version,
            install_path=record.install_path,
        )

    # -- Methodes privees --

    def _load_registry(self) -> InstalledPluginRegistry:
        if not self.registry_path.exists():
            return InstalledPluginRegistry()
        try:
            data = json.loads(self.registry_path.read_text(encoding="utf-8"))
            plugins = {}
            for pid, entry in data.get("plugins", {}).items():
                source_data = entry.get("source", {})
                source = PluginInstallSource(
                    type=source_data.get("type", "local_path"),
                    path=Path(source_data["path"]) if "path" in source_data else None,
                    url=source_data.get("url"),
                )
                plugins[pid] = InstalledPluginRecord(
                    kind=PluginKind(entry.get("kind", "external")),
                    id=entry["id"],
                    name=entry["name"],
                    version=entry["version"],
                    description=entry.get("description", ""),
                    install_path=Path(entry["install_path"]),
                    source=source,
                    installed_at_unix_ms=entry.get("installed_at_unix_ms", 0),
                    updated_at_unix_ms=entry.get("updated_at_unix_ms", 0),
                )
            return InstalledPluginRegistry(plugins=plugins)
        except (json.JSONDecodeError, KeyError):
            return InstalledPluginRegistry()

    def _store_registry(self, registry: InstalledPluginRegistry) -> None:
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        data = {"plugins": {}}
        for pid, record in registry.plugins.items():
            source_dict: dict[str, Any] = {"type": record.source.type}
            if record.source.path:
                source_dict["path"] = str(record.source.path)
            if record.source.url:
                source_dict["url"] = record.source.url
            data["plugins"][pid] = {
                "kind": record.kind.value,
                "id": record.id,
                "name": record.name,
                "version": record.version,
                "description": record.description,
                "install_path": str(record.install_path),
                "source": source_dict,
                "installed_at_unix_ms": record.installed_at_unix_ms,
                "updated_at_unix_ms": record.updated_at_unix_ms,
            }
        self.registry_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def _write_enabled_state(self, plugin_id: str, enabled: bool | None) -> None:
        """Met a jour l'etat active/desactive dans settings.json."""
        settings: dict[str, Any] = {}
        if self.settings_path.exists():
            try:
                settings = json.loads(self.settings_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                settings = {}
        enabled_plugins = settings.setdefault("enabledPlugins", {})
        if enabled is None:
            enabled_plugins.pop(plugin_id, None)
        else:
            enabled_plugins[plugin_id] = enabled
        self.settings_path.parent.mkdir(parents=True, exist_ok=True)
        self.settings_path.write_text(json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8")

    def _ensure_known_plugin(self, plugin_id: str) -> None:
        registry = self._load_registry()
        if plugin_id not in registry.plugins:
            raise PluginError(f"plugin `{plugin_id}` is not installed")

    def _sync_bundled_plugins(self) -> None:
        """Synchronise les plugins bundled depuis la source vers le repertoire d'installation."""
        bundled_root = self._config.bundled_root or self.bundled_root()
        if not bundled_root.exists():
            return

        registry = self._load_registry()
        changed = False

        for source_root in _discover_plugin_dirs(bundled_root):
            try:
                manifest = _load_plugin_from_directory(source_root)
            except PluginError:
                continue
            pid = _plugin_id(manifest.name, BUNDLED_MARKETPLACE)
            install_path = self.install_root / _sanitize_plugin_id(pid)
            now = _unix_time_ms()

            existing = registry.plugins.get(pid)
            needs_sync = existing is None or (
                existing.kind != PluginKind.BUNDLED
                or existing.version != manifest.version
                or existing.name != manifest.name
                or not existing.install_path.exists()
            )

            if not needs_sync:
                continue

            if install_path.exists():
                shutil.rmtree(install_path)
            shutil.copytree(str(source_root), str(install_path))

            installed_at = existing.installed_at_unix_ms if existing else now
            registry.plugins[pid] = InstalledPluginRecord(
                kind=PluginKind.BUNDLED,
                id=pid,
                name=manifest.name,
                version=manifest.version,
                description=manifest.description,
                install_path=install_path,
                source=PluginInstallSource(type="local_path", path=source_root),
                installed_at_unix_ms=installed_at,
                updated_at_unix_ms=now,
            )
            changed = True

        if changed:
            self._store_registry(registry)

    def _discover_installed_plugins(
        self,
    ) -> tuple[list[PluginDefinition], list[PluginLoadFailure]]:
        plugins: list[PluginDefinition] = []
        failures: list[PluginLoadFailure] = []
        seen_ids: set[str] = set()

        for install_path in _discover_plugin_dirs(self.install_root):
            source = str(install_path)
            try:
                plugin = _load_plugin_definition(install_path, PluginKind.EXTERNAL, source, EXTERNAL_MARKETPLACE)
                if plugin.metadata().id not in seen_ids:
                    seen_ids.add(plugin.metadata().id)
                    plugins.append(plugin)
            except PluginError as e:
                failures.append(PluginLoadFailure(install_path, PluginKind.EXTERNAL, source, e))

        return plugins, failures

    def _discover_external_directory_plugins(
        self, existing: list[PluginDefinition]
    ) -> tuple[list[PluginDefinition], list[PluginLoadFailure]]:
        plugins: list[PluginDefinition] = []
        failures: list[PluginLoadFailure] = []
        existing_ids = {p.metadata().id for p in existing}

        for directory in self._config.external_dirs:
            for root in _discover_plugin_dirs(directory):
                source = str(root)
                try:
                    plugin = _load_plugin_definition(root, PluginKind.EXTERNAL, source, EXTERNAL_MARKETPLACE)
                    pid = plugin.metadata().id
                    if pid not in existing_ids and pid not in {p.metadata().id for p in plugins}:
                        plugins.append(plugin)
                except PluginError as e:
                    failures.append(PluginLoadFailure(root, PluginKind.EXTERNAL, source, e))

        return plugins, failures

    def _build_registry_report(
        self, plugins: list[PluginDefinition], failures: list[PluginLoadFailure]
    ) -> PluginRegistryReport:
        registered: list[RegisteredPlugin] = []
        for plugin in plugins:
            pid = plugin.metadata().id
            enabled = self._config.enabled_plugins.get(pid, plugin.metadata().default_enabled)
            registered.append(RegisteredPlugin(definition=plugin, enabled=enabled))
        return PluginRegistryReport(
            registry=PluginRegistry(registered),
            failures=failures,
        )


# -- Helpers --


def _unix_time_ms() -> int:
    return int(time.time() * 1000)


def _plugin_id(name: str, marketplace: str) -> str:
    return f"{name}@{marketplace}"


def _sanitize_plugin_id(plugin_id: str) -> str:
    return plugin_id.replace("/", "__").replace("@", "_at_")


def _builtin_plugins() -> list[PluginDefinition]:
    """Retourne les plugins builtin (vide pour l'instant)."""
    return []


def _discover_plugin_dirs(root: Path) -> list[Path]:
    """Decouvre les repertoires contenant un manifeste plugin."""
    if not root.exists():
        return []
    dirs: list[Path] = []
    for entry in sorted(root.iterdir()):
        if entry.is_dir():
            manifest_path = entry / ".claude-plugin" / MANIFEST_FILE_NAME
            if manifest_path.is_file():
                dirs.append(entry)
    return dirs


def _load_plugin_from_directory(plugin_root: Path) -> PluginManifest:
    """Charge un manifeste plugin depuis un repertoire."""
    manifest_path = plugin_root / ".claude-plugin" / MANIFEST_FILE_NAME
    if not manifest_path.is_file():
        raise PluginError(f"plugin manifest not found: {manifest_path}")

    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise PluginError(f"invalid plugin manifest JSON: {e}") from e

    permissions = []
    for p in data.get("permissions", []):
        parsed = PluginPermission.parse(p)
        if parsed:
            permissions.append(parsed)

    hooks_data = data.get("hooks", {})
    hooks = PluginHooks(
        pre_tool_use=hooks_data.get("PreToolUse", []),
        post_tool_use=hooks_data.get("PostToolUse", []),
        post_tool_use_failure=hooks_data.get("PostToolUseFailure", []),
    )

    lifecycle_data = data.get("lifecycle", {})
    lifecycle = PluginLifecycle(
        init=lifecycle_data.get("Init", []),
        shutdown=lifecycle_data.get("Shutdown", []),
    )

    tools = []
    for t in data.get("tools", []):
        perm = PluginToolPermission.parse(t.get("requiredPermission", "danger-full-access"))
        tools.append(PluginToolManifest(
            name=t["name"],
            description=t.get("description", ""),
            input_schema=t.get("inputSchema", {}),
            command=t["command"],
            args=t.get("args", []),
            required_permission=perm or PluginToolPermission.DANGER_FULL_ACCESS,
        ))

    commands = []
    for c in data.get("commands", []):
        commands.append(PluginCommandManifest(
            name=c["name"],
            description=c.get("description", ""),
            command=c["command"],
        ))

    return PluginManifest(
        name=data["name"],
        version=data["version"],
        description=data.get("description", ""),
        permissions=permissions,
        default_enabled=data.get("defaultEnabled", False),
        hooks=hooks,
        lifecycle=lifecycle,
        tools=tools,
        commands=commands,
    )


def _load_plugin_definition(
    plugin_root: Path,
    kind: PluginKind,
    source: str,
    marketplace: str,
) -> PluginDefinition:
    """Charge un plugin complet depuis un repertoire."""
    manifest = _load_plugin_from_directory(plugin_root)
    pid = _plugin_id(manifest.name, marketplace)
    metadata = PluginMetadata(
        id=pid,
        name=manifest.name,
        version=manifest.version,
        description=manifest.description,
        kind=kind,
        source=source,
        default_enabled=manifest.default_enabled,
        root=plugin_root,
    )

    plugin_tools = []
    for t in manifest.tools:
        plugin_tools.append(PluginTool(
            plugin_id=pid,
            plugin_name=manifest.name,
            definition=PluginToolDefinition(
                name=t.name,
                description=t.description,
                input_schema=t.input_schema,
            ),
            command=t.command,
            args=t.args,
            required_permission=t.required_permission,
            root=plugin_root,
        ))

    if kind == PluginKind.BUILTIN:
        inner = BuiltinPlugin(_metadata=metadata, _hooks=manifest.hooks, _lifecycle=manifest.lifecycle, _tools=plugin_tools)
    elif kind == PluginKind.BUNDLED:
        inner = BundledPlugin(_metadata=metadata, _hooks=manifest.hooks, _lifecycle=manifest.lifecycle, _tools=plugin_tools)
    else:
        inner = ExternalPlugin(_metadata=metadata, _hooks=manifest.hooks, _lifecycle=manifest.lifecycle, _tools=plugin_tools)

    return PluginDefinition(_inner=inner)


def _validate_hook_paths(root: Path | None, hooks: PluginHooks) -> None:
    if root is None:
        return
    for cmd_list in [hooks.pre_tool_use, hooks.post_tool_use, hooks.post_tool_use_failure]:
        for cmd in cmd_list:
            if cmd.startswith("./") or cmd.startswith("../"):
                path = root / cmd
                if not path.exists():
                    raise PluginError(f"hook path `{path}` does not exist")


def _validate_lifecycle_paths(root: Path | None, lifecycle: PluginLifecycle) -> None:
    if root is None:
        return
    for cmd_list in [lifecycle.init, lifecycle.shutdown]:
        for cmd in cmd_list:
            if cmd.startswith("./") or cmd.startswith("../"):
                path = root / cmd
                if not path.exists():
                    raise PluginError(f"lifecycle path `{path}` does not exist")


def _validate_tool_paths(root: Path | None, tools: list[PluginTool]) -> None:
    if root is None:
        return
    for tool in tools:
        cmd = tool.command
        if cmd.startswith("./") or cmd.startswith("../"):
            path = root / cmd
            if not path.exists():
                raise PluginError(f"tool command path `{path}` does not exist")


def _run_lifecycle_commands(metadata: PluginMetadata, phase: str, commands: list[str]) -> None:
    for cmd in commands:
        try:
            subprocess.run(
                ["sh", "-c", cmd] if not Path(cmd).exists() else ["sh", cmd],
                capture_output=True,
                text=True,
                cwd=str(metadata.root) if metadata.root else None,
                timeout=30,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError) as e:
            raise PluginError(
                f"plugin `{metadata.id}` {phase} command `{cmd}` failed: {e}"
            ) from e


def _parse_install_source(source: str) -> PluginInstallSource:
    if source.startswith("http://") or source.startswith("https://") or source.endswith(".git"):
        return PluginInstallSource(type="git_url", url=source)
    return PluginInstallSource(type="local_path", path=Path(source).resolve())


def _resolve_local_source(source: str) -> Path:
    path = Path(source).resolve()
    if not path.exists():
        raise PluginError(f"plugin source path does not exist: {path}")
    return path


def _materialize_source(source: PluginInstallSource, temp_root: Path) -> Path:
    """Materialise la source (copie locale ou clone git) dans un repertoire temporaire."""
    if source.type == "local_path" and source.path:
        return source.path
    if source.type == "git_url" and source.url:
        temp_root.mkdir(parents=True, exist_ok=True)
        clone_dir = temp_root / f"clone_{_unix_time_ms()}"
        try:
            subprocess.run(
                ["git", "clone", "--depth=1", source.url, str(clone_dir)],
                capture_output=True,
                text=True,
                check=True,
                timeout=120,
            )
        except subprocess.CalledProcessError as e:
            raise PluginError(f"git clone failed: {e.stderr}") from e
        return clone_dir
    raise PluginError("invalid install source")
