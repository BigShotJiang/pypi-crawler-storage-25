"""Configuration Maestro — chargement depuis ~/.maestro/config.yaml + env vars.

Gère la configuration par défaut du provider, modèle, mode trust,
et les clés API des différents providers."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml


_CONFIG_DIR = Path.home() / ".maestro"
_CONFIG_FILE = _CONFIG_DIR / "config.yaml"

# Template de configuration par défaut
_DEFAULT_CONFIG = {
    "default_provider": "anthropic",
    "default_model": "claude-sonnet-4-20250514",
    "trust_mode": "standard",
    "providers": {
        "anthropic": {
            "api_key_env": "ANTHROPIC_API_KEY",
        },
        "openai": {
            "api_key_env": "OPENAI_API_KEY",
        },
        "gemini": {
            "api_key_env": "GOOGLE_API_KEY",
        },
        "ollama": {
            "base_url": "http://localhost:11434",
        },
    },
}


@dataclass
class ProviderConfig:
    """Configuration d'un provider individuel."""

    name: str
    api_key_env: Optional[str] = None
    base_url: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)

    def resolve_api_key(self) -> Optional[str]:
        """Résout la clé API depuis la variable d'environnement configurée."""
        if self.api_key_env:
            value = os.environ.get(self.api_key_env, "")
            return value if value else None
        return None


@dataclass
class MaestroConfig:
    """Configuration globale de Maestro."""

    default_provider: str = "anthropic"
    default_model: str = "claude-sonnet-4-20250514"
    trust_mode: str = "standard"
    providers: dict[str, ProviderConfig] = field(default_factory=dict)

    @classmethod
    def load(cls) -> MaestroConfig:
        """Charge la config depuis ~/.maestro/config.yaml, avec fallback sur les défauts."""
        raw = dict(_DEFAULT_CONFIG)

        if _CONFIG_FILE.exists():
            try:
                with open(_CONFIG_FILE, "r", encoding="utf-8") as f:
                    user_config = yaml.safe_load(f) or {}
                # Merger : les valeurs utilisateur écrasent les défauts
                _deep_merge(raw, user_config)
            except (yaml.YAMLError, OSError):
                # Config invalide ou illisible — on utilise les défauts
                pass

        # Override par variables d'environnement
        env_provider = os.environ.get("MAESTRO_PROVIDER")
        if env_provider:
            raw["default_provider"] = env_provider

        env_model = os.environ.get("MAESTRO_MODEL")
        if env_model:
            raw["default_model"] = env_model

        env_trust = os.environ.get("MAESTRO_TRUST_MODE")
        if env_trust:
            raw["trust_mode"] = env_trust

        # Construire les ProviderConfig
        providers: dict[str, ProviderConfig] = {}
        for name, conf in raw.get("providers", {}).items():
            if isinstance(conf, dict):
                providers[name] = ProviderConfig(
                    name=name,
                    api_key_env=conf.get("api_key_env"),
                    base_url=conf.get("base_url"),
                    extra={k: v for k, v in conf.items() if k not in ("api_key_env", "base_url")},
                )
            else:
                providers[name] = ProviderConfig(name=name)

        return cls(
            default_provider=raw.get("default_provider", "anthropic"),
            default_model=raw.get("default_model", "claude-sonnet-4-20250514"),
            trust_mode=raw.get("trust_mode", "standard"),
            providers=providers,
        )

    def save(self) -> None:
        """Sauvegarde la config dans ~/.maestro/config.yaml."""
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        data: dict[str, Any] = {
            "default_provider": self.default_provider,
            "default_model": self.default_model,
            "trust_mode": self.trust_mode,
            "providers": {},
        }
        for name, pc in self.providers.items():
            entry: dict[str, Any] = {}
            if pc.api_key_env:
                entry["api_key_env"] = pc.api_key_env
            if pc.base_url:
                entry["base_url"] = pc.base_url
            entry.update(pc.extra)
            data["providers"][name] = entry

        with open(_CONFIG_FILE, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, allow_unicode=True)

    def get_provider_config(self, name: str) -> Optional[ProviderConfig]:
        """Retourne la config d'un provider par nom."""
        return self.providers.get(name)

    def ensure_config_dir(self) -> Path:
        """Crée le répertoire de config si nécessaire et retourne son chemin."""
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        return _CONFIG_DIR

    def write_default_config(self) -> Path:
        """Écrit le fichier de config par défaut si aucun n'existe."""
        if not _CONFIG_FILE.exists():
            self.ensure_config_dir()
            with open(_CONFIG_FILE, "w", encoding="utf-8") as f:
                yaml.dump(_DEFAULT_CONFIG, f, default_flow_style=False, allow_unicode=True)
        return _CONFIG_FILE


def _deep_merge(base: dict, override: dict) -> None:
    """Merge récursif : override écrase base, en profondeur."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
