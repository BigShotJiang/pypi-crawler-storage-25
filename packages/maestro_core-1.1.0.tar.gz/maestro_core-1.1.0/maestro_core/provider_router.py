"""Provider Router — orchestre le choix de provider + trust layer.

Logique centrale de Maestro :
1. L'utilisateur envoie un message
2. Le trust layer anonymise si nécessaire
3. Le router choisit le provider (cloud vs local)
4. Le message est envoyé au LLM
5. La réponse est dé-anonymisée
6. L'utilisateur reçoit la réponse avec les vraies données"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

from maestro_core.api.providers.anthropic import AnthropicClient
from maestro_core.api.providers.gemini import GeminiClient
from maestro_core.api.providers.ollama import OllamaClient
from maestro_core.api.providers.openai_compat import OpenAiCompatClient
from maestro_core.api.types import MessageRequest, MessageResponse, StreamEvent
from maestro_core.config import MaestroConfig
from maestro_core.trust.anonymizer import Anonymizer, TrustMode


class RoutingMode(str, Enum):
    """Mode de routage des requêtes."""

    AUTO = "auto"        # Détection automatique de sensibilité
    LOCAL = "local"      # Tout en local (Ollama)
    CLOUD = "cloud"      # Tout en cloud (provider configuré)
    HYBRID = "hybrid"    # Switch mid-conversation si données sensibles


@dataclass
class RouteDecision:
    """Résultat du routage — quel provider utiliser."""

    provider_name: str
    model: str
    reason: str
    anonymized: bool


class ProviderRouter:
    """Orchestre le choix de provider et l'anonymisation."""

    def __init__(
        self,
        config: MaestroConfig,
        routing_mode: RoutingMode = RoutingMode.AUTO,
        trust_mode: Optional[TrustMode] = None,
    ) -> None:
        self._config = config
        self._routing_mode = routing_mode
        self._trust_mode = trust_mode or TrustMode(config.trust.default_mode)
        self._anonymizer = Anonymizer(self._trust_mode)

        # Clients initialisés à la demande
        self._clients: dict[str, Any] = {}

    @property
    def anonymizer(self) -> Anonymizer:
        return self._anonymizer

    @property
    def trust_mode(self) -> TrustMode:
        return self._trust_mode

    @property
    def routing_mode(self) -> RoutingMode:
        return self._routing_mode

    def set_trust_mode(self, mode: TrustMode) -> None:
        """Change le trust mode en cours de session."""
        self._trust_mode = mode
        self._anonymizer = Anonymizer(mode)

    def set_routing_mode(self, mode: RoutingMode) -> None:
        """Change le routing mode."""
        self._routing_mode = mode

    def route(self, text: str) -> RouteDecision:
        """Décide quel provider utiliser pour un texte donné."""
        if self._routing_mode == RoutingMode.LOCAL:
            return RouteDecision(
                provider_name="ollama",
                model=self._config.get_provider_config("ollama").default_model,
                reason="mode local forcé",
                anonymized=False,
            )

        if self._routing_mode == RoutingMode.CLOUD:
            provider = self._config.default_provider
            return RouteDecision(
                provider_name=provider,
                model=self._config.resolve_model(provider=provider),
                reason="mode cloud forcé",
                anonymized=self._trust_mode != TrustMode.OFF,
            )

        # Mode AUTO ou HYBRID — détecter la sensibilité
        if self._trust_mode != TrustMode.OFF and self._anonymizer._detector:
            has_sensitive = self._anonymizer._detector.has_sensitive_data(text)
            if has_sensitive and self._routing_mode == RoutingMode.AUTO:
                # En AUTO, les données sensibles vont en local
                return RouteDecision(
                    provider_name="ollama",
                    model=self._config.get_provider_config("ollama").default_model,
                    reason="données sensibles détectées → local",
                    anonymized=False,  # local = pas besoin d'anonymiser
                )

        # Pas de données sensibles ou mode HYBRID → cloud avec anonymisation
        provider = self._config.default_provider
        return RouteDecision(
            provider_name=provider,
            model=self._config.resolve_model(provider=provider),
            reason="pas de données sensibles → cloud",
            anonymized=self._trust_mode != TrustMode.OFF,
        )

    def anonymize(self, text: str) -> str:
        """Anonymise un texte avant envoi au LLM."""
        return self._anonymizer.anonymize_text(text)

    def deanonymize(self, text: str) -> str:
        """Dé-anonymise une réponse LLM."""
        return self._anonymizer.deanonymize_text(text)

    def has_credentials(self, provider_name: str) -> bool:
        """Vérifie si un provider a ses credentials configurés."""
        import os
        match provider_name:
            case "anthropic":
                return bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
            case "openai":
                return bool(os.environ.get("OPENAI_API_KEY"))
            case "gemini":
                return bool(os.environ.get("GOOGLE_API_KEY"))
            case "ollama":
                return True  # Pas de credentials nécessaires
            case _:
                return False

    def resolve_available_provider(self) -> tuple[str, str]:
        """Résout le meilleur provider disponible. Retourne (provider, model).

        Ordre : provider par défaut > anthropic > openai > gemini > ollama."""
        # Le provider par défaut en premier
        default = self._config.default_provider
        if self.has_credentials(default):
            return default, self._config.resolve_model(provider=default)

        # Essayer les autres providers cloud
        for name in ("anthropic", "openai", "gemini"):
            if name != default and self.has_credentials(name):
                return name, self._config.get_provider_config(name).default_model

        # Fallback Ollama (toujours disponible)
        return "ollama", self._config.get_provider_config("ollama").default_model

    async def get_client(self, provider_name: str) -> Any:
        """Retourne le client pour un provider (lazy init)."""
        if provider_name not in self._clients:
            self._clients[provider_name] = self._create_client(provider_name)
        return self._clients[provider_name]

    def _create_client(self, provider_name: str) -> Any:
        """Crée un client pour le provider demandé."""
        match provider_name:
            case "anthropic":
                return AnthropicClient.from_env()
            case "openai":
                return OpenAiCompatClient.from_env()
            case "gemini":
                return GeminiClient.from_env()
            case "ollama":
                return OllamaClient.from_env()
            case _:
                raise ValueError(f"Provider inconnu: {provider_name}")

    async def send_message(
        self,
        request: MessageRequest,
        user_text: str = "",
    ) -> tuple[MessageResponse, RouteDecision]:
        """Envoie un message avec routage + anonymisation automatiques.

        Returns:
            (response, decision) — la réponse LLM + les détails du routage
        """
        # 1. Décider du routage
        decision = self.route(user_text or "")

        # 2. Anonymiser si nécessaire
        if decision.anonymized:
            request = self._anonymize_request(request)

        # 3. Si le user a spécifié un modèle, adapter le provider au modèle (pas l'inverse)
        target_model = request.model if request.model else decision.model
        if request.model:
            actual_provider = self._config.resolve_provider_for_model(request.model)
            if actual_provider != decision.provider_name:
                decision = RouteDecision(
                    provider_name=actual_provider,
                    model=request.model,
                    reason=f"modèle {request.model} → {actual_provider}",
                    anonymized=decision.anonymized and actual_provider != "ollama",
                )
                target_model = request.model
        request = MessageRequest(
            model=target_model,
            max_tokens=request.max_tokens,
            messages=request.messages,
            system=request.system,
            tools=request.tools,
            tool_choice=request.tool_choice,
            stream=request.stream,
        )

        # 4. Envoyer
        client = await self.get_client(decision.provider_name)
        response = await client.send_message(request)

        # 5. Dé-anonymiser la réponse si nécessaire
        if decision.anonymized:
            response = self._deanonymize_response(response)

        return response, decision

    def _anonymize_request(self, request: MessageRequest) -> MessageRequest:
        """Anonymise les messages d'une requête."""
        from maestro_core.api.types import InputMessage, TextInputBlock

        anonymized_messages = []
        for msg in request.messages:
            new_content = []
            for block in msg.content:
                if isinstance(block, TextInputBlock):
                    new_content.append(TextInputBlock(
                        text=self._anonymizer.anonymize_text(block.text)
                    ))
                else:
                    new_content.append(block)
            anonymized_messages.append(InputMessage(
                role=msg.role,
                content=new_content,
            ))

        return MessageRequest(
            model=request.model,
            max_tokens=request.max_tokens,
            messages=anonymized_messages,
            system=request.system,
            tools=request.tools,
            tool_choice=request.tool_choice,
            stream=request.stream,
        )

    def _deanonymize_response(self, response: MessageResponse) -> MessageResponse:
        """Dé-anonymise le contenu de la réponse."""
        from maestro_core.api.types import TextOutputBlock, OutputContentBlock

        new_content = []
        for block in response.content:
            if isinstance(block, TextOutputBlock):
                new_content.append(TextOutputBlock(
                    text=self._anonymizer.deanonymize_text(block.text)
                ))
            else:
                new_content.append(block)

        return MessageResponse(
            id=response.id,
            kind=response.kind,
            role=response.role,
            content=new_content,
            model=response.model,
            stop_reason=response.stop_reason,
            stop_sequence=response.stop_sequence,
            usage=response.usage,
            request_id=response.request_id,
        )

    async def close(self) -> None:
        """Ferme tous les clients."""
        for client in self._clients.values():
            if hasattr(client, "close"):
                await client.close()
        self._clients.clear()
