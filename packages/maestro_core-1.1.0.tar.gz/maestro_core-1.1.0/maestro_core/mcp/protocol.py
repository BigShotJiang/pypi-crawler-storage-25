"""
Bootstrap des clients MCP.

Traduit depuis mcp_client.rs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from maestro_core.runtime.config import McpOAuthConfig, McpServerConfig, ScopedMcpServerConfig, McpTransport
from maestro_core.mcp.client import normalize_name_for_mcp, mcp_tool_prefix, mcp_server_signature

DEFAULT_MCP_TOOL_CALL_TIMEOUT_MS = 60_000

class McpClientAuth(Enum):
    NONE = "none"
    OAUTH = "oauth"

    def requires_user_auth(self) -> bool:
        return self == McpClientAuth.OAUTH

@dataclass
class McpStdioTransport:
    command: str = ""
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    tool_call_timeout_ms: int | None = None

    def resolved_tool_call_timeout_ms(self) -> int:
        return self.tool_call_timeout_ms or DEFAULT_MCP_TOOL_CALL_TIMEOUT_MS

@dataclass
class McpRemoteTransport:
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    headers_helper: str | None = None
    auth: McpClientAuth = McpClientAuth.NONE

@dataclass
class McpSdkTransport:
    name: str = ""

@dataclass
class McpManagedProxyTransport:
    url: str = ""
    id: str = ""

@dataclass
class McpClientTransport:
    """Transport client MCP (union des types)."""
    kind: str = "stdio"
    stdio: McpStdioTransport | None = None
    sse: McpRemoteTransport | None = None
    http: McpRemoteTransport | None = None
    websocket: McpRemoteTransport | None = None
    sdk: McpSdkTransport | None = None
    managed_proxy: McpManagedProxyTransport | None = None

@dataclass
class McpClientBootstrap:
    server_name: str = ""
    normalized_name: str = ""
    tool_prefix: str = ""
    signature: str | None = None
    transport: McpClientTransport = field(default_factory=McpClientTransport)

    @staticmethod
    def from_scoped_config(server_name: str, config: ScopedMcpServerConfig) -> McpClientBootstrap:
        return McpClientBootstrap(
            server_name=server_name,
            normalized_name=normalize_name_for_mcp(server_name),
            tool_prefix=mcp_tool_prefix(server_name),
            signature=mcp_server_signature(config.config) if config.config else None,
            transport=McpClientTransport(),
        )
