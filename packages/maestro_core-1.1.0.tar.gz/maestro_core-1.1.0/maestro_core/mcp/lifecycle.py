"""
Validation du cycle de vie MCP durci.

Traduit depuis mcp_lifecycle_hardened.rs.
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from enum import Enum
from datetime import timedelta

def _now_secs() -> int:
    return int(time.time())

class McpLifecyclePhase(Enum):
    CONFIG_LOAD = "config_load"
    SERVER_REGISTRATION = "server_registration"
    SPAWN_CONNECT = "spawn_connect"
    INITIALIZE_HANDSHAKE = "initialize_handshake"
    TOOL_DISCOVERY = "tool_discovery"
    RESOURCE_DISCOVERY = "resource_discovery"
    READY = "ready"
    INVOCATION = "invocation"
    ERROR_SURFACING = "error_surfacing"
    SHUTDOWN = "shutdown"
    CLEANUP = "cleanup"

    @staticmethod
    def all() -> list[McpLifecyclePhase]:
        return list(McpLifecyclePhase)

@dataclass
class McpErrorSurface:
    phase: McpLifecyclePhase = McpLifecyclePhase.CONFIG_LOAD
    server_name: str | None = None
    message: str = ""
    context: dict[str, str] = field(default_factory=dict)
    recoverable: bool = False
    timestamp: int = field(default_factory=_now_secs)

@dataclass
class McpPhaseResult:
    pass

@dataclass
class McpPhaseSuccess(McpPhaseResult):
    phase: McpLifecyclePhase = McpLifecyclePhase.CONFIG_LOAD
    duration_ms: float = 0.0

@dataclass
class McpPhaseFailure(McpPhaseResult):
    phase: McpLifecyclePhase = McpLifecyclePhase.CONFIG_LOAD
    error: McpErrorSurface = field(default_factory=McpErrorSurface)
    recoverable: bool = False

@dataclass
class McpPhaseTimeout(McpPhaseResult):
    phase: McpLifecyclePhase = McpLifecyclePhase.CONFIG_LOAD
    waited_ms: float = 0.0

@dataclass
class McpFailedServer:
    server_name: str = ""
    phase: McpLifecyclePhase = McpLifecyclePhase.CONFIG_LOAD
    error: McpErrorSurface = field(default_factory=McpErrorSurface)

@dataclass
class McpDegradedReport:
    working_servers: list[str] = field(default_factory=list)
    failed_servers: list[McpFailedServer] = field(default_factory=list)
    available_tools: list[str] = field(default_factory=list)
    missing_tools: list[str] = field(default_factory=list)

@dataclass
class McpLifecycleState:
    current_phase: McpLifecyclePhase | None = None
    phase_errors: dict[McpLifecyclePhase, list[McpErrorSurface]] = field(default_factory=dict)
    phase_timestamps: dict[McpLifecyclePhase, int] = field(default_factory=dict)
    phase_results: list[McpPhaseResult] = field(default_factory=list)

    def errors_for_phase(self, phase: McpLifecyclePhase) -> list[McpErrorSurface]:
        return self.phase_errors.get(phase, [])

    def results(self) -> list[McpPhaseResult]:
        return self.phase_results

class McpLifecycleValidator:
    def __init__(self) -> None:
        self._state = McpLifecycleState()

    def state(self) -> McpLifecycleState:
        return self._state

    @staticmethod
    def validate_phase_transition(from_phase: McpLifecyclePhase, to_phase: McpLifecyclePhase) -> bool:
        valid = {
            (McpLifecyclePhase.CONFIG_LOAD, McpLifecyclePhase.SERVER_REGISTRATION),
            (McpLifecyclePhase.SERVER_REGISTRATION, McpLifecyclePhase.SPAWN_CONNECT),
            (McpLifecyclePhase.SPAWN_CONNECT, McpLifecyclePhase.INITIALIZE_HANDSHAKE),
            (McpLifecyclePhase.INITIALIZE_HANDSHAKE, McpLifecyclePhase.TOOL_DISCOVERY),
            (McpLifecyclePhase.TOOL_DISCOVERY, McpLifecyclePhase.RESOURCE_DISCOVERY),
            (McpLifecyclePhase.TOOL_DISCOVERY, McpLifecyclePhase.READY),
            (McpLifecyclePhase.RESOURCE_DISCOVERY, McpLifecyclePhase.READY),
            (McpLifecyclePhase.READY, McpLifecyclePhase.INVOCATION),
            (McpLifecyclePhase.INVOCATION, McpLifecyclePhase.READY),
            (McpLifecyclePhase.ERROR_SURFACING, McpLifecyclePhase.READY),
            (McpLifecyclePhase.ERROR_SURFACING, McpLifecyclePhase.SHUTDOWN),
            (McpLifecyclePhase.SHUTDOWN, McpLifecyclePhase.CLEANUP),
        }
        if (from_phase, to_phase) in valid:
            return True
        if to_phase == McpLifecyclePhase.SHUTDOWN and from_phase != McpLifecyclePhase.CLEANUP:
            return True
        if to_phase == McpLifecyclePhase.ERROR_SURFACING and from_phase not in (McpLifecyclePhase.CLEANUP, McpLifecyclePhase.SHUTDOWN):
            return True
        return False

    def run_phase(self, phase: McpLifecyclePhase) -> McpPhaseResult:
        started = time.monotonic()
        if self._state.current_phase is not None:
            if not self.validate_phase_transition(self._state.current_phase, phase):
                error = McpErrorSurface(phase=phase, message=f"invalid MCP lifecycle transition from {self._state.current_phase.value} to {phase.value}", recoverable=False)
                self._state.phase_errors.setdefault(phase, []).append(error)
                self._state.current_phase = McpLifecyclePhase.ERROR_SURFACING
                result = McpPhaseFailure(phase=phase, error=error)
                self._state.phase_results.append(result)
                return result
        elif phase != McpLifecyclePhase.CONFIG_LOAD:
            error = McpErrorSurface(phase=phase, message=f"invalid initial MCP lifecycle phase {phase.value}")
            result = McpPhaseFailure(phase=phase, error=error)
            self._state.phase_results.append(result)
            return result

        self._state.current_phase = phase
        self._state.phase_timestamps[phase] = _now_secs()
        duration = (time.monotonic() - started) * 1000
        result = McpPhaseSuccess(phase=phase, duration_ms=duration)
        self._state.phase_results.append(result)
        return result
