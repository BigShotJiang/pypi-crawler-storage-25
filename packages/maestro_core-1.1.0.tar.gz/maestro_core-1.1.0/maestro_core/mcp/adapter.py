"""MCP Tool Adapter — intègre les tools MCP dans le ToolRegistry de maestro_core.

Charge les serveurs MCP depuis la config, découvre leurs tools, et les enregistre
dans le ToolRegistry pour qu'ils soient utilisables par le ConversationEngine.

Config : ~/.maestro/mcp.json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/Users/me/projects"],
      "env": {}
    },
    "postgres": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-postgres", "postgresql://..."],
    }
  }
}
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolRegistry, ToolResult

from .stdio import (
    McpServerManager,
    McpStdioProcess,
    McpToolCallContent,
    ManagedMcpTool,
)

logger = logging.getLogger(__name__)

MCP_CONFIG_PATHS = [
    Path.home() / ".maestro" / "mcp.json",
    Path.cwd() / ".maestro" / "mcp.json",
    Path.cwd() / "mcp.json",
]


@dataclass
class McpServerConfig:
    """Configuration d'un serveur MCP."""

    name: str
    command: str
    args: list[str]
    env: dict[str, str]


class McpToolWrapper(Tool):
    """Wrappe un tool MCP dans l'interface maestro_core.tools.Tool."""

    def __init__(
        self,
        managed_tool: ManagedMcpTool,
        manager: McpServerManager,
        loop: asyncio.AbstractEventLoop,
    ) -> None:
        self._managed = managed_tool
        self._manager = manager
        self._loop = loop

        # Mapper les champs
        self.name = managed_tool.qualified_name
        self.description = managed_tool.tool.description or f"MCP tool: {managed_tool.tool.name}"
        self.input_schema = managed_tool.tool.input_schema or {
            "type": "object",
            "properties": {},
        }
        self.risk_level = RiskLevel.MEDIUM  # MCP tools = risque moyen par défaut

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        """Appelle le tool MCP via JSON-RPC."""
        try:
            response = self._loop.run_until_complete(
                self._manager.call_tool(self._managed.qualified_name, args)
            )

            if response.error:
                return ToolResult(
                    content=f"MCP error: {response.error.message}",
                    is_error=True,
                )

            # Extraire le contenu de la réponse
            result = response.result
            if result is None:
                return ToolResult(content="<no result>")

            # Le résultat MCP est souvent {"content": [{"type": "text", "text": "..."}]}
            if isinstance(result, dict) and "content" in result:
                content_parts = result["content"]
                texts = []
                for part in content_parts:
                    if isinstance(part, dict):
                        if part.get("type") == "text":
                            texts.append(part.get("text", ""))
                        elif part.get("type") == "image":
                            texts.append(f"[image: {part.get('mimeType', 'image')}]")
                        else:
                            texts.append(json.dumps(part, ensure_ascii=False))
                    else:
                        texts.append(str(part))
                return ToolResult(content="\n".join(texts))

            # Fallback : sérialiser le résultat
            if isinstance(result, str):
                return ToolResult(content=result)
            return ToolResult(content=json.dumps(result, ensure_ascii=False, default=str))

        except Exception as e:
            logger.error(f"MCP tool '{self.name}' error: {e}")
            return ToolResult(content=str(e), is_error=True)


def load_mcp_config() -> list[McpServerConfig]:
    """Charge la config MCP depuis les chemins standard."""
    for config_path in MCP_CONFIG_PATHS:
        if config_path.exists():
            try:
                data = json.loads(config_path.read_text())
                servers = data.get("mcpServers", {})
                configs = []
                for name, server_data in servers.items():
                    configs.append(McpServerConfig(
                        name=name,
                        command=server_data.get("command", ""),
                        args=server_data.get("args", []),
                        env=server_data.get("env", {}),
                    ))
                if configs:
                    logger.info(f"Loaded {len(configs)} MCP servers from {config_path}")
                return configs
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning(f"Failed to parse MCP config {config_path}: {e}")
    return []


async def _start_mcp_servers(
    configs: list[McpServerConfig],
) -> McpServerManager:
    """Démarre les serveurs MCP et découvre leurs tools."""
    manager = McpServerManager()

    for config in configs:
        try:
            process = McpStdioProcess(
                command=config.command,
                args=config.args,
                env=config.env or None,
            )
            await process.start()

            # Initialize le serveur MCP
            init_response = await process.send_request("initialize", {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "maestro", "version": "0.5.0"},
            })

            if init_response.error:
                logger.warning(f"MCP server '{config.name}' init failed: {init_response.error.message}")
                await process.shutdown()
                continue

            # Notification initialized
            await process.send_request("notifications/initialized", {})

            await manager.add_server(config.name, process)
            logger.info(f"MCP server '{config.name}' started ({config.command})")

        except Exception as e:
            logger.warning(f"Failed to start MCP server '{config.name}': {e}")

    # Découvrir les tools
    if manager._processes:
        report = await manager.discover_tools()
        logger.info(
            f"MCP discovery: {len(report.tools)} tools, "
            f"{len(report.unsupported)} unsupported servers"
        )

    return manager


def register_mcp_tools(
    registry: ToolRegistry,
    loop: asyncio.AbstractEventLoop | None = None,
) -> McpServerManager | None:
    """Charge les serveurs MCP et enregistre leurs tools dans le registry.

    Returns:
        Le McpServerManager (pour shutdown plus tard), ou None si aucun serveur.
    """
    configs = load_mcp_config()
    if not configs:
        return None

    _loop = loop or asyncio.new_event_loop()

    try:
        manager = _loop.run_until_complete(_start_mcp_servers(configs))
    except Exception as e:
        logger.error(f"Failed to start MCP servers: {e}")
        return None

    # Enregistrer les tools MCP dans le registry
    for managed_tool in manager._tools:
        wrapper = McpToolWrapper(managed_tool, manager, _loop)
        registry.register(wrapper)
        logger.info(f"Registered MCP tool: {wrapper.name}")

    tool_count = len(manager._tools)
    if tool_count > 0:
        logger.info(f"Registered {tool_count} MCP tools")

    return manager
