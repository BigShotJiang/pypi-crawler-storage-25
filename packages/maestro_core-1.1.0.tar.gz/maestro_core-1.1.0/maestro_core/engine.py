"""Conversation Engine — boucle de conversation avec tool calling.

Orchestre : user message → anonymisation → LLM → tool execution → LLM → ... → réponse finale.
Utilisé par le CLI et par OKE Cloud."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

from maestro_core.api.types import (
    InputMessage,
    TextInputBlock,
    ToolUseInputBlock,
    ToolResultInputBlock,
    TextToolResultBlock,
    MessageRequest,
    MessageResponse,
    TextOutputBlock,
    ToolUseOutputBlock,
    OutputContentBlock,
    Usage,
    ToolDefinition as ApiToolDef,
)
from maestro_core.provider_router import ProviderRouter, RouteDecision
from maestro_core.tools.base import ToolRegistry, ToolDefinition


@dataclass
class ToolCallResult:
    """Résultat d'un appel d'outil."""

    tool_name: str
    tool_id: str
    arguments: dict[str, Any]
    result: str
    is_error: bool
    duration_ms: int


@dataclass
class TurnResult:
    """Résultat d'un tour de conversation."""

    response_text: str
    tool_calls: list[ToolCallResult]
    usage: Usage
    model: str
    provider: str
    decision: RouteDecision
    duration_seconds: float
    turn_count: int  # nombre de sous-tours (LLM calls) dans ce tour


class ConversationEngine:
    """Boucle de conversation avec tool calling.

    Orchestre la boucle :
    1. Le user envoie un message
    2. Le router choisit le provider + anonymise si nécessaire
    3. Le LLM répond (texte et/ou tool_use)
    4. Si tool_use : exécuter les outils, renvoyer les résultats au LLM
    5. Répéter 3-4 jusqu'à réponse finale (pas de tool_use) ou max_turns
    """

    def __init__(
        self,
        router: ProviderRouter,
        tools: Optional[ToolRegistry] = None,
        max_turns: int = 25,
        max_tokens: int = 4096,
    ) -> None:
        self.router = router
        self.tools = tools
        self.max_turns = max_turns
        self.max_tokens = max_tokens
        self._messages: list[InputMessage] = []

    @property
    def messages(self) -> list[InputMessage]:
        """Copie de l'historique de conversation."""
        return list(self._messages)

    def set_messages(self, messages: list[InputMessage]) -> None:
        """Remplace l'historique de conversation."""
        self._messages = list(messages)

    def clear(self) -> None:
        """Vide l'historique de conversation."""
        self._messages.clear()

    async def run_turn(
        self,
        user_text: str,
        system_prompt: str = "",
        model: str = "",
    ) -> TurnResult:
        """Exécute un tour complet : user message → [LLM → tools]* → réponse finale.

        Args:
            user_text: Message de l'utilisateur.
            system_prompt: System prompt (optionnel, envoyé à chaque requête LLM).
            model: Modèle à utiliser (vide = laisser le router décider).

        Returns:
            TurnResult avec la réponse finale, les appels d'outils, et les métriques.
        """
        start = time.time()

        # Ajouter le message utilisateur à l'historique
        self._messages.append(InputMessage.user_text(user_text))

        # Préparer les définitions d'outils pour l'API
        tool_defs = self._build_tool_defs()

        total_usage = Usage()
        all_tool_calls: list[ToolCallResult] = []
        sub_turns = 0
        last_decision: Optional[RouteDecision] = None

        while sub_turns < self.max_turns:
            sub_turns += 1

            # Construire la requête
            request = MessageRequest(
                model=model,
                max_tokens=self.max_tokens,
                messages=list(self._messages),
                system=system_prompt or None,
                tools=tool_defs,
            )

            # Envoyer au LLM via le router (gère routage + anonymisation)
            response, decision = await self.router.send_message(request, user_text)
            last_decision = decision

            # Accumuler l'usage
            total_usage = self._merge_usage(total_usage, response.usage)

            # Séparer les blocs texte et tool_use
            text_parts: list[str] = []
            tool_use_blocks: list[ToolUseOutputBlock] = []
            assistant_content: list = []

            for block in response.content:
                if isinstance(block, TextOutputBlock):
                    text_parts.append(block.text)
                    assistant_content.append(TextInputBlock(text=block.text))
                elif isinstance(block, ToolUseOutputBlock):
                    tool_use_blocks.append(block)
                    assistant_content.append(ToolUseInputBlock(
                        id=block.id,
                        name=block.name,
                        input=block.input,
                    ))
                # ThinkingOutputBlock etc. — ignorés dans l'historique

            # Ajouter la réponse assistant à l'historique
            self._messages.append(InputMessage(
                role="assistant",
                content=assistant_content,
            ))

            # Pas de tool calls → tour terminé
            if not tool_use_blocks:
                return TurnResult(
                    response_text="\n".join(text_parts),
                    tool_calls=all_tool_calls,
                    usage=total_usage,
                    model=response.model or model,
                    provider=decision.provider_name,
                    decision=decision,
                    duration_seconds=time.time() - start,
                    turn_count=sub_turns,
                )

            # Exécuter les outils
            tool_result_blocks = await self._execute_tools(
                tool_use_blocks, all_tool_calls
            )

            # Ajouter les résultats d'outils à l'historique (message user)
            self._messages.append(InputMessage(
                role="user",
                content=tool_result_blocks,
            ))

            # Boucle : le LLM va traiter les résultats

        # Limite de tours atteinte
        fallback_decision = last_decision or RouteDecision(
            provider_name="", model="", reason="max turns", anonymized=False
        )
        return TurnResult(
            response_text="[Limite de tours atteinte]",
            tool_calls=all_tool_calls,
            usage=total_usage,
            model=model,
            provider=fallback_decision.provider_name,
            decision=fallback_decision,
            duration_seconds=time.time() - start,
            turn_count=sub_turns,
        )

    def _build_tool_defs(self) -> Optional[list[ApiToolDef]]:
        """Construit les définitions d'outils au format API."""
        if not self.tools or len(self.tools) == 0:
            return None
        return [
            ApiToolDef(
                name=td.name,
                description=td.description,
                input_schema=td.input_schema,
            )
            for td in self.tools.get_definitions()
        ]

    async def _execute_tools(
        self,
        tool_use_blocks: list[ToolUseOutputBlock],
        all_tool_calls: list[ToolCallResult],
    ) -> list[ToolResultInputBlock]:
        """Exécute une liste de tool_use blocks et retourne les résultats."""
        result_blocks: list[ToolResultInputBlock] = []

        for block in tool_use_blocks:
            tool_start = time.time()
            args = block.input or {}

            if self.tools:
                result = await self.tools.execute(block.name, args)
                content = result.content
                is_error = result.is_error
            else:
                content = f"Tool '{block.name}' not available"
                is_error = True

            duration_ms = int((time.time() - tool_start) * 1000)

            # Logger dans la liste globale
            all_tool_calls.append(ToolCallResult(
                tool_name=block.name,
                tool_id=block.id,
                arguments=args,
                result=content[:2000],  # tronquer pour le logging
                is_error=is_error,
                duration_ms=duration_ms,
            ))

            # Construire le bloc résultat pour le LLM
            result_blocks.append(ToolResultInputBlock(
                tool_use_id=block.id,
                content=[TextToolResultBlock(text=content)],
                is_error=is_error,
            ))

        return result_blocks

    @staticmethod
    def _merge_usage(a: Usage, b: Usage) -> Usage:
        """Fusionne deux Usage en additionnant les tokens."""
        return Usage(
            input_tokens=a.input_tokens + b.input_tokens,
            output_tokens=a.output_tokens + b.output_tokens,
            cache_creation_input_tokens=(
                a.cache_creation_input_tokens + b.cache_creation_input_tokens
            ),
            cache_read_input_tokens=(
                a.cache_read_input_tokens + b.cache_read_input_tokens
            ),
        )
