# maestro-core

Core engine for Maestro AI agent. Multi-provider, privacy-first.

## Features

- **4 LLM Providers**: Anthropic (Claude), OpenAI (GPT), Google (Gemini), Ollama (local)
- **Trust Layer**: Automatic anonymization of sensitive data (NIR, SIRET, IBAN, emails, names, API keys)
- **Provider Router**: Auto-route to local/cloud based on data sensitivity
- **Conversation Engine**: Turn loop with tool calling
- **Tool Framework**: Base classes + 6 built-in tools (bash, file_read, file_write, file_edit, grep, glob)

## Installation

```bash
pip install maestro-core
```

## Usage

```python
from maestro_core.engine import ConversationEngine
from maestro_core.provider_router import ProviderRouter, RoutingMode
from maestro_core.tools import ToolRegistry
from maestro_core.tools.bash import BashTool
from maestro_core.config import MaestroConfig
from maestro_core.trust.anonymizer import TrustMode

# Setup
config = MaestroConfig()
router = ProviderRouter(config, RoutingMode.AUTO, TrustMode.STANDARD)

tools = ToolRegistry()
tools.register(BashTool())

engine = ConversationEngine(router=router, tools=tools)

# Chat
result = await engine.run_turn("List Python files", model="claude-sonnet-4")
print(result.response_text)
```

## Trust Layer

```python
from maestro_core.trust.anonymizer import Anonymizer, TrustMode

anon = Anonymizer(TrustMode.STANDARD)
safe = anon.anonymize_text("NIR 267041305561777 SIRET 41021468800013")
# → "NIR [NIR_1] SIRET [SIRET_1]"

restored = anon.deanonymize_text(safe)
# → "NIR 267041305561777 SIRET 41021468800013"
```
