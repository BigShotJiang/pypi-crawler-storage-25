# streamlit-video-editor

A non-linear video editor component for Streamlit featuring a multi-track timeline, drag-and-drop clips, audio alignment, and more.

## Installation

```bash
pip install streamlit-video-editor
```

## Usage

```python
from streamlit_video_editor import st_video_editor

result = st_video_editor(key="editor")
```
