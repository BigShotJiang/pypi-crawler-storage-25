"""
Complete Pre-Development Check for Python Projects
Combines version validation + Quick Check API
Uses manifestguard.core.VersionValidator
"""

import sys

from manifestguard.api import QuickCheck
from manifestguard.core import VersionValidator


def pre_dev_check(project_path: str = ".", package_name: str = "manifestguard"):
    """
    Complete pre-development check:
    1. Version validation (x.y.z)
    2. Project detection
    3. Test recommendations
    4. Config generation
    """
    print("=" * 70)
    print("ManifestGuard Pre-Development Check")
    print("=" * 70)

    # 1. Version validation
    print("\n[1/4] Validating version schema (x.y.z)...")
    validator = VersionValidator()
    success, version_info, message = validator.validate_package(package_name)
    print(f"      {message}")
    if not success:
        print("\n❌ Pre-development check FAILED")
        return False

    # Show version components
    if version_info:
        print(
            f"      Components: major={version_info.major}, minor={version_info.minor}, patch={version_info.patch}"
        )
        print(f"      Stable: {version_info.is_stable}")

    # 2. Project detection
    print("\n[2/4] Detecting project type...")
    qc = QuickCheck()
    info = qc.detect_project_type(project_path)
    print(f"      ✅ Type: {info.project_type.name}")
    print(f"      ✅ Root: {info.root_path}")
    print(f"      ✅ Features: {', '.join(sorted(info.detected_features))}")
    print(f"      ✅ Tests: {info.has_tests}, CLI: {info.has_cli}, GUI: {info.has_gui}")

    # 3. Test recommendations
    print("\n[3/4] Generating test recommendations...")
    recommendations = qc.recommend_tests(info)
    print(f"      ✅ Total recommendations: {len(recommendations)}")

    high_priority = [r for r in recommendations if r.priority.name == "HIGH"]
    print(f"\n      High priority tests ({len(high_priority)}):")
    for rec in high_priority:
        print(f"         🔴 {rec.name}")
        print(f"            {rec.reason}")

    # 4. Config generation
    print("\n[4/4] Generating manifestguard.json config...")
    config = qc.generate_config_template(info, recommendations)
    print(f"      ✅ Config version: {config.version}")
    print(f"      ✅ Enabled: {config.enabled}")
    print(f"      ✅ Recommended tests: {len(config.recommended_tests)}")
    print(f"      ✅ Settings: {list(config.settings.keys())}")

    # Summary
    print("\n" + "=" * 70)
    print("✅ Pre-Development Check PASSED")
    print("=" * 70)
    print("\nNext steps:")
    print("  1. Review test recommendations above")
    print("  2. Create manifestguard.json from config template")
    print("  3. Implement recommended tests")
    print("  4. Run: manifestguard check")
    print("\nFor VS Code Extension developers:")
    print('  - Use: python -c "from manifestguard.api import QuickCheck; ..."')
    print("  - See: AI-PYTHON-PROJECT-INSTRUCTIONS.md")
    print("=" * 70)

    return True


if __name__ == "__main__":
    success = pre_dev_check(project_path=".", package_name="manifestguard")
    sys.exit(0 if success else 1)
