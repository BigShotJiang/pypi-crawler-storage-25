from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from .rich_compat import console
from .types import PipInstallScope


def ensure_python_package(package: str, import_name: str | None = None) -> None:
    """Ensure a Python package is available, installing it via pip when missing."""
    module_name = import_name or package
    try:
        __import__(module_name)
        return
    except ImportError:
        console.print(f"Installing missing dependency: [cyan]{package}[/cyan]")

    subprocess.run(
        [sys.executable, "-m", "pip", "install", package],
        check=True,
    )


def is_running_in_venv() -> bool:
    """Return True if current interpreter is a virtual environment."""
    base_prefix = getattr(sys, "base_prefix", sys.prefix)
    return sys.prefix != base_prefix


def pip_install_command(
    python_executable: str,
    scope: PipInstallScope,
    *pip_args: str,
) -> list[str]:
    """Build a pip install command with a consistent install scope."""
    resolved_scope: PipInstallScope = scope
    if scope == "auto":
        resolved_scope = "current" if is_running_in_venv() else "user"

    command = [python_executable, "-m", "pip", *pip_args]
    if resolved_scope == "user":
        command.insert(4, "--user")
    return command


def get_manifestguard_runtime_info(python_executable: str) -> dict:
    """Return manifestguard runtime info for the provided interpreter."""
    code = (
        "import json, sys\n"
        'info = {"python": sys.executable, "prefix": sys.prefix, "base_prefix": getattr(sys, \'base_prefix\', sys.prefix)}\n'
        "try:\n"
        "  import manifestguard\n"
        "  from pathlib import Path\n"
        '  info.update({"installed": True, "version": getattr(manifestguard, \'__version__\', None), "module_path": str(Path(manifestguard.__file__).resolve())})\n'
        "except Exception as e:\n"
        '  info.update({"installed": False, "error": str(e)})\n'
        "sys.stdout.write(json.dumps(info, ensure_ascii=False))\n"
    )

    try:
        result = subprocess.run(
            [python_executable, "-c", code],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=True,
        )
        return json.loads(result.stdout.strip() or "{}")
    except Exception as exc:
        return {
            "python": python_executable,
            "installed": False,
            "error": str(exc),
        }


def resolve_global_python() -> str | None:
    """Find the base Python interpreter when running inside a virtual environment."""
    base_executable = getattr(sys, "_base_executable", None)
    current_executable = Path(sys.executable).resolve()

    candidates: list[Path] = []
    if base_executable:
        candidates.append(Path(base_executable))

    base_prefix = Path(getattr(sys, "base_prefix", sys.prefix))
    if sys.platform.startswith("win"):
        candidates.append(base_prefix / "python.exe")
    else:
        candidates.append(base_prefix / "bin" / "python3")
        candidates.append(base_prefix / "bin" / "python")

    for candidate in candidates:
        try:
            resolved = candidate.resolve(strict=True)
        except FileNotFoundError:
            continue
        if resolved != current_executable:
            return str(resolved)

    return None


def get_manifestguard_version(python_executable: str) -> str | None:
    """Return manifestguard version for the provided interpreter."""
    try:
        result = subprocess.run(
            [
                python_executable,
                "-c",
                "import manifestguard, sys; sys.stdout.write(manifestguard.__version__)",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None

    version = result.stdout.strip()
    return version or None


def get_user_scripts_dir(python_executable: str) -> str | None:
    """Return the user-level scripts directory for the given interpreter."""
    try:
        if sys.platform == "win32":
            code = "import sysconfig; print(sysconfig.get_path('scripts', scheme='nt_user'))"
        else:
            code = "import site; print(site.USER_BASE + '/bin')"

        result = subprocess.run(
            [python_executable, "-c", code],
            capture_output=True,
            text=True,
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None

    scripts_dir = result.stdout.strip()
    return scripts_dir or None


def get_scripts_dir(python_executable: str, scope: PipInstallScope) -> str | None:
    """Return the scripts directory that will receive console entry points."""
    try:
        if scope == "user":
            return get_user_scripts_dir(python_executable)

        if sys.platform == "win32":
            code = (
                "import sys, sysconfig\n"
                "is_venv = sys.prefix != getattr(sys, 'base_prefix', sys.prefix)\n"
                f"scope = {scope!r}\n"
                "if scope == 'auto':\n"
                "    scope = 'current' if is_venv else 'user'\n"
                "if scope == 'user':\n"
                "    path = sysconfig.get_path('scripts', scheme='nt_user')\n"
                "else:\n"
                "    path = sysconfig.get_path('scripts')\n"
                "print(path)\n"
            )
        else:
            code = (
                "import site, sys, sysconfig\n"
                "is_venv = sys.prefix != getattr(sys, 'base_prefix', sys.prefix)\n"
                f"scope = {scope!r}\n"
                "if scope == 'auto':\n"
                "    scope = 'current' if is_venv else 'user'\n"
                "if scope == 'user':\n"
                "    path = site.USER_BASE + '/bin'\n"
                "else:\n"
                "    path = sysconfig.get_path('scripts')\n"
                "print(path)\n"
            )

        result = subprocess.run(
            [python_executable, "-c", code],
            capture_output=True,
            text=True,
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None

    scripts_dir = result.stdout.strip()
    return scripts_dir or None


def get_manifestguard_command_path(python_executable: str, scope: PipInstallScope) -> str | None:
    """Return the expected manifestguard command path for the target install scope."""
    scripts_dir = get_scripts_dir(python_executable, scope)
    if not scripts_dir:
        return None

    command_name = "manifestguard.exe" if sys.platform == "win32" else "manifestguard"
    return str(Path(scripts_dir) / command_name)


def resolve_path_manifestguard_python() -> str | None:
    """Find the Python interpreter that owns the global `manifestguard` command in PATH.

    Skips any manifestguard that belongs to the currently active venv so that
    the real global install (e.g. a Python 3.13 user install) is found even
    when this code runs from within a venv.

    Handles two layouts:
    - System/regular install: python.exe sits next to the Scripts/ dir.
    - Windows user install (--user): scripts land in
        %APPDATA%\\Python\\PythonXYZ\\Scripts\\  but python.exe lives in the
        base Python directory.  We derive the version from the dir name and
        ask the `py` launcher for the matching interpreter.
    """
    mg_name = "manifestguard.exe" if sys.platform == "win32" else "manifestguard"
    venv_prefix = str(Path(sys.prefix).resolve()).lower()

    for path_entry in os.environ.get("PATH", "").split(os.pathsep):
        mg_candidate = Path(path_entry) / mg_name
        if not mg_candidate.exists():
            continue
        # Skip manifestguard that lives inside the current venv.
        if str(mg_candidate.resolve()).lower().startswith(venv_prefix):
            continue

        scripts_dir = mg_candidate.parent

        # Case 1: python.exe is co-located with the scripts (system / regular install).
        for name in ("python.exe", "python3.exe", "python3", "python"):
            py_candidate = scripts_dir / name
            if py_candidate.exists():
                return str(py_candidate.resolve())

        # Case 2: Windows user install — %APPDATA%\Python\PythonXYZ\Scripts\
        # Extract version from the Scripts parent dir name, e.g. "Python313" → "3.13".
        for part in (scripts_dir.name, scripts_dir.parent.name):
            m = re.search(r"[Pp]ython(\d)(\d+)", part)
            if m:
                version_tag = f"-{m.group(1)}.{m.group(2)}"
                py_launcher = shutil.which("py")
                if py_launcher:
                    try:
                        result = subprocess.run(
                            [py_launcher, version_tag, "-c", "import sys; print(sys.executable)"],
                            capture_output=True,
                            text=True,
                            check=False,
                            timeout=10,
                        )
                        if result.returncode == 0:
                            exe = result.stdout.strip()
                            if exe and Path(exe).exists():
                                return exe
                    except Exception:
                        pass
                break

    return None


def which(executable: str) -> str | None:
    resolved = shutil.which(executable)
    return resolved
