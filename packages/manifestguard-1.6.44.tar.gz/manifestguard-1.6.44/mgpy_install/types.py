from __future__ import annotations

from typing import Literal

PipInstallScope = Literal["auto", "current", "user", "system"]
GlobalInstallScope = Literal["user", "system"]
