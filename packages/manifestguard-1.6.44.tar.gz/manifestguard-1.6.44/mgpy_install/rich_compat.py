from __future__ import annotations

import subprocess
import sys


# --- Rich Integration ---
try:
    from rich.console import Console
    from rich.panel import Panel
except ImportError:
    print("'rich' library not found. Installing...")
    subprocess.run([sys.executable, "-m", "pip", "install", "rich"], check=True)
    from rich.console import Console
    from rich.panel import Panel


console = Console()


def print_safe(text: str) -> None:
    """Print text using Rich if possible, fallback to plain print."""
    try:
        console.print(text)
    except Exception:
        try:
            print(text)
        except Exception:
            pass


def print_process_output(result) -> None:
    """Pretty-print process output captured from a subprocess result.

    Uses a safe fallback for Windows consoles that can't encode unicode.
    """

    def _safe_print(text: str) -> None:
        try:
            console.print(text)
        except Exception:
            try:
                sanitized = text.encode("ascii", "ignore").decode("ascii")
                print(sanitized)
            except Exception:
                pass

    if getattr(result, "stdout", None):
        _safe_print(str(result.stdout).rstrip())
    if getattr(result, "stderr", None):
        _safe_print(str(result.stderr).rstrip())
