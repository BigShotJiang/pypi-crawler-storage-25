from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from .rich_compat import Panel, console


def maybe_reexec_into_repo_venv(script_path: Path, argv: list[str]) -> None:
    """Re-exec this script using the repo's .venv interpreter when available.

    This script is often invoked from arbitrary working directories using a global
    Python. If a repo-local virtual environment exists, prefer it for deterministic
    runs.
    """
    if os.environ.get("MGPY_INSTALL_REEXEC", "").strip() == "1":
        return

    repo_root = script_path.resolve().parent
    candidates = [
        repo_root / ".venv" / "Scripts" / "python.exe",  # Windows
        repo_root / ".venv" / "bin" / "python",  # POSIX
    ]
    venv_python = next((p for p in candidates if p.exists()), None)
    if venv_python is None:
        return

    try:
        current = Path(sys.executable).resolve()
        target = venv_python.resolve()
        if str(current).lower() == str(target).lower():
            return
    except Exception:
        return

    try:
        console.print(
            Panel(
                f"Re-executing with repo venv interpreter:\n[cyan]{target}[/cyan]\n"
                f"(was: [dim]{current}[/dim])",
                title="[bold]MGPY Install Runner[/bold]",
                border_style="blue",
            )
        )
    except Exception:
        print(f"Re-executing with repo venv interpreter: {target} (was: {current})")

    new_env = os.environ.copy()
    new_env["MGPY_INSTALL_REEXEC"] = "1"

    # Windows has no true execve; emulate via child process and wait.
    result = subprocess.run(
        [str(target), str(script_path.resolve()), *argv],
        env=new_env,
        check=False,
    )
    raise SystemExit(result.returncode)
