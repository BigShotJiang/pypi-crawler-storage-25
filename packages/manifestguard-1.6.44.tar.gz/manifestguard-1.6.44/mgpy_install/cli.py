from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .install import _ensure_user_scripts_preferred, install_from_local, sync_global_install
from .interpreters import default_extra_interpreters, install_into_interpreters
from .pip_utils import get_manifestguard_runtime_info, get_manifestguard_version, is_running_in_venv, resolve_global_python
from .reexec import maybe_reexec_into_repo_venv
from .rich_compat import Panel, console, print_safe
from .types import GlobalInstallScope, PipInstallScope
from .verify import (
    append_ruff_to_report,
    collect_ruff_metrics,
    detect_known_issues,
    print_process_output,
    run_manifestguard_command,
    run_manifestguard_init,
    run_pytest_with_coverage,
)


def _print_install_banner(pip_scope: PipInstallScope) -> None:
    current = get_manifestguard_runtime_info(sys.executable)
    in_venv = is_running_in_venv()
    resolved_scope = pip_scope
    if pip_scope == "auto":
        resolved_scope = "current" if in_venv else "user"

    console.print(Panel("ManifestGuard Runner", style="bold blue", expand=False))

    def _safe_emoji_print(text: str, fallback: str) -> None:
        try:
            console.print(text)
        except UnicodeEncodeError:
            console.print(fallback)

    _safe_emoji_print(
        f"🐍 Python: [cyan]{sys.executable}[/cyan] ([cyan]{sys.version.split()[0]}[/cyan])",
        f"Python: [cyan]{sys.executable}[/cyan] ([cyan]{sys.version.split()[0]}[/cyan])",
    )
    _safe_emoji_print(
        f"📌 Install scope: [bold]{pip_scope}[/bold] (resolved: [bold]{resolved_scope}[/bold])",
        f"Install scope: [bold]{pip_scope}[/bold] (resolved: [bold]{resolved_scope}[/bold])",
    )

    if current.get("installed"):
        _safe_emoji_print(
            f"📦 ManifestGuard: [cyan]{current.get('version') or 'unknown'}[/cyan]",
            f"ManifestGuard: [cyan]{current.get('version') or 'unknown'}[/cyan]",
        )
        _safe_emoji_print(
            f"📍 Location: [cyan]{current.get('module_path') or 'unknown'}[/cyan]",
            f"Location: [cyan]{current.get('module_path') or 'unknown'}[/cyan]",
        )
    else:
        _safe_emoji_print(
            "📦 ManifestGuard: [yellow]not installed in this interpreter[/yellow]",
            "ManifestGuard: [yellow]not installed in this interpreter[/yellow]",
        )
        if current.get("error"):
            _safe_emoji_print(
                f"⚠️  Import error: [dim]{current.get('error')}[/dim]",
                f"Import error: [dim]{current.get('error')}[/dim]",
            )

    global_python = resolve_global_python()
    if global_python:
        base_info = get_manifestguard_runtime_info(global_python)
        base_version = base_info.get("version") if base_info.get("installed") else None
        _safe_emoji_print(
            f"🌍 Base Python: [cyan]{global_python}[/cyan]",
            f"Base Python: [cyan]{global_python}[/cyan]",
        )
        _safe_emoji_print(
            f"🌍 Base ManifestGuard: [cyan]{base_version or 'not installed'}[/cyan]",
            f"Base ManifestGuard: [cyan]{base_version or 'not installed'}[/cyan]",
        )
        if base_info.get("installed"):
            _safe_emoji_print(
                f"🌍 Base location: [cyan]{base_info.get('module_path') or 'unknown'}[/cyan]",
                f"Base location: [cyan]{base_info.get('module_path') or 'unknown'}[/cyan]",
            )


def main() -> None:
    script_path = Path(__file__).resolve().parent.parent / "run_mgpy_install.py"
    maybe_reexec_into_repo_venv(script_path, sys.argv[1:])

    parser = argparse.ArgumentParser(description="ManifestGuard Runner")
    parser.add_argument(
        "--workspace",
        metavar="PATH",
        help="Workspace to run the MGPY self-test in (default: this repository)",
    )
    parser.add_argument(
        "--local-dev",
        metavar="PATH",
        help="Build from local dev directory (default: this repository)",
    )
    parser.add_argument(
        "--from-pip",
        action="store_true",
        help="Install/Update ManifestGuard from PyPI instead of local source",
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Force reinstall/sync even if Base Python already has the same version",
    )

    parser.add_argument(
        "--verify",
        action="store_true",
        help="(Dev) Run init-config + pytest + manifestguard check before syncing global install",
    )

    parser.add_argument(
        "--pip-scope",
        choices=["auto", "current", "user", "system"],
        default="auto",
        help="Where pip should install: auto(current if venv else user), current(env), user(--user), system(no --user)",
    )
    parser.add_argument(
        "--global-scope",
        choices=["user", "system"],
        default="user",
        help="Where to install into the base Python: user(--user, default) or system(no --user)",
    )

    parser.add_argument(
        "--no-global-sync",
        action="store_true",
        help="Do not sync/install into the base Python (global). Only build/install into the current interpreter.",
    )

    parser.add_argument(
        "--install-all-interpreters",
        action="store_true",
        help="Detect other installed Python interpreters and install the validated wheel into them",
    )
    parser.add_argument(
        "--install-interpreters",
        metavar="LIST",
        help="Comma-separated list of interpreter paths or versions (e.g. '3.12, C:/Python312/python.exe')",
    )

    args = parser.parse_args()

    pip_scope: PipInstallScope = args.pip_scope
    global_scope: GlobalInstallScope = args.global_scope
    _print_install_banner(pip_scope)

    repo_root = Path(__file__).resolve().parent.parent
    workspace_root = Path(args.workspace).resolve() if args.workspace else repo_root
    default_local_path = Path(args.local_dev).resolve() if args.local_dev else repo_root
    base_python = resolve_global_python()

    install_tokens: list[str] | None = None
    if args.install_interpreters:
        install_tokens = [t.strip() for t in args.install_interpreters.split(",") if t.strip()]
    elif sys.platform.startswith("win"):
        install_tokens = default_extra_interpreters(base_python)

    if not args.verify and not args.from_pip and not args.force:
        from .install import _collect_sync_targets, _recompile_after_install
        sync_targets = _collect_sync_targets(base_python)
        repo_version = get_manifestguard_version(sys.executable)
        version_targets = list(sync_targets)
        if install_tokens:
            version_targets.extend(install_tokens)

        if version_targets and repo_version:
            target_versions = {p: get_manifestguard_version(p) for p in version_targets}
            all_current = all(v == repo_version for v in target_versions.values())
            if all_current:
                for p in version_targets:
                    _recompile_after_install(p)
                _ensure_user_scripts_preferred(sync_targets[0], global_scope)
                targets_str = ", ".join(Path(p).name + f" ({Path(p).parent.parent.name})" for p in version_targets)
                print_safe(
                    f"\n[bold green]All global installs already have ManifestGuard {repo_version} [{targets_str}]. Nothing to update.[/bold green]"
                )
                raise SystemExit(0)

    local_source: Path | None
    if args.from_pip:
        with console.status("[bold green]Installing/Updating ManifestGuard from PyPI...", spinner="dots"):
            import subprocess

            cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "manifestguard"]
            if pip_scope == "user" or (pip_scope == "auto" and not is_running_in_venv()):
                cmd.insert(4, "--user")
            result = subprocess.run(cmd, check=False, capture_output=True, text=True)
            if result.returncode != 0:
                console.print(
                    Panel(
                        result.stderr,
                        title="[bold red]Installation Failed[/bold red]",
                        border_style="red",
                    )
                )
                raise SystemExit(1)
        console.print("ManifestGuard installed from PyPI.")
        local_source = None
        built_wheel = None
    else:
        local_source = default_local_path
        built_wheel = install_from_local(str(local_source), pip_scope)

    if not args.verify:
        if not args.no_global_sync:
            sync_global_install(local_source, built_wheel, global_scope)

        if args.install_all_interpreters or install_tokens:
            if not built_wheel:
                print_safe(
                    "[bold yellow]No validated wheel available (PyPI mode). Skipping install into other interpreters.[/bold yellow]"
                )
            else:
                install_into_interpreters(
                    built_wheel,
                    pip_scope,
                    args.install_all_interpreters,
                    install_tokens,
                )

        print_safe("\n[bold green]Install complete.[/bold green]")
        raise SystemExit(0)

    max_attempts = 2 if local_source else 1
    config_filename = "manifestguard.json"

    for attempt in range(1, max_attempts + 1):
        print_safe(f"\n[bold blue]Updating {config_filename}...[/bold blue]")
        init_result = run_manifestguard_init(workspace_root, config_filename)
        print_process_output(init_result)
        init_output = f"{init_result.stdout or ''}{init_result.stderr or ''}"
        init_issues = detect_known_issues(init_output)

        if init_result.returncode != 0 or init_issues:
            if local_source and attempt < max_attempts:
                print_safe(
                    "[bold yellow]Detected issues during init. Reinstalling local build and retrying...[/bold yellow]"
                )
                install_from_local(str(local_source), pip_scope)
                continue

            for issue in init_issues:
                print_safe(f"[bold red]ERROR: {issue}[/bold red]")
            if init_result.returncode != 0:
                print_safe(
                    f"[bold red]init-config failed with exit code {init_result.returncode}.[/bold red]"
                )
                raise SystemExit(init_result.returncode)
            raise SystemExit(1)

        print_safe("\n[bold blue]Running pytest with coverage...[/bold blue]")
        coverage_result = run_pytest_with_coverage(workspace_root)
        print_process_output(coverage_result)

        if coverage_result.returncode != 0:
            if local_source and attempt < max_attempts:
                print_safe(
                    "[bold yellow]Pytest with coverage failed. Reinstalling local build and retrying...[/bold yellow]"
                )
                install_from_local(str(local_source), pip_scope)
                continue

            print_safe(f"[bold red]Pytest failed with exit code {coverage_result.returncode}.[/bold red]")
            raise SystemExit(coverage_result.returncode)

        print_safe("\n[bold blue]Running manifestguard check --extended...[/bold blue]")
        check_result = run_manifestguard_command(workspace_root)
        print_process_output(check_result)
        check_output = f"{check_result.stdout or ''}{check_result.stderr or ''}"
        check_issues = detect_known_issues(check_output)

        if check_result.returncode != 0 or check_issues:
            if local_source and attempt < max_attempts:
                console.print(
                    "[bold yellow]Detected issues during tests. Reinstalling local build and retrying...[/bold yellow]"
                )
                install_from_local(str(local_source), pip_scope)
                continue

            for issue in check_issues:
                print_safe(f"[bold red]ERROR: {issue}[/bold red]")
            if check_result.returncode != 0:
                print_safe(f"[bold red]Checks failed with exit code {check_result.returncode}.[/bold red]")
                raise SystemExit(check_result.returncode)
            raise SystemExit(1)

        print_safe("\n[bold green]All checks passed![/bold green]")
        report_path = workspace_root / "manifestguard-report.json"
        print_safe(f"Detailed report saved to: [bold cyan]{report_path}[/bold cyan]")
        append_ruff_to_report(report_path, collect_ruff_metrics(workspace_root))
        if not args.no_global_sync:
            sync_global_install(local_source, built_wheel, global_scope)

        if args.install_all_interpreters or install_tokens:
            install_into_interpreters(built_wheel, pip_scope, args.install_all_interpreters, install_tokens)
        raise SystemExit(0)

    console.print("[bold red]❌ Unable to complete checks without issues after retries.[/bold red]")
    raise SystemExit(1)
