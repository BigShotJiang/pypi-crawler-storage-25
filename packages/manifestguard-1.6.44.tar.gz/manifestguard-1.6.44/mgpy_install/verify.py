from __future__ import annotations

import contextlib
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Iterator

from .rich_compat import Panel, console, print_process_output, print_safe
from .pip_utils import ensure_python_package


def _workspace_runtime_tmp_root(workspace: Path) -> Path:
    """Return workspace-scoped runtime tmp root for install verification artifacts.

    This keeps temporary data isolated per workspace even when mgpy is installed
    user-wide and multiple installs/verifications run in parallel from different
    directories.
    """
    return workspace / ".mgpy" / "tmp" / "install-preserve"


def _allocate_preserve_backup_root(workspace: Path) -> Path:
    """Allocate unique backup root with deterministic workspace isolation."""
    base_root = _workspace_runtime_tmp_root(workspace)
    workspace_id = hashlib.sha1(str(workspace.resolve()).encode("utf-8")).hexdigest()[:12]
    run_id = f"{os.getpid()}-{uuid.uuid4().hex}"
    backup_root = base_root / workspace_id / run_id
    backup_root.mkdir(parents=True, exist_ok=True)
    return backup_root


def run_manifestguard_init(workspace: Path, output_filename: str) -> subprocess.CompletedProcess[str]:
    command = [
        sys.executable,
        "-m",
        "manifestguard",
        "init-config",
        "--merge",
        "--output",
        output_filename,
    ]
    return subprocess.run(
        command,
        cwd=workspace,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )


def load_coverage_sources(workspace: Path) -> list[str]:
    pyproject = workspace / "pyproject.toml"
    if not pyproject.exists():
        return []

    try:
        import tomllib  # type: ignore[attr-defined]
    except ModuleNotFoundError:  # pragma: no cover
        ensure_python_package("tomli")
        import tomli as tomllib  # type: ignore[no-redef]

    try:
        with pyproject.open("rb") as handle:
            data = tomllib.load(handle)
    except Exception:  # pragma: no cover
        return []

    tool_section = data.get("tool") if isinstance(data, dict) else None
    if not isinstance(tool_section, dict):
        return []

    coverage_section = tool_section.get("coverage")
    if not isinstance(coverage_section, dict):
        return []

    run_section = coverage_section.get("run")
    if not isinstance(run_section, dict):
        return []

    sources = run_section.get("source")
    if isinstance(sources, str):
        return [sources]
    if isinstance(sources, list):
        return [str(item) for item in sources if isinstance(item, str) and item.strip()]
    return []


def run_pytest_with_coverage(workspace: Path) -> subprocess.CompletedProcess[str]:
    ensure_python_package("pytest")
    ensure_python_package("pytest-cov", "pytest_cov")

    coverage_sources = load_coverage_sources(workspace)
    if not coverage_sources:
        coverage_sources = ["src/manifestguard"]

    command: list[str] = [sys.executable, "-m", "pytest"]
    for source in coverage_sources:
        command.append(f"--cov={source}")
    command.extend(["--cov-report=json:coverage.json", "--cov-report=xml", "--cov-report=term"])

    log_dir = workspace / ".manifestguard"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "pytest-coverage.log"

    output_chunks: list[str] = []
    try:
        with log_path.open("w", encoding="utf-8", errors="replace") as log_file:
            process = subprocess.Popen(
                command,
                cwd=workspace,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )

            assert process.stdout is not None
            for line in process.stdout:
                log_file.write(line)
                log_file.flush()
                try:
                    console.print(line.rstrip("\n"))
                except Exception:
                    print(line, end="")

                output_chunks.append(line)
                if len(output_chunks) > 2000:
                    output_chunks = output_chunks[-1000:]

            returncode = process.wait()

        combined_output = "".join(output_chunks)
        return subprocess.CompletedProcess(args=command, returncode=returncode, stdout=combined_output, stderr="")
    except KeyboardInterrupt:
        console.print(
            f"\n[bold yellow]⛔ Pytest interrupted by user. Log: [cyan]{log_path}[/cyan][/bold yellow]"
        )
        raise


def compute_file_hash(path: Path) -> str | None:
    import hashlib

    try:
        if not path.exists():
            return None
        if path.is_dir():
            entries = sorted(str(p.relative_to(path)) for p in path.rglob("*") if p.is_file())
            content = "\n".join(entries).encode("utf-8")
        else:
            content = path.read_bytes()
        return hashlib.sha256(content).hexdigest()
    except Exception:
        return None


def verify_paths_unchanged(
    workspace: Path,
    preserved_paths: list[str],
    before_hashes: dict[str, str | None],
    step: str,
    *,
    raise_on_change: bool = False,
) -> None:
    changes: list[str] = []
    for rel in preserved_paths:
        current = workspace / rel
        before = before_hashes.get(rel)
        after = compute_file_hash(current)
        if before != after:
            changes.append(
                f"  • {rel}: {before[:8] if before else 'missing'} → {after[:8] if after else 'missing'}"
            )

    if changes:
        console.print(f"[bold yellow]Configuration changed after {step}:[/bold yellow]")
        for change in changes:
            console.print(f"[yellow]{change}[/yellow]")

        if raise_on_change:
            raise RuntimeError("Preserved paths changed after " + step + ":\n" + "\n".join(changes))


def force_remove_path(path: Path) -> None:
    def _rmtree_onerror(func, p, exc_info):  # pragma: no cover
        try:
            os.chmod(p, stat.S_IWRITE)
        except Exception:
            pass
        try:
            func(p)
        except Exception:
            pass

    for attempt in range(5):
        try:
            if not path.exists():
                return

            if path.is_dir():
                shutil.rmtree(path, onerror=_rmtree_onerror)
            else:
                try:
                    path.chmod(0o666)
                except Exception:
                    pass
                path.unlink()
            return
        except Exception:
            if attempt >= 4:
                raise
            time.sleep(0.15 * (attempt + 1))


def run_manifestguard_command(workspace: Path) -> subprocess.CompletedProcess[str]:
    report_path = workspace / "manifestguard-report.json"
    command = [
        sys.executable,
        "-m",
        "manifestguard",
        "check",
        "--extended",
        "--report",
        str(report_path),
        "--verbose",
    ]

    preserved_paths = [
        ".manifestguard-history.json",
        ".manifestguard/metrics-history.json",
        ".manifestguard/recommendation-acks.json",
        ".manifestguard/baselines",
    ]

    def _run_streaming() -> subprocess.CompletedProcess[str]:
        proc = subprocess.Popen(
            command,
            cwd=workspace,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert proc.stdout is not None

        chunks: list[str] = []
        try:
            for line in proc.stdout:
                chunks.append(line)
                console.print(line.rstrip("\n"))
        finally:
            try:
                proc.stdout.close()
            except Exception:
                pass

        rc = proc.wait()
        return subprocess.CompletedProcess(args=command, returncode=rc, stdout="".join(chunks), stderr="")

    @contextlib.contextmanager
    def _preserve_paths() -> Iterator[None]:
        console.print("[dim]📸 Capturing configuration snapshot...[/dim]")
        initial_hashes = {rel: compute_file_hash(workspace / rel) for rel in preserved_paths}

        backup_root = _allocate_preserve_backup_root(workspace)
        existed: dict[str, bool] = {}
        try:
            for rel in preserved_paths:
                src = workspace / rel
                existed[rel] = src.exists()
                if not src.exists():
                    continue

                dest = backup_root / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                if src.is_dir():
                    shutil.copytree(src, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(src, dest)

            console.print("[dim]✅ Configuration backed up[/dim]")
            yield

            console.print("[dim]🔍 Verifying configuration integrity...[/dim]")
            verify_paths_unchanged(workspace, preserved_paths, initial_hashes, "extended check")

        finally:
            console.print("[dim]♻️  Restoring configuration...[/dim]")
            for rel, did_exist in existed.items():
                current = workspace / rel
                backup = backup_root / rel

                if not did_exist:
                    if current.exists():
                        force_remove_path(current)
                    continue

                if current.exists():
                    force_remove_path(current)

                if backup.exists():
                    current.parent.mkdir(parents=True, exist_ok=True)
                    if backup.is_dir():
                        shutil.copytree(backup, current, dirs_exist_ok=True)
                    else:
                        shutil.copy2(backup, current)

            shutil.rmtree(backup_root, ignore_errors=True)

            verify_paths_unchanged(workspace, preserved_paths, initial_hashes, "restore", raise_on_change=True)
            console.print("[dim]✅ Configuration restored and verified[/dim]")

    with _preserve_paths():
        return _run_streaming()


def collect_ruff_metrics(workspace: Path) -> dict | None:
    try:
        ensure_python_package("ruff")

        ver_proc = subprocess.run(
            [sys.executable, "-m", "ruff", "--version"],
            cwd=workspace,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        version = (ver_proc.stdout or ver_proc.stderr or "").strip()

        chk_proc = subprocess.run(
            [
                sys.executable,
                "-m",
                "ruff",
                "check",
                "--output-format",
                "json",
                "--exit-zero",
                str(workspace),
            ],
            cwd=workspace,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )

        diagnostics: list = []
        out = chk_proc.stdout.strip()
        if out:
            try:
                diagnostics = json.loads(out)
            except json.JSONDecodeError:
                diagnostics = []

        issue_count = len(diagnostics) if isinstance(diagnostics, list) else 0
        code_freq: dict[str, int] = {}
        files: set[str] = set()
        for d in diagnostics:
            code = d.get("code") if isinstance(d, dict) else None
            if isinstance(code, str):
                code_freq[code] = code_freq.get(code, 0) + 1
            filename = d.get("filename") if isinstance(d, dict) else None
            if isinstance(filename, str):
                files.add(filename)

        top_codes = sorted(code_freq.items(), key=lambda kv: kv[1], reverse=True)[:5]
        return {
            "source": "ruff",
            "version": version,
            "issue_count": issue_count,
            "files_scanned": len(files),
            "top_codes": [{"code": c, "count": n} for c, n in top_codes],
        }
    except Exception:
        return None


def append_ruff_to_report(report_path: Path, metrics: dict | None) -> None:
    if not metrics or not report_path.exists():
        return
    try:
        content = report_path.read_text(encoding="utf-8")
        data = json.loads(content) if content.strip() else {}
        quality = data.get("quality")
        if not isinstance(quality, dict):
            quality = {}
            data["quality"] = quality
        quality["ruff"] = metrics
        report_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


def detect_known_issues(output: str) -> list[str]:
    issues: list[str] = []
    lowered = output.lower()
    if "i18n key missing" in lowered:
        issues.append("Missing i18n translation keys detected")
    return issues


__all__ = [
    "append_ruff_to_report",
    "collect_ruff_metrics",
    "detect_known_issues",
    "print_process_output",
    "print_safe",
    "run_manifestguard_command",
    "run_manifestguard_init",
    "run_pytest_with_coverage",
]
