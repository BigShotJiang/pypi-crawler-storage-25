from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from .rich_compat import Panel, console
from .types import GlobalInstallScope, PipInstallScope
from .pip_utils import ensure_python_package, get_manifestguard_command_path, get_manifestguard_version, get_user_scripts_dir, pip_install_command, resolve_global_python, resolve_path_manifestguard_python


def _recompile_after_install(python_exe: str) -> None:
    """Force-recompile all manifestguard .pyc files after install to prevent stale cache issues."""
    try:
        result = subprocess.run(
            [python_exe, "-c",
             "import manifestguard, pathlib; print(pathlib.Path(manifestguard.__file__).parent)"],
            capture_output=True, text=True, check=False,
        )
        pkg_dir = result.stdout.strip()
        if pkg_dir:
            subprocess.run(
                [python_exe, "-m", "compileall", "-q", "-f", pkg_dir],
                capture_output=True, check=False,
            )
    except Exception:
        pass  # Best-effort; never block the install


def find_built_wheel(source_dir: Path, version: str) -> Path | None:
    """Find locally built wheel matching the requested version."""
    dist_dir = source_dir / "dist"
    if not dist_dir.exists():
        return None

    candidates = sorted(dist_dir.glob("manifestguard-*.whl"))
    for wheel in reversed(candidates):
        if version in wheel.name:
            return wheel
    return candidates[-1] if candidates else None


def install_from_local(dev_path: str, pip_scope: PipInstallScope) -> Path:
    """Build & install ManifestGuard from a local development directory."""
    mgpy = Path(dev_path).resolve()

    if not mgpy.exists():
        console.print(f"[bold red]Path not found:[/bold red] {mgpy}")
        raise SystemExit(1)

    if not (mgpy / "pyproject.toml").exists():
        console.print(f"[bold red]Not a Python project:[/bold red] {mgpy}")
        raise SystemExit(1)

    console.print(f"Building ManifestGuard from: [cyan]{mgpy}[/cyan]")

    build_dir = mgpy / "build"
    if build_dir.exists():
        console.print("Removing previous build artifacts...")
        shutil.rmtree(build_dir)

    dist_dir = mgpy / "dist"
    if dist_dir.exists():
        console.print("Removing previous dist artifacts...")
        shutil.rmtree(dist_dir)

    ensure_python_package("build")

    try:
        with console.status("[bold green]Building wheel...", spinner="dots"):
            subprocess.run(
                [sys.executable, "-m", "build", "--wheel"],
                cwd=mgpy,
                check=True,
                capture_output=True,
            )

        with console.status("[bold green]Installing wheel...", spinner="dots"):
            wheels = list(dist_dir.glob("*.whl"))
            if not wheels:
                console.print("[bold red]No wheel found after build.[/bold red]")
                raise SystemExit(1)

            wheel = max(wheels, key=lambda path: path.stat().st_mtime)
            install_cmd = pip_install_command(
                sys.executable,
                pip_scope,
                "install",
                "--force-reinstall",
                str(wheel),
            )
            subprocess.run(install_cmd, check=True, capture_output=True)

        console.print(f"Installed: [bold yellow]{wheel.name}[/bold yellow]")
        _recompile_after_install(sys.executable)
        return wheel

    except subprocess.CalledProcessError as exc:
        error_panel = Panel(
            f"[bold]Command:[/bold] {' '.join(exc.cmd)}\n"
            f"[bold]Exit Code:[/bold] {exc.returncode}\n\n"
            f"[bold]Stderr:[/bold]\n{(exc.stderr or '').strip()}",
            title="[bold red]Build/Install Failed[/bold red]",
            border_style="red",
        )
        console.print(error_panel)
        raise SystemExit(1)
    finally:
        if build_dir.exists():
            shutil.rmtree(build_dir, ignore_errors=True)


def _collect_sync_targets(base_python: str | None) -> list[str]:
    """Collect global sync targets.

    ManifestGuard is intended to have one canonical global install. When running
    from the repo venv, that canonical target is the base interpreter (py312 in
    this workspace), not whatever foreign interpreter currently happens to own a
    global `manifestguard` launcher in PATH.
    """
    if not base_python:
        return []
    return [base_python]


def _get_windows_shim_dir() -> Path:
    """Return the dedicated user-level shim directory for ManifestGuard commands."""
    appdata = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    return Path(appdata) / "ManifestGuard" / "shims"


def _write_windows_command_shims(python_exe: str, global_scope: GlobalInstallScope) -> str | None:
    """Create cmd shims that bind global manifestguard commands to the base Python.

    This bypasses flaky pip-generated .exe launchers on Windows while keeping the
    user-facing command name unchanged. We write both cmd and PowerShell shims so
    PowerShell sessions can resolve a script before later .exe launchers on PATH.
    """
    if sys.platform != "win32" or global_scope != "user":
        return None

    shim_version = "1.0.0"
    shim_dir = _get_windows_shim_dir()
    try:
        shim_dir.mkdir(parents=True, exist_ok=True)
        manifestguard_cmd = (
            "@echo off\r\n"
            f"REM R4IT_MGPY_SHIM_VERSION: {shim_version}\r\n"
            f'"{python_exe}" -m manifestguard %*\r\n'
        )
        manifestguard_gui_cmd = (
            "@echo off\r\n"
            f"REM R4IT_MGPY_SHIM_VERSION: {shim_version}\r\n"
            f'"{python_exe}" -m manifestguard.gui %*\r\n'
        )
        manifestguard_ps1 = (
            f'# R4IT_MGPY_SHIM_VERSION: {shim_version}\r\n'
            f'& "{python_exe}" -m manifestguard @args\r\n'
        )
        manifestguard_gui_ps1 = (
            f'# R4IT_MGPY_SHIM_VERSION: {shim_version}\r\n'
            f'& "{python_exe}" -m manifestguard.gui @args\r\n'
        )
        (shim_dir / "manifestguard.cmd").write_text(manifestguard_cmd, encoding="ascii")
        (shim_dir / "manifestguard-gui.cmd").write_text(manifestguard_gui_cmd, encoding="ascii")
        (shim_dir / "manifestguard.ps1").write_text(manifestguard_ps1, encoding="ascii")
        (shim_dir / "manifestguard-gui.ps1").write_text(manifestguard_gui_ps1, encoding="ascii")
    except OSError:
        return None

    return str(shim_dir)


def _ensure_user_scripts_preferred(python_exe: str, global_scope: GlobalInstallScope) -> None:
    """Ensure the preferred ManifestGuard command location comes first on user PATH.

    On Windows we prefer a dedicated shim directory whose wrappers invoke the
    base interpreter directly. This avoids broken pip-generated .exe launchers.
    On other platforms we fall back to the interpreter's user Scripts/bin dir.
    Changes apply to future shells; current shells must be reopened or refreshed.
    """
    if global_scope != "user":
        return

    preferred_dir = _write_windows_command_shims(python_exe, global_scope) if sys.platform == "win32" else None
    if not preferred_dir:
        preferred_dir = get_user_scripts_dir(python_exe)
    if not preferred_dir:
        return

    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ) as key:
            current_user_path, reg_type = winreg.QueryValueEx(key, "Path")
    except FileNotFoundError:
        current_user_path = ""
        reg_type = 1
    except OSError:
        return

    parts = [p for p in current_user_path.split(os.pathsep) if p]
    normalized_target = str(Path(preferred_dir).resolve()).lower()
    filtered_parts: list[str] = []
    seen: set[str] = set()

    for part in parts:
        normalized = str(Path(part).resolve()).lower() if Path(part).exists() else part.lower()
        if normalized == normalized_target:
            continue
        if normalized in seen:
            continue
        seen.add(normalized)
        filtered_parts.append(part)

    new_parts = [preferred_dir, *filtered_parts]
    new_user_path = os.pathsep.join(new_parts)
    if new_user_path == current_user_path:
        if sys.platform == "win32":
            console.print(
                "pip install succeeded, but the active [cyan]manifestguard[/cyan] command depends on current shell PATH resolution."
            )
            console.print(
                "PowerShell note: verify [cyan]manifestguard[/cyan] with "
                "[bold]Get-Command manifestguard[/bold], not [bold]where.exe manifestguard[/bold]."
            )
            console.print(
                "If this terminal still resolves the old command, refresh session PATH with:\n"
                "  [bold]$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')[/bold]"
            )
            console.print(
                "If the old command is still active: [bold yellow]Close this terminal and start a new one.[/bold yellow]"
            )
        return

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "Path", 0, reg_type, new_user_path)
        console.print(
            f"Updated user PATH to prefer [cyan]{preferred_dir}[/cyan]. Open a new terminal so global manifestguard resolves to this interpreter."
        )
        console.print(
            "pip install succeeded, but the active [cyan]manifestguard[/cyan] command depends on current shell PATH resolution."
        )
        console.print(
            "PowerShell note: verify [cyan]manifestguard[/cyan] with "
            "[bold]Get-Command manifestguard[/bold], not [bold]where.exe manifestguard[/bold]."
        )
        console.print(
            "If this terminal still resolves the old command, refresh session PATH with:\n"
            "  [bold]$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')[/bold]"
        )
        console.print(
            "If the old command is still active: [bold yellow]Close this terminal and start a new one.[/bold yellow]"
        )
    except OSError:
        return


def _warn_if_foreign_manifestguard_on_path(base_python: str) -> None:
    """Warn if the currently PATH-visible global manifestguard belongs to another Python."""
    path_python = resolve_path_manifestguard_python()
    if not path_python:
        return
    try:
        if Path(path_python).resolve() == Path(base_python).resolve():
            return
    except OSError:
        return

    console.print(
        Panel(
            f"Base Python: {base_python}\n"
            f"PATH manifestguard owner: {path_python}\n\n"
            "ManifestGuard is configured to use one canonical global install. "
            "The installer will keep the base Python in sync and move its user Scripts directory ahead on PATH.",
            title="[bold yellow]Global ManifestGuard PATH Warning[/bold yellow]",
            border_style="yellow",
        )
    )


def sync_global_install(
    local_source: Path | None,
    built_wheel: Path | None,
    global_scope: GlobalInstallScope,
) -> None:
    """Ensure all relevant global Python installs pick up the validated manifestguard build."""
    base_python = resolve_global_python()
    sync_targets = _collect_sync_targets(base_python)
    if not sync_targets:
        console.print("ℹ️ No separate global Python interpreter detected; skipping global sync.")
        return

    _warn_if_foreign_manifestguard_on_path(sync_targets[0])

    for global_python in sync_targets:
        _sync_one_interpreter(global_python, local_source, built_wheel, global_scope)

    _ensure_user_scripts_preferred(sync_targets[0], global_scope)


def _sync_one_interpreter(
    global_python: str,
    local_source: Path | None,
    built_wheel: Path | None,
    global_scope: GlobalInstallScope,
) -> None:
    """Sync manifestguard into a single global Python interpreter."""
    global_install_args: list[str] = []
    if global_scope == "user":
        global_install_args.append("--user")

    if built_wheel and built_wheel.exists():
        expected_version = get_manifestguard_version(sys.executable)
        console.print(f"Installing validated wheel globally via: [cyan]{global_python}[/cyan]")
        command = [
            global_python,
            "-m",
            "pip",
            "install",
            *global_install_args,
            "--upgrade",
            "--force-reinstall",
            str(built_wheel),
        ]

        result = subprocess.run(command, capture_output=True, text=True, check=False)
        if result.returncode == 0:
            _recompile_after_install(global_python)
            post_version = get_manifestguard_version(global_python)
            command_path = get_manifestguard_command_path(global_python, global_scope)
            if expected_version and post_version and post_version != expected_version:
                console.print(
                    Panel(
                        f"[bold]Expected version:[/bold] {expected_version}\n"
                        f"[bold]Global version:[/bold] {post_version}\n\n"
                        f"[bold]Command:[/bold] {' '.join(command)}\n\n"
                        f"[bold]Stdout:[/bold]\n{result.stdout.strip()}\n\n"
                        f"[bold]Stderr:[/bold]\n{result.stderr.strip()}",
                        title="[bold yellow]Global Sync Verification Warning[/bold yellow]",
                        border_style="yellow",
                    )
                )
            else:
                console.print("Global ManifestGuard installation updated (validated wheel).")
                if command_path:
                    console.print(f"Global command path: [cyan]{command_path}[/cyan]")
        else:
            console.print(
                Panel(
                    f"[bold]Command:[/bold] {' '.join(command)}\n"
                    f"[bold]Exit Code:[/bold] {result.returncode}\n\n"
                    f"[bold]Stdout:[/bold]\n{result.stdout.strip()}\n\n"
                    f"[bold]Stderr:[/bold]\n{result.stderr.strip()}",
                    title="[bold red]Global Sync Failed[/bold red]",
                    border_style="red",
                )
            )
        return

    current_version = get_manifestguard_version(sys.executable)
    if not current_version:
        console.print("Unable to determine current manifestguard version; skipping global sync.")
        return

    global_version = get_manifestguard_version(global_python)
    if global_version == current_version:
        console.print(f"Global ManifestGuard already at version [cyan]{current_version}[/cyan].")
        return

    console.print(
        f"Updating global ManifestGuard from [yellow]{global_version or 'unknown'}[/yellow]"
        f" to [cyan]{current_version}[/cyan]..."
    )

    if local_source:
        wheel_path = find_built_wheel(local_source, current_version)
        install_args = [str(wheel_path)] if wheel_path and wheel_path.exists() else [f"manifestguard=={current_version}"]
    else:
        install_args = [f"manifestguard=={current_version}"]

    command = [
        global_python,
        "-m",
        "pip",
        "install",
        *global_install_args,
        "--upgrade",
        "--force-reinstall",
        *install_args,
    ]
    result = subprocess.run(command, capture_output=True, text=True, check=False)

    if result.returncode == 0:
        _recompile_after_install(global_python)
        console.print("Global ManifestGuard installation synchronized.")
        command_path = get_manifestguard_command_path(global_python, global_scope)
        if command_path:
            console.print(f"Global command path: [cyan]{command_path}[/cyan]")
    else:
        console.print(
            Panel(
                f"[bold]Command:[/bold] {' '.join(command)}\n"
                f"[bold]Exit Code:[/bold] {result.returncode}\n\n"
                f"[bold]Stdout:[/bold]\n{result.stdout.strip()}\n\n"
                f"[bold]Stderr:[/bold]\n{result.stderr.strip()}",
                title="[bold red]Global Sync Failed[/bold red]",
                border_style="red",
            )
        )
