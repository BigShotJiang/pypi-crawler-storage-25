from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

from .pip_utils import get_manifestguard_command_path
from .rich_compat import Panel, console
from .types import PipInstallScope


def is_interpreter_venv(python_executable: str) -> bool:
    """Return True if the provided interpreter appears to be running inside a venv."""
    try:
        result = subprocess.run(
            [
                python_executable,
                "-c",
                "import sys;print(int(sys.prefix != getattr(sys,'base_prefix', sys.prefix)))",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip() == "1"
    except Exception:
        return False


def resolve_interpreter_from_token(token: str) -> str | None:
    """Resolve a token provided by the user to an interpreter executable path."""
    candidate = Path(token)
    if candidate.exists():
        return str(candidate.resolve())

    if sys.platform.startswith("win") and token.count(".") == 1:
        try:
            proc = subprocess.run(
                ["py", f"-{token}", "-c", "import sys;print(sys.executable)"],
                capture_output=True,
                text=True,
                check=True,
            )
            path = proc.stdout.strip()
            if path:
                return path
        except Exception:
            pass

    which = shutil.which(token)
    if which:
        return which

    return None


def discover_installed_interpreters_windows() -> list[str]:
    """Discover installed interpreters via the `py -0p` launcher on Windows."""
    interpreters: list[str] = []
    try:
        proc = subprocess.run(["py", "-0p"], capture_output=True, text=True, check=True)
        for line in proc.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            token = line.split()[-1]
            if Path(token).exists():
                interpreters.append(str(Path(token).resolve()))
    except Exception:
        pass
    return interpreters


def detect_interpreters(all_installed: bool, tokens: list[str] | None) -> list[str]:
    """Return a list of interpreter executables to target for installation."""
    results: list[str] = []

    if tokens:
        for t in tokens:
            t = t.strip()
            if not t:
                continue
            resolved = resolve_interpreter_from_token(t)
            if resolved and Path(resolved).exists():
                if resolved not in results and str(Path(resolved).resolve()) != str(Path(sys.executable).resolve()):
                    results.append(resolved)
        return results

    if all_installed:
        if sys.platform.startswith("win"):
            results = discover_installed_interpreters_windows()
        else:
            for major in range(3, 4):
                for minor in range(5, 14):
                    name = f"python{major}.{minor}"
                    path = shutil.which(name)
                    if path and path not in results:
                        results.append(path)

        results = [r for r in results if str(Path(r).resolve()) != str(Path(sys.executable).resolve())]

    return results


def default_extra_interpreters(base_python: str | None) -> list[str]:
    """Return additional non-base interpreters that should also receive mgpy.

    Primary global support remains the base interpreter (py312 in this workspace),
    but on Windows we also keep other installed interpreters such as py313 in sync
    so `python -m manifestguard` works there as well.
    """
    results = detect_interpreters(all_installed=True, tokens=None)
    if not results:
        return []

    excluded: set[str] = {str(Path(sys.executable).resolve())}
    if base_python:
        excluded.add(str(Path(base_python).resolve()))

    extras: list[str] = []
    seen: set[str] = set()
    for interp in results:
        resolved = str(Path(interp).resolve())
        if resolved in excluded or resolved in seen:
            continue
        seen.add(resolved)
        extras.append(interp)
    return extras


def install_wheel_into_interpreter(
    python_executable: str,
    wheel: Path,
    pip_scope: PipInstallScope,
) -> tuple[bool, str]:
    """Install the given wheel into the provided interpreter."""
    resolved_scope = pip_scope
    if pip_scope == "auto":
        resolved_scope = "current" if is_interpreter_venv(python_executable) else "user"

    cmd = [python_executable, "-m", "pip", "install", "--force-reinstall", str(wheel)]
    if resolved_scope == "user":
        cmd.insert(4, "--user")

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode == 0:
            command_path = get_manifestguard_command_path(python_executable, resolved_scope)
            if command_path:
                return True, f"Installed via {python_executable} ({resolved_scope}); command path: {command_path}"
            return True, f"Installed via {python_executable} ({resolved_scope})"
        return False, f"Failed ({proc.returncode}): {proc.stderr.strip()}"
    except FileNotFoundError:
        return False, "Interpreter not found"
    except Exception as exc:
        return False, str(exc)


def install_into_interpreters(
    wheel: Path | None,
    pip_scope: PipInstallScope,
    all_installed: bool,
    tokens: list[str] | None,
) -> None:
    """Install the validated wheel (or PyPI package) into additional interpreters."""
    if not wheel and not tokens:
        console.print("ℹ️ No built wheel available and no interpreters specified; skipping extra installs.")
        return

    interpreters = detect_interpreters(all_installed, tokens)
    if not interpreters:
        console.print("ℹ️ No target interpreters discovered; skipping extra installs.")
        return

    for interp in interpreters:
        console.print(f"🔁 Installing into: [cyan]{interp}[/cyan]")
        if wheel and wheel.exists():
            success, msg = install_wheel_into_interpreter(interp, wheel, pip_scope)
        else:
            pkg_cmd = [interp, "-m", "pip", "install", "--upgrade", "manifestguard"]
            if pip_scope == "user" or (pip_scope == "auto" and not is_interpreter_venv(interp)):
                pkg_cmd.insert(4, "--user")
            try:
                proc = subprocess.run(pkg_cmd, capture_output=True, text=True, check=False)
                success = proc.returncode == 0
                msg = proc.stderr.strip() if not success else "Installed from PyPI"
            except Exception as exc:
                success = False
                msg = str(exc)

        if success:
            try:
                from .install import _recompile_after_install

                _recompile_after_install(interp)
            except Exception:
                pass
            console.print(f"✅ {msg}")
        else:
            console.print(
                Panel(
                    f"{msg}",
                    title=f"[bold red]Install failed: {interp}[/bold red]",
                    border_style="red",
                )
            )
