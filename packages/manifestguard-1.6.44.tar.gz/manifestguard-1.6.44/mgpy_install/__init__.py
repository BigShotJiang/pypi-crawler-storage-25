"""Internal helpers for run_mgpy_install.py.

This package is intentionally not part of the public manifestguard API.
"""

from .cli import main

__all__ = ["main"]
