"""Interface Discovery API for ManifestGuard.

Provides machine-readable interface information for external tools,
AI assistants, and integration testing.
"""

import inspect
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, get_type_hints


class InterfaceType(Enum):
    """Type of interface."""

    CLI_COMMAND = "cli_command"
    API_METHOD = "api_method"
    FUNCTION = "function"


@dataclass
class Parameter:
    """Function/method parameter information."""

    name: str
    type: str
    default: Any | None = None
    required: bool = True
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "type": self.type,
            "default": str(self.default) if self.default is not inspect.Parameter.empty else None,
            "required": self.required,
            "description": self.description,
        }


@dataclass
class InterfaceDefinition:
    """Complete interface definition."""

    name: str
    type: InterfaceType
    description: str
    parameters: list[Parameter] = field(default_factory=list)
    return_type: str = "None"
    examples: list[dict[str, str]] = field(default_factory=list)
    category: str = "general"
    deprecated: bool = False
    since_version: str = "0.2.0"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "type": self.type.value,
            "description": self.description,
            "parameters": [p.to_dict() for p in self.parameters],
            "return_type": self.return_type,
            "examples": self.examples,
            "category": self.category,
            "deprecated": self.deprecated,
            "since_version": self.since_version,
        }


class InterfaceDiscovery:
    """Interface Discovery API.

    Provides machine-readable information about all available
    ManifestGuard interfaces (CLI commands, API methods, functions).
    """

    def __init__(self):
        """Initialize interface discovery."""
        self._interfaces: dict[str, InterfaceDefinition] = {}
        self._load_builtin_interfaces()

    def _load_builtin_interfaces(self) -> None:
        """Load built-in interface definitions."""
        # CLI Commands
        self.register(
            InterfaceDefinition(
                name="check",
                type=InterfaceType.CLI_COMMAND,
                description="Validate manifest files with optional extended analysis",
                category="validation",
                parameters=[
                    Parameter(
                        "file",
                        "Path",
                        default="pyproject.toml",
                        required=False,
                        description="Path to manifest file",
                    ),
                    Parameter(
                        "extended",
                        "bool",
                        default=True,
                        required=False,
                        description="Run extended test mode",
                    ),
                    Parameter(
                        "report",
                        "Path",
                        default=None,
                        required=False,
                        description="Save metrics to JSON report",
                    ),
                ],
                return_type="int",
                examples=[
                    {
                        "command": "manifestguard check",
                        "description": "Check pyproject.toml in current directory",
                    },
                    {
                        "command": "manifestguard check setup.py --report metrics.json",
                        "description": "Check setup.py and save report",
                    },
                ],
            )
        )

        self.register(
            InterfaceDefinition(
                name="fix",
                type=InterfaceType.CLI_COMMAND,
                description="Fix detected issues automatically",
                category="remediation",
                parameters=[
                    Parameter(
                        "auto",
                        "bool",
                        default=False,
                        required=False,
                        description="Apply fixes without confirmation",
                    ),
                ],
                return_type="int",
                examples=[
                    {"command": "manifestguard fix", "description": "Interactive fix mode"},
                    {"command": "manifestguard fix --auto", "description": "Auto-fix all issues"},
                ],
            )
        )

        self.register(
            InterfaceDefinition(
                name="sbom",
                type=InterfaceType.CLI_COMMAND,
                description="Generate Software Bill of Materials",
                category="security",
                parameters=[
                    Parameter(
                        "format",
                        "str",
                        default="spdx",
                        required=False,
                        description="SBOM format (spdx, cyclonedx)",
                    ),
                    Parameter(
                        "output",
                        "Path",
                        default="sbom.json",
                        required=False,
                        description="Output file path",
                    ),
                ],
                return_type="int",
                examples=[
                    {
                        "command": "manifestguard sbom",
                        "description": "Generate SPDX SBOM",
                    },
                    {
                        "command": "manifestguard sbom --format cyclonedx --output bill.json",
                        "description": "CycloneDX format",
                    },
                ],
            )
        )

        self.register(
            InterfaceDefinition(
                name="baseline",
                type=InterfaceType.CLI_COMMAND,
                description="Manage metric baselines for trend analysis",
                category="analysis",
                parameters=[
                    Parameter(
                        "list",
                        "bool",
                        default=False,
                        required=False,
                        description="List all baselines",
                    ),
                    Parameter(
                        "compare",
                        "str",
                        default=None,
                        required=False,
                        description="Compare to baseline label",
                    ),
                    Parameter(
                        "trend",
                        "bool",
                        default=False,
                        required=False,
                        description="Show trend report",
                    ),
                ],
                return_type="int",
                examples=[
                    {
                        "command": "manifestguard baseline --list",
                        "description": "List all saved baselines",
                    },
                    {
                        "command": "manifestguard baseline --compare v1.0",
                        "description": "Compare against v1.0 baseline",
                    },
                ],
            )
        )

        self.register(
            InterfaceDefinition(
                name="list-interfaces",
                type=InterfaceType.CLI_COMMAND,
                description="List all available CLI commands and options (AI Interface Discovery)",
                category="meta",
                parameters=[],
                return_type="int",
                examples=[
                    {
                        "command": "manifestguard list-interfaces",
                        "description": "Show all interfaces as JSON",
                    },
                ],
            )
        )

        self.register(
            InterfaceDefinition(
                name="list-tests",
                type=InterfaceType.CLI_COMMAND,
                description="List all available test categories and checks",
                category="meta",
                parameters=[
                    Parameter(
                        "json", "bool", default=False, required=False, description="Output as JSON"
                    ),
                ],
                return_type="int",
                examples=[
                    {"command": "manifestguard list-tests", "description": "Show all tests"},
                    {"command": "manifestguard list-tests --json", "description": "JSON output"},
                ],
            )
        )

        self.register(
            InterfaceDefinition(
                name="show-config",
                type=InterfaceType.CLI_COMMAND,
                description="Show effective configuration with defaults",
                category="configuration",
                parameters=[
                    Parameter(
                        "json", "bool", default=False, required=False, description="Output as JSON"
                    ),
                ],
                return_type="int",
                examples=[
                    {"command": "manifestguard show-config", "description": "Show config"},
                    {"command": "manifestguard show-config --json", "description": "JSON format"},
                ],
            )
        )

    def register(self, interface: InterfaceDefinition) -> None:
        """Register an interface definition.

        Args:
            interface: Interface definition to register

        """
        self._interfaces[interface.name] = interface

    def get(self, name: str) -> InterfaceDefinition | None:
        """Get interface definition by name.

        Args:
            name: Interface name

        Returns:
            Interface definition or None

        """
        return self._interfaces.get(name)

    def list_interfaces(
        self,
        category: str | None = None,
        interface_type: InterfaceType | None = None,
    ) -> list[InterfaceDefinition]:
        """List all registered interfaces.

        Args:
            category: Filter by category (optional)
            interface_type: Filter by type (optional)

        Returns:
            List of interface definitions

        """
        return [
            interface
            for interface in self._interfaces.values()
            if self._matches_filters(interface, category, interface_type)
        ]

    def _matches_filters(
        self,
        interface: InterfaceDefinition,
        category: str | None,
        interface_type: InterfaceType | None,
    ) -> bool:
        if category and interface.category != category:
            return False
        return not (interface_type and interface.type != interface_type)

    def list_categories(self) -> list[str]:
        """Get all unique categories.

        Returns:
            List of category names

        """
        return sorted({i.category for i in self._interfaces.values()})

    def _check_required_params(
        self, interface: InterfaceDefinition, arguments: dict[str, Any]
    ) -> list[str]:
        """Check for missing required parameters."""
        required_params = {p.name for p in interface.parameters if p.required}
        provided_params = set(arguments.keys())
        missing_params = required_params - provided_params
        return (
            [f"Missing required parameters: {', '.join(missing_params)}"] if missing_params else []
        )

    def _check_unknown_params(
        self, interface: InterfaceDefinition, arguments: dict[str, Any]
    ) -> list[str]:
        """Check for unknown parameters."""
        valid_params = {p.name for p in interface.parameters}
        provided_params = set(arguments.keys())
        unknown_params = provided_params - valid_params
        return [f"Unknown parameters: {', '.join(unknown_params)}"] if unknown_params else []

    def _validate_param_type(self, param: Parameter, value: Any) -> str | None:
        """Validate parameter type."""
        expected_type = param.type.lower()
        type_map = {"bool": bool, "int": int, "str": str}

        if expected_type in type_map and not isinstance(value, type_map[expected_type]):
            return f"Parameter '{param.name}' expects {expected_type}, got {type(value).__name__}"
        return None

    def validate_call(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> dict[str, Any]:
        """Validate a call to an interface.

        Args:
            name: Interface name
            arguments: Call arguments

        Returns:
            Validation result with errors/warnings

        """
        interface = self.get(name)

        if not interface:
            return self._interface_not_found(name)

        errors, warnings = self._collect_validation_feedback(interface, arguments)

        return {
            "valid": not errors,
            "errors": errors,
            "warnings": warnings,
        }

    def _interface_not_found(self, name: str) -> dict[str, Any]:
        return {
            "valid": False,
            "errors": [f"Interface '{name}' not found"],
            "warnings": [],
        }

    def _collect_validation_feedback(
        self,
        interface: InterfaceDefinition,
        arguments: dict[str, Any],
    ) -> tuple[list[str], list[str]]:
        errors: list[str] = []
        warnings: list[str] = []

        if interface.deprecated:
            warnings.append(f"Interface '{interface.name}' is deprecated")

        errors.extend(self._check_required_params(interface, arguments))
        warnings.extend(self._check_unknown_params(interface, arguments))
        errors.extend(self._collect_type_errors(interface, arguments))

        return errors, warnings

    def _collect_type_errors(
        self,
        interface: InterfaceDefinition,
        arguments: dict[str, Any],
    ) -> list[str]:
        type_errors: list[str] = []
        for param in interface.parameters:
            if param.name not in arguments:
                continue
            error = self._validate_param_type(param, arguments[param.name])
            if error:
                type_errors.append(error)
        return type_errors

    def get_example_call(self, name: str, index: int = 0) -> str | None:
        """Get example call for an interface.

        Args:
            name: Interface name
            index: Example index (default: 0)

        Returns:
            Example command string or None

        """
        interface = self.get(name)

        if not interface or not interface.examples:
            return None

        if index >= len(interface.examples):
            return None

        return interface.examples[index].get("command")

    def to_dict(self) -> dict[str, Any]:
        """Export all interfaces as dictionary.

        Returns:
            Dictionary with all interface definitions

        """
        return {
            "version": "0.3.0",
            "categories": self.list_categories(),
            "interfaces": {
                name: interface.to_dict() for name, interface in self._interfaces.items()
            },
        }

    def to_openapi(self) -> dict[str, Any]:
        """Export interfaces as OpenAPI 3.0 spec.

        Returns:
            OpenAPI specification dictionary

        """
        paths = {
            f"/{name}": path_spec
            for name, interface in self._interfaces.items()
            if (path_spec := self._build_openapi_path(interface))
        }

        return {
            "openapi": "3.0.0",
            "info": {
                "title": "ManifestGuard API",
                "version": "0.3.0",
                "description": "ManifestGuard programmatic interface",
            },
            "paths": paths,
        }

    def _build_openapi_path(self, interface: InterfaceDefinition) -> dict[str, Any] | None:
        if interface.type != InterfaceType.API_METHOD:
            return None

        return {
            "post": {
                "summary": interface.description,
                "tags": [interface.category],
                "requestBody": self._build_request_body(interface),
                "responses": self._build_response_block(interface),
            },
        }

    def _build_request_body(self, interface: InterfaceDefinition) -> dict[str, Any]:
        return {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "properties": {
                            parameter.name: {"type": parameter.type.lower()}
                            for parameter in interface.parameters
                        },
                        "required": [
                            parameter.name
                            for parameter in interface.parameters
                            if parameter.required
                        ],
                    },
                },
            },
        }

    def _build_response_block(self, interface: InterfaceDefinition) -> dict[str, Any]:
        return {
            "200": {
                "description": "Success",
                "content": {
                    "application/json": {
                        "schema": {"type": interface.return_type.lower()},
                    },
                },
            },
        }

    @staticmethod
    def from_function(
        func: Callable,
        category: str = "general",
        description: str | None = None,
    ) -> InterfaceDefinition:
        """Create interface definition from a Python function.

        Args:
            func: Function to analyze
            category: Interface category
            description: Custom description (uses docstring if None)

        Returns:
            Interface definition

        """
        signature_obj = inspect.signature(func)
        type_hints = get_type_hints(func) if hasattr(func, "__annotations__") else {}

        parameters = InterfaceDiscovery._build_parameters(signature_obj, type_hints)
        return_type = InterfaceDiscovery._resolve_return_type(type_hints)
        description_text = InterfaceDiscovery._resolve_description(func, description)

        return InterfaceDefinition(
            name=func.__name__,
            type=InterfaceType.FUNCTION,
            description=description_text.strip(),
            parameters=parameters,
            return_type=return_type,
            category=category,
        )

    @staticmethod
    def _build_parameters(
        signature_obj: inspect.Signature,
        type_hints: dict[str, Any],
    ) -> list[Parameter]:
        parameters: list[Parameter] = []
        for name, parameter in signature_obj.parameters.items():
            if name == "self":
                continue
            parameters.append(
                InterfaceDiscovery._build_parameter(name, parameter, type_hints.get(name, Any)),
            )
        return parameters

    @staticmethod
    def _build_parameter(
        name: str,
        parameter: inspect.Parameter,
        hinted_type: Any,
    ) -> Parameter:
        param_type = getattr(hinted_type, "__name__", None) or getattr(hinted_type, "_name", "Any")
        default = parameter.default if parameter.default is not inspect.Parameter.empty else None
        required = parameter.default is inspect.Parameter.empty
        return Parameter(
            name=name,
            type=param_type or "Any",
            default=default,
            required=required,
            description="",
        )

    @staticmethod
    def _resolve_return_type(type_hints: dict[str, Any]) -> str:
        return_type = type_hints.get("return")
        return getattr(return_type, "__name__", "None") if return_type else "None"

    @staticmethod
    def _resolve_description(func: Callable, description: str | None) -> str:
        if description:
            return description
        if func.__doc__:
            return func.__doc__.split("\n")[0]
        return func.__name__
