"""Quick Check API - ADR-010 Implementation

Provides fast project analysis and test recommendations for Python projects.
Analog to VS Extension QuickCheck API.

Usage:
    from manifestguard.api import QuickCheck

    qc = QuickCheck()
    info = qc.detect_project_type(".")
    tests = qc.recommend_tests(info)
    config = qc.generate_config_template(tests)

Author: Nejat Philip Eryigit
Copyright: (c) 2025 ready-4-it.com
License: Proprietary
"""

import json
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import tomllib

from manifestguard import CONFIG_SCHEMA_VERSION
from manifestguard.api.quick_check_i18n import apply_i18n_hardcoded_gui_strings_settings
from manifestguard.api.quick_check_i18n import apply_i18n_hardcoded_cli_strings_settings

logger = logging.getLogger(__name__)


class ProjectType(Enum):
    """Python project types based on manifest files"""

    PYPROJECT_TOML = "pyproject.toml"
    POETRY = "poetry"
    PIPENV = "pipenv"
    CONDA = "conda"
    SETUP_PY = "setup.py"
    REQUIREMENTS = "requirements.txt"
    UNKNOWN = "unknown"


class RecommendationPriority(Enum):
    """Test recommendation priority levels"""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class ProjectInfo:
    """Project information from detection

    Python Translation of VS Extension ProjectInfo:
    - projectType: PythonProjectType (enum)
    - detectedFeatures: list[str] (CLI, GUI, tests, etc.)
    - manifestPath: Path (pyproject.toml, setup.py, etc.)
    - hasTests: bool
    - hasCLI: bool
    - dependencies: list[str]
    """

    project_type: ProjectType
    root_path: Path
    manifest_path: Path | None = None
    detected_features: set[str] = field(default_factory=set)
    has_tests: bool = False
    has_cli: bool = False
    has_gui: bool = False
    dependencies: list[str] = field(default_factory=list)
    python_version: str | None = None


@dataclass
class TestRecommendation:
    """Test recommendation with priority and reasoning

    Python Translation of VS Extension TestRecommendation:
    - id: str (manifest_check, coverage, etc.)
    - name: str (display name)
    - description: str (what it does)
    - priority: RecommendationPriority (high, medium, low)
    - reason: str (why recommended)
    """

    __test__ = False  # Prevent pytest from attempting to collect this dataclass as a test case
    id: str
    name: str
    description: str
    priority: RecommendationPriority
    reason: str
    enabled: bool = True


@dataclass
class ConfigTemplate:
    """ManifestGuard configuration template

    Python Translation of VS Extension ConfigTemplate:
    - version: str ("1.0")
    - enabled: bool
    - recommendedTests: list[str]
    - settings: dict[str, Any] (thresholds, etc.)
    """

    version: str
    enabled: bool
    recommended_tests: list[str]
    settings: dict[str, Any] = field(default_factory=dict)
    complexity: dict[str, Any] | None = None
    coverage: dict[str, Any] | None = None


class QuickCheck:
    """Quick Check API - Zentrale Klasse für Projekt-Analyse

    ADR-010 Analog Implementation:
    1. detect_project_type() - Like detectProjectType()
    2. recommend_tests() - Like generateTestRecommendations()
    3. generate_config_template() - Like generateConfigTemplate()
    4. merge_configs() - Like mergeConfigs()

    Python Translation Strategy:
    - Use pathlib instead of path module
    - Use tomllib (3.11+) for TOML parsing
    - Use configparser for setup.cfg
    - Use ast module for setup.py (safe, no exec)
    """

    def __init__(self):
        """Initialize QuickCheck API"""
        self.cache: dict[str, Any] = {}

    def detect_project_type(self, project_path: str | Path) -> ProjectInfo:
        """Detect Python project type from manifest files

        Detection Order (VS Extension analog):
        1. pyproject.toml (check for [tool.poetry])
        2. Pipfile (Pipenv)
        3. environment.yml (Conda)
        4. setup.py (legacy)
        5. requirements.txt (minimal)

        Args:
            project_path: Path to project root

        Returns:
            ProjectInfo with detected type and features

        Example:
            >>> qc = QuickCheck()
            >>> info = qc.detect_project_type(".")
            >>> print(info.project_type)
            ProjectType.PYPROJECT_TOML

        """
        path = Path(project_path).resolve()
        detectors: list[tuple[str, Callable[[Path, Path], ProjectInfo]]] = [
            ("pyproject.toml", self._analyze_pyproject),
            ("Pipfile", self._analyze_pipfile),
            ("environment.yml", self._analyze_conda),
            ("setup.py", self._analyze_setup_py),
            ("requirements.txt", self._analyze_requirements),
        ]

        detected = self._run_detection_strategies(path, detectors)
        if detected:
            return detected

        return ProjectInfo(project_type=ProjectType.UNKNOWN, root_path=path)

    def _run_detection_strategies(
        self,
        root: Path,
        detectors: list[tuple[str, Callable[[Path, Path], ProjectInfo]]],
    ) -> ProjectInfo | None:
        for manifest_name, analyzer in detectors:
            manifest_path = root / manifest_name
            if manifest_path.exists():
                return analyzer(root, manifest_path)
        return None

    def _analyze_pyproject(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze pyproject.toml project"""
        info = ProjectInfo(
            project_type=ProjectType.PYPROJECT_TOML,
            root_path=root,
            manifest_path=manifest,
        )

        try:
            data = self._load_pyproject_data(manifest)
            info.project_type = self._detect_project_type(data)
            project = data.get("project", {})

            self._extract_python_version(project, info)
            self._extract_dependencies(project, info)
            self._detect_cli_features(project, info)
            self._detect_test_features(root, info)

        except Exception:
            pass

        return info

    def _load_pyproject_data(self, manifest: Path) -> dict[str, Any]:
        """Load and parse pyproject.toml"""
        with manifest.open("rb") as f:
            return tomllib.load(f)

    def _detect_project_type(self, data: dict) -> ProjectType:
        """Detect if Poetry or standard pyproject.toml"""
        if "tool" in data and "poetry" in data["tool"]:
            return ProjectType.POETRY
        return ProjectType.PYPROJECT_TOML

    def _extract_python_version(self, project: dict, info: ProjectInfo) -> None:
        """Extract Python version requirement"""
        requires_python = project.get("requires-python")
        if requires_python:
            info.python_version = requires_python

    def _extract_dependencies(self, project: dict, info: ProjectInfo) -> None:
        """Extract project dependencies"""
        deps = project.get("dependencies", [])
        info.dependencies = [str(d) for d in deps]

        if any("pytest" in str(d).lower() for d in info.dependencies):
            info.detected_features.add("pytest")

    def _detect_cli_features(self, project: dict, info: ProjectInfo) -> None:
        """Detect CLI and GUI features"""
        if project.get("scripts") or project.get("gui-scripts"):
            info.has_cli = True
            info.detected_features.add("cli")

        if project.get("gui-scripts"):
            info.has_gui = True
            info.detected_features.add("gui")

    def _detect_test_features(self, root: Path, info: ProjectInfo) -> None:
        """Detect test directories"""
        if (root / "tests").exists() or (root / "test").exists():
            info.has_tests = True
            info.detected_features.add("tests")

    def _analyze_pipfile(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze Pipfile project"""
        return ProjectInfo(
            project_type=ProjectType.PIPENV,
            root_path=root,
            manifest_path=manifest,
            detected_features={"pipenv"},
        )

    def _analyze_conda(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze Conda environment.yml"""
        return ProjectInfo(
            project_type=ProjectType.CONDA,
            root_path=root,
            manifest_path=manifest,
            detected_features={"conda"},
        )

    def _analyze_setup_py(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze setup.py project (legacy)"""
        return ProjectInfo(
            project_type=ProjectType.SETUP_PY,
            root_path=root,
            manifest_path=manifest,
            detected_features={"legacy"},
        )

    def _analyze_requirements(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze requirements.txt project"""
        info = ProjectInfo(
            project_type=ProjectType.REQUIREMENTS,
            root_path=root,
            manifest_path=manifest,
        )

        # Read dependencies
        try:
            with manifest.open(encoding="utf-8") as f:
                info.dependencies = [
                    line.strip() for line in f if line.strip() and not line.startswith("#")
                ]
        except Exception:
            pass

        return info

    def recommend_tests(self, project_info: ProjectInfo) -> list[TestRecommendation]:
        """Generate prioritized test recommendations for a project."""
        optional_recommendations: list[TestRecommendation | None] = [
            self._dependency_recommendation(project_info),
            self._sbom_recommendation(project_info),
        ]

        core_recommendations: list[TestRecommendation] = [
            self._manifest_recommendation(project_info),
            self._coverage_recommendation(project_info),
            self._security_recommendation(),
            self._packaging_recommendation(),
            self._complexity_recommendation(),
            self._baseline_recommendation(),
        ]

        all_recommendations: list[TestRecommendation] = [
            *core_recommendations,
            *(rec for rec in optional_recommendations if rec is not None),
        ]

        metrics_snapshot = self._load_latest_metrics(project_info.root_path)
        if metrics_snapshot:
            self._apply_metric_context(all_recommendations, metrics_snapshot)

        return sorted(all_recommendations, key=self._priority_sort_key)

    def _manifest_recommendation(self, project_info: ProjectInfo) -> TestRecommendation:
        return TestRecommendation(
            id="manifest_check",
            name="Manifest Check",
            description="Validate manifest file structure and metadata",
            priority=RecommendationPriority.HIGH,
            reason=f"Essential validation for {project_info.project_type.value} project",
        )

    def _coverage_recommendation(self, project_info: ProjectInfo) -> TestRecommendation:
        has_test_support = project_info.has_tests or "pytest" in project_info.detected_features
        priority = (
            RecommendationPriority.HIGH if has_test_support else RecommendationPriority.MEDIUM
        )
        reason = (
            "Project has test infrastructure"
            if has_test_support
            else "No tests detected - set up test infrastructure first"
        )
        return TestRecommendation(
            id="coverage",
            name="Coverage Analysis",
            description="Measure test coverage and identify untested code",
            priority=priority,
            reason=reason,
        )

    def _dependency_recommendation(self, project_info: ProjectInfo) -> TestRecommendation | None:
        if not project_info.dependencies:
            return None
        return TestRecommendation(
            id="dependencies",
            name="Dependency Check",
            description="Check for outdated or vulnerable dependencies",
            priority=RecommendationPriority.HIGH,
            reason=f"Project has {len(project_info.dependencies)} dependencies",
        )

    def _security_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="security",
            name="Security Scan",
            description="Detect unsafe code patterns (eval/exec, secrets)",
            priority=RecommendationPriority.HIGH,
            reason="Security is critical for all projects",
        )

    def _sbom_recommendation(self, project_info: ProjectInfo) -> TestRecommendation | None:
        if project_info.project_type not in {ProjectType.PYPROJECT_TOML, ProjectType.POETRY}:
            return None
        return TestRecommendation(
            id="sbom",
            name="SBOM Generation",
            description="Generate Software Bill of Materials",
            priority=RecommendationPriority.MEDIUM,
            reason="Modern project with clear dependency management",
        )

    def _packaging_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="packaging",
            name="Packaging Check",
            description="Validate package metadata and structure",
            priority=RecommendationPriority.MEDIUM,
            reason="Ensure proper package configuration",
        )

    def _complexity_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="complexity",
            name="Code Complexity",
            description="Measure cyclomatic complexity with radon",
            priority=RecommendationPriority.LOW,
            reason="Monitor code maintainability",
        )

    def _baseline_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="baseline_comparison",
            name="Baseline Comparison",
            description="Compare metrics against stored baseline",
            priority=RecommendationPriority.LOW,
            reason="Track quality trends over time",
        )

    def _load_latest_metrics(self, root_path: Path) -> dict[str, Any] | None:
        candidates: list[Path] = [
            root_path / "manifestguard-report.json",
            root_path / ".manifestguard" / "manifestguard-report.json",
            root_path / "report.json",
        ]

        for report_path in candidates:
            if not report_path.exists():
                continue
            try:
                with report_path.open(encoding="utf-8") as handle:
                    data = json.load(handle)
            except Exception as e:
                logger.debug(f"Failed to read report {report_path}: {e}")
                continue

            extended = data.get("extended") if isinstance(data, dict) else None
            if isinstance(extended, dict):
                return extended

        return None

    def _apply_metric_context(
        self,
        recommendations: list[TestRecommendation],
        metrics_snapshot: dict[str, Any],
    ) -> None:
        metric_data: dict[str, Any] = (
            metrics_snapshot.get("metrics", {}) if isinstance(metrics_snapshot, dict) else {}
        )
        rec_map: dict[str, TestRecommendation] = {rec.id: rec for rec in recommendations}

        coverage_data = metric_data.get("coverage", {})
        self._adjust_coverage_priority(rec_map.get("coverage"), coverage_data)

        dependency_data = metric_data.get("dependency", {})
        self._adjust_dependency_priority(rec_map.get("dependencies"), dependency_data)

        security_data = metric_data.get("security", {})
        self._adjust_security_priority(rec_map.get("security"), security_data)

        packaging_data = metric_data.get("packaging", {})
        self._adjust_manifest_priority(rec_map.get("manifest_check"), packaging_data)

    def _adjust_coverage_priority(
        self,
        recommendation: TestRecommendation | None,
        coverage_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(coverage_data, dict):
            return

        if coverage_data.get("unit_measured") is False:
            return

        coverage_percent = coverage_data.get("unit_percent")
        if coverage_percent is None:
            return

        if coverage_percent >= 90:
            self._downgrade_priority(recommendation, RecommendationPriority.LOW)
        elif coverage_percent >= 70:
            self._downgrade_priority(recommendation, RecommendationPriority.MEDIUM)

    def _adjust_dependency_priority(
        self,
        recommendation: TestRecommendation | None,
        dependency_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(dependency_data, dict):
            return

        critical = dependency_data.get("vulnerable_critical", 0)
        high = dependency_data.get("vulnerable_high", 0)
        outdated = dependency_data.get("outdated_count", 0)

        if critical or high:
            return

        if outdated == 0:
            self._downgrade_priority(recommendation, RecommendationPriority.LOW)
        elif outdated <= 10:
            self._downgrade_priority(recommendation, RecommendationPriority.MEDIUM)

    def _adjust_security_priority(
        self,
        recommendation: TestRecommendation | None,
        security_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(security_data, dict):
            return

        issues = [
            security_data.get("unsafe_exec_count", 0),
            security_data.get("hardcoded_secrets", 0),
            security_data.get("hardcoded_paths", 0),
        ]
        if any(value for value in issues):
            return

        if security_data.get("weak_crypto") or security_data.get("insecure_permissions"):
            return

        self._downgrade_priority(recommendation, RecommendationPriority.LOW)

    def _adjust_manifest_priority(
        self,
        recommendation: TestRecommendation | None,
        packaging_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(packaging_data, dict):
            return

        has_gaps = (
            packaging_data.get("missing_classifiers")
            or not packaging_data.get("readme_present", False)
            or not packaging_data.get("license_present", False)
            or not packaging_data.get("version_consistency", True)
        )

        if has_gaps:
            return

        self._downgrade_priority(recommendation, RecommendationPriority.MEDIUM)

    def _downgrade_priority(
        self,
        recommendation: TestRecommendation,
        target_priority: RecommendationPriority,
    ) -> None:
        priority_order = {
            RecommendationPriority.HIGH: 0,
            RecommendationPriority.MEDIUM: 1,
            RecommendationPriority.LOW: 2,
        }

        current_rank = priority_order.get(recommendation.priority)
        target_rank = priority_order.get(target_priority)

        if current_rank is None or target_rank is None:
            return

        if target_rank >= current_rank:
            recommendation.priority = target_priority

    def _priority_sort_key(self, recommendation: TestRecommendation) -> tuple[int, str]:
        priority_order = {
            RecommendationPriority.HIGH: 0,
            RecommendationPriority.MEDIUM: 1,
            RecommendationPriority.LOW: 2,
        }
        return priority_order[recommendation.priority], recommendation.id

    def generate_config_template(
        self,
        project_info: ProjectInfo,
        recommendations: list[TestRecommendation],
    ) -> ConfigTemplate:
        """Generate manifestguard.json configuration template."""
        enabled_tests = self._collect_enabled_tests(recommendations)

        template = ConfigTemplate(
            version=CONFIG_SCHEMA_VERSION,
            enabled=True,
            recommended_tests=enabled_tests,
            settings={},
        )

        self._apply_complexity_settings(template, enabled_tests)
        self._apply_coverage_settings(template, project_info, enabled_tests)
        self._apply_project_defaults(template, project_info)
        apply_i18n_hardcoded_gui_strings_settings(template, project_info)
        apply_i18n_hardcoded_cli_strings_settings(template, project_info)

        return template

    def _collect_enabled_tests(self, recommendations: list[TestRecommendation]) -> list[str]:
        return [recommendation.id for recommendation in recommendations if recommendation.enabled]

    def _apply_complexity_settings(
        self, template: ConfigTemplate, enabled_tests: list[str]
    ) -> None:
        if "complexity" not in enabled_tests:
            return

        template.complexity = {
            "threshold": 10,
            "includeTests": False,
            # LOC-based oversized-file thresholds (defaults tuned for AI reviewability)
            "maxFileLinesHigh": 600,
            "maxFileLinesCritical": 1200,
        }

    def _apply_coverage_settings(
        self,
        template: ConfigTemplate,
        project_info: ProjectInfo,
        enabled_tests: list[str],
    ) -> None:
        if "coverage" not in enabled_tests:
            return

        include_paths = self._detect_source_paths(project_info)
        template.coverage = {
            "threshold": 80,
            "fail_under": 70,
            "include": include_paths if include_paths else [],
            "exclude": self._default_coverage_excludes(),
        }

    def _default_coverage_excludes(self) -> list[str]:
        return [
            "tests/**",
            "**/__pycache__/**",
            "**/*.pyc",
            ".venv/**",
            "venv/**",
            "build/**",
            "dist/**",
        ]

    def _apply_project_defaults(self, template: ConfigTemplate, project_info: ProjectInfo) -> None:
        manifest_files = {
            ProjectType.PYPROJECT_TOML: "pyproject.toml",
            ProjectType.SETUP_PY: "setup.py",
        }

        manifest_file = manifest_files.get(project_info.project_type)
        if manifest_file:
            template.settings["manifest_file"] = manifest_file

    def _detect_source_paths(self, project_info: ProjectInfo) -> list[str]:
        """Detect source code directories for coverage include paths"""
        use_provided_root = bool(project_info.root_path and project_info.root_path.exists())
        project_root = project_info.root_path if use_provided_root else Path.cwd()
        project_name = project_root.name if use_provided_root else None

        # Try common source directories first
        source_paths = self._check_common_source_dirs(project_root, project_name)
        if source_paths:
            return source_paths

        # Fallback: scan for top-level Python packages
        return self._scan_toplevel_packages(project_root)

    def _check_common_source_dirs(self, project_root: Path, project_name: str | None) -> list[str]:
        """Check common source directory patterns"""
        source_paths: list[str] = []
        common_dirs: list[str | None] = ["src", "lib", project_name]

        for dirname in common_dirs:
            if not dirname:
                continue

            dir_path = project_root / dirname
            if dir_path.is_dir() and self._contains_python_files(dir_path):
                source_paths.append(f"{dirname}/**/*.py")

        return source_paths

    def _contains_python_files(self, directory: Path) -> bool:
        """Check if directory contains Python files"""
        return any(directory.rglob("*.py"))

    def _scan_toplevel_packages(self, project_root: Path) -> list[str]:
        """Scan for top-level Python packages"""
        source_paths: list[str] = []

        for item in project_root.iterdir():
            if self._is_valid_package_dir(item):
                source_paths.append(f"{item.name}/**/*.py")

        return source_paths

    def _is_valid_package_dir(self, item: Path) -> bool:
        """Check if directory is a valid Python package"""
        if not item.is_dir():
            return False
        if item.name.startswith((".", "_", "test", "doc", "example")):
            return False
        return (item / "__init__.py").exists()

    def generate_ai_recommendations(
        self,
        project_info: ProjectInfo,
        test_recommendations: list[TestRecommendation],
    ) -> list[dict[str, Any]]:
        """Generate optional AI-backed suggestions for project configuration."""
        recommendations: list[dict[str, Any]] = []
        recommendations.extend(
            self._ai_packaging_guidance(project_info, test_recommendations),
        )
        recommendations.extend(self._ai_coverage_guidance(project_info))
        recommendations.extend(self._ai_security_guidance(project_info))
        return recommendations

    def _ai_packaging_guidance(
        self,
        project_info: ProjectInfo,
        test_recommendations: list[TestRecommendation],
    ) -> list[dict[str, Any]]:
        if not self._is_application_project(project_info):
            return []

        if not self._is_packaging_enabled(test_recommendations):
            return []

        project_name = project_info.root_path.name if project_info.root_path else "This project"
        return [
            {
                "id": "packaging",
                "name": "Packaging Check",
                "priority": "LOW",
                "enabled": False,
                "reason": (
                    f"{project_name} appears to be an application, not a distributable package. "
                    "Packaging tests may not be relevant."
                ),
            }
        ]

    def _is_application_project(self, project_info: ProjectInfo) -> bool:
        return bool({"application", "cli"} & project_info.detected_features)

    def _is_packaging_enabled(
        self,
        test_recommendations: list[TestRecommendation],
    ) -> bool:
        return any(
            recommendation.id == "packaging" and recommendation.enabled
            for recommendation in test_recommendations
        )

    def _ai_coverage_guidance(self, project_info: ProjectInfo) -> list[dict[str, Any]]:
        guidance: list[dict[str, Any]]
        if "tests" in project_info.detected_features:
            return []
        guidance = [
            {
                "id": "coverage",
                "name": "Test Coverage",
                "priority": "HIGH",
                "enabled": True,
                "reason": "No test directory detected. Consider adding unit tests to improve code quality.",
            }
        ]
        return guidance

    def _ai_security_guidance(self, project_info: ProjectInfo) -> list[dict[str, Any]]:
        if "dependencies" not in project_info.detected_features:
            return []
        return [
            {
                "id": "security",
                "name": "Dependency Security",
                "priority": "HIGH",
                "enabled": True,
                "reason": "Regular security audits recommended for projects with external dependencies.",
            }
        ]

    def merge_configs(
        self,
        existing: dict[str, Any],
        template: ConfigTemplate,
        preserve_user: bool = True,
    ) -> dict[str, Any]:
        """Merge existing config with new template

        VS Extension Analog: mergeConfigs()

        Merge Strategy:
        - preserve_user=True: Keep user customizations (thresholds, settings)
        - preserve_user=False: Overwrite with template defaults
        - Always preserve: version, enabled, custom fields
        - Always merge: recommended_tests (union)

        Args:
            existing: Existing manifestguard.json content
            template: ConfigTemplate from generate_config_template()
            preserve_user: Keep user customizations (default: True)

        Returns:
            Merged configuration dictionary

        Example:
            >>> qc = QuickCheck()
            >>> existing = {"version": "1.0", "enabled": True}
            >>> template = qc.generate_config_template(info, tests)
            >>> merged = qc.merge_configs(existing, template, preserve_user=True)
            >>> print(merged["recommended_tests"])
            ['manifest_check', 'coverage', 'security']

        """
        merged: dict[str, Any] = existing.copy()

        self._ensure_extended_field(merged)
        self._merge_recommended_tests(merged, existing, template)
        self._merge_settings(merged, template)
        self._merge_complexity_config(merged, template, preserve_user)
        self._merge_coverage_config(merged, template, preserve_user)

        return merged

    def _ensure_extended_field(self, merged: dict[str, Any]) -> None:
        """Ensure extended field exists"""
        if "extended" not in merged:
            merged["extended"] = False

    def _merge_recommended_tests(
        self,
        merged: dict[str, Any],
        existing: dict[str, Any],
        template: ConfigTemplate,
    ) -> None:
        """Merge recommended tests using set union"""
        existing_tests: set[str] = set(existing.get("recommended_tests", []))
        template_tests: set[str] = set(template.recommended_tests)
        merged["recommended_tests"] = sorted(existing_tests | template_tests)

    def _merge_settings(self, merged: dict[str, Any], template: ConfigTemplate) -> None:
        """Merge settings, adding missing keys"""
        if "settings" not in merged:
            merged["settings"] = {}

        for key, value in template.settings.items():
            if key not in merged["settings"]:
                merged["settings"][key] = value

    def _merge_complexity_config(
        self, merged: dict[str, Any], template: ConfigTemplate, preserve_user: bool
    ) -> None:
        """Merge complexity configuration"""
        if not template.complexity:
            return

        if "complexity" not in merged or not preserve_user:
            merged["complexity"] = template.complexity
            return

        # Preserve user-tuned values but add new default keys when missing.
        if isinstance(merged.get("complexity"), dict):
            for key, value in template.complexity.items():
                if key not in merged["complexity"]:
                    merged["complexity"][key] = value

    def _merge_coverage_config(
        self, merged: dict[str, Any], template: ConfigTemplate, preserve_user: bool
    ) -> None:
        """Merge coverage configuration"""
        if not template.coverage:
            return

        if "coverage" not in merged or not preserve_user:
            merged["coverage"] = template.coverage
            return

        # Preserve user-tuned values but add new default keys when missing.
        if isinstance(merged.get("coverage"), dict):
            for key, value in template.coverage.items():
                if key not in merged["coverage"]:
                    merged["coverage"][key] = value

    def compare_configs(
        self,
        config_a: dict[str, Any],
        config_b: dict[str, Any],
    ) -> dict[str, Any]:
        """Compare two configurations and return differences

        VS Extension Analog: compareConfig()

        Returns:
            Dictionary with added, removed, and changed fields

        Example:
            >>> qc = QuickCheck()
            >>> diff = qc.compare_configs(old_config, new_config)
            >>> print(diff["added"])
            ['complexity', 'coverage']

        """
        added = self._find_added_keys(config_a, config_b)
        removed = self._find_removed_keys(config_a, config_b)
        changed = self._find_changed_values(config_a, config_b)

        return {
            "added": added,
            "removed": removed,
            "changed": changed,
        }

    def _find_added_keys(
        self,
        original: dict[str, Any],
        updated: dict[str, Any],
    ) -> list[str]:
        return [key for key in updated if key not in original]

    def _find_removed_keys(
        self,
        original: dict[str, Any],
        updated: dict[str, Any],
    ) -> list[str]:
        return [key for key in original if key not in updated]

    def _find_changed_values(
        self,
        original: dict[str, Any],
        updated: dict[str, Any],
    ) -> list[str]:
        return [
            key
            for key in original
            if key in updated and not self._values_match(original[key], updated[key])
        ]

    def _values_match(self, first: Any, second: Any) -> bool:
        return first == second
