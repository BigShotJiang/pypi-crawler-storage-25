"""ManifestGuard Public API.

This module provides programmatic access to ManifestGuard functionality
for external tools, CI/CD systems, and other integrations.
"""

from .integration_test import IntegrationTestHelper, example_integration_test
from .interface_discovery import InterfaceDefinition, InterfaceDiscovery, InterfaceType, Parameter
from .quick_check import (
    ConfigTemplate,
    ProjectInfo,
    ProjectType,
    QuickCheck,
    RecommendationPriority,
    TestRecommendation,
)
from .quick_check_cache import QuickCheckCache, get_cache

__all__ = [
    "ConfigTemplate",
    "IntegrationTestHelper",
    "InterfaceDefinition",
    # Interface Discovery (ADR-010 Phase 1)
    "InterfaceDiscovery",
    "InterfaceType",
    "Parameter",
    "ProjectInfo",
    "ProjectType",
    # Quick Check API (ADR-010 Phase 2)
    "QuickCheck",
    "QuickCheckCache",
    "RecommendationPriority",
    "TestRecommendation",
    "example_integration_test",
    "get_cache",
]
