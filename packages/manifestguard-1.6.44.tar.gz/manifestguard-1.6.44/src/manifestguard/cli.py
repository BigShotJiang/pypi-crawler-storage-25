"""ManifestGuard CLI - Command Line Interface

Usage:
    manifestguard check [FILE]
    manifestguard fix [--auto]
    manifestguard sbom [--format FORMAT] [--output FILE]
    manifestguard --version
"""

import asyncio
import contextlib
import importlib.metadata as md
import json
import logging
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, cast

import click

import manifestguard.quickcheck as qc
from manifestguard import CONFIG_SCHEMA_VERSION, __version__, get_runtime_version
from manifestguard.api import InterfaceDiscovery
from manifestguard.api.quick_check import ProjectInfo, QuickCheck
from manifestguard.core.config import ConfigurationService
from manifestguard.core.config import (
    CONFIG_FILENAMES,
    PROJECT_ROOT_MARKERS,
    find_existing_config_path as _find_existing_config_path,
    resolve_workspace_root as _resolve_workspace_root,
)
from manifestguard.core.config_analysis import ConfigAnalyzer, format_warning_output
from manifestguard.core.examples import (
    get_example_config,
    get_example_history,
    get_example_metrics_schema,
    get_example_report,
    print_all_examples,
)
from manifestguard.extended import BaselineManager, ExtendedTestRunner  # re-exported for cli_parts
from manifestguard.extended.complexity import (
    ComplexityAnalyzer,
    serialize_complexity_metrics,
    write_metrics_file,
)


class RawHelpGroup(click.Group):
    """Click group that can append an unwrapped help block."""

    raw_help_suffix: str = ""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_options(ctx, formatter)

        suffix = str(getattr(self, "raw_help_suffix", "") or "").strip()
        if suffix != "":
            formatter.write_paragraph()
            formatter.write(suffix + "\n")

        self.format_epilog(ctx, formatter)


LICENSE_GROUP_RAW_HELP = """HowTo (recommended):
    manifestguard license guide

Quick commands:
    manifestguard license device-hash
    manifestguard license activate <TOKEN>
    manifestguard license status

Notes:
    - Activation expects a token in the format: R4IT.payload.signature
    - You can also pass an activation JSON (or a file path to it) to `activate`.
    - Language: use `manifestguard --lang de license guide` (or `MANIFESTGUARD_LANG=de` or `manifestguard set-language de`)."""
from manifestguard.i18n import (
    SUPPORTED_LANGUAGES,
    detect_language,
    detect_language_with_source,
    get_current_language,
    get_current_language_source,
    set_language,
    t,
    t_format,
)
from manifestguard.core.user_settings import load_user_settings, save_user_settings, user_settings_path
from manifestguard.licensing import LicensingClient
from manifestguard.licensing.client import FEATURE_LIMITS
from manifestguard.models.telemetry import (
    ComplexityHotspot,
    ComplexityTelemetry,
    QualityTelemetry,
    RuffTelemetry,
)
from manifestguard.openapi import OpenAPIGenerator
from manifestguard.quickfix import (
    BackupContext,
    QuickFixAction,
    apply_quickfix,
    get_quickfixes,
    preview_quickfix,
)
from manifestguard.quickfix.backup import create_snapshot
from manifestguard.cli_commands.validate_views import (
    run_validate_views,
    format_violations,
)
from manifestguard.cli_commands.quickfix import quickfix_group
from manifestguard.cli_commands.duplication import duplication_group
from manifestguard.extended.metrics_history_export import add_coverage_metric_to_history
from manifestguard.extended.coverage_metrics import format_coverage_metric_for_display
from manifestguard.extended.coverage_weekly import (
    reconstruct_weekly_coverage,
    format_weekly_summary,
    export_weekly_summary_json,
)
from manifestguard.validation import (
    DependencyConflictChecker,
    DependencyLicensePolicyValidator,
    DependencyPolicyValidator,
    DiagnosticSeverity,
    EntryPointValidator,
    LicenseGuardrailValidator,
    PyprojectValidator,
    RequirementsValidator,
    SetupPyValidator,
    ValidationResult,
)
from manifestguard.validation.base import Diagnostic
from manifestguard.validation.inline_markers import (
    filter_result_with_inline_markers,
)
from manifestguard.validation.runtime_metrics import run_manifest_validation_with_metrics

logger = logging.getLogger(__name__)

def _validate_workspace_root_safe(workspace_root: Path) -> Path:
    """Validate workspace root with proper error handling.
    
    Args:
        workspace_root: Path to validate
        
    Returns:
        Validated workspace root
        
    Raises:
        click.UsageError: If validation fails with user-friendly message
    """
    try:
        return cli_validation.validate_workspace_root(workspace_root)
    except Exception as e:
        # Convert validation errors to Click usage errors
        raise click.UsageError(str(e)) from e


def _get_license_client() -> LicensingClient:
    """Get singleton licensing client instance"""
    return LicensingClient.get_instance()

# Force UTF-8 encoding for Windows console
if sys.platform == "win32":
    # Set console output encoding to UTF-8
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
    # Also set environment variable for subprocess
    os.environ["PYTHONIOENCODING"] = "utf-8"


def _normalize_lang_option(lang: str | None) -> str | None:
    if lang is None:
        return None
    value = lang.strip().lower()
    if not value:
        return None
    return value


def _normalize_common_license_argv(argv: list[str]) -> list[str]:
    if len(argv) < 2:
        return list(argv)

    normalized = list(argv)
    first_arg = str(normalized[1] or "").strip()

    if first_arg in {"-license", "--license"}:
        normalized[1] = "license"
    elif first_arg in {"device-hash", "--device-hash"}:
        return [normalized[0], "license", "device-hash", *normalized[2:]]

    if len(normalized) >= 3 and normalized[1] == "license" and normalized[2] == "help":
        normalized[2] = "--help"

    return normalized


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=get_runtime_version(), prog_name="manifestguard")
@click.option(
    "-l",
    "--lang",
    "lang",
    default=None,
    type=click.Choice(SUPPORTED_LANGUAGES, case_sensitive=False),
    metavar="LANG",
    help=t_format(
        "cli.options.lang",
        languages=", ".join(SUPPORTED_LANGUAGES),
        module="cli",
    ),
)
def cli(lang: str | None) -> None:
    """ManifestGuard - Python Package Manifest Validation.

    Validate pyproject.toml, setup.py, requirements.txt for consistency.

    \b
    Quick Start:
      manifestguard check                    # Basic validation
      manifestguard check --extended         # Full analysis with metrics
            manifestguard guide --list             # Local versioned help catalog
            manifestguard license guide            # License activation HowTo
            manifestguard license status           # Current license/tier state
      manifestguard list-tests               # Show available test categories
      manifestguard examples --type config   # Show config template

        \b
        License Activation:
            manifestguard license guide
            manifestguard license device-hash
            manifestguard license activate <TOKEN>
            manifestguard license status

            Common shortcuts accepted:
            manifestguard device-hash
            manifestguard --device-hash

    \b
    Common Workflows:
      - CI/CD Integration:    manifestguard check --extended --report report.json
      - Local Development:    manifestguard dashboard
      - Config Setup:         manifestguard init-config --merge
      - SBOM Generation:      manifestguard sbom --format cyclonedx

    \b
    Bootstrap Script for Projects (CI/CD Ready):
      Copy examples/run_manifestguard.py to your project for:
        • Auto-install/update ManifestGuard
        • Auto-generate config (manifestguard.json)
        • Run tests + extended analysis
        • Generate CI/CD-ready reports

      Usage:  python run_manifestguard.py --help
      GitHub: https://github.com/timejunky/r4it_manifest_guard_py/tree/dev/examples

    \b
    Global Install + Project Venv (Recommended):
      Keep ManifestGuard (mgpy) installed globally, but run coverage/tests inside
      your project's venv.

      - Extended coverage auto-uses a project venv Python if found:
          .venv/ , venv/ , .env/
      - Override the interpreter explicitly via CLI:
          manifestguard check --extended --project-python path/to/python.exe

      Note: the selected project interpreter must have pytest + coverage installed
      (and pytest-cov if you use --cov flags in your own test commands).

    \b
    Extended Analysis Includes:
      • Code Coverage (pytest-cov)      • Cyclomatic Complexity (radon)
      • Dependency Security (pip-audit) • License Compliance
      • Duplication Detection           • Dummy/Placeholder Code
      • Policy Enforcement              • Packaging Best Practices

    Use 'manifestguard COMMAND --help' for detailed command information.
    """
    # Refresh language on every CLI invocation so persisted user settings
    # (and system locale) take effect even if the module was imported earlier.
    lang_norm = _normalize_lang_option(lang)
    if lang_norm is None:
        detected, src = detect_language_with_source()
        set_language(detected, source=src)
        return
    set_language(lang_norm, source="cli-flag")


@cli.group("license")
def license_group() -> None:
    """License management commands"""
    pass


@license_group.command("sync")
@click.option("--show-entitlement", is_flag=True, help="Show computed entitlement (update allowed)")
def license_sync(show_entitlement: bool) -> None:
    """Re-read persisted activation/token and report entitlement state.

    Note: This command does not contact any activation server; it's a local
    sync/inspect helper for persisted offline activation data.
    """
    client = _get_license_client()
    # Re-read persisted storage
    act = client.get_activation()
    token = client.get_token()

    click.echo("Re-read activation and token from local storage")
    if act:
        click.echo("  activation: present")
    else:
        click.echo("  activation: missing")

    if token:
        click.echo("  token: present")
    else:
        click.echo("  token: missing")

    if show_entitlement:
        entitled = client.is_update_entitled()
        click.echo(f"  update_entitled: {entitled}")


def _run_manifest_validation(workspace_root: Path) -> ValidationResult:
    """Run manifest validation on project

    Args:
        workspace_root: Project root directory

    Returns:
        Combined ValidationResult

    """
    return run_manifest_validation_with_metrics(workspace_root).result


def _security_attr_int(obj: Any, name: str) -> int:
    try:
        return int(getattr(obj, name, 0) or 0)
    except Exception:
        return 0


def _security_attr_list(obj: Any, name: str) -> list[Any]:
    if obj is None:
        return []
    return list(getattr(obj, name, []) or [])


def _summarize_security_findings(security: Any) -> dict[str, Any]:
    """Return a compact summary of security findings for gating and display."""
    weak_crypto_files = _security_attr_list(security, "weak_crypto")
    insecure_perm_files = _security_attr_list(security, "insecure_permissions")
    wheel_findings = _security_attr_list(security, "wheel_content_findings")

    summary = {
        "unsafe_exec": _security_attr_int(security, "unsafe_exec_count"),
        "hardcoded_secrets": _security_attr_int(security, "hardcoded_secrets"),
        "hardcoded_paths": _security_attr_int(security, "hardcoded_paths"),
        "subprocess_shell_true": _security_attr_int(security, "subprocess_shell_true"),
        "unsafe_deserialization": _security_attr_int(security, "unsafe_deserialization"),
        "tls_verify_disabled": _security_attr_int(security, "tls_verify_disabled"),
        "insecure_tempfile": _security_attr_int(security, "insecure_tempfile"),
        "weak_crypto_files": len(weak_crypto_files),
        "insecure_permissions_files": len(insecure_perm_files),
        "wheel_content_issues": _security_attr_int(security, "wheel_content_issues"),
        "examples": {
            "weak_crypto": weak_crypto_files[:3],
            "insecure_permissions": insecure_perm_files[:3],
            "wheel": wheel_findings[:3],
        },
    }

    numeric_keys = {
        "unsafe_exec",
        "hardcoded_secrets",
        "hardcoded_paths",
        "subprocess_shell_true",
        "unsafe_deserialization",
        "tls_verify_disabled",
        "insecure_tempfile",
        "weak_crypto_files",
        "insecure_permissions_files",
        "wheel_content_issues",
    }
    summary["has_findings"] = any(summary.get(key, 0) for key in numeric_keys) or bool(
        wheel_findings
    )
    return summary


def _build_complexity_hotspots(comp: Any) -> list[ComplexityHotspot]:
    """Extract top-5 hotspot objects from a complexity metrics object."""
    hotspots: list[ComplexityHotspot] = []
    for v in getattr(comp, "top_violations", [])[:5]:
        if not isinstance(v, dict):
            continue
        file_path = v.get("file")
        func_name = v.get("function") or v.get("name")
        line_num = v.get("line")
        complexity_val = v.get("complexity") or v.get("value")
        if file_path and func_name and line_num and complexity_val:
            hotspots.append(ComplexityHotspot(file=file_path, name=func_name, line=line_num, value=complexity_val))
    return hotspots


def _normalize_complexity_engine(comp: Any) -> tuple[str, str | None]:
    """Return (engine_name, engine_version) normalized from a complexity object."""
    engine = (getattr(comp, "engine", "mgpy-analyzer") or "mgpy-analyzer").strip().lower()
    if engine == "mgpy" or engine not in {"mgpy-analyzer", "radon"}:
        engine = "mgpy-analyzer"
    engine_version = getattr(comp, "engine_version", None)
    if engine == "mgpy-analyzer" and not engine_version:
        engine_version = __version__
    return engine, engine_version


def _build_quality_slice(metrics: Any, workspace_root: Path) -> dict[str, Any]:  # noqa: ARG001
    """Construct quality telemetry slice with Ruff and complexity data.

    The schema matches TODO-018 (Telemetry Schema Definition) and uses Pydantic models
    for validation and JSON serialization. Returns a dict for backwards compatibility
    with existing code that expects dict structure.
    """
    ruff_info = _get_ruff_info()

    ruff_telemetry = RuffTelemetry(
        issueCount=ruff_info.get("issueCount", 0),
        warningCount=ruff_info.get("warningCount", 0),
        version=ruff_info.get("version"),
        source=ruff_info.get("source", "none"),
        byRule=ruff_info.get("byRule", {}),
    )

    complexity_telemetry: ComplexityTelemetry | None = None
    comp = getattr(metrics, "complexity", None)
    if comp:
        engine, engine_version = _normalize_complexity_engine(comp)
        functions_above = getattr(comp, "violations_count", 0)
        complexity_telemetry = ComplexityTelemetry(
            avg=round(getattr(comp, "average_complexity", 0.0), 1),
            violations=functions_above,
            threshold=getattr(comp, "threshold", 10),
            functionsAboveThreshold=functions_above,
            hotspots=_build_complexity_hotspots(comp),
            engine=engine,
            engineVersion=engine_version,
        )

    quality_score = getattr(metrics, "quality_score", None)
    quality_telemetry = QualityTelemetry(
        timestamp=datetime.now(timezone.utc).isoformat(),
        projectName=str(workspace_root.name),
        manifestguardVersion=__version__,
        ruff=ruff_telemetry,
        complexity=complexity_telemetry,
        qualityScore=round(float(quality_score), 1) if isinstance(quality_score, (int, float)) else None,
    )

    return json.loads(quality_telemetry.model_dump_json(exclude_none=True, by_alias=False))


def run_extended_tests(workspace_root: Path) -> Any:
    """Run extended analysis and return metrics (public API for CLI helpers).

    Note:
        Some commands (e.g. `export-metrics`) and tests patch this symbol via
        `manifestguard.cli.run_extended_tests`, so it must remain importable.
    """
    try:
        from manifestguard.core.test_config_helper import load_manifest_config

        config = load_manifest_config(workspace_root)
    except Exception:
        config = {}

    from manifestguard.extended.runner import run_extended_tests as _run

    return _run(workspace_root, config=config)


def _get_ruff_info() -> dict[str, Any]:
    """Best-effort Ruff telemetry: version and zeroed counts if Ruff not available.

    Avoids invoking Ruff during tests; counts remain zero unless future integration populates them.
    Also attempts to collect radon version for complexity engine provenance.
    """
    info: dict[str, Any] = {
        "issueCount": 0,
        "warningCount": 0,
        "version": None,
        "source": "none",
        "byRule": {},
        "radonVersion": None,
    }
    try:
        # Try importlib.metadata first
        try:
            info["version"] = md.version("ruff")
            info["source"] = "venv"
        except Exception:
            pass
        with contextlib.suppress(Exception):
            info["radonVersion"] = md.version("radon")
    except Exception:
        # Fallback: attempt direct import
        try:
            import ruff  # noqa: PLC0415 - optional dependency

            info["version"] = getattr(ruff, "__version__", None)
            info["source"] = "venv"
        except Exception:
            pass
        try:
            import radon  # noqa: PLC0415 - optional dependency

            info["radonVersion"] = getattr(radon, "__version__", None)
        except Exception:
            pass
    return info


def _has_license_feature(feature: str) -> bool:
    """Return True if current license enables a feature.

    This is best-effort and must never crash core CLI flows.
    """
    try:
        client = LicensingClient.get_instance()

        def _status_allows() -> bool:
            status = client.get_status()
            status_name = getattr(status.code, "name", "")
            if status_name not in {"OK", "UPDATE_ENTITLEMENT_EXPIRED"}:
                return False
            if not status.payload:
                return False

            raw_tier = status.payload.get("tier") or status.payload.get("plan") or "community"
            normalized_tier = client._normalized_tier(raw_tier)
            limits = FEATURE_LIMITS.get(normalized_tier, FEATURE_LIMITS["community"])
            value = limits.get(feature, False)
            return bool(value) if isinstance(value, (int, bool)) else False

        # Prefer direct status-based checks first.
        if _status_allows():
            return True

        # Retry once to smooth over transient keyring/env read races in fresh shells.
        time.sleep(0.1)
        if _status_allows():
            return True

        # Backward-compatible fallback.
        return client.has_feature(feature)
    except Exception:
        return False


def _license_tier_label() -> str:
    """Return a short tier label for UX messages (best-effort)."""
    try:
        client = LicensingClient.get_instance()
        status = client.get_status()
        if not status.payload:
            return "community"

        tier = status.payload.get("tier") or status.payload.get("plan") or "community"
        return client._normalized_tier(tier)
    except Exception:
        return "community"


@cli.group(
    name="license",
    cls=RawHelpGroup,
    help="Manage ManifestGuard licensing.",
    invoke_without_command=True,
    no_args_is_help=True,
)
@click.pass_context
def license_group(ctx: click.Context) -> None:
    """Manage ManifestGuard licensing."""
    return None


license_group.raw_help_suffix = LICENSE_GROUP_RAW_HELP


# Split command implementations into smaller modules to comply with the internal
# per-file LOC limit while keeping `manifestguard.cli` as the public entrypoint.
from manifestguard.cli_parts import config_commands as _config_commands
from manifestguard.cli_parts import core_commands as _core_commands
from manifestguard.cli_parts import guide_commands as _guide_commands
from manifestguard.cli_parts import git_check_commands as _git_check_commands
from manifestguard.cli_parts import i18n_commands as _i18n_commands
from manifestguard.cli_parts import licensing_commands as _licensing_commands
from manifestguard.cli_parts import metrics_commands as _metrics_commands

_config_commands.register(cli)
_core_commands.register(cli)
_guide_commands.register(cli)
_git_check_commands.register(cli)
_i18n_commands.register(cli)
_metrics_commands.register(cli)
_licensing_commands.register(license_group)


# Register external command groups
cli.add_command(quickfix_group)
cli.add_command(duplication_group)


def main() -> int:
    """Main entry point."""
    try:
        sys.argv[:] = _normalize_common_license_argv(sys.argv)
        cli()
        return 0
    except SystemExit as e:
        code = e.code
        if isinstance(code, int):
            return code
        return 0 if code in (None, False) else 1
    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
