"""pyproject.toml Validator

Validates pyproject.toml files against PEP 621 (Project Metadata)
and PEP 518 (Build System) specifications.

References:
- PEP 621: https://peps.python.org/pep-0621/
- PEP 518: https://peps.python.org/pep-0518/

"""

import sys
from pathlib import Path
from typing import Any, ClassVar

from packaging.requirements import InvalidRequirement, Requirement
from packaging.version import InvalidVersion, Version

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None

from .base import DiagnosticSeverity, ManifestValidator, ValidationResult


class PyprojectValidator(ManifestValidator):
    """Validator for pyproject.toml files

    Checks:
    1. File exists and is valid TOML
    2. PEP 518 [build-system] section (if present)
    3. PEP 621 [project] section (required fields)
    4. Project metadata (name, version, description, etc.)
    5. Dependencies format (PEP 440 compliance)
    6. Entry points format ([project.scripts], [project.gui-scripts])
    7. Optional dependencies ([project.optional-dependencies])

    Diagnostic Codes:
    - PYP-001: pyproject.toml not found
    - PYP-002: Invalid TOML syntax
    - PYP-003: Missing [project] section
    - PYP-004: Missing required [project] fields
    - PYP-005: Invalid project.name format
    - PYP-006: Invalid project.version format
    - PYP-007: Invalid dependency specifier
    - PYP-008: Invalid entry point format
    - PYP-009: Invalid [build-system]
    - PYP-010: Deprecated fields used

    Example:
        >>> validator = PyprojectValidator(Path("/project"))
        >>> result = validator.validate()
        >>> if not result.is_valid:
        ...     for diag in result.diagnostics:
        ...         print(f"{diag.code}: {diag.message}")

    """

    # PEP 621 required fields
    REQUIRED_PROJECT_FIELDS: ClassVar[list[str]] = ["name"]

    # PEP 621 recommended fields
    RECOMMENDED_FIELDS: ClassVar[list[str]] = ["version", "description"]

    # PEP 621 valid classifiers prefixes
    VALID_CLASSIFIER_PREFIXES: ClassVar[list[str]] = [
        "Development Status",
        "Intended Audience",
        "License",
        "Programming Language",
        "Topic",
    ]

    def __init__(self, project_root: Path, config: dict[str, Any] | None = None):
        """Initialize pyproject.toml validator

        Args:
            project_root: Root directory containing pyproject.toml
            config: Optional configuration

        """
        super().__init__(project_root, config)
        self.pyproject_path = self.project_root / "pyproject.toml"
        self.pyproject_data: dict[str, Any] | None = None

    def validate(self) -> ValidationResult:
        """Validate pyproject.toml file

        Returns:
            ValidationResult with all diagnostics

        """
        result = ValidationResult(validated_files=[self.pyproject_path])

        # Check if file exists
        if not self.pyproject_path.exists():
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-001",
                    message="pyproject.toml not found in project root",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    fix_suggestion="Create pyproject.toml with [project] section",
                ),
            )
            return result

        # Parse TOML
        if not self._parse_toml(result):
            return result

        # Validate sections
        self._validate_build_system(result)
        self._validate_project_section(result)

        if self.pyproject_data and "project" in self.pyproject_data:
            project = self.pyproject_data["project"]
            self._validate_project_metadata(project, result)
            self._validate_dependencies(project, result)
            self._validate_optional_dependencies(project, result)
            self._validate_entry_points(project, result)

        return result

    def _parse_toml(self, result: ValidationResult) -> bool:
        """Parse TOML file

        Args:
            result: ValidationResult to add diagnostics to

        Returns:
            True if parsing succeeded, False otherwise

        """
        if tomllib is None:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-002",
                    message="TOML parser not available (install tomli for Python <3.11)",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    fix_suggestion="pip install tomli",
                ),
            )
            return False

        try:
            with self.pyproject_path.open("rb") as f:
                self.pyproject_data = tomllib.load(f)
            return True
        except tomllib.TOMLDecodeError as e:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-002",
                    message=f"Invalid TOML syntax: {e}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    line=getattr(e, "lineno", None),
                ),
            )
            return False
        except Exception as e:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-002",
                    message=f"Error reading pyproject.toml: {e}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                ),
            )
            return False

    def _validate_build_system(self, result: ValidationResult) -> None:
        """Validate [build-system] section (PEP 518)

        Args:
            result: ValidationResult to add diagnostics to

        """
        if not self.pyproject_data or "build-system" not in self.pyproject_data:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-009",
                    message="[build-system] section missing (recommended by PEP 518)",
                    severity=DiagnosticSeverity.WARNING,
                    file_path=self.pyproject_path,
                    fix_suggestion='Add [build-system] with requires = ["setuptools>=68.0", "wheel"]',
                ),
            )
            return

        build_system = self.pyproject_data["build-system"]

        # Validate table structure
        if not isinstance(build_system, dict):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-009",
                    message="[build-system] must be a table",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    fix_suggestion="Use TOML table syntax: [build-system]",
                ),
            )
            return

        # Check required fields
        requires = build_system.get("requires")
        if requires is None:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-009",
                    message="[build-system] missing 'requires' field",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    fix_suggestion='Add requires = ["setuptools>=68.0", "wheel"]',
                ),
            )
        elif not isinstance(requires, list) or not all(isinstance(item, str) for item in requires):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-009",
                    message="[build-system].requires must be a list of strings",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    fix_suggestion='Example: requires = ["setuptools>=68.0", "wheel"]',
                ),
            )

        build_backend = build_system.get("build-backend")
        if build_backend is None:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-009",
                    message="[build-system] missing 'build-backend' field",
                    severity=DiagnosticSeverity.WARNING,
                    file_path=self.pyproject_path,
                    fix_suggestion='Add build-backend = "setuptools.build_meta"',
                ),
            )
        elif not isinstance(build_backend, str):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-009",
                    message="[build-system].build-backend must be a string",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                ),
            )

    def _validate_project_section(self, result: ValidationResult) -> None:
        """Validate [project] section exists (PEP 621)

        Args:
            result: ValidationResult to add diagnostics to

        """
        if not self.pyproject_data or "project" not in self.pyproject_data:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-003",
                    message="[project] section missing (required by PEP 621)",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    fix_suggestion="Add [project] section with at minimum 'name' field",
                ),
            )

    def _validate_project_metadata(self, project: dict[str, Any], result: ValidationResult) -> None:
        """Validate project metadata fields"""
        self._check_required_fields(project, result)
        self._check_recommended_fields(project, result)
        self._validate_name_field(project, result)
        self._validate_version_field(project, result)

    def _check_required_fields(self, project: dict, result: ValidationResult) -> None:
        """Check required project fields"""
        for field in self.REQUIRED_PROJECT_FIELDS:
            if field not in project:
                fix_suggestion = f'Add {field} = "your-package-name"' if field == "name" else None
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="PYP-004",
                        message=f"Required field 'project.{field}' is missing",
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.pyproject_path,
                        fix_suggestion=fix_suggestion,
                    ),
                )

    def _check_recommended_fields(self, project: dict, result: ValidationResult) -> None:
        """Check recommended project fields"""
        for field in self.RECOMMENDED_FIELDS:
            if field not in project:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="PYP-004",
                        message=f"Recommended field 'project.{field}' is missing",
                        severity=DiagnosticSeverity.INFO,
                        file_path=self.pyproject_path,
                    ),
                )

    def _validate_name_field(self, project: dict, result: ValidationResult) -> None:
        """Validate project.name format"""
        if "name" not in project:
            return

        name = project["name"]
        if not isinstance(name, str) or not name:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-005",
                    message="project.name must be a non-empty string",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                ),
            )
        elif not self._is_valid_package_name(name):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-005",
                    message=f"Invalid package name '{name}' (use lowercase, hyphens, no spaces)",
                    severity=DiagnosticSeverity.WARNING,
                    file_path=self.pyproject_path,
                    fix_suggestion="Use lowercase letters, numbers, and hyphens only",
                ),
            )

    def _validate_version_field(self, project: dict, result: ValidationResult) -> None:
        """Validate project.version format"""
        if "version" not in project:
            return

        version = project["version"]
        if not isinstance(version, str) or not version:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-006",
                    message="project.version must be a non-empty string",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                ),
            )
            return

        try:
            Version(version)
        except InvalidVersion as exc:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-006",
                    message=f"Invalid version '{version}': {exc}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                    fix_suggestion="Use PEP 440 compliant version, e.g. '1.2.3'",
                ),
            )

    def _validate_dependencies(self, project: dict[str, Any], result: ValidationResult) -> None:
        """Validate dependencies format (PEP 440)

        Args:
            project: [project] section data
            result: ValidationResult to add diagnostics to

        """
        if "dependencies" in project:
            deps = project["dependencies"]
            if not isinstance(deps, list):
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="PYP-007",
                        message="project.dependencies must be a list",
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.pyproject_path,
                    ),
                )
            else:
                seen: set[str] = set()
                for i, dep in enumerate(deps):
                    if not isinstance(dep, str) or not dep.strip():
                        result.add_diagnostic(
                            self._create_diagnostic(
                                code="PYP-007",
                                message=f"Dependency at index {i} must be a non-empty string",
                                severity=DiagnosticSeverity.ERROR,
                                file_path=self.pyproject_path,
                            ),
                        )
                        continue

                    try:
                        requirement = Requirement(dep)
                    except InvalidRequirement as exc:
                        result.add_diagnostic(
                            self._create_diagnostic(
                                code="PYP-007",
                                message=f"Invalid dependency specifier '{dep}': {exc}",
                                severity=DiagnosticSeverity.ERROR,
                                file_path=self.pyproject_path,
                                fix_suggestion="Use valid PEP 508 requirement, e.g. 'package>=1.0.0'",
                            ),
                        )
                        continue

                    normalized_name = requirement.name.lower()
                    if normalized_name in seen:
                        result.add_diagnostic(
                            self._create_diagnostic(
                                code="PYP-007",
                                message=f"Duplicate dependency '{requirement.name}' in project.dependencies",
                                severity=DiagnosticSeverity.WARNING,
                                file_path=self.pyproject_path,
                                fix_suggestion="Remove duplicate entry",
                            ),
                        )
                    else:
                        seen.add(normalized_name)

                    # Warn if dependency is unpinned in strict mode
                    if not requirement.specifier:
                        result.add_diagnostic(
                            self._create_diagnostic(
                                code="PYP-007",
                                message=f"Dependency '{requirement.name}' has no version constraints",
                                severity=DiagnosticSeverity.INFO,
                                file_path=self.pyproject_path,
                                fix_suggestion=f"Add version specifier: {requirement.name}>=1.0.0",
                            ),
                        )

    def _validate_optional_dependencies(
        self, project: dict[str, Any], result: ValidationResult
    ) -> None:
        """Validate [project.optional-dependencies] section."""
        optional = project.get("optional-dependencies")
        if optional is None:
            return

        if not isinstance(optional, dict):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-007",
                    message="[project.optional-dependencies] must be a table",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                ),
            )
            return

        for group, deps in optional.items():
            if not isinstance(deps, list):
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="PYP-007",
                        message=f"Optional dependency group '{group}' must be a list",
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.pyproject_path,
                    ),
                )
                continue

            for dep in deps:
                if not isinstance(dep, str) or not dep.strip():
                    result.add_diagnostic(
                        self._create_diagnostic(
                            code="PYP-007",
                            message=f"Optional dependency in group '{group}' must be a non-empty string",
                            severity=DiagnosticSeverity.ERROR,
                            file_path=self.pyproject_path,
                        ),
                    )
                    continue

                try:
                    Requirement(dep)
                except InvalidRequirement as exc:
                    result.add_diagnostic(
                        self._create_diagnostic(
                            code="PYP-007",
                            message=f"Invalid optional dependency '{dep}' in group '{group}': {exc}",
                            severity=DiagnosticSeverity.ERROR,
                            file_path=self.pyproject_path,
                        ),
                    )

    def _validate_entry_points(self, project: dict[str, Any], result: ValidationResult) -> None:
        """Validate entry points format

        Args:
            project: [project] section data
            result: ValidationResult to add diagnostics to

        """
        scripts = project.get("scripts")
        if scripts is not None:
            self._validate_entry_point_table("project.scripts", scripts, result)

        gui_scripts = project.get("gui-scripts")
        if gui_scripts is not None:
            self._validate_entry_point_table("project.gui-scripts", gui_scripts, result)

        entry_points = project.get("entry-points")
        if entry_points is not None:
            if not isinstance(entry_points, dict):
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="PYP-008",
                        message="project.entry-points must be a table",
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.pyproject_path,
                    ),
                )
            else:
                for group, entries in entry_points.items():
                    self._validate_entry_point_table(
                        f"project.entry-points.{group}", entries, result
                    )

    def _validate_entry_point_table(
        self,
        label: str,
        entry_points: Any,
        result: ValidationResult,
    ) -> None:
        """Validate an entry point table (scripts, gui-scripts, entry-points group)."""
        if not isinstance(entry_points, dict):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="PYP-008",
                    message=f"{label} must be a table of entry points",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.pyproject_path,
                ),
            )
            return

        for name, target in entry_points.items():
            if not isinstance(target, str) or not target.strip():
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="PYP-008",
                        message=f"Entry point '{name}' in {label} must be a non-empty string",
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.pyproject_path,
                    ),
                )
                continue

            if ":" not in target:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="PYP-008",
                        message=f"Entry point '{name}' has invalid format (expected 'module:function')",
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.pyproject_path,
                        fix_suggestion=f"Change to format like '{name} = \"package.module:main\"'",
                    ),
                )

    @staticmethod
    def _is_valid_package_name(name: str) -> bool:
        """Check if package name follows PyPI naming conventions

        Args:
            name: Package name

        Returns:
            True if valid, False otherwise

        """
        import re  # noqa: PLC0415 - only used in this one method

        # PyPI allows letters, numbers, hyphens, underscores, periods
        # Best practice: lowercase with hyphens
        return bool(re.match(r"^[a-z0-9]([a-z0-9\-_\.]*[a-z0-9])?$", name, re.IGNORECASE))
