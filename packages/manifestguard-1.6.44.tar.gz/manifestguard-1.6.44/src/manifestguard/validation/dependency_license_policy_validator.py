"""Dependency license policy enforcement (best-effort).

This validator is intentionally conservative and deterministic:
- It never contacts external services.
- It attempts to resolve license metadata from installed distributions.
- If a dependency is not installed, license may be "unknown".

Config format (manifestguard.json -> dependencyRules):

{
  "dependencyRules": {
    "licenseAllowlist": ["mit", "apache"],
    "licenseDenylist": ["gpl", "agpl"],
    "unknownLicenseSeverity": "warning",
    "licensePolicySeverity": "error",
    "resolveFromInstalled": true
  }
}
"""

from __future__ import annotations

import ast
import importlib.metadata as md
import logging
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from packaging.requirements import InvalidRequirement, Requirement

from .base import DiagnosticSeverity, ManifestValidator, ValidationResult

logger = logging.getLogger(__name__)


def _load_pyproject_toml(pyproject_path: Path) -> dict[str, Any] | None:
    try:
        import sys  # noqa: PLC0415 - version check for tomllib availability

        if sys.version_info >= (3, 11):
            import tomllib  # noqa: PLC0415 - version-specific import (3.11+)
        else:
            import tomli as tomllib  # noqa: PLC0415 - backport for <3.11

        with pyproject_path.open("rb") as handle:
            data = tomllib.load(handle)
    except Exception:
        return None

    return data if isinstance(data, dict) else None


def _iter_pyproject_dependency_strings(
    project: dict[str, Any],
    *,
    include_optional: bool,
) -> Iterable[str]:
    deps = project.get("dependencies")
    if isinstance(deps, list):
        for raw in deps:
            if isinstance(raw, str):
                yield raw

    if not include_optional:
        return

    optional = project.get("optional-dependencies")
    if not isinstance(optional, dict):
        return

    for _group, items in optional.items():
        if not isinstance(items, list):
            continue
        for raw in items:
            if isinstance(raw, str):
                yield raw


@dataclass(frozen=True)
class _DeclaredDependency:
    name: str
    requirement: str
    file_path: Path
    line: int | None = None


@dataclass(frozen=True)
class _ResolvedLicense:
    names: set[str]
    raw: str
    source: str


class DependencyLicensePolicyValidator(ManifestValidator):
    """Enforce dependency license allow/deny policies.

    Diagnostic Codes:
    - POL-LIC-001: Denylist violation (dependency license blocked)
    - POL-LIC-002: Unknown license (unable to resolve)
    - POL-LIC-003: Not in allowlist (license not allowed)
    """

    def validate(self) -> ValidationResult:
        result = ValidationResult()

        rules = self.config or {}
        allowlist = _normalize_list(rules.get("licenseAllowlist"))
        denylist = _normalize_list(rules.get("licenseDenylist"))

        if not allowlist and not denylist:
            return result

        if not bool(rules.get("resolveFromInstalled", True)):
            return result

        unknown_sev = _parse_severity(
            rules.get("unknownLicenseSeverity"),
            default=DiagnosticSeverity.WARNING,
            allow_ignore=True,
        )
        policy_sev = _parse_severity(
            rules.get("licensePolicySeverity"),
            default=DiagnosticSeverity.ERROR,
            allow_ignore=False,
        )

        seen: set[tuple[str, str, str, int | None]] = set()
        for dep in self._collect_declared_dependencies():
            self._validate_declared_dependency(
                dep,
                result=result,
                seen=seen,
                allowlist=allowlist,
                denylist=denylist,
                unknown_sev=unknown_sev,
                policy_sev=policy_sev,
            )

        return result

    def _validate_declared_dependency(
        self,
        dep: _DeclaredDependency,
        *,
        result: ValidationResult,
        seen: set[tuple[str, str, str, int | None]],
        allowlist: set[str],
        denylist: set[str],
        unknown_sev: DiagnosticSeverity | None,
        policy_sev: DiagnosticSeverity,
    ) -> None:
        resolved = _resolve_license_from_installed(dep.name)
        if resolved is None:
            self._add_unknown_license_diagnostic(dep, result=result, seen=seen, unknown_sev=unknown_sev)
            return
        if denylist and _matches_any(denylist, resolved):
            self._add_policy_diagnostic(
                dep,
                resolved,
                result=result,
                seen=seen,
                code="POL-LIC-001",
                policy="denylist",
                severity=policy_sev,
                message=(
                    f"Dependency '{dep.name}' uses a blocked license "
                    f"({resolved.raw}) ({dep.file_path.name}{_fmt_line(dep.line)})."
                ),
                fix_suggestion="Remove the dependency or replace it with an allowed alternative.",
            )
            return
        if allowlist and not _matches_any(allowlist, resolved):
            self._add_policy_diagnostic(
                dep,
                resolved,
                result=result,
                seen=seen,
                code="POL-LIC-003",
                policy="allowlist",
                severity=policy_sev,
                message=(
                    f"Dependency '{dep.name}' license is not allowed by allowlist policy "
                    f"({resolved.raw}) ({dep.file_path.name}{_fmt_line(dep.line)})."
                ),
                fix_suggestion="Adjust license allowlist or choose a dependency with an allowed license.",
            )

    def _add_unknown_license_diagnostic(
        self,
        dep: _DeclaredDependency,
        *,
        result: ValidationResult,
        seen: set[tuple[str, str, str, int | None]],
        unknown_sev: DiagnosticSeverity | None,
    ) -> None:
        if unknown_sev is None:
            return
        key = _diagnostic_key("POL-LIC-002", dep)
        if key in seen:
            return
        seen.add(key)
        result.add_diagnostic(
            self._create_diagnostic(
                code="POL-LIC-002",
                message=(
                    f"License for dependency '{dep.name}' could not be resolved from installed metadata "
                    f"({dep.file_path.name}{_fmt_line(dep.line)}). "
                    "Interpreting as proprietary (unknown license)."
                ),
                severity=unknown_sev,
                file_path=dep.file_path,
                line=dep.line,
                fix_suggestion=(
                    "Install dependencies in the environment or "
                    "configure policy to ignore unknown licenses."
                ),
                data={
                    "dependency": dep.name,
                    "policy": "unknown",
                    "assumedLicense": "proprietary",
                    "assumption": "unknown licenses are treated as proprietary",
                },
            )
        )

    def _add_policy_diagnostic(
        self,
        dep: _DeclaredDependency,
        resolved: _ResolvedLicense,
        *,
        result: ValidationResult,
        seen: set[tuple[str, str, str, int | None]],
        code: str,
        policy: str,
        severity: DiagnosticSeverity,
        message: str,
        fix_suggestion: str,
    ) -> None:
        key = _diagnostic_key(code, dep)
        if key in seen:
            return
        seen.add(key)
        result.add_diagnostic(
            self._create_diagnostic(
                code=code,
                message=message,
                severity=severity,
                file_path=dep.file_path,
                line=dep.line,
                fix_suggestion=fix_suggestion,
                data={
                    "dependency": dep.name,
                    "policy": policy,
                    "licenses": sorted(resolved.names),
                    "source": resolved.source,
                },
            )
        )

    def _collect_declared_dependencies(self) -> Iterable[_DeclaredDependency]:
        yield from self._collect_from_pyproject(include_optional=True)
        yield from self._collect_from_requirements_files()
        yield from self._collect_from_setup_py()

    def _collect_from_pyproject(self, *, include_optional: bool) -> Iterable[_DeclaredDependency]:
        pyproject_path = self.project_root / "pyproject.toml"
        if not pyproject_path.exists():
            return

        data = _load_pyproject_toml(pyproject_path)
        if not data:
            return

        project = data.get("project")
        if not isinstance(project, dict):
            return

        for raw in _iter_pyproject_dependency_strings(project, include_optional=include_optional):
            req = _parse_requirement(raw)
            if req is None:
                continue
            yield _DeclaredDependency(
                name=req.name.lower(),
                requirement=raw,
                file_path=pyproject_path,
                line=None,
            )

    def _collect_from_requirements_files(self) -> Iterable[_DeclaredDependency]:
        files = [
            "requirements.txt",
            "requirements-dev.txt",
            "requirements-test.txt",
        ]

        for filename in files:
            path = self.project_root / filename
            if not path.exists():
                continue

            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except Exception as e:
                logger.debug(f"Failed to read {filename}: {e}")
                continue

            for line_no, line in enumerate(lines, start=1):
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                if stripped.startswith("-"):
                    continue

                req = _parse_requirement(stripped)
                if req is None:
                    continue

                yield _DeclaredDependency(
                    name=req.name.lower(),
                    requirement=stripped,
                    file_path=path,
                    line=line_no,
                )

    def _collect_from_setup_py(self) -> Iterable[_DeclaredDependency]:
        setup_path = self.project_root / "setup.py"
        if not setup_path.exists():
            return

        try:
            content = setup_path.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(setup_path))
        except Exception:
            return

        for raw in _collect_setup_install_requires(tree):
            req = _parse_requirement(raw)
            if req is None:
                continue
            yield _DeclaredDependency(
                name=req.name.lower(),
                requirement=raw,
                file_path=setup_path,
                line=None,
            )


def _safe_classifier_list(meta: Any) -> list[str]:
    try:
        values = list(meta.get_all("Classifier") or [])
    except Exception:
        return []
    return [v for v in values if isinstance(v, str)]


def _collect_setup_install_requires(tree: ast.AST) -> list[str]:
    install_requires: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _get_call_name(node.func) != "setup":
            continue
        for keyword in node.keywords:
            if keyword.arg != "install_requires":
                continue
            value = _extract_string_list(keyword.value)
            if value:
                install_requires.extend(value)
    return install_requires


def _license_names_from_metadata(license_field: str, classifiers: list[str]) -> set[str]:
    names: set[str] = set()

    if license_field and license_field.lower() not in {"unknown", "n/a", "none"}:
        names.add(_normalize_license_string(license_field))

    for classifier in classifiers:
        if not classifier.startswith("License ::"):
            continue
        tail = classifier.split("::")[-1].strip()
        if tail:
            names.add(_normalize_license_string(tail))

    return names


def _raw_license_from_metadata(license_field: str, classifiers: list[str]) -> str:
    if license_field:
        return license_field.strip() or "UNKNOWN"

    license_classifiers = [c for c in classifiers if c.startswith("License ::")]
    raw = "; ".join(license_classifiers).strip()
    return raw or "UNKNOWN"


def _resolve_license_from_installed(package_name: str) -> _ResolvedLicense | None:
    try:
        dist = md.distribution(package_name)
    except Exception:
        return None

    meta = dist.metadata
    license_field = (meta.get("License") or "").strip()
    classifiers = _safe_classifier_list(meta)
    names = _license_names_from_metadata(license_field, classifiers)
    if not names:
        return None

    raw = _raw_license_from_metadata(license_field, classifiers)
    return _ResolvedLicense(names=names, raw=raw, source="installed")


def _normalize_license_string(value: str) -> str:
    # Minimal normalization; policy matching uses substring matching.
    return " ".join(value.strip().lower().split())


def _matches_any(policies: set[str], resolved: _ResolvedLicense) -> bool:
    raw = resolved.raw.lower()
    for item in policies:
        if not item:
            continue
        if any(item in name for name in resolved.names):
            return True
        if item in raw:
            return True
    return False


def _parse_requirement(raw: str) -> Requirement | None:
    try:
        return Requirement(raw)
    except InvalidRequirement:
        return None


def _normalize_list(value: Any) -> set[str]:
    if not value:
        return set()
    if not isinstance(value, list):
        return set()
    out: set[str] = set()
    for item in value:
        if isinstance(item, str) and item.strip():
            out.add(item.strip().lower())
    return out


def _parse_severity(
    value: Any,
    *,
    default: DiagnosticSeverity,
    allow_ignore: bool,
) -> DiagnosticSeverity | None:
    if isinstance(value, str):
        v = value.strip().lower()
        if allow_ignore and v == "ignore":
            return None
        for sev in DiagnosticSeverity:
            if sev.value == v:
                return sev
    return default


def _fmt_line(line: int | None) -> str:
    return f":{line}" if line else ""


def _diagnostic_key(code: str, dep: _DeclaredDependency) -> tuple[str, str, str, int | None]:
    return code, dep.name, str(dep.file_path), dep.line


def _get_call_name(node: ast.expr) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _extract_string_list(node: ast.expr) -> list[str]:
    if isinstance(node, (ast.List, ast.Tuple)):
        out: list[str] = []
        for el in node.elts:
            if isinstance(el, ast.Constant) and isinstance(el.value, str):
                out.append(el.value)
        return out
    return []
