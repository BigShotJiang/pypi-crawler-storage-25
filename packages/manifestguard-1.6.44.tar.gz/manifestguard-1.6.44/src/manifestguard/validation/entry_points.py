"""Entry Point Validator

Validates that entry points (console_scripts, gui_scripts) target existing modules.
Uses AST-based module detection to check if targets resolve.
"""

import ast
from pathlib import Path
from typing import Any

from .base import DiagnosticSeverity, ManifestValidator, ValidationResult


class EntryPointValidator(ManifestValidator):
    """Validator for entry points (console_scripts, gui_scripts)

    Checks:
    1. Entry point format (module:function)
    2. Target module exists in project
    3. Target function/attribute exists (best effort)
    4. Module is importable (syntax check)

    Diagnostic Codes:
    - EP-001: Entry point targets non-existent module
    - EP-002: Entry point has invalid format
    - EP-003: Target function not found (warning)
    - EP-004: Module has syntax errors

    Example:
        >>> validator = EntryPointValidator(Path("/project"))
        >>> result = validator.validate()
        >>> for diag in result.diagnostics:
        ...     print(f"{diag.code}: {diag.message}")

    """

    def __init__(self, project_root: Path, config: dict[str, Any] | None = None):
        super().__init__(project_root, config)
        self.entry_points: list[tuple[str, str, Path]] = []
        self.source_dirs = self._find_source_dirs()
        self.search_roots = self._build_search_roots()

    def validate(self) -> ValidationResult:
        """Validate entry point declarations and return aggregated diagnostics."""
        result = ValidationResult()
        self.entry_points.clear()

        self._load_entry_points(result)

        for name, target, source_path in self.entry_points:
            self._validate_entry_point(name, target, source_path, result)

        return result

    def _find_source_dirs(self) -> list[Path]:
        """Locate source directories by scanning src/ and package roots."""
        source_dirs: list[Path] = []

        src_dir = self.project_root / "src"
        if src_dir.exists() and src_dir.is_dir():
            for item in src_dir.iterdir():
                if item.is_dir() and not item.name.startswith("."):
                    source_dirs.append(item)

        for item in self.project_root.iterdir():
            if item.is_dir() and not item.name.startswith(".") and (item / "__init__.py").exists():
                source_dirs.append(item)

        return source_dirs

    def _build_search_roots(self) -> list[Path]:
        """Create search roots including packages, src, and project root."""
        seen: set[Path] = set()
        roots: list[Path] = []

        for directory in self.source_dirs:
            if directory not in seen:
                roots.append(directory)
                seen.add(directory)

        src_dir = self.project_root / "src"
        if src_dir.exists() and src_dir.is_dir() and src_dir not in seen:
            roots.append(src_dir)
            seen.add(src_dir)

        if self.project_root not in seen:
            roots.append(self.project_root)

        return roots

    def _load_entry_points(self, result: ValidationResult) -> None:
        """Load entry points from pyproject.toml and setup.py if present."""
        pyproject_path = self.project_root / "pyproject.toml"
        if pyproject_path.exists():
            self._load_from_pyproject(pyproject_path, result)

        setup_path = self.project_root / "setup.py"
        if setup_path.exists():
            self._load_from_setup_py(setup_path, result)

    def _load_from_pyproject(self, pyproject_path: Path, result: ValidationResult) -> None:
        """Parse pyproject.toml and collect declared entry points."""
        try:
            import sys  # noqa: PLC0415 - version check for tomllib availability

            if sys.version_info >= (3, 11):
                import tomllib  # noqa: PLC0415 - version-specific import (3.11+)
            else:
                try:
                    import tomli as tomllib  # noqa: PLC0415 - backport for <3.11
                except ImportError:
                    return

            with pyproject_path.open("rb") as buffer:
                data = tomllib.load(buffer)

            project = data.get("project", {})
            if not isinstance(project, dict):
                return

            scripts = project.get("scripts")
            self._collect_entry_points(scripts, pyproject_path)

            gui_scripts = project.get("gui-scripts")
            self._collect_entry_points(gui_scripts, pyproject_path)

            entry_points = project.get("entry-points")
            if isinstance(entry_points, dict):
                for group in entry_points.values():
                    self._collect_entry_points(group, pyproject_path)

            result.validated_files.append(pyproject_path)
        except Exception:
            # Ignore parsing errors here; PyprojectValidator will report details.
            return

    def _load_from_setup_py(self, setup_path: Path, result: ValidationResult) -> None:
        """Parse setup.py AST to capture entry_points argument content."""
        try:
            content = setup_path.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(setup_path))
        except (OSError, SyntaxError):
            # SetupPyValidator will surface these issues
            return

        entry_points = self._extract_setup_entry_points(tree)
        if not entry_points:
            return

        for group in entry_points.values():
            self._collect_entry_points(group, setup_path)

        result.validated_files.append(setup_path)

    def _collect_entry_points(self, raw: Any, source_path: Path) -> None:
        """Normalize dict/list entry point declarations into internal list."""
        if isinstance(raw, dict):
            for name, target in raw.items():
                if isinstance(name, str) and isinstance(target, str):
                    self.entry_points.append((name.strip(), target.strip(), source_path))
        elif isinstance(raw, list):
            for entry in raw:
                if isinstance(entry, str) and "=" in entry:
                    name_part, _, target_part = entry.partition("=")
                    self.entry_points.append((name_part.strip(), target_part.strip(), source_path))

    def _extract_setup_entry_points(self, tree: ast.AST) -> dict[str, Any]:
        """Extract entry_points keyword argument from setup() call."""
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            func_name = self._get_function_name(node.func)
            if func_name != "setup":
                continue

            for keyword in node.keywords:
                if keyword.arg == "entry_points":
                    try:
                        value = ast.literal_eval(keyword.value)
                    except Exception:
                        return {}

                    if isinstance(value, dict):
                        return value

        return {}

    @staticmethod
    def _get_function_name(node: ast.expr) -> str | None:
        """Return function name for a Call node without executing it."""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        return None

    def _validate_entry_point(
        self,
        name: str,
        target: str,
        source_path: Path,
        result: ValidationResult,
    ) -> None:
        """Validate a single entry point target for format and existence."""
        if ":" not in target:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="EP-002",
                    message=f"Entry point '{name}' has invalid format (missing ':'): {target}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=source_path,
                    fix_suggestion=f'Use format: {name} = "package.module:function"',
                ),
            )
            return

        module_path, _, attr_name = target.partition(":")

        if not self._module_exists(module_path):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="EP-001",
                    message=f"Entry point '{name}' targets non-existent module: {module_path}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=source_path,
                    fix_suggestion=f"Create module {module_path} or fix the entry point target",
                    data={
                        "entry_point": name,
                        "module": module_path,
                        "target": target,
                        "attribute": attr_name,
                    },
                ),
            )
            return

        module_file = self._find_module_file(module_path)
        if module_file and not self._attribute_exists(module_file, attr_name):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="EP-003",
                    message=f"Entry point '{name}' targets '{attr_name}' which may not exist in {module_path}",
                    severity=DiagnosticSeverity.WARNING,
                    file_path=source_path,
                    fix_suggestion=f"Ensure {attr_name} is defined as a function in {module_path}",
                    data={
                        "entry_point": name,
                        "module": module_path,
                        "attribute": attr_name,
                        "target": target,
                    },
                ),
            )

    def _module_exists(self, module_path: str) -> bool:
        """Return True if a module path can be resolved under known source dirs."""
        return self._find_module_file(module_path) is not None

    def _find_module_file(self, module_path: str) -> Path | None:
        """Locate the file backing a module path inside discovered source dirs."""
        parts = module_path.split(".")

        for root in self.search_roots:
            relative_parts = parts
            if root.name == parts[0]:
                relative_parts = parts[1:]

            candidate_base = root.joinpath(*relative_parts)
            file_candidate = candidate_base.with_suffix(".py")
            if file_candidate.exists():
                return file_candidate

            package_candidate = candidate_base / "__init__.py"
            if package_candidate.exists():
                return package_candidate

        return None

    def _attribute_exists(self, module_file: Path, attr_name: str) -> bool:
        """Check via AST whether the target attribute exists within the module."""
        try:
            content = module_file.read_text(encoding="utf-8")
            tree = ast.parse(content)

            for node in ast.walk(tree):
                if (
                    isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef))
                    and node.name == attr_name
                ):
                    return True

            return False
        except Exception:
            return True
