"""setup.py Validator

Validates setup.py files using AST parsing (no code execution).
Extracts setup() call arguments and validates metadata.

Safety: Uses AST module to parse setup.py without executing code.
This prevents arbitrary code execution vulnerabilities.
"""

import ast
from pathlib import Path
from typing import Any, ClassVar

from packaging.requirements import InvalidRequirement, Requirement

from .base import DiagnosticSeverity, ManifestValidator, ValidationResult


class SetupPyValidator(ManifestValidator):
    """Validator for setup.py files (legacy format)

    Uses AST parsing to extract setup() call without executing code.

    Checks:
    1. File exists and is valid Python
    2. Contains setup() call from setuptools
    3. Required arguments (name, version)
    4. Recommended arguments (description, author, etc.)
    5. Entry points format
    6. Install_requires format

    Diagnostic Codes:
    - SET-001: setup.py not found
    - SET-002: Invalid Python syntax
    - SET-003: No setup() call found
    - SET-004: Missing required setup() argument
    - SET-005: Invalid argument type
    - SET-006: Deprecated argument
    - SET-007: Invalid entry point format
    - SET-008: Invalid install_requires entry

    Example:
        >>> validator = SetupPyValidator(Path("/project"))
        >>> result = validator.validate()
        >>> print(f"Valid: {result.is_valid}")

    """

    # Required setup() arguments
    REQUIRED_ARGS: ClassVar[list[str]] = ["name", "version"]

    # Recommended setup() arguments
    RECOMMENDED_ARGS: ClassVar[list[str]] = ["description", "author", "license", "classifiers"]

    # Deprecated arguments
    DEPRECATED_ARGS: ClassVar[dict[str, str]] = {
        "license_file": "Use license_files (plural) instead",
        "test_suite": "Use pytest or other modern test runner",
    }

    def __init__(self, project_root: Path, config: dict[str, Any] | None = None):
        """Initialize setup.py validator

        Args:
            project_root: Root directory containing setup.py
            config: Optional configuration

        """
        super().__init__(project_root, config)
        self.setup_path = self.project_root / "setup.py"
        self.setup_args: dict[str, Any] = {}

    def validate(self) -> ValidationResult:
        """Validate setup.py file

        Returns:
            ValidationResult with all diagnostics

        """
        result = ValidationResult(validated_files=[self.setup_path])

        # Check if file exists
        if not self.setup_path.exists():
            # Not an error if project uses pyproject.toml
            return result

        # Parse setup.py
        if not self._parse_setup_py(result):
            return result

        # Validate setup() call
        if not self.setup_args:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-003",
                    message="No setup() call found in setup.py",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                    fix_suggestion="Add setup() call from setuptools",
                ),
            )
            return result

        # Validate arguments
        self._validate_required_args(result)
        self._validate_recommended_args(result)
        self._check_deprecated_args(result)
        self._validate_entry_points(result)
        self._validate_install_requires(result)

        return result

    def _parse_setup_py(self, result: ValidationResult) -> bool:
        """Parse setup.py using AST

        Args:
            result: ValidationResult to add diagnostics to

        Returns:
            True if parsing succeeded, False otherwise

        """
        try:
            content = self.setup_path.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(self.setup_path))
        except SyntaxError as e:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-002",
                    message=f"Invalid Python syntax: {e}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                    line=e.lineno,
                ),
            )
            return False
        except Exception as e:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-002",
                    message=f"Error reading setup.py: {e}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                ),
            )
            return False

        # Extract setup() call arguments
        self.setup_args = self._extract_setup_call(tree)
        return True

    def _extract_setup_call(self, tree: ast.Module) -> dict[str, Any]:
        """Extract setup() call arguments from AST

        Args:
            tree: Parsed AST

        Returns:
            Dictionary of setup() arguments

        """
        args: dict[str, Any] = {}

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                # Check if this is setup() call
                func_name = self._get_function_name(node.func)
                if func_name == "setup":
                    # Extract keyword arguments
                    for keyword in node.keywords:
                        if keyword.arg:
                            args[keyword.arg] = self._extract_value(keyword.value)

        return args

    @staticmethod
    def _get_function_name(node: ast.expr) -> str | None:
        """Get function name from call expression

        Args:
            node: AST node

        Returns:
            Function name or None

        """
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        return None

    def _extract_value(self, node: ast.expr) -> Any:
        """Extract value from AST node (simplified)

        Args:
            node: AST node

        Returns:
            Extracted value (str, list, dict, etc.) or None

        """
        if isinstance(node, ast.Constant):
            return node.value
        if type(node).__name__ == "Str":  # Python 3.7 compatibility without ast.Str
            return getattr(node, "s", None)
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            return [self._extract_value(el) for el in node.elts]
        if isinstance(node, ast.Dict):
            return {
                self._extract_value(k): self._extract_value(v)
                for k, v in zip(node.keys, node.values, strict=False)
                if k is not None
            }
        return None

    def _validate_required_args(self, result: ValidationResult) -> None:
        """Validate required setup() arguments

        Args:
            result: ValidationResult to add diagnostics to

        """
        for arg in self.REQUIRED_ARGS:
            if arg not in self.setup_args:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="SET-004",
                        message=f"Required argument '{arg}' missing from setup() call",
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.setup_path,
                        fix_suggestion=f"Add {arg}='...' to setup() call",
                    ),
                )
            elif not self.setup_args[arg]:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="SET-005",
                        message=f"Argument '{arg}' is empty",
                        severity=DiagnosticSeverity.WARNING,
                        file_path=self.setup_path,
                    ),
                )

    def _validate_recommended_args(self, result: ValidationResult) -> None:
        """Check for recommended arguments

        Args:
            result: ValidationResult to add diagnostics to

        """
        for arg in self.RECOMMENDED_ARGS:
            if arg not in self.setup_args:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="SET-004",
                        message=f"Recommended argument '{arg}' missing from setup() call",
                        severity=DiagnosticSeverity.INFO,
                        file_path=self.setup_path,
                    ),
                )

    def _check_deprecated_args(self, result: ValidationResult) -> None:
        """Check for deprecated arguments

        Args:
            result: ValidationResult to add diagnostics to

        """
        for arg, message in self.DEPRECATED_ARGS.items():
            if arg in self.setup_args:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="SET-006",
                        message=f"Deprecated argument '{arg}' used. {message}",
                        severity=DiagnosticSeverity.WARNING,
                        file_path=self.setup_path,
                    ),
                )

    def _validate_entry_points(self, result: ValidationResult) -> None:
        """Validate entry_points format

        Args:
            result: ValidationResult to add diagnostics to

        """
        if "entry_points" not in self.setup_args:
            return

        entry_points = self.setup_args["entry_points"]

        if not isinstance(entry_points, dict):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-007",
                    message="entry_points must be a dictionary",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                ),
            )
            return

        for group, entries in entry_points.items():
            self._validate_entry_point_group(group, entries, result)

    def _validate_entry_point_group(
        self,
        group: str,
        entries: Any,
        result: ValidationResult,
    ) -> None:
        if isinstance(entries, dict):
            for name, target in entries.items():
                self._validate_entry_point_mapping(group, name, target, result)
            return

        if isinstance(entries, list):
            for item in entries:
                self._validate_entry_point_list_item(group, item, result)
            return

        if isinstance(entries, str):
            self._validate_entry_point_target(group, group, entries.strip(), result)
            return

        if entries is not None:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-007",
                    message=f"Entry point group '{group}' must be a list or dict",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                ),
            )

    def _validate_entry_point_mapping(
        self,
        group: str,
        name: Any,
        target: Any,
        result: ValidationResult,
    ) -> None:
        if not isinstance(name, str) or not isinstance(target, str):
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-007",
                    message=f"Entry point group '{group}' must map strings to strings",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                ),
            )
            return

        self._validate_entry_point_target(group, name.strip(), target.strip(), result)

    def _validate_entry_point_list_item(
        self,
        group: str,
        item: Any,
        result: ValidationResult,
    ) -> None:
        if not isinstance(item, str) or "=" not in item:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-007",
                    message=f"Invalid entry point declaration in group '{group}': {item}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                    fix_suggestion="Use format: 'command = package.module:function'",
                ),
            )
            return

        name_part, _, target_part = item.partition("=")
        self._validate_entry_point_target(group, name_part.strip(), target_part.strip(), result)

    def _validate_entry_point_target(
        self,
        group: str,
        name: str,
        target: str,
        result: ValidationResult,
    ) -> None:
        if not target:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-007",
                    message=f"Entry point '{name}' in group '{group}' is empty",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                ),
            )
            return

        if ":" not in target:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-007",
                    message=f"Entry point '{name}' in group '{group}' must be in 'module:function' format",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                    fix_suggestion=f"Use format: {name} = package.module:function",
                ),
            )
            return

        module_path, _, attr_name = target.partition(":")
        if not module_path or not attr_name:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-007",
                    message=f"Entry point '{name}' in group '{group}' must reference module and callable",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                    fix_suggestion=f"Use format: {name} = package.module:function",
                ),
            )

    def _validate_install_requires(self, result: ValidationResult) -> None:
        """Validate install_requires entries using packaging requirement parser."""
        if "install_requires" not in self.setup_args:
            return

        requirements = self._normalize_install_requires(self.setup_args["install_requires"], result)
        if requirements is None:
            return

        seen: set[str] = set()
        for index, dep in enumerate(requirements):
            self._validate_single_requirement(dep, index, seen, result)

    def _normalize_install_requires(
        self,
        raw_value: Any,
        result: ValidationResult,
    ) -> list[str] | None:
        if isinstance(raw_value, str):
            return [raw_value]
        if isinstance(raw_value, (list, tuple, set)):
            return [str(item) for item in raw_value]

        result.add_diagnostic(
            self._create_diagnostic(
                code="SET-008",
                message="install_requires must be a list of strings",
                severity=DiagnosticSeverity.ERROR,
                file_path=self.setup_path,
            ),
        )
        return None

    def _validate_single_requirement(
        self,
        dep: Any,
        index: int,
        seen: set[str],
        result: ValidationResult,
    ) -> None:
        if not isinstance(dep, str) or not dep.strip():
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-008",
                    message=f"install_requires entry at index {index} must be a non-empty string",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                ),
            )
            return

        try:
            requirement = Requirement(dep)
        except InvalidRequirement as exc:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-008",
                    message=f"Invalid requirement '{dep}': {exc}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=self.setup_path,
                    fix_suggestion="Use valid PEP 508 requirement syntax",
                ),
            )
            return

        normalized = requirement.name.lower()
        if normalized in seen:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-008",
                    message=f"Duplicate requirement '{requirement.name}' in install_requires",
                    severity=DiagnosticSeverity.WARNING,
                    file_path=self.setup_path,
                    fix_suggestion="Remove duplicate entry",
                ),
            )
        else:
            seen.add(normalized)

        if not requirement.specifier:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="SET-008",
                    message=f"Requirement '{requirement.name}' has no version constraint",
                    severity=DiagnosticSeverity.INFO,
                    file_path=self.setup_path,
                    fix_suggestion=f"Add version specifier for {requirement.name}",
                ),
            )
