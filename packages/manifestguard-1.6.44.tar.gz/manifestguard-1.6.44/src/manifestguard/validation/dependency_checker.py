"""Dependency Conflict Checker

Detects version conflicts and incompatibilities between dependencies.
"""

import re
from pathlib import Path
from typing import Any

from .base import DiagnosticSeverity, ManifestValidator, ValidationResult


class DependencyConflictChecker(ManifestValidator):
    """Checker for dependency conflicts

    Checks:
    1. Conflicts between pyproject.toml and requirements.txt
    2. Incompatible version specifiers
    3. Duplicate dependencies with different versions

    Diagnostic Codes:
    - DEP-001: Dependency conflict between files
    - DEP-002: Incompatible version specifiers
    - DEP-003: Duplicate with different version

    Example:
        >>> checker = DependencyConflictChecker(Path("/project"))
        >>> result = checker.validate()
        >>> print(f"Conflicts: {result.error_count}")

    """

    VERSION_PATTERN = re.compile(
        r"([a-zA-Z0-9\-_.]+)"  # Package name
        r"(?:\[([^\]]+)\])?"  # Optional extras
        r"(?:\s*([<>=!~]+)\s*([0-9.*]+(?:[.][0-9.*]+)*))?",  # Version specifier
    )

    def __init__(self, project_root: Path, config: dict[str, Any] | None = None):
        """Initialize dependency conflict checker

        Args:
            project_root: Root directory of the project
            config: Optional configuration

        """
        super().__init__(project_root, config)

    def validate(self) -> ValidationResult:
        """Check for dependency conflicts

        Returns:
            ValidationResult with all diagnostics

        """
        result = ValidationResult()

        # Load dependencies from all sources
        pyproject_deps = self._load_pyproject_dependencies()
        requirements_deps = self._load_requirements_dependencies()

        # Detect conflicts within individual sources
        self._detect_internal_conflicts(
            pyproject_deps, self.project_root / "pyproject.toml", result
        )
        self._detect_internal_conflicts(
            requirements_deps, self.project_root / "requirements.txt", result
        )

        # Check for conflicts
        self._check_conflicts(pyproject_deps, requirements_deps, result)

        return result

    def _load_pyproject_dependencies(self) -> dict[str, list[str]]:
        """Load dependencies from pyproject.toml

        Returns:
            Dictionary mapping package names to version specifiers

        """
        deps: dict[str, list[str]] = {}
        pyproject_path = self.project_root / "pyproject.toml"

        if not pyproject_path.exists():
            return deps

        try:
            import sys  # noqa: PLC0415 - version check for tomllib availability

            if sys.version_info >= (3, 11):
                import tomllib  # noqa: PLC0415 - version-specific import (3.11+)
            else:
                try:
                    import tomli as tomllib  # noqa: PLC0415 - backport for <3.11
                except ImportError:
                    return deps

            with pyproject_path.open("rb") as f:
                data = tomllib.load(f)

            project = data.get("project", {})
            dependencies = project.get("dependencies", [])

            for dep in dependencies:
                if isinstance(dep, str):
                    name, version = self._parse_dependency(dep)
                    if name:
                        if name not in deps:
                            deps[name] = []
                        if version:
                            deps[name].append(version)
        except Exception:
            pass

        return deps

    def _load_requirements_dependencies(self) -> dict[str, list[str]]:
        """Load dependencies from requirements.txt

        Returns:
            Dictionary mapping package names to version specifiers

        """
        deps: dict[str, list[str]] = {}
        req_path = self.project_root / "requirements.txt"

        if not req_path.exists():
            return deps

        try:
            lines = req_path.read_text(encoding="utf-8").splitlines()

            for line in lines:
                stripped = line.strip()
                if not stripped or stripped.startswith("#") or stripped.startswith("-"):
                    continue

                name, version = self._parse_dependency(stripped)
                if name:
                    if name not in deps:
                        deps[name] = []
                    if version:
                        deps[name].append(version)
        except Exception:
            pass

        return deps

    def _parse_dependency(self, dep: str) -> tuple[str | None, str | None]:
        """Parse dependency string

        Args:
            dep: Dependency string (e.g., "requests>=2.0.0")

        Returns:
            Tuple of (package_name, version_specifier)

        """
        match = self.VERSION_PATTERN.match(dep)
        if match:
            name = match.group(1).lower()
            operator = match.group(3)
            version = match.group(4)

            if operator and version:
                return name, f"{operator}{version}"
            return name, None
        return None, None

    def _check_conflicts(
        self,
        pyproject_deps: dict[str, list[str]],
        requirements_deps: dict[str, list[str]],
        result: ValidationResult,
    ) -> None:
        """Check for conflicts between dependency sources

        Args:
            pyproject_deps: Dependencies from pyproject.toml
            requirements_deps: Dependencies from requirements.txt
            result: ValidationResult to add diagnostics to

        """
        all_packages = set(pyproject_deps.keys()) | set(requirements_deps.keys())

        for package in all_packages:
            pyproject_versions = pyproject_deps.get(package, [])
            requirements_versions = requirements_deps.get(package, [])

            has_conflict = (
                pyproject_versions
                and requirements_versions
                and not self._versions_compatible(pyproject_versions, requirements_versions)
            )
            if has_conflict:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="DEP-001",
                        message=(
                            f"Dependency conflict for '{package}': "
                            f"pyproject.toml specifies {pyproject_versions}, "
                            f"requirements.txt specifies {requirements_versions}"
                        ),
                        severity=DiagnosticSeverity.ERROR,
                        file_path=self.project_root / "pyproject.toml",
                        fix_suggestion="Align versions between pyproject.toml and requirements.txt",
                    ),
                )

    def _detect_internal_conflicts(
        self,
        deps: dict[str, list[str]],
        file_path: Path,
        result: ValidationResult,
    ) -> None:
        """Detect conflicting exact version pins within a single manifest."""
        for package, versions in deps.items():
            exact_versions = {v for v in versions if v.startswith("==")}
            if len(exact_versions) > 1:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="DEP-003",
                        message=(
                            f"Package '{package}' pinned to multiple versions "
                            f"{sorted(exact_versions)} in {file_path.name}"
                        ),
                        severity=DiagnosticSeverity.ERROR,
                        file_path=file_path,
                        fix_suggestion="Keep a single exact version pin per package",
                    ),
                )

    @staticmethod
    def _versions_compatible(versions1: list[str], versions2: list[str]) -> bool:
        """Check if version specifiers are compatible (simplified)

        Args:
            versions1: List of version specifiers
            versions2: List of version specifiers

        Returns:
            True if compatible, False otherwise

        """
        exact1 = {v for v in versions1 if v.startswith("==")}
        exact2 = {v for v in versions2 if v.startswith("==")}

        if exact1 and exact2:
            return not exact1.isdisjoint(exact2)

        # Fallback: if either side lacks exact pins, assume compatibility for now
        return True
