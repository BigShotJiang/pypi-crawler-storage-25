from __future__ import annotations

import ast
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

__MGVS_TRANSFER_IMPLEMENTED__ = True


ImportCategory = Literal["stdlib", "third-party", "local", "unknown"]


@dataclass(frozen=True)
class PythonImport:
    type: Literal["import", "from"]
    module: str
    names: list[str]
    line: int
    statement: str
    category: ImportCategory
    alias: str | None = None


@dataclass(frozen=True)
class ImportIssue:
    type: Literal[
        "unused-import", "import-order-violation", "missing-dependency", "circular-import"
    ]
    severity: Literal["error", "warning", "info"]
    message: str
    file: str
    line: int


# Intentionally complex for comprehensive AST-based import extraction with multiple node types
# manifestguard-ignore-next-line: COMPLEXITY
def extract_imports(content: str, _file_path: str) -> list[PythonImport]:
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []

    imports: list[PythonImport] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                module = alias.name
                statement = ast.get_source_segment(content, node) or ""
                imports.append(
                    PythonImport(
                        type="import",
                        module=module,
                        names=[],
                        alias=alias.asname,
                        line=getattr(node, "lineno", 1),
                        statement=statement,
                        category=_categorize_module(module, is_relative=False),
                    ),
                )
        elif isinstance(node, ast.ImportFrom):
            dots = "." * int(getattr(node, "level", 0) or 0)
            mod = getattr(node, "module", None)
            module = f"{dots}{mod or ''}" if dots else (mod or "")
            statement = ast.get_source_segment(content, node) or ""
            names = [a.name for a in node.names if isinstance(a, ast.alias)]
            is_relative = bool(dots)
            imports.append(
                PythonImport(
                    type="from",
                    module=module,
                    names=names,
                    alias=None,
                    line=getattr(node, "lineno", 1),
                    statement=statement,
                    category=_categorize_module(module, is_relative=is_relative),
                ),
            )

    imports.sort(key=lambda i: i.line)
    return imports


def detect_unused_imports(content: str, file_path: str) -> list[ImportIssue]:
    imports = extract_imports(content, file_path)
    if not imports:
        return []

    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []

    used_names: set[str] = set()

    class _UsageCollector(ast.NodeVisitor):
        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            module = node.module or ""
            for alias in node.names:
                if alias.name == "*" and module:
                    # Star-import: record module name to suppress false positives.
                    used_names.add(module.split(".")[0])
            self.generic_visit(node)

        def visit_Name(self, node: ast.Name) -> None:
            if isinstance(node.ctx, ast.Load):
                used_names.add(node.id)

    _UsageCollector().visit(tree)

    issues: list[ImportIssue] = []
    for imp in imports:
        used_name = _used_name_for_import(imp)
        if not used_name:
            continue

        if used_name not in used_names:
            issues.append(
                ImportIssue(
                    type="unused-import",
                    severity="warning",
                    message=f"Unused import: {imp.module}",
                    file=file_path,
                    line=imp.line,
                ),
            )

    issues.sort(key=lambda i: i.line)
    return issues


def check_import_order(content: str, file_path: str) -> list[ImportIssue]:
    imports = extract_imports(content, file_path)
    if not imports:
        return []

    order_map = {"stdlib": 0, "third-party": 1, "local": 2, "unknown": 3}
    last_category: str | None = None
    last_order = -1
    issues: list[ImportIssue] = []

    for imp in imports:
        current_order = order_map.get(imp.category, 3)
        if last_category is not None and current_order < last_order:
            issues.append(
                ImportIssue(
                    type="import-order-violation",
                    severity="info",
                    message=f"Import order violation: {imp.category} import after {last_category}",
                    file=file_path,
                    line=imp.line,
                ),
            )

        last_category = imp.category
        last_order = current_order

    issues.sort(key=lambda i: i.line)
    return issues


def _categorize_module(module: str, *, is_relative: bool) -> ImportCategory:
    if is_relative or module.startswith("."):
        return "local"

    base = module.split(".", 1)[0]

    stdlib_names = getattr(sys, "stdlib_module_names", None)
    if stdlib_names is None:
        # Conservative fallback for older Pythons.
        stdlib_names = set(sys.builtin_module_names)

    if base in stdlib_names:
        return "stdlib"

    return "third-party"


def _used_name_for_import(imp: PythonImport) -> str | None:
    if imp.type == "import":
        if imp.alias:
            return imp.alias
        return imp.module.split(".", 1)[0]
    if imp.type == "from":
        # For contract scope, we only need basic behavior.
        if imp.names:
            return imp.names[0]
        return None
    return None  # type: ignore[unreachable]


def _normalize_package_name(name: str) -> str:
    """Normalize package name per PEP 503: case-insensitive, _ and - equivalent."""
    return name.lower().replace("_", "-")


def parse_requirements_txt(content: str) -> set[str]:
    """Parse requirements.txt format and extract package names.
    
    Handles:
    - Simple declarations: requests, flask
    - Version specifiers: requests>=2.0.0, pytest==7.0.0
    - Comments and empty lines
    - Editable installs: -e git+...#egg=package
    """
    packages: set[str] = set()
    
    for line in content.splitlines():
        trimmed = line.strip()
        
        # Skip empty lines and comments
        if not trimmed or trimmed.startswith("#"):
            continue
        
        # Handle editable installs: -e git+...#egg=package
        if trimmed.startswith("-e") and "#egg=" in trimmed:
            egg_match = re.search(r"#egg=([a-zA-Z0-9_-]+)", trimmed)
            if egg_match:
                packages.add(_normalize_package_name(egg_match.group(1)))
            continue
        
        # Skip other options (-r, --index-url, etc.)
        if trimmed.startswith("-"):
            continue
        
        # Extract package name (before ==, >=, <=, ~=, !=, <, >, [, @, etc.)
        match = re.match(r"^([a-zA-Z0-9_-]+)", trimmed)
        if match:
            packages.add(_normalize_package_name(match.group(1)))
    
    return packages


def parse_pyproject_toml(content: str) -> set[str]:
    """Parse pyproject.toml format and extract dependencies.
    
    Handles:
    - [project] dependencies array: dependencies = ["package>=1.0"]
    - [tool.poetry.dependencies] section (Poetry format)
    """
    packages: set[str] = set()
    
    # Match: dependencies = [ "package>=1.0", "other" ]
    deps_array_match = re.search(r"dependencies\s*=\s*\[([\s\S]*?)\]", content)
    if deps_array_match:
        deps_str = deps_array_match.group(1)
        for match in re.finditer(r'"([a-zA-Z0-9_-]+)[^"]*"', deps_str):
            packages.add(_normalize_package_name(match.group(1)))
    
    # Match: [tool.poetry.dependencies]
    poetry_match = re.search(r"\[tool\.poetry\.dependencies\]([\s\S]*?)(?=\[|$)", content)
    if poetry_match:
        section = poetry_match.group(1)
        for match in re.finditer(r"^([a-zA-Z0-9_-]+)\s*=", section, re.MULTILINE):
            pkg = match.group(1)
            if pkg != "python":  # Skip python version specifier
                packages.add(_normalize_package_name(pkg))
    
    return packages


def parse_pipfile(content: str) -> set[str]:
    """Parse Pipfile format and extract dependencies.
    
    Handles:
    - [packages] section
    - [dev-packages] section
    """
    packages: set[str] = set()
    
    # Match: [packages] section
    packages_match = re.search(r"\[packages\]([\s\S]*?)(?=\[|$)", content)
    if packages_match:
        section = packages_match.group(1)
        for match in re.finditer(r"^([a-zA-Z0-9_-]+)\s*=", section, re.MULTILINE):
            packages.add(_normalize_package_name(match.group(1)))
    
    # Match: [dev-packages] section
    dev_match = re.search(r"\[dev-packages\]([\s\S]*?)(?=\[|$)", content)
    if dev_match:
        section = dev_match.group(1)
        for match in re.finditer(r"^([a-zA-Z0-9_-]+)\s*=", section, re.MULTILINE):
            packages.add(_normalize_package_name(match.group(1)))
    
    return packages


def collect_declared_dependencies(project_path: Path) -> set[str]:
    """Collect all declared dependencies from project dependency files.
    
    Searches for and parses:
    - requirements.txt
    - pyproject.toml
    - Pipfile
    
    Returns normalized package names (lowercase, _ → -).
    """
    declared_deps: set[str] = set()
    
    # Try requirements.txt
    req_path = project_path / "requirements.txt"
    if req_path.exists():
        try:
            content = req_path.read_text(encoding="utf-8")
            declared_deps.update(parse_requirements_txt(content))
        except Exception:
            pass
    
    # Try pyproject.toml
    pyproject_path = project_path / "pyproject.toml"
    if pyproject_path.exists():
        try:
            content = pyproject_path.read_text(encoding="utf-8")
            declared_deps.update(parse_pyproject_toml(content))
        except Exception:
            pass
    
    # Try Pipfile
    pipfile_path = project_path / "Pipfile"
    if pipfile_path.exists():
        try:
            content = pipfile_path.read_text(encoding="utf-8")
            declared_deps.update(parse_pipfile(content))
        except Exception:
            pass
    
    return declared_deps


def detect_missing_dependencies(
    content: str,
    file_path: str,
    project_path: Path,
) -> list[ImportIssue]:
    """Detect third-party imports that are not declared in dependency files.
    
    Cross-references imports with requirements.txt, pyproject.toml, and Pipfile.
    Returns issues with suggested fixes.
    """
    issues: list[ImportIssue] = []
    
    # Parse dependency files
    declared_deps = collect_declared_dependencies(project_path)
    
    if not declared_deps:
        # No dependency files found, skip check
        return issues
    
    # Extract imports
    imports = extract_imports(content, file_path)
    
    # Check each third-party import
    for imp in imports:
        if imp.category != "third-party":
            continue
        
        # Get package name (first part of module)
        package_name = _normalize_package_name(imp.module.split(".")[0])
        
        # Check if declared
        if package_name not in declared_deps:
            issues.append(
                ImportIssue(
                    type="missing-dependency",
                    severity="error",
                    message=f"Missing dependency: {package_name} (imported but not declared in dependency files)",
                    file=file_path,
                    line=imp.line,
                ),
            )
    
    issues.sort(key=lambda i: i.line)
    return issues

