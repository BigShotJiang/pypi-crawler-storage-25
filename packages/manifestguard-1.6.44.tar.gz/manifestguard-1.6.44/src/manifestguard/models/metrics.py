"""Metrics API models
"""

from pydantic import BaseModel, ConfigDict, Field


class CoverageMetrics(BaseModel):
    """Code coverage metrics"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "line_coverage": 85.5,
                "branch_coverage": 78.2,
                "total_lines": 1000,
                "covered_lines": 855,
                "missing_lines": 145,
            },
        }
    )

    line_coverage: float = Field(..., ge=0, le=100, description="Line coverage percentage")
    branch_coverage: float = Field(..., ge=0, le=100, description="Branch coverage percentage")
    total_lines: int = Field(..., ge=0, description="Total lines of code")
    covered_lines: int = Field(..., ge=0, description="Covered lines")
    missing_lines: int = Field(..., ge=0, description="Missing coverage lines")


class DependencyMetrics(BaseModel):
    """Dependency analysis metrics"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "direct_dependencies": 15,
                "transitive_dependencies": 87,
                "outdated_dependencies": 3,
                "vulnerable_dependencies": 1,
                "dependency_graph_depth": 5,
            },
        }
    )

    direct_dependencies: int = Field(..., ge=0, description="Number of direct dependencies")
    transitive_dependencies: int = Field(..., ge=0, description="Number of transitive dependencies")
    outdated_dependencies: int = Field(..., ge=0, description="Number of outdated packages")
    vulnerable_dependencies: int = Field(..., ge=0, description="Number of vulnerable packages")
    dependency_graph_depth: int = Field(..., ge=0, description="Maximum dependency depth")


class SecurityMetrics(BaseModel):
    """Security analysis metrics"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "high_severity_issues": 0,
                "medium_severity_issues": 2,
                "low_severity_issues": 5,
                "security_score": 92.0,
                "hardcoded_secrets": 0,
            },
        }
    )

    high_severity_issues: int = Field(..., ge=0, description="High severity issues")
    medium_severity_issues: int = Field(..., ge=0, description="Medium severity issues")
    low_severity_issues: int = Field(..., ge=0, description="Low severity issues")
    security_score: float = Field(..., ge=0, le=100, description="Overall security score")
    hardcoded_secrets: int = Field(..., ge=0, description="Potential hardcoded secrets")


class MetricsReport(BaseModel):
    """Complete metrics report"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "project_name": "my-project",
                "project_version": "1.0.0",
                "coverage": {
                    "line_coverage": 85.5,
                    "branch_coverage": 78.2,
                    "total_lines": 1000,
                    "covered_lines": 855,
                    "missing_lines": 145,
                },
                "dependencies": {
                    "direct_dependencies": 15,
                    "transitive_dependencies": 87,
                    "outdated_dependencies": 3,
                    "vulnerable_dependencies": 1,
                    "dependency_graph_depth": 5,
                },
                "security": {
                    "high_severity_issues": 0,
                    "medium_severity_issues": 2,
                    "low_severity_issues": 5,
                    "security_score": 92.0,
                    "hardcoded_secrets": 0,
                },
                "quality_score": 87.5,
            },
        }
    )

    project_name: str = Field(..., description="Project name")
    project_version: str = Field(..., description="Project version")
    coverage: CoverageMetrics = Field(..., description="Coverage metrics")
    dependencies: DependencyMetrics = Field(..., description="Dependency metrics")
    security: SecurityMetrics = Field(..., description="Security metrics")
    quality_score: float = Field(..., ge=0, le=100, description="Overall quality score")


class MetricsResponse(BaseModel):
    """Response model for metrics endpoint"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "report": {
                    "project_name": "my-project",
                    "project_version": "1.0.0",
                    "coverage": {"line_coverage": 85.5},
                    "dependencies": {"direct_dependencies": 15},
                    "security": {"security_score": 92.0},
                    "quality_score": 87.5,
                },
                "warnings": [],
            },
        }
    )

    success: bool = Field(..., description="Whether metrics collection succeeded")
    report: MetricsReport = Field(..., description="Metrics report")
    warnings: list[str] = Field(default_factory=list, description="Collection warnings")
