"""Base response models for API contracts
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class BaseResponse(BaseModel):
    """Base response model for all API responses"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {"success": True, "message": "Operation completed successfully"},
        },
    )

    success: bool = Field(..., description="Whether the operation succeeded")
    message: str | None = Field(None, description="Optional message")


class SuccessResponse(BaseResponse):
    """Success response with data"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "message": "Resource created",
                "data": {"id": "env-123", "name": "production"},
            },
        },
    )

    success: Literal[True] = Field(True, description="Always true for success")
    data: dict[str, Any] | None = Field(None, description="Response data")


class ErrorResponse(BaseResponse):
    """Error response with details"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": False,
                "message": "Validation failed",
                "error": "ValidationError",
                "details": {"field": "name", "reason": "Required field missing"},
            },
        },
    )

    success: Literal[False] = Field(False, description="Always false for errors")
    error: str = Field(..., description="Error type")
    details: dict[str, Any] | None = Field(None, description="Error details")
