"""Test Configuration Helper for ManifestGuard Python

Provides threshold-based test result validation and configuration management.
Port of TypeScript testConfigHelper.ts from MGVS.

Usage:
    from manifestguard.core.test_config_helper import check_thresholds, TestThresholdResult
    
    result = check_thresholds(
        test_name="complexity",
        errors=2,
        warnings=5,
        info=10,
        config=config
    )
    
    if not result.passes:
        print(f"Threshold exceeded: {result.message}")
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

logger = logging.getLogger(__name__)

Severity = Literal["error", "warning", "info"]
GateMode = Literal[
    "allowed",
    "disabled",
    "deep-analysis-disabled",
    "threshold-blocked",
]


@dataclass
class Thresholds:
    """Threshold limits for a specific test.
    
    Attributes:
        max_errors: Maximum allowed errors (None = unlimited)
        max_warnings: Maximum allowed warnings (None = unlimited)
        max_info: Maximum allowed info messages (None = unlimited)
    """

    max_errors: int | None = None
    max_warnings: int | None = None
    max_info: int | None = None


@dataclass
class Config:
    """Configuration for a specific test.
    
    Attributes:
        enabled: Whether the test is enabled
        deep_analysis_mode: Whether expensive analysis should run
        thresholds: Severity thresholds for the test
    """

    enabled: bool = True
    deep_analysis_mode: bool = False
    thresholds: Thresholds | None = None


@dataclass
class ThresholdResult:
    """Result of threshold validation.
    
    Attributes:
        passes: Whether all thresholds are satisfied
        message: Human-readable result message
        exceeded: Which thresholds were exceeded (if any)
    """

    passes: bool
    message: str
    exceeded: list[str]


@dataclass
class ThresholdGateDecision:
    """Normalized gate decision for expensive extended checks.

    Attributes:
        should_run: Whether the expensive check should execute.
        mode: Decision type for downstream reporting.
        message: Human-readable explanation.
        threshold_result: Raw threshold result when a threshold check was performed.
    """

    should_run: bool
    mode: GateMode
    message: str
    threshold_result: ThresholdResult | None = None


class ThresholdGateController:
    """Central gate controller for expensive checks.

    This class resolves test settings and validates E/W/I thresholds in one
    place so runners and report builders use identical gate semantics.
    """

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self._config = config or {}

    def _resolve_test_config(self, test_name: str) -> Config:
        return resolve_test_config_from_dict(test_name, self._config)

    def evaluate(
        self,
        *,
        test_name: str,
        errors: int | None,
        warnings: int | None,
        info: int | None,
    ) -> ThresholdGateDecision:
        """Evaluate whether a test is allowed to run under current settings.

        Threshold checks are only applied when all three counters are provided.
        """
        cfg = self._resolve_test_config(test_name)

        if not cfg.enabled:
            return ThresholdGateDecision(
                should_run=False,
                mode="disabled",
                message=(
                    f"disabled via manifestguard.json testConfig.{test_name}.enabled=false"
                ),
            )

        if not cfg.deep_analysis_mode:
            return ThresholdGateDecision(
                should_run=False,
                mode="deep-analysis-disabled",
                message=f"deep analysis disabled via testConfig.{test_name}.deepAnalysisMode=false",
            )

        if errors is None or warnings is None or info is None:
            return ThresholdGateDecision(
                should_run=True,
                mode="allowed",
                message=f"{test_name} gate passed (no runtime counts provided)",
            )

        thresholds = cfg.thresholds or Thresholds(
            max_errors=0,
            max_warnings=0,
            max_info=None,
        )
        gate_cfg = Config(
            enabled=cfg.enabled,
            deep_analysis_mode=cfg.deep_analysis_mode,
            thresholds=thresholds,
        )
        result = check_thresholds(
            test_name=test_name,
            errors=errors,
            warnings=warnings,
            info=info,
            config=gate_cfg,
        )

        if not result.passes:
            return ThresholdGateDecision(
                should_run=False,
                mode="threshold-blocked",
                message=(
                    "threshold gate not satisfied (expensive tests run only after E/W/I "
                    f"are within limits): {result.message}"
                ),
                threshold_result=result,
            )

        return ThresholdGateDecision(
            should_run=True,
            mode="allowed",
            message=result.message,
            threshold_result=result,
        )


def load_manifest_config(workspace_root: Path) -> dict[str, Any]:
    """Load manifestguard.json configuration.
    
    Args:
        workspace_root: Root directory of the workspace
        
    Returns:
        Configuration dictionary, empty dict if file not found
    """
    config_path = workspace_root / "manifestguard.json"
    if not config_path.exists():
        return {}

    try:
        with config_path.open(encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"Failed to load manifestguard.json: {e}")
        return {}


def resolve_test_config_from_dict(test_name: str, config: dict[str, Any]) -> Config:
    """Resolve a test config from an already-loaded manifestguard.json dict.

    Supports both formats:
    - Per-test only:
        {"testConfig": {"coverage": { ... }}}
    - Global defaults + per-test overrides:
        {"testConfig": {"deepAnalysisMode": true, "thresholds": {...}, "coverage": { ... }}}
    """
    test_config_root = config.get("testConfig", {})
    if not isinstance(test_config_root, dict):
        test_config_root = {}

    # Global defaults at testConfig root (optional)
    default_enabled = True
    default_deep = False
    default_thresholds_data: dict[str, Any] | None = None

    if isinstance(test_config_root.get("enabled"), bool):
        default_enabled = bool(test_config_root.get("enabled"))
    if isinstance(test_config_root.get("deepAnalysisMode"), bool):
        default_deep = bool(test_config_root.get("deepAnalysisMode"))
    if isinstance(test_config_root.get("thresholds"), dict):
        default_thresholds_data = test_config_root.get("thresholds")

    # Per-test overrides (optional)
    test_config_data = test_config_root.get(test_name, {})
    if not isinstance(test_config_data, dict):
        test_config_data = {}

    enabled = bool(test_config_data.get("enabled", default_enabled))
    deep_analysis_mode = bool(test_config_data.get("deepAnalysisMode", default_deep))

    thresholds_data = test_config_data.get("thresholds")
    if thresholds_data is None:
        thresholds_data = default_thresholds_data

    thresholds: Thresholds | None = None
    if isinstance(thresholds_data, dict) and thresholds_data:
        thresholds = Thresholds(
            max_errors=thresholds_data.get("maxErrors"),
            max_warnings=thresholds_data.get("maxWarnings"),
            max_info=thresholds_data.get("maxInfo"),
        )

    return Config(
        enabled=enabled,
        deep_analysis_mode=deep_analysis_mode,
        thresholds=thresholds,
    )


def get_test_config(test_name: str, workspace_root: Path) -> Config:
    """Get configuration for a specific test.
    
    Args:
        test_name: Name of the test (e.g., 'complexity', 'coverage')
        workspace_root: Root directory of the workspace
        
    Returns:
        Config with settings from manifestguard.json or defaults
    """
    config = load_manifest_config(workspace_root)
    return resolve_test_config_from_dict(test_name, config)


def is_deep_analysis_mode(test_name: str, workspace_root: Path) -> bool:
    """Check if Deep Analysis Mode is enabled for a test.
    
    Deep Analysis Mode enables expensive checks (e.g., complexity analysis).
    
    Args:
        test_name: Name of the test
        workspace_root: Root directory of the workspace
        
    Returns:
        True if Deep Analysis Mode is enabled
    """
    config = get_test_config(test_name, workspace_root)
    return config.deep_analysis_mode


def check_thresholds(
    test_name: str,
    errors: int,
    warnings: int,
    info: int,
    workspace_root: Path | None = None,
    config: Config | None = None,
) -> ThresholdResult:
    """Check if issue counts are within configured thresholds.
    
    Args:
        test_name: Name of the test being checked
        errors: Number of error-level issues
        warnings: Number of warning-level issues
        info: Number of info-level issues
        workspace_root: Root directory (required if config not provided)
        config: Pre-loaded Config (optional, loads from workspace if not provided)
        
    Returns:
        ThresholdResult indicating pass/fail and details
        
    Example:
        >>> result = check_thresholds("complexity", errors=3, warnings=10, info=5)
        >>> if not result.passes:
        ...     print(f"Failed: {result.message}")
    """
    if config is None:
        if workspace_root is None:
            workspace_root = Path.cwd()
        config = get_test_config(test_name, workspace_root)

    # No thresholds configured = always pass
    if config.thresholds is None:
        return ThresholdResult(
            passes=True, message=f"No thresholds configured for {test_name}", exceeded=[]
        )

    thresholds = config.thresholds
    exceeded: list[str] = []

    # Check each severity level
    if thresholds.max_errors is not None and errors > thresholds.max_errors:
        exceeded.append(f"errors: {errors} > {thresholds.max_errors}")

    if thresholds.max_warnings is not None and warnings > thresholds.max_warnings:
        exceeded.append(f"warnings: {warnings} > {thresholds.max_warnings}")

    if thresholds.max_info is not None and info > thresholds.max_info:
        exceeded.append(f"info: {info} > {thresholds.max_info}")

    # Generate result
    if exceeded:
        return ThresholdResult(
            passes=False,
            message=f"{test_name} threshold exceeded: {', '.join(exceeded)}",
            exceeded=exceeded,
        )

    return ThresholdResult(
        passes=True,
        message=f"{test_name} within thresholds (E:{errors}, W:{warnings}, I:{info})",
        exceeded=[],
    )


def format_threshold_summary(result: ThresholdResult, test_name: str) -> str:
    """Format a threshold result for display.
    
    Args:
        result: Threshold check result
        test_name: Name of the test
        
    Returns:
        Formatted string suitable for console or report output
    """
    if result.passes:
        return f"✅ {test_name}: {result.message}"

    return f"❌ {test_name} FAILED: {result.message}\n   Exceeded: {', '.join(result.exceeded)}"
