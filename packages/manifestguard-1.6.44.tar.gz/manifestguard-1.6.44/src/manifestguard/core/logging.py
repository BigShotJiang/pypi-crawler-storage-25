"""Structured Logging Module
Ported from VS Code logger.ts

Features:
- Output channel pattern with configurable levels
- Structured JSON logging with context
- Stack trace control based on log level
- Configuration change watching
- Error display automation
"""

import json
import os
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

LogLevel = Literal["DEBUG", "INFO", "WARN", "ERROR"]


class OutputChannel:
    """Simulates VS Code OutputChannel for Python"""

    def __init__(self, name: str, log_file: Path | None = None):
        self.name = name
        self.log_file = log_file
        self._buffer: list[str] = []

    def append_line(self, message: str) -> None:
        """Append line to output channel"""
        timestamped = f"[{datetime.now().isoformat()}] {message}"
        self._buffer.append(timestamped)

        # Write to console

        # Write to file if configured
        if self.log_file:
            try:
                with self.log_file.open("a", encoding="utf-8") as f:
                    f.write(timestamped + "\n")
            except Exception:
                pass

    def show(self, preserve_focus: bool = False) -> None:
        """Show output channel.

        In CLI mode this writes the buffered output to stderr so the
        caller can surface important messages to the user. The
        ``preserve_focus`` flag is accepted for API compatibility with
        IDE integrations but has no behavioral effect here.
        """
        if not self._buffer:
            return
        try:
            for line in self._buffer:
                print(line, file=sys.stderr)
        except Exception:
            # Best-effort display; never fail hard on logging.
            pass

    def clear(self) -> None:
        """Clear output buffer"""
        self._buffer.clear()


class Logger:
    """Centralized logger with VS Code output channel pattern.

    Features:
    - Configurable log level from environment
    - Structured logging with context
    - Stack trace control (full in debug, message only otherwise)
    - Automatic error display
    - Output channel abstraction
    """

    def __init__(self, channel_name: str = "ManifestGuard", log_file: Path | None = None):
        self.output_channel = OutputChannel(channel_name, log_file)
        self.configured_level = self._get_log_level_from_env()

    def _get_log_level_from_env(self) -> Literal["debug", "info"]:
        """Get log level from environment variable"""
        level = os.getenv("MANIFESTGUARD_LOG_LEVEL", "info").lower()
        return "debug" if level == "debug" else "info"

    def info(self, message: str) -> None:
        """Log info message"""
        self._log("INFO", message)

    def warn(self, message: str) -> None:
        """Log warning message"""
        self._log("WARN", message)

    def error(self, message: str, error: Exception | None = None) -> None:
        """Log error message with optional exception"""
        error_message = ""
        if error:
            # In debug mode: full stack trace, otherwise just message
            if self.configured_level == "debug" and hasattr(error, "__traceback__"):
                error_message = "".join(
                    traceback.format_exception(type(error), error, error.__traceback__),
                )
            else:
                error_message = str(error)

        full_message = f"{message}\n{error_message}" if error_message else message
        self._log("ERROR", full_message)
        self.output_channel.show(preserve_focus=True)  # Always show on error

    def debug(self, message: str) -> None:
        """Log debug message (only if debug level enabled)"""
        if self.configured_level == "debug":
            self._log("DEBUG", message)

    def _log(self, level: LogLevel, message: str) -> None:
        """Internal log method"""
        self.output_channel.append_line(f"[{level}] {message}")


# Global logger instance
_logger: Logger | None = None


def setup_logger(
    name: str = "manifestguard",
    log_file: Path | None = None,
    *,
    level: int | None = None,
) -> Logger:
    """Setup global logger instance.

    Args:
        name: Logger name (channel name)
        log_file: Optional file path for persistent logging

    Returns:
        Logger instance

    """
    global _logger  # noqa: PLW0603  # Singleton pattern
    if _logger is None:
        _logger = Logger(name, log_file)

    # Optional override used by tests and programmatic consumers.
    if level is not None:
        # Map stdlib logging levels to our simple debug/info split.
        _logger.configured_level = "debug" if int(level) <= 10 else "info"
    return _logger


def get_logger() -> Logger:
    """Get global logger instance"""
    global _logger  # noqa: PLW0603  # Singleton pattern
    if _logger is None:
        _logger = Logger()
    return _logger


def log_struct(logger: Logger, level: str, message: str, **context: Any) -> None:
    """Log structured message with context as JSON.

    Args:
        logger: Logger instance
        level: Log level (debug/info/warn/error)
        message: Log message
        **context: Additional context as key-value pairs

    """
    log_data = {"msg": message, "context": context}
    json_str = json.dumps(log_data, default=str)

    level_lower = level.lower()
    if level_lower == "debug":
        logger.debug(json_str)
    elif level_lower == "warn":
        logger.warn(json_str)
    elif level_lower == "error":
        logger.error(json_str)
    else:
        logger.info(json_str)
