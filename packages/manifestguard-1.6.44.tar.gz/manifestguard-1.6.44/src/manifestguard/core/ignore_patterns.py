"""Compatibility wrapper for MGVS contract tests.

This module provides an IgnorePatterns class that wraps ScanSpaceResolver
to maintain API compatibility with the MGVS transfer contract tests.

Now powered by ADR-014's unified ScanSpaceResolver.
"""

from __future__ import annotations

from pathlib import Path

from manifestguard.core.scan_space import IgnoreRule as ScanIgnoreRule
from manifestguard.core.scan_space import ScanSpaceResolver

__MGVS_TRANSFER_IMPLEMENTED__ = True


# Re-export for compatibility
IgnoreRule = ScanIgnoreRule


class IgnorePatterns:
    """Compatibility wrapper around ScanSpaceResolver for contract tests."""

    def __init__(self, workspace_root: str | Path):
        """Initialize with workspace root."""
        self.workspace_root = Path(workspace_root)
        self._resolver = ScanSpaceResolver(workspace_root=self.workspace_root)

    def load(self) -> None:
        """Load ignore patterns from all sources."""
        self._resolver.load()

    def is_ignored(self, file_path: str | Path) -> bool:
        """Check if a file should be ignored."""
        return self._resolver.is_ignored(file_path)

    def get_rules(self) -> list[IgnoreRule]:
        """Get all loaded ignore rules."""
        return self._resolver.get_rules()

    def get_rules_by_source(self, source: str) -> list[IgnoreRule]:
        """Get rules from a specific source."""
        # Filter only .manifestguardignore and manifestguard.json for compat
        return [r for r in self._resolver.get_rules() if r.source == source]

    def match_ignore_rule(self, file_path: str | Path) -> IgnoreRule | None:
        """Return the highest-precedence rule that matches the file."""
        return self._resolver.match_ignore_rule(file_path)

    def clear(self) -> None:
        """Clear all loaded rules (for test cleanup)."""
        self._resolver.rules = []
        self._resolver._loaded = False

        cfg_data = self._resolver._config_service.get_config() if self._resolver._config_service else {}
        patterns = cfg_data.get("ignorePatterns")
        if not isinstance(patterns, list):
            return

        for pattern in patterns:
            if isinstance(pattern, str):
                self._rules.append(IgnoreRule(pattern=pattern, source="manifestguard.json"))
