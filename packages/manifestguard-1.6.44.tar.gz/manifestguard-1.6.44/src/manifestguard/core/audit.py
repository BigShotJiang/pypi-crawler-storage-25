"""Audit Trail with RuleRegistry integration"""

import builtins
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any

_AUDIT_FILE = Path("./audit.log")


class Audit:
    """Audit trail with structured logging and rule code tracking"""

    def __init__(self, log_file: Path | None = None):
        self._store: list[dict[str, Any]] = []
        self._log_file = log_file or _AUDIT_FILE

    def record(
        self,
        actor: str,
        action: str,
        target: str | None = None,
        details: dict[str, Any] | None = None,
        rule_code: str | None = None,
        rule_id: str | None = None,  # Alias for rule_code (backward compatibility)
        severity: str | None = None,
    ) -> None:
        """Record audit event with optional rule code

        Args:
            actor: Who performed the action
            action: What action was performed
            target: What was the target of the action
            details: Additional details about the action
            rule_code: Rule identifier (canonical parameter)
            rule_id: Alias for rule_code (for backward compatibility)
            severity: Severity level (e.g., 'info', 'warning', 'error')

        """
        # Support both rule_code and rule_id (rule_id takes precedence if both provided)
        effective_rule_code = rule_id if rule_id is not None else rule_code

        entry = {
            "ts": int(time.time()),
            "iso_timestamp": datetime.now().astimezone().isoformat(),
            "actor": actor,
            "action": action,
            "target": target,
            "details": details or {},
            "rule_code": effective_rule_code,
            "severity": severity,
        }
        self._store.append(entry)
        try:
            with self._log_file.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except Exception:
            # best-effort: do not break application for failed audit writes
            pass

    def list(self, limit: int | None = None) -> list[dict[str, Any]]:
        """Get audit entries with optional limit"""
        if limit:
            return list(self._store[-limit:])
        return list(self._store)

    def filter_by_actor(self, actor: str) -> builtins.list[dict[str, Any]]:
        """Get entries for specific actor"""
        return [e for e in self._store if e.get("actor") == actor]

    def filter_by_rule(self, rule_code: str) -> builtins.list[dict[str, Any]]:
        """Get entries for specific rule code"""
        return [e for e in self._store if e.get("rule_code") == rule_code]

    def clear(self) -> None:
        """Clear audit trail (for testing)"""
        self._store.clear()


audit = Audit()
