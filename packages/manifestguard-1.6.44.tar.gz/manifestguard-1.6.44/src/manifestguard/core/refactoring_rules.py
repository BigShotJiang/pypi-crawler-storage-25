from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


# These ids are shared with MGVS (`mgvs/src/utils/refactoringRules.ts`).
# Keep in sync so refactoring rules behave consistently across tools.
ALLOWED_REFACTOR_PLAN_RULE_IDS: set[str] = {
    "quickWinsFirst",
    "commandPrefixFirst",
    "noPlaceholders",
    "noHtmlInLanguageStrings",
    "standardizeVenvLayout",
    "excludeVenvArtifacts",
    "enforceSrcLayout",
    "separateTestsFromRuntime",
    "normalizePythonImportBoundaries",
    "isolateCliFromCoreLogic",
    "extractCssFromCode",
    "extractClientJsTsFromCode",
    "extractHtmlFromCode",
    "useSharedWebviewTemplates",
    "reduceDuplication",
    "removeDeadCode",
    "fixFalsePositiveSecurity",
}


ALLOWED_REFACTOR_AI_HINT_IDS: set[str] = {
    "implementFeatureFromDummyTodo",
    "noBackwardCompatibilityForNewCode",
    "localizeFirst",
    "lineOfCodeFirst",
    "complexityFirst",
    "noLocSplitting",
    "commitAfterEachIteration",
    "alwaysIncludeUntracked",
    "neverIncludeUntracked",
}


# Suggestions for renamed/ambiguous legacy ids.
_ID_SUGGESTIONS: dict[str, list[str]] = {
    "noBackwardCompatibility": ["aiHints.noBackwardCompatibilityForNewCode"],
    "featureFromTodo": ["aiHints.implementFeatureFromDummyTodo"],

    # "loc" is ambiguous (localization vs lines-of-code)
    "locFirst": ["aiHints.localizeFirst", "aiHints.lineOfCodeFirst"],

    # Renamed AI hints: clearer and consistent
    "commitAfterEachStage": ["aiHints.commitAfterEachIteration"],
    "alwaysIncludeUntrackedInCommits": ["aiHints.alwaysIncludeUntracked"],
    "neverIncludeUntrackedInCommits": ["aiHints.neverIncludeUntracked"],

    # Renamed plan rules
    "allowInlineHtmlInCodeExceptLanguageString": ["noHtmlInLanguageStrings"],
    "useViewHelpersAndTemplateModule": ["useSharedWebviewTemplates"],
}


# Baseline defaults that are ALWAYS active.
#
# Concept change:
# - These defaults cannot be disabled by removing a rules file or setting values to 0.
# - A rules file (if present) can ADD extra steps, but cannot turn off baseline rules.
BASELINE_RULES: dict[str, int] = {
    "quickWinsFirst": 1,
    "standardizeVenvLayout": 2,
    "excludeVenvArtifacts": 3,
    "enforceSrcLayout": 4,
    "separateTestsFromRuntime": 5,
    "normalizePythonImportBoundaries": 6,
    "isolateCliFromCoreLogic": 7,
    "noPlaceholders": 8,
    "reduceDuplication": 9,
    "removeDeadCode": 10,
}


# Baseline AI hints that are ALWAYS active.
# This enforces "do not split" as a hard ground rule.
BASELINE_AI_HINTS: dict[str, int] = {
    "commitAfterEachIteration": 1,
    "implementFeatureFromDummyTodo": 2,
    "noBackwardCompatibilityForNewCode": 3,
    "noLocSplitting": 4,
}


@dataclass(frozen=True)
class RefactoringRule:
    rule_id: str
    order: int


@dataclass(frozen=True)
class RefactoringAiHint:
    hint_id: str
    order: int


@dataclass(frozen=True)
class RefactoringRulesPlan:
    source_path: Path
    version: str | None
    ai_instruction: str | None
    rules_active: list[RefactoringRule]
    ai_hints_active: list[RefactoringAiHint]
    stages: list[dict[str, Any]]
    warnings: list[str]


class RefactoringRulesError(ValueError):
    pass


def _as_int(value: Any, *, key: str) -> int:
    if isinstance(value, bool):
        raise RefactoringRulesError(f"Invalid value for '{key}': boolean is not allowed")
    if isinstance(value, int):
        return value
    raise RefactoringRulesError(f"Invalid value for '{key}': expected integer >= 0")


def _canonicalize_id(raw_id: Any) -> str:
    return str(raw_id or "").strip()


def _canonicalize_ai_hint_id(raw_id: Any) -> str:
    canon = _canonicalize_id(raw_id)

    # Preferred short-form hint ids (backward compatible):
    # - "untracked" -> alwaysIncludeUntracked
    if canon == "untracked":
        return "alwaysIncludeUntracked"

    return canon


def _format_suggestion(raw_id: str) -> str:
    suggestions = _ID_SUGGESTIONS.get(raw_id)
    if not suggestions:
        return ""
    if len(suggestions) == 1:
        return f" Did you mean '{suggestions[0]}'?"
    return " Did you mean " + " or ".join(f"'{s}'" for s in suggestions) + "?"


def _parse_rules_map(entries: dict[Any, Any], warnings: list[str]) -> dict[str, int]:
    rules_map: dict[str, int] = {}
    for key, raw_val in entries.items():
        if not isinstance(key, str) or not key.strip():
            warnings.append("Ignored non-string/empty rule id")
            continue
        canon = _canonicalize_id(key)

        # AI hints are instructions and must live under aiHints.
        if canon in ALLOWED_REFACTOR_AI_HINT_IDS:
            warnings.append(f"AI hint id used in rules ignored: {key}. Put it under 'aiHints' instead.")
            continue

        if canon not in ALLOWED_REFACTOR_PLAN_RULE_IDS:
            warnings.append(f"Unknown rule id ignored: {key}.{_format_suggestion(key)}")
            continue
        value = _as_int(raw_val, key=key)
        if value < 0:
            raise RefactoringRulesError(f"Invalid value for '{key}': expected integer >= 0")
        rules_map[canon] = value
    return rules_map


def _parse_ai_hints_map(entries: dict[Any, Any], warnings: list[str]) -> dict[str, int]:
    hints_map: dict[str, int] = {}
    for key, raw_val in entries.items():
        if not isinstance(key, str) or not key.strip():
            warnings.append("Ignored non-string/empty aiHints id")
            continue
        canon = _canonicalize_ai_hint_id(key)
        if canon not in ALLOWED_REFACTOR_AI_HINT_IDS:
            warnings.append(f"Unknown aiHints id ignored: {key}.{_format_suggestion(key)}")
            continue
        value = _as_int(raw_val, key=key)
        if value < 0:
            raise RefactoringRulesError(f"Invalid value for aiHints '{key}': expected integer >= 0")
        hints_map[canon] = value
    return hints_map


def parse_refactoring_rules_data(data: Any) -> tuple[str | None, str | None, dict[str, int], dict[str, int], list[str]]:
    """Parse Format A/B and return (version, ai_instruction, rules_map, ai_hints_map, warnings)."""

    if not isinstance(data, dict):
        raise RefactoringRulesError("Rules file must be a JSON object")

    warnings: list[str] = []

    # Format A
    if "rules" in data:
        rules_obj = data.get("rules")
        if not isinstance(rules_obj, dict):
            raise RefactoringRulesError("Format A requires 'rules' to be an object")

        version = data.get("version")
        if version is not None and not isinstance(version, (str, int)):
            raise RefactoringRulesError("'version' must be a string or integer if provided")
        if isinstance(version, int):
            version = str(version)

        ai_instruction = data.get("aiInstruction")
        if ai_instruction is not None and not isinstance(ai_instruction, str):
            raise RefactoringRulesError("'aiInstruction' must be a string if provided")

        ai_hints_raw = data.get("aiHints")
        if ai_hints_raw is not None and not isinstance(ai_hints_raw, dict):
            raise RefactoringRulesError("'aiHints' must be an object if provided")

        rules_map = _parse_rules_map(rules_obj, warnings)
        ai_hints_map = _parse_ai_hints_map(ai_hints_raw or {}, warnings) if isinstance(ai_hints_raw, dict) else {}
        return version, ai_instruction, rules_map, ai_hints_map, warnings

    # Format B (flat)
    version = None

    ai_instruction = data.get("aiInstruction")
    if ai_instruction is not None and not isinstance(ai_instruction, str):
        raise RefactoringRulesError("'aiInstruction' must be a string if provided")

    ai_hints_raw = data.get("aiHints")
    if ai_hints_raw is not None and not isinstance(ai_hints_raw, dict):
        raise RefactoringRulesError("'aiHints' must be an object if provided")

    flat_entries = {k: v for k, v in data.items() if k not in {"$schema", "version", "aiInstruction", "aiHints"}}
    rules_map = _parse_rules_map(flat_entries, warnings)
    ai_hints_map = _parse_ai_hints_map(ai_hints_raw or {}, warnings) if isinstance(ai_hints_raw, dict) else {}

    return version, ai_instruction, rules_map, ai_hints_map, warnings


def build_refactoring_plan(
    source_path: Path,
    version: str | None,
    ai_instruction: str | None,
    rules_map: dict[str, int],
    ai_hints_map: dict[str, int],
    warnings: list[str],
) -> RefactoringRulesPlan:
    # Merge baseline (always-on) + user-provided maps.
    merged_rules: dict[str, int] = dict(BASELINE_RULES)
    for rule_id, order in rules_map.items():
        if rule_id in BASELINE_RULES:
            if order <= 0:
                warnings.append(f"Baseline rule cannot be disabled; ignoring: {rule_id}")
                continue
            if order != BASELINE_RULES[rule_id]:
                warnings.append(f"Baseline rule order is fixed; ignoring override: {rule_id}")
                continue
            continue
        merged_rules[rule_id] = order

    merged_hints: dict[str, int] = dict(BASELINE_AI_HINTS)
    for hint_id, order in ai_hints_map.items():
        if hint_id in BASELINE_AI_HINTS:
            if order <= 0:
                warnings.append(f"Baseline aiHint cannot be disabled; ignoring: {hint_id}")
                continue
            if order != BASELINE_AI_HINTS[hint_id]:
                warnings.append(f"Baseline aiHint order is fixed; ignoring override: {hint_id}")
                continue
            continue
        merged_hints[hint_id] = order

    active = [RefactoringRule(rule_id=k, order=v) for k, v in merged_rules.items() if v > 0]
    active_sorted = sorted(active, key=lambda r: (r.order, r.rule_id))

    hints_active = [RefactoringAiHint(hint_id=k, order=v) for k, v in merged_hints.items() if v > 0]
    hints_active_sorted = sorted(hints_active, key=lambda h: (h.order, h.hint_id))

    stages: list[dict[str, Any]] = []
    current_order: int | None = None
    current_ids: list[str] = []
    for r in active_sorted:
        if current_order is None:
            current_order = r.order
            current_ids = [r.rule_id]
            continue
        if r.order != current_order:
            stages.append({"order": current_order, "ruleIds": current_ids})
            current_order = r.order
            current_ids = [r.rule_id]
        else:
            current_ids.append(r.rule_id)

    if current_order is not None:
        stages.append({"order": current_order, "ruleIds": current_ids})

    return RefactoringRulesPlan(
        source_path=source_path,
        version=version,
        ai_instruction=ai_instruction,
        rules_active=active_sorted,
        ai_hints_active=hints_active_sorted,
        stages=stages,
        warnings=warnings,
    )


def load_refactoring_rules_plan(path: Path) -> RefactoringRulesPlan:
    try:
        raw = path.read_text(encoding="utf-8")
    except Exception as e:
        raise RefactoringRulesError(f"Failed to read rules file: {path}: {e}") from e

    try:
        data = json.loads(raw)
    except Exception as e:
        raise RefactoringRulesError(f"Invalid JSON in rules file: {path}: {e}") from e

    version, ai_instruction, rules_map, ai_hints_map, warnings = parse_refactoring_rules_data(data)
    return build_refactoring_plan(path, version, ai_instruction, rules_map, ai_hints_map, warnings)


def build_baseline_refactoring_plan(source_path: Path) -> RefactoringRulesPlan:
    """Return a plan even when no rules file exists.

    Baseline is always-on by design and cannot be bypassed by configuration.
    """

    return build_refactoring_plan(
        source_path=source_path,
        version=None,
        ai_instruction=None,
        rules_map={},
        ai_hints_map={},
        warnings=["No rules file found; using baseline defaults."],
    )
