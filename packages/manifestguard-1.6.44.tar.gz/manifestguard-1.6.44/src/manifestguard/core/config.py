"""Configuration Service for ManifestGuard
Ported from VS Code ConfigurationService.ts

Provides hierarchical configuration management:
- User-level settings
- Workspace-level settings
- Workspace folder-level settings
- manifestguard.json file
"""

import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from watchdog.events import FileSystemEvent, FileSystemEventHandler

if TYPE_CHECKING:
    pass

AccessLevel = Literal["strict", "balanced", "permissive"]
AIProvider = Literal["ollama", "openai-compatible"]

# Filenames that indicate a project root (ordered by priority).
PROJECT_ROOT_MARKERS: frozenset[str] = frozenset(
    {
        "pyproject.toml",
        "setup.py",
        "manifestguard.json",
        "requirements.txt",
    }
)

# Config filenames accepted by ManifestGuard (precedence order).
CONFIG_FILENAMES: tuple[str, ...] = ("manifestguard.json",)


def _looks_like_config_file(data: Any) -> bool:
    """Return True when ``data`` looks like a manifestguard config dict."""
    return isinstance(data, dict) and ("version" in data or "enabled" in data)


def find_existing_config_path(workspace_root: Path) -> Path | None:
    """Return the first preferred config path that exists in ``workspace_root``, or None."""
    for filename in CONFIG_FILENAMES:
        candidate = workspace_root / filename
        if not candidate.exists():
            continue
        try:
            with candidate.open(encoding="utf-8") as handle:
                data = json.load(handle)
            if _looks_like_config_file(data):
                return candidate
        except Exception:
            continue
    return None


def resolve_workspace_root(start: Path | None = None) -> Path:
    """Walk upward from ``start`` (default: cwd) until a project-root marker is found."""
    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        if any((candidate / marker).exists() for marker in PROJECT_ROOT_MARKERS):
            return candidate
    return current


def resolve_project_root(path: "Path | str") -> Path:
    """Resolve a project root path to a normalised absolute ``Path``.

    Args:
        path: A ``Path`` object or string pointing to the project root.

    Returns:
        Fully resolved absolute ``Path``.

    Raises:
        ValueError: When the resolved path does not exist on disk.
    """
    resolved = Path(path).resolve()
    if not resolved.exists():
        raise ValueError(f"Project root does not exist: {resolved}")
    return resolved


@dataclass
class EffectiveAIConfig:
    """Effective AI configuration with source tracking"""

    provider: AIProvider
    model: str
    ollama: dict[str, str]
    openai: dict[str, str]
    security: dict[str, Any]
    source: dict[str, Any]


@dataclass
class EffectiveConfig:
    """Effective configuration with all merged settings"""

    access_level: AccessLevel
    consented_workflows: list[str]
    severity_overrides: dict[str, Literal["info", "warn", "error"]]
    rules: dict[str, Any]
    dependency_rules: dict[str, Any] | None
    monorepo_roots: list[str]
    license_key: str
    advanced_checks_enabled: bool
    sources: dict[str, str]  # maps key -> source descriptor


class ConfigFileWatcher(FileSystemEventHandler):
    """Watches manifestguard.json for changes"""

    def __init__(self, config_service: "ConfigurationService"):
        self.config_service = config_service

    def on_modified(self, event: FileSystemEvent) -> None:
        if str(event.src_path).endswith("manifestguard.json"):
            self.config_service.invalidate_cache()


class ConfigurationService:
    """Centralized configuration service with hierarchical settings.

    Settings precedence (highest to lowest):
    1. Workspace folder manifestguard.json
    2. Workspace manifestguard.json
    3. User settings (environment variables / config file)
    4. Defaults

    Supports:
    - Access levels (strict/balanced/permissive)
    - AI provider configuration
    - Security settings
    - Workflow consent management
    - Severity overrides
    - Dependency rules
    - Monorepo roots
    """

    def __init__(self, workspace_root: Path | None = None):
        self.workspace_root = workspace_root or Path.cwd()
        self._cache: EffectiveConfig | None = None
        self._observer: Any = None
        self._setup_watcher()

    def _setup_watcher(self) -> None:
        """Setup file system watcher for manifestguard.json"""
        try:
            from watchdog.observers import Observer as WatchdogObserver  # noqa: PLC0415 - optional dependency

            self._observer = WatchdogObserver()
            event_handler = ConfigFileWatcher(self)
            self._observer.schedule(event_handler, str(self.workspace_root), recursive=False)
            self._observer.start()
        except Exception:
            # Silently fail if watchdog not available or permissions issue
            pass

    def invalidate_cache(self) -> None:
        """Invalidate cached configuration"""
        self._cache = None

    def _read_config_file(self) -> dict[str, Any] | None:
        """Read manifestguard.json from workspace and auto-migrate old formats"""
        config_path = self.workspace_root / "manifestguard.json"
        if config_path.exists():
            try:
                with config_path.open(encoding="utf-8") as f:
                    data: dict[str, Any] = json.load(f)

                # Auto-migration: scanSpace.ignoreDirs → ignorePatterns (ADR-014)
                migrated = self._migrate_config_format(data)
                if migrated:
                    # Write back migrated config
                    try:
                        with config_path.open("w", encoding="utf-8") as f:
                            json.dump(data, f, indent=2, ensure_ascii=False)
                        print(
                            "✅ Config auto-migrated: scanSpace.ignoreDirs → ignorePatterns (ADR-014)"
                        )
                    except Exception as e:
                        print(f"⚠️  Config migration successful but write failed: {e}")

                return data
            except Exception:
                return None
        return None

    def _migrate_config_format(self, data: dict[str, Any]) -> bool:
        """Migrate old config format to ADR-014 standard.

        Returns True if migration was performed.
        """
        migrated = False

        # Migration 1: scanSpace.ignoreDirs → ignorePatterns
        if "scanSpace" in data and "ignoreDirs" in data["scanSpace"]:
            ignore_dirs = data["scanSpace"]["ignoreDirs"]
            if isinstance(ignore_dirs, list) and ignore_dirs:
                # Merge with existing ignorePatterns
                existing = data.get("ignorePatterns", [])
                if not isinstance(existing, list):
                    existing = []

                # Convert directory patterns (add trailing slash if missing)
                for pattern in ignore_dirs:
                    normalized = pattern if pattern.endswith("/") else f"{pattern}/"
                    if normalized not in existing:
                        existing.append(normalized)

                data["ignorePatterns"] = existing
                print(f"  Migrating {len(ignore_dirs)} patterns: {ignore_dirs}")
                migrated = True

            # Remove old scanSpace section
            del data["scanSpace"]

        return migrated

    def get_config(self) -> EffectiveConfig:
        """Get effective configuration with caching"""
        if self._cache:
            return self._cache

        # Read manifestguard.json
        file_config = self._read_config_file() or {}

        # Read environment variables
        env_config = {
            "license_key": os.getenv("MANIFESTGUARD_LICENSE_KEY", ""),
            "access_level": os.getenv("MANIFESTGUARD_ACCESS_LEVEL", "balanced"),
            "advanced_checks_enabled": os.getenv("MANIFESTGUARD_ADVANCED_CHECKS", "false").lower()
            == "true",
        }

        # Merge configurations
        config = EffectiveConfig(
            access_level=file_config.get("accessLevel", env_config["access_level"]),
            consented_workflows=file_config.get("ai", {})
            .get("security", {})
            .get("consentedWorkflows", []),
            severity_overrides=file_config.get("severityOverrides", {}),
            rules=file_config.get("rules", {}),
            dependency_rules=file_config.get("dependencyRules"),
            monorepo_roots=file_config.get("monorepo", {}).get("roots", []),
            license_key=str(env_config["license_key"] or file_config.get("licenseKey", "")),
            advanced_checks_enabled=bool(env_config["advanced_checks_enabled"]),
            sources={
                "accessLevel": "file" if "accessLevel" in file_config else "env",
                "licenseKey": "env" if env_config["license_key"] else "file",
            },
        )

        self._cache = config
        return config

    def get_access_level(self) -> AccessLevel:
        """Get current access level"""
        return self.get_config().access_level

    def has_consent(self, workflow_id: str) -> bool:
        """Check if user has given consent for specific workflow"""
        return workflow_id in self.get_config().consented_workflows

    def add_consent(self, workflow_id: str) -> None:
        """Add consent for a workflow"""
        config = self.get_config()
        if workflow_id not in config.consented_workflows:
            config.consented_workflows.append(workflow_id)
            self._save_consent(config.consented_workflows)

    def remove_consent(self, workflow_id: str) -> None:
        """Remove consent for a workflow"""
        config = self.get_config()
        if workflow_id in config.consented_workflows:
            config.consented_workflows.remove(workflow_id)
            self._save_consent(config.consented_workflows)

    def _save_consent(self, consented_workflows: list[str]) -> None:
        """Save consented workflows to manifestguard.json"""
        config_path = self.workspace_root / "manifestguard.json"

        try:
            # Read current file or create new
            if config_path.exists():
                with config_path.open(encoding="utf-8") as f:
                    data = json.load(f)
            else:
                data = {}

            # Update AI security section
            if "ai" not in data:
                data["ai"] = {}
            if "security" not in data["ai"]:
                data["ai"]["security"] = {}
            data["ai"]["security"]["consentedWorkflows"] = consented_workflows

            # Write back
            with config_path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            self.invalidate_cache()
        except Exception:
            pass  # Silently fail

    def get_ai_config(self) -> EffectiveAIConfig:
        """Get effective AI configuration"""
        file_config = self._read_config_file() or {}
        ai_config = file_config.get("ai", {})

        return EffectiveAIConfig(
            provider=ai_config.get("provider", "ollama"),
            model=ai_config.get("model", "llama3.1"),
            ollama={
                "baseUrl": ai_config.get("ollama", {}).get("baseUrl", "http://localhost:11434"),
            },
            openai={
                "baseUrl": ai_config.get("openai", {}).get("baseUrl", "https://api.openai.com/v1"),
                "apiKey": ai_config.get("openai", {}).get("apiKey", ""),
            },
            security={
                "accessLevel": self.get_access_level(),
                "consentedWorkflows": self.get_config().consented_workflows,
                "allowedHosts": ai_config.get("security", {}).get("allowedHosts", []),
            },
            source={
                "provider": "workspace-folder" if "ai" in file_config else "default",
                "folder": str(self.workspace_root) if "ai" in file_config else None,
            },
        )

    def get_severity_override(self, rule_code: str) -> Literal["info", "warn", "error"] | None:
        """Get severity override for specific rule"""
        return self.get_config().severity_overrides.get(rule_code)

    def is_rule_enabled(self, rule_code: str) -> bool:
        """Check if specific rule is enabled"""
        rules = self.get_config().rules
        if rule_code in rules:
            return rules[rule_code] is not False
        return True  # Enabled by default

    def get_python_version_constraint(self) -> tuple[int, int]:
        """Get minimum Python version from config or detect current"""
        file_config = self._read_config_file() or {}
        min_version = file_config.get("python", {}).get("minVersion", "3.8")
        parts = min_version.split(".")
        return (int(parts[0]), int(parts[1]))

    def is_python_version_compatible(self) -> bool:
        """Check if current Python version meets minimum requirements"""
        min_major, min_minor = self.get_python_version_constraint()
        current = sys.version_info
        return (current.major, current.minor) >= (min_major, min_minor)

    def cleanup(self) -> None:
        """Cleanup resources (stop file watcher)"""
        try:
            if self._observer is not None:
                self._observer.stop()
                self._observer.join()
        except Exception:
            pass
