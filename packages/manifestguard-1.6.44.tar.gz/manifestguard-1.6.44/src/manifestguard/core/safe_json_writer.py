from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, Literal

__MGVS_TRANSFER_IMPLEMENTED__ = True

LineEnding = Literal["lf", "crlf"]


def _normalize_line_endings(text: str, line_ending: LineEnding) -> str:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    if line_ending == "lf":
        return normalized
    if line_ending == "crlf":
        return normalized.replace("\n", "\r\n")
    raise ValueError(f"Unsupported line_ending: {line_ending}")


def _json_bytes(
    data: Any,
    *,
    prettify: bool = True,
    indent: int = 2,
    line_ending: LineEnding = "lf",
) -> bytes:
    if prettify:
        json_text = json.dumps(data, indent=indent, ensure_ascii=False)
    else:
        json_text = json.dumps(data, separators=(",", ":"), ensure_ascii=False)

    json_text = _normalize_line_endings(json_text, line_ending)

    # Only force a trailing newline for CRLF output so the payload actually contains
    # CRLFs even when JSON is minified (no internal newlines). For LF, leave the
    # content untouched so callers/tests can rely on exact minified output.
    if line_ending == "crlf" and "\r\n" not in json_text:
        json_text += "\r\n"
    return json_text.encode("utf-8")


async def write_json_file(
    file_path: str | Path,
    data: Any,
    *,
    prettify: bool = True,
    indent: int = 2,
    line_ending: LineEnding = "lf",
) -> None:
    path = Path(file_path)
    payload = _json_bytes(data, prettify=prettify, indent=indent, line_ending=line_ending)
    await asyncio.to_thread(path.write_bytes, payload)


def write_json_file_sync(
    file_path: str | Path,
    data: Any,
    *,
    prettify: bool = True,
    indent: int = 2,
    line_ending: LineEnding = "lf",
) -> None:
    path = Path(file_path)
    payload = _json_bytes(data, prettify=prettify, indent=indent, line_ending=line_ending)
    path.write_bytes(payload)


def has_bom(file_path: str | Path) -> bool:
    path = Path(file_path)
    try:
        raw = path.read_bytes()
    except OSError:
        return False

    if raw.startswith(b"\xEF\xBB\xBF"):
        return True
    if raw.startswith(b"\xFE\xFF") or raw.startswith(b"\xFF\xFE"):
        return True

    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError:
        return False

    return bool(text) and text[0] == "\ufeff"


def remove_bom(file_path: str | Path) -> bool:
    path = Path(file_path)
    try:
        raw = path.read_bytes()
    except OSError:
        return False

    if raw.startswith(b"\xEF\xBB\xBF"):
        path.write_bytes(raw[3:])
        return True

    if raw.startswith(b"\xFE\xFF") or raw.startswith(b"\xFF\xFE"):
        path.write_bytes(raw[2:])
        return True

    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError:
        return False

    if text and text[0] == "\ufeff":
        path.write_text(text[1:], encoding="utf-8", newline="\n")
        return True

    return False


def find_json_files_with_bom(directory: str | Path, *, recursive: bool = True) -> list[str]:
    root = Path(directory)
    if not root.exists():
        return []

    iterator = root.rglob("*.json") if recursive else root.glob("*.json")
    matches: list[str] = []
    for candidate in iterator:
        if candidate.is_file() and has_bom(candidate):
            matches.append(str(candidate))

    return matches
