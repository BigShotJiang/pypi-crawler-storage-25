"""Unified Scan Space & Excludes Strategy (ADR-014).

This module provides a centralized scan-space resolver with:
- Layered scan model (core/tests/framework/generated)
- Precedence: config > VCS ignore > built-in defaults
- Observability: exclude attribution and scan-space summary
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

logger = logging.getLogger(__name__)

# Type aliases
IgnoreSource = Literal[
    ".manifestguardignore",
    "manifestguard.json",
    ".gitignore",
    ".vscodeignore",
    ".npmignore",
    ".pyignore",
    ".svnignore",
    "built-in",
]


@dataclass
class IgnoreRule:
    """Represents a single ignore pattern with attribution."""

    pattern: str
    source: IgnoreSource
    code: str | None = None  # For inline violation-specific ignores
    line: int | None = None  # For inline comment tracking


@dataclass
class ScanSpaceSummary:
    """Machine-readable scan-space metrics for reports."""

    included_files: list[str] = field(default_factory=list)
    excluded_files: list[str] = field(default_factory=list)
    excluded_by: dict[str, str] = field(default_factory=dict)  # file -> source
    frameworks_detected: list[str] = field(default_factory=list)
    presets_applied: list[str] = field(default_factory=list)
    lines_of_code: int = 0


class ScanSpaceResolver:
    """Unified scan-space resolver with layered exclusion precedence.

    Precedence (highest to lowest):
    1. manifestguard.json (explicit config)
    2. .manifestguardignore
    3. VCS ignore files (.gitignore, .svnignore, etc.)
    4. Built-in defaults (venv, __pycache__, node_modules, etc.)
    """

    def __init__(self, workspace_root: Path):
        """Initialize resolver for given workspace root."""
        self.workspace_root = workspace_root
        self.rules: list[IgnoreRule] = []
        self._loaded = False

    def load(self) -> None:
        """Load ignore patterns from all sources in precedence order."""
        if self._loaded:
            return

        self.rules = []

        # Priority 1: Built-in defaults (lowest precedence)
        self._load_built_in_defaults()

        # Priority 2: VCS ignore files
        self._load_vcs_ignore_files()

        # Priority 3: .manifestguardignore
        self._load_manifestguardignore()

        # Priority 4: manifestguard.json (highest precedence)
        self._load_manifestguard_json()

        self._loaded = True
        logger.debug(
            "ScanSpaceResolver: Loaded %d total rules from workspace %s",
            len(self.rules),
            self.workspace_root,
        )

    def _load_built_in_defaults(self) -> None:
        """Load built-in default exclude patterns."""
        defaults = [
            "__pycache__",
            "*.pyc",
            "*.pyo",
            "*.pyd",
            ".Python",
            "build/",
            "develop-eggs/",
            "dist/",
            "downloads/",
            "eggs/",
            ".eggs/",
            "lib/",
            "lib64/",
            "parts/",
            "sdist/",
            "var/",
            "wheels/",
            "*.egg-info/",
            ".installed.cfg",
            "*.egg",
            "venv/",
            ".venv/",
            "ENV/",
            "env/",
            "site-packages/",
            ".git/",
            ".svn/",
            ".cvs/",
            ".hg/",
            "node_modules/",
            ".pytest_cache/",
            ".coverage",
            "htmlcov/",
            ".tox/",
            ".mypy_cache/",
            ".ruff_cache/",
        ]
        for pattern in defaults:
            self.rules.append(IgnoreRule(pattern=pattern, source="built-in"))

    def _load_vcs_ignore_files(self) -> None:
        """Load patterns from VCS ignore files."""
        vcs_files = [
            (".gitignore", ".gitignore"),
            (".vscodeignore", ".vscodeignore"),
            (".npmignore", ".npmignore"),
            (".pyignore", ".pyignore"),
            (".svnignore", ".svnignore"),
        ]

        for filename, source in vcs_files:
            ignore_file = self.workspace_root / filename
            if not ignore_file.exists():
                continue

            try:
                content = ignore_file.read_text(encoding="utf-8")
                for line in content.splitlines():
                    stripped = line.strip()
                    if stripped and not stripped.startswith("#") and not stripped.startswith("!"):
                        self.rules.append(IgnoreRule(pattern=stripped, source=source))  # type: ignore[arg-type]
            except Exception as exc:
                logger.debug("Could not read %s: %s", filename, exc)

    def _load_manifestguardignore(self) -> None:
        """Load patterns from .manifestguardignore."""
        ignore_file = self.workspace_root / ".manifestguardignore"
        if not ignore_file.exists():
            return

        try:
            content = ignore_file.read_text(encoding="utf-8")
            for line in content.splitlines():
                stripped = line.strip()
                if stripped and not stripped.startswith("#") and not stripped.startswith("!"):
                    self.rules.append(IgnoreRule(pattern=stripped, source=".manifestguardignore"))
        except Exception as exc:
            logger.debug("Could not read .manifestguardignore: %s", exc)

    def _load_manifestguard_json(self) -> None:
        """Load explicit exclude/include patterns from manifestguard.json."""
        config_file = self.workspace_root / "manifestguard.json"
        if not config_file.exists():
            return

        try:
            content = config_file.read_text(encoding="utf-8")
            config = json.loads(content)

            if "ignorePatterns" in config and isinstance(config["ignorePatterns"], list):
                for pattern in config["ignorePatterns"]:
                    if isinstance(pattern, str):
                        self.rules.append(IgnoreRule(pattern=pattern, source="manifestguard.json"))
        except json.JSONDecodeError:
            logger.debug("manifestguard.json is invalid JSON; skipping")
        except Exception as exc:
            logger.debug("Could not read manifestguard.json: %s", exc)

    def is_ignored(self, file_path: str | Path) -> bool:
        """Check if file should be ignored (any matching rule)."""
        if not self._loaded:
            self.load()

        path = Path(file_path) if isinstance(file_path, str) else file_path
        path_str = str(path).replace("\\", "/")

        try:
            rel_path = str(path.relative_to(self.workspace_root)).replace("\\", "/")
        except ValueError:
            rel_path = path_str

        return any(
            self._pattern_matches(rule.pattern, path, path_str, rel_path)
            for rule in reversed(self.rules)
        )

    def match_ignore_rule(self, file_path: str | Path) -> IgnoreRule | None:
        """Return the highest-precedence rule that matches the file (for attribution)."""
        if not self._loaded:
            self.load()

        path = Path(file_path) if isinstance(file_path, str) else file_path
        path_str = str(path).replace("\\", "/")

        try:
            rel_path = str(path.relative_to(self.workspace_root)).replace("\\", "/")
        except ValueError:
            rel_path = path_str

        for rule in reversed(self.rules):  # Higher precedence rules added last
            if self._pattern_matches(rule.pattern, path, path_str, rel_path):
                return rule

        return None

    def _matches_extension_pattern(self, pattern_norm: str, path: Path) -> bool:
        """Return True for simple extension patterns like "*.py" or "*.generated.ts"."""
        if pattern_norm.startswith("*.") and "*" not in pattern_norm[2:]:
            suffix = pattern_norm[1:]
            return path.name.endswith(suffix)
        return False

    @staticmethod
    def _matches_prefix_wildcard(pattern_norm: str, path: Path) -> bool:
        """Return True for prefix wildcards like "test_*"."""
        if pattern_norm.endswith("*") and "*" not in pattern_norm[:-1] and "/" not in pattern_norm:
            prefix = pattern_norm[:-1]
            return path.name.startswith(prefix)
        return False

    @staticmethod
    def _matches_middle_wildcard(pattern_norm: str, path: Path) -> bool:
        """Return True for simple prefix*suffix patterns like "*_generated.ts"."""
        if (
            "*" in pattern_norm
            and not pattern_norm.startswith("*.")
            and not pattern_norm.endswith("*")
        ):
            parts = pattern_norm.split("*")
            if len(parts) == 2:
                prefix, suffix = parts
                return path.name.startswith(prefix) and path.name.endswith(suffix)
        return False

    @staticmethod
    def _matches_directory_glob(pattern_norm: str, path_str: str, rel_path: str) -> bool:
        """Return True for directory globs like "src/legacy/**"."""
        if "/**" not in pattern_norm:
            return False
        needle = pattern_norm.replace("/**", "")
        if rel_path.startswith(needle + "/") or rel_path == needle:
            return True
        if path_str.find("/" + needle + "/") != -1 or path_str.endswith("/" + needle):
            return True
        return False

    @staticmethod
    def _matches_directory_suffix(pattern_norm: str, path_str: str, rel_path: str) -> bool:
        """Return True for directory patterns ending with a slash, e.g. "tests/"."""
        if not pattern_norm.endswith("/"):
            return False
        needle = pattern_norm.rstrip("/")
        if rel_path.startswith(needle + "/"):
            return True
        if needle in path_str or needle in rel_path:
            return True
        return False

    @staticmethod
    def _matches_substring_or_component(
        pattern_norm: str,
        path: Path,
        path_str: str,
        rel_path: str,
    ) -> bool:
        """Fallback matching using simple substring or path-component checks."""
        if pattern_norm in path_str or pattern_norm in rel_path:
            return True
        if "/" not in pattern_norm and "*" not in pattern_norm and pattern_norm in path.parts:
            return True
        return False

    def _pattern_matches(self, pattern: str, path: Path, path_str: str, rel_path: str) -> bool:  # noqa: PLR0911
        """Check if pattern matches the given path (paths already normalized with forward slashes)."""
        # Normalize pattern (convert backslashes to forward slashes)
        pattern_norm = pattern.replace("\\", "/")

        if self._matches_extension_pattern(pattern_norm, path):
            return True
        if self._matches_prefix_wildcard(pattern_norm, path):
            return True
        if self._matches_middle_wildcard(pattern_norm, path):
            return True
        if self._matches_directory_glob(pattern_norm, path_str, rel_path):
            return True
        if self._matches_directory_suffix(pattern_norm, path_str, rel_path):
            return True

        return self._matches_substring_or_component(pattern_norm, path, path_str, rel_path)

    def get_rules(self) -> list[IgnoreRule]:
        """Get all loaded ignore rules."""
        if not self._loaded:
            self.load()
        return self.rules.copy()

    def get_rules_by_source(self, source: IgnoreSource) -> list[IgnoreRule]:
        """Get all rules from a specific source."""
        if not self._loaded:
            self.load()
        return [r for r in self.rules if r.source == source]

    def build_scan_summary(
        self,
        included: list[Path],
        excluded: list[Path],
    ) -> ScanSpaceSummary:
        """Build a machine-readable scan-space summary for reports."""
        summary = ScanSpaceSummary()
        summary.included_files = [str(p.relative_to(self.workspace_root)) for p in included]
        summary.excluded_files = [str(p.relative_to(self.workspace_root)) for p in excluded]

        for exc_path in excluded:
            rule = self.match_ignore_rule(exc_path)
            if rule:
                rel = str(exc_path.relative_to(self.workspace_root))
                summary.excluded_by[rel] = rule.source

        return summary
