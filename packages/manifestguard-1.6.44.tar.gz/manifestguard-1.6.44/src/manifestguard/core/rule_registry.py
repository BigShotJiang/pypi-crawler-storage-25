"""Rule Registry for ManifestGuard
Ported from VS Code RuleRegistry.ts

Central registry for all diagnostic rules with metadata,
documentation URLs, quick fixes, and severity defaults.
"""

from dataclasses import dataclass, field
from typing import ClassVar, Literal


@dataclass
class QuickFixAction:
    """Quick fix action for a rule violation"""

    title: str
    command: str | None = None
    edit: dict | None = None


@dataclass
class RuleMetadata:
    """Metadata for a diagnostic rule"""

    code: str
    title: str
    description: str
    severity: Literal["info", "warn", "error"]
    category: Literal["best-practice", "compatibility", "compliance", "security", "correctness"]
    blocking: bool
    doc_url: str | None = None
    quick_fixes: list[QuickFixAction] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)


class RuleRegistry:
    """Singleton registry for all diagnostic rules.

    Provides:
    - Rule metadata with documentation
    - Severity levels and blocking flags
    - Quick fix suggestions
    - Category-based organization
    - Dynamic rule registration
    """

    _rules: ClassVar[dict[str, RuleMetadata]] = {
        # Environment Rules
        "ENV_NAME_MISSING": RuleMetadata(
            code="ENV_NAME_MISSING",
            title="Environment Name Missing",
            description="Environment must have a name field.",
            doc_url="https://ready-4-it.com/docs/mgpy/rules/ENV_NAME_MISSING",
            severity="error",
            category="correctness",
            blocking=True,
            examples=['{"name": "production", "description": "Production environment"}'],
        ),
        "ENV_NAME_INVALID": RuleMetadata(
            code="ENV_NAME_INVALID",
            title="Invalid Environment Name",
            description="Environment name must be a non-empty string.",
            severity="error",
            category="correctness",
            blocking=True,
        ),
        "ENV_NOT_FOUND": RuleMetadata(
            code="ENV_NOT_FOUND",
            title="Environment Not Found",
            description="Requested environment does not exist.",
            severity="error",
            category="correctness",
            blocking=True,
        ),
        # License Rules
        "LICENSE_MISSING": RuleMetadata(
            code="LICENSE_MISSING",
            title="No License Found",
            description="No valid license token found. Running in free mode.",
            doc_url="https://ready-4-it.com/docs/mgpy/rules/LICENSE_MISSING",
            severity="warn",
            category="compliance",
            blocking=False,
        ),
        "LICENSE_INVALID_FORMAT": RuleMetadata(
            code="LICENSE_INVALID_FORMAT",
            title="Invalid License Format",
            description="License token format is invalid.",
            severity="error",
            category="compliance",
            blocking=True,
        ),
        "LICENSE_BAD_SIGNATURE": RuleMetadata(
            code="LICENSE_BAD_SIGNATURE",
            title="License Signature Verification Failed",
            description="License signature could not be verified.",
            severity="error",
            category="security",
            blocking=True,
        ),
        "LICENSE_EXPIRED": RuleMetadata(
            code="LICENSE_EXPIRED",
            title="License Expired",
            description="License has expired.",
            severity="error",
            category="compliance",
            blocking=True,
        ),
        "LICENSE_TIME_ROLLBACK": RuleMetadata(
            code="LICENSE_TIME_ROLLBACK",
            title="Clock Manipulation Detected",
            description="System clock rollback detected. Please verify system time.",
            severity="error",
            category="security",
            blocking=True,
        ),
        "LICENSE_SLOTS_EXHAUSTED": RuleMetadata(
            code="LICENSE_SLOTS_EXHAUSTED",
            title="Device Activation Slots Exhausted",
            description="All device activation slots are in use.",
            severity="error",
            category="compliance",
            blocking=True,
            quick_fixes=[
                QuickFixAction(
                    title="Deactivate another device",
                    command="manifestguard.license.deactivate",
                ),
            ],
        ),
        # i18n Rules
        "TRANSLATION_MISSING": RuleMetadata(
            code="TRANSLATION_MISSING",
            title="Missing Translation Key",
            description="Translation key is used but not defined.",
            doc_url="https://ready-4-it.com/docs/mgpy/rules/TRANSLATION_MISSING",
            severity="error",
            category="compliance",
            blocking=True,
            examples=['i18n.get("environment.create.success", "en", "environment")'],
        ),
        "TRANSLATION_UNUSED": RuleMetadata(
            code="TRANSLATION_UNUSED",
            title="Unused Translation Key",
            description="Translation key is defined but never used.",
            severity="info",
            category="best-practice",
            blocking=False,
        ),
        "TRANSLATION_FALLBACK": RuleMetadata(
            code="TRANSLATION_FALLBACK",
            title="Translation Fallback Used",
            description="Translation not found in requested language, using fallback.",
            severity="info",
            category="best-practice",
            blocking=False,
        ),
        # API Rules
        "API_VALIDATION_ERROR": RuleMetadata(
            code="API_VALIDATION_ERROR",
            title="API Validation Error",
            description="Request payload failed validation.",
            severity="error",
            category="correctness",
            blocking=True,
        ),
        "API_ROUTE_NOT_FOUND": RuleMetadata(
            code="API_ROUTE_NOT_FOUND",
            title="API Route Not Found",
            description="Requested API endpoint does not exist.",
            severity="error",
            category="correctness",
            blocking=True,
        ),
        # Workflow Rules
        "WORKFLOW_CONSENT_MISSING": RuleMetadata(
            code="WORKFLOW_CONSENT_MISSING",
            title="Workflow Consent Required",
            description="User consent required before executing this workflow.",
            doc_url="https://ready-4-it.com/docs/mgpy/rules/WORKFLOW_CONSENT_MISSING",
            severity="warn",
            category="security",
            blocking=True,
            quick_fixes=[
                QuickFixAction(
                    title="Grant consent", command="manifestguard.workflow.grantConsent"
                ),
            ],
        ),
        "WORKFLOW_ACCESS_DENIED": RuleMetadata(
            code="WORKFLOW_ACCESS_DENIED",
            title="Workflow Access Denied",
            description="Workflow execution blocked by access level policy.",
            severity="error",
            category="security",
            blocking=True,
        ),
        # Configuration Rules
        "CONFIG_INVALID": RuleMetadata(
            code="CONFIG_INVALID",
            title="Invalid Configuration",
            description="manifestguard.json contains invalid configuration.",
            severity="error",
            category="correctness",
            blocking=True,
        ),
        "CONFIG_DEPRECATED": RuleMetadata(
            code="CONFIG_DEPRECATED",
            title="Deprecated Configuration Key",
            description="Configuration uses deprecated key.",
            severity="warn",
            category="compatibility",
            blocking=False,
        ),
        # Security Rules
        "SECURITY_WEAK_HASH": RuleMetadata(
            code="SECURITY_WEAK_HASH",
            title="Weak Hashing Algorithm",
            description="Using weak hashing algorithm (MD5, SHA1).",
            severity="warn",
            category="security",
            blocking=False,
        ),
        "SECURITY_HARDCODED_SECRET": RuleMetadata(
            code="SECURITY_HARDCODED_SECRET",
            title="Hardcoded Secret Detected",
            description="Potential hardcoded secret or API key found.",
            severity="error",
            category="security",
            blocking=True,
        ),
        # Python Version Rules
        "PYTHON_VERSION_INCOMPATIBLE": RuleMetadata(
            code="PYTHON_VERSION_INCOMPATIBLE",
            title="Python Version Incompatible",
            description="Current Python version does not meet minimum requirements.",
            severity="error",
            category="compatibility",
            blocking=True,
        ),
        "PYTHON_VERSION_DEPRECATED": RuleMetadata(
            code="PYTHON_VERSION_DEPRECATED",
            title="Python Version Deprecated",
            description="Python version is deprecated. Consider upgrading.",
            severity="warn",
            category="compatibility",
            blocking=False,
        ),
    }

    @classmethod
    def get(cls, code: str) -> RuleMetadata | None:
        """Get metadata for specific rule code"""
        return cls._rules.get(code)

    @classmethod
    def get_all(cls) -> list[RuleMetadata]:
        """Get all registered rules"""
        return list(cls._rules.values())

    @classmethod
    def has(cls, code: str) -> bool:
        """Check if rule code exists"""
        return code in cls._rules

    @classmethod
    def get_by_category(cls, category: str) -> list[RuleMetadata]:
        """Get all rules by category"""
        return [r for r in cls._rules.values() if r.category == category]

    @classmethod
    def get_non_blocking(cls) -> list[RuleMetadata]:
        """Get all non-blocking (INFO-level) rules"""
        return [r for r in cls._rules.values() if not r.blocking]

    @classmethod
    def get_blocking(cls) -> list[RuleMetadata]:
        """Get all blocking rules"""
        return [r for r in cls._rules.values() if r.blocking]

    @classmethod
    def register(cls, rule: RuleMetadata) -> None:
        """Register new custom rule at runtime"""
        if rule.code in cls._rules:
            # Warn about overwrite (would use logger if available)
            pass
        cls._rules[rule.code] = rule

    @classmethod
    def unregister(cls, code: str) -> bool:
        """Unregister a rule"""
        if code in cls._rules:
            del cls._rules[code]
            return True
        return False

    @classmethod
    def get_by_severity(cls, severity: Literal["info", "warn", "error"]) -> list[RuleMetadata]:
        """Get all rules with specific severity"""
        return [r for r in cls._rules.values() if r.severity == severity]

    @classmethod
    def search(cls, query: str) -> list[RuleMetadata]:
        """Search rules by code, title, or description"""
        query_lower = query.lower()
        return [
            r
            for r in cls._rules.values()
            if query_lower in r.code.lower()
            or query_lower in r.title.lower()
            or query_lower in r.description.lower()
        ]
