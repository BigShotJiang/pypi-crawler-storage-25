"""Validators with RuleRegistry integration"""

from typing import Any


class ValidationError(Exception):
    """Validation error with rule code"""

    def __init__(self, rule_code: str, message: str, field: str | None = None):
        self.rule_code = rule_code
        self.message = message
        self.field = field
        super().__init__(message)


def validate_environment_payload(payload: dict[str, Any]) -> tuple[bool, str]:
    """Validate environment payload (legacy interface)"""
    if not isinstance(payload, dict):
        pass  # Type check happens at runtime
    name = payload.get("name")
    if not name or not isinstance(name, str) or not name.strip():
        return False, "name"
    # optional description length
    desc = payload.get("description")
    if desc is not None and not isinstance(desc, str):
        return False, "description must be a string"
    return True, ""


def validate_environment(payload: dict[str, Any]) -> None:
    """Validate environment payload with RuleRegistry codes (raises ValidationError)"""
    if not isinstance(payload, dict):
        raise ValidationError("API_VALIDATION_ERROR", "Payload must be an object")

    name = payload.get("name")
    if not name or not isinstance(name, str) or not name.strip():
        raise ValidationError(
            "ENV_NAME_MISSING",
            "Environment name is required and must be a non-empty string",
            field="name",
        )

    desc = payload.get("description")
    if desc is not None and not isinstance(desc, str):
        raise ValidationError(
            "API_VALIDATION_ERROR",
            "Description must be a string",
            field="description",
        )


def validate_workflow_id(workflow_id: str) -> None:
    """Validate workflow ID format"""
    if not workflow_id or not isinstance(workflow_id, str):
        raise ValidationError("API_VALIDATION_ERROR", "Workflow ID must be a non-empty string")

    if not workflow_id.replace("_", "").replace("-", "").isalnum():
        raise ValidationError(
            "API_VALIDATION_ERROR",
            "Workflow ID must contain only alphanumeric characters, hyphens, and underscores",
        )
