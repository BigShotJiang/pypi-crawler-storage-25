"""Security helpers with Ed25519 and version-aware crypto"""

import hashlib
import hmac

try:
    import nacl.encoding
    import nacl.signing

    HAS_NACL = True
except ImportError:
    HAS_NACL = False


def verify_signature(secret: bytes, message: bytes, signature_hex: str) -> bool:
    """Verify HMAC-SHA256 signature (legacy)"""
    mac = hmac.new(secret, message, hashlib.sha256).hexdigest()
    return hmac.compare_digest(mac, signature_hex)


def verify_ed25519_signature(public_key_base64: str, message: bytes, signature: bytes) -> bool:
    """Verify Ed25519 signature (for license tokens)"""
    if not HAS_NACL:
        raise RuntimeError("PyNaCl required for Ed25519 signature verification")

    try:
        key_bytes = (
            public_key_base64.encode() if isinstance(public_key_base64, str) else public_key_base64
        )
        public_key = nacl.signing.VerifyKey(
            key_bytes,
            encoder=nacl.encoding.Base64Encoder,
        )
        public_key.verify(message, signature)
        return True
    except Exception:
        return False


def has_role(user_roles: list[str] | None, required: str) -> bool:
    """Check if user has required role"""
    if not user_roles:
        return False
    return required in user_roles


def has_any_role(user_roles: list[str] | None, required: list[str]) -> bool:
    """Check if user has any of the required roles"""
    if not user_roles:
        return False
    return any(role in user_roles for role in required)


def check_password_strength(pwd: str) -> tuple[bool, str | None]:
    """Check password strength (basic validation)"""
    if len(pwd) < 8:
        return False, "Credential must be at least 8 characters"

    if not any(c.isupper() for c in pwd):
        return False, "Credential must contain at least one uppercase letter"

    if not any(c.islower() for c in pwd):
        return False, "Credential must contain at least one lowercase letter"

    if not any(c.isdigit() for c in pwd):
        return False, "Credential must contain at least one digit"

    return True, None
