"""List Interface for ManifestGuard

Provides abstract base classes for structured list data providers.
Used for CLI output and API responses with tree-like structures.

Part of Feature Parity Plan - ListInterface implementation.
"""

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class ListItem:
    """Generic list item for CLI/API output

    Represents a single item in a hierarchical list structure.
    """

    id: str
    label: str
    description: str | None = None
    icon: str | None = None  # CLI: emoji, API: icon name
    children: list["ListItem"] | None = None
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "label": self.label,
            "description": self.description,
            "icon": self.icon,
            "children": [child.to_dict() for child in (self.children or [])],
            "metadata": self.metadata or {},
        }


class IList(ABC):
    """Abstract interface for list data providers

    Implementations provide structured data for CLI trees or API responses.
    """

    @abstractmethod
    def get_items(self) -> list[ListItem]:
        """Return list items

        Returns:
            List of ListItem objects representing the data structure

        """
        # Note: this is an abstract method; the return value is not used.
        # Returning an empty list keeps the body non-empty for policy checks.
        return []

    @abstractmethod
    def refresh(self) -> None:
        """Refresh the list data

        Called when the underlying data might have changed.
        """
        # Note: this is an abstract method; implementations should override.
        return None

    def to_json(self) -> list[dict[str, Any]]:
        """Convert list to JSON-serializable format

        Returns:
            List of dictionaries representing the items

        """
        return [item.to_dict() for item in self.get_items()]

    def to_cli_tree(self, prefix: str = "") -> str:
        """Render list as CLI tree with Unicode symbols

        Returns:
            String representation of the tree structure

        """
        items = self.get_items()
        if not items:
            return "No items"

        lines = []
        for i, item in enumerate(items):
            is_last = i == len(items) - 1
            connector = "└─ " if is_last else "├─ "

            # Item line
            icon = item.icon or "•"
            line = f"{prefix}{connector}{icon} {item.label}"
            lines.append(line)

            # Description if present
            if item.description:
                desc_prefix = "    " if is_last else "│   "
                lines.append(f"{prefix}{desc_prefix}{item.description}")

            # Children recursively
            if item.children:
                child_prefix = "    " if is_last else "│   "
                child_tree = self._render_children(item.children, prefix + child_prefix)
                lines.extend(child_tree.split("\n") if child_tree else [])

        return "\n".join(lines)

    def _render_children(self, children: list[ListItem], prefix: str) -> str:
        """Helper to render child items"""
        if not children:
            return ""

        lines = []
        for i, child in enumerate(children):
            is_last = i == len(children) - 1
            connector = "└─ " if is_last else "├─ "

            icon = child.icon or "•"
            line = f"{prefix}{connector}{icon} {child.label}"
            lines.append(line)

            if child.description:
                desc_prefix = "    " if is_last else "│   "
                lines.append(f"{prefix}{desc_prefix}{child.description}")

            if child.children:
                child_prefix = "    " if is_last else "│   "
                child_tree = self._render_children(child.children, prefix + child_prefix)
                lines.extend(child_tree.split("\n") if child_tree else [])

        return "\n".join(lines)


class LicenseStatusList(IList):
    """List provider for license status information

    Shows current license state, tier, and expiration info.
    """

    def __init__(self, licensing_client: Any) -> None:
        self.client = licensing_client

    def get_items(self) -> list[ListItem]:
        """Get license status as list items"""
        from manifestguard.licensing.client import LicenseStatusCode  # noqa: PLC0415 - avoid circular import

        token = self.client.get_token()

        if not token:
            # No license
            return [
                ListItem(
                    id="license-status",
                    label="No License",
                    description="Using community features only",
                    icon="❌",
                    metadata={"tier": "community"},
                )
            ]

        status = self.client.verify_token(token)

        if status.code != LicenseStatusCode.OK:
            # Invalid license
            return [
                ListItem(
                    id="license-status",
                    label=f"Invalid License: {status.message}",
                    description="Please check your license or contact support",
                    icon="⚠️",
                    metadata={"tier": "community", "error": status.message},
                )
            ]

        # Valid license
        tier = status.payload.get("tier", "unknown")
        sub = status.payload.get("sub", "unknown")
        exp = status.payload.get("exp", 0)

        # Format expiration
        if exp > time.time():
            days_left = int((exp - time.time()) / 86400)
            exp_text = f"Expires in {days_left} days"
        else:
            exp_text = "Expired"

        icon = "🆓" if status.trial else "✅"
        label = f"License: {tier.title()}"
        if status.trial:
            label = "License: Trial"

        return [
            ListItem(
                id="license-status",
                label=label,
                description=f"Subscription: {sub} - {exp_text}",
                icon=icon,
                metadata={
                    "tier": tier,
                    "subscription": sub,
                    "expires": exp,
                    "trial": status.trial,
                },
            )
        ]

    def refresh(self) -> None:
        """Refresh license status.

        Best-effort: mark refresh time and invalidate any client-side caches if available.
        """
        self._last_refresh_ts = time.time()
        for method_name in ("invalidate_cache", "clear_cache", "reset_cache"):
            method = getattr(self.client, method_name, None)
            if callable(method):
                try:
                    method()
                except Exception:
                    pass
                break
