from __future__ import annotations

import json
import os
import socket
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RunLockInfo:
    pid: int | None
    started_at: str | None
    hostname: str | None
    cwd: str | None
    command: str | None
    report_path: str | None


class RunLockHeldError(RuntimeError):
    def __init__(
        self,
        lock_path: Path,
        info: RunLockInfo,
        is_owner_running: bool | None,
    ) -> None:
        self.lock_path = lock_path
        self.info = info
        self.is_owner_running = is_owner_running
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        pid = self.info.pid
        started = self.info.started_at
        running = self.is_owner_running

        running_text = "läuft" if running is True else "läuft nicht" if running is False else "unbekannt"

        parts = ["Ein anderer ManifestGuard-Lauf ist bereits aktiv (Sperrdatei gefunden)."]
        if pid is not None:
            parts.append(f"PID: {pid} ({running_text})")
        else:
            parts.append("PID: unbekannt (unbekannt)")
        if started:
            parts.append(f"Gestartet: {started}")
        else:
            parts.append("Gestartet: unbekannt")
        if self.info.command:
            parts.append(f"Command: {self.info.command}")
        if self.info.report_path:
            parts.append(f"Report: {self.info.report_path}")
        parts.append(f"Sperrdatei: {self.lock_path}")
        parts.append(
            "Hinweis: Wenn du sicher bist, dass kein ManifestGuard-Prozess mehr läuft, lösche die Sperrdatei manuell, um die Sperre aufzuheben."
        )
        return "\n".join(parts)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_pid_running(pid: int) -> bool | None:
    """Best-effort cross-platform PID liveness check.

    Returns:
        True  -> process appears to be running
        False -> process appears to be not running
        None  -> cannot determine reliably
    """

    if pid <= 0:
        return False

    if sys.platform == "win32":
        try:
            import ctypes

            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259

            handle = ctypes.windll.kernel32.OpenProcess(
                PROCESS_QUERY_LIMITED_INFORMATION, 0, pid
            )
            if not handle:
                return False
            try:
                exit_code = ctypes.c_ulong()
                ok = ctypes.windll.kernel32.GetExitCodeProcess(
                    handle, ctypes.byref(exit_code)
                )
                if not ok:
                    return None
                return exit_code.value == STILL_ACTIVE
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
        except Exception:
            return None

    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return None
    except OSError:
        return False


class RunLock:
    def __init__(
        self,
        lock_path: Path,
        *,
        command: str,
        report_path: str | None = None,
    ) -> None:
        self._lock_path = lock_path
        self._command = command
        self._report_path = report_path
        self._acquired = False

    @property
    def lock_path(self) -> Path:
        return self._lock_path

    def acquire(self) -> None:
        self._lock_path.parent.mkdir(parents=True, exist_ok=True)

        info = {
            "version": 1,
            "pid": os.getpid(),
            "startedAt": _utc_now_iso(),
            "hostname": socket.gethostname(),
            "cwd": str(Path.cwd()),
            "command": self._command,
            "reportPath": self._report_path,
        }

        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        fd: int | None = None
        try:
            fd = os.open(self._lock_path, flags)
        except FileExistsError:
            existing = self._read_info_best_effort(self._lock_path)
            owner_running: bool | None = None
            if existing.pid is not None:
                owner_running = is_pid_running(existing.pid)
            raise RunLockHeldError(self._lock_path, existing, owner_running)
        else:
            try:
                os.write(fd, json.dumps(info, ensure_ascii=False, indent=2).encode("utf-8"))
            finally:
                os.close(fd)
            self._acquired = True

    def release(self) -> None:
        if not self._acquired:
            return
        try:
            self._lock_path.unlink(missing_ok=True)
        finally:
            self._acquired = False

    def __enter__(self) -> "RunLock":
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.release()

    @staticmethod
    def _read_info_best_effort(lock_path: Path) -> RunLockInfo:
        try:
            raw = lock_path.read_text(encoding="utf-8")
            data = json.loads(raw) if raw else {}
        except Exception:
            return RunLockInfo(
                pid=None,
                started_at=None,
                hostname=None,
                cwd=None,
                command=None,
                report_path=None,
            )

        def _s(key: str) -> str | None:
            value = data.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
            return None

        pid_val: Any = data.get("pid")
        pid: int | None = None
        if isinstance(pid_val, int):
            pid = pid_val
        elif isinstance(pid_val, str) and pid_val.strip().isdigit():
            pid = int(pid_val.strip())

        return RunLockInfo(
            pid=pid,
            started_at=_s("startedAt"),
            hostname=_s("hostname"),
            cwd=_s("cwd"),
            command=_s("command"),
            report_path=_s("reportPath"),
        )
