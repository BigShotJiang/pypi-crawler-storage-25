from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

from manifestguard.core.safe_json_writer import write_json_file_sync


def user_config_dir(app_name: str = "manifestguard") -> Path:
    """Return per-user configuration directory.

    Windows: %APPDATA%/<app_name> (fallback ~/.manifestguard)
    Linux:   $XDG_CONFIG_HOME/<app_name> (fallback ~/.config/<app_name>)
    macOS:   (treated like Linux fallback) ~/.config/<app_name>

    Note: This function creates the directory if needed.
    """

    if sys.platform == "win32":
        app_data = os.environ.get("APPDATA")
        base_dir = Path(app_data) / app_name if app_data else Path.home() / ".manifestguard"
    else:
        xdg = os.environ.get("XDG_CONFIG_HOME")
        base_dir = Path(xdg) / app_name if xdg else Path.home() / ".config" / app_name

    base_dir.mkdir(parents=True, exist_ok=True)
    return base_dir


def user_settings_path() -> Path:
    """Return the per-user settings JSON path.

    Environment override:
        MANIFESTGUARD_USER_SETTINGS_PATH
    """

    env = os.environ.get("MANIFESTGUARD_USER_SETTINGS_PATH")
    if env:
        return Path(env)
    return user_config_dir("manifestguard") / "user.json"


def load_user_settings() -> dict[str, Any]:
    path = user_settings_path()
    try:
        if not path.exists():
            return {}
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def save_user_settings(settings: dict[str, Any]) -> None:
    path = user_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    write_json_file_sync(path, settings, prettify=True, indent=2, line_ending="lf")
