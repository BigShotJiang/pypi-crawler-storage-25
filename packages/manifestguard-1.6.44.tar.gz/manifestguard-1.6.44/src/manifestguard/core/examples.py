"""Example data for ManifestGuard configurations, reports, and schemas.

Provides template data for:
- manifestguard.json configuration
- Report JSON structure
- History JSON structure
- Metrics/schema examples
"""

import json

EXAMPLE_CONFIG = {
    "licenseKey": "your-license-key-here",
    "accessLevel": "balanced",
    "ignorePatterns": [
        "*.pyc",
        "__pycache__/",
        ".venv/",
        ".pytest_cache/",
        "*.egg-info/",
        "dist/",
        "build/",
        ".git/",
        "node_modules/",
        "coverage.json",
        ".coverage",
    ],
    "python": {"minVersion": "3.10"},
    "rules": {"MG-001": True, "MG-002": True, "MG-003": True},
    "severityOverrides": {"MG-001": "error", "MG-002": "warn"},
    "dependencyRules": {
        "allowedLicenses": ["MIT", "Apache-2.0", "BSD-3-Clause"],
        "blockedPackages": ["package-to-avoid"],
    },
    "suppressions": [
        {
            "code": "DUMMY-001",
            "pattern": "examples/**",
            "reason": "Example code intentionally contains placeholders",
            "expires": "2025-12-31",
        }
    ],
    "ai": {
        "provider": "ollama",
        "model": "llama3.1",
        "ollama": {"baseUrl": "http://localhost:11434"},
        "security": {
            "accessLevel": "balanced",
            "consentedWorkflows": ["code-review"],
            "allowedHosts": ["localhost"],
        },
    },
    "quickfix": {
        "backup": {
            "mode": "git",  # git | snapshot | both
            "dir": ".manifestguard-backups/",
            "requireCleanGit": True,
            "autoCommit": False,
            "maxBackups": 100,
            "dryRun": False
        }
    }
}

EXAMPLE_REPORT = {
    "timestamp": "2025-12-26T12:00:00Z",
    "version": "1.5.16",
    "workspace": "/path/to/workspace",
    "summary": {"totalErrors": 2, "totalWarnings": 5, "totalInfo": 10, "passed": True},
    "manifestValidation": {
        "pyproject": {"valid": True, "diagnostics": []},
        "requirements": {"valid": True, "diagnostics": []},
    },
    "extendedMetrics": {
        "coverage": {"line": 85.5, "branch": 78.2, "function": 92.1},
        "complexity": {
            "avgCyclomatic": 3.2,
            "maxCyclomatic": 12,
            "violations": [
                {
                    "file": "src/module.py",
                    "function": "complex_function",
                    "line": 42,
                    "complexity": 12,
                    "severity": "warn",
                }
            ],
        },
        "duplication": {"totalGroups": 3, "totalLines": 150, "percentDuplicated": 2.5},
    },
    "policyMetrics": {
        "dummyCode": {"totalViolations": 2, "byCode": {"DUMMY-001": 1, "DUMMY-002": 1}}
    },
    "scanSpace": {
        "includedFiles": 120,
        "excludedFiles": 85,
        "excludedBy": {"built-in": 60, ".gitignore": 15, "manifestguard.json": 10},
    },
}

EXAMPLE_HISTORY = {
    "version": "1.0",
    "workspace": "/path/to/workspace",
    "entries": [
        {
            "timestamp": "2025-12-26T12:00:00Z",
            "version": "1.5.16",
            "summary": {"totalErrors": 2, "totalWarnings": 5, "totalInfo": 10},
            "coverage": {"line": 85.5},
            "complexity": {"avgCyclomatic": 3.2, "maxCyclomatic": 12},
        },
        {
            "timestamp": "2025-12-25T12:00:00Z",
            "version": "1.5.14",
            "summary": {"totalErrors": 3, "totalWarnings": 7, "totalInfo": 12},
            "coverage": {"line": 84.2},
            "complexity": {"avgCyclomatic": 3.5, "maxCyclomatic": 15},
        },
    ],
}

EXAMPLE_METRICS_SCHEMA = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "ManifestGuard Metrics",
    "type": "object",
    "properties": {
        "coverage": {
            "type": "object",
            "properties": {
                "line": {"type": "number", "minimum": 0, "maximum": 100},
                "branch": {"type": "number", "minimum": 0, "maximum": 100},
                "function": {"type": "number", "minimum": 0, "maximum": 100},
            },
        },
        "complexity": {
            "type": "object",
            "properties": {
                "avgCyclomatic": {"type": "number", "minimum": 0},
                "maxCyclomatic": {"type": "number", "minimum": 0},
                "violations": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "file": {"type": "string"},
                            "function": {"type": "string"},
                            "line": {"type": "integer"},
                            "complexity": {"type": "integer"},
                            "severity": {"type": "string", "enum": ["info", "warn", "error"]},
                        },
                    },
                },
            },
        },
        "duplication": {
            "type": "object",
            "properties": {
                "totalGroups": {"type": "integer", "minimum": 0},
                "totalLines": {"type": "integer", "minimum": 0},
                "percentDuplicated": {"type": "number", "minimum": 0, "maximum": 100},
            },
        },
    },
}


def get_example_config() -> dict:
    """Get example manifestguard.json configuration."""
    return EXAMPLE_CONFIG.copy()


def get_example_report() -> dict:
    """Get example report JSON structure."""
    return EXAMPLE_REPORT.copy()


def get_example_history() -> dict:
    """Get example history JSON structure."""
    return EXAMPLE_HISTORY.copy()


def get_example_metrics_schema() -> dict:
    """Get example metrics JSON schema."""
    return EXAMPLE_METRICS_SCHEMA.copy()


def print_all_examples() -> None:
    """Print all examples to console."""
    print("=" * 80)
    print("EXAMPLE: manifestguard.json Configuration")
    print("=" * 80)
    print(json.dumps(EXAMPLE_CONFIG, indent=2))

    print("\n" + "=" * 80)
    print("EXAMPLE: Report JSON Structure")
    print("=" * 80)
    print(json.dumps(EXAMPLE_REPORT, indent=2))

    print("\n" + "=" * 80)
    print("EXAMPLE: History JSON Structure")
    print("=" * 80)
    print(json.dumps(EXAMPLE_HISTORY, indent=2))

    print("\n" + "=" * 80)
    print("EXAMPLE: Metrics JSON Schema")
    print("=" * 80)
    print(json.dumps(EXAMPLE_METRICS_SCHEMA, indent=2))
