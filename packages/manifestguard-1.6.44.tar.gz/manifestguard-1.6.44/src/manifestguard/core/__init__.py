"""ManifestGuard Core Module

Central components ported from VS Code extension with Python best practices.

Modules:
- config: Hierarchical configuration service
- logging: Enhanced logger with output channel pattern
- audit: Audit trail with rule code tracking
- security: Crypto helpers (HMAC, Ed25519, role-based access)
- validators: Validation with structured errors
- rule_registry: Centralized rule metadata registry
- workflow: Consent-based workflow execution
- version_check: Python version detection and feature flags
"""

from .audit import Audit
from .config import AccessLevel, ConfigurationService, EffectiveConfig
from .list_interface import IList, LicenseStatusList, ListItem
from .logging import Logger, get_logger, log_struct, setup_logger
from .rule_registry import QuickFixAction, RuleMetadata, RuleRegistry
from .security import (
    HAS_NACL,
    check_password_strength,
    has_any_role,
    has_role,
    verify_ed25519_signature,
    verify_signature,
)
from .validators import (
    ValidationError,
    validate_environment,
    validate_environment_payload,
    validate_workflow_id,
)
from .version_check import (
    FeatureFlags,
    PythonVersionInfo,
    check_version_range,
    compare_versions,
    get_compatibility_layer,
    get_feature_flags,
    get_python_version,
    require_python_version,
)
from .version_validator import VersionInfo, VersionValidator, validate_package_version
from .workflow import WorkflowDescriptor, WorkflowDispatcher, WorkflowService, WorkflowTrigger

__all__ = [
    "HAS_NACL",
    "AccessLevel",
    # Audit
    "Audit",
    # Config
    "ConfigurationService",
    "EffectiveConfig",
    "FeatureFlags",
    # List Interface
    "IList",
    "LicenseStatusList",
    "ListItem",
    # Logging
    "Logger",
    "PythonVersionInfo",
    "QuickFixAction",
    "RuleMetadata",
    # Rule Registry
    "RuleRegistry",
    "ValidationError",
    "VersionInfo",
    # Version Validator
    "VersionValidator",
    "WorkflowDescriptor",
    "WorkflowDispatcher",
    # Workflow
    "WorkflowService",
    "WorkflowTrigger",
    "check_password_strength",
    "check_version_range",
    "compare_versions",
    "get_compatibility_layer",
    "get_feature_flags",
    "get_logger",
    # Version Check
    "get_python_version",
    "has_any_role",
    "has_role",
    "log_struct",
    "require_python_version",
    "setup_logger",
    "validate_environment",
    # Validators
    "validate_environment_payload",
    "validate_package_version",
    "validate_workflow_id",
    "verify_ed25519_signature",
    # Security
    "verify_signature",
]
