"""Git check — list files that should or should not be committed to git.

Each known path pattern is classified as:
  COMMIT   — should be tracked in VCS (config owned by the project).
  IGNORE   — should NOT be tracked (runtime/machine-local data).
  WARNING  — currently tracked but should be removed (git rm --cached).

Run ``manifestguard git-check`` to see the full report.
"""
from __future__ import annotations

import subprocess
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from manifestguard.i18n import t


class GitCheckAction(str, Enum):
    COMMIT = "commit"
    IGNORE = "ignore"
    WARNING = "warning"


@dataclass
class GitCheckItem:
    path: str
    action: GitCheckAction
    reason: str
    exists: bool
    tracked: bool


# ---------------------------------------------------------------------------
# Known patterns: (relative_path_or_glob, expected_action, i18n_reason_key)
# Glob patterns are matched via Path.glob(); fixed paths are tested directly.
# ---------------------------------------------------------------------------
_COMMIT_ITEMS_MGPY: list[tuple[str, GitCheckAction, str]] = [
    (".mgpy/mg.rules.refactoring.json", GitCheckAction.COMMIT, "git_check.reason.rules_refactoring"),
    (".mgpy/readme.rules.en.md",        GitCheckAction.COMMIT, "git_check.reason.rules_readme"),
]

_COMMIT_ITEMS_MGVS: list[tuple[str, GitCheckAction, str]] = [
    (".mgvs/mg.rules.refactoring.json", GitCheckAction.COMMIT, "git_check.reason.rules_refactoring"),
]

_IGNORE_ITEMS: list[tuple[str, GitCheckAction, str]] = [
    (".mgvs/cache",                            GitCheckAction.IGNORE, "git_check.reason.local_state"),
    (".manifestguard/baselines",                  GitCheckAction.IGNORE, "git_check.reason.baselines"),
    (".manifestguard/metrics*.json",              GitCheckAction.IGNORE, "git_check.reason.metrics"),
    (".manifestguard/duplication_cache*.json.gz", GitCheckAction.IGNORE, "git_check.reason.duplication_cache"),
    (".manifestguard/coverage*.json",             GitCheckAction.IGNORE, "git_check.reason.coverage"),
    (".manifestguard/tui-snapshot.md",            GitCheckAction.IGNORE, "git_check.reason.tui_snapshot"),
    (".manifestguard/tmp-*.txt",                  GitCheckAction.IGNORE, "git_check.reason.tmp_files"),
    (".manifestguard/tmp-*.json",                 GitCheckAction.IGNORE, "git_check.reason.tmp_files"),
    (".manifestguard/recommendation-acks.json",   GitCheckAction.IGNORE, "git_check.reason.local_state"),
    (".manifestguard/dashboard-stats.html",       GitCheckAction.IGNORE, "git_check.reason.local_state"),
    ("worker-report.md",                      GitCheckAction.IGNORE, "git_check.reason.local_state"),
    ("worker-report.html",                    GitCheckAction.IGNORE, "git_check.reason.local_state"),
    ("multi-interpreter-validation-report.json", GitCheckAction.IGNORE, "git_check.reason.ci_coverage"),
    ("manifestguard-report*.json",             GitCheckAction.IGNORE, "git_check.reason.metrics"),
    ("coverage.xml",                              GitCheckAction.IGNORE, "git_check.reason.ci_coverage"),
    ("coverage.json",                             GitCheckAction.IGNORE, "git_check.reason.ci_coverage"),
    (".manifestguard/_coverage_prelude.py",       GitCheckAction.IGNORE, "git_check.reason.ci_coverage"),
]


def _should_check_mgpy_items(workspace_root: Path) -> bool:
    return (workspace_root / ".mgpy").exists() or any(
        _is_tracked(workspace_root, pattern) for pattern, _, _ in _COMMIT_ITEMS_MGPY
    )


def _should_check_mgvs_items(workspace_root: Path) -> bool:
    # IMPORTANT: only enforce MGVS SSOT if the SSOT file itself exists or is tracked.
    # Some Python repos may have a .mgvs directory for unrelated reasons.
    ssot_rel = ".mgvs/mg.rules.refactoring.json"
    return (workspace_root / ssot_rel).exists() or _is_tracked(workspace_root, ssot_rel)


def _git_tracked_paths(workspace_root: Path, pattern: str) -> list[str]:
    """Return all git-tracked paths matching *pattern* (relative to workspace_root)."""
    try:
        result = subprocess.run(
            ["git", "ls-files", pattern],
            capture_output=True,
            text=True,
            cwd=str(workspace_root),
            timeout=10,
        )
        lines = [ln.strip() for ln in result.stdout.splitlines() if ln.strip()]
        return lines
    except Exception:
        return []


def is_git_repo(workspace_root: Path) -> bool:
    """Return True if *workspace_root* is inside a git worktree."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
            cwd=str(workspace_root),
            timeout=5,
        )
        return result.returncode == 0 and result.stdout.strip().lower() == "true"
    except Exception:
        return False


def _is_tracked(workspace_root: Path, rel_path: str) -> bool:
    return bool(_git_tracked_paths(workspace_root, rel_path))


def run_git_check(workspace_root: Path) -> list[GitCheckItem]:
    """Analyse the workspace and return a list of :class:`GitCheckItem`."""
    items: list[GitCheckItem] = []

    known_items: list[tuple[str, GitCheckAction, str]] = []
    if _should_check_mgpy_items(workspace_root):
        known_items.extend(_COMMIT_ITEMS_MGPY)
    if _should_check_mgvs_items(workspace_root):
        known_items.extend(_COMMIT_ITEMS_MGVS)
    known_items.extend(_IGNORE_ITEMS)

    for pattern, expected_action, reason_key in known_items:
        reason = t(reason_key, module="core")
        is_glob = any(c in pattern for c in ("*", "?", "["))

        if is_glob:
            # Expand glob on-disk
            matched_paths = sorted(workspace_root.glob(pattern))
            # Also check if git tracks any files matching the pattern
            tracked_in_git = set(_git_tracked_paths(workspace_root, pattern))

            if not matched_paths and not tracked_in_git:
                # Nothing on disk and nothing tracked — skip (no news is good news)
                continue

            reported: set[str] = set()

            for p in matched_paths:
                rel = p.relative_to(workspace_root).as_posix()
                tracked = rel in tracked_in_git or _is_tracked(workspace_root, rel)
                action = GitCheckAction.WARNING if (expected_action == GitCheckAction.IGNORE and tracked) else expected_action
                items.append(GitCheckItem(path=rel, action=action, reason=reason, exists=True, tracked=tracked))
                reported.add(rel)

            # Also report any git-tracked files not found on disk
            for rel in sorted(tracked_in_git - reported):
                items.append(GitCheckItem(path=rel, action=GitCheckAction.WARNING, reason=reason, exists=False, tracked=True))

        else:
            target = workspace_root / pattern
            # For directories, check existence differently
            exists = target.exists()
            tracked = _is_tracked(workspace_root, pattern)

            if not exists and not tracked:
                if expected_action == GitCheckAction.COMMIT:
                    # Config file is missing entirely — report it so devs know
                    items.append(GitCheckItem(path=pattern, action=GitCheckAction.COMMIT, reason=reason, exists=False, tracked=False))
                # For IGNORE patterns: if neither exists nor tracked, skip silently
                continue

            action = expected_action
            if expected_action == GitCheckAction.IGNORE and tracked:
                action = GitCheckAction.WARNING

            items.append(GitCheckItem(path=pattern, action=action, reason=reason, exists=exists, tracked=tracked))

    return items


def format_git_check_report(items: list[GitCheckItem]) -> dict[str, Any]:
    """Return the git-check result as a JSON-serialisable dict."""
    def _item(i: GitCheckItem) -> dict[str, Any]:
        return {
            "path": i.path,
            "action": i.action.value,
            "reason": i.reason,
            "exists": i.exists,
            "tracked": i.tracked,
        }

    return {
        "items": [_item(i) for i in items],
        "summary": {
            "warnings": sum(1 for i in items if i.action == GitCheckAction.WARNING),
            "needs_commit": sum(1 for i in items if i.action == GitCheckAction.COMMIT and not i.tracked),
            "ok_committed": sum(1 for i in items if i.action == GitCheckAction.COMMIT and i.tracked),
            "ok_ignored": sum(1 for i in items if i.action == GitCheckAction.IGNORE and not i.tracked and i.exists),
        },
    }
