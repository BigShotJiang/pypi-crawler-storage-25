"""Configuration safety analysis to detect anti-patterns.

This module implements detection of the "ignore instead of repair" anti-pattern,
where users (or AI agents) add mass ignores to suppress validation errors
instead of fixing them properly.

Real-World Trigger (2025-01-02):
- 85 ruff issues encountered
- Initial attempt: Add all to global ignore list
- User challenge: "du hast ignore statt repair?"
- Lesson: Need automated detection to prevent this anti-pattern

See: concept.config-safety.en.md for full strategy and rationale.
"""

import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

logger = logging.getLogger(__name__)


# Detection thresholds
ABNORMAL_CONFIG_THRESHOLDS = {
    "ignore_ratio": 0.20,  # >20% of available rules ignored
    "new_ignores": 5,  # >5 new ignores in one config change
    "wildcard_ignores": 1,  # Patterns like "MG-*" (hides categories)
    "duplicate_ignores": 3,  # Same rule ignored in multiple places
}


@dataclass
class AbnormalConfigWarning:
    """Warning about abnormal configuration patterns."""

    code: str
    severity: Literal["warning", "error"]
    message: str
    suggestion: str
    details: dict[str, Any]
    doc_url: str = field(default="https://manifestguard.dev/docs/config-safety")


@dataclass
class ConfigState:
    """State snapshot of configuration for change detection."""

    version: str
    timestamp: str
    config_hash: str
    ignored_rules: list[str]
    ignore_ratio: float
    acknowledged: bool = False
    acknowledged_at: str | None = None


class ConfigAnalyzer:
    """Analyzer for detecting abnormal configuration patterns."""

    def __init__(self, total_rules: int = 32):
        """Initialize analyzer.

        Args:
            total_rules: Total number of available ManifestGuard rules
        """
        self.total_rules = total_rules

    def detect_abnormal_ignores(
        self,
        ignored_rules: list[str],
        previous_state: ConfigState | None = None,
    ) -> list[AbnormalConfigWarning]:
        """Detect abnormal ignore patterns in configuration.

        Args:
            ignored_rules: List of currently ignored rule IDs
            previous_state: Previous configuration state for diff analysis

        Returns:
            List of warnings about abnormal patterns
        """
        warnings: list[AbnormalConfigWarning] = []

        # 1. High ignore ratio
        ignore_ratio = len(ignored_rules) / self.total_rules if self.total_rules > 0 else 0
        if ignore_ratio > ABNORMAL_CONFIG_THRESHOLDS["ignore_ratio"]:
            warnings.append(
                AbnormalConfigWarning(
                    code="MG-CONFIG-001",
                    severity="warning",
                    message=(
                        f"High ignore ratio: {ignore_ratio:.0%} "
                        f"({len(ignored_rules)}/{self.total_rules} rules)"
                    ),
                    suggestion="Consider using quickfixes to resolve issues instead",
                    details={"ratio": ignore_ratio, "count": len(ignored_rules)},
                    doc_url="https://manifestguard.dev/docs/config-safety#ignore-ratio",
                )
            )

        # 2. New ignores spike (if previous state available)
        if previous_state:
            new_ignores = set(ignored_rules) - set(previous_state.ignored_rules)
            if len(new_ignores) > ABNORMAL_CONFIG_THRESHOLDS["new_ignores"]:
                warnings.append(
                    AbnormalConfigWarning(
                        code="MG-CONFIG-001",
                        severity="warning",
                        message=f"{len(new_ignores)} new ignores added in recent config change",
                        suggestion=(
                            "Run `manifestguard fix --interactive` to review auto-fixes first"
                        ),
                        details={"new_ignores": sorted(new_ignores)},
                        doc_url="https://manifestguard.dev/docs/config-safety#new-ignores",
                    )
                )

        # 3. Wildcard patterns
        wildcards = [r for r in ignored_rules if "*" in r]
        if len(wildcards) >= ABNORMAL_CONFIG_THRESHOLDS["wildcard_ignores"]:
            warnings.append(
                AbnormalConfigWarning(
                    code="MG-CONFIG-002",
                    severity="error",
                    message=f"Wildcard ignores detected: {', '.join(wildcards)}",
                    suggestion="Avoid category-wide ignores (e.g., 'MG-*'). Be explicit.",
                    details={"wildcards": wildcards},
                    doc_url="https://manifestguard.dev/docs/config-safety#wildcards",
                )
            )

        return warnings

    def calculate_config_hash(self, ignored_rules: list[str]) -> str:
        """Calculate hash of configuration for change detection.

        Args:
            ignored_rules: List of ignored rule IDs

        Returns:
            SHA-256 hash of normalized configuration
        """
        # Normalize: sort rules and serialize
        normalized = json.dumps({"ignores": sorted(ignored_rules)}, sort_keys=True)
        return hashlib.sha256(normalized.encode()).hexdigest()


class WarningStateManager:
    """Manager for persistent warning state to avoid spam."""

    STATE_FILE = ".manifestguard/config-warnings.json"
    STATE_VERSION = "1.0"

    def __init__(self, workspace_root: Path):
        """Initialize state manager.

        Args:
            workspace_root: Root directory of workspace
        """
        self.workspace_root = workspace_root
        self.state_file = workspace_root / self.STATE_FILE

    def is_acknowledged(self, config_hash: str) -> bool:
        """Check if current config has been acknowledged.

        Args:
            config_hash: Hash of current configuration

        Returns:
            True if this exact config was already acknowledged
        """
        state = self.load_state()
        if not state or not state.acknowledged:
            return False
        return state.config_hash == config_hash

    def acknowledge(
        self,
        ignored_rules: list[str],
        warnings: list[AbnormalConfigWarning],
        analyzer: ConfigAnalyzer,
    ) -> None:
        """Acknowledge current configuration.

        Args:
            ignored_rules: Current list of ignored rules
            warnings: Warnings that were shown
            analyzer: ConfigAnalyzer instance for hash calculation
        """
        state = ConfigState(
            version=self.STATE_VERSION,
            timestamp=datetime.now().isoformat(),
            config_hash=analyzer.calculate_config_hash(ignored_rules),
            ignored_rules=ignored_rules,
            ignore_ratio=len(ignored_rules) / analyzer.total_rules,
            acknowledged=True,
            acknowledged_at=datetime.now().isoformat(),
        )
        self.save_state(state)
        logger.info("Configuration warning acknowledged by user")

    def load_state(self) -> ConfigState | None:
        """Load last saved warning state.

        Returns:
            Last saved state, or None if no state exists
        """
        if not self.state_file.exists():
            return None

        try:
            with self.state_file.open() as f:
                data = json.load(f)

            return ConfigState(
                version=data["version"],
                timestamp=data["timestamp"],
                config_hash=data["config_hash"],
                ignored_rules=data["ignored_rules"],
                ignore_ratio=data["ignore_ratio"],
                acknowledged=data.get("acknowledged", False),
                acknowledged_at=data.get("acknowledged_at"),
            )
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"Failed to load config warning state: {e}")
            return None

    def save_state(self, state: ConfigState) -> None:
        """Save warning state to disk.

        Args:
            state: State to save
        """
        self.state_file.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "version": state.version,
            "timestamp": state.timestamp,
            "config_hash": state.config_hash,
            "ignored_rules": state.ignored_rules,
            "ignore_ratio": state.ignore_ratio,
            "acknowledged": state.acknowledged,
            "acknowledged_at": state.acknowledged_at,
        }

        with self.state_file.open("w") as f:
            json.dump(data, f, indent=2)

    def clear(self) -> None:
        """Clear warning state (for testing or reset)."""
        if self.state_file.exists():
            self.state_file.unlink()


def format_warning_output(warnings: list[AbnormalConfigWarning]) -> str:
    """Format warnings for CLI output.

    Args:
        warnings: List of warnings to format

    Returns:
        Formatted warning message
    """
    if not warnings:
        return ""

    lines = [
        "",
        "⚠️  CONFIGURATION WARNING",
        "━" * 70,
        "",
        "Detected abnormal ignore configuration:",
    ]

    for warning in warnings:
        lines.append(f"  • {warning.message}")

    lines.extend(
        [
            "",
            '⚠️  RISK: "Ignore instead of repair" anti-pattern',
            "    Adding many ignores may hide real bugs instead of fixing them.",
            "",
            "🔧 ALTERNATIVES:",
            "    1. Run quickfixes first:",
            "       $ manifestguard fix --interactive",
            "",
            "    2. Use targeted exceptions:",
            "       # Good: Document reason",
            "       x = get_config()  # noqa: PLC0415 - Circular import avoidance",
            "",
            "       # Bad: Hide problem",
            "       [tool.ruff.lint]",
            '       ignore = ["PLC0415"]  # Global ignore',
            "",
            "    3. Fix issues properly (example from 2025-01-02 incident):",
            "       - PLC0415: Move 28 imports to top, mark 33 intentional",
            "       - S603: Document controlled subprocess calls",
            "       - SIM102: Combine nested conditions",
            "",
            "📚 DOCUMENTATION:",
            "    Why this matters: https://manifestguard.dev/docs/config-safety",
            "    Best practices: https://manifestguard.dev/docs/fixing-vs-ignoring",
            "",
            "To acknowledge this warning and proceed:",
            "    $ manifestguard check --acknowledge-config-warning",
            "",
            "━" * 70,
            "",
        ]
    )

    return "\n".join(lines)
