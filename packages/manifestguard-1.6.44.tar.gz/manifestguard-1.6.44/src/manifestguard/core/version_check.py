"""Python Version Detection and Compatibility Checks
Ported from VS Code version check patterns

Provides:
- Python version detection
- Semver comparison
- Feature flag detection based on version
- Compatibility layer for version-specific imports
"""

import sys
from typing import Any

from packaging import version as pkg_version


class PythonVersionInfo:
    """Python version information and compatibility"""

    def __init__(self) -> None:
        self.major = sys.version_info.major
        self.minor = sys.version_info.minor
        self.micro = sys.version_info.micro
        self.releaselevel = sys.version_info.releaselevel
        self.serial = sys.version_info.serial

    @property
    def version_string(self) -> str:
        """Get version as string (e.g., '3.12.10')"""
        return f"{self.major}.{self.minor}.{self.micro}"

    @property
    def short_version(self) -> str:
        """Get short version (e.g., '3.12')"""
        return f"{self.major}.{self.minor}"

    def is_at_least(self, major: int, minor: int = 0) -> bool:
        """Check if current version is at least major.minor"""
        return (self.major, self.minor) >= (major, minor)

    def is_exactly(self, major: int, minor: int, micro: int | None = None) -> bool:
        """Check if current version matches exactly"""
        if micro is not None:
            return (self.major, self.minor, self.micro) == (major, minor, micro)
        return (self.major, self.minor) == (major, minor)

    def is_deprecated(self) -> bool:
        """Check if current Python version is deprecated (< 3.8)"""
        return not self.is_at_least(3, 8)

    def is_supported(self) -> bool:
        """Check if current Python version is supported (>= 3.8)"""
        return self.is_at_least(3, 8)


def get_python_version() -> PythonVersionInfo:
    """Get current Python version info"""
    return PythonVersionInfo()


def compare_versions(v1: str, v2: str) -> int:
    """Compare two semver version strings.

    Args:
        v1: First version
        v2: Second version

    Returns:
        -1 if v1 < v2
        0 if v1 == v2
        1 if v1 > v2

    """
    try:
        ver1 = pkg_version.parse(v1)
        ver2 = pkg_version.parse(v2)

        if ver1 < ver2:
            return -1
        if ver1 > ver2:
            return 1
        return 0
    except Exception:
        # Fallback to simple string comparison
        if v1 < v2:
            return -1
        if v1 > v2:
            return 1
        return 0


def check_version_range(
    current: str,
    min_version: str | None = None,
    max_version: str | None = None,
) -> bool:
    """Check if current version is within min/max range.

    Args:
        current: Current version string
        min_version: Minimum required version (inclusive)
        max_version: Maximum allowed version (inclusive)

    Returns:
        True if within range, False otherwise

    """
    if min_version and compare_versions(current, min_version) < 0:
        return False

    return not (max_version and compare_versions(current, max_version) > 0)


class FeatureFlags:
    """Feature flags based on Python version.

    Provides conditional feature availability based on Python version.
    """

    def __init__(self, version_info: PythonVersionInfo | None = None):
        self.version = version_info or get_python_version()

    @property
    def has_match_case(self) -> bool:
        """Match-case statements (Python 3.10+)"""
        return self.version.is_at_least(3, 10)

    @property
    def has_union_types(self) -> bool:
        """Union types with | operator (Python 3.10+)"""
        return self.version.is_at_least(3, 10)

    @property
    def has_exception_groups(self) -> bool:
        """Exception groups (Python 3.11+)"""
        return self.version.is_at_least(3, 11)

    @property
    def has_tomllib(self) -> bool:
        """Built-in tomllib (Python 3.11+)"""
        return self.version.is_at_least(3, 11)

    @property
    def has_type_alias_syntax(self) -> bool:
        """Type alias syntax with 'type' keyword (Python 3.12+)"""
        return self.version.is_at_least(3, 12)

    @property
    def has_dataclass_slots(self) -> bool:
        """Dataclass __slots__ support (Python 3.10+)"""
        return self.version.is_at_least(3, 10)

    @property
    def has_asyncio_timeout(self) -> bool:
        """asyncio.timeout context manager (Python 3.11+)"""
        return self.version.is_at_least(3, 11)


def get_feature_flags() -> FeatureFlags:
    """Get feature flags for current Python version"""
    return FeatureFlags()


def require_python_version(
    min_version: tuple[int, int],
    feature_name: str | None = None,
) -> None:
    """Require minimum Python version, raise if not met.

    Args:
        min_version: Minimum (major, minor) version
        feature_name: Optional feature name for error message

    Raises:
        RuntimeError: If Python version requirement not met

    """
    current = get_python_version()
    if not current.is_at_least(*min_version):
        feature_msg = f" for {feature_name}" if feature_name else ""
        raise RuntimeError(
            f"Python {min_version[0]}.{min_version[1]}+ required{feature_msg}. "
            f"Current version: {current.version_string}",
        )


def get_compatibility_layer() -> dict[str, Any]:
    """Get compatibility layer for version-specific imports.

    Returns:
        Dictionary of module/function replacements

    """
    version = get_python_version()
    compat = {}

    # TOML library
    if version.is_at_least(3, 11):
        import tomllib  # noqa: PLC0415 - version-specific import (3.11+)

        compat["tomllib"] = tomllib
    else:
        try:
            import tomli as tomllib  # noqa: PLC0415 - backport for <3.11

            compat["tomllib"] = tomllib
        except ImportError:
            compat["tomllib"] = None

    # asyncio.timeout (Python 3.11+)
    if version.is_at_least(3, 11):
        try:
            import asyncio  # noqa: PLC0415 - version-specific feature check

            if hasattr(asyncio, "timeout"):
                compat["asyncio_timeout"] = asyncio.timeout
            else:
                compat["asyncio_timeout"] = None
        except (ImportError, AttributeError):
            compat["asyncio_timeout"] = None
    else:
        try:
            from async_timeout import timeout  # noqa: PLC0415 - backport for <3.11

            compat["asyncio_timeout"] = timeout
        except ImportError:
            compat["asyncio_timeout"] = None

    return compat
