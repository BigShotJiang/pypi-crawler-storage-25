"""Workflow Service
Ported from VS Code WorkflowService.ts and WorkflowDispatcher.ts

Provides consent-based workflow execution with security levels.
"""

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Literal

from .config import AccessLevel, ConfigurationService

WorkflowTrigger = Literal["manual", "agent", "ci", "scheduled"]


@dataclass
class WorkflowDescriptor:
    """Workflow metadata"""

    id: str
    title: str
    description: str
    required_consent: bool = False
    category: str = "general"
    min_access_level: AccessLevel = "permissive"


class WorkflowService:
    """Workflow execution service with consent and access level gating.

    Security model:
    - strict: Blocks all agent/automated execution
    - balanced: Requires explicit consent for agent execution
    - permissive: Allows all execution with consent for sensitive workflows

    Features:
    - Consent-based execution
    - Access level enforcement
    - Trigger-based gating
    - Workflow registry
    """

    def __init__(self, config: ConfigurationService):
        self.config = config
        self._workflows: dict[str, WorkflowDescriptor] = {}

    def register_workflow(self, workflow: WorkflowDescriptor) -> None:
        """Register a workflow"""
        self._workflows[workflow.id] = workflow

    def get_workflow(self, workflow_id: str) -> WorkflowDescriptor | None:
        """Get workflow by ID"""
        return self._workflows.get(workflow_id)

    def get_all_workflows(self) -> list[WorkflowDescriptor]:
        """Get all registered workflows"""
        return list(self._workflows.values())

    def _check_access_level(
        self, access_level: str, trigger: str, show_warning: Callable | None
    ) -> bool:
        """Check if access level allows execution."""
        if access_level == "strict" and trigger == "agent":
            if show_warning:
                show_warning(
                    "Agent execution blocked in 'strict' mode. "
                    "Change access level to 'balanced' or 'permissive'.",
                )
            return False

        if access_level == "balanced" and trigger == "agent":
            if show_warning:
                show_warning(
                    "Agent execution blocked in 'balanced' mode. " "Manual confirmation required.",
                )
            return False

        return True

    def _check_minimum_access_level(
        self,
        workflow: WorkflowDescriptor,
        access_level: str,
        show_warning: Callable[[str], None] | None,
    ) -> bool:
        """Check if current access level meets workflow requirements."""
        access_level_order = {"strict": 0, "balanced": 1, "permissive": 2}
        current_level_value = access_level_order[access_level]
        required_level_value = access_level_order[workflow.min_access_level]

        if current_level_value < required_level_value:
            if show_warning:
                show_warning(
                    f"Workflow requires '{workflow.min_access_level}' access level, current is '{access_level}'.",
                )
            return False
        return True

    def _check_consent(
        self,
        workflow: WorkflowDescriptor,
        workflow_id: str,
        show_warning: Callable[[str], None] | None,
    ) -> bool:
        """Check if workflow consent is granted."""
        if workflow.required_consent and not self.config.has_consent(workflow_id):
            if show_warning:
                show_warning(
                    f"Consent required for workflow '{workflow.title}'. "
                    f"Run 'manifestguard.workflow.grantConsent {workflow_id}' first.",
                )
            return False
        return True

    async def try_execute_workflow(
        self,
        workflow_id: str,
        trigger: WorkflowTrigger,
        execute_callback: Callable[[], Awaitable[None]],
        show_warning_callback: Callable[[str], None] | None = None,
    ) -> bool:
        """Try to execute workflow with security gating.

        Args:
            workflow_id: Workflow identifier
            trigger: How workflow was triggered
            execute_callback: Async function to execute
            show_warning_callback: Optional callback for warnings

        Returns:
            True if execution was allowed, False otherwise

        """
        workflow = self.get_workflow(workflow_id)
        if not workflow:
            if show_warning_callback:
                show_warning_callback(f"Workflow '{workflow_id}' not declared.")
            return False

        access_level = self.config.get_access_level()

        # Run all checks
        if not self._check_access_level(access_level, trigger, show_warning_callback):
            return False

        if not self._check_minimum_access_level(workflow, access_level, show_warning_callback):
            return False

        if not self._check_consent(workflow, workflow_id, show_warning_callback):
            return False

        # All checks passed, execute workflow
        try:
            await execute_callback()
            return True
        except Exception as e:
            if show_warning_callback:
                show_warning_callback(f"Workflow execution failed: {e!s}")
            raise


class WorkflowDispatcher:
    """Workflow dispatcher with context management.

    Provides:
    - Workflow discovery
    - Context exposure
    - Execution coordination
    """

    def __init__(self, workflow_service: WorkflowService):
        self.workflow_service = workflow_service
        self._context: dict[str, Any] = {}

    def set_context(self, key: str, value: Any) -> None:
        """Set workflow context variable"""
        self._context[key] = value

    def get_context(self, key: str) -> Any:
        """Get workflow context variable"""
        return self._context.get(key)

    def expose_context(self) -> dict[str, Any]:
        """Expose all workflow context (for debugging/inspection)"""
        return self._context.copy()

    async def dispatch(
        self,
        workflow_id: str,
        trigger: WorkflowTrigger,
        callback: Callable[[], Awaitable[None]],
        warning_handler: Callable[[str], None] | None = None,
    ) -> bool:
        """Dispatch workflow execution through workflow service.

        Args:
            workflow_id: Workflow to execute
            trigger: Execution trigger
            callback: Async execution function
            warning_handler: Optional warning callback

        Returns:
            True if executed, False if blocked

        """
        return await self.workflow_service.try_execute_workflow(
            workflow_id=workflow_id,
            trigger=trigger,
            execute_callback=callback,
            show_warning_callback=warning_handler,
        )
