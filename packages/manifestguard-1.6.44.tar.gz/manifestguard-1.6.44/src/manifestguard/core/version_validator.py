"""Version Schema Validator
Validates that Python packages follow semantic versioning (x.y.z)
"""

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VersionInfo:
    """Version information with semantic components"""

    raw: str
    major: int
    minor: int
    patch: int
    prerelease: str | None = None
    build: str | None = None

    @property
    def is_stable(self) -> bool:
        """Check if version is stable (no prerelease/build suffix)"""
        return self.prerelease is None and self.build is None

    @property
    def semantic_version(self) -> str:
        """Get semantic version string (major.minor.patch)"""
        return f"{self.major}.{self.minor}.{self.patch}"


class VersionValidator:
    """Validates Python package versions against x.y.z schema

    Supports semantic versioning (SemVer 2.0.0):
    - MAJOR.MINOR.PATCH (e.g., 1.0.0)
    - Pre-release: 1.0.0-alpha, 1.0.0-beta.1
    - Build metadata: 1.0.0+20130313144700
    - Combined: 1.0.0-beta+exp.sha.5114f85

    Example:
        >>> validator = VersionValidator()
        >>> success, info = validator.validate_package('manifestguard')
        >>> if success:
        ...     print(f"Version: {info.semantic_version}")

    """

    # Semantic versioning pattern (SemVer 2.0.0)
    SEMVER_PATTERN = re.compile(
        r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)"
        r"(?:-(?P<prerelease>[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?"
        r"(?:\+(?P<build>[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$",
    )

    def __init__(self, strict: bool = False):
        """Initialize validator

        Args:
            strict: If True, only accept stable versions (no prerelease/build)

        """
        self.strict = strict

    def parse_version(self, version_string: str) -> VersionInfo | None:
        """Parse version string into components

        Args:
            version_string: Version string to parse (e.g., "1.2.3")

        Returns:
            VersionInfo if valid, None otherwise

        Example:
            >>> validator = VersionValidator()
            >>> info = validator.parse_version("1.2.3-alpha")
            >>> print(f"{info.major}.{info.minor}.{info.patch}")
            1.2.3

        """
        match = self.SEMVER_PATTERN.match(version_string)
        if not match:
            return None

        groups = match.groupdict()

        return VersionInfo(
            raw=version_string,
            major=int(groups["major"]),
            minor=int(groups["minor"]),
            patch=int(groups["patch"]),
            prerelease=groups.get("prerelease"),
            build=groups.get("build"),
        )

    def validate_version(self, version_string: str) -> tuple[bool, VersionInfo | None, str]:
        """Validate version string format

        Args:
            version_string: Version string to validate

        Returns:
            Tuple of (success, version_info, message)

        Example:
            >>> validator = VersionValidator()
            >>> success, info, msg = validator.validate_version("1.2.3")
            >>> print(msg)
            Valid semantic version: 1.2.3

        """
        if not version_string:
            return False, None, "Version string is empty"

        # Parse version
        info = self.parse_version(version_string)
        if info is None:
            return (
                False,
                None,
                (
                    f"Version '{version_string}' does not match x.y.z schema. "
                    "Expected format: MAJOR.MINOR.PATCH (e.g., '0.3.0')"
                ),
            )

        # Check strict mode
        if self.strict and not info.is_stable:
            return (
                False,
                info,
                (
                    f"Version '{version_string}' is not stable. "
                    "Strict mode requires stable versions (no prerelease/build)"
                ),
            )

        return True, info, f"Valid semantic version: {info.semantic_version}"

    def validate_package(self, package_name: str) -> tuple[bool, VersionInfo | None, str]:
        """Validate package's __version__ attribute

        Args:
            package_name: Name of installed Python package

        Returns:
            Tuple of (success, version_info, message)

        Example:
            >>> validator = VersionValidator()
            >>> success, info, msg = validator.validate_package('manifestguard')
            >>> if success:
            ...     print(f"Version: {info.semantic_version}")

        """
        try:
            # Import package
            package = __import__(package_name)

            # Check __version__ attribute
            if not hasattr(package, "__version__"):
                return (
                    False,
                    None,
                    (
                        f"Package '{package_name}' has no __version__ attribute. "
                        "Add __version__ = '0.1.0' to package __init__.py"
                    ),
                )

            version_string = package.__version__

            # Validate version format
            return self.validate_version(version_string)

        except ImportError as e:
            return False, None, f"Cannot import package '{package_name}': {e}"
        except Exception as e:
            return False, None, f"Unexpected error validating package '{package_name}': {e}"

    def validate_project(  # noqa: PLR0911
        self, project_path: Path | str
    ) -> tuple[bool, VersionInfo | None, str]:
        """Validate version in project's pyproject.toml or setup.py

        Args:
            project_path: Path to project root

        Returns:
            Tuple of (success, version_info, message)

        Example:
            >>> validator = VersionValidator()
            >>> success, info, msg = validator.validate_project('.')
            >>> print(msg)

        """
        if isinstance(project_path, str):
            project_path = Path(project_path)

        # Try pyproject.toml first
        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            try:
                import tomllib  # noqa: PLC0415 - version-specific import (3.11+)

                with pyproject.open("rb") as f:
                    data = tomllib.load(f)

                # Check project.version
                version = data.get("project", {}).get("version")
                if version:
                    return self.validate_version(version)

                # Check tool.poetry.version
                version = data.get("tool", {}).get("poetry", {}).get("version")
                if version:
                    return self.validate_version(version)

                return (
                    False,
                    None,
                    (
                        f"No version found in {pyproject}. "
                        "Add version to [project] or [tool.poetry] section"
                    ),
                )

            except Exception as e:
                return False, None, f"Error reading {pyproject}: {e}"

        # Try setup.py
        setup_py = project_path / "setup.py"
        if setup_py.exists():
            try:
                content = setup_py.read_text(encoding="utf-8")

                # Look for version= in setup() call
                version_match = re.search(r"version\s*=\s*['\"]([^'\"]+)['\"]", content)
                if version_match:
                    version = version_match.group(1)
                    return self.validate_version(version)

                return (
                    False,
                    None,
                    (f"No version found in {setup_py}. " "Add version='0.1.0' to setup() call"),
                )

            except Exception as e:
                return False, None, f"Error reading {setup_py}: {e}"

        return (
            False,
            None,
            (
                f"No pyproject.toml or setup.py found in {project_path}. "
                "Cannot validate project version"
            ),
        )

    def compare_versions(self, version_a: str, version_b: str) -> int | None:
        """Compare two version strings

        Args:
            version_a: First version
            version_b: Second version

        Returns:
            -1 if a < b, 0 if a == b, 1 if a > b, None if invalid

        Example:
            >>> validator = VersionValidator()
            >>> result = validator.compare_versions("1.0.0", "1.0.1")
            >>> print(result)
            -1

        """
        info_a = self.parse_version(version_a)
        info_b = self.parse_version(version_b)

        if info_a is None or info_b is None:
            return None

        # Compare major.minor.patch
        base_cmp = self._compare_base(info_a, info_b)
        if base_cmp != 0:
            return base_cmp

        # Same base version, check prerelease
        return self._compare_prerelease(info_a, info_b)

    def _compare_base(self, info_a: "VersionInfo", info_b: "VersionInfo") -> int:
        """Compare major.minor.patch"""
        tuple_a = (info_a.major, info_a.minor, info_a.patch)
        tuple_b = (info_b.major, info_b.minor, info_b.patch)

        if tuple_a < tuple_b:
            return -1
        if tuple_a > tuple_b:
            return 1
        return 0

    def _compare_prerelease(self, info_a: "VersionInfo", info_b: "VersionInfo") -> int:
        """Compare prerelease versions"""
        # Both stable or both prerelease
        if info_a.prerelease == info_b.prerelease:
            return 0

        # Prerelease < stable
        if info_a.prerelease and not info_b.prerelease:
            return -1
        if not info_a.prerelease and info_b.prerelease:
            return 1

        # Both are prerelease, compare strings
        # mypy needs help here - we know both are strings at this point
        assert info_a.prerelease is not None and info_b.prerelease is not None
        if info_a.prerelease < info_b.prerelease:
            return -1
        if info_a.prerelease > info_b.prerelease:
            return 1
        return 0


# Convenience function for quick validation
def validate_package_version(package_name: str, strict: bool = False) -> tuple[bool, str]:
    """Quick validation of package version

    Args:
        package_name: Package to validate
        strict: Require stable version

    Returns:
        Tuple of (success, message)

    Example:
        >>> success, msg = validate_package_version('manifestguard')
        >>> print(msg)
        Valid semantic version: 0.3.0

    """
    validator = VersionValidator(strict=strict)
    success, _info, message = validator.validate_package(package_name)
    return success, message
