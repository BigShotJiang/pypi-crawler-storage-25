"""Shared AI Preferences module for ManifestGuard.

Provides centralized AI configuration with:
- Product-local settings namespace (manifestguard.ai.*)
- Provider abstraction (ollama, openai-compatible)
- Secret storage integration for API keys
- Model/endpoint configuration
"""

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from manifestguard.core.logging import get_logger

logger = get_logger()

# Type aliases
AIProvider = Literal["ollama", "openai-compatible"]


@dataclass
class AIProviderConfig:
    """AI provider configuration with endpoints and models."""

    provider: AIProvider
    model: str | None = None
    base_url: str | None = None
    api_key: str | None = None
    timeout: int = 30
    max_retries: int = 3

    def __post_init__(self):
        """Apply provider-specific defaults."""
        if self.provider == "ollama" and not self.base_url:
            self.base_url = "http://localhost:11434"
        elif self.provider == "openai-compatible" and not self.base_url:
            self.base_url = "https://api.openai.com/v1"

        # Apply default model if not specified
        if not self.model:
            if self.provider == "ollama":
                self.model = "qwen2.5:7b"
            elif self.provider == "openai-compatible":
                self.model = "gpt-4"


class SharedAIPreferences:
    """Manages product-local AI preferences for ManifestGuard.

    Uses the manifestguard.ai.* namespace in manifestguard.json:
    - manifestguard.ai.provider → Provider selection
    - manifestguard.ai.model → Model name
    - manifestguard.ai.ollama.baseUrl → Ollama endpoint
    - manifestguard.ai.openai.baseUrl → OpenAI endpoint
    - manifestguard.ai.secret.apiKey.openai → API key (keyring storage)

    """

    def __init__(self, config_file: Path | None = None):
        """Initialize shared AI preferences.

        Args:
            config_file: Optional path to manifestguard.json

        """
        self.config_file = config_file
        self._config_cache: dict[str, Any] | None = None
        self._has_keyring = False

        # Check for keyring availability
        try:
            import keyring  # noqa: F401, PLC0415 - optional dependency for secure storage

            self._has_keyring = True
        except ImportError:
            logger.warn("keyring not available - API keys will use environment variables")

    def get_provider_config(self) -> AIProviderConfig:
        """Get effective AI provider configuration.

        Resolves configuration from multiple sources (priority order):
        1. Environment variables (R4IT_AI_PROVIDER, R4IT_AI_MODEL, etc.)
        2. manifestguard.json (manifestguard.ai.*)
        3. Defaults (ollama + qwen2.5:7b)

        Returns:
            AIProviderConfig with resolved settings

        """
        # 1. Environment variables (highest priority)
        provider = self._get_from_env("R4IT_AI_PROVIDER")
        model = self._get_from_env("R4IT_AI_MODEL")

        # 2. manifestguard.json product-local namespace
        if not provider:
            provider = self._get_setting("provider", "ai")
        if not model:
            model = self._get_setting("model", "ai")

        # 3. Default fallback
        if not provider:
            provider = "ollama"
            logger.debug("No AI provider configured, using default: ollama")

        # Get provider-specific settings
        if provider == "ollama":
            base_url = (
                self._get_from_env("R4IT_AI_OLLAMA_BASE_URL")
                or self._get_setting("baseUrl", "ollama")
                or "http://localhost:11434"
            )
            api_key = None
        elif provider == "openai-compatible":
            base_url = (
                self._get_from_env("R4IT_AI_OPENAI_BASE_URL")
                or self._get_setting("baseUrl", "openai")
                or "https://api.openai.com/v1"
            )
            api_key = self._get_api_key("openai")
        else:
            raise ValueError(f"Unknown AI provider: {provider}")

        # Type assertion after validation
        provider_typed: AIProvider = provider  # type: ignore[assignment]
        return AIProviderConfig(
            provider=provider_typed, model=model, base_url=base_url, api_key=api_key
        )

    def _get_from_env(self, key: str) -> str | None:
        """Get value from environment variable."""
        return os.environ.get(key)

    def _get_setting(self, key: str, namespace: str) -> str | None:
        """Get setting from the product-local namespace.

        Args:
            key: Setting key (e.g., "provider", "baseUrl")
            namespace: Namespace (e.g., "ai", "ollama", "openai")

        Returns:
            Setting value or None

        """
        config = self._load_config()
        if not config:
            return None

        full_key = f"manifestguard.ai.{key}" if namespace == "ai" else f"manifestguard.ai.{namespace}.{key}"
        value = self._get_nested(config, full_key)
        if value is None:
            return None
        return value

    def _get_nested(self, obj: dict[str, Any], key: str) -> Any | None:
        """Get nested dictionary value by dot-separated key.

        Supports both flattened keys (e.g., {"manifestguard.ai.provider": "ollama"})
        and nested keys (e.g., {"manifestguard": {"ai": {"provider": "ollama"}}}).
        """
        # First try flattened key (direct match)
        if key in obj:
            return obj[key]

        # Then try nested navigation
        keys = key.split(".")
        current = obj

        for k in keys:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return None

        return current

    def _load_config(self) -> dict[str, Any] | None:
        """Load configuration from manifestguard.json."""
        if self._config_cache is not None:
            return self._config_cache

        if not self.config_file or not self.config_file.exists():
            return None

        try:
            with Path(self.config_file).open(encoding="utf-8") as f:
                self._config_cache = json.load(f)
                return self._config_cache
        except Exception as e:
            logger.error(f"Failed to load {self.config_file}", e)
            return None

    def _get_api_key(self, provider: str) -> str | None:
        """Get API key from secure storage.

        Priority:
        1. Environment variable (R4IT_AI_API_KEY_<PROVIDER>)
        2. Keyring (manifestguard.ai.secret.apiKey.<provider>)

        Args:
            provider: Provider name (e.g., "openai")

        Returns:
            API key or None

        """
        # 1. Environment variable
        env_key = f"R4IT_AI_API_KEY_{provider.upper()}"
        api_key = os.environ.get(env_key)
        if api_key:
            return api_key

        # 2. Keyring
        if self._has_keyring:
            try:
                import keyring  # noqa: PLC0415 - optional dependency for secure storage

                keyring_key = f"manifestguard.ai.secret.apiKey.{provider}"
                api_key = keyring.get_password("manifestguard", keyring_key)
                if api_key:
                    return api_key
            except Exception as e:
                logger.warn(f"Failed to retrieve API key from keyring: {e}")

        return None

    def set_api_key(self, provider: str, api_key: str) -> bool:
        """Store API key in secure keyring storage.

        Args:
            provider: Provider name (e.g., "openai")
            api_key: API key to store

        Returns:
            True if stored successfully, False otherwise

        """
        if not self._has_keyring:
            logger.error("keyring not available - cannot store API key securely")
            return False

        try:
            import keyring  # noqa: PLC0415 - optional dependency for secure storage

            keyring_key = f"manifestguard.ai.secret.apiKey.{provider}"
            keyring.set_password("manifestguard", keyring_key, api_key)
            logger.info(f"Stored API key for {provider} in keyring")
            return True
        except Exception as e:
            logger.error(f"Failed to store API key in keyring: {e}")
            return False

    def remove_api_key(self, provider: str) -> bool:
        """Remove API key from keyring storage.

        Args:
            provider: Provider name (e.g., "openai")

        Returns:
            True if removed successfully, False otherwise

        """
        if not self._has_keyring:
            logger.warn("keyring not available")
            return False

        try:
            import keyring  # noqa: PLC0415 - optional dependency for secure storage

            keyring_key = f"manifestguard.ai.secret.apiKey.{provider}"
            keyring.delete_password("manifestguard", keyring_key)
            logger.info(f"Removed API key for {provider} from keyring")
            return True
        except Exception as e:
            logger.warn(f"Failed to remove API key from keyring: {e}")
            return False

    def reset_to_defaults(self):
        """Reset AI settings to defaults (clears cache, does not modify files)."""
        self._config_cache = None
        logger.info("Reset AI preferences cache to defaults")


# Global singleton
_preferences: SharedAIPreferences | None = None


def get_shared_preferences(config_file: Path | None = None) -> SharedAIPreferences:
    """Get global shared AI preferences instance.

    Args:
        config_file: Optional path to manifestguard.json (used on first call)

    Returns:
        Shared preferences singleton

    """
    global _preferences  # noqa: PLW0603  # Singleton pattern
    if _preferences is None:
        _preferences = SharedAIPreferences(config_file)
    elif config_file is not None:
        # Allow late-binding of config_file (GUI may discover active project later).
        try:
            if _preferences.config_file != config_file:
                _preferences.config_file = config_file
                _preferences.reset_to_defaults()
        except Exception:
            pass
    return _preferences
