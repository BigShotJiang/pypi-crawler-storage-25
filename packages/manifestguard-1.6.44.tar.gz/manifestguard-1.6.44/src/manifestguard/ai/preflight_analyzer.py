"""AI-powered analysis of venv health-check results.

This module analyzes HealthReport JSON from venv_wizard preflight
and generates actionable recommendations using configured AI providers
(Ollama, OpenAI, etc.) via SharedAIPreferences.
"""

from __future__ import annotations

import json
from typing import Any

from manifestguard.ai import SharedAIPreferences, get_shared_preferences
from manifestguard.core.logging import get_logger

logger = get_logger()


SYSTEM_PROMPT = """You are a Python virtual environment health advisor. Analyze venv health-check reports and provide concise, actionable recommendations.

Focus on:
- Zombie/dead process cleanup
- Registry hygiene
- Performance optimization
- Risk assessment

Output format:
- One recommendation per issue
- Include specific commands to run
- Prioritize by severity (critical → warning → info)
- Be concise (2-3 sentences per recommendation)"""


def _extract_health_metrics(health_report: dict[str, Any]) -> tuple[str, list, list, bool, bool, int, int, int, int]:
    """Extract and normalize key fields from a health report dict."""
    status = health_report.get("status", "unknown")
    managed_children = health_report.get("managedChildren", [])
    if not isinstance(managed_children, list):
        managed_children = []
    warnings = health_report.get("warnings", [])
    if not isinstance(warnings, list):
        warnings = []
    auto_fix_applied = bool(health_report.get("autoFixApplied", False))
    psutil_available = bool(health_report.get("psutilAvailable", False))
    zombie_count = sum(1 for c in managed_children if c.get("status") == "zombie")
    dead_count = sum(1 for c in managed_children if c.get("status") == "dead")
    running_count = sum(1 for c in managed_children if c.get("status") == "running")
    total_count = len(managed_children)
    return status, managed_children, warnings, auto_fix_applied, psutil_available, zombie_count, dead_count, running_count, total_count


def _build_health_user_prompt(
    venv_path: str | None,
    status: str,
    total_count: int,
    running_count: int,
    zombie_count: int,
    dead_count: int,
    warnings: list,
    auto_fix_applied: bool,
    psutil_available: bool,
) -> str:
    """Build the user prompt for health report AI analysis."""
    venv_display = venv_path or "unknown venv"
    warnings_text = chr(10).join(f'  - {w}' for w in warnings) if warnings else '  (none)'
    auto_fix_text = 'Yes (already applied)' if auto_fix_applied else 'Yes'
    psutil_text = 'Yes' if psutil_available else 'No'
    return (
        f"Analyze this venv health report and provide recommendations:\n\n"
        f"Venv: {venv_display}\nStatus: {status}\nProcess Summary:\n"
        f"  - Total Managed: {total_count}\n  - Running: {running_count}\n"
        f"  - Zombies: {zombie_count}\n  - Dead PIDs: {dead_count}\n\n"
        f"Warnings:\n{warnings_text}\n\n"
        f"Auto-fix available: {auto_fix_text}\npsutil available: {psutil_text}\n\n"
        f"Provide 1-3 actionable recommendations. If status is 'ok', acknowledge that."
    )


def analyze_health_report(
    health_report: dict[str, Any],
    *,
    venv_path: str | None = None,
    preferences: SharedAIPreferences | None = None,
) -> dict[str, Any]:
    """Analyze venv health report and generate AI recommendations."""
    if preferences is None:
        preferences = get_shared_preferences()
    
    (status, _children, warnings, auto_fix_applied, psutil_available,
     zombie_count, dead_count, running_count, total_count) = _extract_health_metrics(health_report)
    
    user_prompt = _build_health_user_prompt(
        venv_path, status, total_count, running_count,
        zombie_count, dead_count, warnings, auto_fix_applied, psutil_available,
    )
    
    try:
        config = preferences.get_provider_config()
        response = _generate_completion_sync(
            system_prompt=SYSTEM_PROMPT,
            user_prompt=user_prompt,
            config=config,
        )
        recommendations = _parse_recommendations(response)
        summary = _generate_summary(status, zombie_count, dead_count, warnings)
        provider_display = f"{config.provider}:{config.model or 'default'}"
        return {
            "success": True,
            "recommendations": recommendations,
            "summary": summary,
            "error": None,
            "provider": provider_display,
        }
    except Exception as e:
        logger.error(f"Failed to analyze health report: {e}")
        return {
            "success": False,
            "recommendations": [],
            "summary": "AI analysis failed",
            "error": str(e),
            "provider": "unknown",
        }


def _generate_completion_sync(
    system_prompt: str,
    user_prompt: str,
    config: Any,
) -> str:
    """Generate AI completion synchronously.
    
    Args:
        system_prompt: System instructions
        user_prompt: User query
        managed_children = health_report.get("managedChildren")
        if not isinstance(managed_children, list):
            managed_children = health_report.get("managed_children", [])
        if not isinstance(managed_children, list):
            managed_children = []
        
        auto_fix_applied = health_report.get("autoFixApplied")
        if auto_fix_applied is None:
            auto_fix_applied = health_report.get("auto_fix_applied", False)
        auto_fix_applied = bool(auto_fix_applied)

        psutil_available = health_report.get("psutilAvailable")
        if psutil_available is None:
            psutil_available = health_report.get("psutil_available", False)
        psutil_available = bool(psutil_available)
    """
    import requests
    
    if config.provider == "ollama":
        # Ollama API call
        url = f"{config.base_url}/api/generate"
        payload = {
            "model": config.model or "qwen2.5:7b",
            "prompt": f"{system_prompt}\n\n{user_prompt}",
            "stream": False,
        }
        
        response = requests.post(url, json=payload, timeout=config.timeout)
        response.raise_for_status()
        
        result = response.json()
        return result.get("response", "")
    
    elif config.provider == "openai-compatible":
        # OpenAI-compatible API call
        url = f"{config.base_url}/chat/completions"
        headers = {}
        if config.api_key:
            headers["Authorization"] = f"Bearer {config.api_key}"
        
        payload = {
            "model": config.model or "gpt-3.5-turbo",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        
        response = requests.post(url, json=payload, headers=headers, timeout=config.timeout)
        response.raise_for_status()
        
        result = response.json()
        return result["choices"][0]["message"]["content"]
    
    else:
        raise ValueError(f"Unsupported AI provider: {config.provider}")


def _parse_recommendations(response: str) -> list[str]:
    """Parse AI response into list of recommendations.
    
    Args:
        response: Raw AI response text
        
    Returns:
        List of recommendation strings (one per line or bullet)
    """
    lines = response.strip().split("\n")
    recommendations = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Remove common bullet markers
        if line.startswith(("- ", "* ", "• ", "→ ")):
            line = line[2:].strip()
        elif line[0].isdigit() and line[1:3] in (". ", ") "):
            line = line[3:].strip()
        
        if line:
            recommendations.append(line)
    
    return recommendations


def _generate_summary(
    status: str,
    zombie_count: int,
    dead_count: int,
    warnings: list[str],
) -> str:
    """Generate brief summary of health status.
    
    Args:
        status: ok|warning|error
        zombie_count: Number of zombie processes
        dead_count: Number of dead PIDs
        warnings: List of warning messages
        
    Returns:
        Brief summary string
    """
    if status == "ok":
        return "✅ Venv healthy - no issues detected"
    
    issues = []
    if zombie_count > 0:
        issues.append(f"{zombie_count} zombie process(es)")
    if dead_count > 0:
        issues.append(f"{dead_count} dead PID(s)")
    if warnings:
        issues.append(f"{len(warnings)} warning(s)")
    
    severity = "⚠️" if status == "warning" else "❌"
    return f"{severity} Issues detected: {', '.join(issues)}"

def _compute_venv_risk_scores(health_reports: list[dict[str, Any]]) -> list[int]:
    """Compute a numeric risk score for each venv health report."""
    risk_scores = []
    for report in health_reports:
        children = report.get("managedChildren")
        if not isinstance(children, list):
            children = report.get("managed_children", [])
        if not isinstance(children, list):
            children = []
        zombies = sum(1 for c in children if c.get("status") == "zombie")
        dead = sum(1 for c in children if c.get("status") == "dead")
        status_weight = {"error": 10, "warning": 5, "ok": 0}.get(report.get("status", "unknown"), 0)
        risk_scores.append(zombies * 3 + dead * 2 + status_weight)
    return risk_scores


def analyze_cross_venv_health(
    health_reports: list[dict[str, Any]],
    venv_paths: list[str],
    *,
    preferences: SharedAIPreferences | None = None,
) -> dict[str, Any]:
    """Compare multiple venv health reports and identify riskiest.
    
    Args:
        health_reports: List of HealthReport dicts from preflight
        venv_paths: List of venv paths (parallel to health_reports)
        preferences: Optional SharedAIPreferences
        
    Returns:
        Dict with:
            - success: bool
            - comparison: str (cross-venv analysis)
            - riskiest_venv: str | None (most problematic venv)
            - recommendations: list[str]
            - error: str | None
            - provider: str
    """
    if preferences is None:
        preferences = get_shared_preferences()
    
    if len(health_reports) != len(venv_paths):
        return {
            "success": False,
            "comparison": "",
            "riskiest_venv": None,
            "recommendations": [],
            "error": "Mismatch between health_reports and venv_paths length",
            "provider": "unknown",
        }
    
    # Build summaries for each venv
    summaries = []
    for i, (report, venv) in enumerate(zip(health_reports, venv_paths), 1):
        status = report.get("status", "unknown")
        children = report.get("managedChildren", [])
        zombies = sum(1 for c in children if c.get("status") == "zombie")
        dead = sum(1 for c in children if c.get("status") == "dead")
        warnings = len(report.get("warnings", []))
        
        summaries.append(f"{i}. {venv}: status={status}, zombies={zombies}, dead={dead}, warnings={warnings}")
    
    # Build cross-venv prompt
    user_prompt = f"""Compare these {len(health_reports)} venv health reports and identify the riskiest one:

{chr(10).join(summaries)}

Which venv has the most critical issues? What should the developer address first?
Provide a prioritized action plan."""
    
    try:
        config = preferences.get_provider_config()
        response = _generate_completion_sync(
            system_prompt=SYSTEM_PROMPT,
            user_prompt=user_prompt,
            config=config,
        )
        
        recommendations = _parse_recommendations(response)
        provider_display = f"{config.provider}:{config.model or 'default'}"
        
        risk_scores = _compute_venv_risk_scores(health_reports)
        max_risk_idx = risk_scores.index(max(risk_scores)) if risk_scores else None
        riskiest_venv = venv_paths[max_risk_idx] if max_risk_idx is not None else None
        
        return {
            "success": True,
            "comparison": response,
            "riskiest_venv": riskiest_venv,
            "recommendations": recommendations,
            "error": None,
            "provider": provider_display,
        }
    
    except Exception as e:
        logger.error(f"Failed to analyze cross-venv health: {e}")
        return {
            "success": False,
            "comparison": "",
            "riskiest_venv": None,
            "recommendations": [],
            "error": str(e),
            "provider": "unknown",
        }
