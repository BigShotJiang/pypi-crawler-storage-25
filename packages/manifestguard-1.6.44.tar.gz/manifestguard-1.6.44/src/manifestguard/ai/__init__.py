"""AI module for ManifestGuard.

Provides AI integration with shared preferences, capabilities, and workflows.
"""

from manifestguard.ai.capabilities import (
    STANDARD_CAPABILITIES,
    STANDARD_WORKFLOWS,
    CapabilitiesManager,
    CapabilitiesRegistry,
    Capability,
    CapabilityScope,
    RateLimit,
    Workflow,
    WorkflowCategory,
    WorkflowTrigger,
)
from manifestguard.ai.shared_preferences import (
    AIProvider,
    AIProviderConfig,
    SharedAIPreferences,
    get_shared_preferences,
)
from manifestguard.ai.preflight_analyzer import (
    analyze_health_report,
    analyze_cross_venv_health,
)

__all__ = [
    "STANDARD_CAPABILITIES",
    "STANDARD_WORKFLOWS",
    "AIProvider",
    "AIProviderConfig",
    "CapabilitiesManager",
    "CapabilitiesRegistry",
    # Capabilities and workflows
    "Capability",
    "CapabilityScope",
    "RateLimit",
    # Shared preferences
    "SharedAIPreferences",
    "Workflow",
    "WorkflowCategory",
    "WorkflowTrigger",
    "get_shared_preferences",
    # Preflight analysis
    "analyze_health_report",
    "analyze_cross_venv_health",
]
