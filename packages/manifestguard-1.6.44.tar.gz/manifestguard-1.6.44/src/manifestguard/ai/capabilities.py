"""AI capabilities and workflows declaration for ManifestGuard.

Implements maschinenlesbare Deklaration von AI-relevanten Fähigkeiten:
- Capability declaration (network-access, fs.write, secrets, exec, etc.)
- Workflow orchestration for AI agents (Copilot, Gemini)
- Security boundaries and consent management
- Rate limiting and parameter validation

Port of VS Code extension's capabilities.json concept from concept.api.aivscode.md
"""

import json
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from manifestguard.core.logging import get_logger

logger = get_logger()

# Type aliases
CapabilityScope = Literal["runtime", "workspace", "remote"]
WorkflowCategory = Literal[
    "testing",
    "diagnostics",
    "audit",
    "localization",
    "securityScan",
    "performance",
]
WorkflowTrigger = Literal["manual", "agent", "ci", "scheduled"]


@dataclass
class Capability:
    """AI capability declaration.

    Describes a single capability the extension exposes or requires.
    """

    id: str  # namespaced identifier (e.g., com.example.cap.network)
    description: str
    scope: CapabilityScope
    title: str | None = None
    privileged: bool = False
    required_consent: bool = False
    allowed_hosts: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)
    version: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "id": self.id,
            "description": self.description,
            "scope": self.scope,
            "privileged": self.privileged,
            "requiredConsent": self.required_consent,
        }
        if self.title:
            result["title"] = self.title
        if self.allowed_hosts:
            result["allowedHosts"] = self.allowed_hosts
        if self.examples:
            result["examples"] = self.examples
        if self.version:
            result["version"] = self.version
        return result


@dataclass
class RateLimit:
    """Rate limit specification."""

    unit: Literal["second", "minute", "hour", "day"]
    max: int

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {"unit": self.unit, "max": self.max}


@dataclass
class Workflow:
    """AI workflow declaration.

    Describes a higher-level orchestration workflow that AI agents can trigger.
    """

    id: str  # namespaced identifier (e.g., com.manifestguard.workflow.test.runAll)
    title: str
    category: WorkflowCategory
    description: str
    triggers: list[WorkflowTrigger]
    required_consent: bool = False
    privileged: bool = False
    rate_limit: RateLimit | None = None
    parameters_schema: dict[str, Any] | None = None
    returns: list[str] = field(default_factory=list)
    safety_notes: str | None = None
    version: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "id": self.id,
            "title": self.title,
            "category": self.category,
            "description": self.description,
            "triggers": self.triggers,
            "requiredConsent": self.required_consent,
            "privileged": self.privileged,
        }
        if self.rate_limit:
            result["rateLimit"] = self.rate_limit.to_dict()
        if self.parameters_schema:
            result["parametersSchema"] = self.parameters_schema
        if self.returns:
            result["returns"] = self.returns
        if self.safety_notes:
            result["safetyNotes"] = self.safety_notes
        if self.version:
            result["version"] = self.version
        return result


class CapabilitiesRegistry:
    """Registry for AI capabilities and workflows.

    Validates capabilities.json and provides access to declared
    capabilities and workflows for AI agent orchestration.
    """

    def __init__(self, capabilities_file: Path | None = None):
        """Initialize capabilities registry.

        Args:
            capabilities_file: Path to capabilities.json

        """
        self.capabilities_file = capabilities_file
        self.capabilities: list[Capability] = []
        self.workflows: list[Workflow] = []

        if capabilities_file and capabilities_file.exists():
            self.load_from_file(capabilities_file)

    def load_from_file(self, file_path: Path) -> None:
        """Load capabilities and workflows from JSON file.

        Args:
            file_path: Path to capabilities.json

        Raises:
            ValueError: If file format is invalid

        """
        try:
            with Path(file_path).open(encoding="utf-8") as f:
                data = json.load(f)

            # Load capabilities
            if "capabilities" in data:
                for cap_data in data["capabilities"]:
                    cap = Capability(
                        id=cap_data["id"],
                        description=cap_data["description"],
                        scope=cap_data["scope"],
                        title=cap_data.get("title"),
                        privileged=cap_data.get("privileged", False),
                        required_consent=cap_data.get("requiredConsent", False),
                        allowed_hosts=cap_data.get("allowedHosts", []),
                        examples=cap_data.get("examples", []),
                        version=cap_data.get("version"),
                    )
                    self.capabilities.append(cap)

            # Load workflows
            if "workflows" in data:
                for wf_data in data["workflows"]:
                    rate_limit = None
                    if "rateLimit" in wf_data:
                        rate_limit = RateLimit(
                            unit=wf_data["rateLimit"]["unit"],
                            max=wf_data["rateLimit"]["max"],
                        )

                    wf = Workflow(
                        id=wf_data["id"],
                        title=wf_data["title"],
                        category=wf_data["category"],
                        description=wf_data["description"],
                        triggers=wf_data["triggers"],
                        required_consent=wf_data.get("requiredConsent", False),
                        privileged=wf_data.get("privileged", False),
                        rate_limit=rate_limit,
                        parameters_schema=wf_data.get("parametersSchema"),
                        returns=wf_data.get("returns", []),
                        safety_notes=wf_data.get("safetyNotes"),
                        version=wf_data.get("version"),
                    )
                    self.workflows.append(wf)

            logger.info(
                f"Loaded {len(self.capabilities)} capabilities and "
                f"{len(self.workflows)} workflows from {file_path}",
            )

        except Exception as e:
            logger.error(f"Failed to load capabilities from {file_path}", e)
            raise ValueError(f"Invalid capabilities file: {e}")

    def get_capability(self, capability_id: str) -> Capability | None:
        """Get capability by ID.

        Args:
            capability_id: Capability ID

        Returns:
            Capability or None

        """
        for cap in self.capabilities:
            if cap.id == capability_id:
                return cap
        return None

    def get_workflow(self, workflow_id: str) -> Workflow | None:
        """Get workflow by ID.

        Args:
            workflow_id: Workflow ID

        Returns:
            Workflow or None

        """
        for wf in self.workflows:
            if wf.id == workflow_id:
                return wf
        return None

    def get_workflows_by_category(self, category: WorkflowCategory) -> list[Workflow]:
        """Get all workflows in a category.

        Args:
            category: Workflow category

        Returns:
            List of workflows

        """
        return [wf for wf in self.workflows if wf.category == category]

    def get_workflows_by_trigger(self, trigger: WorkflowTrigger) -> list[Workflow]:
        """Get all workflows that support a trigger.

        Args:
            trigger: Trigger type

        Returns:
            List of workflows

        """
        return [wf for wf in self.workflows if trigger in wf.triggers]

    def get_privileged_capabilities(self) -> list[Capability]:
        """Get all privileged capabilities."""
        return [cap for cap in self.capabilities if cap.privileged]

    def get_privileged_workflows(self) -> list[Workflow]:
        """Get all privileged workflows."""
        return [wf for wf in self.workflows if wf.privileged]

    def _validate_capability_structure(self, cap: Capability) -> list[str]:
        """Validate the basic structure and required fields of a capability."""
        errors = []
        if not cap.id:
            errors.append("Capability missing 'id'")
        if not cap.description:
            errors.append(f"Capability '{cap.id or 'unknown'}' missing 'description'")
        if cap.scope not in ["runtime", "workspace", "remote"]:
            errors.append(f"Capability '{cap.id}' has invalid scope: {cap.scope}")
        return errors

    def _validate_capability_logic(self, cap: Capability) -> list[str]:
        """Validate the logical consistency of a capability."""
        errors = []
        if "network" in cap.id.lower() and not cap.allowed_hosts:
            errors.append(
                f"Capability '{cap.id}' declares network access but has no 'allowedHosts' whitelist"
            )
        if cap.privileged and not cap.required_consent:
            errors.append(f"Privileged capability '{cap.id}' should set 'requiredConsent: true'")
        return errors

    def _validate_capability(self, cap: Capability) -> list[str]:
        """Validate a single capability"""
        errors = []
        errors.extend(self._validate_capability_structure(cap))
        errors.extend(self._validate_capability_logic(cap))
        return errors

    def _validate_workflow_structure(self, wf: Workflow) -> list[str]:
        """Validate the basic structure and required fields of a workflow."""
        errors = []
        if not wf.id:
            errors.append("Workflow missing 'id'")
        if not wf.title:
            errors.append(f"Workflow '{wf.id or 'unknown'}' missing 'title'")
        if not wf.description:
            errors.append(f"Workflow '{wf.id}' missing 'description'")
        if not wf.triggers:
            errors.append(f"Workflow '{wf.id}' has no triggers")
        return errors

    def _validate_workflow_logic(self, wf: Workflow) -> list[str]:
        """Validate the logical consistency of a workflow."""
        errors = []
        if wf.privileged and not wf.rate_limit:
            errors.append(f"Privileged workflow '{wf.id}' should define 'rateLimit'")
        if "agent" in wf.triggers and not wf.safety_notes:
            errors.append(f"Agent-triggered workflow '{wf.id}' should have 'safetyNotes'")
        return errors

    def _validate_workflow(self, wf: Workflow) -> list[str]:
        """Validate a single workflow"""
        errors = []
        errors.extend(self._validate_workflow_structure(wf))
        errors.extend(self._validate_workflow_logic(wf))
        return errors

    def validate(self) -> list[str]:
        """Validate capabilities and workflows"""
        errors = []
        for cap in self.capabilities:
            errors.extend(self._validate_capability(cap))
        for wf in self.workflows:
            errors.extend(self._validate_workflow(wf))
        return errors

    def to_dict(self) -> dict[str, Any]:
        """Export capabilities and workflows as dictionary.

        Returns:
            Dictionary with capabilities and workflows

        """
        return {
            "capabilities": [cap.to_dict() for cap in self.capabilities],
            "workflows": [wf.to_dict() for wf in self.workflows],
        }

    def save_to_file(self, file_path: Path) -> None:
        """Save capabilities and workflows to JSON file.

        Args:
            file_path: Output path

        """
        try:
            with Path(file_path).open("w", encoding="utf-8") as f:
                json.dump(self.to_dict(), f, indent=2)
            logger.info(f"Saved capabilities to {file_path}")
        except Exception as e:
            logger.error(f"Failed to save capabilities to {file_path}", e)
            raise


# Standard capability templates
STANDARD_CAPABILITIES = [
    Capability(
        id="com.manifestguard.workspace.read",
        title="Workspace Read",
        description="Read-only access to workspace files for static analysis.",
        scope="workspace",
        privileged=False,
        required_consent=False,
    ),
    Capability(
        id="com.manifestguard.workspace.write",
        title="Workspace Write",
        description="Write access to workspace files (e.g., auto-fixes, reports).",
        scope="workspace",
        privileged=True,
        required_consent=True,
    ),
    Capability(
        id="com.manifestguard.network",
        title="Network Access",
        description="Outgoing HTTP requests to configured AI providers.",
        scope="runtime",
        privileged=True,
        required_consent=True,
        allowed_hosts=["api.openai.com", "localhost:11434"],
    ),
    Capability(
        id="com.manifestguard.exec",
        title="External Process Execution",
        description="Spawn external processes (e.g., test runners, linters).",
        scope="runtime",
        privileged=True,
        required_consent=True,
    ),
]


# Standard workflow templates
STANDARD_WORKFLOWS = [
    Workflow(
        id="com.manifestguard.workflow.test.runAll",
        title="Run All Tests",
        category="testing",
        description="Executes unit and integration tests and produces coverage summary.",
        triggers=["manual", "agent", "ci"],
        privileged=True,
        rate_limit=RateLimit(unit="minute", max=2),
        returns=["coverageReport"],
        safety_notes="Does not publish artifacts externally; writes results locally only.",
        version="1.0.0",
    ),
    Workflow(
        id="com.manifestguard.workflow.audit.full",
        title="Run Full Audit",
        category="audit",
        description="Runs dependency, security, privacy and accessibility audits.",
        triggers=["manual", "agent", "ci"],
        required_consent=True,
        privileged=True,
        returns=["auditReport"],
        safety_notes="Does not send code externally; uses local scanners only.",
        version="1.0.0",
    ),
]


class CapabilitiesManager:
    """Simplified capabilities manager for shared AI preferences integration.

    Provides capability validation for AI agents following VS Code patterns.
    """

    def __init__(self, registry: CapabilitiesRegistry | None = None):
        """Initialize capabilities manager.

        Args:
            registry: Optional capabilities registry

        """
        self.registry = registry or CapabilitiesRegistry()
        self._validated_capabilities: list[str] = []

        # Add standard capabilities if registry is empty
        if not self.registry.capabilities:
            self.registry.capabilities = STANDARD_CAPABILITIES

    def validate_capabilities(self, required_capabilities: list[str]) -> None:
        """Validate that required capabilities are available.

        Args:
            required_capabilities: List of capability names

        Raises:
            PermissionError: If required capability is missing

        """
        self._validated_capabilities = required_capabilities.copy()

        known_capabilities = {
            "network-access": "com.manifestguard.network",
            "fs.write": "com.manifestguard.workspace.write",
            "fs.read": "com.manifestguard.workspace.read",
            "secrets": "com.manifestguard.secrets",
            "exec": "com.manifestguard.exec",
        }

        for capability in required_capabilities:
            if capability in known_capabilities:
                # Check if this capability is available
                cap_id = known_capabilities[capability]
                cap = self.registry.get_capability(cap_id)

                if cap and cap.privileged:
                    # Privileged capabilities need special handling
                    logger.info(f"Validating privileged capability: {capability}")

            elif not capability.startswith("com."):
                # Unknown capability format
                warnings.warn(
                    f"Unknown capability '{capability}'. "
                    f"Expected format: 'network-access', 'fs.write', etc.",
                    UserWarning,
                    stacklevel=2,
                )

    def _check_network_permission(self) -> None:
        """Check if network access is allowed."""
        if "network-access" not in self._validated_capabilities:
            raise PermissionError(
                "Network access not permitted. " "Declare 'network-access' capability.",
            )

    def _check_file_write_permission(self) -> None:
        """Check if file write is allowed."""
        if "fs.write" not in self._validated_capabilities:
            raise PermissionError(
                "File write access not permitted. " "Declare 'fs.write' capability.",
            )

    def _check_secrets_permission(self) -> None:
        """Check if secrets access is allowed."""
        if "secrets" not in self._validated_capabilities:
            raise PermissionError("Secrets access not permitted. " "Declare 'secrets' capability.")

    def _check_exec_permission(self) -> None:
        """Check if execution is allowed."""
        if "exec" not in self._validated_capabilities:
            raise PermissionError("Execution not permitted. " "Declare 'exec' capability.")

    def can_access_network(self, capabilities: list[str]) -> bool:
        """Check if network access capability is declared."""
        return "network-access" in capabilities

    def can_access_secrets(self, capabilities: list[str]) -> bool:
        """Check if secrets access capability is declared."""
        return "secrets" in capabilities

    def can_write_files(self, capabilities: list[str]) -> bool:
        """Check if file write capability is declared."""
        return "fs.write" in capabilities

    def can_orchestrate_workflows(self, capabilities: list[str]) -> bool:
        """Check if capabilities are sufficient for workflow orchestration.

        Requires network and execution capabilities.
        """
        return self.can_access_network(capabilities) and "exec" in capabilities
