# Test Configuration Guide (Python)

## Overview

ManifestGuard Python supports **threshold-based test configuration** to enforce quality gates and provide fine-grained control over test results. This system allows you to:

- Set maximum allowed errors, warnings, and info messages per test
- Enable/disable expensive checks (Deep Analysis Mode)
- Validate tool configurations before running tests (e.g., Radon, Pylint, Ruff)
- Gradually improve code quality with incremental thresholds

## Configuration Structure

Add a `testConfig` section to your `manifestguard.json`:

```json
{
  "testConfig": {
    "deepAnalysisMode": true,
    "thresholds": {
      "maxErrors": 0,
      "maxWarnings": 0
    },
    "<test-name>": {
      "enabled": true,
      "deepAnalysisMode": false,
      "thresholds": {
        "maxErrors": 0,
        "maxWarnings": 10,
        "maxInfo": 50
      }
    }
  }
}
```

Notes:
- `testConfig.deepAnalysisMode` and `testConfig.thresholds` act as **global defaults**.
- `testConfig.<test-name>.*` overrides the global defaults for that specific test.
- **Threshold gate is always active for expensive extended checks** (coverage/complexity/bugfix history):
  - If you do not configure thresholds, the default gate is **errors=0 and warnings=0**.
  - This means expensive metrics run only after the workspace passes the basic validation gate.

### Properties

- **`enabled`**: Whether the test should run (default: `true`)
- **`deepAnalysisMode`**: Enable expensive analysis (complexity, security scans) (default: `false`)
- **`thresholds`**: Severity limits
  - **`maxErrors`**: Maximum allowed errors (`None` = unlimited)
  - **`maxWarnings`**: Maximum allowed warnings (`None` = unlimited)
  - **`maxInfo`**: Maximum allowed info messages (`None` = unlimited)

### Duplication / Redundancy (Code Duplicates)

Code duplication detection is configured separately from `testConfig`.
In `manifestguard.json`, use `duplicationDetection` (or legacy key `duplication`) to tune redundancy sensitivity:

```json
{
  "duplicationDetection": {
    "enabled": true,
    "includeTests": true,
    "windowLines": 12,
    "minOccurrences": 2,
    "maxResults": 200
  }
}
```

These values act as practical “redundancy thresholds” (what counts as a duplicate block, how many repeats are required, and how much output is reported).

## Practical Examples

## AI Ground Rules (Reports)

When you generate a JSON report (for example via `manifestguard check --report ...`), ManifestGuard includes a `refactorGuidelines` section.
This section contains versioned, tool-agnostic ground rules intended for automation (including AI fix/refactor loops).

MGVS (the VS Code extension) injects the same `refactorGuidelines` into its JSON reports, so tooling can follow consistent rules across both ecosystems.

Important workflow note:
- If expensive extended metrics were skipped because the threshold gate was not satisfied, the AI/fix loop should:
  1) Reduce validation errors/warnings until the gate passes (default: errors=0, warnings=0),
  2) Rerun extended analysis,
  3) Then fix the extended findings (coverage, complexity, duplication/redundancy, etc.).

### 1. Strict CI/CD Mode

Enforce zero errors and limited warnings in CI pipelines:

```json
{
  "testConfig": {
    "complexity": {
      "enabled": true,
      "deepAnalysisMode": true,
      "thresholds": {
        "maxErrors": 0,
        "maxWarnings": 5,
        "maxInfo": 20
      }
    },
    "coverage": {
      "enabled": true,
      "thresholds": {
        "maxErrors": 0,
        "maxWarnings": 2
      }
    }
  }
}
```

**Use Case**: Production deployments where quality gates must be enforced.

Tip: For external projects, you can also use the bootstrap runner script `examples/run_manifestguard.py` to install/upgrade ManifestGuard, run tests, and generate a JSON report in one command:

```bash
python run_manifestguard.py --report manifestguard-report.json
```

### 2. Gradual Improvement

Start with current baseline and reduce thresholds over time:

```json
{
  "testConfig": {
    "complexity": {
      "enabled": true,
      "deepAnalysisMode": true,
      "thresholds": {
        "maxErrors": 10,
        "maxWarnings": 50
      }
    }
  }
}
```

**Workflow**:
1. Run analysis to get current violations: `manifestguard complexity --threshold 15`
2. Set thresholds slightly above current levels
3. Gradually reduce thresholds as you refactor code
4. Lock in improvements to prevent regression

### 3. Development Mode

Allow flexibility during active development:

```json
{
  "testConfig": {
    "complexity": {
      "enabled": true,
      "deepAnalysisMode": false,
      "thresholds": {
        "maxErrors": 100,
        "maxWarnings": 500
      }
    }
  }
}
```

**Use Case**: Local development where warnings are informational but shouldn't block progress.

### 4. Disabled Tests

Skip specific tests without removing configuration:

```json
{
  "testConfig": {
    "complexity": {
      "enabled": false,
      "reason": "Temporarily disabled during major refactor"
    }
  }
}
```

## Tool Configuration Validation

ManifestGuard validates tool configurations before running tests. This prevents silent failures where the tool is misconfigured.

### Complexity Check (Radon)

When using `engine: "radon"`, ManifestGuard validates:

1. **pyproject.toml** `[tool.radon]` section:
   ```toml
   [tool.radon]
   [tool.radon.cc]
   max_complexity = 15
   ```

2. **`.radon.cfg`** (legacy):
   ```ini
   [cc]
   max_complexity = 15
   ```

**Validation Results**:

```python
{
  "tool_config_status": {
    "found": true,
    "valid": true,
    "errors": [],
    "configured_threshold": 15
  }
}
```

### Invalid Configuration Example

If `max_complexity` is missing or invalid:

```python
{
  "tool_config_status": {
    "found": false,
    "valid": false,
    "errors": [
      "No Radon configuration found (pyproject.toml [tool.radon] or .radon.cfg)"
    ],
    "configured_threshold": null
  }
}
```

**Recommendation**: Always configure your tools properly. ManifestGuard will warn you if configuration is missing.

## Python Usage

### Check Thresholds Programmatically

```python
from pathlib import Path
from manifestguard.core.test_config_helper import check_thresholds

# After running a test
result = check_thresholds(
    test_name="complexity",
    errors=2,
    warnings=8,
    info=15,
    workspace_root=Path(".")
)

if not result.passes:
    print(f"❌ {result.message}")
    print(f"   Exceeded: {', '.join(result.exceeded)}")
else:
    print(f"✅ {result.message}")
```

### Load Test Configuration

```python
from pathlib import Path
from manifestguard.core.test_config_helper import get_test_config

config = get_test_config("complexity", Path("."))

if config.thresholds:
    print(f"Max errors: {config.thresholds.max_errors}")
    print(f"Max warnings: {config.thresholds.max_warnings}")
    print(f"Max info: {config.thresholds.max_info}")
```

### Validate Tool Configuration

```python
from pathlib import Path
from manifestguard.extended.complexity import ComplexityAnalyzer

analyzer = ComplexityAnalyzer(Path("."))
metrics = analyzer.analyze(threshold=15, engine="radon", validate_config=True)

if metrics.tool_config_status and not metrics.tool_config_status.valid:
    print("⚠️  Tool configuration issues:")
    for error in metrics.tool_config_status.errors:
        print(f"  - {error}")
```

## CLI Usage

### Run Complexity Check with Thresholds

```bash
# Standard complexity analysis
manifestguard complexity --threshold 15

# With test files included
manifestguard complexity --threshold 15 --include-tests

# Using Radon engine (validates configuration)
manifestguard complexity --threshold 15 --engine radon
```

### Check Threshold Results

After running analysis, programmatically check thresholds:

```python
import json
from pathlib import Path
from manifestguard.core.test_config_helper import check_thresholds

# Load metrics
with open(".manifestguard/metrics.json") as f:
    metrics = json.load(f)

# Count issues by severity
errors = sum(1 for v in metrics["violations"] if v.get("severity") == "error")
warnings = sum(1 for v in metrics["violations"] if v.get("severity") == "warning")

result = check_thresholds("complexity", errors, warnings, 0, Path("."))
print(result.message)
```

## Best Practices

### 1. Start with Current Baseline

Don't set thresholds arbitrarily. Run tests first:

```bash
# Get current state
manifestguard complexity --threshold 15 > baseline.txt

# Review violations count
grep "Found" baseline.txt
```

Then set thresholds **slightly above** current levels to prevent regression.

### 2. Use Deep Analysis Mode Sparingly

Deep Analysis Mode enables expensive checks (complexity, security):

```json
{
  "testConfig": {
    "complexity": {
      "deepAnalysisMode": true
    }
  }
}
```

**When to enable**:
- ✅ CI/CD pipelines (pre-merge checks)
- ✅ Scheduled nightly builds
- ✅ Pre-release validation

**When to disable**:
- ❌ Every file save (too slow)
- ❌ Local development (use on-demand)

### 3. Separate CI and Local Configs

Use environment-specific configuration:

```bash
# Local development
manifestguard complexity --threshold 20

# CI pipeline (strict)
manifestguard complexity --threshold 12 --engine radon
```

Or use different `manifestguard.json` files:
- `manifestguard.json` (local)
- `manifestguard.ci.json` (CI)

### 4. Document Threshold Choices

Add comments explaining why thresholds are set:

```json
{
  "testConfig": {
    "complexity": {
      "thresholds": {
        "maxErrors": 5,
        "maxWarnings": 20
      },
      "reason": "Current baseline: 3 errors, 15 warnings (2024-01-15). Allow buffer for new code."
    }
  }
}
```

### 5. Monitor Trends

Track threshold violations over time:

```bash
# Save baseline
date >> thresholds.log
manifestguard complexity --threshold 15 | tee -a thresholds.log

# Review monthly
grep "violations" thresholds.log | tail -5
```

## Integration with CI/CD

### GitHub Actions

```yaml
name: Quality Gate

on: [push, pull_request]

jobs:
  quality:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install ManifestGuard
        run: pip install manifestguard
      
      - name: Run Complexity Check
        run: |
          manifestguard complexity --threshold 15 --engine radon
          
      - name: Validate Thresholds
        run: python scripts/check_thresholds.py
```

### Threshold Validation Script

```python
# scripts/check_thresholds.py
import json
import sys
from pathlib import Path
from manifestguard.core.test_config_helper import check_thresholds

# Load metrics
metrics_path = Path(".manifestguard/metrics.json")
if not metrics_path.exists():
    print("❌ No metrics file found")
    sys.exit(1)

with metrics_path.open() as f:
    metrics = json.load(f)

# Count violations
violations = metrics.get("violations", [])
errors = sum(1 for v in violations if v.get("rank") in ["E", "F"])
warnings = sum(1 for v in violations if v.get("rank") in ["C", "D"])

# Check thresholds
result = check_thresholds("complexity", errors, warnings, 0, Path("."))

print(result.message)
if not result.passes:
    print(f"Exceeded: {', '.join(result.exceeded)}")
    sys.exit(1)
```

## Troubleshooting

### Issue: Thresholds Not Applied

**Symptom**: Tests pass even when violations exceed configured limits.

**Solution**:
1. Verify `manifestguard.json` syntax is valid JSON
2. Check test name matches exactly (case-sensitive)
3. Ensure `testConfig` is at root level of JSON

### Issue: Tool Configuration Not Found

**Symptom**: Warning about missing Radon/Pylint configuration.

**Solution**:
1. Add `[tool.radon]` section to `pyproject.toml`:
   ```toml
   [tool.radon]
   [tool.radon.cc]
   max_complexity = 15
   ```

2. Or create `.radon.cfg`:
   ```ini
   [cc]
   max_complexity = 15
   ```

### Issue: Deep Analysis Mode Too Slow

**Symptom**: Tests take minutes to complete.

**Solution**:
- Disable Deep Analysis Mode for local development
- Run complexity checks on-demand: `manifestguard complexity`
- Enable only in CI/CD pipelines

## Related Documentation

- [Complexity Analysis](./COMPLEXITY.md) - Understanding complexity metrics
- [Configuration Reference](./CONFIG.md) - Full `manifestguard.json` schema
- [CI/CD Integration](./CI-CD.md) - Pipeline examples

## Support

For issues or questions:
- GitHub Issues: https://github.com/ready-4-it/r4it_manifest_guard_py/issues
- Documentation: See `docs/` directory
