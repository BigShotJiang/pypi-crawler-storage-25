from __future__ import annotations

from datetime import datetime, timezone
import time
from typing import Any

DEFAULT_SKEW_SECONDS = 300


def _to_epoch_seconds(val: Any) -> int:
    """Convert epoch int or ISO8601 string to epoch seconds.

    Accepts integer seconds or ISO8601-like strings (Z allowed).
    """
    if val is None:
        return 0

    if isinstance(val, (int, float)):
        return int(val)

    if isinstance(val, str):
        s = val.strip()
        # Allow trailing Z (UTC)
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return int(dt.timestamp())
        except Exception:
            # Fallback: try parse as int string
            try:
                return int(s)
            except Exception:
                raise ValueError(f"Unsupported time value: {val}")

    raise ValueError(f"Unsupported time value: {val}")


def is_update_entitled(activation_obj: dict[str, Any], now: int | None = None, skew_seconds: int = DEFAULT_SKEW_SECONDS) -> bool:
    """Return True if the activation object grants update entitlement now.

    activation_obj: expected keys include `updateEntitlementUntil` (ISO8601 or epoch) or None.
    """
    if now is None:
        now = int(time.time())

    ue = activation_obj.get("updateEntitlementUntil")
    if ue is None:
        return False

    try:
        expiry = _to_epoch_seconds(ue)
    except ValueError:
        return False

    return now <= (expiry + skew_seconds)


def clamp_effective_expiry(effective_expiry: int, baseline_first_activation: int, years: int = 1) -> int:
    """Clamp an expiry timestamp to baseline_first_activation + years.

    Returns the clamped expiry (epoch seconds).
    """
    cap = baseline_first_activation + years * 365 * 24 * 3600
    return min(effective_expiry, cap)


def can_activate_more_devices(activation_obj: dict[str, Any], current_device_count: int) -> bool:
    """Return True if another device activation is allowed per `maxActivations`.

    If `maxActivations` is missing or negative, treat as unlimited.
    """
    ma = activation_obj.get("maxActivations")
    if ma is None:
        return True
    try:
        ma_int = int(ma)
    except Exception:
        return True

    if ma_int < 0:
        return True

    return current_device_count < ma_int
