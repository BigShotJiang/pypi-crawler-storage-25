"""Low-level token parsing and Ed25519 signature verification.

These utilities are intentionally stateless (no client / keyring references).
They operate on raw R4IT.<base64_payload>.<base64_signature> token strings.
"""

from __future__ import annotations

import base64
import json
from typing import Any

try:
    import nacl.encoding
    import nacl.exceptions
    import nacl.signing

    _NACL_AVAILABLE = True
except ImportError:
    _NACL_AVAILABLE = False


def parse_token_payload(token: str) -> dict[str, Any]:
    """Parse an R4IT token and return the decoded payload dict.

    Raises ValueError if the format is invalid.
    """
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid token format: must be R4IT.payload.signature")

    prefix, payload_b64, _signature_b64 = parts

    if prefix != "R4IT":
        raise ValueError("Token must start with R4IT")

    try:
        payload_b64_padded = payload_b64 + "=" * ((4 - (len(payload_b64) % 4)) % 4)
        payload_bytes = base64.urlsafe_b64decode(payload_b64_padded)
        return json.loads(payload_bytes)
    except (ValueError, json.JSONDecodeError) as e:
        raise ValueError(f"Invalid token payload: {e}")


def verify_token_signature(token: str, public_key_b64: str) -> bool:
    """Verify the Ed25519 signature of an R4IT token.

    Returns True when the signature is valid, False otherwise.
    Raises RuntimeError if PyNaCl is not installed.
    """
    if not _NACL_AVAILABLE:
        raise RuntimeError("PyNaCl not installed - cannot verify signatures")

    try:
        parts = token.split(".")
        if len(parts) != 3 or parts[0] != "R4IT":
            return False

        payload_b64, signature_b64 = parts[1], parts[2]

        public_key_bytes = base64.b64decode(public_key_b64)
        if len(public_key_bytes) != 32:
            return False

        verify_key = nacl.signing.VerifyKey(public_key_bytes)

        payload_b64_padded = payload_b64 + "=" * ((4 - (len(payload_b64) % 4)) % 4)
        payload_bytes_raw = base64.urlsafe_b64decode(payload_b64_padded)

        signature_b64_padded = signature_b64 + "=" * ((4 - (len(signature_b64) % 4)) % 4)
        signature_bytes = base64.urlsafe_b64decode(signature_b64_padded)

        # Verify detached Ed25519 signature over the raw payload bytes.
        # IMPORTANT: uses raw bytes (no re-dump/canonicalization), matching the
        # generic licensing guide contract.
        verify_key.verify(payload_bytes_raw, signature_bytes)
        return True

    except (nacl.exceptions.BadSignatureError, ValueError, Exception):
        return False


def validate_token_expiry(payload: dict[str, Any], *, max_past_days: int = 90) -> bool:
    """Return True only when the token has a valid, non-expired ``exp`` claim.

    Args:
        payload: Decoded token payload from ``parse_token_payload()``.
        max_past_days: Not used for acceptance — any expired token is rejected.
            Reserved for future grace-period logic; kept for API stability.

    Returns:
        ``True`` when ``exp`` is present, parseable, and in the future.
        ``False`` when ``exp`` is missing, un-parseable, or in the past.
    """
    from datetime import datetime, timezone

    exp = payload.get("exp")
    if exp is None:
        return False
    try:
        exp_dt = datetime.fromtimestamp(int(exp), tz=timezone.utc)
    except (ValueError, OSError, OverflowError):
        return False
    return exp_dt > datetime.now(timezone.utc)
