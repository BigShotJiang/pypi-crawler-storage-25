"""Global repo registry — tracks distinct project roots for max_repos tier enforcement.

Stores stable path fingerprints in ~/.manifestguard/repo_registry.json.
Legacy registry files may still be a plain JSON list of fingerprints; newer files
store per-entry timestamps for status inspection.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

_REGISTRY_PATH = Path.home() / ".manifestguard" / "repo_registry.json"


@dataclass(frozen=True)
class RepoLimitExceeded:
    max_repos: int
    count: int


@dataclass(frozen=True)
class RepoRegistryEntry:
    fingerprint: str
    first_seen: str
    last_seen: str


def _fingerprint(path: Path) -> str:
    """Return a short, stable SHA-256 hash of the resolved absolute path."""
    return hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:16]


def _now_iso() -> str:
    """Return the current UTC timestamp in stable ISO-8601 form."""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load_registry_entries() -> dict[str, RepoRegistryEntry]:
    """Load registry entries from either legacy or metadata-aware file formats."""
    try:
        data = json.loads(_REGISTRY_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

    if isinstance(data, list):
        return {
            fingerprint: RepoRegistryEntry(
                fingerprint=fingerprint,
                first_seen="",
                last_seen="",
            )
            for fingerprint in data
            if isinstance(fingerprint, str)
        }

    if not isinstance(data, dict):
        return {}

    raw_entries = data.get("entries")
    if not isinstance(raw_entries, list):
        return {}

    entries: dict[str, RepoRegistryEntry] = {}
    for raw_entry in raw_entries:
        if not isinstance(raw_entry, dict):
            continue
        fingerprint = raw_entry.get("fingerprint")
        if not isinstance(fingerprint, str) or not fingerprint:
            continue
        first_seen = str(raw_entry.get("firstSeen") or "")
        last_seen = str(raw_entry.get("lastSeen") or first_seen)
        entries[fingerprint] = RepoRegistryEntry(
            fingerprint=fingerprint,
            first_seen=first_seen,
            last_seen=last_seen,
        )
    return entries


def _save_registry_entries(entries: dict[str, RepoRegistryEntry]) -> None:
    """Persist metadata-aware repo registry entries."""
    _REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _REGISTRY_PATH.with_suffix(_REGISTRY_PATH.suffix + ".tmp")
    payload = {
        "schemaVersion": 1,
        "entries": [
            {
                "fingerprint": entry.fingerprint,
                "firstSeen": entry.first_seen,
                "lastSeen": entry.last_seen,
            }
            for entry in sorted(entries.values(), key=lambda item: item.fingerprint)
        ],
    }
    try:
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(_REGISTRY_PATH)
    except Exception:
        pass


def _load_registry() -> set[str]:
    return set(_load_registry_entries().keys())


def _save_registry(registry: set[str]) -> None:
    _REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _REGISTRY_PATH.with_suffix(_REGISTRY_PATH.suffix + ".tmp")
    try:
        tmp.write_text(json.dumps(sorted(registry), indent=2), encoding="utf-8")
        tmp.replace(_REGISTRY_PATH)
    except Exception:
        pass


def list_registered_repos() -> list[RepoRegistryEntry]:
    """Return repo-registry entries sorted by last-seen, then fingerprint."""
    entries = _load_registry_entries().values()
    return sorted(entries, key=lambda entry: (entry.last_seen, entry.fingerprint), reverse=True)


def check_repo_limit(workspace_root: Path, max_repos: int) -> RepoLimitExceeded | None:
    """Register workspace_root and check whether max_repos is exceeded.

    Args:
        workspace_root: The project root being scanned.
        max_repos: The tier's repository limit. Use -1 (or any negative) for
            unlimited — in that case this function always returns None.

    Returns:
        None if the limit is not exceeded (or unlimited), RepoLimitExceeded otherwise.
    """
    if max_repos < 0:
        return None

    fp = _fingerprint(workspace_root)
    now_iso = _now_iso()
    registry_entries = _load_registry_entries()

    # Already registered → within limit (re-scanning a known repo is always allowed).
    if fp in registry_entries:
        existing_entry = registry_entries[fp]
        registry_entries[fp] = RepoRegistryEntry(
            fingerprint=existing_entry.fingerprint,
            first_seen=existing_entry.first_seen or now_iso,
            last_seen=now_iso,
        )
        _save_registry_entries(registry_entries)
        return None

    registry_entries[fp] = RepoRegistryEntry(
        fingerprint=fp,
        first_seen=now_iso,
        last_seen=now_iso,
    )
    _save_registry_entries(registry_entries)

    count = len(registry_entries)
    if count > max_repos:
        return RepoLimitExceeded(max_repos=max_repos, count=count)

    return None
