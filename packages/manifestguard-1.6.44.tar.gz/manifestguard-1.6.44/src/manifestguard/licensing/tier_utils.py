"""Tier normalization utilities — standalone so they can be used without importing LicensingClient."""

from __future__ import annotations

from typing import Any

_TIER_ALIASES: dict[str, str] = {
    "trial": "trial",
    "early_access": "trial",
    "free": "community",
    "basic": "community",
    "standard": "pro",
    "premium": "team",
    "ultimate": "enterprise",
}


def normalize_tier(raw_tier: Any) -> str:
    """Normalize a raw tier string (from JWT payload or activation) to a canonical tier name."""
    tier = str(raw_tier or "community").strip().lower()
    return _TIER_ALIASES.get(tier, tier)
