"""TUI history loading helpers.

The main TUI module is intentionally kept focused on rendering and interaction.
This module contains the JSON history parsing + trend series extraction.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from manifestguard.extended.coverage_weekly import reconstruct_weekly_coverage


def _get_num(obj: Any, *path: str) -> float | None:
    cur: Any = obj
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    if isinstance(cur, (int, float)):
        return float(cur)
    return None


def pick_history_source_file(workspace_root: Path) -> Path | None:
    candidate = workspace_root / ".mgpy" / "metrics" / "manifestguard-history.json"
    if candidate.exists():
        return candidate
    return None


def resolve_history_source_file(workspace_root: Path) -> tuple[Path | None, list[Path]]:
    """Resolve the best history source file path (with diagnostics).

    Returns:
        (selected, tried)
        - selected: first existing candidate (or None)
        - tried: all candidates in the priority order that was checked
    """
    candidates = [
        workspace_root / ".mgpy" / "metrics" / "manifestguard-history.json",
        workspace_root / ".manifestguard-history.json",
        workspace_root / ".manifestguard" / "metrics-history.json",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate, candidates
    return None, candidates


def history_source_resolution_diagnostics(workspace_root: Path) -> str:
    selected, tried = resolve_history_source_file(workspace_root)
    if selected is not None:
        return f"History source selected: {selected}"
    lines = ["No history source found. Tried:"]
    for path in tried:
        lines.append(f"- {path.as_posix()}")
    return "\n".join(lines)


def pick_report_source_file(workspace_root: Path) -> Path | None:
    candidates = [
        workspace_root / "manifestguard-report.json",
        workspace_root / "manifestguard-report-refactor.json",
        workspace_root / ".manifestguard" / "manifestguard-report.json",
        workspace_root / ".manifestguard" / "manifestguard-report-refactor.json",
    ]
    existing = [candidate for candidate in candidates if candidate.exists()]
    if not existing:
        return None
    return max(existing, key=lambda candidate: candidate.stat().st_mtime)


def extract_history_entries(data: Any) -> list[dict[str, Any]]:
    if not isinstance(data, dict):
        return []

    entries = data.get("entries")
    if not isinstance(entries, list):
        entries = data.get("history")
    if not isinstance(entries, list):
        return []

    return [entry for entry in entries if isinstance(entry, dict)]


def take_recent_entries(entries: list[dict[str, Any]], *, limit: int) -> list[dict[str, Any]]:
    if len(entries) <= limit:
        return list(entries)
    return list(entries[-limit:])


def try_load_json_file(source_file: Path) -> dict[str, Any] | None:
    try:
        with source_file.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _coverage_value(entry: dict[str, Any]) -> float:
    coverage_obj = entry.get("coverage") if isinstance(entry.get("coverage"), dict) else {}
    explicit_measured = coverage_obj.get("unit_measured") if isinstance(coverage_obj, dict) else None
    if explicit_measured is False:
        return 0.0

    line_rate = _get_num(entry, "coverage", "line_rate")
    line_rate_pct = (line_rate * 100) if line_rate is not None and line_rate <= 1.0 else line_rate
    cov = (
        _get_num(entry, "coverage", "unit_percent")
        or _get_num(entry, "coverage", "estimate")
        or line_rate_pct
        or 0.0
    )
    if explicit_measured is not True and cov == 0.0:
        return 0.0
    return float(cov)


def _coverage_measured(entry: dict[str, Any]) -> bool:
    coverage_obj = entry.get("coverage") if isinstance(entry.get("coverage"), dict) else {}
    explicit_measured = coverage_obj.get("unit_measured") if isinstance(coverage_obj, dict) else None
    if isinstance(explicit_measured, bool):
        return explicit_measured

    if _get_num(entry, "coverage", "unit_percent") is not None:
        return float(_get_num(entry, "coverage", "unit_percent") or 0.0) > 0.0
    if _get_num(entry, "coverage", "estimate") is not None:
        return float(_get_num(entry, "coverage", "estimate") or 0.0) > 0.0
    line_rate = _get_num(entry, "coverage", "line_rate")
    if line_rate is not None:
        return float(line_rate) > 0.0
    return False


def _complexity_value(entry: dict[str, Any]) -> float:
    comp = (
        _get_num(entry, "complexity", "average_complexity")
        or _get_num(entry, "complexity", "avgComplexity")
        or 0.0
    )
    return float(comp)


def _quality_value(entry: dict[str, Any]) -> float:
    qual = _get_num(entry, "quality", "score")
    if qual is None:
        qual = _get_num(entry, "quality_score")
    return float(qual or 0.0)


def _security_value(entry: dict[str, Any]) -> float:
    sec = _get_num(entry, "security", "totalFindings")
    if sec is None:
        sec = _get_num(entry, "issues", "totalIssues")
    return float(sec or 0.0)


def _vulnerable_value(entry: dict[str, Any]) -> float:
    vuln = (
        _get_num(entry, "dependencies", "vulnerable")
        or _get_num(entry, "dependency", "vulnerable_count")
        or 0.0
    )
    if vuln == 0.0:
        high = _get_num(entry, "dependency", "vulnerable_high") or 0.0
        critical = _get_num(entry, "dependency", "vulnerable_critical") or 0.0
        vuln = float(high + critical)
    return float(vuln)


def _performance_value(entry: dict[str, Any]) -> float:
    perf = (
        _get_num(entry, "performance", "total_analysis_ms")
        or _get_num(entry, "performance", "total_ms")
        or 0.0
    )
    return float(perf)


def _bpd_value(entry: dict[str, Any]) -> float:
    return float(_get_num(entry, "bugfixes", "bpd") or 0.0)


def _venv_health_score_value(entry: dict[str, Any]) -> float:
    """Extract venv health score (0-100) from the first venvHealth metric in entry.

    Score = running / totalManaged * 100. Returns 0.0 when no venvHealth metric exists.
    """
    for metric in entry.get("metrics", []):
        if not isinstance(metric, dict) or metric.get("metric") != "venvHealth":
            continue
        value = metric.get("value", {})
        if not isinstance(value, dict):
            continue
        ps = value.get("processStats", {})
        if not isinstance(ps, dict):
            continue
        total = int(ps.get("totalManaged") or 0)
        running = int(ps.get("running") or 0)
        return (running / total * 100.0) if total > 0 else 0.0
    return 0.0


def _dead_pids_value(entry: dict[str, Any]) -> float:
    """Extract dead process count from the first venvHealth metric in entry."""
    for metric in entry.get("metrics", []):
        if not isinstance(metric, dict) or metric.get("metric") != "venvHealth":
            continue
        value = metric.get("value", {})
        if not isinstance(value, dict):
            continue
        ps = value.get("processStats", {})
        if not isinstance(ps, dict):
            continue
        return float(ps.get("dead") or 0)
    return 0.0


def _ruff_violations_value(entry: dict[str, Any]) -> float:
    """Extract total ruff violation count from the first ruffViolations metric in entry."""
    for metric in entry.get("metrics", []):
        if not isinstance(metric, dict) or metric.get("metric") != "ruffViolations":
            continue
        value = metric.get("value", {})
        if isinstance(value, dict):
            return float(value.get("total") or 0)
    return 0.0


def _weekly_coverage_series(history_file: Path) -> list[float]:
    try:
        weekly_buckets = reconstruct_weekly_coverage(history_file)
        weeks = sorted(weekly_buckets.keys())[-52:]
        return [weekly_buckets[week]["avg_coverage"] for week in weeks]
    except Exception:
        return []


def build_trends_from_entries(
    recent: list[dict[str, Any]],
    *,
    history_file: Path,
) -> dict[str, list[float]]:
    trends: dict[str, list[float]] = {
        "coverage": [],
        "coverage_weekly": [],
        "complexity": [],
        "quality": [],
        "security": [],
        "vulnerable": [],
        "performance": [],
        "bpd": [],
        "scan_space_files": [],
        "scan_space_loc": [],
        "venv_health": [],
        "dead_pids": [],
        "ruff": [],
    }

    for entry in recent:
        trends["coverage"].append(_coverage_value(entry))
        trends["complexity"].append(_complexity_value(entry))
        trends["quality"].append(_quality_value(entry))
        trends["security"].append(_security_value(entry))
        trends["vulnerable"].append(_vulnerable_value(entry))
        trends["performance"].append(_performance_value(entry))
        trends["bpd"].append(_bpd_value(entry))
        scan_space = entry.get("scanSpace") if isinstance(entry.get("scanSpace"), dict) else {}
        trends["scan_space_files"].append(float(scan_space.get("included") or 0))
        trends["scan_space_loc"].append(float(scan_space.get("linesOfCode") or 0))
        trends["venv_health"].append(_venv_health_score_value(entry))
        trends["dead_pids"].append(_dead_pids_value(entry))
        trends["ruff"].append(_ruff_violations_value(entry))

    trends["coverage_weekly"] = _weekly_coverage_series(history_file)
    return trends


def history_entry_to_runtime_metrics(entry: dict[str, Any]) -> dict[str, Any]:
    """Normalize a persisted history entry into the TUI runtime metrics shape."""
    dependencies = entry.get("dependencies") if isinstance(entry.get("dependencies"), dict) else {}
    complexity = entry.get("complexity") if isinstance(entry.get("complexity"), dict) else {}
    bugfixes = entry.get("bugfixes") if isinstance(entry.get("bugfixes"), dict) else {}

    coverage_obj = entry.get("coverage") if isinstance(entry.get("coverage"), dict) else {}
    coverage_present = _coverage_measured(entry)

    vulnerable_total = int(_get_num(dependencies, "vulnerable") or 0)

    return {
        "coverage": {
            "unit_percent": _coverage_value(entry),
            "unit_measured": bool(coverage_present),
        },
        "complexity": {
            "average_complexity": _complexity_value(entry),
            "avg_complexity": _complexity_value(entry),
            "files_scanned": int(_get_num(complexity, "filesScanned") or 0),
            "violations": int(_get_num(complexity, "violations") or 0),
            "max_complexity": float(_get_num(complexity, "maxComplexity") or 0.0),
            "threshold": int(_get_num(complexity, "threshold") or 0),
        },
        "dependency": {
            "total_count": int(_get_num(dependencies, "total") or 0),
            "outdated_count": int(_get_num(dependencies, "outdated") or 0),
            "vulnerable_count": vulnerable_total,
            "vulnerable_high": vulnerable_total,
            "vulnerable_critical": 0,
        },
        "bugfixes": {
            "total": int(_get_num(bugfixes, "total") or 0),
            "bpd": _bpd_value(entry),
        },
        "quality_score": _quality_value(entry),
        "scan_space": {
            "files": int(_get_num(entry.get("scanSpace") or {}, "included") or 0),
            "lines_of_code": int(_get_num(entry.get("scanSpace") or {}, "linesOfCode") or 0),
        },
    }


def load_latest_history_metrics(workspace_root: Path) -> tuple[dict[str, Any], str | None]:
    """Load the latest persisted MGPY metrics entry for immediate dashboard display."""
    source_file = pick_history_source_file(workspace_root)
    if source_file is None:
        return {}, None

    data = try_load_json_file(source_file)
    if data is None:
        return {}, None

    entries = extract_history_entries(data)
    if not entries:
        return {}, None

    latest = entries[-1]
    timestamp = latest.get("timestamp") if isinstance(latest.get("timestamp"), str) else None
    return history_entry_to_runtime_metrics(latest), timestamp


def load_latest_report_metrics(workspace_root: Path) -> tuple[dict[str, Any], str | None]:
    """Load detailed metrics from the most recent MGPY report file."""
    report_file = pick_report_source_file(workspace_root)
    if report_file is None:
        return {}, None

    data = try_load_json_file(report_file)
    if data is None:
        return {}, None

    extended = data.get("extended")
    if not isinstance(extended, dict):
        return {}, None

    metrics = extended.get("metrics")
    if not isinstance(metrics, dict):
        return {}, None

    runtime_metrics = dict(metrics)
    quality_score = extended.get("quality_score")
    if isinstance(quality_score, (int, float)):
        runtime_metrics["quality_score"] = float(quality_score)

    timestamp = extended.get("timestamp") if isinstance(extended.get("timestamp"), str) else None
    return runtime_metrics, timestamp


def merge_runtime_metrics(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge runtime metric dictionaries."""
    merged: dict[str, Any] = dict(base)
    for key, value in overlay.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            merged[key] = merge_runtime_metrics(existing, value)
        else:
            merged[key] = value
    return merged
