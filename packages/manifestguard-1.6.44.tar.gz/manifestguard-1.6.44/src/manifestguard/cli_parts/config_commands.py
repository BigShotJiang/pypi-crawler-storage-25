from __future__ import annotations

import json
import sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, cast

import click

import manifestguard.quickcheck as qc
from manifestguard import CONFIG_SCHEMA_VERSION, __version__, get_runtime_version
from manifestguard.api import InterfaceDiscovery
from manifestguard.api.quick_check import ProjectInfo, QuickCheck
from manifestguard.core.config import find_existing_config_path, resolve_workspace_root
from manifestguard.core.examples import (
    get_example_config,
    get_example_history,
    get_example_metrics_schema,
    get_example_report,
    print_all_examples,
)
from manifestguard.gui_dashboard_stats import build_dashboard_stats_html
from manifestguard.gui_dashboard_stats import build_dashboard_stats_view_model
from manifestguard.i18n import t, t_format
from manifestguard.openapi import OpenAPIGenerator
from manifestguard.cli_commands.validate_views import format_violations, run_validate_views


def _show_banner() -> None:
    """Display CLI banner."""
    runtime_version = get_runtime_version()
    click.echo(t("cli.banner.separator", module="cli"))
    click.echo(t("cli.banner.config_generator", module="cli"))
    click.echo(f"   Version: {runtime_version}")
    click.echo(t("cli.banner.separator", module="cli") + "\n")


def _load_existing_config(config_path: Path) -> tuple[dict[str, Any] | None, str | None]:
    """Load existing config and return (config_dict, old_version)."""
    if not config_path.exists():
        return None, None

    try:
        with config_path.open(encoding="utf-8") as handle:
            existing = json.load(handle)
            old_version = existing.get("version", "unknown")
            click.echo(f"📄 Current config version: {old_version}")
            return existing, old_version
    except Exception:
        return None, None


def _show_project_info(project_info: ProjectInfo) -> None:
    """Display detected project information."""
    click.echo(f"   📦 Project Type: {project_info.project_type.value}")
    if project_info.detected_features:
        features_str = ", ".join(sorted(project_info.detected_features))
        click.echo(f"   ✨ Features: {features_str}")


def _show_recommendations_summary(recommendations: list[Any]) -> None:
    """Display recommendations summary."""
    high_prio = [r for r in recommendations if r.priority.value == "high"]
    medium_prio = [r for r in recommendations if r.priority.value == "medium"]
    click.echo(f"\n📋 Recommended Tests ({len(recommendations)} total):")
    click.echo(f"   🔴 High Priority: {len(high_prio)}")
    click.echo(f"   🟡 Medium Priority: {len(medium_prio)}")


def _generate_ai_recommendations(
    project_info: ProjectInfo, recommendations: list[Any]
) -> list[Any]:
    """Generate AI recommendations if available."""
    try:
        click.echo("\n" + t("cli.ai.generating", module="cli"))
        quick_check = QuickCheck()
        ai_recs = quick_check.generate_ai_recommendations(project_info, recommendations)
        if ai_recs:
            click.echo(f"   ✨ Generated {len(ai_recs)} AI recommendation(s)")
        return ai_recs
    except Exception as e:
        click.echo(f"   ⚠️  AI recommendations unavailable: {e}", err=True)
        return []


def _merge_with_existing(
    existing_config: dict[str, Any], config_template: Any, output: str
) -> dict[str, Any]:
    """Merge new config with existing config."""
    try:
        click.echo(f"\n🔄 Merging with existing {output}...")
        merged = qc.merge_configs(existing_config, config_template, preserve_user=True)

        # Show diff
        diff = qc.compare_configs(existing_config, merged)
        if diff.get("added"):
            click.echo(f"   + Added: {', '.join(diff['added'])}")
        if diff.get("removed"):
            click.echo(f"   - Removed: {', '.join(diff['removed'])}")
        if diff.get("changed"):
            click.echo(f"   🔄 Changed: {', '.join(diff['changed'])}")

        return merged
    except Exception as e:
        click.echo(f"   ⚠️  Failed to merge: {e}", err=True)
        click.echo(f"   {t('cli.ai.using_template', module='cli')}")
        return cast(dict[Any, Any], config_template.__dict__)


def _build_final_config(config_template: Any, ai_recommendations: list[Any]) -> dict[str, Any]:
    """Build final configuration dict."""
    final_config: dict[str, Any] = {
        "version": config_template.version,
        "enabled": config_template.enabled,
        "extended": False,
        "recommended_tests": config_template.recommended_tests,
        "settings": config_template.settings,
    }

    if config_template.complexity:
        final_config["complexity"] = config_template.complexity
    if config_template.coverage:
        final_config["coverage"] = config_template.coverage
    if ai_recommendations and "recommendations" not in final_config:
        final_config["recommendations"] = ai_recommendations

    return final_config


def _write_config_file(
    config_path: Path, final_config: dict[str, Any], old_version: str | None
) -> None:
    """Write configuration to file and display success message."""
    # Always stamp the config with the generating tool version so users can
    # see which MGPY release last updated the file.
    final_config["generated_by"] = {
        "tool": "manifestguard",
        "version": __version__,
    }

    with config_path.open("w", encoding="utf-8") as handle:
        json.dump(final_config, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

    # Show version change
    new_version = final_config.get("version", CONFIG_SCHEMA_VERSION)
    if old_version and old_version != new_version:
        msg = t_format(
            "cli.init_config.config_updated",
            old_version=old_version,
            new_version=new_version,
            module="cli",
        )
        click.echo(msg)

    click.echo(t_format("cli.init_config.config_saved", filename=config_path.name, module="cli"))
    test_count = len(final_config.get("recommended_tests", []))
    click.echo(f"   {t_format('cli.init_config.tests_configured', count=test_count, module='cli')}")

    # Show next steps
    click.echo(f"\n{t('cli.init_config.next_steps', module='cli')}")
    click.echo(
        f"   {t_format('cli.init_config.step1_review', filename=config_path.name, module='cli')}"
    )
    click.echo(f"   {t('cli.init_config.step2_run', module='cli')}")
    click.echo(f"   {t('cli.init_config.step3_view', module='cli')}")
    click.echo("   Refactoring rules belong in .mgpy/mg.rules.refactoring.json, not in manifestguard.json.")


def _detect_default_report_path(workspace_root: Path) -> Path | None:
    for candidate_name in (
        "manifestguard-report.latest.json",
        "manifestguard-report.json",
        ".manifestguard/manifestguard-report.latest.json",
        ".manifestguard/manifestguard-report.json",
    ):
        candidate = workspace_root / candidate_name
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def _render_dashboard_stats_text(view_model: Any) -> str:
    lines = [
        "ManifestGuard Dashboard Stats",
        f"Data source: {view_model.data_source}",
        f"Latest timestamp: {view_model.timestamp}",
        "",
        "Cards:",
    ]

    for card in view_model.cards:
        lines.append(f"- {card.title}: {card.value} ({card.subtitle})")

    if getattr(view_model, "charts", None):
        lines.append("")
        lines.append("Charts:")
        for chart in view_model.charts:
            lines.append(f"- {chart.title}: {chart.sparkline}  {chart.value} [{chart.trend_label}]")

    lines.append("")
    lines.append("Sections:")
    for section in view_model.sections:
        lines.append(f"[{section.title}]")
        for row in section.rows:
            lines.append(f"- {row.label}: {row.value}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


@click.command(name="init-config")
@click.option(
    "--merge/--no-merge",
    default=True,
    help="Merge with existing ManifestGuard config (default: merge)",
)
@click.option(
    "--upgrade",
    is_flag=True,
    help="Upgrade mode: preserve user customizations",
)
@click.option(
    "--output",
    type=click.Path(),
    default="manifestguard.json",
    help="Output file path (default: manifestguard.json)",
)
def init_config(merge: bool, upgrade: bool, output: str) -> None:  # noqa: ARG001
    """Generate or update manifestguard.json with recommended checks.

    Refactoring plan rules are separate from manifestguard.json.
    Store them in .mgpy/mg.rules.refactoring.json instead.
    """
    _show_banner()

    workspace_root = resolve_workspace_root()
    config_path = workspace_root / output

    # Load existing config
    existing_config, old_version = _load_existing_config(config_path)
    if merge and existing_config is None:
        legacy_path = find_existing_config_path(workspace_root)
        if legacy_path and legacy_path != config_path:
            existing_config, old_version = _load_existing_config(legacy_path)

    click.echo(t("cli.init_config.analyzing", module="cli"))

    # Detect project type and features
    try:
        project_info = qc.detect_project(workspace_root)
    except Exception as e:
        click.echo(t_format("cli.init_config.analysis_failed", error=e, module="cli"), err=True)
        sys.exit(1)

    _show_project_info(project_info)

    # Get test recommendations
    recommendations = qc.recommend_tests(project_info)
    _show_recommendations_summary(recommendations)

    # Generate config template
    config_template = qc.generate_config(project_info, recommendations)

    # Generate AI recommendations
    ai_recommendations = _generate_ai_recommendations(project_info, recommendations)

    # Merge or create new config
    if merge and existing_config:
        final_config = _merge_with_existing(existing_config, config_template, output)
    else:
        final_config = _build_final_config(config_template, ai_recommendations)

    # Recommendations are tool-generated; keep them fresh.
    # - If we generated recommendations now, prefer them.
    # - If we didn't generate any, remove any stale ones from older configs.
    if ai_recommendations:
        final_config["recommendations"] = ai_recommendations
    else:
        final_config.pop("recommendations", None)

    # Write config
    try:
        _write_config_file(config_path, final_config, old_version)
    except Exception as e:
        click.echo(t_format("cli.init_config.write_failed", error=e, module="cli"), err=True)
        sys.exit(1)


@click.command()
@click.option("--category", type=str, help="Filter by category")
@click.option(
    "--validate", type=str, help='Validate a call: --validate \'check {"file":"test.toml"}\''
)
def list_interfaces(category: str | None, validate: str | None) -> None:
    """List all available CLI commands and options (AI Interface Discovery)."""
    discovery = InterfaceDiscovery()

    if validate:
        # Parse validate string: "command_name {json_args}"
        parts = validate.split(maxsplit=1)
        if len(parts) != 2:
            click.echo(
                json.dumps(
                    {
                        "valid": False,
                        "errors": [t("cli.list_interfaces.invalid_format", module="cli")],
                    },
                    indent=2,
                ),
                err=True,
            )

            sys.exit(1)

        command_name, args_json = parts
        try:
            arguments = json.loads(args_json)
        except json.JSONDecodeError as e:
            click.echo(
                json.dumps(
                    {
                        "valid": False,
                        "errors": [t_format("cli.list_interfaces.invalid_json", error=e, module="cli")],
                    },
                    indent=2,
                ),
                err=True,
            )
            sys.exit(1)

        result = discovery.validate_call(command_name, arguments)


        click.echo(json.dumps(result, indent=2))
        sys.exit(0 if result["valid"] else 1)

    # List interfaces
    output = discovery.to_dict()

    if category:
        # Filter by category
        filtered_interfaces = {
            name: iface
            for name, iface in output["interfaces"].items()
            if iface["category"] == category
        }
        output["interfaces"] = filtered_interfaces
        output["filtered_by"] = category

    interfaces = {
        "manifestguard": {
            "version": __version__,
            "description": "Python Package Manifest Validation",
            "api_version": output["version"],
            "categories": output["categories"],
            "commands": output.get("commands", []),
            "global_options": [
                {"name": "--version", "description": "Show version and exit"},
                {"name": "--help", "description": "Show help and exit"},
            ],
            "interfaces": output["interfaces"],
        }
    }

    click.echo(json.dumps(interfaces, indent=2))


@click.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_tests(output_json: bool) -> None:
    """List all available test categories and checks."""
    tests: dict[str, Any] = {
        "categories": [
            {
                "name": "Core",
                "description": "Essential manifest validation checks",
                "tests": [
                    {
                        "id": "check",
                        "name": "Manifest Check",
                        "description": "Validate pyproject.toml, setup.py, requirements.txt",
                    },
                ],
            },
            {
                "name": "Extended",
                "description": "Extended test mode with 9 metric categories",
                "tests": [
                    {"id": "coverage", "name": "Code Coverage", "description": "Test coverage analysis"},
                    {"id": "dependencies", "name": "Dependency Scan", "description": "Dependency vulnerability scan"},
                    {"id": "security", "name": "Security Scan", "description": "Static analysis for security issues"},
                    {"id": "license", "name": "License Check", "description": "SPDX license compliance"},
                    {"id": "duplication", "name": "Duplication", "description": "Duplicate code detection"},
                    {"id": "dummy", "name": "Dummy Recognition", "description": "Placeholder/dummy code detection"},
                    {"id": "policy", "name": "Policy", "description": "Package allow/block rules"},
                    {"id": "packaging", "name": "Packaging", "description": "Packaging best practices"},
                    {"id": "complexity", "name": "Complexity", "description": "Cyclomatic complexity analysis"},
                ],
            },
            {
                "name": "Quality",
                "description": "Code quality metrics",
                "tests": [
                    {"id": "complexity", "name": "Complexity", "description": "Cyclomatic complexity"},
                    {"id": "duplication", "name": "Duplication", "description": "Duplicate code detection"},
                    {"id": "dummy", "name": "Dummy", "description": "Dummy/placeholder code"},
                ],
            },
            {
                "name": "Dashboard",
                "description": "Interactive TUI",
                "tests": [
                    {
                        "id": "dashboard",
                        "name": "TUI Dashboard",
                        "description": "Rich-powered terminal dashboard with live metrics",
                    },
                    {
                        "id": "dashboard-stats",
                        "name": "Dashboard Stats",
                        "description": "Render Python dashboard statistics without GUI or TUI",
                    },
                ],
            },
        ],
        "total_tests": 14,
    }

    if output_json:
        click.echo(json.dumps(tests, indent=2))
        return

    title = t_format("cli.list_tests.title", total=tests["total_tests"], module="cli")
    click.echo(title + "\n")
    for category in tests["categories"]:
        prefix = t("cli.list_tests.category_prefix", module="cli")
        click.echo(f"  {prefix} {category['name']}: {category['description']}")
        for test in category["tests"]:
            test_prefix = t("cli.list_tests.test_prefix", module="cli")
            click.echo(f"     {test_prefix} {test['name']} - {test['description']}")
        click.echo()


@click.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def show_config(output_json: bool) -> None:
    """Show effective configuration from ManifestGuard config and defaults."""

    def _get_default_config() -> dict[str, Any]:
        return {
            "extended_tests": {
                "enabled": True,
                "coverage": {"enabled": True, "threshold": 80},
                "dependencies": {"enabled": True},
                "security": {"enabled": True},
                "sbom": {"enabled": True, "format": "spdx"},
                "packaging": {"enabled": True, "threshold": 8},
                "performance": {"enabled": True},
                "policy": {"enabled": True, "allowed_packages": [], "blocked_packages": []},
                "license": {"enabled": True},
                "complexity": {"enabled": True, "threshold": 10},
            },
            "dummyRecognition": {"suppressions": []},
            "duplicationDetection": {
                "enabled": True,
                "includeTests": True,
                "windowLines": 12,
                "minOccurrences": 2,
                "maxFiles": 5000,
                "maxFileSizeBytes": 524288,
                "maxResults": 200,
            },
            "baseline": {"enabled": True, "labels": ["latest", "stable", "release"]},
            "output": {"report_format": "json", "report_path": "manifestguard-report.json"},
        }

    workspace_root = resolve_workspace_root()
    config_path = find_existing_config_path(workspace_root) or (workspace_root / "manifestguard.json")

    config = _load_user_config(config_path, _get_default_config())

    if output_json:
        click.echo(json.dumps(config, indent=2))
    else:
        _display_config_text(config, workspace_root, config_path)


def _load_user_config(config_path: Path, default_config: dict[str, Any]) -> dict[str, Any]:
    """Load and merge user config with defaults."""
    if not config_path.exists():
        return default_config

    try:
        user_config = json.loads(config_path.read_text())
        for key in user_config:
            if key in default_config:
                if isinstance(default_config[key], dict):
                    default_config[key].update(user_config[key])
                else:
                    default_config[key] = user_config[key]
    except json.JSONDecodeError:
        click.echo(t("cli.config.warning_invalid", module="cli"), err=True)

    return default_config


def _display_config_text(config: dict[str, Any], workspace_root: Path, config_path: Path) -> None:
    """Display configuration in text format."""
    click.echo(t("cli.show_config.title", module="cli") + "\n")
    click.echo(f"{t('cli.show_config.workspace_label', module='cli')} {workspace_root}")
    status = (
        t("cli.show_config.config_found", module="cli")
        if config_path.exists()
        else t("cli.show_config.config_not_found", module="cli")
    )
    click.echo(
        f"{t('cli.show_config.config_file_label', module='cli')} {config_path} {status}\n"
    )

    click.echo(t("cli.show_config.extended_tests_label", module="cli"))
    for test_name, test_config in config["extended_tests"].items():
        if test_name == "enabled":
            continue
        enabled = test_config.get("enabled", True) if isinstance(test_config, dict) else test_config
        status = (
            t("cli.show_config.test_enabled", module="cli")
            if enabled
            else t("cli.show_config.test_disabled", module="cli")
        )
        click.echo(f"  {status} {test_name}")
        if isinstance(test_config, dict):
            for key, value in test_config.items():
                if key != "enabled":
                    click.echo(f"      • {key}: {value}")


@click.command(name="schema")
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default="openapi.json",
    help="Output file path (default: openapi.json)",
)
@click.option(
    "--format",
    "format_",
    type=click.Choice(["json", "yaml"], case_sensitive=False),
    default="json",
    help="Output format: json or yaml (default: json)",
)
@click.option(
    "--title",
    type=str,
    default="ManifestGuard API",
    help="API title (default: ManifestGuard API)",
)
@click.option(
    "--api-version",
    type=str,
    default="1.0.0",
    help="API version (default: 1.0.0)",
)
def export_schema(output: str, format_: str, title: str, api_version: str) -> None:
    """Generate OpenAPI 3.0 schema from Pydantic models."""
    click.echo("📄 Generating OpenAPI schema...")

    try:
        generator = OpenAPIGenerator(title=title, version=api_version)
        output_path = Path(output)

        if format_.lower() == "yaml":
            generator.export_to_yaml(output_path)
        else:
            generator.export_to_file(output_path)

        click.echo(f"✅ Schema exported to: {output_path}")
        click.echo(f"   Format: {format_.upper()}")
        click.echo(f"   Title: {title}")
        click.echo(f"   Version: {api_version}")
        click.echo("\n💡 View with Swagger UI: https://editor.swagger.io")

    except ImportError as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Failed to generate schema: {e}", err=True)
        sys.exit(1)


@click.command()
def dashboard() -> None:
    """Launch interactive terminal dashboard."""
    workspace_root = resolve_workspace_root()

    try:
        from manifestguard.tui import run_dashboard  # noqa: PLC0415

        run_dashboard(workspace_root)
    except ImportError:
        click.echo("❌ Rich library required for dashboard. Install with: pip install rich", err=True)
        sys.exit(1)


@click.command("dashboard-stats")
@click.option(
    "--report",
    type=click.Path(path_type=Path),
    help="Optional report JSON path. Defaults to the latest known report in the workspace.",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json", "html"], case_sensitive=False),
    default="text",
    show_default=True,
    help="Output format for the dashboard statistics.",
)
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    help="Optional output file path. Without this option, data is printed to stdout.",
)
def dashboard_stats_command(
    report: Path | None,
    output_format: str,
    output: Path | None,
) -> None:
    """Render the new Python dashboard statistics without launching GUI or TUI."""
    workspace_root = resolve_workspace_root()
    report_path = report or _detect_default_report_path(workspace_root)

    if report_path is not None and not report_path.exists():
        raise click.UsageError(f"Report file not found: {report_path}")

    view_model = build_dashboard_stats_view_model(workspace_root, report_path)

    rendered: str
    if output_format == "json":
        rendered = json.dumps(asdict(view_model), indent=2, ensure_ascii=False) + "\n"
    elif output_format == "html":
        rendered = build_dashboard_stats_html(workspace_root, report_path)
    else:
        rendered = _render_dashboard_stats_text(view_model)

    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered, encoding="utf-8")
        click.echo(f"✅ Dashboard stats written to: {output}")
        if report_path is not None:
            click.echo(f"   Report source: {report_path}")
        return

    click.echo(rendered, nl=False)


@click.command("examples")
@click.option(
    "--type",
    "example_type",
    type=click.Choice(["config", "report", "history", "schema", "all"]),
    default="all",
    help="Type of example to show (default: all)",
)
@click.option(
    "--output",
    type=click.Path(),
    help="Write example to file instead of console",
)
def examples_command(example_type: str, output: str | None) -> None:
    """Show examples of configuration, reports, and schemas."""
    examples_map = {
        "config": ("manifestguard.json Configuration", get_example_config),
        "report": ("Report JSON Structure", get_example_report),
        "history": ("History JSON Structure", get_example_history),
        "schema": ("Metrics JSON Schema", get_example_metrics_schema),
    }

    if example_type == "all":
        if output:
            click.echo("❌ Cannot write all examples to a single file. Use --type to specify one.")
            return
        print_all_examples()
        return

    title, getter = examples_map[example_type]
    data = getter()

    if output:
        output_path = Path(output)
        output_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        click.echo(f"✅ {title} written to: {output}")
    else:
        click.echo("=" * 80)
        click.echo(f"EXAMPLE: {title}")
        click.echo("=" * 80)
        click.echo(json.dumps(data, indent=2))


@click.command("validate-views")
@click.option(
    "--target-dirs",
    multiple=True,
    help="Directories to scan (default: src/manifestguard/extended/tui, src/templates)",
)
@click.option(
    "--ignore",
    multiple=True,
    help="Patterns to ignore (default: tests/**, docs/**, examples/**)",
)
@click.option(
    "--rules",
    help="Comma-separated list of rules to enable (default: all)",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["console", "json"]),
    default="console",
    help="Output format",
)
def validate_views_command(
    target_dirs: tuple[str, ...],
    ignore: tuple[str, ...],
    rules: str | None,
    output_format: str,
) -> None:
    """Validate view registration and HTML hygiene."""
    enabled_rules = set(rules.split(",")) if rules else None

    results = run_validate_views(
        target_dirs=list(target_dirs) if target_dirs else None,
        ignore_patterns=list(ignore) if ignore else None,
        enabled_rules=enabled_rules,
    )

    if output_format == "json":
        output_data = {
            "tool": "manifestguard-validate-views",
            "version": __version__,
            "timestamp": datetime.now().isoformat(),
            "violations": [
                {
                    "rule": v.rule,
                    "file": str(v.file),
                    "line": v.line,
                    "column": v.column,
                    "message": v.message,
                    "severity": v.severity,
                }
                for violations in results.values()
                for v in violations
            ],
            "summary": {
                "total": sum(len(v) for v in results.values()),
                "by_rule": {rule: len(violations) for rule, violations in results.items()},
            },
        }
        click.echo(json.dumps(output_data, indent=2))
    else:
        click.echo(format_violations(results))

    if results:
        sys.exit(2)


def register(cli: click.Group) -> None:
    cli.add_command(init_config)
    cli.add_command(list_interfaces)
    cli.add_command(list_tests)
    cli.add_command(show_config)
    cli.add_command(export_schema)
    cli.add_command(dashboard)
    cli.add_command(dashboard_stats_command)
    cli.add_command(examples_command)
    cli.add_command(validate_views_command)
