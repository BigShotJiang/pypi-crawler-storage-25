"""Guide command registration for local/offline ManifestGuard help."""

from __future__ import annotations

import json
import webbrowser

import click

from manifestguard.guide_catalog import (
    build_online_guide_url,
    list_guides,
    render_guide_document,
    render_guide_markdown,
    render_guide_text,
)


@click.command(name="guide")
@click.argument("slug", required=False)
@click.option("--list", "list_only", is_flag=True, help="List available local guides for the current runtime.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "markdown", "json"], case_sensitive=False),
    default="text",
    show_default=True,
    help="Output format for the guide content.",
)
@click.option(
    "--version-context",
    default=None,
    metavar="MAJOR.MINOR",
    help="Override the local guide catalog version context (for example 1.6).",
)
@click.option("--online", is_flag=True, help="Open the online guide in the default browser.")
def guide_command(
    slug: str | None,
    list_only: bool,
    output_format: str,
    version_context: str | None,
    online: bool,
) -> None:
    """Show local versioned help for a guide slug."""
    if list_only:
        guides = list_guides(runtime_version=version_context)
        if output_format == "json":
            click.echo(
                json.dumps(
                    {
                        "guides": [guide.to_dict(include_content=False) for guide in guides],
                    },
                    indent=2,
                    ensure_ascii=False,
                )
            )
            return

        click.echo("Available local ManifestGuard guides:")
        for guide in guides:
            click.echo(f"- {guide.slug}: {guide.title} ({guide.local_command})")
        return

    if not slug:
        raise click.UsageError("Provide a guide slug or use --list.")

    try:
        document = render_guide_document(slug, runtime_version=version_context, version_context=version_context)
    except KeyError as exc:
        raise click.UsageError(f"Unknown guide slug: {slug}") from exc

    if online:
        webbrowser.open(document.online_url)
        click.echo(document.online_url)
        return

    if output_format == "json":
        click.echo(json.dumps(document.to_dict(include_content=True), indent=2, ensure_ascii=False))
        return
    if output_format == "markdown":
        click.echo(render_guide_markdown(slug, runtime_version=version_context, version_context=version_context))
        return

    click.echo(render_guide_text(slug, runtime_version=version_context, version_context=version_context))


def register(cli: click.core.Group) -> None:
    cli.add_command(guide_command)