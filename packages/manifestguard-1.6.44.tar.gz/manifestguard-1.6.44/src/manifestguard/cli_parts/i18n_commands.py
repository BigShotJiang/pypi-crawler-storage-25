from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from manifestguard.i18n import t, t_format


def _safe_one_line(value: str) -> str:
    # Avoid multi-line spam in CLI output.
    return " ".join((value or "").split())


@click.command(
    name="check-hardcoded-strings",
    help=t("cli.help.check_hardcoded_strings", module="cli"),
)
@click.option(
    "--format",
    "format_",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    show_default=True,
    help=t("cli.options.hardcoded_strings_output_format", module="cli"),
)
@click.option(
    "--max-findings",
    type=int,
    default=200,
    show_default=True,
    help=t("cli.options.hardcoded_strings_max_findings", module="cli"),
)
@click.option(
    "--no-fail",
    is_flag=True,
    default=False,
    help=t("cli.options.hardcoded_strings_no_fail", module="cli"),
)
def check_hardcoded_strings(format_: str, max_findings: int, no_fail: bool) -> None:
    """Detect hardcoded GUI strings in Python GUI sources.

    Notes:
        This command currently scans GUI sources (src/gui/**/*.py). The core
        scanner is also surfaced via Extended Test Mode policy metrics.
    """

    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.extended.hardcoded_gui_strings import (
        load_hardcoded_gui_strings_config_from_manifestguard_json,
        scan_hardcoded_gui_strings,
    )

    workspace_root: Path = _resolve_workspace_root()

    cfg = load_hardcoded_gui_strings_config_from_manifestguard_json(workspace_root)
    if not cfg.enabled:
        if format_.lower() == "json":
            payload: dict[str, Any] = {
                "schemaVersion": "1.0.0",
                "scope": "gui",
                "enabled": False,
                "summary": {
                    "total_findings": 0,
                    "unique_strings": 0,
                    "scanned_files": 0,
                    "printed_findings": 0,
                },
                "findings": [],
            }
            click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
        else:
            click.echo(t("cli.hardcoded_strings.title", module="cli"))
            click.echo(t("cli.hardcoded_strings.disabled", module="cli"))
        raise SystemExit(0)

    result = scan_hardcoded_gui_strings(workspace_root, cfg)

    findings = list(result.findings[: max(0, int(max_findings))])

    if format_.lower() == "json":
        payload: dict[str, Any] = {
            "schemaVersion": "1.0.0",
            "scope": "gui",
            "enabled": True,
            "summary": {
                "total_findings": result.total_findings,
                "unique_strings": result.unique_strings,
                "scanned_files": result.scanned_files,
                "printed_findings": len(findings),
            },
            "findings": findings,
        }
        click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        click.echo(t("cli.hardcoded_strings.title", module="cli"))
        click.echo(t("cli.hardcoded_strings.scanning", module="cli"))

        if result.total_findings == 0:
            click.echo(t("cli.hardcoded_strings.none_found", module="cli"))
        else:
            click.echo(
                t_format(
                    "cli.hardcoded_strings.found",
                    count=result.total_findings,
                    files=result.scanned_files,
                    module="cli",
                )
            )

            for f in findings:
                code = _safe_one_line(str(f.get("code") or ""))
                file = _safe_one_line(str(f.get("file") or ""))
                line = f.get("line")
                kind = _safe_one_line(str(f.get("kind") or ""))
                value = _safe_one_line(str(f.get("value") or ""))

                click.echo(f"  [{code}] {file}:{line} {kind}: {value}")

                suggested = f.get("suggestedReplacement")
                if suggested:
                    click.echo(f"      -> {suggested}")

            click.echo(t("cli.hardcoded_strings.hint", module="cli"))

    if result.total_findings > 0 and not no_fail:
        raise SystemExit(3)


@click.command(
    name="check-hardcoded-cli-strings",
    help=t("cli.help.check_hardcoded_cli_strings", module="cli"),
)
@click.option(
    "--format",
    "format_",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    show_default=True,
    help=t("cli.options.hardcoded_cli_strings_output_format", module="cli"),
)
@click.option(
    "--max-findings",
    type=int,
    default=200,
    show_default=True,
    help=t("cli.options.hardcoded_cli_strings_max_findings", module="cli"),
)
@click.option(
    "--no-fail",
    is_flag=True,
    default=False,
    help=t("cli.options.hardcoded_cli_strings_no_fail", module="cli"),
)
def check_hardcoded_cli_strings(format_: str, max_findings: int, no_fail: bool) -> None:
    """Detect hardcoded CLI strings in Python sources."""

    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.extended.hardcoded_cli_strings import (
        load_hardcoded_cli_strings_config_from_manifestguard_json,
        scan_hardcoded_cli_strings,
    )

    workspace_root: Path = _resolve_workspace_root()

    cfg = load_hardcoded_cli_strings_config_from_manifestguard_json(workspace_root)
    if not cfg.enabled:
        if format_.lower() == "json":
            payload: dict[str, Any] = {
                "schemaVersion": "1.0.0",
                "scope": "cli",
                "enabled": False,
                "summary": {
                    "total_findings": 0,
                    "unique_strings": 0,
                    "scanned_files": 0,
                    "printed_findings": 0,
                },
                "findings": [],
            }
            click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
        else:
            click.echo(t("cli.hardcoded_cli_strings.title", module="cli"))
            click.echo(t("cli.hardcoded_cli_strings.disabled", module="cli"))
        raise SystemExit(0)

    result = scan_hardcoded_cli_strings(workspace_root, cfg)
    findings = list(result.findings[: max(0, int(max_findings))])

    if format_.lower() == "json":
        payload = {
            "schemaVersion": "1.0.0",
            "scope": "cli",
            "enabled": True,
            "summary": {
                "total_findings": result.total_findings,
                "unique_strings": result.unique_strings,
                "scanned_files": result.scanned_files,
                "printed_findings": len(findings),
            },
            "findings": findings,
        }
        click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        click.echo(t("cli.hardcoded_cli_strings.title", module="cli"))
        click.echo(t("cli.hardcoded_cli_strings.scanning", module="cli"))

        if result.total_findings == 0:
            click.echo(t("cli.hardcoded_cli_strings.none_found", module="cli"))
        else:
            click.echo(
                t_format(
                    "cli.hardcoded_cli_strings.found",
                    count=result.total_findings,
                    files=result.scanned_files,
                    module="cli",
                )
            )

            for f in findings:
                code = _safe_one_line(str(f.get("code") or ""))
                file = _safe_one_line(str(f.get("file") or ""))
                line = f.get("line")
                kind = _safe_one_line(str(f.get("kind") or ""))
                value = _safe_one_line(str(f.get("value") or ""))

                click.echo(f"  [{code}] {file}:{line} {kind}: {value}")

                suggested = f.get("suggestedReplacement")
                if suggested:
                    click.echo(f"      -> {suggested}")

            click.echo(t("cli.hardcoded_cli_strings.hint", module="cli"))

    if result.total_findings > 0 and not no_fail:
        raise SystemExit(3)


def register(cli: click.Group) -> None:
    cli.add_command(check_hardcoded_strings)
    cli.add_command(check_hardcoded_cli_strings)
