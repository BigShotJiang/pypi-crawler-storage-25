from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

import click

from manifestguard.extended.metrics_history_export import resolve_history_file_path


@click.command("venv-health-weekly")
@click.option(
    "--history-file",
    type=click.Path(exists=True, path_type=Path),
    help="Path to metrics history (default: auto-resolve .mgpy/metrics/ or legacy locations)",
)
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    help="Export weekly summary to JSON file",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output in JSON format to console",
)
def venv_health_weekly(
    history_file: Path | None,
    output: Path | None,
    output_json: bool,
) -> None:
    """Reconstruct weekly venv health aggregates from metrics history."""
    from manifestguard.extended.venv_health_weekly import (
        calculate_multi_week_health_trend,
        export_weekly_venv_health_json,
        format_weekly_venv_health_summary,
        reconstruct_weekly_venv_health,
    )

    if history_file is None:
        history_file = resolve_history_file_path(Path.cwd(), create_if_missing=False)

    if history_file is None or not history_file.exists():
        if output_json:
            click.echo(
                json.dumps(
                    {
                        "success": False,
                        "error": "history_file_not_found",
                        "message": f"History file not found: {history_file}",
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ History file not found: {history_file}")
            click.echo("\n💡 Generate venv health metrics with: manifestguard venv-health-track")
        sys.exit(2)

    try:
        weekly_aggregates = reconstruct_weekly_venv_health(history_file)

        if not weekly_aggregates:
            if output_json:
                click.echo(
                    json.dumps(
                        {
                            "success": True,
                            "weekly_aggregates": {},
                            "message": "No weekly venv health data found in history",
                        },
                        indent=2,
                    )
                )
            else:
                click.echo("⚠️  No weekly venv health data found in history")
            return

        if output:
            export_weekly_venv_health_json(weekly_aggregates, output)
            if not output_json:
                click.echo(f"✅ Weekly venv health summary exported to: {output}")

        if output_json:
            multi_trend = calculate_multi_week_health_trend(weekly_aggregates)
            click.echo(
                json.dumps(
                    {
                        "success": True,
                        "history_file": str(history_file),
                        "weekly_aggregates": weekly_aggregates,
                        "multi_week_trend": multi_trend,
                        "summary": {
                            "total_weeks": len(weekly_aggregates),
                            "weeks": sorted(weekly_aggregates.keys()),
                        },
                    },
                    indent=2,
                )
            )
        else:
            click.echo(format_weekly_venv_health_summary(weekly_aggregates))
            click.echo(f"\n📁 History: {history_file}")

    except Exception as e:
        if output_json:
            click.echo(
                json.dumps(
                    {"success": False, "error": "exception", "message": str(e)},
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ Error reconstructing weekly venv health: {e}")
        sys.exit(1)


@click.command("venv-health-track")
@click.option(
    "--venv",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    required=True,
    help="Path to virtual environment directory",
)
@click.option(
    "--workspace",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    help="Workspace root directory (default: current directory)",
)
@click.option(
    "--auto-fix",
    is_flag=True,
    help="Apply safe fixes (e.g., remove dead PIDs from registry)",
)
@click.option(
    "--timeout",
    type=float,
    default=30.0,
    help="Timeout in seconds (default: 30)",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output in JSON format",
)
def venv_health_track(
    venv: Path,
    workspace: Path | None,
    auto_fix: bool,
    timeout: float,
    output_json: bool,
) -> None:
    """Run venv preflight and persist health metrics to history."""
    from manifestguard.orchestration.venv_wizard_adapter import (
        run_venv_wizard_preflight,
        summarize_health_payload,
    )
    from manifestguard.extended.metrics_history_export import add_venv_health_to_history

    workspace_root = workspace or Path.cwd()

    if sys.platform == "win32":
        python_exe = venv / "Scripts" / "python.exe"
    else:
        python_exe = venv / "bin" / "python"

    if not python_exe.exists():
        if output_json:
            click.echo(
                json.dumps(
                    {
                        "success": False,
                        "error": "invalid_venv",
                        "message": f"Python executable not found: {python_exe}",
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ Python executable not found: {python_exe}")
        sys.exit(1)

    try:
        result = run_venv_wizard_preflight(
            python_exe=str(python_exe),
            project_root=workspace_root,
            workspace=str(workspace_root),
            auto_fix=auto_fix,
            timeout_seconds=timeout,
        )
    except subprocess.TimeoutExpired:
        if output_json:
            click.echo(
                json.dumps(
                    {
                        "success": False,
                        "error": "timeout",
                        "message": f"Preflight timed out after {timeout:.1f}s",
                        "timeoutSeconds": timeout,
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ Preflight timed out after {timeout:.1f}s")
        sys.exit(124)

    payload = result.payload
    if payload is None:
        if output_json:
            click.echo(
                json.dumps(
                    {
                        "success": False,
                        "error": "invalid_json",
                        "exitCode": result.exit_code,
                        "stdout": result.stdout,
                        "stderr": result.stderr,
                    },
                    indent=2,
                )
            )
        else:
            click.echo("❌ Invalid JSON payload from worker tool")
        sys.exit(1)

    try:
        venv_path_rel = str(venv.resolve().relative_to(workspace_root.resolve()))
    except Exception:
        venv_path_rel = venv.name

    summary: dict[str, Any] = summarize_health_payload(payload)
    summary["venvPath"] = venv_path_rel

    success = add_venv_health_to_history(workspace_root, summary)

    if output_json:
        history_path = resolve_history_file_path(workspace_root, create_if_missing=False)
        click.echo(
            json.dumps(
                {
                    "success": success,
                    "venvHealth": summary,
                    "historyFile": str(history_path) if history_path else None,
                },
                indent=2,
            )
        )
    else:
        if success:
            click.echo(f"✅ Venv health tracked: {summary['venvPath']}")
            click.echo(f"   Status: {summary['status']}")
            click.echo(
                f"   Zombies: {summary.get('zombie')}, "
                f"Dead: {summary.get('dead')}"
            )
            history_path = resolve_history_file_path(workspace_root, create_if_missing=False)
            if history_path:
                click.echo(f"   History: {history_path}")
        else:
            click.echo("❌ Failed to persist venv health to history")
            sys.exit(1)
