"""Focused standalone analysis commands.

Provides ``security``, ``quality``, and ``license-check`` as top-level commands
that run only the relevant metric category instead of the full extended analysis
pipeline.  Each command is gated by the appropriate license feature.

These commands replace the current ``check --extended --fail-on-security``
bridge approach and give MGVS dedicated, fast entry-points.

MGVS mapping (pythonTestExecutor.ts):
  SECURITY          -> ``manifestguard security``
  QUALITY           -> ``manifestguard quality``
  LICENSE_COMPLIANCE -> ``manifestguard license-check``
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from pathlib import Path
from typing import Any

import click

from manifestguard import __version__, get_runtime_version
from manifestguard.i18n import t

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _banner(title: str) -> None:
    click.echo("━" * 60)
    click.echo(f"🛡️  ManifestGuard — {title}")
    click.echo(f"   version: {get_runtime_version()}")
    click.echo("━" * 60 + "\n")


def _check_license(feature: str, tier_label: str) -> bool:
    """Return True if the feature is available; print gate message otherwise."""
    from manifestguard.cli import _has_license_feature, _license_tier_label

    if not _has_license_feature(feature):
        click.echo(f"\n🔒 This command requires a {tier_label} (or higher) license.")
        click.echo(f"   Current tier: {_license_tier_label()}.")
        click.echo("   Run `manifestguard license activate` to upgrade.")
        return False
    return True


def _resolve_root() -> Path:
    from manifestguard.cli import _resolve_workspace_root

    return _resolve_workspace_root()


def _write_report(report_path: str | None, data: dict[str, Any], workspace_root: Path) -> None:
    if not report_path:
        return
    p = Path(report_path)
    if not p.is_absolute():
        p = workspace_root / p
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    click.echo(f"\n📄 Report saved: {p}")


def _has_security_findings(sec: Any) -> bool:
    """Return True if any security indicator has findings."""
    int_fields = [
        "unsafe_exec_count",
        "hardcoded_secrets",
        "hardcoded_paths",
        "subprocess_shell_true",
        "unsafe_deserialization",
        "tls_verify_disabled",
        "insecure_tempfile",
        "wheel_content_issues",
        "supply_chain_vulnerabilities",
    ]
    list_fields = ["weak_crypto", "insecure_permissions", "supply_chain_findings"]
    for f in int_fields:
        if getattr(sec, f, 0) > 0:
            return True
    for f in list_fields:
        if getattr(sec, f, []):
            return True
    return False


# ---------------------------------------------------------------------------
# ``security`` command
# ---------------------------------------------------------------------------

@click.command(name="security")
@click.option(
    "--report",
    type=click.Path(),
    default=None,
    help="Save findings to JSON file.",
)
@click.option(
    "--no-fail",
    is_flag=True,
    default=False,
    help="Exit 0 even when findings are detected (for informational runs).",
)
@click.option("--verbose", "-v", is_flag=True, default=False, help="Show detailed findings.")
def security_command(report: str | None, no_fail: bool, verbose: bool) -> None:
    """Run security analysis only (static scan + supply chain CVE check).

    Exits 0 when clean, 1 when findings detected (unless --no-fail), 2 on error.

    Requires Pro (or higher) license: feature ``cve_checks``.
    """
    _banner("Security Analysis")

    if not _check_license("cve_checks", "Pro"):
        sys.exit(2)

    workspace_root = _resolve_root()

    try:
        from manifestguard.extended.metrics import MetricsCollector
        from manifestguard.core.test_config_helper import load_manifest_config

        config = load_manifest_config(workspace_root)

        click.echo("🔍 Running security scan…")

        collector = MetricsCollector(workspace_root, config=config)

        async def _run() -> Any:
            from manifestguard.extended.metrics import SecurityMetrics, ExtendedTestMetrics
            from datetime import datetime, timezone

            metrics = ExtendedTestMetrics(timestamp=datetime.now(timezone.utc).isoformat())
            await collector._step_security(metrics, progress=_progress_echo)
            return metrics.security

        sec = asyncio.run(_run())

        _print_security_results(sec, verbose=verbose)

        if report:
            _write_report(report, {"security": _sec_to_dict(sec)}, workspace_root)

        has_findings = _has_security_findings(sec)
        if has_findings:
            click.echo("\n❌ Security findings detected.")
            if not no_fail:
                sys.exit(1)
        else:
            click.echo("\n✅ No security issues detected.")

    except Exception as exc:
        logger.error("Security command failed: %s", exc)
        click.echo(f"\n💥 Security scan error: {exc}", err=True)
        sys.exit(2)


def _progress_echo(msg: str) -> None:
    click.echo(f"   {msg}")


def _sec_to_dict(sec: Any) -> dict[str, Any]:
    try:
        return sec.__dict__.copy()
    except Exception:
        return {}


def _print_security_results(sec: Any, *, verbose: bool) -> None:
    click.echo("\n📊 Security Scan Results:")

    int_findings = {
        "Unsafe exec (eval/exec)": ("unsafe_exec_count", "SEC-UNSAFE-EXEC"),
        "Hardcoded secrets":       ("hardcoded_secrets", "SEC-SECRET"),
        "Hardcoded paths":         ("hardcoded_paths",   "SEC-PATH"),
        "subprocess shell=True":   ("subprocess_shell_true", "SEC-SHELL"),
        "Unsafe deserialization":  ("unsafe_deserialization", "SEC-DESER"),
        "TLS verify disabled":     ("tls_verify_disabled", "SEC-TLS"),
        "Insecure tempfile":       ("insecure_tempfile", "SEC-TMPFILE"),
        "Wheel content issues":    ("wheel_content_issues", "SEC-WHEEL"),
        "Supply chain CVEs":       ("supply_chain_vulnerabilities", "SEC-CVE"),
    }

    any_finding = False
    for label, (attr, _) in int_findings.items():
        count = getattr(sec, attr, 0)
        if count > 0:
            click.echo(f"   ⚠️  {label}: {count}")
            any_finding = True
        elif verbose:
            click.echo(f"   ✅ {label}: 0")

    weak_crypto = getattr(sec, "weak_crypto", [])
    if weak_crypto:
        any_finding = True
        click.echo(f"   ⚠️  Weak crypto: {len(weak_crypto)} file(s)")
        if verbose:
            for f in weak_crypto[:5]:
                click.echo(f"      — {f}")

    insecure_perms = getattr(sec, "insecure_permissions", [])
    if insecure_perms:
        any_finding = True
        click.echo(f"   ⚠️  Insecure permissions: {len(insecure_perms)} file(s)")
        if verbose:
            for f in insecure_perms[:5]:
                click.echo(f"      — {f}")

    sc_findings = getattr(sec, "supply_chain_findings", [])
    if sc_findings and verbose:
        click.echo(f"   Supply chain details ({len(sc_findings)} entries):")
        for entry in sc_findings[:5]:
            click.echo(f"      — {entry}")

    if not any_finding and not verbose:
        click.echo("   ✅ All checks clean.")


# ---------------------------------------------------------------------------
# ``quality`` command
# ---------------------------------------------------------------------------

@click.command(name="quality")
@click.option(
    "--report",
    type=click.Path(),
    default=None,
    help="Save results to JSON file.",
)
@click.option("--verbose", "-v", is_flag=True, default=False, help="Show top violations.")
@click.option(
    "--fail-on-violations",
    is_flag=True,
    default=False,
    help="Exit 1 when complexity violations are detected.",
)
def quality_command(report: str | None, verbose: bool, fail_on_violations: bool) -> None:
    """Run quality analysis only (complexity, duplication, dummy-code detection).

    No security or license overhead.  Available on all tiers (community/free and up).
    """
    _banner("Quality Analysis")

    workspace_root = _resolve_root()

    try:
        from manifestguard.extended.metrics import (
            ComplexityMetrics,
            PolicyMetrics,
            ExtendedTestMetrics,
            MetricsCollector,
        )
        from manifestguard.core.test_config_helper import load_manifest_config

        config = load_manifest_config(workspace_root)

        click.echo("🔍 Running quality scan…")

        collector = MetricsCollector(workspace_root, config=config)

        async def _run() -> tuple[Any, Any]:
            from datetime import datetime, timezone

            metrics = ExtendedTestMetrics(timestamp=datetime.now(timezone.utc).isoformat())
            await collector._step_complexity(metrics, progress=_progress_echo)
            await collector._step_policy(metrics, progress=_progress_echo)
            return metrics.complexity, metrics.policy

        complexity, policy = asyncio.run(_run())

        _print_quality_results(complexity, policy, verbose=verbose)

        if report:
            report_data = {
                "quality": {
                    "complexity": complexity.__dict__.copy() if complexity else {},
                    "dummy_code": {
                        k: getattr(policy, k)
                        for k in policy.__dict__
                        if k.startswith("dummy_code") or k.startswith("duplication")
                    },
                }
            }
            _write_report(report, report_data, workspace_root)

        violations = getattr(complexity, "violations_count", 0)
        if violations > 0 and fail_on_violations:
            click.echo(f"\n❌ Quality gate: {violations} complexity violation(s).")
            sys.exit(1)
        elif violations > 0:
            click.echo(f"\n⚠️  {violations} complexity violation(s) detected.")
        else:
            click.echo("\n✅ Quality checks passed.")

    except Exception as exc:
        logger.error("Quality command failed: %s", exc)
        click.echo(f"\n💥 Quality scan error: {exc}", err=True)
        sys.exit(2)


def _print_quality_results(complexity: Any, policy: Any, *, verbose: bool) -> None:
    click.echo("\n📊 Quality Scan Results:")

    violations = getattr(complexity, "violations_count", 0)
    avg = getattr(complexity, "average_complexity", 0.0)
    threshold = getattr(complexity, "threshold", 10)
    files_scanned = getattr(complexity, "files_scanned", 0)

    click.echo(f"   Complexity threshold:  {threshold}")
    click.echo(f"   Files scanned:         {files_scanned}")
    click.echo(f"   Average complexity:    {avg:.1f}")
    click.echo(f"   Violations (>{threshold}):    {violations}")

    if verbose:
        top = getattr(complexity, "top_violations", [])
        if top:
            click.echo("\n   Top violations:")
            for v in top[:8]:
                file_ = v.get("file", "?")
                name_ = v.get("name", "?")
                score = v.get("value", v.get("complexity", "?"))
                click.echo(f"      [{score}] {file_}::{name_}")

    dummy_total = getattr(policy, "dummy_code_total_findings", 0)
    if dummy_total > 0:
        click.echo(f"\n   ⚠️  Dummy/placeholder code: {dummy_total} finding(s)")
        if verbose:
            for s in getattr(policy, "dummy_code_findings_sample", [])[:4]:
                click.echo(f"      — {s.get('file', '?')}:{s.get('line', '?')} {s.get('type', '')}")
    elif verbose:
        click.echo("   ✅ No dummy/placeholder code detected.")

    dup = getattr(policy, "duplication", {})
    dup_pct = dup.get("duplication_percent", dup.get("percent", None))
    if dup_pct is not None:
        icon = "⚠️ " if dup_pct > 5.0 else "✅"
        click.echo(f"\n   {icon} Code duplication: {dup_pct:.1f}%")


# ---------------------------------------------------------------------------
# ``license-check`` command
# ---------------------------------------------------------------------------

@click.command(name="license-check")
@click.option(
    "--report",
    type=click.Path(),
    default=None,
    help="Save results to JSON file.",
)
@click.option("--verbose", "-v", is_flag=True, default=False, help="Show SPDX details.")
@click.option(
    "--fail-on-issues",
    is_flag=True,
    default=False,
    help="Exit 1 when license issues are detected.",
)
def license_check_command(report: str | None, verbose: bool, fail_on_issues: bool) -> None:
    """Run license compliance scan only (SPDX consistency, missing license file).

    Requires Pro (or higher) license: feature ``license_compliance``.
    Note: ``license_compliance`` maps to ``extended_analysis`` in code; Pro tier
    includes both.
    """
    _banner("License Compliance Check")

    if not _check_license("extended_analysis", "Pro"):
        sys.exit(2)

    workspace_root = _resolve_root()

    try:
        from manifestguard.extended.metrics import (
            LicenseMetrics,
            ExtendedTestMetrics,
            MetricsCollector,
        )
        from manifestguard.core.test_config_helper import load_manifest_config

        config = load_manifest_config(workspace_root)

        click.echo("🔍 Running license compliance scan…")

        collector = MetricsCollector(workspace_root, config=config)

        async def _run() -> Any:
            from datetime import datetime, timezone

            metrics = ExtendedTestMetrics(timestamp=datetime.now(timezone.utc).isoformat())
            await collector._step_license(metrics, progress=_progress_echo)
            return metrics.license

        lic = asyncio.run(_run())

        _print_license_results(lic, verbose=verbose)

        if report:
            _write_report(
                report,
                {"license": lic.__dict__.copy()},
                workspace_root,
            )

        has_issues = (
            bool(getattr(lic, "spdx_mismatches", []))
            or getattr(lic, "license_file_missing", False)
            or bool(getattr(lic, "conflicting_notices", []))
        )
        if has_issues and fail_on_issues:
            click.echo("\n❌ License compliance issues detected.")
            sys.exit(1)
        elif has_issues:
            click.echo("\n⚠️  License compliance issues detected.")
        else:
            click.echo("\n✅ License compliance clean.")

    except Exception as exc:
        logger.error("License-check command failed: %s", exc)
        click.echo(f"\n💥 License scan error: {exc}", err=True)
        sys.exit(2)


def _print_license_results(lic: Any, *, verbose: bool) -> None:
    click.echo("\n📊 License Compliance Results:")

    missing = getattr(lic, "license_file_missing", False)
    mismatches = getattr(lic, "spdx_mismatches", [])
    conflicts = getattr(lic, "conflicting_notices", [])

    if missing:
        click.echo("   ❌ License file missing (LICENSE / COPYING / LICENSE.txt).")
    else:
        click.echo("   ✅ License file present.")

    if mismatches:
        click.echo(f"   ⚠️  SPDX mismatches: {len(mismatches)}")
        if verbose:
            for m in mismatches[:5]:
                click.echo(f"      — {m}")
    else:
        click.echo("   ✅ No SPDX mismatches.")

    if conflicts:
        click.echo(f"   ⚠️  Conflicting license notices: {len(conflicts)}")
        if verbose:
            for c in conflicts[:5]:
                click.echo(f"      — {c}")
    elif verbose:
        click.echo("   ✅ No conflicting notices.")
