"""OpenAPI Schema Generator

Generates OpenAPI 3.0 schema from Pydantic models for API documentation.
"""

import json
from pathlib import Path
from typing import Any

from manifestguard.models import (
    BaseResponse,
    ConfigRequest,
    ConfigResponse,
    ConfigTemplate,
    DiagnosticModel,
    EnvironmentCreate,
    EnvironmentListResponse,
    EnvironmentResponse,
    EnvironmentUpdate,
    ErrorResponse,
    MetricsReport,
    MetricsResponse,
    SuccessResponse,
    ValidationRequest,
    ValidationResponse,
    ValidationResult,
)


class OpenAPIGenerator:
    """Generate OpenAPI 3.0 schema from Pydantic models"""

    def __init__(self, title: str = "ManifestGuard API", version: str = "1.0.0"):
        self.title = title
        self.version = version

    def generate_schema(self) -> dict[str, Any]:
        """Generate complete OpenAPI 3.0 schema"""
        # Collect all model schemas
        schemas = self._collect_model_schemas()

        return {
            "openapi": "3.0.3",
            "info": {
                "title": self.title,
                "version": self.version,
                "description": "ManifestGuard API for Python package manifest validation",
                "contact": {
                    "name": "ManifestGuard Support",
                    "url": "https://github.com/timejunky/r4it_manifest_guard_py",
                },
                "license": {"name": "Proprietary", "url": "https://ready-4-it.de/license"},
            },
            "servers": [
                {"url": "http://localhost:8000", "description": "Local development server"},
                {"url": "https://api.manifestguard.com", "description": "Production API"},
            ],
            "paths": self._generate_paths(),
            "components": {"schemas": schemas},
            "tags": [
                {
                    "name": "validation",
                    "description": "Manifest validation operations",
                },
                {
                    "name": "environments",
                    "description": "Environment management operations",
                },
                {
                    "name": "metrics",
                    "description": "Code quality metrics operations",
                },
                {
                    "name": "config",
                    "description": "Configuration management operations",
                },
            ],
        }

    def _collect_model_schemas(self) -> dict[str, Any]:
        """Collect JSON schemas from all Pydantic models"""
        models = [
            BaseResponse,
            SuccessResponse,
            ErrorResponse,
            EnvironmentCreate,
            EnvironmentUpdate,
            EnvironmentResponse,
            EnvironmentListResponse,
            DiagnosticModel,
            ValidationRequest,
            ValidationResult,
            ValidationResponse,
            MetricsReport,
            MetricsResponse,
            ConfigRequest,
            ConfigTemplate,
            ConfigResponse,
        ]

        schemas = {}
        for model in models:
            schema = model.model_json_schema()  # type: ignore[attr-defined]
            # Remove title to avoid duplication
            schema.pop("title", None)
            schemas[model.__name__] = schema

        # Manually add enum schema (doesn't have model_json_schema)
        schemas["DiagnosticSeverity"] = {
            "type": "string",
            "enum": ["error", "warning", "info"],
            "description": "Diagnostic severity levels",
        }

        return schemas

    def _generate_paths(self) -> dict[str, Any]:
        """Generate API paths/endpoints"""
        return {
            "/api/v1/environments": {
                "get": {
                    "tags": ["environments"],
                    "summary": "List all environments",
                    "operationId": "listEnvironments",
                    "responses": {
                        "200": {
                            "description": "List of environments",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "$ref": "#/components/schemas/EnvironmentListResponse"
                                    },
                                },
                            },
                        },
                    },
                },
                "post": {
                    "tags": ["environments"],
                    "summary": "Create new environment",
                    "operationId": "createEnvironment",
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/EnvironmentCreate"},
                            },
                        },
                    },
                    "responses": {
                        "201": {
                            "description": "Environment created",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/EnvironmentResponse"},
                                },
                            },
                        },
                        "422": {
                            "description": "Validation error",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                                },
                            },
                        },
                    },
                },
            },
            "/api/v1/environments/{environment_id}": {
                "get": {
                    "tags": ["environments"],
                    "summary": "Get environment by ID",
                    "operationId": "getEnvironment",
                    "parameters": [
                        {
                            "name": "environment_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                            "description": "Environment ID",
                        },
                    ],
                    "responses": {
                        "200": {
                            "description": "Environment details",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/EnvironmentResponse"},
                                },
                            },
                        },
                        "404": {
                            "description": "Environment not found",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                                },
                            },
                        },
                    },
                },
                "put": {
                    "tags": ["environments"],
                    "summary": "Update environment",
                    "operationId": "updateEnvironment",
                    "parameters": [
                        {
                            "name": "environment_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                    ],
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/EnvironmentUpdate"},
                            },
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Environment updated",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/EnvironmentResponse"},
                                },
                            },
                        },
                        "404": {
                            "description": "Environment not found",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                                },
                            },
                        },
                    },
                },
                "delete": {
                    "tags": ["environments"],
                    "summary": "Delete environment",
                    "operationId": "deleteEnvironment",
                    "parameters": [
                        {
                            "name": "environment_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                    ],
                    "responses": {
                        "204": {"description": "Environment deleted"},
                        "404": {
                            "description": "Environment not found",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                                },
                            },
                        },
                    },
                },
            },
            "/api/v1/validate": {
                "post": {
                    "tags": ["validation"],
                    "summary": "Validate manifest files",
                    "operationId": "validateManifest",
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/ValidationRequest"},
                            },
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Validation completed",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ValidationResponse"},
                                },
                            },
                        },
                        "422": {
                            "description": "Invalid request",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                                },
                            },
                        },
                    },
                },
            },
            "/api/v1/metrics": {
                "post": {
                    "tags": ["metrics"],
                    "summary": "Generate code metrics",
                    "operationId": "generateMetrics",
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "project_path": {
                                            "type": "string",
                                            "description": "Path to project root",
                                        },
                                    },
                                    "required": ["project_path"],
                                },
                            },
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Metrics generated",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/MetricsResponse"},
                                },
                            },
                        },
                    },
                },
            },
            "/api/v1/config/generate": {
                "post": {
                    "tags": ["config"],
                    "summary": "Generate configuration",
                    "operationId": "generateConfig",
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/ConfigRequest"},
                            },
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Configuration generated",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ConfigResponse"},
                                },
                            },
                        },
                    },
                },
            },
        }

    def export_to_file(self, output_path: Path) -> None:
        """Export schema to JSON file"""
        schema = self.generate_schema()
        with output_path.open("w", encoding="utf-8") as f:
            json.dump(schema, f, indent=2, ensure_ascii=False)
            f.write("\n")

    def export_to_yaml(self, output_path: Path) -> None:
        """Export schema to YAML file (requires PyYAML)"""
        try:
            import yaml  # noqa: PLC0415 - optional dependency

            schema = self.generate_schema()
            with output_path.open("w", encoding="utf-8") as f:
                yaml.dump(schema, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
        except ImportError:
            raise ImportError(
                "PyYAML is required for YAML export. Install with: pip install pyyaml"
            )
