"""ManifestGuard CLI Entry Point

Enables running as: python -m manifestguard

This ensures cross-platform compatibility without requiring .exe on Windows.
"""

import sys

from manifestguard.cli import main

if __name__ == "__main__":
    sys.exit(main())
