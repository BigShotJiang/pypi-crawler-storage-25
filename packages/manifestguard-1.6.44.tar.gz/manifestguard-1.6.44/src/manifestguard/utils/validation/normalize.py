"""
Argument normalization utilities for flexible input handling.

Provides generic patterns for normalizing different input types to standardized
formats, inspired by VS Code command URI normalization but generalized for Python.

Design Principles:
- Accept multiple input types (str, Path, dict, etc.)
- Normalize to canonical type (Path, dict, etc.)
- Fail fast with clear error messages
- Support duck typing where appropriate
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Iterable, TypeVar

from manifestguard.utils.validation.errors import ValidationError

T = TypeVar("T")


def _extract_path_value_from_mapping(value: dict, param: str | None) -> Any:
    preferred_keys = (
        "path",
        "file",
        "dir",
        "filepath",
        "dirpath",
    )

    for key in preferred_keys:
        if key in value:
            return value[key]

    for key in value.keys():
        key_lower = str(key).lower()
        if "path" in key_lower:
            return value[key]

    raise ValidationError(
        "Cannot normalize path input: no path-like key",
        param=param,
        value=value,
        expected="dict with a path-like key (e.g. 'path', 'venv_path')",
    )


def _extract_path_value_from_object(value: Any) -> Any | None:
    if hasattr(value, "path"):
        return getattr(value, "path")
    if hasattr(value, "file"):
        return getattr(value, "file")
    if hasattr(value, "dir"):
        return getattr(value, "dir")
    return None


def _validate_normalized_path(
    path: Path,
    *,
    param: str | None,
    must_exist: bool,
    must_be_file: bool,
    must_be_dir: bool,
) -> None:
    if must_exist and not path.exists():
        raise ValidationError(
            "Path does not exist",
            param=param,
            value=str(path),
            hint=f"Ensure path exists: {path}",
        )

    if must_be_file and path.exists() and not path.is_file():
        raise ValidationError(
            "Path is not a file",
            param=param,
            value=str(path),
            hint=f"Path is a directory: {path}",
        )

    if must_be_dir and path.exists() and not path.is_dir():
        raise ValidationError(
            "Path is not a directory",
            param=param,
            value=str(path),
            hint=f"Path is a file: {path}",
        )


def normalize_path_input(
    value: Any,
    *,
    param: str | None = None,
    must_exist: bool = False,
    must_be_file: bool = False,
    must_be_dir: bool = False,
) -> Path:
    """
    Normalize various path-like inputs to Path objects.
    
    Accepts:
    - str: Path string
    - Path: Already a Path
    - dict with 'path', 'file', or 'dir' key
    - Object with .path, .file, or .dir attribute (duck typing)
    
    Args:
        value: Input value to normalize
        param: Parameter name for error messages
        must_exist: Whether path must exist
        must_be_file: Whether path must be a file
        must_be_dir: Whether path must be a directory
        
    Returns:
        Normalized Path object
        
    Raises:
        ValidationError: If normalization fails or validation fails
        
    Examples:
        >>> normalize_path_input("/tmp/test.txt")
        Path('/tmp/test.txt')
        
        >>> normalize_path_input({"path": "/tmp/test.txt"})
        Path('/tmp/test.txt')
        
        >>> normalize_path_input(Path("/tmp/test.txt"))
        Path('/tmp/test.txt')
    """
    if value is None:
        raise ValidationError(
            "Cannot normalize path input",
            param=param,
            value=value,
            expected="str | Path | dict | object with path-like attribute",
            hint="Provide a path string, Path object, or dict with a path-like key",
        )

    if isinstance(value, Path):
        path = value
    elif isinstance(value, str):
        if not value.strip():
            raise ValidationError(
                "Cannot normalize path input",
                param=param,
                value=value,
                expected="non-empty path string",
            )
        path = Path(value)
    elif isinstance(value, dict):
        return normalize_path_input(
            _extract_path_value_from_mapping(value, param),
            param=param,
            must_exist=must_exist,
            must_be_file=must_be_file,
            must_be_dir=must_be_dir,
        )
    else:
        extracted = _extract_path_value_from_object(value)
        if extracted is None:
            raise ValidationError(
                "Cannot normalize path input",
                param=param,
                value=value,
                expected="str | Path | dict | object with path-like attribute",
                hint=f"Got {type(value).__name__}",
            )

        # Preserve previous behavior: `.file` implies file and `.dir` implies dir.
        if hasattr(value, "file") and extracted is getattr(value, "file"):
            must_be_file = True
            must_be_dir = False
        elif hasattr(value, "dir") and extracted is getattr(value, "dir"):
            must_be_file = False
            must_be_dir = True

        return normalize_path_input(
            extracted,
            param=param,
            must_exist=must_exist,
            must_be_file=must_be_file,
            must_be_dir=must_be_dir,
        )

    _validate_normalized_path(
        path,
        param=param,
        must_exist=must_exist,
        must_be_file=must_be_file,
        must_be_dir=must_be_dir,
    )
    return path


def normalize_dict_input(
    value: Any,
    *,
    param: str | None = None,
    required_keys: Iterable[str] | None = None,
) -> dict[str, Any]:
    """
    Normalize various dict-like inputs to dict.
    
    Accepts:
    - dict: Already a dict
    - Object with .to_dict() method
    - Object with .__dict__ attribute
    - JSON string
    
    Args:
        value: Input value to normalize
        param: Parameter name for error messages
        required_keys: Keys that must be present in normalized dict
        
    Returns:
        Normalized dict
        
    Raises:
        ValidationError: If normalization fails
        
    Examples:
        >>> normalize_dict_input({"key": "value"})
        {'key': 'value'}
        
        >>> class MyClass:
        ...     def to_dict(self):
        ...         return {"key": "value"}
        >>> normalize_dict_input(MyClass())
        {'key': 'value'}
    """
    if value is None:
        raise ValidationError(
            "Dict input cannot be None",
            param=param,
            value=value,
        )

    def _call_dict_method(method: Callable[[], object], *, label: str) -> dict[str, Any]:
        try:
            result = method()
        except Exception as e:  # noqa: BLE001
            raise ValidationError(
                f"Failed to call {label}()",
                param=param,
                value=value,
                hint=str(e),
            ) from e
        if not isinstance(result, dict):
            raise ValidationError(
                f"{label}() did not return a dict",
                param=param,
                value=value,
                hint=f"{label}() returned {type(result).__name__}",
            )
        return result

    def _normalize_object_to_dict(obj: object) -> dict[str, Any] | None:
        to_dict = getattr(obj, "to_dict", None)
        if callable(to_dict):
            return _call_dict_method(to_dict, label="to_dict")

        pydantic_dict = getattr(obj, "dict", None)
        if callable(pydantic_dict):
            return _call_dict_method(pydantic_dict, label="dict")

        if hasattr(obj, "__dict__"):
            return vars(obj)

        return None

    if isinstance(value, dict):
        result = value
    elif isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as e:
            raise ValidationError(
                "Invalid JSON",
                param=param,
                value=value,
                hint=str(e),
            ) from e
        if not isinstance(parsed, dict):
            raise ValidationError(
                "JSON value must be JSON object",
                param=param,
                value=value,
                expected="JSON object",
            )
        result = parsed
    else:
        normalized = _normalize_object_to_dict(value)
        if normalized is None:
            raise ValidationError(
                "Cannot normalize to dict",
                param=param,
                value=value,
                expected="dict, object with .to_dict(), or JSON string",
                hint=f"Got {type(value).__name__}",
            )
        result = normalized

    # Check required keys
    if required_keys:
        required_set = set(required_keys)
        missing = required_set - set(result.keys())
        if missing:
            raise ValidationError(
                f"Missing required keys: {', '.join(missing)}",
                param=param,
                value=result,
                expected=f"dict with keys: {', '.join(sorted(required_set))}",
            )

    return result


def normalize_list_input(
    value: Any,
    *,
    param: str | None = None,
    element_type: type[T] | None = None,
) -> list[Any]:
    """
    Normalize various list-like inputs to list.
    
    Accepts:
    - list/tuple: Already a sequence
    - Single item: Wrapped in list
    - Object with __iter__ (generators, etc.)
    - Comma-separated string
    
    Args:
        value: Input value to normalize
        param: Parameter name for error messages
        element_type: Expected type of list elements (for validation)
        
    Returns:
        Normalized list
        
    Raises:
        ValidationError: If normalization fails
        
    Examples:
        >>> normalize_list_input([1, 2, 3])
        [1, 2, 3]
        
        >>> normalize_list_input(42)
        [42]
        
        >>> normalize_list_input("a,b,c")
        ['a', 'b', 'c']
    """
    if value is None:
        return []

    if isinstance(value, dict):
        raise ValidationError(
            "Cannot normalize list input",
            param=param,
            value=value,
            expected="list | tuple | iterable | str",
        )

    # Already a list
    if isinstance(value, list):
        result = value
        
    # Tuple
    elif isinstance(value, tuple):
        result = list(value)
        
    # Comma-separated string
    elif isinstance(value, str):
        if ',' in value:
            result = [item.strip() for item in value.split(',') if item.strip()]
        else:
            result = [value] if value.strip() else []
            
    # Iterable (but not str/dict)
    elif hasattr(value, '__iter__') and not isinstance(value, (str, bytes)):
        try:
            result = list(value)
        except Exception as e:
            raise ValidationError(
                "Failed to convert iterable to list",
                param=param,
                value=value,
                hint=str(e),
            ) from e
            
    # Single item
    else:
        result = [value]

    # Type checking
    if element_type:
        for i, item in enumerate(result):
            if not isinstance(item, element_type):
                raise ValidationError(
                    f"Element at index {i} has wrong type",
                    param=param,
                    value=item,
                    expected=element_type.__name__,
                    hint=f"Got {type(item).__name__}",
                )

    return result


def get_arg_description(value: Any) -> str:
    """
    Get human-readable description of argument for debugging.
    
    Similar to VS Code's getArgDescription but for Python objects.
    
    Args:
        value: Value to describe
        
    Returns:
        Human-readable description string
        
    Examples:
        >>> get_arg_description(Path("/tmp/test.txt"))
        'Path(/tmp/test.txt)'
        
        >>> get_arg_description({"path": "/tmp/test.txt"})
        'dict(path=/tmp/test.txt)'
    """
    def _truncate(text: str, max_len: int = 120) -> str:
        if len(text) <= max_len:
            return text
        return text[: max_len - 3] + "..."

    if value is None:
        return "None"

    if isinstance(value, str):
        return "str:" + _truncate(value)

    if isinstance(value, Path):
        return f"Path:{value}"

    if isinstance(value, dict):
        keys = list(value.keys())
        keys_preview = ", ".join(str(k) for k in keys[:5])
        if len(keys) > 5:
            keys_preview += ", ..."
        return _truncate(f"dict: keys=[{keys_preview}]")

    if isinstance(value, list):
        return f"list: {len(value)} items"

    return f"{type(value).__name__}"
