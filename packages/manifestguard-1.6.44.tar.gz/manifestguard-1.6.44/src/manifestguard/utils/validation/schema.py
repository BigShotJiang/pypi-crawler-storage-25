"""Schema validation for structured data.

Provides simple dict-based schema validation for JSON/YAML inputs.
"""

from __future__ import annotations

from typing import Any, Callable

from manifestguard.utils.validation.errors import ValidationError


def validate_schema(
    data: dict[str, Any],
    schema: dict[str, Callable[[Any], Any]],
    *,
    context: str = "root",
) -> dict[str, Any]:
    """Validate data against a schema of validators.

    Args:
        data: Dictionary to validate
        schema: Dictionary mapping keys to validator functions
        context: Context path for error messages

    Returns:
        Validated dictionary with typed values

    Raises:
        ValidationError: If data doesn't match schema

    Example:
        >>> from manifestguard.utils.validation import primitives
        >>> schema = {
        ...     "name": primitives.is_non_empty_str,
        ...     "age": primitives.is_positive_int,
        ... }
        >>> data = {"name": "Alice", "age": 30}
        >>> validated = validate_schema(data, schema)

    """
    if not isinstance(data, dict):
        raise ValidationError(
            "Expected dictionary",
            param=context,
            expected="dict",
            value=data,
            hint="Provide a dictionary value",
        )

    out = {}
    for key, validator in schema.items():
        if key not in data:
            raise ValidationError(
                "Missing required field",
                param=f"{context}.{key}",
                expected=f"field '{key}'",
                value="<missing>",
                hint=f"Add required field: {key}",
            )

        try:
            out[key] = validator(data[key], param=f"{context}.{key}")
        except ValidationError:
            # Re-raise with enhanced context
            raise
        except Exception as e:
            # Wrap unexpected errors
            raise ValidationError(
                f"Validation failed for field: {e}",
                param=f"{context}.{key}",
                value=data[key],
                hint="Check validator implementation",
            ) from e

    return out


def validate_partial_schema(
    data: dict[str, Any],
    schema: dict[str, Callable[[Any], Any]],
    *,
    context: str = "root",
) -> dict[str, Any]:
    """Validate only present fields against schema (allow missing fields).

    Args:
        data: Dictionary to validate
        schema: Dictionary mapping keys to validator functions
        context: Context path for error messages

    Returns:
        Validated dictionary with typed values for present fields

    Raises:
        ValidationError: If present fields don't match schema

    """
    if not isinstance(data, dict):
        raise ValidationError(
            "Expected dictionary",
            param=context,
            expected="dict",
            value=data,
            hint="Provide a dictionary value",
        )

    out = {}
    for key, value in data.items():
        if key in schema:
            try:
                out[key] = schema[key](value, param=f"{context}.{key}")
            except ValidationError:
                raise
            except Exception as e:
                raise ValidationError(
                    f"Validation failed for field: {e}",
                    param=f"{context}.{key}",
                    value=value,
                    hint="Check validator implementation",
                ) from e
        else:
            # Pass through fields not in schema
            out[key] = value

    return out
