"""Parameter validation toolkit for ManifestGuard.

Provides lightweight, dependency-minimal parameter validation with clear error messages.

Usage:
    >>> from manifestguard.utils import validation
    >>> 
    >>> # Validate primitives
    >>> name = validation.is_non_empty_str(value, param="name")
    >>> age = validation.is_positive_int(value, param="age")
    >>> 
    >>> # Validate paths
    >>> config_file = validation.is_existing_file(path, param="config")
    >>> output_dir = validation.is_writable_dir(path, param="output")
    >>> 
    >>> # Validate collections
    >>> tags = validation.is_list_of(
    ...     validation.is_non_empty_str,
    ...     value,
    ...     param="tags",
    ...     min_length=1
    ... )
    >>> 
    >>> # Validate structured data
    >>> schema = {
    ...     "name": validation.is_non_empty_str,
    ...     "port": validation.is_positive_int,
    ... }
    >>> config = validation.validate_schema(data, schema, context="config")

"""

from manifestguard.utils.validation.collections import (
    is_dict_with_keys,
    is_list_of,
    is_non_empty_list,
    one_of,
)
from manifestguard.utils.validation.errors import ValidationError
from manifestguard.utils.validation.normalize import (
    get_arg_description,
    normalize_dict_input,
    normalize_list_input,
    normalize_path_input,
)
from manifestguard.utils.validation.paths import (
    is_existing_dir,
    is_existing_file,
    is_path,
    is_readable_file,
    is_safe_path,
    is_writable_dir,
)
from manifestguard.utils.validation.primitives import (
    is_bool,
    is_float,
    is_int,
    is_non_empty_str,
    is_non_negative_int,
    is_positive_float,
    is_positive_int,
    is_str,
)
from manifestguard.utils.validation.schema import (
    validate_partial_schema,
    validate_schema,
)

__all__ = [
    # Errors
    "ValidationError",
    # Primitives
    "is_bool",
    "is_float",
    "is_int",
    "is_non_empty_str",
    "is_non_negative_int",
    "is_positive_float",
    "is_positive_int",
    "is_str",
    # Paths
    "is_existing_dir",
    "is_existing_file",
    "is_path",
    "is_readable_file",
    "is_safe_path",
    "is_writable_dir",
    # Collections
    "is_dict_with_keys",
    "is_list_of",
    "is_non_empty_list",
    "one_of",
    # Schema
    "validate_partial_schema",
    "validate_schema",
    # Normalization
    "get_arg_description",
    "normalize_dict_input",
    "normalize_list_input",
    "normalize_path_input",
]
