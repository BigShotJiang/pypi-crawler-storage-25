from __future__ import annotations

from pathlib import Path
from typing import Any

from manifestguard.orchestration.worker_runner import WorkerRunResult, run_worker_json_command


def run_venv_wizard_preflight(
    *,
    python_exe: str,
    project_root: Path,
    workspace: str | None,
    auto_fix: bool,
    timeout_seconds: float,
) -> WorkerRunResult:
    cmd: list[str] = [python_exe, "-m", "venv_wizard", "preflight"]

    if workspace:
        cmd.extend(["--workspace", workspace])

    if auto_fix:
        cmd.append("--auto-fix")

    return run_worker_json_command(
        cmd=cmd,
        cwd=project_root,
        timeout_seconds=timeout_seconds,
        project_root=project_root,
    )


def summarize_health_payload(payload: dict[str, Any] | None) -> dict[str, Any]:
    if not payload or not isinstance(payload, dict):
        return {
            "status": "error",
            "warnings": 0,
            "managedChildren": 0,
            "running": 0,
            "zombie": 0,
            "dead": 0,
            "unknown": 0,
        }

    managed = payload.get("managed_children")
    if not isinstance(managed, list):
        managed = []

    counts = {"running": 0, "zombie": 0, "dead": 0, "unknown": 0}
    for item in managed:
        if not isinstance(item, dict):
            continue
        status = item.get("status")
        if status in counts:
            counts[status] += 1
        else:
            counts["unknown"] += 1

    warnings = payload.get("warnings")
    warnings_count = len(warnings) if isinstance(warnings, list) else 0

    status = payload.get("status")
    if status not in {"ok", "warning", "error"}:
        status = "error"

    return {
        "status": status,
        "warnings": warnings_count,
        "managedChildren": len(managed),
        **counts,
    }
