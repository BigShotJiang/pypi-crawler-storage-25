from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class WorkerRunResult:
    cmd: list[str]
    cwd: Path
    exit_code: int
    duration_seconds: float
    stdout: str
    stderr: str
    payload: dict[str, Any] | None


def _build_env(*, project_root: Path) -> dict[str, str]:
    env = dict(os.environ)

    # Ensure consistent UTF-8 subprocess IO (Windows-safe).
    env["PYTHONIOENCODING"] = "utf-8"

    # Support src-layout projects without requiring installation.
    src_dir = project_root / "src"
    if src_dir.is_dir():
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = str(src_dir) + (os.pathsep + existing if existing else "")

    return env


def run_worker_json_command(
    *,
    cmd: list[str],
    cwd: Path,
    timeout_seconds: float,
    project_root: Path,
) -> WorkerRunResult:
    start = time.time()
    completed = subprocess.run(
        cmd,
        cwd=str(cwd),
        env=_build_env(project_root=project_root),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout_seconds,
    )
    duration = max(0.0, time.time() - start)

    stdout = completed.stdout or ""
    stderr = completed.stderr or ""

    payload: dict[str, Any] | None = None
    if stdout.strip():
        try:
            parsed = json.loads(stdout)
            if isinstance(parsed, dict):
                payload = parsed
        except Exception:
            payload = None

    return WorkerRunResult(
        cmd=cmd,
        cwd=cwd,
        exit_code=int(completed.returncode),
        duration_seconds=duration,
        stdout=stdout,
        stderr=stderr,
        payload=payload,
    )
