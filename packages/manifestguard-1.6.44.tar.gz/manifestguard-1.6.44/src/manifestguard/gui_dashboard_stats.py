from __future__ import annotations

from dataclasses import dataclass
from html import escape
import math
from pathlib import Path
from typing import Any

from manifestguard.tui_history import build_trends_from_entries
from manifestguard.tui_history import extract_history_entries
from manifestguard.tui_history import load_latest_history_metrics
from manifestguard.tui_history import merge_runtime_metrics
from manifestguard.tui_history import pick_history_source_file
from manifestguard.tui_history import take_recent_entries
from manifestguard.tui_history import try_load_json_file


CARD_TEMPLATE = (
    '<div style="border:1px solid #3c3c3c; border-radius:8px; padding:12px; min-width:150px;">'
    '<div style="font-size:12px; opacity:0.75;">{title}</div>'
    '<div style="font-size:24px; font-weight:600; margin:6px 0;">{value}</div>'
    '<div style="font-size:12px; opacity:0.75;">{subtitle}</div>'
    '</div>'
)

ROW_TEMPLATE = (
    '<tr>'
    '<td style="padding:4px 8px 4px 0; opacity:0.8;">{label}</td>'
    '<td style="padding:4px 0;">{value}</td>'
    '</tr>'
)

SECTION_TEMPLATE = (
    '<div style="border:1px solid #3c3c3c; border-radius:8px; padding:12px; min-width:240px; margin:8px 8px 0 0;">'
    '<div style="font-size:13px; font-weight:600; margin-bottom:8px;">{title}</div>'
    '<table style="width:100%;">{rows}</table>'
    '</div>'
)

CHART_TEMPLATE = (
    '<div style="border:1px solid #3c3c3c; border-radius:8px; padding:12px; min-width:260px; flex:1 1 280px;">'
    '<div style="display:flex; justify-content:space-between; align-items:baseline; gap:8px;">'
    '<div style="font-size:13px; font-weight:600;">{title}</div>'
    '<div style="font-size:12px; opacity:0.78;">{trend_label}</div>'
    '</div>'
    '<div style="font-size:22px; font-weight:600; margin:6px 0 2px 0;">{value}</div>'
    '<div style="font-size:12px; opacity:0.75; margin-bottom:8px;">{subtitle}</div>'
    '<div style="margin-bottom:8px;">{svg}</div>'
    '<div style="font-family:Consolas, monospace; font-size:12px; opacity:0.82;">{sparkline}</div>'
    '</div>'
)

PAGE_TEMPLATE = (
    '<html><body style="font-family: Segoe UI, sans-serif; line-height:1.4;">'
    '<h2 style="margin-bottom:6px;">📈 Stats</h2>'
    '<div style="opacity:0.75; margin-bottom:12px;">'
    'Data source: {data_source}<br>'
    'Latest timestamp: {timestamp}'
    '</div>'
    '<div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px;">{cards}</div>'
    '<div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px;">{charts}</div>'
    '<div style="display:flex; flex-wrap:wrap; align-items:flex-start;">{sections}</div>'
    '</body></html>'
)


@dataclass(frozen=True)
class StatCard:
    title: str
    value: str
    subtitle: str


@dataclass(frozen=True)
class StatRow:
    label: str
    value: str


@dataclass(frozen=True)
class StatSection:
    title: str
    rows: list[StatRow]


@dataclass(frozen=True)
class TrendChart:
    title: str
    value: str
    subtitle: str
    sparkline: str
    trend_label: str
    svg: str


@dataclass(frozen=True)
class DashboardStatsViewModel:
    data_source: str
    timestamp: str
    cards: list[StatCard]
    charts: list[TrendChart]
    sections: list[StatSection]


def _get_num(obj: Any, *path: str) -> float | None:
    current = obj
    for key in path:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    if isinstance(current, (int, float)):
        return float(current)
    return None


def _load_report_metrics_from_file(report_path: Path) -> tuple[dict[str, Any], str | None, dict[str, Any]]:
    data = try_load_json_file(report_path)
    if data is None:
        return {}, None, {}

    extended = data.get("extended")
    runtime_metrics: dict[str, Any] = {}
    timestamp: str | None = None
    if isinstance(extended, dict):
        metrics = extended.get("metrics")
        if isinstance(metrics, dict):
            runtime_metrics = dict(metrics)
        quality_score = extended.get("quality_score")
        if isinstance(quality_score, (int, float)):
            runtime_metrics["quality_score"] = float(quality_score)
        timestamp = extended.get("timestamp") if isinstance(extended.get("timestamp"), str) else None

    return runtime_metrics, timestamp, data


def _format_int(value: float | int | None) -> str:
    if value is None:
        return "n/a"
    return f"{int(value):,}"


def _format_decimal(value: float | int | None, *, suffix: str = "", digits: int = 1) -> str:
    if value is None:
        return "n/a"
    return f"{float(value):.{digits}f}{suffix}"


def _format_ms(value: float | int | None) -> str:
    if value is None or float(value) <= 0:
        return "n/a"
    return f"{int(round(float(value)))}ms"


def _format_bool(value: Any, true_label: str = "Yes", false_label: str = "No") -> str:
    if isinstance(value, bool):
        return true_label if value else false_label
    return "n/a"


def _clean_series(values: list[float] | None) -> list[float]:
    if not values:
        return []
    return [float(value) for value in values if isinstance(value, (int, float)) and math.isfinite(value)]


def _generate_unicode_sparkline(values: list[float] | None) -> str:
    clean = _clean_series(values)
    if len(clean) == 1:
        return "▄"
    if len(clean) < 2:
        return "n/a"

    min_val = min(clean)
    max_val = max(clean)
    if max_val == min_val:
        return "▄" * len(clean)

    blocks = "▁▂▃▄▅▆▇█"
    normalized = [int((value - min_val) / (max_val - min_val) * 7) for value in clean]
    return "".join(blocks[level] for level in normalized)


def _trend_label(values: list[float] | None, *, higher_is_better: bool) -> str:
    clean = _clean_series(values)
    if len(clean) < 2:
        return "insufficient history"

    min_val = min(clean)
    max_val = max(clean)
    diff = clean[-1] - clean[-2]
    scale = max(max_val - min_val, abs(clean[-2]) * 0.05, 1.0)
    if abs(diff) <= scale * 0.05:
        return "stable →"
    improved = diff > 0 if higher_is_better else diff < 0
    return "improving ↗" if improved else "degrading ↘"


def _build_svg_sparkline(values: list[float] | None, *, stroke: str) -> str:
    clean = _clean_series(values)
    width = 220
    height = 56
    if len(clean) < 2:
        return (
            f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">'
            '<line x1="0" y1="28" x2="220" y2="28" stroke="#4a4a4a" stroke-width="1" stroke-dasharray="4 4" />'
            '</svg>'
        )

    min_val = min(clean)
    max_val = max(clean)
    if max_val == min_val:
        max_val = min_val + 1.0

    step = width / (len(clean) - 1)
    points: list[str] = []
    for index, value in enumerate(clean):
        x = round(index * step, 2)
        ratio = (value - min_val) / (max_val - min_val)
        y = round(height - 6 - (ratio * (height - 12)), 2)
        points.append(f"{x},{y}")

    polyline = " ".join(points)
    return (
        f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">'
        f'<polyline fill="none" stroke="{stroke}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="{polyline}" />'
        f'<circle cx="{points[-1].split(",")[0]}" cy="{points[-1].split(",")[1]}" r="4" fill="{stroke}" />'
        '</svg>'
    )


def _load_history_trends(workspace_root: Path) -> dict[str, list[float]]:
    source_file = pick_history_source_file(workspace_root)
    if source_file is None:
        return {}

    data = try_load_json_file(source_file)
    if data is None:
        return {}

    entries = extract_history_entries(data)
    if not entries:
        return {}

    recent = take_recent_entries(entries, limit=8)
    return build_trends_from_entries(recent, history_file=source_file)


def _render_card(card: StatCard) -> str:
    return CARD_TEMPLATE.format(
        title=escape(card.title),
        value=escape(card.value),
        subtitle=escape(card.subtitle),
    )


def _render_section(section: StatSection) -> str:
    rows_html = "".join(
        ROW_TEMPLATE.format(label=escape(row.label), value=escape(row.value))
        for row in section.rows
    )
    return SECTION_TEMPLATE.format(title=escape(section.title), rows=rows_html)


def _render_chart(chart: TrendChart) -> str:
    return CHART_TEMPLATE.format(
        title=escape(chart.title),
        value=escape(chart.value),
        subtitle=escape(chart.subtitle),
        sparkline=escape(chart.sparkline),
        trend_label=escape(chart.trend_label),
        svg=chart.svg,
    )


def _build_python_files_card(files: float | None) -> StatCard:
    return StatCard("Python Files", _format_int(files), "scan space / complexity")


def _build_loc_card(lines_of_code: float | None) -> StatCard:
    return StatCard("Lines of Code", _format_int(lines_of_code), "latest recorded size")


def _build_dependencies_card(total_dependencies: float | None) -> StatCard:
    return StatCard("Dependencies", _format_int(total_dependencies), "direct + transitive")


def _build_issue_count_card(latest_issue_count: int | None) -> StatCard:
    return StatCard("Issue Count", _format_int(latest_issue_count), "errors + warnings")


def _build_quality_score_card(quality_score: float | None) -> StatCard:
    return StatCard("Quality Score", _format_decimal(quality_score, suffix="/100", digits=1), "latest quality metric")


def _build_coverage_card(coverage: float | None) -> StatCard:
    return StatCard("Coverage", _format_decimal(coverage, suffix="%", digits=1), "latest coverage estimate")


def _build_complexity_violations_card(complexity_violations: float | None) -> StatCard:
    return StatCard("Complexity", _format_int(complexity_violations), "violation count")


def _build_avg_complexity_card(latest_avg_complexity: float | None) -> StatCard:
    return StatCard("Avg Complexity", _format_decimal(latest_avg_complexity, digits=1), "latest average")


def _build_trend_chart(
    title: str,
    current_value: str,
    subtitle: str,
    series: list[float] | None,
    *,
    higher_is_better: bool,
    stroke: str,
) -> TrendChart:
    return TrendChart(
        title=title,
        value=current_value,
        subtitle=subtitle,
        sparkline=_generate_unicode_sparkline(series),
        trend_label=_trend_label(series, higher_is_better=higher_is_better),
        svg=_build_svg_sparkline(series, stroke=stroke),
    )


def _build_dependencies_section(
    direct_dependencies: float | None,
    transitive_dependencies: float | None,
    outdated: float | None,
    vulnerable_high: float | None,
    vulnerable_critical: float | None,
) -> StatSection:
    return StatSection(
        "Dependencies",
        [
            StatRow("Direct", _format_int(direct_dependencies)),
            StatRow("Transitive", _format_int(transitive_dependencies)),
            StatRow("Outdated", _format_int(outdated)),
            StatRow("Vulnerable", f"H:{_format_int(vulnerable_high)} C:{_format_int(vulnerable_critical)}"),
        ],
    )


def _build_sbom_license_section(
    sbom_components: float | None,
    sbom_missing_licenses: float | None,
    sbom_unknown_origins: float | None,
    sbom_spdx: Any,
    license_file_present: Any,
    spdx_errors: float | None,
) -> StatSection:
    return StatSection(
        "SBOM / License",
        [
            StatRow("Components", _format_int(sbom_components)),
            StatRow("Missing Licenses", _format_int(sbom_missing_licenses)),
            StatRow("Unknown Origins", _format_int(sbom_unknown_origins)),
            StatRow("SPDX Compliance", _format_bool(sbom_spdx, "OK", "No")),
            StatRow("License File", _format_bool(license_file_present, "Present", "Missing")),
            StatRow("SPDX Errors", _format_int(spdx_errors)),
        ],
    )


def _build_policy_section(
    whitelist: float | None,
    blacklist: float | None,
    dummy_code: float | None,
    duplicate_groups: float | None,
) -> StatSection:
    return StatSection(
        "Policy",
        [
            StatRow("Whitelist Violations", _format_int(whitelist)),
            StatRow("Blacklist Violations", _format_int(blacklist)),
            StatRow("Dummy Code Findings", _format_int(dummy_code)),
            StatRow("Duplicate Groups", _format_int(duplicate_groups)),
        ],
    )


def _build_packaging_performance_section(
    missing_classifiers: float | None,
    has_py_typed: Any,
    version_ok: Any,
    readme_present: Any,
    performance: dict[str, Any],
) -> StatSection:
    return StatSection(
        "Packaging / Performance",
        [
            StatRow("Missing Classifiers", _format_int(missing_classifiers)),
            StatRow("py.typed", _format_bool(has_py_typed, "Yes", "No")),
            StatRow("Version Consistency", _format_bool(version_ok, "OK", "Mismatch")),
            StatRow("README", _format_bool(readme_present, "Present", "Missing")),
            StatRow("Total", _format_ms(_get_num(performance, "total_analysis_ms") or _get_num(performance, "total_ms"))),
            StatRow("Manifest", _format_ms(_get_num(performance, "manifest_parse_ms"))),
            StatRow("Rules", _format_ms(_get_num(performance, "rule_engine_ms"))),
            StatRow("Deps", _format_ms(_get_num(performance, "dependency_graph_ms"))),
        ],
    )


def build_dashboard_stats_view_model(
    workspace_root: Path,
    report_path: Path | None,
) -> DashboardStatsViewModel:
    history_metrics, history_timestamp = load_latest_history_metrics(workspace_root)
    trends = _load_history_trends(workspace_root)

    report_metrics: dict[str, Any] = {}
    report_timestamp: str | None = None
    report_data: dict[str, Any] = {}
    if report_path is not None and report_path.exists() and report_path.is_file():
        report_metrics, report_timestamp, report_data = _load_report_metrics_from_file(report_path)

    metrics = merge_runtime_metrics(report_metrics, history_metrics)

    dependency = metrics.get("dependency") if isinstance(metrics.get("dependency"), dict) else {}
    complexity = metrics.get("complexity") if isinstance(metrics.get("complexity"), dict) else {}
    scan_space = metrics.get("scan_space") if isinstance(metrics.get("scan_space"), dict) else {}
    sbom = metrics.get("sbom") if isinstance(metrics.get("sbom"), dict) else {}
    policy = metrics.get("policy") if isinstance(metrics.get("policy"), dict) else {}
    license_data = metrics.get("license") if isinstance(metrics.get("license"), dict) else {}
    packaging = metrics.get("packaging") if isinstance(metrics.get("packaging"), dict) else {}
    performance = metrics.get("performance") if isinstance(metrics.get("performance"), dict) else {}

    files = _get_num(scan_space, "files") or _get_num(scan_space, "included") or _get_num(complexity, "files_scanned")
    lines_of_code = _get_num(scan_space, "lines_of_code") or _get_num(scan_space, "linesOfCode")
    direct_dependencies = _get_num(dependency, "direct_count")
    transitive_dependencies = _get_num(dependency, "transitive_count")
    total_dependencies = _get_num(dependency, "total_count")
    if total_dependencies is None and direct_dependencies is not None and transitive_dependencies is not None:
        total_dependencies = direct_dependencies + transitive_dependencies

    errors = report_data.get("errors") if isinstance(report_data.get("errors"), (int, float)) else None
    warnings = report_data.get("warnings") if isinstance(report_data.get("warnings"), (int, float)) else None
    issues_section = metrics.get("issues") if isinstance(metrics.get("issues"), dict) else {}
    latest_issue_count: int | None = None
    history_total = _get_num(issues_section, "totalIssues")
    if history_total is not None:
        latest_issue_count = int(history_total)
    elif errors is not None or warnings is not None:
        latest_issue_count = int(errors or 0) + int(warnings or 0)

    quality_score = _get_num(metrics, "quality_score")
    coverage_data = metrics.get("coverage") if isinstance(metrics.get("coverage"), dict) else {}
    coverage: float | None = None
    explicit_measured = coverage_data.get("unit_measured") if isinstance(coverage_data, dict) else None
    if explicit_measured is True:
        coverage = _get_num(metrics, "coverage", "unit_percent")
        if coverage is None:
            coverage = _get_num(metrics, "coverage", "estimate")
    elif explicit_measured is not False:
        estimate = _get_num(metrics, "coverage", "unit_percent")
        if estimate is None:
            estimate = _get_num(metrics, "coverage", "estimate")
        if estimate is not None and estimate > 0:
            coverage = estimate
    complexity_violations = _get_num(complexity, "violations")
    latest_avg_complexity = _get_num(complexity, "average_complexity") or _get_num(complexity, "avg_complexity")

    vulnerable_high = _get_num(dependency, "vulnerable_high")
    vulnerable_critical = _get_num(dependency, "vulnerable_critical")
    outdated = _get_num(dependency, "outdated_count")
    sbom_components = _get_num(sbom, "components_count")
    sbom_missing_licenses = _get_num(sbom, "missing_licenses")
    sbom_unknown_origins = _get_num(sbom, "unknown_origins")
    sbom_spdx = sbom.get("spdx_compliance")
    whitelist = len(policy.get("whitelist_violations", [])) if isinstance(policy.get("whitelist_violations"), list) else None
    blacklist = len(policy.get("blacklist_violations", [])) if isinstance(policy.get("blacklist_violations"), list) else None
    dummy_code = _get_num(policy, "dummy_code_total_findings")
    duplicate_groups = _get_num(policy, "duplication", "duplicate_groups_count")
    spdx_errors = len(license_data.get("spdx_mismatches", [])) if isinstance(license_data.get("spdx_mismatches"), list) else None
    license_file_present = None
    if isinstance(license_data.get("license_file_missing"), bool):
        license_file_present = not bool(license_data.get("license_file_missing"))
    missing_classifiers = len(packaging.get("missing_classifiers", [])) if isinstance(packaging.get("missing_classifiers"), list) else None
    has_py_typed = packaging.get("has_py_typed")
    version_ok = packaging.get("version_consistency")
    readme_present = packaging.get("readme_present")

    cards = [
        _build_python_files_card(files),
        _build_loc_card(lines_of_code),
        _build_dependencies_card(total_dependencies),
        _build_issue_count_card(latest_issue_count),
        _build_quality_score_card(quality_score),
        _build_coverage_card(coverage),
        _build_complexity_violations_card(complexity_violations),
        _build_avg_complexity_card(latest_avg_complexity),
    ]

    charts = [
        _build_trend_chart(
            "Quality Score Trend",
            _format_decimal(quality_score, suffix="/100", digits=1),
            "recent history",
            trends.get("quality"),
            higher_is_better=True,
            stroke="#2fa36b",
        ),
        _build_trend_chart(
            "Coverage Trend",
            _format_decimal(coverage, suffix="%", digits=1),
            "recent history",
            trends.get("coverage"),
            higher_is_better=True,
            stroke="#2b7cff",
        ),
        _build_trend_chart(
            "Complexity Trend",
            _format_decimal(latest_avg_complexity, digits=1),
            "lower is better",
            trends.get("complexity"),
            higher_is_better=False,
            stroke="#ff8a2a",
        ),
        _build_trend_chart(
            "Performance Trend",
            _format_ms(_get_num(performance, "total_analysis_ms") or _get_num(performance, "total_ms")),
            "lower is better",
            trends.get("performance"),
            higher_is_better=False,
            stroke="#d14d72",
        ),
    ]

    sections = [
        _build_dependencies_section(
            direct_dependencies,
            transitive_dependencies,
            outdated,
            vulnerable_high,
            vulnerable_critical,
        ),
        _build_sbom_license_section(
            sbom_components,
            sbom_missing_licenses,
            sbom_unknown_origins,
            sbom_spdx,
            license_file_present,
            spdx_errors,
        ),
        _build_policy_section(
            whitelist,
            blacklist,
            dummy_code,
            duplicate_groups,
        ),
        _build_packaging_performance_section(
            missing_classifiers,
            has_py_typed,
            version_ok,
            readme_present,
            performance,
        ),
    ]

    data_source = (
        "history + selected report"
        if history_metrics and report_metrics
        else "selected report"
        if report_metrics
        else "history"
        if history_metrics
        else f"none\nTried: .mgpy/metrics/manifestguard-history.json"
    )
    timestamp_text = report_timestamp or history_timestamp or "n/a"
    return DashboardStatsViewModel(
        data_source=data_source,
        timestamp=timestamp_text,
        cards=cards,
        charts=charts,
        sections=sections,
    )


def render_dashboard_stats_html(view_model: DashboardStatsViewModel) -> str:
    cards_html = "".join(_render_card(card) for card in view_model.cards)
    charts_html = "".join(_render_chart(chart) for chart in view_model.charts)
    sections_html = "".join(_render_section(section) for section in view_model.sections)
    return PAGE_TEMPLATE.format(
        data_source=escape(view_model.data_source),
        timestamp=escape(view_model.timestamp),
        cards=cards_html,
        charts=charts_html,
        sections=sections_html,
    )


def build_dashboard_stats_html(workspace_root: Path, report_path: Path | None) -> str:
    return render_dashboard_stats_html(
        build_dashboard_stats_view_model(workspace_root, report_path)
    )