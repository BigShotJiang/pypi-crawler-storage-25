"""
validate-views: View registration and HTML hygiene validation for mgpy.

This module implements Phase P0-P4 of the validate-views guardrail:
- VV-001: TUI screen registration check (extends to Rich Layout/Panel + Textual attribute bases)
- VV-002: HTML inline style detection
- VV-003: HTML inline event handler detection
- VV-004: Jupyter notebook HTML hygiene (%%html magic, IPython.display.HTML)
- VV-005: Template inheritance orphan-block detection
- VV-006: Unsafe pickle deserialization outside tests/
- VV-007: Deprecated asyncio loop access patterns outside tests/

Config file: .validateviewsrc (JSON) at workspace root — supports per-project rule overrides
and inheritance via an extends key.
Based on concept.validate-views.en.md, adapted for Python/mgpy context.
"""

import ast
import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
import sys


@dataclass
class Violation:
    """Represents a single validate-views violation."""
    rule: str
    file: Path
    line: int
    column: int
    message: str
    severity: str  # ERROR or WARNING

    def __str__(self) -> str:
        """Format violation for console output (CI-friendly)."""
        rel_path = self.file.as_posix()
        return f"{rel_path}:{self.line}:{self.column} {self.rule} {self.message}"


class ViewValidator(ABC):
    """Base class for view validation rules."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        self.target_dirs = target_dirs
        self.ignore_patterns = ignore_patterns
        self.violations: list[Violation] = []

    def should_ignore(self, file_path: Path) -> bool:
        """Check if file should be ignored based on patterns."""
        file_str = file_path.as_posix()
        for pattern in self.ignore_patterns:
            # Simple glob-style matching
            if pattern.endswith("/**"):
                prefix = pattern[:-3]
                if prefix in file_str:
                    return True
            elif pattern in file_str:
                return True
        return False

    @abstractmethod
    def validate(self) -> list[Violation]:
        """Run validation and return violations."""
        ...


class TUIScreenRegistrationValidator(ViewValidator):
    """VV-001: Ensure all TUI screen classes are registered in router."""

    # Base class names for TUI view classes that should be registered.
    # Covers Textual Screen + Rich Layout and Panel.
    TUI_BASE_NAMES: frozenset[str] = frozenset({"Screen", "Layout", "Panel"})

    # Allow IDs like "metrics-history" (kebab-case), not just \w.
    _REGISTRATION_PATTERN = r"register(?:_screen|_view)\s*\(\s*['\"]([\w-]+)['\"]"

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)

    def find_screen_classes(self, file_path: Path) -> list[tuple[str, int]]:
        """Find all TUI view subclasses in a Python file.

        Detects:
        - ``class X(Screen):`` — Textual Screen (simple name)
        - ``class X(textual.Screen):`` — Textual Screen (attribute access)
        - ``class X(Layout):`` — Rich Layout
        - ``class X(Panel):`` — Rich Panel

        Returns:
            [(class_name, line_number), ...]
        """
        try:
            content = file_path.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(file_path))
        except (SyntaxError, UnicodeDecodeError):
            return []

        screens = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for base in node.bases:
                    base_name: str | None = None
                    if isinstance(base, ast.Name):
                        base_name = base.id
                    elif isinstance(base, ast.Attribute):
                        # e.g. textual.Screen → attr = "Screen"
                        base_name = base.attr
                    if base_name in self.TUI_BASE_NAMES:
                        screens.append((node.name, node.lineno))
                        break
        return screens

    def find_registrations(self, file_path: Path) -> set[str]:
        """Find all registered screen IDs in router files."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return set()

        # Look for registration calls like register_screen('screen-id')
        matches = re.findall(self._REGISTRATION_PATTERN, content, re.IGNORECASE)
        return set(matches)

    def _collect_screen_files(self) -> list[Path]:
        """Return all non-ignored .py files from target directories."""
        files: list[Path] = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if not self.should_ignore(py_file):
                    files.append(py_file)
        return files

    def _collect_registered_ids(self) -> set[str]:
        """Return all registered screen IDs found in router/registry files."""
        registered: set[str] = set()
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if "router" in py_file.stem.lower() or "registry" in py_file.stem.lower():
                    registered.update(self.find_registrations(py_file))
        return registered

    @staticmethod
    def _screen_kebab_id(class_name: str) -> str:
        """Convert ClassName to kebab-case screen ID (e.g. MetricsHistoryScreen -> metrics-history)."""
        snake = re.sub(r"(?<!^)(?=[A-Z])", "_", class_name).lower().replace("_screen", "")
        return snake.replace("_", "-")

    def validate(self) -> list[Violation]:
        """Check for unregistered TUI screens."""
        self.violations = []

        all_screens: list[tuple[Path, str, int]] = [
            (fp, name, line)
            for fp in self._collect_screen_files()
            for name, line in self.find_screen_classes(fp)
        ]

        registered_ids = self._collect_registered_ids()

        for file_path, screen_name, line_no in all_screens:
            screen_id_kebab = self._screen_kebab_id(screen_name)
            screen_id_snake = screen_id_kebab.replace("-", "_")
            if screen_id_snake not in registered_ids and screen_id_kebab not in registered_ids:
                self.violations.append(Violation(
                    rule="VV-001",
                    file=file_path,
                    line=line_no,
                    column=1,
                    message=f"TUI screen '{screen_name}' not registered in router (expected ID: '{screen_id_kebab}')",
                    severity="WARNING",
                ))

        return self.violations


class JupyterHTMLHygieneValidator(ViewValidator):
    """VV-004: Detect raw HTML with inline styles or event handlers in Jupyter notebooks.

    Checks:
    - ``%%html`` cell magic containing ``style=`` or inline event attributes
    - ``IPython.display.HTML(...)`` calls passing HTML with inline style / event attributes
    """

    # Matches inline style attribute (e.g. style="color:red")
    _RE_INLINE_STYLE = re.compile(r'\bstyle\s*=', re.IGNORECASE)
    # Matches inline event handlers (e.g. onclick=, onmouseover=)
    _RE_EVENT_HANDLER = re.compile(r'\bon[a-z]{2,}\s*=', re.IGNORECASE)
    # Matches HTML() call content (greedy first arg)
    _RE_HTML_CALL = re.compile(r'HTML\s*\(\s*(["\'][^\'"]*["\']|f["\'][^\'"]*["\'])', re.DOTALL)

    def _scan_python_file(self, file_path: Path) -> list[Violation]:
        """Scan a .py file for IPython.display.HTML calls with problematic content."""
        violations: list[Violation] = []
        try:
            lines = file_path.read_text(encoding="utf-8").splitlines()
        except (UnicodeDecodeError, OSError):
            return violations
        for lineno, line in enumerate(lines, start=1):
            if "HTML(" not in line:
                continue
            if self._RE_INLINE_STYLE.search(line):
                violations.append(Violation(
                    rule="VV-004",
                    file=file_path,
                    line=lineno,
                    column=line.index("HTML(") + 1,
                    message="IPython.display.HTML() call contains inline style",
                    severity="WARNING",
                ))
            elif self._RE_EVENT_HANDLER.search(line):
                violations.append(Violation(
                    rule="VV-004",
                    file=file_path,
                    line=lineno,
                    column=line.index("HTML(") + 1,
                    message="IPython.display.HTML() call contains inline event handler",
                    severity="WARNING",
                ))
        return violations

    def _scan_notebook(self, file_path: Path) -> list[Violation]:
        """Scan a .ipynb notebook for %%html magic cells with problematic content."""
        violations: list[Violation] = []
        try:
            nb = json.loads(file_path.read_text(encoding="utf-8"))
        except Exception:
            return violations
        cells = nb.get("cells") or []
        for cell_idx, cell in enumerate(cells):
            source_lines = cell.get("source") or []
            if isinstance(source_lines, str):
                source_lines = source_lines.splitlines()
            if not source_lines or source_lines[0].strip() not in ("%%html", "%%HTML"):
                continue
            # Check each line in the cell for inline style / event handlers
            for line_offset, line in enumerate(source_lines[1:], start=2):
                if self._RE_INLINE_STYLE.search(line):
                    violations.append(Violation(
                        rule="VV-004",
                        file=file_path,
                        line=cell_idx + line_offset,
                        column=1,
                        message=f"%%html cell (cell #{cell_idx + 1}) contains inline style",
                        severity="WARNING",
                    ))
                elif self._RE_EVENT_HANDLER.search(line):
                    violations.append(Violation(
                        rule="VV-004",
                        file=file_path,
                        line=cell_idx + line_offset,
                        column=1,
                        message=f"%%html cell (cell #{cell_idx + 1}) contains inline event handler",
                        severity="WARNING",
                    ))
        return violations

    def validate(self) -> list[Violation]:
        """Scan .py and .ipynb files for Jupyter HTML hygiene issues."""
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if not self.should_ignore(py_file):
                    self.violations.extend(self._scan_python_file(py_file))
            for nb_file in target_dir.rglob("*.ipynb"):
                if not self.should_ignore(nb_file):
                    self.violations.extend(self._scan_notebook(nb_file))
        return self.violations


class HTMLInlineStyleValidator(ViewValidator):
    """VV-002: Detect inline styles in HTML (CSP violation risk)."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)
        # Patterns for inline style detection
        self.patterns = [
            (r"<style[^>]*>", "Inline <style> block detected (CSP violation risk)"),
            (r'style\s*=\s*["\']', "Inline style attribute detected (CSP violation risk)"),
            (r'\.style\.cssText\s*=', "cssText assignment detected (CSP violation risk)"),
        ]

    def validate(self) -> list[Violation]:
        """Check for inline styles in HTML files and Python string literals."""
        self.violations = []

        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            # Scan .html, .htm, .jinja2, .j2, .mako files
            for pattern in ["*.html", "*.htm", "*.jinja2", "*.j2", "*.mako"]:
                for file_path in target_dir.rglob(pattern):
                    if self.should_ignore(file_path):
                        continue
                    self._check_file(file_path)

            # Also scan Python files for HTML string literals
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                self._check_python_html(py_file)

        return self.violations

    def _check_file(self, file_path: Path):
        """Check a single HTML file for inline styles."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(Violation(
                        rule="VV-002",
                        file=file_path,
                        line=line_no,
                        column=1,
                        message=message,
                        severity="ERROR"
                    ))

    def _check_python_html(self, file_path: Path):
        """Check Python source for inline style patterns.

        We scan *all* lines because CSP-violating patterns like
        `element.style.cssText = ...` can appear outside HTML literals.
        """
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(
                        Violation(
                            rule="VV-002",
                            file=file_path,
                            line=line_no,
                            column=1,
                            message=message,
                            severity="ERROR",
                        )
                    )


class HTMLInlineEventHandlerValidator(ViewValidator):
    """VV-003: Detect inline event handlers in HTML (XSS risk)."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)
        # Common inline event handlers
        self.event_handlers = [
            "onclick", "onload", "onerror", "onmouseover", "onmouseout",
            "onkeydown", "onkeyup", "onchange", "onsubmit", "onfocus", "onblur"
        ]
        self.patterns = [
            (rf'{handler}\s*=\s*["\']', f"Inline {handler} handler detected (XSS risk)")
            for handler in self.event_handlers
        ]

    def validate(self) -> list[Violation]:
        """Check for inline event handlers in HTML files and Python string literals."""
        self.violations = []

        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            # Scan .html, .htm, .jinja2, .j2, .mako files
            for pattern in ["*.html", "*.htm", "*.jinja2", "*.j2", "*.mako"]:
                for file_path in target_dir.rglob(pattern):
                    if self.should_ignore(file_path):
                        continue
                    self._check_file(file_path)

            # Also scan Python files for HTML string literals
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                self._check_python_html(py_file)

        return self.violations

    def _check_file(self, file_path: Path):
        """Check a single HTML file for inline event handlers."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(Violation(
                        rule="VV-003",
                        file=file_path,
                        line=line_no,
                        column=1,
                        message=message,
                        severity="ERROR"
                    ))

    def _check_python_html(self, file_path: Path):
        """Check Python string literals for HTML with inline event handlers."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            # Only check lines that look like HTML (heuristic: contains < and >)
            if "<" in line and ">" in line:
                for pattern, message in self.patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        self.violations.append(Violation(
                            rule="VV-003",
                            file=file_path,
                            line=line_no,
                            column=1,
                            message=message,
                            severity="ERROR"
                        ))


class TemplateInheritanceValidator(ViewValidator):
    """VV-005: Detect Django/Flask template orphan blocks.

    Flags ``.html`` templates that define ``{% block ... %}`` without a
    corresponding ``{% extends ... %}`` — a common copy-paste error that
    produces silently broken template inheritance.
    """

    _RE_EXTENDS = re.compile(r"\{%-?\s*extends\b", re.IGNORECASE)
    _RE_BLOCK = re.compile(r"\{%-?\s*block\s+\w+", re.IGNORECASE)

    def validate(self) -> list[Violation]:
        """Check for orphan block definitions in template files."""
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for html_file in target_dir.rglob("*.html"):
                if self.should_ignore(html_file):
                    continue
                try:
                    content = html_file.read_text(encoding="utf-8")
                except (UnicodeDecodeError, OSError):
                    continue
                if self._RE_BLOCK.search(content) and not self._RE_EXTENDS.search(content):
                    for line_no, line in enumerate(content.splitlines(), start=1):
                        if self._RE_BLOCK.search(line):
                            self.violations.append(Violation(
                                rule="VV-005",
                                file=html_file,
                                line=line_no,
                                column=1,
                                message="Template defines {% block %} without {% extends %} (orphan block)",
                                severity="WARNING",
                            ))
                            break
        return self.violations


class PickleDeserializationValidator(ViewValidator):
    """VV-006: Detect unsafe pickle deserialization outside ``tests/``.

    Flags ``pickle.loads()`` / ``pickle.load()`` calls in any ``.py`` file
    that is not under a ``tests`` directory subtree.  Respects ``.validateviewsrc``
    ``rules.VV-006: off`` to disable per-project.
    """

    _RE_PICKLE = re.compile(r"\bpickle\.(loads?)\s*\(")

    def validate(self) -> list[Violation]:
        """Scan Python files for pickle deserialization outside tests/."""
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                if "tests" in py_file.parts:
                    continue
                try:
                    lines = py_file.read_text(encoding="utf-8").splitlines()
                except (UnicodeDecodeError, OSError):
                    continue
                for line_no, line in enumerate(lines, start=1):
                    m = self._RE_PICKLE.search(line)
                    if m:
                        self.violations.append(Violation(
                            rule="VV-006",
                            file=py_file,
                            line=line_no,
                            column=m.start() + 1,
                            message=(
                                f"Unsafe pickle deserialization: pickle.{m.group(1)}() "
                                "detected outside tests/"
                            ),
                            severity="ERROR",
                        ))
        return self.violations


class AsyncioMisuseValidator(ViewValidator):
    """VV-007: Detect deprecated asyncio loop access outside tests/."""

    _RE_GET_EVENT_LOOP = re.compile(r"\basyncio\.get_event_loop\s*\(")
    _RE_RUN_UNTIL_COMPLETE = re.compile(r"\bloop\.run_until_complete\s*\(")

    def validate(self) -> list[Violation]:
        """Scan Python files for deprecated loop access patterns outside tests/."""
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                if "tests" in py_file.parts:
                    continue
                try:
                    lines = py_file.read_text(encoding="utf-8").splitlines()
                except (UnicodeDecodeError, OSError):
                    continue
                for line_no, line in enumerate(lines, start=1):
                    get_event_loop_match = self._RE_GET_EVENT_LOOP.search(line)
                    if get_event_loop_match:
                        self.violations.append(Violation(
                            rule="VV-007",
                            file=py_file,
                            line=line_no,
                            column=get_event_loop_match.start() + 1,
                            message=(
                                "Deprecated asyncio.get_event_loop() detected outside tests/; "
                                "prefer asyncio.run() or asyncio.get_running_loop()"
                            ),
                            severity="WARNING",
                        ))

                    run_until_complete_match = self._RE_RUN_UNTIL_COMPLETE.search(line)
                    if run_until_complete_match:
                        self.violations.append(Violation(
                            rule="VV-007",
                            file=py_file,
                            line=line_no,
                            column=run_until_complete_match.start() + 1,
                            message=(
                                "Bare loop.run_until_complete() detected outside tests/; "
                                "prefer asyncio.run() at the entry point"
                            ),
                            severity="WARNING",
                        ))
        return self.violations


def _dedupe_strings(values: list[object]) -> list[str]:
    """Return unique string values while preserving first-seen order."""
    result: list[str] = []
    for value in values:
        if isinstance(value, str) and value not in result:
            result.append(value)
    return result


def _merge_validateviewsrc(base: dict, override: dict) -> dict:
    """Merge base and child .validateviewsrc payloads."""
    merged: dict[str, object] = {}

    base_rules = base.get("rules") if isinstance(base.get("rules"), dict) else {}
    override_rules = override.get("rules") if isinstance(override.get("rules"), dict) else {}
    if base_rules or override_rules:
        merged["rules"] = {**base_rules, **override_rules}

    base_ignore = _dedupe_strings(list(base.get("ignore") or []))
    override_ignore = _dedupe_strings(list(override.get("ignore") or []))
    if base_ignore or override_ignore:
        merged["ignore"] = _dedupe_strings(base_ignore + override_ignore)

    base_target_dirs = _dedupe_strings(list(base.get("target_dirs") or []))
    override_target_dirs = _dedupe_strings(list(override.get("target_dirs") or []))
    if override_target_dirs:
        merged["target_dirs"] = override_target_dirs
    elif base_target_dirs:
        merged["target_dirs"] = base_target_dirs

    return merged


def _load_validateviewsrc_file(rc_path: Path, seen: set[Path] | None = None) -> dict:
    """Load a .validateviewsrc file, optionally following an extends chain."""
    seen = seen or set()
    try:
        resolved_path = rc_path.resolve()
    except OSError:
        resolved_path = rc_path

    if resolved_path in seen or not rc_path.is_file():
        return {}

    seen.add(resolved_path)

    try:
        raw = json.loads(rc_path.read_text(encoding="utf-8"))
    except Exception:
        return {}

    if not isinstance(raw, dict):
        return {}

    base_config: dict = {}
    extends_value = raw.get("extends")
    extends_paths: list[str] = []
    if isinstance(extends_value, str):
        extends_paths = [extends_value]
    elif isinstance(extends_value, list):
        extends_paths = [value for value in extends_value if isinstance(value, str)]

    for extends_path in extends_paths:
        parent_path = Path(extends_path)
        if not parent_path.is_absolute():
            parent_path = rc_path.parent / parent_path
        base_config = _merge_validateviewsrc(
            base_config,
            _load_validateviewsrc_file(parent_path, seen),
        )

    child_config = {key: value for key, value in raw.items() if key != "extends"}
    return _merge_validateviewsrc(base_config, child_config)


def _load_validateviewsrc(workspace_root: Path | None = None) -> dict:
    """Load .validateviewsrc config from the workspace root (JSON).

    Supported keys:
    - ``rules``: dict of rule-ID → "on" | "off" (string) or ``true`` / ``false``
    - ``ignore``: list of additional glob patterns to ignore
    - ``target_dirs``: list of directory paths to scan

    Returns an empty dict when the file is absent or unparseable.
    """
    root = workspace_root or Path.cwd()
    rc_path = root / ".validateviewsrc"
    return _load_validateviewsrc_file(rc_path)


def run_validate_views(
    target_dirs: list[str] | None = None,
    ignore_patterns: list[str] | None = None,
    enabled_rules: set[str] | None = None,
    workspace_root: Path | None = None,
) -> dict[str, list[Violation]]:
    """
    Run all validate-views checks.

    Per-project config is read from ``.validateviewsrc`` (JSON) in *workspace_root*.
    CLI / caller arguments take precedence over config-file values.

    Args:
        target_dirs: Directories to scan (default: from .validateviewsrc or built-in list).
        ignore_patterns: Glob patterns to ignore (merged with .validateviewsrc ignore list).
        enabled_rules: Explicit rule-ID allow-set; applied after .validateviewsrc rules.
        workspace_root: Project root used to locate .validateviewsrc (default: cwd).

    Returns:
        Dict mapping rule ID to list of violations.
    """
    rc = _load_validateviewsrc(workspace_root)

    if target_dirs is None:
        rc_dirs = rc.get("target_dirs")
        target_dirs = list(rc_dirs) if isinstance(rc_dirs, list) else [
            "src/manifestguard/extended/tui",
            "src/templates",
            "src/manifestguard/reporters",
        ]

    default_ignore = ["tests/**", "docs/**", "examples/**", "__pycache__/**"]
    rc_ignore = rc.get("ignore") or []
    if ignore_patterns is None:
        ignore_patterns = default_ignore + [p for p in rc_ignore if p not in default_ignore]
    else:
        ignore_patterns = list(ignore_patterns) + [p for p in rc_ignore if p not in ignore_patterns]

    root = workspace_root or Path.cwd()
    target_paths = []
    for target_dir in target_dirs:
        target_path = Path(target_dir)
        if not target_path.is_absolute():
            target_path = root / target_path
        target_paths.append(target_path)

    # Build enabled-rules set from .validateviewsrc then apply caller override.
    rc_rules: dict[str, object] = rc.get("rules") or {}
    rc_disabled: set[str] = {
        rule_id
        for rule_id, val in rc_rules.items()
        if str(val).lower() in ("off", "false", "0")
    }

    validators = [
        TUIScreenRegistrationValidator(target_paths, ignore_patterns),
        HTMLInlineStyleValidator(target_paths, ignore_patterns),
        HTMLInlineEventHandlerValidator(target_paths, ignore_patterns),
        JupyterHTMLHygieneValidator(target_paths, ignore_patterns),
        TemplateInheritanceValidator(target_paths, ignore_patterns),
        PickleDeserializationValidator(target_paths, ignore_patterns),
        AsyncioMisuseValidator(target_paths, ignore_patterns),
    ]

    results: dict[str, list[Violation]] = {}
    for validator in validators:
        violations = validator.validate()
        if violations:
            rule_id = violations[0].rule
            results[rule_id] = violations

    # Remove rules disabled in .validateviewsrc
    if rc_disabled:
        results = {k: v for k, v in results.items() if k not in rc_disabled}

    # Caller-supplied allow-set has final say
    if enabled_rules:
        results = {k: v for k, v in results.items() if k in enabled_rules}

    return results


def format_violations(violations: dict[str, list[Violation]]) -> str:
    """Format violations for console output."""
    if not violations:
        return "✓ No validate-views violations found."

    output_lines = []
    total = 0

    for rule_id in sorted(violations.keys()):
        for violation in violations[rule_id]:
            output_lines.append(str(violation))
            total += 1

    # Add summary
    output_lines.append("")
    output_lines.append("Summary:")
    for rule_id in sorted(violations.keys()):
        count = len(violations[rule_id])
        rule_name = {
            "VV-001": "TUI Registration",
            "VV-002": "HTML Inline Style",
            "VV-003": "HTML Inline Event Handler",
            "VV-004": "Jupyter HTML Hygiene",
            "VV-005": "Template Inheritance",
            "VV-006": "Pickle Deserialization",
            "VV-007": "Asyncio Misuse",
        }.get(rule_id, rule_id)
        output_lines.append(f"  {rule_id} ({rule_name}): {count} violation{'s' if count != 1 else ''}")
    output_lines.append(f"  Total: {total} violation{'s' if total != 1 else ''}")
    output_lines.append("")

    return "\n".join(output_lines)


def main():
    """CLI entry point for validate-views."""
    results = run_validate_views()
    output = format_violations(results)
    print(output)

    # Exit with code 2 if violations found (standard for linting tools)
    sys.exit(2 if results else 0)


if __name__ == "__main__":
    main()
