"""Panel rendering helpers for the ManifestGuard TUI.

This module contains the Rich panel/table rendering logic. It is intentionally
separated from the interactive/dashboard orchestration in `manifestguard.tui`.

Public behavior is preserved by keeping `TUIManager.create_*_panel()` methods
as delegating wrappers.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.panel import Panel
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from manifestguard.tui import TUIManager


def create_header_panel(manager: TUIManager) -> Panel:
    """Create the header panel with title and basic info."""
    title = Text("🛡️ ManifestGuard Dashboard", style="bold blue")
    subtitle = Text(f"Workspace: {manager.workspace_root.name}", style="dim")

    header_text = Text()
    header_text.append(title)
    header_text.append("\n")
    header_text.append(subtitle)

    if manager.show_help:
        header_text.append("\n\n")
        header_text.append("Keyboard Controls:\n", style="yellow bold")
        header_text.append("  q - Quit dashboard\n", style="dim")
        header_text.append("  r - Refresh validation\n", style="dim")
        header_text.append("  h - Toggle this help\n", style="dim")
        header_text.append("  Ctrl+C - Emergency stop\n", style="dim")
    elif manager.last_key:
        header_text.append(f"\n\nLast key: {manager.last_key}", style="cyan")

    return Panel(header_text, title="[bold]ManifestGuard[/bold]", border_style="blue")


def create_footer_panel(manager: TUIManager) -> Panel:
    """Create a small always-visible help footer."""
    msg = f"  |  {manager.footer_message}" if manager.footer_message else ""

    text = Text()
    text.append("q", style="bold")
    text.append(":quit  ", style="dim")
    text.append("r", style="bold")
    text.append(":refresh  ", style="dim")
    text.append("h", style="bold")
    text.append(":help  ", style="dim")
    text.append("m", style="bold")
    text.append(":export-md", style="dim")
    text.append("  |  Copy: mark in terminal + Ctrl+C", style="dim")
    if msg:
        text.append(msg, style="cyan")

    return Panel(text, title="", border_style="dim")


def create_validation_panel(manager: TUIManager) -> Panel:
    """Create validation status panel."""
    if manager.validation_state in {"pending", "running"}:
        msg = (
            "Running validation..."
            if manager.validation_state == "running"
            else "Waiting to start validation..."
        )
        return Panel(msg, title="[bold]Validation Status[/bold]", border_style="blue")

    if manager.validation_state == "error":
        return Panel(
            f"❌ Validation failed\n\n{manager.validation_error or 'Unknown error'}",
            title="[bold]Validation Status[/bold]",
            border_style="red",
        )

    if not manager.validation_result:
        return Panel(
            "No validation data available",
            title="[bold]Validation Status[/bold]",
            border_style="yellow",
        )

    result = manager.validation_result
    status_text = Text()

    # Summary stats
    total_files = len(result.validated_files)
    errors = result.error_count
    warnings = result.warning_count
    infos = result.info_count

    status_text.append(f"Manifest files checked: {total_files}\n", style="dim")
    status_text.append(f"Errors: {errors}\n", style="red" if errors > 0 else "green")
    status_text.append(
        f"Warnings: {warnings}\n", style="yellow" if warnings > 0 else "green"
    )
    status_text.append(f"Infos: {infos}\n", style="blue" if infos > 0 else "dim")

    # Overall status
    if result.is_valid:
        status_text.append("\n✅ All validations passed", style="green bold")
    else:
        status_text.append(f"\n❌ {errors} error(s) need attention", style="red bold")

    return Panel(status_text, title="[bold]Validation Status[/bold]")


def create_quickfix_panel(manager: TUIManager) -> Panel:
    """Create quickfix suggestions panel."""
    from manifestguard.quickfix import get_quickfixes  # noqa: PLC0415 - avoid circular import

    if not manager.validation_result:
        return Panel("No diagnostics available", title="[bold]QuickFix Suggestions[/bold]")

    # Get all available quickfixes
    all_fixes = []
    for diagnostic in manager.validation_result.diagnostics:
        fixes = get_quickfixes(manager.workspace_root, diagnostic)
        all_fixes.extend(fixes)

    if not all_fixes:
        return Panel("No quick fixes available", title="[bold]QuickFix Suggestions[/bold]")

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Code", style="cyan", width=8)
    table.add_column("Action", style="white")
    table.add_column("Target", style="dim", width=20)

    for fix in all_fixes[:5]:  # Show top 5
        table.add_row(
            fix.diagnostic.code,
            fix.title,
            fix.diagnostic.file_path.name,
        )

    if len(all_fixes) > 5:
        table.add_row("...", f"+{len(all_fixes) - 5} more", "")

    return Panel(table, title=f"[bold]QuickFix Suggestions ({len(all_fixes)})[/bold]")


def _extended_state_gate(
    manager: TUIManager,
    *,
    title: str,
    pending_msg: str,
    no_data_msg: str,
) -> Panel | None:
    """Return a state panel for standard extended states, or None to continue."""
    if manager.extended_state in {"pending", "running"} and not manager.metrics_data:
        return Panel(pending_msg, title=title, border_style="blue")

    if manager.extended_state == "disabled" and not manager.metrics_data:
        return Panel("Extended tests are disabled", title=title, border_style="yellow")

    if manager.extended_state == "error":
        return Panel(
            f"❌ Extended tests failed\n\n{manager.extended_error or 'Unknown error'}",
            title=title,
            border_style="red",
        )

    if not manager.metrics_data:
        return Panel(no_data_msg, title=title, border_style="yellow")

    return None


def _sparkline_if_active(manager: TUIManager, series: list[float]) -> str | None:
    """Return a sparkline string for *series* if any value is non-zero, else None."""
    if not any(v > 0 for v in series):
        return None
    return manager._generate_sparkline(series)


# Intentionally complex for comprehensive metrics panel rendering with multiple categories and states
# manifestguard-ignore-next-line: COMPLEXITY
def create_metrics_panel(manager: TUIManager) -> Panel:
    """Create extended metrics summary panel."""
    title = "[bold]Extended Metrics[/bold]"
    if manager.metrics_source == "history":
        title = "[bold]Extended Metrics[/bold] [dim](last recorded)[/dim]"
    elif manager.metrics_source == "report":
        title = "[bold]Extended Metrics[/bold] [dim](last report)[/dim]"
    elif manager.metrics_source == "history+report":
        title = "[bold]Extended Metrics[/bold] [dim](history + report)[/dim]"

    if manager.extended_state in {"pending", "running"} and not manager.metrics_data:
        msg = (
            "Running extended tests..."
            if manager.extended_state == "running"
            else "Waiting to start extended tests..."
        )
        return Panel(msg, title=title, border_style="blue")

    if manager.extended_state == "disabled" and not manager.metrics_data:
        return Panel("Extended tests are disabled", title=title, border_style="yellow")

    if manager.extended_state == "error":
        return Panel(
            f"❌ Extended tests failed\n\n{manager.extended_error or 'Unknown error'}",
            title=title,
            border_style="red",
        )

    if not manager.metrics_data:
        return Panel("No metrics collected", title=title, border_style="yellow")

    # Load trend data
    trends = manager._load_history_trends()

    table = Table(show_header=True, header_style="bold green")
    table.add_column("Metric", style="cyan", width=15)
    table.add_column("Value", style="white", width=12)
    table.add_column("Trend", style="dim", width=12)
    table.add_column("Status", style="white", width=8)

    # Coverage (show weekly trend when available, fall back to per-run)
    coverage = manager.metrics_data.get("coverage", {})
    unit_cov = coverage.get("unit_percent", 0)
    unit_measured = coverage.get("unit_measured", False)
    cov_weekly = trends.get("coverage_weekly") or []
    cov_series = cov_weekly or trends.get("coverage", [])
    cov_spark = manager._generate_sparkline(cov_series)
    if not unit_measured:
        table.add_row("Coverage", "n/a", cov_spark, "•")
    else:
        table.add_row("Coverage", f"{unit_cov:.1f}%", cov_spark, "✅" if unit_cov >= 80 else "⚠️")

    # Complexity
    complexity = manager.metrics_data.get("complexity", {})
    files_scanned = complexity.get("files_scanned", 0)
    avg_complexity = (
        complexity.get("average_complexity")
        if complexity.get("average_complexity") is not None
        else complexity.get("avg_complexity")
    )
    comp_spark = manager._generate_sparkline(trends.get("complexity", []))
    if not files_scanned:
        table.add_row("Complexity", "n/a", comp_spark, "•")
    else:
        avg_num = float(avg_complexity or 0.0)
        table.add_row(
            "Complexity",
            f"{avg_num:.1f}",
            comp_spark,
            "✅" if avg_num <= 10 else "⚠️",
        )

    # Security
    security = manager.metrics_data.get("security", {})
    unsafe_count = security.get("unsafe_exec_count")
    if unsafe_count is None:
        unsafe_count = security.get("total_findings", 0)
    sec_spark = manager._generate_sparkline(trends.get("security", []))
    table.add_row(
        "Security",
        f"{unsafe_count} issues",
        sec_spark,
        "✅" if unsafe_count == 0 else "❌",
    )

    # Quality Score
    quality_score = manager.metrics_data.get("quality_score", 0)
    qual_spark = manager._generate_sparkline(trends.get("quality", []))
    table.add_row(
        "Quality Score",
        f"{quality_score:.1f}%",
        qual_spark,
        "✅" if quality_score >= 80 else "⚠️",
    )

    # BPD (Bugfixes per day)
    bugfixes = manager.metrics_data.get("bugfixes", {})
    bpd = bugfixes.get("bpd", 0.0)
    total_bugfixes = bugfixes.get("total", 0)
    bpd_spark = manager._generate_sparkline(trends.get("bpd", []))
    table.add_row(
        "BPD",
        f"{bpd:.2f} ({total_bugfixes})",
        bpd_spark,
        "✅" if bpd <= 1.0 else "⚠️",
    )

    # Ruff violations trend (only shown when at least one entry has violations)
    ruff_series = trends.get("ruff", [])
    ruff_spark = _sparkline_if_active(manager, ruff_series)
    if ruff_spark is not None:
        latest_ruff = ruff_series[-1] if ruff_series else 0.0
        table.add_row(
            "Ruff",
            f"{latest_ruff:.0f}",
            ruff_spark,
            "✅" if latest_ruff == 0 else "⚠️",
        )

    # Venv Health (sparkline only — live value comes from preflight panel)
    venv_health_series = trends.get("venv_health", [])
    vh_spark = _sparkline_if_active(manager, venv_health_series)
    if vh_spark is not None:
        latest_vh = venv_health_series[-1] if venv_health_series else 0.0
        table.add_row(
            "Venv Health",
            f"{latest_vh:.0f}%",
            vh_spark,
            "✅" if latest_vh >= 90 else ("⚠️" if latest_vh >= 50 else "❌"),
        )

    # Files / LOC (from scan space — tracked over time)
    scan_space = manager.metrics_data.get("scan_space", {})
    ss_files = scan_space.get("files", 0) if isinstance(scan_space, dict) else 0
    ss_loc = scan_space.get("lines_of_code", 0) if isinstance(scan_space, dict) else 0
    if ss_files or ss_loc:
        files_spark = manager._generate_sparkline(trends.get("scan_space_files", []))
        loc_display = f"{ss_loc:,}" if ss_loc else "n/a"
        table.add_row(
            "Files",
            f"{ss_files} ({loc_display} LOC)",
            files_spark,
            "•",
        )

    return Panel(table, title=title)


def create_dependencies_panel(manager: TUIManager) -> Panel:
    """Create dependency health panel."""
    title = "[bold]Dependencies[/bold]"
    gate = _extended_state_gate(
        manager,
        title=title,
        pending_msg="Dependency metrics pending…",
        no_data_msg="No dependency data available",
    )
    if gate is not None:
        return gate

    dep = manager.metrics_data.get("dependency", {})
    total_count = dep.get("total_count")
    direct = dep.get("direct_count", 0)
    transitive = dep.get("transitive_count", 0)
    outdated = dep.get("outdated_count", 0)
    vuln_high = dep.get("vulnerable_high", 0)
    vuln_critical = dep.get("vulnerable_critical", 0)
    vuln_total = (vuln_high or 0) + (vuln_critical or 0)
    if vuln_total == 0:
        vuln_total = dep.get("vulnerable_count", 0)

    trends = manager._load_history_trends()
    vuln_spark = manager._generate_sparkline(trends.get("vulnerable", []))

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan", width=14)
    table.add_column("Value", style="white")
    table.add_column("Status", style="white", width=3)

    if total_count is not None:
        table.add_row("Total", str(total_count), "")
    table.add_row("Direct", str(direct), "")
    table.add_row("Transitive", str(transitive), "")
    table.add_row("Outdated", str(outdated), "✅" if outdated == 0 else "⚠️")
    table.add_row(
        "Vulnerable",
        f"{vuln_total} (H:{vuln_high} C:{vuln_critical})",
        "✅" if vuln_total == 0 else "❌",
    )

    if vuln_spark:
        table.add_row("Trend", vuln_spark, "")

    return Panel(table, title=title)


def create_policy_panel(manager: TUIManager) -> Panel:
    """Create policy compliance panel."""
    title = "[bold]Policy[/bold]"
    gate = _extended_state_gate(
        manager,
        title=title,
        pending_msg="Policy metrics pending…",
        no_data_msg="No policy data available",
    )
    if gate is not None:
        return gate

    policy = manager.metrics_data.get("policy", {})
    whitelist = len(policy.get("whitelist_violations", []))
    blacklist = len(policy.get("blacklist_violations", []))
    dummy_code = policy.get("dummy_code_total_findings", 0)
    duplication_count = policy.get("duplication", {}).get("duplicate_groups_count", 0)

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan", width=12)
    table.add_column("Value", style="white")
    table.add_column("Status", style="white", width=3)

    table.add_row("Whitelist", str(whitelist), "✅" if whitelist == 0 else "⚠️")
    table.add_row("Blacklist", str(blacklist), "✅" if blacklist == 0 else "❌")
    table.add_row("Dummy Code", str(dummy_code), "✅" if dummy_code == 0 else "⚠️")
    table.add_row("Duplicates", str(duplication_count), "✅" if duplication_count == 0 else "⚠️")

    return Panel(table, title=title)


def create_sbom_panel(manager: TUIManager) -> Panel:
    """Create SBOM compliance panel."""
    title = "[bold]SBOM[/bold]"
    gate = _extended_state_gate(
        manager,
        title=title,
        pending_msg="SBOM metrics pending…",
        no_data_msg="No SBOM data available",
    )
    if gate is not None:
        return gate

    sbom = manager.metrics_data.get("sbom", {})
    components = sbom.get("components_count", 0)
    missing_licenses = sbom.get("missing_licenses", 0)
    unknown_origins = sbom.get("unknown_origins", 0)
    spdx_compliant = sbom.get("spdx_compliance", False)

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan", width=12)
    table.add_column("Value", style="white")
    table.add_column("Status", style="white", width=3)

    table.add_row("Components", str(components), "")
    table.add_row("No License", str(missing_licenses), "✅" if missing_licenses == 0 else "⚠️")
    table.add_row("Unknown", str(unknown_origins), "✅" if unknown_origins == 0 else "⚠️")
    table.add_row("SPDX", "Yes" if spdx_compliant else "No", "✅" if spdx_compliant else "❌")

    return Panel(table, title=title)


def create_packaging_panel(manager: TUIManager) -> Panel:
    """Create packaging quality panel."""
    title = "[bold]Packaging[/bold]"
    gate = _extended_state_gate(
        manager,
        title=title,
        pending_msg="Packaging metrics pending…",
        no_data_msg="No packaging data available",
    )
    if gate is not None:
        return gate

    pkg = manager.metrics_data.get("packaging", {})
    missing_classifiers = len(pkg.get("missing_classifiers", []))
    has_py_typed = pkg.get("has_py_typed", False)
    version_ok = pkg.get("version_consistency", True)
    readme_ok = pkg.get("readme_present", True)
    license_ok = pkg.get("license_present", True)

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan", width=12)
    table.add_column("Value", style="white")
    table.add_column("Status", style="white", width=3)

    table.add_row(
        "Classifiers", str(missing_classifiers), "✅" if missing_classifiers == 0 else "⚠️"
    )
    table.add_row("py.typed", "Yes" if has_py_typed else "No", "✅" if has_py_typed else "⚠️")
    table.add_row("Version", "OK" if version_ok else "Mismatch", "✅" if version_ok else "❌")
    table.add_row("README", "Yes" if readme_ok else "No", "✅" if readme_ok else "⚠️")
    table.add_row("LICENSE", "Yes" if license_ok else "No", "✅" if license_ok else "❌")

    return Panel(table, title=title)


def create_license_panel(manager: TUIManager) -> Panel:
    """Create license compliance panel."""
    title = "[bold]License[/bold]"
    gate = _extended_state_gate(
        manager,
        title=title,
        pending_msg="License metrics pending…",
        no_data_msg="No license data available",
    )
    if gate is not None:
        return gate

    lic = manager.metrics_data.get("license", {})
    spdx_mismatches = len(lic.get("spdx_mismatches", []))
    license_missing = lic.get("license_file_missing", False)
    conflicts = len(lic.get("conflicting_notices", []))

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan", width=12)
    table.add_column("Value", style="white")
    table.add_column("Status", style="white", width=3)

    table.add_row("SPDX Errors", str(spdx_mismatches), "✅" if spdx_mismatches == 0 else "❌")
    table.add_row(
        "File", "Missing" if license_missing else "Present", "❌" if license_missing else "✅"
    )
    table.add_row("Conflicts", str(conflicts), "✅" if conflicts == 0 else "⚠️")

    return Panel(table, title=title)


def create_performance_panel(manager: TUIManager) -> Panel:
    """Create performance metrics panel."""
    title = "[bold]Performance[/bold]"
    gate = _extended_state_gate(
        manager,
        title=title,
        pending_msg="Performance metrics pending…",
        no_data_msg="No performance data available",
    )
    if gate is not None:
        return gate

    perf = manager.metrics_data.get("performance", {})
    total_ms = perf.get("total_analysis_ms", 0)
    manifest_ms = perf.get("manifest_parse_ms", 0)
    rule_ms = perf.get("rule_engine_ms", 0)
    dep_ms = perf.get("dependency_graph_ms", 0)

    def _fmt_submetric(value: object) -> str:
        if isinstance(value, (int, float)) and float(value) > 0:
            return f"{float(value):.0f}ms"
        return "n/a"

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan", width=12)
    table.add_column("Value", style="white")
    table.add_column("Status", style="white", width=3)

    table.add_row("Total", f"{total_ms:.0f}ms", "✅" if total_ms < 5000 else "⚠️")
    table.add_row("Manifest", _fmt_submetric(manifest_ms), "")
    table.add_row(
        "Rules",
        _fmt_submetric(rule_ms),
        "✅" if isinstance(rule_ms, (int, float)) and float(rule_ms) > 0 and float(rule_ms) < 1000 else ("" if _fmt_submetric(rule_ms) == "n/a" else "⚠️"),
    )
    table.add_row(
        "Deps",
        _fmt_submetric(dep_ms),
        "✅" if isinstance(dep_ms, (int, float)) and float(dep_ms) > 0 and float(dep_ms) < 2000 else ("" if _fmt_submetric(dep_ms) == "n/a" else "⚠️"),
    )

    return Panel(table, title=title)


def create_progress_panel(manager: TUIManager) -> Panel:
    """Create progress/status panel with simple bar."""
    # Build a simple bar from step/total
    total = max(manager.progress_total, 1)
    step = max(min(manager.progress_step, total), 0)
    width = 30
    filled = int(width * step / total)
    bar = "█" * filled + "─" * (width - filled)

    # Advance spinner
    manager.spinner_index = (manager.spinner_index + 1) % len(manager.spinner_frames)
    spinner = manager.spinner_frames[manager.spinner_index]

    text = Text()
    text.append(f"{spinner} {manager.progress_message}\n", style="bold")
    if manager.tests_current is not None and manager.tests_total is not None:
        text.append(f"Tests {manager.tests_current}/{manager.tests_total}\n", style="cyan")
    if manager.eta_seconds is not None:
        # Format ETA mm:ss
        mins = manager.eta_seconds // 60
        secs = manager.eta_seconds % 60
        text.append(f"ETA ~ {mins}:{secs:02d}\n", style="dim")
    text.append(f"[{bar}] {step}/{total}", style="green" if step >= total else "cyan")
    return Panel(text, title="[bold]Progress[/bold]")
