from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, cast

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from manifestguard.ai.shared_preferences import get_shared_preferences


class GuiAIMixin:
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _create_ai_tab(self) -> QWidget:
        """AI Assistant settings with 4 sub-tabs: Config, Models, Guide, Advanced."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Sub-tabs for AI settings
        ai_tabs = QTabWidget()

        # Config Tab - Basic AI settings
        config_tab = self._create_ai_config_tab()
        ai_tabs.addTab(config_tab, "⚙️ Config")

        # Models Tab - Provider selection & model management
        models_tab = self._create_ai_models_tab()
        ai_tabs.addTab(models_tab, "🤖 Models")

        # Guide Tab - Usage instructions
        guide_tab = self._create_ai_guide_tab()
        ai_tabs.addTab(guide_tab, "📖 Guide")

        # Advanced Tab - Expert settings
        advanced_tab = self._create_ai_advanced_tab()
        ai_tabs.addTab(advanced_tab, "🔬 Advanced")

        layout.addWidget(ai_tabs)

        # Save/Load buttons at bottom
        buttons = QHBoxLayout()
        btn_load = QPushButton("Load AI Settings")
        btn_load.clicked.connect(self._load_ai_settings)
        buttons.addWidget(btn_load)

        btn_save = QPushButton("Save AI Settings")
        btn_save.clicked.connect(self._save_ai_settings)
        buttons.addWidget(btn_save)

        buttons.addStretch()
        layout.addLayout(buttons)

        return widget

    def _create_ai_config_tab(self) -> QWidget:
        """Config Tab: Basic AI settings."""
        config_tab = QWidget()
        config_layout = QVBoxLayout(config_tab)

        # AI Hints
        hints_group = QGroupBox("AI Analysis & Recommendations")
        hints_layout = QVBoxLayout(hints_group)

        self.ai_hints_checkbox = QCheckBox("Enable AI-powered code analysis")
        self.ai_hints_checkbox.setToolTip(
            "Show AI recommendations:\n"
            "• Package version conflict resolution\n"
            "• Dependency optimization suggestions\n"
            "• Security vulnerability warnings\n"
            "• Manifest quality improvements"
        )
        self.ai_hints_checkbox.stateChanged.connect(self._auto_save_ai_settings)
        hints_layout.addWidget(self.ai_hints_checkbox)

        self.ai_preflight_checkbox = QCheckBox("Enable AI analysis after VENV preflight")
        self.ai_preflight_checkbox.setToolTip(
            "Analyze VENV health check results with AI:\n"
            "• Zombie/dead process cleanup recommendations\n"
            "• Registry hygiene suggestions\n"
            "• Performance optimization tips\n"
            "• Risk assessment across multiple VENVs"
        )
        self.ai_preflight_checkbox.stateChanged.connect(self._auto_save_ai_settings)
        hints_layout.addWidget(self.ai_preflight_checkbox)

        config_layout.addWidget(hints_group)

        # Tooling Advisor
        tooling_group = QGroupBox("Preferred Package Manager")
        tooling_layout = QVBoxLayout(tooling_group)

        tooling_layout.addWidget(QLabel("AI will provide recommendations optimized for:"))
        self.ai_tooling_combo = QComboBox()
        self.ai_tooling_combo.addItems(["uv", "pdm", "poetry", "pip", "setuptools"])
        self.ai_tooling_combo.currentTextChanged.connect(self._auto_save_ai_settings)
        tooling_layout.addWidget(self.ai_tooling_combo)

        tooling_note = QLabel(
            "<b>Note:</b> This only changes the recommended commands/examples. "
            "Package storage (history, wheels, summaries) is the same regardless of tool."
        )
        tooling_note.setWordWrap(True)
        tooling_note.setStyleSheet("color: #666; padding: 6px; font-size: 9pt;")
        tooling_layout.addWidget(tooling_note)

        tooling_info = QLabel(
            "<b>uv:</b> Fastest resolver, Rust-based, great for CI/CD<br>"
            "<b>PDM:</b> Modern PEP 621/pyproject.toml workflow<br>"
            "<b>Poetry:</b> Popular, batteries-included, rich commands<br>"
            "<b>pip:</b> Standard Python tool, widely compatible<br>"
            "<b>setuptools:</b> Classic Python packaging"
        )
        tooling_info.setWordWrap(True)
        tooling_info.setStyleSheet("color: #888; padding: 10px; font-size: 10pt;")
        tooling_layout.addWidget(tooling_info)

        config_layout.addWidget(tooling_group)
        config_layout.addStretch()

        return config_tab

    def _create_ai_models_tab(self) -> QWidget:
        """Models Tab: Provider selection & model management."""
        models_tab = QWidget()
        models_layout = QVBoxLayout(models_tab)

        # Provider Selection
        provider_group = QGroupBox("AI Provider")
        provider_layout = QVBoxLayout(provider_group)

        provider_layout.addWidget(QLabel("Select AI provider for code analysis:"))
        self.ai_provider_combo = QComboBox()
        self.ai_provider_combo.addItems(
            [
                "Local (Ollama)",
                "OpenAI",
                "Anthropic Claude",
                "DeepSeek",
                "Azure OpenAI",
                "None",
            ]
        )
        self.ai_provider_combo.currentTextChanged.connect(self._update_model_list)
        self.ai_provider_combo.currentTextChanged.connect(self._auto_save_ai_settings)
        provider_layout.addWidget(self.ai_provider_combo)

        models_layout.addWidget(provider_group)

        # Model Selection
        model_group = QGroupBox("Model Selection")
        model_layout = QVBoxLayout(model_group)

        # Model dropdown with editable search
        model_search_layout = QHBoxLayout()
        model_search_layout.addWidget(QLabel("Model:"))
        self.ai_model_combo = QComboBox()
        self.ai_model_combo.setEditable(True)
        self.ai_model_combo.setToolTip(
            "Type to search or select from dropdown.\n"
            "For Ollama: model names like 'qwen2.5-coder:7b'\n"
            "For cloud providers: 'gpt-4-turbo', 'claude-3-sonnet', etc."
        )
        self.ai_model_combo.currentTextChanged.connect(self._auto_save_ai_settings)
        model_search_layout.addWidget(self.ai_model_combo)

        # Action buttons
        btn_show_installed = QPushButton("📋 Installed")
        btn_show_installed.setToolTip("Show installed models from Ollama and load into dropdown")
        btn_show_installed.clicked.connect(self._show_installed_models)
        model_search_layout.addWidget(btn_show_installed)

        btn_ask_ai = QPushButton("💡 Ask AI")
        btn_ask_ai.setToolTip("Get AI recommendations: which model is best for manifest analysis")
        btn_ask_ai.clicked.connect(self._ask_ai_for_recommendation)
        model_search_layout.addWidget(btn_ask_ai)

        btn_install = QPushButton("📥 Install")
        btn_install.setToolTip("Download and install selected model via Ollama")
        btn_install.clicked.connect(self._install_model)
        model_search_layout.addWidget(btn_install)

        model_layout.addLayout(model_search_layout)

        # Model info
        model_help = QLabel(
            "<b>Tip:</b> Type to search or use 'Ask AI' for recommendations.<br>"
            "<b>Recommended:</b> qwen2.5-coder:7b (local), gpt-4-turbo (cloud)"
        )
        model_help.setWordWrap(True)
        model_help.setStyleSheet("color: #666; font-size: 9pt; padding: 5px;")
        model_layout.addWidget(model_help)

        # API Key (masked input)
        api_key_layout = QHBoxLayout()
        api_key_layout.addWidget(QLabel("API Key:"))
        self.ai_api_key_edit = QLineEdit()
        self.ai_api_key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.ai_api_key_edit.setPlaceholderText("Enter API key (stored securely in system keyring)")
        api_key_layout.addWidget(self.ai_api_key_edit)

        btn_save_key = QPushButton("💾 Save")
        btn_save_key.setToolTip("Save API key to secure keyring storage")
        btn_save_key.clicked.connect(self._save_api_key)
        api_key_layout.addWidget(btn_save_key)

        model_layout.addLayout(api_key_layout)

        model_info = QLabel(
            "<b>Note:</b> API keys are stored securely in your system keyring.<br>"
            "For local models (Ollama), no API key is required."
        )
        model_info.setWordWrap(True)
        model_info.setStyleSheet("color: #666; font-size: 9pt; padding: 5px;")
        model_layout.addWidget(model_info)

        models_layout.addWidget(model_group)
        models_layout.addStretch()

        return models_tab

    def _create_ai_guide_tab(self) -> QWidget:
        """Guide Tab: Usage instructions."""
        guide_tab = QWidget()
        guide_layout = QVBoxLayout(guide_tab)
        guide_text = QTextEdit()
        guide_text.setReadOnly(True)
        guide_text.setHtml(
            "<h2>🤖 AI Assistant Usage Guide</h2>"
            "<h3>What does the AI Assistant do?</h3>"
            "<p>The AI Assistant provides intelligent recommendations for:</p>"
            "<ul>"
            "<li><b>Manifest Validation:</b> Detects issues in pyproject.toml, setup.py</li>"
            "<li><b>Dependency Analysis:</b> Finds conflicts, security issues, deprecated packages</li>"
            "<li><b>Code Quality:</b> Suggests improvements for packaging & distribution</li>"
            "<li><b>Tooling Advisor:</b> Recommends optimal package manager for your workflow</li>"
            "</ul>"
            "<h3>🔹 How to use AI Analysis</h3>"
            "<ol>"
            "<li>Enable <b>'AI-powered code analysis'</b> in Config tab</li>"
            "<li>Select your AI provider in Models tab</li>"
            "<li>Run validation from the Validation tab</li>"
            "<li>View AI recommendations in the results</li>"
            "</ol>"
            "<h3>🔹 Supported Providers</h3>"
            "<ul>"
            "<li><b>Local (Ollama):</b> Privacy-first, runs offline, free</li>"
            "<li><b>OpenAI:</b> GPT-4, GPT-3.5-turbo (requires API key)</li>"
            "<li><b>Anthropic Claude:</b> Claude-3 models (requires API key)</li>"
            "<li><b>DeepSeek:</b> Specialized coding models</li>"
            "<li><b>Azure OpenAI:</b> Enterprise deployment</li>"
            "</ul>"
            "<h3>🔹 Recommended Models</h3>"
            "<p><b>For local/offline use:</b></p>"
            "<ul>"
            "<li><code>qwen2.5-coder:7b</code> - Best quality, 8GB RAM</li>"
            "<li><code>deepseek-coder:6.7b</code> - Fast, efficient</li>"
            "<li><code>codellama:13b</code> - Meta's code specialist</li>"
            "</ul>"
            "<p><b>For cloud use:</b></p>"
            "<ul>"
            "<li><code>gpt-4-turbo</code> - Best for complex analysis</li>"
            "<li><code>claude-3-sonnet</code> - Balanced quality/cost</li>"
            "<li><code>deepseek-coder</code> - Cost-effective coding</li>"
            "</ul>"
            "<h3>🔹 Privacy & Data</h3>"
            "<p><b>Your code never leaves your machine.</b> The AI only analyzes:</p>"
            "<ul>"
            "<li>Package names and versions (public PyPI metadata)</li>"
            "<li>Manifest files (pyproject.toml, setup.py)</li>"
            "<li>Dependency relationships</li>"
            "</ul>"
            "<p>No source code, credentials, or sensitive data is sent to AI providers.</p>"
            "<h3>🔹 Getting Started with Ollama</h3>"
            "<ol>"
            "<li>Install Ollama: <a href='https://ollama.ai'>https://ollama.ai</a></li>"
            "<li>Run: <code>ollama pull qwen2.5-coder:7b</code></li>"
            "<li>Verify: <code>ollama list</code></li>"
            "<li>That's it! No API keys needed.</li>"
            "</ol>"
        )
        guide_layout.addWidget(guide_text)

        return guide_tab

    def _create_ai_advanced_tab(self) -> QWidget:
        """Advanced Tab: Expert settings."""
        advanced_tab = QWidget()
        advanced_layout = QVBoxLayout(advanced_tab)

        advanced_group = QGroupBox("Advanced AI Settings")
        advanced_group_layout = QVBoxLayout(advanced_group)

        self.ai_auto_analyze_checkbox = QCheckBox("Auto-analyze on validation")
        self.ai_auto_analyze_checkbox.setToolTip("Automatically run AI analysis after each validation")
        self.ai_auto_analyze_checkbox.stateChanged.connect(self._auto_save_ai_settings)
        advanced_group_layout.addWidget(self.ai_auto_analyze_checkbox)

        self.ai_security_scan_checkbox = QCheckBox("Enable security vulnerability scanning")
        self.ai_security_scan_checkbox.setToolTip("Check packages against known CVE databases")
        self.ai_security_scan_checkbox.stateChanged.connect(self._auto_save_ai_settings)
        advanced_group_layout.addWidget(self.ai_security_scan_checkbox)

        self.ai_suggest_updates_checkbox = QCheckBox("Suggest package updates")
        self.ai_suggest_updates_checkbox.setToolTip("Recommend newer stable versions when available")
        self.ai_suggest_updates_checkbox.stateChanged.connect(self._auto_save_ai_settings)
        advanced_group_layout.addWidget(self.ai_suggest_updates_checkbox)

        # Context window
        context_layout = QHBoxLayout()
        context_layout.addWidget(QLabel("Analysis context window:"))
        self.ai_context_spin = QSpinBox()
        self.ai_context_spin.setRange(1, 50)
        self.ai_context_spin.setValue(10)
        self.ai_context_spin.setSuffix(" recent checks")
        self.ai_context_spin.setToolTip("Number of recent validation results to include in analysis")
        self.ai_context_spin.valueChanged.connect(self._auto_save_ai_settings)
        context_layout.addWidget(self.ai_context_spin)
        context_layout.addStretch()
        advanced_group_layout.addLayout(context_layout)

        # Temperature
        temp_layout = QHBoxLayout()
        temp_layout.addWidget(QLabel("AI Temperature:"))
        self.ai_temperature_spin = QSpinBox()
        self.ai_temperature_spin.setRange(0, 100)
        self.ai_temperature_spin.setValue(20)
        self.ai_temperature_spin.setSuffix(" (0=deterministic, 100=creative)")
        self.ai_temperature_spin.setToolTip("Controls AI response randomness. Lower = more focused.")
        self.ai_temperature_spin.valueChanged.connect(self._auto_save_ai_settings)
        temp_layout.addWidget(self.ai_temperature_spin)
        temp_layout.addStretch()
        advanced_group_layout.addLayout(temp_layout)

        advanced_layout.addWidget(advanced_group)
        advanced_layout.addStretch()

        return advanced_tab

    def _load_ai_settings(self) -> None:
        """Load AI settings from shared preferences and GUI state."""
        try:
            prefs = get_shared_preferences(config_file=self._get_manifestguard_json_path())
            config = prefs.get_provider_config()

            # Provider mapping
            provider_map = {
                "ollama": "Local (Ollama)",
                "openai-compatible": "OpenAI",
            }
            provider_display = provider_map.get(config.provider, "Local (Ollama)")

            self.ai_provider_combo.setCurrentText(provider_display)
            if config.model:
                self.ai_model_combo.setCurrentText(config.model)

            # Load GUI-specific settings from gui.json
            state = self._load_gui_state()
            ai_settings = state.get("aiSettings", {})

            # Load AI hints checkbox state (default: True)
            hints_enabled = state.get("ai_hints_enabled")
            if hints_enabled is None:
                hints_enabled = ai_settings.get("hintsEnabled", True)
            self.ai_hints_checkbox.setChecked(bool(hints_enabled))

            # Load AI preflight checkbox state (default: False)
            preflight_enabled = state.get("preflight_ai_enabled")
            if preflight_enabled is None:
                preflight_enabled = ai_settings.get("preflightEnabled", False)
            self.ai_preflight_checkbox.setChecked(bool(preflight_enabled))

        except Exception as e:
            QMessageBox.warning(cast(QWidget, self), "Load Settings Error", f"Failed to load AI settings:\n{e}")

    def _save_ai_settings(self) -> None:
        """Save AI settings to shared preferences and GUI state."""
        try:
            # Provider mapping
            provider_display = self.ai_provider_combo.currentText()
            provider_map = {
                "Local (Ollama)": "ollama",
                "OpenAI": "openai-compatible",
                "Anthropic Claude": "openai-compatible",
                "DeepSeek": "openai-compatible",
                "Azure OpenAI": "openai-compatible",
            }
            provider = provider_map.get(provider_display, "ollama")

            # Save GUI-specific settings to gui.json
            state = self._load_gui_state()
            state["ai_hints_enabled"] = self.ai_hints_checkbox.isChecked()
            state["preflight_ai_enabled"] = self.ai_preflight_checkbox.isChecked()

            # Backward-compat bucket for earlier GUI iterations
            state["aiSettings"] = {
                "hintsEnabled": self.ai_hints_checkbox.isChecked(),
                "preflightEnabled": self.ai_preflight_checkbox.isChecked(),
                "provider": provider,
                "model": self.ai_model_combo.currentText(),
            }
            self._save_gui_state(state)

            # Persist provider/model into active manifestguard.json using mgpy-local AI settings.
            self._merge_manifestguard_json_settings(
                updates={
                    "manifestguard.ai.provider": provider,
                    "manifestguard.ai.model": self.ai_model_combo.currentText(),
                }
            )
            _ = get_shared_preferences(config_file=self._get_manifestguard_json_path())

            QMessageBox.information(cast(QWidget, self), "Settings Saved", "AI settings saved successfully!")

        except Exception as e:
            QMessageBox.critical(cast(QWidget, self), "Save Error", f"Failed to save AI settings:\n{e}")

    def _auto_save_ai_settings(self) -> None:
        """Auto-save AI settings when checkboxes/combos change."""
        try:
            state = self._load_gui_state()
            ai_settings = state.get("aiSettings", {})

            # Update only changed settings
            state["ai_hints_enabled"] = self.ai_hints_checkbox.isChecked()
            state["preflight_ai_enabled"] = self.ai_preflight_checkbox.isChecked()

            ai_settings["hintsEnabled"] = self.ai_hints_checkbox.isChecked()
            ai_settings["preflightEnabled"] = self.ai_preflight_checkbox.isChecked()

            provider_display = self.ai_provider_combo.currentText()
            provider_map = {
                "Local (Ollama)": "ollama",
                "OpenAI": "openai-compatible",
                "Anthropic Claude": "openai-compatible",
                "DeepSeek": "openai-compatible",
                "Azure OpenAI": "openai-compatible",
            }
            ai_settings["provider"] = provider_map.get(provider_display, "ollama")
            ai_settings["model"] = self.ai_model_combo.currentText()

            state["aiSettings"] = ai_settings
            self._save_gui_state(state)
        except Exception:
            pass  # Silent auto-save, don't interrupt user

    def _update_model_list(self) -> None:
        """Update model dropdown based on selected provider."""
        provider = self.ai_provider_combo.currentText()

        model_map = {
            "Local (Ollama)": [
                "qwen2.5-coder:7b",
                "deepseek-coder:6.7b",
                "codellama:13b",
                "deepseek-coder:33b",
            ],
            "OpenAI": ["gpt-4-turbo", "gpt-4", "gpt-3.5-turbo"],
            "Anthropic Claude": ["claude-3-opus", "claude-3-sonnet", "claude-3-haiku"],
            "DeepSeek": ["deepseek-coder", "deepseek-chat"],
            "Azure OpenAI": ["gpt-4-turbo", "gpt-4", "gpt-35-turbo"],
            "None": [],
        }

        self.ai_model_combo.clear()
        models = model_map.get(provider, [])
        if models:
            self.ai_model_combo.addItems(models)
        else:
            self.ai_model_combo.addItem("(No model required)")

    def _show_installed_models(self) -> None:
        """Fetch installed models from Ollama."""
        provider = self.ai_provider_combo.currentText()

        if provider != "Local (Ollama)":
            QMessageBox.information(
                cast(QWidget, self),
                "Not Applicable",
                "This feature is only available for Ollama.\n"
                "For cloud providers, models are available instantly via API.",
            )
            return

        try:
            import urllib.request

            prefs = get_shared_preferences()
            config = prefs.get_provider_config()
            url = f"{config.base_url}/api/tags"

            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                models = [m["name"] for m in data.get("models", [])]

                if not models:
                    QMessageBox.information(
                        cast(QWidget, self),
                        "No Models",
                        "No Ollama models installed.\n\n"
                        "Install with: ollama pull qwen2.5-coder:7b",
                    )
                    return

                # Update dropdown
                current_text = self.ai_model_combo.currentText()
                self.ai_model_combo.clear()
                self.ai_model_combo.addItems(models)

                # Restore selection
                idx = self.ai_model_combo.findText(current_text)
                if idx >= 0:
                    self.ai_model_combo.setCurrentIndex(idx)

                QMessageBox.information(
                    cast(QWidget, self),
                    "Models Loaded",
                    f"✅ Found {len(models)} installed models.\n\n" + "\n".join(models[:10]),
                )

        except Exception as e:
            QMessageBox.warning(
                cast(QWidget, self),
                "Connection Error",
                f"Cannot connect to Ollama:\n{e}\n\n"
                "Make sure Ollama is running (https://ollama.ai)",
            )

    def _ask_ai_for_recommendation(self) -> None:
        """Show AI model recommendations."""
        provider = self.ai_provider_combo.currentText()

        recommendations = {
            "Local (Ollama)": (
                "<h3>💡 Recommended Ollama Models for ManifestGuard</h3>"
                "<ul>"
                "<li><b>qwen2.5-coder:7b</b> - Excellent for Python, 8GB RAM</li>"
                "<li><b>deepseek-coder:6.7b</b> - Fast & efficient</li>"
                "<li><b>codellama:13b</b> - Meta's code specialist</li>"
                "</ul>"
                "<p><b>Best choice:</b> <code>qwen2.5-coder:7b</code></p>"
            ),
            "OpenAI": (
                "<h3>💡 Recommended OpenAI Models</h3>"
                "<ul>"
                "<li><b>gpt-4-turbo</b> - Best for complex analysis</li>"
                "<li><b>gpt-4</b> - Reliable reasoning</li>"
                "<li><b>gpt-3.5-turbo</b> - Fast & cost-effective</li>"
                "</ul>"
            ),
            "Anthropic Claude": (
                "<h3>💡 Recommended Claude Models</h3>"
                "<ul>"
                "<li><b>claude-3-sonnet</b> - Balanced quality/cost</li>"
                "<li><b>claude-3-opus</b> - Highest quality</li>"
                "</ul>"
            ),
        }

        msg = QMessageBox(cast(QWidget, self))
        msg.setWindowTitle(f"AI Recommendations - {provider}")
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(recommendations.get(provider, "No recommendations available."))
        msg.setIcon(QMessageBox.Icon.Information)
        msg.exec()

    def _install_model(self) -> None:
        """Install model via Ollama."""
        provider = self.ai_provider_combo.currentText()
        model = self.ai_model_combo.currentText()

        if provider != "Local (Ollama)":
            QMessageBox.information(
                cast(QWidget, self),
                "Not Applicable",
                f"Model installation is only for Ollama.\n" f"For {provider}, use their web dashboard.",
            )
            return

        if not model or model == "(No model required)":
            QMessageBox.warning(cast(QWidget, self), "No Model", "Please type or select a model name.")
            return

        reply = QMessageBox.question(
            cast(QWidget, self),
            "Install Model",
            f"Download and install '{model}' via Ollama?\n\n"
            "This may take several minutes.\n\nContinue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )

        if reply != QMessageBox.StandardButton.Yes:
            return

        # Async model installation with progress dialog may be added later
        QMessageBox.information(
            cast(QWidget, self),
            "Installation",
            f"Model installation not yet implemented.\n\n"
            f"For now, install via terminal:\n"
            f"ollama pull {model}",
        )

    def _save_api_key(self) -> None:
        """Save API key to keyring."""
        api_key = self.ai_api_key_edit.text()
        if not api_key:
            QMessageBox.warning(cast(QWidget, self), "No API Key", "Please enter an API key first.")
            return

        provider = self.ai_provider_combo.currentText()
        provider_map = {
            "OpenAI": "openai",
            "Anthropic Claude": "openai",
            "DeepSeek": "openai",
            "Azure OpenAI": "openai",
        }
        provider_key = provider_map.get(provider)

        if not provider_key:
            QMessageBox.warning(cast(QWidget, self), "No API Key Needed", f"{provider} does not require an API key.")
            return

        try:
            prefs = get_shared_preferences()
            success = prefs.set_api_key(provider_key, api_key)

            if success:
                QMessageBox.information(
                    cast(QWidget, self),
                    "API Key Saved",
                    f"✅ API key saved securely for {provider}.",
                )
                self.ai_api_key_edit.clear()
            else:
                QMessageBox.warning(
                    cast(QWidget, self),
                    "Save Failed",
                    "Failed to save API key (keyring not available)",
                )

        except Exception as e:
            QMessageBox.critical(cast(QWidget, self), "Error", f"Failed to save API key:\n{e}")
