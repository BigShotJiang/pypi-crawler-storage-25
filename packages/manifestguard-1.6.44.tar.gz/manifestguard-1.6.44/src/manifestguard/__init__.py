"""ManifestGuard - Python Package Manifest Validation

Author: Nejat Philip Eryigit
Email: info@ready-4-it.com
Website: https://www.ready-4-it.com
Repository: https://github.com/timejunky/r4it_manifest_guard_py

Copyright (c) 2025 Nejat Philip Eryigit
Proprietary. All rights reserved.
"""

from importlib import metadata as importlib_metadata
from pathlib import Path
import subprocess
from typing import Final

from ._version import __version__ as _generated_version

__author__ = "Nejat Philip Eryigit"
__email__ = "info@ready-4-it.com"
__url__ = "https://www.ready-4-it.com"
__copyright__ = "Copyright (c) 2025 Nejat Philip Eryigit"
__license__ = "LicenseRef-Proprietary"

_PACKAGE_NAME: Final[str] = "manifestguard"
_PACKAGE_ROOT: Final[Path] = Path(__file__).resolve().parents[2]


def get_runtime_version() -> str:
    """Resolve the current package version for the active runtime context."""
    if (_PACKAGE_ROOT / ".git").exists():
        try:
            result = subprocess.run(
                ["git", "describe", "--tags", "--dirty", "--always"],
                cwd=_PACKAGE_ROOT,
                capture_output=True,
                text=True,
                check=True,
                timeout=5,
            )
            version = result.stdout.strip()
            if version:
                return version.removeprefix("v")
        except Exception:
            pass

        try:
            from setuptools_scm import get_version as get_scm_version

            return get_scm_version(root=str(_PACKAGE_ROOT), relative_to=__file__)
        except Exception:
            pass

    try:
        return importlib_metadata.version(_PACKAGE_NAME)
    except importlib_metadata.PackageNotFoundError:
        return _generated_version
    except Exception:
        return _generated_version


__version__ = get_runtime_version()

# Configuration file schema/version (separate from package version)
CONFIG_SCHEMA_VERSION: Final[str] = "0.3.1"

# Package metadata
VERSION: Final[str] = __version__
AUTHOR: Final[str] = __author__
EMAIL: Final[str] = __email__
URL: Final[str] = __url__
COPYRIGHT: Final[str] = __copyright__
LICENSE: Final[str] = __license__

# Simplified Quick Check API (top-level import)
# Use: import manifestguard.quickcheck as qc
from . import quickcheck  # noqa: E402

# Telemetry schema models (Task-018) - for external dashboard integration
from .models.telemetry import (
    ComplexityHotspot,
    ComplexityTelemetry,
    CoverageTelemetry,
    DuplicationTelemetry,
    DummyRecognitionTelemetry,
    QualityTelemetry,
    RadonTelemetry,
    RuffTelemetry,
    SecurityTelemetry,
)

__all__ = [
    "AUTHOR",
    "ComplexityHotspot",
    "ComplexityTelemetry",
    "CONFIG_SCHEMA_VERSION",
    "COPYRIGHT",
    "CoverageTelemetry",
    "DuplicationTelemetry",
    "DummyRecognitionTelemetry",
    "EMAIL",
    "LICENSE",
    "QualityTelemetry",
    "RadonTelemetry",
    "RuffTelemetry",
    "SecurityTelemetry",
    "URL",
    "VERSION",
    "__author__",
    "__copyright__",
    "__email__",
    "__license__",
    "__url__",
    "__version__",
    "get_runtime_version",
    "quickcheck",
]
