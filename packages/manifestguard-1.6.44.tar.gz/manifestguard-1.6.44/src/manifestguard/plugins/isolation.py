"""Plugin Isolation

Provides error boundaries and resource cleanup for plugins.
"""

import logging
import sys
import traceback
from collections.abc import Callable, Generator
from contextlib import contextmanager
from typing import Any

logger = logging.getLogger(__name__)


class PluginIsolation:
    """Plugin isolation manager

    Provides:
    1. Error boundaries (catch plugin exceptions)
    2. Resource cleanup (cleanup on failure)
    3. Import isolation (separate import context)

    Example:
        >>> isolation = PluginIsolation()
        >>> with isolation.error_boundary("my_plugin"):
        ...     # Plugin code here
        ...     pass

    """

    def __init__(self) -> None:
        """Initialize plugin isolation"""
        self._cleanup_handlers: dict[str, list[Callable]] = {}

    @contextmanager
    def error_boundary(self, plugin_id: str) -> Generator[None, None, None]:
        """Error boundary for plugin execution

        Catches and logs exceptions without crashing core.

        Args:
            plugin_id: Plugin ID for error reporting

        Yields:
            None

        Example:
            >>> isolation = PluginIsolation()
            >>> with isolation.error_boundary("my_plugin"):
            ...     risky_plugin_code()

        """
        try:
            yield
        except KeyboardInterrupt:
            # Don't catch keyboard interrupts
            raise
        except SystemExit:
            # Don't catch system exits
            raise
        except Exception as e:
            # Log error with traceback
            logger.error(
                f"Plugin '{plugin_id}' raised exception: {e}\n" f"{traceback.format_exc()}",
            )

            # Run cleanup handlers
            self._run_cleanup(plugin_id)

    def register_cleanup(self, plugin_id: str, cleanup_func: Callable) -> None:
        """Register cleanup handler for plugin

        Args:
            plugin_id: Plugin ID
            cleanup_func: Cleanup function to call on error

        Example:
            >>> isolation = PluginIsolation()
            >>> isolation.register_cleanup("my_plugin", lambda: close_db())

        """
        if plugin_id not in self._cleanup_handlers:
            self._cleanup_handlers[plugin_id] = []

        self._cleanup_handlers[plugin_id].append(cleanup_func)

    def _run_cleanup(self, plugin_id: str) -> None:
        """Run cleanup handlers for plugin

        Args:
            plugin_id: Plugin ID

        """
        handlers = self._cleanup_handlers.get(plugin_id, [])

        for handler in handlers:
            try:
                handler()
            except Exception as e:
                logger.error(f"Cleanup handler for '{plugin_id}' failed: {e}")

        # Clear handlers after running
        if plugin_id in self._cleanup_handlers:
            del self._cleanup_handlers[plugin_id]

    @contextmanager
    def isolated_import(self, plugin_id: str) -> Generator[None, None, None]:
        """Isolated import context for plugin

        Restores sys.modules state after plugin load to prevent pollution.

        Args:
            plugin_id: Plugin ID

        Yields:
            None

        Example:
            >>> isolation = PluginIsolation()
            >>> with isolation.isolated_import("my_plugin"):
            ...     import some_plugin_dependency

        """
        # Save current modules
        original_modules = sys.modules.copy()

        try:
            yield
        finally:
            # Restore original modules (remove plugin additions)
            # Keep core modules and newly imported core dependencies
            new_modules = set(sys.modules.keys()) - set(original_modules.keys())

            for module_name in new_modules:
                # Only remove plugin-specific modules
                if module_name.startswith(plugin_id) or module_name.startswith(
                    "manifestguard.external"
                ):
                    sys.modules.pop(module_name, None)


class PluginErrorBoundary:
    """Decorator for plugin method error boundaries

    Example:
        >>> @PluginErrorBoundary.wrap("my_plugin")
        ... def plugin_method():
        ...     # risky code
        ...     pass

    """

    @staticmethod
    def wrap(plugin_id: str) -> Callable:
        """Wrap function with error boundary

        Args:
            plugin_id: Plugin ID for error reporting

        Returns:
            Decorator function

        Example:
            >>> @PluginErrorBoundary.wrap("my_plugin")
            ... def risky_function():
            ...     pass

        """

        def decorator(func: Callable) -> Callable:
            def wrapper(*args: Any, **kwargs: Any) -> Any | None:
                isolation = PluginIsolation()
                with isolation.error_boundary(plugin_id):
                    return func(*args, **kwargs)

            return wrapper

        return decorator
