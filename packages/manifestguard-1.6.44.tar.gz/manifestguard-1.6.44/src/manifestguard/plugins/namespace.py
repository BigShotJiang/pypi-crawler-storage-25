"""Namespace Manager

Manages hierarchical namespaces and validates naming conventions.
"""

import re


class NamespaceManager:
    """Namespace manager for plugins and config keys

    Namespace Structure:
    - manifestguard.core.*          - Reserved for core (internal only)
    - manifestguard.plugins.*       - Official plugins
    - manifestguard.external.*      - Third-party plugins

    Config Key Structure:
    - <plugin_namespace>.<category>.<key>

    Example:
        >>> nm = NamespaceManager()
        >>> nm.is_valid_plugin_id("manifestguard.plugins.security")
        True
        >>> nm.is_core_namespace("manifestguard.core.validation")
        True

    """

    # Reserved namespaces
    CORE_NAMESPACE = "manifestguard.core"
    PLUGINS_NAMESPACE = "manifestguard.plugins"
    EXTERNAL_NAMESPACE = "manifestguard.external"

    # Valid namespace pattern: manifestguard.<category>.<name>[.<sub>]*
    NAMESPACE_PATTERN = re.compile(
        r"^manifestguard\.(core|plugins|external)\.[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$",
    )

    # Config key pattern: <namespace>.<key>
    CONFIG_KEY_PATTERN = re.compile(
        r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$",
    )

    def __init__(self) -> None:
        """Initialize namespace manager"""
        self._reserved_names: set[str] = {
            "manifestguard",
            "core",
            "plugins",
            "external",
            "config",
            "api",
            "cli",
            "validation",
            "extended",
            "i18n",
            "licensing",
        }

    def is_valid_plugin_id(self, plugin_id: str) -> bool:
        """Check if plugin ID follows naming conventions

        Args:
            plugin_id: Plugin ID to validate

        Returns:
            True if valid

        Example:
            >>> nm = NamespaceManager()
            >>> nm.is_valid_plugin_id("manifestguard.plugins.security")
            True
            >>> nm.is_valid_plugin_id("my-plugin")
            False

        """
        return bool(self.NAMESPACE_PATTERN.match(plugin_id))

    def is_core_namespace(self, plugin_id: str) -> bool:
        """Check if plugin ID is in core namespace

        Args:
            plugin_id: Plugin ID

        Returns:
            True if in core namespace

        """
        return plugin_id.startswith(self.CORE_NAMESPACE + ".")

    def is_official_namespace(self, plugin_id: str) -> bool:
        """Check if plugin ID is in official plugins namespace

        Args:
            plugin_id: Plugin ID

        Returns:
            True if in official namespace

        """
        return plugin_id.startswith(self.PLUGINS_NAMESPACE + ".")

    def is_external_namespace(self, plugin_id: str) -> bool:
        """Check if plugin ID is in external namespace

        Args:
            plugin_id: Plugin ID

        Returns:
            True if in external namespace

        """
        return plugin_id.startswith(self.EXTERNAL_NAMESPACE + ".")

    def get_namespace_category(self, plugin_id: str) -> str | None:
        """Get namespace category (core/plugins/external)

        Args:
            plugin_id: Plugin ID

        Returns:
            Namespace category or None if invalid

        Example:
            >>> nm = NamespaceManager()
            >>> nm.get_namespace_category("manifestguard.plugins.security")
            'plugins'

        """
        if not self.is_valid_plugin_id(plugin_id):
            return None

        parts = plugin_id.split(".")
        if len(parts) >= 2 and parts[0] == "manifestguard":
            return parts[1]

        return None

    def is_valid_config_key(self, config_key: str) -> bool:
        """Check if config key follows naming conventions

        Args:
            config_key: Config key to validate

        Returns:
            True if valid

        Example:
            >>> nm = NamespaceManager()
            >>> nm.is_valid_config_key("security.scan_dependencies")
            True
            >>> nm.is_valid_config_key("Security.Scan")
            False

        """
        return bool(self.CONFIG_KEY_PATTERN.match(config_key))

    def is_reserved_name(self, name: str) -> bool:
        """Check if name is reserved

        Args:
            name: Name to check

        Returns:
            True if reserved

        """
        return name.lower() in self._reserved_names

    def namespace_config_key(self, plugin_id: str, key: str) -> str:
        """Create namespaced config key

        Args:
            plugin_id: Plugin ID
            key: Config key (without plugin prefix)

        Returns:
            Namespaced config key

        Example:
            >>> nm = NamespaceManager()
            >>> nm.namespace_config_key("manifestguard.plugins.security", "scan_deps")
            'security.scan_deps'

        """
        # Extract plugin name from ID
        # manifestguard.plugins.security -> security
        parts = plugin_id.split(".")
        if len(parts) >= 3:
            plugin_name = parts[2]
            return f"{plugin_name}.{key}"

        return key

    def extract_plugin_name(self, plugin_id: str) -> str | None:
        """Extract plugin name from ID

        Args:
            plugin_id: Plugin ID

        Returns:
            Plugin name or None

        Example:
            >>> nm = NamespaceManager()
            >>> nm.extract_plugin_name("manifestguard.plugins.security")
            'security'

        """
        if not self.is_valid_plugin_id(plugin_id):
            return None

        parts = plugin_id.split(".")
        if len(parts) >= 3:
            return parts[2]

        return None
