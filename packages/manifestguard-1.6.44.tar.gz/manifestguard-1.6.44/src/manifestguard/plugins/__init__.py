"""Plugin System for ManifestGuard

Hierarchical namespace management and plugin architecture for extensibility.

Namespaces:
- manifestguard.core.*     - Internal core functionality
- manifestguard.plugins.*  - Official plugins
- manifestguard.external.* - Third-party plugins

Design Goals:
1. Prevent plugin conflicts (name collisions, config keys)
2. Plugin isolation (separate import contexts, error boundaries)
3. Entry point discovery (automatic plugin loading)
4. Config key namespacing (prevent collisions in manifestguard.json)
5. Graceful degradation (plugin failures don't crash core)
"""

from .isolation import PluginIsolation
from .loader import PluginLoader
from .namespace import NamespaceManager
from .registry import Plugin, PluginMetadata, PluginRegistry

__all__ = [
    "NamespaceManager",
    "Plugin",
    "PluginIsolation",
    "PluginLoader",
    "PluginMetadata",
    "PluginRegistry",
]
