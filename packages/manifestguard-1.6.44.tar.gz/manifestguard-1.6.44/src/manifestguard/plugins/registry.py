"""Plugin Registry

Central registry for plugin management with conflict detection.
Inspired by VS Code Extension activation and Python entry_points.
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class PluginStatus(str, Enum):
    """Plugin lifecycle status"""

    DISCOVERED = "discovered"  # Found but not loaded
    LOADING = "loading"  # Currently loading
    ACTIVE = "active"  # Loaded and activated
    FAILED = "failed"  # Failed to load/activate
    DISABLED = "disabled"  # Explicitly disabled


class PluginNamespace(str, Enum):
    """Plugin namespace categories"""

    CORE = "manifestguard.core"  # Internal core (reserved)
    PLUGINS = "manifestguard.plugins"  # Official plugins
    EXTERNAL = "manifestguard.external"  # Third-party plugins


@dataclass
class PluginMetadata:
    """Plugin metadata (similar to package.json engines, contributes)

    Attributes:
        id: Unique plugin identifier (e.g., "manifestguard.plugins.security")
        name: Human-readable name
        version: Plugin version (semver)
        namespace: Plugin namespace (core/plugins/external)
        description: Short description
        author: Plugin author
        requires: List of required plugin IDs
        provides: List of capabilities this plugin provides
        config_keys: List of config keys this plugin uses
        entry_point: Entry point name (for discovery)

    Example:
        >>> metadata = PluginMetadata(
        ...     id="manifestguard.plugins.security",
        ...     name="Security Scanner",
        ...     version="1.0.0",
        ...     namespace=PluginNamespace.PLUGINS,
        ...     config_keys=["security.scan_dependencies", "security.check_licenses"]
        ... )

    """

    id: str
    name: str
    version: str
    namespace: PluginNamespace
    description: str = ""
    author: str = ""
    requires: list[str] = field(default_factory=list)
    provides: list[str] = field(default_factory=list)
    config_keys: list[str] = field(default_factory=list)
    entry_point: str = ""


@dataclass
class Plugin:
    """Plugin instance

    Attributes:
        metadata: Plugin metadata
        status: Current status
        instance: Loaded plugin instance
        error: Error message if failed

    """

    metadata: PluginMetadata
    status: PluginStatus = PluginStatus.DISCOVERED
    instance: Any | None = None
    error: str | None = None


class PluginRegistry:
    """Central plugin registry with conflict detection

    Manages plugin lifecycle:
    1. Discovery (via entry_points)
    2. Validation (metadata, dependencies)
    3. Loading (import & instantiation)
    4. Activation (initialize)
    5. Conflict detection (IDs, config keys)

    Example:
        >>> registry = PluginRegistry()
        >>> registry.discover_plugins()
        >>> registry.load_all()
        >>> for plugin in registry.get_active():
        ...     print(f"{plugin.metadata.name} - {plugin.status}")

    """

    def __init__(self) -> None:
        """Initialize empty registry"""
        self._plugins: dict[str, Plugin] = {}
        self._config_keys: dict[str, str] = {}  # config_key -> plugin_id
        self._capabilities: dict[str, list[str]] = {}  # capability -> [plugin_ids]
        self._load_order: list[str] = []

    def register(self, plugin: Plugin) -> bool:
        """Register a plugin

        Args:
            plugin: Plugin to register

        Returns:
            True if registered, False if conflicts detected

        Raises:
            ValueError: If plugin ID already registered

        """
        plugin_id = plugin.metadata.id

        # Check for ID conflict
        if plugin_id in self._plugins:
            existing = self._plugins[plugin_id]
            logger.error(
                f"Plugin ID conflict: {plugin_id} already registered "
                f"(existing: {existing.metadata.version}, new: {plugin.metadata.version})",
            )
            return False

        # Check for namespace conflicts
        if not self._validate_namespace(plugin.metadata):
            return False

        # Check for config key conflicts
        if not self._check_config_conflicts(plugin.metadata):
            return False

        # Register plugin
        self._plugins[plugin_id] = plugin

        # Register config keys
        for key in plugin.metadata.config_keys:
            self._config_keys[key] = plugin_id

        # Register capabilities
        for capability in plugin.metadata.provides:
            if capability not in self._capabilities:
                self._capabilities[capability] = []
            self._capabilities[capability].append(plugin_id)

        logger.info(f"Registered plugin: {plugin_id} ({plugin.metadata.name})")
        return True

    def unregister(self, plugin_id: str) -> bool:
        """Unregister a plugin

        Args:
            plugin_id: Plugin ID to unregister

        Returns:
            True if unregistered, False if not found

        """
        if plugin_id not in self._plugins:
            return False

        plugin = self._plugins[plugin_id]

        # Remove config keys
        for key in plugin.metadata.config_keys:
            self._config_keys.pop(key, None)

        # Remove capabilities
        for capability in plugin.metadata.provides:
            if capability in self._capabilities:
                self._capabilities[capability].remove(plugin_id)
                if not self._capabilities[capability]:
                    del self._capabilities[capability]

        # Remove from load order
        if plugin_id in self._load_order:
            self._load_order.remove(plugin_id)

        # Remove plugin
        del self._plugins[plugin_id]

        logger.info(f"Unregistered plugin: {plugin_id}")
        return True

    def get(self, plugin_id: str) -> Plugin | None:
        """Get plugin by ID

        Args:
            plugin_id: Plugin ID

        Returns:
            Plugin or None if not found

        """
        return self._plugins.get(plugin_id)

    def get_all(self) -> list[Plugin]:
        """Get all registered plugins"""
        return list(self._plugins.values())

    def get_active(self) -> list[Plugin]:
        """Get all active plugins"""
        return [p for p in self._plugins.values() if p.status == PluginStatus.ACTIVE]

    def get_by_capability(self, capability: str) -> list[Plugin]:
        """Get plugins providing a capability

        Args:
            capability: Capability name

        Returns:
            List of plugins providing this capability

        """
        plugin_ids = self._capabilities.get(capability, [])
        return [self._plugins[pid] for pid in plugin_ids if pid in self._plugins]

    def get_load_order(self) -> list[str]:
        """Get plugin load order (topological sort by dependencies)

        Returns:
            List of plugin IDs in load order

        """
        if self._load_order:
            return self._load_order.copy()

        # Build dependency graph
        graph: dict[str, set[str]] = {}
        for plugin_id, plugin in self._plugins.items():
            graph[plugin_id] = set(plugin.metadata.requires)

        # Topological sort
        visited: set[str] = set()
        order: list[str] = []

        def visit(node: str) -> None:
            if node in visited:
                return
            visited.add(node)
            for dep in graph.get(node, set()):
                if dep in graph:
                    visit(dep)
            order.append(node)

        for plugin_id in graph:
            visit(plugin_id)

        self._load_order = order
        return order.copy()

    def check_conflicts(self) -> list[str]:
        """Check for conflicts in registry

        Returns:
            List of conflict descriptions

        """
        conflicts = []

        # Check for duplicate config keys
        key_usage: dict[str, list[str]] = {}
        for plugin_id, plugin in self._plugins.items():
            for key in plugin.metadata.config_keys:
                if key not in key_usage:
                    key_usage[key] = []
                key_usage[key].append(plugin_id)

        for key, users in key_usage.items():
            if len(users) > 1:
                conflicts.append(
                    f"Config key '{key}' used by multiple plugins: {', '.join(users)}",
                )

        # Check for missing dependencies
        for plugin_id, plugin in self._plugins.items():
            for dep in plugin.metadata.requires:
                if dep not in self._plugins:
                    conflicts.append(
                        f"Plugin '{plugin_id}' requires missing plugin: {dep}",
                    )

        return conflicts

    def _validate_namespace(self, metadata: PluginMetadata) -> bool:
        """Validate plugin namespace

        Args:
            metadata: Plugin metadata

        Returns:
            True if namespace is valid

        """
        plugin_id = metadata.id
        namespace = metadata.namespace

        # Check if ID matches namespace
        if not plugin_id.startswith(namespace):
            logger.error(
                f"Plugin ID '{plugin_id}' does not match namespace '{namespace}'",
            )
            return False

        # Check if core namespace is used by non-core plugin
        if namespace == PluginNamespace.CORE and not plugin_id.startswith("manifestguard.core."):
            # Only allow core namespace for internal plugins
            logger.error(
                f"Plugin '{plugin_id}' cannot use reserved 'core' namespace",
            )
            return False

        return True

    def _check_config_conflicts(self, metadata: PluginMetadata) -> bool:
        """Check for config key conflicts

        Args:
            metadata: Plugin metadata

        Returns:
            True if no conflicts

        """
        for key in metadata.config_keys:
            if key in self._config_keys:
                existing_plugin = self._config_keys[key]
                logger.error(
                    f"Config key conflict: '{key}' already used by plugin '{existing_plugin}'",
                )
                return False

        return True

    def get_plugin_for_config_key(self, config_key: str) -> str | None:
        """Get plugin ID that owns a config key

        Args:
            config_key: Config key (e.g., "security.scan_dependencies")

        Returns:
            Plugin ID or None

        """
        return self._config_keys.get(config_key)
