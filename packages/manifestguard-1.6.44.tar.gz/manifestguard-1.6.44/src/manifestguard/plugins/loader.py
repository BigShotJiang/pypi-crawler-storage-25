"""Plugin Loader

Discovers and loads plugins via entry_points.
"""

import logging
from importlib.metadata import EntryPoint, entry_points

from .registry import Plugin, PluginMetadata, PluginNamespace, PluginStatus

logger = logging.getLogger(__name__)


class PluginLoader:
    """Plugin loader with entry_point discovery

    Discovers plugins via entry_points:
    [project.entry-points."manifestguard.plugins"]
    my_plugin = "my_package.plugin:setup"

    Example:
        >>> loader = PluginLoader()
        >>> plugins = loader.discover()
        >>> print(f"Found {len(plugins)} plugins")

    """

    # Entry point group names
    ENTRY_POINT_GROUP_PLUGINS = "manifestguard.plugins"
    ENTRY_POINT_GROUP_VALIDATORS = "manifestguard.validators"
    ENTRY_POINT_GROUP_COLLECTORS = "manifestguard.collectors"

    def __init__(self) -> None:
        """Initialize plugin loader"""
        self._discovered: dict[str, EntryPoint] = {}

    def discover(self, group: str | None = None) -> list[Plugin]:
        """Discover plugins via entry_points

        Args:
            group: Entry point group (default: all manifestguard.* groups)

        Returns:
            List of discovered plugins

        Example:
            >>> loader = PluginLoader()
            >>> plugins = loader.discover()

        """
        plugins: list[Plugin] = []

        # Determine which groups to scan
        if group:
            groups = [group]
        else:
            groups = [
                self.ENTRY_POINT_GROUP_PLUGINS,
                self.ENTRY_POINT_GROUP_VALIDATORS,
                self.ENTRY_POINT_GROUP_COLLECTORS,
            ]

        # Scan entry points
        for group_name in groups:
            try:
                # Python 3.10+ API
                eps = entry_points(group=group_name)

                for ep in eps:
                    plugin = self._create_plugin_from_entry_point(ep, group_name)
                    if plugin:
                        plugins.append(plugin)
                        self._discovered[plugin.metadata.id] = ep
            except Exception as e:
                logger.error(f"Error discovering plugins in group '{group_name}': {e}")

        logger.info(f"Discovered {len(plugins)} plugin(s)")
        return plugins

    def load(self, plugin: Plugin) -> bool:
        """Load a plugin

        Args:
            plugin: Plugin to load

        Returns:
            True if loaded successfully

        """
        if plugin.status == PluginStatus.ACTIVE:
            logger.warning(f"Plugin '{plugin.metadata.id}' already loaded")
            return True

        plugin.status = PluginStatus.LOADING

        try:
            # Get entry point
            ep = self._discovered.get(plugin.metadata.id)
            if not ep:
                raise ValueError(f"No entry point found for plugin '{plugin.metadata.id}'")

            # Load entry point
            setup_func = ep.load()

            # Call setup function
            if callable(setup_func):
                plugin.instance = setup_func()
            else:
                plugin.instance = setup_func

            plugin.status = PluginStatus.ACTIVE
            logger.info(f"Loaded plugin: {plugin.metadata.id}")
            return True

        except Exception as e:
            plugin.status = PluginStatus.FAILED
            plugin.error = str(e)
            logger.error(f"Failed to load plugin '{plugin.metadata.id}': {e}")
            return False

    def unload(self, plugin: Plugin) -> bool:
        """Unload a plugin

        Args:
            plugin: Plugin to unload

        Returns:
            True if unloaded successfully

        """
        if plugin.status != PluginStatus.ACTIVE:
            return True

        try:
            # Call cleanup if available
            if plugin.instance and hasattr(plugin.instance, "cleanup"):
                plugin.instance.cleanup()

            plugin.instance = None
            plugin.status = PluginStatus.DISCOVERED
            logger.info(f"Unloaded plugin: {plugin.metadata.id}")
            return True

        except Exception as e:
            logger.error(f"Failed to unload plugin '{plugin.metadata.id}': {e}")
            return False

    def _create_plugin_from_entry_point(
        self,
        ep: EntryPoint,
        group: str,
    ) -> Plugin | None:
        """Create Plugin from entry_point

        Args:
            ep: EntryPoint
            group: Entry point group name

        Returns:
            Plugin or None if failed

        """
        try:
            # Determine namespace from group
            is_plugin_group = group == self.ENTRY_POINT_GROUP_PLUGINS or group in [
                self.ENTRY_POINT_GROUP_VALIDATORS,
                self.ENTRY_POINT_GROUP_COLLECTORS,
            ]
            namespace = PluginNamespace.PLUGINS if is_plugin_group else PluginNamespace.EXTERNAL

            # Create plugin ID
            plugin_id = f"{namespace}.{ep.name}"

            # Create metadata
            metadata = PluginMetadata(
                id=plugin_id,
                name=ep.name,
                version="unknown",
                namespace=namespace,
                entry_point=f"{group}:{ep.name}",
            )

            return Plugin(
                metadata=metadata,
                status=PluginStatus.DISCOVERED,
            )

        except Exception as e:
            logger.error(f"Failed to create plugin from entry_point '{ep.name}': {e}")
            return None
