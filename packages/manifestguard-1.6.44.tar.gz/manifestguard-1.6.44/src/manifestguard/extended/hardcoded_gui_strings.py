"""Detect hardcoded GUI strings in Python GUI sources.

This is a focused scanner intended to catch common GUI-string patterns (PySide6/
PyQt/Tk-style API usage) that should typically be localized via ManifestGuard's
i18n framework.

Scope (best-effort):
- Scans `src/gui/**/*.py` (and `gui/**/*.py` as fallback)
- Detects direct string literals in common GUI APIs (setText, QLabel("..."), etc.)
- Respects ignore patterns and inline suppressions

Inline suppression:
- `# manifestguard-ignore-line: I18N-HARDCODED-STRING`
- `# manifestguard-ignore-next-line: I18N-HARDCODED-STRING`
- `# manifestguard-ignore-line: I18N` (coarse)
- `# manifestguard-ignore-next-line: I18N` (coarse)

The scanner is intentionally heuristic (regex-based) to stay fast and avoid
parsing dependencies.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from manifestguard.validation.inline_markers import is_line_suppressed

from .filesystem_safety import safe_read_file, safe_rglob
from .hardcoded_strings_common import (
    STRING_LITERAL_RE,
    coerce_bool,
    coerce_nonneg_int,
    coerce_str_list,
    filter_paths_by_include_exclude,
    get_first_dict_block,
    is_comment_line,
    load_manifestguard_json_dict,
    relpath_for_report,
    should_consider_string,
    slugify_for_i18n_key,
    update_triple_quote_state,
)
from .scan_utils import load_ignore_patterns, should_skip_path


I18N_HARDCODED_GUI_STRING_CODE = "I18N-HARDCODED-STRING"


@dataclass
class HardcodedGuiStringsResult:
    scanned_files: int = 0
    total_findings: int = 0
    unique_strings: int = 0
    findings: list[dict[str, object]] = field(default_factory=list)


@dataclass(frozen=True)
class HardcodedGuiStringsConfig:
    enabled: bool = True
    include: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)
    max_findings: int = 0  # 0 = unlimited


def _slugify_for_i18n_key(value: str) -> str | None:
    return slugify_for_i18n_key("gui", value)


def _is_suppressed(path: Path, line: int) -> bool:
    return is_line_suppressed(path, line, "I18N") or is_line_suppressed(
        path, line, I18N_HARDCODED_GUI_STRING_CODE
    )


def load_hardcoded_gui_strings_config_from_manifestguard_json(
    workspace_root: Path,
) -> HardcodedGuiStringsConfig:
    """Load hardcoded GUI strings scan config from manifestguard.json.

    Supported shapes (best-effort):

    - {"checks": {"i18nHardcodedGuiStrings": {"enabled": true, ...}}}
    - {"i18nHardcodedGuiStrings": {...}}
    - {"i18n": {"hardcodedGuiStrings": {...}}}
    - {"settings": {"i18nHardcodedGuiStrings": {...}}}

    Accepted keys:
    - enabled: bool
    - include: list[str] (glob patterns against workspace-relative paths)
    - exclude: list[str]
    - maxFindings: int
    """

    raw = load_manifestguard_json_dict(workspace_root)
    if raw is None:
        return HardcodedGuiStringsConfig()

    block = get_first_dict_block(
        raw,
        [
            ("checks", "i18nHardcodedGuiStrings"),
            ("i18nHardcodedGuiStrings",),
            ("i18n", "hardcodedGuiStrings"),
            ("settings", "i18nHardcodedGuiStrings"),
        ],
    )
    if block is None:
        return HardcodedGuiStringsConfig()

    enabled = coerce_bool(block.get("enabled"), True)
    include = coerce_str_list(block.get("include"))
    exclude = coerce_str_list(block.get("exclude"))
    max_findings = coerce_nonneg_int(block.get("maxFindings"), 0)

    return HardcodedGuiStringsConfig(enabled=enabled, include=include, exclude=exclude, max_findings=max_findings)


def _iter_gui_python_files(
    workspace_root: Path,
    config: HardcodedGuiStringsConfig,
) -> list[Path]:
    ignore = load_ignore_patterns(workspace_root)

    roots: list[Path] = []
    src_gui = workspace_root / "src" / "gui"
    if src_gui.exists() and src_gui.is_dir():
        roots.append(src_gui)

    gui = workspace_root / "gui"
    if gui.exists() and gui.is_dir():
        roots.append(gui)

    files: list[Path] = []
    for root in roots:
        for py_file in safe_rglob(root, "*.py", max_files=25000):
            if should_skip_path(py_file, ignore, workspace_root):
                continue
            files.append(py_file)

    # Deterministic ordering for stable reports/tests.
    files.sort(key=lambda p: str(p).replace("\\", "/").lower())

    return filter_paths_by_include_exclude(
        workspace_root,
        files,
        include=config.include,
        exclude=config.exclude,
    )


# Patterns for direct string literals in common GUI APIs.
# These patterns intentionally require the literal to appear directly in the call
# (i.e., NOT t("key")) to avoid flagging localized code.
_GUI_LINE_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("setWindowTitle", re.compile(r"\.setWindowTitle\(\s*['\"]")),
    ("setText", re.compile(r"\.setText\(\s*['\"]")),
    ("setPlaceholderText", re.compile(r"\.setPlaceholderText\(\s*['\"]")),
    ("setToolTip", re.compile(r"\.setToolTip\(\s*['\"]")),
    ("setStatusTip", re.compile(r"\.setStatusTip\(\s*['\"]")),
    ("setWhatsThis", re.compile(r"\.setWhatsThis\(\s*['\"]")),
    ("addItem", re.compile(r"\.addItem\(\s*['\"]")),
    ("setTabText", re.compile(r"\.setTabText\(\s*[^,]+,\s*['\"]")),
    ("addTab", re.compile(r"\.addTab\(\s*[^,]+,\s*['\"]")),
    ("QLabel", re.compile(r"\bQLabel\(\s*['\"]")),
    ("QPushButton", re.compile(r"\bQPushButton\(\s*['\"]")),
    ("QGroupBox", re.compile(r"\bQGroupBox\(\s*['\"]")),
    ("QCheckBox", re.compile(r"\bQCheckBox\(\s*['\"]")),
    ("QRadioButton", re.compile(r"\bQRadioButton\(\s*['\"]")),
    ("QMenu", re.compile(r"\bQMenu\(\s*['\"]")),
    ("QAction", re.compile(r"\bQAction\(\s*['\"]")),
]


def _build_gui_string_finding(
    *,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    kind: str,
    raw: str,
) -> dict[str, object]:
    suggested = _slugify_for_i18n_key(raw)
    return {
        "code": I18N_HARDCODED_GUI_STRING_CODE,
        "file": relpath_for_report(workspace_root, py_file),
        "line": line_no,
        "kind": kind,
        "value": raw,
        "suggestedKey": suggested,
        "suggestedReplacement": (f't("{suggested}", module="gui")' if suggested else None),
    }


def _extend_findings_with_limit(
    findings: list[dict[str, object]],
    new_findings: list[dict[str, object]],
    max_findings: int,
) -> bool:
    """Extend findings and return True if the max limit is reached."""

    if not new_findings:
        return False

    if not max_findings:
        findings.extend(new_findings)
        return False

    remaining = max_findings - len(findings)
    if remaining <= 0:
        return True

    findings.extend(new_findings[:remaining])
    return len(findings) >= max_findings


def _find_horizontal_header_label_findings(
    *,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    line: str,
    unique: set[str],
) -> list[dict[str, object]] | None:
    if "setHorizontalHeaderLabels" not in line or "[" not in line or "]" not in line:
        return None

    m = re.search(r"setHorizontalHeaderLabels\(\s*\[(?P<inner>[^\]]*)\]", line)
    if not m:
        return []

    inner = m.group("inner")
    out: list[dict[str, object]] = []
    for s_m in STRING_LITERAL_RE.finditer(inner):
        raw = s_m.group("text")
        if not should_consider_string(raw):
            continue
        unique.add(raw)
        out.append(
            _build_gui_string_finding(
                workspace_root=workspace_root,
                py_file=py_file,
                line_no=line_no,
                kind="setHorizontalHeaderLabels",
                raw=raw,
            )
        )
    return out


def _find_qmessagebox_findings(
    *,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    line: str,
    unique: set[str],
) -> list[dict[str, object]] | None:
    if "QMessageBox." not in line or "(" not in line:
        return None

    if not re.search(r"\bQMessageBox\.(information|warning|critical|question)\(", line):
        return []

    out: list[dict[str, object]] = []
    for s_m in STRING_LITERAL_RE.finditer(line):
        raw = s_m.group("text")
        if not should_consider_string(raw):
            continue
        unique.add(raw)
        out.append(
            _build_gui_string_finding(
                workspace_root=workspace_root,
                py_file=py_file,
                line_no=line_no,
                kind="QMessageBox",
                raw=raw,
            )
        )
    return out


def _find_general_gui_pattern_finding(
    *,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    line: str,
    unique: set[str],
) -> dict[str, object] | None:
    for kind, rx in _GUI_LINE_PATTERNS:
        if not rx.search(line):
            continue

        m = STRING_LITERAL_RE.search(line)
        if not m:
            return None

        raw = m.group("text")
        if not should_consider_string(raw):
            return None

        unique.add(raw)
        return _build_gui_string_finding(
            workspace_root=workspace_root,
            py_file=py_file,
            line_no=line_no,
            kind=kind,
            raw=raw,
        )

    return None


def scan_hardcoded_gui_strings(
    workspace_root: Path,
    config: HardcodedGuiStringsConfig | None = None,
) -> HardcodedGuiStringsResult:
    """Scan GUI python sources for hardcoded user-facing strings."""

    cfg = config or load_hardcoded_gui_strings_config_from_manifestguard_json(workspace_root)

    result = HardcodedGuiStringsResult()
    findings: list[dict[str, object]] = []
    unique: set[str] = set()

    if not cfg.enabled:
        return result

    files = _iter_gui_python_files(workspace_root, cfg)
    result.scanned_files = len(files)

    for py_file in files:
        if _scan_single_gui_file(
            workspace_root=workspace_root,
            py_file=py_file,
            cfg=cfg,
            findings=findings,
            unique=unique,
        ):
            break

    result.total_findings = len(findings)
    result.unique_strings = len(unique)

    # Keep the raw finding list; callers should cap before serialization if needed.
    result.findings = findings
    return result


def _scan_single_gui_file(
    *,
    workspace_root: Path,
    py_file: Path,
    cfg: HardcodedGuiStringsConfig,
    findings: list[dict[str, object]],
    unique: set[str],
) -> bool:
    """Scan a single GUI Python file and extend findings.

    Returns True if the global max_findings limit has been reached and
    scanning should stop.
    """

    content = safe_read_file(py_file, max_bytes=10 * 1024 * 1024)
    if not content:
        return False

    in_triple: str | None = None

    for line_no, line in enumerate(content.splitlines(), start=1):
        in_triple = update_triple_quote_state(line, in_triple)
        if in_triple or is_comment_line(line) or _is_suppressed(py_file, line_no):
            continue

        header_findings = _find_horizontal_header_label_findings(
            workspace_root=workspace_root,
            py_file=py_file,
            line_no=line_no,
            line=line,
            unique=unique,
        )
        if header_findings is not None:
            if _extend_findings_with_limit(findings, header_findings, cfg.max_findings):
                return True
            continue

        msgbox_findings = _find_qmessagebox_findings(
            workspace_root=workspace_root,
            py_file=py_file,
            line_no=line_no,
            line=line,
            unique=unique,
        )
        if msgbox_findings is not None:
            if _extend_findings_with_limit(findings, msgbox_findings, cfg.max_findings):
                return True
            continue

        one_finding = _find_general_gui_pattern_finding(
            workspace_root=workspace_root,
            py_file=py_file,
            line_no=line_no,
            line=line,
            unique=unique,
        )
        if one_finding:
            if _extend_findings_with_limit(findings, [one_finding], cfg.max_findings):
                return True

    return bool(cfg.max_findings and len(findings) >= cfg.max_findings)
