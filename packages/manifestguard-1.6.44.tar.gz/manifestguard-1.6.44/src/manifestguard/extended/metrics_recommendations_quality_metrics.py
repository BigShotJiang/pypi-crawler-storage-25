from __future__ import annotations

from typing import TYPE_CHECKING

from .metrics import Recommendation

if TYPE_CHECKING:
    from .metrics import ExtendedTestMetrics


class _MetricsRecommendationsQualityMetricsMixin:
    def _project_declares_dependencies(self) -> bool:
        pyproject = getattr(self, "workspace_root", None)
        if pyproject is None:
            return False
        try:
            from .dependency_collection import _declared_dependency_names  # noqa: PLC0415

            return bool(_declared_dependency_names(pyproject))
        except Exception:
            return False

    def _recommend_packaging_gaps(self, metrics: "ExtendedTestMetrics") -> list[Recommendation]:
        recs: list[Recommendation] = []
        if not metrics.packaging.has_py_typed:
            recs.append(
                Recommendation(
                    category="packaging",
                    id="missing-py-typed",
                    priority="low",
                    summary="py.typed marker file missing",
                    proposed_fix="Add empty 'py.typed' file to enable type distribution",
                    confidence=0.95,
                ),
            )

        if not metrics.packaging.readme_present:
            recs.append(
                Recommendation(
                    category="packaging",
                    id="missing-readme",
                    priority="high",
                    summary="README file missing",
                    proposed_fix="Create README.md with usage examples and installation steps",
                    confidence=1.0,
                ),
            )

        if not metrics.packaging.license_present:
            recs.append(
                Recommendation(
                    category="packaging",
                    id="missing-license",
                    priority="high",
                    summary="LICENSE file missing",
                    proposed_fix="Add LICENSE file matching pyproject.toml license field",
                    confidence=1.0,
                ),
            )
        return recs

    def _recommend_sbom_followups(self, metrics: "ExtendedTestMetrics") -> list[Recommendation]:
        recs: list[Recommendation] = []
        if metrics.sbom.components_count > 0:
            missing_licenses = metrics.sbom.missing_licenses
            if missing_licenses > metrics.sbom.components_count * 0.2:
                recs.append(
                    Recommendation(
                        category="sbom",
                        id="incomplete-sbom-licenses",
                        priority="low",
                        summary=(
                            f"SBOM incomplete: {missing_licenses}/{metrics.sbom.components_count} "
                            f"dependencies missing license information"
                        ),
                        proposed_fix=(
                            "Update SBOM generation to include all license information. "
                            "Use pip-licenses or scancode-toolkit for better detection."
                        ),
                        confidence=0.85,
                        effort_minutes=30,
                        impact_score=4,
                        code_example=(
                            "# Generate comprehensive SBOM with licenses\n"
                            "$ pip install pip-licenses\n"
                            "$ pip-licenses --format=json --output-file=licenses.json\n\n"
                            "# Or use scancode for deeper analysis\n"
                            "$ pip install scancode-toolkit\n"
                            "$ scancode --license --copyright --package --json-pp sbom.json ."
                        ),
                        guide_url="https://www.ready-4-it.com/mgpy/guides/sbom-quality",
                    ),
                )
        return recs

    def _recommend_performance_tuning(self, metrics: "ExtendedTestMetrics") -> list[Recommendation]:
        recs: list[Recommendation] = []
        if metrics.performance.total_analysis_ms > 5000:
            slow_components: list[str] = []
            dependency_share = metrics.performance.dependency_graph_ms / max(
                metrics.performance.total_analysis_ms,
                1.0,
            )
            if metrics.performance.dependency_graph_ms > 2000 and dependency_share >= 0.05:
                slow_components.append(
                    f"dependency analysis ({metrics.performance.dependency_graph_ms:.0f}ms)",
                )
            if metrics.performance.rule_engine_ms > 1000:
                slow_components.append(
                    f"rule engine ({metrics.performance.rule_engine_ms:.0f}ms)",
                )

            if slow_components:
                total_seconds = metrics.performance.total_analysis_ms / 1000
                slow_summary = ", ".join(slow_components[:2])
                recs.append(
                    Recommendation(
                        category="performance",
                        id="slow-analysis-performance",
                        priority="low",
                        summary=(
                            f"Analysis is slow ({total_seconds:.1f}s). "
                            f"Bottlenecks: {slow_summary}"
                        ),
                        proposed_fix=(
                            "Profile with cProfile to identify hotspots. "
                            "Consider caching, parallel processing, or algorithm optimization."
                        ),
                        confidence=0.75,
                        effort_minutes=120,
                        impact_score=6,
                        code_example=(
                            "# Profile with cProfile\n"
                            "$ python -m cProfile -o profile.stats -m manifestguard "
                            "check --extended\n"
                            "$ python -m pstats profile.stats\n"
                            "(pstats) sort cumtime\n"
                            "(pstats) stats 10\n\n"
                            "# Or use py-spy for live profiling\n"
                            "$ pip install py-spy\n"
                            "$ py-spy record -o profile.svg -- "
                            "python -m manifestguard check --extended\n\n"
                            "# Enable performance tracing\n"
                            "$ MANIFESTGUARD_PROFILE=1 manifestguard check --extended"
                        ),
                        guide_url="https://www.ready-4-it.com/mgpy/guides/performance-optimization",
                    ),
                )
        return recs

    def _recommend_memory_profiling(self, metrics: "ExtendedTestMetrics") -> list[Recommendation]:
        recs: list[Recommendation] = []
        if not self._project_declares_dependencies():
            return recs
        direct_deps = metrics.dependency.direct_count
        total_deps = metrics.dependency.direct_count + metrics.dependency.transitive_count
        if direct_deps >= 25 or total_deps >= 250:
            recs.append(
                Recommendation(
                    category="memory",
                    id="enable-memory-profiling",
                    priority="low",
                    summary=(
                        f"Large dependency footprint ({direct_deps} direct, {total_deps} total) - "
                        "consider memory profiling"
                    ),
                    proposed_fix=(
                        "Enable memory profiling to detect leaks and optimize usage. "
                        "Use memory_profiler or tracemalloc for detailed analysis."
                    ),
                    confidence=0.70,
                    effort_minutes=90,
                    impact_score=5,
                    code_example=(
                        "# Profile with memory_profiler\n"
                        "$ pip install memory_profiler\n"
                        "$ python -m memory_profiler -m manifestguard check --extended\n\n"
                        "# Or use tracemalloc (built-in)\n"
                        "import tracemalloc\n"
                        "tracemalloc.start()\n"
                        "# ... run analysis ...\n"
                        "snapshot = tracemalloc.take_snapshot()\n"
                        "top_stats = snapshot.statistics('lineno')\n"
                        "for stat in top_stats[:10]:\n"
                        "    print(stat)\n\n"
                        "# Use pympler for advanced analysis\n"
                        "$ pip install pympler\n"
                        "from pympler import tracker\n"
                        "tr = tracker.SummaryTracker()\n"
                        "# ... run analysis ...\n"
                        "tr.print_diff()"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/memory-profiling",
                ),
            )
        return recs
