from __future__ import annotations

from .metrics_recommendations_quality_base import _MetricsRecommendationsQualityBaseMixin
from .metrics_recommendations_quality_helpers import _MetricsRecommendationsQualityHelpersMixin
from .metrics_recommendations_quality_metrics import _MetricsRecommendationsQualityMetricsMixin
from .metrics_recommendations_quality_modern import _MetricsRecommendationsQualityModernMixin
from .metrics_recommendations_quality_static import _MetricsRecommendationsQualityStaticMixin
from .metrics_recommendations_quality_trends import _MetricsRecommendationsQualityTrendsMixin


class _MetricsRecommendationsQualityMixin(
    _MetricsRecommendationsQualityBaseMixin,
    _MetricsRecommendationsQualityStaticMixin,
    _MetricsRecommendationsQualityModernMixin,
    _MetricsRecommendationsQualityTrendsMixin,
    _MetricsRecommendationsQualityMetricsMixin,
    _MetricsRecommendationsQualityHelpersMixin,
):
    """Quality recommendation mixin.

    Split across multiple modules to keep file sizes below the LOC threshold
    while preserving the original public symbol name.
    """

