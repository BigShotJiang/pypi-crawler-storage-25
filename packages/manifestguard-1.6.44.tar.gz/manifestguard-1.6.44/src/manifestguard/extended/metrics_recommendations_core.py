from __future__ import annotations

import logging
import re
from collections.abc import Callable
from pathlib import Path

from .filesystem_safety import safe_rglob
from .metrics import Recommendation

logger = logging.getLogger(__name__)


class _MetricsRecommendationsCoreMixin:
    def _generate_recommendations(self, metrics: "ExtendedTestMetrics") -> list[Recommendation]:
        """Generate AI-driven recommendations based on metrics

        Reduced complexity by delegating to helper functions for each category.
        """
        recommendations: list[Recommendation] = []

        # Delegate to category-specific helper functions
        recommendations.extend(self._generate_coverage_recommendations(metrics.coverage))
        recommendations.extend(self._generate_dependency_recommendations(metrics.dependency))
        recommendations.extend(self._generate_security_recommendations(metrics.security))
        recommendations.extend(self._generate_complexity_recommendations(metrics.complexity))
        recommendations.extend(self._generate_quality_recommendations(metrics))

        return recommendations

    def _get_mixed_runner_patterns(self) -> tuple[list[re.Pattern], re.Pattern]:
        """Compile regex patterns for detecting explicit test runner invocations.

        Returns:
            (hard_patterns, unittest_main_pattern)

        Notes:
            Importing `unittest` (e.g., `unittest.mock`) is not a runner mix.
            We treat `unittest.main()` as a weaker signal and require additional
            evidence (e.g., __main__ guard or non-test locations).
        """

        hard_patterns = (
            r"\bpython\s+-m\s+unittest\b",
            r"\bnosetests\b",
            r"\bnose2\b",
        )
        unittest_main_pattern = r"\bunittest\.main\s*\("
        return (
            [re.compile(p, re.IGNORECASE) for p in hard_patterns],
            re.compile(unittest_main_pattern, re.IGNORECASE),
        )

    def _collect_mixed_runner_candidate_files(self) -> list[Path]:
        """Collect candidate files to scan for mixed runner signals."""
        root = self.workspace_root
        candidates: list[Path] = [
            root / "pyproject.toml",
            root / "setup.cfg",
            root / "tox.ini",
            root / "noxfile.py",
            root / "Makefile",
            root / "Pipfile",
            root / "requirements.txt",
        ]

        workflows_dir = root / ".github" / "workflows"
        if workflows_dir.exists():
            try:
                workflows = sorted(
                    safe_rglob(workflows_dir, "*.yml", max_files=25),
                    key=lambda p: str(p).replace("\\\\", "/").lower(),
                )
                candidates.extend(workflows)
            except Exception:
                pass

        # Intentionally do NOT scan tests for runner signals.
        # Tests may contain example strings like "python -m unittest" which would
        # create false positives. Runner invocations are better detected via
        # config/CI (tox/nox/Makefile/workflows).

        return candidates

    def _try_read_candidate_text(self, path: Path, per_file_limit: int) -> str | None:
        if not path.exists() or not path.is_file():
            return None
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return None
        if len(text) > per_file_limit:
            return text[:per_file_limit]
        return text

    def _scan_files_for_mixed_runner(
        self,
        candidates: list[Path],
        hard_patterns: list[re.Pattern],
        unittest_main_pattern: re.Pattern,
    ) -> bool:
        """Scan candidate files for patterns indicating mixed test runners."""
        total_bytes_budget = 512 * 1024
        per_file_limit = 64 * 1024

        def _is_test_path(path: Path) -> bool:
            try:
                rel = str(path.resolve().relative_to(self.workspace_root.resolve()))
            except Exception:
                rel = str(path)
            rel = rel.replace("\\\\", "/").lower()
            return rel.startswith("tests/") or rel.startswith("test/")

        def _has_main_guard(text: str) -> bool:
            # Keep it simple and robust; avoid parsing.
            return "__name__" in text and "__main__" in text

        for path in candidates:
            if total_bytes_budget <= 0:
                break

            text = self._try_read_candidate_text(path, per_file_limit)
            if text is None:
                continue

            total_bytes_budget -= len(text)

            for rx in hard_patterns:
                if rx.search(text):
                    return True

            if unittest_main_pattern.search(text):
                # `unittest.main()` in a test file can be a leftover snippet or
                # example and should not trigger the recommendation unless it's
                # clearly used as a runner.
                if _is_test_path(path) and not _has_main_guard(text):
                    continue
                return True

        return False

    def _has_mixed_test_runner_signals(self) -> bool:
        """Best-effort detection for mixed/competing test runners.

        This recommendation should not be emitted unconditionally just because a
        tests folder exists. Many projects use pytest as the runner while still
        importing parts of unittest (e.g., unittest.mock), which is not a runner mix.

        We therefore look for explicit runner invocations or CI/config references.
        """
        root = self.workspace_root

        if not (root / "tests").exists() and not (root / "test").exists():
            return False

        hard_patterns, unittest_main_pattern = self._get_mixed_runner_patterns()
        candidates = self._collect_mixed_runner_candidate_files()
        return self._scan_files_for_mixed_runner(
            candidates,
            hard_patterns,
            unittest_main_pattern,
        )

    # manifestguard-ignore-line: COMPLEXITY
    def _generate_coverage_recommendations(self, coverage: "CoverageMetrics") -> list[Recommendation]:
        """Generate test coverage recommendations"""
        recommendations: list[Recommendation] = []

        # If coverage couldn't be measured for this run, do not emit a fake
        # low-coverage CRITICAL recommendation.
        if not coverage.unit_measured:
            return recommendations

        # A raw 0% value without any discovered test count is too ambiguous for a
        # hard critical. This commonly means pytest discovery/progress data was not
        # available, or coverage configuration needs verification before we can
        # treat the result as a trustworthy 0% datapoint.
        if coverage.unit_percent <= 0.0 and coverage.total_tests <= 0:
            recommendations.append(
                Recommendation(
                    category="coverage",
                    id="coverage-zero-inconclusive",
                    priority="low",
                    summary=(
                        "Coverage result is inconclusive "
                        "(0.0% with no discovered test count)."
                    ),
                    proposed_fix=(
                        "📋 Verify pytest discovery and coverage configuration first: "
                        "run `pytest --collect-only -q` and your project's direct "
                        "coverage command (for example `pytest --cov=<package> "
                        "--cov-report=json`). Only treat 0.0% as real once tests "
                        "and measured files are confirmed."
                    ),
                    confidence=0.8,
                    effort_minutes=0,
                    impact_score=0,
                    guide_url="https://www.ready-4-it.com/mgpy/guides/testing-basics",
                ),
            )
            return recommendations

        # Coverage recommendations
        if coverage.unit_percent < 50:
            untested_modules = coverage.untested_modules[:3]
            untested_display = (
                ", ".join(untested_modules) if untested_modules else "multiple modules"
            )

            recommendations.append(
                Recommendation(
                    category="coverage",
                    id="low-coverage-critical",
                    priority="critical",
                    summary=(
                        f"Test coverage is critically low "
                        f"({coverage.unit_percent:.1f}%). Target: 70%+"
                    ),
                    proposed_fix=(
                        f"📋 Add pytests (or unit tests) for: {untested_display}. "
                        "Start with core validators and parsers."
                    ),
                    confidence=0.95,
                    effort_minutes=240,  # 4 hours for initial test setup
                    impact_score=25,  # High impact on quality
                    code_example=(
                        "# Example unit test structure\n"
                        "import pytest\n"
                        "from manifestguard.validators import SchemaValidator\n\n"
                        "def test_schema_validator_valid_input():\n"
                        "    validator = SchemaValidator()\n"
                        "    result = validator.validate({'name': 'test'})\n"
                        "    assert result.is_valid\n\n"
                        "def test_schema_validator_invalid_input():\n"
                        "    validator = SchemaValidator()\n"
                        "    result = validator.validate({})\n"
                        "    assert not result.is_valid\n"
                        "    assert 'name' in result.errors"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/testing-basics",
                    files_affected=untested_modules,
                ),
            )
        elif coverage.unit_percent < 70:
            recommendations.append(
                Recommendation(
                    category="coverage",
                    id="low-coverage-warn",
                    priority="high",
                    summary=(
                        f"Test coverage needs improvement "
                        f"({coverage.unit_percent:.1f}%). Target: 70%+"
                    ),
                    proposed_fix="Focus on edge cases and error paths",
                    confidence=0.90,
                ),
            )

        # Best practice: keep test execution and coverage consistent.
        # Append this after coverage-critical recommendations so tests that use coverage_recs[0]
        # continue to pick the actionable coverage issue first.
        if self._has_mixed_test_runner_signals():
            recommendations.append(
                Recommendation(
                    category="coverage",
                    id="pytest-runner-consistency",
                    priority="low",
                    summary="Prefer pytest + pytest-cov; avoid mixing test runners",
                    proposed_fix=(
                        "Run the suite via pytest (it can execute unittest-style tests too) and "
                        "avoid a separate unittest runner in CI to keep "
                        "discovery/fixtures/coverage consistent. "
                        "Prefer pytest-cov for coverage reporting, and use "
                        "pytest's monkeypatch fixture (or unittest.mock) "
                        "for safe, test-local patching."
                    ),
                    confidence=0.85,
                    effort_minutes=15,
                    impact_score=4,
                    code_example=(
                        "# Run tests with coverage\n"
                        "$ pytest -q --cov=your_package --cov-report=term-missing\n\n"
                        "# Example: isolate side effects with pytest's monkeypatch\n"
                        "def test_reads_env(monkeypatch):\n"
                        "    monkeypatch.setenv('FEATURE_FLAG', '1')\n"
                        "    assert True\n"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/testing-basics",
                ),
            )

        return recommendations

    # manifestguard-ignore-line: COMPLEXITY
    def _generate_dependency_recommendations(
        self,
        dependency: "DependencyMetrics",
    ) -> list[Recommendation]:
        """Generate dependency-related recommendations"""
        recommendations: list[Recommendation] = []

        # Dependency recommendations
        if dependency.vulnerable_critical > 0:
            recommendations.append(
                Recommendation(
                    category="dependency",
                    id="critical-vulns",
                    priority="critical",
                    summary=(f"{dependency.vulnerable_critical} critical " "vulnerabilities found"),
                    proposed_fix=(
                        "Run 'pip-audit' and upgrade affected packages immediately. "
                        "Review CVE details and test after upgrade."
                    ),
                    confidence=1.0,
                    effort_minutes=15,  # Quick upgrade
                    impact_score=30,  # Critical security impact
                    code_example=(
                        "# Step 1: Audit dependencies\n"
                        "$ pip install pip-audit\n"
                        "$ pip-audit\n\n"
                        "# Step 2: Upgrade vulnerable packages\n"
                        "$ pip install --upgrade <package-name>\n\n"
                        "# Step 3: Update requirements\n"
                        "$ pip freeze > requirements.txt\n\n"
                        "# Step 4: Test your application\n"
                        "$ pytest"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/security-vulnerabilities",
                ),
            )
        elif dependency.vulnerable_high > 0:
            recommendations.append(
                Recommendation(
                    category="dependency",
                    id="high-vulns",
                    priority="high",
                    summary=(
                        f"{dependency.vulnerable_high} high-severity " "vulnerabilities found"
                    ),
                    proposed_fix="Review and upgrade vulnerable dependencies",
                    confidence=0.98,
                ),
            )

        if dependency.outdated_count > 10:
            recommendations.append(
                Recommendation(
                    category="dependency",
                    id="many-outdated",
                    priority="medium",
                    summary=f"{dependency.outdated_count} outdated packages",
                    proposed_fix="Schedule dependency update sprint",
                    confidence=0.85,
                ),
            )

        return recommendations

    def _rec_hardcoded_paths(self, count: int) -> Recommendation:
        example_win = "C:\\" + "Users\\dev\\"
        example_linux = "/" + "home/user/"
        example_config = "C:\\\\" + "Users\\\\dev\\\\project\\\\config.json"
        return Recommendation(
            category="security",
            id="hardcoded-paths",
            priority="high",
            summary=(
                f"{count} files with "
                f"hardcoded dev/user paths (e.g., {example_win}, {example_linux})"
            ),
            proposed_fix=(
                "Replace with Path(__file__).parent for relative paths, "
                "or use environment variables for config paths"
            ),
            confidence=0.95,
            effort_minutes=30,
            impact_score=10,
            code_example=(
                "# ❌ BAD: Hardcoded path\n"
                f"config_path = '{example_config}'\n\n"
                "# ✅ GOOD: Relative path\n"
                "from pathlib import Path\n"
                "config_path = Path(__file__).parent / 'config.json'\n\n"
                "# ✅ GOOD: Environment variable\n"
                "import os\n"
                "config_path = os.getenv('CONFIG_PATH', 'config.json')"
            ),
            guide_url="https://www.ready-4-it.com/mgpy/guides/portable-paths",
        )

    def _rec_unsafe_exec(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="unsafe-exec",
            priority="high",
            summary=f"{count} file(s) use eval/exec",
            proposed_fix="Replace with safe alternatives (ast.literal_eval, importlib)",
            confidence=0.92,
        )

    def _rec_hardcoded_secrets(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="hardcoded-secrets",
            priority="critical",
            summary=f"{count} potential hardcoded secret(s)",
            proposed_fix="Move to environment variables or secret management service",
            confidence=0.80,
        )

    def _rec_subprocess_shell(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="subprocess-shell-true",
            priority="high",
            summary=f"{count} file(s) use subprocess with shell=True",
            proposed_fix=(
                "Avoid shell=True where possible. Pass arguments as a list and validate inputs. "
                "If shell is required, strictly control/escape inputs."
            ),
            confidence=0.9,
        )

    def _rec_unsafe_deserialization(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="unsafe-deserialization",
            priority="high",
            summary=f"{count} file(s) use unsafe deserialization patterns",
            proposed_fix=(
                "Avoid pickle for untrusted data. Prefer JSON. For YAML use yaml.safe_load() or SafeLoader."
            ),
            confidence=0.9,
        )

    def _rec_tls_verify_disabled(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="tls-verify-disabled",
            priority="high",
            summary=f"{count} file(s) disable TLS verification (certificate verification disabled)",
            proposed_fix=(
                "Enable TLS verification. Use proper CA bundles or certificate pinning instead of disabling certificate verification."
            ),
            confidence=0.9,
        )

    def _rec_insecure_tempfile(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="insecure-tempfile",
            priority="high",
            summary=f"{count} file(s) use insecure tempfile patterns (mktemp)",
            proposed_fix="Avoid tempfile.mktemp (insecure). Use NamedTemporaryFile or mkstemp instead.",
            confidence=0.9,
        )

    def _rec_insecure_permissions(self, files: list[str]) -> Recommendation:
        return Recommendation(
            category="security",
            id="insecure-permissions",
            priority="high",
            summary=f"{len(files)} file(s) set overly permissive chmod modes",
            proposed_fix="Avoid world-writable modes (e.g. 0o777/0o666). Use least privilege (e.g. 0o600/0o700).",
            confidence=0.85,
            files_affected=files[:5],
        )

    def _rec_wheel_content_issues(self, count: int, findings: list[str]) -> Recommendation:
        return Recommendation(
            category="security",
            id="wheel-content-issues",
            priority="high",
            summary=f"{count} suspicious wheel content item(s) detected",
            proposed_fix=(
                "Verify package include/exclude rules (pyproject.toml / MANIFEST.in). "
                "Ensure tests/fixtures/.manifestguard and secret-like files are not packaged."
            ),
            confidence=0.9,
            files_affected=findings[:5],
        )

    def _rec_supply_chain_vulnerabilities(self, count: int, findings: list[str]) -> Recommendation:
        return Recommendation(
            category="security",
            id="supply-chain-vulnerabilities",
            priority="critical",
            summary=f"{count} known CVE(s) in dependencies (detected via pip-audit)",
            proposed_fix=(
                "Update vulnerable dependencies to patched versions. "
                "Run 'pip-audit --fix' or manually upgrade affected packages."
            ),
            confidence=0.95,
            files_affected=findings[:5],
        )

    def _generate_security_recommendations(self, security: "SecurityMetrics") -> list[Recommendation]:
        """Generate security-related recommendations"""
        recommendations: list[Recommendation] = []

        if security.hardcoded_paths > 0:
            recommendations.append(self._rec_hardcoded_paths(security.hardcoded_paths))
        if security.unsafe_exec_count > 0:
            recommendations.append(self._rec_unsafe_exec(security.unsafe_exec_count))
        if security.hardcoded_secrets > 0:
            recommendations.append(self._rec_hardcoded_secrets(security.hardcoded_secrets))
        if security.subprocess_shell_true > 0:
            recommendations.append(self._rec_subprocess_shell(security.subprocess_shell_true))
        if security.unsafe_deserialization > 0:
            recommendations.append(
                self._rec_unsafe_deserialization(security.unsafe_deserialization)
            )
        if security.tls_verify_disabled > 0:
            recommendations.append(self._rec_tls_verify_disabled(security.tls_verify_disabled))
        if security.insecure_tempfile > 0:
            recommendations.append(self._rec_insecure_tempfile(security.insecure_tempfile))
        if security.insecure_permissions:
            recommendations.append(self._rec_insecure_permissions(security.insecure_permissions))
        if security.wheel_content_issues > 0:
            recommendations.append(
                self._rec_wheel_content_issues(
                    security.wheel_content_issues,
                    security.wheel_content_findings,
                ),
            )
        if security.supply_chain_vulnerabilities > 0:
            recommendations.append(
                self._rec_supply_chain_vulnerabilities(
                    security.supply_chain_vulnerabilities,
                    security.supply_chain_findings,
                ),
            )

        return recommendations

    def _coerce_dict_list(self, items: object) -> list[dict]:
        if not isinstance(items, list):
            return []
        return [item for item in items if isinstance(item, dict)]

    def _complexity_max_oversized_lines(self, complexity: "ComplexityMetrics") -> int:
        oversized_files = self._coerce_dict_list(getattr(complexity, "oversized_files", []) or [])
        max_lines = 0
        for item in oversized_files:
            max_lines = max(max_lines, int(item.get("lines", 0) or 0))
        if max_lines:
            return max_lines
        return int(getattr(complexity, "max_file_lines_observed", 0) or 0)

    def _complexity_oversized_priority(self, max_lines: int, critical_threshold: int | None) -> str:
        if isinstance(critical_threshold, int) and critical_threshold > 0 and max_lines >= critical_threshold:
            return "critical"
        return "high"

    def _complexity_top_oversized_display(self, top_files: list[dict]) -> str:
        if not top_files:
            return "one or more files"
        parts: list[str] = []
        for item in top_files:
            parts.append(
                f"{item.get('file', 'unknown')} ({int(item.get('lines', 0) or 0)} lines)"
            )
        return ", ".join(parts)

    def _complexity_top_violations_display(self, top_violations: list[dict]) -> str:
        if not top_violations:
            return "multiple functions"
        parts: list[str] = []
        for v in top_violations:
            name = v.get("function") or v.get("name") or "unknown"
            parts.append(f"{name} ({v.get('complexity', 0)})")
        return ", ".join(parts)

    def _rec_oversized_files(self, complexity: "ComplexityMetrics") -> Recommendation:
        threshold = getattr(complexity, "max_file_lines_threshold", None)
        _t, _it, _eng, _high, critical_threshold = self._read_complexity_settings_from_manifest()

        oversized_files = self._coerce_dict_list(getattr(complexity, "oversized_files", []) or [])
        top_files = oversized_files[:3]

        max_lines = self._complexity_max_oversized_lines(complexity)
        priority = self._complexity_oversized_priority(max_lines, critical_threshold)
        top_display = self._complexity_top_oversized_display(top_files)

        return Recommendation(
            category="complexity",
            id="oversized-files",
            priority=priority,
            summary=(
                f"{complexity.oversized_files_count} file(s) exceed max file length "
                f"({threshold} lines). Top offenders: {top_display}"
            ),
            proposed_fix=(
                "Split oversized modules into smaller, cohesive files: "
                "1. Extract components/helpers into separate modules, "
                "2. Group related functions into submodules, "
                "3. Reduce file scope to improve reviewability and testing"
            ),
            confidence=0.95,
            effort_minutes=240,
            impact_score=20,
            guide_url="https://www.ready-4-it.com/mgpy/guides/reducing-complexity",
            files_affected=[f.get("file", "") for f in top_files if f.get("file")],
        )

    def _rec_high_complexity(self, complexity: "ComplexityMetrics") -> Recommendation:
        priority = "critical" if complexity.max_complexity > 20 else "high"
        top_violations = self._coerce_dict_list(getattr(complexity, "top_violations", []) or [])[:3]
        top_display = self._complexity_top_violations_display(top_violations)

        return Recommendation(
            category="complexity",
            id="high-complexity",
            priority=priority,
            summary=(
                f"{complexity.violations_count} function(s) "
                f"exceed complexity threshold. Top offenders: {top_display}"
            ),
            proposed_fix=(
                "Refactor high-complexity functions: "
                "1. Extract helper functions, "
                "2. Reduce nesting (max 3 levels), "
                "3. Simplify conditionals (use early returns)"
            ),
            confidence=0.90,
            effort_minutes=120,
            impact_score=15,
            code_example=(
                "# ❌ BAD: High complexity (nested conditions)\n"
                "def process_data(data):\n"
                "    if data:\n"
                "        if data.get('type') == 'valid':\n"
                "            if data.get('status') == 'active':\n"
                "                return data['value']\n"
                "    return None\n\n"
                "# ✅ GOOD: Low complexity (early returns)\n"
                "def process_data(data):\n"
                "    if not data:\n"
                "        return None\n"
                "    if data.get('type') != 'valid':\n"
                "        return None\n"
                "    if data.get('status') != 'active':\n"
                "        return None\n"
                "    return data['value']"
            ),
            guide_url="https://www.ready-4-it.com/mgpy/guides/reducing-complexity",
            files_affected=[v.get("file", "") for v in top_violations if v.get("file")],
        )

    def _generate_complexity_recommendations(
        self,
        complexity: "ComplexityMetrics",
    ) -> list[Recommendation]:
        """Generate code complexity recommendations"""
        recommendations: list[Recommendation] = []

        if getattr(complexity, "oversized_files_count", 0) > 0:
            recommendations.append(self._rec_oversized_files(complexity))
        if getattr(complexity, "violations_count", 0) > 0:
            recommendations.append(self._rec_high_complexity(complexity))

        return recommendations
