"""Docstring coverage analysis for extended metrics."""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from .filesystem_safety import safe_rglob
from .scan_utils import load_ignore_patterns, should_skip_path

logger = logging.getLogger(__name__)


def _has_valid_docstring(node: ast.AST) -> bool:
    docstring = ast.get_docstring(node)  # type: ignore[arg-type]
    return docstring is not None and len(docstring.strip()) > 10


def _is_public_symbol(name: str) -> bool:
    if not name:
        return False
    if name.startswith("__") and name.endswith("__"):
        return False
    return not name.startswith("_")


def _analyze_file_documentation(py_file: Path) -> tuple[int, int, float]:
    try:
        content = py_file.read_text(encoding="utf-8")
        tree = ast.parse(content, filename=str(py_file))

        file_total = 0
        file_documented = 0

        # Count only top-level public symbols (functions/classes).
        # This avoids inflating the denominator with private helpers and
        # class methods that are typically documented at class/module level.
        for node in getattr(tree, "body", []):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = getattr(node, "name", "")
                if not isinstance(name, str) or not _is_public_symbol(name):
                    continue

                file_total += 1
                if _has_valid_docstring(node):
                    file_documented += 1

        if file_total > 0:
            file_coverage = (file_documented / file_total) * 100
            return file_total, file_documented, file_coverage

    except (SyntaxError, UnicodeDecodeError):
        pass

    return 0, 0, 0.0


def analyze_documentation(workspace_root: Path) -> dict:
    """Analyze documentation (docstring) coverage."""
    total_items = 0
    documented_items = 0
    files_with_low_coverage: list[str] = []

    try:
        ignore_patterns = load_ignore_patterns(workspace_root)

        src_dir = workspace_root / "src"
        if not src_dir.exists():
            src_dir = workspace_root

        py_files = safe_rglob(src_dir, "*.py", max_files=50000)
        for py_file in py_files:
            if should_skip_path(py_file, ignore_patterns, workspace_root):
                continue
            if "test_" in py_file.name:
                continue

            file_total, file_documented, file_coverage = _analyze_file_documentation(py_file)

            if file_total > 0:
                total_items += file_total
                documented_items += file_documented

                if file_coverage < 70:
                    rel_path = py_file.relative_to(workspace_root)
                    files_with_low_coverage.append(str(rel_path))

    except Exception as exc:
        logger.debug("Documentation analysis failed: %s", exc)
        return {}

    if total_items == 0:
        return {}

    coverage_percent = (documented_items / total_items) * 100

    return {
        "total_items": total_items,
        "documented_items": documented_items,
        "coverage_percent": round(coverage_percent, 1),
        "files_with_low_coverage": files_with_low_coverage,
    }
