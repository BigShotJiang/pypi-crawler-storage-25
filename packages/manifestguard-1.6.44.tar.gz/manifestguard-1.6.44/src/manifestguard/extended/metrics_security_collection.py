from __future__ import annotations

import logging
from collections.abc import Iterable
from pathlib import Path

from manifestguard.validation.inline_markers import is_line_suppressed

from .filesystem_safety import safe_read_file, safe_rglob
from .security_detectors import (
    find_eval_exec_lines,
    find_hardcoded_path_lines,
    find_hardcoded_secret_lines,
    find_insecure_permission_lines,
    find_insecure_tempfile_lines,
    find_subprocess_shell_true_lines,
    find_tls_verify_disabled_lines,
    find_unsafe_deserialization_lines,
    find_weak_crypto_lines,
)
from .supply_chain_audit import audit_supply_chain, audit_wheel_contents

logger = logging.getLogger(__name__)


def _is_security_suppressed(py_file: Path, line: int, code: str) -> bool:
    # Support both coarse and fine-grained suppressions.
    return is_line_suppressed(py_file, line, "SECURITY") or is_line_suppressed(py_file, line, code)


def _iter_security_python_files(src_dir: Path) -> list[Path]:
    # Use safe file walker (max 50k files for DoS resilience)
    return safe_rglob(src_dir, "*.py", max_files=50000)


def _try_read_security_file(py_file: Path) -> str | None:
    try:
        # Enforce 10MB per-file limit for DoS resilience
        return safe_read_file(py_file, max_bytes=10 * 1024 * 1024)
    except ValueError as exc:
        logger.warning(f"Skipping oversized file: {exc}")
        return None


def _any_unsuppressed(py_file: Path, lines: Iterable[int], code: str) -> bool:
    return any(not _is_security_suppressed(py_file, ln, code) for ln in lines)


def _append_unique_rel_path(items: list[str], workspace_root: Path, py_file: Path) -> None:
    rel_path = str(py_file.relative_to(workspace_root))
    if rel_path not in items:
        items.append(rel_path)


def _check_exec(metrics: object, py_file: Path, content: str) -> None:
    if _any_unsuppressed(py_file, find_eval_exec_lines(py_file, content), "SEC-UNSAFE-EXEC"):
        setattr(metrics, "unsafe_exec_count", int(getattr(metrics, "unsafe_exec_count", 0)) + 1)


def _check_secrets(metrics: object, py_file: Path, content: str) -> None:
    if _any_unsuppressed(py_file, find_hardcoded_secret_lines(content), "SEC-HARDCODED-SECRET"):
        setattr(metrics, "hardcoded_secrets", int(getattr(metrics, "hardcoded_secrets", 0)) + 1)


def _check_paths(metrics: object, py_file: Path, content: str) -> None:
    if _any_unsuppressed(py_file, find_hardcoded_path_lines(py_file, content), "SEC-HARDCODED-PATH"):
        setattr(metrics, "hardcoded_paths", int(getattr(metrics, "hardcoded_paths", 0)) + 1)


def _check_shell(metrics: object, py_file: Path, content: str) -> None:
    if _any_unsuppressed(py_file, find_subprocess_shell_true_lines(content), "SEC-SUBPROCESS-SHELL"):
        setattr(metrics, "subprocess_shell_true", int(getattr(metrics, "subprocess_shell_true", 0)) + 1)


def _check_deser(metrics: object, py_file: Path, content: str) -> None:
    if _any_unsuppressed(
        py_file,
        find_unsafe_deserialization_lines(content),
        "SEC-UNSAFE-DESERIALIZATION",
    ):
        setattr(metrics, "unsafe_deserialization", int(getattr(metrics, "unsafe_deserialization", 0)) + 1)


def _check_tls(metrics: object, py_file: Path, content: str) -> None:
    if _any_unsuppressed(
        py_file,
        find_tls_verify_disabled_lines(content),
        "SEC-TLS-VERIFY-DISABLED",
    ):
        setattr(metrics, "tls_verify_disabled", int(getattr(metrics, "tls_verify_disabled", 0)) + 1)


def _check_tempfile(metrics: object, py_file: Path, content: str) -> None:
    if _any_unsuppressed(py_file, find_insecure_tempfile_lines(content), "SEC-INSECURE-TEMPFILE"):
        setattr(metrics, "insecure_tempfile", int(getattr(metrics, "insecure_tempfile", 0)) + 1)


def _check_perms(metrics: object, workspace_root: Path, py_file: Path, content: str) -> None:
    if _any_unsuppressed(
        py_file,
        find_insecure_permission_lines(content),
        "SEC-INSECURE-PERMISSIONS",
    ):
        insecure_permissions = getattr(metrics, "insecure_permissions", None)
        if isinstance(insecure_permissions, list):
            _append_unique_rel_path(insecure_permissions, workspace_root, py_file)


def _check_crypto(metrics: object, workspace_root: Path, py_file: Path, content: str) -> None:
    if _any_unsuppressed(py_file, find_weak_crypto_lines(content), "SEC-WEAK-CRYPTO"):
        weak_crypto = getattr(metrics, "weak_crypto", None)
        if isinstance(weak_crypto, list):
            _append_unique_rel_path(weak_crypto, workspace_root, py_file)


def _collect_security_findings_for_file(metrics: object, workspace_root: Path, *, py_file: Path, content: str) -> None:
    _check_exec(metrics, py_file, content)
    _check_secrets(metrics, py_file, content)
    _check_paths(metrics, py_file, content)
    _check_shell(metrics, py_file, content)
    _check_deser(metrics, py_file, content)
    _check_tls(metrics, py_file, content)
    _check_tempfile(metrics, py_file, content)
    _check_perms(metrics, workspace_root, py_file, content)
    _check_crypto(metrics, workspace_root, py_file, content)


def _collect_security_wheel_and_supply_chain(workspace_root: Path, metrics: object) -> None:
    wheel_issues, wheel_findings = audit_wheel_contents(workspace_root)
    setattr(metrics, "wheel_content_issues", wheel_issues)
    setattr(metrics, "wheel_content_findings", wheel_findings)

    # Supply-chain vulnerability audit (pip-audit)
    vuln_count, vuln_findings = audit_supply_chain(workspace_root)
    setattr(metrics, "supply_chain_vulnerabilities", vuln_count)
    setattr(metrics, "supply_chain_findings", vuln_findings)


def collect_security_metrics(workspace_root: Path):
    """Collect security risk indicators via static analysis.

    Kept in a separate module to keep extended/metrics.py under the LOC threshold.
    """

    # Import lazily to avoid circular imports at module load time.
    from .metrics import SecurityMetrics  # noqa: PLC0415

    metrics = SecurityMetrics()

    try:
        src_dir = workspace_root / "src"
        if not src_dir.exists():
            return metrics

        for py_file in _iter_security_python_files(src_dir):
            content = _try_read_security_file(py_file)
            if content is None:
                continue
            _collect_security_findings_for_file(metrics, workspace_root, py_file=py_file, content=content)

        _collect_security_wheel_and_supply_chain(workspace_root, metrics)

    except Exception as exc:  # pragma: no cover - best-effort
        logger.debug(f"Security metrics collection failed: {exc}")

    return metrics
