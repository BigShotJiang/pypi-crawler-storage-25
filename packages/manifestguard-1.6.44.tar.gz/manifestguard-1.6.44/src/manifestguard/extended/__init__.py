"""Extended Test & Analysis Mode

Post-validation consolidation phase for holistic quality metrics
and AI-driven recommendations.
"""

from .baseline import BaselineManager
from .metrics import ExtendedTestMetrics, MetricsCollector
from .runner import ExtendedTestRunner

__all__ = ["BaselineManager", "ExtendedTestMetrics", "ExtendedTestRunner", "MetricsCollector"]
