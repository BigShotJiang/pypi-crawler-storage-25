"""Weekly venv health reconstruction from metrics history.

Aggregates venvHealth entries into calendar-week buckets (ISO weeks)
for trend analysis aligned with Preflight Phase III concept.
"""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any


def get_iso_week(timestamp: str) -> str:
    """Extract ISO week number from timestamp.
    
    Args:
        timestamp: ISO format timestamp
        
    Returns:
        ISO week string (format: 2026-W02)
    """
    try:
        dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        iso_cal = dt.isocalendar()
        return f"{iso_cal.year}-W{iso_cal.week:02d}"
    except Exception:
        return "unknown"


def _load_history_entries(history_file: Path) -> list[dict[str, Any]] | None:
    """Load history entries from metrics history file (.mgpy/metrics/ or legacy locations)."""
    if not history_file.exists():
        return None

    try:
        data = json.loads(history_file.read_text(encoding="utf-8"))
    except Exception:
        return None

    entries = data.get("entries", []) if isinstance(data, dict) else data
    if not isinstance(entries, list):
        return None

    return [e for e in entries if isinstance(e, dict)]


def _iter_venv_health_metrics(entries: list[dict[str, Any]]):
    """Iterate over venvHealth metrics from history entries."""
    for entry in entries:
        timestamp = entry.get("timestamp", "")
        if not timestamp:
            continue

        metrics = entry.get("metrics", [])
        if not isinstance(metrics, list):
            continue

        for metric in metrics:
            if not isinstance(metric, dict):
                continue
            if metric.get("metric") != "venvHealth":
                continue

            value = metric.get("value", {})
            if not isinstance(value, dict):
                continue

            yield get_iso_week(timestamp), timestamp, value


def _trend_for_week(measurements: list[dict[str, Any]]) -> str:
    """Determine health trend for a week."""
    if len(measurements) < 2:
        return "insufficient_data"
    
    # Count status changes
    ok_count = sum(1 for m in measurements if m.get("status") == "ok")
    warning_count = sum(1 for m in measurements if m.get("status") == "warning")
    error_count = sum(1 for m in measurements if m.get("status") == "error")
    
    # Trend based on dominant status
    if ok_count == len(measurements):
        return "stable_healthy"
    elif error_count > len(measurements) / 2:
        return "degrading"
    elif warning_count > len(measurements) / 2:
        return "unstable"
    else:
        return "mixed"


def _build_week_aggregate(week: str, measurements: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Build weekly aggregate from venvHealth measurements."""
    if not measurements:
        return None

    measurements.sort(key=lambda x: x["timestamp"])

    # Count statuses
    status_counts = defaultdict(int)
    total_warnings = 0
    total_managed = 0
    total_zombie = 0
    total_dead = 0
    
    for m in measurements:
        health = m.get("health", {})
        status = health.get("status", "unknown")
        status_counts[status] += 1
        
        total_warnings += health.get("warnings", 0)
        total_managed += health.get("managedChildren", 0)
        total_zombie += health.get("zombie", 0)
        total_dead += health.get("dead", 0)

    n = len(measurements)
    trend = _trend_for_week(measurements)

    return {
        "week": week,
        "measurements": n,
        "status_distribution": dict(status_counts),
        "avg_warnings": round(total_warnings / n, 2),
        "avg_managed_children": round(total_managed / n, 2),
        "avg_zombie_processes": round(total_zombie / n, 2),
        "avg_dead_processes": round(total_dead / n, 2),
        "total_warnings": total_warnings,
        "total_zombie": total_zombie,
        "total_dead": total_dead,
        "trend": trend,
        "first_timestamp": measurements[0]["timestamp"],
        "last_timestamp": measurements[-1]["timestamp"],
    }


def reconstruct_weekly_venv_health(
    history_file: Path
) -> dict[str, dict[str, Any]]:
    """Reconstruct weekly venv health aggregates from metrics history.
    
    Args:
        history_file: Path to metrics history file
        
    Returns:
        Dict mapping ISO week strings to weekly aggregates
        
    Example:
        {
            "2026-W01": {
                "week": "2026-W01",
                "measurements": 5,
                "status_distribution": {"ok": 4, "warning": 1},
                "avg_warnings": 0.2,
                "avg_managed_children": 2.4,
                "avg_zombie_processes": 0.0,
                "avg_dead_processes": 0.2,
                "trend": "stable_healthy"
            },
            ...
        }
    """
    entries = _load_history_entries(history_file)
    if not entries:
        return {}
    
    # Group venvHealth entries by ISO week
    weekly_data: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for week, timestamp, health_value in _iter_venv_health_metrics(entries):
        weekly_data[week].append({"timestamp": timestamp, "health": health_value})
    
    # Calculate aggregates for each week
    weekly_aggregates: dict[str, dict[str, Any]] = {}
    for week, measurements in sorted(weekly_data.items()):
        aggregate = _build_week_aggregate(week, measurements)
        if aggregate is None:
            continue
        weekly_aggregates[week] = aggregate
    
    return weekly_aggregates


def calculate_multi_week_health_trend(
    weekly_aggregates: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Calculate health trend across multiple weeks.
    
    Args:
        weekly_aggregates: Output from reconstruct_weekly_venv_health
        
    Returns:
        Multi-week health trend summary
    """
    if not weekly_aggregates:
        return {"trend": "no_data"}
    
    sorted_weeks = sorted(weekly_aggregates.keys())
    
    if len(sorted_weeks) < 2:
        return {
            "trend": "insufficient_data",
            "weeks": len(sorted_weeks)
        }
    
    first_week = weekly_aggregates[sorted_weeks[0]]
    last_week = weekly_aggregates[sorted_weeks[-1]]
    
    # Calculate health score (ok=3, warning=2, error=1, unknown=0)
    def health_score(status_dist: dict[str, int]) -> float:
        total = sum(status_dist.values())
        if total == 0:
            return 0.0
        weighted = (
            status_dist.get("ok", 0) * 3 +
            status_dist.get("warning", 0) * 2 +
            status_dist.get("error", 0) * 1
        )
        return weighted / total
    
    first_score = health_score(first_week["status_distribution"])
    last_score = health_score(last_week["status_distribution"])
    change = last_score - first_score
    
    # Determine trend direction
    if abs(change) < 0.2:  # Less than 0.2 score change
        direction = "stable"
    elif change > 0:
        direction = "improving"
    else:
        direction = "degrading"
    
    # Calculate week-over-week changes
    wow_changes: list[float] = []
    for i in range(1, len(sorted_weeks)):
        prev_week = weekly_aggregates[sorted_weeks[i-1]]
        curr_week = weekly_aggregates[sorted_weeks[i]]
        prev_score = health_score(prev_week["status_distribution"])
        curr_score = health_score(curr_week["status_distribution"])
        wow_change = curr_score - prev_score
        wow_changes.append(wow_change)
    
    # Aggregate zombie/dead trends
    total_zombie = sum(w["total_zombie"] for w in weekly_aggregates.values())
    total_dead = sum(w["total_dead"] for w in weekly_aggregates.values())
    total_warnings = sum(w["total_warnings"] for w in weekly_aggregates.values())
    
    return {
        "trend": direction,
        "total_weeks": len(sorted_weeks),
        "first_week": sorted_weeks[0],
        "last_week": sorted_weeks[-1],
        "first_health_score": round(first_score, 2),
        "last_health_score": round(last_score, 2),
        "total_health_change": round(change, 2),
        "avg_weekly_change": round(sum(wow_changes) / len(wow_changes), 2) if wow_changes else 0.0,
        "total_zombie_processes": total_zombie,
        "total_dead_processes": total_dead,
        "total_warnings": total_warnings,
    }


def format_weekly_venv_health_summary(
    weekly_aggregates: dict[str, dict[str, Any]]
) -> str:
    """Format weekly venv health summary for console display.
    
    Args:
        weekly_aggregates: Output from reconstruct_weekly_venv_health
        
    Returns:
        Formatted string
    """
    if not weekly_aggregates:
        return "No weekly venv health data available."
    
    lines = ["Weekly Venv Health Summary", "=" * 80]
    
    for week in sorted(weekly_aggregates.keys()):
        agg = weekly_aggregates[week]
        
        trend_icon = {
            "stable_healthy": "✓",
            "degrading": "↘",
            "unstable": "~",
            "mixed": "±",
            "insufficient_data": "•"
        }.get(agg["trend"], "?")
        
        status_str = ", ".join(f"{k}: {v}" for k, v in agg["status_distribution"].items())
        
        lines.append(
            f"{week}: [{status_str}] | "
            f"{agg['measurements']:2d} measurements | "
            f"⚠ {agg['avg_warnings']:.1f} | "
            f"🧟 {agg['avg_zombie_processes']:.1f} | "
            f"💀 {agg['avg_dead_processes']:.1f} | "
            f"{trend_icon} {agg['trend']}"
        )
    
    # Add multi-week trend
    multi_trend = calculate_multi_week_health_trend(weekly_aggregates)
    if multi_trend.get("trend") not in ["no_data", "insufficient_data"]:
        lines.append("")
        lines.append("Multi-Week Health Trend:")
        lines.append(f"  Period: {multi_trend['first_week']} → {multi_trend['last_week']} ({multi_trend['total_weeks']} weeks)")
        lines.append(f"  Health Score: {multi_trend['first_health_score']:.2f} → {multi_trend['last_health_score']:.2f}")
        lines.append(f"  Total Change: {multi_trend['total_health_change']:+.2f}")
        lines.append(f"  Avg Weekly Change: {multi_trend['avg_weekly_change']:+.2f}")
        lines.append(f"  Trend: {multi_trend['trend']}")
        lines.append(f"  Total Zombie Processes: {multi_trend['total_zombie_processes']}")
        lines.append(f"  Total Dead Processes: {multi_trend['total_dead_processes']}")
        lines.append(f"  Total Warnings: {multi_trend['total_warnings']}")
    
    return "\n".join(lines)


def export_weekly_venv_health_json(
    weekly_aggregates: dict[str, dict[str, Any]],
    output_file: Path
) -> None:
    """Export weekly venv health summary to JSON file.
    
    Args:
        weekly_aggregates: Output from reconstruct_weekly_venv_health
        output_file: Path for JSON output
    """
    multi_trend = calculate_multi_week_health_trend(weekly_aggregates)
    
    output_data = {
        "weekly_aggregates": weekly_aggregates,
        "multi_week_trend": multi_trend,
        "summary": {
            "total_weeks": len(weekly_aggregates),
            "weeks": sorted(weekly_aggregates.keys())
        }
    }
    
    output_file.write_text(
        json.dumps(output_data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )


__all__ = [
    "reconstruct_weekly_venv_health",
    "calculate_multi_week_health_trend",
    "format_weekly_venv_health_summary",
    "export_weekly_venv_health_json",
]
