from __future__ import annotations

import ast
import datetime as _dt
import logging
import re
import tokenize
from collections.abc import Iterable
from io import StringIO
from pathlib import Path
from typing import Any

from manifestguard.validation.inline_markers import is_line_suppressed

from .dummy_recognition_markers import _load_markers
from .dummy_recognition_models import DummyCodeFinding, DummyEvidence, DummyRecognitionResult
from .dummy_recognition_suppressions import apply_dummy_recognition_suppressions

logger = logging.getLogger(__name__)


def _normalize_marker(text: str) -> str:
    return (
        text.lower()
        .replace("-", " ")
        .replace("_", " ")
        .replace(":", " ")
        .replace("/", " ")
        .replace("\\", " ")
    )


def _normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _contains_stub_marker(text: str) -> tuple[bool, str | None]:
    normalized = _normalize_whitespace(_normalize_marker(text))
    # Load all language markers
    all_markers = [
        *_load_markers("en"),
        *_load_markers("de"),
        *_load_markers("fr"),
        *_load_markers("es"),
    ]
    for marker in all_markers:
        normalized_marker = _normalize_whitespace(_normalize_marker(marker))
        if normalized_marker and normalized_marker in normalized:
            return True, marker
    return False, None


def _is_test_path(path: Path) -> bool:
    lower_path = str(path).lower().replace("\\", "/")
    name = path.name.lower()
    parts = {p.lower() for p in path.parts}

    # Build outputs
    if "/dist/" in lower_path or "/build/" in lower_path or "/out/" in lower_path:
        return True

    # Test directories
    if parts.intersection({"tests", "test", "__tests__"}):
        return True

    # Test file naming conventions
    if name.startswith("test_"):
        return True
    if name.endswith("_test.py"):
        return True
    return bool(".test." in name or ".spec." in name)


# Intentionally complex for flexible Python file discovery with test filtering and path resolution
# manifestguard-ignore-next-line: COMPLEXITY
def _iter_python_files(paths: Iterable[str | Path], include_tests: bool) -> list[Path]:
    out: list[Path] = []
    for p in paths:
        path = Path(p)
        if path.is_dir():
            for py_file in path.rglob("*.py"):
                if not include_tests and _is_test_path(py_file):
                    continue
                out.append(py_file)
        elif path.is_file() and path.suffix.lower() == ".py":
            if not include_tests and _is_test_path(path):
                continue
            out.append(path)
    # deterministic
    return sorted({p.resolve() for p in out})


def _is_constant_literal(node: ast.AST | None) -> bool:
    if node is None:
        return True
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, ast.List) and len(node.elts) == 0:
        return True
    if isinstance(node, ast.Tuple) and len(node.elts) == 0:
        return True
    return bool(isinstance(node, ast.Dict) and len(node.keys) == 0)


def _const_text(node: ast.AST | None, source: str) -> str:
    try:
        if node is None:
            return "<const>"
        return ast.get_source_segment(source, node) or "<const>"
    except Exception:
        return "<const>"


def _strip_docstring(stmts: list[ast.stmt]) -> list[ast.stmt]:
    if not stmts:
        return []
    first = stmts[0]
    if (
        isinstance(first, ast.Expr)
        and isinstance(first.value, ast.Constant)
        and isinstance(first.value.value, str)
    ):
        return stmts[1:]
    return stmts


def _is_logging_stmt(stmt: ast.stmt) -> bool:
    if not isinstance(stmt, ast.Expr):
        return False
    call = stmt.value
    if not isinstance(call, ast.Call):
        return False
    func = call.func
    if isinstance(func, ast.Name):
        return func.id in {"print"}
    if isinstance(func, ast.Attribute):
        # logger.info / logging.warning etc.
        base = func.value
        if isinstance(base, ast.Name) and base.id in {"logger", "logging"}:
            return True
    return False


def _success_literal(node: ast.AST | None) -> bool:
    if isinstance(node, ast.Constant):
        # truthy constants are treated as 'success fallback'
        return bool(node.value)
    if isinstance(node, (ast.List, ast.Tuple, ast.Dict)):
        # empty collections are falsy; treat as not success
        return False
    return False


def _pos_to_line_col(text: str, index: int) -> tuple[int, int]:
    # 1-based line/col
    line = text.count("\n", 0, index) + 1
    last_nl = text.rfind("\n", 0, index)
    col0 = index if last_nl == -1 else index - last_nl - 1
    return line, col0 + 1


def _detect_explicit_markers(source_text: str, file_path: Path) -> list[DummyCodeFinding]:
    # Detection module files legitimately reference marker words as detection patterns.
    if file_path.stem.startswith("dummy_recognition"):
        return []
    findings: list[DummyCodeFinding] = []
    try:
        tokens = tokenize.generate_tokens(StringIO(source_text).readline)
        for tok in tokens:
            if tok.type != tokenize.COMMENT:
                continue
            # Ignore ManifestGuard inline suppression directives (they may include strings like "DUMMY-001").
            if "manifestguard-ignore" in tok.string.lower():
                continue
            found, marker = _contains_stub_marker(tok.string)
            if found and marker:
                line, col = tok.start
                findings.append(
                    DummyCodeFinding(
                        code="DUMMY-001",
                        severity="warn",
                        confidence=70,
                        message=f'Explicit stub marker found: "{marker}"',
                        file=str(file_path),
                        line=line,
                        column=col + 1,
                        symbol=None,
                        evidence=DummyEvidence(
                            pattern="explicit-marker",
                            notes=[
                                f"Marker: {marker}",
                                (
                                    f"Comment: {tok.string[:50]}..."
                                    if len(tok.string) > 50
                                    else f"Comment: {tok.string}"
                                ),
                            ],
                        ),
                        remediation="Implement the missing functionality or remove the marker if completed.",
                    ),
                )
    except tokenize.TokenError:
        # If tokenization fails, skip comment layer.
        pass
    return findings


def _has_abstractmethod_decorator(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Return True if the function has an @abstractmethod decorator."""
    for decorator in node.decorator_list:
        if isinstance(decorator, ast.Name) and decorator.id == "abstractmethod":
            return True
        if isinstance(decorator, ast.Attribute) and decorator.attr == "abstractmethod":
            return True
    return False


def _has_click_group_decorator(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Return True if the function has a @click.group or @<grp>.group decorator."""
    for decorator in node.decorator_list:
        dec = decorator.func if isinstance(decorator, ast.Call) else decorator
        if isinstance(dec, ast.Attribute) and dec.attr == "group":
            return True
    return False


def _detect_not_implemented_raises(
    tree: ast.AST, source_text: str, file_path: Path
) -> list[DummyCodeFinding]:
    findings: list[DummyCodeFinding] = []

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self._current_func: ast.FunctionDef | ast.AsyncFunctionDef | None = None

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            prev = self._current_func
            self._current_func = node
            self.generic_visit(node)
            self._current_func = prev

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            self.visit_FunctionDef(node)  # type: ignore[arg-type]

        def visit_Raise(self, node: ast.Raise) -> None:
            if self._current_func is not None and _has_abstractmethod_decorator(self._current_func):
                self.generic_visit(node)
                return
            exc = node.exc
            exc_text = _const_text(exc, source_text)
            found, _marker = _contains_stub_marker(exc_text)
            is_not_impl = False

            if isinstance(exc, ast.Call):
                func = exc.func
                if isinstance(func, ast.Name) and func.id in {"NotImplementedError"}:
                    is_not_impl = True
                if isinstance(func, ast.Attribute) and func.attr in {"NotImplementedError"}:
                    is_not_impl = True

            if found or is_not_impl or "NotImplemented" in exc_text:
                line = getattr(node, "lineno", 1)
                col = getattr(node, "col_offset", 0) + 1
                findings.append(
                    DummyCodeFinding(
                        code="DUMMY-002",
                        severity="error",
                        confidence=95,
                        message="Not implemented exception thrown",
                        file=str(file_path),
                        line=line,
                        column=col,
                        symbol=None,
                        evidence=DummyEvidence(
                            pattern="not-implemented-exception",
                            notes=(
                                [f"Expression: {exc_text}"]
                                if exc_text
                                else ["Expression: <unknown>"]
                            ),
                        ),
                        remediation="Implement the method or remove the stub exception.",
                    ),
                )

            self.generic_visit(node)

    Visitor().visit(tree)
    return findings


def _body_is_noop(body: list[ast.stmt]) -> bool:
    if not body:
        return True
    if all(isinstance(s, ast.Pass) for s in body):
        return True
    return (
        len(body) == 1
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and body[0].value.value is Ellipsis
    )


def _has_effective_params(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    return any(a.arg not in {"self", "cls"} for a in node.args.args) or bool(
        node.args.vararg or node.args.kwarg or node.args.kwonlyargs,
    )


def _detect_noop_function(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    body: list[ast.stmt],
    file_path: Path,
) -> DummyCodeFinding | None:
    if not _body_is_noop(body):
        return None
    if _has_abstractmethod_decorator(node):
        return None
    if _has_click_group_decorator(node):
        return None

    line = getattr(node, "lineno", 1)
    col = getattr(node, "col_offset", 0) + 1
    function_name = node.name
    return DummyCodeFinding(
        code="DUMMY-011",
        severity="warn",
        confidence=80,
        message=f'Function "{function_name}" has empty body (no-op implementation)',
        file=str(file_path),
        line=line,
        column=col,
        symbol=function_name,
        evidence=DummyEvidence(pattern="no-op", notes=["Function body is empty"]),
        remediation="Implement the function logic or remove if not needed.",
    )


def _detect_constant_return_with_params(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    body: list[ast.stmt],
    source_text: str,
    file_path: Path,
) -> DummyCodeFinding | None:
    if not _has_effective_params(node):
        return None
    if len(body) != 1 or not isinstance(body[0], ast.Return):
        return None
    if not _is_constant_literal(body[0].value):
        return None

    line = getattr(node, "lineno", 1)
    col = getattr(node, "col_offset", 0) + 1
    function_name = node.name
    return_value = _const_text(body[0].value, source_text)
    return DummyCodeFinding(
        code="DUMMY-010",
        severity="warn",
        confidence=75,
        message=(
            f'Function "{function_name}" always returns constant "{return_value}" '
            "regardless of parameters"
        ),
        file=str(file_path),
        line=line,
        column=col,
        symbol=function_name,
        evidence=DummyEvidence(
            pattern="constant-return",
            notes=[
                f"Has {len(node.args.args)} parameter(s)",
                f"Always returns: {return_value}",
            ],
        ),
        remediation="Implement actual logic using the parameters or document why constant return is intentional.",
    )


def _try_is_catch_and_ignore(stmt: ast.Try) -> bool:
    if not stmt.handlers:
        return False
    for handler in stmt.handlers:
        handler_body = list(handler.body)
        if not handler_body or all(isinstance(s, ast.Pass) for s in handler_body):
            continue
        if len(handler_body) == 1 and _is_logging_stmt(handler_body[0]):
            continue
        return False
    return True


def _body_has_success_fallback_return(body: list[ast.stmt]) -> bool:
    return any(isinstance(stmt, ast.Return) and _success_literal(stmt.value) for stmt in body)


def _detect_catch_and_ignore_success_fallback(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    body: list[ast.stmt],
    file_path: Path,
) -> list[DummyCodeFinding]:
    # Only consider top-level try blocks in the function body to keep it conservative.
    findings: list[DummyCodeFinding] = []
    function_name = node.name

    for idx, stmt in enumerate(body):
        if not isinstance(stmt, ast.Try):
            continue
        if not _try_is_catch_and_ignore(stmt):
            continue
        if not _body_has_success_fallback_return(body[idx + 1 :]):
            continue

        line = getattr(stmt, "lineno", getattr(node, "lineno", 1))
        col = getattr(stmt, "col_offset", 0) + 1
        findings.append(
            DummyCodeFinding(
                code="DUMMY-012",
                severity="error",
                confidence=85,
                message=(
                    f'Function "{function_name}" catches errors and returns success fallback '
                    "(bypass dummy)"
                ),
                file=str(file_path),
                line=line,
                column=col,
                symbol=function_name,
                evidence=DummyEvidence(
                    pattern="catch-and-ignore",
                    notes=["Catch block empty or only logs", "Returns success value after catch"],
                ),
                remediation="Handle errors explicitly or propagate them. Implement proper error recovery logic.",
            ),
        )

    return findings


# Intentionally complex for comprehensive dummy detection (DUMMY-010, DUMMY-011, DUMMY-012)
# manifestguard-ignore-next-line: COMPLEXITY
def _is_type_checking_guard(test: ast.expr) -> bool:
    """Return True if the given test expression represents a TYPE_CHECKING guard."""

    if isinstance(test, ast.Name) and test.id == "TYPE_CHECKING":
        return True

    if isinstance(test, ast.Attribute) and getattr(test, "attr", None) == "TYPE_CHECKING":
        return True

    try:
        expr_text = ast.unparse(test)
    except Exception:
        expr_text = ""

    return "TYPE_CHECKING" in expr_text


def _build_parent_map(tree: ast.AST) -> dict[ast.AST, ast.AST | None]:
    parent_map: dict[ast.AST, ast.AST | None] = {tree: None}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parent_map[child] = parent
    return parent_map


def _is_guarded_by_type_checking(node: ast.AST, parent_map: dict[ast.AST, ast.AST | None]) -> bool:
    current = parent_map.get(node)
    while current is not None:
        if isinstance(current, ast.If) and _is_type_checking_guard(current.test):
            return True
        current = parent_map.get(current)
    return False


def _detect_constant_return_noop_and_catch_ignore(
    tree: ast.AST,
    source_text: str,
    file_path: Path,
) -> list[DummyCodeFinding]:
    findings: list[DummyCodeFinding] = []
    parent_map = _build_parent_map(tree)

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        if _is_guarded_by_type_checking(node, parent_map):
            continue

        body = _strip_docstring(list(node.body))

        finding = _detect_noop_function(node, body, file_path)
        if finding is not None:
            findings.append(finding)

        finding = _detect_constant_return_with_params(node, body, source_text, file_path)
        if finding is not None:
            findings.append(finding)

        findings.extend(_detect_catch_and_ignore_success_fallback(node, body, file_path))

    return findings


_TEST_ARTIFACT_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("print-test", re.compile(r"print\s*\(\s*['\"]test", re.IGNORECASE)),
    ("breakpoint", re.compile(r"\bbreakpoint\s*\(\s*\)")),
    ("pdb", re.compile(r"pdb\.set_trace\s*\(\s*\)")),
    ("sleep-long", re.compile(r"\bsleep\s*\(\s*\d{4,}\s*\)")),
    ("sk-test", re.compile(r"['\"]sk-test-[a-zA-Z0-9]+['\"]")),
    ("dummy-token", re.compile(r"['\"]dummy[_-]?token['\"]", re.IGNORECASE)),
    ("test-key", re.compile(r"['\"]test[_-]?key['\"]", re.IGNORECASE)),
    ("test-mode", re.compile(r"TEST_MODE")),
]


def _detect_test_artifacts(source_text: str, file_path: Path) -> list[DummyCodeFinding]:
    # The detector modules themselves legitimately contain strings that look like
    # test artifacts (e.g. "dummy-token", "test-key") as detection patterns.
    # To keep results focused on target projects, we skip flagging these files.
    if file_path.stem.startswith("dummy_recognition"):
        return []

    findings: list[DummyCodeFinding] = []
    for _name, pattern in _TEST_ARTIFACT_PATTERNS:
        for match in pattern.finditer(source_text):
            line, col = _pos_to_line_col(source_text, match.start())
            findings.append(
                DummyCodeFinding(
                    code="DUMMY-030",
                    severity="warn",
                    confidence=65,
                    message=f'Test/debug artifact found in runtime code: "{match.group(0)}"',
                    file=str(file_path),
                    line=line,
                    column=col,
                    symbol=None,
                    evidence=DummyEvidence(
                        pattern="test-artifact", notes=[f"Match: {match.group(0)}"]
                    ),
                    remediation="Remove debug/test code from production sources or move to test files.",
                ),
            )
    return findings


# Intentionally complex for orchestrating multiple dummy code detection passes with suppression handling
# manifestguard-ignore-next-line: COMPLEXITY
def run_dummy_recognition(
    paths: list[str | Path] | str | Path,
    *,
    include_tests: bool = False,
    suppressions: list[dict[str, Any]] | None = None,
    workspace_root: Path | None = None,
    now: _dt.date | _dt.datetime | None = None,
) -> DummyRecognitionResult:
    """Run dummy recognition on a list of files/dirs.

    Args:
        paths: File and/or directory paths to scan.
        include_tests: When False (default), test/spec files are excluded.

    """
    input_paths = [paths] if isinstance(paths, (str, Path)) else list(paths)
    files_to_scan = _iter_python_files(input_paths, include_tests=include_tests)

    all_findings: list[DummyCodeFinding] = []
    scanned_files = 0

    for file_path in files_to_scan:
        try:
            source_text = file_path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source_text)

            all_findings.extend(_detect_explicit_markers(source_text, file_path))
            all_findings.extend(_detect_not_implemented_raises(tree, source_text, file_path))
            all_findings.extend(
                _detect_constant_return_noop_and_catch_ignore(tree, source_text, file_path)
            )
            all_findings.extend(_detect_test_artifacts(source_text, file_path))

            scanned_files += 1
        except Exception as e:
            # best-effort: skip unparseable/unreadable files
            logger.debug(f"Failed to scan {file_path} for dummy code: {e}")
            continue

    all_findings = sorted(all_findings, key=lambda f: (f.file, f.line, f.column, f.code))

    # Inline suppression markers in code (e.g. "# manifestguard-ignore-next-line: DUMMY-001").
    inline_suppressed = 0
    kept_inline: list[DummyCodeFinding] = []
    for finding in all_findings:
        try:
            if is_line_suppressed(Path(finding.file), int(finding.line), finding.code):
                inline_suppressed += 1
                continue
        except Exception:
            # Best-effort: if suppression check fails, keep the finding.
            pass
        kept_inline.append(finding)
    all_findings = kept_inline

    if suppressions:
        all_findings, suppressed = apply_dummy_recognition_suppressions(
            all_findings,
            suppressions,
            workspace_root=workspace_root,
            now=now,
        )
    else:
        suppressed = 0

    stats = {
        "totalFiles": len(files_to_scan),
        "scannedFiles": scanned_files,
        "markerFindings": sum(1 for f in all_findings if f.code in {"DUMMY-001", "DUMMY-002"}),
        "constantReturnFindings": sum(
            1 for f in all_findings if f.code in {"DUMMY-010", "DUMMY-011", "DUMMY-012"}
        ),
        "noOpFindings": sum(1 for f in all_findings if f.code == "DUMMY-011"),
        "testArtifactFindings": sum(1 for f in all_findings if f.code == "DUMMY-030"),
        "inlineSuppressedFindings": inline_suppressed,
        "suppressedFindings": suppressed,
    }

    return DummyRecognitionResult(findings=all_findings, stats=stats)
