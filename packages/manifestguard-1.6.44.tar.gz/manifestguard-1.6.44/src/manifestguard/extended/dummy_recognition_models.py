from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DummyEvidence:
    pattern: str
    notes: list[str]


@dataclass(frozen=True)
class DummyCodeFinding:
    code: str
    severity: str  # 'error' | 'warn' | 'info'
    confidence: int  # 0-100
    message: str
    file: str
    line: int
    column: int
    symbol: str | None
    evidence: DummyEvidence
    remediation: str


@dataclass(frozen=True)
class DummyRecognitionResult:
    findings: list[DummyCodeFinding]
    stats: dict[str, int]
