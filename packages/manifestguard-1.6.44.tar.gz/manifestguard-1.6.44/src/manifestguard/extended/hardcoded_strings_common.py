"""Shared helpers for hardcoded-string scanners.

These scanners are intentionally heuristic (regex/line-based) to remain fast and
avoid additional parsing dependencies.

The goal of this module is to keep GUI and CLI hardcoded-string checks aligned
and reduce duplicated logic.
"""

from __future__ import annotations

import fnmatch
import json
import re
from pathlib import Path
from typing import Any, Iterable, Sequence


STRING_LITERAL_RE = re.compile(r"(?P<q>['\"])(?P<text>(?:\\.|(?!\1).)*?)(?P=q)")


def load_manifestguard_json_dict(workspace_root: Path) -> dict[str, Any] | None:
    """Best-effort read+parse of manifestguard.json.

    Returns a dict on success, otherwise None.
    """

    config_path = workspace_root / "manifestguard.json"
    if not config_path.exists():
        return None

    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        return None

    return raw if isinstance(raw, dict) else None


def get_first_dict_block(raw: dict[str, Any], candidates: Sequence[Sequence[str]]) -> dict[str, Any] | None:
    """Return the first nested dict matching any candidate path."""

    for path in candidates:
        current: Any = raw
        for key in path:
            if not isinstance(current, dict):
                current = None
                break
            current = current.get(key)
        if isinstance(current, dict):
            return current
    return None


def coerce_str_list(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    out: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            out.append(text)
    return out


def coerce_bool(value: object, default: bool) -> bool:
    return value if isinstance(value, bool) else default


def coerce_nonneg_int(value: object, default: int) -> int:
    if not isinstance(value, int):
        return default
    return max(value, 0)


def is_comment_line(line: str) -> bool:
    return line.lstrip().startswith("#")


def update_triple_quote_state(line: str, in_triple: str | None) -> str | None:
    """Best-effort triple-quote skipping.

    Returns the new in_triple marker (triple-single or triple-double), or None.

    This is heuristic. It reduces false positives in docstrings/comment blocks
    without requiring AST parsing.
    """

    markers = ("'''", '"""')

    if in_triple:
        if in_triple in line:
            # If we see the same marker, we assume it closes here.
            # Handle inline open+close by checking occurrence count parity.
            if line.count(in_triple) % 2 == 1:
                return None
        return in_triple

    for marker in markers:
        if marker in line:
            if line.count(marker) % 2 == 1:
                return marker
    return None


def looks_like_constant(value: str) -> bool:
    # e.g. "HTTP_OK", "UTF_8".
    return bool(value) and value.isupper() and "_" in value


def should_consider_string(value: str) -> bool:
    if not value:
        return False
    stripped = value.strip()
    if not stripped:
        return False
    if len(stripped) < 2:
        return False

    # Avoid f-string templates / code-ish content.
    if "{" in stripped or "}" in stripped:
        return False

    if stripped.startswith("_"):
        return False

    if looks_like_constant(stripped):
        return False

    return True


def slugify_for_i18n_key(prefix: str, value: str) -> str | None:
    """Create a stable, readable key suggestion.

    Examples:
        prefix='gui', value='Hello World' -> 'gui.hello_world'
        prefix='cli', value='Invalid option' -> 'cli.invalid_option'
    """

    text = (value or "").strip().lower()
    if not text:
        return None

    # Remove common punctuation; keep alnum and spaces.
    text = re.sub(r"[^a-z0-9\s]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return None

    slug = text.replace(" ", "_")
    slug = re.sub(r"_+", "_", slug).strip("_")
    if not slug:
        return None

    if slug[0].isdigit():
        slug = f"s_{slug}"

    # Bound key length to keep reports tidy.
    if len(slug) > 40:
        slug = slug[:40].rstrip("_")

    return f"{prefix}.{slug}"


def relpath_for_report(workspace_root: Path, path: Path) -> str:
    try:
        rel = path.relative_to(workspace_root)
        return str(rel).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def _matches_any_pattern(rel_lower: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(rel_lower, pat.lower()) for pat in patterns)


def filter_paths_by_include_exclude(
    workspace_root: Path,
    files: list[Path],
    include: list[str] | None,
    exclude: list[str] | None,
) -> list[Path]:
    include = [p.replace("\\", "/") for p in (include or []) if str(p).strip()]
    exclude = [p.replace("\\", "/") for p in (exclude or []) if str(p).strip()]

    if not include and not exclude:
        return files

    filtered: list[Path] = []
    for path in files:
        rel_lower = relpath_for_report(workspace_root, path).lower()
        if include and not _matches_any_pattern(rel_lower, include):
            continue
        if exclude and _matches_any_pattern(rel_lower, exclude):
            continue
        filtered.append(path)

    return filtered
