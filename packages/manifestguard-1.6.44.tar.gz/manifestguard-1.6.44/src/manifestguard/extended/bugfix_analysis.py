"""Bugfix Analysis - Git commit history analysis for bugfix tracking.

Provides utilities for analyzing git commit messages to detect bugfixes,
categorize them by severity and domain, and calculate bugs-per-day metrics.
"""

import re
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class BugfixMetrics:
    """Bugfix tracking metrics from git history.

    Attributes:
        total: Total number of bugfixes detected
        bpd: Bugs per day metric
        days_analyzed: Number of days in analysis period
        by_severity: Count of bugfixes by severity (critical/major/minor)
        by_category: Count of bugfixes by domain (dashboard/api/packaging/etc.)
        recent_fixes: List of recent bugfix commit messages (limited)

    """

    total: int = 0
    bpd: float = 0.0
    days_analyzed: int = 0
    by_severity: dict[str, int] = field(
        default_factory=lambda: {
            "critical": 0,
            "major": 0,
            "minor": 0,
        }
    )
    by_category: dict[str, int] = field(
        default_factory=lambda: {
            "dashboard": 0,
            "api": 0,
            "packaging": 0,
            "tests": 0,
            "documentation": 0,
            "i18n": 0,
            "other": 0,
        }
    )
    recent_fixes: list[dict] = field(default_factory=list)


def get_bugfix_patterns() -> tuple:
    """Get compiled regex pattern and keyword lists for bugfix detection.

    Returns:
        Tuple of (pattern, critical_keywords, major_keywords, category_keywords)

    """
    bugfix_patterns = [
        r"\bfix\b",
        r"\bbug\b",
        r"\bissue\b",
        r"\berror\b",
        r"\bcrash\b",
        r"\bfail\b",
        r"\bbroke\b",
        r"\bproblem\b",
        r"\bresolve\b",
        r"\bpatch\b",
        r"\bhotfix\b",
    ]
    combined_pattern = re.compile("|".join(bugfix_patterns), re.IGNORECASE)

    critical_keywords = ["critical", "blocker", "crash", "data loss", "security"]
    major_keywords = ["major", "important", "broken", "fail"]

    category_keywords = {
        "dashboard": ["dashboard", "ui", "gui", "view"],
        "api": ["api", "endpoint", "rest", "graphql"],
        "packaging": ["package", "build", "dist", "setup"],
        "tests": ["test", "spec", "pytest", "unittest"],
        "documentation": ["doc", "docs", "readme", "guide"],
        "i18n": ["i18n", "translation", "locale", "lang"],
    }

    return combined_pattern, critical_keywords, major_keywords, category_keywords


def categorize_bugfix(
    msg: str,
    metrics: BugfixMetrics,
    critical_keywords: list,
    major_keywords: list,
    category_keywords: dict,
) -> None:
    """Categorize a bugfix commit by severity and category.

    Args:
        msg: Commit message
        metrics: BugfixMetrics to update
        critical_keywords: Keywords indicating critical severity
        major_keywords: Keywords indicating major severity
        category_keywords: Dict mapping categories to their keywords

    """
    msg_lower = msg.lower()

    # Determine severity
    if any(kw in msg_lower for kw in critical_keywords):
        metrics.by_severity["critical"] += 1
    elif any(kw in msg_lower for kw in major_keywords):
        metrics.by_severity["major"] += 1
    else:
        metrics.by_severity["minor"] += 1

    # Determine category
    categorized = False
    for category, keywords in category_keywords.items():
        if any(kw in msg_lower for kw in keywords):
            metrics.by_category[category] += 1
            categorized = True
            break
    if not categorized:
        metrics.by_category["other"] += 1

    # Store recent fixes (limit to 10)
    if len(metrics.recent_fixes) < 10:
        metrics.recent_fixes.append(
            {
                "message": msg[:100],
                "timestamp": "",
            }
        )


def calculate_bpd_metrics(
    metrics: BugfixMetrics,
    bugfix_count: int,
    month_start: datetime,
    now: datetime,
) -> None:
    """Calculate bugs per day (BPD) metric.

    Args:
        metrics: BugfixMetrics to update
        bugfix_count: Total number of bugfixes found
        month_start: Start of analysis period
        now: Current datetime

    """
    metrics.total = bugfix_count

    days_analyzed = (now - month_start).days
    if days_analyzed == 0:
        days_analyzed = 1

    metrics.days_analyzed = days_analyzed
    metrics.bpd = round((metrics.total / days_analyzed) * 100) / 100
