"""Dependency health collection used by extended metrics."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from packaging.requirements import InvalidRequirement, Requirement

if TYPE_CHECKING:
    from .metrics import DependencyMetrics

logger = logging.getLogger(__name__)
DEPENDENCY_CACHE_FILE = Path(".mgpy") / "cache" / "dependency-health.json"
DEPENDENCY_CACHE_TTL_SECONDS = 900
DEPENDENCY_CACHE_BACKGROUND_REFRESH_SECONDS = 60


def _resolve_project_python_executable(
    workspace_root: Path, *, python_override: str | None = None
) -> str:
    if python_override:
        try:
            override_path = Path(python_override)
            if override_path.exists():
                return str(override_path)
        except Exception:
            pass

    return sys.executable


def _dependency_command_env() -> dict[str, str]:
    return {
        **os.environ,
        "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        "PIP_PROGRESS_BAR": "off",
        "PYTHONWARNINGS": os.environ.get("PYTHONWARNINGS", "ignore"),
    }


def _load_pyproject_data(pyproject_path: Path) -> dict | None:
    try:
        if sys.version_info >= (3, 11):
            import tomllib  # noqa: PLC0415
        else:
            import tomli as tomllib  # noqa: PLC0415

        with pyproject_path.open("rb") as handle:
            data = tomllib.load(handle)
    except Exception:
        return None

    return data if isinstance(data, dict) else None


def _declared_dependency_names(workspace_root: Path) -> set[str]:
    pyproject_path = workspace_root / "pyproject.toml"
    if not pyproject_path.exists():
        return set()

    data = _load_pyproject_data(pyproject_path)
    if not data:
        return set()

    project = data.get("project")
    if not isinstance(project, dict):
        return set()

    deps = project.get("dependencies")
    if not isinstance(deps, list):
        return set()

    names: set[str] = set()
    for raw in deps:
        if not isinstance(raw, str):
            continue
        try:
            req = Requirement(raw)
        except InvalidRequirement:
            continue
        names.add(req.name.lower())

    return names


def _load_installed_package_names(workspace_root: Path, python_executable: str) -> set[str]:
    try:
        result = subprocess.run(  # Controlled pip invocation  # noqa: S603
            [python_executable, "-m", "pip", "list", "--format=json"],
            check=False,
            cwd=workspace_root,
            capture_output=True,
            text=True,
            timeout=15,
            env=_dependency_command_env(),
        )
    except Exception:
        return set()

    if result.returncode != 0:
        return set()

    try:
        items = json.loads(result.stdout)
    except Exception:
        return set()

    if not isinstance(items, list):
        return set()

    names: set[str] = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if isinstance(name, str) and name:
            names.add(name.lower())
    return names


def _installed_versions_from_snapshot(installed_packages: list[dict[str, str]]) -> dict[str, str]:
    versions: dict[str, str] = {}
    for item in installed_packages:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        version = item.get("version")
        if isinstance(name, str) and name and isinstance(version, str):
            versions[name.lower()] = version
    return versions


def _load_installed_package_versions(
    workspace_root: Path,
    python_executable: str,
) -> dict[str, str]:
    try:
        result = subprocess.run(  # Controlled pip invocation  # noqa: S603
            [python_executable, "-m", "pip", "list", "--format=json"],
            check=False,
            cwd=workspace_root,
            capture_output=True,
            text=True,
            timeout=15,
            env=_dependency_command_env(),
        )
    except Exception:
        return {}

    if result.returncode != 0:
        return {}

    try:
        items = json.loads(result.stdout)
    except Exception:
        return {}

    if not isinstance(items, list):
        return {}

    versions: dict[str, str] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        version = item.get("version")
        if isinstance(name, str) and name and isinstance(version, str):
            versions[name.lower()] = version
    return versions


def _compute_dependency_cache_key(
    workspace_root: Path,
    declared_names: set[str],
    installed_versions: dict[str, str],
    python_executable: str,
) -> str:
    pyproject_path = workspace_root / "pyproject.toml"
    pyproject_hash = ""
    if pyproject_path.exists():
        try:
            pyproject_hash = hashlib.sha256(pyproject_path.read_bytes()).hexdigest()
        except OSError:
            pyproject_hash = ""

    payload = {
        "python": python_executable,
        "pyprojectHash": pyproject_hash,
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _load_dependency_cache_payload(
    workspace_root: Path, cache_key: str
) -> tuple[dict[str, int] | None, float | None]:
    cache_path = workspace_root / DEPENDENCY_CACHE_FILE
    if not cache_path.exists():
        return None, None

    try:
        payload = json.loads(cache_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None, None

    if not isinstance(payload, dict):
        return None, None
    if payload.get("cacheKey") != cache_key:
        return None, None

    cached_at = payload.get("cachedAt")
    if not isinstance(cached_at, (int, float)):
        return None, None
    cache_age_seconds = time.time() - float(cached_at)
    if cache_age_seconds > DEPENDENCY_CACHE_TTL_SECONDS:
        return None, None

    result = payload.get("result")
    if not isinstance(result, dict):
        return None, None

    normalized: dict[str, int] = {}
    for key in (
        "direct_count",
        "transitive_count",
        "outdated_count",
        "vulnerable_high",
        "vulnerable_critical",
    ):
        value = result.get(key, 0)
        if isinstance(value, (int, float)):
            normalized[key] = int(value)
        else:
            normalized[key] = 0
    return normalized, cache_age_seconds


def _load_cached_dependency_health(
    workspace_root: Path, cache_key: str
) -> tuple[dict[str, int] | None, float | None]:
    normalized, cache_age_seconds = _load_dependency_cache_payload(workspace_root, cache_key)
    if normalized is None or cache_age_seconds is None:
        return None, None
    if cache_age_seconds > DEPENDENCY_CACHE_TTL_SECONDS:
        return None, None
    return normalized, cache_age_seconds


def _load_stale_cached_dependency_health(
    workspace_root: Path, cache_key: str
) -> tuple[dict[str, int] | None, float | None]:
    return _load_dependency_cache_payload(workspace_root, cache_key)


def _save_cached_dependency_health(
    workspace_root: Path,
    cache_key: str,
    result: dict[str, Any],
) -> None:
    cache_path = workspace_root / DEPENDENCY_CACHE_FILE
    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(
            json.dumps(
                {
                    "cacheKey": cache_key,
                    "cachedAt": time.time(),
                    "ttlSeconds": DEPENDENCY_CACHE_TTL_SECONDS,
                    "result": result,
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )
    except OSError:
        logger.debug("Failed to write dependency cache", exc_info=True)


def _refresh_dependency_health_cache(
    workspace_root: Path,
    *,
    cache_key: str,
    declared_names: set[str],
    python_executable: str,
    installed_versions: dict[str, str] | None = None,
) -> dict[str, int]:
    from .metrics import DependencyMetrics  # noqa: PLC0415 - avoid circular import

    metrics = DependencyMetrics()
    resolved_installed_versions = installed_versions or _load_installed_package_versions(
        workspace_root,
        python_executable,
    )
    installed_names = set(resolved_installed_versions.keys())
    metrics.direct_count = len(declared_names & installed_names) if declared_names else 0
    metrics.transitive_count = max(len(installed_names) - metrics.direct_count, 0)

    # Determinism rule:
    # If the project declares no dependencies, do not turn the active Python
    # environment into "transitive dependencies" (it varies across machines).
    # In that case, dependency health should remain empty/zero.
    if not declared_names:
        cached_result = {
            "direct_count": metrics.direct_count,
            "transitive_count": metrics.transitive_count,
            "outdated_count": 0,
            "vulnerable_high": 0,
            "vulnerable_critical": 0,
        }
        _save_cached_dependency_health(workspace_root, cache_key, cached_result)
        return cached_result

    outdated_command = [
        python_executable,
        "-m",
        "pip",
        "list",
        "--outdated",
        "--not-required",
        "--format=json",
    ]

    result = subprocess.run(  # Controlled pip invocation  # noqa: S603
        outdated_command,
        check=False,
        cwd=workspace_root,
        capture_output=True,
        text=True,
        timeout=15,
        env=_dependency_command_env(),
    )
    if result.returncode == 0:
        outdated = json.loads(result.stdout)
        if isinstance(outdated, list):
            if declared_names:
                metrics.outdated_count = sum(
                    1
                    for item in outdated
                    if isinstance(item, dict)
                    and isinstance(item.get("name"), str)
                    and item["name"].lower() in declared_names
                )
            else:
                metrics.outdated_count = len(outdated)

    audit_result = subprocess.run(  # Controlled pip_audit invocation  # noqa: S603
        [python_executable, "-m", "pip_audit", "--format=json"],
        check=False,
        cwd=workspace_root,
        capture_output=True,
        text=True,
        timeout=20,
        env=_dependency_command_env(),
    )
    if audit_result.returncode == 0:
        audit_data = json.loads(audit_result.stdout)
        for vuln in audit_data.get("vulnerabilities", []):
            if vuln.get("severity") == "high":
                metrics.vulnerable_high += 1
            elif vuln.get("severity") == "critical":
                metrics.vulnerable_critical += 1

    cached_result = {
        "direct_count": metrics.direct_count,
        "transitive_count": metrics.transitive_count,
        "outdated_count": metrics.outdated_count,
        "vulnerable_high": metrics.vulnerable_high,
        "vulnerable_critical": metrics.vulnerable_critical,
    }
    _save_cached_dependency_health(workspace_root, cache_key, cached_result)
    return cached_result


def _start_background_dependency_refresh(
    workspace_root: Path,
    *,
    cache_key: str,
    declared_names: set[str],
    python_executable: str,
) -> None:
    def _runner() -> None:
        try:
            _refresh_dependency_health_cache(
                workspace_root,
                cache_key=cache_key,
                declared_names=declared_names,
                python_executable=python_executable,
            )
        except Exception:
            logger.debug("Background dependency refresh failed", exc_info=True)

    thread = threading.Thread(
        target=_runner,
        name="mgpy-dependency-refresh",
        daemon=True,
    )
    thread.start()


def _collect_dependency_metrics_sync(
    workspace_root: Path,
    *,
    deep_analysis_mode: bool = True,
    installed_packages: list[dict[str, str]] | None = None,
    python_override: str | None = None,
) -> "DependencyMetrics":
    from .metrics import DependencyMetrics  # noqa: PLC0415 - avoid circular import

    metrics = DependencyMetrics()
    python_executable = _resolve_project_python_executable(workspace_root, python_override=python_override)

    declared_names = _declared_dependency_names(workspace_root)
    cache_key = _compute_dependency_cache_key(
        workspace_root,
        declared_names,
        {},
        python_executable,
    )

    cached, cache_age_seconds = _load_cached_dependency_health(workspace_root, cache_key)
    if cached is not None and {"direct_count", "transitive_count"}.issubset(cached):
        metrics.direct_count = cached.get("direct_count", 0)
        metrics.transitive_count = cached.get("transitive_count", 0)
        if not deep_analysis_mode:
            return metrics
        metrics.outdated_count = cached.get("outdated_count", 0)
        metrics.vulnerable_high = cached.get("vulnerable_high", 0)
        metrics.vulnerable_critical = cached.get("vulnerable_critical", 0)
        if (
            cache_age_seconds is not None
            and cache_age_seconds >= DEPENDENCY_CACHE_BACKGROUND_REFRESH_SECONDS
        ):
            _start_background_dependency_refresh(
                workspace_root,
                cache_key=cache_key,
                declared_names=declared_names,
                python_executable=python_executable,
            )
        return metrics

    stale_cached, stale_age_seconds = _load_stale_cached_dependency_health(
        workspace_root,
        cache_key,
    )
    if stale_cached is not None and {"direct_count", "transitive_count"}.issubset(stale_cached):
        metrics.direct_count = stale_cached.get("direct_count", 0)
        metrics.transitive_count = stale_cached.get("transitive_count", 0)
        if not deep_analysis_mode:
            return metrics
        metrics.outdated_count = stale_cached.get("outdated_count", 0)
        metrics.vulnerable_high = stale_cached.get("vulnerable_high", 0)
        metrics.vulnerable_critical = stale_cached.get("vulnerable_critical", 0)
        if stale_age_seconds is None or stale_age_seconds >= DEPENDENCY_CACHE_BACKGROUND_REFRESH_SECONDS:
            _start_background_dependency_refresh(
                workspace_root,
                cache_key=cache_key,
                declared_names=declared_names,
                python_executable=python_executable,
            )
        return metrics

    installed_versions = (
        _installed_versions_from_snapshot(installed_packages)
        if installed_packages is not None
        else _load_installed_package_versions(workspace_root, python_executable)
    )
    installed_names = set(installed_versions.keys())
    metrics.direct_count = len(declared_names & installed_names) if declared_names else 0
    metrics.transitive_count = max(len(installed_names) - metrics.direct_count, 0)
    if not deep_analysis_mode or not declared_names:
        return metrics

    if cached is not None:
        metrics.outdated_count = cached.get("outdated_count", 0)
        metrics.vulnerable_high = cached.get("vulnerable_high", 0)
        metrics.vulnerable_critical = cached.get("vulnerable_critical", 0)
        return metrics

    try:
        refreshed = _refresh_dependency_health_cache(
            workspace_root,
            cache_key=cache_key,
            declared_names=declared_names,
            python_executable=python_executable,
            installed_versions=installed_versions,
        )
        metrics.direct_count = refreshed.get("direct_count", metrics.direct_count)
        metrics.transitive_count = refreshed.get("transitive_count", metrics.transitive_count)
        metrics.outdated_count = refreshed.get("outdated_count", 0)
        metrics.vulnerable_high = refreshed.get("vulnerable_high", 0)
        metrics.vulnerable_critical = refreshed.get("vulnerable_critical", 0)
    except Exception as exc:
        logger.debug("Dependency metrics collection failed: %s", exc)

    return metrics


def collect_current_dependency_inventory(
    workspace_root: Path, *, python_override: str | None = None
) -> tuple[int, int]:
    """Return current direct and transitive dependency counts for the active environment."""
    declared_names = _declared_dependency_names(workspace_root)
    python_executable = _resolve_project_python_executable(workspace_root, python_override=python_override)
    installed_names = set(_load_installed_package_versions(workspace_root, python_executable).keys())
    direct_count = len(declared_names & installed_names) if declared_names else 0
    transitive_count = max(len(installed_names) - direct_count, 0)
    return direct_count, transitive_count


async def collect_dependency_metrics(
    workspace_root: Path,
    *,
    deep_analysis_mode: bool = True,
    installed_packages: list[dict[str, str]] | None = None,
    python_override: str | None = None,
) -> DependencyMetrics:
    """Collect dependency health data (best-effort).

    Always collects a fast local inventory of direct/transitive packages.
    By default, outdated/vulnerability checks also run. Callers may opt out of
    those expensive checks explicitly when they only need the local inventory.

    Returns a DependencyMetrics instance (imported lazily to avoid cycles).
    """
    return await asyncio.to_thread(
        _collect_dependency_metrics_sync,
        workspace_root,
        deep_analysis_mode=deep_analysis_mode,
        installed_packages=installed_packages,
        python_override=python_override,
    )
