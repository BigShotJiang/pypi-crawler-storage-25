from __future__ import annotations

from .metrics import Recommendation


class _MetricsRecommendationsQualityStaticMixin:
    def _recommend_typing_improvements(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        type_hints_stats = self._analyze_type_hints()
        if type_hints_stats and type_hints_stats.get("coverage_percent", 100) < 60:
            total_funcs = type_hints_stats.get("total_functions", 0)
            typed_funcs = type_hints_stats.get("typed_functions", 0)
            coverage = type_hints_stats.get("coverage_percent", 0)

            recs.append(
                Recommendation(
                    category="typing",
                    id="missing-type-hints",
                    priority="medium",
                    summary=(
                        f"Type hints coverage is low ({coverage:.1f}%). "
                        f"Only {typed_funcs}/{total_funcs} functions are type-hinted"
                    ),
                    proposed_fix=(
                        "Add type annotations to function signatures. "
                        "Start with public APIs and complex functions."
                    ),
                    confidence=0.90,
                    effort_minutes=60,
                    impact_score=10,
                    code_example=(
                        "# ❌ BAD: No type hints\n"
                        "def process_data(data, config):\n"
                        "    return data.get('value') * config['multiplier']\n\n"
                        "# ✅ GOOD: Full type hints\n"
                        "from typing import Any\n\n"
                        "def process_data(\n"
                        "    data: dict[str, Any],\n"
                        "    config: dict[str, int]\n"
                        ") -> int | None:\n"
                        "    value = data.get('value')\n"
                        "    if value is None:\n"
                        "        return None\n"
                        "    return value * config['multiplier']"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/type-hints",
                    files_affected=type_hints_stats.get("files_with_low_coverage", [])[:5],
                ),
            )
        return recs

    def _recommend_documentation_coverage(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        doc_stats = self._analyze_documentation()
        if doc_stats and doc_stats.get("coverage_percent", 100) < 70:
            total_items = doc_stats.get("total_items", 0)
            documented_items = doc_stats.get("documented_items", 0)
            coverage = doc_stats.get("coverage_percent", 0)

            recs.append(
                Recommendation(
                    category="documentation",
                    id="low-documentation-coverage",
                    priority="medium",
                    summary=(
                        f"Documentation coverage is low ({coverage:.1f}%). "
                        f"Only {documented_items}/{total_items} functions/classes have docstrings"
                    ),
                    proposed_fix=(
                        "Add docstrings with Args, Returns, and Raises sections. "
                        "Use Google or NumPy docstring style."
                    ),
                    confidence=0.95,
                    effort_minutes=90,
                    impact_score=8,
                    code_example=(
                        "# ❌ BAD: No docstring\n"
                        "def calculate_total(items, tax_rate):\n"
                        "    return sum(items) * (1 + tax_rate)\n\n"
                        "# ✅ GOOD: Complete docstring\n"
                        "def calculate_total(\n"
                        "    items: list[float],\n"
                        "    tax_rate: float\n"
                        ") -> float:\n"
                        '    """\n'
                        "    Calculate total price with tax.\n"
                        "    \n"
                        "    Args:\n"
                        "        items: List of item prices\n"
                        "        tax_rate: Tax rate as decimal (e.g., 0.19 for 19%)\n"
                        "    \n"
                        "    Returns:\n"
                        "        Total price including tax\n"
                        "    \n"
                        "    Raises:\n"
                        "        ValueError: If tax_rate is negative\n"
                        '    """\n'
                        "    if tax_rate < 0:\n"
                        "        raise ValueError('Tax rate cannot be negative')\n"
                        "    return sum(items) * (1 + tax_rate)"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/documentation",
                    files_affected=doc_stats.get("files_with_low_coverage", [])[:5],
                ),
            )
        return recs

    def _recommend_pep8_cleanup(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        pep8_violations = self._check_pep8_violations()
        if pep8_violations and pep8_violations.get("total_violations", 0) > 50:
            total = pep8_violations.get("total_violations", 0)
            top_types = pep8_violations.get("top_violation_types", [])[:3]
            top_display = (
                ", ".join(f"{v['code']} ({v['count']})" for v in top_types)
                if top_types
                else "various"
            )

            recs.append(
                Recommendation(
                    category="style",
                    id="pep8-violations",
                    priority="medium",
                    summary=(
                        f"{total} PEP 8 style violations found. " f"Top issues: {top_display}"
                    ),
                    proposed_fix=(
                        "Run autopep8 or black formatter to auto-fix most issues. "
                        "Configure pre-commit hooks for consistent formatting."
                    ),
                    confidence=0.98,
                    effort_minutes=30,
                    impact_score=5,
                    code_example=(
                        "# Auto-fix with black:\n"
                        "$ pip install black\n"
                        "$ black src/\n\n"
                        "# Or autopep8:\n"
                        "$ pip install autopep8\n"
                        "$ autopep8 --in-place --aggressive --aggressive -r src/\n\n"
                        "# Configure pre-commit:\n"
                        "# .pre-commit-config.yaml\n"
                        "repos:\n"
                        "  - repo: https://github.com/psf/black\n"
                        "    rev: 24.1.1\n"
                        "    hooks:\n"
                        "      - id: black"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/pep8-style",
                    files_affected=pep8_violations.get("files_with_violations", [])[:5],
                ),
            )
        return recs

    def _recommend_style_consistency(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        style_issues = self._check_style_consistency()
        if style_issues and style_issues.get("inconsistencies", 0) > 0:
            issues = style_issues.get("inconsistencies", 0)
            issue_types = style_issues.get("issue_types", [])
            issue_display = ", ".join(issue_types[:3]) if issue_types else "various"

            recs.append(
                Recommendation(
                    category="style",
                    id="inconsistent-code-style",
                    priority="medium",
                    summary=(
                        f"{issues} code style inconsistencies detected. " f"Issues: {issue_display}"
                    ),
                    proposed_fix=(
                        "Standardize on one style: Use single quotes OR double quotes, "
                        "spaces OR tabs (prefer spaces). Configure formatter."
                    ),
                    confidence=0.85,
                    effort_minutes=45,
                    impact_score=5,
                    code_example=(
                        "# ❌ BAD: Mixed quote styles\n"
                        'name = "John"  # Double quotes\n'
                        "title = 'Engineer'  # Single quotes\n\n"
                        "# ✅ GOOD: Consistent quotes\n"
                        'name = "John"\n'
                        'title = "Engineer"\n\n'
                        "# Or consistently use single quotes:\n"
                        "name = 'John'\n"
                        "title = 'Engineer'\n\n"
                        "# Configure in pyproject.toml:\n"
                        "[tool.black]\n"
                        "line-length = 100\n"
                        "skip-string-normalization = false  # Force double quotes"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/code-consistency",
                    files_affected=style_issues.get("affected_files", [])[:5],
                ),
            )
        return recs

    def _recommend_crypto_hardening(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        crypto_issues = self._check_weak_crypto()
        if crypto_issues and crypto_issues.get("total_occurrences", 0) > 0:
            total = crypto_issues.get("total_occurrences", 0)
            weak_algos = crypto_issues.get("weak_algorithms", [])
            algo_list = ", ".join([f"{a['algorithm']} ({a['count']}x)" for a in weak_algos[:3]])

            recs.append(
                Recommendation(
                    category="security",
                    id="weak-crypto-algorithms",
                    priority="medium",
                    summary=(
                        f"{total} usage(s) of weak cryptographic algorithms detected. "
                        f"Found: {algo_list}"
                    ),
                    proposed_fix=(
                        "Replace weak algorithms with modern alternatives: "
                        "Use SHA-256/SHA-512 for hashing, AES-256-GCM for encryption."
                    ),
                    confidence=0.95,
                    effort_minutes=45,
                    impact_score=8,
                    code_example=(
                        "# ❌ BAD: Weak algorithms\n"
                        "import hashlib\n"
                        "# Split vulnerable calls to avoid self-flagging during pattern scans\n"
                        "hash_md5 = hashlib.md"
                        "5(data).hexdigest()  # Vulnerable!\n"
                        "hash_sha1 = hashlib.sha"
                        "1(data).hexdigest()  # Deprecated!\n\n"
                        "from Crypto.Cipher import DES\n"
                        "cipher = DES.new(key, DES.MODE_ECB)  # Insecure!\n\n"
                        "# ✅ GOOD: Modern algorithms\n"
                        "import hashlib\n"
                        "# For hashing (non-cryptographic: fast)\n"
                        "hash_blake2 = hashlib.blake2b(data).hexdigest()\n\n"
                        "# For cryptographic hashing\n"
                        "hash_sha256 = hashlib.sha256(data).hexdigest()\n"
                        "hash_sha512 = hashlib.sha512(data).hexdigest()\n\n"
                        "# For encryption\n"
                        "from cryptography.hazmat.primitives.ciphers.aead import AESGCM\n"
                        "aesgcm = AESGCM(key)  # key must be 32 bytes\n"
                        "ciphertext = aesgcm.encrypt(nonce, plaintext, associated_data)"
                    ),
                    guide_url="https://www.ready-4-it.com/mgpy/guides/modern-cryptography",
                    files_affected=crypto_issues.get("affected_files", [])[:5],
                ),
            )
        return recs
