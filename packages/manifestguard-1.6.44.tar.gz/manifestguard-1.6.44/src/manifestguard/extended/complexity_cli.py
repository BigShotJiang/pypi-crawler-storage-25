from __future__ import annotations

import argparse
import sys
from collections.abc import Iterable
from pathlib import Path

from .complexity_analyzer import ComplexityAnalyzer
from .complexity_models import ComplexityMetrics
from .complexity_serialization import serialize_complexity_metrics, write_metrics_file


def _build_arg_parser() -> argparse.ArgumentParser:
    """Build CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="ManifestGuard cyclomatic complexity analysis",
    )
    parser.add_argument(
        "--path",
        default=".",
        help="Workspace root to scan (defaults to current directory)",
    )
    parser.add_argument(
        "--threshold",
        type=int,
        default=10,
        help="Complexity threshold for violations (default: 10)",
    )
    parser.add_argument(
        "--include-tests",
        action="store_true",
        help="Include files under tests/ in the analysis",
    )
    parser.add_argument(
        "--min-rank",
        default="A",
        choices=["A", "B", "C", "D", "E", "F"],
        help="Minimum complexity rank to include in violations (A-F, default: A)",
    )
    parser.add_argument(
        "--engine",
        default="mgpy-analyzer",
        choices=["mgpy-analyzer", "radon"],
        help="Complexity engine to use (default: mgpy-analyzer)",
    )
    parser.add_argument(
        "--max-file-lines",
        type=int,
        default=None,
        help=(
            "Optional max file length (physical lines). When set and exceeded, the file is reported "
            "as an oversized-file maintainability hotspot. (default: disabled)"
        ),
    )
    parser.add_argument(
        "--output",
        default=str(Path(".manifestguard") / "metrics.json"),
        help="Relative or absolute path to metrics JSON output",
    )
    parser.add_argument(
        "--fail-on-violation",
        action="store_true",
        help="Exit with non-zero status when violations are found",
    )
    return parser


def _resolve_output_path(workspace_root: Path, potential_path: str) -> Path:
    """Resolve metrics output path relative to the workspace."""
    raw_path = Path(potential_path)
    return raw_path if raw_path.is_absolute() else workspace_root / raw_path


def _print_console_summary(
    metrics: ComplexityMetrics,
    recommendations: Iterable[str],
    output_path: Path,
) -> None:
    """Emit a short actionable summary to stdout for CLI usage."""
    divider = "=" * 60
    print(divider)
    print(
        f"Complexity Analysis • threshold {metrics.threshold} • "
        f"files scanned {metrics.files_scanned}",
    )
    print(
        f"Violations: {metrics.violations_count} | "
        f"Average: {metrics.average_complexity:.2f} | Max: {metrics.max_complexity}",
    )
    if metrics.oversized_files_count:
        top = sorted(metrics.oversized_files, key=lambda x: x.line_count, reverse=True)[:3]
        top_str = ", ".join(f"{o.file_path} ({o.line_count} lines)" for o in top)
        print(
            f"Oversized files: {metrics.oversized_files_count} "
            f"(threshold: {metrics.max_file_lines_threshold}) | Top: {top_str}",
        )
    if metrics.violations:
        top = sorted(metrics.violations, key=lambda v: v.complexity, reverse=True)[:3]
        print("Top offenders:")
        for idx, violation in enumerate(top, start=1):
            print(
                f"  {idx}. {violation.function_name} "
                f"({violation.file_path}:{violation.line_number}) -> "
                f"{violation.complexity}",
            )
    else:
        print("No functions exceed the configured threshold ✅")

    for note in recommendations:
        print(f"- {note}")

    print(f"Metrics written to: {output_path}")
    print(divider)


def run_cli(argv: Iterable[str] | None = None) -> int:
    """Entry-point for running the complexity analyzer as a CLI."""
    parser = _build_arg_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    workspace_root = Path(args.path).expanduser().resolve()
    if not workspace_root.exists():
        parser.error(f"Workspace path does not exist: {workspace_root}")

    analyzer = ComplexityAnalyzer(workspace_root)
    metrics = analyzer.analyze(
        threshold=args.threshold,
        include_tests=args.include_tests,
        min_rank=args.min_rank,
        engine=args.engine,
        max_file_lines=args.max_file_lines,
    )
    recommendations = analyzer.get_recommendations(metrics)

    payload = serialize_complexity_metrics(metrics, recommendations)
    output_path = _resolve_output_path(workspace_root, args.output)
    write_metrics_file(payload, output_path)
    _print_console_summary(metrics, recommendations, output_path)

    has_violations = metrics.violations_count > 0
    if args.fail_on_violation and has_violations:
        return 1
    return 0


def _main() -> None:
    sys.exit(run_cli())
