"""Cyclomatic Complexity Analysis Module

This module provides McCabe cyclomatic complexity analysis for Python code.

Implementation is split across submodules to keep file sizes below the LOC
maintainability threshold, while preserving the public import path:
`manifestguard.extended.complexity`.
"""

from __future__ import annotations

from .complexity_analyzer import ComplexityAnalyzer
from .complexity_cli import run_cli
from .complexity_models import (
    ComplexityMetrics,
    ComplexityViolation,
    OversizedFile,
    ToolConfigStatus,
)
from .complexity_serialization import serialize_complexity_metrics, write_metrics_file

__all__ = [
    "ComplexityAnalyzer",
    "ComplexityMetrics",
    "ComplexityViolation",
    "OversizedFile",
    "ToolConfigStatus",
    "serialize_complexity_metrics",
    "write_metrics_file",
    "run_cli",
]


if __name__ == "__main__":
    import sys

    sys.exit(run_cli())
