"""Detect hardcoded CLI strings in Python sources.

This scanner targets user-facing strings that appear in CLI contexts:
- click.echo / click.secho
- click.prompt / click.confirm
- click.option(help="...")
- click.command(help="..."), click.group(...)
- print("...") (best-effort)

It is intentionally heuristic (regex-based) to stay fast and avoid AST parsing.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from manifestguard.validation.inline_markers import is_line_suppressed

from .filesystem_safety import safe_read_file, safe_rglob
from .hardcoded_strings_common import (
    STRING_LITERAL_RE,
    coerce_bool,
    coerce_nonneg_int,
    coerce_str_list,
    filter_paths_by_include_exclude,
    get_first_dict_block,
    is_comment_line,
    load_manifestguard_json_dict,
    relpath_for_report,
    should_consider_string,
    slugify_for_i18n_key,
    update_triple_quote_state,
)
from .scan_utils import load_ignore_patterns, should_skip_path


I18N_HARDCODED_CLI_STRING_CODE = "I18N-HARDCODED-CLI-STRING"


@dataclass
class HardcodedCliStringsResult:
    scanned_files: int = 0
    total_findings: int = 0
    unique_strings: int = 0
    findings: list[dict[str, object]] = field(default_factory=list)


@dataclass(frozen=True)
class HardcodedCliStringsConfig:
    enabled: bool = True
    include: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)
    max_findings: int = 0  # 0 = unlimited


def _slugify_for_i18n_key(value: str) -> str | None:
    return slugify_for_i18n_key("cli", value)


def _is_suppressed(path: Path, line: int) -> bool:
    return is_line_suppressed(path, line, "I18N") or is_line_suppressed(
        path, line, I18N_HARDCODED_CLI_STRING_CODE
    )


def load_hardcoded_cli_strings_config_from_manifestguard_json(
    workspace_root: Path,
) -> HardcodedCliStringsConfig:
    """Load hardcoded CLI strings scan config from manifestguard.json.

    Supported shapes (best-effort):

    - {"checks": {"i18nHardcodedCliStrings": {"enabled": true, ...}}}
    - {"i18nHardcodedCliStrings": {...}}
    - {"i18n": {"hardcodedCliStrings": {...}}}
    - {"settings": {"i18nHardcodedCliStrings": {...}}}

    Accepted keys:
    - enabled: bool
    - include: list[str] (glob patterns against workspace-relative paths)
    - exclude: list[str]
    - maxFindings: int
    """

    raw = load_manifestguard_json_dict(workspace_root)
    if raw is None:
        return HardcodedCliStringsConfig()

    block = get_first_dict_block(
        raw,
        [
            ("checks", "i18nHardcodedCliStrings"),
            ("i18nHardcodedCliStrings",),
            ("i18n", "hardcodedCliStrings"),
            ("settings", "i18nHardcodedCliStrings"),
        ],
    )
    if block is None:
        return HardcodedCliStringsConfig()

    enabled = coerce_bool(block.get("enabled"), True)
    include = coerce_str_list(block.get("include"))
    exclude = coerce_str_list(block.get("exclude"))
    max_findings = coerce_nonneg_int(block.get("maxFindings"), 0)

    return HardcodedCliStringsConfig(enabled=enabled, include=include, exclude=exclude, max_findings=max_findings)


def _iter_cli_python_files(
    workspace_root: Path,
    config: HardcodedCliStringsConfig,
) -> list[Path]:
    ignore = load_ignore_patterns(workspace_root)

    roots: list[Path] = []
    src = workspace_root / "src"
    if src.exists() and src.is_dir():
        roots.append(src)

    # Fallback for single-file scripts or non-src layouts.
    if not roots:
        roots.append(workspace_root)

    files: list[Path] = []
    for root in roots:
        for py_file in safe_rglob(root, "*.py", max_files=25000):
            if should_skip_path(py_file, ignore, workspace_root):
                continue

            rel = relpath_for_report(workspace_root, py_file).lower()
            # Don't double-report GUI strings here.
            if rel.startswith("src/gui/") or rel.startswith("gui/"):
                continue

            files.append(py_file)

    # Deterministic ordering for stable reports/tests.
    files.sort(key=lambda p: relpath_for_report(workspace_root, p).lower())

    return filter_paths_by_include_exclude(
        workspace_root,
        files,
        include=config.include,
        exclude=config.exclude,
    )


_CLI_DIRECT_CALL_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("click.echo", re.compile(r"\bclick\.echo\(\s*['\"]")),
    ("click.secho", re.compile(r"\bclick\.secho\(\s*['\"]")),
    ("click.prompt", re.compile(r"\bclick\.prompt\(\s*['\"]")),
    ("click.confirm", re.compile(r"\bclick\.confirm\(\s*['\"]")),
    ("click.edit", re.compile(r"\bclick\.edit\(\s*['\"]")),
    ("click.pause", re.compile(r"\bclick\.pause\(\s*['\"]")),
    ("print", re.compile(r"\bprint\(\s*['\"]")),
]


def _append_finding(
    *,
    findings: list[dict[str, object]],
    unique: set[str],
    raw: str,
    kind: str,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
) -> None:
    unique.add(raw)
    suggested = _slugify_for_i18n_key(raw)
    findings.append(
        {
            "code": I18N_HARDCODED_CLI_STRING_CODE,
            "file": relpath_for_report(workspace_root, py_file),
            "line": line_no,
            "kind": kind,
            "value": raw,
            "suggestedKey": suggested,
            "suggestedReplacement": (
                f't("{suggested}", module="cli")' if suggested else None
            ),
        }
    )


def _scan_click_decorator_help(
    *,
    line: str,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    findings: list[dict[str, object]],
    unique: set[str],
    cfg: HardcodedCliStringsConfig,
) -> None:
    if "click.command" not in line and "click.group" not in line:
        return

    for arg_name in ("help", "short_help"):
        raw = _extract_named_arg_literal(line, arg_name)
        if not raw or not should_consider_string(raw):
            continue
        _append_finding(
            findings=findings,
            unique=unique,
            raw=raw,
            kind=f"click.{arg_name}",
            workspace_root=workspace_root,
            py_file=py_file,
            line_no=line_no,
        )
        if cfg.max_findings and len(findings) >= cfg.max_findings:
            return


def _scan_click_option_help_prompt(
    *,
    line: str,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    findings: list[dict[str, object]],
    unique: set[str],
    cfg: HardcodedCliStringsConfig,
) -> None:
    if "click.option" not in line:
        return

    for arg_name in ("help", "prompt"):
        raw = _extract_named_arg_literal(line, arg_name)
        if not raw or not should_consider_string(raw):
            continue
        _append_finding(
            findings=findings,
            unique=unique,
            raw=raw,
            kind=f"click.option.{arg_name}",
            workspace_root=workspace_root,
            py_file=py_file,
            line_no=line_no,
        )
        if cfg.max_findings and len(findings) >= cfg.max_findings:
            return


def _scan_direct_calls(
    *,
    line: str,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    findings: list[dict[str, object]],
    unique: set[str],
    cfg: HardcodedCliStringsConfig,
) -> None:
    for kind, rx in _CLI_DIRECT_CALL_PATTERNS:
        if not rx.search(line):
            continue

        m = STRING_LITERAL_RE.search(line)
        if not m:
            continue

        raw = m.group("text")
        if not should_consider_string(raw):
            continue

        _append_finding(
            findings=findings,
            unique=unique,
            raw=raw,
            kind=kind,
            workspace_root=workspace_root,
            py_file=py_file,
            line_no=line_no,
        )
        return


def _extract_named_arg_literal(line: str, arg_name: str) -> str | None:
    """Extract first string literal after a named argument, best-effort."""

    idx = line.find(arg_name)
    if idx < 0:
        return None

    segment = line[idx:]
    m = re.search(rf"\b{re.escape(arg_name)}\s*=\s*['\"]", segment)
    if not m:
        return None

    # From the 'help="' onwards, extract the first literal.
    sub = segment[m.start() :]
    lit = STRING_LITERAL_RE.search(sub)
    if not lit:
        return None

    return lit.group("text")


def _limit_reached(cfg: HardcodedCliStringsConfig, findings: list[dict[str, object]]) -> bool:
    return bool(cfg.max_findings and len(findings) >= cfg.max_findings)


def _scan_cli_line(
    *,
    line: str,
    workspace_root: Path,
    py_file: Path,
    line_no: int,
    findings: list[dict[str, object]],
    unique: set[str],
    cfg: HardcodedCliStringsConfig,
) -> bool:
    """Scan a single line and return True if scanning should stop due to limits."""

    _scan_click_decorator_help(
        line=line,
        workspace_root=workspace_root,
        py_file=py_file,
        line_no=line_no,
        findings=findings,
        unique=unique,
        cfg=cfg,
    )
    if _limit_reached(cfg, findings):
        return True

    _scan_click_option_help_prompt(
        line=line,
        workspace_root=workspace_root,
        py_file=py_file,
        line_no=line_no,
        findings=findings,
        unique=unique,
        cfg=cfg,
    )
    if _limit_reached(cfg, findings):
        return True

    _scan_direct_calls(
        line=line,
        workspace_root=workspace_root,
        py_file=py_file,
        line_no=line_no,
        findings=findings,
        unique=unique,
        cfg=cfg,
    )

    return _limit_reached(cfg, findings)


def scan_hardcoded_cli_strings(
    workspace_root: Path,
    config: HardcodedCliStringsConfig | None = None,
) -> HardcodedCliStringsResult:
    """Scan python sources for hardcoded user-facing CLI strings."""

    cfg = config or load_hardcoded_cli_strings_config_from_manifestguard_json(workspace_root)

    result = HardcodedCliStringsResult()
    findings: list[dict[str, object]] = []
    unique: set[str] = set()

    if not cfg.enabled:
        return result

    files = _iter_cli_python_files(workspace_root, cfg)
    result.scanned_files = len(files)

    for py_file in files:
        content = safe_read_file(py_file, max_bytes=10 * 1024 * 1024)
        if not content:
            continue

        in_triple: str | None = None

        for line_no, line in enumerate(content.splitlines(), start=1):
            in_triple = update_triple_quote_state(line, in_triple)
            if in_triple or is_comment_line(line) or _is_suppressed(py_file, line_no):
                continue

            if _scan_cli_line(
                line=line,
                workspace_root=workspace_root,
                py_file=py_file,
                line_no=line_no,
                findings=findings,
                unique=unique,
                cfg=cfg,
            ):
                break

        if _limit_reached(cfg, findings):
            break

    result.total_findings = len(findings)
    result.unique_strings = len(unique)
    result.findings = findings
    return result
