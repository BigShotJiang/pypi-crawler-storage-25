"""Policy enforcement collection used by extended metrics."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .metrics import PolicyMetrics

logger = logging.getLogger(__name__)


def _apply_hardcoded_strings_scan(
    metrics: PolicyMetrics,
    workspace_root: Path,
    *,
    kind: str,
) -> None:
    """Run a hardcoded-string scan and write results onto *metrics* (best-effort).

    Args:
        metrics: The :class:`PolicyMetrics` object to update in place.
        workspace_root: Project root directory.
        kind: Either ``"gui"`` or ``"cli"`` — selects the appropriate scanner module.
    """
    if kind == "gui":
        from .hardcoded_gui_strings import (  # noqa: PLC0415 - avoid circular import
            load_hardcoded_gui_strings_config_from_manifestguard_json as load_cfg,
            scan_hardcoded_gui_strings as scan,
        )
    else:
        from .hardcoded_cli_strings import (  # noqa: PLC0415 - avoid circular import
            load_hardcoded_cli_strings_config_from_manifestguard_json as load_cfg,
            scan_hardcoded_cli_strings as scan,
        )

    cfg = load_cfg(workspace_root)
    if not cfg.enabled:
        return

    result = scan(workspace_root, cfg)
    max_details = 200
    sample: list[Any] = list(result.findings[:max_details])

    if kind == "gui":
        metrics.gui_hardcoded_strings_total_findings = result.total_findings
        metrics.gui_hardcoded_strings_unique_strings = result.unique_strings
        metrics.gui_hardcoded_strings_scanned_files = result.scanned_files
        metrics.gui_hardcoded_strings_findings_sample = sample
    else:
        metrics.cli_hardcoded_strings_total_findings = result.total_findings
        metrics.cli_hardcoded_strings_unique_strings = result.unique_strings
        metrics.cli_hardcoded_strings_scanned_files = result.scanned_files
        metrics.cli_hardcoded_strings_findings_sample = sample


def _collect_policy_metrics_sync(workspace_root: Path) -> PolicyMetrics:
    """Collect policy enforcement status (best-effort)."""
    from .metrics import PolicyMetrics  # noqa: PLC0415 - avoid circular import

    metrics = PolicyMetrics()

    try:
        from .dummy_recognition import (  # noqa: PLC0415 - avoid circular import
            load_dummy_recognition_suppressions_from_manifestguard_json,
            run_dummy_recognition,
        )

        src_dir = workspace_root / "src"
        if src_dir.exists():
            suppressions = load_dummy_recognition_suppressions_from_manifestguard_json(
                workspace_root
            )

            result = run_dummy_recognition(
                [src_dir],
                include_tests=False,
                suppressions=suppressions,
                workspace_root=workspace_root,
            )
            metrics.dummy_code_total_findings = len(result.findings)
            metrics.dummy_code_scanned_files = result.stats.get("scannedFiles", 0)
            metrics.dummy_code_marker_findings = result.stats.get("markerFindings", 0)
            metrics.dummy_code_constant_return_findings = result.stats.get(
                "constantReturnFindings", 0
            )
            metrics.dummy_code_no_op_findings = result.stats.get("noOpFindings", 0)
            metrics.dummy_code_test_artifact_findings = result.stats.get("testArtifactFindings", 0)

            # Cap sample at 50 to avoid bloating JSON; convert findings to dict
            metrics.dummy_code_findings_sample = [
                {
                    "code": f.code,
                    "severity": f.severity,
                    "message": f.message,
                    "file": f.file,
                    "line": f.line,
                    "column": f.column,
                    "symbol": f.symbol,
                }
                for f in result.findings[:50]
            ]

            # Store real finding details for report drill-down.
            # Keep payload bounded: include all when small, else cap.
            max_details = 200
            findings = result.findings
            if len(findings) > max_details:
                findings = findings[:max_details]

            metrics.dummy_code_findings_sample = [
                {
                    "code": f.code,
                    "severity": f.severity,
                    "confidence": f.confidence,
                    "message": f.message,
                    "file": f.file,
                    "line": f.line,
                    "column": f.column,
                    "symbol": f.symbol,
                    "remediation": f.remediation,
                }
                for f in findings
            ]

    except Exception as exc:
        logger.debug("Policy metrics (dummy recognition) failed: %s", exc)

    try:
        from manifestguard.core.ignore_patterns import IgnorePatterns  # noqa: PLC0415 - avoid circular import

        from .duplication import (  # noqa: PLC0415 - avoid circular import
            load_duplication_detection_config_from_manifestguard_json,
            run_duplication_detection,
        )

        dup_cfg = load_duplication_detection_config_from_manifestguard_json(workspace_root)
        if dup_cfg.enabled:
            ignore = IgnorePatterns(workspace_root)
            ignore.load()
            metrics.duplication = run_duplication_detection(
                workspace_root,
                config=dup_cfg,
                ignore=ignore,
            )
        else:
            metrics.duplication = {"enabled": False}

    except Exception as exc:
        logger.debug("Policy metrics (duplication) failed: %s", exc)

    try:
        _apply_hardcoded_strings_scan(metrics, workspace_root, kind="gui")
    except Exception as exc:
        logger.debug("Policy metrics (hardcoded gui strings) failed: %s", exc)

    try:
        _apply_hardcoded_strings_scan(metrics, workspace_root, kind="cli")
    except Exception as exc:
        logger.debug("Policy metrics (hardcoded cli strings) failed: %s", exc)

    return metrics


async def collect_policy_metrics(workspace_root: Path) -> PolicyMetrics:
    """Collect policy enforcement status (best-effort)."""
    return await asyncio.to_thread(_collect_policy_metrics_sync, workspace_root)
