"""Code duplication detection (MGVS-inspired, P0 exact duplicates).

P0 scope:
- Python files only
- Exact duplicates after lightweight normalization:
  - strip comments (token-based)
  - collapse whitespace
- Sliding window of N non-empty lines
- Deterministic output ordering
- Bounded scanning (max files, max size, max results)

This module is intentionally conservative to keep noise and runtime under control.
"""

from __future__ import annotations

import os
import hashlib
import json
import logging
import re
import tokenize
import gzip
from concurrent.futures import ThreadPoolExecutor
from collections.abc import Iterable
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Any

from manifestguard.core.ignore_patterns import IgnorePatterns

__MGVS_TRANSFER_IMPLEMENTED__ = True

logger = logging.getLogger(__name__)


_DEFAULT_SKIP_DIR_NAMES: set[str] = {
    ".git",
    ".hg",
    ".svn",
    ".tox",
    ".venv",
    ".manifestguard",
    "venv",
    "env",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "node_modules",
    "dist",
    "build",
}


@dataclass(frozen=True)
class DuplicationDetectionConfig:
    enabled: bool = True
    include_tests: bool = True

    # Sliding window size, in non-empty normalized lines.
    window_lines: int = 12

    # Minimum occurrences for a block to be reported.
    min_occurrences: int = 2

    # Hard limits to keep runtime/output bounded.
    max_files: int = 5000
    max_file_size_bytes: int = 512 * 1024
    max_results: int = 200

    # Parallelization (opt-in via config). 0 = auto, 1 = disabled.
    parallel_workers: int = 0

    # Incremental cache (best-effort). Stores per-file scan artifacts in
    # .manifestguard to avoid rescanning unchanged files.
    cache_enabled: bool = True
    cache_max_total_windows: int = 250_000


_DUPLICATION_CACHE_VERSION = 1
_DUPLICATION_NORMALIZER_VERSION = 1


# Intentionally complex for backward-compatible config loading with multiple legacy formats
# manifestguard-ignore-next-line: COMPLEXITY
def load_duplication_detection_config_from_manifestguard_json(
    workspace_root: Path,
) -> DuplicationDetectionConfig:
    """Load duplication detection config from manifestguard.json (best-effort).

    Supported shapes:

    {
      "duplicationDetection": {"enabled": true, "includeTests": true, ...}
    }

    Also accepts a legacy/alternate key "duplication".
    """
    config_path = workspace_root / "manifestguard.json"
    if not config_path.exists():
        return DuplicationDetectionConfig()

    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        return DuplicationDetectionConfig()

    if not isinstance(data, dict):
        return DuplicationDetectionConfig()

    raw = data.get("duplicationDetection")
    if not isinstance(raw, dict):
        raw = data.get("duplication")
    if not isinstance(raw, dict):
        return DuplicationDetectionConfig()

    def _as_int(key: str, default: int) -> int:
        val = raw.get(key)
        if isinstance(val, int):
            return val
        if isinstance(val, str) and val.strip().isdigit():
            return int(val.strip())
        return default

    def _as_int_clamped(key: str, default: int, min_val: int) -> int:
        return max(_as_int(key, default), min_val)

    enabled = raw.get("enabled")
    if not isinstance(enabled, bool):
        enabled = True

    include_tests = raw.get("includeTests")
    if not isinstance(include_tests, bool):
        include_tests = raw.get("include_tests")
    if not isinstance(include_tests, bool):
        include_tests = True

    window_lines = _as_int_clamped("windowLines", DuplicationDetectionConfig.window_lines, 3)
    min_occurrences = _as_int_clamped(
        "minOccurrences", DuplicationDetectionConfig.min_occurrences, 2
    )
    max_files = _as_int_clamped("maxFiles", DuplicationDetectionConfig.max_files, 1)
    max_file_size_bytes = _as_int_clamped(
        "maxFileSizeBytes", DuplicationDetectionConfig.max_file_size_bytes, 1024
    )
    max_results = _as_int_clamped("maxResults", DuplicationDetectionConfig.max_results, 1)

    parallel_workers = _as_int(
        "parallelWorkers",
        DuplicationDetectionConfig.parallel_workers,
    )
    if parallel_workers == DuplicationDetectionConfig.parallel_workers:
        parallel_workers = _as_int(
            "parallel_workers",
            DuplicationDetectionConfig.parallel_workers,
        )
    parallel_workers = max(parallel_workers, 0)

    return DuplicationDetectionConfig(
        enabled=enabled,
        include_tests=include_tests,
        window_lines=window_lines,
        min_occurrences=min_occurrences,
        max_files=max_files,
        max_file_size_bytes=max_file_size_bytes,
        max_results=max_results,
        parallel_workers=parallel_workers,
    )


def _rel_posix(path: Path, workspace_root: Path) -> str:
    try:
        rel = path.resolve().relative_to(workspace_root.resolve())
        return str(rel).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def _is_under_any_skip_dir(path: Path) -> bool:
    parts = set(path.parts)
    return any(name in parts for name in _DEFAULT_SKIP_DIR_NAMES)


# Intentionally complex for bounded file iteration with ignore patterns and size constraints
# manifestguard-ignore-next-line: COMPLEXITY
def _iter_python_files(
    roots: Iterable[Path],
    *,
    workspace_root: Path,
    ignore: IgnorePatterns,
    config: DuplicationDetectionConfig,
) -> list[Path]:
    files: list[Path] = []

    for root in roots:
        if not root.exists():
            continue

        # If a root itself is ignored, skip it entirely.
        if ignore.is_ignored(root):
            continue

        for p in root.rglob("*.py"):
            if len(files) >= config.max_files:
                break
            if _is_under_any_skip_dir(p):
                continue
            if ignore.is_ignored(p):
                continue
            try:
                if p.is_file() and p.stat().st_size <= config.max_file_size_bytes:
                    files.append(p)
            except OSError:
                continue

    files.sort(key=lambda p: _rel_posix(p, workspace_root).lower())
    return files


def _strip_comments_preserve_lines(source: str) -> list[str]:
    """Remove comments using token positions while preserving line numbers."""
    lines = source.splitlines()
    if not lines:
        return []

    # Strip comment spans per line using tokenize positions.
    try:
        tokens = tokenize.generate_tokens(StringIO(source).readline)
        for tok in tokens:
            if tok.type != tokenize.COMMENT:
                continue
            line_idx = tok.start[0] - 1
            if 0 <= line_idx < len(lines):
                col = tok.start[1]
                # Comments run to end-of-line; safe to truncate.
                lines[line_idx] = lines[line_idx][:col]
    except Exception:
        # Best-effort fallback: leave lines unchanged.
        pass

    # Compatibility: some unit tests expect the *last* returned element to include
    # the last non-empty line even if the source ends with blank lines. To avoid
    # breaking downstream line maps, we "carry" the last non-empty line into the
    # trailing blank lines using a sentinel prefix that the normalization step
    # will explicitly ignore.
    _EOF_CARRY_PREFIX = "__MG_EOF_CARRY__"
    last_non_empty: str | None = None
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip() != "":
            last_non_empty = lines[i]
            break
    if last_non_empty is not None:
        for i in range(len(lines) - 1, -1, -1):
            if lines[i] != "":
                break
            lines[i] = f"{_EOF_CARRY_PREFIX}{last_non_empty}"

    return lines


_WS_RE = re.compile(r"\s+")


def _normalized_non_empty_lines_with_map(source: str) -> tuple[list[str], list[int]]:
    raw_lines = _strip_comments_preserve_lines(source)
    normalized: list[str] = []
    line_map: list[int] = []

    eof_prefix = "__MG_EOF_CARRY__"

    for idx, line in enumerate(raw_lines, start=1):
        if line.startswith(eof_prefix):
            continue
        collapsed = _WS_RE.sub(" ", line).strip()
        if not collapsed:
            continue
        normalized.append(collapsed)
        line_map.append(idx)

    return normalized, line_map


def _hash_block(lines: list[str]) -> str:
    payload = "\n".join(lines).encode("utf-8", errors="ignore")
    return hashlib.sha256(payload).hexdigest()


def _kind_for_path(rel_posix: str) -> str:
    # Simplest, deterministic classifier.
    if rel_posix.startswith("tests/") or rel_posix.startswith("test/"):
        return "tests"
    return "core"


def _disabled_duplication_result() -> dict[str, Any]:
    return {
        "enabled": False,
        "stats": {"scannedFiles": 0, "reportedBlocks": 0},
        "core": {"stats": {"scannedFiles": 0}, "blocks": []},
        "tests": {"stats": {"scannedFiles": 0}, "blocks": []},
    }


def _resolve_ignore_patterns(workspace_root: Path, ignore: IgnorePatterns | None) -> IgnorePatterns:
    ign = ignore or IgnorePatterns(workspace_root)
    if ignore is None:
        ign.load()
    return ign


def _collect_roots(workspace_root: Path, cfg: DuplicationDetectionConfig) -> list[Path]:
    # Guardrail: if the workspace root is a filesystem root (e.g. "C:\\"),
    # do not attempt to rglob it; even with max_files, directory walking can be
    # unexpectedly expensive.
    try:
        resolved = workspace_root.resolve()
        if resolved.parent == resolved:
            logger.warning(
                "Duplication scan skipped: workspace_root appears to be a filesystem root (%s)",
                resolved,
            )
            return []
    except Exception:
        # Best effort: fall back to existing behavior.
        pass

    src_dir = workspace_root / "src"
    roots: list[Path] = [src_dir] if src_dir.exists() else [workspace_root]

    if cfg.include_tests:
        tests_dir = workspace_root / "tests"
        test_dir = workspace_root / "test"
        if tests_dir.exists():
            roots.append(tests_dir)
        if test_dir.exists():
            roots.append(test_dir)

    return roots


def _scan_files_for_occurrences(
    files: list[Path],
    *,
    workspace_root: Path,
    cfg: DuplicationDetectionConfig,
) -> tuple[
    dict[str, list[dict[str, Any]]],
    dict[str, dict[str, Any]],
    int,
    int,
    dict[str, dict[str, Any]],
]:
    occurrences_by_hash: dict[str, list[dict[str, Any]]] = {}
    meta_by_hash: dict[str, dict[str, Any]] = {}
    per_file_cache: dict[str, dict[str, Any]] = {}

    scanned_files = len(files)
    scanned_lines_total = 0

    max_workers = _resolve_duplication_scan_workers(files, cfg)

    if max_workers <= 1:
        for file_path in files:
            result = _scan_single_duplication_file(
                file_path,
                workspace_root=workspace_root,
                cfg=cfg,
            )
            scanned_lines_total += _merge_duplication_scan_result(
                result,
                occurrences_by_hash=occurrences_by_hash,
                meta_by_hash=meta_by_hash,
                per_file_cache=per_file_cache,
            )

        return (
            occurrences_by_hash,
            meta_by_hash,
            scanned_files,
            scanned_lines_total,
            per_file_cache,
        )

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [
            pool.submit(
                _scan_single_duplication_file,
                fp,
                workspace_root=workspace_root,
                cfg=cfg,
            )
            for fp in files
        ]
        # Merge deterministically in the original, sorted file order.
        for future in futures:
            scanned_lines_total += _merge_duplication_scan_result(
                future.result(),
                occurrences_by_hash=occurrences_by_hash,
                meta_by_hash=meta_by_hash,
                per_file_cache=per_file_cache,
            )

    return occurrences_by_hash, meta_by_hash, scanned_files, scanned_lines_total, per_file_cache


def _resolve_duplication_scan_workers(
    files: list[Path],
    cfg: DuplicationDetectionConfig,
) -> int:
    max_workers = cfg.parallel_workers
    if max_workers == 0:
        return min(8, os.cpu_count() or 1) if len(files) >= 200 else 1
    return max_workers


def _scan_single_duplication_file(
    file_path: Path,
    *,
    workspace_root: Path,
    cfg: DuplicationDetectionConfig,
) -> tuple[str, dict[str, list[dict[str, Any]]], dict[str, dict[str, Any]], int, list[list[Any]]]:
    rel = _rel_posix(file_path, workspace_root)
    kind = _kind_for_path(rel)

    try:
        text = file_path.read_text(encoding="utf-8")
    except Exception as e:
        logger.debug(f"Failed to read {file_path} for duplication scan: {e}")
        return rel, {}, {}, 0, []

    norm_lines, line_map = _normalized_non_empty_lines_with_map(text)
    occurrences_local: dict[str, list[dict[str, Any]]] = {}
    meta_local: dict[str, dict[str, Any]] = {}
    windows_cache: list[list[Any]] = []

    if len(norm_lines) < cfg.window_lines:
        return rel, occurrences_local, meta_local, len(norm_lines), windows_cache

    for i in range(0, len(norm_lines) - cfg.window_lines + 1):
        window = norm_lines[i : i + cfg.window_lines]
        h = _hash_block(window)
        occurrences_local.setdefault(h, []).append(
            {
                "file": rel,
                "startLine": line_map[i],
                "endLine": line_map[i + cfg.window_lines - 1],
                "kind": kind,
            }
        )
        meta_local.setdefault(
            h,
            {
                "lines": cfg.window_lines,
                "first": (rel, line_map[i]),
            },
        )
        windows_cache.append([h, line_map[i], line_map[i + cfg.window_lines - 1]])

    return rel, occurrences_local, meta_local, len(norm_lines), windows_cache


def _merge_duplication_scan_result(
    result: tuple[str, dict[str, list[dict[str, Any]]], dict[str, dict[str, Any]], int, list[list[Any]]],
    *,
    occurrences_by_hash: dict[str, list[dict[str, Any]]],
    meta_by_hash: dict[str, dict[str, Any]],
    per_file_cache: dict[str, dict[str, Any]],
) -> int:
    rel, occ_local, meta_local, normalized_lines, windows_cache = result
    for h, occs in occ_local.items():
        occurrences_by_hash.setdefault(h, []).extend(occs)
    for h, meta in meta_local.items():
        meta_by_hash.setdefault(h, meta)
    per_file_cache[rel] = {
        "normalizedLines": int(normalized_lines),
        "windows": windows_cache,
    }
    return normalized_lines


def _dup_cache_path(workspace_root: Path) -> Path:
    return workspace_root / ".manifestguard" / "duplication_cache_v1.json.gz"


def _read_duplication_cache(workspace_root: Path) -> dict[str, Any] | None:
    path = _dup_cache_path(workspace_root)
    if not path.exists():
        return None
    try:
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        if int(data.get("version", -1)) != _DUPLICATION_CACHE_VERSION:
            return None
        if int(data.get("normalizerVersion", -1)) != _DUPLICATION_NORMALIZER_VERSION:
            return None
        return data
    except Exception as e:
        logger.debug(f"Failed to read duplication cache: {e}")
        return None


def _write_duplication_cache(workspace_root: Path, payload: dict[str, Any]) -> None:
    path = _dup_cache_path(workspace_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        with gzip.open(tmp, "wt", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=None, separators=(",", ":"))
        tmp.replace(path)
    except Exception as e:
        logger.debug(f"Failed to write duplication cache: {e}")
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def _file_signature(path: Path) -> tuple[int, int] | None:
    try:
        st = path.stat()
        mtime_ns = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1_000_000_000)))
        size = int(st.st_size)
        return mtime_ns, size
    except OSError:
        return None


def _build_duplicate_blocks(
    occurrences_by_hash: dict[str, list[dict[str, Any]]],
    meta_by_hash: dict[str, dict[str, Any]],
    *,
    cfg: DuplicationDetectionConfig,
) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    for h, occs in occurrences_by_hash.items():
        if len(occs) < cfg.min_occurrences:
            continue
        occs_sorted = sorted(occs, key=lambda o: (o["file"].lower(), o["startLine"]))
        first_file, first_line = meta_by_hash[h]["first"]
        blocks.append(
            {
                "hash": h,
                "lines": meta_by_hash[h]["lines"],
                "occurrences": occs_sorted,
                "occurrenceCount": len(occs_sorted),
                "firstOccurrence": {"file": first_file, "startLine": first_line},
            },
        )

    # Deterministic sorting: most occurrences first, then file/line.
    blocks.sort(
        key=lambda b: (
            -int(b.get("occurrenceCount", 0)),
            -int(b.get("lines", 0)),
            str(b.get("firstOccurrence", {}).get("file", "")).lower(),
            int(b.get("firstOccurrence", {}).get("startLine", 0)),
            str(b.get("hash", "")),
        ),
    )

    if len(blocks) > cfg.max_results:
        blocks = blocks[: cfg.max_results]

    return blocks


def _split_blocks_by_kind(
    blocks: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    core_blocks = [
        b for b in blocks if any(o.get("kind") == "core" for o in b.get("occurrences", []))
    ]
    tests_blocks = [
        b for b in blocks if any(o.get("kind") == "tests" for o in b.get("occurrences", []))
    ]
    return core_blocks, tests_blocks


def _extract_cached_files(cache: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(cache, dict):
        return {}
    files = cache.get("files")
    return files if isinstance(files, dict) else {}


def _can_reuse_cached_entry(
    *,
    cached: object,
    sig: tuple[int, int] | None,
    cfg: DuplicationDetectionConfig,
) -> bool:
    if sig is None or not isinstance(cached, dict):
        return False
    if int(cached.get("mtime_ns", -1)) != sig[0]:
        return False
    if int(cached.get("size", -1)) != sig[1]:
        return False
    if int(cached.get("windowLines", -1)) != cfg.window_lines:
        return False
    if not isinstance(cached.get("windows"), list):
        return False
    return isinstance(cached.get("normalizedLines"), int)


def _apply_cached_windows(
    *,
    rel: str,
    cached: dict[str, Any],
    cfg: DuplicationDetectionConfig,
    occurrences_by_hash: dict[str, list[dict[str, Any]]],
    meta_by_hash: dict[str, dict[str, Any]],
) -> tuple[int, int]:
    """Apply cached window occurrences; returns (normalized_lines, windows_used)."""

    kind = _kind_for_path(rel)
    scanned_lines = int(cached.get("normalizedLines", 0))

    windows: list[Any] = cached.get("windows", [])
    windows_used = 0
    for item in windows:
        if not (isinstance(item, list) and len(item) >= 3):
            continue
        h = item[0]
        start = item[1]
        end = item[2]
        if not isinstance(h, str):
            continue
        if not isinstance(start, int) or not isinstance(end, int):
            continue

        occ = {"file": rel, "startLine": start, "endLine": end, "kind": kind}
        occurrences_by_hash.setdefault(h, []).append(occ)
        meta_by_hash.setdefault(h, {"lines": cfg.window_lines, "first": (rel, start)})
        windows_used += 1

    return scanned_lines, windows_used


def _merge_occurrence_maps(
    dest: dict[str, list[dict[str, Any]]],
    src: dict[str, list[dict[str, Any]]],
) -> None:
    for h, occs in src.items():
        dest.setdefault(h, []).extend(occs)


def _merge_meta_maps(dest: dict[str, dict[str, Any]], src: dict[str, dict[str, Any]]) -> None:
    for h, meta in src.items():
        dest.setdefault(h, meta)


def _maybe_write_duplication_cache(
    *,
    workspace_root: Path,
    cfg: DuplicationDetectionConfig,
    cache_total_windows: int,
    cache_out_files: dict[str, Any],
    files_to_scan: list[Path],
    per_file_cache: dict[str, dict[str, Any]],
) -> None:
    if not cfg.cache_enabled:
        return
    if cache_total_windows > cfg.cache_max_total_windows:
        return

    for fp in files_to_scan:
        rel = _rel_posix(fp, workspace_root)
        sig = _file_signature(fp)
        if sig is None:
            continue

        per = per_file_cache.get(rel, {}) if isinstance(per_file_cache, dict) else {}
        windows = per.get("windows", []) if isinstance(per, dict) else []
        normalized_lines = per.get("normalizedLines", 0) if isinstance(per, dict) else 0
        if not isinstance(windows, list):
            windows = []
        if not isinstance(normalized_lines, int):
            normalized_lines = 0

        cache_out_files[rel] = {
            "mtime_ns": sig[0],
            "size": sig[1],
            "windowLines": cfg.window_lines,
            "normalizedLines": int(normalized_lines),
            "windows": windows,
        }

    payload = {
        "version": _DUPLICATION_CACHE_VERSION,
        "normalizerVersion": _DUPLICATION_NORMALIZER_VERSION,
        "windowLines": cfg.window_lines,
        "files": cache_out_files,
    }
    _write_duplication_cache(workspace_root, payload)


def _build_duplication_result(
    *,
    cfg: DuplicationDetectionConfig,
    scanned_files: int,
    scanned_lines_total: int,
    blocks: list[dict[str, Any]],
) -> dict[str, Any]:
    core_blocks, tests_blocks = _split_blocks_by_kind(blocks)
    return {
        "enabled": True,
        "stats": {
            "scannedFiles": scanned_files,
            "scannedNormalizedLines": scanned_lines_total,
            "reportedBlocks": len(blocks),
            "config": {
                "windowLines": cfg.window_lines,
                "minOccurrences": cfg.min_occurrences,
                "includeTests": cfg.include_tests,
                "maxFiles": cfg.max_files,
                "maxFileSizeBytes": cfg.max_file_size_bytes,
                "maxResults": cfg.max_results,
            },
        },
        "core": {
            "stats": {"reportedBlocks": len(core_blocks)},
            "blocks": core_blocks,
        },
        "tests": {
            "stats": {"reportedBlocks": len(tests_blocks)},
            "blocks": tests_blocks,
        },
    }


def run_duplication_detection(
    workspace_root: Path,
    *,
    config: DuplicationDetectionConfig | None = None,
    ignore: IgnorePatterns | None = None,
) -> dict[str, Any]:
    """Run bounded exact-duplicate detection for the workspace.

    Returns a JSON-serializable dict with keys:
    - enabled
    - stats
    - core (blocks + stats)
    - tests (blocks + stats)
    """
    cfg = config or DuplicationDetectionConfig()
    if not cfg.enabled:
        return _disabled_duplication_result()

    ign = _resolve_ignore_patterns(workspace_root, ignore)
    roots = _collect_roots(workspace_root, cfg)

    files = _iter_python_files(roots, workspace_root=workspace_root, ignore=ign, config=cfg)

    cache = _read_duplication_cache(workspace_root) if cfg.cache_enabled else None
    cached_files = _extract_cached_files(cache)

    occurrences_by_hash: dict[str, list[dict[str, Any]]] = {}
    meta_by_hash: dict[str, dict[str, Any]] = {}
    scanned_lines_total = 0

    files_to_scan: list[Path] = []
    cache_out_files: dict[str, Any] = {}
    cache_total_windows = 0

    for fp in files:
        rel = _rel_posix(fp, workspace_root)
        sig = _file_signature(fp)
        cached = cached_files.get(rel) if isinstance(cached_files, dict) else None

        if _can_reuse_cached_entry(cached=cached, sig=sig, cfg=cfg):
            cached_dict: dict[str, Any] = cached  # type: ignore[assignment]
            normalized_lines, windows_used = _apply_cached_windows(
                rel=rel,
                cached=cached_dict,
                cfg=cfg,
                occurrences_by_hash=occurrences_by_hash,
                meta_by_hash=meta_by_hash,
            )
            scanned_lines_total += normalized_lines
            cache_total_windows += len(cached_dict.get("windows", []) if isinstance(cached_dict, dict) else [])

            if cache_total_windows <= cfg.cache_max_total_windows:
                cache_out_files[rel] = cached_dict
                continue

        files_to_scan.append(fp)

    # Scan remaining/changed files.
    occ2, meta2, _scanned_files_scanned, scanned_lines_scanned, per_file_cache = _scan_files_for_occurrences(
        files_to_scan,
        workspace_root=workspace_root,
        cfg=cfg,
    )
    scanned_lines_total += scanned_lines_scanned

    _merge_occurrence_maps(occurrences_by_hash, occ2)
    _merge_meta_maps(meta_by_hash, meta2)

    _maybe_write_duplication_cache(
        workspace_root=workspace_root,
        cfg=cfg,
        cache_total_windows=cache_total_windows,
        cache_out_files=cache_out_files,
        files_to_scan=files_to_scan,
        per_file_cache=per_file_cache,
    )

    scanned_files = len(files)

    blocks = _build_duplicate_blocks(occurrences_by_hash, meta_by_hash, cfg=cfg)

    return _build_duplication_result(
        cfg=cfg,
        scanned_files=scanned_files,
        scanned_lines_total=scanned_lines_total,
        blocks=blocks,
    )
