from __future__ import annotations

import json
from pathlib import Path

# Marker cache to avoid reloading JSON files on every scan
_MARKER_CACHE: dict[str, list[str]] = {}


def _load_markers(language: str) -> list[str]:
    """Load markers from JSON file for the specified language.

    Args:
        language: Language code (e.g., 'en', 'de', 'fr', 'es')

    Returns:
        List of marker strings for the language

    Raises:
        FileNotFoundError: If marker file does not exist
        ValueError: If JSON is malformed
    """
    if language in _MARKER_CACHE:
        return _MARKER_CACHE[language]

    markers_dir = Path(__file__).parent / "markers"
    marker_file = markers_dir / f"{language}.json"

    if not marker_file.exists():
        msg = f"Marker file not found: {marker_file}"
        raise FileNotFoundError(msg)

    try:
        with marker_file.open("r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict) or "markers" not in data:
            msg = f"Invalid marker file format: {marker_file}"
            raise ValueError(msg)

        markers = data["markers"]
        if not isinstance(markers, list):
            msg = f"Invalid markers format in {marker_file}"
            raise ValueError(msg)

        _MARKER_CACHE[language] = markers
        return markers

    except json.JSONDecodeError as e:
        msg = f"Invalid JSON in marker file {marker_file}: {e}"
        raise ValueError(msg) from e


# For backward compatibility, expose markers as module-level constants
# These will be loaded lazily on first access
def _get_en_markers() -> list[str]:
    return _load_markers("en")


def _get_de_markers() -> list[str]:
    return _load_markers("de")


def _get_fr_markers() -> list[str]:
    return _load_markers("fr")


def _get_es_markers() -> list[str]:
    return _load_markers("es")
