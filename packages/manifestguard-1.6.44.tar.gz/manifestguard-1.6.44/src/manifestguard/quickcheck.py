"""Quick Check - Simplified API for Python project validation

Simplified top-level interface for manifestguard.api.QuickCheck

Example:
    >>> import manifestguard.quickcheck as qc
    >>> info = qc.detect_project('.')
    >>> tests = qc.recommend_tests(info)
    >>> config = qc.generate_config(info, tests)

"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from manifestguard.api import (
    ConfigTemplate,
    ProjectInfo,
    ProjectType,
    RecommendationPriority,
    TestRecommendation,
    get_cache,
)
from manifestguard.api import (
    QuickCheck as _QuickCheck,
)
from manifestguard.core import VersionValidator as _VersionValidator


@dataclass
class _QuickCheckState:
    quick_check: _QuickCheck | None = None
    validator: _VersionValidator | None = None


_STATE = _QuickCheckState()


def _get_quick_check() -> _QuickCheck:
    """Get QuickCheck singleton"""
    if _STATE.quick_check is None:
        _STATE.quick_check = _QuickCheck()
    return _STATE.quick_check


def _get_validator(strict: bool = False) -> _VersionValidator:
    """Get VersionValidator singleton"""
    if strict:
        return _VersionValidator(strict=True)
    if _STATE.validator is None:
        _STATE.validator = _VersionValidator()
    return _STATE.validator


# Simplified API functions
def detect_project(path: str | Path = ".") -> ProjectInfo:
    """Detect project type and features

    Args:
        path: Project directory path (default: current directory)

    Returns:
        ProjectInfo with type, features, dependencies

    Example:
        >>> import manifestguard.quickcheck as qc
        >>> info = qc.detect_project('.')
        >>> print(info.project_type)
        ProjectType.PYPROJECT_TOML

    """
    qc = _get_quick_check()
    return qc.detect_project_type(path)


def recommend_tests(project_info: ProjectInfo) -> list[TestRecommendation]:
    """Get test recommendations for project

    Args:
        project_info: ProjectInfo from detect_project()

    Returns:
        List of test recommendations with priorities

    Example:
        >>> info = qc.detect_project('.')
        >>> tests = qc.recommend_tests(info)
        >>> for t in tests:
        ...     print(f"{t.name}: {t.priority}")

    """
    qc = _get_quick_check()
    return qc.recommend_tests(project_info)


def generate_config(
    project_info: ProjectInfo,
    recommendations: list[TestRecommendation],
) -> ConfigTemplate:
    """Generate manifestguard.json config template

    Args:
        project_info: ProjectInfo from detect_project()
        recommendations: Test recommendations from recommend_tests()

    Returns:
        ConfigTemplate ready to write as JSON

    Example:
        >>> info = qc.detect_project('.')
        >>> tests = qc.recommend_tests(info)
        >>> config = qc.generate_config(info, tests)

    """
    qc = _get_quick_check()
    return qc.generate_config_template(project_info, recommendations)


def merge_configs(
    existing: dict[str, Any],
    template: ConfigTemplate,
    preserve_user: bool = True,
) -> dict[str, Any]:
    """Merge existing config with new template

    Args:
        existing: Existing config dict
        template: New config template
        preserve_user: Keep user customizations

    Returns:
        Merged config dict

    """
    qc = _get_quick_check()
    return qc.merge_configs(existing, template, preserve_user)


def compare_configs(
    config_a: dict[str, Any],
    config_b: dict[str, Any],
) -> dict[str, Any]:
    """Compare two configurations

    Args:
        config_a: First config
        config_b: Second config

    Returns:
        Dict with 'added', 'removed', 'changed' keys

    """
    qc = _get_quick_check()
    return qc.compare_configs(config_a, config_b)


def validate_version(package_name: str, strict: bool = False) -> tuple[bool, str]:
    """Validate package version (x.y.z schema)

    Args:
        package_name: Package to validate
        strict: Require stable version (no prerelease/build)

    Returns:
        Tuple of (success, message)

    Example:
        >>> success, msg = qc.validate_version('manifestguard')
        >>> print(msg)
        Valid semantic version: 0.3.0

    """
    validator = _get_validator(strict=strict)
    success, _info, message = validator.validate_package(package_name)
    return success, message


def validate_project_version(path: str | Path = ".") -> tuple[bool, str]:
    """Validate version in pyproject.toml or setup.py

    Args:
        path: Project directory path

    Returns:
        Tuple of (success, message)

    """
    validator = _get_validator()
    success, _info, message = validator.validate_project(path)
    return success, message


# Export all public API
__all__ = [
    "ConfigTemplate",
    # Classes/Enums (for type hints)
    "ProjectInfo",
    "ProjectType",
    "RecommendationPriority",
    "TestRecommendation",
    "compare_configs",
    # Functions
    "detect_project",
    "generate_config",
    # Cache
    "get_cache",
    "merge_configs",
    "recommend_tests",
    "validate_project_version",
    "validate_version",
]
