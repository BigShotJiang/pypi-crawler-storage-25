"""
Invoke Tasks für ManifestGuard Development & Release
"""

import os
import shutil
import sys
import sysconfig
from pathlib import Path

from invoke import task


def _rewrite_pyarmor_runtime_import(path: Path) -> None:
    if path.suffix != ".py":
        return

    original = path.read_text(encoding="utf-8")
    rewritten = original.replace(
        "from pyarmor_runtime_000000 import __pyarmor__",
        "from manifestguard.pyarmor_runtime_000000 import __pyarmor__",
    )
    if rewritten != original:
        path.write_text(rewritten, encoding="utf-8")


def _copy_obfuscated_files() -> None:
    obf_src = Path("dist-obfuscated/manifestguard")
    target = Path("src/manifestguard")

    # PyArmor v8/v9 `gen` outputs obfuscated .py sources (plus runtime binaries).
    # Older pipelines sometimes emitted .pyo; support both.
    for ext in (".py", ".pyo", ".pyd", ".so", ".dll"):
        for obf_file in obf_src.rglob(f"*{ext}"):
            rel_path = obf_file.relative_to(obf_src)
            dest = target / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(obf_file, dest)
            _rewrite_pyarmor_runtime_import(dest)

    runtime_src = obf_src / "pyarmor_runtime_000000"
    if runtime_src.exists():
        runtime_dest = target / "pyarmor_runtime_000000"
        shutil.copytree(runtime_src, runtime_dest, dirs_exist_ok=True)


def _restore_source_tree(c) -> None:
    c.run("git restore src/", warn=True)


def _wheel_cp_tag() -> str:
    """Returns e.g. 'cp312' for Python 3.12."""
    vi = sys.version_info
    return f"cp{vi.major}{vi.minor}"


def _wheel_platform_tag() -> str:
    """Returns e.g. 'win_amd64' for Windows AMD64."""
    return sysconfig.get_platform().replace("-", "_").replace(".", "_")


def _retag_wheels_to_cp(dist: Path) -> None:
    """Rename py3-none-any wheels to cp-specific tags so pip auto-selects the
    correct wheel per Python version (required because the wheel bundles a
    native PyArmor runtime DLL).

    Only wheels whose name contains 'py3-none-any' are retagged; already-tagged
    cp-wheels (e.g. from a previous interpreter in build-multi) are left alone.
    """
    cp = _wheel_cp_tag()
    plat = _wheel_platform_tag()
    for whl in list(dist.glob("*-py3-none-any.whl")):
        parts = whl.stem.split("-")
        if len(parts) < 5:
            continue
        parts[-3] = cp
        parts[-2] = cp
        parts[-1] = plat
        new_name = "-".join(parts) + ".whl"
        whl.rename(whl.parent / new_name)
        print(f"[retag] {whl.name} -> {new_name}")


def _build_wheel_distribution(c) -> None:
    _copy_obfuscated_files()
    try:
        c.run(f'"{sys.executable}" -m build --wheel')
    finally:
        _restore_source_tree(c)

    wheels = list(Path("dist").glob("*.whl"))
    if not wheels:
        sys.exit(1)

    _retag_wheels_to_cp(Path("dist"))


@task
def clean(c):
    """Cleanup all build artifacts"""

    def _is_protected_dir(part: str) -> bool:
        if part in {".venv", "venv", ".tox", ".nox", ".git"}:
            return True
        if part.startswith(".venv.bak"):
            return True
        return False

    def _is_under_protected_dir(path: Path) -> bool:
        return any(_is_protected_dir(p) for p in path.parts)

    patterns = [
        "dist",
        "build",
        "*.egg-info",
        "dist-obfuscated",
        ".venv-test",
        "**/__pycache__",
        "**/*.pyc",
        "**/*.pyo",
        "**/*.pyd",
        "**/*.so",
        "**/*.dll",
        ".pytest_cache",
        ".coverage",
        "htmlcov",
    ]

    for pattern in patterns:
        for path in Path().glob(pattern):
            if _is_under_protected_dir(path):
                continue
            if path.is_dir():
                shutil.rmtree(path)
            elif path.is_file():
                path.unlink()


@task
def install_hooks(c):
    """Install Git Hooks"""

    hooks_dir = Path(".githooks")
    git_hooks_dir = Path(".git/hooks")

    for hook_file in hooks_dir.glob("*"):
        target = git_hooks_dir / hook_file.name
        shutil.copy(hook_file, target)

        # Make executable on Unix
        if sys.platform != "win32":
            c.run(f"chmod +x {target}")

    # Configure Git to use hooks directory
    c.run("git config core.hooksPath .githooks")


@task
def lint(c):
    """Run linters (black, ruff, mypy)"""

    commands = [
        ("black --check src/ tests/", "Black"),
        ("ruff check src/ tests/", "Ruff"),
        ("mypy src/", "MyPy"),
    ]

    failed = []
    for cmd, name in commands:
        result = c.run(cmd, warn=True)
        if result.exited != 0:
            failed.append(name)

    if failed:
        sys.exit(1)


@task
def format(c):
    """Format code with black"""
    c.run("black src/ tests/")


@task
def test(c, verbose=False):
    """Run unit tests"""

    cmd = "pytest tests/"
    if verbose:
        cmd += " -vv"

    c.run(cmd)


@task
def coverage(c):
    """Run tests with coverage report"""
    c.run("pytest tests/ --cov=manifestguard --cov-report=term-missing --cov-report=html")


@task
def obfuscate(c, platform: str = ""):
    """Obfuscate core modules with PyArmor"""

    # Cleanup
    shutil.rmtree("dist-obfuscated", ignore_errors=True)

    # PyArmor obfuscation
    # Do not rely on PATH. Resolve the `pyarmor` entrypoint next to the active interpreter.
    scripts_dir = Path(sys.executable).resolve().parent
    pyarmor_exe = next(
        (
            p
            for p in (
                scripts_dir / "pyarmor.exe",  # Windows venv
                scripts_dir / "pyarmor-8.exe",  # Windows venv (PyArmor v8)
                scripts_dir / "pyarmor-8",  # POSIX venv (PyArmor v8)
                scripts_dir / "pyarmor",  # POSIX venv
            )
            if p.exists()
        ),
        None,
    )

    if not pyarmor_exe:
        raise RuntimeError(
            "PyArmor executable not found next to the active interpreter. "
            f"Interpreter: {sys.executable}. "
            "Install PyArmor in this environment (pip install pyarmor)."
        )

    pyarmor_cmd = f'"{pyarmor_exe}"'

    platform_arg = f"--platform {platform} " if platform else ""
    c.run(
        f"{pyarmor_cmd} gen "
        f"{platform_arg}"
        f"--output dist-obfuscated/manifestguard "
        f"src/manifestguard/core/ "
        f"src/manifestguard/ai/"
    )

    # Count obfuscated files
    list(Path("dist-obfuscated").rglob("*.pyo"))


@task
def compile_cython(c):
    """Compile parsers with Cython"""

    setup_py = Path("setup.py")
    pyx_files = list(Path("src").rglob("*.pyx"))
    if not setup_py.exists():
        if not pyx_files:
            # Repo currently uses pyproject.toml builds; no Cython extension sources present.
            # Keep the task as a no-op to preserve the release pipeline contract.
            print("[compile_cython] No setup.py / no .pyx sources found. Skipping.")
            return
        raise RuntimeError("Cython sources (*.pyx) found, but setup.py is missing.")

    c.run(f"{sys.executable} setup.py build_ext --inplace")

    # Count compiled files (best-effort)
    list(Path("src/manifestguard").rglob("*.pyd")) + list(Path("src/manifestguard").rglob("*.so"))


@task(pre=[clean])
def build_source(c):
    """Build source distribution (no obfuscation)"""
    c.run(f'"{sys.executable}" -m build --sdist')


@task(pre=[clean, obfuscate, compile_cython])
def build(c):
    """Build wheel with obfuscated code"""
    _build_wheel_distribution(c)


def _resolve_local_wheels_cache() -> Path | None:
    """Return the first local ``find-links`` directory from pip's global config.

    Reads ``pip config list`` so the path is never hardcoded in this file.
    Returns None when no local find-links entry is configured.
    """
    import subprocess
    try:
        out = subprocess.check_output(
            [sys.executable, "-m", "pip", "config", "list"],
            text=True, stderr=subprocess.DEVNULL,
        )
    except Exception:
        return None
    for line in out.splitlines():
        if "find-links" in line.lower():
            # e.g.  global.find-links='file:///path/to/your/wheels'
            value = line.split("=", 1)[-1].strip().strip("'\"")
            path = Path(value.removeprefix("file:///").replace("/", os.sep))
            if path.is_dir():
                return path
    return None


def _publish_to_local_cache(dist: Path) -> None:
    """Copy all wheels and the sdist from dist/ to the local pip find-links cache.

    The cache path is read from pip's global ``find-links`` config entry so
    that no local path is hardcoded in source.  Silently skips when no
    matching directory is found.
    """
    cache = _resolve_local_wheels_cache()
    if cache is None:
        print("[local-cache] no local find-links dir found in pip config — skipping.")
        return
    for artifact in list(dist.glob("*.whl")) + list(dist.glob("*.tar.gz")):
        dest = cache / artifact.name
        shutil.copy(artifact, dest)
        print(f"[local-cache] copied {artifact.name} -> {dest}")


@task(pre=[clean, obfuscate, compile_cython])
def build_release(c):
    """Build source distribution and wheel for release publishing.

    After building, all artifacts are copied to the local pip find-links cache
    (resolved from pip's global ``find-links`` config) so that
    ``py -3.12 -m pip install --user manifestguard`` resolves the new version
    automatically.
    """
    c.run(f'"{sys.executable}" -m build --sdist')
    _build_wheel_distribution(c)

    dist = Path("dist")
    if not list(dist.glob("*.tar.gz")):
        sys.exit(1)

    _publish_to_local_cache(dist)


@task(pre=[obfuscate, compile_cython])
def build_wheel_only(c):
    """Build only the cp-tagged wheel for the current interpreter (no clean, no sdist).

    Used by build-multi so each interpreter's wheel is accumulated in dist/
    without the pre=[clean] step wiping previous wheels.
    """
    _build_wheel_distribution(c)


@task
def build_multi(c, pythons=""):
    """Build cp-tagged wheels for multiple Python versions in one pass.

    - Cleans once, builds one sdist, then per interpreter: obfuscates with
      *that* interpreter's PyArmor and builds a correctly tagged wheel.
    - All wheels accumulate in dist/ so you end up with e.g.:
        manifestguard-1.6.32-cp312-cp312-win_amd64.whl
        manifestguard-1.6.32-cp313-cp313-win_amd64.whl
    - pip automatically picks the right one at install time.

    Each interpreter listed must have invoke, pyarmor, and build installed.

    Usage:
        invoke build-multi --pythons ".venv/Scripts/python.exe,.venv313/Scripts/python.exe"
    """
    if not pythons:
        print(
            "[build_multi] --pythons required.\n"
            "  Example: invoke build-multi "
            '--pythons ".venv/Scripts/python.exe,.venv313/Scripts/python.exe"'
        )
        sys.exit(1)

    interpreters = [p.strip() for p in pythons.split(",") if p.strip()]

    # Step 1: clean once so dist/ starts empty
    clean(c)
    Path("dist").mkdir(exist_ok=True)

    # Step 2: build the sdist once with whichever interpreter runs this task
    c.run(f'"{sys.executable}" -m build --sdist')

    # Step 3: per-interpreter wheel build (obfuscate + wheel, no clean)
    for interpreter in interpreters:
        print(f"\n{'='*60}")
        print(f"[build_multi] Building wheel with: {interpreter}")
        print(f"{'='*60}")
        result = c.run(
            f'"{interpreter}" -m invoke build-wheel-only',
            warn=True,
        )
        if result.exited != 0:
            print(f"[build_multi] FAILED for {interpreter} (exit {result.exited})")
            sys.exit(result.exited)

    print("\nBuilt artifacts:")
    for f in sorted(Path("dist").iterdir()):
        print(f"  {f.name}")


@task
def install_multi(c, pythons="", user=True):
    """Install cp-tagged wheels userwide (or system-wide) for each listed interpreter.

    Picks the correct cp-tagged wheel from dist/ for each interpreter
    automatically — fails if no matching wheel is found.

    Usage (user-wide, default):
        invoke install-multi --pythons "py -3.12,py -3.13"

    Usage (system-wide):
        invoke install-multi --pythons "py -3.12,py -3.13" --no-user
    """
    if not pythons:
        print(
            "[install_multi] --pythons required.\n"
            "  Example: invoke install-multi --pythons \"py -3.12,py -3.13\""
        )
        sys.exit(1)

    wheels = list(Path("dist").glob("*.whl"))
    if not wheels:
        print("[install_multi] No wheels in dist/ — run invoke build-multi first.")
        sys.exit(1)

    user_flag = "--user" if user else ""

    for interpreter in [p.strip() for p in pythons.split(",") if p.strip()]:
        # Resolve cp tag for this interpreter
        result = c.run(
            f'"{interpreter}" -c "import sys; vi=sys.version_info; print(f\"cp{{vi.major}}{{vi.minor}}\")"',
            hide=True, warn=True,
        )
        if result.exited != 0:
            print(f"[install_multi] Could not query version for: {interpreter}")
            sys.exit(1)
        cp_tag = result.stdout.strip()
        matches = [w for w in wheels if cp_tag in w.name]
        if not matches:
            print(f"[install_multi] No wheel found for {cp_tag} in dist/ (interpreter: {interpreter})")
            print(f"  Available: {[w.name for w in wheels]}")
            sys.exit(1)
        wheel = sorted(matches)[-1]
        print(f"[install_multi] {interpreter} ({cp_tag}) <- {wheel.name}")
        c.run(f'"{interpreter}" -m pip install {user_flag} --force-reinstall --no-deps "{wheel}"')


@task
def test_wheel(c):
    """Test wheel installation in clean environment"""

    # Create temp venv
    venv_path = ".venv-test"
    c.run(f'"{sys.executable}" -m venv {venv_path}')

    # Determine paths
    if sys.platform == "win32":
        pip = f"{venv_path}/Scripts/pip"
        mg = f"{venv_path}/Scripts/manifestguard"
    else:
        pip = f"{venv_path}/bin/pip"
        mg = f"{venv_path}/bin/manifestguard"

    # Get latest wheel
    wheels = sorted(Path("dist").glob("*.whl"))
    if not wheels:
        sys.exit(1)

    wheel = wheels[-1]

    # Install
    c.run(f"{pip} install {wheel}")

    # Smoke tests
    c.run(f"{mg} --version")
    c.run(f"{mg} check --help")

    # Cleanup
    shutil.rmtree(venv_path)


@task(pre=[lint, test, build_release, test_wheel])
def publish(c, repo="pypi", dry_run=False, allow=False):
    """Publish to PyPI (guarded).

    Safety guardrails:
    - By default, publishing is refused.
    - Set MG_ALLOW_PYPI_PUBLISH=YES (or pass --allow) to enable publishing.
    - For real PyPI (repo=pypi) and non-dry-run, a confirmation phrase is required.
      Use MG_PYPI_CONFIRM to avoid interactive prompts in CI.
    """

    allow_env = os.environ.get("MG_ALLOW_PYPI_PUBLISH", "").strip().lower()
    is_allowed = allow or (allow_env in {"1", "true", "yes", "y"})
    if not is_allowed:
        print(
            "Refusing to publish by default. "
            "Set MG_ALLOW_PYPI_PUBLISH=YES or run: invoke publish --allow"
        )
        sys.exit(2)

    if repo == "pypi" and not dry_run:
        required_phrase = "PUBLISH MANIFESTGUARD TO PYPI"
        phrase_env = os.environ.get("MG_PYPI_CONFIRM", "").strip()

        if phrase_env != required_phrase:
            if not sys.stdin.isatty():
                print(
                    "Non-interactive publish to real PyPI requires MG_PYPI_CONFIRM="
                    f'"{required_phrase}"'
                )
                sys.exit(2)

            typed = input(f'Type "{required_phrase}" to continue: ').strip()
            if typed != required_phrase:
                print("Publish aborted.")
                sys.exit(2)

    cmd = "twine upload"

    if dry_run:
        cmd += " --dry-run"

    if repo == "testpypi":
        cmd += " --repository testpypi"

    cmd += " dist/*"

    c.run(cmd)

    if not dry_run:
        pass
    else:
        pass


@task
def release_check_packet(c, packet_dir: str, expected_homepage: str = "https://www.ready-4-it.com/mgpy"):
    """Audit a built release packet folder (wheel+sdist) for leaks and release hygiene."""
    script = Path("tools") / "release_check_packet.py"
    if not script.exists():
        raise RuntimeError(f"Missing release checker script: {script}")
    c.run(f"{sys.executable} {script} --packetDir {packet_dir} --expectedHomepage {expected_homepage}")


@task
def dev_install(c):
    """Install package in development mode"""
    c.run("pip install -e .[dev,ai]")


@task
def security_scan(c):
    """Run security scans (bandit, safety)"""

    # Bandit (code security)
    c.run("pip install bandit", warn=True)
    c.run("bandit -r src/", warn=True)

    # Safety (dependency security)
    c.run("pip install safety", warn=True)
    c.run("safety check", warn=True)


@task
def pre_release_check(c):
    """Run all pre-release checks"""

    checks = [
        ("Linting", lambda: lint(c)),
        ("Tests", lambda: test(c)),
        ("Coverage", lambda: coverage(c)),
        ("Build", lambda: build(c)),
        ("Wheel Test", lambda: test_wheel(c)),
        ("Security Scan", lambda: security_scan(c)),
    ]

    failed = []
    for check_name, check_func in checks:

        try:
            check_func()
        except Exception:
            failed.append(check_name)

    if failed:
        for _check in failed:
            pass
        sys.exit(1)
