"""Check i18n loading and required base keys.

Usage:
  python check_i18n.py
  python check_i18n.py --strict
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

REQUIRED_BASE_KEYS = (
    "cli.banner.separator",
    "cli.options.auto",
)


def _load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Expected object JSON in {path}")
    return data


def run_check(*, strict: bool) -> int:
    cli_json_path = Path("src/manifestguard/i18n/locales/en/cli.json")
    errors: list[str] = []

    if not cli_json_path.exists():
        errors.append(f"Missing locale file: {cli_json_path.as_posix()}")
    else:
        try:
            data = _load_json(cli_json_path)
            print("✅ JSON loaded successfully")
            print(f"📊 Keys loaded: {len(data)}")
            missing = [key for key in REQUIRED_BASE_KEYS if key not in data]
            if missing:
                for key in missing:
                    errors.append(f"Missing base key: {key}")
            else:
                print("✅ Required base keys present")
        except Exception as exc:
            errors.append(f"Failed to load {cli_json_path.as_posix()}: {exc}")

    print("\n--- Testing i18n module ---")
    try:
        from manifestguard.i18n import _get_i18n

        i18n = _get_i18n()
        print(f"Base path: {i18n.base_path}")
        print(f"Base path exists: {i18n.base_path.exists()}")

        cli_data = i18n.load_module("en", "cli")
        print(f"CLI module keys loaded: {len(cli_data)}")
        missing_module_keys = [key for key in REQUIRED_BASE_KEYS if key not in cli_data]
        if missing_module_keys:
            for key in missing_module_keys:
                errors.append(f"Missing i18n module key: {key}")

        result = i18n.get("cli.banner.separator", lang="en", module="cli")
        print(f"i18n.get() result: {result}")
    except Exception as exc:
        errors.append(f"i18n module check failed: {exc}")

    if errors:
        print("\n❌ i18n check reported issues:")
        for issue in errors:
            print(f"- {issue}")
        return 1 if strict else 0

    print("\n✅ i18n check passed")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Check i18n loading and base key availability")
    parser.add_argument("--strict", action="store_true", help="Exit non-zero on missing keys/errors")
    args = parser.parse_args()
    return run_check(strict=args.strict)


if __name__ == "__main__":
    raise SystemExit(main())
