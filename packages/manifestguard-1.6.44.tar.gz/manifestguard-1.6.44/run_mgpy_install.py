#!/usr/bin/env python3
"""ManifestGuard Runner (MGPY-only)

"""

import os
import sys
import io
from typing import cast


def _force_utf8_console() -> None:
    """Best-effort: avoid UnicodeEncodeError on Windows consoles (cp1252)."""
    if sys.platform != "win32":
        return

    # These env vars are primarily read at interpreter start, but setting them
    # here still helps subprocesses and some libs.
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")

    try:
        if hasattr(sys.stdout, "reconfigure"):
            cast(io.TextIOWrapper, sys.stdout).reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            cast(io.TextIOWrapper, sys.stderr).reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        # Best-effort only.
        pass


_force_utf8_console()

from mgpy_install.cli import main
from mgpy_install.rich_compat import console


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("[bold yellow]Interrupted by user (Ctrl+C).[/bold yellow]")
        raise SystemExit(130)
