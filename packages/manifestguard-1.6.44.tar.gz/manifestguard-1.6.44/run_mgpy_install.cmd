@echo off
python "%~dp0run_mgpy_install.py" %*
