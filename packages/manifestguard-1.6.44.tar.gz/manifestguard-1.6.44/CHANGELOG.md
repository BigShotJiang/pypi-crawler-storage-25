# Changelog

<!-- markdownlint-disable -->

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.6.44] - 2026-04-09

### Fixed
- Packaging docs no longer embed a user-specific Windows absolute path in the README, preventing that path from leaking into wheel and sdist metadata during publish-packet checks.

## [1.6.43] - 2026-04-09

### Fixed
- Install verification now allocates preserve-backup temp roots with a UUID-based run id, preventing same-process collisions on platforms where consecutive `time.time_ns()` calls can repeat.

## [1.6.42] - 2026-04-09

### Fixed
- QuickCheck recommendation-priority validation now resolves extended metrics from the same report candidates as the runtime logic, preventing false release-gate failures when metrics context is loaded from `report.json`.

## [1.6.41] - 2026-04-09

### Changed
- Extended metrics now prefetch the installed-package snapshot before the long coverage phase begins, so dependency and SBOM collection can reuse a warmed snapshot instead of starting inventory work late in the run.
- `mgpy check --extended` now prints a compact quality/coverage/test summary even when there are no recommendations, so successful runs still show the measured coverage result.

### Fixed
- Performance recommendations now only flag dependency analysis as a bottleneck when it is materially relevant relative to total analysis time, avoiding false low-priority warnings on coverage-dominated runs.

## [1.6.40] - 2026-04-08

### Added
- `validate-views` VV-007 detects deprecated `asyncio.get_event_loop()` and bare `loop.run_until_complete()` usage outside `tests/`.
- `.validateviewsrc` now supports `extends` for inheriting a base project config.
- `mgpy repo-status` prints repo-registry fingerprints, last-seen timestamps, and the active tier cap.

### Changed
- `mgpy history-export` now supports `--format csv` for machine-readable exports alongside JSON.
- Repo registry persistence now keeps backward-compatible metadata (`firstSeen` / `lastSeen`) instead of only a flat fingerprint list.

### Fixed
- Coverage collection in `mgpy check --extended` now suppresses project-level `pytest-cov` addopts during ManifestGuard's internal `coverage run -m pytest` and `pytest --collect-only` calls, preventing false 0% results and broken test-count discovery when projects already enable `--cov` in pytest config.
- `coverage.json` fallback handling no longer treats `num_statements > 0` with `covered_lines = 0` as a meaningful datapoint, so pre-existing valid coverage can recover after an invalid dual-instrumented run.

## [1.6.32] - 2026-04-04

### Added
- **`coverage.xml` (Cobertura) export** — `mgpy coverage` can now emit coverage in Cobertura XML format via `--format xml`; consumed by CI coverage badges and IDE plugins.
- **`mgpy ruff-metrics`** — new command; runs Ruff in stats mode and appends per-violation-category counters to the metrics history; TUI sparkline support for ruff deficit trend (Steps 42–43, 45).
- **`validate-views` VV-005/VV-006** — template-inheritance cycle detector (VV-005) and `pickle`/unsafe-YAML call detector (VV-006) added to the view-validation pass (Steps 35–37).
- **`jwt_utils.validate_token_expiry()`** — standalone expiry check extracted from licensing client; raises `TokenExpiredError` on expired JWTs (Step 48).
- **`tui_history` extractor functions** — 13 new unit-tested helpers for TUI history extraction (Step 49).
- **`resolve_project_root()` / `scope_root`** — workspace root helpers moved to `core/config`; removes duplicate CLI import paths (Steps 22–25).
- **`repo_registry` / `max_repos` CLI gate** — enforces per-tier repository limits at runtime; regression tests included (Step 22).
- **venv health sparklines, Markdown export, `dead_pids`/BPD correlation** in TUI metrics view (Steps 19–21).
- **`metrics reconstruct --dry-run`, `history-export`, `--since`** — three new `metrics` sub-commands for audit and replay (Steps 38–39, 45).

### Fixed
- **JWT expiry enforcement** — `_resolve_feature_base()` in `licensing/client.py` now validates token expiry and raises `TokenExpiredError` instead of silently continuing (Step 51 — security fix).
- **Dedup guard in `_append_entry_trimmed()`** — prevents duplicate metrics entries on rapid successive writes (Step 44).
- **`_blank_string_content()` false-positive** — blank comment bodies no longer trigger `hardcoded_strings` security findings (fixFalsePositiveSecurity:11).
- **`pickle`/`yaml.load` docstring false-positive** — occurrences in docstrings/comments are excluded from the unsafe-call detector (fixFalsePositiveSecurity:11).
- **CICD recommendation false-positive** — `_merge_cicd_recommendations()` deduplication corrected (Step 28).

### Refactored
- `cli._run_extended_tests` and 3 orphaned imports removed (Step 59 — dead code).
- `_apply_hardcoded_strings_scan()` extracted from inline policy runner (Step 57).
- `_sparkline_if_active()` extracted in TUI renderer (Step 56).
- `_as_int_clamped()` extracted as local closure in duplication reporter (Step 55).
- `_regression_entry()` / `_improvement_entry()` extracted from baseline diff logic (Step 54).
- `_resolve_feature_base()` + SQL detector refactored; licensing/security separation hardened (Steps 30–34).
- Workers, history, CICD helpers consolidated; CICD recommendation dedup fixed (Steps 26, 28).
- `resolve_project_root()` added to `core/config`; CLI `duplication` + `quickfix` migrated (Steps 24–25).

## [1.6.31] - 2026-04-04

### Added
- **Standalone focused commands** — three new subcommands replacing MGVS bridge wrappers:
  - `mgpy security` — static SAST + supply chain CVE analysis only; exits 0 (clean) / 1 (findings) / 2 (error); feature-gated (`cve_checks`).
  - `mgpy quality` — AST complexity + duplication + dummy/placeholder detection only; available on all tiers including community.
  - `mgpy license-check` — SPDX license consistency scan only; feature-gated (`extended_analysis`).
  - All three accept `--report <path>`, `--verbose`, and a `--fail-on-*` / `--no-fail` flag.
- **License tiers** — `free` (community alias), `trial`, and `early_access` added to `FEATURE_LIMITS` and `_normalized_tier()` in `licensing/client.py`:
  - `free` maps to `community` feature set (max 5 repos).
  - `trial` = full Pro features except `quickfix_apply=False`, single device, unlimited repos.
  - `early_access` normalises to `trial` — Early Access purchasers receive trial-level features until permanent Pro key is issued.
- **E2E regression tests** — `tests/test_extended_report_contract.py`:
  - Golden report contract test: strips volatile fields, compares canonical structure across two consecutive runs.
  - No-import safety test: fixture file that raises at import must not leak execution into static scan.
  - `exec()` safety test: fixture file that calls `exec()` to write a marker file; marker must not exist after scan.
- **GUI dashboard feature gate** — licenses without the desktop dashboard entitlement see a "🔒 Pro License Required" upgrade prompt instead of dashboard content; `help` and `license` pages remain freely accessible (`gui_dashboard_mixin.py`).
- **`_DASHBOARD_FREE_PAGES` contract tests** — guardrail tests assert which pages are always accessible vs. gated.
- **`jwt_utils.py`** — stateless `parse_token_payload` / `verify_token_signature` helpers extracted from `client.py`.
- **`_finalize_full_run_metrics()`** extracted from `collect_metrics()` in `metrics.py`.
- **`_check_renewal_policy()`** and **`_merge_activation_features()`** extracted from `client.py`.

### Fixed
- CLI bootstrap: license command registration now occurs after the root Click group is defined, avoiding import-time failures in CLI tests.
- `_clean_series()` in `gui_dashboard_stats.py` now filters NaN and infinite float values.
- `build_dashboard_stats_view_model()` issue count now prefers `history.issues.totalIssues` over `report_data.errors + warnings`.
- `data_source` field shows diagnostic `Tried: .mgpy/metrics/manifestguard-history.json` when no history/report data is found.
- Extended report regression coverage: canonical golden contract test plus a static-scan no-import safety test for `manifestguard check --extended --report`.
- Test safety: golden snapshots now require explicit local opt-in via `MANIFESTGUARD_UPDATE_GOLDEN=1`; CI workflows pin the variable to `0`.

## [1.6.23] - 2026-03-22

### Added
- Refactoring plan: baseline rules and AI hints are now always active; user config can extend but not disable the baseline.
- Refactoring plan: `aiHints` and `aiInstruction` fields now supported in `mg.rules.refactoring.json` (Format A/B); CLI output includes `aiHintsActive` and `aiInstruction`.
- Refactoring plan: `noLocSplitting` AI hint added to baseline — enforces "modularize, do not split" as an invariant.
- Refactoring rules: MGVS-aligned allowlists for rule IDs and AI hint IDs; legacy IDs map to canonical suggestions.

### Fixed
- Bootstrapper: corrected `REFRACTORING` → `REFACTORING` typo in variable names and epilog placeholder in `examples/run_manifestguard.py` and `examples/i18n/run_manifestguard/en.json`.

## [1.6.20] - 2026-03-21

### Added
- Dashboard stats: new `gui_dashboard_stats.py` module for Python dashboard statistics.
- ADR: architecture decision record for Python dashboard UI modernization.
- Planning: dashboard modernization planning notes.

### Changed
- Licensing CLI: command registration refactored to eliminate circular import; `license_group` passed explicitly.
- Licensing tests: test-signing helpers moved to releaser-only; removed from product repo.
- Licensing client: aligned to shared interpreter resolution path.
- Docs: updated how-to, roadmap, and GUI documentation to reflect dashboard and licensing changes.

### Removed
- `activate_test_license.py` and `integration_test_license.py` removed from product repo (now releaser-only).

## [1.6.19] - 2026-03-20

### Added
- Runtime validation metrics: new timing buckets for manifest parsing vs. rule-engine execution, plus tests for the exported timing helper.
- Windows install helper: added `run_mgpy_install.cmd` as a direct wrapper for `run_mgpy_install.py`.

### Changed
- Installer/runtime tooling: refined install, interpreter, pip, dependency, metrics, and scan-space flows across CLI, TUI, GUI, and supporting helpers.

### Fixed
- Licensing and reporting flow: aligned activation handling and downstream metrics/report integration for the current Python toolchain changes.

## [1.6.15] - 2026-02-07

### Added
- Refactoring rules plan: new `refactor-plan` CLI command to load/validate `mg.rules.refactoring.json` from `.mgpy/` (then `.mgvs/`) and output a sequenced plan
- Refactoring rules plan: new core module `manifestguard.core.refactoring_rules`

### Changed
- Windows tooling: `python run_mgpy_install.py --help` is now robust under legacy console encodings (forces UTF-8 output)

## [1.6.14] - 2026-02-07

### Changed
- **Metrics history location**: Centralized all metrics history to `.mgpy/metrics/manifestguard-history.json` (parallel to MGVS `.mgvs/history/`). Legacy locations (`.manifestguard-history.json`, `.manifestguard/metrics-history.json`) remain readable for migration compatibility.
- All readers (CLI, TUI, GUI, metrics collectors) now use `resolve_history_file_path()` with priority-based fallback.
- All writers (coverage tracking, venv health, repo reconstruction) write to new location.
- Cross-tool compatibility maintained: MGPY writes both `metrics[]` (native) and top-level slices (MGVS-compatible) for coverage entries.
- 38 tests passing (metrics history export, reconstruction, coverage weekly, venv health weekly).

### Added
- New helper: `resolve_history_file_path()` with priority-based resolution (`.mgpy/metrics/` → legacy locations).
- Concept document: `concept.metrics-directory-structure.en.md` documenting centralized metrics architecture.

## [1.6.13] - 2026-02-04

### Added
- CI helpers: `examples/run_manifestguard.py` supports `--ci` / `--non-interactive` and an optional bounded local `--fix-loop`
- CI templates (draft): `ci/integration-examples/` (GitHub Actions + Azure Pipelines)

### Changed
- Complexity (LOC thresholds): more AI-friendly defaults (High=600, Critical=1200) for oversized-file hotspot detection

## [1.6.8] - 2026-01-30

### Changed
- CLI refactor: split large `manifestguard.cli` command implementations into `manifestguard.cli_parts` modules to comply with internal per-file LOC limits while preserving backwards-compatible import/patch targets

### Fixed
- CLI wiring stability: ensured `export-metrics`, baseline management, and venv health tracking remain compatible with test monkeypatch expectations and history schema requirements

## [1.6.7] - 2026-01-23

### Changed
- Maintenance release: documentation/status synchronization (no runtime behavior changes)

## [1.6.6] - 2026-01-20

### Fixed
- Filesystem scan safety: `safe_rglob()` now prunes common huge directories (`.venv/`, `node_modules/`, `.git/`, caches/build dirs) to prevent accidental whole-workspace traversal
- Bounded traversal: keeps max-files enforcement and symlink/containment guards while using a prunable `os.scandir()` walk

## [1.6.5] - 2026-01-20

### Added
- Worker result export formats: `mgpy worker venv-wizard-preflight` now supports `--output-format` (summary|json|markdown|html) for professional reporting
- Preflight Phase III: Weekly venv health analytics via `mgpy venv-health-weekly` command (ISO-week aggregation, multi-week trend analysis, health score tracking)
- New module `manifestguard.reporting.worker_export` with Markdown/HTML formatters for worker results (offline-safe, no CDN dependencies)
- New module `manifestguard.extended.venv_health_weekly` for weekly venv health reconstruction from metrics history

### Changed
- Cross-tool orchestration: Worker results now exportable in multiple formats for documentation and CI integration

## [1.6.3] - 2026-01-19

### Fixed
- vwpy preflight timeline: normalized timeline keys to improve compatibility across historical formats

## [1.6.2] - 2026-01-19

### Fixed
- Argument normalization: aligned behavior + error messages with normalization contract tests
  - Path dict inputs now accept custom path-like keys (e.g. `venv_path`)
  - Dict normalization supports Pydantic-like `.dict()` and enforces JSON object inputs
  - List normalization rejects dict inputs and reports element type errors as "Element at index N"
  - `get_arg_description()` now uses `str:` / `Path:` / `dict:` / `list:` formatting with truncation

## [1.6.1] - 2026-01-18

### Added
- Test config thresholds helper (Python port of MGVS threshold/test-config logic)
- Complexity tool-config validation surfaced in metrics (engine configuration sanity checks)

### Changed
- Public user guide for test config moved under `src/manifestguard/doc/` for bundling

## [1.6.0] - 2026-01-18

### Added
- **Argument normalization framework**: New `normalize.py` module providing flexible input handling for paths, dicts, and lists
  - `normalize_path_input()`: Accept str/Path/dict/objects with `.path` attribute
  - `normalize_dict_input()`: Accept dict/objects with `.to_dict()`/JSON strings
  - `normalize_list_input()`: Accept list/tuple/single items/CSV strings
  - `get_arg_description()`: Debug helper for human-readable value representation
- Exported normalization functions in validation module `__all__`
- Comprehensive concept documentation for argument normalization.

### Changed
- Validation framework now supports preprocessing layer (normalization → validation → business logic)

## [1.5.31] - 2026-01-17

### Added
- GUI i18n bundles: generated locale JSON files for GUI strings.

### Fixed
- i18n coverage: added tests to ensure GUI locales are present and consistent.

## [1.5.30] - 2026-01-17

### Added
- GUI settings: Requirements/Packages snapshot support (full snapshots as artifacts + delta-only history timeline entries).

### Changed
- GUI settings: Repository (artifacts) fields now persist and migrate legacy keys.
- GUI preflight: uses configured user repo root as workspace for history/artifacts.

### Fixed
- AI preflight analyzer tolerates snake_case/camelCase HealthReport fields.
- Removed duplicate `add_venv_health_to_history()` definition to prevent ambiguity.

## [1.5.28] - 2026-01-11

### Changed
- Release sync: version bump with tests passing.

## [1.5.27] - 2026-01-08

### Fixed
- Reduced log noise for scan-space safety limits ("Reached file limit...") while preserving protective behavior.
- Hardened `run_mgpy_install.py` to avoid leaving local repository artifacts and to improve robustness.

## [1.5.26] - 2026-01-08

### Added
- **validate-views (generic tool)**: `mgpy validate-views <target_dir>` for external Python projects, plus example projects and CI/pre-commit patterns.
- **Complexity engine selection**: default `mgpy-analyzer`, optional `radon` via `manifestguard[radon]`, with engine provenance in reports/history.
- **Coverage metrics tooling**: coverage tracking + weekly aggregation helpers and related CLI commands.
- **Automation/CI templates**: multi-interpreter validation and _info repo update helpers.

### Fixed
- Complexity average reporting showing `0.0` by improving scan-root fallback and JSON compatibility.

### Technical Debt
- Test suite status: **834 passed, 3 skipped** (all green)
  - Deleted incorrect `VALIDATE-VIEWS-SELF-CHECK-*` documents, updated TODO.md with correct implementation tasks

- **validate-views User Guide (Phase 1 Complete)**: Comprehensive external user documentation
  - Created `VALIDATE-VIEWS-USER-GUIDE.md` in mgpy_info repo with 400+ lines of examples and integration patterns
  - **Installation**: Documented `pip install manifestguard[validate-views]` for lightweight setup
  - **Rule Reference**: VV-001 (TUI screen registration), VV-002 (HTML inline styles), VV-003 (HTML inline handlers)
  - **CI Integration**: GitHub Actions, GitLab CI, pre-commit hooks with complete YAML examples
  - **Project Examples**: Rich TUI applications, Flask web apps, Django templates, Jupyter notebooks
  - **Configuration**: `.validateviewsrc` JSON config, `pyproject.toml` integration, suppression comments
  - **Output Formats**: Human-readable CLI output, JSON for CI pipelines (exit codes 0/1/2)
  - **Troubleshooting**: False positives, performance tuning, common issues and solutions
  - **pyproject.toml**: Added `[validate-views]` optional dependency (no extra packages, uses stdlib only)

- **validate-views Example Projects**: Working sample projects demonstrating CI integration
  - `examples/example-rich-tui/`: Minimal TUI app with VV-001 Screen Registration check, GitHub Actions workflow
  - `examples/example-flask-app/`: Flask web app with VV-002/003 HTML template hygiene, pre-commit hooks
  - Both examples include: Working code, CI configuration, README with violation testing instructions
  - `examples/README.md`: Overview of all examples with usage patterns and quick comparison table
  - Ready for external developers to copy and adapt patterns to their projects

### Technical Debt
- Test suite status: **788 passed, 3 skipped** (all green)
- Test count progression: 773 → 788 (+15 effective validate-views tests)

## [1.5.25] - 2026-01-07

### Changed
- **Release Sync**: Version bump for the integration branch to keep mgpy in lockstep with MGVS v0.41.31 and aligned licensing/report-path behavior.

### Technical Debt
- Test suite status on release: **695 passed, 3 skipped** (all green).

## [1.5.19] - 2025-12-26

### Changed
- **Stability Release**: No functional changes, version bump for release synchronization

### Technical Debt
- Total test suite: **636 passed, 6 skipped** (all green)

## [1.5.18] - 2025-12-26

### Added
- **QuickFix Expansion (ADR-021 Phase 1)**: DUMMY code auto-fixes for developer productivity
  - **DUMMY-001 fixes**: Remove or convert stub markers (TODO/FIXME/STUB/PLACEHOLDER)
    - Option 1: Remove marker comment entirely
    - Option 2: Convert to issue tracker reference (# See: ISSUE-XXX)
    - Supports 60+ patterns across 6 languages
  - **DUMMY-002 fixes**: Replace NotImplementedError with minimal stub
    - Generates `pass  # TODO: Implement logic` in place of exception
    - Excludes abstract methods with `@abstractmethod` decorator
  - Comprehensive backup/restore with `BackupContext` integration
  - Interactive, auto, and dry-run modes available
  - 8 new integration tests (all passing)
- **File Operations Module**: Safe file manipulation helpers for QuickFix system
  - `file_ops.py`: read/write/remove/replace/insert line operations
  - Encoding-safe (UTF-8), backup-aware, error-handling built-in
- **ADR-021 Document**: QuickFix System Expansion Strategy (Phase 1-3 roadmap)
  - Phase 1: DUMMY fixes (v1.5.18) ✅
  - Phase 2: Manifest hygiene fixes (MG-001 to MG-010, v1.5.19) 🔄
  - Phase 3: Security & Ruff integration (SEC-*/RUFF-*, v1.6.0) 📋
  - Target coverage: 28.4% of all diagnostic codes (high-value automation)

### Changed
- **QUICKFIX-GUIDE.md**: Updated with DUMMY-001/002 examples and usage
- **QuickFix Registry**: Expanded from 3 to 5 fix generators (+67% coverage)

### Fixed
- **QuickFix Line Number Handling**: Fixed `diagnostic.line` vs `diagnostic.line_number` consistency

### Technical Debt
- Total QuickFix tests: **37 passing** (29 existing + 8 new)
- Total test suite: **636 passed, 6 skipped**

## [1.5.17] - 2025-12-26

### Added
- **Auto-Migration for Config**: Automatic migration of old `scanSpace.ignoreDirs` to `ignorePatterns` (ADR-014)
  - Migration happens transparently on config load in `ConfigurationService`
  - Migrated config is written back to file
  - User feedback: "✅ Config auto-migrated: scanSpace.ignoreDirs → ignorePatterns"
- **Examples API**: New `manifestguard examples` command for templates
  - Templates for config, report, history, metrics schema
  - Output to console or file: `manifestguard examples --type config --output file.json`
- **Enhanced CLI Help**: Comprehensive documentation in all commands
  - Quick Start section with common workflows
  - Extended Analysis Categories with tool names (pytest-cov, mgpy-analyzer / optional radon, pip-audit, etc.)
  - Configuration Sections explained (ignorePatterns, rules, suppressions, etc.)
  - Rule Codes reference (MG-001, DUMMY-001 to DUMMY-030, License, Policy)
  - Concrete examples for each command
- **Bootstrap Script Enhancements**: CI/CD-ready project integration script
  - `--force-init-config`: Force config regeneration
  - `--report <file>`: Custom report filename
  - CI/CD integration examples in help (GitHub Actions, GitLab CI, Jenkins, Azure)
  - Success tip with CI/CD command after run
  - Referenced in main CLI help with GitHub link

### Changed
- Pre-push git hook: Removed heavy tests/build validation, kept only tag format validation
- CLI help now shows available test categories, workflows, and integration examples

### Status
- All tests passing (628 passed, 6 skipped)
- Code quality: ZERO violations maintained

## [1.5.16] - 2025-12-26

### Added
- **ADR-014 Unified Scan Space & Excludes Strategy**: Complete implementation with precedence-based ignore system
  - `ScanSpaceResolver` with 4-tier precedence: manifestguard.json > .manifestguardignore > VCS ignore files > built-in defaults
  - Pattern matching for globs (`dir/**`), wildcards (`*.ext`, `test_*`, `*suffix`), directory patterns (`dir/`)
  - 36 built-in default patterns (venv, __pycache__, node_modules, .git, etc.)
  - `excludedBy` attribution for observability (track which rule excluded a file)
  - `ScanSpaceSummary` for scan reports with included/excluded file lists
  - Cross-platform path normalization (Windows backslash → forward slash)
  - Contract tests ensure MGVS compatibility

### Changed
- `IgnorePatterns` converted to compatibility wrapper around `ScanSpaceResolver`
- Duplication detection now respects ignore patterns correctly

### Status
- All tests passing (628 passed, 6 skipped)
- Code quality: ZERO violations maintained

## [1.5.14] - 2025-12-25

### Added
- **Dummy Code Recognition - Complete**: Finalized ADR-015 with comprehensive documentation.
  - 6 detection layers (DUMMY-001, DUMMY-002, DUMMY-010, DUMMY-011, DUMMY-012, DUMMY-030)
  - 60+ multilingual markers across 6 languages (EN, DE, FR, ES, TR, LB)
  - Inline suppression support (`# manifestguard-ignore-next-line: DUMMY-001`)
  - Config suppressions with required `reason` and optional `expires`
  - Integration with PolicyMetrics and extended analysis mode
  - Full test coverage (contract tests + suppression tests)
  - Marker documentation consolidated in `src/manifestguard/extended/markers/README.md`

### Changed
- Updated roadmap: ADR-015 marked as complete (Q4 2025)
- Updated documentation: Marker references consolidated in evaluation docs

### Status
- All tests passing (615 passed, 6 skipped)
- Code quality: ZERO violations maintained
- Production-ready: Dummy recognition feature complete

## [1.5.13] - 2025-12-25

### Changed
- **Version Bump**: Post-analysis update following comprehensive TODO/Roadmap evaluation.
- All tests passing (615 passed, 6 skipped). Test runtime: 6:00 minutes.
- Production-ready codebase confirmed. Ready for Q1 2026 PyPI publication sprint.

## [1.5.12] - 2025-12-25

### Changed
- **Code Quality - ZERO VIOLATIONS**: Marked all 43 intentional lazy loading imports with `# noqa: PLC0415`.
  - Lazy imports are intentional for performance optimization (avoid loading heavy dependencies at startup).
  - Marked in 20 files: ai/shared_preferences.py (5), cli.py (4), core modules (7), extended modules (11), licensing, openapi, tui (6), validation (9).
  - **Result**: 0 Ruff violations (100% clean code!).
- All tests passing (615 passed, 6 skipped). Coverage: 72.62% maintained.

## [1.5.11] - 2025-12-25

### Changed
- **Code Quality - MASSIVE STYLE CLEANUP**: Auto-fixed 950 style violations across 75 files.
  - **Q000** (363): Standardized all quotes to double quotes for consistency.
  - **D212** (307): Fixed multi-line docstring formatting (summary on first line).
  - **D413** (232): Added missing blank lines after last docstring section.
  - **D202** (30): Fixed blank lines after function definitions.
  - **D204** (18): Fixed blank lines after class definitions.
- **Final Status**: Only 43 PLC0415 violations remaining (intentional lazy loading).
- **Quality Milestone**: 96.8% violation reduction from original baseline (1,360→43).
- All tests passing (615 passed, 6 skipped). Coverage: 72.62% maintained.

## [1.5.10] - 2025-12-25

### Changed
- **Code Quality**: Further improvements - reduced to 43 violations (89.5% reduction from v1.5.3 baseline).
  - **SIM108**: Resolved 1 violation - converted verbose if-else to concise ternary for simple assignment.
  - **COM812**: Added 509 trailing commas for better git diffs (auto-fixed).
    - Trailing commas reduce merge conflicts when adding list/dict items
    - Cleaner diffs show only the added line, not the modified previous line
  - **PLC0415**: 43 remaining violations are intentional lazy loading (performance optimization, documented).
- All tests passing (615 passed, 6 skipped).
- Coverage: 72.62% maintained.

## [1.5.9] - 2025-12-25

### Changed
- **Code Quality**: Ruff violations cleanup - reduced from 234 to 43 (81.6% reduction, total 89.5% since v1.5.3).
  - **E501**: Line-too-long violations eliminated - reduced from 191 to 0 (100% elimination).
    - Increased line-length limit from 100 to 120 characters in pyproject.toml (modern standard, eliminates 163 violations).
    - Refactored all remaining 28 long lines through proper code formatting:
      - Split ternary expressions into if-else blocks for better readability (10 instances)
      - Broke dict literals across multiple lines (8 instances)
      - Extracted function call parameters to separate lines (6 instances)
      - Split complex f-strings into multiline expressions (4 instances)
    - **Tools used**: Ruff linter for detection, manual refactoring for readability, Black formatter for consistency
  - **PLC0415**: 43 remaining violations are intentional lazy loading (documented in previous releases).
- All tests passing (615 passed, 6 skipped).
- Coverage: 72.62% maintained.
- Note: 1 new SIM108 violation (suggests ternary over if-else) - intentionally kept for readability.

## [1.5.8] - 2025-12-24

### Changed
- **Code Quality**: Ruff violations cleanup - reduced from 243 to 234 (3.7% reduction, total 43.5% since v1.5.3).
  - **E402**: Fixed 5 module import placement violations (cli.py).
    - Moved logger initialization after all imports to comply with PEP 8 import ordering.
  - **PLR0911**: Added noqa comments to 4 functions with intentional multiple return paths.
    - Files: core/version_validator.py (8 returns), extended/dummy_recognition.py (7 returns), licensing/client.py (9 returns), validation/license_guardrail.py (12 returns)
    - Complex validation/normalization logic requires multiple early returns for clarity.
- All tests passing (615 passed, 6 skipped).
- Coverage: 72.62% maintained.

## [1.5.7] - 2025-12-24

### Changed
- **Code Quality**: Ruff violations cleanup - reduced from 257 to 243 (5.4% reduction, total 41.0% since v1.5.3).
  - **S603**: Added noqa comments to 8 subprocess calls with controlled commands (Security Documentation).
    - Files: api/integration_test.py (2), extended/dependency_collection.py (2), extended/metrics.py (1), extended/sbom_collection.py (1), extended/supply_chain_audit.py (2)
    - All subprocess calls use hardcoded system executables (sys.executable, git) with validated arguments.
  - **PLW0603**: Added noqa comments to 4 global statement usages (Singleton Pattern Documentation).
    - Files: ai/shared_preferences.py (1), api/quick_check_cache.py (1), core/logging.py (2)
    - Standard singleton pattern - global statements intentional for module-level caching.
  - **SIM105**: Replaced 2 try-except-pass blocks with contextlib.suppress() (Code Clarity).
    - Files: cli.py (1), licensing/client.py (1)
- All tests passing (615 passed, 6 skipped).
- Coverage: 72.62% maintained.

## [1.5.6] - 2025-12-24

### Changed
- **Code Quality**: Ruff violations cleanup - reduced from 271 to 257 (5.2% reduction, total 37.2% since v1.5.3).
  - **S112**: Added exception logging to 5 try-except-continue patterns (Security Fix).
    - Files: api/quick_check.py, cli.py, extended/dummy_recognition.py, extended/duplication.py, extended/metrics.py
  - **ARG001/ARG002/ARG003**: Fixed 14 unused argument violations.
    - Prefixed unused but intentional arguments with underscore (interface contracts).
    - Added noqa comments for Click/pytest hook parameters.
    - Files: cli.py (2), core/logging.py (1), extended/security_detectors.py (1), pytest_progress.py (1), quickfix/__init__.py (5), quickfix/backup.py (1), validation/python_import_analysis.py (3)
- All tests passing (615 passed, 6 skipped).
- Coverage: 72.62% maintained.

## [1.5.5] - 2025-12-24

### Changed
- **Code Quality**: Ruff violations cleanup - reduced from 287 to 271 (5.6% reduction, total 33.5% since v1.5.3).
  - **RUF012**: Added ClassVar annotations to 9 mutable class attributes (Security Fix).
  - **ERA001**: Removed 2 commented-out code blocks (app.py).
  - **RUF001**: Replaced 2 ambiguous unicode characters with ASCII (cli.py ➕/➖ → +/-).
  - **E402**: Fixed module import order with noqa for intentional late import (quickcheck).
  - **RUF006**: Fixed 2 dangling asyncio tasks by storing references (tui.py).
- All tests passing (615 passed, 6 skipped).
- Coverage: 72.62% maintained.

## [1.5.4] - 2025-12-24

### Changed
- **Code Quality**: Ruff violations cleanup - reduced from 308 to 287 (6.8% reduction).
  - **PTH123**: Migrated 12 `open()` calls to `Path.open()` for pathlib consistency.
  - **F401**: Removed 4 unused imports (typing.Dict, typing.List, manifestguard.i18n.t, rich availability check).
  - **SIM102**: Simplified 4 nested if statements into single conditional expressions.
  - **I001**: Auto-fixed 1 import sorting violation.
- All tests passing (615 passed, 6 skipped).
- Coverage: 72.62% maintained.

## [1.5.3] - 2025-12-24

### Changed
- **Code Quality**: Refactored 19 import statements to top-level (PLC0415 cleanup).
  - Moved non-optional imports from function bodies to module top-level.
  - Reduced PLC0415 violations from 146 to 127 (13% reduction).
  - All tests passing (615 passed, 6 skipped).
- Remaining lazy imports preserved for optional dependencies (Rich, Radon engine, pycodestyle) and circular dependency avoidance.

## [1.5.2] - 2025-12-24

### Added
- Incremental pydocstyle enforcement via pre-commit for `src/manifestguard/**/*.py`.
- Pytest guardrails for the pydocstyle/pre-commit configuration (tests/quality).

### Changed
- Documentation updated to reflect the pydocstyle enforcement approach.

## [1.4.10] - 2025-12-23

### Added
- Dummy recognition suppressions/allowlist support (`dummyRecognition.suppressions`) with required reason and optional expiry.
- Policy metrics now respect configured dummy-recognition suppressions.

### Changed
- `show-config` defaults now include `dummyRecognition.suppressions`.
- Sphinx configuration docs updated with suppression configuration example.

## [1.4.9] - 2025-12-23

### Added
- MGVS-inspired dummy/placeholder code recognition (P0) with contract tests.
- Extended metrics integration: dummy recognition counts exported via Policy metrics.

## [1.4.5] - 2025-12-17

### Changed
- Bumped project version to 1.4.5 (CLI 0.5.3) to capture the successful core validation run and extended verification workflow.
- Updated release automation metadata to reflect the aligned CLI/package versions after rerunning `run_manifestguard.py` with extended analysis.

## [1.4.4] - 2025-12-16

### Changed
- Bumped project version to 1.4.4 (CLI 0.5.2) to ship the enhanced manifest validation core feature.
- Hardened manifest validators to use `packaging.Requirement` parsing for `pyproject.toml`, `setup.py`, and `requirements.txt`, catching duplicate entries and invalid specifiers earlier.
- Extended entry point discovery to scan additional source layouts, improving error diagnostics when CLI targets unknown callables.

### Added
- Introduced regression coverage for the updated validators ensuring invalid dependencies, optional dependency tables, and entry point lookups are reported consistently.

## [1.4.3] - 2025-12-15

- Bumped project version to 1.4.3 (CLI 0.5.1) to capture latest automation fixes.
- `run_manifestguard.py` now re-installs the freshly built wheel into the base Python interpreter when versions diverge, keeping global environments aligned after successful checks.

## [1.4.2] - 2025-12-09

### Changed
- `run_manifestguard.py` now auto-installs required build tooling (e.g. `build`) when missing to ensure fresh environments can package and install locally without manual preparation.
- Updated Rich integration to remove unused imports and simplify dependency handling during CLI runs.

### Fixed
- Resolved Python dashboard project detection in the VS Code companion by decoding Windows `file://` URIs correctly, restoring multi-project discovery.

## [1.4.0] - 2025-11-29 ✅

### 🎉 MILESTONE: F-018 Type Hints & mypy Enforcement - 100% COMPLETE

This release achieves **zero mypy errors** with strict type checking enabled, completing the F-018 Type Hints & mypy Enforcement feature from the Clean Code Foundation initiative.

### Added
- **Type Annotations** ✅
  - Added 74+ type annotations across 54 source files
  - Added missing return type annotations (`-> None`, `-> Dict[str, Any]`, `-> bool`, `-> float`)
  - Added function parameter types (`Callable`, `Dict[str, Any]`, `List[Dict]`, `Set[str]`)
  - Added variable type annotations for collections (`Dict[str, List]`, `List[Dict[str, Any]]`, `Set[str]`)
  - Fixed Python 3.8 compatibility (replaced `is_relative_to` with `try/except` pattern)
  - Installed `types-PyYAML` stub package for yaml type checking

- **Type Safety Fixes** 🔧
  - Fixed 88 mypy strict mode errors → **0 errors** (100% complete)
  - Fixed `Union`, `Tuple`, `List`, `Dict`, `Any`, `Set`, `Callable`, `cast` imports in 15+ modules
  - Fixed `callable` → `Callable` type annotation in runner.py
  - Fixed `AIProvider` Literal type validation with type assertion
  - Fixed `Optional[Dict]` `.get()` access with proper None checks
  - Fixed return type mismatches (int vs bool, Any vs Dict, float vs int)
  - Fixed unreachable code warnings in environment.py
  - Fixed DependencyMetrics attribute (`total_dependencies` → `direct_count`)
  - Added type ignores for Pydantic compatibility and false positives

- **Middleware Type Annotations** 📡
  - Added proper types to FastAPI middleware functions (`i18n_middleware`, `audit_middleware`, `logging_middleware`)
  - Added exception handler type annotations (`_handler` with `Exception` parameter)
  - Added `Callable` types for middleware `call_next` parameters

### Changed
- **Type Quality** 📊
  - mypy strict mode: 88 errors → **0 errors** (-100%)
  - Type coverage: ~60% → ~95% (estimated)
  - All 54 source files pass mypy strict checks
  - Test suite: 455/457 passing (99.6%)
  - Code coverage: 98.74% maintained
  - Quality score: 97.0/100 maintained

### Technical Details
- **Error Reduction Progress**:
  - Start: 88 errors (baseline)
  - After Python 3.10+ syntax fixes: 61 errors (-27 errors)
  - After return type annotations: 52 errors (-9 errors)
  - After collection type annotations: 43 errors (-9 errors)
  - After licensing/client.py fixes: 32 errors (-11 errors)
  - After CLI/runner type annotations: 14 errors (-18 errors)
  - After middleware type annotations: 5 errors (-9 errors)
  - Final: **0 errors** (-5 errors) ✅

- **Files Modified**: 20+ files including:
  - `extended/metrics.py`, `extended/runner.py`, `extended/baseline.py`
  - `licensing/client.py`, `ai/shared_preferences.py`, `ai/capabilities.py`
  - `cli.py`, `api/app.py`, `api/routes/environment.py`
  - `api/quick_check.py`, `api/quick_check_cache.py`, `quickcheck.py`
  - `environment/service.py`, `i18n/__init__.py`

## [1.3.0] - 2025-11-28 🎯

### 🚀 MILESTONE: Clean Code Foundation - Complexity Reduction

This release focuses on **code complexity reduction** and **type safety improvements** as part of the Clean Code Foundation initiative.

### Changed
- **Complexity Reduction** 🎯
  - Refactored `_generate_recommendations()` from complexity 54 → 8 (split into 5 helper functions)
  - Refactored `show_recommendations()` from complexity 43 → 8 (split into 5 helper functions)
  - Top complexity reduced from 54 to 39 (-28% improvement)
  - 19 functions still exceed threshold (was 20), target: <10 for all functions
  - Helper functions: `_generate_coverage_recommendations()`, `_generate_dependency_recommendations()`, `_generate_security_recommendations()`, `_generate_complexity_recommendations()`, `_generate_quality_recommendations()`
  - Display helpers: `_display_critical_recommendations()`, `_display_high_recommendations()`, `_display_medium_recommendations()`, `_display_low_recommendations()`, `_display_recommendation_details()`

### Added
- **Type Safety Improvements** ✅
  - Added `Union` import to `api/quick_check.py`, `quickcheck.py`, `cli.py`
  - Added `Tuple` import to `cli.py`
  - Added `List` import to `extended/runner.py`, `extended/metrics.py`
  - Added `Any` import to `i18n/__init__.py`
  - Fixed 27 type annotation issues (88 → 61 mypy errors, currently 85 with refactoring in progress)
  - Type annotations for `*args` and `**kwargs` in `t_format()`
  - Type annotations for empty lists/dicts in metrics collection
  - Type ignore comments for legitimate type compatibility issues

- **Auto-Update Script** 🔄
  - `examples/run_manifestguard.py` now auto-detects newer versions
  - Compares installed version vs a local development checkout
  - Auto-installs when dev version is newer
  - Flags: `--skip-install` (skip check), `--force-install` (force reinstall)
  - Smart version comparison (0.5.0 vs 0.6.0)
  - Standard dev path: configurable (no hard-coded local path)

### Fixed
- Fixed `Union` import missing in multiple modules causing NameError
- Fixed `metrics.` references in refactored helper functions (changed to parameter names)
- Fixed security recommendations wrongly placed in dependency function
- Fixed type annotation errors in `integration_test.py` with type ignore comments
- Fixed empty list type annotation in `_check_modern_patterns()`

### Technical Debt
- **F-018 Type Hints**: 85/88 mypy errors remaining (paused for complexity fix)
- Remaining complexity targets: `_log_recommendations()` (21), `_display_validation_results()` (18)

### Quality Metrics
- Test Coverage: **98.74%** (unchanged, excellent)
- Quality Score: **97.0/100** (unchanged)
- Complexity: Top function 54 → 39 (-28%)
- Recommendations: 3 total (1 Critical, 1 Medium, 1 Low)

### Documentation
- Updated F-018-PLAN.md with current progress
- Added refactoring notes to function docstrings
- Documented helper function responsibilities

### Developer Experience
- Improved error messages with traceback logging
- Better terminal output with auto-update notifications
- Clearer version comparison messages

---

## [1.2.0] - 2025-11-28

### Added
- **F-020: Documentation Standards (Sphinx)** ✅ COMPLETE
  - **98.6% docstring coverage** (344/349 items documented)
  - Sphinx documentation infrastructure with ReadTheDocs theme
  - Google-style docstring enforcement via pydocstyle
  - Complete API documentation generation with autodoc + napoleon
  - Interactive Sphinx HTML documentation (8 rst files, 1,500+ lines)
  - ReadTheDocs configuration (.readthedocs.yaml) ready for hosting
  - Comprehensive guides: installation, usage, configuration, contributing, architecture, changelog
  - API reference: models, validation, metrics, config, OpenAPI
  - Getting started tutorial with code examples
  - Documentation build automation (Makefile + make.bat)
  - README updated with documentation links and badges
  - All public classes 100% documented (109/109)
  - Public functions 97.9% documented (235/240)
  - Docstring coverage exceeds 90% target by 8.6%

- **F-019: API Contracts with Pydantic** ✅ COMPLETE (All 7 Tasks)
  - 16 Pydantic v2 models for API contracts (base, environment, validation, metrics, config)
  - OpenAPI 3.0.3 schema generation with `manifestguard schema` CLI command
  - JSON/YAML export support for OpenAPI schemas
  - 29 contract tests verifying API-schema compliance
  - 21 regression tests for critical validation paths
  - Complete model documentation with examples
  - Validation rules: string constraints, numeric bounds, path validation, XSS protection
  - FastAPI integration with automatic request/response validation
  - Response models on all API endpoints with proper error schemas
  - Comprehensive API documentation (README.md API section, OPENAPI.md guide)
  - Interactive Swagger UI and ReDoc documentation support
  - 150 total tests passing with 99.37% code coverage
  - Generated 1,902-line OpenAPI schema compatible with Swagger UI

## [Unreleased]

## [1.0.0] - 2025-11-28 🎉

### 🎯 MILESTONE: ManifestGuard Quality Coach 100% Complete!

This release completes **all 24 planned Quality Coach recommendations** across all priority levels:
- ✅ Critical Priority: 4/4 (100%)
- ✅ High Priority: 6/6 (100%)
- ✅ Medium Priority: 6/6 (100%)
- ✅ Low Priority: 8/8 (100%)

### Added
- **Low-Priority Recommendations (4 new)**: Advanced quality tracking features
  - **Baseline Tracking UI**: Visualizes multiple stored quality baselines
    - Detects `.manifestguard/baselines/*.json` with multiple baseline files
    - Triggers when >1 baseline exists but visualization is not enabled
    - Effort: 90 min, Impact: +5 points
    - Provides CLI commands: --show-trends, dashboard, --compare-to
  - **Trend Analysis**: Detects quality score regression over time
    - Reads `.manifestguard/metrics-history.json` with ≥5 measurements
    - Triggers if quality_score declined by 5+ points
    - Effort: 60 min, Impact: +5 points
    - Suggests trend monitoring, regression detection, baseline comparison
  - **Performance Profiling**: Identifies slow analysis operations
    - Checks `metrics.performance.total_analysis_ms > 5000` (>5 seconds)
    - Identifies bottlenecks: dependency_graph_ms >2s, rule_engine_ms >1s
    - Effort: 120 min, Impact: +6 points
    - Provides profiling tools: cProfile, py-spy, MANIFESTGUARD_PROFILE=1
  - **Memory Leak Detection**: Recommends memory profiling for large projects
    - Triggers when (direct_count + transitive_count) > 100 dependencies
    - Effort: 90 min, Impact: +5 points
    - Suggests memory_profiler, tracemalloc, pympler for leak detection

### Changed
- **Recommendation System**: All 24 recommendations now operational
  - Priority levels: CRITICAL (4), HIGH (6), MEDIUM (6), LOW (8)
  - Quality Score range: 0-100 (Coverage 40%, Security 30%, Dependencies 15%, Complexity 10%, Tests 5%)
  - Code examples and documentation links for all recommendations

### 🎊 Project Status
**"So gut war mein Code nie!"** - Vision achieved!
- 100% recommendation coverage (24/24)
- 319 tests passing (100%)
- Comprehensive i18n support (Phase 1: 75/237 strings)
- Production-ready Quality Coach system

## [0.9.0] - 2025-11-28

### Added
- **Low-Priority Recommendations (3 new)**: Quality improvement suggestions
  - **Modern Python Patterns**: Detects 281 modernization opportunities
    - Optional[X] → X | None (Python 3.10+ union syntax)
    - List[X] → list[X], Dict[K,V] → dict[K,V] (Python 3.9+ built-in generics)
    - Traditional classes → @dataclass decorator
    - if-elif chains → match/case statements (Python 3.10+)
    - Effort: 120 min, Impact: +6 points
    - Code examples: Complete before/after patterns for all modernizations
  - **SBOM Completeness**: Validates Software Bill of Materials license coverage
    - Triggers if >20% dependencies missing license information
    - Uses components_count and missing_licenses from SBOMMetrics
    - Effort: 30 min, Impact: +4 points
    - Suggests pip-licenses or scancode-toolkit for better detection
  - **CI/CD Integration**: Detects missing automation infrastructure
    - Checks for .github/workflows and .pre-commit-config.yaml
    - Triggers if neither automation system exists
    - Effort: 60 min, Impact: +7 points
    - Provides complete pre-commit config and GitHub Actions workflow templates
- **Helper Method**: `_check_modern_patterns()` with regex-based pattern detection (~80 lines)

### Changed
- **Low Priority Recommendations**: Now 50% complete (4/8)
  - ✅ py.typed marker
  - ✅ Modern Python Patterns (NEW)
  - ✅ SBOM Completeness (NEW)
  - ✅ CI/CD Integration (NEW)
  - ❌ Baseline Tracking UI
  - ❌ Trend Analysis
  - ❌ Performance Profiling
  - ❌ Memory Leak Detection

### Technical Details
- Added `_check_modern_patterns()`: Regex pattern detection for 6 modernization opportunities
- SBOM check: Uses existing SBOMMetrics (components_count, missing_licenses)
- CI/CD check: File system checks for .github/workflows and .pre-commit-config.yaml
- Total additions: ~220 lines of analysis and recommendation logic
- Recommendation count: 17 → 20 total (+3 Low)

## [0.8.0] - 2025-11-28

### Added
- **Weak Cryptographic Algorithm Detection (MEDIUM)**: Security-focused crypto analysis
  - Detects MD5, SHA-1, DES, 3DES, RC4, Blowfish usage
  - Regex patterns for `hashlib` and `PyCrypto`/`cryptography` modules
  - Triggers MEDIUM recommendation with modern alternatives
  - Effort: 45 min, Impact: +8 points
  - Code example: Migration from MD5/DES to SHA-256/AES-256-GCM
  - Recommendations:
    - Hashing: Use SHA-256, SHA-512, or BLAKE2b
    - Encryption: Use AES-256-GCM (AEAD cipher)
  - Tracks affected files (up to 5 files listed)
- **Ignore File Pattern Support**: Respects VCS ignore files during analysis
  - Loads patterns from: `.gitignore`, `.vsignore`, `.cvsignore`, `.svnignore`, `.hgignore`
  - Default patterns: `__pycache__`, `venv/`, `dist/`, `node_modules/`, etc.
  - Pattern matching: substring, directory (`/`), extension (`*.pyc`), wildcard (`*test`)
  - Applied to all analysis methods: type hints, documentation, style, crypto
  - Result: More accurate analysis (278 vs 298 functions - excludes ignored files)
  - Benefits:
    - No false positives from generated/vendor code
    - Respects project-specific ignore rules
    - Standard VCS ignore file compatibility

### Changed
- **Medium Priority Recommendations**: Now 100% complete (6/6)
  - ✅ Type Hints Detection
  - ✅ Documentation Coverage
  - ✅ PEP 8 Violations
  - ✅ Code Style Consistency
  - ✅ Outdated Dependencies
  - ✅ Weak Crypto Patterns (NEW)

### Technical Details
- Added `_check_weak_crypto()`: Regex-based pattern detection (~100 lines)
- Added `_load_ignore_patterns()`: Multi-file ignore pattern loader (~60 lines)
- Added `_should_skip_path()`: Path matching logic with glob support (~40 lines)
- Updated 3 analysis methods to use ignore patterns
- Total additions: ~200 lines of security and filtering logic

## [0.7.0] - 2025-11-28

### Added
- **Medium Priority Recommendations (4 new)**: Expanded Quality Coach with code quality metrics
  - **Type Hints Detection**: AST-based analysis, triggers at <60% coverage
    - Counts typed vs untyped functions, identifies files with low coverage
    - Effort: 60 min, Impact: +10 points
    - Code example: Shows before/after with proper type annotations
  - **Documentation Coverage**: Docstring analysis, triggers at <70% coverage
    - Analyzes functions/classes/methods for docstrings >10 chars
    - Effort: 90 min, Impact: +8 points
    - Code example: Shows Google-style docstring format
  - **PEP 8 Violations**: pycodestyle integration, triggers at >50 violations
    - Detects style violations with violation type breakdown
    - Effort: 30 min, Impact: +5 points
    - Code example: Shows black/autopep8 auto-fix commands
  - **Code Style Consistency**: Quote and indentation detection
    - Identifies mixed single/double quotes, tabs/spaces mixing
    - Effort: 45 min, Impact: +5 points
    - Code example: Shows consistent style configuration
- **Scope Restriction**: Analysis limited to src/ directory only
  - Excludes: test files, __pycache__, site-packages, venv, .venv
  - Prevents false positives from dependencies (43K → ~400 functions)
  - Fallback to workspace root if src/ doesn't exist
- **Helper Methods (4 new)**:
  - `_analyze_type_hints()`: AST parsing for function type annotations
  - `_analyze_documentation()`: Docstring completeness analysis
  - `_check_pep8_violations()`: Optional pycodestyle integration
  - `_check_style_consistency()`: Quote/indentation pattern detection
- **Enhanced Recommendations**:
  - All Medium recommendations include code_example with ❌/✅ patterns
  - guide_url links to best practices documentation
  - files_affected lists top 5 files needing attention
  - effort_minutes and impact_score for prioritization

### Technical Details
- Added ~300 lines of analysis code to metrics.py
- AST-based static analysis (no code execution)
- Error handling: Returns {} on failure, logs debug messages
- Optional dependency: pycodestyle (graceful degradation if not installed)
- Recommendation count: 13 → 17 total (+4 Medium)

## [0.6.0] - 2025-11-28

### Added
- **Quality Score Calculation (0-100)**: Real-time project quality assessment
  - Weighted scoring: Coverage (40%), Security (30%), Dependencies (15%), Complexity (10%), Tests (5%)
  - Formula: Base 100 - penalties + bonuses (Excellence >90% coverage, Type safety)
  - Visual display: "🎯 Quality Score: 71.4/100" with potential score projection
  - Exported to metrics-history.json for trend tracking
- **--verbose Flag**: Detailed Medium/Low priority recommendations
  - Default behavior: Show Critical/High only (collapsed Medium/Low)
  - With --verbose: Expand all priorities with effort/impact details
  - Usage: `manifestguard check --extended --verbose`
- **Enhanced Recommendation Display**:
  - Potential score projection: "🎯 Potential: 71.4 → 100.0/100"
  - Next steps include --verbose hint when Medium/Low exist
  - Quality-focused motivational messaging

### Fixed
- **i18n Module Resolution**: Fixed missing keys for cli.validation.running and cli.validation.no_issues
  - Added `module='cli'` parameter to t() calls
  - Resolved "i18n key missing" errors in check command
- **Quality Score Bonus Field**: Fixed AttributeError by using correct `has_py_typed` field
  - Changed from non-existent `type_hints_present` to `has_py_typed`
  - Type safety bonus now correctly applied (+2 points)

### Changed
- **show_recommendations Signature**: Now accepts `verbose: bool = False` parameter
  - Enables conditional expansion of Medium/Low priorities
  - Maintains backward compatibility with default False

## [0.5.2] - 2025-11-28

### Added
- **Test Coverage**: Comprehensive test suite for enhanced recommendation system
  - 21 new pytest tests covering recommendation dataclass, priority logic, display formatting
  - Tests for effort estimates (5-240 min), impact scores (0-100), code examples, guide URLs
  - Priority sorting validation (Critical > High > Medium > Low)
  - Display formatting tests (Critical/High expanded, Medium/Low collapsed)
  - Integration tests for JSON export and critical recommendation counting
  - Total test count: 285 → 319 tests (+34 tests, 0 failures)

### Changed
- **Test Philosophy**: Reinforced pytest-based testing (no unittest.TestCase)
  - Used pytest.mark.asyncio for async tests
  - Leveraged capsys fixture for stdout validation
  - Applied tmp_path fixture for filesystem operations
  - Test-layer integrity maintained: ManifestGuard is primarily a test layer, not just a coach

## [0.5.1] - 2025-11-27

### Fixed
- **Coverage Collection**: Fixed 0% coverage reporting when `.coverage` file doesn't exist
  - Added fallback to run `pytest --cov` automatically if no coverage data found
  - Improved coverage detection for projects like clone-ville
- **Code Quality**: Auto-fixed 235 ruff violations (60% reduction: 393 → 158)
  - Removed 205 blank line whitespace issues
  - Fixed 59 line-too-long violations
  - Various code style improvements

### Added
- **BPD Metric**: Bugs Per Day tracking from git commit history analysis
  - Categorizes bugfixes by severity (critical/major/minor)
  - Tracks by category (dashboard/api/packaging/tests/docs/other)
  - Exports to manifestguard-report.json and metrics-history.json
- **Documentation**: Comprehensive ruff integration guide (`docs/concept.ruff.en.md`)
- **Documentation**: Generic Python project recommendations (`docs/generic-recommendations.en.md`)
  - 10 modern patterns derived from clone-ville modernization
  - pyproject.toml migration, setuptools_scm, Black+Ruff, pytest best practices

## [0.5.0] - 2025-11-22

### Added
- Intelligent pre-push hook to validate builds only on protected branches.
- Comprehensive pre-commit hooks for code quality (black, ruff, mypy), security (detect-secrets), and commit message format (conventional-commits).
- User-friendly runner script (`run_manifestguard.py`) with rich console output.
- Detailed documentation for pre-commit hooks setup.
- Recommendation for `ruff` as a modern linter alternative in the project concept.

## [0.3.1] - 2025-11-21

### Added

- **Quick Check API - Simplified Top-Level Interface (ADR-010 Phase 2)**
  - `manifestguard.quickcheck` module: Simplified wrapper around `manifestguard.api.QuickCheck`
  - One-liner imports: `import manifestguard.quickcheck as qc`
  - Simplified function names:
    - `detect_project(path)` - Project type and feature detection
    - `recommend_tests(info)` - Test recommendations with priorities
    - `generate_config(info, tests)` - Config template generation
    - `merge_configs(existing, template)` - Config merging
    - `compare_configs(old, new)` - Config comparison
    - `validate_version(package)` - Version validation (x.y.z)
    - `validate_project_version(path)` - pyproject.toml/setup.py version validation
  - Singleton pattern for performance (one QuickCheck instance)
  - Complete API documentation in `AI-PYTHON-PROJECT-INSTRUCTIONS.md`

- **Version Validator - Core Module (Semantic Versioning)**
  - `manifestguard.core.VersionValidator` class: SemVer 2.0.0 validation
  - `VersionInfo` dataclass: major, minor, patch, prerelease, build metadata
  - Support for:
    - Basic versions: `1.0.0`, `0.3.1`
    - Prerelease: `1.0.0-alpha`, `1.0.0-beta.1`
    - Build metadata: `1.0.0+20130313144700`
    - Combined: `1.0.0-beta+exp.sha.5114f85`
  - Methods:
    - `validate_package(name)` - Validate installed package __version__
    - `validate_version(string)` - Validate version string format
    - `validate_project(path)` - Validate pyproject.toml/setup.py version
    - `parse_version(string)` - Parse version into components
    - `compare_versions(a, b)` - Compare two versions
  - Strict mode: Reject prerelease/build versions
  - Quick helper: `validate_package_version(name)` function
  - Integrated into `pre_dev_check.py` and `test_version_schema.py`

### Changed

- **AI Instructions Simplified**
  - Updated `AI-PYTHON-PROJECT-INSTRUCTIONS.md` with `manifestguard.quickcheck` examples
  - Shorter function names (detect_project vs detect_project_type)
  - One-liner examples for VS Code Extension integration
  - Fixed code example syntax errors (removed orphaned except block)

### Fixed

- Path handling in `QuickCheckCache.generate_cache_key()` - Now accepts both str and Path
- Code example in `AI-PYTHON-PROJECT-INSTRUCTIONS.md` line 203 (removed try-less except)

## [0.3.0] - 2025-11-20

### Added

- **Interface Discovery API (ADR-010 Analog)**
  - `InterfaceDiscovery` class: Machine-readable interface definitions with parameters, types, examples
  - `validate_call()`: Validate command parameters before execution (early error detection)
  - `IntegrationTestHelper`: Test helper for external projects (r4it_ai_cert_guard, r4it_ai_keep_clean_vs)
  - Enhanced `list-interfaces` command with `--validate` and `--category` options
  - OpenAPI 3.0 export support via `to_openapi()`
  - 7 CLI commands registered with full metadata (validation, security, meta, remediation categories)
  - `from_function()`: Create interface definitions from Python functions via introspection
  - External projects can now:
    1. Query available interfaces programmatically
    2. Validate calls before execution
    3. Run automated integration tests
    4. Get example calls and documentation
  - Example integration test: `python -m manifestguard.api.integration_test`
  - Fixes feedback loop for dependent projects

- **Comprehensive Test Suite for Phase 1 API (160+ tests)**
  - `tests/api/test_quick_check.py`: 40+ tests for QuickCheck API (feature detection, recommendations, config templates)
  - `tests/api/test_public_api.py`: 50+ tests for ManifestGuardAPI (validation, configuration, baseline, reporting, licensing, sessions, workflows)
  - `tests/api/test_workflows.py`: 40+ tests for Workflow system (registry, execution, validation)
  - `tests/cli/test_quick_check_command.py`: 30+ tests for CLI integration
  - Total: 160+ test cases covering >80% of planned v0.3.0 API
  - Based on implementation steps from `docs/todo.concept.python_gui.steps.en.md`

- **Python GUI Planning Documentation (4 comprehensive documents)**
  - `docs/concept.python_gui.en.md` (12k tokens): Architecture, API design, feature parity with VS Extension
  - `docs/todo.concept.python_gui.en.md` (8k tokens): 5 phases with release checklists
  - `docs/todo.concept.python_gui.steps.en.md` (14k tokens): Implementation steps with complete code examples
  - `docs/roadmap.python_gui.en.md`: Timeline, priorities, success metrics (v0.3.0 → v0.7.0)
  - `docs/api.interface_discovery.integration_guide.en.md` (444 lines): Complete integration guide for external projects
  - Based on VS Extension public API (48 commands across 10 categories)
  - Planned GUI variants: Qt/Tkinter Desktop, FastAPI Web, Rich TUI, Public API
  - Phase 1 (v0.3.0): Core API - quick_check, workflows, public API (Target: 2025-11-30)

### Added (from previous unreleased)

- **CLI Interface Discovery (AI Interface Discovery)**
  - `list-interfaces` command: JSON output of all available commands, options, and arguments
  - Enables external apps to programmatically discover CLI capabilities
  - Critical for AI-powered tools like r4it_ai_git_control
  - Output includes version, command structure, options with types/defaults, deprecation flags

- **Test Discovery & Configuration Management**
  - `list-tests` command: Show all 12 available tests across 4 categories (Core, Extended, Quality, Baseline)
  - `list-tests --json` for programmatic consumption
  - `show-config` command: Display effective configuration from manifestguard.json + defaults
  - `show-config --json` for structured output
  - Shows Extended Test Mode status for all 9 metric categories

- **Cyclomatic Complexity Analysis**
  - Historical: initial integration with Radon for McCabe complexity measurement
  - Current default: built-in AST-based analyzer (mgpy-analyzer); Radon remains optional as a compatibility engine
  - ComplexityAnalyzer with configurable threshold (default: 10)
  - Complexity grades A (1-5) to F (41+) following a Radon-compatible McCabe scale
  - Integration into Extended Test Mode (9th metric category)
  - Priority-based recommendations (critical >20, high >threshold)
  - Local analysis (privacy-compliant, no external transmission)
  - 8 comprehensive unit tests with 100% coverage
  - violations_count property for convenient access

### Fixed

- **Backward Compatibility**
  - Added deprecated `--format` option to check command
  - Maps `--format json` to `--report manifestguard-report.json`
  - Shows clear deprecation warning to stderr
  - Visible in --help for interface discovery by external apps
  - Fixes breaking change affecting r4it_ai_git_control and other external tools

- **Audit API Compatibility**
  - Added `rule_id` parameter alias for `Audit.record()` method
  - Maintains backward compatibility with external integrations (e.g., r4it_ai_cert_guard)
  - `rule_id` takes precedence if both `rule_id` and `rule_code` are provided
  - Enhanced test coverage for parameter aliasing

## [0.2.0] - 2025-11-20

### Added

- **Extended Test Mode Implementation (v0.2.0)**
  - Comprehensive metrics collection across 8 categories
  - Coverage, dependency health, security, SBOM, packaging, performance, policy, and license analysis
  - AI-powered recommendations with priority levels
  - Baseline storage and comparison for regression detection
  - Trend analysis for quality metrics over time
  - Async execution with progress callbacks

### Changed

- **Documentation Enhancements**
  - Comprehensive docstrings for all Extended Test Mode modules
  - Google-style documentation with examples and usage patterns
  - Enhanced module-level documentation for metrics.py, runner.py, baseline.py
  - Added privacy notes and performance information

### Fixed

- **Deprecation Warnings**
  - Replaced `datetime.utcnow()` with `datetime.now(timezone.utc)` (10 occurrences)
  - Replaced `asyncio.get_event_loop()` with `asyncio.get_running_loop()`

- **Test Suite Improvements**
  - Fixed utility test failures (capture_output, run_cli_command, create_test_license)
  - Added graceful PyJWT skip for optional dependency
  - Installed missing dependencies (pytest-asyncio, watchdog, fastapi, PyNaCl)
  - All 28/29 tests passing (1 skipped for optional dependency)

## [0.1.1] - 2025-01-14

### Changed

- **Code Quality Improvements**
  - Comprehensive linting cleanup (393 → 0 ruff errors)
  - Fixed unused imports, type annotations, and code style issues
  - Updated pyproject.toml to use modern `tool.ruff.lint` configuration
  - Removed broken debug files (bad_debug.py, test_hook.py)
  - Fixed naming conflicts (format → format_, EnvironmentError, etc.)
  - Improved exception handling patterns
  - Standardized code formatting with Black across entire codebase

- **Configuration Updates**
  - Migrated ruff settings to new `lint` section format
  - Added comprehensive per-file ignore rules for test files
  - Enhanced .gitignore with .clutchpoint_history/ exclusion

## [0.1.0] - 2025-11-19

### Added

- **Shared AI Preferences** (`manifestguard.ai.shared_preferences`)
  - Centralized AI provider configuration (Ollama, OpenAI-compatible)
  - Multi-source configuration resolution (env vars → manifestguard.json → defaults)
  - Provider abstraction with smart defaults (Ollama: qwen2.5:7b, OpenAI: gpt-4)
  - Secure keyring-based API key storage with graceful fallbacks
  - Deprecation warnings for legacy `manifestguard.ai.*` settings
  - Migration path to `r4it.ai.shared.*` namespace

- **AI Capabilities & Workflows** (`manifestguard.ai.capabilities`)
  - Capability declaration system (network-access, fs.write, secrets, exec)
  - Workflow orchestration for AI agents (testing, audit, diagnostics, etc.)
  - Comprehensive validation (privileged items, rate limits, consent requirements)
  - Standard capability and workflow templates
  - JSON schema support for capabilities.json

- **Core Components Ported from VS Code Extension**
  - ConfigurationService: Hierarchical settings with access levels (strict/balanced/permissive)
  - RuleRegistry: Centralized rule metadata with 25+ predefined rules
  - Enhanced Logger: OutputChannel pattern with configurable levels
  - WorkflowService: Consent-based execution with security gating
  - Python Version Check: Feature flags for Python 3.8-3.12+

- **Environment Management**
  - Full CRUD API for environment configuration
  - i18n support (en, fr, de, lb, tr) with fallback mechanism
  - Audit logging and security integration
  - FastAPI integration with middleware

- **Licensing System**
  - License verification (Ed25519 signatures)
  - Token storage with keyring
  - Feature unlocking by tier (Trial/Pro/Team/Enterprise)
  - Time window validation with expiration checks
  - Renewal validation (same order, later expiration)

### Infrastructure

- Test suite: 188 tests (185 passing, 3 skipped)
- Code coverage: 88%+ for new modules
- Python support: 3.8-3.12+
- Dependencies: tomlkit, click, pydantic, packaging, watchdog, PyNaCl

### Documentation

- Shared AI preferences implementation summary
- Capabilities & workflows concept documentation
- Migration guides (legacy → shared namespace)
- Provider configuration examples

## [0.0.1] - 2025-11-15

### Added

- Initial project structure
- Basic licensing infrastructure
- Core validation modules
- i18n framework

[0.1.0]: https://github.com/timejunky/r4it_manifest_guard_py/compare/v0.0.1...v0.1.0
[0.0.1]: https://github.com/timejunky/r4it_manifest_guard_py/releases/tag/v0.0.1
