import subprocess
from pathlib import Path

from setuptools import setup, find_packages
from setuptools.command.build_py import build_py as _build_py

ROOT = Path(__file__).parent.resolve()
PKG_DIR = ROOT / 'dl_py2f'
SRC_DIR = ROOT / 'dl_py2f'
BUILD_LIB_DIR = ROOT / 'build'   # arbitrary name for CMake build dir


class build_py(_build_py):
    '''
    Custom build_py that first builds libdl_py2f.so via CMake
    and copies it into dl_py2f/ so it ends up inside the wheel.
    '''

    def run(self):
        self.build_dl_py2f_lib()
        super().run()

    def build_dl_py2f_lib(self):
        # Ensure build directory exists
        BUILD_LIB_DIR.mkdir(exist_ok=True)

        # ---- 1. Configure CMake ----
        # Adapt these commands to match your existing build.
        # For example, if your current script does:
        #   cmake -B build -S . -DCMAKE_BUILD_TYPE=Release
        #   cmake --build build --target dl_py2f
        # you can do the same here:
        cmake_config_cmd = [
            'cmake',
            '-S', str(SRC_DIR),
            '-B', str(BUILD_LIB_DIR),
            '-DCMAKE_BUILD_TYPE=Release',
        ]
        subprocess.run(cmake_config_cmd, check=True)

        # ---- 2. Build the library ----
        cmake_build_cmd = [
            'cmake',
            '--build', str(BUILD_LIB_DIR),
            '--target', 'dl_py2f',
            '--config', 'Release',
        ]
        subprocess.run(cmake_build_cmd, check=True)

        # ---- 3. Verify build outputs exist in package directory ----
        # CMakeLists.txt outputs .so and .mod directly to dl_py2f/
        built_lib = PKG_DIR / 'libdl_py2f.so'
        if not built_lib.exists():
            raise RuntimeError(f'Could not find {built_lib} after CMake build')
        print(f'Built library: {built_lib}')

        built_mods = list(PKG_DIR.glob('*.mod'))
        if not built_mods:
            raise RuntimeError('No .mod file could be found in package directory')
        for mod in built_mods:
            print(f'Built module: {mod}')

setup(name='dl_py2f',
      version='1.3.0',
      description='DL_PY2F: A library for Python-Fortran interoperability',
      long_description=open('dl_py2f/README.md').read(),
      long_description_content_type='text/markdown',
      author='You Lu',
      author_email='you.lu@stfc.ac.uk',
      url='https://github.com/stfc/dl_py2f',
      license='GNU Lesser General Public License v3.0',
      packages=find_packages(),
      include_package_data=True,
      package_data={'dl_py2f': ['*.so', '*.mod']},
      python_requires='>=3.9',
      install_requires=['numpy>=1.26'],
      cmdclass={'build_py': build_py})

