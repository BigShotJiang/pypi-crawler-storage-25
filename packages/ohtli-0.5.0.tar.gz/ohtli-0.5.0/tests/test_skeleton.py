"""
tests/test_skeleton.py
"""

import numpy as np
import pytest
from beta_skeletons import (
    adjacency_matrix,
    build_graph,
    point_in_lune,
    is_beta_neighbor,
    relative_asymmetry,
    control_value,
)


# ── geometría ──────────────────────────────────────────────────────────────

def test_point_in_lune_center_is_inside():
    """El punto medio entre p1 y p2 está dentro de la luna para beta=2."""
    p1 = np.array([0.0, 0.0])
    p2 = np.array([4.0, 0.0])
    midpoint = np.array([2.0, 0.0])
    assert point_in_lune(midpoint, p1, p2, beta=2.0)


def test_point_in_lune_far_point_is_outside():
    """Un punto lejano no está en la luna."""
    p1 = np.array([0.0, 0.0])
    p2 = np.array([1.0, 0.0])
    far = np.array([10.0, 10.0])
    assert not point_in_lune(far, p1, p2, beta=1.0)


def test_identical_points_raises():
    from beta_skeletons.geometry import _lune_centers_and_radius
    with pytest.raises(ValueError):
        _lune_centers_and_radius(np.array([0.0, 0.0]), np.array([0.0, 0.0]), beta=1.0)


# ── matriz de adyacencia ──────────────────────────────────────────────────

def test_adjacency_matrix_is_symmetric():
    coords = np.array([[0, 0], [1, 0], [2, 0], [1, 1]], dtype=float)
    adj = adjacency_matrix(coords, beta=1.0)
    np.testing.assert_array_equal(adj, adj.T)


def test_adjacency_matrix_no_self_loops():
    coords = np.array([[0, 0], [1, 0], [2, 0]], dtype=float)
    adj = adjacency_matrix(coords, beta=1.0)
    assert np.all(np.diag(adj) == 0)


def test_collinear_points_gabriel():
    """Para tres puntos colineales, solo los adyacentes deben conectarse (beta=1)."""
    coords = np.array([[0, 0], [1, 0], [2, 0]], dtype=float)
    adj = adjacency_matrix(coords, beta=1.0)
    assert adj[0, 1] == 1
    assert adj[1, 2] == 1
    assert adj[0, 2] == 0


def test_invalid_beta_raises():
    coords = np.array([[0, 0], [1, 0]], dtype=float)
    with pytest.raises(ValueError):
        adjacency_matrix(coords, beta=-1.0)


# ── grafo ─────────────────────────────────────────────────────────────────

def test_build_graph_node_count():
    coords = np.array([[0, 0], [1, 0], [2, 0]], dtype=float)
    G = build_graph(coords, beta=1.0)
    assert G.number_of_nodes() == 3


def test_build_graph_with_labels():
    coords = np.array([[0, 0], [1, 0]], dtype=float)
    G = build_graph(coords, beta=1.0, labels=["A", "B"])
    assert G.nodes[0]["label"] == "A"
    assert G.nodes[1]["label"] == "B"


# ── métricas ──────────────────────────────────────────────────────────────

def test_relative_asymmetry_keys():
    coords = np.array([[0, 0], [1, 0], [2, 0]], dtype=float)
    G = build_graph(coords, beta=1.0)
    ra = relative_asymmetry(G)
    assert set(ra.keys()) == set(G.nodes())


def test_control_value_keys():
    coords = np.array([[0, 0], [1, 0], [2, 0]], dtype=float)
    G = build_graph(coords, beta=1.0)
    cv = control_value(G)
    assert set(cv.keys()) == set(G.nodes())


def test_isolated_node_control_value_is_zero():
    import networkx as nx
    G = nx.Graph()
    G.add_node(0)
    G.add_node(1)
    G.add_edge(1, 2)
    cv = control_value(G)
    assert cv[0] == 0.0
