[![PyPI version](https://badge.fury.io/py/justin_furuness.svg)](https://badge.fury.io/py/justin_furuness)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/justin_furuness)](https://pypi.org/project/justin_furuness/)
![Linux](https://img.shields.io/badge/os-Linux-blue.svg)
![macOS Intel](https://img.shields.io/badge/os-macOS_Intel-lightgrey.svg)
![macOS ARM](https://img.shields.io/badge/os-macOS_ARM-lightgrey.svg)

# Ohtli

Librería para el cálculo y visualización de β-esqueletos para el modelado de redes de conexión entre sitios arqueológicos.

## Instalación

```bash
pip install ohtli
```

O en modo desarrollo:

```bash
git clone https://github.com/tu-usuario/ohtli.git
cd ohtli
pip install -e ".[dev]"
```

## Uso básico

```python
import numpy as np
from ohtli import adjacency_matrix, build_graph, plot_skeleton
from ohtli import relative_asymmetry, control_value, plot_metric_bars
from ohtli.datasets import load_metro_cdmx

coords = np.array([[0,0],[1,0],[2,0],[1,1]], dtype=float)
names  = ["A", "B", "C", "D"]

# Matriz de adyacencia
adj = adjacency_matrix(coords, beta=1.0)

# Grafo de NetworkX
G = build_graph(coords, beta=2.0, labels=names)

# Visualización
ax, G = plot_skeleton(coords, beta=1.0, labels=names)

# Métricas
ra = relative_asymmetry(G)
cv = control_value(G)
plot_metric_bars(ra, metric_name="Asimetría relativa")

metro  = load_metro_cdmx()
coords = metro["coords"]
names  = metro["names"]
adj    = metro["adj"]
lines  = metro["lines"]
```

## Estructura del paquete

```
ohtli/
├── geometry.py   # cálculo de lunas y vecindades
├── skeleton.py   # matriz de adyacencia y construcción del grafo
├── metrics.py    # asimetría relativa y valor de control
└── viz.py        # visualizaciones
```

## Referencia

Kirkpatrick, D. G. y Radke, J. D. (1985).
*A Framework for Computational Morphology*.
Computational Geometry, pp. 217-248.
