"""
datasets.py
-----------
Datos de ejemplo incluidos en el paquete.
"""

import json
from importlib.resources import files
import numpy as np
import pandas as pd


def load_metro_cdmx() -> dict:
    """
    Carga los datos del Metro CDMX incluidos en el paquete.

    Retorna
    -------
    dict con las siguientes claves:

    coords : np.ndarray (n, 2)  — [longitud, latitud]
    names  : list de str        — nombres originales
    names_norm : list de str    — nombres normalizados
    adj    : np.ndarray (n, n)  — matriz de adyacencia
    lines  : dict               — {station_norm: [linea, ...]}

    Ejemplo
    -------
    >>> from ohtli.datasets import load_metro_cdmx
    >>> metro = load_metro_cdmx()
    >>> metro["coords"].shape
    (163, 2)
    """
    data = files("ohtli").joinpath("data")

    # coordenadas
    df = pd.read_csv(str(data.joinpath("metro_cdmx_stations.csv")))
    names = df["estacion"].tolist()
    names_norm = df["estacion_norm"].tolist()
    coords = df[["lng", "lat"]].values

    # adyacencia
    with open(str(data.joinpath("metro_cdmx_adjacency.json")), encoding="utf-8") as f:
        adj_dict = json.load(f)

    n = len(names_norm)
    idx = {name: i for i, name in enumerate(names_norm)}
    adj = np.zeros((n, n), dtype=int)
    for src, neighbors in adj_dict.items():
        if src not in idx:
            continue
        for tgt in neighbors:
            if tgt in idx:
                i, j = idx[src], idx[tgt]
                adj[i, j] = 1
                adj[j, i] = 1

    # líneas
    with open(str(data.joinpath("metro_cdmx_lines.json")), encoding="utf-8") as f:
        lines = json.load(f)

    return {
        "coords": coords,
        "names": names,
        "names_norm": names_norm,
        "adj": adj,
        "lines": lines,
    }
