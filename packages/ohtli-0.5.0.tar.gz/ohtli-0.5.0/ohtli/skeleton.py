"""
skeleton.py
-----------
Algoritmo de fuerza bruta para calcular β-esqueletos.
Complejidad temporal: O(n^3).

Referencia:
    Kirkpatrick, D. G. y Radke, J. D. (1985).
    A Framework for Computational Morphology.
    Computational Geometry, pp. 217-248.
"""

import numpy as np
import networkx as nx

from .geometry import is_beta_neighbor


def adjacency_matrix(coords: np.ndarray, beta: float = 1.0) -> np.ndarray:
    """
    Calcula la matriz de adyacencia del β-esqueleto de un conjunto
    de puntos mediante fuerza bruta.

    Para cada par (i, j), verifica si la luna de influencia está vacía.
    La matriz resultante es simétrica y sin auto-lazos.

    Complejidad: O(n^3)

    Parámetros
    ----------
    coords : np.ndarray de forma (n, 2)
        Coordenadas de los n puntos en el plano.
    beta   : float > 0
        Parámetro que controla el tamaño de la región de influencia.
        beta = 1  → Grafo de Gabriel
        beta = 2  → Grafo de vecindad relativa (RNG)

    Retorna
    -------
    np.ndarray de forma (n, n), dtype int
        Matriz de adyacencia binaria y simétrica.

    Ejemplos
    --------
    >>> import numpy as np
    >>> from beta_skeletons import adjacency_matrix
    >>> coords = np.array([[0,0],[1,0],[2,0]])
    >>> adjacency_matrix(coords, beta=1.0)
    array([[0, 1, 0],
           [1, 0, 1],
           [0, 1, 0]])
    """
    coords = np.asarray(coords, dtype=float)
    if coords.ndim != 2 or coords.shape[1] != 2:
        raise ValueError("coords debe tener forma (n, 2).")
    if beta <= 0:
        raise ValueError("beta debe ser estrictamente positivo.")

    n = len(coords)
    matrix = np.zeros((n, n), dtype=int)

    for i in range(n):
        for j in range(i + 1, n):
            if is_beta_neighbor(coords, i, j, beta):
                matrix[i, j] = 1
                matrix[j, i] = 1

    return matrix


def build_graph(
    coords: np.ndarray,
    beta: float = 1.0,
    labels: list | None = None,
) -> nx.Graph:
    """
    Construye el β-esqueleto como un grafo de NetworkX.

    Cada nodo almacena su posición ('pos') y, opcionalmente,
    su etiqueta ('label').

    Parámetros
    ----------
    coords : np.ndarray de forma (n, 2)
    beta   : float > 0
    labels : list de str, opcional
        Nombres de los nodos. Si es None se usan índices enteros.

    Retorna
    -------
    nx.Graph
        Grafo con atributos 'pos' y 'label' en cada nodo.
    """
    coords = np.asarray(coords, dtype=float)
    n = len(coords)

    if labels is not None and len(labels) != n:
        raise ValueError("labels debe tener la misma longitud que coords.")

    adj = adjacency_matrix(coords, beta=beta)
    G = nx.Graph()

    for i, (x, y) in enumerate(coords):
        G.add_node(i, pos=(x, y), label=labels[i] if labels is not None else str(i))

    for i in range(n):
        for j in range(i + 1, n):
            if adj[i, j] == 1:
                G.add_edge(i, j)

    return G
