"""
metrics.py
----------
Métricas de análisis sobre grafos de β-esqueletos.

Incluye:
    - Asimetría relativa (RA) por nodo
    - Valor de control por nodo
"""

import networkx as nx


def relative_asymmetry(G: nx.Graph) -> dict:
    """
    Calcula la asimetría relativa (RA) para cada nodo del grafo.

    La RA mide la centralidad de un nodo en términos de profundidad
    media respecto al resto de nodos del grafo.

    Fórmula:
        RA_i = 2 * (MD_i - 1) / (n - 2)

    donde MD_i es la profundidad media del nodo i (media de las
    longitudes de caminos más cortos hacia todos los demás nodos).

    Parámetros
    ----------
    G : nx.Graph
        Grafo conectado.

    Retorna
    -------
    dict : {nodo: valor_RA}

    Notas
    -----
    Para grafos desconectados, los nodos sin camino hacia algún otro
    nodo tendrán RA indefinida. Se recomienda verificar conectividad
    antes de aplicar esta métrica.
    """
    n = G.number_of_nodes()
    if n < 3:
        return {node: 0.0 for node in G.nodes()}

    ra = {}
    for node in G.nodes():
        lengths = nx.single_source_shortest_path_length(G, node)
        total_depth = sum(d for target, d in lengths.items() if target != node)
        md = total_depth / (n - 1)
        ra[node] = 2 * (md - 1) / (n - 2)

    return ra


def control_value(G: nx.Graph) -> dict:
    """
    Calcula el valor de control para cada nodo del grafo.

    El valor de control de un nodo i es la suma de los inversos
    del grado de cada uno de sus vecinos:

        CV_i = sum_{j ∈ N(i)} 1 / deg(j)

    Un nodo con alto valor de control está conectado a vecinos
    de bajo grado, lo que le otorga mayor influencia estructural.

    Parámetros
    ----------
    G : nx.Graph

    Retorna
    -------
    dict : {nodo: valor_control}
    """
    cv = {}
    for node in G.nodes():
        neighbors = list(G.neighbors(node))
        if not neighbors:
            cv[node] = 0.0
        else:
            cv[node] = sum(1 / G.degree(nb) for nb in neighbors)
    return cv
