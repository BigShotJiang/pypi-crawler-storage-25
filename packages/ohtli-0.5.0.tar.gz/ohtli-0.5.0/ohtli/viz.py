"""
viz.py
------
Funciones de visualización para β-esqueletos y sus métricas.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import networkx as nx
from matplotlib.patches import Circle
from adjustText import adjust_text

from .geometry import _lune_centers_and_radius
from .skeleton import build_graph


def plot_points(
    coords: np.ndarray,
    labels: list | None = None,
    ax: plt.Axes | None = None,
    title: str = "Conjunto de puntos",
) -> plt.Axes:
    """
    Grafica un conjunto de puntos con etiquetas opcionales.

    Parámetros
    ----------
    coords : np.ndarray de forma (n, 2)
    labels : list de str, opcional
    ax     : plt.Axes, opcional — si None se crea una figura nueva
    title  : str

    Retorna
    -------
    plt.Axes
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 10))

    ax.scatter(coords[:, 0], coords[:, 1], color="steelblue", s=50, zorder=5)

    if labels is not None:
        texts = [ax.text(x, y, labels[i], fontsize=8)
                 for i, (x, y) in enumerate(coords)]
        adjust_text(
            texts, ax=ax,
            arrowprops=dict(arrowstyle="->", color="gray", lw=0.5),
            expand_points=(1.2, 1.2),
        )

    ax.set_xlabel("Longitud")
    ax.set_ylabel("Latitud")
    ax.set_title(title)
    ax.axis("equal")
    ax.grid(True)
    return ax


def plot_lune(
    coords: np.ndarray,
    i: int,
    j: int,
    beta: float = 1.0,
    labels: list | None = None,
    ax: plt.Axes | None = None,
) -> plt.Axes:
    """
    Visualiza la luna de influencia del par (i, j) para un beta dado,
    clasificando los puntos restantes según si caen dentro o fuera.

    Parámetros
    ----------
    coords : np.ndarray de forma (n, 2)
    i, j   : int — índices del par a visualizar
    beta   : float > 0
    labels : list de str, opcional
    ax     : plt.Axes, opcional

    Retorna
    -------
    plt.Axes
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 10))

    p1, p2 = coords[i], coords[j]
    center1, center2, r = _lune_centers_and_radius(p1, p2, beta)
    n = len(coords)

    in_lune, out_lune = [], []
    for k in range(n):
        if k in (i, j):
            continue
        pk = coords[k]
        inside = (np.linalg.norm(pk - center1) < r and
                  np.linalg.norm(pk - center2) < r)
        (in_lune if inside else out_lune).append((pk, k))

    if out_lune:
        pts = np.array([p for p, _ in out_lune])
        ax.scatter(pts[:, 0], pts[:, 1], color="lightgray",
                   label="Fuera de la luna", zorder=3)

    if in_lune:
        pts = np.array([p for p, _ in in_lune])
        ax.scatter(pts[:, 0], pts[:, 1], color="steelblue",
                   label="Dentro de la luna", zorder=4)

    ax.scatter([p1[0], p2[0]], [p1[1], p2[1]],
               color="crimson", zorder=5, label="Par evaluado")
    ax.plot([p1[0], p2[0]], [p1[1], p2[1]], "k--", alpha=0.4)

    name_i = labels[i] if labels else str(i)
    name_j = labels[j] if labels else str(j)
    offset = r * 0.03
    ax.text(p1[0] + offset, p1[1] + offset, name_i, fontsize=9)
    ax.text(p2[0] + offset, p2[1] + offset, name_j, fontsize=9)

    ax.add_patch(Circle(center1, r, color="steelblue",
                        fill=False, linestyle="--",
                        label=f"Disco de {name_i}"))
    ax.add_patch(Circle(center2, r, color="seagreen",
                        fill=False, linestyle="--",
                        label=f"Disco de {name_j}"))

    ax.set_xlabel("Longitud")
    ax.set_ylabel("Latitud")
    ax.set_title(f"Luna β = {beta}  —  '{name_i}' y '{name_j}'")
    ax.axis("equal")
    ax.grid(True)
    ax.legend(fontsize=8)
    return ax


def plot_skeleton(
    coords: np.ndarray,
    beta: float = 1.0,
    labels: list | None = None,
    node_color: str | list = "skyblue",
    cmap=None,
    colorbar_label: str | None = None,
    ax: plt.Axes | None = None,
    title: str | None = None,
) -> tuple[plt.Axes, nx.Graph]:
    """
    Calcula y grafica el β-esqueleto.

    Parámetros
    ----------
    coords         : np.ndarray de forma (n, 2)
    beta           : float > 0
    labels         : list de str, opcional
    node_color     : str o list — color fijo o lista de valores numéricos
    cmap           : colormap de matplotlib, opcional
    colorbar_label : str, opcional — título de la barra de color
    ax             : plt.Axes, opcional
    title          : str, opcional

    Retorna
    -------
    (plt.Axes, nx.Graph)
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(12, 12))

    G = build_graph(coords, beta=beta, labels=labels)
    pos = nx.get_node_attributes(G, "pos")
    node_labels = nx.get_node_attributes(G, "label")

    draw_kwargs = dict(
        pos=pos, ax=ax, with_labels=False,
        node_size=100, edge_color="gray",
    )

    if cmap is not None and isinstance(node_color, (list, np.ndarray)):
        norm = plt.Normalize(vmin=min(node_color), vmax=max(node_color))
        draw_kwargs.update(node_color=node_color, cmap=cmap)
        sm = cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        cbar = plt.colorbar(sm, ax=ax, shrink=0.7)
        if colorbar_label:
            cbar.set_label(colorbar_label)
    else:
        draw_kwargs["node_color"] = node_color

    nx.draw(G, **draw_kwargs)

    if labels is not None:
        texts = [ax.text(pos[i][0], pos[i][1], node_labels[i], fontsize=8)
                 for i in G.nodes()]
        adjust_text(
            texts,
            arrowprops=dict(arrowstyle="->", color="gray", lw=0.5),
            expand_points=(1.2, 1.2),
        )

    ax.set_title(title or f"β-esqueleto (β = {beta})")
    ax.axis("equal")
    ax.grid(True)
    return ax, G


def plot_metric_bars(
    metric_values: dict,
    metric_name: str = "Métrica",
    ax: plt.Axes | None = None,
) -> plt.Axes:
    """
    Grafica un diagrama de barras de una métrica por nodo.

    Parámetros
    ----------
    metric_values : dict {nodo: valor}
    metric_name   : str — nombre de la métrica para etiquetas
    ax            : plt.Axes, opcional

    Retorna
    -------
    plt.Axes
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(20, 6))

    nodes, values = zip(*sorted(metric_values.items()))
    ax.bar(nodes, values)
    ax.set_xticks(nodes)
    ax.set_xlabel("Nodo")
    ax.set_ylabel(metric_name)
    ax.set_title(f"{metric_name} por nodo")
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    return ax
