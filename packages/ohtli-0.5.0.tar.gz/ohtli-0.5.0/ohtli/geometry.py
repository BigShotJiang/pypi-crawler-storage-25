"""
geometry.py
-----------
Funciones geométricas para el cálculo de β-esqueletos.
Implementa la definición de Kirkpatrick y Radke (1985) para
vecindades tipo luna (lune-based neighbourhoods).
"""

import numpy as np


def _lune_centers_and_radius(p1: np.ndarray, p2: np.ndarray, beta: float):
    """
    Calcula los centros y radio de los dos discos que definen
    la luna de influencia del par (p1, p2) para un valor beta dado.

    Para beta >= 1:
        radio = beta * d(p1, p2) / 2
        centros desplazados hacia el interior del segmento.

    Para beta < 1:
        radio = d(p1, p2) / (2 * beta)
        centros en p1 y p2.

    Parámetros
    ----------
    p1, p2 : np.ndarray de forma (2,)
    beta   : float > 0

    Retorna
    -------
    center1, center2 : np.ndarray de forma (2,)
    r                : float
    """
    d = np.linalg.norm(p2 - p1)
    if d == 0:
        raise ValueError("Los puntos p1 y p2 son idénticos.")
    if beta <= 0:
        raise ValueError("beta debe ser estrictamente positivo.")

    if beta >= 1:
        r = beta * d / 2
        direction = (p2 - p1) / d
        center1 = p1 + (1 - beta / 2) * (p2 - p1)
        center2 = p2 + (1 - beta / 2) * (p1 - p2)
    else:
        r = d / (2 * beta)
        center1 = p1.copy()
        center2 = p2.copy()

    return center1, center2, r


def point_in_lune(pk: np.ndarray, p1: np.ndarray, p2: np.ndarray, beta: float) -> bool:
    """
    Determina si el punto pk está en el interior de la luna
    de influencia del par (p1, p2) para el parámetro beta.

    Un punto está en la luna si y solo si está dentro de
    ambos discos simultáneamente (intersección estricta).

    Parámetros
    ----------
    pk     : np.ndarray de forma (2,) — punto a evaluar
    p1, p2 : np.ndarray de forma (2,) — par de puntos
    beta   : float > 0

    Retorna
    -------
    bool : True si pk está en el interior de la luna
    """
    center1, center2, r = _lune_centers_and_radius(p1, p2, beta)
    return (np.linalg.norm(pk - center1) < r and
            np.linalg.norm(pk - center2) < r)


def is_beta_neighbor(coords: np.ndarray, i: int, j: int, beta: float) -> bool:
    """
    Determina si los puntos i y j son β-vecinos en el conjunto coords,
    es decir, si la luna de influencia del par (i, j) está vacía.

    Parámetros
    ----------
    coords : np.ndarray de forma (n, 2)
    i, j   : int — índices del par a evaluar
    beta   : float > 0

    Retorna
    -------
    bool : True si la luna está vacía (i y j son β-vecinos)
    """
    p1, p2 = coords[i], coords[j]
    n = len(coords)
    for k in range(n):
        if k == i or k == j:
            continue
        if point_in_lune(coords[k], p1, p2, beta):
            return False
    return True
