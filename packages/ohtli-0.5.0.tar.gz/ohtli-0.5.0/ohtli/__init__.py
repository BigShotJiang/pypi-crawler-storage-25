"""
beta_skeletons
==============
Librería para el cálculo y visualización de β-esqueletos.

Algoritmo de fuerza bruta — O(n^3).

Referencia principal:
    Kirkpatrick, D. G. y Radke, J. D. (1985).
    A Framework for Computational Morphology.
    Computational Geometry, pp. 217-248.

Uso básico
----------
>>> import numpy as np
>>> from ohtli import adjacency_matrix, build_graph
>>> coords = np.array([[0,0],[1,0],[2,0],[1,1]])
>>> adj = adjacency_matrix(coords, beta=1.0)
>>> G   = build_graph(coords, beta=2.0)
"""

from .skeleton import adjacency_matrix, build_graph
from .geometry import point_in_lune, is_beta_neighbor
from .metrics import relative_asymmetry, control_value
from .viz import plot_points, plot_lune, plot_skeleton, plot_metric_bars
from .datasets import load_metro_cdmx

# print("Cargando la librería ohtli...")

__all__ = [
    "adjacency_matrix",
    "build_graph",
    "point_in_lune",
    "is_beta_neighbor",
    "relative_asymmetry",
    "control_value",
    "plot_points",
    "plot_lune",
    "plot_skeleton",
    "plot_metric_bars",
    "load_metro_cdmx",
]


__version__ = "0.5.0"
__author__ = "Sara Luz Valenzuela Camacho"
