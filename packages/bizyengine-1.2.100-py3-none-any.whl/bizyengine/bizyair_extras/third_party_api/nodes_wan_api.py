import io

from bizyengine.bizyair_extras.utils.audio import save_audio

from .trd_nodes_base import BizyAirTrdApiBaseNode


class Wan_V2_5_I2V_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
            },
            "optional": {
                "audio": ("AUDIO",),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "resolution": (
                    ["480P", "720P", "1080P"],
                    {"default": "1080P"},
                ),
                "duration": ([5, 10], {"default": 5}),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "auto_audio": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否由模型自动生成声音，优先级低于audio参数。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.5 Image To Video"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        "STRING",
        """{"wan2.5-i2v-preview": "wan2.5-i2v-preview"}""",
    )
    RETURN_NAMES = ("video", "actual_prompt", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # 参数
        prompt = kwargs.get("prompt", "")
        negative_prompt = kwargs.get("negative_prompt", "")
        audio = kwargs.get("audio", None)
        resolution = kwargs.get("resolution", "1080P")
        duration = kwargs.get("duration", 5)
        prompt_extend = kwargs.get("prompt_extend", True)
        auto_audio = kwargs.get("auto_audio", True)
        image = kwargs.get("image", None)

        model = "wan2.5-i2v-preview"
        input = {
            "resolution": resolution,
            "prompt_extend": prompt_extend,
            "duration": duration,
            "audio": auto_audio,
            "model": model,
        }
        if prompt is not None and prompt.strip() != "":
            input["prompt"] = prompt
        if negative_prompt is not None and negative_prompt.strip() != "":
            input["negative_prompt"] = negative_prompt

        # 上传图片&音频
        if image is not None:
            image_url = self.upload_file(
                self.compress_image(image=image, total_pixels=4096 * 4096),
                f"{prompt_id}.webp",
                headers,
            )
            input["img_url"] = image_url
        if audio is not None:
            audio_url = self.upload_file(
                save_audio(audio=audio, format="mp3"), f"{prompt_id}.mp3", headers
            )
            input["audio_url"] = audio_url

        return input, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        text = None
        if len(outputs[2]) > 0:
            text = outputs[2][0]
        return (outputs[0][0], text, urls_str, "")


class Wan_V2_5_T2V_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
            },
            "optional": {
                "audio": ("AUDIO",),
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "size": (
                    [
                        "832*480",
                        "480*832",
                        "624*624",
                        "1280*720",
                        "720*1280",
                        "960*960",
                        "1088*832",
                        "832*1088",
                        "1920*1080",
                        "1080*1920",
                        "1440*1440",
                        "1632*1248",
                        "1248*1632",
                    ],
                    {"default": "1920*1080"},
                ),
                "duration": ([5, 10], {"default": 5}),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "auto_audio": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否由模型自动生成声音，优先级低于audio参数。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.5 Text To Video"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        "STRING",
        """"{"wan2.5-t2v-preview": "wan2.5-t2v-preview"}""",
    )
    RETURN_NAMES = ("video", "actual_prompt", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # 参数
        model = "wan2.5-t2v-preview"
        negative_prompt = kwargs.get("negative_prompt", "")
        audio = kwargs.get("audio", None)
        size = kwargs.get("size", "1920*1080")
        duration = kwargs.get("duration", 5)
        prompt_extend = kwargs.get("prompt_extend", True)
        auto_audio = kwargs.get("auto_audio", True)
        prompt = kwargs.get("prompt", "")

        input = {
            "size": size,
            "prompt_extend": prompt_extend,
            "duration": duration,
            "audio": auto_audio,
            "model": model,
        }
        if prompt is not None and prompt.strip() != "":
            input["prompt"] = prompt
        if negative_prompt is not None and negative_prompt.strip() != "":
            input["negative_prompt"] = negative_prompt

        # 上传音频
        if audio is not None:
            audio_url = self.upload_file(
                save_audio(audio=audio, format="mp3"), f"{prompt_id}.mp3", headers
            )
            input["audio_url"] = audio_url

        return input, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        text = None
        if len(outputs[2]) > 0:
            text = outputs[2][0]
        return (outputs[0][0], text, urls_str, "")


class Wan_V2_6_I2V_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
            },
            "optional": {
                "audio": ("AUDIO",),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "resolution": (
                    ["720P", "1080P"],
                    {"default": "1080P"},
                ),
                "duration": ([5, 10, 15], {"default": 5}),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "shot_type": (
                    ["single", "multi"],
                    {
                        "default": "single",
                        "tooltip": "指定生成视频的镜头类型，即视频是由一个连续镜头还是多个切换镜头组成。仅当prompt_extend: true时生效",
                    },
                ),
                "auto_audio": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否由模型自动生成声音，优先级低于audio参数。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.6 Image To Video"
    RETURN_TYPES = ("VIDEO", "STRING", "STRING", """{"wan2.6-i2v": "wan2.6-i2v"}""")
    RETURN_NAMES = ("video", "actual_prompt", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # 参数
        prompt = kwargs.get("prompt", "")
        negative_prompt = kwargs.get("negative_prompt", "")
        audio = kwargs.get("audio", None)
        resolution = kwargs.get("resolution", "1080P")
        duration = kwargs.get("duration", 5)
        prompt_extend = kwargs.get("prompt_extend", True)
        shot_type = kwargs.get("shot_type", "single")
        auto_audio = kwargs.get("auto_audio", True)
        image = kwargs.get("image", None)

        model = "wan2.6-i2v"
        input = {
            "resolution": resolution,
            "prompt_extend": prompt_extend,
            "duration": duration,
            "audio": auto_audio,
            "model": model,
            "shot_type": shot_type,
        }
        if prompt is not None and prompt.strip() != "":
            input["prompt"] = prompt
        if negative_prompt is not None and negative_prompt.strip() != "":
            input["negative_prompt"] = negative_prompt

        # 上传图片&音频
        if image is not None:
            image_url = self.upload_file(
                self.compress_image(image=image, total_pixels=4096 * 4096),
                f"{prompt_id}.webp",
                headers,
            )
            input["img_url"] = image_url
        if audio is not None:
            audio_url = self.upload_file(
                save_audio(audio=audio, format="mp3"), f"{prompt_id}.mp3", headers
            )
            input["audio_url"] = audio_url

        return input, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        text = None
        if len(outputs[2]) > 0:
            text = outputs[2][0]
        return (outputs[0][0], text, urls_str, "")


class Wan_V2_6_T2V_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
            },
            "optional": {
                "audio": ("AUDIO",),
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "size": (
                    [
                        "1280*720",
                        "720*1280",
                        "960*960",
                        "1088*832",
                        "832*1088",
                        "1920*1080",
                        "1080*1920",
                        "1440*1440",
                        "1632*1248",
                        "1248*1632",
                    ],
                    {"default": "1920*1080"},
                ),
                "duration": ([5, 10, 15], {"default": 5}),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "shot_type": (
                    ["single", "multi"],
                    {
                        "default": "single",
                        "tooltip": "指定生成视频的镜头类型，即视频是由一个连续镜头还是多个切换镜头组成。仅当prompt_extend: true时生效",
                    },
                ),
                "auto_audio": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否由模型自动生成声音，优先级低于audio参数。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.6 Text To Video"
    RETURN_TYPES = ("VIDEO", "STRING", "STRING", """{"wan2.6-t2v": "wan2.6-t2v"}""")
    RETURN_NAMES = ("video", "actual_prompt", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # 参数
        model = "wan2.6-t2v"
        negative_prompt = kwargs.get("negative_prompt", "")
        audio = kwargs.get("audio", None)
        size = kwargs.get("size", "1920*1080")
        duration = kwargs.get("duration", 5)
        prompt_extend = kwargs.get("prompt_extend", True)
        shot_type = kwargs.get("shot_type", "single")
        auto_audio = kwargs.get("auto_audio", True)
        prompt = kwargs.get("prompt", "")

        input = {
            "size": size,
            "prompt_extend": prompt_extend,
            "duration": duration,
            "audio": auto_audio,
            "model": model,
            "shot_type": shot_type,
        }
        if prompt is not None and prompt.strip() != "":
            input["prompt"] = prompt
        if negative_prompt is not None and negative_prompt.strip() != "":
            input["negative_prompt"] = negative_prompt

        # 上传音频
        if audio is not None:
            audio_url = self.upload_file(
                save_audio(audio=audio, format="mp3"), f"{prompt_id}.mp3", headers
            )
            input["audio_url"] = audio_url

        return input, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        text = None
        if len(outputs[2]) > 0:
            text = outputs[2][0]
        return (outputs[0][0], text, urls_str, "")


class Wan_V2_7_R2V_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
            },
            "optional": {
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "first_frame_image": (
                    "IMAGE",
                    {
                        "tooltip": "可选首帧图像。传入后，模型会优先参考首帧构图，ratio 参数会被忽略。",
                    },
                ),
                "ref_image_1": ("IMAGE",),
                "ref_image_2": ("IMAGE",),
                "ref_image_3": ("IMAGE",),
                "ref_image_4": ("IMAGE",),
                "ref_image_5": ("IMAGE",),
                "ref_video_1": ("VIDEO",),
                "ref_video_2": ("VIDEO",),
                "ref_video_3": ("VIDEO",),
                "ref_video_4": ("VIDEO",),
                "ref_video_5": ("VIDEO",),
                "reference_voice": (
                    "AUDIO",
                    {
                        "tooltip": "可选参考音色。若后端支持，将与参考主体一起用于音色控制。",
                    },
                ),
                "resolution": (
                    ["720P", "1080P"],
                    {"default": "1080P"},
                ),
                "ratio": (
                    ["16:9", "9:16", "1:1", "4:3", "3:4"],
                    {"default": "16:9"},
                ),
                "duration": (
                    "INT",
                    {
                        "default": 5,
                        "min": 2,
                        "max": 10,
                    },
                ),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "watermark": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "是否添加“AI生成”水印。",
                    },
                ),
                "seed": (
                    "INT",
                    {
                        "default": -1,
                        "min": -1,
                        "max": 2147483647,
                        "tooltip": "随机种子。设为 -1 时不传此参数，由服务端随机生成。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.7 Reference To Video"
    RETURN_TYPES = ("VIDEO", "STRING", """{"wan2.7-r2v": "wan2.7-r2v"}""")
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def _upload_wan_video(self, video, prompt_id, index, headers):
        if video is None:
            return None

        duration = None
        if hasattr(video, "get_duration") and callable(
            getattr(video, "get_duration", None)
        ):
            duration = video.get_duration()
        if duration is not None and (duration < 1 or duration > 30):
            raise ValueError(
                "Reference video duration must be between 1 and 30 seconds"
            )

        video_bytes_io = io.BytesIO()
        format_to_use = getattr(video, "container", "mp4")
        codec_to_use = getattr(video, "codec", "h264")
        video.save_to(video_bytes_io, format=format_to_use, codec=codec_to_use)
        video_bytes_io.seek(0)
        if video_bytes_io.getbuffer().nbytes > 100 * 1024 * 1024:
            raise ValueError(
                "Reference video size is too large, must be less than 100MB"
            )

        return self.upload_file(
            video_bytes_io,
            f"{prompt_id}_wan27_ref_video_{index}.{format_to_use}",
            headers,
        )

    def _upload_wan_image(self, image, prompt_id, file_name, headers):
        if image is None:
            return None
        return self.upload_file(
            self.compress_image(
                image=image,
                total_pixels=8000 * 8000,
                max_size=20 * 1024 * 1024,
            ),
            f"{prompt_id}_{file_name}.webp",
            headers,
        )

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = "wan2.7-r2v"
        prompt = kwargs.get("prompt", "")
        negative_prompt = kwargs.get("negative_prompt", "")
        first_frame_image = kwargs.get("first_frame_image", None)
        reference_voice = kwargs.get("reference_voice", None)
        resolution = kwargs.get("resolution", "1080P")
        ratio = kwargs.get("ratio", "16:9")
        duration = kwargs.get("duration", 5)
        prompt_extend = kwargs.get("prompt_extend", True)
        watermark = kwargs.get("watermark", False)
        seed = kwargs.get("seed", -1)

        if prompt is None or prompt.strip() == "":
            raise ValueError("Prompt is required for Wan2.7 Reference To Video")

        media = []

        for index, ref_video in enumerate(
            [
                kwargs.get("ref_video_1", None),
                kwargs.get("ref_video_2", None),
                kwargs.get("ref_video_3", None),
                kwargs.get("ref_video_4", None),
                kwargs.get("ref_video_5", None),
            ],
            1,
        ):
            ref_video_url = self._upload_wan_video(ref_video, prompt_id, index, headers)
            if ref_video_url is not None:
                media.append({"type": "reference_video", "url": ref_video_url})

        for index, ref_image in enumerate(
            [
                kwargs.get("ref_image_1", None),
                kwargs.get("ref_image_2", None),
                kwargs.get("ref_image_3", None),
                kwargs.get("ref_image_4", None),
                kwargs.get("ref_image_5", None),
            ],
            1,
        ):
            ref_image_url = self._upload_wan_image(
                ref_image,
                prompt_id,
                f"wan27_ref_image_{index}",
                headers,
            )
            if ref_image_url is not None:
                media.append({"type": "reference_image", "url": ref_image_url})

        ref_media_count = len(media)
        if ref_media_count == 0:
            raise ValueError(
                "Wan2.7 Reference To Video requires at least one reference image or reference video"
            )
        if ref_media_count > 5:
            raise ValueError(
                "Wan2.7 Reference To Video supports at most 5 reference images/videos in total"
            )

        first_frame_image_url = self._upload_wan_image(
            first_frame_image,
            prompt_id,
            "wan27_first_frame",
            headers,
        )
        if first_frame_image_url is not None:
            media.append({"type": "first_frame", "url": first_frame_image_url})

        data = {
            "model": model,
            "prompt": prompt,
            "media": media,
            "resolution": resolution,
            "duration": duration,
            "prompt_extend": prompt_extend,
            "watermark": watermark,
        }
        if first_frame_image_url is None:
            data["ratio"] = ratio
        if negative_prompt is not None and negative_prompt.strip() != "":
            data["negative_prompt"] = negative_prompt
        if seed is not None and seed >= 0:
            data["seed"] = seed
        if reference_voice is not None:
            reference_voice_url = self.upload_file(
                save_audio(audio=reference_voice, format="mp3"),
                f"{prompt_id}_wan27_reference_voice.mp3",
                headers,
            )
            data["reference_voice"] = reference_voice_url

        return data, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Wan_V2_7_VIDEOEDIT_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "video": ("VIDEO",),
            },
            "optional": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "first_frame_image": (
                    "IMAGE",
                    {
                        "tooltip": "可选首帧图像。用于更精细地约束编辑后的首帧表现。",
                    },
                ),
                "ref_image_1": ("IMAGE",),
                "ref_image_2": ("IMAGE",),
                "ref_image_3": ("IMAGE",),
                "resolution": (
                    ["720P", "1080P"],
                    {"default": "1080P"},
                ),
                "ratio": (
                    ["default", "16:9", "9:16", "1:1", "4:3", "3:4"],
                    {
                        "default": "default",
                        "tooltip": "default 表示跟随输入视频宽高比；其余值会显式传给模型。",
                    },
                ),
                "duration": (
                    "INT",
                    {
                        "default": 0,
                        "min": 0,
                        "max": 10,
                        "tooltip": "0 表示保持输入视频时长；2-10 表示从 0 秒开始截断到指定长度。",
                    },
                ),
                "audio_setting": (
                    ["auto", "origin"],
                    {
                        "default": "auto",
                        "tooltip": "auto 为模型自动判断；origin 为强制保留输入视频原声。",
                    },
                ),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "watermark": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "是否添加“AI生成”水印。",
                    },
                ),
                "seed": (
                    "INT",
                    {
                        "default": -1,
                        "min": -1,
                        "max": 2147483647,
                        "tooltip": "随机种子。设为 -1 时不传此参数，由服务端随机生成。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.7 Video Edit"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"wan2.7-videoedit": "wan2.7-videoedit"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def _upload_wan_videoedit_video(self, video, prompt_id, headers):
        if video is None:
            raise ValueError("Video is required for Wan2.7 Video Edit")

        video_duration = None
        if hasattr(video, "get_duration") and callable(
            getattr(video, "get_duration", None)
        ):
            video_duration = video.get_duration()
        if video_duration is not None and (video_duration < 2 or video_duration > 10):
            raise ValueError("Input video duration must be between 2 and 10 seconds")

        video_bytes_io = io.BytesIO()
        format_to_use = getattr(video, "container", "mp4")
        codec_to_use = getattr(video, "codec", "h264")
        video.save_to(video_bytes_io, format=format_to_use, codec=codec_to_use)
        video_bytes_io.seek(0)
        if video_bytes_io.getbuffer().nbytes > 100 * 1024 * 1024:
            raise ValueError("Input video size is too large, must be less than 100MB")

        return self.upload_file(
            video_bytes_io,
            f"{prompt_id}_wan27_videoedit_input.{format_to_use}",
            headers,
        )

    def _upload_wan_videoedit_image(self, image, prompt_id, file_name, headers):
        if image is None:
            return None
        return self.upload_file(
            self.compress_image(
                image=image,
                total_pixels=8000 * 8000,
                max_size=20 * 1024 * 1024,
            ),
            f"{prompt_id}_{file_name}.webp",
            headers,
        )

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = "wan2.7-videoedit"
        video = kwargs.get("video", None)
        prompt = kwargs.get("prompt", "")
        negative_prompt = kwargs.get("negative_prompt", "")
        first_frame_image = kwargs.get("first_frame_image", None)
        resolution = kwargs.get("resolution", "1080P")
        ratio = kwargs.get("ratio", "default")
        duration = kwargs.get("duration", 0)
        audio_setting = kwargs.get("audio_setting", "auto")
        prompt_extend = kwargs.get("prompt_extend", True)
        watermark = kwargs.get("watermark", False)
        seed = kwargs.get("seed", -1)

        video_url = self._upload_wan_videoedit_video(video, prompt_id, headers)
        media = [{"type": "video", "url": video_url}]

        first_frame_image_url = self._upload_wan_videoedit_image(
            first_frame_image,
            prompt_id,
            "wan27_videoedit_first_frame",
            headers,
        )
        if first_frame_image_url is not None:
            media.append({"type": "first_frame", "url": first_frame_image_url})

        reference_image_count = 0
        for index, ref_image in enumerate(
            [
                kwargs.get("ref_image_1", None),
                kwargs.get("ref_image_2", None),
                kwargs.get("ref_image_3", None),
            ],
            1,
        ):
            ref_image_url = self._upload_wan_videoedit_image(
                ref_image,
                prompt_id,
                f"wan27_videoedit_ref_image_{index}",
                headers,
            )
            if ref_image_url is not None:
                media.append({"type": "reference_image", "url": ref_image_url})
                reference_image_count += 1

        if reference_image_count > 3:
            raise ValueError("Wan2.7 Video Edit supports at most 3 reference images")

        data = {
            "model": model,
            "media": media,
            "resolution": resolution,
            "audio_setting": audio_setting,
            "prompt_extend": prompt_extend,
            "watermark": watermark,
        }
        if prompt is not None and prompt.strip() != "":
            data["prompt"] = prompt
        if negative_prompt is not None and negative_prompt.strip() != "":
            data["negative_prompt"] = negative_prompt
        if ratio != "default":
            data["ratio"] = ratio
        if duration not in (None, 0):
            if duration < 2 or duration > 10:
                raise ValueError("Duration must be 0 or an integer between 2 and 10")
            data["duration"] = duration
        if seed is not None and seed >= 0:
            data["seed"] = seed

        return data, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Wan_V2_7_T2V_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "可通过自然语言控制镜头结构，实现多镜头叙事。",
                    },
                ),
            },
            "optional": {
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "反向提示词，用来描述不希望在视频画面中看到的内容，可以对视频画面进行限制。",
                    },
                ),
                "audio": ("AUDIO", {"tooltip": "模型将使用该音频生成视频。"}),
                "resolution": (
                    ["720P", "1080P"],
                    {"default": "1080P"},
                ),
                "ratio": (
                    [
                        "1:1",
                        "4:3",
                        "3:4",
                        "9:16",
                        "16:9",
                    ],
                    {"default": "16:9"},
                ),
                "duration": (
                    "INT",
                    {
                        "default": 5,
                        "min": 2,
                        "max": 15,
                        "step": 1,
                    },
                ),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "watermark": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "是否添加水印标识，水印位于视频右下角，文案固定为“AI生成”。",
                    },
                ),
                "seed": (
                    "INT",
                    {
                        "default": 0,
                        "min": 0,
                        "max": 2147483647,
                        "step": 1,
                        "tooltip": "未指定时，系统自动生成随机种子。若需提升生成结果的可复现性，建议固定seed值。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.7 Text To Video"
    RETURN_TYPES = ("VIDEO", "STRING", """{"wan2.7-t2v": "wan2.7-t2v"}""")
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # 参数
        model = "wan2.7-t2v"
        prompt = kwargs.get("prompt", "")
        negative_prompt = kwargs.get("negative_prompt", "")
        audio = kwargs.get("audio", None)
        resolution = kwargs.get("resolution", "1080P")
        ratio = kwargs.get("ratio", "16:9")
        duration = kwargs.get("duration", 5)
        prompt_extend = kwargs.get("prompt_extend", True)
        watermark = kwargs.get("watermark", False)
        seed = kwargs.get("seed", 0)

        input = {
            "model": model,
            "resolution": resolution,
            "ratio": ratio,
            "duration": duration,
            "prompt_extend": prompt_extend,
            "watermark": watermark,
            "seed": seed,
        }

        if prompt is not None and prompt.strip() != "":
            input["prompt"] = prompt
        if negative_prompt is not None and negative_prompt.strip() != "":
            input["negative_prompt"] = negative_prompt

        # 上传音频
        if audio is not None:
            audio_url = self.upload_file(
                save_audio(audio=audio, format="mp3"), f"{prompt_id}.mp3", headers
            )
            input["audio_url"] = audio_url

        return input, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Wan_V2_7_I2V_API(BizyAirTrdApiBaseNode):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "first_frame": ("IMAGE",),
            },
            "optional": {
                "last_frame": ("IMAGE",),
                "audio": ("AUDIO",),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "negative_prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "resolution": (
                    ["720P", "1080P"],
                    {"default": "1080P"},
                ),
                "duration": (
                    "INT",
                    {"default": 5, "min": 2, "max": 15, "step": 1},
                ),
                "prompt_extend": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
                    },
                ),
                "watermark": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "是否添加水印标识，水印位于视频右下角，文案固定为“AI生成”。",
                    },
                ),
                "seed": (
                    "INT",
                    {
                        "default": -1,
                        "min": -1,
                        "max": 2147483647,
                        "tooltip": "随机数种子，-1 表示不指定（由系统随机生成）。",
                    },
                ),
            },
        }

    NODE_DISPLAY_NAME = "Wan2.7 Image To Video"
    RETURN_TYPES = ("VIDEO", "STRING", """{"wan2.7-i2v": "wan2.7-i2v"}""")
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/WanVideo"

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", "")
        negative_prompt = kwargs.get("negative_prompt", "")
        first_frame = kwargs.get("first_frame", None)
        last_frame = kwargs.get("last_frame", None)
        audio = kwargs.get("audio", None)
        resolution = kwargs.get("resolution", "1080P")
        duration = kwargs.get("duration", 5)
        prompt_extend = kwargs.get("prompt_extend", True)
        watermark = kwargs.get("watermark", False)
        seed = kwargs.get("seed", -1)

        model = "wan2.7-i2v"

        input_data = {
            "model": model,
            "resolution": resolution,
            "duration": duration,
            "prompt_extend": prompt_extend,
            "watermark": watermark,
        }

        if prompt is not None and prompt.strip() != "":
            input_data["prompt"] = prompt
        if negative_prompt is not None and negative_prompt.strip() != "":
            input_data["negative_prompt"] = negative_prompt
        if seed != -1:
            input_data["seed"] = seed

        # 上传首帧（必选）
        if first_frame is not None:
            first_frame_url = self.upload_file(
                self.compress_image(image=first_frame, total_pixels=4096 * 4096),
                f"{prompt_id}_first_frame.webp",
                headers,
            )
            input_data["first_frame"] = first_frame_url

        # 上传尾帧（可选，有则变为首尾帧生视频）
        if last_frame is not None:
            last_frame_url = self.upload_file(
                self.compress_image(image=last_frame, total_pixels=4096 * 4096),
                f"{prompt_id}_last_frame.webp",
                headers,
            )
            input_data["last_frame"] = last_frame_url

        # 上传驱动音频（可选）
        if audio is not None:
            audio_url = self.upload_file(
                save_audio(audio=audio, format="mp3"), f"{prompt_id}.mp3", headers
            )
            input_data["driving_audio"] = audio_url

        return input_data, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


# class Wan_V2_7_VideoExtension_API(BizyAirTrdApiBaseNode):
#     @classmethod
#     def INPUT_TYPES(cls):
#         return {
#             "required": {
#                 "first_clip": ("VIDEO",),
#             },
#             "optional": {
#                 "last_frame": ("IMAGE",),
#                 "prompt": (
#                     "STRING",
#                     {
#                         "multiline": True,
#                         "default": "",
#                     },
#                 ),
#                 "negative_prompt": (
#                     "STRING",
#                     {
#                         "multiline": True,
#                         "default": "",
#                     },
#                 ),
#                 "resolution": (
#                     ["720P", "1080P"],
#                     {"default": "1080P"},
#                 ),
#                 "duration": (
#                     "INT",
#                     {"default": 5, "min": 2, "max": 15, "step": 1},
#                 ),
#                 "prompt_extend": (
#                     "BOOLEAN",
#                     {
#                         "default": True,
#                         "tooltip": "是否开启prompt智能改写。开启后使用大模型对输入prompt进行智能改写。对于较短的prompt生成效果提升明显，但会增加耗时。",
#                     },
#                 ),
#                 "watermark": (
#                     "BOOLEAN",
#                     {
#                         "default": False,
#                         "tooltip": "是否添加水印标识，水印位于视频右下角，文案固定为“AI生成”。",
#                     },
#                 ),
#                 "seed": (
#                     "INT",
#                     {
#                         "default": -1,
#                         "min": -1,
#                         "max": 2147483647,
#                         "tooltip": "随机数种子，-1 表示不指定（由系统随机生成）。",
#                     },
#                 ),
#             },
#         }

#     NODE_DISPLAY_NAME = "Wan2.7 Video Extension"
#     RETURN_TYPES = ("VIDEO", "STRING", """{"wan2.7-i2v": "wan2.7-i2v"}""")
#     RETURN_NAMES = ("video", "urls", "bizyair_model_name")
#     CATEGORY = "☁️BizyAir/External APIs/WanVideo"

#     def handle_inputs(self, headers, prompt_id, **kwargs):
#         prompt = kwargs.get("prompt", "")
#         negative_prompt = kwargs.get("negative_prompt", "")
#         first_clip = kwargs.get("first_clip", None)
#         last_frame = kwargs.get("last_frame", None)
#         resolution = kwargs.get("resolution", "1080P")
#         duration = kwargs.get("duration", 5)
#         prompt_extend = kwargs.get("prompt_extend", True)
#         watermark = kwargs.get("watermark", False)
#         seed = kwargs.get("seed", -1)

#         model = "wan2.7-i2v"

#         input_data = {
#             "model": model,
#             "resolution": resolution,
#             "duration": duration,
#             "prompt_extend": prompt_extend,
#             "watermark": watermark,
#         }

#         if prompt is not None and prompt.strip() != "":
#             input_data["prompt"] = prompt
#         if negative_prompt is not None and negative_prompt.strip() != "":
#             input_data["negative_prompt"] = negative_prompt
#         if seed != -1:
#             input_data["seed"] = seed

#         # 上传首段视频（必选）
#         if first_clip is not None:
#             video_bytes_io = io.BytesIO()
#             format_to_use = getattr(first_clip, "container", "mp4")
#             codec_to_use = getattr(first_clip, "codec", "h264")
#             first_clip.save_to(video_bytes_io, format=format_to_use, codec=codec_to_use)
#             video_bytes_io.seek(0)
#             first_clip_url = self.upload_file(
#                 video_bytes_io,
#                 f"{prompt_id}_first_clip.{format_to_use}",
#                 headers,
#             )
#             input_data["first_clip"] = first_clip_url

#         # 上传尾帧（可选，有则变为首段视频+尾帧续写）
#         if last_frame is not None:
#             last_frame_url = self.upload_file(
#                 self.compress_image(image=last_frame, total_pixels=4096 * 4096),
#                 f"{prompt_id}_last_frame.webp",
#                 headers,
#             )
#             input_data["last_frame"] = last_frame_url

#         return input_data, model

#     def handle_outputs(self, outputs):
#         urls_str = outputs[3]
#         return (outputs[0][0], urls_str, "")


# class Wan_V2_7_IMAGE_API(BizyAirTrdApiBaseNode):
#     NODE_DISPLAY_NAME = "Wan2.7 Image"
#     RETURN_TYPES = (
#         "IMAGE",
#         "STRING",
#         """{"wan2.7-image-pro": "wan2.7-image","wan2.7-image": "wan2.7-image"}""",
#     )
#     RETURN_NAMES = ("images", "urls", "bizyair_model_name")
#     CATEGORY = "☁️BizyAir/External APIs/WanImage"
#     INPUT_IS_LIST = True

#     @classmethod
#     def INPUT_TYPES(cls):
#         return {
#             "required": {
#                 "prompt": (
#                     "STRING",
#                     {
#                         "multiline": True,
#                         "default": "",
#                     },
#                 ),
#                 "model": (
#                     ["wan2.7-image-pro", "wan2.7-image"],
#                     {"default": "wan2.7-image-pro"},
#                 ),
#                 "size": (
#                     ["1K", "2K", "4K", "Custom"],
#                     {
#                         "default": "2K",
#                         "tooltip": "1K/2K/4K 为官方规格，Custom 使用自定义宽高像素值。",
#                     },
#                 ),
#                 "custom_width": (
#                     "INT",
#                     {
#                         "default": 2048,
#                         "min": 768,
#                         "max": 4096,
#                         "tooltip": "仅当 size=Custom 时生效。",
#                     },
#                 ),
#                 "custom_height": (
#                     "INT",
#                     {
#                         "default": 2048,
#                         "min": 768,
#                         "max": 4096,
#                         "tooltip": "仅当 size=Custom 时生效。",
#                     },
#                 ),
#                 "n": (
#                     "INT",
#                     {
#                         "default": 4,
#                         "min": 1,
#                         "max": 12,
#                         "tooltip": "非组图模式下范围 1-4；组图模式下范围 1-12。",
#                     },
#                 ),
#             },
#             "optional": {
#                 "images": (
#                     "IMAGE",
#                     {"tooltip": "可输入 0-9 张参考图，用于图像编辑、多图参考生成或图生组图。"},
#                 ),
#                 "inputcount": (
#                     "INT",
#                     {
#                         "default": 1,
#                         "min": 1,
#                         "max": 9,
#                         "tooltip": "动态控制输入参考图数量，范围 1-9，点击 Update inputs 按钮刷新。",
#                     },
#                 ),
#                 "enable_sequential": (
#                     "BOOLEAN",
#                     {
#                         "default": False,
#                         "tooltip": "是否启用组图模式。启用后可生成一组保持角色或主体一致性的图片。",
#                     },
#                 ),
#                 "thinking_mode": (
#                     "BOOLEAN",
#                     {
#                         "default": True,
#                         "tooltip": "仅在文生图且未开启组图模式时生效。",
#                     },
#                 ),
#                 "bbox_list": (
#                     "STRING",
#                     {
#                         "multiline": True,
#                         "default": "",
#                         "tooltip": "交互式编辑框选区域，使用 JSON 数组字符串，例如 [[], [[989, 515, 1138, 681]]]",
#                     },
#                 ),
#                 "color_palette": (
#                     "STRING",
#                     {
#                         "multiline": True,
#                         "default": "",
#                         "tooltip": '颜色主题 JSON 数组，例如 [{"hex":"#C2D1E6","ratio":"23.51%"}]',
#                     },
#                 ),
#                 "watermark": (
#                     "BOOLEAN",
#                     {
#                         "default": False,
#                         "tooltip": "是否添加“AI生成”水印。",
#                     },
#                 ),
#                 "seed": (
#                     "INT",
#                     {
#                         "default": -1,
#                         "min": -1,
#                         "max": 2147483647,
#                         "tooltip": "随机种子。设为 -1 时不传此参数。",
#                     },
#                 ),
#             },
#         }

#     def _upload_wan27_generation_image(self, image, prompt_id, index, headers):
#         bio = self.compress_image(
#             image=image,
#             total_pixels=8000 * 8000,
#             max_size=20 * 1024 * 1024,
#         )
#         return self.upload_file(
#             bio,
#             f"{prompt_id}_wan27_image_{index}.webp",
#             headers,
#         )

#     def _parse_bbox_list(self, bbox_list_str, image_count):
#         if bbox_list_str is None or bbox_list_str.strip() == "":
#             return None
#         try:
#             bbox_list = json.loads(bbox_list_str)
#         except json.JSONDecodeError as e:
#             raise ValueError(f"bbox_list must be valid JSON: {e}") from e

#         if not isinstance(bbox_list, list):
#             raise ValueError("bbox_list must be a JSON array")
#         if len(bbox_list) != image_count:
#             raise ValueError(
#                 "bbox_list length must exactly match the number of input images"
#             )
#         for image_boxes in bbox_list:
#             if not isinstance(image_boxes, list):
#                 raise ValueError("Each bbox_list item must be an array")
#             if len(image_boxes) > 2:
#                 raise ValueError("Each input image supports at most 2 bounding boxes")
#             for box in image_boxes:
#                 if (
#                     not isinstance(box, list)
#                     or len(box) != 4
#                     or not all(isinstance(v, int) for v in box)
#                 ):
#                     raise ValueError(
#                         "Each bounding box must be a list of 4 integers: [x1, y1, x2, y2]"
#                     )
#         return bbox_list

#     def _parse_color_palette(self, color_palette_str, enable_sequential):
#         if color_palette_str is None or color_palette_str.strip() == "":
#             return None
#         if enable_sequential:
#             raise ValueError(
#                 "color_palette is only supported when enable_sequential is false"
#             )
#         try:
#             color_palette = json.loads(color_palette_str)
#         except json.JSONDecodeError as e:
#             raise ValueError(f"color_palette must be valid JSON: {e}") from e

#         if not isinstance(color_palette, list):
#             raise ValueError("color_palette must be a JSON array")
#         if len(color_palette) < 3 or len(color_palette) > 10:
#             raise ValueError("color_palette must contain between 3 and 10 colors")

#         ratio_sum = 0.0
#         for color in color_palette:
#             if not isinstance(color, dict):
#                 raise ValueError("Each color_palette item must be an object")
#             hex_value = color.get("hex", "")
#             ratio_value = color.get("ratio", "")
#             if (
#                 not isinstance(hex_value, str)
#                 or len(hex_value) != 7
#                 or not hex_value.startswith("#")
#             ):
#                 raise ValueError(
#                     "Each color_palette item must contain a hex value like #C2D1E6"
#                 )
#             if not isinstance(ratio_value, str) or not ratio_value.endswith("%"):
#                 raise ValueError(
#                     'Each color_palette item must contain a ratio string like "23.51%"'
#                 )
#             try:
#                 ratio_sum += float(ratio_value[:-1])
#             except ValueError as e:
#                 raise ValueError(
#                     f"Invalid color ratio value in color_palette: {ratio_value}"
#                 ) from e

#         if abs(ratio_sum - 100.0) > 0.05:
#             raise ValueError("color_palette ratios must sum to 100.00%")
#         return color_palette

#     def _resolve_size(
#         self, model, size, custom_width, custom_height, has_input_images, enable_sequential
#     ):
#         if size != "Custom":
#             if size == "4K":
#                 if model != "wan2.7-image-pro":
#                     raise ValueError("wan2.7-image does not support 4K output")
#                 if has_input_images or enable_sequential:
#                     raise ValueError(
#                         "4K is only supported for text-to-image when there are no input images and enable_sequential is false"
#                     )
#             return size

#         total_pixels = custom_width * custom_height
#         if custom_width / custom_height < 1 / 8 or custom_width / custom_height > 8:
#             raise ValueError("Custom size aspect ratio must be between 1:8 and 8:1")
#         if total_pixels < 768 * 768:
#             raise ValueError("Custom size total pixels must be at least 768*768")

#         max_pixels = 2048 * 2048
#         if (
#             model == "wan2.7-image-pro"
#             and not has_input_images
#             and not enable_sequential
#         ):
#             max_pixels = 4096 * 4096
#         if total_pixels > max_pixels:
#             raise ValueError(
#                 f"Custom size total pixels exceed the current scene limit: {max_pixels}"
#             )
#         return f"{custom_width}*{custom_height}"

#     def handle_inputs(self, headers, prompt_id, **kwargs):
#         prompt = kwargs.get("prompt", [""])[0]
#         model = kwargs.get("model", ["wan2.7-image-pro"])[0]
#         size = kwargs.get("size", ["2K"])[0]
#         custom_width = kwargs.get("custom_width", [2048])[0]
#         custom_height = kwargs.get("custom_height", [2048])[0]
#         n = kwargs.get("n", [4])[0]
#         enable_sequential = kwargs.get("enable_sequential", [False])[0]
#         thinking_mode = kwargs.get("thinking_mode", [True])[0]
#         bbox_list_str = kwargs.get("bbox_list", [""])[0]
#         color_palette_str = kwargs.get("color_palette", [""])[0]
#         watermark = kwargs.get("watermark", [False])[0]
#         seed = kwargs.get("seed", [-1])[0]
#         images = kwargs.get("images", [])

#         total_input_images = 0
#         for img_batch in images if images is not None else []:
#             if img_batch is not None:
#                 total_input_images += img_batch.shape[0]
#         extra_images, total_extra_images = self.get_extra_images(**kwargs)
#         total_input_images += total_extra_images
#         if total_input_images > 9:
#             raise ValueError("Wan2.7 Image supports at most 9 input images")

#         if enable_sequential:
#             if n < 1 or n > 12:
#                 raise ValueError("n must be between 1 and 12 when enable_sequential=true")
#         else:
#             if n < 1 or n > 4:
#                 raise ValueError("n must be between 1 and 4 when enable_sequential=false")

#         resolved_size = self._resolve_size(
#             model,
#             size,
#             custom_width,
#             custom_height,
#             total_input_images > 0,
#             enable_sequential,
#         )
#         bbox_list = self._parse_bbox_list(bbox_list_str, total_input_images)
#         color_palette = self._parse_color_palette(
#             color_palette_str, enable_sequential
#         )

#         urls = []
#         image_index = 1
#         for img_batch in images if images is not None else []:
#             for img in img_batch if img_batch is not None else []:
#                 if img is not None:
#                     image_url = self._upload_wan27_generation_image(
#                         img, prompt_id, image_index, headers
#                     )
#                     urls.append(image_url)
#                     image_index += 1
#         for img_batch in extra_images:
#             for img in img_batch if img_batch is not None else []:
#                 if img is not None:
#                     image_url = self._upload_wan27_generation_image(
#                         img, prompt_id, image_index, headers
#                     )
#                     urls.append(image_url)
#                     image_index += 1

#         if (prompt is None or prompt.strip() == "") and len(urls) == 0:
#             raise ValueError("At least a prompt or one input image is required")

#         data = {
#             "model": model,
#             "size": resolved_size,
#             "n": n,
#             "watermark": watermark,
#         }
#         if prompt is not None and prompt.strip() != "":
#             data["prompt"] = prompt
#         if len(urls) > 0:
#             data["urls"] = urls
#         if enable_sequential:
#             data["enable_sequential"] = True
#         if not enable_sequential and total_input_images == 0:
#             data["thinking_mode"] = thinking_mode
#         if bbox_list is not None:
#             data["bbox_list"] = bbox_list
#         if color_palette is not None:
#             data["color_palette"] = color_palette
#         if seed is not None and seed >= 0:
#             data["seed"] = seed
#         return data, "wan2.7-image"

#     def handle_outputs(self, outputs):
#         images = self.combine_images(outputs[1])
#         if images is None:
#             raise ValueError("No image found in response")
#         urls_str = outputs[3]
#         return (images, urls_str, "")
