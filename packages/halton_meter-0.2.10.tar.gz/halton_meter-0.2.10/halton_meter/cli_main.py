"""CLI entrypoint shim — wires Phase-2 cloud commands into the main CLI.

The historical entrypoint ``halton-meter`` resolves to
``halton_meter.cli:cli``. This module re-exports that same ``cli``
object after attaching the Phase-2 ``cloud`` subgroup and the
top-level ``sync`` alias.

Why a shim rather than editing ``cli.py`` directly:

- ``cli.py`` is ~130k+ lines and on the hot path for every
  ``halton-meter ...`` invocation; touching it for every new subgroup
  invites merge conflicts and reorg churn.
- The shim is one-import-deep, costs nothing at runtime, and keeps the
  Wave 1A.iii diff strictly additive in the daemon repo.
- The pyproject entrypoint is flipped to ``halton_meter.cli_main:cli``
  in the same PR so ``pipx install halton-meter`` picks up both the
  existing CLI and the new ``cloud`` subgroup with no user-visible
  difference.

Importing this module is idempotent — ``register()`` is safe to call
multiple times because click's ``add_command`` overwrites by name.
"""

from __future__ import annotations

from halton_meter.cli import cli
from halton_meter.cli_cloud import register as _register_cloud_cli

_register_cloud_cli(cli)

__all__ = ["cli"]
