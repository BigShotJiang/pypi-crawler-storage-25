"""Local-at-rest encryption for the cloud API key stored in ``cloud_state``.

Phase 2 design decision (memory/plans/phase2-daemon-changes.md §1c): the raw
``hm_sync_…`` token's canonical home is ``~/.halton-meter/config.toml`` with
``chmod 600``. The ``cloud_state.api_key_ciphertext`` column is a defence-
in-depth mirror so that:

  * audit + debugging tools that walk the SQLite file (e.g.
    ``halton-meter doctor``, ``halton-meter cloud status``) can confirm an
    encrypted token is present without exposing it;
  * a future v0.3 release that flips the canonical home into the DB does
    not need a schema migration.

We use Fernet (AES-128-CBC + HMAC-SHA256, URL-safe-b64 framing) over a key
loaded from ``~/.halton-meter/cloud.key`` (``chmod 600``, owner-only). The
key file is auto-generated on first encrypt and never logged.

Public surface:

    encrypt_api_key(plaintext: str) -> bytes
    decrypt_api_key(ciphertext: bytes) -> str
    fingerprint_api_key(plaintext: str) -> str   # 64-char SHA-256 hex

This module is deliberately tiny and lives next to the storage layer (not in
``cloud/``) because the storage repo needs it to round-trip the column and
the cloud worker is allowed to depend on storage — but never vice-versa.
"""

from __future__ import annotations

import hashlib
import os
import stat
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

# Default location — overridable by callers (tests use ``tmp_path``).
DEFAULT_KEY_PATH = Path("~/.halton-meter/cloud.key").expanduser()

# Owner-only read/write. The key file is as sensitive as the token itself;
# leaking it nullifies the encryption.
_KEY_FILE_MODE = 0o600


class CloudCryptoError(RuntimeError):
    """Raised when encryption setup fails irrecoverably.

    The storage layer treats this as fail-closed for the encrypted-token
    write but does NOT block the rest of the cloud_state row from
    persisting (workspace_id, hostname, etc. are still useful for diag).
    """


def _ensure_key(path: Path = DEFAULT_KEY_PATH) -> bytes:
    """Load or generate the per-machine Fernet key.

    Idempotent: returns the existing key if present, otherwise generates a
    fresh one and writes it with ``chmod 600``. Never raises into the
    caller — failures translate to :class:`CloudCryptoError`.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:  # pragma: no cover — defensive
        msg = f"cloud.key parent dir not creatable: {exc}"
        raise CloudCryptoError(msg) from exc

    if path.exists():
        try:
            data = path.read_bytes().strip()
        except OSError as exc:
            msg = f"cloud.key not readable: {exc}"
            raise CloudCryptoError(msg) from exc
        if not data:
            msg = "cloud.key is empty — refusing to use"
            raise CloudCryptoError(msg)
        return data

    # Generate + write + tighten perms. The order matters: open with
    # exclusive create + chmod before write so the key bytes are never
    # visible to a co-tenant in the brief window between create and chmod.
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, _KEY_FILE_MODE)
    try:
        key = Fernet.generate_key()
        os.write(fd, key)
    finally:
        os.close(fd)

    # Belt + braces: re-assert the mode in case the umask weakened it.
    try:
        current = stat.S_IMODE(path.stat().st_mode)
        if current != _KEY_FILE_MODE:
            path.chmod(_KEY_FILE_MODE)
    except OSError:  # pragma: no cover — defensive
        pass
    return key


def encrypt_api_key(plaintext: str, *, key_path: Path | None = None) -> bytes:
    """Encrypt ``plaintext`` using the per-machine Fernet key.

    Returns the Fernet token (URL-safe b64 ciphertext) as ``bytes``. The
    SQLAlchemy ``LargeBinary`` column stores it verbatim.
    """
    if not plaintext:
        msg = "encrypt_api_key: empty plaintext"
        raise CloudCryptoError(msg)
    key = _ensure_key(key_path or DEFAULT_KEY_PATH)
    return Fernet(key).encrypt(plaintext.encode("utf-8"))


def decrypt_api_key(
    ciphertext: bytes, *, key_path: Path | None = None
) -> str:
    """Decrypt a Fernet ciphertext produced by :func:`encrypt_api_key`.

    Raises :class:`CloudCryptoError` on tampering, key mismatch, or empty
    input. Callers MUST NOT log the plaintext.
    """
    if not ciphertext:
        msg = "decrypt_api_key: empty ciphertext"
        raise CloudCryptoError(msg)
    key = _ensure_key(key_path or DEFAULT_KEY_PATH)
    try:
        return Fernet(key).decrypt(ciphertext).decode("utf-8")
    except InvalidToken as exc:
        msg = "cloud_state.api_key_ciphertext failed Fernet verification"
        raise CloudCryptoError(msg) from exc


def fingerprint_api_key(plaintext: str) -> str:
    """SHA-256 hex of the raw key — for audit display and log lines.

    The fingerprint is safe to log; the plaintext is never. 64-char output.
    """
    if not plaintext:
        msg = "fingerprint_api_key: empty plaintext"
        raise CloudCryptoError(msg)
    return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()


__all__ = [
    "DEFAULT_KEY_PATH",
    "CloudCryptoError",
    "decrypt_api_key",
    "encrypt_api_key",
    "fingerprint_api_key",
]
