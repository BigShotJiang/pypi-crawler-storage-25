"""Request model — one row per captured LLM API call.

This is the union of:
  * the daemon's existing `requests` table (proxy hot-path writer)
  * the cloud backend's `requests` table (FK to projects, FastAPI reader)

The daemon's old `project TEXT` slug is replaced by `project_id` (FK to
projects). The proxy write path auto-creates the row in `projects` on first
sighting via `services.ingest._get_or_create_project`.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from halton_meter.storage.models.base import Base

if TYPE_CHECKING:
    from halton_meter.storage.models.request_body import RequestBody


def _uuid4_str() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class Request(Base):
    __tablename__ = "requests"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4_str)
    project_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("projects.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    provider: Mapped[str] = mapped_column(String(64), nullable=False)
    model: Mapped[str] = mapped_column(String(255), nullable=False)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="standard")

    input_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    thinking_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # Cache READ tokens (Anthropic: usage.cache_read_input_tokens).
    # Renamed from `cached_tokens` 2026-04-30 (decisions.md); ambiguous name
    # would become a bug once `cache_write_tokens` exists alongside it.
    cache_read_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # Cache WRITE tokens (Anthropic: usage.cache_creation_input_tokens).
    # Single field by design — see pricing/matrix.py for the TTL note.
    cache_write_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Cost in millicents: 1 USD = 100_000 millicents. NULL if model unknown.
    cost_usd_minor_units: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    # Stored as REAL — daemon's existing schema has latency_ms as float, not int.
    latency_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    tokens_complete: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    requested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    source_machine: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_workdir: Mapped[str | None] = mapped_column(Text, nullable=True)
    # ``attribution_method`` — which tier of the unified resolver produced
    # this row. Canonical value list maintained in
    # ``halton_meter.attribution_store`` (module docstring "ATTRIBUTION_METHOD
    # ENUM"). v0.2.4 added seven values: ``ide_env_label``,
    # ``ide_argv_label``, ``parent_rcfile``, ``parent_git``,
    # ``parent_ide_sniff``, ``parent_ide_env_label``,
    # ``parent_ide_argv_label``. Longest new value is 21 chars; the
    # existing ``String(32)`` is wide enough — no schema migration
    # required on the daemon side. Cloud-side Alembic migration must
    # land first per the v0.2.4 sequencing rule.
    attribution_method: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="success")

    # --- Phase 2 cloud-sync (v0.2.0) wire-contract fields. --------------------
    # All nullable / defaulted so older rows + offline writers keep working.
    # See memory/plans/phase2-wire-contract.md §3 (pinned to SHA e8f252a) and
    # memory/plans/phase2-daemon-changes.md §1a.

    # Anthropic prompt-cache WRITE tokens — already declared above as
    # ``cache_write_tokens`` (Integer, default 0). Wire field name in cloud is
    # ``cache_write_tokens`` (Integer | None on the wire; locally we keep the
    # non-null Integer-default-0 shape that the proxy hot path uses today and
    # let the serialiser emit ``None`` only when the proxy didn't compute it).

    # Streaming-only: time-to-first-token in milliseconds. None for non-stream.
    time_to_first_token_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)

    # USD → GBP rate the daemon used at write time. Decimal precision 10,6 to
    # match the cloud schema; SQLite Numeric is stored as TEXT.
    fx_rate: Mapped[float | None] = mapped_column(
        Numeric(10, 6), nullable=True
    )

    # Provider request kind: chat / embedding / image / audio / moderation /
    # tool / other. Default left to None so adapters that don't classify yet
    # are not silently mislabelled.
    request_kind: Mapped[str | None] = mapped_column(String(32), nullable=True)

    # SHA-256 hex of redacted prompt bytes, first 64 chars. NULL when the
    # project hasn't opted into body capture. Never the raw prompt text.
    prompt_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # Per-record idempotency key. Pass-through from request header (e.g.
    # ``Idempotency-Key``, ``Anthropic-Idempotency-Key``). Never synthesised.
    idempotency_key: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Pricing-freshness audit field (v0.1.22.22, Layer 1).
    #
    # Records which rate row produced ``cost_usd_minor_units``:
    #   * "bundled-YYYY-MM-DD" — cost computed from a seed pricing_rates
    #     row (``PricingRate.is_seed_default = True``). The date is
    #     ``BUNDLED_RATES_DATE`` from the daemon version that wrote the row.
    #   * "override"           — cost computed from an operator-set
    #     pricing_rates row (``is_seed_default = False``).
    #   * NULL                  — no rate matched and the bundled-matrix
    #     fallback (or unknown-model NULL) was used. Pre-v0.1.22.22 rows
    #     are also NULL because the column did not exist when they were
    #     written; the in-place ALTER defaults to NULL.
    #
    # See decisions.md 2026-05-08.
    rates_source: Mapped[str | None] = mapped_column(String(64), nullable=True)

    project: Mapped[Project] = relationship(  # noqa: F821 — forward ref
        "Project", back_populates="requests"
    )
    # Optional 1:1 to the captured request/response bodies. Body rows live
    # in a separate table so retention / purges don't touch the counts row.
    # uselist=False because of the strict 1:1 (PK = request_id on the body
    # side); cascade=delete-orphan + ON DELETE CASCADE in the body's FK so
    # purging a request drops its body atomically.
    body: Mapped[RequestBody | None] = relationship(
        "RequestBody",
        back_populates="request",
        uselist=False,
        lazy="select",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("idx_requests_project_requested_at", "project_id", "requested_at"),
        Index("idx_requests_provider_model_requested_at", "provider", "model", "requested_at"),
        # Cloud-sync cursor key: (recorded_at, id). The sync worker reads
        # rows ordered by ``recorded_at, id`` so the daemon's monotonic
        # write-time ordering is the cursor anchor; ``id`` is the tiebreaker
        # for same-ms rows. See phase2-cloud-sync.md §3c.
        Index("idx_requests_cloud_cursor", "recorded_at", "id"),
    )
