"""RequestBody model — captured request + response payloads, one row per request.

Companion to ``Request``. Strict 1:1 (PK = request_id, FK CASCADE) so the
counts row remains the source of truth and bodies can be purged
independently for retention without touching the metering ledger.

Capture is opt-in by project (default ON). Bodies land here AFTER credential
redaction; reads are plaintext-as-stored. See
``daemon/halton_meter/redaction/credentials.py`` for the redaction pass and
``memory/plans/2026-05-01-body-capture.md`` for the design.

The hot path that writes this row is in ``halton_meter.proxy`` (PR2). PR1
ships only the schema, redaction, and CLI scaffolding — the table is
created but no rows land in it until PR2 wires the proxy hook.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from halton_meter.storage.models.base import Base

if TYPE_CHECKING:
    from halton_meter.storage.models.request import Request


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class RequestBody(Base):
    __tablename__ = "request_bodies"

    # PK = request_id. Strict 1:1 with the counts row. CASCADE so a request
    # purge drops its body row; the body row can also be purged
    # independently (retention TTL) without touching the counts row.
    request_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("requests.id", ondelete="CASCADE"),
        primary_key=True,
    )

    # Body payloads. TEXT not BLOB — captured bodies are JSON or SSE text,
    # both UTF-8 by the time mitmproxy hands them to us. Stored AFTER
    # redaction; reads return exactly what was written.
    request_body: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_body: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Original byte sizes (pre-truncation, pre-redaction). Lets the dashboard
    # surface "captured 124 KB / 1.2 MB" without re-decoding the stored body.
    request_body_bytes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    response_body_bytes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Content types as observed in the request/response headers. Useful for
    # downstream tooling to know whether the body is JSON, SSE, or other.
    request_content_type: Mapped[str | None] = mapped_column(String(255), nullable=True)
    response_content_type: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Capture-status flags. Each is independent; all default False.
    request_truncated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    response_truncated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    # Reserved for the failure mode where mitmproxy delivered a short/empty
    # body but the request status was 200 (the upstream cut out). Under the
    # daemon's pure-buffer assumption this should be rare; still recorded so
    # downstream consumers can distinguish "we truncated" from "they did".
    streaming_incomplete: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    redaction_applied: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    # Free-form short reason when something went wrong during capture. None
    # on the happy path. Examples: "request_decode_failed",
    # "response_decode_failed", "redaction_failed", "binary_body_skipped".
    capture_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Counts of redactions applied, by category. Stored as JSON map
    # (TEXT — SQLite JSON1 backs it) for forward compatibility: a new
    # credential category can ship without a schema change.
    # Example: {"openai_key": 1, "jwt": 2}.
    redaction_summary: Mapped[str | None] = mapped_column(Text, nullable=True)

    captured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=_utcnow,
        index=True,
    )

    # Body-sync upload watermark (v0.2.2). Set when the BodyUploader has
    # successfully POSTed BOTH the request and response legs (where present)
    # to the cloud. NULL = not yet uploaded; the uploader's batch loader
    # selects strictly on ``uploaded_at IS NULL`` and marks rows as it
    # ships them. Per-project ``upload=false`` rows also get stamped (so
    # the cursor advances) but the worker never opens a network connection
    # for them — see ``halton_meter.cloud.body_uploader``.
    uploaded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        index=True,
    )

    request: Mapped[Request] = relationship(
        "Request",
        back_populates="body",
    )

    __table_args__ = (
        Index("idx_request_bodies_captured_at", "captured_at"),
        # Composite predicate index pattern: filtering on ``uploaded_at IS NULL``
        # is the hot path for the body uploader. A plain index on the column is
        # enough because the typical post-cleanup workload has most rows
        # uploaded (uploaded_at IS NOT NULL) — a scan of NULL-only rows is fast.
        Index("idx_request_bodies_uploaded_at", "uploaded_at"),
    )
