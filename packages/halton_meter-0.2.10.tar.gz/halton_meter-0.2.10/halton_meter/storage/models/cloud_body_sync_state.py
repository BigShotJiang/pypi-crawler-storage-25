"""CloudBodySyncState model — forward-declared body-sync cursor (v0.2.1).

Mirrors :class:`CloudSyncState` but for the body-upload cursor. Bodies have
their own pacing; a stuck body upload must never block metadata sync.

This table is created in v0.2.0 (Wave 1A.i) so the v0.2.1 body worker can
land without a schema migration. It stays empty until the body worker
exists. See:

  * memory/plans/phase2-wire-contract.md §2 (deferred body endpoint)
  * memory/plans/phase2-daemon-changes.md §1d
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from halton_meter.storage.models.base import Base


class CloudBodySyncState(Base):
    __tablename__ = "cloud_body_sync_state"

    endpoint: Mapped[str] = mapped_column(String(512), primary_key=True)

    last_synced_body_request_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True
    )
    last_synced_recorded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    consecutive_failures: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    paused_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
