"""CloudState model — connection / auth visibility for the cloud sync.

Separate from ``cloud_sync_state`` (the cursor table) because this row outlives
token rotations: when the daemon rotates its API key, the cursor stays valid
but the auth fingerprint changes.

See:
  * memory/plans/phase2-wire-contract.md §4 (pinned to SHA e8f252a)
  * memory/plans/phase2-daemon-changes.md §1c

Encryption posture: the raw API key never lives in SQLite. We store an
encrypted ciphertext (Fernet, AES-128-CBC + HMAC-SHA256) for the cases
where the daemon's encrypted token store is the source of truth, plus a
SHA-256 fingerprint (full hash, never the bytes) for audit display. The
canonical home for the *clear* key remains ``~/.halton-meter/config.toml``
(chmod 600); the ciphertext column lets a future v0.3 move the canonical
home into the DB without a schema migration.

Single-row in practice (one cloud endpoint per daemon today).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, LargeBinary, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from halton_meter.storage.models.base import Base


class CloudState(Base):
    __tablename__ = "cloud_state"

    endpoint: Mapped[str] = mapped_column(String(512), primary_key=True)

    # Pairing surface (filled in by ``halton-meter cloud connect``).
    workspace_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    workspace_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    machine_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    hostname_reported: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # API-key ciphertext. Fernet token (libsodium-equivalent: AES-128 CBC +
    # HMAC-SHA256, URL-safe-b64 encoded). Decryption key lives at
    # ``~/.halton-meter/cloud.key`` (chmod 600) and is generated on first
    # ``cloud connect``. NULL when the daemon has no key bound yet.
    api_key_ciphertext: Mapped[bytes | None] = mapped_column(
        LargeBinary, nullable=True
    )
    # Full SHA-256 hex of the raw key. Used for audit / log lines so we never
    # need to display the token itself. 64 hex chars.
    api_key_fingerprint: Mapped[str | None] = mapped_column(
        String(64), nullable=True
    )

    # Base URL is duplicated from ``endpoint`` for backwards-compat with the
    # config.toml world where the operator can override the endpoint without
    # touching the primary key. Today they will always match; tomorrow they
    # may diverge for blue/green endpoint cutover.
    base_url: Mapped[str | None] = mapped_column(String(512), nullable=True)

    # Master switch. Mirrors ``config.cloud.enabled``. The cursor worker
    # checks this column on every tick so a CLI ``cloud pause`` takes effect
    # without restarting the daemon.
    enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )

    connected_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Auth health. ``paused_reason`` mirrors the equivalent field on
    # ``cloud_sync_state`` so the CLI can answer "why is cloud off?"
    # without joining tables.
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    paused_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
