"""Graceful shutdown sentinel management (v0.1.16 Issue #1).

When the user runs `halton-meter stop` or `halton-meter uninstall`, we write
a sentinel file (~/.halton-meter/graceful-shutdown) to signal that metering
should not auto-restart on reboot.

On daemon startup, we check:
  * If sentinel exists and is recent (< 30 seconds), stay down (respect user's intent)
  * If sentinel exists but is old (> 30 seconds), delete it (assume stale leftover)
  * If sentinel doesn't exist, proceed normally (auto-recovery on reboot is OK)

This prevents surprising the user with auto-restart after they deliberately
stopped the daemon, while still allowing normal recovery if the system crashes
before they re-enable metering.
"""

from __future__ import annotations

import time
from pathlib import Path

import structlog

log = structlog.get_logger()

GRACEFUL_SHUTDOWN_SENTINEL_PATH = Path("~/.halton-meter/graceful-shutdown").expanduser()
GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS = 30


def write_graceful_shutdown_sentinel() -> None:
    """Write the graceful shutdown sentinel file.

    Called by `halton-meter stop` and `halton-meter uninstall` to indicate
    that metering is deliberately paused and should not auto-restart on reboot.
    """
    try:
        GRACEFUL_SHUTDOWN_SENTINEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        GRACEFUL_SHUTDOWN_SENTINEL_PATH.write_text(
            f"{time.time()}\n", encoding="utf-8"
        )
        log.info("lifecycle.graceful_shutdown_sentinel_written")
    except Exception as exc:
        log.error(
            "lifecycle.graceful_shutdown_sentinel_write_failed",
            error=str(exc),
            exc_info=True,
        )


def clear_graceful_shutdown_sentinel() -> None:
    """Remove the graceful-shutdown sentinel if present.

    Invoked by user-driven start paths (``halton-meter init`` and
    ``halton-meter start``) so a sentinel left behind by a preceding
    ``stop``/``uninstall`` does not silently make the freshly-kickstarted
    daemon exit-on-startup inside the 30-second suppression window. Without
    this clear, rapid ``uninstall && init --apps`` cycles (or
    ``stop && start``) all fall inside the 30s window: the daemon spawns,
    sees the recent sentinel, exits "graceful_shutdown_active", and the
    self-test times out on /health. See ``decisions.md`` 2026-05-06 —
    "v0.1.22 graceful-shutdown sentinel blocks rapid init/start retry".

    Best-effort: a missing file is fine; an OSError is logged and
    swallowed (the install/start path must continue regardless).
    """
    try:
        GRACEFUL_SHUTDOWN_SENTINEL_PATH.unlink(missing_ok=True)
        log.info("lifecycle.graceful_shutdown_sentinel_cleared")
    except OSError as exc:
        log.warning(
            "lifecycle.graceful_shutdown_sentinel_clear_failed",
            error=str(exc),
        )


def check_graceful_shutdown_sentinel() -> bool:
    """Return True if the daemon should stay down due to graceful shutdown.

    Returns True if:
      * Sentinel exists AND
      * Is recent (< GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS)

    If sentinel exists but is old, deletes it and returns False (assume stale).
    If sentinel doesn't exist, returns False (normal operation).
    """
    if not GRACEFUL_SHUTDOWN_SENTINEL_PATH.exists():
        return False

    try:
        mtime = GRACEFUL_SHUTDOWN_SENTINEL_PATH.stat().st_mtime
        age_seconds = time.time() - mtime
        is_recent = age_seconds < GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS

        if is_recent:
            log.info(
                "daemon.graceful_shutdown_active",
                age_seconds=age_seconds,
                timeout_seconds=GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS,
            )
            return True

        # Sentinel is old; clean it up and proceed
        GRACEFUL_SHUTDOWN_SENTINEL_PATH.unlink(missing_ok=True)
        log.info(
            "daemon.graceful_shutdown_sentinel_expired",
            age_seconds=age_seconds,
            timeout_seconds=GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS,
        )
        return False
    except Exception as exc:
        log.error(
            "daemon.graceful_shutdown_check_failed",
            error=str(exc),
            exc_info=True,
        )
        # Defensive: assume we should proceed rather than staying down
        return False
