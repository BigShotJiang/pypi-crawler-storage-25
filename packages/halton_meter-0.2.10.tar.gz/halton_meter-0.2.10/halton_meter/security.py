"""
Security guards for Halton Meter daemon startup.

All checks here must run before any socket is opened.  Failures raise
``SystemExit`` so the daemon process exits with a non-zero code and a clear
human-readable message — not a Python traceback.
"""

from __future__ import annotations

import os
import socket
import sys

import structlog

log = structlog.get_logger(__name__)

# Addresses that are always permitted regardless of the override env var.
_LOOPBACK_IPS: frozenset[str] = frozenset({"127.0.0.1", "::1"})

# Env var that relaxes the loopback-only constraint.  Intended for
# containerised or VPN environments where the operator knowingly binds to
# a non-loopback interface.
_ALLOW_NON_LOOPBACK_ENV = "HALTON_METER_ALLOW_NON_LOOPBACK"


def _resolve_host(host: str) -> str:
    """Return the first IP address that ``host`` resolves to.

    Uses ``socket.getaddrinfo`` so the result honours ``/etc/hosts``,
    mDNS, and any other resolver the OS uses.  Returns the *string*
    representation of the address (dotted-decimal IPv4 or colon-hex IPv6).
    """
    results = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    if not results:
        raise OSError(f"getaddrinfo returned no results for {host!r}")
    # results[i] = (family, type, proto, canonname, sockaddr)
    # sockaddr for IPv4 = (address, port); for IPv6 = (address, port, flowinfo, scope_id)
    return results[0][4][0]


def _assert_loopback_bind(listen_host: str, api_host: str) -> None:
    """Hard-refuse startup if either host resolves to a non-loopback address.

    The daemon binds two surfaces:
      * the mitmproxy listener (``listen_host`` — ``daemon.listen_host`` in
        config, defaults to ``127.0.0.1``).
      * the FastAPI HTTP API (``api_host`` — ``daemon.api_host`` in config,
        defaults to ``127.0.0.1``).

    Both must resolve to a loopback address (``127.0.0.1`` or ``::1``).
    Binding to ``0.0.0.0`` or any routable IP would expose TLS-intercepted
    traffic and the management API to the local network — a hard security
    boundary violation.

    Escape hatch for containers / VPNs:
      Set ``HALTON_METER_ALLOW_NON_LOOPBACK=1`` in the process environment.
      A WARNING is logged and startup continues.  This env var must be
      set deliberately — it is never written by the daemon itself.

    Args:
        listen_host: The host the mitmproxy listener will bind to.
        api_host:    The host the FastAPI app will bind to.

    Raises:
        SystemExit: Exit code 1 if either host resolves to a non-loopback
            address and the override env var is not set.
    """
    hosts_to_check = [
        ("daemon.listen_host", listen_host),
        ("daemon.api_host", api_host),
    ]

    override = bool(os.environ.get(_ALLOW_NON_LOOPBACK_ENV, "").strip())

    for field_name, host in hosts_to_check:
        try:
            resolved_ip = _resolve_host(host)
        except OSError as exc:
            # Resolution failure is treated as non-loopback to be safe.
            # The daemon cannot safely bind without knowing where it lands.
            msg = (
                f"Daemon cannot resolve {field_name}={host!r}: {exc}. "
                "Set HALTON_METER_ALLOW_NON_LOOPBACK=1 to skip this check."
            )
            if override:
                log.warning(
                    "security.loopback_check.resolution_failed_override",
                    field=field_name,
                    host=host,
                    error=str(exc),
                )
                continue
            print(msg, file=sys.stderr)
            sys.exit(1)

        if resolved_ip in _LOOPBACK_IPS:
            log.debug(
                "security.loopback_check.passed",
                field=field_name,
                host=host,
                resolved=resolved_ip,
            )
            continue

        # Non-loopback address detected.
        msg = (
            f"Daemon refuses to bind to {host!r} (resolved: {resolved_ip}) — "
            f"only loopback addresses are permitted. "
            f"Set HALTON_METER_ALLOW_NON_LOOPBACK=1 to override."
        )

        if override:
            log.warning(
                "security.loopback_check.non_loopback_override",
                field=field_name,
                host=host,
                resolved=resolved_ip,
            )
        else:
            print(msg, file=sys.stderr)
            sys.exit(1)
