"""Platform-agnostic helpers for ``halton_meter.setup``.

v0.1.22.18 Fix 3 — added :func:`certifi_already_contains_ca`, the
single-source-of-truth idempotency check shared by the install-side
``patch_certifi`` and ``doctor``. Pre-fix both call sites were
implemented separately; even though they consulted the same predicate,
extracting the check here makes the contract explicit and forecloses
future drift.
"""

from __future__ import annotations

from pathlib import Path

# Marker line written into the certifi bundle alongside the appended CA
# cert. Kept here (not in ``_macos``) because both the install path and
# the doctor path consult it, and Linux will share the same wire format
# in v0.1.23+. Imported into ``_macos`` for backwards compatibility.
CERTIFI_MARKER = "# halton-meter mitmproxy CA cert appended by halton-meter setup"


def certifi_already_contains_ca(
    ca_pem_path: Path,
    certifi_bundle_path: Path,
) -> bool:
    """Return True iff the certifi bundle already carries the current
    mitmproxy CA cert verbatim.

    v0.1.22.18 Fix 3 — single source of truth for the
    "is the certifi bundle patched?" question, shared by:

    * :func:`halton_meter.setup._macos.patch_certifi` — install-side
      idempotency gate (skips appending when this returns True).
    * :func:`halton_meter.setup._macos._is_certifi_patched` — the
      doctor-side check (which doctor calls directly).

    Idempotency contract:

    1. Bundle file must exist (a missing certifi bundle is unpatched
       by definition; ``pipx --force`` re-creates the venv → fresh
       bundle on disk → previous patch is gone → must re-patch).
    2. The marker comment must be present (cheap fast-path; bundles
       we never touched skip the body comparison).
    3. The CURRENT CA cert body (from disk) must appear verbatim in
       the bundle (catches the stale-marker drift case where the CA
       was rotated but the bundle still carries the old body).

    The CA cert PEM is read fresh on every call. ``.strip()`` is
    applied symmetrically to both sides — not to the bundle (the
    substring search is what does the alignment) but to the cert
    body so trailing newlines from the disk file don't cause a false
    miss when the bundle was appended without them.

    Returns False on any exception (missing path, decode error, etc).
    Never raises — callers treat False as "not patched, please patch".
    """
    try:
        if not certifi_bundle_path.exists():
            return False
        if not ca_pem_path.exists():
            # No CA on disk -> we cannot prove the bundle has the
            # current cert body. Conservatively treat as unpatched so
            # ``patch_certifi`` re-runs once the cert is regenerated.
            return False
        bundle_text = certifi_bundle_path.read_text(encoding="utf-8")
        if CERTIFI_MARKER not in bundle_text:
            return False
        cert_body = ca_pem_path.read_text(encoding="utf-8").strip()
        if not cert_body:
            return False
        return cert_body in bundle_text
    except Exception:
        return False


def revert_certifi_patch(certifi_bundle_path: Path) -> bool:
    """Strip the halton-meter mitmproxy CA block from the certifi bundle.

    v0.1.23 Blocker 4: uninstall must leave the certifi bundle byte-clean
    so a subsequent ``pipx install halton-meter && halton-meter init``
    reaches a deterministic post-install state regardless of how many
    install/uninstall cycles preceded it.

    The block written by :func:`patch_certifi` is::

        \\n{CERTIFI_MARKER}\\n
        <PEM body><trailing newline if missing in source>

    Implementation: read the bundle, locate the marker line, find the
    end-of-PEM (``-----END CERTIFICATE-----``) after it, and excise
    everything from the leading newline up through and including the
    PEM trailer line + its newline. Idempotent — returns ``False`` when
    no marker is present (nothing to do) and ``True`` when at least one
    block was removed. Never raises (uninstall is best-effort).
    """
    try:
        if not certifi_bundle_path.exists():
            return False
        text = certifi_bundle_path.read_text(encoding="utf-8")
        if CERTIFI_MARKER not in text:
            return False
        end_token = "-----END CERTIFICATE-----"
        changed = False
        while CERTIFI_MARKER in text:
            marker_idx = text.find(CERTIFI_MARKER)
            # Include the leading newline (the marker is preceded by
            # ``"\\n"`` in patch_certifi).
            block_start = (
                marker_idx - 1
                if marker_idx > 0 and text[marker_idx - 1] == "\n"
                else marker_idx
            )
            end_idx = text.find(end_token, marker_idx)
            if end_idx == -1:
                # Malformed block — strip from marker to EOF defensively
                # so a future run does not see a half-block.
                text = text[:block_start]
            else:
                # Cut up to and including the END line + its trailing
                # newline (if any).
                cut_end = end_idx + len(end_token)
                if cut_end < len(text) and text[cut_end] == "\n":
                    cut_end += 1
                text = text[:block_start] + text[cut_end:]
            changed = True
        if changed:
            certifi_bundle_path.write_text(text, encoding="utf-8")
        return changed
    except Exception:
        return False
