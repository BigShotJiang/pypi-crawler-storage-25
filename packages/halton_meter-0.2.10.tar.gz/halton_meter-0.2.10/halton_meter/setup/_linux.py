"""Linux apps-mode implementation for ``halton_meter.setup``.

**v0.1.22.5 — UNTESTED on real Linux.** Subprocess-mocked unit tests only.

Forwards every name from :mod:`halton_meter.setup._macos`. The shared
module's public surface (``run_setup``, ``check_steps``,
``generate_mitmproxy_cert``, ``patch_certifi``) is platform-aware —
on non-macOS systems the keychain-trust step returns a "Not yet
supported" :class:`StepStatus` rather than failing. Apps-mode users
rely on the certifi-patched bundle (which every Python LLM client
honours via ``urllib3``/``requests``); transparent system-trust-store
install is deferred to the proper Linux phase.

``trust_cert_macos`` is re-exported as a no-op stub so callers that
unconditionally invoke it (e.g. ``halton-meter doctor``) don't crash.
"""

from __future__ import annotations

import types as _types

from . import _macos as _macos_impl

_globals = globals()
for _name in dir(_macos_impl):
    if _name.startswith("__"):
        continue
    _attr = getattr(_macos_impl, _name)
    if isinstance(_attr, _types.ModuleType):
        continue
    _globals[_name] = _attr
del _globals, _name, _attr


def trust_cert_linux(*, force: bool = False) -> object:
    """Stub: Linux system-trust-store install is deferred.

    Apps mode does not require system-wide trust — Python clients pick
    up the cert via the certifi-patched bundle. Returns a "deferred"
    :class:`StepStatus` so the doctor / setup output reads honestly.
    """
    from ._macos import StepStatus

    return StepStatus(
        name="Trust cert in system store",
        done=False,
        note=(
            "Linux apps-mode: system trust-store install deferred. "
            "Python clients use the certifi-patched bundle directly."
        ),
    )
