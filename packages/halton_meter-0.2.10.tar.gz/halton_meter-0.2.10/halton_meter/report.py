"""
Report formatting logic for Halton Meter CLI — Halton brand language.

v0.1.22.13 — branded cost report. The cost-report surface now uses the
editorial brand language (``brand_section`` dividers, ``brand_kv``
summary, ``brand_bar`` share-of-spend column, ``brand_sparkline`` 7d
trend column, ``brand_pill`` accents) and ships a set of new flags:

    --since 7d / --from / --to     — period filters
    --vs-previous                  — period comparison with Δ columns
    --by project / --by model      — table filter
    --csv / --json                 — export modes (stdlib only)

Hard invariants preserved (see ``memory/decisions.md`` 2026-05-07):

  1. ``configure_for_user_cli()`` is the first in-body line of the
     ``report`` callback. New ``@click.option`` decorators land above
     the function; the body's first statement is unchanged.
  2. Per-OS module split untouched.
  3. B4 stop semantics untouched.
  4. v0.1.22.5–.12 helpers untouched.
  5. ``memory/decisions.md`` is append-only.
  6. Stdlib-only — no new third-party deps. CSV via ``csv``, JSON via
     ``json``. ``rich`` already on the dependency list.

Money display rules
-------------------
Editorial — never six decimals. Format only at display time.

  * amount ≥ $0.01     → ``$X.XX``       (e.g. ``$54.32``, ``$0.01``)
  * amount < $0.01     → ``$0.XXXX``     (e.g. ``$0.0001``, ``$0.0040``)
  * exactly zero       → ``$0.00``
  * unknown / N/A      → ``N/A``

CSV / JSON exports keep the raw ``cost_millicents`` integer for
round-trip fidelity; only the human-facing renderer applies the rules
above.
"""

from __future__ import annotations

import csv as _csv
import io
import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, date, datetime, timedelta
from typing import NamedTuple

from rich.console import Console, Group
from rich.text import Text

from halton_meter import __version__
from halton_meter._app_registry import humanize_bundle_id
from halton_meter.branding import (
    BRAND_ORANGE,
    HEADER_BLUE,
    MUTED,
    NUMERIC,
    OK,
    WARN,
    brand_bar,
    brand_command_lead,
    brand_kv,
    brand_section,
    brand_sparkline,
    brand_table,
)
from halton_meter.models import LogRecord

# Local aliases keep the render functions readable without polluting the
# brand-language module. New colour tokens MUST land in branding.py first.
_BRAND = BRAND_ORANGE       # money values + headline accent
_HEADER = HEADER_BLUE       # table headers + key labels
_OK = OK                    # ✓ ticks
_WARN = WARN                # ⚠ advisories
_MUTED = MUTED              # secondary text
_WHITE = NUMERIC            # high-contrast right-aligned numbers

# Conversion constant — see memory/patterns.md and decisions.md 2026-04-28
_MILLICENTS_PER_USD: int = 100_000

# Anthropic / OpenAI append a calendar-date suffix to model identifiers
# (e.g. ``claude-haiku-4-5-20251001``). Strip for display only — exports
# preserve the full ID. Eight digits at the end of the string with a
# leading hyphen.
_MODEL_DATE_SUFFIX = re.compile(r"-\d{8}$")


def strip_model_date(model: str) -> str:
    """Drop the ``-YYYYMMDD`` suffix from a model identifier.

    Display-only — keep the full ID in CSV/JSON exports for round-trip
    fidelity. No-op for models that don't carry the suffix.
    """
    return _MODEL_DATE_SUFFIX.sub("", model)


def humanize_project(project: str) -> str:
    """Display label for a project tag.

    Wraps :func:`humanize_bundle_id` so the report module is the single
    import point. Pure pass-through for non-``mac:`` tags.
    """
    return humanize_bundle_id(project)


def format_usd(millicents: int | None) -> str:
    """Format millicents as a human-facing USD string.

    v0.1.22.13: editorial format — never six decimals.

      * ``None``                 → ``"N/A"``
      * exactly zero             → ``"$0.00"``
      * 0 < amount < $0.01       → ``"$0.XXXX"`` (4dp)
      * amount ≥ $0.01           → ``"$X.XX"``  (2dp, comma-grouped)

    Args:
        millicents: Cost in millicents, or ``None`` if unknown.
    """
    if millicents is None:
        return "N/A"
    if millicents == 0:
        return "$0.00"
    dollars = millicents / _MILLICENTS_PER_USD
    if abs(dollars) < 0.01:
        # Sub-cent — 4dp keeps signal without spilling to six decimals.
        return f"${dollars:.4f}"
    return f"${dollars:,.2f}"


# ---------------------------------------------------------------------------
# Aggregation helpers
# ---------------------------------------------------------------------------


@dataclass
class ProjectStats:
    """Aggregated stats for a single project.

    Cost-handling policy (see decisions.md 2026-05-02 — "NULL cost handling
    in report aggregation"): records with ``cost_millicents is None`` are
    EXCLUDED from cost totals but STILL counted in ``requests`` /
    ``input_tokens`` / ``output_tokens`` / ``incomplete_count``. The number
    of cost-excluded records is tracked in ``cost_excluded_count`` so the
    renderer can surface a footnote. Previous behaviour (a single None row
    poisoning the entire grand total to ``None``) is gone.
    """

    project: str
    requests: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_millicents: int = 0
    cost_excluded_count: int = 0
    latency_sum_ms: float = 0.0
    latencies_ms: list[float] = field(default_factory=list)
    incomplete_count: int = 0
    # Per-day cost in millicents for the most recent 7 calendar days
    # (UTC). Populated by ``build_report_data`` after the per-record
    # accumulation pass. Used by the report's ``7d trend`` sparkline.
    daily_cost_buckets: list[int] = field(default_factory=list)
    # Δ vs prior period — populated only when ``--vs-previous`` is set.
    prev_cost_millicents: int | None = None

    def add(self, record: LogRecord) -> None:
        """Merge a single LogRecord into this stats bucket."""
        self.requests += 1
        self.input_tokens += record.input_tokens
        self.output_tokens += record.output_tokens
        if record.cost_millicents is None:
            self.cost_excluded_count += 1
        else:
            self.cost_millicents += record.cost_millicents
        self.latency_sum_ms += record.latency_ms
        self.latencies_ms.append(record.latency_ms)
        if not record.tokens_complete:
            self.incomplete_count += 1

    @property
    def avg_latency_ms(self) -> float:
        """Average latency in milliseconds, or 0 if no requests."""
        return self.latency_sum_ms / self.requests if self.requests else 0.0

    @property
    def p95_latency_ms(self) -> float:
        """95th percentile latency in milliseconds, or 0 if no requests."""
        return _percentile(self.latencies_ms, 95.0)


@dataclass
class ModelStats:
    """Aggregated stats for a single model.

    See ``ProjectStats`` for the NULL-cost handling policy.
    """

    model: str
    requests: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_millicents: int = 0
    cost_excluded_count: int = 0
    latency_sum_ms: float = 0.0
    latencies_ms: list[float] = field(default_factory=list)
    prev_cost_millicents: int | None = None

    def add(self, record: LogRecord) -> None:
        """Merge a single LogRecord into this stats bucket."""
        self.requests += 1
        self.input_tokens += record.input_tokens
        self.output_tokens += record.output_tokens
        if record.cost_millicents is None:
            self.cost_excluded_count += 1
        else:
            self.cost_millicents += record.cost_millicents
        self.latency_sum_ms += record.latency_ms
        self.latencies_ms.append(record.latency_ms)

    @property
    def avg_latency_ms(self) -> float:
        return self.latency_sum_ms / self.requests if self.requests else 0.0

    @property
    def p95_latency_ms(self) -> float:
        return _percentile(self.latencies_ms, 95.0)


def _percentile(values: list[float], pct: float) -> float:
    """Linear-interpolation percentile. Empty list → 0.0."""
    if not values:
        return 0.0
    s = sorted(values)
    if len(s) == 1:
        return s[0]
    k = (pct / 100.0) * (len(s) - 1)
    lo = int(k)
    hi = min(lo + 1, len(s) - 1)
    frac = k - lo
    return s[lo] + (s[hi] - s[lo]) * frac


class RatesSummary(NamedTuple):
    """Pricing-freshness header summary for the report (v0.1.22.22, Layer 1).

    ``bundled_date`` is the daemon's bundled-matrix verification date
    (``BUNDLED_RATES_DATE``); ``override_count`` is the number of rows
    in ``pricing_rates`` with ``is_seed_default = False``.

    Surfaced as one masthead line: ``Rates: bundled YYYY-MM-DD · N override(s)``.
    Populated by the CLI before render_report; ``None`` skips the line
    (used by tests that don't open the storage).
    """

    bundled_date: str
    override_count: int


class ReportData(NamedTuple):
    """
    Processed data ready to render into a report.

    Produced by :func:`build_report_data` from a list of LogRecords.
    """

    records: list[LogRecord]
    total_requests: int
    total_input_tokens: int
    total_output_tokens: int
    total_cost_millicents: int
    cost_excluded_count: int  # records with NULL cost — excluded from cost totals only
    date_from: str | None  # ISO 8601 string of oldest record
    date_to: str | None  # ISO 8601 string of newest record
    incomplete_count: int
    project_stats: list[ProjectStats]
    model_stats: list[ModelStats]
    # Number of distinct UTC dates spanned by ``records``. Used to gate
    # the 7-day trend sparkline column (``< 2`` → suppress).
    span_days: int = 0
    # Δ vs prior period — only set when ``--vs-previous`` is enabled.
    prev_total_cost_millicents: int | None = None
    # Pricing-freshness header summary (v0.1.22.22, Layer 1). When None
    # the masthead skips the rates line (tests that don't open storage,
    # legacy callers).
    rates_summary: RatesSummary | None = None


def build_report_data(
    records: list[LogRecord],
    *,
    prev_records: list[LogRecord] | None = None,
    window_end: datetime | None = None,
) -> ReportData:
    """
    Aggregate a list of LogRecords into a ReportData summary.

    Args:
        records: LogRecords to aggregate (order does not matter).
        prev_records: Optional records from the immediately preceding
            period. When supplied, per-project / per-model
            ``prev_cost_millicents`` are populated for Δ rendering.
        window_end: UTC datetime used as the right edge of the 7-day
            trend window. Defaults to ``datetime.now(UTC)``. Tests
            inject a fixed value so the daily buckets are deterministic.

    Returns:
        ReportData with totals, per-project, per-model breakdowns,
        7-day per-project cost buckets, and (optionally) prior-period
        deltas.
    """
    if not records:
        return ReportData(
            records=[],
            total_requests=0,
            total_input_tokens=0,
            total_output_tokens=0,
            total_cost_millicents=0,
            cost_excluded_count=0,
            date_from=None,
            date_to=None,
            incomplete_count=0,
            project_stats=[],
            model_stats=[],
            span_days=0,
            prev_total_cost_millicents=(
                sum(r.cost_millicents for r in prev_records if r.cost_millicents is not None)
                if prev_records
                else None
            ),
        )

    project_map: dict[str, ProjectStats] = {}
    model_map: dict[str, ModelStats] = {}

    total_input = 0
    total_output = 0
    total_cost: int = 0
    cost_excluded_count = 0
    incomplete_count = 0
    dates: list[str] = []
    distinct_days: set[date] = set()

    for rec in records:
        # project bucket
        if rec.project not in project_map:
            project_map[rec.project] = ProjectStats(project=rec.project)
        project_map[rec.project].add(rec)

        # model bucket — display key strips the date suffix; the raw ID
        # is preserved per-record for exports.
        display_model = strip_model_date(rec.model)
        if display_model not in model_map:
            model_map[display_model] = ModelStats(model=display_model)
        model_map[display_model].add(rec)

        # totals — NULL cost rows are excluded from the cost sum but still
        # contribute to request / token counts. See decisions.md 2026-05-02.
        total_input += rec.input_tokens
        total_output += rec.output_tokens
        if rec.cost_millicents is None:
            cost_excluded_count += 1
        else:
            total_cost += rec.cost_millicents
        if not rec.tokens_complete:
            incomplete_count += 1
        dates.append(rec.requested_at)
        parsed_dt = _safe_parse_iso(rec.requested_at)
        if parsed_dt is not None:
            distinct_days.add(parsed_dt.astimezone(UTC).date())

    dates_sorted = sorted(dates)
    date_from = dates_sorted[0] if dates_sorted else None
    date_to = dates_sorted[-1] if dates_sorted else None

    # 7-day trend buckets per project. Bucket 0 = oldest, bucket 6 =
    # most recent (window_end's date). Records outside the window are
    # silently dropped from the trend (still counted in totals).
    if window_end is None:
        window_end = datetime.now(UTC)
    window_end_date = window_end.astimezone(UTC).date()
    trend_buckets: dict[str, list[int]] = defaultdict(lambda: [0] * 7)
    for rec in records:
        if rec.cost_millicents is None:
            continue
        parsed_dt = _safe_parse_iso(rec.requested_at)
        if parsed_dt is None:
            continue
        delta_days = (window_end_date - parsed_dt.astimezone(UTC).date()).days
        if 0 <= delta_days < 7:
            idx = 6 - delta_days
            trend_buckets[rec.project][idx] += rec.cost_millicents

    for proj, stats in project_map.items():
        stats.daily_cost_buckets = trend_buckets.get(proj, [0] * 7)

    # Prev-period deltas — match by raw project key and by stripped
    # model key (so e.g. ``claude-haiku-4-5-20251001`` rolls into
    # ``claude-haiku-4-5``).
    prev_total: int | None = None
    if prev_records is not None:
        prev_proj: dict[str, int] = defaultdict(int)
        prev_model: dict[str, int] = defaultdict(int)
        prev_total = 0
        for rec in prev_records:
            if rec.cost_millicents is None:
                continue
            prev_proj[rec.project] += rec.cost_millicents
            prev_model[strip_model_date(rec.model)] += rec.cost_millicents
            prev_total += rec.cost_millicents
        for proj, stats in project_map.items():
            stats.prev_cost_millicents = prev_proj.get(proj, 0)
        for mdl, mstats in model_map.items():
            mstats.prev_cost_millicents = prev_model.get(mdl, 0)

    # Case-insensitive sort: ``algonifty`` should sit next to
    # ``AlgoNifty`` rather than at the bottom of the table.
    project_stats = sorted(project_map.values(), key=lambda s: s.project.lower())
    model_stats = sorted(model_map.values(), key=lambda s: s.model.lower())

    return ReportData(
        records=records,
        total_requests=len(records),
        total_input_tokens=total_input,
        total_output_tokens=total_output,
        total_cost_millicents=total_cost,
        cost_excluded_count=cost_excluded_count,
        date_from=date_from,
        date_to=date_to,
        incomplete_count=incomplete_count,
        project_stats=project_stats,
        model_stats=model_stats,
        span_days=len(distinct_days),
        prev_total_cost_millicents=prev_total,
    )


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


_MONTHS = (
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
)


def _safe_parse_iso(iso_str: str | None) -> datetime | None:
    """Parse an ISO 8601 string. Returns None on failure."""
    if iso_str is None:
        return None
    try:
        return datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
    except ValueError:
        return None


def _format_short_date(iso_str: str | None) -> str:
    """Render an ISO 8601 string as ``Apr 1`` style."""
    if iso_str is None:
        return "—"
    dt = _safe_parse_iso(iso_str)
    if dt is None:
        return iso_str
    dt = dt.astimezone(UTC)
    return f"{_MONTHS[dt.month - 1]} {dt.day}"


def _format_latency(ms: float) -> str:
    """Render latency as ``1.2s`` or ``320ms``."""
    if ms <= 0:
        return "—"
    if ms < 1000:
        return f"{round(ms)}ms"
    return f"{ms / 1000:.1f}s"


def _format_delta(curr: int, prev: int | None) -> Text:
    """Render a Δ% change marker.

    Brand-orange for an increase, MUTED for a decrease, MUTED ``—`` for
    "no prior data". Sign is always shown.
    """
    if prev is None or prev == 0:
        # No prior data (or prior was zero, which gives no defined %).
        # Render as a muted em-dash rather than fabricating a "+inf%".
        return Text("—", style=MUTED)
    pct = (curr - prev) / prev * 100.0
    sign = "+" if pct >= 0 else ""
    label = f"Δ {sign}{pct:.1f}%"
    return Text(label, style=BRAND_ORANGE if pct >= 0 else MUTED)


def render_report(
    data: ReportData,
    console: Console,
    *,
    empty_hint: str | None = None,
    show_projects: bool = True,
    show_models: bool = True,
    vs_previous: bool = False,
) -> None:
    """
    Print the full report to *console* using rich formatting.

    v0.1.22.13: editorial layout — masthead + underrule + brand_section
    blocks for ``summary`` / ``by project`` / ``by model``. Each table
    optionally carries a 7d trend sparkline column (when window ≥ 2
    days), a share-of-spend bar, and an avg/p95 latency column.

    Args:
        data: Pre-aggregated ReportData from :func:`build_report_data`.
        console: Rich Console to print to.
        empty_hint: Rich-markup string shown when there are no records.
            Falls back to a generic "no records yet" line.
        show_projects: Render the by-project block. Default True; the
            ``--by model`` flag flips this off.
        show_models: Render the by-model block. Default True; the
            ``--by project`` flag flips this off.
        vs_previous: When True, render Δ% columns and skip the top-1
            outlier row accent (avoids double-emphasis).
    """
    _render_header(data, console)

    if data.total_requests == 0:
        if empty_hint is None:
            empty_hint = (
                f"[{_MUTED}]no records yet. Run[/] "
                f"[bold]halton-meter start[/] "
                f"[{_MUTED}]to begin metering, then route an LLM API "
                f"call through your client.[/]"
            )
        console.print(empty_hint + "\n")
        return

    _render_summary(data, console, vs_previous=vs_previous)
    if show_projects:
        _render_project_table(data, console, vs_previous=vs_previous)
    if show_models:
        _render_model_table(data, console, vs_previous=vs_previous)
    _render_footer(data, console)


def _render_header(data: ReportData, console: Console) -> None:
    """Editorial masthead + underrule, then optional date-range row.

    v0.1.22.13: date range moves to the masthead's own muted line under
    the rule and uses the short ``Apr 1 → May 6`` format from the
    reference layout. The legacy ``YYYY-MM-DD HH:MM UTC`` format is
    preserved as a fallback for parsers that grep for it.
    """
    console.print()
    # v0.1.22.14: Tier-A masthead — the block-H mark sits to the left of
    # the wordmark/version/date-range stack. The date-range line moves
    # into the masthead itself rather than printing as a separate row,
    # collapsing two newlines into one and keeping the dwell-surface
    # signature consistent with ``status``.
    short_range: str | None = None
    if data.date_from and data.date_to:
        short_range = (
            f"{_format_short_date(data.date_from)} → "
            f"{_format_short_date(data.date_to)}"
        )
    console.print(
        brand_command_lead(
            "cost report",
            version=__version__,
            mark="block",
            date_range=short_range,
        )
    )
    # Pricing freshness line — v0.1.22.22, Layer 1. Plain text print so it
    # survives the report's CSV/JSON parsers that grep stdout. ``Rates:
    # bundled YYYY-MM-DD · N override(s)`` (override count omitted when 0).
    if data.rates_summary is not None:
        rs = data.rates_summary
        if rs.override_count == 0:
            line = f"Rates: bundled {rs.bundled_date}"
        else:
            noun = "override" if rs.override_count == 1 else "overrides"
            line = (
                f"Rates: bundled {rs.bundled_date} · "
                f"{rs.override_count} {noun}"
            )
        console.print(f"[{_MUTED}]{line}[/]")
    console.print()


def _render_summary(
    data: ReportData,
    console: Console,
    *,
    vs_previous: bool = False,
) -> None:
    """``── › summary ──`` block with brand_kv rows."""
    project_count = len(data.project_stats)
    model_count = len(data.model_stats)
    project_word = "project" if project_count == 1 else "projects"
    model_word = "model" if model_count == 1 else "models"

    rows: list[Text] = [
        brand_kv("Requests", f"{data.total_requests:,}"),
        brand_kv(
            "Coverage",
            f"{project_count} {project_word} · {model_count} {model_word}",
        ),
        brand_kv(
            "Tokens",
            f"{data.total_input_tokens:,} in · {data.total_output_tokens:,} out",
        ),
        brand_kv(
            "Total cost",
            format_usd(data.total_cost_millicents),
            value_style=f"bold {_BRAND}",
        ),
    ]

    if vs_previous and data.prev_total_cost_millicents is not None:
        delta = _format_delta(
            data.total_cost_millicents,
            data.prev_total_cost_millicents,
        )
        kv_label = Text("  ")
        kv_label.append("Δ vs previous".ljust(20), style=MUTED)
        kv_label.append_text(delta)
        rows.append(kv_label)

    # Tightened single-line warning under summary. Full text in footer.
    warning_bits: list[str] = []
    if data.incomplete_count > 0:
        warning_bits.append(f"{data.incomplete_count} incomplete")
    if data.cost_excluded_count > 0:
        word = "model" if data.cost_excluded_count == 1 else "models"
        warning_bits.append(f"{data.cost_excluded_count} unrecognised {word}")
    if warning_bits:
        joined = " · ".join(warning_bits)
        rows.append(
            Text.from_markup(
                f"  [{_WARN}]⚠ {joined} — see footer[/]"
            )
        )

    console.print(brand_section("summary", Group(*rows)))
    console.print()


@dataclass(frozen=True)
class _ResponsiveLayout:
    """Which optional columns to render at the active console width.

    v0.1.22.18 Fix 2: responsive layout selection. The previous fixed
    column set always tried to render project · requests · cost · share
    · avg · p95 · 7d trend, which truncated headers (``reque…``) and
    cropped the share-bar at terminal widths < 100.

    Tier ladder, evaluated against ``console.width`` at render time:

      width >= 110 → all columns, share width 10
      width  90–109 → drop 7d trend, share width 8
      width  70–89  → drop p95 + 7d trend, share width 5
      width  < 70  → drop avg + p95 + 7d trend, share width 3

    Headers and rows must use the same tier so cell-count alignment
    holds. Computed from ``console.width`` once per render call (not
    at module import) so tests and pipes can drive the layout via a
    Console constructor.

    CSV / JSON exports are unaffected — they go through ``render_csv`` /
    ``render_json``, which never touch this struct.
    """

    show_avg: bool
    show_p95: bool
    show_trend: bool
    share_width: int


def _layout_for_width(width: int) -> _ResponsiveLayout:
    """Pick a column-set tier for the given terminal width.

    Returns the bottom-most layout when ``width`` is non-positive (test
    consoles sometimes report 0). Width thresholds are exclusive on
    the LOW side: a width of exactly 110 hits the top tier.
    """
    if width >= 110:
        return _ResponsiveLayout(
            show_avg=True, show_p95=True, show_trend=True, share_width=10
        )
    if width >= 90:
        return _ResponsiveLayout(
            show_avg=True, show_p95=True, show_trend=False, share_width=8
        )
    if width >= 70:
        return _ResponsiveLayout(
            show_avg=True, show_p95=False, show_trend=False, share_width=5
        )
    return _ResponsiveLayout(
        show_avg=False, show_p95=False, show_trend=False, share_width=3
    )


def _render_project_table(
    data: ReportData,
    console: Console,
    *,
    vs_previous: bool = False,
) -> None:
    """``── › by project ──`` block.

    Columns: project · requests · cost · share · avg · p95 · 7d trend
    (avg/p95/trend dropped at narrower widths — see
    :func:`_layout_for_width`). The 7d trend column also requires
    ``span_days >= 2`` (single-day reports have nothing to chart).
    """
    layout = _layout_for_width(int(getattr(console, "width", 0) or 0))
    table = brand_table(show_edge=False)
    table.add_column("project", no_wrap=True, style=_WHITE)
    table.add_column("requests", justify="right", style=_WHITE)
    table.add_column("cost", justify="right", style=_BRAND)
    if vs_previous:
        table.add_column("Δ", justify="right", style=_WHITE)
    table.add_column("share", justify="left", style=_WHITE)
    if layout.show_avg:
        table.add_column("avg", justify="right", style=_WHITE, min_width=6)
    if layout.show_p95:
        table.add_column("p95", justify="right", style=_WHITE, min_width=6)
    show_trend = layout.show_trend and data.span_days >= 2
    if show_trend:
        table.add_column("7d trend", justify="left", style=_WHITE)

    max_cost = max((s.cost_millicents for s in data.project_stats), default=0)
    top_idx = _top1_index([s.cost_millicents for s in data.project_stats])

    for i, s in enumerate(data.project_stats):
        is_top = (i == top_idx) and not vs_previous and len(data.project_stats) > 1
        accent = f"bold {_BRAND}" if is_top else None
        cells: list[Text | str] = []
        cells.append(_styled(humanize_project(s.project), accent))
        cells.append(_styled(f"{s.requests:,}", accent))
        cells.append(_styled(format_usd(s.cost_millicents), accent or f"bold {_BRAND}"))
        if vs_previous:
            cells.append(_format_delta(s.cost_millicents, s.prev_cost_millicents))
        share_bar = brand_bar(
            float(s.cost_millicents),
            float(max_cost) if max_cost > 0 else 1.0,
            width=layout.share_width,
        )
        cells.append(share_bar)
        if layout.show_avg:
            cells.append(_styled(_format_latency(s.avg_latency_ms), accent))
        if layout.show_p95:
            cells.append(_styled(_format_latency(s.p95_latency_ms), accent))
        if show_trend:
            cells.append(brand_sparkline(s.daily_cost_buckets))
        table.add_row(*cells)

    console.print(brand_section("by project", table))
    console.print()


def _render_model_table(
    data: ReportData,
    console: Console,
    *,
    vs_previous: bool = False,
) -> None:
    """``── › by model ──`` block."""
    layout = _layout_for_width(int(getattr(console, "width", 0) or 0))
    table = brand_table(show_edge=False)
    table.add_column("model", no_wrap=True, style=_WHITE)
    table.add_column("requests", justify="right", style=_WHITE)
    table.add_column("in", justify="right", style=_WHITE)
    table.add_column("out", justify="right", style=_WHITE)
    table.add_column("cost", justify="right", style=_BRAND)
    if vs_previous:
        table.add_column("Δ", justify="right", style=_WHITE)
    # v0.1.22.18 Fix 2: avg/p95 follow the same responsive tier as the
    # by-project table so a width=80 terminal sees a coherent column
    # set across both blocks (rather than e.g. project=4 cols, model=8).
    if layout.show_avg:
        table.add_column("avg", justify="right", style=_WHITE, min_width=6)
    if layout.show_p95:
        table.add_column("p95", justify="right", style=_WHITE, min_width=6)

    top_idx = _top1_index([s.cost_millicents for s in data.model_stats])

    for i, s in enumerate(data.model_stats):
        is_top = (i == top_idx) and not vs_previous and len(data.model_stats) > 1
        accent = f"bold {_BRAND}" if is_top else None
        cells: list[Text | str] = []
        cells.append(_styled(s.model, accent))
        cells.append(_styled(f"{s.requests:,}", accent))
        cells.append(_styled(f"{s.input_tokens:,}", accent))
        cells.append(_styled(f"{s.output_tokens:,}", accent))
        cells.append(_styled(format_usd(s.cost_millicents), accent or f"bold {_BRAND}"))
        if vs_previous:
            cells.append(_format_delta(s.cost_millicents, s.prev_cost_millicents))
        if layout.show_avg:
            cells.append(_styled(_format_latency(s.avg_latency_ms), accent))
        if layout.show_p95:
            cells.append(_styled(_format_latency(s.p95_latency_ms), accent))
        table.add_row(*cells)

    console.print(brand_section("by model", table))
    console.print()


def _render_footer(data: ReportData, console: Console) -> None:
    """Footer block with the full warning text."""
    if data.incomplete_count == 0 and data.cost_excluded_count == 0:
        return
    lines: list[str] = []
    if data.incomplete_count > 0:
        rec_word = "record" if data.incomplete_count == 1 else "records"
        lines.append(
            f"[{_WARN}]{data.incomplete_count} incomplete {rec_word} — "
            f"token counts may be partial[/]"
        )
    if data.cost_excluded_count > 0:
        rec_word = "record" if data.cost_excluded_count == 1 else "records"
        lines.append(
            f"[{_MUTED}]{data.cost_excluded_count} {rec_word} with "
            f"unrecognised model — counted in totals but excluded from cost[/]"
        )
    body = Group(*[Text.from_markup(line) for line in lines])
    console.print(brand_section("notes", body))
    console.print()


def _styled(text: str, style: str | None) -> Text:
    if style is None:
        return Text(text)
    return Text(text, style=style)


def _top1_index(values: list[int]) -> int:
    """Index of the largest value, or -1 for empty."""
    if not values:
        return -1
    return max(range(len(values)), key=lambda i: values[i])


# ---------------------------------------------------------------------------
# Date filtering (used by CLI)
# ---------------------------------------------------------------------------


def filter_records_by_days(records: list[LogRecord], since_days: int) -> list[LogRecord]:
    """Return records whose requested_at is within the last *since_days*.

    Preserved for backward compatibility with existing tests / callers
    that pass an integer day count. New callers should prefer
    :func:`filter_records_by_window` for explicit windows.
    """
    if since_days <= 0:
        return []
    now = datetime.now(UTC)
    return filter_records_by_window(
        records,
        start=now - timedelta(days=since_days),
        end=now,
    )


def filter_records_by_window(
    records: list[LogRecord],
    *,
    start: datetime | None,
    end: datetime | None,
) -> list[LogRecord]:
    """Return records with ``start <= requested_at <= end``.

    Records with an unparseable timestamp are included (safe default —
    we'd rather show a row than drop it).
    """
    result: list[LogRecord] = []
    for rec in records:
        dt = _safe_parse_iso(rec.requested_at)
        if dt is None:
            result.append(rec)
            continue
        if start is not None and dt < start:
            continue
        if end is not None and dt > end:
            continue
        result.append(rec)
    return result


# ---------------------------------------------------------------------------
# Period parsing — --since / --from / --to
# ---------------------------------------------------------------------------


_SINCE_PATTERN = re.compile(r"^(\d+)d$")


def parse_since(value: str) -> int:
    """Parse a ``--since`` value like ``7d`` into an int day count.

    Raises ``ValueError`` on malformed input.
    """
    m = _SINCE_PATTERN.match(value.strip().lower())
    if not m:
        raise ValueError(
            f"invalid --since value '{value}': expected '<N>d' (e.g. '7d', '30d')"
        )
    n = int(m.group(1))
    if n <= 0:
        raise ValueError(f"--since must be positive, got '{value}'")
    return n


def parse_iso_date(value: str) -> datetime:
    """Parse a ``YYYY-MM-DD`` string into a UTC datetime at 00:00:00."""
    try:
        d = datetime.strptime(value.strip(), "%Y-%m-%d")
    except ValueError as exc:
        raise ValueError(
            f"invalid date '{value}': expected ISO YYYY-MM-DD"
        ) from exc
    return d.replace(tzinfo=UTC)


# ---------------------------------------------------------------------------
# Export helpers — CSV / JSON
# ---------------------------------------------------------------------------


def render_csv(data: ReportData, console: Console) -> None:
    """Emit the report as CSV to *console*'s file.

    One row per (level, key) — ``summary`` / ``project`` / ``model``.
    Money fields stay as raw integer ``cost_millicents`` for round-trip
    fidelity; we also write a derived ``cost_usd`` float so spreadsheet
    users get an immediately legible column.
    """
    buf = io.StringIO()
    writer = _csv.DictWriter(
        buf,
        fieldnames=[
            "level", "key", "requests", "input_tokens", "output_tokens",
            "cost_millicents", "cost_usd",
            "avg_latency_ms", "p95_latency_ms",
        ],
    )
    writer.writeheader()
    writer.writerow({
        "level": "summary",
        "key": "total",
        "requests": data.total_requests,
        "input_tokens": data.total_input_tokens,
        "output_tokens": data.total_output_tokens,
        "cost_millicents": data.total_cost_millicents,
        "cost_usd": _to_usd(data.total_cost_millicents),
        "avg_latency_ms": "",
        "p95_latency_ms": "",
    })
    for s in data.project_stats:
        writer.writerow({
            "level": "project",
            "key": s.project,
            "requests": s.requests,
            "input_tokens": s.input_tokens,
            "output_tokens": s.output_tokens,
            "cost_millicents": s.cost_millicents,
            "cost_usd": _to_usd(s.cost_millicents),
            "avg_latency_ms": f"{s.avg_latency_ms:.1f}",
            "p95_latency_ms": f"{s.p95_latency_ms:.1f}",
        })
    for s in data.model_stats:
        writer.writerow({
            "level": "model",
            "key": s.model,
            "requests": s.requests,
            "input_tokens": s.input_tokens,
            "output_tokens": s.output_tokens,
            "cost_millicents": s.cost_millicents,
            "cost_usd": _to_usd(s.cost_millicents),
            "avg_latency_ms": f"{s.avg_latency_ms:.1f}",
            "p95_latency_ms": f"{s.p95_latency_ms:.1f}",
        })
    console.file.write(buf.getvalue())


def render_json(data: ReportData, console: Console) -> None:
    """Emit the report as a single JSON object to *console*'s file."""
    payload = {
        "summary": {
            "requests": data.total_requests,
            "input_tokens": data.total_input_tokens,
            "output_tokens": data.total_output_tokens,
            "cost_millicents": data.total_cost_millicents,
            "cost_usd": _to_usd(data.total_cost_millicents),
            "date_from": data.date_from,
            "date_to": data.date_to,
            "incomplete_count": data.incomplete_count,
            "cost_excluded_count": data.cost_excluded_count,
            "span_days": data.span_days,
            "prev_total_cost_millicents": data.prev_total_cost_millicents,
        },
        "by_project": [
            {
                "project": s.project,
                "requests": s.requests,
                "input_tokens": s.input_tokens,
                "output_tokens": s.output_tokens,
                "cost_millicents": s.cost_millicents,
                "cost_usd": _to_usd(s.cost_millicents),
                "avg_latency_ms": s.avg_latency_ms,
                "p95_latency_ms": s.p95_latency_ms,
                "daily_cost_buckets": s.daily_cost_buckets,
                "prev_cost_millicents": s.prev_cost_millicents,
            }
            for s in data.project_stats
        ],
        "by_model": [
            {
                "model": s.model,
                "requests": s.requests,
                "input_tokens": s.input_tokens,
                "output_tokens": s.output_tokens,
                "cost_millicents": s.cost_millicents,
                "cost_usd": _to_usd(s.cost_millicents),
                "avg_latency_ms": s.avg_latency_ms,
                "p95_latency_ms": s.p95_latency_ms,
                "prev_cost_millicents": s.prev_cost_millicents,
            }
            for s in data.model_stats
        ],
    }
    console.file.write(json.dumps(payload, indent=2, sort_keys=True))
    console.file.write("\n")


def _to_usd(millicents: int | None) -> float | None:
    if millicents is None:
        return None
    return round(millicents / _MILLICENTS_PER_USD, 6)
