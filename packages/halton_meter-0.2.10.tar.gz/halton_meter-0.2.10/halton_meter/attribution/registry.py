"""Per-edge-process slug → absolute-path corroboration registry (v0.2.4).

Decision: ``memory/decisions.md`` 2026-05-18 — "v0.2.4 unified attribution
resolver (strict-slug + registry + parent walk)".

This is a tiny in-memory data structure consumed by the unified
attribution resolver (``halton_meter.attribution.resolver``). Its only
job is to corroborate a workspace-label slug observed in process env
or argv (Tier 4b / 4c) against a real absolute path on disk recovered
from a path-bearing tier earlier in the same resolver call or from a
prior call in the same edge process.

Lifetime: the edge process. Cleared on edge restart. There is **no**
on-disk persistence — stale paths are worse than missing ones, and
corroboration is cheap to rebuild on the next CONNECT.

Threading: the registry is touched by the psutil worker thread (the
edge runs the resolver via :func:`asyncio.to_thread`) and never the
event loop. A plain :class:`threading.Lock` is the right primitive;
no asyncio coupling.
"""

from __future__ import annotations

import threading

from halton_meter.attribution.layers import normalise_project_slug


class EdgeAttributionRegistry:
    """In-memory ``slug → abspath`` corroboration registry.

    Populated by every path-bearing tier the resolver runs (Tier 2
    rcfile, Tier 3 IDE-args sniff, Tier 4a git, plus the parent-walk
    variants of each). Queried by Tier 4b (env label) and Tier 4c
    (argv label) before either tier is allowed to attribute traffic —
    the strict-slug policy (decision 1 in the v0.2.4 ADR).

    Slug keys are normalised via
    :func:`halton_meter.attribution.layers.normalise_project_slug`
    on both register and lookup so a caller can hand in a raw bundle
    string and get consistent behaviour.
    """

    def __init__(self) -> None:
        self._map: dict[str, str] = {}
        self._lock = threading.Lock()

    def register(self, slug: str, abspath: str) -> None:
        """Record that ``slug`` corresponds to ``abspath`` for this edge.

        Re-registering the same slug overwrites the prior entry. This
        is intentional — the most recent path-bearing resolution wins,
        which matters when a user moves a project on disk and the
        edge has been running since before the move.

        Empty / falsy inputs are silently ignored — the registry never
        stores ``"" → "/some/path"`` or ``"foo" → ""``.
        """
        if not slug or not abspath:
            return
        normalised = normalise_project_slug(slug)
        if not normalised or normalised == "unattributed":
            return
        with self._lock:
            self._map[normalised] = abspath

    def lookup(self, slug: str) -> str | None:
        """Return the registered abspath for ``slug`` or ``None``.

        Slug is normalised before lookup so callers don't have to
        pre-process. ``None`` for empty input, unrecognised slug, or
        any slug that normalises to ``"unattributed"``.
        """
        if not slug:
            return None
        normalised = normalise_project_slug(slug)
        if not normalised or normalised == "unattributed":
            return None
        with self._lock:
            return self._map.get(normalised)

    def known_slugs(self) -> set[str]:
        """Snapshot of currently-registered slugs. Diagnostics only.

        Not part of the resolver hot path. Used by tests and (future)
        a doctor / introspection surface.
        """
        with self._lock:
            return set(self._map.keys())

    def clear(self) -> None:
        """Drop every entry. Test-only helper.

        Production code never clears the registry; edge restart is the
        only intended reset path.
        """
        with self._lock:
            self._map.clear()


# Module-level singleton used by the edge process. Tests construct
# their own ``EdgeAttributionRegistry()`` instances and pass them
# explicitly so the singleton is never touched in unit tests.
_EDGE_REGISTRY = EdgeAttributionRegistry()


def get_edge_registry() -> EdgeAttributionRegistry:
    """Return the per-edge-process singleton registry.

    The edge process and ``edge_attribution.py`` use this entry point
    so they share one registry across all resolver calls. Tests
    construct their own instances and inject them.
    """
    return _EDGE_REGISTRY
