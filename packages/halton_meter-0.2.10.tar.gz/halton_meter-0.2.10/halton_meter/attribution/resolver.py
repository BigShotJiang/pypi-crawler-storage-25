"""Unified attribution resolver (v0.2.4).

Decision: ``memory/decisions.md`` 2026-05-18 — "v0.2.4 unified attribution
resolver (strict-slug + registry + parent walk)".

This module implements the Tier 1 → 5 chain described in
``memory/plans/v0.2.4-unified-attribution.md`` §3. Tier 0 (edge
attribution store) is the caller's responsibility — the caller
consults ``attribution_store.lookup`` first and only invokes this
resolver on a miss. Tier 6 (container), 6.5 (mac sandbox), 7 (cwd
basename), 8 (smart_default) are also the caller's responsibility;
they remain in ``edge_attribution.py`` and ``tagging.py`` because
they have layer-specific input shapes (the matched process's environ
vs ``os.environ``, the matched process's cwd vs a flow-derived cwd).

What this module DOES own:

* Tier 1 — ``HALTON_PROJECT`` on the target process's env.
* Tier 2 — ``.haltonrc`` walked from the target's cwd.
* Tier 3 — IDE workspace-flag sniff against the target's cmdline.
* Tier 4a — git repo basename from the target's cwd.
* Tier 4b — ``CURSOR_WORKSPACE_LABEL`` / ``VSCODE_WORKSPACE_LABEL``
  env-var label, gated by strict-slug corroboration against the
  per-edge registry.
* Tier 4c — Electron-helper argv label, gated by strict-slug
  corroboration against the per-edge registry.
* Tier 5 — bounded parent-PID walk. Stops at uid / session boundary
  or hop budget. Warms the registry from every parent's path-bearing
  resolution; emits ``parent_*`` attribution methods.

Cardinal rule: this resolver MUST NEVER raise. Every entry point is
wrapped in a top-level try/except that returns ``None`` on any
unexpected error so the caller falls through to smart_default. The
proxy hot path is observation infrastructure, not gatekeeping —
attribution failure must never block the user's request.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from pathlib import Path
from typing import Any, NamedTuple

import structlog

from halton_meter.attribution import layers as _layers
from halton_meter.attribution.layers import find_project_root_by_slug
from halton_meter.attribution.registry import EdgeAttributionRegistry

log = structlog.get_logger(__name__)


# Hop budget for the parent walk (Tier 5). Chromium process tree depth
# on macOS is typically 3-4; 5 hops is comfortably generous and the
# cheap guard against runaway loops if proc.parent() ever returns a
# cycle.
DEFAULT_HOP_BUDGET = 5


class ResolvedAttribution(NamedTuple):
    """Structured resolver output.

    ``project`` — the resolved project slug.
    ``attribution_method`` — one of the enum values documented in
        ``attribution_store.py`` / ``storage/models/request.py``.
    ``source_workdir`` — the cwd that fed the winning tier, or
        ``None`` for tiers that consult no cwd (env, env_label,
        argv_label).
    ``tier_id`` — short string identifier emitted only in telemetry.
    """

    project: str
    attribution_method: str
    source_workdir: str | None
    tier_id: str


# ---------------------------------------------------------------------------
# psutil helpers — never raise. Mirror the shape of edge_attribution.py.
# ---------------------------------------------------------------------------


def _safe_cmdline(proc: Any) -> list[str]:
    try:
        return list(proc.cmdline())
    except Exception:
        return []


def _safe_environ(proc: Any) -> dict[str, str]:
    try:
        return dict(proc.environ())
    except Exception:
        return {}


def _safe_cwd(proc: Any) -> str | None:
    try:
        cwd = proc.cwd()
    except Exception:
        return None
    if not cwd:
        return None
    return str(cwd)


def _safe_parent(proc: Any) -> Any | None:
    try:
        return proc.parent()
    except Exception:
        return None


def _safe_pid(proc: Any) -> int | None:
    try:
        return int(proc.pid)
    except Exception:
        return None


def _safe_name(proc: Any) -> str:
    try:
        return str(proc.name())
    except Exception:
        return ""


def _safe_uids(proc: Any) -> tuple[int, int, int] | None:
    """Return ``(real, effective, saved)`` uid triple or ``None`` on error.

    psutil returns ``puids(real=..., effective=..., saved=...)`` on
    POSIX. Tests can pass any object whose ``uids()`` returns a tuple
    of three ints.
    """
    try:
        u = proc.uids()
    except Exception:
        return None
    try:
        return (int(u[0]), int(u[1]), int(u[2]))
    except Exception:
        return None


def _safe_terminal(proc: Any) -> str | None:
    """Return ``proc.terminal()`` or ``None`` on any error.

    Used as the macOS session-boundary fallback because psutil does
    not expose session id directly on Darwin.
    """
    try:
        t = proc.terminal()
    except Exception:
        return None
    if t is None:
        return None
    return str(t)


def _same_uid_session(parent: Any, target: Any) -> bool:
    """True iff ``parent`` and ``target`` share the same uid AND session.

    Decision 5 in the v0.2.4 ADR: stop the walk the moment a parent
    crosses a uid or session boundary. This is the cardinal-rule
    defence against attributing traffic to a system service that
    happens to live above a user process in the tree.

    Failure mode is fail-closed: any exception treats the boundary
    as crossed (returns ``False``). The walk terminates and the
    request falls through to a later tier — better than misattributing.
    """
    try:
        parent_uids = _safe_uids(parent)
        target_uids = _safe_uids(target)
        # When NEITHER process exposes uid info we have no signal of
        # crossing — treat as same-session. Test fakes deliberately
        # omit ``uids()`` / ``terminal()``; the resolver still needs
        # to walk those trees. Production psutil exposes uids() on
        # POSIX so a real boundary always produces a real signal.
        if parent_uids is None and target_uids is None:
            parent_term = _safe_terminal(parent)
            target_term = _safe_terminal(target)
            # Both terminals also missing: no signal of crossing.
            if parent_term is None and target_term is None:
                return True
            # One terminal set, one not: ambiguous, fail-closed.
            if parent_term is None or target_term is None:
                return False
            return parent_term == target_term
        # When ONE side exposes uid info and the other doesn't, we
        # have a partial signal — fail closed to be safe.
        if parent_uids is None or target_uids is None:
            return False
        # Real uid match is the conservative gate. Effective uid can
        # differ across setuid hops; real uid is the owning user.
        if parent_uids[0] != target_uids[0]:
            return False
        # Session boundary: terminal() is the macOS-friendly proxy.
        # When both terminals are None we treat them as same-session
        # (common case for daemon-spawned processes); when one is set
        # and the other isn't, treat as boundary crossed.
        parent_term = _safe_terminal(parent)
        target_term = _safe_terminal(target)
        if parent_term is None and target_term is None:
            return True
        if parent_term is None or target_term is None:
            return False
        return parent_term == target_term
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Telemetry — structured per-tier event.
# ---------------------------------------------------------------------------


def _emit_tier_hit(
    tier: str,
    method: str | None,
    pid: int | None,
    slug: str | None = None,
) -> None:
    """Emit a structured ``attribution.tier_hit`` event.

    Decision 6 in the v0.2.4 ADR. Cloud-side observability will graph
    the mix post-rollout so we can tell whether the strict-slug policy
    is appropriately tight. ``tier`` is the canonical tier_id (e.g.
    ``"1"``, ``"4b"``, ``"4b_miss"``, ``"none"``); ``method`` is the
    winning attribution_method (or ``None`` when the tier missed).
    """
    try:
        log.info(
            "attribution.tier_hit",
            tier=tier,
            method=method,
            pid=pid,
            slug=slug,
        )
    except Exception:
        # Telemetry never breaks the hot path.
        pass


# ---------------------------------------------------------------------------
# Per-tier helpers. Each returns either a (project, method, cwd,
# tier_id) tuple or None.
# ---------------------------------------------------------------------------


def _try_env(env: Mapping[str, str]) -> ResolvedAttribution | None:
    project = _layers.resolve_via_env(env)
    if project is None:
        return None
    return ResolvedAttribution(project, "env", None, "1")


def _try_rcfile(cwd: str | None) -> ResolvedAttribution | None:
    if not cwd:
        return None
    project, _body_capture = _layers.resolve_via_haltonrc(cwd)
    if not project:
        return None
    slug = _layers.normalise_project_slug(project)
    if not slug or slug == _layers.UNATTRIBUTED:
        return None
    return ResolvedAttribution(slug, "rcfile", cwd, "2")


def _try_ide_sniff(cmdline: list[str]) -> ResolvedAttribution | None:
    """Tier 3 — IDE workspace-flag sniff. Path-bearing, self-corroborating."""
    if not cmdline:
        return None
    workspace_path = _layers.extract_workspace_path_from_cmdline(cmdline)
    if not workspace_path:
        return None
    # Re-run rcfile from the discovered workspace path; fall back to
    # basename. Both shapes are path-bearing — no registry corroboration
    # needed.
    project, _body_capture = _layers.resolve_via_haltonrc(workspace_path)
    if project:
        slug = _layers.normalise_project_slug(project)
        if slug and slug != _layers.UNATTRIBUTED:
            return ResolvedAttribution(slug, "ide_sniff", workspace_path, "3")
    basename = Path(workspace_path).name
    if basename:
        slug = _layers.normalise_project_slug(basename)
        if slug and slug != _layers.UNATTRIBUTED:
            return ResolvedAttribution(slug, "ide_sniff", workspace_path, "3")
    return None


def _try_git(cwd: str | None) -> ResolvedAttribution | None:
    if not cwd:
        return None
    project = _layers.resolve_via_git(cwd)
    if not project:
        return None
    return ResolvedAttribution(project, "git", cwd, "4a")


def _try_env_label(
    env: Mapping[str, str],
    registry: EdgeAttributionRegistry,
) -> ResolvedAttribution | None:
    """Tier 4b — IDE workspace env label. STRICT corroboration + lenient fallback.

    Strict path: registry hit → attribute immediately.
    Lenient path (v0.2.5 cold-start fix): registry miss → one-level
    filesystem scan via :func:`find_project_root_by_slug`. On a scan hit,
    warm the registry so future requests use the strict path without
    rescanning. Emit ``4b_lenient`` telemetry to distinguish from the
    normal strict corroboration path.
    """
    slug = _layers.extract_workspace_label_from_env(env)
    if not slug:
        return None
    corroborated = registry.lookup(slug)
    if corroborated:
        return ResolvedAttribution(slug, "ide_env_label", corroborated, "4b")
    # Strict miss — attempt lenient filesystem scan before giving up.
    found_path = find_project_root_by_slug(slug)
    if found_path:
        # Warm the registry so subsequent CONNECTs take the strict path.
        registry.register(slug, found_path)
        return ResolvedAttribution(slug, "ide_env_label", found_path, "4b_lenient")
    return None


def _try_argv_label(
    cmdline: list[str],
    registry: EdgeAttributionRegistry,
) -> ResolvedAttribution | None:
    """Tier 4c — IDE workspace argv label. STRICT corroboration + lenient fallback.

    Strict path: registry hit → attribute immediately.
    Lenient path (v0.2.5 cold-start fix): registry miss → one-level
    filesystem scan via :func:`find_project_root_by_slug`. On a scan hit,
    warm the registry so future requests use the strict path without
    rescanning. Emit ``4c_lenient`` telemetry to distinguish.
    """
    slug = _layers.extract_workspace_label_from_cmdline(cmdline)
    if not slug:
        return None
    corroborated = registry.lookup(slug)
    if corroborated:
        return ResolvedAttribution(slug, "ide_argv_label", corroborated, "4c")
    # Strict miss — attempt lenient filesystem scan before giving up.
    found_path = find_project_root_by_slug(slug)
    if found_path:
        # Warm the registry so subsequent CONNECTs take the strict path.
        registry.register(slug, found_path)
        return ResolvedAttribution(slug, "ide_argv_label", found_path, "4c_lenient")
    return None


def _warm_registry_from_path(
    registry: EdgeAttributionRegistry,
    project: str,
    path: str,
) -> None:
    """Register ``project → path`` so later label tiers can corroborate.

    No-op when either field is empty / unattributed.
    """
    if not project or not path:
        return
    if project == _layers.UNATTRIBUTED:
        return
    registry.register(project, path)


# ---------------------------------------------------------------------------
# Tier 5 — bounded parent walk.
# ---------------------------------------------------------------------------


_PARENT_METHOD_MAP = {
    "rcfile": "parent_rcfile",
    "git": "parent_git",
    "ide_sniff": "parent_ide_sniff",
    "ide_env_label": "parent_ide_env_label",
    "ide_argv_label": "parent_ide_argv_label",
}


def _walk_parents(
    target_proc: Any,
    registry: EdgeAttributionRegistry,
    hop_budget: int,
) -> ResolvedAttribution | None:
    """Walk parent PIDs running Tiers 1→4c against each ancestor.

    Stop conditions (any one ends the walk):

    * ``proc.parent()`` returns ``None`` (top of the tree).
    * Parent pid <= 1 (launchd / init — no project context above).
    * uid or session boundary crossed (decision 5 — cardinal-rule
      defence against attributing to a system service).
    * Hop budget exhausted.

    Warms the registry from each path-bearing ancestor we visit so a
    label sniff at the original target can corroborate against a
    sibling helper's cwd we walked past.

    Returns a ``ResolvedAttribution`` with ``parent_*`` method, or
    ``None`` when the walk terminates without finding anything
    attributable.
    """
    current = target_proc
    for _depth in range(1, hop_budget + 1):
        parent = _safe_parent(current)
        if parent is None:
            return None
        parent_pid = _safe_pid(parent)
        if parent_pid is None or parent_pid <= 1:
            return None
        # uid / session boundary check against the ORIGINATING target,
        # not the immediate child. We want to stay in the same user
        # session as the process that started the request, even across
        # multiple hops within that session.
        if not _same_uid_session(parent, target_proc):
            return None

        parent_env = _safe_environ(parent)
        parent_cwd = _safe_cwd(parent)
        parent_cmdline = _safe_cmdline(parent)

        # Tier 1 against the parent — env var still wins, no
        # corroboration needed. Re-stamped as parent_* via the
        # method map below.
        env_hit = _try_env(parent_env)
        if env_hit is not None:
            # No "parent_env" method in the enum — fold into rcfile-like
            # treatment? The plan only enumerates rcfile/git/ide_sniff/
            # ide_env_label/ide_argv_label parents. Env var on the
            # parent is rare in practice; preserve original method.
            return ResolvedAttribution(
                env_hit.project, "env", None, "5"
            )

        # Path-bearing tiers — warm the registry from each hit.
        rc_hit = _try_rcfile(parent_cwd)
        if rc_hit is not None:
            _warm_registry_from_path(registry, rc_hit.project, parent_cwd or "")
            return ResolvedAttribution(
                rc_hit.project,
                _PARENT_METHOD_MAP["rcfile"],
                parent_cwd,
                "5",
            )

        sniff_hit = _try_ide_sniff(parent_cmdline)
        if sniff_hit is not None:
            _warm_registry_from_path(
                registry, sniff_hit.project, sniff_hit.source_workdir or ""
            )
            return ResolvedAttribution(
                sniff_hit.project,
                _PARENT_METHOD_MAP["ide_sniff"],
                sniff_hit.source_workdir,
                "5",
            )

        git_hit = _try_git(parent_cwd)
        if git_hit is not None:
            _warm_registry_from_path(registry, git_hit.project, parent_cwd or "")
            return ResolvedAttribution(
                git_hit.project,
                _PARENT_METHOD_MAP["git"],
                parent_cwd,
                "5",
            )

        # Label tiers — strict-slug corroboration applies even at
        # the parent layer. If the immediate target didn't carry a
        # label, but a deeper ancestor does AND that ancestor's
        # cwd is in the registry, attribute parent_ide_*_label.
        env_label_hit = _try_env_label(parent_env, registry)
        if env_label_hit is not None:
            return ResolvedAttribution(
                env_label_hit.project,
                _PARENT_METHOD_MAP["ide_env_label"],
                env_label_hit.source_workdir,
                "5",
            )

        argv_label_hit = _try_argv_label(parent_cmdline, registry)
        if argv_label_hit is not None:
            return ResolvedAttribution(
                argv_label_hit.project,
                _PARENT_METHOD_MAP["ide_argv_label"],
                argv_label_hit.source_workdir,
                "5",
            )

        # Walk-warming: even when no tier hit on this ancestor, if its
        # cwd is path-bearing register a fallback ``<basename> → cwd``
        # so later label sniffs against the original target have a
        # chance to corroborate. Strictly opportunistic — basename
        # is the slug under Layer 7.
        if parent_cwd:
            basename_slug = _layers.resolve_via_workdir_basename(parent_cwd)
            if basename_slug:
                _warm_registry_from_path(registry, basename_slug, parent_cwd)

        # Keep walking.
        current = parent
    return None


# ---------------------------------------------------------------------------
# Entry point.
# ---------------------------------------------------------------------------


def resolve_unified(
    *,
    target_proc: Any | None,
    target_env: Mapping[str, str] | None,
    target_cwd: str | None,
    target_cmdline: list[str] | None,
    registry: EdgeAttributionRegistry,
    hop_budget: int = DEFAULT_HOP_BUDGET,
) -> ResolvedAttribution | None:
    """Run Tiers 1→5. Return the winning attribution or ``None``.

    Cardinal rule: NEVER raises. The whole body is wrapped in a
    top-level try/except that returns ``None`` on any unexpected error
    so the caller falls through to smart_default. Telemetry attempts
    are also wrapped (see :func:`_emit_tier_hit`).

    ``target_proc`` may be ``None`` (the daemon's bypass path may not
    have a psutil handle when ``_get_process_cwd`` returns ``None``).
    The resolver still runs Tiers 1/2/3/4a against the supplied env
    and cwd; only Tier 5 (parent walk) and Tier 4c (argv label) are
    skipped when the handle is missing.
    """
    try:
        env: Mapping[str, str] = target_env if target_env is not None else {}
        cmdline: list[str] = list(target_cmdline) if target_cmdline else []
        target_pid = _safe_pid(target_proc) if target_proc is not None else None

        # Tier 1 — env var.
        hit = _try_env(env)
        if hit is not None:
            _emit_tier_hit("1", hit.attribution_method, target_pid, hit.project)
            return hit

        # Tier 2 — rcfile. Warm the registry on success.
        hit = _try_rcfile(target_cwd)
        if hit is not None:
            _warm_registry_from_path(registry, hit.project, target_cwd or "")
            _emit_tier_hit("2", hit.attribution_method, target_pid, hit.project)
            return hit

        # Tier 3 — IDE sniff (path-bearing). Warm the registry from
        # the discovered workspace path.
        hit = _try_ide_sniff(cmdline)
        if hit is not None:
            _warm_registry_from_path(
                registry, hit.project, hit.source_workdir or ""
            )
            _emit_tier_hit("3", hit.attribution_method, target_pid, hit.project)
            return hit

        # Tier 4a — git basename. Warm the registry.
        hit = _try_git(target_cwd)
        if hit is not None:
            _warm_registry_from_path(registry, hit.project, target_cwd or "")
            _emit_tier_hit("4a", hit.attribution_method, target_pid, hit.project)
            return hit

        # Tier 5 — parent walk. Runs BEFORE Tier 4b/4c so that
        # sibling helpers' paths get warmed into the registry first;
        # the post-walk re-check of 4b/4c below benefits from the
        # walk's warming.
        walk_hit: ResolvedAttribution | None = None
        if target_proc is not None:
            walk_hit = _walk_parents(target_proc, registry, hop_budget)

        # Tier 4b — env label. Strict corroboration; lenient fallback on cold-start.
        env_label_slug_pre = _layers.extract_workspace_label_from_env(env)
        env_label_hit = _try_env_label(env, registry)
        if env_label_hit is not None:
            # tier_id is "4b" for strict path, "4b_lenient" for the cold-start
            # filesystem scan (v0.2.5). The hit.tier_id carries the correct value.
            _emit_tier_hit(
                env_label_hit.tier_id,
                env_label_hit.attribution_method,
                target_pid,
                env_label_hit.project,
            )
            return env_label_hit
        if env_label_slug_pre is not None:
            # The label was present but neither registry nor lenient scan hit.
            # Telemetry only — no attribution.
            _emit_tier_hit("4b_miss", None, target_pid, env_label_slug_pre)

        # Tier 4c — argv label. Strict corroboration; lenient fallback on cold-start.
        argv_label_slug_pre = _layers.extract_workspace_label_from_cmdline(cmdline)
        argv_label_hit = _try_argv_label(cmdline, registry)
        if argv_label_hit is not None:
            # tier_id is "4c" for strict path, "4c_lenient" for lenient scan.
            _emit_tier_hit(
                argv_label_hit.tier_id,
                argv_label_hit.attribution_method,
                target_pid,
                argv_label_hit.project,
            )
            return argv_label_hit
        if argv_label_slug_pre is not None:
            _emit_tier_hit("4c_miss", None, target_pid, argv_label_slug_pre)

        # Parent-walk fallback last — the original target's label
        # tiers were preferred when the registry was warm enough to
        # corroborate. If we got here, the walk's result (if any) is
        # the best attribution we have from Tiers 1-5.
        if walk_hit is not None:
            _emit_tier_hit(
                "5",
                walk_hit.attribution_method,
                target_pid,
                walk_hit.project,
            )
            return walk_hit

        # No tier hit.
        _emit_tier_hit("none", None, target_pid, None)
        return None
    except Exception as exc:  # pragma: no cover — cardinal-rule defence
        # Cardinal rule: NEVER raise. The caller must always get a
        # value back (None ⇒ smart_default).
        try:
            log.debug("attribution.resolver_failed", error=str(exc))
        except Exception:
            pass
        return None


# Convenience entry point for the daemon bypass path. Builds the
# resolver call from ``os.environ`` + a flow-derived cwd (no psutil
# handle). The edge path constructs ``resolve_unified`` directly
# because it already has the matched psutil process from its hot
# path.
def resolve_from_daemon_bypass(
    *,
    cwd: str | None,
    registry: EdgeAttributionRegistry,
) -> ResolvedAttribution | None:
    """Daemon bypass path — runs Tiers 1, 2, 4a against ``os.environ`` + cwd.

    Tier 3 (cmdline sniff) and Tier 5 (parent walk) require a psutil
    handle on the originating process; this entry point intentionally
    skips them. The daemon-side caller invokes this AFTER its own
    attempt at finding the originating process; if a psutil handle is
    available the caller invokes :func:`resolve_unified` directly with
    the full argument set.
    """
    return resolve_unified(
        target_proc=None,
        target_env=os.environ,
        target_cwd=cwd,
        target_cmdline=None,
        registry=registry,
    )
