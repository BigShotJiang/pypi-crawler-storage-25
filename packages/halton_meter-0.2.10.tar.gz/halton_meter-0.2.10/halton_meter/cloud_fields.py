"""Helpers for the Wave 1A.ii cloud-sync field capture.

This module hosts the pure helpers the proxy hot path and provider
adapters use to compute the v0.2.0 ``LogRecordIn`` fields that are
not derivable from the existing ``RequestMetadata`` / ``ResponseMetadata``
shape:

* :func:`canonical_prompt_hash` — SHA-256 over a *canonical* JSON
  encoding of the request payload (sorted keys, no whitespace, UTF-8).
  Single source of truth: every adapter goes through this function so
  the same prompt always hashes to the same digest regardless of which
  provider sent it. The contract document
  (``memory/plans/phase2-wire-contract.md`` SHA ``e8f252a``) requires
  SHA-256 and forbids storing the raw prompt text anywhere.

* :func:`extract_idempotency_key` — case-insensitive lookup of the
  per-provider idempotency-key header. Returns ``None`` when no header
  is present. Never synthesises a key — the contract says echo-only.

* :func:`derive_request_kind` — map an HTTP path (and an optional
  inline body hint) to one of ``chat`` / ``embedding`` / ``tool`` /
  ``unknown``. Adapters call this from ``parse_request`` so the
  classification lives next to the URL-shape knowledge each adapter
  already encodes.

* :func:`get_source_machine` — cached ``socket.gethostname()`` snapshot.
  The hostname is captured once at daemon start (first call) so that a
  later hostname change inside the daemon's lifetime does not produce
  ambiguous per-row attribution.

Contract guarantees:

* No imports of provider SDKs or network libraries — pure stdlib only.
* Every function is fail-open: on any unexpected input it returns
  ``None`` (for the extractors) or the contract default (for the
  classifier). It never raises.
* No third-party dependencies. ``hashlib`` and ``json`` are stdlib.
"""

from __future__ import annotations

import hashlib
import json
import socket
from collections.abc import Mapping
from typing import Any

# Header names commonly used by providers for per-request idempotency.
# Match is case-insensitive (HTTP header names are case-insensitive per
# RFC 7230); we lowercase both the candidates and the incoming header
# keys before comparison.
_IDEMPOTENCY_HEADER_CANDIDATES: tuple[str, ...] = (
    "idempotency-key",            # OpenAI, Stripe-style
    "anthropic-idempotency-key",  # Anthropic
    "x-idempotency-key",          # generic vendor convention
    "x-request-id",               # some SDKs reuse this as a dedupe key
)

# Common chat-style URL fragments. Adapter-specific routing happens in
# the adapters themselves; this list is the fallback path used by
# ``derive_request_kind`` when an adapter doesn't pre-decide.
_CHAT_PATH_HINTS: tuple[str, ...] = (
    "/v1/messages",
    "/v1/chat/completions",
    "/v1/responses",
    ":generatecontent",
    ":streamgeneratecontent",
    "/backend-api/codex/responses",
    "/v1internal:generatecontent",
    "/v1internal:streamgeneratecontent",
)

_EMBEDDING_PATH_HINTS: tuple[str, ...] = (
    "/v1/embeddings",
    ":embedcontent",
    ":batchembedcontents",
)

_TOOL_PATH_HINTS: tuple[str, ...] = (
    # Anthropic tool-use is a sub-shape of /v1/messages — adapters
    # disambiguate via body inspection. Leave the list empty here so
    # the path-only fallback only fires when the URL itself is the
    # giveaway (none today). Adapters that need tool classification
    # pass it in directly via ``derive_request_kind(..., body_hint=...)``.
)

REQUEST_KIND_CHAT = "chat"
REQUEST_KIND_EMBEDDING = "embedding"
REQUEST_KIND_TOOL = "tool"
REQUEST_KIND_UNKNOWN = "unknown"

_VALID_REQUEST_KINDS = frozenset(
    {REQUEST_KIND_CHAT, REQUEST_KIND_EMBEDDING, REQUEST_KIND_TOOL, REQUEST_KIND_UNKNOWN}
)


def _coerce_json_serialisable(value: Any) -> Any:
    """Best-effort coerce ``value`` into something ``json.dumps`` will accept.

    The canonical-JSON contract requires every adapter to feed the same
    shape regardless of how the provider's wire body arrived (already a
    dict, raw bytes, raw text, or a ``BaseModel``). We never want a
    hashing path to raise. The fallbacks here mirror the
    "if it isn't already JSON-decodable, drop it" posture taken by every
    other adapter parse function.
    """
    if value is None:
        return None
    if isinstance(value, (dict, list, str, int, float, bool)):
        return value
    if isinstance(value, (bytes, bytearray)):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return value.decode("utf-8", errors="replace")
    # Pydantic / dataclasses / etc. — last-resort: ``str()``.
    try:
        return json.loads(json.dumps(value, default=str))
    except (TypeError, ValueError):
        return str(value)


def canonical_prompt_hash(payload: Any) -> str | None:
    """Return the SHA-256 hex digest of ``payload`` in canonical-JSON form.

    Canonical-JSON rules used here (deliberately a strict subset so the
    daemon and the cloud can both reproduce the same digest from the
    same logical payload):

    1. Sort keys at every level (``sort_keys=True``).
    2. No whitespace between separators (``separators=(",", ":")``).
    3. ``ensure_ascii=False`` so non-ASCII content hashes consistently
       with its UTF-8 byte representation.
    4. Encode to UTF-8 bytes before SHA-256 — never platform default.

    ``payload`` is typically the parsed JSON object of the request body
    (e.g. ``{"model": "...", "messages": [...]}``). Pass ``None`` or an
    empty dict if there is no body (the function returns ``None`` in
    those cases — the contract is "field is optional, leave None when
    not computable").

    Returns ``None`` on any encoding failure. Never raises. Never logs
    or stores the raw payload.
    """
    if payload is None:
        return None
    try:
        coerced = _coerce_json_serialisable(payload)
        if coerced is None:
            return None
        # Empty containers carry no signal; treat as None so we don't
        # produce a digest for every "{}" payload and have it collide
        # across providers.
        if isinstance(coerced, (dict, list, str)) and not coerced:
            return None
        encoded = json.dumps(
            coerced,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            default=str,
        ).encode("utf-8")
    except (TypeError, ValueError):
        return None
    return hashlib.sha256(encoded).hexdigest()


def extract_idempotency_key(headers: Mapping[str, str] | None) -> str | None:
    """Return the first idempotency-key header value found in ``headers``.

    ``headers`` is a mapping-like (e.g. ``flow.request.headers`` from
    mitmproxy or a plain dict). Lookup is case-insensitive. Empty /
    whitespace-only values are rejected so a header set to the empty
    string does not poison the field with ``""``.

    Returns ``None`` when no recognised header is present. Never
    synthesises a value — the contract is "echo the provider's value if
    present".
    """
    if headers is None:
        return None
    try:
        iterator = headers.items()
    except (AttributeError, TypeError):
        return None
    # Lower-case the keys once so we don't quadratic-scan.
    lowered: dict[str, str] = {}
    try:
        for name, value in iterator:
            if not isinstance(name, str) or value is None:
                continue
            lowered[name.lower()] = str(value)
    except Exception:
        return None
    for candidate in _IDEMPOTENCY_HEADER_CANDIDATES:
        v = lowered.get(candidate)
        if v is None:
            continue
        stripped = v.strip()
        if stripped:
            return stripped
    return None


def derive_request_kind(
    path: str,
    *,
    body_hint: Mapping[str, Any] | None = None,
) -> str:
    """Classify a request as ``chat`` / ``embedding`` / ``tool`` / ``unknown``.

    ``path`` is the request URL path (case-insensitive comparisons; we
    lower-case before matching the hint lists).

    ``body_hint`` is an optional already-parsed JSON request body the
    adapter has on hand. When present, we inspect it for tool-use
    markers (Anthropic-style ``tools`` array, OpenAI-style ``tools`` /
    ``tool_choice`` keys). When ``body_hint`` is absent the
    classification is path-only.

    The classifier is intentionally non-exhaustive: when in doubt it
    returns ``unknown``. The contract permits ``None`` for this field,
    but adapters call this helper to avoid leaving the cloud receiver
    guessing; ``unknown`` is the explicit "we looked and could not
    classify" answer.
    """
    p = (path or "").lower()

    # Tool-use is a sub-shape of chat — check the body hint first so a
    # tool-using /v1/messages call is classified as ``tool`` rather than
    # ``chat``. ``tools`` is the canonical marker in both Anthropic and
    # OpenAI's wire shape.
    if body_hint is not None:
        try:
            tools = body_hint.get("tools")
            tool_choice = body_hint.get("tool_choice")
            if (isinstance(tools, list) and tools) or tool_choice:
                return REQUEST_KIND_TOOL
        except (AttributeError, TypeError):
            pass

    for hint in _EMBEDDING_PATH_HINTS:
        if hint in p:
            return REQUEST_KIND_EMBEDDING
    for hint in _CHAT_PATH_HINTS:
        if hint in p:
            return REQUEST_KIND_CHAT
    for hint in _TOOL_PATH_HINTS:
        if hint in p:
            return REQUEST_KIND_TOOL
    return REQUEST_KIND_UNKNOWN


def is_valid_request_kind(value: str | None) -> bool:
    """Return ``True`` if ``value`` is one of the contract's request_kind values."""
    return value in _VALID_REQUEST_KINDS


# ---------------------------------------------------------------------------
# Cached hostname snapshot.
# ---------------------------------------------------------------------------

_HOSTNAME_CACHE: str | None = None


def get_source_machine() -> str | None:
    """Return a cached ``socket.gethostname()`` snapshot.

    Captured once on first call and reused for the lifetime of the
    process so that two records written by the same daemon always carry
    the same ``source_machine`` value, even if ``hostname`` is changed
    mid-flight (rare, but possible on laptops that join VPNs).

    Returns ``None`` when ``socket.gethostname`` raises (DNS misconfig
    on cold boot, sandboxed environments, etc.) so the proxy hot path
    can leave the field as ``None`` rather than failing the write.
    """
    global _HOSTNAME_CACHE
    if _HOSTNAME_CACHE is not None:
        return _HOSTNAME_CACHE
    try:
        name = socket.gethostname()
    except OSError:
        return None
    if not name:
        return None
    _HOSTNAME_CACHE = name
    return _HOSTNAME_CACHE


def _reset_source_machine_cache_for_tests() -> None:
    """Drop the cached hostname. Test-only helper.

    Production code must not call this — the cache is intentionally
    process-lifetime so per-row attribution stays consistent.
    """
    global _HOSTNAME_CACHE
    _HOSTNAME_CACHE = None
