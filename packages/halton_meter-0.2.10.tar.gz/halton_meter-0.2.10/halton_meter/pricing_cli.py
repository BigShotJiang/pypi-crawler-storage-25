"""Business logic for ``halton-meter pricing set / list / reset``.

Layer 2 of the v0.1.22.22 pricing-freshness model: operator overrides
that supersede the bundled matrix at write time and during historical
recompute.

Design choices recorded in ``memory/decisions.md`` 2026-05-08:

* Override storage piggybacks on the existing ``pricing_rates`` table.
  ``is_seed_default = False`` distinguishes overrides from seed rows.
  Seed rows are *kept* when an override is added — historical requests
  costed against them stay valid; only the recompute path consults the
  override.
* "Set" semantics: insert a new row with ``effective_from = now`` and
  set the previously-active row's ``effective_to = now`` so a single
  point-in-time always resolves to a single rate. This matches the
  cloud backend's eventual versioning shape (no schema change needed
  later).
* Values flow USD/MTok in (operator-friendly) and millicents/MTok out
  (database canonical). Rounding via ``round(value * 100_000)`` so
  $1.50 → 150_000 exactly, no float drift in the persisted integer.
* "Reset" deletes operator overrides and restores the seed row's
  ``effective_to = NULL``. Idempotent.

Uses stdlib ``sqlite3`` only — no SQLAlchemy. Mirrors the isolation
pattern in ``recompute_costs.py`` (``BEGIN IMMEDIATE`` + explicit
COMMIT/ROLLBACK) so the CLI plays nicely with a running daemon (WAL
mode).
"""

from __future__ import annotations

import sqlite3
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import structlog

log = structlog.get_logger()


_MILLICENTS_PER_DOLLAR = 100_000


def usd_per_mtok_to_millicents(value: float) -> int:
    """Convert a USD/MTok rate to millicents/MTok (integer).

    Example: 1.50 → 150_000.
    """
    if value < 0:
        msg = f"Rate must be non-negative; got {value}"
        raise ValueError(msg)
    return round(value * _MILLICENTS_PER_DOLLAR)


def millicents_to_usd_per_mtok(value: int) -> float:
    """Inverse of :func:`usd_per_mtok_to_millicents` for display."""
    return value / _MILLICENTS_PER_DOLLAR


def _sqlalchemy_datetime_format(dt: datetime) -> str:
    """Format ``dt`` the way SQLAlchemy's SQLite dialect persists datetimes.

    SQLAlchemy's default SQLite ``DateTime`` adapter stores values as
    ``"%Y-%m-%d %H:%M:%S.%f"`` (space separator, no timezone offset, even
    when the column is declared ``DateTime(timezone=True)``).
    Lexicographic ordering on that format matches chronological order,
    which is what the rate-resolution query relies on.

    Writing the override row's ``effective_from`` in any other shape
    (e.g. ISO-8601 with trailing ``Z`` or a ``+00:00`` offset) breaks
    string comparison against ``requests.requested_at`` and silently
    drops overrides from recompute matches. Hence the explicit format.
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    dt_utc = dt.astimezone(UTC)
    return dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")


@dataclass(frozen=True)
class RateRow:
    """One row from ``pricing_rates`` for display purposes."""

    id: str
    provider: str
    model: str
    mode: str
    effective_from: str
    effective_to: str | None
    input_rate: int  # millicents per million tokens
    output_rate: int
    thinking_rate: int
    cache_read_rate: int
    cache_write_rate: int
    is_seed_default: bool


@dataclass(frozen=True)
class SetResult:
    """Returned by :func:`set_override`."""

    inserted_id: str
    """UUID of the newly-inserted override row."""

    superseded_id: str | None
    """UUID of the previously-active row whose ``effective_to`` was
    stamped to ``now``, or None if no prior row matched."""

    effective_at: str
    """ISO-8601 timestamp the override took effect."""


@dataclass(frozen=True)
class ResetResult:
    """Returned by :func:`reset_overrides`."""

    rows_deleted: int
    """Number of override rows removed."""

    rows_reopened: int
    """Number of seed rows whose ``effective_to`` was cleared back to
    NULL so the seed is once again the active row."""


def list_rates(db_path: Path, provider: str | None = None) -> list[RateRow]:
    """Return all rate rows (seed + override), most recent first.

    When ``provider`` is non-None, restrict the result to that provider.
    """
    conn = sqlite3.connect(str(db_path), timeout=10.0)
    try:
        sql = (
            "SELECT id, provider, model, mode, effective_from, effective_to, "
            "input_rate_per_million_minor_units, "
            "output_rate_per_million_minor_units, "
            "thinking_rate_per_million_minor_units, "
            "cache_read_rate_per_million_minor_units, "
            "cache_write_rate_per_million_minor_units, "
            "COALESCE(is_seed_default, 1) "
            "FROM pricing_rates"
        )
        params: tuple[object, ...] = ()
        if provider is not None:
            sql += " WHERE provider = ?"
            params = (provider,)
        sql += (
            " ORDER BY is_seed_default ASC, provider ASC, model ASC, "
            "mode ASC, effective_from DESC"
        )
        try:
            rows = conn.execute(sql, params).fetchall()
        except sqlite3.OperationalError:
            # Fresh database: the daemon hasn't run yet, so the
            # pricing_rates table doesn't exist. Treat as "no rows" —
            # the CLI surfaces an actionable hint to start the daemon.
            rows = []
    finally:
        conn.close()

    return [
        RateRow(
            id=str(r[0]),
            provider=str(r[1]),
            model=str(r[2]),
            mode=str(r[3]),
            effective_from=str(r[4]),
            effective_to=str(r[5]) if r[5] is not None else None,
            input_rate=int(r[6]),
            output_rate=int(r[7]),
            thinking_rate=int(r[8]),
            cache_read_rate=int(r[9]),
            cache_write_rate=int(r[10]),
            is_seed_default=bool(r[11]),
        )
        for r in rows
    ]


def set_override(
    db_path: Path,
    *,
    provider: str,
    model: str,
    mode: str = "standard",
    input_usd_per_mtok: float | None = None,
    output_usd_per_mtok: float | None = None,
    thinking_usd_per_mtok: float | None = None,
    cache_read_usd_per_mtok: float | None = None,
    cache_write_usd_per_mtok: float | None = None,
) -> SetResult:
    """Insert an operator-set pricing rate row that supersedes any prior row.

    Any rate parameter left as ``None`` inherits the value of the
    currently-active row (seed or prior override). At least one of the
    rate parameters must be non-None.

    The previously-active row (if any) gets its ``effective_to``
    stamped to the current UTC instant so a point-in-time lookup
    always resolves to a single rate.

    All transactions are isolated via ``BEGIN IMMEDIATE`` + explicit
    COMMIT/ROLLBACK so concurrent daemon writes are safely serialised.
    """
    if all(
        x is None
        for x in (
            input_usd_per_mtok,
            output_usd_per_mtok,
            thinking_usd_per_mtok,
            cache_read_usd_per_mtok,
            cache_write_usd_per_mtok,
        )
    ):
        msg = "set_override requires at least one rate to be specified."
        raise ValueError(msg)

    now = datetime.now(tz=UTC)
    now_iso = _sqlalchemy_datetime_format(now)
    new_id = str(uuid.uuid4())

    conn = sqlite3.connect(str(db_path), timeout=10.0)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.execute("BEGIN IMMEDIATE")
        try:
            # Find the currently-active row for inheritance + supersession.
            current = conn.execute(
                "SELECT id, "
                "input_rate_per_million_minor_units, "
                "output_rate_per_million_minor_units, "
                "thinking_rate_per_million_minor_units, "
                "cache_read_rate_per_million_minor_units, "
                "cache_write_rate_per_million_minor_units "
                "FROM pricing_rates "
                "WHERE provider = ? AND model = ? AND mode = ? "
                "AND effective_to IS NULL "
                "ORDER BY effective_from DESC LIMIT 1",
                (provider, model, mode),
            ).fetchone()

            if current is None:
                # No prior row to inherit from — every rate must be supplied.
                missing = [
                    name
                    for name, val in (
                        ("input", input_usd_per_mtok),
                        ("output", output_usd_per_mtok),
                    )
                    if val is None
                ]
                if missing:
                    msg = (
                        f"No prior rate to inherit from for "
                        f"{provider}/{model}/{mode}; missing required "
                        f"rate(s): {', '.join(missing)}."
                    )
                    raise ValueError(msg)
                inherited_thinking = 0
                inherited_cache_read = 0
                inherited_cache_write = 0
                inherited_input = usd_per_mtok_to_millicents(
                    input_usd_per_mtok or 0
                )
                inherited_output = usd_per_mtok_to_millicents(
                    output_usd_per_mtok or 0
                )
            else:
                inherited_input = int(current[1])
                inherited_output = int(current[2])
                inherited_thinking = int(current[3])
                inherited_cache_read = int(current[4])
                inherited_cache_write = int(current[5])

            new_input = (
                usd_per_mtok_to_millicents(input_usd_per_mtok)
                if input_usd_per_mtok is not None
                else inherited_input
            )
            new_output = (
                usd_per_mtok_to_millicents(output_usd_per_mtok)
                if output_usd_per_mtok is not None
                else inherited_output
            )
            new_thinking = (
                usd_per_mtok_to_millicents(thinking_usd_per_mtok)
                if thinking_usd_per_mtok is not None
                else inherited_thinking
            )
            new_cache_read = (
                usd_per_mtok_to_millicents(cache_read_usd_per_mtok)
                if cache_read_usd_per_mtok is not None
                else inherited_cache_read
            )
            new_cache_write = (
                usd_per_mtok_to_millicents(cache_write_usd_per_mtok)
                if cache_write_usd_per_mtok is not None
                else inherited_cache_write
            )

            superseded_id_val: str | None = None
            if current is not None:
                superseded_id_val = str(current[0])
                conn.execute(
                    "UPDATE pricing_rates SET effective_to = ? WHERE id = ?",
                    (now_iso, superseded_id_val),
                )

            conn.execute(
                "INSERT INTO pricing_rates ("
                "id, provider, model, mode, effective_from, effective_to, "
                "input_rate_per_million_minor_units, "
                "output_rate_per_million_minor_units, "
                "thinking_rate_per_million_minor_units, "
                "cache_read_rate_per_million_minor_units, "
                "cache_write_rate_per_million_minor_units, "
                "is_seed_default"
                ") VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, 0)",
                (
                    new_id,
                    provider,
                    model,
                    mode,
                    now_iso,
                    new_input,
                    new_output,
                    new_thinking,
                    new_cache_read,
                    new_cache_write,
                ),
            )
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    finally:
        conn.close()

    log.info(
        "pricing.override_set",
        provider=provider,
        model=model,
        mode=mode,
        input_millicents=new_input,
        output_millicents=new_output,
    )
    return SetResult(
        inserted_id=new_id,
        superseded_id=superseded_id_val,
        effective_at=now_iso,
    )


def reset_overrides(
    db_path: Path,
    *,
    provider: str | None = None,
    model: str | None = None,
    mode: str | None = None,
) -> ResetResult:
    """Delete operator-set rows and reopen the matching seed rows.

    The match scope is the conjunction of the supplied filters; all-None
    means "every override across every provider/model/mode". Always
    idempotent — running twice in a row removes zero rows on the
    second pass.
    """
    conn = sqlite3.connect(str(db_path), timeout=10.0)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.execute("BEGIN IMMEDIATE")
        try:
            where = ["is_seed_default = 0"]
            params: list[object] = []
            if provider is not None:
                where.append("provider = ?")
                params.append(provider)
            if model is not None:
                where.append("model = ?")
                params.append(model)
            if mode is not None:
                where.append("mode = ?")
                params.append(mode)
            where_sql = " AND ".join(where)

            # Capture the (provider, model, mode) tuples we are about to
            # delete so we can reopen the corresponding seed rows.
            tuples = conn.execute(
                f"SELECT DISTINCT provider, model, mode FROM pricing_rates "
                f"WHERE {where_sql}",
                tuple(params),
            ).fetchall()

            cursor = conn.execute(
                f"DELETE FROM pricing_rates WHERE {where_sql}",
                tuple(params),
            )
            rows_deleted = int(cursor.rowcount or 0)

            rows_reopened = 0
            for prov, mdl, md in tuples:
                # Reopen the most recent seed row for this triple so a
                # cost lookup at "now" matches it again.
                seed_row = conn.execute(
                    "SELECT id FROM pricing_rates "
                    "WHERE provider = ? AND model = ? AND mode = ? "
                    "AND is_seed_default = 1 "
                    "ORDER BY effective_from DESC LIMIT 1",
                    (prov, mdl, md),
                ).fetchone()
                if seed_row is None:
                    continue
                cur2 = conn.execute(
                    "UPDATE pricing_rates SET effective_to = NULL "
                    "WHERE id = ? AND effective_to IS NOT NULL",
                    (str(seed_row[0]),),
                )
                if (cur2.rowcount or 0) > 0:
                    rows_reopened += 1

            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    finally:
        conn.close()

    log.info(
        "pricing.overrides_reset",
        rows_deleted=rows_deleted,
        rows_reopened=rows_reopened,
    )
    return ResetResult(
        rows_deleted=rows_deleted,
        rows_reopened=rows_reopened,
    )
