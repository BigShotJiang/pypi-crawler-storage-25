"""Halton Meter brand language for terminal surfaces.

The single source of truth for visual tokens (colours, box style, icons,
table padding) and small builder helpers (``brand_panel``, ``brand_table``,
``brand_progress``) used across the daily-driven CLI surfaces.

Why this lives in its own module
--------------------------------
Visual unification across ``status`` / ``doctor`` / ``report`` / lifecycle
surfaces was previously inconsistent: ``report`` shipped a Bloomberg
Terminal palette (cyan + gold), ``status`` used Rich default styles, and
the lifecycle panels picked colours per-call. Phase 0.5 of the v0.2
roadmap asked for a single brand language: rounded boxes, brand-orange
accents (``#ea7d2e``), consistent semantic colour assignments.

Adding a new surface? Use ``brand_panel`` / ``brand_table`` / the colour
tokens — never hard-code hex values or pick arbitrary Rich named colours.
That keeps every surface visually coherent without any single render site
needing to know the full palette.

See ``daemon/docs/brand-language.md`` for the contributor-facing spec.

Pure helpers — no I/O, no Rich state mutation, no implicit Console use.
Callers pass a ``Console`` in. Returns Rich renderables / styles strings.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from rich import box
from rich.console import Group, RenderableType
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    ProgressColumn,
    SpinnerColumn,
    Task,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Colour tokens
# ---------------------------------------------------------------------------
#
# Single source of truth. If a render site needs a colour, it imports from
# here. New colours land here first, with a one-line rationale.

#: Halton brand orange. Used for headlines, primary borders, money values
#: in cost reports, and the chevron accent. Hex form so Rich renders the
#: exact brand colour rather than a 256-colour approximation.
BRAND_ORANGE: str = "#ea7d2e"

#: Soft slate-blue for headers and labels in tables. Pairs cleanly with
#: brand orange without competing for attention.
HEADER_BLUE: str = "#7aa2d8"

#: High-contrast neutral for primary numeric content (token counts, request
#: counts, dates). Reads as bright on dark terminals and ink-black on light
#: terminals because Rich's ``bright_white`` resolves per-terminal.
NUMERIC: str = "bright_white"

#: Subdued grey for secondary text — labels, units, captions, footnotes.
MUTED: str = "grey58"

#: Status semantics. Reused identically across status / doctor / report.
OK: str = "bright_green"
WARN: str = "#f0c674"  # amber
ERROR: str = "#e06c75"  # soft red — reads better than pure red on dark bg
INFO: str = HEADER_BLUE

#: Standard box style across panels and tables. Rounded corners are the
#: brand signature.
BOX_STYLE = box.ROUNDED

#: Padding tuple for tables — vertical 0, horizontal 2. Matches the Phase 0.5
#: spec and gives readable density without feeling cramped.
TABLE_PADDING: tuple[int, int] = (0, 2)

# ---------------------------------------------------------------------------
# Iconography
# ---------------------------------------------------------------------------
#
# We expose both glyph and plain forms. The doctor module already has its
# own glyph/plain split for legacy reasons; new surfaces use these.

ICON_OK: str = "✓"
ICON_WARN: str = "⚠"
ICON_ERROR: str = "✗"
ICON_INFO: str = "ℹ"
ICON_BULLET: str = "•"
ICON_CHEVRON: str = "›"

# State pills — preferred over words ("RUNNING", "STOPPED") in headline rows.
# The glyph carries the semantic; pair with the matching colour token at the
# render site (see ``brand_pill``).
PILL_ACTIVE: str = "●"   # filled — running / healthy / on
PILL_PAUSED: str = "○"   # hollow — stopped / paused / off
PILL_DEGRADED: str = "◐"  # half — degraded / inconsistent
PILL_BROKEN: str = "✗"   # cross — broken / failed

# Block characters used by ``brand_bar`` for inline progress / share bars.
# ``▰`` (filled) / ``▱`` (empty) read as a single bar at any terminal width
# without depending on Unicode-block-rendering quirks.
_BAR_FILLED: str = "▰"
_BAR_EMPTY: str = "▱"

# Sparkline glyph ramp (height 1..8).  Used by ``brand_sparkline`` for the
# tiny 7-day cost trend in the report header.
_SPARK_RAMP: tuple[str, ...] = ("▁", "▂", "▃", "▄", "▅", "▆", "▇", "█")

# ---------------------------------------------------------------------------
# Severity → colour mapping helpers
# ---------------------------------------------------------------------------


def severity_color(severity: str) -> str:
    """Map a severity-ish string to its brand colour token.

    Accepts the union of strings used across status / doctor / lifecycle
    today: ``HEALTHY``, ``INCONSISTENT``, ``BROKEN``, ``healthy``,
    ``warn``, ``error``, ``ok``, ``info``. Unknown severities fall through
    to ``MUTED`` so render sites never crash.
    """
    s = severity.strip().lower()
    if s in ("healthy", "ok", "success", "green"):
        return OK
    if s in ("inconsistent", "warn", "warning", "yellow"):
        return WARN
    if s in ("broken", "error", "fail", "failed", "red"):
        return ERROR
    # v0.1.21: ``stopped`` is the manual-start "metering paused"
    # verdict. Render in INFO blue — calmer than amber/red, distinct
    # from OK green.
    if s in ("info", "blue", "stopped"):
        return INFO
    return MUTED


# ---------------------------------------------------------------------------
# Panel / Table / Progress factories
# ---------------------------------------------------------------------------


def brand_panel(
    body: Any,
    *,
    title: str | None = None,
    severity: str = "info",
    expand: bool = False,
    padding: tuple[int, int] = (1, 2),
) -> Panel:
    """Build a brand-language Panel.

    Rounded corners, severity-driven border colour, brand-orange title
    when severity is ``info`` or unset (the default for "neutral" panels
    like ``halton-meter start`` summary), severity colour otherwise.

    Args:
        body: Renderable or markup string for the body.
        title: Panel title (omitted if None).
        severity: One of ``ok`` / ``warn`` / ``error`` / ``info``. Drives
            border + title colour. Unknown severities fall through to
            ``MUTED``.
        expand: Whether the panel stretches to console width (default False
            — panels shrink to fit). NEVER pass a hardcoded ``width``.
        padding: Inner padding tuple. Default ``(1, 2)`` reads cleanly.
    """
    border = severity_color(severity) if severity != "info" else BRAND_ORANGE
    title_markup: str | None
    if title is None:
        title_markup = None
    else:
        # Brand-orange titles on info; severity colour otherwise.
        colour = BRAND_ORANGE if severity == "info" else severity_color(severity)
        title_markup = f"[bold {colour}]{title}[/bold {colour}]"
    return Panel(
        body,
        title=title_markup,
        border_style=border,
        box=BOX_STYLE,
        expand=expand,
        padding=padding,
    )


def brand_table(
    *,
    title: str | None = None,
    show_lines: bool = False,
    expand: bool = False,
    show_edge: bool = True,
) -> Table:
    """Build a brand-language Table shell.

    Caller adds columns + rows. We pre-set: rounded box, brand padding,
    blue header style, optional brand-orange title.

    Args:
        title: Optional table title; rendered in brand orange + bold.
        show_lines: Inter-row dividers. Default off (denser).
        expand: Stretch to console width. Default off (table shrinks to
            content).
        show_edge: Outer border. Default on; pass False for "grid only"
            layouts (used in the report's by-project / by-model tables).
    """
    title_markup: str | None
    if title is None:
        title_markup = None
    else:
        title_markup = f"[bold {BRAND_ORANGE}]{title}[/bold {BRAND_ORANGE}]"
    table = Table(
        title=title_markup,
        box=BOX_STYLE,
        show_lines=show_lines,
        expand=expand,
        show_edge=show_edge,
        padding=TABLE_PADDING,
        header_style=f"bold {HEADER_BLUE}",
    )
    return table


def brand_progress(*, transient: bool = True) -> Progress:
    """Build a brand-language Progress bar.

    Spinner + description + bar + percent + elapsed. Bar uses brand
    orange for the completed portion and muted grey for the remainder.

    Args:
        transient: Whether to clear the bar on completion. Default True
            (cleaner final output).
    """
    return Progress(
        SpinnerColumn(style=BRAND_ORANGE),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(
            complete_style=BRAND_ORANGE,
            finished_style=OK,
            pulse_style=BRAND_ORANGE,
        ),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        transient=transient,
    )


class _SubSecondElapsedColumn(ProgressColumn):
    """Elapsed-time column that renders sub-second precision.

    Default ``TimeElapsedColumn`` formats as ``H:MM:SS`` which loses
    information for sub-second phases (cert checks frequently complete
    in <100ms). The brand reference shows ``2.1s`` / ``800ms`` style
    timings on the right edge — readable signal for fast no-ops while
    still legible for slower work.

    Format rules:
      * < 1s          → ``Nms``  (e.g. ``230ms``)
      * < 60s         → ``N.Ns`` (e.g. ``2.1s``)
      * >= 60s        → ``H:MM:SS`` (fall back to default)
    """

    def render(self, task: Task) -> Text:
        elapsed = task.finished_time if task.finished else task.elapsed
        if elapsed is None:
            return Text("--", style=MUTED)
        if elapsed < 1.0:
            label = f"{int(elapsed * 1000)}ms"
        elif elapsed < 60.0:
            label = f"{elapsed:.1f}s"
        else:
            mins, secs = divmod(int(elapsed), 60)
            hrs, mins = divmod(mins, 60)
            label = (
                f"{hrs}:{mins:02d}:{secs:02d}"
                if hrs
                else f"{mins}:{secs:02d}"
            )
        return Text(label, style=MUTED)


def brand_phase_progress() -> Progress:
    """Build a brand-language per-phase Progress with persisted lines.

    Layout: ``[spinner]  description …                    elapsed``.

    Each call site adds one task per phase via ``progress.add_task(desc,
    total=1)``. While the task is incomplete the orange spinner shows;
    once the caller marks it complete (``progress.update(task_id,
    completed=1)`` or ``advance=1``), Rich's ``SpinnerColumn`` swaps the
    spinner glyph for the ``finished_text`` (a brand-coloured ``✓``)
    and freezes the elapsed time. ``transient=False`` keeps every
    completed line on screen — this is the v0.1.20.dev3 mockup shape.

    No bar / percent column: per-phase work is single-shot, the bar
    would just sit at 0% then jump to 100%. The elapsed column is the
    informative bit.

    Reuses ``BRAND_ORANGE`` for the spinner + finished glyph and
    ``MUTED`` for the elapsed timing so the right edge reads as
    secondary text.
    """
    return Progress(
        SpinnerColumn(
            style=BRAND_ORANGE,
            finished_text=f"[{OK}]{ICON_OK}[/{OK}]",
        ),
        TextColumn("[progress.description]{task.description}"),
        _SubSecondElapsedColumn(),
        transient=False,
    )


# ---------------------------------------------------------------------------
# Headline helper
# ---------------------------------------------------------------------------


def brand_headline(product: str, version: str, subtitle: str | None = None) -> str:
    """Build the standard ``halton-meter v0.1.20 · subtitle`` headline.

    Brand orange product, muted version, muted subtitle. Returned as a
    Rich markup string; caller controls when / where to print.
    """
    parts = [f"[bold {BRAND_ORANGE}]{product}[/bold {BRAND_ORANGE}]"]
    parts.append(f"[{MUTED}]v{version}[/{MUTED}]")
    if subtitle:
        parts.append(f"[{MUTED}]· {subtitle}[/{MUTED}]")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Editorial primitives (v0.1.22)
# ---------------------------------------------------------------------------
#
# These compose the "editorial" surface aesthetic — unframed by default,
# strong typographic hierarchy, restrained colour. Reach for these when
# building a new daily-driver surface; reach for ``brand_panel`` only for
# moments that earn a frame (start/stop confirmation, errors, destructive
# confirmations, the welcome poster).
#
# Composition rules:
#   1. Lead every command with ``brand_masthead`` then ``brand_underrule``.
#   2. Group related rows under ``brand_section``.
#   3. State is a glyph pill, not a word — use ``brand_pill``.
#   4. Key/value rows go through ``brand_kv`` for aligned dim-label /
#      bright-value typography.


def brand_masthead(
    *,
    subtitle: str | None = None,
    version: str | None = None,
    mark: str = "dot",
) -> Text:
    """The ``● halton meter  ›  subtitle  ·  v0.1.21`` masthead row.

    Single line, bare (no border). Brand-orange dot, bold wordmark, muted
    chevron + subtitle, muted version on the right side of the same line.
    Pair with ``brand_underrule`` for the section break.

    The dot+wordmark is the brand signature. Used at the top of every
    long-form command surface (``status``, ``doctor``, ``report``,
    ``init``).

    Args:
        subtitle: optional subtitle text.
        version: optional version string (rendered with ``v`` prefix).
        mark: ``"dot"`` (default — legacy ``●`` brand-active pill) or
            ``"inline"`` (the ``[H]`` block-letter brand mark for
            v0.1.22.14 quick-command mastheads).
    """
    line = Text()
    if mark == "inline":
        # ``[H]`` mark — brand-orange bold ``H`` between muted brackets.
        line.append("[", style=MUTED)
        line.append("H", style=f"bold {BRAND_ORANGE}")
        line.append("] ", style=MUTED)
    else:
        line.append(f"{PILL_ACTIVE} ", style=f"bold {BRAND_ORANGE}")
    line.append("halton", style="bold bright_white")
    line.append("-", style=BRAND_ORANGE)
    line.append("meter", style=f"bold {BRAND_ORANGE}")
    if subtitle:
        line.append("  ", style=MUTED)
        line.append(ICON_CHEVRON, style=BRAND_ORANGE)
        line.append(f"  {subtitle}", style=MUTED)
    if version:
        line.append("  ", style=MUTED)
        line.append(ICON_BULLET, style=MUTED)
        line.append(f"  v{version}", style=MUTED)
    return line


def brand_underrule(*, style: str = MUTED) -> Rule:
    """The thin horizontal rule that sits below the masthead.

    Defaults to ``MUTED`` so the rule reads as architecture, not signal.
    Pass ``style=BRAND_ORANGE`` for celebratory surfaces (post-init
    success) where the brand accent is earned.
    """
    return Rule(style=style, characters="─")


def brand_section(title: str, body: RenderableType) -> Group:
    """Render a section: muted-title rule, blank line, body.

    Section dividers in the editorial layout look like::

        ── › status ────────────────────────────

    Brand-orange chevron + brand-orange title flush-left, muted rule
    extending to terminal width. Followed by one blank line, then the
    body renderable.
    """
    title_markup = (
        f"[{MUTED}]── [/]{ICON_CHEVRON} "
        f"[bold {BRAND_ORANGE}]{title}[/bold {BRAND_ORANGE}] "
        f"[{MUTED}]{'─' * 4}[/]"
    )
    rule = Rule(title=title_markup, align="left", style=MUTED, characters="─")
    return Group(rule, Text(""), body)


def brand_pill(
    state: str,
    label: str | None = None,
    *,
    glyph: str | None = None,
) -> Text:
    """A state pill: a single coloured glyph, optionally followed by a label.

    State strings map exactly the way they do for ``severity_color``:
    ``ok`` / ``healthy`` / ``active`` / ``running`` → ``●`` in green;
    ``warn`` / ``inconsistent`` / ``degraded`` → ``◐`` in amber;
    ``error`` / ``broken`` / ``fail`` → ``✗`` in red;
    ``stopped`` / ``paused`` / ``off`` / ``info`` → ``○`` in muted.

    Pass an explicit ``glyph`` to override the default state glyph
    (rare — only for novelty surfaces).
    """
    s = state.strip().lower()
    if s in ("ok", "healthy", "active", "running", "on", "success"):
        chosen_glyph = glyph or PILL_ACTIVE
        colour = OK
    elif s in ("warn", "warning", "inconsistent", "degraded"):
        chosen_glyph = glyph or PILL_DEGRADED
        colour = WARN
    elif s in ("error", "broken", "fail", "failed"):
        chosen_glyph = glyph or PILL_BROKEN
        colour = ERROR
    elif s in ("stopped", "paused", "off"):
        chosen_glyph = glyph or PILL_PAUSED
        colour = MUTED
    else:
        chosen_glyph = glyph or PILL_PAUSED
        colour = MUTED

    out = Text()
    out.append(chosen_glyph, style=colour)
    if label:
        out.append(f"  {label}")
    return out


def brand_kv(
    label: str,
    value: str,
    *,
    label_width: int = 20,
    label_style: str = MUTED,
    value_style: str = NUMERIC,
) -> Text:
    """Two-column key/value row: muted label, bright value, fixed gutter.

    Label is left-padded to ``label_width`` so multiple ``brand_kv``
    rows align cleanly when stacked. Default 20 columns is wide enough
    for ``"System proxy"`` / ``"Requests (24h)"`` without crowding.

    Used inside ``brand_section`` for "by the numbers" blocks. Avoids
    the visual heaviness of a Rich Table when only two columns are in
    play.
    """
    out = Text()
    out.append("  ", style=label_style)
    padded = label.ljust(label_width)
    out.append(padded, style=label_style)
    out.append(value, style=value_style)
    return out


def brand_step(
    state: str,
    label: str,
    detail: str | None = None,
) -> Text:
    """One step row: state pill + label + muted detail.

    The step is the building block for "what just happened" lists in
    ``start`` / ``stop`` / ``init`` panels and the doctor's check rows.
    Pair the state with the matching pill colour (see ``brand_pill``).

    Visual::

        ●  Daemon loaded                     PID 81234
        ●  /health responding                :8765 (47ms)
        ○  Watchdog dormant                  re-arm on next start
    """
    out = Text()
    pill = brand_pill(state)
    out.append_text(pill)
    out.append(f"  {label}")
    if detail:
        out.append(f"   {detail}", style=MUTED)
    return out


def brand_bar(value: float, total: float, *, width: int = 20) -> Text:
    """Inline filled-block progress bar.

    Renders ``▰▰▰▰▰▰▱▱▱▱`` style at ``width`` characters; orange filled,
    muted empty. Used inline in headlines (e.g. share-of-spend per
    project in the report).

    Negative or zero ``total`` renders as fully empty.
    """
    if total <= 0:
        ratio = 0.0
    else:
        ratio = max(0.0, min(1.0, value / total))
    filled_count = round(ratio * width)
    empty_count = max(0, width - filled_count)
    out = Text()
    if filled_count:
        out.append(_BAR_FILLED * filled_count, style=BRAND_ORANGE)
    if empty_count:
        out.append(_BAR_EMPTY * empty_count, style=MUTED)
    return out


def brand_sparkline(values: Iterable[float]) -> Text:
    """Compact 8-step sparkline for a small numeric series.

    Empty / single-value series collapses to a single ``▁`` glyph so
    callers don't have to special-case "no history yet". The output
    width equals ``len(values)`` characters; bound the input upstream
    if you need a fixed width.
    """
    series = [max(0.0, float(v)) for v in values]
    if not series:
        return Text("▁", style=MUTED)
    hi = max(series)
    if hi <= 0:
        return Text("▁" * len(series), style=MUTED)
    out = Text()
    last_idx = len(_SPARK_RAMP) - 1
    for v in series:
        idx = round((v / hi) * last_idx)
        idx = max(0, min(last_idx, idx))
        out.append(_SPARK_RAMP[idx], style=BRAND_ORANGE)
    return out


def brand_command_grid(
    rows: list[tuple[str, str]],
    *,
    cmd_width: int = 26,
) -> Group:
    """Grid of ``command  →  one-line description`` rows.

    Used by the bare-``halton-meter`` next-steps surface and the
    overridden ``--help`` output. Command in bright_white, arrow + tail
    in muted. Indented two spaces. ``cmd_width`` is the column the
    arrow lands on — pick a value wider than the longest command in
    ``rows`` for clean alignment.
    """
    lines: list[Text] = []
    for cmd, desc in rows:
        line = Text("  ")
        line.append(cmd, style="bold bright_white")
        gap = max(1, cmd_width - len(cmd))
        line.append(" " * gap, style=MUTED)
        line.append("→ ", style=BRAND_ORANGE)
        line.append(desc, style=MUTED)
        lines.append(line)
    return Group(*lines)


# ---------------------------------------------------------------------------
# v0.1.22.14 — Halton Meter "H" block-letter mark
# ---------------------------------------------------------------------------
#
# Geometry follows the design-system SVG (``halton-meter-mark.svg``):
# slab-serif H, two vertical legs with inward-pointing half-serifs at the
# top and bottom, plus a middle crossbar. Ten columns × five rows in
# brand-orange block characters. Used for the Tier-A dwell surfaces
# (``status``, ``report``); the inline ``[H]`` form is used for the
# Tier-B quick commands.

#: The five lines of the Tier-A block-H. Each line is exactly 10 columns
#: wide so the column count stays constant under any terminal width.
BRAND_MARK_BLOCK_LINES: tuple[str, ...] = (
    "████  ████",
    "██      ██",
    "██████████",
    "██      ██",
    "████  ████",
)


def brand_mark_block() -> Group:
    """The 5-line block-H mark in brand orange.

    Returns a Rich ``Group`` of five ``Text`` rows, each rendered bold +
    brand-orange. Used as the left column of the Tier-A masthead built
    by ``brand_command_lead(mark="block")``.

    Pure renderable — no console mutation, no I/O.
    """
    style = f"bold {BRAND_ORANGE}"
    return Group(*[Text(line, style=style) for line in BRAND_MARK_BLOCK_LINES])


def brand_mark_inline() -> Text:
    """The single-line ``[H]`` brand mark.

    Brand-orange bold ``H`` between muted brackets, followed by a single
    space. Drop-in replacement for the leading ``● `` glyph in the
    Tier-B quick-command mastheads.
    """
    out = Text()
    out.append("[", style=MUTED)
    out.append("H", style=f"bold {BRAND_ORANGE}")
    out.append("] ", style=MUTED)
    return out


def brand_command_lead_with_mark_block(
    *,
    subtitle: str,
    version: str | None = None,
    date_range: str | None = None,
) -> RenderableType:
    """Tier-A masthead: 5-line block-H + vertically-centred text stack.

    Layout:

    ::

        ████  ████   halton-meter   <subtitle>
        ██      ██   v<version>
        ██████████   <date_range>
        ██      ██
        ████  ████

    The right-hand stack carries up to three rows: the wordmark + subtitle
    line, the version line, and the optional date-range line. Stack rows
    align with the centre of the H — when only two stack rows are
    supplied (``status``: no ``date_range``) the empty rows pad above and
    below to keep the wordmark vertically centred against the H crossbar
    line. The H stays anchored at the left margin regardless of terminal
    width because we drive the layout via ``Table.grid`` rather than
    string padding.

    Pair with ``brand_underrule`` (the caller composes both via
    ``brand_command_lead(mark="block")``).
    """
    # Build the right-hand text stack: wordmark+subtitle, version, date.
    wordmark_line = Text()
    wordmark_line.append("halton", style="bold bright_white")
    wordmark_line.append("-", style=BRAND_ORANGE)
    wordmark_line.append("meter", style=f"bold {BRAND_ORANGE}")
    if subtitle:
        wordmark_line.append("  ", style=MUTED)
        wordmark_line.append(ICON_CHEVRON, style=BRAND_ORANGE)
        wordmark_line.append(f"  {subtitle}", style=MUTED)

    stack_rows: list[Text] = [wordmark_line]
    if version is not None:
        stack_rows.append(Text(f"v{version}", style=MUTED))
    if date_range is not None:
        stack_rows.append(Text(date_range, style=MUTED))

    # Vertically centre the stack against the 5-line H. Pad with empty
    # rows above and below so the visual centre of the stack lands on
    # row 3 (the crossbar). 1 row → centred at row 3; 2 rows → rows 2-3;
    # 3 rows → rows 2-4. We never produce more than 3 stack rows so the
    # padding logic stays simple.
    n = len(stack_rows)
    if n == 1:
        top_pad, bottom_pad = 2, 2
    elif n == 2:
        top_pad, bottom_pad = 1, 2
    else:  # n == 3
        top_pad, bottom_pad = 1, 1

    rendered_stack: list[Text] = []
    for _ in range(top_pad):
        rendered_stack.append(Text(""))
    rendered_stack.extend(stack_rows)
    for _ in range(bottom_pad):
        rendered_stack.append(Text(""))

    grid = Table.grid(padding=(0, 0))
    grid.add_column(no_wrap=True)  # mark column
    grid.add_column()               # text-stack column
    for i in range(5):
        left = Text(BRAND_MARK_BLOCK_LINES[i], style=f"bold {BRAND_ORANGE}")
        right_line = rendered_stack[i] if i < len(rendered_stack) else Text("")
        # Three-space gutter between the H and the text stack — matches
        # the spec's mockup spacing without crowding the crossbar.
        gutter = Text("   ")
        # We pre-merge gutter into the right cell so the grid only needs
        # two columns (mark | text) rather than three.
        merged = Text()
        merged.append_text(gutter)
        merged.append_text(right_line)
        grid.add_row(left, merged)
    return grid


def brand_command_lead(
    subtitle: str,
    version: str | None = None,
    *,
    mark: str = "dot",
    date_range: str | None = None,
) -> Group:
    """The standard ``masthead + underrule`` pair every user-facing command opens with.

    Single composition point so the visual signature stays uniform across
    ``status`` / ``start`` / ``stop`` / ``init`` / ``report`` / ``doctor``.
    Returns a Group renderable: print once, get the masthead row + the
    thin muted rule directly underneath.

    Pair only — for celebratory rules (post-init success) build the
    ``brand_underrule(style=BRAND_ORANGE)`` separately at the call site.

    Args:
        subtitle: command subtitle (``"status"``, ``"cost report"``…).
        version: optional version string rendered with ``v`` prefix.
        mark: visual mark style. ``"dot"`` (default) — the legacy ``●``
            glyph leading the masthead; preserves all existing call sites
            byte-for-byte. ``"inline"`` — the ``[H]`` block-letter mark
            replaces the ``●`` glyph in an otherwise identical single-line
            masthead. ``"block"`` — the 5-line block-H mark sits to the
            left of a vertically-centred wordmark/subtitle/version stack
            (the ``brand_mark_block`` Tier-A shape used by the dwell
            surfaces ``status`` and ``report``).
        date_range: optional third line for ``mark="block"`` (e.g.
            ``"May 1 → May 7"``) rendered muted under the version. Ignored
            for the ``"dot"`` and ``"inline"`` shapes.
    """
    if mark == "block":
        return Group(
            brand_command_lead_with_mark_block(
                subtitle=subtitle,
                version=version,
                date_range=date_range,
            ),
            brand_underrule(),
        )
    if mark == "inline":
        return Group(
            brand_masthead(
                subtitle=subtitle, version=version, mark="inline"
            ),
            brand_underrule(),
        )
    # mark == "dot" — legacy shape, byte-for-byte unchanged.
    return Group(
        brand_masthead(subtitle=subtitle, version=version),
        brand_underrule(),
    )


def brand_dot_separator() -> Text:
    """A spaced muted middle-dot — the canonical inline separator.

    Use in masthead-style lines for ``A · B · C``. Centralised so the
    spacing stays uniform across surfaces.
    """
    return Text("  ·  ", style=MUTED)
