"""Provider-level helpers shared by the edge and the metering daemon.

This subpackage is import-light and stdlib-only on purpose: it is
imported by ``halton_meter.edge`` (which is otherwise stdlib-only) and
must not pull in mitmproxy / Pydantic / SQLAlchemy.
"""

from halton_meter.providers.hosts import (
    LLM_INTERCEPT_HOSTS,
    LLM_INTERCEPT_SUFFIXES,
    host_should_intercept,
    mitmproxy_ignore_hosts_regex,
)

__all__ = [
    "LLM_INTERCEPT_HOSTS",
    "LLM_INTERCEPT_SUFFIXES",
    "host_should_intercept",
    "mitmproxy_ignore_hosts_regex",
]
