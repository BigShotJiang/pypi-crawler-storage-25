"""Canonical LLM host allowlist.

This module is the single source of truth for "which hostnames should
the edge chain into the metering daemon, and which should pass through
untouched." It is imported by both ``halton_meter.edge`` (the always-on
TCP listener) and ``halton_meter.proxy`` (the mitmproxy DumpMaster
configuration), so the edge-level allowlist and mitmproxy's
``ignore_hosts`` belt-and-braces never drift apart.

Design (v0.1.22.24):

* The allowlist is intentionally **small and explicit**. A new provider
  that is not in this list is **fail-open**: traffic passes through
  unmetered rather than being broken. See the 2026-05-08 entry in
  ``memory/decisions.md`` for the rationale (edge cardinal rule:
  observation must never become a single point of failure).

* Exact-match hosts live in ``LLM_INTERCEPT_HOSTS``; suffix-match
  patterns live in ``LLM_INTERCEPT_SUFFIXES``. Suffix matching is
  performed against the **rightmost label boundary** to defend against
  the classic suffix-bypass attack
  (``foo.bedrock.amazonaws.com.evil.example`` must NOT match
  ``.bedrock.amazonaws.com``). The implementation in
  :func:`host_should_intercept` enforces this by requiring an exact
  ``.suffix`` boundary, never a substring.

* Hosts here mirror what the per-provider adapters in
  ``halton_meter/adapters/`` already accept via their ``matches()``
  methods. If you add an adapter, add its host(s) here too.
"""

from __future__ import annotations

# Exact-match hosts (case-insensitive). Each one corresponds to an
# adapter under ``halton_meter/adapters/``.
LLM_INTERCEPT_HOSTS: tuple[str, ...] = (
    "api.anthropic.com",                       # adapters/anthropic.py
    "api.openai.com",                          # adapters/openai.py
    "chatgpt.com",                             # adapters/openai_codex.py
    "generativelanguage.googleapis.com",       # adapters/gemini.py
    "cloudcode-pa.googleapis.com",             # adapters/gemini_code_assist.py
    "api.x.ai",                                # adapters/xai.py
)

# Suffix-match patterns. The leading dot is **required** — it is the
# label boundary that stops ``foo.bedrock.amazonaws.com.evil.example``
# from matching ``.bedrock.amazonaws.com``.
#
# No adapter ships for Bedrock or Vertex today; they are listed here so
# the moment an adapter lands, the allowlist already routes the regional
# host shape correctly. Specifically:
#
#   * AWS Bedrock regional endpoints look like
#     ``bedrock-runtime.<region>.amazonaws.com`` — we match the
#     ``.bedrock-runtime.amazonaws.com`` shape conservatively. The
#     exact regional pattern uses the region between two dots, which
#     means a generic ``.amazonaws.com`` suffix would be far too broad
#     (would intercept S3, DynamoDB, etc.). So we only list the
#     bedrock-prefixed shapes.
#   * Google Vertex AI regional endpoints look like
#     ``<region>-aiplatform.googleapis.com``. We match the
#     ``-aiplatform.googleapis.com`` suffix; ``aiplatform.googleapis.com``
#     itself is also included as an exact host below for the
#     non-regional surface.
LLM_INTERCEPT_SUFFIXES: tuple[str, ...] = (
    ".bedrock.amazonaws.com",
    ".bedrock-runtime.amazonaws.com",
    "-aiplatform.googleapis.com",
)

# Vertex non-regional surface — exact match.
_VERTEX_EXACT: tuple[str, ...] = (
    "aiplatform.googleapis.com",
)


def _strip_port(host: str) -> str:
    """Drop a trailing ``:port`` if present. IPv6 literals are not
    expected here (LLM provider hosts are always DNS names), but if one
    arrives we leave it intact."""
    if host.startswith("["):
        return host
    if ":" in host:
        return host.rpartition(":")[0]
    return host


def host_should_intercept(host: str) -> bool:
    """Return True if ``host`` is an LLM provider host the daemon should
    chain into mitmproxy.

    Accepts either ``api.anthropic.com`` or ``api.anthropic.com:443``.
    Comparison is case-insensitive (DNS is). A trailing dot
    (``api.anthropic.com.``) is normalised away.
    """
    if not host:
        return False
    h = _strip_port(host).lower().rstrip(".")
    if not h:
        return False
    if h in LLM_INTERCEPT_HOSTS or h in _VERTEX_EXACT:
        return True
    for suffix in LLM_INTERCEPT_SUFFIXES:
        # Suffix patterns include the leading dot so substring shenanigans
        # (``api.anthropic.com.evil.example`` matching ``.anthropic.com``)
        # cannot occur — the boundary is part of the pattern.
        if h.endswith(suffix) and len(h) > len(suffix):
            return True
    return False


def mitmproxy_ignore_hosts_regex() -> str:
    """Build the regex passed to mitmproxy's ``ignore_hosts`` option.

    mitmproxy's ``ignore_hosts`` takes a list of regexes; any CONNECT
    whose ``host:port`` matches is tunnelled transparently (no TLS
    interception, no addon hooks). We invert the allowlist so that
    anything NOT on it is ignored — belt-and-braces against the edge
    misrouting a non-LLM CONNECT into the mitm port by accident.

    Returns a single negative-lookahead regex anchored at the start of
    the host. mitmproxy applies this to the ``host:port`` string.
    """
    # Build a single negative-lookahead regex. mitmproxy's
    # ``ignore_hosts`` matches against ``host:port``; anything matching
    # is tunnelled raw. We want to ignore EVERYTHING that is not on the
    # allowlist, so we negative-lookahead the allowlist.
    exact = list(LLM_INTERCEPT_HOSTS) + list(_VERTEX_EXACT)
    exact_branches = [_re_escape(h) for h in exact]
    # Suffix branches: any prefix + the literal suffix. The leading
    # ``.+`` enforces "at least one character before the suffix" so
    # the suffix isn't matched at position 0 (which would make
    # ``.bedrock-runtime.amazonaws.com`` match nothing useful).
    suffix_branches = [f".+{_re_escape(s)}" for s in LLM_INTERCEPT_SUFFIXES]
    branches = "|".join(exact_branches + suffix_branches)
    # Each branch is followed by optional ``:port`` and end-of-string.
    allowed = f"(?:{branches})(?::\\d+)?\\Z"
    return f"^(?!{allowed}).*"


def _re_escape(s: str) -> str:
    """Inline re.escape to avoid an import — keeps this module
    importable from contexts that count their dependencies."""
    import re

    return re.escape(s)
