"""LogRecord → LogRecordIn dict mapping.

The mapping matches the Phase 2 wire contract field list exactly
(``memory/plans/phase2-wire-contract.md`` § 3, frozen at SHA ``e8f252a``).

Renames vs. local DTO:

- ``cache_read_tokens`` → ``cached_tokens`` (cloud schema name).
- ``cost_millicents`` is mirrored to ``cost_usd_minor_units`` for the
  Wave-0 alias window (contract § 3). Cloud accepts either; we send both
  so old cloud sees ``cost_millicents`` and new cloud sees the
  canonical name.

``fx_rate`` is serialised as a JSON-safe string preserving full decimal
precision — never a float. The cloud's ``LogRecordIn`` accepts both
strings and ``Decimal``-shaped numbers, but only the string form is
lossless on the wire.

Forward-compat rule (contract § 5): the daemon never sends a field cloud
doesn't know about until cloud is deployed first. The field list below
is exactly what cloud at SHA ``e8f252a`` accepts; we don't add fields
here without bumping the cloud's pinned SHA and the Wave-0 contract doc.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from halton_meter.cloud.privacy import (
    UploadPolicy,
    apply_to_wire,
    resolve_for_project,
)
from halton_meter.models import LogRecord


def log_record_to_wire(
    record: LogRecord,
    *,
    source_machine: str | None = None,
    upload_policy: UploadPolicy | None = None,
) -> dict[str, Any] | None:
    """Map a local :class:`LogRecord` to a wire ``LogRecordIn`` dict.

    Args:
        record: The local record DTO. Must already carry daemon-issued
            ``id`` (UUIDv4 string) — the cloud never re-ids records
            (contract § 5.3).
        source_machine: Optional hostname snapshot. The Wave 1A.i
            ``LogRecord`` extension will add this field directly; for now
            we accept it as a kwarg so 1A.iii can land independently. If
            both the record and the kwarg supply a value, the record
            wins.

        upload_policy: Optional resolved privacy policy. When supplied,
            per-project rules can drop the record entirely (returning
            ``None``) and gateable fields are nulled per the policy.
            ``None`` means "no redaction" — preserves the pre-privacy
            contract so existing tests and the body-sync path keep
            working unchanged.

    Returns:
        A dict whose keys are exactly the wire-contract field list, or
        ``None`` if the policy's per-project rule said this record
        should not upload at all. ``None``-valued optional fields are
        still included for shape stability — cloud's
        ``extra='ignore'`` makes that safe and the explicit ``null`` is
        easier to grep in logs than an omitted key.

    Raises:
        Nothing. The mapping is total over the current ``LogRecord``
        shape. Any future wire field that requires a transform belongs
        here, not in the caller.
    """
    # ``LogRecord`` is frozen Pydantic; ``getattr`` lets us tolerate the
    # Wave-1A.i additions before they land in models.py (this PR is
    # 1A.iii — model fields ship in 1A.i).
    fx_rate = _serialize_fx_rate(getattr(record, "fx_rate", None))

    # Money: ``cost_millicents`` is the legacy local field name; the wire
    # contract uses ``cost_usd_minor_units`` as the canonical name with
    # ``cost_millicents`` as an accepted alias during the Wave-0 window.
    # We send the same value under both keys so either cloud version
    # accepts the row.
    cost = record.cost_millicents

    wire: dict[str, Any] = {
        "id": record.id,
        "project": record.project,
        "provider": record.provider,
        "model": record.model,
        "input_tokens": record.input_tokens,
        "output_tokens": record.output_tokens,
        "thinking_tokens": record.thinking_tokens,
        "cached_tokens": record.cache_read_tokens,
        "cache_write_tokens": record.cache_write_tokens,
        "cost_millicents": cost,
        "cost_usd_minor_units": cost,
        "fx_rate": fx_rate,
        "tokens_complete": record.tokens_complete,
        "latency_ms": record.latency_ms,
        "time_to_first_token_ms": getattr(record, "time_to_first_token_ms", None),
        "requested_at": record.requested_at,
        "recorded_at": record.recorded_at,
        "status": record.status,
        "request_kind": getattr(record, "request_kind", None),
        "attribution_method": record.attribution_method,
        "source_workdir": record.source_workdir,
        "source_machine": getattr(record, "source_machine", None) or source_machine,
        "prompt_hash": getattr(record, "prompt_hash", None),
        "idempotency_key": getattr(record, "idempotency_key", None),
    }

    if upload_policy is None:
        return wire

    resolved = resolve_for_project(upload_policy, record.project)
    if not resolved.upload:
        # Per-project rule says skip this record entirely.
        return None
    return apply_to_wire(wire, resolved)


def _serialize_fx_rate(value: Decimal | float | str | None) -> str | None:
    """Render an FX rate for the wire.

    Cloud's schema is ``Numeric(10,6)`` so we emit at most 6 fractional
    digits. ``Decimal`` round-trips lossless; ``float`` is coerced via
    ``Decimal(str(float))`` to avoid binary-fraction surprises. ``None``
    passes through.
    """
    if value is None:
        return None
    if isinstance(value, Decimal):
        d = value
    elif isinstance(value, str):
        d = Decimal(value)
    else:
        # Coerce float → Decimal through str so 0.79 doesn't become
        # 0.78999999999999999.
        d = Decimal(str(value))
    # Quantise to 6dp; ``normalize()`` would drop trailing zeros, which
    # is fine for the wire but breaks straight string compares in tests
    # — we keep the explicit ``f`` formatting.
    return format(d, "f")
