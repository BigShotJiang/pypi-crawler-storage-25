"""Cloud sync subpackage (Phase 2, Wave 1A.iii — scaffolding only).

This subpackage isolates everything that talks to the halton-meter-cloud
SaaS:

- ``client.py`` — async ``httpx`` client with its own connection pool. Kept
  off the proxy hot path so a wedged cloud sync cannot stall request
  capture.
- ``serialize.py`` — pure ``LogRecord`` → ``LogRecordIn`` dict mapping
  matching the Phase 2 wire contract (commit SHA ``e8f252a``).
- ``errors.py`` — typed exceptions surfaced by ``client.py``.
- ``config_glue.py`` — adapter from the existing ``HaltonConfig`` to the
  cloud client's view of the world.
- ``worker.py`` — async loop that drives ``client.batch_ingest``.
  Scaffolding only in this wave; **not wired into daemon startup yet**
  (that lands in Wave 2A.2). Exposed as :func:`worker.run_once` and
  :func:`worker.run_forever` so the CLI's ``cloud sync`` command can
  exercise the drain path today.

Wire contract: ``memory/plans/phase2-wire-contract.md`` @ SHA e8f252a.
Daemon plan:   ``memory/plans/phase2-daemon-changes.md``.
"""

from __future__ import annotations

from halton_meter.cloud import client, config_glue, errors, serialize, worker

__all__ = [
    "client",
    "config_glue",
    "errors",
    "serialize",
    "worker",
]
