"""Supervisor glue — wire ``cloud.worker.run_forever`` into the daemon.

Phase 2 Wave 2A.2. Extracted to its own module so the supervisor wiring
in ``halton_meter.cli._run_daemon`` is a one-line spawn and so the
gating logic (config-on, token-present) is unit-testable without
booting the whole daemon process.

Design notes:

* The cloud worker shares the daemon's event loop (same-process spawn,
  per the Wave-2 operator decision). This avoids a second supervised
  process for v0.2.0 and keeps cancellation semantics simple: a single
  ``shutdown_event`` flows from the signal handler through to
  :func:`halton_meter.cloud.worker.run_forever`.

* A cloud-task crash MUST NEVER terminate the daemon. ``run_forever``
  itself catches per-tick exceptions; this glue wraps the whole task in
  a try/except so a structural failure (e.g. ``CloudClient.__aenter__``
  raising) is logged and absorbed.

* Gating order: ``CloudClientConfig.is_active`` first (cheap), then
  token presence (the worker is useless without an API key). When
  either is false the spawn is skipped silently — the daemon proxy
  hot path keeps writing local rows.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from halton_meter.cloud.body_uploader import (
    BodyRecord,
    PendingReader,
    ProjectGate,
    UploadMarker,
)
from halton_meter.cloud.body_uploader import (
    PauseWriter as BodyPauseWriter,
)
from halton_meter.cloud.body_uploader import (
    run_forever as body_run_forever,
)
from halton_meter.cloud.client import CloudClient, _stub_token_provider
from halton_meter.cloud.config_glue import (
    CloudBodiesConfig,
    CloudClientConfig,
    load_bodies_config,
    load_cloud_config,
    load_upload_policy,
)
from halton_meter.cloud.privacy import UploadPolicy
from halton_meter.cloud.worker import (
    BatchLoader,
    Cursor,
    CursorAdvancer,
    CursorReader,
    ErrorWriter,
    PauseWriter,
    run_forever,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------- #
# Storage-backed factories
#
# Lifted out of ``halton_meter.cli_cloud`` (where the ``cloud sync``
# one-shot still lives) so the supervisor spawn site in
# ``halton_meter.cli`` can import them without pulling in any
# ``halton_meter.cli*`` module — the proxy hot path must stay free of
# Click / rich / CLI-only deps. ``cli_cloud`` re-imports the same
# factories from this module so the one-shot ``cloud sync`` command
# and the supervisor share persistence semantics.
# ---------------------------------------------------------------------- #


def _resolved_db_path() -> str:
    """Resolve the SQLite path the daemon writes to.

    Mirrors :func:`halton_meter.config.load_config` so the supervisor
    and the one-shot ``cloud sync`` command always land on the same
    file regardless of process entry point.
    """
    from halton_meter.config import load_config

    cfg = load_config()
    return cfg.storage.db_path


def make_cursor_reader(endpoint: str) -> CursorReader:
    """Return a cursor_reader callable backed by ``cloud_sync_state``."""

    from halton_meter.storage import StorageManager

    async def _reader() -> Cursor:
        try:
            async with StorageManager(_resolved_db_path()) as storage:
                state = await storage.cloud_get_sync_state(endpoint)
        except Exception as exc:
            logger.warning("cloud.cursor_read_failed: %s", exc)
            return Cursor.pristine()
        if state is None or state.last_synced_request_recorded_at is None:
            return Cursor.pristine()
        recorded_at = state.last_synced_request_recorded_at.isoformat().replace(
            "+00:00", "Z"
        )
        return Cursor(
            recorded_at=recorded_at,
            record_id=state.last_synced_request_id or "",
        )

    return _reader


def make_batch_loader(
    upload_policy: UploadPolicy | None = None,
) -> BatchLoader:
    """Return a batch_loader that pulls + serialises the next page.

    The upload policy, when supplied, redacts gateable fields and drops
    records whose per-project rule says ``upload=false``. Dropped records
    still **advance the cursor** — the worker's cursor advance happens at
    the records-fetched level, not the records-uploaded level, so a
    deliberately-skipped project does not block sync for other projects.

    When ``upload_policy`` is ``None`` (legacy / tests) the serializer
    falls through to the pre-privacy behaviour: every field travels.
    """

    from halton_meter.cloud.serialize import log_record_to_wire
    from halton_meter.storage import StorageManager

    async def _loader(cursor: Cursor, limit: int) -> list[dict[str, Any]]:
        try:
            async with StorageManager(_resolved_db_path()) as storage:
                if cursor.recorded_at and cursor.record_id:
                    cur_at = datetime.fromisoformat(
                        cursor.recorded_at.replace("Z", "+00:00")
                    )
                    records = await storage.cloud_unsynced_batch(
                        limit=limit, cursor=(cur_at, cursor.record_id)
                    )
                else:
                    records = await storage.cloud_unsynced_batch(limit=limit)
        except Exception as exc:
            logger.warning("cloud.batch_load_failed: %s", exc)
            return []
        wire: list[dict[str, Any]] = []
        for r in records:
            payload = log_record_to_wire(r, upload_policy=upload_policy)
            if payload is not None:
                wire.append(payload)
        return wire

    return _loader


def make_cursor_advancer(endpoint: str) -> CursorAdvancer:
    """Return a cursor_advancer that transactionally updates ``cloud_sync_state``.

    Success contract per phase2-daemon-changes.md § 2b: cursor advance,
    ``last_batch_succeeded_at`` stamped to now, ``consecutive_failures``
    reset, ``last_error`` cleared. All in one transaction (delegated to
    ``StorageManager.cloud_advance_cursor``).
    """

    from halton_meter.storage import StorageManager

    async def _advancer(cursor: Cursor) -> None:
        try:
            async with StorageManager(_resolved_db_path()) as storage:
                await storage.cloud_advance_cursor(
                    endpoint=endpoint,
                    record_id=cursor.record_id,
                    recorded_at=cursor.recorded_at,
                )
        except Exception as exc:
            # Cardinal: never raise out of the worker hot path. The next
            # tick will pick up the same batch and retry.
            logger.warning("cloud.cursor_advance_failed: %s", exc)

    return _advancer


def make_pause_writer(endpoint: str) -> PauseWriter:
    """Return a pause_writer that mirrors ``paused_reason`` onto both tables.

    v0.2.8: also stamps ``last_error_at`` so ``cloud status`` can show
    when the pause was set. The pause-classification is strict — see
    :mod:`halton_meter.cloud.worker` for the rules. This writer is only
    called for terminal causes (401 → paused_unauthorised,
    403 → paused_forbidden); transient failures route through
    :func:`make_error_writer` instead and never touch ``paused_reason``.
    """

    from halton_meter.storage import StorageManager
    from halton_meter.storage.models import CloudSyncState

    async def _writer(reason: str) -> None:
        try:
            now = datetime.now(tz=UTC)
            async with StorageManager(_resolved_db_path()) as storage:
                async with storage._sessionmaker() as session, session.begin():  # type: ignore[union-attr]
                    state = await session.get(CloudSyncState, endpoint)
                    if state is None:
                        state = CloudSyncState(
                            endpoint=endpoint,
                            consecutive_failures=1,
                            last_error=f"worker paused: {reason}"[:512],
                            last_error_at=now,
                            paused_reason=reason,
                        )
                        session.add(state)
                    else:
                        state.consecutive_failures = (
                            state.consecutive_failures or 0
                        ) + 1
                        state.last_error = f"worker paused: {reason}"[:512]
                        state.last_error_at = now
                        state.last_batch_attempted_at = now
                        state.paused_reason = reason
                # Mirror onto cloud_state so ``cloud status`` reads the same
                # story from either table.
                await storage.cloud_set_state(
                    endpoint=endpoint, paused_reason=reason
                )
        except Exception as exc:
            logger.warning("cloud.pause_write_failed: %s", exc)

    return _writer


def make_error_writer(endpoint: str) -> ErrorWriter:
    """Return an error_writer for transient sync failures (v0.2.8).

    Called by :func:`halton_meter.cloud.worker.run_once` when a tick
    fails for a non-terminal reason — 5xx, connection reset, timeout,
    DNS failure, 429, or 422/400. Bumps ``consecutive_failures``, writes
    ``last_error`` + ``last_error_at``, but DOES NOT touch
    ``paused_reason``. The next tick retries the same batch.

    The split between pause_writer and error_writer is the heart of the
    v0.2.8 fix: previously any sync failure inside the worker's catch
    arm wrote ``paused_unauthorised``, forcing users to re-pair after a
    transient ALB hiccup. Now only real 401s pause.
    """

    from halton_meter.storage import StorageManager
    from halton_meter.storage.models import CloudSyncState

    async def _writer(detail: str) -> None:
        try:
            now = datetime.now(tz=UTC)
            async with StorageManager(_resolved_db_path()) as storage:
                async with storage._sessionmaker() as session, session.begin():  # type: ignore[union-attr]
                    state = await session.get(CloudSyncState, endpoint)
                    if state is None:
                        state = CloudSyncState(
                            endpoint=endpoint,
                            consecutive_failures=1,
                            last_error=detail[:512],
                            last_error_at=now,
                            paused_reason=None,
                        )
                        session.add(state)
                    else:
                        state.consecutive_failures = (
                            state.consecutive_failures or 0
                        ) + 1
                        state.last_error = detail[:512]
                        state.last_error_at = now
                        state.last_batch_attempted_at = now
                        # Deliberately do NOT touch ``paused_reason`` —
                        # transient failures must not pause the worker.
        except Exception as exc:
            logger.warning("cloud.error_write_failed: %s", exc)

    return _writer


# ---------------------------------------------------------------------- #
# Public surface
# ---------------------------------------------------------------------- #


async def _run_cloud_worker(
    *,
    cfg: CloudClientConfig,
    cursor_reader: CursorReader,
    batch_loader: BatchLoader,
    cursor_advancer: CursorAdvancer,
    pause_writer: PauseWriter,
    error_writer: ErrorWriter | None = None,
    stop_event: asyncio.Event,
    client_factory: Callable[[str], CloudClient] | None = None,
) -> None:
    """Construct a :class:`CloudClient` and drive :func:`run_forever`.

    Failure-mode contract:

    * Any exception raised during client construction or inside
      ``run_forever`` is caught and logged. The coroutine returns
      cleanly. The daemon stays up.
    * ``stop_event`` is forwarded to :func:`run_forever` so a SIGTERM
      walks the daemon → supervisor glue → worker → tick boundary out
      cleanly.
    """
    factory = client_factory or (lambda url: CloudClient(base_url=url))
    try:
        async with factory(cfg.base_url) as client:
            await run_forever(
                client,
                cursor_reader=cursor_reader,
                batch_loader=batch_loader,
                cursor_advancer=cursor_advancer,
                pause_writer=pause_writer,
                error_writer=error_writer,
                interval_seconds=float(cfg.sync_interval_seconds),
                stop_event=stop_event,
            )
    except asyncio.CancelledError:
        # Cooperative cancellation from the outer shutdown — propagate so
        # the supervisor sees the task transitioned cleanly.
        raise
    except Exception:
        # Cardinal: a cloud-task crash MUST NEVER terminate the daemon.
        logger.exception("cloud.supervisor.worker_crashed")


def _resolve_token_for_gating(
    *,
    token_provider: Callable[[], str | None] | None = None,
) -> str | None:
    """Probe whether a usable token exists. Used for spawn-gating only.

    Returns the token string, or ``None`` if no token is configured /
    every loader path failed. NEVER raises — a corrupt credentials file
    must not crash daemon startup.
    """
    provider = token_provider or _stub_token_provider
    try:
        return provider()
    except Exception:
        # Fail-open: treat any loader failure as "no token, don't spawn".
        # The user's local-proxy workflow remains intact.
        logger.debug("cloud.supervisor.token_probe_failed", exc_info=True)
        return None


def maybe_spawn_cloud_worker(
    *,
    shutdown_event: asyncio.Event,
    cursor_reader_factory: Callable[[str], CursorReader],
    batch_loader_factory: Callable[[], BatchLoader],
    cursor_advancer_factory: Callable[[str], CursorAdvancer],
    pause_writer_factory: Callable[[str], PauseWriter],
    error_writer_factory: Callable[[str], ErrorWriter] | None = None,
    cloud_config_loader: Callable[[], CloudClientConfig] | None = None,
    token_provider: Callable[[], str | None] | None = None,
    client_factory: Callable[[str], CloudClient] | None = None,
    task_runner: Callable[[Awaitable[None], str], asyncio.Task[None]] | None = None,
) -> asyncio.Task[None] | None:
    """Spawn the cloud-sync worker as an asyncio task, if gates pass.

    Returns the spawned :class:`asyncio.Task`, or ``None`` when the
    spawn was suppressed (cloud disabled, no endpoint, no token). The
    caller does not need to await the task — the daemon's event loop
    runs it concurrently with the proxy / API / health tasks.

    All collaborator wiring is injected so the gating logic is
    unit-testable without touching SQLite, the filesystem, or the live
    cloud endpoint.

    Args:
        shutdown_event: Set by the daemon's signal handler. Forwarded
            to :func:`run_forever` as ``stop_event``.
        cursor_reader_factory / batch_loader_factory / ...: Match the
            seams already used by ``halton_meter.cli_cloud`` so the
            supervisor and the one-shot ``cloud sync`` command share
            persistence semantics. Endpoint is supplied at spawn time.
        cloud_config_loader: Override for tests. Defaults to
            :func:`load_cloud_config`.
        token_provider: Override for tests. Defaults to the stub used
            by :class:`CloudClient`.
        client_factory: Override for tests (typically a lambda binding
            a :class:`httpx.MockTransport`).
        task_runner: Override for tests. Defaults to
            ``asyncio.create_task``. Tests inject a recording stub so
            the spawn decision can be asserted without scheduling.
    """
    loader = cloud_config_loader or load_cloud_config
    cfg = loader()
    upload_policy = load_upload_policy()
    if not cfg.is_active:
        logger.info(
            "cloud.supervisor.skip",
            extra={"reason": "disabled", "endpoint": cfg.base_url or ""},
        )
        return None

    token = _resolve_token_for_gating(token_provider=token_provider)
    if not token:
        logger.info(
            "cloud.supervisor.skip",
            extra={"reason": "no_token", "endpoint": cfg.base_url},
        )
        return None

    endpoint = cfg.base_url
    # The default factory ignores its extra args; tests injecting their own
    # factory may pass through the policy or ignore it.
    try:
        batch_loader = batch_loader_factory(upload_policy)  # type: ignore[call-arg]
    except TypeError:
        batch_loader = batch_loader_factory()
    # v0.2.8 — error_writer is optional in the factory signature so
    # older callers (tests, the one-shot ``cloud sync`` command) still
    # work. The supervisor wires it by default.
    error_writer: ErrorWriter | None = None
    if error_writer_factory is not None:
        error_writer = error_writer_factory(endpoint)
    else:
        # Default to the storage-backed writer so the daemon supervisor
        # records transient errors without callers having to remember.
        error_writer = make_error_writer(endpoint)

    coro = _run_cloud_worker(
        cfg=cfg,
        cursor_reader=cursor_reader_factory(endpoint),
        batch_loader=batch_loader,
        cursor_advancer=cursor_advancer_factory(endpoint),
        pause_writer=pause_writer_factory(endpoint),
        error_writer=error_writer,
        stop_event=shutdown_event,
        client_factory=client_factory,
    )
    runner = task_runner or _default_task_runner
    task = runner(coro, "halton-cloud-worker")
    logger.info(
        "cloud.supervisor.spawned",
        extra={
            "endpoint": endpoint,
            "interval_seconds": cfg.sync_interval_seconds,
        },
    )
    return task


def _default_task_runner(
    coro: Awaitable[None], name: str
) -> asyncio.Task[None]:
    """Concrete ``asyncio.create_task`` wrapper.

    Lives here (not inline) so tests can swap it with a recorder via
    the ``task_runner`` injection point.
    """
    return asyncio.create_task(coro, name=name)  # type: ignore[arg-type]


# ---------------------------------------------------------------------- #
# Body uploader (v0.2.2)
#
# Sibling supervisor surface to ``maybe_spawn_cloud_worker``. Same
# fail-open posture; same shared event loop; its own gates, its own
# pause table, its own cursor (``request_bodies.uploaded_at``).
# ---------------------------------------------------------------------- #


def make_body_pending_reader() -> PendingReader:
    """Return a pending-reader callable backed by SQLite."""

    from halton_meter.storage import StorageManager

    async def _reader(limit: int) -> list[BodyRecord]:
        try:
            async with StorageManager(_resolved_db_path()) as storage:
                rows = await storage.bodies_pending_upload(limit=limit)
        except Exception as exc:
            logger.warning("cloud.body_pending_read_failed: %s", exc)
            return []
        return [
            BodyRecord(
                request_id=str(r["request_id"]),
                project_slug=str(r["project_slug"]),
                request_body=r.get("request_body"),
                response_body=r.get("response_body"),
                request_content_type=r.get("request_content_type"),
                response_content_type=r.get("response_content_type"),
                request_body_bytes=int(r.get("request_body_bytes") or 0),
                response_body_bytes=int(r.get("response_body_bytes") or 0),
                redaction_applied=bool(r.get("redaction_applied")),
                redaction_summary=r.get("redaction_summary"),
            )
            for r in rows
        ]

    return _reader


def make_body_upload_marker() -> UploadMarker:
    """Return a marker that stamps ``uploaded_at`` on a single body row."""

    from halton_meter.storage import StorageManager

    async def _marker(request_id: str) -> None:
        try:
            async with StorageManager(_resolved_db_path()) as storage:
                await storage.bodies_mark_uploaded(request_id)
        except Exception as exc:
            logger.warning("cloud.body_mark_uploaded_failed: %s", exc)

    return _marker


def make_body_pause_writer(endpoint: str) -> BodyPauseWriter:
    """Return a pause writer for the body uploader (separate table)."""

    from halton_meter.storage import StorageManager

    async def _writer(reason: str | None) -> None:
        try:
            async with StorageManager(_resolved_db_path()) as storage:
                await storage.body_sync_set_pause(endpoint, reason)
        except Exception as exc:
            logger.warning("cloud.body_pause_write_failed: %s", exc)

    return _writer


def make_project_gate(cfg: CloudBodiesConfig) -> ProjectGate:
    """Wrap :meth:`CloudBodiesConfig.should_upload` as a callable."""
    return lambda slug: cfg.should_upload(slug)


async def _run_body_uploader(
    *,
    base_url: str,
    interval_seconds: int,
    max_body_bytes_per_upload: int,
    pending_reader: PendingReader,
    upload_marker: UploadMarker,
    pause_writer: BodyPauseWriter,
    project_gate: ProjectGate,
    stop_event: asyncio.Event,
    client_factory: Callable[[str], CloudClient] | None = None,
) -> None:
    """Construct a :class:`CloudClient` and drive the body uploader.

    Failure-mode contract matches :func:`_run_cloud_worker`: client
    construction or run_forever exceptions are caught, logged, and
    absorbed. The daemon stays up.
    """
    factory = client_factory or (lambda url: CloudClient(base_url=url))
    try:
        async with factory(base_url) as client:
            await body_run_forever(
                client,
                pending_reader=pending_reader,
                upload_marker=upload_marker,
                pause_writer=pause_writer,
                project_gate=project_gate,
                interval_seconds=float(interval_seconds),
                max_body_bytes_per_upload=max_body_bytes_per_upload,
                stop_event=stop_event,
            )
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("cloud.supervisor.body_uploader_crashed")


def maybe_spawn_body_uploader(
    *,
    shutdown_event: asyncio.Event,
    pending_reader_factory: Callable[[], PendingReader] | None = None,
    upload_marker_factory: Callable[[], UploadMarker] | None = None,
    pause_writer_factory: Callable[[str], BodyPauseWriter] | None = None,
    project_gate_factory: Callable[[CloudBodiesConfig], ProjectGate] | None = None,
    cloud_config_loader: Callable[[], CloudClientConfig] | None = None,
    bodies_config_loader: Callable[[], CloudBodiesConfig] | None = None,
    token_provider: Callable[[], str | None] | None = None,
    client_factory: Callable[[str], CloudClient] | None = None,
    task_runner: Callable[[Awaitable[None], str], asyncio.Task[None]] | None = None,
) -> asyncio.Task[None] | None:
    """Spawn the body uploader as an asyncio task, if every gate passes.

    Gates (order matters — cheap first):

    1. ``CloudClientConfig.is_active`` (cloud master switch + base URL).
    2. ``CloudBodiesConfig.enabled`` (the v0.2.2 bodies opt-in).
    3. Token present (the same provider the metadata worker uses).

    Returns the spawned :class:`asyncio.Task`, or ``None`` if any gate
    fails. Logging on skip mirrors the metadata-worker pattern so
    operators have one consistent log line to grep for.
    """
    cloud_loader = cloud_config_loader or load_cloud_config
    bodies_loader = bodies_config_loader or load_bodies_config

    cfg_cloud = cloud_loader()
    if not cfg_cloud.is_active:
        logger.info(
            "cloud.supervisor.body_skip",
            extra={"reason": "cloud_disabled", "endpoint": cfg_cloud.base_url or ""},
        )
        return None

    cfg_bodies = bodies_loader()
    if not cfg_bodies.enabled:
        logger.info(
            "cloud.supervisor.body_skip",
            extra={"reason": "bodies_disabled", "endpoint": cfg_cloud.base_url},
        )
        return None

    token = _resolve_token_for_gating(token_provider=token_provider)
    if not token:
        logger.info(
            "cloud.supervisor.body_skip",
            extra={"reason": "no_token", "endpoint": cfg_cloud.base_url},
        )
        return None

    endpoint = cfg_cloud.base_url
    pending_reader = (pending_reader_factory or make_body_pending_reader)()
    upload_marker = (upload_marker_factory or make_body_upload_marker)()
    pause_writer = (pause_writer_factory or make_body_pause_writer)(endpoint)
    project_gate = (project_gate_factory or make_project_gate)(cfg_bodies)

    coro = _run_body_uploader(
        base_url=endpoint,
        interval_seconds=cfg_bodies.sync_interval_seconds,
        max_body_bytes_per_upload=cfg_bodies.max_body_bytes_per_upload,
        pending_reader=pending_reader,
        upload_marker=upload_marker,
        pause_writer=pause_writer,
        project_gate=project_gate,
        stop_event=shutdown_event,
        client_factory=client_factory,
    )
    runner = task_runner or _default_task_runner
    task = runner(coro, "halton-cloud-body-uploader")
    logger.info(
        "cloud.supervisor.body_spawned",
        extra={
            "endpoint": endpoint,
            "interval_seconds": cfg_bodies.sync_interval_seconds,
            "max_bytes": cfg_bodies.max_body_bytes_per_upload,
            "per_project_count": len(cfg_bodies.per_project),
        },
    )
    return task


__all__ = [
    "make_batch_loader",
    "make_body_pause_writer",
    "make_body_pending_reader",
    "make_body_upload_marker",
    "make_cursor_advancer",
    "make_cursor_reader",
    "make_error_writer",
    "make_pause_writer",
    "make_project_gate",
    "maybe_spawn_body_uploader",
    "maybe_spawn_cloud_worker",
]
