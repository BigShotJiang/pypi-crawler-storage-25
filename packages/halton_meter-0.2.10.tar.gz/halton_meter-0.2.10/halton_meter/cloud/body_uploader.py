"""BodyUploader — v0.2.2 cloud body sync worker.

Sibling to ``halton_meter.cloud.worker`` (metadata sync). Where the metadata
worker pushes ``LogRecord`` rows on a ``(recorded_at, id)`` cursor, this
module pushes captured request/response bodies row-by-row, tracked by
``request_bodies.uploaded_at``:

* Selection: rows where ``uploaded_at IS NULL`` AND a matching ``requests``
  row exists. Ordered by ``captured_at ASC`` — oldest first, FIFO.
* Per row, fire **two POSTs** to ``/v1/requests/{id}/body`` — one for the
  request leg (when ``request_body`` is non-NULL) and one for the response
  leg (when ``response_body`` is non-NULL).
* On both POSTs ACKing successfully, stamp ``uploaded_at`` to ``now()`` and
  move on.
* Per-project ``upload=false`` rows are **skipped network-wise but stamped**
  so the cursor advances — a deliberately-skipped project must not block
  sync for other projects.

The worker is **dual-isolated** from the metadata worker:

* Its own cursor (no overlap with ``cloud_sync_state``).
* Its own ``cloud_body_sync_state`` row for pause / error tracking.
* A 401 pauses bodies-only; metadata sync continues until it sees its own
  401. Symmetrically, a metadata 401 doesn't stop bodies. Operationally,
  re-running ``cloud connect`` clears both.

The hot path NEVER blocks the daemon proxy. Crash isolation is the same as
the metadata worker: exceptions are logged and absorbed; the daemon stays
up regardless of cloud state.

Wire shape: ``BodyEnvelopeV021`` (cloud's class name; the wire fields are
the public contract). Sent via ``CloudClient.upload_request_body``.
"""

from __future__ import annotations

import asyncio
import base64
import json as _json
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.errors import (
    CloudRateLimited,
    CloudSchemaMismatch,
    CloudTransport,
    CloudUnauthorised,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------- #
# Injection seams
# ---------------------------------------------------------------------- #


@dataclass(frozen=True)
class BodyRecord:
    """One pending body — both legs in a single value object.

    Either or both of ``request_body`` / ``response_body`` may be ``None``
    (e.g. capture-error on one direction). The uploader fires a POST only
    for non-NULL legs.
    """

    request_id: str
    project_slug: str
    request_body: str | None
    response_body: str | None
    request_content_type: str | None
    response_content_type: str | None
    request_body_bytes: int
    response_body_bytes: int
    redaction_applied: bool
    redaction_summary: str | None  # raw TEXT (JSON map)


PendingReader = Callable[[int], Awaitable[list[BodyRecord]]]
UploadMarker = Callable[[str], Awaitable[None]]
PauseWriter = Callable[[str | None], Awaitable[None]]
ProjectGate = Callable[[str | None], bool]


# ---------------------------------------------------------------------- #
# Public API
# ---------------------------------------------------------------------- #


@dataclass(frozen=True)
class BodyDrainResult:
    """Outcome of one :func:`run_once` invocation.

    Attributes:
        records_processed: Bodies the worker walked past — uploaded plus
            project-skipped.
        legs_sent: Number of POSTs whose 2xx ACK was received.
        skipped_by_project: Records that the per-project gate dropped
            before any network call.
        paused: Terminal pause signal received (401).
        caught_up: No more pending bodies after this tick.
    """

    records_processed: int
    legs_sent: int
    skipped_by_project: int
    paused: bool
    caught_up: bool


def _make_envelope(
    *,
    request_id: str,
    direction: str,
    body_text: str,
    content_type: str | None,
    original_size_bytes: int,
    redaction_applied: bool,
    redaction_summary: str | None,
) -> dict[str, Any]:
    """Build a wire envelope dict matching ``BodyEnvelopeV021``.

    ``body_text`` is the post-redaction body bytes as stored locally; the
    daemon's writer already redacted credentials (see
    ``daemon/halton_meter/redaction/credentials.py``) before persistence,
    so the upload payload is identical to what's on disk.
    """
    encoded = base64.b64encode(body_text.encode("utf-8")).decode("ascii")
    summary_list: list[str] = []
    if redaction_summary:
        try:
            payload = _json.loads(redaction_summary)
            if isinstance(payload, dict):
                summary_list = sorted(str(k) for k in payload.keys())
        except (ValueError, TypeError):
            summary_list = []
    return {
        "request_id": request_id,
        "direction": direction,
        "content_type": content_type or "application/octet-stream",
        "body_b64": encoded,
        "redaction_applied": bool(redaction_applied),
        "redaction_summary": summary_list,
        "original_size_bytes": int(original_size_bytes or 0),
    }


async def run_once(
    client: CloudClient,
    *,
    pending_reader: PendingReader,
    upload_marker: UploadMarker,
    pause_writer: PauseWriter,
    project_gate: ProjectGate,
    max_body_bytes_per_upload: int = 524_288,
    batch_size: int = 50,
    max_batches: int = 4,
) -> BodyDrainResult:
    """Drain pending body rows until caught up or a terminal error fires.

    Used by the BodyUploader's run_forever and by the test surface as a
    single-tick driver. Per-record errors are surfaced as exceptions from
    the caller of :meth:`CloudClient.upload_request_body` — transient
    failures bubble up and the loop pauses on the failed row without
    advancing it (it will be retried on the next tick).

    Args:
        client: A live :class:`CloudClient`, inside its async context.
        pending_reader: ``async (limit) -> list[BodyRecord]``. Returns
            rows with ``uploaded_at IS NULL`` ordered by ``captured_at``.
        upload_marker: ``async (request_id) -> None``. Stamps
            ``uploaded_at`` for the row. Called for both shipped and
            project-skipped rows.
        pause_writer: ``async (reason | None) -> None``. Persists the
            terminal pause flag. Called once on 401 with ``"paused_unauthorised"``.
        project_gate: Pure function ``(project_slug | None) -> bool`` —
            ``False`` means "don't upload; advance cursor".
        max_body_bytes_per_upload: Skip legs whose stored bytes exceed
            this cap. The body row still advances. Default 512 KiB.
        batch_size: Records fetched per loader call.
        max_batches: Safety stop per tick.
    """
    records_processed = 0
    legs_sent = 0
    skipped_by_project = 0

    for _ in range(max_batches):
        batch = await pending_reader(batch_size)
        if not batch:
            return BodyDrainResult(
                records_processed=records_processed,
                legs_sent=legs_sent,
                skipped_by_project=skipped_by_project,
                paused=False,
                caught_up=True,
            )

        for record in batch:
            # Per-project gate — drop entirely before any wire activity.
            if not project_gate(record.project_slug):
                await upload_marker(record.request_id)
                skipped_by_project += 1
                records_processed += 1
                continue

            try:
                legs_sent += await _upload_one(
                    client,
                    record,
                    max_body_bytes_per_upload=max_body_bytes_per_upload,
                )
            except CloudUnauthorised:
                # Terminal — pause bodies-only and stop.
                await pause_writer("paused_unauthorised")
                return BodyDrainResult(
                    records_processed=records_processed,
                    legs_sent=legs_sent,
                    skipped_by_project=skipped_by_project,
                    paused=True,
                    caught_up=False,
                )
            except (CloudTransport, CloudRateLimited):
                # Transient — DON'T mark uploaded. The next tick will see
                # the same row at the head of the queue and retry.
                logger.warning(
                    "cloud.body_uploader.transient_failure",
                    extra={"request_id": record.request_id},
                )
                # Bail out of the inner loop to back off — keep error
                # blast radius small.
                return BodyDrainResult(
                    records_processed=records_processed,
                    legs_sent=legs_sent,
                    skipped_by_project=skipped_by_project,
                    paused=False,
                    caught_up=False,
                )
            except CloudSchemaMismatch as exc:
                # Hard rejection from cloud (e.g. 4xx that isn't 401). The
                # row is broken in a way retries won't fix; mark it uploaded
                # so we don't pin the queue on it forever. Surface in logs.
                logger.error(
                    "cloud.body_uploader.schema_mismatch",
                    extra={
                        "request_id": record.request_id,
                        "error": str(exc),
                    },
                )
                await upload_marker(record.request_id)
                records_processed += 1
                continue

            # Both legs (or whatever was present) shipped. Stamp the cursor.
            await upload_marker(record.request_id)
            records_processed += 1

        # If the loader returned a short page we're caught up.
        if len(batch) < batch_size:
            return BodyDrainResult(
                records_processed=records_processed,
                legs_sent=legs_sent,
                skipped_by_project=skipped_by_project,
                paused=False,
                caught_up=True,
            )

    return BodyDrainResult(
        records_processed=records_processed,
        legs_sent=legs_sent,
        skipped_by_project=skipped_by_project,
        paused=False,
        caught_up=False,
    )


async def _upload_one(
    client: CloudClient,
    record: BodyRecord,
    *,
    max_body_bytes_per_upload: int,
) -> int:
    """Upload whichever legs are present on a single body row.

    Returns the count of legs actually POSTed (0, 1, or 2). Raises the
    same exception set as :class:`CloudClient` — caller decides
    transient vs. terminal handling.
    """
    legs_sent = 0
    if record.request_body is not None:
        if len(record.request_body.encode("utf-8")) <= max_body_bytes_per_upload:
            envelope = _make_envelope(
                request_id=record.request_id,
                direction="request",
                body_text=record.request_body,
                content_type=record.request_content_type,
                original_size_bytes=record.request_body_bytes,
                redaction_applied=record.redaction_applied,
                redaction_summary=record.redaction_summary,
            )
            await client.upload_request_body(
                request_id=record.request_id, envelope=envelope
            )
            legs_sent += 1
        else:
            logger.info(
                "cloud.body_uploader.skip_oversize_request",
                extra={
                    "request_id": record.request_id,
                    "bytes": len(record.request_body.encode("utf-8")),
                    "cap": max_body_bytes_per_upload,
                },
            )

    if record.response_body is not None:
        if len(record.response_body.encode("utf-8")) <= max_body_bytes_per_upload:
            envelope = _make_envelope(
                request_id=record.request_id,
                direction="response",
                body_text=record.response_body,
                content_type=record.response_content_type,
                original_size_bytes=record.response_body_bytes,
                redaction_applied=record.redaction_applied,
                redaction_summary=record.redaction_summary,
            )
            await client.upload_request_body(
                request_id=record.request_id, envelope=envelope
            )
            legs_sent += 1
        else:
            logger.info(
                "cloud.body_uploader.skip_oversize_response",
                extra={
                    "request_id": record.request_id,
                    "bytes": len(record.response_body.encode("utf-8")),
                    "cap": max_body_bytes_per_upload,
                },
            )

    return legs_sent


async def run_forever(
    client: CloudClient,
    *,
    pending_reader: PendingReader,
    upload_marker: UploadMarker,
    pause_writer: PauseWriter,
    project_gate: ProjectGate,
    interval_seconds: float = 60.0,
    max_body_bytes_per_upload: int = 524_288,
    stop_event: asyncio.Event | None = None,
) -> None:
    """Run :func:`run_once` on a fixed interval until cancelled.

    A worker-tick exception is caught and logged. The daemon never sees
    a crash from this task. Cardinal: cloud failure MUST NEVER block the
    daemon proxy or kill the daemon process.
    """
    while True:
        if stop_event is not None and stop_event.is_set():
            return
        try:
            result = await run_once(
                client,
                pending_reader=pending_reader,
                upload_marker=upload_marker,
                pause_writer=pause_writer,
                project_gate=project_gate,
                max_body_bytes_per_upload=max_body_bytes_per_upload,
            )
            if result.paused:
                logger.warning("cloud.body_uploader.paused_unauthorised")
                return
        except Exception:
            logger.exception("cloud.body_uploader.tick_failed")

        try:
            await asyncio.sleep(interval_seconds)
        except asyncio.CancelledError:
            return


__all__ = [
    "BodyDrainResult",
    "BodyRecord",
    "PauseWriter",
    "PendingReader",
    "ProjectGate",
    "UploadMarker",
    "run_forever",
    "run_once",
]
