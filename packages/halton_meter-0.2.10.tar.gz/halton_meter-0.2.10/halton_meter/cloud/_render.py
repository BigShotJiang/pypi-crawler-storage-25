"""Rich renderers for the ``halton-meter cloud`` CLI surface.

Pre-0.2.2 every command in the cloud group printed Python dicts or raw JSON,
which read as debugging output rather than user-facing UX. The rest of the
daemon's CLI uses Rich Panels + Tables + status icons (see
``halton-meter status``); the cloud subgroup should match.

This module owns the rendering logic so ``cli_cloud.py`` stays focused on
the command bodies. Every public renderer takes a Console + payload and
prints; nothing returns formatted strings to keep call-site code uncluttered.
"""

from __future__ import annotations

from typing import Any

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

_ICON_OK = "●"        # green
_ICON_WARN = "◐"      # yellow
_ICON_BAD = "✗"       # red
_ICON_OFF = "○"       # dim


def _humanise_seconds(seconds: float) -> str:
    """Short human-friendly duration: '12s', '4m', '2h ago'."""
    if seconds < 60:
        return f"{int(seconds)}s ago"
    if seconds < 3600:
        return f"{int(seconds // 60)}m ago"
    if seconds < 86400:
        return f"{int(seconds // 3600)}h ago"
    return f"{int(seconds // 86400)}d ago"


def _relative_age(iso_ts: str | None) -> str:
    """Render '12s ago' from an ISO timestamp; '—' when None."""
    if not iso_ts:
        return "—"
    from datetime import UTC, datetime

    try:
        # Tolerate both 'Z' and '+00:00' tails.
        ts = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=UTC)
        delta = (datetime.now(tz=UTC) - ts).total_seconds()
        if delta < 0:
            return iso_ts  # future timestamp; fall back to raw
        return _humanise_seconds(delta)
    except Exception:
        return iso_ts


def render_status(console: Console, payload: dict[str, Any]) -> None:
    """Pretty-print ``cloud status`` as a banner + component-health table.

    Mirrors the style of ``halton-meter status``: a banner panel up top
    summarising the overall state, then a per-component breakdown.
    """
    is_active = bool(payload.get("is_active"))
    paused_reason = payload.get("paused_reason")
    consecutive_failures = int(payload.get("consecutive_failures") or 0)
    workspace_name = payload.get("workspace_name") or "(no workspace)"
    base_url = payload.get("base_url") or "(no endpoint)"

    # Banner — overall state.
    if not payload.get("base_url"):
        banner_title = "[bright_black]○  NOT CONFIGURED[/bright_black]"
        banner_body = (
            "Run `halton-meter cloud connect --base-url <URL>` to pair this "
            "daemon with a halton-meter-cloud instance."
        )
        banner_style = "bright_black"
    elif paused_reason == "paused_unauthorised":
        banner_title = "[red]✗  PAUSED — UNAUTHORISED[/red]"
        banner_body = (
            f"Cloud rejected the API key (HTTP 401). Try "
            f"[bold]halton-meter cloud resume[/bold] first — if the pause "
            f"was a transient cloud hiccup the daemon will re-probe and "
            f"recover without re-pairing. If resume reports the key is "
            f"genuinely invalid, run [bold]halton-meter cloud connect[/bold]. "
            f"Endpoint: {base_url}"
        )
        banner_style = "red"
    elif paused_reason == "paused_forbidden":
        banner_title = "[red]✗  PAUSED — FORBIDDEN[/red]"
        banner_body = (
            f"Cloud returned HTTP 403 — workspace membership is no longer "
            f"valid for this daemon. Contact your workspace owner to "
            f"re-invite this machine, then run "
            f"[bold]halton-meter cloud resume[/bold]. Endpoint: {base_url}"
        )
        banner_style = "red"
    elif paused_reason == "paused_manual":
        banner_title = "[yellow]◐  PAUSED (manual)[/yellow]"
        banner_body = (
            "Cloud sync is paused. Run `halton-meter cloud resume` to "
            "continue. Cursor preserved at the last successful batch."
        )
        banner_style = "yellow"
    elif paused_reason:
        banner_title = f"[yellow]◐  PAUSED ({paused_reason})[/yellow]"
        banner_body = (
            "Worker is not draining. Run `halton-meter cloud status` after "
            "investigation."
        )
        banner_style = "yellow"
    elif consecutive_failures >= 3:
        banner_title = (
            f"[yellow]◐  DEGRADED ({consecutive_failures} consecutive "
            f"failures)[/yellow]"
        )
        banner_body = (
            "Worker is retrying. Check `last_error` below; cloud may be "
            "transiently unreachable."
        )
        banner_style = "yellow"
    elif is_active:
        if payload.get("workspace_id"):
            banner_title = f"[green]●  ACTIVE — {workspace_name}[/green]"
        else:
            banner_title = "[green]●  ACTIVE[/green]"
        banner_body = f"Syncing to {base_url}"
        banner_style = "green"
    else:
        banner_title = "[yellow]◐  CONFIGURED BUT DISABLED[/yellow]"
        banner_body = (
            "`[cloud].enabled` is false. Run `halton-meter cloud resume` "
            "or flip the config."
        )
        banner_style = "yellow"

    console.print(
        Panel(
            Text.from_markup(banner_body),
            title=banner_title,
            border_style=banner_style,
            padding=(0, 1),
        )
    )

    # Per-component table.
    table = Table(
        show_header=True,
        header_style="bold",
        box=box.SIMPLE,
        pad_edge=False,
        title=None,
    )
    table.add_column("Field", style="bold")
    table.add_column("Status", justify="left", width=4)
    table.add_column("Value")

    def _row(field: str, state: str, value: str) -> None:
        # state is one of "ok", "warn", "bad", "off", "neutral".
        icon_map = {
            "ok": f"[green]{_ICON_OK}[/green]",
            "warn": f"[yellow]{_ICON_WARN}[/yellow]",
            "bad": f"[red]{_ICON_BAD}[/red]",
            "off": f"[bright_black]{_ICON_OFF}[/bright_black]",
            "neutral": " ",
        }
        table.add_row(field, icon_map.get(state, " "), value)

    _row(
        "Endpoint",
        "ok" if base_url and base_url != "(no endpoint)" else "off",
        base_url,
    )
    _row("Workspace", "ok" if payload.get("workspace_id") else "off", workspace_name)
    machine_id = payload.get("machine_id")
    _row(
        "Machine",
        "ok" if machine_id else "off",
        machine_id[:8] + "…" if machine_id else "—",
    )
    _row(
        "Enabled",
        "ok" if payload.get("enabled") else "off",
        "yes" if payload.get("enabled") else "no",
    )
    _row(
        "Continuous worker",
        "ok" if payload.get("continuous") else "off",
        f"every {int(payload.get('sync_interval_seconds') or 30)}s"
        if payload.get("continuous")
        else "off",
    )
    _row(
        "Paused reason",
        "ok" if not paused_reason else (
            "bad" if paused_reason == "paused_unauthorised" else "warn"
        ),
        paused_reason or "—",
    )
    _row(
        "Last sync",
        "ok" if payload.get("last_batch_succeeded_at") else "off",
        _relative_age(payload.get("last_batch_succeeded_at")),
    )
    _row(
        "Cursor",
        "ok" if payload.get("last_synced_request_recorded_at") else "off",
        _relative_age(payload.get("last_synced_request_recorded_at")),
    )
    _row(
        "Consecutive failures",
        "ok" if consecutive_failures == 0 else (
            "warn" if consecutive_failures < 3 else "bad"
        ),
        str(consecutive_failures),
    )
    last_error = payload.get("last_error")
    _row(
        "Last error",
        "ok" if not last_error else "warn",
        (last_error[:80] + "…") if last_error and len(last_error) > 80 else (last_error or "—"),
    )
    last_error_at = payload.get("last_error_at")
    if last_error or last_error_at:
        # v0.2.8 — only render the timestamp row when there is an error
        # to anchor it to. Avoids two "—" rows on a clean status.
        _row(
            "Last error at",
            "warn" if last_error_at else "neutral",
            _relative_age(last_error_at) if last_error_at else "—",
        )

    unsynced = int(payload.get("unsynced_record_count") or 0)
    _row(
        "Unsynced records",
        "ok" if unsynced == 0 else ("warn" if unsynced < 1000 else "bad"),
        f"{unsynced:,}",
    )

    console.print(table)


def render_whoami(console: Console, payload: dict[str, Any]) -> None:
    """Render ``cloud whoami`` as a labeled key-value panel."""
    table = Table(show_header=False, box=None, pad_edge=False)
    table.add_column("k", style="bold", no_wrap=True)
    table.add_column("v")

    for key, label in (
        ("workspace_name", "Workspace"),
        ("workspace_id", "Workspace ID"),
        ("machine_id", "Machine ID"),
        ("hostname", "Hostname"),
        ("daemon_version", "Daemon version"),
        ("connected_at", "Connected at"),
    ):
        value = payload.get(key)
        if value is None:
            continue
        table.add_row(label, str(value))

    # Append anything the cloud sent that we didn't pre-label, so future
    # field additions surface without a daemon rebuild.
    handled = {
        "workspace_name", "workspace_id", "machine_id", "hostname",
        "daemon_version", "connected_at",
    }
    for key, value in payload.items():
        if key in handled or value is None:
            continue
        table.add_row(key, str(value))

    console.print(
        Panel(table, title="[bold]Cloud identity[/bold]", border_style="cyan")
    )


def render_reconcile(
    console: Console,
    payload: dict[str, Any],
    *,
    daemon_total_millicents: int | None = None,
) -> None:
    """Render ``cloud reconcile`` as a per-row table + total + variance.

    ``daemon_total_millicents`` is the daemon-side sum the caller computed
    from local SQLite. When supplied, the renderer prints a variance line
    underneath the totals; otherwise just the cloud-side numbers.
    """
    rows = payload.get("rows") or []
    if not rows:
        console.print(
            Panel(
                "No reconcilable rows found in the date window.",
                title="[bold]Reconcile[/bold]",
                border_style="yellow",
            )
        )
        return

    table = Table(
        show_header=True,
        header_style="bold",
        box=box.SIMPLE,
        title="[bold]Cloud-side daily totals[/bold]",
        title_justify="left",
        pad_edge=False,
    )
    table.add_column("Project", style="cyan", no_wrap=True)
    table.add_column("Date", no_wrap=True)
    table.add_column("Requests", justify="right")
    table.add_column("Prompt tok", justify="right")
    table.add_column("Output tok", justify="right")
    table.add_column("Cost (USD)", justify="right")

    cloud_total = 0
    total_requests = 0
    for row in rows:
        cost_millicents = int(row.get("cost_usd_minor_units") or 0)
        cloud_total += cost_millicents
        total_requests += int(row.get("request_count") or 0)
        table.add_row(
            str(row.get("project", "—")),
            str(row.get("date", "—")),
            f"{int(row.get('request_count') or 0):,}",
            f"{int(row.get('prompt_tokens') or 0):,}",
            f"{int(row.get('completion_tokens') or 0):,}",
            f"${cost_millicents / 100_000:.4f}",
        )

    console.print(table)

    # Totals box.
    summary = Table(show_header=False, box=None, pad_edge=False)
    summary.add_column("k", style="bold", no_wrap=True)
    summary.add_column("v", justify="right")
    summary.add_row("Rows", f"{len(rows):,}")
    summary.add_row("Requests", f"{total_requests:,}")
    summary.add_row("Cloud total", f"${cloud_total / 100_000:.4f}")

    if daemon_total_millicents is not None:
        summary.add_row("Daemon total", f"${daemon_total_millicents / 100_000:.4f}")
        variance = cloud_total - daemon_total_millicents
        if daemon_total_millicents > 0:
            pct = variance / daemon_total_millicents * 100
        else:
            pct = 0.0
        if variance == 0:
            variance_text = "[green]$0.00 (0.00%) ✓[/green]"
        elif abs(pct) < 0.5:
            variance_text = (
                f"[yellow]${variance / 100_000:+.4f} ({pct:+.4f}%) — within tolerance[/yellow]"
            )
        else:
            variance_text = (
                f"[red]${variance / 100_000:+.4f} ({pct:+.4f}%) — investigate[/red]"
            )
        summary.add_row("Variance", variance_text)

    console.print(
        Panel(summary, title="[bold]Summary[/bold]", border_style="green")
    )

    cursor_high_water = payload.get("cursor_high_water")
    if cursor_high_water:
        console.print(
            f"[bright_black]cursor high water: {cursor_high_water}[/bright_black]"
        )


def render_pairing_code(console: Console, *, code: str, pairing_url: str) -> None:
    """Render the pairing-code prompt as a panel."""
    body = Text()
    body.append("Pairing code:  ", style="dim")
    body.append(code, style="bold cyan")
    body.append("\n\nOpen this URL in a browser already signed in to the dashboard:\n")
    body.append(pairing_url, style="underline")
    console.print(
        Panel(body, title="[bold]Halton Meter — cloud pairing[/bold]", border_style="cyan")
    )


def render_paired(
    console: Console, *, workspace_name: str, machine_id: str
) -> None:
    """Render the successful-pair message."""
    body = Text()
    body.append("✓ Paired", style="bold green")
    body.append("  with workspace ")
    body.append(workspace_name, style="bold")
    body.append("\nMachine ID: ")
    body.append(machine_id, style="cyan")
    body.append("\n\nRun ", style="dim")
    body.append("halton-meter cloud status", style="bold")
    body.append(" to verify, or wait — the daemon will start draining within 30s.", style="dim")
    console.print(Panel(body, border_style="green"))


__all__ = [
    "render_paired",
    "render_pairing_code",
    "render_reconcile",
    "render_status",
    "render_whoami",
]
