"""Cloud-side constants for the halton-meter daemon (v0.2.5).

This module is the single source of truth for the production cloud URL.
The constant is consumed by ``cloud/config_glue.py`` (default base_url)
and ``cli_cloud.py`` (the ``cloud connect`` command default).

Override via the ``HALTON_METER_CLOUD_URL`` environment variable for
dev/staging work:

    HALTON_METER_CLOUD_URL=https://staging.api.haltonmeter.com halton-meter cloud connect

The ``--base-url`` CLI flag on ``halton-meter cloud connect`` also
accepts an explicit override and takes precedence over the env var.

Decision: ``memory/decisions.md`` 2026-05-21 — "v0.2.5 lock daemon to
official backend host".
"""

from __future__ import annotations

import os

# Production URL for the halton-meter cloud API.
# This is the authoritative default — shipped in the daemon so end-users
# never need to configure [cloud].base_url manually.
HALTON_METER_CLOUD_URL: str = "https://api.haltonmeter.com"

# Dev/staging override: HALTON_METER_CLOUD_URL env var wins when set.
# This is intentional — running `HALTON_METER_CLOUD_URL=http://localhost:3000`
# in a local dev shell is the supported workflow for daemon↔cloud integration
# testing without modifying config.toml.
_env_override = os.environ.get("HALTON_METER_CLOUD_URL", "").strip()
if _env_override:
    HALTON_METER_CLOUD_URL = _env_override


def get_default_cloud_url() -> str:
    """Return the effective default cloud URL.

    Resolution order:
    1. ``HALTON_METER_CLOUD_URL`` environment variable (dev/staging override).
    2. The hardcoded production constant ``"https://api.haltonmeter.com"``.

    Called at config-load time and by ``cli_cloud.connect`` when no
    ``--base-url`` flag is supplied.
    """
    # Module-level constant already applied the env override; just return it.
    return HALTON_METER_CLOUD_URL
