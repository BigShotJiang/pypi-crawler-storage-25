"""Cloud sync worker loop — scaffolding only.

Wave 1A.iii ships :func:`run_once` and :func:`run_forever` as importable
entry points. Wave 2 wires :func:`run_forever` into the daemon's
``daemon`` subcommand alongside the proxy / health / watchdog tasks; this
PR deliberately stops short of that step.

The worker design (per ``phase2-daemon-changes.md`` § 2b):

1. Read the cursor (``cloud_sync_state``) — ``(recorded_at, id)`` tuple.
2. Select the next batch from ``requests`` strictly after that cursor.
3. Serialise via :mod:`halton_meter.cloud.serialize`.
4. POST via :func:`CloudClient.batch_ingest`.
5. **On full-success ACK only**, advance the cursor in a single
   transaction with the batch attempt bookkeeping.
6. On :class:`~halton_meter.cloud.errors.CloudUnauthorised`, persist
   ``paused_reason='paused_unauthorised'`` and stop. Do NOT advance the
   cursor.

This file does **not** know about SQLite directly. It accepts injected
``cursor_reader``, ``batch_loader``, and ``cursor_advancer`` callables
so Wave 1A.i (storage layer) and Wave 1A.iii (this) can land in parallel
without colliding. The storage wave plugs real implementations into the
callables in Wave 2.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.errors import (
    CloudForbidden,
    CloudRateLimited,
    CloudSchemaMismatch,
    CloudTransport,
    CloudUnauthorised,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------- #
# Injection seams — Wave 1A.i provides the real implementations.
# ---------------------------------------------------------------------- #


@dataclass(frozen=True)
class Cursor:
    """Sync cursor — strictly-greater-than key for the next batch.

    ``(recorded_at, id)`` is the canonical ordering. ``recorded_at`` is
    monotonic in the daemon process (write time, not request time) so
    long-running streaming responses can't be left permanently behind
    the cursor. See ``phase2-cloud-sync.md`` § 3c for the rationale.

    A pristine cursor (no rows synced yet) is signalled by
    ``recorded_at=""`` and ``record_id=""`` — the "earliest possible"
    sentinel. SQL callers should treat both fields as "treat any row as
    newer than this".
    """

    recorded_at: str
    record_id: str

    @classmethod
    def pristine(cls) -> Cursor:
        """Sentinel cursor; every persisted row sorts after this."""
        return cls(recorded_at="", record_id="")


CursorReader = Callable[[], Awaitable[Cursor]]
BatchLoader = Callable[[Cursor, int], Awaitable[list[dict[str, Any]]]]
CursorAdvancer = Callable[[Cursor], Awaitable[None]]
PauseWriter = Callable[[str], Awaitable[None]]
# v0.2.8 — error_writer is the transient-failure twin of pause_writer.
# Called for 5xx / connection reset / timeout / DNS failure / 422 / 429
# — anything that should NOT pause the worker but SHOULD bump
# ``consecutive_failures`` and stamp ``last_error`` so the operator can
# see why sync is sluggish via ``halton-meter cloud status``.
ErrorWriter = Callable[[str], Awaitable[None]]


# ---------------------------------------------------------------------- #
# Public API
# ---------------------------------------------------------------------- #


@dataclass(frozen=True)
class DrainResult:
    """Outcome of a :func:`run_once` invocation.

    Attributes:
        batches_sent: Number of POSTs whose ACK was fully successful.
        records_sent: Sum of records across those successful batches.
        paused: True iff the worker hit a terminal pause signal (401).
        caught_up: True iff the cursor reached the end of the table
            (the last batch came back smaller than ``batch_size``).
    """

    batches_sent: int
    records_sent: int
    paused: bool
    caught_up: bool


async def run_once(
    client: CloudClient,
    *,
    cursor_reader: CursorReader,
    batch_loader: BatchLoader,
    cursor_advancer: CursorAdvancer,
    pause_writer: PauseWriter,
    error_writer: ErrorWriter | None = None,
    batch_size: int = 500,
    max_batches: int = 10,
) -> DrainResult:
    """Drain the cursor until caught up or a terminal error fires.

    Used by ``halton-meter cloud sync`` (single drain pass, then exit)
    and by :func:`run_forever` (one drain per tick).

    Args:
        client: A live :class:`CloudClient`, already inside its async
            context manager.
        cursor_reader: ``async () -> Cursor``. The current sync cursor.
        batch_loader: ``async (cursor, limit) -> list[dict]``. Returns
            wire-serialised records strictly after the cursor, ordered
            ascending. Must return ``[]`` when caught up.
        cursor_advancer: ``async (Cursor) -> None``. Persists the new
            cursor + bookkeeping in a single SQL transaction. Called
            only after a fully-successful batch ACK.
        pause_writer: ``async (reason) -> None``. Writes
            ``cloud_sync_state.paused_reason``. Called once on 401.
        batch_size: Records per POST. Soft cap — the cloud also enforces
            a hard cap on its side.
        max_batches: Safety stop. A normal box never reaches this; it's
            here so a buggy ``batch_loader`` can't pin an event loop.

    Returns:
        :class:`DrainResult` summarising what happened.
    """
    batches = 0
    records = 0
    cursor = await cursor_reader()

    for _ in range(max_batches):
        wire_records = await batch_loader(cursor, batch_size)
        if not wire_records:
            return DrainResult(
                batches_sent=batches,
                records_sent=records,
                paused=False,
                caught_up=True,
            )

        batch_id = str(uuid.uuid4())
        try:
            await client.batch_ingest(batch_id=batch_id, records=wire_records)
        except CloudUnauthorised as exc:
            # Terminal. Persist pause; cursor stays put. Caller surfaces
            # paused_unauthorised in `halton-meter cloud status`.
            # v0.2.8: only a real HTTP 401 reaches here — CloudClient
            # raises CloudTransport for connection resets / 5xx /
            # timeouts, so the daemon will no longer pause-as-401 on
            # mid-deploy ALB hiccups.
            logger.warning(
                "sync.paused reason=paused_unauthorised "
                "http_status=401 last_request_id=%s detail=%r",
                batch_id,
                str(exc),
            )
            await pause_writer("paused_unauthorised")
            return DrainResult(
                batches_sent=batches,
                records_sent=records,
                paused=True,
                caught_up=False,
            )
        except CloudForbidden as exc:
            # Terminal. Membership invalidated (user removed, workspace
            # deleted, etc). Re-pair won't help — surface a distinct
            # pause reason so the operator goes to the right place.
            logger.warning(
                "sync.paused reason=paused_forbidden "
                "http_status=403 last_request_id=%s detail=%r",
                batch_id,
                str(exc),
            )
            await pause_writer("paused_forbidden")
            return DrainResult(
                batches_sent=batches,
                records_sent=records,
                paused=True,
                caught_up=False,
            )
        except CloudRateLimited as exc:
            # 429 — transient. CloudClient already retried up to
            # MAX_RETRIES; if it bubbled this far the cloud is sustained
            # rate-limiting us. Do NOT pause; stamp last_error and let
            # the next tick try again.
            logger.warning(
                "sync.transient reason=rate_limited "
                "http_status=429 last_request_id=%s",
                batch_id,
            )
            if error_writer is not None:
                await error_writer(f"rate_limited: {exc!s}"[:512])
            return DrainResult(
                batches_sent=batches,
                records_sent=records,
                paused=False,
                caught_up=False,
            )
        except CloudTransport as exc:
            # 5xx, connection reset, ReadTimeout, ConnectTimeout, DNS
            # failure. The cloud is allowed to be transiently unreachable;
            # do NOT pause. Stamp last_error so the operator can see what
            # happened, increment consecutive_failures, retry next tick.
            logger.warning(
                "sync.transient reason=transport "
                "http_status=%s last_request_id=%s detail=%r",
                getattr(exc, "status_code", None),
                batch_id,
                str(exc),
            )
            if error_writer is not None:
                await error_writer(f"transport: {exc!s}"[:512])
            return DrainResult(
                batches_sent=batches,
                records_sent=records,
                paused=False,
                caught_up=False,
            )
        except CloudSchemaMismatch as exc:
            # 422 / 400 / other 4xx. The payload is malformed in a way the
            # cloud refuses. Do NOT pause — that would block sync for the
            # other 99% of valid records sitting behind this batch.
            # Log loudly so the bug surfaces in support channels. The
            # cursor stays put for now; v0.3 will introduce a quarantine
            # table so a poison-pill record can be skipped past.
            logger.error(
                "sync.payload_rejected http_status=%s "
                "last_request_id=%s batch_records=%d detail=%r — "
                "cursor blocked until daemon-side fix lands.",
                getattr(exc, "status_code", None),
                batch_id,
                len(wire_records),
                str(exc),
            )
            if error_writer is not None:
                await error_writer(
                    f"schema_mismatch ({getattr(exc, 'status_code', '?')}): "
                    f"{exc!s}"[:512]
                )
            return DrainResult(
                batches_sent=batches,
                records_sent=records,
                paused=False,
                caught_up=False,
            )

        # Cursor advances ONLY on a full success. Pull the new cursor
        # from the last record's wire payload — it's already in
        # ``(recorded_at, id)`` form courtesy of the serializer.
        last = wire_records[-1]
        cursor = Cursor(
            recorded_at=str(last["recorded_at"]),
            record_id=str(last["id"]),
        )
        await cursor_advancer(cursor)

        batches += 1
        records += len(wire_records)

        # If we drained less than a full batch, we're caught up — no
        # point asking the loader for an empty page.
        if len(wire_records) < batch_size:
            return DrainResult(
                batches_sent=batches,
                records_sent=records,
                paused=False,
                caught_up=True,
            )

    # Hit max_batches without catching up. Not paused; just yielded the
    # event loop to other tasks. The forever-loop will pick up on the
    # next tick.
    return DrainResult(
        batches_sent=batches,
        records_sent=records,
        paused=False,
        caught_up=False,
    )


async def run_forever(
    client: CloudClient,
    *,
    cursor_reader: CursorReader,
    batch_loader: BatchLoader,
    cursor_advancer: CursorAdvancer,
    pause_writer: PauseWriter,
    error_writer: ErrorWriter | None = None,
    interval_seconds: float = 30.0,
    batch_size: int = 500,
    max_batches_per_tick: int = 10,
    stop_event: asyncio.Event | None = None,
) -> None:
    """Run :func:`run_once` on a fixed interval until cancelled.

    Wave 2 will spawn this from the daemon's ``daemon`` subcommand. This
    PR ships it as scaffolding so the wiring change in Wave 2 is a
    one-line edit (and so integration tests in 1A.iii can exercise the
    loop in isolation against a ``MockTransport``).

    Args:
        stop_event: Optional asyncio.Event. If set, the loop exits at
            the next tick boundary. Lets the daemon's graceful-shutdown
            machinery stop the loop deterministically.
    """
    while True:
        if stop_event is not None and stop_event.is_set():
            return
        try:
            result = await run_once(
                client,
                cursor_reader=cursor_reader,
                batch_loader=batch_loader,
                cursor_advancer=cursor_advancer,
                pause_writer=pause_writer,
                error_writer=error_writer,
                batch_size=batch_size,
                max_batches=max_batches_per_tick,
            )
            if result.paused:
                # Terminal — recovery requires re-running ``cloud
                # connect``. No point spinning the loop.
                logger.warning("cloud.worker.sync_paused")
                return
        except Exception:
            # A cloud-task crash must NEVER kill the daemon. Plan doc
            # § 7. Log and sleep before the next attempt.
            logger.exception("cloud.worker.tick_failed")

        try:
            await asyncio.sleep(interval_seconds)
        except asyncio.CancelledError:
            return


__all__ = [
    "BatchLoader",
    "Cursor",
    "CursorAdvancer",
    "CursorReader",
    "DrainResult",
    "ErrorWriter",
    "PauseWriter",
    "run_forever",
    "run_once",
]
