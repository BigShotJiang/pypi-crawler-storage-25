"""Upload-privacy policy resolution.

Privacy by default for the Phase 2 cloud-sync surface. The daemon, not the
cloud, decides what leaves the machine — the cloud cannot redact what it
never receives. This module owns the policy data model + resolver; the
config layer parses it out of ``[cloud.upload]`` and the serializer applies
the resolved policy to each wire record.

Three layers of intent, resolved left-to-right:

1. **Preset.** ``minimal`` / ``standard`` / ``full``. A coarse-grained baseline
   that gets the user 80% of the way to a sensible posture. Default is
   ``standard``.
2. **Global field overrides.** Each gateable field can be force-on or
   force-off independent of the preset. Useful for the "I trust standard but
   want hostname off" case.
3. **Per-project rules.** Some projects are local-only (``upload=false`` drops
   every record). Others have project-specific field overrides on top of the
   preset + global overrides.

Always-keep fields are operational metadata with no meaningful privacy weight
(``provider``, ``model``, token counts, timing, cost, ids, status). They are
not gateable and always travel with an upload.

The policy is **fail-closed** in the sense that the safest default for any
unknown field is "drop" — but the field list is closed (we ship for v0.2.0's
``LogRecordIn`` shape) so this only matters for forward-compat. New wire
fields added in a later wave must register their default disposition here
before they can flow upward.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class UploadPreset(StrEnum):
    """Coarse-grained privacy baselines.

    ``minimal``  — operational only. No project slug, no workdir, no hostname,
                   no prompt hash. The cloud sees provider/model/tokens/cost.
                   Sufficient for "show me my spend" reporting; insufficient
                   for project-level attribution in the cloud.
    ``standard`` — minimal + project slug + prompt_hash + hostname. Workdir
                   stays off because it leaks employer/client paths. **This
                   is the v0.2.0 default.**
    ``full``     — everything in the contract field list. The Phase 0 / pre-
                   privacy default. Use this only if you've made an active
                   decision that the workdir field is acceptable.
    """

    minimal = "minimal"
    standard = "standard"
    full = "full"


# The complete set of gateable wire fields. Every key here must be a real
# ``LogRecordIn`` field name (see ``cloud/serialize.py`` and the wire contract
# §3). Anything not listed is always-keep.
GATEABLE_FIELDS: tuple[str, ...] = (
    "project",
    "source_workdir",
    "source_machine",
    "prompt_hash",
    "attribution_method",
    "idempotency_key",
)


# Default field dispositions per preset. ``True`` = send. ``False`` = drop.
# This table is the source of truth — every other layer ultimately resolves to
# one of these booleans per field.
PRESET_DEFAULTS: dict[UploadPreset, dict[str, bool]] = {
    UploadPreset.minimal: {
        "project": False,
        "source_workdir": False,
        "source_machine": False,
        "prompt_hash": False,
        "attribution_method": False,
        "idempotency_key": True,  # provider-issued, no PII
    },
    UploadPreset.standard: {
        "project": True,
        "source_workdir": False,  # the high-leak field — off in v0.2.0 default
        "source_machine": True,
        "prompt_hash": True,
        "attribution_method": True,
        "idempotency_key": True,
    },
    UploadPreset.full: {
        "project": True,
        "source_workdir": True,
        "source_machine": True,
        "prompt_hash": True,
        "attribution_method": True,
        "idempotency_key": True,
    },
}


@dataclass(frozen=True)
class ProjectRule:
    """Per-project privacy override.

    ``upload=False`` drops every record for the project before serialization
    — no opportunity for partial leakage. ``upload=True`` keeps records but
    allows ``fields`` to lock down specific columns on top of the global
    policy.
    """

    upload: bool = True
    fields: dict[str, bool] = field(default_factory=dict)


@dataclass(frozen=True)
class UploadPolicy:
    """The resolved-at-config-load privacy policy for one daemon.

    Construction order matches the resolution order: preset comes first,
    global field overrides apply on top, and per-project rules apply per
    record at upload time (see :func:`resolve_for_project`).
    """

    preset: UploadPreset = UploadPreset.standard
    field_overrides: dict[str, bool] = field(default_factory=dict)
    per_project: dict[str, ProjectRule] = field(default_factory=dict)

    @classmethod
    def default(cls) -> UploadPolicy:
        """The v0.2.0 default policy. Standard preset, no overrides."""
        return cls()


@dataclass(frozen=True)
class ResolvedFieldPolicy:
    """A per-record decision: should this record upload, and which fields?

    ``upload=False`` means the record is dropped entirely — the supervisor
    skips serialization and never sends the row. ``fields`` is a complete
    map ``{gateable_field_name: should_send}`` so the serializer can apply
    it without re-resolving precedence at the hot-path layer.
    """

    upload: bool
    fields: dict[str, bool]


def resolve_for_project(policy: UploadPolicy, project: str | None) -> ResolvedFieldPolicy:
    """Combine preset + global overrides + per-project rules for one record.

    The lookup is total: every gateable field gets a boolean in the result.
    Unknown fields (not in :data:`GATEABLE_FIELDS`) are not in the result;
    the serializer's contract is "absent key = no override = pass through".
    """
    # Start from the preset defaults so every gateable field has a baseline.
    resolved: dict[str, bool] = dict(PRESET_DEFAULTS[policy.preset])

    # Global overrides: keys outside GATEABLE_FIELDS are silently ignored —
    # the config-loader is responsible for filtering, but a stray key here
    # would just become a no-op rather than a crash.
    for field_name, send in policy.field_overrides.items():
        if field_name in GATEABLE_FIELDS:
            resolved[field_name] = send

    # Per-project rules. ``None`` project (attribution miss) gets the global
    # policy — no project-specific override applies.
    if project is not None:
        rule = policy.per_project.get(project)
        if rule is not None:
            if not rule.upload:
                return ResolvedFieldPolicy(upload=False, fields=resolved)
            for field_name, send in rule.fields.items():
                if field_name in GATEABLE_FIELDS:
                    resolved[field_name] = send

    return ResolvedFieldPolicy(upload=True, fields=resolved)


def apply_to_wire(wire: dict[str, Any], resolved: ResolvedFieldPolicy) -> dict[str, Any]:
    """Redact a serialized wire dict according to a resolved policy.

    Pure transform — does not mutate the input. Fields the policy says drop
    are replaced with ``None`` rather than removed from the dict, because the
    wire contract specifies shape stability (cloud's ``extra="ignore"`` makes
    ``None`` safe; explicit nulls are easier to grep in logs than missing
    keys).

    Caller is responsible for the upload-skip path (``resolved.upload=False``)
    — this function never sees those records.
    """
    if not resolved.upload:
        # Defensive: a caller that passes upload=False is misusing the API,
        # but redacting everything except the operational scaffold is the
        # least-surprising behaviour.
        redacted = dict(wire)
        for f in GATEABLE_FIELDS:
            if f in redacted:
                redacted[f] = None
        return redacted

    redacted = dict(wire)
    for field_name, send in resolved.fields.items():
        if not send and field_name in redacted:
            redacted[field_name] = None
    return redacted


def describe(policy: UploadPolicy) -> str:
    """Render a one-screen human summary of the policy. Used by ``cloud privacy show``."""
    lines = [f"preset = {policy.preset.value}"]
    if policy.field_overrides:
        lines.append("global field overrides:")
        for name in sorted(policy.field_overrides):
            lines.append(f"  {name} = {policy.field_overrides[name]}")
    else:
        lines.append("global field overrides: (none)")

    if policy.per_project:
        lines.append("per-project rules:")
        for name in sorted(policy.per_project):
            rule = policy.per_project[name]
            if not rule.upload:
                lines.append(f"  {name}: upload=false  (entire project skipped)")
            elif rule.fields:
                overrides = ", ".join(
                    f"{k}={v}" for k, v in sorted(rule.fields.items())
                )
                lines.append(f"  {name}: {overrides}")
            else:
                lines.append(f"  {name}: (no overrides)")
    else:
        lines.append("per-project rules: (none)")

    return "\n".join(lines)


__all__ = [
    "GATEABLE_FIELDS",
    "PRESET_DEFAULTS",
    "ProjectRule",
    "ResolvedFieldPolicy",
    "UploadPolicy",
    "UploadPreset",
    "apply_to_wire",
    "describe",
    "resolve_for_project",
]
