"""Layer 2 of the three-layer connectivity-on-crash fix: separate watchdog process.

See ``memory/decisions.md`` 2026-04-29 — "Three-layer connectivity-on-crash fix"
and "Layer 2 watchdog: Option-1 daemon-side proxy enable on startup".

What it does
------------

A second OS-supervised process (``halton-meter watchdog``) polls the
daemon's ``/health`` endpoint every 1.5s. After 5 consecutive failures
(~7.5s of unresponsiveness — covering the freeze-but-don't-die case
that layer 1 cannot catch alone), the watchdog runs ``networksetup
-setsecurewebproxystate <iface> off`` so the user's outbound HTTPS
traffic flows direct to providers (untracked, but flowing). When the
daemon comes back, the **daemon's own startup** (post-Option-1 patch)
re-enables the system proxy from the ``proxy-managed`` sentinel — the
watchdog never re-enables. One direction of state transition only.

Design constraints (do not violate without an ADR)
--------------------------------------------------

* Stdlib only — no new dependencies.
* Watchdog never raises out of the polling loop.
* Watchdog never re-enables the system proxy.
* The interface snapshot is taken once at startup and not refreshed.
* Hysteresis: 5 fails → disable; 3 successes → exit RECOVERING. Recovery
  never triggers re-enable; it only resolves the watchdog's internal
  state so a subsequent freeze gets a fresh failure budget.
* All state transitions logged via structlog with structured fields;
  individual polls are NOT logged.
"""

from __future__ import annotations

import enum
import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections import deque
from dataclasses import dataclass
from typing import Any

import structlog

from halton_meter import system_proxy
from halton_meter.port_alloc import (
    API_PORT_DEFAULT,
    EDGE_PORT_DEFAULT,
    load_effective_config,
)

# --------------------------------------------------------------------------- #
# Constants                                                                    #
# --------------------------------------------------------------------------- #

_HEALTH_PATH = "/health"
_POLL_INTERVAL_SECONDS = 1.5
_FAILURE_THRESHOLD = 5
_RECOVERY_THRESHOLD = 3
_HEALTH_TIMEOUT_SECONDS = 1.0

# v0.1.16 P0.2: MITM port liveness probe.
# The daemon's `/health` endpoint can keep responding while the mitmproxy
# acceptor task has died (caught in the wild 2026-05-02 — `lsof` showed
# nothing on :8090 while status said healthy). Probe the MITM port
# directly via TCP connect; do NOT speak HTTP or TLS — mitmproxy on the
# internal port speaks HTTP-CONNECT-style proxy, not raw HTTP, so any
# protocol traffic from a probe would either get logged as malformed or
# trigger a TLS handshake we don't want.
MITM_PROBE_TIMEOUT_S = 0.5
MITM_FAIL_THRESHOLD_WARN = 3
MITM_FAIL_THRESHOLD_RESTART = 5
MITM_RESTART_CAP_PER_HOUR = 3
_MITM_RESTART_WINDOW_S = 3600
_LAUNCHD_LABEL = "com.haltonlabs.meter"

# v0.1.19.dev1 (Phase 2 Bug B): /health-failure-driven kickstart.
# The user reported a wedged-but-alive daemon after a real reboot:
# the daemon process was running, system proxy was disabled by the
# watchdog (correct, per cardinal rule), but /health stayed dead so
# nothing recovered. The MITM-port restart path didn't trigger
# because that gate is `success=True AND mitm dead`. This second
# branch handles the inverse case: /health is dead for N ticks AND
# the daemon process is alive (so we are not stomping a clean exit
# / SIGKILL recovery already in flight).
HEALTH_FAIL_THRESHOLD_RESTART = 8  # ~12s at 1.5s ticks
HEALTH_RESTART_CAP_PER_HOUR = 3


log = structlog.get_logger("halton_meter.watchdog")


# --------------------------------------------------------------------------- #
# State machine (pure logic, no I/O)                                           #
# --------------------------------------------------------------------------- #


class WatchdogState(enum.Enum):
    HEALTHY = "healthy"
    DEGRADING = "degrading"
    PROXY_DISABLED = "proxy_disabled"
    RECOVERING = "recovering"


@dataclass(frozen=True)
class StateTransition:
    """The result of feeding one health-check observation into the machine.

    ``should_disable_proxy_now`` fires exactly once on the
    DEGRADING -> PROXY_DISABLED edge. Everything else is informational.
    """

    from_: WatchdogState
    to: WatchdogState
    fail_count: int
    success_count: int
    should_disable_proxy_now: bool


class WatchdogStateMachine:
    """Pure-logic four-state hysteresis machine.

    HEALTHY -> DEGRADING on first fail.
    DEGRADING -> HEALTHY on first success (resets fail_count).
    DEGRADING -> PROXY_DISABLED on fail_count == _FAILURE_THRESHOLD
        (signals disable on this transition only).
    PROXY_DISABLED -> RECOVERING on first success.
    RECOVERING -> PROXY_DISABLED on first fail (resets success_count).
    RECOVERING -> HEALTHY on success_count == _RECOVERY_THRESHOLD.

    No I/O. The caller is responsible for actually disabling the proxy
    when ``should_disable_proxy_now`` is True.
    """

    def __init__(
        self,
        *,
        failure_threshold: int = _FAILURE_THRESHOLD,
        recovery_threshold: int = _RECOVERY_THRESHOLD,
    ) -> None:
        self._failure_threshold = failure_threshold
        self._recovery_threshold = recovery_threshold
        self._state = WatchdogState.HEALTHY
        self._fail_count = 0
        self._success_count = 0

    @property
    def state(self) -> WatchdogState:
        return self._state

    @property
    def fail_count(self) -> int:
        return self._fail_count

    @property
    def success_count(self) -> int:
        return self._success_count

    def record_health(self, success: bool) -> StateTransition:
        prev = self._state
        should_disable = False

        if self._state is WatchdogState.HEALTHY:
            if success:
                # Stay HEALTHY. Counters already zero.
                self._fail_count = 0
                self._success_count = 0
            else:
                self._fail_count = 1
                self._success_count = 0
                self._state = WatchdogState.DEGRADING

        elif self._state is WatchdogState.DEGRADING:
            if success:
                self._fail_count = 0
                self._success_count = 0
                self._state = WatchdogState.HEALTHY
            else:
                self._fail_count += 1
                if self._fail_count >= self._failure_threshold:
                    self._state = WatchdogState.PROXY_DISABLED
                    should_disable = True
                    # Reset success counter so RECOVERING starts fresh.
                    self._success_count = 0

        elif self._state is WatchdogState.PROXY_DISABLED:
            if success:
                self._success_count = 1
                self._state = WatchdogState.RECOVERING
            else:
                # Stay disabled. fail_count irrelevant here.
                self._success_count = 0

        elif self._state is WatchdogState.RECOVERING:
            if success:
                self._success_count += 1
                if self._success_count >= self._recovery_threshold:
                    self._state = WatchdogState.HEALTHY
                    self._fail_count = 0
                    self._success_count = 0
            else:
                self._success_count = 0
                self._state = WatchdogState.PROXY_DISABLED

        return StateTransition(
            from_=prev,
            to=self._state,
            fail_count=self._fail_count,
            success_count=self._success_count,
            should_disable_proxy_now=should_disable,
        )


# --------------------------------------------------------------------------- #
# Side-effecting helpers                                                       #
# --------------------------------------------------------------------------- #


def disable_system_proxy(interfaces: list[str]) -> None:
    """Best-effort ``networksetup -setsecurewebproxystate <iface> off`` loop.

    Mirrors :func:`system_proxy._disable_macos_proxy` but is the
    one-direction watchdog action — no atexit, no signal chaining.
    Each (interface, variant) failure is swallowed so one bad
    interface never stops the rest.
    """
    for iface in interfaces:
        for flag in ("-setsecurewebproxystate", "-setwebproxystate"):
            try:
                subprocess.run(
                    ["networksetup", flag, iface, "off"],
                    capture_output=True,
                    timeout=5,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError):
                # Best-effort; the next iteration may still succeed.
                pass


def poll_health(api_port: int, timeout: float = _HEALTH_TIMEOUT_SECONDS) -> bool:
    """Return True iff GET http://127.0.0.1:<api_port>/health returns 200 + ok body.

    Anything else (connection refused, timeout, 4xx, 5xx, malformed
    JSON, generic exception) returns False. The watchdog itself must
    never raise from this function — broad ``Exception`` catch at the
    boundary.
    """
    url = f"http://127.0.0.1:{api_port}{_HEALTH_PATH}"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if getattr(resp, "status", None) != 200:
                return False
            body = resp.read()
            try:
                payload = json.loads(body.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return False
            return isinstance(payload, dict) and payload.get("status") == "ok"
    except (urllib.error.URLError, TimeoutError, OSError):
        return False
    except Exception:
        return False


def _probe_mitm_port(host: str, port: int) -> bool:
    """Return True iff a TCP connect to ``(host, port)`` succeeds inside
    :data:`MITM_PROBE_TIMEOUT_S`.

    Pure TCP connect; no payload sent, no TLS handshake, socket closed
    immediately. mitmproxy's internal listener answers SYN as soon as
    the acceptor task is alive, so a successful connect proves the
    listener is up. A refused/timeout/OSError proves the acceptor is
    NOT accepting — which is the silent-death symptom this exists to
    detect. Never raises — broad exception catch at the boundary.
    """
    try:
        with socket.create_connection((host, port), timeout=MITM_PROBE_TIMEOUT_S):
            return True
    except (OSError, TimeoutError):
        # ConnectionRefusedError + socket.timeout are subclasses of
        # OSError / TimeoutError respectively; explicit catches above
        # are redundant per ruff UP041.
        return False
    except Exception:
        return False


def _kickstart_daemon() -> bool:
    """Trigger ``launchctl kickstart -k gui/<uid>/com.haltonlabs.meter``.

    Returns True iff launchctl exited 0. Never raises. The ``-k`` flag
    sends SIGTERM to the existing process before relaunching, which
    matches what the operator would do by hand. Only called from inside
    :func:`run_watchdog` after the per-hour cap has been checked.
    """
    target = f"gui/{os.getuid()}/{_LAUNCHD_LABEL}"
    try:
        result = subprocess.run(
            ["launchctl", "kickstart", "-k", target],
            capture_output=True,
            timeout=5,
            check=False,
        )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False
    except Exception:
        return False


def snapshot_interfaces(listen_port: int) -> list[str]:
    """Return the macOS interfaces currently routing through ``127.0.0.1:listen_port``.

    The system proxy on each interface points at the daemon's mitmproxy
    *listener* (``daemon.listen_port``, default 8080), NOT the FastAPI
    HTTP API port (``daemon.api_port``, default 8765). The watchdog
    polls ``/health`` on ``api_port`` for liveness but matches
    interfaces against ``listen_port`` because that's the address the
    OS actually has stored against each network service.

    (2B.10.5: prior to this fix, both used ``api_port``. With
    ``listen_port=8080`` and ``api_port=8765`` distinct, the snapshot
    always returned empty, so the watchdog logged
    ``no_interfaces_pointing_at_us`` and exited even on a fully-installed
    daemon. Combined with 2B.10.4's ``KeepAlive={SuccessfulExit: False}``,
    that meant smoke_init Step 4e correctly reported ``[FAIL] watchdog
    not running``.)

    Snapshot is taken once at watchdog startup and not refreshed for
    the lifetime of the process. If the user changes their network
    setup mid-session, restarting the watchdog (``launchctl unload/load``
    of the watchdog plist) picks up the new state.
    """
    if sys.platform != "darwin":
        return []

    matching: list[str] = []
    for iface in system_proxy._macos_interfaces():
        # We reach into the leading-underscore helper here intentionally:
        # the same module already exports a public alias for the read
        # helper, but the interface list is configuration-as-data
        # populated dynamically (2B.7.2) from
        # ``networksetup -listallnetworkservices``. Same precedent as
        # ``_log_audit_event`` callers in the api layer.
        for secure in (True, False):
            enabled, host, port = system_proxy.read_proxy_target(iface, secure=secure)
            if not enabled:
                continue
            if host in {"127.0.0.1", "localhost", "0.0.0.0"} and port == listen_port:
                if iface not in matching:
                    matching.append(iface)
    return matching


# --------------------------------------------------------------------------- #
# Run loop                                                                     #
# --------------------------------------------------------------------------- #


def _log_transition(transition: StateTransition) -> None:
    if transition.from_ is transition.to:
        return
    log.info(
        "watchdog.state_change",
        from_=transition.from_.value,
        to=transition.to.value,
        fail_count=transition.fail_count,
        success_count=transition.success_count,
        disabled_proxy=transition.should_disable_proxy_now,
    )


def _resolve_runtime_ports(
    fallback_api_port: int, fallback_listen_port: int
) -> tuple[int, int]:
    """Read ``runtime.toml``-overlaid effective ports, falling back to the
    given defaults when the file is missing / unreadable.

    Used at watchdog startup and on each poll tick so that ports written
    by the daemon AFTER the watchdog launched (e.g. the daemon binding
    to the fallback 8082 / 8766 because 8081 / 8765 were already taken)
    are honoured without needing to restart the watchdog. Never raises.
    """
    try:
        cfg = load_effective_config()
    except Exception:
        return fallback_api_port, fallback_listen_port
    # v0.1.6 rename: the user-facing proxy port is ``edge_port``
    # (was ``listen_port``). The system-proxy is pointed at edge_port.
    return cfg.daemon.api_port, cfg.daemon.edge_port


def run_watchdog(
    api_port: int,
    *,
    listen_port: int | None = None,
    internal_port: int | None = None,
    max_polls: int | None = None,
) -> int:
    """Watchdog main loop.

    Two ports, two purposes:
    * ``api_port`` — FastAPI ``/health`` endpoint, polled every
      :data:`_POLL_INTERVAL_SECONDS` for liveness.
    * ``listen_port`` — mitmproxy listener address stored against each
      macOS network service; used to identify which interfaces are
      pointed at the daemon and therefore need their proxy disabled
      on a freeze.

    For backward compatibility, ``listen_port`` defaults to ``api_port``
    when not supplied. Production callers (``main()`` and the
    ``halton-meter watchdog`` Click command) always pass both.

    Snapshots the macOS interfaces currently pointed at the listener,
    then polls ``/health`` every :data:`_POLL_INTERVAL_SECONDS`.
    Disables the system proxy exactly on the DEGRADING -> PROXY_DISABLED
    edge. Never re-enables — the daemon's startup path handles re-enable
    via the ``proxy-managed`` sentinel.

    Cold-start tolerance (2B.10.8): the watchdog gates the actual
    ``disable_system_proxy`` call on having observed *at least one*
    successful ``/health`` response since process start. The launchd
    ``RunAtLoad`` semantics race the daemon and the watchdog at boot and
    after ``halton-meter start``; the watchdog typically wins. Without
    this gate, the watchdog's first 5 polls during the daemon's cold
    start (Python 3.14 + uv module imports take ~3-5s before
    ``/health`` answers 200) would tick the state machine straight to
    PROXY_DISABLED and tear down the user's system proxy seconds after
    they ran ``halton-meter start``. The gate is a *loop-level* I/O
    concern, not a state-machine concern: ``WatchdogState`` stays
    pure-logic (four states, no STARTING). The state machine still
    emits ``should_disable_proxy_now`` on the DEGRADING ->
    PROXY_DISABLED edge as before; we just refuse to act on it until
    the daemon has proven it can answer at least once. Once the first
    success has been seen, the watchdog behaves exactly as designed —
    the gate latches on for the lifetime of the process.

    ``max_polls`` is for tests only; if set, the loop exits after that
    many iterations regardless of state.

    Returns 0 on graceful shutdown, 0 if no interfaces point at us at
    startup (nothing to watch).
    """
    if listen_port is None:
        listen_port = api_port
    # MITM probe target: the daemon's internal mitmproxy listener (8090
    # default), NOT the user-facing edge port. Bug 1 (silent MITM death,
    # 2026-05-02) only manifests on the daemon's internal port — the edge
    # keeps accepting connections even when the daemon's MITM is dead.
    # Defaults to ``listen_port`` for back-compat with old test callers;
    # production caller (cli.py) passes the daemon's ``internal_port``.
    if internal_port is None:
        internal_port = listen_port

    interfaces = snapshot_interfaces(listen_port)
    if not interfaces:
        log.warning(
            "watchdog.no_interfaces_pointing_at_us",
            api_port=api_port,
            listen_port=listen_port,
            note=(
                "no macOS network service has its system proxy pointed at "
                "127.0.0.1:<listen_port>; watchdog has nothing to do — exiting"
            ),
        )
        return 0

    log.info(
        "watchdog.start",
        api_port=api_port,
        listen_port=listen_port,
        interfaces=interfaces,
        poll_interval_seconds=_POLL_INTERVAL_SECONDS,
        failure_threshold=_FAILURE_THRESHOLD,
        recovery_threshold=_RECOVERY_THRESHOLD,
    )
    # v0.1.21.4: emitted right before entering the poll loop. Pairs
    # with ``watchdog.startup.entered`` from ``main()`` so a soak log
    # tail can confirm both the entry and the readiness phase
    # completed (vs. snapshot_interfaces having returned empty and
    # exiting at line ~473).
    log.info(
        "watchdog.startup.ready",
        api_port=api_port,
        listen_port=listen_port,
        poll_interval_seconds=_POLL_INTERVAL_SECONDS,
    )

    machine = WatchdogStateMachine()
    # 2B.10.8: STARTING gate. Until we have seen at least one
    # successful /health response, refuse to disable the system proxy
    # even if the state machine fires PROXY_DISABLED. See run_watchdog
    # docstring for the cold-start race rationale.
    seen_first_success = False
    polls = 0
    # v0.1.16 P0.2: MITM-port liveness tracking. The state lives in
    # closure variables (not the WatchdogStateMachine) because it's a
    # separate concern: /health proves FastAPI is up, the MITM probe
    # proves the mitmproxy acceptor task is up. Both can fail
    # independently. The acceptor task can crash silently (asyncio
    # swallows the traceback) and Bug 1 in the v0.1.16 plan is
    # specifically the case where /health stays green but the listener
    # is dead. Sliding-window restart cap prevents tight loops if the
    # underlying cause persists across restarts.
    mitm_consecutive_fails = 0
    mitm_warn_logged = False
    mitm_restart_history: deque[float] = deque()
    # v0.1.19.dev1 (Phase 2 Bug B): /health-failure-driven kickstart.
    # Tracks consecutive `/health` failures only after we have ever seen
    # a green probe (no point counting against the cold-start window).
    health_consecutive_fails = 0
    health_restart_history: deque[float] = deque()
    while True:
        if max_polls is not None and polls >= max_polls:
            return 0

        # v0.1.13: re-resolve ports each tick so the watchdog tracks
        # post-startup runtime.toml changes (e.g. daemon restarts on
        # different fallback ports). When ports change we re-snapshot
        # interfaces; if the new listen_port has no interfaces pointing
        # at it the watchdog exits cleanly the same way it does on
        # startup. Cheap (one stat + tomllib parse per 1.5s tick).
        new_api_port, new_listen_port = _resolve_runtime_ports(api_port, listen_port)
        if (new_api_port, new_listen_port) != (api_port, listen_port):
            log.info(
                "watchdog.ports_changed",
                old_api_port=api_port,
                old_listen_port=listen_port,
                new_api_port=new_api_port,
                new_listen_port=new_listen_port,
            )
            api_port, listen_port = new_api_port, new_listen_port
            interfaces = snapshot_interfaces(listen_port)
            if not interfaces:
                log.warning(
                    "watchdog.no_interfaces_pointing_at_us",
                    api_port=api_port,
                    listen_port=listen_port,
                    note=(
                        "ports changed but no macOS network service is "
                        "pointed at the new listen_port; exiting"
                    ),
                )
                return 0

        success = poll_health(api_port)
        if success:
            seen_first_success = True
        transition = machine.record_health(success)
        if transition.should_disable_proxy_now and seen_first_success:
            disable_system_proxy(interfaces)
        elif transition.should_disable_proxy_now and not seen_first_success:
            # The state machine moved to PROXY_DISABLED, but we have
            # never confirmed the daemon was alive. Most likely the
            # watchdog won the cold-start race; do not punish the user
            # for that. Log so we can spot it in field logs.
            log.warning(
                "watchdog.suppressed_disable_during_cold_start",
                fail_count=transition.fail_count,
                note=(
                    "state machine reached PROXY_DISABLED before any "
                    "successful /health response; suppressing proxy "
                    "disable until daemon has proven liveness at least "
                    "once"
                ),
            )
        _log_transition(transition)

        # v0.1.19.dev1 (Phase 2 Bug B): /health-failure-driven kickstart.
        # Distinct from the MITM-port branch below (which fires when
        # /health is GREEN but mitmproxy is dead). This branch handles
        # the inverse: /health stays RED for N ticks and the daemon
        # process is alive (so we're not stomping a clean shutdown).
        # Without this, a wedged daemon plus the cardinal-rule
        # proxy-disable from earlier ticks leaves the user permanently
        # untracked until they intervene by hand.
        try:
            if success:
                if health_consecutive_fails > 0:
                    log.info(
                        "watchdog.health_recovered",
                        api_port=api_port,
                        consecutive_fails=health_consecutive_fails,
                    )
                health_consecutive_fails = 0
            elif seen_first_success:
                # Only count failures AFTER we have proven the daemon
                # was alive at least once — cold-start races never
                # trigger a restart.
                health_consecutive_fails += 1
                if health_consecutive_fails >= HEALTH_FAIL_THRESHOLD_RESTART:
                    now = time.monotonic()
                    cutoff = now - _MITM_RESTART_WINDOW_S
                    while (
                        health_restart_history
                        and health_restart_history[0] < cutoff
                    ):
                        health_restart_history.popleft()
                    if len(health_restart_history) >= HEALTH_RESTART_CAP_PER_HOUR:
                        log.error(
                            "watchdog.health_restart_cap_exceeded",
                            api_port=api_port,
                            restarts_in_window=len(health_restart_history),
                            window_seconds=_MITM_RESTART_WINDOW_S,
                            cap=HEALTH_RESTART_CAP_PER_HOUR,
                            note=(
                                "/health unresponsive after max restarts "
                                "in the last hour; manual intervention "
                                "required"
                            ),
                        )
                        # Reset so we re-fire on the next streak only.
                        health_consecutive_fails = 0
                    else:
                        log.error(
                            "watchdog.health_restart_attempt",
                            api_port=api_port,
                            consecutive_fails=health_consecutive_fails,
                            restarts_in_window=len(health_restart_history),
                            note=(
                                "/health unresponsive for sustained "
                                "window; daemon appears wedged — "
                                "kickstarting via launchctl"
                            ),
                        )
                        ok = _kickstart_daemon()
                        health_restart_history.append(now)
                        log.info(
                            "watchdog.health_restart_done",
                            launchctl_ok=ok,
                            target=f"gui/{os.getuid()}/{_LAUNCHD_LABEL}",
                        )
                        # Fresh budget after kickstart.
                        health_consecutive_fails = 0
        except Exception as exc:  # pragma: no cover — paranoia rail
            log.warning("watchdog.health_recovery_error", error=str(exc))

        # v0.1.16 P0.2: MITM port probe. Defensive try/except — this
        # MUST NEVER raise out of the watchdog tick (the operator
        # workflow depends on the watchdog staying alive even when the
        # daemon is in a bad state).
        try:
            mitm_alive = _probe_mitm_port("127.0.0.1", internal_port)
            if mitm_alive:
                if mitm_consecutive_fails > 0:
                    log.info(
                        "watchdog.mitm_recovered",
                        listen_port=listen_port,
                        consecutive_fails=mitm_consecutive_fails,
                    )
                mitm_consecutive_fails = 0
                mitm_warn_logged = False
            else:
                mitm_consecutive_fails += 1
                # Threshold 1: WARN — log ERROR exactly once per
                # failure streak so we don't spam the log every 1.5s.
                # The streak resets on a successful probe (see above),
                # so a flapping listener will WARN per outage, not per
                # tick.
                if (
                    mitm_consecutive_fails >= MITM_FAIL_THRESHOLD_WARN
                    and not mitm_warn_logged
                    and success
                ):
                    log.error(
                        "watchdog.mitm_unhealthy",
                        listen_port=listen_port,
                        consecutive_fails=mitm_consecutive_fails,
                        health_ok=True,
                        note=(
                            "MITM port unreachable while /health is up — "
                            "mitmproxy acceptor likely died silently; "
                            "metering is dark"
                        ),
                    )
                    mitm_warn_logged = True
                # Threshold 2: RESTART — kickstart the daemon via
                # launchd, subject to the per-hour cap. Cap-exceeded
                # state is sticky for the rest of the window: we keep
                # logging on every additional N=5 failure (which
                # happens once, then the counter is reset on success
                # or on the next attempted restart).
                if mitm_consecutive_fails >= MITM_FAIL_THRESHOLD_RESTART:
                    if not seen_first_success:
                        # The MITM port has never been alive since this
                        # watchdog started. Most likely the watchdog
                        # started before the daemon finished its cold-start
                        # sequence (Python import + mitmproxy construction
                        # + uvicorn bind can take 8–18s on a cold machine).
                        # Do NOT kickstart here — `launchctl kickstart -k`
                        # sends SIGTERM, which would kill a still-starting
                        # daemon and cause the user's `halton-meter start`
                        # probe to false-fail. Wait until we have seen at
                        # least one healthy /health response before
                        # trusting that MITM silence means a real failure.
                        log.warning(
                            "watchdog.suppressed_mitm_restart_during_cold_start",
                            listen_port=listen_port,
                            consecutive_fails=mitm_consecutive_fails,
                            note=(
                                "MITM port unreachable but no successful "
                                "/health response yet; suppressing kickstart "
                                "until daemon proves liveness — likely cold-start race"
                            ),
                        )
                        # Reset counter so we re-fire this log on the next
                        # streak rather than every tick.
                        mitm_consecutive_fails = 0
                        mitm_warn_logged = False
                    else:
                        now = time.monotonic()
                        # Trim restart history to the sliding window.
                        cutoff = now - _MITM_RESTART_WINDOW_S
                        while mitm_restart_history and mitm_restart_history[0] < cutoff:
                            mitm_restart_history.popleft()
                        if len(mitm_restart_history) >= MITM_RESTART_CAP_PER_HOUR:
                            log.error(
                                "watchdog.restart_cap_exceeded",
                                listen_port=listen_port,
                                restarts_in_window=len(mitm_restart_history),
                                window_seconds=_MITM_RESTART_WINDOW_S,
                                cap=MITM_RESTART_CAP_PER_HOUR,
                                note=(
                                    "MITM port still unreachable after "
                                    "max restarts in the last hour; "
                                    "manual intervention required"
                                ),
                            )
                            # Reset the consecutive counter so we don't
                            # spam this log every tick — only re-fire on
                            # the next 5-fail streak.
                            mitm_consecutive_fails = 0
                            mitm_warn_logged = False
                        else:
                            log.error(
                                "watchdog.mitm_restart_attempt",
                                listen_port=listen_port,
                                consecutive_fails=mitm_consecutive_fails,
                                restarts_in_window=len(mitm_restart_history),
                            )
                            ok = _kickstart_daemon()
                            mitm_restart_history.append(now)
                            log.info(
                                "watchdog.mitm_restart_done",
                                launchctl_ok=ok,
                                target=f"gui/{os.getuid()}/{_LAUNCHD_LABEL}",
                            )
                            # Reset so the post-restart cold start gets a
                            # fresh budget before the next attempt.
                            mitm_consecutive_fails = 0
                            mitm_warn_logged = False
        except Exception as exc:  # pragma: no cover — paranoia rail
            log.warning("watchdog.mitm_probe_error", error=str(exc))

        polls += 1
        time.sleep(_POLL_INTERVAL_SECONDS)


# --------------------------------------------------------------------------- #
# CLI entry point                                                              #
# --------------------------------------------------------------------------- #


def _install_signal_handlers() -> None:
    """SIGINT/SIGTERM trigger a clean exit; the watchdog never touches
    the system proxy on shutdown — that's the daemon's job."""

    def _exit(signum: int, _frame: Any) -> None:
        log.info("watchdog.shutdown", signal=signum)
        sys.exit(0)

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _exit)
        except (OSError, ValueError):
            # Some environments forbid signal installation; best-effort.
            pass


def poll_once(api_port: int) -> int:
    """Run a single health check and return 0 (healthy) or 1 (unhealthy)."""
    return 0 if poll_health(api_port) else 1


def main(api_port: int | None = None, listen_port: int | None = None) -> int:
    """Watchdog process entry point.

    Reads ``daemon.api_port`` and ``daemon.listen_port`` from config
    when not supplied. Distinct ports because ``/health`` lives on the
    FastAPI app (``api_port``, default 8765) but the system proxy on
    each interface points at the mitmproxy listener (``listen_port``,
    default 8080).
    """
    if api_port is None or listen_port is None:
        # v0.1.13: ``load_effective_config`` overlays ``runtime.toml`` on
        # top of ``config.toml`` defaults so we pick up the daemon's
        # fallback ports (e.g. 8082 / 8766) when 8081 / 8765 were taken
        # at daemon startup. Previously we used ``load_config`` which
        # ignores runtime.toml — and therefore the watchdog logged the
        # defaults forever, never matching the actual installed listener.
        try:
            cfg = load_effective_config()
            if api_port is None:
                api_port = cfg.daemon.api_port
            if listen_port is None:
                # v0.1.6: the user-facing proxy port is now ``edge_port``
                # (was ``listen_port``). The watchdog matches network
                # interfaces against this port — same address either
                # way.
                listen_port = cfg.daemon.edge_port
        except Exception:
            if api_port is None:
                api_port = API_PORT_DEFAULT
            if listen_port is None:
                listen_port = EDGE_PORT_DEFAULT

    # v0.1.21.4: structured startup/exit instrumentation. Soak
    # observation: status reports `Watchdog ⚠ dormant` immediately
    # after a successful `init --apps` despite the install path
    # kickstarting the watchdog label. These logs let the next soak
    # tell us whether the watchdog process even reached this entry
    # point — vs. being kickstarted-then-immediately-exited by launchd.
    try:
        from halton_meter import __version__ as _hm_version
    except Exception:
        _hm_version = "unknown"
    _started_monotonic = time.monotonic()
    log.info(
        "watchdog.startup.entered",
        pid=os.getpid(),
        version=_hm_version,
        api_port=api_port,
        listen_port=listen_port,
    )
    _install_signal_handlers()
    rc = 0
    exit_reason = "returned"
    try:
        rc = run_watchdog(api_port, listen_port=listen_port)
        exit_reason = f"run_watchdog_returned_{rc}"
        return rc
    except SystemExit as exc:
        exit_reason = f"system_exit_{exc.code}"
        raise
    except BaseException as exc:
        exit_reason = f"exception_{type(exc).__name__}"
        raise
    finally:
        log.info(
            "watchdog.exit",
            reason=exit_reason,
            uptime_s=round(time.monotonic() - _started_monotonic, 3),
            rc=rc,
        )
