"""
FastAPI app factory for the Halton Meter daemon.

The app is mounted by `halton-meter daemon` programmatically — it is not
launched standalone via `uvicorn app:main`. The factory takes a HaltonConfig
so CORS origins (and future settings) flow from the same config file the
rest of the daemon reads.

Phase 2B.1 ships a skeleton: only the /health router is wired in. Routers
ported from the legacy backend (projects, pricing_rates, reconciliation,
policies, audit, daemon) land in Phase 2B.3.

Onboarding (v0.2.6+): two more routers — ``cloud_state`` (paired-state
probe) and ``cloud_connect`` (browser-triggered pairing) — are mounted
so the cloud dashboard at ``app.haltonmeter.com`` can detect this
daemon during first-login onboarding and drive a fully in-browser pair.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response

from halton_meter import __version__
from halton_meter.api.deps import configure_session_factory
from halton_meter.api.routers import (
    audit,
    cloud_connect,
    cloud_state,
    daemon,
    health,
    ingest,
    policies,
    pricing_rates,
    projects,
    reconciliation,
)
from halton_meter.config import HaltonConfig


def create_app(config: HaltonConfig | None = None) -> FastAPI:
    """
    Build a FastAPI app for the daemon.

    Args:
        config: HaltonConfig instance. If None, defaults are used — useful for
            tests and ad-hoc REPL exploration. Production callers (the CLI)
            always pass an explicit config.

    Returns:
        A configured FastAPI app. Not yet bound to a server — the caller
        wraps it in uvicorn.
    """
    cfg = config or HaltonConfig()
    configure_session_factory(cfg.storage.db_path)

    app = FastAPI(
        title="Halton Meter",
        description="Local LLM API cost-attribution daemon HTTP API.",
        version=__version__,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(cfg.cors.allow_origins),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        # ``Access-Control-Allow-Private-Network`` is needed for
        # Chrome ≥ 117's Private Network Access (PNA) gate when the
        # cloud dashboard (a public HTTPS origin) probes the daemon's
        # loopback API. Without it the preflight is rejected and the
        # onboarding auto-detect probe silently fails on Chrome.
        # ``allow_headers=["*"]`` covers the request side; the response
        # header is added in :func:`_private_network_header`.
        expose_headers=["Access-Control-Allow-Private-Network"],
    )

    app.middleware("http")(_private_network_header)

    app.include_router(health.router)
    app.include_router(projects.router)
    app.include_router(pricing_rates.router)
    app.include_router(reconciliation.router)
    app.include_router(policies.router)
    app.include_router(audit.router)
    app.include_router(daemon.router)
    app.include_router(ingest.router)
    app.include_router(cloud_state.router)
    app.include_router(cloud_connect.router)

    return app


async def _private_network_header(
    request: Request,
    call_next: Callable[[Request], Awaitable[Response]],
) -> Response:
    """Stamp ``Access-Control-Allow-Private-Network: true`` on the response.

    Chrome's PNA check fires on the CORS preflight (the ``OPTIONS``
    request that carries ``Access-Control-Request-Private-Network:
    true``) and on the actual request that follows. Adding the header
    unconditionally is simpler than branching on the request header and
    costs nothing on non-Chrome browsers that ignore it. Safari and
    Firefox don't enforce PNA today so the extra header is a no-op for
    them.
    """
    response = await call_next(request)
    response.headers.setdefault("Access-Control-Allow-Private-Network", "true")
    return response
