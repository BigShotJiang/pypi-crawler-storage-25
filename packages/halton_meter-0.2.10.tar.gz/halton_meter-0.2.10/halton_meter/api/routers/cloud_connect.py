"""``/v1/cloud/connect`` — browser-triggered pairing handshake.

The cloud onboarding flow can call ``POST /v1/cloud/connect`` from the
dashboard to ask this daemon to start a pairing handshake against the
cloud. The daemon kicks off the same ``CloudClient.pairing_start`` →
``CloudClient.pairing_poll`` loop the ``halton-meter cloud connect`` CLI
runs, in a background task, and returns the pairing code + URL to the
browser immediately so the dashboard can render the approve form
inline. The browser then polls ``GET /v1/cloud/connect/status`` (or
watches the cloud ``sync-health`` endpoint) to know when the daemon
has consumed the API key.

This endpoint mutates daemon state — it writes the pairing credentials
on success — but only when the operator explicitly clicks "Pair this
daemon" in the browser. CORS is restricted to the configured dashboard
origins (defaults to ``localhost:3000`` + ``app.haltonmeter.com``) and
the bind address is loopback only, so reach-from-the-internet is not
a concern.

Safety:

* Refuses with 409 if the daemon is already paired. Re-pairing is
  destructive — the existing API key gets revoked cloud-side and any
  unsynced rows would orphan against the old key. Make the user
  explicitly ``halton-meter cloud disconnect`` first.
* Refuses with 409 if another pairing handshake is already in flight.
  Pairing codes are rate-limited cloud-side (10/IP). Don't burn them.
* The pairing code is single-shot at the cloud — a second POST after
  approval is a no-op against the existing credentials.
"""

from __future__ import annotations

import asyncio
import logging
import platform as _platform
import socket
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter import __version__
from halton_meter.api.deps import get_session
from halton_meter.cli_cloud import _resolved_db_path
from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.config_glue import load_cloud_config
from halton_meter.cloud.errors import (
    CloudRateLimited,
    CloudSchemaMismatch,
    CloudTransport,
    CloudUnauthorised,
)
from halton_meter.storage import StorageManager
from halton_meter.storage.models import CloudState

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/cloud", tags=["cloud-connect"])

# Pairing lifecycle vocabulary — kept in lockstep with the cloud
# ``pairing.py`` router's status enum where it overlaps, plus two
# daemon-local additions (``starting`` / ``failed``) the cloud never
# emits because it's not the side driving the loop.
_STATE_STARTING = "starting"
_STATE_AWAITING_APPROVAL = "awaiting_approval"
_STATE_APPROVED = "approved"
_STATE_DENIED = "denied"
_STATE_EXPIRED = "expired"
_STATE_CONSUMED = "consumed"
_STATE_FAILED = "failed"

_POLL_INTERVAL_SECONDS = 2.0
_DEFAULT_TIMEOUT_SECONDS = 600.0


@dataclass
class _ActivePairing:
    """In-process record of the active pairing handshake.

    Held in a module-level ``_active`` slot. Only one handshake is
    permitted at a time — see the 409 in :func:`start_cloud_connect`.
    The object outlives the response so the dashboard can subsequently
    poll :func:`get_cloud_connect_status`.
    """

    state: str
    pairing_code: str | None
    pairing_url: str | None
    expires_at: datetime | None
    started_at: datetime
    base_url: str
    error: str | None = None
    workspace_id: str | None = None
    workspace_name: str | None = None
    machine_id: str | None = None
    task: asyncio.Task[Any] | None = None


_active: _ActivePairing | None = None
_lock = asyncio.Lock()


class StartCloudConnectRequest(BaseModel):
    """Optional knobs for the browser-triggered pairing flow.

    The dashboard usually sends an empty body — the daemon already
    knows its own base URL from ``config.toml``. ``base_url`` is here
    as an escape hatch for the case where the operator wants to point
    a paired daemon at a different cloud surface without editing config
    (e.g. staging).
    """

    base_url: str | None = Field(default=None)
    timeout_seconds: float = Field(default=_DEFAULT_TIMEOUT_SECONDS, gt=0, le=900)


class CloudConnectStatusResponse(BaseModel):
    """Snapshot of the in-flight pairing handshake.

    ``state == "approved"`` is the dashboard's signal to stop polling
    this endpoint and rely on the cloud ``sync-health`` cycle for the
    final "data is flowing" handshake — the daemon's pairing-write
    finished before the response was emitted.
    """

    state: str
    pairing_code: str | None = None
    pairing_url: str | None = None
    expires_at: datetime | None = None
    started_at: datetime | None = None
    workspace_id: str | None = None
    workspace_name: str | None = None
    machine_id: str | None = None
    error: str | None = None
    daemon_version: str = Field(default=__version__)
    hostname: str = Field(default_factory=socket.gethostname)


@router.post(
    "/connect",
    response_model=CloudConnectStatusResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def start_cloud_connect(
    body: StartCloudConnectRequest,
    session: Annotated[AsyncSession, Depends(get_session)],
) -> CloudConnectStatusResponse:
    """Begin a pairing handshake on behalf of the dashboard.

    Returns ``202 Accepted`` with the pairing code + URL the user
    should approve. The dashboard renders the approve form inline
    using these values.

    Raises:
        HTTPException(409): daemon is already paired (must
            ``cloud disconnect`` first) OR another handshake is in
            flight.
        HTTPException(503): no cloud base URL configured and none
            supplied in the request body — nothing to pair against.
    """
    global _active

    # Refuse if already paired. Re-pair is destructive and should be
    # an explicit ``cloud disconnect`` from the operator.
    existing = (await session.execute(_select_any_cloud_state())).scalar_one_or_none()
    if existing is not None and existing.workspace_id and existing.enabled:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "already_paired",
                "workspace_id": existing.workspace_id,
                "workspace_name": existing.workspace_name,
                "hint": "Run `halton-meter cloud disconnect` first, then retry.",
            },
        )

    base_url = body.base_url or load_cloud_config().base_url
    if not base_url:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "no_endpoint",
                "hint": (
                    "No cloud base URL is configured. Either pass it in the "
                    "request body, or set `[cloud].base_url` in "
                    "~/.halton-meter/config.toml."
                ),
            },
        )

    async with _lock:
        if _active is not None and _active.state in (
            _STATE_STARTING,
            _STATE_AWAITING_APPROVAL,
        ):
            # Another handshake is in flight. Return its current state
            # so the browser can render the same approve form (handles
            # the "user double-clicked Pair" case gracefully).
            return _snapshot(_active)

        active = _ActivePairing(
            state=_STATE_STARTING,
            pairing_code=None,
            pairing_url=None,
            expires_at=None,
            started_at=datetime.now(tz=UTC),
            base_url=base_url,
        )
        _active = active

    # Launch the pairing loop. We *await* the start so the response
    # carries the pairing_code (the whole point of the in-browser
    # short-circuit); the polling that follows runs in a background
    # task because it blocks for up to ``timeout_seconds``.
    try:
        await _drive_pairing_start(active)
    except _PairingStartFailed as exc:
        active.state = _STATE_FAILED
        active.error = str(exc)
        logger.warning("cloud.connect.start_failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={"error": "pairing_start_failed", "message": str(exc)},
        ) from exc

    active.task = asyncio.create_task(
        _drive_pairing_poll(active, timeout_seconds=body.timeout_seconds)
    )
    return _snapshot(active)


@router.get("/connect/status", response_model=CloudConnectStatusResponse)
async def get_cloud_connect_status() -> CloudConnectStatusResponse:
    """Return the current state of the active pairing handshake.

    Dashboard polls this every couple of seconds while the user is
    looking at the approve form. ``state="approved"`` is the cue to
    transition into the post-pairing onboarding step. The dashboard
    *can* prefer the cloud-side ``sync-health`` signal instead — that
    poll already drives the next step and survives daemon restarts —
    but this endpoint is faster (no network round-trip beyond
    loopback) for the immediate "did the daemon receive the key yet?"
    feedback.
    """
    if _active is None:
        return CloudConnectStatusResponse(state="idle")
    return _snapshot(_active)


# --------------------------------------------------------------------------- #
# Internal helpers                                                            #
# --------------------------------------------------------------------------- #


class _PairingStartFailed(Exception):
    """Raised when ``CloudClient.pairing_start`` did not return a code."""


def _select_any_cloud_state() -> Any:
    from sqlalchemy import select

    # Latest connected_at row. A daemon that's had ``cloud disconnect``
    # run against it keeps the row but with ``enabled=False`` — see
    # ``StorageManager.cloud_set_state``.
    return select(CloudState).order_by(CloudState.connected_at.desc().nulls_last()).limit(1)


def _snapshot(active: _ActivePairing) -> CloudConnectStatusResponse:
    return CloudConnectStatusResponse(
        state=active.state,
        pairing_code=active.pairing_code,
        pairing_url=active.pairing_url,
        expires_at=active.expires_at,
        started_at=active.started_at,
        workspace_id=active.workspace_id,
        workspace_name=active.workspace_name,
        machine_id=active.machine_id,
        error=active.error,
    )


async def _drive_pairing_start(active: _ActivePairing) -> None:
    """Call ``pairing_start`` and stash the code + URL on the record."""
    async with CloudClient(base_url=active.base_url) as client:
        try:
            start = await client.pairing_start(
                hostname=socket.gethostname(),
                daemon_version=__version__,
                platform=_platform.system(),
            )
        except CloudRateLimited as exc:
            raise _PairingStartFailed(f"rate-limited: {exc}") from exc
        except (CloudTransport, CloudSchemaMismatch) as exc:
            raise _PairingStartFailed(str(exc)) from exc

    pairing_code = start.get("pairing_code")
    if not pairing_code:
        raise _PairingStartFailed("cloud returned no pairing_code")

    expires_at_raw = start.get("expires_at")
    try:
        expires_at = (
            datetime.fromisoformat(expires_at_raw.replace("Z", "+00:00"))
            if isinstance(expires_at_raw, str)
            else None
        )
    except ValueError:
        expires_at = None

    active.pairing_code = str(pairing_code)
    active.pairing_url = (
        str(start.get("pairing_url"))
        if start.get("pairing_url")
        else None
    )
    active.expires_at = expires_at
    active.state = _STATE_AWAITING_APPROVAL
    # ``poll_token`` is a daemon-only secret — stash on the active
    # record so the background poller has it without re-deriving.
    active.error = None
    object.__setattr__(active, "_poll_token", str(start.get("poll_token") or ""))


async def _drive_pairing_poll(active: _ActivePairing, *, timeout_seconds: float) -> None:
    """Poll until terminal status, then persist the credentials.

    Always finishes — either with one of the terminal pairing statuses
    or with ``state=_STATE_FAILED`` on transport error. The main thread
    can re-POST to start a fresh handshake once this task settles.
    """
    poll_token = getattr(active, "_poll_token", "") or ""
    if not active.pairing_code or not poll_token:
        active.state = _STATE_FAILED
        active.error = "missing pairing_code/poll_token after start"
        return

    deadline = asyncio.get_running_loop().time() + timeout_seconds
    try:
        async with CloudClient(base_url=active.base_url) as client:
            while True:
                if asyncio.get_running_loop().time() > deadline:
                    active.state = _STATE_EXPIRED
                    active.error = "pairing timed out before approval"
                    return
                try:
                    polled = await client.pairing_poll(
                        pairing_code=active.pairing_code,
                        poll_token=poll_token,
                    )
                except (CloudTransport, CloudSchemaMismatch, CloudRateLimited) as exc:
                    active.state = _STATE_FAILED
                    active.error = f"poll failed: {exc}"
                    return
                except CloudUnauthorised as exc:
                    active.state = _STATE_FAILED
                    active.error = f"poll unauthorised: {exc}"
                    return

                cloud_status = polled.get("status")
                if cloud_status == _STATE_APPROVED:
                    await _persist_credentials(active, polled)
                    active.state = _STATE_APPROVED
                    return
                if cloud_status == _STATE_DENIED:
                    active.state = _STATE_DENIED
                    return
                if cloud_status == _STATE_EXPIRED:
                    active.state = _STATE_EXPIRED
                    return
                if cloud_status == _STATE_CONSUMED:
                    # Already consumed by a prior poll — treat as
                    # success; the credentials must already be on disk.
                    active.state = _STATE_CONSUMED
                    return
                # Anything else is "still pending"; keep polling.
                await asyncio.sleep(_POLL_INTERVAL_SECONDS)
    except Exception as exc:  # pragma: no cover — defence in depth
        logger.exception("cloud.connect.poll_loop_crashed")
        active.state = _STATE_FAILED
        active.error = f"unexpected: {exc}"


async def _persist_credentials(active: _ActivePairing, polled: dict[str, Any]) -> None:
    """Write the API key + workspace binding into ``cloud_state`` + 0600 file.

    Mirrors the persistence sequence in
    :func:`halton_meter.cli_cloud._write_cloud_state_token` — 0600 file
    first (primary store per the wire contract), encrypted DB row
    second, ``config.toml`` last — but does the DB write inline because
    we're already on an event loop and the CLI helper drives it
    through ``asyncio.run()``.
    """
    api_key = polled.get("api_key")
    if not api_key:
        active.state = _STATE_FAILED
        active.error = "approved without api_key"
        return

    workspace_id = polled.get("workspace_id")
    workspace_name = polled.get("workspace_name")
    machine_id = polled.get("machine_id")

    active.workspace_id = str(workspace_id) if workspace_id else None
    active.workspace_name = str(workspace_name) if workspace_name else None
    active.machine_id = str(machine_id) if machine_id else None

    # 0600 credentials file — primary token store. Failure logged but
    # not fatal; the encrypted DB row below is the recoverable mirror.
    try:
        from halton_meter.cli_cloud import _write_credentials_file

        _write_credentials_file(
            {
                "endpoint": active.base_url,
                "api_key": str(api_key),
                "workspace_id": active.workspace_id,
                "workspace_name": active.workspace_name,
                "machine_id": active.machine_id,
            }
        )
    except Exception as exc:  # pragma: no cover — non-fatal
        logger.warning("cloud.connect.credentials_file_write_failed: %s", exc)

    # Encrypted DB row + master switch flip. Done inline because we're
    # already in an event loop (the CLI helper uses ``asyncio.run`` which
    # would deadlock here).  ``_resolved_db_path`` is imported from
    # ``cli_cloud`` — single source of truth.
    try:
        async with StorageManager(_resolved_db_path()) as storage:
            await storage.cloud_set_state(
                endpoint=active.base_url,
                api_key_plaintext=str(api_key),
                workspace_id=active.workspace_id,
                workspace_name=active.workspace_name,
                machine_id=active.machine_id,
                hostname_reported=socket.gethostname(),
                base_url=active.base_url,
                enabled=True,
                connected_at=datetime.now(tz=UTC),
                paused_reason=None,
            )
    except Exception as exc:
        logger.exception("cloud.connect.persist_failed")
        active.state = _STATE_FAILED
        active.error = f"persist_failed: {exc}"
        return

    # config.toml refresh — ``cloud status`` / ``cloud sync`` rely on
    # ``[cloud].base_url`` being present after pairing succeeds.
    try:
        from halton_meter.cli_cloud import _persist_base_url_to_toml

        _persist_base_url_to_toml(active.base_url)
    except Exception as exc:  # pragma: no cover — non-fatal
        logger.warning("cloud.connect.config_write_failed: %s", exc)


