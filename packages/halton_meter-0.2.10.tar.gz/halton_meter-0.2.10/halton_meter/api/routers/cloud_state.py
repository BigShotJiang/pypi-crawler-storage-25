"""``GET /v1/cloud/state`` — paired-state probe consumed by the dashboard.

The cloud onboarding flow probes this endpoint from the user's browser
right after first-login to answer two questions in one round-trip:

  1. Is a daemon running on this machine? (probe is reachable)
  2. Is it paired? If so, to which workspace?

Strictly read-only. Never returns the API key or the Fernet ciphertext —
only the metadata the dashboard needs to decide which onboarding screen
to render. Authentication is intentionally absent: the endpoint is bound
to ``127.0.0.1`` (loopback only) and CORS is restricted to the
configured dashboard origins. A caller that can reach the endpoint
already has loopback access to the user's machine and could read
``~/.halton-meter/cloud-credentials.json`` directly anyway.
"""

from __future__ import annotations

import platform as _platform
import socket
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter import __version__
from halton_meter.api.deps import get_session
from halton_meter.cloud.config_glue import load_cloud_config
from halton_meter.storage.models import CloudState

router = APIRouter(prefix="/v1/cloud", tags=["cloud-state"])


class CloudStateResponse(BaseModel):
    """The cloud-pairing snapshot returned to the dashboard.

    Field-by-field rationale:

    * ``paired`` is the single most useful boolean for the dashboard's
      segment-detection. It is True iff an enabled ``cloud_state`` row
      exists with a workspace_id.
    * ``workspace_id`` + ``workspace_name`` let the dashboard cross-
      check whether the daemon is paired to the workspace the signed-in
      user is currently viewing.
    * ``hostname`` + ``platform`` mirror the values the daemon would
      otherwise send via ``/v1/pairing/start`` — they're the user's
      "this is my machine" affirmation.
    * ``daemon_version`` lets the dashboard surface "your daemon is out
      of date, upgrade with `uv tool upgrade halton-meter`" without an
      extra round-trip.
    * ``paused_reason`` surfaces auth-error / quota-error states so the
      dashboard can hint at recovery actions ("re-pair" / "check
      cloud-side billing").
    """

    paired: bool = Field(
        description=(
            "True iff this daemon has a workspace binding and the cloud "
            "worker is enabled."
        ),
    )
    workspace_id: str | None = Field(default=None)
    workspace_name: str | None = Field(default=None)
    machine_id: str | None = Field(default=None)
    base_url: str | None = Field(
        default=None,
        description="Cloud endpoint this daemon talks to.",
    )
    enabled: bool = Field(
        default=False,
        description="Master switch on the cloud_state row.",
    )
    paused_reason: str | None = Field(default=None)
    daemon_version: str = Field(
        description="Daemon package version — useful for upgrade prompts.",
    )
    hostname: str = Field(description="``socket.gethostname()`` at request time.")
    platform: str = Field(
        description="``platform.system()`` — Darwin / Linux / Windows.",
    )


@router.get("/state", response_model=CloudStateResponse)
async def get_cloud_state(
    session: Annotated[AsyncSession, Depends(get_session)],
) -> CloudStateResponse:
    """Return the daemon's cloud-pairing snapshot.

    The endpoint resolves the *configured* cloud endpoint (from
    ``~/.halton-meter/config.toml``) and looks up the matching
    ``cloud_state`` row. If no endpoint is configured, or no row
    exists, the response carries ``paired=false`` with the daemon's
    version + hostname so the dashboard can still display the
    "we found your daemon" affirmation.
    """
    base_url = load_cloud_config().base_url or None

    state: CloudState | None = None
    if base_url:
        state = await session.get(CloudState, base_url)

    if state is None:
        # Fall back: look up any row in the table. A daemon may have a
        # pairing persisted under an endpoint that no longer matches
        # ``config.toml`` (e.g. user edited the file). Best-effort: pick
        # the most-recently-connected row if there is one.
        row = (
            await session.execute(
                select(CloudState).order_by(CloudState.connected_at.desc().nulls_last()).limit(1)
            )
        ).scalar_one_or_none()
        state = row

    hostname = socket.gethostname()
    platform = _platform.system()

    if state is None:
        return CloudStateResponse(
            paired=False,
            daemon_version=__version__,
            hostname=hostname,
            platform=platform,
        )

    paired = bool(state.workspace_id) and bool(state.enabled)

    return CloudStateResponse(
        paired=paired,
        workspace_id=state.workspace_id,
        workspace_name=state.workspace_name,
        machine_id=state.machine_id,
        base_url=state.base_url or base_url,
        enabled=bool(state.enabled),
        paused_reason=state.paused_reason,
        daemon_version=__version__,
        hostname=hostname,
        platform=platform,
    )
