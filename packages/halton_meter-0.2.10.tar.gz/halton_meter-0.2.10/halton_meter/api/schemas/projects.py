"""Pydantic schemas for projects + stats endpoints.

Ported verbatim from halton-meter-cloud:backend/app/schemas/projects.py.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ProjectMonthStats(BaseModel):
    requests_this_month: int
    cost_usd_this_month_minor_units: int
    previous_month_cost_usd_minor_units: int = Field(default=0)
    all_time_cost_usd_minor_units: int = Field(default=0)
    all_time_requests: int = Field(default=0)
    last_active_at: datetime | None
    primary_model: str | None = None
    primary_provider: str | None = None
    # All-time top model + provider, ranked by cost (highest cost wins).
    # Used by the Projects page Top Model / Top Provider columns. Computed
    # server-side because the dashboard's MODELS lookup table has undated
    # IDs (claude-opus-4-7) but the daemon stores dated variants
    # (claude-opus-4-7-20260101) — exact-match fails client-side. NULL on
    # projects with zero captured requests.
    top_model: str | None = None
    top_provider: str | None = None


class ProjectListItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    created_at: datetime
    archived_at: datetime | None
    stats: ProjectMonthStats


class ProjectDetail(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    created_at: datetime
    archived_at: datetime | None
    stats: ProjectMonthStats


class RatesSourceBreakdown(BaseModel):
    """Per-``rates_source`` request count (v0.1.22.22, Layer 1).

    Surfaced on aggregate stats so the dashboard / report consumers can
    show "of N requests, X were priced from bundled rates and Y from
    operator overrides". Keys mirror the values stamped on
    ``requests.rates_source``: ``"bundled-YYYY-MM-DD"``, ``"override"``,
    plus the synthetic ``"unknown"`` bucket for legacy NULL rows.
    """

    bundled: int = Field(default=0)
    override: int = Field(default=0)
    unknown: int = Field(default=0)


class StatsSummary(BaseModel):
    total_requests: int
    total_input_tokens: int
    total_output_tokens: int
    total_thinking_tokens: int
    # Renamed from `total_cached_tokens` 2026-04-30 (decisions.md). The
    # cache-hit-rate denominator continues to use the read count.
    total_cache_read_tokens: int
    total_cache_write_tokens: int
    total_cost_usd_minor_units: int
    cache_hit_rate: float
    active_projects: int = Field(default=0)
    models_in_use: int = Field(default=0)
    last_request_at: datetime | None = None
    # Pricing-freshness rollup (v0.1.22.22, Layer 1).
    rates_breakdown: RatesSourceBreakdown = Field(default_factory=RatesSourceBreakdown)


class StatsByDay(BaseModel):
    date: str
    requests: int
    cost_usd_minor_units: int


class StatsByDayByProvider(BaseModel):
    date: str
    provider: str
    requests: int
    cost_usd_minor_units: int


class StatsByProvider(BaseModel):
    provider: str
    requests: int
    cost_usd_minor_units: int


class StatsByModel(BaseModel):
    provider: str
    model: str
    requests: int
    input_tokens: int
    output_tokens: int
    cost_usd_minor_units: int


class RequestRecord(BaseModel):
    id: uuid.UUID
    provider: str
    model: str
    mode: str
    input_tokens: int
    output_tokens: int
    thinking_tokens: int
    # Renamed from `cached_tokens` 2026-04-30 (decisions.md).
    cache_read_tokens: int
    cache_write_tokens: int
    cost_usd_minor_units: int | None
    latency_ms: float | None
    tokens_complete: bool
    requested_at: datetime
    status: str
    # Pricing-freshness audit field (v0.1.22.22, Layer 1). One of
    # ``"bundled-YYYY-MM-DD"``, ``"override"``, or ``None`` for rows
    # written before this column existed (or for rows whose cost came
    # from the bundled-matrix fallback path with no rate row match).
    rates_source: str | None = None


class RequestsPage(BaseModel):
    items: list[RequestRecord]
    next_cursor: str | None = None
    total: int


class ProjectStats(BaseModel):
    summary: StatsSummary
    by_day: list[StatsByDay]
    by_day_by_provider: list[StatsByDayByProvider] = Field(default_factory=list)
    by_provider: list[StatsByProvider]
    by_model: list[StatsByModel]
    requests: RequestsPage


class GlobalStats(BaseModel):
    summary: StatsSummary
    by_day: list[StatsByDay]
    by_day_by_provider: list[StatsByDayByProvider]
    by_provider: list[StatsByProvider]
    by_model: list[StatsByModel]
