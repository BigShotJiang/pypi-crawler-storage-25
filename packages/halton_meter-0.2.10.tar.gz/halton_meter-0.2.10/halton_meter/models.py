"""
Pydantic models for Halton Meter local log records.

LogRecord maps 1:1 to the `requests` table in schema.sql.
All money fields are integers in millicents (1 USD = 100_000 millicents).
See memory/decisions.md 2026-04-28 for the money-storage decision.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class LogRecord(BaseModel):
    """
    A single captured LLM API request/response pair.

    Stored in SQLite at ~/.halton-meter/logs.db. Synced to the backend in
    Phase 1. cost_millicents is nullable — NULL means we have no pricing
    rate for this model (e.g. unknown model, or Phase 0 pricing matrix
    doesn't cover it).
    """

    model_config = ConfigDict(frozen=True)

    id: str = Field(description="UUID v4 — unique record identifier")
    project: str = Field(description="Project tag resolved by tagging.py")
    provider: str = Field(description="Provider name, e.g. 'anthropic'")
    model: str = Field(description="Model identifier as returned by the provider")

    input_tokens: int = Field(default=0, description="Prompt tokens including system and tools")
    output_tokens: int = Field(default=0, description="Completion tokens")
    thinking_tokens: int = Field(
        default=0,
        description="Extended thinking tokens (Anthropic) or reasoning tokens (OpenAI o-series)",
    )
    cache_read_tokens: int = Field(
        default=0,
        description="Cache READ tokens (Anthropic: usage.cache_read_input_tokens).",
    )
    cache_write_tokens: int = Field(
        default=0,
        description=(
            "Cache WRITE tokens (Anthropic: usage.cache_creation_input_tokens). "
            "See pricing/matrix.py for the 5m/1h TTL-limitation note."
        ),
    )

    cost_millicents: int | None = Field(
        default=None,
        description=(
            "Computed cost in millicents (1 USD = 100_000). "
            "NULL if model is unknown or not in the pricing matrix."
        ),
    )

    tokens_complete: bool = Field(
        default=True,
        description="False if response body was truncated and token counts may be partial",
    )
    latency_ms: float = Field(default=0.0, description="End-to-end latency in milliseconds")

    # Phase 2 Wave 1A.ii: time-to-first-token (streaming responses only;
    # non-streaming flows leave this None — the cloud receiver treats
    # None as "not applicable / not computable"). Sourced from the
    # difference between ``flow.response.timestamp_start`` and
    # ``flow.request.timestamp_end`` in the proxy hot path; left as
    # ``None`` when either timestamp is missing.
    time_to_first_token_ms: int | None = Field(
        default=None,
        description="Time from request fully sent to first response byte (ms). Streaming only.",
    )

    requested_at: str = Field(description="ISO 8601 UTC timestamp when the request was made")
    recorded_at: str = Field(description="ISO 8601 UTC timestamp when the record was written")

    # Phase 3: request disposition. 'success' | 'error' | 'blocked_by_policy'
    status: str = Field(default="success", description="Request disposition")

    # Phase 2 Wave 1A.ii: provider-side request shape classification.
    # ``chat`` / ``embedding`` / ``tool`` / ``unknown``. Populated by
    # adapter ``parse_request`` via ``cloud_fields.derive_request_kind``.
    # Optional so legacy / backfill callers keep working with the default
    # of ``None``.
    request_kind: str | None = Field(
        default=None,
        description=(
            "Request shape classification: 'chat' / 'embedding' / 'tool' / 'unknown'."
        ),
    )

    # Phase 2 Wave 1A.ii: SHA-256 of the canonical-JSON-encoded prompt.
    # NEVER the raw text — the contract pins this to a digest only so
    # the daemon can never accidentally exfiltrate prompt content via the
    # metadata sync envelope. Computed by ``cloud_fields.canonical_prompt_hash``
    # over the adapter-parsed request body.
    prompt_hash: str | None = Field(
        default=None,
        description="SHA-256 hex digest of canonical-JSON-encoded prompt. Never the raw text.",
    )

    # Phase 2 Wave 1A.ii: provider-supplied idempotency key, echoed
    # verbatim. Never synthesised — the contract is "echo if present".
    idempotency_key: str | None = Field(
        default=None,
        description="Per-request idempotency key, echoed from the provider's request header.",
    )

    # Phase 2 Wave 1A.ii: hostname snapshot at daemon start. Identifies
    # the developer machine when the workspace contains many machines.
    # Captured once at first call to ``cloud_fields.get_source_machine``
    # and reused for the lifetime of the daemon process.
    source_machine: str | None = Field(
        default=None,
        description="``socket.gethostname()`` snapshot from daemon process start.",
    )

    # Phase 2 Wave 1A.i (storage layer): USD → GBP rate snapshot used at
    # write time. Audit-only on the wire — cloud is authoritative for
    # cost when ``cloud.enabled = true``. Pinned to wire-contract
    # SHA e8f252a §3 (``LogRecordIn.fx_rate``). Stored on the row so
    # that downstream drift analysis can attribute cost changes to
    # either a token-count drift or an FX-rate drift.
    fx_rate: float | None = Field(
        default=None,
        description=(
            "USD → GBP rate the daemon used at write time. "
            "Audit-only — cloud recomputes cost authoritatively."
        ),
    )

    # Smart Attribution observability (added 2026-05-02). Both fields are
    # populated by ``tagging.resolve_project_with_meta`` on the proxy hot
    # path so the ``requests`` table records WHICH attribution layer fired
    # for each row. Defaults are ``None`` so legacy callers (tests,
    # backfill) keep working without source-edits; the daemon's hot path
    # always supplies both.
    attribution_method: str | None = Field(
        default=None,
        description=(
            "Which attribution layer resolved the project. One of: "
            "'edge_store', 'env', 'rcfile', 'ide_sniff', 'git', 'container', "
            "'mac_sandbox', 'workdir', 'unattributed'. None when the writer "
            "did not supply a method (legacy / backfill path)."
        ),
    )
    source_workdir: str | None = Field(
        default=None,
        description=(
            "The cwd that was used as input to the layer that won. "
            "None for cache hits ('edge_store' — the original method's "
            "source_workdir was recorded ONCE at edge time and is not "
            "currently re-surfaced on cache hit; tracked as a follow-up) "
            "and for env-var hits (no cwd consulted)."
        ),
    )
