"""
SQLite-backed attribution store — race-free edge → daemon project handoff.

WHY THIS EXISTS
---------------

The edge process accepts the client's TCP CONNECT, resolves the project
name via a psutil walk (see ``edge_attribution.py``), and must hand that
name off to the daemon's mitmproxy ``request()`` hook **before** the
hook fires. The original v0.1.13 design routed the handoff over
``POST /v1/internal/attribution`` to FastAPI/uvicorn. In production this
raced the proxy hot path 100 % of the time: by the time uvicorn
dispatched the POST through Starlette and into the in-memory cache, the
daemon's addon had already resolved ``unattributed`` and moved on.

The fix is structural — write the attribution **synchronously** to the
same SQLite file the daemon already uses (``~/.halton-meter/db.sqlite``)
**before** the edge forwards the CONNECT bytes upstream. SQLite WAL
mode handles cross-process reader/writer concurrency natively, so the
edge can write while the daemon reads from the same file with no
locking surprise. ``BEGIN IMMEDIATE`` takes the writer lock, the INSERT
OR REPLACE commits in well under a millisecond on local SSD, and the
daemon's ``request()`` hook (which runs only after the bytes the edge
forwards arrive) is guaranteed to see the row.

The cardinal rule still holds: every code path here is wrapped so that
attribution failures NEVER block the proxy hot path. Failed reads
return ``None`` (the tagger then falls through to its legacy psutil
chain → ``"unattributed"``); failed writes are logged and we proceed
(the daemon will see ``unattributed`` for that one connection, the
explicit safe-default the cardinal rule demands).

DESIGN
------

A thin module — five functions, one module-level singleton path.

* ``set_db_path(path)`` — wire the singleton to a SQLite file. Called
  once from the daemon CLI (``_run_daemon``) and from the edge entry
  point. Tests use it with a ``tmp_path`` value.
* ``get_db_path()`` — read the current singleton (None until set).
* ``write(edge_src_port, project_name)`` — synchronous INSERT OR
  REPLACE under ``BEGIN IMMEDIATE``. Hot path. Target < 5 ms p99 on
  local SSD.
* ``lookup(edge_src_port, max_age_s=300.0)`` — SELECT WHERE port AND
  not stale. Returns ``str | None``.
* ``evict_stale(max_age_s=300.0)`` — DELETE old rows. Called
  opportunistically from ``write`` (1 in 50 writes via a counter) so
  the table never grows unbounded.

No L1 in-memory cache, no dataclass, no class wrapping a connection.
Each call opens a fresh ``sqlite3.connect``, runs its statement, and
closes. SQLite's open is sub-millisecond once the WAL pager warms; the
simplicity of one-shot connections is worth the negligible overhead
and removes every connection-affinity hazard from the threading model.

ATTRIBUTION_METHOD ENUM (canonical value list)
----------------------------------------------

The ``requests.attribution_method`` column on
``halton_meter.storage.models.request.RequestRecord`` is the canonical
home for which tier resolved a given row. The value space is:

    edge_store              Tier 0 — this module's row hit on the
                            ``attribution_log`` table.
    env                     Tier 1 — ``HALTON_PROJECT`` env var.
    rcfile                  Tier 2 — ``.haltonrc`` walked from cwd.
    workdir / ide_sniff     Tier 3 — IDE workspace-flag sniff (path-
                            bearing, self-corroborating).
    git                     Tier 4a — git repo basename.
    container               Tier 6 — k8s / Docker container.
    mac_sandbox             Tier 6.5 — macOS sandbox bundle id.
    process_heuristics      Tier 7.5 — daemon-only, config-driven.
    smart_default           Tier 8 — fallthrough; production tripwire
                            (WARN-level).

    -- v0.2.4 additions (memory/decisions.md 2026-05-18 "v0.2.4 unified
    -- attribution resolver"). Cloud-side Alembic migration required
    -- before any daemon ships these values to the sync endpoint.

    ide_env_label           Tier 4b — ``CURSOR_WORKSPACE_LABEL`` /
                            ``VSCODE_WORKSPACE_LABEL`` env var,
                            strict-slug corroborated against the
                            per-edge registry.
    ide_argv_label          Tier 4c — Electron-helper trailing-token
                            argv label, strict-slug corroborated.
    parent_rcfile           Tier 5 — bounded parent walk; ancestor's
                            ``.haltonrc`` matched.
    parent_git              Tier 5 — ancestor's git repo basename.
    parent_ide_sniff        Tier 5 — ancestor's IDE workspace-flag
                            argv sniff.
    parent_ide_env_label    Tier 5 — ancestor's env label, strict-slug
                            corroborated.
    parent_ide_argv_label   Tier 5 — ancestor's argv label, strict-slug
                            corroborated.

The column on the daemon side is ``String(32)``; the longest new
value (``parent_ide_argv_label``) is 21 chars so no schema migration
is required. Cloud-side ENUM type must be widened ahead of any
v0.2.4 daemon shipping rows with the new values.

WAL MODE NOTE
-------------

The daemon's storage layer (``halton_meter.storage.engine``) opens
the SQLite file under WAL mode at daemon startup. WAL is sticky — set
once on the file, persisted in the header. We do NOT re-execute
``PRAGMA journal_mode = WAL`` here for two reasons:

1. The daemon owns that pragma; we should not race it.
2. ``journal_mode = WAL`` is a no-op when WAL is already set, but
   spurious to run on the hot path.

We DO set ``busy_timeout`` so the writer doesn't return SQLITE_BUSY
on a transient lock collision with the daemon's other writers
(retag, recompute_costs, ingest). 5 s mirrors the rest of the daemon's
direct-sqlite3 callers.
"""

from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


# Default max age for both lookup and eviction. Five minutes is generous
# vs. observed multi-turn LLM session lengths (longest captured: ~4 m
# 12 s) and far longer than the OS-level TIME_WAIT for a closed
# ephemeral port (~30 s on Linux/macOS), so a stale row cannot
# misattribute a fresh connection on a reused port.
DEFAULT_MAX_AGE_SECONDS = 300.0

# SQLite busy_timeout in milliseconds — same as the rest of the
# daemon's direct sqlite3 callers (retag.py, recompute_costs.py).
_BUSY_TIMEOUT_MS = 5000

# Schema. ``edge_src_port`` is PRIMARY KEY so an INSERT OR REPLACE is
# a single UPSERT — port reuse simply overwrites. ``created_at`` is a
# wall-clock REAL (epoch seconds); wall-clock is correct here because
# the edge and the daemon are separate processes that share state via
# the disk file, and monotonic clocks are not comparable across
# processes.
#
# ``body_capture_enabled`` (added 2026-05-02 for B1) carries the
# rcfile-side ``body_capture`` flag from the edge to the daemon's
# ``BodyCaptureCache`` so per-project opt-out via ``.haltonrc`` works
# without a ``project_settings`` row. Default 1 (TRUE) matches the
# master-on default — when the rcfile is absent or doesn't set the
# flag, body capture is on. The daemon migration in storage/repo.py
# adds this column to existing DBs (PRAGMA user_version 2 → 3); the
# CREATE here covers greenfield-from-edge-first paths (the edge
# process can run before the daemon has ever created the file).
_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS attribution_log (
    edge_src_port INTEGER PRIMARY KEY,
    project_name TEXT NOT NULL,
    created_at REAL NOT NULL,
    body_capture_enabled BOOLEAN NOT NULL DEFAULT 1,
    source_workdir TEXT
);
CREATE INDEX IF NOT EXISTS idx_attribution_log_created_at
    ON attribution_log(created_at);
"""

# Migration SQL: add ``source_workdir`` to existing attribution_log tables
# that were created before this column was added. The column is nullable so
# old rows are unaffected; the ALTER TABLE is idempotent on fresh DBs because
# ``_open_connection`` guards the schema bootstrap.
_MIGRATION_ADD_SOURCE_WORKDIR = (
    "ALTER TABLE attribution_log ADD COLUMN source_workdir TEXT"
)

# Opportunistic eviction cadence — 1 in N writes triggers an
# evict_stale call. Keeps the table bounded without spawning a
# dedicated background task; for a single developer the row count
# stays in the low hundreds even at peak. The daemon also runs an
# explicit prune loop (cli._run_daemon) so this is belt-and-braces.
_EVICT_EVERY_N_WRITES = 50


# ---------------------------------------------------------------------------
# Module-level singleton state
#
# A single SQLite path applies to the whole process. The daemon's CLI
# wires it; the edge entry point wires it. Tests inject a tmp_path via
# ``set_db_path``. Reads from these globals are guarded by ``_LOCK``
# even though Python's GIL would technically make naive reads safe —
# the lock makes the contract explicit and survives any future
# free-threaded build.
# ---------------------------------------------------------------------------

_LOCK = threading.Lock()
_DB_PATH: Path | None = None
_SCHEMA_INITIALISED: bool = False
_WRITE_COUNTER: int = 0


def set_db_path(path: Path | str | None) -> None:
    """Register the SQLite file the singleton operates against.

    Called from ``cli._run_daemon`` (daemon process) and from the edge
    process's entry point. Setting to ``None`` resets the singleton so
    a stale instance cannot leak between test runs.

    Re-setting to a different path resets the schema-initialised flag
    so the next write/lookup re-bootstraps the schema on the new file.
    """
    global _DB_PATH, _SCHEMA_INITIALISED, _WRITE_COUNTER
    with _LOCK:
        new_path = Path(path).expanduser() if path is not None else None
        if new_path != _DB_PATH:
            _SCHEMA_INITIALISED = False
            _WRITE_COUNTER = 0
        _DB_PATH = new_path


def get_db_path() -> Path | None:
    """Return the current singleton path, or None if unset."""
    with _LOCK:
        return _DB_PATH


def _open_connection() -> sqlite3.Connection | None:
    """Open a one-shot SQLite connection or return None if not wired.

    The parent directory is created if missing — the edge process may
    run before the daemon has ever materialised ``~/.halton-meter/``
    on a fresh install, and we still want the write to succeed.

    The schema is bootstrapped lazily on first connection; the flag
    is process-local so a single ``CREATE TABLE IF NOT EXISTS`` runs
    per process even though the DDL itself is idempotent.
    """
    global _SCHEMA_INITIALISED
    with _LOCK:
        path = _DB_PATH
    if path is None:
        return None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(path), timeout=5.0)
        conn.execute(f"PRAGMA busy_timeout = {_BUSY_TIMEOUT_MS}")
    except (sqlite3.Error, OSError) as exc:
        log.warning("attribution.store_open_failed", error=str(exc))
        return None
    # Schema bootstrap. Idempotent; flag-guard prevents repeated DDL.
    # Hold the lock across the check-and-set to prevent two threads
    # from concurrently running the migration on startup.
    with _LOCK:
        already = _SCHEMA_INITIALISED
        if not already:
            _SCHEMA_INITIALISED = True  # claim the slot; we do the work below
    if not already:
        try:
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
        except sqlite3.Error as exc:
            log.warning("attribution.store_schema_failed", error=str(exc))
            try:
                conn.close()
            except sqlite3.Error:
                pass
            return None
        # Migration guard: add source_workdir column to existing DBs that
        # were created before this column was introduced. The column is
        # nullable so old rows are unaffected. We catch the "duplicate column
        # name" OperationalError silently (idempotent on fresh DBs); any
        # other sqlite3.Error is logged as a warning and we continue — the
        # hot path must never fail because a migration attempt failed.
        try:
            conn.execute(_MIGRATION_ADD_SOURCE_WORKDIR)
            conn.commit()
        except sqlite3.OperationalError as exc:
            # "duplicate column name: source_workdir" — expected on fresh DBs
            # and on any DB that already has the column. Anything else is
            # unexpected but non-fatal.
            if "duplicate column" not in str(exc).lower():
                log.warning(
                    "attribution.store_migration_warning",
                    migration="add_source_workdir",
                    error=str(exc),
                )
        except sqlite3.Error as exc:
            log.warning(
                "attribution.store_migration_warning",
                migration="add_source_workdir",
                error=str(exc),
            )
    return conn


def write(
    edge_src_port: int,
    project_name: str,
    body_capture_enabled: bool = True,
    *,
    source_workdir: str | None = None,
) -> None:
    """Record an attribution decision. Hot path; never raises.

    Synchronous on purpose: the edge MUST block on this call before
    forwarding the CONNECT to the daemon, otherwise the addon's
    ``request()`` hook will race ahead of the write and resolve
    ``unattributed``. The whole call completes well under a millisecond
    on local SSD under WAL.

    ``body_capture_enabled`` carries the rcfile-side opt-out (default
    True = master-on default). B1 plumbs the flag here; B2 wires
    ``BodyCaptureCache`` to read it as a per-project override fallback.

    ``source_workdir`` is the originating process's cwd as resolved at
    edge time (v0.2.10 — previously always None on cache hits because
    the column didn't exist). Keyword-only, optional, defaults to None.

    Failures (sqlite3 error, lock timeout, anything) are logged and
    swallowed. The caller does not branch on the outcome — chained
    traffic still flows; the daemon will see ``unattributed`` for this
    one connection, which is the cardinal-rule-correct fail-open
    behaviour.

    Opportunistically evicts stale rows on every Nth write so the
    table never grows unbounded. The eviction is best-effort: if it
    fails, the next prune cycle (or the next write's eviction tick)
    will catch up.
    """
    global _WRITE_COUNTER
    conn = _open_connection()
    if conn is None:
        return
    port = int(edge_src_port)
    name = str(project_name)
    bce = 1 if body_capture_enabled else 0
    workdir = str(source_workdir) if source_workdir is not None else None
    now = time.time()
    try:
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                "INSERT INTO attribution_log "
                "(edge_src_port, project_name, created_at, body_capture_enabled, source_workdir) "
                "VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT(edge_src_port) DO UPDATE SET "
                "project_name = excluded.project_name, "
                "created_at = excluded.created_at, "
                "body_capture_enabled = excluded.body_capture_enabled, "
                "source_workdir = excluded.source_workdir",
                (port, name, now, bce, workdir),
            )
            conn.commit()
        except sqlite3.Error as exc:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
            log.warning(
                "attribution.store_write_failed",
                edge_src_port=port,
                error=str(exc),
            )
            return
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass

    # Opportunistic eviction. Tick the counter under the lock; when it
    # rolls over the threshold, run an evict_stale on a fresh
    # connection. Failures are logged and swallowed inside the
    # function — they cannot affect the just-completed write.
    with _LOCK:
        _WRITE_COUNTER += 1
        should_evict = (_WRITE_COUNTER % _EVICT_EVERY_N_WRITES) == 0
    if should_evict:
        evict_stale()


def lookup(
    edge_src_port: int, max_age_s: float = DEFAULT_MAX_AGE_SECONDS
) -> tuple[str, str | None] | None:
    """Look up the project name and source workdir for an edge source port.

    Returns ``(project_name, source_workdir)`` on hit (row exists in the
    ``attribution_log`` table), ``None`` on miss / any error. The
    ``source_workdir`` field is ``None`` when not set (e.g. env-var path,
    or rows written before v0.2.10). Never raises — the tagger falls
    through to its legacy psutil chain on None, which is the
    cardinal-rule-correct fail-open path.

    **Read-side TTL removed in v0.2.3 (decisions.md 2026-05-18).**
    Pre-v0.2.3 this method filtered by ``AND created_at >= ?`` against
    a 5-minute cutoff. Claude Code holds CONNECT tunnels open for
    hours during a single coding session; once 5 minutes elapsed the
    edge-store row was effectively invisible to the daemon and
    requests fell through every attribution layer onto the
    ``smart_default`` fallthrough, producing 2,193 mis-attributed
    rows in the operator's live DB. Long-lived TCP sockets must stay
    attributed for the life of the connection.

    The ``max_age_s`` parameter is retained for backwards-compat
    (callers may still pass it; tests do) but is **ignored on the
    read path**. The write-side opportunistic eviction loop and the
    explicit prune loop in ``cli._run_daemon`` continue to bound the
    table's on-disk footprint at ``DEFAULT_MAX_AGE_SECONDS``; that
    side of the TTL was never the bug.
    """
    # max_age_s is intentionally unused — see docstring.
    del max_age_s
    conn = _open_connection()
    if conn is None:
        return None
    port = int(edge_src_port)
    try:
        try:
            row = conn.execute(
                "SELECT project_name, source_workdir FROM attribution_log "
                "WHERE edge_src_port = ?",
                (port,),
            ).fetchone()
        except sqlite3.Error as exc:
            log.debug(
                "attribution.store_read_failed",
                edge_src_port=port,
                error=str(exc),
            )
            return None
        if row is None:
            return None
        project_name = str(row[0])
        source_workdir = str(row[1]) if row[1] is not None else None
        return (project_name, source_workdir)
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass


def evict_stale(max_age_s: float = DEFAULT_MAX_AGE_SECONDS) -> int:
    """Delete rows older than ``max_age_s``. Returns rows deleted.

    Idempotent. Called opportunistically from ``write`` and explicitly
    from the daemon's prune loop in ``cli._run_daemon``. Failures are
    logged and return 0; the next call retries.
    """
    conn = _open_connection()
    if conn is None:
        return 0
    cutoff = time.time() - float(max_age_s)
    try:
        try:
            conn.execute("BEGIN IMMEDIATE")
            cur = conn.execute(
                "DELETE FROM attribution_log WHERE created_at < ?",
                (cutoff,),
            )
            deleted = int(cur.rowcount or 0)
            conn.commit()
            return deleted
        except sqlite3.Error as exc:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
            log.debug("attribution.store_evict_failed", error=str(exc))
            return 0
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass


def _size() -> int:
    """Return the current row count. Test helper; not part of the
    contract.
    """
    conn = _open_connection()
    if conn is None:
        return 0
    try:
        try:
            row = conn.execute(
                "SELECT COUNT(*) FROM attribution_log"
            ).fetchone()
            return int(row[0] or 0) if row else 0
        except sqlite3.Error:
            return 0
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass


def _clear() -> None:
    """Delete every row. Test helper; not part of the contract.

    Also resets the write counter so eviction-cadence tests are
    deterministic across runs.
    """
    global _WRITE_COUNTER
    conn = _open_connection()
    if conn is None:
        return
    try:
        try:
            conn.execute("DELETE FROM attribution_log")
            conn.commit()
        except sqlite3.Error:
            pass
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass
    with _LOCK:
        _WRITE_COUNTER = 0
