"""CLI runtime helpers — process-wide setup for user-facing Click commands.

The single public entry point :func:`configure_for_user_cli` MUST be called
as the first line of every user-facing Click command callback (``init``,
``start``, ``stop``, ``status``, ``uninstall``, ``setup``, ``rescue``,
``reset-proxy``, ``doctor``, ``onboard``, ``report``, ``retag``,
``recompute-costs``, ``version``, plus subcommands of ``bodies`` /
``project``).

It MUST NOT be called from the long-running daemon-process commands
(``daemon``, ``edge``, ``watchdog``, ``install``, ``_apply-user-env``,
``run``) — those processes need full structured logging to disk via
:func:`halton_meter.cli._configure_daemon_logging` and ship their stderr
to dedicated err-log files.

Why this exists
---------------
``structlog``'s default ``PrintLoggerFactory`` writes INFO and WARNING
events to **stdout**, which dumps lines like
``2026-05-06 23:51:50 [info     ] launchctl.bootstrap_attempt ...`` into
the user's terminal during ``init`` and ``start``. Every module that
imports ``structlog`` and calls ``log.info(...)`` mid-command leaks.

This helper reconfigures structlog process-wide so:
- INFO and DEBUG drop entirely (filtering bound logger at WARNING)
- WARNING+ surface on **stderr**, not stdout — so piped CLI output
  stays clean and user-facing reports remain machine-readable.

Set ``HALTON_DEBUG=1`` to opt back into full DEBUG output (also routed
to stderr) for development.

Idempotent: safe to call multiple times. Only the first call wins per
process unless ``HALTON_DEBUG`` flips.
"""

from __future__ import annotations

import os
import sys

_CONFIGURED = False


def configure_for_user_cli() -> None:
    """Silence structlog noise for short-lived user-facing CLI commands.

    See module docstring. Call as the first line of every user-facing
    Click command callback. Never call from the long-running daemon
    process commands.
    """
    global _CONFIGURED
    if _CONFIGURED:
        return

    import logging

    import structlog

    debug = os.environ.get("HALTON_DEBUG", "").strip() not in ("", "0", "false", "False")
    level = logging.DEBUG if debug else logging.WARNING

    structlog.configure(
        wrapper_class=structlog.make_filtering_bound_logger(level),
        # Route surviving events to stderr so piped stdout stays clean.
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )
    _CONFIGURED = True
