"""Auto-port-fallback (v0.1.3 P0-5; v0.1.6 2C.2 split).

The daemon can collide with another local service on its default ports.
v0.1.0/0.1.1 crashed on bind; v0.1.2's preflight refused to start; v0.1.3
auto-allocates the first free port in a small window when the user has
NOT explicitly pinned a port in ``~/.halton-meter/config.toml``.

**v0.1.6 (2C.2)** splits the user-facing proxy port from the metering
daemon's mitmproxy listener:

* ``edge_port`` (default 8081, probe range 8081..8089) — owned by the
  edge proxy. This is what apps see in ``HTTPS_PROXY``.
* ``internal_port`` (default 8090, probe range 8090..8099) — owned by
  the daemon's mitmproxy listener. Loopback-only, never advertised.
* ``api_port`` (unchanged: default 8765, probe range 8765..8774) —
  FastAPI HTTP API.

**Legacy compatibility:** v0.1.5 and earlier wrote/read ``listen_port``
in both ``config.toml`` and ``runtime.toml``. Per the ratified plan
(§12.2): legacy ``listen_port`` always means ``edge_port`` — the user's
contract was "the port my apps see", and that port did not move. The
loaders translate the legacy key transparently:

* ``runtime.toml`` is daemon-managed: the next ``_write_runtime_toml``
  call rewrites the file with the canonical ``edge_port`` /
  ``internal_port`` keys (atomic, fsynced).
* ``config.toml`` is user-owned: legacy ``listen_port`` is honoured with
  a structlog deprecation warning. **We do not auto-rewrite the user's
  file.**

**Collision-aware internal probe (plan §8 Risk 4):** if the user pinned
``edge_port`` somewhere in 8090..8099 (the default internal range), the
internal probe range shifts to start at ``edge_port + 10`` so we don't
self-collide.

Stable identity contract: if the user pins a port in ``config.toml``
AND that port is unavailable, the daemon will fail-fast with a clear
error. We do NOT silently relocate a pinned port — that would break
the user's mental model and any external clients pointing at it.
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import tomllib
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

import structlog

from halton_meter.config import HaltonConfig

log = structlog.get_logger(__name__)

# v0.1.22.5: launchd label of our edge process. Hardcoded here (rather
# than imported from ``halton_meter.install._macos``) to avoid creating
# an import cycle — ``install`` and ``lifecycle`` both depend on
# ``port_alloc``. The string MUST stay in sync with
# ``install._macos._EDGE_LABEL``; covered by
# ``test_managed_edge_label_matches_install`` in
# ``daemon/tests/test_lifecycle.py``.
_MANAGED_EDGE_LAUNCHD_LABEL = "com.haltonlabs.meter.edge"

# v0.1.22.9: daemon launchd label (mitm proxy listener + FastAPI HTTP API
# both bound by the same process under this label). Hardcoded to mirror
# ``install._macos._LABEL`` per the same import-cycle constraint
# documented above. Used by the status panel's ground-truth port lookup
# (Bug 2) to read the actually-bound mitm + api ports from the live
# managed daemon process when ``effective-ports.json`` is missing or
# stale. Covered by ``test_managed_daemon_label_matches_install`` in
# ``daemon/tests/test_port_alloc.py``.
_MANAGED_DAEMON_LAUNCHD_LABEL = "com.haltonlabs.meter"

# Ports we are willing to probe when the default is busy.
# v0.1.4 (2B.15) P0-5: exposed publicly so status / doctor / init can
# compare the effective port to the default and surface a fallback hint
# without duplicating the constant.
# v0.1.6 (2C.2): the user-facing proxy port moved from 8080 to 8081 (the
# edge owns it now), and a new internal_port (8090) hosts the daemon's
# mitmproxy listener.
EDGE_PORT_DEFAULT = 8081
INTERNAL_PORT_DEFAULT = 8090
API_PORT_DEFAULT = 8765
# v0.1.5 back-compat alias — the value moved with the rename. Callers
# that imported ``LISTEN_PORT_DEFAULT`` see the v0.1.6 user-facing port.
LISTEN_PORT_DEFAULT = EDGE_PORT_DEFAULT
# Private aliases preserved for back-compat with the v0.1.3 module
# internals.
_EDGE_PORT_DEFAULT = EDGE_PORT_DEFAULT
_EDGE_PORT_PROBE_RANGE = 9  # 8081..8089 inclusive (9 ports — 8090 starts internal)
_INTERNAL_PORT_DEFAULT = INTERNAL_PORT_DEFAULT
_INTERNAL_PORT_PROBE_RANGE = 10  # 8090..8099 inclusive (10 ports)
_API_PORT_DEFAULT = API_PORT_DEFAULT
_API_PORT_PROBE_RANGE = 10  # 8765..8774 inclusive (10 ports)

RUNTIME_TOML_PATH = Path("~/.halton-meter/runtime.toml").expanduser()
CONFIG_TOML_PATH = Path("~/.halton-meter/config.toml").expanduser()

# v0.1.7 Gap 0: edge-process sidecar with the chain target the running edge
# is currently bound to. Written by the edge process at startup and on every
# successful re-resolve; read by `halton-meter status` and `halton-meter
# doctor` to detect the stale-chain INCONSISTENT case introduced by the
# port-fallback race documented in
# memory/plans/2026-05-01-edge-passthrough-lockin-bug.md.
EDGE_STATE_TOML_PATH = Path("~/.halton-meter/edge-state.toml").expanduser()

# v0.1.19.dev1: shared kernel-confirmed effective port-state file. Written
# by the daemon on every successful bind (after ``asyncio.start_server`` /
# uvicorn ``startup.complete`` returns the actually-bound ports), read by
# every other component that needs to know which ports the daemon is on
# right now: edge (chain target re-resolve), watchdog (`/health` probe),
# `_apply-user-env` (HTTPS_PROXY value), status, doctor.
#
# Existence and freshness contract:
#
# * The file is written ATOMICALLY by ``write_effective_ports`` after
#   the daemon binds; partial writes are never observable.
# * The PID embedded in the file is the writer's PID. Readers may treat
#   the file as stale when ``psutil`` (or ``os.kill(pid, 0)``) reports
#   the PID dead — the daemon's launchd plist cleans up via SIGKILL
#   sometimes, so a leftover file with a dead PID is the normal
#   crash-and-restart shape.
# * Schema is versioned (``schema_version: 1``). Forward-compat readers
#   tolerate unknown extra keys; older readers see fields they
#   recognise and ignore the rest.
#
# Fallback chain on read: effective-ports.json -> runtime.toml ->
# defaults. The legacy ``runtime.toml`` continues to be written for
# back-compat with v0.1.18-and-earlier readers; it is no longer the
# authoritative source for v0.1.19+ readers.
EFFECTIVE_PORTS_JSON_PATH = Path("~/.halton-meter/effective-ports.json").expanduser()
_EFFECTIVE_PORTS_SCHEMA_VERSION = 1


def _is_port_free(host: str, port: int) -> bool:
    """Return True iff a TCP listener bind on (host, port) succeeds.

    The probe binds and closes immediately. SO_REUSEADDR is set so the
    probe matches the bind semantics of mitmproxy's actual listener
    (``asyncio.start_server`` defaults to ``reuse_address=True`` on
    Unix).

    v0.1.22.7 (BUG FIX): Without SO_REUSEADDR, this probe was
    falsely reporting busy when only TIME_WAIT residue remained on
    the port — the previous-generation daemon had been SIGTERM-ed but
    its ESTABLISHED clients lingered in TIME_WAIT for the macOS
    default window (~15s + n*RTT). mitmproxy's real listener would
    have bound just fine via asyncio's reuse_address default; the
    probe lied, so ``allocate_ports`` walked to the next candidate
    (:8091) and stamped ``runtime.toml`` / ``effective-ports.json``
    with the drifted port. Setting SO_REUSEADDR here aligns the probe
    with reality.

    A foreign LISTEN socket on the port still surfaces as busy:
    SO_REUSEADDR only relaxes TIME_WAIT residue; two LISTEN sockets
    on the same (host, port) still EADDRINUSE.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    except OSError:
        # Defensive: should never fail on macOS/Linux/Windows for an
        # AF_INET TCP socket. If it does, fall through and the bind
        # observes whatever the kernel says.
        pass
    try:
        sock.bind((host, port))
    except OSError:
        return False
    finally:
        sock.close()
    return True


def _macos_lsof_listen_pids(port: int) -> list[int]:
    """Return PIDs LISTENING on ``port`` (TCP, LISTEN state) on macOS.

    v0.1.22.5: duplicated (intentionally) from
    ``lifecycle._macos._lsof_listen_pids_on_port`` because ``port_alloc``
    cannot import ``lifecycle`` (cycle: lifecycle imports port_alloc).
    Same lsof argv shape — single combined ``-iTCP:<port>`` selector
    plus ``-sTCP:LISTEN`` — see the lifecycle helper's docstring for
    the v0.1.22.3 OR-semantics regression that motivated that argv
    shape. Empty list when nothing is listening or lsof is unavailable.
    """
    if sys.platform != "darwin":
        return []
    try:
        result = subprocess.run(
            ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if result.returncode not in (0, 1):
        return []
    pids: list[int] = []
    for tok in result.stdout.split():
        try:
            pids.append(int(tok.strip()))
        except ValueError:
            continue
    return pids


def _macos_launchctl_label_pid(label: str) -> int | None:
    """Return the PID launchctl reports for ``label``, or None.

    v0.1.22.5: minimal port of
    ``lifecycle._macos._launchctl_label_pid`` for use inside
    ``port_alloc`` (cycle-avoiding). Defensive: never raises.
    """
    if sys.platform != "darwin":
        return None
    try:
        uid = os.getuid()
    except AttributeError:
        return None
    try:
        result = subprocess.run(
            ["launchctl", "print", f"gui/{uid}/{label}"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if stripped.startswith("pid ="):
            tail = stripped.split("=", 1)[1].strip()
            try:
                return int(tail)
            except ValueError:
                return None
    return None


def _macos_lsof_listen_ports_for_pid(pid: int) -> list[int]:
    """Return TCP LISTEN ports the given PID is bound to on macOS.

    v0.1.22.6: the dual of ``_macos_lsof_listen_pids`` (which goes
    port -> PIDs); this helper goes PID -> ports. Used by
    ``_managed_edge_listening_port`` so the daemon's startup write of
    ``effective-ports.json`` can seed ``edge_port`` from the actually-
    bound port of the always-on managed edge process — without that, a
    ``stop && start`` cycle in which the edge survives leaves the JSON
    advertising ``edge_port=null`` even though the edge is healthily
    LISTENing on (typically) :8081.

    Output format from ``lsof -nP -iTCP -sTCP:LISTEN -p <pid>``:

        halton-me 3810 user 7u IPv4 0x... 0t0 TCP 127.0.0.1:8081 (LISTEN)

    Column 9 is the local address; the port follows the final colon
    (handles IPv6 ``[::1]:8081`` too). Returns an empty list when lsof
    is unavailable, the PID has no LISTEN sockets, or any line fails
    to parse — defensive: never raises.
    """
    if sys.platform != "darwin":
        return []
    try:
        result = subprocess.run(
            ["lsof", "-nP", "-iTCP", "-sTCP:LISTEN", "-p", str(int(pid))],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if result.returncode not in (0, 1):
        return []
    ports: list[int] = []
    for raw_line in result.stdout.splitlines():
        # Skip the header line ("COMMAND PID USER FD ...").
        if raw_line.startswith("COMMAND"):
            continue
        cols = raw_line.split()
        if len(cols) < 9:
            continue
        addr = cols[8]
        # Strip a trailing "(LISTEN)" if lsof variants emit it on the
        # same column (it's normally the 10th column on macOS, but be
        # tolerant).
        if "(" in addr:
            addr = addr.split("(", 1)[0]
        # Take the substring after the final colon — works for both
        # ``127.0.0.1:8081`` and ``[::1]:8081`` and ``*:8081``.
        if ":" not in addr:
            continue
        tail = addr.rsplit(":", 1)[1]
        try:
            ports.append(int(tail))
        except ValueError:
            continue
    return ports


def _managed_label_listening_port(
    label: str, *, prefer_range: range | None = None
) -> int | None:
    """Return a TCP LISTEN port the launchctl-managed ``label`` process is bound to.

    v0.1.22.9: generalised lift of the v0.1.22.6
    ``_managed_edge_listening_port`` helper. Same primitive composition:

    1. ``_macos_launchctl_label_pid(label)`` resolves the PID;
    2. ``_macos_lsof_listen_ports_for_pid(pid)`` lists the LISTEN ports
       that PID owns.

    When ``prefer_range`` is given, a port within that range is
    preferred over any other reported port (handy for the edge probe
    range). Otherwise the first reported port is returned.

    Used by the status panel (Bug 2 ground-truth port lookup) so the
    panel reports the actually-bound port rather than the configured
    default when ``effective-ports.json`` is stale or missing.

    Returns:
        The bound port when the labelled process is alive and
        LISTENing, else None. None on non-macOS.

    Note: the daemon process binds two ports (mitm + api). Callers
    that need to disambiguate must apply their own filter — passing
    ``prefer_range`` covering only the expected port range is the
    intended mechanism.
    """
    if sys.platform != "darwin":
        return None
    pid = _macos_launchctl_label_pid(label)
    if pid is None:
        return None
    ports = _macos_lsof_listen_ports_for_pid(pid)
    if not ports:
        return None
    if prefer_range is not None:
        for port in ports:
            if port in prefer_range:
                return port
    return ports[0]


def _managed_label_listening_ports(label: str) -> list[int]:
    """Return all TCP LISTEN ports the managed ``label`` process is bound to.

    v0.1.22.9: companion to ``_managed_label_listening_port`` for the
    daemon (which binds both mitm + api ports under the same launchd
    label). Returns an empty list when the label is unknown / dead /
    has no LISTEN sockets / on non-macOS.
    """
    if sys.platform != "darwin":
        return []
    pid = _macos_launchctl_label_pid(label)
    if pid is None:
        return []
    return list(_macos_lsof_listen_ports_for_pid(pid))


def _managed_edge_listening_port() -> int | None:
    """Return the TCP LISTEN port the managed edge process is bound to.

    v0.1.22.6: returns the actually-bound port of the always-on managed
    edge so the daemon's startup write of ``effective-ports.json`` can
    reflect ground truth.

    v0.1.22.9: thin wrapper over ``_managed_label_listening_port`` —
    the prior implementation lifted to a generic helper. Behaviour
    preserved verbatim for back-compat with the v0.1.22.6 test suite.
    """
    edge_range = range(
        _EDGE_PORT_DEFAULT, _EDGE_PORT_DEFAULT + _EDGE_PORT_PROBE_RANGE
    )
    return _managed_label_listening_port(
        _MANAGED_EDGE_LAUNCHD_LABEL, prefer_range=edge_range
    )


def _resolve_managed_daemon_mitm_port() -> int | None:
    """Ground-truth mitm-listener port of the managed daemon process.

    v0.1.22.9 (Bug 2): the status panel previously trusted
    ``cfg.daemon.internal_port`` (which fell back to the default 8090
    when ``effective-ports.json`` was absent). This helper returns the
    actually-bound mitm port by reading the launchctl-managed daemon
    PID's LISTEN sockets. The daemon binds two ports under one label —
    mitm (default 8090) and api (default 8765); this helper picks the
    one that is NOT the api port.

    Returns the bound mitm port, or None when the daemon is not
    running, has no LISTEN sockets, has only one LISTEN socket
    matching the api port (i.e. mitm hasn't bound yet), or on
    non-macOS.

    Disambiguation strategy: prefer a port within
    ``_INTERNAL_PORT_DEFAULT..+_INTERNAL_PORT_PROBE_RANGE``; otherwise
    return the first port that is NOT in the api default range.
    """
    if sys.platform != "darwin":
        return None
    ports = _managed_label_listening_ports(_MANAGED_DAEMON_LAUNCHD_LABEL)
    if not ports:
        return None
    mitm_range = range(
        _INTERNAL_PORT_DEFAULT,
        _INTERNAL_PORT_DEFAULT + _INTERNAL_PORT_PROBE_RANGE,
    )
    for port in ports:
        if port in mitm_range:
            return port
    api_range = range(
        _API_PORT_DEFAULT, _API_PORT_DEFAULT + _API_PORT_PROBE_RANGE
    )
    # Fallback: any port that isn't in the api range is plausibly mitm.
    for port in ports:
        if port not in api_range:
            return port
    return None


def _resolve_managed_daemon_api_port() -> int | None:
    """Ground-truth FastAPI/HTTP-API port of the managed daemon process.

    v0.1.22.9 (Bug 2): companion to ``_resolve_managed_daemon_mitm_port``.
    Picks the port from the daemon's LISTEN set that lies within the
    api probe range; falls through to the second-most-likely candidate
    otherwise.
    """
    if sys.platform != "darwin":
        return None
    ports = _managed_label_listening_ports(_MANAGED_DAEMON_LAUNCHD_LABEL)
    if not ports:
        return None
    api_range = range(
        _API_PORT_DEFAULT, _API_PORT_DEFAULT + _API_PORT_PROBE_RANGE
    )
    for port in ports:
        if port in api_range:
            return port
    return None


def resolve_effective_port(
    *,
    role: str,
    cfg_value: int | None = None,
) -> int | None:
    """Three-step ground-truth port lookup for ``role``.

    v0.1.22.9 Bug 2: the status panel + doctor previously read
    ``cfg.daemon.<role>_port`` directly, which silently fell back to
    the configured default when ``effective-ports.json`` was missing
    or stale. This helper walks the priority chain so the panel
    reports what is actually bound:

    1. **lsof on the managed launchctl PID** (ground truth — what the
       kernel says is bound). Per role: edge label for ``edge``,
       daemon label + mitm/api disambiguation for ``mitm`` / ``api``.
    2. **``effective-ports.json``** (last-known-good kernel-confirmed
       state, written by the daemon at startup).
    3. **``cfg_value``** (the config / runtime.toml default — the
       legacy behaviour, kept as a final fallback).

    Args:
        role: one of ``"mitm"``, ``"api"``, ``"edge"``.
        cfg_value: the configured-default fallback. When None the
            chain returns None instead of guessing.

    Returns:
        The resolved port int, or None when nothing in the chain
        produced a value.
    """
    if role not in ("mitm", "api", "edge"):
        raise ValueError(
            f"unknown role: {role!r}; expected 'mitm' / 'api' / 'edge'"
        )

    # Step 1: lsof on the managed launchctl PID.
    if role == "mitm":
        live = _resolve_managed_daemon_mitm_port()
    elif role == "api":
        live = _resolve_managed_daemon_api_port()
    else:  # edge
        live = _managed_edge_listening_port()
    if live is not None:
        return live

    # Step 2: effective-ports.json.
    try:
        eff = read_effective_ports()
    except Exception:
        eff = {}
    if isinstance(eff, dict):
        key = {
            "mitm": "internal_port",
            "api": "api_port",
            "edge": "edge_port",
        }[role]
        candidate = eff.get(key)
        if isinstance(candidate, int) and candidate > 0:
            return candidate

    # Step 3: configured fallback.
    if cfg_value is not None:
        return int(cfg_value)
    return None


# v0.1.22.15: ground-truth retry + freshness-gated JSON fallback.
#
# The v0.1.22.14 ``halton-meter start`` user soak surfaced a temporal race:
# the post-kickstart panel called ``load_effective_config`` (which reads
# ``effective-ports.json``) before the new daemon process had overwritten
# the file. The JSON still held the previous generation's
# ``pid + api_port`` tuple, so the panel probed the wrong port and the
# v0.1.22.4 post-success liveness flipped a healthy daemon to red.
#
# This helper closes the race with two guarantees:
#
# 1. **Retry on lsof.** The launchctl-managed PID is the kernel-level
#    ground truth. We retry the lsof read up to ``retries`` times with
#    ``retry_delay_s`` backoff so the helper tolerates the bind not
#    having happened yet (kickstart returned in tens of ms; uvicorn may
#    take 1-3s to bind on a cold boot).
# 2. **Freshness-gated JSON.** When lsof yields nothing within the
#    retry window, we fall back to ``effective-ports.json`` ONLY when
#    the JSON's ``pid`` field equals the launchctl-reported PID for
#    ``freshness_label``. A mismatch means the JSON is from a previous
#    daemon generation; we treat it as missing.
#
# Default behaviour of ``resolve_effective_port`` is unchanged — this is
# an additive helper for the start / post-success-liveness / status /
# doctor surfaces that need to defeat the race.
_GROUND_TRUTH_DEFAULT_RETRIES = 8
_GROUND_TRUTH_DEFAULT_RETRY_DELAY_S = 0.25


def resolve_effective_port_ground_truth(
    *,
    role: str,
    cfg_value: int | None = None,
    retries: int = _GROUND_TRUTH_DEFAULT_RETRIES,
    retry_delay_s: float = _GROUND_TRUTH_DEFAULT_RETRY_DELAY_S,
    sleep: Callable[[float], None] | None = None,
) -> int | None:
    """Race-tolerant ground-truth port resolution for ``role``.

    v0.1.22.15: same priority chain as ``resolve_effective_port`` but
    with two additions designed to defeat the post-kickstart race:

    1. lsof on the managed launchctl PID is retried up to ``retries``
       times with ``retry_delay_s`` between attempts. Total bounded
       wait: ``retries * retry_delay_s`` seconds (default 8 × 0.25 =
       2.0s).
    2. ``effective-ports.json`` is consulted only after the freshness
       gate passes: the JSON's ``pid`` field must match the
       launchctl-reported PID for the role's daemon/edge label. A
       mismatch (or absent ``pid``) is treated as "stale; ignore JSON"
       and the helper proceeds to ``cfg_value``.

    Args:
        role: ``"mitm"`` / ``"api"`` / ``"edge"``.
        cfg_value: configured-default fallback (last resort).
        retries: number of lsof attempts.
        retry_delay_s: delay between lsof attempts.
        sleep: monkeypatch seam for tests.

    Returns:
        Resolved port int, or None when nothing in the chain produced
        a value.
    """
    if role not in ("mitm", "api", "edge"):
        raise ValueError(
            f"unknown role: {role!r}; expected 'mitm' / 'api' / 'edge'"
        )

    sleeper = sleep if sleep is not None else time.sleep

    # Step 1: retry-bounded lsof on the managed launchctl PID.
    for attempt in range(max(1, int(retries))):
        if role == "mitm":
            live = _resolve_managed_daemon_mitm_port()
        elif role == "api":
            live = _resolve_managed_daemon_api_port()
        else:  # edge
            live = _managed_edge_listening_port()
        if live is not None:
            return live
        # Don't sleep after the last attempt.
        if attempt < int(retries) - 1 and retry_delay_s > 0:
            try:
                sleeper(float(retry_delay_s))
            except Exception:  # pragma: no cover — defensive
                break

    # Step 2: freshness-gated effective-ports.json. The JSON's ``pid``
    # must equal the launchctl-reported PID of the appropriate label;
    # otherwise the file is from a previous generation and we treat
    # it as missing.
    try:
        eff = read_effective_ports()
    except Exception:
        eff = {}
    if isinstance(eff, dict) and eff:
        json_pid = eff.get("pid")
        # mitm / api are written by the daemon process. ``edge`` is
        # merged in by the edge process (which writes ``edge_pid``,
        # leaving the daemon's ``pid`` field intact). For ``edge`` the
        # historical writer puts the edge PID in a separate
        # ``edge_pid`` key (see ``merge_edge_port_into_effective_ports``);
        # fall back to comparing ``pid`` against the daemon label since
        # both writers preserve it.
        if role == "edge":
            edge_pid_in_json = eff.get("edge_pid")
            label_pid = _macos_launchctl_label_pid(_MANAGED_EDGE_LAUNCHD_LABEL)
            fresh = (
                isinstance(edge_pid_in_json, int)
                and label_pid is not None
                and edge_pid_in_json == label_pid
            )
        else:
            label_pid = _macos_launchctl_label_pid(
                _MANAGED_DAEMON_LAUNCHD_LABEL
            )
            fresh = (
                isinstance(json_pid, int)
                and label_pid is not None
                and json_pid == label_pid
            )
        if fresh:
            key = {
                "mitm": "internal_port",
                "api": "api_port",
                "edge": "edge_port",
            }[role]
            candidate = eff.get(key)
            if isinstance(candidate, int) and candidate > 0:
                return candidate

    # Step 3: configured fallback.
    if cfg_value is not None:
        return int(cfg_value)
    return None


def _managed_edge_holds_default_port(host: str, port: int) -> bool:
    """Return True iff our managed edge process is the LISTENing holder.

    v0.1.22.5 (B5): symmetric primitive to the v0.1.22.3 stop-side
    ``_our_managed_pids()`` filter. The bug the gate fixes: a healthy
    always-on edge (plist ``KeepAlive=True``) keeps :8081 bound across
    the ``stop && start`` cycle. ``_is_port_free(:8081)`` returns False
    because *we* hold it, and without this check ``allocate_ports``
    treats :8081 as "busy by a foreign process" and falls back to
    :8082 — corrupting ``runtime.toml`` and (transitively) the
    ``effective-ports.json`` view that apps reading ``HTTPS_PROXY``
    consult. Net result: traffic silently bypassed the meter on every
    rapid restart.

    Returns True iff:

    * we are on macOS, AND
    * a TCP LISTEN socket exists on ``host:port``, AND
    * the holder PID equals the launchctl-reported PID of the
      ``com.haltonlabs.meter.edge`` label.

    On Linux this is always False — Linux doesn't have lsof/launchctl
    in the same shape and the v0.1.22 line is macOS-perfect-first per
    ``CLAUDE.md``. The Linux edge-port reuse story will land alongside
    its own lifecycle work in v0.1.23+.

    v0.1.22.6: kept as a thin convenience wrapper. The historical
    ``allocate_ports`` call site only needs a yes/no answer for the
    *default* edge port; the new ``_managed_edge_listening_port``
    helper carries the broader signal. Both are tested independently.
    """
    if sys.platform != "darwin":
        return False
    holders = _macos_lsof_listen_pids(port)
    if not holders:
        return False
    edge_pid = _macos_launchctl_label_pid(_MANAGED_EDGE_LAUNCHD_LABEL)
    if edge_pid is None:
        return False
    return edge_pid in holders


def _probe_port(host: str, default_port: int, probe_range: int) -> int | None:
    """Probe ``default_port .. default_port + probe_range - 1``. Returns the
    first free port, or ``None`` if every candidate is busy."""
    for offset in range(probe_range):
        candidate = default_port + offset
        if _is_port_free(host, candidate):
            return candidate
    return None


def _legacy_warning_emitted() -> bool:
    """Track whether we've already logged the legacy deprecation warning
    in this process so we don't repeat ourselves on every read."""
    return bool(getattr(_legacy_warning_emitted, "_done", False))


def _mark_legacy_warning_emitted() -> None:
    _legacy_warning_emitted._done = True  # type: ignore[attr-defined]


def _reset_legacy_warning_state() -> None:
    """Test seam: clear the once-per-process latch."""
    if hasattr(_legacy_warning_emitted, "_done"):
        delattr(_legacy_warning_emitted, "_done")


def _read_explicit_keys_from_config_toml(
    path: Path,
) -> tuple[bool, bool, bool]:
    """Inspect raw config.toml; return (edge_pinned, internal_pinned, api_pinned).

    A port is "pinned" when the user has written it explicitly under
    ``[daemon]``. Pydantic's defaults synthesise the same values into
    ``HaltonConfig`` regardless, so we can't tell from the model — we
    have to look at the raw TOML. v0.1.6 honours the legacy key
    ``listen_port`` as a synonym for ``edge_port`` (with a deprecation
    warning emitted by ``load_effective_config``).
    """
    if not path.exists():
        return False, False, False
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except (tomllib.TOMLDecodeError, OSError):
        return False, False, False
    daemon_tbl = raw.get("daemon", {}) or {}
    edge_pinned = ("edge_port" in daemon_tbl) or ("listen_port" in daemon_tbl)
    internal_pinned = "internal_port" in daemon_tbl
    api_pinned = "api_port" in daemon_tbl
    return edge_pinned, internal_pinned, api_pinned


def _read_runtime_toml(path: Path) -> dict[str, int]:
    """Return ``{"edge_port": ..., "internal_port": ..., "api_port": ...}``
    from runtime.toml, or an empty dict if the file is missing /
    unparseable. v0.1.6: legacy ``listen_port`` reads as ``edge_port``
    (silent — runtime.toml is daemon-managed and rewritten on next
    ``_write_runtime_toml`` call)."""
    if not path.exists():
        return {}
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except (tomllib.TOMLDecodeError, OSError):
        return {}
    daemon_tbl = raw.get("daemon", {}) or {}
    out: dict[str, int] = {}
    # Canonical keys.
    for key in ("edge_port", "internal_port", "api_port"):
        val = daemon_tbl.get(key)
        if isinstance(val, int):
            out[key] = val
    # Legacy `listen_port` -> `edge_port` (only when canonical key absent).
    if "edge_port" not in out:
        legacy = daemon_tbl.get("listen_port")
        if isinstance(legacy, int):
            out["edge_port"] = legacy
    return out


def _write_runtime_toml(
    path: Path,
    *,
    edge_port: int | None = None,
    internal_port: int | None = None,
    api_port: int,
    # v0.1.5 back-compat: callers passing legacy ``listen_port=`` still
    # work — it maps to ``edge_port``. Drop in v0.1.7.
    listen_port: int | None = None,
) -> None:
    """Atomically write ``runtime.toml`` with the chosen ports.

    Hand-rolled TOML — the file is tiny (one section, three int keys)
    so a full TOML emitter (tomli-w / tomlkit) would add a dependency we
    don't otherwise need. The format is human-readable and tomllib-
    parseable; covered by ``test_runtime_toml_round_trip``.

    v0.1.6 (2C.2): file gains an ``internal_port`` line. Legacy
    ``listen_port`` callers (v0.1.5 era tests) are silently mapped to
    ``edge_port`` for now to keep the test surface stable across the
    rename window; the on-disk file always uses the canonical keys.
    """
    # Resolve the v0.1.5 -> v0.1.6 alias.
    if edge_port is None:
        if listen_port is None:
            raise TypeError(
                "_write_runtime_toml requires either edge_port= or "
                "(legacy) listen_port="
            )
        edge_port = listen_port
    if internal_port is None:
        # On the back-compat path (legacy callers passing only
        # listen_port), fall back to the default internal port. The
        # next daemon startup with v0.1.6 logic will probe and persist
        # the right value.
        internal_port = _INTERNAL_PORT_DEFAULT

    path.parent.mkdir(parents=True, exist_ok=True)
    body = (
        "# Halton Meter — runtime-discovered port allocation (P0-5; v0.1.6 2C.2 split).\n"
        "# Written by the daemon at startup; do not edit by hand.\n"
        "# To pin a port, edit ~/.halton-meter/config.toml instead.\n"
        "\n"
        "[daemon]\n"
        f"edge_port = {int(edge_port)}\n"
        f"internal_port = {int(internal_port)}\n"
        f"api_port = {int(api_port)}\n"
    )
    # Atomic write with fsync — mirrors system_proxy._atomic_write_json.
    # Order: open with O_CREAT|O_TRUNC|O_WRONLY to a sibling .tmp file,
    # write the body bytes, fsync the fd so the bytes hit disk before we
    # rename, close, then os.replace over the canonical path. Crash-safe:
    # a partial write never appears at runtime.toml.
    tmp = path.with_suffix(".tmp")
    data = body.encode("utf-8")
    fd = os.open(str(tmp), os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(str(tmp), str(path))


def remove_runtime_toml(path: Path | None = None) -> None:
    """Remove ``runtime.toml``. Idempotent. Used by ``halton-meter
    uninstall``."""
    target = path or RUNTIME_TOML_PATH
    try:
        target.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def read_edge_state_toml(path: Path | None = None) -> dict[str, int]:
    """Return ``{"edge_port", "chain_port", "pid"}`` from the edge sidecar.

    Empty dict if the file is missing or unparseable. v0.1.7 Gap 0:
    written by the edge process so callers (status, doctor) can detect
    when the edge is chaining to a stale ``internal_port``.
    """
    target = path or EDGE_STATE_TOML_PATH
    if not target.exists():
        return {}
    try:
        with target.open("rb") as fh:
            raw = tomllib.load(fh)
    except (tomllib.TOMLDecodeError, OSError):
        return {}
    edge_tbl = raw.get("edge", {}) or {}
    out: dict[str, int] = {}
    for key in ("edge_port", "chain_port", "pid"):
        val = edge_tbl.get(key)
        if isinstance(val, int):
            out[key] = val
    return out


def write_edge_state_toml(
    path: Path | None,
    *,
    edge_port: int,
    chain_port: int,
    pid: int,
) -> None:
    """Atomically write the edge sidecar.

    v0.1.7 Gap 0: each successful (re)bind of the edge's chain target
    rewrites this file so doctor/status can compare against
    ``runtime.toml.internal_port`` and surface a stale-chain INCONSISTENT
    verdict. Same atomic pattern as ``_write_runtime_toml``.
    """
    target = path or EDGE_STATE_TOML_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    body = (
        "# Halton Meter — edge process sidecar (v0.1.7 Gap 0).\n"
        "# Written by halton-meter-edge at startup and on every chain-target\n"
        "# re-resolve. Diagnostic only; do not edit by hand.\n"
        "\n"
        "[edge]\n"
        f"edge_port = {int(edge_port)}\n"
        f"chain_port = {int(chain_port)}\n"
        f"pid = {int(pid)}\n"
    )
    tmp = target.with_suffix(target.suffix + ".tmp")
    data = body.encode("utf-8")
    fd = os.open(str(tmp), os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(str(tmp), str(target))


def remove_edge_state_toml(path: Path | None = None) -> None:
    """Remove the edge sidecar. Idempotent. Used by ``halton-meter
    uninstall`` and the edge process when shutting down cleanly."""
    target = path or EDGE_STATE_TOML_PATH
    try:
        target.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _atomic_write_json(path: Path, payload: dict) -> None:
    """Atomic JSON write — same recipe as ``system_proxy._atomic_write_json``.

    Duplicated here to keep ``port_alloc`` import-cheap (no system_proxy
    pull-in). The two helpers MUST stay shape-compatible. Crash-safe:
    a partial write never appears at the canonical path.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    data = json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
    fd = os.open(str(tmp), os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(str(tmp), str(path))


def write_effective_ports(
    *,
    edge_port: int | None,
    internal_port: int,
    api_port: int,
    pid: int | None = None,
    path: Path | None = None,
) -> None:
    """Write the daemon's authoritative bound-port tuple.

    v0.1.19.dev1 (Phase 2 Bug B fix). Called from the daemon's startup
    path AFTER each listener returns a kernel-confirmed bound port. The
    tuple goes into ``effective-ports.json`` atomically; downstream
    readers (edge, watchdog, ``_apply-user-env``, status, doctor) treat
    this file as the source of truth and fall back to ``runtime.toml``
    only when it's missing.

    ``edge_port`` is optional because the daemon process does not bind
    the edge listener (the edge process does). The daemon writes
    ``None`` for ``edge_port`` and the edge-side write
    (``write_edge_state_toml`` plus a follow-up merge in
    ``write_effective_ports`` from the edge process at startup) fills
    it in. Readers that need the edge port consult ``edge-state.toml``
    when ``edge_port`` is null in this file.

    Best-effort persistence: a failure here is logged and swallowed —
    the in-memory port tuple is still correct in the calling process.
    """
    target = path or EFFECTIVE_PORTS_JSON_PATH
    payload: dict = {
        "schema_version": _EFFECTIVE_PORTS_SCHEMA_VERSION,
        "pid": int(pid if pid is not None else os.getpid()),
        "bound_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.")
        + f"{int((time.time() % 1) * 1000):03d}Z",
        "edge_port": int(edge_port) if edge_port is not None else None,
        "internal_port": int(internal_port),
        "api_port": int(api_port),
    }
    try:
        _atomic_write_json(target, payload)
    except OSError as exc:
        log.warning(
            "effective_ports.write_failed",
            error=str(exc),
            path=str(target),
        )


def read_effective_ports(path: Path | None = None) -> dict:
    """Return the parsed effective-ports.json contents, or ``{}`` on error.

    Schema-tolerant: unknown keys are ignored; missing keys yield no
    entries. ``schema_version`` is checked but never causes a hard
    failure — older daemons that don't write the file at all should
    fall back to runtime.toml via the caller's fallback chain.

    Empty dict means "no authoritative answer here; consult the
    legacy runtime.toml fallback".
    """
    target = path or EFFECTIVE_PORTS_JSON_PATH
    if not target.exists():
        return {}
    try:
        with target.open("rb") as fh:
            raw = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(raw, dict):
        return {}
    out: dict = {}
    for key in ("edge_port", "internal_port", "api_port"):
        val = raw.get(key)
        if isinstance(val, int):
            out[key] = val
    pid = raw.get("pid")
    if isinstance(pid, int):
        out["pid"] = pid
    # v0.1.22.15: surface ``edge_pid`` so the freshness gate in
    # ``resolve_effective_port_ground_truth`` can compare it against
    # the launchctl-reported edge label PID. Written by
    # ``merge_edge_port_into_effective_ports`` from the edge process
    # at startup.
    edge_pid = raw.get("edge_pid")
    if isinstance(edge_pid, int):
        out["edge_pid"] = edge_pid
    bound_at = raw.get("bound_at")
    if isinstance(bound_at, str):
        out["bound_at"] = bound_at
    schema_version = raw.get("schema_version")
    if isinstance(schema_version, int):
        out["schema_version"] = schema_version
    return out


def remove_effective_ports(path: Path | None = None) -> None:
    """Remove ``effective-ports.json``. Idempotent. Called by uninstall."""
    target = path or EFFECTIVE_PORTS_JSON_PATH
    try:
        target.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def merge_edge_port_into_effective_ports(
    edge_port: int,
    *,
    path: Path | None = None,
) -> None:
    """Merge the edge process's bound edge_port into effective-ports.json.

    Called from the edge process at startup (after ``asyncio.start_server``
    returns the kernel-confirmed bound port). The edge-side write
    preserves whatever ``internal_port`` / ``api_port`` the daemon
    already wrote so readers can rely on a single file rather than
    merging effective-ports.json + edge-state.toml. Best-effort.

    If the file does not exist yet (edge started before daemon), this
    creates a minimal file with only ``edge_port``; the daemon's
    startup write will overlay internal/api on top.
    """
    target = path or EFFECTIVE_PORTS_JSON_PATH
    existing = read_effective_ports(target)
    payload: dict = {
        "schema_version": _EFFECTIVE_PORTS_SCHEMA_VERSION,
        "pid": existing.get("pid"),
        "bound_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.")
        + f"{int((time.time() % 1) * 1000):03d}Z",
        "edge_port": int(edge_port),
        "internal_port": existing.get("internal_port"),
        "api_port": existing.get("api_port"),
        "edge_pid": int(os.getpid()),
    }
    try:
        _atomic_write_json(target, payload)
    except OSError as exc:
        log.warning(
            "effective_ports.merge_edge_port_failed",
            error=str(exc),
            path=str(target),
        )


def _internal_probe_range_for(edge_port: int) -> tuple[int, int]:
    """Return ``(start_port, range_count)`` for the internal probe.

    Plan §8 Risk 4: when the user pinned ``edge_port`` somewhere in
    8090..8099 (the default internal range), shift the internal probe
    range to start at ``edge_port + 10`` so we don't self-collide. In
    every other case the default range applies.
    """
    if (
        _INTERNAL_PORT_DEFAULT
        <= edge_port
        < _INTERNAL_PORT_DEFAULT + _INTERNAL_PORT_PROBE_RANGE
    ):
        return edge_port + 10, _INTERNAL_PORT_PROBE_RANGE
    return _INTERNAL_PORT_DEFAULT, _INTERNAL_PORT_PROBE_RANGE


def allocate_ports(
    cfg: HaltonConfig,
    *,
    edge_pinned: bool | None = None,
    internal_pinned: bool = False,
    api_pinned: bool = False,
    runtime_path: Path | None = None,
    persist: bool = True,
    # v0.1.5 back-compat keyword. New callers should use ``edge_pinned=``.
    listen_pinned: bool | None = None,
) -> tuple[int, int, int]:
    """Return ``(edge_port, internal_port, api_port)`` honouring the
    precedence:

      1. config.toml pin (when ``edge_pinned`` / ``internal_pinned`` /
         ``api_pinned`` is True)
      2. probe + first-free in ``default .. default + probe_range - 1``
         (defaults: 8081..8089 for edge, 8090..8099 for internal,
         8765..8774 for api; the internal range shifts when ``edge_port``
         is pinned in 8090..8099)
      3. fall back to default if every candidate is busy (the daemon
         will then surface a clear bind error; we prefer noisy failure
         over silent confusion)

    When ``persist=True`` and discovery picked any non-default value,
    the chosen tuple is written to ``runtime_path`` (default
    ``RUNTIME_TOML_PATH``) so subsequent daemon restarts converge on the
    same tuple. When all three ports sit at their defaults, no write
    happens (avoids stamping a redundant runtime.toml on a clean default
    install).

    v0.1.5 back-compat: callers that still pass ``listen_pinned=`` are
    accepted; the value maps to ``edge_pinned``. The return tuple grew
    a third element — old two-tuple callers will see a TypeError on
    unpack; updated in lockstep with the rename.
    """
    runtime_target = runtime_path or RUNTIME_TOML_PATH
    host = cfg.daemon.listen_host

    # Resolve v0.1.5 -> v0.1.6 alias for the kwarg.
    if edge_pinned is None:
        edge_pinned = bool(listen_pinned) if listen_pinned is not None else False

    if edge_pinned:
        edge_port = int(cfg.daemon.edge_port)
    else:
        # v0.1.22.5 (B5): if the default edge port is held by OUR managed
        # edge process (launchd label ``com.haltonlabs.meter.edge``,
        # plist ``KeepAlive=True`` so it survives every ``stop`` cycle),
        # treat it as available and reuse it. Without this gate the
        # bare ``_is_port_free`` returns False because *we* hold the
        # socket, ``_probe_port`` walks to :8082, and runtime.toml gets
        # rewritten with the fallback — even though no actual conflict
        # exists. Net symptom: ``effective-ports.json`` ends up advertising
        # :8082, apps reading ``HTTPS_PROXY`` from there bypass the meter
        # silently, and the user sees a "fallback" warning in status.
        # Symmetric to the stop-side ``_our_managed_pids()`` filter
        # added in v0.1.22.3 (B4); see ``decisions.md`` 2026-05-07
        # "v0.1.22.5 — start reuses existing managed edge".
        if _managed_edge_holds_default_port(host, _EDGE_PORT_DEFAULT):
            edge_port = _EDGE_PORT_DEFAULT
        else:
            candidate = _probe_port(host, _EDGE_PORT_DEFAULT, _EDGE_PORT_PROBE_RANGE)
            edge_port = candidate if candidate is not None else _EDGE_PORT_DEFAULT

    # Internal probe: shift the range away from a pinned edge_port that
    # falls inside the default internal range.
    if internal_pinned:
        internal_port = int(cfg.daemon.internal_port)
    else:
        start, count = _internal_probe_range_for(edge_port)
        candidate = _probe_port(host, start, count)
        internal_port = candidate if candidate is not None else start

    api_host = cfg.daemon.api_host
    if api_pinned:
        api_port = int(cfg.daemon.api_port)
    else:
        candidate = _probe_port(api_host, _API_PORT_DEFAULT, _API_PORT_PROBE_RANGE)
        api_port = candidate if candidate is not None else _API_PORT_DEFAULT

    if persist:
        all_default = (
            edge_port == _EDGE_PORT_DEFAULT
            and internal_port == _INTERNAL_PORT_DEFAULT
            and api_port == _API_PORT_DEFAULT
        )
        # v0.1.19.dev1 (Phase 2 Bug B): port-convergence on boot. If we
        # ended up on the default tuple BUT a stale runtime.toml on disk
        # says otherwise (e.g. the previous boot fell back to 8082 / 8091
        # / 8766 because the defaults were transiently busy at probe-time
        # but are free again now), we must remove the stale file. Without
        # this every reader (load_effective_config) keeps overlaying the
        # stale tuple on top of the defaults, locking the daemon into a
        # fallback choice that's no longer needed.
        if all_default:
            try:
                if runtime_target.exists():
                    runtime_target.unlink()
            except OSError:
                pass
        else:
            try:
                _write_runtime_toml(
                    runtime_target,
                    edge_port=edge_port,
                    internal_port=internal_port,
                    api_port=api_port,
                )
            except OSError:
                # Persistence is best-effort. A read-only home / disk-full
                # case falls through with the in-memory ports still correct.
                pass

    return edge_port, internal_port, api_port


def load_effective_config(
    *,
    config_path: Path | None = None,
    runtime_path: Path | None = None,
) -> HaltonConfig:
    """Return a ``HaltonConfig`` whose daemon ports reflect the precedence:

        defaults < runtime.toml < config.toml

    This is what every read site (status, doctor, the run wrapper, the
    daemon's own startup) should call instead of ``load_config`` directly.
    The daemon's startup code path additionally calls ``allocate_ports``
    BEFORE this — discovering and persisting the runtime.toml tuple when
    no user pin is in place — so the next call here picks them up.

    v0.1.6 (2C.2): legacy ``listen_port`` in ``config.toml`` is honoured
    as ``edge_port`` and a structlog deprecation warning is emitted
    once per process. ``internal_port`` is read out of either source if
    present; defaulted otherwise.
    """
    cfg_path = config_path or CONFIG_TOML_PATH
    rt_path = runtime_path or RUNTIME_TOML_PATH

    # Start from defaults via HaltonConfig().
    base = HaltonConfig()

    # Overlay runtime.toml (legacy, written by daemon on fallback).
    rt = _read_runtime_toml(rt_path)
    edge_port = rt.get("edge_port", base.daemon.edge_port)
    internal_port = rt.get("internal_port", base.daemon.internal_port)
    api_port = rt.get("api_port", base.daemon.api_port)

    # Overlay effective-ports.json (v0.1.19.dev1: kernel-confirmed
    # truth, written after each successful bind). Higher precedence
    # than runtime.toml because runtime.toml may be stale across
    # reboots; effective-ports.json is rewritten on every daemon start.
    eff = read_effective_ports()
    if "edge_port" in eff:
        edge_port = eff["edge_port"]
    if "internal_port" in eff:
        internal_port = eff["internal_port"]
    if "api_port" in eff:
        api_port = eff["api_port"]

    # Inspect raw config.toml (parsed once; reused below).
    user_raw: dict[str, object] = {}
    if cfg_path.exists():
        try:
            with cfg_path.open("rb") as fh:
                user_raw = tomllib.load(fh)
        except (tomllib.TOMLDecodeError, OSError):
            user_raw = {}

    user_daemon: dict[str, object] = dict(user_raw.get("daemon", {}) or {})

    # Detect legacy `listen_port` for the deprecation warning.
    if "listen_port" in user_daemon and "edge_port" not in user_daemon:
        if not _legacy_warning_emitted():
            log.warning(
                "config.legacy_listen_port",
                msg=(
                    "config.toml uses deprecated [daemon] listen_port; "
                    "rename it to edge_port (same meaning, new name in "
                    "v0.1.6 — v0.1.5 wrote/read listen_port). The legacy "
                    "key continues to work for now."
                ),
                config_path=str(cfg_path),
            )
            _mark_legacy_warning_emitted()

    # Overlay config.toml (highest precedence). Legacy `listen_port`
    # maps to `edge_port` only when the canonical key is absent.
    if isinstance(user_daemon.get("edge_port"), int):
        edge_port = int(user_daemon["edge_port"])
    elif isinstance(user_daemon.get("listen_port"), int):
        edge_port = int(user_daemon["listen_port"])
    if isinstance(user_daemon.get("internal_port"), int):
        internal_port = int(user_daemon["internal_port"])
    if isinstance(user_daemon.get("api_port"), int):
        api_port = int(user_daemon["api_port"])

    # Fold into a fresh HaltonConfig. We rebuild the daemon section to
    # honour the resolved ports while preserving any other config.toml
    # keys we may have parsed.
    from halton_meter.config import (
        CorsConfig,
        DaemonConfig,
        StorageConfig,
        SyncConfig,
    )
    from halton_meter.config import HaltonConfig as _HC

    user_daemon_kw: dict[str, object] = dict(user_daemon)
    # Strip the keys we've already resolved; everything else (host,
    # log_path, edge_health_ttl_ms) flows through.
    for k in ("listen_port", "edge_port", "internal_port", "api_port"):
        user_daemon_kw.pop(k, None)

    daemon_cfg = DaemonConfig(
        **user_daemon_kw,
        edge_port=edge_port,
        internal_port=internal_port,
        api_port=api_port,
    )

    # Other sections come straight from defaults so we don't lose
    # storage / sync / cors keys.
    other_storage = base.storage
    other_sync = base.sync
    other_cors = base.cors
    if user_raw:
        try:
            if "storage" in user_raw:
                other_storage = StorageConfig.model_validate(user_raw["storage"])
            if "sync" in user_raw:
                other_sync = SyncConfig.model_validate(user_raw["sync"])
            if "cors" in user_raw:
                other_cors = CorsConfig.model_validate(user_raw["cors"])
        except Exception:  # pragma: no cover - defensive
            pass

    return _HC(
        daemon=daemon_cfg,
        storage=other_storage,
        sync=other_sync,
        cors=other_cors,
    )


def discover_and_persist_ports(
    *,
    config_path: Path | None = None,
    runtime_path: Path | None = None,
    persist: bool = True,
) -> tuple[int, int, int]:
    """Convenience wrapper used by the daemon's startup + by init.

    Reads the user's config.toml (to detect pins), probes the default
    ranges for whichever ports aren't pinned, persists runtime.toml
    when appropriate, and returns the chosen
    ``(edge_port, internal_port, api_port)``.

    v0.1.6: return tuple grew from two to three elements. The legacy
    ``(listen_port, api_port)`` shape is gone; callers were updated in
    lockstep with the config rename.
    """
    cfg_path = config_path or CONFIG_TOML_PATH
    rt_path = runtime_path or RUNTIME_TOML_PATH

    edge_pinned, internal_pinned, api_pinned = _read_explicit_keys_from_config_toml(
        cfg_path
    )
    cfg = load_effective_config(config_path=cfg_path, runtime_path=rt_path)
    return allocate_ports(
        cfg,
        edge_pinned=edge_pinned,
        internal_pinned=internal_pinned,
        api_pinned=api_pinned,
        runtime_path=rt_path,
        persist=persist,
    )


def probe_free_edge_port(preferred: int, *, host: str = "127.0.0.1") -> int:
    """Return the first free port in the edge probe range, preferring ``preferred``.

    v0.1.22 Fix 2: used by the edge process at startup so that a stale
    ``effective-ports.json`` fallback port (e.g. :8082 written by a
    previous session that fell back from :8081) does not cause a hard bind
    failure when another process has since grabbed that port.

    Probe order:

    1. ``preferred`` itself — if free, return it immediately (cheapest
       path, zero overhead on the normal happy path).
    2. ``EDGE_PORT_DEFAULT`` (8081) — always try the canonical default
       next so that we converge back to the standard port after a reboot.
    3. ``EDGE_PORT_DEFAULT+1 .. EDGE_PORT_DEFAULT+_EDGE_PORT_PROBE_RANGE-1``
       in order — same range the original ``allocate_ports`` probes.

    Returns the first free port found.  If nothing in the entire range is
    free, returns ``preferred`` unchanged — the subsequent bind attempt
    will surface a clear ``OSError`` (same fail-fast behaviour as before).

    Args:
        preferred: The port the edge wants to use (from config /
            effective-ports.json). Typically 8081..8089.
        host: The bind host to probe. Defaults to ``"127.0.0.1"``.

    Returns:
        An available port as an ``int``.
    """
    # Fast path: the stored port is still free — use it unchanged.
    if _is_port_free(host, preferred):
        return preferred

    # Preferred is busy.  Walk the default probe range to find the next
    # free slot.  We always start from EDGE_PORT_DEFAULT (8081) so we
    # converge back to the canonical port when possible (e.g. the fallback
    # port was grabbed but the default is free again after a reboot).
    candidate = _probe_port(host, _EDGE_PORT_DEFAULT, _EDGE_PORT_PROBE_RANGE)
    if candidate is not None:
        return candidate

    # Nothing free in the range.  Return preferred so the caller's bind
    # attempt can produce the usual descriptive OSError.
    return preferred


def migrate_runtime_toml(path: Path | None = None) -> bool:
    """Rewrite a v0.1.5 ``runtime.toml`` (with ``listen_port`` and
    ``api_port``) into the v0.1.6 shape (``edge_port`` +
    ``internal_port`` + ``api_port``).

    Returns True iff a rewrite happened. Idempotent: a v0.1.6-shaped
    file is left alone. Atomic + fsynced via ``_write_runtime_toml``.

    The daemon's startup path calls ``discover_and_persist_ports`` which
    reads the file, probes the defaults, and writes the canonical shape;
    this function exists so init / status can perform the migration
    early (e.g. before the daemon is up) and so the migration is unit-
    testable in isolation.
    """
    target = path or RUNTIME_TOML_PATH
    if not target.exists():
        return False
    try:
        with target.open("rb") as fh:
            raw = tomllib.load(fh)
    except (tomllib.TOMLDecodeError, OSError):
        return False
    daemon_tbl = raw.get("daemon", {}) or {}
    has_legacy = "listen_port" in daemon_tbl and "edge_port" not in daemon_tbl
    if not has_legacy:
        return False
    edge_port = daemon_tbl["listen_port"]
    if not isinstance(edge_port, int):
        return False
    api_port = daemon_tbl.get("api_port", _API_PORT_DEFAULT)
    if not isinstance(api_port, int):
        api_port = _API_PORT_DEFAULT
    # Choose a sane internal_port: use whatever's in the file if present,
    # else the default (or the collision-shifted default if edge_port is
    # in 8090..8099).
    explicit_internal = daemon_tbl.get("internal_port")
    if isinstance(explicit_internal, int):
        internal_port = explicit_internal
    else:
        start, _ = _internal_probe_range_for(edge_port)
        internal_port = start
    _write_runtime_toml(
        target,
        edge_port=edge_port,
        internal_port=internal_port,
        api_port=api_port,
    )
    log.info(
        "runtime_toml.migrated_v0_1_5_to_v0_1_6",
        edge_port=edge_port,
        internal_port=internal_port,
        api_port=api_port,
    )
    return True
