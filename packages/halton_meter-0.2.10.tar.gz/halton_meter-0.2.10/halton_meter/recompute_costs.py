"""
v0.1.12 — ``halton-meter recompute-costs`` one-shot CLI logic.

Recomputes ``cost_usd_minor_units`` for every captured request row using
the current pricing-rate authority. Designed to fix historical
undercount and to surface the effects of operator overrides
retroactively.

Resolution order at each row (v0.1.22.22, Layer 2):

  1. ``pricing_rates`` row whose ``effective_from <= row.requested_at``
     and (``effective_to`` is NULL or > row.requested_at). The
     most-recent ``effective_from`` wins ties. This honours **operator
     overrides** for the historical window they cover, and falls
     through to the **seed defaults** for windows the operator never
     touched. Both seed and override rows are stored in
     ``pricing_rates``; the override-vs-seed distinction is recorded
     on each row via ``is_seed_default`` but recompute does not branch
     on it — it picks the row that was authoritative at the time the
     request was captured.

  2. Bundled-matrix fallback (``compute_cost_millicents``). Used when
     a fresh database has not yet been seeded, or when a model is
     known to the bundled matrix but absent from ``pricing_rates``
     (e.g. test databases). Same value as the Layer 1 cost path uses
     for unmatched rows.

The operation is **idempotent**: it compares each stored cost against
what the resolution order above produces today. Rows that already
match are skipped. Running twice in a row updates zero rows on the
second pass.

Uses stdlib ``sqlite3`` only — no SQLAlchemy. Mirrors the isolation
pattern in ``retag.py``: ``BEGIN IMMEDIATE`` + explicit COMMIT/ROLLBACK
so we play nicely with a running daemon (WAL mode).

Schema invariant relied upon:
  requests(id, provider, model, mode, input_tokens, output_tokens,
           thinking_tokens, cache_read_tokens, cache_write_tokens,
           cost_usd_minor_units, requested_at)
  pricing_rates(provider, model, mode, effective_from, effective_to,
                input_rate_per_million_minor_units,
                output_rate_per_million_minor_units,
                thinking_rate_per_million_minor_units,
                cache_read_rate_per_million_minor_units,
                cache_write_rate_per_million_minor_units)
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path

import structlog

from halton_meter.pricing import apply_rates, compute_cost_millicents

log = structlog.get_logger()


def _lookup_rate_for_row(
    conn: sqlite3.Connection,
    *,
    provider: str,
    model: str,
    mode: str,
    requested_at: str,
) -> tuple[int, int, int, int, int] | None:
    """Return the rates tuple from ``pricing_rates`` active at ``requested_at``.

    Returns ``(input_rate, output_rate, thinking_rate, cache_read_rate,
    cache_write_rate)`` or ``None`` when no row matches. The tuple
    ordering matches the ``apply_rates`` keyword arguments used in
    :func:`recompute_costs`.

    The query mirrors :func:`halton_meter.api.services.ingest.get_pricing_rate`
    but uses raw SQL because :mod:`recompute_costs` is sqlite3-only.
    """
    try:
        row = conn.execute(
            "SELECT input_rate_per_million_minor_units, "
            "output_rate_per_million_minor_units, "
            "thinking_rate_per_million_minor_units, "
            "cache_read_rate_per_million_minor_units, "
            "cache_write_rate_per_million_minor_units "
            "FROM pricing_rates "
            "WHERE provider = ? AND model = ? AND mode = ? "
            "AND effective_from <= ? "
            "AND (effective_to IS NULL OR effective_to > ?) "
            "ORDER BY effective_from DESC LIMIT 1",
            (provider, model, mode, requested_at, requested_at),
        ).fetchone()
    except sqlite3.OperationalError:
        # Database doesn't have a pricing_rates table yet (greenfield
        # install scenarios, certain unit tests). Fall through to the
        # bundled-matrix path.
        return None
    if row is None:
        return None
    return (int(row[0]), int(row[1]), int(row[2]), int(row[3]), int(row[4]))


@dataclass(frozen=True)
class RecomputeResult:
    """Summary returned by :func:`recompute_costs`."""

    rows_scanned: int
    """Total rows read from the requests table (where cost IS NOT NULL)."""

    rows_updated: int
    """Rows whose stored cost differed from the current matrix value.
    If ``dry_run=True``, no writes occurred but this count still reflects
    how many *would* have been updated.
    """

    old_total_millicents: int
    """Sum of the original ``cost_usd_minor_units`` values for the rows
    that were (or would be) updated. Zero if ``rows_updated == 0``."""

    new_total_millicents: int
    """Sum of the recomputed costs for those same rows.
    Zero if ``rows_updated == 0``."""


def recompute_costs(db_path: Path, dry_run: bool = False) -> RecomputeResult:
    """Recompute stored costs for all captured requests using current rates.

    Args:
        db_path: Path to the SQLite database (e.g. ~/.halton-meter/logs.db).
        dry_run: If True, identify rows that need updating but do not write.
                 The returned ``RecomputeResult.rows_updated`` still reflects
                 the count of rows that *would* be changed.

    Returns:
        :class:`RecomputeResult` summarising the operation.

    Raises:
        sqlite3.Error: If the database cannot be opened or the transaction
            fails (after a ROLLBACK attempt).
    """
    conn = sqlite3.connect(str(db_path), timeout=10.0)
    try:
        # Match the daemon's pragmas for WAL-mode compatibility.
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.execute("BEGIN IMMEDIATE")
        try:
            rows = conn.execute(
                "SELECT id, provider, model, mode, "
                "input_tokens, output_tokens, "
                "thinking_tokens, cache_read_tokens, cache_write_tokens, "
                "cost_usd_minor_units, requested_at "
                "FROM requests "
                "WHERE cost_usd_minor_units IS NOT NULL"
            ).fetchall()

            updates: list[tuple[int, str]] = []  # (new_cost, id)
            old_total: int = 0
            new_total: int = 0

            for row in rows:
                (
                    row_id,
                    provider,
                    model,
                    mode,
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    cache_write_tokens,
                    stored_cost,
                    requested_at,
                ) = row

                # Resolution order — pricing_rates first (honours operator
                # overrides + seed rows scoped to historical effective
                # windows), then bundled-matrix fallback for rows whose
                # request time predates any matching rate row.
                rates = _lookup_rate_for_row(
                    conn,
                    provider=str(provider or "anthropic"),
                    model=str(model),
                    mode=str(mode or "standard"),
                    requested_at=str(requested_at),
                )
                if rates is not None:
                    new_cost: int | None = apply_rates(
                        input_tokens=int(input_tokens or 0),
                        input_rate=rates[0],
                        output_tokens=int(output_tokens or 0),
                        output_rate=rates[1],
                        thinking_tokens=int(thinking_tokens or 0),
                        thinking_rate=rates[2],
                        cache_read_tokens=int(cache_read_tokens or 0),
                        cache_read_rate=rates[3],
                        cache_write_tokens=int(cache_write_tokens or 0),
                        cache_write_rate=rates[4],
                    )
                else:
                    new_cost = compute_cost_millicents(
                        model=str(model),
                        input_tokens=int(input_tokens or 0),
                        output_tokens=int(output_tokens or 0),
                        thinking_tokens=int(thinking_tokens or 0),
                        cache_read_tokens=int(cache_read_tokens or 0),
                        cache_write_tokens=int(cache_write_tokens or 0),
                    )

                # Skip rows whose model is not in any rates source —
                # do NOT zero them out; NULL is the correct sentinel.
                if new_cost is None:
                    continue

                if new_cost != int(stored_cost):
                    updates.append((new_cost, row_id))
                    old_total += int(stored_cost)
                    new_total += new_cost

            if not dry_run:
                for new_cost, row_id in updates:
                    conn.execute(
                        "UPDATE requests SET cost_usd_minor_units = ? WHERE id = ?",
                        (new_cost, row_id),
                    )

            conn.execute("COMMIT")

        except Exception:
            conn.execute("ROLLBACK")
            raise

    finally:
        conn.close()

    log.info(
        "recompute_costs.complete",
        rows_scanned=len(rows),
        rows_updated=len(updates),
        dry_run=dry_run,
    )

    return RecomputeResult(
        rows_scanned=len(rows),
        rows_updated=len(updates),
        old_total_millicents=old_total,
        new_total_millicents=new_total,
    )


def format_usd(millicents: int) -> str:
    """Format a millicent value as a USD string with 6 decimal places.

    Six decimal places ensures sub-cent precision is visible (useful when
    reviewing small corrections like per-row recompute deltas).

    Example: 5_250 → "$0.052500"
    """
    dollars = millicents / 100_000
    return f"${dollars:,.6f}"
