"""
Hand-curated mapping of macOS bundle identifiers to human-readable names.

Used by ``report.humanize_project`` to turn raw attribution tags like
``mac:com.docker.docker`` into report-grade labels like ``Docker``. Keep
this small — only the bundle IDs we actually see in real attribution
output. Unknown ``mac:com.X.Y`` strings drop the ``mac:`` prefix only;
they do NOT get auto-titlecased (e.g. ``com.acme.foo`` stays as
``com.acme.foo``).

Add new entries inline as we encounter them in the wild. The registry
is intentionally a flat dict, not a regex table, because the value
proposition is editorial: each label is human-chosen.

See decisions.md 2026-05-07 entry for v0.1.22.13.
"""

from __future__ import annotations

#: Bundle-ID → display name. Lower-case keys; preserve case in values.
APP_REGISTRY: dict[str, str] = {
    "com.docker.docker": "Docker",
    "com.microsoft.excel": "Excel",
    "com.microsoft.outlook": "Outlook",
    "com.microsoft.teams2": "Teams",
    "com.apple.safari": "Safari",
    "com.apple.dock": "Dock",
    "com.google.chrome": "Chrome",
    "org.mozilla.firefox": "Firefox",
}


def humanize_bundle_id(raw: str) -> str:
    """Turn an attribution tag into a display label.

    Rules (in order):
      1. ``mac:<bundle>`` with a registry hit → registry label.
      2. ``mac:<bundle>`` without a hit → ``<bundle>`` (drop the prefix only).
      3. Anything else → returned verbatim.

    Bundle IDs are case-insensitive in practice; we lower-case before
    lookup but keep the bundle's original casing in the fallback.
    """
    if not raw.startswith("mac:"):
        return raw
    bundle = raw[len("mac:"):]
    label = APP_REGISTRY.get(bundle.lower())
    if label is not None:
        return label
    return bundle
