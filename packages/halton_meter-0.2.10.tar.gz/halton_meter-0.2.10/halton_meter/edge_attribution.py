"""
Edge-side project attribution (v0.1.13, SQLite-backed since 2026-05-01 fix).

The edge process accepts the client TCP connection directly, which
makes it the only place in the system that can do **deterministic**
project attribution:

* The connection is fresh (microseconds old) when accept fires —
  there is no race against the kernel's connection table state.
* The edge sees ``(client_host, client_port)`` from
  ``writer.get_extra_info('peername')``; a psutil lookup for the
  process owning that local port is reliable because there are no
  intervening proxies to confuse the connection table.
* The edge can read the originating process's ``cwd`` and ``environ``
  directly — psutil works on macOS for child processes the user
  owns (the common case for Claude Code, Windsurf, etc.).

This module is **deliberately not imported by edge.py at module
import time** so the edge.py docstring's stdlib-only invariant
holds. ``edge.py`` imports the public functions lazily inside
``_handle_connection``. The actual hot-path work — psutil walk +
SQLite write — runs at TCP accept and is bounded by ``RESOLVE_BUDGET_S``
so a stuck psutil call cannot block accept latency.

Why SQLite instead of HTTP (production-bug fix, 2026-05-01):

The original v0.1.13 design POSTed the resolution to the daemon's
``/v1/internal/attribution`` endpoint over HTTP. In production this
raced the daemon's mitmproxy ``request()`` hook every time: the edge
would ``up_writer.write(connect_bytes)`` to the daemon BEFORE the POST
to FastAPI/uvicorn finished (or sometimes started), and every row
landed as ``unattributed``.

The fix is to write to a shared SQLite table (in the same
``~/.halton-meter/db.sqlite`` file the daemon already uses) under
``BEGIN IMMEDIATE``. SQLite WAL handles cross-process reader/writer
concurrency natively. The write completes in well under a millisecond,
inside the TCP-accept window before the daemon's addon ``request()``
hook fires.

The two-step flow inside the edge is:

1. ``resolve_client_project(client_port, edge_port)`` returns the
   project name for the process owning ``laddr.port == client_port``
   AND ``raddr.port == edge_port`` (the dual match makes the client
   uniquely identifiable even when an unrelated system process
   happens to have ``laddr.port`` collide).

2. After ``asyncio.open_connection`` to the daemon, the edge captures
   its **own** outbound source port (``sockname[1]``) and calls
   ``register_attribution(edge_src_port, project)``. That write MUST
   happen before the CONNECT request line is forwarded so the daemon's
   ``request()`` hook sees the row when it inspects
   ``flow.client_conn.peername``.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import Any

import structlog

from halton_meter import attribution_store
from halton_meter.attribution import layers as _layers
from halton_meter.attribution.resolver import _same_uid_session

log = structlog.get_logger(__name__)

# Hard time budget for the psutil resolution step. We MUST NOT block
# accept latency by more than this — the daemon's tagging pathway has
# a perfectly good fallback ("unattributed") and the cardinal rule
# ranks workflow-uninterrupted above attribution-accuracy.
#
# 2026-05-01 fix: bumped from 50 ms to 200 ms. macOS psutil's
# ``net_connections()`` walk can take 30-100 ms on a busy system
# (Vikrant's MacBook with ~600 processes regularly hits 60 ms). 50 ms
# was timing out roughly 10 % of the time even when resolution would
# have succeeded. 200 ms accommodates the variance without making
# accept latency perceptibly slower.
#
# 2026-05-02 fix: bumped from 200 ms to 500 ms. Brief D's diagnostic
# found 130 ``edge.attribution.resolve_timeout`` warnings in a single
# day's edge.out.log — clusters at 12:49 and 13:06, correlated with
# system-wide socket-scan churn. 200 ms was clipping a real subset of
# resolutions that would otherwise have succeeded; 500 ms gives enough
# headroom for the parent-PID walk (Fix 1, same PR) to complete inside
# the same budget without nudging the ceiling further.
RESOLVE_BUDGET_S = 0.50  # 500 ms

# Constants kept as module-level aliases for back-compat. Canonical home
# is :mod:`halton_meter.attribution.layers`.
_RCFILE_NAME = _layers.RCFILE_NAME
_ENV_VAR = _layers.ENV_VAR
_UNATTRIBUTED = _layers.UNATTRIBUTED
_WORKSPACE_FLAGS = _layers.WORKSPACE_FLAGS

# Layer helpers — the implementations now live in
# :mod:`halton_meter.attribution.layers`. The aliases below preserve the
# private names that the existing test suite reaches for. The
# body_capture parsing remains here (`_parse_body_capture_value`) only as
# a re-export so any external caller still works; the canonical parser
# lives inside ``layers.resolve_via_haltonrc``.
_sanitize_project_name = _layers.normalise_project_slug
_read_haltonrc = _layers.resolve_via_haltonrc
_decode_windsurf_workspace_id = _layers.decode_windsurf_workspace_id
_decode_file_uri = _layers.decode_file_uri
_decode_workspace_value = _layers.decode_workspace_value
_extract_workspace_path_from_cmdline = _layers.extract_workspace_path_from_cmdline
_parse_body_capture_value = _layers._parse_body_capture_value


def _safe_cmdline(proc: Any) -> list[str]:
    """Return ``proc.cmdline()`` or ``[]`` on any psutil error."""
    try:
        return list(proc.cmdline())
    except Exception:
        # psutil error surface is wide (NoSuchProcess, AccessDenied,
        # ZombieProcess, OSError); attribution must never raise.
        return []


# Parent-PID walk (v0.2.4 — drops the v0.1.13 chromium-helper gate and
# IDE-family allow-list per memory/decisions.md 2026-05-18 "v0.2.4
# unified attribution resolver"). The walk now runs unconditionally for
# any process whose own IDE-args sniff misses; the bound is uid /
# session boundary + hop budget (decision 5).
#
# The legacy ``_IDE_FAMILY_NAMES`` allow-list bailed out the moment a
# parent crossed an IDE-family boundary — which mis-handled the
# legitimate ``claude → bash → Cursor Helper`` shape because ``bash``
# isn't in the allow-list. uid / session boundary is the structurally
# correct stop: as long as we stay in the same user session, the
# parent chain is owned by the same human and attribution stays safe.
#
# Chromium process tree depth on macOS is typically 3-4; 5 hops is
# comfortably generous and the cheap guard against runaway loops if
# ``proc.parent()`` ever returns a cycle.
_PARENT_WALK_MAX_HOPS = 5


def _safe_proc_name(proc: Any) -> str:
    """Return ``proc.name()`` or ``""`` on any psutil error."""
    try:
        return str(proc.name())
    except Exception:
        return ""


def _safe_parent(proc: Any) -> Any | None:
    """Return ``proc.parent()`` or ``None`` on any psutil error."""
    try:
        return proc.parent()
    except Exception:
        return None


def _walk_parents_for_workspace(
    target_proc: Any,
) -> tuple[str, str, int] | None:
    """Walk parent PIDs looking for one whose argv carries a workspace.

    Returns ``(parent_name, workspace_path, depth)`` on success or
    ``None`` when the walk terminates without finding a workspace flag.

    Stop conditions (any one ends the walk):

    * ``proc.parent()`` returns ``None`` (we are at the top of the tree).
    * Parent's pid is ``1`` (launchd / init — workspace state never
      lives there).
    * uid or session boundary crossed (v0.2.4 decision 5 — cardinal
      rule defence against attributing to a system service that
      happens to live above the user process in the tree).
    * Hop budget exhausted (5 hops; see :data:`_PARENT_WALK_MAX_HOPS`).

    Wrapped in a top-level try/except in the caller — this function
    must NEVER raise; on any unexpected error return ``None`` and let
    the caller fall through to the next layer.
    """
    current = target_proc
    for depth in range(1, _PARENT_WALK_MAX_HOPS + 1):
        parent = _safe_parent(current)
        if parent is None:
            return None
        # PID 1 = launchd / init. No workspace context above this point.
        try:
            parent_pid = int(parent.pid)
        except Exception:
            return None
        if parent_pid <= 1:
            return None
        # v0.2.4 — uid / session boundary replaces the legacy IDE
        # allow-list. As long as we stay in the same user session, the
        # parent chain is owned by the same human and attribution is
        # safe. Crossing into a different uid (e.g. ``root``) or a
        # different session (e.g. an unrelated terminal) ends the walk.
        if not _same_uid_session(parent, target_proc):
            return None
        parent_name = _safe_proc_name(parent)
        parent_cmdline = _safe_cmdline(parent)
        workspace_path = _extract_workspace_path_from_cmdline(parent_cmdline)
        if workspace_path:
            return (parent_name, workspace_path, depth)
        current = parent
    return None


def _resolve_via_psutil(
    client_port: int,
    edge_port: int,
) -> tuple[str, bool, str | None]:
    """Synchronous psutil walk — invoked from a thread, never the event loop.

    Find the single process whose connection table contains
    ``laddr.port == client_port`` AND ``raddr.port == edge_port``.
    The dual match makes the client unique even when unrelated
    processes have ephemeral ports that coincidentally equal
    ``client_port``.

    On match, apply attribution precedence to that process:
    HALTON_PROJECT env var → .haltonrc walk → cwd basename →
    ``"unattributed"``. Returns ``("unattributed", True, None)`` on any
    failure (no match, psutil raised, env_var/cwd readable but empty).

    Returns ``(project_name, body_capture_enabled, source_workdir)``. The
    ``body_capture_enabled`` flag is taken from the same ``.haltonrc``
    that supplied the project tag (whether walked from cwd or from
    the IDE-args sniff workspace). Default True (master-on default)
    when no rcfile is found or the rcfile doesn't set the flag.

    ``source_workdir`` is the originating process's cwd as a string, or
    ``None`` when it could not be resolved (e.g. env-var path fires
    before cwd is read, or cwd is unreadable). Added in v0.2.10.

    Why the dual match: macOS routinely reports many processes with
    overlapping ephemeral ports in the LISTEN/CLOSE_WAIT/TIME_WAIT
    states. The single-match version misattributes ~10 % of requests
    in steady-state observation.
    """
    try:
        import psutil  # type: ignore[import-untyped]
    except ImportError:
        return (_UNATTRIBUTED, True, None)

    target_proc: Any = None
    try:
        for proc in psutil.process_iter(["pid"]):
            try:
                # net_connections() rename in psutil 6.0; tolerate both.
                try:
                    conns = proc.net_connections()
                except AttributeError:
                    conns = proc.connections()  # type: ignore[attr-defined]
            except (
                psutil.NoSuchProcess,
                psutil.AccessDenied,
                psutil.ZombieProcess,
            ):
                continue
            for conn in conns:
                laddr = getattr(conn, "laddr", None)
                raddr = getattr(conn, "raddr", None)
                if (
                    laddr
                    and getattr(laddr, "port", None) == client_port
                    and raddr
                    and getattr(raddr, "port", None) == edge_port
                ):
                    target_proc = proc
                    break
            if target_proc is not None:
                break
    except Exception as exc:  # pragma: no cover — defensive
        log.debug("edge.attribution.psutil_walk_failed", error=str(exc))
        return (_UNATTRIBUTED, True, None)

    if target_proc is None:
        return (_UNATTRIBUTED, True, None)

    # Step 1 — HALTON_PROJECT on the originating process. We read the
    # ORIGINATING process's environ, not os.environ — that's the whole
    # point of doing the lookup at the edge. proc.environ() works on
    # macOS for processes the daemon's user owns (the common case);
    # AccessDenied falls through. ``HALTON_PROJECT`` doesn't carry a
    # body-capture preference; if the env-var path wins, we still walk
    # the rcfile chain for the body_capture flag below.
    #
    # ``proc_env`` is also captured here for Layer 6 (container
    # detection, PR2 2026-05-02) further down. The matched process's
    # environ — NOT the edge's — is what determines whether the
    # caller is inside a container; getting this wrong would mis-tag
    # every dev laptop where the edge happens to have inherited a
    # ``KUBERNETES_SERVICE_HOST`` value.
    env_project: str | None = None
    proc_env: dict[str, str] = {}
    try:
        proc_env = target_proc.environ()
        # Layer 1 — delegated to attribution.layers. Pass the
        # ORIGINATING process's environ explicitly (not os.environ —
        # that's the whole point of doing the lookup at the edge).
        env_project = _layers.resolve_via_env(proc_env)
    except (
        psutil.NoSuchProcess,
        psutil.AccessDenied,
        psutil.ZombieProcess,
    ):
        pass
    except Exception as exc:  # pragma: no cover — defensive
        log.debug("edge.attribution.environ_failed", pid=target_proc.pid, error=str(exc))

    # Step 2 — .haltonrc walk from the process's cwd.
    # cwd is resolved here; all return sites below pass it as source_workdir.
    try:
        cwd = target_proc.cwd()
    except (
        psutil.NoSuchProcess,
        psutil.AccessDenied,
        psutil.ZombieProcess,
    ):
        # cwd unreadable — env var still wins if present, workdir unknown.
        if env_project:
            return (env_project, True, None)
        return (_UNATTRIBUTED, True, None)
    except Exception as exc:  # pragma: no cover — defensive
        log.debug("edge.attribution.cwd_failed", pid=target_proc.pid, error=str(exc))
        if env_project:
            return (env_project, True, None)
        return (_UNATTRIBUTED, True, None)

    # cwd is now known; surface it as source_workdir on all subsequent returns.
    cwd_str: str | None = str(cwd) if cwd else None

    rc_project, rc_body_capture = _read_haltonrc(cwd)
    # body_capture defaults to True (master-on); only flip when an
    # rcfile says so. The rcfile that wins for the project tag also
    # wins for the body-capture flag.
    if env_project:
        # The cwd's rcfile (if any) supplies the body_capture flag
        # even when env var supplies the project. Documented contract:
        # rcfile is the canonical config surface; env var only
        # overrides the project tag. Default True when missing.
        return (env_project, rc_body_capture if rc_body_capture is not None else True, cwd_str)

    if rc_project:
        return (
            _sanitize_project_name(rc_project),
            rc_body_capture if rc_body_capture is not None else True,
            cwd_str,
        )

    # Step 3 — IDE workspace sniff. GUI-launched IDE helpers (Windsurf
    # language_server, Cursor/VS Code extension hosts) have a useless
    # cwd (the app bundle); their actual workspace lives in argv. If
    # we recover a real workspace path, prefer .haltonrc walked from
    # there over the cwd basename. See the module docstring for the
    # 2026-05-01 trial-run motivation.
    cmdline = _safe_cmdline(target_proc)
    workspace_path = _extract_workspace_path_from_cmdline(cmdline)
    if workspace_path:
        ws_project, ws_body_capture = _read_haltonrc(workspace_path)
        if ws_project:
            return (
                _sanitize_project_name(ws_project),
                ws_body_capture if ws_body_capture is not None else True,
                cwd_str,
            )
        ws_basename = Path(workspace_path).name
        if ws_basename:
            return (
                _sanitize_project_name(ws_basename),
                ws_body_capture if ws_body_capture is not None else True,
                cwd_str,
            )

    # Step 4 — git repo basename (PR2 2026-05-02; Option A locked,
    # never concatenates branch info). Per-cwd memoised inside
    # ``layers.resolve_via_git``.
    git_project = _layers.resolve_via_git(cwd)
    if git_project:
        return (git_project, True, cwd_str)

    # Step 6 — Linux/Kubernetes container detection (PR2 2026-05-02).
    # Pass the MATCHED PROCESS'S environ, never the edge's. The
    # ``fs_probe`` argument is omitted so production reads the real
    # filesystem; tests inject a fake.
    container_project = _layers.resolve_via_container(proc_env)
    if container_project:
        return (container_project, True, cwd_str)

    # Step 6.5 — macOS sandbox bundle id (PR2 2026-05-02; Brief D).
    # Pre-empts the ``Data`` collapse for sandboxed Mac AI apps.
    mac_project = _layers.resolve_via_mac_sandbox(cwd)
    if mac_project:
        return (mac_project, True, cwd_str)

    # Step 7 — basename of cwd. Last resort; for IDE helpers this is
    # often a non-project directory (e.g. the Windsurf app bundle), so
    # the IDE-args sniff above gets first crack.
    basename = Path(cwd).name
    if basename:
        return (_sanitize_project_name(basename), True, cwd_str)

    # Step 7.5 — parent-PID walk (v0.2.4 ADR — drops the
    # ``_is_chromium_helper`` gate and the IDE-family allow-list). The
    # walk runs ONLY when the target's own cwd is uninformative
    # (basename empty, cwd is ``/``) — moved here from the old Step
    # 3.5 position so a target with a usable cwd is never overridden
    # by its parent's workspace. The walk is bounded by the hop budget
    # + uid / session boundary stops inside
    # :func:`_walk_parents_for_workspace`. This covers the native ELF
    # ``claude`` worker case (no ``--type=`` marker, no IDE-family
    # name, cwd reads as ``/``) that the v0.1.13 gate silently skipped.
    #
    # Wrapped in try/except: parent walk MUST NOT raise out of the hot
    # path. ``psutil.AccessDenied`` / ``NoSuchProcess`` / OSError are
    # all fair game when the parent terminated mid-walk.
    try:
        walk_result = _walk_parents_for_workspace(target_proc)
    except Exception as exc:  # pragma: no cover — defensive
        log.debug(
            "edge_attribution.parent_walk_failed",
            pid=target_proc.pid,
            error=str(exc),
        )
        walk_result = None
    if walk_result is not None:
        parent_name, parent_ws, parent_depth = walk_result
        log.info(
            "edge_attribution.parent_walk_resolved",
            depth=parent_depth,
            parent_pid=getattr(_safe_parent(target_proc), "pid", None),
            parent_name=parent_name,
            workspace=parent_ws,
        )
        ws_project, ws_body_capture = _read_haltonrc(parent_ws)
        if ws_project:
            return (
                _sanitize_project_name(ws_project),
                ws_body_capture if ws_body_capture is not None else True,
                cwd_str,
            )
        ws_basename = Path(parent_ws).name
        if ws_basename:
            return (
                _sanitize_project_name(ws_basename),
                ws_body_capture if ws_body_capture is not None else True,
                cwd_str,
            )

    # Step 8 — unified resolver fallback (v0.2.5 edge_store leak fix).
    # The standalone chain (Steps 1-7.5) exhausted all options. Before
    # returning unattributed, give the unified resolver a chance — it
    # contains the Tier 4b/4c env/argv label extractors plus the v0.2.5
    # cold-start lenient scan that the standalone chain does not replicate.
    # Lazy imports preserve the stdlib-only invariant at module-import time
    # (same pattern as the psutil import at the top of this function).
    #
    # Wrapped in a top-level try/except: a crash here must NEVER block the
    # accept path. The unified resolver itself never raises (it has its own
    # cardinal-rule guard), but belt-and-braces around the import/call too.
    try:
        from halton_meter.attribution.registry import get_edge_registry
        from halton_meter.attribution.resolver import resolve_unified

        resolved = resolve_unified(
            target_proc=target_proc,
            target_env=proc_env,
            target_cwd=str(cwd) if cwd else None,
            target_cmdline=cmdline,
            registry=get_edge_registry(),
        )
        if resolved is not None and resolved.project != _UNATTRIBUTED:
            log.info(
                "edge_attribution.resolver_fallback",
                pid=getattr(target_proc, "pid", None),
                project=resolved.project,
                method=resolved.attribution_method,
            )
            return (resolved.project, True, cwd_str)
    except Exception as exc:  # pragma: no cover — cardinal-rule defence
        log.debug(
            "edge_attribution.resolver_fallback_failed",
            pid=getattr(target_proc, "pid", None),
            error=str(exc),
        )

    return (_UNATTRIBUTED, True, cwd_str)


async def resolve_client_project(
    client_port: int, edge_port: int
) -> tuple[str, bool, str | None]:
    """Resolve the originating process's project name from a client port.

    Runs the psutil walk on a worker thread under ``RESOLVE_BUDGET_S``
    so accept latency can never be held hostage to a slow connection-
    table scan. On timeout / any unexpected error we return
    ``("unattributed", True, None)`` — the cardinal rule says
    workflow-uninterrupted beats attribution-accuracy. Never raises.

    Returns ``(project, body_capture_enabled, source_workdir)``. The
    ``body_capture_enabled`` flag defaults True (master-on default)
    when no rcfile is found or the rcfile doesn't set it.
    ``source_workdir`` is the originating process's cwd or None when
    unavailable (added v0.2.10).
    """
    started = time.monotonic()
    try:
        project, body_capture_enabled, source_workdir = await asyncio.wait_for(
            asyncio.to_thread(_resolve_via_psutil, client_port, edge_port),
            timeout=RESOLVE_BUDGET_S,
        )
    except TimeoutError:
        log.warning(
            "edge.attribution.resolve_timeout",
            client_port=client_port,
            budget_s=RESOLVE_BUDGET_S,
        )
        return (_UNATTRIBUTED, True, None)
    except Exception as exc:  # pragma: no cover — defensive
        log.error(
            "edge.attribution.resolve_failed",
            client_port=client_port,
            error=str(exc),
        )
        return (_UNATTRIBUTED, True, None)
    elapsed_ms = (time.monotonic() - started) * 1000
    log.info(
        "edge.attribution.resolved",
        client_port=client_port,
        project=project,
        body_capture_enabled=body_capture_enabled,
        source_workdir=source_workdir,
        elapsed_ms=round(elapsed_ms, 2),
    )
    return (project, body_capture_enabled, source_workdir)


def register_attribution(
    edge_src_port: int,
    project_name: str,
    body_capture_enabled: bool = True,
    *,
    source_workdir: str | None = None,
) -> None:
    """Persist the resolution to the shared SQLite attribution table.

    Synchronous on purpose — the edge MUST block on this call before
    forwarding the CONNECT bytes to the daemon, otherwise the addon's
    ``request()`` hook races ahead of the write and resolves
    ``unattributed``. The SQLite write completes well under a
    millisecond on local SSD under WAL with ``BEGIN IMMEDIATE``.

    ``body_capture_enabled`` defaults True (matches the master-on
    default); the edge passes the flag from the resolved ``.haltonrc``
    so B2's ``BodyCaptureCache`` fallback can honour rcfile-side opt-out
    without a ``project_settings`` row.

    ``source_workdir`` is the originating process's cwd (v0.2.10 —
    stored in ``attribution_log.source_workdir`` so ``tagging.py``
    cache hits can surface it without re-resolving). Keyword-only,
    optional, defaults to None.

    Never raises. ``attribution_store.write`` already wraps every
    sqlite3 error path and logs internally; this function is a
    paper-thin facade so callers can keep the same name they used
    for the v0.1.13 HTTP transport. (Also, keeping the function here
    lets edge.py continue to import from ``edge_attribution`` rather
    than directly from the storage module — a small concession to
    callsite stability during the transport swap.)
    """
    attribution_store.write(
        edge_src_port,
        project_name,
        body_capture_enabled,
        source_workdir=source_workdir,
    )
