"""
Pricing module for Halton Meter daemon.

TEMP-PHASE-0: Local cost computation using a hardcoded matrix.
Will be removed when the backend takes over in Phase 1.
See memory/decisions.md 2026-04-28.

Public API:
    compute_cost_millicents(model, input_tokens, output_tokens,
                            thinking_tokens, cache_read_tokens,
                            cache_write_tokens) -> int | None
    apply_rates(...) -> int

``apply_rates`` is the single source of truth for the sum-first cost
formula. Both the bundled-matrix path (``compute_cost_millicents`` here)
and the rates-table path (``api/services/ingest.compute_cost_from_rate``
and ``recompute_cost``) route through it, so cost values are
bit-identical across paths for the same token set + rate values.
See memory/plans/2026-04-30-daemon-audit-remediation.md (P0-4).

``compute_cost_millicents`` resolves in this order:
  1. ``ANTHROPIC_RATES`` — all Anthropic/Claude models (single tier).
  2. ``GEMINI_TIERED_RATES`` — the two Gemini models with a >200k
     input-token surcharge (gemini-3.1-pro-preview, gemini-2.5-pro).
     Tier selected at call time based on ``input_tokens``.
     Decision: memory/decisions.md 2026-05-01 "Gemini tier surcharge".
  3. ``GEMINI_RATES`` — remaining single-tier Gemini models.
  4. ``OPENAI_RATES`` — OpenAI chat / responses / reasoning / embedding
     models (single tier; flat per-model rates as of 2026-05-02).
  5. ``XAI_RATES`` — xAI / Grok models (single tier; flat per-model rates
     as of 2026-05-02). xAI exposes both OpenAI- and Anthropic-shape APIs
     on the same host; pricing is per-model regardless of API shape.
  6. ``None`` — model unknown; store as NULL rather than a wrong 0.
"""

from __future__ import annotations

from halton_meter.pricing.matrix import (
    ANTHROPIC_RATES,
    BUNDLED_RATES_DATE,
    GEMINI_RATES,
    GEMINI_TIERED_RATES,
    OPENAI_RATES,
    XAI_RATES,
)


def bundled_rates_source() -> str:
    """Return the canonical ``rates_source`` string for bundled-matrix costs.

    Stored on each ``requests`` row whose cost was computed against a
    seed pricing_rates row (i.e. ``is_seed_default = True``). The string
    is intentionally human-readable so audit consumers (CSV exports,
    client cost reports) can read it without a join.

    See ``BUNDLED_RATES_DATE`` in ``pricing/matrix.py``.
    """
    return f"bundled-{BUNDLED_RATES_DATE}"


def apply_rates(
    *,
    input_tokens: int,
    input_rate: int,
    output_tokens: int,
    output_rate: int,
    thinking_tokens: int,
    thinking_rate: int,
    cache_read_tokens: int,
    cache_read_rate: int,
    cache_write_tokens: int,
    cache_write_rate: int,
) -> int:
    """Sum-first-then-divide cost calculation in millicents.

    All rates are millicents per million tokens. The formula accumulates
    every ``tokens * rate`` numerator first and divides by 1_000_000 once
    at the end. Per-line ``// 1_000_000`` truncation would silently drop
    the sub-millicent remainder of each term and undercount by up to one
    millicent per line item — see memory/decisions.md 2026-04-30 for the
    rationale.

    This is the shared helper used by both the bundled-matrix path
    (``compute_cost_millicents``) and the rates-table path
    (``api/services/ingest.compute_cost_from_rate`` /
    ``recompute_cost``). Routing both through here guarantees bit-identical
    cost values across paths for the same token set + rate values.
    """
    numerator = (
        input_tokens * input_rate
        + output_tokens * output_rate
        + thinking_tokens * thinking_rate
        + cache_read_tokens * cache_read_rate
        + cache_write_tokens * cache_write_rate
    )
    return numerator // 1_000_000


def compute_cost_millicents(
    model: str,
    input_tokens: int,
    output_tokens: int,
    thinking_tokens: int,
    cache_read_tokens: int,
    cache_write_tokens: int = 0,
) -> int | None:
    """
    Compute the cost of a request in millicents (1 USD = 100_000 millicents).

    Returns None if the model is not in the bundled pricing matrix
    (unknown model), so that cost_millicents can be stored as NULL in the
    DB rather than incorrectly as 0.

    Resolution order:
      1. ``ANTHROPIC_RATES`` — all Claude/Anthropic models.
      2. ``GEMINI_TIERED_RATES`` — Gemini models with a >200k token surcharge.
         Tier selected at call time: input_tokens > threshold → high_context;
         otherwise → standard. Both are ``ModelRates`` instances; routing
         then falls through to the shared ``apply_rates`` call.
      3. ``GEMINI_RATES`` — remaining single-tier Gemini models.
      4. Return None (unknown model).

    Args:
        model: The model identifier string (e.g. 'claude-sonnet-4-6').
        input_tokens: Prompt tokens including system and tools.
        output_tokens: Completion tokens.
        thinking_tokens: Extended thinking / reasoning tokens.
        cache_read_tokens: Cache-read tokens (priced lower than fresh input).
        cache_write_tokens: Cache-write tokens (Anthropic
            ``cache_creation_input_tokens``; priced at 1.25x input by
            default — see ``pricing/matrix.py`` for the TTL note).

    Returns:
        Cost in millicents as an integer, or None if model is unknown.
    """
    # 1. Anthropic/Claude models.
    rates = ANTHROPIC_RATES.get(model)

    # 2. Tiered Gemini models (gemini-3.1-pro-preview, gemini-2.5-pro).
    if rates is None:
        tiered = GEMINI_TIERED_RATES.get(model)
        if tiered is not None:
            # Tier boundary is exclusive: >200k = high_context, ≤200k = standard.
            rates = (
                tiered.high_context
                if input_tokens > tiered.threshold_tokens
                else tiered.standard
            )

    # 3. Single-tier Gemini models.
    if rates is None:
        rates = GEMINI_RATES.get(model)

    # 4. OpenAI models (single tier; reasoning tokens billed at output rate
    # via ModelRates.thinking == output for every entry in OPENAI_RATES).
    if rates is None:
        rates = OPENAI_RATES.get(model)

    # 5. xAI / Grok models (single tier; no caching, no reasoning today).
    if rates is None:
        rates = XAI_RATES.get(model)

    # 6. Unknown model — caller stores NULL rather than a wrong 0.
    if rates is None:
        return None

    return apply_rates(
        input_tokens=input_tokens,
        input_rate=rates.input,
        output_tokens=output_tokens,
        output_rate=rates.output,
        thinking_tokens=thinking_tokens,
        thinking_rate=rates.thinking,
        cache_read_tokens=cache_read_tokens,
        cache_read_rate=rates.cache_read,
        cache_write_tokens=cache_write_tokens,
        cache_write_rate=rates.cache_write,
    )
