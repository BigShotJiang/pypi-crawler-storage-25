"""
TEMP-PHASE-0: Hardcoded Anthropic + Gemini pricing matrix for Phase 0 only.

This module will be removed when the backend takes over cost computation
in Phase 1. Tracked in memory/decisions.md 2026-04-28.

Rates are in millicents per million tokens (1 USD = 100_000 millicents,
so $3.00/MTok = 300_000 millicents/MTok).

Decision reference: memory/decisions.md 2026-04-28 — "Daemon Phase 0
computes cost locally"

Source: 2026-05-01.
  Anthropic: https://www.anthropic.com/api (and https://claude.com/pricing)
  Google Gemini: https://ai.google.dev/gemini-api/docs/pricing

Format per model entry:
  "model-id": ModelRates(
      input=<millicents per million input tokens>,
      output=<millicents per million output tokens>,
      thinking=<millicents per million thinking/reasoning tokens>,
      cache_read=<millicents per million cache-read tokens>,
      cache_write=<millicents per million cache-write tokens>,
  )

Gemini tiered-pricing (added v0.1.12):
  Two Gemini models publish a >200k-token surcharge. ``GeminiTieredRates``
  holds both the standard (≤200k) and high_context (>200k) ``ModelRates``
  alongside the threshold. ``compute_cost_millicents`` inspects
  ``input_tokens`` at call time and selects the correct tier.
  See memory/decisions.md 2026-05-01 — "Gemini tier surcharge —
  request-time resolution".

Gemini multimodal rates (added v0.1.12):
  ``GeminiModalRates`` records audio and image-generation per-MTok rates
  for models that support them. These are informational for v0.1.12 —
  the text-only cost path (``compute_cost_millicents``) does not yet
  dispatch on modality, as the schema has no separate audio/image columns.
  Future work: add token columns + dispatch in the cost path.

────────────────────────────────────────────────────────────────────────────
Cache-write TTL limitation (recorded 2026-04-30; decisions.md "Cache token
accounting: rename `cached_tokens`, single `cache_write` field, defer TTL
split"):

1. Anthropic's response usage object surfaces **one** cache-write field —
   ``usage.cache_creation_input_tokens``. There is no 5m/1h split in the
   response. TTL is set request-side via ``cache_control`` blocks in the
   messages array; it is not echoed in the response.

2. Chosen rate: ``cache_write = 1.25 x input``, the documented Anthropic
   5m-default ephemeral cache-write rate. Single field, single rate.

3. 1h-TTL undercount: requests using a 1h ephemeral cache TTL are billed
   by Anthropic at 2x input but logged here at 1.25x input — an accepted
   undercount until Anthropic exposes the TTL split in response usage.
   The undercount must be disclosed in user-facing reports once we have
   any 1h-TTL users (product-copy task, tracked separately).

4. Deferred extension point — when Anthropic exposes a structured split
   (e.g. ``usage.cache_creation = {"ephemeral_5m": …, "ephemeral_1h": …}``):
       (a) ``ResponseMetadata`` adds ``cache_write_5m_tokens`` and
           ``cache_write_1h_tokens`` (replacing the single
           ``cache_write_tokens`` field, or alongside it during a
           transition window).
       (b) ``ModelRates`` adds a ``cache_write_1h`` rate (the existing
           ``cache_write`` becomes the 5m rate).
       (c) One additive schema migration adds two columns to ``requests``
           and one column to ``pricing_rates`` (gated by
           ``PRAGMA user_version``).
       (d) The Anthropic adapter extracts the structured ``usage.cache_creation``
           dict instead of the single ``cache_creation_input_tokens`` field.
   This is contained in scope: one adapter change + one schema migration.
────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from dataclasses import dataclass, field

# ────────────────────────────────────────────────────────────────────────────
# BUNDLED_RATES_DATE — the ISO-8601 date the bundled pricing matrix below
# was last verified against the providers' public price pages.
#
# Layer 1 of the pricing-freshness model (v0.1.22.22):
#   * Surfaced in `halton-meter report` headers as "Rates: bundled YYYY-MM-DD".
#   * Stamped on every request row as `rates_source = "bundled-YYYY-MM-DD"`
#     when the cost is computed against a seed pricing_rates row (rather
#     than an operator override). Provides per-request audit traceability.
#   * Consulted by the Layer 3 freshness probe (`halton-meter doctor`) to
#     compare against the published `rates-manifest.json`.
#
# Bump this string in lockstep with any rate change above. The tests in
# tests/test_pricing_freshness.py assert it is a valid ISO-8601 date and
# round-trips through the `rates_source` field.
# ────────────────────────────────────────────────────────────────────────────
BUNDLED_RATES_DATE: str = "2026-05-01"


@dataclass(frozen=True)
class ModelRates:
    """Pricing rates for a single model, in millicents per million tokens."""

    input: int
    """Millicents per million input tokens (prompt + system + tools)."""

    output: int
    """Millicents per million output tokens (completion)."""

    thinking: int
    """Millicents per million thinking/reasoning tokens (same as output for Anthropic)."""

    cache_read: int
    """Millicents per million cache-read tokens."""

    cache_write: int
    """Millicents per million cache-write tokens.

    Initially seeded at 1.25x ``input`` (the Anthropic 5m-default ephemeral
    cache-write rate). See module-level TTL-limitation note above for the
    1h undercount rationale and the deferred extension point.
    """


# TEMP-PHASE-0: Anthropic + Gemini rates as of 2026-05-01.
# $1 USD = 100_000 millicents.
# Rates in millicents per million tokens.
#
# Model                Input $/MTok  Output $/MTok  Thinking $/MTok  Cache read $/MTok
# claude-opus-4-7      $5.00         $25.00         $25.00           $0.50
# claude-opus-4-6      $5.00         $25.00         $25.00           $0.50
# claude-sonnet-4-6    $3.00         $15.00         $15.00           $0.30
# claude-haiku-4-5     $1.00         $5.00          $5.00            $0.10

_MILLICENTS_PER_DOLLAR = 100_000


def _usd(dollars_per_million: float) -> int:
    """Convert USD/MTok rate to millicents/MTok."""
    return round(dollars_per_million * _MILLICENTS_PER_DOLLAR)


ANTHROPIC_RATES: dict[str, ModelRates] = {
    # ----------------------------------------------------------------
    # Claude Opus 4.7 (latest Opus)
    # ----------------------------------------------------------------
    "claude-opus-4-7": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # Dated snapshot alias
    "claude-opus-4-7-20260101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Claude Opus 4.6
    # ----------------------------------------------------------------
    "claude-opus-4-6": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    "claude-opus-4-6-20251101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Claude Sonnet 4.6
    # ----------------------------------------------------------------
    "claude-sonnet-4-6": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-6-20251101": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Claude Haiku 4.5
    # ----------------------------------------------------------------
    "claude-haiku-4-5": ModelRates(
        input=_usd(1.00),
        output=_usd(5.00),
        thinking=_usd(5.00),
        cache_read=_usd(0.10),
        cache_write=_usd(1.00 * 1.25),
    ),
    "claude-haiku-4-5-20251001": ModelRates(
        input=_usd(1.00),
        output=_usd(5.00),
        thinking=_usd(5.00),
        cache_read=_usd(0.10),
        cache_write=_usd(1.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Legacy Opus 4.5 / 4.1 / 4.0 (still in use on some machines)
    # ----------------------------------------------------------------
    "claude-opus-4-5": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    "claude-opus-4-5-20251101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # Opus 4.1 — Anthropic publishes $15/$75 (NOT $5/$25). v0.1.5 → v0.1.10
    # silently shipped a 3x undercount on every Opus 4.1 capture; fixed
    # 2026-05-01 (v0.1.11). cache_read = 10% of input ($1.50/MTok).
    "claude-opus-4-1": ModelRates(
        input=_usd(15.00),
        output=_usd(75.00),
        thinking=_usd(75.00),
        cache_read=_usd(1.50),
        cache_write=_usd(15.00 * 1.25),
    ),
    "claude-opus-4-1-20250805": ModelRates(
        input=_usd(15.00),
        output=_usd(75.00),
        thinking=_usd(75.00),
        cache_read=_usd(1.50),
        cache_write=_usd(15.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Legacy Sonnet 4.5 / 4.0
    # ----------------------------------------------------------------
    "claude-sonnet-4-5": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-5-20250929": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-0": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-20250514": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Deprecated models — still in use on legacy SDKs / pinned configs.
    # Rates frozen at the values Anthropic charges as of 2026-05-01.
    # Listed in claude.com/pricing under "Legacy models".
    # ----------------------------------------------------------------
    # Opus 4 (legacy, pre-4.1)
    "claude-opus-4-0": ModelRates(
        input=_usd(15.00),
        output=_usd(75.00),
        thinking=_usd(75.00),
        cache_read=_usd(1.50),
        cache_write=_usd(15.00 * 1.25),
    ),
    "claude-opus-4-20250514": ModelRates(
        input=_usd(15.00),
        output=_usd(75.00),
        thinking=_usd(75.00),
        cache_read=_usd(1.50),
        cache_write=_usd(15.00 * 1.25),
    ),
    # Sonnet 3.7
    "claude-3-7-sonnet-latest": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-3-7-sonnet-20250219": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    # Haiku 3.5
    "claude-3-5-haiku-latest": ModelRates(
        input=_usd(0.80),
        output=_usd(4.00),
        thinking=_usd(4.00),
        cache_read=_usd(0.08),
        cache_write=_usd(0.80 * 1.25),
    ),
    "claude-3-5-haiku-20241022": ModelRates(
        input=_usd(0.80),
        output=_usd(4.00),
        thinking=_usd(4.00),
        cache_read=_usd(0.08),
        cache_write=_usd(0.80 * 1.25),
    ),
    # Opus 3
    "claude-3-opus-latest": ModelRates(
        input=_usd(15.00),
        output=_usd(75.00),
        thinking=_usd(75.00),
        cache_read=_usd(1.50),
        cache_write=_usd(15.00 * 1.25),
    ),
    "claude-3-opus-20240229": ModelRates(
        input=_usd(15.00),
        output=_usd(75.00),
        thinking=_usd(75.00),
        cache_read=_usd(1.50),
        cache_write=_usd(15.00 * 1.25),
    ),
    # Haiku 3
    "claude-3-haiku-20240307": ModelRates(
        input=_usd(0.25),
        output=_usd(1.25),
        thinking=_usd(1.25),
        cache_read=_usd(0.03),
        cache_write=_usd(0.25 * 1.25),
    ),
}


# ────────────────────────────────────────────────────────────────────────────
# Google Gemini rates — added 2026-05-01.
#
# Source: https://ai.google.dev/gemini-api/docs/pricing (operator-pasted
# 2026-05-01).
#
# Tiered-pricing (v0.1.12): gemini-3.1-pro-preview and gemini-2.5-pro have
# a >200k input-token surcharge. The surcharge is handled at request time in
# ``compute_cost_millicents`` via ``GEMINI_TIERED_RATES`` below.
# ``GEMINI_RATES`` keeps the lower-tier (≤200k) defaults; they are the
# canonical standard-tier values and are also stored in the ``standard``
# field of each ``GeminiTieredRates`` entry.
#
# Multimodal-pricing (v0.1.12): Audio/image rates are in ``GEMINI_MODAL_RATES``.
# They are informational for this cycle — the cost path is text-only.
#
# Verified 2026-05-02 against https://ai.google.dev/pricing
# (multi-provider PR3): all model entries below match the published rates;
# tiered (>200k) and modal (audio/image) rates also unchanged. No drift.
# ────────────────────────────────────────────────────────────────────────────
GEMINI_RATES: dict[str, ModelRates] = {
    # Gemini 3.1 Pro (preview) — $2/$12 (≤200k) | $4/$18 (>200k).
    # High-context tier handled in GEMINI_TIERED_RATES.
    "gemini-3.1-pro-preview": ModelRates(
        input=_usd(2.00),
        output=_usd(12.00),
        thinking=_usd(12.00),
        cache_read=_usd(0.50),
        cache_write=_usd(2.00 * 1.25),
    ),
    # Gemini 3.1 Flash Lite (preview) — $0.25/$1.50, single tier.
    "gemini-3.1-flash-lite-preview": ModelRates(
        input=_usd(0.25),
        output=_usd(1.50),
        thinking=_usd(1.50),
        cache_read=_usd(0.025),
        cache_write=_usd(0.25 * 1.25),
    ),
    # Gemini Code Assist SKUs — canonical id confirmed dev4 (2026-05-04).
    #
    # Real-traffic confirmation from the dev3 wheel's
    # ``adapter.gemini_code_assist.model_observed`` log lines
    # (e.g. ``~/.halton-meter/daemon.out.log`` 2026-05-04 17:37:44+):
    # the canonical on-the-wire SKU id under
    # ``cloudcode-pa.googleapis.com/v1internal:streamGenerateContent``
    # is ``gemini-3-flash-preview``. Confirmed: the dev2 best-guess
    # was right; the SKU id used inside Code Assist matches the one
    # surfaced in the gemini-cli UI summary.
    #
    # Source-of-rates rationale: as of 2026-05-04 Google's public
    # Gemini API pricing page (https://ai.google.dev/gemini-api/
    # docs/pricing) does NOT list ``gemini-3-flash-preview`` — it
    # is a Code Assist preview alias and has no published per-token
    # rate. The closest comparable seeded tier in this matrix is
    # ``gemini-3.1-flash-lite-preview`` ($0.25 in / $1.50 out /
    # $0.025 cache_read), the cheapest published Flash-class
    # preview. Code Assist users on the free / quota tier have a
    # cost-to-them of $0; the rates here are the transparency-as-
    # feature opportunity-cost figure — what the same workload
    # would cost on the public Gemini API at the closest matched
    # tier (see CLAUDE.md).
    #
    # Update path: when Google publishes API rates for
    # ``gemini-3-flash-preview`` (or reconciliation against a real
    # Gemini API invoice gives ground truth), the two entries
    # below become a one-line rate update.
    "gemini-3-flash-preview": ModelRates(
        input=_usd(0.25),
        output=_usd(1.50),
        thinking=_usd(1.50),
        cache_read=_usd(0.025),
        cache_write=_usd(0.25 * 1.25),
    ),
    # Adapter fallback row — emitted when the request body has no
    # recognisable model field. Held at the same flash-lite-tier
    # rate as ``gemini-3-flash-preview`` (NOT zero) so a novel
    # Code Assist SKU we haven't seeded does not silently land at
    # $0 in cost reports.
    "gemini-code-assist-unknown": ModelRates(
        input=_usd(0.25),
        output=_usd(1.50),
        thinking=_usd(1.50),
        cache_read=_usd(0.025),
        cache_write=_usd(0.25 * 1.25),
    ),
    # Gemini 3.1 Flash Live (preview) — text $0.75 in / $4.50 out.
    # Audio rates ($3/$12) are in GEMINI_MODAL_RATES.
    "gemini-3.1-flash-live-preview": ModelRates(
        input=_usd(0.75),
        output=_usd(4.50),
        thinking=_usd(4.50),
        cache_read=_usd(0.075),
        cache_write=_usd(0.75 * 1.25),
    ),
    # Gemini 3.1 Flash Image (preview) — text $0.50 in / $3 out.
    # Image-generation rate ($60/MTok) is in GEMINI_MODAL_RATES.
    "gemini-3.1-flash-image-preview": ModelRates(
        input=_usd(0.50),
        output=_usd(3.00),
        thinking=_usd(3.00),
        cache_read=_usd(0.05),
        cache_write=_usd(0.50 * 1.25),
    ),
    # Gemini 2.5 Pro — $1.25/$10 (≤200k) | $2.50/$15 (>200k).
    # High-context tier handled in GEMINI_TIERED_RATES.
    "gemini-2.5-pro": ModelRates(
        input=_usd(1.25),
        output=_usd(10.00),
        thinking=_usd(10.00),
        cache_read=_usd(0.31),
        cache_write=_usd(1.25 * 1.25),
    ),
}


# ────────────────────────────────────────────────────────────────────────────
# Gemini tiered rates (v0.1.12) — request-time tier resolution.
#
# Decision: memory/decisions.md 2026-05-01 — "Gemini tier surcharge —
# request-time resolution, not separate rate rows".
#
# Two models publish a >200k input-token surcharge. ``GeminiTieredRates``
# encapsulates both tiers. ``compute_cost_millicents`` selects the correct
# ``ModelRates`` based on ``input_tokens > threshold_tokens`` at call time.
# ────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GeminiTieredRates:
    """Tiered pricing for a Gemini model with a token-count surcharge.

    ``standard`` applies when input_tokens <= threshold_tokens.
    ``high_context`` applies when input_tokens > threshold_tokens.
    """

    standard: ModelRates
    """Rates for requests at or below the token threshold (≤200k)."""

    high_context: ModelRates
    """Surcharge rates for requests above the token threshold (>200k)."""

    threshold_tokens: int = field(default=200_000)
    """Token count above which high_context rates apply (exclusive)."""


GEMINI_TIERED_RATES: dict[str, GeminiTieredRates] = {
    # gemini-3.1-pro-preview — ≤200k: $2/$12 | >200k: $4/$18
    "gemini-3.1-pro-preview": GeminiTieredRates(
        standard=GEMINI_RATES["gemini-3.1-pro-preview"],
        high_context=ModelRates(
            input=_usd(4.00),
            output=_usd(18.00),
            thinking=_usd(18.00),
            cache_read=_usd(1.00),
            cache_write=_usd(4.00 * 1.25),
        ),
    ),
    # gemini-2.5-pro — ≤200k: $1.25/$10 | >200k: $2.50/$15
    "gemini-2.5-pro": GeminiTieredRates(
        standard=GEMINI_RATES["gemini-2.5-pro"],
        high_context=ModelRates(
            input=_usd(2.50),
            output=_usd(15.00),
            thinking=_usd(15.00),
            cache_read=_usd(0.63),
            cache_write=_usd(2.50 * 1.25),
        ),
    ),
}


# ────────────────────────────────────────────────────────────────────────────
# Gemini multimodal rates (v0.1.12) — informational scaffold.
#
# Records audio and image-generation per-MTok rates for models that support
# them. NOT used by ``compute_cost_millicents`` in v0.1.12 — the schema has
# no separate audio/image token columns yet. Future work: add token columns
# and dispatch modality in the cost path.
# ────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GeminiModalRates:
    """Per-modality rates for a Gemini model, in millicents per million tokens.

    Zero means the modality is not applicable for this model.
    """

    audio_input: int
    """Millicents per million audio input tokens."""

    audio_output: int
    """Millicents per million audio output tokens."""

    image_generation: int
    """Millicents per million image generation tokens (imagen-3 class)."""


GEMINI_MODAL_RATES: dict[str, GeminiModalRates] = {
    # gemini-3.1-flash-live-preview — audio: $3 in / $12 out; no image generation.
    "gemini-3.1-flash-live-preview": GeminiModalRates(
        audio_input=_usd(3.00),
        audio_output=_usd(12.00),
        image_generation=0,
    ),
    # gemini-3.1-flash-image-preview — image generation at $60/MTok (imagen-3 class).
    "gemini-3.1-flash-image-preview": GeminiModalRates(
        audio_input=0,
        audio_output=0,
        image_generation=_usd(60.00),
    ),
}


# ────────────────────────────────────────────────────────────────────────────
# OpenAI rates — added 2026-05-02 (multi-provider PR1).
#
# Source: https://openai.com/api/pricing/ as of 2026-05-02 (operator-pasted).
#
# Cache write: OpenAI auto-manages prompt caches server-side; there is no
# explicit cache-write event. cache_write rate is set to 0 for every model.
# cache_read corresponds to ``usage.prompt_tokens_details.cached_tokens``.
#
# Reasoning tokens (o1 / o1-pro / o3 / o3-mini / o4-mini) are billed by
# OpenAI at the same rate as completion (output) tokens. We surface them as
# ``thinking_tokens`` and set ``ModelRates.thinking == output`` for every
# model below — ``compute_cost_millicents`` then routes thinking_tokens
# through the ``thinking`` rate, producing the correct billed amount.
#
# OpenAI does NOT have Anthropic-style 200k-tier pricing today — flat
# per-model rates. If that changes, extend with a tiered structure
# analogous to ``GEMINI_TIERED_RATES``.
#
# Embedding models: input-only billing (output_tokens is always 0), so the
# output / thinking / cache rates are zero. cache_read is also zero —
# OpenAI does not document caching for embeddings as of 2026-05-02.
# ────────────────────────────────────────────────────────────────────────────


OPENAI_RATES: dict[str, ModelRates] = {
    # ----------------------------------------------------------------
    # GPT-4o family
    # https://openai.com/api/pricing/ as of 2026-05-02
    # gpt-4o:        $2.50 in / $10.00 out / $1.25 cache_read
    # gpt-4o-mini:   $0.15 in / $0.60 out / $0.075 cache_read
    # ----------------------------------------------------------------
    "gpt-4o": ModelRates(
        input=_usd(2.50),
        output=_usd(10.00),
        thinking=_usd(10.00),
        cache_read=_usd(1.25),
        cache_write=0,
    ),
    "gpt-4o-mini": ModelRates(
        input=_usd(0.15),
        output=_usd(0.60),
        thinking=_usd(0.60),
        cache_read=_usd(0.075),
        cache_write=0,
    ),
    # ----------------------------------------------------------------
    # GPT-4.1 family
    # https://openai.com/api/pricing/ as of 2026-05-02
    # gpt-4.1:       $2.00 in / $8.00 out / $0.50 cache_read
    # gpt-4.1-mini:  $0.40 in / $1.60 out / $0.10 cache_read
    # gpt-4.1-nano:  $0.10 in / $0.40 out / $0.025 cache_read
    # ----------------------------------------------------------------
    "gpt-4.1": ModelRates(
        input=_usd(2.00),
        output=_usd(8.00),
        thinking=_usd(8.00),
        cache_read=_usd(0.50),
        cache_write=0,
    ),
    "gpt-4.1-mini": ModelRates(
        input=_usd(0.40),
        output=_usd(1.60),
        thinking=_usd(1.60),
        cache_read=_usd(0.10),
        cache_write=0,
    ),
    "gpt-4.1-nano": ModelRates(
        input=_usd(0.10),
        output=_usd(0.40),
        thinking=_usd(0.40),
        cache_read=_usd(0.025),
        cache_write=0,
    ),
    # ----------------------------------------------------------------
    # Reasoning models (o1 / o1-pro / o3 / o3-mini / o4-mini)
    # https://openai.com/api/pricing/ as of 2026-05-02
    # Reasoning tokens billed at the output rate (per OpenAI docs).
    # o1:        $15.00 in  / $60.00 out  / $7.50 cache_read
    # o1-pro:    $150.00 in / $600.00 out / no cache
    # o3:        $10.00 in  / $40.00 out  / $2.50 cache_read
    # o3-mini:   $1.10 in   / $4.40 out   / $0.55 cache_read
    # o4-mini:   $1.10 in   / $4.40 out   / $0.275 cache_read
    # ----------------------------------------------------------------
    "o1": ModelRates(
        input=_usd(15.00),
        output=_usd(60.00),
        thinking=_usd(60.00),
        cache_read=_usd(7.50),
        cache_write=0,
    ),
    "o1-pro": ModelRates(
        input=_usd(150.00),
        output=_usd(600.00),
        thinking=_usd(600.00),
        cache_read=0,
        cache_write=0,
    ),
    "o3": ModelRates(
        input=_usd(10.00),
        output=_usd(40.00),
        thinking=_usd(40.00),
        cache_read=_usd(2.50),
        cache_write=0,
    ),
    "o3-mini": ModelRates(
        input=_usd(1.10),
        output=_usd(4.40),
        thinking=_usd(4.40),
        cache_read=_usd(0.55),
        cache_write=0,
    ),
    "o4-mini": ModelRates(
        input=_usd(1.10),
        output=_usd(4.40),
        thinking=_usd(4.40),
        cache_read=_usd(0.275),
        cache_write=0,
    ),
    # ----------------------------------------------------------------
    # Legacy chat
    # https://openai.com/api/pricing/ as of 2026-05-02
    # gpt-3.5-turbo: $0.50 in / $1.50 out / no cache
    # ----------------------------------------------------------------
    "gpt-3.5-turbo": ModelRates(
        input=_usd(0.50),
        output=_usd(1.50),
        thinking=_usd(1.50),
        cache_read=0,
        cache_write=0,
    ),
    # ----------------------------------------------------------------
    # Embeddings — input-only billing.
    # https://openai.com/api/pricing/ as of 2026-05-02
    # text-embedding-3-large: $0.13 / MTok
    # text-embedding-3-small: $0.02 / MTok
    # text-embedding-ada-002: $0.10 / MTok
    # ----------------------------------------------------------------
    "text-embedding-3-large": ModelRates(
        input=_usd(0.13),
        output=0,
        thinking=0,
        cache_read=0,
        cache_write=0,
    ),
    "text-embedding-3-small": ModelRates(
        input=_usd(0.02),
        output=0,
        thinking=0,
        cache_read=0,
        cache_write=0,
    ),
    "text-embedding-ada-002": ModelRates(
        input=_usd(0.10),
        output=0,
        thinking=0,
        cache_read=0,
        cache_write=0,
    ),
    # ----------------------------------------------------------------
    # OpenAI Codex backend SKUs — added 2026-05-04 (v0.1.19.dev4).
    #
    # ADR: memory/decisions.md 2026-05-04 dev4 entry. The 6 SKUs
    # below are the ones the user observed being returned from
    # ``GET chatgpt.com/backend-api/codex/models`` (the SKU
    # catalogue endpoint) when running ``@openai/codex`` v0.128.0.
    # The classic-API ChatGPT-plan-bundled tunnelling means
    # cost-to-the-user is folded into the ChatGPT subscription;
    # the rates here are the transparency-as-feature opportunity-
    # cost figure — what the same workload would cost if billed
    # against the public OpenAI API.
    #
    # Source-of-rates rationale: as of 2026-05-04 the public OpenAI
    # API pricing page (https://openai.com/api/pricing/) does NOT
    # list any of these ``gpt-5.x`` SKUs — they are ChatGPT-backend-
    # only IDs and have no published per-token rate. We therefore
    # map each one to the closest comparable tier already in
    # OPENAI_RATES above (drawn from the published 2026-05-02
    # snapshot) and document the mapping below. When OpenAI
    # publishes API rates for these SKUs (or when reconciliation
    # against a real OpenAI API invoice gives ground truth), each
    # entry becomes a one-line rate update.
    #
    # SKU                    Mapped to       Rationale
    # ─────────────────────  ──────────────  ────────────────────────
    # gpt-5.5                gpt-4.1 tier    Latest flagship in the
    #                                        catalogue list — same
    #                                        position gpt-4.1 holds
    #                                        in the public API.
    # gpt-5.4                gpt-4.1 tier    Previous-gen flagship —
    #                                        OpenAI historically
    #                                        prices N and N-1 the
    #                                        same on flagship.
    # gpt-5.4-mini           gpt-4.1-mini    Mini-tier of 5.4 — maps
    #                                        to gpt-4.1-mini (the
    #                                        published mini tier).
    # gpt-5.3-codex          gpt-4.1 tier    Coding-specialised but
    #                                        OpenAI does not price
    #                                        coding variants higher
    #                                        than the base flagship
    #                                        on the public API.
    # gpt-5.2                gpt-4.1 tier    Older flagship in the
    #                                        list — same flagship
    #                                        per-token price.
    # codex-auto-review      gpt-4.1-mini    Background review
    #                                        utility; bulk-task tier
    #                                        — maps to mini, the
    #                                        cheapest-per-quality
    #                                        tier in the lineup.
    # codex-unknown          gpt-4.1 tier    Adapter fallback when
    #                                        the request body has
    #                                        no recognisable model
    #                                        id. Mid-flagship
    #                                        ensures we don't
    #                                        under-report on novel
    #                                        SKUs that haven't been
    #                                        seeded yet.
    # ----------------------------------------------------------------
    "gpt-5.5": ModelRates(
        input=_usd(2.00),
        output=_usd(8.00),
        thinking=_usd(8.00),
        cache_read=_usd(0.50),
        cache_write=0,
    ),
    "gpt-5.4": ModelRates(
        input=_usd(2.00),
        output=_usd(8.00),
        thinking=_usd(8.00),
        cache_read=_usd(0.50),
        cache_write=0,
    ),
    "gpt-5.4-mini": ModelRates(
        input=_usd(0.40),
        output=_usd(1.60),
        thinking=_usd(1.60),
        cache_read=_usd(0.10),
        cache_write=0,
    ),
    "gpt-5.3-codex": ModelRates(
        input=_usd(2.00),
        output=_usd(8.00),
        thinking=_usd(8.00),
        cache_read=_usd(0.50),
        cache_write=0,
    ),
    "gpt-5.2": ModelRates(
        input=_usd(2.00),
        output=_usd(8.00),
        thinking=_usd(8.00),
        cache_read=_usd(0.50),
        cache_write=0,
    ),
    "codex-auto-review": ModelRates(
        input=_usd(0.40),
        output=_usd(1.60),
        thinking=_usd(1.60),
        cache_read=_usd(0.10),
        cache_write=0,
    ),
    # Adapter fallback model id — emitted when the request body has
    # no ``model`` field. Kept at the gpt-4.1 mid-flagship tier (NOT
    # zero) so a novel SKU we haven't seeded does not silently land
    # at $0 in cost reports. Matches the closest comparable
    # observable Codex SKU (``gpt-5.5`` / ``gpt-5.4`` / ``gpt-5.2``
    # / ``gpt-5.3-codex``) — most Codex traffic is flagship-class.
    "codex-unknown": ModelRates(
        input=_usd(2.00),
        output=_usd(8.00),
        thinking=_usd(8.00),
        cache_read=_usd(0.50),
        cache_write=0,
    ),
}


# ────────────────────────────────────────────────────────────────────────────
# xAI (Grok) rates — added 2026-05-02 (multi-provider PR4).
#
# Source: https://docs.x.ai/docs/models and https://x.ai/api as of 2026-05-02.
#
# xAI exposes BOTH an OpenAI-compatible /v1/chat/completions surface AND an
# Anthropic-compatible /v1/messages surface on the same host (api.x.ai). The
# adapter URL-dispatches to sibling parsers; the rates table is shared across
# both shapes — pricing is per-model, not per-API-shape.
#
# No prompt caching today: cache_read = cache_write = 0 for every model.
#   (xAI may add caching later — extend in place when usage shape changes.)
#
# No reasoning tokens today: Grok does not surface reasoning the way o-series
# does. ``thinking`` is set equal to ``output`` for every model anyway,
# matching the OpenAI / Gemini convention — harmless given thinking_tokens
# will always be 0 on xAI responses, but means a future Grok reasoning model
# would be billed correctly without a rate-table change.
#
# Models intentionally OMITTED:
#   * grok-beta            — deprecated by xAI in 2025-Q4; no longer accepted
#                            by the API. Don't ship rates for dead models.
#   * grok-vision-beta     — deprecated alongside grok-beta.
#
# No tiered pricing today (no >Nk surcharge).
# ────────────────────────────────────────────────────────────────────────────


XAI_RATES: dict[str, ModelRates] = {
    # ----------------------------------------------------------------
    # Grok 4 family
    # https://docs.x.ai/docs/models as of 2026-05-02
    # grok-4:        $3.00 in / $15.00 out
    # grok-4-mini:   $0.30 in / $0.50 out
    # ----------------------------------------------------------------
    "grok-4": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=0,
        cache_write=0,
    ),
    "grok-4-mini": ModelRates(
        input=_usd(0.30),
        output=_usd(0.50),
        thinking=_usd(0.50),
        cache_read=0,
        cache_write=0,
    ),
    # ----------------------------------------------------------------
    # Grok 3 family
    # https://docs.x.ai/docs/models as of 2026-05-02
    # grok-3:           $3.00 in  / $15.00 out
    # grok-3-mini:      $0.30 in  / $0.50 out
    # grok-3-fast:      $5.00 in  / $25.00 out
    # grok-3-mini-fast: $0.60 in  / $4.00 out
    # ----------------------------------------------------------------
    "grok-3": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=0,
        cache_write=0,
    ),
    "grok-3-mini": ModelRates(
        input=_usd(0.30),
        output=_usd(0.50),
        thinking=_usd(0.50),
        cache_read=0,
        cache_write=0,
    ),
    "grok-3-fast": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=0,
        cache_write=0,
    ),
    "grok-3-mini-fast": ModelRates(
        input=_usd(0.60),
        output=_usd(4.00),
        thinking=_usd(4.00),
        cache_read=0,
        cache_write=0,
    ),
    # ----------------------------------------------------------------
    # Grok 2 vision (legacy but still served as of 2026-05-02)
    # https://docs.x.ai/docs/models as of 2026-05-02
    # grok-2-vision-1212: $2.00 in / $10.00 out
    # ----------------------------------------------------------------
    "grok-2-vision-1212": ModelRates(
        input=_usd(2.00),
        output=_usd(10.00),
        thinking=_usd(10.00),
        cache_read=0,
        cache_write=0,
    ),
}
