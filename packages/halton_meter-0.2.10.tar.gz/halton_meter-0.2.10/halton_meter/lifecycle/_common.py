"""Platform-agnostic helpers for ``halton_meter.lifecycle``.

Currently empty by design — the v0.1.22 per-OS module refactor was a
pure structural decoupling (zero behavior change). Cross-platform
helpers (HealthSummary, _http_probe_health, etc.) currently live in
``_macos.py`` and will migrate here lazily as Linux work in v0.1.23+
needs to share them. See
``memory/plans/2026-05-05-per-os-module-refactor.md``.
"""

from __future__ import annotations
