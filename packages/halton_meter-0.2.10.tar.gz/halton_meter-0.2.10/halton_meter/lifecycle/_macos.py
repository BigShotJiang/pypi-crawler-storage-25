"""Lifecycle CLI orchestrator: ``halton-meter start | stop | status`` (Phase 2B.8).

Wraps ``launchctl load|unload|list`` (macOS) / ``systemctl --user`` (Linux)
into ergonomic commands that close the gaps left by ``install`` / ``uninstall``:

* ``start`` is "I want metering on without re-running the cert + proxy
  setup steps". Refuses up-front if the daemon's ports are held by an
  unrelated process; reuses ``init._detect_live_daemon`` for the
  already-loaded check; verifies ``/health`` comes up before claiming
  success.
* ``stop`` is "I want metering paused without losing my install state".
  Unloads both plists, then absorbs the manual
  ``lsof -ti :8765 | xargs kill -9`` recovery dance if any zombie still
  holds the ports. Does NOT touch the system proxy (that's
  ``uninstall``'s load-bearing recovery line).
* ``status`` is the single-pane "is metering working?" view. Reports
  daemon, watchdog, system proxy, sentinel, cert trust, and latest
  capture state in a Rich table or as JSON via ``--json``.

Pure orchestrator — no new functionality lives here that isn't a thin
wrapper over existing modules. Each public entry point returns a process
exit code. macOS is the priority path; Linux is best-effort via
systemctl --user; Windows prints "not yet supported".
"""

from __future__ import annotations

import datetime as _datetime
import json as _json
import os
import signal as _signal
import sqlite3
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog
from rich.console import Console

_log = structlog.get_logger("halton_meter.lifecycle")

# Panel / Table now come from halton_meter.branding via brand_panel /
# brand_table builders — keeps visual tokens unified across surfaces.
from halton_meter.config import (
    load_config,  # noqa: F401 — kept for tests that monkeypatch lifecycle._macos.load_config
)
from halton_meter.init import (
    _detect_live_daemon,  # noqa: F401 — re-exported for tests / external callers
)
from halton_meter.install import (
    _EDGE_LABEL,
    _LABEL,
    _LINUX_UNIT_NAME,
    _LINUX_WATCHDOG_UNIT_NAME,
    _USERENV_LABEL,
    _WATCHDOG_LABEL,
    _linux_unit_path,
    _linux_watchdog_unit_path,
    _macos_edge_plist_path,
    _macos_paths,
    _macos_watchdog_plist_path,
    _proxy_managed_sentinel_path,
)
from halton_meter.port_alloc import (
    load_effective_config,
    resolve_effective_port_ground_truth,
)

# Exit codes
_EXIT_OK = 0
_EXIT_FAILED = 1


# --------------------------------------------------------------------------- #
# launchctl helpers                                                            #
# --------------------------------------------------------------------------- #


def _launchctl_label_pid(label: str) -> int | None:
    """Return the PID launchctl reports for ``label``, or None if unknown / not running.

    Modern macOS surfaces the PID via ``launchctl list <label>`` as a
    plist-like fragment containing ``"PID" = <int>;``. When the label
    is registered but not currently running launchctl prints ``"PID"
    = -;`` or omits the key entirely. When the label is unknown
    launchctl exits non-zero.
    """
    if sys.platform != "darwin":
        return None
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        # `"PID" = 81234;`  (running)   or  `"PID" = -;`  (not running)
        if line.startswith('"PID"'):
            _, _, rhs = line.partition("=")
            value = rhs.strip().rstrip(";").strip()
            if value == "-" or not value:
                return None
            try:
                return int(value)
            except ValueError:
                return None
    return None


def _launchctl_label_known(label: str) -> bool:
    """Return True iff ``launchctl list <label>`` exits 0 (label is registered)."""
    if sys.platform != "darwin":
        return False
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


# --------------------------------------------------------------------------- #
# Modern launchctl verbs (v0.1.21.2)                                           #
#                                                                              #
# v0.1.21 introduced manual-start by setting ``RunAtLoad=False`` on the daemon #
# + watchdog plists. The legacy ``launchctl load -w`` path that ``start`` /    #
# ``init`` relied on then became a silent no-op: ``-w`` only clears a          #
# "Disabled" override, it does NOT override ``RunAtLoad``. Net effect          #
# observed in the v0.1.21.1 reboot soak: ``halton-meter start`` registered    #
# the label but never started the process — zero ``daemon.startup.phase       #
# phase=entered`` events between manual invocation and re-issue.              #
#                                                                              #
# Modern macOS (10.10+) requires ``launchctl bootstrap`` to register a job    #
# in a domain and ``launchctl kickstart`` to force an immediate start         #
# (regardless of ``RunAtLoad``). All deployment targets satisfy this; we do   #
# not version-detect.                                                         #
# --------------------------------------------------------------------------- #


def _gui_uid() -> int | None:
    """Return the gui-domain uid, or None on platforms without geteuid."""
    try:
        return int(os.geteuid())
    except (AttributeError, OSError):
        return None


def _launchctl_bootstrap(plist_path: Path) -> tuple[int, str]:
    """``launchctl bootstrap gui/<uid> <plist>`` — modern equivalent of ``load``.

    Idempotent at the call site: bootstrapping an already-loaded label
    returns non-zero with "service already loaded" on stderr; callers
    that pair this with ``_launchctl_kickstart`` get the desired
    "register if needed, then force start" semantics.

    Returns ``(returncode, stderr)`` so callers can log on failure but
    decide whether to continue (e.g. start tolerates already-loaded).
    """
    if sys.platform != "darwin":
        return (0, "")
    uid = _gui_uid()
    if uid is None:
        return (1, "no uid")
    try:
        result = subprocess.run(
            ["launchctl", "bootstrap", f"gui/{uid}", str(plist_path)],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return (1, str(exc))
    return (result.returncode, (result.stderr or "").strip())


def _launchctl_bootout(label: str) -> tuple[int, str]:
    """``launchctl bootout gui/<uid>/<label>`` — modern equivalent of ``unload``.

    Best-effort: a bootout on an unknown label returns non-zero and is
    swallowed by callers (the post-condition "label not loaded" already
    holds).
    """
    if sys.platform != "darwin":
        return (0, "")
    uid = _gui_uid()
    if uid is None:
        return (1, "no uid")
    try:
        result = subprocess.run(
            ["launchctl", "bootout", f"gui/{uid}/{label}"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return (1, str(exc))
    return (result.returncode, (result.stderr or "").strip())


# v0.1.22 hardening: rc=5 EIO retry schedule for ``_launchctl_reload``.
# After bootout completes and the label disappears from the registry,
# ``launchctl bootstrap`` can still return rc=5 ("Input/output error")
# for ~3-5s on first-after-boot init for KeepAlive/RunAtLoad jobs (the
# edge label is the load-bearing case). launchd's internal state for
# auto-start, keep-alive labels takes a beat longer to settle than
# registry visibility. Single 1s retry from v0.1.21.5 wasn't enough on
# every fresh-login path. Schedule: 1s, 2s, 4s (total worst case ~7s
# of sleep + ~2s of bootout polls per retry = ~9s ceiling).
_LAUNCHCTL_RC5_BACKOFF: tuple[float, ...] = (1.0, 2.0, 4.0)
_INSTALL_ERR_LOG = Path.home() / ".halton-meter" / "install.err.log"


def _launchctl_label_loaded(uid: int, label: str) -> tuple[bool, int, str]:
    """``launchctl print gui/<uid>/<label>`` — return (loaded, rc, stderr).

    ``loaded`` is True iff rc == 0. Used both during the bootout
    poll-loop and as the post-failure liveness check that converts a
    bootstrap rc=5 EIO into a success when the label is in fact loaded.
    """
    try:
        probe = subprocess.run(
            ["launchctl", "print", f"gui/{uid}/{label}"],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return (False, 1, str(exc))
    return (probe.returncode == 0, probe.returncode, (probe.stderr or "").strip())


def _bootout_and_wait(uid: int, label: str) -> None:
    """Bootout the label and poll until it disappears (~2s ceiling).

    Best-effort. Bootout on an unknown label returns non-zero and is
    ignored — the post-condition "label is not loaded" already holds.
    The poll covers macOS's async-bootout window (v0.1.21.4): bootout
    returns success immediately but the actual unload finishes in the
    background, and a bootstrap against an in-progress unload returns
    rc=5 EIO.
    """
    try:
        subprocess.run(
            ["launchctl", "bootout", f"gui/{uid}/{label}"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        pass
    for _ in range(20):  # up to ~2s, polled every 100ms
        loaded, _rc, _err = _launchctl_label_loaded(uid, label)
        if not loaded:
            return
        time.sleep(0.1)


def _capture_launchctl_list(label: str) -> tuple[int, str]:
    """``launchctl list <label>`` — return (rc, stdout) for diagnostics."""
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return (1, str(exc))
    return (result.returncode, (result.stdout or "").strip())


def _append_install_err_log(lines: list[str]) -> None:
    """Append diagnostic lines to ``~/.halton-meter/install.err.log``.

    Best-effort — never raise. Mirrors ``install._record_install_error``
    schema (ISO-8601 timestamp + indented payload). We write directly
    rather than importing from ``halton_meter.install`` to avoid the
    circular ``lifecycle <-> install`` dependency.
    """
    try:
        _INSTALL_ERR_LOG.parent.mkdir(parents=True, exist_ok=True)
        with _INSTALL_ERR_LOG.open("a", encoding="utf-8") as fh:
            for line in lines:
                fh.write(line if line.endswith("\n") else line + "\n")
    except OSError:
        pass


def _launchctl_reload(plist_path: Path, label: str) -> tuple[int, str]:
    """Idempotently bootout-then-bootstrap a launchd job.

    v0.1.22 hardening: combines three robustness approaches uniformly
    for all labels.

    A. Exponential backoff on rc=5 (EIO). Up to 3 retries at 1s/2s/4s
       (worst case ~7s of sleep). Other non-zero rcs surface
       immediately. Happy-path (first-attempt success): zero overhead.

    B. Post-failure liveness verification. After exhausting retries,
       if ``launchctl print`` shows the label is in fact loaded, treat
       as success — bootstrap occasionally returns rc=5 even when the
       registration committed.

    C. Bootout + poll-for-disappearance before EVERY attempt (initial
       and each retry). Clears any half-state. The 2s poll ceiling is
       unchanged — backoff retry covers slow unloads.

    D. Hard-failure diagnostics. If all retries fail AND liveness
       confirms NOT loaded, capture ``launchctl print`` rc + stderr,
       ``launchctl list`` output, plist path + mtime, and append to
       ``~/.halton-meter/install.err.log``.

    E. Structured logging via structlog: ``launchctl.bootstrap_attempt``,
       ``launchctl.bootstrap_retry_scheduled``,
       ``launchctl.bootstrap_eio_but_loaded``,
       ``launchctl.bootstrap_exhausted``.

    F. Applies uniformly to all four labels (daemon / watchdog / edge /
       userenv) — no per-label special-cases.
    """
    if sys.platform != "darwin":
        return (0, "")
    uid = _gui_uid()
    if uid is None:
        return (1, "no uid")

    start_time = time.monotonic()
    last_rc = 0
    last_err = ""
    total_attempts = 0

    # Initial attempt (attempt 1) is followed by up to len(backoff)
    # retries — total of 1 + 3 = 4 bootstrap calls in the worst case.
    for attempt in range(1, len(_LAUNCHCTL_RC5_BACKOFF) + 2):
        total_attempts = attempt

        # C. Bootout + poll BEFORE each attempt (initial and retries).
        _bootout_and_wait(uid, label)

        try:
            result = subprocess.run(
                ["launchctl", "bootstrap", f"gui/{uid}", str(plist_path)],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            return (1, str(exc))

        last_rc = result.returncode
        last_err = (result.stderr or "").strip()

        _log.info(
            "launchctl.bootstrap_attempt",
            label=label,
            attempt=attempt,
            rc=last_rc,
            stderr_excerpt=last_err[:200],
        )

        if last_rc == 0:
            return (0, last_err)

        # Non-rc=5 errors fail fast — no retry storm for plist syntax,
        # permissions, etc.
        if last_rc != 5:
            return (last_rc, last_err)

        # rc == 5 (EIO). Schedule retry if budget remains.
        if attempt <= len(_LAUNCHCTL_RC5_BACKOFF):
            sleep_s = _LAUNCHCTL_RC5_BACKOFF[attempt - 1]
            _log.info(
                "launchctl.bootstrap_retry_scheduled",
                label=label,
                attempt=attempt,
                sleep_s=sleep_s,
            )
            # v0.1.22.1 A2: demoted from a plain stderr print to debug.
            # Retry is launchctl mechanism, not user-relevant signal —
            # the live progress UI already shows the install/start phase
            # and a plain print bypassed both that UI and the CLI
            # structlog silencer, leaving raw banner lines mid-install.
            # Set HALTON_DEBUG=1 to surface; otherwise it stays in the
            # structured log file and out of the user's terminal.
            _log.debug(
                "launchctl.bootstrap_rc5_retry_banner",
                label=label,
                attempt=attempt,
                max_attempts=len(_LAUNCHCTL_RC5_BACKOFF),
                sleep_s=sleep_s,
            )
            time.sleep(sleep_s)
            continue

    # All retries exhausted — last_rc is 5.
    elapsed = time.monotonic() - start_time

    # B. Liveness verification. If the label is in fact loaded, the
    # bootstrap succeeded despite the EIO return.
    loaded, print_rc, print_err = _launchctl_label_loaded(uid, label)
    if loaded:
        _log.info(
            "launchctl.bootstrap_eio_but_loaded",
            label=label,
            attempt=total_attempts,
        )
        return (0, last_err)

    _log.error(
        "launchctl.bootstrap_exhausted",
        label=label,
        total_attempts=total_attempts,
        total_elapsed_s=round(elapsed, 3),
    )

    # D. Hard-failure diagnostics → install.err.log.
    list_rc, list_stdout = _capture_launchctl_list(label)
    try:
        plist_mtime = _datetime.datetime.fromtimestamp(
            plist_path.stat().st_mtime, tz=_datetime.UTC
        ).isoformat()
    except OSError:
        plist_mtime = "<unreadable>"
    ts = _datetime.datetime.now(_datetime.UTC).isoformat()
    diag_lines: list[str] = [
        f"{ts} launchctl bootstrap exhausted for {label} "
        f"(attempts={total_attempts}, elapsed_s={elapsed:.3f}, last_rc={last_rc})",
        f"  stderr: {last_err or '<empty>'}",
        f"  plist:  {plist_path}",
        f"  plist_mtime: {plist_mtime}",
        f"  print_rc: {print_rc}",
        f"  print_stderr: {print_err or '<empty>'}",
        f"  list_rc: {list_rc}",
        f"  list_stdout: {list_stdout or '<empty>'}",
    ]
    _append_install_err_log(diag_lines)

    return (last_rc, last_err)


def _launchctl_kickstart(label: str, *, kill_existing: bool = True) -> tuple[int, str]:
    """``launchctl kickstart [-k] gui/<uid>/<label>`` — force the job to start.

    The ``-k`` flag (default) kills any existing instance first, ensuring
    a clean restart; without it kickstart is a no-op when the job is
    already running. Critical for ``RunAtLoad=False`` plists where
    bootstrap alone does not start the process.
    """
    if sys.platform != "darwin":
        return (0, "")
    uid = _gui_uid()
    if uid is None:
        return (1, "no uid")
    args: list[str] = ["launchctl", "kickstart"]
    if kill_existing:
        args.append("-k")
    args.append(f"gui/{uid}/{label}")
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return (1, str(exc))
    return (result.returncode, (result.stderr or "").strip())


def _detect_live_watchdog() -> bool:
    """Return True iff launchctl reports a live watchdog agent (mirror of
    :func:`init._detect_live_daemon`)."""
    if sys.platform != "darwin":
        return False
    try:
        uid = os.getuid()
    except AttributeError:
        return False
    try:
        result = subprocess.run(
            ["launchctl", "print", f"gui/{uid}/{_WATCHDOG_LABEL}"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


# --------------------------------------------------------------------------- #
# Port + process helpers                                                       #
# --------------------------------------------------------------------------- #


def _lsof_pids_on_port(port: int) -> list[int]:
    """Return the list of PIDs holding ``port`` according to ``lsof -ti :<port>``.

    Empty list when nothing is bound (or lsof is unavailable). Caller is
    responsible for distinguishing "managed by us" vs "orphan".

    Note: this matches ALL TCP states (LISTEN + ESTABLISHED + ...). Use
    :func:`_lsof_listen_pids_on_port` when you specifically want to know
    "who is listening on this port" — e.g. ``start``'s pre-flight
    conflict check, where an unrelated client process with a transient
    ``ESTABLISHED`` connection to our edge must NOT be flagged as a
    listener squatter.
    """
    try:
        result = subprocess.run(
            ["lsof", "-ti", f":{port}"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if result.returncode not in (0, 1):
        # rc 1 from lsof can mean "nothing matched" — treat as empty.
        return []
    pids: list[int] = []
    for tok in result.stdout.split():
        try:
            pids.append(int(tok.strip()))
        except ValueError:
            continue
    return pids


def _lsof_listen_pids_on_port(port: int) -> list[int]:
    """Return PIDs LISTENING on ``port`` (TCP, LISTEN state only).

    v0.1.22.1 fix: ``halton-meter start``'s pre-flight conflict check
    must not flag transient TCP client connections as port holders. The
    edge port (8082 default after fallback) sees a steady stream of
    ``ESTABLISHED`` client sockets from any LLM tool currently making a
    request (e.g. Windsurf Helper, Claude Code). The bare ``-i :PORT``
    filter returns those clients alongside the listener, and the start
    pre-flight then refuses with "port held by PID X (Windsurf Helper)"
    on every concurrent request — a daily-driver killer.

    ``-sTCP:LISTEN`` restricts to the listening socket. Empty list when
    nothing is listening (or lsof is unavailable).
    """
    try:
        result = subprocess.run(
            # IMPORTANT: ``-iTCP:{port}`` is ONE selector. Do NOT split into
            # ``-iTCP -i:{port}`` — lsof unions multiple ``-i`` filters
            # (OR-semantics), which causes the result to include every TCP
            # listener on every port AND every socket on this port,
            # constrained only by ``-sTCP:LISTEN`` (which restricts the
            # protocol set to TCP-LISTEN but does NOT re-apply the port
            # filter). Net result of the broken form: this helper returned
            # ALL TCP-LISTEN PIDs on the box regardless of port, and
            # ``halton-meter start`` printed nonsense like "port 8765 is
            # held by PID 606 (ControlCenter)" when ControlCenter listens
            # on :7000/:5000 — just happened to be the lowest-PID listener.
            # The single-flag ``-iTCP:{port}`` form is the canonical idiom
            # documented in lsof(8) for "TCP listeners on a specific port".
            ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if result.returncode not in (0, 1):
        return []
    pids: list[int] = []
    for tok in result.stdout.split():
        try:
            pids.append(int(tok.strip()))
        except ValueError:
            continue
    return pids


def _process_name(pid: int) -> str:
    """Best-effort: return the process name for ``pid`` via ``ps``."""
    try:
        result = subprocess.run(
            ["ps", "-o", "comm=", "-p", str(pid)],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return "unknown"
    name = (result.stdout or "").strip().splitlines()
    if not name:
        return "unknown"
    return name[0].strip() or "unknown"


def _our_managed_pids() -> set[int]:
    """Return the PIDs launchctl reports as belonging to our labels.

    v0.1.21.4: includes edge + userenv labels in addition to daemon +
    watchdog. ``_start_macos`` Step 3 cross-references this set against
    ``lsof``-reported port holders to distinguish "an unrelated
    squatter is on our port" from "our own running edge holds it,
    proceed". Without edge here, a healthy edge running at PID X
    holding the user-facing port (8082 default) showed up as an
    "orphan" and ``halton-meter start`` refused. The userenv label is
    short-lived (one-shot at login) but cheap to include and keeps
    parity with the install-side label list.
    """
    pids: set[int] = set()
    for label in (_LABEL, _WATCHDOG_LABEL, _EDGE_LABEL, _USERENV_LABEL):
        pid = _launchctl_label_pid(label)
        if pid is not None:
            pids.add(pid)
    return pids


# --------------------------------------------------------------------------- #
# /health                                                                     #
# --------------------------------------------------------------------------- #


def _poll_health_with_latency(api_port: int, timeout: float = 1.0) -> tuple[bool, float | None]:
    """Single ``/health`` poll with millisecond latency. ``(healthy, ms)``."""
    import json as _j
    import urllib.error
    import urllib.request

    url = f"http://127.0.0.1:{api_port}/health"
    started = time.monotonic()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if getattr(resp, "status", None) != 200:
                return (False, None)
            body = resp.read()
            try:
                payload = _j.loads(body.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return (False, None)
            ms = (time.monotonic() - started) * 1000.0
            return (
                isinstance(payload, dict) and payload.get("status") == "ok",
                ms,
            )
    except (urllib.error.URLError, TimeoutError, OSError):
        return (False, None)
    except Exception:
        return (False, None)


def _wait_for_health(api_port: int, *, timeout_seconds: float = 15.0) -> tuple[bool, float | None]:
    """Poll /health until healthy or ``timeout_seconds`` elapse.

    Default is 15s (was 5s pre-2B.10.2): Python 3.14 cold-start through
    `halton-meter start`'s `launchctl load` path can take longer than 5s
    on a freshly-booted Mac before uvicorn binds. 15s ceiling matches the
    cadence in 2B.10.1's smoke scripts (which use 10x1s on top of a 1s
    settle). Cold-start is the only realistic regression here; on warm
    starts /health responds in <1s and the wait returns immediately.
    """
    deadline = time.monotonic() + timeout_seconds
    last_ms: float | None = None
    while time.monotonic() < deadline:
        ok, ms = _poll_health_with_latency(api_port, timeout=0.75)
        if ok:
            return (True, ms)
        last_ms = ms
        time.sleep(0.25)
    return (False, last_ms)


# --------------------------------------------------------------------------- #
# MITM listener TCP probe (v0.1.16 Q4.3 — Bug 1 silent-death detection)       #
# --------------------------------------------------------------------------- #


def _probe_mitm_listener(host: str, port: int, *, timeout: float = 0.5) -> bool:
    """Return True iff a TCP connection to ``host:port`` opens within ``timeout``.

    The MITM listener (mitmproxy on the daemon's ``internal_port``) speaks
    proxy CONNECT, NOT raw HTTP — we deliberately do not send any bytes
    here. A successful TCP handshake is the strongest health signal we
    can collect without speaking the protocol.

    Defensive: never raises. Any failure (refused, timeout, OSError,
    DNS failure on a literal IP, anything) returns False so the calling
    `status` command can render a row instead of crashing.

    Bug 1 (2026-05-02 soak): the asyncio MITM acceptor died silently
    while ``/health`` (FastAPI) kept responding. Probing the MITM port
    directly is the only way `status` can surface that state.
    """
    import socket as _socket

    try:
        sock = _socket.create_connection((host, port), timeout=timeout)
    except (OSError, TimeoutError):
        return False
    except Exception:
        return False

    try:
        sock.close()
    except OSError:
        pass
    return True


# --------------------------------------------------------------------------- #
# Cert trust check (delegates to setup module)                                 #
# --------------------------------------------------------------------------- #


def _is_cert_trusted() -> bool:
    """macOS-only cert-trust check; delegates to setup._is_cert_trusted_macos."""
    if sys.platform != "darwin":
        return False
    try:
        from halton_meter.setup import _is_cert_trusted_macos
        return _is_cert_trusted_macos()
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# System proxy state                                                           #
# --------------------------------------------------------------------------- #


def _system_proxy_state(host: str, port: int) -> tuple[str, str]:
    """Return ``(state, detail)`` for the system proxy row.

    States: ``enabled`` (points at us, on) / ``pointed elsewhere``
    (on but address differs) / ``disabled`` (off or absent).
    """
    if sys.platform != "darwin":
        return ("not applicable", "Linux: managed via HTTPS_PROXY env var")
    from halton_meter import system_proxy

    enabled_anywhere = False
    matching_iface: str | None = None
    other_target: str | None = None
    for iface in system_proxy._macos_interfaces():
        for secure in (True, False):
            enabled, current_host, current_port = system_proxy._read_macos_proxy(
                iface, secure=secure
            )
            if not enabled:
                continue
            enabled_anywhere = True
            if system_proxy._proxy_targets_us(current_host, current_port, host, port):
                matching_iface = iface
                break
            if other_target is None and current_host:
                other_target = f"{current_host}:{current_port or '?'}"
        if matching_iface is not None:
            break

    if matching_iface is not None:
        return ("enabled", f"{host}:{port} on {matching_iface}")
    if enabled_anywhere:
        return (
            "pointed elsewhere",
            f"system proxy on but address={other_target or 'unknown'}",
        )
    return ("disabled", "no interface routing through halton-meter")


# --------------------------------------------------------------------------- #
# Effective ports row with auto-fallback marker (v0.1.4 P0-5)                 #
# --------------------------------------------------------------------------- #


def _port_status_row(listen_port: int, api_port: int) -> _ComponentRow:
    """Build the "Effective ports" row, marking auto-fallback explicitly.

    When the proxy listener or HTTP API uses a non-default port (e.g.
    8081 instead of 8080), the detail string includes ``"(fallback
    from busy default 8080)"`` so the user knows their tool config
    must target the actual port, not the marketed default.

    State: ``default`` (both ports at default) / ``fallback`` (at
    least one differs). Both states are non-failing — the row is
    informational, not a health signal.
    """
    from halton_meter.port_alloc import API_PORT_DEFAULT, LISTEN_PORT_DEFAULT

    parts: list[str] = []
    parts.append(f"proxy=:{listen_port}")
    parts.append(f"api=:{api_port}")
    fallback_notes: list[str] = []
    if listen_port != LISTEN_PORT_DEFAULT:
        fallback_notes.append(
            f"proxy fell back from busy default :{LISTEN_PORT_DEFAULT} to :{listen_port}"
        )
    if api_port != API_PORT_DEFAULT:
        fallback_notes.append(
            f"api fell back from busy default :{API_PORT_DEFAULT} to :{api_port}"
        )
    if fallback_notes:
        return _ComponentRow(
            "Effective ports", "fallback", "; ".join(fallback_notes)
        )
    return _ComponentRow(
        "Effective ports", "default", " ".join(parts)
    )


# --------------------------------------------------------------------------- #
# Latest capture (SQLite read)                                                 #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class _LatestCapture:
    found: bool
    db_missing: bool
    timestamp_iso: str | None = None
    seconds_ago: float | None = None
    model: str | None = None
    project: str | None = None
    cost_usd_minor_units: int | None = None
    captured_last_hour: int = 0
    captured_last_day: int = 0


def _latest_capture(db_path: str) -> _LatestCapture:
    """Read the latest capture row + window counts from SQLite. Defensive."""
    from datetime import UTC, datetime

    expanded = Path(db_path).expanduser()
    if not expanded.exists():
        return _LatestCapture(found=False, db_missing=True)

    try:
        conn = sqlite3.connect(f"file:{expanded}?mode=ro", uri=True, timeout=2.0)
    except sqlite3.Error:
        return _LatestCapture(found=False, db_missing=True)

    try:
        cur = conn.cursor()
        try:
            cur.execute(
                "SELECT requested_at, model, project_id, cost_usd_minor_units "
                "FROM requests ORDER BY requested_at DESC LIMIT 1"
            )
            row = cur.fetchone()
        except sqlite3.Error:
            return _LatestCapture(found=False, db_missing=False)

        if row is None:
            return _LatestCapture(found=False, db_missing=False)

        ts_str, model, project_id, cost = row

        seconds_ago: float | None = None
        try:
            ts = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=UTC)
            seconds_ago = (datetime.now(tz=UTC) - ts).total_seconds()
        except (ValueError, TypeError):
            pass

        # Window counts. Use SQLite datetime() arithmetic on the
        # ISO-8601 strings; if requested_at is malformed for some
        # rows the predicate just skips them.
        last_hour = 0
        last_day = 0
        try:
            cur.execute(
                "SELECT COUNT(*) FROM requests WHERE "
                "requested_at >= datetime('now', '-1 hour')"
            )
            last_hour = int(cur.fetchone()[0] or 0)
            cur.execute(
                "SELECT COUNT(*) FROM requests WHERE "
                "requested_at >= datetime('now', '-1 day')"
            )
            last_day = int(cur.fetchone()[0] or 0)
        except sqlite3.Error:
            pass

        # Resolve project slug from id (best-effort).
        project_slug: str | None = None
        try:
            cur.execute("SELECT slug FROM projects WHERE id = ?", (project_id,))
            slug_row = cur.fetchone()
            if slug_row:
                project_slug = str(slug_row[0])
        except sqlite3.Error:
            pass

        return _LatestCapture(
            found=True,
            db_missing=False,
            timestamp_iso=str(ts_str) if ts_str else None,
            seconds_ago=seconds_ago,
            model=str(model) if model else None,
            project=project_slug,
            cost_usd_minor_units=int(cost) if cost is not None else None,
            captured_last_hour=last_hour,
            captured_last_day=last_day,
        )
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass


# --------------------------------------------------------------------------- #
# Status assembly                                                              #
# --------------------------------------------------------------------------- #


@dataclass
class _ComponentRow:
    name: str
    state: str
    detail: str


# v0.1.3 P0-8: mode-aware health summary at the top of `halton-meter status`.
@dataclass
class _HealthSummary:
    """Mode-aware verdict computed from component rows + install mode."""

    severity: str  # "HEALTHY" | "INCONSISTENT" | "BROKEN"
    message: str  # one-line user-facing summary


@dataclass
class _StatusReport:
    healthy: bool
    rows: list[_ComponentRow] = field(default_factory=list)
    last_hour: int = 0
    last_day: int = 0
    platform: str = ""
    health_summary: _HealthSummary | None = None

    def to_json_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "healthy": self.healthy,
            "platform": self.platform,
            "components": [
                {"name": r.name, "state": r.state, "detail": r.detail}
                for r in self.rows
            ],
            "captured_last_hour": self.last_hour,
            "captured_last_day": self.last_day,
        }
        if self.health_summary is not None:
            payload["health_summary"] = {
                "severity": self.health_summary.severity,
                "message": self.health_summary.message,
            }
        return payload


def _detect_sentinel_drift_for_status(install_mode: str | None) -> str | None:
    """v0.1.22.12 Bug 3: probe sentinel-state consistency for the
    status verdict.

    Returns a human-readable BROKEN message describing the drift, or
    ``None`` when the state is consistent (or when probing failed —
    we err on the side of NOT flagging drift in that case so a
    transient FS error doesn't poison the verdict).

    Drift cases (any one fires BROKEN):

    * ``install-mode=apps``  AND ``proxy-managed`` present
    * ``install-mode=full``  AND ``apps-managed`` present
    * both sentinels present (impossible-but-defensive)
    * ``install-mode`` set to apps/full AND neither sentinel present

    Env-only mode and the fresh-machine signature (no install-mode +
    no sentinels) are treated as not-drift; they're handled by other
    branches in :func:`_compute_health_summary_macos`.
    """
    try:
        from halton_meter.setup import (
            APPS_MANAGED_SENTINEL,
            PROXY_MANAGED_SENTINEL,
        )
    except Exception:
        return None

    try:
        proxy_present = PROXY_MANAGED_SENTINEL.exists()
        apps_present = APPS_MANAGED_SENTINEL.exists()
    except Exception:
        return None

    # Both sentinels present — impossible-but-defensive.
    if proxy_present and apps_present:
        return (
            "sentinel drift: both `proxy-managed` and `apps-managed` are "
            "present — install-mode state machine is inconsistent. Run "
            "`halton-meter init --apps` (or `--full`) to reconcile."
        )

    if install_mode == "apps":
        if proxy_present:
            return (
                "sentinel drift: install-mode is `apps` but the "
                "`proxy-managed` sentinel is present (stale full-mode "
                "state). Re-run `halton-meter init --apps` to reconcile."
            )
        if not apps_present:
            return (
                "sentinel drift: install-mode is `apps` but the "
                "`apps-managed` sentinel is missing. Re-run "
                "`halton-meter init --apps` to reconcile."
            )
        return None

    if install_mode == "full":
        if apps_present:
            return (
                "sentinel drift: install-mode is `full` but the "
                "`apps-managed` sentinel is present (stale apps-mode "
                "state). Re-run `halton-meter init --full` to reconcile."
            )
        if not proxy_present:
            return (
                "sentinel drift: install-mode is `full` but the "
                "`proxy-managed` sentinel is missing. Re-run "
                "`halton-meter init --full` to reconcile."
            )
        return None

    # env-only / unknown / None — not drift here. The `unknown mode`
    # branch in _compute_health_summary_macos handles the
    # install-mode-missing case via the existing INCONSISTENT verdict.
    return None


def _compute_health_summary_macos(
    rows: list[_ComponentRow], install_mode: str | None
) -> _HealthSummary:
    """Compute the mode-aware top-line verdict (v0.1.5 (2B.16) three modes).

    Decision matrix:

    * env-only: HEALTHY when daemon healthy + cert trusted. System proxy
      state is informational (we don't manage it in this mode).
    * apps: HEALTHY when daemon + cert trusted AND system proxy is
      DISABLED on our interfaces. System proxy enabled in apps mode is
      DRIFT (BROKEN) — apps mode promises not to manage system proxy.
    * full: HEALTHY when daemon + cert trusted AND system proxy is
      enabled at us. BROKEN if proxy enabled but cert not trusted
      (totaljobs.com cert↔proxy invariant). INCONSISTENT if proxy not
      enabled.
    * unknown mode (sentinel missing): INCONSISTENT to nudge re-init.

    Legacy ``gui`` sentinel value is read by ``init.read_install_mode``
    as the canonical ``full`` — this function only sees canonical
    names.
    """
    by_name = {r.name: r for r in rows}
    daemon = by_name.get("Daemon")
    proxy = by_name.get("System proxy")
    cert = by_name.get("Cert trust")
    mitm = by_name.get("MITM listener")
    edge = by_name.get("Edge")

    edge_stale_chain = edge is not None and edge.state == "stale chain"
    daemon_ok = daemon is not None and daemon.state == "healthy"
    # ``not loaded`` = plist exists, launchctl doesn't know the label
    # (the post-reboot / post-`stop` signature). ``not installed`` is a
    # different case (user has never run init) and stays BROKEN below.
    daemon_unloaded = daemon is not None and daemon.state == "not loaded"
    # v0.1.21.2: ``dormant`` is a distinct state for "label registered
    # in launchctl but no live PID" — the post-reboot signature under
    # manual-start when the plist auto-loaded but RunAtLoad=False
    # prevented the actual exec. Treated as STOPPED in the mode-aware
    # verdict below; would otherwise fall through to BROKEN.
    daemon_dormant = daemon is not None and daemon.state == "dormant"
    cert_trusted = cert is not None and cert.state == "trusted"
    proxy_enabled = proxy is not None and proxy.state == "enabled"
    mitm_unresponsive = mitm is not None and mitm.state == "unresponsive"
    edge_ok = edge is not None and edge.state == "healthy"

    # v0.1.21 (2026-05-05): "STOPPED" is a first-class verdict —
    # distinct from BROKEN. Daemon-not-loaded with edge alive is the
    # EXPECTED state after reboot or `halton-meter stop` under the
    # manual-start architecture. Surfacing it as BROKEN read as a
    # crisis pre-v0.1.21; users got a wall of red on a perfectly
    # well-behaved post-reboot system. STOPPED tells the user the
    # truth: metering is paused, fail-open is intact, run start to
    # resume. See ``decisions.md`` 2026-05-05 — "STOPPED is now a
    # first-class status state".
    #
    # v0.1.21.2: extended to cover the "label registered, no live
    # PID" case (``daemon_dormant``). After reboot the launchd job
    # may be in the registered-but-not-running state and we want the
    # SAME calm verdict, not a BROKEN render.
    if (daemon_unloaded or daemon_dormant) and edge_ok:
        return _HealthSummary(
            "STOPPED",
            "metering paused. Daemon is not running. Edge is tunnelling "
            "traffic un-metered. Run `halton-meter start` to resume "
            "metering.",
        )

    if not daemon_ok:
        return _HealthSummary(
            "BROKEN",
            "daemon is not healthy — run `halton-meter start`",
        )

    # v0.1.21.2: edge ``stale chain`` means edge is alive but pointing
    # at a stale daemon ``internal_port`` — apps see the proxy come up
    # but every CONNECT bypasses metering. Pre-v0.1.21.2 the table
    # flagged this on the Edge row only and the top-line verdict
    # stayed HEALTHY (silent metering loss). Surface as BROKEN so the
    # operator sees the failure mode in the verdict panel itself.
    if edge_stale_chain:
        return _HealthSummary(
            "BROKEN",
            "edge proxy is alive but its chain target points at a stale "
            "daemon port — metering is OFF for new requests. Run "
            "`halton-meter stop && halton-meter start` to reconcile.",
        )

    # v0.1.16 Q4.3 (Bug 1): daemon `/health` UP + MITM listener DOWN is
    # the silent-death signature. Banner precedence: daemon-down >
    # MITM-down > everything else. Surfacing this here makes `status`
    # the definitive single-pane view for the failure mode that bit us
    # in the 0.1.15 soak.
    if mitm_unresponsive:
        mitm_detail = mitm.detail if mitm is not None else ""
        port_str = "?"
        # Best-effort extract `:PORT` from the row detail for the banner.
        if mitm_detail:
            import re as _re

            match = _re.search(r":(\d+)", mitm_detail)
            if match:
                port_str = match.group(1)
        return _HealthSummary(
            "BROKEN",
            f"daemon /health is up but MITM listener on :{port_str} is "
            "unresponsive; metering is OFF. Run `halton-meter restart` "
            "or check ~/.halton-meter/daemon.err.log.",
        )

    # v0.1.22.12 Bug 3: sentinel-state drift detection. If
    # ``install-mode`` disagrees with the on-disk
    # ``proxy-managed`` / ``apps-managed`` sentinels, the install is
    # in an inconsistent state and the verdict must surface BROKEN
    # rather than reporting healthy from the install-mode side alone.
    # Four drift cases:
    #
    #   1. install_mode=apps  AND proxy-managed present
    #   2. install_mode=full  AND apps-managed present
    #   3. both sentinels present
    #   4. install_mode set   AND neither sentinel present (apps/full only)
    #
    # The daemon's heartbeat reconcile (v0.1.22.12 Bug 2) auto-heals
    # this within 30s, but the user may run ``status`` between the
    # leak and the heal — they must see BROKEN, not HEALTHY, in that
    # window. Best-effort: any probe error skips the check rather than
    # falsely flagging drift.
    sentinel_drift_msg = _detect_sentinel_drift_for_status(install_mode)
    if sentinel_drift_msg is not None:
        return _HealthSummary("BROKEN", sentinel_drift_msg)

    if install_mode == "env-only":
        if cert_trusted:
            return _HealthSummary(
                "HEALTHY",
                "env-var-only mode: use `halton-meter run <command>` to meter "
                "Claude Code, SDK clients, etc. For terminal + Spotlight-app "
                "coverage, re-run `halton-meter init --apps`. For broadest "
                "coverage (browsers + GUI apps), re-run "
                "`halton-meter init --full`.",
            )
        return _HealthSummary(
            "BROKEN",
            "cert is not trusted — run `halton-meter setup --force`",
        )

    if install_mode == "apps":
        if not cert_trusted:
            return _HealthSummary(
                "BROKEN",
                "cert is not trusted — run `halton-meter setup --force`",
            )
        if proxy_enabled:
            # Drift: apps mode promises NOT to manage system proxy.
            return _HealthSummary(
                "BROKEN",
                "system proxy is enabled but install-mode is `apps` "
                "(stale full-mode state). Re-run "
                "`halton-meter init --apps` to reconcile.",
            )
        return _HealthSummary(
            "HEALTHY",
            "--apps mode is healthy. New shells + Spotlight-spawned apps are "
            "metered; system proxy is intentionally unmanaged.",
        )

    # Full or unknown mode follows the v0.1.2 invariant: proxy enabled
    # implies cert must be trusted.
    if proxy_enabled and not cert_trusted:
        return _HealthSummary(
            "BROKEN",
            "system proxy enabled but cert is not trusted "
            "(SecTrust will reject TLS) — run `halton-meter reset-proxy`",
        )

    if install_mode == "full":
        if not proxy_enabled:
            return _HealthSummary(
                "INCONSISTENT",
                "--full mode but system proxy not enabled — "
                "run `halton-meter start`",
            )
        if cert_trusted:
            return _HealthSummary("HEALTHY", "--full mode is healthy.")
        return _HealthSummary(
            "BROKEN",
            "--full mode requires cert to be trusted — "
            "run `halton-meter setup --force`",
        )

    # Unknown mode.
    if proxy_enabled and cert_trusted:
        return _HealthSummary(
            "INCONSISTENT",
            "install-mode sentinel missing (older install). "
            "Re-run `halton-meter init` to reconcile.",
        )
    return _HealthSummary(
        "INCONSISTENT",
        "install-mode sentinel missing — run `halton-meter init`.",
    )


def _detect_graceful_uninstall_macos(cfg: Any) -> _StatusReport | None:
    """Detect the post-`uninstall --graceful` state and render a one-row table.

    v0.1.10 Gap 16. After `halton-meter uninstall --graceful` the edge
    process is alive (in pure passthrough), but the daemon and watchdog
    plists are gone, the install-mode sentinel was removed, and the
    edge plist file itself was removed from `~/Library/LaunchAgents/`.
    The standard `_build_status_macos` would render this as a wall of
    "not installed" red and a BROKEN verdict — confusing the user out
    of an explicit, expected state.

    Detection requires ALL FOUR conditions:

    * Edge label has a live PID (via `_launchctl_label_pid`)
    * Daemon label is unknown to launchctl
    * Install-mode sentinel `~/.halton-meter/proxy-managed` is missing
    * Edge plist file is missing from `~/Library/LaunchAgents/`

    All four are necessary because partial states (e.g. only the
    sentinel was deleted) are NOT graceful-uninstall — they are drift
    that should keep going to the standard render so the user sees the
    inconsistency.

    Returns the special `_StatusReport` when matched, else ``None``.
    """
    edge_pid = _launchctl_label_pid(_EDGE_LABEL)
    if edge_pid is None:
        return None
    if _launchctl_label_known(_LABEL):
        return None
    if _proxy_managed_sentinel_path().exists():
        return None
    if _macos_edge_plist_path().exists():
        return None

    detail = (
        f"PID {edge_pid}, port=:{cfg.daemon.edge_port} "
        "(no metering — edge tunnels direct to upstream until next reboot)"
    )
    row = _ComponentRow("Graceful uninstall", "edge in passthrough", detail)
    summary = _HealthSummary(
        "HEALTHY",
        "graceful uninstall is in effect — edge proxy is still running in "
        "pure-passthrough so apps with HTTPS_PROXY baked in keep working. "
        "No metering until next reboot. Re-run `halton-meter init` to "
        "restore metering.",
    )
    return _StatusReport(
        healthy=True,
        rows=[row],
        last_hour=0,
        last_day=0,
        platform="darwin",
        health_summary=summary,
    )


def _build_status_macos(cfg: Any) -> _StatusReport:
    # v0.1.10 Gap 16: pre-empt the standard table when the post-graceful
    # signature is present (edge alive, daemon label unknown, sentinel
    # gone, edge plist gone). Pure rendering pre-emption — the standard
    # path below is unchanged.
    graceful = _detect_graceful_uninstall_macos(cfg)
    if graceful is not None:
        return graceful

    plist_path, _, _ = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()
    sentinel_path = _proxy_managed_sentinel_path()

    rows: list[_ComponentRow] = []
    healthy = True

    # v0.1.22.9 Bug 2: ground-truth port resolution chain. The panel
    # previously trusted ``cfg.daemon.<role>_port`` which silently fell
    # back to the configured default when ``effective-ports.json`` was
    # missing or stale. ``resolve_effective_port`` walks
    # lsof(launchctl-managed-PID) → effective-ports.json → cfg, so the
    # panel reports the actually-bound port even after a
    # stop/start/upgrade cycle that left the JSON unwritten.
    # v0.1.22.15: switch to the freshness-gated ground-truth resolver.
    # The status panel can be invoked seconds after a stop/start cycle
    # in which the new daemon has not yet overwritten
    # ``effective-ports.json``; the freshness gate keeps the panel from
    # trusting a stale pid+port pair from a previous generation. The
    # retry budget is small (one immediate attempt — ``retries=1``) so
    # ``status`` stays snappy when called at idle; the load-bearing
    # behaviour for the race window is the freshness gate, not the
    # retry loop.
    _live_mitm_port = (
        resolve_effective_port_ground_truth(
            role="mitm",
            cfg_value=int(cfg.daemon.internal_port),
            retries=1,
        )
        or int(cfg.daemon.internal_port)
    )
    _live_api_port = (
        resolve_effective_port_ground_truth(
            role="api",
            cfg_value=int(cfg.daemon.api_port),
            retries=1,
        )
        or int(cfg.daemon.api_port)
    )
    _live_edge_port = (
        resolve_effective_port_ground_truth(
            role="edge",
            cfg_value=int(cfg.daemon.edge_port),
            retries=1,
        )
        or int(cfg.daemon.edge_port)
    )

    # Daemon row.
    if not plist_path.exists():
        rows.append(_ComponentRow("Daemon", "not installed", f"{plist_path} missing"))
        healthy = False
    else:
        daemon_pid = _launchctl_label_pid(_LABEL)
        if daemon_pid is None:
            registered = _launchctl_label_known(_LABEL)
            if not registered:
                rows.append(
                    _ComponentRow(
                        "Daemon", "not loaded",
                        f"label {_LABEL} unknown to launchctl",
                    )
                )
                healthy = False
            else:
                # v0.1.21.2: distinct state ``dormant`` for the
                # "registered, no live PID" signature so the verdict
                # logic can promote to STOPPED without confusing it
                # with the "loaded but /health failed" state. Both
                # render as warn icons; semantics diverge in the
                # mode-aware health summary.
                rows.append(
                    _ComponentRow(
                        "Daemon",
                        "dormant",
                        "registered, will start on `halton-meter start`",
                    )
                )
                healthy = False
        else:
            ok, ms = _poll_health_with_latency(_live_api_port)
            if ok:
                latency_str = f"{ms:.0f}ms" if ms is not None else "—"
                rows.append(
                    _ComponentRow(
                        "Daemon",
                        "healthy",
                        # 2C.2 (v0.1.6): the daemon binds internal_port now
                        # — the edge owns the user-facing edge_port. Surface
                        # both in the detail string so operators can tell at
                        # a glance which process they're inspecting.
                        # v0.1.22.9 Bug 2: ports come from the ground-truth
                        # resolution chain (lsof → JSON → cfg) so a stale
                        # ``effective-ports.json`` no longer poisons the panel.
                        f"PID {daemon_pid}, internal=:{_live_mitm_port}, "
                        f"/health OK ({latency_str})",
                    )
                )
            else:
                rows.append(
                    _ComponentRow(
                        "Daemon",
                        "loaded",
                        f"PID {daemon_pid}, internal=:{_live_mitm_port}, "
                        f"/health failed on :{_live_api_port} "
                        f"— may be starting up; wait 30s then retry",
                    )
                )
                healthy = False

    # MITM listener row (v0.1.16 Q4.3, Bug 1). The daemon row only
    # checks `/health` on the FastAPI port — that endpoint can be UP
    # while the mitmproxy listener on `internal_port` has died silently
    # (asyncio task crash, FD exhaustion, etc.). Probe the MITM port
    # directly so `status` surfaces the silent-death gap. Defensive:
    # `_probe_mitm_listener` never raises, and a failure here flips the
    # banner via `_compute_health_summary_macos` precedence — it does
    # not flip individual component rows beyond this one.
    try:
        mitm_host = "127.0.0.1"
        # v0.1.22.9 Bug 2: ground-truth-resolved mitm port.
        mitm_port = int(_live_mitm_port)
        mitm_ok = _probe_mitm_listener(mitm_host, mitm_port)
    except Exception:
        mitm_ok = False
        mitm_port = int(getattr(cfg.daemon, "internal_port", 0) or 0)
    if mitm_ok:
        rows.append(
            _ComponentRow(
                "MITM listener",
                "healthy",
                f"127.0.0.1:{mitm_port} TCP connect OK",
            )
        )
    else:
        rows.append(
            _ComponentRow(
                "MITM listener",
                "unresponsive",
                f"127.0.0.1:{mitm_port} TCP connect failed — "
                f"metering is OFF; check ~/.halton-meter/daemon.err.log",
            )
        )
        healthy = False

    # Watchdog row.
    if not watchdog_plist_path.exists():
        rows.append(_ComponentRow("Watchdog", "not installed", f"{watchdog_plist_path} missing"))
        healthy = False
    else:
        watchdog_pid = _launchctl_label_pid(_WATCHDOG_LABEL)
        if watchdog_pid is None:
            if _launchctl_label_known(_WATCHDOG_LABEL):
                # v0.1.21.2: ``dormant`` mirrors the daemon's distinct
                # state for the "registered, no live PID" signature.
                rows.append(
                    _ComponentRow(
                        "Watchdog", "dormant", "stops with daemon"
                    )
                )
                healthy = False
            else:
                rows.append(
                    _ComponentRow(
                        "Watchdog", "not loaded",
                        f"label {_WATCHDOG_LABEL} unknown",
                    )
                )
                healthy = False
        else:
            rows.append(_ComponentRow("Watchdog", "healthy", f"PID {watchdog_pid}"))

    # 2C.2 (v0.1.6): Edge proxy row. The edge owns the user-facing
    # HTTPS_PROXY port — apps see it. It must stay running across every
    # daemon transition. Without this row a stopped/dead edge would be
    # invisible until apps started failing.
    edge_plist_path = _macos_edge_plist_path()
    if not edge_plist_path.exists():
        rows.append(
            _ComponentRow("Edge", "not installed", f"{edge_plist_path} missing")
        )
        healthy = False
    else:
        edge_pid = _launchctl_label_pid(_EDGE_LABEL)
        if edge_pid is None:
            if _launchctl_label_known(_EDGE_LABEL):
                rows.append(
                    _ComponentRow(
                        "Edge", "loaded", "label registered, no live PID"
                    )
                )
                healthy = False
            else:
                rows.append(
                    _ComponentRow(
                        "Edge", "not loaded",
                        f"label {_EDGE_LABEL} unknown",
                    )
                )
                healthy = False
        else:
            # v0.1.7 Gap 0: surface the edge's actual chain target.
            # When the edge bound to a stale internal_port (port-fallback
            # race) the row goes from "healthy" to "stale chain" so the
            # operator sees the silent metering loss in `status` itself,
            # not just in `doctor`.
            # v0.1.22.9 Bug 2: ground-truth edge port (lsof on the
            # managed edge PID) so the panel reports the actually-bound
            # port even when ``effective-ports.json`` is missing.
            edge_detail = f"PID {edge_pid}, port=:{_live_edge_port}"
            edge_state_status = "healthy"
            try:
                from halton_meter.port_alloc import read_edge_state_toml

                edge_state = read_edge_state_toml()
                edge_chain = edge_state.get("chain_port")
                edge_state_pid = edge_state.get("pid")
                # Compare the edge's recorded chain target against the
                # daemon's ground-truth-resolved mitm port (not the cfg
                # default — that lied when JSON was missing).
                runtime_internal = int(_live_mitm_port)
                if (
                    edge_chain is not None
                    and edge_state_pid == edge_pid
                ):
                    if edge_chain == runtime_internal:
                        edge_detail += f" -> chain :{edge_chain} ✓"
                    else:
                        edge_detail += (
                            f" -> chain :{edge_chain} ✗ "
                            f"(daemon on :{runtime_internal})"
                        )
                        edge_state_status = "stale chain"
                        healthy = False
            except Exception:
                pass
            rows.append(
                _ComponentRow(
                    "Edge",
                    edge_state_status,
                    edge_detail,
                )
            )

    # Effective ports row (v0.1.4 P0-5). When auto-port-fallback fired
    # (chosen port differs from default), make it explicit so the user
    # knows their tools must point at the actual port — not the
    # default. Witnessed: the daemon picked 8081 because 8080 was
    # busy; user wasn't sure which port to configure.
    # v0.1.22.9 Bug 2: ground-truth ports (chain through lsof) so the
    # row reports the actually-bound listener, not the configured default.
    rows.append(_port_status_row(_live_edge_port, _live_api_port))

    # System proxy row.
    proxy_state, proxy_detail = _system_proxy_state(
        cfg.daemon.listen_host, _live_edge_port
    )
    rows.append(_ComponentRow("System proxy", proxy_state, proxy_detail))
    if proxy_state != "enabled":
        healthy = False

    # Sentinel row. v0.1.20.1: mode-aware — apps-managed mirrors
    # proxy-managed for ``init --apps`` installs so we don't false-warn
    # "missing" on a healthy apps-mode setup.
    from halton_meter.setup import APPS_MANAGED_SENTINEL as _APPS_MGMT
    if sentinel_path.exists():
        rows.append(
            _ComponentRow(
                "Sentinel file", "present",
                f"{sentinel_path} (full mode)",
            )
        )
    elif _APPS_MGMT.exists():
        rows.append(
            _ComponentRow(
                "Sentinel file", "present",
                f"{_APPS_MGMT} (apps mode)",
            )
        )
    else:
        rows.append(_ComponentRow("Sentinel file", "missing", str(sentinel_path)))
        # Sentinel missing is informative but doesn't itself fail status.

    # Cert trust row.
    if _is_cert_trusted():
        rows.append(_ComponentRow("Cert trust", "trusted", "/Library/Keychains/System.keychain"))
    else:
        rows.append(_ComponentRow("Cert trust", "not trusted", "run `halton-meter setup`"))

    # Latest capture row.
    capture = _latest_capture(cfg.storage.db_path)
    if capture.db_missing:
        rows.append(_ComponentRow("Latest capture", "database not found", cfg.storage.db_path))
    elif not capture.found:
        rows.append(_ComponentRow("Latest capture", "no captures yet", "database empty"))
    else:
        ago = "?"
        if capture.seconds_ago is not None:
            ago = _humanize_seconds(capture.seconds_ago)
        cost_str = ""
        if capture.cost_usd_minor_units is not None:
            cost_str = f" / ${capture.cost_usd_minor_units / 100_000:.4f}"
        detail = (
            f"{capture.model or '—'} / {capture.project or '—'}{cost_str}"
        )
        rows.append(_ComponentRow("Latest capture", f"{ago} ago", detail))

    # P0-8: mode-aware health summary.
    from halton_meter.init import read_install_mode

    install_mode = read_install_mode()
    health_summary = _compute_health_summary_macos(rows, install_mode)
    # v0.1.5 (2B.16): mode-aware Capture hint row.
    if install_mode == "env-only":
        rows.append(
            _ComponentRow(
                "Capture",
                "env-var-only",
                "use `halton-meter run <command>` to meter CLI / SDK clients. "
                "Re-run `halton-meter init --apps` for terminal + "
                "Spotlight-app coverage, or `init --full` for browsers too.",
            )
        )
    elif install_mode == "apps":
        rows.append(
            _ComponentRow(
                "Capture",
                "apps mode",
                "new shells + Spotlight-spawned apps inherit the proxy env "
                "vars; browsers flow direct. For browser coverage re-run "
                "`halton-meter init --full`.",
            )
        )

    # v0.1.21 (2026-05-05): STOPPED is an expected state under
    # manual-start — not drift, not failure. Promote the report's
    # ``healthy`` to True so ``halton-meter status`` exits 0 (status
    # commands feeding shell prompts and CI checks should NOT see a
    # non-zero exit on a clean post-reboot machine that has just not
    # been started yet). The Component Health table still shows the
    # daemon row as "✗ not loaded" — that's factual; the verdict-line
    # severity is what changed.
    if health_summary is not None and health_summary.severity == "STOPPED":
        healthy = True

    return _StatusReport(
        healthy=healthy,
        rows=rows,
        last_hour=capture.captured_last_hour,
        last_day=capture.captured_last_day,
        platform="darwin",
        health_summary=health_summary,
    )


def _build_status_linux(cfg: Any) -> _StatusReport:
    rows: list[_ComponentRow] = []
    healthy = True

    daemon_unit_path = _linux_unit_path()
    watchdog_unit_path = _linux_watchdog_unit_path()

    daemon_active = (
        _systemctl_is_active(_LINUX_UNIT_NAME)
        if daemon_unit_path.exists()
        else "not installed"
    )
    watchdog_active = (
        _systemctl_is_active(_LINUX_WATCHDOG_UNIT_NAME)
        if watchdog_unit_path.exists()
        else "not installed"
    )
    if daemon_active == "active":
        rows.append(_ComponentRow("Daemon", "healthy", f"systemd unit {_LINUX_UNIT_NAME} active"))
    else:
        rows.append(_ComponentRow("Daemon", daemon_active, _LINUX_UNIT_NAME))
        healthy = False
    if watchdog_active == "active":
        rows.append(
            _ComponentRow(
                "Watchdog", "healthy",
                f"systemd unit {_LINUX_WATCHDOG_UNIT_NAME} active",
            )
        )
    else:
        rows.append(_ComponentRow("Watchdog", watchdog_active, _LINUX_WATCHDOG_UNIT_NAME))
        healthy = False

    # Linux: skip system-proxy row (not managed by this tool).

    # Latest capture row.
    capture = _latest_capture(cfg.storage.db_path)
    if capture.db_missing:
        rows.append(_ComponentRow("Latest capture", "database not found", cfg.storage.db_path))
    elif not capture.found:
        rows.append(_ComponentRow("Latest capture", "no captures yet", "database empty"))
    else:
        ago = "?"
        if capture.seconds_ago is not None:
            ago = _humanize_seconds(capture.seconds_ago)
        rows.append(
            _ComponentRow(
                "Latest capture",
                f"{ago} ago",
                f"{capture.model or '—'} / {capture.project or '—'}",
            )
        )

    return _StatusReport(
        healthy=healthy,
        rows=rows,
        last_hour=capture.captured_last_hour,
        last_day=capture.captured_last_day,
        platform="linux",
    )


def _systemctl_is_active(unit: str) -> str:
    try:
        result = subprocess.run(
            ["systemctl", "--user", "is-active", unit],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return "unknown"
    state = (result.stdout or "").strip()
    return state or "unknown"


def _humanize_seconds(seconds: float) -> str:
    if seconds < 60:
        return f"{int(seconds)}s"
    if seconds < 3600:
        return f"{int(seconds / 60)}m"
    if seconds < 86400:
        return f"{int(seconds / 3600)}h"
    return f"{int(seconds / 86400)}d"


_STATE_TO_SEVERITY: dict[str, str] = {
    # ok
    "healthy": "ok",
    "trusted": "ok",
    "enabled": "ok",
    "present": "ok",
    "default": "ok",
    # warn
    "loaded": "warn",
    # v0.1.21.2: ``dormant`` (registered, no live PID) renders as info
    # — the same calm tone as the STOPPED verdict it produces.
    "dormant": "warn",
    "pointed elsewhere": "warn",
    "missing": "warn",
    "no captures yet": "warn",
    "fallback": "warn",
    "edge in passthrough": "warn",
    # v0.1.21.2: stale chain = silent metering loss. Render red.
    "stale chain": "error",
    # error
    "not loaded": "error",
    "not installed": "error",
    "not trusted": "error",
    "disabled": "error",
    "database not found": "error",
    "unknown": "error",
    "inactive": "error",
    "failed": "error",
    "unresponsive": "error",
}


def _state_severity(state: str) -> str:
    """Map a component state string to ok/warn/error severity."""
    if state in _STATE_TO_SEVERITY:
        return _STATE_TO_SEVERITY[state]
    if state.endswith(" ago"):  # uptime/last-seen rows
        return "ok"
    return "warn"


def _render_status(report: _StatusReport, console: Console) -> None:
    # P0-8: render the mode-aware health summary above the table.
    # v0.1.20.dev0: brand-language migration — colour tokens come from
    # halton_meter.branding so status / doctor / report stay aligned.
    # v0.1.20.dev1: verdict panel above the table; semantic severity icon
    # column on the State cell.
    from halton_meter import __version__
    from halton_meter.branding import (
        BRAND_ORANGE,
        MUTED,
        brand_command_lead,
        brand_kv,
        brand_panel,
        brand_pill,
        brand_section,
        brand_table,
    )

    # v0.1.22.11: editorial masthead + underrule lead every user-facing
    # surface. Replaces the single-line ``brand_headline`` so ``status``
    # shares the visual signature with ``start`` / ``stop`` / ``doctor``
    # / ``init`` / ``report``.
    # v0.1.22.14: Tier-A masthead — block-H mark + wordmark / version
    # stack. ``status`` is a dwell surface (users screenshot it for
    # clients), so it earns the bigger mark. The verdict pill below
    # remains a separate state indicator (``●`` / ``✗`` / ``◐`` / ``○``)
    # — the H is brand identity, never state.
    console.print(brand_command_lead("status", version=__version__, mark="block"))
    console.print()

    if report.health_summary is not None:
        # v0.1.21: STOPPED maps to ``info`` severity so the verdict
        # panel uses the calm brand-orange border instead of warning
        # amber or error red. STOPPED is the expected post-reboot /
        # post-`stop` state under manual-start, not drift.
        sev_upper = report.health_summary.severity.upper()
        if sev_upper == "HEALTHY":
            verdict_severity = "ok"
            pill_state = "healthy"
        elif sev_upper == "BROKEN":
            verdict_severity = "error"
            pill_state = "broken"
        elif sev_upper == "STOPPED":
            verdict_severity = "info"
            pill_state = "stopped"
        else:
            verdict_severity = "warn"
            pill_state = "warn"
        # v0.1.22.11: verdict line led by a brand_pill (semantic glyph
        # + colour) followed by the verdict word and the message. The
        # surrounding brand_panel keeps the verdict as a "framed
        # moment" but the pill is now the primary signal — earned its
        # frame because the verdict drives the user's next action.
        from rich.console import Group as _Group
        from rich.text import Text as _Text

        verdict_pill = brand_pill(pill_state, report.health_summary.severity)
        message_line = _Text("  ")
        message_line.append("— ", style=MUTED)
        message_line.append(report.health_summary.message)
        body = _Group(verdict_pill, message_line)
        console.print(brand_panel(body, severity=verdict_severity, padding=(0, 1)))
        console.print()

    # v0.1.22.11: Component Health under a brand_section divider, with
    # the State column rendered as brand_pill (glyph + label). The
    # previous shape used brand_panel-wrapped table + ICON_* glyphs;
    # the editorial layout drops the outer frame so the section reads
    # as architecture, not a sub-panel.
    table = brand_table(show_lines=False, show_edge=False)
    table.add_column("Component", style=f"bold {BRAND_ORANGE}")
    table.add_column("State")
    table.add_column("Detail")
    for row in report.rows:
        sev = _state_severity(row.state)
        # Pill state mapping mirrors verdict mapping above.
        if sev == "ok":
            pill_state = "healthy"
        elif sev == "warn":
            pill_state = "warn"
        elif sev == "error":
            pill_state = "broken"
        else:
            pill_state = "stopped"
        rendered_state = brand_pill(pill_state, row.state)
        table.add_row(row.name, rendered_state, row.detail)
    console.print(brand_section("Component Health", table))
    console.print()
    # v0.1.22.11: tail summary as brand_kv pairs — aligned label/value
    # rows replace the inline ``Tests captured (last Nh): ...`` lines.
    # Same numbers, denser typographic hierarchy.
    console.print(brand_kv("Tests (last 1h)", f"{report.last_hour:,}"))
    console.print(brand_kv("Tests (last 24h)", f"{report.last_day:,}"))


# --------------------------------------------------------------------------- #
# Public entry points                                                          #
# --------------------------------------------------------------------------- #


def start(*, console: Console | None = None, quiet: bool = False) -> int:
    """Load both launchd plists; refuse if ports are held by another process.

    Idempotent — ``start`` of an already-started service is a no-op
    success. macOS path is fully implemented; Linux delegates to
    ``systemctl --user start``; Windows prints "not yet supported".

    Args:
        console: Rich Console for branded panel rendering. Created if
            None.
        quiet: v0.1.21. Suppress branded panels; emit a single-line
            status suitable for scripts and shell-rc helpers. Exit
            codes are unchanged (0 / 1).
    """
    if console is None:
        console = Console()

    platform = sys.platform
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter start is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK
    if platform == "darwin":
        return _start_macos(console, quiet=quiet)
    if platform.startswith("linux"):
        return _start_linux(console)
    console.print(f"[red]unsupported platform: {platform}[/red]")
    return _EXIT_FAILED


def stop(*, console: Console | None = None) -> int:
    """Unload both launchd plists, kill orphan port-holders, reset the system proxy.

    The sentinel file (``~/.halton-meter/proxy-managed``) is preserved so
    ``halton-meter start`` can resume cleanly via the daemon's Option-1
    startup re-enable. Use ``halton-meter uninstall`` for full removal
    (plists + sentinel + proxy reset).
    """
    if console is None:
        console = Console()

    platform = sys.platform
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter stop is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK
    if platform == "darwin":
        return _stop_macos(console)
    if platform.startswith("linux"):
        return _stop_linux(console)
    console.print(f"[red]unsupported platform: {platform}[/red]")
    return _EXIT_FAILED


def status(*, console: Console | None = None, json_output: bool = False) -> int:
    """Print a unified view of daemon + watchdog + proxy state."""
    if console is None:
        console = Console()

    platform = sys.platform
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter status is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK

    try:
        cfg = load_effective_config()
    except Exception as exc:
        console.print(f"[red]failed to load config: {exc}[/red]")
        return _EXIT_FAILED

    if platform == "darwin":
        report = _build_status_macos(cfg)
    elif platform.startswith("linux"):
        report = _build_status_linux(cfg)
    else:
        console.print(f"[red]unsupported platform: {platform}[/red]")
        return _EXIT_FAILED

    if json_output:
        # Bypass Rich (which wraps long lines / inserts control codes when
        # the terminal is narrow) — JSON output must be byte-clean for
        # downstream parsers.
        sys.stdout.write(_json.dumps(report.to_json_dict(), indent=2) + "\n")
        sys.stdout.flush()
    else:
        _render_status(report, console)

    return _EXIT_OK if report.healthy else _EXIT_FAILED


# --------------------------------------------------------------------------- #
# macOS implementations                                                        #
# --------------------------------------------------------------------------- #


def _start_macos(console: Console, *, quiet: bool = False) -> int:
    plist_path, _, _ = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()

    # Step 1: detect plists installed.
    if not plist_path.exists() or not watchdog_plist_path.exists():
        console.print(
            "[red]halton-meter is not installed; run `halton-meter init` first.[/red]"
        )
        return _EXIT_FAILED

    try:
        cfg = load_effective_config()
    except Exception as exc:
        console.print(f"[red]failed to load config: {exc}[/red]")
        return _EXIT_FAILED

    # Step 2: short-circuit when the daemon is already healthy.
    #
    # v0.1.21.4: gate the short-circuit on /health alone, NOT the
    # combined "daemon + watchdog both have live PIDs" predicate.
    # Watchdog state is best-effort defensive scaffolding; the user's
    # daily flow is "daemon is metering" and that's exactly what
    # /health responding 200 proves. The previous AND-watchdog
    # predicate forced a re-bootstrap (and thus a port-conflict check
    # against our own running edge — see Step 3) on any machine where
    # the watchdog had drifted to dormant while the daemon stayed up.
    #
    # Opportunistically kickstart the watchdog when the daemon is
    # healthy but the watchdog has no live PID — cheap and brings the
    # defensive layer back without disturbing the live daemon.
    healthy_now, _ = _poll_health_with_latency(cfg.daemon.api_port, timeout=1.0)
    if healthy_now:
        d_pid = _launchctl_label_pid(_LABEL)
        w_pid = _launchctl_label_pid(_WATCHDOG_LABEL)
        if w_pid is None:
            try:
                _launchctl_kickstart(_WATCHDOG_LABEL, kill_existing=True)
                w_pid = _launchctl_label_pid(_WATCHDOG_LABEL)
            except Exception:
                pass
        if quiet:
            console.print("halton-meter: metering active (already running)")
        else:
            # v0.1.22.11: editorial lead-in + brand_step rows inside the
            # ok-severity confirmation panel. Step rows replace inline
            # ``[OK]✓[/OK]  Daemon already running (PID ...)`` strings.
            from rich.console import Group as _Group

            from halton_meter import __version__ as _hm_version
            from halton_meter.branding import (
                brand_command_lead,
                brand_panel,
                brand_step,
            )

            console.print(brand_command_lead("start", version=_hm_version, mark="inline"))
            console.print()

            d_pid_str = str(d_pid) if d_pid is not None else "?"
            steps: list[Any] = [
                brand_step(
                    "ok",
                    "Daemon already running",
                    f"PID {d_pid_str}",
                ),
            ]
            if w_pid is not None:
                steps.append(brand_step("ok", "Watchdog running", f"PID {w_pid}"))
            else:
                steps.append(brand_step("stopped", "Watchdog dormant"))
            from rich.text import Text as _Text

            steps.append(_Text(""))
            steps.append(
                _Text.from_markup(
                    "Metering is active. Run [bold]halton-meter status[/bold] for full health."
                )
            )
            console.print(
                brand_panel(
                    _Group(*steps),
                    title="Halton Meter — already metering",
                    severity="ok",
                    padding=(0, 1),
                )
            )
        return _EXIT_OK

    # Step 3: detect port conflicts (against unmanaged orphans).
    #
    # v0.1.22.1: only check the daemon-bound ports — ``api_port`` (FastAPI)
    # and ``internal_port`` (mitmproxy). The edge port (``edge_port``,
    # 8081/8082) is owned by the always-on edge process, which is NOT
    # what ``start`` brings up. ``stop`` deliberately leaves the edge
    # running (fail-open across the metering gap), so checking edge_port
    # here is meaningless and false-positive-prone — a steady-state
    # edge listener on 8082 with concurrent client connections from
    # Windsurf / Claude Code / etc. would be flagged as a "squatter".
    #
    # Filter to LISTEN sockets only via ``_lsof_listen_pids_on_port``.
    # The bare lsof match returned every PID with any TCP socket on the
    # port, including transient ``ESTABLISHED`` client connections from
    # LLM tools mid-request — flagged as port holders even though they
    # were just sending traffic through our edge. See the helper's
    # docstring for the user-soak repro that surfaced this.
    managed_pids = _our_managed_pids()
    for port in (cfg.daemon.api_port, cfg.daemon.internal_port):
        holders = _lsof_listen_pids_on_port(port)
        orphans = [pid for pid in holders if pid not in managed_pids]
        if orphans:
            pid = orphans[0]
            console.print(
                f"[red]port {port} is held by PID {pid} ({_process_name(pid)}); "
                f"free it before starting halton-meter, or run "
                f"`halton-meter stop` to clear orphans first.[/red]"
            )
            return _EXIT_FAILED

    # Step 4: bootout-then-bootstrap both plists, then kickstart.
    #
    # v0.1.22: clear the graceful-shutdown sentinel before kickstart.
    # ``_stop_macos`` (and ``uninstall``) write the sentinel so the daemon
    # stays down across reboot when the user explicitly stopped metering.
    # ``start`` is the user's explicit countermand: their intent has
    # flipped back to "start metering". Without this clear, a rapid
    # ``stop && start`` round-trip falls inside the 30s suppression
    # window — the daemon spawns, sees the sentinel, logs
    # ``daemon.graceful_shutdown_active``, exits, and start's /health
    # probe times out. See ``decisions.md`` 2026-05-06 —
    # "v0.1.22 graceful-shutdown sentinel blocks rapid init/start retry".
    from halton_meter.graceful_shutdown import clear_graceful_shutdown_sentinel

    clear_graceful_shutdown_sentinel()

    # Record the wall-clock time immediately before we kickstart so that
    # the error panel's log tail can filter to lines written by THIS
    # start attempt — not lines from the previous session (which is all
    # the log contained when the probe times out before the daemon writes
    # anything). See ``_print_err_log_tail`` for the filter logic.
    _kickstart_wall_time = time.time()
    #
    # v0.1.21.3: unconditional ``bootout`` + ``bootstrap`` via
    # ``_launchctl_reload``. Bootstrap returns rc=5 EIO when the label
    # is already registered (the post-reboot steady-state for
    # user-domain LaunchAgents); v0.1.21.2's stderr-substring detection
    # missed the bare "Input/output error" message and false-failed
    # init. Clearing first and re-registering is robust and idempotent.
    # ``kickstart -k`` then forces start regardless of ``RunAtLoad``.
    for label, path in (
        (_LABEL, plist_path),
        (_WATCHDOG_LABEL, watchdog_plist_path),
    ):
        bs_rc, bs_err = _launchctl_reload(path, label)
        if bs_rc != 0:
            console.print(
                f"[red]launchctl bootstrap failed for {label} "
                f"(exit {bs_rc}): {bs_err}[/red]"
            )
            return _EXIT_FAILED
        ks_rc, ks_err = _launchctl_kickstart(label, kill_existing=True)
        if ks_rc != 0:
            console.print(
                f"[red]launchctl kickstart failed for {label} "
                f"(exit {ks_rc}): {ks_err}[/red]"
            )
            return _EXIT_FAILED

    # Step 5: wait + verify /health on a 3-tick cadence (1s / 3s / 8s
    # ceiling). v0.1.21 narrows the ceiling from 15s to 8s — the
    # manual-start path is run interactively and a healthy warm start
    # responds in <1s; an 8s deadline keeps the failure-mode feedback
    # loop tight without sacrificing realistic cold starts on a freshly
    # booted laptop (uvicorn binds in ~2-3s on Vikrant's machine).
    #
    # v0.1.14: re-resolve effective ports AFTER launchctl load. Between
    # the Step 1 cfg read and here, the daemon may have rebound to a
    # fallback port (e.g. 8765 -> 8766) and persisted the new tuple to
    # runtime.toml. Probing the original (stale) api_port would print
    # "/health never came up on :8765" on a perfectly healthy daemon
    # bound to 8766. Fail-open: if the re-read raises, fall back to the
    # cfg we already have.
    try:
        effective_cfg = load_effective_config()
    except Exception:
        effective_cfg = cfg
    # v0.1.22.15: ground-truth port resolution for the panel probe.
    # ``load_effective_config`` reads ``effective-ports.json`` directly,
    # which is racy at this point — kickstart returned in tens of ms
    # but the new daemon may not yet have overwritten the file. The
    # JSON can still hold a previous generation's ``pid + api_port``
    # tuple, sending the panel to the wrong port. ``resolve_effective_port_ground_truth``
    # retries lsof on the managed daemon PID for up to 2s, then falls
    # back to the JSON ONLY if its ``pid`` field matches the live
    # launchctl PID, then to cfg as a last resort.
    api_port = (
        resolve_effective_port_ground_truth(
            role="api",
            cfg_value=int(effective_cfg.daemon.api_port),
        )
        or int(effective_cfg.daemon.api_port)
    )

    healthy, ms, elapsed_ms = _start_probe_health(api_port)
    cfg = effective_cfg

    daemon_pid = _launchctl_label_pid(_LABEL)
    watchdog_pid = _launchctl_label_pid(_WATCHDOG_LABEL)
    edge_port = int(cfg.daemon.edge_port)

    # v0.1.22.4: post-success liveness verification.
    #
    # The 25s `_start_probe_health` returns the moment ``/health``
    # responds 200 once. Several user-soak symptoms have shown the
    # daemon answering /health and then exiting within seconds: the
    # success panel rendered (lying to the user) and the next
    # ``halton-meter status`` reported the daemon dormant with no
    # visible cause. We re-probe ~3s after the first success; if
    # /health is no longer responding, we treat the start as failed
    # and surface the diagnostic surface (launchctl state +
    # err-log tail) so the user sees the actual exit reason instead
    # of a green panel followed by silent disappearance.
    #
    # The 3s wait is bounded — long enough to catch fast-exit bugs
    # (the v0.1.22.3 soak showed the daemon dying within ~5s) but
    # short enough to keep the ``start`` UX feeling immediate. A
    # daemon that's actually healthy will pass this re-probe in
    # <1ms and the user just sees the success panel as before.
    post_success_failed = False
    if healthy:
        # v0.1.22.15: re-resolve the api port at re-probe time. Without
        # this, a daemon that bound to a fallback port AFTER the
        # initial probe (e.g. the JSON write landed mid-window) would
        # be probed on the wrong port and falsely flipped to red. The
        # re-resolution is cheap — lsof on the managed PID — and uses
        # the same ground-truth chain as the initial probe.
        post_success_alive = _start_post_success_liveness(
            resolved_api_port=lambda: (
                resolve_effective_port_ground_truth(
                    role="api", cfg_value=api_port
                )
                or api_port
            )
        )
        if not post_success_alive:
            healthy = False
            post_success_failed = True
            daemon_pid = _launchctl_label_pid(_LABEL)

    if not healthy:
        if quiet:
            if post_success_failed:
                console.print(
                    "halton-meter: daemon answered /health then exited "
                    "within 3s, edge tunnelling"
                )
            else:
                console.print(
                    "halton-meter: daemon failed to start, edge tunnelling"
                )
        else:
            _render_start_failure_panel(
                console,
                api_port,
                edge_port,
                post_success_died=post_success_failed,
            )
            _print_launchctl_state(console, _LABEL)
            _print_err_log_tail(console, since_wall_time=_kickstart_wall_time)
        return _EXIT_FAILED

    if quiet:
        console.print("halton-meter: metering active")
        return _EXIT_OK

    _render_start_success_panel(
        console,
        daemon_pid=daemon_pid,
        watchdog_pid=watchdog_pid,
        api_port=api_port,
        edge_port=edge_port,
        health_ms=ms,
        elapsed_ms=elapsed_ms,
    )
    return _EXIT_OK


# --------------------------------------------------------------------------- #
# v0.1.21 manual-start: 3-tick health probe + branded panels                  #
# --------------------------------------------------------------------------- #


_POST_SUCCESS_LIVENESS_DELAY_S = 3.0
_POST_SUCCESS_LIVENESS_TIMEOUT_S = 1.0


def _start_post_success_liveness(
    api_port: int | None = None,
    *,
    resolved_api_port: Callable[[], int] | None = None,
) -> bool:
    """Verify the daemon is still healthy a few seconds after first success.

    Returns ``True`` if ``/health`` still responds 200 after a fixed
    delay; ``False`` if the daemon exited or stopped responding in the
    interim. Constants are module-level so tests can monkeypatch the
    delay to zero.

    v0.1.22.4: load-bearing for the case where uvicorn has bound the
    socket and answered /health, then the daemon process exits before
    the user can run ``halton-meter status``. Without this re-probe
    the success panel is a lie. With it we render the failure panel
    and surface the err-log tail.

    v0.1.22.15: accepts ``resolved_api_port`` — a zero-arg callable
    that re-resolves the ground-truth api port at re-probe time. The
    initial probe and the re-probe MUST agree on which port to hit;
    a stale cached port produced the v0.1.22.14 user soak symptom
    where a healthy daemon was flipped to red by this re-probe. The
    legacy ``api_port: int`` keyword is preserved for back-compat
    with existing tests.
    """
    try:
        time.sleep(_POST_SUCCESS_LIVENESS_DELAY_S)
    except Exception:  # pragma: no cover — defensive
        return True
    if resolved_api_port is not None:
        try:
            port = int(resolved_api_port())
        except Exception:  # pragma: no cover — defensive
            port = int(api_port) if api_port is not None else 0
    elif api_port is not None:
        port = int(api_port)
    else:  # pragma: no cover — call signature contract
        return True
    ok, _ms = _poll_health_with_latency(
        port, timeout=_POST_SUCCESS_LIVENESS_TIMEOUT_S
    )
    return bool(ok)


def _start_probe_health(api_port: int) -> tuple[bool, float | None, float]:
    """Poll ``/health`` at 1s / 3s / 8s ceiling.

    Returns ``(healthy, last_response_ms, elapsed_ms)`` — ``elapsed_ms``
    is the wall-clock from probe start to the moment we returned, so
    the success panel can report total user-visible latency without
    rounding it to the per-poll latency.

    Defensive: never raises. Polls every 250ms but only "ticks"
    user-visible feedback at 1s / 3s / 25s (ceiling). v0.1.21.3 bumped
    the ceiling from 10s to 25s — first-cold-start on slow machines
    (or where port-fallback discovery is happening in parallel) needs
    the headroom. Observed soak: a healthy fresh boot can spend up to
    ~12-18s in DumpMaster construction + uvicorn route registration
    before /health responds. 10s false-failed those starts. 25s gives
    real cold-starts room while still bounding the failure feedback
    loop tightly enough for interactive use.
    """
    deadline = time.monotonic() + 25.0
    started = time.monotonic()
    last_ms: float | None = None
    while time.monotonic() < deadline:
        ok, ms = _poll_health_with_latency(api_port, timeout=0.75)
        if ok:
            elapsed_ms = (time.monotonic() - started) * 1000.0
            return (True, ms, elapsed_ms)
        last_ms = ms
        time.sleep(0.25)
    elapsed_ms = (time.monotonic() - started) * 1000.0
    return (False, last_ms, elapsed_ms)


def _render_start_success_panel(
    console: Console,
    *,
    daemon_pid: int | None,
    watchdog_pid: int | None,
    api_port: int,
    edge_port: int,
    health_ms: float | None,
    elapsed_ms: float,
) -> None:
    # v0.1.22.11: editorial lead-in + brand_step rows for each phase.
    # Critical numerics (PID, port, latency) are preserved verbatim as
    # the step's detail string so existing shape assertions still grep.
    from rich.console import Group as _Group
    from rich.text import Text as _Text

    from halton_meter import __version__ as _hm_version
    from halton_meter.branding import (
        brand_command_lead,
        brand_panel,
        brand_step,
    )

    console.print(brand_command_lead("start", version=_hm_version, mark="inline"))
    console.print()

    daemon_pid_str = str(daemon_pid) if daemon_pid is not None else "?"
    watchdog_pid_str = str(watchdog_pid) if watchdog_pid is not None else "?"
    # Prefer wall-clock elapsed for the headline figure (it captures
    # the user-visible launchctl-load + uvicorn-bind window). If for
    # some reason the timer didn't run, fall back to per-poll latency.
    headline_ms = elapsed_ms if elapsed_ms > 0 else (health_ms or 0.0)
    steps: list[Any] = [
        brand_step("ok", "Daemon loaded", f"PID {daemon_pid_str}"),
        brand_step("ok", "Watchdog loaded", f"PID {watchdog_pid_str}"),
        brand_step(
            "ok",
            "/health responding",
            f":{api_port} ({headline_ms:.0f}ms)",
        ),
        _Text(""),
        _Text.from_markup(
            "Metering is now ON for new shells, Spotlight-spawned apps,\n"
            f"and traffic via http://127.0.0.1:{edge_port}.\n\n"
            "Run [bold]halton-meter stop[/bold] to halt metering at end of day."
        ),
    ]
    console.print(
        brand_panel(
            _Group(*steps),
            title="Halton Meter — metering active",
            severity="ok",
            padding=(0, 1),
        )
    )


def _render_start_failure_panel(
    console: Console,
    api_port: int,
    edge_port: int,
    *,
    post_success_died: bool = False,
) -> None:
    from halton_meter import __version__ as _hm_version
    from halton_meter.branding import ERROR, brand_command_lead, brand_panel

    # v0.1.22.11: editorial lead-in even on failure — surface signature
    # is the same as success so the user's eye finds the verdict pill /
    # panel border colour without re-anchoring on a different layout.
    console.print(brand_command_lead("start", version=_hm_version, mark="inline"))
    console.print()

    if post_success_died:
        # v0.1.22.4: post-success liveness failure. The daemon answered
        # /health once and then exited before the user-facing wait
        # cleared — the diagnostic surface below (launchctl state +
        # err-log tail) reveals the exit reason.
        headline = (
            f"[{ERROR}]✗[/{ERROR}]  Daemon answered /health on :{api_port} "
            "but exited within\n   3 seconds. The diagnostic tail below "
            "shows why.\n\n"
        )
    else:
        headline = (
            f"[{ERROR}]✗[/{ERROR}]  Daemon plist loaded but /health did not "
            f"respond on\n   :{api_port} within 25s.\n\n"
        )

    body = (
        f"{headline}"
        f"The edge proxy is still running on :{edge_port} and traffic is\n"
        "passing through to upstream un-metered (fail-open).\n\n"
        "Next steps:\n"
        "  [bold]›[/bold] [bold]halton-meter doctor[/bold]       "
        "— run diagnostics\n"
        "  [bold]›[/bold] tail ~/.halton-meter/daemon.err.log\n"
        "  [bold]›[/bold] [bold]halton-meter stop && halton-meter start[/bold]   "
        "— retry"
    )
    console.print(
        brand_panel(
            body,
            title="Halton Meter — daemon failed to start",
            severity="error",
            padding=(0, 1),
        )
    )


def _stop_macos(console: Console) -> int:
    from halton_meter.graceful_shutdown import write_graceful_shutdown_sentinel

    plist_path, _, _ = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()

    plists_present = plist_path.exists() or watchdog_plist_path.exists()

    cfg: Any | None = None
    try:
        # v0.1.22.x: use ``load_effective_config`` (not ``load_config``)
        # so the stop panel's "Edge proxy still running on :PORT" line
        # reads from ``effective-ports.json`` (kernel-confirmed bound
        # port written by the running edge process). Previously this
        # used the static config default and printed ``:8081`` even
        # when the edge had fallen back to ``:8082``. Effective config
        # is also the right input for the orphan-port-holder kill loop
        # below — we want to clean up the actually-bound ports.
        cfg = load_effective_config()
    except Exception as exc:
        # Without config we can't kill orphan port-holders, but we can
        # still reset the system proxy — that's the load-bearing step.
        console.print(f"[yellow]warning: failed to load config: {exc}[/yellow]")

    unloaded: list[str] = []
    unload_failed: list[str] = []
    # v0.1.21.2: modern ``launchctl bootout`` replaces legacy ``unload``.
    # On a ``RunAtLoad=False`` plist the legacy ``unload`` path stayed
    # mostly correct (it does tear the label down), but using the
    # symmetric verb pair (bootstrap/bootout) keeps this code path
    # consistent with the start side and behaves identically across
    # macOS 11..15.
    for label, path in (
        (_WATCHDOG_LABEL, watchdog_plist_path),
        (_LABEL, plist_path),
    ):
        if not path.exists():
            continue
        rc, err = _launchctl_bootout(label)
        if rc == 0:
            unloaded.append(label)
        else:
            # ``bootout`` of an unknown label returns non-zero — that's
            # the post-condition we wanted, so swallow it. Genuine
            # failure paths surface in stderr (e.g. permission denied).
            err_lc = err.lower()
            if "could not find" in err_lc or "no such" in err_lc:
                unloaded.append(label)
            else:
                unload_failed.append(label)
                if err:
                    console.print(
                        f"[yellow]warning: launchctl bootout {label}: {err}[/yellow]"
                    )

    # Wait for the daemon PID to actually exit before returning. A fixed
    # 0.5s sleep was too short: if the caller immediately runs
    # ``halton-meter start`` the daemon process may still be alive,
    # causing the kickstart to SIGTERM a mid-exit process and leaving
    # the port briefly occupied. Poll up to 3s in 100ms increments for
    # the daemon label's PID to disappear; fall through on timeout.
    if plists_present:
        _settle_deadline = time.monotonic() + 3.0
        while time.monotonic() < _settle_deadline:
            if _launchctl_label_pid(_LABEL) is None:
                break
            time.sleep(0.1)

    # Kill orphan port-holders (best-effort; needs cfg).
    #
    # v0.1.22.2 (B4): three changes from the prior shape:
    #
    # 1. Drop ``edge_port`` from the loop. ``stop`` deliberately leaves
    #    the edge running for fail-open (apps inherit ``HTTPS_PROXY``
    #    pointing at the edge port; killing the edge severs every
    #    in-flight LLM request). Checking ``edge_port`` here would (and
    #    did, for v0.1.22.1) SIGTERM our own edge process every time
    #    ``stop`` ran — launchd's ``KeepAlive=True`` then respawned it
    #    immediately, but the edge.err.log filled with "Task was
    #    destroyed but it is pending!" warnings on every cycle and the
    #    user's ESTABLISHED clients (Windsurf Helper, Claude Code,
    #    etc.) holding sockets to the edge were SIGTERMed as collateral.
    #
    # 2. Use ``_lsof_listen_pids_on_port`` (LISTEN-only) instead of
    #    ``_lsof_pids_on_port`` (all states). The all-states variant
    #    returned every ESTABLISHED client connection on the daemon
    #    ports too — most of which were OUR OWN edge → daemon
    #    connections. Filtering to LISTEN means we only consider real
    #    port-holders, never transient client sockets.
    #
    # 3. Filter against ``_our_managed_pids()``. Even on the daemon
    #    ports a launchctl-managed PID should never be killed by this
    #    path — bootout is the supervised exit. Killing our own PID
    #    races with launchctl's bootout poll and produces inconsistent
    #    state (a SIGKILLed daemon mid-bootout leaves stale label
    #    state the next ``start`` then has to clean up).
    killed: list[tuple[int, str]] = []
    if cfg is not None:
        managed_pids = _our_managed_pids()
        for port in (cfg.daemon.api_port,):
            for pid in _lsof_listen_pids_on_port(port):
                if pid in managed_pids:
                    continue
                sig_sent = _terminate_pid(pid)
                if sig_sent:
                    killed.append((pid, sig_sent))

    # Reset the system proxy. Symmetric with `uninstall`'s recovery line:
    # leaving the system proxy pointed at our (now-dead) listener breaks
    # every HTTPS-via-system-proxy client on the machine. The sentinel
    # file is intentionally preserved so `halton-meter start` can resume
    # via the daemon's Option-1 startup re-enable.
    proxy_reset_ifaces = _reset_macos_system_proxy(console)

    # v0.1.21 (2026-05-05): copy reframed for the manual-start mental
    # model. "Stopped" is the expected end-of-day state, not a failure
    # state — so we lead with the OK ticks for what actually happened
    # and explicitly tell the user the edge stays up (fail-open) until
    # they run ``halton-meter start`` again. The previous copy ("Apps
    # still work — the edge proxy is still running...") still applies
    # but reads less calmly than the v0.1.21 framing.
    # v0.1.22.11: editorial lead-in + brand_step rows for the
    # daemon/watchdog/proxy-reset sequence. Strings ("Daemon stopped",
    # "Watchdog stopped", "System proxy reset on: ...") preserved
    # verbatim from v0.1.22.10 so substring assertions in
    # test_lifecycle survive.
    from rich.console import Group as _StopGroup
    from rich.text import Text as _StopText

    from halton_meter import __version__ as _stop_hm_version
    from halton_meter.branding import (
        brand_command_lead as _brand_command_lead,
    )
    from halton_meter.branding import (
        brand_step as _brand_step,
    )

    console.print(_brand_command_lead("stop", version=_stop_hm_version, mark="inline"))
    console.print()

    body_renderables: list[Any] = []
    if not plists_present:
        body_renderables.append(
            _StopText.from_markup(
                "[yellow]halton-meter is not installed; no plists to unload.[/yellow]"
            )
        )
    # Daemon + watchdog tick rows. We render an OK step for each label
    # we successfully unloaded.
    label_pretty = {
        _LABEL: "Daemon",
        _WATCHDOG_LABEL: "Watchdog",
    }
    for label in (_LABEL, _WATCHDOG_LABEL):
        if label in unloaded:
            body_renderables.append(
                _brand_step("ok", f"{label_pretty[label]} stopped")
            )
    if unload_failed:
        body_renderables.append(
            _StopText.from_markup(
                f"[yellow]Unload returned non-zero: {', '.join(unload_failed)} "
                f"(continuing — system-proxy reset still ran)[/yellow]"
            )
        )
    if killed:
        body_renderables.append(
            _StopText(
                "Killed orphans: "
                + ", ".join(f"PID {pid} ({sig})" for pid, sig in killed)
            )
        )
    if proxy_reset_ifaces:
        body_renderables.append(
            _brand_step(
                "ok",
                "System proxy reset on",
                ", ".join(proxy_reset_ifaces),
            )
        )
    # 2C.2 (v0.1.6): the edge proxy is INTENTIONALLY left running. It
    # owns the user-facing port (HTTPS_PROXY for any app) and tunnels
    # traffic directly to upstream (no metering) until the daemon is
    # restarted. Apps don't need to be restarted.
    edge_port: int | None = None
    if cfg is not None:
        try:
            edge_port = int(cfg.daemon.edge_port)
        except (AttributeError, TypeError, ValueError):
            edge_port = None
    if edge_port is not None:
        body_renderables.append(_StopText(""))
        body_renderables.append(
            _StopText.from_markup(
                f"Edge proxy still running on :{edge_port}; traffic tunnels "
                "through to\nupstream un-metered until you run "
                "[bold]halton-meter start[/bold]."
            )
        )
    body_renderables.append(_StopText(""))
    body_renderables.append(
        _StopText.from_markup(
            "[dim]Sentinel preserved — re-run "
            "[bold]halton-meter start[/bold] to resume metering.\n"
            "For full removal: [bold]halton-meter uninstall[/bold].[/dim]"
        )
    )
    from halton_meter.branding import brand_panel

    # padding=(0, 1) matches the pre-v0.1.20 Panel default and keeps the
    # multi-line "Apps still work" message from wrapping mid-phrase in
    # narrow terminals (the test fixture asserts substrings).
    console.print(
        brand_panel(
            _StopGroup(*body_renderables),
            title="halton-meter stop",
            severity="warn",
            padding=(0, 1),
        )
    )

    # v0.1.16 Issue #1: write graceful shutdown sentinel so the daemon doesn't
    # auto-restart on reboot (respecting the user's explicit stop request).
    write_graceful_shutdown_sentinel()

    return _EXIT_OK


def _reset_macos_system_proxy(console: Console) -> list[str]:
    """Disable the macOS system proxy on Wi-Fi + Ethernet, both secure and
    unsecure. Best-effort — non-zero exits per interface are swallowed
    (not every interface exists on every machine). Returns the list of
    interfaces a reset was attempted on (for the status line).

    Interfaces are enumerated dynamically via
    ``networksetup -listallnetworkservices`` (see ``decisions.md``
    2026-04-30 — "2B.7.2 enumerate macOS network services dynamically")
    so machines without ``Ethernet`` (or with ``Thunderbolt Bridge`` /
    ``iPhone USB`` instead) get their proxy reset on the interfaces that
    actually exist."""
    from halton_meter import system_proxy

    interfaces = system_proxy._macos_interfaces()
    succeeded: list[str] = []
    for iface in interfaces:
        any_ok = False
        for variant in ("-setsecurewebproxystate", "-setwebproxystate"):
            try:
                result = subprocess.run(
                    ["networksetup", variant, iface, "off"],
                    capture_output=True,
                    timeout=5,
                    check=False,
                )
                if result.returncode == 0:
                    any_ok = True
            except (OSError, subprocess.SubprocessError):
                pass
        if any_ok:
            succeeded.append(iface)
            # v0.1.22.1: demoted from ``console.print`` to structlog debug.
            # The per-interface result is duplicated by the stop panel's
            # aggregated "✓ System proxy reset on: <iface>, <iface>, ..."
            # line; printing each interface here as well leaks plain
            # text above the panel (Rich renders ``[halton-meter]`` as
            # an unknown markup tag and silently strips it, so the user
            # sees a bare "system proxy reset on Wi-Fi" line). Keep the
            # signal in the log file for diagnosability; the panel is
            # the user-facing surface.
            _log.debug("system_proxy.iface_reset", interface=iface)
    return succeeded


def _terminate_pid(pid: int) -> str | None:
    """Send SIGTERM, wait, then SIGKILL if still alive. Returns signal sent."""
    try:
        os.kill(pid, _signal.SIGTERM)
    except ProcessLookupError:
        return None
    except OSError:
        return None

    # Wait up to 2s for graceful exit.
    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)  # signal 0 = liveness probe
        except ProcessLookupError:
            return "SIGTERM"
        except OSError:
            return "SIGTERM"
        time.sleep(0.1)

    # Still alive — escalate.
    try:
        os.kill(pid, _signal.SIGKILL)
        return "SIGKILL"
    except (ProcessLookupError, OSError):
        return "SIGTERM"


def _print_launchctl_state(console: Console, label: str) -> None:
    """Print a one-line "is the daemon process alive?" diagnostic.

    Critical for distinguishing the two failure modes that both produce
    "/health did not respond":

    * Daemon process is NOT running. Either the bootstrap+kickstart failed
      silently (kickstart returns rc=0 even when the process never spawned),
      or the daemon spawned and crashed during Python import / asyncio
      init before any structlog event was written. Surfacing the absent
      PID points the user at the err-log tail for crash output.
    * Daemon process IS running but ``/health`` is slow. Cold-start of
      mitmproxy + uvicorn + DumpMaster construction can take longer than
      the 25s probe ceiling on a freshly-rebooted machine. PID present +
      no log entries means "still initialising — wait and retry".

    Without this line the user (and the operator reading their bug
    report) sees only the panel copy and has to guess. Best-effort: any
    failure in the launchctl call falls through silently — observation
    infrastructure must never block the start command from returning.
    """
    if sys.platform != "darwin":
        return
    pid = _launchctl_label_pid(label)
    if pid is not None:
        console.print(
            f"\n[dim]daemon process: alive (launchctl PID {pid}) — "
            "/health may still be initialising. Retry with [bold]halton-meter "
            "start[/bold] in ~30s, or run [bold]halton-meter status[/bold].[/dim]"
        )
        return
    # Label registered but no live PID — capture the launchctl print
    # for diagnostics so the failure surface includes "why".
    uid = _gui_uid()
    if uid is None:
        console.print(
            "\n[dim]daemon process: not running (no launchctl PID). "
            "See err-log tail below for crash output.[/dim]"
        )
        return
    loaded, print_rc, print_err = _launchctl_label_loaded(uid, label)
    if loaded:
        console.print(
            "\n[dim]daemon process: registered but not running (launchctl "
            "reports the label loaded with no PID — the spawn failed or the "
            "process exited before /health bound). See err-log tail below.[/dim]"
        )
    else:
        suffix = f": {print_err}" if print_err else ""
        console.print(
            f"\n[dim]daemon process: launchctl reports the label is NOT "
            f"loaded (rc={print_rc}{suffix}). Re-run [bold]halton-meter "
            f"start[/bold] or [bold]halton-meter rescue[/bold].[/dim]"
        )


def _parse_log_line_timestamp(line: str, _json_mod: Any) -> Any:
    """Return a tz-aware ``datetime`` for ``line``'s timestamp, or None.

    Handles two log formats produced by the daemon over its history:

    * structlog ``ConsoleRenderer`` (current daemon output, configured in
      :func:`halton_meter.cli._configure_daemon_logging`). Lines start
      with an ISO-8601 UTC timestamp followed by ``[level    ]``, e.g.
      ``2026-05-06T18:20:05.123456Z [info     ] daemon.startup.phase ...``.
    * Pure JSON log lines (legacy / future-proofing). The ``timestamp``
      or ``ts`` key carries the ISO-8601 string.

    Defensive: never raises. Returns None for any line that doesn't
    parse cleanly so the caller can decide how to bucket it (typically
    "stack-trace continuation of the previous timestamped line").
    """
    from datetime import UTC, datetime

    line_stripped = line.strip()
    if not line_stripped:
        return None

    # Format (1): ConsoleRenderer — ISO-8601 timestamp at start of line.
    # Whitespace separates the timestamp from ``[level ]``; we slice on
    # the first space and try to parse the lhs.
    head, sep, _ = line_stripped.partition(" ")
    if sep and len(head) >= 19:  # "YYYY-MM-DDTHH:MM:SS" minimum
        try:
            ts = datetime.fromisoformat(head.replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=UTC)
            return ts
        except ValueError:
            pass

    # Format (2): JSON log lines.
    if line_stripped.startswith("{"):
        try:
            obj = _json_mod.loads(line_stripped)
            raw_ts = obj.get("timestamp") or obj.get("ts")
            if raw_ts:
                ts = datetime.fromisoformat(str(raw_ts).replace("Z", "+00:00"))
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=UTC)
                return ts
        except (ValueError, AttributeError, _json_mod.JSONDecodeError):
            pass

    return None


def _print_err_log_tail(
    console: Console,
    *,
    lines: int = 20,
    since_wall_time: float | None = None,
) -> None:
    """Print the tail of ``daemon.err.log`` to the console.

    ``since_wall_time`` (a ``time.time()`` value) filters log lines to only
    those whose structured-log ``timestamp`` field is at or after the given
    wall-clock time. This prevents showing stale lines from the *previous*
    daemon session when the current start probe timed out before the daemon
    had a chance to write anything.

    Lines without a parseable ISO-8601 timestamp (plain stderr, Python
    tracebacks, etc.) are always shown so we don't silently drop crash
    output. If ``since_wall_time`` is None the filter is disabled and all
    lines are shown (legacy behaviour, used in contexts without a kickstart
    timestamp).

    When the file has no lines at or after ``since_wall_time``, a note is
    shown instead of a stale tail — telling the user that no new log entries
    exist yet and the daemon may still be starting.
    """
    import json as _json

    err_log = Path.home() / ".halton-meter" / "daemon.err.log"
    if not err_log.exists():
        return
    try:
        text = err_log.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return

    all_lines = text.splitlines()
    if not all_lines:
        return

    if since_wall_time is None:
        tail = "\n".join(all_lines[-lines:])
        if tail.strip():
            console.print(f"\n[dim]daemon.err.log tail:[/dim]\n[dim]{tail}[/dim]")
        return

    # Filter to lines at or after ``since_wall_time``. Strategy:
    # - Two recognised log formats:
    #   (1) structlog ConsoleRenderer (the daemon's actual output —
    #       ``_configure_daemon_logging`` uses ``ConsoleRenderer(colors=False)``
    #       with ``TimeStamper(fmt="iso", utc=True)``). Lines look like:
    #         ``2026-05-06T18:20:05.123456Z [info     ] daemon.startup.phase ...``
    #       i.e. an ISO-8601 timestamp at the START of the line.
    #   (2) Pure JSON log lines (legacy / future-proofing). The
    #       ``timestamp`` or ``ts`` key carries the ISO-8601 string.
    # - Lines without a parseable timestamp are treated as belonging to the
    #   same "session bucket" as the most-recently-seen timestamped line.
    # - Lines that precede our cutoff are excluded; non-timestamped lines
    #   that follow a recent-enough timestamped line are included (they are
    #   likely stack-trace continuations from the new session).
    #
    # The previous implementation only parsed the JSON variant; because the
    # daemon uses ConsoleRenderer the filter dropped EVERY line and rendered
    # the misleading "no new entries since start was invoked" note even
    # when the daemon had logged a full crash trace. (root-cause analysis,
    # 2026-05-07; see decisions.md.)
    from datetime import UTC, datetime

    cutoff_dt = datetime.fromtimestamp(since_wall_time, tz=UTC)

    filtered: list[str] = []
    last_line_was_recent = False

    for line in all_lines:
        ts = _parse_log_line_timestamp(line, _json)

        if ts is not None:
            if ts >= cutoff_dt:
                filtered.append(line)
                last_line_was_recent = True
            else:
                last_line_was_recent = False
        else:
            # Non-timestamped line (plain stderr, traceback frame, etc.).
            # Include it when the preceding context was from the new session.
            if last_line_was_recent:
                filtered.append(line)

    if not filtered:
        console.print(
            "\n[dim]daemon.err.log: no new entries since start was invoked "
            "— daemon may still be initialising. "
            "Run [bold]halton-meter start[/bold] again in ~30s, or "
            "[bold]halton-meter doctor[/bold] for diagnostics.[/dim]"
        )
        return

    # Cap at ``lines`` most-recent entries.
    tail = "\n".join(filtered[-lines:])
    console.print(f"\n[dim]daemon.err.log tail (new entries only):[/dim]\n[dim]{tail}[/dim]")


# --------------------------------------------------------------------------- #
# Linux implementations (best-effort minimal stub)                             #
# --------------------------------------------------------------------------- #


def _start_linux(console: Console) -> int:
    if not _linux_unit_path().exists():
        console.print(
            "[red]halton-meter is not installed; run `halton-meter init` first.[/red]"
        )
        return _EXIT_FAILED
    try:
        result = subprocess.run(
            [
                "systemctl",
                "--user",
                "start",
                _LINUX_UNIT_NAME,
                _LINUX_WATCHDOG_UNIT_NAME,
            ],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        console.print(
            f"[yellow]systemctl --user start failed ({exc}); "
            f"manual: systemctl --user start {_LINUX_UNIT_NAME} "
            f"{_LINUX_WATCHDOG_UNIT_NAME}[/yellow]"
        )
        return _EXIT_OK
    if result.returncode != 0:
        console.print(
            f"[red]systemctl start failed: {(result.stderr or '').strip()}[/red]"
        )
        return _EXIT_FAILED
    console.print("[green]halton-meter started via systemd[/green]")
    return _EXIT_OK


def _stop_linux(console: Console) -> int:
    from halton_meter.graceful_shutdown import write_graceful_shutdown_sentinel

    if not _linux_unit_path().exists():
        console.print("[yellow]halton-meter is not installed; nothing to stop.[/yellow]")
        return _EXIT_OK
    try:
        subprocess.run(
            [
                "systemctl",
                "--user",
                "stop",
                _LINUX_UNIT_NAME,
                _LINUX_WATCHDOG_UNIT_NAME,
            ],
            capture_output=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        console.print(f"[yellow]systemctl stop raised: {exc}[/yellow]")
    console.print("[green]halton-meter stopped via systemd[/green]")

    # v0.1.16 Issue #1: write graceful shutdown sentinel so the daemon doesn't
    # auto-restart on reboot (respecting the user's explicit stop request).
    write_graceful_shutdown_sentinel()

    return _EXIT_OK
