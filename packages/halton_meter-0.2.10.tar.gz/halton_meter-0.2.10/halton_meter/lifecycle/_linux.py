"""Linux apps-mode implementation for ``halton_meter.lifecycle``.

**v0.1.22.5 — UNTESTED on real Linux.** Subprocess-mocked unit tests only.

Forwards every name from :mod:`halton_meter.lifecycle._macos`. The
shared module's public ``start`` / ``stop`` / ``status`` already branch
on ``sys.platform`` and call ``_start_linux`` / ``_stop_linux`` /
``_build_status_linux`` (all defined inside ``_macos.py`` from the
historical flat-module days). Linux flow: ``systemctl --user`` against
the unit names ``halton-meter.service`` and
``halton-meter-watchdog.service``.

Linux phase 0 caveats:

* Status panel: launchd verdict columns ("dormant", "registered but not
  running") get translated from ``systemctl is-active`` output —
  ``active`` / ``activating`` / ``inactive`` / ``failed`` / ``unknown``.
* ``halton-meter start``'s post-success liveness re-probe (v0.1.22.4)
  applies on Linux too via the shared ``_start_probe_health`` /
  ``_start_post_success_liveness`` helpers.
* The edge process is NOT a separate plist on Linux today — the daemon
  binds the user-facing port directly. ``stop`` therefore takes the
  daemon and watchdog down together; there is no fail-open edge
  tunnelling on Linux until the proper Linux phase ships an
  ``halton-meter.edge.service``.
"""

from __future__ import annotations

import types as _types

from . import _macos as _macos_impl

_globals = globals()
for _name in dir(_macos_impl):
    if _name.startswith("__"):
        continue
    _attr = getattr(_macos_impl, _name)
    if isinstance(_attr, _types.ModuleType):
        continue
    _globals[_name] = _attr
del _globals, _name, _attr
