"""
Base types for provider adapters.

Defines the ProviderAdapter Protocol and the Pydantic data models that
all adapters produce. Adding a new provider means implementing this Protocol —
nothing else in the codebase needs to change.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, Field


class RequestMetadata(BaseModel):
    """
    Structured metadata extracted from an outbound LLM API request.

    Populated by ProviderAdapter.parse_request() before the request is forwarded.
    Carried through the flow and passed to parse_response() so the adapter can
    compute latency without needing to re-read the flow.
    """

    model_config = ConfigDict(frozen=True)

    provider: str = Field(description="Provider name, e.g. 'anthropic'")
    model: str = Field(description="Model identifier as returned by the provider")
    stream: bool = Field(description="True if the client requested a streaming response")
    started_at: float = Field(
        description="time.monotonic() value at request parse time, for latency computation"
    )

    # Phase 2 Wave 1A.ii: cloud-sync fields captured at request-parse time.
    # All optional (default None) so adapters that have not yet been
    # updated remain wire-compatible. The proxy hot path reads these and
    # copies them onto the LogRecord before write.
    request_kind: str | None = Field(
        default=None,
        description=(
            "'chat' | 'embedding' | 'tool' | 'unknown'. Derived by the adapter "
            "via cloud_fields.derive_request_kind. None for adapters that do "
            "not classify."
        ),
    )
    prompt_hash: str | None = Field(
        default=None,
        description=(
            "SHA-256 hex digest of the canonical-JSON-encoded request body. "
            "Computed by cloud_fields.canonical_prompt_hash. None when the "
            "request body was not JSON-parsable or empty."
        ),
    )
    idempotency_key: str | None = Field(
        default=None,
        description=(
            "Provider-supplied idempotency key, echoed verbatim from a known "
            "header (Anthropic-Idempotency-Key / Idempotency-Key / etc.). "
            "None when no such header was present."
        ),
    )


class ResponseMetadata(BaseModel):
    """
    Structured metadata extracted from a completed LLM API response.

    Populated by ProviderAdapter.parse_response() after the full body is available.
    Token fields default to 0 when absent. tokens_complete=False signals that
    the body was truncated (e.g. client disconnected mid-stream) — stored record
    should be marked incomplete rather than silently showing wrong counts.
    """

    model_config = ConfigDict(frozen=True)

    input_tokens: int = Field(default=0, description="Prompt tokens including system and tools")
    output_tokens: int = Field(default=0, description="Completion tokens")
    thinking_tokens: int = Field(
        default=0,
        description="Extended thinking tokens (Anthropic) or reasoning tokens (OpenAI o-series)",
    )
    cache_read_tokens: int = Field(
        default=0,
        description=(
            "Cache READ tokens (Anthropic: usage.cache_read_input_tokens). "
            "Priced lower than fresh input."
        ),
    )
    cache_write_tokens: int = Field(
        default=0,
        description=(
            "Cache WRITE tokens (Anthropic: usage.cache_creation_input_tokens). "
            "Single field — Anthropic's response usage does not surface a 5m/1h split. "
            "See pricing/matrix.py for the TTL-limitation note."
        ),
    )
    tokens_complete: bool = Field(
        default=True,
        description="False if the response body was truncated and counts may be partial",
    )
    latency_ms: float = Field(default=0.0, description="End-to-end latency in milliseconds")


@runtime_checkable
class ProviderAdapter(Protocol):
    """
    Protocol for provider-specific request/response parsers.

    Implementations must be:
    - Stateless: no instance-level mutable state that depends on request flow.
    - Pure: no I/O, no network calls, no filesystem access, no side effects.
    - Safe: must not raise — callers wrap in try/except but prefer not to need it.

    To add a new provider: implement this Protocol, add an instance to
    ADAPTER_REGISTRY in proxy.py. No other changes required.
    """

    name: str
    """Short provider identifier, e.g. 'anthropic'. Used in log fields and DB records."""

    domains: list[str]
    """Canonical hostnames this adapter handles, e.g. ['api.anthropic.com']."""

    def matches(self, host: str) -> bool:
        """
        Return True if this adapter should handle the given request host.

        Host may include a port suffix (e.g. 'api.anthropic.com:443').
        Implementations should use startswith() to handle both forms.
        """
        ...

    def matches_url(self, host: str, path: str) -> bool:
        """
        Return True if this adapter should handle the given (host, path) pair.

        Default semantics (additive bump, 2026-05-02): delegates to
        ``matches(host)`` so every existing adapter is backward compatible
        without modification. Adapters MAY override to opt OUT of specific
        URL paths on hosts they otherwise own. Example use case: the OpenAI
        adapter overrides this to return ``False`` for ``/v1/moderations``
        (free endpoint — would clutter the DB with $0 rows).

        Adapters MUST NOT use this hook to opt INTO hosts they do not own
        — host-level routing stays in ``matches()``. ``matches_url`` is
        strictly a path-level filter on top of ``matches()``.

        The proxy dispatch passes ``flow.request.path`` as the second
        argument; the path includes the leading ``/`` and any query string.
        """
        ...

    def parse_request(self, flow: object) -> RequestMetadata:
        """
        Extract metadata from an outbound request.

        Called with the full mitmproxy HTTPFlow after the request headers and
        body are available. Must return a RequestMetadata even on parse failure
        (use defaults). Must not raise.
        """
        ...

    def parse_response(
        self,
        flow: object,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata | None:
        """
        Extract metadata from a completed response.

        Called after the full response body has been received and accumulated
        by mitmproxy (including streamed SSE bodies). Must return a
        ResponseMetadata even on parse failure. Must not raise.

        Returning ``None`` signals "skip this row entirely — do not write
        a counts record to SQLite". Use sparingly: only when the
        request+response together carry no meterable signal AND would
        otherwise pollute aggregations (concrete case, 2026-05-02:
        Anthropic SSE responses where the request body lacked a ``model``
        field AND the response carried zero usage tokens — typically
        non-inference probes that slip past ``_INFERENCE_PATH_PREFIXES``).
        Adapters that always emit meterable data should never return None.
        """
        ...
