"""
Gemini Code Assist provider adapter (sibling of GeminiAdapter).

Handles ``cloudcode-pa.googleapis.com`` — the OAuth-authenticated Code
Assist surface that the official ``gemini`` CLI uses when signed in with
a Google account (free / Code Assist plan). This is a separate host
from the public Gemini API (``generativelanguage.googleapis.com``) and
has materially different wire conventions, so it is implemented as a
sibling adapter rather than broadening :class:`GeminiAdapter`.

Background — investigation 2026-05-04
(``memory/plans/2026-05-04-gemini-capture-gap-investigation.md``):

    User ran Gemini CLI v0.40.1 (Google OAuth, "Gemini Code Assist for
    individuals" plan); ``halton-meter report`` showed zero Gemini rows.
    Root cause: the daemon cleanly intercepted every byte but the
    public-API ``GeminiAdapter`` rejected ``cloudcode-pa.googleapis.com``
    in :meth:`matches`, so requests fell out at adapter dispatch.
    See ADR ``memory/decisions.md`` 2026-05-04 for the sibling-adapter
    decision and TEMP- pricing convention.

Endpoints in scope (billable):
  POST /v1internal:generateContent           — non-streaming chat
  POST /v1internal:streamGenerateContent     — streaming SSE
                                               (query string ``?alt=sse``)

Endpoints filtered OUT via :meth:`matches_url` (control-plane / free):
  /v1internal:loadCodeAssist                 — session bootstrap
  /v1internal:retrieveUserQuota              — quota lookup
  /v1internal:listExperiments
  /v1internal:fetchAdminControls
  (and any other non-:generateContent action)

Two important deltas vs ``GeminiAdapter`` (the public-API sibling):

1. **Model is body-extracted, not URL-extracted.** Public Gemini puts
   the model id in the URL path (``/v1beta/models/<model>:action``);
   Code Assist tunnels it server-side. The model field is in the JSON
   request body (most likely top-level ``"model"``; we also accept
   nested ``request.model`` defensively). When absent we fall back to
   the literal ``"gemini-code-assist-unknown"`` so the request still
   gets a row.

2. **Streaming is SSE, not JSON-array.** Public ``:streamGenerateContent``
   returns a JSON array; Code Assist's ``:streamGenerateContent?alt=sse``
   returns Server-Sent-Events. The SSE branch reuses the same
   ``data:`` walking idiom as the OpenAI adapter — find the final
   chunk that carries ``usageMetadata`` (per-chunk on Code Assist;
   the LAST one is authoritative).

Token-count locations:

Non-streaming (``:generateContent``):
    Response body root → ``"response"`` (Code Assist wraps the public
    API's response under a top-level ``"response"`` key on this
    surface — observed in client code) → ``"usageMetadata"``. We
    accept BOTH shapes:
      - public-style: top-level ``usageMetadata``
      - wrapped:      response.usageMetadata

Streaming (``:streamGenerateContent?alt=sse``):
    Standard ``data: {...}`` SSE chunks. Each chunk's payload follows
    the same shape as non-streaming. Walk every chunk; the final
    chunk that carries a ``usageMetadata`` block wins. ``[DONE]``
    sentinel may or may not be present — handled either way.

Multimodal: same as ``GeminiAdapter`` — log
``adapter.gemini_code_assist.multimodal_input_detected`` if
``promptTokensDetails`` lists non-text modalities, accept the v1
text-only under-count.

Pricing-matrix coupling: ``name = "gemini"`` (same provider id as
``GeminiAdapter``) so reports aggregate cleanly. The model id we
extract from the body must match a ``GEMINI_RATES`` entry — see
``pricing/matrix.py`` for the TEMP- placeholder for
``gemini-3-flash-preview`` landed alongside this adapter pending
real-traffic confirmation of the canonical SKU id.

Contract guarantees (same as every other adapter): stateless, pure,
must-not-raise. Parse failures return zero-valued metadata with
``tokens_complete=False`` rather than crashing the proxy hot path.
"""

from __future__ import annotations

import json
import time
from typing import Any, ClassVar

import structlog
from mitmproxy import http

from halton_meter.adapters.base import RequestMetadata, ResponseMetadata
from halton_meter.cloud_fields import (
    REQUEST_KIND_CHAT,
    canonical_prompt_hash,
    extract_idempotency_key,
)

log = structlog.get_logger()


_HOST = "cloudcode-pa.googleapis.com"
_PATH_PREFIX_NONSTREAM = "/v1internal:generateContent"
_PATH_PREFIX_STREAM = "/v1internal:streamGenerateContent"

# Fallback model id when the request body carries no recognisable
# model field. Surfaces in reports as ``model='gemini-code-assist-unknown'``
# so the user can spot misclassification. Pricing path falls back to
# the TEMP- placeholder for ``gemini-3-flash-preview`` (the model the
# Gemini CLI's UI summary surfaced in 2026-05-04 investigation).
_FALLBACK_MODEL = "gemini-code-assist-unknown"


class GeminiCodeAssistAdapter:
    """
    Adapter for ``cloudcode-pa.googleapis.com`` (Gemini Code Assist).

    Sibling of :class:`GeminiAdapter`; both share ``name="gemini"`` so
    cost reports aggregate across the two surfaces. Both stay live —
    a user may use the public Gemini API and the Code Assist CLI from
    the same machine.
    """

    name: ClassVar[str] = "gemini"
    domains: ClassVar[list[str]] = [_HOST]

    def matches(self, host: str) -> bool:
        """Match ``cloudcode-pa.googleapis.com`` exactly, with optional
        ``:port`` suffix.

        Same exact-match-plus-port-carve-out shape as the sibling
        adapters — guards against ``cloudcode-pa.googleapis.com.evil.com``
        and ``evil.cloudcode-pa.googleapis.com``.
        """
        return host == _HOST or host.startswith(f"{_HOST}:")

    def matches_url(self, host: str, path: str) -> bool:
        """Path-level filter — only the two billable inference actions.

        Rejects every control-plane path on the same host
        (``loadCodeAssist``, ``retrieveUserQuota``, ``listExperiments``,
        ``fetchAdminControls`` — all observed in the 2026-05-04 capture
        and all free of charge).
        """
        if not self.matches(host):
            return False
        # Use startswith so ``?alt=sse`` and any other query strings
        # pass through.
        if path.startswith(_PATH_PREFIX_NONSTREAM):
            return True
        if path.startswith(_PATH_PREFIX_STREAM):
            return True
        return False

    def parse_request(self, flow: http.HTTPFlow) -> RequestMetadata:
        """Extract model id + stream flag.

        Stream flag: derived from the URL action (``streamGenerateContent``)
        OR ``alt=sse`` query string. Either is sufficient.

        Model id: from the JSON request body. Code Assist wraps the
        public-API request under the top-level ``"request"`` key
        (server-side fan-out) but ALSO accepts a top-level ``"model"``
        in some client builds — both shapes are checked. When absent
        we log ``adapter.gemini_code_assist.model_observed`` with the
        fallback id so the user sees the entry surface and the
        operator gets a hint about real traffic shape (TEMP- marker
        for dev2; real fixture lands in dev3).
        """
        path = flow.request.path or ""
        stream = path.startswith(_PATH_PREFIX_STREAM) or "alt=sse" in path

        model = _FALLBACK_MODEL
        data: dict | None = None
        try:
            body = flow.request.get_text(strict=False) or ""
            if body:
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    data = parsed
                    model = self._extract_model(data) or _FALLBACK_MODEL
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Non-JSON body is unexpected on this host — log and use
            # the fallback so the request still gets a row.
            log.debug(
                "adapter.gemini_code_assist.request_body_not_json",
                host=_HOST,
                path=path,
            )

        # TEMP-CODEASSIST-DEV2 (memory/decisions.md 2026-05-04): always
        # log the observed model so dev3 can correct the TEMP- pricing
        # placeholder once a real Code Assist response is in hand.
        log.info(
            "adapter.gemini_code_assist.model_observed",
            provider=self.name,
            model=model,
            stream=stream,
            path=path,
        )

        # Wave 1A.ii fields. Code Assist is exclusively a chat surface
        # (generateContent / streamGenerateContent) — embeddings live on
        # the public Gemini host.
        prompt_hash = canonical_prompt_hash(data) if data else None
        idempotency_key = None
        try:
            idempotency_key = extract_idempotency_key(flow.request.headers)
        except Exception:
            idempotency_key = None

        return RequestMetadata(
            provider=self.name,
            model=model,
            stream=stream,
            started_at=time.monotonic(),
            request_kind=REQUEST_KIND_CHAT,
            prompt_hash=prompt_hash,
            idempotency_key=idempotency_key,
        )

    def parse_response(
        self,
        flow: http.HTTPFlow,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata:
        """Extract token counts from the completed response body.

        Two branches:
          1. Streaming SSE — walk ``data:`` chunks; the final chunk
             with ``usageMetadata`` wins.
          2. Non-streaming — single JSON object; pull ``usageMetadata``
             (top-level OR wrapped under ``response.usageMetadata``).
        """
        latency_ms = (time.monotonic() - request_meta.started_at) * 1000
        content_type = flow.response.headers.get("content-type", "") if flow.response else ""
        is_sse = "text/event-stream" in content_type or request_meta.stream

        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        cache_write_tokens = 0  # Code Assist context caching is server-side; no usage field.
        tokens_complete = True

        try:
            body = flow.response.get_text(strict=False) or ""

            if is_sse and body.lstrip().startswith("data:"):
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    tokens_complete,
                ) = self._parse_sse(body)
            else:
                data = json.loads(body) if body else {}
                usage = self._find_usage_metadata(data)
                if not usage:
                    tokens_complete = False
                else:
                    (
                        input_tokens,
                        output_tokens,
                        thinking_tokens,
                        cache_read_tokens,
                    ) = self._extract_usage_fields(usage)

        except Exception as exc:
            tokens_complete = False
            log.error(
                "adapter.parse_response.failed",
                provider=self.name,
                surface="code_assist",
                error=str(exc),
                exc_info=True,
            )

        return ResponseMetadata(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            thinking_tokens=thinking_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            tokens_complete=tokens_complete,
            latency_ms=latency_ms,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_model(data: Any) -> str | None:
        """Pull a model id out of a Code Assist request body.

        Tries (in order):
          - top-level ``"model"``
          - ``"request"."model"`` (Code Assist server-side wrapper)
          - ``"model"`` nested under any single dict-valued top-level key
            (defensive — shapes do drift between gemini-cli versions).
        """
        if not isinstance(data, dict):
            return None
        model = data.get("model")
        if isinstance(model, str) and model:
            return model
        request = data.get("request")
        if isinstance(request, dict):
            inner = request.get("model")
            if isinstance(inner, str) and inner:
                return inner
        # Last-ditch shallow walk for any single-level "model" we missed.
        for value in data.values():
            if isinstance(value, dict):
                inner = value.get("model")
                if isinstance(inner, str) and inner:
                    return inner
        return None

    @staticmethod
    def _find_usage_metadata(data: Any) -> dict[str, Any] | None:
        """Pull the ``usageMetadata`` dict out of a non-streaming body.

        Code Assist clients have been observed wrapping the public-API
        response under ``"response"``; we accept BOTH shapes:
          - top-level ``usageMetadata``
          - ``response.usageMetadata``
        """
        if not isinstance(data, dict):
            return None
        usage = data.get("usageMetadata")
        if isinstance(usage, dict) and usage:
            return usage
        response = data.get("response")
        if isinstance(response, dict):
            inner = response.get("usageMetadata")
            if isinstance(inner, dict) and inner:
                return inner
        return None

    def _extract_usage_fields(
        self, usage: dict[str, Any]
    ) -> tuple[int, int, int, int]:
        """Pull (input, output, thinking, cache_read) from a usageMetadata dict.

        Same field names as the public Gemini API:
          promptTokenCount         → input_tokens
          candidatesTokenCount     → output_tokens
          thoughtsTokenCount       → thinking_tokens (2.5+; 0 otherwise)
          cachedContentTokenCount  → cache_read_tokens (optional)

        Logs ``adapter.gemini_code_assist.multimodal_input_detected``
        when ``promptTokensDetails`` lists non-text modalities so the
        v1 text-only under-count can be quantified.
        """
        input_tokens = int(usage.get("promptTokenCount", 0) or 0)
        output_tokens = int(usage.get("candidatesTokenCount", 0) or 0)
        thinking_tokens = int(usage.get("thoughtsTokenCount", 0) or 0)
        cache_read_tokens = int(usage.get("cachedContentTokenCount", 0) or 0)

        details = usage.get("promptTokensDetails")
        if isinstance(details, list) and details:
            non_text = [
                d
                for d in details
                if isinstance(d, dict)
                and str(d.get("modality", "")).upper() not in ("", "TEXT")
            ]
            if non_text:
                log.info(
                    "adapter.gemini_code_assist.multimodal_input_detected",
                    provider=self.name,
                    modalities=[d.get("modality") for d in non_text],
                )

        return input_tokens, output_tokens, thinking_tokens, cache_read_tokens

    def _parse_sse(self, body: str) -> tuple[int, int, int, int, bool]:
        """Walk SSE chunks and return (input, output, thinking, cache_read, complete).

        Each ``data:`` chunk's payload follows the public-API shape;
        most chunks omit ``usageMetadata``. The final chunk that
        carries it wins. If no chunk has ``usageMetadata``, returns
        zeros + ``tokens_complete=False`` and emits
        ``adapter.gemini_code_assist.streaming_no_usage_block``.
        """
        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        found_usage = False

        for raw_line in body.splitlines():
            line = raw_line.strip()
            if not line.startswith("data:"):
                continue
            raw_data = line[len("data:") :].strip()
            if raw_data in ("[DONE]", ""):
                continue
            try:
                payload = json.loads(raw_data)
            except json.JSONDecodeError:
                continue

            usage = self._find_usage_metadata(payload)
            if usage:
                found_usage = True
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                ) = self._extract_usage_fields(usage)

        if not found_usage:
            log.debug(
                "adapter.gemini_code_assist.streaming_no_usage_block",
                provider=self.name,
                hint="no SSE chunk carried usageMetadata; client closed early?",
            )
            return (0, 0, 0, 0, False)

        return (input_tokens, output_tokens, thinking_tokens, cache_read_tokens, True)
