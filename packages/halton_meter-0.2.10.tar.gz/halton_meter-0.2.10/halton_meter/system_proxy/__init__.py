"""Public API for system-proxy management.

Platform-specific implementations live in ``_macos.py`` (darwin) and
``_linux.py`` (linux). Style A dispatch: at import time we select the
right impl module and forward all attribute lookups to it via
:pep:`562` module ``__getattr__``. Callers that previously imported
``halton_meter.system_proxy.X`` continue to work unchanged.

See ``memory/plans/2026-05-05-per-os-module-refactor.md``.
"""

from __future__ import annotations

import sys

from . import _common  # noqa: F401 — reserved for future platform-agnostic helpers

if sys.platform == "darwin":
    from . import _macos as _impl
elif sys.platform.startswith("linux"):
    from . import _linux as _impl  # type: ignore[no-redef]
else:
    raise RuntimeError(
        f"halton-meter does not support platform {sys.platform!r}; "
        "supported: darwin, linux."
    )


def __getattr__(name: str) -> object:
    # Forward unknown attributes to the platform impl module so that
    # ``halton_meter.system_proxy.X`` always reflects the current value
    # of ``_macos.X`` (or ``_linux.X``). This means tests that rebind a
    # function on ``_macos`` see their patch honoured by callers that
    # reach in via ``system_proxy.X``.
    try:
        return getattr(_impl, name)
    except AttributeError as exc:
        raise AttributeError(
            f"module 'halton_meter.system_proxy' has no attribute {name!r}"
        ) from exc


def __dir__() -> list[str]:
    return sorted(set(globals().keys()) | set(dir(_impl)))
