"""Linux apps-mode implementation for ``halton_meter.system_proxy``.

**v0.1.22.5 — UNTESTED on real Linux.** Subprocess-mocked unit tests only.

Apps mode on Linux means **no system-level proxy** is touched. Apps
inherit ``HTTPS_PROXY`` / ``HTTP_PROXY`` from the user's shell rc
(installed by :mod:`halton_meter.init`'s shell-rc append step) and from
new processes ``halton-meter`` spawns. Every function in this module is
either a deliberate no-op (so the daemon's startup / shutdown paths
work unmodified on Linux) or a path-helper that returns the same
sentinel locations as the macOS implementation (since the sentinels
are used to track install mode regardless of OS).

What this module does NOT cover (deferred to the proper Linux phase):

* Transparent proxy via iptables / nftables ``REDIRECT``.
* GNOME / KDE proxy settings via ``gsettings`` /
  ``kreadconfig5``.
* GUI app environment via systemd's ``import-environment`` / per-user
  ``environment.d``.

These are ``--full`` mode features. Apps mode is the conservative,
zero-network-rules path we ship in v0.1.22.5.
"""

from __future__ import annotations

import os
import subprocess
from collections.abc import Callable
from pathlib import Path

import structlog

from ._macos import (  # noqa: F401 — re-export the exception hierarchy
    AdminCancelledError,
    AdminElevationError,
    AdminInfrastructureError,
    AdminInnerCommandError,
)

log = structlog.get_logger(__name__)

# Empty tuple: macOS uses this to enumerate the launchctl gui-domain
# env-keys we care about. Linux has no launchctl analogue and apps mode
# never sets these — keeping the symbol for source-compat with macOS.
GUI_LAUNCHCTL_ENV_KEYS: tuple[str, ...] = ()

# Same sentinel locations as macOS — these mark install mode (apps vs
# proxy-managed), not OS-specific state.
_PROXY_MANAGED_SENTINEL = Path("~/.halton-meter/proxy-managed").expanduser()
_SYSTEM_STATE_PATH = Path("~/.halton-meter/system_state.json").expanduser()


def proxy_managed_sentinel_path() -> Path:
    """Return the path of the proxy-managed sentinel file."""
    return _PROXY_MANAGED_SENTINEL


def system_state_path() -> Path:
    """Return the snapshot file path (no-op storage on Linux apps mode)."""
    return _SYSTEM_STATE_PATH


def enable_system_proxy_if_managed(
    host: str, port: int, *, eager: bool = False
) -> None:
    """No-op on Linux apps mode.

    Apps mode never points the system proxy at us — we rely on
    ``HTTPS_PROXY`` env-var inheritance from shell rc. ``init --full``
    is gated to ``NotImplementedError`` on Linux so this code path
    only runs in apps mode where there is nothing to enable.

    Logs at DEBUG so a confused operator can grep
    ``daemon.err.log`` for ``system_proxy.linux_apps_mode_noop``.
    """
    log.debug(
        "system_proxy.linux_apps_mode_noop",
        op="enable_if_managed",
        host=host,
        port=port,
        eager=eager,
    )


def install_proxy_cleanup(
    our_host: str, our_port: int
) -> Callable[[], None] | None:
    """Return ``None`` on Linux apps mode — nothing to restore on shutdown.

    The macOS version registers atexit + signal handlers that reset the
    system proxy on daemon exit. On Linux apps mode the system proxy
    was never enabled, so there is nothing to undo.
    """
    log.debug(
        "system_proxy.linux_apps_mode_noop",
        op="install_proxy_cleanup",
        host=our_host,
        port=our_port,
    )
    return None


def reset_proxy_minimal() -> int:
    """Reset state — apps mode has no system proxy to reset, so this is a no-op success.

    Mirrors macOS exit-code contract (0 = ok, non-zero = failure). Used
    by ``halton-meter reset-proxy``.
    """
    log.info("system_proxy.linux_apps_mode_reset_noop")
    return 0


def setenv_user_domain(env_vars: dict[str, str]) -> dict[str, int]:
    """No-op on Linux apps mode — env vars come from shell rc.

    Returns the macOS-shaped result dict (key → exit code). On Linux
    every key reports 0 because there is nothing to set in a
    user-domain registry equivalent.
    """
    log.debug(
        "system_proxy.linux_apps_mode_noop",
        op="setenv_user_domain",
        keys=list(env_vars.keys()),
    )
    return {key: 0 for key in env_vars}


def unsetenv_user_domain(keys: list[str] | tuple[str, ...]) -> dict[str, int]:
    """No-op on Linux apps mode — symmetric with :func:`setenv_user_domain`."""
    log.debug(
        "system_proxy.linux_apps_mode_noop",
        op="unsetenv_user_domain",
        keys=list(keys),
    )
    return {key: 0 for key in keys}


def getenv_user_domain(key: str) -> str | None:
    """Return ``None`` — we don't manage a user-domain env registry on Linux."""
    return None


def read_proxy_target(
    interface: str | None = None,
) -> tuple[bool, str | None, str | None]:
    """Return ``(False, None, None)`` — Linux apps mode never points the system proxy at us."""
    return (False, None, None)


def snapshot_system_proxy() -> None:
    """No-op — there is no system proxy to snapshot in apps mode."""
    log.debug("system_proxy.linux_apps_mode_noop", op="snapshot")


def restore_system_proxy(our_host: str, our_port: int) -> bool:
    """Return ``False`` — nothing was snapshotted, so nothing to restore."""
    log.debug(
        "system_proxy.linux_apps_mode_noop",
        op="restore",
        host=our_host,
        port=our_port,
    )
    return False


def run_with_admin(
    argv: list[str],
    *,
    prompt_message: str | None = None,
    require_interactive: bool = False,
    timeout: int | None = None,
) -> subprocess.CompletedProcess:
    """Run ``argv`` under ``sudo`` on Linux. Apps-mode users should never
    hit this path — apps mode is admin-free by design — but doctor /
    reset paths may invoke it speculatively.

    Surfaces :class:`AdminInfrastructureError` if ``sudo`` is missing
    or returns non-interactive mode failures, mirroring the macOS
    contract so callers don't need a platform branch.
    """
    if not argv:
        raise AdminInfrastructureError("run_with_admin: empty argv")
    sudo_argv = ["sudo", "-n", *argv]
    try:
        return subprocess.run(
            sudo_argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as exc:
        raise AdminInfrastructureError(
            f"sudo not found on PATH: {exc}"
        ) from exc
    except subprocess.SubprocessError as exc:
        raise AdminInfrastructureError(
            f"sudo invocation failed: {exc}"
        ) from exc


def gui_uid() -> int:
    """Return the current user's UID — Linux equivalent of macOS gui domain UID."""
    return os.getuid()
