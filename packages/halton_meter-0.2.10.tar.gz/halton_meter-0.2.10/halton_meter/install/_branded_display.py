"""Visual-layer renderer for the branded install / uninstall surfaces.

v0.1.22.16. Pure rendering — no I/O, no state mutation, no install logic.
Consumes the raw ``_print`` event stream captured via
``_macos.start_capture()`` and emits ``brand_section`` blocks of
``brand_step`` rows so ``init`` and ``uninstall`` match the editorial
signature of ``status`` / ``start`` / ``stop`` / ``report`` / ``doctor``.

Why this is a separate module
-----------------------------
The classification logic (which raw event belongs in which section, how
to collapse 4 plist-write lines into one row, how to phrase the grouped
result) is the visual layer; the install logic in ``_macos.py`` stays
byte-identical at the function-call level. Keeping the renderer in its
own module makes the contract obvious: the install module produces an
event stream; the display module renders it. Either side can evolve
without touching the other.

``HALTON_DEBUG=1`` short-circuit
--------------------------------
The CLI / ``init`` callers consult :func:`debug_mode_enabled` before
starting capture. When set, capture stays off, the legacy
``[halton-meter] ...`` stderr lines flow as before, and no branded
sections render — preserving the verbose forensic path for install
troubleshooting without a separate code branch in the renderer.
"""

from __future__ import annotations

import os
from collections.abc import Iterable

from rich.console import Console

from halton_meter.branding import (
    MUTED,
    brand_section,
    brand_step,
)


def debug_mode_enabled() -> bool:
    """``True`` when ``HALTON_DEBUG=1`` (or any non-empty value) is set."""
    return bool(os.environ.get("HALTON_DEBUG"))


# ---------------------------------------------------------------------------
# Event classification
# ---------------------------------------------------------------------------


def _has_any(events: Iterable[str], *needles: str) -> bool:
    for e in events:
        for n in needles:
            if n in e:
                return True
    return False


def _count(events: Iterable[str], needle: str) -> int:
    return sum(1 for e in events if needle in e)


def _first_match(events: Iterable[str], needle: str) -> str | None:
    for e in events:
        if needle in e:
            return e
    return None


# ---------------------------------------------------------------------------
# init renderer
# ---------------------------------------------------------------------------


def render_init_supervisor_section(
    console: Console, events: list[str]
) -> None:
    """Render the supervisor section from captured events.

    On macOS: collapses ``writing X.plist`` / ``plist unchanged`` /
    ``launchctl bootout`` / ``launchctl kickstart`` events into rows.

    On Linux (v0.1.23 Blocker 3): collapses ``writing .../*.service`` /
    ``unit unchanged: ...`` / ``systemctl --user daemon-reload`` /
    ``systemctl --user enable --now ...`` events into rows. Section
    title becomes ``supervisor (systemd)``.

    No-op when no supervisor events are present (e.g. install errored
    out before bootstrap).
    """
    # Detect platform from events: ``.service`` writes are unambiguous
    # systemd; ``launchctl`` events are unambiguous launchd. Mixed runs
    # are impossible because install is a single platform-dispatch.
    is_linux_install = _has_any(
        events,
        "systemctl --user",
        ".service",
    )

    rows = []
    if is_linux_install:
        unit_writes = sum(
            1 for e in events
            if e.startswith("writing ") and ".service" in e
        )
        unit_unchanged = _count(events, "unit unchanged:")
        unit_total = unit_writes + unit_unchanged
        if unit_total:
            target_dir = "~/.config/systemd/user"
            if unit_writes and unit_unchanged:
                detail = f"{unit_writes} new, {unit_unchanged} unchanged"
                rows.append(
                    brand_step(
                        "ok",
                        f"Wrote {unit_total} units to {target_dir}",
                        detail,
                    )
                )
            elif unit_writes:
                plural = "s" if unit_writes != 1 else ""
                rows.append(
                    brand_step(
                        "ok",
                        f"Wrote {unit_writes} unit{plural} to {target_dir}",
                    )
                )
            else:
                rows.append(
                    brand_step(
                        "info",
                        f"{unit_unchanged} units unchanged (idempotent)",
                    )
                )
        if _has_any(events, "systemctl --user daemon-reload"):
            rows.append(brand_step("ok", "Reloaded systemd user manager"))
        enables = _count(events, "systemctl --user enable --now")
        if enables:
            plural = "s" if enables != 1 else ""
            rows.append(
                brand_step("ok", f"Enabled + started {enables} unit{plural}")
            )
        for e in events:
            if "user systemd unavailable" in e:
                rows.append(brand_step("warn", e))
        if not rows:
            return
        from rich.console import Group
        console.print(brand_section("supervisor (systemd)", Group(*rows)))
        console.print()
        return

    plist_writes = _count(events, "writing /")
    plist_unchanged = _count(events, "plist unchanged:")
    plist_total = plist_writes + plist_unchanged
    if plist_total:
        target_dir = "~/Library/LaunchAgents"
        if plist_writes and plist_unchanged:
            detail = f"{plist_writes} new, {plist_unchanged} unchanged"
            rows.append(
                brand_step(
                    "ok",
                    f"Wrote {plist_total} plists to {target_dir}",
                    detail,
                )
            )
        elif plist_writes:
            plural = "s" if plist_writes != 1 else ""
            rows.append(
                brand_step(
                    "ok",
                    f"Wrote {plist_writes} plist{plural} to {target_dir}",
                )
            )
        else:
            rows.append(
                brand_step(
                    "info",
                    f"{plist_unchanged} plists unchanged (idempotent)",
                )
            )

    bootstraps = _count(events, "launchctl bootout") and _count(events, "bootstrap gui/")
    if bootstraps:
        rows.append(
            brand_step(
                "ok",
                "Bootstrapped daemon, watchdog, edge, userenv supervisors",
            )
        )

    kickstarts = _count(events, "launchctl kickstart")
    if kickstarts:
        rows.append(
            brand_step(
                "ok",
                f"Kicked daemon + watchdog ({kickstarts} kickstarts)",
            )
        )

    # Surface bootstrap / kickstart failure events explicitly — they are
    # rare but high-stakes, and the closing failure panel renders them
    # in detail; here we just ensure the section at least flags them.
    for e in events:
        if e.startswith("error: launchctl"):
            rows.append(brand_step("error", e))

    if not rows:
        return
    from rich.console import Group
    console.print(brand_section("supervisor (launchd)", Group(*rows)))
    console.print()


def render_init_certificate_section(
    console: Console, events: list[str]
) -> None:
    """The certificate-trust section is rendered separately by ``init``
    via ``setup.render_result``. We add a brand header above the legacy
    checklist so it sits inside the editorial layout. Returns nothing —
    the actual checklist printing remains the caller's responsibility.
    """
    # No-op placeholder. The certifi/keychain progress lives in
    # setup.render_result; we add a brand_section header in init.py
    # itself rather than duplicating the row content here.
    return


def render_uninstall_sections(
    console: Console, events: list[str]
) -> None:
    """Render the editorial sections for ``halton-meter uninstall``.

    Three sections: sentinels-and-state, launchd-supervisors,
    system-proxy. Walls of ``[halton-meter] xxx`` collapse into a
    handful of branded step rows; the closing panel is rendered by
    the caller.
    """
    from rich.console import Group

    # Section 1: sentinels and state.
    sentinel_rows = []
    if _has_any(events, "removed /Users/") and _has_any(events, "apps-managed"):
        sentinel_rows.append(brand_step("ok", "Removed apps-managed sentinel"))
    if _first_match(events, "proxy-managed"):
        sentinel_rows.append(brand_step("ok", "Removed proxy-managed sentinel"))
    # Catch generic sentinel removals when only the system_state file path
    # appears. This is fine even if both fire — both rows are accurate.
    if not sentinel_rows:
        # Fall through with a generic "no sentinel state" row when the
        # uninstall ran on a never-installed machine.
        for e in events:
            if e.startswith("removed ") and "halton-meter" in e:
                sentinel_rows.append(brand_step("ok", "Removed sentinel state"))
                break
    if sentinel_rows:
        console.print(brand_section("sentinels and state", Group(*sentinel_rows)))
        console.print()

    # Section 2: supervisors.
    # v0.1.23 Blocker 3: detect Linux uninstall via systemctl events;
    # render systemd-shaped rows + section title instead of launchd.
    is_linux_uninstall = _has_any(events, "systemctl --user")
    sup_rows = []
    if is_linux_uninstall:
        disables = _count(events, "systemctl --user disable")
        unit_removed = sum(
            1 for e in events
            if e.startswith("removed ")
            and ("systemd/user" in e or ".service" in e)
        )
        if unit_removed:
            sup_rows.append(
                brand_step(
                    "ok",
                    f"Disabled + removed {unit_removed} supervisor unit"
                    f"{'s' if unit_removed != 1 else ''}",
                )
            )
        elif disables:
            sup_rows.append(
                brand_step("ok", f"Disabled {disables} supervisor unit(s)")
            )
        if _has_any(events, "systemctl --user daemon-reload"):
            sup_rows.append(brand_step("ok", "Reloaded systemd user manager"))
        if _has_any(events, "systemctl --user reset-failed"):
            sup_rows.append(brand_step("ok", "Cleared failed-state counters"))
        if sup_rows:
            from rich.console import Group as _G
            console.print(brand_section("systemd supervisors", _G(*sup_rows)))
            console.print()
        return

    unloaded_count = _count(events, "launchctl unload")
    plist_removed = sum(
        1 for e in events
        if e.startswith("removed ") and "Library/LaunchAgents" in e
    )
    if plist_removed:
        sup_rows.append(
            brand_step("ok", f"Unloaded + removed {plist_removed} supervisor plists")
        )
    elif unloaded_count:
        sup_rows.append(
            brand_step("ok", f"Unloaded {unloaded_count} supervisors")
        )
    if _first_match(events, "launchctl unsetenv:"):
        # The captured event has the form
        # "launchctl unsetenv: HTTPS_PROXY, HTTP_PROXY, ..."
        line = _first_match(events, "launchctl unsetenv:") or ""
        keys_part = line.split(":", 1)[1].strip() if ":" in line else ""
        n = len([k for k in keys_part.split(",") if k.strip()])
        if n:
            sup_rows.append(
                brand_step("ok", f"Cleared launchctl user-domain env ({n} keys)")
            )
        else:
            sup_rows.append(brand_step("ok", "Cleared launchctl user-domain env"))
    if _first_match(events, "removed halton-meter env block from"):
        line = _first_match(events, "removed halton-meter env block from") or ""
        path = line.split("from", 1)[-1].strip()
        sup_rows.append(brand_step("ok", "Removed shell-rc env block", path))
    if sup_rows:
        console.print(brand_section("launchd supervisors", Group(*sup_rows)))
        console.print()

    # Section 3: system proxy.
    proxy_rows = []
    reset_events = [e for e in events if e.startswith("system proxy reset on ")]
    if reset_events:
        ifaces = [e.split("system proxy reset on ", 1)[1].strip() for e in reset_events]
        proxy_rows.append(
            brand_step(
                "ok",
                f"Reset on {len(ifaces)} interface{'s' if len(ifaces) != 1 else ''}",
                ", ".join(ifaces),
            )
        )
    if _first_match(events, "system proxy restored from snapshot"):
        proxy_rows.append(
            brand_step("ok", "Restored system proxy from snapshot")
        )
    if _first_match(events, "removed edge proxy"):
        proxy_rows.append(brand_step("ok", "Removed edge proxy"))
    elif _first_match(events, "graceful uninstall: edge proxy"):
        # Graceful mode: edge stays running.
        proxy_rows.append(
            brand_step("info", "Edge proxy left running (graceful uninstall)")
        )
    if proxy_rows:
        console.print(brand_section("system proxy", Group(*proxy_rows)))
        console.print()


def render_purge_section(
    console: Console, events: list[str]
) -> None:
    """Render a ``data wipe`` section for ``uninstall --purge``.

    Picks up the ``removed ~/.halton-meter (database preserved)`` /
    ``(including database)`` events emitted by ``_purge_data_dir``.
    """
    from rich.console import Group

    rows = []
    if _first_match(events, "(including database)"):
        rows.append(
            brand_step("ok", "Removed ~/.halton-meter/ (including database)")
        )
    elif _first_match(events, "(database preserved)"):
        rows.append(
            brand_step(
                "ok",
                "Removed ~/.halton-meter/",
                "database preserved (db.sqlite + WAL siblings)",
            )
        )
    elif _first_match(events, "does not exist; nothing to purge"):
        rows.append(brand_step("info", "~/.halton-meter/ already absent"))
    for e in events:
        if e.startswith("warning:") and "purge" in e.lower():
            rows.append(brand_step("warn", e))
    if rows:
        console.print(brand_section("data wipe", Group(*rows)))
        console.print()


__all__ = [
    "debug_mode_enabled",
    "render_init_supervisor_section",
    "render_purge_section",
    "render_uninstall_sections",
]


# Re-export MUTED so consumers can import-from this module without
# pulling branding directly when they only need the renderer surface.
_ = MUTED
