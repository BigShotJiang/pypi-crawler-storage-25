"""Linux apps-mode implementation for ``halton_meter.install``.

**v0.1.22.5 — UNTESTED on real Linux.** Subprocess-mocked unit tests only.
The per-OS refactor (v0.1.22) left Linux helpers inside
:mod:`halton_meter.install._macos` verbatim (the historical flat
``install.py`` module already supported both platforms). Rather than
move that code and risk a large diff, this Linux-side module forwards
its public surface to ``_macos`` — the public ``install()`` /
``uninstall()`` orchestrators there already branch on ``sys.platform``
to call ``_install_linux`` / ``_uninstall_linux``.

Apps-mode only. ``--full`` mode (system-level proxy via networksetup-
equivalent on Linux, transparent-proxy via iptables/nftables) is gated
to ``NotImplementedError`` from :mod:`halton_meter.init`. Linux phase
0 covers: systemd user units (daemon + watchdog), env-var-only proxy
via shell rc, and CA cert generation/certifi patch (no system trust-
store install — apps-mode users rely on the certifi patched bundle
which works for every Python LLM client).

Forwards every public and private symbol from ``_macos.py`` so that
cross-imports like ``from halton_meter.install import _EDGE_LABEL``
keep working under the per-OS dispatch on Linux.
"""

from __future__ import annotations

import types as _types

from . import _macos as _macos_impl

# Re-export everything _macos.py defines. We forward ALL names so cross-
# module imports (``from halton_meter.install import <whatever>``) keep
# resolving on Linux. Skip standard-library module objects (subprocess,
# os, etc.) that _macos.py imports at the top — those would shadow real
# modules elsewhere.
_globals = globals()
for _name in dir(_macos_impl):
    if _name.startswith("__"):
        continue
    _attr = getattr(_macos_impl, _name)
    if isinstance(_attr, _types.ModuleType):
        continue
    _globals[_name] = _attr
del _globals, _name, _attr
