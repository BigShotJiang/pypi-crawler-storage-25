"""Beautiful, actionable error messages for Halton Meter CLI.

Provides structured error panels with clear remediation guidance using rich.
All errors print to console with context, possible causes, and next steps.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()


class HaltonError(Exception):
    """Base exception for Halton Meter errors with rich output support."""

    title: str = "Halton Meter Error"
    causes: list[str] = []
    remediation: list[str] = []

    def __init__(self, message: str, causes: list[str] | None = None, remediation: list[str] | None = None) -> None:
        self.message = message
        if causes is not None:
            self.causes = causes
        if remediation is not None:
            self.remediation = remediation
        super().__init__(message)

    def print_panel(self) -> None:
        """Print formatted error panel to console."""
        content = Text(self.message, style="red")

        if self.causes:
            content.append("\n\n[bold]Possible causes:[/bold]\n")
            for cause in self.causes:
                content.append(f"• {cause}\n")

        if self.remediation:
            content.append("\n[bold]How to fix:[/bold]\n")
            for i, step in enumerate(self.remediation, 1):
                content.append(f"{i}. {step}\n")

        panel = Panel(
            content,
            title=self.title,
            border_style="red",
            expand=False,
        )
        console.print(panel)


class DaemonNotRunningError(HaltonError):
    """Daemon is not running."""

    title = "Daemon is Not Running"
    remediation = [
        "Run: [bold cyan]halton-meter start[/bold cyan]",
        "Check logs: [bold cyan]tail ~/.halton-meter/daemon.log[/bold cyan]",
        "If that fails, run diagnostics: [bold cyan]halton-meter doctor[/bold cyan]",
    ]


class PortConflictError(HaltonError):
    """Network port is already in use."""

    title = "Port Conflict"

    def __init__(self, port: int, message: str = "") -> None:
        msg = f"Port {port} is already in use (busy)."
        if message:
            msg += f" {message}"
        causes = [
            f"Another proxy or service is listening on :{port}",
            "Daemon process didn't shut down cleanly",
            "System firewall blocking port",
        ]
        remediation = [
            f"Find what's using port {port}: [bold cyan]lsof -i :{port}[/bold cyan]",
            "Kill the process or change Halton Meter's port in config.toml",
            "Or try: [bold cyan]halton-meter restart[/bold cyan]",
        ]
        super().__init__(msg, causes=causes, remediation=remediation)


class PermissionError(HaltonError):
    """User lacks required permissions."""

    title = "Permission Denied"
    causes = [
        "System proxy requires admin/sudo",
        "File permissions issue (~/.halton-meter/)",
        "Firewall blocking network access",
    ]
    remediation = [
        "Run with sudo if setting system proxy: [bold cyan]sudo halton-meter init --apps[/bold cyan]",
        "Check folder permissions: [bold cyan]ls -la ~/.halton-meter/[/bold cyan]",
        "Check system proxy settings: [bold cyan]halton-meter doctor[/bold cyan]",
    ]


class ConfigError(HaltonError):
    """Configuration is invalid or missing."""

    title = "Configuration Error"
    causes = [
        "~/.halton-meter/config.toml has syntax errors",
        "Required config fields are missing",
        "Invalid values in config",
    ]
    remediation = [
        "Check syntax: [bold cyan]cat ~/.halton-meter/config.toml[/bold cyan]",
        "Validate TOML online: https://www.toml-lint.com",
        "Reset to defaults: [bold cyan]rm ~/.halton-meter/config.toml && halton-meter init[/bold cyan]",
    ]


class DatabaseLockedError(HaltonError):
    """SQLite database is locked."""

    title = "Database Locked"
    causes = [
        "Another Halton Meter process is using the database",
        "Daemon crashed and left the database in a locked state",
        "File system issue (permissions, bad sector)",
    ]
    remediation = [
        "Restart the daemon: [bold cyan]halton-meter restart[/bold cyan]",
        "If that fails, check processes: [bold cyan]ps aux | grep halton[/bold cyan]",
        "Remove stale lock: [bold cyan]rm ~/.halton-meter/db.sqlite-wal ~/.halton-meter/db.sqlite-shm[/bold cyan]",
        "Run: [bold cyan]halton-meter start[/bold cyan]",
    ]


class HealthCheckFailedError(HaltonError):
    """Daemon health check failed."""

    title = "Daemon Health Check Failed"
    causes = [
        "Daemon process crashed or is unresponsive",
        "Network connectivity issue",
        "Port configuration mismatch",
    ]
    remediation = [
        "Run diagnostics: [bold cyan]halton-meter doctor[/bold cyan]",
        "Check logs: [bold cyan]tail ~/.halton-meter/daemon.log[/bold cyan]",
        "Restart: [bold cyan]halton-meter restart[/bold cyan]",
        "If problem persists, try clean reinstall: [bold cyan]halton-meter uninstall && halton-meter init[/bold cyan]",
    ]


def handle_error(error: Exception) -> None:
    """Print error with appropriate formatting based on type."""
    if isinstance(error, HaltonError):
        error.print_panel()
    else:
        # Generic error fallback
        console.print(
            Panel(
                f"[red]{error}[/red]",
                title="Unexpected Error",
                border_style="red",
            )
        )
