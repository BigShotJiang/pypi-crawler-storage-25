"""
Entry point for ``halton-meter edge``.

The edge proxy runs as a separate launchd-supervised process (its own
plist lands in W3). This module is the bridge between the CLI/plist
ProgramArguments and the asyncio event loop that runs
:class:`halton_meter.edge.EdgeProxy`.

W1 deliberately leaves edge_host/edge_port/internal_host/internal_port
as constructable defaults. W2 wires them from the merged effective
config (defaults < runtime.toml < config.toml) once the
``edge_port`` / ``internal_port`` config keys land.
"""

from __future__ import annotations

import asyncio
import signal
import sys
from pathlib import Path

import structlog

from halton_meter.edge import EdgeConfig, EdgeProxy

log = structlog.get_logger(__name__)

# Sentinel paths consulted at shutdown to decide whether to restore the
# system proxy. Defined as module-level constants so tests can monkeypatch
# them without touching the real ~/.halton-meter directory.
_PROXY_MANAGED_SENTINEL_PATH = Path("~/.halton-meter/proxy-managed").expanduser()
_SYSTEM_STATE_PATH = Path("~/.halton-meter/system_state.json").expanduser()


def _restore_proxy_on_shutdown(bound_port: int) -> None:
    """Restore the macOS system proxy from snapshot on edge shutdown.

    v0.1.22 Fix 1: when the machine shuts down in --full mode, launchd
    sends SIGTERM to the edge process. Without this restore call the
    system proxy stays pointed at ``bound_port`` across the reboot. On
    next boot that port may be grabbed by an unrelated system process
    (e.g. parsecd), breaking all HTTPS traffic on the machine until the
    user manually clears the proxy.

    Only runs when:
    - ``~/.halton-meter/proxy-managed`` sentinel exists (--full mode only)
    - ``~/.halton-meter/system_state.json`` exists (snapshot present)

    In ``--apps`` mode (no sentinel) this is a no-op.  On failure the
    exception is swallowed and logged — the edge is observation
    infrastructure and must never block its own shutdown.
    """
    try:
        if not _PROXY_MANAGED_SENTINEL_PATH.exists():
            # Not in --full mode; system proxy was never managed by us.
            return
        if not _SYSTEM_STATE_PATH.exists():
            # No snapshot to restore from — nothing to do.
            return
        from halton_meter import system_proxy

        system_proxy.restore_system_proxy("127.0.0.1", bound_port)
        log.info("edge.shutdown_proxy_restored", port=bound_port)
    except Exception as exc:
        log.warning("edge.shutdown_proxy_restore_failed", error=str(exc))


async def run_edge(config: EdgeConfig) -> int:
    """Run the edge proxy until cancelled. Returns process exit code.

    On SIGINT / SIGTERM the listener is closed and the function returns
    0. Any unexpected error returns 1.
    """
    proxy = EdgeProxy(config)
    # Initialise to None so the finally block can safely skip the proxy
    # restore when start() failed before a port was bound.
    bound_port: int | None = None
    try:
        bound_port = await proxy.start()
    except OSError as exc:
        # Bind failure (port already in use, no permission, etc.). Print
        # a clear message to stderr — launchd captures this in
        # StandardErrorPath.
        print(
            f"[halton-meter-edge] bind failed on "
            f"{config.edge_host}:{config.edge_port}: {exc}",
            file=sys.stderr,
            flush=True,
        )
        return 1

    # v0.1.7 Gap 0: persist the chain target sidecar so doctor/status
    # can detect a stale-chain INCONSISTENT state (the failure mode
    # documented in 2026-05-01-edge-passthrough-lockin-bug.md).
    proxy.write_initial_state(bound_edge_port=bound_port)

    # v0.1.19.dev1 (Phase 2 Bug B): merge the edge's kernel-confirmed
    # bound edge_port into the shared effective-ports.json so readers
    # (`_apply-user-env`, status, doctor) publish the actually-listening
    # port — not the stale runtime.toml fallback the daemon may have
    # written before the edge re-bound.
    try:
        from halton_meter.port_alloc import merge_edge_port_into_effective_ports

        merge_edge_port_into_effective_ports(bound_port)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("edge.effective_ports_merge_failed", error=str(exc))

    print(
        f"[halton-meter-edge] listening on "
        f"{config.edge_host}:{bound_port} -> "
        f"{config.internal_host}:{config.internal_port}",
        file=sys.stderr,
        flush=True,
    )

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _request_stop() -> None:
        stop_event.set()

    # Best-effort signal handler install. Some platforms (Windows) don't
    # support add_signal_handler; the launchd plist is macOS-only for
    # v0.1.6 so this is fine in practice.
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _request_stop)
        except (NotImplementedError, RuntimeError):
            pass

    # v0.1.22.10 — daemon SIGUSR1s us after its startup ready to request
    # edge-state.toml re-emit. The persistent edge (KeepAlive=True per B4)
    # survives across daemon stop/start cycles, so without this signal
    # the sidecar is stale or missing whenever the daemon was the one
    # that touched the file system. Handler is purely a re-emit of the
    # already-known bound port — idempotent, no state mutation, atomic
    # write via ``os.replace``. Failure is swallowed and logged; the
    # edge is hot-path infrastructure and a sidecar regen must never
    # break it. SIGUSR1 is Unix-only; guarded for Windows portability.
    def _request_sidecar_regen() -> None:
        try:
            proxy.write_initial_state(bound_edge_port=bound_port)
            log.info("edge.sidecar_regen", port=bound_port)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("edge.sidecar_regen_failed", error=str(exc))

    if hasattr(signal, "SIGUSR1"):
        try:
            loop.add_signal_handler(signal.SIGUSR1, _request_sidecar_regen)
        except (NotImplementedError, RuntimeError):
            pass

    serve_task = asyncio.create_task(proxy.serve_forever(), name="edge-serve")
    stop_task = asyncio.create_task(stop_event.wait(), name="edge-stop-wait")
    # v0.1.8 Gap 10: poll runtime.toml so the edge re-resolves the chain
    # target the moment the daemon rebinds, with zero failed CONNECTs.
    # Stdlib-only mtime polling — see EdgeProxy.watch_runtime_toml.
    watch_task = asyncio.create_task(
        proxy.watch_runtime_toml(), name="edge-runtime-watch"
    )

    try:
        done, _pending = await asyncio.wait(
            {serve_task, stop_task}, return_when=asyncio.FIRST_COMPLETED
        )
        if stop_task in done:
            log.info("edge.shutdown_signal_received")
        # If serve_task completed (cancelled or error), surface that.
        if serve_task in done and not serve_task.cancelled():
            try:
                serve_task.result()
            except asyncio.CancelledError:
                pass
            except Exception as exc:  # pragma: no cover - defensive
                log.error("edge.serve_failed", error=str(exc), exc_info=True)
                return 1
    finally:
        # v0.1.22.18 Fix 1: drain in-flight per-connection handlers
        # BEFORE awaiting ``proxy.stop()``. Order matters under
        # Python 3.12+: ``asyncio.Server.wait_closed()`` (which
        # ``stop()`` awaits internally) blocks until every spawned
        # handler task has completed. If we called ``stop()`` first
        # while a CONNECT tunnel is parked in ``readline()``, the
        # await would deadlock — the handler can only return after
        # cancellation, but cancellation hasn't been issued yet. So
        # cancel first; the handlers unwind through their
        # ``CancelledError`` exits; then ``stop()`` returns
        # immediately. Defensive guard around the cancel — the edge
        # is observation infrastructure and a drain failure must
        # never block its own shutdown.
        try:
            await proxy.cancel_inflight()
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("edge.shutdown_cancel_inflight_failed", error=str(exc))
        await proxy.stop()
        for task in (serve_task, watch_task):
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
        # v0.1.7 Gap 0: clean up the sidecar so a leftover file with a
        # dead PID doesn't fool the doctor on next status. Best-effort.
        try:
            from halton_meter.port_alloc import remove_edge_state_toml

            if config.state_path is not None:
                remove_edge_state_toml(config.state_path)
        except Exception:  # pragma: no cover - defensive
            pass
        # v0.1.22 Fix 1: restore the system proxy from snapshot when we
        # are in --full mode (proxy-managed sentinel present). This
        # handles the machine-shutdown path where launchd sends SIGTERM
        # but the system proxy has never been cleared. Only runs when we
        # actually bound a port (bound_port is not None).
        if bound_port is not None:
            _restore_proxy_on_shutdown(bound_port)
    return 0


def main() -> int:
    """Synchronous entry point used by the CLI subcommand and the plist.

    Resolves the edge config from the merged effective config
    (defaults < runtime.toml < config.toml). Falls back to literal
    defaults if the config layer raises (paranoid: a broken config.toml
    must never prevent the edge from binding its port — the cardinal
    rule applies to the edge as much as to the daemon).
    """
    try:
        from halton_meter.port_alloc import load_effective_config

        cfg = load_effective_config()
        config = EdgeConfig.from_halton_config(cfg)
    except Exception as exc:  # pragma: no cover - defensive
        print(
            f"[halton-meter-edge] config load failed ({exc}); "
            "falling back to defaults",
            file=sys.stderr,
            flush=True,
        )
        config = EdgeConfig()

    # v0.1.22 Fix 2: re-probe the edge port rather than insisting on the
    # stored fallback from effective-ports.json.  The stored value may be
    # stale across reboots — the OS can grab a previously-used fallback
    # port (e.g. parsecd taking :8082 at boot).  If the stored port is
    # free we use it immediately (zero overhead); if not we find the first
    # free port in the default probe range.  This prevents the post-reboot
    # hard-fail that left the user with a broken system proxy pointing at a
    # port owned by a system process.
    try:
        from halton_meter.port_alloc import probe_free_edge_port

        free_port = probe_free_edge_port(config.edge_port, host=config.edge_host)
        if free_port != config.edge_port:
            log.info(
                "edge.startup_port_reprobe",
                stored_port=config.edge_port,
                free_port=free_port,
            )
            config.edge_port = free_port
    except Exception as exc:
        log.warning("edge.startup_port_reprobe_failed", error=str(exc))
        # Proceed with whatever port was in config — bind attempt will
        # surface the error if the port is truly unavailable.

    try:
        return asyncio.run(run_edge(config))
    except KeyboardInterrupt:
        return 0
