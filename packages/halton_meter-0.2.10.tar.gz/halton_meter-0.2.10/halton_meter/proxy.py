"""
mitmproxy addon and DumpMaster runner for Halton Meter.

HaltonAddon is the mitmproxy addon class. It:
  - Filters requests to inference endpoints only (paths starting with /v1/messages)
  - Looks up the appropriate provider adapter for the request host
  - Parses request metadata and stores it keyed by flow ID
  - On response, parses response metadata, resolves project, computes cost,
    writes a LogRecord to SQLite, and prints a capture line

The hot path (request / response hooks) never raises — all errors are caught,
logged, and the flow continues unaffected. This is the cardinal rule: observation
must never become a single point of failure for the developer's workflow.

Path filtering rationale:
  The adapter registry matches on host (e.g. api.anthropic.com), but Anthropic
  exposes many non-inference endpoints on that host:
    /v1/mcp_servers, /api/oauth/..., /api/claude_cli/..., /mcp-registry/...
  These are matched by the adapter's matches() but should not be processed.
  The path filter lives here in proxy.py (not in the adapter) so that adapters
  remain pure host-matching parsers and the filtering concern stays in one place.
"""

from __future__ import annotations

import asyncio
import sys
import time
import uuid
from collections import defaultdict, deque
from datetime import UTC, datetime

import structlog
from mitmproxy import http
from mitmproxy.options import Options
from mitmproxy.tools.dump import DumpMaster

from halton_meter.adapters.anthropic import AnthropicAdapter
from halton_meter.adapters.base import ProviderAdapter
from halton_meter.adapters.gemini import GeminiAdapter
from halton_meter.adapters.gemini_code_assist import GeminiCodeAssistAdapter
from halton_meter.adapters.openai import OpenAIAdapter
from halton_meter.adapters.openai_codex import OpenAICodexAdapter
from halton_meter.adapters.xai import XAIAdapter
from halton_meter.body_capture import (
    BodyCaptureCache,
    CapturedBody,
    PendingCapture,
    build_body_record,
    capture_body,
)
from halton_meter.cloud_fields import get_source_machine
from halton_meter.config import HaltonConfig
from halton_meter.models import LogRecord
from halton_meter.observability import (
    heartbeat_loop,
    install_task_crash_handler,
)
from halton_meter.policy_engine import PolicyDecision, evaluate_policies
from halton_meter.pricing import compute_cost_millicents
from halton_meter.storage import StorageManager
from halton_meter.tagging import resolve_project_with_meta

log = structlog.get_logger()


# ---------------------------------------------------------------------------
# v0.1.7 Gap 4: per-host parse timeouts + circuit breaker
#
# The response hook used to call ``adapter.parse_response`` synchronously
# on the asyncio event loop. A pathological response body (e.g. a 50 MB
# accumulated SSE stream that triggers a slow regex) would stall the
# event loop, blocking every other in-flight flow until the parse
# returned. We now offload the parse to a worker thread under
# ``asyncio.wait_for`` with a per-host timeout; if a host racks up
# repeated timeouts the breaker trips and bypasses metering for that
# host until it cools off (60s -> 120s -> 240s, capped).
#
# Important invariants (do not redesign without re-reading these):
#  * Pure-buffer mode: mitmproxy is configured WITHOUT
#    ``stream_large_bodies`` / ``flow.response.stream``. ``parse_response``
#    is a pure function over the fully-accumulated body. If you ever
#    enable streaming mode, the asyncio.to_thread offload silently races
#    the stream — DO NOT enable streaming without revisiting the hook.
#  * ``_pending.pop`` happens BEFORE the circuit-open check so a
#    sustained outage cannot grow ``_pending`` unbounded.
#  * ONLY parse timeouts trip the breaker. Parse exceptions stay
#    fail-open without tripping — they don't stall the hot path, so
#    tripping on them would lose data unnecessarily.
# ---------------------------------------------------------------------------

PARSE_TIMEOUTS: dict[str, float] = {
    "api.anthropic.com": 5.0,
    "*": 3.0,
}

# Bodies larger than this are skipped entirely rather than truncated.
# Prevents a second memory spike when decoding + slicing a multi-modal payload
# that mitmproxy already buffered. 4 MiB is sufficient for all text-only
# LLM exchanges; vision payloads almost always exceed this.
_BODY_CAPTURE_SIZE_GATE_BYTES: int = 4 * 1024 * 1024  # 4 MiB

_CB_WINDOW_SEC = 60.0
_CB_FAILURE_THRESHOLD = 5
_CB_OPEN_DURATIONS = (60.0, 120.0, 240.0)  # 1st, 2nd, 3rd+ trip (capped)

# ---------------------------------------------------------------------------
# Adapter registry
#
# Maps host → adapter. To add a new provider: instantiate its adapter here.
# The registry is a list; first match wins.
# ---------------------------------------------------------------------------

ADAPTER_REGISTRY: list[ProviderAdapter] = [
    AnthropicAdapter(),
    OpenAIAdapter(),
    GeminiAdapter(),
    # Gemini Code Assist (sibling of GeminiAdapter; same name="gemini" so
    # reports aggregate). Host is unique (cloudcode-pa.googleapis.com)
    # so registration order is not load-bearing.
    # See ADR memory/decisions.md 2026-05-04 — sibling-adapter pattern
    # for divergent provider surfaces.
    GeminiCodeAssistAdapter(),
    # OpenAI Codex backend (sibling of OpenAIAdapter; same name="openai"
    # so reports aggregate). Host is unique (chatgpt.com) so registration
    # order is not load-bearing. Path-prefix-scoped to /backend-api/codex/*
    # to avoid metering the classic ChatGPT site (`/api/conversation` etc.)
    # which lives on the same host. See ADR memory/decisions.md 2026-05-04
    # — sibling-adapter pattern dev3 extension.
    OpenAICodexAdapter(),
    # xAI / Grok (multi-provider PR4, 2026-05-02). Host is unique
    # (api.x.ai), so registration order is not load-bearing — but kept
    # AFTER Gemini to match the per-PR sequencing of adapter rollout.
    # NOTE: /v1/chat/completions and /v1/messages prefixes are already in
    # ``_INFERENCE_PATH_PREFIXES`` (added by PR1 + pre-existing Anthropic
    # entry); xAI does NOT need new path-filter entries.
    XAIAdapter(),
]


def find_adapter(host: str, path: str = "") -> ProviderAdapter | None:
    """Return the first adapter that matches the given host+path, or None.

    Dispatches via ``matches_url(host, path)`` (Protocol bump 2026-05-02,
    multi-provider PR2). Adapters that do not override ``matches_url``
    inherit the default-via-``matches`` semantics, so callers that do not
    yet pass a path (e.g. the response-side lookup, where the host is the
    sole identifier needed) keep working with a sentinel empty path.
    """
    for adapter in ADAPTER_REGISTRY:
        # ``matches_url`` is an additive Protocol bump — fall back to
        # ``matches(host)`` for adapters (and test fakes) that haven't
        # implemented it yet. This keeps the bump strictly additive: no
        # existing adapter behaviour changes when matches_url is absent.
        matches_url = getattr(adapter, "matches_url", None)
        if matches_url is not None:
            if matches_url(host, path):
                return adapter
        elif adapter.matches(host):
            return adapter

    # Defensive logging: requests that reach adapter dispatch but match no
    # adapter indicate either an unknown provider or a path collision
    # (e.g. a third-party service's URL happens to match our patterns).
    # This helps diagnose cross-provider issues in system-proxy mode.
    log.debug("addon.no_adapter_match", host=host, path=path)
    return None


# ---------------------------------------------------------------------------
# Path filtering moved to adapters
#
# Removed global _INFERENCE_PATH_PREFIXES (2026-05-03, issue #2 fix).
# Each adapter now enforces its own strict path matching via matches_url(),
# preventing cross-provider collisions in system-proxy mode (where every
# app's traffic routes through and can accidentally match patterns meant
# for other providers). This eliminates the need for a global path filter
# that was too broad and error-prone.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def _format_cost(cost_millicents: int | None) -> str:
    """Format a cost value in millicents for display, e.g. '$0.0012'."""
    if cost_millicents is None:
        return "unknown"
    dollars = cost_millicents / 100_000
    return f"${dollars:.4f}"


def _now_iso() -> str:
    """Return the current UTC time as an ISO 8601 string."""
    return datetime.now(UTC).isoformat()


def _compute_time_to_first_token_ms(flow: http.HTTPFlow) -> int | None:
    """Return time-to-first-response-byte in milliseconds, or ``None``.

    Best-effort: uses mitmproxy's ``timestamp_end`` on the request
    (time the request bytes were fully delivered to the upstream) and
    ``timestamp_start`` on the response (time the first response byte
    arrived). When either timestamp is missing — or the values are
    nonsense (negative delta, e.g. clock-skewed test fixtures) — we
    return ``None`` rather than emit a misleading number.

    For non-streaming responses the contract permits ``None`` (the
    proxy hot path can also fall back to ``latency_ms`` if desired —
    not done here so the cloud receiver can distinguish "no TTFT
    measured" from "TTFT == E2E latency").
    """
    try:
        req_end = getattr(flow.request, "timestamp_end", None)
        resp_start = getattr(flow.response, "timestamp_start", None) if flow.response else None
        if req_end is None or resp_start is None:
            return None
        delta_sec = float(resp_start) - float(req_end)
    except (TypeError, ValueError):
        return None
    if delta_sec < 0:
        return None
    return int(delta_sec * 1000)


def _derive_status_from_response(flow: http.HTTPFlow) -> str:
    """Map an HTTPFlow's response code to a contract status value.

    Contract values: ``success`` / ``error`` / ``blocked_by_policy``.
    The blocked-by-policy branch is set explicitly elsewhere; this
    helper only distinguishes success from error based on the
    response status code. Missing / unparseable response falls back to
    ``success`` (same default the LogRecord schema uses) so we never
    fabricate an error signal.
    """
    try:
        status_code = int(flow.response.status_code) if flow.response else None
    except (AttributeError, TypeError, ValueError):
        return "success"
    if status_code is None:
        return "success"
    if status_code >= 400:
        return "error"
    return "success"


# ---------------------------------------------------------------------------
# Policy enforcement helpers (Phase 3)
# ---------------------------------------------------------------------------


async def _evaluate_project_policies(
    storage: StorageManager | None,
    project: str,
    model: str,
) -> PolicyDecision:
    """
    Fetch cached policies for the project and evaluate them against the request.

    Returns PolicyDecision(action='allow') if no storage or no policies.
    Never raises.
    """
    if storage is None:
        return PolicyDecision(action="allow")
    try:
        policies = await storage.get_policies(project)
        if not policies:
            return PolicyDecision(action="allow")
        running_total = await storage.get_running_monthly_total(project)
        requests_today = await storage.get_today_request_count(project)
        return evaluate_policies(
            policies=policies,
            project=project,
            model=model,
            running_total_millicents=running_total,
            requests_today=requests_today,
        )
    except Exception as exc:
        # Policy enforcement must never disrupt the proxy hot path
        log.error("policy.evaluation_error", project=project, error=str(exc), exc_info=True)
        return PolicyDecision(action="allow")


def _print_policy_decision(decision: PolicyDecision, project: str, model: str) -> None:
    """Print a policy warn/block line to stderr."""
    tag = "WARN" if decision.action == "warn" else "BLOCK"
    print(
        f"[halton-meter] policy.{decision.action.upper()} project={project} model={model}"
        f" reason={decision.reason}",
        file=sys.stderr,
        flush=True,
    )
    log.warning(
        f"policy.{tag.lower()}",
        project=project,
        model=model,
        reason=decision.reason,
        policy_id=decision.policy_id,
    )


async def _log_audit_event(
    storage: StorageManager | None,
    action: str,
    project: str,
    policy_id: str | None,
    metadata: dict,
) -> None:
    """
    Write a policy audit event to local SQLite.

    Replaces the Phase 1/3 ``_post_audit_event`` httpx POST to the backend
    — the daemon now writes audit events to the same SQLite file the
    FastAPI app reads from. Fire-and-forget; never raises.
    """
    if storage is None or storage._sessionmaker is None:
        return
    try:
        from halton_meter.api.services.audit import log_event
        from halton_meter.storage.models import Project

        async with storage._sessionmaker() as session, session.begin():
            project_id: str | None = None
            if project:
                from sqlalchemy import select  # local import to keep hot-path lean

                proj_result = await session.execute(
                    select(Project).where(Project.slug == project)
                )
                proj = proj_result.scalar_one_or_none()
                if proj is not None:
                    project_id = proj.id
            await log_event(
                session,
                action=action,
                project_id=project_id,
                policy_id=policy_id,
                metadata=metadata,
            )
    except Exception:  # pragma: no cover — observation-infrastructure rule
        pass


# ---------------------------------------------------------------------------
# mitmproxy addon
# ---------------------------------------------------------------------------


class HaltonAddon:
    """
    mitmproxy addon that intercepts LLM inference traffic and logs metadata.

    Lifecycle per request:
      request()  → path-filter → adapter lookup → parse_request → store in _pending
      response() → retrieve from _pending → parse_response → tag → cost → write DB → print
    """

    def __init__(
        self,
        storage: StorageManager | None = None,
        edge_port: int | None = None,
        body_capture_cache: BodyCaptureCache | None = None,
        max_body_bytes: int = 512 * 1024,
    ) -> None:
        # flow.id → PendingCapture (v0.1.13+: includes captured request body
        # alongside the pre-existing meta + requested_at fields).
        # Bounded in practice by in-flight request count.
        self._pending: dict[str, PendingCapture] = {}
        # StorageManager instance, provided by the runner at startup
        self._storage = storage
        # v0.1.12: edge_port is the user-facing proxy port (default 8081).
        # Passed to resolve_project so the two-hop traversal can skip the
        # edge process and find the real originating client process.
        # In v0.1.13+ this is only used by the legacy fallback path —
        # the production hot path consults the
        # ``halton_meter.attribution_store`` module singleton via
        # ``resolve_project`` Step 0 (SQLite-backed).
        self._edge_port = edge_port
        # v0.1.7 Gap 4: per-host circuit-breaker state. Only parse-
        # timeouts trip the breaker (parse exceptions are fail-open
        # without tripping — see module docstring for why).
        self._cb_timeouts: dict[str, deque[float]] = defaultdict(deque)
        self._cb_open_until: dict[str, float] = {}
        self._cb_trip_count: dict[str, int] = defaultdict(int)
        # v0.1.13: body-capture state. ``None`` means "feature off entirely"
        # (master switch False or cache wasn't passed in for any reason —
        # the addon falls back to no capture). The cache itself enforces
        # both the master switch AND the per-project opt-out.
        self._body_capture_cache = body_capture_cache
        self._max_body_bytes = max_body_bytes
        # Wave 1A.ii: snapshot the machine hostname once at addon
        # construction so every record written by this daemon process
        # carries a consistent ``source_machine`` value. Cached inside
        # ``cloud_fields.get_source_machine`` — calling the helper here
        # primes the cache even when no record is ever written.
        self._source_machine: str | None = get_source_machine()

    # ----------------------------------------------------------------- #
    # Gap 4 helpers — parse timeout + circuit breaker                    #
    # ----------------------------------------------------------------- #

    def _get_parse_timeout(self, host: str) -> float:
        return PARSE_TIMEOUTS.get(host, PARSE_TIMEOUTS["*"])

    def _is_circuit_open(self, host: str) -> bool:
        return time.monotonic() < self._cb_open_until.get(host, 0.0)

    def _record_parse_timeout(self, host: str) -> None:
        """Record a parse-timeout against ``host``; trip the breaker if
        we've crossed the threshold inside the rolling window. Only
        timeouts call this — parse exceptions do not.
        """
        now = time.monotonic()
        dq = self._cb_timeouts[host]
        dq.append(now)
        while dq and now - dq[0] > _CB_WINDOW_SEC:
            dq.popleft()
        if len(dq) >= _CB_FAILURE_THRESHOLD:
            idx = min(self._cb_trip_count[host], len(_CB_OPEN_DURATIONS) - 1)
            open_for = _CB_OPEN_DURATIONS[idx]
            self._cb_open_until[host] = now + open_for
            self._cb_trip_count[host] += 1
            dq.clear()
            log.warning(
                "addon.circuit_opened",
                host=host,
                open_for_sec=open_for,
                trip_count=self._cb_trip_count[host],
            )

    async def _write_record_then_body(
        self,
        record: LogRecord,
        body_record: object | None,
    ) -> None:
        """Write the counts row, THEN the body row.

        Both writes are kept inside a single fire-and-forget task created
        in the response hook. Sequencing is load-bearing: ``request_bodies``
        has an FK to ``requests(id)``, so the parent row must exist before
        the child insert hits the SQLite write lock. The earlier v0.1.13
        scheme used two parallel ``asyncio.create_task`` calls which
        raced for the lock; once the project row had been auto-created
        on the very first request, the body task started winning the
        race on every subsequent flow and silently failed FK inside
        ``IntegrityError`` → rollback. See decisions.md "Body capture
        v0.1.13.dev1 follow-up".

        ``write_record`` and ``write_body_record`` both swallow their
        own exceptions and log them; this wrapper additionally guards
        against an unexpected exception escaping (cardinal-rule: the
        proxy hot path is observation infrastructure, never block the
        user's traffic).
        """
        if self._storage is None:  # pragma: no cover — guard shouldn't fire
            return
        try:
            await self._storage.write_record(record)
        except Exception as exc:  # pragma: no cover — write_record swallows
            log.error(
                "addon.write_record_unexpected_failure",
                record_id=record.id,
                exc_type=type(exc).__name__,
                error=str(exc),
                exc_info=True,
            )
            return
        if body_record is None:
            return
        try:
            await self._storage.write_body_record(body_record)
        except Exception as exc:  # pragma: no cover — write_body_record swallows
            log.error(
                "addon.write_body_record_unexpected_failure",
                record_id=record.id,
                exc_type=type(exc).__name__,
                error=str(exc),
                exc_info=True,
            )

    async def request(self, flow: http.HTTPFlow) -> None:
        """
        Called when mitmproxy has the full outbound request.

        Policy enforcement runs here, before forwarding to the provider.
        If a policy blocks the request, we inject a synthetic 429 response
        and mark the flow as killed — the provider never sees the request.
        """
        host = flow.request.host
        path = flow.request.path

        # Adapter dispatch: each adapter enforces its own strict path matching.
        # Non-matching requests (unknown providers, non-inference paths) return
        # None and pass through without metering.
        adapter = find_adapter(host, path)
        if adapter is None:
            return

        try:
            meta = adapter.parse_request(flow)
            requested_at = _now_iso()

            # --- Policy enforcement (Phase 3) ---
            resolved = resolve_project_with_meta(
                flow,
                edge_port=self._edge_port,
            )
            project = resolved.project
            decision = await _evaluate_project_policies(
                storage=self._storage,
                project=project,
                model=meta.model,
            )

            if decision.action in ("warn", "block"):
                _print_policy_decision(decision, project=project, model=meta.model)
                # Write audit event to local SQLite fire-and-forget
                # (never blocks proxy; replaces the httpx POST that
                # previously called the cloud backend).
                asyncio.create_task(  # noqa: RUF006
                    _log_audit_event(
                        storage=self._storage,
                        action=(
                            "policy.warned"
                            if decision.action == "warn"
                            else "policy.blocked"
                        ),
                        project=project,
                        policy_id=decision.policy_id,
                        metadata={
                            "reason": decision.reason,
                            "model": meta.model,
                            **decision.metadata,
                        },
                    ),
                    name="policy-audit-event",
                )

            if decision.action == "block":
                # Inject synthetic 429 — the provider never sees this request.
                # We still write a LogRecord to SQLite with status='blocked_by_policy'.
                error_body = (
                    f'{{"type":"error","error":{{"type":"rate_limit_error",'
                    f'"message":"[Halton Meter] {decision.reason}"}}}}'
                )
                flow.response = http.Response.make(
                    429,
                    error_body,
                    {"content-type": "application/json"},
                )
                # Write a blocked LogRecord to SQLite (fire-and-forget)
                if self._storage is not None:
                    record = LogRecord(
                        id=str(uuid.uuid4()),
                        project=project,
                        provider=meta.provider,
                        model=meta.model,
                        input_tokens=0,
                        output_tokens=0,
                        thinking_tokens=0,
                        cache_read_tokens=0,
                        cache_write_tokens=0,
                        cost_millicents=None,
                        tokens_complete=False,
                        latency_ms=0.0,
                        time_to_first_token_ms=None,
                        requested_at=requested_at,
                        recorded_at=_now_iso(),
                        status="blocked_by_policy",
                        attribution_method=resolved.method,
                        source_workdir=resolved.source_workdir,
                        # Wave 1A.ii: cloud-sync fields. The blocked
                        # request never reached the provider, so the
                        # idempotency_key and request_kind we captured
                        # at request-parse time are still meaningful;
                        # prompt_hash captures the prompt the user
                        # tried to send for downstream auditing.
                        request_kind=meta.request_kind,
                        prompt_hash=meta.prompt_hash,
                        idempotency_key=meta.idempotency_key,
                        source_machine=self._source_machine,
                    )
                    asyncio.create_task(  # noqa: RUF006
                        self._storage.write_record(record),
                        name=f"write-blocked-record-{record.id}",
                    )
                return  # Do not add to _pending — response hook will skip it

            # v0.1.13: capture the request body. Defence-in-depth: every
            # branch is fail-open. If ``capture_body`` raises, we still
            # add to ``_pending`` (without a body) so the response hook
            # writes the counts row as before.
            #
            # v0.1.13.dev1: every silent-skip branch emits a debug log
            # so the body-capture path can never go quiet again. The
            # original PR2 silently fell through when ``is_enabled_for``
            # returned False or when the master cache was unwired,
            # making the "first request OK, second silently skipped"
            # bug invisible in production. Now: every "we are not
            # capturing this request" decision is visible at debug.
            captured_request_body: CapturedBody | None = None
            if self._body_capture_cache is None:
                log.debug(
                    "addon.body_capture.skip",
                    reason="no_cache",
                    flow_id=flow.id,
                    project=project,
                )
            else:
                try:
                    enabled = self._body_capture_cache.is_enabled_for(project)
                except Exception as exc:
                    # is_enabled_for() is fail-open in its own right but
                    # belt-and-braces: a cache poisoning bug must never
                    # take down the request hook.
                    log.error(
                        "addon.body_capture.optout_check_failed",
                        host=host,
                        project=project,
                        error=str(exc),
                        exc_info=True,
                    )
                    enabled = False
                if not enabled:
                    log.debug(
                        "addon.body_capture.skip",
                        reason="opt_out",
                        flow_id=flow.id,
                        project=project,
                        master_enabled=self._body_capture_cache.master_enabled,
                    )
                else:
                    try:
                        request_size = len(flow.request.content or b"")
                    except Exception:
                        request_size = 0
                    if request_size > _BODY_CAPTURE_SIZE_GATE_BYTES:
                        log.info(
                            "addon.body_capture.skip",
                            reason="body_too_large",
                            flow_id=flow.id,
                            size_bytes=request_size,
                            gate_bytes=_BODY_CAPTURE_SIZE_GATE_BYTES,
                        )
                        captured_request_body = None
                    else:
                        try:
                            captured_request_body = capture_body(
                                flow.request,
                                max_bytes=self._max_body_bytes,
                                side="request",
                            )
                        except Exception as exc:
                            log.error(
                                "addon.body_capture.request_failed",
                                host=host,
                                project=project,
                                flow_id=flow.id,
                                exc_type=type(exc).__name__,
                                error=str(exc),
                                exc_info=True,
                            )
                            captured_request_body = None

            self._pending[flow.id] = PendingCapture(
                meta=meta,
                requested_at=requested_at,
                request_body=captured_request_body,
            )
            log.info(
                "intercept.request",
                provider=adapter.name,
                model=meta.model,
                stream=meta.stream,
                host=host,
                path=path,
            )
        except Exception as exc:
            log.error(
                "addon.request.failed",
                host=host,
                path=path,
                error=str(exc),
                exc_info=True,
            )

    async def response(self, flow: http.HTTPFlow) -> None:
        """Async response hook with per-host parse timeout + circuit breaker.

        v0.1.7 Gap 4: the parse runs on a worker thread under
        ``asyncio.wait_for`` so a slow / stuck parser cannot stall the
        mitmproxy event loop; sustained per-host timeouts trip a
        circuit breaker that bypasses metering for that host until it
        cools off (see module docstring for the failure model).

        IMPORTANT — pure-buffer assumption:
          mitmproxy is configured WITHOUT ``stream_large_bodies`` /
          ``flow.response.stream``. That means ``flow.response.content``
          holds the fully-accumulated body (incl. SSE) by the time this
          hook fires, and ``adapter.parse_response`` is a pure function
          over that final body. If you ever enable streaming mode on
          mitmproxy, this ``asyncio.to_thread`` offload will silently
          start racing the stream — DO NOT enable streaming without
          revisiting this hook.
        """
        host = "<unknown>"
        try:
            host = flow.request.host

            pending = self._pending.pop(flow.id, None)
            if pending is None:
                return

            # Circuit open → bypass metering for this host. Pending
            # entry has already been popped so memory cannot grow
            # unbounded during a sustained outage.
            if self._is_circuit_open(host):
                log.info("addon.response.circuit_bypass", host=host, flow_id=flow.id)
                return

            request_meta = pending.meta
            requested_at = pending.requested_at
            # Pass path so adapters with strict matches_url (e.g. Gemini's
            # action-suffix check) succeed on the response side too — without
            # it, find_adapter falls through to the host-only fallback which
            # adapters may reject. Symptom before this fix: gemini requests
            # logged `intercept.request provider=gemini` then immediately
            # `addon.response.no_adapter` and never wrote a row.
            path = getattr(flow.request, "path", "") or ""
            adapter = find_adapter(host, path)
            if adapter is None:
                log.warning("addon.response.no_adapter", host=host, flow_id=flow.id)
                return

            # v0.1.13: capture the response body BEFORE the parse offload
            # (operator open-question #5 sign-off). This way a slow/stuck
            # parse cannot kill the body capture. The capture function is
            # fail-open; we wrap defensively anyway.
            captured_response_body: CapturedBody | None = None
            if self._body_capture_cache is None:
                log.debug(
                    "addon.body_capture.skip",
                    reason="no_cache",
                    flow_id=flow.id,
                    side="response",
                )
            elif pending.request_body is None:
                log.debug(
                    "addon.body_capture.skip",
                    reason="request_side_skipped",
                    flow_id=flow.id,
                    side="response",
                )
            else:
                try:
                    response_size = len(
                        (flow.response.content if flow.response is not None else None) or b""
                    )
                except Exception:
                    response_size = 0
                if response_size > _BODY_CAPTURE_SIZE_GATE_BYTES:
                    log.info(
                        "addon.body_capture.skip",
                        reason="body_too_large",
                        flow_id=flow.id,
                        size_bytes=response_size,
                        gate_bytes=_BODY_CAPTURE_SIZE_GATE_BYTES,
                    )
                    captured_response_body = None
                else:
                    try:
                        captured_response_body = capture_body(
                            flow.response,
                            max_bytes=self._max_body_bytes,
                            side="response",
                        )
                    except Exception as exc:
                        log.error(
                            "addon.body_capture.response_failed",
                            host=host,
                            flow_id=flow.id,
                            exc_type=type(exc).__name__,
                            error=str(exc),
                            exc_info=True,
                        )
                        captured_response_body = None

            # Offload parsing to a worker thread with a hard timeout so
            # a slow/stuck parser cannot stall the mitmproxy event loop.
            try:
                resp_meta = await asyncio.wait_for(
                    asyncio.to_thread(adapter.parse_response, flow, request_meta),
                    timeout=self._get_parse_timeout(host),
                )
            except TimeoutError:
                # asyncio.TimeoutError aliases TimeoutError on 3.11+.
                log.warning("addon.parse_response_timeout", host=host, flow_id=flow.id)
                self._record_parse_timeout(host)
                return  # fail-open — request already returned to client
            # Any other exception falls through to the outer except,
            # which logs and returns — does NOT trip the breaker.

            # Adapter signalled "skip this row" — request+response combo
            # carries no meterable signal (e.g. model=unknown + zero
            # tokens). Do not write a counts row; do not emit
            # intercept.complete. See adapters/base.py ProviderAdapter
            # docstring + decisions.md 2026-05-02.
            if resp_meta is None:
                log.info(
                    "addon.response.adapter_skipped",
                    host=host,
                    provider=request_meta.provider,
                    flow_id=flow.id,
                )
                return

            # Resolve project tag (sync, fast, never raises). The meta
            # tuple lets us populate attribution_method + source_workdir
            # on the LogRecord so the requests row carries the layer
            # that fired (Smart Attribution observability, 2026-05-02).
            resolved = resolve_project_with_meta(
                flow,
                edge_port=self._edge_port,
            )
            project = resolved.project

            # Local fallback cost from the bundled matrix. The repo's
            # write_record path will look up the active pricing_rates row
            # asynchronously and override this when one is found, so the
            # bundled matrix is only used until rates are seeded or for
            # models the matrix knows but the rates table doesn't.
            cost = compute_cost_millicents(
                model=request_meta.model,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                thinking_tokens=resp_meta.thinking_tokens,
                cache_read_tokens=resp_meta.cache_read_tokens,
                cache_write_tokens=resp_meta.cache_write_tokens,
            )

            recorded_at = _now_iso()
            # Wave 1A.ii: derive cloud-sync fields. Each helper is
            # fail-soft to ``None`` / contract default so a missing
            # field never blocks the write.
            ttft_ms = _compute_time_to_first_token_ms(flow)
            response_status = _derive_status_from_response(flow)
            record = LogRecord(
                id=str(uuid.uuid4()),
                project=project,
                provider=request_meta.provider,
                model=request_meta.model,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                thinking_tokens=resp_meta.thinking_tokens,
                cache_read_tokens=resp_meta.cache_read_tokens,
                cache_write_tokens=resp_meta.cache_write_tokens,
                cost_millicents=cost,
                tokens_complete=resp_meta.tokens_complete,
                latency_ms=resp_meta.latency_ms,
                time_to_first_token_ms=ttft_ms,
                requested_at=requested_at,
                recorded_at=recorded_at,
                status=response_status,
                attribution_method=resolved.method,
                source_workdir=resolved.source_workdir,
                # Wave 1A.ii: cloud-sync fields populated from the
                # adapter-captured RequestMetadata (request_kind,
                # prompt_hash, idempotency_key) and the daemon-process
                # hostname snapshot (source_machine).
                request_kind=request_meta.request_kind,
                prompt_hash=request_meta.prompt_hash,
                idempotency_key=request_meta.idempotency_key,
                source_machine=self._source_machine,
            )

            # Build the body record up-front so the write coroutine has
            # everything it needs without re-touching the proxy state.
            #
            # v0.1.13.dev1: build_body_record returns None when both sides
            # are None (e.g. opt-out, or both sides failed before the
            # response). Log the no-write decision so the silent path is
            # visible.
            body_record = None
            if (
                self._storage is not None
                and pending.request_body is not None
            ):
                body_record = build_body_record(
                    request_id=record.id,
                    request_body=pending.request_body,
                    response_body=captured_response_body,
                )
                if body_record is None:
                    log.debug(
                        "addon.body_capture.skip",
                        reason="no_body_to_write",
                        flow_id=flow.id,
                        record_id=record.id,
                    )
            elif self._storage is not None and pending.request_body is None:
                log.debug(
                    "addon.body_capture.skip",
                    reason="request_side_skipped",
                    flow_id=flow.id,
                    record_id=record.id,
                )

            # Write to SQLite asynchronously. The two writes are chained
            # in a single task: counts FIRST (so the parent ``requests``
            # row exists), then the body row (FK target now present).
            # Before v0.1.13.dev1 these were two parallel
            # ``asyncio.create_task`` calls, which raced for the SQLite
            # write lock — when the body task won, the FK constraint
            # caught the missing parent, and ``write_body_record``
            # rolled back silently inside its IntegrityError branch.
            # That manifested as the "first request body lands, every
            # subsequent body silently skipped" bug logged in the v0.1.13
            # trial run. Chaining preserves fire-and-forget semantics for
            # the proxy hot path while making the FK contract honour the
            # fact that bodies are children of counts.
            if self._storage is not None:
                asyncio.create_task(  # noqa: RUF006
                    self._write_record_then_body(record, body_record),
                    name=f"write-record-{record.id}",
                )

            log.info(
                "intercept.complete",
                provider=request_meta.provider,
                model=request_meta.model,
                project=project,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                thinking_tokens=resp_meta.thinking_tokens,
                cache_read_tokens=resp_meta.cache_read_tokens,
                cache_write_tokens=resp_meta.cache_write_tokens,
                tokens_complete=resp_meta.tokens_complete,
                cost_millicents=cost,
                latency_ms=round(resp_meta.latency_ms),
            )

            _print_capture(
                project=project,
                provider=request_meta.provider,
                model=request_meta.model,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                cost_millicents=cost,
                latency_ms=resp_meta.latency_ms,
            )

        except Exception as exc:
            # Fail-open. NOTE: parse exceptions land here. They do NOT
            # trip the breaker — only timeouts do (see
            # _record_parse_timeout).
            log.error(
                "addon.response.failed",
                host=host,
                error=str(exc),
                exc_info=True,
            )


def _print_capture(
    *,
    project: str,
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    cost_millicents: int | None,
    latency_ms: float,
) -> None:
    """Print a single-line capture summary to stderr."""
    cost_str = _format_cost(cost_millicents)
    print(
        f"[halton-meter] project={project} provider={provider} model={model}"
        f" input={input_tokens} output={output_tokens}"
        f" cost={cost_str} latency={round(latency_ms)}ms",
        file=sys.stderr,
        flush=True,
    )


# ---------------------------------------------------------------------------
# DumpMaster runner with resilient socket binding
# ---------------------------------------------------------------------------


def _create_dumpmaster_with_retry(
    listen_host: str,
    listen_port: int,
    max_retries: int = 3,
) -> DumpMaster:
    """
    Create a mitmproxy DumpMaster with retry logic and clear error logging.

    Handles TIME_WAIT port reuse and other transient socket errors. Retries
    with exponential backoff (500ms, 1000ms, 2000ms). On final failure,
    raises the exception so the daemon startup fails loudly.

    Port binding resilience (v0.1.16 Issue #1):
      * SO_REUSEADDR is set via mitmproxy Options (if supported) or we retry
      * Exponential backoff handles TIME_WAIT and transient lock timeouts
      * Clear logging makes startup failures debuggable
    """
    import time as _time

    for attempt in range(1, max_retries + 1):
        try:
            options = Options(
                listen_host=listen_host,
                listen_port=listen_port,
            )
            # Attempt to enable SO_REUSEADDR if mitmproxy supports it.
            # mitmproxy.options.Options may not expose socket_reuseaddr,
            # so we set it defensively without raising if missing.
            if hasattr(options, "socket_reuseaddr"):
                options.socket_reuseaddr = True
            # v0.1.22.25: do NOT wire ``ignore_hosts`` here. The
            # ``mitmproxy_ignore_hosts_regex()`` helper in
            # ``halton_meter.providers.hosts`` is unsafe when consumed by
            # mitmproxy's ``re.search``-based ignore-list matcher: an
            # IP-form CONNECT (e.g. ``160.79.104.10:443`` — Anthropic's
            # own A record) matches the "ignore" branch and gets
            # tunnelled raw, silently dropping metering for that flow.
            # The edge's allowlist gate (added in v0.1.22.24) is the
            # canonical defence; mitmproxy's belt-and-braces here was
            # actively unsafe. See ``memory/decisions.md`` 2026-05-11
            # entry for v0.1.22.25. The structural guard test
            # ``tests/test_proxy_no_ignore_hosts.py`` enforces this.
            master = DumpMaster(options, with_termlog=False, with_dumper=False)
            log.info(
                "daemon.listener_bind_success",
                listen_host=listen_host,
                listen_port=listen_port,
                attempt=attempt,
            )
            return master
        except (OSError, RuntimeError) as exc:
            if attempt < max_retries:
                backoff_ms = 500 * (2 ** (attempt - 1))
                backoff_sec = backoff_ms / 1000.0
                log.warning(
                    "daemon.listener_bind_failed_retrying",
                    listen_host=listen_host,
                    listen_port=listen_port,
                    attempt=attempt,
                    max_retries=max_retries,
                    error=str(exc),
                    backoff_sec=backoff_sec,
                )
                _time.sleep(backoff_sec)
            else:
                log.error(
                    "daemon.listener_bind_failed_final",
                    listen_host=listen_host,
                    listen_port=listen_port,
                    attempt=attempt,
                    error=str(exc),
                    exc_info=True,
                )
                raise


async def run_proxy(
    config: HaltonConfig,
    *,
    mitm_ready_event: asyncio.Event | None = None,
    startup_t0: float | None = None,
) -> None:
    """
    Start the mitmproxy DumpMaster with HaltonAddon.

    Initialises StorageManager, passes it to HaltonAddon, then blocks until
    Ctrl-C. Shuts down cleanly on interrupt.

    The daemon's tagger reads attribution decisions from the
    ``halton_meter.attribution_store`` module singleton (SQLite-backed,
    same file the rest of the daemon uses). The CLI's ``_run_daemon``
    wires the singleton's path before this function runs; if the
    singleton is unwired (test mode), Step 0 returns None and the
    tagger falls through to its legacy psutil chain.
    """
    from pathlib import Path

    from halton_meter import attribution_store

    # Q4.2 (v0.1.16): install the asyncio task crash hook before any
    # task is spawned in the daemon's hot path. Today's silent-task-
    # death failure mode (Bug 1: MITM acceptor crashes, asyncio
    # swallows the traceback, FastAPI keeps serving) becomes a single
    # ``daemon.task_crashed`` log line at ERROR with task name +
    # exception type + traceback. Idempotent — wraps any handler the
    # outer ``asyncio.run`` may have installed.
    try:
        install_task_crash_handler(asyncio.get_running_loop())
    except Exception as exc:  # pragma: no cover — defensive
        log.warning("daemon.crash_handler_install_failed", error=str(exc))

    storage = StorageManager(config.storage.db_path)
    await storage.initialise()

    # Best-effort: make sure the attribution-store singleton is wired
    # to the same SQLite file the addon's reads will hit. Idempotent
    # if the CLI already wired it. Tests that drive ``run_proxy``
    # directly get the wiring for free.
    if attribution_store.get_db_path() is None:
        attribution_store.set_db_path(
            Path(str(config.storage.db_path)).expanduser()
        )

    # v0.1.6 (2C.2): the daemon's mitmproxy listener binds the
    # internal_port. The user-facing edge_port is owned by the edge
    # proxy process; apps see edge_port in HTTPS_PROXY and the edge
    # chains CONNECTs through to this internal_port for metering. The
    # internal_port is loopback-only and is never advertised in any
    # env var.
    #
    # v0.1.16 Issue #1: wrap listener creation with retry logic and
    # clear error logging to handle TIME_WAIT and transient socket errors
    # on reboot.
    #
    # v0.1.21.1 instrumentation: bracket the DumpMaster construction with
    # structured phase events so ``daemon.err.log`` shows whether the
    # cold-boot zombie hangs INSIDE this call (port allocation / mitm
    # init) or somewhere else entirely.
    import time as _time_local

    def _elapsed_ms() -> int | None:
        if startup_t0 is None:
            return None
        return int((_time_local.perf_counter() - startup_t0) * 1000)

    log.info(
        "daemon.startup.phase",
        phase="mitm_construct_begin",
        listen_host=config.daemon.listen_host,
        listen_port=config.daemon.internal_port,
        elapsed_ms=_elapsed_ms(),
    )
    _mitm_t0 = _time_local.perf_counter()
    master = _create_dumpmaster_with_retry(
        listen_host=config.daemon.listen_host,
        listen_port=config.daemon.internal_port,
        max_retries=3,
    )
    _mitm_construct_ms = int((_time_local.perf_counter() - _mitm_t0) * 1000)
    log.info(
        "daemon.startup.phase",
        phase="mitm_construct_end",
        elapsed_ms=_elapsed_ms(),
        mitm_construct_ms=_mitm_construct_ms,
    )
    # v0.1.21.2: signal listener readiness to the startup health probe.
    # The probe (in ``cli._probe_listeners_post_bind``) is gated on this
    # event so it never TCP-connects the MITM port before mitmproxy
    # has had a chance to bind. Without this gate the probe could
    # false-kill a healthy startup on cold boot (witnessed in the
    # v0.1.21.1 err log: probe fired ~381ms after fastapi_serve_begin,
    # before mitm_construct_begin even started).
    if mitm_ready_event is not None:
        try:
            mitm_ready_event.set()
        except Exception:  # pragma: no cover — defensive; .set() is sync
            pass

    # v0.1.13: per-prompt body capture. The cache is the single place
    # the master switch + per-project opt-out converge; the addon
    # consults it for every captured request.
    body_cache = BodyCaptureCache(
        db_path=Path(str(config.storage.db_path)).expanduser(),
        master_enabled=config.bodies.enabled,
        ttl_seconds=config.bodies.cache_ttl_seconds,
    )
    if config.bodies.enabled:
        print(
            f"[halton-meter] Body capture: ENABLED "
            f"(cap {config.bodies.max_body_bytes:,} bytes/body, "
            f"per-project opt-out via `halton-meter project … set body-capture off`).",
            file=sys.stderr,
            flush=True,
        )
    else:
        print(
            "[halton-meter] Body capture: DISABLED via "
            "config.toml (bodies.enabled = false).",
            file=sys.stderr,
            flush=True,
        )

    master.addons.add(
        HaltonAddon(
            storage=storage,
            edge_port=config.daemon.edge_port,
            body_capture_cache=body_cache,
            max_body_bytes=config.bodies.max_body_bytes,
        )
    )

    print(
        f"[halton-meter] Daemon proxy (internal) listening on "
        f"http://{config.daemon.listen_host}:{config.daemon.internal_port}",
        file=sys.stderr,
        flush=True,
    )
    print(
        f"[halton-meter] Apps should set HTTPS_PROXY=http://"
        f"{config.daemon.listen_host}:{config.daemon.edge_port} "
        f"(edge proxy chains to this daemon).",
        file=sys.stderr,
        flush=True,
    )
    print("[halton-meter] Press Ctrl-C to stop.", file=sys.stderr, flush=True)

    # Q4.1 (v0.1.16): listener heartbeat. Every 30s emits one INFO
    # ``daemon.heartbeat`` line with mitm/api listener status, db
    # readability, and a rough open-FD count. Tail-friendly signal that
    # makes any silent-failure (Bug 1, Bug 4) immediately visible
    # without restructuring supervision.
    heartbeat_task: asyncio.Task[None] | None = None
    try:
        heartbeat_task = asyncio.create_task(
            heartbeat_loop(
                mitm_port=config.daemon.internal_port,
                api_port=config.daemon.api_port,
                db_path=Path(str(config.storage.db_path)).expanduser(),
            ),
            name="halton-heartbeat",
        )
    except Exception as exc:  # pragma: no cover — defensive
        log.warning("daemon.heartbeat_spawn_failed", error=str(exc))

    try:
        await master.run()
    except KeyboardInterrupt:
        master.shutdown()
        print("\n[halton-meter] Stopped.", file=sys.stderr, flush=True)
    finally:
        if heartbeat_task is not None and not heartbeat_task.done():
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except (asyncio.CancelledError, Exception):
                pass
        await storage.close()
