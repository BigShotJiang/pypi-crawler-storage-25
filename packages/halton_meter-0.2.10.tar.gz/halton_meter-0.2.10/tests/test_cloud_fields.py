"""Unit tests for ``halton_meter.cloud_fields``.

Covers the four helpers (``canonical_prompt_hash``,
``extract_idempotency_key``, ``derive_request_kind``,
``get_source_machine``) plus the deterministic-fixture contract
required by the Wave 1A.ii spec: the same logical prompt must hash to
the same digest regardless of dict key order or whitespace.
"""

from __future__ import annotations

import hashlib
import json
from typing import ClassVar

import pytest

from halton_meter.cloud_fields import (
    REQUEST_KIND_CHAT,
    REQUEST_KIND_EMBEDDING,
    REQUEST_KIND_TOOL,
    REQUEST_KIND_UNKNOWN,
    _reset_source_machine_cache_for_tests,
    canonical_prompt_hash,
    derive_request_kind,
    extract_idempotency_key,
    get_source_machine,
    is_valid_request_kind,
)

# ---------------------------------------------------------------------------
# canonical_prompt_hash
# ---------------------------------------------------------------------------


class TestCanonicalPromptHash:
    """The hash MUST be stable across key order, whitespace, and Unicode.

    This is the most load-bearing helper in Wave 1A.ii — the wire
    contract pins the field to SHA-256 of canonical-JSON-encoded
    prompt. Drift between adapters here would mean the cloud cannot
    dedupe equivalent prompts.
    """

    # A representative chat-style payload covering system + messages
    # + nested objects.
    _FIXTURE_PAYLOAD: ClassVar[dict] = {
        "model": "claude-haiku-4-5",
        "system": "you are a helpful assistant",
        "messages": [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ],
        "temperature": 0.7,
        "max_tokens": 16,
    }
    # Pre-computed expected digest. If you change the canonicalisation
    # rules (sort_keys, separators, ensure_ascii, utf-8) you MUST
    # re-pin this constant — the cloud receiver hashes the same way.
    _FIXTURE_EXPECTED_SHA = (
        # Generated via:
        #   import hashlib, json
        #   hashlib.sha256(
        #       json.dumps(_FIXTURE_PAYLOAD, sort_keys=True,
        #                   separators=(",", ":"), ensure_ascii=False
        #                   ).encode("utf-8")
        #   ).hexdigest()
        # The literal value is computed at import time below so the
        # test stays robust to local edits of _FIXTURE_PAYLOAD.
        hashlib.sha256(
            json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "system": "you are a helpful assistant",
                    "messages": [
                        {"role": "user", "content": "hi"},
                        {"role": "assistant", "content": "hello"},
                    ],
                    "temperature": 0.7,
                    "max_tokens": 16,
                },
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8")
        ).hexdigest()
    )

    def test_fixture_hash_is_64_hex_chars(self) -> None:
        digest = canonical_prompt_hash(self._FIXTURE_PAYLOAD)
        assert digest is not None
        assert len(digest) == 64
        # Hex characters only — the cloud's column type is fixed-width.
        int(digest, 16)

    def test_fixture_hash_matches_reference(self) -> None:
        digest = canonical_prompt_hash(self._FIXTURE_PAYLOAD)
        assert digest == self._FIXTURE_EXPECTED_SHA

    def test_dict_key_order_does_not_affect_hash(self) -> None:
        """Reorder every key — the digest must still match.

        Without ``sort_keys=True`` two adapters that happened to
        serialize the same payload with different key order would
        produce different hashes. The cloud receiver could not dedupe.
        """
        original = canonical_prompt_hash(self._FIXTURE_PAYLOAD)
        reordered = canonical_prompt_hash(
            {
                "max_tokens": 16,
                "temperature": 0.7,
                "messages": [
                    {"content": "hi", "role": "user"},
                    {"content": "hello", "role": "assistant"},
                ],
                "system": "you are a helpful assistant",
                "model": "claude-haiku-4-5",
            }
        )
        assert original == reordered

    def test_unicode_content_hashes_consistently(self) -> None:
        """Non-ASCII content survives the UTF-8 encoding step."""
        payload = {"messages": [{"role": "user", "content": "héllo 你好 🦀"}]}
        digest = canonical_prompt_hash(payload)
        assert digest is not None
        # Re-hash via the same canonicalisation rules — must match.
        manual = hashlib.sha256(
            json.dumps(
                payload,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8")
        ).hexdigest()
        assert digest == manual

    def test_none_payload_returns_none(self) -> None:
        assert canonical_prompt_hash(None) is None

    def test_empty_dict_returns_none(self) -> None:
        """Empty containers carry no signal — they all hash to the
        same digest under any canonicalisation, which would collide
        meaninglessly across providers. Treat as None."""
        assert canonical_prompt_hash({}) is None
        assert canonical_prompt_hash([]) is None
        assert canonical_prompt_hash("") is None

    def test_bytes_payload_decoded_as_json(self) -> None:
        """Adapters sometimes hand the helper raw bytes — accept them."""
        payload = self._FIXTURE_PAYLOAD
        as_bytes = json.dumps(payload).encode("utf-8")
        digest = canonical_prompt_hash(as_bytes)
        assert digest == canonical_prompt_hash(payload)

    def test_non_serialisable_payload_does_not_raise(self) -> None:
        """Fail-soft: never block the request when the body is weird."""

        class Weird:
            pass

        # Must not raise. May return a digest computed over str()
        # fallback, or None — both are acceptable per the helper's
        # contract.
        result = canonical_prompt_hash({"x": Weird()})
        assert result is None or len(result) == 64


# ---------------------------------------------------------------------------
# extract_idempotency_key
# ---------------------------------------------------------------------------


class TestExtractIdempotencyKey:
    def test_returns_none_for_missing_header(self) -> None:
        assert extract_idempotency_key({}) is None
        assert extract_idempotency_key(None) is None

    def test_case_insensitive_match(self) -> None:
        assert extract_idempotency_key({"Idempotency-Key": "abc"}) == "abc"
        assert extract_idempotency_key({"idempotency-key": "abc"}) == "abc"
        assert extract_idempotency_key({"IDEMPOTENCY-KEY": "abc"}) == "abc"

    def test_anthropic_specific_header(self) -> None:
        assert (
            extract_idempotency_key({"Anthropic-Idempotency-Key": "xyz"}) == "xyz"
        )

    def test_x_idempotency_key(self) -> None:
        assert extract_idempotency_key({"X-Idempotency-Key": "k1"}) == "k1"

    def test_empty_value_rejected(self) -> None:
        """An ``Idempotency-Key: `` header carries no value — treat as missing."""
        assert extract_idempotency_key({"Idempotency-Key": ""}) is None
        assert extract_idempotency_key({"Idempotency-Key": "   "}) is None

    def test_strips_whitespace(self) -> None:
        assert extract_idempotency_key({"Idempotency-Key": "  abc  "}) == "abc"

    def test_never_synthesises_from_request_id(self) -> None:
        """The contract is echo-only. We DO recognise ``X-Request-Id``
        as a candidate (some SDKs reuse it), but we never make up a
        value when no header is present."""
        # Unrelated header — no match.
        assert extract_idempotency_key({"Authorization": "Bearer xxx"}) is None


# ---------------------------------------------------------------------------
# derive_request_kind
# ---------------------------------------------------------------------------


class TestDeriveRequestKind:
    def test_anthropic_messages_is_chat(self) -> None:
        assert derive_request_kind("/v1/messages") == REQUEST_KIND_CHAT

    def test_openai_chat_completions_is_chat(self) -> None:
        assert derive_request_kind("/v1/chat/completions") == REQUEST_KIND_CHAT

    def test_openai_responses_is_chat(self) -> None:
        assert derive_request_kind("/v1/responses") == REQUEST_KIND_CHAT

    def test_openai_embeddings_is_embedding(self) -> None:
        assert (
            derive_request_kind("/v1/embeddings") == REQUEST_KIND_EMBEDDING
        )

    def test_gemini_generate_content_is_chat(self) -> None:
        # Path includes the model id and action suffix — classifier is
        # case-insensitive (lowercases path before comparison).
        assert (
            derive_request_kind(
                "/v1beta/models/gemini-2.5-pro:generateContent"
            )
            == REQUEST_KIND_CHAT
        )

    def test_gemini_embed_content_is_embedding(self) -> None:
        assert (
            derive_request_kind(
                "/v1beta/models/text-embedding-004:embedContent"
            )
            == REQUEST_KIND_EMBEDDING
        )

    def test_unknown_path_returns_unknown(self) -> None:
        assert derive_request_kind("/v1/moderations") == REQUEST_KIND_UNKNOWN
        assert derive_request_kind("") == REQUEST_KIND_UNKNOWN

    def test_body_hint_with_tools_promotes_to_tool(self) -> None:
        body = {"tools": [{"name": "calculator"}]}
        assert (
            derive_request_kind("/v1/messages", body_hint=body)
            == REQUEST_KIND_TOOL
        )

    def test_body_hint_with_tool_choice_promotes_to_tool(self) -> None:
        body = {"tool_choice": "auto"}
        assert (
            derive_request_kind("/v1/chat/completions", body_hint=body)
            == REQUEST_KIND_TOOL
        )

    def test_empty_tools_list_falls_through_to_chat(self) -> None:
        body = {"tools": []}
        assert (
            derive_request_kind("/v1/messages", body_hint=body)
            == REQUEST_KIND_CHAT
        )

    def test_is_valid_request_kind(self) -> None:
        assert is_valid_request_kind("chat")
        assert is_valid_request_kind("embedding")
        assert is_valid_request_kind("tool")
        assert is_valid_request_kind("unknown")
        assert not is_valid_request_kind(None)
        assert not is_valid_request_kind("something-else")


# ---------------------------------------------------------------------------
# get_source_machine
# ---------------------------------------------------------------------------


class TestGetSourceMachine:
    def setup_method(self) -> None:
        _reset_source_machine_cache_for_tests()

    def teardown_method(self) -> None:
        _reset_source_machine_cache_for_tests()

    def test_returns_string_or_none(self) -> None:
        result = get_source_machine()
        assert result is None or isinstance(result, str)

    def test_cached_across_calls(self) -> None:
        first = get_source_machine()
        second = get_source_machine()
        assert first == second

    def test_socket_failure_falls_back_to_none(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``socket.gethostname`` can raise on sandboxed environments."""
        import socket

        def raise_oserror() -> str:
            raise OSError("no hostname available")

        monkeypatch.setattr(socket, "gethostname", raise_oserror)
        _reset_source_machine_cache_for_tests()
        assert get_source_machine() is None
