"""Structural guard — ``daemon/halton_meter/proxy.py`` must NOT pass
``ignore_hosts`` to mitmproxy.

Why this guard exists (v0.1.22.25 ADR — ``memory/decisions.md``
2026-05-11):

v0.1.22.24 wired ``mitmproxy_ignore_hosts_regex()`` from
``halton_meter.providers.hosts`` into mitmproxy's ``ignore_hosts``
option as belt-and-braces around the edge's allowlist gate. The helper
returned a negative-lookahead regex of the shape
``^(?!<llm-host-allowlist>).*`` intended for ``re.match`` semantics.
mitmproxy consumes ``ignore_hosts`` via ``re.search``, and although the
``^`` anchor in our regex prevents the obvious mid-string false-positive,
the regex still matches the ``host:port`` shape of an IP-form CONNECT
(e.g. ``160.79.104.10:443`` — an Anthropic A record). Result: a flow
that should be metered gets tunnelled raw, silently dropping coverage.

The edge's allowlist gate (``providers.hosts.host_should_intercept``
consulted in ``edge.py:_handle_connect``) is the canonical defence and
is unaffected. The mitmproxy belt-and-braces was actively unsafe and
has been removed. This test reads the ``proxy.py`` source and asserts
the wiring stays out.

If a future contributor wants to re-introduce ``ignore_hosts`` to
mitmproxy, they MUST first either (a) rewrite the helper to be safe
under ``re.search`` (i.e. handle IP-form ``host:port`` strings without
false-matching them as "ignore"), or (b) bypass this helper with a
different, hand-audited regex. Update the ADR in ``decisions.md`` and
this test together.
"""

from __future__ import annotations

from pathlib import Path

PROXY_SOURCE = (
    Path(__file__).resolve().parent.parent
    / "halton_meter"
    / "proxy.py"
)


def test_proxy_does_not_pass_ignore_hosts_to_mitmproxy() -> None:
    """``proxy.py`` must not wire ``ignore_hosts`` on mitmproxy Options.

    Reads the source rather than the runtime to catch the regression
    even when ``_create_dumpmaster_with_retry`` isn't exercised in a
    given test path.
    """
    src = PROXY_SOURCE.read_text(encoding="utf-8")
    # The whole point of this guard: any ``ignore_hosts=...`` assignment
    # or kwarg in proxy.py is forbidden. Comments and docstrings may
    # mention the string (this test's reasoning depends on naming it),
    # so strip comment lines before checking.
    code_lines = [
        line for line in src.splitlines()
        if not line.lstrip().startswith("#")
    ]
    code_only = "\n".join(code_lines)
    assert "ignore_hosts=" not in code_only, (
        "proxy.py must not pass ignore_hosts to mitmproxy — see "
        "v0.1.22.25 ADR in memory/decisions.md. The helper "
        "providers.hosts.mitmproxy_ignore_hosts_regex() is unsafe "
        "under mitmproxy's re.search-based matcher."
    )
    # Belt-and-braces: the inverse-allowlist helper must not be imported
    # by proxy.py either. The helper still lives in providers/hosts.py
    # (kept as a documented trap with a pinned-bad-behaviour test) but
    # is no longer a consumer in the daemon's hot path.
    assert "mitmproxy_ignore_hosts_regex" not in code_only, (
        "proxy.py must not import mitmproxy_ignore_hosts_regex — the "
        "helper is preserved in providers/hosts.py only to document "
        "the trap (see test_provider_hosts.py::"
        "test_mitmproxy_ignore_hosts_regex_is_unsafe_under_search)."
    )
