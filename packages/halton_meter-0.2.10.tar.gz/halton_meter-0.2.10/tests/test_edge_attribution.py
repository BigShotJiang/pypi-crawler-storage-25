"""
Unit tests for halton_meter.edge_attribution.

Covers:

* ``_resolve_via_psutil`` precedence: env var → .haltonrc → cwd basename
  → ``"unattributed"``, with the dual-port match (laddr.port=client_port
  AND raddr.port=edge_port).
* ``_sanitize_project_name`` mirrors the daemon-side behaviour
  (strip leading dots, collapse to ``"unattributed"`` on empty).
* ``_read_haltonrc`` walks parent directories.
* ``resolve_client_project`` returns ``"unattributed"`` on timeout
  and never raises.
* ``register_attribution`` writes through the SQLite-backed
  ``attribution_store`` module singleton synchronously and tolerates
  failure quietly. (Replaces the v0.1.13 HTTP path that was racing
  the daemon's ``request()`` hook in production — see the 2026-05-01
  fix.)

The psutil walk is exercised against a fake ``psutil`` module (sys.modules
swap) so we don't depend on real OS state.
"""

from __future__ import annotations

import sys
import types
from pathlib import Path
from typing import Any, ClassVar

import pytest

from halton_meter import attribution_store, edge_attribution

# --------------------------------------------------------------------------- #
# Test helpers — fake psutil                                                  #
# --------------------------------------------------------------------------- #


class _Addr:
    def __init__(self, port: int) -> None:
        self.port = port


class _Conn:
    def __init__(self, lport: int | None, rport: int | None) -> None:
        self.laddr = _Addr(lport) if lport is not None else None
        self.raddr = _Addr(rport) if rport is not None else None


def _make_proc(
    pid: int,
    conns: list[_Conn],
    cwd: str,
    environ: dict[str, str] | None = None,
    cwd_raises: type[Exception] | None = None,
    environ_raises: type[Exception] | None = None,
    cmdline: list[str] | None = None,
    name: str = "",
    parent: Any | None = None,
    parent_raises: type[Exception] | None = None,
) -> Any:
    """Build a SimpleNamespace that quacks like a psutil.Process.

    ``name`` and ``parent`` (plus ``parent_raises``) support the
    Chromium-helper parent-PID walk added 2026-05-02. Defaults preserve
    pre-walk behaviour: empty name + no parent → walk aborts immediately.
    """
    proc = types.SimpleNamespace(pid=pid)

    def _net() -> list[_Conn]:
        return conns

    proc.net_connections = _net

    def _cwd() -> str:
        if cwd_raises is not None:
            raise cwd_raises()
        return cwd

    proc.cwd = _cwd

    def _environ() -> dict[str, str]:
        if environ_raises is not None:
            raise environ_raises()
        return environ or {}

    proc.environ = _environ

    def _cmdline() -> list[str]:
        return list(cmdline or [])

    proc.cmdline = _cmdline

    def _name() -> str:
        return name

    proc.name = _name

    def _parent() -> Any | None:
        if parent_raises is not None:
            raise parent_raises()
        return parent

    proc.parent = _parent
    return proc


class _FakePsutil:
    NoSuchProcess = type("NoSuchProcess", (Exception,), {})
    AccessDenied = type("AccessDenied", (Exception,), {})
    ZombieProcess = type("ZombieProcess", (Exception,), {})

    # ClassVar so ruff doesn't complain about a mutable default.
    _processes: ClassVar[list[Any]] = []

    @classmethod
    def process_iter(cls, attrs: list[str]) -> list[Any]:
        # ``attrs`` mirrors the real psutil.process_iter signature even
        # though our fake ignores it — keeps call sites identical.
        del attrs
        return cls._processes


@pytest.fixture
def fake_psutil(monkeypatch: pytest.MonkeyPatch) -> type[_FakePsutil]:
    """Install ``_FakePsutil`` as ``sys.modules['psutil']`` for the test.

    Restored on teardown. Tests append to ``_FakePsutil._processes``
    to set up the world.
    """
    real = sys.modules.get("psutil")
    _FakePsutil._processes = []
    monkeypatch.setitem(sys.modules, "psutil", _FakePsutil)
    yield _FakePsutil
    if real is None:
        sys.modules.pop("psutil", None)
    else:
        sys.modules["psutil"] = real


@pytest.fixture(autouse=True)
def _isolate_store():
    """Reset the attribution-store singleton around each test."""
    attribution_store.set_db_path(None)
    yield
    attribution_store.set_db_path(None)


# --------------------------------------------------------------------------- #
# _sanitize_project_name                                                       #
# --------------------------------------------------------------------------- #


def test_sanitize_strips_leading_dots() -> None:
    assert edge_attribution._sanitize_project_name(".halton-meter") == "halton-meter"
    assert edge_attribution._sanitize_project_name("...x") == "x"
    assert edge_attribution._sanitize_project_name("plain") == "plain"


def test_sanitize_empty_becomes_unattributed() -> None:
    assert edge_attribution._sanitize_project_name("") == "unattributed"
    assert edge_attribution._sanitize_project_name("   ") == "unattributed"
    assert edge_attribution._sanitize_project_name("...") == "unattributed"


# --------------------------------------------------------------------------- #
# _read_haltonrc                                                               #
# --------------------------------------------------------------------------- #


def test_read_haltonrc_in_cwd(tmp_path: Path) -> None:
    (tmp_path / ".haltonrc").write_text("project: my-app\n")
    assert edge_attribution._read_haltonrc(str(tmp_path)) == ("my-app", None)


def test_read_haltonrc_walks_parents(tmp_path: Path) -> None:
    (tmp_path / ".haltonrc").write_text("project: outer\n")
    nested = tmp_path / "src" / "module"
    nested.mkdir(parents=True)
    assert edge_attribution._read_haltonrc(str(nested)) == ("outer", None)


def test_read_haltonrc_returns_none_when_absent(tmp_path: Path) -> None:
    nested = tmp_path / "deep" / "nested"
    nested.mkdir(parents=True)
    # A bare directory under tmp — there's no .haltonrc upward unless
    # the test runner's parent dirs contain one (unlikely under /var).
    project, body_capture = edge_attribution._read_haltonrc(str(nested))
    # Either fully missing, or some ancestor rcfile with a project string.
    assert project is None or isinstance(project, str)
    assert body_capture is None or isinstance(body_capture, bool)


# --------------------------------------------------------------------------- #
# _resolve_via_psutil                                                          #
# --------------------------------------------------------------------------- #


def test_resolve_no_match_returns_unattributed(fake_psutil: type[_FakePsutil]) -> None:
    """No process owns (laddr.port=12345, raddr.port=8081) → unattributed."""
    fake_psutil._processes = [
        _make_proc(1000, conns=[_Conn(99999, 8081)], cwd="/tmp/x"),
    ]
    project, body_capture, source_workdir = edge_attribution._resolve_via_psutil(
        client_port=12345, edge_port=8081
    )
    assert project == "unattributed"
    assert body_capture is True
    assert source_workdir is None


def test_resolve_env_var_wins(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """HALTON_PROJECT on the matched process beats .haltonrc and cwd."""
    (tmp_path / ".haltonrc").write_text("project: rc-name\n")
    fake_psutil._processes = [
        _make_proc(
            2000,
            conns=[_Conn(54321, 8081)],
            cwd=str(tmp_path),
            environ={"HALTON_PROJECT": "from-env"},
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54321, edge_port=8081
    )
    assert project == "from-env"
    # cwd has an .haltonrc but it doesn't set body_capture, so default True.
    assert body_capture is True


def test_resolve_haltonrc_wins_over_cwd(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """.haltonrc beats cwd basename when env var is absent."""
    (tmp_path / ".haltonrc").write_text("project: rc-tagged\n")
    fake_psutil._processes = [
        _make_proc(
            3000,
            conns=[_Conn(54322, 8081)],
            cwd=str(tmp_path),
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54322, edge_port=8081
    )
    assert project == "rc-tagged"
    assert body_capture is True


def test_resolve_falls_back_to_cwd_basename(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """With no env and no .haltonrc, cwd basename is used."""
    project_dir = tmp_path / "staffhub"
    project_dir.mkdir()
    fake_psutil._processes = [
        _make_proc(
            4000,
            conns=[_Conn(54323, 8081)],
            cwd=str(project_dir),
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54323, edge_port=8081
    )
    assert project == "staffhub"
    assert body_capture is True


def test_resolve_dual_match_prevents_misattribution(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """A process whose laddr.port collides but raddr is different is skipped.

    macOS frequently has unrelated processes with ephemeral ports
    that coincidentally equal the client port. Without the dual
    raddr.port==edge_port match, the wrong process would be picked.
    """
    decoy_dir = tmp_path / "decoy-system-process"
    decoy_dir.mkdir()
    real_dir = tmp_path / "windsurf-project"
    real_dir.mkdir()
    fake_psutil._processes = [
        # Decoy: same laddr.port but raddr is something else.
        _make_proc(
            5000,
            conns=[_Conn(54324, 12345)],
            cwd=str(decoy_dir),
        ),
        # Real client: laddr.port matches AND raddr.port == edge_port.
        _make_proc(
            5001,
            conns=[_Conn(54324, 8081)],
            cwd=str(real_dir),
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54324, edge_port=8081
    )
    assert project == "windsurf-project"
    assert body_capture is True


def test_resolve_environ_access_denied_falls_through(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """AccessDenied on environ() falls through to cwd-based attribution."""
    (tmp_path / ".haltonrc").write_text("project: fallback\n")
    fake_psutil._processes = [
        _make_proc(
            6000,
            conns=[_Conn(54325, 8081)],
            cwd=str(tmp_path),
            environ_raises=fake_psutil.AccessDenied,
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54325, edge_port=8081
    )
    assert project == "fallback"
    assert body_capture is True


def test_resolve_cwd_access_denied_returns_unattributed(
    fake_psutil: type[_FakePsutil],
) -> None:
    """AccessDenied on cwd() with no env-var hit yields unattributed."""
    fake_psutil._processes = [
        _make_proc(
            7000,
            conns=[_Conn(54326, 8081)],
            cwd="/never-read",
            cwd_raises=fake_psutil.AccessDenied,
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54326, edge_port=8081
    )
    assert project == "unattributed"
    assert body_capture is True


def test_resolve_no_psutil_returns_unattributed(monkeypatch: pytest.MonkeyPatch) -> None:
    """When psutil is unimportable, return unattributed cleanly."""
    monkeypatch.setitem(sys.modules, "psutil", None)
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=1, edge_port=8081
    )
    assert project == "unattributed"
    assert body_capture is True


def test_resolve_env_var_with_leading_dot_is_sanitized(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """A HALTON_PROJECT value with leading dot is stripped."""
    fake_psutil._processes = [
        _make_proc(
            8000,
            conns=[_Conn(54327, 8081)],
            cwd=str(tmp_path),
            environ={"HALTON_PROJECT": ".hidden"},
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54327, edge_port=8081
    )
    assert project == "hidden"
    assert body_capture is True


# --------------------------------------------------------------------------- #
# resolve_client_project                                                       #
# --------------------------------------------------------------------------- #


async def test_resolve_client_project_returns_via_psutil(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    proj = tmp_path / "demo"
    proj.mkdir()
    fake_psutil._processes = [
        _make_proc(9000, conns=[_Conn(54328, 8081)], cwd=str(proj)),
    ]
    project, body_capture, source_workdir = await edge_attribution.resolve_client_project(54328, 8081)
    assert project == "demo"
    assert body_capture is True
    assert source_workdir == str(proj)


async def test_resolve_client_project_timeout_returns_unattributed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the psutil walk runs past the budget, we return unattributed.

    Patch the synchronous helper to sleep > budget on a worker thread
    and confirm the wrapper returns "unattributed" without raising.
    """
    import time

    def _slow(client_port: int, edge_port: int) -> tuple[str, bool]:
        time.sleep(edge_attribution.RESOLVE_BUDGET_S * 3)  # past the budget
        return ("should-not-see-this", True)

    monkeypatch.setattr(edge_attribution, "_resolve_via_psutil", _slow)
    project, body_capture, _source_workdir = await edge_attribution.resolve_client_project(54329, 8081)
    assert project == "unattributed"
    assert body_capture is True


async def test_resolve_client_project_swallows_exceptions(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Any unexpected exception from the worker is swallowed."""

    def _raise(client_port: int, edge_port: int) -> tuple[str, bool]:
        raise RuntimeError("boom")

    monkeypatch.setattr(edge_attribution, "_resolve_via_psutil", _raise)
    project, body_capture, _source_workdir = await edge_attribution.resolve_client_project(54330, 8081)
    assert project == "unattributed"
    assert body_capture is True


# --------------------------------------------------------------------------- #
# register_attribution (SQLite-backed; replaces the v0.1.13 HTTP path)        #
# --------------------------------------------------------------------------- #


def test_register_attribution_persists_via_singleton(tmp_path: Path) -> None:
    """register_attribution writes through the attribution_store singleton.

    Verifies the structural fix: a singleton wired to the same path
    sees the edge's write — same primitive the daemon's tagger uses.
    """
    db = tmp_path / "shared.sqlite"
    attribution_store.set_db_path(db)
    edge_attribution.register_attribution(
        edge_src_port=55555,
        project_name="staffhub",
    )
    assert attribution_store.lookup(55555) == ("staffhub", None)


def test_register_attribution_silent_when_singleton_unwired(
    tmp_path: Path,
) -> None:
    """No path wired → register_attribution is a no-op, never raises."""
    attribution_store.set_db_path(None)
    edge_attribution.register_attribution(
        edge_src_port=55556,
        project_name="x",
    )
    # And nothing was persisted (no path to persist to).
    attribution_store.set_db_path(tmp_path / "fresh.sqlite")
    assert attribution_store.lookup(55556) is None


def test_register_attribution_does_not_raise_on_sqlite_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A sqlite3 error during write is logged and swallowed; never raises."""
    import sqlite3

    db = tmp_path / "ok.sqlite"
    attribution_store.set_db_path(db)
    # Bootstrap schema with a real connect first.
    attribution_store.write(1, "real")

    def _bad_connect(*args: object, **kwargs: object) -> object:
        raise sqlite3.OperationalError("disk full (simulated)")

    monkeypatch.setattr(sqlite3, "connect", _bad_connect)
    # Must not raise.
    edge_attribution.register_attribution(
        edge_src_port=55557,
        project_name="x",
    )


# --------------------------------------------------------------------------- #
# IDE-args workspace sniff (2026-05-01 fix — Vikrant trial run)               #
# --------------------------------------------------------------------------- #


def test_decode_windsurf_workspace_id_grounds_against_filesystem(
    tmp_path: Path,
) -> None:
    """``file_<encoded>`` decodes by backtracking on real directories.

    The encoding squashes both ``/`` and ``-`` into ``_``, so
    ``halton_meter_cloud`` is ambiguous between four splits. Greedy
    longest-match against the filesystem recovers the intended path.
    """
    project = tmp_path / "halton-meter-cloud"
    project.mkdir()
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    encoded = f"file_{encoded_root}_halton_meter_cloud"
    result = edge_attribution._decode_windsurf_workspace_id(encoded)
    assert result == str(project)


def test_decode_windsurf_workspace_id_returns_none_for_nonexistent(
    tmp_path: Path,
) -> None:
    """If no path under the encoded prefix exists, return None."""
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    encoded = f"file_{encoded_root}_does_not_exist_anywhere"
    assert edge_attribution._decode_windsurf_workspace_id(encoded) is None


def test_decode_windsurf_workspace_id_rejects_missing_prefix() -> None:
    assert edge_attribution._decode_windsurf_workspace_id("workspace_foo") is None
    assert edge_attribution._decode_windsurf_workspace_id("") is None


def test_extract_workspace_path_windsurf_form(tmp_path: Path) -> None:
    project = tmp_path / "haltonlabs-meter"
    project.mkdir()
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    cmdline = [
        "/Applications/Windsurf.app/Contents/Resources/app/extensions/"
        "windsurf/bin/language_server_macos_arm",
        "--ide_name",
        "windsurf",
        "--workspace_id",
        f"file_{encoded_root}_haltonlabs_meter",
        "--sentry_telemetry",
    ]
    assert (
        edge_attribution._extract_workspace_path_from_cmdline(cmdline)
        == str(project)
    )


def test_extract_workspace_path_vscode_folder_uri(tmp_path: Path) -> None:
    project = tmp_path / "my project"  # space → exercise URL-decode
    project.mkdir()
    cmdline = [
        "/Applications/Cursor.app/Contents/Frameworks/.../Code Helper",
        "--folder-uri",
        f"file://{str(project).replace(' ', '%20')}",
    ]
    assert (
        edge_attribution._extract_workspace_path_from_cmdline(cmdline)
        == str(project)
    )


def test_extract_workspace_path_inline_equals_form(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    project.mkdir()
    cmdline = ["/some/bin", f"--folder={project}"]
    assert (
        edge_attribution._extract_workspace_path_from_cmdline(cmdline)
        == str(project)
    )


def test_extract_workspace_path_returns_none_when_absent() -> None:
    cmdline = ["/usr/bin/python", "-m", "thing"]
    assert edge_attribution._extract_workspace_path_from_cmdline(cmdline) is None


def test_resolve_uses_ide_args_when_cwd_is_app_bundle(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """Windsurf trial-run regression.

    Process cwd is an app bundle (would resolve to a non-project
    basename). Argv carries the real workspace via ``--workspace_id``.
    Sniff must win over cwd-basename.
    """
    project = tmp_path / "halton-meter-cloud"
    project.mkdir()
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    bundle = tmp_path / "Resources"
    bundle.mkdir()
    fake_psutil._processes = [
        _make_proc(
            12000,
            conns=[_Conn(51999, 8082)],
            cwd=str(bundle),
            cmdline=[
                "language_server_macos_arm",
                "--workspace_id",
                f"file_{encoded_root}_halton_meter_cloud",
            ],
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=51999, edge_port=8082
    )
    assert project == "halton-meter-cloud"
    assert body_capture is True


def test_resolve_ide_args_walks_haltonrc_from_workspace(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """``.haltonrc`` inside the sniffed workspace beats workspace basename."""
    project = tmp_path / "haltonlabs-meter"
    project.mkdir()
    (project / ".haltonrc").write_text("project: halton-meter\n")
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    bundle = tmp_path / "AppBundle"
    bundle.mkdir()
    fake_psutil._processes = [
        _make_proc(
            12001,
            conns=[_Conn(51747, 8082)],
            cwd=str(bundle),
            cmdline=[
                "language_server_macos_arm",
                "--workspace_id",
                f"file_{encoded_root}_haltonlabs_meter",
            ],
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=51747, edge_port=8082
    )
    assert project == "halton-meter"
    assert body_capture is True


def test_resolve_haltonrc_in_cwd_still_wins_over_ide_args(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """If the matched process has its own .haltonrc, that wins.

    Pinned: the IDE-args sniff is a fallback for processes whose cwd
    can't be reasonably attributed. Terminal Claude (cwd in repo root
    with .haltonrc) must keep its current behaviour unchanged.
    """
    cwd = tmp_path / "real-cwd"
    cwd.mkdir()
    (cwd / ".haltonrc").write_text("project: claude-code\n")
    bogus = tmp_path / "bogus"
    bogus.mkdir()
    fake_psutil._processes = [
        _make_proc(
            12002,
            conns=[_Conn(40000, 8082)],
            cwd=str(cwd),
            cmdline=[
                "claude",
                "--workspace_id",
                f"file_{str(bogus).strip('/').replace('/', '_').replace('-', '_')}",
            ],
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=40000, edge_port=8082
    )
    assert project == "claude-code"
    assert body_capture is True


# --------------------------------------------------------------------------- #
# B1 (2026-05-02) — rcfile body_capture flag plumbed into attribution_log     #
# --------------------------------------------------------------------------- #


def test_read_haltonrc_body_capture_off(tmp_path: Path) -> None:
    """``body_capture: off`` parses to False; project still parses."""
    (tmp_path / ".haltonrc").write_text(
        "project: my-app\nbody_capture: off\n"
    )
    project, body_capture = edge_attribution._read_haltonrc(str(tmp_path))
    assert project == "my-app"
    assert body_capture is False


def test_read_haltonrc_body_capture_equals_form(tmp_path: Path) -> None:
    """``body_capture = off`` (with =) is the docs-facing shape; must parse."""
    (tmp_path / ".haltonrc").write_text(
        "project: my-app\nbody_capture = off\n"
    )
    project, body_capture = edge_attribution._read_haltonrc(str(tmp_path))
    assert project == "my-app"
    assert body_capture is False


def test_read_haltonrc_body_capture_on_explicit(tmp_path: Path) -> None:
    """``body_capture: on`` parses to True (explicit master-on default)."""
    (tmp_path / ".haltonrc").write_text(
        "project: my-app\nbody_capture: on\n"
    )
    project, body_capture = edge_attribution._read_haltonrc(str(tmp_path))
    assert project == "my-app"
    assert body_capture is True


def test_read_haltonrc_no_body_capture_field(tmp_path: Path) -> None:
    """An rcfile without the field returns None; resolver defaults to True."""
    (tmp_path / ".haltonrc").write_text("project: my-app\n")
    project, body_capture = edge_attribution._read_haltonrc(str(tmp_path))
    assert project == "my-app"
    assert body_capture is None


def test_read_haltonrc_unknown_value_defaults(tmp_path: Path) -> None:
    """Unrecognised values fall through to None (default-on at the resolver)."""
    (tmp_path / ".haltonrc").write_text(
        "project: my-app\nbody_capture: maybe\n"
    )
    project, body_capture = edge_attribution._read_haltonrc(str(tmp_path))
    assert project == "my-app"
    assert body_capture is None


def test_resolve_via_psutil_propagates_body_capture_off(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """rcfile body_capture=off → resolver returns body_capture=False."""
    project_dir = tmp_path / "demo"
    project_dir.mkdir()
    (project_dir / ".haltonrc").write_text(
        "project: demo\nbody_capture: off\n"
    )
    fake_psutil._processes = [
        _make_proc(
            13000,
            conns=[_Conn(54400, 8081)],
            cwd=str(project_dir),
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54400, edge_port=8081
    )
    assert project == "demo"
    assert body_capture is False


def test_resolve_via_psutil_ide_args_propagates_body_capture(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """When the workspace-sniff rcfile sets body_capture, that propagates."""
    project = tmp_path / "haltonlabs-meter"
    project.mkdir()
    (project / ".haltonrc").write_text(
        "project: halton-meter\nbody_capture: off\n"
    )
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    bundle = tmp_path / "AppBundle"
    bundle.mkdir()
    fake_psutil._processes = [
        _make_proc(
            13001,
            conns=[_Conn(54401, 8082)],
            cwd=str(bundle),
            cmdline=[
                "language_server_macos_arm",
                "--workspace_id",
                f"file_{encoded_root}_haltonlabs_meter",
            ],
        ),
    ]
    proj, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54401, edge_port=8082
    )
    assert proj == "halton-meter"
    assert body_capture is False


def test_register_attribution_writes_body_capture_off(tmp_path: Path) -> None:
    """register_attribution(..., body_capture_enabled=False) persists to row.

    B1 acceptance: rcfile with body_capture=off → attribution_log row has
    body_capture_enabled=0. Direct sqlite SELECT confirms the column shape
    B2 will read.
    """
    import sqlite3

    db = tmp_path / "shared.sqlite"
    attribution_store.set_db_path(db)
    edge_attribution.register_attribution(
        edge_src_port=44400,
        project_name="demo",
        body_capture_enabled=False,
    )
    with sqlite3.connect(str(db)) as conn:
        row = conn.execute(
            "SELECT project_name, body_capture_enabled "
            "FROM attribution_log WHERE edge_src_port = ?",
            (44400,),
        ).fetchone()
    assert row is not None
    assert row[0] == "demo"
    assert int(row[1]) == 0


def test_register_attribution_default_body_capture_is_one(tmp_path: Path) -> None:
    """B1 acceptance: missing rcfile / unset flag → row has body_capture_enabled=1."""
    import sqlite3

    db = tmp_path / "shared.sqlite"
    attribution_store.set_db_path(db)
    # Default param is True (master-on default).
    edge_attribution.register_attribution(
        edge_src_port=44401,
        project_name="demo",
    )
    with sqlite3.connect(str(db)) as conn:
        row = conn.execute(
            "SELECT body_capture_enabled FROM attribution_log "
            "WHERE edge_src_port = ?",
            (44401,),
        ).fetchone()
    assert row is not None
    assert int(row[0]) == 1


def test_register_attribution_body_capture_explicit_on(tmp_path: Path) -> None:
    """``body_capture: on`` explicit in rcfile → row has 1."""
    import sqlite3

    db = tmp_path / "shared.sqlite"
    attribution_store.set_db_path(db)
    edge_attribution.register_attribution(
        edge_src_port=44402,
        project_name="demo",
        body_capture_enabled=True,
    )
    with sqlite3.connect(str(db)) as conn:
        row = conn.execute(
            "SELECT body_capture_enabled FROM attribution_log "
            "WHERE edge_src_port = ?",
            (44402,),
        ).fetchone()
    assert row is not None
    assert int(row[0]) == 1


def test_resolve_no_rcfile_yields_default_body_capture(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """B1 acceptance: missing rcfile defaults body_capture_enabled to True."""
    project_dir = tmp_path / "no-rc-here"
    project_dir.mkdir()
    fake_psutil._processes = [
        _make_proc(
            13100,
            conns=[_Conn(54500, 8081)],
            cwd=str(project_dir),
        ),
    ]
    project, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54500, edge_port=8081
    )
    # cwd basename fallback. body_capture defaults True (master-on default).
    assert project == "no-rc-here"
    assert body_capture is True


# --------------------------------------------------------------------------- #
# PR2 (2026-05-02) — Smart Attribution v0.3 layers 4 / 6 / 6.5 wiring         #
# --------------------------------------------------------------------------- #
#
# These tests pin the EDGE-side wiring of the new layers added by Smart
# Attribution v0.3 PR2. The layers themselves are unit-tested in
# ``test_attribution_layers.py``; here we prove they fire correctly
# from inside ``_resolve_via_psutil`` against a realistic fake-psutil
# fixture and that the precedence vs. existing layers is correct.

from halton_meter.attribution import layers as _layers  # noqa: E402


@pytest.fixture(autouse=True)
def _clear_layers_git_cache():
    """Ensure layer 4's per-cwd cache doesn't leak across tests."""
    _layers._GIT_CACHE.clear()
    yield
    _layers._GIT_CACHE.clear()


def test_pr2_layer4_git_fires_at_edge(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """Layer 4 — git repo basename — fires from the edge resolver."""
    repo = tmp_path / "myrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    nested = repo / "src"
    nested.mkdir()
    fake_psutil._processes = [
        _make_proc(
            20000,
            conns=[_Conn(60000, 8081)],
            cwd=str(nested),
        ),
    ]
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=60000, edge_port=8081
    )
    assert project == "myrepo"


def test_pr2_layer4_git_outside_repo_falls_through_to_basename(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """No .git anywhere → layer 4 returns None → layer 7 (basename) fires."""
    leaf = tmp_path / "leaf-dir"
    leaf.mkdir()
    fake_psutil._processes = [
        _make_proc(
            20001,
            conns=[_Conn(60001, 8081)],
            cwd=str(leaf),
        ),
    ]
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=60001, edge_port=8081
    )
    # leaf basename or some ancestor's git repo basename — but NOT
    # an exception, and NOT unattributed (cwd basename is non-empty).
    assert project is not None
    assert project != "unattributed"


def test_pr2_layer6_k8s_fires_at_edge(
    fake_psutil: type[_FakePsutil], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Layer 6 — k8s container — fires from the edge resolver.

    The matched process's environ carries KUBERNETES_SERVICE_HOST and
    HOSTNAME; layer 6 emits ``k8s:<HOSTNAME>``. Layer 4 must NOT fire
    (no .git anywhere).
    """
    leaf = tmp_path / "app"  # cwd has no .git
    leaf.mkdir()
    fake_psutil._processes = [
        _make_proc(
            21000,
            conns=[_Conn(61000, 8081)],
            cwd=str(leaf),
            environ={
                "KUBERNETES_SERVICE_HOST": "10.0.0.1",
                "HOSTNAME": "checkout-pod-abc",
            },
        ),
    ]
    # Force layer 4 (git) to return None so this test is deterministic
    # regardless of whether tmp_path lives under a real git tree.
    monkeypatch.setattr(_layers, "resolve_via_git", lambda cwd: None)
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=61000, edge_port=8081
    )
    assert project == "k8s:checkout-pod-abc"


def test_pr2_layer6_docker_fires_at_edge(
    fake_psutil: type[_FakePsutil], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Layer 6 — docker — fires from the edge resolver."""
    leaf = tmp_path / "app"
    leaf.mkdir()
    fake_psutil._processes = [
        _make_proc(
            21001,
            conns=[_Conn(61001, 8081)],
            cwd=str(leaf),
            environ={"HOSTNAME": "a1b2c3d4"},
        ),
    ]
    monkeypatch.setattr(_layers, "resolve_via_git", lambda cwd: None)
    monkeypatch.setattr(
        _layers,
        "resolve_via_container",
        lambda env, fs_probe=None: (
            f"docker:{env['HOSTNAME']}" if env.get("HOSTNAME") else None
        ),
    )
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=61001, edge_port=8081
    )
    assert project == "docker:a1b2c3d4"


def test_pr2_layer6_dev_laptop_does_not_fire_at_edge(
    fake_psutil: type[_FakePsutil], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """REGRESSION: dev laptop (no container signals) → layer 6 returns None,
    fall through to basename. Without this case the v0.3 draft's bug recurs."""
    leaf = tmp_path / "dev-project"
    leaf.mkdir()
    fake_psutil._processes = [
        _make_proc(
            21002,
            conns=[_Conn(61002, 8081)],
            cwd=str(leaf),
            environ={"HOSTNAME": "vikrants-mbp"},
        ),
    ]
    monkeypatch.setattr(_layers, "resolve_via_git", lambda cwd: None)
    # Force the production fs_probe to never report container files.
    monkeypatch.setattr(_layers, "_default_container_fs_probe", lambda p: False)
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=61002, edge_port=8081
    )
    # Falls through to basename — NOT k8s:vikrants-mbp.
    assert project == "dev-project"
    assert "k8s:" not in project
    assert "docker:" not in project


def test_pr2_layer65_mac_sandbox_fires_at_edge(
    fake_psutil: type[_FakePsutil], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Layer 6.5 — mac sandbox — fires from the edge resolver and
    pre-empts the layer-7 ``Data`` collapse."""
    cwd = "/Users/stack/Library/Containers/ai.perplexity.mac/Data"
    fake_psutil._processes = [
        _make_proc(
            22000,
            conns=[_Conn(62000, 8081)],
            cwd=cwd,
        ),
    ]
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    monkeypatch.setattr(_layers, "resolve_via_container", lambda env, fs_probe=None: None)
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=62000, edge_port=8081
    )
    assert project == "mac:ai.perplexity.mac"
    assert project != "Data"  # the collapse Brief D identified


def test_pr2_layer65_uses_matched_process_cwd_not_edge(
    fake_psutil: type[_FakePsutil], monkeypatch: pytest.MonkeyPatch
) -> None:
    """The mac-sandbox path is read from the matched process's cwd.

    The edge process's own cwd (``~/.halton-meter`` under launchd) must
    NOT be confused with the originating process's cwd. We simulate
    that by giving the matched process a Mac sandbox cwd while the
    edge presumably has a different one.
    """
    sandboxed_cwd = "/Users/stack/Library/Containers/com.openai.chat/Data/Documents"
    fake_psutil._processes = [
        _make_proc(
            22001,
            conns=[_Conn(62001, 8081)],
            cwd=sandboxed_cwd,
        ),
    ]
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    monkeypatch.setattr(_layers, "resolve_via_container", lambda env, fs_probe=None: None)
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=62001, edge_port=8081
    )
    assert project == "mac:com.openai.chat"


# --- PR2 precedence pinning (edge resolver) -------------------------------- #


def test_pr2_precedence_env_beats_git(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """Layer 1 (env) beats Layer 4 (git) at the edge."""
    repo = tmp_path / "gitrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    fake_psutil._processes = [
        _make_proc(
            23000,
            conns=[_Conn(63000, 8081)],
            cwd=str(repo),
            environ={"HALTON_PROJECT": "from-env"},
        ),
    ]
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=63000, edge_port=8081
    )
    assert project == "from-env"


def test_pr2_precedence_rcfile_beats_git(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """Layer 2 (.haltonrc) beats Layer 4 (git) at the edge."""
    repo = tmp_path / "gitrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    (repo / ".haltonrc").write_text("project: from-rcfile\n")
    fake_psutil._processes = [
        _make_proc(
            23001,
            conns=[_Conn(63001, 8081)],
            cwd=str(repo),
        ),
    ]
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=63001, edge_port=8081
    )
    assert project == "from-rcfile"


def test_pr2_precedence_ide_sniff_beats_git(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """Layer 3 (IDE sniff) beats Layer 4 (git) at the edge.

    The IDE workspace path resolves to a project; even if the matched
    process's cwd is inside a git repo, the IDE sniff wins because it
    runs first in the precedence chain.
    """
    workspace = tmp_path / "haltonlabs-meter"
    workspace.mkdir()
    repo = tmp_path / "irrelevant-repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    fake_psutil._processes = [
        _make_proc(
            23002,
            conns=[_Conn(63002, 8081)],
            cwd=str(repo),
            cmdline=[
                "language_server_macos_arm",
                "--workspace_id",
                f"file_{encoded_root}_haltonlabs_meter",
            ],
        ),
    ]
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=63002, edge_port=8081
    )
    # IDE sniff beats git. Critically NOT ``irrelevant-repo``.
    assert project == "haltonlabs-meter"


def test_pr2_precedence_git_beats_container(
    fake_psutil: type[_FakePsutil], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Layer 4 (git) beats Layer 6 (container)."""
    repo = tmp_path / "gitrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    fake_psutil._processes = [
        _make_proc(
            23003,
            conns=[_Conn(63003, 8081)],
            cwd=str(repo),
            environ={
                "KUBERNETES_SERVICE_HOST": "10.0.0.1",
                "HOSTNAME": "would-be-pod",
            },
        ),
    ]
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=63003, edge_port=8081
    )
    assert project == "gitrepo"


def test_pr2_precedence_container_beats_basename(
    fake_psutil: type[_FakePsutil], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Layer 6 (container) beats Layer 7 (basename)."""
    leaf = tmp_path / "app"
    leaf.mkdir()
    fake_psutil._processes = [
        _make_proc(
            23004,
            conns=[_Conn(63004, 8081)],
            cwd=str(leaf),
            environ={
                "KUBERNETES_SERVICE_HOST": "10.0.0.1",
                "HOSTNAME": "pod-1",
            },
        ),
    ]
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=63004, edge_port=8081
    )
    assert project == "k8s:pod-1"


def test_pr2_precedence_mac_sandbox_beats_basename(
    fake_psutil: type[_FakePsutil], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Layer 6.5 (mac sandbox) beats Layer 7 (basename) — the whole
    point of the layer per Brief D."""
    cwd = "/Users/stack/Library/Containers/ai.perplexity.mac/Data"
    fake_psutil._processes = [
        _make_proc(
            23005,
            conns=[_Conn(63005, 8081)],
            cwd=cwd,
        ),
    ]
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    monkeypatch.setattr(_layers, "resolve_via_container", lambda env, fs_probe=None: None)
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=63005, edge_port=8081
    )
    assert project == "mac:ai.perplexity.mac"
    # NOT ``Data`` (the layer-7 collapse).
    assert project != "Data"


def test_pr2_container_uses_matched_process_environ_not_edge(
    fake_psutil: type[_FakePsutil], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The matched process's environ — not os.environ — drives layer 6.

    If the daemon/edge happens to have inherited KUBERNETES_SERVICE_HOST
    (test runner under k8s, CI image, dev mistake), the matched
    process's environ should still control the gate. Simulate by
    setting the value in os.environ and asserting the matched process's
    EMPTY environ does not produce a container tag.
    """
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "should-be-ignored")
    monkeypatch.setenv("HOSTNAME", "edge-host-should-be-ignored")
    leaf = tmp_path / "real-app"
    leaf.mkdir()
    fake_psutil._processes = [
        _make_proc(
            23006,
            conns=[_Conn(63006, 8081)],
            cwd=str(leaf),
            environ={},  # matched process has clean environ
        ),
    ]
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    # Disable real-fs container detection so the test is deterministic.
    monkeypatch.setattr(_layers, "_default_container_fs_probe", lambda p: False)
    project, _, _ = edge_attribution._resolve_via_psutil(
        client_port=63006, edge_port=8081
    )
    # Layer 6 must NOT fire — falls through to basename.
    assert project == "real-app"
    assert "k8s:" not in project


# --------------------------------------------------------------------------- #
# Brief D follow-up (2026-05-02) — Chromium helper parent-PID walk +          #
# RESOLVE_BUDGET_S 200 -> 500 ms                                              #
# --------------------------------------------------------------------------- #


def test_parent_walk_resolves_via_renderer_workspace(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """Helper PID (no workspace_id) -> parent renderer with workspace_id.

    Mirrors the production failure described in Brief D: Windsurf
    Helper running ``--utility-sub-type=network.mojom.NetworkService``
    has cwd ``/`` and no workspace flag. Its parent (Windsurf Helper
    (Renderer) or Windsurf main) carries ``--workspace_id``. The walk
    must recover the workspace and resolve the project.
    """
    project = tmp_path / "halton-meter-cloud"
    project.mkdir()
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    renderer = _make_proc(
        2000,
        conns=[],
        cwd="/",
        cmdline=[
            "Windsurf Helper (Renderer)",
            "--type=renderer",
            "--workspace_id",
            f"file_{encoded_root}_halton_meter_cloud",
        ],
        name="Windsurf Helper (Renderer)",
    )
    helper = _make_proc(
        2462,
        conns=[_Conn(54100, 8082)],
        cwd="/",
        cmdline=[
            "Windsurf Helper",
            "--type=utility",
            "--utility-sub-type=network.mojom.NetworkService",
        ],
        name="Windsurf Helper",
        parent=renderer,
    )
    fake_psutil._processes = [helper]
    project_name, body_capture, _source_workdir = edge_attribution._resolve_via_psutil(
        client_port=54100, edge_port=8082
    )
    assert project_name == "halton-meter-cloud"
    assert body_capture is True


def test_parent_walk_uses_haltonrc_inside_resolved_workspace(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """When the parent's workspace contains a .haltonrc, that wins
    (mirrors the existing IDE-args sniff behaviour for the matched proc)."""
    project = tmp_path / "haltonlabs-meter"
    project.mkdir()
    (project / ".haltonrc").write_text("project: halton-meter\n")
    encoded_root = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    renderer = _make_proc(
        2001,
        conns=[],
        cwd="/",
        cmdline=[
            "Windsurf",
            "--type=renderer",
            "--workspace_id",
            f"file_{encoded_root}_haltonlabs_meter",
        ],
        name="Windsurf",
    )
    helper = _make_proc(
        2463,
        conns=[_Conn(54101, 8082)],
        cwd="/",
        cmdline=["Windsurf Helper", "--type=utility"],
        name="Windsurf Helper",
        parent=renderer,
    )
    fake_psutil._processes = [helper]
    project_name, _, _ = edge_attribution._resolve_via_psutil(
        client_port=54101, edge_port=8082
    )
    assert project_name == "halton-meter"


def test_parent_walk_aborts_when_leaving_ide_family(
    fake_psutil: type[_FakePsutil],
) -> None:
    """Parent's name not in IDE allow-list -> abort + fall through.

    Conservative: better to attribute via cwd/git than to walk into
    an unrelated process tree. Helper's cwd is ``/`` so when the walk
    aborts the resolver falls all the way through to ``unattributed``.
    """
    unknown_parent = _make_proc(
        9999,
        conns=[],
        cwd="/",
        cmdline=[
            "some_random_app",
            "--workspace_id",
            "file_should_not_be_used",
        ],
        name="some_random_app",
    )
    helper = _make_proc(
        2464,
        conns=[_Conn(54102, 8082)],
        cwd="/",
        cmdline=["Helper", "--type=utility"],
        name="Windsurf Helper",
        parent=unknown_parent,
    )
    fake_psutil._processes = [helper]
    project_name, _, _ = edge_attribution._resolve_via_psutil(
        client_port=54102, edge_port=8082
    )
    assert project_name == "unattributed"


def test_parent_walk_aborts_at_pid_1(
    fake_psutil: type[_FakePsutil],
) -> None:
    """Walk reaches launchd (pid 1) -> abort + fall through."""
    launchd = _make_proc(
        1,
        conns=[],
        cwd="/",
        cmdline=["/sbin/launchd"],
        name="launchd",
    )
    helper = _make_proc(
        2465,
        conns=[_Conn(54103, 8082)],
        cwd="/",
        cmdline=["Code Helper", "--type=utility"],
        name="Code Helper",
        parent=launchd,
    )
    fake_psutil._processes = [helper]
    project_name, _, _ = edge_attribution._resolve_via_psutil(
        client_port=54103, edge_port=8082
    )
    assert project_name == "unattributed"


def test_parent_walk_aborts_at_hop_budget(
    fake_psutil: type[_FakePsutil],
) -> None:
    """Chain longer than 5 in-family hops with no workspace -> abort.

    Build a 7-deep chain of Windsurf Helper procs, none carrying a
    workspace flag. The walk must give up at hop 5 and fall through.
    """
    # Chain root -> ... -> direct parent. Each hop carries a Chromium
    # marker but no workspace flag, so the walk only stops via the
    # hop-budget guard.
    parent: Any | None = None
    for i in range(7):
        parent = _make_proc(
            3000 + i,
            conns=[],
            cwd="/",
            cmdline=["Windsurf Helper", "--type=utility"],
            name="Windsurf Helper",
            parent=parent,
        )
    helper = _make_proc(
        2466,
        conns=[_Conn(54104, 8082)],
        cwd="/",
        cmdline=["Windsurf Helper", "--type=utility"],
        name="Windsurf Helper",
        parent=parent,
    )
    fake_psutil._processes = [helper]
    project_name, _, _ = edge_attribution._resolve_via_psutil(
        client_port=54104, edge_port=8082
    )
    assert project_name == "unattributed"


def test_parent_walk_does_not_fire_when_target_lacks_chromium_marker(
    fake_psutil: type[_FakePsutil], tmp_path: Path
) -> None:
    """A target with a usable own cwd MUST win over its parent's workspace.

    v0.2.4 dropped the ``_is_chromium_helper`` gate and the IDE-family
    allow-list (memory/decisions.md 2026-05-18 "v0.2.4 unified
    attribution resolver"). The walk now bounds via uid / session
    boundary, not process-name allow-list. Structural ordering change:
    the parent walk runs ONLY when the target's own cwd is
    uninformative (basename empty / cwd is ``/``). When the target
    has a real cwd (this test), Layer 7 (workdir basename) returns
    the target's project before the walk is consulted.
    """
    workspace_root = tmp_path / "would-be-stolen"
    workspace_root.mkdir()
    encoded = str(tmp_path).strip("/").replace("/", "_").replace("-", "_")
    parent = _make_proc(
        4000,
        conns=[],
        cwd="/",
        cmdline=[
            "Windsurf",
            "--workspace_id",
            f"file_{encoded}_would_be_stolen",
        ],
        name="Windsurf",
    )
    real_cwd = tmp_path / "actual-project"
    real_cwd.mkdir()
    target = _make_proc(
        2467,
        conns=[_Conn(54105, 8082)],
        cwd=str(real_cwd),
        cmdline=["python", "-m", "thing"],  # no --type / --utility-sub-type
        name="python",
        parent=parent,
    )
    fake_psutil._processes = [target]
    project_name, _, _ = edge_attribution._resolve_via_psutil(
        client_port=54105, edge_port=8082
    )
    # Falls through to layer 7 (basename of cwd). NOT ``would-be-stolen``.
    assert project_name == "actual-project"


def test_parent_walk_swallows_psutil_access_denied(
    fake_psutil: type[_FakePsutil],
) -> None:
    """``parent()`` raising AccessDenied must not escape the resolver.

    The hot path is sacred: psutil error surface (NoSuchProcess,
    AccessDenied, ZombieProcess, OSError, ...) is wide and the resolver
    must fall through cleanly on any of them.
    """
    helper = _make_proc(
        2468,
        conns=[_Conn(54106, 8082)],
        cwd="/",
        cmdline=["Windsurf Helper", "--type=utility"],
        name="Windsurf Helper",
        parent_raises=fake_psutil.AccessDenied,
    )
    fake_psutil._processes = [helper]
    # Must not raise.
    project_name, _, _ = edge_attribution._resolve_via_psutil(
        client_port=54106, edge_port=8082
    )
    assert project_name == "unattributed"


def test_resolve_budget_pinned_at_500ms() -> None:
    """Regression pin for Brief D's RESOLVE_BUDGET_S bump.

    A future accidental revert to 200 ms (or any other value) should
    fail this test loudly. Brief D documented 130 timeouts/day at the
    200 ms ceiling; the bump is load-bearing for production.
    """
    assert edge_attribution.RESOLVE_BUDGET_S == 0.5


# ---------------------------------------------------------------------------
# v0.2.5 — edge resolver fallback (Item 2, edge_store leak fix)
# ---------------------------------------------------------------------------


def test_edge_falls_through_to_unified_resolver_for_env_label(
    fake_psutil: type[_FakePsutil],
    tmp_path: Path,
) -> None:
    """When the standalone chain returns unattributed, resolve_unified is called.

    The process carries CURSOR_WORKSPACE_LABEL and a matching directory
    exists on disk. The standalone chain misses (cwd is ``/``, no .haltonrc,
    no git, basename is empty). The unified resolver's lenient scan recovers
    the project via the label.
    """
    # Create a real project directory so the lenient scan can find it.
    project_dir = tmp_path / "myproject"
    project_dir.mkdir()

    # Target process: cwd=/, no rcfile, carries env label.
    target = _make_proc(
        9001,
        conns=[_Conn(55000, 8082)],
        cwd="/",
        environ={"CURSOR_WORKSPACE_LABEL": "myproject"},
        cmdline=["cursor", "helper"],
        name="cursor",
    )
    fake_psutil._processes = [target]

    # Patch find_project_root_by_slug so it scans tmp_path instead of home.
    import halton_meter.attribution.layers as _l
    from halton_meter.attribution.layers import find_project_root_by_slug as _orig_fn

    def _patched(slug: str, search_dirs: list | None = None) -> str | None:
        return _orig_fn(slug, search_dirs=[tmp_path])

    original = _l.find_project_root_by_slug
    _l.find_project_root_by_slug = _patched

    import halton_meter.attribution.resolver as _rv
    rv_original = _rv.find_project_root_by_slug
    _rv.find_project_root_by_slug = _patched

    # Also reset the edge registry singleton so cold-start state is simulated.
    from halton_meter.attribution.registry import _EDGE_REGISTRY
    _EDGE_REGISTRY.clear()

    try:
        project_name, _, _ = edge_attribution._resolve_via_psutil(
            client_port=55000, edge_port=8082
        )
        assert project_name == "myproject", (
            f"Expected 'myproject' from unified resolver fallback, got {project_name!r}"
        )
    finally:
        _l.find_project_root_by_slug = original
        _rv.find_project_root_by_slug = rv_original
        _EDGE_REGISTRY.clear()


def test_edge_resolver_fallback_does_not_raise_on_unified_error(
    fake_psutil: type[_FakePsutil],
) -> None:
    """If resolve_unified raises unexpectedly, _resolve_via_psutil still returns unattributed.

    Cardinal rule: the attribution path must NEVER raise, even when the
    fallback resolver crashes.
    """
    target = _make_proc(
        9002,
        conns=[_Conn(55001, 8082)],
        cwd="/",
        environ={},
        cmdline=[],
        name="some-process",
    )
    fake_psutil._processes = [target]

    # Patch the resolver import inside edge_attribution to raise.
    import halton_meter.attribution.resolver as _rv
    original_fn = _rv.resolve_unified

    def _raise(*args: object, **kwargs: object) -> None:
        raise RuntimeError("simulated crash")

    # Monkeypatch at the module level so the lazy import inside
    # _resolve_via_psutil picks up the patched version.
    _rv.resolve_unified = _raise  # type: ignore[assignment]

    # Also make the resolver importable from inside the function (lazy import path).
    import sys
    original_module = sys.modules.get("halton_meter.attribution.resolver")
    sys.modules["halton_meter.attribution.resolver"] = _rv  # type: ignore[assignment]

    try:
        project_name, _, _ = edge_attribution._resolve_via_psutil(
            client_port=55001, edge_port=8082
        )
        # Must fall through to unattributed, not raise.
        assert project_name == "unattributed"
    finally:
        _rv.resolve_unified = original_fn
        if original_module is not None:
            sys.modules["halton_meter.attribution.resolver"] = original_module
