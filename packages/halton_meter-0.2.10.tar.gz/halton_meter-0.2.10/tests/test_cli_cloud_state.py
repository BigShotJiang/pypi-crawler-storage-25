"""Tests for the wired-up Wave 1A.i CLI ↔ storage helpers.

Covers the six functions that this PR converted from stubs into real
``cloud_state`` / ``cloud_sync_state`` writers + the status reader:

  * ``_write_cloud_state_token`` — encrypts the token, writes 0600 file,
    writes the encrypted ciphertext to ``cloud_state``, sets
    ``enabled=True``.
  * ``_clear_cloud_state_token`` — wipes both stores; fail-open.
  * ``_set_cloud_enabled`` — pause/resume drive ``enabled`` +
    ``paused_reason`` on ``cloud_state``.
  * ``_make_cursor_advancer`` — success path advances the cursor,
    resets ``consecutive_failures``, stamps ``last_batch_succeeded_at``.
  * ``_record_sync_failure`` — bumps ``consecutive_failures``, writes
    ``last_error``; with ``paused_reason`` set also mirrors onto
    ``cloud_state``.
  * ``_load_status_payload`` — reads both tables + counts unsynced.

Storage round-trip is exercised against a real tmp_path SQLite file per
``memory/patterns.md`` (no SQLite mocks).
"""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from halton_meter import cli_cloud
from halton_meter.cloud.worker import Cursor
from halton_meter.models import LogRecord
from halton_meter.storage import StorageManager
from halton_meter.storage.cloud_crypto import (
    decrypt_api_key,
    fingerprint_api_key,
)

ENDPOINT = "https://meter.example.test"


# --------------------------------------------------------------------------- #
# Fixtures                                                                    #
# --------------------------------------------------------------------------- #


@pytest.fixture
def tmp_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect every filesystem-touching path to tmp_path.

    Returns the db file. The Fernet key file, the 0600 credentials file,
    and the config-resolved db path all land under tmp_path so tests
    don't touch the developer's real ``~/.halton-meter``.
    """
    db_path = tmp_path / "db.sqlite"
    cred_path = tmp_path / "cloud-credentials.json"
    key_path = tmp_path / "cloud.key"

    monkeypatch.setattr(cli_cloud, "CLOUD_CREDENTIALS_PATH", cred_path)
    monkeypatch.setattr(
        "halton_meter.storage.cloud_crypto.DEFAULT_KEY_PATH", key_path
    )
    monkeypatch.setattr(cli_cloud, "_resolved_db_path", lambda: str(db_path))
    monkeypatch.setattr(cli_cloud, "_resolved_endpoint", lambda: ENDPOINT)
    # Wave 2 moved the storage-backed factories into cloud._supervisor_glue
    # and duplicated `_resolved_db_path` there. The cli_cloud module re-imports
    # the factories under legacy underscore names, but they still resolve the
    # DB path via the supervisor-glue module's own helper — so patching only
    # cli_cloud lets the factories leak onto the developer's real
    # ~/.halton-meter/db.sqlite. Patch both copies.
    from halton_meter.cloud import _supervisor_glue

    monkeypatch.setattr(
        _supervisor_glue, "_resolved_db_path", lambda: str(db_path)
    )
    return db_path


def _make_record(
    *,
    id: str | None = None,
    recorded_at: str = "2026-05-11T10:00:00Z",
) -> LogRecord:
    return LogRecord(
        id=id or str(uuid.uuid4()),
        project="cli-test",
        provider="anthropic",
        model="claude-sonnet-4-6",
        input_tokens=10,
        output_tokens=5,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
        cost_millicents=100,
        tokens_complete=True,
        latency_ms=12.3,
        requested_at=recorded_at,
        recorded_at=recorded_at,
        status="success",
    )


# --------------------------------------------------------------------------- #
# _write_cloud_state_token + _clear_cloud_state_token                         #
# --------------------------------------------------------------------------- #


def test_write_cloud_state_token_persists_both_stores(tmp_env: Path) -> None:
    token = "hm_sync_" + ("a" * 40)
    payload = {
        "api_key": token,
        "workspace_id": "ws-001",
        "workspace_name": "Halton Labs",
        "machine_id": "mach-001",
        "base_url": ENDPOINT,
    }

    cli_cloud._write_cloud_state_token(token, payload)

    # 0600 credentials file.
    cred_path = cli_cloud.CLOUD_CREDENTIALS_PATH
    assert cred_path.exists()
    assert cred_path.stat().st_mode & 0o777 == 0o600
    data = json.loads(cred_path.read_text())
    assert data["api_key"] == token
    assert data["endpoint"] == ENDPOINT
    assert data["workspace_id"] == "ws-001"

    # DB row — token encrypted, fingerprint matches, enabled flipped.
    import asyncio

    async def _read() -> tuple[str | None, str | None, bool, str | None]:
        async with StorageManager(str(tmp_env)) as storage:
            row = await storage.cloud_get_state(ENDPOINT)
            assert row is not None
            decrypted = (
                decrypt_api_key(row.api_key_ciphertext)
                if row.api_key_ciphertext
                else None
            )
            return decrypted, row.api_key_fingerprint, row.enabled, row.paused_reason

    decrypted, fp, enabled, paused = asyncio.run(_read())
    assert decrypted == token
    assert fp == fingerprint_api_key(token)
    assert enabled is True
    assert paused is None  # clean pair, no leftover pause


def test_clear_cloud_state_token_wipes_both_stores(tmp_env: Path) -> None:
    token = "hm_sync_" + ("b" * 40)
    cli_cloud._write_cloud_state_token(
        token, {"api_key": token, "workspace_id": "ws-001", "base_url": ENDPOINT}
    )
    assert cli_cloud.CLOUD_CREDENTIALS_PATH.exists()

    cli_cloud._clear_cloud_state_token()

    assert not cli_cloud.CLOUD_CREDENTIALS_PATH.exists()

    import asyncio

    async def _read():
        async with StorageManager(str(tmp_env)) as storage:
            return await storage.cloud_get_state(ENDPOINT)

    row = asyncio.run(_read())
    assert row is not None
    assert row.api_key_ciphertext is None
    assert row.api_key_fingerprint is None
    assert row.enabled is False
    assert row.paused_reason == "disconnected"
    # Audit fields survive the wipe.
    assert row.workspace_id == "ws-001"


def test_clear_cloud_state_token_is_fail_open(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """No DB and no creds file → still exits cleanly."""
    monkeypatch.setattr(
        cli_cloud, "CLOUD_CREDENTIALS_PATH", tmp_path / "missing.json"
    )
    monkeypatch.setattr(cli_cloud, "_resolved_endpoint", lambda: "")
    # No db path needed — endpoint is empty so we never open one.
    cli_cloud._clear_cloud_state_token()  # must not raise


# --------------------------------------------------------------------------- #
# _set_cloud_enabled (pause / resume)                                         #
# --------------------------------------------------------------------------- #


def test_set_cloud_enabled_pause_then_resume(tmp_env: Path) -> None:
    token = "hm_sync_" + ("c" * 40)
    cli_cloud._write_cloud_state_token(
        token, {"api_key": token, "workspace_id": "ws", "base_url": ENDPOINT}
    )

    cli_cloud._set_cloud_enabled(False, paused_reason="paused_manual")
    import asyncio

    async def _read():
        async with StorageManager(str(tmp_env)) as storage:
            return await storage.cloud_get_state(ENDPOINT)

    paused = asyncio.run(_read())
    assert paused is not None
    assert paused.enabled is False
    assert paused.paused_reason == "paused_manual"

    cli_cloud._set_cloud_enabled(True, paused_reason=None)
    resumed = asyncio.run(_read())
    assert resumed is not None
    assert resumed.enabled is True
    assert resumed.paused_reason is None


# --------------------------------------------------------------------------- #
# Cursor advancer + sync failure recorder                                     #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_cursor_advancer_success_advances_and_resets_failures(
    tmp_env: Path,
) -> None:
    # Seed a failure so we can assert it resets on success.
    await cli_cloud._record_sync_failure("first try failed")
    async with StorageManager(str(tmp_env)) as storage:
        sync = await storage.cloud_get_sync_state(ENDPOINT)
        assert sync is not None
        assert sync.consecutive_failures == 1
        assert sync.last_error == "first try failed"

    advancer = cli_cloud._make_cursor_advancer(ENDPOINT)
    cursor = Cursor(recorded_at="2026-05-11T10:00:01Z", record_id="rec-001")
    await advancer(cursor)

    async with StorageManager(str(tmp_env)) as storage:
        sync = await storage.cloud_get_sync_state(ENDPOINT)
        assert sync is not None
        assert sync.last_synced_request_id == "rec-001"
        assert sync.last_batch_succeeded_at is not None
        # Reset to zero on the successful advance — cardinal contract.
        assert sync.consecutive_failures == 0
        assert sync.last_error is None


@pytest.mark.asyncio
async def test_record_sync_failure_bumps_counter(tmp_env: Path) -> None:
    await cli_cloud._record_sync_failure("transport timeout")
    await cli_cloud._record_sync_failure("transport timeout again")
    async with StorageManager(str(tmp_env)) as storage:
        sync = await storage.cloud_get_sync_state(ENDPOINT)
        assert sync is not None
        assert sync.consecutive_failures == 2
        assert sync.last_error is not None


@pytest.mark.asyncio
async def test_record_sync_failure_401_sets_paused_reason(tmp_env: Path) -> None:
    # Pre-seed cloud_state so we can confirm the paused_reason mirror.
    async with StorageManager(str(tmp_env)) as storage:
        await storage.cloud_set_state(
            endpoint=ENDPOINT, base_url=ENDPOINT, enabled=True
        )

    await cli_cloud._record_sync_failure(
        "bad token", paused_reason="paused_unauthorised"
    )

    async with StorageManager(str(tmp_env)) as storage:
        sync = await storage.cloud_get_sync_state(ENDPOINT)
        state = await storage.cloud_get_state(ENDPOINT)
        assert sync is not None
        assert sync.paused_reason == "paused_unauthorised"
        assert state is not None
        assert state.paused_reason == "paused_unauthorised"


# --------------------------------------------------------------------------- #
# Status payload                                                              #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_load_status_payload_reports_unsynced_count(tmp_env: Path) -> None:
    # Five records, advance the cursor past the first two.
    base = datetime(2026, 5, 11, 10, 0, 0, tzinfo=UTC)
    async with StorageManager(str(tmp_env)) as storage:
        rec_ids = []
        for i in range(5):
            rid = str(uuid.uuid4())
            rec_ids.append(rid)
            ts = (base + timedelta(seconds=i)).isoformat().replace("+00:00", "Z")
            await storage.write_record(_make_record(id=rid, recorded_at=ts))

        # Set cursor to row #1 (so rows #2-#4 are unsynced).
        all_rows = await storage.cloud_unsynced_batch(limit=100)
        cursor_row = all_rows[1]
        cursor_at = datetime.fromisoformat(
            cursor_row.recorded_at.replace("Z", "+00:00")
        )
        await storage.cloud_advance_cursor(
            endpoint=ENDPOINT,
            record_id=cursor_row.id,
            recorded_at=cursor_at,
            batch_id="batch-status",
        )
        # And register a workspace so the status reader has audit data.
        await storage.cloud_set_state(
            endpoint=ENDPOINT,
            workspace_id="ws-status",
            workspace_name="Status Test",
            machine_id="m-status",
            base_url=ENDPOINT,
            enabled=True,
        )

    payload = await cli_cloud._load_status_payload(ENDPOINT)
    assert payload["unsynced_record_count"] == 3
    assert payload["workspace_id"] == "ws-status"
    assert payload["workspace_name"] == "Status Test"
    assert payload["machine_id"] == "m-status"
    assert payload["last_batch_succeeded_at"] is not None
    assert payload["consecutive_failures"] == 0
