"""Shape tests for the four macOS plist builders + atomic-write crash safety.

v0.2.3 (2026-05-18): added after the on-disk edge plist was found truncated
to the 8-byte stub ``<plist/>`` on the operator's daily-driver mid-day. The
shape tests are the CHANGELOG-vs-code drift tripwire: any future
``RunAtLoad`` / ``KeepAlive`` / ``ThrottleInterval`` / ``ProgramArguments``
change has to update these assertions, which means the CHANGELOG entry
documenting that change has to exist too. The atomic-write crash test
asserts that an interrupted write leaves the target file unchanged rather
than truncated to a partial-write stub.

Decision: ``decisions.md`` 2026-05-18 — "v0.2.3 — keep manual-start; add
plist atomic-write hardening".
"""

from __future__ import annotations

import os
import plistlib
from pathlib import Path
from unittest.mock import patch

import pytest

from halton_meter.install import _macos

# --------------------------------------------------------------------------- #
# Builder shape tests                                                          #
# --------------------------------------------------------------------------- #


@pytest.fixture
def builder_args(tmp_path: Path) -> tuple[Path, Path, Path]:
    """``(halton_path, log_dir, working_dir)`` for the builder signatures."""
    halton = tmp_path / "bin" / "halton-meter"
    halton.parent.mkdir(parents=True)
    halton.write_text("#!/usr/bin/env python3\n")
    log_dir = tmp_path / "logs"
    log_dir.mkdir()
    return halton, log_dir, log_dir


def _load(payload: bytes) -> dict:
    return plistlib.loads(payload)


def test_build_macos_plist_daemon_shape(builder_args: tuple[Path, Path, Path]) -> None:
    """Daemon plist: v0.1.21.1 manual-start — no KeepAlive, RunAtLoad=False."""
    halton, log_dir, working_dir = builder_args
    payload = _load(_macos.build_macos_plist(halton, log_dir, working_dir))

    assert payload["Label"] == "com.haltonlabs.meter"
    assert payload["ProgramArguments"] == [str(halton), "daemon"]
    # v0.1.21.1 manual-start: NO KeepAlive (the key must be absent — see
    # docstring on build_macos_plist). RunAtLoad False so reboot does not
    # auto-load the daemon.
    assert "KeepAlive" not in payload
    assert payload["RunAtLoad"] is False
    assert payload["ThrottleInterval"] == 1
    assert payload["ExitTimeOut"] == 30
    assert payload["ProcessType"] == "Background"
    assert payload["SoftResourceLimits"] == {"NumberOfFiles": 10240}


def test_build_watchdog_plist_shape(builder_args: tuple[Path, Path, Path]) -> None:
    """Watchdog plist: same shape as daemon — manual-start, no KeepAlive."""
    halton, log_dir, working_dir = builder_args
    payload = _load(_macos.build_watchdog_plist(halton, log_dir, working_dir))

    assert payload["Label"] == "com.haltonlabs.meter.watchdog"
    assert payload["ProgramArguments"] == [str(halton), "watchdog"]
    assert "KeepAlive" not in payload
    assert payload["RunAtLoad"] is False
    assert payload["ThrottleInterval"] == 1
    assert payload["ExitTimeOut"] == 30


def test_build_macos_plist_edge_shape(builder_args: tuple[Path, Path, Path]) -> None:
    """Edge plist: 2C.2 port-keeper — RunAtLoad=True, KeepAlive=True."""
    halton, log_dir, working_dir = builder_args
    payload = _load(_macos.build_macos_plist_edge(halton, log_dir, working_dir))

    assert payload["Label"] == "com.haltonlabs.meter.edge"
    assert payload["ProgramArguments"] == [str(halton), "edge"]
    # Edge MUST stay up across every daemon transition — that is the
    # entire reason 2C.2 split it off the daemon process.
    assert payload["RunAtLoad"] is True
    assert payload["KeepAlive"] is True
    assert payload["ThrottleInterval"] == 1
    assert payload["ExitTimeOut"] == 5


def test_build_macos_plist_userenv_shape(
    builder_args: tuple[Path, Path, Path],
) -> None:
    """Userenv plist: v0.1.19 login one-shot — RunAtLoad=True, KeepAlive=False."""
    halton, log_dir, working_dir = builder_args
    payload = _load(_macos.build_macos_plist_userenv(halton, log_dir, working_dir))

    assert payload["Label"] == "com.haltonlabs.meter.userenv"
    assert payload["ProgramArguments"] == [str(halton), "_apply-user-env"]
    assert payload["RunAtLoad"] is True
    # Literal one-shot: NOT {SuccessfulExit: False} — see docstring.
    assert payload["KeepAlive"] is False
    assert payload["ThrottleInterval"] == 1
    assert payload["ExitTimeOut"] == 5


# --------------------------------------------------------------------------- #
# Atomic-write crash safety                                                    #
# --------------------------------------------------------------------------- #


def test_atomic_write_replaces_existing_file(tmp_path: Path) -> None:
    """Happy path: existing file is replaced by the new content."""
    target = tmp_path / "agent.plist"
    target.write_bytes(b"OLD CONTENT")

    _macos._atomic_write_bytes(target, b"NEW CONTENT")

    assert target.read_bytes() == b"NEW CONTENT"


def test_atomic_write_creates_new_file(tmp_path: Path) -> None:
    """Happy path: target may not exist; the write creates it."""
    target = tmp_path / "subdir" / "agent.plist"

    _macos._atomic_write_bytes(target, b"fresh")

    assert target.read_bytes() == b"fresh"


def test_atomic_write_interrupted_leaves_target_unchanged(tmp_path: Path) -> None:
    """Crash mid-write: target keeps its old content; no truncated stub.

    This is the load-bearing assertion. Pre-v0.2.3 the install path called
    ``Path.write_bytes`` which opens with ``O_TRUNC``; a process death
    between truncate and final flush left the target at zero bytes or a
    valid-prefix corruption. Atomic write via tmp + ``os.replace`` is
    immune: the canonical path is never opened for writing.
    """
    target = tmp_path / "edge.plist"
    target.write_bytes(b"PRE-EXISTING-VALID-PLIST-BYTES")

    real_write = os.write

    def boom_after_first(fd: int, data: bytes) -> int:  # type: ignore[no-redef]
        # Raise BEFORE writing — simulates a crash inside the tmp file
        # write phase. The canonical target must remain untouched.
        raise OSError("simulated mid-write failure")

    with patch.object(_macos.os, "write", side_effect=boom_after_first):
        with pytest.raises(OSError, match="simulated mid-write failure"):
            _macos._atomic_write_bytes(target, b"NEW CONTENT THAT NEVER LANDS")

    # The original bytes are still on disk — atomicity preserved.
    assert target.read_bytes() == b"PRE-EXISTING-VALID-PLIST-BYTES"
    # Sanity: no stray .tmp files in the directory.
    assert real_write is os.write  # patch unwound
    leftover = [p for p in target.parent.iterdir() if p.suffix == ".tmp"]
    assert leftover == [], f"atomic write leaked tmp files: {leftover}"


def test_atomic_write_replace_failure_cleans_tmp(tmp_path: Path) -> None:
    """If ``os.replace`` fails the tmp file is unlinked and the error propagates."""
    target = tmp_path / "edge.plist"
    target.write_bytes(b"OLD")

    with patch.object(
        _macos.os, "replace", side_effect=OSError("simulated replace failure")
    ):
        with pytest.raises(OSError, match="simulated replace failure"):
            _macos._atomic_write_bytes(target, b"NEW")

    assert target.read_bytes() == b"OLD"
    leftover = [p for p in target.parent.iterdir() if p.suffix == ".tmp"]
    assert leftover == [], f"atomic write leaked tmp files: {leftover}"


def test_atomic_write_produces_valid_plist_for_edge_builder(
    tmp_path: Path, builder_args: tuple[Path, Path, Path]
) -> None:
    """End-to-end: edge builder output round-trips through the atomic writer.

    Regression for the 2026-05-18 ``<plist/>`` stub: the on-disk file after
    an atomic write must be parseable by ``plistlib.load``, not the 8-byte
    truncation.
    """
    halton, log_dir, working_dir = builder_args
    payload = _macos.build_macos_plist_edge(halton, log_dir, working_dir)
    target = tmp_path / "com.haltonlabs.meter.edge.plist"

    _macos._atomic_write_bytes(target, payload)

    assert target.stat().st_size > 200, "edge plist is suspiciously small"
    with target.open("rb") as fh:
        parsed = plistlib.load(fh)
    assert parsed["Label"] == "com.haltonlabs.meter.edge"
    assert parsed["KeepAlive"] is True
