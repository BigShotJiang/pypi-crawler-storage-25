"""Shared pytest fixtures for the daemon test suite.

The single autouse fixture here exists to keep ``structlog`` global
state from bleeding between test files. v0.1.22.1's
:func:`halton_meter.cli_runtime.configure_for_user_cli` reconfigures
structlog process-wide (filtering bound logger at WARNING) and is now
called from inside several user-facing CLI command callbacks. Tests
that exercise those callbacks (``test_cli``, ``test_doctor``,
``test_lifecycle``, ``test_init``, …) leave the silencer in place;
later tests that rely on ``structlog.testing.capture_logs`` capturing
INFO events (``test_observability``) then see no events because the
filter drops them before the captor's processor can run.

Resetting structlog to its library default (``BoundLoggerFilteringAtNotset``)
between tests is cheap and matches the silencer's idempotency
contract — any test that needs the silencer (re-)installs it during
its own setup.
"""

from __future__ import annotations

import sys

import pytest

# macOS-only test files. These tests exercise launchctl / keychain / lsof /
# networksetup paths and import macOS-specific helpers at module load.
# Until the Linux-side per-OS shims land (planned post-v0.1.22 soak), they
# fail to collect on Linux. CI runs on ubuntu-latest, so we ignore them
# there. Local macOS pytest still collects + runs all of them.
if sys.platform != "darwin":
    collect_ignore = [
        "test_attribution_e2e.py",
        "test_branded_surfaces.py",
        "test_cert_permissions.py",
        "test_certifi_parity.py",
        "test_cli.py",
        "test_cli_apply_user_env.py",
        "test_doctor.py",
        "test_doctor_apply.py",
        "test_edge_chain_resolve.py",
        "test_edge_e2e.py",
        "test_edge_graceful_shutdown.py",
        "test_health.py",
        "test_init.py",
        "test_install.py",
        "test_install_branded.py",
        "test_lifecycle.py",
        "test_module_layout.py",
        "test_port_alloc.py",
        "test_retag.py",
        "test_run.py",
        "test_setup.py",
        "test_system_proxy.py",
        "test_watchdog.py",
        "test_v0_1_22_9_sentinel_state_and_ports.py",
        "test_v0_1_22_10_sidecar_regen_signal.py",
        "test_v0_1_22_12_sentinel_writers_heartbeat_verdict.py",
        "test_v0_1_22_14_h_mark_and_columns.py",
        "test_v0_1_22_15_ground_truth_port_resolution.py",
        "test_v0_1_22_17_install_cosmetic.py",
    ]


@pytest.fixture(autouse=True)
def _reset_structlog_between_tests() -> None:
    """Reset structlog config + the cli_runtime silencer flag before
    every test so global state from a previous test cannot mask events
    in this one."""
    import structlog

    from halton_meter import cli_runtime

    structlog.reset_defaults()
    cli_runtime._CONFIGURED = False
    yield
    structlog.reset_defaults()
    cli_runtime._CONFIGURED = False
