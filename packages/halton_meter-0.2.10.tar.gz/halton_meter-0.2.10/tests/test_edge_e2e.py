"""End-to-end edge-proxy lifecycle test (2C.2 W6, v0.1.6).

Drives the full edge-proxy lifecycle without spawning the real
``halton-meter daemon`` (the constraint about not starting the daemon
applies to this test suite). Three synthetic peers stand in:

* **upstream**: a TCP listener that accepts the byte stream a CONNECT
  client forwards, and echoes a marker so the test can confirm the
  bytes reached this peer (passthrough mode).
* **daemon-target**: a TCP listener that accepts a CONNECT request line
  + headers from the edge (chain mode), then echoes a different marker
  so the test can distinguish "we hit the chain" from "we hit
  passthrough".
* **edge**: the real :class:`halton_meter.edge.EdgeProxy`. Talks to the
  daemon-target on a probe port and falls back to direct passthrough
  whenever that probe says down or the chain TCP connect raises
  ConnectionRefusedError.

The test exercises §10 acceptance criteria #2, #4, #5: stop daemon →
passthrough; restart → chain resumes; mid-stream daemon kill → instant
fall-through to passthrough on the very next request (cache-invalidate
path).
"""

from __future__ import annotations

import asyncio
import socket
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import pytest

from halton_meter.edge import (
    DaemonHealthCache,
    EdgeConfig,
    EdgeProxy,
)

# --------------------------------------------------------------------------- #
# Synthetic peers                                                             #
# --------------------------------------------------------------------------- #


class _SyntheticServer:
    """Wraps an asyncio TCP server with a stop button.

    Subclasses define ``handle()``. ``start()`` binds 127.0.0.1:0 (kernel-
    assigned), ``stop()`` closes the listener cleanly. Tracks the count
    of connections accepted so tests can assert "the chain target was
    actually hit" vs "the upstream was hit directly".
    """

    def __init__(self) -> None:
        self.server: asyncio.base_events.Server | None = None
        self.port: int = 0
        self.connections: int = 0

    async def start(self) -> int:
        self.server = await asyncio.start_server(
            self._wrap_handle, host="127.0.0.1", port=0
        )
        sock = self.server.sockets[0]
        self.port = sock.getsockname()[1]
        return self.port

    async def stop(self) -> None:
        if self.server is None:
            return
        self.server.close()
        await self.server.wait_closed()
        self.server = None

    async def _wrap_handle(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        self.connections += 1
        try:
            await self.handle(reader, writer)
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass

    async def handle(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


class _UpstreamServer(_SyntheticServer):
    """Stand-in for the real upstream (e.g. api.anthropic.com:443).

    After accepting the connection it echoes a marker so the test can
    confirm "passthrough did reach upstream directly". The edge in
    passthrough mode opens a TCP tunnel to ``host:port`` and writes
    ``200 Connection Established`` to the client; the bytes the test
    sends after that arrive here verbatim.
    """

    MARKER = b"HELLO-FROM-UPSTREAM\n"

    async def handle(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        writer.write(self.MARKER)
        await writer.drain()
        # Drain whatever the client sends so the close is clean.
        try:
            await asyncio.wait_for(reader.read(1024), timeout=0.5)
        except TimeoutError:
            pass


class _DaemonTargetServer(_SyntheticServer):
    """Stand-in for the daemon's mitmproxy listener on internal_port.

    Speaks just enough to look like an HTTP-proxy: reads the CONNECT
    request line + headers (which the edge replays verbatim when
    chaining), then writes a distinctive marker so the test can confirm
    "the chain reached the daemon".
    """

    MARKER = b"HELLO-FROM-DAEMON-CHAIN\n"
    HEALTH_RESPONSE = (
        b"HTTP/1.0 200 OK\r\n"
        b"Content-Type: application/json\r\n"
        b"Content-Length: 15\r\n"
        b"Connection: close\r\n"
        b"\r\n"
        b'{"ok": true}\r\n'
    )

    async def handle(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        # Peek the first request line to decide between health probe and
        # chain replay.
        first = await reader.readline()
        if first.startswith(b"GET /health"):
            # Drain remaining headers.
            while True:
                line = await reader.readline()
                if line in (b"\r\n", b"\n", b""):
                    break
            writer.write(self.HEALTH_RESPONSE)
            await writer.drain()
            return
        # CONNECT (or other) — drain headers, then echo the chain marker.
        while True:
            line = await reader.readline()
            if line in (b"\r\n", b"\n", b""):
                break
        writer.write(self.MARKER)
        await writer.drain()
        try:
            await asyncio.wait_for(reader.read(1024), timeout=0.5)
        except TimeoutError:
            pass


# --------------------------------------------------------------------------- #
# Edge harness                                                                #
# --------------------------------------------------------------------------- #


@asynccontextmanager
async def _spawn_edge(
    daemon_host: str, daemon_port: int, *, healthy_ttl: float = 0.05
) -> AsyncIterator[tuple[EdgeProxy, int]]:
    """Start an EdgeProxy bound to a kernel-assigned port. Yields
    ``(proxy, port)``.

    The healthy TTL is set to 50ms so the test can observe cache
    refresh quickly without hand-rolled time mocking.
    """
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host=daemon_host,
        internal_port=daemon_port,
        healthy_ttl_s=healthy_ttl,
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.5,
    )
    proxy = EdgeProxy(config)
    bound = await proxy.start()
    serve_task = asyncio.create_task(proxy.serve_forever())
    try:
        yield proxy, bound
    finally:
        await proxy.stop()
        serve_task.cancel()
        try:
            await serve_task
        except (asyncio.CancelledError, Exception):
            pass


def _next_free_port() -> int:
    """Return a TCP port that was free on bind. Used as the
    daemon-target port so we can stop and restart it on the same port —
    EdgeConfig.internal_port is fixed at construction time."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()


async def _send_connect_via_edge(
    edge_port: int,
    upstream_host: str,
    upstream_port: int,
) -> bytes:
    """Open a TCP connection to the edge, send a CONNECT request, drain
    the socket until EOF (or 1.5s timeout).

    Returns all bytes received after the request — this is the union of
    any proxy-issued response (e.g. ``200 Connection Established`` for
    passthrough) AND the bytes the eventual peer (upstream or
    daemon-target) sends after the tunnel is established.
    """
    reader, writer = await asyncio.open_connection("127.0.0.1", edge_port)
    try:
        request = (
            f"CONNECT {upstream_host}:{upstream_port} HTTP/1.1\r\n"
            f"Host: {upstream_host}:{upstream_port}\r\n"
            f"\r\n"
        ).encode("ascii")
        writer.write(request)
        await writer.drain()
        # Read until EOF or timeout. Both peers close their side after
        # writing the marker; the edge propagates EOF.
        chunks: list[bytes] = []
        deadline = asyncio.get_event_loop().time() + 2.5
        while True:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                break
            try:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=remaining)
            except TimeoutError:
                break
            if not chunk:
                break
            chunks.append(chunk)
        return b"".join(chunks)
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass


# --------------------------------------------------------------------------- #
# The lifecycle test                                                          #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_edge_lifecycle_chain_then_passthrough_then_chain_then_invalidate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # v0.1.22.24: chaining is gated on an LLM host allowlist; loopback
    # CONNECT in this lifecycle test would otherwise skip chaining.
    # Allowlist semantics tested elsewhere; here the gate is patched
    # open to keep the chain/passthrough/cache-invalidate behaviour in
    # focus.
    monkeypatch.setattr(
        "halton_meter.edge.host_should_intercept", lambda _h: True
    )
    """End-to-end §10 acceptance: chain mode -> passthrough on daemon
    stop -> chain resumes on daemon restart -> instant fall-through to
    passthrough when the chain connect raises ConnectionRefused.
    """
    upstream = _UpstreamServer()
    upstream_port = await upstream.start()

    # Reserve a stable port for the daemon-target so we can restart it
    # there. EdgeConfig is constructed with a fixed internal_port; the
    # daemon-target stops and re-binds on the same port across the test.
    daemon_port = _next_free_port()

    daemon = _DaemonTargetServer()
    daemon_actual = await asyncio.start_server(
        daemon._wrap_handle, host="127.0.0.1", port=daemon_port
    )
    daemon.server = daemon_actual

    try:
        async with _spawn_edge(
            "127.0.0.1", daemon_port, healthy_ttl=0.05
        ) as (_proxy, edge_port):
            # ---------- Step 1: chain mode reaches the daemon-target.
            data = await _send_connect_via_edge(
                edge_port, "127.0.0.1", upstream_port
            )
            # Cache might be cold on first call; if so, give it a small
            # window to converge and retry.
            if _DaemonTargetServer.MARKER not in data:
                await asyncio.sleep(0.1)
                data = await _send_connect_via_edge(
                    edge_port, "127.0.0.1", upstream_port
                )
            assert _DaemonTargetServer.MARKER in data, (
                "Step 1: chain mode should have reached the daemon-target. "
                f"Got: {data!r}"
            )
            # The daemon-target was hit at least once for the CONNECT
            # plus probably once for the /health probe. Upstream should
            # not have been touched.
            assert daemon.connections >= 1
            assert upstream.connections == 0

            # ---------- Step 2: stop the daemon-target.
            daemon.server.close()
            await daemon.server.wait_closed()
            daemon.server = None
            # Invalidate the cache so the next request re-probes
            # immediately rather than waiting for the 50ms TTL.
            _proxy.health_cache.invalidate()

            # Next CONNECT should succeed via passthrough — the upstream
            # writes its marker, that flows back through the edge.
            data = await _send_connect_via_edge(
                edge_port, "127.0.0.1", upstream_port
            )
            assert _UpstreamServer.MARKER in data, (
                "Step 2: passthrough should have reached upstream "
                f"directly. Got: {data!r}"
            )
            assert upstream.connections >= 1

            # ---------- Step 3: restart the daemon-target on the same port.
            daemon_again = _DaemonTargetServer()
            daemon_again.server = await asyncio.start_server(
                daemon_again._wrap_handle, host="127.0.0.1", port=daemon_port
            )
            # Wait for the unhealthy TTL to expire so the next probe
            # actually re-runs.
            await asyncio.sleep(0.2)

            # Next CONNECT should chain through the (revived) daemon.
            data = await _send_connect_via_edge(
                edge_port, "127.0.0.1", upstream_port
            )
            if _DaemonTargetServer.MARKER not in data:
                # Probe TTL window — give one more attempt.
                await asyncio.sleep(0.1)
                data = await _send_connect_via_edge(
                    edge_port, "127.0.0.1", upstream_port
                )
            assert _DaemonTargetServer.MARKER in data, (
                "Step 3: chain mode should have resumed via the "
                f"restarted daemon-target. Got: {data!r}"
            )
            assert daemon_again.connections >= 1

            # ---------- Step 4: stop daemon mid-stream WITHOUT
            # invalidating the cache, then send a CONNECT within the
            # cache TTL. The cached "healthy" answer is stale; the
            # chain TCP connect should raise ConnectionRefusedError;
            # the edge should invalidate the cache and fall through to
            # passthrough on this very request.
            daemon_again.server.close()
            await daemon_again.server.wait_closed()
            daemon_again.server = None
            # Cache is still "healthy" because the probe only ran a
            # moment ago. The next request triggers the invalidate-on-
            # ECONNREFUSED branch in EdgeProxy._try_chain.

            data = await _send_connect_via_edge(
                edge_port, "127.0.0.1", upstream_port
            )
            assert _UpstreamServer.MARKER in data, (
                "Step 4: cache-invalidate-on-refused branch should have "
                "fallen through to passthrough on the very same request. "
                f"Got: {data!r}"
            )
            # And the cache should now report unhealthy (no longer
            # the stale "True").
            assert _proxy.health_cache._has_result is False or (
                _proxy.health_cache._last_result is False
            )
    finally:
        if daemon.server is not None:
            daemon.server.close()
            await daemon.server.wait_closed()
        await upstream.stop()


@pytest.mark.asyncio
async def test_health_cache_invalidates_immediately_on_chain_refused(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Focused unit-level companion to step 4 above: a cached "healthy"
    answer must be cleared the instant the real chain connect raises
    ConnectionRefusedError. No TTL wait, no second request needed —
    the same request that observed the failure falls through to
    passthrough.

    v0.1.22.24: edge now gates chaining on an LLM host allowlist; the
    loopback CONNECT in this test would otherwise skip chaining
    entirely. Allowlist semantics live in ``test_chain_decision.py`` /
    ``test_provider_hosts.py``; here we patch the gate open to keep
    the test focused on the cache-invalidation contract.
    """
    monkeypatch.setattr(
        "halton_meter.edge.host_should_intercept", lambda _h: True
    )
    upstream = _UpstreamServer()
    upstream_port = await upstream.start()

    # No daemon-target ever runs — connections to the internal port
    # raise ConnectionRefusedError immediately. We seed the health
    # cache with a stale-positive entry to simulate "the daemon was up
    # a moment ago but is not now".
    daemon_port = _next_free_port()

    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=daemon_port,
        healthy_ttl_s=60.0,  # long; only invalidate-on-refused should clear it
        unhealthy_ttl_s=0.2,
        probe_timeout_s=0.5,
    )
    cache = DaemonHealthCache(
        internal_host="127.0.0.1",
        internal_port=daemon_port,
        healthy_ttl_s=60.0,
        unhealthy_ttl_s=0.2,
    )
    cache._has_result = True
    cache._last_result = True
    cache._last_check_at = cache.clock()

    proxy = EdgeProxy(config, health_cache=cache)
    edge_port = await proxy.start()
    serve_task = asyncio.create_task(proxy.serve_forever())
    try:
        data = await _send_connect_via_edge(
            edge_port, "127.0.0.1", upstream_port
        )
        assert _UpstreamServer.MARKER in data
        # Cache invalidated on the refused chain attempt.
        assert cache._has_result is False or cache._last_result is False
    finally:
        await proxy.stop()
        serve_task.cancel()
        try:
            await serve_task
        except (asyncio.CancelledError, Exception):
            pass
        await upstream.stop()
