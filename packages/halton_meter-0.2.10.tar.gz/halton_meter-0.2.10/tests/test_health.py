"""Tests for ``halton_meter.health`` (v0.1.3 P0-6).

Pure probe primitives used by ``init`` self-test and by
``halton-meter doctor``.
"""

from __future__ import annotations

import socket
import urllib.error
from pathlib import Path
from typing import Any

import pytest

from halton_meter import health

# --------------------------------------------------------------------------- #
# check_daemon_health                                                         #
# --------------------------------------------------------------------------- #


class _FakeResp:
    def __init__(self, status: int) -> None:
        self.status = status

    def __enter__(self) -> _FakeResp:
        return self

    def __exit__(self, *_args: Any) -> None:
        return None


def test_daemon_health_returns_ok_on_200(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        health.urllib.request, "urlopen", lambda *_a, **_kw: _FakeResp(200)
    )
    res = health.check_daemon_health("127.0.0.1", 8765, timeout=1.0)
    assert res.ok is True


def test_daemon_health_returns_fail_on_non_2xx(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        health.urllib.request, "urlopen", lambda *_a, **_kw: _FakeResp(500)
    )
    res = health.check_daemon_health("127.0.0.1", 8765, timeout=1.0)
    assert res.ok is False


def test_daemon_health_returns_fail_on_url_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        health.urllib.request, "urlopen",
        lambda *_a, **_kw: (_ for _ in ()).throw(urllib.error.URLError("nope")),
    )
    res = health.check_daemon_health("127.0.0.1", 8765, timeout=0.1)
    assert res.ok is False


# --------------------------------------------------------------------------- #
# check_cert_trusted_macos                                                    #
# --------------------------------------------------------------------------- #


def test_cert_trusted_passes_when_helper_returns_true(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "halton_meter.setup._is_cert_trusted_macos", lambda: True
    )
    res = health.check_cert_trusted_macos()
    assert res.ok is True


def test_cert_trusted_fails_when_helper_returns_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "halton_meter.setup._is_cert_trusted_macos", lambda: False
    )
    res = health.check_cert_trusted_macos()
    assert res.ok is False
    assert "verify" in res.message.lower() or "trust" in res.message.lower()


# --------------------------------------------------------------------------- #
# check_port_persisted                                                        #
# --------------------------------------------------------------------------- #


def test_port_persisted_runtime_toml_present(tmp_path: Path) -> None:
    rt = tmp_path / "runtime.toml"
    rt.write_text("[daemon]\nlisten_port = 8081\n", encoding="utf-8")
    cfg = tmp_path / "config.toml"
    res = health.check_port_persisted(runtime_toml=rt, config_toml=cfg)
    assert res.ok is True
    assert res.severity == "fatal"  # default; passing is OK regardless


def test_port_persisted_config_pin_present(tmp_path: Path) -> None:
    rt = tmp_path / "runtime.toml"
    cfg = tmp_path / "config.toml"
    cfg.write_text("[daemon]\nlisten_port = 9000\n", encoding="utf-8")
    res = health.check_port_persisted(runtime_toml=rt, config_toml=cfg)
    assert res.ok is True


def test_port_persisted_defaults_returns_info_severity(tmp_path: Path) -> None:
    rt = tmp_path / "runtime.toml"
    cfg = tmp_path / "config.toml"
    res = health.check_port_persisted(runtime_toml=rt, config_toml=cfg)
    assert res.ok is True  # using defaults is OK
    assert res.severity == "info"


# --------------------------------------------------------------------------- #
# check_install_mode_sentinel                                                 #
# --------------------------------------------------------------------------- #


def test_install_mode_sentinel_present(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from halton_meter import init as init_module

    sentinel = tmp_path / "install-mode"
    sentinel.write_text("env-only\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", sentinel)

    res = health.check_install_mode_sentinel(sentinel_path=sentinel)
    assert res.ok is True


def test_install_mode_sentinel_absent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from halton_meter import init as init_module

    sentinel = tmp_path / "install-mode"
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", sentinel)
    res = health.check_install_mode_sentinel(sentinel_path=sentinel)
    assert res.ok is False


# --------------------------------------------------------------------------- #
# check_plists_loaded_macos                                                   #
# --------------------------------------------------------------------------- #


def test_plists_loaded_pid_present(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "halton_meter.cli._launchctl_managed_pid", lambda label: 12345
    )
    res = health.check_plists_loaded_macos(label="com.haltonlabs.meter")
    assert res.ok is True
    assert "12345" in res.message


def test_plists_loaded_pid_absent(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "halton_meter.cli._launchctl_managed_pid", lambda label: None
    )
    res = health.check_plists_loaded_macos(label="com.haltonlabs.meter")
    assert res.ok is False


# --------------------------------------------------------------------------- #
# check_system_proxy_points_at_us                                              #
# --------------------------------------------------------------------------- #


def test_system_proxy_points_at_us_match(monkeypatch: pytest.MonkeyPatch) -> None:
    from halton_meter import system_proxy

    monkeypatch.setattr(system_proxy._macos, "_macos_interfaces", lambda: ("Wi-Fi",))
    monkeypatch.setattr(
        system_proxy._macos, "_read_macos_proxy",
        lambda iface, secure: (True, "127.0.0.1", "8080"),
    )
    res = health.check_system_proxy_points_at_us(
        listen_host="127.0.0.1", listen_port=8080
    )
    assert res.ok is True


def test_system_proxy_points_at_us_no_match(monkeypatch: pytest.MonkeyPatch) -> None:
    from halton_meter import system_proxy

    monkeypatch.setattr(system_proxy._macos, "_macos_interfaces", lambda: ("Wi-Fi",))
    monkeypatch.setattr(
        system_proxy._macos, "_read_macos_proxy",
        lambda iface, secure: (False, None, None),
    )
    res = health.check_system_proxy_points_at_us(
        listen_host="127.0.0.1", listen_port=8080
    )
    assert res.ok is False


# --------------------------------------------------------------------------- #
# check_launchctl_env_var                                                     #
# --------------------------------------------------------------------------- #


def test_launchctl_env_var_present_with_substr(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "halton_meter.system_proxy.getenv_user_domain",
        lambda key: "http://127.0.0.1:8081",
    )
    res = health.check_launchctl_env_var(key="HTTPS_PROXY", expected_substr="8081")
    assert res.ok is True


def test_launchctl_env_var_present_but_substr_mismatch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "halton_meter.system_proxy.getenv_user_domain",
        lambda key: "http://127.0.0.1:8080",
    )
    res = health.check_launchctl_env_var(key="HTTPS_PROXY", expected_substr="9999")
    assert res.ok is False


def test_launchctl_env_var_absent(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "halton_meter.system_proxy.getenv_user_domain", lambda key: None
    )
    res = health.check_launchctl_env_var(key="HTTPS_PROXY")
    assert res.ok is False


# --------------------------------------------------------------------------- #
# shell_env_present                                                           #
# --------------------------------------------------------------------------- #


def test_shell_env_present_returns_dict_with_all_keys(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HTTPS_PROXY", "http://x:1")
    monkeypatch.delenv("NO_PROXY", raising=False)
    snap = health.shell_env_present()
    assert "HTTPS_PROXY" in snap
    assert snap["HTTPS_PROXY"] == "http://x:1"
    assert snap["NO_PROXY"] is None


# --------------------------------------------------------------------------- #
# check_can_listen                                                            #
# --------------------------------------------------------------------------- #


def test_check_can_listen_against_open_socket(tmp_path: Path) -> None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)
    port = sock.getsockname()[1]
    try:
        res = health.check_can_listen("127.0.0.1", port)
        assert res.ok is True
    finally:
        sock.close()


def test_check_can_listen_against_closed_port() -> None:
    # Pick a port we know nothing is listening on (use 1 which is reserved
    # and rejected almost everywhere as a non-root listener).
    res = health.check_can_listen("127.0.0.1", 1)
    assert res.ok is False
