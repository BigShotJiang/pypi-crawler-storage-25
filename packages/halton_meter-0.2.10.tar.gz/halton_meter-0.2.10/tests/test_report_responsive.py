"""v0.1.22.18 Fix 2: responsive cost-report layout.

Pre-fix the report's by-project / by-model tables always tried to
render the full column set (project · requests · cost · share · avg ·
p95 · 7d trend). Below width 100 the headers truncated
(``reque…``, ``▁▁▁▁…``) and the share bar got cropped.

This module verifies the four-tier layout selection in
``_layout_for_width`` and the rendered table cell counts at each width.

CSV / JSON exports are unaffected by terminal width — verified
explicitly so future drift can't bleed presentation rules into the
wire formats clients consume.
"""

from __future__ import annotations

import io
import json
from datetime import UTC, datetime, timedelta

from rich.console import Console

from halton_meter.models import LogRecord
from halton_meter.report import (
    _layout_for_width,
    build_report_data,
    render_csv,
    render_json,
    render_report,
)


def _rec(
    *,
    project: str = "alpha",
    cost_millicents: int = 1_000,
    requested_at: str | None = None,
) -> LogRecord:
    if requested_at is None:
        requested_at = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    return LogRecord(
        id="test-id",
        project=project,
        provider="anthropic",
        model="claude-haiku-4-5",
        input_tokens=100,
        output_tokens=50,
        cost_millicents=cost_millicents,
        tokens_complete=True,
        latency_ms=500.0,
        requested_at=requested_at,
        recorded_at=requested_at,
    )


def _multi_day_records() -> list[LogRecord]:
    """Two days of records so ``span_days >= 2`` and the trend column
    is eligible at the top tier."""
    today = datetime.now(UTC)
    yesterday = today - timedelta(days=1)
    return [
        _rec(
            project="alpha",
            cost_millicents=1_000,
            requested_at=yesterday.isoformat().replace("+00:00", "Z"),
        ),
        _rec(
            project="beta",
            cost_millicents=500,
            requested_at=today.isoformat().replace("+00:00", "Z"),
        ),
    ]


def _render_at_width(width: int) -> str:
    """Render the full report into a plain-text buffer at ``width``."""
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, width=width)
    data = build_report_data(_multi_day_records())
    render_report(data, console)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# _layout_for_width — pure unit tests for the tier selector
# ---------------------------------------------------------------------------


class TestLayoutTiers:
    def test_top_tier_at_120(self) -> None:
        layout = _layout_for_width(120)
        assert layout.show_avg
        assert layout.show_p95
        assert layout.show_trend
        assert layout.share_width == 10

    def test_top_tier_boundary_at_110(self) -> None:
        # Exactly the bottom of the top tier.
        layout = _layout_for_width(110)
        assert layout.show_trend
        assert layout.share_width == 10

    def test_mid_tier_at_100(self) -> None:
        layout = _layout_for_width(100)
        assert layout.show_avg
        assert layout.show_p95
        assert not layout.show_trend
        assert layout.share_width == 8

    def test_compact_tier_at_80(self) -> None:
        layout = _layout_for_width(80)
        assert layout.show_avg
        assert not layout.show_p95
        assert not layout.show_trend
        assert layout.share_width == 5

    def test_min_tier_at_60(self) -> None:
        layout = _layout_for_width(60)
        assert not layout.show_avg
        assert not layout.show_p95
        assert not layout.show_trend
        assert layout.share_width == 3

    def test_zero_width_falls_back_to_min_tier(self) -> None:
        layout = _layout_for_width(0)
        assert not layout.show_avg
        assert layout.share_width == 3


# ---------------------------------------------------------------------------
# End-to-end render: column-count assertions via header text
# ---------------------------------------------------------------------------


class TestResponsiveRender:
    def test_width_120_shows_all_columns(self) -> None:
        out = _render_at_width(120)
        # Headers present (lower-case, plain text).
        assert "project" in out
        assert "requests" in out
        assert "cost" in out
        assert "share" in out
        assert "avg" in out
        assert "p95" in out
        assert "7d trend" in out

    def test_width_100_drops_7d_trend(self) -> None:
        out = _render_at_width(100)
        assert "avg" in out
        assert "p95" in out
        assert "7d trend" not in out

    def test_width_80_drops_p95_and_trend(self) -> None:
        out = _render_at_width(80)
        assert "avg" in out
        assert "p95" not in out
        assert "7d trend" not in out

    def test_width_60_drops_avg_p95_and_trend(self) -> None:
        out = _render_at_width(60)
        # ``avg`` may or may not appear as a substring of an unrelated
        # word; the by-project table header is " avg " in column form,
        # and at width 60 the column is dropped entirely. Check the
        # column header explicitly.
        assert " avg " not in out
        assert "p95" not in out
        assert "7d trend" not in out
        # The core column set must still be present.
        assert "project" in out
        assert "requests" in out
        assert "cost" in out
        assert "share" in out


# ---------------------------------------------------------------------------
# Wire formats unaffected
# ---------------------------------------------------------------------------


class TestExportsUnaffectedByWidth:
    def test_csv_does_not_consult_console_width(self) -> None:
        data = build_report_data(_multi_day_records())
        # CSV is rendered through stdlib csv module — terminal-width
        # has nothing to do with it. Verify the emitted text is
        # identical at narrow vs wide consoles.
        narrow_buf = io.StringIO()
        wide_buf = io.StringIO()
        render_csv(data, Console(file=narrow_buf, force_terminal=False, width=60))
        render_csv(data, Console(file=wide_buf, force_terminal=False, width=200))
        assert narrow_buf.getvalue() == wide_buf.getvalue()
        # And the schema header carries the full latency column set.
        first_line = narrow_buf.getvalue().splitlines()[0]
        assert "avg_latency_ms" in first_line
        assert "p95_latency_ms" in first_line

    def test_json_does_not_consult_console_width(self) -> None:
        data = build_report_data(_multi_day_records())
        narrow_buf = io.StringIO()
        wide_buf = io.StringIO()
        render_json(data, Console(file=narrow_buf, force_terminal=False, width=60))
        render_json(data, Console(file=wide_buf, force_terminal=False, width=200))
        # JSON output is identical regardless of terminal width.
        assert narrow_buf.getvalue() == wide_buf.getvalue()
        parsed = json.loads(narrow_buf.getvalue())
        assert "by_project" in parsed
        assert all(
            "avg_latency_ms" in p and "p95_latency_ms" in p
            for p in parsed["by_project"]
        )
