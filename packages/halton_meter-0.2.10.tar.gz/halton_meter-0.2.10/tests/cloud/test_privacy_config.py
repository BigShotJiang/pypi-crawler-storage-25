"""Tests for `[cloud.upload]` parsing in ``cloud/config_glue.py``.

Covers:
- TOML missing → default policy.
- Preset + global field overrides + per-project rules round-trip.
- Malformed TOML / unknown preset → fail-closed to standard.
"""

from __future__ import annotations

from pathlib import Path

from halton_meter.cloud.config_glue import load_upload_policy
from halton_meter.cloud.privacy import UploadPreset


def test_no_file_returns_default_policy(tmp_path: Path) -> None:
    policy = load_upload_policy(config_path=tmp_path / "nope.toml")
    assert policy.preset is UploadPreset.standard
    assert policy.field_overrides == {}
    assert policy.per_project == {}


def test_no_cloud_upload_section_returns_default(tmp_path: Path) -> None:
    cfg = tmp_path / "config.toml"
    cfg.write_text("[storage]\ndb_path = '/tmp/nope.sqlite'\n")
    policy = load_upload_policy(config_path=cfg)
    assert policy.preset is UploadPreset.standard


def test_full_policy_round_trips(tmp_path: Path) -> None:
    cfg = tmp_path / "config.toml"
    cfg.write_text(
        """
[cloud.upload]
preset = "minimal"

[cloud.upload.fields]
source_machine = true
prompt_hash = true

[cloud.upload.per_project."acme-secret"]
upload = false

[cloud.upload.per_project."client-x"]
upload = true
fields.source_workdir = false
"""
    )
    policy = load_upload_policy(config_path=cfg)
    assert policy.preset is UploadPreset.minimal
    assert policy.field_overrides == {
        "source_machine": True,
        "prompt_hash": True,
    }
    assert policy.per_project["acme-secret"].upload is False
    assert policy.per_project["client-x"].upload is True
    assert policy.per_project["client-x"].fields == {"source_workdir": False}


def test_unknown_preset_falls_back_to_standard(tmp_path: Path) -> None:
    """Privacy-by-default: a typo'd preset name does not silently send more."""
    cfg = tmp_path / "config.toml"
    cfg.write_text('[cloud.upload]\npreset = "paranoid"\n')
    policy = load_upload_policy(config_path=cfg)
    assert policy.preset is UploadPreset.standard


def test_unknown_field_names_are_dropped(tmp_path: Path) -> None:
    """Forward-compat: the resolver ignores unknown gateable-field names."""
    cfg = tmp_path / "config.toml"
    cfg.write_text(
        """
[cloud.upload]
preset = "standard"

[cloud.upload.fields]
future_unknown_field = true
source_workdir = true
"""
    )
    policy = load_upload_policy(config_path=cfg)
    assert "future_unknown_field" not in policy.field_overrides
    assert policy.field_overrides == {"source_workdir": True}


def test_malformed_toml_returns_default(tmp_path: Path) -> None:
    """A broken TOML degrades to the safest default — standard preset."""
    cfg = tmp_path / "config.toml"
    cfg.write_text("[cloud.upload\nbroken =")
    policy = load_upload_policy(config_path=cfg)
    assert policy.preset is UploadPreset.standard
    assert policy.field_overrides == {}
    assert policy.per_project == {}
