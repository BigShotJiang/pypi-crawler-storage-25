"""``maybe_spawn_body_uploader`` gating tests (v0.2.2 body sync).

Asserts the three spawn gates (cloud master, bodies-enabled, token-present)
and that none of them touch SQLite, the filesystem, or the live cloud
endpoint when probed in isolation.
"""

from __future__ import annotations

import asyncio
from typing import Any

from halton_meter.cloud._supervisor_glue import maybe_spawn_body_uploader
from halton_meter.cloud.config_glue import (
    CloudBodiesConfig,
    CloudClientConfig,
)


def _cfg_active() -> CloudClientConfig:
    return CloudClientConfig(
        enabled=True,
        base_url="https://cloud.test",
        continuous=True,
        sync_interval_seconds=30,
    )


def _cfg_disabled() -> CloudClientConfig:
    return CloudClientConfig(
        enabled=False, base_url="", continuous=True, sync_interval_seconds=30
    )


class _FakeTask:
    """Minimal stand-in for ``asyncio.Task`` — non-truthy attribute access only."""

    def get_name(self) -> str:
        return "halton-cloud-body-uploader"


def _record_runner() -> tuple[Any, list[str]]:
    """Return a ``task_runner`` stub that records spawn names without scheduling.

    The runner closes the coroutine it receives (since we never plan to run
    it) and returns a sentinel task object so the spawn helper's caller can
    distinguish "spawned" from "skipped".
    """
    spawned: list[str] = []

    def _runner(coro: Any, name: str) -> Any:
        spawned.append(name)
        try:
            coro.close()
        except Exception:
            pass
        return _FakeTask()

    return _runner, spawned


# ─── 1. bodies disabled → no spawn ──────────────────────────────────────


def test_bodies_disabled_no_spawn() -> None:
    runner, spawned = _record_runner()
    task = maybe_spawn_body_uploader(
        shutdown_event=asyncio.Event(),
        cloud_config_loader=_cfg_active,
        bodies_config_loader=lambda: CloudBodiesConfig(enabled=False),
        token_provider=lambda: "hm_sync_xyz",
        task_runner=runner,
    )
    assert task is None
    assert spawned == []


# ─── 2. cloud master disabled → no spawn even with bodies on ────────────


def test_cloud_disabled_no_spawn_even_if_bodies_enabled() -> None:
    runner, spawned = _record_runner()
    task = maybe_spawn_body_uploader(
        shutdown_event=asyncio.Event(),
        cloud_config_loader=_cfg_disabled,
        bodies_config_loader=lambda: CloudBodiesConfig(enabled=True),
        token_provider=lambda: "hm_sync_xyz",
        task_runner=runner,
    )
    assert task is None
    assert spawned == []


# ─── 3. no token → no spawn ─────────────────────────────────────────────


def test_no_token_no_spawn() -> None:
    runner, spawned = _record_runner()
    task = maybe_spawn_body_uploader(
        shutdown_event=asyncio.Event(),
        cloud_config_loader=_cfg_active,
        bodies_config_loader=lambda: CloudBodiesConfig(enabled=True),
        token_provider=lambda: None,
        task_runner=runner,
    )
    assert task is None
    assert spawned == []


# ─── 4. all gates pass → spawn under the expected task name ─────────────


def test_all_gates_pass_spawns_task() -> None:
    runner, spawned = _record_runner()
    task = maybe_spawn_body_uploader(
        shutdown_event=asyncio.Event(),
        cloud_config_loader=_cfg_active,
        bodies_config_loader=lambda: CloudBodiesConfig(
            enabled=True, sync_interval_seconds=15
        ),
        token_provider=lambda: "hm_sync_xyz",
        # Replace factories with cheap closures so the spawn doesn't open
        # SQLite during the test.
        pending_reader_factory=lambda: (lambda _l: _noop_list()),
        upload_marker_factory=lambda: (lambda _r: _noop()),
        pause_writer_factory=lambda _ep: (lambda _r: _noop()),
        project_gate_factory=lambda _cfg: (lambda _slug: True),
        task_runner=runner,
    )
    assert task is not None
    assert spawned == ["halton-cloud-body-uploader"]


async def _noop() -> None:
    return None


async def _noop_list() -> list[Any]:
    return []
