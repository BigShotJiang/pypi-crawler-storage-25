"""Test: CloudClient.reconciliation_totals sends from_date/to_date.

Pre-v0.2.1 bug: daemon sent ``from`` and ``to`` query params; cloud's
reconciliation router expects ``from_date`` and ``to_date``. Every reconcile
returned HTTP 422 with the cloud's "Field required" detail.
"""

from __future__ import annotations

import httpx
import pytest

from halton_meter.cloud.client import CloudClient


@pytest.mark.asyncio
async def test_reconciliation_totals_sends_from_date_to_date() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["query"] = request.url.query.decode()
        return httpx.Response(200, json={"rows": [], "generated_at": "2026-05-12T00:00:00Z"})

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="http://test",
        token_provider=lambda: "hm_sync_test",
        transport=transport,
    ) as client:
        await client.reconciliation_totals(
            date_from="2026-04-01", date_to="2026-05-12"
        )

    # Whatever the keys were renamed FROM, they MUST be from_date/to_date now.
    assert "from_date=2026-04-01" in captured["query"]
    assert "to_date=2026-05-12" in captured["query"]
    assert captured["path"] == "/v1/reconciliation/daemon-totals"


@pytest.mark.asyncio
async def test_reconciliation_totals_includes_machine_id_when_supplied() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["query"] = request.url.query.decode()
        return httpx.Response(200, json={"rows": [], "generated_at": "2026-05-12T00:00:00Z"})

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="http://test",
        token_provider=lambda: "hm_sync_test",
        transport=transport,
    ) as client:
        await client.reconciliation_totals(
            date_from="2026-04-01",
            date_to="2026-05-12",
            machine_id="f2ebe7df-7605-4a7d-814a-ba25d0794e94",
        )

    assert "machine_id=f2ebe7df-7605-4a7d-814a-ba25d0794e94" in captured["query"]
    assert "from_date=2026-04-01" in captured["query"]
    assert "to_date=2026-05-12" in captured["query"]
