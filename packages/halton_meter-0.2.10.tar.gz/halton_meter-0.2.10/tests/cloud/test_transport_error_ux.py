"""v0.2.5 — friendly transport error + placeholder TLD guard.

Tests for:
1. ``_check_base_url_not_placeholder`` raises ``CloudTransport`` with a
   helpful message for placeholder TLDs (.test, .example, .invalid, .local).
2. Production-looking URLs are allowed through without raising.
3. The placeholder check is skipped when a test transport is injected.
4. The ``cloud.transport_error`` log message includes the host and config hint.
"""

from __future__ import annotations

import logging

import httpx
import pytest

from halton_meter.cloud.client import CloudClient, _check_base_url_not_placeholder
from halton_meter.cloud.errors import CloudTransport

# ---------------------------------------------------------------------------
# _check_base_url_not_placeholder unit tests
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "url",
    [
        "https://meter.example.test",
        "https://api.example.test",
        "http://local.example.invalid",
        "https://halton.local",
        "https://cloud.test",
        "https://meter.example",
    ],
)
def test_placeholder_tld_raises(url: str) -> None:
    """Placeholder TLDs raise CloudTransport with an actionable message."""
    with pytest.raises(CloudTransport) as exc_info:
        _check_base_url_not_placeholder(url)
    msg = str(exc_info.value)
    # Message should mention the URL and the config path hint.
    assert "placeholder" in msg.lower() or "reserved" in msg.lower() or "RFC" in msg
    assert "config.toml" in msg or "halton-meter" in msg.lower()


@pytest.mark.parametrize(
    "url",
    [
        "https://api.haltonmeter.com",
        "https://backend-production-30d99.up.railway.app",
        "https://halton-meter-cloud.vercel.app",
        "http://localhost:8000",  # local dev — explicit localhost, not .local TLD
        "",  # empty string is allowed (means "disabled")
    ],
)
def test_production_url_does_not_raise(url: str) -> None:
    """Well-formed production URLs pass through without raising."""
    _check_base_url_not_placeholder(url)  # must not raise


def test_placeholder_check_skipped_with_mock_transport() -> None:
    """Placeholder TLD guard is skipped when a test transport is injected.

    Tests use placeholder hostnames by convention. When MockTransport is
    supplied, the URL is just a routing label — no real connection is made.
    """
    calls: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(200, json={})

    transport = httpx.MockTransport(handler)
    # Would raise if the guard ran — but transport=... skips it.
    import asyncio

    async def _run() -> None:
        async with CloudClient(
            base_url="https://halton.local",
            transport=transport,
            token_provider=lambda: "test-token",
        ) as c:
            # GET that returns 200 — just to confirm the context manager opened.
            await c._request("GET", "/v1/daemon/whoami")

    asyncio.run(_run())
    assert calls == [1]


@pytest.mark.asyncio
async def test_transport_error_log_includes_host(caplog: pytest.LogCaptureFixture) -> None:
    """The cloud.transport_error warning includes the host and config hint."""
    import halton_meter.cloud.client as _m

    async def _no_sleep(_: float) -> None:
        return None

    original_sleep = _m._sleep_with_jitter
    _m._sleep_with_jitter = _no_sleep  # type: ignore[assignment]
    original_retries = _m.MAX_RETRIES
    _m.MAX_RETRIES = 0  # fail fast

    call_count = [0]

    def handler(request: httpx.Request) -> httpx.Response:
        call_count[0] += 1
        raise httpx.ConnectError("connection refused")

    transport = httpx.MockTransport(handler)

    try:
        with caplog.at_level(logging.WARNING, logger="halton_meter.cloud.client"):
            with pytest.raises(CloudTransport) as exc_info:
                async with CloudClient(
                    base_url="https://api.haltonmeter.com",
                    transport=transport,
                    token_provider=lambda: "test-token",
                ) as c:
                    await c.batch_ingest(batch_id="b1", records=[])
        # The exception message should include the host.
        assert "api.haltonmeter.com" in str(exc_info.value)
        assert "config.toml" in str(exc_info.value) or "halton-meter" in str(exc_info.value).lower()
        # The log record should mention the host.
        transport_warning = next(
            (r for r in caplog.records if "transport_error" in r.message),
            None,
        )
        assert transport_warning is not None, "No transport_error log entry found"
        assert "api.haltonmeter.com" in transport_warning.message
    finally:
        _m._sleep_with_jitter = original_sleep  # type: ignore[assignment]
        _m.MAX_RETRIES = original_retries
