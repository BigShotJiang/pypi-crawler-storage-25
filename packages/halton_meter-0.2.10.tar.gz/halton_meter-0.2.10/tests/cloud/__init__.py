"""Tests for the Phase 2 cloud subpackage (Wave 1A.iii)."""
