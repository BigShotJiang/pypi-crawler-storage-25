"""Tests for the upload-privacy resolver in ``cloud/privacy.py``.

Pure-logic tests — no IO, no fixtures beyond stdlib. Cover:

* Preset defaults match the documented behaviour for minimal/standard/full.
* Global field overrides win over preset.
* Per-project rules win over global overrides.
* ``upload=false`` short-circuits regardless of field overrides.
* The ``apply_to_wire`` transform nulls dropped fields without removing
  keys (shape stability per the wire contract).
"""

from __future__ import annotations

from halton_meter.cloud.privacy import (
    GATEABLE_FIELDS,
    PRESET_DEFAULTS,
    ProjectRule,
    UploadPolicy,
    UploadPreset,
    apply_to_wire,
    describe,
    resolve_for_project,
)

_BASELINE_WIRE = {
    "id": "rec-0001",
    "project": "alpha",
    "provider": "anthropic",
    "model": "claude-sonnet-4-6",
    "input_tokens": 100,
    "output_tokens": 50,
    "source_workdir": "/Users/dev/secret-client/project",
    "source_machine": "macbook.local",
    "prompt_hash": "deadbeef",
    "attribution_method": "env",
    "idempotency_key": "anthropic-abc-123",
}


# ─── Preset defaults ──────────────────────────────────────────────────────────


def test_preset_minimal_drops_all_high_signal_fields() -> None:
    """Minimal preset withholds project, workdir, hostname, prompt_hash."""
    defaults = PRESET_DEFAULTS[UploadPreset.minimal]
    assert defaults["project"] is False
    assert defaults["source_workdir"] is False
    assert defaults["source_machine"] is False
    assert defaults["prompt_hash"] is False
    # Provider-issued idempotency key has no PII.
    assert defaults["idempotency_key"] is True


def test_preset_standard_withholds_only_workdir() -> None:
    """Standard preset — v0.2.0 default — keeps project + hostname + hash, drops workdir."""
    defaults = PRESET_DEFAULTS[UploadPreset.standard]
    assert defaults["project"] is True
    assert defaults["source_machine"] is True
    assert defaults["prompt_hash"] is True
    assert defaults["source_workdir"] is False  # the high-leak field
    assert defaults["attribution_method"] is True


def test_preset_full_sends_everything() -> None:
    """Full preset is the pre-privacy behaviour for backward-compat."""
    defaults = PRESET_DEFAULTS[UploadPreset.full]
    for field_name in GATEABLE_FIELDS:
        assert defaults[field_name] is True, field_name


# ─── Global field overrides ───────────────────────────────────────────────────


def test_global_override_can_force_workdir_back_on() -> None:
    """An operator who explicitly trusts workdir can flip it without changing preset."""
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        field_overrides={"source_workdir": True},
    )
    resolved = resolve_for_project(policy, project="alpha")
    assert resolved.upload is True
    assert resolved.fields["source_workdir"] is True
    # Other standard-preset fields untouched.
    assert resolved.fields["project"] is True


def test_global_override_can_force_hostname_off_on_standard() -> None:
    """Tightening below the preset is the common case."""
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        field_overrides={"source_machine": False, "prompt_hash": False},
    )
    resolved = resolve_for_project(policy, project="alpha")
    assert resolved.fields["source_machine"] is False
    assert resolved.fields["prompt_hash"] is False


def test_global_override_for_unknown_field_is_silently_ignored() -> None:
    """Forward-compat: unknown fields in the config don't crash the resolver."""
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        field_overrides={"future_field_unknown_in_v0_2_0": False},
    )
    resolved = resolve_for_project(policy, project="alpha")
    # The standard-preset shape is intact; the unknown key didn't pollute it.
    assert resolved.fields == PRESET_DEFAULTS[UploadPreset.standard]


# ─── Per-project rules ────────────────────────────────────────────────────────


def test_per_project_upload_false_short_circuits() -> None:
    """`upload=false` for a project drops the record before any field logic."""
    policy = UploadPolicy(
        preset=UploadPreset.full,
        per_project={"acme-secret": ProjectRule(upload=False)},
    )
    resolved = resolve_for_project(policy, project="acme-secret")
    assert resolved.upload is False


def test_per_project_upload_true_with_field_overrides() -> None:
    """Project keeps uploading but locks down specific fields."""
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        per_project={
            "client-x": ProjectRule(
                upload=True,
                fields={"prompt_hash": False, "source_machine": False},
            )
        },
    )
    resolved = resolve_for_project(policy, project="client-x")
    assert resolved.upload is True
    assert resolved.fields["prompt_hash"] is False
    assert resolved.fields["source_machine"] is False
    # Project slug itself still travels.
    assert resolved.fields["project"] is True


def test_per_project_overrides_global_overrides() -> None:
    """When global and per-project disagree, the project-specific rule wins."""
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        field_overrides={"source_workdir": True},  # global says yes
        per_project={
            "client-x": ProjectRule(fields={"source_workdir": False})  # project says no
        },
    )
    resolved = resolve_for_project(policy, project="client-x")
    assert resolved.fields["source_workdir"] is False


def test_per_project_does_not_affect_other_projects() -> None:
    """Per-project rules apply only to the named project."""
    policy = UploadPolicy(
        preset=UploadPreset.full,
        per_project={"acme-secret": ProjectRule(upload=False)},
    )
    other = resolve_for_project(policy, project="alpha")
    assert other.upload is True
    # And the full preset is intact for alpha.
    for field_name in GATEABLE_FIELDS:
        assert other.fields[field_name] is True


def test_unattributed_record_falls_through_to_global_policy() -> None:
    """A record with project=None gets the preset + global overrides only."""
    policy = UploadPolicy(
        preset=UploadPreset.minimal,
        per_project={"alpha": ProjectRule(upload=False)},
    )
    resolved = resolve_for_project(policy, project=None)
    # No per-project rule kicks in; minimal-preset shape applies.
    assert resolved.upload is True
    assert resolved.fields == PRESET_DEFAULTS[UploadPreset.minimal]


# ─── apply_to_wire ────────────────────────────────────────────────────────────


def test_apply_to_wire_nulls_dropped_fields_without_removing_keys() -> None:
    """Dropped fields become None; the dict still has the same shape."""
    policy = UploadPolicy(preset=UploadPreset.standard)
    resolved = resolve_for_project(policy, project="alpha")
    out = apply_to_wire(_BASELINE_WIRE, resolved)
    # Standard preset drops source_workdir.
    assert out["source_workdir"] is None
    # Untouched fields survive verbatim.
    assert out["project"] == "alpha"
    assert out["input_tokens"] == 100
    # Shape preserved — every original key is still present.
    assert set(out) == set(_BASELINE_WIRE)


def test_apply_to_wire_is_pure() -> None:
    """Input dict is not mutated."""
    policy = UploadPolicy(preset=UploadPreset.minimal)
    resolved = resolve_for_project(policy, project="alpha")
    before = dict(_BASELINE_WIRE)
    apply_to_wire(_BASELINE_WIRE, resolved)
    assert _BASELINE_WIRE == before


def test_apply_to_wire_with_upload_false_redacts_all_gateable() -> None:
    """Defensive: an upload=False resolved policy redacts everything if applied."""
    policy = UploadPolicy(
        preset=UploadPreset.full,
        per_project={"acme-secret": ProjectRule(upload=False)},
    )
    resolved = resolve_for_project(policy, project="acme-secret")
    out = apply_to_wire(_BASELINE_WIRE, resolved)
    for field_name in GATEABLE_FIELDS:
        assert out[field_name] is None, field_name


# ─── describe ─────────────────────────────────────────────────────────────────


def test_describe_renders_preset_and_overrides() -> None:
    """The ``cloud privacy show`` output names the preset and overrides."""
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        field_overrides={"prompt_hash": False},
        per_project={"acme-secret": ProjectRule(upload=False)},
    )
    rendered = describe(policy)
    assert "preset = standard" in rendered
    assert "prompt_hash = False" in rendered
    assert "acme-secret" in rendered
    assert "entire project skipped" in rendered


def test_describe_default_policy_is_readable() -> None:
    """The default policy renders without overrides noise."""
    rendered = describe(UploadPolicy.default())
    assert "preset = standard" in rendered
    assert "(none)" in rendered
