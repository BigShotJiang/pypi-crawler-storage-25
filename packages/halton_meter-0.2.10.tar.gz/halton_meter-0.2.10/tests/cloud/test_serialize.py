"""Serializer round-trip — LogRecord → LogRecordIn dict.

Pinned to the Phase 2 wire contract at SHA ``e8f252a``
(``memory/plans/phase2-wire-contract.md`` § 3). When that doc changes,
this test fails first; on purpose.
"""

from __future__ import annotations

from decimal import Decimal

from halton_meter.cloud.serialize import _serialize_fx_rate, log_record_to_wire
from halton_meter.models import LogRecord


def _make_record(**overrides):
    base = dict(
        id="11111111-2222-3333-4444-555555555555",
        project="acme",
        provider="anthropic",
        model="claude-sonnet-4",
        input_tokens=100,
        output_tokens=200,
        thinking_tokens=10,
        cache_read_tokens=5,
        cache_write_tokens=3,
        cost_millicents=12345,
        tokens_complete=True,
        latency_ms=123.4,
        requested_at="2026-05-10T12:00:00Z",
        recorded_at="2026-05-10T12:00:01Z",
        status="success",
        attribution_method="env",
        source_workdir="/home/dev/acme",
    )
    base.update(overrides)
    return LogRecord(**base)


def test_serialize_includes_all_contract_fields():
    record = _make_record()

    wire = log_record_to_wire(record, source_machine="dev-laptop")

    # Every field listed in wire-contract § 3 must be present in the
    # output, even when the source value is None. Missing keys would
    # silently change semantics on the cloud side; explicit nulls don't.
    expected_keys = {
        "id",
        "project",
        "provider",
        "model",
        "input_tokens",
        "output_tokens",
        "thinking_tokens",
        "cached_tokens",
        "cache_write_tokens",
        "cost_millicents",
        "cost_usd_minor_units",
        "fx_rate",
        "tokens_complete",
        "latency_ms",
        "time_to_first_token_ms",
        "requested_at",
        "recorded_at",
        "status",
        "request_kind",
        "attribution_method",
        "source_workdir",
        "source_machine",
        "prompt_hash",
        "idempotency_key",
    }
    assert set(wire.keys()) == expected_keys


def test_cache_read_tokens_renames_to_cached_tokens():
    record = _make_record(cache_read_tokens=42)
    wire = log_record_to_wire(record)
    assert wire["cached_tokens"] == 42


def test_cost_double_keyed_for_alias_window():
    """Wave-0 contract: cloud accepts ``cost_millicents`` and
    ``cost_usd_minor_units``; daemon sends both so either cloud version
    persists the row.
    """
    record = _make_record(cost_millicents=98765)
    wire = log_record_to_wire(record)
    assert wire["cost_millicents"] == 98765
    assert wire["cost_usd_minor_units"] == 98765


def test_source_machine_falls_through_kwarg():
    record = _make_record()
    wire = log_record_to_wire(record, source_machine="laptop-42")
    assert wire["source_machine"] == "laptop-42"


def test_fx_rate_decimal_preserved():
    """``fx_rate`` must be a Decimal-precise string on the wire."""
    assert _serialize_fx_rate(Decimal("0.793215")) == "0.793215"
    assert _serialize_fx_rate(Decimal("0.79")) == "0.79"
    assert _serialize_fx_rate(None) is None


def test_fx_rate_float_coerced_via_str():
    # Float 0.79 → str "0.79" → Decimal, avoids binary-fraction drift.
    assert _serialize_fx_rate(0.79) == "0.79"


def test_optional_fields_default_to_none_when_record_lacks_them():
    """Forward-compat: today's ``LogRecord`` doesn't carry
    ``time_to_first_token_ms`` / ``prompt_hash`` / etc. (Wave 1A.i adds
    them). The serializer must still emit explicit ``null`` so the wire
    shape is stable.
    """
    record = _make_record()
    wire = log_record_to_wire(record)
    assert wire["time_to_first_token_ms"] is None
    assert wire["prompt_hash"] is None
    assert wire["idempotency_key"] is None
    assert wire["request_kind"] is None
