"""Test: ``cloud connect --base-url`` persists to config.toml.

Pre-v0.2.1 bug: the --base-url flag was a transient override that let pairing
succeed but never wrote ``[cloud].base_url`` to the user's TOML. The result
was a successful pair followed by ``cloud status`` reporting empty fields
(because every other command resolves the endpoint via ``load_cloud_config``,
which reads TOML).

This test exercises the persist helper directly with a tmp HOME so we don't
touch the developer's real config.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

import pytest

from halton_meter import cli_cloud


def test_persist_base_url_writes_cloud_block(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cfg_path = tmp_path / "config.toml"
    monkeypatch.setattr(cli_cloud, "_CONFIG_TOML_PATH", cfg_path)

    cli_cloud._persist_base_url_to_toml("https://cloud.example.com")

    data = tomllib.loads(cfg_path.read_text())
    assert data["cloud"]["base_url"] == "https://cloud.example.com"
    assert data["cloud"]["enabled"] is True


def test_persist_base_url_merges_with_existing_cloud_block(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """User already has a [cloud] block with other keys — they must survive."""
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(
        """
[cloud]
sync_interval_seconds = 60
continuous = false

[cloud.upload]
preset = "minimal"
"""
    )
    monkeypatch.setattr(cli_cloud, "_CONFIG_TOML_PATH", cfg_path)

    cli_cloud._persist_base_url_to_toml("https://cloud.example.com")

    data = tomllib.loads(cfg_path.read_text())
    assert data["cloud"]["base_url"] == "https://cloud.example.com"
    assert data["cloud"]["enabled"] is True
    assert data["cloud"]["sync_interval_seconds"] == 60
    assert data["cloud"]["continuous"] is False
    assert data["cloud"]["upload"]["preset"] == "minimal"


def test_persist_base_url_preserves_other_top_level_sections(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """[daemon], [storage], etc. must not be stomped by the [cloud] write."""
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(
        """
[daemon]
edge_port = 9999

[storage]
db_path = "/tmp/halton.sqlite"
"""
    )
    monkeypatch.setattr(cli_cloud, "_CONFIG_TOML_PATH", cfg_path)

    cli_cloud._persist_base_url_to_toml("https://cloud.example.com")

    text = cfg_path.read_text()
    assert "edge_port = 9999" in text
    assert '"/tmp/halton.sqlite"' in text
    data = tomllib.loads(text)
    assert data["cloud"]["base_url"] == "https://cloud.example.com"


def test_persist_base_url_creates_config_when_absent(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Fresh install: no config.toml exists yet. Helper creates it."""
    cfg_path = tmp_path / "nested" / "config.toml"
    monkeypatch.setattr(cli_cloud, "_CONFIG_TOML_PATH", cfg_path)
    assert not cfg_path.exists()

    cli_cloud._persist_base_url_to_toml("https://cloud.example.com")

    assert cfg_path.exists()
    data = tomllib.loads(cfg_path.read_text())
    assert data["cloud"]["base_url"] == "https://cloud.example.com"
