"""Config-glue read of the ``[cloud]`` TOML block."""

from __future__ import annotations

from pathlib import Path

from halton_meter.cloud.config_glue import load_cloud_config


def test_missing_file_yields_safe_defaults(tmp_path: Path):
    cfg = load_cloud_config(config_path=tmp_path / "does-not-exist.toml")
    assert cfg.enabled is False
    # v0.2.5: base_url defaults to the production URL rather than empty string
    # so users who have no config.toml still point at the correct endpoint.
    # sync is still disabled because enabled=False.
    assert cfg.base_url == "https://api.haltonmeter.com"
    assert cfg.continuous is True
    assert cfg.sync_interval_seconds == 30
    assert cfg.is_active is False  # enabled=False → not active despite non-empty URL


def test_reads_cloud_block(tmp_path: Path):
    path = tmp_path / "config.toml"
    path.write_text(
        '\n'.join(
            [
                "[cloud]",
                "enabled = true",
                'base_url = "https://meter.example.test"',
                "continuous = false",
                "sync_interval_seconds = 15",
            ]
        )
    )
    cfg = load_cloud_config(config_path=path)
    assert cfg.enabled is True
    # v0.2.6: placeholder TLD is replaced with the production URL automatically.
    assert cfg.base_url == "https://api.haltonmeter.com"
    assert cfg.continuous is False
    assert cfg.sync_interval_seconds == 15
    assert cfg.is_active is True


def test_is_active_requires_enabled_flag(tmp_path: Path):
    """``is_active`` requires ``enabled=True``. ``base_url`` now defaults to
    the production URL (v0.2.5), so a config with only ``enabled=true`` is
    active (base_url is the production endpoint).

    The old contract was: both enabled AND non-empty base_url required.
    The new contract is: enabled=True is sufficient — the production URL
    is the default when no explicit base_url is configured.
    """
    path = tmp_path / "config.toml"
    path.write_text("[cloud]\nenabled = true\n")
    cfg = load_cloud_config(config_path=path)
    assert cfg.enabled is True
    assert cfg.base_url == "https://api.haltonmeter.com"
    assert cfg.is_active is True  # v0.2.5: non-empty default URL → active
