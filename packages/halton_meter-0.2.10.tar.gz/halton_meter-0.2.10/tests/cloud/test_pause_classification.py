"""v0.2.8 — strict pause classification.

Asserts that ``run_once`` only writes ``paused_unauthorised`` on a real
HTTP 401 response, only writes ``paused_forbidden`` on a real 403, and
routes every other failure class through ``error_writer`` without
touching ``paused_reason``.

Background: the 2026-05-24 ALB rolling-deploy incident caused the
daemon to misclassify a connection reset (which httpx surfaces as
``RemoteProtocolError`` / ``CloudTransport``) as a 401, forcing the
user to re-pair. v0.2.8's contract is that only the actual on-wire
status code 401 from ``/v1/requests/batch`` triggers the
``paused_unauthorised`` state.
"""

from __future__ import annotations

import httpx
import pytest

from halton_meter.cloud import client as client_module
from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.worker import Cursor, run_once


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    async def _instant(_seconds: float) -> None:
        return None

    monkeypatch.setattr(client_module, "_sleep_with_jitter", _instant)


def _wire_record(idx: int) -> dict:
    return {
        "id": f"rec-{idx:04d}",
        "project": "demo",
        "provider": "anthropic",
        "model": "claude-sonnet-4",
        "input_tokens": 1,
        "output_tokens": 1,
        "thinking_tokens": 0,
        "cached_tokens": 0,
        "cache_write_tokens": None,
        "cost_millicents": 100,
        "cost_usd_minor_units": 100,
        "fx_rate": None,
        "tokens_complete": True,
        "latency_ms": 1.0,
        "time_to_first_token_ms": None,
        "requested_at": f"2026-05-10T12:00:{idx % 60:02d}Z",
        "recorded_at": f"2026-05-10T12:01:{idx % 60:02d}Z",
        "status": "success",
        "request_kind": "chat",
        "attribution_method": "env",
        "source_workdir": None,
        "source_machine": "host-1",
        "prompt_hash": None,
        "idempotency_key": None,
    }


class _Harness:
    """Bundle of writers for run_once's pause/error seams."""

    def __init__(self) -> None:
        self.pauses: list[str] = []
        self.errors: list[str] = []
        self.advanced: list[Cursor] = []

    async def pause_writer(self, reason: str) -> None:
        self.pauses.append(reason)

    async def error_writer(self, detail: str) -> None:
        self.errors.append(detail)

    async def cursor_advancer(self, cursor: Cursor) -> None:
        self.advanced.append(cursor)


def _make_loader(records: list[dict]):
    async def _loader(_cursor: Cursor, _limit: int) -> list[dict]:
        return records

    return _loader


async def _cursor_reader() -> Cursor:
    return Cursor.pristine()


async def _drive(transport: httpx.MockTransport, harness: _Harness):
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "tk",
    ) as c:
        return await run_once(
            c,
            cursor_reader=_cursor_reader,
            batch_loader=_make_loader([_wire_record(0)]),
            cursor_advancer=harness.cursor_advancer,
            pause_writer=harness.pause_writer,
            error_writer=harness.error_writer,
        )


# ---------------------------------------------------------------------- #
# Terminal: 401 → paused_unauthorised, 403 → paused_forbidden.
# ---------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_real_401_pauses_unauthorised():
    transport = httpx.MockTransport(
        lambda _r: httpx.Response(401, json={"detail": "bad key"})
    )
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is True
    assert h.pauses == ["paused_unauthorised"]
    assert h.errors == []
    assert h.advanced == []


@pytest.mark.asyncio
async def test_real_403_pauses_forbidden():
    transport = httpx.MockTransport(
        lambda _r: httpx.Response(403, json={"detail": "membership revoked"})
    )
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is True
    assert h.pauses == ["paused_forbidden"]
    assert h.errors == []
    assert h.advanced == []


# ---------------------------------------------------------------------- #
# Transient: 5xx / connection reset / read timeout / connect timeout /
# DNS failure / 429 / 422 — must NOT pause, must record last_error.
# ---------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_500_does_not_pause():
    transport = httpx.MockTransport(lambda _r: httpx.Response(500))
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors  # at least one transient error recorded
    assert "transport" in h.errors[0]


@pytest.mark.asyncio
async def test_502_does_not_pause():
    transport = httpx.MockTransport(lambda _r: httpx.Response(502))
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors


@pytest.mark.asyncio
async def test_503_does_not_pause():
    transport = httpx.MockTransport(lambda _r: httpx.Response(503))
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors


@pytest.mark.asyncio
async def test_remote_protocol_error_does_not_pause():
    """ALB-style connection reset → httpx.RemoteProtocolError → CloudTransport."""

    def handler(_r: httpx.Request) -> httpx.Response:
        raise httpx.RemoteProtocolError("Server disconnected without sending a response.")

    h = _Harness()
    result = await _drive(httpx.MockTransport(handler), h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors
    assert "transport" in h.errors[0]


@pytest.mark.asyncio
async def test_read_timeout_does_not_pause():
    def handler(_r: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("read timeout")

    h = _Harness()
    result = await _drive(httpx.MockTransport(handler), h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors


@pytest.mark.asyncio
async def test_connect_timeout_does_not_pause():
    def handler(_r: httpx.Request) -> httpx.Response:
        raise httpx.ConnectTimeout("connect timeout")

    h = _Harness()
    result = await _drive(httpx.MockTransport(handler), h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors


@pytest.mark.asyncio
async def test_connect_error_dns_does_not_pause():
    def handler(_r: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("Name or service not known")

    h = _Harness()
    result = await _drive(httpx.MockTransport(handler), h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors


@pytest.mark.asyncio
async def test_422_does_not_pause():
    """Malformed payload — log loud, keep syncing on the next tick."""
    transport = httpx.MockTransport(
        lambda _r: httpx.Response(422, json={"detail": "bad field"})
    )
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors
    assert "schema_mismatch" in h.errors[0]


@pytest.mark.asyncio
async def test_400_does_not_pause():
    transport = httpx.MockTransport(lambda _r: httpx.Response(400))
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors


@pytest.mark.asyncio
async def test_429_does_not_pause():
    transport = httpx.MockTransport(
        lambda _r: httpx.Response(429, headers={"retry-after": "1"})
    )
    h = _Harness()
    result = await _drive(transport, h)
    assert result.paused is False
    assert h.pauses == []
    assert h.errors
    assert "rate_limited" in h.errors[0]
