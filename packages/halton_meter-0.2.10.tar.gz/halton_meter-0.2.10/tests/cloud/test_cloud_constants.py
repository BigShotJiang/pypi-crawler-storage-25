"""v0.2.5 — cloud constants + official backend URL lock tests.

Tests for:
1. ``HALTON_METER_CLOUD_URL`` is set to the official production URL.
2. ``get_default_cloud_url()`` returns the production URL by default.
3. ``HALTON_METER_CLOUD_URL`` env var overrides the production constant.
4. ``load_cloud_config()`` uses the production URL as default when no
   [cloud].base_url is in config.toml.
5. An explicit [cloud].base_url in config.toml still takes precedence.
"""

from __future__ import annotations

import importlib
import os
import textwrap
from pathlib import Path

import pytest

PRODUCTION_URL = "https://api.haltonmeter.com"


def test_production_url_constant() -> None:
    """HALTON_METER_CLOUD_URL matches the agreed production URL."""
    import halton_meter.cloud.constants as _c

    env_bak = os.environ.pop("HALTON_METER_CLOUD_URL", None)
    try:
        importlib.reload(_c)
        assert _c.HALTON_METER_CLOUD_URL == PRODUCTION_URL
    finally:
        if env_bak is not None:
            os.environ["HALTON_METER_CLOUD_URL"] = env_bak
        importlib.reload(_c)


def test_get_default_cloud_url_returns_production(monkeypatch: pytest.MonkeyPatch) -> None:
    """get_default_cloud_url() returns the production URL when no env override."""
    monkeypatch.delenv("HALTON_METER_CLOUD_URL", raising=False)
    import halton_meter.cloud.constants as _c

    importlib.reload(_c)
    assert _c.get_default_cloud_url() == PRODUCTION_URL


def test_get_default_cloud_url_env_override(monkeypatch: pytest.MonkeyPatch) -> None:
    """HALTON_METER_CLOUD_URL env var overrides the production constant."""
    staging = "https://staging.api.haltonmeter.com"
    monkeypatch.setenv("HALTON_METER_CLOUD_URL", staging)
    import halton_meter.cloud.constants as _c

    importlib.reload(_c)
    assert _c.get_default_cloud_url() == staging


def test_load_cloud_config_defaults_to_production_url(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When config.toml has no [cloud] section, base_url is the production URL."""
    monkeypatch.delenv("HALTON_METER_CLOUD_URL", raising=False)
    import halton_meter.cloud.constants as _c

    importlib.reload(_c)

    config_file = tmp_path / "config.toml"
    config_file.write_text("[daemon]\nlisten_port = 8081\n")

    from halton_meter.cloud.config_glue import load_cloud_config

    cfg = load_cloud_config(config_path=config_file)
    assert cfg.base_url == PRODUCTION_URL


def test_load_cloud_config_explicit_base_url_wins(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An explicit [cloud].base_url in config.toml takes precedence over the default."""
    monkeypatch.delenv("HALTON_METER_CLOUD_URL", raising=False)
    import halton_meter.cloud.constants as _c

    importlib.reload(_c)

    explicit_url = "https://custom.api.haltonmeter.com"
    config_file = tmp_path / "config.toml"
    config_file.write_text(
        textwrap.dedent(f"""\
            [daemon]
            listen_port = 8081

            [cloud]
            base_url = "{explicit_url}"
            enabled = false
            """)
    )

    from halton_meter.cloud.config_glue import load_cloud_config

    cfg = load_cloud_config(config_path=config_file)
    assert cfg.base_url == explicit_url


def test_load_cloud_config_empty_base_url_in_toml_uses_default(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An explicit empty base_url in config.toml still uses the production default.

    This covers the migration case where a user's config.toml was generated
    before v0.2.5 and has ``base_url = ""``.
    """
    monkeypatch.delenv("HALTON_METER_CLOUD_URL", raising=False)
    import halton_meter.cloud.constants as _c

    importlib.reload(_c)

    config_file = tmp_path / "config.toml"
    config_file.write_text(
        textwrap.dedent("""\
            [cloud]
            base_url = ""
            enabled = false
            """)
    )

    from halton_meter.cloud.config_glue import load_cloud_config

    cfg = load_cloud_config(config_path=config_file)
    assert cfg.base_url == PRODUCTION_URL
