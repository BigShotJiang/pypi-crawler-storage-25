"""CLI smoke tests for ``halton-meter cloud privacy set``.

The set-command writes ``~/.halton-meter/config.toml``. We exercise the
internal helper directly so the test never touches the real home dir —
the helper is parameterised on Path semantics by monkey-patching the
expanduser default.

Coverage:
- preset round-trip
- global field override round-trip
- per-project upload toggle
- malformed value rejected
- TOML rewrite preserves other top-level sections
"""

from __future__ import annotations

from pathlib import Path

import pytest

from halton_meter.cli_cloud import (
    _apply_privacy_set,
    _parse_privacy_set_target,
    _PrivacySetError,
    _render_toml,
)
from halton_meter.cloud.config_glue import load_upload_policy
from halton_meter.cloud.privacy import UploadPreset


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ``Path('~/.halton-meter/...').expanduser()`` to a tmp dir.

    The CLI helper expands the path internally; patching ``HOME`` is the
    cleanest swap that survives `expanduser`. The returned path is the
    fake home root; the config file lands at ``<home>/.halton-meter/config.toml``.
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))  # Windows safety net
    return tmp_path


def _config_path(fake_home: Path) -> Path:
    return fake_home / ".halton-meter" / "config.toml"


# ─── target parsing ───────────────────────────────────────────────────────────


def test_parse_preset_target() -> None:
    assert _parse_privacy_set_target("preset") == ("preset", "")


def test_parse_field_target() -> None:
    assert _parse_privacy_set_target("field.source_workdir") == (
        "field",
        "source_workdir",
    )


def test_parse_upload_target() -> None:
    assert _parse_privacy_set_target("upload") == ("upload", "")


def test_parse_unknown_field_returns_none() -> None:
    assert _parse_privacy_set_target("field.future_field") is None


def test_parse_garbage_returns_none() -> None:
    assert _parse_privacy_set_target("foo.bar") is None


# ─── apply: preset ────────────────────────────────────────────────────────────


def test_apply_preset_writes_toml(fake_home: Path) -> None:
    _apply_privacy_set(kind="preset", name="", value="minimal", project=None)
    policy = load_upload_policy(config_path=_config_path(fake_home))
    assert policy.preset is UploadPreset.minimal


def test_apply_preset_rejects_unknown_value(fake_home: Path) -> None:
    with pytest.raises(_PrivacySetError):
        _apply_privacy_set(
            kind="preset", name="", value="paranoid", project=None
        )


def test_apply_preset_rejects_per_project_flag(fake_home: Path) -> None:
    with pytest.raises(_PrivacySetError):
        _apply_privacy_set(
            kind="preset", name="", value="minimal", project="alpha"
        )


# ─── apply: field ─────────────────────────────────────────────────────────────


def test_apply_global_field_override(fake_home: Path) -> None:
    _apply_privacy_set(
        kind="field", name="source_workdir", value="true", project=None
    )
    policy = load_upload_policy(config_path=_config_path(fake_home))
    assert policy.field_overrides == {"source_workdir": True}


def test_apply_per_project_field_override(fake_home: Path) -> None:
    _apply_privacy_set(
        kind="field",
        name="prompt_hash",
        value="false",
        project="client-x",
    )
    policy = load_upload_policy(config_path=_config_path(fake_home))
    assert policy.per_project["client-x"].fields == {"prompt_hash": False}
    assert policy.per_project["client-x"].upload is True


def test_apply_field_rejects_non_bool(fake_home: Path) -> None:
    with pytest.raises(_PrivacySetError):
        _apply_privacy_set(
            kind="field", name="source_workdir", value="maybe", project=None
        )


# ─── apply: upload ────────────────────────────────────────────────────────────


def test_apply_upload_false_for_project(fake_home: Path) -> None:
    _apply_privacy_set(
        kind="upload", name="", value="false", project="acme-secret"
    )
    policy = load_upload_policy(config_path=_config_path(fake_home))
    assert policy.per_project["acme-secret"].upload is False


def test_apply_upload_requires_project(fake_home: Path) -> None:
    with pytest.raises(_PrivacySetError):
        _apply_privacy_set(
            kind="upload", name="", value="false", project=None
        )


# ─── TOML preservation ────────────────────────────────────────────────────────


def test_rewrite_preserves_other_sections(fake_home: Path) -> None:
    """Writing [cloud.upload] does not stomp [storage] / [daemon]."""
    cfg = _config_path(fake_home)
    cfg.parent.mkdir(parents=True, exist_ok=True)
    cfg.write_text(
        """
[daemon]
edge_port = 9999

[storage]
db_path = "/tmp/halton-test.sqlite"
"""
    )
    _apply_privacy_set(
        kind="field", name="source_workdir", value="false", project=None
    )

    # After the write, the original sections must still be present.
    text = cfg.read_text()
    assert 'edge_port = 9999' in text
    assert '"/tmp/halton-test.sqlite"' in text
    assert "[cloud.upload" in text


def test_render_toml_handles_quoted_project_slug() -> None:
    """Project slugs with dots / dashes survive a round-trip via quoted keys."""
    data = {
        "cloud": {
            "upload": {
                "per_project": {
                    "client.with.dots": {"upload": False},
                    "vanilla-slug": {"upload": True},
                }
            }
        }
    }
    rendered = _render_toml(data)
    assert '"client.with.dots"' in rendered
    # Vanilla slug doesn't need quoting.
    assert "vanilla-slug" in rendered
