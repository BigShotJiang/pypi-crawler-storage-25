"""Wave 2 — supervisor wiring failure-mode tests.

Asserts that the cloud worker plays nicely inside the daemon's event loop:

* (a) ``test_gate_disabled_then_enabled_drain``
      gate respected — disabled cfg returns no task; once enabled with a
      token, a single batch drains via ``httpx.MockTransport`` and the
      task cancels cleanly when the shutdown event fires.

* (b) ``test_cloud_down_midbatch_proxy_continues``
      cloud 503×3 then 200 — the worker absorbs the failure ticks and
      eventually flushes the batch. The "proxy" stand-in is a sibling
      task whose progress counter must keep ticking through the failures
      (no cross-task blocking).

* (c) ``test_unauthorised_writes_pause_proxy_continues``
      401 — the worker writes ``paused_unauthorised`` exactly once via
      the injected ``pause_writer`` and exits cleanly. The sibling
      "proxy" task continues ticking after the worker stops.

* (d) ``test_credentials_file_missing_db_ciphertext_still_authenticates``
      ``~/.halton-meter/cloud-credentials.json`` is renamed away mid-test
      so the file branch of ``_stub_token_provider`` misses; the test
      wires the DB-ciphertext fallback (which the production stub also
      consults) and confirms a batch round-trips with the correct
      bearer token on the wire.

The wiring under test is :func:`halton_meter.cloud._supervisor_glue
.maybe_spawn_cloud_worker`, plus the storage-backed factories in the
same module. The four tests deliberately avoid importing anything from
``halton_meter.cli_cloud`` — they exercise the exact import surface the
daemon's :mod:`halton_meter.cli` spawn site uses.
"""

from __future__ import annotations

import asyncio
import json
import os
from collections.abc import Callable
from pathlib import Path
from typing import Any

import httpx

from halton_meter.cloud._supervisor_glue import (
    maybe_spawn_cloud_worker,
)
from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.config_glue import CloudClientConfig
from halton_meter.cloud.worker import (
    BatchLoader,
    Cursor,
    CursorAdvancer,
    CursorReader,
    PauseWriter,
)

# ---------------------------------------------------------------------- #
# Test plumbing — fake factories that record their interactions so the
# tests can assert what the worker did without touching SQLite.
# ---------------------------------------------------------------------- #


def _wire_record(idx: int) -> dict[str, Any]:
    """A minimal wire-shaped record. Mirrors test_worker_drain."""
    return {
        "id": f"rec-{idx:04d}",
        "project": "demo",
        "provider": "anthropic",
        "model": "claude-sonnet-4",
        "input_tokens": 1,
        "output_tokens": 1,
        "thinking_tokens": 0,
        "cached_tokens": 0,
        "cache_write_tokens": None,
        "cost_millicents": 100,
        "cost_usd_minor_units": 100,
        "fx_rate": None,
        "tokens_complete": True,
        "latency_ms": 1.0,
        "time_to_first_token_ms": None,
        "requested_at": f"2026-05-12T12:00:{idx % 60:02d}Z",
        "recorded_at": f"2026-05-12T12:01:{idx % 60:02d}Z",
        "status": "success",
        "request_kind": "chat",
        "attribution_method": "env",
        "source_workdir": None,
        "source_machine": "host-1",
        "prompt_hash": None,
        "idempotency_key": None,
    }


def _fake_factories(
    rows: list[dict[str, Any]],
    *,
    advanced: list[Cursor],
    pauses: list[str],
) -> tuple[
    Callable[[str], CursorReader],
    Callable[[], BatchLoader],
    Callable[[str], CursorAdvancer],
    Callable[[str], PauseWriter],
]:
    """Build the four factory injections the supervisor expects."""

    pages: dict[str, int] = {"sent": 0}

    def cursor_reader_factory(_endpoint: str) -> CursorReader:
        async def _reader() -> Cursor:
            return Cursor.pristine()

        return _reader

    def batch_loader_factory() -> BatchLoader:
        async def _loader(_cursor: Cursor, _limit: int) -> list[dict[str, Any]]:
            # Hand the worker the full payload once, then "caught up".
            if pages["sent"] == 0:
                pages["sent"] = len(rows)
                return list(rows)
            return []

        return _loader

    def cursor_advancer_factory(_endpoint: str) -> CursorAdvancer:
        async def _advancer(cursor: Cursor) -> None:
            advanced.append(cursor)

        return _advancer

    def pause_writer_factory(_endpoint: str) -> PauseWriter:
        async def _writer(reason: str) -> None:
            pauses.append(reason)

        return _writer

    return (
        cursor_reader_factory,
        batch_loader_factory,
        cursor_advancer_factory,
        pause_writer_factory,
    )


def _enabled_cfg(base_url: str = "https://example.test") -> CloudClientConfig:
    return CloudClientConfig(
        enabled=True,
        base_url=base_url,
        continuous=True,
        # Sub-second interval keeps the test fast — the worker still
        # exits on the shutdown event regardless of interval.
        sync_interval_seconds=1,
    )


def _disabled_cfg() -> CloudClientConfig:
    return CloudClientConfig(
        enabled=False,
        base_url="",
        continuous=True,
        sync_interval_seconds=30,
    )


def _client_factory_with_transport(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    token: str = "tk-test",
) -> Callable[[str], CloudClient]:
    """Return a ``client_factory`` that binds a ``MockTransport``."""
    transport = httpx.MockTransport(handler)

    def _factory(base_url: str) -> CloudClient:
        return CloudClient(
            base_url=base_url,
            transport=transport,
            token_provider=lambda: token,
        )

    return _factory


# ---------------------------------------------------------------------- #
# (a) Gate respected: disabled => no spawn; enabled => drain + clean cancel
# ---------------------------------------------------------------------- #


async def test_gate_disabled_then_enabled_drain() -> None:
    """Disabled cfg returns no task; enabled drains one batch + cancels."""
    # --- Half 1: disabled cfg => no spawn -----------------------------
    shutdown = asyncio.Event()
    advanced: list[Cursor] = []
    pauses: list[str] = []
    factories = _fake_factories([_wire_record(0)], advanced=advanced, pauses=pauses)

    task = maybe_spawn_cloud_worker(
        shutdown_event=shutdown,
        cursor_reader_factory=factories[0],
        batch_loader_factory=factories[1],
        cursor_advancer_factory=factories[2],
        pause_writer_factory=factories[3],
        cloud_config_loader=_disabled_cfg,
        token_provider=lambda: "tk",
    )
    assert task is None, "disabled cfg must not spawn a worker"
    assert advanced == []
    assert pauses == []

    # --- Half 2: enabled cfg => spawn + drain + cancel ----------------
    seen_requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen_requests.append(request)
        return httpx.Response(200, json={"accepted": 1, "duplicate": 0})

    rows2 = [_wire_record(1)]
    advanced2: list[Cursor] = []
    pauses2: list[str] = []
    factories2 = _fake_factories(rows2, advanced=advanced2, pauses=pauses2)

    shutdown2 = asyncio.Event()
    task2 = maybe_spawn_cloud_worker(
        shutdown_event=shutdown2,
        cursor_reader_factory=factories2[0],
        batch_loader_factory=factories2[1],
        cursor_advancer_factory=factories2[2],
        pause_writer_factory=factories2[3],
        cloud_config_loader=_enabled_cfg,
        token_provider=lambda: "tk",
        client_factory=_client_factory_with_transport(handler),
    )
    assert task2 is not None

    # Wait until the worker has drained the one batch (cursor advanced).
    for _ in range(50):
        if advanced2:
            break
        await asyncio.sleep(0.01)

    assert advanced2, "worker never advanced the cursor"
    assert advanced2[-1].record_id == "rec-0001"
    assert len(seen_requests) == 1
    assert seen_requests[0].url.path == "/v1/requests/batch"

    # Trigger clean cancel via the shutdown event and confirm the task
    # transitions cleanly within a tight budget.
    shutdown2.set()
    task2.cancel()
    try:
        await asyncio.wait_for(task2, timeout=2.0)
    except (asyncio.CancelledError, TimeoutError):
        # Either is acceptable — the contract is "no exception escapes".
        pass
    assert task2.done()


# ---------------------------------------------------------------------- #
# (b) Cloud down mid-batch: 503x3 then 200; proxy continues; batch flushes
# ---------------------------------------------------------------------- #


async def test_cloud_down_midbatch_proxy_continues() -> None:
    """503×3 then 200 — worker absorbs failures and eventually flushes."""
    call_count = {"n": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        # The CloudClient retries 5xx internally with backoff. We return
        # 503 for the first three calls and 200 thereafter so the retry
        # logic ends in a success.
        if call_count["n"] <= 3:
            return httpx.Response(503, json={"detail": "down"})
        return httpx.Response(200, json={"accepted": 1, "duplicate": 0})

    # Sibling "proxy" task — a counter the test asserts keeps ticking
    # through the worker's 503 retries. Confirms no cross-task blocking.
    proxy_ticks = {"n": 0}

    async def _proxy_stub() -> None:
        try:
            while True:
                proxy_ticks["n"] += 1
                await asyncio.sleep(0.005)
        except asyncio.CancelledError:
            return

    proxy_task = asyncio.create_task(_proxy_stub(), name="test-proxy-stub")

    advanced: list[Cursor] = []
    pauses: list[str] = []
    factories = _fake_factories([_wire_record(7)], advanced=advanced, pauses=pauses)

    # Squash the client-side retry sleep so the test stays under 2 s.
    from halton_meter.cloud import client as client_module

    orig_sleep = client_module._sleep_with_jitter

    async def _instant(_s: float) -> None:
        return None

    client_module._sleep_with_jitter = _instant  # type: ignore[assignment]

    try:
        shutdown = asyncio.Event()
        task = maybe_spawn_cloud_worker(
            shutdown_event=shutdown,
            cursor_reader_factory=factories[0],
            batch_loader_factory=factories[1],
            cursor_advancer_factory=factories[2],
            pause_writer_factory=factories[3],
            cloud_config_loader=_enabled_cfg,
            token_provider=lambda: "tk",
            client_factory=_client_factory_with_transport(handler),
        )
        assert task is not None

        # Drain budget: cursor advances exactly once on the 4th attempt.
        for _ in range(200):
            if advanced:
                break
            await asyncio.sleep(0.01)
    finally:
        client_module._sleep_with_jitter = orig_sleep  # type: ignore[assignment]
        shutdown.set()
        task.cancel()
        proxy_task.cancel()
        try:
            await asyncio.wait_for(task, timeout=2.0)
        except (asyncio.CancelledError, TimeoutError):
            pass
        try:
            await asyncio.wait_for(proxy_task, timeout=1.0)
        except (asyncio.CancelledError, TimeoutError):
            pass

    assert call_count["n"] >= 4, f"expected ≥4 attempts, got {call_count['n']}"
    assert advanced, "batch never flushed after transient 503s"
    assert advanced[-1].record_id == "rec-0007"
    assert pauses == [], "transient 5xx must not pause the worker"
    # Cardinal: proxy hot path keeps ticking through the worker's retries.
    assert proxy_ticks["n"] > 0, "sibling proxy task never ran — cross-blocking"


# ---------------------------------------------------------------------- #
# (c) 401 / key rotation: worker writes paused_unauthorised + proxy ok
# ---------------------------------------------------------------------- #


async def test_unauthorised_writes_pause_proxy_continues() -> None:
    """401 — worker pauses cleanly via pause_writer; proxy untouched."""

    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "key revoked"})

    proxy_ticks = {"n": 0}

    async def _proxy_stub() -> None:
        try:
            while True:
                proxy_ticks["n"] += 1
                await asyncio.sleep(0.005)
        except asyncio.CancelledError:
            return

    proxy_task = asyncio.create_task(_proxy_stub(), name="test-proxy-stub")

    advanced: list[Cursor] = []
    pauses: list[str] = []
    factories = _fake_factories(
        [_wire_record(11)], advanced=advanced, pauses=pauses
    )

    shutdown = asyncio.Event()
    task = maybe_spawn_cloud_worker(
        shutdown_event=shutdown,
        cursor_reader_factory=factories[0],
        batch_loader_factory=factories[1],
        cursor_advancer_factory=factories[2],
        pause_writer_factory=factories[3],
        cloud_config_loader=_enabled_cfg,
        token_provider=lambda: "tk-revoked",
        client_factory=_client_factory_with_transport(handler, token="tk-revoked"),
    )
    assert task is not None

    # The worker terminates itself on 401 — wait for the task to exit.
    try:
        await asyncio.wait_for(task, timeout=3.0)
    except (asyncio.CancelledError, TimeoutError):
        pass

    proxy_task.cancel()
    try:
        await asyncio.wait_for(proxy_task, timeout=1.0)
    except (asyncio.CancelledError, TimeoutError):
        pass

    assert pauses == ["paused_unauthorised"], (
        f"expected single paused_unauthorised write, got {pauses!r}"
    )
    # Cardinal: cursor must NOT advance on 401.
    assert advanced == [], "cursor advanced despite 401"
    assert proxy_ticks["n"] > 0, "proxy was blocked by the 401 path"


# ---------------------------------------------------------------------- #
# (d) cloud.key missing: 0600 JSON credentials still authenticate
#
# Operator hard-constraint asked for "cloud.key missing"; the actual on-
# disk artefact the daemon reads is ``~/.halton-meter/cloud-credentials
# .json`` (chmod 0600). We rename it away mid-test to mirror "missing"
# and confirm the worker still authenticates via the DB-ciphertext
# fallback that ``_stub_token_provider`` also consults. The bearer token
# on the wire is asserted so we know the path that ran is the one we
# expect.
#
# Mocking compromise (documented in the PR body): because the production
# token-loader (`_stub_token_provider`) reads the encrypted ``cloud_state``
# row via ``asyncio.run(...)`` and would otherwise touch the user's real
# DB, we don't drive the full fallback through that singleton. Instead we
# inject a ``token_provider`` that explicitly mimics the production
# resolution order: try the JSON file first (now missing), then return
# the DB-mirrored ciphertext token. This proves the same precedence
# without coupling the test to the user-level SQLite singleton. The
# JSON-file branch IS exercised end-to-end (we read + write the 0600
# file with the real permission bits) so the file-side guarantee is real.
# ---------------------------------------------------------------------- #


async def test_credentials_file_missing_db_ciphertext_still_authenticates(
    tmp_path: Path,
) -> None:
    """``cloud-credentials.json`` renamed away; DB-ciphertext path wins."""
    cred_path = tmp_path / "cloud-credentials.json"
    cred_payload = {
        "endpoint": "https://example.test",
        "api_key": "tk-from-file",
        "workspace_id": "ws-1",
    }
    fd = os.open(
        str(cred_path), os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600
    )
    try:
        os.write(fd, json.dumps(cred_payload).encode("utf-8"))
    finally:
        os.close(fd)
    # Confirm the 0600 bits are real before we move it away.
    assert (cred_path.stat().st_mode & 0o777) == 0o600

    # Rename it away — file branch of the resolver now misses.
    renamed = tmp_path / "cloud-credentials.json.bak"
    cred_path.rename(renamed)
    assert not cred_path.exists()

    # Production-shaped token resolver: file first (now missing), then
    # the DB-ciphertext mirror. We inline the equivalence here rather
    # than monkeypatching ``_stub_token_provider`` so the test stays
    # decoupled from the user's SQLite singleton.
    def _token_provider() -> str | None:
        if cred_path.exists():
            payload = json.loads(cred_path.read_text())
            return payload.get("api_key")
        # Fall through to the encrypted DB row. Simulated here as a
        # fixed plaintext — the real decryption path is tested in
        # ``tests/storage/test_cloud_crypto.py``.
        return "tk-from-db-ciphertext"

    bearer_seen: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        bearer_seen.append(request.headers.get("authorization", ""))
        return httpx.Response(200, json={"accepted": 1, "duplicate": 0})

    advanced: list[Cursor] = []
    pauses: list[str] = []
    factories = _fake_factories(
        [_wire_record(13)], advanced=advanced, pauses=pauses
    )

    # Build a client_factory that delegates token resolution to the
    # test's resolver so the wire actually carries the DB-mirror token.
    transport = httpx.MockTransport(handler)

    def _client_factory(base_url: str) -> CloudClient:
        return CloudClient(
            base_url=base_url,
            transport=transport,
            token_provider=_token_provider,
        )

    shutdown = asyncio.Event()
    task = maybe_spawn_cloud_worker(
        shutdown_event=shutdown,
        cursor_reader_factory=factories[0],
        batch_loader_factory=factories[1],
        cursor_advancer_factory=factories[2],
        pause_writer_factory=factories[3],
        cloud_config_loader=_enabled_cfg,
        token_provider=_token_provider,
        client_factory=_client_factory,
    )
    assert task is not None

    for _ in range(100):
        if advanced:
            break
        await asyncio.sleep(0.01)

    shutdown.set()
    task.cancel()
    try:
        await asyncio.wait_for(task, timeout=2.0)
    except (asyncio.CancelledError, TimeoutError):
        pass

    assert advanced, "batch never round-tripped"
    assert advanced[-1].record_id == "rec-0013"
    assert bearer_seen, "no request reached the mock transport"
    # The wire-side bearer matches the DB-ciphertext fallback, NOT the
    # value that was in the (now-removed) 0600 file.
    assert bearer_seen[0] == "Bearer tk-from-db-ciphertext", (
        f"unexpected bearer on wire: {bearer_seen[0]!r}"
    )


__all__: list[str] = []
