"""Smoke tests for the ``cloud._render`` helpers.

These don't assert on Rich's exact terminal output — Rich's styling escape
sequences are noisy. We just confirm that:

  - Renderers don't crash on the shapes the CLI hands them.
  - Banner choice reflects the expected state (string contains assertions).
  - Variance arithmetic in the reconcile renderer is correct.
"""

from __future__ import annotations

import io

from rich.console import Console

from halton_meter.cloud._render import (
    render_paired,
    render_pairing_code,
    render_reconcile,
    render_status,
    render_whoami,
)


def _capture(width: int = 100) -> Console:
    """Build a Console that captures into a StringIO so tests can read."""
    return Console(file=io.StringIO(), width=width, force_terminal=False, no_color=True)


# ─── render_status ───────────────────────────────────────────────────────────


def test_status_not_configured() -> None:
    c = _capture()
    render_status(c, {"base_url": None, "enabled": False, "is_active": False})
    out = c.file.getvalue()
    assert "NOT CONFIGURED" in out
    assert "cloud connect" in out


def test_status_active_with_workspace() -> None:
    c = _capture()
    render_status(
        c,
        {
            "base_url": "https://cloud.example.com",
            "enabled": True,
            "continuous": True,
            "sync_interval_seconds": 30,
            "is_active": True,
            "workspace_id": "ws-1",
            "workspace_name": "Personal",
            "machine_id": "f2ebe7df-7605-4a7d-814a-ba25d0794e94",
            "paused_reason": None,
            "last_error": None,
            "last_synced_request_recorded_at": None,
            "last_batch_succeeded_at": None,
            "consecutive_failures": 0,
            "unsynced_record_count": 0,
        },
    )
    out = c.file.getvalue()
    assert "ACTIVE" in out
    assert "Personal" in out
    assert "https://cloud.example.com" in out
    assert "f2ebe7df" in out  # truncated machine id


def test_status_paused_unauthorised_is_red_banner() -> None:
    c = _capture()
    render_status(
        c,
        {
            "base_url": "https://cloud.example.com",
            "is_active": True,
            "paused_reason": "paused_unauthorised",
        },
    )
    out = c.file.getvalue()
    assert "UNAUTHORISED" in out
    assert "cloud connect" in out


def test_status_paused_manual_suggests_resume() -> None:
    c = _capture()
    render_status(
        c,
        {
            "base_url": "https://cloud.example.com",
            "is_active": True,
            "paused_reason": "paused_manual",
        },
    )
    out = c.file.getvalue()
    assert "PAUSED (manual)" in out
    assert "cloud resume" in out


def test_status_degraded_after_three_failures() -> None:
    c = _capture()
    render_status(
        c,
        {
            "base_url": "https://cloud.example.com",
            "is_active": True,
            "consecutive_failures": 5,
            "last_error": "connection refused",
        },
    )
    out = c.file.getvalue()
    assert "DEGRADED" in out
    assert "5" in out


# ─── render_whoami ───────────────────────────────────────────────────────────


def test_whoami_renders_known_labels() -> None:
    c = _capture()
    render_whoami(
        c,
        {
            "workspace_name": "Personal",
            "workspace_id": "ws-1",
            "machine_id": "machine-uuid",
            "hostname": "macbook.local",
        },
    )
    out = c.file.getvalue()
    assert "Workspace" in out
    assert "Personal" in out
    assert "machine-uuid" in out
    assert "macbook.local" in out


def test_whoami_surfaces_unknown_keys() -> None:
    """Future field additions show up without a daemon rebuild."""
    c = _capture()
    render_whoami(c, {"future_field": "future-value"})
    out = c.file.getvalue()
    assert "future_field" in out
    assert "future-value" in out


# ─── render_reconcile ────────────────────────────────────────────────────────


def test_reconcile_empty_renders_warning_panel() -> None:
    c = _capture()
    render_reconcile(c, {"rows": []})
    out = c.file.getvalue()
    assert "No reconcilable rows" in out


def test_reconcile_renders_table_and_total() -> None:
    c = _capture(width=140)
    payload = {
        "rows": [
            {
                "project": "alpha",
                "date": "2026-05-12",
                "request_count": 100,
                "prompt_tokens": 1000,
                "completion_tokens": 500,
                "cost_usd_minor_units": 5_000_000,  # millicents = $50
            },
        ],
    }
    render_reconcile(c, payload)
    out = c.file.getvalue()
    assert "alpha" in out
    assert "2026-05-12" in out
    assert "$50" in out
    assert "100" in out


def test_reconcile_variance_zero_is_green_check() -> None:
    c = _capture(width=140)
    payload = {
        "rows": [
            {
                "project": "alpha",
                "date": "2026-05-12",
                "request_count": 10,
                "prompt_tokens": 100,
                "completion_tokens": 50,
                "cost_usd_minor_units": 1_000_000,  # $10
            },
        ],
    }
    render_reconcile(c, payload, daemon_total_millicents=1_000_000)
    out = c.file.getvalue()
    assert "Variance" in out
    assert "0.00%" in out


def test_reconcile_variance_nonzero_shows_signed_delta() -> None:
    c = _capture(width=140)
    payload = {
        "rows": [
            {
                "project": "alpha",
                "date": "2026-05-12",
                "request_count": 10,
                "prompt_tokens": 100,
                "completion_tokens": 50,
                "cost_usd_minor_units": 800_000,  # cloud says $8
            },
        ],
    }
    render_reconcile(c, payload, daemon_total_millicents=1_000_000)  # daemon says $10
    out = c.file.getvalue()
    assert "Variance" in out
    # Delta is cloud - daemon = -$2 → negative percent
    assert "-2" in out  # appears in $-2.0000 and -20.0000%
    assert "investigate" in out  # >0.5% triggers the red "investigate" copy


# ─── render_pairing_code + render_paired ─────────────────────────────────────


def test_pairing_code_panel_contains_code_and_url() -> None:
    c = _capture()
    render_pairing_code(
        c, code="XK4M-9P2A", pairing_url="https://cloud.example.com/connect?code=XK4M-9P2A"
    )
    out = c.file.getvalue()
    assert "XK4M-9P2A" in out
    assert "https://cloud.example.com/connect?code=XK4M-9P2A" in out


def test_paired_renders_workspace_and_machine() -> None:
    c = _capture()
    render_paired(c, workspace_name="Personal", machine_id="machine-uuid")
    out = c.file.getvalue()
    assert "Paired" in out
    assert "Personal" in out
    assert "machine-uuid" in out
