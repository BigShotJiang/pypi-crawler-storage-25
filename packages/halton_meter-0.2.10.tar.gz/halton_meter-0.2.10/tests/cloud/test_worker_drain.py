"""Worker drain + cursor advancement + 401 pause.

Asserts that:
- The cursor advances ONLY on a fully-successful batch ACK.
- A 401 triggers ``paused_unauthorised`` and stops the loop.
- Caught-up state is detected when the loader returns a short page.
"""

from __future__ import annotations

import httpx
import pytest

from halton_meter.cloud import client as client_module
from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.worker import Cursor, run_once


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    async def _instant(_seconds: float) -> None:
        return None

    monkeypatch.setattr(client_module, "_sleep_with_jitter", _instant)


def _wire_record(idx: int) -> dict:
    return {
        "id": f"rec-{idx:04d}",
        "project": "demo",
        "provider": "anthropic",
        "model": "claude-sonnet-4",
        "input_tokens": 1,
        "output_tokens": 1,
        "thinking_tokens": 0,
        "cached_tokens": 0,
        "cache_write_tokens": None,
        "cost_millicents": 100,
        "cost_usd_minor_units": 100,
        "fx_rate": None,
        "tokens_complete": True,
        "latency_ms": 1.0,
        "time_to_first_token_ms": None,
        "requested_at": f"2026-05-10T12:00:{idx % 60:02d}Z",
        "recorded_at": f"2026-05-10T12:01:{idx % 60:02d}Z",
        "status": "success",
        "request_kind": "chat",
        "attribution_method": "env",
        "source_workdir": None,
        "source_machine": "host-1",
        "prompt_hash": None,
        "idempotency_key": None,
    }


@pytest.mark.asyncio
async def test_drain_advances_cursor_only_on_success():
    """Happy path: three batches of 2 + a trailing partial page."""

    def handler(request: httpx.Request) -> httpx.Response:
        # Cloud ACK is fixed — the test cares about cursor advancement.
        return httpx.Response(200, json={"accepted": 2, "duplicate": 0})

    transport = httpx.MockTransport(handler)

    rows = [_wire_record(i) for i in range(5)]
    pages: list[list[dict]] = []

    async def cursor_reader() -> Cursor:
        return Cursor.pristine()

    async def batch_loader(cursor: Cursor, limit: int) -> list[dict]:
        # First two pages full (2 rows each), third page partial (1 row).
        start = len(pages) * 2
        page = rows[start : start + 2]
        pages.append(page)
        return page

    advanced: list[Cursor] = []

    async def cursor_advancer(cursor: Cursor) -> None:
        advanced.append(cursor)

    async def pause_writer(reason: str) -> None:
        raise AssertionError(f"unexpected pause: {reason}")

    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "tk",
    ) as c:
        result = await run_once(
            c,
            cursor_reader=cursor_reader,
            batch_loader=batch_loader,
            cursor_advancer=cursor_advancer,
            pause_writer=pause_writer,
            batch_size=2,
        )

    # 2 full pages of 2 + 1 partial page of 1 = 3 successful batches.
    assert result.batches_sent == 3
    assert result.records_sent == 5
    assert result.caught_up is True
    # Cursor advanced exactly 3 times (one per successful batch); last
    # cursor matches the last row written.
    assert len(advanced) == 3
    assert advanced[-1].record_id == "rec-0004"


@pytest.mark.asyncio
async def test_401_writes_pause_and_stops_without_advancing():
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "bad key"})

    transport = httpx.MockTransport(handler)

    async def cursor_reader() -> Cursor:
        return Cursor.pristine()

    async def batch_loader(_cursor: Cursor, _limit: int) -> list[dict]:
        return [_wire_record(0)]

    advanced: list[Cursor] = []

    async def cursor_advancer(cursor: Cursor) -> None:
        advanced.append(cursor)

    pauses: list[str] = []

    async def pause_writer(reason: str) -> None:
        pauses.append(reason)

    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "tk",
    ) as c:
        result = await run_once(
            c,
            cursor_reader=cursor_reader,
            batch_loader=batch_loader,
            cursor_advancer=cursor_advancer,
            pause_writer=pause_writer,
        )

    assert result.paused is True
    assert result.batches_sent == 0
    # Cardinal rule: no advance on failure.
    assert advanced == []
    assert pauses == ["paused_unauthorised"]


@pytest.mark.asyncio
async def test_drain_no_rows_is_caught_up():
    transport = httpx.MockTransport(lambda r: httpx.Response(200, json={}))

    async def cursor_reader() -> Cursor:
        return Cursor.pristine()

    async def batch_loader(_cursor: Cursor, _limit: int) -> list[dict]:
        return []

    async def cursor_advancer(_cursor: Cursor) -> None:
        raise AssertionError("must not advance on empty drain")

    async def pause_writer(_reason: str) -> None:
        raise AssertionError("must not pause on empty drain")

    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "tk",
    ) as c:
        result = await run_once(
            c,
            cursor_reader=cursor_reader,
            batch_loader=batch_loader,
            cursor_advancer=cursor_advancer,
            pause_writer=pause_writer,
        )

    assert result.caught_up is True
    assert result.batches_sent == 0
    assert result.records_sent == 0
