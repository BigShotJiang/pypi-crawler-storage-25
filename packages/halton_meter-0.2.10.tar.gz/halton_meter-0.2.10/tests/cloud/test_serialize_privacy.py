"""Integration tests for the privacy redaction at the serializer boundary.

Proves that ``log_record_to_wire`` honours an ``upload_policy`` arg:

* ``None`` policy preserves the pre-privacy contract (every field travels).
* ``standard`` preset nulls ``source_workdir`` on the wire dict.
* Per-project ``upload=false`` returns ``None`` so the supervisor skips the
  record entirely (no partial-leak risk).
"""

from __future__ import annotations

from decimal import Decimal

from halton_meter.cloud.privacy import (
    ProjectRule,
    UploadPolicy,
    UploadPreset,
)
from halton_meter.cloud.serialize import log_record_to_wire
from halton_meter.models import LogRecord


def _make_record(project: str = "alpha") -> LogRecord:
    """Build a LogRecord with every gateable field populated."""
    return LogRecord(
        id="rec-0001",
        project=project,
        provider="anthropic",
        model="claude-sonnet-4-6",
        input_tokens=100,
        output_tokens=50,
        thinking_tokens=10,
        cache_read_tokens=0,
        cache_write_tokens=0,
        cost_millicents=42_000,
        fx_rate=Decimal("0.79"),
        tokens_complete=True,
        latency_ms=1234.5,
        requested_at="2026-05-12T10:00:00Z",
        recorded_at="2026-05-12T10:00:01Z",
        status="success",
        attribution_method="env",
        source_workdir="/Users/dev/secret-client/project",
    )


def test_no_policy_preserves_all_fields() -> None:
    """Backward-compat: callers that don't pass a policy see no redaction."""
    record = _make_record()
    wire = log_record_to_wire(record, source_machine="mac.local")
    assert wire is not None
    assert wire["source_workdir"] == "/Users/dev/secret-client/project"
    assert wire["source_machine"] == "mac.local"
    assert wire["project"] == "alpha"


def test_standard_policy_nulls_workdir() -> None:
    """v0.2.0 default — workdir is the highest-leak field and is off."""
    record = _make_record()
    wire = log_record_to_wire(
        record,
        source_machine="mac.local",
        upload_policy=UploadPolicy(preset=UploadPreset.standard),
    )
    assert wire is not None
    assert wire["source_workdir"] is None
    # Other standard-preset fields kept.
    assert wire["source_machine"] == "mac.local"
    assert wire["project"] == "alpha"
    assert wire["prompt_hash"] is None or "prompt_hash" in wire  # field shape


def test_minimal_policy_drops_project_and_hostname() -> None:
    """Minimal preset is the maximum-paranoia option for this user-base."""
    record = _make_record()
    wire = log_record_to_wire(
        record,
        source_machine="mac.local",
        upload_policy=UploadPolicy(preset=UploadPreset.minimal),
    )
    assert wire is not None
    assert wire["project"] is None
    assert wire["source_machine"] is None
    assert wire["source_workdir"] is None
    # Operational metadata still travels.
    assert wire["model"] == "claude-sonnet-4-6"
    assert wire["input_tokens"] == 100
    assert wire["cost_millicents"] == 42_000


def test_per_project_upload_false_returns_none() -> None:
    """A skipped project produces a None payload so the supervisor drops it."""
    record = _make_record(project="acme-secret")
    wire = log_record_to_wire(
        record,
        source_machine="mac.local",
        upload_policy=UploadPolicy(
            preset=UploadPreset.standard,
            per_project={"acme-secret": ProjectRule(upload=False)},
        ),
    )
    assert wire is None


def test_per_project_field_override_locks_down_one_project() -> None:
    """Project-level field rules apply only to the named project."""
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        per_project={
            "client-x": ProjectRule(
                upload=True,
                fields={"prompt_hash": False, "source_machine": False},
            )
        },
    )
    wire_x = log_record_to_wire(
        _make_record(project="client-x"),
        source_machine="mac.local",
        upload_policy=policy,
    )
    wire_alpha = log_record_to_wire(
        _make_record(project="alpha"),
        source_machine="mac.local",
        upload_policy=policy,
    )
    assert wire_x is not None
    assert wire_alpha is not None
    # client-x is locked down.
    assert wire_x["source_machine"] is None
    # alpha gets the standard-preset shape.
    assert wire_alpha["source_machine"] == "mac.local"


def test_global_override_can_force_workdir_back_on_top_of_standard() -> None:
    """An operator who actively wants workdir can flip it without changing preset."""
    record = _make_record()
    policy = UploadPolicy(
        preset=UploadPreset.standard,
        field_overrides={"source_workdir": True},
    )
    wire = log_record_to_wire(
        record, source_machine="mac.local", upload_policy=policy
    )
    assert wire is not None
    assert wire["source_workdir"] == "/Users/dev/secret-client/project"
