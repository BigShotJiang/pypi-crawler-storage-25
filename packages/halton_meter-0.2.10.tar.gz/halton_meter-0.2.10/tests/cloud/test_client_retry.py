"""Retry policy on the cloud client.

- 5xx → retry with exponential backoff.
- 429 → retry honouring ``Retry-After``.
- 401 → ``CloudUnauthorised``, no retry.
- 4xx other → ``CloudSchemaMismatch``, no retry.
- Transport error → retry with exponential backoff.

Backoff is monkeypatched to a no-op so the suite stays fast.
"""

from __future__ import annotations

import httpx
import pytest

from halton_meter.cloud import client as client_module
from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.errors import (
    CloudRateLimited,
    CloudSchemaMismatch,
    CloudTransport,
    CloudUnauthorised,
)


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    async def _instant(_seconds: float) -> None:
        return None

    monkeypatch.setattr(client_module, "_sleep_with_jitter", _instant)


async def _post_minimal(client: CloudClient) -> dict:
    return await client.batch_ingest(batch_id="b1", records=[])


@pytest.mark.asyncio
async def test_5xx_retries_then_succeeds():
    calls: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(1)
        if len(calls) < 3:
            return httpx.Response(503, text="busy")
        return httpx.Response(200, json={"accepted": 0, "duplicate": 0})

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "hm_sync_test",
    ) as c:
        result = await _post_minimal(c)

    assert len(calls) == 3
    assert result == {"accepted": 0, "duplicate": 0}


@pytest.mark.asyncio
async def test_5xx_exhausts_then_raises_transport():
    """All retries 5xx → terminal CloudTransport with status preserved."""

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(503)

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "hm_sync_test",
    ) as c:
        try:
            client_module.MAX_RETRIES = 2
            with pytest.raises(CloudTransport) as exc_info:
                await _post_minimal(c)
        finally:
            client_module.MAX_RETRIES = 8
    assert exc_info.value.status_code == 503


@pytest.mark.asyncio
async def test_429_honours_retry_after():
    calls: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(1)
        if len(calls) == 1:
            return httpx.Response(429, headers={"retry-after": "0"})
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "hm_sync_test",
    ) as c:
        result = await _post_minimal(c)
    assert result == {"ok": True}
    assert len(calls) == 2


@pytest.mark.asyncio
async def test_429_exhaust_raises_rate_limited():
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(429, headers={"retry-after": "1"})

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "hm_sync_test",
    ) as c:
        try:
            client_module.MAX_RETRIES = 1
            with pytest.raises(CloudRateLimited) as exc_info:
                await _post_minimal(c)
        finally:
            client_module.MAX_RETRIES = 8
    assert exc_info.value.retry_after_seconds == 1.0


@pytest.mark.asyncio
async def test_401_no_retry_raises_unauthorised():
    calls: list[int] = []

    def handler(_: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(401, json={"detail": "bad key"})

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "hm_sync_test",
    ) as c:
        with pytest.raises(CloudUnauthorised):
            await _post_minimal(c)
    # Single call — no retry on 401.
    assert calls == [1]


@pytest.mark.asyncio
async def test_400_raises_schema_mismatch_no_retry():
    calls: list[int] = []

    def handler(_: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(422, text="bad shape")

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "hm_sync_test",
    ) as c:
        with pytest.raises(CloudSchemaMismatch) as exc_info:
            await _post_minimal(c)
    assert calls == [1]
    assert exc_info.value.status_code == 422


@pytest.mark.asyncio
async def test_missing_token_raises_before_wire():
    transport = httpx.MockTransport(lambda r: httpx.Response(200, json={}))
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: None,
    ) as c:
        with pytest.raises(CloudUnauthorised):
            await c.whoami()


@pytest.mark.asyncio
async def test_transport_error_retries_then_succeeds():
    state = {"calls": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        state["calls"] += 1
        if state["calls"] < 2:
            raise httpx.ConnectError("boom", request=request)
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    async with CloudClient(
        base_url="https://example.test",
        transport=transport,
        token_provider=lambda: "hm_sync_test",
    ) as c:
        result = await _post_minimal(c)
    assert result == {"ok": True}
    assert state["calls"] == 2
