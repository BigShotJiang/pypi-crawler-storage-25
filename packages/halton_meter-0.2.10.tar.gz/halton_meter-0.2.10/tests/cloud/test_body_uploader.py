"""BodyUploader — v0.2.2 body-sync worker tests.

Covered behaviours:

* Happy path: a single pending body row with both request and response
  legs produces exactly two POSTs to ``/v1/requests/{id}/body``, then the
  row is marked uploaded.
* Per-project skip: a row whose ``project_slug`` is gated False is marked
  uploaded WITHOUT firing any POST.
* 401 → ``paused_unauthorised`` is written exactly once; the loop exits
  without marking the failing row uploaded.
* Transport error → no upload mark; the row stays pending for the next
  tick.
* Oversize body → leg is skipped (logged), but the row still advances if
  the other leg fits.

Storage and config integration are not exercised here — those are covered
in ``test_supervisor_spawns_body_uploader.py``. This file uses
``httpx.MockTransport`` + recording stubs to drive ``run_once`` directly.
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import Any

import httpx
import pytest

from halton_meter.cloud.body_uploader import BodyRecord, run_once
from halton_meter.cloud.client import CloudClient

# ─── plumbing ───────────────────────────────────────────────────────────


def _record(
    *,
    request_id: str = "00000000-0000-0000-0000-000000000001",
    project_slug: str = "demo",
    request_body: str | None = '{"prompt": "hi"}',
    response_body: str | None = '{"reply": "ok"}',
    redaction_applied: bool = False,
    redaction_summary: str | None = None,
) -> BodyRecord:
    return BodyRecord(
        request_id=request_id,
        project_slug=project_slug,
        request_body=request_body,
        response_body=response_body,
        request_content_type="application/json",
        response_content_type="application/json",
        request_body_bytes=len((request_body or "").encode()),
        response_body_bytes=len((response_body or "").encode()),
        redaction_applied=redaction_applied,
        redaction_summary=redaction_summary,
    )


def _scripted_pending(batches: list[list[BodyRecord]]) -> Callable[[int], Awaitable[list[BodyRecord]]]:
    """Return a pending_reader that yields each batch then empties."""
    iterator = iter([*batches, []])

    async def _reader(_limit: int) -> list[BodyRecord]:
        try:
            return next(iterator)
        except StopIteration:
            return []

    return _reader


def _recording_marker() -> tuple[Callable[[str], Awaitable[None]], list[str]]:
    seen: list[str] = []

    async def _mark(request_id: str) -> None:
        seen.append(request_id)

    return _mark, seen


def _recording_pause() -> tuple[Callable[[str | None], Awaitable[None]], list[str | None]]:
    seen: list[str | None] = []

    async def _pause(reason: str | None) -> None:
        seen.append(reason)

    return _pause, seen


def _client_with_handler(handler: Callable[[httpx.Request], httpx.Response]) -> CloudClient:
    transport = httpx.MockTransport(handler)
    return CloudClient(
        base_url="https://cloud.test",
        token_provider=lambda: "hm_sync_test",
        transport=transport,
    )


# ─── 1. happy path: two POSTs, then mark uploaded ─────────────────────────


@pytest.mark.asyncio
async def test_happy_path_two_posts_then_marked() -> None:
    requests_seen: list[dict[str, Any]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path.startswith("/v1/requests/")
        assert request.url.path.endswith("/body")
        assert request.headers.get("authorization") == "Bearer hm_sync_test"
        payload = json.loads(request.content.decode())
        requests_seen.append(payload)
        return httpx.Response(
            200,
            json={
                "request_id": payload["request_id"],
                "direction": payload["direction"],
                "stored_bytes": 0,
                "redaction_applied": payload["redaction_applied"],
            },
        )

    client = _client_with_handler(handler)
    mark, marked = _recording_marker()
    pause, paused = _recording_pause()

    pending = _scripted_pending(
        [
            [
                _record(
                    request_id="r-1",
                    redaction_applied=True,
                    redaction_summary='{"email": 2}',
                )
            ]
        ]
    )

    async with client:
        result = await run_once(
            client,
            pending_reader=pending,
            upload_marker=mark,
            pause_writer=pause,
            project_gate=lambda _slug: True,
            batch_size=10,
        )

    assert result.legs_sent == 2
    assert result.records_processed == 1
    assert result.skipped_by_project == 0
    assert result.paused is False
    assert result.caught_up is True

    # One POST per direction, both for the same request_id.
    assert len(requests_seen) == 2
    directions = sorted(p["direction"] for p in requests_seen)
    assert directions == ["request", "response"]
    # Redaction state survives into the envelope.
    assert all(p["redaction_applied"] is True for p in requests_seen)
    # Redaction summary parses TEXT JSON map into a sorted list of keys.
    assert all(p["redaction_summary"] == ["email"] for p in requests_seen)
    # Row marked uploaded after both legs ACK.
    assert marked == ["r-1"]
    # No pause was written.
    assert paused == []


# ─── 2. per-project skip: marked uploaded with zero POSTs ─────────────────


@pytest.mark.asyncio
async def test_per_project_skip_marks_without_posting() -> None:
    requests_seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append(request)
        return httpx.Response(200, json={})

    client = _client_with_handler(handler)
    mark, marked = _recording_marker()
    pause, paused = _recording_pause()

    pending = _scripted_pending(
        [
            [
                _record(request_id="r-locked", project_slug="acme-secret"),
                _record(request_id="r-ok", project_slug="demo"),
            ]
        ]
    )

    # Gate denies "acme-secret"; allows everything else.
    def gate(slug: str | None) -> bool:
        return slug != "acme-secret"

    async with client:
        result = await run_once(
            client,
            pending_reader=pending,
            upload_marker=mark,
            pause_writer=pause,
            project_gate=gate,
            batch_size=10,
        )

    assert result.skipped_by_project == 1
    # 2 records processed; 1 record sent both legs (= 2 POSTs).
    assert result.records_processed == 2
    assert result.legs_sent == 2
    # Locked project: zero network calls for it (only the demo row hit the wire).
    assert len(requests_seen) == 2
    # Both rows advanced the cursor.
    assert sorted(marked) == ["r-locked", "r-ok"]
    assert paused == []


# ─── 3. 401 → paused_unauthorised, no mark ────────────────────────────────


@pytest.mark.asyncio
async def test_401_pauses_and_does_not_mark() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "revoked"})

    client = _client_with_handler(handler)
    mark, marked = _recording_marker()
    pause, paused = _recording_pause()

    pending = _scripted_pending([[_record(request_id="r-401")]])

    async with client:
        result = await run_once(
            client,
            pending_reader=pending,
            upload_marker=mark,
            pause_writer=pause,
            project_gate=lambda _slug: True,
        )

    assert result.paused is True
    assert paused == ["paused_unauthorised"]
    # Critically: the failing row is NOT stamped uploaded.
    assert marked == []


# ─── 4. transient transport error → no mark, no pause ─────────────────────


@pytest.mark.asyncio
async def test_transport_error_does_not_mark_or_pause(monkeypatch) -> None:
    """A persistent connect failure surfaces as ``CloudTransport``.

    The worker treats this as transient: the row stays pending, no
    pause is written, and the next tick retries.
    """
    # Bypass the backoff so the test doesn't sleep for ~8 retries.
    from halton_meter.cloud import client as client_mod

    async def _no_sleep(_seconds: float) -> None:
        return None

    monkeypatch.setattr(client_mod, "_sleep_with_jitter", _no_sleep)
    monkeypatch.setattr(client_mod, "MAX_RETRIES", 1, raising=True)

    def handler(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("cloud unreachable", request=_request)

    client = _client_with_handler(handler)
    mark, marked = _recording_marker()
    pause, paused = _recording_pause()

    pending = _scripted_pending([[_record(request_id="r-dropped")]])

    async with client:
        result = await run_once(
            client,
            pending_reader=pending,
            upload_marker=mark,
            pause_writer=pause,
            project_gate=lambda _slug: True,
        )

    assert result.paused is False
    assert marked == []  # row stays pending for next tick
    assert paused == []  # NOT a pause condition


# ─── 5. oversize leg skipped; row still advances if other leg fits ────────


@pytest.mark.asyncio
async def test_oversize_request_leg_skipped_response_ships() -> None:
    requests_seen: list[dict[str, Any]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode())
        requests_seen.append(payload)
        return httpx.Response(200, json={"direction": payload["direction"]})

    client = _client_with_handler(handler)
    mark, marked = _recording_marker()
    pause, paused = _recording_pause()

    # Request body is 200 bytes; response is 10 bytes. Cap at 100 → only the
    # response leg should hit the wire.
    big_request = "x" * 200
    pending = _scripted_pending(
        [
            [
                _record(
                    request_id="r-big",
                    request_body=big_request,
                    response_body="short",
                )
            ]
        ]
    )

    async with client:
        result = await run_once(
            client,
            pending_reader=pending,
            upload_marker=mark,
            pause_writer=pause,
            project_gate=lambda _slug: True,
            max_body_bytes_per_upload=100,
        )

    assert result.legs_sent == 1
    assert result.records_processed == 1
    assert len(requests_seen) == 1
    assert requests_seen[0]["direction"] == "response"
    # Row still advances — the oversize leg is dropped, not retried forever.
    assert marked == ["r-big"]
    assert paused == []
