"""Full pairing flow against ``httpx.MockTransport``.

Exercises the six-step handshake from wire-contract § 4 end-to-end:
start → poll(pending) → poll(approved) → single-shot key delivered.
"""

from __future__ import annotations

import httpx
import pytest

from halton_meter.cli_cloud import _run_pairing_flow
from halton_meter.cloud import client as client_module
from halton_meter.cloud.client import CloudClient


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    import asyncio

    real_sleep = asyncio.sleep

    async def _instant(_: float) -> None:
        return await real_sleep(0)

    async def _instant_inner(_seconds: float) -> None:
        return None

    monkeypatch.setattr(client_module, "_sleep_with_jitter", _instant_inner)
    monkeypatch.setattr(asyncio, "sleep", _instant)


def _pairing_transport():
    """Build a MockTransport scripted with the six-step handshake."""
    poll_calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/v1/pairing/start":
            return httpx.Response(
                200,
                json={
                    "pairing_code": "XK4M-9P2A",
                    "pairing_url": "https://meter.haltonlabs.io/pair",
                    "poll_token": "secret-poll-token",
                    "expires_at": "2026-05-10T13:00:00Z",
                    "poll_interval_seconds": 2,
                },
            )
        if request.url.path == "/v1/pairing/poll":
            poll_calls["count"] += 1
            if poll_calls["count"] == 1:
                return httpx.Response(200, json={"status": "pending"})
            return httpx.Response(
                200,
                json={
                    "status": "approved",
                    "api_key": "hm_sync_singleshotkey",
                    "workspace_id": "ws_abc",
                    "workspace_name": "Acme",
                    "machine_id": "m_xyz",
                },
            )
        return httpx.Response(404)

    return httpx.MockTransport(handler), poll_calls


@pytest.mark.asyncio
async def test_pairing_flow_completes_and_returns_key():
    transport, poll_calls = _pairing_transport()

    # Bypass the module-level CloudClient construction so we can inject
    # the transport. _run_pairing_flow makes its own client — for the
    # test we patch CloudClient to accept the transport via closure.
    original_init = CloudClient.__init__

    def patched_init(self, base_url, **kwargs):
        kwargs.setdefault("transport", transport)
        original_init(self, base_url, **kwargs)

    CloudClient.__init__ = patched_init
    try:
        result = await _run_pairing_flow(
            base_url="https://example.test",
            poll_interval_seconds=0,
            timeout_seconds=5.0,
        )
    finally:
        CloudClient.__init__ = original_init

    assert result["status"] == "approved"
    assert result["api_key"] == "hm_sync_singleshotkey"
    assert result["workspace_name"] == "Acme"
    assert poll_calls["count"] == 2
