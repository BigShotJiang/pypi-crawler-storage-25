"""Tests for ``halton_meter.lifecycle`` (Phase 2B.8).

All OS-level subprocess calls are mocked. No real ``launchctl``,
``lsof``, ``networksetup``, ``security``, ``systemctl``, ``ps``, or
``os.kill`` invocations against live processes.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import lifecycle, system_proxy
from halton_meter.cli import cli
from halton_meter.config import HaltonConfig

# --------------------------------------------------------------------------- #
# Helpers / fixtures                                                          #
# --------------------------------------------------------------------------- #


def _completed(rc: int = 0, stdout: str = "", stderr: str = "") -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(
        args=["mock"], returncode=rc, stdout=stdout, stderr=stderr
    )


def _make_cfg(tmp_path: Path) -> HaltonConfig:
    return HaltonConfig.model_validate(
        {
            "daemon": {
                "listen_host": "127.0.0.1",
                "listen_port": 9080,
                "api_host": "127.0.0.1",
                "api_port": 8765,
                "log_path": str(tmp_path / "daemon.log"),
            },
            "storage": {"db_path": str(tmp_path / "db.sqlite")},
        }
    )


@pytest.fixture(autouse=True)
def _reset_macos_interfaces_cache() -> Any:
    """Reset the per-process enumeration cache between tests so cache
    presets in one test do not leak into the next (2B.7.2 / 2B.7.3)."""
    system_proxy._macos._MACOS_INTERFACES_CACHE = None
    yield
    system_proxy._macos._MACOS_INTERFACES_CACHE = None


@pytest.fixture(autouse=True)
def _default_lsof_listen_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    """Default ``_lsof_listen_pids_on_port`` to empty so tests that
    don't explicitly exercise the LISTEN-state pre-flight don't shell
    out to a real ``lsof`` against arbitrary ports during the test
    run. Tests that DO exercise it set their own monkeypatch which
    overrides this default (last-set wins in pytest's monkeypatch).
    """
    monkeypatch.setattr(lifecycle._macos, "_lsof_listen_pids_on_port", lambda port: [])


@pytest.fixture
def macos(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "darwin")
    # Preset the dynamic-enumeration cache (2B.7.2) so existing
    # stop/networksetup-call-count tests exercise the 4-interface
    # fallback deterministically without an extra
    # ``networksetup -listallnetworkservices`` call inflating counts.
    monkeypatch.setattr(
        system_proxy._macos, "_MACOS_INTERFACES_CACHE", system_proxy._macos._MACOS_INTERFACE_FALLBACK
    )


@pytest.fixture
def installed_plists(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> tuple[Path, Path]:
    daemon_plist = tmp_path / "com.haltonlabs.meter.plist"
    watchdog_plist = tmp_path / "com.haltonlabs.meter.watchdog.plist"
    edge_plist = tmp_path / "com.haltonlabs.meter.edge.plist"
    daemon_plist.write_text("<plist/>")
    watchdog_plist.write_text("<plist/>")
    edge_plist.write_text("<plist/>")
    monkeypatch.setattr(
        lifecycle._macos, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle._macos, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle._macos, "_macos_edge_plist_path", lambda: edge_plist)
    return daemon_plist, watchdog_plist


@pytest.fixture
def absent_plists(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    daemon_plist = tmp_path / "missing.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    monkeypatch.setattr(
        lifecycle._macos, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle._macos, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle._macos, "_macos_edge_plist_path", lambda: edge_plist)


@pytest.fixture
def cfg_loaded(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> HaltonConfig:
    cfg = _make_cfg(tmp_path)
    monkeypatch.setattr(lifecycle._macos, "load_config", lambda: cfg)
    # v0.1.22.x: stop now reads ``load_effective_config`` (so the panel
    # reflects the actual kernel-bound edge port from
    # ``effective-ports.json``). Patch both so existing fixtures cover
    # the stop path without leaking real ``~/.halton-meter`` state.
    monkeypatch.setattr(lifecycle._macos, "load_effective_config", lambda: cfg)
    return cfg


# --------------------------------------------------------------------------- #
# start: macOS                                                                #
# --------------------------------------------------------------------------- #


def test_start_macos_not_installed_returns_error(
    macos: None, absent_plists: None, cfg_loaded: HaltonConfig
) -> None:
    rc = lifecycle.start()
    assert rc == 1


def test_start_macos_port_held_by_orphan_returns_error(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # No daemon running.
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: short-circuit gates on /health, not on
    # _detect_live_daemon. Force /health unhealthy to fall through to
    # the port-conflict check.
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    # Both labels are unknown to launchctl → no managed PIDs.
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
    # Port 8765 (api_port) held by an external PID 99999, listening.
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_listen_pids_on_port",
        lambda port: [99999] if port == 8765 else [],
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_process_name", lambda pid: "ghost")

    rc = lifecycle.start()
    assert rc == 1


def test_start_macos_already_running_is_idempotent(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # v0.1.21.4: short-circuit on /health alone. _detect_live_daemon
    # / _detect_live_watchdog no longer gate the short-circuit.
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (True, 4.5)
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_kickstart",
        lambda label, kill_existing=True: (0, ""),
    )

    rc = lifecycle.start()
    assert rc == 0


def test_start_macos_full_load_succeeds(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Initially nothing running, no port conflicts.
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: short-circuit checks /health first; force unhealthy
    # so we fall through to the full bootstrap+kickstart path.
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])

    # After load, launchctl reports live PIDs.
    pid_state = {"daemon": 4242, "watchdog": 4243}

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return pid_state["daemon"]
        if label == lifecycle._WATCHDOG_LABEL:
            return pid_state["watchdog"]
        return None

    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", fake_pid)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())

    # Mock launchctl unload + load -w.
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)

    # /health comes up immediately. v0.1.21 swapped _wait_for_health
    # for _start_probe_health (3-tick poll, 8s ceiling, returns elapsed
    # ms in addition to per-poll latency).
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health",
        lambda port: (True, 3.2, 5.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )

    # System-proxy + capture.
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    assert rc == 0
    # v0.1.21.3: bootout-then-bootstrap-then-kickstart for each label.
    # ``_launchctl_reload`` always boots-out first to clear any stale
    # registration (bootstrap returns rc=5 EIO on already-loaded), then
    # bootstraps. ``kickstart -k`` forces an immediate start regardless
    # of ``RunAtLoad=False``. Two labels: daemon + watchdog.
    bootout_calls = [argv for argv in run_calls if "bootout" in argv]
    bootstrap_calls = [argv for argv in run_calls if "bootstrap" in argv]
    kickstart_calls = [argv for argv in run_calls if "kickstart" in argv]
    assert len(bootout_calls) == 2
    assert len(bootstrap_calls) == 2
    assert len(kickstart_calls) == 2
    # Order per label: bootout precedes bootstrap.
    first_bootout = run_calls.index(bootout_calls[0])
    first_bootstrap = run_calls.index(bootstrap_calls[0])
    assert first_bootout < first_bootstrap


def test_start_macos_health_probe_uses_runtime_toml_port(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Regression for the v0.1.14 bug: when the daemon falls back from
    the default 8765 to 8766 (because 8765 was busy at bind time) and
    persists the new tuple to ``runtime.toml``, the post-load health
    probe must consult the effective ports overlay — not the stale
    ``cfg`` captured before ``launchctl load`` ran. Mirrors the
    watchdog fix in commit 5c7d244.
    """
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: force short-circuit /health to unhealthy (this test
    # wants the full bootstrap path).
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 4242)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))

    # Two cfg loads happen inside `_start_macos`:
    #   1. before launchctl load — sees the bare config defaults.
    #   2. after launchctl load — must see the runtime.toml fallback
    #      that the daemon's startup persisted.
    # We swap the patched `load_effective_config` between calls.
    rt = tmp_path / "runtime.toml"
    rt.write_text(
        "[daemon]\n"
        "edge_port = 8082\n"
        "internal_port = 8090\n"
        "api_port = 8766\n",
        encoding="utf-8",
    )
    from halton_meter import port_alloc

    call_count = {"n": 0}

    def fake_loader() -> HaltonConfig:
        call_count["n"] += 1
        if call_count["n"] == 1:
            # Pre-load: bare defaults (no runtime.toml exists yet).
            return port_alloc.load_effective_config(
                runtime_path=tmp_path / "missing-runtime.toml",
                config_path=tmp_path / "missing-config.toml",
            )
        # Post-load: daemon has just written runtime.toml with 8766.
        return port_alloc.load_effective_config(
            runtime_path=rt, config_path=tmp_path / "missing-config.toml"
        )

    monkeypatch.setattr(lifecycle._macos, "load_effective_config", fake_loader)

    # Capture which port the health probe actually targeted.
    probed_ports: list[int] = []

    def fake_health(port: int) -> tuple[bool, float, float]:
        probed_ports.append(port)
        return (True, 1.0, 1.5)

    # v0.1.21: probe entry point is _start_probe_health (was
    # _wait_for_health pre-v0.1.21).
    monkeypatch.setattr(lifecycle._macos, "_start_probe_health", fake_health)
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:8082 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    assert rc == 0
    assert probed_ports == [8766], (
        "post-load health probe must read api_port from runtime.toml "
        "(8766), not the stale pre-load default (8765)"
    )


def test_start_macos_health_never_comes_up_returns_error(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: short-circuit /health unhealthy → fall through to
    # the full path; the post-load probe remains the failure surface.
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health",
        lambda port: (False, None, 8000.0),
    )

    err_log_called: list[int] = []
    monkeypatch.setattr(
        lifecycle._macos, "_print_err_log_tail", lambda *a, **kw: err_log_called.append(1)
    )

    rc = lifecycle.start()
    assert rc == 1
    assert err_log_called == [1]


# --------------------------------------------------------------------------- #
# stop: macOS                                                                 #
# --------------------------------------------------------------------------- #


def test_stop_macos_not_installed_is_idempotent(
    macos: None,
    absent_plists: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Even with no plists installed, `stop` resets the system proxy.

    A user who runs `stop` after a hard crash that left the proxy stuck
    wants the proxy off regardless of plist state — same recovery
    posture as `uninstall`.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x (secure, unsecure) variants → 8 calls.
    assert len(networksetup_calls) == 8


def test_stop_macos_unloads_both_plists(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    # v0.1.21.2: modern ``launchctl bootout`` replaces legacy ``unload``.
    bootout_argvs = [argv for argv in run_calls if "bootout" in argv]
    assert len(bootout_argvs) == 2


def test_stop_macos_kills_orphan_port_holders(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)
    # Port 8765 held by 7777 even after unload.
    seen: dict[int, int] = {8765: 7777}
    # v0.1.22.2 (B4): _stop_macos now uses _lsof_listen_pids_on_port and
    # filters against _our_managed_pids; both must be patched so the
    # orphan-kill path observes the seeded squatter.
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_listen_pids_on_port",
        lambda port: [seen[port]] if port in seen else [],
    )
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(
        lifecycle._macos, "_lsof_pids_on_port", lambda port: [seen[port]] if port in seen else []
    )

    kills: list[tuple[int, int]] = []

    def fake_kill(pid: int, sig: int) -> None:
        kills.append((pid, sig))
        # First SIGTERM: still alive; signal-0 probe also must succeed.
        # On SIGKILL or after timeout, simulate process gone.
        if sig == 0:
            # liveness probe: process still alive within the wait loop.
            return
        if sig == lifecycle._signal.SIGKILL:
            return

    monkeypatch.setattr(lifecycle.os, "kill", fake_kill)
    # Skip the wait loop. v0.1.22 ``_stop_macos`` settle loop consumes
    # the first 2 monotonic calls (``deadline = monotonic() + 3.0`` and
    # ``while monotonic() < deadline`` exit). ``_terminate_pid`` then
    # consumes 2 more calls (``deadline = monotonic() + 2.0`` and the
    # exit check). Default fallback (100.0) keeps any further callers
    # safely past every deadline.
    times = iter([0.0, 100.0, 0.0, 100.0])
    monkeypatch.setattr(lifecycle.time, "monotonic", lambda: next(times, 100.0))

    rc = lifecycle.stop()
    assert rc == 0
    # SIGTERM to 7777 then SIGKILL escalation.
    sent = {(pid, sig) for pid, sig in kills if sig != 0}
    assert (7777, lifecycle._signal.SIGTERM) in sent


def test_stop_macos_resets_system_proxy_after_unload(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`stop` must reset the system proxy, and only after unloading the plists.

    Inverted from the original 2B.8 contract — leaving the proxy
    pointed at a now-dead listener breaks every HTTPS-via-system-proxy
    client on the machine.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    # Networksetup must run for every fallback interface, both proxy variants, all `off`.
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x 2 variants = 8.
    assert len(networksetup_calls) == 8
    expected_pairs = {
        (iface, variant)
        for iface in system_proxy._macos._MACOS_INTERFACE_FALLBACK
        for variant in ("-setsecurewebproxystate", "-setwebproxystate")
    }
    seen_pairs = {(argv[2], argv[1]) for argv in networksetup_calls}
    assert seen_pairs == expected_pairs
    for argv in networksetup_calls:
        assert argv[3] == "off"

    # Ordering: every networksetup call must come AFTER the last
    # launchctl bootout, so the daemon is dead before the proxy goes off
    # (closes the brief window where new traffic would hit a dying listener).
    last_unload_idx = max(
        i
        for i, argv in enumerate(run_calls)
        if argv and argv[0] == "launchctl" and "bootout" in argv
    )
    first_networksetup_idx = min(
        i for i, argv in enumerate(run_calls) if argv and argv[0] == "networksetup"
    )
    assert first_networksetup_idx > last_unload_idx


def test_stop_macos_preserves_sentinel_file(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """`stop` must NOT delete the proxy-managed sentinel — that's `uninstall`'s job.

    Preserving it means the daemon's Option-1 startup re-enable will
    fire on the next `halton-meter start`.
    """
    sentinel = tmp_path / "proxy-managed"
    sentinel.touch()

    real_unlink = Path.unlink
    unlinked: list[str] = []

    def tracking_unlink(self: Path, *args: Any, **kwargs: Any) -> None:
        unlinked.append(str(self))
        real_unlink(self, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", tracking_unlink)
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    assert sentinel.exists()
    assert str(sentinel) not in unlinked


def test_stop_macos_proxy_reset_runs_even_when_unload_fails(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If `launchctl unload` fails, system-proxy reset must still run.

    Same best-effort recovery posture as `uninstall` — the proxy reset
    is the load-bearing line, never gated on prior step success.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        if argv and argv[0] == "launchctl" and "unload" in argv:
            return _completed(1, stderr="launchctl: Could not unload service")
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x 2 variants = 8 calls.
    assert len(networksetup_calls) == 8


def test_stop_macos_resets_proxy_on_vikrants_mac_shape(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: `stop` on a Mac whose enumerated services
    are Wi-Fi / Thunderbolt Bridge / iPhone USB (Vikrant's MacBook) must
    reset the proxy on those three interfaces and MUST NOT call
    networksetup against a non-existent ``Ethernet`` service."""
    # Override the FALLBACK preset baked into the `macos` fixture.
    monkeypatch.setattr(
        system_proxy._macos,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi", "Thunderbolt Bridge", "iPhone USB"),
    )
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 3 interfaces x 2 variants = 6.
    assert len(networksetup_calls) == 6
    seen_ifaces = {argv[2] for argv in networksetup_calls}
    assert seen_ifaces == {"Wi-Fi", "Thunderbolt Bridge", "iPhone USB"}
    assert "Ethernet" not in seen_ifaces


def test_stop_macos_no_networksetup_calls_when_enum_empty(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: when dynamic enumeration yields an empty
    tuple, `stop` must not shell out to networksetup at all — graceful
    degradation rather than a flurry of bad-argument failures."""
    monkeypatch.setattr(system_proxy._macos, "_MACOS_INTERFACES_CACHE", ())
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    assert networksetup_calls == []


# --------------------------------------------------------------------------- #
# status: macOS                                                               #
# --------------------------------------------------------------------------- #


@pytest.fixture
def status_macos_healthy(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    # v0.1.16 Q4.3: status now probes the MITM listener via TCP. Stub
    # to "open" so the healthy fixture stays healthy without binding a
    # real socket on :8090.
    monkeypatch.setattr(
        lifecycle._macos, "_probe_mitm_listener",
        lambda host, port, timeout=0.5: True,
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    # Sentinel present.
    sentinel = Path("/tmp/halton-meter-test-sentinel-status")
    sentinel.touch()
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(
            found=True, db_missing=False, timestamp_iso="2026-04-29T12:00:00Z",
            seconds_ago=25.0, model="claude-opus-4-7", project="halton-meter",
            cost_usd_minor_units=8790, captured_last_hour=12, captured_last_day=4208,
        ),
    )


def test_status_macos_healthy_returns_zero(status_macos_healthy: None) -> None:
    rc = lifecycle.status()
    assert rc == 0


def test_status_macos_edge_row_present_when_healthy(
    status_macos_healthy: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """2C.2 (v0.1.6): the status table includes an explicit Edge row
    showing the user-facing port. Without this row, a stopped/dead
    edge would be invisible until apps started failing."""
    lifecycle.status()
    out = capsys.readouterr().out
    assert "Edge" in out
    assert ":8081" in out  # default edge_port

    # The Daemon row also surfaces internal_port now (was only api_port).
    assert "internal=:8090" in out


def test_status_macos_edge_row_shows_chain_target_ok(
    status_macos_healthy: None,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.7 Gap 0: when the edge sidecar's chain_port matches the
    cfg.daemon.internal_port, the row carries `chain :PORT ✓`."""
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc,
        "read_edge_state_toml",
        lambda *a, **kw: {"edge_port": 8081, "chain_port": 8090, "pid": 81235},
    )
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "chain :8090" in out
    assert "✓" in out


def test_status_macos_edge_row_marks_stale_chain(
    status_macos_healthy: None,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.7 Gap 0: when the edge's bound chain_port differs from the
    daemon's actual internal_port, the row says STALE and status returns
    non-zero. Pre-fix this state was completely invisible."""
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc,
        "read_edge_state_toml",
        lambda *a, **kw: {"edge_port": 8081, "chain_port": 8091, "pid": 81235},
    )
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc != 0  # stale chain forces non-healthy
    assert "chain :8091" in out
    assert "✗" in out
    assert "stale chain" in out


def test_status_macos_edge_not_installed_marks_unhealthy(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """When the edge plist is missing the Edge row reports not-installed
    and status returns non-zero — apps would fail with ConnectionRefused."""
    daemon_plist = tmp_path / "com.haltonlabs.meter.plist"
    watchdog_plist = tmp_path / "com.haltonlabs.meter.watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    daemon_plist.write_text("<plist/>")
    watchdog_plist.write_text("<plist/>")
    monkeypatch.setattr(
        lifecycle._macos, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle._macos, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle._macos, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 81234)
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_stop_macos_explains_apps_still_work_via_edge(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """2C.2 (v0.1.6): stop output makes the new behaviour explicit —
    apps continue working in passthrough via the still-running edge
    proxy. Stop never restarts apps; the edge is the reason it doesn't
    have to."""
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    out = capsys.readouterr().out
    # v0.1.21 reframed copy: lead with "Edge proxy still running" + the
    # un-metered tunnel-through promise; no longer "Apps still work".
    assert "Edge proxy still running" in out
    # Test cfg uses port 9080 — assert the resolved edge_port appears.
    assert f":{cfg_loaded.daemon.edge_port}" in out
    assert "halton-meter start" in out
    assert "un-metered" in out
    assert "Sentinel preserved" in out


def test_stop_macos_panel_uses_effective_bound_edge_port(
    macos: None,
    installed_plists: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path: Path,
) -> None:
    """v0.1.22.x bug 2: when the edge falls back from the configured
    default (e.g. :8081 busy) to a different port (e.g. :8082), the
    stop panel's "Edge proxy still running on :PORT" line MUST reflect
    the actual kernel-bound port from ``effective-ports.json``, not the
    static ``cfg.daemon.edge_port`` default.

    Repro: cfg defaults edge_port=8081, but ``load_effective_config``
    returns 8082 (effective-ports.json has higher precedence). The
    panel must say ``:8082`` and NOT ``:8081``.
    """
    static_cfg = _make_cfg(tmp_path)
    # Build an effective cfg that mimics the post-bind state where the
    # edge fell back to :8082.
    effective_cfg = HaltonConfig.model_validate(
        {
            "daemon": {
                "listen_host": "127.0.0.1",
                "listen_port": 8082,
                "api_host": "127.0.0.1",
                "api_port": static_cfg.daemon.api_port,
                "log_path": str(tmp_path / "daemon.log"),
            },
            "storage": {"db_path": str(tmp_path / "db.sqlite")},
        }
    )
    assert effective_cfg.daemon.edge_port == 8082
    assert static_cfg.daemon.edge_port == 9080  # cfg default in tests

    monkeypatch.setattr(lifecycle._macos, "load_config", lambda: static_cfg)
    monkeypatch.setattr(
        lifecycle._macos, "load_effective_config", lambda: effective_cfg
    )
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    out = capsys.readouterr().out
    # The panel MUST show the effective bound port.
    assert "Edge proxy still running on :8082" in out
    # And MUST NOT show the static-config default port (the bug).
    assert ":9080" not in out
    # Also guard against the originally-hardcoded :8081 regression.
    assert "Edge proxy still running on :8081" not in out


def test_status_macos_daemon_loaded_but_unhealthy_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 81234)
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_proxy_disabled_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state", lambda host, port: ("disabled", "off"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_proxy_pointed_elsewhere_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state",
        lambda host, port: ("pointed elsewhere", "system proxy on but address=10.0.0.1:3128"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_database_missing(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert "database not found" in result.output


def test_status_macos_database_empty(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert "no captures yet" in result.output


def test_status_json_output(status_macos_healthy: None) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    assert result.exit_code == 0
    # Last JSON object on stdout — Rich console may have leading/trailing
    # whitespace but no other text in --json mode.
    payload = json.loads(result.output.strip())
    assert payload["healthy"] is True
    assert payload["platform"] == "darwin"
    assert "components" in payload
    assert any(c["name"] == "Daemon" for c in payload["components"])
    assert payload["captured_last_hour"] == 12
    assert payload["captured_last_day"] == 4208


# --------------------------------------------------------------------------- #
# v0.1.10 Gap 16 — graceful-uninstall status detection                        #
# --------------------------------------------------------------------------- #


@pytest.fixture
def graceful_uninstall_state(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Materialise the post-`uninstall --graceful` filesystem signature.

    Edge plist + sentinel + daemon plist all absent on disk; edge label
    has a live PID; daemon label is unknown to launchctl.
    """
    daemon_plist = tmp_path / "missing-daemon.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    sentinel = tmp_path / "missing-sentinel"
    monkeypatch.setattr(
        lifecycle._macos, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle._macos, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle._macos, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle._macos,
        "_launchctl_label_pid",
        lambda label: 90210 if label == lifecycle._EDGE_LABEL else None,
    )
    # daemon label unknown → returncode != 0 from `launchctl list`
    monkeypatch.setattr(
        lifecycle._macos,
        "_launchctl_label_known",
        lambda label: False,
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )


def test_status_macos_graceful_uninstall_renders_single_row(
    graceful_uninstall_state: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """When all four detection conditions hold, `status` emits a single
    `Graceful uninstall` row instead of the standard 8-row table, and
    exits HEALTHY (0) — graceful is an explicit user-state, not drift."""
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "Graceful uninstall" in out
    assert "edge in passthrough" in out
    assert "PID 90210" in out
    # Standard rows must NOT appear.
    assert "Watchdog" not in out
    assert "System proxy" not in out
    assert "Cert trust" not in out
    # HEALTHY verdict, not BROKEN.
    assert "HEALTHY" in out
    assert "BROKEN" not in out


def test_status_macos_graceful_uninstall_json_payload(
    graceful_uninstall_state: None,
) -> None:
    """JSON output mirrors the rendered table — one component row,
    HEALTHY summary, healthy=True."""
    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.output.strip())
    assert payload["healthy"] is True
    assert len(payload["components"]) == 1
    assert payload["components"][0]["name"] == "Graceful uninstall"
    assert payload["components"][0]["state"] == "edge in passthrough"
    assert payload["health_summary"]["severity"] == "HEALTHY"


def test_status_macos_graceful_partial_falls_through_to_standard_table(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Partial graceful state (sentinel still present) is NOT graceful —
    it is drift. The standard render must fire so the user sees the
    inconsistency, not a misleading HEALTHY graceful row."""
    daemon_plist = tmp_path / "missing-daemon.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    # Sentinel is present — breaks the four-of-four detection.
    sentinel = tmp_path / "proxy-managed"
    sentinel.touch()
    monkeypatch.setattr(
        lifecycle._macos, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle._macos, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle._macos, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle._macos,
        "_launchctl_label_pid",
        lambda label: 90210 if label == lifecycle._EDGE_LABEL else None,
    )
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: False)
    monkeypatch.setattr(
        lifecycle._macos, "_is_cert_trusted", lambda: True,
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state", lambda host, port: ("disabled", "off"),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc != 0  # standard render reports the wall of "not installed"
    assert "Graceful uninstall" not in out
    # Standard table rows present.
    assert "Daemon" in out
    assert "Watchdog" in out


# --------------------------------------------------------------------------- #
# Linux                                                                       #
# --------------------------------------------------------------------------- #


def test_status_linux_skips_proxy_row(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "linux")
    monkeypatch.setattr(lifecycle.os, "name", "posix")
    cfg = _make_cfg(tmp_path)
    monkeypatch.setattr(lifecycle._macos, "load_config", lambda: cfg)

    # Pretend systemd units exist + active.
    daemon_unit = tmp_path / "halton-meter.service"
    watchdog_unit = tmp_path / "halton-meter-watchdog.service"
    daemon_unit.write_text("")
    watchdog_unit.write_text("")
    monkeypatch.setattr(lifecycle._macos, "_linux_unit_path", lambda: daemon_unit)
    monkeypatch.setattr(lifecycle._macos, "_linux_watchdog_unit_path", lambda: watchdog_unit)
    monkeypatch.setattr(lifecycle._macos, "_systemctl_is_active", lambda unit: "active")
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    payload = json.loads(result.output.strip())
    component_names = {c["name"] for c in payload["components"]}
    assert "System proxy" not in component_names
    assert "Daemon" in component_names
    assert "Watchdog" in component_names


# --------------------------------------------------------------------------- #
# Windows                                                                     #
# --------------------------------------------------------------------------- #


def test_start_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.start()
    assert rc == 0


def test_stop_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.stop()
    assert rc == 0


def test_status_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.status()
    assert rc == 0


# --------------------------------------------------------------------------- #
# v0.1.3 P0-8 — mode-aware health summary                                     #
# --------------------------------------------------------------------------- #


def _row(name: str, state: str) -> lifecycle._ComponentRow:
    return lifecycle._ComponentRow(name, state, "")


class TestComputeHealthSummaryMacos:
    @pytest.fixture(autouse=True)
    def _isolate_sentinel_drift(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """v0.1.22.12 Bug 3: ``_compute_health_summary_macos`` now
        consults the on-disk ``proxy-managed`` / ``apps-managed``
        sentinels via ``_detect_sentinel_drift_for_status``. The legacy
        tests in this class exercise the per-mode verdict branches
        with row-only fixtures and don't manage sentinel state. Stub
        the drift probe to return ``None`` (no drift) so the
        per-mode branches stay reachable; dedicated drift tests live
        in ``test_v0_1_22_12_sentinel_writers_heartbeat_verdict.py``.
        """
        from halton_meter.lifecycle import _macos as _lifecycle_macos

        monkeypatch.setattr(
            _lifecycle_macos,
            "_detect_sentinel_drift_for_status",
            lambda _mode: None,
        )

    def test_env_only_healthy_when_daemon_and_cert_ok(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
            _row("Sentinel file", "missing"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "env-only")
        assert summary.severity == "HEALTHY"
        assert "halton-meter run" in summary.message

    def test_env_only_broken_when_cert_not_trusted(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "env-only")
        assert summary.severity == "BROKEN"

    def test_full_broken_when_proxy_enabled_but_cert_untrusted(self) -> None:
        """Witnessed totaljobs.com regression: proxy enabled at us but
        cert is not trusted -> SecTrust rejects, browsing dies."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "cert" in summary.message.lower()

    def test_full_inconsistent_when_proxy_not_enabled(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "INCONSISTENT"

    def test_full_healthy_when_all_signals_good(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "HEALTHY"

    def test_apps_healthy_when_proxy_disabled_and_cert_trusted(self) -> None:
        """v0.1.5 (2B.16): apps mode is HEALTHY when daemon + cert ok AND
        system proxy is DISABLED on our interfaces (apps mode promises
        to leave the system proxy alone)."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "HEALTHY"
        assert "apps" in summary.message.lower()

    def test_apps_broken_when_proxy_enabled_drift(self) -> None:
        """v0.1.5 (2B.16): apps mode + system proxy enabled = BROKEN
        drift. The user is running stale full-mode state."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "stale" in summary.message.lower() or "drift" in summary.message.lower()

    def test_apps_broken_when_cert_not_trusted(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "cert" in summary.message.lower()

    def test_unknown_mode_returns_inconsistent(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, None)
        assert summary.severity == "INCONSISTENT"

    def test_daemon_unhealthy_dominates(self) -> None:
        rows = [
            _row("Daemon", "loaded"),  # not healthy
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "daemon" in summary.message.lower()


def test_status_report_to_json_dict_includes_health_summary() -> None:
    report = lifecycle._StatusReport(
        healthy=True,
        platform="darwin",
        health_summary=lifecycle._HealthSummary(
            "HEALTHY", "env-var-only mode is healthy."
        ),
    )
    payload = report.to_json_dict()
    assert "health_summary" in payload
    assert payload["health_summary"]["severity"] == "HEALTHY"


def test_status_report_to_json_dict_omits_health_summary_when_none() -> None:
    report = lifecycle._StatusReport(healthy=True, platform="darwin")
    payload = report.to_json_dict()
    assert "health_summary" not in payload


# --------------------------------------------------------------------------- #
# v0.1.4 (2B.15) P0-5 — auto-port-fallback in status                           #
# --------------------------------------------------------------------------- #


class TestPortStatusRow:
    """Effective ports row marks auto-fallback explicitly so the user
    knows their tools must target the actual port, not the marketed
    default."""

    def test_default_ports_show_default_state(self) -> None:
        # v0.1.6: user-facing proxy default is now 8081 (was 8080); the
        # daemon's mitmproxy listener still binds it at this stage of
        # the rollout (W4 flips it to internal_port 8090).
        row = lifecycle._port_status_row(8081, 8765)
        assert row.name == "Effective ports"
        assert row.state == "default"
        assert "8081" in row.detail
        assert "8765" in row.detail
        assert "fallback" not in row.detail.lower()

    def test_listen_port_fallback_marked(self) -> None:
        # 8082 is one above the v0.1.6 default 8081 -> fallback.
        row = lifecycle._port_status_row(8082, 8765)
        assert row.state == "fallback"
        assert "8082" in row.detail
        assert "fell back" in row.detail.lower()
        assert "8081" in row.detail  # v0.1.6 default we fell back from

    def test_api_port_fallback_marked(self) -> None:
        row = lifecycle._port_status_row(8081, 8766)
        assert row.state == "fallback"
        assert "8766" in row.detail
        assert "fell back" in row.detail.lower()
        assert "8765" in row.detail  # default we fell back from

    def test_both_ports_fallback_listed(self) -> None:
        row = lifecycle._port_status_row(8083, 8767)
        assert row.state == "fallback"
        # Both fallback notes present.
        assert "8083" in row.detail
        assert "8767" in row.detail
        assert "8081" in row.detail  # v0.1.6 default
        assert "8765" in row.detail


# --------------------------------------------------------------------------- #
# v0.1.16 Q4.3 — MITM listener TCP probe + banner precedence (Bug 1)           #
# --------------------------------------------------------------------------- #


class TestProbeMitmListener:
    """The TCP probe is the only signal that catches the Bug 1 silent
    death: the asyncio MITM acceptor died but FastAPI `/health` is still
    UP. Defensive — must never raise."""

    def test_probe_returns_true_when_socket_opens(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        class _FakeSock:
            def close(self) -> None:
                self.closed = True

        captured: dict = {}

        def _fake_create_connection(addr, timeout):  # type: ignore[no-untyped-def]
            captured["addr"] = addr
            captured["timeout"] = timeout
            return _FakeSock()

        monkeypatch.setattr(_socket, "create_connection", _fake_create_connection)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is True
        assert captured["addr"] == ("127.0.0.1", 8090)
        assert captured["timeout"] == 0.5

    def test_probe_returns_false_on_connection_refused(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        def _refuse(addr, timeout):  # type: ignore[no-untyped-def]
            raise ConnectionRefusedError("nope")

        monkeypatch.setattr(_socket, "create_connection", _refuse)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False

    def test_probe_returns_false_on_timeout(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        def _timeout(addr, timeout):  # type: ignore[no-untyped-def]
            raise TimeoutError("slow")

        monkeypatch.setattr(_socket, "create_connection", _timeout)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False

    def test_probe_returns_false_on_generic_oserror(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        def _err(addr, timeout):  # type: ignore[no-untyped-def]
            raise OSError("generic")

        monkeypatch.setattr(_socket, "create_connection", _err)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False

    def test_probe_swallows_unexpected_exceptions(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Even if a wildly unexpected exception escapes, the probe must
        return False — never raise into the status command."""
        import socket as _socket

        def _kaboom(addr, timeout):  # type: ignore[no-untyped-def]
            raise RuntimeError("totally unexpected")

        monkeypatch.setattr(_socket, "create_connection", _kaboom)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False


class TestMitmBannerPrecedence:
    """Banner precedence (v0.1.16 Q4.3, Bug 1):

        daemon-down  >  MITM-down  >  existing mode-aware verdict

    Daemon-down dominates so we never double-warn (the existing message
    already tells the user to run start). MITM-down fires BROKEN with a
    distinct, action-oriented message."""

    @pytest.fixture(autouse=True)
    def _isolate_sentinel_drift(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """v0.1.22.12 Bug 3: stub the new sentinel-drift probe so this
        class continues to test ONLY the daemon/mitm banner precedence
        rules. Drift detection has its own dedicated tests."""
        from halton_meter.lifecycle import _macos as _lifecycle_macos

        monkeypatch.setattr(
            _lifecycle_macos,
            "_detect_sentinel_drift_for_status",
            lambda _mode: None,
        )

    def test_banner_broken_when_daemon_healthy_and_mitm_unresponsive(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("MITM listener", "unresponsive"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        # Stuff a port into the row detail so the banner can extract it.
        rows[1] = lifecycle._ComponentRow(
            "MITM listener",
            "unresponsive",
            "127.0.0.1:8090 TCP connect failed — metering is OFF",
        )
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "MITM listener" in summary.message
        assert ":8090" in summary.message
        assert "metering is OFF" in summary.message
        assert "halton-meter restart" in summary.message
        assert "daemon.err.log" in summary.message

    def test_banner_does_not_fire_when_daemon_healthy_and_mitm_healthy(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("MITM listener", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "HEALTHY"
        assert "MITM" not in summary.message

    def test_daemon_down_banner_takes_precedence_over_mitm_down(self) -> None:
        """If the daemon row is unhealthy, the existing daemon-down
        message wins — no double-warn, no mention of MITM."""
        rows = [
            _row("Daemon", "loaded"),  # not healthy
            _row("MITM listener", "unresponsive"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "daemon" in summary.message.lower()
        assert "MITM" not in summary.message
        assert "halton-meter start" in summary.message

    def test_mitm_unresponsive_overrides_apps_mode_healthy_path(self) -> None:
        """Apps-mode + daemon healthy + cert trusted + proxy disabled is
        normally HEALTHY — but MITM-down still flips to BROKEN."""
        rows = [
            _row("Daemon", "healthy"),
            _row("MITM listener", "unresponsive"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        rows[1] = lifecycle._ComponentRow(
            "MITM listener", "unresponsive", "127.0.0.1:8090 TCP connect failed",
        )
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "MITM listener" in summary.message


def test_status_macos_renders_mitm_listener_row_when_healthy(
    status_macos_healthy: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """v0.1.16 Q4.3: the status table includes a MITM listener row that
    reports healthy when the TCP probe succeeds."""
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "MITM listener" in out
    # Detail mentions the probed port (default internal_port 8090).
    assert ":8090" in out


def test_status_macos_mitm_unresponsive_flips_banner_to_broken(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.16 Q4.3: when /health is up but the MITM port is silently
    dead, status flips BROKEN with the action-oriented banner. This is
    the exact silent-failure mode that bit us in the 0.1.15 soak."""
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    # Critical: MITM port unresponsive while /health is healthy.
    monkeypatch.setattr(
        lifecycle._macos, "_probe_mitm_listener",
        lambda host, port, timeout=0.5: False,
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
    sentinel = Path("/tmp/halton-meter-test-sentinel-mitm-broken")
    sentinel.touch()
    monkeypatch.setattr(lifecycle._macos, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 1
    assert "BROKEN" in out
    assert "MITM listener" in out
    assert "unresponsive" in out
    assert "halton-meter restart" in out


# --------------------------------------------------------------------------- #
# v0.1.21 manual-start: branded panels + --quiet + STOPPED verdict            #
# --------------------------------------------------------------------------- #


def test_start_macos_success_renders_metering_active_panel(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21: success panel title is "Halton Meter — metering active"
    with the new mental-model body lines (PIDs, /health latency, edge
    port, stop hint)."""
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_label_pid",
        lambda label: 9001 if label == lifecycle._LABEL else 9002,
    )
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (True, 4.0, 5.0)
    )
    # v0.1.22.4: post-success liveness re-probe runs after _start_probe_health.
    # Existing success-path tests don't model the daemon dying, so short-circuit
    # the helper to True. The dedicated post-success tests cover the False path.
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )

    rc = lifecycle.start()
    out = capsys.readouterr().out
    assert rc == 0
    assert "metering active" in out
    assert "Daemon loaded" in out
    assert "9001" in out
    assert "Watchdog loaded" in out
    assert "halton-meter stop" in out


def test_start_macos_failure_renders_branded_failure_panel(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21: when /health does not respond within 8s, the failure
    panel surfaces (a) edge is still tunnelling fail-open and (b) the
    three retry steps."""
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (False, None, 8000.0)
    )
    monkeypatch.setattr(lifecycle._macos, "_print_err_log_tail", lambda *a, **kw: None)

    rc = lifecycle.start()
    out = capsys.readouterr().out
    assert rc == 1
    assert "daemon failed to start" in out
    assert "fail-open" in out
    assert "halton-meter doctor" in out
    assert "halton-meter stop && halton-meter start" in out


def test_start_macos_quiet_mode_emits_single_line_success(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21 ``--quiet``: scripts and shell-rc helpers see one line."""
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 4242)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (True, 1.0, 1.0)
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )

    rc = lifecycle.start(quiet=True)
    out = capsys.readouterr().out
    assert rc == 0
    # No box-drawing in quiet mode.
    assert "metering active" in out
    assert "│" not in out
    assert "╭" not in out


def test_start_macos_quiet_mode_emits_single_line_failure(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21 ``--quiet`` failure path mentions edge tunnelling so a
    script can grep the single line and know fail-open is intact."""
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (False, None, 8000.0)
    )

    rc = lifecycle.start(quiet=True)
    out = capsys.readouterr().out
    assert rc == 1
    assert "edge tunnelling" in out
    assert "│" not in out


# --------------------------------------------------------------------------- #
# v0.1.21: STOPPED is a first-class verdict (info, not error)                 #
# --------------------------------------------------------------------------- #


class TestComputeHealthSummaryStoppedVerdict:
    """v0.1.21 manual-start: daemon not loaded + edge healthy = STOPPED."""

    def test_stopped_when_daemon_not_loaded_and_edge_healthy(self) -> None:
        rows = [
            _row("Daemon", "not loaded"),
            _row("Edge", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "STOPPED"
        assert "halton-meter start" in summary.message
        assert "un-metered" in summary.message

    def test_loaded_but_unresponsive_still_broken(self) -> None:
        """Zombie signature (loaded, no PID-but-known) stays BROKEN —
        STOPPED is reserved for the clean post-reboot/post-stop path."""
        rows = [
            _row("Daemon", "loaded"),  # zombie state
            _row("Edge", "healthy"),
            _row("Cert trust", "trusted"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"

    def test_status_macos_stopped_returns_zero_and_renders_info(
        self,
        macos: None,
        installed_plists: tuple[Path, Path],
        cfg_loaded: HaltonConfig,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        """End-to-end: post-reboot status (daemon not loaded, edge alive)
        renders STOPPED verdict and exits 0 — not BROKEN, not exit 1."""
        # Daemon: known plist, no PID, label unknown to launchctl.
        monkeypatch.setattr(
            lifecycle._macos, "_launchctl_label_pid",
            lambda label: 4242 if label == lifecycle._EDGE_LABEL else None,
        )
        monkeypatch.setattr(
            lifecycle._macos, "_launchctl_label_known",
            lambda label: label == lifecycle._EDGE_LABEL,
        )
        # Edge plist is present (auto-loaded).
        from halton_meter import install as _install
        edge_plist = Path.home() / "Library" / "LaunchAgents" / _install._EDGE_PLIST_NAME
        edge_plist.parent.mkdir(parents=True, exist_ok=True)
        edge_plist.write_text("<plist/>")
        monkeypatch.setattr(lifecycle._macos, "_macos_edge_plist_path", lambda: edge_plist)
        # MITM probe → up (edge tunnels there during fail-open is fine).
        monkeypatch.setattr(lifecycle._macos, "_probe_mitm_listener", lambda *a, **kw: True)
        monkeypatch.setattr(lifecycle._macos, "_is_cert_trusted", lambda: True)
        monkeypatch.setattr(
            lifecycle._macos, "_system_proxy_state",
            lambda host, port: ("disabled", "—"),
        )
        monkeypatch.setattr(
            lifecycle._macos, "_latest_capture",
            lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
        )

        rc = lifecycle.status()
        out = capsys.readouterr().out
        assert rc == 0, "STOPPED is an expected state — must exit 0"
        assert "STOPPED" in out
        assert "metering paused" in out
        assert "BROKEN" not in out


# --------------------------------------------------------------------------- #
# v0.1.21.2: modern launchctl verbs                                           #
# --------------------------------------------------------------------------- #


class TestModernLaunchctlVerbs:
    """v0.1.21.2: legacy ``launchctl load -w`` is a no-op on
    ``RunAtLoad=False`` plists. Switched to ``bootstrap`` / ``bootout``
    / ``kickstart`` against ``gui/$UID`` domain.
    """

    def test_bootstrap_invokes_correct_verb_and_domain(
        self, macos: None, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_bootstrap(tmp_path / "x.plist")
        assert rc == 0
        assert captured[-1][:3] == ["launchctl", "bootstrap", "gui/501"]
        assert captured[-1][-1] == str(tmp_path / "x.plist")

    def test_bootout_invokes_correct_verb_and_domain(
        self, macos: None, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_bootout("com.haltonlabs.meter")
        assert rc == 0
        assert captured[-1] == [
            "launchctl", "bootout", "gui/501/com.haltonlabs.meter",
        ]

    def test_kickstart_includes_dash_k_when_killing(
        self, macos: None, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_kickstart(
            "com.haltonlabs.meter", kill_existing=True
        )
        assert rc == 0
        assert captured[-1] == [
            "launchctl", "kickstart", "-k", "gui/501/com.haltonlabs.meter",
        ]

    def test_kickstart_omits_dash_k_when_not_killing(
        self, macos: None, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_kickstart(
            "com.haltonlabs.meter", kill_existing=False
        )
        assert rc == 0
        assert "-k" not in captured[-1]
        assert captured[-1][-1] == "gui/501/com.haltonlabs.meter"

    def test_start_macos_kickstart_failure_is_fatal(
        self,
        macos: None,
        installed_plists: tuple[Path, Path],
        cfg_loaded: HaltonConfig,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """v0.1.21.2: kickstart is the load-bearing call. A non-zero
        kickstart exit MUST surface as a non-zero ``halton-meter start``
        exit (the v0.1.21.1 silent-failure regression).
        """
        monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
        monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
        monkeypatch.setattr(
            lifecycle._macos,
            "_poll_health_with_latency",
            lambda port, timeout=1.0: (False, None),
        )
        monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
        monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
        monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            if "kickstart" in argv:
                return _completed(1, stderr="job failed to start")
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        rc = lifecycle.start()
        assert rc == 1


# --------------------------------------------------------------------------- #
# v0.1.21.2: dormant daemon → STOPPED verdict                                  #
# --------------------------------------------------------------------------- #


class TestDormantDaemonStopped:
    """v0.1.21.2: ``dormant`` (label registered, no live PID) is the
    post-reboot signature on a manual-start install whose plist
    auto-loaded at boot. The verdict must be STOPPED (not BROKEN)
    when edge is healthy.
    """

    def test_dormant_daemon_with_healthy_edge_returns_stopped(self) -> None:
        rows = [
            _row("Daemon", "dormant"),
            _row("Edge", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "STOPPED"
        assert "halton-meter start" in summary.message

    def test_dormant_daemon_with_dead_edge_falls_through_to_broken(self) -> None:
        rows = [
            _row("Daemon", "dormant"),
            _row("Edge", "not loaded"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        # No STOPPED — edge isn't healthy, fail-open is broken.
        assert summary.severity == "BROKEN"


# --------------------------------------------------------------------------- #
# v0.1.21.2: stale-chain → BROKEN verdict                                      #
# --------------------------------------------------------------------------- #


def test_edge_stale_chain_promotes_verdict_to_broken() -> None:
    """v0.1.21.2: edge ``stale chain`` row used to be flagged in the
    Component Health table only — top-line verdict stayed HEALTHY.
    Now it's BROKEN (silent metering loss is a credibility wall).
    """
    rows = [
        _row("Daemon", "healthy"),
        _row("Edge", "stale chain"),
        _row("Cert trust", "trusted"),
        _row("System proxy", "enabled"),
    ]
    summary = lifecycle._compute_health_summary_macos(rows, "apps")
    assert summary.severity == "BROKEN"
    assert "stale" in summary.message.lower()


# --------------------------------------------------------------------------- #
# v0.1.21.3: bootout-then-bootstrap idempotency                                #
# --------------------------------------------------------------------------- #


def test_launchctl_reload_calls_bootout_then_bootstrap(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """``_launchctl_reload`` always calls bootout BEFORE bootstrap.

    v0.1.21.3 fix for the user-soak bug where ``launchctl bootstrap``
    on an already-registered label returns rc=5 EIO ("Input/output
    error") with neither "already" nor "loaded" in stderr — v0.1.21.2's
    substring detection missed it and false-failed init. Clearing
    first is robust and idempotent.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        calls.append(argv)
        if "print" in argv:
            # v0.1.21.4: simulate label absent → poll exits immediately.
            return _completed(1, stderr="Could not find specified service")
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert err == ""
    # v0.1.21.4: order is bootout → print (poll until label absent) →
    # bootstrap. With print returning rc=1 on the first poll, exactly
    # three calls fire.
    assert len(calls) == 3
    assert calls[0][:2] == ["launchctl", "bootout"]
    assert calls[1][:2] == ["launchctl", "print"]
    assert calls[2][:2] == ["launchctl", "bootstrap"]
    assert str(plist_path) in calls[2]


def test_launchctl_reload_succeeds_when_bootout_fails(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Bootout of an unregistered label returns non-zero; reload still
    proceeds to bootstrap and reports the bootstrap rc.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootout" in argv:
            # Simulate "not loaded" — bootout rc=3 with stderr.
            return _completed(3, stderr="Could not find specified service")
        if "print" in argv:
            # v0.1.21.4: label was never loaded → print rc != 0.
            return _completed(1)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)
    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert err == ""


def test_launchctl_reload_propagates_real_bootstrap_failure(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """If bootstrap returns non-zero AFTER the bootout (e.g. plist
    syntax error), surface the failure — that's a real error, not
    the "already loaded" steady-state we cleared.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootout" in argv:
            return _completed(0)
        if "print" in argv:
            return _completed(1)
        return _completed(112, stderr="Bootstrap failed: 5: Input/output error")

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)
    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 112
    assert "Input/output" in err



def test_start_probe_health_uses_25s_ceiling(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.3 bumped the start probe ceiling from 10s to 25s for
    cold-start headroom on slow machines. Verify the deadline is set
    25s out from probe start.
    """
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda p, timeout: (False, None),
    )

    t = [0.0]

    def fake_monotonic() -> float:
        return t[0]

    def fake_sleep(s: float) -> None:
        t[0] += s

    monkeypatch.setattr(lifecycle.time, "monotonic", fake_monotonic)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    healthy, _last_ms, _elapsed = lifecycle._start_probe_health(api_port=8765)
    assert healthy is False
    # Loop must advance past 25s — v0.1.21.2's 10s ceiling would stop ~10s.
    assert t[0] >= 25.0


# --------------------------------------------------------------------------- #
# v0.1.21.4: async bootout + start short-circuit + own-edge recognition       #
# --------------------------------------------------------------------------- #


def test_launchctl_reload_polls_for_label_disappearance(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """``_launchctl_reload`` polls ``launchctl print`` between bootout
    and bootstrap until the label is gone (rc != 0). On macOS, bootout
    is async and bootstrap on a still-loaded label returns rc=5 EIO.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    print_calls: list[int] = [0]

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "print" in argv:
            print_calls[0] += 1
            # First 3 polls: label still present (bootout in flight).
            # 4th poll onward: rc != 0 (label gone).
            if print_calls[0] < 4:
                return _completed(0)
            return _completed(1)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert err == ""
    # Polled exactly until the label disappeared (4 polls).
    assert print_calls[0] == 4


def test_launchctl_reload_poll_timeout_proceeds_to_bootstrap(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """When the poll never observes label disappearance, bootstrap
    still fires after ~20 polls (the 2s ceiling). Don't block forever.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    print_calls: list[int] = [0]
    bootstrap_fired: list[bool] = [False]

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "print" in argv:
            print_calls[0] += 1
            return _completed(0)  # Always-loaded — never disappears.
        if "bootstrap" in argv:
            bootstrap_fired[0] = True
        return _completed(0)

    sleep_total: list[float] = [0.0]

    def fake_sleep(s: float) -> None:
        sleep_total[0] += s

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    rc, _err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    # Polled to the ceiling (20) and then proceeded to bootstrap.
    assert print_calls[0] == 20
    assert bootstrap_fired[0] is True
    # Total simulated sleep <= 2s (20 polls of 0.1s each).
    assert sleep_total[0] <= 2.0 + 1e-6


def test_start_macos_short_circuits_on_health_alone(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.4: ``halton-meter start`` short-circuits to OK when
    /health responds 200, regardless of watchdog liveness. Reproduces
    the user-soak bug where a healthy daemon + dormant watchdog had
    ``start`` re-bootstrap and false-fail on its own running edge.
    """
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (True, 4.5)
    )

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return 6968
        if label == lifecycle._WATCHDOG_LABEL:
            return 6969
        return None

    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", fake_pid)

    bootstrap_attempts: list[str] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            bootstrap_attempts.append(" ".join(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)

    rc = lifecycle.start()
    assert rc == 0
    # Critical: no bootstrap fired — we short-circuited.
    assert bootstrap_attempts == []


def test_start_macos_short_circuit_kickstarts_dormant_watchdog(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Daemon healthy, watchdog dormant → opportunistically kickstart
    the watchdog (cheap; brings the defensive layer back).
    """
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (True, 3.0)
    )

    pid_state = {"watchdog": None}

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return 6968
        if label == lifecycle._WATCHDOG_LABEL:
            return pid_state["watchdog"]
        return None

    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", fake_pid)

    kickstart_calls: list[str] = []

    def fake_kickstart(label: str, *, kill_existing: bool = True) -> tuple[int, str]:
        kickstart_calls.append(label)
        # Now watchdog has a PID.
        pid_state["watchdog"] = 7777
        return (0, "")

    monkeypatch.setattr(lifecycle._macos, "_launchctl_kickstart", fake_kickstart)

    rc = lifecycle.start()
    assert rc == 0
    assert kickstart_calls == [lifecycle._WATCHDOG_LABEL]


def test_our_managed_pids_includes_edge_label(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.4: ``_our_managed_pids`` returns edge + userenv PIDs
    too, so ``_start_macos`` Step 3 doesn't false-flag our own running
    edge as an orphan port-squatter.
    """
    pid_map = {
        lifecycle._LABEL: 1001,
        lifecycle._WATCHDOG_LABEL: 1002,
        lifecycle._EDGE_LABEL: 6975,
        lifecycle._USERENV_LABEL: None,
    }
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_label_pid", lambda label: pid_map.get(label)
    )
    pids = lifecycle._our_managed_pids()
    assert 1001 in pids
    assert 1002 in pids
    assert 6975 in pids, (
        "edge PID must be recognised as managed; otherwise `start` "
        "false-flags our own edge as a port-squatter (user-soak bug)."
    )


def test_start_macos_ignores_client_connections_on_edge_port(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.22.1 Bug 1: the daily-driver-killer — Windsurf Helper /
    Claude Code / etc. has an ESTABLISHED client connection to our
    edge on 8082 at the moment the user runs ``start``. The bare
    ``lsof -i :PORT`` returned the client PID alongside the listener
    and start refused with "port held by PID X (Windsurf Helper)".

    Fix: ``start`` no longer checks the edge port at all (the daemon
    doesn't bind it), and the daemon-port check now uses LISTEN-only
    lsof. Either fix alone would have caught this; both apply.
    """
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)

    # Simulate Windsurf Helper PID 8998 with an ESTABLISHED client
    # connection to 127.0.0.1:9080 (the edge port in test cfg). The
    # bare-lsof helper would return [8998] on port 9080; the LISTEN
    # helper does not — that's the fix.
    def fake_listen_lsof(port: int) -> list[int]:
        # Daemon ports clear; edge port has the listener but we should
        # never be queried for it post-fix.
        if port == 9080:
            pytest.fail(
                "start pre-flight must not check the edge port — the "
                "daemon does not bind it"
            )
        return []

    monkeypatch.setattr(lifecycle._macos, "_lsof_listen_pids_on_port", fake_listen_lsof)
    # Keep the ALL-states helper present; if the regression returns,
    # this would surface PID 8998 as a "holder" of port 9080.
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_pids_on_port",
        lambda port: [8998] if port == 9080 else [],
    )
    monkeypatch.setattr(lifecycle._macos, "_process_name", lambda pid: "Windsurf Helper")
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (True, 1.0, 1.5)
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    assert rc == 0


def test_start_macos_refuses_foreign_listener_on_daemon_port(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Symmetry guard: a foreign process LISTENING on the daemon's
    api_port (8765) or internal_port (8090) must STILL be rejected.
    Bug 1's fix narrowed which ports are checked but did not weaken
    the check for the ports we DO own.
    """
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
    # Foreign rogue listening on api_port.
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_listen_pids_on_port",
        lambda port: [99999] if port == 8765 else [],
    )
    monkeypatch.setattr(lifecycle._macos, "_process_name", lambda pid: "rogue-python")

    rc = lifecycle.start()
    assert rc == 1


def test_start_macos_accepts_own_listener_on_daemon_port(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression guard for v0.1.21.4 own-process self-recognition.

    If our own daemon (orphaned from a prior crash, still launchctl-
    registered) is somehow listening on 8765 / 8090 at start time,
    ``_our_managed_pids()`` recognises the PID and start does NOT
    refuse. Same predicate as the v0.1.21.4 fix; just expressed
    against the daemon ports rather than the (no-longer-checked)
    edge port.
    """
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    pid_map = {
        lifecycle._LABEL: 4242,
        lifecycle._WATCHDOG_LABEL: None,
        lifecycle._EDGE_LABEL: None,
        lifecycle._USERENV_LABEL: None,
    }
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_label_pid", lambda label: pid_map.get(label)
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_listen_pids_on_port",
        lambda port: [4242] if port == 8765 else [],
    )
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (True, 1.0, 1.5)
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    assert rc == 0


# --------------------------------------------------------------------------- #
# v0.1.22 hardening: _print_err_log_tail since_wall_time filter               #
# --------------------------------------------------------------------------- #


def _write_err_log(tmp_path: Path, content: str) -> Path:
    """Helper: write ``content`` to a ``daemon.err.log`` inside ``tmp_path``
    and return the ``~/.halton-meter`` dir so callers can monkeypatch ``Path.home``.
    """
    hm_dir = tmp_path / ".halton-meter"
    hm_dir.mkdir()
    log_file = hm_dir / "daemon.err.log"
    log_file.write_text(content)
    return tmp_path


def test_print_err_log_tail_no_filter_shows_all(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When ``since_wall_time`` is None, all lines are shown (legacy behaviour)."""
    import io as _io
    import json as _json
    from pathlib import Path as _Path

    from rich.console import Console as _Console

    home_dir = _write_err_log(tmp_path, "\n".join([
        _json.dumps({"timestamp": "2026-05-06T04:00:00.000000Z", "event": "old_session"}),
        _json.dumps({"timestamp": "2026-05-06T13:00:00.000000Z", "event": "new_session"}),
    ]))
    monkeypatch.setattr(_Path, "home", classmethod(lambda cls: home_dir))

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_err_log_tail(console)
    output = buf.getvalue()
    assert "old_session" in output
    assert "new_session" in output


def test_print_err_log_tail_since_wall_time_filters_old_lines(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """With ``since_wall_time`` set, only lines at or after the cutoff are shown.

    This is the fix for the stale-log-tail regression: when the daemon
    probe times out before the daemon writes anything, the failure panel
    must NOT show log lines from the previous session (which could be
    hours old), because that's misleading.
    """
    import datetime as _dt
    import io as _io
    import json as _json
    from pathlib import Path as _Path

    from rich.console import Console as _Console

    home_dir = _write_err_log(tmp_path, "\n".join([
        _json.dumps({"timestamp": "2026-05-06T04:00:00.000000Z", "event": "old_session_event"}),
        _json.dumps({"timestamp": "2026-05-06T13:00:00.000000Z", "event": "new_session_event"}),
    ]))
    monkeypatch.setattr(_Path, "home", classmethod(lambda cls: home_dir))

    # Cutoff just before the new line's timestamp (noon).
    cutoff_wall = _dt.datetime(2026, 5, 6, 12, 0, 0, tzinfo=_dt.UTC).timestamp()

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_err_log_tail(console, since_wall_time=cutoff_wall)
    output = buf.getvalue()

    assert "old_session_event" not in output, (
        "old log lines must be filtered out when since_wall_time is set"
    )
    assert "new_session_event" in output, (
        "new log lines must appear when they are at or after since_wall_time"
    )


def test_print_err_log_tail_since_wall_time_shows_note_when_no_new_lines(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When all log lines are older than ``since_wall_time``, show a note
    rather than a stale tail — the daemon may still be starting.
    """
    import datetime as _dt
    import io as _io
    import json as _json
    from pathlib import Path as _Path

    from rich.console import Console as _Console

    home_dir = _write_err_log(tmp_path, _json.dumps({
        "timestamp": "2026-05-06T04:00:00.000000Z",
        "event": "previous_session",
    }))
    monkeypatch.setattr(_Path, "home", classmethod(lambda cls: home_dir))

    # Cutoff well after the only log line.
    cutoff_wall = _dt.datetime(2026, 5, 6, 13, 0, 0, tzinfo=_dt.UTC).timestamp()

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_err_log_tail(console, since_wall_time=cutoff_wall)
    output = buf.getvalue()

    assert "previous_session" not in output, (
        "must not show stale lines from a previous session"
    )
    assert "no new entries" in output.lower() or "still be" in output.lower(), (
        "must show a note that the daemon may still be starting"
    )


def test_print_err_log_tail_includes_non_json_lines_after_recent_ts(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-JSON lines (traceback frames, plain stderr) that immediately follow
    a recent timestamped JSON line are included — they are likely continuation
    output from the same crash event.
    """
    import datetime as _dt
    import io as _io
    import json as _json
    from pathlib import Path as _Path

    from rich.console import Console as _Console

    new_ts = "2026-05-06T13:00:00.000000Z"
    home_dir = _write_err_log(tmp_path, "\n".join([
        _json.dumps({"timestamp": new_ts, "event": "exception_event"}),
        "Traceback (most recent call last):",
        '  File "proxy.py", line 42, in handle',
        "ValueError: bad token",
    ]))
    monkeypatch.setattr(_Path, "home", classmethod(lambda cls: home_dir))

    cutoff_wall = _dt.datetime(2026, 5, 6, 12, 0, 0, tzinfo=_dt.UTC).timestamp()

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_err_log_tail(console, since_wall_time=cutoff_wall)
    output = buf.getvalue()

    assert "exception_event" in output
    assert "Traceback" in output
    assert "ValueError" in output


# --------------------------------------------------------------------------- #
# v0.1.22.1 fix: ConsoleRenderer-format log lines must be filterable          #
# --------------------------------------------------------------------------- #
#
# Root-cause regression (2026-05-07): the daemon's ``_configure_daemon_logging``
# uses ``structlog.dev.ConsoleRenderer(colors=False)`` — plain text, NOT JSON.
# Pre-fix the filter only parsed JSON lines, so it dropped EVERY daemon-written
# event and rendered "no new entries since start was invoked" even when the
# daemon had logged a full crash trace, hiding the actual failure cause.


def test_print_err_log_tail_parses_console_renderer_format(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Lines in structlog ConsoleRenderer format (ISO-8601 timestamp at the
    start of the line, then ``[level     ]``) must be filterable by
    ``since_wall_time``. This is the format the live daemon writes.
    """
    import datetime as _dt
    import io as _io
    from pathlib import Path as _Path

    from rich.console import Console as _Console

    home_dir = _write_err_log(tmp_path, "\n".join([
        "2026-05-06T04:00:00.000000Z [info     ] daemon.startup.phase           "
        "phase=entered pid=11111",
        "2026-05-06T13:00:00.000000Z [info     ] daemon.startup.phase           "
        "phase=entered pid=22222",
        "2026-05-06T13:00:01.000000Z [info     ] daemon.startup.ready           "
        "api_port=8765",
    ]))
    monkeypatch.setattr(_Path, "home", classmethod(lambda cls: home_dir))

    # Cutoff just before the new lines (noon).
    cutoff_wall = _dt.datetime(2026, 5, 6, 12, 0, 0, tzinfo=_dt.UTC).timestamp()

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_err_log_tail(console, since_wall_time=cutoff_wall)
    output = buf.getvalue()

    assert "pid=11111" not in output, (
        "pre-cutoff ConsoleRenderer line must be filtered out"
    )
    assert "pid=22222" in output, (
        "post-cutoff ConsoleRenderer line must be retained — without "
        "this the failure-panel diagnostic hides the actual daemon "
        "startup events and the user sees a misleading 'no new entries' note"
    )
    assert "daemon.startup.ready" in output, (
        "post-cutoff ConsoleRenderer line must be retained"
    )


def test_print_err_log_tail_console_renderer_with_traceback(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Crash tracebacks following a recent ConsoleRenderer line must be shown.

    Critical for diagnosing daemon crashes: when the daemon dies during
    asyncio init it logs one ``daemon.startup.phase`` event then prints
    a Python traceback. The filter must include both.
    """
    import datetime as _dt
    import io as _io
    from pathlib import Path as _Path

    from rich.console import Console as _Console

    home_dir = _write_err_log(tmp_path, "\n".join([
        "2026-05-06T13:00:00.000000Z [info     ] daemon.startup.phase           "
        "phase=entered pid=99999",
        "Traceback (most recent call last):",
        '  File "proxy.py", line 42, in run_proxy',
        "RuntimeError: mitmproxy CA cert missing",
    ]))
    monkeypatch.setattr(_Path, "home", classmethod(lambda cls: home_dir))

    cutoff_wall = _dt.datetime(2026, 5, 6, 12, 0, 0, tzinfo=_dt.UTC).timestamp()

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_err_log_tail(console, since_wall_time=cutoff_wall)
    output = buf.getvalue()

    assert "phase=entered" in output
    assert "Traceback" in output
    assert "RuntimeError" in output
    assert "mitmproxy CA cert missing" in output


def test_parse_log_line_timestamp_handles_both_formats() -> None:
    """The timestamp parser must accept ConsoleRenderer + JSON formats."""
    import json as _json
    from datetime import UTC, datetime

    # ConsoleRenderer format.
    ts = lifecycle._macos._parse_log_line_timestamp(
        "2026-05-06T13:00:00.000000Z [info     ] daemon.startup.phase phase=entered",
        _json,
    )
    assert ts is not None
    assert ts == datetime(2026, 5, 6, 13, 0, 0, tzinfo=UTC)

    # JSON format.
    ts = lifecycle._macos._parse_log_line_timestamp(
        _json.dumps({"timestamp": "2026-05-06T13:00:00.000000Z", "event": "x"}),
        _json,
    )
    assert ts is not None
    assert ts == datetime(2026, 5, 6, 13, 0, 0, tzinfo=UTC)

    # Non-timestamped line (traceback continuation).
    assert lifecycle._macos._parse_log_line_timestamp(
        "Traceback (most recent call last):", _json
    ) is None
    # Empty line.
    assert lifecycle._macos._parse_log_line_timestamp("", _json) is None


# --------------------------------------------------------------------------- #
# v0.1.22.1 fix: post-failure launchctl PID diagnostic                        #
# --------------------------------------------------------------------------- #


def test_print_launchctl_state_alive_pid(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When launchctl reports a live PID, the diagnostic line says so.

    This is the load-bearing distinguisher between "daemon is slow at
    cold start, retry" and "daemon spawned-and-crashed, see log".
    """
    import io as _io

    from rich.console import Console as _Console

    monkeypatch.setattr(lifecycle._macos.sys, "platform", "darwin")
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_label_pid", lambda label: 12345
    )

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_launchctl_state(console, "com.haltonlabs.meter")
    output = buf.getvalue()

    assert "alive" in output
    assert "12345" in output


def test_print_launchctl_state_label_loaded_no_pid(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Label registered but no PID = spawn failed / process exited."""
    import io as _io

    from rich.console import Console as _Console

    monkeypatch.setattr(lifecycle._macos.sys, "platform", "darwin")
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle._macos, "_gui_uid", lambda: 501)
    monkeypatch.setattr(
        lifecycle._macos,
        "_launchctl_label_loaded",
        lambda uid, label: (True, 0, ""),
    )

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_launchctl_state(console, "com.haltonlabs.meter")
    output = buf.getvalue()

    assert "registered" in output
    assert "not running" in output


def test_print_launchctl_state_label_unloaded(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Label not loaded at all = bootstrap silently rolled back."""
    import io as _io

    from rich.console import Console as _Console

    monkeypatch.setattr(lifecycle._macos.sys, "platform", "darwin")
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle._macos, "_gui_uid", lambda: 501)
    monkeypatch.setattr(
        lifecycle._macos,
        "_launchctl_label_loaded",
        lambda uid, label: (False, 113, "not loaded"),
    )

    buf = _io.StringIO()
    console = _Console(file=buf, highlight=False)
    lifecycle._macos._print_launchctl_state(console, "com.haltonlabs.meter")
    output = buf.getvalue()

    assert "NOT" in output or "not" in output
    assert "rc=113" in output


# --------------------------------------------------------------------------- #
# v0.1.22 hardening: _detect_live_daemon requires a live PID                  #
# --------------------------------------------------------------------------- #


def test_detect_live_daemon_returns_false_for_dormant_label(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A registered but dormant label (PID = '-') must return False.

    This is the fix for the init false positive: a dormant daemon (label
    registered via bootstrap but RunAtLoad=False, or stopped via
    ``halton-meter stop``) has no running process, so the "live daemon
    detected" disruption warning must NOT fire for it.
    """
    import subprocess as _subprocess
    import sys as _sys

    from halton_meter import init as _init

    monkeypatch.setattr(_sys, "platform", "darwin")
    monkeypatch.setattr(_init.os, "getuid", lambda: 501)

    run_calls: list[list[str]] = []

    def fake_run(args: list[str], **kwargs: object) -> object:
        run_calls.append(args)
        # launchctl print → rc=0 (label is registered)
        if "print" in args:
            return _subprocess.CompletedProcess(args, 0, b"", b"")
        # launchctl list → rc=0 but PID = '-' (dormant)
        if "list" in args:
            output = '"PID" = -;\n"LastExitStatus" = 0;\n'
            return _subprocess.CompletedProcess(args, 0, output, "")
        return _subprocess.CompletedProcess(args, 1, "", "")

    monkeypatch.setattr(_subprocess, "run", fake_run)

    result = _init._detect_live_daemon()
    assert result is False, (
        "_detect_live_daemon must return False for a dormant label (PID='-')"
    )


def test_detect_live_daemon_returns_true_for_running_label(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A running label (numeric PID) must return True."""
    import subprocess as _subprocess
    import sys as _sys

    from halton_meter import init as _init

    monkeypatch.setattr(_sys, "platform", "darwin")
    monkeypatch.setattr(_init.os, "getuid", lambda: 501)

    def fake_run(args: list[str], **kwargs: object) -> object:
        if "print" in args:
            return _subprocess.CompletedProcess(args, 0, b"", b"")
        if "list" in args:
            output = '"PID" = 12345;\n"LastExitStatus" = 0;\n'
            return _subprocess.CompletedProcess(args, 0, output, "")
        return _subprocess.CompletedProcess(args, 1, "", "")

    monkeypatch.setattr(_subprocess, "run", fake_run)

    result = _init._detect_live_daemon()
    assert result is True, (
        "_detect_live_daemon must return True when a numeric PID is reported"
    )


def test_detect_live_daemon_returns_false_for_unknown_label(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An unregistered label must return False (launchctl print rc != 0)."""
    import subprocess as _subprocess
    import sys as _sys

    from halton_meter import init as _init

    monkeypatch.setattr(_sys, "platform", "darwin")
    monkeypatch.setattr(_init.os, "getuid", lambda: 501)

    def fake_run(args: list[str], **kwargs: object) -> object:
        # launchctl print returns non-zero (label not registered)
        if "print" in args:
            return _subprocess.CompletedProcess(args, 113, b"", b"Could not find service")
        return _subprocess.CompletedProcess(args, 0, "", "")

    monkeypatch.setattr(_subprocess, "run", fake_run)

    result = _init._detect_live_daemon()
    assert result is False


# --------------------------------------------------------------------------- #
# v0.1.22 hardening: rc=5 EIO backoff retry + liveness verification           #
# (decisions.md 2026-05-06 — "v0.1.22 launchctl bootstrap rc=5 hardening")    #
# --------------------------------------------------------------------------- #


def test_launchctl_reload_succeeds_first_attempt(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Happy path: bootstrap rc=0 on first attempt → no retries, no
    backoff sleeps, single bootstrap call."""
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    bootstrap_calls: list[int] = [0]
    backoff_sleeps: list[float] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            bootstrap_calls[0] += 1
            return _completed(0)
        if "print" in argv:
            return _completed(1)
        return _completed(0)

    def fake_sleep(s: float) -> None:
        if s in (1.0, 2.0, 4.0):
            backoff_sleeps.append(s)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert err == ""
    assert bootstrap_calls[0] == 1
    assert backoff_sleeps == []


def test_launchctl_reload_rc5_succeeds_on_second_attempt(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """First bootstrap rc=5; backoff 1s; second bootstrap rc=0.
    Total: 2 bootstrap calls, exactly one 1.0s backoff sleep."""
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    bootstrap_calls: list[int] = [0]

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            bootstrap_calls[0] += 1
            if bootstrap_calls[0] == 1:
                return _completed(5, stderr="Bootstrap failed: 5: Input/output error")
            return _completed(0)
        if "print" in argv:
            return _completed(1)
        return _completed(0)

    backoff_sleeps: list[float] = []

    def fake_sleep(s: float) -> None:
        if s in (1.0, 2.0, 4.0):
            backoff_sleeps.append(s)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    rc, _err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert bootstrap_calls[0] == 2
    assert backoff_sleeps == [1.0]


def test_launchctl_reload_rc5_succeeds_on_third_attempt(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """First two bootstrap calls return rc=5; third returns rc=0.
    Total: 3 bootstrap calls, backoff sleeps [1.0, 2.0]."""
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    bootstrap_calls: list[int] = [0]

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            bootstrap_calls[0] += 1
            if bootstrap_calls[0] <= 2:
                return _completed(5, stderr="Bootstrap failed: 5: Input/output error")
            return _completed(0)
        if "print" in argv:
            return _completed(1)
        return _completed(0)

    backoff_sleeps: list[float] = []

    def fake_sleep(s: float) -> None:
        if s in (1.0, 2.0, 4.0):
            backoff_sleeps.append(s)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    rc, _err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert bootstrap_calls[0] == 3
    assert backoff_sleeps == [1.0, 2.0]


def test_launchctl_reload_rc5_label_actually_loaded_treated_as_success(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """All 4 bootstrap attempts return rc=5, but the post-failure
    liveness check shows the label IS loaded. Treat as success."""
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    bootstrap_calls: list[int] = [0]

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            bootstrap_calls[0] += 1
            return _completed(5, stderr="Bootstrap failed: 5: Input/output error")
        if "print" in argv:
            # During bootout polls (between attempts) report absent;
            # post-failure liveness check (after 4 bootstraps) report
            # loaded.
            if bootstrap_calls[0] >= 4:
                return _completed(0)
            return _completed(1)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc, _err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    # 1 initial + 3 retries = 4 bootstrap calls.
    assert bootstrap_calls[0] == 4


def test_launchctl_reload_rc5_exhausted_returns_failure_with_diagnostics(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """All 4 bootstrap attempts return rc=5 AND liveness check shows
    label NOT loaded. Returns (5, stderr); writes diagnostics to
    install.err.log."""
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    err_log = tmp_path / "install.err.log"
    monkeypatch.setattr(lifecycle._macos, "_INSTALL_ERR_LOG", err_log)

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            return _completed(5, stderr="Bootstrap failed: 5: Input/output error")
        if "print" in argv:
            return _completed(1, stderr="Could not find specified service")
        if "list" in argv:
            return _completed(1, stdout="")
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 5
    assert "Input/output" in err
    assert err_log.exists()
    contents = err_log.read_text()
    assert "bootstrap exhausted" in contents
    assert label in contents
    assert str(plist_path) in contents
    assert "print_rc" in contents
    assert "list_rc" in contents


def test_launchctl_reload_non_rc5_error_fails_fast(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Non-rc=5 errors surface immediately — no retry storm."""
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    bootstrap_calls: list[int] = [0]
    backoff_sleeps: list[float] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            bootstrap_calls[0] += 1
            return _completed(137, stderr="Bootstrap failed: 137: bad plist")
        if "print" in argv:
            return _completed(1)
        return _completed(0)

    def fake_sleep(s: float) -> None:
        if s in (1.0, 2.0, 4.0):
            backoff_sleeps.append(s)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 137
    assert "bad plist" in err
    assert bootstrap_calls[0] == 1
    assert backoff_sleeps == []


# --------------------------------------------------------------------------- #
# v0.1.22 graceful-shutdown sentinel clear on start                            #
# --------------------------------------------------------------------------- #


def test_start_macos_clears_graceful_shutdown_sentinel(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.22: ``_start_macos`` must clear ``~/.halton-meter/graceful-shutdown``
    before kickstart, otherwise a rapid ``stop && start`` round-trip falls
    inside the 30s suppression window and the freshly-spawned daemon exits
    "graceful_shutdown_active" before /health can come up.
    """
    from halton_meter import graceful_shutdown as gs

    sentinel = tmp_path / "graceful-shutdown"
    sentinel.write_text("999.0\n")
    monkeypatch.setattr(gs, "GRACEFUL_SHUTDOWN_SENTINEL_PATH", sentinel)

    # Force the full bootstrap+kickstart path (not the short-circuit).
    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())

    pid_state = {"daemon": 4242, "watchdog": 4243}

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return pid_state["daemon"]
        if label == lifecycle._WATCHDOG_LABEL:
            return pid_state["watchdog"]
        return None

    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", fake_pid)
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health",
        lambda port: (True, 3.2, 5.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)

    rc = lifecycle.start()
    assert rc == 0
    assert not sentinel.exists(), (
        "_start_macos must remove the graceful-shutdown sentinel so the "
        "freshly-kickstarted daemon does not exit graceful_shutdown_active "
        "inside the 30s suppression window"
    )


def test_start_macos_clears_sentinel_before_kickstart(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Ordering invariant: sentinel clear must precede the kickstart call."""
    from halton_meter import graceful_shutdown as gs

    sentinel = tmp_path / "graceful-shutdown"
    sentinel.write_text("999.0\n")
    monkeypatch.setattr(gs, "GRACEFUL_SHUTDOWN_SENTINEL_PATH", sentinel)

    monkeypatch.setattr(
        lifecycle._macos, "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(
        lifecycle._macos, "_launchctl_label_pid",
        lambda label: 4242 if label == lifecycle._LABEL else 4243,
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health",
        lambda port: (True, 3.2, 5.0),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: True
    )
    monkeypatch.setattr(
        lifecycle._macos, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle._macos, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    events: list[str] = []
    real_unlink = Path.unlink

    def tracking_unlink(self: Path, *a: Any, **kw: Any) -> None:
        if self == sentinel:
            events.append("clear_sentinel")
        return real_unlink(self, *a, **kw)

    monkeypatch.setattr(Path, "unlink", tracking_unlink)

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "kickstart" in argv:
            events.append("kickstart")
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)

    rc = lifecycle.start()
    assert rc == 0
    assert "clear_sentinel" in events, events
    assert "kickstart" in events, events
    assert events.index("clear_sentinel") < events.index("kickstart"), events


def test_clear_graceful_shutdown_sentinel_helper_idempotent(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The helper is unconditional + idempotent. Calling it on a missing
    file is a no-op; calling it on an existing file removes it; calling
    it twice in a row never raises.
    """
    from halton_meter import graceful_shutdown as gs

    sentinel = tmp_path / "graceful-shutdown"
    monkeypatch.setattr(gs, "GRACEFUL_SHUTDOWN_SENTINEL_PATH", sentinel)

    # Missing -> no-op, no raise.
    gs.clear_graceful_shutdown_sentinel()
    assert not sentinel.exists()

    # Present -> removed.
    sentinel.write_text("999.0\n")
    gs.clear_graceful_shutdown_sentinel()
    assert not sentinel.exists()

    # Second call -> still no-op.
    gs.clear_graceful_shutdown_sentinel()
    assert not sentinel.exists()


# --------------------------------------------------------------------------- #
# v0.1.22.1 Bug 1: LISTEN-only lsof helper                                     #
# --------------------------------------------------------------------------- #


_REAL_LSOF_LISTEN_PIDS = lifecycle._macos._lsof_listen_pids_on_port


def test_lsof_listen_pids_filters_to_listen_state(monkeypatch: pytest.MonkeyPatch) -> None:
    """``_lsof_listen_pids_on_port`` must invoke ``lsof`` with the
    ``-sTCP:LISTEN`` filter, so transient ESTABLISHED client
    connections do not appear in the result.
    """
    captured_argv: list[str] = []

    def fake_run(argv: list[str], **kwargs: Any) -> Any:
        captured_argv.extend(argv)

        class _R:
            returncode = 0
            stdout = "8123\n"

        return _R()

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    # Restore the real helper (the autouse default-empty fixture
    # stubs it to ``[]`` for the rest of the suite).
    monkeypatch.setattr(
        lifecycle._macos, "_lsof_listen_pids_on_port", _REAL_LSOF_LISTEN_PIDS
    )
    pids = lifecycle._macos._lsof_listen_pids_on_port(8765)
    assert pids == [8123]
    assert "-sTCP:LISTEN" in captured_argv, (
        "the helper MUST pass -sTCP:LISTEN; otherwise it returns "
        "ESTABLISHED client connections alongside listeners and the "
        "user-soak Bug 1 regression returns."
    )
    # v0.1.22.2 (B1-redux): the port selector MUST be a single
    # ``-iTCP:<port>`` argument. The previous shape split it into two
    # ``-i`` flags (``-iTCP`` + ``-i:<port>``); lsof unions multiple
    # ``-i`` filters (OR-semantics), which made this helper return
    # every TCP listener on the box regardless of port. The combined
    # form is the canonical "TCP listener on this port" idiom.
    assert "-iTCP:8765" in captured_argv, (
        "expected single combined -iTCP:<port> selector; the broken "
        "form split into -iTCP + -i:<port> matches every TCP listener "
        "on the box (OR-semantics), not just listeners on this port."
    )
    assert "-iTCP" not in captured_argv, (
        "regression guard: the bare -iTCP token (without the :port "
        "suffix) means the argv was split into two -i selectors and "
        "lsof OR-unions them. Stay on the single -iTCP:<port> form."
    )
    assert "-i:8765" not in captured_argv


def test_lsof_listen_pids_returns_empty_when_lsof_unavailable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def boom(*_a: object, **_kw: object) -> Any:
        raise OSError("lsof not on PATH")

    monkeypatch.setattr(lifecycle.subprocess, "run", boom)
    monkeypatch.setattr(
        lifecycle._macos, "_lsof_listen_pids_on_port", _REAL_LSOF_LISTEN_PIDS
    )
    assert lifecycle._macos._lsof_listen_pids_on_port(8765) == []


# --------------------------------------------------------------------------- #
# v0.1.22.1 Bug 3: per-interface system-proxy-reset print demoted              #
# --------------------------------------------------------------------------- #


def test_reset_macos_system_proxy_does_not_console_print_per_interface(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.22.1: ``_reset_macos_system_proxy`` must not write a
    per-interface line to the console. The aggregated result is
    rendered inside the ``stop`` panel one row up; printing each
    interface here as well leaks plain text above the panel.
    """
    from halton_meter import system_proxy

    monkeypatch.setattr(
        system_proxy._macos, "_macos_interfaces", lambda: ("Wi-Fi", "Thunderbolt Bridge")
    )
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))

    captured: list[str] = []

    class _Recording:
        def print(self, *args: object, **_kwargs: object) -> None:
            captured.append(" ".join(str(a) for a in args))

    succeeded = lifecycle._macos._reset_macos_system_proxy(_Recording())
    assert succeeded == ["Wi-Fi", "Thunderbolt Bridge"]
    assert captured == [], (
        "per-interface result must NOT be printed; it duplicates the "
        "stop panel's aggregated 'System proxy reset on: ...' line "
        "and previously rendered as a bare 'system proxy reset on Wi-Fi' "
        "leak above the panel."
    )


# --------------------------------------------------------------------------- #
# v0.1.22.2 (B1-redux): real-lsof integration test for the LISTEN-only helper #
# --------------------------------------------------------------------------- #


def test_lsof_listen_pids_on_port_returns_only_target_port_listener(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Real-lsof integration test for ``_lsof_listen_pids_on_port``.

    This is the test the v0.1.22.1 unit test should have been: we open
    TWO real TCP listeners on TWO ephemeral ports inside the test
    process, then assert ``_lsof_listen_pids_on_port(port_a)`` returns
    THIS process's PID and the helper's port filter actually constrains
    the result.

    The previous argv-mock-only test was confidently green even when the
    argv had an OR-semantics bug (``-iTCP -i:<port>`` returns every TCP
    listener on the box, not just listeners on ``<port>``). A real-lsof
    test catches that class of bug because the kernel is the source of
    truth, not the argv list.
    """
    import os
    import shutil
    import socket

    if shutil.which("lsof") is None:
        pytest.skip("lsof not available on this PATH")

    # Restore the real helper (autouse fixture stubs it to ``[]``).
    monkeypatch.setattr(
        lifecycle._macos, "_lsof_listen_pids_on_port", _REAL_LSOF_LISTEN_PIDS
    )

    sock_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock_a.bind(("127.0.0.1", 0))
        sock_a.listen(8)
        port_a = sock_a.getsockname()[1]

        sock_b.bind(("127.0.0.1", 0))
        sock_b.listen(8)
        port_b = sock_b.getsockname()[1]

        my_pid = os.getpid()

        pids_on_a = lifecycle._macos._lsof_listen_pids_on_port(port_a)
        pids_on_b = lifecycle._macos._lsof_listen_pids_on_port(port_b)

        # Our PID listens on both — must show up in BOTH results.
        assert my_pid in pids_on_a, (
            f"expected my PID {my_pid} in lsof result for port {port_a}; "
            f"got {pids_on_a}. If the result is empty, the helper isn't "
            f"shelling lsof correctly. If the result is non-empty without "
            f"my PID, the helper is matching the wrong set of sockets."
        )
        assert my_pid in pids_on_b

        # The port filter must actually constrain. The other listener
        # (sock_b on port_b) is in this same process, so my_pid will
        # legitimately appear in both queries — that's not the bug we're
        # guarding against. The bug we're guarding against is the helper
        # returning EVERY TCP listener on the box (e.g. system services
        # like ControlCenter, rapportd, mDNSResponder). Verify by asking
        # for an obviously-unbound ephemeral port: the result must be
        # empty (or at most contain our PID if the kernel happened to
        # reuse the slot, which we just freed).
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind(("127.0.0.1", 0))
            free_port = probe.getsockname()[1]
        # Now probe is closed; free_port has nothing listening on it
        # (best-effort — the kernel may reassign on unrelated bind). The
        # helper must return [] for an unused port; if it returns ANY
        # PIDs we are matching too broadly. Retry once if the result is
        # non-empty AND my_pid is in it (kernel reuse race).
        empty_or_my = lifecycle._macos._lsof_listen_pids_on_port(free_port)
        assert empty_or_my == [] or empty_or_my == [my_pid], (
            f"expected [] (or at most [my_pid]) for an unbound port "
            f"{free_port}; got {empty_or_my}. A non-empty result with "
            f"PIDs other than ours means the helper is matching every "
            f"TCP listener on the box (the OR-semantics argv bug)."
        )
    finally:
        sock_a.close()
        sock_b.close()


# --------------------------------------------------------------------------- #
# v0.1.22.2 (B4): _stop_macos must not kill the edge or ESTABLISHED clients   #
# --------------------------------------------------------------------------- #


def test_stop_macos_does_not_kill_edge_port_holders(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.22.2 (B4): ``stop`` must NOT kill anything on the edge port.

    Pre-fix shape: ``_stop_macos`` looped over ``(api_port, edge_port)``
    and SIGTERMed every PID lsof reported, including (a) our own
    launchctl-supervised edge process — which launchd then immediately
    respawned via ``KeepAlive=True``, producing the v0.1.22.2 soak's
    edge respawn loop and the "Task was destroyed but it is pending!"
    log spam — and (b) every ESTABLISHED client connection on the edge
    port (Windsurf Helper, Claude Code, etc.) that happened to be
    making an LLM request at the time, which is hostile to the
    developer's workflow and breaks the cardinal-rule fail-open invariant.

    Stop deliberately leaves the edge running (it stays bound across
    the metering gap so apps inheriting HTTPS_PROXY don't see refused
    connections). The orphan-killer must NOT touch edge_port.
    """
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    # Seed: nothing on api_port, but the edge port is held by a real
    # PID (the live edge listener) AND an ESTABLISHED client.
    edge_listen_pid = 5555  # our edge process
    edge_client_pid = 9999  # a Windsurf Helper currently making a request
    edge_port = cfg_loaded.daemon.edge_port

    listen_seen: dict[int, list[int]] = {edge_port: [edge_listen_pid]}
    all_seen: dict[int, list[int]] = {
        edge_port: [edge_listen_pid, edge_client_pid],
    }
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_listen_pids_on_port",
        lambda port: list(listen_seen.get(port, [])),
    )
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_pids_on_port",
        lambda port: list(all_seen.get(port, [])),
    )
    # Pretend nothing is "managed" so any kill that fires would be
    # observable (the regression must not hide behind the managed-PID
    # filter).
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())

    kills: list[tuple[int, int]] = []

    def fake_kill(pid: int, sig: int) -> None:
        kills.append((pid, sig))

    monkeypatch.setattr(lifecycle.os, "kill", fake_kill)
    times = iter([0.0, 100.0, 0.0, 100.0])
    monkeypatch.setattr(lifecycle.time, "monotonic", lambda: next(times, 100.0))

    rc = lifecycle.stop()
    assert rc == 0
    # Critically: nothing on edge_port should have been killed.
    real_kills = {(pid, sig) for pid, sig in kills if sig != 0}
    assert (edge_listen_pid, lifecycle._signal.SIGTERM) not in real_kills, (
        f"_stop_macos SIGTERMed our edge listener PID {edge_listen_pid}; "
        f"the edge MUST stay running across stop for fail-open. Apps "
        f"inheriting HTTPS_PROXY would see ConnectionRefused otherwise."
    )
    assert (edge_client_pid, lifecycle._signal.SIGTERM) not in real_kills, (
        f"_stop_macos SIGTERMed an ESTABLISHED client PID {edge_client_pid} "
        f"on the edge port. Killing developer tools mid-LLM-request is the "
        f"exact opposite of the cardinal-rule fail-open invariant."
    )


def test_stop_macos_does_not_kill_managed_listener_on_api_port(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``_stop_macos`` must filter our own managed PIDs out of the
    orphan-killer even on the daemon's api_port.

    Bootout is the supervised exit path; SIGKILL/SIGTERM from this
    helper races the launchctl bootout-poll and produces inconsistent
    label state.
    """
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    our_daemon_pid = 4242
    api_port = cfg_loaded.daemon.api_port
    monkeypatch.setattr(
        lifecycle._macos,
        "_lsof_listen_pids_on_port",
        lambda port: [our_daemon_pid] if port == api_port else [],
    )
    monkeypatch.setattr(
        lifecycle._macos, "_our_managed_pids", lambda: {our_daemon_pid}
    )

    kills: list[tuple[int, int]] = []
    monkeypatch.setattr(
        lifecycle.os, "kill", lambda pid, sig: kills.append((pid, sig))
    )
    times = iter([0.0, 100.0, 0.0, 100.0])
    monkeypatch.setattr(lifecycle.time, "monotonic", lambda: next(times, 100.0))

    rc = lifecycle.stop()
    assert rc == 0
    real_kills = {(pid, sig) for pid, sig in kills if sig != 0}
    assert (our_daemon_pid, lifecycle._signal.SIGTERM) not in real_kills, (
        "stop must not SIGTERM a launchctl-managed PID; bootout owns "
        "supervised exit. Killing here races the bootout-poll and leaves "
        "stale label state."
    )


# --------------------------------------------------------------------------- #
# v0.1.22.4: post-success liveness verification + premature-exit panel        #
# --------------------------------------------------------------------------- #


def test_start_post_success_liveness_returns_true_when_daemon_alive(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Healthy re-probe → returns True; daemon stayed up."""
    monkeypatch.setattr(lifecycle._macos, "_POST_SUCCESS_LIVENESS_DELAY_S", 0.0)
    monkeypatch.setattr(
        lifecycle._macos,
        "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.2),
    )

    assert lifecycle._macos._start_post_success_liveness(8765) is True


def test_start_post_success_liveness_returns_false_when_daemon_dies(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Failing re-probe → returns False so the caller renders the
    failure panel instead of the lying success panel.

    Reproduces v0.1.22.3 user-soak: daemon answered /health at the
    25s probe, then exited within ~5s. Pre-fix the success panel
    rendered and `halton-meter status` later showed `dormant` with
    no surfaced reason.
    """
    monkeypatch.setattr(lifecycle._macos, "_POST_SUCCESS_LIVENESS_DELAY_S", 0.0)
    monkeypatch.setattr(
        lifecycle._macos,
        "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )

    assert lifecycle._macos._start_post_success_liveness(8765) is False


def test_start_macos_post_success_death_renders_failure_panel(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """End-to-end: when ``_start_probe_health`` returns True but the
    post-success liveness re-probe fails, the user sees the failure
    panel (with the post-success-died headline) AND the diagnostic
    surface (launchctl state + err-log tail), not the success panel.

    This is the regression test for the 2026-05-07 user-soak bug:
    daemon answered /health then vanished within seconds; pre-fix the
    user saw `Halton Meter — metering active` followed by `dormant`.
    """
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    # Step 2 short-circuit: not already healthy.
    monkeypatch.setattr(
        lifecycle._macos,
        "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 8888)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    # Initial probe wins.
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (True, 16861.0, 16861.0)
    )
    # Post-success liveness loses — the daemon died between the two probes.
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: False
    )
    monkeypatch.setattr(lifecycle._macos, "_print_err_log_tail", lambda *a, **kw: None)
    monkeypatch.setattr(
        lifecycle._macos, "_print_launchctl_state", lambda *a, **kw: None
    )

    rc = lifecycle.start()
    out = capsys.readouterr().out

    assert rc == 1, "post-success death must yield non-zero exit"
    assert "metering active" not in out, (
        "the success panel must NOT render when the daemon answered "
        "/health then vanished"
    )
    assert "daemon failed to start" in out
    # The post-success-specific headline.
    assert "exited within" in out, (
        "failure panel must mention the post-success-death scenario "
        "so the user knows the daemon answered then died"
    )


def test_start_macos_post_success_death_quiet_mode_emits_distinct_line(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """``--quiet`` failure on post-success death emits a single
    grep-friendly line distinct from the timeout failure so scripts can
    distinguish the two.
    """
    monkeypatch.setattr(lifecycle._macos, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle._macos, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle._macos,
        "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )
    monkeypatch.setattr(lifecycle._macos, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle._macos, "_launchctl_label_pid", lambda label: 9999)
    monkeypatch.setattr(lifecycle._macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle._macos, "_start_probe_health", lambda port: (True, 100.0, 100.0)
    )
    monkeypatch.setattr(
        lifecycle._macos, "_start_post_success_liveness", lambda *a, **k: False
    )

    rc = lifecycle.start(quiet=True)
    out = capsys.readouterr().out
    assert rc == 1
    assert "exited" in out
    assert "edge tunnelling" in out


def test_render_start_failure_panel_post_success_died_branch() -> None:
    """The panel renders the post-success-died headline when the kwarg
    is True, and the legacy 25s-timeout headline when it's False.
    """
    from io import StringIO

    from rich.console import Console

    cap_a = StringIO()
    Console(file=cap_a, width=80, record=False, force_terminal=False)
    console_a = Console(file=cap_a, width=80, force_terminal=False)
    lifecycle._macos._render_start_failure_panel(
        console_a, 8765, 8081, post_success_died=True
    )
    out_a = cap_a.getvalue()
    assert "exited within" in out_a
    assert "did not respond" not in out_a

    cap_b = StringIO()
    console_b = Console(file=cap_b, width=80, force_terminal=False)
    lifecycle._macos._render_start_failure_panel(
        console_b, 8765, 8081, post_success_died=False
    )
    out_b = cap_b.getvalue()
    assert "did not respond" in out_b
    assert "exited within" not in out_b
