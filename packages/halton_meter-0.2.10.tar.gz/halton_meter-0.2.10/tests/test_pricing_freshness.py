"""Pricing-freshness tests — v0.1.22.22, Layer 1.

Covers:
  * ``BUNDLED_RATES_DATE`` is a valid ISO-8601 date string and exported
    from the public ``halton_meter.pricing`` namespace.
  * ``bundled_rates_source()`` round-trips through the canonical
    ``rates_source`` field shape (``"bundled-YYYY-MM-DD"``).
  * ``recompute_cost`` returns a 3-tuple and stamps the correct
    ``rates_source`` for both seed and override rows.
  * Migration: ``pricing_rates.is_seed_default`` and
    ``requests.rates_source`` columns are present after init_db on a
    greenfield database, and ``user_version`` is bumped to ≥ 4.
  * Migration is idempotent: calling ``init_db`` twice does not error
    and leaves the DB unchanged.
  * Report header renders the rates line.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from pathlib import Path

import pytest
import pytest_asyncio

from halton_meter.api.services.ingest import recompute_cost
from halton_meter.pricing import (
    BUNDLED_RATES_DATE,
    bundled_rates_source,
    compute_cost_millicents,
)
from halton_meter.storage import init_db, seed_pricing_rates
from halton_meter.storage.engine import _ENGINES, create_engine_for, dispose_engines
from halton_meter.storage.models import PricingRate


@pytest.fixture(autouse=True)
def _reset_engine_cache():
    _ENGINES.clear()
    yield
    _ENGINES.clear()


@pytest_asyncio.fixture
async def seeded_db(tmp_path: Path):
    p = tmp_path / "freshness-test.sqlite"
    engine, sessionmaker = create_engine_for(p)
    await init_db(engine)
    async with sessionmaker() as session:
        await seed_pricing_rates(session)
    yield p, engine, sessionmaker
    await dispose_engines()


# ── Constant + helper ──────────────────────────────────────────────────────


def test_bundled_rates_date_is_iso_string() -> None:
    """``BUNDLED_RATES_DATE`` must be a YYYY-MM-DD literal."""
    assert isinstance(BUNDLED_RATES_DATE, str)
    assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", BUNDLED_RATES_DATE)
    # Round-trip through datetime to catch '2026-13-99' style typos.
    datetime.strptime(BUNDLED_RATES_DATE, "%Y-%m-%d")


def test_bundled_rates_source_format() -> None:
    src = bundled_rates_source()
    assert src == f"bundled-{BUNDLED_RATES_DATE}"
    assert src.startswith("bundled-")


def test_bundled_constant_exported_from_pricing_namespace() -> None:
    """The constant must be importable from ``halton_meter.pricing``."""
    import halton_meter.pricing as pricing

    assert hasattr(pricing, "BUNDLED_RATES_DATE")
    assert hasattr(pricing, "bundled_rates_source")


# ── Migration ──────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_migration_adds_columns_on_greenfield(seeded_db) -> None:
    p, _engine, _ = seeded_db
    import sqlite3

    conn = sqlite3.connect(str(p))
    try:
        # Both new columns must exist.
        rate_cols = {row[1] for row in conn.execute("PRAGMA table_info(pricing_rates)").fetchall()}
        assert "is_seed_default" in rate_cols, rate_cols
        req_cols = {row[1] for row in conn.execute("PRAGMA table_info(requests)").fetchall()}
        assert "rates_source" in req_cols, req_cols

        # user_version must be at least 4 after the migration runs.
        ver = conn.execute("PRAGMA user_version").fetchone()[0]
        assert ver >= 4, ver
    finally:
        conn.close()


@pytest.mark.asyncio
async def test_migration_idempotent(tmp_path: Path) -> None:
    """Calling init_db twice must not error and must leave user_version stable."""
    import sqlite3

    p = tmp_path / "idempotent.sqlite"
    engine, _ = create_engine_for(p)
    await init_db(engine)
    await init_db(engine)  # second run must be a no-op

    conn = sqlite3.connect(str(p))
    try:
        ver = conn.execute("PRAGMA user_version").fetchone()[0]
        assert ver >= 4
    finally:
        conn.close()
    await dispose_engines()


# ── recompute_cost triple ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_recompute_cost_returns_triple_with_bundled_source(seeded_db) -> None:
    _, _, sessionmaker = seeded_db
    async with sessionmaker() as session:
        cost, rate, source = await recompute_cost(
            session=session,
            provider="anthropic",
            model="claude-sonnet-4-6",
            mode="standard",
            requested_at=datetime.now(tz=UTC),
            input_tokens=1_000,
            output_tokens=2_000,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
    assert rate is not None
    assert cost is not None
    assert cost == compute_cost_millicents(
        model="claude-sonnet-4-6",
        input_tokens=1_000,
        output_tokens=2_000,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    # Seed rows are bundled defaults.
    assert source == bundled_rates_source()


@pytest.mark.asyncio
async def test_recompute_cost_marks_override_source(seeded_db) -> None:
    """A non-seed pricing_rates row produces ``rates_source = "override"``."""
    import uuid

    _, _, sessionmaker = seeded_db
    async with sessionmaker() as session:
        # Insert a future-dated override that supersedes the seed for one model.
        override = PricingRate(
            id=str(uuid.uuid4()),
            provider="anthropic",
            model="claude-sonnet-4-6",
            mode="standard",
            effective_from=datetime(2025, 1, 1, tzinfo=UTC),
            effective_to=None,
            input_rate_per_million_minor_units=999_999,
            output_rate_per_million_minor_units=999_999,
            thinking_rate_per_million_minor_units=999_999,
            cache_read_rate_per_million_minor_units=0,
            cache_write_rate_per_million_minor_units=0,
            is_seed_default=False,
        )
        session.add(override)
        await session.commit()

        cost, rate, source = await recompute_cost(
            session=session,
            provider="anthropic",
            model="claude-sonnet-4-6",
            mode="standard",
            requested_at=datetime.now(tz=UTC),
            input_tokens=1_000,
            output_tokens=1_000,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
    assert rate is not None
    assert cost is not None
    assert source == "override"


@pytest.mark.asyncio
async def test_recompute_cost_no_match_returns_none_source(tmp_path: Path) -> None:
    """No matching rate → fallback cost, source is None."""
    p = tmp_path / "empty-rates.sqlite"
    engine, sessionmaker = create_engine_for(p)
    await init_db(engine)
    # Intentionally do NOT seed.
    try:
        async with sessionmaker() as session:
            cost, rate, source = await recompute_cost(
                session=session,
                provider="anthropic",
                model="claude-sonnet-4-6",
                mode="standard",
                requested_at=datetime.now(tz=UTC),
                input_tokens=10,
                output_tokens=10,
                thinking_tokens=0,
                cache_read_tokens=0,
                cache_write_tokens=0,
                fallback=12345,
            )
        assert rate is None
        assert cost == 12345
        assert source is None
    finally:
        await dispose_engines()


# ── Report header ──────────────────────────────────────────────────────────


def test_report_header_renders_rates_line() -> None:
    """The masthead must include the bundled date when ``rates_summary`` is set."""
    import io

    from rich.console import Console

    from halton_meter.report import RatesSummary, ReportData, _render_header

    data = ReportData(
        records=[],
        total_requests=0,
        total_input_tokens=0,
        total_output_tokens=0,
        total_cost_millicents=0,
        cost_excluded_count=0,
        date_from=None,
        date_to=None,
        incomplete_count=0,
        project_stats=[],
        model_stats=[],
        span_days=0,
        prev_total_cost_millicents=None,
        rates_summary=RatesSummary(
            bundled_date=BUNDLED_RATES_DATE, override_count=0
        ),
    )
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, width=120)
    _render_header(data, console)
    out = buf.getvalue()
    assert f"Rates: bundled {BUNDLED_RATES_DATE}" in out
    assert "override" not in out  # zero overrides → suppressed


def test_report_header_pluralises_overrides() -> None:
    import io

    from rich.console import Console

    from halton_meter.report import RatesSummary, ReportData, _render_header

    base_kwargs = dict(
        records=[],
        total_requests=0,
        total_input_tokens=0,
        total_output_tokens=0,
        total_cost_millicents=0,
        cost_excluded_count=0,
        date_from=None,
        date_to=None,
        incomplete_count=0,
        project_stats=[],
        model_stats=[],
        span_days=0,
        prev_total_cost_millicents=None,
    )
    for count, expected in [(1, "1 override"), (2, "2 overrides"), (5, "5 overrides")]:
        data = ReportData(
            **base_kwargs,
            rates_summary=RatesSummary(
                bundled_date=BUNDLED_RATES_DATE, override_count=count
            ),
        )
        buf = io.StringIO()
        console = Console(file=buf, force_terminal=False, width=120)
        _render_header(data, console)
        out = buf.getvalue()
        assert expected in out, (count, out)
