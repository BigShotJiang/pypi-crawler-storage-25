"""
Tests for the edge proxy (W1 of Phase 2C.2 / v0.1.6).

Coverage targets (per plan §7.W1):

* Unit
  - parse CONNECT request line
  - parse HTTP absolute-URL request line
  - daemon-health cache: TTL boundaries (healthy + unhealthy),
    invalidate(), de-duplication of concurrent probes
  - probe timeout fail-closed
  - bidirectional shuttle on a localhost socketpair-equivalent

* Integration
  - fake daemon up: CONNECT goes through chain
  - fake daemon down: CONNECT falls through to direct passthrough
  - fake daemon comes back up: chain resumes after TTL
  - chain-failure invalidation: cache says healthy, daemon dies before
    chain TCP connect, we fall through on this very request and the
    cache is invalidated for the next one
"""

from __future__ import annotations

import asyncio
import contextlib

import pytest

from halton_meter.edge import (
    DEFAULT_HEALTHY_TTL_SECONDS,
    DaemonHealthCache,
    EdgeConfig,
    EdgeProxy,
    ParsedRequest,
    _parse_http_absolute_url,
    parse_connect_target,
    read_request_head,
    shuttle_bidirectional,
)

# --------------------------------------------------------------------------- #
# Test helpers                                                                #
# --------------------------------------------------------------------------- #


class FakeUpstream:
    """Tiny TCP echo-with-banner server for passthrough tests.

    On connect, sends ``banner`` then echoes everything the client
    sends back. Used to verify the edge bidirectionally shuttles bytes
    in passthrough mode.
    """

    def __init__(self, banner: bytes = b"UPSTREAM\n") -> None:
        self.banner = banner
        self.server: asyncio.base_events.Server | None = None
        self.host = "127.0.0.1"
        self.port = 0
        self.connections_seen = 0

    async def start(self) -> int:
        self.server = await asyncio.start_server(
            self._handle, host=self.host, port=0
        )
        sock = self.server.sockets[0]
        self.port = sock.getsockname()[1]
        return self.port

    async def stop(self) -> None:
        if self.server is None:
            return
        self.server.close()
        with contextlib.suppress(Exception):
            await self.server.wait_closed()
        self.server = None

    async def _handle(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        self.connections_seen += 1
        try:
            writer.write(self.banner)
            await writer.drain()
            while True:
                chunk = await reader.read(4096)
                if not chunk:
                    break
                writer.write(chunk)
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        finally:
            with contextlib.suppress(Exception):
                writer.close()
                await writer.wait_closed()


class FakeDaemon:
    """Tiny TCP server impersonating the metering daemon.

    Two roles in one:

    * ``/health`` HTTP handler — answers ``HTTP/1.1 200 OK`` to a GET
      so :class:`DaemonHealthCache` returns True.
    * Forward-proxy CONNECT replayer — when the request line is
      ``CONNECT host:port HTTP/1.1`` we tag the connection as proxy
      and send back an arbitrary marker (``DAEMON_CHAINED\\n``)
      followed by echoing what the client sends. This lets the test
      confirm "chained through the daemon" vs "direct to upstream"
      because the bytes the client receives differ.

    Real mitmproxy answers CONNECT with ``200 Connection Established``
    then performs TLS interception. We don't need TLS here — the test
    only needs to assert the byte path went through the daemon.
    """

    def __init__(self) -> None:
        self.server: asyncio.base_events.Server | None = None
        self.host = "127.0.0.1"
        self.port = 0
        self.connect_targets: list[str] = []
        self.health_probes = 0

    async def start(self) -> int:
        self.server = await asyncio.start_server(
            self._handle, host=self.host, port=0
        )
        sock = self.server.sockets[0]
        self.port = sock.getsockname()[1]
        return self.port

    async def stop(self) -> None:
        if self.server is None:
            return
        self.server.close()
        with contextlib.suppress(Exception):
            await self.server.wait_closed()
        self.server = None

    async def _handle(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        try:
            first = await reader.readline()
            if not first:
                return
            decoded = first.decode("iso-8859-1").rstrip("\r\n")
            parts = decoded.split(" ", 2)
            if len(parts) < 3:
                return
            method, target, _version = parts
            # Drain headers to blank line.
            while True:
                line = await reader.readline()
                if not line or line in (b"\r\n", b"\n"):
                    break
            if method.upper() == "GET" and target == "/health":
                self.health_probes += 1
                writer.write(
                    b"HTTP/1.1 200 OK\r\n"
                    b"Content-Type: application/json\r\n"
                    b"Content-Length: 15\r\n"
                    b"Connection: close\r\n"
                    b"\r\n"
                    b'{"status":"ok"}'
                )
                await writer.drain()
                return
            if method.upper() == "CONNECT":
                self.connect_targets.append(target)
                writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                writer.write(b"DAEMON_CHAINED\n")
                await writer.drain()
                # Echo bytes back (so shuttle path completes cleanly).
                while True:
                    chunk = await reader.read(4096)
                    if not chunk:
                        break
                    writer.write(chunk)
                    await writer.drain()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        finally:
            with contextlib.suppress(Exception):
                writer.close()
                await writer.wait_closed()


async def _send_through_edge(
    edge_port: int,
    raw: bytes,
    *,
    read_until_close: bool = True,
    extra_payload: bytes = b"",
) -> bytes:
    """Connect to the edge, send ``raw``, optionally send ``extra_payload``,
    then read response bytes until EOF (or a single chunk if
    ``read_until_close=False``).
    """
    reader, writer = await asyncio.open_connection("127.0.0.1", edge_port)
    try:
        writer.write(raw)
        await writer.drain()
        if extra_payload:
            writer.write(extra_payload)
            await writer.drain()
            try:
                if writer.can_write_eof():
                    writer.write_eof()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
        if read_until_close:
            chunks: list[bytes] = []
            while True:
                chunk = await reader.read(4096)
                if not chunk:
                    break
                chunks.append(chunk)
            return b"".join(chunks)
        return await reader.read(4096)
    finally:
        with contextlib.suppress(Exception):
            writer.close()
            await writer.wait_closed()


# --------------------------------------------------------------------------- #
# Unit: request-line parsing                                                  #
# --------------------------------------------------------------------------- #


def test_parse_connect_target_simple_host() -> None:
    assert parse_connect_target("api.anthropic.com:443") == ("api.anthropic.com", 443)


def test_parse_connect_target_ipv4() -> None:
    assert parse_connect_target("127.0.0.1:8080") == ("127.0.0.1", 8080)


def test_parse_connect_target_ipv6_bracketed() -> None:
    assert parse_connect_target("[::1]:443") == ("::1", 443)


def test_parse_connect_target_missing_port() -> None:
    assert parse_connect_target("api.anthropic.com") is None


def test_parse_connect_target_non_numeric_port() -> None:
    assert parse_connect_target("api.anthropic.com:ssl") is None


def test_parse_connect_target_out_of_range_port() -> None:
    assert parse_connect_target("api.anthropic.com:99999") is None


def test_parse_connect_target_empty() -> None:
    assert parse_connect_target("") is None


def test_parse_http_absolute_url_default_port() -> None:
    assert _parse_http_absolute_url("http://example.com/foo") == (
        "example.com",
        80,
        "/foo",
    )


def test_parse_http_absolute_url_explicit_port() -> None:
    assert _parse_http_absolute_url("http://example.com:8080/x?y=1") == (
        "example.com",
        8080,
        "/x?y=1",
    )


def test_parse_http_absolute_url_no_path() -> None:
    assert _parse_http_absolute_url("http://example.com") == ("example.com", 80, "/")


def test_parse_http_absolute_url_origin_form_rejected() -> None:
    assert _parse_http_absolute_url("/foo") is None


# --------------------------------------------------------------------------- #
# Unit: read_request_head                                                     #
# --------------------------------------------------------------------------- #


async def _feed_into_reader(payload: bytes) -> asyncio.StreamReader:
    reader = asyncio.StreamReader()
    reader.feed_data(payload)
    reader.feed_eof()
    return reader


async def test_read_request_head_connect() -> None:
    reader = await _feed_into_reader(
        b"CONNECT api.anthropic.com:443 HTTP/1.1\r\n"
        b"Host: api.anthropic.com:443\r\n"
        b"\r\n"
    )
    parsed = await read_request_head(reader)
    assert parsed is not None
    assert parsed.method == "CONNECT"
    assert parsed.target == "api.anthropic.com:443"
    assert parsed.version == "HTTP/1.1"
    assert parsed.raw_head.endswith(b"\r\n\r\n")
    assert b"Host: api.anthropic.com:443" in parsed.raw_head


async def test_read_request_head_get() -> None:
    reader = await _feed_into_reader(
        b"GET http://example.com/x HTTP/1.1\r\n"
        b"Host: example.com\r\n"
        b"\r\n"
    )
    parsed = await read_request_head(reader)
    assert parsed is not None
    assert parsed.method == "GET"
    assert parsed.target == "http://example.com/x"


async def test_read_request_head_malformed() -> None:
    reader = await _feed_into_reader(b"NOT-A-VALID-LINE\r\n\r\n")
    parsed = await read_request_head(reader)
    assert parsed is None


async def test_read_request_head_connection_closed_mid_headers() -> None:
    reader = asyncio.StreamReader()
    reader.feed_data(b"CONNECT example.com:443 HTTP/1.1\r\nHost: example.com\r\n")
    reader.feed_eof()  # No terminating blank line.
    parsed = await read_request_head(reader)
    assert parsed is None


# --------------------------------------------------------------------------- #
# Unit: DaemonHealthCache                                                     #
# --------------------------------------------------------------------------- #


async def test_health_cache_uses_cached_healthy_within_ttl(monkeypatch) -> None:
    fake_now = [100.0]
    cache = DaemonHealthCache(
        internal_host="127.0.0.1",
        internal_port=1,  # unreachable; but probe shouldn't fire.
        healthy_ttl_s=1.0,
        clock=lambda: fake_now[0],
    )
    cache._has_result = True
    cache._last_result = True
    cache._last_check_at = 100.0
    fake_now[0] = 100.5  # within healthy TTL
    assert await cache.is_healthy() is True


async def test_health_cache_uses_cached_unhealthy_within_ttl() -> None:
    fake_now = [100.0]
    cache = DaemonHealthCache(
        internal_host="127.0.0.1",
        internal_port=1,
        unhealthy_ttl_s=0.2,
        clock=lambda: fake_now[0],
    )
    cache._has_result = True
    cache._last_result = False
    cache._last_check_at = 100.0
    fake_now[0] = 100.1  # within unhealthy TTL
    assert await cache.is_healthy() is False


async def test_health_cache_re_probes_after_healthy_ttl_expires() -> None:
    daemon = FakeDaemon()
    port = await daemon.start()
    try:
        fake_now = [100.0]
        cache = DaemonHealthCache(
            internal_host="127.0.0.1",
            internal_port=port,
            probe_port=port,
            healthy_ttl_s=1.0,
            clock=lambda: fake_now[0],
        )
        cache._has_result = True
        cache._last_result = True
        cache._last_check_at = 100.0
        fake_now[0] = 102.0  # well past TTL — must re-probe
        assert await cache.is_healthy() is True
        assert daemon.health_probes == 1
    finally:
        await daemon.stop()


async def test_health_cache_invalidate_forces_re_probe() -> None:
    daemon = FakeDaemon()
    port = await daemon.start()
    try:
        cache = DaemonHealthCache(
            internal_host="127.0.0.1",
            internal_port=port,
            probe_port=port,
        )
        # First probe populates cache.
        assert await cache.is_healthy() is True
        assert daemon.health_probes == 1
        cache.invalidate()
        # Next call must re-probe.
        assert await cache.is_healthy() is True
        assert daemon.health_probes == 2
    finally:
        await daemon.stop()


async def test_health_cache_probe_timeout_returns_false() -> None:
    # Bind a TCP listener that never accepts (sort of). We instead use a
    # closed port and expect ConnectionRefused → False; for a real
    # timeout we'd need a black-hole peer. We test both branches:
    # ConnectionRefused on closed port (deterministic) AND we test the
    # explicit timeout path by using a custom probe_timeout_s of 0.
    cache = DaemonHealthCache(
        internal_host="127.0.0.1",
        internal_port=1,  # almost certainly closed
        probe_port=1,
        probe_timeout_s=0.5,
    )
    assert await cache.is_healthy() is False


async def test_health_cache_probe_zero_timeout_fails_closed() -> None:
    """A 0-second timeout should always return False (fail-closed)."""
    daemon = FakeDaemon()
    port = await daemon.start()
    try:
        cache = DaemonHealthCache(
            internal_host="127.0.0.1",
            internal_port=port,
            probe_port=port,
            probe_timeout_s=0.0,
        )
        assert await cache.is_healthy() is False
    finally:
        await daemon.stop()


async def test_health_cache_concurrent_callers_share_one_probe() -> None:
    """When N callers race onto a cold cache, only one probe fires."""
    daemon = FakeDaemon()
    port = await daemon.start()
    try:
        cache = DaemonHealthCache(
            internal_host="127.0.0.1",
            internal_port=port,
            probe_port=port,
        )
        results = await asyncio.gather(*[cache.is_healthy() for _ in range(8)])
        assert all(r is True for r in results)
        assert daemon.health_probes == 1
    finally:
        await daemon.stop()


# --------------------------------------------------------------------------- #
# Unit: shuttle_bidirectional                                                 #
# --------------------------------------------------------------------------- #


async def test_shuttle_bidirectional_round_trip() -> None:
    """Server doubles each chunk it receives; client should see doubled
    bytes after a round-trip through ``shuttle_bidirectional``.
    """
    # Pair A: client <-> shuttle-A; the shuttle copies into pair B.
    # Pair B: shuttle-B <-> echo-server.
    server_ready = asyncio.Event()
    server_data: list[bytes] = []

    async def echo_server(
        reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        server_ready.set()
        while True:
            chunk = await reader.read(4096)
            if not chunk:
                break
            server_data.append(chunk)
            writer.write(chunk * 2)
            await writer.drain()
        with contextlib.suppress(Exception):
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(echo_server, host="127.0.0.1", port=0)
    server_port = server.sockets[0].getsockname()[1]

    # Client side socket: a real TCP client we drive the test from.
    a_reader, a_writer = await asyncio.open_connection("127.0.0.1", server_port)

    # We don't actually need a shuttle here — the standard echo path
    # above is enough. The "shuttle" abstraction is really tested
    # below by the integration tests where it's exercised on the
    # real edge proxy code path. This test keeps the sanity check
    # against deadlocks / EOF handling on the unit-level helper.
    a_writer.write(b"hello\n")
    await a_writer.drain()
    if a_writer.can_write_eof():
        a_writer.write_eof()
    received = await a_reader.read()
    assert received == b"hello\n" * 2
    assert b"hello\n" in b"".join(server_data)

    a_writer.close()
    with contextlib.suppress(Exception):
        await a_writer.wait_closed()
    server.close()
    with contextlib.suppress(Exception):
        await server.wait_closed()


async def test_shuttle_bidirectional_propagates_eof() -> None:
    """When one side closes, the shuttle propagates EOF to the other and
    returns cleanly — no hang.
    """
    # Two stream pairs A↔B.
    # Use two TCP socketpair-style connections via asyncio helpers.
    # We synthesise them by opening two connections to a no-op server
    # whose handler immediately bridges its reader to the writer of
    # another connection… too convoluted. Instead, use the
    # well-supported asyncio.open_connection over a loopback pair we
    # control via two start_server calls that just hold the connection.

    # Simplest viable harness: create two duplex pipes via socketpair.
    import socket as _socket

    a_sock, b_sock = _socket.socketpair(_socket.AF_UNIX, _socket.SOCK_STREAM)
    c_sock, d_sock = _socket.socketpair(_socket.AF_UNIX, _socket.SOCK_STREAM)

    loop = asyncio.get_running_loop()
    # Wrap a_sock and b_sock into asyncio streams.
    # Wrap c_sock and d_sock similarly.
    # We'll pipe a→shuttle→c and d→shuttle→b.

    # Use loop.create_connection with a custom protocol... or simpler,
    # use loop.connect_accepted_socket via a transport. Simplest is
    # asyncio.open_connection with sock=...

    async def _wrap(sock: _socket.socket) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        sock.setblocking(False)
        reader = asyncio.StreamReader(loop=loop)
        protocol = asyncio.StreamReaderProtocol(reader, loop=loop)
        transport, _ = await loop.create_connection(lambda: protocol, sock=sock)
        writer = asyncio.StreamWriter(transport, protocol, reader, loop)
        return reader, writer

    a_reader, a_writer = await _wrap(a_sock)
    b_reader, b_writer = await _wrap(b_sock)
    c_reader, c_writer = await _wrap(c_sock)
    d_reader, d_writer = await _wrap(d_sock)

    # Run shuttle: pipe (a_reader, a_writer) <-> (c_reader, c_writer).
    # External test driver writes on b_writer (lands in a_reader),
    # and reads from d_reader (gets data we wrote to c_writer's peer).
    # But shuttle copies a_reader -> c_writer and c_reader -> a_writer.
    # So data we write into b ends up at d, and vice versa.

    shuttle_task = asyncio.create_task(
        shuttle_bidirectional(a_reader, a_writer, c_reader, c_writer)
    )

    b_writer.write(b"forward\n")
    await b_writer.drain()
    # Peer of b is a; shuttle copies a->c; peer of c is d, so d_reader sees:
    received_forward = await asyncio.wait_for(d_reader.read(8), timeout=2.0)
    assert received_forward == b"forward\n"

    d_writer.write(b"reverse\n")
    await d_writer.drain()
    received_reverse = await asyncio.wait_for(b_reader.read(8), timeout=2.0)
    assert received_reverse == b"reverse\n"

    # Now close b -> a sees EOF -> shuttle propagates EOF to c -> d sees EOF.
    b_writer.close()
    with contextlib.suppress(Exception):
        await b_writer.wait_closed()

    # Wait for shuttle to finish (one direction's EOF triggers the
    # asyncio.gather to resolve when both sides settle; closing both
    # writers is the caller's job, which we do here).
    # Forcibly close c on the other side so the b_reader unblocks.
    d_writer.close()
    with contextlib.suppress(Exception):
        await d_writer.wait_closed()

    await asyncio.wait_for(shuttle_task, timeout=2.0)

    # Cleanup remaining writers.
    for w in (a_writer, c_writer):
        with contextlib.suppress(Exception):
            w.close()
            await w.wait_closed()


# --------------------------------------------------------------------------- #
# Integration: full edge proxy with fake daemon + fake upstream               #
# --------------------------------------------------------------------------- #


@pytest.fixture
async def edge_setup():
    """Spin up a fake daemon, fake upstream, and a real edge proxy.

    Returns ``(daemon, upstream, edge, edge_port)``. The daemon is
    started; tests that want it down can call ``await daemon.stop()``.
    """
    daemon = FakeDaemon()
    upstream = FakeUpstream()
    daemon_port = await daemon.start()
    upstream_port = await upstream.start()
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=daemon_port,
        probe_port=daemon_port,  # FakeDaemon serves /health on the same port
        healthy_ttl_s=0.05,  # short so cache flips fast in tests
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.5,
    )
    edge = EdgeProxy(config)
    edge_port = await edge.start()
    serve_task = asyncio.create_task(edge.serve_forever(), name="edge-test-serve")
    try:
        yield daemon, upstream, edge, edge_port, upstream_port
    finally:
        await edge.stop()
        serve_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await serve_task
        await daemon.stop()
        await upstream.stop()


async def test_edge_chains_when_daemon_healthy(edge_setup) -> None:
    daemon, upstream, edge, edge_port, _upstream_port = edge_setup
    # Warm cache so we deterministically chain.
    assert await edge.health_cache.is_healthy() is True

    response = await _send_through_edge(
        edge_port,
        "CONNECT api.anthropic.com:443 HTTP/1.1\r\n"
        "Host: api.anthropic.com:443\r\n"
        "\r\n".encode("ascii"),
        extra_payload=b"client-says-hi",
    )
    # The fake daemon's CONNECT handler answers with
    # "200 Connection Established" then "DAEMON_CHAINED\n" then echoes.
    assert b"DAEMON_CHAINED" in response
    assert daemon.connect_targets == ["api.anthropic.com:443"]
    # Upstream must NOT have been contacted directly.
    assert upstream.connections_seen == 0


async def test_edge_passes_through_when_daemon_down(edge_setup) -> None:
    daemon, upstream, edge, edge_port, upstream_port = edge_setup
    # Take the daemon down BEFORE any traffic. Force the cache to know
    # daemon is down by invalidating + waiting for the unhealthy probe.
    await daemon.stop()
    edge.health_cache.invalidate()
    assert await edge.health_cache.is_healthy() is False

    response = await _send_through_edge(
        edge_port,
        f"CONNECT 127.0.0.1:{upstream_port} HTTP/1.1\r\n"
        f"Host: 127.0.0.1:{upstream_port}\r\n"
        f"\r\n".encode("ascii"),
        extra_payload=b"hello",
    )
    # Edge answers 200 Connection Established itself, then we see the
    # FakeUpstream banner.
    assert b"200 Connection Established" in response
    assert b"UPSTREAM" in response
    assert upstream.connections_seen == 1
    # Daemon connect_targets unchanged (it was stopped).
    assert daemon.connect_targets == []


async def test_edge_resumes_chain_after_daemon_restart(edge_setup) -> None:
    daemon, upstream, edge, edge_port, upstream_port = edge_setup
    # Stop daemon, force unhealthy.
    await daemon.stop()
    edge.health_cache.invalidate()
    assert await edge.health_cache.is_healthy() is False

    # First request: passthrough.
    await _send_through_edge(
        edge_port,
        f"CONNECT 127.0.0.1:{upstream_port} HTTP/1.1\r\n"
        f"Host: 127.0.0.1:{upstream_port}\r\n\r\n".encode("ascii"),
        extra_payload=b"first",
    )
    assert upstream.connections_seen == 1
    assert daemon.connect_targets == []

    # Restart daemon on a NEW port; rebuild the cache pointing at the
    # new port.
    daemon2 = FakeDaemon()
    daemon2_port = await daemon2.start()
    try:
        edge.health_cache.internal_host = "127.0.0.1"
        edge.health_cache.internal_port = daemon2_port
        edge.health_cache.probe_port = daemon2_port
        # The edge's _try_chain uses self._config.internal_port for
        # its TCP connect — the cache only governs the gating decision.
        # For this test to also verify the chain TCP path, we need to
        # update the EdgeConfig too. The simplest is to mutate the
        # private attribute (test-only).
        edge._config = EdgeConfig(
            edge_host=edge._config.edge_host,
            edge_port=edge._config.edge_port,
            internal_host="127.0.0.1",
            internal_port=daemon2_port,
            probe_port=daemon2_port,
            healthy_ttl_s=edge._config.healthy_ttl_s,
            unhealthy_ttl_s=edge._config.unhealthy_ttl_s,
            probe_timeout_s=edge._config.probe_timeout_s,
        )
        # Wait for unhealthy TTL to expire so cache re-probes.
        await asyncio.sleep(0.1)
        edge.health_cache.invalidate()
        assert await edge.health_cache.is_healthy() is True

        response = await _send_through_edge(
            edge_port,
            b"CONNECT api.anthropic.com:443 HTTP/1.1\r\n"
            b"Host: api.anthropic.com:443\r\n\r\n",
            extra_payload=b"second",
        )
        assert b"DAEMON_CHAINED" in response
        assert daemon2.connect_targets == ["api.anthropic.com:443"]
    finally:
        await daemon2.stop()


async def test_edge_invalidates_cache_on_chain_connection_refused(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The stale-positive race: cache says healthy, daemon dies before the
    chain's TCP connect. The connect raises ConnectionRefusedError, the
    edge invalidates the cache and falls through to passthrough on this
    very request — no TTL wait.

    v0.1.22.24: the edge now gates chaining on an LLM host allowlist.
    This test exercises a control-plane path (cache invalidation on a
    refused chain TCP connect), not an attribution path, so we
    short-circuit the allowlist to "always intercept" and keep the
    test using its loopback ``127.0.0.1`` upstream. The allowlist
    semantics themselves are tested in ``test_chain_decision.py`` and
    ``test_provider_hosts.py``.
    """
    monkeypatch.setattr(
        "halton_meter.edge.host_should_intercept", lambda _h: True
    )
    daemon = FakeDaemon()
    upstream = FakeUpstream()
    daemon_port = await daemon.start()
    upstream_port = await upstream.start()
    try:
        config = EdgeConfig(
            edge_host="127.0.0.1",
            edge_port=0,
            internal_host="127.0.0.1",
            internal_port=daemon_port,
            probe_port=daemon_port,
            healthy_ttl_s=DEFAULT_HEALTHY_TTL_SECONDS,
            unhealthy_ttl_s=0.05,
        )
        edge = EdgeProxy(config)
        edge_port = await edge.start()
        serve_task = asyncio.create_task(edge.serve_forever())
        try:
            # Warm the cache to "healthy".
            assert await edge.health_cache.is_healthy() is True

            # Now kill the daemon WITHOUT giving the cache a chance to
            # re-probe. The cache still says healthy.
            await daemon.stop()
            assert edge.health_cache._has_result is True
            assert edge.health_cache._last_result is True

            # Send a CONNECT to the upstream's port. The edge, believing
            # the daemon is healthy, will try to chain — TCP connect to
            # daemon_port now fails ConnectionRefused — cache is
            # invalidated, edge falls through to passthrough; client sees
            # 200 Connection Established + upstream banner.
            response = await _send_through_edge(
                edge_port,
                f"CONNECT 127.0.0.1:{upstream_port} HTTP/1.1\r\n"
                f"Host: 127.0.0.1:{upstream_port}\r\n\r\n".encode("ascii"),
                extra_payload=b"x",
            )
            assert b"200 Connection Established" in response
            assert b"UPSTREAM" in response
            # Cache must have been invalidated.
            assert edge.health_cache._has_result is False
            # Upstream observed the passthrough.
            assert upstream.connections_seen == 1
        finally:
            await edge.stop()
            serve_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await serve_task
    finally:
        await daemon.stop()
        await upstream.stop()


async def test_edge_returns_502_when_upstream_unreachable_in_passthrough() -> None:
    """Daemon is down + upstream host:port closed → client sees 502."""
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=1,  # daemon "down"
        probe_port=1,
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.2,
    )
    edge = EdgeProxy(config)
    edge_port = await edge.start()
    serve_task = asyncio.create_task(edge.serve_forever())
    try:
        # CONNECT to a closed local port → passthrough connect fails.
        response = await _send_through_edge(
            edge_port,
            b"CONNECT 127.0.0.1:1 HTTP/1.1\r\nHost: 127.0.0.1:1\r\n\r\n",
        )
        assert b"502 Bad Gateway" in response
    finally:
        await edge.stop()
        serve_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await serve_task


async def test_edge_returns_400_on_malformed_request() -> None:
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=1,
        probe_port=1,
        probe_timeout_s=0.2,
    )
    edge = EdgeProxy(config)
    edge_port = await edge.start()
    serve_task = asyncio.create_task(edge.serve_forever())
    try:
        response = await _send_through_edge(
            edge_port, b"GARBAGE-NOT-HTTP\r\n\r\n"
        )
        assert b"400 Bad Request" in response
    finally:
        await edge.stop()
        serve_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await serve_task


async def test_edge_returns_400_on_bad_connect_target() -> None:
    """A CONNECT line with no port should be rejected with 400 once we
    reach the connect-target parser (we have to surface a daemon-down
    state so passthrough is the chosen branch, otherwise the chain
    would forward the malformed line straight to the daemon).
    """
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=1,  # down
        probe_port=1,
        probe_timeout_s=0.2,
    )
    edge = EdgeProxy(config)
    edge_port = await edge.start()
    serve_task = asyncio.create_task(edge.serve_forever())
    try:
        response = await _send_through_edge(
            edge_port,
            b"CONNECT no-port-here HTTP/1.1\r\nHost: no-port-here\r\n\r\n",
        )
        assert b"400 Bad Request" in response
    finally:
        await edge.stop()
        serve_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await serve_task


# --------------------------------------------------------------------------- #
# Surface check: ParsedRequest is a frozen dataclass-like value               #
# --------------------------------------------------------------------------- #


def test_parsed_request_is_frozen_value() -> None:
    pr = ParsedRequest(
        method="CONNECT",
        target="x:1",
        version="HTTP/1.1",
        raw_head=b"CONNECT x:1 HTTP/1.1\r\n\r\n",
    )
    assert pr.method == "CONNECT"
    with pytest.raises((AttributeError, Exception)):
        pr.method = "GET"  # type: ignore[misc]


# --------------------------------------------------------------------------- #
# Bug 2 regression (0.1.13.dev2) — RuntimeError: cannot reuse already         #
# awaited coroutine, raised by ``await client_writer.wait_closed()`` in       #
# ``_handle_connection``'s finally on Python 3.14.                            #
# --------------------------------------------------------------------------- #


async def test_handle_connection_close_path_does_not_double_await() -> None:
    """Many short-lived connections must not raise from the close path.

    Pre-fix: under Python 3.14, ``client_writer.wait_closed()`` on the
    cleanup path could be re-awaited at task-shutdown time, raising
    ``RuntimeError: cannot reuse already awaited coroutine`` and
    polluting edge.err.log on every clean shutdown.

    Post-fix: the cleanup just calls ``close()`` and lets the
    transport tear down asynchronously. This test opens N connections,
    sends a CONNECT to a deliberately-unroutable target so passthrough
    fails fast (502), and asserts the run completes without any
    RuntimeError surfacing into the test.
    """
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=1,  # nobody listens here
        healthy_ttl_s=0.05,
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.05,
    )
    proxy = EdgeProxy(config)
    bound = await proxy.start()
    serve_task = asyncio.create_task(proxy.serve_forever())
    try:
        for _ in range(8):
            r, w = await asyncio.open_connection("127.0.0.1", bound)
            w.write(
                b"CONNECT 127.0.0.1:1 HTTP/1.1\r\nHost: 127.0.0.1:1\r\n\r\n"
            )
            try:
                await w.drain()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
            # Drain (or 502) and close from our side immediately to
            # force the edge's finally-block close-path to run.
            try:
                await asyncio.wait_for(r.read(1024), timeout=0.5)
            except TimeoutError:
                pass
            w.close()
            try:
                await asyncio.wait_for(w.wait_closed(), timeout=0.5)
            except (TimeoutError, ConnectionResetError, BrokenPipeError, OSError):
                pass
        # Give the server a tick to run the per-connection finally
        # blocks before tearing the harness down.
        await asyncio.sleep(0.05)
    finally:
        await proxy.stop()
        serve_task.cancel()
        try:
            await serve_task
        except (asyncio.CancelledError, Exception):
            pass


async def test_handle_connection_close_path_idempotent_when_already_closing() -> None:
    """``is_closing()`` guard prevents redundant close() in the finally."""
    from halton_meter.edge import EdgeProxy as _Edge

    cfg = EdgeConfig(edge_host="127.0.0.1", edge_port=0, internal_port=1)
    proxy = _Edge(cfg)
    bound = await proxy.start()
    serve_task = asyncio.create_task(proxy.serve_forever())
    try:
        # Connect and immediately close from the client side without
        # sending any request — exercises the ``parsed is None`` 400
        # branch followed by the cleanup finally.
        r, w = await asyncio.open_connection("127.0.0.1", bound)
        w.close()
        try:
            await asyncio.wait_for(w.wait_closed(), timeout=0.5)
        except (TimeoutError, ConnectionResetError, BrokenPipeError, OSError):
            pass
        del r
        await asyncio.sleep(0.05)
    finally:
        await proxy.stop()
        serve_task.cancel()
        try:
            await serve_task
        except (asyncio.CancelledError, Exception):
            pass
