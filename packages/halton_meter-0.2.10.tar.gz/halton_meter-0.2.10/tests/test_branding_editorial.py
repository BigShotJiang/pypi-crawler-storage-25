"""Smoke tests for the editorial branding primitives lifted from
the rejected ``claude/polish-cli-ux-9mbFC`` PR and rebuilt on the
v0.1.22 line in v0.1.22.8.

Goal of this file is *not* to snapshot Rich output (brittle) — only to
assert that every public helper:

1. Imports cleanly.
2. Returns a Rich-renderable object without raising.
3. Renders to a non-empty string when a Console captures it.

Anything beyond that (exact glyph, exact colour) is editorial taste and
out of scope for an automated invariant.
"""

from __future__ import annotations

from io import StringIO

import pytest
from rich.console import Console

from halton_meter import branding


def _capture(renderable: object) -> str:
    """Render ``renderable`` to a string via a no-color, fixed-width Console."""
    buf = StringIO()
    console = Console(file=buf, force_terminal=False, width=120, color_system=None)
    console.print(renderable)
    return buf.getvalue()


def test_palette_tokens_present() -> None:
    """Brand-orange + state colour tokens are exposed at module level."""
    assert branding.BRAND_ORANGE == "#ea7d2e"
    assert branding.MUTED
    assert branding.OK
    assert branding.WARN
    assert branding.ERROR
    # Pill glyphs lifted from the editorial redesign
    assert branding.PILL_ACTIVE == "●"
    assert branding.PILL_PAUSED == "○"
    assert branding.PILL_DEGRADED == "◐"
    assert branding.PILL_BROKEN == "✗"


def test_brand_masthead_renders() -> None:
    out = _capture(branding.brand_masthead(subtitle="status", version="0.1.22.8"))
    assert "halton" in out
    assert "meter" in out
    assert "status" in out
    assert "0.1.22.8" in out


def test_brand_masthead_minimal() -> None:
    """Masthead with no subtitle/version still renders the wordmark."""
    out = _capture(branding.brand_masthead())
    assert "halton" in out
    assert "meter" in out


def test_brand_underrule_renders() -> None:
    out = _capture(branding.brand_underrule())
    assert out.strip()  # non-empty


def test_brand_section_renders_title_and_body() -> None:
    from rich.text import Text
    body = Text("inner content")
    out = _capture(branding.brand_section("Component Health", body))
    assert "Component Health" in out
    assert "inner content" in out


@pytest.mark.parametrize(
    ("state", "expected_glyph"),
    [
        ("ok", branding.PILL_ACTIVE),
        ("running", branding.PILL_ACTIVE),
        ("warn", branding.PILL_DEGRADED),
        ("degraded", branding.PILL_DEGRADED),
        ("error", branding.PILL_BROKEN),
        ("broken", branding.PILL_BROKEN),
        ("stopped", branding.PILL_PAUSED),
        ("paused", branding.PILL_PAUSED),
    ],
)
def test_brand_pill_state_to_glyph(state: str, expected_glyph: str) -> None:
    out = _capture(branding.brand_pill(state, label="thing"))
    assert expected_glyph in out
    assert "thing" in out


def test_brand_kv_aligns_label_and_value() -> None:
    out = _capture(branding.brand_kv("System proxy", "active"))
    assert "System proxy" in out
    assert "active" in out


def test_brand_step_renders_pill_label_detail() -> None:
    out = _capture(branding.brand_step("ok", "Daemon loaded", detail="PID 81234"))
    assert branding.PILL_ACTIVE in out
    assert "Daemon loaded" in out
    assert "PID 81234" in out


def test_brand_bar_zero_total_renders_empty_bar() -> None:
    out = _capture(branding.brand_bar(0.0, 0.0, width=10))
    assert out.strip()


def test_brand_bar_partial_fill_renders() -> None:
    out = _capture(branding.brand_bar(3.0, 10.0, width=20))
    assert out.strip()


def test_brand_sparkline_empty_collapses_to_single_glyph() -> None:
    out = _capture(branding.brand_sparkline([]))
    assert out.strip()


def test_brand_sparkline_renders_series() -> None:
    out = _capture(branding.brand_sparkline([1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]))
    assert out.strip()


def test_brand_sparkline_all_zeros() -> None:
    out = _capture(branding.brand_sparkline([0.0, 0.0, 0.0]))
    assert out.strip()


def test_brand_command_grid_renders_rows() -> None:
    out = _capture(
        branding.brand_command_grid(
            [
                ("halton-meter status", "show daemon health"),
                ("halton-meter report", "summarise spend"),
            ]
        )
    )
    assert "halton-meter status" in out
    assert "show daemon health" in out
    assert "halton-meter report" in out
    assert "summarise spend" in out


def test_brand_dot_separator_renders() -> None:
    out = _capture(branding.brand_dot_separator())
    assert "·" in out


def test_severity_color_known_states() -> None:
    """Known severities map to non-empty colour tokens."""
    for state in ("ok", "warn", "error", "info"):
        assert branding.severity_color(state)


def test_brand_panel_table_progress_still_callable() -> None:
    """Pre-existing helpers preserved by the v0.1.22.8 lift."""
    panel = branding.brand_panel("hello", title="ok")
    table = branding.brand_table()
    progress = branding.brand_progress()
    phase_progress = branding.brand_phase_progress()
    assert panel is not None
    assert table is not None
    assert progress is not None
    assert phase_progress is not None
