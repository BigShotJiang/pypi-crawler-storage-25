"""v0.1.22.11 — branded CLI surface integration tests.

Each surface (status / start / stop / init / report / doctor) opens
with the editorial masthead + underrule pair (``brand_command_lead``)
and uses ``brand_pill`` for verdict glyphs / state cells. These tests
assert the rendered text contains the masthead signature, the
underrule, the verdict pill colour mapping, and the load-bearing
numeric values (PIDs, ports, latencies) preserved from the previous
panel-based shape.

Captures use ``StringIO`` + ``Console(force_terminal=False)`` — same
plain-text pattern v0.1.22.8 used for the editorial smoke tests.
"""

from __future__ import annotations

from io import StringIO

from rich.console import Console

from halton_meter import __version__
from halton_meter.branding import (
    PILL_ACTIVE,
    PILL_BROKEN,
    PILL_PAUSED,
    brand_command_lead,
)


def _capture(*renderables: object) -> str:
    console = Console(file=StringIO(), force_terminal=False, width=120)
    for r in renderables:
        console.print(r)
    return console.file.getvalue()  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# brand_command_lead — the shared visual signature
# ---------------------------------------------------------------------------


def test_brand_command_lead_renders_masthead_underrule_and_version() -> None:
    """The shared lead-in carries product wordmark, subtitle, version, and rule."""
    out = _capture(brand_command_lead("status", version="9.9.9"))
    # Wordmark
    assert "halton-meter" in out
    # Subtitle separator + subtitle text
    assert "›" in out
    assert "status" in out
    # Version with v-prefix
    assert "v9.9.9" in out
    # Underrule glyph
    assert "─" in out


def test_brand_command_lead_uses_active_pill_glyph() -> None:
    """The masthead opens with the brand-active pill (●) as the dot accent."""
    out = _capture(brand_command_lead("doctor", version=__version__))
    assert PILL_ACTIVE in out
    assert __version__ in out


# ---------------------------------------------------------------------------
# status — _render_status uses masthead + brand_section + brand_pill + brand_kv
# ---------------------------------------------------------------------------


def test_render_status_emits_masthead_pill_section_and_kv() -> None:
    """Direct ``_render_status`` capture — covers all primitives wired in."""
    from halton_meter.lifecycle import _macos as lifecycle_macos

    rows = [
        lifecycle_macos._ComponentRow("Daemon", "healthy", "PID 17733"),
        lifecycle_macos._ComponentRow("Watchdog", "healthy", "PID 17734"),
        lifecycle_macos._ComponentRow("System proxy", "disabled", "off"),
    ]
    summary = lifecycle_macos._HealthSummary("HEALTHY", "env-only mode is healthy.")
    report = lifecycle_macos._StatusReport(
        rows=rows,
        last_hour=12,
        last_day=345,
        healthy=True,
        health_summary=summary,
    )

    console = Console(file=StringIO(), force_terminal=False, width=120)
    lifecycle_macos._render_status(report, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]

    # Masthead + version
    assert "halton-meter" in out
    assert __version__ in out
    assert "status" in out
    # Underrule
    assert "─" in out
    # Verdict pill (HEALTHY -> active pill in OK colour)
    assert "HEALTHY" in out
    assert PILL_ACTIVE in out
    # brand_section divider for Component Health
    assert "Component Health" in out
    # PID preserved
    assert "PID 17733" in out
    # brand_kv tail rows — labels + numeric values
    assert "Tests (last 1h)" in out
    assert "Tests (last 24h)" in out
    assert "12" in out
    assert "345" in out


def test_render_status_broken_verdict_uses_broken_pill() -> None:
    from halton_meter.lifecycle import _macos as lifecycle_macos

    summary = lifecycle_macos._HealthSummary("BROKEN", "daemon dead.")
    report = lifecycle_macos._StatusReport(
        rows=[lifecycle_macos._ComponentRow("Daemon", "dead", "no PID")],
        last_hour=0,
        last_day=0,
        healthy=False,
        health_summary=summary,
    )
    console = Console(file=StringIO(), force_terminal=False, width=120)
    lifecycle_macos._render_status(report, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]

    assert "BROKEN" in out
    # Broken pill glyph in the verdict line
    assert PILL_BROKEN in out


def test_render_status_stopped_verdict_uses_paused_pill() -> None:
    """STOPPED maps to the paused pill (○) — not BROKEN, not warn."""
    from halton_meter.lifecycle import _macos as lifecycle_macos

    summary = lifecycle_macos._HealthSummary("STOPPED", "graceful stop in effect.")
    report = lifecycle_macos._StatusReport(
        rows=[lifecycle_macos._ComponentRow("Daemon", "stopped", "")],
        last_hour=0,
        last_day=0,
        healthy=True,
        health_summary=summary,
    )
    console = Console(file=StringIO(), force_terminal=False, width=120)
    lifecycle_macos._render_status(report, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]

    assert "STOPPED" in out
    assert PILL_PAUSED in out


# ---------------------------------------------------------------------------
# start success / failure panels — masthead present, numerics preserved
# ---------------------------------------------------------------------------


def test_render_start_success_panel_emits_masthead_and_numerics() -> None:
    from halton_meter.lifecycle import _macos as lifecycle_macos

    console = Console(file=StringIO(), force_terminal=False, width=120)
    lifecycle_macos._render_start_success_panel(
        console,
        daemon_pid=4242,
        watchdog_pid=4243,
        api_port=8765,
        edge_port=8081,
        health_ms=2.0,
        elapsed_ms=5.0,
    )
    out = console.file.getvalue()  # type: ignore[attr-defined]

    # Editorial lead-in
    assert "halton-meter" in out
    assert "start" in out
    assert __version__ in out
    # Numerics preserved verbatim
    assert "4242" in out
    assert "4243" in out
    assert ":8765" in out
    assert "8081" in out
    # Existing copy preserved
    assert "metering active" in out
    assert "Daemon loaded" in out
    assert "Watchdog loaded" in out
    # Brand-active pill in the step rows
    assert PILL_ACTIVE in out


def test_render_start_failure_panel_keeps_diagnostic_copy() -> None:
    from halton_meter.lifecycle import _macos as lifecycle_macos

    console = Console(file=StringIO(), force_terminal=False, width=120)
    lifecycle_macos._render_start_failure_panel(
        console, api_port=8765, edge_port=8081
    )
    out = console.file.getvalue()  # type: ignore[attr-defined]

    # Lead-in
    assert "halton-meter" in out
    assert "start" in out
    # Critical action-oriented copy preserved
    assert "halton-meter doctor" in out
    assert "fail-open" in out
    assert ":8765" in out


# ---------------------------------------------------------------------------
# stop panel — masthead present, daemon/watchdog/proxy steps preserved
# ---------------------------------------------------------------------------


def test_stop_panel_renders_masthead_and_steps(monkeypatch, tmp_path) -> None:  # type: ignore[no-untyped-def]
    """Drive ``_stop_macos`` with everything stubbed — assert the panel
    surfaces the masthead, the per-step pills, and the edge tunnel hint."""
    from halton_meter.config import HaltonConfig
    from halton_meter.lifecycle import _macos as lifecycle_macos

    plist = tmp_path / "daemon.plist"
    watchdog = tmp_path / "watchdog.plist"
    plist.touch()
    watchdog.touch()
    monkeypatch.setattr(
        lifecycle_macos, "_macos_paths", lambda: (plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle_macos, "_macos_watchdog_plist_path", lambda: watchdog)
    cfg = HaltonConfig()  # type: ignore[call-arg]
    monkeypatch.setattr(lifecycle_macos, "load_effective_config", lambda: cfg)
    monkeypatch.setattr(lifecycle_macos, "_launchctl_bootout", lambda label: (0, ""))
    monkeypatch.setattr(lifecycle_macos, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle_macos, "_lsof_listen_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle_macos, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(
        lifecycle_macos, "_reset_macos_system_proxy", lambda console: ["Wi-Fi"]
    )
    # Suppress the sentinel write to keep the test pure.
    monkeypatch.setattr(
        "halton_meter.graceful_shutdown.write_graceful_shutdown_sentinel",
        lambda: None,
    )

    console = Console(file=StringIO(), force_terminal=False, width=120)
    rc = lifecycle_macos._stop_macos(console)
    out = console.file.getvalue()  # type: ignore[attr-defined]
    assert rc == 0

    # Editorial lead-in
    assert "halton-meter" in out
    assert "stop" in out
    # Existing copy substrings — load-bearing for the v0.1.22.10 tests
    assert "Daemon stopped" in out
    assert "Watchdog stopped" in out
    assert "System proxy reset on" in out
    assert "Wi-Fi" in out
    # Edge tunnel hint preserved
    assert "Edge proxy still running" in out
    # Active pill rendered for each successful step
    assert PILL_ACTIVE in out


# ---------------------------------------------------------------------------
# init — replaced brand_headline with brand_command_lead
# ---------------------------------------------------------------------------


def test_init_lead_uses_command_lead_with_subtitle_variants() -> None:
    """``init`` uses brand_command_lead — subtitle reflects --apps / --full."""
    out_apps = _capture(brand_command_lead("init --apps", version=__version__))
    out_full = _capture(brand_command_lead("init --full", version=__version__))
    out_default = _capture(brand_command_lead("init", version=__version__))

    for out in (out_apps, out_full, out_default):
        assert "halton-meter" in out
        assert __version__ in out
        assert "─" in out
    assert "init --apps" in out_apps
    assert "init --full" in out_full
    assert " init " in out_default or out_default.endswith("init\n") or "init" in out_default


# ---------------------------------------------------------------------------
# report — masthead + brand_kv summary
# ---------------------------------------------------------------------------


def test_report_header_and_summary_use_branding() -> None:
    from halton_meter import report as report_module

    data = report_module.ReportData(
        records=[],
        total_requests=42,
        total_input_tokens=1234,
        total_output_tokens=567,
        total_cost_millicents=12_345_000,
        cost_excluded_count=0,
        date_from="2026-05-01T00:00:00Z",
        date_to="2026-05-07T00:00:00Z",
        incomplete_count=0,
        project_stats=[],
        model_stats=[],
    )
    console = Console(file=StringIO(), force_terminal=False, width=120)
    report_module._render_header(data, console)
    report_module._render_summary(data, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]

    # Masthead + version + subtitle
    assert "halton-meter" in out
    assert __version__ in out
    assert "cost report" in out
    # Underrule
    assert "─" in out
    # Date arrow preserved
    assert "→" in out
    # brand_kv label/value pairs
    assert "Requests" in out
    assert "Tokens" in out
    assert "Total cost" in out
    # Numeric values preserved
    assert "42" in out
    assert "1,234" in out
    assert "567" in out


# ---------------------------------------------------------------------------
# doctor — masthead + brand_pill in Status column
# ---------------------------------------------------------------------------


def test_doctor_render_report_uses_masthead_and_pills() -> None:
    from halton_meter import doctor as doctor_module

    rows = [
        doctor_module.DoctorRow(
            name="config-loadable",
            icon="ok",
            summary="config loads cleanly",
            next_action=None,
        ),
        doctor_module.DoctorRow(
            name="cert-trust",
            icon="fail",
            summary="cert not trusted",
            next_action="run halton-meter init",
        ),
        doctor_module.DoctorRow(
            name="env-vars",
            icon="warn",
            summary="HTTPS_PROXY not set in this shell",
            next_action="reload your shell",
        ),
    ]
    report = doctor_module.DoctorReport(
        verdict=doctor_module.VERDICT_BROKEN,
        platform="darwin",
        version=__version__,
        mode="env-only",
        rows=rows,
        summary_message="cert trust is broken.",
    )
    console = Console(file=StringIO(), force_terminal=False, width=140)
    doctor_module.render_report(report, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]

    # Lead-in
    assert "halton-meter" in out
    assert "doctor" in out
    assert __version__ in out
    # Pill glyphs in the Status column — covers active (ok), broken
    # (fail), and degraded (warn → ◐) glyphs all in one render.
    assert PILL_ACTIVE in out  # ok row
    assert PILL_BROKEN in out  # fail row
    assert "◐" in out  # warn row
    # Doctor row content preserved
    assert "config-loadable" in out
    assert "cert-trust" in out
    assert "env-vars" in out
    # Verdict text preserved
    assert "BROKEN" in out
