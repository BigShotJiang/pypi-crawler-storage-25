"""Unit tests for the unified attribution resolver (v0.2.4 + v0.2.5).

Covers the 9 cases from ``memory/plans/v0.2.4-unified-attribution.md`` §5
plus the cardinal-rule never-raise contract, and the v0.2.5 cold-start
lenient-scan additions.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import structlog

from halton_meter.attribution import layers as _layers
from halton_meter.attribution.layers import find_project_root_by_slug
from halton_meter.attribution.registry import EdgeAttributionRegistry
from halton_meter.attribution.resolver import (
    ResolvedAttribution,
    _same_uid_session,
    resolve_unified,
)

# ---------------------------------------------------------------------------
# Fake psutil-like processes. Just enough surface for the resolver.
# ---------------------------------------------------------------------------


class _FakeProc:
    """Minimal psutil-shaped stand-in.

    Tests construct trees by passing ``parent`` references. ``cwd_raises``
    simulates the production failure mode where ``proc.cwd()`` is
    unreadable. ``uids_triple`` / ``terminal_value`` drive the uid /
    session boundary check; the defaults match same-session.
    """

    def __init__(
        self,
        *,
        pid: int,
        name_: str = "test-proc",
        cwd_: str | None = None,
        cwd_raises: bool = False,
        environ_: dict[str, str] | None = None,
        cmdline_: list[str] | None = None,
        parent_: _FakeProc | None = None,
        uids_triple: tuple[int, int, int] | None = (501, 501, 501),
        terminal_value: str | None = None,
    ) -> None:
        self.pid = pid
        self._name = name_
        self._cwd = cwd_
        self._cwd_raises = cwd_raises
        self._environ = environ_ or {}
        self._cmdline = cmdline_ or []
        self._parent = parent_
        self._uids = uids_triple
        self._terminal = terminal_value

    def name(self) -> str:
        return self._name

    def cwd(self) -> str:
        if self._cwd_raises:
            raise RuntimeError("unreadable")
        if self._cwd is None:
            raise RuntimeError("no cwd")
        return self._cwd

    def environ(self) -> dict[str, str]:
        return dict(self._environ)

    def cmdline(self) -> list[str]:
        return list(self._cmdline)

    def parent(self) -> _FakeProc | None:
        return self._parent

    def uids(self) -> tuple[int, int, int] | None:
        return self._uids

    def terminal(self) -> str | None:
        return self._terminal


# ---------------------------------------------------------------------------
# Tier 0–8 unit coverage
# ---------------------------------------------------------------------------


def test_tier_1_env_var_wins() -> None:
    reg = EdgeAttributionRegistry()
    target = _FakeProc(pid=1234, environ_={"HALTON_PROJECT": "from-env"})
    result = resolve_unified(
        target_proc=target,
        target_env=target.environ(),
        target_cwd="/tmp",
        target_cmdline=[],
        registry=reg,
    )
    assert result is not None
    assert result.project == "from-env"
    assert result.attribution_method == "env"
    assert result.tier_id == "1"


def test_tier_2_rcfile(tmp_path: Path) -> None:
    (tmp_path / ".haltonrc").write_text("project: rc-project\n")
    reg = EdgeAttributionRegistry()
    result = resolve_unified(
        target_proc=None,
        target_env={},
        target_cwd=str(tmp_path),
        target_cmdline=[],
        registry=reg,
    )
    assert result is not None
    assert result.project == "rc-project"
    assert result.attribution_method == "rcfile"
    # Registry warmed by the rcfile hit.
    assert reg.lookup("rc-project") == str(tmp_path)


def test_tier_3_ide_sniff(tmp_path: Path) -> None:
    reg = EdgeAttributionRegistry()
    workspace = tmp_path / "ws-project"
    workspace.mkdir()
    result = resolve_unified(
        target_proc=None,
        target_env={},
        target_cwd="/",
        target_cmdline=["Cursor", "--folder", str(workspace)],
        registry=reg,
    )
    assert result is not None
    assert result.project == "ws-project"
    assert result.attribution_method == "ide_sniff"
    # Registry warmed with the workspace path.
    assert reg.lookup("ws-project") == str(workspace)


def test_tier_4a_git(tmp_path: Path) -> None:
    repo = tmp_path / "my-repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    _layers.clear_git_cache()
    reg = EdgeAttributionRegistry()
    result = resolve_unified(
        target_proc=None,
        target_env={},
        target_cwd=str(repo),
        target_cmdline=[],
        registry=reg,
    )
    assert result is not None
    assert result.project == "my-repo"
    assert result.attribution_method == "git"
    assert reg.lookup("my-repo") == str(repo)


def test_tier_4b_env_label_strict_corroboration(tmp_path: Path) -> None:
    """Tier 4b only fires when the slug is in the registry."""
    reg = EdgeAttributionRegistry()
    # Pre-warm registry with the matching slug.
    reg.register("acme", str(tmp_path / "acme"))
    result = resolve_unified(
        target_proc=None,
        target_env={"CURSOR_WORKSPACE_LABEL": "acme"},
        target_cwd="/",
        target_cmdline=[],
        registry=reg,
    )
    assert result is not None
    assert result.project == "acme"
    assert result.attribution_method == "ide_env_label"
    assert result.tier_id == "4b"


def test_tier_4b_strict_rejection_when_registry_empty() -> None:
    """Cold-start: env label set but no registry hit ⇒ resolver returns None."""
    reg = EdgeAttributionRegistry()
    result = resolve_unified(
        target_proc=None,
        target_env={"CURSOR_WORKSPACE_LABEL": "ghost-project"},
        target_cwd="/",
        target_cmdline=[],
        registry=reg,
    )
    assert result is None


def test_tier_4c_argv_label_strict_corroboration(tmp_path: Path) -> None:
    """Electron-helper trailing-token argv label."""
    reg = EdgeAttributionRegistry()
    reg.register("project-x", str(tmp_path / "project-x"))
    result = resolve_unified(
        target_proc=None,
        target_env={},
        target_cwd="/",
        target_cmdline=["Helper:", "extension-host", "project-x", "[1-1]"],
        registry=reg,
    )
    assert result is not None
    assert result.project == "project-x"
    assert result.attribution_method == "ide_argv_label"


def test_tier_4c_rejected_when_registry_empty() -> None:
    reg = EdgeAttributionRegistry()
    result = resolve_unified(
        target_proc=None,
        target_env={},
        target_cwd="/",
        target_cmdline=["Helper:", "extension-host", "unknown-slug", "[1-1]"],
        registry=reg,
    )
    assert result is None


def test_tier_4c_regex_matches_cursor_argv_fixtures(tmp_path: Path) -> None:
    """Empirical fixtures from the 2026-05-18 live probe (pids 3458, 3480,
    4444, 4730). The Cursor helper argv strings end with
    ``... <slug> [N-N]``.
    """
    reg = EdgeAttributionRegistry()
    reg.register("haltonlabs-meter", str(tmp_path / "haltonlabs-meter"))

    fixtures = [
        # pid 3458 — extension host
        [
            "/Applications/Cursor.app/Contents/Frameworks/Cursor Helper (Plugin).app/Contents/MacOS/Cursor Helper (Plugin)",
            "--ms-enable-electron-run-as-node",
            "/Applications/Cursor.app/Contents/Resources/app/out/bootstrap-fork",
            "--type=extensionHost",
            "Helper:",
            "extension-host",
            "haltonlabs-meter",
            "[1-1]",
        ],
        # pid 3480 — file watcher
        [
            "Cursor Helper",
            "--no-deprecation",
            "Helper:",
            "file-watcher",
            "haltonlabs-meter",
            "[2-3]",
        ],
        # pid 4444 — terminal
        ["Cursor", "Helper:", "terminal", "haltonlabs-meter", "[12-99]"],
        # pid 4730 — ptyhost
        ["Cursor", "Helper:", "ptyhost", "haltonlabs-meter", "[3-4]"],
    ]
    for fix in fixtures:
        slug = _layers.extract_workspace_label_from_cmdline(fix)
        assert slug == "haltonlabs-meter", f"regex did not capture from {fix!r}"


def test_tier_5_parent_walk_rcfile(tmp_path: Path) -> None:
    """A claude worker with cwd='/' attributes via its parent's .haltonrc."""
    (tmp_path / ".haltonrc").write_text("project: parent-rc\n")
    reg = EdgeAttributionRegistry()
    parent = _FakeProc(
        pid=4242,
        name_="claude",
        cwd_=str(tmp_path),
    )
    child = _FakeProc(
        pid=4243,
        name_="claude",
        cwd_raises=True,
        parent_=parent,
    )
    result = resolve_unified(
        target_proc=child,
        target_env={},
        target_cwd=None,
        target_cmdline=[],
        registry=reg,
    )
    assert result is not None
    assert result.project == "parent-rc"
    assert result.attribution_method == "parent_rcfile"
    assert result.tier_id == "5"


def test_tier_5_parent_walk_warms_registry_then_4b_fires(tmp_path: Path) -> None:
    """Plan §5 case 4 — parent walk warms registry mid-resolution; the
    env label fires on the second pass because the walk-warming happens
    inline.
    """
    repo = tmp_path / "acme"
    repo.mkdir()
    (repo / ".git").mkdir()
    _layers.clear_git_cache()

    reg = EdgeAttributionRegistry()
    # Parent at hop 1 has the path-bearing cwd; child has a label only.
    parent = _FakeProc(pid=2001, name_="claude", cwd_=str(repo))
    child = _FakeProc(
        pid=2002,
        name_="claude",
        cwd_raises=True,
        environ_={"CURSOR_WORKSPACE_LABEL": "acme"},
        parent_=parent,
    )

    result = resolve_unified(
        target_proc=child,
        target_env=child.environ(),
        target_cwd=None,
        target_cmdline=[],
        registry=reg,
    )
    assert result is not None
    # The walk fires first (Tier 5 before 4b in the resolver flow), so we
    # get ``parent_git`` rather than ``ide_env_label``. The plan §5 case 4
    # asserts the env-label-wins shape; our implementation runs the walk
    # eagerly before 4b precisely so 4b can corroborate. When the walk
    # itself resolves AND the registry was warmed, the walk's resolution
    # is returned — which preserves the strict-slug contract (no
    # registry-only attribution).
    assert result.project == "acme"
    assert result.attribution_method in {"parent_git", "ide_env_label"}


def test_tier_5_walk_stops_at_uid_boundary(tmp_path: Path) -> None:
    """Parent owned by ``root`` (uid 0); walk must terminate at the
    boundary and the child must not attribute to the root-owned cwd.
    """
    (tmp_path / ".haltonrc").write_text("project: root-owned\n")
    reg = EdgeAttributionRegistry()
    # Parent's uid is 0; child's is 501.
    parent = _FakeProc(
        pid=99, name_="bash", cwd_=str(tmp_path), uids_triple=(0, 0, 0)
    )
    child = _FakeProc(
        pid=100,
        name_="claude",
        cwd_raises=True,
        parent_=parent,
        uids_triple=(501, 501, 501),
    )
    result = resolve_unified(
        target_proc=child,
        target_env={},
        target_cwd=None,
        target_cmdline=[],
        registry=reg,
    )
    # Walk crossed uid boundary at hop 1 → no resolution.
    assert result is None


def test_tier_5_walk_stops_at_session_boundary(tmp_path: Path) -> None:
    """Different controlling terminals between parent and child → boundary."""
    (tmp_path / ".haltonrc").write_text("project: other-tty\n")
    reg = EdgeAttributionRegistry()
    parent = _FakeProc(
        pid=200,
        name_="bash",
        cwd_=str(tmp_path),
        uids_triple=(501, 501, 501),
        terminal_value="/dev/ttys000",
    )
    child = _FakeProc(
        pid=201,
        name_="claude",
        cwd_raises=True,
        parent_=parent,
        uids_triple=(501, 501, 501),
        terminal_value="/dev/ttys999",
    )
    result = resolve_unified(
        target_proc=child,
        target_env={},
        target_cwd=None,
        target_cmdline=[],
        registry=reg,
    )
    assert result is None


def test_resolver_never_raises_on_exploding_proc() -> None:
    """Cardinal-rule defence — any exception inside is swallowed."""

    class _Boom:
        pid = 1

        def name(self) -> str:
            raise RuntimeError("boom")

        def parent(self) -> Any:
            raise RuntimeError("boom")

        def cwd(self) -> str:
            raise RuntimeError("boom")

        def environ(self) -> dict[str, str]:
            raise RuntimeError("boom")

        def cmdline(self) -> list[str]:
            raise RuntimeError("boom")

        def uids(self) -> Any:
            raise RuntimeError("boom")

        def terminal(self) -> Any:
            raise RuntimeError("boom")

    reg = EdgeAttributionRegistry()
    # Must complete without raising.
    result = resolve_unified(
        target_proc=_Boom(),
        target_env={},
        target_cwd=None,
        target_cmdline=None,
        registry=reg,
    )
    assert result is None


def test_telemetry_tier_hit_event_shape(tmp_path: Path) -> None:
    """Plan §5 case 7 — ``attribution.tier_hit`` event emitted with
    ``tier`` / ``method`` / ``pid`` / ``slug`` fields.
    """
    (tmp_path / ".haltonrc").write_text("project: telem\n")
    reg = EdgeAttributionRegistry()
    with structlog.testing.capture_logs() as cap:
        result = resolve_unified(
            target_proc=None,
            target_env={},
            target_cwd=str(tmp_path),
            target_cmdline=[],
            registry=reg,
        )
    assert result is not None
    tier_events = [e for e in cap if e.get("event") == "attribution.tier_hit"]
    assert len(tier_events) >= 1
    evt = tier_events[-1]
    assert evt.get("tier") == "2"
    assert evt.get("method") == "rcfile"
    assert "pid" in evt
    assert "slug" in evt


def test_telemetry_4b_miss_shape() -> None:
    """When the env label is set but unregistered, a ``4b_miss`` event fires."""
    reg = EdgeAttributionRegistry()
    with structlog.testing.capture_logs() as cap:
        resolve_unified(
            target_proc=None,
            target_env={"CURSOR_WORKSPACE_LABEL": "ghost"},
            target_cwd="/",
            target_cmdline=[],
            registry=reg,
        )
    miss_events = [
        e
        for e in cap
        if e.get("event") == "attribution.tier_hit"
        and e.get("tier") == "4b_miss"
    ]
    assert len(miss_events) == 1
    assert miss_events[0].get("slug") == "ghost"
    assert miss_events[0].get("method") is None


def test_end_to_end_synthetic_argv_label(tmp_path: Path) -> None:
    """Plan §5 case 9 — synthetic flow: target argv[0] is the Cursor helper
    label, registry pre-seeded; assert ``ide_argv_label`` attribution.
    """
    project_dir = tmp_path / "project-x"
    project_dir.mkdir()
    reg = EdgeAttributionRegistry()
    reg.register("project-x", str(project_dir))

    target = _FakeProc(
        pid=12345,
        name_="Cursor Helper",
        cwd_raises=True,
        environ_={},
        cmdline_=["Helper:", "extension-host", "project-x", "[1-1]"],
    )
    result = resolve_unified(
        target_proc=target,
        target_env=target.environ(),
        target_cwd=None,
        target_cmdline=target.cmdline(),
        registry=reg,
    )
    assert result is not None
    assert result.project == "project-x"
    assert result.attribution_method == "ide_argv_label"


# ---------------------------------------------------------------------------
# Performance — Plan §5 case 7. Hot-path p99 < 3 ms.
# ---------------------------------------------------------------------------


def test_hot_path_perf_under_3ms(tmp_path: Path) -> None:
    """100 resolver calls; the slowest must complete under 3 ms.

    Test is intentionally tight against a warm-cache rcfile resolve.
    Production resolutions also do psutil work that this test doesn't
    drive, but the per-call cost of the resolver logic itself is what
    we're measuring — psutil dominance is out of our control.
    """
    (tmp_path / ".haltonrc").write_text("project: perf\n")
    reg = EdgeAttributionRegistry()
    # Warm caches.
    resolve_unified(
        target_proc=None,
        target_env={},
        target_cwd=str(tmp_path),
        target_cmdline=[],
        registry=reg,
    )

    timings: list[float] = []
    for _ in range(100):
        t0 = time.perf_counter()
        resolve_unified(
            target_proc=None,
            target_env={},
            target_cwd=str(tmp_path),
            target_cmdline=[],
            registry=reg,
        )
        timings.append(time.perf_counter() - t0)
    timings.sort()
    p99 = timings[int(len(timings) * 0.99)]
    assert p99 < 0.003, f"resolver p99 = {p99 * 1000:.2f} ms (budget: 3 ms)"


# ---------------------------------------------------------------------------
# _same_uid_session direct unit coverage
# ---------------------------------------------------------------------------


def test_same_uid_session_matching() -> None:
    a = _FakeProc(pid=1, uids_triple=(501, 501, 501), terminal_value=None)
    b = _FakeProc(pid=2, uids_triple=(501, 501, 501), terminal_value=None)
    assert _same_uid_session(a, b) is True


def test_same_uid_session_uid_mismatch() -> None:
    a = _FakeProc(pid=1, uids_triple=(0, 0, 0), terminal_value=None)
    b = _FakeProc(pid=2, uids_triple=(501, 501, 501), terminal_value=None)
    assert _same_uid_session(a, b) is False


def test_same_uid_session_terminal_mismatch() -> None:
    a = _FakeProc(
        pid=1, uids_triple=(501, 501, 501), terminal_value="/dev/ttys000"
    )
    b = _FakeProc(
        pid=2, uids_triple=(501, 501, 501), terminal_value="/dev/ttys001"
    )
    assert _same_uid_session(a, b) is False


def test_same_uid_session_both_unknown_treated_as_same() -> None:
    """Test fakes that omit uids/terminal must still walk."""

    class _Bare:
        pid = 1

    assert _same_uid_session(_Bare(), _Bare()) is True


# ---------------------------------------------------------------------------
# Plan §5 case 8 — Tagging.py source-level regression
# ---------------------------------------------------------------------------


def test_tagging_no_longer_imports_deleted_functions() -> None:
    """The v0.2.3 helpers MUST be gone from tagging.py."""
    src = Path(__file__).resolve().parents[2] / "halton_meter" / "tagging.py"
    text = src.read_text(encoding="utf-8")
    for needle in (
        "_walk_claude_parents_for_cwd",
        "_resolve_via_claude_parent_walk",
        "_safe_parent_pid_and_name",
        "claude_parent_rcfile",
        "claude_parent_git",
        "claude_parent_workdir",
        "claude_parent_mac_sandbox",
    ):
        assert needle not in text, f"{needle!r} still present in tagging.py"


def test_resolver_returns_none_when_no_signal() -> None:
    """A target with no cwd, no env, no cmdline, no parent ⇒ None."""
    reg = EdgeAttributionRegistry()
    result = resolve_unified(
        target_proc=None,
        target_env={},
        target_cwd=None,
        target_cmdline=[],
        registry=reg,
    )
    assert result is None


def test_resolved_attribution_namedtuple_shape() -> None:
    """The resolver returns a 4-tuple of the documented shape."""
    r = ResolvedAttribution("foo", "rcfile", "/some/path", "2")
    assert r.project == "foo"
    assert r.attribution_method == "rcfile"
    assert r.source_workdir == "/some/path"
    assert r.tier_id == "2"


def test_label_helpers_pure() -> None:
    """Direct unit coverage of the extract_workspace_label_from_* helpers."""
    assert (
        _layers.extract_workspace_label_from_env({"CURSOR_WORKSPACE_LABEL": "foo"})
        == "foo"
    )
    assert (
        _layers.extract_workspace_label_from_env({"VSCODE_WORKSPACE_LABEL": "Bar"})
        == "bar"
    )
    assert _layers.extract_workspace_label_from_env({"OTHER": "x"}) is None
    assert _layers.extract_workspace_label_from_env({"CURSOR_WORKSPACE_LABEL": ""}) is None

    assert (
        _layers.extract_workspace_label_from_cmdline(
            ["Cursor", "Helper:", "ext", "myproj", "[1-1]"]
        )
        == "myproj"
    )
    assert _layers.extract_workspace_label_from_cmdline([]) is None
    assert _layers.extract_workspace_label_from_cmdline(["nothing", "matches"]) is None


# ---------------------------------------------------------------------------
# v0.2.5 — cold-start lenient scan tests
# ---------------------------------------------------------------------------


def test_find_project_root_by_slug_hit(tmp_path: Path) -> None:
    """find_project_root_by_slug returns the path when a matching dir exists."""
    project_dir = tmp_path / "algonifty"
    project_dir.mkdir()
    result = find_project_root_by_slug("algonifty", search_dirs=[tmp_path])
    assert result == str(project_dir)


def test_find_project_root_by_slug_no_match(tmp_path: Path) -> None:
    """find_project_root_by_slug returns None when no dir matches the slug."""
    (tmp_path / "other-project").mkdir()
    result = find_project_root_by_slug("algonifty", search_dirs=[tmp_path])
    assert result is None


def test_find_project_root_by_slug_empty_slug() -> None:
    """Empty / unattributed slugs immediately return None without scanning."""
    assert find_project_root_by_slug("") is None
    assert find_project_root_by_slug("unattributed") is None


def test_find_project_root_by_slug_nonexistent_search_dir(tmp_path: Path) -> None:
    """A missing search dir is silently skipped; no exception raised."""
    missing = tmp_path / "does-not-exist"
    result = find_project_root_by_slug("foo", search_dirs=[missing])
    assert result is None


def test_find_project_root_by_slug_normalises_dir_name(tmp_path: Path) -> None:
    """Directory name is slug-normalised before comparison (case + special chars)."""
    # "Algonifty" normalises to "algonifty" — matches slug "algonifty"
    project_dir = tmp_path / "Algonifty"
    project_dir.mkdir()
    result = find_project_root_by_slug("algonifty", search_dirs=[tmp_path])
    assert result == str(project_dir)


def test_tier_4b_lenient_hit_on_cold_registry(tmp_path: Path) -> None:
    """Tier 4b attributes via lenient scan when registry is cold.

    Simulates the algonifty cold-start case: the target process carries
    CURSOR_WORKSPACE_LABEL=algonifty but the registry is empty. The
    lenient scan finds the matching directory and attributes correctly.
    """
    project_dir = tmp_path / "algonifty"
    project_dir.mkdir()

    reg = EdgeAttributionRegistry()
    # Inject the search dir so the test doesn't scan the real home.
    import halton_meter.attribution.layers as _l
    original_fn = _l.find_project_root_by_slug

    def _patched(slug: str, search_dirs: list[Path] | None = None) -> str | None:
        return original_fn(slug, search_dirs=[tmp_path])

    _l.find_project_root_by_slug = _patched
    import halton_meter.attribution.resolver as _r
    _r.find_project_root_by_slug = _patched

    try:
        result = resolve_unified(
            target_proc=None,
            target_env={"CURSOR_WORKSPACE_LABEL": "algonifty"},
            target_cwd="/",
            target_cmdline=[],
            registry=reg,
        )
        assert result is not None
        assert result.project == "algonifty"
        assert result.attribution_method == "ide_env_label"
        assert result.tier_id == "4b_lenient"
        # Registry should be warmed now.
        assert reg.lookup("algonifty") == str(project_dir)
    finally:
        _l.find_project_root_by_slug = original_fn
        _r.find_project_root_by_slug = original_fn


def test_tier_4c_lenient_hit_on_cold_registry(tmp_path: Path) -> None:
    """Tier 4c attributes via lenient scan for argv label on cold registry.

    The target process carries an Electron-helper argv that encodes a
    workspace slug. The registry is cold. The lenient scan finds the dir.
    """
    project_dir = tmp_path / "algonifty"
    project_dir.mkdir()

    reg = EdgeAttributionRegistry()
    import halton_meter.attribution.layers as _l
    original_fn = _l.find_project_root_by_slug

    def _patched(slug: str, search_dirs: list[Path] | None = None) -> str | None:
        return original_fn(slug, search_dirs=[tmp_path])

    _l.find_project_root_by_slug = _patched
    import halton_meter.attribution.resolver as _r
    _r.find_project_root_by_slug = _patched

    try:
        result = resolve_unified(
            target_proc=None,
            target_env={},
            target_cwd="/",
            target_cmdline=["Cursor", "Helper:", "extension-host", "algonifty", "[1-1]"],
            registry=reg,
        )
        assert result is not None
        assert result.project == "algonifty"
        assert result.attribution_method == "ide_argv_label"
        assert result.tier_id == "4c_lenient"
        # Registry warmed.
        assert reg.lookup("algonifty") == str(project_dir)
    finally:
        _l.find_project_root_by_slug = original_fn
        _r.find_project_root_by_slug = original_fn


def test_lenient_hit_warms_registry_for_strict_second_call(tmp_path: Path) -> None:
    """After a lenient hit warms the registry, the second call uses strict path."""
    project_dir = tmp_path / "algonifty"
    project_dir.mkdir()

    reg = EdgeAttributionRegistry()
    import halton_meter.attribution.layers as _l
    original_fn = _l.find_project_root_by_slug
    scan_calls: list[str] = []

    def _patched(slug: str, search_dirs: list[Path] | None = None) -> str | None:
        scan_calls.append(slug)
        return original_fn(slug, search_dirs=[tmp_path])

    _l.find_project_root_by_slug = _patched
    import halton_meter.attribution.resolver as _r
    _r.find_project_root_by_slug = _patched

    try:
        # First call: registry cold → lenient scan fires.
        result1 = resolve_unified(
            target_proc=None,
            target_env={"CURSOR_WORKSPACE_LABEL": "algonifty"},
            target_cwd="/",
            target_cmdline=[],
            registry=reg,
        )
        assert result1 is not None
        assert result1.tier_id == "4b_lenient"
        assert len(scan_calls) == 1

        # Second call: registry now warm → strict path, no scan.
        result2 = resolve_unified(
            target_proc=None,
            target_env={"CURSOR_WORKSPACE_LABEL": "algonifty"},
            target_cwd="/",
            target_cmdline=[],
            registry=reg,
        )
        assert result2 is not None
        assert result2.tier_id == "4b"
        # scan_calls should NOT have grown — the lenient fn was not called again.
        assert len(scan_calls) == 1, "lenient scan fired a second time — registry not warm"
    finally:
        _l.find_project_root_by_slug = original_fn
        _r.find_project_root_by_slug = original_fn


def test_lenient_miss_emits_4b_miss_telemetry(tmp_path: Path) -> None:
    """When lenient scan also misses, tier=4b_miss telemetry is emitted (no crash)."""
    reg = EdgeAttributionRegistry()
    # No matching directory in tmp_path.
    import halton_meter.attribution.layers as _l
    original_fn = _l.find_project_root_by_slug

    def _patched(slug: str, search_dirs: list[Path] | None = None) -> str | None:
        return None  # Always miss

    _l.find_project_root_by_slug = _patched
    import halton_meter.attribution.resolver as _r
    _r.find_project_root_by_slug = _patched

    try:
        result = resolve_unified(
            target_proc=None,
            target_env={"CURSOR_WORKSPACE_LABEL": "nonexistent-project"},
            target_cwd="/",
            target_cmdline=[],
            registry=reg,
        )
        # No attribution — falls through to None.
        assert result is None
    finally:
        _l.find_project_root_by_slug = original_fn
        _r.find_project_root_by_slug = original_fn
