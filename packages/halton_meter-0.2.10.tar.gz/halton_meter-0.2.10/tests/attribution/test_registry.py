"""Unit tests for the per-edge attribution registry (v0.2.4)."""

from __future__ import annotations

from halton_meter.attribution.registry import EdgeAttributionRegistry


def test_register_and_lookup_roundtrip() -> None:
    reg = EdgeAttributionRegistry()
    reg.register("project-x", "/Users/alice/project-x")
    assert reg.lookup("project-x") == "/Users/alice/project-x"


def test_lookup_returns_none_for_unknown() -> None:
    reg = EdgeAttributionRegistry()
    assert reg.lookup("never-registered") is None


def test_register_normalises_slug() -> None:
    """Mixed-case / whitespace input still finds the registered path."""
    reg = EdgeAttributionRegistry()
    reg.register("Project X", "/p/x")
    # Both lookups normalise to ``project-x``.
    assert reg.lookup("project-x") == "/p/x"
    assert reg.lookup("Project X") == "/p/x"


def test_empty_inputs_ignored() -> None:
    reg = EdgeAttributionRegistry()
    reg.register("", "/some/path")
    reg.register("slug", "")
    assert reg.lookup("slug") is None
    assert reg.known_slugs() == set()


def test_clear() -> None:
    reg = EdgeAttributionRegistry()
    reg.register("a", "/a")
    reg.register("b", "/b")
    assert reg.known_slugs() == {"a", "b"}
    reg.clear()
    assert reg.known_slugs() == set()
    assert reg.lookup("a") is None


def test_overwrite_on_reregister() -> None:
    reg = EdgeAttributionRegistry()
    reg.register("p", "/old")
    reg.register("p", "/new")
    assert reg.lookup("p") == "/new"
