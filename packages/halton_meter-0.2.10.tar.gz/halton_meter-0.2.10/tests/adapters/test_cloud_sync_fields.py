"""Per-adapter unit tests for the Wave 1A.ii cloud-sync fields.

Each adapter's ``parse_request`` is expected to populate three new
fields on ``RequestMetadata``:

* ``request_kind`` — ``chat`` / ``embedding`` / ``tool`` / ``unknown``.
* ``prompt_hash`` — SHA-256 hex digest of the canonical-JSON request
  body. ``None`` when the body is not JSON-decodable or empty.
* ``idempotency_key`` — echoed verbatim from the request headers.
  ``None`` when no such header is present.

These tests are deliberately lightweight — the heavy contract logic
(hashing, header lookup, kind classification) lives in
``halton_meter.cloud_fields`` and is unit-tested in
``tests/test_cloud_fields.py``. The adapter tests assert that the
adapter wires the helpers correctly into ``parse_request``.

No live network. Flows are constructed via mitmproxy's ``tflow`` /
``tutils`` helpers (same shape as the existing adapter test files).
"""

from __future__ import annotations

import json

from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters.anthropic import AnthropicAdapter
from halton_meter.adapters.gemini import GeminiAdapter
from halton_meter.adapters.gemini_code_assist import GeminiCodeAssistAdapter
from halton_meter.adapters.openai import OpenAIAdapter
from halton_meter.adapters.openai_codex import OpenAICodexAdapter
from halton_meter.adapters.xai import XAIAdapter
from halton_meter.cloud_fields import (
    REQUEST_KIND_CHAT,
    REQUEST_KIND_EMBEDDING,
    REQUEST_KIND_TOOL,
    canonical_prompt_hash,
)


def _make_flow(
    *,
    host: str,
    path: str,
    request_body: dict | bytes | None = None,
    headers: dict[str, str] | None = None,
) -> http.HTTPFlow:
    """Construct a mitmproxy flow with the given request shape."""
    req = tutils.treq(host=host, port=443, path=path)
    if isinstance(request_body, dict):
        req.content = json.dumps(request_body).encode()
    elif isinstance(request_body, (bytes, bytearray)):
        req.content = bytes(request_body)
    else:
        req.content = b""
    if headers:
        for k, v in headers.items():
            req.headers[k] = v
    return tflow.tflow(req=req)


# ---------------------------------------------------------------------------
# AnthropicAdapter
# ---------------------------------------------------------------------------


class TestAnthropicCloudFields:
    def test_chat_request_populates_kind_and_hash(self) -> None:
        body = {
            "model": "claude-haiku-4-5",
            "messages": [{"role": "user", "content": "hi"}],
        }
        flow = _make_flow(
            host="api.anthropic.com", path="/v1/messages", request_body=body
        )
        meta = AnthropicAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash == canonical_prompt_hash(body)
        assert meta.idempotency_key is None

    def test_tool_use_promotes_kind_to_tool(self) -> None:
        body = {
            "model": "claude-haiku-4-5",
            "messages": [{"role": "user", "content": "calc 1+1"}],
            "tools": [{"name": "calculator"}],
        }
        flow = _make_flow(
            host="api.anthropic.com", path="/v1/messages", request_body=body
        )
        meta = AnthropicAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_TOOL

    def test_idempotency_key_header_echoed(self) -> None:
        flow = _make_flow(
            host="api.anthropic.com",
            path="/v1/messages",
            request_body={"model": "claude-haiku-4-5", "messages": []},
            headers={"Anthropic-Idempotency-Key": "abc-123"},
        )
        meta = AnthropicAdapter().parse_request(flow)
        assert meta.idempotency_key == "abc-123"

    def test_generic_idempotency_header_also_accepted(self) -> None:
        flow = _make_flow(
            host="api.anthropic.com",
            path="/v1/messages",
            request_body={"model": "claude-haiku-4-5", "messages": []},
            headers={"Idempotency-Key": "key-2"},
        )
        meta = AnthropicAdapter().parse_request(flow)
        assert meta.idempotency_key == "key-2"

    def test_non_json_body_leaves_prompt_hash_none(self) -> None:
        flow = _make_flow(
            host="api.anthropic.com",
            path="/v1/messages",
            request_body=b"not-json-at-all",
        )
        meta = AnthropicAdapter().parse_request(flow)
        # request_kind still classifiable by path alone.
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash is None


# ---------------------------------------------------------------------------
# OpenAIAdapter
# ---------------------------------------------------------------------------


class TestOpenAICloudFields:
    def test_chat_completions_request_kind_and_hash(self) -> None:
        body = {
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
        }
        flow = _make_flow(
            host="api.openai.com",
            path="/v1/chat/completions",
            request_body=body,
        )
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash == canonical_prompt_hash(body)

    def test_embeddings_request_classified_as_embedding(self) -> None:
        body = {"model": "text-embedding-3-small", "input": "hello"}
        flow = _make_flow(
            host="api.openai.com",
            path="/v1/embeddings",
            request_body=body,
        )
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_EMBEDDING

    def test_tool_use_promotes_to_tool(self) -> None:
        body = {
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "calc"}],
            "tools": [{"type": "function", "function": {"name": "calc"}}],
        }
        flow = _make_flow(
            host="api.openai.com",
            path="/v1/chat/completions",
            request_body=body,
        )
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_TOOL

    def test_idempotency_key_header_captured(self) -> None:
        flow = _make_flow(
            host="api.openai.com",
            path="/v1/chat/completions",
            request_body={"model": "gpt-4o-mini", "messages": []},
            headers={"Idempotency-Key": "openai-abc"},
        )
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.idempotency_key == "openai-abc"


# ---------------------------------------------------------------------------
# GeminiAdapter
# ---------------------------------------------------------------------------


class TestGeminiCloudFields:
    def test_generate_content_is_chat(self) -> None:
        body = {"contents": [{"role": "user", "parts": [{"text": "hi"}]}]}
        flow = _make_flow(
            host="generativelanguage.googleapis.com",
            path="/v1beta/models/gemini-2.5-pro:generateContent",
            request_body=body,
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash == canonical_prompt_hash(body)

    def test_embed_content_is_embedding(self) -> None:
        body = {"content": {"parts": [{"text": "hello"}]}}
        flow = _make_flow(
            host="generativelanguage.googleapis.com",
            path="/v1beta/models/text-embedding-004:embedContent",
            request_body=body,
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_EMBEDDING

    def test_idempotency_key_captured(self) -> None:
        flow = _make_flow(
            host="generativelanguage.googleapis.com",
            path="/v1beta/models/gemini-2.5-pro:generateContent",
            request_body={"contents": []},
            headers={"X-Idempotency-Key": "g-key"},
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.idempotency_key == "g-key"


# ---------------------------------------------------------------------------
# GeminiCodeAssistAdapter
# ---------------------------------------------------------------------------


class TestGeminiCodeAssistCloudFields:
    def test_request_kind_chat_and_prompt_hash(self) -> None:
        body = {"model": "gemini-2.5-pro", "request": {"contents": []}}
        flow = _make_flow(
            host="cloudcode-pa.googleapis.com",
            path="/v1internal:generateContent",
            request_body=body,
        )
        meta = GeminiCodeAssistAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash == canonical_prompt_hash(body)


# ---------------------------------------------------------------------------
# OpenAICodexAdapter
# ---------------------------------------------------------------------------


class TestOpenAICodexCloudFields:
    def test_request_kind_chat_and_prompt_hash(self) -> None:
        body = {
            "model": "gpt-5.3-codex",
            "input": [{"role": "user", "content": "refactor this"}],
        }
        flow = _make_flow(
            host="chatgpt.com",
            path="/backend-api/codex/responses",
            request_body=body,
        )
        meta = OpenAICodexAdapter().parse_request(flow)
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash == canonical_prompt_hash(body)

    def test_idempotency_key_captured(self) -> None:
        flow = _make_flow(
            host="chatgpt.com",
            path="/backend-api/codex/responses",
            request_body={"model": "gpt-5.3-codex", "input": []},
            headers={"Idempotency-Key": "codex-1"},
        )
        meta = OpenAICodexAdapter().parse_request(flow)
        assert meta.idempotency_key == "codex-1"


# ---------------------------------------------------------------------------
# XAIAdapter — delegation must propagate Wave 1A.ii fields from siblings
# ---------------------------------------------------------------------------


class TestXAICloudFields:
    def test_messages_path_propagates_anthropic_sibling_fields(self) -> None:
        body = {
            "model": "grok-2",
            "messages": [{"role": "user", "content": "hi"}],
        }
        flow = _make_flow(
            host="api.x.ai",
            path="/v1/messages",
            request_body=body,
            headers={"Idempotency-Key": "x-1"},
        )
        meta = XAIAdapter().parse_request(flow)
        # Provider stays relabelled to xai but the Wave 1A.ii fields
        # come through from the Anthropic sibling.
        assert meta.provider == "xai"
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash == canonical_prompt_hash(body)
        assert meta.idempotency_key == "x-1"

    def test_chat_completions_path_propagates_openai_sibling_fields(
        self,
    ) -> None:
        body = {
            "model": "grok-2",
            "messages": [{"role": "user", "content": "hi"}],
        }
        flow = _make_flow(
            host="api.x.ai",
            path="/v1/chat/completions",
            request_body=body,
        )
        meta = XAIAdapter().parse_request(flow)
        assert meta.provider == "xai"
        assert meta.request_kind == REQUEST_KIND_CHAT
        assert meta.prompt_hash == canonical_prompt_hash(body)
