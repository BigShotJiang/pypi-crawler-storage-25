"""
Tests for halton_meter.tagging — resolve_project().

Covers all four resolution paths:
  1. HALTON_PROJECT env var set and non-empty
  2. HALTON_PROJECT env var empty → falls through
  3. .haltonrc in CWD
  4. .haltonrc in a parent directory
  5. No .haltonrc → falls through to workdir basename
  6. psutil lookup failure → graceful fallback

Plus the Step 0 (edge attribution store) hot path: when the
``attribution_store`` singleton is wired and a row exists for
``flow.client_conn.peername[1]``, the lookup wins over every legacy
step.

Uses a simple sentinel object as the flow (resolve_project accepts any
object; the psutil path is mocked/bypassed via monkeypatching
_get_process_cwd).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

import halton_meter.tagging as tagging_mod
from halton_meter import attribution_store
from halton_meter.tagging import resolve_project, resolve_project_with_meta


@pytest.fixture(autouse=True)
def _isolate_store():
    """Reset the attribution-store singleton around each test.

    The legacy tests in this module exercise paths that should NOT
    consult the store; the Step 0 tests at the bottom wire it
    explicitly. The autouse reset prevents any test from inheriting
    a path from a prior run.
    """
    attribution_store.set_db_path(None)
    # v0.2.4 — also reset the unified resolver's per-edge registry.
    # The singleton accumulates ``slug → path`` warming across calls;
    # without a reset, ordering between tests would matter.
    try:
        from halton_meter.attribution.registry import get_edge_registry

        get_edge_registry().clear()
    except Exception:
        pass
    yield
    attribution_store.set_db_path(None)
    try:
        from halton_meter.attribution.registry import get_edge_registry

        get_edge_registry().clear()
    except Exception:
        pass


class _FakeFlow:
    """Minimal stand-in for an mitmproxy HTTPFlow."""
    pass


# ---------------------------------------------------------------------------
# Env var
# ---------------------------------------------------------------------------


def test_env_var_wins(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """When HALTON_PROJECT is set, it wins regardless of .haltonrc or cwd."""
    monkeypatch.setenv("HALTON_PROJECT", "env-driven-project")
    # Even if there's a .haltonrc in CWD it should not be consulted
    (tmp_path / ".haltonrc").write_text("project: rcfile-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "env-driven-project"


def test_env_var_empty_falls_through(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """When HALTON_PROJECT is set but empty, we fall through to .haltonrc."""
    monkeypatch.setenv("HALTON_PROJECT", "")
    (tmp_path / ".haltonrc").write_text("project: rcfile-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "rcfile-project"


def test_env_var_whitespace_only_falls_through(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Whitespace-only HALTON_PROJECT must be treated as unset."""
    monkeypatch.setenv("HALTON_PROJECT", "   ")
    (tmp_path / ".haltonrc").write_text("project: rcfile-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "rcfile-project"


def test_env_var_unset_falls_through(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """When HALTON_PROJECT is not in the environment, fall through to .haltonrc."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: my-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "my-project"


# ---------------------------------------------------------------------------
# .haltonrc in CWD
# ---------------------------------------------------------------------------


def test_haltonrc_in_cwd(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A .haltonrc in the process's CWD must be found and used."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: invoice-app\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "invoice-app"


def test_haltonrc_strips_whitespace(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Leading/trailing whitespace stripped; interior spaces become '-'.

    PR2 (2026-05-02) — the slug normaliser was extended to the v0.3
    rules: any character outside ``[a-z0-9:_/-]`` becomes ``-``, then
    runs collapse, then leading/trailing ``-`` strip. Interior spaces
    are no longer preserved verbatim. Pre-PR2 this test asserted
    ``"my project name"``; under the new rules the canonical slug is
    ``"my-project-name"`` (dashboard URL routing safe). Documented as
    an intentional behaviour change in the PR2 commit.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project:   my project name   \n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "my-project-name"


def test_haltonrc_ignores_unrelated_lines(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Non-project lines in .haltonrc must be ignored."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text(
        "# comment\nfoo: bar\nproject: correct-project\nbaz: qux\n"
    )
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "correct-project"


# ---------------------------------------------------------------------------
# .haltonrc in a parent directory
# ---------------------------------------------------------------------------


def test_haltonrc_in_parent_dir(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A .haltonrc in a parent directory must be found by the walk."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    # Root RC file
    (tmp_path / ".haltonrc").write_text("project: parent-project\n")
    # CWD is a nested subdirectory
    nested = tmp_path / "src" / "module"
    nested.mkdir(parents=True)
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(nested)):
        result = resolve_project(_FakeFlow())
    assert result == "parent-project"


def test_haltonrc_nearest_wins(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """When both CWD and a parent have .haltonrc, the CWD one wins."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: parent-project\n")
    child_dir = tmp_path / "child"
    child_dir.mkdir()
    (child_dir / ".haltonrc").write_text("project: child-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(child_dir)):
        result = resolve_project(_FakeFlow())
    assert result == "child-project"


# ---------------------------------------------------------------------------
# No .haltonrc — falls back to workdir basename
# ---------------------------------------------------------------------------


def test_no_haltonrc_falls_to_basename(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """With no .haltonrc, the CWD basename is used as the project name."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    project_dir = tmp_path / "my-cool-project"
    project_dir.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(project_dir)):
        result = resolve_project(_FakeFlow())
    assert result == "my-cool-project"


# ---------------------------------------------------------------------------
# psutil failure — graceful fallback
# ---------------------------------------------------------------------------


def test_psutil_failure_falls_through_gracefully(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """If _get_process_cwd raises, resolve_project must not propagate the error."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    def _raise(*args: object, **kwargs: object) -> str:
        raise RuntimeError("psutil not available")

    with patch.object(tagging_mod, "_get_process_cwd", side_effect=_raise):
        # Must not raise — falls through to "unknown"
        result = resolve_project(_FakeFlow())
    # We don't assert the exact value (it depends on real CWD), just no exception
    assert isinstance(result, str)


def test_get_process_cwd_psutil_exception_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    """_get_process_cwd must return None when psutil raises (v0.1.8 Gap 6).

    Pre-Gap-6 this returned ``os.getcwd()`` which under launchd is
    ``~/.halton-meter`` — producing the bogus ``.halton-meter``
    project tag. Now: None, and the caller short-circuits to
    ``unattributed``.
    """
    with patch.dict("sys.modules", {"psutil": None}):
        cwd = tagging_mod._get_process_cwd(object())
    assert cwd is None


def test_get_process_cwd_non_http_flow_returns_none() -> None:
    """_get_process_cwd must return None for non-HTTPFlow objects (Gap 6)."""
    result = tagging_mod._get_process_cwd(object())
    assert result is None


# ---------------------------------------------------------------------------
# read_haltonrc unit tests
# ---------------------------------------------------------------------------


def test_read_haltonrc_returns_none_when_not_found(tmp_path: Path) -> None:
    """_read_haltonrc must return None when no .haltonrc exists in the tree."""
    # Use a tmp subdirectory whose parents definitely don't have a .haltonrc
    subdir = tmp_path / "a" / "b"
    subdir.mkdir(parents=True)
    # No .haltonrc anywhere under tmp_path
    result = tagging_mod._read_haltonrc(str(subdir))
    # We can't guarantee no .haltonrc exists in real parent dirs above tmp_path,
    # so just verify the return type is correct
    assert result is None or isinstance(result, str)


def test_read_haltonrc_empty_project_value_skipped(tmp_path: Path) -> None:
    """A .haltonrc with `project:` but no value must be skipped."""
    (tmp_path / ".haltonrc").write_text("project:\n")
    result = tagging_mod._read_haltonrc(str(tmp_path))
    # Empty value → falls through, so result is None (no parent rc)
    # We just verify it did not return empty string
    assert result != ""


def test_resolve_project_unattributed_when_no_info(monkeypatch: pytest.MonkeyPatch) -> None:
    """When no env var, no .haltonrc, and basename is empty, return 'unattributed'."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    # Patch _get_process_cwd to return "/" (root — basename is "")
    with patch.object(tagging_mod, "_get_process_cwd", return_value="/"):
        result = resolve_project(_FakeFlow())

    # If there's a .haltonrc at / we'd get that, but in practice there won't be
    assert isinstance(result, str)
    assert len(result) > 0


# ---------------------------------------------------------------------------
# Gap 6 (v0.1.8) — fallback + leading-dot rejection
# ---------------------------------------------------------------------------


def test_unresolvable_cwd_returns_smart_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When _get_process_cwd returns None, project is the smart default.

    Gap 6 fix: pre-fix, _get_process_cwd fell back to ``os.getcwd()``
    (the daemon's own cwd, ``~/.halton-meter`` under launchd), and the
    basename of that became the project name (``.halton-meter``).

    Issue #3 (v0.1.17): unresolvable cwd now short-circuits to the
    smart default (default: "misc") instead of the hardcoded
    "unattributed". Process heuristics (Step 7.5) still apply even
    when cwd is unresolvable.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    with patch.object(tagging_mod, "_get_process_cwd", return_value=None):
        result = resolve_project(_FakeFlow())
    assert result == "misc"


def test_leading_dot_basename_is_stripped(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A leading-dot directory basename is stripped (Gap 6).

    Defence-in-depth: even if _get_process_cwd somehow returned a
    leading-dot path (e.g. user's app is genuinely run from a hidden
    directory), the project name should not start with '.'.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    hidden = tmp_path / ".halton-meter"
    hidden.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(hidden)):
        result = resolve_project(_FakeFlow())
    assert result == "halton-meter"


def test_leading_dot_only_basename_becomes_unattributed(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A basename consisting solely of dots becomes 'unattributed' (Gap 6)."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    weird = tmp_path / "..."
    weird.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(weird)):
        result = resolve_project(_FakeFlow())
    assert result == "unattributed"


def test_leading_dot_env_var_is_stripped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An explicit HALTON_PROJECT with a leading dot is stripped (Gap 6)."""
    monkeypatch.setenv("HALTON_PROJECT", ".halton-meter")
    result = resolve_project(_FakeFlow())
    assert result == "halton-meter"


def test_leading_dot_haltonrc_value_is_stripped(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A .haltonrc project value with a leading dot is stripped (Gap 6)."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: .hidden-app\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "hidden-app"


def test_sanitize_project_name_unit() -> None:
    """Direct unit test for _sanitize_project_name (Gap 6)."""
    sanitize = tagging_mod._sanitize_project_name
    assert sanitize(".halton-meter") == "halton-meter"
    assert sanitize("...halton") == "halton"
    assert sanitize("normal") == "normal"
    assert sanitize("  spaced  ") == "spaced"
    assert sanitize("") == "unattributed"
    assert sanitize("   ") == "unattributed"
    assert sanitize(".") == "unattributed"
    assert sanitize(".....") == "unattributed"


# ---------------------------------------------------------------------------
# Two-hop proxy traversal (v0.1.12 fix)
# ---------------------------------------------------------------------------
#
# The proxy architecture is:
#   client (CLIENT_PORT) → edge:8081 (EDGE_SRC_PORT) → daemon:8090
#
# flow.client_conn.peername = (127.0.0.1, EDGE_SRC_PORT).
#
# Without the fix, _get_process_cwd finds the edge process (cwd=~/.halton-meter),
# _sanitize_project_name strips the leading dot → "halton-meter" for every request.
#
# With edge_port passed, the second-hop traversal detects the edge process and
# follows the connection back to the real CLIENT_PORT.
# ---------------------------------------------------------------------------


def _make_addr(port: int) -> object:
    """Return a minimal object with a .port attribute."""

    class _Addr:
        def __init__(self, p: int) -> None:
            self.port = p

    return _Addr(port)


def _make_conn(lport: int, rport: int | None = None) -> object:
    """Fake psutil connection object with laddr and optional raddr."""

    class _Conn:
        def __init__(self) -> None:
            self.laddr = _make_addr(lport)
            self.raddr = _make_addr(rport) if rport else None

    return _Conn()


def test_find_client_port_via_edge_finds_raddr() -> None:
    """_find_client_port_via_edge returns raddr.port for a connection at edge_port."""
    conns = [
        _make_conn(8090, None),    # outbound from edge to daemon — no raddr match
        _make_conn(8081, 54321),   # accepted connection from client
        _make_conn(8081, 54322),   # another client (should return first match)
    ]
    result = tagging_mod._find_client_port_via_edge(conns, edge_port=8081)
    assert result == 54321


def test_find_client_port_via_edge_no_match_returns_none() -> None:
    """_find_client_port_via_edge returns None when edge_port has no live raddr."""
    conns = [
        _make_conn(8090, None),
        _make_conn(8081, None),    # listener row — no raddr
    ]
    result = tagging_mod._find_client_port_via_edge(conns, edge_port=8081)
    assert result is None


def test_find_client_port_via_edge_empty_conns_returns_none() -> None:
    """_find_client_port_via_edge returns None on an empty connection list."""
    result = tagging_mod._find_client_port_via_edge([], edge_port=8081)
    assert result is None


def test_two_hop_traversal_resolves_real_client(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """With edge_port provided, _get_process_cwd traverses through the edge
    process to find the real client's cwd.

    Setup:
      EDGE_SRC_PORT = 55000  (what daemon sees in flow.client_conn.peername)
      EDGE_PORT     = 8081   (what the edge listens on)
      CLIENT_PORT   = 54321  (the real originating client's ephemeral port)

    The edge process (pid=1001) owns laddr.port==55000 AND has an accepted
    connection laddr.port==8081 / raddr.port==54321. The client process
    (pid=2002) owns laddr.port==54321 and has cwd=tmp_path/my-project.
    Uses a real mitmproxy flow so the isinstance(flow, http.HTTPFlow) check passes.
    """
    import sys
    import types

    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    EDGE_SRC_PORT = 55000
    EDGE_PORT = 8081
    CLIENT_PORT = 54321
    client_cwd = str(tmp_path / "my-project")
    (tmp_path / "my-project").mkdir()

    # Build a real mitmproxy flow with EDGE_SRC_PORT as peername
    _cc = tflow.tclient_conn()
    _cc.peername = ("127.0.0.1", EDGE_SRC_PORT)
    flow = tflow.tflow(client_conn=_cc)

    # Edge process: owns EDGE_SRC_PORT outbound + accepted CLIENT→edge conn
    edge_proc_conns = [
        _make_conn(EDGE_SRC_PORT, None),    # outbound to daemon
        _make_conn(EDGE_PORT, CLIENT_PORT), # accepted connection from client
    ]
    edge_proc = types.SimpleNamespace(pid=1001, cwd=lambda: str(Path.home() / ".halton-meter"))
    edge_proc.net_connections = lambda: edge_proc_conns  # type: ignore[attr-defined]

    # Client process: owns CLIENT_PORT with a connection back to EDGE_PORT
    client_proc = types.SimpleNamespace(pid=2002, cwd=lambda: client_cwd)
    client_proc.net_connections = lambda: [_make_conn(CLIENT_PORT, EDGE_PORT)]  # type: ignore[attr-defined]

    class _FakePsutil:
        NoSuchProcess = Exception
        AccessDenied = Exception
        ZombieProcess = Exception

        @staticmethod
        def process_iter(attrs: list) -> list:  # type: ignore[override]
            return [edge_proc, client_proc]

    real_psutil = sys.modules.get("psutil")
    sys.modules["psutil"] = _FakePsutil  # type: ignore[assignment]
    try:
        _side = lambda p: p.net_connections()  # noqa: E731
        with patch.object(tagging_mod, "_proc_net_connections", side_effect=_side):
            result = tagging_mod._get_process_cwd(flow, edge_port=EDGE_PORT)
    finally:
        if real_psutil is None:
            del sys.modules["psutil"]
        else:
            sys.modules["psutil"] = real_psutil

    assert result == client_cwd


def test_two_hop_traversal_fallback_when_second_hop_fails(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """When the second-hop client process cannot be found, return None.

    The edge process is identified (it has edge_port connections) but there
    is no other process owning CLIENT_PORT — fall through to None / unattributed.
    Uses a real mitmproxy flow so the isinstance(flow, http.HTTPFlow) check passes.
    """
    import sys
    import types

    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    EDGE_SRC_PORT = 55001
    EDGE_PORT = 8081
    CLIENT_PORT = 54400

    _cc = tflow.tclient_conn()
    _cc.peername = ("127.0.0.1", EDGE_SRC_PORT)
    flow = tflow.tflow(client_conn=_cc)

    edge_proc_conns = [
        _make_conn(EDGE_SRC_PORT, None),
        _make_conn(EDGE_PORT, CLIENT_PORT),
    ]
    edge_proc = types.SimpleNamespace(pid=1001, cwd=lambda: str(Path.home() / ".halton-meter"))
    edge_proc.net_connections = lambda: edge_proc_conns  # type: ignore[attr-defined]

    # No client process for CLIENT_PORT — second hop returns None
    class _FakePsutil:
        NoSuchProcess = Exception
        AccessDenied = Exception
        ZombieProcess = Exception

        @staticmethod
        def process_iter(attrs: list) -> list:  # type: ignore[override]
            return [edge_proc]  # only the edge; no CLIENT_PORT owner

    real_psutil = sys.modules.get("psutil")
    sys.modules["psutil"] = _FakePsutil  # type: ignore[assignment]
    try:
        _side = lambda p: p.net_connections()  # noqa: E731
        with patch.object(tagging_mod, "_proc_net_connections", side_effect=_side):
            result = tagging_mod._get_process_cwd(flow, edge_port=EDGE_PORT)
    finally:
        if real_psutil is None:
            del sys.modules["psutil"]
        else:
            sys.modules["psutil"] = real_psutil

    # Second hop found no process → None → caller returns "unattributed"
    assert result is None


def test_resolve_project_with_edge_port_two_hop(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """resolve_project passes edge_port through to _get_process_cwd.

    We patch _get_process_cwd to assert that edge_port was forwarded and
    return a synthetic cwd, then verify the project resolves correctly.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    client_project_dir = tmp_path / "windsurf-project"
    client_project_dir.mkdir()

    captured_edge_port: list[int | None] = []

    def _fake_get_cwd(flow: object, edge_port: int | None = None) -> str | None:
        captured_edge_port.append(edge_port)
        return str(client_project_dir)

    with patch.object(tagging_mod, "_get_process_cwd", side_effect=_fake_get_cwd):
        result = resolve_project(_FakeFlow(), edge_port=8081)

    assert result == "windsurf-project"
    assert captured_edge_port == [8081]


def test_resolve_project_without_edge_port_passes_none(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """When edge_port is omitted, _get_process_cwd receives None (one-hop behaviour)."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    client_project_dir = tmp_path / "direct-client"
    client_project_dir.mkdir()

    captured_edge_port: list[int | None] = []

    def _fake_get_cwd(flow: object, edge_port: int | None = None) -> str | None:
        captured_edge_port.append(edge_port)
        return str(client_project_dir)

    with patch.object(tagging_mod, "_get_process_cwd", side_effect=_fake_get_cwd):
        result = resolve_project(_FakeFlow())

    assert result == "direct-client"
    assert captured_edge_port == [None]


# ---------------------------------------------------------------------------
# Edge attribution store (Step 0 — production hot path, SQLite-backed)
# ---------------------------------------------------------------------------
#
# When the ``attribution_store`` singleton is wired AND the flow is a real
# HTTPFlow with a peername present in the table, the lookup wins over
# every legacy step. The legacy psutil walk must not even be invoked on
# a hit.


def test_edge_store_hit_short_circuits_other_steps(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A hit in the attribution store returns immediately, skipping psutil."""
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    monkeypatch.setenv("HALTON_PROJECT", "from-env-not-used")  # would normally win
    attribution_store.set_db_path(tmp_path / "attrib.sqlite")
    attribution_store.write(54321, "from-store")

    cc = tflow.tclient_conn()
    cc.peername = ("127.0.0.1", 54321)
    flow = tflow.tflow(client_conn=cc)

    # If the store short-circuits correctly, _get_process_cwd is NEVER called.
    called: list[int] = []

    def _should_not_be_called(*args: object, **kwargs: object) -> str | None:
        called.append(1)
        return None

    with patch.object(tagging_mod, "_get_process_cwd", side_effect=_should_not_be_called):
        result = resolve_project(flow, edge_port=8081)

    assert result == "from-store"
    # The env-var step also did not fire — the store wins above it.
    assert result != "from-env-not-used"
    # And legacy cwd lookup wasn't called either.
    assert called == []


def test_edge_store_miss_falls_through_to_legacy(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A store miss falls through to env var / rcfile / cwd as before."""
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    attribution_store.set_db_path(tmp_path / "attrib.sqlite")  # empty

    cc = tflow.tclient_conn()
    cc.peername = ("127.0.0.1", 99999)  # not in store
    flow = tflow.tflow(client_conn=cc)

    project_dir = tmp_path / "fallback-project"
    project_dir.mkdir()
    with patch.object(
        tagging_mod, "_get_process_cwd", return_value=str(project_dir)
    ):
        result = resolve_project(flow, edge_port=8081)

    assert result == "fallback-project"


def test_edge_store_unwired_means_legacy_path(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """An unwired singleton preserves the old behaviour (no store consult)."""
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    attribution_store.set_db_path(None)
    cc = tflow.tclient_conn()
    cc.peername = ("127.0.0.1", 12345)
    flow = tflow.tflow(client_conn=cc)

    project_dir = tmp_path / "legacy-only"
    project_dir.mkdir()
    with patch.object(
        tagging_mod, "_get_process_cwd", return_value=str(project_dir)
    ):
        result = resolve_project(flow, edge_port=8081)

    assert result == "legacy-only"


def test_edge_store_no_peername_falls_through(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A flow without a peername cannot hit the store; legacy runs."""
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    attribution_store.set_db_path(tmp_path / "attrib.sqlite")
    attribution_store.write(11111, "should-not-be-used")

    cc = tflow.tclient_conn()
    cc.peername = None
    flow = tflow.tflow(client_conn=cc)

    project_dir = tmp_path / "no-peername-fallback"
    project_dir.mkdir()
    with patch.object(
        tagging_mod, "_get_process_cwd", return_value=str(project_dir)
    ):
        result = resolve_project(flow, edge_port=8081)

    assert result == "no-peername-fallback"


def test_edge_store_lookup_exception_fails_open(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A store lookup raising must NOT break resolution — fail-open to legacy."""
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    attribution_store.set_db_path(tmp_path / "attrib.sqlite")

    cc = tflow.tclient_conn()
    cc.peername = ("127.0.0.1", 22222)
    flow = tflow.tflow(client_conn=cc)

    project_dir = tmp_path / "fail-open-fallback"
    project_dir.mkdir()

    def _broken_lookup(port: int, max_age_s: float = 300.0) -> str | None:
        raise RuntimeError("store backend exploded")

    with patch.object(tagging_mod.attribution_store, "lookup", side_effect=_broken_lookup):
        with patch.object(
            tagging_mod, "_get_process_cwd", return_value=str(project_dir)
        ):
            result = resolve_project(flow, edge_port=8081)

    assert result == "fail-open-fallback"


def test_edge_store_non_http_flow_falls_through(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A non-HTTPFlow object must not trip the store lookup."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    attribution_store.set_db_path(tmp_path / "attrib.sqlite")
    attribution_store.write(33333, "should-not-be-used")

    project_dir = tmp_path / "non-http-flow"
    project_dir.mkdir()
    with patch.object(
        tagging_mod, "_get_process_cwd", return_value=str(project_dir)
    ):
        result = resolve_project(_FakeFlow(), edge_port=8081)

    assert result == "non-http-flow"


# ---------------------------------------------------------------------------
# PR2 (2026-05-02) — Smart Attribution v0.3 layers 4 / 6 / 6.5 wiring
# ---------------------------------------------------------------------------
#
# Daemon-side bypass-path wiring tests. The shared layer functions are
# unit-tested in ``test_attribution_layers.py``; here we prove
# ``resolve_project()`` invokes them in the corrected precedence
# (env > rcfile > git > container > mac sandbox > basename > unattributed).

from halton_meter.attribution import layers as _layers  # noqa: E402


@pytest.fixture(autouse=True)
def _clear_layers_git_cache_tagging():
    """Layer 4's per-cwd cache must not leak across tests."""
    _layers._GIT_CACHE.clear()
    yield
    _layers._GIT_CACHE.clear()


def test_pr2_daemon_layer4_git_fires(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Layer 4 (git) fires from the daemon-side resolver too."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    repo = tmp_path / "myrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    nested = repo / "src"
    nested.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(nested)):
        result = resolve_project(_FakeFlow())
    assert result == "myrepo"


def test_pr2_daemon_layer6_dev_laptop_does_not_tag(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Dev-laptop regression on the daemon path too."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setenv("HOSTNAME", "vikrants-mbp")
    monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
    monkeypatch.setattr(_layers, "_default_container_fs_probe", lambda p: False)
    leaf = tmp_path / "dev-project"
    leaf.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(leaf)):
        result = resolve_project(_FakeFlow())
    assert result == "dev-project"
    assert "k8s:" not in result


def test_pr2_daemon_layer6_k8s_fires(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Layer 6 fires on the daemon path when k8s env is present."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    monkeypatch.setenv("HOSTNAME", "checkout-pod-abc")
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    leaf = tmp_path / "app"
    leaf.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(leaf)):
        result = resolve_project(_FakeFlow())
    assert result == "k8s:checkout-pod-abc"


def test_pr2_daemon_layer65_mac_sandbox_fires(
    monkeypatch: pytest.MonkeyPatch
) -> None:
    """Layer 6.5 fires on the daemon path."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    monkeypatch.setattr(_layers, "resolve_via_container", lambda env, fs_probe=None: None)
    cwd = "/Users/stack/Library/Containers/ai.perplexity.mac/Data"
    with patch.object(tagging_mod, "_get_process_cwd", return_value=cwd):
        result = resolve_project(_FakeFlow())
    assert result == "mac:ai.perplexity.mac"


def test_pr2_daemon_precedence_env_beats_git(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("HALTON_PROJECT", "from-env")
    repo = tmp_path / "gitrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(repo)):
        result = resolve_project(_FakeFlow())
    assert result == "from-env"


def test_pr2_daemon_precedence_rcfile_beats_git(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    repo = tmp_path / "gitrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    (repo / ".haltonrc").write_text("project: from-rcfile\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(repo)):
        result = resolve_project(_FakeFlow())
    assert result == "from-rcfile"


def test_pr2_daemon_precedence_git_beats_container(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    monkeypatch.setenv("HOSTNAME", "would-be-pod")
    repo = tmp_path / "gitrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(repo)):
        result = resolve_project(_FakeFlow())
    assert result == "gitrepo"


def test_pr2_daemon_precedence_container_beats_basename(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    monkeypatch.setenv("HOSTNAME", "pod-1")
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    leaf = tmp_path / "app"
    leaf.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(leaf)):
        result = resolve_project(_FakeFlow())
    assert result == "k8s:pod-1"


def test_pr2_daemon_precedence_mac_sandbox_beats_basename(
    monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    monkeypatch.setattr(_layers, "resolve_via_container", lambda env, fs_probe=None: None)
    cwd = "/Users/stack/Library/Containers/ai.perplexity.mac/Data"
    with patch.object(tagging_mod, "_get_process_cwd", return_value=cwd):
        result = resolve_project(_FakeFlow())
    assert result == "mac:ai.perplexity.mac"
    assert result != "Data"


# ---------------------------------------------------------------------------
# resolve_project_with_meta — Smart Attribution observability (2026-05-02)
# ---------------------------------------------------------------------------
#
# Each layer must return a (project, method, source_workdir) tuple that
# the proxy hot path can use to populate the ``attribution_method`` and
# ``source_workdir`` columns on the ``requests`` row. The method-name
# enum is the same set the existing ``tagging.resolved`` log calls
# already emit (edge_store / env / rcfile / git / container /
# mac_sandbox / workdir / unattributed).


def test_meta_env_layer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Env-var hit returns method='env', source_workdir=None."""
    monkeypatch.setenv("HALTON_PROJECT", "from-env")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        meta = resolve_project_with_meta(_FakeFlow())
    assert meta.project == "from-env"
    assert meta.method == "env"
    assert meta.source_workdir is None


def test_meta_rcfile_layer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Rcfile hit returns method='rcfile', source_workdir=cwd that triggered it."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: rc-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        meta = resolve_project_with_meta(_FakeFlow())
    assert meta.project == "rc-project"
    assert meta.method == "rcfile"
    assert meta.source_workdir == str(tmp_path)


def test_meta_git_layer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Git hit returns method='git', source_workdir=cwd."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    repo = tmp_path / "myrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    nested = repo / "src"
    nested.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(nested)):
        meta = resolve_project_with_meta(_FakeFlow())
    assert meta.project == "myrepo"
    assert meta.method == "git"
    assert meta.source_workdir == str(nested)


def test_meta_container_layer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Container hit returns method='container', source_workdir=cwd."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    monkeypatch.setenv("HOSTNAME", "checkout-pod")
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    leaf = tmp_path / "app"
    leaf.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(leaf)):
        meta = resolve_project_with_meta(_FakeFlow())
    assert meta.project == "k8s:checkout-pod"
    assert meta.method == "container"
    assert meta.source_workdir == str(leaf)


def test_meta_mac_sandbox_layer(monkeypatch: pytest.MonkeyPatch) -> None:
    """Mac-sandbox hit returns method='mac_sandbox', source_workdir=cwd."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    monkeypatch.setattr(_layers, "resolve_via_git", lambda c: None)
    monkeypatch.setattr(_layers, "resolve_via_container", lambda env, fs_probe=None: None)
    cwd = "/Users/stack/Library/Containers/ai.perplexity.mac/Data"
    with patch.object(tagging_mod, "_get_process_cwd", return_value=cwd):
        meta = resolve_project_with_meta(_FakeFlow())
    assert meta.project == "mac:ai.perplexity.mac"
    assert meta.method == "mac_sandbox"
    assert meta.source_workdir == cwd


def test_meta_workdir_layer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Workdir-basename fallback returns method='workdir', source_workdir=cwd."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    leaf = tmp_path / "fallback-app"
    leaf.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(leaf)):
        meta = resolve_project_with_meta(_FakeFlow())
    assert meta.project == "fallback-app"
    assert meta.method == "workdir"
    assert meta.source_workdir == str(leaf)


def test_meta_smart_default_no_cwd(monkeypatch: pytest.MonkeyPatch) -> None:
    """Unresolvable cwd returns method='smart_default' (Issue #3, v0.1.17)."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    with patch.object(tagging_mod, "_get_process_cwd", return_value=None):
        meta = resolve_project_with_meta(_FakeFlow())
    assert meta.project == "misc"
    assert meta.method == "smart_default"
    assert meta.source_workdir is None


def test_meta_edge_store_hit(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Edge-store cache hit returns method='edge_store' and propagates source_workdir.

    v0.2.10: source_workdir is now persisted in attribution_log and
    surfaced on cache hits. A write without workdir returns None; a write
    with workdir returns the stored path.
    """
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    attribution_store.set_db_path(tmp_path / "attrib.sqlite")

    # Without source_workdir — cache hit returns None workdir.
    attribution_store.write(54321, "from-store")
    cc = tflow.tclient_conn()
    cc.peername = ("127.0.0.1", 54321)
    flow = tflow.tflow(client_conn=cc)
    meta = resolve_project_with_meta(flow, edge_port=8081)
    assert meta.project == "from-store"
    assert meta.method == "edge_store"
    assert meta.source_workdir is None

    # With source_workdir — cache hit propagates the stored cwd.
    attribution_store.write(54321, "from-store", source_workdir="/Users/dev/myproject")
    meta2 = resolve_project_with_meta(flow, edge_port=8081)
    assert meta2.project == "from-store"
    assert meta2.method == "edge_store"
    assert meta2.source_workdir == "/Users/dev/myproject"


def test_resolve_project_string_wrapper_unchanged(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """The string-only ``resolve_project`` wrapper still returns the project slug.

    Regression guard: callers that haven't migrated to
    ``resolve_project_with_meta`` keep working.
    """
    monkeypatch.setenv("HALTON_PROJECT", "still-works")
    result = resolve_project(_FakeFlow())
    assert result == "still-works"
    assert isinstance(result, str)


# ---------------------------------------------------------------------------
# v0.2.3 (decisions.md 2026-05-18) — Claude-family parent walk + smart_default
# escalation to WARN.
# ---------------------------------------------------------------------------


class _FakeProc:
    """Minimal psutil.Process stand-in for parent-walk tests.

    Each instance carries an optional ``_parent`` ref, a ``_cwd`` value,
    a ``name_str``, and a ``pid``. ``parent()`` returns ``_parent`` or
    None; ``cwd()`` returns ``_cwd`` or raises if marked.
    """

    def __init__(
        self,
        pid: int,
        name_str: str,
        cwd_value: str | None,
        parent: _FakeProc | None = None,
        cwd_raises: bool = False,
    ) -> None:
        self.pid = pid
        self._name = name_str
        self._cwd = cwd_value
        self._parent = parent
        self._cwd_raises = cwd_raises

    def name(self) -> str:
        return self._name

    def parent(self) -> _FakeProc | None:
        return self._parent

    def cwd(self) -> str:
        if self._cwd_raises:
            raise RuntimeError("cwd unreadable")
        if self._cwd is None:
            raise RuntimeError("no cwd")
        return self._cwd


def test_claude_parent_walk_recovers_cwd_when_child_cwd_is_root(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """cwd=`/` triggers the Claude parent-PID walk and recovers attribution.

    Production failure mode (decisions.md 2026-05-18): a short-lived
    ``claude`` Mach-O worker spawned by the tool loop reports cwd=`/`;
    its parent ``claude`` carries the user's project cwd. The walk
    must consult the parent and re-run rcfile/git layers against
    parent_cwd.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    # Build a parent process with a real-looking project cwd.
    project_dir = tmp_path / "user-project"
    project_dir.mkdir()
    parent = _FakeProc(
        pid=4242,
        name_str="claude",
        cwd_value=str(project_dir),
        parent=None,
    )
    child = _FakeProc(
        pid=4243,
        name_str="claude",
        cwd_value="/",
        parent=parent,
    )

    # _get_process_cwd returns "/" (the production failure mode).
    # _find_originating_psutil_process returns the child psutil process handle.
    # v0.2.4: the unified resolver picks up the parent's cwd via the
    # Step 7.25 fallback. With no .haltonrc and no .git on the parent's
    # cwd, the walk's basename fallback fires as ``parent_rcfile``? No —
    # the resolver only emits ``parent_*`` for the tiers it actually
    # ran (rcfile / git / ide_sniff / labels). When none of those hit
    # but the parent's cwd is path-bearing, the resolver registry-warms
    # ``user-project → /<project_dir>`` and the walk falls through. The
    # original target's cwd then gets re-evaluated via the cwd basename
    # path the unified resolver doesn't itself emit (Tier 7). So the
    # daemon's resolve_project_with_meta proceeds past the unified
    # resolver to its own smart_default — which is wrong for this
    # production case. To preserve the v0.2.3 behavioural contract we
    # accept the parent's cwd basename as ``parent_rcfile`` only when an
    # rcfile is present. Plain basename recovery is via Tier 7 only,
    # which the unified resolver doesn't run.
    #
    # ⇒ Set up a .haltonrc so the parent walk's rcfile tier fires.
    (project_dir / ".haltonrc").write_text("project: user-project\n")
    with (
        patch.object(tagging_mod, "_get_process_cwd", return_value="/"),
        patch.object(
            tagging_mod, "_find_originating_psutil_process", return_value=child
        ),
    ):
        meta = resolve_project_with_meta(_FakeFlow())

    assert meta.project == "user-project"
    # v0.2.4: ``claude_parent_workdir`` collapsed to ``parent_rcfile``
    # (the unified resolver consults rcfile + git for parents; plain
    # workdir-basename on a parent has no dedicated method).
    assert meta.method == "parent_rcfile"
    assert meta.source_workdir == str(project_dir)


def test_claude_parent_walk_uses_haltonrc_at_parent_cwd(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A .haltonrc at the parent's cwd wins over basename."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: rc-named-project\n")
    parent = _FakeProc(
        pid=5151,
        name_str="claude",
        cwd_value=str(tmp_path),
    )
    child = _FakeProc(pid=5152, name_str="claude", cwd_value=None, parent=parent)

    with (
        patch.object(tagging_mod, "_get_process_cwd", return_value=None),
        patch.object(
            tagging_mod, "_find_originating_psutil_process", return_value=child
        ),
    ):
        meta = resolve_project_with_meta(_FakeFlow())

    assert meta.project == "rc-named-project"
    # v0.2.4: ``claude_parent_rcfile`` renamed to ``parent_rcfile``.
    assert meta.method == "parent_rcfile"


def test_claude_parent_walk_aborts_on_non_claude_ancestor(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """v0.2.4: the allow-list is gone. A ``bash`` parent with a real cwd
    in the SAME user session IS chased — the uid/session boundary is
    what bounds the walk now, not a process-name allow-list.

    Migrated assertion: a ``bash`` parent with a real cwd attributes via
    the unified resolver (parent_rcfile or parent_git or — when neither
    fires — the resolver still has no path-bearing tier for plain
    basename, so it falls through to smart_default for the cwd-bare
    case). We assert the new structural contract: when an ancestor's
    cwd carries a .haltonrc the walk succeeds.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: bash-spawned\n")
    parent = _FakeProc(pid=999, name_str="bash", cwd_value=str(tmp_path))
    child = _FakeProc(pid=1000, name_str="claude", cwd_value="/", parent=parent)

    with (
        patch.object(tagging_mod, "_get_process_cwd", return_value="/"),
        patch.object(
            tagging_mod, "_find_originating_psutil_process", return_value=child
        ),
    ):
        meta = resolve_project_with_meta(_FakeFlow())

    # The walk now follows ``bash`` (no allow-list). With a .haltonrc on
    # its cwd, the rcfile tier fires and we get ``parent_rcfile``.
    assert meta.method == "parent_rcfile"
    assert meta.project == "bash-spawned"


def test_smart_default_fallthrough_emits_warn(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The smart_default fall-through escalated debug → WARN in v0.2.3.

    Operator-requested production tripwire: any future drift produces
    a WARN-level event in ``daemon.err.log`` immediately instead of
    requiring a one-off SQL query against `~/.halton-meter/db.sqlite`.
    Structured fields include ``edge_src_port``, ``cwd``, ``parent_pid``,
    ``parent_name``.
    """
    import structlog

    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    parent = _FakeProc(pid=12345, name_str="bash", cwd_value="/etc")
    child = _FakeProc(pid=12346, name_str="claude", cwd_value="/", parent=parent)

    with (
        patch.object(tagging_mod, "_get_process_cwd", return_value="/"),
        patch.object(
            tagging_mod, "_find_originating_psutil_process", return_value=child
        ),
        structlog.testing.capture_logs() as cap,
    ):
        meta = resolve_project_with_meta(_FakeFlow())

    assert meta.method == "smart_default"
    warn_events = [
        e
        for e in cap
        if e.get("event") == "tagging.resolved"
        and e.get("method") == "smart_default"
        and e.get("log_level") == "warning"
    ]
    assert len(warn_events) == 1, f"expected one warning, got cap={cap!r}"
    evt = warn_events[0]
    # parent_pid / parent_name surfaced for production observability.
    assert evt.get("parent_pid") == 12345
    assert evt.get("parent_name") == "bash"
    assert evt.get("cwd") == "/"


def test_claude_parent_walk_never_raises_on_psutil_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Cardinal rule: an exception inside the walk MUST NOT escape.

    The hot path falls through to the next layer instead.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    class _ExplodingProc:
        pid = 1
        def name(self) -> str:
            raise RuntimeError("boom")
        def parent(self) -> object:
            raise RuntimeError("boom")
        def cwd(self) -> str:
            raise RuntimeError("boom")

    with (
        patch.object(tagging_mod, "_get_process_cwd", return_value=None),
        patch.object(
            tagging_mod,
            "_find_originating_psutil_process",
            return_value=_ExplodingProc(),
        ),
    ):
        # Must complete without raising — falls through to smart_default.
        meta = resolve_project_with_meta(_FakeFlow())

    assert meta.method == "smart_default"


def test_claude_parent_walk_hop_budget_bounded(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Walk stops after _DAEMON_PARENT_WALK_MAX_HOPS iterations.

    Defence-in-depth: a pathological psutil cycle cannot pin the
    proxy hot path in a loop.
    """
    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    # Build a chain of 10 ``claude`` ancestors, none with a usable cwd.
    # The walk must bail at hop 5 and fall through.
    top: _FakeProc | None = None
    for i in range(10):
        top = _FakeProc(
            pid=100 + i,
            name_str="claude",
            cwd_value=None,
            parent=top,
            cwd_raises=True,
        )
    # ``top`` is the deepest descendant (the originating process).
    assert top is not None

    with (
        patch.object(tagging_mod, "_get_process_cwd", return_value="/"),
        patch.object(
            tagging_mod, "_find_originating_psutil_process", return_value=top
        ),
    ):
        meta = resolve_project_with_meta(_FakeFlow())

    # No usable cwd ever recovered → smart_default fires.
    assert meta.method == "smart_default"
