"""
Tests for the body capture size gate in proxy.py (v0.2.10).

The gate skips capture_body() entirely when the request/response body
exceeds _BODY_CAPTURE_SIZE_GATE_BYTES (4 MiB), preventing a second
memory spike on multi-modal payloads that mitmproxy already buffered.

Test strategy: we exercise the gate logic by using mitmproxy's tflow
test utilities to build flows and running HaltonAddon.request / response.
We patch capture_body and the storage layer to keep tests fast and
side-effect-free.
"""

from __future__ import annotations

import asyncio
import inspect
from unittest.mock import MagicMock, patch

import pytest
import structlog.testing

pytest.importorskip("mitmproxy", reason="mitmproxy not installed")

from mitmproxy.test import tflow, tutils

from halton_meter.proxy import _BODY_CAPTURE_SIZE_GATE_BYTES, HaltonAddon

# ---------------------------------------------------------------------------
# Constant sanity check
# ---------------------------------------------------------------------------


def test_gate_constant_is_4_mib() -> None:
    """The gate is set to exactly 4 MiB."""
    assert _BODY_CAPTURE_SIZE_GATE_BYTES == 4 * 1024 * 1024


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_addon() -> HaltonAddon:
    """Build a HaltonAddon with mocked storage and a wired BodyCaptureCache."""
    from halton_meter.body_capture import BodyCaptureCache
    from halton_meter.storage import StorageManager

    storage = MagicMock(spec=StorageManager)
    # write_record must return an awaitable so the async response hook works.
    storage.write_record = MagicMock(return_value=MagicMock())

    body_cache = MagicMock(spec=BodyCaptureCache)
    body_cache.master_enabled = True
    body_cache.is_enabled_for = MagicMock(return_value=True)

    return HaltonAddon(storage=storage, body_capture_cache=body_cache)


def _make_request_flow(body: bytes) -> object:
    """Build a minimal flow with a given request body."""
    flow = tflow.tflow()
    flow.request.host = "api.anthropic.com"
    flow.request.path = "/v1/messages"
    flow.request.content = body
    return flow


# ---------------------------------------------------------------------------
# Request body size gate
# ---------------------------------------------------------------------------


def test_request_body_under_gate_calls_capture_body() -> None:
    """A request body under 4 MiB passes through to capture_body()."""
    addon = _make_addon()
    small_body = b"x" * (1 * 1024 * 1024)  # 1 MiB
    flow = _make_request_flow(small_body)

    capture_calls: list[str] = []

    def _spy_capture(msg: object, max_bytes: int, side: str) -> object:
        capture_calls.append(side)
        return MagicMock()

    with (
        patch("halton_meter.proxy.find_adapter") as mock_find,
        patch("halton_meter.proxy.capture_body", side_effect=_spy_capture),
        patch("halton_meter.proxy.resolve_project_with_meta") as mock_tag,
    ):
        mock_find.return_value = MagicMock(
            name="anthropic",
            parse_request=MagicMock(return_value=MagicMock(stream=False)),
        )
        mock_tag.return_value = MagicMock(project="test-project")

        asyncio.run(addon.request(flow))

    assert "request" in capture_calls, (
        f"Expected capture_body(side='request') for a {len(small_body)}-byte body. "
        f"calls={capture_calls}"
    )


def test_request_body_over_gate_skips_capture_body() -> None:
    """A request body over 4 MiB leaves captured_request_body as None."""
    addon = _make_addon()
    large_body = b"x" * (_BODY_CAPTURE_SIZE_GATE_BYTES + 1)
    flow = _make_request_flow(large_body)

    capture_calls: list[str] = []

    def _spy_capture(msg: object, max_bytes: int, side: str) -> object:
        capture_calls.append(side)
        return MagicMock()

    with (
        patch("halton_meter.proxy.find_adapter") as mock_find,
        patch("halton_meter.proxy.capture_body", side_effect=_spy_capture),
        patch("halton_meter.proxy.resolve_project_with_meta") as mock_tag,
    ):
        mock_find.return_value = MagicMock(
            name="anthropic",
            parse_request=MagicMock(return_value=MagicMock(stream=False)),
        )
        mock_tag.return_value = MagicMock(project="test-project")

        asyncio.run(addon.request(flow))

    assert "request" not in capture_calls, (
        f"capture_body should NOT be called for a {len(large_body)}-byte body. "
        f"calls={capture_calls}"
    )
    # The pending entry exists — the request was still recorded, just no body.
    assert flow.id in addon._pending
    assert addon._pending[flow.id].request_body is None


def test_request_body_over_gate_logs_body_too_large() -> None:
    """Skipping a large request body emits a structured log with correct fields."""
    addon = _make_addon()
    large_body = b"y" * (_BODY_CAPTURE_SIZE_GATE_BYTES + 500)
    flow = _make_request_flow(large_body)
    flow.id = "gate-log-test-req"

    with (
        patch("halton_meter.proxy.find_adapter") as mock_find,
        patch("halton_meter.proxy.capture_body", return_value=MagicMock()),
        patch("halton_meter.proxy.resolve_project_with_meta") as mock_tag,
        structlog.testing.capture_logs() as cap,
    ):
        mock_find.return_value = MagicMock(
            name="anthropic",
            parse_request=MagicMock(return_value=MagicMock(stream=False)),
        )
        mock_tag.return_value = MagicMock(project="test-project")

        asyncio.run(addon.request(flow))

    skip_events = [
        e for e in cap
        if e.get("event") == "addon.body_capture.skip"
        and e.get("reason") == "body_too_large"
    ]
    assert skip_events, (
        f"Expected 'addon.body_capture.skip' with reason='body_too_large'. "
        f"Got: {[e.get('event') + '/' + str(e.get('reason')) for e in cap]}"
    )
    ev = skip_events[0]
    assert ev["size_bytes"] == len(large_body)
    assert ev["gate_bytes"] == _BODY_CAPTURE_SIZE_GATE_BYTES


# ---------------------------------------------------------------------------
# Response body size gate — exercised via proxy.py constant + logic check
# ---------------------------------------------------------------------------


def test_response_gate_constant_consistent_with_request_gate() -> None:
    """Request and response gates use the same constant (single source of truth)."""
    # This test confirms the constant is referenced symmetrically; it catches
    # drift if someone hardens one side but not the other.
    import halton_meter.proxy as proxy_mod

    src = inspect.getsource(proxy_mod.HaltonAddon.response)
    assert "_BODY_CAPTURE_SIZE_GATE_BYTES" in src, (
        "response() does not reference _BODY_CAPTURE_SIZE_GATE_BYTES — "
        "the response-side size gate may be missing."
    )


def test_response_body_over_gate_skips_capture_body() -> None:
    """A response body over 4 MiB skips capture_body for the response side.

    We exercise this via a full request+response round-trip on a flow,
    seeding _pending with a non-None request_body so the response hook
    doesn't short-circuit on 'request_side_skipped'.
    """
    from halton_meter.adapters.base import RequestMetadata
    from halton_meter.body_capture import CapturedBody, PendingCapture

    addon = _make_addon()

    flow = tflow.tflow(resp=tutils.tresp())
    flow.request.host = "api.anthropic.com"
    flow.request.path = "/v1/messages"
    flow.request.content = b"small request"
    # Build a large response body.
    large_response = b"r" * (_BODY_CAPTURE_SIZE_GATE_BYTES + 1)
    flow.response.content = large_response

    # Pre-seed _pending so the response hook doesn't no-op.
    fake_meta = MagicMock(spec=RequestMetadata)
    fake_pending = PendingCapture(
        meta=fake_meta,
        requested_at=0.0,
        request_body=MagicMock(spec=CapturedBody),  # non-None
    )
    addon._pending[flow.id] = fake_pending

    capture_calls: list[str] = []

    def _spy_capture(msg: object, max_bytes: int, side: str) -> object:
        capture_calls.append(side)
        return MagicMock()

    with (
        patch("halton_meter.proxy.find_adapter") as mock_find,
        patch("halton_meter.proxy.capture_body", side_effect=_spy_capture),
        patch("halton_meter.proxy.resolve_project_with_meta") as mock_tag,
        patch("halton_meter.proxy.HaltonAddon._write_record_then_body", return_value=None),
        patch("asyncio.wait_for") as mock_wait_for,
    ):
        mock_find.return_value = MagicMock(name="anthropic")
        mock_tag.return_value = MagicMock(project="test-project")
        mock_wait_for.return_value = MagicMock(
            input_tokens=100, output_tokens=50, thinking_tokens=0,
            cached_tokens=0, tokens_complete=True, model="claude-opus-4-5",
            stream=False,
        )

        asyncio.run(addon.response(flow))

    assert "response" not in capture_calls, (
        f"capture_body should NOT be called for a large response body. "
        f"calls={capture_calls}"
    )


def test_response_body_under_gate_calls_capture_body() -> None:
    """A response body under 4 MiB calls capture_body for the response side."""
    from halton_meter.adapters.base import RequestMetadata
    from halton_meter.body_capture import CapturedBody, PendingCapture

    addon = _make_addon()

    flow = tflow.tflow(resp=tutils.tresp())
    flow.request.host = "api.anthropic.com"
    flow.request.path = "/v1/messages"
    flow.request.content = b"small request"
    small_response = b"s" * (512 * 1024)  # 512 KiB
    flow.response.content = small_response

    fake_meta = MagicMock(spec=RequestMetadata)
    fake_pending = PendingCapture(
        meta=fake_meta,
        requested_at=0.0,
        request_body=MagicMock(spec=CapturedBody),
    )
    addon._pending[flow.id] = fake_pending

    capture_calls: list[str] = []

    def _spy_capture(msg: object, max_bytes: int, side: str) -> object:
        capture_calls.append(side)
        return MagicMock()

    with (
        patch("halton_meter.proxy.find_adapter") as mock_find,
        patch("halton_meter.proxy.capture_body", side_effect=_spy_capture),
        patch("halton_meter.proxy.resolve_project_with_meta") as mock_tag,
        patch("halton_meter.proxy.HaltonAddon._write_record_then_body", return_value=None),
        patch("asyncio.wait_for") as mock_wait_for,
    ):
        mock_find.return_value = MagicMock(name="anthropic")
        mock_tag.return_value = MagicMock(project="test-project")
        mock_wait_for.return_value = MagicMock(
            input_tokens=100, output_tokens=50, thinking_tokens=0,
            cached_tokens=0, tokens_complete=True, model="claude-opus-4-5",
            stream=False,
        )

        asyncio.run(addon.response(flow))

    assert "response" in capture_calls, (
        f"Expected capture_body(side='response') for a small response. "
        f"calls={capture_calls}"
    )


def test_response_body_over_gate_logs_body_too_large() -> None:
    """Skipping a large response body emits a structured log with correct fields."""
    from halton_meter.adapters.base import RequestMetadata
    from halton_meter.body_capture import CapturedBody, PendingCapture

    addon = _make_addon()

    flow = tflow.tflow(resp=tutils.tresp())
    flow.request.host = "api.anthropic.com"
    flow.request.path = "/v1/messages"
    flow.request.content = b"req"
    large_response = b"L" * (_BODY_CAPTURE_SIZE_GATE_BYTES + 200)
    flow.response.content = large_response
    flow.id = "gate-log-test-resp"

    fake_meta = MagicMock(spec=RequestMetadata)
    fake_pending = PendingCapture(
        meta=fake_meta,
        requested_at=0.0,
        request_body=MagicMock(spec=CapturedBody),
    )
    addon._pending[flow.id] = fake_pending

    with (
        patch("halton_meter.proxy.find_adapter") as mock_find,
        patch("halton_meter.proxy.capture_body", return_value=MagicMock()),
        patch("halton_meter.proxy.resolve_project_with_meta") as mock_tag,
        patch("halton_meter.proxy.HaltonAddon._write_record_then_body", return_value=None),
        patch("asyncio.wait_for") as mock_wait_for,
        structlog.testing.capture_logs() as cap,
    ):
        mock_find.return_value = MagicMock(name="anthropic")
        mock_tag.return_value = MagicMock(project="test-project")
        mock_wait_for.return_value = MagicMock(
            input_tokens=100, output_tokens=50, thinking_tokens=0,
            cached_tokens=0, tokens_complete=True, model="claude-opus-4-5",
            stream=False,
        )

        asyncio.run(addon.response(flow))

    skip_events = [
        e for e in cap
        if e.get("event") == "addon.body_capture.skip"
        and e.get("reason") == "body_too_large"
    ]
    assert skip_events, (
        f"Expected 'addon.body_capture.skip' with reason='body_too_large' in response path. "
        f"Events: {[e.get('event') for e in cap]}"
    )
    ev = skip_events[0]
    assert ev["size_bytes"] == len(large_response)
    assert ev["gate_bytes"] == _BODY_CAPTURE_SIZE_GATE_BYTES
