"""v0.1.22.14 — Halton Meter ``H`` mark mastheads + cost report column polish.

Three coupled visual polish items shipped as v0.1.22.14:

  1. Tier-A 5-line block-H mark on the dwell surfaces (``status``,
     ``report``) — left of a vertically-centred wordmark/version stack.
  2. Tier-B inline ``[H]`` mark on the quick-command surfaces
     (``start``, ``stop``, ``init``, ``doctor``) — replaces the legacy
     ``●`` glyph in the masthead.
  3. Cost-report ``avg / p95`` combined column split into two
     right-justified columns so each project row stays single-line at
     standard widths.

The verdict pill on ``status`` (``●`` / ``✗`` / ``◐`` / ``○``) stays a
distinct state indicator — the H is brand identity, never state.

Captures use ``StringIO`` + ``Console(force_terminal=False)`` — same
plain-text pattern v0.1.22.11/.13 use.
"""

from __future__ import annotations

from io import StringIO

from rich.console import Console

from halton_meter import __version__
from halton_meter.branding import (
    BRAND_MARK_BLOCK_LINES,
    PILL_ACTIVE,
    PILL_BROKEN,
    PILL_DEGRADED,
    PILL_PAUSED,
    brand_command_lead,
    brand_mark_block,
    brand_mark_inline,
)


def _capture(*renderables: object, width: int = 100) -> str:
    console = Console(file=StringIO(), force_terminal=False, width=width)
    for r in renderables:
        console.print(r)
    return console.file.getvalue()  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# brand_mark_block / brand_mark_inline primitives
# ---------------------------------------------------------------------------


def test_brand_mark_block_renders_five_lines_of_block_chars() -> None:
    """The block-H mark is exactly five rows, all built from ``█`` and spaces."""
    out = _capture(brand_mark_block())
    lines = [line for line in out.splitlines() if line.strip()]
    assert len(lines) == 5
    for src in BRAND_MARK_BLOCK_LINES:
        assert src in out
    # Every meaningful line consists only of block / space characters.
    for line in lines:
        stripped = line.strip()
        assert set(stripped) <= {"█", " "}


def test_brand_mark_block_columns_are_consistent() -> None:
    """All five rows are exactly 10 columns wide — no width drift."""
    for line in BRAND_MARK_BLOCK_LINES:
        assert len(line) == 10


def test_brand_mark_inline_is_single_line_with_brackets() -> None:
    """The inline ``[H]`` mark renders on one line with the load-bearing chars."""
    out = _capture(brand_mark_inline())
    lines = [line for line in out.splitlines() if line.strip()]
    assert len(lines) == 1
    assert "[" in out and "H" in out and "]" in out


# ---------------------------------------------------------------------------
# brand_command_lead — mark kwarg routing
# ---------------------------------------------------------------------------


def test_brand_command_lead_default_dot_keeps_legacy_glyph() -> None:
    """``mark="dot"`` (the default) preserves the legacy ``●`` masthead."""
    out = _capture(brand_command_lead("status", version=__version__))
    assert PILL_ACTIVE in out
    # Legacy shape: no ``[H]`` brackets.
    assert "[H]" not in out


def test_brand_command_lead_inline_emits_h_brackets_not_dot() -> None:
    """``mark="inline"`` swaps the ``●`` for ``[H]`` on the same single line."""
    out = _capture(brand_command_lead("start", version=__version__, mark="inline"))
    assert "[H]" in out
    # Subtitle + version preserved.
    assert "halton-meter" in out
    assert "start" in out
    assert __version__ in out


def test_brand_command_lead_block_renders_five_line_h_left_of_wordmark() -> None:
    """``mark="block"`` produces the 5-line H to the left of the text stack."""
    out = _capture(
        brand_command_lead(
            "cost report", version="9.9.9", mark="block", date_range="May 1 → May 7"
        )
    )
    # The five H lines are present.
    for line in BRAND_MARK_BLOCK_LINES:
        assert line in out
    # Wordmark + subtitle + version + date appear in the rendered output.
    assert "halton-meter" in out
    assert "cost report" in out
    assert "v9.9.9" in out
    assert "May 1 → May 7" in out


# ---------------------------------------------------------------------------
# Surface wiring — status (Tier A) and start (Tier B)
# ---------------------------------------------------------------------------


def test_render_status_opens_with_block_h_then_wordmark() -> None:
    """``_render_status`` rendered output begins with the 5-line block H."""
    from halton_meter.lifecycle import _macos as lifecycle_macos

    rows = [lifecycle_macos._ComponentRow("Daemon", "healthy", "PID 17733")]
    summary = lifecycle_macos._HealthSummary("HEALTHY", "env-only mode is healthy.")
    report = lifecycle_macos._StatusReport(
        rows=rows,
        last_hour=12,
        last_day=345,
        healthy=True,
        health_summary=summary,
    )
    console = Console(file=StringIO(), force_terminal=False, width=100)
    lifecycle_macos._render_status(report, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]

    # First non-empty line of the rendered surface is the top of the H.
    non_empty = [line for line in out.splitlines() if line.strip()]
    assert non_empty, "status rendered no output"
    assert BRAND_MARK_BLOCK_LINES[0] in non_empty[0]
    # All five H lines present in rendered output.
    for line in BRAND_MARK_BLOCK_LINES:
        assert line in out
    # HEALTHY verdict pill (●) still rendered as a separate state
    # indicator — the H is identity, not state.
    assert PILL_ACTIVE in out


def test_render_status_broken_verdict_uses_broken_pill_not_h() -> None:
    """BROKEN verdict surfaces ``✗`` glyph; the H is never a state pill."""
    from halton_meter.lifecycle import _macos as lifecycle_macos

    summary = lifecycle_macos._HealthSummary("BROKEN", "daemon dead.")
    report = lifecycle_macos._StatusReport(
        rows=[lifecycle_macos._ComponentRow("Daemon", "dead", "no PID")],
        last_hour=0,
        last_day=0,
        healthy=False,
        health_summary=summary,
    )
    console = Console(file=StringIO(), force_terminal=False, width=100)
    lifecycle_macos._render_status(report, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]
    assert "BROKEN" in out
    assert PILL_BROKEN in out


def test_pill_glyphs_are_distinct_from_h_mark() -> None:
    """All four state pills are single-glyph and not the H character."""
    for glyph in (PILL_ACTIVE, PILL_BROKEN, PILL_DEGRADED, PILL_PAUSED):
        assert glyph != "H"
        assert glyph != "[H]"
        assert "█" not in glyph


def test_start_panel_uses_inline_h_not_dot() -> None:
    """``start`` (success path) opens with ``[H]`` not ``●``."""
    from halton_meter.lifecycle import _macos as lifecycle_macos

    console = Console(file=StringIO(), force_terminal=False, width=100)
    lifecycle_macos._render_start_success_panel(
        console,
        daemon_pid=4242,
        watchdog_pid=4243,
        api_port=8765,
        edge_port=8081,
        health_ms=2.0,
        elapsed_ms=5.0,
    )
    out = console.file.getvalue()  # type: ignore[attr-defined]
    # Tier-B masthead — inline H present.
    assert "[H]" in out
    # Existing copy preserved.
    assert "halton-meter" in out
    assert "start" in out
    # PIDs preserved.
    assert "4242" in out
    assert "4243" in out


def test_doctor_lead_uses_inline_h() -> None:
    """``doctor`` masthead opens with ``[H]``."""
    # We capture the lead helper directly rather than a full doctor run,
    # which depends on system probes. The doctor surface is wired via
    # the same brand_command_lead(mark="inline") call.
    out = _capture(brand_command_lead("doctor", version=__version__, mark="inline"))
    assert "[H]" in out
    assert "doctor" in out


# ---------------------------------------------------------------------------
# Cost report — column-width fix
# ---------------------------------------------------------------------------


def _stub_report_data(*, project_count: int = 2):  # type: ignore[no-untyped-def]
    """Build a minimal ``ReportData`` with two projects + one model.

    ``ProjectStats`` / ``ModelStats`` derive ``avg_latency_ms`` and
    ``p95_latency_ms`` from ``latencies_ms`` + ``latency_sum_ms``, so we
    seed those fields directly. The first project's latencies (73s avg /
    137.5s p95) and the second's (1.9s avg / 2.8s p95) match the spec's
    visual targets.
    """
    from halton_meter.report import ModelStats, ProjectStats, ReportData

    project_stats = []
    # Project 0 latencies chosen so avg formats to "73.0s" and p95 to
    # "137.5s" — the visual targets in the spec.
    # avg = 73000ms = 73.0s; with two values [10_000, 137_500] avg=73.75s
    # so we use [73_000.0, 73_000.0, 137_500.0] which gives:
    #   avg = (73_000+73_000+137_500) / 3 = 94_500ms = 94.5s
    # That doesn't match. Use a single-value latencies for clean averages:
    project_specs = [
        ("project-0", [73_000.0, 137_500.0]),  # avg 105.2s, p95 137.5s
        ("project-1", [1_900.0, 2_800.0]),     # avg 2.4s, p95 2.8s
    ]
    for slug, latencies in project_specs[:project_count]:
        ps = ProjectStats(
            project=slug,
            requests=len(latencies),
            input_tokens=1000,
            output_tokens=500,
            cost_millicents=50_000 if slug == "project-0" else 17_000,
            cost_excluded_count=0,
            latency_sum_ms=sum(latencies),
            latencies_ms=list(latencies),
            incomplete_count=0,
            daily_cost_buckets=[1, 0, 0, 0, 0, 0, 0],
            prev_cost_millicents=None,
        )
        project_stats.append(ps)
    model_stats = [
        ModelStats(
            model="claude-sonnet-4",
            requests=3,
            input_tokens=1000,
            output_tokens=500,
            cost_millicents=50_000,
            cost_excluded_count=0,
            latency_sum_ms=283_500.0,
            latencies_ms=[60_000.0, 86_000.0, 137_500.0],
            prev_cost_millicents=None,
        ),
    ]
    return ReportData(
        records=[],
        total_requests=sum(p.requests for p in project_stats),
        total_input_tokens=2000,
        total_output_tokens=1000,
        total_cost_millicents=67_000,
        cost_excluded_count=0,
        date_from="2026-05-01T00:00:00+00:00",
        date_to="2026-05-07T00:00:00+00:00",
        incomplete_count=0,
        project_stats=project_stats,
        model_stats=model_stats,
        span_days=7,
        prev_total_cost_millicents=None,
    )


def test_cost_report_each_project_row_is_single_line_at_width_100() -> None:
    """At width=100 every project row renders on exactly one terminal line.

    Regression for the v0.1.22.13 ``avg / p95`` combined-column wrap that
    ate three lines per project. v0.1.22.14 splits into two columns.
    """
    from halton_meter.report import render_report

    data = _stub_report_data(project_count=2)
    console = Console(file=StringIO(), force_terminal=False, width=100)
    render_report(data, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]

    # The header is the standalone ``avg`` and ``p95`` columns, NOT the
    # combined ``avg / p95`` legacy form.
    assert "avg / p95" not in out
    # Each project row contains both latency values on the same line.
    # We grep for the formatted strings produced by ``_format_latency``.
    found_first_row = False
    found_second_row = False
    for line in out.splitlines():
        # Project 0: avg = (73_000 + 137_500) / 2 = 105.2s; p95 with
        # linear-interp on two points lands at 134.3s.
        if "105.2s" in line and "134.3s" in line:
            found_first_row = True
        # Project 1: avg = (1_900 + 2_800) / 2 = 2.4s; p95 = 2.8s.
        if "2.4s" in line and "2.8s" in line:
            found_second_row = True
    assert found_first_row, "first project's avg + p95 did not land on the same line"
    assert found_second_row, "second project's avg + p95 did not land on the same line"


def test_cost_report_renders_at_width_120_without_avg_p95_combo() -> None:
    """Sanity check at wider width — the legacy combined header is gone."""
    from halton_meter.report import render_report

    data = _stub_report_data(project_count=1)
    console = Console(file=StringIO(), force_terminal=False, width=120)
    render_report(data, console)
    out = console.file.getvalue()  # type: ignore[attr-defined]
    assert "avg / p95" not in out
    # Both latency columns render their formatted values inline.
    assert "105.2s" in out
    assert "134.3s" in out
