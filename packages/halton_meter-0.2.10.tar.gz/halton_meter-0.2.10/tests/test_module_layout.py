"""Regression tests for the per-OS module layout (v0.1.22).

Guards the structural shape introduced by
``memory/plans/2026-05-05-per-os-module-refactor.md``: each of the four
platform-aware modules must be a package with ``_common``, ``_macos``,
and ``_linux`` submodules so future Linux work is purely additive.
"""

from __future__ import annotations

import importlib

import pytest

PER_OS_MODULES = ["system_proxy", "lifecycle", "install", "setup"]


@pytest.mark.parametrize("module_name", PER_OS_MODULES)
def test_module_is_a_package(module_name: str) -> None:
    """The 4 per-OS modules must be packages, not flat files."""
    module = importlib.import_module(f"halton_meter.{module_name}")
    assert hasattr(module, "__path__"), (
        f"halton_meter.{module_name} must be a package "
        f"(have __path__), not a flat module — see "
        f"memory/plans/2026-05-05-per-os-module-refactor.md"
    )


@pytest.mark.parametrize("module_name", PER_OS_MODULES)
def test_common_submodule_exists(module_name: str) -> None:
    common = importlib.import_module(f"halton_meter.{module_name}._common")
    assert common is not None


@pytest.mark.parametrize("module_name", PER_OS_MODULES)
def test_macos_submodule_exists(module_name: str) -> None:
    macos = importlib.import_module(f"halton_meter.{module_name}._macos")
    assert macos is not None


@pytest.mark.parametrize("module_name", PER_OS_MODULES)
def test_linux_submodule_exists(module_name: str) -> None:
    linux = importlib.import_module(f"halton_meter.{module_name}._linux")
    assert linux is not None
