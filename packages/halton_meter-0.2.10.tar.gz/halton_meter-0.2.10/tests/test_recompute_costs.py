"""Tests for ``halton_meter.recompute_costs``.

Covers:

* Opus 4.1 rows stored at the old wrong rate ($5/$25) are recomputed to the
  correct rate ($15/$75).
* Dry-run mode: identifies updates without writing.
* Idempotency: second pass updates zero rows.
* Gemini >200k tier: rows stored at the lower-tier rate are recomputed to
  the high-context tier rate when input_tokens > 200_000.
* Unknown model rows (compute_cost_millicents returns None) are skipped.
* Already-correct rows are skipped (rows_updated == 0).

Test DB setup uses minimal raw sqlite3 with only the columns recompute_costs
reads/writes — no SQLAlchemy engine required.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from halton_meter.pricing import compute_cost_millicents
from halton_meter.recompute_costs import recompute_costs

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# v0.1.22.22: schema includes ``provider``, ``mode``, and ``requested_at``
# because ``recompute_costs`` now consults the ``pricing_rates`` table
# scoped by (provider, model, mode) and effective_from/to. Tests that
# don't set up a ``pricing_rates`` row exercise the bundled-matrix
# fallback (the path that handled all pre-v0.1.22.22 rows).
_CREATE_TABLE = """
CREATE TABLE requests (
    id TEXT PRIMARY KEY,
    provider TEXT NOT NULL DEFAULT 'anthropic',
    model TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'standard',
    input_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    thinking_tokens INTEGER NOT NULL DEFAULT 0,
    cache_read_tokens INTEGER NOT NULL DEFAULT 0,
    cache_write_tokens INTEGER NOT NULL DEFAULT 0,
    cost_usd_minor_units INTEGER,
    requested_at TEXT NOT NULL DEFAULT '1970-01-01 00:00:00.000000'
)
"""

_INSERT_ROW = (
    "INSERT INTO requests "
    "(id, model, input_tokens, output_tokens, thinking_tokens, "
    "cache_read_tokens, cache_write_tokens, cost_usd_minor_units) "
    "VALUES (:id, :model, :input_tokens, :output_tokens, :thinking_tokens, "
    ":cache_read_tokens, :cache_write_tokens, :cost_usd_minor_units)"
)


def _make_db(tmp_path: Path, rows: list[dict]) -> Path:  # type: ignore[type-arg]
    """Create a minimal test SQLite DB and populate it with ``rows``."""
    db = tmp_path / "test.db"
    con = sqlite3.connect(str(db))
    con.execute(_CREATE_TABLE)
    for row in rows:
        con.execute(_INSERT_ROW, row)
    con.commit()
    con.close()
    return db


def _read_cost(db: Path, row_id: str) -> int | None:
    con = sqlite3.connect(str(db))
    row = con.execute(
        "SELECT cost_usd_minor_units FROM requests WHERE id = ?", (row_id,)
    ).fetchone()
    con.close()
    return row[0] if row else None


# ---------------------------------------------------------------------------
# Cost constants for claude-opus-4-1
#
# OLD (wrong) cost — as stored in v0.1.5→v0.1.10 rows at $5/$25:
#   (1000 * 500_000 + 500 * 2_500_000) // 1_000_000
#   = (500_000_000 + 1_250_000_000) // 1_000_000 = 1_750
#
# NEW (correct) cost — at $15/$75:
#   (1000 * 1_500_000 + 500 * 7_500_000) // 1_000_000
#   = (1_500_000_000 + 3_750_000_000) // 1_000_000 = 5_250
# ---------------------------------------------------------------------------
_OPUS_4_1_OLD_COST = 1_750   # wrong rate stored in old rows
_OPUS_4_1_NEW_COST = 5_250   # correct rate per current matrix
_OPUS_4_1_INPUT = 1_000
_OPUS_4_1_OUTPUT = 500

_OPUS_4_1_ROW = {
    "id": "test-uuid-opus-4-1",
    "model": "claude-opus-4-1",
    "input_tokens": _OPUS_4_1_INPUT,
    "output_tokens": _OPUS_4_1_OUTPUT,
    "thinking_tokens": 0,
    "cache_read_tokens": 0,
    "cache_write_tokens": 0,
    "cost_usd_minor_units": _OPUS_4_1_OLD_COST,
}


def test_recompute_costs_opus_4_1_dry_run(tmp_path: Path) -> None:
    """Dry run: identifies the wrong-rate row but does not write."""
    db = _make_db(tmp_path, [_OPUS_4_1_ROW])

    result = recompute_costs(db, dry_run=True)

    assert result.rows_scanned == 1
    assert result.rows_updated == 1
    assert result.old_total_millicents == _OPUS_4_1_OLD_COST
    assert result.new_total_millicents == _OPUS_4_1_NEW_COST

    # DB must be unchanged after dry run.
    assert _read_cost(db, "test-uuid-opus-4-1") == _OPUS_4_1_OLD_COST


def test_recompute_costs_opus_4_1_apply(tmp_path: Path) -> None:
    """Apply mode: updates the wrong-rate row to the correct cost."""
    db = _make_db(tmp_path, [_OPUS_4_1_ROW])

    result = recompute_costs(db, dry_run=False)

    assert result.rows_updated == 1
    assert _read_cost(db, "test-uuid-opus-4-1") == _OPUS_4_1_NEW_COST


def test_recompute_costs_idempotent(tmp_path: Path) -> None:
    """Running twice: first pass updates the row; second pass updates zero."""
    db = _make_db(tmp_path, [_OPUS_4_1_ROW])

    result1 = recompute_costs(db, dry_run=False)
    assert result1.rows_updated == 1

    result2 = recompute_costs(db, dry_run=False)
    assert result2.rows_updated == 0


def test_recompute_costs_gemini_tier_applied(tmp_path: Path) -> None:
    """gemini-2.5-pro at 300k input tokens: standard-rate row → high_context.

    Standard cost (stored, ≤200k rate):
      (300_000 * 125_000 + 500_000 * 1_000_000) // 1_000_000
      = (37_500_000_000 + 500_000_000_000) // 1_000_000 = 537_500

    High-context cost (correct for 300k input):
      (300_000 * 250_000 + 500_000 * 1_500_000) // 1_000_000
      = (75_000_000_000 + 750_000_000_000) // 1_000_000 = 825_000
    """
    old_cost = 537_500
    new_cost = 825_000

    # Verify our hand-computed values match the matrix.
    assert compute_cost_millicents("gemini-2.5-pro", 300_000, 500_000, 0, 0, 0) == new_cost

    row = {
        "id": "test-uuid-gemini-2-5-pro",
        "model": "gemini-2.5-pro",
        "input_tokens": 300_000,
        "output_tokens": 500_000,
        "thinking_tokens": 0,
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
        "cost_usd_minor_units": old_cost,
    }
    db = _make_db(tmp_path, [row])

    result = recompute_costs(db, dry_run=False)

    assert result.rows_updated == 1
    assert result.old_total_millicents == old_cost
    assert result.new_total_millicents == new_cost
    assert _read_cost(db, "test-uuid-gemini-2-5-pro") == new_cost


def test_recompute_costs_unknown_model_skipped(tmp_path: Path) -> None:
    """Rows with cost_usd_minor_units IS NULL are excluded by the WHERE clause."""
    row = {
        "id": "test-uuid-unknown",
        "model": "gpt-unknown-xyz",
        "input_tokens": 1_000,
        "output_tokens": 500,
        "thinking_tokens": 0,
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
        "cost_usd_minor_units": None,  # NULL — excluded by WHERE clause
    }
    db = _make_db(tmp_path, [row])

    result = recompute_costs(db, dry_run=False)

    # Row filtered out by WHERE cost_usd_minor_units IS NOT NULL.
    assert result.rows_scanned == 0
    assert result.rows_updated == 0


def test_recompute_costs_already_correct_skipped(tmp_path: Path) -> None:
    """Rows whose stored cost matches the current matrix are not updated."""
    correct_cost = compute_cost_millicents("claude-sonnet-4-6", 1_000, 500, 0, 0, 0)
    assert correct_cost is not None and correct_cost > 0

    row = {
        "id": "test-uuid-correct",
        "model": "claude-sonnet-4-6",
        "input_tokens": 1_000,
        "output_tokens": 500,
        "thinking_tokens": 0,
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
        "cost_usd_minor_units": correct_cost,
    }
    db = _make_db(tmp_path, [row])

    result = recompute_costs(db, dry_run=False)

    assert result.rows_scanned == 1
    assert result.rows_updated == 0
    # Cost unchanged.
    assert _read_cost(db, "test-uuid-correct") == correct_cost
