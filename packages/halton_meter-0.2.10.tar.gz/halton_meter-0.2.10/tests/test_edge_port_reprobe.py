"""Tests for ``halton_meter.port_alloc.probe_free_edge_port`` (v0.1.22 Fix 2).

The function lets the edge process fall back gracefully when its stored
effective port has been grabbed by another process (e.g. parsecd taking
:8082 at boot), rather than failing hard on bind.
"""

from __future__ import annotations

import pytest

from halton_meter import port_alloc
from halton_meter.port_alloc import (
    _EDGE_PORT_PROBE_RANGE,
    EDGE_PORT_DEFAULT,
    probe_free_edge_port,
)


class TestProbeFreeEdgePort:
    def test_returns_preferred_when_free(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Preferred port is free → returned immediately, no range probe."""
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)

        result = probe_free_edge_port(8082)

        assert result == 8082

    def test_skips_to_default_when_preferred_busy(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Preferred busy, default (8081) free → returns 8081."""

        def _free(host: str, port: int) -> bool:
            return port == EDGE_PORT_DEFAULT  # only 8081 is free

        monkeypatch.setattr(port_alloc, "_is_port_free", _free)

        result = probe_free_edge_port(8082)

        assert result == EDGE_PORT_DEFAULT

    def test_walks_range_when_default_busy(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Preferred busy, 8081 busy, 8082 free → returns 8082."""

        def _free(host: str, port: int) -> bool:
            return port == EDGE_PORT_DEFAULT + 1  # only 8082 is free

        monkeypatch.setattr(port_alloc, "_is_port_free", _free)

        result = probe_free_edge_port(8089)  # preferred is something else entirely

        assert result == EDGE_PORT_DEFAULT + 1

    def test_returns_preferred_when_all_busy(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """All ports in range are busy → returns preferred so bind can surface the error."""
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        preferred = 8082
        result = probe_free_edge_port(preferred)

        assert result == preferred, (
            "When no port is free, preferred should be returned so the "
            "subsequent bind attempt produces the standard OSError."
        )

    def test_preferred_equals_default_no_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """preferred IS the default (8081) and it's free → returns 8081 cleanly."""
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)

        result = probe_free_edge_port(EDGE_PORT_DEFAULT)

        assert result == EDGE_PORT_DEFAULT

    def test_host_forwarded_to_probe(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The ``host`` kwarg is forwarded to the underlying port checks."""
        seen_hosts: list[str] = []

        def _free(host: str, port: int) -> bool:
            seen_hosts.append(host)
            return True  # first call (preferred) returns free

        monkeypatch.setattr(port_alloc, "_is_port_free", _free)

        probe_free_edge_port(8082, host="0.0.0.0")

        assert seen_hosts == ["0.0.0.0"], (
            "host kwarg must be forwarded to the underlying port probe"
        )

    def test_probe_range_coverage(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """All ports in the default range are probed before giving up."""
        probed: list[int] = []

        def _free(host: str, port: int) -> bool:
            probed.append(port)
            return False  # nothing free

        monkeypatch.setattr(port_alloc, "_is_port_free", _free)

        # preferred is outside the default range so it's probed first
        probe_free_edge_port(9999)

        # Expect: 9999 (preferred), then 8081..8081+range-1
        expected_default_range = list(
            range(EDGE_PORT_DEFAULT, EDGE_PORT_DEFAULT + _EDGE_PORT_PROBE_RANGE)
        )
        assert probed[0] == 9999
        assert probed[1:] == expected_default_range, (
            f"Expected full default range to be probed; got {probed[1:]}"
        )
