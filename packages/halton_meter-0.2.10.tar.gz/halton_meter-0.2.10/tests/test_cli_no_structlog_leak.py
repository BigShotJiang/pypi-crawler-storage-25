"""Regression tests for v0.1.22.1 A1: zero structlog noise in user-facing CLI.

Every user-facing Click command must call
:func:`halton_meter.cli_runtime.configure_for_user_cli` as its first
line so structlog INFO/DEBUG events stop leaking onto the user's
terminal. These tests don't run the full lifecycle — they just emit a
representative INFO event from inside each command's process and assert
nothing matching the structlog timestamp prefix surfaces on stdout
(stderr is allowed to carry WARNING+ events but must not carry INFO).

The user-facing inventory deliberately excludes the launchd-spawned
processes (``daemon``, ``edge``, ``watchdog``, ``install``,
``_apply-user-env``) — those configure their own structlog and need
real structured logs to land in the err-log files.
"""

from __future__ import annotations

import re

import pytest
import structlog
from click.testing import CliRunner

from halton_meter import cli as cli_module
from halton_meter import cli_runtime

# The structlog ConsoleRenderer / KeyValueRenderer default prefix —
# ``YYYY-MM-DD HH:MM:SS [info     ] event=...`` or just
# ``YYYY-MM-DD HH:MM:SS [info     ] event``. Match the timestamp +
# bracketed level for the leak detector.
_STRUCTLOG_LEAK = re.compile(
    r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \[(info|debug)",
    re.MULTILINE,
)


def _reset_structlog_to_default() -> None:
    """Reset structlog to its default factory so each test starts with
    the leaky default (PrintLogger -> stdout) and only the silencer
    can quiet it."""
    structlog.reset_defaults()
    cli_runtime._CONFIGURED = False


@pytest.fixture(autouse=True)
def _structlog_reset_each_test() -> None:
    _reset_structlog_to_default()
    yield
    _reset_structlog_to_default()


# Commands that touch only inert helpers (no launchctl, no daemon
# state) and so are safe to invoke under CliRunner with no fixtures.
# Subcommands of ``bodies`` / ``project`` are covered transitively by
# their group callbacks (the group runs first under Click).
_INERT_COMMANDS: list[list[str]] = [
    [],  # bare ``halton-meter`` (renders welcome + help)
    ["version"],
    ["--help"],
    ["bodies", "--help"],
    ["project", "--help"],
    ["report", "--help"],
    ["init", "--help"],
    ["start", "--help"],
    ["stop", "--help"],
    ["status", "--help"],
    ["uninstall", "--help"],
    ["setup", "--help"],
    ["rescue", "--help"],
    ["reset-proxy", "--help"],
    ["doctor", "--help"],
    ["onboard", "--help"],
    ["retag", "--help"],
    ["recompute-costs", "--help"],
    ["run", "--help"],
]


@pytest.mark.parametrize("argv", _INERT_COMMANDS, ids=lambda a: " ".join(a) or "(bare)")
def test_user_facing_command_does_not_leak_structlog(argv: list[str]) -> None:
    """Each user-facing CLI invocation must produce zero structlog
    INFO/DEBUG lines on stdout or stderr.

    We pre-emit a representative log event after the silencer has had a
    chance to install (the ``cli`` group callback runs first). The
    silencer drops INFO; if it isn't wired, the line lands on stdout.
    """
    # Click >= 8.2 captures stderr separately by default; older
    # versions used the ``mix_stderr=False`` toggle which was removed.
    runner = CliRunner()

    # Sanity: with the default factory and no silencer, an INFO event
    # WOULD print to stdout. The runner captures stdout/stderr; once
    # the command's silencer fires, subsequent INFO emissions drop.
    result = runner.invoke(cli_module.cli, argv, catch_exceptions=False)

    # ``--help`` exits 0; bare command exits 0. Either way, no structlog leak.
    combined = (result.stdout or "") + "\n" + (result.stderr or "")
    leaks = _STRUCTLOG_LEAK.findall(combined)
    assert leaks == [], (
        f"structlog leak in `halton-meter {' '.join(argv)}` output: "
        f"matched {len(leaks)} prefix(es). "
        f"stdout=\n{result.stdout!r}\nstderr=\n{result.stderr!r}"
    )


def test_configure_for_user_cli_silences_info(capsys: pytest.CaptureFixture[str]) -> None:
    """Direct unit test: after calling the silencer, INFO and DEBUG
    events emit nothing visible (filtered out at the bound logger),
    while WARNING+ surface on stderr."""
    cli_runtime.configure_for_user_cli()

    log = structlog.get_logger()
    log.info("test.info_event_should_drop", value=42)
    log.debug("test.debug_event_should_drop", value=42)
    log.warning("test.warning_event_should_surface", value=42)

    captured = capsys.readouterr()
    assert "test.info_event_should_drop" not in captured.out
    assert "test.info_event_should_drop" not in captured.err
    assert "test.debug_event_should_drop" not in captured.out
    assert "test.debug_event_should_drop" not in captured.err
    # WARNING surfaces on stderr (not stdout — keeps piped output clean).
    assert "test.warning_event_should_surface" in captured.err
    assert "test.warning_event_should_surface" not in captured.out


def test_configure_for_user_cli_is_idempotent() -> None:
    """Calling the silencer twice is safe; second call is a no-op."""
    cli_runtime.configure_for_user_cli()
    first_state = cli_runtime._CONFIGURED
    cli_runtime.configure_for_user_cli()
    assert first_state is True
    assert cli_runtime._CONFIGURED is True


_USER_FACING_CALLBACKS: list[tuple[str, str]] = [
    # (module_name, function_name) — every user-facing Click callback
    # whose body must call configure_for_user_cli() as its first
    # in-body statement (after the docstring).
    ("halton_meter.cli", "version"),
    ("halton_meter.cli", "report"),
    ("halton_meter.cli", "install"),
    ("halton_meter.cli", "uninstall"),
    ("halton_meter.cli", "start"),
    ("halton_meter.cli", "stop"),
    ("halton_meter.cli", "status"),
    ("halton_meter.cli", "reset_proxy_cmd"),
    ("halton_meter.cli", "rescue_cmd"),
    ("halton_meter.cli", "run_cmd"),
    ("halton_meter.cli", "init_cmd"),
    ("halton_meter.cli", "onboard_cmd"),
    ("halton_meter.cli", "setup"),
    ("halton_meter.cli", "retag_cmd"),
    ("halton_meter.cli", "recompute_costs_cmd"),
    ("halton_meter.cli", "bodies_group"),
    ("halton_meter.cli", "project_group"),
    ("halton_meter.cli", "pricing_group"),
    ("halton_meter.cli", "pricing_list_cmd"),
    ("halton_meter.cli", "pricing_set_cmd"),
    ("halton_meter.cli", "pricing_reset_cmd"),
    ("halton_meter.doctor", "doctor_cmd"),
]


@pytest.mark.parametrize("module_name,func_name", _USER_FACING_CALLBACKS)
def test_user_facing_callback_calls_silencer(module_name: str, func_name: str) -> None:
    """Source-level guard: every user-facing Click command callback must
    call ``configure_for_user_cli()`` somewhere in its body. The test
    looks at the wrapped function's source — Click's decorator chain
    preserves ``__wrapped__`` / ``callback`` attributes."""
    import importlib
    import inspect

    module = importlib.import_module(module_name)
    obj = getattr(module, func_name)
    # Click commands wrap the original callback under .callback;
    # plain functions are returned as-is.
    func = getattr(obj, "callback", obj)
    source = inspect.getsource(func)
    assert "configure_for_user_cli()" in source, (
        f"{module_name}.{func_name} is user-facing but does not call "
        f"configure_for_user_cli(). Source:\n{source[:400]}"
    )


def test_halton_debug_env_var_opts_back_in(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """``HALTON_DEBUG=1`` re-enables DEBUG/INFO on stderr for development."""
    monkeypatch.setenv("HALTON_DEBUG", "1")
    cli_runtime.configure_for_user_cli()

    log = structlog.get_logger()
    log.info("test.info_event_visible_with_debug", value=42)

    captured = capsys.readouterr()
    assert "test.info_event_visible_with_debug" in captured.err
    assert "test.info_event_visible_with_debug" not in captured.out
