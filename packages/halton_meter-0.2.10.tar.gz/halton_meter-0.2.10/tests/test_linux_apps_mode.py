"""Linux apps-mode dispatch + no-op tests.

**v0.1.22.5 — UNTESTED on real Linux.** Subprocess-mocked unit tests only.
These tests verify the per-OS dispatch shape on Linux and the apps-mode
no-op contracts in :mod:`halton_meter.system_proxy._linux`. Real systemd
/ real ``update-ca-certificates`` behaviour is NOT verified — that
needs a real Linux box and is the next user-soak gate.

Why source-grep + import-shape tests live next to the (sparse)
behavioural ones: the per-OS refactor means broken dispatch silently
falls back to ``NotImplementedError`` stubs, which would surface as a
flood of opaque failures across every other test file. Catching it
here means one focused failure with the right message.
"""

from __future__ import annotations

import sys

import pytest

# Skip these tests on darwin — the dispatch routes to _macos there and
# this file is specifically about Linux semantics.
pytestmark = pytest.mark.skipif(
    sys.platform == "darwin",
    reason="Linux apps-mode dispatch tests; macOS routes to _macos.",
)


# --------------------------------------------------------------------------- #
# Per-OS dispatch shape                                                        #
# --------------------------------------------------------------------------- #


def test_install_package_dispatches_to_linux_impl_on_linux() -> None:
    """``halton_meter.install._impl`` must point at ``_linux`` on Linux."""
    import halton_meter.install as install_pkg

    assert install_pkg._impl.__name__.endswith("._linux"), (
        f"install dispatch should route to _linux on Linux; "
        f"got {install_pkg._impl.__name__!r}"
    )


def test_lifecycle_package_dispatches_to_linux_impl_on_linux() -> None:
    import halton_meter.lifecycle as lifecycle_pkg

    assert lifecycle_pkg._impl.__name__.endswith("._linux")


def test_setup_package_dispatches_to_linux_impl_on_linux() -> None:
    import halton_meter.setup as setup_pkg

    assert setup_pkg._impl.__name__.endswith("._linux")


def test_system_proxy_package_dispatches_to_linux_impl_on_linux() -> None:
    import halton_meter.system_proxy as system_proxy_pkg

    assert system_proxy_pkg._impl.__name__.endswith("._linux")


# --------------------------------------------------------------------------- #
# Cross-imports needed by lifecycle/_macos.py must resolve on Linux            #
# --------------------------------------------------------------------------- #


def test_install_linux_re_exports_macos_label_constants() -> None:
    """``lifecycle/_macos.py`` (which is the source of Linux start/stop/status
    via the per-OS refactor's left-behind code) imports ``_LABEL``, ``_EDGE_LABEL``,
    etc. from ``halton_meter.install``. Those imports must resolve on Linux,
    or the entire lifecycle module fails to import and ``halton-meter status``
    crashes before printing anything.
    """
    from halton_meter.install import (
        _LABEL,
        _LINUX_UNIT_NAME,
        _linux_unit_path,
        _linux_watchdog_unit_path,
        _macos_edge_plist_path,
        _macos_paths,
        _macos_watchdog_plist_path,
        _proxy_managed_sentinel_path,
    )

    # Constants must be strings, not None / NotImplementedError.
    assert isinstance(_LABEL, str) and _LABEL.startswith("com.haltonlabs.meter")
    assert isinstance(_LINUX_UNIT_NAME, str) and _LINUX_UNIT_NAME.endswith(".service")
    # Path helpers are callable.
    assert callable(_linux_unit_path)
    assert callable(_linux_watchdog_unit_path)
    assert callable(_proxy_managed_sentinel_path)
    # macOS-named helpers exist on Linux too — they're imported defensively
    # from doctor / lifecycle even when Linux dispatch wins.
    assert callable(_macos_paths)
    assert callable(_macos_edge_plist_path)
    assert callable(_macos_watchdog_plist_path)


def test_lifecycle_public_api_is_callable_on_linux() -> None:
    from halton_meter.lifecycle import start, status, stop

    assert callable(start)
    assert callable(stop)
    assert callable(status)


def test_install_public_api_is_callable_on_linux() -> None:
    from halton_meter.install import install, uninstall

    assert callable(install)
    assert callable(uninstall)


def test_setup_public_api_is_callable_on_linux() -> None:
    from halton_meter.setup import (
        check_steps,
        generate_mitmproxy_cert,
        patch_certifi,
        run_setup,
        trust_cert_linux,
    )

    assert callable(check_steps)
    assert callable(generate_mitmproxy_cert)
    assert callable(patch_certifi)
    assert callable(run_setup)
    assert callable(trust_cert_linux)


# --------------------------------------------------------------------------- #
# system_proxy apps-mode no-op contracts                                       #
# --------------------------------------------------------------------------- #


def test_install_proxy_cleanup_returns_none_on_linux() -> None:
    """Apps mode never enables a system proxy → no cleanup handler to register."""
    from halton_meter.system_proxy import install_proxy_cleanup

    assert install_proxy_cleanup("127.0.0.1", 8080) is None


def test_enable_system_proxy_if_managed_is_silent_noop_on_linux() -> None:
    """``enable_system_proxy_if_managed`` must be a silent no-op so the
    daemon's startup path on Linux doesn't fail. No exception, no state
    change."""
    from halton_meter.system_proxy import enable_system_proxy_if_managed

    # Both eager values must succeed without raising.
    assert enable_system_proxy_if_managed("127.0.0.1", 8080) is None
    assert enable_system_proxy_if_managed("127.0.0.1", 8080, eager=True) is None


def test_reset_proxy_minimal_returns_zero_on_linux() -> None:
    """``halton-meter reset-proxy`` is a benign no-op on Linux apps mode."""
    from halton_meter.system_proxy import reset_proxy_minimal

    assert reset_proxy_minimal() == 0


def test_setenv_user_domain_returns_zero_per_key_on_linux() -> None:
    """No-op success for every key — apps mode reads env from shell rc."""
    from halton_meter.system_proxy import setenv_user_domain

    result = setenv_user_domain({"HTTP_PROXY": "http://x", "HTTPS_PROXY": "http://x"})
    assert result == {"HTTP_PROXY": 0, "HTTPS_PROXY": 0}


def test_unsetenv_user_domain_returns_zero_per_key_on_linux() -> None:
    from halton_meter.system_proxy import unsetenv_user_domain

    assert unsetenv_user_domain(["HTTP_PROXY", "HTTPS_PROXY"]) == {
        "HTTP_PROXY": 0,
        "HTTPS_PROXY": 0,
    }


def test_getenv_user_domain_returns_none_on_linux() -> None:
    from halton_meter.system_proxy import getenv_user_domain

    assert getenv_user_domain("HTTPS_PROXY") is None


def test_read_proxy_target_reports_no_target_on_linux() -> None:
    """Apps mode never points the system proxy at us — reads must report
    'not enabled, no host, no port' so doctor doesn't false-flag a managed
    install."""
    from halton_meter.system_proxy import read_proxy_target

    enabled, host, port = read_proxy_target()
    assert enabled is False
    assert host is None
    assert port is None


def test_snapshot_system_proxy_is_silent_noop_on_linux() -> None:
    """Apps mode has no system-proxy state to snapshot."""
    from halton_meter.system_proxy import snapshot_system_proxy

    snapshot_system_proxy()  # must not raise.


def test_restore_system_proxy_returns_false_on_linux() -> None:
    """Symmetric with snapshot — nothing to restore."""
    from halton_meter.system_proxy import restore_system_proxy

    assert restore_system_proxy("127.0.0.1", 8080) is False


def test_gui_launchctl_env_keys_is_empty_on_linux() -> None:
    """No launchctl on Linux → no env-keys to manage."""
    from halton_meter.system_proxy import GUI_LAUNCHCTL_ENV_KEYS

    assert GUI_LAUNCHCTL_ENV_KEYS == ()


def test_admin_exception_hierarchy_re_exports_on_linux() -> None:
    """The exception classes must be importable so callers don't need
    a platform branch around their try/except."""
    from halton_meter.system_proxy import (
        AdminCancelledError,
        AdminElevationError,
        AdminInfrastructureError,
        AdminInnerCommandError,
    )

    assert issubclass(AdminCancelledError, AdminElevationError)
    assert issubclass(AdminInfrastructureError, AdminElevationError)
    assert issubclass(AdminInnerCommandError, AdminElevationError)


def test_proxy_managed_sentinel_path_is_inside_halton_meter_dir() -> None:
    """Sentinel path must match macOS so install-mode detection works
    cross-platform."""
    from halton_meter.system_proxy import proxy_managed_sentinel_path

    p = proxy_managed_sentinel_path()
    assert p.name == "proxy-managed"
    assert p.parent.name == ".halton-meter"


def test_system_state_path_is_inside_halton_meter_dir() -> None:
    from halton_meter.system_proxy import system_state_path

    p = system_state_path()
    assert p.name == "system_state.json"
    assert p.parent.name == ".halton-meter"


# --------------------------------------------------------------------------- #
# trust_cert_linux: deferred-step semantics                                    #
# --------------------------------------------------------------------------- #


def test_trust_cert_linux_returns_deferred_step_status() -> None:
    """The Linux trust-store install is deferred to a future Linux phase.
    apps-mode users rely on the certifi-patched bundle; trust_cert_linux
    must report this honestly so doctor / setup output reads clearly."""
    from halton_meter.setup import StepStatus, trust_cert_linux

    status = trust_cert_linux()
    assert isinstance(status, StepStatus)
    assert status.done is False
    assert "deferred" in status.note.lower() or "certifi" in status.note.lower()


# --------------------------------------------------------------------------- #
# init.py Linux flow: --full downgrades to apps                                #
# --------------------------------------------------------------------------- #


def test_init_linux_full_mode_downgrade_string_is_present_in_source() -> None:
    """``init --full`` on Linux must downgrade to apps mode (the system-
    proxy management path is the deferred Linux phase). Source-grep is the
    right tool here — driving init() end-to-end requires substantial
    fixture wiring and the downgrade itself is a single conditional.
    """
    from pathlib import Path

    from halton_meter import init as init_module

    src = Path(init_module.__file__).read_text()
    # The downgrade message must mention --full and apps-mode fallback so
    # the user understands what just happened.
    assert "--full system-proxy management is not" in src
    assert "Falling back to apps mode" in src


def test_init_full_mode_proxy_step_gated_on_darwin() -> None:
    """The system-proxy enable step in init must be gated on darwin so
    Linux apps-mode users never trigger an admin prompt that doesn't
    exist."""
    from pathlib import Path

    from halton_meter import init as init_module

    src = Path(init_module.__file__).read_text()
    # The gating check must include the platform == "darwin" guard.
    assert 'mode == MODE_FULL and platform == "darwin"' in src


# --------------------------------------------------------------------------- #
# Smoke: Linux apps-mode dispatch for key entry points                         #
# --------------------------------------------------------------------------- #


def test_lifecycle_status_dispatches_to_linux_helper(monkeypatch: pytest.MonkeyPatch) -> None:
    """Smoke test: ``halton_meter.lifecycle.status`` reaches the Linux branch."""
    import halton_meter.lifecycle as lifecycle_pkg
    from halton_meter.lifecycle import _macos as macos_module

    branch_taken = {"linux": False}
    real_build_status_linux = macos_module._build_status_linux

    def fake_build_status_linux(cfg):  # type: ignore[no-untyped-def]
        branch_taken["linux"] = True
        return real_build_status_linux(cfg)

    monkeypatch.setattr(macos_module, "_build_status_linux", fake_build_status_linux)
    # JSON output keeps the test small + side-effect-free.
    rc = lifecycle_pkg.status(json_output=True)
    assert isinstance(rc, int)
    assert branch_taken["linux"], (
        "lifecycle.status on Linux must reach _build_status_linux"
    )


# --------------------------------------------------------------------------- #
# v0.1.23 Blocker 2: watchdog must NOT install on Linux                        #
# --------------------------------------------------------------------------- #


def test_install_linux_does_not_write_watchdog_unit(tmp_path, monkeypatch) -> None:
    """``_install_linux`` must skip the watchdog unit file write.

    The watchdog is a macOS ``networksetup`` poller with no Linux job.
    Pre-v0.1.23, ``_install_linux`` wrote ``halton-meter-watchdog.service``
    and enabled it, after which systemd's Restart=always + StartLimitBurst
    drove the unit into permanent failed state ~7s after install. The fix:
    skip the write + enable entirely on Linux.
    """
    from halton_meter.install import _macos as install_macos

    monkeypatch.setenv("HOME", str(tmp_path))
    # Stub out subprocess so daemon-reload / enable calls don't escape into
    # the host. We only care about the on-disk unit files.
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        calls.append(list(cmd))
        return type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})()

    monkeypatch.setattr(install_macos.subprocess, "run", fake_run)
    monkeypatch.setattr(install_macos, "_resolve_halton_path", lambda: tmp_path / "halton-meter")

    rc = install_macos._install_linux()
    assert rc == 0

    daemon_unit = tmp_path / ".config" / "systemd" / "user" / "halton-meter.service"
    watchdog_unit = tmp_path / ".config" / "systemd" / "user" / "halton-meter-watchdog.service"
    assert daemon_unit.exists(), "daemon unit must still be written on Linux"
    assert not watchdog_unit.exists(), (
        "watchdog unit MUST NOT be written on Linux (v0.1.23 Blocker 2)"
    )

    # Enable calls must not target the watchdog unit.
    enable_calls = [c for c in calls if "enable" in c]
    assert enable_calls, "daemon unit should be enabled"
    for cmd in enable_calls:
        assert "halton-meter-watchdog.service" not in cmd, (
            f"watchdog unit must not be enabled on Linux; got {cmd}"
        )


def test_install_linux_removes_stale_watchdog_unit(tmp_path, monkeypatch) -> None:
    """If a stale watchdog unit from an older version exists, _install_linux
    removes it so the user's ``systemctl --user list-unit-files`` is clean
    after upgrading to v0.1.23.
    """
    from halton_meter.install import _macos as install_macos

    monkeypatch.setenv("HOME", str(tmp_path))
    units_dir = tmp_path / ".config" / "systemd" / "user"
    units_dir.mkdir(parents=True)
    stale = units_dir / "halton-meter-watchdog.service"
    stale.write_text("# stale from a pre-v0.1.23 install\n")

    monkeypatch.setattr(
        install_macos.subprocess,
        "run",
        lambda cmd, **kw: type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})(),
    )
    monkeypatch.setattr(install_macos, "_resolve_halton_path", lambda: tmp_path / "halton-meter")

    install_macos._install_linux()
    assert not stale.exists(), "stale watchdog unit should be removed on Linux upgrade"


# --------------------------------------------------------------------------- #
# v0.1.23 Blocker 1 — edge systemd unit                                       #
# --------------------------------------------------------------------------- #


def test_install_linux_writes_edge_unit_with_keepalive_shape(tmp_path, monkeypatch):
    """v0.1.23 Blocker 1: edge unit written next to the daemon unit, with
    Restart=always + RestartSec=1 (KeepAlive shape) + TimeoutStopSec=10 +
    KillSignal=SIGTERM + LimitNOFILE=10240."""
    from halton_meter.install import _macos as install_macos

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(
        install_macos.subprocess,
        "run",
        lambda cmd, **kw: type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})(),
    )
    monkeypatch.setattr(install_macos, "_resolve_halton_path", lambda: tmp_path / "halton-meter")

    install_macos._install_linux()

    edge_unit = tmp_path / ".config" / "systemd" / "user" / "halton-meter-edge.service"
    assert edge_unit.exists()
    text = edge_unit.read_text()
    assert "ExecStart=" in text and " edge\n" in text  # calls `halton-meter edge`
    assert "Restart=always" in text
    assert "RestartSec=1" in text
    assert "TimeoutStopSec=10" in text
    assert "KillSignal=SIGTERM" in text
    assert "LimitNOFILE=10240" in text


def test_install_linux_enables_edge_unit(tmp_path, monkeypatch):
    """Daemon + edge units must both be enabled (watchdog stays skipped)."""
    from halton_meter.install import _macos as install_macos

    monkeypatch.setenv("HOME", str(tmp_path))
    calls: list[list[str]] = []

    def fake_run(cmd, **kw):  # type: ignore[no-untyped-def]
        calls.append(list(cmd))
        return type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})()

    monkeypatch.setattr(install_macos.subprocess, "run", fake_run)
    monkeypatch.setattr(install_macos, "_resolve_halton_path", lambda: tmp_path / "halton-meter")

    install_macos._install_linux()

    enable_calls = [c for c in calls if "enable" in c]
    enabled_units = {c[-1] for c in enable_calls}
    assert "halton-meter.service" in enabled_units
    assert "halton-meter-edge.service" in enabled_units
    assert "halton-meter-watchdog.service" not in enabled_units


# --------------------------------------------------------------------------- #
# v0.1.23 Blocker 4 — uninstall completeness on Linux                         #
# --------------------------------------------------------------------------- #


def test_uninstall_linux_removes_sentinels_and_runs_reload(tmp_path, monkeypatch):
    """Non-graceful Linux uninstall must remove proxy-managed + apps-managed
    sentinels and run systemctl daemon-reload + reset-failed (load-bearing
    so a subsequent ``init`` starts from a clean systemd state)."""
    from halton_meter.install import _macos as install_macos

    monkeypatch.setenv("HOME", str(tmp_path))
    calls: list[list[str]] = []

    def fake_run(cmd, **kw):  # type: ignore[no-untyped-def]
        calls.append(list(cmd))
        return type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})()

    monkeypatch.setattr(install_macos.subprocess, "run", fake_run)

    # Drop pre-existing sentinels. _uninstall_linux reads
    # halton_meter.setup.{PROXY,APPS}_MANAGED_SENTINEL — module-level
    # constants resolved at import time from $HOME, so monkeypatch the
    # constants to point at tmp_path or the test races the import order.
    halton_dir = tmp_path / ".halton-meter"
    halton_dir.mkdir()
    proxy_sentinel = halton_dir / "proxy-managed"
    apps_sentinel = halton_dir / "apps-managed"
    proxy_sentinel.write_text("")
    apps_sentinel.write_text("")

    from halton_meter import setup as halton_setup

    monkeypatch.setattr(halton_setup, "PROXY_MANAGED_SENTINEL", proxy_sentinel)
    monkeypatch.setattr(halton_setup, "APPS_MANAGED_SENTINEL", apps_sentinel)

    install_macos._uninstall_linux(graceful=False)

    assert not proxy_sentinel.exists(), "proxy-managed sentinel must be removed"
    assert not apps_sentinel.exists(), "apps-managed sentinel must be removed"
    assert ["systemctl", "--user", "daemon-reload"] in calls
    for unit in (
        "halton-meter-watchdog.service",
        "halton-meter-edge.service",
        "halton-meter.service",
    ):
        assert ["systemctl", "--user", "reset-failed", unit] in calls


def test_uninstall_linux_removes_edge_unit_file(tmp_path, monkeypatch):
    """v0.1.23 Blocker 1+4: the edge unit file must be removed from
    ~/.config/systemd/user/ on uninstall (both graceful and default)."""
    from halton_meter.install import _macos as install_macos

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(
        install_macos.subprocess,
        "run",
        lambda cmd, **kw: type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})(),
    )

    units_dir = tmp_path / ".config" / "systemd" / "user"
    units_dir.mkdir(parents=True)
    edge_unit = units_dir / "halton-meter-edge.service"
    edge_unit.write_text("# fake\n")

    install_macos._uninstall_linux(graceful=False)
    assert not edge_unit.exists()



