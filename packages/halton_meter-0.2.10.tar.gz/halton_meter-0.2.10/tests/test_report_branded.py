"""
v0.1.22.13 — branded cost report tests.

Covers the rebrand + nine new features:

  * Editorial date-range masthead (Apr 1 → May 6 short format)
  * Section dividers for summary / by project / by model
  * Cost decimal rules — never six decimals
  * Bundle-ID humanisation (mac:com.docker.docker → Docker)
  * Model date suffix strip (claude-haiku-4-5-20251001 → claude-haiku-4-5)
  * Case-insensitive project sort
  * p95 latency column populated
  * 7d trend sparkline column when window ≥ 2 days
  * --since 7d / --from / --to / --vs-previous / --by / --csv / --json
  * Top-1 outlier row accent
  * Tightened warnings (single line under summary, full footer)
  * Mutually exclusive flag combinations rejected
"""

from __future__ import annotations

import csv
import io
import json
from datetime import UTC, datetime, timedelta

import pytest
from click.testing import CliRunner
from rich.console import Console

from halton_meter.models import LogRecord
from halton_meter.report import (
    build_report_data,
    format_usd,
    humanize_project,
    parse_iso_date,
    parse_since,
    render_csv,
    render_json,
    render_report,
    strip_model_date,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _rec(
    *,
    project: str = "alpha",
    model: str = "claude-haiku-4-5",
    cost_millicents: int | None = 1_000,
    input_tokens: int = 100,
    output_tokens: int = 50,
    latency_ms: float = 500.0,
    requested_at: str | None = None,
    tokens_complete: bool = True,
) -> LogRecord:
    if requested_at is None:
        requested_at = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    return LogRecord(
        id="test-id",
        project=project,
        provider="anthropic",
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cost_millicents=cost_millicents,
        tokens_complete=tokens_complete,
        latency_ms=latency_ms,
        requested_at=requested_at,
        recorded_at=requested_at,
    )


def _console() -> Console:
    return Console(record=True, width=120)


def _plain_console() -> tuple[Console, io.StringIO]:
    """Return a Console writing to a StringIO with terminal forcing OFF."""
    buf = io.StringIO()
    return Console(file=buf, force_terminal=False, width=88), buf


# ---------------------------------------------------------------------------
# Bundle-ID humanisation
# ---------------------------------------------------------------------------


class TestBundleHumanisation:
    def test_known_bundle(self) -> None:
        assert humanize_project("mac:com.docker.docker") == "Docker"
        assert humanize_project("mac:com.microsoft.excel") == "Excel"
        assert humanize_project("mac:com.microsoft.outlook") == "Outlook"
        assert humanize_project("mac:com.microsoft.teams2") == "Teams"
        assert humanize_project("mac:com.apple.Safari") == "Safari"
        assert humanize_project("mac:com.apple.dock") == "Dock"
        assert humanize_project("mac:com.google.Chrome") == "Chrome"
        assert humanize_project("mac:org.mozilla.firefox") == "Firefox"

    def test_unknown_bundle_drops_prefix_only(self) -> None:
        assert humanize_project("mac:com.acme.foo") == "com.acme.foo"

    def test_non_mac_passthrough(self) -> None:
        assert humanize_project("halton-meter") == "halton-meter"
        assert humanize_project("AlgoNifty") == "AlgoNifty"

    def test_renders_in_table(self) -> None:
        rec = _rec(project="mac:com.docker.docker", cost_millicents=10_000)
        c = _console()
        render_report(build_report_data([rec]), c)
        out = c.export_text()
        assert "Docker" in out
        # The raw ``mac:`` prefix must NOT leak through to the rendered table.
        assert "mac:com.docker.docker" not in out


# ---------------------------------------------------------------------------
# Model date strip
# ---------------------------------------------------------------------------


class TestModelDateStrip:
    def test_strip_dated(self) -> None:
        assert strip_model_date("claude-haiku-4-5-20251001") == "claude-haiku-4-5"

    def test_no_date_suffix_passthrough(self) -> None:
        assert strip_model_date("claude-haiku-4-5") == "claude-haiku-4-5"

    def test_renders_stripped(self) -> None:
        rec = _rec(model="claude-haiku-4-5-20251001", cost_millicents=10_000)
        c = _console()
        render_report(build_report_data([rec]), c)
        out = c.export_text()
        assert "claude-haiku-4-5" in out
        assert "20251001" not in out


# ---------------------------------------------------------------------------
# Case-insensitive sort
# ---------------------------------------------------------------------------


def test_case_insensitive_project_sort() -> None:
    r1 = _rec(project="AlgoNifty", cost_millicents=10_000)
    r2 = _rec(project="algonifty", cost_millicents=10_000)
    r3 = _rec(project="halton-meter", cost_millicents=10_000)
    r4 = _rec(project="Beta", cost_millicents=10_000)
    data = build_report_data([r1, r2, r3, r4])
    keys = [s.project.lower() for s in data.project_stats]
    assert keys == sorted(keys)
    # AlgoNifty / algonifty must end up adjacent (both start with 'a').
    a_indices = [i for i, k in enumerate(keys) if k == "algonifty"]
    assert len(a_indices) == 2
    assert a_indices[1] - a_indices[0] == 1


# ---------------------------------------------------------------------------
# Cost decimal formatting
# ---------------------------------------------------------------------------


class TestCostFormatting:
    def test_amounts_at_or_above_one_cent_use_2dp(self) -> None:
        assert format_usd(1_000) == "$0.01"
        assert format_usd(194_000) == "$1.94"
        assert format_usd(23_510_000) == "$235.10"

    def test_sub_cent_uses_4dp(self) -> None:
        assert format_usd(10) == "$0.0001"
        assert format_usd(400) == "$0.0040"

    def test_never_six_decimals_in_render(self) -> None:
        rec = _rec(cost_millicents=4)
        c = _console()
        render_report(build_report_data([rec]), c)
        out = c.export_text()
        assert ".000000" not in out


# ---------------------------------------------------------------------------
# Editorial layout — section dividers + masthead
# ---------------------------------------------------------------------------


class TestEditorialLayout:
    def test_masthead_carries_short_date_range(self) -> None:
        # Apr 1 → May 6
        r1 = _rec(cost_millicents=10_000, requested_at="2026-04-01T10:00:00Z")
        r2 = _rec(cost_millicents=10_000, requested_at="2026-05-06T10:00:00Z")
        c = _console()
        render_report(build_report_data([r1, r2]), c)
        out = c.export_text()
        assert "Apr 1" in out
        assert "May 6" in out
        assert "→" in out

    def test_section_dividers_present(self) -> None:
        rec = _rec(cost_millicents=100_000)
        c = _console()
        render_report(build_report_data([rec]), c)
        out = c.export_text()
        # Editorial section headers carry a chevron + lower-case label.
        assert "summary" in out
        assert "by project" in out
        assert "by model" in out

    def test_summary_includes_coverage(self) -> None:
        r1 = _rec(project="alpha", model="claude-haiku-4-5", cost_millicents=10_000)
        r2 = _rec(project="beta", model="claude-sonnet-4-6", cost_millicents=10_000)
        c = _console()
        render_report(build_report_data([r1, r2]), c)
        out = c.export_text()
        # The Coverage row carries the project + model counts.
        assert "Coverage" in out
        assert "2 projects" in out
        assert "2 models" in out


# ---------------------------------------------------------------------------
# Latency p95 column
# ---------------------------------------------------------------------------


def test_p95_column_populated() -> None:
    recs = [_rec(latency_ms=v * 1000.0, cost_millicents=10_000) for v in (1, 2, 3, 4, 8, 22)]
    c = _console()
    render_report(build_report_data(recs), c)
    out = c.export_text()
    # The avg / p95 column header must be present.
    assert "avg / p95" in out
    # And per-row latency cells should render.
    assert "s" in out  # at least one latency rendered as "Ns"


# ---------------------------------------------------------------------------
# 7d trend sparkline
# ---------------------------------------------------------------------------


def test_sparkline_column_present_with_multi_day_data() -> None:
    base = datetime(2026, 5, 7, 12, 0, tzinfo=UTC)
    recs = []
    for i in range(5):
        ts = (base - timedelta(days=i)).isoformat().replace("+00:00", "Z")
        recs.append(_rec(cost_millicents=10_000, requested_at=ts))
    data = build_report_data(recs, window_end=base)
    c = _console()
    render_report(data, c)
    out = c.export_text()
    assert "7d trend" in out
    assert data.span_days >= 2
    # Buckets are populated.
    assert sum(data.project_stats[0].daily_cost_buckets) > 0


def test_sparkline_column_hidden_for_single_day_window() -> None:
    rec = _rec(cost_millicents=10_000)
    data = build_report_data([rec])
    c = _console()
    render_report(data, c)
    out = c.export_text()
    assert "7d trend" not in out


# ---------------------------------------------------------------------------
# CLI flags
# ---------------------------------------------------------------------------


@pytest.fixture()
def clean_db(tmp_path):
    """Path to an empty DB. The report CLI works fine on an empty DB."""
    return str(tmp_path / "empty.db")


def _invoke(args: list[str], db_path: str):  # type: ignore[no-untyped-def]
    from halton_meter.cli import cli

    runner = CliRunner()
    return runner.invoke(cli, ["report", "--db", db_path, *args])


class TestCLIFlags:
    def test_since_7d(self, clean_db: str) -> None:
        result = _invoke(["--since", "7d"], clean_db)
        # Exit 0 with empty DB (renders the empty hint).
        assert result.exit_code == 0, result.output

    def test_from_to_validated(self, clean_db: str) -> None:
        # Valid ISO dates → ok.
        result = _invoke(["--from", "2026-04-01", "--to", "2026-05-06"], clean_db)
        assert result.exit_code == 0, result.output

    def test_from_invalid_date_rejected(self, clean_db: str) -> None:
        result = _invoke(["--from", "not-a-date"], clean_db)
        assert result.exit_code != 0
        assert "expected ISO" in result.output or "invalid date" in result.output

    def test_since_and_from_mutually_exclusive(self, clean_db: str) -> None:
        result = _invoke(
            ["--since", "7d", "--from", "2026-04-01"], clean_db,
        )
        assert result.exit_code != 0
        assert "mutually exclusive" in result.output

    def test_csv_and_json_mutually_exclusive(self, clean_db: str) -> None:
        result = _invoke(["--csv", "--json"], clean_db)
        assert result.exit_code != 0
        assert "mutually exclusive" in result.output

    def test_by_project_only(self, clean_db: str) -> None:
        result = _invoke(["--by", "project"], clean_db)
        assert result.exit_code == 0

    def test_by_model_only(self, clean_db: str) -> None:
        result = _invoke(["--by", "model"], clean_db)
        assert result.exit_code == 0

    def test_by_invalid_value_rejected(self, clean_db: str) -> None:
        result = _invoke(["--by", "garbage"], clean_db)
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# parse_since / parse_iso_date
# ---------------------------------------------------------------------------


class TestPeriodParsers:
    @pytest.mark.parametrize("s,n", [("7d", 7), ("30d", 30), ("1d", 1), ("90d", 90)])
    def test_parse_since(self, s: str, n: int) -> None:
        assert parse_since(s) == n

    @pytest.mark.parametrize("bad", ["7", "7days", "", "abc", "0d", "-1d"])
    def test_parse_since_rejects(self, bad: str) -> None:
        with pytest.raises(ValueError):
            parse_since(bad)

    def test_parse_iso_date(self) -> None:
        d = parse_iso_date("2026-05-06")
        assert d == datetime(2026, 5, 6, tzinfo=UTC)

    def test_parse_iso_date_rejects(self) -> None:
        with pytest.raises(ValueError):
            parse_iso_date("06/05/2026")


# ---------------------------------------------------------------------------
# --by suppresses the other table
# ---------------------------------------------------------------------------


class TestByFilter:
    def test_by_model_suppresses_by_project(self) -> None:
        rec = _rec(cost_millicents=10_000)
        c = _console()
        render_report(build_report_data([rec]), c, show_projects=False)
        out = c.export_text()
        assert "by model" in out
        assert "by project" not in out

    def test_by_project_suppresses_by_model(self) -> None:
        rec = _rec(cost_millicents=10_000)
        c = _console()
        render_report(build_report_data([rec]), c, show_models=False)
        out = c.export_text()
        assert "by project" in out
        assert "by model" not in out


# ---------------------------------------------------------------------------
# vs-previous Δ rendering
# ---------------------------------------------------------------------------


class TestVsPrevious:
    def test_delta_increase_renders(self) -> None:
        curr = [_rec(project="alpha", cost_millicents=20_000)]
        prev = [_rec(project="alpha", cost_millicents=10_000)]
        data = build_report_data(curr, prev_records=prev)
        c = _console()
        render_report(data, c, vs_previous=True)
        out = c.export_text()
        # +100% increase rendered with brand-orange Δ marker.
        assert "Δ" in out
        assert "+100" in out

    def test_delta_decrease_renders(self) -> None:
        curr = [_rec(project="alpha", cost_millicents=5_000)]
        prev = [_rec(project="alpha", cost_millicents=10_000)]
        data = build_report_data(curr, prev_records=prev)
        c = _console()
        render_report(data, c, vs_previous=True)
        out = c.export_text()
        assert "Δ" in out
        assert "-50" in out

    def test_no_prior_data_renders_em_dash(self) -> None:
        curr = [_rec(project="alpha", cost_millicents=5_000)]
        prev: list = []
        data = build_report_data(curr, prev_records=prev)
        c = _console()
        render_report(data, c, vs_previous=True)
        out = c.export_text()
        # Some Δ row with em-dash for "no prior".
        assert "—" in out


# ---------------------------------------------------------------------------
# Top-1 outlier accent
# ---------------------------------------------------------------------------


def test_top1_outlier_row_accented() -> None:
    r1 = _rec(project="alpha", cost_millicents=1_000)
    r2 = _rec(project="beta", cost_millicents=100_000)  # the outlier
    r3 = _rec(project="gamma", cost_millicents=10_000)
    c = _console()
    render_report(build_report_data([r1, r2, r3]), c)
    # Capture as ANSI to check styling.
    ansi = c.export_text(styles=True)
    # The accent uses brand-orange #ea7d2e + bold; Rich renders it as
    # an ANSI sequence that contains '234;125;46' (the RGB for #ea7d2e).
    # We don't pin the exact escape; just check that 'beta' appears in
    # the styled output adjacent to brand-orange-bold styling.
    assert "beta" in ansi
    # The styled export contains ANSI escape codes only when styling is
    # applied; ensure SOME styling is present near beta.
    assert "\x1b[" in ansi


def test_top1_skipped_when_vs_previous() -> None:
    # When --vs-previous is set we suppress the row accent. We can't
    # easily diff styles, so this is a smoke test that vs-previous
    # rendering doesn't crash with multiple rows.
    curr = [
        _rec(project="alpha", cost_millicents=1_000),
        _rec(project="beta", cost_millicents=100_000),
    ]
    prev = [
        _rec(project="alpha", cost_millicents=1_000),
        _rec(project="beta", cost_millicents=50_000),
    ]
    c = _console()
    render_report(
        build_report_data(curr, prev_records=prev),
        c,
        vs_previous=True,
    )
    out = c.export_text()
    assert "alpha" in out
    assert "beta" in out


# ---------------------------------------------------------------------------
# Tightened warnings
# ---------------------------------------------------------------------------


def test_tightened_warning_under_summary_full_footer() -> None:
    r1 = _rec(cost_millicents=10_000, tokens_complete=False)
    r2 = _rec(cost_millicents=None, model="weird-model")
    c = _console()
    render_report(build_report_data([r1, r2]), c)
    out = c.export_text()
    # Single-line warning under summary (just shy of the body).
    assert "see footer" in out
    # Full text in the footer block.
    assert "incomplete" in out
    assert "unrecognised model" in out


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------


def test_csv_round_trip() -> None:
    r1 = _rec(project="alpha", model="claude-haiku-4-5", cost_millicents=10_000)
    r2 = _rec(project="beta", model="claude-sonnet-4-6", cost_millicents=20_000)
    data = build_report_data([r1, r2])
    c, buf = _plain_console()
    render_csv(data, c)
    text = buf.getvalue()
    # Round-trip via DictReader.
    reader = csv.DictReader(io.StringIO(text))
    rows = list(reader)
    levels = {r["level"] for r in rows}
    assert levels == {"summary", "project", "model"}
    summary_row = next(r for r in rows if r["level"] == "summary")
    assert summary_row["cost_millicents"] == "30000"
    project_rows = [r for r in rows if r["level"] == "project"]
    assert {r["key"] for r in project_rows} == {"alpha", "beta"}


# ---------------------------------------------------------------------------
# JSON export
# ---------------------------------------------------------------------------


def test_json_export_shape() -> None:
    r1 = _rec(project="alpha", model="claude-haiku-4-5", cost_millicents=10_000)
    r2 = _rec(project="beta", model="claude-sonnet-4-6", cost_millicents=20_000)
    data = build_report_data([r1, r2])
    c, buf = _plain_console()
    render_json(data, c)
    payload = json.loads(buf.getvalue())
    assert set(payload.keys()) == {"summary", "by_project", "by_model"}
    assert payload["summary"]["cost_millicents"] == 30_000
    assert payload["summary"]["cost_usd"] == 0.3
    assert {p["project"] for p in payload["by_project"]} == {"alpha", "beta"}
    assert {m["model"] for m in payload["by_model"]} == {
        "claude-haiku-4-5", "claude-sonnet-4-6",
    }
