"""Proxy integration test for Wave 1A.ii cloud-sync field plumbing.

Drives a synthetic flow through ``HaltonAddon.request`` →
``HaltonAddon.response`` and asserts the new fields land on the
``LogRecord`` passed to ``StorageManager.write_record``.

Covers:

* ``request_kind`` / ``prompt_hash`` / ``idempotency_key`` are
  propagated from the Anthropic adapter's ``RequestMetadata`` onto
  the ``LogRecord``.
* ``source_machine`` is set from the addon's hostname snapshot.
* ``time_to_first_token_ms`` is computed from
  ``flow.response.timestamp_start - flow.request.timestamp_end`` when
  both are present.
* ``status`` is derived from the response code (``success`` for 2xx,
  ``error`` for 4xx/5xx).

The cardinal-rule promise ("never fail the request") is exercised by
the existing fail-open regressions in ``test_proxy_async_response``;
this file focuses purely on the new fields landing correctly.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter import cloud_fields
from halton_meter.cloud_fields import canonical_prompt_hash
from halton_meter.models import LogRecord
from halton_meter.proxy import HaltonAddon


def _build_flow(
    *,
    request_body: dict,
    response_body: dict,
    response_status: int = 200,
    idempotency_header: str | None = None,
    request_end_ts: float | None = 1000.0,
    response_start_ts: float | None = 1000.2,
) -> http.HTTPFlow:
    """Build a fully-shaped Anthropic flow with synthetic timestamps.

    The timestamp fields drive the time-to-first-token computation.
    Setting ``request_end_ts=1000.0`` and ``response_start_ts=1000.2``
    yields a TTFT of 200 ms.
    """
    req = tutils.treq(host="api.anthropic.com", port=443, path="/v1/messages")
    req.content = json.dumps(request_body).encode()
    if idempotency_header:
        req.headers["Anthropic-Idempotency-Key"] = idempotency_header
    flow = tflow.tflow(req=req)
    flow.id = str(uuid.uuid4())
    flow.response = http.Response.make(
        response_status,
        json.dumps(response_body).encode(),
        {"Content-Type": "application/json"},
    )
    # mitmproxy populates timestamps with the current wallclock when
    # tflow constructs the flow. Overwrite with the controlled values
    # (or set to None — the helper treats either side missing as
    # "TTFT not measurable").
    try:
        flow.request.timestamp_end = request_end_ts  # type: ignore[assignment]
        flow.response.timestamp_start = response_start_ts  # type: ignore[assignment]
    except (AttributeError, TypeError):
        # Older mitmproxy variants — skip and the TTFT helper will
        # return None, which other tests already cover.
        pass
    return flow


@pytest.fixture(autouse=True)
def _reset_hostname_cache() -> None:
    cloud_fields._reset_source_machine_cache_for_tests()
    yield
    cloud_fields._reset_source_machine_cache_for_tests()


@pytest.mark.asyncio
async def test_logrecord_carries_cloud_sync_fields(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Drive a happy-path Anthropic flow through the addon and assert
    every Wave 1A.ii field lands on the LogRecord."""

    request_body = {
        "model": "claude-haiku-4-5",
        "messages": [{"role": "user", "content": "hi"}],
        "max_tokens": 16,
    }
    expected_prompt_hash = canonical_prompt_hash(request_body)
    flow = _build_flow(
        request_body=request_body,
        response_body={
            "id": "msg_test",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": "ok"}],
            "model": "claude-haiku-4-5",
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 1, "output_tokens": 1},
        },
        idempotency_header="proxy-itest-1",
    )

    # Mock storage so we can inspect what write_record was called with
    # without booting a real SQLite. The addon writes via a chained
    # coroutine (``_write_record_then_body``) so we expose
    # ``write_record`` and ``write_body_record`` as AsyncMocks.
    fake_storage = AsyncMock()
    fake_storage.write_record = AsyncMock()
    fake_storage.write_body_record = AsyncMock()

    # Pin the hostname so the assertion is deterministic on any
    # machine running the test suite.
    monkeypatch.setattr(
        cloud_fields,
        "socket",
        type("M", (), {"gethostname": staticmethod(lambda: "itest-host")}),
    )
    cloud_fields._reset_source_machine_cache_for_tests()

    addon = HaltonAddon(storage=fake_storage)
    assert addon._source_machine == "itest-host"

    # Drive the request hook then the response hook.
    await addon.request(flow)
    await addon.response(flow)

    # The response hook schedules the write via asyncio.create_task —
    # yield to the loop so it runs.
    await asyncio.sleep(0)
    # If the task is still pending, give the loop another spin. The
    # _write_record_then_body coroutine awaits write_record before
    # write_body_record; one extra loop iteration is enough.
    for _ in range(3):
        if fake_storage.write_record.await_count:
            break
        await asyncio.sleep(0)

    assert fake_storage.write_record.await_count == 1
    written_record: LogRecord = fake_storage.write_record.await_args.args[0]

    # --- Wave 1A.ii field assertions -------------------------------------
    assert written_record.provider == "anthropic"
    assert written_record.model == "claude-haiku-4-5"
    assert written_record.request_kind == "chat"
    assert written_record.prompt_hash == expected_prompt_hash
    assert written_record.idempotency_key == "proxy-itest-1"
    assert written_record.source_machine == "itest-host"
    # 200ms TTFT from the synthetic timestamps on the flow.
    assert written_record.time_to_first_token_ms == 200
    assert written_record.status == "success"


@pytest.mark.asyncio
async def test_error_response_status_is_error(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A 4xx/5xx response must surface as status='error'."""
    flow = _build_flow(
        request_body={
            "model": "claude-haiku-4-5",
            "messages": [{"role": "user", "content": "hi"}],
        },
        response_body={
            "type": "error",
            "error": {"type": "overloaded_error", "message": "down"},
        },
        response_status=529,
    )

    fake_storage = AsyncMock()
    fake_storage.write_record = AsyncMock()
    fake_storage.write_body_record = AsyncMock()

    addon = HaltonAddon(storage=fake_storage)
    await addon.request(flow)
    await addon.response(flow)
    for _ in range(3):
        if fake_storage.write_record.await_count:
            break
        await asyncio.sleep(0)

    if fake_storage.write_record.await_count == 0:
        # Anthropic's parse_response treats unknown-model + zero-token
        # bodies as "skip this row" (returns None). The error fixture
        # passes the request body's model field so we still get a row.
        pytest.fail("Expected a record write for a 529 error flow")
    written: LogRecord = fake_storage.write_record.await_args.args[0]
    assert written.status == "error"


@pytest.mark.asyncio
async def test_missing_timestamps_leave_ttft_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the flow has no usable timestamps, TTFT is None — never
    a fabricated value."""
    flow = _build_flow(
        request_body={
            "model": "claude-haiku-4-5",
            "messages": [{"role": "user", "content": "hi"}],
        },
        response_body={
            "id": "msg_test",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": "ok"}],
            "model": "claude-haiku-4-5",
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 1, "output_tokens": 1},
        },
        request_end_ts=None,
        response_start_ts=None,
    )

    fake_storage = AsyncMock()
    fake_storage.write_record = AsyncMock()
    fake_storage.write_body_record = AsyncMock()

    addon = HaltonAddon(storage=fake_storage)
    await addon.request(flow)
    await addon.response(flow)
    for _ in range(3):
        if fake_storage.write_record.await_count:
            break
        await asyncio.sleep(0)

    written: LogRecord = fake_storage.write_record.await_args.args[0]
    assert written.time_to_first_token_ms is None
