"""
Tests for halton_meter.setup — cert generation, keychain trust, certifi patch.

Tests use temporary directories and mock subprocess calls — no actual system
modifications are made.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from halton_meter.setup import (
    CERTIFI_MARKER,
    StepStatus,
    _is_cert_trusted_macos,
    _is_certifi_patched,
    _verify_cert_trust_macos_raw,
    check_steps,
    generate_mitmproxy_cert,
    patch_certifi,
    render_result,
    run_setup,
    trust_cert_macos,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FAKE_CERT_PEM = """\
-----BEGIN CERTIFICATE-----
MIIDFakeCertDataForTestingOnly==
-----END CERTIFICATE-----
"""


def _write_fake_cert(path: Path) -> None:
    """Write a minimal PEM stub to the given path."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(FAKE_CERT_PEM, encoding="utf-8")


# ---------------------------------------------------------------------------
# generate_mitmproxy_cert
# ---------------------------------------------------------------------------


class TestGenerateCert:
    def test_skips_if_cert_exists(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        with patch("halton_meter.setup._macos.MITMPROXY_CERT_PATH", fake_cert):
            result = generate_mitmproxy_cert(force=False)

        assert result.done is True
        assert "Already exists" in result.note

    def test_force_reruns_even_if_exists(self, tmp_path: Path) -> None:
        """With force=True the CertStore code path is hit; we mock it out."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        mock_cert_store = MagicMock()

        def _create_store_side_effect(ca_dir: Path, name: str, bits: int) -> None:
            # Simulate CertStore creating the cert
            pass

        mock_cert_store.create_store = _create_store_side_effect

        with (
            patch("halton_meter.setup._macos.MITMPROXY_CERT_PATH", fake_cert),
            patch("halton_meter.setup._macos.CertStore", mock_cert_store, create=True),
        ):
            # Import after patching so the attribute is visible
            import halton_meter.setup as setup_mod

            orig = setup_mod._macos.MITMPROXY_CERT_PATH
            setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
            try:
                result = generate_mitmproxy_cert(force=True)
            finally:
                setup_mod._macos.MITMPROXY_CERT_PATH = orig

        # If CertStore runs and cert still exists → done
        assert result.done is True

    def test_certstore_exception_returns_not_done(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        # Cert does NOT exist; CertStore will raise

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert

        try:
            with patch("mitmproxy.certs.CertStore.create_store", side_effect=RuntimeError("boom")):
                result = generate_mitmproxy_cert(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is False
        assert "Failed" in result.note or "Not found" in result.note or "boom" in result.note


# ---------------------------------------------------------------------------
# _is_cert_trusted_macos / _verify_cert_trust_macos_raw
# ---------------------------------------------------------------------------


class TestIsCertTrustedMacos:
    """
    Three-state coverage matching the v0.1.3 cert-trust spike (Phase 1):

      * S1 — cert in keychain + admin-trusted: rc=0 -> trusted=True
      * S2 — cert in keychain, NOT trusted:    rc=1 -> trusted=False
      * S3 — cert missing:                     no subprocess call, trusted=False
    """

    def test_s1_cert_present_and_trusted_returns_true(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch(
                "subprocess.run",
                return_value=MagicMock(
                    returncode=0,
                    stdout="...certificate verification successful...\n",
                    stderr="",
                ),
            ) as mock_run:
                assert _is_cert_trusted_macos() is True
            # Confirm we used verify-cert WITHOUT -r and WITHOUT find-certificate.
            args = mock_run.call_args.args[0]
            assert args[0] == "security"
            assert args[1] == "verify-cert"
            assert "-r" not in args, "must NOT pass -r <self> (tautological for self-signed CAs)"
            assert "find-certificate" not in args, "find-certificate pre-filter dropped in v0.1.3"
            assert "-p" in args and args[args.index("-p") + 1] == "ssl"
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

    def test_s2_cert_present_but_not_trusted_returns_false(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch(
                "subprocess.run",
                return_value=MagicMock(
                    returncode=1,
                    stdout="",
                    stderr="...not trusted...\n",
                ),
            ):
                assert _is_cert_trusted_macos() is False
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

    def test_s3_cert_missing_short_circuits_without_subprocess(self, tmp_path: Path) -> None:
        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = tmp_path / "missing.pem"
        try:
            with patch("subprocess.run") as mock_run:
                assert _is_cert_trusted_macos() is False
            mock_run.assert_not_called()
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

    def test_subprocess_error_is_fail_closed(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("subprocess.run", side_effect=FileNotFoundError("security: not found")):
                assert _is_cert_trusted_macos() is False
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig


class TestVerifyCertTrustMacosRaw:
    """Raw helper used by `halton-meter doctor` to surface tool output."""

    def test_returns_rc_stdout_stderr_on_success(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch(
                "subprocess.run",
                return_value=MagicMock(returncode=0, stdout="ok-stdout", stderr="ok-stderr"),
            ):
                rc, stdout, stderr = _verify_cert_trust_macos_raw()
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert rc == 0
        assert stdout == "ok-stdout"
        assert stderr == "ok-stderr"

    def test_returns_minus_one_on_file_not_found(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("subprocess.run", side_effect=FileNotFoundError("no security")):
                rc, stdout, stderr = _verify_cert_trust_macos_raw()
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert rc == -1
        assert stdout == ""
        assert "no security" in stderr

    def test_returns_minus_one_on_timeout(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            import subprocess

            with patch(
                "subprocess.run",
                side_effect=subprocess.TimeoutExpired(cmd=["security"], timeout=10),
            ):
                rc, _stdout, stderr = _verify_cert_trust_macos_raw()
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert rc == -1
        assert "10" in stderr or "timeout" in stderr.lower() or "TimeoutExpired" in stderr


# ---------------------------------------------------------------------------
# trust_cert_macos
# ---------------------------------------------------------------------------


class TestTrustCertMacos:
    def test_skips_if_cert_not_found(self, tmp_path: Path) -> None:
        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = tmp_path / "missing.pem"
        try:
            result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is False
        assert "step 1" in result.note.lower() or "not found" in result.note.lower()

    def test_skips_if_already_trusted(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=True):
                result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is True
        assert "Already trusted" in result.note

    def test_security_command_success(self, tmp_path: Path) -> None:
        """v0.1.4 (2B.15) P0-2: when osascript is unavailable, falls back
        to plain sudo subprocess and reports success."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=False),
                patch("halton_meter.setup._macos._osascript_available", return_value=False),
                patch(
                    "subprocess.run",
                    return_value=MagicMock(returncode=0, stderr="", stdout=""),
                ),
            ):
                result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is True
        assert "Added" in result.note

    def test_security_command_failure_shows_manual_instruction(self, tmp_path: Path) -> None:
        """If security fails (e.g. no sudo), a clear manual command must be printed."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=False),
                patch("halton_meter.setup._macos._osascript_available", return_value=False),
                patch(
                    "subprocess.run",
                    return_value=MagicMock(
                        returncode=1,
                        stderr="sudo: a password is required",
                        stdout="",
                    ),
                ),
            ):
                result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is False
        # Must contain the manual command to run
        assert "security add-trusted-cert" in result.note
        # Must not crash
        assert "sudo" in result.note

    def test_security_command_not_found_returns_not_done(self, tmp_path: Path) -> None:
        """FileNotFoundError (security not available) must be handled gracefully."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=False),
                patch("halton_meter.setup._macos._osascript_available", return_value=False),
                patch("subprocess.run", side_effect=FileNotFoundError("security not found")),
            ):
                result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is False
        assert "not found" in result.note.lower() or "security" in result.note.lower()

    # --------------------------------------------------------------------- #
    # v0.1.4 (2B.15) P0-2: osascript GUI admin dialog                        #
    # --------------------------------------------------------------------- #

    def test_osascript_path_succeeds_without_sudo(self, tmp_path: Path) -> None:
        """When osascript is available and the dialog completes, the cert
        is trusted via the GUI admin path — no terminal sudo prompt.

        This is the new-user happy path: ``halton-meter init`` cold on
        a clean Mac pops the standard "halton-meter wants to make
        changes" dialog and proceeds when the user types their password
        into the GUI.
        """
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert

        run_with_admin_calls: list[tuple[tuple, dict]] = []
        sudo_run_calls: list[tuple] = []

        def fake_run_with_admin(argv, *, prompt_reason):
            run_with_admin_calls.append((tuple(argv), {"prompt_reason": prompt_reason}))
            from subprocess import CompletedProcess
            return CompletedProcess(args=argv, returncode=0, stdout="", stderr="")

        def fake_subprocess_run(*args, **kwargs):
            sudo_run_calls.append(args)
            from subprocess import CompletedProcess
            return CompletedProcess(args=args, returncode=0, stdout="", stderr="")

        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=False),
                patch("halton_meter.setup._macos._osascript_available", return_value=True),
                patch(
                    "halton_meter.system_proxy.run_with_admin",
                    side_effect=fake_run_with_admin,
                ),
                patch("subprocess.run", side_effect=fake_subprocess_run),
            ):
                result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is True
        # Confirms the osascript path was taken: run_with_admin was
        # called and the message mentions the GUI dialog.
        assert run_with_admin_calls, "run_with_admin must be invoked first"
        assert "admin dialog" in result.note.lower()
        # The fallback sudo subprocess.run must NOT have been called.
        # (Tests are isolated: the fixture only patches subprocess.run
        # globally; verify no call was made.)
        assert sudo_run_calls == [], (
            "fallback sudo path must not run when osascript succeeds"
        )

    def test_osascript_user_cancel_reports_clear_message(self, tmp_path: Path) -> None:
        """If the user cancels the osascript admin dialog, do NOT fall
        through to terminal sudo (which would also fail with no
        password). Surface a clear "you cancelled the dialog" message
        instead so the user knows what to do."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert

        sudo_run_calls: list[tuple] = []

        from halton_meter.system_proxy import AdminCancelledError

        def cancel_dialog(*args, **kwargs):
            # v0.1.5 (2B.16) P1-AUDIT-4: typed exception. Plain
            # RuntimeError no longer triggers the cancel branch (now
            # AdminCancelledError specifically).
            raise AdminCancelledError("admin password dialog cancelled by user")

        def fake_subprocess_run(*args, **kwargs):
            sudo_run_calls.append(args)
            from subprocess import CompletedProcess
            return CompletedProcess(args=args, returncode=0, stdout="", stderr="")

        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=False),
                patch("halton_meter.setup._macos._osascript_available", return_value=True),
                patch(
                    "halton_meter.system_proxy.run_with_admin",
                    side_effect=cancel_dialog,
                ),
                patch("subprocess.run", side_effect=fake_subprocess_run),
            ):
                result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is False
        assert "cancel" in result.note.lower()
        assert "Re-run" in result.note
        # Did NOT fall through to terminal sudo on cancel.
        assert sudo_run_calls == [], (
            "user-cancel must not silently retry via terminal sudo"
        )

    def test_osascript_failure_falls_through_to_sudo(self, tmp_path: Path) -> None:
        """When the osascript dialog fails for a non-cancel reason
        (e.g. macOS version quirk where osascript's `do shell script`
        path is broken), fall through to the terminal sudo path."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)

        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert

        sudo_run_calls: list[list[str]] = []

        def fake_subprocess_run(argv, *args, **kwargs):
            sudo_run_calls.append(list(argv))
            from subprocess import CompletedProcess
            return CompletedProcess(args=argv, returncode=0, stdout="", stderr="")

        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=False),
                patch("halton_meter.setup._macos._osascript_available", return_value=True),
                patch(
                    "halton_meter.system_proxy.run_with_admin",
                    side_effect=RuntimeError("osascript: AppleScript syntax error"),
                ),
                patch("subprocess.run", side_effect=fake_subprocess_run),
            ):
                result = trust_cert_macos(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is True
        # Fell through to sudo and succeeded.
        assert sudo_run_calls, "sudo fallback must run when osascript errors out"
        assert sudo_run_calls[0][0] == "sudo", (
            f"expected sudo argv; got {sudo_run_calls[0]}"
        )


# ---------------------------------------------------------------------------
# patch_certifi
# ---------------------------------------------------------------------------


class TestPatchCertifi:
    def test_skips_if_cert_not_found(self, tmp_path: Path) -> None:
        import halton_meter.setup as setup_mod

        orig = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = tmp_path / "missing.pem"
        try:
            result = patch_certifi(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig

        assert result.done is False

    def test_skips_if_already_patched(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        # Create a fake certifi bundle that already contains the marker
        bundle = tmp_path / "cacert.pem"
        bundle.write_text(f"existing certs\n{CERTIFI_MARKER}\n{FAKE_CERT_PEM}", encoding="utf-8")

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
                result = patch_certifi(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        assert result.done is True
        assert "Already patched" in result.note

    def test_appends_cert_when_not_patched(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        # Bundle without the marker
        bundle = tmp_path / "cacert.pem"
        bundle.write_text("existing certs\n", encoding="utf-8")

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
                result = patch_certifi(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        assert result.done is True
        content = bundle.read_text(encoding="utf-8")
        assert CERTIFI_MARKER in content
        assert FAKE_CERT_PEM.strip() in content

    def test_force_repatches_already_patched_bundle(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        bundle = tmp_path / "cacert.pem"
        bundle.write_text(f"existing\n{CERTIFI_MARKER}\n{FAKE_CERT_PEM}", encoding="utf-8")

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
                result = patch_certifi(force=True)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        # force=True should still succeed (appends again)
        assert result.done is True

    def test_repatches_when_marker_present_but_cert_body_drifted(
        self, tmp_path: Path
    ) -> None:
        """P0-2 idempotency contract: marker line present alone is not
        sufficient — if the cert body has drifted (cert rotated), patch
        re-runs to bring the bundle up to date."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        new_cert_body = (
            "-----BEGIN CERTIFICATE-----\n"
            "ROTATED_CERT_BODY_DIFFERENT_FROM_OLD\n"
            "-----END CERTIFICATE-----\n"
        )
        fake_cert.write_text(new_cert_body, encoding="utf-8")

        # Bundle has the marker but contains an OLD (different) cert body.
        bundle = tmp_path / "cacert.pem"
        bundle.write_text(
            f"existing\n{CERTIFI_MARKER}\n{FAKE_CERT_PEM}", encoding="utf-8"
        )

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
                result = patch_certifi(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        # Force=False but cert drifted -> patch must re-run.
        assert result.done is True
        bundle_text = bundle.read_text(encoding="utf-8")
        assert "ROTATED_CERT_BODY_DIFFERENT_FROM_OLD" in bundle_text

    def test_skips_when_marker_present_and_cert_body_matches(
        self, tmp_path: Path
    ) -> None:
        """P0-2 idempotency contract: when marker AND cert body are both
        present, patch is a no-op. mtime is stable across the call."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        bundle = tmp_path / "cacert.pem"
        bundle.write_text(
            f"existing certs\n{CERTIFI_MARKER}\n{FAKE_CERT_PEM}", encoding="utf-8"
        )
        mtime_before = bundle.stat().st_mtime_ns

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
                result = patch_certifi(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        assert result.done is True
        assert "Already patched" in result.note
        # No write happened -> mtime unchanged.
        assert bundle.stat().st_mtime_ns == mtime_before

    def test_marker_and_cert_body_present_identifies_patched_bundle(
        self, tmp_path: Path
    ) -> None:
        """v0.1.3 P0-2: marker AND cert body must both be present to count
        as 'already patched' (idempotency contract — drift is detected)."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        bundle = tmp_path / "cacert.pem"
        bundle.write_text(
            f"certs\n{CERTIFI_MARKER}\n{FAKE_CERT_PEM}", encoding="utf-8"
        )

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
                assert _is_certifi_patched() is True
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

    def test_marker_only_without_cert_body_returns_false(
        self, tmp_path: Path
    ) -> None:
        """v0.1.3 P0-2: marker present but cert body missing/drifted ->
        not patched (re-run will append the current cert body)."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        bundle = tmp_path / "cacert.pem"
        bundle.write_text(f"certs\n{CERTIFI_MARKER}\n", encoding="utf-8")

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
                assert _is_certifi_patched() is False
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

    def test_marker_detection_returns_false_for_unpatched_bundle(
        self, tmp_path: Path
    ) -> None:
        bundle = tmp_path / "cacert.pem"
        bundle.write_text("just regular certs\n", encoding="utf-8")
        with patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle):
            assert _is_certifi_patched() is False


# ---------------------------------------------------------------------------
# check_steps
# ---------------------------------------------------------------------------


class TestCheckSteps:
    def test_check_all_done(self, tmp_path: Path) -> None:
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        bundle = tmp_path / "cacert.pem"
        # P0-2: bundle must contain marker AND current cert body.
        bundle.write_text(
            f"certs\n{CERTIFI_MARKER}\n{FAKE_CERT_PEM}", encoding="utf-8"
        )

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=True),
                patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle),
                patch("halton_meter.setup._macos._is_macos", return_value=True),
            ):
                result = check_steps()
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        assert result.cert_generated.done is True
        assert result.cert_trusted.done is True
        assert result.certifi_patched.done is True
        assert result.all_done() is True

    def test_check_nothing_done(self, tmp_path: Path) -> None:
        missing_cert = tmp_path / "missing.pem"
        bundle = tmp_path / "cacert.pem"
        bundle.write_text("no marker here\n", encoding="utf-8")

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = missing_cert
        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=False),
                patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle),
                patch("halton_meter.setup._macos._is_macos", return_value=True),
            ):
                result = check_steps()
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        assert result.cert_generated.done is False
        assert result.cert_trusted.done is False
        assert result.certifi_patched.done is False
        assert result.all_done() is False


# ---------------------------------------------------------------------------
# run_setup — idempotent path (all steps already done)
# ---------------------------------------------------------------------------


class TestRunSetup:
    def test_idempotent_when_all_done(self, tmp_path: Path) -> None:
        """run_setup with no force should skip all steps when already complete."""
        fake_cert = tmp_path / "mitmproxy-ca-cert.pem"
        _write_fake_cert(fake_cert)
        bundle = tmp_path / "cacert.pem"
        bundle.write_text(f"certs\n{CERTIFI_MARKER}\n{FAKE_CERT_PEM}", encoding="utf-8")

        import halton_meter.setup as setup_mod

        orig_cert = setup_mod._macos.MITMPROXY_CERT_PATH
        setup_mod._macos.MITMPROXY_CERT_PATH = fake_cert
        try:
            with (
                patch("halton_meter.setup._macos._is_cert_trusted_macos", return_value=True),
                patch("halton_meter.setup._macos._certifi_bundle_path", return_value=bundle),
                patch("halton_meter.setup._macos._is_macos", return_value=True),
            ):
                result = run_setup(force=False)
        finally:
            setup_mod._macos.MITMPROXY_CERT_PATH = orig_cert

        assert result.cert_generated.done is True
        assert "Already exists" in result.cert_generated.note
        assert result.cert_trusted.done is True
        assert "Already trusted" in result.cert_trusted.note
        assert result.certifi_patched.done is True
        assert "Already patched" in result.certifi_patched.note


# ---------------------------------------------------------------------------
# render_result — smoke test
# ---------------------------------------------------------------------------


class TestRenderResult:
    def test_renders_without_crash(self) -> None:
        from rich.console import Console

        from halton_meter.setup import SetupResult

        result = SetupResult(
            cert_generated=StepStatus("Generate CA cert", done=True, note="OK"),
            cert_trusted=StepStatus("Trust in keychain", done=False, note="no sudo"),
            certifi_patched=StepStatus("Patch certifi", done=True, note="patched"),
        )
        c = Console(record=True, width=100)
        render_result(result, c)
        output = c.export_text()
        # v0.1.22.17: success glyph swapped from ✓ to ● to match the
        # brand-orange step-row convention; failure glyph unchanged.
        assert "●" in output or "✗" in output
        assert "Generate CA cert" in output
        assert "Trust in keychain" in output
        assert "Patch certifi" in output
