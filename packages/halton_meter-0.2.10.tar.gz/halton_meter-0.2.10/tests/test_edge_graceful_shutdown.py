"""v0.1.22.18 Fix 1: edge graceful shutdown — cancel in-flight tunnels.

Pre-fix, ``EdgeProxy.stop()`` closed the listener but did NOT cancel
per-connection handler tasks already running for active CONNECT
tunnels. On legitimate SIGTERM (e.g. ``halton-meter uninstall`` /
machine shutdown sending the edge process SIGTERM via launchd), the
asyncio event loop closed with these tasks pending and surfaced the
``Task was destroyed but it is pending`` runtime warning into
``edge.err.log`` on every shutdown.

These tests verify:

1. ``cancel_inflight()`` cancels all active handlers and they unwind
   cleanly through the new ``CancelledError`` exits in
   ``_handle_connection`` and ``_shuttle_one_way``.
2. After cancellation, no task remains in the inflight set.
3. The asyncio loop closes without surfacing
   ``Task was destroyed but it is pending`` warnings.
4. The unrelated B4 invariant (the daemon's ``stop`` lifecycle does
   NOT signal connected clients) is not affected — this fix is in the
   edge's OWN shutdown sequence.
"""

from __future__ import annotations

import asyncio
import warnings

import pytest

from halton_meter.edge import EdgeConfig, EdgeProxy


@pytest.mark.asyncio
async def test_cancel_inflight_drains_active_handler_tasks() -> None:
    """An open CONNECT tunnel is cancelled cleanly by ``cancel_inflight``."""
    config = EdgeConfig(edge_port=0, internal_port=1, probe_port=1)
    proxy = EdgeProxy(config)
    bound_port = await proxy.start()
    serve_task = asyncio.create_task(proxy.serve_forever())

    # Open a connection that will sit in _handle_connection waiting for
    # a request line — that's an in-flight handler.
    _reader, writer = await asyncio.open_connection("127.0.0.1", bound_port)
    # Yield long enough for the handler task to register itself.
    for _ in range(20):
        await asyncio.sleep(0.005)
        if proxy._active_handler_tasks:
            break
    assert len(proxy._active_handler_tasks) >= 1, (
        "handler task must register itself in _active_handler_tasks"
    )

    # Drive the legitimate shutdown sequence the same way ``run_edge``
    # does: stop the listener, then cancel inflight, then unwind.
    await proxy.cancel_inflight()
    await proxy.stop()

    # All registered tasks must be done after cancellation.
    assert all(t.done() for t in list(proxy._active_handler_tasks))
    # The set has been drained by the handlers' ``finally`` discards.
    assert proxy._active_handler_tasks == set()

    serve_task.cancel()
    try:
        await serve_task
    except asyncio.CancelledError:
        pass

    writer.close()
    try:
        await writer.wait_closed()
    except (ConnectionResetError, BrokenPipeError, OSError):
        pass


@pytest.mark.asyncio
async def test_cancel_inflight_idempotent_when_no_tasks() -> None:
    """Calling ``cancel_inflight`` with no in-flight tasks is a no-op."""
    config = EdgeConfig(edge_port=0)
    proxy = EdgeProxy(config)
    await proxy.start()
    # No clients have connected — set is empty.
    assert proxy._active_handler_tasks == set()
    await proxy.cancel_inflight()  # must not raise
    await proxy.stop()


@pytest.mark.asyncio
async def test_shutdown_emits_no_pending_task_warning() -> None:
    """Full shutdown of the edge with an active tunnel emits zero
    'Task was destroyed but it is pending' warnings.

    This is the exact diagnostic that surfaced in edge.err.log
    pre-fix. Filter the warnings we capture so unrelated
    DeprecationWarnings from third-party imports don't fail this.
    """
    config = EdgeConfig(edge_port=0, internal_port=1, probe_port=1)
    proxy = EdgeProxy(config)
    bound_port = await proxy.start()
    serve_task = asyncio.create_task(proxy.serve_forever())

    _reader, writer = await asyncio.open_connection("127.0.0.1", bound_port)
    for _ in range(20):
        await asyncio.sleep(0.005)
        if proxy._active_handler_tasks:
            break

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        # Cancel inflight BEFORE stop — see ``run_edge`` for the
        # rationale (Server.wait_closed waits for handlers to finish).
        await proxy.cancel_inflight()
        await proxy.stop()
        serve_task.cancel()
        try:
            await serve_task
        except asyncio.CancelledError:
            pass
        writer.close()
        try:
            await writer.wait_closed()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        # Yield the loop so any deferred __del__ on tasks runs now.
        for _ in range(5):
            await asyncio.sleep(0)

    pending_warnings = [
        w for w in caught if "pending" in str(w.message).lower()
    ]
    assert pending_warnings == [], (
        "no 'Task was destroyed but it is pending' warning expected; "
        f"got {[str(w.message) for w in pending_warnings]}"
    )


@pytest.mark.asyncio
async def test_handler_task_deregisters_on_clean_completion() -> None:
    """A handler task that exits normally (bad request) must remove
    itself from ``_active_handler_tasks`` so the set doesn't grow
    unbounded over the edge's lifetime."""
    config = EdgeConfig(edge_port=0)
    proxy = EdgeProxy(config)
    bound_port = await proxy.start()
    serve_task = asyncio.create_task(proxy.serve_forever())

    # Send malformed bytes — the edge replies 400 and closes.
    reader, writer = await asyncio.open_connection("127.0.0.1", bound_port)
    writer.write(b"NOT_A_VALID_REQUEST_LINE\r\n\r\n")
    await writer.drain()
    # Read the 400 response, then EOF.
    try:
        await asyncio.wait_for(reader.read(), timeout=1.0)
    except TimeoutError:
        pass
    writer.close()
    try:
        await writer.wait_closed()
    except (ConnectionResetError, BrokenPipeError, OSError):
        pass

    # Yield enough cycles for the handler task to finish and discard.
    for _ in range(20):
        await asyncio.sleep(0.005)
        if not proxy._active_handler_tasks:
            break
    assert proxy._active_handler_tasks == set(), (
        "handler must deregister itself on clean exit; otherwise the "
        "set grows unbounded across millions of connections"
    )

    await proxy.stop()
    serve_task.cancel()
    try:
        await serve_task
    except asyncio.CancelledError:
        pass
