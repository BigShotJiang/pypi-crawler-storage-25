"""
Unit tests for halton_meter.attribution_store.

Covers the SQLite-backed attribution store that replaced the v0.1.13
in-memory cache after the 2026-05-01 production-bug fix:

* write/lookup round-trip persists across the singleton path so the
  edge process and the daemon process — which open independent
  connections to the same SQLite file — see each other's writes.
* TTL is NOT enforced on lookup (v0.2.3): a row in the table is a
  hit regardless of ``created_at``. Long-lived Claude Code CONNECT
  tunnels (hours) must stay attributed for the life of the socket;
  the pre-v0.2.3 5-minute read-side filter produced 2,193 misc-tagged
  rows in production. See ``memory/decisions.md`` 2026-05-18.
* ``evict_stale`` deletes rows older than the threshold; rows newer
  than the threshold survive. Bounded write-side TTL is the
  table-size guard; read-side does not gate hits.
* Concurrent writes from many threads each land cleanly under
  ``BEGIN IMMEDIATE`` + WAL — the production load profile from the
  brief.
* Schema bootstrap is idempotent: re-opening the DB after the table
  exists doesn't error.
* ``set_db_path`` swaps the singleton; resetting to None disarms it.
* Failures (sqlite3 errors, missing path) are swallowed: ``write``
  returns silently, ``lookup`` returns None.
"""

from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

from halton_meter import attribution_store
from halton_meter.attribution_store import (
    DEFAULT_MAX_AGE_SECONDS,
)


@pytest.fixture(autouse=True)
def _isolate_singleton(tmp_path: Path):
    """Wire each test to a fresh SQLite file, reset on teardown.

    The store's singleton is module-level by design — the production
    daemon and edge processes have a single path each. Tests must
    reset between runs so a stale path can't leak.
    """
    attribution_store.set_db_path(tmp_path / "attrib.sqlite")
    yield
    attribution_store.set_db_path(None)


# --------------------------------------------------------------------------- #
# write / lookup round-trip                                                   #
# --------------------------------------------------------------------------- #


def test_write_then_lookup_roundtrip() -> None:
    """A written value is returned by lookup within the TTL window."""
    attribution_store.write(54321, "staffhub")
    assert attribution_store.lookup(54321) == ("staffhub", None)


def test_lookup_missing_returns_none() -> None:
    """lookup on an unknown port returns None."""
    assert attribution_store.lookup(99999) is None


def test_overwrite_of_existing_port() -> None:
    """Writing the same port twice overwrites; last value wins."""
    attribution_store.write(54321, "alpha")
    attribution_store.write(54321, "beta")
    assert attribution_store.lookup(54321) == ("beta", None)


def test_persistence_across_singleton_reset(tmp_path: Path) -> None:
    """A lookup re-finds rows after re-pointing the singleton at the same file.

    This is the critical cross-process invariant — the edge and the
    daemon each wire the singleton in their own address space, both
    pointing at the same on-disk file. We model that here by
    re-pointing at the same path: the row written before the reset
    must still be visible after.
    """
    db = tmp_path / "shared.sqlite"
    attribution_store.set_db_path(db)
    attribution_store.write(60000, "shared-project")

    # Simulate the daemon process: a fresh wiring at the same path.
    attribution_store.set_db_path(None)
    attribution_store.set_db_path(db)
    assert attribution_store.lookup(60000) == ("shared-project", None)


def test_lookup_returns_none_when_unwired() -> None:
    """An unwired singleton looks up nothing — never raises."""
    attribution_store.set_db_path(None)
    assert attribution_store.lookup(1) is None


def test_write_when_unwired_is_silent() -> None:
    """Writing when no path is set is a no-op, not an error."""
    attribution_store.set_db_path(None)
    # Must not raise.
    attribution_store.write(1, "noop")
    # And no row materialises anywhere we can find.
    assert attribution_store.lookup(1) is None


# --------------------------------------------------------------------------- #
# TTL on the read path is intentionally absent (v0.2.3)                       #
# --------------------------------------------------------------------------- #


def test_lookup_returns_row_older_than_default_ttl(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A row older than ``DEFAULT_MAX_AGE_SECONDS`` is STILL a hit.

    v0.2.3 regression guard. Pre-v0.2.3 ``lookup`` filtered by
    ``created_at >= now - max_age_s``, which broke attribution for
    long-lived CONNECT tunnels (Claude Code holds them open for
    hours). The read-side TTL is gone; only the write-side eviction
    + the explicit prune loop bound the table.
    """
    import halton_meter.attribution_store as store_mod

    # Write at t=1000, look up at t=1000 + 24h. Row is in the DB; we
    # expect the hit.
    times = iter([1000.0, 1000.0 + 24 * 3600.0])

    def _now() -> float:
        try:
            return next(times)
        except StopIteration:
            return 1000.0 + 48 * 3600.0

    monkeypatch.setattr(store_mod.time, "time", _now)
    attribution_store.write(7777, "long-lived-tunnel")
    # 24 hours later — pre-v0.2.3 this returned None. Now: hit.
    assert attribution_store.lookup(7777) == ("long-lived-tunnel", None)


def test_lookup_within_max_age_hits(monkeypatch: pytest.MonkeyPatch) -> None:
    """A row written moments ago is returned (sanity)."""
    import halton_meter.attribution_store as store_mod

    times = iter([2000.0, 2000.5])

    def _now() -> float:
        try:
            return next(times)
        except StopIteration:
            return 2000.5

    monkeypatch.setattr(store_mod.time, "time", _now)
    attribution_store.write(8888, "fresh")
    assert attribution_store.lookup(8888) == ("fresh", None)


def test_lookup_max_age_s_arg_is_accepted_but_ignored(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``max_age_s=`` is preserved on the signature but has no effect.

    Callers in the codebase and tests still pass it; v0.2.3 removed
    the read-side filtering but kept the parameter so no caller has
    to be updated synchronously. A row older than the passed
    ``max_age_s`` MUST still hit.
    """
    import halton_meter.attribution_store as store_mod

    times = iter([3000.0, 3010.0])

    def _now() -> float:
        try:
            return next(times)
        except StopIteration:
            return 3010.0

    monkeypatch.setattr(store_mod.time, "time", _now)
    attribution_store.write(9999, "ten-seconds-ago")
    # max_age_s=5.0 would, pre-v0.2.3, return None. Post-fix: still a hit.
    assert attribution_store.lookup(9999, max_age_s=5.0) == ("ten-seconds-ago", None)
    # And the default-arg path still hits.
    assert attribution_store.lookup(9999) == ("ten-seconds-ago", None)


# --------------------------------------------------------------------------- #
# evict_stale                                                                 #
# --------------------------------------------------------------------------- #


def test_evict_stale_deletes_old_rows(monkeypatch: pytest.MonkeyPatch) -> None:
    """Rows older than max_age_s are deleted on evict_stale."""
    import halton_meter.attribution_store as store_mod

    # Write at t=0; evict at t=horizon+1; both rows must be gone.
    times = iter([0.0, 0.0, DEFAULT_MAX_AGE_SECONDS + 1.0])

    def _now() -> float:
        try:
            return next(times)
        except StopIteration:
            return DEFAULT_MAX_AGE_SECONDS + 1.0

    monkeypatch.setattr(store_mod.time, "time", _now)
    attribution_store.write(1, "old-1")
    attribution_store.write(2, "old-2")
    # Now the clock is at horizon+1; evict should delete both.
    deleted = attribution_store.evict_stale()
    assert deleted == 2
    # Reset clock for the lookups (they call time.time too).
    monkeypatch.setattr(store_mod.time, "time", lambda: DEFAULT_MAX_AGE_SECONDS + 2.0)
    assert attribution_store.lookup(1) is None
    assert attribution_store.lookup(2) is None


def test_evict_stale_leaves_fresh_rows() -> None:
    """Rows newer than the horizon survive eviction."""
    attribution_store.write(1, "fresh")
    deleted = attribution_store.evict_stale(max_age_s=300.0)
    assert deleted == 0
    assert attribution_store.lookup(1) == ("fresh", None)


def test_evict_stale_when_unwired_returns_zero() -> None:
    """Eviction without a wired path returns 0, never raises."""
    attribution_store.set_db_path(None)
    assert attribution_store.evict_stale() == 0


# --------------------------------------------------------------------------- #
# v0.2.3 prune-loop max-age — system-level closure of Mode 1                  #
# --------------------------------------------------------------------------- #
#
# These tests pin the actual integration between the daemon's prune loop and
# ``evict_stale``. The read-side TTL was removed in
# ``test_lookup_returns_row_older_than_default_ttl`` above, but if the
# write-side eviction runs every 60s at the 300s default it deletes the row
# out from under the lookup ~5-6 minutes after write — the original misc-
# tagging bug recurs on a slight delay. The daemon prune loop now passes
# ``max_age_s=86400.0`` (24h) at the call site in ``cli._run_daemon``; these
# tests use the same horizon to confirm a row written at t=0 still resolves
# at t=1h (a realistic Claude Code coding-session length).

# Mirror of the constant defined in halton_meter.cli._run_daemon; if the cli
# value drifts this test will need to be updated in lockstep. Keeping a
# literal here rather than importing avoids importing cli (which has heavy
# launchd/structlog side-effects) into a unit-test module.
_PRUNE_LOOP_MAX_AGE_S = 86400.0


def test_prune_loop_horizon_keeps_long_lived_row(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """At the daemon prune-loop horizon (24h), a 1h-old row survives.

    System-level closure of Mode 1 (long-lived CONNECT tunnel).
    Pre-fix: prune loop ran with max_age_s=300s, deleted the row at
    t≈5min, lookup returned None, request fell through to
    smart_default. Post-fix: prune loop uses max_age_s=86400s, the
    row stays, lookup hits, attribution is preserved across the
    whole session.
    """
    import halton_meter.attribution_store as store_mod

    # Write at t=0, evict at t=1h, look up at t=1h+1s.
    times = iter([0.0, 3600.0, 3601.0])

    def _now() -> float:
        try:
            return next(times)
        except StopIteration:
            return 3601.0

    monkeypatch.setattr(store_mod.time, "time", _now)
    attribution_store.write(11111, "long-session")
    # Prune loop fires at t=1h with the daemon's 24h horizon.
    deleted = attribution_store.evict_stale(max_age_s=_PRUNE_LOOP_MAX_AGE_S)
    assert deleted == 0
    assert attribution_store.lookup(11111) == ("long-session", None)


def test_default_evict_horizon_still_deletes_old_row(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Paired negative: at the module default (300s) a 1h-old row IS evicted.

    Confirms the eviction primitive itself still works for other callers
    (opportunistic in-write eviction, ad-hoc callers) — only the daemon
    prune loop was raised. If this test fails the module default has
    drifted; see decisions.md 2026-05-18.
    """
    import halton_meter.attribution_store as store_mod

    times = iter([0.0, 3600.0, 3601.0])

    def _now() -> float:
        try:
            return next(times)
        except StopIteration:
            return 3601.0

    monkeypatch.setattr(store_mod.time, "time", _now)
    attribution_store.write(22222, "doomed-row")
    # Default max_age_s=300.0 (DEFAULT_MAX_AGE_SECONDS) — the row is well
    # past the cutoff at t=1h and must be deleted.
    deleted = attribution_store.evict_stale()
    assert deleted == 1
    assert DEFAULT_MAX_AGE_SECONDS == 300.0  # guard against drift
    # Lookup at t=1h+1s: row is gone, no attribution survives.
    assert attribution_store.lookup(22222) is None


# --------------------------------------------------------------------------- #
# Schema idempotence                                                          #
# --------------------------------------------------------------------------- #


def test_schema_bootstrap_is_idempotent(tmp_path: Path) -> None:
    """Re-pointing the singleton at the same file does not raise.

    The CREATE TABLE IF NOT EXISTS + CREATE INDEX IF NOT EXISTS
    statements must tolerate a second open on a file where the
    schema is already in place.
    """
    db = tmp_path / "shared.sqlite"
    attribution_store.set_db_path(db)
    attribution_store.write(1, "a")
    # Re-wire — schema already there.
    attribution_store.set_db_path(None)
    attribution_store.set_db_path(db)
    assert attribution_store.lookup(1) == ("a", None)


def test_creates_parent_directory_if_missing(tmp_path: Path) -> None:
    """The store mkdir's the parent so a fresh-install edge can run.

    The edge process may run before the daemon has ever created the
    ``~/.halton-meter/`` dir.
    """
    nested = tmp_path / "does" / "not" / "exist"
    db = nested / "attrib.sqlite"
    attribution_store.set_db_path(db)
    attribution_store.write(1, "a")
    assert db.exists()


# --------------------------------------------------------------------------- #
# Concurrency — simulating the production load profile                        #
# --------------------------------------------------------------------------- #


def test_concurrent_writes_with_thread_pool(tmp_path: Path) -> None:
    """50 simultaneous threads writing through the singleton complete cleanly.

    This mirrors the production load profile the brief calls out: many
    edge accept handlers running in parallel, each writing one
    attribution. We assert that every distinct port lands in the
    table (no race-loss).
    """
    db = tmp_path / "concurrent.sqlite"
    attribution_store.set_db_path(db)
    n_threads = 50

    def writer(idx: int) -> None:
        attribution_store.write(50000 + idx, f"proj-{idx}")

    with ThreadPoolExecutor(max_workers=n_threads) as ex:
        futures = [ex.submit(writer, i) for i in range(n_threads)]
        for f in futures:
            f.result()

    # Every port should resolve to its own project name.
    for i in range(n_threads):
        assert attribution_store.lookup(50000 + i) == (f"proj-{i}", None)


def test_concurrent_writes_via_threading_module(tmp_path: Path) -> None:
    """Mirror of the brief's other concurrency check: 50 plain threads.

    Uses ``threading.Thread`` directly so we explicitly exercise the
    scenario the brief calls out (50 workers via
    ``concurrent.futures.ThreadPoolExecutor`` is in the test above —
    this one is a redundant check on the simpler primitive).
    """
    db = tmp_path / "threads.sqlite"
    attribution_store.set_db_path(db)
    n_threads = 50

    def writer(idx: int) -> None:
        attribution_store.write(60000 + idx, f"proj-{idx}")

    threads = [threading.Thread(target=writer, args=(i,)) for i in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    for i in range(n_threads):
        assert attribution_store.lookup(60000 + i) == (f"proj-{i}", None)


# --------------------------------------------------------------------------- #
# Failure modes — fail-open behaviour                                         #
# --------------------------------------------------------------------------- #


def test_write_silent_when_sqlite_unwritable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A sqlite3 error during write is logged and swallowed; never raises.

    We force the failure by patching sqlite3.connect to raise after
    the schema has been bootstrapped on a real connection.
    """
    import sqlite3

    db = tmp_path / "ok.sqlite"
    attribution_store.set_db_path(db)
    # Trigger schema bootstrap with a real connection first.
    attribution_store.write(1, "real")

    def _bad_connect(*args: object, **kwargs: object) -> object:
        raise sqlite3.OperationalError("disk full (simulated)")

    monkeypatch.setattr(sqlite3, "connect", _bad_connect)
    # Must not raise.
    attribution_store.write(11111, "foo")


def test_lookup_returns_none_when_sqlite_read_fails(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A sqlite3 error during lookup returns None — tagger fall-through path."""
    import sqlite3

    db = tmp_path / "ok.sqlite"
    attribution_store.set_db_path(db)
    attribution_store.write(33333, "x")

    monkeypatch.setattr(
        sqlite3,
        "connect",
        lambda *args, **kwargs: (_ for _ in ()).throw(
            sqlite3.OperationalError("read error (simulated)")
        ),
    )
    assert attribution_store.lookup(33333) is None


# --------------------------------------------------------------------------- #
# Singleton wiring                                                            #
# --------------------------------------------------------------------------- #


def test_get_db_path_returns_none_until_set() -> None:
    """get_db_path returns None when the singleton is unwired.

    The autouse fixture wires it at the start of each test, so we
    explicitly disarm here to assert the unwired path.
    """
    attribution_store.set_db_path(None)
    assert attribution_store.get_db_path() is None


def test_set_db_path_overrides(tmp_path: Path) -> None:
    """set_db_path swaps the singleton."""
    new = tmp_path / "alt.sqlite"
    attribution_store.set_db_path(new)
    # The path comes back resolved/expanded.
    assert attribution_store.get_db_path() == new


def test_set_db_path_none_clears(tmp_path: Path) -> None:
    """set_db_path(None) clears the singleton."""
    attribution_store.set_db_path(tmp_path / "x.sqlite")
    assert attribution_store.get_db_path() is not None
    attribution_store.set_db_path(None)
    assert attribution_store.get_db_path() is None


@pytest.mark.parametrize("port", [1, 80, 443, 8081, 65535])
def test_arbitrary_valid_ports(tmp_path: Path, port: int) -> None:
    """Every port in (0, 65536) round-trips."""
    attribution_store.set_db_path(tmp_path / f"attrib-{port}.sqlite")
    attribution_store.write(port, f"proj-{port}")
    assert attribution_store.lookup(port) == (f"proj-{port}", None)


# --------------------------------------------------------------------------- #
# Opportunistic eviction triggers from inside write()                         #
# --------------------------------------------------------------------------- #


def test_opportunistic_eviction_runs_periodically(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """write() should fire evict_stale every Nth call.

    We patch the eviction threshold to 5 so we don't have to do 50
    writes; then we count calls to ``evict_stale`` and assert they
    track the threshold.
    """
    import halton_meter.attribution_store as store_mod

    db = tmp_path / "tick.sqlite"
    attribution_store.set_db_path(db)

    monkeypatch.setattr(store_mod, "_EVICT_EVERY_N_WRITES", 5)
    calls: list[int] = []
    real_evict = store_mod.evict_stale

    def _counting(max_age_s: float = DEFAULT_MAX_AGE_SECONDS) -> int:
        calls.append(1)
        return real_evict(max_age_s)

    monkeypatch.setattr(store_mod, "evict_stale", _counting)
    for i in range(12):
        attribution_store.write(70000 + i, f"p-{i}")
    # 12 writes, threshold 5 → eviction fires at write 5, 10. 2 calls.
    assert len(calls) == 2
