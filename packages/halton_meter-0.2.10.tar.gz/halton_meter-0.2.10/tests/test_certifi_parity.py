"""v0.1.22.18 Fix 3: certifi patch idempotency parity.

Pre-fix, the install path's "Already patched" message and doctor's
"Certifi bundle: unpatched" status could disagree on the user's
machine — the user reported ``init --apps`` saying "Already patched"
while ``doctor`` flagged unpatched in the same shell. Both helpers
already routed through the same predicate, but the implementation was
embedded inline in ``_macos.py`` with no name, no test for the four
divergent cases, and no shared helper. This module nails down the
contract via a single-source-of-truth helper named
:func:`certifi_already_contains_ca` in ``setup/_common.py`` and
verifies the four edge cases that drive the install / doctor agreement.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from halton_meter.setup._common import (
    CERTIFI_MARKER,
    certifi_already_contains_ca,
)

_DUMMY_CA_PEM = (
    "-----BEGIN CERTIFICATE-----\n"
    "MIIDazCCAlOgAwIBAgIUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\n"
    "FAKE_PAYLOAD_FOR_TEST_ONLY_NOT_A_REAL_CERT_BODY\n"
    "-----END CERTIFICATE-----\n"
)


def _fresh_bundle(path: Path) -> None:
    """Write a stock certifi bundle with no halton-meter marker."""
    path.write_text(
        "# Stock Mozilla CA bundle\n"
        "-----BEGIN CERTIFICATE-----\nUNRELATED\n-----END CERTIFICATE-----\n",
        encoding="utf-8",
    )


def _patched_bundle(path: Path, ca_pem: str) -> None:
    """Write a bundle that already carries our marker + CA cert body."""
    _fresh_bundle(path)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(f"\n{CERTIFI_MARKER}\n")
        fh.write(ca_pem)


def _ca_file(path: Path, pem: str = _DUMMY_CA_PEM) -> Path:
    path.write_text(pem, encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# The four cases the install / doctor must agree on
# ---------------------------------------------------------------------------


class TestCertifiAlreadyContainsCA:
    def test_fresh_bundle_no_marker_no_ca(self, tmp_path: Path) -> None:
        """A stock certifi bundle with no halton-meter marker is unpatched —
        the cardinal "fresh ``pipx --force`` reinstall" case where the
        previous patch is gone with the venv."""
        bundle = tmp_path / "cacert.pem"
        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem")
        _fresh_bundle(bundle)
        assert certifi_already_contains_ca(ca, bundle) is False

    def test_patched_bundle_with_current_ca_is_idempotent(
        self, tmp_path: Path
    ) -> None:
        """A bundle carrying our marker AND our current CA verbatim is
        patched. ``patch_certifi`` skips re-appending; doctor reports
        ok. Both call sites must agree."""
        bundle = tmp_path / "cacert.pem"
        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem")
        _patched_bundle(bundle, _DUMMY_CA_PEM)
        assert certifi_already_contains_ca(ca, bundle) is True

    def test_tampered_bundle_marker_only_no_body(self, tmp_path: Path) -> None:
        """Bundle has the marker line but the CA body has been
        partially stripped (e.g. user opened the file in a text editor
        and accidentally truncated). Stale-marker drift must register
        as unpatched so ``patch_certifi`` re-appends and doctor warns."""
        bundle = tmp_path / "cacert.pem"
        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem")
        # Marker present but only one line of the CA body remains.
        first_line = _DUMMY_CA_PEM.splitlines()[0]
        bundle.write_text(
            f"# Stock\n{CERTIFI_MARKER}\n{first_line}\n", encoding="utf-8"
        )
        assert certifi_already_contains_ca(ca, bundle) is False

    def test_different_ca_body_in_bundle(self, tmp_path: Path) -> None:
        """Bundle carries a DIFFERENT CA cert body (e.g. a corporate
        proxy's CA the user hand-appended). Detection must look for
        OUR specific CA body, not just "any halton-meter marker"."""
        bundle = tmp_path / "cacert.pem"
        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem")
        other_ca = (
            "-----BEGIN CERTIFICATE-----\n"
            "DIFFERENT_CORPORATE_CA_PAYLOAD_NOT_OUR_MITM\n"
            "-----END CERTIFICATE-----\n"
        )
        _patched_bundle(bundle, other_ca)
        assert certifi_already_contains_ca(ca, bundle) is False

    def test_missing_bundle_file_returns_false(self, tmp_path: Path) -> None:
        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem")
        bundle = tmp_path / "does-not-exist.pem"
        assert certifi_already_contains_ca(ca, bundle) is False

    def test_missing_ca_file_returns_false(self, tmp_path: Path) -> None:
        """Marker present in the bundle but the CA disk file is gone.
        Conservatively unpatched — re-run ``patch_certifi`` once the
        CA is regenerated."""
        bundle = tmp_path / "cacert.pem"
        _patched_bundle(bundle, _DUMMY_CA_PEM)
        ca = tmp_path / "mitmproxy-ca-cert.pem"  # not written
        assert certifi_already_contains_ca(ca, bundle) is False

    def test_empty_ca_file_returns_false(self, tmp_path: Path) -> None:
        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem", pem="\n  \n")
        bundle = tmp_path / "cacert.pem"
        _patched_bundle(bundle, _DUMMY_CA_PEM)
        assert certifi_already_contains_ca(ca, bundle) is False

    def test_never_raises(self, tmp_path: Path) -> None:
        """Defensive: callers treat False as 'patch please' — the
        helper must never raise, even on permission / decode errors."""
        # Pass paths that don't exist at all.
        assert (
            certifi_already_contains_ca(
                tmp_path / "no-ca", tmp_path / "no-bundle"
            )
            is False
        )


# ---------------------------------------------------------------------------
# Install / doctor parity — both sides must agree on every case
# ---------------------------------------------------------------------------


class TestInstallDoctorParity:
    """The user's reported bug: install says 'Already patched' but
    doctor says 'unpatched'. Verify both call sites consult the same
    helper and therefore cannot disagree.
    """

    def test_install_check_routes_through_shared_helper(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from halton_meter.setup import _macos

        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem")
        bundle = tmp_path / "cacert.pem"
        _fresh_bundle(bundle)
        monkeypatch.setattr(_macos, "MITMPROXY_CERT_PATH", ca)
        monkeypatch.setattr(_macos, "_certifi_bundle_path", lambda: bundle)
        # Fresh bundle, no marker, no body — must be unpatched.
        assert _macos._is_certifi_patched() is False

        _patched_bundle(bundle, ca.read_text(encoding="utf-8"))
        # Now both helper + install-side wrapper must agree.
        assert _macos._is_certifi_patched() is True
        assert certifi_already_contains_ca(ca, bundle) is True

    def test_doctor_and_install_agree_on_tampered_bundle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Tampered bundle (marker present, body partial) must surface
        as unpatched on BOTH paths simultaneously. Pre-fix the user's
        machine reported install=patched / doctor=unpatched in this
        exact configuration."""
        from halton_meter.setup import _macos

        ca = _ca_file(tmp_path / "mitmproxy-ca-cert.pem")
        bundle = tmp_path / "cacert.pem"
        first_line = _DUMMY_CA_PEM.splitlines()[0]
        bundle.write_text(
            f"# Stock\n{CERTIFI_MARKER}\n{first_line}\n", encoding="utf-8"
        )
        monkeypatch.setattr(_macos, "MITMPROXY_CERT_PATH", ca)
        monkeypatch.setattr(_macos, "_certifi_bundle_path", lambda: bundle)
        assert _macos._is_certifi_patched() is False
        assert certifi_already_contains_ca(ca, bundle) is False
