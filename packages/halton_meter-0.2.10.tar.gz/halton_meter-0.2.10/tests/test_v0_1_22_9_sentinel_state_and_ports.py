"""v0.1.22.9 — sentinel state machine + ground-truth port resolution.

Three areas covered:

1. ``init.set_install_mode`` — atomic write of install-mode + matching
   sentinel + opposite-sentinel removal. Bug 1 fix surface.
2. ``init.reconcile_sentinel_state`` — startup invariant; auto-heals
   drift left behind by pre-v0.1.22.9 writers (e.g. legacy
   ``halton-meter setup`` writing ``proxy-managed`` regardless of
   install-mode).
3. ``port_alloc.resolve_effective_port`` + ``_managed_label_listening_port``
   — Bug 2 ground-truth port lookup so the status panel reports the
   actually-bound port even when ``effective-ports.json`` is missing.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from halton_meter import init as init_module
from halton_meter import port_alloc

# --------------------------------------------------------------------------- #
# Bug 1: set_install_mode — atomic state-machine writer.                       #
# --------------------------------------------------------------------------- #


@pytest.fixture
def sentinel_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> dict[str, Path]:
    """Redirect the three-file state machine into a tmp dir."""
    install_mode = tmp_path / "install-mode"
    proxy_managed = tmp_path / "proxy-managed"
    apps_managed = tmp_path / "apps-managed"

    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", install_mode)
    # ``set_install_mode`` resolves these via late-bound import inside
    # the function body, so we patch ``halton_meter.setup`` directly.
    import halton_meter.setup as setup_module

    monkeypatch.setattr(setup_module, "PROXY_MANAGED_SENTINEL", proxy_managed)
    monkeypatch.setattr(setup_module, "APPS_MANAGED_SENTINEL", apps_managed)

    return {
        "install_mode": install_mode,
        "proxy_managed": proxy_managed,
        "apps_managed": apps_managed,
    }


def test_set_install_mode_apps_writes_apps_removes_proxy(
    sentinel_paths: dict[str, Path],
) -> None:
    # Seed with stale full-mode state.
    sentinel_paths["proxy_managed"].write_text("full\n2026-01-01T00:00:00+00:00\n")

    init_module.set_install_mode("apps")

    assert sentinel_paths["install_mode"].read_text().strip() == "apps"
    assert sentinel_paths["apps_managed"].exists()
    assert not sentinel_paths["proxy_managed"].exists()


def test_set_install_mode_full_writes_proxy_removes_apps(
    sentinel_paths: dict[str, Path],
) -> None:
    # Seed with stale apps-mode state.
    sentinel_paths["apps_managed"].write_text("apps\n2026-01-01T00:00:00+00:00\n")

    init_module.set_install_mode("full")

    assert sentinel_paths["install_mode"].read_text().strip() == "full"
    assert sentinel_paths["proxy_managed"].exists()
    assert not sentinel_paths["apps_managed"].exists()


def test_set_install_mode_env_only_removes_both_sentinels(
    sentinel_paths: dict[str, Path],
) -> None:
    sentinel_paths["proxy_managed"].write_text("full\n")
    sentinel_paths["apps_managed"].write_text("apps\n")

    init_module.set_install_mode("env-only")

    assert sentinel_paths["install_mode"].read_text().strip() == "env-only"
    assert not sentinel_paths["proxy_managed"].exists()
    assert not sentinel_paths["apps_managed"].exists()


def test_set_install_mode_rejects_unknown_mode(
    sentinel_paths: dict[str, Path],
) -> None:
    with pytest.raises(ValueError):
        init_module.set_install_mode("gui")  # legacy alias — write-rejected


def test_set_install_mode_does_not_touch_effective_ports_json(
    sentinel_paths: dict[str, Path], tmp_path: Path
) -> None:
    """Bug 1 invariant: state-machine helper must NOT sweep adjacent
    port-allocator state. ``effective-ports.json`` is owned by
    ``port_alloc``, not by install-mode."""
    eff_json = tmp_path / "effective-ports.json"
    eff_json.write_text('{"edge_port": 8081}')

    init_module.set_install_mode("apps")

    assert eff_json.exists()
    assert eff_json.read_text() == '{"edge_port": 8081}'


# --------------------------------------------------------------------------- #
# Bug 1: reconcile_sentinel_state — startup invariant + auto-heal.             #
# --------------------------------------------------------------------------- #


def test_reconcile_heals_apps_mode_with_stale_proxy_managed_sentinel(
    sentinel_paths: dict[str, Path],
) -> None:
    """The user's exact reproduction signature: install-mode=apps, but
    proxy-managed exists and apps-managed is missing."""
    sentinel_paths["install_mode"].write_text("apps\n")
    sentinel_paths["proxy_managed"].write_text("full\n2026-05-07T11:04:00+00:00\n")
    # apps-managed deliberately missing.

    result = init_module.reconcile_sentinel_state()

    assert result == "apps"
    assert sentinel_paths["apps_managed"].exists()
    assert not sentinel_paths["proxy_managed"].exists()


def test_reconcile_heals_full_mode_with_stale_apps_managed_sentinel(
    sentinel_paths: dict[str, Path],
) -> None:
    """Inverse signature."""
    sentinel_paths["install_mode"].write_text("full\n")
    sentinel_paths["apps_managed"].write_text("apps\n")
    # proxy-managed missing.

    result = init_module.reconcile_sentinel_state()

    assert result == "full"
    assert sentinel_paths["proxy_managed"].exists()
    assert not sentinel_paths["apps_managed"].exists()


def test_reconcile_no_op_on_consistent_apps_state(
    sentinel_paths: dict[str, Path],
) -> None:
    sentinel_paths["install_mode"].write_text("apps\n")
    sentinel_paths["apps_managed"].write_text("apps\n2026-05-07T11:00:00+00:00\n")
    apps_mtime_before = sentinel_paths["apps_managed"].stat().st_mtime

    result = init_module.reconcile_sentinel_state()

    assert result == "apps"
    # Auto-heal should NOT have rewritten the file when state is consistent.
    assert sentinel_paths["apps_managed"].stat().st_mtime == apps_mtime_before
    assert not sentinel_paths["proxy_managed"].exists()


def test_reconcile_no_op_on_fresh_machine(
    sentinel_paths: dict[str, Path],
) -> None:
    """No install-mode + no sentinels = fresh machine; nothing to heal."""
    result = init_module.reconcile_sentinel_state()

    assert result is None
    assert not sentinel_paths["install_mode"].exists()
    assert not sentinel_paths["proxy_managed"].exists()
    assert not sentinel_paths["apps_managed"].exists()


def test_reconcile_infers_mode_from_sentinel_when_install_mode_missing(
    sentinel_paths: dict[str, Path],
) -> None:
    """An older install with no install-mode but with an apps-managed
    sentinel should be healed by inferring apps mode."""
    sentinel_paths["apps_managed"].write_text("apps\n")

    result = init_module.reconcile_sentinel_state()

    assert result == "apps"
    assert sentinel_paths["install_mode"].read_text().strip() == "apps"
    assert sentinel_paths["apps_managed"].exists()
    assert not sentinel_paths["proxy_managed"].exists()


def test_reconcile_heals_silently_when_state_already_consistent(
    sentinel_paths: dict[str, Path],
) -> None:
    """No drift = no auto-heal write. Sentinel mtime unchanged."""
    sentinel_paths["install_mode"].write_text("full\n")
    sentinel_paths["proxy_managed"].write_text("full\n2026-01-01\n")
    proxy_mtime = sentinel_paths["proxy_managed"].stat().st_mtime

    result = init_module.reconcile_sentinel_state()

    assert result == "full"
    assert sentinel_paths["proxy_managed"].stat().st_mtime == proxy_mtime
    assert not sentinel_paths["apps_managed"].exists()


# --------------------------------------------------------------------------- #
# Bug 2: ground-truth port resolution chain.                                   #
# --------------------------------------------------------------------------- #


def test_managed_label_listening_port_returns_first_match_in_prefer_range(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Generic helper picks a port within the preferred range when present."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )
    monkeypatch.setattr(
        port_alloc,
        "_macos_lsof_listen_ports_for_pid",
        lambda _pid: [9999, 8765, 8081],
    )

    result = port_alloc._managed_label_listening_port(
        "com.example.label", prefer_range=range(8081, 8090)
    )
    assert result == 8081


def test_managed_label_listening_port_falls_back_to_first_when_no_range_match(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: [9999, 7777]
    )

    result = port_alloc._managed_label_listening_port(
        "com.example.label", prefer_range=range(8081, 8090)
    )
    assert result == 9999


def test_managed_label_listening_port_returns_none_when_label_dead(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: None
    )
    assert (
        port_alloc._managed_label_listening_port("com.example.label") is None
    )


def test_managed_daemon_label_matches_install() -> None:
    """The daemon launchd label string MUST stay in sync with the
    canonical definition in ``install._macos``."""
    from halton_meter.install._macos import _LABEL

    assert port_alloc._MANAGED_DAEMON_LAUNCHD_LABEL == _LABEL


def test_resolve_effective_port_picks_lsof_first(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Step 1 of the chain: lsof on managed PID overrides JSON + cfg."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )
    monkeypatch.setattr(
        port_alloc,
        "_macos_lsof_listen_ports_for_pid",
        lambda _pid: [9999, 8765],  # mitm on 9999, api on 8765
    )

    result = port_alloc.resolve_effective_port(role="mitm", cfg_value=8090)
    assert result == 9999


def test_resolve_effective_port_falls_back_to_effective_ports_json(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Step 2 of the chain: when lsof returns nothing, read JSON."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: None
    )

    eff_path = tmp_path / "effective-ports.json"
    eff_path.write_text(
        '{"internal_port": 8091, "api_port": 8766, "edge_port": 8082}'
    )
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    assert (
        port_alloc.resolve_effective_port(role="mitm", cfg_value=8090) == 8091
    )
    assert (
        port_alloc.resolve_effective_port(role="api", cfg_value=8765) == 8766
    )
    assert (
        port_alloc.resolve_effective_port(role="edge", cfg_value=8081) == 8082
    )


def test_resolve_effective_port_falls_back_to_cfg_value(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Step 3 of the chain: lsof empty + JSON empty → cfg default."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: None
    )

    eff_path = tmp_path / "effective-ports.json"  # does not exist
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    assert (
        port_alloc.resolve_effective_port(role="mitm", cfg_value=8090) == 8090
    )


def test_resolve_effective_port_rejects_unknown_role() -> None:
    with pytest.raises(ValueError):
        port_alloc.resolve_effective_port(role="bogus", cfg_value=1234)


def test_resolve_effective_port_returns_none_when_chain_empty(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """No lsof, no JSON, no cfg → None (not a guess)."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: None
    )
    monkeypatch.setattr(
        port_alloc, "EFFECTIVE_PORTS_JSON_PATH", tmp_path / "absent.json"
    )

    assert (
        port_alloc.resolve_effective_port(role="api", cfg_value=None) is None
    )


def test_managed_edge_listening_port_back_compat_v0_1_22_6(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.22.6 regression guard: behaviour preserved through the
    v0.1.22.9 lift to ``_managed_label_listening_port``."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 3810
    )
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: [8081]
    )

    assert port_alloc._managed_edge_listening_port() == 8081


def test_resolve_managed_daemon_disambiguates_mitm_vs_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The daemon binds two ports under one label; helper must split them."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12969
    )
    # mitm + api in the same return value.
    monkeypatch.setattr(
        port_alloc,
        "_macos_lsof_listen_ports_for_pid",
        lambda _pid: [8090, 8765],
    )

    assert port_alloc._resolve_managed_daemon_mitm_port() == 8090
    assert port_alloc._resolve_managed_daemon_api_port() == 8765


# --------------------------------------------------------------------------- #
# CLI ``setup`` no longer writes proxy-managed (Bug 1 offending writer).        #
# --------------------------------------------------------------------------- #


def test_cli_setup_command_passes_managed_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Source-grep guard: ``halton-meter setup`` must NOT default to
    ``managed=True`` and write the ``proxy-managed`` sentinel
    regardless of install-mode (Bug 1 root cause)."""
    cli_path = (
        Path(__file__).resolve().parent.parent
        / "halton_meter"
        / "cli.py"
    )
    src = cli_path.read_text(encoding="utf-8")
    # Find the setup function body and confirm it passes managed=False.
    assert "managed=False" in src, (
        "halton-meter setup must explicitly pass managed=False to "
        "run_setup; defaulting writes proxy-managed regardless of "
        "install-mode (v0.1.22.9 Bug 1)"
    )


def test_run_daemon_invokes_reconcile_sentinel_state() -> None:
    """Source-grep guard: the daemon startup path must call the
    sentinel-state invariant on every cold start."""
    cli_path = (
        Path(__file__).resolve().parent.parent
        / "halton_meter"
        / "cli.py"
    )
    src = cli_path.read_text(encoding="utf-8")
    assert "reconcile_sentinel_state" in src
