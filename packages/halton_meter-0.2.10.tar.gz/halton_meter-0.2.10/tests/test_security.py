"""Tests for daemon/halton_meter/security.py — loopback-only bind guard."""
from __future__ import annotations

import socket
from unittest.mock import patch

import pytest

from halton_meter.security import _assert_loopback_bind, _ALLOW_NON_LOOPBACK_ENV


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_getaddrinfo(resolved_ip: str):
    """Return a getaddrinfo patcher that yields ``resolved_ip`` for any host."""

    def _fake_getaddrinfo(host, port, **kwargs):  # type: ignore[override]
        # Minimal well-formed getaddrinfo result:
        # (family, type, proto, canonname, sockaddr)
        # For IPv4: sockaddr = (address, port)
        # For IPv6: sockaddr = (address, port, flowinfo, scope_id)
        if ":" in resolved_ip:
            sockaddr = (resolved_ip, 0, 0, 0)
        else:
            sockaddr = (resolved_ip, 0)
        return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", sockaddr)]

    return patch("halton_meter.security.socket.getaddrinfo", side_effect=_fake_getaddrinfo)


# ---------------------------------------------------------------------------
# test_loopback_passes
# ---------------------------------------------------------------------------

def test_loopback_127_0_0_1_passes():
    """127.0.0.1 must pass without raising for both hosts."""
    with _mock_getaddrinfo("127.0.0.1"):
        # Should not raise or call sys.exit.
        _assert_loopback_bind("127.0.0.1", "127.0.0.1")


def test_loopback_ipv6_passes():
    """::1 must pass without raising."""
    with _mock_getaddrinfo("::1"):
        _assert_loopback_bind("::1", "::1")


def test_loopback_localhost_resolves_to_127_passes():
    """'localhost' that resolves to 127.0.0.1 must pass."""
    with _mock_getaddrinfo("127.0.0.1"):
        _assert_loopback_bind("localhost", "localhost")


# ---------------------------------------------------------------------------
# test_non_loopback_refuses
# ---------------------------------------------------------------------------

def test_non_loopback_0_0_0_0_refuses(monkeypatch):
    """0.0.0.0 must cause SystemExit(1) when override env is not set."""
    monkeypatch.delenv(_ALLOW_NON_LOOPBACK_ENV, raising=False)
    with _mock_getaddrinfo("0.0.0.0"):
        with pytest.raises(SystemExit) as exc_info:
            _assert_loopback_bind("0.0.0.0", "127.0.0.1")
    assert exc_info.value.code == 1


def test_non_loopback_public_ip_refuses(monkeypatch):
    """A routable IP in listen_host must cause SystemExit(1)."""
    monkeypatch.delenv(_ALLOW_NON_LOOPBACK_ENV, raising=False)
    with _mock_getaddrinfo("192.168.1.50"):
        with pytest.raises(SystemExit) as exc_info:
            _assert_loopback_bind("0.0.0.0", "127.0.0.1")
    assert exc_info.value.code == 1


def test_non_loopback_api_host_refuses(monkeypatch):
    """A non-loopback api_host must also cause SystemExit(1)."""
    monkeypatch.delenv(_ALLOW_NON_LOOPBACK_ENV, raising=False)

    call_count = 0

    def _side_effect(host, port, **kwargs):
        nonlocal call_count
        call_count += 1
        # First call (listen_host) → loopback; second (api_host) → non-loopback.
        ip = "127.0.0.1" if call_count == 1 else "10.0.0.1"
        return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (ip, 0))]

    with patch("halton_meter.security.socket.getaddrinfo", side_effect=_side_effect):
        with pytest.raises(SystemExit) as exc_info:
            _assert_loopback_bind("127.0.0.1", "0.0.0.0")
    assert exc_info.value.code == 1


def test_non_loopback_override_env_allows(monkeypatch):
    """When HALTON_METER_ALLOW_NON_LOOPBACK=1, non-loopback must NOT raise."""
    monkeypatch.setenv(_ALLOW_NON_LOOPBACK_ENV, "1")
    with _mock_getaddrinfo("0.0.0.0"):
        # Must complete without raising SystemExit.
        _assert_loopback_bind("0.0.0.0", "0.0.0.0")


def test_non_loopback_override_env_truthy_values(monkeypatch):
    """Any non-empty truthy string in the override env var must work."""
    for value in ("1", "true", "yes", "override"):
        monkeypatch.setenv(_ALLOW_NON_LOOPBACK_ENV, value)
        with _mock_getaddrinfo("10.10.10.10"):
            _assert_loopback_bind("0.0.0.0", "127.0.0.1")


def test_override_env_empty_string_does_not_override(monkeypatch):
    """An empty HALTON_METER_ALLOW_NON_LOOPBACK must not count as an override."""
    monkeypatch.setenv(_ALLOW_NON_LOOPBACK_ENV, "")
    with _mock_getaddrinfo("0.0.0.0"):
        with pytest.raises(SystemExit) as exc_info:
            _assert_loopback_bind("0.0.0.0", "127.0.0.1")
    assert exc_info.value.code == 1
