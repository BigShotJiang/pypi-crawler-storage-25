"""v0.1.22.12 — sentinel writer plug + heartbeat reconcile + verdict drift.

Three bugs covered:

1. Bug 1 — every remaining ``proxy-managed`` writer is routed through
   ``init.set_install_mode``. Source-grep guards on the ex-writers in
   ``setup/_macos.py`` and ``init.py`` plus a behavioural check that
   ``run_setup(managed=True)`` is now a no-op for the sentinel.

2. Bug 2 — heartbeat-triggered ``reconcile_sentinel_state`` fires
   when drift is introduced after cold start, with a per-cycle
   oscillation cap that escalates the log line from ERROR to CRITICAL.

3. Bug 3 — verdict pill / text reports BROKEN under all four
   sentinel-drift cases (apps+proxy_managed, full+apps_managed, both
   present, install-mode set + neither sentinel).
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest

from halton_meter import init as init_module
from halton_meter import observability as obs_module

# --------------------------------------------------------------------------- #
# Shared fixture: redirect sentinel paths into a tmp dir.
# --------------------------------------------------------------------------- #


@pytest.fixture
def sentinel_paths(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> dict[str, Path]:
    install_mode = tmp_path / "install-mode"
    proxy_managed = tmp_path / "proxy-managed"
    apps_managed = tmp_path / "apps-managed"

    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", install_mode)
    import halton_meter.setup as setup_module

    monkeypatch.setattr(setup_module, "PROXY_MANAGED_SENTINEL", proxy_managed)
    monkeypatch.setattr(setup_module, "APPS_MANAGED_SENTINEL", apps_managed)

    return {
        "install_mode": install_mode,
        "proxy_managed": proxy_managed,
        "apps_managed": apps_managed,
    }


# --------------------------------------------------------------------------- #
# Bug 1 — writer audit. Every previously-leaking writer is plugged.
# --------------------------------------------------------------------------- #


def test_run_setup_managed_true_no_longer_writes_proxy_managed_sentinel(
    sentinel_paths: dict[str, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.22.12 Bug 1: ``run_setup(managed=True)`` MUST NOT write
    the ``proxy-managed`` sentinel. The sentinel is owned exclusively
    by ``init.set_install_mode``."""
    import sys

    if sys.platform != "darwin":
        pytest.skip("setup.run_setup sentinel write was macOS-only")

    from halton_meter.setup import _macos as setup_macos

    # Stub out the three real steps so they all return done=True
    # without touching keychain / certifi / cert-gen.
    from halton_meter.setup._macos import StepStatus

    def _ok(_label: str) -> StepStatus:
        return StepStatus(name=_label, done=True, note="stub")

    monkeypatch.setattr(
        setup_macos,
        "generate_mitmproxy_cert",
        lambda *a, **kw: _ok("Generate mitmproxy CA cert"),
    )
    monkeypatch.setattr(
        setup_macos,
        "trust_cert_macos",
        lambda *a, **kw: _ok("Trust cert in macOS keychain"),
    )
    monkeypatch.setattr(
        setup_macos,
        "patch_certifi",
        lambda *a, **kw: _ok("Patch certifi bundle"),
    )

    assert not sentinel_paths["proxy_managed"].exists()
    setup_macos.run_setup(force=False, managed=True)
    # The whole point of the v0.1.22.12 fix:
    assert not sentinel_paths["proxy_managed"].exists(), (
        "run_setup(managed=True) wrote proxy-managed; the writer "
        "should now be exclusively owned by init.set_install_mode."
    )


def test_init_progress_branch_no_longer_inlines_sentinel_touch() -> None:
    """v0.1.22.12 Bug 1 source-grep: the init flow's progress-mode
    branch must NOT contain a direct ``PROXY_MANAGED_SENTINEL.touch()``
    write. Sentinel writes route through ``set_install_mode``."""
    init_path = (
        Path(__file__).resolve().parent.parent
        / "halton_meter"
        / "init.py"
    )
    src = init_path.read_text(encoding="utf-8")
    # The pre-v0.1.22.12 inline write looked like:
    #   PROXY_MANAGED_SENTINEL.touch(exist_ok=True)
    # The fix removes it. (The constant may still appear in
    # set_install_mode's body — that's the canonical path.) Filter
    # comment lines so prose mentioning the removed call doesn't
    # trip the guard.
    code_lines = [
        ln for ln in src.splitlines()
        if not ln.lstrip().startswith("#")
    ]
    code_only = "\n".join(code_lines)
    assert "PROXY_MANAGED_SENTINEL.touch" not in code_only, (
        "init.py still contains a direct PROXY_MANAGED_SENTINEL.touch "
        "call; route the write through init.set_install_mode instead."
    )


def test_setup_macos_run_setup_no_longer_calls_touch_on_sentinel() -> None:
    """v0.1.22.12 Bug 1 source-grep: ``setup/_macos.py`` must not
    contain a ``PROXY_MANAGED_SENTINEL.touch`` call. The ``managed``
    parameter is preserved for backward compatibility but is a
    documented no-op for sentinel state."""
    setup_path = (
        Path(__file__).resolve().parent.parent
        / "halton_meter"
        / "setup"
        / "_macos.py"
    )
    src = setup_path.read_text(encoding="utf-8")
    code_lines = [
        ln for ln in src.splitlines()
        if not ln.lstrip().startswith("#")
    ]
    src = "\n".join(code_lines)
    assert "PROXY_MANAGED_SENTINEL.touch" not in src, (
        "setup/_macos.py still touches PROXY_MANAGED_SENTINEL; "
        "remove the write — set_install_mode owns the sentinel."
    )


def test_init_init_flow_passes_managed_false_to_run_setup() -> None:
    """v0.1.22.12 Bug 1 source-grep: the init flow's legacy-mode
    ``run_setup`` call must pass ``managed=False`` so even if a
    backward-compat external caller relied on the old behaviour, the
    halton-meter init path itself is sentinel-clean."""
    init_path = (
        Path(__file__).resolve().parent.parent
        / "halton_meter"
        / "init.py"
    )
    src = init_path.read_text(encoding="utf-8")
    # Locate the run_setup call in the legacy-mode branch.
    assert "managed=(mode == MODE_FULL)" not in src, (
        "init.py still passes managed=(mode == MODE_FULL) to run_setup; "
        "the sentinel write is now owned by set_install_mode — pass "
        "managed=False unconditionally."
    )


# --------------------------------------------------------------------------- #
# Bug 2 — heartbeat-triggered reconcile + oscillation cap.
# --------------------------------------------------------------------------- #


class _RecordingReconcile:
    def __init__(self) -> None:
        self.calls: list[str] = []

    def __call__(self, trigger: str) -> str | None:
        self.calls.append(trigger)
        return "apps"


def _run_one_heartbeat_tick(
    *,
    drift: bool,
    reconciler: _RecordingReconcile,
    interval: float = 0.001,
) -> None:
    """Drive the heartbeat loop for exactly one tick then cancel."""

    async def _go() -> None:
        task = asyncio.create_task(
            obs_module.heartbeat_loop(
                mitm_port=0,
                api_port=0,
                db_path=Path("/tmp/halton-meter-test.db"),
                interval=interval,
                probe_mitm=lambda _p: False,
                probe_api=lambda _p: False,
                probe_db=lambda _p: False,
                probe_fds=lambda: 0,
                sentinel_reconcile=reconciler,
                detect_sentinel_drift=lambda: drift,
            )
        )
        # Yield enough that the loop body runs once.
        await asyncio.sleep(interval * 5)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    asyncio.run(_go())


def test_heartbeat_reconcile_fires_when_drift_detected() -> None:
    """v0.1.22.12 Bug 2: drift in the running daemon's sentinel state
    must trigger the auto-heal within one heartbeat — not deferred to
    the next stop/start cycle."""
    rec = _RecordingReconcile()
    _run_one_heartbeat_tick(drift=True, reconciler=rec)
    assert len(rec.calls) >= 1, "heartbeat reconcile did not fire on drift"
    assert rec.calls[0] == "heartbeat", (
        "heartbeat reconcile must pass trigger='heartbeat' to disambiguate "
        "from startup-detected drift in daemon.err.log"
    )


def test_heartbeat_reconcile_no_op_when_state_consistent() -> None:
    """When sentinel state is consistent the reconciler must not be
    invoked. Avoid log-spam on every heartbeat in the steady state."""
    rec = _RecordingReconcile()
    _run_one_heartbeat_tick(drift=False, reconciler=rec)
    assert rec.calls == [], (
        "heartbeat reconcile fired despite consistent sentinel state"
    )


def test_heartbeat_oscillation_escalates_to_critical(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.22.12 Bug 2: when drift fires every heartbeat for the
    threshold count, escalate the log line from ERROR (per-drift) to
    CRITICAL with state=oscillating so the user sees the bug above
    the noise floor.

    Captures via a recording structlog logger so the test doesn't
    depend on caplog's stdlib-bridging configuration.
    """
    captured: list[tuple[str, str, dict[str, Any]]] = []

    class _RecordingLogger:
        def critical(self, event: str, **kw: Any) -> None:
            captured.append(("critical", event, kw))

        def error(self, event: str, **kw: Any) -> None:
            captured.append(("error", event, kw))

        def warning(self, event: str, **kw: Any) -> None:
            captured.append(("warning", event, kw))

        def info(self, event: str, **kw: Any) -> None:
            captured.append(("info", event, kw))

    monkeypatch.setattr(obs_module, "log", _RecordingLogger())

    rec = _RecordingReconcile()

    async def _go() -> None:
        task = asyncio.create_task(
            obs_module.heartbeat_loop(
                mitm_port=0,
                api_port=0,
                db_path=Path("/tmp/halton-meter-test.db"),
                interval=0.001,
                probe_mitm=lambda _p: False,
                probe_api=lambda _p: False,
                probe_db=lambda _p: False,
                probe_fds=lambda: 0,
                sentinel_reconcile=rec,
                detect_sentinel_drift=lambda: True,
            )
        )
        # Run long enough for >= threshold cycles.
        await asyncio.sleep(
            0.001
            * (obs_module.SENTINEL_RECONCILE_OSCILLATION_THRESHOLD + 4)
            * 4
        )
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    asyncio.run(_go())

    assert (
        len(rec.calls)
        >= obs_module.SENTINEL_RECONCILE_OSCILLATION_THRESHOLD
    ), "did not run enough heartbeat cycles to trip oscillation cap"

    critical_oscillation = [
        (level, event, kw)
        for level, event, kw in captured
        if level == "critical"
        and event == "daemon.heartbeat.sentinel_drift_oscillating"
        and kw.get("state") == "oscillating"
    ]
    assert critical_oscillation, (
        "expected a CRITICAL log line tagged state=oscillating after "
        "consecutive drift cycles ≥ threshold; captured: "
        f"{[(level, event) for level, event, _ in captured]}"
    )


# --------------------------------------------------------------------------- #
# Bug 3 — verdict drift detection: BROKEN in all four drift cases.
# --------------------------------------------------------------------------- #


def _make_rows_healthy() -> list:
    """Build the minimum component rows needed to bypass the
    daemon-down / mitm-down / edge-stale early returns in
    ``_compute_health_summary_macos``."""
    from halton_meter.lifecycle._macos import _ComponentRow

    return [
        _ComponentRow("Daemon", "healthy", "PID 1, /health OK"),
        _ComponentRow("MITM listener", "healthy", "127.0.0.1:8090 OK"),
        _ComponentRow("Watchdog", "healthy", "PID 2"),
        _ComponentRow("Edge", "healthy", "PID 3, port=:8081"),
        _ComponentRow("Cert trust", "trusted", "/Library/Keychains/System.keychain"),
        _ComponentRow("System proxy", "disabled", "—"),
    ]


@pytest.mark.parametrize(
    ("install_mode", "make_proxy", "make_apps", "expected_substr"),
    [
        # Case 1: install-mode=apps but proxy-managed present (the
        # exact 14:54 user signature).
        ("apps", True, False, "install-mode is `apps`"),
        # Case 2: install-mode=full but apps-managed present.
        ("full", False, True, "install-mode is `full`"),
        # Case 3: both sentinels present.
        ("apps", True, True, "both"),
        # Case 4a: install-mode=apps but neither sentinel present.
        ("apps", False, False, "`apps-managed` sentinel is missing"),
        # Case 4b: install-mode=full but neither sentinel present.
        ("full", False, False, "`proxy-managed` sentinel is missing"),
    ],
)
def test_compute_health_summary_returns_broken_for_sentinel_drift(
    sentinel_paths: dict[str, Path],
    install_mode: str,
    make_proxy: bool,
    make_apps: bool,
    expected_substr: str,
) -> None:
    """v0.1.22.12 Bug 3: ``_compute_health_summary_macos`` must
    return BROKEN whenever the install-mode + sentinel triplet is
    inconsistent. Render-side mapping converts BROKEN → PILL_BROKEN
    pill in the verdict panel; we assert on the underlying severity
    here so the test doesn't depend on rich rendering."""
    if make_proxy:
        sentinel_paths["proxy_managed"].write_text("seed\n")
    if make_apps:
        sentinel_paths["apps_managed"].write_text("seed\n")

    from halton_meter.lifecycle._macos import _compute_health_summary_macos

    rows = _make_rows_healthy()
    summary = _compute_health_summary_macos(rows, install_mode)

    assert summary.severity == "BROKEN", (
        f"expected BROKEN verdict for "
        f"install_mode={install_mode!r}, proxy={make_proxy}, "
        f"apps={make_apps}; got {summary.severity!r} "
        f"with message {summary.message!r}"
    )
    assert expected_substr in summary.message, (
        f"verdict message missing expected substring "
        f"{expected_substr!r}; got {summary.message!r}"
    )


def test_compute_health_summary_healthy_for_consistent_apps_mode(
    sentinel_paths: dict[str, Path],
) -> None:
    """Negative control: with consistent apps-mode state (apps-managed
    present, proxy-managed absent) the verdict must NOT regress to
    BROKEN. Guards against an over-eager drift check that fires in
    the steady state."""
    sentinel_paths["apps_managed"].write_text("apps\n2026-05-07T00:00:00+00:00\n")

    from halton_meter.lifecycle._macos import _compute_health_summary_macos

    rows = _make_rows_healthy()
    summary = _compute_health_summary_macos(rows, "apps")
    assert summary.severity == "HEALTHY", (
        f"consistent apps-mode state regressed to {summary.severity}; "
        f"message={summary.message!r}"
    )


def test_render_status_maps_broken_verdict_to_pill_broken_glyph(
    sentinel_paths: dict[str, Path],
) -> None:
    """v0.1.22.12 Bug 3: end-to-end check that a BROKEN verdict from
    ``_compute_health_summary_macos`` reaches the rendered status
    panel as the PILL_BROKEN glyph (✗) plus the BROKEN word."""
    # Drive a drift state — install-mode=apps, proxy-managed present.
    sentinel_paths["proxy_managed"].write_text("seed\n")

    from io import StringIO

    from rich.console import Console

    from halton_meter.branding import PILL_BROKEN
    from halton_meter.lifecycle._macos import (
        _compute_health_summary_macos,
        _render_status,
        _StatusReport,
    )

    rows = _make_rows_healthy()
    summary = _compute_health_summary_macos(rows, "apps")
    assert summary.severity == "BROKEN"

    report = _StatusReport(
        healthy=False,
        rows=rows,
        last_hour=0,
        last_day=0,
        platform="darwin",
        health_summary=summary,
    )

    buf = StringIO()
    console = Console(file=buf, width=120, force_terminal=False, color_system=None)
    _render_status(report, console)
    out = buf.getvalue()

    assert PILL_BROKEN in out, (
        "BROKEN verdict did not render the PILL_BROKEN glyph in the "
        "status panel"
    )
    assert "BROKEN" in out, "BROKEN verdict word missing from status output"
