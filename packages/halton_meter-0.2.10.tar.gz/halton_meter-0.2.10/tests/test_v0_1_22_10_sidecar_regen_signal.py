"""
Regression tests for v0.1.22.10 — edge-state.toml regen on SIGUSR1.

Background. The persistent edge (KeepAlive=True per B4 v0.1.22.3)
survives across daemon stop/start cycles. The edge writes
``edge-state.toml`` once via ``write_initial_state`` at its own
startup and removes it on its own clean shutdown. Once the file is
removed by anything else (or never existed when the edge was started
by an older binary that pre-dated the sidecar contract), the sidecar
stays missing for as long as the edge stays alive — even though the
edge IS alive and the contract says the file should exist.

Fix: SIGUSR1 → edge re-runs ``write_initial_state`` using its already
known bound port. Daemon dispatches the signal once, after its own
``daemon.startup.ready`` event, to the managed edge PID.

Tests verify both halves of the contract:
- Edge handler: re-emits the sidecar when the helper fires (uses the
  same write path as initial bind, atomic via ``os.replace``).
- Daemon dispatch: ``_signal_managed_edge_for_sidecar_regen`` resolves
  the edge PID via the v0.1.22.6/.9 helpers and sends SIGUSR1.
- Negative paths: dispatch when no edge is alive must not crash and
  must not log a misleading "requested" event.
- Idempotence: two regens in quick succession leave a valid sidecar.
"""

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path

import pytest

from halton_meter.edge import EdgeConfig, EdgeProxy
from halton_meter.port_alloc import read_edge_state_toml, write_edge_state_toml

# --------------------------------------------------------------------------- #
# Edge-side handler: regen helper rewrites the sidecar                         #
# --------------------------------------------------------------------------- #


async def test_edge_regen_rewrites_missing_sidecar(tmp_path) -> None:
    """The signal target. Calling ``write_initial_state`` after the
    sidecar was deleted re-creates it with the original chain target
    and PID. This is the exact code path the SIGUSR1 handler runs.
    """
    state_path = tmp_path / "edge-state.toml"
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=12345,
        runtime_path=tmp_path / "runtime.toml",
        state_path=state_path,
    )
    edge = EdgeProxy(config)
    bound_port = await edge.start()
    try:
        edge.write_initial_state(bound_edge_port=bound_port)
        assert state_path.exists()
        # Simulate "something else removed the sidecar" — the v0.1.22.10
        # repro on the user's machine.
        state_path.unlink()
        assert not state_path.exists()

        # Handler re-emit.
        edge.write_initial_state(bound_edge_port=bound_port)

        sidecar = read_edge_state_toml(state_path)
        assert sidecar.get("edge_port") == bound_port
        assert sidecar.get("chain_port") == 12345
        assert isinstance(sidecar.get("pid"), int)
    finally:
        await edge.stop()


async def test_edge_regen_is_idempotent(tmp_path) -> None:
    """Two regens in quick succession leave a valid sidecar. Atomic
    write via ``os.replace`` means there is never a window where a
    consumer sees a half-written file. Test exercises the same code
    path as ``write_edge_state_toml`` directly.
    """
    state_path = tmp_path / "edge-state.toml"
    write_edge_state_toml(state_path, edge_port=8082, chain_port=8090, pid=1)
    write_edge_state_toml(state_path, edge_port=8082, chain_port=8090, pid=1)
    out = read_edge_state_toml(state_path)
    assert out == {"edge_port": 8082, "chain_port": 8090, "pid": 1}
    # No leftover ``.tmp`` after the atomic replaces.
    assert not (tmp_path / "edge-state.toml.tmp").exists()


# --------------------------------------------------------------------------- #
# Daemon-side dispatch: _signal_managed_edge_for_sidecar_regen                 #
# --------------------------------------------------------------------------- #


def _import_dispatch():
    from halton_meter.cli import _signal_managed_edge_for_sidecar_regen

    return _signal_managed_edge_for_sidecar_regen


@pytest.mark.skipif(sys.platform != "darwin", reason="dispatch is macOS-only")
def test_dispatch_signals_managed_edge_when_alive(monkeypatch) -> None:
    """Happy path: managed edge is alive → SIGUSR1 sent to its PID."""
    fake_pid = 4242
    sent: list[tuple[int, int]] = []

    def fake_pid_lookup(label: str) -> int | None:
        return fake_pid

    def fake_kill(pid: int, sig: int) -> None:
        sent.append((pid, sig))

    monkeypatch.setattr(
        "halton_meter.port_alloc._macos_launchctl_label_pid",
        fake_pid_lookup,
    )
    monkeypatch.setattr(os, "kill", fake_kill)

    dispatch = _import_dispatch()
    dispatch()

    assert sent == [(fake_pid, signal.SIGUSR1)]


@pytest.mark.skipif(sys.platform != "darwin", reason="dispatch is macOS-only")
def test_dispatch_no_edge_alive_is_silent(monkeypatch) -> None:
    """No managed edge → no signal sent, no crash, no spurious log."""
    sent: list[tuple[int, int]] = []

    monkeypatch.setattr(
        "halton_meter.port_alloc._macos_launchctl_label_pid",
        lambda label: None,
    )
    monkeypatch.setattr(os, "kill", lambda pid, sig: sent.append((pid, sig)))

    dispatch = _import_dispatch()
    dispatch()  # Must not raise.

    assert sent == []


@pytest.mark.skipif(sys.platform != "darwin", reason="dispatch is macOS-only")
def test_dispatch_swallows_pid_gone_race(monkeypatch) -> None:
    """PID disappears between launchctl lookup and os.kill — the race
    must be swallowed; daemon startup must not fail."""
    monkeypatch.setattr(
        "halton_meter.port_alloc._macos_launchctl_label_pid",
        lambda label: 9999,
    )

    def boom(pid: int, sig: int) -> None:
        raise ProcessLookupError(f"no such pid {pid}")

    monkeypatch.setattr(os, "kill", boom)

    dispatch = _import_dispatch()
    dispatch()  # Must not raise.


@pytest.mark.skipif(sys.platform != "darwin", reason="dispatch is macOS-only")
def test_dispatch_swallows_permission_error(monkeypatch) -> None:
    """``os.kill`` raising PermissionError (e.g. SIP / cross-user) must
    not crash daemon startup."""
    monkeypatch.setattr(
        "halton_meter.port_alloc._macos_launchctl_label_pid",
        lambda label: 9999,
    )

    def boom(pid: int, sig: int) -> None:
        raise PermissionError("denied")

    monkeypatch.setattr(os, "kill", boom)

    dispatch = _import_dispatch()
    dispatch()  # Must not raise.


@pytest.mark.skipif(sys.platform != "darwin", reason="dispatch is macOS-only")
def test_dispatch_swallows_pid_lookup_error(monkeypatch) -> None:
    """If the launchctl-label PID lookup itself raises, the helper must
    not propagate the exception into daemon startup."""

    def boom(label: str) -> int | None:
        raise RuntimeError("launchctl exploded")

    monkeypatch.setattr(
        "halton_meter.port_alloc._macos_launchctl_label_pid",
        boom,
    )
    sent: list[tuple[int, int]] = []
    monkeypatch.setattr(os, "kill", lambda pid, sig: sent.append((pid, sig)))

    dispatch = _import_dispatch()
    dispatch()  # Must not raise.

    assert sent == []


# --------------------------------------------------------------------------- #
# Static / source-grep guards                                                  #
# --------------------------------------------------------------------------- #


def test_edge_main_installs_sigusr1_handler() -> None:
    """v0.1.22.10 invariant: edge_main.py registers a SIGUSR1 handler
    alongside the existing SIGINT/SIGTERM handlers, gated on
    ``hasattr(signal, "SIGUSR1")`` for Windows portability."""
    text = Path(
        "halton_meter/edge_main.py"
    ).read_text(encoding="utf-8")
    assert 'hasattr(signal, "SIGUSR1")' in text
    assert "loop.add_signal_handler(signal.SIGUSR1" in text
    assert "write_initial_state(bound_edge_port=bound_port)" in text
    # Cardinal rule for hot-path infra: the handler must not crash the
    # edge if the regen write fails.
    assert "edge.sidecar_regen_failed" in text


def test_cli_dispatches_after_startup_ready() -> None:
    """v0.1.22.10 invariant: the dispatch helper is invoked from the
    startup probe, AFTER ``daemon.startup.ready`` is logged. The
    ordering matters because the contract is "regen on the daemon's
    *successful* startup transition" — sending earlier would race a
    daemon that is itself about to fail its health probe."""
    text = Path("halton_meter/cli.py").read_text(encoding="utf-8")
    ready_pos = text.find('"daemon.startup.ready"')
    # Use rfind so we land on the call-site, not the helper's definition
    # (`def _signal_managed_edge_for_sidecar_regen()`).
    dispatch_pos = text.rfind("_signal_managed_edge_for_sidecar_regen()")
    assert ready_pos > 0
    assert dispatch_pos > ready_pos
    # Helper exists and has the structured-log event names the dispatch
    # path uses on success and on each negative branch.
    assert "def _signal_managed_edge_for_sidecar_regen" in text
    assert '"edge.sidecar_regen_requested"' in text


def test_existing_sigterm_sigint_handlers_untouched() -> None:
    """Hard invariant 4 from the v0.1.22.10 dispatch: do NOT modify the
    existing SIGTERM/SIGINT handlers — only ADD a SIGUSR1 handler
    alongside them. Source-grep guard catches future drift."""
    text = Path(
        "halton_meter/edge_main.py"
    ).read_text(encoding="utf-8")
    assert "for sig in (signal.SIGINT, signal.SIGTERM):" in text
    assert "loop.add_signal_handler(sig, _request_stop)" in text
