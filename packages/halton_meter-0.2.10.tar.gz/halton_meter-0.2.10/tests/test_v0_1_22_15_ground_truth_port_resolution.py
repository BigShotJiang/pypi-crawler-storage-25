"""v0.1.22.15 — ground-truth port resolution + freshness gate.

The v0.1.22.14 user soak surfaced a temporal race between
``halton-meter start``'s post-kickstart panel and the new daemon's
write of ``effective-ports.json``. ``load_effective_config`` reads the
JSON directly; the panel called it tens of milliseconds after
``launchctl kickstart`` returned, before the new daemon process had
overwritten the file. The JSON still held the previous generation's
``pid + api_port`` tuple, so the panel probed the wrong port and
post-success liveness flipped a healthy daemon to red.

The fix is a new ``resolve_effective_port_ground_truth`` helper with:

1. lsof retry on the launchctl-managed daemon PID (default 8 × 250ms).
2. freshness-gated JSON fallback (the JSON's ``pid`` field must match
   the live launchctl PID).
3. cfg_value as the last resort.

The start panel + post-success liveness wire to the new helper. The
status panel + doctor were audited and switched to the same helper
(retries=1) so a stale ``effective-ports.json`` cannot poison those
surfaces either.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from halton_meter import port_alloc
from halton_meter.lifecycle import _macos as lifecycle_macos

# --------------------------------------------------------------------------- #
# resolve_effective_port_ground_truth — chain                                 #
# --------------------------------------------------------------------------- #


def test_ground_truth_picks_lsof_first_no_sleep_needed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When lsof returns immediately, no retry / no sleep / no JSON read."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: [8765]
    )
    sleep_calls: list[float] = []

    result = port_alloc.resolve_effective_port_ground_truth(
        role="api",
        cfg_value=8765,
        sleep=lambda s: sleep_calls.append(s),
    )

    assert result == 8765
    assert sleep_calls == []


def test_ground_truth_freshness_gate_rejects_stale_json(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """JSON pid mismatch with launchctl pid → JSON treated as stale."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    # No lsof result — forces JSON fallback.
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: []
    )
    # Live daemon PID is 12345.
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )

    # JSON claims pid=99999 (stale, e.g. previous daemon generation).
    eff_path = tmp_path / "effective-ports.json"
    eff_path.write_text(
        '{"pid": 99999, "api_port": 8766, "internal_port": 8090, '
        '"edge_port": 8081, "schema_version": 1}'
    )
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    result = port_alloc.resolve_effective_port_ground_truth(
        role="api",
        cfg_value=8765,
        retries=1,
        sleep=lambda _s: None,
    )

    # Stale JSON is rejected — falls through to cfg_value.
    assert result == 8765, "stale JSON must NOT poison the resolution"


def test_ground_truth_freshness_gate_accepts_fresh_json(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """JSON pid matches launchctl pid → JSON is fresh; use it."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: []
    )
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )

    eff_path = tmp_path / "effective-ports.json"
    eff_path.write_text(
        '{"pid": 12345, "api_port": 8766, "internal_port": 8090, '
        '"edge_port": 8081, "schema_version": 1}'
    )
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    result = port_alloc.resolve_effective_port_ground_truth(
        role="api",
        cfg_value=8765,
        retries=1,
        sleep=lambda _s: None,
    )

    assert result == 8766


def test_ground_truth_retry_loop_resolves_when_port_appears_late(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """lsof returns nothing for first 4 attempts, then 8765 → resolved.

    Models the start-panel race: kickstart returns before uvicorn has
    bound; the retry loop waits long enough for the bind to complete.
    """
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )
    call_count = {"n": 0}

    def lsof_late(_pid: int) -> list[int]:
        call_count["n"] += 1
        if call_count["n"] <= 4:
            return []
        return [8765]

    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lsof_late
    )
    sleeps: list[float] = []

    result = port_alloc.resolve_effective_port_ground_truth(
        role="api",
        cfg_value=8090,  # wrong cfg — must come from lsof
        retries=8,
        retry_delay_s=0.25,
        sleep=lambda s: sleeps.append(s),
    )

    assert result == 8765
    # 5 lsof attempts → 4 sleeps between them.
    assert call_count["n"] == 5
    assert len(sleeps) == 4
    assert all(s == 0.25 for s in sleeps)


def test_ground_truth_retry_loop_gives_up_at_retries_count(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """lsof never returns → loop runs ``retries`` times then falls through.

    Sleeps happen between attempts only — N retries means N-1 sleeps.
    """
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: []
    )
    sleeps: list[float] = []
    # No JSON.
    monkeypatch.setattr(
        port_alloc,
        "EFFECTIVE_PORTS_JSON_PATH",
        Path("/tmp/this-file-does-not-exist-v0_1_22_15"),
    )

    result = port_alloc.resolve_effective_port_ground_truth(
        role="api",
        cfg_value=8765,
        retries=8,
        retry_delay_s=0.25,
        sleep=lambda s: sleeps.append(s),
    )

    # All attempts failed → cfg_value falls through.
    assert result == 8765
    # 8 lsof attempts means 7 sleeps between them.
    assert len(sleeps) == 7


def test_ground_truth_lsof_none_fresh_json_used_when_pid_matches(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """lsof permanently None + fresh JSON → JSON used (panel would still
    have an answer rather than escalating)."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: []
    )
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )

    eff_path = tmp_path / "effective-ports.json"
    eff_path.write_text(
        '{"pid": 12345, "api_port": 8765, "internal_port": 8090, '
        '"edge_port": 8081, "schema_version": 1}'
    )
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    result = port_alloc.resolve_effective_port_ground_truth(
        role="api",
        cfg_value=9999,
        retries=2,
        sleep=lambda _s: None,
    )

    assert result == 8765


def test_ground_truth_lsof_none_stale_json_falls_to_cfg(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """lsof permanently None + stale JSON → cfg_value (fail-safe)."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: []
    )
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: None
    )

    eff_path = tmp_path / "effective-ports.json"
    eff_path.write_text(
        '{"pid": 99999, "api_port": 8766, "internal_port": 8090, '
        '"edge_port": 8081, "schema_version": 1}'
    )
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    result = port_alloc.resolve_effective_port_ground_truth(
        role="api",
        cfg_value=8765,
        retries=2,
        sleep=lambda _s: None,
    )

    # No live launchctl pid → freshness gate cannot pass → cfg_value.
    assert result == 8765


def test_ground_truth_rejects_unknown_role() -> None:
    with pytest.raises(ValueError):
        port_alloc.resolve_effective_port_ground_truth(
            role="bogus", cfg_value=1234
        )


def test_ground_truth_edge_role_uses_edge_pid_field(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """For role=edge the freshness gate compares ``edge_pid`` against
    the edge label's launchctl pid (the daemon's ``pid`` field is
    irrelevant for edge — it's stamped by a different writer)."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: []
    )

    # Distinct PIDs per label so we can verify the right one was queried.
    def label_pid(label: str) -> int | None:
        if label == port_alloc._MANAGED_EDGE_LAUNCHD_LABEL:
            return 4242
        return 12345  # daemon

    monkeypatch.setattr(port_alloc, "_macos_launchctl_label_pid", label_pid)

    eff_path = tmp_path / "effective-ports.json"
    # ``pid`` is the daemon pid (12345); ``edge_pid`` is the edge pid (4242).
    eff_path.write_text(
        '{"pid": 12345, "edge_pid": 4242, "api_port": 8765, '
        '"internal_port": 8090, "edge_port": 8082, "schema_version": 1}'
    )
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    result = port_alloc.resolve_effective_port_ground_truth(
        role="edge",
        cfg_value=8081,
        retries=1,
        sleep=lambda _s: None,
    )

    assert result == 8082


def test_ground_truth_edge_freshness_rejects_stale_edge_pid(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """role=edge with mismatched ``edge_pid`` → JSON rejected."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: []
    )

    def label_pid(label: str) -> int | None:
        if label == port_alloc._MANAGED_EDGE_LAUNCHD_LABEL:
            return 4242
        return 12345

    monkeypatch.setattr(port_alloc, "_macos_launchctl_label_pid", label_pid)

    eff_path = tmp_path / "effective-ports.json"
    eff_path.write_text(
        '{"pid": 12345, "edge_pid": 99999, "api_port": 8765, '
        '"internal_port": 8090, "edge_port": 8082, "schema_version": 1}'
    )
    monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)

    result = port_alloc.resolve_effective_port_ground_truth(
        role="edge",
        cfg_value=8081,
        retries=1,
        sleep=lambda _s: None,
    )

    assert result == 8081, "stale edge_pid must not be trusted"


# --------------------------------------------------------------------------- #
# Post-success liveness re-resolves the port via the helper                   #
# --------------------------------------------------------------------------- #


def test_post_success_liveness_uses_resolved_port_callable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The post-success liveness probe calls ``resolved_api_port()`` at
    re-probe time so a port that changed between initial probe and
    re-probe is still hit correctly. This is the v0.1.22.14 bug — the
    cached port pointed to the previous generation's :8766 while the
    daemon was healthy on :8765, and the re-probe failed a healthy
    daemon."""
    # Skip the sleep.
    monkeypatch.setattr(
        lifecycle_macos, "_POST_SUCCESS_LIVENESS_DELAY_S", 0.0
    )

    probed_ports: list[int] = []

    def fake_poll(port: int, timeout: float) -> tuple[bool, float | None]:
        probed_ports.append(port)
        return (True, 1.0)

    monkeypatch.setattr(
        lifecycle_macos, "_poll_health_with_latency", fake_poll
    )

    result = lifecycle_macos._start_post_success_liveness(
        resolved_api_port=lambda: 8765
    )

    assert result is True
    assert probed_ports == [8765]


def test_post_success_liveness_resolved_port_overrides_legacy_arg(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When both legacy ``api_port`` and ``resolved_api_port`` are
    supplied, the callable wins. Models the bug shape: cached port
    8766 was wrong; ground-truth resolution at re-probe time returns
    8765."""
    monkeypatch.setattr(
        lifecycle_macos, "_POST_SUCCESS_LIVENESS_DELAY_S", 0.0
    )
    probed: list[int] = []
    monkeypatch.setattr(
        lifecycle_macos,
        "_poll_health_with_latency",
        lambda p, timeout: (probed.append(p), (True, 1.0))[1],
    )

    lifecycle_macos._start_post_success_liveness(
        api_port=8766,  # stale cache
        resolved_api_port=lambda: 8765,  # ground truth
    )

    assert probed == [8765]


def test_post_success_liveness_back_compat_legacy_signature(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The pre-v0.1.22.15 call shape ``_start_post_success_liveness(api_port)``
    still works (existing v0.1.22.4 tests rely on this)."""
    monkeypatch.setattr(
        lifecycle_macos, "_POST_SUCCESS_LIVENESS_DELAY_S", 0.0
    )
    probed: list[int] = []
    monkeypatch.setattr(
        lifecycle_macos,
        "_poll_health_with_latency",
        lambda p, timeout: (probed.append(p), (True, 1.0))[1],
    )

    result = lifecycle_macos._start_post_success_liveness(8765)

    assert result is True
    assert probed == [8765]


# --------------------------------------------------------------------------- #
# v0.1.22.9 helper untouched (regression guard)                               #
# --------------------------------------------------------------------------- #


def test_v0_1_22_9_managed_label_listening_port_unchanged(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The v0.1.22.9 ``_managed_label_listening_port`` helper signature
    + behaviour MUST remain identical — v0.1.22.15 extends usage, not
    the helper itself."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: 12345
    )
    monkeypatch.setattr(
        port_alloc, "_macos_lsof_listen_ports_for_pid", lambda _pid: [9999]
    )

    assert (
        port_alloc._managed_label_listening_port("com.example.label") == 9999
    )


def test_v0_1_22_9_resolve_effective_port_default_unchanged(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``resolve_effective_port`` must keep its byte-identical
    pre-v0.1.22.15 behaviour: no retry, no freshness gate. The new
    surface is ``resolve_effective_port_ground_truth``."""
    monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
    monkeypatch.setattr(
        port_alloc, "_macos_launchctl_label_pid", lambda _label: None
    )
    # Stale JSON (pid mismatch) must STILL be honoured by the legacy
    # ``resolve_effective_port`` — the v0.1.22.9 contract is "JSON is
    # last-known-good kernel-confirmed state". Only the new helper
    # adds the freshness gate.
    import tempfile

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as fh:
        fh.write(
            '{"pid": 99999, "api_port": 8766, "internal_port": 8091, '
            '"edge_port": 8082}'
        )
        eff_path = Path(fh.name)
    try:
        monkeypatch.setattr(port_alloc, "EFFECTIVE_PORTS_JSON_PATH", eff_path)
        # Legacy: stale JSON IS used (pre-v0.1.22.15 behaviour).
        assert (
            port_alloc.resolve_effective_port(role="api", cfg_value=8765)
            == 8766
        )
    finally:
        eff_path.unlink()
