"""Tests for the edge process's system-proxy restore on shutdown (v0.1.22 Fix 1).

The ``_restore_proxy_on_shutdown`` helper is called from the ``finally``
block of ``run_edge()`` when the edge receives SIGTERM (e.g. at machine
shutdown).  It should:

* Be a no-op when the proxy-managed sentinel is absent (--apps mode).
* Be a no-op when system_state.json is absent (nothing snapshotted).
* Call ``system_proxy.restore_system_proxy("127.0.0.1", port)`` when both
  sentinel and state file exist.
* Never raise — any exception is swallowed and logged.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import halton_meter.edge_main as edge_main_mod
from halton_meter.edge_main import _restore_proxy_on_shutdown


class TestRestoreProxyOnShutdown:
    def test_skipped_when_no_sentinel(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """No sentinel → restore_system_proxy must never be called."""
        # Point sentinel at a path that does not exist.
        monkeypatch.setattr(
            edge_main_mod, "_PROXY_MANAGED_SENTINEL_PATH", tmp_path / "proxy-managed"
        )
        monkeypatch.setattr(
            edge_main_mod, "_SYSTEM_STATE_PATH", tmp_path / "system_state.json"
        )
        called: list[tuple] = []

        def _fake_restore(host: str, port: int) -> bool:
            called.append((host, port))
            return True

        import halton_meter.system_proxy as sp_mod

        monkeypatch.setattr(sp_mod, "restore_system_proxy", _fake_restore)

        _restore_proxy_on_shutdown(8082)

        assert called == [], "restore_system_proxy must not be called when no sentinel"

    def test_skipped_when_no_state_file(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Sentinel present but system_state.json absent → no restore."""
        sentinel = tmp_path / "proxy-managed"
        sentinel.touch()
        monkeypatch.setattr(edge_main_mod, "_PROXY_MANAGED_SENTINEL_PATH", sentinel)
        monkeypatch.setattr(
            edge_main_mod, "_SYSTEM_STATE_PATH", tmp_path / "system_state.json"
        )
        called: list[tuple] = []

        import halton_meter.system_proxy as sp_mod

        monkeypatch.setattr(
            sp_mod, "restore_system_proxy", lambda h, p: called.append((h, p)) or True
        )

        _restore_proxy_on_shutdown(8082)

        assert called == [], "restore_system_proxy must not be called when no state file"

    def test_restore_called_when_both_present(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Both sentinel and state file present → restore called with correct args."""
        sentinel = tmp_path / "proxy-managed"
        sentinel.touch()
        state_file = tmp_path / "system_state.json"
        state_file.write_text("{}", encoding="utf-8")

        monkeypatch.setattr(edge_main_mod, "_PROXY_MANAGED_SENTINEL_PATH", sentinel)
        monkeypatch.setattr(edge_main_mod, "_SYSTEM_STATE_PATH", state_file)

        called: list[tuple] = []

        import halton_meter.system_proxy as sp_mod

        monkeypatch.setattr(
            sp_mod, "restore_system_proxy", lambda h, p: called.append((h, p)) or True
        )

        _restore_proxy_on_shutdown(8082)

        assert called == [("127.0.0.1", 8082)], (
            f"Expected restore_system_proxy called with ('127.0.0.1', 8082); got {called}"
        )

    def test_restore_swallows_exception(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """If restore_system_proxy raises, the exception must not propagate."""
        sentinel = tmp_path / "proxy-managed"
        sentinel.touch()
        state_file = tmp_path / "system_state.json"
        state_file.write_text("{}", encoding="utf-8")

        monkeypatch.setattr(edge_main_mod, "_PROXY_MANAGED_SENTINEL_PATH", sentinel)
        monkeypatch.setattr(edge_main_mod, "_SYSTEM_STATE_PATH", state_file)

        import halton_meter.system_proxy as sp_mod

        def _raise(host: str, port: int) -> bool:
            raise RuntimeError("networksetup exploded")

        monkeypatch.setattr(sp_mod, "restore_system_proxy", _raise)

        # Must not raise — exception is swallowed inside the helper.
        _restore_proxy_on_shutdown(8082)
