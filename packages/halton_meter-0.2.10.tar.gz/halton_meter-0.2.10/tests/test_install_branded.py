"""Tests for the branded install / uninstall display layer (v0.1.22.16).

The branding sits on top of the existing ``install_module.install`` /
``install_module.uninstall`` orchestrators. Direct callers (the existing
test_install.py / test_init.py suites) bypass this layer entirely — those
tests assert on the raw ``[halton-meter] xxx`` stderr line stream, which
remains unchanged when ``set_quiet=False`` and capture is off.

What's tested here:
  * ``_macos.start_capture`` / ``stop_capture`` collects the raw event
    stream when active, and ``_print`` keeps emitting to stderr unless
    ``set_quiet(True)`` is set.
  * ``_branded_display.render_init_supervisor_section`` collapses 4
    plist-write events + 4 bootstrap events + 2 kickstart events into
    three branded step rows.
  * ``_branded_display.render_uninstall_sections`` produces the three
    section headers (``sentinels and state``, ``launchd supervisors``,
    ``system proxy``) with collapsed step rows.
  * The CLI ``uninstall`` callback emits the ``[H]`` masthead, the
    branded sections, and the closing ``halton-meter — uninstalled``
    panel; the destructive WARNING block survives (callout form).
  * ``HALTON_DEBUG=1`` short-circuits the branded path so the legacy
    verbose ``[halton-meter] xxx`` lines flow as before.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner
from rich.console import Console

from halton_meter import install as install_module
from halton_meter.install import _branded_display
from halton_meter.install import _macos as _install_macos

# --------------------------------------------------------------------------- #
# capture machinery                                                            #
# --------------------------------------------------------------------------- #


def test_start_stop_capture_collects_print_events() -> None:
    """The capture buffer collects every ``_print`` call between start
    and stop, with the ``[halton-meter]`` prefix stripped."""
    _install_macos.start_capture()
    _install_macos._print("writing /tmp/foo.plist")
    _install_macos._print("removed /tmp/bar")
    events = _install_macos.stop_capture()
    assert events == ["writing /tmp/foo.plist", "removed /tmp/bar"]


def test_capture_does_not_disable_stderr_by_default(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Capture is orthogonal to set_quiet — direct callers (tests) keep
    seeing the legacy stderr stream when set_quiet=False."""
    _install_macos.start_capture()
    try:
        _install_macos._print("hello world")
    finally:
        _install_macos.stop_capture()
    err = capsys.readouterr().err
    assert "[halton-meter] hello world" in err


def test_set_quiet_silences_stderr_under_capture(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """The branded display path uses set_quiet(True) + start_capture()
    together; stderr stays clean and the buffer still collects events."""
    _install_macos.set_quiet(True)
    _install_macos.start_capture()
    try:
        _install_macos._print("writing /tmp/foo.plist")
    finally:
        _install_macos.set_quiet(False)
        events = _install_macos.stop_capture()
    err = capsys.readouterr().err
    assert "[halton-meter]" not in err
    assert events == ["writing /tmp/foo.plist"]


# --------------------------------------------------------------------------- #
# init supervisor section renderer                                             #
# --------------------------------------------------------------------------- #


def test_render_init_supervisor_section_collapses_events() -> None:
    """Four plist writes + four bootstraps + two kickstarts collapse into
    a single branded step row each (≤3 rows total)."""
    events = [
        "writing /Users/test/Library/LaunchAgents/com.haltonlabs.meter.plist",
        "writing /Users/test/Library/LaunchAgents/com.haltonlabs.meter.watchdog.plist",
        "writing /Users/test/Library/LaunchAgents/com.haltonlabs.meter.edge.plist",
        "writing /Users/test/Library/LaunchAgents/com.haltonlabs.meter.userenv.plist",
        "launchctl bootout com.haltonlabs.meter; bootstrap gui/501 ...",
        "launchctl bootout com.haltonlabs.meter.watchdog; bootstrap gui/501 ...",
        "launchctl bootout com.haltonlabs.meter.edge; bootstrap gui/501 ...",
        "launchctl bootout com.haltonlabs.meter.userenv; bootstrap gui/501 ...",
        "launchctl kickstart -k gui/501/com.haltonlabs.meter",
        "launchctl kickstart -k gui/501/com.haltonlabs.meter.watchdog",
        "daemon + watchdog + edge + userenv installed; launchd will keep ...",
    ]
    console = Console(record=True, width=100, force_terminal=True)
    _branded_display.render_init_supervisor_section(console, events)
    out = console.export_text()
    assert "supervisor (launchd)" in out
    # Three condensed rows, no per-plist spam.
    assert "Wrote 4 plists" in out
    assert "Bootstrapped" in out
    assert "Kicked daemon + watchdog" in out
    # The 11 raw events do NOT each appear as their own line.
    assert out.count("\n") < 10


def test_render_init_supervisor_section_handles_idempotent_run() -> None:
    """Re-running init against a healthy install: every plist already
    matches, no kickstart fires (depending on launchd state). The
    section still renders without raising."""
    events = [
        "plist unchanged: /Users/test/Library/LaunchAgents/com.haltonlabs.meter.plist",
        "plist unchanged: /Users/test/Library/LaunchAgents/com.haltonlabs.meter.watchdog.plist",
        "plist unchanged: /Users/test/Library/LaunchAgents/com.haltonlabs.meter.edge.plist",
        "plist unchanged: /Users/test/Library/LaunchAgents/com.haltonlabs.meter.userenv.plist",
        "launchctl bootout com.haltonlabs.meter; bootstrap gui/501 ...",
        "launchctl bootout com.haltonlabs.meter.watchdog; bootstrap gui/501 ...",
    ]
    console = Console(record=True, width=100, force_terminal=True)
    _branded_display.render_init_supervisor_section(console, events)
    out = console.export_text()
    assert "supervisor (launchd)" in out
    # Idempotent line uses the muted "unchanged" copy, not "Wrote N plists".
    assert "unchanged" in out


# --------------------------------------------------------------------------- #
# uninstall section renderer                                                   #
# --------------------------------------------------------------------------- #


def test_render_uninstall_sections_emits_three_headers() -> None:
    events = [
        "removed /Users/test/.halton-meter/proxy-managed",
        "removed /Users/test/.halton-meter/apps-managed",
        "launchctl unsetenv: HTTPS_PROXY, HTTP_PROXY, NO_PROXY, ALL_PROXY",
        "launchctl unload /Users/test/Library/LaunchAgents/com.haltonlabs.meter.plist",
        "removed /Users/test/Library/LaunchAgents/com.haltonlabs.meter.plist",
        "launchctl unload /Users/test/Library/LaunchAgents/com.haltonlabs.meter.watchdog.plist",
        "removed /Users/test/Library/LaunchAgents/com.haltonlabs.meter.watchdog.plist",
        "launchctl unload /Users/test/Library/LaunchAgents/com.haltonlabs.meter.edge.plist",
        "removed /Users/test/Library/LaunchAgents/com.haltonlabs.meter.edge.plist",
        "launchctl unload /Users/test/Library/LaunchAgents/com.haltonlabs.meter.userenv.plist",
        "removed /Users/test/Library/LaunchAgents/com.haltonlabs.meter.userenv.plist",
        "system proxy reset on Wi-Fi",
        "system proxy reset on Thunderbolt Bridge",
        "system proxy reset on iPhone USB",
        "removed edge proxy",
    ]
    console = Console(record=True, width=120, force_terminal=True)
    _branded_display.render_uninstall_sections(console, events)
    out = console.export_text()
    assert "sentinels and state" in out
    assert "launchd supervisors" in out
    assert "system proxy" in out
    # Collapsed step rows, not 14 raw lines.
    assert "Unloaded + removed 4 supervisor plists" in out
    assert "Cleared launchctl user-domain env" in out
    assert "Reset on 3 interfaces" in out
    assert "Removed edge proxy" in out


def test_render_purge_section_picks_up_data_wipe_event() -> None:
    events = [
        "removed /Users/test/.halton-meter (database preserved)",
    ]
    console = Console(record=True, width=120, force_terminal=True)
    _branded_display.render_purge_section(console, events)
    out = console.export_text()
    assert "data wipe" in out
    assert "database preserved" in out


# --------------------------------------------------------------------------- #
# debug-mode opt-out                                                           #
# --------------------------------------------------------------------------- #


def test_debug_mode_enabled_respects_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HALTON_DEBUG", raising=False)
    assert _branded_display.debug_mode_enabled() is False
    monkeypatch.setenv("HALTON_DEBUG", "1")
    assert _branded_display.debug_mode_enabled() is True


# --------------------------------------------------------------------------- #
# CLI uninstall masthead + closing panel                                       #
# --------------------------------------------------------------------------- #


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))  # type: ignore[arg-type]
    return tmp_path


def test_cli_uninstall_renders_masthead_and_closing_panel(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The CLI ``uninstall`` callback prints the ``[H]`` masthead, the
    branded sections, and the closing ``halton-meter — uninstalled``
    panel with the warning callout."""
    monkeypatch.setenv("HALTON_DEBUG", "")  # ensure branded path
    monkeypatch.delenv("HALTON_DEBUG", raising=False)
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy._macos,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._macos._MACOS_INTERFACE_FALLBACK,
    )

    # Stub subprocess so launchctl + networksetup are no-ops.
    import subprocess

    class _NullRun:
        def __call__(self, argv, *a, **kw):  # type: ignore[no-untyped-def]
            return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(install_module.subprocess, "run", _NullRun())

    from halton_meter.cli import cli

    runner = CliRunner()
    result = runner.invoke(cli, ["uninstall", "--yes"])
    # Exit code 0 on successful uninstall.
    assert result.exit_code == 0, result.output
    out = result.output
    # Masthead with the [H] inline mark.
    assert "[H]" in out
    assert "halton-meter" in out
    assert "uninstall" in out
    # Closing panel.
    assert "uninstalled" in out
    # Destructive warning callout (default = non-graceful).
    assert "lose connectivity" in out
    # --purge hint surfaces on the non-purge path.
    assert "--purge" in out


def test_cli_uninstall_debug_mode_skips_branded_layer(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``HALTON_DEBUG=1`` skips capture / branded sections so the
    legacy ``[halton-meter] xxx`` stream survives for forensics."""
    monkeypatch.setenv("HALTON_DEBUG", "1")
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy._macos,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._macos._MACOS_INTERFACE_FALLBACK,
    )
    import subprocess

    class _NullRun:
        def __call__(self, argv, *a, **kw):  # type: ignore[no-untyped-def]
            return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(install_module.subprocess, "run", _NullRun())

    from halton_meter.cli import cli

    runner = CliRunner()
    result = runner.invoke(cli, ["uninstall", "--yes"])
    assert result.exit_code == 0, result.output
    # In debug mode the legacy [halton-meter] lines flow to stderr.
    # Click's CliRunner captures stderr separately; the masthead still
    # prints (it's outside the branded toggle).
    assert "[halton-meter]" in result.output
