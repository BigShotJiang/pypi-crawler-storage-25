"""Tests for ``POST /v1/cloud/connect`` — browser-triggered pairing.

These exercise the request path with the outbound ``CloudClient``
monkey-patched. We don't talk to a real cloud here — that's covered by
``tests/cloud/test_pairing_handshake.py``. The point of these tests is
to lock in:

  * 409 when the daemon is already paired
  * 503 when no cloud endpoint is configured
  * 202 + pairing_code returned on a successful start
  * the same handshake can be polled via ``GET /v1/cloud/connect/status``
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from halton_meter.api.routers import cloud_connect as cc_module
from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import CloudState


@pytest.fixture(autouse=True)
def reset_active_pairing():
    """Each test starts with an empty active-pairing slot."""
    cc_module._active = None
    yield
    cc_module._active = None


@pytest.fixture
def stub_cloud_endpoint(monkeypatch):
    """Pretend the daemon has a configured cloud endpoint.

    The router captured ``load_cloud_config`` at import-time via
    ``from halton_meter.cloud.config_glue import load_cloud_config``,
    so we patch the binding in the router's namespace rather than the
    source module.
    """

    class _Cfg:
        enabled = True
        base_url = "https://api.haltonmeter.com"
        continuous = True
        sync_interval_seconds = 30

        @property
        def is_active(self) -> bool:
            return True

    monkeypatch.setattr(cc_module, "load_cloud_config", lambda *a, **kw: _Cfg())


@pytest.fixture
def stub_pairing_start_success(monkeypatch):
    """Stub CloudClient.pairing_start to return a deterministic payload.

    We also block the background poll task from doing any real work by
    stubbing pairing_poll to return ``pending`` forever — the tests
    that care about the approval path call _drive_pairing_poll
    directly with their own poll stub.
    """

    async def fake_start(self, *, hostname, daemon_version, platform):
        return {
            "pairing_code": "XK4M-9P2A",
            "pairing_url": "https://app.haltonmeter.com/connect?code=XK4M-9P2A",
            "expires_at": (datetime.now(tz=UTC) + timedelta(minutes=10)).isoformat(),
            "poll_token": "test-poll-token",
        }

    async def fake_poll(self, *, pairing_code, poll_token):
        return {"status": "pending"}

    from halton_meter.cloud.client import CloudClient

    monkeypatch.setattr(CloudClient, "pairing_start", fake_start)
    monkeypatch.setattr(CloudClient, "pairing_poll", fake_poll)


async def test_connect_503_when_no_endpoint(client, monkeypatch):
    """No cloud configured → caller gets a 503 with a clear hint."""

    class _Empty:
        enabled = False
        base_url = ""
        continuous = True
        sync_interval_seconds = 30

        @property
        def is_active(self) -> bool:
            return False

    monkeypatch.setattr(cc_module, "load_cloud_config", lambda *a, **kw: _Empty())

    resp = await client.post("/v1/cloud/connect", json={})
    assert resp.status_code == 503
    detail = resp.json()["detail"]
    assert detail["error"] == "no_endpoint"
    assert "config.toml" in detail["hint"]


async def test_connect_202_returns_pairing_code(
    client,
    stub_cloud_endpoint,
    stub_pairing_start_success,
):
    """Happy path: 202 + pairing_code + pairing_url in the body."""
    resp = await client.post("/v1/cloud/connect", json={})
    assert resp.status_code == 202
    data = resp.json()
    assert data["state"] == "awaiting_approval"
    assert data["pairing_code"] == "XK4M-9P2A"
    assert data["pairing_url"].endswith("?code=XK4M-9P2A")
    assert data["expires_at"] is not None
    assert data["error"] is None
    # poll_token MUST NOT be exposed — it's daemon-only.
    assert "poll_token" not in data

    # Cancel the polling task so we don't leak it past the test.
    if cc_module._active and cc_module._active.task:
        cc_module._active.task.cancel()


async def test_connect_409_when_already_paired(client, stub_cloud_endpoint, db_path):
    """Daemon with an enabled cloud_state row refuses fresh pairing."""
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        session.add(
            CloudState(
                endpoint="https://api.haltonmeter.com",
                workspace_id="11111111-1111-4111-8111-111111111111",
                workspace_name="Acme",
                enabled=True,
                connected_at=datetime.now(tz=UTC),
            )
        )

    resp = await client.post("/v1/cloud/connect", json={})
    assert resp.status_code == 409
    detail = resp.json()["detail"]
    assert detail["error"] == "already_paired"
    assert detail["workspace_name"] == "Acme"
    assert "disconnect" in detail["hint"]


async def test_connect_409_when_handshake_in_flight_returns_same_code(
    client,
    stub_cloud_endpoint,
    stub_pairing_start_success,
):
    """Double-clicking Pair returns the in-flight handshake's code, not 409."""
    r1 = await client.post("/v1/cloud/connect", json={})
    assert r1.status_code == 202
    code = r1.json()["pairing_code"]

    r2 = await client.post("/v1/cloud/connect", json={})
    assert r2.status_code == 202
    assert r2.json()["pairing_code"] == code

    if cc_module._active and cc_module._active.task:
        cc_module._active.task.cancel()


async def test_status_returns_idle_when_no_active(client):
    """No POST yet → status reports idle."""
    resp = await client.get("/v1/cloud/connect/status")
    assert resp.status_code == 200
    assert resp.json()["state"] == "idle"


async def test_status_mirrors_active_pairing(
    client,
    stub_cloud_endpoint,
    stub_pairing_start_success,
):
    """After a successful POST, GET /status carries the same code."""
    started = await client.post("/v1/cloud/connect", json={})
    code = started.json()["pairing_code"]

    resp = await client.get("/v1/cloud/connect/status")
    assert resp.status_code == 200
    data = resp.json()
    assert data["state"] == "awaiting_approval"
    assert data["pairing_code"] == code

    if cc_module._active and cc_module._active.task:
        cc_module._active.task.cancel()
