"""Tests for ``GET /v1/cloud/state`` — paired-state probe."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from halton_meter import __version__
from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import CloudState


async def test_state_unpaired_when_no_row(client):
    """Default daemon — no pairing ever happened — returns paired=False."""
    resp = await client.get("/v1/cloud/state")
    assert resp.status_code == 200
    data = resp.json()
    assert data["paired"] is False
    assert data["workspace_id"] is None
    assert data["enabled"] is False
    assert data["daemon_version"] == __version__
    assert isinstance(data["hostname"], str) and data["hostname"]
    assert data["platform"] in ("Darwin", "Linux", "Windows", "")


@pytest.fixture
async def seed_paired_state(db_path):
    """Seed a fully-paired cloud_state row."""
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        session.add(
            CloudState(
                endpoint="https://api.haltonmeter.com",
                workspace_id="11111111-1111-4111-8111-111111111111",
                workspace_name="Acme",
                machine_id="22222222-2222-4222-8222-222222222222",
                hostname_reported="seed-host",
                base_url="https://api.haltonmeter.com",
                enabled=True,
                connected_at=datetime.now(tz=UTC),
            )
        )


async def test_state_paired_when_row_enabled(client, seed_paired_state):
    resp = await client.get("/v1/cloud/state")
    assert resp.status_code == 200
    data = resp.json()
    assert data["paired"] is True
    assert data["workspace_id"] == "11111111-1111-4111-8111-111111111111"
    assert data["workspace_name"] == "Acme"
    assert data["machine_id"] == "22222222-2222-4222-8222-222222222222"
    assert data["enabled"] is True
    assert data["base_url"] == "https://api.haltonmeter.com"
    assert data["paused_reason"] is None
    # API key never leaks through this endpoint.
    assert "api_key" not in data
    assert "api_key_ciphertext" not in data


@pytest.fixture
async def seed_disabled_state(db_path):
    """A previously-paired daemon that's had ``cloud disconnect`` run."""
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        session.add(
            CloudState(
                endpoint="https://api.haltonmeter.com",
                workspace_id="11111111-1111-4111-8111-111111111111",
                workspace_name="Acme",
                enabled=False,
                connected_at=datetime.now(tz=UTC),
            )
        )


async def test_state_not_paired_when_disabled(client, seed_disabled_state):
    """An ``enabled=false`` row counts as unpaired for onboarding purposes."""
    resp = await client.get("/v1/cloud/state")
    assert resp.status_code == 200
    data = resp.json()
    assert data["paired"] is False
    # We still expose workspace metadata so the dashboard can surface
    # "this daemon was previously paired to <workspace>, re-pair?".
    assert data["workspace_id"] == "11111111-1111-4111-8111-111111111111"
    assert data["enabled"] is False


@pytest.fixture
async def seed_paused_state(db_path):
    """A paired daemon whose cloud worker is paused (auth error, quota, etc.)."""
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        session.add(
            CloudState(
                endpoint="https://api.haltonmeter.com",
                workspace_id="11111111-1111-4111-8111-111111111111",
                workspace_name="Acme",
                enabled=True,
                connected_at=datetime.now(tz=UTC),
                paused_reason="auth_error",
            )
        )


async def test_state_surfaces_paused_reason(client, seed_paused_state):
    resp = await client.get("/v1/cloud/state")
    assert resp.status_code == 200
    data = resp.json()
    assert data["paired"] is True
    assert data["paused_reason"] == "auth_error"


async def test_state_pna_header_present(client):
    """Chrome PNA: the daemon must return Allow-Private-Network on every response."""
    resp = await client.get("/v1/cloud/state")
    assert resp.status_code == 200
    assert resp.headers.get("access-control-allow-private-network") == "true"
