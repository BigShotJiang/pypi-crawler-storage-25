"""Tests for ``halton-meter pricing set / list / reset`` (v0.1.22.22, Layer 2).

Covers:
  * ``set_override`` inserts a new override row, supersedes the prior
    seed, and inherits unset rates from the active row.
  * ``list_rates`` returns both seeds and overrides; provider filter works.
  * ``reset_overrides`` deletes overrides and reopens the seed row(s).
  * The CLI surface (`pricing list / set / reset`) round-trips end-to-end.
  * ``recompute_costs`` consults overrides first when a request's
    ``requested_at`` falls inside the override window, and falls back
    to the seed row for older windows. Verifies historical-recompute
    correctness.
"""

from __future__ import annotations

import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
import pytest_asyncio
from click.testing import CliRunner

from halton_meter.cli import cli
from halton_meter.pricing_cli import (
    list_rates,
    millicents_to_usd_per_mtok,
    reset_overrides,
    set_override,
    usd_per_mtok_to_millicents,
)
from halton_meter.recompute_costs import recompute_costs
from halton_meter.storage import init_db, seed_pricing_rates
from halton_meter.storage.engine import _ENGINES, create_engine_for, dispose_engines


@pytest.fixture(autouse=True)
def _reset_engine_cache():
    _ENGINES.clear()
    yield
    _ENGINES.clear()


@pytest_asyncio.fixture
async def seeded_db_path(tmp_path: Path) -> Path:
    p = tmp_path / "pricing-cli-test.sqlite"
    engine, sessionmaker = create_engine_for(p)
    await init_db(engine)
    async with sessionmaker() as session:
        await seed_pricing_rates(session)
    await dispose_engines()
    return p


# ── unit conversion ────────────────────────────────────────────────────────


def test_usd_to_millicents_round_trip() -> None:
    assert usd_per_mtok_to_millicents(3.00) == 300_000
    assert usd_per_mtok_to_millicents(0.15) == 15_000
    assert usd_per_mtok_to_millicents(0.025) == 2_500
    assert millicents_to_usd_per_mtok(300_000) == 3.0


def test_usd_to_millicents_rejects_negative() -> None:
    with pytest.raises(ValueError):
        usd_per_mtok_to_millicents(-1.0)


# ── set / list / reset ─────────────────────────────────────────────────────


def test_set_override_supersedes_seed_and_inherits_rates(seeded_db_path: Path) -> None:
    result = set_override(
        seeded_db_path,
        provider="anthropic",
        model="claude-sonnet-4-6",
        mode="standard",
        input_usd_per_mtok=4.00,
        output_usd_per_mtok=20.00,
    )
    assert result.superseded_id is not None
    assert result.inserted_id != result.superseded_id

    # The new row's other rates are inherited from the prior seed row.
    rates = [
        r
        for r in list_rates(seeded_db_path)
        if r.provider == "anthropic"
        and r.model == "claude-sonnet-4-6"
        and r.mode == "standard"
    ]
    overrides = [r for r in rates if not r.is_seed_default]
    seeds = [r for r in rates if r.is_seed_default]
    assert len(overrides) == 1
    assert len(seeds) == 1
    assert overrides[0].input_rate == 400_000
    assert overrides[0].output_rate == 2_000_000
    # Inherited from the seed.
    assert overrides[0].cache_read_rate == seeds[0].cache_read_rate
    # Seed row was superseded — its effective_to is now non-NULL.
    assert seeds[0].effective_to is not None


def test_set_override_requires_at_least_one_rate(seeded_db_path: Path) -> None:
    with pytest.raises(ValueError):
        set_override(
            seeded_db_path,
            provider="anthropic",
            model="claude-sonnet-4-6",
            mode="standard",
        )


def test_list_rates_provider_filter(seeded_db_path: Path) -> None:
    all_rates = list_rates(seeded_db_path)
    anthropic_only = list_rates(seeded_db_path, provider="anthropic")
    assert len(anthropic_only) < len(all_rates)
    assert all(r.provider == "anthropic" for r in anthropic_only)


def test_reset_overrides_idempotent(seeded_db_path: Path) -> None:
    set_override(
        seeded_db_path,
        provider="anthropic",
        model="claude-sonnet-4-6",
        mode="standard",
        input_usd_per_mtok=99.0,
        output_usd_per_mtok=99.0,
    )
    first = reset_overrides(seeded_db_path)
    assert first.rows_deleted == 1
    assert first.rows_reopened == 1
    second = reset_overrides(seeded_db_path)
    assert second.rows_deleted == 0
    assert second.rows_reopened == 0

    # After reset, the seed row is the active row again (effective_to=NULL).
    seeds = [
        r
        for r in list_rates(seeded_db_path)
        if r.provider == "anthropic"
        and r.model == "claude-sonnet-4-6"
        and r.mode == "standard"
    ]
    assert len(seeds) == 1
    assert seeds[0].is_seed_default is True
    assert seeds[0].effective_to is None


def test_reset_overrides_scoped_filter(seeded_db_path: Path) -> None:
    """Filters compose with AND — non-matching overrides survive."""
    set_override(
        seeded_db_path,
        provider="anthropic",
        model="claude-sonnet-4-6",
        mode="standard",
        input_usd_per_mtok=4.0,
        output_usd_per_mtok=20.0,
    )
    set_override(
        seeded_db_path,
        provider="anthropic",
        model="claude-haiku-4-5",
        mode="standard",
        input_usd_per_mtok=2.0,
        output_usd_per_mtok=10.0,
    )
    result = reset_overrides(
        seeded_db_path,
        provider="anthropic",
        model="claude-sonnet-4-6",
    )
    assert result.rows_deleted == 1
    assert result.rows_reopened == 1
    overrides = [r for r in list_rates(seeded_db_path) if not r.is_seed_default]
    assert len(overrides) == 1
    assert overrides[0].model == "claude-haiku-4-5"


# ── CLI surface end-to-end ─────────────────────────────────────────────────


def test_cli_pricing_list_set_reset_round_trip(seeded_db_path: Path) -> None:
    runner = CliRunner()

    # list (no overrides yet)
    res = runner.invoke(
        cli, ["pricing", "list", "--db", str(seeded_db_path), "--provider", "anthropic"]
    )
    assert res.exit_code == 0, res.output
    assert "Bundled rates date" in res.output
    assert "0 override" in res.output

    # set
    res = runner.invoke(
        cli,
        [
            "pricing",
            "set",
            "anthropic",
            "claude-sonnet-4-6",
            "--input",
            "4.00",
            "--output",
            "20.00",
            "--db",
            str(seeded_db_path),
        ],
    )
    assert res.exit_code == 0, res.output
    assert "Recorded pricing override" in res.output

    # list (one override visible). We invoke a wide terminal so the
    # model column doesn't get Rich-truncated.
    res = runner.invoke(
        cli,
        ["pricing", "list", "--db", str(seeded_db_path), "--provider", "anthropic"],
        env={"COLUMNS": "200"},
    )
    assert res.exit_code == 0, res.output
    assert "Operator overrides" in res.output
    assert "1 override" in res.output
    assert "claude-sonnet-4-6" in res.output

    # reset
    res = runner.invoke(
        cli, ["pricing", "reset", "--db", str(seeded_db_path)]
    )
    assert res.exit_code == 0, res.output
    assert "Removed 1 override" in res.output


def test_cli_pricing_set_rejects_no_rates(seeded_db_path: Path) -> None:
    runner = CliRunner()
    res = runner.invoke(
        cli,
        [
            "pricing",
            "set",
            "anthropic",
            "claude-sonnet-4-6",
            "--db",
            str(seeded_db_path),
        ],
    )
    assert res.exit_code != 0
    assert "No rate supplied" in res.output


# ── recompute-costs honours overrides ──────────────────────────────────────


def test_recompute_costs_uses_override_for_recent_rows(seeded_db_path: Path) -> None:
    """A row captured *after* an override was set must be repriced
    against the override; rows captured before stay on the seed.

    Sequence of operations matters: we set the override first, then
    insert requests at carefully-chosen timestamps on either side of
    the override's ``effective_from``. The ``recompute_costs`` pass
    must reprice the post-override request and leave the pre-override
    request alone.
    """
    import uuid

    # 1. Set a 10x override now. effective_from = "set time".
    set_result = set_override(
        seeded_db_path,
        provider="anthropic",
        model="claude-sonnet-4-6",
        mode="standard",
        input_usd_per_mtok=30.00,
        output_usd_per_mtok=150.00,
    )

    # 2. Read the override's effective_from straight from the DB so the
    #    test is exact about ordering rather than racing the wall clock.
    conn = sqlite3.connect(str(seeded_db_path))
    try:
        eff_from_row = conn.execute(
            "SELECT effective_from FROM pricing_rates WHERE id = ?",
            (set_result.inserted_id,),
        ).fetchone()
        assert eff_from_row is not None
        eff_from = datetime.strptime(
            eff_from_row[0], "%Y-%m-%d %H:%M:%S.%f"
        ).replace(tzinfo=UTC)
    finally:
        conn.close()

    old_at = eff_from - timedelta(days=10)
    new_at = eff_from + timedelta(seconds=30)
    expected_seed_cost = 1_800  # 1k in + 1k out at $3/$15 = (300k + 15M)/1M

    # 3. Insert one pre- and one post-override request. The pre-override
    #    row is stamped with the seed cost; the post-override row is
    #    intentionally stamped with the *seed* cost too so the recompute
    #    pass has a delta to apply.
    conn = sqlite3.connect(str(seeded_db_path))
    try:
        proj_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO projects (id, name, slug, created_at) "
            "VALUES (?, ?, ?, ?)",
            (
                proj_id,
                "test",
                "test",
                eff_from.strftime("%Y-%m-%d %H:%M:%S.%f"),
            ),
        )
        for at in (old_at, new_at):
            conn.execute(
                "INSERT INTO requests (id, project_id, provider, model, mode, "
                "input_tokens, output_tokens, thinking_tokens, "
                "cache_read_tokens, cache_write_tokens, "
                "cost_usd_minor_units, tokens_complete, "
                "requested_at, recorded_at, status) "
                "VALUES (?, ?, ?, ?, 'standard', 1000, 1000, 0, 0, 0, ?, 1, ?, ?, 'success')",
                (
                    str(uuid.uuid4()),
                    proj_id,
                    "anthropic",
                    "claude-sonnet-4-6",
                    expected_seed_cost,
                    at.strftime("%Y-%m-%d %H:%M:%S.%f"),
                    at.strftime("%Y-%m-%d %H:%M:%S.%f"),
                ),
            )
        conn.commit()
    finally:
        conn.close()

    result = recompute_costs(seeded_db_path)

    # Expectation: only the post-override row is repriced.
    assert result.rows_updated == 1
    expected_override_cost = (
        1000 * 3_000_000 + 1000 * 15_000_000
    ) // 1_000_000
    assert result.new_total_millicents == expected_override_cost
    assert result.old_total_millicents == expected_seed_cost

    # Re-run is idempotent — the post-override row is now at the override
    # value, so a second pass updates nothing.
    second = recompute_costs(seeded_db_path)
    assert second.rows_updated == 0
