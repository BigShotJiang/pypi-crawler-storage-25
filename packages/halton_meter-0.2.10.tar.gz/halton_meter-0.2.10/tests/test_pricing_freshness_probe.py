"""Tests for the doctor pricing-freshness probe (v0.1.22.22, Layer 3).

The probe must be fail-open in every failure mode and must never
disrupt the rest of doctor's report. We use ``httpx.MockTransport`` to
exercise each branch without touching the network. The opt-out env
var (``HALTON_METER_NO_RATES_PROBE=1``) bypasses the probe entirely.
"""

from __future__ import annotations

import json

import httpx
import pytest

from halton_meter.doctor import _pricing_freshness_row
from halton_meter.pricing import BUNDLED_RATES_DATE


def _transport_returning(payload: dict | str | None, status: int = 200) -> httpx.MockTransport:
    """Build an httpx.MockTransport that returns ``payload`` for every request."""

    def handler(request: httpx.Request) -> httpx.Response:
        if isinstance(payload, str):
            return httpx.Response(status, content=payload.encode("utf-8"))
        if payload is None:
            return httpx.Response(status)
        return httpx.Response(status, json=payload)

    return httpx.MockTransport(handler)


def test_freshness_ok_when_bundled_matches_manifest() -> None:
    transport = _transport_returning(
        {
            "latest_bundle_date": BUNDLED_RATES_DATE,
            "min_supported_date": "2026-04-01",
            "providers_changed_since": [],
        }
    )
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "ok"
    assert BUNDLED_RATES_DATE in row.summary


def test_freshness_warn_when_bundled_older_than_manifest() -> None:
    # Manifest published a date strictly newer than what's bundled.
    transport = _transport_returning(
        {
            "latest_bundle_date": "2099-12-31",
            "min_supported_date": "2026-04-01",
            "providers_changed_since": ["anthropic/claude-opus-4-7"],
        }
    )
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "warn"
    assert "older than" in row.summary
    assert row.next_action is not None
    assert "pipx upgrade" in row.next_action
    assert row.raw["manifest_latest"] == "2099-12-31"


def test_freshness_fail_open_on_network_error() -> None:
    def boom(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("simulated outage")

    transport = httpx.MockTransport(boom)
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "ok"
    assert "manifest unreachable" in row.summary
    assert row.raw.get("error") == "ConnectError"


def test_freshness_fail_open_on_invalid_json() -> None:
    transport = _transport_returning("not-json-at-all", status=200)
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "ok"
    assert "manifest unreachable" in row.summary or "manifest malformed" in row.summary


def test_freshness_fail_open_on_missing_field() -> None:
    transport = _transport_returning({"foo": "bar"})
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "ok"
    assert "manifest malformed" in row.summary


def test_freshness_fail_open_on_unparseable_date() -> None:
    transport = _transport_returning({"latest_bundle_date": "not-a-date"})
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "ok"
    assert "date parse failed" in row.summary


def test_freshness_opt_out_skips_probe(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``HALTON_METER_NO_RATES_PROBE=1`` must bypass any HTTP fetch."""

    called = {"n": 0}

    def boom(_request: httpx.Request) -> httpx.Response:
        called["n"] += 1
        raise AssertionError("transport must not be hit when probe is disabled")

    monkeypatch.setenv("HALTON_METER_NO_RATES_PROBE", "1")
    transport = httpx.MockTransport(boom)
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "ok"
    assert "probe disabled" in row.summary
    assert called["n"] == 0


def test_freshness_fail_open_on_http_error_status() -> None:
    transport = _transport_returning("forbidden", status=403)
    row = _pricing_freshness_row(transport=transport)
    assert row.icon == "ok"
    assert "manifest unreachable" in row.summary


def test_repo_root_manifest_is_valid_json_with_required_fields() -> None:
    """Sanity-check the committed rates-manifest.json."""
    from pathlib import Path

    repo_root = Path(__file__).resolve().parents[2]
    manifest_path = repo_root / "rates-manifest.json"
    assert manifest_path.exists(), f"missing {manifest_path}"
    data = json.loads(manifest_path.read_text("utf-8"))
    assert isinstance(data, dict)
    assert "latest_bundle_date" in data
    # The committed manifest must match the bundled-matrix date —
    # bumping the constant without bumping the manifest would silently
    # warn every running daemon when this version ships.
    assert data["latest_bundle_date"] == BUNDLED_RATES_DATE
