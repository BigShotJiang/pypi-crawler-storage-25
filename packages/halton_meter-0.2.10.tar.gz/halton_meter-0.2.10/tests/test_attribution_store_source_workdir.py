"""
Tests for source_workdir storage in attribution_store (v0.2.10).

Covers:
* write/lookup with source_workdir round-trip
* write/lookup without source_workdir returns None workdir
* Migration guard: existing DBs without the column get ALTER TABLE'd
* tagging.py propagates the cached workdir from a store hit
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest

import halton_meter.tagging as tagging_mod
from halton_meter import attribution_store
from halton_meter.tagging import resolve_project_with_meta


@pytest.fixture(autouse=True)
def _isolate_singleton(tmp_path: Path):
    """Wire each test to a fresh SQLite file; reset on teardown."""
    attribution_store.set_db_path(tmp_path / "attrib.sqlite")
    yield
    attribution_store.set_db_path(None)


# ---------------------------------------------------------------------------
# write / lookup with source_workdir
# ---------------------------------------------------------------------------


def test_write_with_workdir_then_lookup_returns_tuple() -> None:
    """write(..., source_workdir=...) → lookup returns (project, workdir)."""
    attribution_store.write(
        60001, "my-project", source_workdir="/Users/dev/my-project"
    )
    result = attribution_store.lookup(60001)
    assert result == ("my-project", "/Users/dev/my-project")


def test_write_without_workdir_then_lookup_returns_none_workdir() -> None:
    """write without source_workdir → lookup returns (project, None)."""
    attribution_store.write(60002, "another-project")
    result = attribution_store.lookup(60002)
    assert result == ("another-project", None)


def test_write_workdir_overwrite_updates_workdir() -> None:
    """Second write with different workdir overwrites the first."""
    attribution_store.write(60003, "proj", source_workdir="/old/path")
    attribution_store.write(60003, "proj", source_workdir="/new/path")
    result = attribution_store.lookup(60003)
    assert result == ("proj", "/new/path")


def test_write_workdir_tilde_path() -> None:
    """Tilde-containing paths are stored and returned verbatim."""
    attribution_store.write(60004, "proj", source_workdir="~/Documents/proj")
    result = attribution_store.lookup(60004)
    assert result == ("proj", "~/Documents/proj")


# ---------------------------------------------------------------------------
# Migration guard: ALTER TABLE for existing DBs
# ---------------------------------------------------------------------------


def test_migration_guard_adds_column_to_existing_db(tmp_path: Path) -> None:
    """An existing DB without source_workdir gets the column added on open.

    Simulates a DB written by an older daemon version that didn't have
    source_workdir. After the migration guard runs, lookup must return
    a 2-tuple with None for the missing column.
    """
    db_path = tmp_path / "old.sqlite"

    # Create the DB with the old schema (no source_workdir column).
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attribution_log (
            edge_src_port INTEGER PRIMARY KEY,
            project_name TEXT NOT NULL,
            created_at REAL NOT NULL,
            body_capture_enabled BOOLEAN NOT NULL DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_attribution_log_created_at
            ON attribution_log(created_at)
    """)
    # Write a row in the old schema (no source_workdir).
    conn.execute(
        "INSERT INTO attribution_log "
        "(edge_src_port, project_name, created_at, body_capture_enabled) "
        "VALUES (?, ?, ?, ?)",
        (70001, "legacy-project", 1000.0, 1),
    )
    conn.commit()
    conn.close()

    # Now wire the store to the old DB and open it through the normal path.
    # The migration guard should add source_workdir without error.
    attribution_store.set_db_path(db_path)
    result = attribution_store.lookup(70001)

    # The migrated row should return the project name with None workdir.
    assert result == ("legacy-project", None)

    # After migration, we can write new rows with a workdir.
    attribution_store.write(70002, "new-project", source_workdir="/some/path")
    assert attribution_store.lookup(70002) == ("new-project", "/some/path")


def test_migration_guard_idempotent_on_fresh_db() -> None:
    """Running against a fresh DB (column already present) does not error.

    The migration guard catches 'duplicate column' and continues. This
    test verifies the happy path on a DB created by the current schema.
    """
    # The autouse fixture already wired a fresh DB. Write + read normally.
    attribution_store.write(70003, "proj", source_workdir="/path/to/proj")
    assert attribution_store.lookup(70003) == ("proj", "/path/to/proj")


# ---------------------------------------------------------------------------
# tagging.py Step 0: workdir propagated from cache
# ---------------------------------------------------------------------------


def test_tagging_step0_propagates_workdir_from_cache(tmp_path: Path) -> None:
    """tagging.py Step 0 returns source_workdir stored in attribution_log.

    When the edge writes a row with a source_workdir, the daemon's
    tagging.py Step 0 cache hit must surface it in ResolvedProject.
    """
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    attribution_store.write(
        54321, "edge-project", source_workdir="/Users/dev/edge-project"
    )

    cc = tflow.tclient_conn()
    cc.peername = ("127.0.0.1", 54321)
    flow = tflow.tflow(client_conn=cc)

    # Mock _get_process_cwd to confirm it's NOT called on a cache hit.
    called: list[int] = []

    def _should_not_be_called(*args: object, **kwargs: object) -> str | None:
        called.append(1)
        return None

    with patch.object(tagging_mod, "_get_process_cwd", side_effect=_should_not_be_called):
        meta = resolve_project_with_meta(flow, edge_port=8081)

    assert meta.project == "edge-project"
    assert meta.method == "edge_store"
    assert meta.source_workdir == "/Users/dev/edge-project"
    assert called == []  # cache hit — psutil walk skipped


def test_tagging_step0_workdir_none_when_not_stored(tmp_path: Path) -> None:
    """tagging.py Step 0 returns source_workdir=None when not set in DB."""
    pytest.importorskip("mitmproxy", reason="mitmproxy not installed")
    from mitmproxy.test import tflow

    attribution_store.write(54322, "edge-project-no-workdir")

    cc = tflow.tclient_conn()
    cc.peername = ("127.0.0.1", 54322)
    flow = tflow.tflow(client_conn=cc)

    with patch.object(tagging_mod, "_get_process_cwd", return_value=None):
        meta = resolve_project_with_meta(flow, edge_port=8081)

    assert meta.project == "edge-project-no-workdir"
    assert meta.method == "edge_store"
    assert meta.source_workdir is None
