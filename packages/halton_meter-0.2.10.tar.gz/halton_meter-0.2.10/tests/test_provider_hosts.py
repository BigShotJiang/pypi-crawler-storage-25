"""Unit tests for the LLM-host allowlist (v0.1.22.24).

The allowlist is load-bearing: it decides whether a CONNECT chains into
the metering daemon or passes through transparently. Bugs here either
silently drop metering coverage (missed cost) or break unrelated traffic
(workflow disruption — cardinal-rule violation). Both failure modes are
worse than the bug, so the helper gets a dedicated test file.
"""

from __future__ import annotations

import re

import pytest

from halton_meter.providers.hosts import (
    LLM_INTERCEPT_HOSTS,
    LLM_INTERCEPT_SUFFIXES,
    host_should_intercept,
    mitmproxy_ignore_hosts_regex,
)


@pytest.mark.parametrize(
    "host",
    [
        "api.anthropic.com",
        "api.openai.com",
        "chatgpt.com",
        "generativelanguage.googleapis.com",
        "cloudcode-pa.googleapis.com",
        "api.x.ai",
        "aiplatform.googleapis.com",
    ],
)
def test_exact_hosts_match(host: str) -> None:
    assert host_should_intercept(host)
    assert host_should_intercept(f"{host}:443")
    # Case-insensitive (DNS).
    assert host_should_intercept(host.upper())
    # Trailing-dot FQDN form is also accepted.
    assert host_should_intercept(f"{host}.")


@pytest.mark.parametrize(
    "host",
    [
        "foo.bedrock.amazonaws.com",
        "us-east-1.bedrock-runtime.amazonaws.com",
        "us-central1-aiplatform.googleapis.com",
    ],
)
def test_suffix_hosts_match(host: str) -> None:
    assert host_should_intercept(host)
    assert host_should_intercept(f"{host}:443")


@pytest.mark.parametrize(
    "host",
    [
        # Suffix-bypass attack — must NOT match.
        "bedrock.amazonaws.com.evil.example",
        "api.anthropic.com.evil.example",
        "evil.api.anthropic.com",
        # Generic non-LLM hosts.
        "github.com",
        "registry.npmjs.org",
        "sentry.io",
        "googleapis.com",  # bare TLD-ish — too broad, must be rejected
        "amazonaws.com",
        # Empty / malformed.
        "",
        ":",
    ],
)
def test_non_llm_hosts_reject(host: str) -> None:
    assert not host_should_intercept(host)


def test_allowlist_population_sane() -> None:
    """Tripwire — if anyone ever empties the allowlist, this test
    fails loudly rather than silently disabling metering."""
    assert len(LLM_INTERCEPT_HOSTS) >= 6
    assert "api.anthropic.com" in LLM_INTERCEPT_HOSTS
    assert any(s.endswith("amazonaws.com") for s in LLM_INTERCEPT_SUFFIXES)


def test_mitmproxy_ignore_hosts_regex_is_unsafe_under_search() -> None:
    """Pin the known-bad behaviour of ``mitmproxy_ignore_hosts_regex()``.

    Why this test exists (v0.1.22.25 ADR — ``memory/decisions.md``
    2026-05-11): the helper was wired into mitmproxy's ``ignore_hosts``
    option in v0.1.22.24 as belt-and-braces around the edge's
    allowlist gate. mitmproxy consumes ``ignore_hosts`` via
    ``re.search`` — not ``re.match`` — and although the helper's regex
    is anchored with ``^``, an IP-form CONNECT (e.g. Anthropic's own
    A-record ``160.79.104.10:443``) matches the "ignore" branch under
    ``re.search``. That would tunnel the flow raw and silently drop
    metering coverage. The wiring has been removed; the helper is
    retained here only to document the trap, and this test asserts the
    trap is real so nobody re-wires it without first making the helper
    safe under ``re.search`` semantics.

    Concretely the test pins:

    * LLM hosts pass ``pattern.match`` cleanly — they do NOT match the
      "ignore" branch (so under a ``re.match`` consumer they would be
      intercepted, the intended behaviour).
    * ``pattern.search`` against an IP-form host like
      ``160.79.104.10:443`` returns a match — i.e. the helper would
      mark an Anthropic IP-form CONNECT as "tunnel raw", silently
      bypassing metering when consumed via ``re.search``.

    If you make the helper safe under ``re.search`` (e.g. by anchoring
    differently, normalising the input, or detecting IP-form hosts),
    update this test AND the v0.1.22.25 ADR together, and remove the
    structural guard in ``test_proxy_no_ignore_hosts.py``.
    """
    pattern = re.compile(mitmproxy_ignore_hosts_regex())

    # 1. LLM hosts pass pattern.match cleanly — the intended behaviour
    # under a re.match consumer.
    for h in (
        "api.anthropic.com:443",
        "api.openai.com:443",
        "us-east-1.bedrock-runtime.amazonaws.com:443",
        "aiplatform.googleapis.com:443",
    ):
        assert pattern.match(h) is None, h

    # 2. The unsafe trap: an IP-form host for an Anthropic A record
    # gets matched as "ignore" under pattern.search. mitmproxy uses
    # re.search, so wiring this helper into ``ignore_hosts`` would
    # tunnel the flow raw and silently drop metering coverage for any
    # client that resolved the LLM host itself and CONNECTed by IP.
    ip_form_anthropic = "160.79.104.10:443"
    assert pattern.search(ip_form_anthropic) is not None, (
        "Expected the helper to be unsafe under re.search against "
        "IP-form Anthropic CONNECTs — if this assertion now fails, "
        "the helper has been fixed; update the v0.1.22.25 ADR and "
        "drop the structural guard in test_proxy_no_ignore_hosts.py."
    )

    # 3. Non-LLM hosts still match (correct, but not load-bearing once
    # the helper is unwired). Kept so the pinned behaviour is fully
    # described, not just the unsafe part.
    for h in (
        "github.com:443",
        "registry.npmjs.org:443",
        "haltonmeter.com:443",
        "evil.api.anthropic.com:443",
    ):
        assert pattern.match(h) is not None, h
