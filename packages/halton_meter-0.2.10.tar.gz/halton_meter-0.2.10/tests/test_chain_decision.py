"""Edge chain-vs-passthrough decision (v0.1.22.24).

These tests exist because of the v0.1.22.23 cardinal-rule violation:
the edge was chaining EVERY CONNECT into the daemon's mitmproxy port,
including non-LLM hosts (github.com, registry.npmjs.org, …). When the
mitmproxy listener was unhealthy or returned 502 for a host it couldn't
mint a leaf cert for, those non-LLM tools broke. The fix is to gate
chaining on a host allowlist; passthrough is the default.

The existing ``test_edge.py`` integration tests already cover the
healthy-daemon LLM-host path (``test_edge_chains_when_daemon_healthy``)
— those tests would have continued to pass even with the bug, because
they used ``api.anthropic.com``. The tests below pin the *negative*
case (non-LLM host with healthy daemon must NOT touch the daemon) and
the suffix-bypass attack surface.
"""

from __future__ import annotations

import asyncio
import contextlib

import pytest

from halton_meter.edge import EdgeConfig, EdgeProxy

# Reuse the integration-quality fakes from the main edge test module.
# They speak the exact wire shape ``EdgeProxy`` cares about.
from tests.test_edge import (  # type: ignore[import-not-found]
    FakeDaemon,
    FakeUpstream,
    _send_through_edge,
)


@pytest.fixture
async def edge_with_fakes():
    daemon = FakeDaemon()
    upstream = FakeUpstream()
    daemon_port = await daemon.start()
    upstream_port = await upstream.start()
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=daemon_port,
        probe_port=daemon_port,
        healthy_ttl_s=0.05,
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.5,
    )
    edge = EdgeProxy(config)
    edge_port = await edge.start()
    serve_task = asyncio.create_task(edge.serve_forever(), name="edge-serve")
    try:
        # Warm health cache to "healthy" so chaining is on the table.
        assert await edge.health_cache.is_healthy() is True
        yield daemon, upstream, edge_port, upstream_port
    finally:
        await edge.stop()
        serve_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await serve_task
        await daemon.stop()
        await upstream.stop()


async def test_non_llm_connect_bypasses_mitm(edge_with_fakes) -> None:
    """Non-LLM CONNECT with healthy daemon must go directly to upstream
    and never open a socket to the internal mitm port."""
    daemon, upstream, edge_port, upstream_port = edge_with_fakes
    daemon_connects_before = len(daemon.connect_targets)
    daemon_health_probes_before = daemon.health_probes

    # CONNECT to a non-LLM host (use loopback upstream so we can read
    # back the upstream banner and confirm passthrough actually went
    # there — and not into the FakeDaemon's CONNECT echo path).
    response = await _send_through_edge(
        edge_port,
        f"CONNECT 127.0.0.1:{upstream_port} HTTP/1.1\r\n"
        f"Host: 127.0.0.1:{upstream_port}\r\n\r\n".encode("ascii"),
        extra_payload=b"hello",
    )
    assert b"200 Connection Established" in response
    assert b"UPSTREAM" in response
    assert upstream.connections_seen == 1
    # Daemon CONNECT count must not advance — we never touched the mitm
    # port. (Health probes from the cache may still have happened
    # before the request landed; we ignore those.)
    assert len(daemon.connect_targets) == daemon_connects_before
    # The daemon may have been health-probed in fixture warm-up; that's
    # fine. What matters is no NEW health probe was triggered to gate
    # this specific request — the allowlist check short-circuits before
    # the cache is consulted.
    assert daemon.health_probes >= daemon_health_probes_before


async def test_llm_connect_chains_through_mitm(edge_with_fakes) -> None:
    """CONNECT for ``api.anthropic.com`` chains through the daemon."""
    daemon, upstream, edge_port, _upstream_port = edge_with_fakes

    response = await _send_through_edge(
        edge_port,
        b"CONNECT api.anthropic.com:443 HTTP/1.1\r\n"
        b"Host: api.anthropic.com:443\r\n\r\n",
        extra_payload=b"x",
    )
    assert b"DAEMON_CHAINED" in response
    assert daemon.connect_targets == ["api.anthropic.com:443"]
    # Upstream must NOT have been contacted directly.
    assert upstream.connections_seen == 0


async def test_allowlist_suffix_match(edge_with_fakes) -> None:
    """Suffix-bypass defence.

    ``foo.bedrock.amazonaws.com`` chains (legitimate Bedrock regional
    shape). ``bedrock.amazonaws.com.evil.example`` does NOT — it goes
    through the passthrough path and never reaches the daemon.
    """
    daemon, _upstream, edge_port, _upstream_port = edge_with_fakes

    # Legitimate Bedrock regional host — should chain.
    # Note: the FakeDaemon doesn't care about the target hostname, it
    # echoes ``DAEMON_CHAINED`` for any CONNECT, so we just assert the
    # daemon recorded the target.
    await _send_through_edge(
        edge_port,
        b"CONNECT us-east-1.bedrock-runtime.amazonaws.com:443 HTTP/1.1\r\n"
        b"Host: us-east-1.bedrock-runtime.amazonaws.com:443\r\n\r\n",
        extra_payload=b"x",
    )
    assert any(
        t == "us-east-1.bedrock-runtime.amazonaws.com:443"
        for t in daemon.connect_targets
    )
    daemon_connects_after_bedrock = len(daemon.connect_targets)

    # Suffix-bypass attack — must passthrough, NOT chain. The CONNECT
    # target needs to resolve to *something* for the passthrough TCP
    # connect to succeed; we point it at the loopback upstream by using
    # ``127.0.0.1`` in the actual connect target's port. But we also
    # want the parsed host to be the attacker shape. The edge parses
    # the request line's host:port literally, so we use the attacker
    # shape directly and accept that the passthrough TCP connect will
    # fail (DNS or connect error) — the assertion we care about is
    # "daemon NOT touched", regardless of upstream outcome.
    with contextlib.suppress(Exception):
        await asyncio.wait_for(
            _send_through_edge(
                edge_port,
                b"CONNECT bedrock.amazonaws.com.evil.example:443 HTTP/1.1\r\n"
                b"Host: bedrock.amazonaws.com.evil.example:443\r\n\r\n",
                extra_payload=b"x",
            ),
            timeout=3.0,
        )
    # Daemon must not have gained a new chain target from the attack.
    assert len(daemon.connect_targets) == daemon_connects_after_bedrock
    assert not any(
        "evil.example" in t for t in daemon.connect_targets
    )
