"""Tests for the Phase 2 Wave 1A.i cloud-sync storage layer.

Covers:

  * ``test_new_fields_persist_round_trip``      — every contract §3 field
    written through ``StorageManager.write_record`` is readable back
    via ``cloud_unsynced_batch``.
  * ``test_cursor_advance_no_regression``       — ``cloud_advance_cursor``
    is idempotent + monotonic; a no-op advance to the same cursor does
    not leak failure counts or rotate ``last_batch_succeeded_at``
    backwards.
  * ``test_cursor_excludes_already_synced``     — selecting past a cursor
    excludes the cursor row itself and the strictly-prior rows.
  * ``test_cursor_tiebreak_on_id``              — two rows sharing
    ``recorded_at`` to the second are ordered by ``id`` so the cursor
    can advance past both.
  * ``test_cloud_state_encryption_round_trip``  — ``cloud_set_state`` /
    ``cloud_get_state`` round-trips an API key via the Fernet
    ciphertext column without ever persisting the plaintext.
  * ``test_cloud_state_clear_api_key``          — ``clear_api_key=True``
    wipes the ciphertext + fingerprint while preserving the audit row.
  * ``test_user_version_stamped``               — boot leaves
    ``PRAGMA user_version`` at :data:`CURRENT_USER_VERSION` (5).
  * ``test_phase2_tables_exist``                — the three new tables
    are created on a greenfield boot.

The tests use a real ``tmp_path`` SQLite file (no mocks), per
``memory/patterns.md``.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from sqlalchemy import text

from halton_meter.models import LogRecord
from halton_meter.storage import StorageManager
from halton_meter.storage.cloud_crypto import (
    decrypt_api_key,
    encrypt_api_key,
    fingerprint_api_key,
)
from halton_meter.storage.engine import CURRENT_USER_VERSION

ENDPOINT = "https://meter.example.test"


# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #


def _make_record(
    *,
    id: str | None = None,
    project: str = "wave-1a-i",
    requested_at: str = "2026-05-11T10:00:00Z",
    recorded_at: str = "2026-05-11T10:00:01Z",
    **overrides: object,
) -> LogRecord:
    """Build a LogRecord with the Phase-2 wire-contract fields populated."""
    base: dict[str, object] = {
        "id": id or str(uuid.uuid4()),
        "project": project,
        "provider": "anthropic",
        "model": "claude-sonnet-4-6",
        "input_tokens": 100,
        "output_tokens": 50,
        "thinking_tokens": 0,
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
        "cost_millicents": 1500,
        "tokens_complete": True,
        "latency_ms": 123.4,
        "requested_at": requested_at,
        "recorded_at": recorded_at,
        "status": "success",
        "attribution_method": "env",
        "source_workdir": "/Users/dev/proj",
        "source_machine": "dev-laptop-01",
        "request_kind": "chat",
        "time_to_first_token_ms": 420,
        "fx_rate": 0.7891,
        "prompt_hash": "f" * 64,
        "idempotency_key": "client-supplied-key-123",
    }
    base.update(overrides)
    return LogRecord(**base)  # type: ignore[arg-type]


@pytest.fixture(autouse=True)
def _isolate_cloud_key(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Redirect the Fernet key file to a tmp location for every test.

    The default path is ``~/.halton-meter/cloud.key``. Tests must not
    write into the real user's home — and a key file shared across
    parallel test workers would cause flaky decryption (different
    workers would generate competing keys).
    """
    key_file = tmp_path / "cloud.key"
    monkeypatch.setattr(
        "halton_meter.storage.cloud_crypto.DEFAULT_KEY_PATH",
        key_file,
    )
    # Sanity — confirm we didn't accidentally leave the real default
    # path leaking through. If this asserts, _isolate_cloud_key was
    # imported after the SUT module cached the original constant.
    from halton_meter.storage import cloud_crypto

    assert cloud_crypto.DEFAULT_KEY_PATH == key_file


# --------------------------------------------------------------------------- #
# Schema-level                                                                #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_user_version_stamped(tmp_path: Path) -> None:
    """A greenfield boot leaves the DB at the documented user_version."""
    db = tmp_path / "test.db"
    async with StorageManager(db) as storage:
        engine = storage._engine
        assert engine is not None
        async with engine.connect() as conn:
            result = await conn.exec_driver_sql("PRAGMA user_version")
            version = result.scalar_one()
    assert int(version) == CURRENT_USER_VERSION


@pytest.mark.asyncio
async def test_phase2_tables_exist(tmp_path: Path) -> None:
    """The three new Wave 1A.i tables are present after boot."""
    db = tmp_path / "test.db"
    async with StorageManager(db) as storage:
        engine = storage._engine
        assert engine is not None
        async with engine.connect() as conn:
            for table in (
                "cloud_sync_state",
                "cloud_state",
                "cloud_body_sync_state",
            ):
                result = await conn.execute(
                    text(
                        "SELECT name FROM sqlite_master "
                        "WHERE type='table' AND name=:n"
                    ),
                    {"n": table},
                )
                assert result.scalar_one_or_none() == table, (
                    f"expected {table!r} to exist after boot"
                )

            # The cursor index must exist too — the worker selects on it.
            result = await conn.execute(
                text(
                    "SELECT name FROM sqlite_master "
                    "WHERE type='index' AND name='idx_requests_cloud_cursor'"
                )
            )
            assert result.scalar_one_or_none() == "idx_requests_cloud_cursor"


# --------------------------------------------------------------------------- #
# Record persistence                                                          #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_new_fields_persist_round_trip(tmp_path: Path) -> None:
    """Every Phase-2 contract §3 field round-trips through the DB."""
    db = tmp_path / "test.db"
    record = _make_record()

    async with StorageManager(db) as storage:
        await storage.write_record(record)
        batch = await storage.cloud_unsynced_batch(limit=10)

    assert len(batch) == 1
    r = batch[0]
    assert r.id == record.id
    assert r.source_machine == "dev-laptop-01"
    assert r.request_kind == "chat"
    assert r.time_to_first_token_ms == 420
    # fx_rate is stored as Numeric(10,6); SQLite round-trips as float and
    # the 4-decimal input is preserved within REAL precision.
    assert r.fx_rate is not None
    assert abs(r.fx_rate - 0.7891) < 1e-6
    assert r.prompt_hash == "f" * 64
    assert r.idempotency_key == "client-supplied-key-123"
    assert r.attribution_method == "env"
    assert r.source_workdir == "/Users/dev/proj"
    assert r.status == "success"


# --------------------------------------------------------------------------- #
# Cursor                                                                      #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_cursor_advance_no_regression(tmp_path: Path) -> None:
    """Advancing the cursor twice to the same key is idempotent + monotonic.

    The worker is allowed to crash after a batch succeeds but before the
    cursor write commits — on restart it will re-ship the same batch and
    call ``cloud_advance_cursor`` with the same key. That must not throw
    and must not corrupt the row (e.g. by zeroing a succeeded timestamp
    or doubling consecutive_failures).
    """
    db = tmp_path / "test.db"
    async with StorageManager(db) as storage:
        rec_id = str(uuid.uuid4())
        recorded_at = "2026-05-11T10:00:01Z"

        await storage.cloud_advance_cursor(
            endpoint=ENDPOINT,
            record_id=rec_id,
            recorded_at=recorded_at,
            batch_id="batch-A",
        )
        state1 = await storage.cloud_get_sync_state(ENDPOINT)
        assert state1 is not None
        first_success = state1.last_batch_succeeded_at
        assert state1.last_synced_request_id == rec_id
        assert state1.consecutive_failures == 0

        # No-op replay: same cursor, same batch_id.
        await storage.cloud_advance_cursor(
            endpoint=ENDPOINT,
            record_id=rec_id,
            recorded_at=recorded_at,
            batch_id="batch-A",
        )
        state2 = await storage.cloud_get_sync_state(ENDPOINT)
        assert state2 is not None
        assert state2.last_synced_request_id == rec_id
        assert state2.consecutive_failures == 0
        # last_batch_succeeded_at may bump forward (we stamp now()) but
        # never backwards.
        assert (state2.last_batch_succeeded_at or first_success) >= first_success

        # Forward advance to a strictly-later cursor.
        rec_id2 = str(uuid.uuid4())
        await storage.cloud_advance_cursor(
            endpoint=ENDPOINT,
            record_id=rec_id2,
            recorded_at="2026-05-11T10:00:02Z",
            batch_id="batch-B",
        )
        state3 = await storage.cloud_get_sync_state(ENDPOINT)
        assert state3 is not None
        assert state3.last_synced_request_id == rec_id2
        assert state3.last_batch_id == "batch-B"


@pytest.mark.asyncio
async def test_cursor_excludes_already_synced(tmp_path: Path) -> None:
    """``cloud_unsynced_batch(cursor=...)`` excludes the cursor row itself."""
    db = tmp_path / "test.db"
    async with StorageManager(db) as storage:
        base = datetime(2026, 5, 11, 10, 0, 0, tzinfo=UTC)
        ids = []
        for i in range(5):
            ts = base + timedelta(seconds=i)
            rid = str(uuid.uuid4())
            ids.append(rid)
            await storage.write_record(
                _make_record(
                    id=rid,
                    requested_at=ts.isoformat().replace("+00:00", "Z"),
                    recorded_at=ts.isoformat().replace("+00:00", "Z"),
                )
            )

        # Read all to discover the canonical ordering by (recorded_at, id).
        all_rows = await storage.cloud_unsynced_batch(limit=100)
        assert len(all_rows) == 5

        # Advance past the second row's recorded_at.
        second = all_rows[1]
        cursor_at = datetime.fromisoformat(second.recorded_at.replace("Z", "+00:00"))
        remaining = await storage.cloud_unsynced_batch(
            limit=100, cursor=(cursor_at, second.id)
        )
        # Must exclude both the cursor row and everything before it.
        returned_ids = {r.id for r in remaining}
        assert second.id not in returned_ids
        assert all_rows[0].id not in returned_ids
        assert len(remaining) == 3


@pytest.mark.asyncio
async def test_cursor_tiebreak_on_id(tmp_path: Path) -> None:
    """Same-ms rows order by ``id`` so the cursor can step past both."""
    db = tmp_path / "test.db"
    async with StorageManager(db) as storage:
        ts = "2026-05-11T10:00:01.000000Z"
        ids = sorted([str(uuid.uuid4()) for _ in range(3)])
        for rid in ids:
            await storage.write_record(
                _make_record(id=rid, recorded_at=ts, requested_at=ts)
            )

        ordered = await storage.cloud_unsynced_batch(limit=100)
        ordered_ids = [r.id for r in ordered]
        # The cursor key is (recorded_at, id) with ascending id.
        same_ms = [rid for rid in ordered_ids if rid in ids]
        assert same_ms == sorted(same_ms)


# --------------------------------------------------------------------------- #
# Encryption + cloud_state                                                    #
# --------------------------------------------------------------------------- #


def test_fernet_round_trip_local(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """``encrypt_api_key`` / ``decrypt_api_key`` round-trip cleanly."""
    key_file = tmp_path / "cloud.key"
    monkeypatch.setattr(
        "halton_meter.storage.cloud_crypto.DEFAULT_KEY_PATH",
        key_file,
    )
    token = "hm_sync_" + ("a" * 40)
    ciphertext = encrypt_api_key(token)
    assert token.encode() not in ciphertext  # plaintext never in bytes
    assert decrypt_api_key(ciphertext) == token

    # Fingerprint is deterministic and full SHA-256 hex (64 chars).
    fp = fingerprint_api_key(token)
    assert len(fp) == 64
    assert all(c in "0123456789abcdef" for c in fp)


@pytest.mark.asyncio
async def test_cloud_state_encryption_round_trip(tmp_path: Path) -> None:
    """``cloud_set_state`` encrypts the API key; ``cloud_get_state`` returns it."""
    db = tmp_path / "test.db"
    token = "hm_sync_" + ("b" * 40)

    async with StorageManager(db) as storage:
        await storage.cloud_set_state(
            endpoint=ENDPOINT,
            api_key_plaintext=token,
            workspace_id="ws-001",
            workspace_name="Halton Labs",
            machine_id="mach-001",
            hostname_reported="dev-laptop-01",
            base_url=ENDPOINT,
            enabled=True,
        )
        state = await storage.cloud_get_state(ENDPOINT)

    assert state is not None
    assert state.workspace_id == "ws-001"
    assert state.workspace_name == "Halton Labs"
    assert state.enabled is True
    assert state.api_key_fingerprint == fingerprint_api_key(token)

    # The plaintext must not be persisted verbatim.
    assert state.api_key_ciphertext is not None
    assert token.encode() not in state.api_key_ciphertext

    # Round-trip via the helper.
    assert decrypt_api_key(state.api_key_ciphertext) == token


@pytest.mark.asyncio
async def test_cloud_state_partial_update_preserves_other_fields(
    tmp_path: Path,
) -> None:
    """Partial ``cloud_set_state`` calls do not overwrite untouched fields."""
    db = tmp_path / "test.db"
    token = "hm_sync_" + ("c" * 40)
    async with StorageManager(db) as storage:
        await storage.cloud_set_state(
            endpoint=ENDPOINT,
            api_key_plaintext=token,
            workspace_id="ws-001",
            workspace_name="Halton Labs",
            enabled=True,
        )
        # Now only flip paused_reason. Workspace + token must survive.
        await storage.cloud_set_state(
            endpoint=ENDPOINT,
            paused_reason="paused_manual",
        )
        state = await storage.cloud_get_state(ENDPOINT)

    assert state is not None
    assert state.paused_reason == "paused_manual"
    assert state.workspace_id == "ws-001"
    assert state.workspace_name == "Halton Labs"
    assert state.enabled is True
    assert state.api_key_fingerprint == fingerprint_api_key(token)


@pytest.mark.asyncio
async def test_cloud_state_clear_api_key(tmp_path: Path) -> None:
    """``clear_api_key=True`` wipes ciphertext + fingerprint."""
    db = tmp_path / "test.db"
    token = "hm_sync_" + ("d" * 40)
    async with StorageManager(db) as storage:
        await storage.cloud_set_state(
            endpoint=ENDPOINT,
            api_key_plaintext=token,
            workspace_id="ws-001",
            enabled=True,
        )
        await storage.cloud_set_state(endpoint=ENDPOINT, clear_api_key=True)
        state = await storage.cloud_get_state(ENDPOINT)

    assert state is not None
    assert state.api_key_ciphertext is None
    assert state.api_key_fingerprint is None
    # Audit fields preserved on the wipe.
    assert state.workspace_id == "ws-001"
