"""Tests for the hidden ``halton-meter _apply-user-env`` subcommand.

v0.1.19 Task 0.1: invoked at every login by the userenv LaunchAgent
(``com.haltonlabs.meter.userenv.plist``) to re-apply launchctl
user-domain env vars (HTTPS_PROXY et al). macOS clears those on
logout/reboot, so without this command, ``init --apps``/``--full``
mode does not survive a reboot.

These tests assert:

* The subcommand is registered (and hidden from ``--help``).
* It calls :func:`system_proxy.setenv_user_domain` with the full
  ``GUI_LAUNCHCTL_ENV_KEYS`` set.
* It exits 0 even on partial setenv failures (login must never block).
* It no-ops in env-only / unknown install modes.
"""

from __future__ import annotations

from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import cli as cli_module
from halton_meter import system_proxy


def test_apply_user_env_is_hidden_from_help() -> None:
    """The subcommand is registered but does not appear in ``--help``."""
    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["--help"])
    assert result.exit_code == 0
    assert "_apply-user-env" not in result.output


def test_apply_user_env_calls_setenv_with_all_gui_keys(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Acceptance: setenv_user_domain is called with the full
    ``GUI_LAUNCHCTL_ENV_KEYS`` set when in --apps/--full mode."""
    from halton_meter import init as init_module

    monkeypatch.setattr(init_module, "read_install_mode", lambda: init_module.MODE_APPS)

    captured: dict[str, Any] = {}

    def fake_setenv(env_vars: dict[str, str]) -> dict[str, int]:
        captured["env_vars"] = env_vars
        return {k: 0 for k in env_vars}

    monkeypatch.setattr(system_proxy._macos, "setenv_user_domain", fake_setenv)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["_apply-user-env"])

    assert result.exit_code == 0, result.output
    assert "env_vars" in captured, "setenv_user_domain was not called"
    # All GUI launchctl env keys must appear in the env_vars passed in.
    for key in system_proxy.GUI_LAUNCHCTL_ENV_KEYS:
        assert key in captured["env_vars"], f"missing key: {key}"
    # And the proxy URL pattern is plausible.
    assert captured["env_vars"]["HTTPS_PROXY"].startswith("http://")


def test_apply_user_env_exits_zero_on_partial_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A login-time agent must NEVER block the user's session start.
    Per-key launchctl failures are warning-only; doctor surfaces them
    later. Exit code stays 0."""
    from halton_meter import init as init_module

    monkeypatch.setattr(init_module, "read_install_mode", lambda: init_module.MODE_FULL)

    def fake_setenv(env_vars: dict[str, str]) -> dict[str, int]:
        # Half the keys fail to apply (rc != 0).
        return {k: (1 if i % 2 == 0 else 0) for i, k in enumerate(env_vars)}

    monkeypatch.setattr(system_proxy._macos, "setenv_user_domain", fake_setenv)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["_apply-user-env"])
    assert result.exit_code == 0, result.output


def test_apply_user_env_exits_zero_when_setenv_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Even a hard exception out of setenv_user_domain must not block login."""
    from halton_meter import init as init_module

    monkeypatch.setattr(init_module, "read_install_mode", lambda: init_module.MODE_APPS)

    def fake_setenv(env_vars: dict[str, str]) -> dict[str, int]:
        raise RuntimeError("launchctl exploded")

    monkeypatch.setattr(system_proxy._macos, "setenv_user_domain", fake_setenv)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["_apply-user-env"])
    assert result.exit_code == 0, result.output


def test_apply_user_env_noops_in_env_only_mode(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Defensive: if the plist somehow exists in env-only mode the agent
    must not overwrite the user's launchctl env."""
    from halton_meter import init as init_module

    monkeypatch.setattr(
        init_module, "read_install_mode", lambda: init_module.MODE_ENV_ONLY
    )

    called = False

    def fake_setenv(env_vars: dict[str, str]) -> dict[str, int]:
        nonlocal called
        called = True
        return {k: 0 for k in env_vars}

    monkeypatch.setattr(system_proxy._macos, "setenv_user_domain", fake_setenv)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["_apply-user-env"])
    assert result.exit_code == 0, result.output
    assert called is False, "setenv_user_domain must not run in env-only mode"


def test_apply_user_env_noops_when_install_mode_unknown(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``read_install_mode`` returning ``None`` (older / corrupted
    install) must not trigger a setenv — defensive."""
    from halton_meter import init as init_module

    monkeypatch.setattr(init_module, "read_install_mode", lambda: None)

    called = False

    def fake_setenv(env_vars: dict[str, str]) -> dict[str, int]:
        nonlocal called
        called = True
        return {k: 0 for k in env_vars}

    monkeypatch.setattr(system_proxy._macos, "setenv_user_domain", fake_setenv)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["_apply-user-env"])
    assert result.exit_code == 0
    assert called is False
