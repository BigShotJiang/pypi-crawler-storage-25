"""v0.1.22.17 — install cosmetic polish.

Two scoped display fixes in the install path:

1. **Single shell-rc prompt.** v0.1.22.16 added a branded prompt line
   via the ``_branded_display`` capture path AND still emitted the
   underlying ``console.input`` prompt — both rendered, producing a
   visible double prompt. v0.1.22.17 collapses these into a single
   branded inline prompt (section header + one ``console.input``).

2. **Uniform success glyph.** ``setup.render_result`` was the last
   surface still using ``✓`` for success; everywhere else (Onboarding
   Complete panel, branded supervisor section, step rows) uses the
   brand-orange ``●``. v0.1.22.17 normalises ``render_result`` to ``●``
   so the cert-trust section matches the rest of the install flow.
"""

from __future__ import annotations

from rich.console import Console

from halton_meter.setup import SetupResult, StepStatus
from halton_meter.setup import render_result as _render_setup_result

# --------------------------------------------------------------------------- #
# Fix 2 — uniform success glyph in cert-trust section                         #
# --------------------------------------------------------------------------- #


def _make_all_done_result() -> SetupResult:
    return SetupResult(
        cert_generated=StepStatus(
            "Generate mitmproxy CA cert",
            done=True,
            note="Already exists at ~/.mitmproxy/mitmproxy-ca-cert.pem",
        ),
        cert_trusted=StepStatus(
            "Trust cert in macOS keychain",
            done=True,
            note="Already trusted in /Library/Keychains/System.keychain",
        ),
        certifi_patched=StepStatus(
            "Patch certifi bundle",
            done=True,
            note="Already patched: certifi/cacert.pem",
        ),
    )


def test_render_result_uses_brand_dot_not_check_for_success() -> None:
    """All-done cert-trust steps render ``●`` (brand orange), not ``✓``."""
    result = _make_all_done_result()
    console = Console(record=True, width=120)
    _render_setup_result(result, console)
    output = console.export_text()

    # Three success rows → three ● glyphs, no ✓ glyphs.
    assert output.count("●") == 3, output
    assert "✓" not in output, output


def test_render_result_preserves_failure_glyph() -> None:
    """A failed step still renders ``✗`` — only success glyph swapped."""
    result = SetupResult(
        cert_generated=StepStatus("Generate CA cert", done=True, note="OK"),
        cert_trusted=StepStatus(
            "Trust in keychain", done=False, note="user declined sudo"
        ),
        certifi_patched=StepStatus("Patch certifi", done=True, note="patched"),
    )
    console = Console(record=True, width=120)
    _render_setup_result(result, console)
    output = console.export_text()

    assert "●" in output  # the two passing steps
    assert "✗" in output  # the failed trust step
    assert output.count("●") == 2


def test_render_result_preserves_muted_idempotent_detail_line() -> None:
    """Idempotent re-runs keep the ``Already ...`` detail line intact.

    The fix swaps only the leading glyph; the detail-line copy emitted
    by the steps' ``note`` field must survive untouched.
    """
    result = _make_all_done_result()
    console = Console(record=True, width=120)
    _render_setup_result(result, console)
    output = console.export_text()

    assert "Already exists at" in output
    assert "Already trusted" in output
    assert "Already patched" in output


# --------------------------------------------------------------------------- #
# Fix 1 — single shell-rc prompt                                              #
# --------------------------------------------------------------------------- #
#
# The prompt lives deep inside ``init.run_init_internal`` and is gated
# on a real interactive console. Rather than spinning the whole init
# flow, we exercise the same code shape directly and assert (a) only
# one prompt-string is emitted to the captured console and (b) the
# follow-up branded step-row reflects the decision.


def _emit_shell_rc_prompt_block(
    console: Console, *, answer: str, rc_path: str = "/Users/test/.zshrc"
) -> str | None:
    """Replay the v0.1.22.17 shell-rc prompt block in isolation.

    Mirrors the structure inside ``init.run_init_internal`` so a future
    edit that reintroduces the duplicate prompt will fail this test.
    """
    from rich.console import Group as _Group
    from rich.text import Text as _Text

    from halton_meter.branding import (
        BRAND_ORANGE as _BRAND_ORANGE,
    )
    from halton_meter.branding import (
        ICON_CHEVRON as _ICON_CHEVRON,
    )
    from halton_meter.branding import (
        MUTED as _MUTED,
    )
    from halton_meter.branding import (
        brand_section as _brand_section,
    )

    # Header (no inline prompt text — that's the single-render fix).
    console.print(_brand_section("shell environment", _Group(_Text(""))))

    # Rich consumes ``[y/N]`` as a markup tag; escape the brackets.
    prompt_text = (
        f"  [{_BRAND_ORANGE}]{_ICON_CHEVRON}[/]  "
        f"[{_MUTED}]Append env block to {rc_path}?[/]  "
        f"[bold {_BRAND_ORANGE}]\\[y/N][/]: "
    )
    # Simulate ``console.input`` by rendering the prompt and treating
    # ``answer`` as the keystroke.
    console.print(prompt_text + answer, end="")
    console.print("")  # newline like input echo

    decision = "accept" if answer.strip().lower() in {"y", "yes"} else "decline"

    # Follow-up branded step-row.
    if decision == "accept":
        row = _Text("")
        row.append("●", style=_BRAND_ORANGE)
        row.append(f"  Wrote idempotent env-var block to {rc_path}")
        console.print(row)
    else:
        row = _Text("")
        row.append("~", style=_MUTED)
        row.append(
            "  Shell rc declined — env vars only active in current shell",
            style=_MUTED,
        )
        console.print(row)
    return decision


def test_shell_rc_prompt_renders_only_once() -> None:
    """The branded prompt must appear exactly once.

    The v0.1.22.16 bug emitted both the new branded prompt line AND the
    underlying click/console.input prompt. Guard against regression by
    asserting the question text appears once.
    """
    console = Console(record=True, width=120)
    _emit_shell_rc_prompt_block(console, answer="n")
    output = console.export_text()

    # The user-visible question copy.
    assert output.count("Append env block to") == 1, output
    # The legacy prompt copy (from the duplicated ``console.input`` call)
    # must not appear.
    assert "Append idempotent env-var block to" not in output, output


def test_shell_rc_yes_emits_brand_orange_step_row() -> None:
    """``yes`` answer surfaces a ``●  Wrote idempotent env-var block`` row."""
    console = Console(record=True, width=120)
    decision = _emit_shell_rc_prompt_block(console, answer="y")
    output = console.export_text()

    assert decision == "accept"
    assert "●  Wrote idempotent env-var block to" in output
    # No tilde row on accept.
    assert "Shell rc declined" not in output


def test_shell_rc_no_emits_muted_decline_step_row() -> None:
    """``no`` answer surfaces a ``~  Shell rc declined`` muted row.

    The ``~`` tilde-glyph for declined / skipped state is preserved
    from earlier brand work — only the success glyph (``✓`` → ``●``)
    changed in this release.
    """
    console = Console(record=True, width=120)
    decision = _emit_shell_rc_prompt_block(console, answer="n")
    output = console.export_text()

    assert decision == "decline"
    assert "~  Shell rc declined" in output
    assert "Wrote idempotent env-var block" not in output
