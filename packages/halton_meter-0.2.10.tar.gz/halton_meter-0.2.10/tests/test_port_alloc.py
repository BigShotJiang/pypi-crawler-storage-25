"""Tests for ``halton_meter.port_alloc`` (v0.1.3 P0-5; v0.1.6 2C.2 split).

Auto-port-fallback: probe defaults; persist chosen tuple to runtime.toml;
honour user-pinned values from config.toml. The merged effective config
overlays defaults < runtime < config.toml.

v0.1.6 (2C.2): the user-facing proxy port was renamed
``listen_port`` -> ``edge_port`` and a new ``internal_port`` field was
added. Legacy ``listen_port`` keys in ``config.toml`` / ``runtime.toml``
are honoured as ``edge_port`` (deprecation warning logged for
``config.toml``; silent rewrite for ``runtime.toml`` on next persist).
"""

from __future__ import annotations

import socket
import textwrap
from pathlib import Path

import pytest

from halton_meter import port_alloc
from halton_meter.config import HaltonConfig


def _make_busy_listener(host: str, port: int) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((host, port))
    sock.listen(1)
    return sock


# v0.1.22.5: preserve the real ``_managed_edge_holds_default_port`` so
# the direct unit tests in ``TestManagedEdgePortReuse`` can exercise it
# even when the autouse fixture below replaces the module attribute.
_REAL_MANAGED_EDGE_GATE = port_alloc._managed_edge_holds_default_port


@pytest.fixture(autouse=True)
def _reset_legacy_warning(monkeypatch: pytest.MonkeyPatch) -> None:
    """The legacy `listen_port` deprecation warning is once-per-process;
    tests that expect to observe it (or to NOT observe it) need a clean
    latch each time. Ditto: tests that exercise legacy config.toml don't
    pollute later tests.

    v0.1.22.5: also stub ``_managed_edge_holds_default_port`` to False so
    existing tests that simulate ":8081 busy" behave the same regardless
    of the host machine. The new gate is exercised explicitly by
    ``TestManagedEdgePortReuse`` below; those direct-helper tests reach
    for ``_REAL_MANAGED_EDGE_GATE`` to bypass this stub.
    """
    port_alloc._reset_legacy_warning_state()
    monkeypatch.setattr(
        port_alloc,
        "_managed_edge_holds_default_port",
        lambda host, port: False,
    )


# --------------------------------------------------------------------------- #
# allocate_ports                                                              #
# --------------------------------------------------------------------------- #


class TestAllocatePorts:
    def test_returns_defaults_when_all_three_free(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        # Stub the probe so we don't actually bind on the dev box.
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
            persist=True,
        )
        assert edge == 8081
        assert internal == 8090
        assert api == 8765
        # When all three are at default, we do NOT write runtime.toml.
        assert not runtime.exists()

    def test_falls_back_when_edge_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        # 8081 busy, 8082 free; 8090 free; 8765 free.
        def fake_probe(host: str, port: int) -> bool:
            return port not in (8081,)

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8082
        assert internal == 8090
        assert api == 8765
        # runtime.toml persisted because edge drifted from default.
        assert runtime.exists()
        body = runtime.read_text(encoding="utf-8")
        assert "edge_port = 8082" in body
        assert "internal_port = 8090" in body
        assert "api_port = 8765" in body

    def test_falls_back_when_internal_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        # 8090 busy, 8091 free; everything else free.
        def fake_probe(host: str, port: int) -> bool:
            return port != 8090

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081
        assert internal == 8091
        assert api == 8765
        assert runtime.exists()

    def test_falls_back_when_api_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        def fake_probe(host: str, port: int) -> bool:
            return port != 8765

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081
        assert internal == 8090
        assert api == 8766
        assert runtime.exists()

    def test_pinned_edge_honoured_even_if_unavailable(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When user pinned ``edge_port=8081`` in config.toml, we honour
        it regardless of availability — daemon will fail-fast on bind
        clash with a clear error rather than silently relocating."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()  # default edge_port=8081
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=True,  # pinned!
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        # Edge is honoured (no probe).
        assert edge == 8081
        # Internal still falls back to default since every probe returns False.
        assert internal == 8090
        assert api == 8765

    def test_pinned_edge_in_internal_range_shifts_internal_probe(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Plan §8 Risk 4: if the user pinned ``edge_port=8095`` (within
        the default internal range 8090..8099), the internal probe range
        shifts to start at ``edge_port + 10`` = 8105 so we don't
        self-collide."""
        runtime = tmp_path / "runtime.toml"
        # Build a HaltonConfig with edge_port pinned at 8095. Use the
        # alias so we can also exercise the legacy kwarg path.
        from halton_meter.config import DaemonConfig
        from halton_meter.config import HaltonConfig as _HC

        cfg = _HC(daemon=DaemonConfig(edge_port=8095))

        # Probe answers True for 8105 only — proves we actually shifted.
        def fake_probe(host: str, port: int) -> bool:
            return port == 8105 or port == 8765

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=True,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8095
        assert internal == 8105
        assert api == 8765

    def test_falls_back_to_default_when_every_candidate_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When all candidates busy: noisy fallback to default. Daemon
        will surface a clear bind error."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081
        assert internal == 8090
        assert api == 8765

    def test_persist_false_skips_write(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        def fake_probe(host: str, port: int) -> bool:
            return port != 8081

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, _internal, _api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
            persist=False,
        )
        assert edge == 8082
        assert not runtime.exists()

    def test_legacy_listen_pinned_kwarg_maps_to_edge_pinned(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """v0.1.5 callers passing ``listen_pinned=`` continue to work —
        the value is mapped to ``edge_pinned=`` for one release window."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        edge, _internal, _api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=True,  # legacy kwarg
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081  # honoured the pin


# --------------------------------------------------------------------------- #
# load_effective_config                                                       #
# --------------------------------------------------------------------------- #


class TestLoadEffectiveConfig:
    def test_returns_defaults_when_neither_file_exists(
        self, tmp_path: Path
    ) -> None:
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=tmp_path / "missing-runtime.toml",
        )
        assert cfg.daemon.edge_port == 8081
        assert cfg.daemon.internal_port == 8090
        assert cfg.daemon.api_port == 8765

    def test_runtime_overrides_defaults(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent("""
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
            """),
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.edge_port == 8082
        assert cfg.daemon.internal_port == 8091
        assert cfg.daemon.api_port == 8766

    def test_config_overrides_runtime(self, tmp_path: Path) -> None:
        config = tmp_path / "config.toml"
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nedge_port = 8082\napi_port = 8766\n",
            encoding="utf-8",
        )
        config.write_text(
            "[daemon]\nedge_port = 9999\n",
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=config, runtime_path=runtime
        )
        # config.toml's edge_port wins.
        assert cfg.daemon.edge_port == 9999
        # api_port not in config.toml -> takes from runtime.
        assert cfg.daemon.api_port == 8766

    def test_partial_runtime_only_one_port(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nedge_port = 8085\n", encoding="utf-8"
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.edge_port == 8085
        # api_port falls back to default because runtime didn't have it.
        assert cfg.daemon.api_port == 8765
        # internal_port also falls back to default.
        assert cfg.daemon.internal_port == 8090

    def test_garbage_runtime_ignored(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text("not valid toml = = = ", encoding="utf-8")
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing.toml",
            runtime_path=runtime,
        )
        # Defaults preserved; garbage tomllib decode error swallowed.
        assert cfg.daemon.edge_port == 8081

    def test_legacy_listen_port_in_config_maps_to_edge(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """v0.1.5 users with ``listen_port = 9000`` in config.toml see
        their pin honoured as ``edge_port`` (preserving the v0.1.5
        contract: the port my apps see is the port I pinned)."""
        config = tmp_path / "config.toml"
        config.write_text("[daemon]\nlisten_port = 9000\n", encoding="utf-8")
        cfg = port_alloc.load_effective_config(
            config_path=config,
            runtime_path=tmp_path / "missing-runtime.toml",
        )
        assert cfg.daemon.edge_port == 9000
        # internal_port still defaults.
        assert cfg.daemon.internal_port == 8090

    def test_legacy_listen_port_in_runtime_maps_silently(
        self, tmp_path: Path
    ) -> None:
        """v0.1.5 ``runtime.toml`` files with the legacy ``listen_port``
        key are read silently (no deprecation warning — the daemon owns
        runtime.toml and rewrites it on next persist)."""
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nlisten_port = 8083\napi_port = 8767\n",
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.edge_port == 8083
        assert cfg.daemon.api_port == 8767


# --------------------------------------------------------------------------- #
# discover_and_persist_ports                                                  #
# --------------------------------------------------------------------------- #


class TestDiscoverAndPersistPorts:
    def test_detects_user_pinned_and_persists_only_runtime_drift(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config = tmp_path / "config.toml"
        runtime = tmp_path / "runtime.toml"
        # User pins edge_port; api_port + internal_port are implicit.
        config.write_text(
            "[daemon]\nedge_port = 9000\n",
            encoding="utf-8",
        )

        # 9000 (pinned -> not probed). 8090 free; 8765 busy; 8766 free.
        def fake_probe(host: str, port: int) -> bool:
            if port == 8090:
                return True
            return port == 8766

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.discover_and_persist_ports(
            config_path=config, runtime_path=runtime
        )
        assert edge == 9000  # pinned
        assert internal == 8090
        assert api == 8766  # auto-allocated
        # runtime.toml persists the auto-allocated tuple.
        assert runtime.exists()
        body = runtime.read_text(encoding="utf-8")
        assert "api_port = 8766" in body
        assert "edge_port = 9000" in body
        assert "internal_port = 8090" in body


# --------------------------------------------------------------------------- #
# runtime.toml round-trip + migration                                         #
# --------------------------------------------------------------------------- #


def test_runtime_toml_round_trip(tmp_path: Path) -> None:
    runtime = tmp_path / "runtime.toml"
    port_alloc._write_runtime_toml(
        runtime, edge_port=8082, internal_port=8091, api_port=8770
    )
    rt = port_alloc._read_runtime_toml(runtime)
    assert rt == {"edge_port": 8082, "internal_port": 8091, "api_port": 8770}


def test_runtime_toml_legacy_listen_port_kwarg_back_compat(
    tmp_path: Path,
) -> None:
    """v0.1.5 callers passing only ``listen_port=`` continue to write a
    valid file. ``listen_port=`` maps to ``edge_port=`` and
    ``internal_port`` defaults to 8090. The on-disk file uses the
    canonical v0.1.6 keys."""
    runtime = tmp_path / "runtime.toml"
    port_alloc._write_runtime_toml(runtime, listen_port=8090, api_port=8770)
    body = runtime.read_text(encoding="utf-8")
    assert "edge_port = 8090" in body
    assert "internal_port = 8090" in body
    assert "api_port = 8770" in body
    # Re-read normalises to canonical keys.
    rt = port_alloc._read_runtime_toml(runtime)
    assert rt["edge_port"] == 8090
    assert rt["internal_port"] == 8090
    assert rt["api_port"] == 8770


def test_migrate_runtime_toml_v0_1_5_to_v0_1_6(tmp_path: Path) -> None:
    """Synthetic v0.1.5 runtime.toml -> rewritten with canonical keys."""
    runtime = tmp_path / "runtime.toml"
    runtime.write_text(
        "[daemon]\nlisten_port = 8081\napi_port = 8765\n",
        encoding="utf-8",
    )
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is True
    body = runtime.read_text(encoding="utf-8")
    assert "edge_port = 8081" in body
    assert "internal_port" in body
    assert "api_port = 8765" in body
    assert "listen_port" not in body


def test_migrate_runtime_toml_idempotent_on_canonical_file(
    tmp_path: Path,
) -> None:
    runtime = tmp_path / "runtime.toml"
    runtime.write_text(
        "[daemon]\nedge_port = 8081\ninternal_port = 8090\napi_port = 8765\n",
        encoding="utf-8",
    )
    before = runtime.read_text(encoding="utf-8")
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is False
    after = runtime.read_text(encoding="utf-8")
    assert before == after


def test_migrate_runtime_toml_missing_file_noop(tmp_path: Path) -> None:
    """Missing file -> False, no exception, no file created."""
    runtime = tmp_path / "missing.toml"
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is False
    assert not runtime.exists()


def test_migrate_runtime_toml_uses_collision_shifted_internal(
    tmp_path: Path,
) -> None:
    """If legacy ``listen_port`` was 8095 (within the default internal
    range 8090..8099), the migration picks an internal_port outside
    the collision window via ``_internal_probe_range_for``."""
    runtime = tmp_path / "runtime.toml"
    runtime.write_text(
        "[daemon]\nlisten_port = 8095\napi_port = 8765\n",
        encoding="utf-8",
    )
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is True
    body = runtime.read_text(encoding="utf-8")
    assert "edge_port = 8095" in body
    # Internal_port was shifted to 8105 (8095 + 10).
    assert "internal_port = 8105" in body


def test_write_runtime_toml_fsyncs_before_rename(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """PR 7 P2-2: ``_write_runtime_toml`` must fsync the temp-file fd
    before renaming it over the canonical path. Pins crash-safety —
    without fsync, a power loss between rename and disk-flush can
    leave runtime.toml present but empty.

    Spies on ``os.fsync`` and ``os.replace``; asserts fsync was
    called on the fd we wrote to AND that fsync's call ordered
    strictly before replace (mirrors system_proxy._atomic_write_json).
    v0.1.6: signature uses canonical ``edge_port=`` / ``internal_port=``.
    """
    import os as _os

    runtime = tmp_path / "runtime.toml"

    call_log: list[tuple[str, object]] = []

    real_fsync = _os.fsync
    real_replace = _os.replace
    real_write = _os.write

    written_fds: list[int] = []

    def spy_write(fd: int, data: bytes) -> int:
        written_fds.append(fd)
        return real_write(fd, data)

    def spy_fsync(fd: int) -> None:
        call_log.append(("fsync", fd))
        real_fsync(fd)

    def spy_replace(src: object, dst: object) -> None:
        call_log.append(("replace", (src, dst)))
        real_replace(src, dst)  # type: ignore[arg-type]

    monkeypatch.setattr(port_alloc.os, "write", spy_write)
    monkeypatch.setattr(port_alloc.os, "fsync", spy_fsync)
    monkeypatch.setattr(port_alloc.os, "replace", spy_replace)

    port_alloc._write_runtime_toml(
        runtime, edge_port=8082, internal_port=8091, api_port=8770
    )

    # (a) fsync was called.
    fsync_calls = [c for c in call_log if c[0] == "fsync"]
    assert fsync_calls, f"expected fsync to be called; got {call_log}"

    # (b) fsync was called on the same fd we wrote to.
    assert written_fds, "expected at least one os.write call"
    assert fsync_calls[0][1] == written_fds[0], (
        f"fsync fd {fsync_calls[0][1]} != write fd {written_fds[0]}"
    )

    # (c) fsync ordered strictly before replace — the whole point of
    # the atomic-write pattern.
    fsync_idx = next(i for i, c in enumerate(call_log) if c[0] == "fsync")
    replace_idx = next(i for i, c in enumerate(call_log) if c[0] == "replace")
    assert fsync_idx < replace_idx, (
        f"fsync must precede replace; got order {call_log}"
    )

    # And the file actually exists with the expected contents.
    assert runtime.exists()
    rt = port_alloc._read_runtime_toml(runtime)
    assert rt == {"edge_port": 8082, "internal_port": 8091, "api_port": 8770}


def test_remove_runtime_toml_idempotent(tmp_path: Path) -> None:
    target = tmp_path / "runtime.toml"
    # Missing -> no-op.
    port_alloc.remove_runtime_toml(target)
    # Exists -> removed.
    target.write_text("[daemon]\nedge_port = 8081\n", encoding="utf-8")
    assert target.exists()
    port_alloc.remove_runtime_toml(target)
    assert not target.exists()


def test_is_port_free_against_real_socket(tmp_path: Path) -> None:
    """Real socket round-trip: 0 means OS picks free port; we then
    confirm the same port returns False once we hold the listener."""
    # Pick an arbitrary high port the test harness probably isn't using.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    bound_port = sock.getsockname()[1]
    sock.listen(1)
    try:
        # While the socket holds the port, our probe must say "not free".
        assert port_alloc._is_port_free("127.0.0.1", bound_port) is False
    finally:
        sock.close()
    # After the socket releases, probe says "free" again (fallible on
    # SO_LINGER timing; assert weakly).
    # (Not asserting the True branch here to avoid timing flake on CI.)


def test_is_port_free_sets_so_reuseaddr_on_probe_socket() -> None:
    """v0.1.22.7 regression guard: ``_is_port_free`` MUST set
    ``SO_REUSEADDR`` on its probe socket so the probe matches the
    bind semantics of mitmproxy's actual listener (asyncio's
    ``start_server`` defaults to ``reuse_address=True`` on Unix).

    Without this, the probe falsely reports "busy" on a port that
    has only TIME_WAIT residue from the previous-generation daemon's
    ESTABLISHED clients — driving the v0.1.22.6 soak's :8090 -> :8091
    drift on every fast ``stop && start`` cycle. See
    ``decisions.md`` 2026-05-07 v0.1.22.7 entry.
    """
    real_socket = socket.socket
    captured: dict[str, list[tuple[int, int, int]]] = {"opts": []}

    class _SpySocket:
        def __init__(self, *args: object, **kwargs: object) -> None:
            self._inner = real_socket(*args, **kwargs)

        def setsockopt(self, level: int, optname: int, value: int) -> None:
            captured["opts"].append((level, optname, value))
            self._inner.setsockopt(level, optname, value)

        def __getattr__(self, name: str):
            return getattr(self._inner, name)

    import unittest.mock as _mock

    with _mock.patch.object(socket, "socket", _SpySocket):
        # Pick a free port via OS-assigned bind; close it; then probe.
        scratch = real_socket(socket.AF_INET, socket.SOCK_STREAM)
        scratch.bind(("127.0.0.1", 0))
        free_port = scratch.getsockname()[1]
        scratch.close()
        # Drain the spy's record from the scratch socket above (which
        # was created BEFORE the patch via ``real_socket`` directly,
        # so it shouldn't be there — but reset to be safe).
        captured["opts"].clear()
        result = port_alloc._is_port_free("127.0.0.1", free_port)

    assert result is True, (
        "scratch port should probe free after we closed it"
    )
    assert (socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) in captured["opts"], (
        f"SO_REUSEADDR(1) not set on probe socket — recorded opts: "
        f"{captured['opts']}"
    )


def test_is_port_free_still_detects_foreign_listener() -> None:
    """v0.1.22.7 regression guard: SO_REUSEADDR on the probe must NOT
    leak into "any port is free" — a real foreign LISTEN socket on
    the port still EADDRINUSE-blocks our probe bind. SO_REUSEADDR
    only relaxes TIME_WAIT residue; two LISTEN sockets on the same
    (host, port) still collide on macOS / Linux.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Note: deliberately do NOT set SO_REUSEADDR on the foreign holder
    # — even with our probe setting it, two LISTEN sockets cannot
    # coexist on the same (host, port) without SO_REUSEPORT.
    sock.bind(("127.0.0.1", 0))
    bound_port = sock.getsockname()[1]
    sock.listen(1)
    try:
        assert port_alloc._is_port_free("127.0.0.1", bound_port) is False
    finally:
        sock.close()


def test_is_port_free_handles_setsockopt_failure_gracefully(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If setsockopt somehow fails (defensive — should never happen on
    AF_INET TCP), the probe must still fall through to ``bind()`` and
    return its truthful answer rather than crashing.
    """
    real_socket = socket.socket

    class _FailingSetsockopt:
        def __init__(self, *args: object, **kwargs: object) -> None:
            self._inner = real_socket(*args, **kwargs)

        def setsockopt(self, *args: object, **kwargs: object) -> None:
            raise OSError("simulated setsockopt failure")

        def __getattr__(self, name: str):
            return getattr(self._inner, name)

    import unittest.mock as _mock

    # Pick a fresh free port via real socket BEFORE patching.
    scratch = real_socket(socket.AF_INET, socket.SOCK_STREAM)
    scratch.bind(("127.0.0.1", 0))
    free_port = scratch.getsockname()[1]
    scratch.close()

    with _mock.patch.object(socket, "socket", _FailingSetsockopt):
        # Even with setsockopt raising, the bind should succeed and
        # the function should return True without raising.
        assert port_alloc._is_port_free("127.0.0.1", free_port) is True


def test_allocate_ports_reuses_internal_default_when_only_time_wait_residue(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """v0.1.22.7 repro: previous-generation daemon SIGTERM-ed; its
    LISTEN socket on :8090 is gone but TIME_WAIT residue from the
    ESTABLISHED clients remains. With v0.1.22.6's bare-bind probe
    this drove drift to :8091 on the next start (witnessed in the
    operator's soak). With v0.1.22.7's SO_REUSEADDR-aware probe,
    the new daemon must reuse :8090.

    We can't trivially synthesise real TIME_WAIT in a unit test, but
    we CAN synthesise the condition the bug created: ``socket.bind``
    raises EADDRINUSE on a bare AF_INET socket but succeeds when
    SO_REUSEADDR has been set. That's exactly what the kernel does
    for TIME_WAIT-residue on macOS / Linux.
    """
    real_socket = socket.socket

    class _TimeWaitResidueSocket:
        """Simulate TIME_WAIT residue on the default internal port:
        bind on :8090 raises EADDRINUSE unless SO_REUSEADDR was set."""

        def __init__(self, family: int, type_: int) -> None:
            self._inner = real_socket(family, type_)
            self._reuseaddr = False

        def setsockopt(self, level: int, optname: int, value: int) -> None:
            if level == socket.SOL_SOCKET and optname == socket.SO_REUSEADDR:
                self._reuseaddr = bool(value)
            self._inner.setsockopt(level, optname, value)

        def bind(self, addr: tuple[str, int]) -> None:
            _host, port = addr
            if port == port_alloc._INTERNAL_PORT_DEFAULT and not self._reuseaddr:
                raise OSError(48, "Address already in use")
            # Other ports: route to a real ephemeral bind so the rest
            # of the probe path stays honest.
            self._inner.bind(("127.0.0.1", 0))

        def __getattr__(self, name: str):
            return getattr(self._inner, name)

    import unittest.mock as _mock

    monkeypatch.setattr(
        port_alloc, "_managed_edge_holds_default_port", lambda host, port: False
    )
    cfg = HaltonConfig()
    runtime_target = tmp_path / "runtime.toml"

    with _mock.patch.object(socket, "socket", _TimeWaitResidueSocket):
        _edge_port, internal_port, _api_port = port_alloc.allocate_ports(
            cfg,
            runtime_path=runtime_target,
            persist=False,
        )

    assert internal_port == port_alloc._INTERNAL_PORT_DEFAULT, (
        f"expected reuse of :{port_alloc._INTERNAL_PORT_DEFAULT} via "
        f"SO_REUSEADDR-aware probe; got drift to :{internal_port}"
    )


# --------------------------------------------------------------------------- #
# Effective ports source-of-truth (v0.1.19.dev1, Phase 2 Bug B)               #
# --------------------------------------------------------------------------- #


class TestEffectivePorts:
    def test_round_trip_round(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=8081,
            internal_port=8090,
            api_port=8765,
            pid=42,
            path=path,
        )
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        assert out["internal_port"] == 8090
        assert out["api_port"] == 8765
        assert out["pid"] == 42
        assert out["schema_version"] == 1
        assert "bound_at" in out

    def test_missing_file_returns_empty(self, tmp_path: Path) -> None:
        assert port_alloc.read_effective_ports(tmp_path / "nope.json") == {}

    def test_corrupt_json_returns_empty(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        path.write_text("not json {{{")
        assert port_alloc.read_effective_ports(path) == {}

    def test_unknown_keys_tolerated(self, tmp_path: Path) -> None:
        # Forward-compat: a future version writes extra keys; today's
        # reader must not blow up.
        import json

        path = tmp_path / "effective-ports.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": 999,
                    "edge_port": 8081,
                    "internal_port": 8090,
                    "api_port": 8765,
                    "future_field": ["nested", "stuff"],
                }
            )
        )
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        assert out["internal_port"] == 8090

    def test_edge_port_null_ok(self, tmp_path: Path) -> None:
        # Daemon-side write sets edge_port=None; reader filters non-int.
        path = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=None,
            internal_port=8090,
            api_port=8765,
            path=path,
        )
        out = port_alloc.read_effective_ports(path)
        assert "edge_port" not in out  # filtered: not an int
        assert out["internal_port"] == 8090
        assert out["api_port"] == 8765

    def test_remove_idempotent(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=8081, internal_port=8090, api_port=8765, path=path
        )
        assert path.exists()
        port_alloc.remove_effective_ports(path)
        assert not path.exists()
        # Idempotent: a second remove on a missing file is a no-op.
        port_alloc.remove_effective_ports(path)
        assert not path.exists()

    def test_merge_edge_port_preserves_internal_api(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        # Daemon writes first (no edge port).
        port_alloc.write_effective_ports(
            edge_port=None, internal_port=8090, api_port=8765, path=path
        )
        # Edge merges its bound edge_port.
        port_alloc.merge_edge_port_into_effective_ports(8081, path=path)
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        assert out["internal_port"] == 8090
        assert out["api_port"] == 8765

    def test_merge_edge_port_when_no_daemon_write_yet(self, tmp_path: Path) -> None:
        # Edge starts before daemon: merge writes a minimal file with only
        # edge_port; the daemon's later write will overlay internal/api.
        path = tmp_path / "effective-ports.json"
        port_alloc.merge_edge_port_into_effective_ports(8081, path=path)
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        # internal_port and api_port absent (None gets filtered by reader).
        assert "internal_port" not in out
        assert "api_port" not in out

    def test_load_effective_config_prefers_effective_ports_over_runtime(
        self, tmp_path: Path
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent(
                """
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
                """
            )
        )
        eff = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=8081, internal_port=8090, api_port=8765, path=eff
        )
        # Monkey-patch the module-level path so load_effective_config picks
        # up the test file.
        import halton_meter.port_alloc as pa

        original = pa.EFFECTIVE_PORTS_JSON_PATH
        pa.EFFECTIVE_PORTS_JSON_PATH = eff
        try:
            cfg = port_alloc.load_effective_config(
                config_path=tmp_path / "missing-config.toml",
                runtime_path=runtime,
            )
        finally:
            pa.EFFECTIVE_PORTS_JSON_PATH = original
        # effective-ports.json wins over runtime.toml.
        assert cfg.daemon.edge_port == 8081
        assert cfg.daemon.internal_port == 8090
        assert cfg.daemon.api_port == 8765

    def test_load_effective_config_falls_back_to_runtime_when_missing(
        self, tmp_path: Path
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent(
                """
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
                """
            )
        )
        # No effective-ports.json — must fall back to runtime.toml.
        import halton_meter.port_alloc as pa

        original = pa.EFFECTIVE_PORTS_JSON_PATH
        pa.EFFECTIVE_PORTS_JSON_PATH = tmp_path / "absent.json"
        try:
            cfg = port_alloc.load_effective_config(
                config_path=tmp_path / "missing-config.toml",
                runtime_path=runtime,
            )
        finally:
            pa.EFFECTIVE_PORTS_JSON_PATH = original
        assert cfg.daemon.edge_port == 8082
        assert cfg.daemon.internal_port == 8091
        assert cfg.daemon.api_port == 8766


class TestPortConvergence:
    def test_stale_runtime_toml_removed_when_defaults_now_free(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """v0.1.19.dev1 Bug B: a previous boot wrote 8082/8091/8766 because
        the defaults were busy. Now defaults are free. The next boot's
        ``allocate_ports`` MUST remove the stale runtime.toml so readers
        do not keep overlaying the obsolete tuple on top of fresh defaults.
        """
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent(
                """
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
                """
            )
        )
        # Stub the probe — defaults all free now.
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)
        cfg = HaltonConfig()
        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert (edge, internal, api) == (
            port_alloc.EDGE_PORT_DEFAULT,
            port_alloc.INTERNAL_PORT_DEFAULT,
            port_alloc.API_PORT_DEFAULT,
        )
        # The stale file MUST be gone.
        assert not runtime.exists(), (
            "stale runtime.toml left on disk; readers would lock the "
            "daemon into the stale tuple"
        )


# --------------------------------------------------------------------------- #
# v0.1.22.5 (B5) — managed-edge port reuse on stop && start                   #
# --------------------------------------------------------------------------- #


class TestManagedEdgePortReuse:
    """Repro of the v0.1.22.4 soak bug: ``halton-meter stop && start``
    drifted ``edge_port`` from :8081 -> :8082 even though the always-on
    edge process (KeepAlive=True, same PID across the cycle) still held
    :8081. The fallback was driven by ``_is_port_free(:8081)`` returning
    False because *we* held the socket.
    """

    def test_reuses_default_edge_port_when_managed_edge_holds_it(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When :8081 is held by our managed edge, allocate_ports must
        return :8081 (no fallback) and must NOT persist a stale
        runtime.toml.
        """
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        # :8081 reads as "busy" to the bare bind probe — exactly the
        # observable shape of our own running edge holding it.
        def fake_probe(host: str, port: int) -> bool:
            return port != 8081

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)
        # ...but the managed-edge gate recognises the holder as ours.
        monkeypatch.setattr(
            port_alloc,
            "_managed_edge_holds_default_port",
            lambda host, port: port == 8081,
        )

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081, (
            "managed edge already holds the default port — reuse it. "
            "Falling back to :8082 corrupts effective-ports.json and "
            "silently bypasses metering."
        )
        assert internal == 8090
        assert api == 8765
        # Triple defaults => no runtime.toml write.
        assert not runtime.exists(), (
            "runtime.toml must not be rewritten when we reused the "
            "default tuple; otherwise next load_effective_config keeps "
            "drifting back to the stale fallback"
        )

    def test_falls_back_when_foreign_listener_holds_default_edge_port(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Symmetry: when :8081 is held by an UNRELATED process (managed
        gate returns False), we must still fall back to :8082 and
        persist runtime.toml. The B5 fix narrowed when we trust the
        port; it must not weaken the foreign-squatter case.
        """
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        def fake_probe(host: str, port: int) -> bool:
            return port != 8081

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)
        monkeypatch.setattr(
            port_alloc,
            "_managed_edge_holds_default_port",
            lambda host, port: False,
        )

        edge, _internal, _api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8082
        assert runtime.exists()
        body = runtime.read_text(encoding="utf-8")
        assert "edge_port = 8082" in body

    def test_managed_edge_holds_default_port_is_false_on_non_darwin(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Linux + Windows must short-circuit to False — the helper
        relies on lsof+launchctl which are macOS-shaped. v0.1.22.5 is
        macOS-perfect-first per CLAUDE.md.
        """
        monkeypatch.setattr(port_alloc.sys, "platform", "linux")
        assert _REAL_MANAGED_EDGE_GATE("127.0.0.1", 8081) is False

    def test_managed_edge_holds_default_port_returns_false_when_no_listener(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """No LISTEN socket => no holder to verify => False. Defensive
        path: lsof unavailable or the port is genuinely free."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(port_alloc, "_macos_lsof_listen_pids", lambda port: [])
        # launchctl probe MUST NOT be invoked when there's no listener.
        called = {"launchctl": False}

        def fake_launchctl(label: str) -> int | None:
            called["launchctl"] = True
            return 1234

        monkeypatch.setattr(port_alloc, "_macos_launchctl_label_pid", fake_launchctl)
        assert (
            _REAL_MANAGED_EDGE_GATE("127.0.0.1", 8081) is False
        )
        assert called["launchctl"] is False

    def test_managed_edge_holds_default_port_returns_true_when_pid_matches(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(port_alloc, "_macos_lsof_listen_pids", lambda port: [3810])
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        assert _REAL_MANAGED_EDGE_GATE("127.0.0.1", 8081) is True

    def test_managed_edge_holds_default_port_returns_false_on_pid_mismatch(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Foreign listener + a known managed edge PID elsewhere: holder
        is NOT us, gate must return False so the foreign-squatter
        fallback path runs."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(port_alloc, "_macos_lsof_listen_pids", lambda port: [9999])
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        assert (
            _REAL_MANAGED_EDGE_GATE("127.0.0.1", 8081) is False
        )

    def test_stop_then_start_preserves_edge_port_via_runtime_toml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Integration-ish: simulate the user's reproduction.

        Cycle 1: edge process binds :8081 (no managed edge yet — first
        ever start). allocate_ports sees :8081 free, returns the default
        tuple, no runtime.toml written. Effective-ports.json (post-edge-
        merge) advertises :8081.

        Cycle 2: user runs ``stop && start``. The edge survived
        (KeepAlive=True) and still holds :8081. allocate_ports must
        recognise our edge as the holder and STILL return :8081 — not
        :8082. The pre-fix behaviour wrote runtime.toml with edge_port
        = 8082, which then propagated through load_effective_config to
        effective-ports.json and to apps reading HTTPS_PROXY.
        """
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        # --- Cycle 1: cold start, nothing on :8081, no managed edge yet.
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)
        monkeypatch.setattr(
            port_alloc, "_managed_edge_holds_default_port", lambda host, port: False
        )
        edge1, internal1, api1 = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert (edge1, internal1, api1) == (8081, 8090, 8765)
        assert not runtime.exists(), "fresh defaults must not stamp runtime.toml"

        # --- Cycle 2: stop && start. Edge still holds :8081 (PID 3810
        # in the user's repro). The bare bind probe sees :8081 busy.
        # The managed-edge gate must say "yes, that's us — reuse it".
        def fake_probe_cycle2(host: str, port: int) -> bool:
            return port != 8081  # :8081 busy (held by our own edge)

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe_cycle2)
        monkeypatch.setattr(
            port_alloc,
            "_managed_edge_holds_default_port",
            lambda host, port: port == 8081,
        )

        edge2, internal2, api2 = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )

        # The whole point of the fix: edge_port stays at the default.
        assert edge2 == 8081, (
            f"PID-preserving stop && start drifted edge_port to {edge2}; "
            "this is the v0.1.22.5 regression — apps reading "
            "effective-ports.json now silently bypass the meter"
        )
        assert internal2 == 8090
        assert api2 == 8765
        # runtime.toml must remain absent — we're at all-default and the
        # convergence-on-boot branch should have left no stale file.
        assert not runtime.exists(), (
            "runtime.toml stamped on a default-tuple cycle; next "
            "load_effective_config would overlay :8082 onto fresh defaults"
        )

    def test_managed_edge_label_matches_install_constant(self) -> None:
        """The label string is duplicated into ``port_alloc`` to avoid an
        import cycle (lifecycle/install -> port_alloc). This test is the
        invariant that pins the two strings together — if the install-
        side label ever changes, port_alloc's gate would silently stop
        recognising our edge and the v0.1.22.5 fallback regression would
        come back. Skip on non-darwin where install._macos isn't
        importable.
        """
        import sys as _sys

        if _sys.platform != "darwin":
            pytest.skip("install._macos is macOS-only")
        from halton_meter.install._macos import _EDGE_LABEL

        assert port_alloc._MANAGED_EDGE_LAUNCHD_LABEL == _EDGE_LABEL


# --------------------------------------------------------------------------- #
# v0.1.22.6: _macos_lsof_listen_ports_for_pid + _managed_edge_listening_port  #
# --------------------------------------------------------------------------- #


class _FakeCompletedProcess:
    """Minimal subprocess.CompletedProcess stand-in for the lsof mock."""

    def __init__(self, *, returncode: int, stdout: str = "") -> None:
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = ""


# Realistic ``lsof -nP -iTCP -sTCP:LISTEN -p <pid>`` output for the macOS
# managed edge — column 9 carries the local address; the port follows the
# final colon. Format pinned by the helper docstring.
_LSOF_LISTEN_PORTS_FIXTURE = (
    "COMMAND   PID USER   FD   TYPE             DEVICE SIZE/OFF NODE NAME\n"
    "halton-me 3810 user    7u  IPv4 0x1234567890abcdef      0t0  TCP 127.0.0.1:8081 (LISTEN)\n"
)


class TestMacosLsofListenPortsForPid:
    def test_returns_empty_on_non_darwin(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(port_alloc.sys, "platform", "linux")
        # subprocess.run must NOT be invoked on non-darwin.
        called = {"run": False}

        def fake_run(*args: object, **kwargs: object) -> _FakeCompletedProcess:
            called["run"] = True
            return _FakeCompletedProcess(returncode=0, stdout="")

        monkeypatch.setattr(port_alloc.subprocess, "run", fake_run)
        assert port_alloc._macos_lsof_listen_ports_for_pid(3810) == []
        assert called["run"] is False

    def test_returns_empty_when_lsof_missing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """OSError (executable not found) must yield an empty list, not
        raise. Defensive contract — port-seed must never break startup."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")

        def fake_run(*args: object, **kwargs: object) -> _FakeCompletedProcess:
            raise FileNotFoundError("lsof not on PATH")

        monkeypatch.setattr(port_alloc.subprocess, "run", fake_run)
        assert port_alloc._macos_lsof_listen_ports_for_pid(3810) == []

    def test_parses_listen_port_from_lsof_output(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        captured_argv: list[list[str]] = []

        def fake_run(argv: list[str], **kwargs: object) -> _FakeCompletedProcess:
            captured_argv.append(argv)
            return _FakeCompletedProcess(
                returncode=0, stdout=_LSOF_LISTEN_PORTS_FIXTURE
            )

        monkeypatch.setattr(port_alloc.subprocess, "run", fake_run)
        ports = port_alloc._macos_lsof_listen_ports_for_pid(3810)
        assert ports == [8081]
        # Argv shape: PID-scoped via -p, LISTEN-only state filter.
        assert captured_argv == [
            ["lsof", "-nP", "-iTCP", "-sTCP:LISTEN", "-p", "3810"]
        ]

    def test_returns_empty_when_pid_has_no_listen_sockets(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """lsof returns rc=1 with empty stdout when the PID has no matching
        sockets — both rc=0 and rc=1 are accepted; an empty list is the
        correct answer."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")

        def fake_run(*args: object, **kwargs: object) -> _FakeCompletedProcess:
            return _FakeCompletedProcess(returncode=1, stdout="")

        monkeypatch.setattr(port_alloc.subprocess, "run", fake_run)
        assert port_alloc._macos_lsof_listen_ports_for_pid(3810) == []

    def test_handles_ipv6_address_form(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``[::1]:8081`` must parse as port 8081 (rsplit on the final colon)."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        ipv6_line = (
            "COMMAND   PID USER   FD   TYPE             DEVICE SIZE/OFF NODE NAME\n"
            "halton-me 3810 user    8u  IPv6 0xdeadbeef      0t0  TCP [::1]:8081 (LISTEN)\n"
        )

        def fake_run(*args: object, **kwargs: object) -> _FakeCompletedProcess:
            return _FakeCompletedProcess(returncode=0, stdout=ipv6_line)

        monkeypatch.setattr(port_alloc.subprocess, "run", fake_run)
        assert port_alloc._macos_lsof_listen_ports_for_pid(3810) == [8081]


class TestManagedEdgeListeningPort:
    def test_returns_none_on_non_darwin(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Linux/Windows: macOS-perfect-first; Linux story is v0.1.23+."""
        monkeypatch.setattr(port_alloc.sys, "platform", "linux")
        # launchctl + lsof must NOT be invoked.
        monkeypatch.setattr(
            port_alloc,
            "_macos_launchctl_label_pid",
            lambda label: pytest.fail("must not invoke launchctl on non-darwin"),
        )
        monkeypatch.setattr(
            port_alloc,
            "_macos_lsof_listen_ports_for_pid",
            lambda pid: pytest.fail("must not invoke lsof on non-darwin"),
        )
        assert port_alloc._managed_edge_listening_port() is None

    def test_returns_none_when_no_managed_edge(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """launchctl reports no PID for our label => no managed edge =>
        None. lsof must NOT be probed."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: None
        )
        called = {"lsof": False}

        def fake_lsof(pid: int) -> list[int]:
            called["lsof"] = True
            return []

        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", fake_lsof
        )
        assert port_alloc._managed_edge_listening_port() is None
        assert called["lsof"] is False

    def test_returns_none_when_lsof_returns_no_ports(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Managed edge PID exists but lsof reports no LISTEN sockets
        (race: edge mid-respawn, or lsof unavailable). None is the correct
        answer — caller will preserve the legacy ``edge_port=None``
        behaviour."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: []
        )
        assert port_alloc._managed_edge_listening_port() is None

    def test_returns_bound_port_when_managed_edge_alive(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The happy path the v0.1.22.6 wiring depends on: managed edge
        alive on :8081, helper returns 8081, daemon's startup
        write_effective_ports seeds JSON with edge_port=8081."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: [8081]
        )
        assert port_alloc._managed_edge_listening_port() == 8081

    def test_returns_fallback_port_within_edge_range(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Edge legitimately fell back from :8081 to :8082 in an earlier
        session; helper must surface the actually-bound port."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: [8082]
        )
        assert port_alloc._managed_edge_listening_port() == 8082

    def test_prefers_edge_range_port_over_stray_loopback(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Defensive: when the PID has multiple LISTEN sockets, the edge-
        probe-range port wins so a stray loopback control port doesn't
        poison the result."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        # Stray :55555 sorts first; helper must skip past it to :8081.
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: [55555, 8081]
        )
        assert port_alloc._managed_edge_listening_port() == 8081

    def test_falls_through_to_first_port_when_none_in_range(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If NO reported port is inside the canonical edge range, return
        the first port — caller still gets *some* answer rather than
        None on a misconfigured edge."""
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: [55555]
        )
        assert port_alloc._managed_edge_listening_port() == 55555

    def test_composes_with_managed_edge_holds_default_port(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Regression guard: the v0.1.22.5 ``_managed_edge_holds_default_port``
        gate and the new ``_managed_edge_listening_port`` helper must
        compose correctly — same managed edge alive on :8081 means BOTH
        return a positive answer (True / 8081). They reuse the same
        primitives (``_macos_launchctl_label_pid``); a regression in
        either the gate or the helper would surface as a mismatch here.
        """
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: [8081]
        )
        # The gate uses the OTHER lsof helper (port -> PIDs); stub it to
        # match a consistent universe where PID 3810 holds :8081.
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_pids", lambda port: [3810] if port == 8081 else []
        )
        assert _REAL_MANAGED_EDGE_GATE("127.0.0.1", 8081) is True
        assert port_alloc._managed_edge_listening_port() == 8081


class TestEffectivePortsEdgePortSeed:
    """v0.1.22.6: integration-style — the daemon's startup write of
    effective-ports.json must reflect the live managed-edge port when one
    exists, and preserve the legacy ``edge_port=null`` when none does.
    The wiring lives in ``cli.py:486``; these tests exercise the contract
    end-to-end by calling ``write_effective_ports`` directly with the
    helper's output, which is what the cli call now does.
    """

    def test_seeds_edge_port_from_managed_edge_helper(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        target = tmp_path / "effective-ports.json"
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: [8081]
        )
        seeded = port_alloc._managed_edge_listening_port()
        assert seeded == 8081

        port_alloc.write_effective_ports(
            edge_port=seeded,
            internal_port=8090,
            api_port=8765,
            pid=12345,
            path=target,
        )
        eff = port_alloc.read_effective_ports(target)
        assert eff["edge_port"] == 8081
        assert eff["internal_port"] == 8090
        assert eff["api_port"] == 8765

    def test_writes_null_edge_port_when_helper_returns_none(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """No managed edge => helper returns None => JSON keeps the
        legacy ``edge_port=null`` shape (current behaviour, harmless)."""
        target = tmp_path / "effective-ports.json"
        monkeypatch.setattr(port_alloc.sys, "platform", "linux")
        seeded = port_alloc._managed_edge_listening_port()
        assert seeded is None

        port_alloc.write_effective_ports(
            edge_port=seeded,
            internal_port=8090,
            api_port=8765,
            pid=12345,
            path=target,
        )
        eff = port_alloc.read_effective_ports(target)
        # ``read_effective_ports`` only includes int fields — null
        # edge_port is omitted from the parsed dict.
        assert "edge_port" not in eff
        # Direct JSON read confirms the on-disk shape.
        import json as _json

        raw = _json.loads(target.read_text(encoding="utf-8"))
        assert raw["edge_port"] is None

    def test_simulated_stop_then_start_preserves_edge_port_in_json(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """End-to-end shape: simulate ``stop && start`` with the managed
        edge alive throughout. After the daemon's startup write, the JSON
        must advertise the edge's actually-bound port — NOT null. Pre-fix
        behaviour wrote null, leaving a window in which downstream readers
        had no edge port to advertise.
        """
        target = tmp_path / "effective-ports.json"
        monkeypatch.setattr(port_alloc.sys, "platform", "darwin")
        # Edge alive across the cycle on :8081.
        monkeypatch.setattr(
            port_alloc, "_macos_launchctl_label_pid", lambda label: 3810
        )
        monkeypatch.setattr(
            port_alloc, "_macos_lsof_listen_ports_for_pid", lambda pid: [8081]
        )

        # Simulate: previous session left a JSON with edge_port=8081.
        port_alloc.write_effective_ports(
            edge_port=8081,
            internal_port=8090,
            api_port=8765,
            pid=99999,
            path=target,
        )

        # User runs ``stop`` (edge survives KeepAlive=True) then ``start``.
        # The daemon's startup wiring at cli.py:486 calls the helper
        # then write_effective_ports.
        edge_port_seed = port_alloc._managed_edge_listening_port()
        port_alloc.write_effective_ports(
            edge_port=edge_port_seed,
            internal_port=8090,
            api_port=8765,
            pid=12345,
            path=target,
        )

        eff = port_alloc.read_effective_ports(target)
        assert eff.get("edge_port") == 8081, (
            f"effective-ports.json edge_port drifted to {eff.get('edge_port')!r} "
            "across the simulated stop && start cycle; pre-fix the JSON "
            "advertised null in this window"
        )
