import os

from hs2p.utils.stderr import run_with_filtered_stderr, run_with_filtered_stdio


def test_run_with_filtered_stderr_suppresses_known_cucim_noise(capfd):
    def _write_noise():
        os.write(2, b"cuInit Failed, error CUDA_ERROR_NO_DEVICE\n")
        os.write(2, b"cuFile initialization failed\n")
        os.write(2, b"kept line\n")
        return 123

    result = run_with_filtered_stderr(_write_noise)
    captured = capfd.readouterr()

    assert result == 123
    assert captured.err == "kept line\n"


def test_run_with_filtered_stderr_forwards_unrelated_stderr(capfd):
    def _write_noise():
        os.write(2, b"unrelated warning\n")
        return 7

    result = run_with_filtered_stderr(_write_noise)
    captured = capfd.readouterr()

    assert result == 7
    assert captured.err == "unrelated warning\n"


def test_run_with_filtered_stderr_suppresses_interleaved_cucim_noise(capfd):
    def _write_noise():
        os.write(
            2,
            b" cuInit Failed, errorcuFile initialization failed \nCUDA_ERROR_NOT_INITIALIZED\n",
        )
        os.write(2, b"kept line\n")
        return 11

    result = run_with_filtered_stderr(_write_noise)
    captured = capfd.readouterr()

    assert result == 11
    assert captured.err == "kept line\n"


def test_run_with_filtered_stdio_suppresses_known_cucim_noise_from_stdout_and_stderr(capfd):
    def _write_noise():
        os.write(1, b"cuInit Failed, error CUDA_ERROR_NO_DEVICE\n")
        os.write(2, b"cuFile initialization failed\n")
        os.write(1, b"kept stdout\n")
        os.write(2, b"kept stderr\n")
        return 5

    result = run_with_filtered_stdio(_write_noise)
    captured = capfd.readouterr()

    assert result == 5
    assert captured.out == "kept stdout\n"
    assert captured.err == "kept stderr\n"
