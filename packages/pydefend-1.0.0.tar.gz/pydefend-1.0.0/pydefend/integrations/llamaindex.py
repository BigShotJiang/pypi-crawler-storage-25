from __future__ import annotations

import asyncio
from typing import Any

from ..core import Defend


class DefendNodePostprocessor:
    """
    Minimal postprocessor hook for guarding retrieved nodes.

    This implementation is deliberately duck-typed so it can work without importing LlamaIndex types.
    It expects an iterable of nodes, each with either:
    - `get_content()` method, or
    - `text` / `content` attribute, or
    - dict with `text` key.
    """

    def __init__(self, defend: Defend) -> None:
        self._defend = defend

    # Compatibility with LlamaIndex's BaseNodePostprocessor interface.
    async def apostprocess_nodes(self, nodes: Any, **kwargs: Any) -> Any:
        if nodes is None:
            return nodes
        try:
            node_list = list(nodes)
        except TypeError:
            return nodes

        def _get_text(n: Any) -> str | None:
            if isinstance(n, dict):
                v = n.get("text")
                return v if isinstance(v, str) else None
            if hasattr(n, "get_content") and callable(getattr(n, "get_content")):
                try:
                    v = n.get_content()
                    return v if isinstance(v, str) else None
                except Exception:
                    pass
            for attr in ("text", "content"):
                v = getattr(n, attr, None)
                if isinstance(v, str):
                    return v
            return None

        texts: list[str] = []
        idx_map: list[int] = []
        for i, n in enumerate(node_list):
            t = _get_text(n)
            if t is None:
                continue
            texts.append(t)
            idx_map.append(i)

        if not texts:
            return nodes

        results = await self._defend.scan_batch(texts, concurrency=20)
        keep: list[Any] = []
        for orig_i, t, r in zip(idx_map, texts, results):
            if not r:
                continue
            n = node_list[orig_i]
            if r.text is not None and r.text != t:
                if isinstance(n, dict):
                    n = dict(n)
                    n["text"] = r.text
                elif hasattr(n, "text"):
                    try:
                        setattr(n, "text", r.text)
                    except Exception:
                        pass
            keep.append(n)
        return keep

    def postprocess_nodes(self, nodes: Any, **kwargs: Any) -> Any:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self.apostprocess_nodes(nodes, **kwargs))
        raise RuntimeError(
            "postprocess_nodes() cannot be called while an event loop is running. "
            "Use `await apostprocess_nodes(...)` instead."
        )


class DefendQueryFilter:
    def __init__(self, defend: Defend) -> None:
        self._defend = defend

    async def filter(self, query: str) -> str:
        """Return a safe query string (or empty string if blocked)."""
        r = await self._defend.scan(query)
        return r.text or "" if r else ""

    def filter_sync(self, query: str) -> str:
        r = self._defend.scan_sync(query)
        return r.text or "" if r else ""
