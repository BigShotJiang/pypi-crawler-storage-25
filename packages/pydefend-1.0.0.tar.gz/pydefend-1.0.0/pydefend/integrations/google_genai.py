from __future__ import annotations

from typing import Any

from ..core import Defend


class GuardedGemini:
    """
    Thin wrapper: scans user text before ``models.generate_content``,
    and checks assistant text after (google-genai client).
    """

    def __init__(self, defend: Defend, client: Any | None = None, *, model: str | None = None) -> None:
        try:
            from google import genai
        except Exception as exc:
            raise RuntimeError('google-genai is not installed; install "pydefend[gemini]"') from exc

        self._defend = defend
        self._client = client or genai.Client()
        self._default_model = model
        self.models = _ModelsNamespace(self)

    @property
    def inner(self) -> Any:
        return self._client


class _ModelsNamespace:
    def __init__(self, g: GuardedGemini) -> None:
        self._g = g

    async def generate_content(self, *args: Any, **kwargs: Any) -> Any:
        # Support both patterns:
        # - client.models.generate_content(model=..., contents=...)
        # - client.models.generate_content(contents=...) with a default model
        contents = kwargs.get("contents")
        if isinstance(contents, str):
            res = await self._g._defend.scan(contents)
            if not res:
                raise RuntimeError(f"defend blocked input: {res.action.value}")
            if res.text is not None:
                kwargs["contents"] = res.text

        if "model" not in kwargs and self._g._default_model:
            kwargs["model"] = self._g._default_model

        resp = self._g._client.models.generate_content(*args, **kwargs)
        try:
            txt = getattr(resp, "text", None)
            if isinstance(txt, str) and txt:
                out = await self._g._defend.check(txt)
                if out.text is not None:
                    # Best-effort: patch the response text if it's mutable.
                    try:
                        resp.text = out.text
                    except Exception:
                        pass
        except Exception:
            pass
        return resp

