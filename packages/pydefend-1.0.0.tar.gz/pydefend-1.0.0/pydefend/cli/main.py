from __future__ import annotations

import asyncio
import json
from pathlib import Path

import typer

app = typer.Typer(add_completion=False, help="pydefend CLI")


@app.command("validate")
def validate_cmd(path: str = typer.Argument(..., help="Path to defend.yaml")) -> None:
    from ..config import load_defend_config
    from ..exceptions import ConfigError

    try:
        load_defend_config(path)
    except ConfigError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    typer.echo("ok")


@app.command("init")
def init_cmd(
    preset: str = typer.Option(
        "default",
        "--preset",
        help="default",
    ),
    out: Path | None = typer.Option(
        None,
        "--out",
        help="Write YAML to this path as UTF-8 (recommended on Windows)",
    ),
) -> None:
    from ..config import preset_yaml
    from ..exceptions import ConfigError

    try:
        yml = preset_yaml(preset)
    except ConfigError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    if out is not None:
        out.write_text(yml, encoding="utf-8", newline="\n")
        return
    typer.echo(yml, nl=False)


@app.command("test")
def test_cmd(
    config: str = typer.Option(..., "--config", help="defend.yaml path"),
    input_text: str | None = typer.Option(None, "--input", help="Text to scan"),
) -> None:
    from ..config import load_defend_config
    from ..exceptions import ConfigError

    if not input_text:
        typer.echo("--input required", err=True)
        raise typer.Exit(1)
    try:
        defend = load_defend_config(config)
    except ConfigError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc

    async def _run() -> None:
        r = await defend.scan(input_text)
        typer.echo(json.dumps(r.to_dict(), indent=2))

    asyncio.run(_run())

def main() -> None:
    app()


if __name__ == "__main__":
    main()
