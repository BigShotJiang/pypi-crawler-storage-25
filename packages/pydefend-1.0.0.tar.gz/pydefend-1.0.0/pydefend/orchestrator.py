from __future__ import annotations

import logging
from typing import Literal

from .context import GuardContext
from .exceptions import ProviderError
from .messaging import format_provider_failure_one_line
from .modules.base import BaseModule
from .policy import OnFail, on_fail_to_action, resolve_on_fail_dynamic
from .providers.base import BaseProvider, ClassifierModuleOutcome, ProviderUnavailableError
from .types import Action, DefendResult, Severity, Violation

_LOG = logging.getLogger("pydefend")


def _infer_severity(confidence: float, action: Action) -> Severity:
    if action == Action.BLOCKED:
        return Severity.CRITICAL if confidence >= 0.85 else Severity.HIGH
    if action == Action.REDACTED:
        return Severity.HIGH if confidence >= 0.7 else Severity.MEDIUM
    if action in (Action.WARNED, Action.FLAGGED):
        return Severity.MEDIUM if confidence >= 0.5 else Severity.LOW
    return Severity.LOW


def _aggregate_action(actions: list[Action]) -> Action:
    order = (Action.BLOCKED, Action.REDACTED, Action.WARNED, Action.FLAGGED, Action.PASSED)
    rank = {a: i for i, a in enumerate(order)}
    best = Action.PASSED
    for a in actions:
        if rank[a] < rank[best]:
            best = a
    return best


def _modules_for_direction(modules: list[BaseModule], direction: Literal["input", "output"]) -> list[BaseModule]:
    out: list[BaseModule] = []
    for m in modules:
        if m.direction == "both" or m.direction == direction:
            out.append(m)
    return out


async def run_guard(
    *,
    text: str,
    direction: Literal["input", "output"],
    provider: BaseProvider,
    all_modules: list[BaseModule],
    global_on_fail: OnFail | None,
    timeout: float | None,
    max_input_chars: int | None,
    module_error_policy: str,
    ctx: GuardContext,
    extra_system_suffix: str = "",
    images: list[bytes] | None = None,
    image_format: str = "auto",
) -> DefendResult:
    original = text
    if max_input_chars is not None and len(text) > max_input_chars:
        text = text[:max_input_chars]

    modules = _modules_for_direction(all_modules, direction)
    if not modules:
        return DefendResult(
            flagged=False,
            action=Action.PASSED,
            text=original,
            original_text=original,
            violations=[],
            latency_ms=0.0,
            provider=provider.name,
            _scan_is_input=(direction == "input"),
        )

    allowed = {m.name for m in modules}
    by_name = {m.name: m for m in modules}

    suffix = extra_system_suffix.strip()
    if max_input_chars is not None:
        note = f"Runtime note: input text is limited to the first {max_input_chars} characters."
        if len(original) > max_input_chars:
            note = f"{note} (truncated before evaluation)"
        if suffix:
            suffix = f"{suffix}\n\n{note}"
        else:
            suffix = note

    batch_latency = 0.0
    outcomes: list[ClassifierModuleOutcome] = []
    try:
        if images:
            batch = await provider.classify_modules_multimodal(
                text=text,
                images=images,
                image_format=image_format,
                modules=modules,
                allowed_module_names=allowed,
                timeout=timeout,
                extra_system_suffix=suffix,
            )
        else:
            batch = await provider.classify_modules(
                text,
                modules,
                allowed,
                timeout=timeout,
                extra_system_suffix=suffix,
            )
        batch_latency = batch.latency_ms
        outcomes = batch.outcomes
    except (ProviderUnavailableError, TimeoutError) as exc:
        _LOG.warning("%s", format_provider_failure_one_line(provider.name, exc).message)
        if module_error_policy == "raise":
            raise ProviderError(provider.name, underlying=exc) from exc
        if module_error_policy == "block":
            return DefendResult(
                flagged=True,
                action=Action.BLOCKED,
                text=None,
                original_text=original,
                violations=[
                    Violation(
                        module="_provider",
                        category="provider_failure",
                        severity=Severity.HIGH,
                        confidence=1.0,
                        action_taken=Action.BLOCKED,
                        explanation=str(exc),
                    )
                ],
                latency_ms=0.0,
                provider=provider.name,
                _scan_is_input=(direction == "input"),
            )
        if module_error_policy == "warn":
            return DefendResult(
                flagged=True,
                action=Action.WARNED,
                text=original,
                original_text=original,
                violations=[
                    Violation(
                        module="_provider",
                        category="provider_failure",
                        severity=Severity.LOW,
                        confidence=1.0,
                        action_taken=Action.WARNED,
                        explanation=str(exc),
                    )
                ],
                latency_ms=0.0,
                provider=provider.name,
                _scan_is_input=(direction == "input"),
            )
        return DefendResult(
            flagged=False,
            action=Action.PASSED,
            text=original,
            original_text=original,
            violations=[],
            latency_ms=0.0,
            provider=provider.name,
            _scan_is_input=(direction == "input"),
        )
    except ValueError as exc:
        # Some provider implementations raise ValueError for setup/misconfig (e.g. Azure).
        _LOG.warning("%s", format_provider_failure_one_line(provider.name, exc).message)
        if module_error_policy == "raise":
            raise ProviderError(provider.name, underlying=exc) from exc
        if module_error_policy == "block":
            return DefendResult(
                flagged=True,
                action=Action.BLOCKED,
                text=None,
                original_text=original,
                violations=[
                    Violation(
                        module="_provider",
                        category="provider_failure",
                        severity=Severity.HIGH,
                        confidence=1.0,
                        action_taken=Action.BLOCKED,
                        explanation=str(exc),
                    )
                ],
                latency_ms=0.0,
                provider=provider.name,
                _scan_is_input=(direction == "input"),
            )
        if module_error_policy == "warn":
            return DefendResult(
                flagged=True,
                action=Action.WARNED,
                text=original,
                original_text=original,
                violations=[
                    Violation(
                        module="_provider",
                        category="provider_failure",
                        severity=Severity.LOW,
                        confidence=1.0,
                        action_taken=Action.WARNED,
                        explanation=str(exc),
                    )
                ],
                latency_ms=0.0,
                provider=provider.name,
                _scan_is_input=(direction == "input"),
            )
        return DefendResult(
            flagged=False,
            action=Action.PASSED,
            text=original,
            original_text=original,
            violations=[],
            latency_ms=0.0,
            provider=provider.name,
            _scan_is_input=(direction == "input"),
        )
    except Exception as exc:
        _LOG.warning("pydefend unexpected error: %s", exc)
        if module_error_policy == "raise":
            raise
        if module_error_policy == "block":
            return DefendResult(
                flagged=True,
                action=Action.BLOCKED,
                text=None,
                original_text=original,
                violations=[
                    Violation(
                        module="_provider",
                        category="internal_error",
                        severity=Severity.HIGH,
                        confidence=1.0,
                        action_taken=Action.BLOCKED,
                        explanation=str(exc),
                    )
                ],
                latency_ms=0.0,
                provider=provider.name,
                _scan_is_input=(direction == "input"),
            )
        return DefendResult(
            flagged=False,
            action=Action.PASSED,
            text=original,
            original_text=original,
            violations=[],
            latency_ms=0.0,
            provider=provider.name,
            _scan_is_input=(direction == "input"),
        )

    violations: list[Violation] = []
    per_actions: list[Action] = []
    any_triggered = False
    needs_redacted_text = False

    for o in outcomes:
        mod = by_name.get(o.module)
        if mod is None:
            continue
        if not o.triggered:
            continue
        any_triggered = True
        placeholder = Violation(
            module=o.module,
            category=o.category,
            severity=Severity.MEDIUM,
            confidence=o.confidence,
            action_taken=Action.PASSED,
            explanation=o.explanation,
        )
        resolved = resolve_on_fail_dynamic(mod.on_fail, global_on_fail, placeholder, ctx)
        act = on_fail_to_action(resolved)
        expl = o.explanation
        if act == Action.REDACTED:
            needs_redacted_text = True
        sev = _infer_severity(o.confidence, act)
        violations.append(
            Violation(
                module=o.module,
                category=o.category,
                severity=sev,
                confidence=o.confidence,
                action_taken=act,
                explanation=expl,
            ),
        )
        per_actions.append(act)

    flagged = any_triggered
    if not per_actions:
        agg = Action.PASSED
    else:
        agg = _aggregate_action(per_actions)

    if needs_redacted_text and not batch.redacted_text:
        # Redaction was requested by policy, but the provider didn't supply a redacted version.
        # Fail closed to avoid leaking sensitive content.
        agg = Action.BLOCKED
        for v in violations:
            if v.action_taken == Action.REDACTED:
                v.action_taken = Action.BLOCKED
                v.severity = _infer_severity(v.confidence, Action.BLOCKED)
                v.explanation = (v.explanation or "") + " (redact requested but no redacted_text; blocked)"

    if agg == Action.BLOCKED:
        out_text: str | None = None
    elif agg == Action.REDACTED:
        out_text = batch.redacted_text or None
    else:
        out_text = original

    return DefendResult(
        flagged=flagged,
        action=agg,
        text=out_text,
        original_text=original,
        violations=violations,
        latency_ms=batch_latency,
        provider=provider.name,
        _scan_is_input=(direction == "input"),
    )
