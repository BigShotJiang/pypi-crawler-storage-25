from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .core import Defend, DefendRuntime
from .exceptions import ConfigError
from .modules import (
    BanCode,
    BanCompetitors,
    BanCompetitorsOutput,
    BaseModule,
    BiasOutput,
    CanaryToken,
    CodeExecutionOutput,
    Custom,
    CustomOutput,
    ExcessiveAgency,
    FinancialPii,
    FinancialPiiOutput,
    HallucinationOutput,
    HealthPii,
    HealthPiiOutput,
    ImagePii,
    IndirectInjection,
    Injection,
    InvisibleText,
    Jailbreak,
    MaliciousUrl,
    NoRefusalOutput,
    Pii,
    PiiOutput,
    PromptComplexity,
    PromptLeak,
    RelevanceOutput,
    Secrets,
    SecretsOutput,
    SensitiveTopics,
    SentimentOutput,
    ToolMisuse,
    Topic,
    TopicOutput,
    Toxicity,
    ToxicityOutput,
    VisualInjection,
)
from .policy import OnFail
from .providers.resolve import resolve_provider

MODULE_CLASS_BY_NAME: dict[str, type[BaseModule]] = {
    "injection": Injection,
    "jailbreak": Jailbreak,
    "invisible_text": InvisibleText,
    "indirect_injection": IndirectInjection,
    "secrets": Secrets,
    "pii": Pii,
    "financial_pii": FinancialPii,
    "health_pii": HealthPii,
    "visual_injection": VisualInjection,
    "image_pii": ImagePii,
    "toxicity": Toxicity,
    "sensitive_topics": SensitiveTopics,
    "topic": Topic,
    "ban_code": BanCode,
    "ban_competitors": BanCompetitors,
    "prompt_complexity": PromptComplexity,
    "custom": Custom,
    "prompt_leak": PromptLeak,
    "secrets_output": SecretsOutput,
    "pii_output": PiiOutput,
    "financial_pii_output": FinancialPiiOutput,
    "health_pii_output": HealthPiiOutput,
    "malicious_url": MaliciousUrl,
    "canary_token": CanaryToken,
    "code_execution_output": CodeExecutionOutput,
    "tool_misuse": ToolMisuse,
    "excessive_agency": ExcessiveAgency,
    "toxicity_output": ToxicityOutput,
    "bias_output": BiasOutput,
    "topic_output": TopicOutput,
    "ban_competitors_output": BanCompetitorsOutput,
    "custom_output": CustomOutput,
    "hallucination_output": HallucinationOutput,
    "relevance_output": RelevanceOutput,
    "no_refusal_output": NoRefusalOutput,
    "sentiment_output": SentimentOutput,
}


def _module_cfg_for_yaml(m: BaseModule) -> dict[str, Any]:
    # Modules store their constructor kwargs in `_extra` (non-public); we use that for round-trippable YAML.
    extra = dict(getattr(m, "_extra", {}) or {})
    cfg = getattr(m, "_cfg", None)
    if isinstance(cfg, dict):
        extra = {**cfg, **extra}
    on_fail = getattr(m, "on_fail", None)
    timeout = getattr(m, "timeout", None)
    if isinstance(on_fail, OnFail):
        extra["on_fail"] = on_fail.value
    elif on_fail is not None:
        # Non-serializable callable policy; omit from YAML rather than emitting an invalid value.
        extra.pop("on_fail", None)
    if timeout is not None:
        extra["timeout"] = float(timeout)
    return extra


def _defend_to_yaml_dict(d: Defend, *, provider: str = "auto") -> dict[str, Any]:
    rt = d._runtime
    modules: dict[str, Any] = {
        "input": [{m.name: _module_cfg_for_yaml(m) or {}} for m in rt.input_modules],
        "output": [{m.name: _module_cfg_for_yaml(m) or {}} for m in rt.output_modules],
    }
    out: dict[str, Any] = {
        "provider": provider,
        "timeout": rt.timeout,
        "max_input_chars": rt.max_input_chars,
        "on_fail": rt.global_on_fail.value if isinstance(rt.global_on_fail, OnFail) else None,
        "module_error_policy": rt.module_error_policy,
        "modules": modules,
    }
    # Keep the init output clean: omit null-ish values rather than emitting YAML nulls.
    if out.get("timeout") is None:
        out.pop("timeout", None)
    if out.get("max_input_chars") is None:
        out.pop("max_input_chars", None)
    if out.get("on_fail") is None:
        out.pop("on_fail", None)
    return out


def _yaml_dump(data: dict[str, Any]) -> str:
    # Stable, human-friendly YAML for docs + config files.
    return yaml.safe_dump(
        data,
        sort_keys=False,
        default_flow_style=False,
        allow_unicode=True,
    )


def _coerce_on_fail(raw: Any) -> OnFail | None:
    if raw is None:
        return None
    if isinstance(raw, OnFail):
        return raw
    if isinstance(raw, str):
        try:
            return OnFail(raw.strip().lower())
        except ValueError as exc:
            raise ConfigError(f"invalid on_fail: {raw!r}") from exc
    raise ConfigError(f"invalid on_fail type: {type(raw)}")


def _instantiate_module(name: str, cfg: dict[str, Any]) -> BaseModule:
    cls = MODULE_CLASS_BY_NAME.get(name)
    if cls is None:
        raise ConfigError(f"unknown module: {name!r}")
    cfg = dict(cfg)
    cfg.setdefault("on_fail", OnFail.BLOCK.value)
    return cls(**cfg)


def _parse_module_list(entries: Any) -> list[BaseModule]:
    if entries is None:
        return []
    if not isinstance(entries, list):
        raise ConfigError("modules.input / modules.output must be lists")
    mods: list[BaseModule] = []
    for item in entries:
        if not isinstance(item, dict) or len(item) != 1:
            raise ConfigError("each module entry must be a single-key dict, e.g. injection: {...}")
        name, cfg = next(iter(item.items()))
        if cfg is None:
            cfg = {}
        if not isinstance(cfg, dict):
            raise ConfigError(f"config for {name!r} must be a mapping")
        mods.append(_instantiate_module(str(name), cfg))
    return mods


def load_defend_config(path: str | Path) -> Defend:
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"config file not found: {p}")

    try:
        data = p.read_bytes()
        # PowerShell redirection (and some editors) commonly write UTF-16 with BOM on Windows.
        if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
            text = data.decode("utf-16")
        else:
            text = data.decode("utf-8")
        if not text.strip():
            raise ConfigError("invalid YAML: empty config file")
        raw = yaml.safe_load(text)
    except Exception as exc:
        raise ConfigError(f"invalid YAML: {exc}") from exc
    if raw is None:
        raise ConfigError("invalid YAML: empty document")
    if not isinstance(raw, dict):
        raise ConfigError("top level of defend.yaml must be a mapping")

    provider = str(raw.get("provider", "auto") or "auto").strip().lower()
    model = raw.get("model")
    model_s = str(model) if model is not None else None
    timeout = raw.get("timeout")
    timeout_f = float(timeout) if isinstance(timeout, (int, float)) else None
    mic_raw = raw.get("max_input_chars", 8192)
    if mic_raw is None:
        max_input_chars: int | None = None
    elif isinstance(mic_raw, int):
        if mic_raw <= 0:
            raise ConfigError("max_input_chars must be a positive integer or null")
        max_input_chars = mic_raw
    else:
        raise ConfigError("max_input_chars must be an integer or null")
    global_on_fail = _coerce_on_fail(raw.get("on_fail"))

    modules = raw.get("modules") or {}
    if not isinstance(modules, dict):
        raise ConfigError("modules must be a mapping")
    inp = _parse_module_list(modules.get("input"))
    out = _parse_module_list(modules.get("output"))

    mep = str(raw.get("module_error_policy", "passthrough") or "passthrough").strip().lower()
    if mep not in ("passthrough", "warn", "raise", "block"):
        raise ConfigError(f"invalid module_error_policy: {mep!r}")

    audit = raw.get("audit") or {}
    if audit and not isinstance(audit, dict):
        raise ConfigError("audit must be a mapping")

    prov = resolve_provider(provider=None if provider == "auto" else provider, model=model_s)

    all_m = DefendRuntime.merge_modules(tuple(inp), tuple(out))
    rt = DefendRuntime(
        provider=prov,
        input_modules=tuple(inp),
        output_modules=tuple(out),
        global_on_fail=global_on_fail,
        timeout=timeout_f,
        max_input_chars=max_input_chars,
        module_error_policy=mep,
        all_modules=all_m,
    )
    d = Defend(_runtime=rt)
    if isinstance(audit, dict) and audit.get("enabled"):
        from .observe import StructuredLogger

        if str(audit.get("backend", "stdout")).strip().lower() in ("stdout", "stderr", ""):
            d.observe(StructuredLogger(level=str(audit.get("log_level", "INFO"))))
    return d


def preset_yaml(preset: str) -> str:
    """Return starter YAML for `defend init --preset`."""
    p = preset.strip().lower()
    if p == "default":
        return _yaml_dump(_defend_to_yaml_dict(Defend.default()))
    raise ConfigError(f"unknown preset: {preset!r}")
