from __future__ import annotations

from typing import Any

from .base import BaseProvider
from .claude import ClaudeProvider
from .gemini import GeminiProvider
from .openai import OpenAIProvider


async def run_simple_classifier(
    provider: BaseProvider,
    user_text: str,
    *,
    timeout: float | None = None,
) -> dict[str, Any]:
    """Run a small JSON tool call for custom / PromptModule authors."""
    if isinstance(provider, ClaudeProvider):
        return await provider.classify_simple_json(user_text, timeout=timeout)
    if isinstance(provider, OpenAIProvider):
        return await provider.classify_simple_json(user_text, timeout=timeout)
    if isinstance(provider, GeminiProvider):
        return await provider.classify_simple_json(user_text, timeout=timeout)
    raise NotImplementedError(f"run_simple_classifier not implemented for provider {provider.name!r}")
