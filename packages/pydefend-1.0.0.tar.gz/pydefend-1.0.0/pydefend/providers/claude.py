from __future__ import annotations

import base64
import os
import time
from typing import Any

import anyio

from ..modules.base import BaseModule
from ._batch_schema import (
    EVAL_SYSTEM_PROMPT,
    build_module_results_claude_tool,
    normalize_module_outcomes,
)
from .base import BaseProvider, ClassifierBatchResult, ProviderUnavailableError

Anthropic: Any | None = None
APIStatusError: Any = Exception

try:
    from anthropic import Anthropic, APIStatusError
except Exception:
    Anthropic = None
    APIStatusError = Exception


class ClaudeProvider(BaseProvider):
    name = "claude"
    supports_modules = True

    def __init__(
        self,
        api_key: str | None = None,
        *,
        model: str = "claude-haiku-4-5",
        max_input_tokens: int | None = 2048,
    ) -> None:
        self._client: Anthropic | None = None
        self._api_key = api_key
        self._model = model
        self._max_input_tokens = max_input_tokens

    async def classify_modules(
        self,
        text: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        *,
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        start = time.perf_counter()
        if not modules or not allowed_module_names:
            return ClassifierBatchResult(outcomes=[], latency_ms=0.0, provider=self.name)

        module_instructions = "\n\n".join(m.system_prompt() for m in modules)
        allowed_list = ", ".join(f'"{n}"' for n in sorted(allowed_module_names))
        module_instructions = f"""{module_instructions}

Configured module names (emit one module_results entry per name): [{allowed_list}]"""
        if extra_system_suffix.strip():
            module_instructions = f"{module_instructions}\n\n{extra_system_suffix.strip()}"

        system = EVAL_SYSTEM_PROMPT.format(module_instructions=module_instructions)

        max_input_tokens = self._max_input_tokens
        if max_input_tokens and max_input_tokens > 0:
            max_chars = max_input_tokens * 4
            if len(text) > max_chars:
                text = text[:max_chars]

        if Anthropic is None:
            raise ProviderUnavailableError('anthropic is not installed; install "pydefend[anthropic]"')
        if not self._api_key and not os.environ.get("ANTHROPIC_API_KEY"):
            raise ProviderUnavailableError("ANTHROPIC_API_KEY is not set")
        try:
            if self._client is None:
                self._client = Anthropic(api_key=self._api_key) if self._api_key else Anthropic()

            tool = build_module_results_claude_tool(allowed_module_names)

            def _call_claude() -> object:
                return self._client.messages.create(
                    model=self._model,
                    max_tokens=1024,
                    system=system,
                    messages=[{"role": "user", "content": text}],
                    tools=[tool],
                    tool_choice={"type": "tool", "name": "submit_module_results"},
                )

            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call_claude)
            else:
                response = await anyio.to_thread.run_sync(_call_claude)
        except TimeoutError as exc:
            raise ProviderUnavailableError(f"claude timeout: {exc}") from exc
        except APIStatusError as exc:
            raise ProviderUnavailableError(f"claude API error: {exc}") from exc
        except Exception as exc:
            raise ProviderUnavailableError(f"claude error: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000

        payload: dict[str, Any] | None = None
        for block in response.content:
            if (
                getattr(block, "type", None) == "tool_use"
                and getattr(block, "name", None) == "submit_module_results"
            ):
                payload = getattr(block, "input", None)
                break
        if not isinstance(payload, dict):
            raise ProviderUnavailableError("claude invalid tool payload")

        raw = payload.get("module_results")
        if not isinstance(raw, list):
            raise ProviderUnavailableError("claude missing module_results")
        rows = [r for r in raw if isinstance(r, dict)]
        outcomes = normalize_module_outcomes(rows, allowed_module_names)
        redacted_text = payload.get("redacted_text")
        return ClassifierBatchResult(
            outcomes=outcomes,
            latency_ms=latency_ms,
            provider=self.name,
            redacted_text=str(redacted_text) if isinstance(redacted_text, str) else None,
        )

    async def classify_modules_multimodal(
        self,
        *,
        text: str,
        images: list[bytes],
        image_format: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        start = time.perf_counter()
        if not modules or not allowed_module_names:
            return ClassifierBatchResult(outcomes=[], latency_ms=0.0, provider=self.name)

        module_instructions = "\n\n".join(m.system_prompt() for m in modules)
        allowed_list = ", ".join(f'"{n}"' for n in sorted(allowed_module_names))
        module_instructions = f"""{module_instructions}

Configured module names (emit one module_results entry per name): [{allowed_list}]"""
        if extra_system_suffix.strip():
            module_instructions = f"{module_instructions}\n\n{extra_system_suffix.strip()}"
        system = EVAL_SYSTEM_PROMPT.format(module_instructions=module_instructions)

        fmt = (image_format or "auto").strip().lower()
        if fmt == "auto":
            fmt = "png"

        content: list[dict[str, Any]] = [{"type": "text", "text": text}]
        for b in images:
            b64 = base64.b64encode(b).decode("ascii")
            content.append(
                {
                    "type": "image",
                    "source": {"type": "base64", "media_type": f"image/{fmt}", "data": b64},
                },
            )

        if Anthropic is None:
            raise ProviderUnavailableError('anthropic is not installed; install "pydefend[anthropic]"')
        if not self._api_key and not os.environ.get("ANTHROPIC_API_KEY"):
            raise ProviderUnavailableError("ANTHROPIC_API_KEY is not set")
        try:
            if self._client is None:
                self._client = Anthropic(api_key=self._api_key) if self._api_key else Anthropic()

            tool = build_module_results_claude_tool(allowed_module_names)

            def _call_claude() -> object:
                return self._client.messages.create(
                    model=self._model,
                    max_tokens=1024,
                    system=system,
                    messages=[{"role": "user", "content": content}],
                    tools=[tool],
                    tool_choice={"type": "tool", "name": "submit_module_results"},
                )

            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call_claude)
            else:
                response = await anyio.to_thread.run_sync(_call_claude)
        except TimeoutError as exc:
            raise ProviderUnavailableError(f"claude timeout: {exc}") from exc
        except APIStatusError as exc:
            raise ProviderUnavailableError(f"claude API error: {exc}") from exc
        except Exception as exc:
            raise ProviderUnavailableError(f"claude error: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000

        payload: dict[str, Any] | None = None
        for block in response.content:
            if (
                getattr(block, "type", None) == "tool_use"
                and getattr(block, "name", None) == "submit_module_results"
            ):
                payload = getattr(block, "input", None)
                break
        if not isinstance(payload, dict):
            raise ProviderUnavailableError("claude invalid tool payload")

        raw = payload.get("module_results")
        if not isinstance(raw, list):
            raise ProviderUnavailableError("claude missing module_results")
        rows = [r for r in raw if isinstance(r, dict)]
        outcomes = normalize_module_outcomes(rows, allowed_module_names)
        redacted_text = payload.get("redacted_text")
        return ClassifierBatchResult(
            outcomes=outcomes,
            latency_ms=latency_ms,
            provider=self.name,
            redacted_text=str(redacted_text) if isinstance(redacted_text, str) else None,
        )

    async def classify_simple_json(self, user_text: str, *, timeout: float | None = None) -> dict[str, Any]:
        """Small JSON verdict: flagged, confidence, reason."""
        tool = {
            "name": "submit_simple_verdict",
            "description": "Binary classification result.",
            "input_schema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "flagged": {"type": "boolean"},
                    "confidence": {"type": "number"},
                    "reason": {"type": "string"},
                },
                "required": ["flagged", "confidence", "reason"],
            },
        }
        if self._client is None:
            self._client = Anthropic(api_key=self._api_key) if self._api_key else Anthropic()

        def _call() -> object:
            return self._client.messages.create(
                model=self._model,
                max_tokens=256,
                system="Respond only via the tool with valid JSON fields.",
                messages=[{"role": "user", "content": user_text}],
                tools=[tool],
                tool_choice={"type": "tool", "name": "submit_simple_verdict"},
            )

        try:
            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call)
            else:
                response = await anyio.to_thread.run_sync(_call)
        except Exception as exc:
            raise ProviderUnavailableError(f"claude classify_simple_json: {exc}") from exc

        for block in response.content:
            if getattr(block, "type", None) == "tool_use" and getattr(block, "name", None) == "submit_simple_verdict":
                inp = getattr(block, "input", None)
                if isinstance(inp, dict):
                    return inp
        return {"flagged": False, "confidence": 0.0, "reason": "no tool output"}
