from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from ..modules.base import BaseModule


@dataclass
class ClassifierModuleOutcome:
    module: str
    triggered: bool
    confidence: float = 0.0
    category: str | None = None
    explanation: str | None = None


@dataclass
class ClassifierBatchResult:
    outcomes: list[ClassifierModuleOutcome]
    latency_ms: float
    provider: str
    redacted_text: str | None = None


class ProviderUnavailableError(RuntimeError):
    """Raised when an upstream provider is temporarily unavailable."""


class BaseProvider(ABC):
    name: str
    supports_modules: bool = False

    @abstractmethod
    async def classify_modules(
        self,
        text: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        *,
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        ...

    async def classify_modules_multimodal(
        self,
        *,
        text: str,
        images: list[bytes],
        image_format: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        """
        Optional multimodal module classification.

        Providers that do not support vision should raise ProviderUnavailableError.
        """
        raise ProviderUnavailableError(f"multimodal classify not implemented for provider {self.name!r}")

    async def health_check(self) -> bool:
        return True
