from __future__ import annotations

import json
import os
import time
from typing import Any

import anyio

from ..modules.base import BaseModule
from ._batch_schema import (
    EVAL_SYSTEM_PROMPT,
    build_module_results_openai_schema,
    normalize_module_outcomes,
)
from .base import BaseProvider, ClassifierBatchResult, ProviderUnavailableError

genai: Any | None = None
types: Any | None = None

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None
    types = None


class GeminiProvider(BaseProvider):
    name = "gemini"
    supports_modules = True

    def __init__(
        self,
        api_key: str | None = None,
        *,
        model: str = "gemini-2.5-flash",
        max_input_tokens: int | None = 2048,
    ) -> None:
        self._client: Any | None = None
        self._api_key = api_key
        self._model = model
        self._max_input_tokens = max_input_tokens

    def _ensure_client(self) -> Any:
        if genai is None or types is None:
            raise ProviderUnavailableError('google-genai is not installed; install "pydefend[gemini]"')
        key = self._api_key or os.environ.get("GOOGLE_API_KEY")
        if not key:
            raise ProviderUnavailableError("GOOGLE_API_KEY is not set")
        if self._client is None:
            self._client = genai.Client(api_key=key)
        return self._client

    @staticmethod
    def _truncate_text_by_tokens(text: str, max_input_tokens: int | None) -> str:
        if not max_input_tokens or max_input_tokens <= 0:
            return text
        max_chars = max_input_tokens * 4
        return text[:max_chars] if len(text) > max_chars else text

    async def classify_modules(
        self,
        text: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        *,
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        start = time.perf_counter()
        if not modules or not allowed_module_names:
            return ClassifierBatchResult(outcomes=[], latency_ms=0.0, provider=self.name)

        module_instructions = "\n\n".join(m.system_prompt() for m in modules)
        allowed_list = ", ".join(f'"{n}"' for n in sorted(allowed_module_names))
        module_instructions = f"""{module_instructions}

Configured module names (emit one module_results entry per name): [{allowed_list}]"""
        if extra_system_suffix.strip():
            module_instructions = f"{module_instructions}\n\n{extra_system_suffix.strip()}"

        system = EVAL_SYSTEM_PROMPT.format(module_instructions=module_instructions)
        text = self._truncate_text_by_tokens(text, self._max_input_tokens)

        client = self._ensure_client()
        schema = build_module_results_openai_schema(allowed_module_names)

        try:

            def _call() -> object:
                cfg = types.GenerateContentConfig(
                    temperature=0,
                    response_mime_type="application/json",
                    response_json_schema=schema,
                    system_instruction=system,
                )
                return client.models.generate_content(model=self._model, contents=text, config=cfg)

            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call)
            else:
                response = await anyio.to_thread.run_sync(_call)
        except TimeoutError as exc:
            raise ProviderUnavailableError(f"gemini timeout: {exc}") from exc
        except Exception as exc:
            raise ProviderUnavailableError(f"gemini error: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000

        try:
            payload = json.loads(getattr(response, "text", "") or "")
        except Exception as exc:
            raise ProviderUnavailableError(f"gemini invalid JSON response: {exc}") from exc

        raw = payload.get("module_results") if isinstance(payload, dict) else None
        if not isinstance(raw, list):
            raise ProviderUnavailableError("gemini missing module_results")
        rows = [r for r in raw if isinstance(r, dict)]
        outcomes = normalize_module_outcomes(rows, allowed_module_names)
        redacted_text = payload.get("redacted_text") if isinstance(payload, dict) else None
        return ClassifierBatchResult(
            outcomes=outcomes,
            latency_ms=latency_ms,
            provider=self.name,
            redacted_text=str(redacted_text) if isinstance(redacted_text, str) else None,
        )

    async def classify_modules_multimodal(
        self,
        *,
        text: str,
        images: list[bytes],
        image_format: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        start = time.perf_counter()
        if not modules or not allowed_module_names:
            return ClassifierBatchResult(outcomes=[], latency_ms=0.0, provider=self.name)

        module_instructions = "\n\n".join(m.system_prompt() for m in modules)
        allowed_list = ", ".join(f'"{n}"' for n in sorted(allowed_module_names))
        module_instructions = f"""{module_instructions}

Configured module names (emit one module_results entry per name): [{allowed_list}]"""
        if extra_system_suffix.strip():
            module_instructions = f"{module_instructions}\n\n{extra_system_suffix.strip()}"

        system = EVAL_SYSTEM_PROMPT.format(module_instructions=module_instructions)

        text = self._truncate_text_by_tokens(text, self._max_input_tokens)
        client = self._ensure_client()
        schema = build_module_results_openai_schema(allowed_module_names)

        fmt = (image_format or "auto").strip().lower()
        if fmt == "auto":
            fmt = "png"
        mime = f"image/{fmt}"

        parts: list[Any] = [types.Part.from_text(text)]
        for b in images:
            parts.append(types.Part.from_bytes(data=b, mime_type=mime))

        try:

            def _call() -> object:
                cfg = types.GenerateContentConfig(
                    temperature=0,
                    response_mime_type="application/json",
                    response_json_schema=schema,
                    system_instruction=system,
                )
                return client.models.generate_content(model=self._model, contents=parts, config=cfg)

            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call)
            else:
                response = await anyio.to_thread.run_sync(_call)
        except TimeoutError as exc:
            raise ProviderUnavailableError(f"gemini timeout: {exc}") from exc
        except Exception as exc:
            raise ProviderUnavailableError(f"gemini error: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000

        try:
            payload = json.loads(getattr(response, "text", "") or "")
        except Exception as exc:
            raise ProviderUnavailableError(f"gemini invalid JSON response: {exc}") from exc

        raw = payload.get("module_results") if isinstance(payload, dict) else None
        if not isinstance(raw, list):
            raise ProviderUnavailableError("gemini missing module_results")
        rows = [r for r in raw if isinstance(r, dict)]
        outcomes = normalize_module_outcomes(rows, allowed_module_names)
        redacted_text = payload.get("redacted_text") if isinstance(payload, dict) else None
        return ClassifierBatchResult(
            outcomes=outcomes,
            latency_ms=latency_ms,
            provider=self.name,
            redacted_text=str(redacted_text) if isinstance(redacted_text, str) else None,
        )

    async def classify_simple_json(self, user_text: str, *, timeout: float | None = None) -> dict[str, Any]:
        schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "flagged": {"type": "boolean"},
                "confidence": {"type": "number"},
                "reason": {"type": "string"},
            },
            "required": ["flagged", "confidence", "reason"],
        }
        client = self._ensure_client()

        try:

            def _call() -> object:
                cfg = types.GenerateContentConfig(
                    temperature=0,
                    response_mime_type="application/json",
                    response_json_schema=schema,
                    system_instruction="Respond with valid JSON only.",
                )
                return client.models.generate_content(model=self._model, contents=user_text, config=cfg)

            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call)
            else:
                response = await anyio.to_thread.run_sync(_call)
        except Exception as exc:
            raise ProviderUnavailableError(f"gemini classify_simple_json: {exc}") from exc

        try:
            payload = json.loads(getattr(response, "text", "") or "")
        except Exception:
            return {"flagged": False, "confidence": 0.0, "reason": "no JSON output"}
        if isinstance(payload, dict):
            return payload
        return {"flagged": False, "confidence": 0.0, "reason": "invalid JSON output"}

