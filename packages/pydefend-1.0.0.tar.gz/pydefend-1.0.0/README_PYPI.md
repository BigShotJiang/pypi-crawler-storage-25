# pydefend

AI security guardrails for LLM applications — scan inputs and check outputs with Claude, OpenAI, Gemini, Azure, or Ollama.

For the full project README, docs, and examples, see:

- **GitHub repo**: https://github.com/Adxzer/defend
- **Docs**: https://www.pydefend.com/docs

## Install

```bash
pip install pydefend
```

Optional provider extras:

```bash
pip install "pydefend[openai]"      # OpenAI SDK integration
pip install "pydefend[anthropic]"   # Anthropic SDK integration
pip install "pydefend[gemini]"      # Gemini (google-genai) SDK integration
pip install "pydefend[fastapi]"     # FastAPI middleware/integration helpers
pip install "pydefend[langchain]"   # LangChain integration helpers
pip install "pydefend[all]"         # All optional integrations
```

## Quick start

```python
import asyncio
from pydefend import Defend

defend = Defend.default()

async def main():
    scanned = await defend.scan("User message here")
    if not scanned:
        return "Can't help with that."

    # ... call your LLM with scanned.text ...

    checked = await defend.check("Model reply here")
    return checked.text if checked else None

print(asyncio.run(main()))
```

## Configuration

- **Code-first**: use `Defend.default()` or the builder API to choose modules.
- **Config file**: drop a `defend.yaml` into your repo and load it with `Defend.from_yaml("defend.yaml")`.

## Links

- **Repository / issues**: https://github.com/Adxzer/defend
- **Documentation**: https://www.pydefend.com/docs

## License

Apache-2.0 — see `LICENSE` in the GitHub repo.