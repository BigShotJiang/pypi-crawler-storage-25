"""GDB REST API client."""

from mcp_eregistrations_gdb.gdb_client.client import GDBClient
from mcp_eregistrations_gdb.gdb_client.errors import (
    GDBAuthError,
    GDBClientError,
    GDBNotFoundError,
    GDBServerError,
    GDBValidationError,
    translate_error,
)

__all__ = [
    "GDBClient",
    "GDBAuthError",
    "GDBClientError",
    "GDBNotFoundError",
    "GDBServerError",
    "GDBValidationError",
    "translate_error",
]
