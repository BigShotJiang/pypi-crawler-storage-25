"""GDB tools package — shared helpers."""

from __future__ import annotations

from typing import Any


def _add_optional(body: dict[str, Any], key: str, value: Any) -> None:
    """Add a key to the body dict only if the value is not None."""
    if value is not None:
        body[key] = value
