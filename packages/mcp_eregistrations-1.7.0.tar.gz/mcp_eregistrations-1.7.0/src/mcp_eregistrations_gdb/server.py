"""GDB MCP Server entry point."""

from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-gdb",
    instructions=(
        "GDB (Generic Database Builder) tools for managing databases, schemas, "
        "and records in eRegistrations. Use gdb_catalog_list to discover available "
        "databases, then gdb_database_get for schema details.\n\n"
        "AUTHENTICATION: If a tool returns an auth error, call gdb_auth_login "
        "with the user's credentials. Credentials are stored for silent auto-login "
        "on future sessions. Shared across all eRegistrations MCP servers."
    ),
)

import mcp_eregistrations_gdb.tools.catalogs  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.data  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.data_views  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.databases  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.groups  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.services  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.system  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.translations  # noqa: F401, E402
from mcp_eregistrations_common.tools.instances import (  # noqa: E402
    register_instance_tools,
)

register_instance_tools(mcp)


def main() -> None:
    mcp.run()
