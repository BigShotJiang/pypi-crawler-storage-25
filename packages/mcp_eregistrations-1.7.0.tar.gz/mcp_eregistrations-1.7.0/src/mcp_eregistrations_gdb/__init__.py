"""GDB MCP Server — Generic Database Builder tools for eRegistrations."""
