"""DS MCP Server — admin/ops monitoring for eRegistrations Display System."""

from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-ds",
    instructions=(
        "DS (Display System) tools for monitoring and managing application files, "
        "payments, workflows, documents, and system health. "
        "Read tools for monitoring, write tools for file lifecycle "
        "(create, fill, submit, process, pay, cleanup). "
        "Use ds_auth_login to authenticate first."
    ),
)


import mcp_eregistrations_ds.tools.documents  # noqa: F401, E402
import mcp_eregistrations_ds.tools.file_lifecycle  # noqa: F401, E402
import mcp_eregistrations_ds.tools.files  # noqa: F401, E402
import mcp_eregistrations_ds.tools.financial_reports  # noqa: F401, E402
import mcp_eregistrations_ds.tools.messages  # noqa: F401, E402
import mcp_eregistrations_ds.tools.payments  # noqa: F401, E402
import mcp_eregistrations_ds.tools.processes  # noqa: F401, E402
import mcp_eregistrations_ds.tools.services  # noqa: F401, E402
import mcp_eregistrations_ds.tools.system  # noqa: F401, E402
import mcp_eregistrations_ds.tools.users  # noqa: F401, E402
from mcp_eregistrations_common.tools.instances import (  # noqa: E402
    register_instance_tools,
)

register_instance_tools(mcp)


def main() -> None:
    """Entry point for mcp-eregistrations-ds."""
    mcp.run()


if __name__ == "__main__":
    main()
