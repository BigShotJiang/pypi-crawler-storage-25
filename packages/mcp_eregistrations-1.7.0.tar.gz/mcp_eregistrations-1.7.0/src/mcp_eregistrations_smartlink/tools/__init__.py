"""SmartLink MCP tools."""
