"""SmartLink REST API client."""

from mcp_eregistrations_smartlink.smartlink_client.client import SmartLinkClient
from mcp_eregistrations_smartlink.smartlink_client.errors import (
    SmartLinkAuthError,
    SmartLinkClientError,
    SmartLinkForbiddenError,
    SmartLinkNotFoundError,
    SmartLinkServerError,
    SmartLinkValidationError,
    translate_error,
)

__all__ = [
    "SmartLinkClient",
    "SmartLinkAuthError",
    "SmartLinkClientError",
    "SmartLinkForbiddenError",
    "SmartLinkNotFoundError",
    "SmartLinkServerError",
    "SmartLinkValidationError",
    "translate_error",
]
