"""SmartLink MCP audit database."""
