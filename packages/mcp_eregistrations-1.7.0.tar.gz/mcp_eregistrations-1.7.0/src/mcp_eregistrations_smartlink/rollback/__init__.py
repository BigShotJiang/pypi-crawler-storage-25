"""SmartLink MCP rollback capability."""
