"""SmartLink MCP Server — debugging tools for eRegistrations integration flows."""
