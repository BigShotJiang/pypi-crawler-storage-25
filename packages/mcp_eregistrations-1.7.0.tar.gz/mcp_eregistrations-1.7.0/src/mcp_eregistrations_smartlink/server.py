from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-smartlink",
    instructions=(
        "SmartLink debugging tools for eRegistrations integration flows. "
        "Start with smartlink_audit_get to inspect a failing request, then use "
        "smartlink_flow_get / smartlink_action_get to understand the configuration. "
        "Use smartlink_flow_update / smartlink_action_update to fix broken config.\n\n"
        "AUTHENTICATION: If a tool returns an auth error, call smartlink_auth_login "
        "with the user's credentials. Credentials are shared across all eRegistrations "
        "MCP servers.\n\n"
        "NOTE: The authenticated user must have the sysadmin role to access audit data."
    ),
)

import mcp_eregistrations_smartlink.tools.actions  # noqa: F401, E402
import mcp_eregistrations_smartlink.tools.audits  # noqa: F401, E402
import mcp_eregistrations_smartlink.tools.flows  # noqa: F401, E402
import mcp_eregistrations_smartlink.tools.instances  # noqa: F401, E402
import mcp_eregistrations_smartlink.tools.system  # noqa: F401, E402


def main() -> None:
    """Entry point for mcp-eregistrations-smartlink."""
    mcp.run()
