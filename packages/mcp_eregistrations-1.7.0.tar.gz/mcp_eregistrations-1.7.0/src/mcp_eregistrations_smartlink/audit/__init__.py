"""SmartLink MCP audit logging."""
