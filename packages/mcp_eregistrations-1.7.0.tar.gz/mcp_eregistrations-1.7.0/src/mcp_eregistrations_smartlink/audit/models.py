from enum import StrEnum


class SlObjectType(StrEnum):
    FLOW = "flow"
    ACTION = "action"
