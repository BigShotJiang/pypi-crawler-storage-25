"""Shared code for MCP eRegistrations components (BPA, DS, GDB)."""
