"""Shared MCP tools registered by all eRegistrations servers."""
