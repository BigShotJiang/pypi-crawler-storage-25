"""CLI entry point for mcp-eregistrations."""

from mcp_eregistrations_bpa import main

if __name__ == "__main__":
    main()
