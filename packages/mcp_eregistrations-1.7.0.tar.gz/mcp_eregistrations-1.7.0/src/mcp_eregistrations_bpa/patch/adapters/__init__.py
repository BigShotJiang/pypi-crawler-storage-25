"""Form adapters for fetching and saving Form.io component trees."""

from mcp_eregistrations_bpa.patch.adapters.base import FormAdapter
from mcp_eregistrations_bpa.patch.adapters.print_document import PrintDocumentAdapter
from mcp_eregistrations_bpa.patch.adapters.role_form import RoleFormAdapter
from mcp_eregistrations_bpa.patch.adapters.service_form import ServiceFormAdapter

__all__ = [
    "FormAdapter",
    "PrintDocumentAdapter",
    "RoleFormAdapter",
    "ServiceFormAdapter",
]
