"""PrintDocumentAdapter — fetch/save Form.io trees from BPA print documents."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

from mcp_eregistrations_bpa.patch.adapters.base import FormAdapter


class PrintDocumentAdapter(FormAdapter):
    """Adapter for print document / certificate forms.

    Endpoints use ``/print-documents/{document_id}`` for both GET and PUT
    (unlike roles, the ID IS in the URL).
    """

    def __init__(self, client: Any) -> None:
        self._client = client
        self._envelope: dict[str, Any] | None = None
        self._target_id: str | None = None

    @property
    def envelope(self) -> dict[str, Any] | None:
        """Full print document object stored after fetch(), used for round-trip save."""
        return self._envelope

    @property
    def label(self) -> str:
        if self._envelope is None:
            return "Print Document (unfetched)"
        name = self._envelope.get("name")
        if name:
            return f'Print Document "{name}"'
        return f"Print Document {self._target_id}"

    async def fetch(self, target_id: str) -> list[dict[str, Any]]:
        """Fetch print document form components via GET /print-documents/{document_id}.

        Handles formSchema returned as either a dict or a JSON string.

        Args:
            target_id: The print document ID.

        Returns:
            List of Form.io components from the document's formSchema.
        """
        self._target_id = target_id
        data = await self._client.get(
            "/print-documents/{document_id}",
            path_params={"document_id": target_id},
            resource_type="print_document",
            resource_id=target_id,
        )
        self._envelope = deepcopy(data)

        form_schema = data.get("formSchema")
        if form_schema is None:
            return []

        # BPA sometimes returns formSchema as a JSON string
        if isinstance(form_schema, str):
            form_schema = json.loads(form_schema)

        if not isinstance(form_schema, dict):
            return []

        components: list[dict[str, Any]] = form_schema.get("components", [])
        return components

    async def save(self, components: list[dict[str, Any]]) -> None:
        """Save modified components back via PUT /print-documents/{document_id}.

        Re-embeds the components into the stored envelope and PUTs
        the full print document object.  Unlike roles, the document ID
        IS in the URL.

        Args:
            components: Modified Form.io component list.

        Raises:
            RuntimeError: If fetch() was not called first.
        """
        if self._envelope is None:
            raise RuntimeError(
                "Must call fetch() before save() — the adapter needs the "
                "print document envelope for a round-trip PUT."
            )

        payload = deepcopy(self._envelope)

        # Ensure formSchema is a dict (it may have been stored as string)
        form_schema = payload.get("formSchema")
        if isinstance(form_schema, str):
            form_schema = json.loads(form_schema)
        if form_schema is None:
            form_schema = {}

        form_schema["components"] = components
        payload["formSchema"] = form_schema

        await self._client.put(
            "/print-documents/{document_id}",
            path_params={"document_id": self._target_id},
            json=payload,
            resource_type="print_document",
            resource_id=self._target_id,
        )
