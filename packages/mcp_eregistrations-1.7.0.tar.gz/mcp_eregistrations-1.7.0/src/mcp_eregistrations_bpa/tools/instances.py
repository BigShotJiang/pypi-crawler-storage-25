"""BPA instance tools — now provided by mcp_eregistrations_common.

This module re-exports the shared implementation for backwards compatibility.
"""

from mcp_eregistrations_common.tools.instances import (  # noqa: F401
    instance_add,
    instance_list,
    instance_remove,
    register_instance_tools,
)

__all__ = [
    "instance_list",
    "instance_add",
    "instance_remove",
    "register_instance_tools",
]
