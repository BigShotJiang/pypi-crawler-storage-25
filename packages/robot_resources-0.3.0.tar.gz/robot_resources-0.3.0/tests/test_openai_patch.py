"""
Tests for robot_resources._autoattach.openai_patch.

Mirrors the anthropic patch test surface — same gating, idempotency, and
prompt-extraction guarantees.
"""

from __future__ import annotations

import sys
import types

import pytest


@pytest.fixture
def fake_openai(monkeypatch):
    openai = types.ModuleType("openai")
    resources = types.ModuleType("openai.resources")
    chat = types.ModuleType("openai.resources.chat")
    completions_mod = types.ModuleType("openai.resources.chat.completions")

    class FakeCompletions:
        def create(self, *args, **kwargs):
            return {"echo": kwargs}

    class FakeAsyncCompletions:
        async def create(self, *args, **kwargs):
            return {"echo": kwargs}

    completions_mod.Completions = FakeCompletions  # type: ignore[attr-defined]
    completions_mod.AsyncCompletions = FakeAsyncCompletions  # type: ignore[attr-defined]
    chat.completions = completions_mod  # type: ignore[attr-defined]
    resources.chat = chat  # type: ignore[attr-defined]
    openai.resources = resources  # type: ignore[attr-defined]

    sys.modules["openai"] = openai
    sys.modules["openai.resources"] = resources
    sys.modules["openai.resources.chat"] = chat
    sys.modules["openai.resources.chat.completions"] = completions_mod

    yield completions_mod

    for k in [
        "openai.resources.chat.completions",
        "openai.resources.chat",
        "openai.resources",
        "openai",
    ]:
        sys.modules.pop(k, None)

    # Drop cached patch module so attach() re-runs on next test
    sys.modules.pop("robot_resources._autoattach.openai_patch", None)


def test_attach_returns_false_when_openai_missing(monkeypatch):
    for k in list(sys.modules):
        if k == "openai" or k.startswith("openai."):
            sys.modules.pop(k, None)

    monkeypatch.setattr("builtins.__import__", _block_openai_import(__import__))
    sys.modules.pop("robot_resources._autoattach.openai_patch", None)
    from robot_resources._autoattach.openai_patch import attach

    assert attach() is False


def _block_openai_import(real):
    def _import(name, *args, **kwargs):
        if name == "openai" or name.startswith("openai."):
            raise ImportError(f"simulated: {name}")
        return real(name, *args, **kwargs)
    return _import


def test_attach_patches_completions_create_when_sdk_present(fake_openai, monkeypatch):
    monkeypatch.delenv("RR_API_KEY", raising=False)
    from robot_resources._autoattach.openai_patch import attach

    Completions = fake_openai.Completions
    original_create = Completions.create

    assert attach() is True
    assert Completions.create is not original_create
    assert getattr(Completions, "_rr_autoattach_patched", False) is True


def test_attach_is_idempotent(fake_openai):
    from robot_resources._autoattach.openai_patch import attach

    assert attach() is True
    Completions = fake_openai.Completions
    create_after_first = Completions.create
    assert attach() is True
    assert Completions.create is create_after_first


def test_extract_prompt_handles_string_content():
    from robot_resources._autoattach.openai_patch import _extract_prompt

    msgs = [{"role": "user", "content": "hello world"}]
    assert _extract_prompt(msgs) == "hello world"


def test_extract_prompt_returns_last_user_message():
    from robot_resources._autoattach.openai_patch import _extract_prompt

    msgs = [
        {"role": "system", "content": "you are helpful"},
        {"role": "user", "content": "old"},
        {"role": "assistant", "content": "ok"},
        {"role": "user", "content": "newest"},
    ]
    assert _extract_prompt(msgs) == "newest"
