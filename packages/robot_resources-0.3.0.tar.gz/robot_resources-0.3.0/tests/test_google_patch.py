"""
Tests for robot_resources._autoattach.google_patch.

Same gating + idempotency surface as anthropic + openai. Google's `contents`
shape is more varied (string, list-of-strings, list-of-dicts), so we have
more `_extract_prompt` cases.
"""

from __future__ import annotations

import sys
import types

import pytest


@pytest.fixture
def fake_google(monkeypatch):
    google = types.ModuleType("google")
    genai = types.ModuleType("google.generativeai")

    class FakeGenerativeModel:
        def __init__(self, model_name="models/gemini-1.5-flash"):
            self.model_name = model_name

        def generate_content(self, contents, *args, **kwargs):
            return {"echo_model": self.model_name, "echo_contents": contents}

        async def generate_content_async(self, contents, *args, **kwargs):
            return {"echo_model": self.model_name, "echo_contents": contents}

    genai.GenerativeModel = FakeGenerativeModel  # type: ignore[attr-defined]
    google.generativeai = genai  # type: ignore[attr-defined]

    sys.modules["google"] = google
    sys.modules["google.generativeai"] = genai

    yield genai

    sys.modules.pop("google.generativeai", None)
    sys.modules.pop("google", None)
    sys.modules.pop("robot_resources._autoattach.google_patch", None)


def test_attach_returns_false_when_google_missing(monkeypatch):
    for k in list(sys.modules):
        if k == "google" or k.startswith("google."):
            sys.modules.pop(k, None)

    monkeypatch.setattr("builtins.__import__", _block_google_import(__import__))
    sys.modules.pop("robot_resources._autoattach.google_patch", None)
    from robot_resources._autoattach.google_patch import attach

    assert attach() is False


def _block_google_import(real):
    def _import(name, *args, **kwargs):
        if name == "google" or name.startswith("google."):
            raise ImportError(f"simulated: {name}")
        return real(name, *args, **kwargs)
    return _import


def test_attach_patches_generate_content_when_sdk_present(fake_google):
    from robot_resources._autoattach.google_patch import attach

    GenerativeModel = fake_google.GenerativeModel
    original = GenerativeModel.generate_content

    assert attach() is True
    assert GenerativeModel.generate_content is not original
    assert getattr(GenerativeModel, "_rr_autoattach_patched", False) is True


def test_attach_is_idempotent(fake_google):
    from robot_resources._autoattach.google_patch import attach

    assert attach() is True
    GenerativeModel = fake_google.GenerativeModel
    after_first = GenerativeModel.generate_content
    assert attach() is True
    assert GenerativeModel.generate_content is after_first


def test_extract_prompt_handles_plain_string():
    from robot_resources._autoattach.google_patch import _extract_prompt

    assert _extract_prompt("Tell me a joke") == "Tell me a joke"


def test_extract_prompt_handles_list_of_strings():
    from robot_resources._autoattach.google_patch import _extract_prompt

    assert _extract_prompt(["first", "second"]) == "second"


def test_extract_prompt_handles_role_parts_dicts():
    from robot_resources._autoattach.google_patch import _extract_prompt

    contents = [
        {"role": "user", "parts": ["please summarize"]},
    ]
    assert _extract_prompt(contents) == "please summarize"


def test_extract_prompt_handles_dict_with_text_blocks():
    from robot_resources._autoattach.google_patch import _extract_prompt

    contents = [
        {"role": "user", "parts": [{"text": "alpha"}, {"text": "beta"}]},
    ]
    assert _extract_prompt(contents) == "alpha\nbeta"


def test_extract_prompt_returns_none_for_assistant_only():
    from robot_resources._autoattach.google_patch import _extract_prompt

    assert _extract_prompt([{"role": "model", "parts": ["hi"]}]) is None


def test_extract_prompt_returns_none_for_empty():
    from robot_resources._autoattach.google_patch import _extract_prompt

    assert _extract_prompt(None) is None
    assert _extract_prompt([]) is None
    assert _extract_prompt("") is None
