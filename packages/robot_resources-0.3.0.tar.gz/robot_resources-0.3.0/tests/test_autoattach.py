"""
Tests for robot_resources._autoattach.

Phase 2 ships the gating + monkey-patching pieces. These tests cover the
public surface; the live end-to-end (real Python interpreter loading the
.pth file in a fresh venv) lives in Phase 3's wizard fixture matrix.
"""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest


@pytest.fixture
def reset_autoattach_state(monkeypatch):
    """Each test starts from a clean autoattach singleton + clean module cache.

    The package writes a flag onto ``sys`` to enforce single-load; tests must
    clear it so successive tests can re-exercise the import path.
    """
    monkeypatch.delattr(sys, "__rr_autoattach_loaded__", raising=False)

    # Drop any cached autoattach modules so importing again re-runs the gate.
    to_drop = [
        name
        for name in list(sys.modules)
        if name == "robot_resources._autoattach"
        or name.startswith("robot_resources._autoattach.")
    ]
    for name in to_drop:
        sys.modules.pop(name, None)

    yield

    monkeypatch.delattr(sys, "__rr_autoattach_loaded__", raising=False)


# --------------------------------------------------------------------------
# Gating
# --------------------------------------------------------------------------


def test_skips_attach_when_RR_AUTOATTACH_unset(monkeypatch, reset_autoattach_state):
    monkeypatch.delenv("RR_AUTOATTACH", raising=False)
    monkeypatch.setenv("RR_AUTOATTACH_DRY_RUN", "1")

    import robot_resources._autoattach  # noqa: F401

    # Singleton flag should NOT be set — the entire body short-circuited.
    assert not getattr(sys, "__rr_autoattach_loaded__", False)


def test_skips_attach_when_RR_AUTOATTACH_zero(monkeypatch, reset_autoattach_state):
    monkeypatch.setenv("RR_AUTOATTACH", "0")
    monkeypatch.setenv("RR_AUTOATTACH_DRY_RUN", "1")

    import robot_resources._autoattach  # noqa: F401

    assert not getattr(sys, "__rr_autoattach_loaded__", False)


def test_dry_run_sets_singleton_but_skips_actual_patch(monkeypatch, reset_autoattach_state):
    monkeypatch.setenv("RR_AUTOATTACH", "1")
    monkeypatch.setenv("RR_AUTOATTACH_DRY_RUN", "1")

    import robot_resources._autoattach  # noqa: F401

    assert getattr(sys, "__rr_autoattach_loaded__", False) is True


# --------------------------------------------------------------------------
# anthropic_patch.attach() — direct (no .pth)
# --------------------------------------------------------------------------


def _install_fake_anthropic() -> types.ModuleType:
    """Stand up a minimal anthropic.resources.messages.Messages so attach()
    has something to patch without requiring the real SDK in tests.
    """
    anthropic = types.ModuleType("anthropic")
    resources = types.ModuleType("anthropic.resources")
    messages_mod = types.ModuleType("anthropic.resources.messages")

    class FakeMessages:
        def create(self, *args, **kwargs):
            return {"echo": kwargs}

    class FakeAsyncMessages:
        async def create(self, *args, **kwargs):
            return {"echo": kwargs}

    messages_mod.Messages = FakeMessages  # type: ignore[attr-defined]
    messages_mod.AsyncMessages = FakeAsyncMessages  # type: ignore[attr-defined]
    resources.messages = messages_mod  # type: ignore[attr-defined]
    anthropic.resources = resources  # type: ignore[attr-defined]

    sys.modules["anthropic"] = anthropic
    sys.modules["anthropic.resources"] = resources
    sys.modules["anthropic.resources.messages"] = messages_mod
    return messages_mod


@pytest.fixture
def fake_anthropic(monkeypatch):
    mod = _install_fake_anthropic()
    yield mod
    for k in [
        "anthropic.resources.messages",
        "anthropic.resources",
        "anthropic",
    ]:
        sys.modules.pop(k, None)


def test_attach_returns_false_when_anthropic_missing(monkeypatch):
    # Make sure no fake or real anthropic is in sys.modules
    for k in list(sys.modules):
        if k == "anthropic" or k.startswith("anthropic."):
            sys.modules.pop(k, None)
    # Block import resolution
    monkeypatch.setattr("builtins.__import__", _block_anthropic_import(__import__))

    from robot_resources._autoattach.anthropic_patch import attach

    assert attach() is False


def _block_anthropic_import(real):
    def _import(name, *args, **kwargs):
        if name == "anthropic" or name.startswith("anthropic."):
            raise ImportError(f"simulated: {name}")
        return real(name, *args, **kwargs)
    return _import


def test_attach_patches_messages_create_when_sdk_present(fake_anthropic, monkeypatch):
    monkeypatch.delenv("RR_API_KEY", raising=False)
    # No api_key -> RouterClient construction returns None -> patcher still
    # patches but routes-through a no-op (kwargs unchanged). That covers
    # most of what we want to verify here: the method got replaced.
    from robot_resources._autoattach.anthropic_patch import attach

    Messages = fake_anthropic.Messages
    original_create = Messages.create

    assert attach() is True
    assert Messages.create is not original_create
    assert getattr(Messages, "_rr_autoattach_patched", False) is True


def test_attach_is_idempotent(fake_anthropic):
    from robot_resources._autoattach.anthropic_patch import attach

    assert attach() is True
    Messages = fake_anthropic.Messages
    create_after_first = Messages.create
    assert attach() is True
    # Second call must not re-wrap; reference must be stable.
    assert Messages.create is create_after_first


def test_extract_prompt_handles_string_content():
    from robot_resources._autoattach.anthropic_patch import _extract_prompt

    msgs = [{"role": "user", "content": "hello world"}]
    assert _extract_prompt(msgs) == "hello world"


def test_extract_prompt_handles_structured_content():
    from robot_resources._autoattach.anthropic_patch import _extract_prompt

    msgs = [
        {"role": "user", "content": [{"type": "text", "text": "first"}, {"type": "text", "text": "second"}]},
    ]
    assert _extract_prompt(msgs) == "first\nsecond"


def test_extract_prompt_returns_last_user_message_only():
    from robot_resources._autoattach.anthropic_patch import _extract_prompt

    msgs = [
        {"role": "user", "content": "old"},
        {"role": "assistant", "content": "between"},
        {"role": "user", "content": "newest"},
    ]
    assert _extract_prompt(msgs) == "newest"


def test_extract_prompt_returns_none_for_empty_messages():
    from robot_resources._autoattach.anthropic_patch import _extract_prompt

    assert _extract_prompt([]) is None
    assert _extract_prompt(None) is None


def test_extract_prompt_returns_none_for_assistant_only():
    from robot_resources._autoattach.anthropic_patch import _extract_prompt

    assert _extract_prompt([{"role": "assistant", "content": "hi"}]) is None
