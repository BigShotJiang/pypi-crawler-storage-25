# robot-resources

Python SDK for [Robot Resources](https://robotresources.ai) — smart model selection for AI agents.

## Install

```bash
pip install robot-resources
```

## Quick start

```python
from robot_resources.router import route

decision = route("write a python function that reverses a string")
print(decision["selected_model"])   # e.g. 'claude-haiku-4-5'
print(decision["savings_percent"])  # e.g. 68.0
```

## Filter by what providers you have keys for

```python
decision = route(
    "summarize this article",
    available_providers=["anthropic", "openai"],
)
```

Or pass an explicit allowlist of model names:

```python
decision = route(
    "what is the capital of France",
    available_models=["claude-haiku-4-5", "gpt-5.4-mini"],
)
```

## Reusing the client across many calls

For agents that route many prompts in a single process (LangChain, LlamaIndex, CrewAI), instantiate `RouterClient` once and reuse it — connection pooling cuts per-call latency by ~3x.

```python
from robot_resources.router import RouterClient

with RouterClient() as client:
    for prompt in prompts:
        decision = client.route(prompt)
        # ... call your LLM provider with decision['selected_model']
```

## Authentication

Set `RR_API_KEY` in your environment, or pass `api_key=...` per call.

```bash
export RR_API_KEY=rr_live_yourkey...
```

Don't have a key? Run `npx robot-resources` to get one provisioned anonymously.

## Errors

The client raises typed exceptions:

- `AuthenticationError` — bad or missing API key (HTTP 401)
- `RateLimitError` — too many requests for this API key (HTTP 429)
- `ServerError` — platform 5xx after retries exhausted
- `RouterError` — base class for any other platform error

Network errors retry with exponential backoff (3 attempts: 0.5s, 1s, 2s).

## Override the endpoint

```python
decision = route("hello", endpoint="http://localhost:8787/v1/route")
# or via env var: RR_PLATFORM_URL=https://staging.robotresources.ai
```

## Future tools

This package is the umbrella SDK for Robot Resources. Today it exposes routing under `robot_resources.router`. As we expose more tools via HTTP API, they'll land as additional submodules under the same package — `pip install robot-resources` covers them all.

## About the package name

The PyPI name `robot-resources-router` was used 2026-04-26 as a redirect stub when the legacy Python daemon was deprecated. **This SDK is a different package: `robot-resources`** (singular). If you previously had `robot-resources-router` pinned, leave that pin alone — it's deprecated and won't change.

## License

MIT
