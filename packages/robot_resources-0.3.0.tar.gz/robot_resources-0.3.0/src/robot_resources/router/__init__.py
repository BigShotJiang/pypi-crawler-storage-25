"""
robot_resources.router — Python client for the public POST /v1/route endpoint.

Thin httpx wrapper. Lets non-OC Python agents (LangChain, LlamaIndex, CrewAI,
Mastra-via-py, etc.) get routing decisions without bundling routing logic
locally. The classifier runs server-side; this client is just transport.

Usage:

    from robot_resources.router import route

    decision = route("write a python function that reverses a string")
    print(decision["selected_model"])  # e.g. 'claude-haiku-4-5'

    # Filter by what providers/models the caller has API keys for:
    decision = route(
        "summarize this article",
        available_providers=["anthropic", "openai"],
    )

    # Override the platform endpoint (CI / staging / self-hosted):
    decision = route("hello", endpoint="http://localhost:8787/v1/route")

Environment variables:
  RR_PLATFORM_URL  — override the default https://api.robotresources.ai
  RR_API_KEY       — bearer token used in the Authorization header
"""

from __future__ import annotations

import os
import time
from typing import Any

import httpx

DEFAULT_ENDPOINT = "https://api.robotresources.ai/v1/route"
DEFAULT_TIMEOUT = 10.0  # seconds
RETRY_STATUS = {500, 502, 503, 504}
RETRY_BACKOFF_S = (0.5, 1.0, 2.0)  # 3 attempts total


class RouterError(Exception):
    """Base error for the robot_resources.router client."""


class AuthenticationError(RouterError):
    """Raised when the platform returns 401 (missing/invalid api_key)."""


class RateLimitError(RouterError):
    """Raised when the platform returns 429 (rate limited)."""


class ServerError(RouterError):
    """Raised when retries are exhausted on a 5xx response."""


class RouterClient:
    """Stateful client; reuses a single httpx connection pool across calls.

    Prefer this when making many routing decisions in a single process
    (LangChain, LlamaIndex, etc.) — connection reuse keeps per-call latency
    in the 30-50 ms range vs ~150 ms for a fresh httpx call each time.
    """

    def __init__(
        self,
        api_key: str | None = None,
        endpoint: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key or os.environ.get("RR_API_KEY")
        self.endpoint = endpoint or os.environ.get("RR_PLATFORM_URL") or DEFAULT_ENDPOINT
        if self.endpoint.endswith("/"):
            self.endpoint = self.endpoint.rstrip("/")
        if not self.endpoint.endswith("/v1/route") and "/v1/route" not in self.endpoint:
            self.endpoint = self.endpoint + "/v1/route"
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "RouterClient":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def route(
        self,
        prompt: str,
        available_providers: list[str] | None = None,
        available_models: list[str] | None = None,
    ) -> dict[str, Any]:
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("prompt must be a non-empty string")

        body: dict[str, Any] = {"prompt": prompt}
        if available_providers:
            body["available_providers"] = list(available_providers)
        if available_models:
            body["available_models"] = list(available_models)

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        last_exc: Exception | None = None
        for attempt, backoff in enumerate((*RETRY_BACKOFF_S, None)):
            try:
                resp = self._client.post(self.endpoint, json=body, headers=headers)
            except httpx.HTTPError as exc:
                last_exc = exc
                if backoff is None:
                    raise RouterError(f"Request failed after retries: {exc}") from exc
                time.sleep(backoff)
                continue

            if resp.status_code == 401:
                raise AuthenticationError("Platform returned 401 — check your RR_API_KEY")
            if resp.status_code == 429:
                raise RateLimitError("Platform returned 429 — rate limit exceeded for this api_key")
            if resp.status_code in RETRY_STATUS:
                last_exc = ServerError(f"Platform returned {resp.status_code}")
                if backoff is None:
                    raise last_exc
                time.sleep(backoff)
                continue
            if resp.status_code >= 400:
                raise RouterError(f"Platform returned {resp.status_code}: {resp.text}")

            payload = resp.json()
            if not payload.get("success"):
                err = payload.get("error", {})
                raise RouterError(
                    f"Platform error {err.get('code', 'UNKNOWN')}: {err.get('message', '')}"
                )
            data = payload.get("data") or {}
            return data

        raise RouterError(f"Request failed after retries: {last_exc}")


def route(
    prompt: str,
    available_providers: list[str] | None = None,
    available_models: list[str] | None = None,
    api_key: str | None = None,
    endpoint: str | None = None,
    timeout: float = DEFAULT_TIMEOUT,
) -> dict[str, Any]:
    """Convenience wrapper — opens a short-lived RouterClient for one call.

    For repeated calls in the same process, instantiate `RouterClient` once
    and reuse it (connection pooling cuts per-call overhead by ~3x).
    """
    with RouterClient(api_key=api_key, endpoint=endpoint, timeout=timeout) as client:
        return client.route(
            prompt,
            available_providers=available_providers,
            available_models=available_models,
        )


__all__ = [
    "AuthenticationError",
    "DEFAULT_ENDPOINT",
    "RateLimitError",
    "RouterClient",
    "RouterError",
    "ServerError",
    "route",
]
