"""
Robot Resources Python SDK.

Multi-tool client for the Robot Resources platform. Today exposes routing;
future tools (e.g. scraper HTTP API) land as additional submodules under the
same package, so users only ever `pip install robot-resources` once.

Usage:

    from robot_resources.router import route
    decision = route("write a python function")
    print(decision["selected_model"])

See `robot_resources.router` for the full routing API.
"""

__version__ = "0.3.0"

__all__ = ["__version__"]
