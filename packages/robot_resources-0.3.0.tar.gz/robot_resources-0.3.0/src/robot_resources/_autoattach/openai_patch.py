"""
OpenAI SDK patcher for the auto-attach path.

Mirrors ``anthropic_patch.py``: monkey-patches the Chat Completions create
methods (sync + async) at class level. Each call extracts the user prompt,
asks ``/v1/route`` for a routing decision, swaps ``model`` in kwargs, then
forwards to the original create. The user's ``OPENAI_API_KEY`` flows
straight to api.openai.com via the SDK — we never see request bodies.

Why method-wrapping instead of env-var override (matches Anthropic Python
deviation): Python deployments commonly run in environments that block
inbound port binding (Lambda, Cloud Run, hardened containers). Pure
HTTP-out is portable; in-process listener is not.

Failure modes (all silent):
    - SDK not installed → ``attach()`` returns False.
    - No api_key in config → telemetry skipped, kwargs unchanged.
    - Platform 4xx/5xx → kwargs unchanged.
"""

from __future__ import annotations

import os
import sys
from typing import Any

from robot_resources.router import RouterClient, RouterError

_PATCHED_FLAG = "_rr_autoattach_patched"


def attach() -> bool:
    """Monkey-patch the OpenAI SDK's Chat Completions create methods.

    Returns True if patching succeeded (or was already in place), False if
    the SDK isn't installed or any unexpected error occurred during patching.
    """
    try:
        import openai  # noqa: F401
        from openai.resources.chat.completions import Completions
    except Exception:
        return False  # SDK not in env

    try:
        from openai.resources.chat.completions import AsyncCompletions
    except Exception:
        AsyncCompletions = None  # type: ignore[assignment]

    if getattr(Completions, _PATCHED_FLAG, False):
        return True  # idempotent

    original_create = Completions.create
    original_acreate = AsyncCompletions.create if AsyncCompletions else None

    _shared_client = _build_client()

    def _routed_kwargs(self: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
        # Honor user-supplied base_url override (corp proxy, dev stub, etc.)
        try:
            client_base_url = str(getattr(self._client, "base_url", "") or "")
            if client_base_url and "openai.com" not in client_base_url:
                return kwargs
        except Exception:
            pass

        prompt = _extract_prompt(kwargs.get("messages"))
        if not prompt:
            return kwargs

        if _shared_client is None:
            return kwargs

        try:
            decision = _shared_client.route(prompt, available_providers=["openai"])
            new_model = decision.get("selected_model")
            if new_model:
                kwargs = {**kwargs, "model": new_model}
        except RouterError as err:
            _maybe_log(f"route failed: {err}")
        except Exception as err:  # noqa: BLE001
            _maybe_log(f"route unexpected error: {err}")

        return kwargs

    def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
        return original_create(self, *args, **_routed_kwargs(self, kwargs))

    Completions.create = patched_create  # type: ignore[method-assign]
    setattr(Completions, _PATCHED_FLAG, True)

    if AsyncCompletions and original_acreate:
        async def patched_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
            return await original_acreate(self, *args, **_routed_kwargs(self, kwargs))

        AsyncCompletions.create = patched_acreate  # type: ignore[method-assign]
        setattr(AsyncCompletions, _PATCHED_FLAG, True)

    _emit_attach_event(sdk="openai", attached=True)
    return True


def _build_client() -> RouterClient | None:
    api_key = _read_api_key()
    if not api_key:
        return None
    try:
        return RouterClient(api_key=api_key)
    except Exception:
        return None


def _read_api_key() -> str | None:
    env_key = os.environ.get("RR_API_KEY")
    if env_key:
        return env_key
    try:
        import json
        from pathlib import Path

        cfg = Path.home() / ".robot-resources" / "config.json"
        return json.loads(cfg.read_text()).get("api_key")
    except Exception:
        return None


def _extract_prompt(messages: Any) -> str | None:
    """Pull the last user message text out of an OpenAI Chat Completions
    payload. OpenAI uses the same ``[{role, content}, ...]`` shape as
    Anthropic for our purposes, so we mirror anthropic_patch's logic.
    """
    if not messages:
        return None
    try:
        for msg in reversed(messages):
            if not isinstance(msg, dict):
                continue
            if msg.get("role") != "user":
                continue
            content = msg.get("content")
            if isinstance(content, str):
                return content if content.strip() else None
            if isinstance(content, list):
                texts = [
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                ]
                joined = "\n".join(t for t in texts if t)
                return joined if joined.strip() else None
    except Exception:
        return None
    return None


def _maybe_log(msg: str) -> None:
    if os.environ.get("RR_AUTOATTACH_DEBUG") == "1":
        print(f"[robot-resources/autoattach/openai] {msg}", file=sys.stderr)


def _emit_attach_event(*, sdk: str, attached: bool, **rest: Any) -> None:
    api_key = _read_api_key()
    if not api_key:
        return
    platform_url = os.environ.get("RR_PLATFORM_URL", "https://api.robotresources.ai")
    try:
        import httpx
        from importlib.metadata import version as _pkg_version

        try:
            sdk_version = _pkg_version("openai")
        except Exception:
            sdk_version = None

        with httpx.Client(timeout=5.0) as client:
            client.post(
                f"{platform_url}/v1/telemetry",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "product": "router",
                    "event_type": "adapter_attached",
                    "payload": {
                        "sdk": sdk,
                        "sdk_version": sdk_version,
                        "attached": attached,
                        "language": "python",
                        "module_system": "pth",
                        "python_version": sys.version.split()[0],
                        "platform": sys.platform,
                        **rest,
                    },
                },
            )
    except Exception:
        pass
