"""
Google Generative AI SDK patcher for the auto-attach path.

Patches ``google.generativeai.GenerativeModel.generate_content`` (and async)
to swap the model id with a routing decision from ``/v1/route``. Falls
through unchanged on any failure mode.

Targets the legacy ``google-generativeai`` package (deprecated upstream
but still the dominant install in agent codebases). The newer
``google.genai`` package gets its own patcher in a follow-up if usage
warrants. The legacy SDK's ``GenerativeModel`` constructor takes ``model``
positionally; ``generate_content`` then sends to that fixed model. Our
patcher rewrites ``self.model_name`` (or the SDK's internal model
attribute) per call so each request can route to a different in-lab model.

Why method-wrapping + RouterClient (not env var override): the Google SDK
doesn't expose an env-var base URL hook, AND Python deployments often
restrict inbound port binding. Pure HTTP-out via ``/v1/route`` is the
portable path.
"""

from __future__ import annotations

import os
import sys
from typing import Any

from robot_resources.router import RouterClient, RouterError

_PATCHED_FLAG = "_rr_autoattach_patched"


def attach() -> bool:
    """Monkey-patch the Google Generative AI SDK's GenerativeModel.

    Returns True if patching succeeded (or was already in place), False
    if the SDK isn't installed or any unexpected error occurred.
    """
    try:
        import google.generativeai as genai  # noqa: F401
        from google.generativeai import GenerativeModel
    except Exception:
        return False

    if getattr(GenerativeModel, _PATCHED_FLAG, False):
        return True

    original_gen = GenerativeModel.generate_content
    original_agen = getattr(GenerativeModel, "generate_content_async", None)

    _shared_client = _build_client()

    def _route_and_swap(self: Any) -> None:
        """Pick a routing decision and mutate the model attr in place. Best-
        effort — failure leaves the original model untouched.
        """
        # Latest user content lives on the bound contents arg; we don't see
        # the prompt easily here without a callback hook, so for v1 we use
        # the model's first call to ``contents`` extraction. The wrappers
        # below pass it through.
        pass  # routing happens inside the wrapper closures below

    def _routed_model_name(self: Any, contents: Any) -> str:
        """Return the model id to use for THIS call. Honors user override
        of ``client_options.api_endpoint`` (corp proxy etc.) by falling
        through unchanged.
        """
        original_name = getattr(self, "model_name", None) or getattr(self, "_model_name", None)
        if not original_name:
            return original_name

        try:
            client_options = getattr(self, "_client", None)
            if client_options:
                # If the user pointed the client at a custom endpoint, leave alone.
                api_endpoint = getattr(getattr(client_options, "_options", None), "api_endpoint", "")
                if api_endpoint and "googleapis.com" not in str(api_endpoint):
                    return original_name
        except Exception:
            pass

        prompt = _extract_prompt(contents)
        if not prompt or _shared_client is None:
            return original_name

        try:
            decision = _shared_client.route(prompt, available_providers=["google"])
            new_model = decision.get("selected_model")
            if new_model:
                # Google models are sometimes prefixed with "models/" — keep
                # the same prefix style as the original.
                if str(original_name).startswith("models/") and not str(new_model).startswith("models/"):
                    new_model = "models/" + new_model
                return new_model
        except RouterError as err:
            _maybe_log(f"route failed: {err}")
        except Exception as err:  # noqa: BLE001
            _maybe_log(f"route unexpected error: {err}")

        return original_name

    def patched_generate_content(self: Any, contents: Any, *args: Any, **kwargs: Any) -> Any:
        chosen = _routed_model_name(self, contents)
        # Mutate the SDK's internal model field for the call duration. The
        # SDK reads ``self.model_name`` to build the URL each request.
        original_attr = getattr(self, "model_name", None)
        if chosen and chosen != original_attr:
            try:
                self.model_name = chosen
                return original_gen(self, contents, *args, **kwargs)
            finally:
                if original_attr is not None:
                    self.model_name = original_attr
        return original_gen(self, contents, *args, **kwargs)

    GenerativeModel.generate_content = patched_generate_content  # type: ignore[method-assign]
    setattr(GenerativeModel, _PATCHED_FLAG, True)

    if original_agen:
        async def patched_generate_content_async(self: Any, contents: Any, *args: Any, **kwargs: Any) -> Any:
            chosen = _routed_model_name(self, contents)
            original_attr = getattr(self, "model_name", None)
            if chosen and chosen != original_attr:
                try:
                    self.model_name = chosen
                    return await original_agen(self, contents, *args, **kwargs)
                finally:
                    if original_attr is not None:
                        self.model_name = original_attr
            return await original_agen(self, contents, *args, **kwargs)

        GenerativeModel.generate_content_async = patched_generate_content_async  # type: ignore[method-assign]

    _emit_attach_event(sdk="google", attached=True)
    return True


def _build_client() -> RouterClient | None:
    api_key = _read_api_key()
    if not api_key:
        return None
    try:
        return RouterClient(api_key=api_key)
    except Exception:
        return None


def _read_api_key() -> str | None:
    env_key = os.environ.get("RR_API_KEY")
    if env_key:
        return env_key
    try:
        import json
        from pathlib import Path

        cfg = Path.home() / ".robot-resources" / "config.json"
        return json.loads(cfg.read_text()).get("api_key")
    except Exception:
        return None


def _extract_prompt(contents: Any) -> str | None:
    """Pull the user prompt text out of a Google `contents` value. The SDK
    accepts strings, dicts, or lists of parts. We handle the common cases
    and fall through silently on anything weird.
    """
    if contents is None:
        return None
    try:
        if isinstance(contents, str):
            return contents if contents.strip() else None
        if isinstance(contents, list):
            # List of {role, parts} dicts OR list of strings
            for item in reversed(contents):
                if isinstance(item, str):
                    return item if item.strip() else None
                if isinstance(item, dict):
                    role = item.get("role")
                    if role and role != "user":
                        continue
                    parts = item.get("parts") or []
                    texts: list[str] = []
                    for p in parts:
                        if isinstance(p, str):
                            texts.append(p)
                        elif isinstance(p, dict) and "text" in p:
                            texts.append(str(p["text"]))
                    joined = "\n".join(t for t in texts if t)
                    if joined.strip():
                        return joined
            return None
        if isinstance(contents, dict):
            return _extract_prompt([contents])
    except Exception:
        return None
    return None


def _maybe_log(msg: str) -> None:
    if os.environ.get("RR_AUTOATTACH_DEBUG") == "1":
        print(f"[robot-resources/autoattach/google] {msg}", file=sys.stderr)


def _emit_attach_event(*, sdk: str, attached: bool, **rest: Any) -> None:
    api_key = _read_api_key()
    if not api_key:
        return
    platform_url = os.environ.get("RR_PLATFORM_URL", "https://api.robotresources.ai")
    try:
        import httpx
        from importlib.metadata import version as _pkg_version

        sdk_version = None
        for name in ("google-generativeai", "google.generativeai"):
            try:
                sdk_version = _pkg_version(name)
                break
            except Exception:
                continue

        with httpx.Client(timeout=5.0) as client:
            client.post(
                f"{platform_url}/v1/telemetry",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "product": "router",
                    "event_type": "adapter_attached",
                    "payload": {
                        "sdk": sdk,
                        "sdk_version": sdk_version,
                        "attached": attached,
                        "language": "python",
                        "module_system": "pth",
                        "python_version": sys.version.split()[0],
                        "platform": sys.platform,
                        **rest,
                    },
                },
            )
    except Exception:
        pass
