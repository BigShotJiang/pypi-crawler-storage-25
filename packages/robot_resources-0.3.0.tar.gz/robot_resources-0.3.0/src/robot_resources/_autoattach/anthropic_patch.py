"""
Anthropic SDK patcher for the auto-attach path.

Mechanism: wrap ``anthropic.resources.messages.Messages.create`` (and the
async variant) at class level so every Anthropic instance the user creates
inherits the patch. On each call:

    1. Extract the latest user-message text from ``messages``.
    2. POST to ``/v1/route`` to get a routing decision (selected_model).
    3. Swap ``model`` in kwargs; forward to the original create.

The user's ``ANTHROPIC_API_KEY`` continues to flow straight to
api.anthropic.com via the SDK — we never see request bodies or responses.

Failure modes (all silent — must never break the host agent):
    - SDK not installed → ``attach()`` returns False, no monkey-patching.
    - No api_key in ``~/.robot-resources/config.json`` → telemetry skipped
      AND ``/v1/route`` returns 401 → fall through with original model.
    - Platform unreachable / 5xx / timeout → fall through with original model.
    - ``RR_AUTOATTACH_DEBUG=1`` surfaces these on stderr.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

# Reuse the existing RouterClient — same module, same retries, same auth.
from robot_resources.router import DEFAULT_ENDPOINT, RouterClient, RouterError

_PATCHED_FLAG = "_rr_autoattach_patched"


def attach() -> bool:
    """Monkey-patch the Anthropic SDK's Messages.create methods.

    Returns True if patching succeeded (or was already in place), False if
    the SDK isn't installed or any unexpected error occurred during patching.
    Never raises back into the caller.
    """
    try:
        import anthropic  # noqa: F401 — used via attribute access below
        from anthropic.resources.messages import Messages
    except Exception:
        return False  # SDK not in env — nothing to do

    # AsyncMessages may live in a separate path depending on SDK version. Best-
    # effort: skip async patching if the import path doesn't resolve. Sync is
    # the dominant cohort for non-OC agents we're targeting in P2.
    try:
        from anthropic.resources.messages import AsyncMessages
    except Exception:
        AsyncMessages = None  # type: ignore[assignment]

    if getattr(Messages, _PATCHED_FLAG, False):
        return True  # idempotent

    original_create = Messages.create
    original_acreate = AsyncMessages.create if AsyncMessages else None

    # Single shared client per process — connection pool + retries.
    _shared_client = _build_client()

    def _routed_kwargs(self: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
        # Honor explicit user override of base_url — if they pointed THIS
        # instance somewhere (e.g. a corp proxy), don't second-guess them.
        # ``self`` is the Messages instance; client is in ``self._client``.
        try:
            client_base_url = str(getattr(self._client, "base_url", "") or "")
            if client_base_url and "anthropic.com" not in client_base_url:
                return kwargs
        except Exception:
            pass

        prompt = _extract_prompt(kwargs.get("messages"))
        if not prompt:
            return kwargs

        if _shared_client is None:
            return kwargs

        try:
            decision = _shared_client.route(prompt, available_providers=["anthropic"])
            new_model = decision.get("selected_model")
            if new_model:
                kwargs = {**kwargs, "model": new_model}
        except RouterError as err:
            _maybe_log(f"route failed: {err}")
        except Exception as err:  # noqa: BLE001
            _maybe_log(f"route unexpected error: {err}")

        return kwargs

    def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
        return original_create(self, *args, **_routed_kwargs(self, kwargs))

    Messages.create = patched_create  # type: ignore[method-assign]
    setattr(Messages, _PATCHED_FLAG, True)

    if AsyncMessages and original_acreate:
        async def patched_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
            return await original_acreate(self, *args, **_routed_kwargs(self, kwargs))

        AsyncMessages.create = patched_acreate  # type: ignore[method-assign]
        setattr(AsyncMessages, _PATCHED_FLAG, True)

    _emit_attach_event(sdk="anthropic", attached=True)
    return True


def _build_client() -> RouterClient | None:
    api_key = _read_api_key()
    if not api_key:
        return None
    try:
        return RouterClient(api_key=api_key)
    except Exception:
        return None


def _read_api_key() -> str | None:
    # Env var wins over config.json — matches the Node side and lets users
    # CI-override without writing to disk.
    env_key = os.environ.get("RR_API_KEY")
    if env_key:
        return env_key
    cfg_path = Path.home() / ".robot-resources" / "config.json"
    try:
        return json.loads(cfg_path.read_text()).get("api_key")
    except Exception:
        return None


def _extract_prompt(messages: Any) -> str | None:
    """Pull the last user message text out of an Anthropic Messages payload.

    Supports both the simple form ({'role': 'user', 'content': 'string'})
    and the structured form ({'role': 'user', 'content': [{'type': 'text', ...}]}).
    """
    if not messages:
        return None
    try:
        for msg in reversed(messages):
            if not isinstance(msg, dict):
                continue
            if msg.get("role") != "user":
                continue
            content = msg.get("content")
            if isinstance(content, str):
                return content if content.strip() else None
            if isinstance(content, list):
                texts = [
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                ]
                joined = "\n".join(t for t in texts if t)
                return joined if joined.strip() else None
    except Exception:
        return None
    return None


def _maybe_log(msg: str) -> None:
    if os.environ.get("RR_AUTOATTACH_DEBUG") == "1":
        print(f"[robot-resources/autoattach/anthropic] {msg}", file=sys.stderr)


def _emit_attach_event(*, sdk: str, attached: bool, **rest: Any) -> None:
    """Fire-and-forget telemetry. Never raises."""
    api_key = _read_api_key()
    if not api_key:
        return
    platform_url = os.environ.get("RR_PLATFORM_URL", "https://api.robotresources.ai")
    try:
        import httpx

        sdk_version = _read_sdk_version("anthropic")
        with httpx.Client(timeout=5.0) as client:
            client.post(
                f"{platform_url}/v1/telemetry",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "product": "router",
                    "event_type": "adapter_attached",
                    "payload": {
                        "sdk": sdk,
                        "sdk_version": sdk_version,
                        "attached": attached,
                        "language": "python",
                        "module_system": "pth",
                        "python_version": sys.version.split()[0],
                        "platform": sys.platform,
                        **rest,
                    },
                },
            )
    except Exception:
        pass


def _read_sdk_version(name: str) -> str | None:
    try:
        from importlib.metadata import version

        return version(name)
    except Exception:
        return None
