from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class DiagnosticSummary:
    propensity_min: float
    propensity_max: float
    treated_mean_propensity: float
    control_mean_propensity: float
    overlap_ok: bool
    balance_before: dict[str, float]
    balance_after: dict[str, float]
    variance_ratios: dict[str, float] | None = None
    ess_treated: float | None = None
    ess_control: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def __str__(self) -> str:
        return (
            f"DiagnosticSummary(\n"
            f"  overlap: {self.overlap_ok}\n"
            f"  balance_before (mean |SMD|): {sum(self.balance_before.values()) / len(self.balance_before):.4f}\n"
            f"  balance_after (mean |SMD|): {sum(self.balance_after.values()) / len(self.balance_after):.4f}\n"
            f"  propensity_range: [{self.propensity_min:.3f}, {self.propensity_max:.3f}]\n"
            f")"
        )

    def summary(self) -> str:
        """Human-readable summary of diagnostic checks."""
        status = "✓ PASS" if self.overlap_ok else "✗ FAIL"
        return (
            f"Common support (overlap): {status}\n"
            f"Balance improvement: {sum(self.balance_before.values()) / len(self.balance_before):.4f} → "
            f"{sum(self.balance_after.values()) / len(self.balance_after):.4f}"
        )


@dataclass(frozen=True)
class CausalEstimate:
    method: str
    estimand: str
    effect: float
    ci_low: float | None
    ci_high: float | None
    treated_count: int
    control_count: int
    diagnostics: DiagnosticSummary
    se: float | None = None
    p_value: float | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["diagnostics"] = self.diagnostics.to_dict()
        return payload

    def __str__(self) -> str:
        ci_str = (
            f"[{self.ci_low:.2f}, {self.ci_high:.2f}]"
            if self.ci_low is not None and self.ci_high is not None
            else "None"
        )
        p_str = f" (p={self.p_value:.4f})" if self.p_value is not None else ""
        return (
            f"{self.method} ({self.estimand}): effect={self.effect:.4f}, 95% CI={ci_str}{p_str}"
        )

    def summary(self) -> str:
        """Human-readable summary with key metrics."""
        lines = [f"\n{self.method} ({self.estimand}):"]
        lines.append(f"  Effect estimate: {self.effect:.4f}")
        if self.se is not None:
            lines.append(f"  Standard error: {self.se:.4f}")
        if self.ci_low is not None and self.ci_high is not None:
            lines.append(f"  95% CI: [{self.ci_low:.4f}, {self.ci_high:.4f}]")
        if self.p_value is not None:
            lines.append(f"  p-value: {self.p_value:.4e}")
        lines.append(f"  Sample: {self.treated_count} treated, {self.control_count} control")
        lines.append(f"  {self.diagnostics.summary()}")
        return "\n".join(lines)



@dataclass(frozen=True)
class SensitivityScenario:
    bias: float
    adjusted_effect: float
    adjusted_ci_low: float | None
    adjusted_ci_high: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SensitivitySummary:
    bias_to_zero_effect: float
    bias_to_zero_ci: float
    standardized_bias_to_zero_effect: float
    standardized_bias_to_zero_ci: float
    scenarios: list[SensitivityScenario]
    e_value: float | None = None
    e_value_ci: float | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["scenarios"] = [scenario.to_dict() for scenario in self.scenarios]
        return payload


@dataclass(frozen=True)
class SubgroupEstimate:
    subgroup: str
    rows: int
    treated_count: int
    control_count: int
    effect: float
    ci_low: float | None
    ci_high: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RosenbaumSensitivity:
    gamma: float
    p_upper: float
    significant_at_05: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PlaceboResult:
    placebo_outcome: str
    method: str
    effect: float
    ci_low: float | None
    ci_high: float | None
    passes: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
