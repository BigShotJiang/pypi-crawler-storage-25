from __future__ import annotations

from pathlib import Path
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


METHOD_LABELS = {
    "RegressionAdjustmentEstimator": "Regression",
    "PropensityMatcher": "Matching",
    "IPWEstimator": "IPW",
    "DoublyRobustEstimator": "Doubly robust",
}

PALETTE = {
    "primary": "#2D6A8E",
    "secondary": "#CB7A34",
    "accent": "#5B8F65",
    "neutral": "#1F2A37",
    "muted": "#6B7280",
    "reference": "#8B3A3A",
    "fill": "#CDE3F0",
}


plt.style.use("seaborn-v0_8-whitegrid")
plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Segoe UI", "Arial", "DejaVu Sans"],
        "axes.titlesize": 15,
        "axes.titleweight": "semibold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)


def results_to_frame(results: list[dict]) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for result in results:
        diagnostics = result["diagnostics"]
        balance_before = diagnostics["balance_before"]
        balance_after = diagnostics["balance_after"]
        rows.append(
            {
                "method": result["method"],
                "estimand": result["estimand"],
                "effect": result["effect"],
                "se": result.get("se"),
                "p_value": result.get("p_value"),
                "ci_low": result["ci_low"],
                "ci_high": result["ci_high"],
                "overlap_ok": diagnostics["overlap_ok"],
                "mean_abs_balance_before": sum(abs(value) for value in balance_before.values()) / len(balance_before),
                "mean_abs_balance_after": sum(abs(value) for value in balance_after.values()) / len(balance_after),
                "ess_treated": diagnostics.get("ess_treated"),
                "ess_control": diagnostics.get("ess_control"),
            }
        )
    return pd.DataFrame(rows)


def subgroup_to_frame(subgroups: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(subgroups)


def sensitivity_to_frame(summary: dict) -> pd.DataFrame:
    return pd.DataFrame(summary["scenarios"])


def export_dataset_artifacts(dataset_key: str, payload: dict, output_dir: Path) -> None:
    charts_dir = output_dir / "charts"
    tables_dir = output_dir / "tables"
    charts_dir.mkdir(parents=True, exist_ok=True)
    tables_dir.mkdir(parents=True, exist_ok=True)

    results_frame = results_to_frame(payload["results"])
    sensitivity_frame = sensitivity_to_frame(payload["primary_sensitivity"])
    subgroup_frame = subgroup_to_frame(payload["subgroups"])

    results_csv = tables_dir / f"{dataset_key}_estimator_summary.csv"
    subgroup_csv = tables_dir / f"{dataset_key}_subgroup_summary.csv"
    sensitivity_csv = tables_dir / f"{dataset_key}_sensitivity_summary.csv"
    results_md = tables_dir / f"{dataset_key}_estimator_summary.md"

    results_frame.to_csv(results_csv, index=False)
    subgroup_frame.to_csv(subgroup_csv, index=False)
    sensitivity_frame.to_csv(sensitivity_csv, index=False)
    results_md.write_text(_frame_to_markdown(results_frame), encoding="utf-8")

    _plot_estimator_comparison(
        results_frame,
        title=f"{_display_name(dataset_key)} estimator comparison",
        output_path=charts_dir / f"{dataset_key}_estimator_comparison.png",
    )
    _plot_balance_summary(
        results_frame,
        title=f"{_display_name(dataset_key)} balance summary",
        output_path=charts_dir / f"{dataset_key}_balance_summary.png",
    )
    _plot_sensitivity_summary(
        sensitivity_frame,
        title=f"{_display_name(dataset_key)} sensitivity curve",
        output_path=charts_dir / f"{dataset_key}_sensitivity_curve.png",
    )
    if not subgroup_frame.empty:
        _plot_subgroup_effects(
            subgroup_frame,
            title=f"{_display_name(dataset_key)} subgroup effects",
            output_path=charts_dir / f"{dataset_key}_subgroup_effects.png",
        )

    if payload["results"]:
        primary = payload["results"][-1]
        _plot_love(
            primary["diagnostics"]["balance_before"],
            primary["diagnostics"]["balance_after"],
            title=f"{_display_name(dataset_key)} covariate balance (Love plot)",
            output_path=charts_dir / f"{dataset_key}_love_plot.png",
        )


def export_benchmark_artifacts(report_payload: dict, output_dir: Path) -> None:
    tables_dir = output_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)

    benchmark_frame = benchmark_to_frame(report_payload)
    benchmark_csv = tables_dir / "cross_dataset_benchmark_summary.csv"
    benchmark_md = tables_dir / "cross_dataset_benchmark_summary.md"
    benchmark_frame.to_csv(benchmark_csv, index=False)
    benchmark_md.write_text(_frame_to_markdown(benchmark_frame), encoding="utf-8")


def benchmark_to_frame(report_payload: dict) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for dataset_key, dataset in report_payload.items():
        if not isinstance(dataset, dict) or "results" not in dataset:
            continue
        results_frame = results_to_frame(dataset["results"]).copy()
        results_frame["dataset"] = dataset_key
        for _, row in results_frame.iterrows():
            ci_width = float(row["ci_high"] - row["ci_low"])
            rows.append(
                {
                    "dataset": dataset_key,
                    "method": row["method"],
                    "effect": float(row["effect"]),
                    "ci_width": ci_width,
                    "overlap_ok": bool(row["overlap_ok"]),
                    "mean_abs_balance_before": float(row["mean_abs_balance_before"]),
                    "mean_abs_balance_after": float(row["mean_abs_balance_after"]),
                    "balance_improvement": float(row["mean_abs_balance_before"] - row["mean_abs_balance_after"]),
                }
            )
    return pd.DataFrame(rows)


def _clean_method_label(label: str) -> str:
    return METHOD_LABELS.get(label, label)


def _setup_axes(ax: "plt.Axes") -> None:
    ax.set_axisbelow(True)
    ax.grid(axis="x", color="#E5E7EB", linewidth=0.8, linestyle="-")
    ax.grid(axis="y", visible=False)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.spines["left"].set_color(PALETTE["muted"])
    ax.spines["bottom"].set_color(PALETTE["muted"])


def _styled_title(raw_title: str) -> str:
    return textwrap.fill(raw_title, width=44)


def _set_x_limits_with_padding(ax: "plt.Axes", lower_bound: float, upper_bound: float) -> None:
    span = max(upper_bound - lower_bound, 1e-9)
    pad = span * 0.08
    ax.set_xlim(lower_bound - pad, upper_bound + pad)


def _plot_estimator_comparison(results_frame: pd.DataFrame, title: str, output_path: Path) -> None:
    frame = results_frame.copy().sort_values("effect")
    frame["method"] = frame["method"].map(_clean_method_label)
    effect = frame["effect"].astype(float).to_numpy()
    ci_low = frame["ci_low"].astype(float).to_numpy()
    ci_high = frame["ci_high"].astype(float).to_numpy()
    lower = (effect - ci_low).clip(min=0.0)
    upper = (ci_high - effect).clip(min=0.0)

    fig, ax = plt.subplots(figsize=(9.4, 5.4), constrained_layout=True)
    y_positions = list(range(len(frame)))
    ax.errorbar(
        effect,
        y_positions,
        xerr=[lower, upper],
        fmt="o",
        color=PALETTE["primary"],
        ecolor=PALETTE["neutral"],
        elinewidth=1.4,
        capsize=4,
        markersize=7,
    )
    ax.axvline(0.0, color=PALETTE["reference"], linestyle="--", linewidth=1.3)
    ax.set_yticks(y_positions)
    ax.set_yticklabels(frame["method"])
    ax.set_xlabel("Estimated effect (point and 95% CI)")
    ax.set_title(_styled_title(title), pad=12)
    _set_x_limits_with_padding(ax, min(float(ci_low.min()), 0.0), max(float(ci_high.max()), 0.0))
    _setup_axes(ax)
    fig.savefig(output_path, dpi=240, bbox_inches="tight")
    plt.close(fig)


def _plot_balance_summary(results_frame: pd.DataFrame, title: str, output_path: Path) -> None:
    frame = results_frame.copy()
    frame["method"] = frame["method"].map(_clean_method_label)
    frame = frame.sort_values("mean_abs_balance_before", ascending=True)

    before = frame["mean_abs_balance_before"].astype(float).to_numpy()
    after = frame["mean_abs_balance_after"].astype(float).to_numpy()
    y_positions = list(range(len(frame)))

    fig, ax = plt.subplots(figsize=(9.4, 5.4), constrained_layout=True)
    for idx, y_pos in enumerate(y_positions):
        ax.plot(
            [before[idx], after[idx]],
            [y_pos, y_pos],
            color="#C9D2DA",
            linewidth=2.0,
            zorder=1,
        )
    ax.scatter(before, y_positions, color=PALETTE["secondary"], label="Before", s=60, zorder=3)
    ax.scatter(after, y_positions, color=PALETTE["accent"], label="After", s=60, zorder=3)
    ax.axvline(0.1, color=PALETTE["reference"], linestyle="--", linewidth=1.1, alpha=0.9, label="|SMD| threshold")
    ax.set_yticks(y_positions)
    ax.set_yticklabels(frame["method"])
    ax.set_xlabel("Mean absolute standardized mean difference")
    ax.set_title(_styled_title(title), pad=12)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), frameon=False, borderaxespad=0.0)
    _set_x_limits_with_padding(ax, 0.0, max(float(before.max()), float(after.max()), 0.1))
    _setup_axes(ax)
    fig.savefig(output_path, dpi=240, bbox_inches="tight")
    plt.close(fig)


def _plot_sensitivity_summary(sensitivity_frame: pd.DataFrame, title: str, output_path: Path) -> None:
    frame = sensitivity_frame.copy().sort_values("bias")
    fig, ax = plt.subplots(figsize=(9.4, 5.4), constrained_layout=True)
    ax.plot(frame["bias"], frame["adjusted_effect"], marker="o", color=PALETTE["primary"], linewidth=2.1)
    ax.fill_between(
        frame["bias"],
        frame["adjusted_ci_low"],
        frame["adjusted_ci_high"],
        color=PALETTE["fill"],
        alpha=0.45,
    )
    ax.axhline(0.0, color=PALETTE["reference"], linestyle="--", linewidth=1.3)
    ax.set_title(_styled_title(title), pad=12)
    ax.set_xlabel("Additive bias")
    ax.set_ylabel("Adjusted effect")
    _set_x_limits_with_padding(ax, float(frame["bias"].min()), float(frame["bias"].max()))
    _setup_axes(ax)
    fig.savefig(output_path, dpi=240, bbox_inches="tight")
    plt.close(fig)


def _plot_subgroup_effects(subgroup_frame: pd.DataFrame, title: str, output_path: Path) -> None:
    frame = subgroup_frame.copy().sort_values("effect")
    frame["subgroup"] = frame["subgroup"].astype(str)
    effect = frame["effect"].astype(float).to_numpy()
    ci_low = frame["ci_low"].astype(float).to_numpy()
    ci_high = frame["ci_high"].astype(float).to_numpy()
    lower = (effect - ci_low).clip(min=0.0)
    upper = (ci_high - effect).clip(min=0.0)
    y_positions = list(range(len(frame)))

    fig, ax = plt.subplots(figsize=(9.6, 5.6), constrained_layout=True)
    ax.errorbar(
        effect,
        y_positions,
        xerr=[lower, upper],
        fmt="o",
        color=PALETTE["primary"],
        ecolor=PALETTE["neutral"],
        elinewidth=1.4,
        capsize=4,
        markersize=7,
    )
    ax.axvline(0.0, color=PALETTE["reference"], linestyle="--", linewidth=1.3)
    ax.set_title(_styled_title(title), pad=12)
    ax.set_xlabel("Estimated effect (point and 95% CI)")
    ax.set_yticks(y_positions)
    ax.set_yticklabels(frame["subgroup"])
    _set_x_limits_with_padding(ax, min(float(ci_low.min()), 0.0), max(float(ci_high.max()), 0.0))
    _setup_axes(ax)
    fig.savefig(output_path, dpi=240, bbox_inches="tight")
    plt.close(fig)


def export_propensity_overlap(
    propensity: "np.ndarray",
    treatment: "np.ndarray",
    title: str,
    output_path: Path,
) -> None:
    """Export a propensity-score overlap histogram by treatment group."""
    import numpy as np

    fig, ax = plt.subplots(figsize=(9.4, 5.4), constrained_layout=True)
    bins = np.linspace(float(propensity.min()), float(propensity.max()), 35)
    ax.hist(
        propensity[treatment == 1],
        bins=bins,
        alpha=0.35,
        label="Treated",
        color=PALETTE["primary"],
        edgecolor=PALETTE["primary"],
        linewidth=1.0,
        density=True,
    )
    ax.hist(
        propensity[treatment == 0],
        bins=bins,
        alpha=0.35,
        label="Control",
        color=PALETTE["secondary"],
        edgecolor=PALETTE["secondary"],
        linewidth=1.0,
        density=True,
    )
    ax.set_xlabel("Propensity score")
    ax.set_ylabel("Density")
    ax.set_title(_styled_title(title), pad=12)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), frameon=False, borderaxespad=0.0)
    _set_x_limits_with_padding(ax, float(propensity.min()), float(propensity.max()))
    _setup_axes(ax)
    fig.savefig(output_path, dpi=240, bbox_inches="tight")
    plt.close(fig)


def export_placebo_artifacts(placebo_results: list[dict], output_dir: Path) -> pd.DataFrame:
    """Export placebo/falsification test results to CSV."""
    tables_dir = output_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(placebo_results)
    frame.to_csv(tables_dir / "placebo_test.csv", index=False)
    return frame


def export_rosenbaum_artifacts(rosenbaum_results: list[dict], output_dir: Path) -> pd.DataFrame:
    """Export Rosenbaum sensitivity bounds to CSV."""
    tables_dir = output_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rosenbaum_results)
    frame.to_csv(tables_dir / "rosenbaum_bounds.csv", index=False)
    return frame


def _plot_love(
    balance_before: dict[str, float],
    balance_after: dict[str, float],
    title: str,
    output_path: Path,
) -> None:
    """Love plot: covariate-level |SMD| before and after adjustment."""
    covariates = sorted(balance_before.keys(), key=lambda cov: abs(balance_before[cov]), reverse=True)
    y_positions = list(range(len(covariates)))
    abs_before = [abs(balance_before[c]) for c in covariates]
    abs_after = [abs(balance_after[c]) for c in covariates]

    fig, ax = plt.subplots(figsize=(9.6, max(5.2, 0.48 * len(covariates))), constrained_layout=True)
    for idx, y_pos in enumerate(y_positions):
        ax.plot(
            [abs_before[idx], abs_after[idx]],
            [y_pos, y_pos],
            color="#CBD5E1",
            linewidth=1.2,
            zorder=1,
        )
    ax.scatter(abs_before, y_positions, marker="x", s=90, color=PALETTE["secondary"], label="Unadjusted", zorder=3)
    ax.scatter(abs_after, y_positions, marker="o", s=65, color=PALETTE["accent"], label="Adjusted", zorder=3)
    ax.axvline(0.1, color=PALETTE["reference"], linestyle="--", linewidth=1.2, label="|SMD| = 0.1")
    ax.axvline(0.25, color=PALETTE["reference"], linestyle=":", linewidth=1.0, alpha=0.6, label="|SMD| = 0.25")
    ax.set_yticks(y_positions)
    ax.set_yticklabels(covariates)
    ax.set_xlabel("Absolute standardized mean difference")
    ax.set_title(_styled_title(title), pad=12)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=9, frameon=False, borderaxespad=0.0)
    _set_x_limits_with_padding(ax, 0.0, max(max(abs_before), max(abs_after), 0.25))
    _setup_axes(ax)
    fig.savefig(output_path, dpi=240, bbox_inches="tight")
    plt.close(fig)


def _display_name(dataset_key: str) -> str:
    return dataset_key.replace("_", " ").title()


def _frame_to_markdown(frame: pd.DataFrame) -> str:
    columns = list(frame.columns)
    header = "| " + " | ".join(columns) + " |"
    divider = "| " + " | ".join(["---"] * len(columns)) + " |"
    rows = [header, divider]
    for _, row in frame.iterrows():
        values = [str(row[column]) for column in columns]
        rows.append("| " + " | ".join(values) + " |")
    return "\n".join(rows) + "\n"
