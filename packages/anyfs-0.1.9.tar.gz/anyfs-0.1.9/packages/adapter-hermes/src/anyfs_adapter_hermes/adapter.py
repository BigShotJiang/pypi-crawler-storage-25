from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay
from anyfs_transcript import parse_transcript, render_markdown

_DEFAULT_HERMES_HOME = ".hermes"
_HERMES_EXCLUDED_CONTEXT_FILES = {"config.yaml", ".env"}


def _hermes_home() -> Path:
    return Path(os.environ.get("HERMES_HOME", Path.home() / _DEFAULT_HERMES_HOME)).expanduser()


def _current_hermes_session_id() -> str | None:
    for env_name in ("ANYFS_HERMES_SESSION_ID", "ANYFS_CURRENT_PROCESS_ID"):
        value = os.environ.get(env_name)
        if value:
            return value.strip()
    return None


def _hermes_recent_session_ids(hermes_home: Path) -> list[str]:
    discovered: list[str] = []
    state_db = hermes_home / "state.db"
    if state_db.is_file():
        try:
            conn = sqlite3.connect(state_db)
            rows = conn.execute(
                "SELECT id FROM sessions WHERE source = 'cli' ORDER BY started_at DESC LIMIT 20"
            ).fetchall()
            conn.close()
            discovered.extend(row[0] for row in rows if isinstance(row[0], str) and row[0])
        except sqlite3.Error:
            pass

    sessions_dir = hermes_home / "sessions"
    for path in sorted(sessions_dir.glob("*.jsonl"), key=lambda item: item.stat().st_mtime, reverse=True)[:20]:
        if path.stem not in discovered:
            discovered.append(path.stem)
    return discovered[:20]


def _hermes_process_files(process_scope: str = "current") -> list[Path]:
    hermes_home = _hermes_home()
    sessions_dir = hermes_home / "sessions"
    if not sessions_dir.exists():
        return []

    if process_scope == "all":
        session_ids = _hermes_recent_session_ids(hermes_home)
    else:
        current_session_id = _current_hermes_session_id()
        session_ids = [current_session_id] if current_session_id else _hermes_recent_session_ids(hermes_home)

    files: list[Path] = []
    for session_id in session_ids:
        if not session_id:
            continue
        path = sessions_dir / f"{session_id}.jsonl"
        if path.is_file():
            append_unique(files, path)
            if process_scope != "all":
                break
    return files[:20] if process_scope == "all" else files[:1]


class HermesAdapter(AgentAdapter):
    agent_type = AgentType.HERMES

    def __init__(self, process_scope: str = "current") -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"

    def discover(self, workspace: str) -> list[Path]:
        workspace_path = Path(workspace).resolve()
        hermes_home = _hermes_home()
        candidates: list[Path] = list(_hermes_process_files(self.process_scope))

        for path in (
            workspace_path / "AGENTS.md",
            hermes_home / "SOUL.md",
            hermes_home / "memories" / "USER.md",
            hermes_home / "memories" / "MEMORY.md",
        ):
            append_unique(candidates, path)

        for root in (
            workspace_path / ".hermes",
            hermes_home / "skills",
            hermes_home / "memories",
        ):
            for path in collect_text_files(root, max_files=120, exclude_names=_HERMES_EXCLUDED_CONTEXT_FILES):
                append_unique(candidates, path)

        return candidates[:200]

    def extract(self, workspace: str) -> list[dict]:
        workspace_path = Path(workspace).resolve()
        hermes_home = _hermes_home()
        records = []
        for path in self.discover(workspace):
            name = path.name.lower()
            if path.suffix == ".jsonl" and path.parent == hermes_home / "sessions":
                try:
                    canonical = parse_transcript(path, agent_type="hermes")
                    records.append(
                        {
                            "path": str(path),
                            "relative_path": f"process/hermes/{path.name}",
                            "namespace": "process",
                            "content": render_markdown(canonical),
                            "canonical_transcript": canonical.model_dump(mode="json"),
                        }
                    )
                    continue
                except Exception:
                    pass
            if path.is_relative_to(hermes_home):
                relative = path.relative_to(hermes_home)
                if name == "soul.md":
                    namespace = "soul"
                elif name == "user.md":
                    namespace = "user"
                elif "memory" in relative.parts or name == "memory.md":
                    namespace = "memory"
                else:
                    namespace = "skills"
                relative_path = f"{namespace}/hermes/global/{relative}"
            else:
                if name == "agents.md":
                    namespace = "skills"
                elif name == "soul.md":
                    namespace = "soul"
                elif name == "user.md":
                    namespace = "user"
                elif "memory" in path.parts or name == "memory.md":
                    namespace = "memory"
                else:
                    namespace = "skills"
                relative_path = str(path.relative_to(workspace_path))

            records.append(
                {
                    "path": str(path),
                    "relative_path": relative_path,
                    "namespace": namespace,
                    "content": read_text_file(path),
                }
            )
        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no Hermes Agent files were discovered"],
        )
