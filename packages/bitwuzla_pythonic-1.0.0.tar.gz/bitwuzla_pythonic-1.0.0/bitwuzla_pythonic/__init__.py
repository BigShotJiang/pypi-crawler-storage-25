"""Pythonic API for Bitwuzla - a Satisfiability Modulo Theories (SMT) solver.

This module provides a z3py-compatible interface for the Bitwuzla SMT solver.
It supports Booleans, Bit-vectors, Floating-point, Arrays, Uninterpreted
functions, and Quantifiers.

>>> x, y = BitVecs('x y', 32)
>>> s = Solver()
>>> s.add(x + y == 10)
>>> s.add(x > 0, y > 0)
>>> s.check()
sat
"""

from ._api import *  # noqa: F403
