from __future__ import annotations

import io

from bitwuzla import Kind

from . import _api as bw

_bw_kinds_to_str = {
    Kind.EQUAL: '==',
    Kind.DISTINCT: 'Distinct',
    Kind.ITE: 'If',
    Kind.AND: 'And',
    Kind.OR: 'Or',
    Kind.XOR: 'Xor',
    Kind.NOT: 'Not',
    Kind.IMPLIES: 'Implies',
    Kind.IFF: '==',
    Kind.BV_ADD: '+',
    Kind.BV_SUB: '-',
    Kind.BV_MUL: '*',
    Kind.BV_SDIV: '/',
    Kind.BV_SMOD: '%',
    Kind.BV_SREM: 'SRem',
    Kind.BV_UREM: 'URem',
    Kind.BV_UDIV: 'UDiv',
    Kind.BV_NEG: '-',
    Kind.BV_NOT: '~',
    Kind.BV_OR: '|',
    Kind.BV_AND: '&',
    Kind.BV_XOR: '^',
    Kind.BV_NAND: 'BVNand',
    Kind.BV_NOR: 'BVNor',
    Kind.BV_XNOR: 'BVXnor',
    Kind.BV_SHL: '<<',
    Kind.BV_ASHR: '>>',
    Kind.BV_SHR: 'LShR',
    Kind.BV_SLE: '<=',
    Kind.BV_SLT: '<',
    Kind.BV_SGE: '>=',
    Kind.BV_SGT: '>',
    Kind.BV_ULE: 'ULE',
    Kind.BV_ULT: 'ULT',
    Kind.BV_UGE: 'UGE',
    Kind.BV_UGT: 'UGT',
    Kind.BV_SIGN_EXTEND: 'SignExt',
    Kind.BV_ZERO_EXTEND: 'ZeroExt',
    Kind.BV_REPEAT: 'RepeatBitVec',
    Kind.BV_CONCAT: 'Concat',
    Kind.BV_EXTRACT: 'Extract',
    Kind.BV_ROL: 'RotateLeft',
    Kind.BV_ROR: 'RotateRight',
    Kind.BV_ROLI: 'RotateLeft',
    Kind.BV_RORI: 'RotateRight',
    Kind.BV_COMP: 'BVComp',
    Kind.BV_REDAND: 'BVRedAnd',
    Kind.BV_REDOR: 'BVRedOr',
    Kind.BV_REDXOR: 'BVRedXor',
    Kind.BV_INC: 'BVInc',
    Kind.BV_DEC: 'BVDec',
    Kind.ARRAY_SELECT: 'Select',
    Kind.ARRAY_STORE: 'Store',
    Kind.CONST_ARRAY: 'ConstArray',
    Kind.FP_IS_NAN: 'fpIsNaN',
    Kind.FP_IS_INF: 'fpIsInf',
    Kind.FP_IS_ZERO: 'fpIsZero',
    Kind.FP_IS_NORMAL: 'fpIsNormal',
    Kind.FP_IS_SUBNORMAL: 'fpIsSubnormal',
    Kind.FP_IS_NEG: 'fpIsNegative',
    Kind.FP_IS_POS: 'fpIsPositive',
}

_bw_infix = [
    Kind.EQUAL,
    Kind.IFF,
    Kind.BV_ADD,
    Kind.BV_SUB,
    Kind.BV_MUL,
    Kind.BV_SDIV,
    Kind.BV_SMOD,
    Kind.BV_OR,
    Kind.BV_AND,
    Kind.BV_XOR,
    Kind.BV_SLE,
    Kind.BV_SLT,
    Kind.BV_SGE,
    Kind.BV_SGT,
    Kind.BV_ASHR,
    Kind.BV_SHL,
]

_bw_unary = [Kind.BV_NEG, Kind.BV_NOT]

_bw_precedence = {
    Kind.BV_NEG: 1,
    Kind.BV_NOT: 1,
    Kind.BV_MUL: 2,
    Kind.BV_SDIV: 2,
    Kind.BV_SMOD: 2,
    Kind.BV_ADD: 3,
    Kind.BV_SUB: 3,
    Kind.BV_ASHR: 4,
    Kind.BV_SHL: 4,
    Kind.BV_AND: 5,
    Kind.BV_XOR: 6,
    Kind.BV_OR: 7,
    Kind.EQUAL: 8,
    Kind.IFF: 8,
    Kind.BV_SLE: 8,
    Kind.BV_SLT: 8,
    Kind.BV_SGE: 8,
    Kind.BV_SGT: 8,
    Kind.BV_ULE: 8,
    Kind.BV_ULT: 8,
    Kind.BV_UGE: 8,
    Kind.BV_UGT: 8,
}

_bw_fp_rm_short_strings = {
    'RNE': 'RNE()',
    'RNA': 'RNA()',
    'RTN': 'RTN()',
    'RTP': 'RTP()',
    'RTZ': 'RTZ()',
}

_bw_fp_rm_long_strings = {
    'RNE': 'RoundNearestTiesToEven()',
    'RNA': 'RoundNearestTiesToAway()',
    'RTN': 'RoundTowardNegative()',
    'RTP': 'RoundTowardPositive()',
    'RTZ': 'RoundTowardZero()',
}

_bw_kind_to_fp_normal_str = {
    Kind.FP_ADD: 'fpAdd',
    Kind.FP_SUB: 'fpSub',
    Kind.FP_NEG: 'fpNeg',
    Kind.FP_MUL: 'fpMul',
    Kind.FP_DIV: 'fpDiv',
    Kind.FP_REM: 'fpRem',
    Kind.FP_ABS: 'fpAbs',
    Kind.FP_MIN: 'fpMin',
    Kind.FP_MAX: 'fpMax',
    Kind.FP_FMA: 'fpFMA',
    Kind.FP_SQRT: 'fpSqrt',
    Kind.FP_RTI: 'fpRoundToIntegral',
    Kind.FP_EQUAL: 'fpEQ',
    Kind.FP_LT: 'fpLT',
    Kind.FP_GT: 'fpGT',
    Kind.FP_LEQ: 'fpLEQ',
    Kind.FP_GEQ: 'fpGEQ',
    Kind.FP_TO_FP_FROM_FP: 'fpToFP',
    Kind.FP_TO_FP_FROM_UBV: 'fpToFP',
    Kind.FP_TO_FP_FROM_SBV: 'fpToFP',
    Kind.FP_TO_FP_FROM_BV: 'fpToFP',
    Kind.FP_TO_UBV: 'fpToUBV',
    Kind.FP_TO_SBV: 'fpToSBV',
}

_bw_kind_to_fp_pretty_str = {
    Kind.FP_ADD: '+',
    Kind.FP_SUB: '-',
    Kind.FP_MUL: '*',
    Kind.FP_DIV: '/',
    Kind.FP_REM: '%',
    Kind.FP_NEG: '-',
    Kind.FP_EQUAL: 'fpEQ',
    Kind.FP_LT: '<',
    Kind.FP_GT: '>',
    Kind.FP_LEQ: '<=',
    Kind.FP_GEQ: '>=',
}

_bw_fp_infix = [
    Kind.FP_ADD,
    Kind.FP_SUB,
    Kind.FP_MUL,
    Kind.FP_DIV,
    Kind.FP_REM,
    Kind.FP_LT,
    Kind.FP_GT,
    Kind.FP_LEQ,
    Kind.FP_GEQ,
]

_bw_infix_compact = [
    Kind.BV_MUL,
    Kind.BV_SDIV,
    Kind.BV_SMOD,
]

_ellipses = '...'


def _is_assoc(k):
    return k in {Kind.BV_OR, Kind.BV_XOR, Kind.BV_AND, Kind.BV_ADD, Kind.BV_MUL}


def _is_left_assoc(k):
    return _is_assoc(k) or k == Kind.BV_SUB


def _is_add(k):
    return k == Kind.BV_ADD


def _is_sub(k):
    return k == Kind.BV_SUB


_base_infix_set = set(_bw_infix)
_fp_infix_set = set(_bw_fp_infix)
_unary_set = set(_bw_unary)
_infix_compact_set = set(_bw_infix_compact)

# Module-level fpa_pretty flag (used by free functions below)
_fpa_pretty = True


def _is_infix(k):
    if k in _base_infix_set:
        return True
    if _fpa_pretty and k in _fp_infix_set:
        return True
    return False


def _is_infix_compact(k):
    return k in _infix_compact_set


def _is_unary(k):
    return k in _unary_set


def _op_name(a):
    k = a.kind()
    if _fpa_pretty and k in _bw_kind_to_fp_pretty_str:
        return _bw_kind_to_fp_pretty_str[k]
    n = _bw_kinds_to_str.get(k, None)
    if n is not None:
        return n
    if k in (Kind.CONSTANT, Kind.VALUE, Kind.VARIABLE):
        return str(a.ast)
    if isinstance(a, bw.FuncDeclRef):
        return a.name()
    return str(a.ast)


def _get_precedence(k):
    return _bw_precedence.get(k, 100000)


class FormatObject:
    def is_compose(self):
        return False

    def is_choice(self):
        return False

    def is_indent(self):
        return False

    def is_string(self):
        return False

    def is_linebreak(self):
        return False

    def is_nil(self):
        return True

    def space_upto_nl(self):
        return (0, False)

    def flat(self):
        return self


class NAryFormatObject(FormatObject):
    def __init__(self, fs):
        self.children = fs


class ComposeFormatObject(NAryFormatObject):
    def is_compose(self):
        return True

    def space_upto_nl(self):
        r = 0
        for child in self.children:
            s, nl = child.space_upto_nl()
            r = r + s
            if nl:
                return (r, True)
        return (r, False)

    def flat(self):
        return compose([a.flat() for a in self.children])


class ChoiceFormatObject(NAryFormatObject):
    def is_choice(self):
        return True

    def space_upto_nl(self):
        return self.children[0].space_upto_nl()

    def flat(self):
        return self.children[0].flat()


class IndentFormatObject(FormatObject):
    def __init__(self, indent, child):
        self.indent = indent
        self.child = child

    def space_upto_nl(self):
        return self.child.space_upto_nl()

    def flat(self):
        return indent(self.indent, self.child.flat())

    def is_indent(self):
        return True


class LineBreakFormatObject(FormatObject):
    def __init__(self):
        self.space = ' '

    def is_linebreak(self):
        return True

    def space_upto_nl(self):
        return (0, True)

    def flat(self):
        return to_format(self.space)


class StringFormatObject(FormatObject):
    def __init__(self, string):
        self.string = string
        self.size: int | None = None

    def is_string(self):
        return True

    def space_upto_nl(self):
        return (self.size if self.size is not None else len(self.string), False)


def fits(f, space_left):
    s, _nl = f.space_upto_nl()
    return s <= space_left


def to_format(arg, size=None):
    if isinstance(arg, FormatObject):
        return arg
    r = StringFormatObject(str(arg))
    if size is not None:
        r.size = size
    return r


def compose(*args):
    if len(args) == 1 and isinstance(args[0], (list, tuple)):
        args = args[0]
    return ComposeFormatObject(args)


def indent(i, arg):
    return IndentFormatObject(i, arg)


def group(arg):
    return ChoiceFormatObject([arg.flat(), arg])


def line_break():
    return LineBreakFormatObject()


def _len(a):
    if isinstance(a, StringFormatObject):
        return a.size if a.size is not None else len(a.string)
    return len(a)


def seq(args, sep=',', space=True):
    nl = line_break()
    if not space:
        nl.space = ''
    r = []
    num = len(args)
    if num > 0:
        r.append(args[0])
        for i in range(num - 1):
            r.append(to_format(sep))
            r.append(nl)
            r.append(args[i + 1])
    return compose(r)


def seq1(header, args, lp='(', rp=')'):
    return group(
        compose(
            to_format(header),
            to_format(lp),
            indent(len(lp) + _len(header), seq(args)),
            to_format(rp),
        )
    )


def seq3(args, lp='(', rp=')'):
    if len(args) == 0:
        return compose(to_format(lp), to_format(rp))
    return group(indent(len(lp), compose(to_format(lp), seq(args), to_format(rp))))


class StopPPException(Exception):
    pass


class PP:
    def __init__(self):
        self.max_lines = 200
        self.max_width = 60
        self.bounded = False
        self.max_indent = 40

    def pp_string(self, f, indent):
        if not self.bounded or self.pos <= self.max_width:
            sz = _len(f)
            if self.bounded and self.pos + sz > self.max_width:
                self.out.write(_ellipses)
            else:
                self.pos = self.pos + sz
                self.ribbon_pos = self.ribbon_pos + sz
                self.out.write(f.string)

    def pp_compose(self, f, indent):
        for c in f.children:
            self.pp(c, indent)

    def pp_choice(self, f, indent):
        space_left = self.max_width - self.pos
        if space_left > 0 and fits(f.children[0], space_left):
            self.pp(f.children[0], indent)
        else:
            self.pp(f.children[1], indent)

    def pp_line_break(self, f, indent):
        self.pos = indent
        self.ribbon_pos = 0
        self.line = self.line + 1
        if self.line < self.max_lines:
            self.out.write('\n')
            for _i in range(indent):
                self.out.write(' ')
        else:
            self.out.write('\n...')
            raise StopPPException()

    def pp(self, f, indent):
        if isinstance(f, str):
            self.pp_string(f, indent)
        elif f.is_string():
            self.pp_string(f, indent)
        elif f.is_indent():
            self.pp(f.child, min(indent + f.indent, self.max_indent))
        elif f.is_compose():
            self.pp_compose(f, indent)
        elif f.is_choice():
            self.pp_choice(f, indent)
        elif f.is_linebreak():
            self.pp_line_break(f, indent)

    def __call__(self, out, f):
        try:
            self.pos = 0
            self.ribbon_pos = 0
            self.line = 0
            self.out = out
            self.pp(f, 0)
        except StopPPException:
            return


class Formatter:
    def __init__(self):
        self.max_depth = 20
        self.max_args = 128
        self.ellipses = to_format(_ellipses)
        self.max_visited = 10000
        self.fpa_pretty = True

    def pp_sort(self, s):
        if isinstance(s, bw.ArraySortRef):
            return seq1('Array', (self.pp_sort(s.domain()), self.pp_sort(s.range())))
        elif isinstance(s, bw.BitVecSortRef):
            return seq1('BitVec', (to_format(s.size()),))
        elif isinstance(s, bw.FPSortRef):
            return seq1('FPSort', (to_format(s.ebits()), to_format(s.sbits())))
        else:
            return to_format(s.name())

    def pp_const(self, a):
        return to_format(_op_name(a))

    def pp_bv(self, a):
        return to_format(a.as_string())

    def pp_bool(self, a):
        if a.ast.is_true():
            return to_format('True')
        return to_format('False')

    def pp_fprm_value(self, a):
        ast_str = str(a.ast)
        if self.fpa_pretty:
            return to_format(_bw_fp_rm_short_strings.get(ast_str, ast_str))
        return to_format(_bw_fp_rm_long_strings.get(ast_str, ast_str))

    def pp_fp_value(self, a):
        if not self.fpa_pretty:
            r = []
            if a.isNaN():
                r.append(to_format('fpNaN('))
                r.append(to_format(a.sort()))
                r.append(to_format(')'))
                return compose(r)
            elif a.isInf():
                if a.isNegative():
                    r.append(to_format('fpMinusInfinity('))
                else:
                    r.append(to_format('fpPlusInfinity('))
                r.append(to_format(a.sort()))
                r.append(to_format(')'))
                return compose(r)
            elif a.isZero():
                if a.isNegative():
                    return to_format('-zero')
                return to_format('+zero')
            else:
                return to_format(str(a.ast))
        else:
            if a.isNaN():
                return to_format('NaN')
            elif a.isInf():
                if a.isNegative():
                    return to_format('-oo')
                return to_format('+oo')
            elif a.isZero():
                if a.isNegative():
                    return to_format('-0.0')
                return to_format('+0.0')
            else:
                return to_format(str(a.ast))

    def pp_fp(self, a, d, xs):
        k = a.kind()
        op = '?'
        if self.fpa_pretty and k in _bw_kind_to_fp_pretty_str:
            op = _bw_kind_to_fp_pretty_str[k]
        elif k in _bw_kind_to_fp_normal_str:
            op = _bw_kind_to_fp_normal_str[k]
        elif k in _bw_kinds_to_str:
            op = _bw_kinds_to_str[k]

        n = a.num_args()

        if self.fpa_pretty:
            if _is_infix(k) and n >= 3:
                rm = a.arg(0)
                if bw.is_fprm_value(rm) and bw.get_default_rounding_mode(a.ctx).eq(rm):
                    arg1 = to_format(self.pp_expr(a.arg(1), d + 1, xs))
                    arg2 = to_format(self.pp_expr(a.arg(2), d + 1, xs))
                    r = []
                    r.append(arg1)
                    r.append(to_format(' '))
                    r.append(to_format(op))
                    r.append(to_format(' '))
                    r.append(arg2)
                    return compose(r)
            elif k == Kind.FP_NEG:
                return compose(
                    [to_format('-'), to_format(self.pp_expr(a.arg(0), d + 1, xs))]
                )

        if k in _bw_kind_to_fp_normal_str:
            op = _bw_kind_to_fp_normal_str[k]

        r = []
        r.append(to_format(op))
        if not bw.is_const(a):
            r.append(to_format('('))
            first = True
            for c in a.children():
                if first:
                    first = False
                else:
                    r.append(to_format(', '))
                r.append(self.pp_expr(c, d + 1, xs))
            r.append(to_format(')'))
            return compose(r)
        return to_format(a.as_string())

    def pp_prefix(self, a, d, xs):
        r = []
        sz = 0
        for child in a.children():
            r.append(self.pp_expr(child, d + 1, xs))
            sz = sz + 1
            if sz > self.max_args:
                r.append(self.ellipses)
                break
        return seq1(to_format(_op_name(a)), r)

    def is_infix(self, a):
        return _is_infix(a)

    def is_unary(self, a):
        return _is_unary(a)

    def get_precedence(self, a):
        return _get_precedence(a)

    def is_infix_compact(self, a):
        return _is_infix_compact(a)

    def is_infix_unary(self, a):
        return self.is_infix(a) or self.is_unary(a)

    def add_paren(self, a):
        return compose(to_format('('), indent(1, a), to_format(')'))

    def infix_args_core(self, a, d, xs, r):
        sz = len(r)
        k = a.kind()
        p = self.get_precedence(k)
        first = True
        for child in a.children():
            child_pp = self.pp_expr(child, d + 1, xs)
            child_k = None
            if bw.is_app(child):
                child_k = child.kind()
            if k == child_k and (_is_assoc(k) or (first and _is_left_assoc(k))):
                self.infix_args_core(child, d, xs, r)
                sz = len(r)
                if sz > self.max_args:
                    return
            elif self.is_infix_unary(child_k):
                child_p = self.get_precedence(child_k)
                if (
                    p > child_p
                    or (_is_add(k) and _is_sub(child_k))
                    or (_is_sub(k) and first and _is_add(child_k))
                ):
                    r.append(child_pp)
                else:
                    r.append(self.add_paren(child_pp))
                sz = sz + 1
            else:
                r.append(child_pp)
                sz = sz + 1
            if sz > self.max_args:
                r.append(self.ellipses)
                return
            first = False

    def infix_args(self, a, d, xs):
        r = []
        self.infix_args_core(a, d, xs, r)
        return r

    def pp_infix(self, a, d, xs):
        k = a.kind()
        if self.is_infix_compact(k):
            op = to_format(_op_name(a))
            return group(seq(self.infix_args(a, d, xs), op, False))
        else:
            op = to_format(_op_name(a))
            sz = _len(op)
            op.string = ' ' + op.string
            op.size = sz + 1
            return group(seq(self.infix_args(a, d, xs), op))

    def pp_unary(self, a, d, xs):
        k = a.kind()
        p = self.get_precedence(k)
        child = a.children()[0]
        child_k = None
        if bw.is_app(child):
            child_k = child.kind()
        child_pp = self.pp_expr(child, d + 1, xs)
        if k != child_k and self.is_infix_unary(child_k):
            child_p = self.get_precedence(child_k)
            if p <= child_p:
                child_pp = self.add_paren(child_pp)
        name = to_format(_op_name(a))
        return compose(name, indent(_len(name), child_pp))

    def pp_distinct(self, a, d, xs):
        if a.num_args() == 2:
            op = to_format('!=')
            sz = _len(op)
            op.string = ' ' + op.string
            op.size = sz + 1
            return group(seq(self.infix_args(a, d, xs), op))
        return self.pp_prefix(a, d, xs)

    def pp_select(self, a, d, xs):
        if a.num_args() != 2:
            return self.pp_prefix(a, d, xs)
        arg1_pp = self.pp_expr(a.arg(0), d + 1, xs)
        arg2_pp = self.pp_expr(a.arg(1), d + 1, xs)
        return compose(
            arg1_pp, indent(2, compose(to_format('['), arg2_pp, to_format(']')))
        )

    def pp_K(self, a, d, xs):
        return seq1(
            to_format(_op_name(a)),
            [self.pp_sort(a.sort().domain()), self.pp_expr(a.arg(0), d + 1, xs)],
        )

    def pp_extract(self, a, d, xs):
        indices = a.ast.indices()
        arg = self.pp_expr(a.arg(0), d + 1, xs)
        return seq1(
            to_format('Extract'), [to_format(indices[0]), to_format(indices[1]), arg]
        )

    def pp_indexed_unary(self, a, d, xs, param_on_right):
        indices = a.ast.indices()
        p = indices[0]
        arg = self.pp_expr(a.arg(0), d + 1, xs)
        if param_on_right:
            return seq1(to_format(_op_name(a)), [arg, to_format(p)])
        return seq1(to_format(_op_name(a)), [to_format(p), arg])

    def pp_quantifier(self, a, d, xs):
        ys = [to_format(a.var_name(i)) for i in range(a.num_vars())]
        new_xs = xs + ys
        body_pp = self.pp_expr(a.body(), d + 1, new_xs)
        if len(ys) == 1:
            ys_pp = ys[0]
        else:
            ys_pp = seq3(ys, '[', ']')
        if a.is_forall():
            header = 'ForAll'
        elif a.is_exists():
            header = 'Exists'
        else:
            header = 'Lambda'
        return seq1(header, (ys_pp, body_pp))

    def pp_uf_apply(self, a, d, xs):
        r = []
        sz = 0
        # For APPLY, children() already skips the function (index 0)
        func_decl = a.decl()
        for child in a.children():
            r.append(self.pp_expr(child, d + 1, xs))
            sz = sz + 1
            if sz > self.max_args:
                r.append(self.ellipses)
                break
        return seq1(to_format(func_decl.name()), r)

    def pp_app(self, a, d, xs):
        if bw.is_bool_value(a):
            return self.pp_bool(a)
        elif bw.is_bv_value(a):
            return self.pp_bv(a)
        elif bw.is_fprm_value(a):
            return self.pp_fprm_value(a)
        elif bw.is_fp_value(a):
            return self.pp_fp_value(a)
        elif bw.is_fp(a):
            return self.pp_fp(a, d, xs)
        elif bw.is_const(a):
            return self.pp_const(a)
        else:
            k = a.kind()
            if k == Kind.DISTINCT:
                return self.pp_distinct(a, d, xs)
            elif k == Kind.ARRAY_SELECT:
                return self.pp_select(a, d, xs)
            elif k in (Kind.BV_SIGN_EXTEND, Kind.BV_ZERO_EXTEND, Kind.BV_REPEAT):
                return self.pp_indexed_unary(a, d, xs, False)
            elif k in (Kind.BV_ROLI, Kind.BV_RORI):
                return self.pp_indexed_unary(a, d, xs, True)
            elif k == Kind.BV_EXTRACT:
                return self.pp_extract(a, d, xs)
            elif k == Kind.CONST_ARRAY:
                return self.pp_K(a, d, xs)
            elif k in (Kind.CONSTANT, Kind.VALUE, Kind.VARIABLE):
                return to_format(_op_name(a))
            elif self.is_infix(k):
                return self.pp_infix(a, d, xs)
            elif self.is_unary(k):
                return self.pp_unary(a, d, xs)
            elif k == Kind.APPLY:
                return self.pp_uf_apply(a, d, xs)
            else:
                return self.pp_prefix(a, d, xs)

    def pp_expr(self, a, d, xs):
        self.visited = self.visited + 1
        if d > self.max_depth or self.visited > self.max_visited:
            return self.ellipses
        if bw.is_quantifier(a):
            return self.pp_quantifier(a, d, xs)
        elif bw.is_app(a):
            return self.pp_app(a, d, xs)
        return to_format('<unknown>')

    def pp_seq(self, a, d, xs):
        self.visited = self.visited + 1
        if d > self.max_depth or self.visited > self.max_visited:
            return self.ellipses
        r = []
        sz = 0
        for elem in a:
            r.append(self.pp_expr(elem, d + 1, xs))
            sz = sz + 1
            if sz > self.max_args:
                r.append(self.ellipses)
                break
        return seq3(r, '[', ']')

    def pp_list(self, a):
        r = []
        sz = 0
        for elem in a:
            if isinstance(elem, (bw.ExprRef, bw.SortRef)):
                r.append(self.main(elem))
            else:
                r.append(to_format(str(elem)))
            sz = sz + 1
            if sz > self.max_args:
                r.append(self.ellipses)
                break
        if isinstance(a, tuple):
            return seq3(r)
        return seq3(r, '[', ']')

    def main(self, a):
        if bw.is_expr(a):
            return self.pp_expr(a, 0, [])
        elif bw.is_sort(a):
            return self.pp_sort(a)
        elif isinstance(a, bw.Solver):
            return self.pp_seq(a.assertions(), 0, [])
        elif isinstance(a, bw.ModelRef):
            return self.pp_model(a)
        elif isinstance(a, (list, tuple)):
            return self.pp_list(a)
        return to_format('<unknown>')

    def pp_model(self, m):
        r = []
        sz = 0
        for d_expr in m.decls():
            i = m[d_expr]
            i_pp = self.pp_expr(i, 0, [])
            name = self.pp_expr(d_expr, 0, [])
            r.append(compose(name, to_format(' = '), indent(_len(name) + 3, i_pp)))
            sz = sz + 1
            if sz > self.max_args:
                r.append(self.ellipses)
                break
        return seq3(r, '[', ']')

    def __call__(self, a):
        self.visited = 0
        return self.main(a)


_PP = PP()
_Formatter = Formatter()


def obj_to_string(a):
    out = io.StringIO()
    _PP(out, _Formatter(a))
    return out.getvalue()


def set_fpa_pretty(flag=True):
    global _fpa_pretty
    _Formatter.fpa_pretty = flag
    _fpa_pretty = flag


set_fpa_pretty(True)


def get_fpa_pretty():
    return _Formatter.fpa_pretty
