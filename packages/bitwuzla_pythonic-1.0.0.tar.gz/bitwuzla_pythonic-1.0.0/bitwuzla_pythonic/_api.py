from __future__ import annotations

import functools as ft
import itertools
import math
from typing import Any, Sequence, Union

import bitwuzla as _bitwuzla
from bitwuzla import Kind, Option, Result, RoundingMode

from ._printer import get_fpa_pretty, obj_to_string, set_fpa_pretty

# Native bitwuzla types are from a C extension and have no stubs.
# We alias them to Any for type annotations.
_Term = Any
_Sort = Any
_TermManager = Any
_Bitwuzla = Any
_Options = Any

# Type alias for things coercible to an expression
_Coercible = Union['ExprRef', int, float, bool]


class SMTException(Exception):
    def __init__(self, value: str) -> None:
        self.value = value

    def __str__(self) -> str:
        return str(self.value)


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise SMTException(msg)


def _is_int(v: object) -> bool:
    return isinstance(v, int)


def _get_args(args: tuple[Any, ...] | list[Any]) -> list[Any]:
    """Flatten a single list/tuple argument."""
    if len(args) == 1 and isinstance(args[0], (list, tuple)):
        return list(args[0])
    return list(args)


class Context:
    """Wraps a bitwuzla TermManager. Provides variable caching and fresh name
    generation, matching the z3py/cvc5_pythonic global-context pattern."""

    def __init__(self) -> None:
        self.tm: _TermManager = _bitwuzla.TermManager()
        self.vars: dict[tuple[str, _Sort], _Term] = {}
        self.next_fresh_var: int = 0

    def get_var(self, name: str, sort: SortRef) -> _Term:
        key = (name, sort.ast)
        if key not in self.vars:
            self.vars[key] = self.tm.mk_const(sort.ast, name)
        return self.vars[key]

    def next_fresh(self, sort: SortRef, prefix: str) -> str:
        name = f'{prefix}{self.next_fresh_var}'
        while (name, sort.ast) in self.vars:
            self.next_fresh_var += 1
            name = f'{prefix}{self.next_fresh_var}'
        return name

    def __eq__(self, o: object) -> bool:
        return isinstance(o, Context) and self.tm is o.tm


_main_ctx: Context | None = None


def main_ctx() -> Context:
    """Return a reference to the global context."""
    global _main_ctx
    if _main_ctx is None:
        _main_ctx = Context()
    return _main_ctx


def _get_ctx(ctx: Context | None) -> Context:
    if ctx is None:
        return main_ctx()
    return ctx


def get_ctx(ctx: Context | None) -> Context:
    """Return *ctx* if not None, otherwise the default context."""
    return _get_ctx(ctx)


def _ctx_from_ast_arg_list(
    args: Sequence[Any], default_ctx: Context | None = None
) -> Context | None:
    for a in args:
        if is_expr(a):
            return a.ctx
        if is_sort(a):
            return a.ctx
    return default_ctx


class SortRef:
    """A Sort is essentially a type. Every term has a sort."""

    def __init__(self, ast: _Sort, ctx: Context | None = None) -> None:
        self.ast: _Sort = ast
        self.ctx: Context = _get_ctx(ctx)

    def __str__(self) -> str:
        return obj_to_string(self)

    def __repr__(self) -> str:
        return obj_to_string(self)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SortRef):
            return NotImplemented
        return self.ast == other.ast

    def __ne__(self, other: object) -> bool:
        if not isinstance(other, SortRef):
            return NotImplemented
        return self.ast != other.ast

    def __hash__(self) -> int:
        return hash(self.ast)

    def sexpr(self) -> str:
        return str(self.ast)

    def as_ast(self) -> _Sort:
        return self.ast

    def eq(self, other: SortRef) -> bool:
        """Structural equality."""
        return isinstance(other, SortRef) and self.ast == other.ast

    def name(self) -> str:
        return str(self.ast)

    def subsort(self, other: SortRef) -> bool:
        return False

    def cast(self, val: _Coercible) -> ExprRef:
        if isinstance(val, ExprRef):
            _assert(self.eq(val.sort()), 'Sort mismatch')
            return val
        raise SMTException('Cannot cast value to sort')


class BoolSortRef(SortRef):
    """Boolean sort."""

    def cast(self, val: _Coercible) -> ExprRef:
        if isinstance(val, ExprRef):
            if isinstance(val, BoolRef):
                return val
            _assert(False, 'Sort mismatch: expected Bool')
        if isinstance(val, bool):
            return BoolVal(val, self.ctx)
        _assert(False, 'Cannot cast to Bool')
        raise SMTException('Cannot cast to Bool')  # unreachable, for type checker

    def subsort(self, other: SortRef) -> bool:
        return False

    def is_bool(self) -> bool:
        return True


class BitVecSortRef(SortRef):
    """Bit-vector sort."""

    def size(self) -> int:
        return self.ast.bv_size()

    def subsort(self, other: SortRef) -> bool:
        return isinstance(other, BitVecSortRef) and self.size() < other.size()

    def cast(self, val: _Coercible) -> ExprRef:
        if isinstance(val, ExprRef):
            return val
        if isinstance(val, (int, str)):
            return BitVecVal(val, self)
        raise SMTException('Cannot cast to BitVec')


class FPSortRef(SortRef):
    """Floating-point sort."""

    def ebits(self) -> int:
        return self.ast.fp_exp_size()

    def sbits(self) -> int:
        return self.ast.fp_sig_size()

    def cast(self, val: _Coercible) -> ExprRef:
        if isinstance(val, ExprRef):
            return val
        if isinstance(val, (int, float, str)):
            return FPVal(val, None, self, self.ctx)
        raise SMTException('Cannot cast to FP')


class FPRMSortRef(SortRef):
    """Floating-point rounding mode sort."""


class ArraySortRef(SortRef):
    """Array sort."""

    def domain(self) -> SortRef:
        return _to_sort_ref(self.ast.array_index(), self.ctx)

    def range(self) -> SortRef:
        return _to_sort_ref(self.ast.array_element(), self.ctx)


def _to_sort_ref(s: _Sort, ctx: Context) -> SortRef:
    """Dispatch a native Sort to the correct SortRef subclass."""
    if s.is_bool():
        return BoolSortRef(s, ctx)
    if s.is_bv():
        return BitVecSortRef(s, ctx)
    if s.is_fp():
        return FPSortRef(s, ctx)
    if s.is_rm():
        return FPRMSortRef(s, ctx)
    if s.is_array():
        return ArraySortRef(s, ctx)
    return SortRef(s, ctx)


def _sort(ctx: Context, a: _Term) -> SortRef:
    """Return the SortRef for a native Term."""
    return _to_sort_ref(a.sort(), ctx)


def is_sort(s: object) -> bool:
    return isinstance(s, SortRef)


def is_bv_sort(s: object) -> bool:
    return isinstance(s, BitVecSortRef)


def is_fp_sort(s: object) -> bool:
    return isinstance(s, FPSortRef)


def is_fprm_sort(s: object) -> bool:
    return isinstance(s, FPRMSortRef)


def is_array_sort(s: object) -> bool:
    return isinstance(s, ArraySortRef)


class ExprRef:
    """Constraints, formulas and terms are expressions."""

    def __init__(
        self,
        ast: _Term,
        ctx: Context | None = None,
        reverse_children: bool = False,
    ) -> None:
        self.ast: _Term = ast
        self.ctx: Context = _get_ctx(ctx)
        self.reverse_children: bool = reverse_children

    def __str__(self) -> str:
        return obj_to_string(self)

    def __repr__(self) -> str:
        return obj_to_string(self)

    def __nonzero__(self) -> bool:
        return self.__bool__()

    def __bool__(self) -> bool:
        if is_true(self):
            return True
        elif is_false(self):
            return False
        elif is_eq(self) and self.num_args() == 2:
            return self.arg(0).eq(self.arg(1))
        else:
            raise SMTException(
                'Symbolic expressions cannot be cast to concrete Boolean values.'
            )

    def sexpr(self) -> str:
        return str(self.ast)

    def as_ast(self) -> _Term:
        return self.ast

    def get_id(self) -> int:
        return self.ast.id()

    def eq(self, other: ExprRef) -> bool:
        """Structural equality (Python bool)."""
        if not isinstance(other, ExprRef):
            return False
        return self.ctx == other.ctx and self.ast == other.ast

    def hash(self) -> int:
        return hash(self.ast)

    def sort(self) -> SortRef:
        return _sort(self.ctx, self.ast)

    def __eq__(self, other: object) -> BoolRef | bool:  # ty: ignore[invalid-method-override]
        if other is None:
            return False
        if not isinstance(other, (ExprRef, int, float, bool)):
            return NotImplemented
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.EQUAL, [a.ast, b.ast]), self.ctx)

    def __hash__(self) -> int:
        return hash(self.ast)

    def __ne__(self, other: object) -> BoolRef | bool:  # ty: ignore[invalid-method-override]
        if other is None:
            return True
        if not isinstance(other, (ExprRef, int, float, bool)):
            return NotImplemented
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.DISTINCT, [a.ast, b.ast]), self.ctx)

    def kind(self) -> Kind:
        return self.ast.kind()

    def num_args(self) -> int:
        if is_app_of(self, Kind.APPLY):
            return self.ast.num_children() - 1
        return self.ast.num_children()

    def arg(self, idx: int) -> ExprRef:
        if is_app_of(self, Kind.APPLY):
            return _to_expr_ref(self.ast[idx + 1], self.ctx)
        if self.reverse_children:
            return _to_expr_ref(self.ast[self.ast.num_children() - (idx + 1)], self.ctx)
        return _to_expr_ref(self.ast[idx], self.ctx)

    def children(self) -> list[ExprRef]:
        if is_app_of(self, Kind.APPLY):
            return [
                _to_expr_ref(self.ast[i], self.ctx)
                for i in range(1, self.ast.num_children())
            ]
        cs = [self.ast[i] for i in range(self.ast.num_children())]
        if self.reverse_children:
            cs = list(reversed(cs))
        return [_to_expr_ref(c, self.ctx) for c in cs]

    def decl(self) -> ExprRef:
        if is_app_of(self, Kind.APPLY):
            return _to_expr_ref(self.ast[0], self.ctx)
        raise SMTException('Declarations for non-function applications')


def _to_expr_ref(a: _Term | ExprRef, ctx: Context) -> ExprRef:
    """Dispatch a native Term (or ExprRef) to the correct ExprRef subclass."""
    if isinstance(a, ExprRef):
        ast = a.ast
    elif isinstance(a, _bitwuzla.Term):
        ast = a
    else:
        raise SMTException('Non-term given to _to_expr_ref')

    k = ast.kind()
    if k in (Kind.FORALL, Kind.EXISTS, Kind.LAMBDA):
        return QuantifierRef(ast, ctx)

    s = ast.sort()
    if s.is_bool():
        return BoolRef(ast, ctx)
    if s.is_bv():
        if ast.is_value():
            return BitVecNumRef(ast, ctx)
        return BitVecRef(ast, ctx)
    if s.is_fp():
        if ast.is_value():
            return FPNumRef(ast, ctx)
        return FPRef(ast, ctx)
    if s.is_rm():
        return FPRMRef(ast, ctx)
    if s.is_array():
        return ArrayRef(ast, ctx)
    if s.is_fun():
        return FuncDeclRef(ast, ctx)
    return ExprRef(ast, ctx)


def _coerce_expr_merge(s: SortRef | None, a: _Coercible) -> SortRef | None:
    if isinstance(a, ExprRef):
        s1 = a.sort()
        if s is None:
            return s1
        if s1.eq(s):
            return s
        if s.subsort(s1):
            return s1
        if s1.subsort(s):
            return s
        _assert(False, 'sort mismatch')
    return s


def _py2expr(v: _Coercible, ctx: Context | None = None) -> ExprRef:
    """Convert a Python value to an ExprRef."""
    ctx = _get_ctx(ctx)
    if isinstance(v, bool):
        return BoolVal(v, ctx)
    if isinstance(v, int):
        raise SMTException(
            'Cannot convert Python int to SMT expression without sort context. '
            'Use BitVecVal(val, width) explicitly.'
        )
    if isinstance(v, float):
        raise SMTException(
            'Cannot convert Python float to SMT expression without sort context. '
            'Use FPVal(val, sort) explicitly.'
        )
    raise SMTException('Python bool, int, or float expected')


def _coerce_exprs(
    a: _Coercible, b: _Coercible, ctx: Context | None = None
) -> tuple[ExprRef, ExprRef]:
    if not is_expr(a) and not is_expr(b):
        a = _py2expr(a, ctx)
        b = _py2expr(b, ctx)
    s: SortRef | None = None
    s = _coerce_expr_merge(s, a)
    s = _coerce_expr_merge(s, b)
    if s is not None:
        a = s.cast(a)
        b = s.cast(b)
    assert isinstance(a, ExprRef) and isinstance(b, ExprRef)
    return (a, b)


def _coerce_expr_list(
    alist: list[_Coercible], ctx: Context | None = None
) -> list[ExprRef]:
    assert len(alist) > 0
    has_expr = any(is_expr(a) for a in alist)
    if not has_expr:
        alist = [_py2expr(a, ctx) for a in alist]
    s = ft.reduce(_coerce_expr_merge, alist, None)
    assert s is not None
    return [s.cast(a) for a in alist]


def is_expr(a: object) -> bool:
    return isinstance(a, ExprRef)


def is_app(a: object) -> bool:
    return isinstance(a, ExprRef) and a.ast is not None


def is_const(a: object) -> bool:
    return isinstance(a, ExprRef) and a.ast.kind() == Kind.CONSTANT


def is_var(a: object) -> bool:
    return isinstance(a, ExprRef) and a.ast.kind() == Kind.VARIABLE


def is_app_of(a: object, k: Kind) -> bool:
    return isinstance(a, ExprRef) and a.ast is not None and a.ast.kind() == k


def is_ast(a: object) -> bool:
    return isinstance(a, (ExprRef, SortRef))


def eq(a: ExprRef | SortRef, b: ExprRef | SortRef) -> bool:
    """Structural equality (Python bool)."""
    if isinstance(a, ExprRef) and isinstance(b, ExprRef):
        return a.eq(b)
    if isinstance(a, SortRef) and isinstance(b, SortRef):
        return a.eq(b)
    return False


def is_func_decl(a: object) -> bool:
    return isinstance(a, FuncDeclRef)


def Const(name: str, sort: SortRef, ctx: Context | None = None) -> ExprRef:
    ctx = _get_ctx(ctx)
    return _to_expr_ref(ctx.get_var(name, sort), ctx)


def Consts(
    names: str | Sequence[str], sort: SortRef, ctx: Context | None = None
) -> list[ExprRef]:
    ctx = _get_ctx(ctx)
    if isinstance(names, str):
        names = names.split()
    return [Const(name, sort, ctx) for name in names]


def FreshConst(sort: SortRef, prefix: str = 'c', ctx: Context | None = None) -> ExprRef:
    ctx = _get_ctx(ctx)
    name = ctx.next_fresh(sort, prefix)
    return Const(name, sort, ctx)


def BoolSort(ctx: Context | None = None) -> BoolSortRef:
    ctx = _get_ctx(ctx)
    return BoolSortRef(ctx.tm.mk_bool_sort(), ctx)


def BoolVal(val: bool, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx)
    if val:
        return BoolRef(ctx.tm.mk_true(), ctx)
    return BoolRef(ctx.tm.mk_false(), ctx)


def Bool(name: str, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx)
    return BoolRef(ctx.get_var(name, BoolSort(ctx)), ctx)


def Bools(names: str | Sequence[str], ctx: Context | None = None) -> list[BoolRef]:
    ctx = _get_ctx(ctx)
    if isinstance(names, str):
        names = names.split()
    return [Bool(name, ctx) for name in names]


def BoolVector(prefix: str, sz: int, ctx: Context | None = None) -> list[BoolRef]:
    ctx = _get_ctx(ctx)
    return [Bool(f'{prefix}__{i}', ctx) for i in range(sz)]


def FreshBool(prefix: str = 'b', ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx)
    s = BoolSort(ctx)
    name = ctx.next_fresh(s, prefix)
    return Bool(name, ctx)


class BoolRef(ExprRef):
    """Boolean expressions."""

    def sort(self) -> BoolSortRef:
        return BoolSortRef(self.ast.sort(), self.ctx)

    def __and__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.AND, [a.ast, b.ast]), self.ctx)

    def __rand__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.AND, [b.ast, a.ast]), self.ctx)

    def __or__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.OR, [a.ast, b.ast]), self.ctx)

    def __ror__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.OR, [b.ast, a.ast]), self.ctx)

    def __xor__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.XOR, [a.ast, b.ast]), self.ctx)

    def __rxor__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other)
        return BoolRef(self.ctx.tm.mk_term(Kind.XOR, [b.ast, a.ast]), self.ctx)

    def __invert__(self) -> BoolRef:
        return BoolRef(self.ctx.tm.mk_term(Kind.NOT, [self.ast]), self.ctx)


def is_bool(a: object) -> bool:
    return isinstance(a, BoolRef)


def is_true(a: object) -> bool:
    return isinstance(a, BoolRef) and a.ast.is_true()


def is_false(a: object) -> bool:
    return isinstance(a, BoolRef) and a.ast.is_false()


def is_bool_value(a: object) -> bool:
    return is_true(a) or is_false(a)


def is_and(a: object) -> bool:
    return is_app_of(a, Kind.AND)


def is_or(a: object) -> bool:
    return is_app_of(a, Kind.OR)


def is_not(a: object) -> bool:
    return is_app_of(a, Kind.NOT)


def is_implies(a: object) -> bool:
    return is_app_of(a, Kind.IMPLIES)


def is_xor(a: object) -> bool:
    return is_app_of(a, Kind.XOR)


def is_eq(a: object) -> bool:
    return is_app_of(a, Kind.EQUAL) or is_app_of(a, Kind.IFF)


def is_distinct(a: object) -> bool:
    return is_app_of(a, Kind.DISTINCT)


def And(*args: _Coercible | list[_Coercible] | Context) -> ExprRef:
    """N-ary And."""
    last = args[-1] if args else None
    if isinstance(last, Context):
        ctx: Context | None = last
        args = args[:-1]
    else:
        ctx = None
    args_list = _get_args(args)
    ctx = _get_ctx(_ctx_from_ast_arg_list(args_list, ctx))
    args_list = _coerce_expr_list(args_list, ctx)
    if len(args_list) == 1:
        return args_list[0]
    return BoolRef(ctx.tm.mk_term(Kind.AND, [a.ast for a in args_list]), ctx)


def Or(*args: _Coercible | list[_Coercible] | Context) -> ExprRef:
    """N-ary Or."""
    last = args[-1] if args else None
    if isinstance(last, Context):
        ctx: Context | None = last
        args = args[:-1]
    else:
        ctx = None
    args_list = _get_args(args)
    ctx = _get_ctx(_ctx_from_ast_arg_list(args_list, ctx))
    args_list = _coerce_expr_list(args_list, ctx)
    if len(args_list) == 1:
        return args_list[0]
    return BoolRef(ctx.tm.mk_term(Kind.OR, [a.ast for a in args_list]), ctx)


def Not(a: BoolRef, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx)
    _assert(is_bool(a), 'Boolean expression expected')
    return BoolRef(ctx.tm.mk_term(Kind.NOT, [a.ast]), ctx)


def mk_not(a: BoolRef) -> BoolRef:
    """Smart negation — eliminates double negation."""
    if is_not(a):
        inner = a.arg(0)
        assert isinstance(inner, BoolRef)
        return inner
    return Not(a)


def Xor(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx)
    a, b = _coerce_exprs(a, b)
    return BoolRef(ctx.tm.mk_term(Kind.XOR, [a.ast, b.ast]), ctx)


def Implies(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx)
    a, b = _coerce_exprs(a, b)
    return BoolRef(ctx.tm.mk_term(Kind.IMPLIES, [a.ast, b.ast]), ctx)


def Iff(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx)
    a, b = _coerce_exprs(a, b)
    return BoolRef(ctx.tm.mk_term(Kind.IFF, [a.ast, b.ast]), ctx)


def If(
    a: BoolRef | bool, b: _Coercible, c: _Coercible, ctx: Context | None = None
) -> ExprRef:
    ctx = _get_ctx(ctx)
    _assert(is_bool(a) or isinstance(a, bool), 'Boolean expression expected')
    if isinstance(a, bool):
        a = BoolVal(a, ctx)
    b, c = _coerce_exprs(b, c)
    return _to_expr_ref(ctx.tm.mk_term(Kind.ITE, [a.ast, b.ast, c.ast]), ctx)


def Distinct(*args: _Coercible | list[_Coercible]) -> BoolRef:
    args_list = _get_args(args)
    ctx = _get_ctx(_ctx_from_ast_arg_list(args_list))
    args_list = _coerce_expr_list(args_list, ctx)
    return BoolRef(ctx.tm.mk_term(Kind.DISTINCT, [a.ast for a in args_list]), ctx)


def BitVecSort(sz: int, ctx: Context | None = None) -> BitVecSortRef:
    ctx = _get_ctx(ctx)
    return BitVecSortRef(ctx.tm.mk_bv_sort(sz), ctx)


def BitVecVal(
    val: int | str, bv: BitVecSortRef | int, ctx: Context | None = None
) -> BitVecNumRef:
    if isinstance(bv, BitVecSortRef):
        ctx = _get_ctx(ctx) if ctx else bv.ctx
        sz = bv.size()
    else:
        ctx = _get_ctx(ctx)
        sz = bv
    sort = ctx.tm.mk_bv_sort(sz)
    if isinstance(val, str):
        if val.startswith(('0x', '0X')):
            return BitVecNumRef(ctx.tm.mk_bv_value(sort, val[2:], 16), ctx)
        if val.startswith(('0b', '0B')):
            return BitVecNumRef(ctx.tm.mk_bv_value(sort, val[2:], 2), ctx)
        return BitVecNumRef(ctx.tm.mk_bv_value(sort, val, 10), ctx)
    if val < 0:
        val = val % (1 << sz)
    return BitVecNumRef(ctx.tm.mk_bv_value(sort, val), ctx)


def BitVec(name: str, bv: BitVecSortRef | int, ctx: Context | None = None) -> BitVecRef:
    if isinstance(bv, BitVecSortRef):
        ctx = _get_ctx(ctx) if ctx else bv.ctx
        s = bv
    else:
        ctx = _get_ctx(ctx)
        s = BitVecSort(bv, ctx)
    return BitVecRef(ctx.get_var(name, s), ctx)


def BitVecs(
    names: str | Sequence[str], bv: BitVecSortRef | int, ctx: Context | None = None
) -> list[BitVecRef]:
    ctx = _get_ctx(ctx)
    if isinstance(names, str):
        names = names.split()
    return [BitVec(name, bv, ctx) for name in names]


def BitVecVector(
    prefix: str, sz: int, bv: BitVecSortRef | int, ctx: Context | None = None
) -> list[BitVecRef]:
    ctx = _get_ctx(ctx)
    return [BitVec(f'{prefix}__{i}', bv, ctx) for i in range(sz)]


def FreshBitVec(
    prefix: str, bv: BitVecSortRef | int, ctx: Context | None = None
) -> BitVecRef:
    ctx = _get_ctx(ctx)
    s = BitVecSort(bv, ctx) if not isinstance(bv, BitVecSortRef) else bv
    name = ctx.next_fresh(s, prefix)
    return BitVec(name, s, ctx)


class BitVecRef(ExprRef):
    """Bit-vector expressions."""

    def sort(self) -> BitVecSortRef:
        return BitVecSortRef(self.ast.sort(), self.ctx)

    def size(self) -> int:
        return self.sort().size()

    # fmt: off
    def __add__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_ADD, [a.ast, b.ast]), self.ctx)
    def __radd__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_ADD, [b.ast, a.ast]), self.ctx)
    def __sub__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SUB, [a.ast, b.ast]), self.ctx)
    def __rsub__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SUB, [b.ast, a.ast]), self.ctx)
    def __mul__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_MUL, [a.ast, b.ast]), self.ctx)
    def __rmul__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_MUL, [b.ast, a.ast]), self.ctx)
    def __div__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SDIV, [a.ast, b.ast]), self.ctx)
    def __truediv__(self, other: _Coercible) -> BitVecRef:
        return self.__div__(other)
    def __rdiv__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SDIV, [b.ast, a.ast]), self.ctx)
    def __rtruediv__(self, other: _Coercible) -> BitVecRef:
        return self.__rdiv__(other)
    def __mod__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SMOD, [a.ast, b.ast]), self.ctx)
    def __rmod__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SMOD, [b.ast, a.ast]), self.ctx)
    def __neg__(self) -> BitVecRef:
        return BitVecRef(self.ctx.tm.mk_term(Kind.BV_NEG, [self.ast]), self.ctx)
    def __pos__(self) -> BitVecRef:
        return self
    def __invert__(self) -> BitVecRef:
        return BitVecRef(self.ctx.tm.mk_term(Kind.BV_NOT, [self.ast]), self.ctx)
    def __and__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_AND, [a.ast, b.ast]), self.ctx)
    def __rand__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_AND, [b.ast, a.ast]), self.ctx)
    def __or__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_OR, [a.ast, b.ast]), self.ctx)
    def __ror__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_OR, [b.ast, a.ast]), self.ctx)
    def __xor__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_XOR, [a.ast, b.ast]), self.ctx)
    def __rxor__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_XOR, [b.ast, a.ast]), self.ctx)
    def __lshift__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SHL, [a.ast, b.ast]), self.ctx)
    def __rlshift__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_SHL, [b.ast, a.ast]), self.ctx)
    def __rshift__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_ASHR, [a.ast, b.ast]), self.ctx)
    def __rrshift__(self, other: _Coercible) -> BitVecRef:
        a, b = _coerce_exprs(self, other); return BitVecRef(self.ctx.tm.mk_term(Kind.BV_ASHR, [b.ast, a.ast]), self.ctx)
    def __le__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other); return BoolRef(self.ctx.tm.mk_term(Kind.BV_SLE, [a.ast, b.ast]), self.ctx)
    def __lt__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other); return BoolRef(self.ctx.tm.mk_term(Kind.BV_SLT, [a.ast, b.ast]), self.ctx)
    def __ge__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other); return BoolRef(self.ctx.tm.mk_term(Kind.BV_SGE, [a.ast, b.ast]), self.ctx)
    def __gt__(self, other: _Coercible) -> BoolRef:
        a, b = _coerce_exprs(self, other); return BoolRef(self.ctx.tm.mk_term(Kind.BV_SGT, [a.ast, b.ast]), self.ctx)
    # fmt: on


class BitVecNumRef(BitVecRef):
    """Bit-vector values."""

    def as_long(self) -> int:
        return int(self.ast.value(10))

    def as_signed_long(self) -> int:
        v = self.as_long()
        sz = self.size()
        if v >= (1 << (sz - 1)):
            v -= 1 << sz
        return v

    def as_string(self) -> str:
        return str(self.as_long())

    def as_binary_string(self) -> str:
        return self.ast.value(2)


def is_bv(a: object) -> bool:
    return isinstance(a, BitVecRef)


def is_bv_value(a: object) -> bool:
    return isinstance(a, BitVecNumRef)


def _bv_bin_bool(kind: Kind, a: _Coercible, b: _Coercible) -> BoolRef:
    ca, cb = _coerce_exprs(a, b)
    return BoolRef(ca.ctx.tm.mk_term(kind, [ca.ast, cb.ast]), ca.ctx)


def _bv_bin(kind: Kind, a: _Coercible, b: _Coercible) -> BitVecRef:
    ca, cb = _coerce_exprs(a, b)
    return BitVecRef(ca.ctx.tm.mk_term(kind, [ca.ast, cb.ast]), ca.ctx)


def ULE(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_ULE, a, b)  # fmt: skip


def ULT(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_ULT, a, b)  # fmt: skip


def UGE(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_UGE, a, b)  # fmt: skip


def UGT(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_UGT, a, b)  # fmt: skip


def SLE(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SLE, a, b)  # fmt: skip


def SLT(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SLT, a, b)  # fmt: skip


def SGE(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SGE, a, b)  # fmt: skip


def SGT(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SGT, a, b)  # fmt: skip


def UDiv(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_UDIV, a, b)  # fmt: skip


def URem(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_UREM, a, b)  # fmt: skip


def SDiv(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_SDIV, a, b)  # fmt: skip


def SRem(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_SREM, a, b)  # fmt: skip


def SMod(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_SMOD, a, b)  # fmt: skip


def LShR(a: _Coercible, b: _Coercible) -> BitVecRef:
    """Logical shift right."""
    return _bv_bin(Kind.BV_SHR, a, b)


def Concat(*args: ExprRef | list[ExprRef]) -> ExprRef:
    """Concatenate bit-vectors."""
    flat = _get_args(args)
    _assert(len(flat) >= 2, 'At least two arguments required')
    ctx = flat[0].ctx
    result = flat[0].ast
    for i in range(1, len(flat)):
        result = ctx.tm.mk_term(Kind.BV_CONCAT, [result, flat[i].ast])
    return _to_expr_ref(result, ctx)


def Extract(high: int, low: int, a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected')
    return BitVecRef(a.ctx.tm.mk_term(Kind.BV_EXTRACT, [a.ast], [high, low]), a.ctx)


def SignExt(n: int, a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected')
    return BitVecRef(a.ctx.tm.mk_term(Kind.BV_SIGN_EXTEND, [a.ast], [n]), a.ctx)


def ZeroExt(n: int, a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected')
    return BitVecRef(a.ctx.tm.mk_term(Kind.BV_ZERO_EXTEND, [a.ast], [n]), a.ctx)


def RepeatBitVec(n: int, a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected')
    return BitVecRef(a.ctx.tm.mk_term(Kind.BV_REPEAT, [a.ast], [n]), a.ctx)


def RotateLeft(a: BitVecRef, b: int | BitVecRef) -> BitVecRef:
    if isinstance(b, int):
        return BitVecRef(a.ctx.tm.mk_term(Kind.BV_ROLI, [a.ast], [b]), a.ctx)
    ca, cb = _coerce_exprs(a, b)
    return BitVecRef(ca.ctx.tm.mk_term(Kind.BV_ROL, [ca.ast, cb.ast]), ca.ctx)


def RotateRight(a: BitVecRef, b: int | BitVecRef) -> BitVecRef:
    if isinstance(b, int):
        return BitVecRef(a.ctx.tm.mk_term(Kind.BV_RORI, [a.ast], [b]), a.ctx)
    ca, cb = _coerce_exprs(a, b)
    return BitVecRef(ca.ctx.tm.mk_term(Kind.BV_ROR, [ca.ast, cb.ast]), ca.ctx)


def BVRedAnd(a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected'); return BitVecRef(a.ctx.tm.mk_term(Kind.BV_REDAND, [a.ast]), a.ctx)  # fmt: skip


def BVRedOr(a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected'); return BitVecRef(a.ctx.tm.mk_term(Kind.BV_REDOR, [a.ast]), a.ctx)  # fmt: skip


def BVRedXor(a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected'); return BitVecRef(a.ctx.tm.mk_term(Kind.BV_REDXOR, [a.ast]), a.ctx)  # fmt: skip


def BVAdd(*args: _Coercible | list[_Coercible]) -> ExprRef:
    return ft.reduce(lambda a, b: a + b, _get_args(args))


def BVSub(a: BitVecRef, b: _Coercible) -> BitVecRef:
    return a - b


def BVMul(*args: _Coercible | list[_Coercible]) -> ExprRef:
    return ft.reduce(lambda a, b: a * b, _get_args(args))


def BVNeg(a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected'); return -a  # fmt: skip


def BVNot(a: BitVecRef) -> BitVecRef:
    _assert(is_bv(a), 'Bit-vector expression expected'); return ~a  # fmt: skip


def BVAnd(*args: _Coercible | list[_Coercible]) -> ExprRef:
    return ft.reduce(lambda a, b: a & b, _get_args(args))


def BVOr(*args: _Coercible | list[_Coercible]) -> ExprRef:
    return ft.reduce(lambda a, b: a | b, _get_args(args))


def BVXor(*args: _Coercible | list[_Coercible]) -> ExprRef:
    return ft.reduce(lambda a, b: a ^ b, _get_args(args))


def BVNand(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_NAND, a, b)  # fmt: skip


def BVNor(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_NOR, a, b)  # fmt: skip


def BVXnor(a: _Coercible, b: _Coercible) -> BitVecRef: return _bv_bin(Kind.BV_XNOR, a, b)  # fmt: skip


def BVSAddOverflow(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SADD_OVERFLOW, a, b)  # fmt: skip


def BVUAddOverflow(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_UADD_OVERFLOW, a, b)  # fmt: skip


def BVSSubOverflow(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SSUB_OVERFLOW, a, b)  # fmt: skip


def BVUSubOverflow(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_USUB_OVERFLOW, a, b)  # fmt: skip


def BVSMulOverflow(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SMUL_OVERFLOW, a, b)  # fmt: skip


def BVUMulOverflow(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_UMUL_OVERFLOW, a, b)  # fmt: skip


def BVSDivOverflow(a: _Coercible, b: _Coercible) -> BoolRef: return _bv_bin_bool(Kind.BV_SDIV_OVERFLOW, a, b)  # fmt: skip


def BVNegOverflow(a: BitVecRef) -> BoolRef:
    _assert(is_bv(a), 'Bit-vector expression expected')
    return BoolRef(a.ctx.tm.mk_term(Kind.BV_NEG_OVERFLOW, [a.ast]), a.ctx)


def ArraySort(dom: SortRef, rng: SortRef) -> ArraySortRef:
    return ArraySortRef(dom.ctx.tm.mk_array_sort(dom.ast, rng.ast), dom.ctx)


def Array(name: str, dom: SortRef, rng: SortRef) -> ArrayRef:
    s = ArraySort(dom, rng)
    return ArrayRef(dom.ctx.get_var(name, s), dom.ctx)


def ConstArray(dom: SortRef, v: ExprRef) -> ArrayRef:
    ctx = dom.ctx
    s = ctx.tm.mk_array_sort(dom.ast, v.sort().ast)
    return ArrayRef(ctx.tm.mk_const_array(s, v.ast), ctx)


def K(dom: SortRef, v: ExprRef) -> ArrayRef:
    """Alias for ConstArray."""
    return ConstArray(dom, v)


def Select(a: ArrayRef, i: ExprRef) -> ExprRef:
    _assert(is_array(a), 'Array expression expected')
    return _to_expr_ref(a.ctx.tm.mk_term(Kind.ARRAY_SELECT, [a.ast, i.ast]), a.ctx)


def Store(a: ArrayRef, i: ExprRef, v: ExprRef) -> ArrayRef:
    _assert(is_array(a), 'Array expression expected')
    return ArrayRef(a.ctx.tm.mk_term(Kind.ARRAY_STORE, [a.ast, i.ast, v.ast]), a.ctx)


def Update(a: ArrayRef, i: ExprRef, v: ExprRef) -> ArrayRef:
    """Alias for Store."""
    return Store(a, i, v)


class ArrayRef(ExprRef):
    """Array expressions."""

    def sort(self) -> ArraySortRef:
        return ArraySortRef(self.ast.sort(), self.ctx)

    def domain(self) -> SortRef:
        return self.sort().domain()

    def range(self) -> SortRef:
        return self.sort().range()

    def __getitem__(self, idx: ExprRef) -> ExprRef:
        return _to_expr_ref(
            self.ctx.tm.mk_term(Kind.ARRAY_SELECT, [self.ast, idx.ast]), self.ctx
        )

    def default(self) -> ExprRef | None:
        if self.ast.kind() == Kind.CONST_ARRAY:
            return _to_expr_ref(self.ast[0], self.ctx)
        return None


def is_array(a: object) -> bool:
    return isinstance(a, ArrayRef)


def is_const_array(a: object) -> bool:
    return is_app_of(a, Kind.CONST_ARRAY)


def is_K(a: object) -> bool:
    return is_const_array(a)


def is_select(a: object) -> bool:
    return is_app_of(a, Kind.ARRAY_SELECT)


def is_store(a: object) -> bool:
    return is_app_of(a, Kind.ARRAY_STORE)


def DeclareSort(name: str, ctx: Context | None = None) -> SortRef:
    ctx = _get_ctx(ctx)
    return SortRef(ctx.tm.mk_uninterpreted_sort(name), ctx)


class FuncDeclRef(ExprRef):
    """Function declaration / uninterpreted function."""

    def name(self) -> str:
        sym = self.ast.symbol()
        return sym if sym is not None else str(self.ast)

    def arity(self) -> int:
        return self.ast.sort().fun_arity()

    def domain(self, i: int = 0) -> SortRef:
        return _to_sort_ref(self.ast.sort().fun_domain()[i], self.ctx)

    def range(self) -> SortRef:
        return _to_sort_ref(self.ast.sort().fun_codomain(), self.ctx)

    def __call__(self, *args: ExprRef) -> ExprRef:
        _assert(len(args) == self.arity(), 'Arity mismatch')
        terms = [self.ast] + [a.ast for a in args]
        return _to_expr_ref(self.ctx.tm.mk_term(Kind.APPLY, terms), self.ctx)


def Function(name: str, *sig: SortRef) -> FuncDeclRef:
    """Create an uninterpreted function.

    sig is a sequence of sorts: domain sorts followed by the range sort.
    """
    _assert(len(sig) >= 2, 'At least domain and range sorts required')
    ctx = sig[0].ctx
    domain = [s.ast for s in sig[:-1]]
    codomain = sig[-1].ast
    fun_sort = ctx.tm.mk_fun_sort(domain, codomain)
    return FuncDeclRef(ctx.get_var(name, SortRef(fun_sort, ctx)), ctx)


def FreshFunction(*sig: SortRef) -> FuncDeclRef:
    _assert(len(sig) >= 2, 'At least domain and range sorts required')
    ctx = sig[0].ctx
    domain = [s.ast for s in sig[:-1]]
    codomain = sig[-1].ast
    fun_sort = ctx.tm.mk_fun_sort(domain, codomain)
    s = SortRef(fun_sort, ctx)
    name = ctx.next_fresh(s, 'f')
    return FuncDeclRef(ctx.get_var(name, s), ctx)


def FPSort(ebits: int, sbits: int, ctx: Context | None = None) -> FPSortRef:
    ctx = _get_ctx(ctx); return FPSortRef(ctx.tm.mk_fp_sort(ebits, sbits), ctx)  # fmt: skip


def Float16(ctx: Context | None = None) -> FPSortRef: return FPSort(5, 11, ctx)  # fmt: skip


def Float32(ctx: Context | None = None) -> FPSortRef: return FPSort(8, 24, ctx)  # fmt: skip


def Float64(ctx: Context | None = None) -> FPSortRef: return FPSort(11, 53, ctx)  # fmt: skip


def Float128(ctx: Context | None = None) -> FPSortRef: return FPSort(15, 113, ctx)  # fmt: skip


FloatHalf = Float16
FloatSingle = Float32
FloatDouble = Float64
FloatQuadruple = Float128


def FPRMSort(ctx: Context | None = None) -> FPRMSortRef:
    ctx = _get_ctx(ctx); return FPRMSortRef(ctx.tm.mk_rm_sort(), ctx)  # fmt: skip


_default_rounding_mode: FPRMRef | None = None
_default_fp_sort: FPSortRef | None = None


def get_default_rounding_mode(ctx: Context | None = None) -> FPRMRef:
    global _default_rounding_mode
    if _default_rounding_mode is None:
        _default_rounding_mode = RNE(ctx)
    return _default_rounding_mode


def set_default_rounding_mode(rm: FPRMRef) -> None:
    global _default_rounding_mode
    _default_rounding_mode = rm


def _dflt_rm(ctx: Context | None = None) -> FPRMRef:
    return get_default_rounding_mode(ctx)


def get_default_fp_sort(ctx: Context | None = None) -> FPSortRef:
    global _default_fp_sort
    if _default_fp_sort is None:
        _default_fp_sort = Float64(ctx)
    return _default_fp_sort


def set_default_fp_sort(ebits: int, sbits: int, ctx: Context | None = None) -> None:
    global _default_fp_sort
    _default_fp_sort = FPSort(ebits, sbits, ctx)


# fmt: off
def RNE(ctx: Context | None = None) -> FPRMRef: ctx = _get_ctx(ctx); return FPRMRef(ctx.tm.mk_rm_value(RoundingMode.RNE), ctx)
def RNA(ctx: Context | None = None) -> FPRMRef: ctx = _get_ctx(ctx); return FPRMRef(ctx.tm.mk_rm_value(RoundingMode.RNA), ctx)
def RTP(ctx: Context | None = None) -> FPRMRef: ctx = _get_ctx(ctx); return FPRMRef(ctx.tm.mk_rm_value(RoundingMode.RTP), ctx)
def RTN(ctx: Context | None = None) -> FPRMRef: ctx = _get_ctx(ctx); return FPRMRef(ctx.tm.mk_rm_value(RoundingMode.RTN), ctx)
def RTZ(ctx: Context | None = None) -> FPRMRef: ctx = _get_ctx(ctx); return FPRMRef(ctx.tm.mk_rm_value(RoundingMode.RTZ), ctx)
def RoundNearestTiesToEven(ctx: Context | None = None) -> FPRMRef: return RNE(ctx)
def RoundNearestTiesToAway(ctx: Context | None = None) -> FPRMRef: return RNA(ctx)
def RoundTowardPositive(ctx: Context | None = None) -> FPRMRef: return RTP(ctx)
def RoundTowardNegative(ctx: Context | None = None) -> FPRMRef: return RTN(ctx)
def RoundTowardZero(ctx: Context | None = None) -> FPRMRef: return RTZ(ctx)
# fmt: on


class FPRef(ExprRef):
    """Floating-point expressions."""

    def sort(self) -> FPSortRef: return FPSortRef(self.ast.sort(), self.ctx)  # fmt: skip

    def ebits(self) -> int: return self.sort().ebits()  # fmt: skip

    def sbits(self) -> int: return self.sort().sbits()  # fmt: skip

    def as_string(self) -> str: return str(self.ast)  # fmt: skip

    # fmt: off
    def __add__(self, other: _Coercible) -> FPRef: return fpAdd(_dflt_rm(), self, other, self.ctx)
    def __radd__(self, other: _Coercible) -> FPRef: return fpAdd(_dflt_rm(), other, self, self.ctx)
    def __sub__(self, other: _Coercible) -> FPRef: return fpSub(_dflt_rm(), self, other, self.ctx)
    def __rsub__(self, other: _Coercible) -> FPRef: return fpSub(_dflt_rm(), other, self, self.ctx)
    def __mul__(self, other: _Coercible) -> FPRef: return fpMul(_dflt_rm(), self, other, self.ctx)
    def __rmul__(self, other: _Coercible) -> FPRef: return fpMul(_dflt_rm(), other, self, self.ctx)
    def __div__(self, other: _Coercible) -> FPRef: return fpDiv(_dflt_rm(), self, other, self.ctx)
    def __truediv__(self, other: _Coercible) -> FPRef: return self.__div__(other)
    def __rdiv__(self, other: _Coercible) -> FPRef: return fpDiv(_dflt_rm(), other, self, self.ctx)
    def __rtruediv__(self, other: _Coercible) -> FPRef: return self.__rdiv__(other)
    def __mod__(self, other: _Coercible) -> FPRef: return fpRem(self, other)
    def __rmod__(self, other: _Coercible) -> FPRef: return fpRem(other, self)
    def __pos__(self) -> FPRef: return self
    def __neg__(self) -> FPRef: return fpNeg(self)
    def __le__(self, other: _Coercible) -> BoolRef: return fpLEQ(self, other, self.ctx)
    def __lt__(self, other: _Coercible) -> BoolRef: return fpLT(self, other, self.ctx)
    def __ge__(self, other: _Coercible) -> BoolRef: return fpGEQ(self, other, self.ctx)
    def __gt__(self, other: _Coercible) -> BoolRef: return fpGT(self, other, self.ctx)
    # fmt: on


class FPRMRef(ExprRef):
    """Floating-point rounding mode expressions."""

    def as_string(self) -> str:
        return str(self.ast)


class FPNumRef(FPRef):
    """Floating-point values."""

    def isNaN(self) -> bool: return self.ast.is_fp_value_nan()  # fmt: skip

    def isInf(self) -> bool: return self.ast.is_fp_value_pos_inf() or self.ast.is_fp_value_neg_inf()  # fmt: skip

    def isZero(self) -> bool: return self.ast.is_fp_value_pos_zero() or self.ast.is_fp_value_neg_zero()  # fmt: skip

    def isNegative(self) -> bool:
        return (
            self.ast.is_fp_value_neg_inf()
            or self.ast.is_fp_value_neg_zero()
            or (
                not self.isNaN()
                and not self.isZero()
                and not self.isInf()
                and self._sign_bit()
            )
        )

    def isPositive(self) -> bool:
        return not self.isNaN() and not self.isNegative()

    def _sign_bit(self) -> bool:
        v = self.ast.value(2, False)
        if isinstance(v, str) and len(v) > 0:
            return v[0] == '1'
        return False

    def sign(self) -> bool:
        return self._sign_bit()


def is_fp(a: object) -> bool: return isinstance(a, FPRef)  # fmt: skip


def is_fp_value(a: object) -> bool: return isinstance(a, FPNumRef)  # fmt: skip


def is_fprm(a: object) -> bool: return isinstance(a, FPRMRef)  # fmt: skip


def is_fprm_value(a: object) -> bool: return isinstance(a, FPRMRef) and a.ast.is_value()  # fmt: skip


def FP(name: str, fpsort: FPSortRef, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else fpsort.ctx
    return FPRef(ctx.get_var(name, fpsort), ctx)


def FPs(
    names: str | Sequence[str], fpsort: FPSortRef, ctx: Context | None = None
) -> list[FPRef]:
    ctx = _get_ctx(ctx) if ctx else fpsort.ctx
    if isinstance(names, str):
        names = names.split()
    return [FP(name, fpsort, ctx) for name in names]


def FPVal(
    val: float | int | str,
    exp: int | FPSortRef | None = None,
    fps: FPSortRef | None = None,
    ctx: Context | None = None,
) -> FPNumRef:
    """Create a floating-point value."""
    if fps is None and isinstance(exp, FPSortRef):
        fps = exp
        exp = None
    if fps is None:
        fps = get_default_fp_sort(ctx)
    ctx = _get_ctx(ctx) if ctx else fps.ctx

    if exp is not None:
        assert isinstance(exp, int) and isinstance(val, (int, float))
        return FPNumRef(
            ctx.tm.mk_fp_value(fps.ast, _dflt_rm(ctx).ast, str(val * (2**exp))), ctx
        )
    if isinstance(val, float):
        if math.isnan(val):
            return fpNaN(fps, ctx)
        if math.isinf(val):
            return fpPlusInfinity(fps, ctx) if val > 0 else fpMinusInfinity(fps, ctx)
        if val == 0.0:
            return (
                fpMinusZero(fps, ctx)
                if math.copysign(1.0, val) < 0
                else fpPlusZero(fps, ctx)
            )
        return FPNumRef(ctx.tm.mk_fp_value(fps.ast, _dflt_rm(ctx).ast, str(val)), ctx)
    if isinstance(val, (int, str)):
        return FPNumRef(ctx.tm.mk_fp_value(fps.ast, _dflt_rm(ctx).ast, str(val)), ctx)
    raise SMTException(f'Cannot create FP value from {type(val)}')


def fpNaN(s: FPSortRef, ctx: Context | None = None) -> FPNumRef:
    ctx = _get_ctx(ctx) if ctx else s.ctx; return FPNumRef(ctx.tm.mk_fp_nan(s.ast), ctx)  # fmt: skip


def fpPlusInfinity(s: FPSortRef, ctx: Context | None = None) -> FPNumRef:
    ctx = _get_ctx(ctx) if ctx else s.ctx; return FPNumRef(ctx.tm.mk_fp_pos_inf(s.ast), ctx)  # fmt: skip


def fpMinusInfinity(s: FPSortRef, ctx: Context | None = None) -> FPNumRef:
    ctx = _get_ctx(ctx) if ctx else s.ctx; return FPNumRef(ctx.tm.mk_fp_neg_inf(s.ast), ctx)  # fmt: skip


def fpInfinity(s: FPSortRef, negative: bool, ctx: Context | None = None) -> FPNumRef:
    return fpMinusInfinity(s, ctx) if negative else fpPlusInfinity(s, ctx)


def fpPlusZero(s: FPSortRef, ctx: Context | None = None) -> FPNumRef:
    ctx = _get_ctx(ctx) if ctx else s.ctx; return FPNumRef(ctx.tm.mk_fp_pos_zero(s.ast), ctx)  # fmt: skip


def fpMinusZero(s: FPSortRef, ctx: Context | None = None) -> FPNumRef:
    ctx = _get_ctx(ctx) if ctx else s.ctx; return FPNumRef(ctx.tm.mk_fp_neg_zero(s.ast), ctx)  # fmt: skip


def fpZero(s: FPSortRef, negative: bool, ctx: Context | None = None) -> FPNumRef:
    return fpMinusZero(s, ctx) if negative else fpPlusZero(s, ctx)


def _coerce_fp(a: _Coercible, fps: Any, ctx: Context) -> ExprRef:
    if isinstance(a, ExprRef):
        return a
    if isinstance(a, (int, float)):
        return FPVal(a, None, fps, ctx)
    raise SMTException(f'Cannot coerce {type(a)} to FP')


def _mk_fp_bin(
    kind: Kind, rm: FPRMRef, a: Any, b: Any, ctx: Context | None = None
) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx if isinstance(a, ExprRef) else b.ctx
    fps = a.sort() if isinstance(a, FPRef) else b.sort()
    a = _coerce_fp(a, fps, ctx); b = _coerce_fp(b, fps, ctx)  # fmt: skip
    return FPRef(ctx.tm.mk_term(kind, [rm.ast, a.ast, b.ast]), ctx)


def _mk_fp_unary(kind: Kind, a: FPRef, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx; return FPRef(ctx.tm.mk_term(kind, [a.ast]), ctx)  # fmt: skip


def _mk_fp_pred(kind: Kind, a: FPRef, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx; return BoolRef(ctx.tm.mk_term(kind, [a.ast]), ctx)  # fmt: skip


def _mk_fp_cmp(kind: Kind, a: Any, b: Any, ctx: Context | None = None) -> BoolRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx if isinstance(a, ExprRef) else b.ctx
    fps = a.sort() if isinstance(a, FPRef) else b.sort()
    a = _coerce_fp(a, fps, ctx); b = _coerce_fp(b, fps, ctx)  # fmt: skip
    return BoolRef(ctx.tm.mk_term(kind, [a.ast, b.ast]), ctx)


# fmt: off
def fpAbs(a: FPRef, ctx: Context | None = None) -> FPRef: return _mk_fp_unary(Kind.FP_ABS, a, ctx)
def fpNeg(a: FPRef, ctx: Context | None = None) -> FPRef: return _mk_fp_unary(Kind.FP_NEG, a, ctx)
def fpAdd(rm: FPRMRef, a: _Coercible, b: _Coercible, ctx: Context | None = None) -> FPRef: return _mk_fp_bin(Kind.FP_ADD, rm, a, b, ctx)
def fpSub(rm: FPRMRef, a: _Coercible, b: _Coercible, ctx: Context | None = None) -> FPRef: return _mk_fp_bin(Kind.FP_SUB, rm, a, b, ctx)
def fpMul(rm: FPRMRef, a: _Coercible, b: _Coercible, ctx: Context | None = None) -> FPRef: return _mk_fp_bin(Kind.FP_MUL, rm, a, b, ctx)
def fpDiv(rm: FPRMRef, a: _Coercible, b: _Coercible, ctx: Context | None = None) -> FPRef: return _mk_fp_bin(Kind.FP_DIV, rm, a, b, ctx)
def fpLT(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef: return _mk_fp_cmp(Kind.FP_LT, a, b, ctx)
def fpLEQ(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef: return _mk_fp_cmp(Kind.FP_LEQ, a, b, ctx)
def fpGT(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef: return _mk_fp_cmp(Kind.FP_GT, a, b, ctx)
def fpGEQ(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef: return _mk_fp_cmp(Kind.FP_GEQ, a, b, ctx)
def fpEQ(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef: return _mk_fp_cmp(Kind.FP_EQUAL, a, b, ctx)
def fpNEQ(a: _Coercible, b: _Coercible, ctx: Context | None = None) -> BoolRef: return Not(fpEQ(a, b, ctx))
def fpIsNaN(a: FPRef, ctx: Context | None = None) -> BoolRef: return _mk_fp_pred(Kind.FP_IS_NAN, a, ctx)
def fpIsInf(a: FPRef, ctx: Context | None = None) -> BoolRef: return _mk_fp_pred(Kind.FP_IS_INF, a, ctx)
def fpIsZero(a: FPRef, ctx: Context | None = None) -> BoolRef: return _mk_fp_pred(Kind.FP_IS_ZERO, a, ctx)
def fpIsNormal(a: FPRef, ctx: Context | None = None) -> BoolRef: return _mk_fp_pred(Kind.FP_IS_NORMAL, a, ctx)
def fpIsSubnormal(a: FPRef, ctx: Context | None = None) -> BoolRef: return _mk_fp_pred(Kind.FP_IS_SUBNORMAL, a, ctx)
def fpIsNegative(a: FPRef, ctx: Context | None = None) -> BoolRef: return _mk_fp_pred(Kind.FP_IS_NEG, a, ctx)
def fpIsPositive(a: FPRef, ctx: Context | None = None) -> BoolRef: return _mk_fp_pred(Kind.FP_IS_POS, a, ctx)
# fmt: on


def fpRem(a: Any, b: Any, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx if isinstance(a, ExprRef) else b.ctx
    fps = a.sort() if isinstance(a, FPRef) else b.sort()
    a = _coerce_fp(a, fps, ctx); b = _coerce_fp(b, fps, ctx)  # fmt: skip
    return FPRef(ctx.tm.mk_term(Kind.FP_REM, [a.ast, b.ast]), ctx)


def fpMin(a: FPRef, b: FPRef, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx; return FPRef(ctx.tm.mk_term(Kind.FP_MIN, [a.ast, b.ast]), ctx)  # fmt: skip


def fpMax(a: FPRef, b: FPRef, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx; return FPRef(ctx.tm.mk_term(Kind.FP_MAX, [a.ast, b.ast]), ctx)  # fmt: skip


def fpFMA(
    rm: FPRMRef, a: FPRef, b: FPRef, c: FPRef, ctx: Context | None = None
) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx
    return FPRef(ctx.tm.mk_term(Kind.FP_FMA, [rm.ast, a.ast, b.ast, c.ast]), ctx)


def fpSqrt(rm: FPRMRef, a: FPRef, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx; return FPRef(ctx.tm.mk_term(Kind.FP_SQRT, [rm.ast, a.ast]), ctx)  # fmt: skip


def fpRoundToIntegral(rm: FPRMRef, a: FPRef, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else a.ctx; return FPRef(ctx.tm.mk_term(Kind.FP_RTI, [rm.ast, a.ast]), ctx)  # fmt: skip


def fpFP(
    sgn: BitVecRef, exp: BitVecRef, sig: BitVecRef, ctx: Context | None = None
) -> FPRef:
    """Create FP from sign bit, exponent, and significand bit-vectors."""
    ctx = _get_ctx(ctx) if ctx else sgn.ctx
    return FPRef(ctx.tm.mk_term(Kind.FP_FP, [sgn.ast, exp.ast, sig.ast]), ctx)


def fpBVToFP(v: BitVecRef, sort: FPSortRef, ctx: Context | None = None) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else v.ctx
    return FPRef(
        ctx.tm.mk_term(Kind.FP_TO_FP_FROM_BV, [v.ast], [sort.ebits(), sort.sbits()]),
        ctx,
    )


def fpFPToFP(
    rm: FPRMRef, v: FPRef, sort: FPSortRef, ctx: Context | None = None
) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else v.ctx
    return FPRef(
        ctx.tm.mk_term(
            Kind.FP_TO_FP_FROM_FP, [rm.ast, v.ast], [sort.ebits(), sort.sbits()]
        ),
        ctx,
    )


def fpSignedToFP(
    rm: FPRMRef, v: BitVecRef, sort: FPSortRef, ctx: Context | None = None
) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else v.ctx
    return FPRef(
        ctx.tm.mk_term(
            Kind.FP_TO_FP_FROM_SBV, [rm.ast, v.ast], [sort.ebits(), sort.sbits()]
        ),
        ctx,
    )


def fpUnsignedToFP(
    rm: FPRMRef, v: BitVecRef, sort: FPSortRef, ctx: Context | None = None
) -> FPRef:
    ctx = _get_ctx(ctx) if ctx else v.ctx
    return FPRef(
        ctx.tm.mk_term(
            Kind.FP_TO_FP_FROM_UBV, [rm.ast, v.ast], [sort.ebits(), sort.sbits()]
        ),
        ctx,
    )


def fpToSBV(
    rm: FPRMRef, x: FPRef, s: BitVecSortRef | int, ctx: Context | None = None
) -> BitVecRef:
    ctx = _get_ctx(ctx) if ctx else x.ctx
    sz = s.size() if isinstance(s, BitVecSortRef) else s
    return BitVecRef(ctx.tm.mk_term(Kind.FP_TO_SBV, [rm.ast, x.ast], [sz]), ctx)


def fpToUBV(
    rm: FPRMRef, x: FPRef, s: BitVecSortRef | int, ctx: Context | None = None
) -> BitVecRef:
    ctx = _get_ctx(ctx) if ctx else x.ctx
    sz = s.size() if isinstance(s, BitVecSortRef) else s
    return BitVecRef(ctx.tm.mk_term(Kind.FP_TO_UBV, [rm.ast, x.ast], [sz]), ctx)


def fpToFP(
    a1: Any,
    a2: Any = None,
    a3: FPSortRef | None = None,
    ctx: Context | None = None,
) -> FPRef:
    """General conversion to floating-point."""
    if a3 is None and isinstance(a2, FPSortRef):
        if is_bv(a1):
            return fpBVToFP(a1, a2, ctx)  # type: ignore[arg-type]
    if a3 is not None and isinstance(a3, FPSortRef):
        if is_fp(a2):
            return fpFPToFP(a1, a2, a3, ctx)  # type: ignore[arg-type]
        if is_bv(a2):
            return fpSignedToFP(a1, a2, a3, ctx)  # type: ignore[arg-type]
    raise SMTException('Unexpected arguments to fpToFP')


class QuantifierRef(BoolRef):
    """Quantified formula."""

    def is_forall(self) -> bool: return self.ast.kind() == Kind.FORALL  # fmt: skip

    def is_exists(self) -> bool: return self.ast.kind() == Kind.EXISTS  # fmt: skip

    def is_lambda(self) -> bool: return self.ast.kind() == Kind.LAMBDA  # fmt: skip

    def body(self) -> ExprRef:
        return _to_expr_ref(self.ast[self.ast.num_children() - 1], self.ctx)

    def num_vars(self) -> int:
        return self.ast.num_children() - 1

    def var_name(self, idx: int) -> str:
        sym = self.ast[idx].symbol()
        return sym if sym is not None else f'x!{idx}'

    def var_sort(self, idx: int) -> SortRef:
        return _to_sort_ref(self.ast[idx].sort(), self.ctx)


def _mk_quant(
    kind: Kind,
    vs: ExprRef | list[ExprRef] | tuple[ExprRef, ...],
    body: ExprRef,
    ctx: Context | None = None,
) -> QuantifierRef:
    vs_list: list[ExprRef] = [vs] if isinstance(vs, ExprRef) else list(vs)
    ctx = _get_ctx(ctx) if ctx else body.ctx
    bound: list[_Term] = []
    substs: dict[_Term, _Term] = {}
    for v in vs_list:
        bv = ctx.tm.mk_var(v.ast.sort(), v.ast.symbol())
        bound.append(bv)
        substs[v.ast] = bv
    new_body = ctx.tm.substitute_term(body.ast, substs)
    return QuantifierRef(ctx.tm.mk_term(kind, bound + [new_body]), ctx)


def ForAll(
    vs: ExprRef | list[ExprRef] | tuple[ExprRef, ...], body: ExprRef
) -> QuantifierRef:
    return _mk_quant(Kind.FORALL, vs, body)


def Exists(
    vs: ExprRef | list[ExprRef] | tuple[ExprRef, ...], body: ExprRef
) -> QuantifierRef:
    return _mk_quant(Kind.EXISTS, vs, body)


def Lambda(
    vs: ExprRef | list[ExprRef] | tuple[ExprRef, ...], body: ExprRef
) -> QuantifierRef:
    return _mk_quant(Kind.LAMBDA, vs, body)


def is_quantifier(a: object) -> bool:
    return isinstance(a, QuantifierRef)


class CheckSatResult:
    """Result of a satisfiability check: sat, unsat, unknown."""

    def __init__(self, r: Result) -> None:
        self.r: Result = r

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, CheckSatResult):
            return NotImplemented
        return repr(self) == repr(other)

    def __ne__(self, other: object) -> bool:
        if not isinstance(other, CheckSatResult):
            return NotImplemented
        return repr(self) != repr(other)

    def __hash__(self) -> int:
        return hash(repr(self))

    def __repr__(self) -> str:
        if self.r == Result.SAT:
            return 'sat'
        if self.r == Result.UNSAT:
            return 'unsat'
        return 'unknown'


class CheckSatResultLiteral(CheckSatResult):
    def __init__(self, string: str) -> None:
        self.string: str = string

    def __repr__(self) -> str:
        return self.string

    def __hash__(self) -> int:
        return hash(self.string)


sat = CheckSatResultLiteral('sat')
unsat = CheckSatResultLiteral('unsat')
unknown = CheckSatResultLiteral('unknown')


class Solver:
    """SMT solver."""

    def __init__(self, ctx: Context | None = None) -> None:
        self.ctx: Context = _get_ctx(ctx)
        self._options: _Options = _bitwuzla.Options()
        self._options.set(Option.PRODUCE_MODELS, True)
        self._solver: _Bitwuzla = _bitwuzla.Bitwuzla(self.ctx.tm, self._options)
        self._scopes: int = 0
        self._assertions: list[list[ExprRef]] = [[]]
        self._last_result: CheckSatResult | None = None
        self._used: bool = False

    def set(self, *args: Any, **kwargs: Any) -> None:
        """Set solver options. Must be called before adding assertions.

        Raises SMTException if called after assertions or check-sat calls,
        since bitwuzla options are immutable after solver construction.
        """
        if self._used:
            raise SMTException(
                'Cannot set options after assertions or check-sat calls. '
                'Use reset() first.'
            )
        for k, v in kwargs.items():
            self._options.set(k, v)
        for i in range(0, len(args), 2):
            self._options.set(args[i], args[i + 1])
        self._solver = _bitwuzla.Bitwuzla(self.ctx.tm, self._options)

    def setOption(self, name: Any, value: Any) -> None:
        self.set(name, value)

    def push(self) -> None:
        self._scopes += 1
        self._assertions.append([])
        self._solver.push(1)

    def pop(self, num: int = 1) -> None:
        _assert(num <= self._scopes, 'Cannot pop more scopes than pushed')
        self._scopes -= num
        for _ in range(num):
            self._assertions.pop()
        self._solver.pop(num)

    def num_scopes(self) -> int:
        return self._scopes

    def assert_exprs(self, *args: _Coercible | list[_Coercible]) -> None:
        flat = _get_args(args)
        s = BoolSort(self.ctx)
        for arg in flat:
            if isinstance(arg, bool):
                arg = BoolVal(arg, self.ctx)
            else:
                arg = s.cast(arg)
            self._assertions[-1].append(arg)
            self._solver.assert_formula(arg.ast)
        self._used = True

    def add(self, *args: _Coercible | list[_Coercible]) -> None:
        self.assert_exprs(*args)

    def __iadd__(self, fml: ExprRef) -> Solver:
        self.add(fml); return self  # fmt: skip

    def append(self, *args: _Coercible | list[_Coercible]) -> None:
        self.assert_exprs(*args)

    def insert(self, *args: _Coercible | list[_Coercible]) -> None:
        self.assert_exprs(*args)

    def check(self, *assumptions: ExprRef | list[ExprRef]) -> CheckSatResult:
        flat = _get_args(assumptions)
        r = (
            self._solver.check_sat(*[a.ast for a in flat])
            if flat
            else self._solver.check_sat()
        )
        self._last_result = CheckSatResult(r)
        self._used = True
        return self._last_result

    def model(self) -> ModelRef:
        return ModelRef(self)

    def assertions(self) -> list[ExprRef]:
        return list(itertools.chain.from_iterable(self._assertions))

    def resetAssertions(self) -> None:
        self._solver = _bitwuzla.Bitwuzla(self.ctx.tm, self._options)
        self._scopes = 0
        self._assertions = [[]]
        self._used = False

    def reset(self) -> None:
        self.resetAssertions()

    def unsat_core(self) -> list[ExprRef]:
        return [_to_expr_ref(t, self.ctx) for t in self._solver.get_unsat_core()]

    def reason_unknown(self) -> str:
        """Return a string describing why the last check() returned unknown.

        Note: bitwuzla does not expose a detailed unknown reason API.
        """
        if self._last_result is None:
            raise SMTException('No previous check-sat call')
        raise NotImplementedError(
            'bitwuzla does not provide a detailed reason for unknown results'
        )

    def statistics(self) -> dict[str, str]:
        return self._solver.statistics()

    def sexpr(self) -> str:
        return self._solver.print_formula()

    def __repr__(self) -> str:
        return '[' + ', '.join(str(a) for a in self.assertions()) + ']'


class ModelRef:
    """Model/Solution of a satisfiability problem."""

    def __init__(self, solver: Solver) -> None:
        self.solver: Solver = solver
        self._vars_cache: set[ExprRef] | None = None

    def vars(self) -> set[ExprRef]:
        """Return all free constants in the assertions (cached)."""
        if self._vars_cache is not None:
            return self._vars_cache
        visited: set[int] = set()
        q: list[ExprRef] = list(self.solver.assertions())
        vars_: set[ExprRef] = set()
        while q:
            a = q.pop()
            aid: int = a.ast.id()
            if aid in visited:
                continue
            visited.add(aid)
            if a.ast.kind() == Kind.CONSTANT:
                vars_.add(a)
            else:
                q.extend(a.children())
                if a.ast.kind() == Kind.APPLY:
                    fn = _to_expr_ref(a.ast[0], a.ctx)
                    if fn.ast.id() not in visited:
                        q.append(fn)
        self._vars_cache = vars_
        return vars_

    def eval(self, t: ExprRef, model_completion: bool = False) -> ExprRef:
        return _to_expr_ref(self.solver._solver.get_value(t.ast), self.solver.ctx)

    def evaluate(self, t: ExprRef, model_completion: bool = False) -> ExprRef:
        return self.eval(t, model_completion)

    def __len__(self) -> int:
        return len(self.decls())

    def __getitem__(self, idx: int | ExprRef) -> ExprRef | None:
        if isinstance(idx, int):
            return self.decls()[idx]
        if isinstance(idx, ExprRef):
            return self.eval(idx)
        return None

    def decls(self) -> list[ExprRef]:
        return sorted(self.vars(), key=lambda v: str(v))

    def __repr__(self) -> str:
        return obj_to_string(self)


def evaluate(t: ExprRef) -> ExprRef:
    """Evaluate a ground term."""
    if not isinstance(t, ExprRef):
        raise TypeError('Can only evaluate ExprRef instances')
    s = Solver()
    s.check()
    result = s.model()[t]
    assert result is not None
    return result


def simplify(a: ExprRef) -> ExprRef:
    """Simplify an expression."""
    opts = _bitwuzla.Options()
    solver = _bitwuzla.Bitwuzla(a.ctx.tm, opts)
    return _to_expr_ref(solver.simplify_term(a.ast), a.ctx)


def substitute(t: ExprRef, *m: Any) -> ExprRef:
    """Substitute terms in t according to mapping m.

    Accepts: substitute(t, (x, val)), substitute(t, (x, xv), (y, yv)),
    or substitute(t, [(x, xv), (y, yv)]).
    """
    substs: dict[_Term, _Term] = {}
    if len(m) == 1 and isinstance(m[0], (list, tuple)):
        first = m[0]
        if (
            len(first) == 2
            and isinstance(first[0], ExprRef)
            and isinstance(first[1], ExprRef)
        ):
            substs[first[0].ast] = first[1].ast
        else:
            for pair in first:
                substs[pair[0].ast] = pair[1].ast
    else:
        for pair in m:
            substs[pair[0].ast] = pair[1].ast
    return _to_expr_ref(t.ctx.tm.substitute_term(t.ast, substs), t.ctx)


def solve(*args: _Coercible, **kwargs: Any) -> Solver:
    """Solve constraints and print the result."""
    s = Solver()
    s.add(*args)
    if kwargs.get('show', True):
        r = s.check()
        if r == sat:
            print(repr(r))
            m = s.model()
            for d in m.decls():
                print(f'{d} = {m[d]}')
        elif r == unsat:
            print('no solution')
        else:
            print('failed to solve')
    return s


def solve_using(s: Solver, *args: _Coercible, **kwargs: Any) -> Solver:
    s.add(*args)
    r = s.check()
    if kwargs.get('show', True):
        if r == sat:
            print(repr(r))
            m = s.model()
            for d in m.decls():
                print(f'{d} = {m[d]}')
        elif r == unsat:
            print('no solution')
        else:
            print('failed to solve')
    return s


def prove(claim: BoolRef, **kwargs: Any) -> bool | None:
    """Try to prove `claim` by checking if its negation is unsatisfiable."""
    s = Solver()
    s.add(Not(claim))
    r = s.check()
    show: bool = kwargs.get('show', True)
    if r == unsat:
        if show:
            print('proved')
        return True
    elif r == sat:
        if show:
            print('counterexample')
            m = s.model()
            for d in m.decls():
                print(f'{d} = {m[d]}')
        return False
    else:
        if show:
            print('failed to prove')
        return None


def is_sat(*args: _Coercible) -> bool:
    s = Solver(); s.add(*args); return s.check() == sat  # fmt: skip


def is_tautology(t: BoolRef) -> bool:
    return prove(t, show=False) is True


def Sum(*args: _Coercible | list[_Coercible]) -> ExprRef:
    return ft.reduce(lambda a, b: a + b, _get_args(args))


def Product(*args: _Coercible | list[_Coercible]) -> ExprRef:
    return ft.reduce(lambda a, b: a * b, _get_args(args))


def Model(ctx: Context | None = None) -> Any:
    """Return an object for evaluating terms (z3 compat)."""

    class _EmptyModel:
        def evaluate(self, t: ExprRef) -> ExprRef:
            return evaluate(t)

    return _EmptyModel()


__all__ = [
    'SMTException',
    'Context',
    'main_ctx',
    'get_ctx',
    'SortRef',
    'BoolSortRef',
    'BitVecSortRef',
    'FPSortRef',
    'FPRMSortRef',
    'ArraySortRef',
    'BoolSort',
    'BitVecSort',
    'FPSort',
    'FPRMSort',
    'ArraySort',
    'DeclareSort',
    'Float16',
    'FloatHalf',
    'Float32',
    'FloatSingle',
    'Float64',
    'FloatDouble',
    'Float128',
    'FloatQuadruple',
    'ExprRef',
    'BoolRef',
    'BitVecRef',
    'BitVecNumRef',
    'FPRef',
    'FPNumRef',
    'FPRMRef',
    'ArrayRef',
    'FuncDeclRef',
    'QuantifierRef',
    'BoolVal',
    'Bool',
    'Bools',
    'BoolVector',
    'FreshBool',
    'And',
    'Or',
    'Not',
    'mk_not',
    'Xor',
    'Implies',
    'Iff',
    'If',
    'Distinct',
    'is_bool',
    'is_true',
    'is_false',
    'is_bool_value',
    'is_and',
    'is_or',
    'is_not',
    'is_implies',
    'is_xor',
    'is_eq',
    'is_distinct',
    'BitVecVal',
    'BitVec',
    'BitVecs',
    'BitVecVector',
    'FreshBitVec',
    'Concat',
    'Extract',
    'SignExt',
    'ZeroExt',
    'RepeatBitVec',
    'RotateLeft',
    'RotateRight',
    'ULE',
    'ULT',
    'UGE',
    'UGT',
    'SLE',
    'SLT',
    'SGE',
    'SGT',
    'UDiv',
    'URem',
    'SDiv',
    'SRem',
    'SMod',
    'LShR',
    'BVRedAnd',
    'BVRedOr',
    'BVRedXor',
    'BVAdd',
    'BVSub',
    'BVMul',
    'BVNeg',
    'BVNot',
    'BVAnd',
    'BVOr',
    'BVXor',
    'BVNand',
    'BVNor',
    'BVXnor',
    'BVSAddOverflow',
    'BVUAddOverflow',
    'BVSSubOverflow',
    'BVUSubOverflow',
    'BVSMulOverflow',
    'BVUMulOverflow',
    'BVSDivOverflow',
    'BVNegOverflow',
    'is_bv',
    'is_bv_value',
    'is_bv_sort',
    'Array',
    'ConstArray',
    'K',
    'Select',
    'Store',
    'Update',
    'is_array',
    'is_array_sort',
    'is_const_array',
    'is_K',
    'is_select',
    'is_store',
    'Function',
    'FreshFunction',
    'is_func_decl',
    'RNE',
    'RNA',
    'RTP',
    'RTN',
    'RTZ',
    'RoundNearestTiesToEven',
    'RoundNearestTiesToAway',
    'RoundTowardPositive',
    'RoundTowardNegative',
    'RoundTowardZero',
    'get_default_rounding_mode',
    'set_default_rounding_mode',
    'get_default_fp_sort',
    'set_default_fp_sort',
    'FP',
    'FPs',
    'FPVal',
    'fpNaN',
    'fpPlusInfinity',
    'fpMinusInfinity',
    'fpInfinity',
    'fpPlusZero',
    'fpMinusZero',
    'fpZero',
    'fpAbs',
    'fpNeg',
    'fpAdd',
    'fpSub',
    'fpMul',
    'fpDiv',
    'fpFMA',
    'fpSqrt',
    'fpRoundToIntegral',
    'fpRem',
    'fpMin',
    'fpMax',
    'fpLT',
    'fpLEQ',
    'fpGT',
    'fpGEQ',
    'fpEQ',
    'fpNEQ',
    'fpIsNaN',
    'fpIsInf',
    'fpIsZero',
    'fpIsNormal',
    'fpIsSubnormal',
    'fpIsNegative',
    'fpIsPositive',
    'fpFP',
    'fpBVToFP',
    'fpFPToFP',
    'fpSignedToFP',
    'fpUnsignedToFP',
    'fpToSBV',
    'fpToUBV',
    'fpToFP',
    'is_fp',
    'is_fp_value',
    'is_fp_sort',
    'is_fprm',
    'is_fprm_sort',
    'is_fprm_value',
    'ForAll',
    'Exists',
    'Lambda',
    'is_quantifier',
    'Solver',
    'ModelRef',
    'CheckSatResult',
    'CheckSatResultLiteral',
    'sat',
    'unsat',
    'unknown',
    'solve',
    'solve_using',
    'prove',
    'is_sat',
    'is_tautology',
    'simplify',
    'substitute',
    'evaluate',
    'Sum',
    'Product',
    'Model',
    'Const',
    'Consts',
    'FreshConst',
    'is_expr',
    'is_sort',
    'is_app',
    'is_const',
    'is_var',
    'is_app_of',
    'is_ast',
    'eq',
    'set_fpa_pretty',
    'get_fpa_pretty',
    'Kind',
    'Option',
    'Result',
    'RoundingMode',
]
