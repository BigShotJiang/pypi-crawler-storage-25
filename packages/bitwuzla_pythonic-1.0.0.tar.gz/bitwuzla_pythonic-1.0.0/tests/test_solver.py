from bitwuzla_pythonic import *


class TestSolver:
    def test_empty_check(self):
        s = Solver()
        assert s.check() == sat

    def test_add(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(42, 8))
        assert s.check() == sat

    def test_add_multiple(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0, x < 10)
        assert s.check() == sat

    def test_iadd(self):
        s = Solver()
        x = BitVec('x', 8)
        s += x == BitVecVal(1, 8)
        assert s.check() == sat

    def test_append(self):
        s = Solver()
        x = BitVec('x', 8)
        s.append(x == BitVecVal(1, 8))
        assert s.check() == sat

    def test_insert(self):
        s = Solver()
        x = BitVec('x', 8)
        s.insert(x == BitVecVal(1, 8))
        assert s.check() == sat

    def test_assertions(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0)
        s.add(x < 10)
        assert len(s.assertions()) == 2

    def test_repr(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0)
        r = repr(s)
        assert '[' in r and ']' in r

    def test_add_bool_python(self):
        s = Solver()
        s.add(True)
        assert s.check() == sat

    def test_add_list(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add([x > 0, x < 10])
        assert s.check() == sat


class TestSolverPushPop:
    def test_push_pop(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0)
        assert s.check() == sat

        s.push()
        s.add(x < 0)
        assert s.check() == unsat

        s.pop()
        assert s.check() == sat

    def test_num_scopes(self):
        s = Solver()
        assert s.num_scopes() == 0
        s.push()
        assert s.num_scopes() == 1
        s.push()
        assert s.num_scopes() == 2
        s.pop()
        assert s.num_scopes() == 1

    def test_nested_push_pop(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0)

        s.push()
        s.add(x == BitVecVal(5, 8))
        assert s.check() == sat
        m = s.model()
        assert m[x].as_long() == 5

        s.push()
        s.add(x != BitVecVal(5, 8))
        assert s.check() == unsat

        s.pop(2)
        assert s.check() == sat

    def test_reset(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(0, 8))
        assert s.check() == sat
        s.reset()
        assert len(s.assertions()) == 0

    def test_reset_assertions(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0)
        s.push()
        s.add(x < 0)
        s.resetAssertions()
        assert s.num_scopes() == 0
        assert len(s.assertions()) == 0


class TestModel:
    def test_getitem_expr(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(42, 8))
        s.check()
        m = s.model()
        assert m[x].as_long() == 42

    def test_getitem_int(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(42, 8))
        s.check()
        m = s.model()
        decl = m[0]
        assert is_expr(decl)

    def test_eval(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(5, 8))
        s.check()
        m = s.model()
        r = m.eval(x + BitVecVal(3, 8))
        assert is_bv_value(r)
        assert r.as_long() == 8

    def test_evaluate_alias(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(5, 8))
        s.check()
        m = s.model()
        assert m.evaluate(x).as_long() == 5

    def test_decls(self):
        s = Solver()
        x = BitVec('x', 8)
        y = BitVec('y', 8)
        s.add(x + y == BitVecVal(10, 8))
        s.check()
        m = s.model()
        assert len(m.decls()) == 2

    def test_len(self):
        s = Solver()
        x = BitVec('x', 8)
        y = BitVec('y', 8)
        s.add(x + y == BitVecVal(10, 8))
        s.check()
        m = s.model()
        assert len(m) == 2

    def test_repr(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(42, 8))
        s.check()
        m = s.model()
        r = repr(m)
        assert 'x' in r and '42' in r


class TestCheckSatResult:
    def test_sat_eq(self):
        s = Solver()
        assert s.check() == sat

    def test_unsat_eq(self):
        x = BitVec('x', 1)
        s = Solver()
        s.add(x == BitVecVal(0, 1))
        s.add(x == BitVecVal(1, 1))
        assert s.check() == unsat

    def test_ne(self):
        s = Solver()
        assert s.check() != unsat

    def test_repr(self):
        s = Solver()
        r = s.check()
        assert repr(r) == 'sat'


class TestConvenienceFunctions:
    def test_is_sat(self):
        x = BitVec('x', 8)
        assert is_sat(x == BitVecVal(42, 8))

    def test_is_sat_false(self):
        x = BitVec('x', 8)
        assert not is_sat(x == BitVecVal(0, 8), x == BitVecVal(1, 8))

    def test_is_tautology(self):
        x = BitVec('x', 8)
        assert is_tautology(x == x)

    def test_is_tautology_false(self):
        x = BitVec('x', 8)
        assert not is_tautology(x == BitVecVal(0, 8))

    def test_evaluate(self):
        r = evaluate(BitVecVal(1, 8) + BitVecVal(2, 8))
        assert r.as_long() == 3

    def test_evaluate_nested(self):
        r = evaluate(evaluate(BitVecVal(1, 8) + BitVecVal(2, 8)) + BitVecVal(3, 8))
        assert r.as_long() == 6

    def test_sum(self):
        x, y, z = BitVecs('x y z', 8)
        r = Sum(x, y, z)
        assert is_bv(r)

    def test_product(self):
        x, y, z = BitVecs('x y z', 8)
        r = Product(x, y, z)
        assert is_bv(r)

    def test_model_helper(self):
        m = Model()
        r = m.evaluate(BitVecVal(1, 8) + BitVecVal(2, 8))
        assert r.as_long() == 3

    def test_simplify(self):
        x = BitVec('x', 8)
        r = simplify(x + BitVecVal(0, 8))
        # simplify should return something; exact result depends on solver
        assert is_bv(r)

    def test_substitute(self):
        x = BitVec('x', 32)
        y = BitVec('y', 32)
        expr = x + y
        r = substitute(expr, (x, BitVecVal(1, 32)))
        assert is_bv(r)


class TestGenericConstructors:
    def test_const(self):
        s = BitVecSort(32)
        x = Const('x', s)
        assert is_bv(x)

    def test_consts(self):
        s = BitVecSort(32)
        x, y = Consts('x y', s)
        assert is_bv(x) and is_bv(y)

    def test_fresh_const(self):
        s = BitVecSort(32)
        a = FreshConst(s)
        b = FreshConst(s)
        assert not a.eq(b)
