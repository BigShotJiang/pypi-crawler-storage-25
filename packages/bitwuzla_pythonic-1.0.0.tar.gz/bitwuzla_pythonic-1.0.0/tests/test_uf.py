from bitwuzla_pythonic import *


class TestDeclareSort:
    def test_creation(self):
        A = DeclareSort('A')
        assert is_sort(A)

    def test_const_of_uninterpreted(self):
        A = DeclareSort('A')
        a = Const('a', A)
        b = Const('b', A)
        assert is_const(a)
        assert is_const(b)

    def test_equality(self):
        A = DeclareSort('A')
        a = Const('a', A)
        b = Const('b', A)
        r = a == b
        assert is_eq(r)


class TestFunction:
    def test_creation(self):
        f = Function('f', BitVecSort(32), BitVecSort(32))
        assert is_func_decl(f)
        assert f.name() == 'f'
        assert f.arity() == 1

    def test_multi_arg(self):
        g = Function('g', BitVecSort(32), BitVecSort(32), BoolSort())
        assert g.arity() == 2

    def test_application(self):
        f = Function('f', BitVecSort(32), BitVecSort(32))
        x = BitVec('x', 32)
        r = f(x)
        assert is_bv(r)
        assert r.sort() == BitVecSort(32)

    def test_application_printing(self):
        f = Function('f', BitVecSort(32), BitVecSort(32))
        x = BitVec('x', 32)
        assert str(f(x)) == 'f(x)'

    def test_multi_arg_application(self):
        g = Function('g', BitVecSort(32), BitVecSort(8), BitVecSort(16))
        x = BitVec('x', 32)
        y = BitVec('y', 8)
        r = g(x, y)
        assert r.sort() == BitVecSort(16)
        assert str(r) == 'g(x, y)'

    def test_domain_range(self):
        f = Function('f', BitVecSort(32), BitVecSort(8), BoolSort())
        assert f.domain(0) == BitVecSort(32)
        assert f.domain(1) == BitVecSort(8)
        assert f.range() == BoolSort()

    def test_decl(self):
        f = Function('f', BitVecSort(32), BitVecSort(32))
        x = BitVec('x', 32)
        app = f(x)
        d = app.decl()
        assert is_func_decl(d)
        assert d.name() == 'f'

    def test_children(self):
        f = Function('f', BitVecSort(32), BitVecSort(32))
        x = BitVec('x', 32)
        app = f(x)
        children = app.children()
        assert len(children) == 1
        assert children[0].eq(x)

    def test_num_args(self):
        g = Function('g', BitVecSort(32), BitVecSort(32), BitVecSort(32))
        x, y = BitVecs('x y', 32)
        app = g(x, y)
        assert app.num_args() == 2

    def test_fresh_function(self):
        f1 = FreshFunction(BitVecSort(32), BitVecSort(32))
        f2 = FreshFunction(BitVecSort(32), BitVecSort(32))
        assert not f1.eq(f2)


class TestUFSolving:
    def test_basic(self):
        f = Function('f', BitVecSort(32), BitVecSort(32))
        x = BitVec('x', 32)
        s = Solver()
        s.add(f(x) == BitVecVal(42, 32))
        s.add(x == BitVecVal(1, 32))
        assert s.check() == sat
        m = s.model()
        assert m.eval(f(BitVecVal(1, 32))).as_long() == 42

    def test_congruence(self):
        f = Function('f', BitVecSort(8), BitVecSort(8))
        a, b = BitVecs('a b', 8)
        s = Solver()
        s.add(f(a) != f(b))
        s.add(a == b)
        assert s.check() == unsat

    def test_uninterpreted_sort(self):
        A = DeclareSort('A')
        a = Const('a', A)
        b = Const('b', A)
        r = a == b
        assert is_eq(r)
