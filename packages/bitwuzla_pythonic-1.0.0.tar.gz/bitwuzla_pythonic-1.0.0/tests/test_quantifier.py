from bitwuzla_pythonic import *


class TestForAll:
    def test_creation(self):
        x = BitVec('x', 32)
        f = ForAll([x], x + BitVecVal(0, 32) == x)
        assert is_quantifier(f)
        assert f.is_forall()
        assert not f.is_exists()

    def test_single_var(self):
        x = BitVec('x', 8)
        f = ForAll(x, x == x)
        assert is_quantifier(f)

    def test_printing(self):
        x = BitVec('x', 32)
        f = ForAll([x], x == x)
        s = str(f)
        assert 'ForAll' in s

    def test_body(self):
        x = BitVec('x', 32)
        f = ForAll([x], x == x)
        body = f.body()
        assert is_bool(body)

    def test_num_vars(self):
        x = BitVec('x', 32)
        f = ForAll([x], x == x)
        assert f.num_vars() == 1

    def test_var_name(self):
        x = BitVec('x', 32)
        f = ForAll([x], x == x)
        assert f.var_name(0) == 'x'

    def test_var_sort(self):
        x = BitVec('x', 32)
        f = ForAll([x], x == x)
        assert f.var_sort(0) == BitVecSort(32)


class TestExists:
    def test_creation(self):
        x = BitVec('x', 8)
        f = Exists([x], x == BitVecVal(42, 8))
        assert is_quantifier(f)
        assert f.is_exists()
        assert not f.is_forall()

    def test_sat(self):
        x = BitVec('x', 8)
        f = Exists([x], x == BitVecVal(42, 8))
        s = Solver()
        s.add(f)
        assert s.check() == sat


class TestLambda:
    def test_creation(self):
        x = BitVec('x', 32)
        f = Lambda([x], x + BitVecVal(1, 32))
        assert is_quantifier(f)
        assert f.is_lambda()
        assert not f.is_forall()
        assert not f.is_exists()


class TestQuantifierSolving:
    def test_forall_trivial(self):
        x = BitVec('x', 8)
        s = Solver()
        s.add(ForAll([x], x == x))
        assert s.check() == sat

    def test_forall_unsat(self):
        x = BitVec('x', 8)
        s = Solver()
        s.add(ForAll([x], x == BitVecVal(0, 8)))
        assert s.check() == unsat

    def test_exists_sat(self):
        x = BitVec('x', 8)
        s = Solver()
        s.add(Exists([x], x == BitVecVal(0, 8)))
        assert s.check() == sat
