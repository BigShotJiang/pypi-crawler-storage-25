from bitwuzla_pythonic import *


class TestArraySort:
    def test_sort_creation(self):
        s = ArraySort(BitVecSort(32), BitVecSort(8))
        assert isinstance(s, ArraySortRef)
        assert s.domain() == BitVecSort(32)
        assert s.range() == BitVecSort(8)
        assert str(s) == 'Array(BitVec(32), BitVec(8))'

    def test_sort_equality(self):
        s1 = ArraySort(BitVecSort(32), BitVecSort(8))
        s2 = ArraySort(BitVecSort(32), BitVecSort(8))
        s3 = ArraySort(BitVecSort(32), BitVecSort(32))
        assert s1 == s2
        assert s1 != s3

    def test_is_array_sort(self):
        assert is_array_sort(ArraySort(BitVecSort(32), BitVecSort(8)))
        assert not is_array_sort(BitVecSort(32))


class TestArrayVar:
    def test_creation(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        assert is_array(a)
        assert is_const(a)
        assert str(a) == 'a'

    def test_domain_range(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        assert a.domain() == BitVecSort(32)
        assert a.range() == BitVecSort(8)


class TestArrayOps:
    def test_select_bracket(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        i = BitVec('i', 32)
        r = a[i]
        assert is_bv(r)
        assert r.size() == 8

    def test_select_func(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        i = BitVec('i', 32)
        r = Select(a, i)
        assert is_bv(r)

    def test_store(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        i = BitVec('i', 32)
        v = BitVecVal(42, 8)
        r = Store(a, i, v)
        assert is_array(r)

    def test_update_alias(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        i = BitVec('i', 32)
        v = BitVecVal(0, 8)
        r = Update(a, i, v)
        assert is_array(r)

    def test_const_array(self):
        dom = BitVecSort(32)
        v = BitVecVal(0, 8)
        a = ConstArray(dom, v)
        assert is_array(a)
        assert is_const_array(a)
        assert is_K(a)

    def test_k_alias(self):
        dom = BitVecSort(32)
        v = BitVecVal(0, 8)
        a = K(dom, v)
        assert is_const_array(a)

    def test_predicates(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        i = BitVec('i', 32)
        v = BitVecVal(0, 8)
        assert is_select(a[i])
        assert is_store(Store(a, i, v))

    def test_default(self):
        dom = BitVecSort(32)
        v = BitVecVal(99, 8)
        a = ConstArray(dom, v)
        d = a.default()
        assert d is not None
        assert is_bv_value(d)
        assert d.as_long() == 99


class TestArraySolving:
    def test_read_after_write(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        i = BitVec('i', 32)
        v = BitVecVal(42, 8)
        s = Solver()
        written = Store(a, i, v)
        s.add(written[i] != v)
        assert s.check() == unsat

    def test_const_array_solving(self):
        dom = BitVecSort(32)
        a = ConstArray(dom, BitVecVal(0, 8))
        i = BitVec('i', 32)
        s = Solver()
        s.add(a[i] != BitVecVal(0, 8))
        assert s.check() == unsat

    def test_array_model(self):
        a = Array('a', BitVecSort(8), BitVecSort(8))
        s = Solver()
        s.add(a[BitVecVal(0, 8)] == BitVecVal(42, 8))
        assert s.check() == sat
        m = s.model()
        val = m.eval(Select(a, BitVecVal(0, 8)))
        assert is_bv_value(val)
        assert val.as_long() == 42
