from bitwuzla_pythonic import *


class TestBoolSort:
    def test_sort_creation(self):
        s = BoolSort()
        assert isinstance(s, BoolSortRef)
        assert str(s) == 'Bool'

    def test_sort_equality(self):
        assert BoolSort() == BoolSort()
        assert BoolSort() != BitVecSort(1)

    def test_sort_hash(self):
        assert hash(BoolSort()) == hash(BoolSort())

    def test_is_bool_sort(self):
        assert is_sort(BoolSort())


class TestBoolVal:
    def test_true(self):
        t = BoolVal(True)
        assert is_true(t)
        assert not is_false(t)
        assert bool(t) is True

    def test_false(self):
        f = BoolVal(False)
        assert is_false(f)
        assert not is_true(f)
        assert bool(f) is False

    def test_is_bool_value(self):
        assert is_bool_value(BoolVal(True))
        assert is_bool_value(BoolVal(False))

    def test_repr(self):
        assert repr(BoolVal(True)) == 'True'
        assert repr(BoolVal(False)) == 'False'


class TestBoolVar:
    def test_creation(self):
        x = Bool('x')
        assert is_bool(x)
        assert is_const(x)
        assert str(x) == 'x'

    def test_bools(self):
        a, b, c = Bools('a b c')
        assert str(a) == 'a'
        assert str(b) == 'b'
        assert str(c) == 'c'

    def test_bools_list(self):
        a, b = Bools(['p', 'q'])
        assert str(a) == 'p'
        assert str(b) == 'q'

    def test_bool_vector(self):
        xs = BoolVector('x', 3)
        assert len(xs) == 3
        assert all(is_bool(x) for x in xs)

    def test_fresh_bool(self):
        a = FreshBool()
        b = FreshBool()
        assert not a.eq(b)

    def test_sort(self):
        x = Bool('x')
        assert x.sort() == BoolSort()


class TestBoolOps:
    def test_and(self):
        a, b = Bools('a b')
        r = a & b
        assert is_and(r)

    def test_or(self):
        a, b = Bools('a b')
        r = a | b
        assert is_or(r)

    def test_xor(self):
        a, b = Bools('a b')
        r = a ^ b
        assert is_xor(r)

    def test_not(self):
        a = Bool('a')
        r = ~a
        assert is_not(r)

    def test_not_func(self):
        a = Bool('a')
        r = Not(a)
        assert is_not(r)

    def test_mk_not_double_negation(self):
        a = Bool('a')
        r = mk_not(mk_not(a))
        assert r.eq(a)

    def test_implies(self):
        a, b = Bools('a b')
        r = Implies(a, b)
        assert is_implies(r)

    def test_iff(self):
        a, b = Bools('a b')
        r = Iff(a, b)
        assert is_eq(r)

    def test_xor_func(self):
        a, b = Bools('a b')
        r = Xor(a, b)
        assert is_xor(r)

    def test_nary_and(self):
        a, b, c = Bools('a b c')
        r = And(a, b, c)
        assert is_and(r)

    def test_nary_or(self):
        a, b, c = Bools('a b c')
        r = Or(a, b, c)
        assert is_or(r)

    def test_and_list(self):
        xs = BoolVector('x', 4)
        r = And(xs)
        assert is_and(r)

    def test_or_single(self):
        a = Bool('a')
        assert Or(a).eq(a)

    def test_eq(self):
        a, b = Bools('a b')
        r = a == b
        assert is_eq(r)

    def test_ne(self):
        a, b = Bools('a b')
        r = a != b
        assert is_distinct(r)

    def test_eq_none(self):
        a = Bool('a')
        assert (a == None) is False  # noqa: E711
        assert (a != None) is True  # noqa: E711

    def test_if(self):
        a, b = Bools('a b')
        c = Bool('c')
        r = If(c, a, b)
        assert is_bool(r)


class TestBoolSolving:
    def test_sat(self):
        a, b = Bools('a b')
        s = Solver()
        s.add(Or(a, b))
        s.add(Not(a))
        assert s.check() == sat
        m = s.model()
        assert is_true(m[b])

    def test_unsat(self):
        a = Bool('a')
        s = Solver()
        s.add(a)
        s.add(Not(a))
        assert s.check() == unsat

    def test_distinct(self):
        a, b = Bools('a b')
        s = Solver()
        s.add(Distinct(a, b))
        assert s.check() == sat
        m = s.model()
        assert bool(m[a]) != bool(m[b])
