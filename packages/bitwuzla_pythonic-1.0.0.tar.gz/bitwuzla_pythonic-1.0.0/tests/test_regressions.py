import pytest

from bitwuzla_pythonic import *


class TestSolverSetOption:
    def test_set_before_use(self):
        s = Solver()
        s.set(Option.SEED, 42)

    def test_set_raises_after_add(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0)
        with pytest.raises(SMTException, match='Cannot set options'):
            s.set(Option.SEED, 42)

    def test_set_raises_after_check(self):
        s = Solver()
        s.check()
        with pytest.raises(SMTException, match='Cannot set options'):
            s.set(Option.SEED, 42)

    def test_set_after_reset(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x > 0)
        s.reset()
        s.set(Option.SEED, 42)

    def test_setOption_raises_after_use(self):
        s = Solver()
        s.check()
        with pytest.raises(SMTException, match='Cannot set options'):
            s.setOption(Option.SEED, 42)


class TestSolverReasonUnknown:
    def test_raises_no_check(self):
        s = Solver()
        with pytest.raises(SMTException, match='No previous check-sat call'):
            s.reason_unknown()

    def test_raises_not_implemented(self):
        s = Solver()
        s.check()
        with pytest.raises(NotImplementedError):
            s.reason_unknown()


class TestSubstituteMultiplePairs:
    def test_single_pair(self):
        x = BitVec('x', 32)
        y = BitVec('y', 32)
        expr = x + y
        result = substitute(expr, (x, BitVecVal(1, 32)))
        assert is_bv(result)

    def test_multiple_pairs_varargs(self):
        x = BitVec('x', 32)
        y = BitVec('y', 32)
        expr = x + y
        result = substitute(
            expr,
            (x, BitVecVal(1, 32)),
            (y, BitVecVal(2, 32)),
        )
        assert is_bv(result)
        val = evaluate(result)
        assert is_bv_value(val)
        assert val.as_long() == 3

    def test_list_of_pairs(self):
        x = BitVec('x', 32)
        y = BitVec('y', 32)
        expr = x + y
        result = substitute(
            expr,
            [(x, BitVecVal(10, 32)), (y, BitVecVal(20, 32))],
        )
        val = evaluate(result)
        assert val.as_long() == 30


class TestFpToFPConversions:
    def test_bv_to_fp(self):
        bv = BitVecVal(0x3F800000, 32)
        result = fpToFP(bv, Float32())
        assert is_fp(result)

    def test_fp_to_fp(self):
        x = FP('x', Float32())
        result = fpToFP(RNE(), x, Float64())
        assert is_fp(result)

    def test_signed_bv_to_fp(self):
        bv = BitVec('x', 32)
        result = fpToFP(RNE(), bv, Float32())
        assert is_fp(result)

    def test_bad_args_raises(self):
        with pytest.raises(SMTException, match='Unexpected arguments'):
            fpToFP(RNE())


class TestSolverUnsatCore:
    def test_unsat_core(self):
        s = Solver()
        s.set(Option.PRODUCE_UNSAT_CORES, True)
        x = BitVec('x', 8)
        s.add(x == BitVecVal(0, 8))
        s.add(x == BitVecVal(1, 8))
        assert s.check() == unsat
        core = s.unsat_core()
        assert len(core) > 0
        assert all(is_bool(c) for c in core)


class TestSolveConvenienceOutput:
    def test_solve_sat(self, capsys):
        x = BitVec('x', 8)
        solve(x == BitVecVal(42, 8))
        out = capsys.readouterr().out
        assert 'sat' in out
        assert 'x' in out
        assert '42' in out

    def test_solve_unsat(self, capsys):
        x = BitVec('x', 8)
        solve(x == BitVecVal(0, 8), x == BitVecVal(1, 8))
        out = capsys.readouterr().out
        assert 'no solution' in out

    def test_solve_using_sat(self, capsys):
        s = Solver()
        x = BitVec('x', 8)
        solve_using(s, x == BitVecVal(5, 8))
        out = capsys.readouterr().out
        assert 'sat' in out
        assert '5' in out

    def test_prove_valid(self, capsys):
        x = BitVec('x', 32)
        prove(x + 0 == x)
        out = capsys.readouterr().out
        assert 'proved' in out

    def test_prove_counterexample(self, capsys):
        x = BitVec('x', 8)
        prove(x == BitVecVal(0, 8))
        out = capsys.readouterr().out
        assert 'counterexample' in out


class TestErrorPaths:
    def test_not_requires_bool(self):
        x = BitVec('x', 32)
        with pytest.raises(SMTException, match='Boolean expression expected'):
            Not(x)

    def test_extract_requires_bv(self):
        a = Bool('a')
        with pytest.raises(SMTException):
            Extract(7, 0, a)

    def test_function_arity_mismatch(self):
        f = Function('f', BitVecSort(32), BitVecSort(32))
        x, y = BitVecs('x y', 32)
        with pytest.raises(SMTException, match='Arity mismatch'):
            f(x, y)

    def test_function_needs_two_sorts(self):
        with pytest.raises(SMTException, match='At least domain and range'):
            Function('f', BitVecSort(32))

    def test_decl_on_non_apply(self):
        x = BitVec('x', 32)
        with pytest.raises(SMTException, match='non-function'):
            x.decl()

    def test_bool_cast_sort_mismatch(self):
        x = BitVec('x', 32)
        with pytest.raises(SMTException, match='Sort mismatch'):
            BoolSort().cast(x)

    def test_symbolic_bool_raises(self):
        x = BitVec('x', 32)
        with pytest.raises(SMTException, match='Symbolic expressions'):
            bool(x > 0)

    def test_pop_too_many(self):
        s = Solver()
        s.push()
        with pytest.raises(SMTException, match='Cannot pop'):
            s.pop(2)

    def test_sort_mismatch_coerce(self):
        x = BitVec('x', 32)
        y = BitVec('y', 16)
        with pytest.raises(Exception, match='mismatching sort'):
            x + y


class TestModelCaching:
    def test_decls_called_twice_is_consistent(self):
        s = Solver()
        x, y = BitVecs('x y', 8)
        s.add(x + y == BitVecVal(10, 8))
        s.check()
        m = s.model()
        d1 = m.decls()
        d2 = m.decls()
        assert d1 == d2

    def test_vars_cached(self):
        s = Solver()
        x = BitVec('x', 8)
        s.add(x == BitVecVal(1, 8))
        s.check()
        m = s.model()
        v1 = m.vars()
        v2 = m.vars()
        assert v1 is v2  # same object, cached


class TestCheckSatResultEquality:
    def test_sat_equals_sat(self):
        s = Solver()
        assert s.check() == sat

    def test_sat_not_equals_string(self):
        s = Solver()
        r = s.check()
        assert not (r == 'sat')  # noqa: E712 -- intentional, testing __eq__ returns NotImplemented

    def test_sat_not_equals_int(self):
        s = Solver()
        r = s.check()
        assert not (r == 10)  # noqa: E712

    def test_sat_ne_unsat(self):
        s = Solver()
        assert s.check() != unsat

    def test_unsat_ne_string(self):
        x = BitVec('x', 1)
        s = Solver()
        s.add(x == BitVecVal(0, 1), x == BitVecVal(1, 1))
        r = s.check()
        assert not (r == 'unsat')  # noqa: E712


class TestArrayTypeMismatch:
    def test_select_wrong_index_sort(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        bad_idx = BitVec('i', 16)
        with pytest.raises(Exception):
            Select(a, bad_idx)

    def test_store_wrong_value_sort(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        i = BitVec('i', 32)
        bad_val = BitVecVal(0, 32)
        with pytest.raises(Exception):
            Store(a, i, bad_val)

    def test_store_wrong_index_sort(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        bad_idx = BitVec('i', 8)
        v = BitVecVal(0, 8)
        with pytest.raises(Exception):
            Store(a, bad_idx, v)

    def test_bracket_wrong_index_sort(self):
        a = Array('a', BitVecSort(32), BitVecSort(8))
        bad_idx = BitVec('i', 16)
        with pytest.raises(Exception):
            _ = a[bad_idx]


class TestFpaPretty:
    def test_toggle(self):
        set_fpa_pretty(True)
        assert get_fpa_pretty() is True

        x, y = FPs('x y', Float32())
        pretty = str(x + y)

        set_fpa_pretty(False)
        assert get_fpa_pretty() is False
        normal = str(x + y)

        assert '+' in pretty
        assert 'fpAdd' in normal

        set_fpa_pretty(True)
