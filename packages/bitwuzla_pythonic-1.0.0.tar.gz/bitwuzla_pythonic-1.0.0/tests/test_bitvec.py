from bitwuzla_pythonic import *


class TestBitVecSort:
    def test_sort_creation(self):
        s = BitVecSort(32)
        assert isinstance(s, BitVecSortRef)
        assert s.size() == 32
        assert str(s) == 'BitVec(32)'

    def test_sort_equality(self):
        assert BitVecSort(32) == BitVecSort(32)
        assert BitVecSort(32) != BitVecSort(64)

    def test_is_bv_sort(self):
        assert is_bv_sort(BitVecSort(8))
        assert not is_bv_sort(BoolSort())


class TestBitVecVal:
    def test_positive(self):
        v = BitVecVal(42, 32)
        assert v.as_long() == 42
        assert v.as_string() == '42'
        assert str(v) == '42'

    def test_zero(self):
        v = BitVecVal(0, 8)
        assert v.as_long() == 0

    def test_max(self):
        v = BitVecVal(255, 8)
        assert v.as_long() == 255

    def test_negative_twos_complement(self):
        v = BitVecVal(-1, 8)
        assert v.as_long() == 255
        assert v.as_signed_long() == -1

    def test_signed_long(self):
        assert BitVecVal(127, 8).as_signed_long() == 127
        assert BitVecVal(128, 8).as_signed_long() == -128
        assert BitVecVal(0, 8).as_signed_long() == 0

    def test_large_bv(self):
        v = BitVecVal(2**64 - 1, 64)
        assert v.as_long() == 2**64 - 1
        assert v.as_signed_long() == -1

    def test_hex_string(self):
        v = BitVecVal('0xFF', 8)
        assert v.as_long() == 255

    def test_binary_string(self):
        v = BitVecVal('0b1010', 4)
        assert v.as_long() == 10

    def test_from_sort(self):
        s = BitVecSort(16)
        v = BitVecVal(100, s)
        assert v.as_long() == 100
        assert v.size() == 16

    def test_is_bv_value(self):
        assert is_bv_value(BitVecVal(0, 8))
        assert not is_bv_value(BitVec('x', 8))

    def test_binary_string_method(self):
        v = BitVecVal(5, 4)
        assert v.as_binary_string() == '0101'


class TestBitVecVar:
    def test_creation(self):
        x = BitVec('x', 32)
        assert is_bv(x)
        assert is_const(x)
        assert x.size() == 32
        assert str(x) == 'x'

    def test_bitvecs(self):
        x, y, z = BitVecs('x y z', 32)
        assert x.size() == 32
        assert str(y) == 'y'

    def test_bitvecs_list(self):
        x, y = BitVecs(['a', 'b'], 8)
        assert str(x) == 'a'
        assert x.size() == 8

    def test_bitvec_vector(self):
        xs = BitVecVector('v', 3, 16)
        assert len(xs) == 3
        assert all(x.size() == 16 for x in xs)

    def test_fresh_bitvec(self):
        a = FreshBitVec('x', 32)
        b = FreshBitVec('x', 32)
        assert not a.eq(b)

    def test_sort(self):
        x = BitVec('x', 32)
        assert x.sort() == BitVecSort(32)


class TestBitVecArith:
    def test_add(self):
        x, y = BitVecs('x y', 32)
        r = x + y
        assert is_bv(r)
        assert str(r) == 'x + y'

    def test_add_int(self):
        x = BitVec('x', 32)
        r = x + 1
        assert is_bv(r)

    def test_radd(self):
        x = BitVec('x', 32)
        r = 10 + x
        assert is_bv(r)
        assert str(r) == '10 + x'

    def test_sub(self):
        x, y = BitVecs('x y', 32)
        r = x - y
        assert is_bv(r)

    def test_rsub(self):
        x = BitVec('x', 32)
        r = 10 - x
        assert is_bv(r)

    def test_mul(self):
        x, y = BitVecs('x y', 32)
        r = x * y
        assert is_bv(r)

    def test_neg(self):
        x = BitVec('x', 32)
        r = -x
        assert is_bv(r)
        assert str(r) == '-x'

    def test_pos(self):
        x = BitVec('x', 32)
        assert (+x).eq(x)

    def test_div(self):
        x, y = BitVecs('x y', 32)
        r = x / y
        assert is_bv(r)
        assert 'bvsdiv' in r.sexpr()

    def test_mod(self):
        x, y = BitVecs('x y', 32)
        r = x % y
        assert is_bv(r)
        assert 'bvsmod' in r.sexpr()


class TestBitVecBitwise:
    def test_and(self):
        x, y = BitVecs('x y', 32)
        r = x & y
        assert is_bv(r)
        assert str(r) == 'x & y'

    def test_or(self):
        x, y = BitVecs('x y', 32)
        r = x | y
        assert is_bv(r)

    def test_xor(self):
        x, y = BitVecs('x y', 32)
        r = x ^ y
        assert is_bv(r)

    def test_not(self):
        x = BitVec('x', 32)
        r = ~x
        assert is_bv(r)
        assert str(r) == '~x'

    def test_lshift(self):
        x, y = BitVecs('x y', 32)
        r = x << y
        assert is_bv(r)

    def test_rshift(self):
        x, y = BitVecs('x y', 32)
        r = x >> y
        assert is_bv(r)
        assert 'bvashr' in r.sexpr()

    def test_lshr(self):
        x, y = BitVecs('x y', 32)
        r = LShR(x, y)
        assert is_bv(r)
        assert 'bvlshr' in r.sexpr()

    def test_rand(self):
        x = BitVec('x', 32)
        r = 0xFF & x
        assert is_bv(r)

    def test_ror(self):
        x = BitVec('x', 32)
        r = 0xFF | x
        assert is_bv(r)

    def test_rxor(self):
        x = BitVec('x', 32)
        r = 0xFF ^ x
        assert is_bv(r)


class TestBitVecComparison:
    def test_signed_le(self):
        x, y = BitVecs('x y', 32)
        r = x <= y
        assert is_bool(r)
        assert 'bvsle' in r.sexpr()

    def test_signed_lt(self):
        x, y = BitVecs('x y', 32)
        r = x < y
        assert is_bool(r)

    def test_signed_ge(self):
        x, y = BitVecs('x y', 32)
        r = x >= y
        assert is_bool(r)

    def test_signed_gt(self):
        x, y = BitVecs('x y', 32)
        r = x > y
        assert is_bool(r)

    def test_ule(self):
        x, y = BitVecs('x y', 32)
        r = ULE(x, y)
        assert is_bool(r)
        assert 'bvule' in r.sexpr()

    def test_ult(self):
        x, y = BitVecs('x y', 32)
        r = ULT(x, y)
        assert is_bool(r)

    def test_uge(self):
        x, y = BitVecs('x y', 32)
        r = UGE(x, y)
        assert is_bool(r)

    def test_ugt(self):
        x, y = BitVecs('x y', 32)
        r = UGT(x, y)
        assert is_bool(r)

    def test_sle(self):
        x, y = BitVecs('x y', 32)
        r = SLE(x, y)
        assert is_bool(r)

    def test_slt(self):
        x, y = BitVecs('x y', 32)
        r = SLT(x, y)
        assert is_bool(r)

    def test_sge(self):
        x, y = BitVecs('x y', 32)
        r = SGE(x, y)
        assert is_bool(r)

    def test_sgt(self):
        x, y = BitVecs('x y', 32)
        r = SGT(x, y)
        assert is_bool(r)

    def test_eq(self):
        x, y = BitVecs('x y', 32)
        r = x == y
        assert is_bool(r)
        assert is_eq(r)

    def test_ne(self):
        x, y = BitVecs('x y', 32)
        r = x != y
        assert is_bool(r)
        assert is_distinct(r)


class TestBitVecDivision:
    def test_udiv(self):
        x, y = BitVecs('x y', 32)
        r = UDiv(x, y)
        assert is_bv(r)
        assert 'bvudiv' in r.sexpr()

    def test_urem(self):
        x, y = BitVecs('x y', 32)
        r = URem(x, y)
        assert is_bv(r)

    def test_sdiv(self):
        x, y = BitVecs('x y', 32)
        r = SDiv(x, y)
        assert is_bv(r)

    def test_srem(self):
        x, y = BitVecs('x y', 32)
        r = SRem(x, y)
        assert is_bv(r)

    def test_smod(self):
        x, y = BitVecs('x y', 32)
        r = SMod(x, y)
        assert is_bv(r)


class TestBitVecManipulation:
    def test_concat(self):
        x = BitVec('x', 16)
        y = BitVec('y', 16)
        r = Concat(x, y)
        assert is_bv(r)
        assert r.size() == 32

    def test_concat_multi(self):
        a, b, c = BitVecs('a b c', 8)
        r = Concat(a, b, c)
        assert r.size() == 24

    def test_extract(self):
        x = BitVec('x', 32)
        r = Extract(7, 0, x)
        assert is_bv(r)
        assert r.size() == 8

    def test_sign_ext(self):
        x = BitVec('x', 8)
        r = SignExt(24, x)
        assert is_bv(r)
        assert r.size() == 32

    def test_zero_ext(self):
        x = BitVec('x', 8)
        r = ZeroExt(24, x)
        assert is_bv(r)
        assert r.size() == 32

    def test_repeat(self):
        x = BitVec('x', 8)
        r = RepeatBitVec(4, x)
        assert is_bv(r)
        assert r.size() == 32

    def test_rotate_left_const(self):
        x = BitVec('x', 8)
        r = RotateLeft(x, 3)
        assert is_bv(r)

    def test_rotate_right_const(self):
        x = BitVec('x', 8)
        r = RotateRight(x, 3)
        assert is_bv(r)

    def test_rotate_left_expr(self):
        x, y = BitVecs('x y', 8)
        r = RotateLeft(x, y)
        assert is_bv(r)

    def test_rotate_right_expr(self):
        x, y = BitVecs('x y', 8)
        r = RotateRight(x, y)
        assert is_bv(r)


class TestBitVecReduction:
    def test_redand(self):
        x = BitVec('x', 8)
        r = BVRedAnd(x)
        assert is_bv(r)

    def test_redor(self):
        x = BitVec('x', 8)
        r = BVRedOr(x)
        assert is_bv(r)

    def test_redxor(self):
        x = BitVec('x', 8)
        r = BVRedXor(x)
        assert is_bv(r)


class TestBitVecNaryOps:
    def test_bvadd(self):
        x, y, z = BitVecs('x y z', 32)
        r = BVAdd(x, y, z)
        assert is_bv(r)

    def test_bvmul(self):
        x, y, z = BitVecs('x y z', 32)
        r = BVMul(x, y, z)
        assert is_bv(r)

    def test_bvsub(self):
        x, y = BitVecs('x y', 32)
        r = BVSub(x, y)
        assert is_bv(r)

    def test_bvneg(self):
        x = BitVec('x', 32)
        r = BVNeg(x)
        assert is_bv(r)

    def test_bvnot(self):
        x = BitVec('x', 32)
        r = BVNot(x)
        assert is_bv(r)

    def test_bvand(self):
        x, y = BitVecs('x y', 32)
        r = BVAnd(x, y)
        assert is_bv(r)

    def test_bvor(self):
        x, y = BitVecs('x y', 32)
        r = BVOr(x, y)
        assert is_bv(r)

    def test_bvxor(self):
        x, y = BitVecs('x y', 32)
        r = BVXor(x, y)
        assert is_bv(r)

    def test_bvnand(self):
        x, y = BitVecs('x y', 32)
        r = BVNand(x, y)
        assert is_bv(r)

    def test_bvnor(self):
        x, y = BitVecs('x y', 32)
        r = BVNor(x, y)
        assert is_bv(r)

    def test_bvxnor(self):
        x, y = BitVecs('x y', 32)
        r = BVXnor(x, y)
        assert is_bv(r)


class TestBitVecOverflow:
    def test_sadd_overflow(self):
        x, y = BitVecs('x y', 8)
        r = BVSAddOverflow(x, y)
        assert is_bool(r)

    def test_uadd_overflow(self):
        x, y = BitVecs('x y', 8)
        r = BVUAddOverflow(x, y)
        assert is_bool(r)

    def test_neg_overflow(self):
        x = BitVec('x', 8)
        r = BVNegOverflow(x)
        assert is_bool(r)


class TestBitVecSolving:
    def test_simple_sat(self):
        x, y = BitVecs('x y', 32)
        s = Solver()
        s.add(x + y == BitVecVal(10, 32))
        s.add(x > 0, y > 0)
        assert s.check() == sat
        m = s.model()
        xv = m[x].as_long()
        yv = m[y].as_long()
        assert (xv + yv) % (2**32) == 10

    def test_unsat(self):
        x = BitVec('x', 8)
        s = Solver()
        s.add(x == BitVecVal(0, 8))
        s.add(x == BitVecVal(1, 8))
        assert s.check() == unsat

    def test_prove_commutativity(self):
        x, y = BitVecs('x y', 32)
        assert prove(x + y == y + x, show=False) is True

    def test_prove_double_negation(self):
        x = BitVec('x', 32)
        assert prove(-(-x) == x, show=False) is True

    def test_prove_double_not(self):
        x = BitVec('x', 32)
        assert prove(~(~x) == x, show=False) is True

    def test_evaluate(self):
        r = evaluate(BitVecVal(3, 8) + BitVecVal(4, 8))
        assert is_bv_value(r)
        assert r.as_long() == 7

    def test_lshr_vs_ashr(self):
        assert evaluate(BitVecVal(4, 3) >> 1).as_long() == 6  # arithmetic: 110
        assert evaluate(LShR(BitVecVal(4, 3), 1)).as_long() == 2  # logical: 010
