from bitwuzla_pythonic import *


class TestFPSort:
    def test_sort_creation(self):
        s = FPSort(8, 24)
        assert isinstance(s, FPSortRef)
        assert s.ebits() == 8
        assert s.sbits() == 24
        assert str(s) == 'FPSort(8, 24)'

    def test_presets(self):
        assert Float16().ebits() == 5
        assert Float16().sbits() == 11
        assert Float32().ebits() == 8
        assert Float32().sbits() == 24
        assert Float64().ebits() == 11
        assert Float64().sbits() == 53
        assert Float128().ebits() == 15
        assert Float128().sbits() == 113

    def test_aliases(self):
        assert FloatHalf() == Float16()
        assert FloatSingle() == Float32()
        assert FloatDouble() == Float64()
        assert FloatQuadruple() == Float128()

    def test_sort_equality(self):
        assert FPSort(8, 24) == Float32()
        assert FPSort(8, 24) != Float64()

    def test_is_fp_sort(self):
        assert is_fp_sort(Float32())
        assert not is_fp_sort(BitVecSort(32))


class TestFPRoundingMode:
    def test_rne(self):
        rm = RNE()
        assert is_fprm(rm)
        assert is_fprm_value(rm)
        assert str(rm) == 'RNE()'

    def test_rna(self):
        rm = RNA()
        assert is_fprm(rm)

    def test_rtp(self):
        rm = RTP()
        assert is_fprm(rm)

    def test_rtn(self):
        rm = RTN()
        assert is_fprm(rm)

    def test_rtz(self):
        rm = RTZ()
        assert is_fprm(rm)

    def test_long_aliases(self):
        assert RoundNearestTiesToEven().eq(RNE())
        assert RoundNearestTiesToAway().eq(RNA())
        assert RoundTowardPositive().eq(RTP())
        assert RoundTowardNegative().eq(RTN())
        assert RoundTowardZero().eq(RTZ())

    def test_sort(self):
        assert is_fprm_sort(RNE().sort())
        assert FPRMSort() == RNE().sort()

    def test_default_rm(self):
        rm = get_default_rounding_mode()
        assert rm.eq(RNE())

    def test_set_default_rm(self):
        old = get_default_rounding_mode()
        set_default_rounding_mode(RTZ())
        assert get_default_rounding_mode().eq(RTZ())
        set_default_rounding_mode(old)  # restore


class TestFPVar:
    def test_creation(self):
        x = FP('x', Float32())
        assert is_fp(x)
        assert is_const(x)
        assert x.ebits() == 8
        assert x.sbits() == 24

    def test_fps(self):
        x, y = FPs('x y', Float32())
        assert is_fp(x)
        assert is_fp(y)

    def test_sort(self):
        x = FP('x', Float64())
        assert x.sort() == Float64()


class TestFPSpecialValues:
    def test_nan(self):
        n = fpNaN(Float32())
        assert is_fp_value(n)
        assert n.isNaN()
        assert str(n) == 'NaN'

    def test_plus_inf(self):
        i = fpPlusInfinity(Float32())
        assert is_fp_value(i)
        assert i.isInf()
        assert i.isPositive()

    def test_minus_inf(self):
        i = fpMinusInfinity(Float32())
        assert is_fp_value(i)
        assert i.isInf()
        assert i.isNegative()

    def test_plus_zero(self):
        z = fpPlusZero(Float32())
        assert is_fp_value(z)
        assert z.isZero()
        assert z.isPositive()

    def test_minus_zero(self):
        z = fpMinusZero(Float32())
        assert is_fp_value(z)
        assert z.isZero()
        assert z.isNegative()

    def test_infinity_helper(self):
        assert fpInfinity(Float32(), False).isPositive()
        assert fpInfinity(Float32(), True).isNegative()

    def test_zero_helper(self):
        assert fpZero(Float32(), False).isPositive()
        assert fpZero(Float32(), True).isNegative()


class TestFPVal:
    def test_float(self):
        v = FPVal(1.0, Float32())
        assert is_fp_value(v)

    def test_int(self):
        v = FPVal(42, Float32())
        assert is_fp_value(v)

    def test_nan_float(self):
        v = FPVal(float('nan'), Float32())
        assert v.isNaN()

    def test_inf_float(self):
        v = FPVal(float('inf'), Float32())
        assert v.isInf()
        assert v.isPositive()

    def test_neg_inf_float(self):
        v = FPVal(float('-inf'), Float32())
        assert v.isInf()
        assert v.isNegative()

    def test_neg_zero(self):
        v = FPVal(-0.0, Float32())
        assert v.isZero()
        assert v.isNegative()


class TestFPOps:
    def test_add(self):
        x, y = FPs('x y', Float32())
        r = x + y
        assert is_fp(r)

    def test_sub(self):
        x, y = FPs('x y', Float32())
        r = x - y
        assert is_fp(r)

    def test_mul(self):
        x, y = FPs('x y', Float32())
        r = x * y
        assert is_fp(r)

    def test_div(self):
        x, y = FPs('x y', Float32())
        r = x / y
        assert is_fp(r)

    def test_neg(self):
        x = FP('x', Float32())
        r = -x
        assert is_fp(r)

    def test_pos(self):
        x = FP('x', Float32())
        assert (+x).eq(x)

    def test_mod(self):
        x, y = FPs('x y', Float32())
        r = x % y
        assert is_fp(r)

    def test_explicit_rm(self):
        x, y = FPs('x y', Float32())
        r = fpAdd(RTZ(), x, y)
        assert is_fp(r)

    def test_fma(self):
        x, y, z = FPs('x y z', Float32())
        r = fpFMA(RNE(), x, y, z)
        assert is_fp(r)

    def test_sqrt(self):
        x = FP('x', Float32())
        r = fpSqrt(RNE(), x)
        assert is_fp(r)

    def test_round_to_integral(self):
        x = FP('x', Float32())
        r = fpRoundToIntegral(RNE(), x)
        assert is_fp(r)

    def test_abs(self):
        x = FP('x', Float32())
        r = fpAbs(x)
        assert is_fp(r)

    def test_min_max(self):
        x, y = FPs('x y', Float32())
        assert is_fp(fpMin(x, y))
        assert is_fp(fpMax(x, y))

    def test_rem(self):
        x, y = FPs('x y', Float32())
        r = fpRem(x, y)
        assert is_fp(r)


class TestFPComparison:
    def test_lt(self):
        x, y = FPs('x y', Float32())
        assert is_bool(x < y)
        assert is_bool(fpLT(x, y))

    def test_leq(self):
        x, y = FPs('x y', Float32())
        assert is_bool(x <= y)
        assert is_bool(fpLEQ(x, y))

    def test_gt(self):
        x, y = FPs('x y', Float32())
        assert is_bool(x > y)
        assert is_bool(fpGT(x, y))

    def test_geq(self):
        x, y = FPs('x y', Float32())
        assert is_bool(x >= y)
        assert is_bool(fpGEQ(x, y))

    def test_eq(self):
        x, y = FPs('x y', Float32())
        assert is_bool(fpEQ(x, y))

    def test_neq(self):
        x, y = FPs('x y', Float32())
        assert is_bool(fpNEQ(x, y))


class TestFPPredicates:
    def test_is_nan(self):
        x = FP('x', Float32())
        assert is_bool(fpIsNaN(x))

    def test_is_inf(self):
        x = FP('x', Float32())
        assert is_bool(fpIsInf(x))

    def test_is_zero(self):
        x = FP('x', Float32())
        assert is_bool(fpIsZero(x))

    def test_is_normal(self):
        x = FP('x', Float32())
        assert is_bool(fpIsNormal(x))

    def test_is_subnormal(self):
        x = FP('x', Float32())
        assert is_bool(fpIsSubnormal(x))

    def test_is_negative(self):
        x = FP('x', Float32())
        assert is_bool(fpIsNegative(x))

    def test_is_positive(self):
        x = FP('x', Float32())
        assert is_bool(fpIsPositive(x))


class TestFPConversions:
    def test_fp_fp(self):
        sgn = BitVecVal(0, 1)
        exp = BitVecVal(127, 8)
        sig = BitVecVal(0, 23)
        r = fpFP(sgn, exp, sig)
        assert is_fp(r)

    def test_bv_to_fp(self):
        bv = BitVecVal(0x3F800000, 32)
        r = fpBVToFP(bv, Float32())
        assert is_fp(r)

    def test_fp_to_sbv(self):
        x = FP('x', Float32())
        r = fpToSBV(RNE(), x, BitVecSort(32))
        assert is_bv(r)

    def test_fp_to_ubv(self):
        x = FP('x', Float32())
        r = fpToUBV(RNE(), x, BitVecSort(32))
        assert is_bv(r)

    def test_signed_to_fp(self):
        bv = BitVec('x', 32)
        r = fpSignedToFP(RNE(), bv, Float32())
        assert is_fp(r)

    def test_unsigned_to_fp(self):
        bv = BitVec('x', 32)
        r = fpUnsignedToFP(RNE(), bv, Float32())
        assert is_fp(r)

    def test_fp_to_fp(self):
        x = FP('x', Float32())
        r = fpFPToFP(RNE(), x, Float64())
        assert is_fp(r)


class TestFPSolving:
    def test_simple(self):
        x = FP('x', Float32())
        s = Solver()
        s.add(x + FPVal(1.0, Float32()) == FPVal(2.0, Float32()))
        assert s.check() == sat

    def test_nan_not_equal_to_itself(self):
        x = FP('x', Float32())
        s = Solver()
        s.add(fpIsNaN(x))
        s.add(fpEQ(x, x))
        assert s.check() == unsat

    def test_coercion(self):
        x = FP('x', Float32())
        r = x + 1.0
        assert is_fp(r)
