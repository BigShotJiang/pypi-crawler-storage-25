import pytest

from bitwuzla_pythonic import *


class TestContext:
    def test_main_ctx(self):
        ctx = main_ctx()
        assert isinstance(ctx, Context)
        assert main_ctx() is ctx

    def test_get_ctx(self):
        assert get_ctx(None) is main_ctx()
        ctx = Context()
        assert get_ctx(ctx) is ctx

    def test_var_caching(self):
        ctx = main_ctx()
        s = BoolSort()
        v1 = ctx.get_var('cached_test', s)
        v2 = ctx.get_var('cached_test', s)
        assert v1 == v2


class TestExprRef:
    def test_eq_returns_smt(self):
        x = BitVec('x', 32)
        y = BitVec('y', 32)
        r = x == y
        assert isinstance(r, BoolRef)

    def test_ne_returns_smt(self):
        x = BitVec('x', 32)
        y = BitVec('y', 32)
        r = x != y
        assert isinstance(r, BoolRef)

    def test_eq_none_returns_false(self):
        x = BitVec('x', 32)
        assert (x == None) is False  # noqa: E711

    def test_ne_none_returns_true(self):
        x = BitVec('x', 32)
        assert (x != None) is True  # noqa: E711

    def test_bool_of_true(self):
        assert bool(BoolVal(True)) is True

    def test_bool_of_false(self):
        assert bool(BoolVal(False)) is False

    def test_bool_of_eq(self):
        x = BitVec('x', 32)
        assert bool(x == x) is True

    def test_bool_of_symbolic_raises(self):
        x = BitVec('x', 32)
        with pytest.raises(SMTException):
            bool(x > 0)

    def test_hash(self):
        x = BitVec('x', 32)
        y = BitVec('x', 32)
        assert hash(x) == hash(y)
        # Can be used in sets/dicts
        s = {x, y}
        assert len(s) == 1

    def test_structural_eq(self):
        x = BitVec('x', 32)
        y = BitVec('x', 32)
        assert x.eq(y)
        assert eq(x, y)

    def test_structural_neq(self):
        x = BitVec('x', 32)
        y = BitVec('y', 32)
        assert not x.eq(y)
        assert not eq(x, y)

    def test_sort(self):
        x = BitVec('x', 32)
        assert x.sort() == BitVecSort(32)

    def test_sexpr(self):
        x = BitVec('x', 32)
        assert x.sexpr() == 'x'

    def test_kind(self):
        x = BitVec('x', 32)
        assert x.kind() == Kind.CONSTANT

    def test_children(self):
        x, y = BitVecs('x y', 32)
        r = x + y
        children = r.children()
        assert len(children) == 2

    def test_num_args(self):
        x, y = BitVecs('x y', 32)
        r = x + y
        assert r.num_args() == 2

    def test_arg(self):
        x, y = BitVecs('x y', 32)
        r = x + y
        assert r.arg(0).eq(x)
        assert r.arg(1).eq(y)


class TestTypeChecks:
    def test_is_expr(self):
        assert is_expr(BitVec('x', 32))
        assert not is_expr(42)
        assert not is_expr(BitVecSort(32))

    def test_is_sort(self):
        assert is_sort(BitVecSort(32))
        assert not is_sort(BitVec('x', 32))
        assert not is_sort(42)

    def test_is_app(self):
        assert is_app(BitVec('x', 32))

    def test_is_const(self):
        assert is_const(BitVec('x', 32))
        x, y = BitVecs('x y', 32)
        assert not is_const(x + y)

    def test_is_app_of(self):
        x, y = BitVecs('x y', 32)
        assert is_app_of(x + y, Kind.BV_ADD)
        assert not is_app_of(x + y, Kind.BV_SUB)

    def test_is_ast(self):
        assert is_ast(BitVec('x', 32))
        assert is_ast(BitVecSort(32))
        assert not is_ast(42)


class TestIf:
    def test_bool_if(self):
        a = Bool('a')
        x, y = BitVecs('x y', 32)
        r = If(a, x, y)
        assert is_bv(r)
        assert r.size() == 32

    def test_python_bool_if(self):
        x, y = BitVecs('x y', 32)
        r = If(True, x, y)
        assert is_bv(r)

    def test_if_solving(self):
        c = Bool('c')
        x = BitVec('x', 8)
        s = Solver()
        s.add(If(c, x, BitVecVal(0, 8)) == BitVecVal(5, 8))
        s.add(c)
        assert s.check() == sat
        m = s.model()
        assert m[x].as_long() == 5


class TestDistinct:
    def test_two(self):
        x, y = BitVecs('x y', 8)
        r = Distinct(x, y)
        assert is_bool(r)
        assert is_distinct(r)

    def test_multiple(self):
        x, y, z = BitVecs('x y z', 8)
        r = Distinct(x, y, z)
        assert is_bool(r)

    def test_solving(self):
        x, y, z = BitVecs('x y z', 2)
        s = Solver()
        s.add(Distinct(x, y, z))
        assert s.check() == sat
        m = s.model()
        vals = {m[x].as_long(), m[y].as_long(), m[z].as_long()}
        assert len(vals) == 3
