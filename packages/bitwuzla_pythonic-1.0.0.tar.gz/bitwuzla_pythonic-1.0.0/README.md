# bitwuzla-pythonic

Pythonic interface for the [Bitwuzla](https://bitwuzla.github.io/) SMT solver.

## Installation

```bash
pip install bitwuzla-pythonic
```

## Usage

Same as `z3py` / `cvc5.pythonic`

```python
from bitwuzla_pythonic import *

s = Solver()
a = BitVec('a', 32)
b = BitVec('b', 32)

s.add((a * b ^ 1337) == 291710820)

assert s.check() == sat
m = s.model()
print(m)
# [a = 4003257763, b = 4294967295]
```

## Acknowledgements

- [cvc5/cvc5_pythonic_api](https://github.com/cvc5/cvc5_pythonic_api) - Reference
- [Z3Prover/z3](https://github.com/Z3Prover/z3) - Reference
- `opus4.6` - Authored most of the code in this repo :upside_down:
