"""
LangGraph-based orchestration for the tdfs4ds consumer agent.

Flow::

    START -> node_classify -> node_detect_domain -> [conditional on intent] -> node_skill_* -> node_synthesize -> END
"""

from __future__ import annotations

from typing import Annotated, List, Optional, Union

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver
from typing_extensions import TypedDict

import tdfs4ds
from tdfs4ds.agent.consumer_agent import (
    intent_classifier,
    get_data_domain,
    detect_data_domain_for_object,
    skill_search,
    skill_definition,
    skill_usage,
    skill_freshness,
    skill_summary,
    skill_lineage,
    skill_explain,
    skill_dataset,
    skill_propose_features,
    skill_check_dataset_name,
    skill_build_dataset,
    resolve_features_for_dataset,
    synthesize_answer,
)


# ═══════════════════════════════════════════════════════════════════════════
# State
# ═══════════════════════════════════════════════════════════════════════════

class AgentState(TypedDict):
    question: str
    intent: Optional[str]
    object_name: Optional[str]
    domain: Optional[str]
    skill_result: Optional[dict]
    answer: Optional[str]
    messages: Annotated[list, add_messages]
    # DATA_DOMAIN resolution
    resolved_data_domain: Optional[str]   # domain selected for this turn
    available_data_domains: Optional[list]  # all domains found in the store
    # Object resolution — persisted across turns for pronoun-only follow-ups
    resolved_object_name: Optional[str]   # last explicitly named feature/dataset (canonical)
    # Feature triplet — persisted after any successful catalog resolution
    resolved_feature_triplet: Optional[dict]  # {feature_name, entity_name, process_id, view_name}
    # Entity / feature-group context — persisted across turns
    resolved_entity_name: Optional[str]   # entity currently in focus (e.g. "CustomerID")
    resolved_feature_list: Optional[list]  # feature names in current focus (1 or many)
    # Column→source-table mapping from the last EXPLAIN result
    # Keys are uppercase column names; values are bare source table/view names.
    # Used by DEFINITION to narrow BD_COLUMNS lookups when the column is not a feature.
    resolved_column_sources: Optional[dict]  # e.g. {"TRANSACTION_DATE": "RAW_TRANSACTIONS"}
    # Multi-turn pending actions (e.g. dataset creation flow)
    pending_action: Optional[str]         # e.g. "awaiting_dataset_name"
    pending_action_context: Optional[dict]  # e.g. {"feature_name": "..."}


# ═══════════════════════════════════════════════════════════════════════════
# Nodes
# ═══════════════════════════════════════════════════════════════════════════

_DATASET_PENDING_ACTIONS = {
    "awaiting_feature_selection",
    "awaiting_feature_confirmation",
    "awaiting_dataset_name",
    "awaiting_version_selection",
    "awaiting_entity_clarification",
}


def _fuzzy_resolve_from_column_sources(question: str, col_sources: dict) -> Optional[str]:
    """Try to resolve a vague column/table reference from a prior EXPLAIN result.

    Splits the question into tokens and checks whether any token appears as a
    substring in a known column name or source table name.  Returns the matched
    name only when exactly one candidate matches (to avoid false positives on
    common words).

    Args:
        question: Raw user question.
        col_sources: ``resolved_column_sources`` dict (COLUMN_UPPER → source_table).

    Returns:
        The matched column name or source table name, or ``None``.
    """
    if not col_sources:
        return None

    # Ignore very short / stop words that would cause false positives
    _STOP = {"what", "is", "the", "a", "an", "does", "mean", "does", "how", "why",
             "this", "that", "it", "are", "was", "qui", "est", "la", "le", "les",
             "un", "une", "de", "du", "des", "cette", "ce", "que", "quel", "quelle"}
    q_tokens = {t for t in question.lower().replace("_", " ").split() if t not in _STOP and len(t) >= 3}

    if not q_tokens:
        return None

    col_hits = [col for col in col_sources if any(tok in col.lower() for tok in q_tokens)]
    if len(col_hits) == 1:
        return col_hits[0]

    # No column match — try source table names
    if not col_hits:
        tbl_hits: dict[str, str] = {}  # source_table → col_name (for dedup)
        for col, tbl in col_sources.items():
            if any(tok in tbl.lower() for tok in q_tokens):
                tbl_hits[tbl] = col
        if len(tbl_hits) == 1:
            return next(iter(tbl_hits))

    return None


def _node_classify_impl(state: AgentState, intent_model, intent_descriptions: dict) -> dict:
    """Core classify logic — extracted so it can be closed over a dynamic model.

    Short-circuits the LLM classifier for all dataset-creation pending states so
    that the user's reply is routed directly to the dataset skill without being
    misclassified.

    When the intent is DEFINITION but no object_name was extracted, attempts a
    fuzzy match against ``resolved_column_sources`` (populated by a prior EXPLAIN
    turn) so that vague follow-ups like "what does the date mean?" resolve to the
    correct column or source table without requiring the user to quote the exact name.
    """
    if state.get("pending_action") in _DATASET_PENDING_ACTIONS:
        active_intent = state.get("intent") or "DATASET"
        if active_intent not in ("DATASET", "BUILD_DATASET"):
            active_intent = "DATASET"
        return {"intent": active_intent, "object_name": state["question"].strip(), "domain": None}
    result = intent_classifier(state["question"], intent_model=intent_model, intent_descriptions=intent_descriptions)
    object_name = result.object_name
    # Fuzzy fallback: DEFINITION with no explicit object → try column/table sources
    if result.intent == "DEFINITION" and not object_name:
        col_sources = state.get("resolved_column_sources") or {}
        fuzzy = _fuzzy_resolve_from_column_sources(state["question"], col_sources)
        if fuzzy:
            object_name = fuzzy
    return {
        "intent": result.intent,
        "object_name": object_name,
        "domain": result.domain,
    }


def node_classify(state: AgentState) -> dict:
    """Run intent classification using the hardwired full-intent model (legacy path)."""
    return _node_classify_impl(state, intent_model=None, intent_descriptions=None)


def node_detect_domain(state: AgentState) -> dict:
    """Detect the DATA_DOMAIN for the requested object and list all available domains.

    Remembers the resolved domain and the last explicitly named object across turns
    (persisted via MemorySaver).  When a follow-up question uses a pronoun ("it",
    "cette feature") without naming an object, the previously resolved object and
    domain are reused automatically.
    """
    domains_df = get_data_domain()
    available = domains_df["DATA_DOMAIN"].tolist() if not domains_df.empty else []

    # Keep the domain/object already resolved unless we find explicit ones this turn
    current_resolved_domain = state.get("resolved_data_domain") or tdfs4ds.DATA_DOMAIN
    current_resolved_object = state.get("resolved_object_name")

    object_name = state.get("object_name")
    resolved_domain = current_resolved_domain
    resolved_object = object_name if object_name else current_resolved_object

    if object_name:
        detected = detect_data_domain_for_object(object_name)
        if detected:
            resolved_domain = detected

    return {
        "resolved_data_domain": resolved_domain,
        "available_data_domains": available,
        "resolved_object_name": resolved_object,
    }


def _with_domain(domain: Optional[str]):
    """Context manager that temporarily sets ``tdfs4ds.DATA_DOMAIN``."""
    from contextlib import contextmanager

    @contextmanager
    def _cm():
        if domain is None:
            yield
            return
        old = tdfs4ds.DATA_DOMAIN
        tdfs4ds.DATA_DOMAIN = domain
        try:
            yield
        finally:
            tdfs4ds.DATA_DOMAIN = old

    return _cm()


def _extract_triplet(skill_result: Optional[dict]) -> Optional[dict]:
    """Pull ``resolved_triplet`` from a skill result if present and non-empty."""
    if not skill_result:
        return None
    triplet = skill_result.get("resolved_triplet")
    if isinstance(triplet, dict) and triplet.get("feature_name"):
        return triplet
    return None


def _skill_with_triplet(skill_result: dict) -> dict:
    """Build state-update dict from a skill result, propagating triplet when resolved."""
    updates = {"skill_result": skill_result}
    triplet = _extract_triplet(skill_result)
    if triplet:
        updates["resolved_feature_triplet"] = triplet
        updates["resolved_object_name"] = triplet["feature_name"]
        if triplet.get("entity_name"):
            updates["resolved_entity_name"] = triplet["entity_name"]
        updates["resolved_feature_list"] = [triplet["feature_name"]]
    return updates


def _hint_view(state: AgentState) -> Optional[str]:
    """Return the remembered view_name only when this turn has no explicit object.

    When the user names something explicitly, we re-resolve rather than reuse
    the stale hint so that a new feature mentioned in the same thread is handled
    correctly.
    """
    if state.get("object_name"):
        return None
    triplet = state.get("resolved_feature_triplet") or {}
    return triplet.get("view_name") or None


def _effective_object(state: AgentState) -> str:
    """Return the object name: explicit > canonical from triplet > remembered raw."""
    explicit = state.get("object_name")
    if explicit:
        return explicit
    triplet = state.get("resolved_feature_triplet")
    if triplet and triplet.get("feature_name"):
        return triplet["feature_name"]
    return state.get("resolved_object_name") or ""


def node_skill_search(state: AgentState) -> dict:
    """Execute the search skill."""
    with _with_domain(state.get("resolved_data_domain")):
        return {"skill_result": skill_search(state["question"])}


def node_skill_definition(state: AgentState) -> dict:
    """Execute the definition skill, passing a source-table hint when the object was
    mentioned in a prior EXPLAIN formula (populated by node_skill_explain)."""
    obj = _effective_object(state)
    col_sources = state.get("resolved_column_sources") or {}
    hint_table = col_sources.get(obj.upper()) if obj else None
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_definition(
            state["question"],
            obj,
            hint_entity_name=state.get("resolved_entity_name"),
            hint_table_name=hint_table,
        )
    return _skill_with_triplet(result)


def node_skill_usage(state: AgentState) -> dict:
    """Execute the usage skill."""
    with _with_domain(state.get("resolved_data_domain")):
        return {"skill_result": skill_usage(state["question"], _effective_object(state))}


def node_skill_freshness(state: AgentState) -> dict:
    """Execute the freshness skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_freshness(
            state["question"],
            _effective_object(state),
            hint_entity_name=state.get("resolved_entity_name"),
        )
    return _skill_with_triplet(result)


def node_skill_summary(state: AgentState) -> dict:
    """Execute the summary skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_summary(state["question"], state.get("domain"))
    updates: dict = {"skill_result": result}
    # Capture feature group context from summary results
    feature_names_by_entity = result.get("feature_names_by_entity") or {}
    all_feature_names = result.get("feature_names") or []
    if all_feature_names:
        updates["resolved_feature_list"] = all_feature_names
    # If the summary covered exactly one entity, remember it
    if len(feature_names_by_entity) == 1:
        updates["resolved_entity_name"] = next(iter(feature_names_by_entity))
    return updates


def node_skill_lineage(state: AgentState) -> dict:
    """Execute the lineage skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_lineage(state["question"], _effective_object(state), hint_view_name=_hint_view(state))
    return _skill_with_triplet(result)


def node_skill_explain(state: AgentState) -> dict:
    """Execute the explain skill and persist column→source-table mapping for follow-up DEFINITION turns."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_explain(state["question"], _effective_object(state), hint_view_name=_hint_view(state))
    updates = _skill_with_triplet(result)
    # Build column sources dict from source_columns list returned by the LLM
    source_cols = result.get("source_columns") or []
    if source_cols:
        col_sources = {}
        for sc in source_cols:
            col_name = (sc.get("column_name") or "").strip().upper()
            src_table = (sc.get("source_table") or "").strip()
            if col_name and src_table:
                col_sources[col_name] = src_table
        if col_sources:
            updates["resolved_column_sources"] = col_sources
    return updates


def node_skill_dataset(state: AgentState) -> dict:
    """Execute the dataset availability skill — handles a 4-step creation flow.

    Step 0 (no pending): look up datasets that expose the feature.
    Step 1 (``awaiting_feature_selection``): user described their use case →
        LLM proposes top-20 relevant features (or all if ≤ 20).
    Step 2 (``awaiting_feature_confirmation``): user replied 'ok' or 'all' →
        record selection and ask for a dataset name.
    Step 3 (``awaiting_dataset_name``): user provided a name → validate it.
    """
    pending = state.get("pending_action")
    context = state.get("pending_action_context") or {}

    # ── Step 1: use-case → feature proposal ───────────────────────────────
    if pending == "awaiting_feature_selection":
        use_case = state["question"]
        entity_name = context.get("entity_name", "")
        all_features = context.get("all_features", [])
        with _with_domain(state.get("resolved_data_domain")):
            result = skill_propose_features(use_case, entity_name, all_features, top_n=20)
        new_context = {
            **context,
            "proposed_features": result.get("proposed_features", []),
            "include_all_offered": result.get("include_all_offered", False),
        }
        return {
            "skill_result": result,
            "pending_action": "awaiting_feature_confirmation",
            "pending_action_context": new_context,
        }

    # ── Step 2: confirm selection (ok / all) ──────────────────────────────
    if pending == "awaiting_feature_confirmation":
        user_msg = state["question"].strip().lower()
        include_all = any(w in user_msg.split() for w in ("all", "tout", "tous", "toutes"))
        new_context = {**context, "include_all": include_all}
        return {
            "skill_result": {
                "status": "features_confirmed",
                "include_all": include_all,
                "proposed_features": context.get("proposed_features", []),
                "feature_count": context.get("feature_count", 0),
            },
            "pending_action": "awaiting_dataset_name",
            "pending_action_context": new_context,
        }

    # ── Step 3: name check ────────────────────────────────────────────────
    if pending == "awaiting_dataset_name":
        proposed_name = state["question"].strip()
        feature_name = context.get("feature_name", "")
        with _with_domain(state.get("resolved_data_domain")):
            result = skill_check_dataset_name(proposed_name, feature_name)
        # Enrich available result with the feature selection context
        if result.get("status") == "name_available":
            result = {
                **result,
                "include_all": context.get("include_all", False),
                "proposed_features": context.get("proposed_features", []),
                "feature_count": context.get("feature_count", 0),
            }
        updates: dict = {"skill_result": result}
        if result.get("status") == "name_available":
            updates["pending_action"] = None
            updates["pending_action_context"] = None
        # name_taken → leave pending_action so the next turn loops back
        return updates

    # ── Step 0: initial lookup ────────────────────────────────────────────
    effective_obj = _effective_object(state)
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_dataset(state["question"], effective_obj)
    updates = _skill_with_triplet(result)
    if result.get("status") == "no_dataset":
        updates["pending_action"] = "awaiting_feature_selection"
        updates["pending_action_context"] = {
            "feature_name": effective_obj,
            "entity_name": result.get("entity_name", ""),
            "all_features": result.get("all_features", []),
            "feature_count": result.get("feature_count", 0),
        }
    else:
        updates["pending_action"] = None
        updates["pending_action_context"] = None
    return updates


def node_skill_build_dataset(state: AgentState) -> dict:
    """Execute the BUILD_DATASET autonomous creation flow.

    Step 0 (no pending): Locate entity from catalog, immediately propose features.
    Step 1 (awaiting_feature_confirmation): User confirms 'ok' or 'all' → resolve versions.
        If conflicts → awaiting_version_selection.
        Else → awaiting_dataset_name.
    Step 2 (awaiting_version_selection): User picks version per conflict.
        When all resolved → awaiting_dataset_name.
    Step 3 (awaiting_dataset_name): Validate name; if available → create + document immediately.
    """
    from tdfs4ds.agent.consumer_agent import _get_feature_catalog_with_docs, _with_domain

    pending = state.get("pending_action")
    context = state.get("pending_action_context") or {}

    # ── Step 1: confirm → check version conflicts ─────────────────────────
    if pending == "awaiting_feature_confirmation":
        user_msg = state["question"].strip().lower()
        include_all = any(w in user_msg.split() for w in ("all", "tout", "tous", "toutes"))
        features_to_use = context.get("all_features", []) if include_all else context.get("proposed_features", [])
        entity_name = context.get("entity_name", "")

        with _with_domain(state.get("resolved_data_domain")):
            clean, conflicts = resolve_features_for_dataset(entity_name, features_to_use)

        new_context = {
            **context,
            "include_all": include_all,
            "selected_features": clean,
            "conflicts": conflicts,
            "resolved_conflicts": {},
        }

        if conflicts:
            return {
                "skill_result": {
                    "status": "version_conflict",
                    "conflicts": conflicts,
                    "proposed_features": features_to_use,
                    "feature_count": len(features_to_use),
                },
                "pending_action": "awaiting_version_selection",
                "pending_action_context": new_context,
            }

        return {
            "skill_result": {
                "status": "features_confirmed",
                "include_all": include_all,
                "proposed_features": features_to_use,
                "feature_count": len(features_to_use),
            },
            "pending_action": "awaiting_dataset_name",
            "pending_action_context": new_context,
        }

    # ── Step 2: version conflict resolution ──────────────────────────────
    if pending == "awaiting_version_selection":
        user_msg = state["question"].strip()
        conflicts = context.get("conflicts", [])
        resolved_conflicts = dict(context.get("resolved_conflicts", {}))

        for conflict in conflicts:
            feat = conflict["feature_name"]
            if feat in resolved_conflicts:
                continue
            versions = conflict["versions"]
            for i, v in enumerate(versions):
                if str(i + 1) in user_msg or v["process_view_name"].upper() in user_msg.upper():
                    resolved_conflicts[feat] = v["process_id"]
                    break

        remaining = [c for c in conflicts if c["feature_name"] not in resolved_conflicts]
        new_context = {**context, "resolved_conflicts": resolved_conflicts}

        if remaining:
            return {
                "skill_result": {
                    "status": "version_conflict",
                    "conflicts": remaining,
                    "feature_count": context.get("feature_count", 0),
                },
                "pending_action": "awaiting_version_selection",
                "pending_action_context": new_context,
            }

        merged = dict(context.get("selected_features", {}))
        merged.update(resolved_conflicts)
        new_context["selected_features"] = merged
        new_context["conflicts"] = []

        features_to_use = context.get("all_features", []) if context.get("include_all") else context.get("proposed_features", [])
        return {
            "skill_result": {
                "status": "features_confirmed",
                "include_all": context.get("include_all", False),
                "proposed_features": features_to_use,
                "feature_count": len(merged),
            },
            "pending_action": "awaiting_dataset_name",
            "pending_action_context": new_context,
        }

    # ── Step 3: name check → create ───────────────────────────────────────
    if pending == "awaiting_dataset_name":
        proposed_name = state["question"].strip()
        entity_name = context.get("entity_name", "")
        with _with_domain(state.get("resolved_data_domain")):
            name_result = skill_check_dataset_name(proposed_name, entity_name)

        if name_result.get("status") == "name_taken":
            return {
                "skill_result": name_result,
                "pending_action": "awaiting_dataset_name",
                "pending_action_context": context,
            }

        selected_features = context.get("selected_features", {})
        with _with_domain(state.get("resolved_data_domain")):
            build_result = skill_build_dataset(
                entity_name=entity_name,
                selected_features=selected_features,
                dataset_name=proposed_name.strip(),
                schema_name=tdfs4ds.SCHEMA,
            )

        return {
            "skill_result": build_result,
            "pending_action": None,
            "pending_action_context": None,
        }

    # ── Step 0b: entity clarification reply ──────────────────────────────
    if pending == "awaiting_entity_clarification":
        use_case = context.get("use_case", state["question"])
        entity_hint = state["question"].strip()
        all_features: list = []

        with _with_domain(state.get("resolved_data_domain")):
            entity_docs = _get_feature_catalog_with_docs(entity_filter=entity_hint)
            entity_name = ""
            if not entity_docs.empty:
                entity_counts = entity_docs.groupby("ENTITY_NAME").size()
                entity_name = str(entity_counts.idxmax()) if not entity_counts.empty else ""
                for _, row in entity_docs.iterrows():
                    name = str(row.get("FEATURE_NAME", "") or "")
                    desc = str(row.get("BUSINESS_DESCRIPTION", "") or "")
                    if name:
                        all_features.append({"name": name, "description": desc})

        if not all_features:
            return {
                "skill_result": {
                    "status": "no_features_found",
                    "entity_name": entity_name,
                    "entity_hint": entity_hint,
                },
                "pending_action": None,
                "pending_action_context": None,
            }

        with _with_domain(state.get("resolved_data_domain")):
            proposal = skill_propose_features(use_case, entity_name, all_features, top_n=20)

        return {
            "skill_result": proposal,
            "pending_action": "awaiting_feature_confirmation",
            "pending_action_context": {
                "entity_name": entity_name,
                "all_features": all_features,
                "feature_count": len(all_features),
                "proposed_features": proposal.get("proposed_features", []),
                "include_all_offered": proposal.get("include_all_offered", False),
                "use_case": use_case,
            },
        }

    # ── Step 0: initial entry (no pending) ────────────────────────────────
    use_case = state["question"]
    object_name = state.get("object_name") or ""

    entity_name = ""
    all_features: list = []

    with _with_domain(state.get("resolved_data_domain")):
        if object_name:
            feat_doc = _get_feature_catalog_with_docs(feature_filter=object_name)
            if not feat_doc.empty:
                entity_name = str(feat_doc.iloc[0].get("ENTITY_NAME", "") or "")

        if not entity_name:
            all_docs = _get_feature_catalog_with_docs()
            if not all_docs.empty:
                entity_counts = all_docs.groupby("ENTITY_NAME").size()
                entity_name = str(entity_counts.idxmax()) if not entity_counts.empty else ""

        if entity_name:
            entity_docs = _get_feature_catalog_with_docs(entity_filter=entity_name)
            for _, row in entity_docs.iterrows():
                name = str(row.get("FEATURE_NAME", "") or "")
                desc = str(row.get("BUSINESS_DESCRIPTION", "") or "")
                if name:
                    all_features.append({"name": name, "description": desc})

    if not all_features:
        return {
            "skill_result": {
                "status": "awaiting_entity_clarification",
                "entity_name": entity_name,
                "use_case": use_case,
            },
            "pending_action": "awaiting_entity_clarification",
            "pending_action_context": {"use_case": use_case},
        }

    with _with_domain(state.get("resolved_data_domain")):
        proposal = skill_propose_features(use_case, entity_name, all_features, top_n=20)

    return {
        "skill_result": proposal,
        "pending_action": "awaiting_feature_confirmation",
        "pending_action_context": {
            "entity_name": entity_name,
            "all_features": all_features,
            "feature_count": len(all_features),
            "proposed_features": proposal.get("proposed_features", []),
            "include_all_offered": proposal.get("include_all_offered", False),
            "use_case": use_case,
        },
    }


def node_synthesize(state: AgentState) -> dict:
    """Synthesize a natural language answer from the skill result."""
    answer = synthesize_answer(state["question"], state["skill_result"], state["intent"])
    return {"answer": answer}


# ═══════════════════════════════════════════════════════════════════════════
# Routing
# ═══════════════════════════════════════════════════════════════════════════

# Static mapping: intent name → node function.
# This is the only place intent names are coupled to Python implementations.
_INTENT_NODE_MAP = {
    "SEARCH":        node_skill_search,
    "DEFINITION":    node_skill_definition,
    "USAGE":         node_skill_usage,
    "FRESHNESS":     node_skill_freshness,
    "SUMMARY":       node_skill_summary,
    "LINEAGE":       node_skill_lineage,
    "EXPLAIN":       node_skill_explain,
    "DATASET":       node_skill_dataset,
    "BUILD_DATASET": node_skill_build_dataset,
}


# ═══════════════════════════════════════════════════════════════════════════
# Graph builder
# ═══════════════════════════════════════════════════════════════════════════

def build_graph(skills=None):
    """Build and compile the LangGraph StateGraph.

    The skill set is loaded from the ``ca-*`` SKILL.md files bundled with the
    package (via :func:`tdfs4ds.consumer_agent_skill_catalog`).  Only skills
    whose ``intent`` is in ``_INTENT_NODE_MAP`` are registered as graph nodes.

    Args:
        skills: Optional list of intent names (e.g. ``['SEARCH', 'DEFINITION']``)
            to restrict the agent to a subset of skills.  When ``None``, all
            installed consumer-agent skills are included.

    Returns:
        A compiled LangGraph with MemorySaver checkpointer for multi-turn support.

    Raises:
        ValueError: When no consumer-agent skills are found in the package.
    """
    from tdfs4ds.cli import consumer_agent_skill_catalog
    from tdfs4ds.agent.consumer_agent import _build_intent_model

    ca_skills = consumer_agent_skill_catalog()
    if skills:
        ca_skills = {k: v for k, v in ca_skills.items() if v.get("intent") in skills}

    # Filter to intents that have a registered node function
    ca_skills = {k: v for k, v in ca_skills.items() if v.get("intent") in _INTENT_NODE_MAP}

    if not ca_skills:
        raise ValueError(
            "No consumer-agent skills found. Ensure tdfs4ds/skills/ca-*/SKILL.md files "
            "are present in the installed package."
        )

    available_intents   = [v["intent"] for v in ca_skills.values()]
    intent_descriptions = {v["intent"]: v["description"] for v in ca_skills.values() if "description" in v}
    IntentResultModel   = _build_intent_model(available_intents)

    # node_names: intent → graph node name (e.g. "SEARCH" → "skill_search")
    node_names = {intent: f"skill_{intent.lower()}" for intent in available_intents}
    fallback   = node_names[available_intents[0]]

    # Classify node closed over the dynamic model
    def _node_classify(state: AgentState) -> dict:
        return _node_classify_impl(state, IntentResultModel, intent_descriptions)

    # Route function closed over the current node map
    def _route_intent(state: AgentState) -> str:
        return node_names.get(state["intent"], fallback)

    graph = StateGraph(AgentState)
    graph.add_node("classify",      _node_classify)
    graph.add_node("detect_domain", node_detect_domain)
    graph.add_node("synthesize",    node_synthesize)

    for intent, node_name in node_names.items():
        graph.add_node(node_name, _INTENT_NODE_MAP[intent])

    graph.set_entry_point("classify")
    graph.add_edge("classify", "detect_domain")
    graph.add_conditional_edges(
        "detect_domain",
        _route_intent,
        {v: v for v in node_names.values()},
    )
    for node_name in node_names.values():
        graph.add_edge(node_name, "synthesize")
    graph.add_edge("synthesize", END)

    return graph.compile(checkpointer=MemorySaver())


# ═══════════════════════════════════════════════════════════════════════════
# Trace builder
# ═══════════════════════════════════════════════════════════════════════════

_SKILL_LABEL = {
    "SEARCH":        "skill_search",
    "DEFINITION":    "skill_definition",
    "USAGE":         "skill_usage",
    "FRESHNESS":     "skill_freshness",
    "SUMMARY":       "skill_summary",
    "LINEAGE":       "skill_lineage",
    "EXPLAIN":       "skill_explain",
    "DATASET":       "skill_dataset",
    "BUILD_DATASET": "skill_build_dataset",
}


def _build_trace_md(state: dict) -> str:
    """Build a markdown trace of the agent execution from the final state.

    Args:
        state: Final state dict returned by the graph after invocation.

    Returns:
        Markdown-formatted string describing intent, skill, and result.
    """
    parts: list[str] = []

    # ── Intent classification ──────────────────────────────────────────────
    intent = state.get("intent") or "unknown"
    object_name = state.get("object_name")
    resolved_object = state.get("resolved_object_name")
    domain = state.get("domain")

    parts.append("## Intent Classification")
    parts.append(f"- **Intent**: `{intent}`")
    if object_name:
        parts.append(f"- **Object (this turn)**: `{object_name}`")
    if resolved_object and resolved_object != object_name:
        parts.append(f"- **Object (remembered)**: `{resolved_object}`")
    elif resolved_object and not object_name:
        parts.append(f"- **Object**: `{resolved_object}` _(remembered from previous turn)_")
    if domain:
        parts.append(f"- **Domain**: `{domain}`")

    # ── Resolved feature triplet ───────────────────────────────────────────
    triplet = state.get("resolved_feature_triplet")
    resolved_entity = state.get("resolved_entity_name")
    resolved_feature_list = state.get("resolved_feature_list") or []
    if triplet and triplet.get("feature_name"):
        parts.append("\n## Feature Context (remembered)")
        parts.append(f"- **Feature**: `{triplet['feature_name']}`")
        if triplet.get("entity_name"):
            parts.append(f"- **Entity**: `{triplet['entity_name']}`")
        if triplet.get("process_id"):
            parts.append(f"- **Process ID**: `{triplet['process_id']}`")
        if triplet.get("view_name"):
            parts.append(f"- **Process View**: `{triplet['view_name']}`")
    elif resolved_entity or resolved_feature_list:
        parts.append("\n## Feature Context (remembered)")
        if resolved_entity:
            parts.append(f"- **Entity**: `{resolved_entity}`")
    if resolved_feature_list and len(resolved_feature_list) > 1:
        parts.append(f"- **Feature group** ({len(resolved_feature_list)}): "
                     + ", ".join(f"`{f}`" for f in resolved_feature_list))
    col_sources = state.get("resolved_column_sources") or {}
    if col_sources:
        if not any("Feature Context" in p for p in parts):
            parts.append("\n## Feature Context (remembered)")
        parts.append(f"- **Column sources** ({len(col_sources)}): "
                     + ", ".join(f"`{c}` → `{t}`" for c, t in col_sources.items()))

    # ── Pending action ─────────────────────────────────────────────────────
    pending = state.get("pending_action")
    if pending:
        ctx = state.get("pending_action_context") or {}
        parts.append("\n## Pending Action")
        parts.append(f"- **Action**: `{pending}`")
        for k, v in ctx.items():
            parts.append(f"- **{k}**: `{v}`")

    # ── DATA_DOMAIN detection ──────────────────────────────────────────────
    resolved_dd = state.get("resolved_data_domain")
    available_dd = state.get("available_data_domains") or []

    parts.append("\n## DATA_DOMAIN")
    if available_dd:
        parts.append(f"- **Available**: {', '.join(f'`{d}`' for d in available_dd)}")
    else:
        parts.append("- **Available**: _(none found)_")
    if resolved_dd:
        source = "detected from object" if object_name else "remembered from previous turn"
        parts.append(f"- **Active**: `{resolved_dd}` _{source}_")
    else:
        parts.append("- **Active**: _(fallback to tdfs4ds.DATA_DOMAIN)_")

    # ── Skill executed ─────────────────────────────────────────────────────
    skill_name = _SKILL_LABEL.get(intent, "skill_search")
    parts.append("\n## Skill Executed")
    parts.append(f"- **Skill**: `{skill_name}`")
    if object_name:
        parts.append(f"- **Input object**: `{object_name}`")
    if domain:
        parts.append(f"- **Input domain**: `{domain}`")

    # ── Skill result ───────────────────────────────────────────────────────
    skill_result = state.get("skill_result") or {}
    if skill_result:
        parts.append("\n## Skill Result")
        if "error" in skill_result:
            parts.append(f"- **Error**: `{skill_result['error']}`")
            if "diagnostic" in skill_result:
                parts.append("\n### Diagnostic steps")
                for step in skill_result["diagnostic"].split("; "):
                    parts.append(f"- {step}")
        else:
            for key, val in skill_result.items():
                if key in ("available_context", "plain_summary", "explanation", "docs_sources"):
                    continue
                if key == "dependencies" and isinstance(val, list):
                    parts.append(f"- **dependencies** ({len(val)} nodes):")
                    for dep in val:
                        indent = "  " * dep.get("depth", 0)
                        parts.append(f"  {indent}- `{dep['name']}` ({dep['type']})")
                elif key == "source_columns" and isinstance(val, list):
                    parts.append(f"- **source_columns** ({len(val)}):")
                    for sc in val:
                        parts.append(f"  - `{sc.get('column_name')}` ← `{sc.get('source_table')}`")
                elif isinstance(val, list):
                    parts.append(f"- **{key}**: {len(val)} item(s)")
                elif isinstance(val, dict):
                    parts.append(f"- **{key}**: {len(val)} entries")
                elif isinstance(val, str) and len(val) > 300:
                    parts.append(f"- **{key}**: {val[:300]}…")
                else:
                    parts.append(f"- **{key}**: {val}")

    # ── Documentation sources ──────────────────────────────────────────────
    docs_sources = (skill_result or {}).get("docs_sources") or []
    if docs_sources:
        parts.append("\n## Documentation Sources")
        for src in docs_sources:
            parts.append(f"- `{src}`")

    return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════════════════
# Graph singleton — keeps MemorySaver alive across turns
# ═══════════════════════════════════════════════════════════════════════════

_graph_instances: dict = {}   # keyed by frozenset of intent names (empty = all skills)


def _get_graph(skills=None):
    """Return the shared compiled graph, building it once per unique skill subset.

    The graph is cached by ``frozenset(skills)`` so that different restricted
    subsets each get their own compiled graph + MemorySaver (and therefore their
    own conversation memory).  The default full-skill graph uses an empty frozenset
    as its key.
    """
    key = frozenset(skills) if skills else frozenset()
    if key not in _graph_instances:
        _graph_instances[key] = build_graph(skills=list(skills) if skills else None)
    return _graph_instances[key]


def reset_consumer_agent():
    """Clear the graph singleton cache.

    Call this after adding or removing consumer-agent SKILL.md files so that the
    next :func:`consumer_agent` call picks up the new skill set.
    """
    global _graph_instances
    _graph_instances = {}


# ═══════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════

def consumer_agent(
    question: str,
    thread_id: str = "default",
    return_trace: bool = False,
    skills: Optional[List[str]] = None,
) -> Union[str, tuple]:
    """Run the LangGraph agent for a single conversational turn.

    Args:
        question: User question in natural language (French or English).
        thread_id: Conversation thread ID for multi-turn memory.
        return_trace: When True, returns ``(answer, trace_md)`` where
            ``trace_md`` is a Markdown string describing the intent,
            skill, and result. When False (default), returns only the
            answer string.
        skills: Optional list of intent names (e.g. ``['SEARCH', 'DEFINITION']``)
            to restrict the agent to a subset of skills.  When ``None`` (default),
            all installed consumer-agent skills are used.  Threads are isolated
            per skill subset — mixing ``skills`` values in the same ``thread_id``
            is not recommended.

    Returns:
        Answer string, or ``(answer, trace_md)`` tuple when
        ``return_trace=True``.
    """
    graph = _get_graph(skills=skills)
    result = graph.invoke(
        {"question": question, "messages": [HumanMessage(content=question)]},
        config={"configurable": {"thread_id": thread_id}},
    )
    answer = result["answer"]

    if return_trace:
        return answer, _build_trace_md(result)
    return answer
