__version__ = '0.3.0.1'
import difflib
import logging
import json

# Setup the logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Helper: central logging gate controlled by tdfs4ds.DISPLAY_LOGS
def logger_safe(level, message, *args, **kwargs):
    """
    Wrapper around the global `logger` that only emits logs when
    tdfs4ds.DISPLAY_LOGS is True. `level` is a string like "info", "error", etc.
    """
    if getattr(tdfs4ds, "DISPLAY_LOGS", True):
        getattr(logger, level)(message, *args, **kwargs)

logger = logging.getLogger(__name__)

from tdfs4ds.feature_store.feature_query_retrieval import get_available_entity_id_records, write_where_clause_filter
from tdfs4ds.process_store.process_followup import follow_up_report
from tdfs4ds.dataset.dataset_catalog import DatasetCatalog, Dataset

# ---------------------------------------------------------------------------
# Global configuration variables
# ---------------------------------------------------------------------------

DATA_DOMAIN             = None
SCHEMA                  = None
FEATURE_CATALOG_NAME         = 'FS_FEATURE_CATALOG'
FEATURE_CATALOG_NAME_VIEW    = 'FS_V_FEATURE_CATALOG'
PROCESS_CATALOG_NAME         = 'FS_PROCESS_CATALOG'
PROCESS_CATALOG_NAME_VIEW    = 'FS_V_PROCESS_CATALOG'
PROCESS_CATALOG_NAME_VIEW_FEATURE_SPLIT    = 'FS_V_PROCESS_CATALOG_FEATURE_SPLIT'
DATASET_CATALOG_NAME         = 'FS_DATASET'

DATA_DISTRIBUTION_NAME  = 'FS_DATA_DISTRIBUTION'
FOLLOW_UP_NAME          = 'FS_FOLLOW_UP'
DATA_DISTRIBUTION_TEMPORAL = False
FILTER_MANAGER_NAME     = 'FS_FILTER_MANAGER'

END_PERIOD              = 'UNTIL_CHANGED'
FEATURE_STORE_TIME      = None
FEATURE_VERSION_DEFAULT = 'dev.0.0'
DISPLAY_LOGS            = True
DEBUG_MODE              = False

USE_VOLATILE_TABLE      = True
STORE_FEATURE           = 'MERGE'
REGISTER_FEATURE        = 'MERGE'
REGISTER_PROCESS        = 'MERGE'
BUILD_DATASET_AT_UPLOAD = False

FEATURE_PARTITION_N     = 20000
FEATURE_PARTITION_EACH  = 1

VARCHAR_SIZE            = 1024

INSTRUCT_MODEL_URL         = None
INSTRUCT_MODEL_API_KEY     = None
INSTRUCT_MODEL_MODEL       = None
INSTRUCT_MODEL_PROVIDER    = None
INSTRUCT_MODEL_TIMEOUT     = 60   # Seconds per LLM request before timeout
INSTRUCT_MODEL_MAX_RETRIES = 3    # Retries on timeout / transient error

QUERY_OPTIMIZER_MAX_CANDIDATES: int = 10
# Max EXPLAIN syntax failures before giving up.  Failures do NOT count toward
# MAX_CANDIDATES.  Default = MAX_CANDIDATES (equal budget for errors and valid rewrites).
QUERY_OPTIMIZER_MAX_FAILURES: int = 10
# Max refinement rounds per strategy.  Each round re-analyses the EXPLAIN and
# asks the LLM to fix remaining [You] items.  The early stopper triggers when
# no [You] items remain (user_score = 5/5).
QUERY_OPTIMIZER_MAX_REFINE_ROUNDS: int = 3
# Hard cap on completion tokens for each candidate-generation LLM call.
# Set to e.g. 4096 when using a small-context model (≤ 16k tokens) to prevent
# the model from exhausting its output budget with verbose reasoning text.
# None = no explicit cap (model default).
QUERY_OPTIMIZER_MAX_CANDIDATE_TOKENS = None
# Root directory for optimization report files.  Reports are stored under
# {QUERY_OPTIMIZER_REPORT_DIR}/{DATA_DOMAIN}/ and the directory is created
# automatically when a report is first saved.
QUERY_OPTIMIZER_REPORT_DIR: str = 'tdfs4ds_optim_reports'

# Embedding model — mirrors instruct model config pattern
# When EMBEDDING_MODEL_PROVIDER is None, falls back to INSTRUCT_MODEL_PROVIDER
EMBEDDING_MODEL_PROVIDER: str = None
EMBEDDING_MODEL_URL     : str = None
EMBEDDING_MODEL_API_KEY : str = None
EMBEDDING_MODEL_MODEL   : str = 'text-embedding-3-small'
EMBEDDING_MODEL_DIM     : int = 1536
CHROMA_MODE             : str = 'local'
CHROMA_PATH             : str = './tdfs4ds_chroma'
CHROMA_HOST             : str = 'localhost'
CHROMA_PORT             : int = 8000


DOCUMENTATION_PROCESS_BUSINESS_LOGIC      = 'FS_PROCESS_DOCUMENTATION_BUSINESS_LOGIC'
DOCUMENTATION_PROCESS_FEATURES            = 'FS_PROCESS_DOCUMENTATION_FEATURES'
DOCUMENTATION_PROCESS_BUSINESS_LOGIC_VIEW = 'FS_V_PROCESS_DOCUMENTATION_BUSINESS_LOGIC'
DOCUMENTATION_PROCESS_FEATURES_VIEW       = 'FS_V_PROCESS_DOCUMENTATION_FEATURES'
DOCUMENTATION_PROCESS_EXPLAIN             = 'FS_PROCESS_DOCUMENTATION_EXPLAIN'
DOCUMENTATION_PROCESS_EXPLAIN_VIEW        = 'FS_V_PROCESS_DOCUMENTATION_EXPLAIN'
DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS  = 'FS_BUSINESS_DICTIONARY_OBJECTS'
DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS  = 'FS_BUSINESS_DICTIONARY_COLUMNS'
DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS = 'FS_BUSINESS_DICTIONARY_SECTIONS'

import sys as _sys
from tdfs4ds.config import _load_config as _cfg_load, load_config
_cfg_load(_sys.modules[__name__])
del _sys, _cfg_load

import warnings
warnings.filterwarnings('ignore')

import teradataml as tdml
from tdfs4ds.utils.lineage import crystallize_view
from tdfs4ds.utils.filter_management import FilterManager
from tdfs4ds.utils.info import seconds_to_dhms
import tdfs4ds.feature_store
import tdfs4ds.process_store
import tdfs4ds.datasets
import time

import inspect
from tqdm import tqdm

from tdfs4ds.feature_store.feature_data_processing import generate_on_clause

import uuid

# Generate a UUID
RUN_ID       = str(uuid.uuid4())
PROCESS_TYPE = 'RUN PROCESS'

import tdfs4ds

try:
    if SCHEMA is None:
        SCHEMA = tdml.context.context._get_current_databasename()
        if SCHEMA is None:
            logger.warning("No default database detected for feature store.")
            logger.warning('Please set it explicitly: tdfs4ds.SCHEMA = "<feature store database>"')
        else:
            logger.info("Default database detected for feature store: %s", SCHEMA)
            logger.info('tdfs4ds.SCHEMA = "%s"', SCHEMA)
    else:
        logger.info("SCHEMA already configured: %s", SCHEMA)

    if DATA_DOMAIN is None and SCHEMA is not None:
        DATA_DOMAIN = SCHEMA
        logger.info("DATA_DOMAIN not set. Defaulting to SCHEMA: %s", DATA_DOMAIN)
        logger.info('You can override it using: tdfs4ds.DATA_DOMAIN = "<your data domain>"')

except Exception as e:
    logger.error("Could not determine current database: %s", str(e).split('\n')[0])
    logger.warning("Please specify the feature store database manually:")
    logger.warning('tdfs4ds.SCHEMA = "<feature store database>"')


# ---------------------------------------------------------------------------
# Public API — imported from sub-modules and re-exported here so that all
# existing call sites (e.g. tdfs4ds.setup(), tdfs4ds.upload_features()) work
# without any changes.
# ---------------------------------------------------------------------------

from tdfs4ds.lifecycle import setup, connect

from tdfs4ds.data_domain import (
    get_data_domains,
    select_data_domain,
    create_data_domain,
)

from tdfs4ds.catalog import (
    feature_catalog,
    process_catalog,
    dataset_catalog,
    get_dataset_entity,
    get_dataset_features,
)

from tdfs4ds.process_store.process_query_administration import get_process_id

from tdfs4ds.execution import (
    run,
    upload_features,
    _upload_features,
    _compute_features_batch,
    upload_tdstone2_scores,
    roll_out,
)

from tdfs4ds.dataset.builder import (
    build_dataset,
    build_dataset_opt,
    augment_source_with_features,
)

from tdfs4ds.cli import (
    install_skills,
    install_skills_global,
    install_skills_local,
    export_skills,
    list_skills,
    skill_path,
    skill_prompt,
    skill_catalog,
    consumer_agent_skill_catalog,
    query_optimizer_skill_catalog,
)

def __getattr__(name: str):
    """Lazy-load heavy optional modules (genai, agent) on first access.

    Keeps ``import tdfs4ds`` fast by deferring LangChain / LangGraph / pandas
    imports until the functions that need them are first called.
    """
    if name == "genai":
        import sys as _sys
        import importlib as _importlib
        # Pre-register a placeholder so importlib._handle_fromlist sees the
        # attribute as already set and does NOT call hasattr(tdfs4ds, 'genai')
        # again, which would re-enter this function and cause infinite recursion.
        _sys.modules[__name__].__dict__['genai'] = None
        try:
            _genai = _importlib.import_module('tdfs4ds.genai')
            _sys.modules[__name__].__dict__['genai'] = _genai
            return _genai
        except Exception:
            _sys.modules[__name__].__dict__.pop('genai', None)
            raise

    _OPTIMIZER_EXPORTS = frozenset({
        "query_optimizer", "aquery_optimizer",
        "skill_optimize_query", "skill_generate_candidates", "display_optimization_result",
        "skill_simplify_query", "simplify_query",
    })
    if name in _OPTIMIZER_EXPORTS:
        from tdfs4ds.agent.query_optimizer import (
            query_optimizer,
            aquery_optimizer,
            skill_optimize_query,
            skill_generate_candidates,
            display_optimization_result,
            skill_simplify_query,
            simplify_query,
        )
        import sys as _sys
        _mod = _sys.modules[__name__]
        _mod.query_optimizer = query_optimizer
        _mod.aquery_optimizer = aquery_optimizer
        _mod.skill_optimize_query = skill_optimize_query
        _mod.skill_generate_candidates = skill_generate_candidates
        _mod.display_optimization_result = display_optimization_result
        _mod.skill_simplify_query = skill_simplify_query
        _mod.simplify_query = simplify_query
        return locals()[name]

    _QO_AGENT_EXPORTS = frozenset({
        "query_optimizer_agent", "reset_query_optimizer_agent",
    })
    if name in _QO_AGENT_EXPORTS:
        from tdfs4ds.agent.query_optimizer_graph import (
            query_optimizer_agent,
            reset_query_optimizer_agent,
        )
        import sys as _sys
        _mod = _sys.modules[__name__]
        _mod.query_optimizer_agent = query_optimizer_agent
        _mod.reset_query_optimizer_agent = reset_query_optimizer_agent
        return locals()[name]

    raise AttributeError(f"module 'tdfs4ds' has no attribute {name!r}")
