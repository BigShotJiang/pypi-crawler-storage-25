from __future__ import annotations  # keeps type hints as strings — no import needed at parse time

import pandas as pd
from typing import Sequence, Optional, Dict, Any, List, Set, Tuple
import textwrap

# langchain_openai, langchain_core, and sqlparse are imported lazily inside the
# functions that need them.  This avoids a 30-40 s startup penalty on every
# plain `import tdfs4ds`, since LangChain's first-time module load is expensive.
from IPython.display import HTML, display

import tdfs4ds
from tdfs4ds import logger_safe
from tdfs4ds.cli import skill_prompt

import teradataml as tdml
import json
import ast
import re
import unicodedata

from teradataml.context.context import _get_database_username
import pandas as pd

from tdfs4ds.process_store.process_store_catalog_management import get_process_info


def _robust_json_parser(response: str) -> Dict[str, Any]:
    """
    Robustly extract and parse JSON from LLM responses.
    Handles markdown code fences, escaped characters, and formatting variations.
    
    Parameters
    ----------
    response : str
        The raw response string from the LLM.
    
    Returns
    -------
    dict
        The parsed JSON as a dictionary.
    
    Raises
    ------
    ValueError
        If JSON cannot be extracted or parsed from the response.
    """
    if not isinstance(response, str):
        raise ValueError(f"Expected string response, got {type(response)}")
    
    # Try 1: Direct JSON parse (response might already be clean)
    try:
        return json.loads(response.strip(), strict=False)
    except json.JSONDecodeError:
        pass
    
    # Try 2: Extract from markdown code fences (most flexible)
    # Match opening backticks (with optional json language specifier) and closing backticks
    # Using non-greedy matching with DOTALL to handle multiline content
    markdown_patterns = [
        r'```(?:json)?\s*\n(.*)\n```',         # ```json\n...\n``` (any content in middle)
        r'```(?:json)?\s*\r?\n(.*?)\r?\n```',  # Handle Windows line endings
        r'```(?:json)?\s*(.*?)\s*```',         # ```...``` (flexible whitespace)
        r'`{3}\s*(?:json)?\s*(.*?)\s*`{3}',    # Alternative triple backticks
    ]
    for pattern in markdown_patterns:
        match = re.search(pattern, response, re.DOTALL | re.IGNORECASE)
        if match:
            try:
                extracted = match.group(1).strip()
                # Normalize line endings
                extracted = extracted.replace('\r\n', '\n').replace('\r', '\n')
                if extracted:  # Only try if we got something
                    return json.loads(extracted, strict=False)
            except (json.JSONDecodeError, IndexError):
                pass
    
    # Try 3: Extract first { ... } block (handles extra text before/after)
    first_brace = response.find('{')
    last_brace = response.rfind('}')
    if first_brace != -1 and last_brace > first_brace:
        try:
            extracted = response[first_brace:last_brace+1]
            # Normalize line endings
            extracted = extracted.replace('\r\n', '\n').replace('\r', '\n')
            return json.loads(extracted, strict=False)
        except json.JSONDecodeError:
            pass
    
    # Try 4: Remove markdown fences and retry
    # Aggressively strip all markdown code fence markers
    cleaned = response.strip()
    cleaned = re.sub(r'^```\s*(?:json)?\s*', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s*```\s*$', '', cleaned)
    cleaned = re.sub(r'^`+\s*', '', cleaned)
    cleaned = re.sub(r'\s*`+$', '', cleaned)
    cleaned = cleaned.strip()
    # Normalize line endings
    cleaned = cleaned.replace('\r\n', '\n').replace('\r', '\n')
    try:
        return json.loads(cleaned, strict=False)
    except json.JSONDecodeError:
        pass
    
    # Try 5: Repair common JSON formatting mistakes then retry all extractions.
    # LLMs sometimes omit the comma between fields, add trailing commas, or use
    # blank lines between fields without the required comma separator.
    def _repair_json(text: str) -> str:
        # Insert missing comma when a closing " or digit/bool/null at line-end
        # is immediately followed (possibly across blank lines) by a new JSON key.
        text = re.sub(r'(")\s*\n(\s*")',           r'\1,\n\2', text)
        text = re.sub(r'(\d)\s*\n(\s*")',           r'\1,\n\2', text)
        text = re.sub(r'(true|false|null)\s*\n(\s*")', r'\1,\n\2', text,
                      flags=re.IGNORECASE)
        # Remove trailing commas before closing brace/bracket
        text = re.sub(r',\s*([}\]])', r'\1', text)
        return text

    # Apply repair to the best candidate we have (cleaned from Try 4)
    repaired = _repair_json(cleaned)
    try:
        return json.loads(repaired, strict=False)
    except json.JSONDecodeError:
        pass

    # Also try repair on the raw { ... } extraction from Try 3
    if first_brace != -1 and last_brace > first_brace:
        repaired_raw = _repair_json(
            response[first_brace:last_brace + 1].replace('\r\n', '\n').replace('\r', '\n')
        )
        try:
            return json.loads(repaired_raw)
        except json.JSONDecodeError:
            pass

    # Try 6: As a last resort, try ast.literal_eval (for Python-like dicts)
    try:
        import ast
        cleaned = cleaned.replace('\r\n', '\n').replace('\r', '\n')
        return ast.literal_eval(cleaned)
    except (ValueError, SyntaxError):
        pass

    # If all else fails, raise informative error
    logger_safe('error', f'Failed to parse JSON from LLM response. Full response: {response}')
    raise ValueError(f"Could not extract valid JSON from response. First 200 chars: {response[:200]}")


# HTML Styling Constants
HTML_STYLES = {
    "container": "font-family: Arial, sans-serif; margin: 10px 0;",
    "title": "color: #1f618d; margin-bottom: 6px;",
    "heading": "color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px;",
    "heading_margin": "color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px; margin-top: 15px;",
    "content": "background-color: #ecf0f1; padding: 10px; border-radius: 5px; line-height: 1.6;",
    "list": "background-color: #ecf0f1; padding: 15px 30px; border-radius: 5px; line-height: 1.8;",
}


def _is_notebook() -> bool:
    """Check if code is running in a Jupyter notebook."""
    try:
        # Check if IPython is available
        from IPython import get_ipython
        ipython = get_ipython()
        if ipython is None:
            return False
        
        # Check for notebook kernel
        if hasattr(ipython, 'kernel') and ipython.kernel is not None:
            return True
        
        # Check config for IPKernelApp (notebook kernel)
        if hasattr(ipython, 'config') and 'IPKernelApp' in ipython.config:
            return True
            
        # Check if it's a ZMQInteractiveShell (notebook shell)
        if ipython.__class__.__name__ == 'ZMQInteractiveShell':
            return True
            
        # Check for ipykernel in sys.modules
        import sys
        if 'ipykernel' in sys.modules:
            return True
            
        return False
    except (ImportError, AttributeError, Exception):
        return False


def _build_provider_llm_caller(llm: ChatOpenAI, provider: str, schema: Optional[Dict] = None):
    """
    Build a provider-specific LLM call wrapper for constrained output.

    Parameters
    ----------
    llm : ChatOpenAI
        The language model interface.
    provider : str
        The LLM provider (vllm, openai, ollama, azure, etc).
    schema : dict, optional
        JSON schema for constrained output.

    Returns
    -------
    callable
        A function that invokes the LLM with appropriate constraints.
    """
    if schema is None:
        return lambda messages: llm.invoke(messages)

    provider_l = provider.lower()

    if provider_l in ("vllm", "openai-compatible"):
        return lambda messages: llm.invoke(messages, extra_body={"guided_json": schema})
    
    if provider_l in ("openai", "azure", "azure-openai"):
        return lambda messages: llm.invoke(messages, response_format=schema)
    
    if provider_l == "ollama":
        return lambda messages: llm.invoke(messages, format=schema)
    
    # Fallback: no constraints
    return lambda messages: llm.invoke(messages)


def _print_documentation(
    documented_sql: str,
    entity_description: str,
    documented_entity_columns: Dict[str, str],
    documented_feature_columns: Dict[str, str],
    process_id: Optional[str] = None,
    view_name: Optional[str] = None,
    explain_analysis: Optional[str] = None,
    user_score: Optional[int] = None,
    optimization_score: Optional[int] = None,
    explain_warnings: Optional[List[str]] = None,
    explain_recommendations: Optional[List[str]] = None,
    sql_query: Optional[str] = None,
    explain_plan: Optional[str] = None,
    n_steps: Optional[int] = None,
    n_spool_objects: Optional[int] = None,
) -> None:
    """
    Pretty print documentation with context-aware formatting.
    Uses HTML in notebooks, text format in regular scripts.

    Parameters
    ----------
    documented_sql : str
        The query business logic description.
    entity_description : str
        The entity description.
    documented_entity_columns : dict
        Mapping of entity column names to descriptions.
    documented_feature_columns : dict
        Mapping of feature column names to descriptions.
    process_id : str, optional
        The process identifier for the title.
    view_name : str, optional
        The view name for the title.
    explain_analysis : str, optional
        The EXPLAIN plan analysis description.
    optimization_score : int, optional
        Optimization score from 1 to 5.
    explain_warnings : list, optional
        List of warnings from EXPLAIN analysis.
    explain_recommendations : list, optional
        List of recommendations from EXPLAIN analysis.
    sql_query : str, optional
        The original SQL query to display.
    explain_plan : str, optional
        The raw EXPLAIN plan output to display.
    """
    title = ''
    if process_id or view_name:
        title_parts = []
        if process_id:
            title_parts.append(f"Process: {process_id}")
        if view_name:
            title_parts.append(f"View: {view_name}")
        title = ' — '.join(title_parts)

    # Helpers to parse structured items and clean markdown (available in both contexts)
    def _try_parse_structured(value):
        if value is None:
            return None
        if isinstance(value, (dict, list)):
            return value
        if not isinstance(value, str):
            return value
        s = value.strip()
        # Try JSON
        try:
            return json.loads(s)
        except Exception:
            pass
        # Try Python literal
        try:
            return ast.literal_eval(s)
        except Exception:
            pass
        return s

    def _flatten_to_list(parsed):
        if parsed is None:
            return []
        if isinstance(parsed, list):
            out = []
            for it in parsed:
                out.extend(_flatten_to_list(it))
            return out
        if isinstance(parsed, dict):
            # Prefer obvious value keys, else format key: value pairs
            for k in ("issue", "warning", "action", "recommendation", "msg", "message"):
                if k in parsed:
                    return [str(parsed[k])]
            return ["; ".join(f"{kk}: {vv}" for kk, vv in parsed.items())]
        return [str(parsed)]

    def _strip_md(s: str) -> str:
        # Remove **bold** and inline markdown emphasis for plain text
        s = re.sub(r"\*\*(.*?)\*\*", r"\1", s)
        s = re.sub(r"\*(.*?)\*", r"\1", s)
        return s

    def _md_to_html(s: str) -> str:
        # Convert **bold** to <strong>
        s = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", s)
        s = re.sub(r"\*(.*?)\*\*", r"<em>\1</em>", s)
        # Escape simple < and > to avoid broken HTML (keep basic newlines)
        s = s.replace("<", "&lt;").replace(">", "&gt;")
        # Restore our strong/em tags
        s = s.replace("&lt;strong&gt;", "<strong>").replace("&lt;/strong&gt;", "</strong>")
        s = s.replace("&lt;em&gt;", "<em>").replace("&lt;/em&gt;", "</em>")
        return s

    # Build EXPLAIN section if available
    parsed_explain = _try_parse_structured(explain_analysis)
    parsed_warnings = _try_parse_structured(explain_warnings)
    parsed_recs = _try_parse_structured(explain_recommendations)

    warn_list = _flatten_to_list(parsed_warnings)
    rec_list = _flatten_to_list(parsed_recs)

    explain_section = ""
    newline = '\n'
    if parsed_explain or optimization_score or user_score or warn_list or rec_list:
        def _score_color(s):
            return "#27ae60" if s and s >= 4 else "#f39c12" if s and s == 3 else "#e74c3c"

        user_score_html = (
            f'<span style="color: {_score_color(user_score)}; font-size: 18px; font-weight: bold;">{user_score}/5</span>'
            if user_score is not None else '<span style="color: #999;">N/A</span>'
        )
        global_score_html = (
            f'<span style="color: {_score_color(optimization_score)}; font-size: 18px; font-weight: bold;">{optimization_score}/5</span>'
            if optimization_score is not None else '<span style="color: #999;">N/A</span>'
        )
        steps_html = (
            f'<span style="font-size: 18px; font-weight: bold;">{n_steps}</span>'
            if n_steps is not None else '<span style="color: #999;">N/A</span>'
        )
        spools_html = (
            f'<span style="font-size: 18px; font-weight: bold;">{n_spool_objects}</span>'
            if n_spool_objects is not None else '<span style="color: #999;">N/A</span>'
        )
        explain_section = f"""
            <h3 style="{HTML_STYLES['heading_margin']}">Query Optimization Analysis</h3>
            <div style="background-color: #ecf0f1; padding: 10px; border-radius: 5px; margin-bottom: 10px; display: flex; gap: 30px;">
                <p style="margin: 0;"><strong>Your SQL score:</strong> {user_score_html}
                    <span style="font-size: 11px; color: #666; margin-left: 6px;">what you control</span></p>
                <p style="margin: 0;"><strong>Overall score:</strong> {global_score_html}
                    <span style="font-size: 11px; color: #666; margin-left: 6px;">incl. infrastructure</span></p>
                <p style="margin: 0;"><strong>Steps:</strong> {steps_html}
                    <span style="font-size: 11px; color: #666; margin-left: 6px;">execution plan depth</span></p>
                <p style="margin: 0;"><strong>Spool objects:</strong> {spools_html}
                    <span style="font-size: 11px; color: #666; margin-left: 6px;">intermediate materializations</span></p>
            </div>
            """

        if parsed_explain:
            # Display explanation as plain text, preserving newlines
            explain_text = parsed_explain if isinstance(parsed_explain, str) else str(parsed_explain)
            explain_text_html = explain_text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace(newline, '<br>')
            explain_section += f'<div style="{HTML_STYLES["content"]}">{explain_text_html}</div>'

        if warn_list:
            warnings_html = '\n'.join(f'<li style="color: #c0392b;">{_md_to_html(w).replace(newline,"<br>")}</li>' for w in warn_list)
            explain_section += f"""
            <h4 style="color: #c0392b; margin-top: 10px;">⚠ Warnings</h4>
            <ul style="{HTML_STYLES['list']}">{warnings_html}</ul>
            """

        if rec_list:
            recommendations_html = '\n'.join(f'<li style="color: #27ae60;">{_md_to_html(r).replace(newline,"<br>")}</li>' for r in rec_list)
            explain_section += f"""
            <h4 style="color: #27ae60; margin-top: 10px;">✓ Recommendations</h4>
            <ul style="{HTML_STYLES['list']}">{recommendations_html}</ul>
            """

    if _is_notebook():
        title_html = f"<h2>{title}</h2>" if title else ""
        entity_items = (
            '\n'.join(f'<li><strong>{col}:</strong> {_md_to_html(desc)}</li>'
                    for col, desc in documented_entity_columns.items())
            if documented_entity_columns is not None
            else "<li><em>No entity columns documented.</em></li>"
            )

        feature_items = (
            '\n'.join(f'<li><strong>{col}:</strong> {_md_to_html(desc)}</li>'
                    for col, desc in documented_feature_columns.items())
            if documented_feature_columns is not None
            else "<li><em>No feature columns documented.</em></li>"
        )

        
        # Build optional sections
        import sqlparse  # lazy — only load when actually rendering HTML documentation
        sql_section = ""
        if sql_query:
            formatted_sql = sqlparse.format(sql_query, reindent=True, keyword_case='upper')
            sql_section = f"""
            <h3 style="{HTML_STYLES['heading_margin']}">Original SQL Query</h3>
            <pre style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; border: 1px solid #dee2e6; font-family: 'Courier New', monospace; font-size: 12px; overflow-x: auto; white-space: pre-wrap;">{formatted_sql}</pre>
            """
        
        explain_plan_section = ""
        if explain_plan:
            explain_plan_section = f"""
            <h3 style="{HTML_STYLES['heading_margin']}">EXPLAIN Plan</h3>
            <pre style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; border: 1px solid #dee2e6; font-family: 'Courier New', monospace; font-size: 12px; overflow-x: auto; white-space: pre-wrap;">{explain_plan}</pre>
            """
        
        html_content = f"""
        <div style="{HTML_STYLES['container']}">
        {title_html}
        <h3 style="{HTML_STYLES['heading']}">Query Business Logic</h3>
        <p style="{HTML_STYLES['content']}">{documented_sql}</p>
        
        <h3 style="{HTML_STYLES['heading_margin']}">Entity Description</h3>
        <p style="{HTML_STYLES['content']}">{entity_description}</p>
        
        <h3 style="{HTML_STYLES['heading_margin']}">Entity Columns</h3>
        <ul style="{HTML_STYLES['list']}">{entity_items}</ul>
        
        <h3 style="{HTML_STYLES['heading_margin']}">Feature Columns</h3>
        <ul style="{HTML_STYLES['list']}">{feature_items}</ul>
        
        {explain_section}
        {sql_section}
        {explain_plan_section}
        </div>
        """
        display(HTML(html_content))
    else:
        # Text formatting for regular scripts
        print("\n" + "="*100)
        print(title if title else "DOCUMENTATION")
        print("="*100)
        print("\nQuery Business Logic:")
        print(textwrap.fill(documented_sql, width=100))
        
        print("\nEntity Description:")
        print(textwrap.fill(entity_description, width=100))
        
        print("\nEntity Columns Documentation:")
        for col, desc in documented_entity_columns.items():
            print(f"\n  {col}:")
            print(textwrap.fill(desc, width=95, initial_indent="    ", subsequent_indent="    "))
        
        print("\nFeature Columns Documentation:")
        for col, desc in documented_feature_columns.items():
            print(f"\n  {col}:")
            print(textwrap.fill(desc, width=95, initial_indent="    ", subsequent_indent="    "))
        
        # Print EXPLAIN analysis if available
        if explain_analysis or optimization_score or user_score or explain_warnings or explain_recommendations:
            print("\n" + "-"*100)
            print("QUERY OPTIMIZATION ANALYSIS")
            print("-"*100)

            if user_score is not None:
                print(f"Your SQL score   : {user_score}/5  (what you control)")
            if optimization_score is not None:
                print(f"Overall score    : {optimization_score}/5  (incl. infrastructure)")
            
            # Print parsed explanation, preserving carriage returns.
            if parsed_explain:
                print("\nExplanation:")
                if isinstance(parsed_explain, str):
                    print(parsed_explain)
                else:
                    print(str(parsed_explain))

            # Print warnings (flattened) preserving carriage returns
            if warn_list:
                print("\nWarnings:")
                for w in warn_list:
                    print(f"  - {w}")

            # Print recommendations (flattened) preserving carriage returns
            if rec_list:
                print("\nRecommendations:")
                for r in rec_list:
                    print(f"  - {r}")

        # Print original SQL query if provided
        if sql_query:
            print("\n" + "-"*100)
            print("ORIGINAL SQL QUERY")
            print("-"*100)
            formatted_sql = sqlparse.format(sql_query, reindent=True, keyword_case='upper')
            print(textwrap.indent(formatted_sql, '    '))

        # Print EXPLAIN plan if provided
        if explain_plan:
            print("\n" + "-"*100)
            print("EXPLAIN PLAN")
            print("-"*100)
            print(explain_plan)

        print("\n" + "="*100 + "\n")


def build_llm(
    llm_service: str = "https://api-dmproject.myddns.me/v1",
    api_key: str = "YOUR_API_KEY_HERE",
    model_id: str = "mistralai/Ministral-3-14B-Instruct-2512",
    temperature: float = 0.0,
    timeout: int = 120,
) -> ChatOpenAI:
    """
    Build and return a ChatOpenAI client pointed at your vLLM/OpenAI-compatible endpoint.

    Parameters
    ----------
    llm_service : str
        Base URL of the LLM service.
    api_key : str
        API key for authentication.
    model_id : str
        Model identifier.
    temperature : float
        Sampling temperature for response diversity.
    timeout : int
        Request timeout in seconds.

    Returns
    -------
    ChatOpenAI
        Configured LLM client.

    Raises
    ------
    Exception
        If LLM client creation fails.
    """
    from langchain_openai import ChatOpenAI  # lazy — only load when building an LLM client
    logger_safe('info', f'build_llm: Using LLM service at {llm_service} with model {model_id}')
    logger_safe('debug', f'build_llm: Temperature={temperature}, Timeout={timeout}s')

    try:
        return ChatOpenAI(
            base_url=llm_service,
            api_key=api_key,
            model=model_id,
            temperature=temperature,
            timeout=timeout,
            seed=42,
        )
    except Exception as e:
        logger_safe('error', f'build_llm: Failed to create LLM client: {e}')
        raise


from typing import Sequence

def build_documentation_json_schema(columns: List[str], provider: str = "generic") -> Dict[str, Any]:
    """
    Build a provider-appropriate JSON Schema used to enforce strict JSON output
    for SQL column documentation across multiple LLM backends.

    This function returns different schema shapes depending on the LLM provider,
    because each ecosystem uses a different structured-output mechanism:

    Provider Modes
    --------------
    - provider="openai", "azure"
        Returns the JSON Schema wrapped in OpenAI's `response_format={"type": "json_schema", ...}`
        structure. Supported by GPT-4.1, GPT-4o, GPT-3.5-Turbo, and Azure OpenAI.

    - provider="anthropic", "claude"
        Returns an Anthropic *tool schema* definition. Claude 3.x models use tool
        schemas to enforce strict JSON output.

    - provider="ollama"
        Returns the raw JSON schema that Ollama expects under the `format=` parameter
        of the generate API. (Ollama 0.2+ supports response schemas.)

    - provider="vllm"
        Returns plain JSON Schema for use with vLLM's `guided_json` constrained decoding.

    - provider="bedrock"
        Bedrock Claude follows the Anthropic tool schema format.
        Bedrock Llama / Titan accept plain JSON schema. This function returns the base
        schema and leaves the final wrapping to the caller.

    - provider="generic"
        Returns plain JSON schema. Useful for LLM backends that do not support
        constrained decoding, prompt-only JSON generation, or post-processing repair.

    Parameters
    ----------
    columns : list[str]
        Column names to include as required JSON object keys. Each column will map
        to a string description generated by the model.

    provider : str, optional
        The model provider or backend type. Determines the structural format
        required for constrained generation. One of:
        "openai", "anthropic", "ollama", "vllm", "bedrock", "generic".

    Returns
    -------
    dict
        A dictionary representing the JSON Schema or provider-specific wrapper
        used to enforce strict JSON output during LLM generation.

    Notes
    -----
    - All schemas require that:
        * the output be a JSON object
        * keys match exactly the column names
        * all values be strings
        * additional properties be disallowed

    - Not all providers enforce schemas equally:
        * OpenAI, Claude, and vLLM offer hard guarantees.
        * Ollama enforces schema reasonably well.
        * Generic models may require post-processing.
    """
    # Base JSON schema — used directly by vLLM, Ollama, Bedrock, fallback
    base_schema = {
        "type": "object",
        "properties": {col: {"type": "string"} for col in columns},
        "required": list(columns),
        "additionalProperties": False,
    }

    # --- Provider-specific formats ---

    if provider.lower() in ("openai", "azure", "azure-openai"):
        # OpenAI's required wrapper structure
        return {
            "type": "json_schema",
            "json_schema": {
                "name": "ColumnDocumentation",
                "schema": base_schema,
                "strict": True,
            }
        }

    if provider.lower() in ("anthropic", "claude"):
        # Anthropic tool schema
        # You embed this inside the "tools" field when calling the model
        return {
            "name": "column_documentation",
            "description": "Generate documentation for SQL output columns.",
            "input_schema": base_schema
        }

    if provider.lower() == "ollama":
        # Ollama's output format schema (unwrapped JSON schema)
        # Returned directly in: generate(..., format=schema)
        return base_schema

    if provider.lower() in ("vllm", "openai-compatible"):
        # vLLM's guided_json uses *plain JSON Schema*
        # so return base_schema exactly
        return base_schema

    if provider.lower() == "bedrock":
        # Bedrock Claude uses Anthropic schema
        # Bedrock Llama uses plain JSON schema
        # Return base_schema and let caller choose
        return base_schema

    # Fallback: generic JSON schema
    return base_schema

def build_sql_documentation_chain(
    llm: ChatOpenAI,
    entity_columns: Sequence[str],
    feature_columns: Sequence[str],
    provider: str = "vllm",
    json_constraint: bool = True,
    prompt_only: bool = False
) -> Runnable:
    """
    Build a LangChain Runnable that generates business-focused documentation
    for lists of entity and feature columns from a SQL query output, with optional provider-specific JSON
    constraints (vLLM, OpenAI, Ollama, etc.).

    The resulting chain expects two input variables:
        - sql_query: str         → the SQL query whose output is being documented
        - columns_str: str       → formatted list of entity and feature columns (e.g. "Entity columns:\n- col1\n\nFeature columns:\n- col2")

    Parameters
    ----------
    llm : ChatOpenAI
        The language model interface (may point to vLLM, OpenAI, Ollama, etc.).
    entity_columns : Sequence[str]
        List of entity/identifier columns that must appear as keys in the output JSON.
    feature_columns : Sequence[str]
        List of feature columns that must appear as keys in the output JSON.
    provider : str, optional (default="vllm")
        Indicates which structured-output mechanism to use.
        Supported values:
            - "vllm"               → uses `guided_json` for strict JSON output
            - "openai" / "azure"   → uses OpenAI JSON Schema via `response_format`
            - "ollama"             → uses Ollama's `format=` schema
            - "openai-compatible"  → alias for vLLM-style guided decoding
            - any other value      → fall back to unconstrained text output
    json_constraint : bool, optional (default=True)
        If True:
            - a JSON Schema is generated from the column lists
            - provider-specific constrained decoding is applied
        If False:
            - the chain does not enforce JSON structure at the LLM level
            - the model is only guided by the prompt (weaker guarantees)
    prompt_only : bool, optional (default=False)
        If True:
            - returns only the prompt template, without attaching the LLM or parser
            - useful for debugging, testing, or customizing the prompt before execution
        If False:
            - returns the full chain: prompt → LLM (optionally schema-guided) → JSON parser

    Returns
    -------
    Runnable
        If prompt_only=False:
            A LangChain Runnable that executes:
                prompt → LLM (optionally schema-guided) → JSON parser
            When invoked with:
                {
                    "sql_query": "...",
                    "columns_str": "Entity columns:\n- column1\n\nFeature columns:\n- column2\n..."
                }
            It returns:
                dict[str, str]
                    A mapping of each requested column name to a short,
                    business-oriented description (≤ 5 sentences), plus a 'query_business_logic' key
                    containing a high-level description of the query's business logic (5-10 sentences), and an 'entity_description' key
                    with a holistic description of the entity (3-5 sentences).
        If prompt_only=True:
            The prompt template itself, for inspection or further customization.

    Notes
    -----
    - The chain enforces valid JSON when possible:
        * vLLM → `guided_json`
        * OpenAI → `response_format={"type": "json_schema", ...}`
        * Ollama → `format=<schema>`
    - For unsupported providers, the model may emit imperfect JSON.
    - Descriptions focus on business meaning, business logic,
      and optionally technical details only when relevant.
    """
    from langchain_core.prompts import ChatPromptTemplate   # lazy — only load when building a chain
    from langchain_core.output_parsers import JsonOutputParser
    from langchain_core.runnables import RunnableLambda
    from langchain_core.messages import AIMessage
    all_columns = entity_columns + feature_columns + ["query_business_logic", "entity_description"]
    logger_safe('info', f'build_sql_documentation_chain: Building chain for provider {provider}, json_constraint={json_constraint}, entity_columns={list(entity_columns)}, feature_columns={list(feature_columns)}')
    prompt = ChatPromptTemplate.from_template(skill_prompt("qo-document-sql"))
    parser = JsonOutputParser()
    if not json_constraint:
        return prompt | llm | parser

    schema = build_documentation_json_schema(all_columns, provider=provider)
    logger_safe('debug', f'build_sql_documentation_chain: Using provider {provider} with json_constraint={json_constraint}')

    # Use helper to build provider-specific LLM caller
    call_llm = _build_provider_llm_caller(llm, provider, schema)
    constrained_llm = RunnableLambda(call_llm)

    # Final chain: prompt -> LLM (schema-guided) -> JSON parser
    # Use _robust_json_parser so markdown-fenced responses (```json ... ```) are handled correctly.
    def _parse(ai_msg: AIMessage):
        raw = ai_msg.content
        return _robust_json_parser(raw)

    if prompt_only:
        return prompt
    else:
        return prompt | constrained_llm | RunnableLambda(_parse)

def run_sql_documentation(
    chain: Runnable,
    sql_query: str,
    entity_columns: Sequence[str],
    feature_columns: Sequence[str],
    language: str = "English",
    upstream_context: str = "",
) -> Dict[str, str]:
    """
    Execute a previously constructed SQL-documentation chain and return
    business-friendly documentation for the specified SQL output columns.

    This function prepares the chain inputs (SQL query, formatted column list,
    target language) and invokes the chain. The chain itself must have been
    created using `build_sql_documentation_chain()`, which ensures the model
    produces structured JSON suitable for parsing.

    Parameters
    ----------
    chain : Runnable
        A LangChain Runnable returned by `build_sql_documentation_chain()`.
        This Runnable encapsulates:
            - the prompt template
            - a provider-specific LLM invocation (with or without JSON constraints)
            - a JSON output parser

    sql_query : str
        The SQL query whose resulting columns should be documented. This query is
        shown to the model so it can infer business logic, derivation rules, and
        column meaning.

    entity_columns : Sequence[str]
        The list of entity/identifier column names that must appear as keys in the output JSON.
        Only these columns will be documented. The order does not matter.

    feature_columns : Sequence[str]
        The list of feature column names that must appear as keys in the output JSON.
        Only these columns will be documented. The order does not matter.

    language : str, optional (default="English")
        The target output language for the generated documentation.
        This value is passed into the prompt’s `{language}` variable.
        Examples: "English", "French", "German", "Spanish", "Japanese".

    Returns
    -------
    dict[str, str]
        A dictionary mapping each column name to a human-readable, business-oriented
        description generated by the model, plus a 'query_business_logic' key
        with the query's business logic description, and an 'entity_description' key
        with the holistic entity description. Example:
            {
                "customer_id": "Unique customer identifier used for ...",
                "order_date": "Business date when the order was created ...",
                "entity_description": "The customer entity represents...",
                "query_business_logic": "This query provides a view of ..."
            }

    Notes
    -----
    - The output format is determined by the chain's JSON parser. If the model
      fails to produce valid JSON (e.g., due to unsupported constraints),
      a `OutputParserException` may be raised.
    - The resulting descriptions are typically ≤ 5 sentences per column, unless
      modified in the chain's prompt.
    """
    logger_safe('info', f'run_sql_documentation: Starting documentation for {len(entity_columns)} entity columns and {len(feature_columns)} feature columns in {language}')
    columns_str = "Entity columns:\n" + "\n".join(f"- {col}" for col in entity_columns) + "\n\nFeature columns:\n" + "\n".join(f"- {col}" for col in feature_columns)

    try:
        result = chain.invoke({
            "sql_query": sql_query,
            "columns_str": columns_str,
            "language": language,
            "upstream_context": upstream_context,
        })
        if isinstance(result, dict):
            logger_safe('info', f'run_sql_documentation: Successfully generated documentation for columns: {list(result.keys())}')
        else:
            logger_safe('info', f'run_sql_documentation: Successfully generated documentation prompt')
        return result
    except Exception as e:
        logger_safe('error', f'run_sql_documentation: Failed to generate documentation: {e}')
        raise


def document_sql_query_columns(
    sql_query: str,
    entity_columns: Sequence[str],
    feature_columns: Sequence[str],
    language: str = "English",
    provider: Optional[str] = None,
    json_constraint: bool = True,
    prompt_only: bool = False,
    upstream_context: str = "",
) -> Dict[str, Any]:
    """
    Convenience function to generate business-focused documentation for SQL query output columns
    using the configured instruction model from tdfs4ds settings.

    This function automatically builds the LLM client using the tdfs4ds configuration variables
    (INSTRUCT_MODEL_URL, INSTRUCT_MODEL_API_KEY, INSTRUCT_MODEL_MODEL), constructs the documentation
    chain, and executes it to produce column descriptions.

    Parameters
    ----------
    sql_query : str
        The SQL query whose resulting columns should be documented. This query is
        shown to the model so it can infer business logic, derivation rules, and
        column meaning.

    entity_columns : Sequence[str]
        The list of entity/identifier column names that must appear as keys in the output JSON.
        Only these columns will be documented. The order does not matter.

    feature_columns : Sequence[str]
        The list of feature column names that must appear as keys in the output JSON.
        Only these columns will be documented. The order does not matter.

    language : str, optional (default="English")
        The target output language for the generated documentation.
        This value is passed into the prompt's {language} variable.
        Examples: "English", "French", "German", "Spanish", "Japanese".

    provider : str, optional (default=None)
        Indicates which structured-output mechanism to use for the LLM.
        If None, uses INSTRUCT_MODEL_PROVIDER from tdfs4ds config.
        Supported values:
            - "vllm"               → uses `guided_json` for strict JSON output
            - "openai" / "azure"   → uses OpenAI JSON Schema via `response_format`
            - "ollama"             → uses Ollama's `format=` schema
            - "openai-compatible"  → alias for vLLM-style guided decoding
            - any other value      → fall back to unconstrained text output

    json_constraint : bool, optional (default=True)
        If True:
            - a JSON Schema is generated from the column lists
            - provider-specific constrained decoding is applied
        If False:
            - the chain does not enforce JSON structure at the LLM level
            - the model is only guided by the prompt (weaker guarantees)

    prompt_only : bool, optional (default=False)
        If True:
            - returns only the prompt template, without executing the chain
            - useful for debugging, testing, or customizing the prompt before execution
        If False:
            - executes the full chain and returns structured documentation

    Returns
    -------
    dict
        If prompt_only=False:
            A dictionary with four keys:
                - "query_business_logic": str containing the high-level business logic description of the query
                - "entity_description": str containing the holistic description of the entity
                - "entity_columns": dict[str, str] mapping each entity column name to its description
                - "feature_columns": dict[str, str] mapping each feature column name to its description
        If prompt_only=True:
            The prompt template itself, for inspection or further customization.

    Raises
    ------
    ValueError
        If any of the required tdfs4ds configuration variables (INSTRUCT_MODEL_URL,
        INSTRUCT_MODEL_API_KEY, INSTRUCT_MODEL_MODEL, INSTRUCT_MODEL_PROVIDER) are not set.

    Notes
    -----
    - This function requires that the tdfs4ds instruction model configuration is properly set.
    - The resulting descriptions are typically ≤ 5 sentences per column, focusing on
      business meaning and logic.
    - If the model fails to produce valid JSON, an exception will be raised.
    """
    # Import the configuration variables
    from tdfs4ds import INSTRUCT_MODEL_URL, INSTRUCT_MODEL_API_KEY, INSTRUCT_MODEL_MODEL, INSTRUCT_MODEL_PROVIDER

    # Validate configuration
    _url_required = INSTRUCT_MODEL_PROVIDER not in ('openai', 'bedrock')
    if (_url_required and not INSTRUCT_MODEL_URL) or not INSTRUCT_MODEL_API_KEY or not INSTRUCT_MODEL_MODEL or not INSTRUCT_MODEL_PROVIDER:
        raise ValueError(
            "tdfs4ds instruction model configuration is incomplete. Please ensure "
            "INSTRUCT_MODEL_URL (not needed for openai/bedrock), INSTRUCT_MODEL_API_KEY, "
            "INSTRUCT_MODEL_MODEL, and INSTRUCT_MODEL_PROVIDER are set."
        )

    logger_safe('info', f'document_sql_query_columns: Starting documentation for {len(entity_columns)} entity columns and {len(feature_columns)} feature columns in {language}')

    if provider is None:
        provider = INSTRUCT_MODEL_PROVIDER

    # Build the LLM client
    llm = build_llm(
        llm_service=INSTRUCT_MODEL_URL,
        api_key=INSTRUCT_MODEL_API_KEY,
        model_id=INSTRUCT_MODEL_MODEL
    )

    # Build the documentation chain
    sql_doc_chain = build_sql_documentation_chain(llm, entity_columns, feature_columns, provider=provider, json_constraint=json_constraint, prompt_only=prompt_only)

    # Run the documentation
    result = run_sql_documentation(sql_doc_chain, sql_query, entity_columns, feature_columns, language=language, upstream_context=upstream_context)

    if prompt_only:
        logger_safe('info', f'document_sql_query_columns: Successfully generated the prompt to be used with a LLM to generate the documentation')
        return result
    else:
        # Separate entity columns, feature columns, entity description, and query logic
        entity_docs = {k: v for k, v in result.items() if k in entity_columns}
        feature_docs = {k: v for k, v in result.items() if k in feature_columns}
        entity_desc = result.get("entity_description", "")
        query_logic = result.get("query_business_logic", "")

        logger_safe('info', f'document_sql_query_columns: Successfully completed documentation for {len(entity_docs)} entity columns, {len(feature_docs)} feature columns, entity description and query logic')
        return {
            "query_business_logic": query_logic,
            "entity_description": entity_desc,
            "entity_columns": entity_docs,
            "feature_columns": feature_docs
        }


def _classify_you_items(you_items: list[str]) -> list[dict]:
    """Classify each ``[You]`` item by semantic category using a single LLM call.

    Returns a list of dicts ``{"item": ..., "category": ...}`` in the same order
    as the input.  Falls back to ``"OTHER"`` for every item when the LLM is not
    available or the call fails.

    Categories
    ----------
    UNCORRELATED_SCALAR_SUBQUERY
        Flags an uncorrelated scalar subquery (e.g. ``SELECT AVG(col) FROM t``)
        as causing redundant scans or per-row evaluation.  Teradata evaluates
        these once — this is a false positive.
    CROSS_JOIN_SINGLE_ROW
        Flags a CROSS JOIN to a single-row aggregate result as a Cartesian
        product.  1 x N = N rows, not a real performance problem.
    INFORMATIONAL
        The item explicitly states no action is needed, the query is already
        correct, or contradicts itself (e.g. "Teradata evaluates it once").
    PRODUCT_JOIN
        Real Cartesian product between multi-row tables.
    REDUNDANT_SCAN
        A table is scanned multiple times for a non-scalar reason (e.g. self-join).
    PI_MISMATCH
        Join on non-primary-index columns forcing data redistribution.
    TYPE_CAST
        Implicit type conversion in join or WHERE predicates.
    OTHER
        Any issue that does not match the above categories.
    """
    if not you_items:
        return []

    fallback = [{"item": item, "category": "OTHER"} for item in you_items]

    try:
        from tdfs4ds import (
            INSTRUCT_MODEL_URL, INSTRUCT_MODEL_API_KEY,
            INSTRUCT_MODEL_MODEL, INSTRUCT_MODEL_PROVIDER,
        )
        if not INSTRUCT_MODEL_API_KEY or not INSTRUCT_MODEL_MODEL or not INSTRUCT_MODEL_PROVIDER:
            return fallback
    except Exception:
        return fallback

    try:
        from langchain_core.messages import SystemMessage, HumanMessage

        llm = build_llm(
            llm_service=INSTRUCT_MODEL_URL or "https://api.openai.com/v1",
            api_key=INSTRUCT_MODEL_API_KEY,
            model_id=INSTRUCT_MODEL_MODEL,
        )

        system = skill_prompt("qo-classify-items")

        items_block = "\n".join(
            f"[{i}] {item}" for i, item in enumerate(you_items)
        )

        response = llm.invoke([
            SystemMessage(content=system),
            HumanMessage(content=items_block),
        ])
        raw = getattr(response, "content", None) or str(response)

        # Strip markdown fences if present
        import re as _re
        raw = _re.sub(r'^```(?:json)?\s*', '', raw.strip(), flags=_re.MULTILINE)
        raw = _re.sub(r'```\s*$', '', raw.strip(), flags=_re.MULTILINE)

        import json
        parsed = json.loads(raw)

        # Build result list, matching by index.
        # Unknown categories are kept as-is (not forced to OTHER) so they
        # surface in logs.  Any category not in _YOU_ITEM_FALSE_POSITIVE_CATEGORIES
        # is treated as a real issue regardless of its name.
        result = [{"item": item, "category": "OTHER"} for item in you_items]
        for entry in parsed:
            idx = entry.get("index")
            cat = (entry.get("category") or "OTHER").upper().strip()
            if isinstance(idx, int) and 0 <= idx < len(you_items):
                result[idx]["category"] = cat if cat else "OTHER"

        _cats = {r["category"] for r in result}
        _known = {
            "UNCORRELATED_SCALAR_SUBQUERY", "CROSS_JOIN_SINGLE_ROW",
            "INFORMATIONAL", "PRODUCT_JOIN", "REDUNDANT_SCAN",
            "PI_MISMATCH", "TYPE_CAST", "OTHER",
        }
        _unknown = _cats - _known
        if _unknown:
            logger_safe('info',
                '_classify_you_items: LLM returned unknown categories %s '
                '— treating as real issues (not filtered).',
                _unknown,
            )

        logger_safe('info',
            '_classify_you_items: classified %d items: %s',
            len(you_items), _cats,
        )
        return result

    except Exception as e:
        logger_safe('warning',
            '_classify_you_items: LLM classification failed (non-fatal): %s',
            str(e).splitlines()[0],
        )
        return fallback


# Categories that are known false positives in Teradata and should be
# filtered from the [You] item count before scoring.
_YOU_ITEM_FALSE_POSITIVE_CATEGORIES = frozenset({
    "UNCORRELATED_SCALAR_SUBQUERY",
    "CROSS_JOIN_SINGLE_ROW",
    "INFORMATIONAL",
})


def _compute_user_score_from_you_items(
    warnings: list,
    recommendations: list,
    explain_text: str = None,
    classify: bool = True,
) -> int:
    """Derive ``user_score`` deterministically from ``[You]``-prefixed items.

    The LLM identifies issues reliably (factual observations) but assigns
    numeric scores inconsistently — the same SQL can score 3/5 or 4/5
    depending on prompt context.  This function replaces the LLM-assigned
    score with a deterministic mapping based on the number and severity
    of ``[You]`` items the LLM identified:

    ===  ============================================
     5   No [You] items — no SQL-level issues found
     4   1 distinct issue
     3   2–3 distinct issues
     2   4+ issues **or** significant structural flaw
     1   Critical bug (Cartesian product, wrong results)
    ===  ============================================

    Parameters
    ----------
    classify : bool, default True
        When True, runs the LLM semantic classification to filter false-positive
        [You] items.  Set to False during intermediate scoring (e.g. the
        simplification baseline) where every [You] item should count so the
        optimizer has the raw signal to drive structural improvements.

    Scoring pipeline:

    1. Extract ``[You]``-prefixed warnings and recommendations.
    2. **LLM semantic classification** (when ``classify=True``) — each item is
       classified into a category via a single LLM call.  Items in
       false-positive categories are filtered out.
       Falls back to regex-based filtering when the LLM is unavailable.
       Skipped entirely when ``classify=False``.
    3. **EXPLAIN validation** (when ``explain_text`` is provided) — items
       that claim an issue not present in the raw EXPLAIN are filtered.
    4. **Severity classification + count mapping** — deterministic 1–5 score.
    """
    import re

    you_w = [w for w in (warnings or []) if isinstance(w, str) and w.startswith("[You]")]
    you_r = [r for r in (recommendations or []) if isinstance(r, str) and r.startswith("[You]")]

    if not you_w and not you_r:
        return 5

    # ── Step 1: LLM semantic classification ───────────────────────────────
    # Classify all [You] items in a single LLM call, then filter out
    # categories that are known Teradata false positives.
    # Skipped when classify=False (intermediate scoring during simplification).
    _llm_classified = False
    if classify:
        all_items_raw = [w[len("[You]"):].strip() for w in you_w] + \
                        [r[len("[You]"):].strip() for r in you_r]
        classified = _classify_you_items(all_items_raw)
        _llm_classified = any(c["category"] != "OTHER" for c in classified)

    if _llm_classified:
        # Split back into warnings and recommendations
        n_w = len(you_w)
        classified_w = classified[:n_w]
        classified_r = classified[n_w:]
        you_w = [you_w[i] for i, c in enumerate(classified_w)
                 if c["category"] not in _YOU_ITEM_FALSE_POSITIVE_CATEGORIES]
        you_r = [you_r[i] for i, c in enumerate(classified_r)
                 if c["category"] not in _YOU_ITEM_FALSE_POSITIVE_CATEGORIES]
    else:
        # Fallback: lightweight regex for self-evident non-actionable items only
        _non_actionable = re.compile(
            r"\bno action\b"
            r"|\bno changes?\b.{0,25}\brequired\b"
            r"|\balready (correct|optimal|efficient)\b"
            r"|\bdoes not need\b|\bdoesn.t need\b"
            r"|\bevaluates?\s+it\s+once\b"
            r"|\boptimizes?\s+it\s+to\s+a\s+single\b",
            re.IGNORECASE,
        )
        you_w = [w for w in you_w if not _non_actionable.search(w[len("[You]"):].strip())]
        you_r = [r for r in you_r if not _non_actionable.search(r[len("[You]"):].strip())]

    # ── Step 2: EXPLAIN-based validation ──────────────────────────────────
    # Cross-reference surviving [You] items against the raw EXPLAIN text.
    if explain_text:
        _signals = _parse_explain_signals(explain_text)

        if _signals:
            # Product join: if the EXPLAIN shows no product join, filter items
            # that claim one (the LLM may hallucinate from CROSS JOIN syntax).
            if not _signals.get("has_product_join"):
                _pj = re.compile(
                    r"\b(product\s+join|cartesian\s+product)\b", re.IGNORECASE,
                )
                you_w = [w for w in you_w if not _pj.search(w[len("[You]"):].strip())]
                you_r = [r for r in you_r if not _pj.search(r[len("[You]"):].strip())]

            # Duplicate scans: if no table is scanned more than once, filter
            # items claiming "scanned twice" or "redundant scan".
            if not _signals.get("has_duplicate_scans"):
                _ds = re.compile(
                    r"\bscann?ed\s+twice\b"
                    r"|\bredundant\b.{0,20}\bscan\b"
                    r"|\bscann?ed\s+two\s+times\b",
                    re.IGNORECASE,
                )
                you_w = [w for w in you_w if not _ds.search(w[len("[You]"):].strip())]
                you_r = [r for r in you_r if not _ds.search(r[len("[You]"):].strip())]

    # ── Step 3: Severity classification + count → score ───────────────────
    all_you = [item[len("[You]"):].strip() for item in you_w + you_r]

    if not all_you:
        return 5

    # A CROSS JOIN to a single-row scalar subquery (e.g. SELECT AVG(col) FROM t)
    # is a standard precomputation pattern — NOT a bug.  Exclude items that
    # mention this pattern from critical/significant severity detection.
    _scalar_safe = re.compile(
        r"\bsingle.row\b|\bscalar\b|\bone.row\b|\bconstant\b|\bthreshold\b",
        re.IGNORECASE,
    )

    def _is_severe(item: str, patterns: list[str]) -> bool:
        """True if *item* matches any severity pattern AND is not about a scalar subquery."""
        if _scalar_safe.search(item):
            return False
        return any(re.search(p, item, re.IGNORECASE) for p in patterns)

    # ── Critical bugs → score 1 ────────────────────────────────────────
    _critical = [
        r"\bcartesian\b.{0,30}\bmulti.row",
        r"\bincorrect\s+result",
        r"\bcritical\s+bug",
        r"\bproduct\s+join\b.{0,30}\blarge\b",
    ]
    for item in all_you:
        if _is_severe(item, _critical):
            return 1

    # ── Significant structural problems → score 2 ──────────────────────
    _significant = [
        r"\bmissing\b.{0,20}\bjoin\s+condition",
        r"\bunintended\b.{0,20}\bcross.product",
        r"\bSELECT\s+\*\b.{0,30}\bwide",
        r"\bfan.out\b",
    ]
    has_significant = any(_is_severe(item, _significant) for item in all_you)

    # ── Count distinct issues ──────────────────────────────────────────
    n_issues = max(len(you_w), len(you_r), 1)

    if has_significant or n_issues >= 4:
        return 2
    if n_issues >= 2:
        return 3
    return 4  # exactly 1 issue


def _parse_explain_metrics(explain_text: str) -> dict:
    """Extract deterministic execution metrics from raw Teradata EXPLAIN text.

    Returns a dict with:
    - ``n_steps``: number of numbered execution steps (e.g. ``  1) First, ...``)
    - ``n_spool_objects``: count of distinct ``Spool N`` references
    """
    import re

    if not explain_text or not isinstance(explain_text, str):
        return {"n_steps": None, "n_spool_objects": None}

    # Steps are numbered lines like "  1) First, we lock ..."
    n_steps = len(re.findall(r'^\s*\d+\)', explain_text, re.MULTILINE))

    # Spool references: "Spool 1", "Spool 2", etc. — count distinct IDs
    spool_ids = set(re.findall(r'\bSpool\s+(\d+)', explain_text, re.IGNORECASE))
    n_spool_objects = len(spool_ids)

    return {
        "n_steps": n_steps if n_steps > 0 else None,
        "n_spool_objects": n_spool_objects if n_spool_objects > 0 else None,
    }


def _parse_explain_signals(explain_text: str) -> dict:
    """Extract concrete execution signals from raw Teradata EXPLAIN text.

    Returns a dict of ground-truth signals that can be used to validate
    LLM-generated ``[You]`` items against what the EXPLAIN actually shows.

    Keys:
    - ``has_product_join``:  True if the EXPLAIN contains a real product join
    - ``table_scan_counts``: ``{TABLE_NAME: n_scans}`` — how many data-access
      steps read from each table (Spool reads excluded)
    - ``has_duplicate_scans``: True if any table is scanned more than once
    - ``has_redistribution``:  True if any step redistributes data by hash
    """
    import re

    if not explain_text or not isinstance(explain_text, str):
        return {}

    signals: dict = {}

    # ── Product joins ───────────────────────────────────────────────────
    # Teradata EXPLAIN uses the exact phrase "product join".
    signals["has_product_join"] = bool(
        re.search(r'\bproduct\s+join\b', explain_text, re.IGNORECASE)
    )

    # ── Table scan counts ───────────────────────────────────────────────
    # Data-access steps look like:
    #   "... step from DB_SOURCE.transactions by way of ..."
    #   "... step from "DB_SOURCE"."transactions" by way of ..."
    # Spool reads ("from Spool 2") are excluded.
    _scan_pattern = re.compile(
        r'\bstep\s+from\s+'
        r'("?[\w]+"?\s*\.\s*"?[\w]+"?)'  # schema.table (optionally quoted)
        r'\s+.*?\bby\s+way\s+of\b',
        re.IGNORECASE,
    )
    scan_counts: dict[str, int] = {}
    for m in _scan_pattern.finditer(explain_text):
        raw = m.group(1)
        # Normalise: strip quotes and whitespace, uppercase
        clean = raw.replace('"', '').replace(' ', '').upper()
        if clean.startswith('SPOOL'):
            continue
        scan_counts[clean] = scan_counts.get(clean, 0) + 1
    signals["table_scan_counts"] = scan_counts
    signals["has_duplicate_scans"] = any(c > 1 for c in scan_counts.values())

    # ── Redistribution ──────────────────────────────────────────────────
    signals["has_redistribution"] = bool(
        re.search(r'\bredistribut\w+\s+by\s+hash\b', explain_text, re.IGNORECASE)
    )

    return signals


def build_explain_documentation_chain(
    llm: ChatOpenAI,
    provider: str = "vllm",
    json_constraint: bool = True,
    prompt_only: bool = False
) -> Runnable:
    """
    Build a LangChain Runnable that analyzes SQL EXPLAIN plans and generates
    optimization scores, warnings, and recommendations.

    The resulting chain expects two input variables:
        - sql_query: str       → the original SQL query
        - explain_plan: str    → the EXPLAIN output from the database

    Parameters
    ----------
    llm : ChatOpenAI
        The language model interface (may point to vLLM, OpenAI, Ollama, etc.).
    provider : str, optional (default="vllm")
        Indicates which structured-output mechanism to use.
        Supported values:
            - "vllm"               → uses `guided_json` for strict JSON output
            - "openai" / "azure"   → uses OpenAI JSON Schema via `response_format`
            - "ollama"             → uses Ollama's `format=` schema
            - "openai-compatible"  → alias for vLLM-style guided decoding
            - any other value      → fall back to unconstrained text output
    json_constraint : bool, optional (default=True)
        If True: a JSON Schema is generated and provider-specific constrained decoding is applied.
        If False: the chain does not enforce JSON structure at the LLM level.

    Returns
    -------
    Runnable
        A LangChain Runnable that executes:
            prompt → LLM (optionally schema-guided) → JSON parser

        When invoked with:
            {
                "sql_query": "SELECT ...",
                "explain_plan": "..."
            }

        It returns:
            dict with keys:
                - "explanation": str describing the EXPLAIN plan in business terms
                - "optimization_score": int from 1 (poorly optimized) to 5 (well optimized)
                - "warnings": list[str] of potential issues or concerns
                - "recommendations": list[str] of actionable optimization suggestions
    """
    from langchain_core.prompts import ChatPromptTemplate   # lazy — only load when building a chain
    from langchain_core.output_parsers import JsonOutputParser
    from langchain_core.runnables import RunnableLambda
    from langchain_core.messages import AIMessage
    logger_safe('info', f'build_explain_documentation_chain: Building chain for provider {provider}, json_constraint={json_constraint}')

    # JSON schema for EXPLAIN analysis output
    explain_schema = {
        "type": "object",
        "properties": {
            "explanation": {"type": "string"},
            "user_score": {
                "type": "integer",
                "minimum": 0,
                "maximum": 5,
                "description": "Set to 0 — computed automatically from [You] items"
            },
            "global_score": {
                "type": "integer",
                "minimum": 1,
                "maximum": 5,
                "description": "Score reflecting overall execution quality including infrastructure (statistics, indexes, table design)"
            },
            "warnings": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of potential issues or concerns, prefixed with [You] or [Data Engineer / DBA]"
            },
            "recommendations": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of actionable optimization suggestions, prefixed with [You] or [Data Engineer / DBA]"
            }
        },
        "required": ["explanation", "user_score", "global_score", "warnings", "recommendations"],
        "additionalProperties": False
    }

    prompt = ChatPromptTemplate.from_template(skill_prompt("qo-explain"))
    parser = JsonOutputParser()
    if not json_constraint:
        return prompt | llm | parser

    logger_safe('debug', f'build_explain_documentation_chain: Using provider {provider} with json_constraint={json_constraint}')

    # Wrap schema for OpenAI providers
    if provider.lower() in ("openai", "azure", "azure-openai"):
        wrapped_schema = {
            "type": "json_schema",
            "json_schema": {
                "name": "ExplainAnalysis",
                "schema": explain_schema,
                "strict": True,
            }
        }
    else:
        wrapped_schema = explain_schema

    # Use helper to build provider-specific LLM caller
    call_llm = _build_provider_llm_caller(llm, provider, wrapped_schema)
    constrained_llm = RunnableLambda(call_llm)

    # Final chain: prompt -> LLM (schema-guided) -> JSON parser
    # Use _robust_json_parser so markdown-fenced responses (```json ... ```) are handled correctly.
    def _parse(ai_msg: AIMessage):
        raw = ai_msg.content
        return _robust_json_parser(raw)

    if prompt_only:
        return prompt
    else:
        return prompt | constrained_llm | RunnableLambda(_parse)


def run_explain_documentation(
    chain: Runnable,
    sql_query: str,
    explain_plan: str,
    classify: bool = True,
) -> Dict[str, Any]:
    """
    Execute an EXPLAIN-documentation chain and return optimization analysis.

    Parameters
    ----------
    chain : Runnable
        A LangChain Runnable returned by `build_explain_documentation_chain()`.
    sql_query : str
        The original SQL query.
    explain_plan : str
        The EXPLAIN output from the database.
    classify : bool, default True
        Pass through to ``_compute_user_score_from_you_items``.  Set to False
        during intermediate scoring (simplification, candidate evaluation)
        to keep the raw [You] count and avoid filtering useful structural signals.

    Returns
    -------
    dict
        A dictionary with keys: "explanation", "optimization_score", "warnings", "recommendations"
    """
    logger_safe('info', 'run_explain_documentation: Starting EXPLAIN analysis')
    
    try:
        result = chain.invoke({
            "sql_query": sql_query,
            "explain_plan": explain_plan
        })
        if isinstance(result, dict):
            # Override LLM-assigned user_score with deterministic computation
            # based on the number/severity of [You] items.  The LLM identifies
            # issues reliably but assigns scores inconsistently.
            llm_score = result.get("user_score")
            det_score = _compute_user_score_from_you_items(
                result.get("warnings", []),
                result.get("recommendations", []),
                explain_text=explain_plan,
                classify=classify,
            )
            if llm_score != det_score:
                logger_safe('debug',
                            'run_explain_documentation: overriding LLM user_score %s → %s (deterministic)',
                            llm_score, det_score)
            result["user_score"] = det_score
            # Inject deterministic execution metrics from raw EXPLAIN text
            metrics = _parse_explain_metrics(explain_plan)
            result["n_steps"] = metrics["n_steps"]
            result["n_spool_objects"] = metrics["n_spool_objects"]
            logger_safe('info', f'run_explain_documentation: Successfully analyzed EXPLAIN plan. '
                                f'User score: {result.get("user_score", "N/A")}/5, '
                                f'Global score: {result.get("global_score", "N/A")}/5, '
                                f'Steps: {metrics["n_steps"]}, Spool objects: {metrics["n_spool_objects"]}')
        else:
            logger_safe('info', 'run_explain_documentation: Successfully generated the prompt to be used with a LLM to generate the documentation')
        return result
    except Exception as e:
        logger_safe('error', f'run_explain_documentation: Failed to analyze EXPLAIN plan: {e}')
        raise


def document_sql_query_explain(
    sql_query: str,
    provider: Optional[str] = None,
    json_constraint: bool = True,
    prompt_only: bool = False,
    classify: bool = True,
) -> Dict[str, Any]:
    """
    Analyze a SQL query's EXPLAIN plan and return optimization recommendations.

    This function automatically builds the LLM client using tdfs4ds configuration,
    constructs the EXPLAIN analysis chain, and executes it.

    Parameters
    ----------
    sql_query : str
        The original SQL query.
    explain_plan : str
        The EXPLAIN output from the database.
    provider : str, optional (default=None)
        Indicates which structured-output mechanism to use for the LLM.
        If None, uses INSTRUCT_MODEL_PROVIDER from tdfs4ds config.
        Supported values: "vllm", "openai", "azure", "ollama", etc.
    json_constraint : bool, optional (default=True)
        If True: use provider-specific constrained decoding.
        If False: rely on prompt guidance only.

    Returns
    -------
    dict
        A dictionary with keys:
        - "explanation": str describing the EXPLAIN plan
        - "optimization_score": int from 1 to 5
        - "warnings": list[str] of potential issues
        - "recommendations": list[str] of actionable suggestions

    Raises
    ------
    ValueError
        If tdfs4ds instruction model configuration is incomplete.
    """
    from tdfs4ds import INSTRUCT_MODEL_URL, INSTRUCT_MODEL_API_KEY, INSTRUCT_MODEL_MODEL, INSTRUCT_MODEL_PROVIDER

    _url_required = INSTRUCT_MODEL_PROVIDER not in ('openai', 'bedrock')
    if (_url_required and not INSTRUCT_MODEL_URL) or not INSTRUCT_MODEL_API_KEY or not INSTRUCT_MODEL_MODEL or not INSTRUCT_MODEL_PROVIDER:
        raise ValueError(
            "tdfs4ds instruction model configuration is incomplete. Please ensure "
            "INSTRUCT_MODEL_URL (not needed for openai/bedrock), INSTRUCT_MODEL_API_KEY, "
            "INSTRUCT_MODEL_MODEL, and INSTRUCT_MODEL_PROVIDER are set."
        )

    logger_safe('info', 'document_sql_query_explain: Starting EXPLAIN analysis')

    if provider is None:
        provider = INSTRUCT_MODEL_PROVIDER

    # Build the LLM client
    llm = build_llm(
        llm_service=INSTRUCT_MODEL_URL,
        api_key=INSTRUCT_MODEL_API_KEY,
        model_id=INSTRUCT_MODEL_MODEL
    )

    # get the explain plan:
    explain_plan = get_the_explain(sql_query)
    # Build and run the EXPLAIN analysis chain
    explain_chain = build_explain_documentation_chain(llm, provider=provider, json_constraint=json_constraint, prompt_only = prompt_only)
    result = run_explain_documentation(explain_chain, sql_query, explain_plan, classify=classify)

    if prompt_only:
        logger_safe('info', f'document_sql_query_explain: Successfully completed EXPLAIN prompt generation')
    else:
        logger_safe('info', f'document_sql_query_explain: Successfully completed EXPLAIN analysis. '
                            f'User score: {result.get("user_score", "N/A")}/5, '
                            f'Global score: {result.get("global_score", "N/A")}/5, '
                            f'Steps: {result.get("n_steps", "N/A")}, '
                            f'Spool objects: {result.get("n_spool_objects", "N/A")}')
    return result

def documentation_tables_creation():
    """
    Create the necessary documentation tables in the database if they do not already exist.
    tdml: The tdfs4ds TDML connection object."""
    query_process_table = f"""
    CREATE MULTISET TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC} ,FALLBACK ,
         NO BEFORE JOURNAL,
         NO AFTER JOURNAL,
         CHECKSUM = DEFAULT,
         DEFAULT MERGEBLOCKRATIO,
         MAP = TD_MAP1
         (
          PROCESS_ID VARCHAR(36) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          BUSINESS_LOGIC_DESCRIPTION VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ENTITY_DESCRIPTION VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ENTITY_COLUMNS_JSON VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME)
    PRIMARY INDEX ( PROCESS_ID )
    """

    query_process_features_table = f"""
    CREATE MULTISET TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_FEATURES} ,FALLBACK ,
         NO BEFORE JOURNAL,
         NO AFTER JOURNAL,
         CHECKSUM = DEFAULT,
         DEFAULT MERGEBLOCKRATIO,
         MAP = TD_MAP1
         (
          PROCESS_ID VARCHAR(36) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          FEATURE_ID BIGINT NOT NULL,
          FEATURE_NAME VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          FEATURE_DESCRIPTION VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME)
    PRIMARY INDEX ( PROCESS_ID, FEATURE_ID )
    """

    query_process_explain_table = f"""
    CREATE MULTISET TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN} ,FALLBACK ,
         NO BEFORE JOURNAL,
         NO AFTER JOURNAL,
         CHECKSUM = DEFAULT,
         DEFAULT MERGEBLOCKRATIO,
         MAP = TD_MAP1
         (
          PROCESS_ID VARCHAR(36) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          EXPLAIN_ANALYSIS VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          USER_SCORE INT,
          OPTIMIZATION_SCORE INT,
          N_STEPS INT,
          N_SPOOL_OBJECTS INT,
          WARNINGS VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          RECOMMENDATIONS VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME)
    PRIMARY INDEX ( PROCESS_ID )
    """

    try:
        tdml.execute_sql(query_process_table)
        logger_safe('info', f'documentation_tables_creation: Created table {tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC}')
    except Exception as e:
        logger_safe('error', f'documentation_tables_creation: Failed to create table {tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC}: {e}')
        if 'already exists' in str(e).lower():
            logger_safe('info', f'documentation_tables_creation: Table {tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC} already exists. Skipping creation.')
            pass
        else:
            raise
    try:
        tdml.execute_sql(query_process_features_table)
        logger_safe('info', f'documentation_tables_creation: Created table {tdfs4ds.DOCUMENTATION_PROCESS_FEATURES}')
    except Exception as e:
        logger_safe('error', f'documentation_tables_creation: Failed to create table {tdfs4ds.DOCUMENTATION_PROCESS_FEATURES}: {e}')
        if 'already exists' in str(e).lower():
            logger_safe('info', f'documentation_tables_creation: Table {tdfs4ds.DOCUMENTATION_PROCESS_FEATURES} already exists. Skipping creation.')
            pass
        else:
            raise

    try:
        tdml.execute_sql(query_process_explain_table)
        logger_safe('info', f'documentation_tables_creation: Created table {tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN}')
    except Exception as e:
        logger_safe('error', f'documentation_tables_creation: Failed to create table {tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN}: {e}')
        if 'already exists' in str(e).lower():
            logger_safe('info', f'documentation_tables_creation: Table {tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN} already exists. Skipping creation.')
            # Migrate: add columns that may be missing from older schema versions.
            # Each ALTER is independent — a column may already exist in some installs.
            for _col_name, _col_def in [
                ("USER_SCORE", "INT"),
                ("N_STEPS", "INT"),
                ("N_SPOOL_OBJECTS", "INT"),
            ]:
                try:
                    tdml.execute_sql(
                        f"ALTER TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN} "
                        f"ADD {_col_name} {_col_def}"
                    )
                    logger_safe('info', f'documentation_tables_creation: Added {_col_name} column to {tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN}.')
                except Exception as alter_e:
                    if 'already exists' in str(alter_e).lower() or 'duplicate' in str(alter_e).lower():
                        pass  # column already present, nothing to do
                    else:
                        logger_safe('warning', f'documentation_tables_creation: Could not add {_col_name} column: {alter_e}')
        else:
            raise
    
    query_business_dictionary_objects_table = f"""
    CREATE MULTISET TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS} ,FALLBACK ,
         NO BEFORE JOURNAL,
         NO AFTER JOURNAL,
         CHECKSUM = DEFAULT,
         DEFAULT MERGEBLOCKRATIO,
         MAP = TD_MAP1
         (
          DATABASE_NAME        VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          OBJECT_NAME          VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          OBJECT_TYPE          CHAR(1)      CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          BUSINESS_DESCRIPTION VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME)
    PRIMARY INDEX ( DATABASE_NAME, OBJECT_NAME )
    """

    query_business_dictionary_columns_table = f"""
    CREATE MULTISET TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS} ,FALLBACK ,
         NO BEFORE JOURNAL,
         NO AFTER JOURNAL,
         CHECKSUM = DEFAULT,
         DEFAULT MERGEBLOCKRATIO,
         MAP = TD_MAP1
         (
          DATABASE_NAME        VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          TABLE_NAME           VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          COLUMN_NAME          VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          BUSINESS_DESCRIPTION VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME)
    PRIMARY INDEX ( DATABASE_NAME, TABLE_NAME, COLUMN_NAME )
    """

    try:
        tdml.execute_sql(query_business_dictionary_objects_table)
        logger_safe('info', f'documentation_tables_creation: Created table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS}')
    except Exception as e:
        logger_safe('error', f'documentation_tables_creation: Failed to create table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS}: {e}')
        if 'already exists' in str(e).lower():
            logger_safe('info', f'documentation_tables_creation: Table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS} already exists. Skipping creation.')
        else:
            raise

    try:
        tdml.execute_sql(query_business_dictionary_columns_table)
        logger_safe('info', f'documentation_tables_creation: Created table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS}')
    except Exception as e:
        logger_safe('error', f'documentation_tables_creation: Failed to create table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS}: {e}')
        if 'already exists' in str(e).lower():
            logger_safe('info', f'documentation_tables_creation: Table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS} already exists. Skipping creation.')
        else:
            raise

    query_business_dictionary_sections_table = f"""
    CREATE MULTISET TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS} ,FALLBACK ,
         NO BEFORE JOURNAL,
         NO AFTER JOURNAL,
         CHECKSUM = DEFAULT,
         DEFAULT MERGEBLOCKRATIO,
         MAP = TD_MAP1
         (
          DATABASE_NAME    VARCHAR(128)   CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          OBJECT_NAME      VARCHAR(128)   CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          SECTION_NAME     VARCHAR(128)   CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
          SECTION_CONTENT  VARCHAR(32000) CHARACTER SET LATIN NOT CASESPECIFIC,
          ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
          PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME)
    PRIMARY INDEX ( DATABASE_NAME, OBJECT_NAME, SECTION_NAME )
    """

    try:
        tdml.execute_sql(query_business_dictionary_sections_table)
        logger_safe('info', f'documentation_tables_creation: Created table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS}')
    except Exception as e:
        logger_safe('error', f'documentation_tables_creation: Failed to create table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS}: {e}')
        if 'already exists' in str(e).lower():
            logger_safe('info', f'documentation_tables_creation: Table {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS} already exists. Skipping creation.')
        else:
            raise

    logger_safe('info', 'documentation_tables_creation: Documentation tables creation process completed.')
    return


def migrate_documentation_explain_schema():
    """
    Ensure the FS_PROCESS_DOCUMENTATION_EXPLAIN table has all expected columns.

    Check-first: inspects the live DDL and only runs ALTER TABLE for columns that
    are actually missing.  No-op (and no log at INFO) when already up-to-date.

    Columns added over time:
    - USER_SCORE        (v0.2.x) — deterministic score from [You] items
    - N_STEPS           (v0.2.9) — EXPLAIN step count
    - N_SPOOL_OBJECTS   (v0.2.9) — distinct Spool object count

    New columns start as NULL for existing rows and are filled on the next
    ``document_process()`` or ``document_process_incremental()`` run.
    """
    # SHOW TABLE is a fast DDL catalog read — no data access, no row locks.
    try:
        _ddl = tdml.execute_sql(
            f"SHOW TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN}"
        ).fetchall()[0][0]
        _ddl_upper = _ddl.upper()
    except Exception:
        # SHOW TABLE failed (table may not exist yet) — nothing to migrate.
        return

    _columns_to_add = [
        ("USER_SCORE", "INT"),
        ("N_STEPS", "INT"),
        ("N_SPOOL_OBJECTS", "INT"),
    ]

    _any_added = False
    for col_name, col_type in _columns_to_add:
        if col_name in _ddl_upper:
            continue
        try:
            tdml.execute_sql(
                f"ALTER TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN} "
                f"ADD {col_name} {col_type}"
            )
            logger_safe('info',
                f'migrate_documentation_explain_schema: Added {col_name} column to '
                f'{tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN}. '
                f'Existing rows will show NULL until re-documented.')
            _any_added = True
        except Exception as e:
            logger_safe('warning',
                f'migrate_documentation_explain_schema: Could not add {col_name}: '
                f'{str(e).splitlines()[0]}')

    if not _any_added:
        logger_safe('debug',
            'migrate_documentation_explain_schema: All columns already present — skipping.')


def document_process(process_id: str, language: str = "English", json_constraint: bool = True, show_sql_query: bool = False, show_explain_plan: bool = False, display: bool = True, upload: bool = True, prompt_only = False) -> Optional[Dict[str, Any]]:
    """
    Generate and store documentation for a data process identified by process_id.
    This function retrieves the SQL query and output columns for the process,
    generates business-focused documentation using an LLM, and stores the results
    in the appropriate documentation tables.

    Parameters
    ----------
    process_id : str
        The unique identifier of the data process to document.

    language : str, optional (default="English")
        The target output language for the generated documentation. This value is   
        passed into the prompt’s `{language}` variable. Examples: "English", "French", "German", "Spanish", "Japanese".
    provider : str, optional (default=None)
        Indicates which structured-output mechanism to use for the LLM.
        If None, uses INSTRUCT_MODEL_PROVIDER from tdfs4ds config.
        Supported values:
            - "vllm"               → uses `guided_json` for strict JSON output
            - "openai" / "azure"   → uses OpenAI JSON Schema via `response_format`
            - "ollama"             → uses Ollama's `format=` schema
            - "openai-compatible"  → alias for vLLM-style guided decoding
            - any other value      → fall back to unconstrained text output
    json_constraint : bool, optional (default=True)
        If True:
            - a JSON Schema is generated from the column list
            - provider-specific constrained decoding is applied 
        If False:
            - the chain does not enforce JSON structure at the LLM level
            - the model is only guided by the prompt (weaker guarantees)
    show_sql_query : bool, optional (default=False)
        If True, display the original SQL query at the end of the documentation report.
    show_explain_plan : bool, optional (default=False)
        If True, display the raw EXPLAIN plan output at the end of the documentation report.
    display : bool, optional (default=True)
        If True, print the generated documentation to the console.
    upload_documentation : bool, optional (default=True)
        If True, upload the generated documentation to the documentation tables.

    Returns
    -------
    dict or None
        A dictionary containing the generated documentation and analysis, or None if an error occurred.
        The dictionary includes keys:
            - PROCESS_ID
            - DOCUMENTED_SQL
            - ENTITY_DESCRIPTION
            - DOCUMENTED_ENTITY_COLUMNS
            - DOCUMENTED_FEATURE_COLUMNS
            - EXPLAIN_ANALYSIS (if show_explain_plan is True)
            - OPTIMIZATION_SCORE (if show_explain_plan is True)
            - EXPLAIN_WARNINGS (if show_explain_plan is True)
            - EXPLAIN_RECOMMENDATIONS (if show_explain_plan is True)
            - RAW_EXPLAIN_PLAN (if show_explain_plan is True)
    Notes
    -----
    - This function requires that the tdfs4ds instruction model configuration is properly set.
    - If the model fails to produce valid JSON, an exception will be raised.
    - The resulting descriptions are typically ≤ 5 sentences per column, focusing on
      business meaning and logic.
    """
    logger_safe('info', f'document_process: Starting documentation for process_id {process_id} in {language}')

    # Retrieve process SQL and columns
    try:
        process_info = tdfs4ds.process_store.process_store_catalog_management.get_process_info(process_id)
    except Exception as e:
        logger_safe('error', f"document_process: Error retrieving process info for process_id {process_id}: {e}")
        return  
    
    documentation = document_sql_query_columns(
            sql_query       = process_info['PROCESS_SQL'],
            entity_columns  = process_info['ENTITY_COLUMNS'],
            feature_columns = process_info['FEATURE_COLUMNS'],
            prompt_only     = prompt_only
        )
    
    if prompt_only:
        process_info['PROMPT_BUSINESS_LOGIC_DESCRIPTION'] = documentation.messages[0].content
        logger_safe('info', 'Prompt available in the PROMPT_BUSINESS_LOGIC_DESCRIPTION field.')
        process_info['DOCUMENTED_SQL']             = None
        process_info['ENTITY_DESCRIPTION']         = None
        process_info['DOCUMENTED_ENTITY_COLUMNS']  = None
        process_info['DOCUMENTED_FEATURE_COLUMNS'] = None       
    else:
        process_info['DOCUMENTED_SQL']             = documentation['query_business_logic']
        process_info['ENTITY_DESCRIPTION']         = documentation['entity_description']
        process_info['DOCUMENTED_ENTITY_COLUMNS']  = documentation['entity_columns']
        process_info['DOCUMENTED_FEATURE_COLUMNS'] = documentation['feature_columns']

    explain_documentation = document_sql_query_explain(
            sql_query = process_info['PROCESS_SQL'],
            prompt_only=prompt_only
        )
    
    if prompt_only:
        process_info['PROMPT_EXPLAIN_THE_EXPLAIN'] = explain_documentation.messages[0].content
        logger_safe('info', 'Prompt available in the PROMPT_EXPLAIN_THE_EXPLAIN field.')
        process_info['EXPLAIN_ANALYSIS']           = None
        process_info['USER_SCORE']                 = None
        process_info['OPTIMIZATION_SCORE']         = None
        process_info['EXPLAIN_WARNINGS']           = None
        process_info['EXPLAIN_RECOMMENDATIONS']    = None
        process_info['EXPLAIN_N_STEPS']            = None
        process_info['EXPLAIN_N_SPOOL_OBJECTS']    = None
    else:
        process_info['EXPLAIN_ANALYSIS']           = explain_documentation['explanation']
        process_info['USER_SCORE']                 = explain_documentation['user_score']
        process_info['OPTIMIZATION_SCORE']         = explain_documentation['global_score']
        process_info['EXPLAIN_WARNINGS']           = explain_documentation['warnings']
        process_info['EXPLAIN_RECOMMENDATIONS']    = explain_documentation['recommendations']
        process_info['EXPLAIN_N_STEPS']            = explain_documentation.get('n_steps')
        process_info['EXPLAIN_N_SPOOL_OBJECTS']    = explain_documentation.get('n_spool_objects')
    
    # Store the raw EXPLAIN plan if needed for display
    if show_explain_plan:
        process_info['RAW_EXPLAIN_PLAN'] = get_the_explain(process_info['PROCESS_SQL'])
    
    # Upload the generated documentation to the documentation tables:
    if upload and prompt_only == False:
        upload_documentation(process_info)
        logger_safe('info', f'document_process: Uploaded documentation for process_id {process_id} to documentation tables.')
    
    if upload and prompt_only == False:
        upload_documentation_explain(process_info)
        logger_safe('info', f'document_process: Uploaded EXPLAIN analysis for process_id {process_id} to documentation tables.')

    # pretty print documentation for info:
    logger_safe('info', f"document_process: Documentation for process_id {process_id}:")

    if display:
        _print_documentation(
            documented_sql             = process_info.get('DOCUMENTED_SQL', None),
            entity_description         = process_info.get('ENTITY_DESCRIPTION', None),
            documented_entity_columns  = process_info.get('DOCUMENTED_ENTITY_COLUMNS', None),
            documented_feature_columns = process_info.get('DOCUMENTED_FEATURE_COLUMNS', None),
            process_id                 = process_info.get('PROCESS_ID', process_id),
            view_name                  = process_info.get('VIEW_NAME', None),
            explain_analysis           = process_info.get('EXPLAIN_ANALYSIS', None),
            user_score                 = process_info.get('USER_SCORE', None),
            optimization_score         = process_info.get('OPTIMIZATION_SCORE', None),
            explain_warnings           = process_info.get('EXPLAIN_WARNINGS', None),
            explain_recommendations    = process_info.get('EXPLAIN_RECOMMENDATIONS', None),
            sql_query                  = process_info.get('PROCESS_SQL', None) if show_sql_query else None,
            explain_plan               = process_info.get('RAW_EXPLAIN_PLAN', None) if show_explain_plan else None,
            n_steps                    = process_info.get('EXPLAIN_N_STEPS', None),
            n_spool_objects            = process_info.get('EXPLAIN_N_SPOOL_OBJECTS', None),
        )

    return process_info

def get_the_explain(sql_query: str) -> str:
    """
    Get the EXPLAIN plan for a given SQL query using the tdfs4ds TDML connection.

    Parameters
    ----------
    sql_query : str
        The SQL query to explain.

    Returns
    -------
    str
        The EXPLAIN plan as a formatted string.
    """
    def _extract_inner_query_from_view(query: str) -> str:
        """
        If the provided SQL is a CREATE/REPLACE VIEW (or REPLACE VIEW), extract and
        return the inner SELECT/definition. Otherwise return the original query.

        This helps when running EXPLAIN: we want to analyze the query inside the
        view definition rather than the DDL wrapper.
        """
        if not isinstance(query, str):
            return query
        pattern = r'^\s*(?:CREATE\s+(?:OR\s+REPLACE\s+)?|REPLACE\s+)?VIEW\b.*?\bAS\b\s*(?P<body>.*)$'
        m = re.search(pattern, query, flags=re.IGNORECASE | re.DOTALL)
        if not m:
            return query
        body = m.group('body').strip()
        # Strip outer parentheses if the definition is wrapped
        if body.startswith('(') and body.endswith(')'):
            body = body[1:-1].strip()
        # Remove trailing semicolon
        if body.endswith(';'):
            body = body[:-1].strip()
        # Remove trailing LOCK ROW FOR ACCESS (or similar) clauses that may appear
        # in view definitions (e.g., "LOCK ROW FOR ACCESS") so EXPLAIN focuses
        # on the inner SELECT statement.
        body = re.sub(r"\bLOCK\s+ROW\s+FOR\s+ACCESS\b\s*;?\s*$", "", body, flags=re.IGNORECASE)
        logger_safe('debug', 'get_the_explain: Extracted inner query from CREATE/REPLACE VIEW for EXPLAIN.')
        return body

    inner_sql = _extract_inner_query_from_view(sql_query)
    try:
        explain_result = tdml.execute_sql(f"EXPLAIN {inner_sql}").fetchall()
        explain_lines = [row[0] for row in explain_result]
        explain_text = "\n".join(explain_lines)
        logger_safe('info', 'get_the_explain: Successfully retrieved EXPLAIN plan.')
        return explain_text
    except Exception as e:
        logger_safe('error', f'get_the_explain: Failed to retrieve EXPLAIN plan: {str(e).splitlines()[0]}')
        raise

def _sanitize_for_teradata(text: str) -> str:
    """Replace characters outside Teradata LATIN (ISO-8859-1) character set.

    LLM-generated text often contains Unicode characters (smart quotes, em
    dashes, ellipsis, etc.) that trigger Teradata Error 6706 when inserted
    into LATIN-charset columns.  This function replaces the most common
    offenders with ASCII equivalents, then encodes the remainder as
    ISO-8859-1, substituting any still-unmappable code points with '?'.
    """
    if not isinstance(text, str):
        return text
    replacements = {
        '\u2018': "'", '\u2019': "'",   # left/right single quotation marks
        '\u201c': '"', '\u201d': '"',   # left/right double quotation marks
        '\u2013': '-', '\u2014': '-',   # en dash, em dash
        '\u2026': '...', '\u2022': '*', # ellipsis, bullet point
        '\u00a0': ' ',                  # non-breaking space
    }
    for char, replacement in replacements.items():
        text = text.replace(char, replacement)
    # Normalise composed Unicode (e.g. accented letters) to decomposed form
    # so that the base character survives the latin-1 round-trip.
    text = unicodedata.normalize('NFKD', text)
    return text.encode('latin-1', errors='replace').decode('latin-1')


def upload_documentation(process_info: Dict[str, Any]) -> None:
    """
    Upload the generated documentation for a data process into the documentation tables.

    Parameters
    ----------
    process_info : dict
        A dictionary containing the process documentation information.
        Expected keys:
            - PROCESS_ID: str
            - DOCUMENTED_SQL: str
            - ENTITY_DESCRIPTION: str
            - DOCUMENTED_ENTITY_COLUMNS: dict[str, str]
            - DOCUMENTED_FEATURE_COLUMNS: dict[str, str]
    """

    process_id          = process_info['PROCESS_ID']
    documented_sql      = _sanitize_for_teradata(process_info['DOCUMENTED_SQL'])
    entity_description  = _sanitize_for_teradata(process_info['ENTITY_DESCRIPTION'])
    entity_columns_json = _sanitize_for_teradata(json.dumps(process_info['DOCUMENTED_ENTITY_COLUMNS']))
    feature_columns     = {
        k: _sanitize_for_teradata(v)
        for k, v in process_info['DOCUMENTED_FEATURE_COLUMNS'].items()
    }

    # build a pandas dataframe containing the data to be uploaded in DOCUMENTATION_PROCESS_BUSINESS_LOGIC
    # that contains PROCESS_ID, BUSINESS_LOGIC_DESCRIPTION, ENTITY_DESCRIPTION, ENTITY_COLUMNS_JSON
    df_business_logic = pd.DataFrame([{
        'PROCESS_ID': process_id,
        'BUSINESS_LOGIC_DESCRIPTION': documented_sql,
        'ENTITY_DESCRIPTION': entity_description,
        'ENTITY_COLUMNS_JSON': entity_columns_json
    }])

    # build a pandas dataframe containing the data to be uploaded in DOCUMENTATION_PROCESS_FEATURES
    # that contains PROCESS_ID, FEATURE_ID, FEATURE_DESCRIPTION
    # at this stage, FEATURE_ID is not known, so we will use the FEATURE_NAME as a placeholder
    # and later replace it with the actual FEATURE_ID after insertion with a join with the FS_FEATURE_CATALOG
    # here we need to explode the feature_columns dict into multiple rows
    feature_rows = []
    for feature_name, feature_description in feature_columns.items():
        feature_rows.append({
            'PROCESS_ID': process_id,
            'FEATURE_NAME': feature_name,  # placeholder for FEATURE_ID
            'FEATURE_DESCRIPTION': feature_description
        })
    df_features = pd.DataFrame(feature_rows)

    # Determine end period based on tdfs4ds configuration
    if tdfs4ds.END_PERIOD == 'UNTIL_CHANGED':
        end_period_ = '9999-01-01 00:00:00' 
    else:
        end_period_ = tdfs4ds.END_PERIOD
    
    # upload the df_business_logic dataframe into a staging volatile table
    # Explicit types prevent teradataml from inferring a too-small VARCHAR
    # (silently truncating long descriptions/JSON before MERGE).
    logger_safe('info', f'upload_documentation: Uploading documentation for process_id {process_id} into staging tables.')
    tdml.copy_to_sql(
        df_business_logic,
        table_name = "DOC_PROCESS_BUSINESS_LOGIC_STAGING",
        if_exists  = 'replace',
        temporary  = True,
        types      = {
            'PROCESS_ID'                : tdml.VARCHAR(length=36,    charset='LATIN'),
            'BUSINESS_LOGIC_DESCRIPTION': tdml.VARCHAR(length=32000, charset='LATIN'),
            'ENTITY_DESCRIPTION'        : tdml.VARCHAR(length=32000, charset='LATIN'),
            'ENTITY_COLUMNS_JSON'       : tdml.VARCHAR(length=32000, charset='LATIN'),
        }
    )
    logger_safe('info', f'upload_documentation: Uploaded business logic documentation for process_id {process_id} into staging table.')

    # upload the df_features dataframe into a staging volatile table
    logger_safe('info', f'upload_documentation: Uploading feature documentation for process_id {process_id} into staging tables.')
    tdml.copy_to_sql(
        df_features,
        table_name = "DOC_PROCESS_FEATURES_STAGING",
        if_exists  = 'replace',
        temporary  = True,
        types      = {
            'PROCESS_ID'         : tdml.VARCHAR(length=36,    charset='LATIN'),
            'FEATURE_NAME'       : tdml.VARCHAR(length=255,   charset='LATIN'),
            'FEATURE_DESCRIPTION': tdml.VARCHAR(length=32000, charset='LATIN'),
        }
    )
    logger_safe('info', f'upload_documentation: Uploaded feature documentation for process_id {process_id} into staging table.')

    # merge into DOCUMENTATION_PROCESS_BUSINESS_LOGIC from staging table
    query_insert_business_logic =  f"""
    CURRENT VALIDTIME
    MERGE INTO {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC} EXISTING
    USING (
        SELECT
            PROCESS_ID,
            BUSINESS_LOGIC_DESCRIPTION,
            ENTITY_DESCRIPTION,
            ENTITY_COLUMNS_JSON
        FROM {_get_database_username()}.DOC_PROCESS_BUSINESS_LOGIC_STAGING
    ) UPDATED
    ON EXISTING.PROCESS_ID = UPDATED.PROCESS_ID
    WHEN MATCHED THEN
        UPDATE
        SET
            BUSINESS_LOGIC_DESCRIPTION = UPDATED.BUSINESS_LOGIC_DESCRIPTION,
            ENTITY_DESCRIPTION         = UPDATED.ENTITY_DESCRIPTION,
            ENTITY_COLUMNS_JSON       = UPDATED.ENTITY_COLUMNS_JSON
    WHEN NOT MATCHED THEN
    INSERT (
        UPDATED.PROCESS_ID,
        UPDATED.BUSINESS_LOGIC_DESCRIPTION,
        UPDATED.ENTITY_DESCRIPTION,
        UPDATED.ENTITY_COLUMNS_JSON
        )   
    """

    # merge into DOCUMENTATION_PROCESS_FEATURES from staging table
    query_insert_features =  f"""
    CURRENT VALIDTIME
    MERGE INTO {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_FEATURES} EXISTING
    USING (
        SELECT
            A.PROCESS_ID,
            FC.FEATURE_ID,
            A.FEATURE_NAME,
            A.FEATURE_DESCRIPTION
        FROM {_get_database_username()}.DOC_PROCESS_FEATURES_STAGING A
        INNER JOIN {tdfs4ds.SCHEMA}.{tdfs4ds.FEATURE_CATALOG_NAME} FC
        ON UPPER(FC.FEATURE_NAME) = UPPER(A.FEATURE_NAME)
        AND UPPER(FC.DATA_DOMAIN) = '{process_info['DATA_DOMAIN'].upper()}'
    ) UPDATED
    ON EXISTING.PROCESS_ID = UPDATED.PROCESS_ID
    AND EXISTING.FEATURE_ID = UPDATED.FEATURE_ID
    WHEN MATCHED THEN
        UPDATE
        SET
            FEATURE_DESCRIPTION = UPDATED.FEATURE_DESCRIPTION,
            FEATURE_NAME        = UPDATED.FEATURE_NAME
    WHEN NOT MATCHED THEN
        INSERT (
            UPDATED.PROCESS_ID,
            UPDATED.FEATURE_ID,
            UPDATED.FEATURE_NAME,
            UPDATED.FEATURE_DESCRIPTION
        )
    """

    # Remove features that are no longer present in the documentation
    query_delete_missing_features = f"""
    CURRENT VALIDTIME
    DELETE FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_FEATURES}
    WHERE PROCESS_ID = '{process_id}'
    AND FEATURE_ID NOT IN (
        SELECT FC.FEATURE_ID
        FROM {_get_database_username()}.DOC_PROCESS_FEATURES_STAGING A
        INNER JOIN {tdfs4ds.SCHEMA}.{tdfs4ds.FEATURE_CATALOG_NAME} FC
        ON UPPER(FC.FEATURE_NAME) = UPPER(A.FEATURE_NAME)
        AND UPPER(FC.DATA_DOMAIN) = '{process_info['DATA_DOMAIN'].upper()}'
    )
    """

    # Execute the merges
    try:
        tdml.execute_sql(query_insert_business_logic)
        logger_safe('info', f'upload_documentation: Merged business logic documentation for process_id {process_id} into main table.')
    except Exception as e:
        logger_safe('error', f'upload_documentation: Failed to merge business logic documentation for process_id {process_id}: {e}')
        print(query_insert_business_logic)
        raise
    try:
        tdml.execute_sql(query_insert_features)
        logger_safe('info', f'upload_documentation: Merged feature documentation for process_id {process_id} into main table.') 
    except Exception as e:
        logger_safe('error', f'upload_documentation: Failed to merge feature documentation for process_id {process_id}: {e}')
        print(query_insert_features)
        raise
    try:
        tdml.execute_sql(query_delete_missing_features)
        logger_safe('info', f'upload_documentation: Removed missing features for process_id {process_id} from main table.') 
    except Exception as e:
        logger_safe('error', f'upload_documentation: Failed to remove missing features for process_id {process_id}: {e}')
        print(query_delete_missing_features)
        raise

    # remove staging tables
    tdml.execute_sql(f"DROP TABLE {_get_database_username()}.DOC_PROCESS_BUSINESS_LOGIC_STAGING")
    tdml.execute_sql(f"DROP TABLE {_get_database_username()}.DOC_PROCESS_FEATURES_STAGING")
    logger_safe('info', f'upload_documentation: Successfully uploaded documentation for process_id {process_id}.')

    # Mirror to business dictionary so the consumer agent can find process documentation.
    # The agent looks up FS_BUSINESS_DICTIONARY_OBJECTS (object overview) and
    # FS_BUSINESS_DICTIONARY_COLUMNS (feature descriptions keyed by TABLE_NAME=view, COLUMN_NAME=feature).
    view_name_raw = process_info.get('VIEW_NAME', '')
    if view_name_raw:
        clean = view_name_raw.replace('"', '')
        parts = clean.split('.')
        biz_db  = parts[0] if len(parts) >= 2 else tdfs4ds.SCHEMA
        biz_obj = parts[-1]

        if entity_description:
            try:
                upload_business_dictionary_objects(pd.DataFrame([{
                    'DATABASE_NAME':       biz_db,
                    'OBJECT_NAME':         biz_obj,
                    'OBJECT_TYPE':         'V',
                    'BUSINESS_DESCRIPTION': entity_description,
                }]))
            except Exception as e:
                logger_safe('warning', f'upload_documentation: could not mirror object entry to business dictionary: {e}')

        if feature_columns:
            try:
                upload_business_dictionary_columns(pd.DataFrame([
                    {
                        'DATABASE_NAME':       biz_db,
                        'TABLE_NAME':          biz_obj,
                        'COLUMN_NAME':         feat,
                        'BUSINESS_DESCRIPTION': desc,
                    }
                    for feat, desc in feature_columns.items()
                ]))
            except Exception as e:
                logger_safe('warning', f'upload_documentation: could not mirror column entries to business dictionary: {e}')

    return

def retrieve_documentation(process_id: str) -> Dict[str, Any]:
    """
    Retrieve the documentation for a data process from the documentation tables.

    Parameters
    ----------
    process_id : str
        The unique identifier of the data process.

    Returns
    -------
    dict
        A dictionary containing the documentation information with keys:
            - documented_sql: str
            - entity_description: str
            - documented_entity_columns: dict[str, str]
            - documented_feature_columns: dict[str, str]
    """
    logger_safe('info', f'retrieve_documentation: Retrieving documentation for process_id {process_id}.')

    # Retrieve business logic documentation
    query_business_logic = f"""
    CURRENT VALIDTIME
    SELECT
        BUSINESS_LOGIC_DESCRIPTION,
        ENTITY_DESCRIPTION,
        ENTITY_COLUMNS_JSON
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC}
    WHERE PROCESS_ID = '{process_id}'
    """
    result_bl = tdml.execute_sql(query_business_logic).fetchone()
    if not result_bl:
        logger_safe('warning', f'retrieve_documentation: No business logic documentation found for process_id {process_id}.')
        return {}

    documented_sql      = result_bl[0]
    entity_description  = result_bl[1]
    entity_columns_json = result_bl[2]
    if entity_columns_json:
        try:
            documented_entity_columns = json.loads(entity_columns_json)
        except (json.JSONDecodeError, ValueError):
            try:
                documented_entity_columns = _robust_json_parser(entity_columns_json)
            except (json.JSONDecodeError, ValueError, Exception):
                logger_safe('warning',
                    f'retrieve_documentation: malformed ENTITY_COLUMNS_JSON for '
                    f'process_id {process_id} — skipping entity columns. '
                    f'Re-run document_process_incremental(process_id="{process_id}", '
                    f'force_update=True) to regenerate.')
                documented_entity_columns = {}
    else:
        documented_entity_columns = {}

    # Retrieve feature documentation
    query_features = f"""
    CURRENT VALIDTIME
    SELECT
        FC.FEATURE_NAME,
        DPF.FEATURE_DESCRIPTION
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_FEATURES} DPF
    INNER JOIN {tdfs4ds.SCHEMA}.{tdfs4ds.FEATURE_CATALOG_NAME} FC
    ON DPF.FEATURE_ID    = FC.FEATURE_ID
    WHERE DPF.PROCESS_ID = '{process_id}'
    """
    result_features = tdml.execute_sql(query_features).fetchall()
    documented_feature_columns = {
        row[0]: row[1] for row in result_features
    }

    logger_safe('info', f'retrieve_documentation: Successfully retrieved documentation for process_id {process_id}.')
    return {
        "DOCUMENTED_SQL"             : documented_sql,
        "ENTITY_DESCRIPTION"         : entity_description,
        "DOCUMENTED_ENTITY_COLUMNS"  : documented_entity_columns,
        "DOCUMENTED_FEATURE_COLUMNS" : documented_feature_columns
    }

def retrieve_explain_documentation(process_id: str) -> Dict[str, Any]:
    """
    Retrieve the EXPLAIN documentation for a data process from the documentation tables.

    Parameters
    ----------
    process_id : str
        The unique identifier of the data process.

    Returns
    -------
    dict
        A dictionary containing the EXPLAIN documentation information with keys:
            - explanation: str
            - optimization_score: int
            - warnings: list[str]
            - recommendations: list[str]
    """
    logger_safe('info', f'retrieve_explain_documentation: Retrieving EXPLAIN documentation for process_id {process_id}.')

    # Detect available columns — older installs may lack N_STEPS / N_SPOOL_OBJECTS.
    _extra_cols = ""
    try:
        _ddl = tdml.execute_sql(
            f"SHOW TABLE {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN}"
        ).fetchall()[0][0]
        _ddl_upper = _ddl.upper()
        _has_n_steps = "N_STEPS" in _ddl_upper
        _has_n_spools = "N_SPOOL_OBJECTS" in _ddl_upper
        if _has_n_steps:
            _extra_cols += ", N_STEPS"
        if _has_n_spools:
            _extra_cols += ", N_SPOOL_OBJECTS"
    except Exception:
        _has_n_steps = False
        _has_n_spools = False

    query_explain = f"""
    CURRENT VALIDTIME
    SELECT
        EXPLAIN_ANALYSIS,
        USER_SCORE,
        OPTIMIZATION_SCORE,
        WARNINGS,
        RECOMMENDATIONS
        {_extra_cols}
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN}
    WHERE PROCESS_ID = '{process_id}'
    """
    result_explain = tdml.execute_sql(query_explain).fetchone()
    if not result_explain:
        logger_safe('warning', f'retrieve_explain_documentation: No EXPLAIN documentation found for process_id {process_id}.')
        return {}

    explanation        = result_explain[0]
    user_score         = result_explain[1]
    optimization_score = result_explain[2]
    try:
        warnings = json.loads(result_explain[3]) if result_explain[3] else []
    except (json.JSONDecodeError, ValueError):
        logger_safe('warning',
            f'retrieve_explain_documentation: malformed WARNINGS JSON for '
            f'process_id {process_id} — returning empty list.')
        warnings = []
    try:
        recommendations = json.loads(result_explain[4]) if result_explain[4] else []
    except (json.JSONDecodeError, ValueError):
        logger_safe('warning',
            f'retrieve_explain_documentation: malformed RECOMMENDATIONS JSON for '
            f'process_id {process_id} — returning empty list.')
        recommendations = []

    # Extra columns are appended after the base 5, in the order added above.
    _extra_idx = 5
    n_steps_val = None
    n_spool_objects_val = None
    if _has_n_steps:
        n_steps_val = result_explain[_extra_idx]
        _extra_idx += 1
    if _has_n_spools:
        n_spool_objects_val = result_explain[_extra_idx]

    logger_safe('info', f'retrieve_explain_documentation: Successfully retrieved EXPLAIN documentation for process_id {process_id}.')
    return {
        "EXPLAIN_ANALYSIS"        : explanation,
        "USER_SCORE"              : user_score,
        "OPTIMIZATION_SCORE"      : optimization_score,
        "EXPLAIN_WARNINGS"        : warnings,
        "EXPLAIN_RECOMMENDATIONS" : recommendations,
        "EXPLAIN_N_STEPS"         : n_steps_val,
        "EXPLAIN_N_SPOOL_OBJECTS" : n_spool_objects_val,
    }

def upload_documentation_explain(process_info: Dict[str, Any]) -> None:
    """
    Upload the EXPLAIN documentation for a data process into the documentation tables.

    Parameters
    ----------
    process_id : str
        The unique identifier of the data process.
    explain_documentation : dict
        A dictionary containing the EXPLAIN documentation information with keys:
            - explanation: str
            - optimization_score: int
            - warnings: list[str]
            - recommendations: list[str]
    """

    explanation         = _sanitize_for_teradata(process_info['EXPLAIN_ANALYSIS'])
    user_score          = process_info.get('USER_SCORE', None)
    optimization_score  = process_info['OPTIMIZATION_SCORE']
    n_steps             = process_info.get('EXPLAIN_N_STEPS', None)
    n_spool_objects     = process_info.get('EXPLAIN_N_SPOOL_OBJECTS', None)
    warnings_json       = _sanitize_for_teradata(json.dumps(process_info['EXPLAIN_WARNINGS']))
    recommendations_json= _sanitize_for_teradata(json.dumps(process_info['EXPLAIN_RECOMMENDATIONS']))
    process_id          = process_info['PROCESS_ID']

    def _int_or_null(v):
        return str(int(v)) if v is not None else 'NULL'

    # merge into DOCUMENTATION_PROCESS_EXPLAIN
    query_insert_explain =  f"""
    CURRENT VALIDTIME
    MERGE INTO {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN} EXISTING
    USING (
        SELECT
            '{process_id}' AS PROCESS_ID,
            '{explanation.replace("'", "''")}' AS EXPLAIN_ANALYSIS,
            {_int_or_null(user_score)} AS USER_SCORE,
            {_int_or_null(optimization_score)} AS OPTIMIZATION_SCORE,
            {_int_or_null(n_steps)} AS N_STEPS,
            {_int_or_null(n_spool_objects)} AS N_SPOOL_OBJECTS,
            '{warnings_json.replace("'", "''")}' AS WARNINGS,
            '{recommendations_json.replace("'", "''")}' AS RECOMMENDATIONS
    ) UPDATED
    ON EXISTING.PROCESS_ID = UPDATED.PROCESS_ID
    WHEN MATCHED THEN
        UPDATE
        SET
            EXPLAIN_ANALYSIS   = UPDATED.EXPLAIN_ANALYSIS,
            USER_SCORE         = UPDATED.USER_SCORE,
            OPTIMIZATION_SCORE = UPDATED.OPTIMIZATION_SCORE,
            N_STEPS            = UPDATED.N_STEPS,
            N_SPOOL_OBJECTS    = UPDATED.N_SPOOL_OBJECTS,
            WARNINGS           = UPDATED.WARNINGS,
            RECOMMENDATIONS    = UPDATED.RECOMMENDATIONS
    WHEN NOT MATCHED THEN
        INSERT (
            UPDATED.PROCESS_ID,
            UPDATED.EXPLAIN_ANALYSIS,
            UPDATED.USER_SCORE,
            UPDATED.OPTIMIZATION_SCORE,
            UPDATED.N_STEPS,
            UPDATED.N_SPOOL_OBJECTS,
            UPDATED.WARNINGS,
            UPDATED.RECOMMENDATIONS
        )
    """

    # Execute the merge
    try:
        tdml.execute_sql(query_insert_explain)
        logger_safe('info', f'upload_documentation_explain: Uploaded EXPLAIN documentation for process_id {process_id}.')
    except Exception as e:
        logger_safe('error', f'upload_documentation_explain: Failed to upload EXPLAIN documentation for process_id {process_id}: {e}')
        raise

    return

def display_process_info(process_info: Dict[str, Any] = None, process_id : str = None) -> None:
    """
    Pretty print the documentation and EXPLAIN analysis for a data process from process_info dict or by retrieving it using process_id.

    Parameters
    ----------
    process_info : dict, optional (default=None)
        A dictionary containing the process documentation information.
        If None, process_id must be provided to retrieve the information.
    process_id : str, optional (default=None)
        The unique identifier of the data process.
        If process_info is None, this parameter is used to retrieve the documentation.
    -----------
    Returns
    None
    """

    if process_info is None:
        if process_id is None:
            raise ValueError("Either process_info or process_id must be provided.")
        logger_safe('info', f'display_process_info: Retrieving documentation for process_id {process_id}.')
        process_info = get_process_info(process_id)

    # pretty print documentation for info:
    _print_documentation(
        documented_sql             = process_info.get('DOCUMENTED_SQL', None),
        entity_description         = process_info.get('ENTITY_DESCRIPTION', None),
        documented_entity_columns  = process_info.get('DOCUMENTED_ENTITY_COLUMNS', None),
        documented_feature_columns = process_info.get('DOCUMENTED_FEATURE_COLUMNS', None),
        process_id                 = process_info.get('PROCESS_ID', None),
        view_name                  = process_info.get('VIEW_NAME', None),
        explain_analysis           = process_info.get('EXPLAIN_ANALYSIS', None),
        user_score                 = process_info.get('USER_SCORE', None),
        optimization_score         = process_info.get('OPTIMIZATION_SCORE', None),
        explain_warnings           = process_info.get('EXPLAIN_WARNINGS', None),
        explain_recommendations    = process_info.get('EXPLAIN_RECOMMENDATIONS', None),
        sql_query                  = process_info.get('PROCESS_SQL', None),
        n_steps                    = process_info.get('EXPLAIN_N_STEPS', None),
        n_spool_objects            = process_info.get('EXPLAIN_N_SPOOL_OBJECTS', None),
    )
    return


def feed_process_info_with_prompt_result(process_info, sql_documentation_response=None, sql_explain_response=None, display_info=True, upload_info=True):
    """
    Enriches a process_info dictionary with SQL documentation and EXPLAIN plan analysis results,
    with options to display the results and upload the enriched information.

    This function integrates the results of SQL documentation and EXPLAIN plan analysis into the provided
    `process_info` dictionary. It extracts and organizes documentation for entity and feature columns,
    as well as optimization insights, to provide a comprehensive view of the SQL query's business logic,
    performance, and potential improvements. It also supports optional display of the enriched information
    and automatic upload of the documentation and EXPLAIN analysis to a backend system.

    Args:
        process_info (dict): A dictionary containing metadata about the SQL process, including:
            - 'ENTITY_COLUMNS': List of columns representing the entity in the SQL query.
            - 'FEATURE_COLUMNS': List of columns representing features in the SQL query.
        sql_documentation_response (dict, optional): A dictionary containing SQL documentation results,
            including descriptions for entity/feature columns and query business logic. Expected keys:
            - 'query_business_logic': Description of the query's purpose and logic.
            - 'entity_description': Description of the entity represented by the query.
            - Column names as keys, with their descriptions as values.
        sql_explain_response (dict, optional): A dictionary containing SQL EXPLAIN plan analysis results,
            including:
            - 'explanation': Detailed analysis of the EXPLAIN plan.
            - 'optimization_score': Integer score (1-5) indicating query optimization level.
            - 'warnings': List of potential issues identified in the EXPLAIN plan.
            - 'recommendations': List of actionable recommendations for query optimization.
        display_info (bool, optional): If True, displays the enriched process_info using `display_process_info`.
            Defaults to True.
        upload_info (bool, optional): If True, uploads the enriched documentation and EXPLAIN analysis to a backend system.
            Defaults to True.

    Returns:
        dict: The enriched `process_info` dictionary with the following additional keys (if input responses are provided):
            - 'DOCUMENTED_SQL': Business logic description of the SQL query.
            - 'ENTITY_DESCRIPTION': Description of the entity represented by the query.
            - 'DOCUMENTED_ENTITY_COLUMNS': Dictionary of documented entity columns and their descriptions.
            - 'DOCUMENTED_FEATURE_COLUMNS': Dictionary of documented feature columns and their descriptions.
            - 'EXPLAIN_ANALYSIS': Analysis of the EXPLAIN plan.
            - 'OPTIMIZATION_SCORE': Optimization score (1-5) for the query.
            - 'EXPLAIN_WARNINGS': List of warnings from the EXPLAIN plan analysis.
            - 'EXPLAIN_RECOMMENDATIONS': List of optimization recommendations.

    Raises:
        Logs errors for any exceptions encountered during the update or upload process, but does not raise them.
        Errors are logged using `logger_safe` with a descriptive message.

    Example:
        >>> process_info = {
        ...     'ENTITY_COLUMNS': ['customer_id', 'order_id'],
        ...     'FEATURE_COLUMNS': ['order_amount', 'order_date']
        ... }
        >>> sql_documentation_response = {
        ...     'query_business_logic': 'This query joins customer and order data...',
        ...     'entity_description': 'The customer entity represents...',
        ...     'customer_id': 'Unique identifier for customers.',
        ...     'order_amount': 'Total amount of the order.'
        ... }
        >>> sql_explain_response = {
        ...     'explanation': 'The EXPLAIN plan shows a nested loop join...',
        ...     'optimization_score': 3,
        ...     'warnings': ['Full table scan on orders table'],
        ...     'recommendations': ['Add index on orders.customer_id']
        ... }
        >>> enriched_info = feed_process_info_with_prompt_result(
        ...     process_info,
        ...     sql_documentation_response,
        ...     sql_explain_response,
        ...     display_info=True,
        ...     upload_info=True
        ... )
        >>> print(enriched_info.keys())
        ['ENTITY_COLUMNS', 'FEATURE_COLUMNS', 'DOCUMENTED_SQL', 'ENTITY_DESCRIPTION',
         'DOCUMENTED_ENTITY_COLUMNS', 'DOCUMENTED_FEATURE_COLUMNS', 'EXPLAIN_ANALYSIS',
         'OPTIMIZATION_SCORE', 'EXPLAIN_WARNINGS', 'EXPLAIN_RECOMMENDATIONS']
    """

    entity_columns  = process_info['ENTITY_COLUMNS']
    feature_columns = process_info['FEATURE_COLUMNS']

    if sql_documentation_response is not None:
        try:
            process_info['DOCUMENTED_SQL']             = sql_documentation_response['query_business_logic']
            process_info['ENTITY_DESCRIPTION']         = sql_documentation_response['entity_description']
            process_info['DOCUMENTED_ENTITY_COLUMNS']  = {k: v for k, v in sql_documentation_response.items() if k in entity_columns}
            process_info['DOCUMENTED_FEATURE_COLUMNS'] = {k: v for k, v in sql_documentation_response.items() if k in feature_columns}
            logger_safe('info', 'update of the SQL documentation in process_info')
            if upload_info:
                upload_documentation(process_info)
        except Exception as e:
            logger_safe('error',f"error in updating the SQL documentation : {str(e).splitlines()[0]}")

    if sql_explain_response is not None:
        try:
            process_info['EXPLAIN_ANALYSIS']           = sql_explain_response['explanation']
            process_info['USER_SCORE']                 = sql_explain_response['user_score']
            process_info['OPTIMIZATION_SCORE']         = sql_explain_response['global_score']
            process_info['EXPLAIN_WARNINGS']           = sql_explain_response['warnings']
            process_info['EXPLAIN_RECOMMENDATIONS']    = sql_explain_response['recommendations']
            logger_safe('info', 'update of the EXPLAIN documentation in process_info')
            if upload_info:
                upload_documentation_explain(process_info)
        except Exception as e:
            logger_safe('error',f"error in updating the EXPLAIN documentation : {str(e).splitlines()[0]}")        

    if display_info:
        display_process_info(process_info)

    return process_info


def upload_business_dictionary_objects(df: pd.DataFrame) -> None:
    """
    Insert or update object-level descriptions in the business dictionary.

    The DataFrame must contain the following columns:
        - DATABASE_NAME       : str  — database (or schema) that owns the object
        - OBJECT_NAME         : str  — table or view name
        - OBJECT_TYPE         : str  — 'T' for table, 'V' for view
        - BUSINESS_DESCRIPTION: str  — business-oriented description of the object

    Rows are merged into ``FS_BUSINESS_DICTIONARY_OBJECTS`` using
    ``CURRENT VALIDTIME`` semantics (Teradata temporal).  Existing rows
    matched on (DATABASE_NAME, OBJECT_NAME) are updated; new rows are inserted.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with columns DATABASE_NAME, OBJECT_NAME, OBJECT_TYPE, BUSINESS_DESCRIPTION.
    """
    required_cols = {'DATABASE_NAME', 'OBJECT_NAME', 'OBJECT_TYPE', 'BUSINESS_DESCRIPTION'}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f'upload_business_dictionary_objects: missing columns {missing}')

    staging = 'BIZ_DICT_OBJECTS_STAGING'
    user_db = _get_database_username()

    df = df.copy()
    df['BUSINESS_DESCRIPTION'] = df['BUSINESS_DESCRIPTION'].apply(_sanitize_for_teradata)

    tdml.copy_to_sql(
        df[['DATABASE_NAME', 'OBJECT_NAME', 'OBJECT_TYPE', 'BUSINESS_DESCRIPTION']],
        table_name=staging,
        if_exists='replace',
        temporary=True,
        types={
            'DATABASE_NAME'       : tdml.VARCHAR(length=128,   charset='LATIN'),
            'OBJECT_NAME'         : tdml.VARCHAR(length=128,   charset='LATIN'),
            'OBJECT_TYPE'         : tdml.VARCHAR(length=1,     charset='LATIN'),
            'BUSINESS_DESCRIPTION': tdml.VARCHAR(length=32000, charset='LATIN'),
        },
    )

    query_merge = f"""
    CURRENT VALIDTIME
    MERGE INTO {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS} EXISTING
    USING (
        SELECT DATABASE_NAME, OBJECT_NAME, OBJECT_TYPE, BUSINESS_DESCRIPTION
        FROM {user_db}.{staging}
    ) UPDATED
    ON  EXISTING.DATABASE_NAME = UPDATED.DATABASE_NAME
    AND EXISTING.OBJECT_NAME   = UPDATED.OBJECT_NAME
    WHEN MATCHED THEN
        UPDATE SET
            OBJECT_TYPE          = UPDATED.OBJECT_TYPE,
            BUSINESS_DESCRIPTION = UPDATED.BUSINESS_DESCRIPTION
    WHEN NOT MATCHED THEN
        INSERT (
            UPDATED.DATABASE_NAME,
            UPDATED.OBJECT_NAME,
            UPDATED.OBJECT_TYPE,
            UPDATED.BUSINESS_DESCRIPTION
        )
    """

    try:
        tdml.execute_sql(query_merge)
        logger_safe('info', f'upload_business_dictionary_objects: Merged {len(df)} row(s) into {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS}.')
    except Exception as e:
        logger_safe('error', f'upload_business_dictionary_objects: Merge failed: {e}')
        raise
    finally:
        try:
            tdml.execute_sql(f'DROP TABLE {user_db}.{staging}')
        except Exception:
            pass


def upload_business_dictionary_columns(df: pd.DataFrame) -> None:
    """
    Insert or update column-level descriptions in the business dictionary.

    The DataFrame must contain the following columns:
        - DATABASE_NAME       : str  — database (or schema) that owns the table
        - TABLE_NAME          : str  — table or view name
        - COLUMN_NAME         : str  — column name
        - BUSINESS_DESCRIPTION: str  — business-oriented description of the column

    Rows are merged into ``FS_BUSINESS_DICTIONARY_COLUMNS`` using
    ``CURRENT VALIDTIME`` semantics (Teradata temporal).  Existing rows
    matched on (DATABASE_NAME, TABLE_NAME, COLUMN_NAME) are updated;
    new rows are inserted.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with columns DATABASE_NAME, TABLE_NAME, COLUMN_NAME, BUSINESS_DESCRIPTION.
    """
    required_cols = {'DATABASE_NAME', 'TABLE_NAME', 'COLUMN_NAME', 'BUSINESS_DESCRIPTION'}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f'upload_business_dictionary_columns: missing columns {missing}')

    staging = 'BIZ_DICT_COLUMNS_STAGING'
    user_db = _get_database_username()

    df = df.copy()
    df['BUSINESS_DESCRIPTION'] = df['BUSINESS_DESCRIPTION'].apply(_sanitize_for_teradata)

    tdml.copy_to_sql(
        df[['DATABASE_NAME', 'TABLE_NAME', 'COLUMN_NAME', 'BUSINESS_DESCRIPTION']],
        table_name=staging,
        if_exists='replace',
        temporary=True,
        types={
            'DATABASE_NAME'       : tdml.VARCHAR(length=128,   charset='LATIN'),
            'TABLE_NAME'          : tdml.VARCHAR(length=128,   charset='LATIN'),
            'COLUMN_NAME'         : tdml.VARCHAR(length=128,   charset='LATIN'),
            'BUSINESS_DESCRIPTION': tdml.VARCHAR(length=32000, charset='LATIN'),
        },
    )

    query_merge = f"""
    CURRENT VALIDTIME
    MERGE INTO {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS} EXISTING
    USING (
        SELECT DATABASE_NAME, TABLE_NAME, COLUMN_NAME, BUSINESS_DESCRIPTION
        FROM {user_db}.{staging}
    ) UPDATED
    ON  EXISTING.DATABASE_NAME = UPDATED.DATABASE_NAME
    AND EXISTING.TABLE_NAME    = UPDATED.TABLE_NAME
    AND EXISTING.COLUMN_NAME   = UPDATED.COLUMN_NAME
    WHEN MATCHED THEN
        UPDATE SET
            BUSINESS_DESCRIPTION = UPDATED.BUSINESS_DESCRIPTION
    WHEN NOT MATCHED THEN
        INSERT (
            UPDATED.DATABASE_NAME,
            UPDATED.TABLE_NAME,
            UPDATED.COLUMN_NAME,
            UPDATED.BUSINESS_DESCRIPTION
        )
    """

    try:
        tdml.execute_sql(query_merge)
        logger_safe('info', f'upload_business_dictionary_columns: Merged {len(df)} row(s) into {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS}.')
    except Exception as e:
        logger_safe('error', f'upload_business_dictionary_columns: Merge failed: {e}')
        raise
    finally:
        try:
            tdml.execute_sql(f'DROP TABLE {user_db}.{staging}')
        except Exception:
            pass


def upload_business_dictionary_sections(df: pd.DataFrame) -> None:
    """
    Insert or update section-level descriptions in the business dictionary.

    The DataFrame must contain the following columns:
        - DATABASE_NAME  : str  — database (or schema) that owns the object
        - OBJECT_NAME    : str  — object name (table, view, dataset)
        - SECTION_NAME   : str  — section identifier (e.g. 'OVERVIEW', 'FEATURE_THEMES')
        - SECTION_CONTENT: str  — section text content

    Rows are merged into ``FS_BUSINESS_DICTIONARY_SECTIONS`` using
    ``CURRENT VALIDTIME`` semantics.  Existing rows matched on
    (DATABASE_NAME, OBJECT_NAME, SECTION_NAME) are updated; new rows
    are inserted.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with columns DATABASE_NAME, OBJECT_NAME, SECTION_NAME, SECTION_CONTENT.
    """
    required_cols = {'DATABASE_NAME', 'OBJECT_NAME', 'SECTION_NAME', 'SECTION_CONTENT'}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f'upload_business_dictionary_sections: missing columns {missing}')

    staging = 'BIZ_DICT_SECTIONS_STAGING'
    user_db = _get_database_username()

    df = df.copy()
    df['SECTION_CONTENT'] = df['SECTION_CONTENT'].apply(_sanitize_for_teradata)

    tdml.copy_to_sql(
        df[['DATABASE_NAME', 'OBJECT_NAME', 'SECTION_NAME', 'SECTION_CONTENT']],
        table_name=staging,
        if_exists='replace',
        temporary=True,
        types={
            'DATABASE_NAME'  : tdml.VARCHAR(length=128,   charset='LATIN'),
            'OBJECT_NAME'    : tdml.VARCHAR(length=128,   charset='LATIN'),
            'SECTION_NAME'   : tdml.VARCHAR(length=128,   charset='LATIN'),
            'SECTION_CONTENT': tdml.VARCHAR(length=32000, charset='LATIN'),
        },
    )

    query_merge = f"""
    CURRENT VALIDTIME
    MERGE INTO {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS} EXISTING
    USING (
        SELECT DATABASE_NAME, OBJECT_NAME, SECTION_NAME, SECTION_CONTENT
        FROM {user_db}.{staging}
    ) UPDATED
    ON  EXISTING.DATABASE_NAME = UPDATED.DATABASE_NAME
    AND EXISTING.OBJECT_NAME   = UPDATED.OBJECT_NAME
    AND EXISTING.SECTION_NAME  = UPDATED.SECTION_NAME
    WHEN MATCHED THEN
        UPDATE SET
            SECTION_CONTENT = UPDATED.SECTION_CONTENT
    WHEN NOT MATCHED THEN
        INSERT (
            UPDATED.DATABASE_NAME,
            UPDATED.OBJECT_NAME,
            UPDATED.SECTION_NAME,
            UPDATED.SECTION_CONTENT
        )
    """

    try:
        tdml.execute_sql(query_merge)
        logger_safe('info', f'upload_business_dictionary_sections: Merged {len(df)} row(s) into {tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS}.')
    except Exception as e:
        logger_safe('error', f'upload_business_dictionary_sections: Merge failed: {e}')
        raise
    finally:
        try:
            tdml.execute_sql(f'DROP TABLE {user_db}.{staging}')
        except Exception:
            pass


def delete_process_documentation(process_id: str) -> None:
    """Remove all documentation rows for a process from every documentation table.

    Deletes from:
    - ``FS_PROCESS_DOCUMENTATION_BUSINESS_LOGIC``  (keyed by PROCESS_ID)
    - ``FS_PROCESS_DOCUMENTATION_FEATURES``         (keyed by PROCESS_ID)
    - ``FS_PROCESS_DOCUMENTATION_EXPLAIN``          (keyed by PROCESS_ID)
    - ``FS_BUSINESS_DICTIONARY_OBJECTS``            (keyed by the process VIEW_NAME)
    - ``FS_BUSINESS_DICTIONARY_COLUMNS``            (keyed by the process VIEW_NAME)
    - ``FS_BUSINESS_DICTIONARY_SECTIONS``           (keyed by the process VIEW_NAME)

    Uses ``NONSEQUENCED VALIDTIME DELETE`` to fully remove all temporal versions,
    mirroring the approach used by ``remove_process`` for the process catalog.

    Each step is independent and non-fatal: a failure on one table is logged as a
    warning and the remaining tables are still cleaned up.

    Parameters
    ----------
    process_id : str
        UUID of the process whose documentation should be removed.
    """
    schema = tdfs4ds.SCHEMA

    # ── Tables keyed directly by PROCESS_ID ──────────────────────────────────
    _pid_tables = [
        tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC,
        tdfs4ds.DOCUMENTATION_PROCESS_FEATURES,
        tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN,
    ]
    for table in _pid_tables:
        try:
            tdml.execute_sql(
                f"NONSEQUENCED VALIDTIME DELETE FROM {schema}.{table} "
                f"WHERE PROCESS_ID = '{process_id}'"
            )
            logger_safe('info', f'delete_process_documentation: Deleted from {table} for process_id={process_id}.')
        except Exception as e:
            logger_safe('warning', f'delete_process_documentation: Could not delete from {table} for process_id={process_id}: {str(e).split(chr(10))[0]}')

    # ── Business dictionary tables keyed by VIEW_NAME ────────────────────────
    # Look up VIEW_NAME from process catalog (process still exists at this point).
    view_name = None
    try:
        query = (
            f"SELECT VIEW_NAME FROM {schema}.{tdfs4ds.PROCESS_CATALOG_NAME_VIEW} "
            f"WHERE PROCESS_ID = '{process_id}'"
        )
        _df = tdml.DataFrame.from_query(query).to_pandas()
        if _df.shape[0] > 0:
            view_name = _df['VIEW_NAME'].values[0]
    except Exception as e:
        logger_safe('warning', f'delete_process_documentation: Could not retrieve VIEW_NAME for process_id={process_id}: {str(e).split(chr(10))[0]}')

    if view_name:
        _parts = view_name.split('.')
        db_name  = _parts[0] if len(_parts) == 2 else schema
        obj_name = _parts[1] if len(_parts) == 2 else view_name

        _bd_deletes = [
            (
                tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS,
                f"DATABASE_NAME = '{db_name}' AND OBJECT_NAME = '{obj_name}'",
            ),
            (
                tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS,
                f"DATABASE_NAME = '{db_name}' AND TABLE_NAME = '{obj_name}'",
            ),
            (
                tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS,
                f"DATABASE_NAME = '{db_name}' AND OBJECT_NAME = '{obj_name}'",
            ),
        ]
        for table, where in _bd_deletes:
            try:
                tdml.execute_sql(
                    f"NONSEQUENCED VALIDTIME DELETE FROM {schema}.{table} WHERE {where}"
                )
                logger_safe('info', f'delete_process_documentation: Deleted from {table} for VIEW_NAME={view_name}.')
            except Exception as e:
                logger_safe('warning', f'delete_process_documentation: Could not delete from {table} for VIEW_NAME={view_name}: {str(e).split(chr(10))[0]}')
    else:
        logger_safe('warning', f'delete_process_documentation: VIEW_NAME not found for process_id={process_id} — business dictionary tables not cleaned.')


def delete_business_dictionary_objects(
    object_names: list,
    *,
    database_name: Optional[str] = None,
) -> None:
    """
    Expire currently-valid object-level entries from the business dictionary.

    Parameters
    ----------
    object_names : list of str
        Object names to delete (e.g. ``['TRANSACTIONS', 'CUSTOMERS']``).
    database_name : str, optional
        When provided, only rows with this DATABASE_NAME are deleted.
        When omitted, all databases are affected (useful to clean up stale
        entries that were uploaded under a wrong database name).
    """
    if not object_names:
        return

    names_list = ", ".join(f"'{n}'" for n in object_names)
    where = f"OBJECT_NAME IN ({names_list})"
    if database_name is not None:
        where += f" AND DATABASE_NAME = '{database_name}'"

    query = f"""
    CURRENT VALIDTIME DELETE FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS}
    WHERE {where}
    """

    try:
        tdml.execute_sql(query)
        logger_safe('info', f'delete_business_dictionary_objects: Expired entries for {object_names}.')
    except Exception as e:
        logger_safe('error', f'delete_business_dictionary_objects: Delete failed: {e}')
        raise


def delete_business_dictionary_columns(
    table_name: str,
    *,
    column_names: Optional[list] = None,
    database_name: Optional[str] = None,
) -> None:
    """
    Expire currently-valid column-level entries from the business dictionary.

    Parameters
    ----------
    table_name : str
        Table whose column descriptions should be deleted.
    column_names : list of str, optional
        Specific columns to delete.  When omitted all columns of the table
        are deleted.
    database_name : str, optional
        When provided, only rows with this DATABASE_NAME are deleted.
        When omitted, all databases are affected.
    """
    where = f"TABLE_NAME = '{table_name}'"
    if column_names:
        cols_list = ", ".join(f"'{c}'" for c in column_names)
        where += f" AND COLUMN_NAME IN ({cols_list})"
    if database_name is not None:
        where += f" AND DATABASE_NAME = '{database_name}'"

    query = f"""
    CURRENT VALIDTIME DELETE FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS}
    WHERE {where}
    """

    try:
        tdml.execute_sql(query)
        label = column_names or 'all columns'
        logger_safe('info', f'delete_business_dictionary_columns: Expired {label} of {table_name}.')
    except Exception as e:
        logger_safe('error', f'delete_business_dictionary_columns: Delete failed: {e}')
        raise


def delete_business_dictionary_sections(
    object_name: str,
    *,
    section_names: Optional[list] = None,
    database_name: Optional[str] = None,
) -> None:
    """
    Expire currently-valid section entries from the business dictionary.

    Parameters
    ----------
    object_name : str
        Object whose section entries should be deleted (OBJECT_NAME column).
    section_names : list of str, optional
        Specific sections to delete (e.g. ``['OVERVIEW', 'ENTITY']``).
        When omitted all sections for the object are deleted.
    database_name : str, optional
        When provided, only rows with this DATABASE_NAME are deleted.
        When omitted, all databases are affected.
    """
    where = f"OBJECT_NAME = '{object_name}'"
    if section_names:
        secs_list = ", ".join(f"'{s}'" for s in section_names)
        where += f" AND SECTION_NAME IN ({secs_list})"
    if database_name is not None:
        where += f" AND DATABASE_NAME = '{database_name}'"

    query = f"""
    CURRENT VALIDTIME DELETE FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS}
    WHERE {where}
    """

    try:
        tdml.execute_sql(query)
        label = section_names or 'all sections'
        logger_safe('info', f'delete_business_dictionary_sections: Expired {label} of {object_name}.')
    except Exception as e:
        logger_safe('error', f'delete_business_dictionary_sections: Delete failed: {e}')
        raise


def remove_object_documentation(
    object_name: str,
    database_name: Optional[str] = None,
) -> None:
    """
    Remove all business dictionary documentation for a given object in one call.

    Deletes all currently-valid rows keyed on *object_name* from:

    - ``FS_BUSINESS_DICTIONARY_OBJECTS``  — object-level description
    - ``FS_BUSINESS_DICTIONARY_SECTIONS`` — structured sections (OVERVIEW, ENTITY, …)
    - ``FS_BUSINESS_DICTIONARY_COLUMNS``  — column / feature descriptions

    Designed to be called alongside ``DROP VIEW`` / ``DROP TABLE`` for any
    documented object: dataset views, process views, source tables, etc.
    Failures on individual tables are non-fatal warnings so a partial cleanup
    does not abort the caller.

    Parameters
    ----------
    object_name : str
        The OBJECT_NAME / TABLE_NAME to remove (leading/trailing quotes are
        stripped automatically).
    database_name : str, optional
        Restrict deletion to this database. When omitted, all databases are
        affected (useful when the database is unknown or may vary).
    """
    clean_name = object_name.strip('"').upper()

    steps = [
        ('objects',  lambda: delete_business_dictionary_objects([clean_name], database_name=database_name)),
        ('sections', lambda: delete_business_dictionary_sections(clean_name, database_name=database_name)),
        ('columns',  lambda: delete_business_dictionary_columns(clean_name, database_name=database_name)),
    ]
    for label, fn in steps:
        try:
            fn()
        except Exception as e:
            logger_safe('warning', f'remove_object_documentation: failed to delete {label} for {clean_name}: {e}')

    logger_safe('info', f'remove_object_documentation: removed all BD documentation for {clean_name}.')


# ─── Agentic incremental documentation helpers ────────────────────────────────

def _normalize_node_name(node_name: str):
    """
    Strip outer quotes from a graph node name, return (database_upper, object_upper).
    Handles: '"DB"."OBJ"', '<DEFAULT_DATABASE>."OBJ"', 'DB.OBJ'.
    """
    s = node_name.strip()
    if s.startswith('<DEFAULT_DATABASE>'):
        parts = s.split('.', 1)
        obj = parts[1].strip('"') if len(parts) > 1 else s
        return None, obj.upper()
    if '"' in s:
        bits = s.split('.')
        if len(bits) >= 2:
            return bits[0].strip('"').upper(), bits[1].strip('"').upper()
        return None, s.strip('"').upper()
    if '.' in s:
        db, obj = s.split('.', 1)
        return db.strip().upper(), obj.strip().upper()
    return None, s.upper()


def _load_fs_feature_tables_cache() -> set:
    """Return a set of (DATABASE_UPPER, TABLE_UPPER) for all physical feature storage tables."""
    try:
        rows = tdml.execute_sql(
            f"SELECT UPPER(TRIM(FEATURE_DATABASE)), UPPER(TRIM(FEATURE_TABLE)) "
            f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.FEATURE_CATALOG_NAME_VIEW}"
        ).fetchall()
        return {(r[0], r[1]) for r in rows}
    except Exception as e:
        logger_safe('warning', f'_load_fs_feature_tables_cache: could not load: {e}')
        return set()


def _is_internal_fs_node(db: Optional[str], obj: str, fs_tables_cache: set) -> bool:
    """Return True for internal feature store objects that should be silently skipped."""
    if obj.upper().endswith('_HIDDEN'):
        return True
    if db and (db.upper(), obj.upper()) in fs_tables_cache:
        return True
    return False


def _classify_fs_nodes(graph: Dict[str, Any]) -> None:
    """
    Tag view nodes in-place as feature store views ('fs_type': 'F') if they appear
    in FS_V_PROCESS_CATALOG. Adds 'fs_process_id' for matched nodes.
    Uses a single batch query for all view nodes.
    """
    view_nodes = [name for name, info in graph['nodes'].items() if info.get('object_type') == 'view']
    if not view_nodes:
        return

    node_lookup: Dict[str, str] = {}
    for name in view_nodes:
        db, obj = _normalize_node_name(name)
        key = f"{db}.{obj}" if db else obj
        node_lookup[key] = name

    try:
        rows = tdml.execute_sql(
            f"SELECT UPPER(TRIM(VIEW_NAME)), PROCESS_ID "
            f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.PROCESS_CATALOG_NAME_VIEW}"
        ).fetchall()
    except Exception as e:
        logger_safe('warning', f'_classify_fs_nodes: could not query process catalog: {e}')
        return

    for view_name_raw, process_id in rows:
        if not view_name_raw:
            continue
        key = view_name_raw.strip().upper()
        if key in node_lookup:
            orig = node_lookup[key]
            graph['nodes'][orig]['fs_type'] = 'F'
            graph['nodes'][orig]['fs_process_id'] = process_id


def _topological_sort(graph: Dict[str, Any]) -> List[str]:
    """
    Return node names bottom-up: leaves (base tables, no dependencies) first, root last.
    Edges are (parent, child) — parent depends on child.
    Kahn's on the reversed direction gives leaves first.
    """
    nodes = set(graph['nodes'].keys())
    edges = graph.get('edges', [])

    children_of: Dict[str, set] = {n: set() for n in nodes}
    parents_of: Dict[str, set] = {n: set() for n in nodes}
    for parent, child in edges:
        children_of.setdefault(parent, set()).add(child)
        parents_of.setdefault(child, set()).add(parent)

    remaining = {n: set(children_of.get(n, set())) for n in nodes}
    queue = [n for n in nodes if not remaining[n]]
    result: List[str] = []

    while queue:
        node = queue.pop(0)
        result.append(node)
        for parent in parents_of.get(node, set()):
            remaining[parent].discard(node)
            if not remaining[parent]:
                queue.append(parent)

    visited = set(result)
    result += [n for n in nodes if n not in visited]
    return result


def _get_direct_children(graph: Dict[str, Any], node_name: str) -> List[str]:
    """Return direct dependencies (children) of node_name in the graph."""
    return [child for parent, child in graph.get('edges', []) if parent == node_name]


def _fetch_context_for_node(db: Optional[str], obj: str) -> Optional[Dict[str, Any]]:
    """
    Look up documentation for (db, obj) in FS_BUSINESS_DICTIONARY_OBJECTS and
    FS_BUSINESS_DICTIONARY_COLUMNS. Returns None if no object-level entry found.
    """
    if not db:
        return None
    try:
        row = tdml.execute_sql(
            f"CURRENT VALIDTIME SELECT OBJECT_TYPE, BUSINESS_DESCRIPTION "
            f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS} "
            f"WHERE DATABASE_NAME = '{db}' AND OBJECT_NAME = '{obj}'"
        ).fetchone()
    except Exception as e:
        logger_safe('warning', f'_fetch_context_for_node: lookup failed for {db}.{obj}: {e}')
        return None

    if not row:
        return None

    obj_type, obj_desc = row[0], row[1]

    try:
        col_rows = tdml.execute_sql(
            f"CURRENT VALIDTIME SELECT COLUMN_NAME, BUSINESS_DESCRIPTION "
            f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS} "
            f"WHERE DATABASE_NAME = '{db}' AND TABLE_NAME = '{obj}'"
        ).fetchall()
    except Exception as e:
        logger_safe('warning', f'_fetch_context_for_node: column lookup failed for {db}.{obj}: {e}')
        col_rows = []

    return {
        'db': db,
        'obj': obj,
        'object_type': obj_type,
        'object_description': obj_desc or '',
        'columns': {r[0].strip(): r[1] for r in col_rows if r[1]},
    }


def _format_upstream_context(context_map: Dict[str, Dict[str, Any]]) -> str:
    """
    Format upstream context as a structured text block for the LLM prompt.
    Returns empty string when context_map is empty so the prompt stays clean.
    """
    if not context_map:
        return ""

    type_labels = {'T': 'Table', 'V': 'View', 'F': 'Feature Store Process', 'D': 'Dataset'}
    lines = [
        "",
        "KNOWN UPSTREAM DOCUMENTATION — use column descriptions as ground truth anchors:",
        "",
    ]
    for ctx in context_map.values():
        label = type_labels.get(ctx.get('object_type', 'V'), 'Object')
        lines.append(f"[{ctx['db']}.{ctx['obj']}] ({label})")
        if ctx.get('object_description'):
            lines.append(f"  Description: {ctx['object_description']}")
        if ctx.get('columns'):
            lines.append("  Columns:")
            for col, desc in ctx['columns'].items():
                lines.append(f"    - {col}: {desc}")
        lines.append("")
    return "\n".join(lines)


def _fetch_sections_for_node(db: str, obj: str) -> Dict[str, str]:
    """
    Look up stored sections for (db, obj) in FS_BUSINESS_DICTIONARY_SECTIONS.
    Returns a dict mapping section_name -> section_content, or empty dict.
    """
    try:
        rows = tdml.execute_sql(
            f"CURRENT VALIDTIME SELECT SECTION_NAME, SECTION_CONTENT "
            f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS} "
            f"WHERE DATABASE_NAME = '{db}' AND OBJECT_NAME = '{obj}'"
        ).fetchall()
        return {r[0].strip(): r[1] for r in rows if r[1]}
    except Exception as e:
        logger_safe('warning', f'_fetch_sections_for_node: lookup failed for {db}.{obj}: {e}')
        return {}


def _get_view_columns(db: str, obj: str) -> List[str]:
    """Return ordered column names for a view or table via DBC.ColumnsV."""
    try:
        rows = tdml.execute_sql(
            f"SELECT ColumnName FROM DBC.ColumnsV "
            f"WHERE DatabaseName = '{db}' AND TableName = '{obj}' "
            f"ORDER BY ColumnId"
        ).fetchall()
        return [r[0].strip() for r in rows]
    except Exception as e:
        logger_safe('warning', f'_get_view_columns: failed for {db}.{obj}: {e}')
        return []


def _store_intermediate_view_doc(
    db: str,
    obj: str,
    object_description: str,
    column_docs: Dict[str, str],
) -> None:
    """Persist generated documentation for an intermediate view to the business dictionary."""
    df_obj = pd.DataFrame([{
        'DATABASE_NAME': db,
        'OBJECT_NAME': obj,
        'OBJECT_TYPE': 'V',
        'BUSINESS_DESCRIPTION': _sanitize_for_teradata(object_description),
    }])
    upload_business_dictionary_objects(df_obj)

    if column_docs:
        df_cols = pd.DataFrame([
            {
                'DATABASE_NAME': db,
                'TABLE_NAME': obj,
                'COLUMN_NAME': col,
                'BUSINESS_DESCRIPTION': _sanitize_for_teradata(desc),
            }
            for col, desc in column_docs.items()
        ])
        upload_business_dictionary_columns(df_cols)


def _document_intermediate_view(
    node_name: str,
    node_meta: Dict[str, Any],
    graph: Dict[str, Any],
    language: str = "English",
) -> None:
    """
    Generate and store documentation for a non-feature-store intermediate view,
    using its direct children's already-resolved context as upstream anchors.
    """
    db = node_meta.get('database')
    obj = node_meta.get('object')
    if not db or not obj:
        db, obj = _normalize_node_name(node_name)
    if not db or not obj:
        logger_safe('warning', f'_document_intermediate_view: cannot resolve db/obj for {node_name}')
        return

    ddl = node_meta.get('ddl') or ''

    direct_children = _get_direct_children(graph, node_name)
    upstream_context_map: Dict[str, Dict[str, Any]] = {}
    for child in direct_children:
        child_meta = graph['nodes'].get(child, {})
        child_db = child_meta.get('database')
        child_obj = child_meta.get('object')
        if not child_db or not child_obj:
            child_db, child_obj = _normalize_node_name(child)
        if child_db and child_obj:
            ctx = _fetch_context_for_node(child_db, child_obj)
            if ctx:
                upstream_context_map[child] = ctx

    columns = _get_view_columns(db, obj)
    if not columns:
        logger_safe('warning', f'_document_intermediate_view: no columns found for {db}.{obj}, skipping.')
        return

    logger_safe('info', f'_document_intermediate_view: generating docs for {db}.{obj} ({len(columns)} columns)')
    try:
        docs = document_sql_query_columns(
            sql_query=ddl or f'SELECT * FROM {db}.{obj}',
            entity_columns=[],
            feature_columns=columns,
            language=language,
            upstream_context=_format_upstream_context(upstream_context_map),
        )
    except Exception as e:
        logger_safe('error', f'_document_intermediate_view: LLM call failed for {db}.{obj}: {e}')
        return

    _store_intermediate_view_doc(
        db=db,
        obj=obj,
        object_description=docs.get('query_business_logic', ''),
        column_docs=docs.get('feature_columns', {}),
    )
    logger_safe('info', f'_document_intermediate_view: stored docs for {db}.{obj}')


def document_process_incremental(
    process_id: str,
    language: str = "English",
    json_constraint: bool = True,
    show_sql_query: bool = False,
    show_explain_plan: bool = False,
    display: bool = True,
    upload: bool = True,
    force_update: bool = False,
    _visited_processes: Optional[set] = None,
    _visited_views: Optional[set] = None,
) -> Optional[Dict[str, Any]]:
    """
    Generate documentation for a process incrementally and bottom-up.

    Traverses the full dependency graph of the process SQL. At each level:
    - Internal feature store tables (in FS_FEATURE_CATALOG or _HIDDEN suffix)
      are silently skipped.
    - Base tables with no business dictionary entry trigger a warning;
      the process continues best-effort without their context.
    - Regular intermediate views with no documentation are automatically
      documented (their own sources resolved first before proceeding upward).
    - Feature store views (type 'F' in FS_BUSINESS_DICTIONARY_OBJECTS, or
      detected via FS_V_PROCESS_CATALOG) are treated as leaves; if undocumented,
      a warning is emitted and they are omitted from context.

    The current process is documented last, using the fully resolved upstream
    context from its direct source objects as ground truth anchors for the LLM.

    Parameters
    ----------
    process_id : str
        UUID of the process to document.
    language : str
        Output language for LLM-generated descriptions.
    json_constraint : bool
        Whether to enforce JSON schema in the LLM output.
    show_sql_query : bool
        Include original SQL in the display output.
    show_explain_plan : bool
        Include raw EXPLAIN plan in the display output.
    display : bool
        Whether to print/render the documentation.
    upload : bool
        Whether to persist the documentation to the catalog tables.
    force_update : bool
        If True, regenerate documentation even for already-documented nodes.
    _visited_processes : set, optional
        Internal recursion guard — do not pass manually.
    _visited_views : set, optional
        Internal recursion guard — do not pass manually.

    Returns
    -------
    dict or None
        Same structure as document_process().
    """
    if _visited_processes is None:
        _visited_processes = set()
    if _visited_views is None:
        _visited_views = set()

    if process_id in _visited_processes:
        logger_safe('info', f'document_process_incremental: already processed {process_id}, skipping.')
        return None
    _visited_processes.add(process_id)

    logger_safe('info', f'document_process_incremental: starting for process_id={process_id}')

    # 1. Retrieve process info
    try:
        process_info = tdfs4ds.process_store.process_store_catalog_management.get_process_info(process_id)
    except Exception as e:
        logger_safe('error', f'document_process_incremental: cannot get process info: {e}')
        return None
    if not process_info:
        return None

    sql = process_info.get('PROCESS_SQL', '')

    # 2. Load internal FS tables cache (single query for all nodes)
    fs_tables_cache = _load_fs_feature_tables_cache()

    # 3. Build full dependency graph with DDL stored for intermediate views
    from tdfs4ds.lineage import build_teradata_dependency_graph
    try:
        graph = build_teradata_dependency_graph(sql, default_database=tdfs4ds.SCHEMA, store_ddl=True)
    except Exception as e:
        logger_safe('error', f'document_process_incremental: lineage build failed: {e}')
        graph = {'nodes': {}, 'edges': [], 'roots': []}

    # 4. Tag feature store view nodes
    _classify_fs_nodes(graph)

    # 5. Topological sort — base tables first, process view last
    topo_order = _topological_sort(graph)
    root_names = set(graph.get('roots', []))

    # 6. Walk bottom-up, resolve/generate documentation at each node
    for node_name in topo_order:
        if node_name in root_names:
            continue
        if node_name in _visited_views:
            continue

        node_meta = graph['nodes'].get(node_name, {})
        obj_type = node_meta.get('object_type', 'unknown')
        db, obj = node_meta.get('database'), node_meta.get('object')
        if not db or not obj:
            db, obj = _normalize_node_name(node_name)

        if _is_internal_fs_node(db, obj, fs_tables_cache):
            _visited_views.add(node_name)
            continue

        _visited_views.add(node_name)

        if obj_type == 'table':
            if not _fetch_context_for_node(db, obj):
                logger_safe('warning',
                    f'document_process_incremental: no business dictionary entry for '
                    f'table {db}.{obj} — omitting from upstream context (best-effort).')

        elif obj_type == 'view':
            fs_type = node_meta.get('fs_type')
            if fs_type == 'F':
                if not _fetch_context_for_node(db, obj):
                    logger_safe('warning',
                        f'document_process_incremental: feature store view {db}.{obj} '
                        f'has no business dictionary entry — omitting from upstream context.')
            else:
                if force_update or not _fetch_context_for_node(db, obj):
                    _document_intermediate_view(node_name, node_meta, graph, language=language)

    # 7. Collect upstream context for direct children of the process view
    view_name_raw = process_info.get('VIEW_NAME', '')
    vn_parts = view_name_raw.upper().replace('"', '').split('.')

    root_node = None
    for root in root_names:
        root_db, root_obj = _normalize_node_name(root)
        if len(vn_parts) == 2 and root_db and root_obj:
            if root_db == vn_parts[0] and root_obj == vn_parts[1]:
                root_node = root
                break
    if root_node is None and root_names:
        root_node = next(iter(root_names))

    direct_sources = _get_direct_children(graph, root_node) if root_node else []

    upstream_context_map: Dict[str, Dict[str, Any]] = {}
    missing_context: List[str] = []
    for src in direct_sources:
        src_meta = graph['nodes'].get(src, {})
        src_db = src_meta.get('database')
        src_obj = src_meta.get('object')
        if not src_db or not src_obj:
            src_db, src_obj = _normalize_node_name(src)
        if src_db and src_obj:
            ctx = _fetch_context_for_node(src_db, src_obj)
            if ctx:
                upstream_context_map[src] = ctx
            elif not _is_internal_fs_node(src_db, src_obj, fs_tables_cache):
                missing_context.append(f'{src_db}.{src_obj}')

    if missing_context:
        logger_safe('warning',
            f'document_process_incremental: proceeding best-effort — '
            f'no upstream context for: {missing_context}')

    upstream_context_str = _format_upstream_context(upstream_context_map)

    # 8. Document the current process with enriched upstream context
    documentation = document_sql_query_columns(
        sql_query=sql,
        entity_columns=process_info.get('ENTITY_COLUMNS', []),
        feature_columns=process_info.get('FEATURE_COLUMNS', []),
        language=language,
        json_constraint=json_constraint,
        upstream_context=upstream_context_str,
    )

    process_info['DOCUMENTED_SQL']             = documentation.get('query_business_logic', '')
    process_info['ENTITY_DESCRIPTION']         = documentation.get('entity_description', '')
    process_info['DOCUMENTED_ENTITY_COLUMNS']  = documentation.get('entity_columns', {})
    process_info['DOCUMENTED_FEATURE_COLUMNS'] = documentation.get('feature_columns', {})

    # 9. EXPLAIN analysis
    try:
        explain_doc = document_sql_query_explain(sql_query=sql)
        process_info['EXPLAIN_ANALYSIS']        = explain_doc.get('explanation', '')
        process_info['USER_SCORE']              = explain_doc.get('user_score')
        process_info['OPTIMIZATION_SCORE']      = explain_doc.get('global_score')
        process_info['EXPLAIN_WARNINGS']        = explain_doc.get('warnings', [])
        process_info['EXPLAIN_RECOMMENDATIONS'] = explain_doc.get('recommendations', [])
        process_info['EXPLAIN_N_STEPS']         = explain_doc.get('n_steps')
        process_info['EXPLAIN_N_SPOOL_OBJECTS'] = explain_doc.get('n_spool_objects')
    except Exception as e:
        logger_safe('error', f'document_process_incremental: EXPLAIN analysis failed: {e}')

    if show_explain_plan:
        try:
            process_info['RAW_EXPLAIN_PLAN'] = get_the_explain(sql)
        except Exception:
            pass

    # 10. Upload
    if upload:
        try:
            upload_documentation(process_info)
            logger_safe('info', f'document_process_incremental: uploaded documentation for {process_id}.')
        except Exception as e:
            logger_safe('error', f'document_process_incremental: upload_documentation failed: {e}')
        try:
            upload_documentation_explain(process_info)
        except Exception as e:
            logger_safe('error', f'document_process_incremental: upload_documentation_explain failed: {e}')

    # 11. Display
    if display:
        _print_documentation(
            documented_sql             = process_info.get('DOCUMENTED_SQL'),
            entity_description         = process_info.get('ENTITY_DESCRIPTION'),
            documented_entity_columns  = process_info.get('DOCUMENTED_ENTITY_COLUMNS'),
            documented_feature_columns = process_info.get('DOCUMENTED_FEATURE_COLUMNS'),
            process_id                 = process_info.get('PROCESS_ID', process_id),
            view_name                  = process_info.get('VIEW_NAME'),
            explain_analysis           = process_info.get('EXPLAIN_ANALYSIS'),
            user_score                 = process_info.get('USER_SCORE'),
            optimization_score         = process_info.get('OPTIMIZATION_SCORE'),
            explain_warnings           = process_info.get('EXPLAIN_WARNINGS'),
            explain_recommendations    = process_info.get('EXPLAIN_RECOMMENDATIONS'),
            sql_query                  = process_info.get('PROCESS_SQL') if show_sql_query else None,
            explain_plan               = process_info.get('RAW_EXPLAIN_PLAN') if show_explain_plan else None,
            n_steps                    = process_info.get('EXPLAIN_N_STEPS'),
            n_spool_objects            = process_info.get('EXPLAIN_N_SPOOL_OBJECTS'),
        )

    return process_info


# ─── Dataset incremental documentation helpers ──────────────────────────────────

def _extract_feature_process_map_from_ddl(ddl: str) -> Dict[str, str]:
    """
    Parse a dataset view DDL and return a mapping of feature name (upper) to PROCESS_ID.

    Dataset subqueries look like:
        ... B1.FEATURE_VALUE AS <feature_name> FROM "DB"."TABLE" B1
            WHERE (FEATURE_ID = 1 AND FEATURE_VERSION='<process_id>')
    """
    pattern = re.compile(
        r"B1\.FEATURE_VALUE\s+AS\s+(?P<fname>[A-Za-z_][\w]*)"
        r".*?FEATURE_VERSION\s*=\s*'(?P<fver>[^']+)'",
        re.IGNORECASE | re.DOTALL,
    )
    return {m.group('fname').upper(): m.group('fver') for m in pattern.finditer(ddl)}


def _get_dataset_info(dataset_id: str) -> Optional[Dict[str, Any]]:
    """
    Resolve a dataset_id to its metadata: name, database, DDL, entity columns,
    and feature-to-process_id mapping.

    Returns None if the dataset is not found in the catalog.
    """
    cat_view = f"{tdfs4ds.SCHEMA}.FS_V_{tdfs4ds.DATASET_CATALOG_NAME}_CATALOG"
    ent_view = f"{tdfs4ds.SCHEMA}.FS_V_{tdfs4ds.DATASET_CATALOG_NAME}_ENTITY"
    feat_view = f"{tdfs4ds.SCHEMA}.FS_V_{tdfs4ds.DATASET_CATALOG_NAME}_FEATURES"

    # Catalog row
    try:
        row = tdml.execute_sql(
            f"SELECT DATASET_NAME, DATASET_DATABASE "
            f"FROM {cat_view} WHERE DATASET_ID = '{dataset_id}'"
        ).fetchone()
    except Exception as e:
        logger_safe('error', f'_get_dataset_info: catalog query failed: {e}')
        return None
    if not row:
        logger_safe('error', f'_get_dataset_info: dataset_id {dataset_id} not found in catalog.')
        return None

    dataset_name = row[0].strip()
    dataset_database = row[1].strip()

    # DDL
    try:
        ddl = tdml.execute_sql(
            f'SHOW VIEW {dataset_database}.{dataset_name}'
        ).fetchall()[0][0].replace('\r', '\n')
    except Exception as e:
        logger_safe('error', f'_get_dataset_info: SHOW VIEW failed for {dataset_database}.{dataset_name}: {e}')
        return None

    # Entity columns
    entity = {}
    try:
        ent_rows = tdml.execute_sql(
            f"SELECT ENTITY, ENTITY_TYPE FROM {ent_view} "
            f"WHERE DATASET_ID = '{dataset_id}'"
        ).fetchall()
        entity = {r[0].strip(): r[1].strip() for r in ent_rows}
    except Exception as e:
        logger_safe('warning', f'_get_dataset_info: entity query failed: {e}')

    # Feature -> process_id mapping from DDL
    feature_process_map = _extract_feature_process_map_from_ddl(ddl)

    # Feature names from catalog (for reference)
    feature_names = []
    try:
        feat_rows = tdml.execute_sql(
            f"SELECT FEATURE_NAME FROM {feat_view} "
            f"WHERE DATASET_ID = '{dataset_id}'"
        ).fetchall()
        feature_names = [r[0].strip().upper() for r in feat_rows]
    except Exception as e:
        logger_safe('warning', f'_get_dataset_info: features query failed: {e}')

    return {
        'DATASET_ID': dataset_id,
        'DATASET_NAME': dataset_name,
        'DATASET_DATABASE': dataset_database,
        'DATASET_DDL': ddl,
        'entity': entity,
        'feature_process_map': feature_process_map,
        'feature_names': feature_names,
    }


def _propagate_docs_from_processes(
    feature_process_map: Dict[str, str],
    entity_columns: List[str],
) -> Dict[str, Any]:
    """
    Propagate feature and entity documentation from process docs.

    For each feature, retrieves the process documentation and copies the
    matching feature description. Also collects entity descriptions and
    process-level business logic descriptions.

    Returns a dict with keys:
        - documented_feature_columns: {feature_name: description}
        - documented_entity_columns: {entity_col: description}
        - entity_description: str
        - process_descriptions: {process_id: business_logic_description}
        - missing_features: [feature_names with no doc found]
    """
    documented_feature_columns: Dict[str, str] = {}
    documented_entity_columns: Dict[str, str] = {}
    entity_description = ''
    process_descriptions: Dict[str, str] = {}
    missing_features: List[str] = []

    # Group features by process_id to avoid redundant retrieve_documentation calls
    pid_to_features: Dict[str, List[str]] = {}
    for feat_name, pid in feature_process_map.items():
        pid_to_features.setdefault(pid, []).append(feat_name)

    for pid, feat_names in pid_to_features.items():
        proc_doc = retrieve_documentation(pid)
        if not proc_doc:
            logger_safe('warning',
                f'_propagate_docs_from_processes: no documentation found for '
                f'process_id {pid} — features {feat_names} will have no description.')
            missing_features.extend(feat_names)
            continue

        # Process-level description
        if proc_doc.get('DOCUMENTED_SQL') and pid not in process_descriptions:
            process_descriptions[pid] = proc_doc['DOCUMENTED_SQL']

        # Entity description (take first non-empty)
        if not entity_description and proc_doc.get('ENTITY_DESCRIPTION'):
            entity_description = proc_doc['ENTITY_DESCRIPTION']

        # Entity columns (take first non-empty for each column)
        for col, desc in (proc_doc.get('DOCUMENTED_ENTITY_COLUMNS') or {}).items():
            col_upper = col.upper()
            if col_upper not in documented_entity_columns and desc:
                # Only propagate if this entity column is actually in the dataset
                if any(e.upper() == col_upper for e in entity_columns):
                    documented_entity_columns[col_upper] = desc

        # Feature columns — case-insensitive match
        proc_features = proc_doc.get('DOCUMENTED_FEATURE_COLUMNS') or {}
        proc_features_upper = {k.upper(): v for k, v in proc_features.items()}
        for feat_name in feat_names:
            desc = proc_features_upper.get(feat_name.upper())
            if desc:
                documented_feature_columns[feat_name] = desc
            else:
                missing_features.append(feat_name)
                logger_safe('warning',
                    f'_propagate_docs_from_processes: feature {feat_name} not found in '
                    f'process {pid} documentation.')

    return {
        'documented_feature_columns': documented_feature_columns,
        'documented_entity_columns': documented_entity_columns,
        'entity_description': entity_description,
        'process_descriptions': process_descriptions,
        'missing_features': missing_features,
    }


DATASET_SECTION_NAMES = ['OVERVIEW', 'ENTITY', 'FEATURE_THEMES', 'BUSINESS_QUESTIONS', 'INTENDED_AUDIENCE']
"""Standard section names produced by ``_generate_dataset_description``."""


def _generate_dataset_description(
    dataset_name: str,
    entity_description: str,
    entity_column_docs: Dict[str, str],
    feature_docs: Dict[str, str],
    process_descriptions: Dict[str, str],
    language: str = "English",
) -> Dict[str, str]:
    """
    Generate a structured business description for a dataset using a single
    LLM call with JSON-constrained output.

    Returns a dict with one key per section, each independently storable as
    a RAG document in ``FS_BUSINESS_DICTIONARY_SECTIONS``:

    - **OVERVIEW** — what the dataset represents, at what grain, primary purpose
    - **ENTITY** — business meaning of each entity column
    - **FEATURE_THEMES** — features grouped by logical themes
    - **BUSINESS_QUESTIONS** — 3-5 concrete questions the dataset answers
    - **INTENDED_AUDIENCE** — who benefits and in what workflows

    Returns
    -------
    dict[str, str]
        Mapping of section name to section content.
        Empty dict on LLM failure.
    """
    from langchain_core.prompts import ChatPromptTemplate   # lazy — only load when generating dataset docs
    from langchain_core.output_parsers import JsonOutputParser
    from langchain_core.runnables import RunnableLambda
    from langchain_core.messages import AIMessage
    entity_cols_text = "\n".join(
        f"  - {name}: {desc}" for name, desc in entity_column_docs.items()
    ) or "  (no entity column descriptions available)"

    features_text = "\n".join(
        f"  - {name}: {desc}" for name, desc in feature_docs.items()
    ) or "  (no feature descriptions available)"

    processes_text = "\n".join(
        f"  - {desc}" for desc in process_descriptions.values()
    ) or "  (no process descriptions available)"

    json_schema = {
        "type": "object",
        "properties": {
            "OVERVIEW":           {"type": "string"},
            "ENTITY":             {"type": "string"},
            "FEATURE_THEMES":     {"type": "string"},
            "BUSINESS_QUESTIONS": {"type": "string"},
            "INTENDED_AUDIENCE":  {"type": "string"},
        },
        "required": DATASET_SECTION_NAMES,
    }

    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a senior data documentation assistant for an enterprise feature store. "
         "Your output will be stored as separate sections in a hierarchical "
         "retrieval-augmented generation (RAG) system. Each section is independently "
         "retrievable, so each must be self-contained and informative on its own.\n\n"
         "Write in {language}. Be precise, business-oriented, and comprehensive.\n\n"
         "IMPORTANT: Return a JSON object with exactly these keys: "
         "OVERVIEW, ENTITY, FEATURE_THEMES, BUSINESS_QUESTIONS, INTENDED_AUDIENCE. "
         "Each value is a plain text string (no markdown, no nested JSON)."),
        ("human",
         "A dataset named '{dataset_name}' has been built in an enterprise feature store.\n\n"
         "ENTITY DESCRIPTION:\n{entity_description}\n\n"
         "ENTITY COLUMNS (the keys that define each row):\n{entity_cols_text}\n\n"
         "FEATURES (the analytical columns):\n{features_text}\n\n"
         "SOURCE PROCESSES (business logic that produces the features):\n{processes_text}\n\n"
         "Generate the JSON with these sections:\n\n"
         "OVERVIEW: What this dataset represents, at what grain (entity level), and "
         "its primary purpose. One solid paragraph.\n\n"
         "ENTITY: Describe what each entity column means and how they jointly define "
         "the observation unit. Mention the business meaning, not just the column name.\n\n"
         "FEATURE_THEMES: Group the features into logical themes (e.g. monetary, "
         "behavioural, categorical). For each theme, summarise what it captures and list "
         "the relevant feature names. This helps a reader quickly understand the breadth "
         "of the dataset without reading every column description.\n\n"
         "BUSINESS_QUESTIONS: List 3-5 concrete business questions or analytical use "
         "cases this dataset can answer. Be specific — name the features involved.\n\n"
         "INTENDED_AUDIENCE: Who benefits from this dataset (e.g. data scientists, "
         "marketing analysts, risk teams) and in what workflows.\n\n"
         "Be factual — only describe what is present in the entity and feature lists above."),
    ])

    try:
        llm = build_llm(
            llm_service=tdfs4ds.INSTRUCT_MODEL_URL,
            api_key=tdfs4ds.INSTRUCT_MODEL_API_KEY,
            model_id=tdfs4ds.INSTRUCT_MODEL_MODEL,
        )

        provider = (tdfs4ds.INSTRUCT_MODEL_PROVIDER or '').lower()
        if provider in ('vllm', 'openai-compatible'):
            chain = prompt | llm.bind(
                extra_body={"guided_json": json.dumps(json_schema)}
            ) | _robust_json_parser
        elif provider in ('openai', 'azure'):
            chain = prompt | llm.with_structured_output(json_schema)
        else:
            chain = prompt | llm | _robust_json_parser

        result = chain.invoke({
            'language': language,
            'dataset_name': dataset_name,
            'entity_description': entity_description or '(not available)',
            'entity_cols_text': entity_cols_text,
            'features_text': features_text,
            'processes_text': processes_text,
        })

        # Normalise: ensure all expected keys exist
        if isinstance(result, dict):
            return {k: result.get(k, '') for k in DATASET_SECTION_NAMES}

        # Fallback: if we got a string (no JSON parsing), put it all in OVERVIEW
        text = result.content.strip() if hasattr(result, 'content') else str(result).strip()
        logger_safe('warning', '_generate_dataset_description: LLM returned plain text, storing as OVERVIEW only.')
        return {k: '' for k in DATASET_SECTION_NAMES} | {'OVERVIEW': text}

    except Exception as e:
        logger_safe('error', f'_generate_dataset_description: LLM call failed: {e}')
        return {}


def _store_dataset_doc(
    db: str,
    obj: str,
    sections: Dict[str, str],
    column_docs: Dict[str, str],
) -> None:
    """Persist generated documentation for a dataset to the business dictionary.

    Stores:
    - Object-level entry in FS_BUSINESS_DICTIONARY_OBJECTS (type 'D')
      with the OVERVIEW section as BUSINESS_DESCRIPTION.
    - One row per section in FS_BUSINESS_DICTIONARY_SECTIONS.
    - One row per column in FS_BUSINESS_DICTIONARY_COLUMNS.
    """
    overview = sections.get('OVERVIEW', '')

    # Level 0 — object entry
    df_obj = pd.DataFrame([{
        'DATABASE_NAME': db,
        'OBJECT_NAME': obj,
        'OBJECT_TYPE': 'D',
        'BUSINESS_DESCRIPTION': _sanitize_for_teradata(overview),
    }])
    upload_business_dictionary_objects(df_obj)

    # Level 1 — sections
    section_rows = [
        {
            'DATABASE_NAME': db,
            'OBJECT_NAME': obj,
            'SECTION_NAME': section_name,
            'SECTION_CONTENT': content,
        }
        for section_name, content in sections.items()
        if content
    ]
    if section_rows:
        upload_business_dictionary_sections(pd.DataFrame(section_rows))

    # Level 2 — columns
    if column_docs:
        df_cols = pd.DataFrame([
            {
                'DATABASE_NAME': db,
                'TABLE_NAME': obj,
                'COLUMN_NAME': col,
                'BUSINESS_DESCRIPTION': _sanitize_for_teradata(desc),
            }
            for col, desc in column_docs.items()
        ])
        upload_business_dictionary_columns(df_cols)


_SECTION_DISPLAY_LABELS = {
    'OVERVIEW': 'Overview',
    'ENTITY': 'Entity',
    'FEATURE_THEMES': 'Feature Themes',
    'BUSINESS_QUESTIONS': 'Business Questions',
    'INTENDED_AUDIENCE': 'Intended Audience',
}


def _print_dataset_documentation(
    dataset_name: str,
    dataset_database: str,
    dataset_id: str,
    sections: Dict[str, str],
    documented_entity_columns: Dict[str, str],
    documented_feature_columns: Dict[str, str],
) -> None:
    """Pretty-print dataset documentation with context-aware formatting."""
    title = f"Dataset: {dataset_database}.{dataset_name}  (ID: {dataset_id})"

    if _is_notebook():
        # Sections
        sections_html = ""
        for key in DATASET_SECTION_NAMES:
            content = sections.get(key, '')
            if not content:
                continue
            label = _SECTION_DISPLAY_LABELS.get(key, key)
            content_html = content.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('\n', '<br>')
            sections_html += f"""
            <h3 style="{HTML_STYLES['heading_margin']}">{label}</h3>
            <p style="{HTML_STYLES['content']}">{content_html}</p>
            """

        entity_items = (
            '\n'.join(f'<li><strong>{col}:</strong> {desc}</li>'
                      for col, desc in documented_entity_columns.items())
            if documented_entity_columns
            else "<li><em>No entity columns documented.</em></li>"
        )
        feature_items = (
            '\n'.join(f'<li><strong>{col}:</strong> {desc}</li>'
                      for col, desc in documented_feature_columns.items())
            if documented_feature_columns
            else "<li><em>No feature columns documented.</em></li>"
        )

        html_content = f"""
        <div style="{HTML_STYLES['container']}">
        <h2>{title}</h2>
        {sections_html}
        <h3 style="{HTML_STYLES['heading_margin']}">Entity Columns</h3>
        <ul style="{HTML_STYLES['list']}">{entity_items}</ul>

        <h3 style="{HTML_STYLES['heading_margin']}">Feature Columns</h3>
        <ul style="{HTML_STYLES['list']}">{feature_items}</ul>
        </div>
        """
        display(HTML(html_content))
    else:
        print("\n" + "=" * 100)
        print(title)
        print("=" * 100)
        for key in DATASET_SECTION_NAMES:
            content = sections.get(key, '')
            if not content:
                continue
            label = _SECTION_DISPLAY_LABELS.get(key, key)
            print(f"\n{label}:")
            print(textwrap.fill(content, width=100))
        print("\nEntity Columns Documentation:")
        for col, desc in (documented_entity_columns or {}).items():
            print(f"\n  {col}:")
            print(textwrap.fill(desc, width=95, initial_indent="    ", subsequent_indent="    "))
        print("\nFeature Columns Documentation:")
        for col, desc in (documented_feature_columns or {}).items():
            print(f"\n  {col}:")
            print(textwrap.fill(desc, width=95, initial_indent="    ", subsequent_indent="    "))
        print("\n" + "=" * 100 + "\n")


def document_dataset_incremental(
    dataset_id: str,
    language: str = "English",
    display: bool = True,
    upload: bool = True,
    force_update: bool = False,
    _visited_processes: Optional[Set[str]] = None,
    _visited_views: Optional[Set[str]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Generate documentation for a dataset incrementally and bottom-up.

    Walks the full lineage graph from the dataset view through its contributing
    process views down to source tables.  At each level:

    - Internal feature store tables (FS_T_*, _HIDDEN) are silently skipped.
    - Base tables with no business dictionary entry trigger a warning.
    - Intermediate views with no documentation are auto-documented via LLM.
    - Process views (feature store type 'F') with no documentation are actively
      documented via ``document_process_incremental``.
    - The dataset itself is documented last: feature and entity column
      descriptions are **propagated** from process documentation (no LLM
      needed for 1:1 columns), and a single LLM call generates the
      dataset-level business description.

    Documentation is stored in the business dictionary tables
    (``FS_BUSINESS_DICTIONARY_OBJECTS`` with type ``'D'``,
    ``FS_BUSINESS_DICTIONARY_COLUMNS``).

    Parameters
    ----------
    dataset_id : str
        UUID of the dataset (from ``dataset_catalog()``).
    language : str
        Output language for LLM-generated descriptions.
    display : bool
        Whether to render the documentation.
    upload : bool
        Whether to persist the documentation to the business dictionary.
    force_update : bool
        If True, regenerate documentation even for already-documented nodes.
    _visited_processes : set, optional
        Shared recursion guard from an outer orchestration call — do not pass manually.
        When provided, processes already in this set are skipped without re-generating docs.
    _visited_views : set, optional
        Shared recursion guard from an outer orchestration call — do not pass manually.

    Returns
    -------
    dict or None
        A dictionary with the dataset documentation, or None on error.
    """
    logger_safe('info', f'document_dataset_incremental: starting for dataset_id={dataset_id}')

    # ── 1. Resolve dataset info ──────────────────────────────────────────────
    ds_info = _get_dataset_info(dataset_id)
    if ds_info is None:
        return None

    ds_name = ds_info['DATASET_NAME']
    ds_db = ds_info['DATASET_DATABASE']
    ddl = ds_info['DATASET_DDL']
    feature_process_map = ds_info['feature_process_map']
    entity_columns = list(ds_info['entity'].keys())

    logger_safe('info',
        f'document_dataset_incremental: {ds_db}.{ds_name} — '
        f'{len(feature_process_map)} features, {len(entity_columns)} entity columns')

    # ── 2. Build lineage graph ───────────────────────────────────────────────
    from tdfs4ds.lineage import build_teradata_dependency_graph

    fs_tables_cache = _load_fs_feature_tables_cache()

    try:
        graph = build_teradata_dependency_graph(
            ddl,
            default_database=tdfs4ds.SCHEMA,
            store_ddl=True,
            stop_at_feature_store_datasets=True,
            expand_datasets_via_process_catalog=True,
        )
    except Exception as e:
        logger_safe('error', f'document_dataset_incremental: lineage build failed: {e}')
        graph = {'nodes': {}, 'edges': [], 'roots': []}

    # ── 3. Classify and sort ─────────────────────────────────────────────────
    _classify_fs_nodes(graph)
    topo_order = _topological_sort(graph)
    root_names = set(graph.get('roots', []))

    # Identify the dataset root node
    dataset_node = None
    for root in root_names:
        r_db, r_obj = _normalize_node_name(root)
        if r_db and r_obj:
            if r_db == ds_db.upper() and r_obj == ds_name.upper():
                dataset_node = root
                break
    if dataset_node is None and root_names:
        dataset_node = next(iter(root_names))

    # ── 4. Walk bottom-up ────────────────────────────────────────────────────
    visited_processes: Set[str] = _visited_processes if _visited_processes is not None else set()
    visited_views: Set[str] = _visited_views if _visited_views is not None else set()

    for node_name in topo_order:
        if node_name == dataset_node:
            continue
        if node_name in visited_views:
            continue

        node_meta = graph['nodes'].get(node_name, {})
        obj_type = node_meta.get('object_type', 'unknown')
        db, obj = node_meta.get('database'), node_meta.get('object')
        if not db or not obj:
            db, obj = _normalize_node_name(node_name)

        # Skip internal FS tables
        if _is_internal_fs_node(db, obj, fs_tables_cache):
            visited_views.add(node_name)
            continue

        visited_views.add(node_name)

        if obj_type == 'table':
            if not _fetch_context_for_node(db, obj):
                logger_safe('warning',
                    f'document_dataset_incremental: no business dictionary entry for '
                    f'table {db}.{obj} — omitting from upstream context (best-effort).')

        elif obj_type == 'view':
            fs_type = node_meta.get('fs_type')
            if fs_type == 'F':
                # Actively document undocumented process views
                pid = node_meta.get('fs_process_id')
                if pid:
                    proc_doc = retrieve_documentation(pid)
                    if force_update or not proc_doc:
                        logger_safe('info',
                            f'document_dataset_incremental: documenting process view '
                            f'{db}.{obj} (process_id={pid})')
                        document_process_incremental(
                            process_id=pid,
                            language=language,
                            display=False,
                            upload=upload,
                            force_update=force_update,
                            _visited_processes=visited_processes,
                            _visited_views=visited_views,
                        )
                else:
                    logger_safe('warning',
                        f'document_dataset_incremental: view {db}.{obj} classified as '
                        f'feature store view but has no process_id — skipping.')
            else:
                # Intermediate view
                if force_update or not _fetch_context_for_node(db, obj):
                    _document_intermediate_view(node_name, node_meta, graph, language=language)

    # ── 5. Propagate feature/entity docs from processes ──────────────────────
    propagated = _propagate_docs_from_processes(feature_process_map, entity_columns)

    documented_feature_columns = propagated['documented_feature_columns']
    documented_entity_columns = propagated['documented_entity_columns']
    entity_description = propagated['entity_description']
    process_descriptions = propagated['process_descriptions']

    if propagated['missing_features']:
        logger_safe('warning',
            f'document_dataset_incremental: could not propagate descriptions for '
            f'features: {propagated["missing_features"]}')

    # ── 6. Generate dataset-level description (single LLM call) ──────────────
    # Returns a dict with one key per section (OVERVIEW, ENTITY, etc.)
    existing_doc = _fetch_context_for_node(ds_db.upper(), ds_name.upper())
    if force_update or not existing_doc or not existing_doc.get('object_description'):
        dataset_sections = _generate_dataset_description(
            dataset_name=ds_name,
            entity_description=entity_description,
            entity_column_docs=documented_entity_columns,
            feature_docs=documented_feature_columns,
            process_descriptions=process_descriptions,
            language=language,
        )
    else:
        # Reuse existing sections from the database
        dataset_sections = _fetch_sections_for_node(ds_db.upper(), ds_name.upper())
        if not dataset_sections:
            # Fallback: only the object-level description exists (pre-sections era)
            dataset_sections = {'OVERVIEW': existing_doc.get('object_description', '')}
        logger_safe('info',
            f'document_dataset_incremental: reusing existing dataset sections '
            f'(force_update=False).')

    # ── 7. Store ─────────────────────────────────────────────────────────────
    all_column_docs = {}
    all_column_docs.update(documented_entity_columns)
    all_column_docs.update(documented_feature_columns)

    if upload:
        try:
            _store_dataset_doc(
                db=ds_db.upper(),
                obj=ds_name.upper(),
                sections=dataset_sections,
                column_docs=all_column_docs,
            )
            logger_safe('info',
                f'document_dataset_incremental: stored documentation for '
                f'{ds_db}.{ds_name} in business dictionary.')
        except Exception as e:
            logger_safe('error',
                f'document_dataset_incremental: failed to store documentation: {e}')

    # ── 8. Display ───────────────────────────────────────────────────────────
    if display:
        _print_dataset_documentation(
            dataset_name=ds_name,
            dataset_database=ds_db,
            dataset_id=dataset_id,
            sections=dataset_sections,
            documented_entity_columns=documented_entity_columns,
            documented_feature_columns=documented_feature_columns,
        )

    # ── 9. Return ────────────────────────────────────────────────────────────
    return {
        'DATASET_ID': dataset_id,
        'DATASET_NAME': ds_name,
        'DATASET_DATABASE': ds_db,
        'DATASET_SECTIONS': dataset_sections,
        'ENTITY_DESCRIPTION': entity_description,
        'DOCUMENTED_ENTITY_COLUMNS': documented_entity_columns,
        'DOCUMENTED_FEATURE_COLUMNS': documented_feature_columns,
        'FEATURE_PROCESS_MAP': feature_process_map,
    }


def document_feature_store_incremental(
    language: str = "English",
    json_constraint: bool = True,
    display: bool = True,
    upload: bool = True,
    force_update: bool = False,
    all_data_domains: bool = False,
) -> Dict[str, Any]:
    """
    Document all registered processes and datasets in a single optimised pass.

    Objects are processed in dependency order — leaves (deepest upstream
    dependencies) first, roots last — so that upstream context is always
    available when a higher-level process or dataset is reached.  A single
    pair of visited-sets is shared across every call so each process view is
    documented at most once, regardless of how many datasets reference it.

    Strategy
    --------
    1. Fetch all registered processes (``process_catalog``) and datasets
       (``dataset_catalog``).
    2. Build a combined lineage graph seeded from every dataset DDL
       (``expand_datasets_via_process_catalog=True``) and from any orphan
       process not already covered by a dataset.
    3. Topologically sort the combined graph (leaves first, roots last).
    4. Walk the sorted order, calling ``document_process_incremental`` for
       registered process views and ``document_dataset_incremental`` for
       dataset views, sharing the same ``_visited_processes`` /
       ``_visited_views`` sets throughout.
    5. Any registered object absent from the graph (e.g. if its lineage
       build failed) is documented individually as a fallback.

    Parameters
    ----------
    language : str
        Output language for LLM-generated descriptions.
    json_constraint : bool
        Whether to enforce JSON schema in the LLM output.
    display : bool
        Whether to render each object's documentation as it is produced.
    upload : bool
        Whether to persist the documentation to the catalog tables.
    force_update : bool
        If True, regenerate documentation even for already-documented objects.
    all_data_domains : bool
        If True, include processes from all DATA_DOMAINs; otherwise only the
        current ``tdfs4ds.DATA_DOMAIN`` is included.

    Returns
    -------
    dict
        Summary with keys ``"processes_documented"``, ``"datasets_documented"``,
        ``"processes_skipped"``, ``"datasets_skipped"`` (each a list of IDs).
    """
    from tdfs4ds.lineage import build_teradata_dependency_graph

    logger_safe('info', 'document_feature_store_incremental: starting full-store documentation pass.')

    # ── 1. Gather registered objects ─────────────────────────────────────────
    try:
        proc_df = tdfs4ds.process_catalog(all_data_domains=all_data_domains).to_pandas()
    except Exception as e:
        logger_safe('error', f'document_feature_store_incremental: cannot load process catalog: {e}')
        proc_df = pd.DataFrame(columns=['PROCESS_ID', 'VIEW_NAME'])

    try:
        ds_df = tdfs4ds.dataset_catalog().to_pandas()
    except Exception as e:
        logger_safe('error', f'document_feature_store_incremental: cannot load dataset catalog: {e}')
        ds_df = pd.DataFrame(columns=['DATASET_ID', 'DATASET_NAME', 'DATASET_DATABASE'])

    all_process_ids: Set[str] = set(proc_df['PROCESS_ID'].tolist()) if not proc_df.empty else set()
    all_dataset_ids: Set[str] = set(ds_df['DATASET_ID'].tolist()) if not ds_df.empty else set()

    logger_safe('info',
        f'document_feature_store_incremental: found {len(all_process_ids)} processes, '
        f'{len(all_dataset_ids)} datasets.')

    # ── 2. Build lookup maps ──────────────────────────────────────────────────
    # (DB_UPPER, VIEW_UPPER) → process_id
    process_view_to_id: Dict[Tuple[str, str], str] = {}
    for _, row in proc_df.iterrows():
        vn = str(row['VIEW_NAME']).strip()
        parts = vn.replace('"', '').split('.')
        if len(parts) == 2:
            process_view_to_id[(parts[0].upper(), parts[1].upper())] = row['PROCESS_ID']

    # (DB_UPPER, NAME_UPPER) → dataset_id
    dataset_name_to_id: Dict[Tuple[str, str], str] = {}
    for _, row in ds_df.iterrows():
        dataset_name_to_id[
            (str(row['DATASET_DATABASE']).strip().upper(),
             str(row['DATASET_NAME']).strip().upper())
        ] = row['DATASET_ID']

    # ── 3. Build combined dependency graph ────────────────────────────────────
    combined_nodes: Dict[str, Any] = {}
    combined_edges: List[Tuple[str, str]] = []
    # Track (DB, VIEW) keys of process views already reachable via dataset graphs
    covered_view_keys: Set[Tuple[str, str]] = set()
    # Cache feature_process_map per dataset for domain filtering
    dataset_process_ids: Dict[str, Set[str]] = {}

    # 3a. Seed from each dataset (expands to contributing process views)
    for _, ds_row in ds_df.iterrows():
        ds_id = ds_row['DATASET_ID']
        ds_info = _get_dataset_info(ds_id)
        if ds_info is None:
            continue

        # Domain filter: skip datasets whose contributing processes are entirely
        # outside the current DATA_DOMAIN (only when all_data_domains=False).
        contributing_pids: Set[str] = set(ds_info.get('feature_process_map', {}).values())
        dataset_process_ids[ds_id] = contributing_pids
        if not all_data_domains and contributing_pids and contributing_pids.isdisjoint(all_process_ids):
            logger_safe('info',
                f'document_feature_store_incremental: skipping dataset '
                f'{ds_info["DATASET_NAME"]} — all contributing processes belong to a '
                f'different DATA_DOMAIN.')
            all_dataset_ids.discard(ds_id)
            continue

        try:
            g = build_teradata_dependency_graph(
                ds_info['DATASET_DDL'],
                default_database=tdfs4ds.SCHEMA,
                store_ddl=False,
                stop_at_feature_store_datasets=True,
                expand_datasets_via_process_catalog=True,
            )
        except Exception as e:
            logger_safe('warning',
                f'document_feature_store_incremental: lineage build failed for dataset '
                f'{ds_info["DATASET_NAME"]}: {e}')
            continue

        _classify_fs_nodes(g)
        combined_nodes.update(g['nodes'])
        combined_edges.extend(g['edges'])

        for node_name, meta in g['nodes'].items():
            if meta.get('fs_type') == 'F':
                db_ = meta.get('database')
                obj_ = meta.get('object')
                if not db_ or not obj_:
                    db_, obj_ = _normalize_node_name(node_name)
                if db_ and obj_:
                    covered_view_keys.add((db_.upper(), obj_.upper()))

    # 3b. Orphan processes: not reachable via any dataset graph
    for _, proc_row in proc_df.iterrows():
        vn = str(proc_row['VIEW_NAME']).strip()
        parts = vn.replace('"', '').split('.')
        key: Tuple[str, str] = (parts[0].upper(), parts[1].upper()) if len(parts) == 2 else ('', vn.upper())

        if key in covered_view_keys:
            continue

        pid = proc_row['PROCESS_ID']
        try:
            proc_info = tdfs4ds.process_store.process_store_catalog_management.get_process_info(pid)
            sql = proc_info.get('PROCESS_SQL', '')
            g = build_teradata_dependency_graph(
                sql,
                default_database=tdfs4ds.SCHEMA,
                store_ddl=False,
            )
            _classify_fs_nodes(g)
            combined_nodes.update(g['nodes'])
            combined_edges.extend(g['edges'])
        except Exception as e:
            logger_safe('warning',
                f'document_feature_store_incremental: cannot build lineage for orphan '
                f'process {pid}: {e}')

    # Deduplicate edges (preserve order)
    seen_edge_set: Set[Tuple[str, str]] = set()
    deduped_edges: List[Tuple[str, str]] = []
    for edge in combined_edges:
        if edge not in seen_edge_set:
            seen_edge_set.add(edge)
            deduped_edges.append(edge)

    combined_graph: Dict[str, Any] = {'nodes': combined_nodes, 'edges': deduped_edges, 'roots': []}

    # ── 4. Topological sort (leaves first, roots last) ────────────────────────
    topo_order = _topological_sort(combined_graph)

    logger_safe('info',
        f'document_feature_store_incremental: combined graph has '
        f'{len(combined_nodes)} nodes, {len(deduped_edges)} edges; '
        f'topo order has {len(topo_order)} entries.')

    # ── 5. Walk in topo order with shared visited sets ────────────────────────
    visited_processes: Set[str] = set()
    visited_views: Set[str] = set()

    processes_documented: List[str] = []
    processes_skipped: List[str] = []
    datasets_documented: List[str] = []
    datasets_skipped: List[str] = []

    seen_process_ids: Set[str] = set()
    seen_dataset_ids: Set[str] = set()

    for node_name in topo_order:
        node_meta = combined_nodes.get(node_name, {})
        db = node_meta.get('database')
        obj = node_meta.get('object')
        if not db or not obj:
            db, obj = _normalize_node_name(node_name)
        if not db or not obj:
            continue

        db_upper = db.upper()
        obj_upper = obj.upper()

        # Check: registered dataset?
        ds_id = dataset_name_to_id.get((db_upper, obj_upper))
        if ds_id and ds_id not in seen_dataset_ids:
            seen_dataset_ids.add(ds_id)
            logger_safe('info',
                f'document_feature_store_incremental: documenting dataset '
                f'{db}.{obj} (id={ds_id})')
            result = document_dataset_incremental(
                dataset_id=ds_id,
                language=language,
                display=display,
                upload=upload,
                force_update=force_update,
                _visited_processes=visited_processes,
                _visited_views=visited_views,
            )
            (datasets_documented if result is not None else datasets_skipped).append(ds_id)
            continue

        # Check: registered process view?
        proc_id = process_view_to_id.get((db_upper, obj_upper))
        if proc_id and proc_id not in seen_process_ids:
            seen_process_ids.add(proc_id)
            logger_safe('info',
                f'document_feature_store_incremental: documenting process '
                f'{db}.{obj} (id={proc_id})')
            result = document_process_incremental(
                process_id=proc_id,
                language=language,
                json_constraint=json_constraint,
                display=display,
                upload=upload,
                force_update=force_update,
                _visited_processes=visited_processes,
                _visited_views=visited_views,
            )
            (processes_documented if result is not None else processes_skipped).append(proc_id)

    # ── 6. Fallback: document any registered object absent from the graph ─────
    for pid in all_process_ids - seen_process_ids:
        logger_safe('warning',
            f'document_feature_store_incremental: process {pid} absent from combined '
            f'graph — documenting directly as fallback.')
        result = document_process_incremental(
            process_id=pid,
            language=language,
            json_constraint=json_constraint,
            display=display,
            upload=upload,
            force_update=force_update,
            _visited_processes=visited_processes,
            _visited_views=visited_views,
        )
        (processes_documented if result is not None else processes_skipped).append(pid)

    for ds_id in all_dataset_ids - seen_dataset_ids:
        logger_safe('warning',
            f'document_feature_store_incremental: dataset {ds_id} absent from combined '
            f'graph — documenting directly as fallback.')
        result = document_dataset_incremental(
            dataset_id=ds_id,
            language=language,
            display=display,
            upload=upload,
            force_update=force_update,
            _visited_processes=visited_processes,
            _visited_views=visited_views,
        )
        (datasets_documented if result is not None else datasets_skipped).append(ds_id)

    summary = {
        'processes_documented': processes_documented,
        'datasets_documented': datasets_documented,
        'processes_skipped': processes_skipped,
        'datasets_skipped': datasets_skipped,
    }
    logger_safe('info',
        f'document_feature_store_incremental: done — '
        f'{len(processes_documented)} processes and {len(datasets_documented)} datasets documented; '
        f'{len(processes_skipped)} processes and {len(datasets_skipped)} datasets skipped.')
    return summary
