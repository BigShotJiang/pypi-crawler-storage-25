"""Legacy setuptools entrypoint.

Modern builds use :

  python -m build

which reads packaging metadata from pyproject.toml (PEP 517/518, PEP 621).
This file exists only for older tooling that still expects setup.py.
"""

from __future__ import annotations

from setuptools import setup


def main() -> None:
    setup()


if __name__ == "__main__":
    main()
