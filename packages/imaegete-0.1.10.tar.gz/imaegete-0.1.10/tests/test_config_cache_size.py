import sys

import yaml


def test_cache_size_round_trips_in_yaml_as_mb(tmp_path, monkeypatch):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "imaegete",
            "--config_dir",
            str(tmp_path),
            "--cache_size",
            "64",
        ],
    )

    from imaegete.core.config import ImaegeteConfig

    cfg = ImaegeteConfig("ImaegeteCacheSizeRoundTrip")

    assert cfg.cache_size == 64 * 1024 * 1024
    assert cfg.to_dict()["cache_size"] == 64
    assert "image_path" not in cfg.to_dict()
    assert "categories" not in cfg.to_dict()
    assert "sort_dir" not in cfg.to_dict()

    saved = cfg.save_yaml()
    with open(saved, "r", encoding="utf-8") as fh:
        saved_data = yaml.safe_load(fh)
    assert saved_data["cache_size"] == 64
    assert "image_path" not in saved_data
    assert "categories" not in saved_data
    assert "sort_dir" not in saved_data

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "imaegete",
            "--config",
            saved,
        ],
    )
    reloaded = ImaegeteConfig("ImaegeteCacheSizeReload")

    assert reloaded.cache_size == 64 * 1024 * 1024
    assert reloaded.to_dict()["cache_size"] == 64
