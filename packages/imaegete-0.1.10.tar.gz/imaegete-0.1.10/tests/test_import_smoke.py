import importlib


def test_core_gui_and_image_processing_modules_import_with_runtime_dependencies_present():
    modules = [
        "imaegete",
        "imaegete.core.config",
        "imaegete.core.path_utils",
        "imaegete.gui.local_opener",
        "imaegete.gui.main_window",
        "imaegete.image_processing.data_management.cache_manager",
        "imaegete.image_processing.data_management.data_service",
        "imaegete.image_processing.image_controller",
        "imaegete.image_processing.image_loader",
    ]

    for module_name in modules:
        assert importlib.import_module(module_name)
