import importlib
import sys
import types


def _load_local_opener(monkeypatch, *, open_result=True, raise_on_open=False):
    class FakeUrl:
        calls = []

        @staticmethod
        def fromLocalFile(path):
            FakeUrl.calls.append(path)
            return ("local", path)

    class FakeDesktopServices:
        calls = []

        @staticmethod
        def openUrl(url):
            FakeDesktopServices.calls.append(url)
            if raise_on_open:
                raise RuntimeError("desktop integration failed")
            return open_result

    pyqt6 = types.ModuleType("PyQt6")
    qtcore = types.ModuleType("PyQt6.QtCore")
    qtgui = types.ModuleType("PyQt6.QtGui")
    qtcore.QUrl = FakeUrl
    qtgui.QDesktopServices = FakeDesktopServices

    monkeypatch.setitem(sys.modules, "PyQt6", pyqt6)
    monkeypatch.setitem(sys.modules, "PyQt6.QtCore", qtcore)
    monkeypatch.setitem(sys.modules, "PyQt6.QtGui", qtgui)
    sys.modules.pop("imaegete.gui.local_opener", None)

    module = importlib.import_module("imaegete.gui.local_opener")
    return module, FakeUrl, FakeDesktopServices


def test_open_local_path_uses_qt_desktop_services(monkeypatch, tmp_path):
    module, fake_url, fake_desktop = _load_local_opener(monkeypatch)
    folder = tmp_path / "images"
    folder.mkdir()

    assert module.open_local_path(folder) is True
    assert fake_url.calls == [str(folder)]
    assert fake_desktop.calls == [("local", str(folder))]


def test_open_local_path_returns_false_without_path(monkeypatch):
    module, fake_url, fake_desktop = _load_local_opener(monkeypatch)

    assert module.open_local_path(None) is False
    assert module.open_local_path("") is False
    assert fake_url.calls == []
    assert fake_desktop.calls == []


def test_open_local_path_returns_false_when_qt_refuses(monkeypatch, tmp_path):
    module, _fake_url, _fake_desktop = _load_local_opener(monkeypatch, open_result=False)

    assert module.open_local_path(tmp_path) is False


def test_open_local_path_returns_false_when_desktop_integration_raises(monkeypatch, tmp_path):
    module, _fake_url, _fake_desktop = _load_local_opener(monkeypatch, raise_on_open=True)

    assert module.open_local_path(tmp_path) is False
