from imaegete.image_processing.data_management.file_operations import find_matching_directory


def test_find_matching_directory_matches_nested_image(tmp_path):
    start_dir = tmp_path / "photos"
    image_dir = start_dir / "nested"
    image_dir.mkdir(parents=True)
    image_path = image_dir / "image.jpg"
    image_path.write_text("", encoding="utf-8")

    assert find_matching_directory(str(image_path), [str(start_dir)]) == str(start_dir)


def test_find_matching_directory_rejects_prefix_named_sibling(tmp_path):
    start_dir = tmp_path / "photos"
    sibling_dir = tmp_path / "photos2"
    start_dir.mkdir()
    sibling_dir.mkdir()
    image_path = sibling_dir / "image.jpg"
    image_path.write_text("", encoding="utf-8")

    assert find_matching_directory(str(image_path), [str(start_dir)]) is None


def test_find_matching_directory_preserves_configured_directory_value(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    start_dir = "photos"
    image_dir = tmp_path / start_dir / "nested"
    image_dir.mkdir(parents=True)
    image_path = image_dir / "image.jpg"
    image_path.write_text("", encoding="utf-8")

    assert find_matching_directory(str(image_path), [start_dir]) == start_dir
