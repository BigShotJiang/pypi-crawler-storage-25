from imaegete.image_processing.image_controller import ImageController
from imaegete.image_processing.image_loader import ImageLoader


class CapturingThreadManager:
    def __init__(self):
        self.exception = None

    def submit_task(self, task, *args, **kwargs):
        try:
            task()
        except Exception as exc:  # emulate GlavnaQt TaskRunnable swallowing ignored errors
            self.exception = exc
            if not getattr(exc, "ignore", False):
                raise
        return object()


class FailingCacheHandler:
    def get_cached_image(self, image_path, background=True):
        raise RuntimeError("decode failed")


class RefusingImageLoader:
    def load_image_async(self, image_path, callback):
        return None


class DummySignal:
    def emit(self, *args, **kwargs):
        pass


class DummyDataService:
    def __init__(self, images):
        self._images = images

    def get_current_image_path(self):
        return self._images[0] if self._images else None

    def get_image_list(self):
        return list(self._images)


class DummyImageListManager:
    def __init__(self, images):
        self.data_service = DummyDataService(images)


def test_async_loader_calls_callback_with_none_before_suppressing_load_exception():
    thread_manager = CapturingThreadManager()
    loader = ImageLoader(FailingCacheHandler(), thread_manager)
    callbacks = []

    loader.load_image_async("broken.jpg", callbacks.append)

    assert callbacks == [None]
    assert isinstance(thread_manager.exception, RuntimeError)
    assert getattr(thread_manager.exception, "ignore", False) is True


def test_show_image_discards_loading_marker_when_task_submission_is_refused(tmp_path):
    image_path = str(tmp_path / "image.jpg")
    controller = type("ImageControllerHarness", (), {})()
    controller.loading_images = set()
    controller.image_list_manager = DummyImageListManager([image_path])
    controller.image_loader = RefusingImageLoader()
    controller.image_loaded = DummySignal()
    controller.current_displayed_image = None
    controller.timer_running = False
    controller._shown_images = set()

    ImageController.show_image(controller, image_path)

    assert controller.loading_images == set()


class DummyClock:
    def __init__(self, elapsed_ms=0):
        self._elapsed_ms = elapsed_ms

    def elapsed(self):
        return self._elapsed_ms


def _stuck_inflight_controller(image_path):
    controller = type("ImageControllerHarness", (), {})()
    controller.timer_running = True
    controller.loading_images = {image_path}
    controller._cycle_mode = "sequential"
    controller._hold_path = None
    controller._hold_beats = 0
    controller._blocked_until = {}
    controller._load_tokens = {image_path: 3}
    controller.cycle_interval = 1000
    controller._next_beat_target_ms = 0
    controller._next_beat_index = 1
    controller._tick_seq = 0
    controller._last_tick_enter_ns = None
    controller._last_tick_seq = 0
    controller.anchor = DummyClock(100)
    controller.tap_clock = DummyClock(500)
    controller.image_list_manager = DummyImageListManager([image_path])
    controller._prefetch_slideshow_window = lambda: None
    controller._schedule_next_tick = lambda: None
    return controller


def test_cycle_images_counts_inflight_hold_without_clearing_under_budget(tmp_path):
    image_path = str(tmp_path / "slow.jpg")
    controller = _stuck_inflight_controller(image_path)
    controller.HOLD_SKIP_AFTER = 2
    controller.HOLD_LOG_EVERY = 16
    controller.FAILED_COOLDOWN_MS = 30000

    ImageController.cycle_images(controller)

    assert controller.loading_images == {image_path}
    assert controller._hold_beats == 1
    assert controller._blocked_until == {}
    assert controller._load_tokens[image_path] == 3


def test_cycle_images_clears_stuck_inflight_marker_after_hold_budget(tmp_path):
    image_path = str(tmp_path / "stuck.jpg")
    controller = _stuck_inflight_controller(image_path)
    controller.HOLD_SKIP_AFTER = 1
    controller.HOLD_LOG_EVERY = 16
    controller.FAILED_COOLDOWN_MS = 30000

    ImageController.cycle_images(controller)

    assert controller.loading_images == set()
    assert controller._hold_path is None
    assert controller._hold_beats == 0
    assert controller._blocked_until[image_path] == 30500
    assert controller._load_tokens[image_path] == 4
