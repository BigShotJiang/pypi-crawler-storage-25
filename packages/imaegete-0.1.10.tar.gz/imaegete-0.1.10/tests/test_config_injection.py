from pathlib import Path


def test_imaegete_config_does_not_publish_over_glavnaqt_config():
    source = (Path(__file__).parents[1] / "imaegete" / "core" / "config.py").read_text()

    assert "publish_to" not in source
    assert "replace_existing=True" not in source


def test_imaegete_gui_passes_config_by_injection():
    source = (Path(__file__).parents[1] / "imaegete" / "gui" / "main_window.py").read_text()

    assert "from glavnaqt.core import config as ui_config" not in source
    assert "ui_config=self.ui_config" in source


def test_imaegete_gui_uses_module_constants_not_config_instance_defaults():
    source = (Path(__file__).parents[1] / "imaegete" / "gui" / "main_window.py").read_text()

    assert "app_name=app_config.APP_NAME" not in source
    assert "app_config.WINDOW_TITLE_SUFFIX" not in source
    assert "app_name=None" in source
    assert "app_name or APP_NAME" in source
