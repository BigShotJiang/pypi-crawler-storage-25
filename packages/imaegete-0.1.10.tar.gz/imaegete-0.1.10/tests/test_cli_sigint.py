import importlib
import signal
import sys
import types


def _install_pyqt_stubs(monkeypatch):
    pyqt6 = types.ModuleType("PyQt6")
    qtcore = types.ModuleType("PyQt6.QtCore")
    qtwidgets = types.ModuleType("PyQt6.QtWidgets")

    class QTimer:
        def __init__(self, *args, **kwargs):
            self.timeout = types.SimpleNamespace(connect=lambda *a, **k: None)

        def start(self, *args, **kwargs):
            pass

        def stop(self):
            pass

    class QApplication:
        def __init__(self, *args, **kwargs):
            pass

    qtcore.QTimer = QTimer
    qtwidgets.QApplication = QApplication
    monkeypatch.setitem(sys.modules, "PyQt6", pyqt6)
    monkeypatch.setitem(sys.modules, "PyQt6.QtCore", qtcore)
    monkeypatch.setitem(sys.modules, "PyQt6.QtWidgets", qtwidgets)


def _install_runtime_stubs(monkeypatch):
    config_mod = types.ModuleType("imaegete.core.config")
    config_mod.config = types.SimpleNamespace()
    monkeypatch.setitem(sys.modules, "imaegete.core.config", config_mod)

    logger_mod = types.ModuleType("imaegete.core.logger")
    logger_mod.debug = lambda *args, **kwargs: None
    monkeypatch.setitem(sys.modules, "imaegete.core.logger", logger_mod)

    core_mod = importlib.import_module("imaegete.core")
    monkeypatch.setattr(core_mod, "config", config_mod.config, raising=False)
    monkeypatch.setattr(core_mod, "logger", logger_mod, raising=False)

    thread_manager_mod = types.ModuleType("glavnaqt.core.thread_manager")
    thread_manager_mod.ThreadManager = object
    monkeypatch.setitem(sys.modules, "glavnaqt.core.thread_manager", thread_manager_mod)

    stubs = {
        "imaegete.gui.display": {"create_image_display": lambda: object()},
        "imaegete.gui.vim_mode": {"ModeSwitcher": object},
        "imaegete.gui.main_window": {"ImaegeteGUI": object},
        "imaegete.gui.status_bar_manager": {"ImaegeteStatusBarManager": object},
        "imaegete.image_processing.data_management.cache_manager": {"CacheManager": object},
        "imaegete.image_processing.data_management.data_service": {"ImageDataService": object},
        "imaegete.image_processing.data_management.file_task_handler": {"FileTaskHandler": object},
        "imaegete.image_processing.data_management.image_cache_handler": {"ImageCacheHandler": object},
        "imaegete.image_processing.data_management.image_list_manager": {"ImageListManager": object},
        "imaegete.image_processing.image_controller": {"ImageController": object},
        "imaegete.image_processing.image_handler": {"ImageHandler": object},
        "imaegete.image_processing.image_loader": {"ImageLoader": object},
        "imaegete.key_binding.key_binder": {"bind_keys": lambda *args, **kwargs: []},
    }
    for name, attrs in stubs.items():
        module = types.ModuleType(name)
        for attr_name, value in attrs.items():
            setattr(module, attr_name, value)
        monkeypatch.setitem(sys.modules, name, module)


def _import_cli_with_stubs(monkeypatch):
    sys.modules.pop("imaegete.cli", None)
    _install_pyqt_stubs(monkeypatch)
    _install_runtime_stubs(monkeypatch)
    return importlib.import_module("imaegete.cli")


def test_sigint_handler_quits_qt_app_and_restores_default_handler(monkeypatch):
    cli = _import_cli_with_stubs(monkeypatch)
    installed = []

    def fake_signal(signum, handler):
        installed.append((signum, handler))

    monkeypatch.setattr(cli.signal, "signal", fake_signal)

    class FakeApp:
        def __init__(self):
            self.quit_calls = 0

        def quit(self):
            self.quit_calls += 1

    app = FakeApp()
    cli._install_sigint_handler(app)

    assert installed[0][0] == signal.SIGINT
    handler = installed[0][1]
    assert callable(handler)

    handler(signal.SIGINT, None)

    assert app.quit_calls == 1
    assert installed[-1] == (signal.SIGINT, signal.SIG_DFL)
