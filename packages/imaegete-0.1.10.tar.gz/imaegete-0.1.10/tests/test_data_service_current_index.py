from imaegete.image_processing.data_management.data_service import ImageDataService
from imaegete.image_processing.data_management.image_list_manager import ImageListManager
from imaegete.image_processing.image_controller import ImageController


class DummyClock:
    def elapsed(self):
        return 0


class DummyImageListManager:
    def __init__(self, data_service):
        self.data_service = data_service


class ImageListManagerHarness:
    _current_index_or_zero = ImageListManager._current_index_or_zero
    _image_list_version = ImageListManager._image_list_version
    _ensure_shuffled_indices = ImageListManager._ensure_shuffled_indices
    set_current_image_by_index = ImageListManager.set_current_image_by_index
    set_next_image = ImageListManager.set_next_image
    set_previous_image = ImageListManager.set_previous_image
    set_random_image = ImageListManager.set_random_image
    peek_shuffled_indices = ImageListManager.peek_shuffled_indices
    commit_shuffled_index = ImageListManager.commit_shuffled_index
    defer_shuffled_index = ImageListManager.defer_shuffled_index

    def __init__(self, data_service):
        self.data_service = data_service
        self._shuffled_indices = []
        self._shuffled_image_list_version = None


def test_set_current_index_clamps_high_index_without_stale_path(tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    service = ImageDataService()
    service.set_image_list([first, second])
    service.set_current_index(0)

    service.set_current_index(99)

    assert service.get_current_index() == 1
    assert service.get_current_image_path() == second


def test_set_current_index_clamps_negative_index_to_first_image(tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    service = ImageDataService()
    service.set_image_list([first, second])
    service.set_current_index(1)

    service.set_current_index(-1)

    assert service.get_current_index() == 0
    assert service.get_current_image_path() == first


def test_set_current_index_clears_path_but_keeps_integer_index_when_list_is_empty():
    service = ImageDataService()
    service.set_current_index(0)

    assert service.get_current_index() == 0
    assert service.get_current_image_path() is None


def test_remove_last_image_clears_path_but_keeps_integer_index(tmp_path):
    image = str(tmp_path / "only.jpg")
    service = ImageDataService()
    service.set_image_list([image])
    service.set_current_index(0)

    service.remove_image(image)

    assert service.get_image_list() == []
    assert service.get_current_index() == 0
    assert service.get_current_image_path() is None


def test_no_current_path_does_not_make_first_image_current(tmp_path):
    image = str(tmp_path / "first.jpg")
    service = ImageDataService()
    service.set_image_list([image])
    service.set_current_index(None)

    assert service.get_current_index() == 0
    assert service.get_current_image_path() is None
    assert service.image_is_current(image) is False


def test_delete_then_undo_style_restore_keeps_index_and_path_coherent(tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    third = str(tmp_path / "third.jpg")
    service = ImageDataService()
    service.set_image_list([first, second, third])
    service.set_current_index(1)

    service.remove_image(second)

    assert service.get_current_index() == 1
    assert service.get_current_image_path() == third

    restored = service.get_image_list()
    restored.insert(1, second)
    service.set_image_list(restored)
    service.set_current_index(service.get_index_for_image(second))

    assert service.get_current_index() == 1
    assert service.get_current_image_path() == second


def test_navigation_arithmetic_tolerates_legacy_none_current_index(tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    service = ImageDataService()
    service.set_image_list([first, second])
    service._current_index = None
    service._current_image_path = None

    manager = ImageListManagerHarness(service)

    assert ImageListManager.set_next_image(manager) == second
    assert service.get_current_index() == 1
    assert service.get_current_image_path() == second

    service._current_index = None
    service._current_image_path = None

    assert ImageListManager.set_previous_image(manager) == second
    assert service.get_current_index() == 1
    assert service.get_current_image_path() == second


def test_slideshow_sequential_picker_tolerates_legacy_none_current_index(tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    service = ImageDataService()
    service.set_image_list([first, second])
    service._current_index = None
    service._current_image_path = None

    controller = type("ImageControllerHarness", (), {})()
    controller.image_list_manager = DummyImageListManager(service)
    controller._shown_images = set()
    controller._blocked_until = {}
    controller.tap_clock = DummyClock()

    assert ImageController._next_unshown_sequential(controller) == second
    assert service.get_current_index() == 1
    assert service.get_current_image_path() == second


def test_slideshow_sequential_picker_uses_same_blocking_rules_for_peek_and_commit(tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    third = str(tmp_path / "third.jpg")
    service = ImageDataService()
    service.set_image_list([first, second, third])
    service.set_current_index(0)

    controller = type("ImageControllerHarness", (), {})()
    controller.image_list_manager = DummyImageListManager(service)
    controller._shown_images = set()
    controller.tap_clock = DummyClock()
    controller._blocked_until = {second: 1000}

    assert ImageController._peek_next_unshown_sequential(controller) == (2, third, False)
    assert ImageController._next_unshown_sequential(controller) == third
    assert service.get_current_index() == 2
    assert service.get_current_image_path() == third


def test_slideshow_sequential_picker_resets_shown_tally_only_on_commit(tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    third = str(tmp_path / "third.jpg")
    service = ImageDataService()
    service.set_image_list([first, second, third])
    service.set_current_index(0)

    controller = type("ImageControllerHarness", (), {})()
    controller.image_list_manager = DummyImageListManager(service)
    controller._shown_images = {first, second, third}
    controller.tap_clock = DummyClock()
    controller._blocked_until = {second: 1000}

    assert ImageController._peek_next_unshown_sequential(controller) == (2, third, True)
    assert controller._shown_images == {first, second, third}

    assert ImageController._next_unshown_sequential(controller) == third
    assert controller._shown_images == set()
    assert service.get_current_index() == 2
    assert service.get_current_image_path() == third


def test_set_current_image_by_index_uses_set_current_index_as_single_source_of_truth(tmp_path):
    class SpyImageDataService(ImageDataService):
        def __init__(self):
            super().__init__()
            self.set_path_calls = 0

        def set_current_image_path(self, image_path):
            self.set_path_calls += 1
            return super().set_current_image_path(image_path)

    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    service = SpyImageDataService()
    service.set_image_list([first, second])

    manager = ImageListManagerHarness(service)

    assert ImageListManager.set_current_image_by_index(manager, 1) == second
    assert service.get_current_index() == 1
    assert service.get_current_image_path() == second
    assert service.set_path_calls == 0


def test_shuffle_queue_rebuilds_after_image_list_shrinks(monkeypatch, tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    third = str(tmp_path / "third.jpg")
    service = ImageDataService()
    service.set_image_list([first, second, third])
    manager = ImageListManagerHarness(service)
    monkeypatch.setattr(
        "imaegete.image_processing.data_management.image_list_manager.random.shuffle",
        lambda seq: None,
    )

    assert manager.peek_shuffled_indices(3) == [0, 1, 2]

    service.remove_image(third)

    assert manager.peek_shuffled_indices(3) == [0, 1]
    assert all(idx < len(service.get_image_list()) for idx in manager._shuffled_indices)


def test_shuffle_queue_rebuilds_after_same_length_image_list_replacement(monkeypatch, tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    replacement_first = str(tmp_path / "replacement-first.jpg")
    replacement_second = str(tmp_path / "replacement-second.jpg")
    service = ImageDataService()
    service.set_image_list([first, second])
    manager = ImageListManagerHarness(service)
    monkeypatch.setattr(
        "imaegete.image_processing.data_management.image_list_manager.random.shuffle",
        lambda seq: None,
    )

    assert manager.peek_shuffled_indices(2) == [0, 1]
    manager._shuffled_indices = [1]
    manager._shuffled_image_list_version = service.get_image_list_version()

    service.set_image_list([replacement_first, replacement_second])

    assert manager.peek_shuffled_indices(2) == [0, 1]
    assert manager.commit_shuffled_index(0) == replacement_first
    assert service.get_current_index() == 0
    assert service.get_current_image_path() == replacement_first


def test_shuffle_queue_rebuilds_after_watcher_style_append(monkeypatch, tmp_path):
    first = str(tmp_path / "first.jpg")
    second = str(tmp_path / "second.jpg")
    third = str(tmp_path / "third.jpg")
    service = ImageDataService()
    service.set_image_list([first, second])
    manager = ImageListManagerHarness(service)
    monkeypatch.setattr(
        "imaegete.image_processing.data_management.image_list_manager.random.shuffle",
        lambda seq: None,
    )

    assert manager.peek_shuffled_indices(2) == [0, 1]
    manager._shuffled_indices = [1]
    manager._shuffled_image_list_version = service.get_image_list_version()

    service.extend_image_list([third])

    assert manager.peek_shuffled_indices(3) == [0, 1, 2]
    assert len(manager._shuffled_indices) == len(service.get_image_list())
