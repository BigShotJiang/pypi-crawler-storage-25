import logging

from imaegete.core import logger as logger_module
from imaegete.core.logger import get_dynamic_logger, logger as imported_logger


def _reset_logger_state(monkeypatch):
    configured = {}
    for logger_instance in logging.Logger.manager.loggerDict.values():
        if isinstance(logger_instance, logging.Logger) and hasattr(logger_instance, "_imaegete_configured"):
            delattr(logger_instance, "_imaegete_configured")

    def fake_configure(logger_instance, module_name):
        logger_instance.setLevel(logging.DEBUG)
        logger_instance.propagate = False
        configured[module_name] = logger_instance

    monkeypatch.setattr(logger_module, "configure_logger", fake_configure)
    logger_module._configured_loggers.clear()
    return configured


def test_module_logger_dispatch_uses_calling_module(monkeypatch):
    configured = _reset_logger_state(monkeypatch)

    logger_module.debug("dispatch smoke")

    assert __name__ in configured
    assert "imaegete.core.logger" not in configured


def test_imported_logger_proxy_dispatches_to_calling_module(monkeypatch):
    configured = _reset_logger_state(monkeypatch)

    imported_logger.info("proxy smoke")

    assert __name__ in configured
    assert "imaegete.core.logger" not in configured


def test_get_dynamic_logger_uses_direct_calling_module(monkeypatch):
    configured = _reset_logger_state(monkeypatch)

    resolved = get_dynamic_logger()

    assert resolved.name == __name__
    assert configured[__name__] is resolved


def test_logger_proxy_is_not_import_time_concrete_logger():
    assert not isinstance(imported_logger, logging.Logger)


def test_logger_dispatch_does_not_use_inspect_stack(monkeypatch):
    def fail_stack():
        raise AssertionError("inspect.stack should not be used for logger dispatch")

    import inspect

    monkeypatch.setattr(inspect, "stack", fail_stack)
    get_dynamic_logger()
    logger_module.warning("no stack walk")
    imported_logger.warning("no stack walk")
