from imaegete.image_processing.data_management.cache_manager import CacheManager


class CapturingThreadManager:
    def __init__(self):
        self.tasks = []

    def submit_task(self, task, *args, tag=None, **kwargs):
        self.tasks.append({
            "task": task,
            "args": args,
            "kwargs": kwargs,
            "tag": tag,
        })
        return object()


class CacheManagerStub:
    _retry_delay_for_attempt = staticmethod(CacheManager._retry_delay_for_attempt)
    _submit_delayed_load_retry = CacheManager._submit_delayed_load_retry

    def __init__(self):
        self.shutdown_flag = False
        self.thread_manager = CapturingThreadManager()
        self.load_calls = []

    def is_shutting_down(self):
        return self.shutdown_flag

    def load_from_disk_and_cache(self, path, attempt=0):
        self.load_calls.append((path, attempt))


def _cache_manager_stub():
    return CacheManagerStub()


def test_delayed_retry_is_queued_through_thread_manager_without_starting_timer(tmp_path):
    manager = _cache_manager_stub()
    image_path = tmp_path / "image.png"

    assert manager._submit_delayed_load_retry(
        str(image_path),
        attempt=1,
        reason="ready",
        delay=0,
    ) is True

    assert len(manager.thread_manager.tasks) == 1
    queued = manager.thread_manager.tasks[0]
    assert queued["tag"] == "retry_ready:image.png"

    queued["task"](stop_flag=lambda: False)
    assert manager.load_calls == [(str(image_path), 2)]


def test_delayed_retry_obeys_shutdown_before_running_retry(tmp_path):
    manager = _cache_manager_stub()
    image_path = tmp_path / "image.png"

    assert manager._submit_delayed_load_retry(
        str(image_path),
        attempt=0,
        reason="exc",
        delay=0,
    ) is True

    manager.shutdown_flag = True
    manager.thread_manager.tasks[0]["task"](stop_flag=lambda: False)

    assert manager.load_calls == []


def test_delayed_retry_obeys_thread_manager_stop_flag(tmp_path):
    manager = _cache_manager_stub()
    image_path = tmp_path / "image.png"

    assert manager._submit_delayed_load_retry(
        str(image_path),
        attempt=0,
        reason="exc",
        delay=0,
    ) is True

    manager.thread_manager.tasks[0]["task"](stop_flag=lambda: True)

    assert manager.load_calls == []
