import threading
import time

from imaegete.image_processing.data_management import cache_manager as cache_manager_module
from imaegete.image_processing.data_management.cache_manager import CacheManager


class CapturingThreadManager:
    def __init__(self):
        self.tasks = []
        self.stopped_tags = []

    def submit_task(self, task, *args, tag=None, **kwargs):
        self.tasks.append({"task": task, "args": args, "kwargs": kwargs, "tag": tag})
        return object()

    def stop_tasks_by_tag(self, tag):
        self.stopped_tags.append(tag)


class DummyDataService:
    def get_image_list(self):
        return []


class CacheManagerHarness:
    def __init__(self, tmp_path):
        self.shutdown_flag = False
        self.image_directories = [str(tmp_path)]
        self.dest_folders = {}
        self.delete_folders = {}
        self.debounce_interval = 0.001
        self._wf_stop_evt = None
        self._wf_thread = None
        self.thread_manager = CapturingThreadManager()
        self.data_service = DummyDataService()
        self._pending_new_paths = set()
        self._pending_new_lock = threading.Lock()
        self._new_files_task_active = False
        self._drain_pending_new_files = CacheManager._drain_pending_new_files.__get__(
            self, CacheManagerHarness
        )
        self.processed_batches = []

    def is_shutting_down(self):
        return self.shutdown_flag

    def process_new_files(self, paths):
        self.processed_batches.append(set(paths))


def test_watchfiles_loop_uses_owned_thread_not_thread_manager(tmp_path, monkeypatch):
    started = threading.Event()

    def fake_watch(*args, stop_event, **kwargs):
        started.set()
        while not stop_event.is_set():
            time.sleep(0.001)
        return
        yield set()

    monkeypatch.setattr(cache_manager_module, "watch", fake_watch)
    manager = CacheManagerHarness(tmp_path)

    CacheManager._initialize_watchfiles(manager)

    assert started.wait(1)
    assert manager.thread_manager.tasks == []
    assert manager._wf_thread is not None
    assert manager._wf_thread.name == "imaegete-watchfiles"
    assert manager._wf_thread.is_alive()

    manager.shutdown_flag = True
    manager._wf_stop_evt.set()
    manager._wf_thread.join(timeout=1)
    assert not manager._wf_thread.is_alive()


def test_new_file_batches_are_coalesced_to_one_thread_manager_task(tmp_path):
    manager = CacheManagerHarness(tmp_path)

    CacheManager._queue_new_files(manager, ["/tmp/a.jpg"])
    CacheManager._queue_new_files(manager, ["/tmp/b.jpg", "/tmp/a.jpg"])

    assert [task["tag"] for task in manager.thread_manager.tasks] == ["batch_new_files"]

    queued = manager.thread_manager.tasks[0]
    queued["task"](stop_flag=lambda: False)

    assert manager.processed_batches == [{"/tmp/a.jpg", "/tmp/b.jpg"}]
    assert manager._new_files_task_active is False
