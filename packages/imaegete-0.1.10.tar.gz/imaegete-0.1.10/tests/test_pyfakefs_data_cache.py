from pathlib import Path

from PyQt6.QtCore import QSize

from imaegete.image_processing.data_management.cache_manager import MetadataManager
from imaegete.image_processing.data_management.data_service import ImageDataService


class ImmediateThreadManager:
    def submit_task(self, task, *args, **kwargs):
        return task()


def test_data_service_tracks_fake_filesystem_paths(fs):
    fs.create_file("/gallery/a.jpg")
    fs.create_file("/gallery/b.jpg")
    service = ImageDataService()

    service.set_image_list(["/gallery/../gallery/a.jpg"])
    service.insert_sorted_image("/gallery/b.jpg")
    service.set_current_index(1)

    assert service.get_image_list() == ["/gallery/a.jpg", "/gallery/b.jpg"]
    assert service.get_current_image_path() == "/gallery/b.jpg"


def test_metadata_manager_round_trips_cache_on_fake_filesystem(fs):
    fs.create_dir("/cache")
    fs.create_file("/gallery/image.png")
    manager = MetadataManager(
        "/cache",
        ImmediateThreadManager(),
        stability_interval=0.001,
        stability_retries=1,
    )
    metadata = {
        "type": "image",
        "file_size": 42,
        "last_modified": 123.0,
        "size": QSize(80, 60),
    }

    manager.save_metadata("/gallery/image.png", metadata)

    cache_path = manager.get_cache_path("/gallery/image.png")
    assert Path(cache_path).exists()
    loaded = manager.load_metadata("/gallery/image.png")
    assert loaded["type"] == "image"
    assert loaded["file_size"] == 42
    assert loaded["last_modified"] == 123.0
    assert loaded["size"] == QSize(80, 60)
