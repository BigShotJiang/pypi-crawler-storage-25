import importlib
import sys


def test_profiler_import_does_not_import_application_entrypoint():
    sys.modules.pop("main", None)
    sys.modules.pop("performance_utils.profiler", None)

    profiler = importlib.import_module("performance_utils.profiler")

    assert "main" not in sys.modules
    assert profiler.run_profiled_app is not None
