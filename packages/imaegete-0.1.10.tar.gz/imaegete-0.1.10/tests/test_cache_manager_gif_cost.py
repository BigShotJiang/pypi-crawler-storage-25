from collections import OrderedDict

from PyQt6.QtCore import QMutex, QSize

from imaegete.image_processing.data_management.cache_manager import CacheManager


class MetadataRecorder:
    def __init__(self):
        self.saved = []

    def save_metadata(self, path, metadata):
        self.saved.append((path, dict(metadata)))


class CacheHarness:
    _cache_entry_bytes = CacheManager._cache_entry_bytes
    _store_gif_stub = CacheManager._store_gif_stub
    _estimated_gif_cache_bytes = CacheManager._estimated_gif_cache_bytes
    _bytes_for_decoded_frames = CacheManager._bytes_for_decoded_frames
    _normalised_frame_count = staticmethod(CacheManager._normalised_frame_count)

    def __init__(self, cache_limit_bytes=10_000_000):
        self.cache_limit_bytes = cache_limit_bytes
        self.cache_used_bytes = 0
        self.image_cache = OrderedDict()
        self.metadata_cache = OrderedDict()
        self.currently_active_requests = {}
        self.cache_lock = QMutex()
        self.metadata_manager = MetadataRecorder()
        self.mem_events = []

    def _publish_mem_event(self):
        self.mem_events.append((self.cache_used_bytes, self.cache_limit_bytes))


def test_gif_stub_cost_uses_decoded_frames_not_file_size(tmp_path):
    gif_path = tmp_path / "tiny.gif"
    gif_path.write_bytes(b"GIF89a")
    manager = CacheHarness()

    CacheManager._store_gif_stub(manager, str(gif_path), QSize(100, 50), frame_count=3)

    expected_cost = 100 * 50 * 4 * 3
    assert gif_path.stat().st_size < expected_cost
    assert manager.cache_used_bytes == expected_cost
    assert manager._cache_entry_bytes(str(gif_path), None) == expected_cost
    assert manager.metadata_cache[str(gif_path)]["file_size"] == gif_path.stat().st_size
    assert manager.metadata_cache[str(gif_path)]["cache_cost"] == expected_cost
    assert manager.metadata_cache[str(gif_path)]["frame_count"] == 3


def test_oversized_gif_stub_eviction_subtracts_decoded_frame_cost(tmp_path):
    gif_path = tmp_path / "oversized.gif"
    gif_path.write_bytes(b"GIF89a")
    manager = CacheHarness(cache_limit_bytes=1024)

    CacheManager._store_gif_stub(manager, str(gif_path), QSize(100, 50), frame_count=3)

    assert str(gif_path) not in manager.image_cache
    assert str(gif_path) not in manager.metadata_cache
    assert manager.cache_used_bytes == 0
    assert manager.metadata_manager.saved[-1][1]["cache_cost"] == 100 * 50 * 4 * 3
