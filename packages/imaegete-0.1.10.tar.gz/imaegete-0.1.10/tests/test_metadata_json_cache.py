import json
import os
import pickle
import shlex
from pathlib import Path

from PyQt6.QtCore import QSize

from imaegete.image_processing.data_management.cache_manager import MetadataManager


class ImmediateThreadManager:
    def submit_task(self, task, *args, **kwargs):
        return task()


def test_metadata_cache_is_json_and_restores_qsize(tmp_path):
    manager = MetadataManager(
        str(tmp_path),
        ImmediateThreadManager(),
        stability_interval=0.01,
        stability_retries=1,
    )
    image_path = tmp_path / "image.png"
    metadata = {
        "type": "image",
        "file_size": 123,
        "last_modified": 456.5,
        "size": QSize(640, 480),
    }

    manager.save_metadata(str(image_path), metadata)

    cache_path = Path(manager.get_cache_path(str(image_path)))
    stored = json.loads(cache_path.read_text(encoding="utf-8"))
    assert stored == {
        "type": "image",
        "file_size": 123,
        "last_modified": 456.5,
        "size": {"width": 640, "height": 480},
    }

    loaded = manager.load_metadata(str(image_path))
    assert loaded["type"] == "image"
    assert loaded["file_size"] == 123
    assert loaded["last_modified"] == 456.5
    assert loaded["size"] == QSize(640, 480)


def test_metadata_loader_ignores_legacy_pickle_without_executing(tmp_path):
    manager = MetadataManager(
        str(tmp_path),
        ImmediateThreadManager(),
        stability_interval=0.01,
        stability_retries=1,
    )
    image_path = tmp_path / "image.png"
    marker = tmp_path / "pickle-executed"

    class PicklePayload:
        def __reduce__(self):
            return (os.system, (f"touch {shlex.quote(str(marker))}",))

    cache_path = Path(manager.get_cache_path(str(image_path)))
    cache_path.write_bytes(pickle.dumps(PicklePayload()))

    assert manager.load_metadata(str(image_path)) is None
    assert not marker.exists()
