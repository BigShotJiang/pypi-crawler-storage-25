import importlib
import signal
import sys
import types


class _FakeSignal:
    def __init__(self):
        self._callback = None

    def connect(self, callback):
        self._callback = callback


class _FakeQTimer:
    def __init__(self, *args, **kwargs):
        self.timeout = _FakeSignal()
        self.started_with = None
        self.stopped = False

    def start(self, value):
        self.started_with = value

    def stop(self):
        self.stopped = True


class _FakeAboutToQuit:
    def __init__(self):
        self.callback = None

    def connect(self, callback):
        self.callback = callback


class _FakeQApplication:
    instances = []

    def __init__(self, *args, **kwargs):
        self.aboutToQuit = _FakeAboutToQuit()
        self.quit_calls = 0
        type(self).instances.append(self)

    def quit(self):
        self.quit_calls += 1

    def exec(self):
        return 0


def _install_pyqt_stubs(monkeypatch):
    pyqt6 = types.ModuleType("PyQt6")
    qtcore = types.ModuleType("PyQt6.QtCore")
    qtwidgets = types.ModuleType("PyQt6.QtWidgets")
    qtcore.QTimer = _FakeQTimer
    qtwidgets.QApplication = _FakeQApplication
    monkeypatch.setitem(sys.modules, "PyQt6", pyqt6)
    monkeypatch.setitem(sys.modules, "PyQt6.QtCore", qtcore)
    monkeypatch.setitem(sys.modules, "PyQt6.QtWidgets", qtwidgets)


def _install_runtime_stubs(monkeypatch, cache_manager_calls):
    config = types.SimpleNamespace(
        cache_dir="/tmp/imaegete-cache",
        cache_size=123456,
        start_dirs=["/tmp/images"],
        selection_only=False,
        selection_files=None,
        clear_cache=False,
        image_path=None,
    )

    config_mod = types.ModuleType("imaegete.core.config")
    config_mod.config = config
    monkeypatch.setitem(sys.modules, "imaegete.core.config", config_mod)

    logger_mod = types.ModuleType("imaegete.core.logger")
    logger_mod.debug = lambda *args, **kwargs: None
    monkeypatch.setitem(sys.modules, "imaegete.core.logger", logger_mod)

    core_mod = importlib.import_module("imaegete.core")
    monkeypatch.setattr(core_mod, "config", config, raising=False)
    monkeypatch.setattr(core_mod, "logger", logger_mod, raising=False)

    class ThreadManager:
        def stop_tasks_by_tag(self, *args, **kwargs):
            pass

        def wait_for_tagged_tasks(self, *args, **kwargs):
            pass

        def shutdown(self):
            pass

    thread_manager_mod = types.ModuleType("glavnaqt.core.thread_manager")
    thread_manager_mod.ThreadManager = ThreadManager
    monkeypatch.setitem(sys.modules, "glavnaqt.core.thread_manager", thread_manager_mod)

    class CacheManager:
        def __init__(self, *args, **kwargs):
            cache_manager_calls.append((args, kwargs))

        def clear_disk_cache(self):
            pass

        def shutdown(self):
            pass

    class ImageDataService:
        def set_cache_manager(self, cache_manager):
            self.cache_manager = cache_manager

        def set_current_image_path(self, image_path):
            self.current_image_path = image_path

    class _AnyInit:
        def __init__(self, *args, **kwargs):
            pass

    class _ShutdownOnly(_AnyInit):
        def shutdown(self):
            pass

    class _AttachKeysOnly(_AnyInit):
        def __init__(self, *args, **kwargs):
            pass

        def attach_keys(self, keys):
            self.keys = keys

    stubs = {
        "imaegete.gui.display": {"create_image_display": lambda: object()},
        "imaegete.gui.vim_mode": {"ModeSwitcher": _AttachKeysOnly},
        "imaegete.gui.main_window": {"ImaegeteGUI": _AnyInit},
        "imaegete.gui.status_bar_manager": {"ImaegeteStatusBarManager": _ShutdownOnly},
        "imaegete.image_processing.data_management.cache_manager": {"CacheManager": CacheManager},
        "imaegete.image_processing.data_management.data_service": {"ImageDataService": ImageDataService},
        "imaegete.image_processing.data_management.file_task_handler": {"FileTaskHandler": _AnyInit},
        "imaegete.image_processing.data_management.image_cache_handler": {"ImageCacheHandler": _AnyInit},
        "imaegete.image_processing.data_management.image_list_manager": {"ImageListManager": _AnyInit},
        "imaegete.image_processing.image_controller": {"ImageController": _ShutdownOnly},
        "imaegete.image_processing.image_handler": {"ImageHandler": _AnyInit},
        "imaegete.image_processing.image_loader": {"ImageLoader": _AnyInit},
        "imaegete.key_binding.key_binder": {"bind_keys": lambda *args, **kwargs: []},
    }
    for name, attrs in stubs.items():
        module = types.ModuleType(name)
        for attr_name, value in attrs.items():
            setattr(module, attr_name, value)
        monkeypatch.setitem(sys.modules, name, module)


def _import_cli_with_stubs(monkeypatch, cache_manager_calls):
    sys.modules.pop("imaegete.cli", None)
    _FakeQApplication.instances.clear()
    _install_pyqt_stubs(monkeypatch)
    _install_runtime_stubs(monkeypatch, cache_manager_calls)
    return importlib.import_module("imaegete.cli")


def test_cli_uses_cache_manager_default_debounce(monkeypatch):
    cache_manager_calls = []
    cli = _import_cli_with_stubs(monkeypatch, cache_manager_calls)
    monkeypatch.setattr(cli.signal, "signal", lambda signum, handler: None)

    try:
        cli.main()
    except SystemExit as exc:
        assert exc.code == 0

    assert len(cache_manager_calls) == 1
    args, kwargs = cache_manager_calls[0]
    assert args[:3]
    assert kwargs["image_directories"] == ["/tmp/images"]
    assert kwargs["cache_limit_bytes"] == 123456
    assert "debounce_interval" not in kwargs
