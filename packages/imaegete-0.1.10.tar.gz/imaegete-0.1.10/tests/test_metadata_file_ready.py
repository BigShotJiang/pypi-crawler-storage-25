from PIL import Image as PILImage, UnidentifiedImageError

from imaegete.image_processing.data_management.cache_manager import MetadataManager


class DummyThreadManager:
    def submit_task(self, task, *args, **kwargs):
        return task()


def _manager(tmp_path):
    return MetadataManager(
        str(tmp_path),
        DummyThreadManager(),
        stability_interval=0.001,
        stability_retries=2,
    )


def _stable_probe_file(tmp_path):
    image_path = tmp_path / "candidate.jpg"
    image_path.write_bytes(b"not an image")
    return image_path


def test_file_is_ready_returns_false_for_truncated_pillow_errors(tmp_path, monkeypatch):
    manager = _manager(tmp_path)
    image_path = _stable_probe_file(tmp_path)

    def raise_truncated(path):
        raise OSError("image file is truncated")

    monkeypatch.setattr(PILImage, "open", raise_truncated)

    assert manager.file_is_ready(str(image_path)) is False


def test_file_is_ready_returns_false_for_malformed_pillow_errors(tmp_path, monkeypatch):
    manager = _manager(tmp_path)
    image_path = _stable_probe_file(tmp_path)

    def raise_malformed(path):
        raise ValueError("malformed image")

    monkeypatch.setattr(PILImage, "open", raise_malformed)

    assert manager.file_is_ready(str(image_path)) is False


def test_file_is_ready_returns_false_for_decompression_bomb_errors(tmp_path, monkeypatch):
    manager = _manager(tmp_path)
    image_path = _stable_probe_file(tmp_path)

    def raise_decompression_bomb(path):
        raise PILImage.DecompressionBombError("image too large")

    monkeypatch.setattr(PILImage, "open", raise_decompression_bomb)

    assert manager.file_is_ready(str(image_path)) is False


def test_file_is_ready_still_returns_false_for_unidentified_images(tmp_path, monkeypatch):
    manager = _manager(tmp_path)
    image_path = _stable_probe_file(tmp_path)

    def raise_unidentified(path):
        raise UnidentifiedImageError("cannot identify image file")

    monkeypatch.setattr(PILImage, "open", raise_unidentified)

    assert manager.file_is_ready(str(image_path)) is False
