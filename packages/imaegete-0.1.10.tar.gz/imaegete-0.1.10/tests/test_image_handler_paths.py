from imaegete.image_processing.image_handler import ImageHandler


class RecordingDataService:
    def __init__(self):
        self.sorted_images = []
        self.current_index = None

    def append_sorted_images(self, item):
        self.sorted_images.append(item)

    def get_index_for_image(self, image_path):
        return 0

    def set_current_index(self, index):
        self.current_index = index


class RecordingFileTaskHandler:
    def __init__(self):
        self.calls = []

    def delete_image(self, image_path, source_dir, dest_dir):
        self.calls.append(("delete", image_path, source_dir, dest_dir))

    def move_image(self, image_path, source_dir, dest_dir):
        self.calls.append(("move", image_path, source_dir, dest_dir))


class RecordingImageListManager:
    def __init__(self, image_path=None, original_index=0):
        self.image_path = image_path
        self.original_index = original_index
        self.restored = []

    def pop_image(self):
        return self.original_index, self.image_path

    def add_image_to_list(self, image_path, index=None):
        self.restored.append((image_path, index))


def _handler(start_dirs, delete_folders=None, dest_folders=None, image_list_manager=None):
    handler = ImageHandler(
        RecordingDataService(),
        None,
        image_list_manager or RecordingImageListManager(),
        RecordingFileTaskHandler(),
    )
    handler.start_dirs = start_dirs
    handler.delete_folders = delete_folders or {}
    handler.dest_folders = dest_folders or {}
    return handler


def test_move_or_delete_image_rejects_prefix_named_sibling_without_recording_action(tmp_path):
    start_dir = tmp_path / "photos"
    sibling_dir = tmp_path / "photos2"
    start_dir.mkdir()
    sibling_dir.mkdir()
    image_path = sibling_dir / "image.jpg"
    image_path.write_text("", encoding="utf-8")

    handler = _handler(
        [str(start_dir)],
        delete_folders={str(start_dir): str(tmp_path / "deleted")},
    )

    assert handler.move_or_delete_image(
        str(image_path),
        "delete",
        original_index=0,
    ) is False
    assert handler.file_task_handler.calls == []
    assert handler.data_service.sorted_images == []


def test_move_or_delete_image_uses_exact_sibling_start_dir(tmp_path):
    start_dir = tmp_path / "photos"
    sibling_dir = tmp_path / "photos2"
    start_dir.mkdir()
    sibling_dir.mkdir()
    image_path = sibling_dir / "image.jpg"
    image_path.write_text("", encoding="utf-8")
    sibling_delete_dir = tmp_path / "deleted-photos2"

    handler = _handler(
        [str(start_dir), str(sibling_dir)],
        delete_folders={
            str(start_dir): str(tmp_path / "deleted-photos"),
            str(sibling_dir): str(sibling_delete_dir),
        },
    )

    assert handler.move_or_delete_image(
        str(image_path),
        "delete",
        original_index=3,
    ) is True
    assert handler.file_task_handler.calls == [
        ("delete", str(image_path), str(sibling_dir), str(sibling_delete_dir))
    ]
    assert handler.data_service.sorted_images == [("delete", str(image_path), None, 3)]


def test_delete_current_image_restores_list_when_no_file_task_is_queued(tmp_path):
    image_path = str(tmp_path / "outside.jpg")
    manager = RecordingImageListManager(image_path, 5)
    handler = _handler([], image_list_manager=manager)

    handler.delete_current_image()

    assert handler.file_task_handler.calls == []
    assert handler.data_service.sorted_images == []
    assert manager.restored == [(image_path, 5)]
    assert handler.data_service.current_index == 0
