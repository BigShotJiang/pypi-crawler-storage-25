"""
Wheel / drag input decoupled from the widget tree.

Pure logic = trivial to unit-test.
"""

from __future__ import annotations

import math
from typing import Callable, Optional

from PyQt6.QtCore import QPointF, Qt
from PyQt6.QtGui import QMouseEvent, QWheelEvent
from glavnaqt.events.bus import create_or_get_shared_event_bus

from ._state import ViewState


class GestureHandler:
    def __init__(
        self,
        state: ViewState,
        repaint_cb: Optional[Callable[[], None]] = None) -> None:
        self._state = state
        self._repaint = repaint_cb or (lambda: None)
        self._zoom_step = 1.1
        self._last_drag: Optional[QPointF] = None
        self._main_event_bus = create_or_get_shared_event_bus()

    # public-facing API called by BaseCanvas ----------------------------------

    def wheel_event(self, ev: QWheelEvent, fit_factor: float) -> None:
        steps = (ev.angleDelta().y() / 8) / 15
        if steps == 0:
            ev.accept()
            return
        prior_pct = round(self._state.zoom * 100)


        if steps > 0:
            new_z = min(self._state.zoom * (self._zoom_step ** steps), 50.0)
        else:
            new_z = max(self._state.zoom / (self._zoom_step ** -steps), fit_factor)

        new_z = max(new_z, fit_factor)         # never smaller than fit
        self._state.is_zoomed = not math.isclose(new_z, fit_factor, rel_tol=1e-3)
        self._state.zoom = new_z
        self._repaint()
        ev.accept()

        new_pct = round(self._state.zoom * 100)
        if new_pct != prior_pct:
        # Only tell listeners that the zoom‐percent changed:
            self._main_event_bus.emit("zoom_changed", zoom_percentage=new_pct)


    def mouse_press(self, ev: QMouseEvent, fit_factor: float) -> None:
        if ev.button() == Qt.MouseButton.LeftButton and self._state.zoom > fit_factor:
            self._last_drag = ev.position()
            ev.accept()

    def mouse_move(self, ev: QMouseEvent) -> None:
        if self._last_drag is None:
            return
        delta = ev.position() - self._last_drag
        self._state.pan += QPointF(delta.x(), delta.y()) / self._state.zoom
        self._last_drag = ev.position()
        self._repaint()
        ev.accept()

    def mouse_release(self, ev: QMouseEvent) -> None:
        if ev.button() == Qt.MouseButton.LeftButton and self._last_drag is not None:
            self._last_drag = None
            ev.accept()
