"""
Draws *static* images with high-quality zoom-out using mip-maps + tiles.
"""

from __future__ import annotations

import math
from typing import Optional

from PyQt6.QtCore import QRect, Qt
from PyQt6.QtGui import QPainter, QPixmap, QImage, QPalette
from PyQt6.QtWidgets import QApplication, QLabel

from ._state import ViewState
from .tiles import TileCache


class StillRenderer:
    def __init__(self, tiles: TileCache, state: ViewState) -> None:
        self._tiles = tiles
        self._state = state

        self._full_image: Optional[QImage] = None
        self._mips: list[QImage] = []
        self._max_smooth_factor = 10.0

    # public API --------------------------------------------------------------

    def set_pixmap(self, pix: QPixmap) -> None:

        """Load a new still image.

        Passing an empty / null / 0x0 pixmap is treated as a *clear* operation so the
        canvas blanks when the last image is deleted.
        """
        # Treat empty pixmaps as a clear operation.
        if pix is None:
            is_empty = True
        else:
            try:
                is_empty = pix.isNull() or pix.size().isEmpty()
            except Exception:
                is_empty = not pix

        if is_empty:
            self._tiles.clear()
            self._full_image = None
            self._mips = []
            self._state.is_zoomed = False
            self._last_pix_cache_key = None
            return

        # Skip reload if it's the same pixmap as last time.
        try:
            new_key = pix.cacheKey()
        except Exception:
            new_key = None

        if self._full_image is not None and new_key is not None and getattr(self, "_last_pix_cache_key", None) == new_key:
            return

        self._last_pix_cache_key = new_key

        self._tiles.clear()
        img = pix.toImage()

        # If conversion yielded a null/empty image, treat as clear.
        if img is None or img.isNull() or img.size().isEmpty():
            self._full_image = None
            self._mips = []
            self._state.is_zoomed = False
            return

        self._full_image = img
        self._build_mips()

        # On first load we fit to window; later loads keep current rel. zoom.
        self._state.is_zoomed = False  # caller may override after first paint

    
    def paint(self, painter: QPainter, widget: QLabel) -> None:
        """
        High-quality tile paint.  Assumes `painter` is already active
        and clipped to `widget.rect()`.
        """
        if (self._full_image is None) or self._full_image.isNull() or self._full_image.size().isEmpty():
            painter.fillRect(
                widget.rect(),
                QApplication.palette().color(QPalette.ColorRole.Window),
            )
            return

        # ── choose mip level ───────────────────────────────────────────
        if self._state.zoom >= 1.0 or not self._mips:
            level, src_img = 0, self._full_image
        else:
            level = min(len(self._mips) - 1, int(math.log2(1 / self._state.zoom)))
            src_img = self._mips[level]

        scale = 1 / (1 << level)                      # mip scale factor
        full_w, full_h = src_img.width(), src_img.height()

        total_zoom = self._state.zoom
        eff_zoom   = total_zoom / scale
        downscale  = eff_zoom < 1.0

        # ── render-hint & borders ──────────────────────────────────────
        painter.setRenderHint(
            QPainter.RenderHint.SmoothPixmapTransform,
            downscale or eff_zoom <= self._max_smooth_factor,
        )
        border = self._tiles.kernel_radius if downscale else 0

        # ── visible source rect (image coords) ─────────────────────────
        vw, vh   = widget.contentsRect().width(), widget.contentsRect().height()
        src_w    = min(full_w, math.ceil(vw / eff_zoom))
        src_h    = min(full_h, math.ceil(vh / eff_zoom))
        cx       = full_w / 2 - self._state.pan.x() * scale
        cy       = full_h / 2 - self._state.pan.y() * scale
        left     = max(0, min(full_w - src_w, int(round(cx - src_w / 2))))
        top      = max(0, min(full_h - src_h, int(round(cy - src_h / 2))))
        src_rect = QRect(left, top, src_w, src_h)

        # ── centring margins in widget space ───────────────────────────
        disp_w, disp_h = src_w * eff_zoom, src_h * eff_zoom
        x_margin = max(0, int((vw - disp_w) / 2))
        y_margin = max(0, int((vh - disp_h) / 2))

        # ── iterate tiles ──────────────────────────────────────────────
        ty0, ty1 = src_rect.top()    // self._tiles.tile_size, src_rect.bottom() // self._tiles.tile_size
        tx0, tx1 = src_rect.left()   // self._tiles.tile_size, src_rect.right()  // self._tiles.tile_size

        for ty in range(ty0, ty1 + 1):
            for tx in range(tx0, tx1 + 1):
                region = QRect(
                    tx * self._tiles.tile_size,
                    ty * self._tiles.tile_size,
                    self._tiles.tile_size,
                    self._tiles.tile_size,
                ).intersected(src_rect)
                if region.isEmpty():
                    continue

                tile_pm, pad_rect = self._tiles.get(src_img, level, tx, ty, border)

                sx0 = region.left()  - src_rect.left()
                sy0 = region.top()   - src_rect.top()
                sx1 = region.right() + 1 - src_rect.left()
                sy1 = region.bottom() + 1 - src_rect.top()

                dest = TileCache.map_source_to_dest(
                    sx0, sy0, sx1, sy1,
                    eff_zoom, x_margin, y_margin,
                )
                src_in_tile = QRect(
                    region.x() - pad_rect.x(),
                    region.y() - pad_rect.y(),
                    region.width(),
                    region.height(),
                )
                painter.drawPixmap(dest, tile_pm, src_in_tile)


    def _build_mips(self) -> None:
        assert self._full_image is not None
        self._mips = [self._full_image]
        while min(self._mips[-1].width(), self._mips[-1].height()) > self._tiles.tile_size:
            self._mips.append(
                self._mips[-1].scaled(
                    self._mips[-1].width() // 2,
                    self._mips[-1].height() // 2,
                    Qt.AspectRatioMode.KeepAspectRatio,                # ← positional
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
