"""
Public façade: callers import only the factory below.
"""

from __future__ import annotations

from PyQt6.QtWidgets import QLabel

from ._state import ViewState
from .movie_renderer import MovieRenderer
from .gestures import GestureHandler
from .facade import ImageDisplay


def create_image_display() -> QLabel:
    state = ViewState()
    movie_renderer = MovieRenderer(state)          # inval-cb wired below
    gestures = GestureHandler(state)               # repaint-cb wired below

    widget = ImageDisplay(state=state, renderer=movie_renderer, gestures=gestures)

    gestures._repaint = widget.update
    movie_renderer._invalidate_cb = widget.update
    return widget

