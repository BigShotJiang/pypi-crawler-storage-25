from __future__ import annotations

from PyQt6.QtCore import Qt, QElapsedTimer, pyqtSignal
from PyQt6.QtGui import QPainter, QMouseEvent, QWheelEvent, QPalette
from PyQt6.QtWidgets import QLabel, QSizePolicy

from ._state import ViewState
from .gestures import GestureHandler
from .movie_renderer import MovieRenderer
from imaegete.core import timing_probe


class BaseCanvas(QLabel):
    frame_rendered = pyqtSignal()

    def __init__(self, *, renderer: MovieRenderer, gestures: GestureHandler, state: ViewState):
        super().__init__()
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._renderer = renderer
        self._gestures = gestures
        self._state = state

        self._emit_guard = QElapsedTimer()
        self._emit_guard.start()
        self._last_frame_id: tuple[str, int | None] | None = None

    # ------------------------------------------------------------------ #
    # Qt events
    # ------------------------------------------------------------------ #

    def paintEvent(self, ev):  # noqa: N802
        painter = QPainter(self)
        # Always clear the background first; otherwise a "clear" that paints nothing can leave stale pixels.
        painter.fillRect(self.rect(), self.palette().color(QPalette.ColorRole.Window))
        self._renderer.paint(painter, self)
        painter.end()

        # Timing probe: record a paint timestamp (used to correlate tick→paint).
        if timing_probe.ENABLED:
            try:
                timing_probe.mark_paint(getattr(self, "current_path", None))
            except Exception:
                pass

        fid = self._renderer.frame_id()

        # Legacy “no pixmap” case → emit exactly once as ("pixmap-empty", None)
        if fid is None:
            if self._last_frame_id != ("pixmap-empty", None):
                self._last_frame_id = ("pixmap-empty", None)
                self._emit_guard.restart()        # suppress duplicates <10ms
                self.frame_rendered.emit()
            return

        # Normal frames (animated or still)…
        if fid != self._last_frame_id and self._emit_guard.elapsed() >= 10:
            self._last_frame_id = fid
            self._emit_guard.restart()
            self.frame_rendered.emit()

    # input forwarding --------------------------------------------------

    def wheelEvent(self, ev: QWheelEvent):  # noqa: N802
        self._gestures.wheel_event(ev, self._fit_factor())

    def mousePressEvent(self, ev: QMouseEvent):  # noqa: N802
        self._gestures.mouse_press(ev, self._fit_factor())
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev: QMouseEvent):  # noqa: N802
        self._gestures.mouse_move(ev)
        super().mouseMoveEvent(ev)

    def mouseReleaseEvent(self, ev: QMouseEvent):  # noqa: N802
        self._gestures.mouse_release(ev)
        super().mouseReleaseEvent(ev)

    # helper -------------------------------------------------------------

    def _fit_factor(self) -> float:
        size = self._renderer.natural_size()
        if not size:
            return 1.0
        cr = self.contentsRect()
        return min(cr.width() / size.width(), cr.height() / size.height())
