from __future__ import annotations

from dataclasses import dataclass, field
from PyQt6.QtCore import QPointF, QSize


@dataclass
class ViewState:
    """Mutable, serialisable view parameters shared by all helpers."""
    zoom: float = 1.0
    pan: QPointF = field(default_factory=lambda: QPointF(0, 0))  # in *image* units, not widget px
    is_zoomed: bool = False               # user intentionally off “fit”


@dataclass
class MovieMeta:
    """Small helper used only by MovieRenderer."""
    frame_size: QSize = field(default_factory=QSize)
    current_frame: int = 0
