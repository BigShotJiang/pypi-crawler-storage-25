"""
Animated-GIF renderer (also accepts still images via delegation).
"""

from __future__ import annotations

from typing import Optional, Callable

from PyQt6.QtCore import QSize, Qt, QThread, QMetaObject
from PyQt6.QtGui import QPainter, QMovie, QPixmap
from PyQt6.QtWidgets import QLabel

from ._state import ViewState, MovieMeta
from .tiles import TileCache
from .still_renderer import StillRenderer


class MovieRenderer:
    def __init__(self, state: ViewState, invalidate_cb: Callable[[], None] = lambda: None) -> None:
        self._state = state
        self._tiles = TileCache()
        self._still = StillRenderer(self._tiles, state)

        self._movie: Optional[QMovie] = None
        self._movie_meta = MovieMeta()
        self._invalidate_cb = invalidate_cb

    # ------------------------------------------------------------------ #
    # public loaders
    # ------------------------------------------------------------------ #
    def movie(self) -> Optional[QMovie]:
        """Return the currently-loaded QMovie (or None if we’re on a still)."""
        return self._movie

    def set_pixmap(self, pix: QPixmap) -> None:
        self._movie = None
        self._movie_meta = MovieMeta()
        self._still.set_pixmap(pix)

    def set_movie(self, movie: QMovie) -> None:
        # ensure we run in the GUI thread
        if QThread.currentThread() is not movie.thread():
            QMetaObject.invokeMethod(
                self,
                "set_movie",
                Qt.ConnectionType.QueuedConnection,
                movie,
            )
            return

        if self._movie is movie:
            return

        self._movie = movie
        self._movie.setCacheMode(QMovie.CacheMode.CacheAll)
        self._movie.frameChanged.connect(lambda _n: self._invalidate_cb())
        self._movie.start()
        self._gather_movie_meta()

    # ------------------------------------------------------------------ #
    # helpers used by BaseCanvas
    # ------------------------------------------------------------------ #

    def natural_size(self) -> QSize | None:
        if self._movie and self._movie_meta.frame_size.isValid():
            return self._movie_meta.frame_size
        if self._still._full_image is not None:
            return self._still._full_image.size()
        return None

    def frame_id(self) -> tuple[str, int | None]:
        if self._movie and self._movie.isValid():
            return ("movie", self._movie.currentFrameNumber())
        if self._still._full_image is not None:
            return ("pixmap", self._still._full_image.cacheKey())
        return ("empty", None)

    def paint(self, painter: QPainter, widget: QLabel) -> None:
        """Render current GIF frame or delegate to StillRenderer."""
        if not self._movie or not self._movie.isValid():
            self._still.paint(painter, widget)
            return

        frame = self._movie.currentPixmap()
        if frame.isNull():
            return

        fw, fh = frame.width(), frame.height()          
        cr = widget.contentsRect()
        total_zoom = self._state.zoom

        scaled = frame.scaled(
            max(1, int(fw * total_zoom)),
            max(1, int(fh * total_zoom)),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )

        x_off = cr.x() + (cr.width() - scaled.width()) // 2 + int(self._state.pan.x() * total_zoom)
        y_off = cr.y() + (cr.height() - scaled.height()) // 2 + int(self._state.pan.y() * total_zoom)
        painter.drawPixmap(x_off, y_off, scaled)

    def _gather_movie_meta(self) -> None:
        if not self._movie or not self._movie.isValid():
            self._movie_meta = MovieMeta()
            return

        self._movie.jumpToFrame(0)
        rect = self._movie.frameRect()
        count = self._movie.frameCount()
        for _ in range(1, count):
            self._movie.jumpToNextFrame()
            rect |= self._movie.frameRect()
        self._movie.jumpToFrame(0)
        self._movie_meta = MovieMeta(frame_size=rect.size(), current_frame=0)

