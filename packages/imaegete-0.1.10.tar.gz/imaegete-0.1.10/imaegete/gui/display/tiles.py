"""
Fast, LRU-based tile cache + helpers for high-quality down-scaling.

No Qt widgets here—only QImage/QPixmap manipulation.
"""

from __future__ import annotations

from math import floor, ceil
import platform
import subprocess
import ctypes
from collections import OrderedDict
from typing import Tuple

from PyQt6.QtCore import QRect
from PyQt6.QtGui import QPixmap, QImage


# ─── platform-specific helpers ────────────────────────────────────────────────


def _detect_total_ram_bytes() -> int:
    """Best-effort physical RAM detection; falls back to 4 GiB."""
    try:
        import psutil  # type: ignore
        return psutil.virtual_memory().available
    except Exception:
        os_name = platform.system()
        if os_name == "Linux":
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemAvailable:"):
                        return int(line.split()[1]) * 1024
                    if line.startswith("MemTotal:"):
                        return int(line.split()[1]) * 1024
        elif os_name == "Darwin":
            return int(subprocess.check_output(["sysctl", "-n", "hw.memsize"]))
        elif os_name == "Windows":
            k32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            kb = ctypes.c_ulonglong()
            if k32.GetPhysicallyInstalledSystemMemory(ctypes.byref(kb)):  # type: ignore[attr-defined]
                return kb.value * 1024
        return 4 * 1024 * 1024 * 1024  # 4 GiB safe default


def _compute_tile_cache_cap() -> int:
    """
    cap = min(256, max(32, avail_RAM // 2 MiB))

    At worst 1 MiB/tile → ≤ 50 % of free RAM, clamped 32-256.
    """
    bytes_avail = _detect_total_ram_bytes()
    cap = bytes_avail // (2 * 1024 * 1024)
    return max(32, min(256, cap))


# ─── TileCache ────────────────────────────────────────────────────────────────


class TileCache:
    """LRU cache of padded tiles used by StillRenderer for sharp zoom-outs."""

    def __init__(self, tile_size: int = 512, kernel_radius: int = 2) -> None:
        self.tile_size = tile_size
        self.kernel_radius = kernel_radius
        self._max_cached = _compute_tile_cache_cap()
        self._cache: OrderedDict[Tuple[int, int, int], Tuple[QPixmap, QRect]] = OrderedDict()

    # public ------------------------------------------------------------------

    def clear(self) -> None:
        self._cache.clear()

    def get(
        self,
        src_img: QImage,
        level: int,
        tx: int,
        ty: int,
        border: int | None = None,
    ) -> tuple[QPixmap, QRect]:
        """
        Retrieve (or cache) a padded tile.

        Returns:
            pixmap, pad_rect  -- pad_rect is the source QRect copied into the pixmap.
        """
        if border is None:
            border = self.kernel_radius

        key = (level, tx, ty)
        if key in self._cache:                       # ── fast path
            pix, r = self._cache.pop(key)
            self._cache[key] = (pix, r)
            return pix, r

        if len(self._cache) >= self._max_cached:     # LRU eviction
            self._cache.popitem(last=False)

        tile_x = tx * self.tile_size
        tile_y = ty * self.tile_size
        pad_rect = QRect(
            tile_x - border,
            tile_y - border,
            self.tile_size + 2 * border,
            self.tile_size + 2 * border,
        ).intersected(src_img.rect())

        pixmap = QPixmap.fromImage(src_img.copy(pad_rect))
        self._cache[key] = (pixmap, pad_rect)
        return pixmap, pad_rect

    # helpers -----------------------------------------------------------------

    @staticmethod
    def map_source_to_dest(
        sx0: float,
        sy0: float,
        sx1: float,
        sy1: float,
        eff_zoom: float,
        x_margin: int,
        y_margin: int,
    ) -> QRect:
        """Convert fractional source coords to int QRect in destination space."""

        dx0 = floor(sx0 * eff_zoom + x_margin)
        dy0 = floor(sy0 * eff_zoom + y_margin)
        dx1 = ceil(sx1 * eff_zoom + x_margin)
        dy1 = ceil(sy1 * eff_zoom + y_margin)
        return QRect(dx0, dy0, dx1 - dx0, dy1 - dy0)
