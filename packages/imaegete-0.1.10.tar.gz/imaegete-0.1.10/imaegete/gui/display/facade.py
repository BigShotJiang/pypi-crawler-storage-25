
"""
Compatibility façade that presents the exact public surface of the old
ImageDisplay while delegating all rendering to the new helpers.
"""

from __future__ import annotations

import os
from math import isclose
from threading import Event
from typing import Optional, Union, Callable

from PyQt6.QtCore import (
    QPointF,
    Qt,
    QThread,
    QMetaObject,
    QTimer,
    pyqtSlot,
)
from PyQt6.QtGui import QPixmap, QMovie, QImage
from PyQt6.QtWidgets import QWidget

from glavnaqt.events.bus import create_or_get_shared_event_bus  # ← your shared bus

from imaegete.core import logger
from imaegete.core import timing_probe

from ._state import ViewState
from .gestures import GestureHandler
from .movie_renderer import MovieRenderer
from ._base_canvas import BaseCanvas


class ImageDisplay(BaseCanvas):
    def __init__(
        self,
        *,
        state: ViewState,
        renderer: MovieRenderer,
        gestures: GestureHandler,
    ) -> None:
        super().__init__(renderer=renderer, gestures=gestures, state=state)

        self.image_label: QWidget = self                  
        self.current_path: Optional[str] = None
        self.main_event_bus = create_or_get_shared_event_bus()

        self.fullscreen_toggling = Event()
        self.is_fullscreen = False
        self._state.is_zoomed = False

        renderer._invalidate_cb = self.update

        self.frame_rendered.connect(self._emit_status_update)

        self.frame_rendered.connect(lambda: self.main_event_bus.emit("frame_rendered"))

        # Ensure the display blanks immediately when the last image is deleted.
        self.main_event_bus.subscribe("no_images", self._on_no_images)


    @pyqtSlot(object)
    def display_image(self, image: Union[str, QImage, QPixmap, QMovie]) -> None:
        """
        Accept QImage / QPixmap / QMovie or a path (string).
        Preserves user zoom+pan if they were manually set.
        Thread-safe: if called from a worker thread, re-invokes on GUI thread.
        """
        # If widget isn’t yet visible, defer exactly one tick
        if not self.isVisible():
            QTimer.singleShot(0, lambda img=image: self.display_image(img))
            return

        # If called from a worker thread, re-invoke in the GUI thread
        if QThread.currentThread() is not self.thread():
            QMetaObject.invokeMethod(
                self,
                "display_image",
                Qt.ConnectionType.QueuedConnection,
                image,
            )
            return

        # === 1) Capture old state for possible zoom+pan preservation ===
        old_fit   = self._fit_factor()
        old_zoom  = self._state.zoom
        was_zoom  = self._state.is_zoomed
        widget_dx = self._state.pan.x() * old_zoom
        widget_dy = self._state.pan.y() * old_zoom

        # === 2) Figure out “new_id” in a uniform way, and fetch “prev_id” from _last_id ===
        prev_id = getattr(self, "_last_id", None)

        if isinstance(image, str) and os.path.exists(image):
            new_id = image
        elif isinstance(image, QPixmap):
            new_id = image.cacheKey()
        elif isinstance(image, QImage):
            new_id = QPixmap.fromImage(image).cacheKey()
        elif isinstance(image, QMovie):
            new_id = id(image)
        else:
            new_id = None

        # If flood-zoom (auto-zoom) is running, do NOT preserve zoom across image changes.
        # Preserving zoom is useful for manual review, but it breaks the intended flood-zoom effect.
        auto_zoom_active = False
        t = getattr(self, "_auto_zoom_timer", None)
        if t is not None and t.isActive():
            auto_zoom_active = True

        # === 3) Load the new content into the renderer (unmodified from your code) ===
        # Timing probe: record the "set" call (GUI thread) so we can correlate to first paint.
        if timing_probe.ENABLED:
            probe_path = None
            if isinstance(image, str) and os.path.exists(image):
                probe_path = image
            else:
                probe_path = getattr(self, "current_path", None)
            timing_probe.mark_set_called(probe_path)

        # If we’re switching from a movie to a still or vice versa, disconnect prior signals:
        if isinstance(image, (QPixmap, QImage, str)) and self._renderer.movie():
            try:
                self._renderer.movie().frameChanged.disconnect()
            except TypeError:
                pass

        if isinstance(image, QImage):
            self._renderer.set_pixmap(QPixmap.fromImage(image))
            # Preserve any pre-set path hint (e.g., from the controller/UI) so
            # instrumentation can correlate paints back to paths.
        elif isinstance(image, QPixmap):
            self._renderer.set_pixmap(image)
        elif isinstance(image, QMovie):
            self._renderer.set_movie(image)
        elif isinstance(image, str) and image.lower().endswith(".gif") and os.path.exists(image):
            self._renderer.set_movie(QMovie(image))
            self.current_path = image
        elif isinstance(image, str) and os.path.exists(image):
            self._renderer.set_pixmap(QPixmap(image))
            self.current_path = image
        else:
            raise TypeError("Unsupported image type")

        # === 4) Apply preserve‐zoom vs fresh‐fit logic strictly based on new_id == prev_id ===
        if (was_zoom and old_fit > 0 and not isclose(old_zoom, old_fit)
                and not (auto_zoom_active and new_id != prev_id)):
            # — Preserve exactly the same multiple of “old_fit” on the new image —
            rel      = old_zoom / old_fit
            new_zoom = max(0.1, min(rel * self._fit_factor(), 50.0))
            self._state.zoom      = new_zoom
            self._state.pan       = QPointF(widget_dx / new_zoom,
                                            widget_dy / new_zoom)
            self._state.is_zoomed = True

            # Redraw & update status
            self.update()
            if self.current_path:
                self._emit_status_update()

            # Remember that we’re still showing “new_id”
            self._last_id = new_id
            return

        # — Otherwise (different content or no prior zoom), reset to “fit to window” —
        fit_now             = self._fit_factor()
        self._state.zoom    = fit_now
        self._state.pan     = QPointF(0, 0)
        self._state.is_zoomed = False
        self.update()
        if self.current_path:
            self._emit_status_update()

        # Remember that we’re now showing “new_id”
        self._last_id = new_id
        return


    def showEvent(self, ev):
        super().showEvent(ev)
        # Wait one tick so that the layout is fully done:
        QTimer.singleShot(0, self._ensure_fit_after_show)

    def clear_image(self) -> None:
        """Clear the currently displayed image and blank the canvas."""
        # Clear both the renderer and any QLabel contents (belt-and-suspenders).
        self._renderer.set_pixmap(QPixmap())
        try:
            self.setPixmap(QPixmap())
            self.setText('')
        except Exception:
            pass
        self.current_path = None
        self.reset_zoom()
        # Force a repaint immediately so stale pixels don't linger.
        self.update()
        self.repaint()

    def _on_no_images(self, *args, **kwargs) -> None:
        """Event-bus handler: clear the canvas when the image list becomes empty."""
        try:
            logger.info('[ImageDisplay] no_images received; calling clear_image()')
            QTimer.singleShot(0, self.clear_image)
        except Exception as e:
            logger.error('[ImageDisplay] _on_no_images error: %s', e, exc_info=True)


    def zoom_out(self, factor: float = 1.1) -> None:
        min_z  = self._fit_factor()
        new_z  = max(self._state.zoom / factor, min_z)
        self._state.zoom = new_z
        self._state.is_zoomed = not isclose(new_z, min_z, rel_tol=1e-3)
        self.update()
        if self.current_path:
            self._emit_status_update()
 
    # helper used above if it doesn’t already exist
    def get_zoom_percentage(self) -> int:
        return round(self._state.zoom * 100)


    def reset_zoom(self) -> None:
        fit_now = self._fit_factor()
        self._state.zoom      = fit_now
        self._state.pan       = QPointF(0, 0)
        self._state.is_zoomed = False
        self.update()
        if self.current_path:
            self._emit_status_update()

    def zoom_in(self, factor: float = 1.1) -> None:
        new_z   = min(self._state.zoom * factor, 50.0)
        fit_z   = self._fit_factor()
        self._state.is_zoomed = not isclose(new_z, fit_z, rel_tol=1e-3)
        self._state.zoom = new_z
        self.update()
        if self.current_path:
            self.main_event_bus.emit('status_update',
                                     self.current_path,
                                     self.get_zoom_percentage())

    def toggle_auto_zoom(self, interval_ms: int = 100) -> None:
        """
        Start/stop the flood-zoom animation.

        * If the timer is stopped, start it with the supplied `interval_ms`
          (default 100 ms – exactly what the monolith did).
        * If it is already active, stop it.
        * If callers pass a new interval while the timer is running,
          the interval is updated immediately, just like before.
        """
        # Lazily create the timer on first use
        if not hasattr(self, "_auto_zoom_timer"):
            self._auto_zoom_timer = QTimer(self)
            self._auto_zoom_timer.timeout.connect(self.zoom_in)

        # Always honour the caller-supplied interval
        self._auto_zoom_timer.setInterval(max(10, int(interval_ms)))

        if self._auto_zoom_timer.isActive():
            self._auto_zoom_timer.stop()
        else:
            self._auto_zoom_timer.start()

    def _with_movie(self, fn: Callable[[QMovie], None]) -> None:
        m = self._renderer.movie()
        if m and m.isValid():
            fn(m)
            self._emit_status_update()

    def increase_speed(self, step: int = 10):
        """Speed up GIF playback (and auto-zoom, if running)."""
        self._with_movie(lambda m: m.setSpeed(min(m.speed() + step, 400)))
        if hasattr(self, "_auto_zoom_timer") and self._auto_zoom_timer.isActive():
            # run the flood-zoom faster too
            self._auto_zoom_timer.setInterval(max(10, self._auto_zoom_timer.interval() - step))

    def decrease_speed(self, step: int = 10):
        """Slow down GIF playback (and auto-zoom, if running)."""
        self._with_movie(lambda m: m.setSpeed(max(m.speed() - step, 10)))
        if hasattr(self, "_auto_zoom_timer") and self._auto_zoom_timer.isActive():
            # and slower here as well
            self._auto_zoom_timer.setInterval(self._auto_zoom_timer.interval() + step)

    def normal_speed(self) -> None:
        self._with_movie(lambda m: m.setSpeed(100))

    def toggle_fullscreen(self, main_window):
        if self.fullscreen_toggling.is_set():
            return
        self.fullscreen_toggling.set()
        self.setUpdatesEnabled(False)

        if self.is_fullscreen:
            main_window.toggle_fullscreen_layout()
            main_window.showNormal()
        else:
            main_window.toggle_fullscreen_layout()
            main_window.showFullScreen()

        self.is_fullscreen = not self.is_fullscreen
        self.setUpdatesEnabled(True)

        # let Qt finish its resize before we repaint
        QTimer.singleShot(100, self.update)
        QTimer.singleShot(100, self._emit_status_update)
        self.fullscreen_toggling.clear()

    # expose current QMovie (used by speed helpers & tests)
    @property
    def current_movie(self) -> Optional[QMovie]:
        return self._renderer.movie()

    def _emit_status_update(self) -> None:
        """Send (path, zoom-percent) to whoever is listening."""
        self.main_event_bus.emit("status_update", self.current_path, self.get_zoom_percentage())

    def _ensure_fit_after_show(self):
        """Called exactly once, right after the widget is visible."""
        # only if we have content loaded AND the user hasn't wheel-zoomed
        if self._renderer.natural_size() and not self._state.is_zoomed:
            self.reset_zoom()           # _fit_factor() now sees final geometry