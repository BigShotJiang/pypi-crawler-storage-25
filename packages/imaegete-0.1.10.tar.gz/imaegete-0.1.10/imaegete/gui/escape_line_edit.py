from PyQt6.QtCore   import Qt, QEvent
from PyQt6.QtGui    import QKeyEvent
from PyQt6.QtWidgets import QLineEdit, QGraphicsOpacityEffect

class EscapeLineEdit(QLineEdit):
    """
    A QLineEdit that:
      - Shows 75% translucent background
      - Honors a theme (bg/fg set externally via setStyleSheet)
      - Intercepts ESC and calls a user-supplied callback before QLineEdit eats it
    """
    def __init__(self, parent=None, *, on_escape=None):
        super().__init__(parent)
        self._on_escape = on_escape
        # translucency baked in
        opacity = QGraphicsOpacityEffect(self)
        opacity.setOpacity(0.75)
        self.setGraphicsEffect(opacity)
        self.setFrame(False)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setStyleSheet("QLineEdit { border: none; }")

    def keyPressEvent(self, ev: QKeyEvent):
        # if ESC pressed, fire callback and do not let QLineEdit clear it
        if ev.type() == QEvent.Type.KeyPress and ev.key() == Qt.Key.Key_Escape:
            if callable(self._on_escape):
                self._on_escape()
            return
        super().keyPressEvent(ev)
