# imaegete/gui/vim_mode.py
#
# Vim-style modal input:
#   ':' command mode
#   '/' search mode (picker)
#
# This module is intentionally self-contained and keeps UI actions routed through
# ImageController / ImageDisplay to avoid duplicating logic.

from __future__ import annotations

from enum import Enum
import os
import shlex
from typing import Dict, List, Optional, Tuple

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPalette
from PyQt6.QtWidgets import QApplication, QCompleter, QGraphicsOpacityEffect

from imaegete.gui.escape_line_edit import EscapeLineEdit
from imaegete.core import logger


class Mode(Enum):
    NORMAL = 0
    COMMAND = 1
    SEARCH = 2


class ModeSwitcher:
    def __init__(self, gui, ctrl, disp, config, shortmap=None):
        self.gui = gui
        self.ctrl = ctrl
        self.disp = disp
        self.config = config

        self.mode: Mode = Mode.NORMAL
        self.keys: Dict[str, object] = {}

        # search-model caches
        self._search_paths: List[str] = []
        self._search_labels: List[str] = []
        self._search_label_to_index: Dict[str, int] = {}
        # entries: (label, idx, lower_label)
        self._search_entries: List[Tuple[str, int, str]] = []

        # ——— Command input (":") —————————————————————
        self.cmd = EscapeLineEdit(gui, on_escape=self._exit_mode)
        self.cmd.hide()
        self.cmd.setPlaceholderText(':')
        self.cmd.returnPressed.connect(self._on_enter)

        # ——— Filename search input ("/") —————————————————
        self.search = EscapeLineEdit(gui, on_escape=self._exit_mode)
        self.search.hide()
        self.search.setPlaceholderText('🔍 ')
        self.search.returnPressed.connect(self._on_search_enter)
        self.search.textEdited.connect(self._on_search_text_changed)

        # completer must live after creating `self.search`
        self.search_completer = QCompleter([], self.search)
        self.search.setCompleter(self.search_completer)
        self._configure_search_completer()

        # Apply initial theme
        dark = QApplication.palette().color(QPalette.ColorRole.Window).lightness() < 128
        self._apply_theme(dark)
        try:
            gui.themeChanged.connect(self.apply_theme)
        except Exception:
            pass

        # register for auto-scaling if available
        try:
            wm = gui.layout_manager.widget_adjuster
            for w in (self.cmd, self.search, self.search_completer.popup()):
                wm.register_autofit_widget(w)
        except Exception:
            pass

        # keep bars full-width on resize
        try:
            gui.resizeFinished.connect(self._on_main_resize)
        except Exception:
            pass

        # wire in shortcuts if provided
        if shortmap:
            self.attach_keys(shortmap)

    def attach_keys(self, key_dict):
        """Attach the shortcut groups so we can disable NORMAL shortcuts in modal modes."""
        self.keys = key_dict or {}

    # ──────────────────────────────────────────────────────────────────────────
    # Mode transitions
    # ──────────────────────────────────────────────────────────────────────────

    def _apply_mode(self):
        for sc in self.keys.get('NORMAL', []):
            try:
                sc.setEnabled(self.mode == Mode.NORMAL)
            except Exception:
                pass

        if self.mode == Mode.COMMAND:
            self.search.hide()
            self.cmd.show()
            self.cmd.setFocus()
            # ensure full width immediately
            self._on_main_resize(self.gui.width(), self.gui.height())
        elif self.mode == Mode.SEARCH:
            self.cmd.hide()
            self.search.show()
            self.search.setFocus()
            self._on_main_resize(self.gui.width(), self.gui.height())
        else:
            self.cmd.hide()
            self.search.hide()
            try:
                self.gui.setFocus()
            except Exception:
                pass

    def _enter_command(self):
        if self.mode != Mode.NORMAL:
            return
        self.mode = Mode.COMMAND
        self.cmd.clear()
        self._apply_mode()

    def _enter_search(self):
        if self.mode != Mode.NORMAL:
            return
        self.mode = Mode.SEARCH
        self._refresh_search_model()
        self.search.clear()
        self._apply_mode()
        # show popup list immediately
        try:
            self.search_completer.complete()
        except Exception:
            pass

    def _exit_mode(self):
        self.mode = Mode.NORMAL
        self._apply_mode()

    # ──────────────────────────────────────────────────────────────────────────
    # ':' command mode
    # ──────────────────────────────────────────────────────────────────────────

    def _on_enter(self):
        line = self.cmd.text().lstrip(':').strip()
        ok = self._dispatch(line)
        if ok:
            self._exit_mode()
        else:
            # keep command mode open for quick fix
            try:
                self.cmd.selectAll()
            except Exception:
                pass

    def _dispatch(self, cmd_line: str) -> bool:
        if not cmd_line:
            return True

        # Allow :<N> jump (1-based index)
        if cmd_line.isdigit():
            idx = int(cmd_line) - 1
            return self._jump_to_index(idx)

        try:
            parts = shlex.split(cmd_line)
        except Exception:
            parts = cmd_line.split()

        if not parts:
            return True

        cmd = parts[0].lower()
        args = parts[1:]

        def arg0() -> str:
            return args[0] if args else ''

        try:
            if cmd in ('q', 'quit', 'exit'):
                try:
                    self.gui.close()
                except Exception:
                    # fallback: ask controller to shutdown if available
                    try:
                        self.ctrl.shutdown()
                    except Exception:
                        pass
                return True

            if cmd in ('n', 'next'):
                self.ctrl.next_image()
                return True
            if cmd in ('p', 'prev', 'previous'):
                self.ctrl.previous_image()
                return True
            if cmd == 'first':
                self.ctrl.first_image()
                return True
            if cmd == 'last':
                self.ctrl.last_image()
                return True
            if cmd in ('rand', 'random'):
                self.ctrl.random_image()
                return True

            if cmd in ('del', 'delete', 'rm'):
                self.ctrl.delete_image()
                return True
            if cmd in ('u', 'undo'):
                self.ctrl.undo_last_action()
                return True

            if cmd in ('m', 'move'):
                if not getattr(self.config, 'categories', None):
                    logger.warning("[VimMode] :move used but no categories configured")
                    return False
                if not args:
                    logger.warning("[VimMode] :move requires a category name or index")
                    return False

                token = arg0().strip()
                cats = list(self.config.categories or [])

                # numeric category index (1-based)
                if token.isdigit():
                    ci = int(token) - 1
                    if ci < 0 or ci >= len(cats):
                        logger.warning("[VimMode] category index out of range: %s", token)
                        return False
                    self.ctrl.move_image(cats[ci])
                    return True

                # name match (case-insensitive)
                low = token.lower()
                for c in cats:
                    if c.lower() == low:
                        self.ctrl.move_image(c)
                        return True

                # prefix match
                matches = [c for c in cats if c.lower().startswith(low)]
                if len(matches) == 1:
                    self.ctrl.move_image(matches[0])
                    return True

                logger.warning("[VimMode] unknown category: %s", token)
                return False

            if cmd in ('fs', 'fullscreen'):
                try:
                    self.disp.toggle_fullscreen()
                except Exception:
                    # some versions expose through gui
                    try:
                        self.gui.toggle_fullscreen()
                    except Exception:
                        pass
                return True

            if cmd in ('ss', 'slideshow'):
                if not args:
                    self.ctrl.toggle_slideshow()
                    return True
                val = arg0().lower()
                if val in ('on', 'start', '1', 'true', 'yes'):
                    self.ctrl.start_slideshow()
                    return True
                if val in ('off', 'stop', '0', 'false', 'no'):
                    self.ctrl.stop_slideshow()
                    return True
                logger.warning("[VimMode] :slideshow arg must be on|off (or omitted)")
                return False

            logger.warning("[VimMode] unknown command: %s", cmd)
            return False
        except Exception as e:
            logger.exception("[VimMode] command failed: %s", e)
            return False

    # ──────────────────────────────────────────────────────────────────────────
    # '/' search mode (picker)
    # ──────────────────────────────────────────────────────────────────────────

    def _refresh_search_model(self):
        paths = self.ctrl.image_list_manager.data_service.get_image_list()
        self._search_paths = list(paths)
        labels = self._build_unique_labels(paths)
        self._search_labels = labels
        self._search_label_to_index = {label: idx for idx, label in enumerate(labels)}
        self._search_entries = [(label, idx, label.lower()) for idx, label in enumerate(labels)]
        self._set_search_completions(labels)

    def _set_search_completions(self, labels: List[str]):
        """Set completer list safely."""
        try:
            self.search_completer.model().setStringList(labels)
            return
        except Exception:
            pass

        # fallback: rebuild completer and re-apply styling/behavior
        self.search_completer = QCompleter(labels, self.search)
        self.search.setCompleter(self.search_completer)
        self._configure_search_completer()

    def _configure_search_completer(self):
        # popup completion list
        try:
            self.search_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        except Exception:
            pass
        try:
            self.search_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        except Exception:
            try:
                self.search_completer.setCaseSensitivity(Qt.CaseInsensitive)
            except Exception:
                pass
        try:
            self.search_completer.setMaxVisibleItems(20)
        except Exception:
            pass

        popup = self.search_completer.popup()
        popup.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        # match line edit transparency
        orig_effect = self.search.graphicsEffect()
        if isinstance(orig_effect, QGraphicsOpacityEffect):
            effect = QGraphicsOpacityEffect(popup)
            effect.setOpacity(orig_effect.opacity())
            popup.setGraphicsEffect(effect)

        # if user selects from popup, jump immediately
        try:
            self.search_completer.activated[str].connect(self._on_search_activated)
        except Exception:
            try:
                self.search_completer.activated.connect(self._on_search_activated)
            except Exception:
                pass

    def _on_search_text_changed(self, text: str):
        # rank and show top results as the completion list
        needle = (text or '').strip().lower()
        if not needle:
            # show full list (or first chunk)
            self._set_search_completions(self._search_labels[:500])
            try:
                self.search_completer.complete()
            except Exception:
                pass
            return

        ranked: List[Tuple[int, str]] = []
        for label, idx, ll in self._search_entries:
            score = self._fuzzy_score(needle, ll)
            if score >= 0:
                ranked.append((score, label))

        ranked.sort(reverse=True, key=lambda t: t[0])
        top = [lbl for _, lbl in ranked[:500]]
        self._set_search_completions(top)

        try:
            self.search_completer.complete()
        except Exception:
            pass

    def _on_search_activated(self, text: str):
        label = (text or '').strip()
        if not label:
            return
        idx = self._search_label_to_index.get(label)
        if idx is None:
            return
        self._jump_to_index(idx)
        self._exit_mode()

    def _on_search_enter(self):
        # Prefer highlighted completion if popup is open
        label = self._get_selected_completion()
        if label:
            idx = self._search_label_to_index.get(label)
            if idx is not None and self._jump_to_index(idx):
                self._exit_mode()
                return

        # Otherwise, pick best match for typed text
        text = (self.search.text() or '').strip().lower()
        if not text:
            self._exit_mode()
            return

        best: Optional[Tuple[int, int]] = None  # (score, idx)
        for label, idx, ll in self._search_entries:
            score = self._fuzzy_score(text, ll)
            if score < 0:
                continue
            if best is None or score > best[0]:
                best = (score, idx)

        if best is not None:
            self._jump_to_index(best[1])

        self._exit_mode()

    def _get_selected_completion(self) -> Optional[str]:
        try:
            popup = self.search_completer.popup()
            if popup and popup.isVisible():
                mi = popup.currentIndex()
                if mi.isValid():
                    data = mi.data()
                    if isinstance(data, str):
                        return data
        except Exception:
            pass
        # fallback
        try:
            cc = self.search_completer.currentCompletion()
            if cc:
                return cc
        except Exception:
            pass
        return None

    def _build_unique_labels(self, paths: List[str]) -> List[str]:
        """Create unique human-readable labels aligned with `paths`.

        If basenames collide, progressively prefix parent directories until unique.
        """
        labels = [os.path.basename(p) for p in paths]
        if not labels:
            return labels

        by_name: Dict[str, List[int]] = {}
        for i, name in enumerate(labels):
            by_name.setdefault(name, []).append(i)

        for name, idxs in by_name.items():
            if len(idxs) <= 1:
                continue

            depth = 1
            while True:
                candidate: List[str] = []
                for i in idxs:
                    parent = os.path.normpath(os.path.dirname(paths[i]))
                    parts = [p for p in parent.split(os.sep) if p]
                    tail = parts[-depth:] if parts else []
                    prefix = os.path.join(*tail) if tail else ''
                    candidate.append(os.path.join(prefix, labels[i]) if prefix else labels[i])

                if len(set(candidate)) == len(candidate):
                    for i, lbl in zip(idxs, candidate):
                        labels[i] = lbl
                    break

                depth += 1
                if depth > 12:
                    for i in idxs:
                        labels[i] = paths[i]
                    break

        return labels

    def _fuzzy_score(self, needle: str, hay_lower: str) -> int:
        """Cheap fuzzy score; higher is better. Returns -1 if no match.

        - Prefer substring matches (earlier is better)
        - Else accept subsequence matches (characters in order)
        """
        if not needle:
            return 0

        pos = hay_lower.find(needle)
        if pos != -1:
            # prefer earlier and shorter strings
            return 10000 - (pos * 10) - len(hay_lower)

        # subsequence match
        it = iter(hay_lower)
        matched = 0
        for ch in needle:
            for hch in it:
                if hch == ch:
                    matched += 1
                    break
            else:
                return -1

        return 1000 + matched - len(hay_lower)

    def _jump_to_index(self, idx: int) -> bool:
        paths = self.ctrl.image_list_manager.data_service.get_image_list()
        if not paths:
            return False
        if idx < 0:
            idx = 0
        if idx >= len(paths):
            idx = len(paths) - 1
        path = paths[idx]
        try:
            self.ctrl.image_list_manager.set_current_image_by_index(idx)
            self.ctrl.show_image(path)
            return True
        except Exception as e:
            logger.exception("[VimMode] jump failed: %s", e)
            return False

    # ──────────────────────────────────────────────────────────────────────────
    # Theme + resize
    # ──────────────────────────────────────────────────────────────────────────

    def _apply_theme(self, dark: bool):
        bg = '0,0,0,180' if dark else '255,255,255,180'
        fg = 'white' if dark else 'black'
        style = f"QLineEdit {{ background: rgba({bg}); color: {fg}; border: none; }}"
        try:
            self.cmd.setStyleSheet(style)
            self.search.setStyleSheet(style)
        except Exception:
            pass

    def apply_theme(self, dark: bool):
        self._apply_theme(dark)

    def _on_main_resize(self, w: int, h: int):
        for bar in (self.cmd, self.search):
            try:
                bar.resize(w, bar.sizeHint().height())
                bar.move(0, 0)
                bar.raise_()
            except Exception:
                pass
