"""Local desktop-open helpers for GUI actions.

Qt already owns the platform abstraction here; do not shell out to a
Linux-only opener from GUI code.
"""

from __future__ import annotations

import logging
import os
from os import PathLike

from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QDesktopServices

_logger = logging.getLogger(__name__)


def open_local_path(path: str | PathLike[str] | None) -> bool:
    """Open a local file or directory through Qt's desktop services.

    Returns ``True`` when Qt accepts the request and ``False`` when there is no
    path, Qt refuses it, or the platform integration raises an exception.
    """

    if not path:
        return False

    try:
        local_path = os.path.abspath(os.fspath(path))
        opened = QDesktopServices.openUrl(QUrl.fromLocalFile(local_path))
    except Exception:
        _logger.exception("Failed to open local path: %r", path)
        return False

    if not opened:
        _logger.warning("Desktop services refused to open local path: %s", local_path)

    return bool(opened)
