import sys
import os
import signal
from PyQt6.QtCore import QTimer
from imaegete.core.config import config 
from imaegete.core import logger
from PyQt6.QtWidgets import QApplication

from glavnaqt.core.thread_manager import ThreadManager

#from imaegete.gui.image_display import ImageDisplay
from imaegete.gui.display import create_image_display


from imaegete.gui.vim_mode import ModeSwitcher
from imaegete.gui.main_window import ImaegeteGUI
from imaegete.gui.status_bar_manager import ImaegeteStatusBarManager
from imaegete.image_processing.data_management.cache_manager import CacheManager
from imaegete.image_processing.data_management.data_service import ImageDataService
from imaegete.image_processing.data_management.file_task_handler import FileTaskHandler
from imaegete.image_processing.data_management.image_cache_handler import ImageCacheHandler
from imaegete.image_processing.data_management.image_list_manager import ImageListManager
from imaegete.image_processing.image_controller import ImageController
from imaegete.image_processing.image_handler import ImageHandler
from imaegete.image_processing.image_loader import ImageLoader
from imaegete.key_binding.key_binder import bind_keys


def _install_sigint_handler(app):
    """Route Ctrl-C through Qt shutdown so aboutToQuit cleanup runs."""

    def _handle_sigint(signum, frame):
        # Let a second Ctrl-C use the process default if cleanup hangs.
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        app.quit()

    signal.signal(signal.SIGINT, _handle_sigint)


def main():
    """
    Main entry point for the Imaegete application.
    Initializes the GUI and manages application shutdown.
    """
    logger.debug("[Main] Starting application.")

    # Establish a GUI
    thread_manager = ThreadManager()
    data_service = ImageDataService()
    app = QApplication(sys.argv)
    _install_sigint_handler(app)
    status_bar_manager = ImaegeteStatusBarManager(
        thread_manager=thread_manager,
        data_service=data_service,
        ui_config=config,
    )

    # Give Python regular bytecode checkpoints while Qt owns the event loop.
    timer = QTimer(app)
    timer.timeout.connect(lambda: None)
    timer.start(100)  # tick every 100 ms

    # Data & cache setup
    # For multi-select “playlist” launches, only watch the parent directories of
    # the explicitly selected files (avoids monitoring large, unrelated trees).
    watch_dirs = config.start_dirs
    if getattr(config, 'selection_only', False) and getattr(config, 'selection_files', None):
        watch_dirs = sorted({os.path.dirname(p) for p in config.selection_files})

    cache_manager = CacheManager(
        config.cache_dir,
        thread_manager,
        data_service,
        image_directories=watch_dirs,
        cache_limit_bytes=config.cache_size,
    )

    # Clear cache and exit option
    if config.clear_cache:
        cache_manager.clear_disk_cache()
        cache_manager.shutdown()                                             # stops the file watcher & clears queues
        thread_manager.shutdown()                                            # flags all remaining tasks and clears pool 
        timer.stop()
        sys.exit(0)

    data_service.set_cache_manager(cache_manager)

    # Controllers & handlers
    image_list_manager = ImageListManager(data_service=data_service, thread_manager=thread_manager)
    file_task_handler = FileTaskHandler(thread_manager=thread_manager, data_service=data_service)
    image_handler = ImageHandler(data_service, thread_manager, image_list_manager, file_task_handler)
    image_cache_handler = ImageCacheHandler(cache_manager=cache_manager)
    image_loader = ImageLoader(cache_handler=image_cache_handler, thread_manager=thread_manager)

    # Sets up a first image
    image_path = getattr(config, 'image_path', None)
    if image_path:
        data_service.set_current_image_path(image_path)

    image_controller = ImageController(
        image_list_manager,
        image_loader,
        image_handler
    )

    image_display = create_image_display() 
    sorter_gui = ImaegeteGUI(
        image_display=image_display,
        thread_manager=thread_manager,
        image_controller=image_controller,
        data_service=data_service,
        timer=timer,
        ui_config=config,
    )

    
    # 1) install the modal commander (with no shortcuts yet)
    ms = ModeSwitcher(
        sorter_gui,
        image_controller,
        image_display,
        config
    )
 
    # 2) collect and group your shortcuts, wiring in ENTER/SEARCH handlers
    shortcuts = bind_keys(
        sorter_gui,
        image_controller,
        image_display,
        mode_switcher=ms
    )
 
    # 3) finally, give ModeSwitcher its shortcuts so it can enable/disable them
    ms.attach_keys(shortcuts)
     
    def on_exit():
        logger.debug("[Main] Quit requested, cleaning up…")

        # 1) Stop list-refresh threads
        thread_manager.stop_tasks_by_tag("refresh_image_list")               # signal them to stop 
        thread_manager.wait_for_tagged_tasks("refresh_image_list")           # wait for each to finish 

        # 2) Shut down other services
        status_bar_manager.shutdown()
        image_controller.shutdown()
        cache_manager.shutdown()                                             # stops the file watcher & clears queues
        
        # 3) Finally, tear down the thread pool
        thread_manager.shutdown()                                            # flags all remaining tasks and clears pool 
        timer.stop()

    app.aboutToQuit.connect(on_exit)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
