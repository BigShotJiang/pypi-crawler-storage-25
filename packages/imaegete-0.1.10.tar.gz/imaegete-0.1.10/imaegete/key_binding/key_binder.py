# Imaegete — Key binding module
# Binds all application shortcuts, including Vim-mode enter/exit, in one centralized place.

from PyQt6.QtGui import QKeySequence, QShortcut

from imaegete.core.config import (
    config,
    VIM_KEYS,
    NEXT_KEY, PREV_KEY, FIRST_KEY, LAST_KEY,
    DELETE_KEY, RANDOM_KEY, UNDO_KEY,
    FULLSCREEN_KEY, QUIT_KEY,
    SLIDE_SHOW_KEY, SPEED_UP_KEY, SPEED_DOWN_KEY,
    FLOOD_ZOOM
)


def bind_keys(gui, image_controller, image_display, mode_switcher=None):
    """
    Create and return all QShortcuts:
      - 'NORMAL': active in normal (Vim) mode
      - 'GLOBAL': always active regardless of mode
      - 'ENTER_CMD': key for ':' to enter command-mode
      - 'ENTER_SEARCH': key for '/' to enter search-mode
    If mode_switcher is provided, its handlers will be wired for enter/exit.
    """
    normal_sc, global_sc = [], []

    def add(key_seq, handler, scope='NORMAL'):
        sc = QShortcut(QKeySequence(key_seq), gui)
        sc.activated.connect(handler)
        if scope == 'GLOBAL':
            global_sc.append(sc)
        else:
            normal_sc.append(sc)
        return sc

    # ── NORMAL mode (Vim-like) bindings ──────────────────
    add('j', image_controller.next_image)
    add('k', image_controller.previous_image)
    add('gg', image_controller.first_image)
    add('G',  image_controller.last_image)
    add('+', image_display.zoom_in)
    add('-', image_display.zoom_out)
    add('=', image_display.reset_zoom)

    # ── GLOBAL (always-on) bindings ──────────────────────
    add(NEXT_KEY,     image_controller.next_image,    'GLOBAL')
    add(PREV_KEY,     image_controller.previous_image,'GLOBAL')
    add(FIRST_KEY,    image_controller.first_image,   'GLOBAL')
    add(LAST_KEY,     image_controller.last_image,    'GLOBAL')
    add(DELETE_KEY,   image_controller.delete_image,  'GLOBAL')
    add(RANDOM_KEY,   image_controller.random_image,  'GLOBAL')
    add(UNDO_KEY,     image_controller.undo_last_action,'GLOBAL')
    add(FULLSCREEN_KEY, lambda: image_display.toggle_fullscreen(gui), 'GLOBAL')
    add(FLOOD_ZOOM, image_display.toggle_auto_zoom,'GLOBAL')
    add(SLIDE_SHOW_KEY, image_controller.toggle_slideshow,'GLOBAL')
    add(QUIT_KEY,     gui.close,                     'GLOBAL')

    # Combined speed control for display and slideshow
    def _speed_up():
        image_display.increase_speed()
        image_controller.increase_slideshow_speed()
    def _slow_down():
        image_display.decrease_speed()
        image_controller.decrease_slideshow_speed()
    add(SPEED_UP_KEY,   _speed_up,   'GLOBAL')
    add(SPEED_DOWN_KEY, _slow_down,  'GLOBAL')



    # ── CATEGORY move bindings (1..9) ────────────────────
    # When categories are configured, pressing the corresponding digit key moves
    # the current image into that category folder. (Undo is supported via UNDO_KEY.)
    if getattr(config, 'categories', None):
        for i, category in enumerate(config.categories[:9]):
            key = str(i + 1)
            add(key, lambda c=category: image_controller.move_image(c), 'GLOBAL')

    # ── ENTER command‐mode (:) and search mode (/) ───────
    enter_cmd = add(VIM_KEYS['ENTER_CMD'], lambda: None)
    enter_search = add(VIM_KEYS['ENTER_SEARCH'], lambda: None)

    # Wire ModeSwitcher if provided
    if mode_switcher:
        # Rebind enter commands
        enter_cmd.activated.disconnect()
        enter_cmd.activated.connect(mode_switcher._enter_command)
        enter_search.activated.disconnect()
        enter_search.activated.connect(mode_switcher._enter_search)

        # ESC to exit from both cmd and search widgets
        for widget in (mode_switcher.cmd, mode_switcher.search):
            esc = QShortcut(QKeySequence(VIM_KEYS['EXIT_MODE']), widget)
            esc.activated.connect(mode_switcher._exit_mode)

    return {
        'NORMAL':     normal_sc,
        'GLOBAL':     global_sc,
        'ENTER_CMD':  enter_cmd,
        'ENTER_SEARCH': enter_search
    }

