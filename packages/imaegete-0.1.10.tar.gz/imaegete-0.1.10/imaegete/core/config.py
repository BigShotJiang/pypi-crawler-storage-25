import os
import sys
import argparse
from urllib.parse import urlparse, unquote
from confuse import NotFoundError, ConfigTypeError
from confumo import Confumo
from glavnaqt.core.config import UIConfig        # inherit base UIConfig

APP_NAME = "Imaegete"
IMAGE_CACHE_MAX_MB = 512
CACHE_SIZE_BYTES_PER_MB = 1024 * 1024
LOGGER_NAME = 'imaegete'
LOG_FILE_NAME = f'{LOGGER_NAME}.log'
WINDOW_TITLE_SUFFIX = 'Imaegete'

# Core navigation and UI keys
NEXT_KEY = 'Right'
PREV_KEY = 'Left'
FIRST_KEY = 'Home'
LAST_KEY = 'End'
RANDOM_KEY = 'R'
DELETE_KEY = 'Delete'
UNDO_KEY = 'U'
FULLSCREEN_KEY = 'F'
QUIT_KEY = 'Q'
SLIDE_SHOW_KEY = 'S'
SPEED_UP_KEY = ']'
SPEED_DOWN_KEY = '['
FLOOD_ZOOM = '\\'

# Vim-mode activation and control keys
ENTER_CMD_KEY    = ':'   # enter command mode
ENTER_SEARCH_KEY = '/'   # enter filename search
EXIT_MODE_KEY    = 'Escape'  # exit any mode back to normal

# Bundle all Vim-mode keys for easy override
VIM_KEYS = {
    'ENTER_CMD':    ENTER_CMD_KEY,
    'ENTER_SEARCH': ENTER_SEARCH_KEY,
    'EXIT_MODE':    EXIT_MODE_KEY,
}

class ImaegeteConfig(UIConfig):
    """
    Configuration for Imaegete application, extends base UIConfig with
    command-line args, directories, and Vim-mode customization.
    """
    _hide_cycle_flag = True

    def add_args(self, parser: argparse.ArgumentParser):
        # Core CLI args (categories, dirs, logging)
        parser.add_argument(
            '--log_level',
            choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
            default='INFO',
            help="Logging level"
        )
        parser.add_argument(
            '--categories', nargs='*', type=str,
            help="List of image categories"
        )
        parser.add_argument(
            '--sort_dir', type=str,
            help="Base directory to put sorted folders. Defaults to start_dirs"
        )
        parser.add_argument(
            '--start_dirs', nargs='+', default=['.'],
            help="One or more base image directories"
        )
        parser.add_argument(
            '--log_dir', type=str,
            help="Where to store logs. Defaults to CONFIG_DIR/logs"
        )
        parser.add_argument(
            '--cache_dir', type=str,
            help="Where to cache data. Defaults to CONFIG_DIR/cache"
        )
        parser.add_argument(
            '--cache_size', type=int, default=argparse.SUPPRESS,
            help=f"The starting cache size in MB. Defaults to {IMAGE_CACHE_MAX_MB}"
        )
        parser.add_argument(
            '--clear_cache', action='store_true',
            help="Clears the cache on disk and exits"
        )
        parser.add_argument(
            '-i', '--image', '--image-path',
            dest='image_path', type=str,
            help="Optional path to a single image file to open on startup"
        )
        # Custom shell commands
        parser.add_argument(
            '--cmd',
            dest='commands',
            action='append',
            metavar='NAME=KEY=TEMPLATE',
            help="Custom command: NAME=KEY=SHELL-TEMPLATE (use {path})"
        )
        parser.add_argument(
            'paths', nargs='*', type=str,
            help="Optional paths to image files and/or directories to open on startup"
        )

    @staticmethod
    def _coerce_cli_path(raw: str) -> str:
        """Accept both plain paths and file: URLs from desktop entries."""
        if not raw:
            return raw
        if raw.startswith('file:'):
            try:
                u = urlparse(raw)
                if u.scheme == 'file' and (u.netloc in ('', 'localhost')):
                    return unquote(u.path)
            except Exception:
                # fall back to raw
                pass
        return raw

    def _init_subclass(self):
        # Initialize base UIConfig fields
        super()._init_subclass()
        cfg = self.cfg

        # --- Start directories and optional single image ---
        try:
            raw = cfg['start_dirs'].get(list)
        except (NotFoundError, ConfigTypeError):
            raw = [cfg['start_dirs'].get(str)]
        abs_start_dirs = [os.path.abspath(d) for d in raw]

        try:
            img_arg = cfg['image_path'].get(str)
        except (NotFoundError, ConfigTypeError):
            img_arg = None

        # Positional paths and/or --image-path may be provided by file managers.
        raw_paths = list(getattr(self.args, 'paths', None) or [])
        raw_paths = [self._coerce_cli_path(p) for p in raw_paths if p]

        files: list[str] = []
        dirs: list[str] = []
        for p in raw_paths:
            full = os.path.abspath(p)
            if os.path.isdir(full):
                dirs.append(full)
            elif os.path.isfile(full):
                files.append(full)
            else:
                raise ValueError(f"Path not found: {p}")

        # If launched with --image-path (common for some desktop entries),
        # treat it like providing a single file positional arg.
        img_cli = getattr(self.args, 'image_path', None)
        if (not raw_paths) and img_cli:
            img_cli = self._coerce_cli_path(img_cli)
            full = os.path.abspath(img_cli)
            if os.path.isfile(full):
                files.append(full)
            elif os.path.isdir(full):
                dirs.append(full)
            else:
                raise ValueError(f"Path not found: {img_cli}")

        # Build inferred dirs in a stable order: file parents first, then explicit dirs.
        inferred: list[str] = []
        for f in files:
            parent = os.path.dirname(f)
            if parent not in inferred:
                inferred.append(parent)
        for d in dirs:
            if d not in inferred:
                inferred.append(d)

        # Decide initial image (first file wins).
        if files:
            img_arg = files[0]

        # Multi-select (e.g. file-manager “Open With” passing multiple files):
        # treat the passed files as the *entire* navigation set instead of
        # recursively scanning their parent directories.
        self.selection_only = bool(files) and (len(files) > 1) and (not dirs)
        if self.selection_only:
            # Keep only existing image files, preserving argument order.
            chosen: list[str] = []
            seen: set[str] = set()
            for f in files:
                if f in seen:
                    continue
                seen.add(f)
                if os.path.isfile(f):
                    chosen.append(f)
            self.selection_files = chosen
            # In selection-only mode, watch roots should be just the parent dirs
            # of selected files (avoids monitoring unrelated trees from config).
            abs_start_dirs = inferred or abs_start_dirs
        else:
            self.selection_files = None
            # Apply inferred dirs:
            # - if start_dirs is still the default ['.'], replace it with inferred
            # - otherwise, prepend inferred dirs that are missing (preserves explicit config)
            if inferred:
                if abs_start_dirs == [os.path.abspath('.')]:
                    abs_start_dirs = inferred
                else:
                    for d in reversed(inferred):
                        if d not in abs_start_dirs:
                            abs_start_dirs.insert(0, d)
        self.start_dirs = abs_start_dirs
        self.image_path = img_arg

        # --- User-defined shell commands from YAML or CLI ---
        try:
            raw_cmds = cfg['commands'].get(dict)
            self.user_commands = {
                name: {'key': info.get('key'), 'tmpl': info.get('tmpl')}
                for name, info in raw_cmds.items()
            }
        except (NotFoundError, ConfigTypeError):
            self.user_commands = {}
            for entry in getattr(self.args, 'commands', []) or []:
                name, key, tmpl = entry.split('=', 2)
                self.user_commands[name] = {'key': key, 'tmpl': tmpl}

        # --- Logging and cache directories ---
        self.log_level = cfg['log_level'].get(str)
        self.config_dir = os.path.abspath(cfg['config_dir'].get(str))

        try:
            self.categories = cfg['categories'].get(list)
        except (NotFoundError, ConfigTypeError):
            self.categories = None

        try:
            self.sort_dir = cfg['sort_dir'].get(str)
        except (NotFoundError, ConfigTypeError):
            self.sort_dir = None

        try:
            self.log_dir = os.path.abspath(cfg['log_dir'].get(str))
        except (NotFoundError, ConfigTypeError):
            self.log_dir = os.path.join(self.config_dir, 'logs')

        try:
            self.cache_dir = os.path.abspath(cfg['cache_dir'].get(str))
        except (NotFoundError, ConfigTypeError):
            self.cache_dir = os.path.join(self.config_dir, 'cache')

        try:
            size_mb = cfg['cache_size'].get(int)
        except (NotFoundError, ConfigTypeError):
            size_mb = IMAGE_CACHE_MAX_MB
        # CLI/YAML expose cache_size in MB; runtime cache consumers need bytes.
        self.cache_size = size_mb * CACHE_SIZE_BYTES_PER_MB

        self.clear_cache = cfg['clear_cache'].get(bool)

        # --- Destination & deletion folders per start_dir ---
        self.dest_folders = {}
        self.delete_folders = {}
        for start in self.start_dirs:
            base_sort = self.sort_dir or start
            if self.categories:
                self.dest_folders[start] = {}
                for cat in self.categories:
                    path = os.path.join(base_sort, cat)
                    self.dest_folders[start][cat] = os.path.abspath(path)
            deleted = os.path.join(base_sort, 'deleted')
            self.delete_folders[start] = os.path.abspath(deleted)

    def _cache_size_mb_for_persistence(self):
        # Persist the same MB unit accepted by --cache_size and YAML input.
        return self.cache_size // CACHE_SIZE_BYTES_PER_MB

    def to_dict(self):
        data = {
            'app_name':       self.app_name,
            'log_level':      self.log_level,
            'config_dir':     self.config_dir,
            'categories':     self.categories,
            'sort_dir':       self.sort_dir,
            'start_dirs':     self.start_dirs,
            'log_dir':        self.log_dir,
            'cache_dir':      self.cache_dir,
            'cache_size':     self._cache_size_mb_for_persistence(),
            'clear_cache':    self.clear_cache,
            'dest_folders':   self.dest_folders,
            'delete_folders': self.delete_folders,
            'image_path':     self.image_path,
        }
        return {key: value for key, value in data.items() if value is not None}

# Expose Imaegete's concrete config. GlavnaQt receives it via explicit
# ui_config injection instead of replacing glavnaqt.core.config globally.
config = Confumo.expose(
    APP_NAME,
    ImaegeteConfig,
    globals(),
)
