"""Path normalization utilities.

We need a *stable* canonical form for cache keys.

Important detail (POSIX): ``os.path.abspath('//foo')`` may preserve the
double-slash prefix due to historical/UNC semantics. For Imaegete's cache keys,
we want ``//foo`` and ``/foo`` to be treated the same.
"""

from __future__ import annotations

import os


def normalize_path(path: str | None) -> str | None:
    if not path:
        return path

    try:
        p = os.path.expanduser(str(path))
    except Exception:
        p = str(path)

    try:
        p = os.path.abspath(p)
    except Exception:
        pass

    try:
        p = os.path.normpath(p)
    except Exception:
        pass

    # POSIX-only: collapse leading '//' into '/'.
    # (On Windows, '\\server\share' must be preserved.)
    if os.sep == '/':
        while p.startswith('//'):
            p = p[1:]

    return p
