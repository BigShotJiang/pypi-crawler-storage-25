"""Timing instrumentation for Imaegete.

Opt-in via:
  - IMAEGETE_TIMING=1
  - IMAEGETE_TIMING_INFO=1  (more verbose)

Goals:
  - Log beat schedule phase/jitter at tick time.
  - Correlate tick → show_image → image_loaded → set_pixmap → first paint.

This module is intentionally lightweight and thread-safe.
"""

from __future__ import annotations

import os
import time
import threading
from dataclasses import dataclass

from imaegete.core import logger


def _env_flag(name: str) -> bool:
    v = os.getenv(name, "").strip().lower()
    return v in {"1", "true", "yes", "on"}


ENABLED: bool = _env_flag("IMAEGETE_TIMING")
INFO: bool = _env_flag("IMAEGETE_TIMING_INFO")


@dataclass
class TickInfo:
    seq: int
    beat_index: int
    cycle_interval_ms: int
    intended_ms: int
    tick_enter_ms: int
    tick_enter_ns: int
    mode: str
    action: str
    path: str
    ready_state: str


_lock = threading.Lock()

_tick_by_seq: dict[int, TickInfo] = {}
_planned_seq_by_path: dict[str, int] = {}
_planned_at_ns_by_seq: dict[int, int] = {}

_show_called_ns: dict[str, int] = {}
_image_loaded_ns: dict[str, int] = {}
_set_called_ns: dict[str, int] = {}

_last_paint_ns: int | None = None
_last_paint_path: str | None = None


def is_enabled() -> bool:
    return bool(ENABLED)


def _ms_from_ns(ns: int | None) -> float | None:
    if ns is None:
        return None
    return ns / 1_000_000.0


def record_tick(
    *,
    seq: int,
    beat_index: int,
    cycle_interval_ms: int,
    intended_ms: int,
    tick_enter_ms: int,
    tick_enter_ns: int,
    mode: str,
    action: str,
    path: str,
    ready_state: str,
) -> None:
    """Called from ImageController.cycle_images()."""
    if not ENABLED:
        return

    jitter = int(tick_enter_ms - intended_ms)
    ti = TickInfo(
        seq=int(seq),
        beat_index=int(beat_index),
        cycle_interval_ms=int(cycle_interval_ms),
        intended_ms=int(intended_ms),
        tick_enter_ms=int(tick_enter_ms),
        tick_enter_ns=int(tick_enter_ns),
        mode=str(mode),
        action=str(action),
        path=str(path or ""),
        ready_state=str(ready_state or ""),
    )
    with _lock:
        _tick_by_seq[ti.seq] = ti
        # keep dict bounded
        if len(_tick_by_seq) > 10_000:
            for k in sorted(_tick_by_seq.keys())[:1000]:
                _tick_by_seq.pop(k, None)

    logger.debug(
        "[Timing] tick seq=%d beat=%d iv=%dms intended=%dms enter=%dms jitter=%+dms mode=%s action=%s ready=%s path=%s",
        ti.seq,
        ti.beat_index,
        ti.cycle_interval_ms,
        ti.intended_ms,
        ti.tick_enter_ms,
        jitter,
        ti.mode,
        ti.action,
        ti.ready_state,
        ti.path,
    )


def plan_commit(seq: int, path: str) -> None:
    """Called when a tick decides to advance to `path`.

    We correlate this with the subsequent first paint.
    """
    if not ENABLED:
        return
    p = str(path or "")
    if not p:
        return
    now_ns = int(time.monotonic_ns())
    with _lock:
        _planned_seq_by_path[p] = int(seq)
        _planned_at_ns_by_seq[int(seq)] = now_ns


def mark_show_called(path: str) -> None:
    if not ENABLED:
        return
    p = str(path or "")
    if not p:
        return
    with _lock:
        _show_called_ns[p] = int(time.monotonic_ns())


def mark_image_loaded(path: str) -> None:
    if not ENABLED:
        return
    p = str(path or "")
    if not p:
        return
    with _lock:
        _image_loaded_ns[p] = int(time.monotonic_ns())


def mark_set_called(path: str | None) -> None:
    """Called on the GUI thread immediately before setting a new pixmap/movie."""
    if not ENABLED:
        return
    p = str(path or "")
    if not p:
        return
    with _lock:
        _set_called_ns[p] = int(time.monotonic_ns())


def mark_paint(path: str | None) -> None:
    """Called from the widget paintEvent on the GUI thread."""
    if not ENABLED:
        return

    p = str(path or "")
    now_ns = int(time.monotonic_ns())

    with _lock:
        global _last_paint_ns, _last_paint_path
        _last_paint_ns = now_ns
        _last_paint_path = p or None

        if not p:
            return

        seq = _planned_seq_by_path.get(p)
        if not seq:
            return

        ti = _tick_by_seq.get(int(seq))
        set_ns = _set_called_ns.get(p)
        show_ns = _show_called_ns.get(p)
        load_ns = _image_loaded_ns.get(p)

        # Mark this plan as satisfied so later animation paints don't spam.
        _planned_seq_by_path.pop(p, None)

    # Logging happens outside the lock.
    dt_tick_ms = None
    if ti is not None and ti.tick_enter_ns:
        dt_tick_ms = (now_ns - int(ti.tick_enter_ns)) / 1_000_000.0
    dt_set_ms = None
    if set_ns is not None:
        dt_set_ms = (now_ns - int(set_ns)) / 1_000_000.0
    dt_show_ms = None
    if show_ns is not None:
        dt_show_ms = (now_ns - int(show_ns)) / 1_000_000.0
    dt_load_ms = None
    if load_ns is not None:
        dt_load_ms = (now_ns - int(load_ns)) / 1_000_000.0

    if ti is not None:
        logger.debug(
            "[Timing] paint seq=%d beat=%d path=%s dt_tick=%.1fms dt_set=%sms dt_loaded=%sms dt_show=%sms",
            int(seq),
            int(ti.beat_index),
            p,
            (dt_tick_ms if dt_tick_ms is not None else -1.0),
            (f"{dt_set_ms:.1f}" if dt_set_ms is not None else "-"),
            (f"{dt_load_ms:.1f}" if dt_load_ms is not None else "-"),
            (f"{dt_show_ms:.1f}" if dt_show_ms is not None else "-"),
        )
    elif INFO:
        logger.debug("[Timing] paint path=%s", p)


def last_paint() -> tuple[int | None, str | None]:
    """Return (monotonic_ns, path) for the most recent paintEvent."""
    with _lock:
        return _last_paint_ns, _last_paint_path
