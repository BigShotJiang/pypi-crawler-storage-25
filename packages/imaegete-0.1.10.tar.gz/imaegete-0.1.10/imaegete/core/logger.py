import logging
import os
import sys
import threading

from imaegete.core import config


_configured_loggers = {}
_configuration_lock = threading.RLock()


class _LoggerProxy:
    """Logger-like proxy that resolves the caller's module at call time."""

    def __getattr__(self, name):
        dynamic_logger = get_dynamic_logger(stacklevel=3)
        return getattr(dynamic_logger, name)

    def debug(self, msg, *args, **kwargs):
        return _call_logger_method("debug", msg, *args, **kwargs)

    def info(self, msg, *args, **kwargs):
        return _call_logger_method("info", msg, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        return _call_logger_method("warning", msg, *args, **kwargs)

    def warn(self, msg, *args, **kwargs):
        return _call_logger_method("warning", msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        return _call_logger_method("error", msg, *args, **kwargs)

    def exception(self, msg, *args, exc_info=True, **kwargs):
        return _call_logger_method("exception", msg, *args, exc_info=exc_info, **kwargs)

    def critical(self, msg, *args, **kwargs):
        return _call_logger_method("critical", msg, *args, **kwargs)

    def fatal(self, msg, *args, **kwargs):
        return _call_logger_method("fatal", msg, *args, **kwargs)

    def log(self, level, msg, *args, **kwargs):
        return _call_logger_method("log", level, msg, *args, **kwargs)

    def isEnabledFor(self, level):
        return get_dynamic_logger(stacklevel=3).isEnabledFor(level)

    def getEffectiveLevel(self):
        return get_dynamic_logger(stacklevel=3).getEffectiveLevel()


def _caller_module_name(stacklevel=2):
    """Return a caller module name without walking the full stack."""
    try:
        frame = sys._getframe(stacklevel)
    except ValueError:
        return "__main__"

    module_name = frame.f_globals.get("__name__")
    return module_name or "__main__"


def _log_level():
    return getattr(logging, str(config.log_level).upper(), logging.INFO)


def get_dynamic_logger(*, stacklevel=2):
    """
    Retrieve a logger for the calling module.

    The caller is resolved with sys._getframe() rather than inspect.stack(), so
    normal log calls do not allocate and inspect the full Python stack.
    """
    module_name = _caller_module_name(stacklevel)

    cached_logger = _configured_loggers.get(module_name)
    if cached_logger is not None:
        return cached_logger

    logger_instance = logging.getLogger(module_name)

    with _configuration_lock:
        cached_logger = _configured_loggers.get(module_name)
        if cached_logger is not None:
            return cached_logger

        if not getattr(logger_instance, "_imaegete_configured", False):
            configure_logger(logger_instance, module_name)
            logger_instance._imaegete_configured = True

        _configured_loggers[module_name] = logger_instance
        return logger_instance


def configure_logger(logger_instance, module_name):
    """
    Configure a logger with both file and console handlers.

    :param logging.Logger logger_instance: The logger instance to configure.
    :param str module_name: The name of the module for which the logger is being configured.
    """
    log_dir = config.log_dir
    log_file_path = os.path.join(log_dir, config.LOG_FILE_NAME)
    log_level = _log_level()

    logger_instance.setLevel(log_level)
    logger_instance.propagate = False

    os.makedirs(log_dir, exist_ok=True)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    existing_file_handler = None
    existing_console_handler = None
    for handler in logger_instance.handlers:
        if getattr(handler, "_imaegete_file_handler", False):
            existing_file_handler = handler
        elif getattr(handler, "_imaegete_console_handler", False):
            existing_console_handler = handler

    if existing_file_handler is None:
        file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
        file_handler._imaegete_file_handler = True
        file_handler.setFormatter(formatter)
        logger_instance.addHandler(file_handler)
    else:
        file_handler = existing_file_handler
        file_handler.setFormatter(formatter)
    file_handler.setLevel(log_level)

    if existing_console_handler is None:
        console_handler = logging.StreamHandler()
        console_handler._imaegete_console_handler = True
        console_handler.setFormatter(formatter)
        logger_instance.addHandler(console_handler)
    else:
        console_handler = existing_console_handler
        console_handler.setFormatter(formatter)
    console_handler.setLevel(log_level)

    logger_instance.debug("Logger configured for module: %s", module_name, stacklevel=2)


def _logging_kwargs(kwargs):
    adjusted = dict(kwargs)
    try:
        stacklevel = int(adjusted.get("stacklevel", 1))
    except (TypeError, ValueError):
        stacklevel = 1
    adjusted["stacklevel"] = stacklevel + 2
    return adjusted


def _call_logger_method(method_name, *args, **kwargs):
    dynamic_logger = get_dynamic_logger(stacklevel=4)
    return getattr(dynamic_logger, method_name)(*args, **_logging_kwargs(kwargs))


# Common logging methods are real module functions so `logger.debug(...)` avoids
# module __getattr__ on the hot path when callers import `imaegete.core.logger`
# as a module via `from imaegete.core import logger`.
def debug(msg, *args, **kwargs):
    return _call_logger_method("debug", msg, *args, **kwargs)


def info(msg, *args, **kwargs):
    return _call_logger_method("info", msg, *args, **kwargs)


def warning(msg, *args, **kwargs):
    return _call_logger_method("warning", msg, *args, **kwargs)


def warn(msg, *args, **kwargs):
    return _call_logger_method("warning", msg, *args, **kwargs)


def error(msg, *args, **kwargs):
    return _call_logger_method("error", msg, *args, **kwargs)


def exception(msg, *args, exc_info=True, **kwargs):
    return _call_logger_method("exception", msg, *args, exc_info=exc_info, **kwargs)


def critical(msg, *args, **kwargs):
    return _call_logger_method("critical", msg, *args, **kwargs)


def fatal(msg, *args, **kwargs):
    return _call_logger_method("fatal", msg, *args, **kwargs)


def log(level, msg, *args, **kwargs):
    return _call_logger_method("log", level, msg, *args, **kwargs)


def isEnabledFor(level):
    return get_dynamic_logger(stacklevel=3).isEnabledFor(level)


def getEffectiveLevel():
    return get_dynamic_logger(stacklevel=3).getEffectiveLevel()


def __getattr__(name):
    """
    Dynamically retrieve attributes from the caller module's logger instance.

    :param str name: The name of the attribute to retrieve.
    :return: The attribute of the logger.
    :rtype: Any
    """
    dynamic_logger = get_dynamic_logger(stacklevel=3)
    return getattr(dynamic_logger, name)


# Backwards-compatible object for `from imaegete.core.logger import logger`.
# It must not be a concrete logging.Logger, because that pins import-time calls
# to imaegete.core.logger forever.
logger = _LoggerProxy()

_initial_logger = get_dynamic_logger()
_initial_logger.debug(
    "Logging initialized with log file: %s and level: %s",
    config.LOG_FILE_NAME,
    logging.getLevelName(_initial_logger.level),
    stacklevel=1,
)
