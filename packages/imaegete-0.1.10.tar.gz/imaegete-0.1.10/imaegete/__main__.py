"""Run Imaegete as ``python -m imaegete``."""

from __future__ import annotations

from imaegete.cli import main


if __name__ == "__main__":
    main()
