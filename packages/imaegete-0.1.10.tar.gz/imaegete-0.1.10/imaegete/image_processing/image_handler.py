from PyQt6.QtCore import QObject
from os.path import dirname
from imaegete.core import config, logger
from imaegete.image_processing.data_management.file_operations import find_matching_directory


class ImageHandler(QObject):
    def __init__(self, data_service, thread_manager, image_list_manager, file_task_handler):
        super().__init__()
        self.data_service = data_service
        self.thread_manager = thread_manager
        self.image_list_manager = image_list_manager
        self.file_task_handler = file_task_handler
        self.delete_folders = config.delete_folders
        self.dest_folders = config.dest_folders
        self.start_dirs = config.start_dirs

    def move_or_delete_image(self, image_path, action_type, original_index=None, category=None):
        """
        Helper function to move or delete an image.
        Determines the correct source and destination directories based on action type.

        :param str image_path: The path to the image.
        :param str action_type: The action type ('move' or 'delete').
        :param int original_index:
        :param str category: The category to move the image to (required for 'move' action).
        :return: True when a file task was queued, otherwise False.
        :rtype: bool
        """
        start_dir = find_matching_directory(image_path, self.start_dirs)
        if not start_dir:
            logger.error(f"Start directory for image {image_path} not found.")
            return False

        image_dir = dirname(image_path)
        task_queued = False
        if action_type == 'delete':
            if original_index is None:
                dest_dir = image_dir
                source_dir = self.delete_folders.get(start_dir)
            else:
                dest_dir = self.delete_folders.get(start_dir)
                source_dir = image_dir
            if source_dir and dest_dir:
                self.file_task_handler.delete_image(image_path, source_dir, dest_dir)
                task_queued = True
            else:
                logger.error(f"Delete folder not configured for start directory {start_dir}")
        elif action_type == 'move' and category:
            category_folder = self.dest_folders.get(start_dir, {}).get(category)
            if original_index is None:
                dest_dir = image_dir
                source_dir = category_folder
            else:
                dest_dir = category_folder
                source_dir = image_dir
            if source_dir and dest_dir:
                self.file_task_handler.move_image(image_path, source_dir, dest_dir)
                task_queued = True
            else:
                logger.error(f"Destination folder not found for category {category} in directory {start_dir}")
        else:
            logger.error(f"Unsupported image action {action_type!r} for image {image_path}")

        if task_queued and original_index is not None:
            self.data_service.append_sorted_images((action_type, image_path, category, original_index))

        return task_queued

    def _restore_unmoved_image(self, image_path, original_index):
        self.image_list_manager.add_image_to_list(image_path, original_index)
        try:
            restored_index = self.data_service.get_index_for_image(image_path)
        except Exception:
            restored_index = None
        if restored_index is not None:
            self.data_service.set_current_index(restored_index)

    def move_current_image(self, category):
        """
        Move the current image to a category folder.
        """
        current_index, image_path = self.image_list_manager.pop_image()
        if image_path:
            moved = self.move_or_delete_image(image_path, 'move', original_index=current_index, category=category)
            if not moved:
                self._restore_unmoved_image(image_path, current_index)

    def delete_current_image(self):
        """
        Delete the current image by moving it to the delete folder.
        """
        current_index, image_path = self.image_list_manager.pop_image()
        if image_path:
            deleted = self.move_or_delete_image(image_path, 'delete', original_index=current_index)
            if not deleted:
                self._restore_unmoved_image(image_path, current_index)

    def undo_last_action(self):
        """
        Undo the last move or delete action.
        """
        last_action = self.data_service.pop_sorted_images()
        if last_action:
            action_type, image_path, *rest = last_action
            original_index = rest[-1]
            restored = False
            if action_type == 'delete':
                restored = self.move_or_delete_image(image_path, 'delete')
            elif action_type == 'move':
                category = rest[0]
                restored = self.move_or_delete_image(image_path, 'move', category=category)

            if not restored:
                return {
                    'action': last_action,
                    'restored_path': None,
                    'restored_index': None,
                }

            # Restore the path into the list at (approximately) its prior index.
            # NOTE: list.insert() clamps indices > len(list) to the end, so we
            # must compute the *actual* restored index before setting current.
            self.image_list_manager.add_image_to_list(image_path, original_index)
            try:
                restored_index = self.data_service.get_index_for_image(image_path)
            except Exception:
                restored_index = None

            if restored_index is not None:
                self.data_service.set_current_index(restored_index)

            return {
                'action': last_action,
                'restored_path': image_path,
                'restored_index': restored_index,
            }
