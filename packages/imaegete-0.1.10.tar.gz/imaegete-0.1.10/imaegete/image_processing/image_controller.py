import os
import time
import statistics
from PyQt6.QtCore import QObject, QTimer, pyqtSignal, Qt, QElapsedTimer
from PyQt6.QtGui import QImage
from glavnaqt.events.bus import create_or_get_shared_event_bus
from imaegete.core import logger
from imaegete.core.path_utils import normalize_path
from imaegete.core import timing_probe


HOLD_DEBUG = os.environ.get("IMAEGETE_HOLD_DEBUG", "").strip().lower() in ("1", "true", "yes", "on")


class ImageController(QObject):
    image_loaded = pyqtSignal(str, object)
    image_cleared = pyqtSignal()
    image_ready = pyqtSignal(str, object)
    MIN_INTERVAL = 30  # ms – protects against auto‑repeat flood
    DEFAULT_CYCLE_INTERVAL = 3000
    TAP_TIMEOUT = 60000
    TAP_TOLERANCE = 0.02  # 2%: taps within this band re-phase without changing BPM

    # Deterministic tap-tempo session state machine.
    #
    # Semantics:
    #   - First tap ALWAYS starts a new tap session (clears history).
    #   - We collect a bounded number of taps (3–5) or a bounded window (~4s).
    #   - Until the session is "locked", we DO NOT mutate the slideshow interval.
    #   - Once stable enough, we atomically commit: set new interval + phase anchor
    #     at the last tap time.
    TAP_SESSION_MAX_MS = 4000
    TAP_SESSION_MAX_TAPS = 5
    TAP_SESSION_LOCK_TAPS = 3  # >=2 intervals
    TAP_SESSION_LOCK_MAX_SPREAD = 0.20  # (max-min)/median must be <= this
    TAP_SESSION_IDLE_GAP_MS = 2500  # gap between taps that restarts the session
    TAP_SESSION_POST_COMMIT_MS = 1500  # brief phase-nudge window after commit
    TAP_SESSION_POST_COMMIT_NUDGES = 2
    PREFETCH_MIN = 8
    PREFETCH_MAX = 64
    FAILED_COOLDOWN_MS = 30000  # skip failed images for this long
    HOLD_LOG_EVERY = 16  # beats
    HOLD_SKIP_AFTER = 64  # beats before we temporarily skip an unready slide
    HOLD_MAX_MS = 5000  # max wall-clock hold before skip in cache-only mode

    def __init__(self, image_list_manager, image_loader, image_handler):
        super().__init__()
        self.image_list_manager = image_list_manager
        self.image_loader = image_loader
        self.image_handler = image_handler
        self.current_displayed_image = None
        self.loading_images = set()  # Track currently loading images
        self.event_bus = create_or_get_shared_event_bus()
        self.event_bus.subscribe("frame_rendered", self._on_frame_rendered)
        self.image_ready.connect(self.send_image_to_display)
        self.image_list_manager.image_list_updated.connect(self.on_image_list_updated)
        self.last_cycle_type = 'next'  # Default cycle type is next
        self.cycle_interval = self.DEFAULT_CYCLE_INTERVAL
        self.tap_clock = QElapsedTimer()      # ← NEW
        self.tap_clock.start()                # ← NEW

        # Tap-tempo state machine (deterministic retap behavior).
        #
        # States:
        #   - 'idle': no active session.
        #   - 'collect': collecting taps for a new tempo.
        #   - 'locked': tempo committed; brief window for phase nudges.
        self._tap_state: str = 'idle'
        self._tap_cycle_type: str | None = None
        self._tap_session_start_ms: int = 0
        self._tap_taps_ms: list[int] = []
        self._tap_last_ms: int = 0
        self._tap_last_event_ms: int = 0  # debounce guard
        self._tap_committed_interval_ms: int = 0
        self._tap_nudge_deadline_ms: int = 0
        self._tap_nudges_left: int = 0
        self.timer = QTimer(self)
        self.timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.timer.setSingleShot(True)              # ← reschedule every tick                NEW
        self.timer_running = False
        self.timer.timeout.connect(self.cycle_images)
        self.anchor = QElapsedTimer()   # zero-point set by first tap
        self.anchor.start()
        self.tap_timer = QTimer(self)  # Safety: expire tap sessions after inactivity
        self.tap_timer.setSingleShot(True)
        self.tap_timer.timeout.connect(self.reset_tap_times)
        self._shown_images: set[str] = set()
        self._blocked_until: dict[str, int] = {}
        self._hold_beats = 0
        self._hold_path = None
        self._load_tokens: dict[str, int] = {}
        self._cycle_mode: str = 'sequential'
        self.image_list_manager.data_service.cache_manager.image_load_failed.connect(self._on_load_failed)
        self.image_list_manager.data_service.cache_manager.request_display_update.connect(
            self._on_cache_request_display_update
        )
        self.event_bus.subscribe('current_image_changed', self._on_current_image_changed)
        self.event_bus.subscribe('no_images', self._on_no_images)

        self._last_slide_path = None

        # Timing instrumentation (opt-in via IMAEGETE_TIMING=1)
        self._tick_seq = 0
        self._next_beat_target_ms = 0
        self._next_beat_index = 0
        self._last_tick_enter_ns: int | None = None
        self._last_tick_seq: int = 0

        # Slideshow best-effort mode: keep timing sacred (do not block on disk).
        # If the next image is not already cached when the tick fires, we hold.
        self._slideshow_cache_only = True

    # ------------------------------------------------------------------
    # Cache + prefetch helpers
    # ------------------------------------------------------------------
    def _cache_manager(self):
        return getattr(self.image_list_manager.data_service, "cache_manager", None)

    def _is_slide_ready(self, image_path: str) -> bool:
        """True if we can display without starting a disk load on the tick."""
        if not image_path:
            return False
        image_path = normalize_path(image_path) or image_path
        # GIFs are currently displayed by passing the path to QMovie.
        # That still touches disk at display-time, so treat them as "ready"
        # (no cache-backed predecode yet).
        if image_path.lower().endswith(".gif"):
            return os.path.exists(image_path)

        cm = self._cache_manager()
        if not cm:
            return False
        try:
            return cm.is_cached(image_path)
        except Exception:
            return False

    def _prefetch_paths(self, paths: list[str], *, force: bool = False) -> None:
        cm = self._cache_manager()
        if not cm or not paths:
            return

        # Avoid prefetch storms when the cache is already near its byte budget.
        # IMPORTANT: do *not* apply this guard to the *immediate next* candidate
        # in cache-only slideshow mode; that path must still be requested so the
        # slideshow can make progress (CacheManager will evict LRU if needed).
        if not force:
            try:
                used = int(getattr(cm, "cache_used_bytes", 0) or 0)
                limit = int(getattr(cm, "cache_limit_bytes", 0) or 0)
                if limit and used >= int(limit * 0.92):
                    return
            except Exception:
                pass

        for p in paths:
            if not p:
                continue
            p = normalize_path(p) or p
            if p.lower().endswith(".gif"):
                continue
            try:
                if cm.is_cached(p):
                    continue
                # active_request=True prevents duplicate enqueues when already loading
                cm.retrieve_image(p, active_request=True, background=True)
            except Exception:
                continue

    def _prefetch_target_count(self) -> int:
        """Heuristic window size that grows as the interval shrinks."""
        iv = max(1, int(self.cycle_interval))
        # Roughly keep ~3 seconds of headroom, with a sane cap.
        target = int(3000 / iv) + 8
        return max(self.PREFETCH_MIN, min(self.PREFETCH_MAX, target))

    def _upcoming_sequential_paths(self, count: int) -> list[str]:
        ds = self.image_list_manager.data_service
        images = ds.get_image_list()
        if not images:
            return []

        cur_idx = ds.get_current_index() or 0
        n = len(images)
        out: list[str] = []

        # Prefer truly-unseen items first.
        for step in range(1, n + 1):
            cand = images[(cur_idx + step) % n]
            if cand == ds.get_current_image_path():
                continue
            if cand in self._shown_images:
                continue
            out.append(cand)
            if len(out) >= count:
                return out

        # If everything is "shown", prefetch from the natural order anyway.
        for step in range(1, n + 1):
            cand = images[(cur_idx + step) % n]
            if cand == ds.get_current_image_path():
                continue
            out.append(cand)
            if len(out) >= count:
                break
        return out

    def _upcoming_random_paths(self, count: int) -> list[str]:
        ds = self.image_list_manager.data_service
        images = ds.get_image_list()
        if not images:
            return []

        # Peek some headroom; we don't want to copy the whole queue for huge lists.
        head = min(len(images), max(count * 4, 64))
        idxs = self.image_list_manager.peek_shuffled_indices(head)

        out: list[str] = []
        cur = ds.get_current_image_path()

        for idx in idxs:
            if idx < 0 or idx >= len(images):
                continue
            cand = images[idx]
            if cand == cur:
                continue
            if cand in self._shown_images:
                continue
            out.append(cand)
            if len(out) >= count:
                return out

        # Fallback: ignore _shown_images (cycle has likely wrapped)
        for idx in idxs:
            if idx < 0 or idx >= len(images):
                continue
            cand = images[idx]
            if cand == cur:
                continue
            out.append(cand)
            if len(out) >= count:
                break
        return out

    def _prefetch_slideshow_window(self) -> None:
        if not self.timer_running:
            return
        target = self._prefetch_target_count()
        if self._cycle_mode == "random":
            paths = self._upcoming_random_paths(target)
        else:
            paths = self._upcoming_sequential_paths(target)
        self._prefetch_paths(paths)


    def _prefetch_immediate_next_candidate(self) -> None:
        """Force-request the *next* candidate as soon as we know it.

        This is critical in cache-only (timing sacred) mode:
        if background prefetch is paused (e.g., near cache byte budget),
        requesting the next candidate only *on the beat* causes consistent
        2-beat quantization (hold one beat, advance the next). By forcing
        the immediate-next request right after an advance, we maximize the
        chance that it will be ready by the next beat.
        """
        if not self.timer_running or not self._slideshow_cache_only:
            return
        try:
            if self._cycle_mode == "random":
                peek = self._peek_next_unshown_random()
                if not peek:
                    return
                _pos, path, _reset = peek
            else:
                peek = self._peek_next_unshown_sequential()
                if not peek:
                    return
                _idx, path, _reset = peek
            if path:
                self._prefetch_paths([path], force=True)
        except Exception:
            return


    # ------------------------------------------------------------------
    # Best-effort slideshow tick
    # ------------------------------------------------------------------
    def _next_unshown_sequential_candidate(self):
        """Return (idx, path, reset_shown) without mutating state."""
        ds = self.image_list_manager.data_service
        images = ds.get_image_list()
        if not images:
            return None

        now_ms = self.tap_clock.elapsed()
        blocked = self._blocked_until

        cur_idx = ds.get_current_index() or 0
        n = len(images)

        # Prefer an unshown, unblocked image.
        for step in range(1, n + 1):
            idx = (cur_idx + step) % n
            cand = images[idx]
            if blocked.get(cand, 0) > now_ms:
                continue
            if cand not in self._shown_images:
                return idx, cand, False

        # Everything available was already shown: continue in sequence and reset
        # the shown tally only when the caller commits this candidate.
        for step in range(1, n + 1):
            idx = (cur_idx + step) % n
            cand = images[idx]
            if blocked.get(cand, 0) > now_ms:
                continue
            return idx, cand, True
        return None

    def _commit_next_unshown_sequential_candidate(self, idx, reset_shown=False):
        """Commit a sequential candidate returned by _next_unshown_sequential_candidate."""
        if reset_shown:
            self._shown_images.clear()

        ds = self.image_list_manager.data_service
        ds.set_current_index(idx)
        return ds.get_current_image_path()

    def _peek_next_unshown_sequential(self):
        """Return (idx, path, reset_shown) without mutating state."""
        return ImageController._next_unshown_sequential_candidate(self)

    def _peek_next_unshown_random(self):
        """Return (position_in_shuffle, path, reset_shown) without consuming."""
        ds = self.image_list_manager.data_service
        images = ds.get_image_list()
        if not images:
            return None

        now_ms = self.tap_clock.elapsed()
        blocked = self._blocked_until

        # Ensure shuffle queue exists and peek a reasonable prefix.
        head = min(len(images), 256)
        idxs = self.image_list_manager.peek_shuffled_indices(head)
        if not idxs:
            return None

        for pos, idx in enumerate(idxs):
            if idx < 0 or idx >= len(images):
                continue
            cand = images[idx]
            if blocked.get(cand, 0) > now_ms:
                continue
            if cand not in self._shown_images:
                return pos, cand, False

        # Everything shown: allow wrap; reset tally on commit.
        for pos, idx in enumerate(idxs):
            if idx < 0 or idx >= len(images):
                continue
            cand = images[idx]
            if blocked.get(cand, 0) > now_ms:
                continue
            return pos, cand, True
        return None

    def _on_load_failed(self, path, err):
        """Forward load-failure handling to the main GUI thread."""
        QTimer.singleShot(0, lambda p=path, e=err: self._handle_load_failed_gui(p, e))

    def _handle_load_failed_gui(self, path, err):
        """Runs on GUI thread: pick the next slide and re-sync the timer."""
        logger.debug("[ImageController] load-failed %s - %s", path, err)
        # only advance if the failed image was the one currently showing
        if path == self.image_list_manager.data_service.get_current_image_path():
            if self._cycle_mode == "random":
                self.random_image(manual=False)
            elif getattr(self, "last_cycle_type", None) == "previous":
                self.previous_image(manual=False)
            else:
                self.next_image(manual=False)
        # recompute drift-corrected timer if the slideshow is active
        self._schedule_next_tick()


    def _refresh_image_lists(self):
        """
        Trim _shown_images to whatever still exists after the manager
        refreshed its list (e.g. files were added / removed on disk).
        """
        images = set(self.image_list_manager.data_service.get_image_list())
        self._shown_images.intersection_update(images)
        # Drop blocked entries that no longer exist
        self._blocked_until = {p: t for p, t in self._blocked_until.items() if p in images}

    def _next_unshown_sequential(self):
        """
        Commit and return the next path selected by the sequential slideshow picker.

        This uses the same non-mutating primitive as cache-only slideshow peeking so
        manual/timer-driven sequential advances cannot drift from cache-only
        candidate selection rules.
        """
        candidate = ImageController._next_unshown_sequential_candidate(self)
        if not candidate:
            return None

        idx, path, reset = candidate
        committed = ImageController._commit_next_unshown_sequential_candidate(self, idx, reset)
        return committed or path


    def _next_unshown_random(self):
        ds = self.image_list_manager.data_service
        attempts = len(ds.get_image_list()) or 1
        while attempts:
            img = self.image_list_manager.set_random_image()
            if img not in self._shown_images:
                return img
            attempts -= 1
        self._shown_images.clear()
        return self.image_list_manager.set_random_image()

    def next_image(self, manual=True):
        """Advance to the next image (sequential)."""
        if manual:
            self.handle_manual_cycle('next')
            self._cycle_mode = 'sequential'

        if self.timer_running:
            image_path = self._next_unshown_sequential()
        else:
            image_path = self.image_list_manager.set_next_image()
        self.show_image(image_path)

    def previous_image(self, manual=True):
        """Handle the previous image cycle."""
        if manual:
            self.handle_manual_cycle('previous')  # Handle manual cycle and set rate
        self.last_cycle_type = 'previous'
        image_path = self.image_list_manager.set_previous_image()
        self.show_image(image_path)

    def random_image(self, manual=True):
        """Advance to a random, unseen image."""
        if manual:
            self.handle_manual_cycle('random')
            self._cycle_mode = 'random'

        if self.timer_running:
            image_path = self._next_unshown_random()
        else:
            image_path = self.image_list_manager.set_random_image()
        self.show_image(image_path)

    def handle_manual_cycle(self, current_cycle_type: str) -> None:
        """Tap-tempo (manual next/prev/random) while slideshow is running.

        This is intentionally deterministic:
        - First tap always starts a new "tap session" (history is cleared).
        - We collect a few taps and then commit the interval atomically.
        - After committing, we allow a short phase-nudge window.

        Instrumentation (when IMAEGETE_TIMING=1 or IMAEGETE_HOLD_DEBUG=1):
        - monotonic timestamps for arrival
        - dt between delivered tap events
        - session state and decision reason
        """
        if not self.timer_running:
            return

        now_ms = int(self.tap_clock.elapsed())
        now_ns = int(time.monotonic_ns())

        def _log(action: str, reason: str, *, dt_ms: int | None = None, cand_ms: int | None = None, spread: float | None = None):
            if not (timing_probe.is_enabled() or HOLD_DEBUG):
                return
            last_tick_age_ms = None
            if self._last_tick_enter_ns is not None:
                try:
                    last_tick_age_ms = (now_ns - int(self._last_tick_enter_ns)) / 1_000_000.0
                except Exception:
                    last_tick_age_ms = None
            paint_age_ms = None
            try:
                pns, _ppath = timing_probe.last_paint()
                if pns is not None:
                    paint_age_ms = (now_ns - int(pns)) / 1_000_000.0
            except Exception:
                paint_age_ms = None

            logger.debug(
                "[Timing] tap action=%s reason=%s type=%s state=%s now=%dms dt=%s cand=%s spread=%s iv=%dms last_tick_age=%sms last_paint_age=%sms taps=%d",
                action,
                reason,
                current_cycle_type,
                getattr(self, '_tap_state', 'idle'),
                now_ms,
                (dt_ms if dt_ms is not None else '-'),
                (cand_ms if cand_ms is not None else '-'),
                (f"{spread:.3f}" if spread is not None else '-'),
                int(getattr(self, 'cycle_interval', 0) or 0),
                (f"{last_tick_age_ms:.1f}" if last_tick_age_ms is not None else '-'),
                (f"{paint_age_ms:.1f}" if paint_age_ms is not None else '-'),
                len(getattr(self, '_tap_taps_ms', []) or []),
            )

        # Debounce (key auto-repeat can deliver floods under some setups)
        if self._tap_last_event_ms and (now_ms - self._tap_last_event_ms) < self.MIN_INTERVAL:
            _log('ignore', 'debounce', dt_ms=int(now_ms - self._tap_last_event_ms))
            return
        self._tap_last_event_ms = now_ms

        # Helper: start a brand-new session (history is cleared).
        def _start_session(start_reason: str):
            self._tap_state = 'collect'
            self._tap_cycle_type = current_cycle_type
            self._tap_session_start_ms = now_ms
            self._tap_taps_ms = [now_ms]
            self._tap_last_ms = now_ms
            self._tap_committed_interval_ms = 0
            self._tap_nudge_deadline_ms = 0
            self._tap_nudges_left = 0
            # Safety: if the user stops tapping, drop the session.
            try:
                self.tap_timer.start(int(self.TAP_SESSION_IDLE_GAP_MS))
            except Exception:
                pass
            _log('start', start_reason)

        st = getattr(self, '_tap_state', 'idle')

        # New session if idle or direction changed.
        if st == 'idle' or (self._tap_cycle_type is not None and current_cycle_type != self._tap_cycle_type):
            _start_session('new_session')
            return

        # Session timeout: if the user waited too long between taps, restart clean.
        if self._tap_last_ms and (now_ms - self._tap_last_ms) > int(self.TAP_SESSION_IDLE_GAP_MS):
            _start_session('gap_restart')
            return

        # LOCKED: short phase-nudge window, otherwise a new session.
        if st == 'locked':
            dt = int(now_ms - (self._tap_last_ms or now_ms))
            cur_iv = int(self.cycle_interval) if self.cycle_interval else 0

            if (
                cur_iv > 0
                and now_ms <= int(self._tap_nudge_deadline_ms or 0)
                and int(self._tap_nudges_left or 0) > 0
            ):
                try:
                    rel = abs(dt - cur_iv) / float(cur_iv)
                except Exception:
                    rel = 1.0
                if rel <= float(self.TAP_TOLERANCE):
                    # Phase nudge only.
                    self._tap_last_ms = now_ms
                    self._tap_taps_ms.append(now_ms)
                    self._tap_taps_ms = self._tap_taps_ms[-self.TAP_SESSION_MAX_TAPS:]
                    self._tap_nudges_left = int(self._tap_nudges_left) - 1

                    self.anchor.restart()
                    self._prefetch_slideshow_window()
                    self._prefetch_immediate_next_candidate()
                    self._schedule_next_tick()

                    # Extend the nudge window slightly while the user is actively nudging.
                    self._tap_nudge_deadline_ms = now_ms + int(self.TAP_SESSION_POST_COMMIT_MS)
                    try:
                        self.tap_timer.start(int(self.TAP_SESSION_POST_COMMIT_MS))
                    except Exception:
                        pass

                    _log('nudge', 'phase_only', dt_ms=dt)

                    if self._tap_nudges_left <= 0:
                        # End session deterministically; further taps start a new session.
                        self._tap_state = 'idle'
                    return

            # Outside the nudge window / too different: start a new session.
            _start_session('locked_to_new_session')
            return

        # COLLECT: append tap and compute candidate.
        if st != 'collect':
            _start_session('state_repair')
            return

        self._tap_taps_ms.append(now_ms)
        self._tap_taps_ms = self._tap_taps_ms[-self.TAP_SESSION_MAX_TAPS:]
        dt = int(now_ms - (self._tap_last_ms or now_ms))
        self._tap_last_ms = now_ms

        # Safety: keep the session alive while tapping.
        try:
            self.tap_timer.start(int(self.TAP_SESSION_IDLE_GAP_MS))
        except Exception:
            pass

        if len(self._tap_taps_ms) < 2:
            _log('collect', 'need_more_taps', dt_ms=dt)
            return

        intervals = [
            int(self._tap_taps_ms[i] - self._tap_taps_ms[i - 1])
            for i in range(1, len(self._tap_taps_ms))
        ]
        if not intervals:
            _log('collect', 'no_intervals', dt_ms=dt)
            return

        try:
            cand = int(round(statistics.median(intervals)))
        except Exception:
            cand = int(intervals[-1])
        cand = max(int(cand), int(self.MIN_INTERVAL))

        spread = None
        if len(intervals) >= 2 and cand > 0:
            try:
                spread = (max(intervals) - min(intervals)) / float(cand)
            except Exception:
                spread = None

        stable_enough = (
            len(self._tap_taps_ms) >= int(self.TAP_SESSION_LOCK_TAPS)
            and (spread is None or spread <= float(self.TAP_SESSION_LOCK_MAX_SPREAD))
        )

        timeout = (now_ms - int(self._tap_session_start_ms or now_ms)) >= int(self.TAP_SESSION_MAX_MS)
        maxed = len(self._tap_taps_ms) >= int(self.TAP_SESSION_MAX_TAPS)

        if stable_enough or timeout or maxed:
            # Commit atomically: interval + phase anchor at this tap.
            self._tap_committed_interval_ms = cand
            self._tap_state = 'locked'
            self._tap_nudge_deadline_ms = now_ms + int(self.TAP_SESSION_POST_COMMIT_MS)
            self._tap_nudges_left = int(self.TAP_SESSION_POST_COMMIT_NUDGES)

            self.update_cycle_rate(cand)

            try:
                self.tap_timer.start(int(self.TAP_SESSION_POST_COMMIT_MS))
            except Exception:
                pass

            _log('commit', 'locked' if stable_enough else ('timeout' if timeout else 'max_taps'), dt_ms=dt, cand_ms=cand, spread=spread)
            return

        _log('collect', 'collecting', dt_ms=dt, cand_ms=cand, spread=spread)

    def reset_tap_times(self):
        """Expire any active tap-tempo session.

        This is a safety net for when the user stops tapping mid-session. It
        must not affect the slideshow cadence beyond tap-tempo itself.
        """
        self._tap_state = 'idle'
        self._tap_cycle_type = None
        self._tap_session_start_ms = 0
        self._tap_taps_ms = []
        self._tap_last_ms = 0
        self._tap_committed_interval_ms = 0
        self._tap_nudge_deadline_ms = 0
        self._tap_nudges_left = 0

    def start_slideshow(self):
        """Start the timer for automatic cycling."""
        if not self.timer_running:
            # reset shuffle indices if starting in random mode
            if self._cycle_mode == 'random':
                self.image_list_manager._shuffled_indices.clear()
            # Reset tally and prime with current image (if any)
            self._shown_images.clear()
            self._blocked_until.clear()
            self._hold_beats = 0
            self._hold_path = None

            # Tap-tempo: start clean on each slideshow run.
            self.reset_tap_times()

            cur = self.image_list_manager.data_service.get_current_image_path()
            if cur:
                self._shown_images.add(cur)

            self.anchor.restart()
            if not self.image_list_manager.data_service.get_image_list():
                logger.warning("[ImageController] start_slideshow: no images to show")
                self.event_bus.emit("no_images")   # your UI can listen for this
                return

            self.timer_running = True
            # Prime cache ahead of the first beat.
            self._prefetch_slideshow_window()
            self._prefetch_immediate_next_candidate()
            self._schedule_next_tick()

    def stop_slideshow(self):
        """Stop the timer, pause the slideshow, and reset the cycling rate to the default."""
        if self.timer_running:
            self.timer.stop()
            self.timer_running = False
            self.cycle_interval = self.DEFAULT_CYCLE_INTERVAL
            # Tap-tempo: stop clean so a new run starts fresh.
            self.reset_tap_times()

    def toggle_slideshow(self):
        """Toggle between start and stop for the slideshow."""
        if self.timer_running:
            self.stop_slideshow()
        else:
            self.start_slideshow()

    def show_image(self, image_path=None):
        # Normalize early to keep cache keys stable.
        if image_path:
            image_path = normalize_path(image_path) or image_path

        if image_path in self.loading_images:
            return

        ds = self.image_list_manager.data_service

        # If no path given, grab current from the data service.
        if not image_path:
            image_path = ds.get_current_image_path()
            if image_path:
                image_path = normalize_path(image_path) or image_path

        # Nothing to show: if the list is empty, clear the display.
        if not image_path:
            if not ds.get_image_list():
                self._emit_image_cleared()
            return

        images = ds.get_image_list()
        in_list = image_path in images
        if not in_list:
            logger.debug("[ImageController] show_image: %s no longer in list", image_path)
            # Startup edge-case: on initial refresh, the list may still be empty
            # even though we were launched with an explicit image_path.
            if not images and os.path.isfile(image_path):
                pass  # allow optimistic first display before the scan flushes
            elif not images:
                self._emit_image_cleared()
                return
            else:
                cur = ds.get_current_image_path()
                if cur:
                    cur = normalize_path(cur) or cur
                if cur and cur in images and cur != image_path:
                    # avoid recursion loops
                    image_path = cur
                else:
                    return

        # Timing probe: mark that we're about to enqueue work for this path.
        if timing_probe.ENABLED:
            try:
                timing_probe.mark_show_called(image_path)
            except Exception:
                pass

        load_tokens = getattr(self, "_load_tokens", None)
        if load_tokens is None:
            load_tokens = {}
            self._load_tokens = load_tokens
        load_token = int(load_tokens.get(image_path, 0) or 0) + 1
        load_tokens[image_path] = load_token

        def display_callback(image):
            try:
                self.loading_images.discard(image_path)

                tokens = getattr(self, "_load_tokens", {})
                if tokens.get(image_path) != load_token:
                    logger.debug(
                        "[ImageController] stale display-callback for %s – ignoring",
                        image_path,
                    )
                    return
                tokens.pop(image_path, None)

                if image:
                    cur = ds.get_current_image_path() or image_path
                    if cur:
                        cur = normalize_path(cur) or cur

                    if cur and cur != image_path:
                        logger.debug(
                            "[ImageController] display-callback for %s arrived after current image changed to %s – ignoring",
                            image_path,
                            cur,
                        )
                        return

                    if timing_probe.ENABLED:
                        try:
                            timing_probe.mark_image_loaded(image_path)
                        except Exception:
                            pass

                    self.image_loaded.emit(image_path, image)
                    self.current_displayed_image = image_path
                    if self.timer_running:
                        self._shown_images.add(image_path)
                else:
                    logger.debug(
                        "[ImageController] display-callback got <None> for %s – skipping",
                        image_path,
                    )
            except Exception as e:
                logger.error(f"[ImageController] Exception in display_callback: {e}", exc_info=True)

        self.loading_images.add(image_path)
        runnable = self.image_loader.load_image_async(image_path, display_callback)
        if runnable is None:
            self.loading_images.discard(image_path)
            tokens = getattr(self, "_load_tokens", None)
            if tokens is not None and tokens.get(image_path) == load_token:
                tokens.pop(image_path, None)

    def first_image(self):
        image_path = self.image_list_manager.set_first_image()
        self.show_image(image_path)

    def last_image(self):
        image_path = self.image_list_manager.set_last_image()
        self.show_image(image_path)

    def send_image_to_display(self, image_path, image):
        # Avoid forcing every QImage into a QPixmap (preserves alpha channels)
        if isinstance(image, QImage):
           self.image_loaded.emit(image_path, image)
        else:
            # e.g. some loaders might yield raw QPixmap or QMovie
            self.image_loaded.emit(image_path, image)
        self._hide_busy_indicator()

    def move_image(self, category):
        self.image_handler.move_current_image(category)
        self.show_image()

    def delete_image(self):
        self.image_handler.delete_current_image()
        self.show_image()

    def undo_last_action(self):
        result = self.image_handler.undo_last_action()
        if not result:
            return

        # Keep UI counters in sync immediately.
        self.event_bus.emit('update_image_total')

        restored_path = None
        if isinstance(result, dict):
            restored_path = result.get('restored_path')
        elif isinstance(result, (tuple, list)) and len(result) >= 2:
            restored_path = result[1]

        # Switch to (and attempt to display) the restored item. If the file move
        # completes slightly later, CacheManager will emit request_display_update
        # and we will redraw.
        if restored_path:
            self.event_bus.emit('current_image_changed', image_path=restored_path)
            self.show_image(restored_path)
        else:
            self.show_image()

    def on_image_list_updated(self):
        """
        """
        self.event_bus.emit("update_image_total")
        if self.current_displayed_image is None:
            self._refresh_image_lists()
            image_path = (
                self.image_list_manager.data_service.get_current_image_path()
            )
            if image_path:
                self.current_displayed_image = image_path          # prevent re‑entry
                self.show_image(image_path)                        # display it
            else:
                # List is empty; clear the display.
                self._emit_image_cleared()
                logger.error(
                    "[ImageController] Could not get current image from data service."
                )


    def _hide_busy_indicator(self):
        if not self.image_list_manager.refreshing:
            self.event_bus.emit('hide_busy')

    def shutdown(self):
        """
        Shutdown the ImageController safely.
        """
        self.image_list_manager.image_list_open_condition.wakeAll()

    def increase_slideshow_speed(self, step: int = 300):
        """
        Speed up the slideshow by decreasing the cycle interval.

        Uses a dynamic step (~10% of the current interval, capped by `step`) to
        avoid the 300ms→30ms 'warp-speed' cliff when the interval gets small.
        """
        dyn = max(10, int(self.cycle_interval * 0.10))
        delta = min(step, dyn)
        new_iv = max(self.MIN_INTERVAL, self.cycle_interval - delta)
        self.update_cycle_rate(new_iv)

    def decrease_slideshow_speed(self, step: int = 300):
        """
        Slow down the slideshow by increasing the cycle interval.

        Uses the same dynamic step logic as increase_slideshow_speed() so speed
        changes remain smooth across the full range.
        """
        dyn = max(10, int(self.cycle_interval * 0.10))
        delta = min(step, dyn)
        new_iv = self.cycle_interval + delta
        self.update_cycle_rate(new_iv)

    def _schedule_next_tick(self):
        """
        Start the single-shot timer for the *next* beat boundary.

        We anchor beats to a monotonic clock (QElapsedTimer). We do not trust
        QTimer to be perfectly accurate under load, so each reschedule computes
        the next beat target from the anchor clock.

        Key detail:
        - Never schedule a 0ms (or near-0ms) timeout. Qt explicitly warns that
          keeping the event loop busy with a zero-timer causes erratic UI
          behavior; and "catch-up bursts" feel like a tempo speed-up.
        - If we're within MIN_LEAD_MS of the next boundary, we intentionally
          skip to the following beat.
        """
        if not self.timer_running:
            return

        self.timer.stop()

        iv = max(1, int(self.cycle_interval))
        elapsed = int(self.anchor.elapsed())

        # Ensure the next tick is at least this far in the future.
        MIN_LEAD_MS = 5

        # Compute the next beat number using a ceil so target >= elapsed + MIN_LEAD_MS.
        next_beat = (elapsed + MIN_LEAD_MS + iv - 1) // iv
        target = int(next_beat * iv)

        # Timing probe: remember what we *intend* to hit for the upcoming tick.
        self._next_beat_target_ms = target
        self._next_beat_index = int(next_beat)

        delay = int(target - elapsed)
        if delay < MIN_LEAD_MS:
            delay = MIN_LEAD_MS

        self.timer.start(delay)

    def _on_frame_rendered(self, *args, **kwargs):
        """
        Slot fired by ImageDisplay when a frame has been painted.
        We keep this hook for bookkeeping/debug, but the cadence is now
        driven solely by the anchor clock. (Best-effort mode must keep
        ticking even when we hold and no new frame is rendered.)
        """
        if self.current_displayed_image != self._last_slide_path:
            self._last_slide_path = self.current_displayed_image

    def cycle_images(self):
        """Advance one slide.


        Best-effort mode: timing is sacred; images are best-effort.

        If the next image isn't already cached when the tick fires, we hold and

        try again on the next beat (or temporarily skip it).

        """
        try:
            if not self.timer_running:
                return

            # Capture beat scheduling data (monotonic via QElapsedTimer).
            # Even when the full timing probe is disabled, these values are useful
            # for optional hold debugging.
            intended_ms = int(getattr(self, '_next_beat_target_ms', 0) or 0)
            beat_index = int(getattr(self, '_next_beat_index', 0) or 0)
            tick_enter_ms = int(self.anchor.elapsed())

            # Capture monotonic tick entry time regardless of probe enablement.
            # (Useful to correlate tap events with tick cadence.)
            tick_seq = None
            tick_enter_ns = int(time.monotonic_ns())
            if timing_probe.ENABLED:
                self._tick_seq += 1
                tick_seq = self._tick_seq

            self._last_tick_enter_ns = tick_enter_ns
            self._last_tick_seq = int(tick_seq or self._tick_seq or 0)

            # Keep the cache filled with upcoming candidates.
            self._prefetch_slideshow_window()

            # If an image load is still in-flight, don't stack more requests.
            # This will *look like* quantization to N beats when the tempo is faster
            # than the (decode->convert->paint) pipeline can complete.
            if self.loading_images:
                inflight_paths = tuple(sorted(str(p) for p in self.loading_images if p))
                hold_key = ("inflight", inflight_paths)
                if getattr(self, "_hold_path", None) != hold_key:
                    self._hold_path = hold_key
                    self._hold_beats = 0
                self._hold_beats += 1

                if HOLD_DEBUG:
                    jitter = int(tick_enter_ms - intended_ms)
                    logger.debug(
                        "[ImageController] tick hold (inflight/%s): beat=%d intended=%dms enter=%dms jitter=%+dms inflight=%d hold_beats=%d",
                        self._cycle_mode,
                        beat_index,
                        intended_ms,
                        tick_enter_ms,
                        jitter,
                        len(self.loading_images),
                        self._hold_beats,
                    )

                if self._hold_beats % self.HOLD_LOG_EVERY == 0:
                    logger.warning(
                        "[ImageController] slideshow hold (inflight/%s): %d load(s) still in flight after %d beats: %s",
                        self._cycle_mode,
                        len(self.loading_images),
                        self._hold_beats,
                        ", ".join(inflight_paths),
                    )

                if self._hold_beats >= self.HOLD_SKIP_AFTER:
                    stuck_paths = set(self.loading_images)
                    try:
                        now_ms = self.tap_clock.elapsed()
                        for stuck_path in stuck_paths:
                            self._blocked_until[stuck_path] = now_ms + self.FAILED_COOLDOWN_MS
                    except Exception:
                        pass

                    tokens = getattr(self, "_load_tokens", None)
                    if tokens is not None:
                        for stuck_path in stuck_paths:
                            tokens[stuck_path] = int(tokens.get(stuck_path, 0) or 0) + 1

                    self.loading_images.difference_update(stuck_paths)
                    logger.warning(
                        "[ImageController] slideshow skip (inflight/%s): %d load(s) still in flight after %d beats; clearing markers and skipping for %dms: %s",
                        self._cycle_mode,
                        len(stuck_paths),
                        self._hold_beats,
                        self.FAILED_COOLDOWN_MS,
                        ", ".join(inflight_paths),
                    )
                    self._hold_path = None
                    self._hold_beats = 0

                if timing_probe.ENABLED and tick_seq is not None:
                    try:
                        cur = self.image_list_manager.data_service.get_current_image_path() or ""
                    except Exception:
                        cur = ""
                    timing_probe.record_tick(
                        seq=tick_seq,
                        beat_index=beat_index or 0,
                        cycle_interval_ms=int(self.cycle_interval),
                        intended_ms=intended_ms or 0,
                        tick_enter_ms=int(tick_enter_ms or 0),
                        tick_enter_ns=int(tick_enter_ns or 0),
                        mode=str(self._cycle_mode),
                        action='inflight',
                        path=cur,
                        ready_state=f'inflight:{len(inflight_paths)}',
                    )
                return

            # Legacy mode: advance regardless of cache state.
            if not self._slideshow_cache_only:
                if self._cycle_mode == "random":
                    self.random_image(manual=False)
                else:
                    self.next_image(manual=False)
                return

            # Determine the next candidate without mutating state.
            mode_label = "sequential"
            pos = None
            idx = None
            if self._cycle_mode == "random":
                mode_label = "random"
                peek = self._peek_next_unshown_random()
                if not peek:
                    return
                pos, path, reset = peek
            else:
                peek = self._peek_next_unshown_sequential()
                if not peek:
                    return
                idx, path, reset = peek

            # Cache-only gating: if not ready on the beat, hold (and maybe skip).
            if not self._is_slide_ready(path):
                self._prefetch_paths([path], force=True)

                if getattr(self, "_hold_path", None) != path:
                    self._hold_path = path
                    self._hold_beats = 0
                self._hold_beats += 1

                if HOLD_DEBUG:
                    jitter = int(tick_enter_ms - intended_ms)
                    logger.debug(
                        "[ImageController] tick hold (not_ready/%s): beat=%d intended=%dms enter=%dms jitter=%+dms path=%s",
                        mode_label,
                        beat_index,
                        intended_ms,
                        tick_enter_ms,
                        jitter,
                        path,
                    )

                if self._hold_beats % self.HOLD_LOG_EVERY == 0:
                    logger.warning(
                        "[ImageController] slideshow hold (%s): next not ready after %d beats: %s",
                        mode_label,
                        self._hold_beats,
                        path,
                    )

                if self._hold_beats >= self.HOLD_SKIP_AFTER:
                    try:
                        now_ms = self.tap_clock.elapsed()
                        self._blocked_until[path] = now_ms + self.FAILED_COOLDOWN_MS
                    except Exception:
                        pass

                    if mode_label == "random" and pos is not None:
                        # push the blocked candidate to the end so we can keep moving
                        try:
                            self.image_list_manager.defer_shuffled_index(pos)
                        except Exception:
                            pass

                    logger.warning(
                        "[ImageController] slideshow skip (%s): %s not ready after %d beats; skipping for %dms",
                        mode_label,
                        path,
                        self._hold_beats,
                        self.FAILED_COOLDOWN_MS,
                    )
                    self._hold_path = None
                    self._hold_beats = 0

                if timing_probe.ENABLED and tick_seq is not None:
                    cm = self._cache_manager()
                    state = None
                    if cm and hasattr(cm, 'get_request_state_summary'):
                        try:
                            state = cm.get_request_state_summary(path)
                        except Exception:
                            state = None
                    timing_probe.record_tick(
                        seq=tick_seq,
                        beat_index=beat_index or 0,
                        cycle_interval_ms=int(self.cycle_interval),
                        intended_ms=intended_ms or 0,
                        tick_enter_ms=int(tick_enter_ms or 0),
                        tick_enter_ns=int(tick_enter_ns or 0),
                        mode=mode_label,
                        action='hold',
                        path=path,
                        ready_state=state,
                    )

                return

            # Ready: commit selection and display.
            self._hold_path = None
            self._hold_beats = 0

            if mode_label == "random" and pos is not None:
                if reset:
                    self._shown_images.clear()
                chosen = self.image_list_manager.commit_shuffled_index(pos)
                if chosen:
                    path = chosen
            elif idx is not None:
                chosen = ImageController._commit_next_unshown_sequential_candidate(self, idx, reset)
                if chosen:
                    path = chosen

            if timing_probe.ENABLED and tick_seq is not None:
                timing_probe.record_tick(
                    seq=tick_seq,
                    beat_index=beat_index or 0,
                    cycle_interval_ms=int(self.cycle_interval),
                    intended_ms=intended_ms or 0,
                    tick_enter_ms=int(tick_enter_ms or 0),
                    tick_enter_ns=int(tick_enter_ns or 0),
                    mode=mode_label,
                    action='advance',
                    path=path,
                    ready_state='ready',
                )
                timing_probe.plan_commit(tick_seq, path)
            self.show_image(path)
            # Pre-arm the next candidate immediately for the upcoming beat.
            self._prefetch_immediate_next_candidate()

        except Exception as e:
            logger.error("[ImageController] Error during cycle_images: %s", e, exc_info=True)
        finally:
            # Cadence continues regardless of whether we advanced or held.
            self._schedule_next_tick()

    def update_cycle_rate(self, interval: int):
        """Called by tap-tempo: set a new interval and restart the clock."""
        self.cycle_interval = max(interval, self.MIN_INTERVAL)
        self.anchor.restart()           # phase-zero at *this* tap
        self._prefetch_slideshow_window()
        self._prefetch_immediate_next_candidate()
        self._schedule_next_tick()      # first beat after tap


    def _on_cache_request_display_update(self, image_path: str) -> None:
        """Redraw the current image if CacheManager updated it."""
        try:
            if not image_path:
                return
            cur = self.image_list_manager.data_service.get_current_image_path()
            if not cur:
                return
            p = normalize_path(image_path) or image_path
            c = normalize_path(cur) or cur
            if p != c:
                return
            self.show_image(cur)
        except Exception as e:
            logger.error("[ImageController] _on_cache_request_display_update error: %s", e, exc_info=True)

    def _on_current_image_changed(self, *args, **kwargs) -> None:
        """Respond to event-bus 'current_image_changed' (positional or keyword)."""
        try:
            image_path = kwargs.get("image_path")
            if not image_path and args:
                image_path = args[0]
            if not image_path:
                return
            self.show_image(image_path)
        except Exception as e:
            logger.error("[ImageController] _on_current_image_changed error: %s", e, exc_info=True)

    def _emit_image_cleared(self) -> None:
        """Clear the display on the GUI thread."""
        def _do_clear():
            self.current_displayed_image = None
            self.image_cleared.emit()
        QTimer.singleShot(0, _do_clear)

    def _on_no_images(self, *args, **kwargs) -> None:
        """Respond to event-bus 'no_images' by clearing the canvas."""
        try:
            logger.info('[ImageController] no_images received; clearing display')
            # Stop slideshow to avoid timer firing against an empty list
            self.stop_slideshow()
            self.loading_images.clear()
            self._shown_images.clear()
            self._emit_image_cleared()
        except Exception as e:
            logger.error('[ImageController] _on_no_images error: %s', e, exc_info=True)
