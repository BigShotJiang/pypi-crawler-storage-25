import hashlib

from PyQt6.QtGui import QMovie

from imaegete.core import logger
from imaegete.core.path_utils import normalize_path


class ImageLoader:
    def __init__(self, cache_handler, thread_manager):
        self.cache_handler = cache_handler
        self.thread_manager = thread_manager

    def load_image(self, image_path):
        p = normalize_path(image_path) or image_path
        logger.debug(f"[ImageLoader] Loading image: {p}")
        return self.cache_handler.get_cached_image(p, background=False)

    def load_image_async(self, image_path, callback):
        p = normalize_path(image_path) or image_path

        def task():
            try:
                logger.debug(f"[ImageLoader] Loading image asynchronously: {p}")
                image = self.load_image(p)
            except Exception as e:
                # The controller owns in-flight cleanup through the callback.
                # GlavnaQt suppresses ignored task exceptions, so notify the
                # callback before re-raising or the path can remain stuck in
                # ImageController.loading_images forever.
                try:
                    callback(None)
                except Exception as callback_error:
                    logger.error(
                        "[ImageLoader] Error in failure callback for %s: %s",
                        p,
                        callback_error,
                        exc_info=True,
                    )
                e.ignore = True
                raise

            callback(image)

        # Per-path unique tag: avoids thread-manager tag collisions cancelling
        # an unrelated in-flight decode.
        h = hashlib.sha1(str(p).encode("utf-8", "ignore")).hexdigest()[:12]
        return self.thread_manager.submit_task(task, tag=f"ui_load:{h}")
