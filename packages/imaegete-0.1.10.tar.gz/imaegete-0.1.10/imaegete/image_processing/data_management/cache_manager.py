"""cache_manager.py – image‑cache, metadata, filesystem watching (watchfiles edition)

This refactor removes *watchdog* and replaces it with **watchfiles**.
The public API of `CacheManager` is unchanged, so callers need no changes.
Key points:

* Uses `watchfiles.watch()` to monitor all configured `image_directories` in a
  *single background thread*, with native OS notifications on Linux/macOS/Windows.
* Debounce (coalescing) is handled by the built‑in `debounce=` argument, so we
  no longer need a custom handler class.
* Adds a small helper that splits the change set into **added** and **deleted**
  paths, then defers heavy work (ready‑check, list update) to the existing
  `thread_manager` just like before.
* Removes the watchdog self‑healing monitor – `watchfiles.watch()` is blocking
  but does not silently stop. We simply exit the loop when the `stop_event` is
  set during shutdown.
"""

from __future__ import annotations

import os, time
import hashlib
import glob
import time
import threading
import json
from collections import OrderedDict
from typing import List, Set

import psutil
from PIL import Image as PILImage, UnidentifiedImageError
from PyQt6.QtCore import (
    QObject, QCoreApplication, QMutex, QMutexLocker, QReadWriteLock, QSize, pyqtSignal,
)
from PyQt6.QtGui import QImage, QMovie, QImageReader

from watchfiles import watch, Change

from glavnaqt.events.bus import create_or_get_shared_event_bus
from imaegete.core import config, logger
from imaegete.core.path_utils import normalize_path
from imaegete.image_processing.data_management.file_operations import is_image_file


_PIL_READY_EXCEPTIONS = (
    UnidentifiedImageError,
    OSError,
    ValueError,
    EOFError,
    SyntaxError,
    PILImage.DecompressionBombError,
)

# ──────────────────────────────────────────────────────────────────────────────
# CacheManager
# ──────────────────────────────────────────────────────────────────────────────
class CacheManager(QObject):
    request_display_update = pyqtSignal(str)
    image_load_failed = pyqtSignal(str, str)

    # If a background decode task is dropped/cancelled, the request can get
    # stuck 'active' forever. Expire actives so cache-only slideshow can't deadlock.
    ACTIVE_REQUEST_STALE_SECS = 20.0

    # --------------------------------------------------------------------- init
    def __init__(
        self,
        cache_dir: str,
        thread_manager,
        data_service,
        image_directories: List[str],
        cache_limit_bytes: int,
        debounce_interval: float = 0.5,
        stability_check_interval: float = 0.05,
        stability_check_retries: int = 3,
    ) -> None:
        super().__init__()
        # basic config
        self.image_directories = [normalize_path(d) or os.path.normpath(d) for d in image_directories]
        self.cache_dir = cache_dir
        self.cache_limit_bytes = cache_limit_bytes
        self.debounce_interval = debounce_interval
        self.stability_check_interval = stability_check_interval
        self.stability_check_retries = stability_check_retries

        # collaborators
        self.thread_manager = thread_manager
        self.data_service = data_service
        self.event_bus = create_or_get_shared_event_bus()
        self.dest_folders = config.dest_folders
        self.delete_folders = config.delete_folders

        # runtime state
        self.cache_used_bytes = 0
        self.image_cache = OrderedDict()           # path -> QImage | QMovie
        self.metadata_cache = OrderedDict()        # path -> dict
        self.cache_lock = QMutex()
        # path -> start_time (time.monotonic())
        self.currently_active_requests: dict[str, float] = {}
        self.debounce_tasks: dict[str, object] = {}
        self.shutdown_flag = False

        # watchfiles stop event/thread. The watcher is a permanent blocking
        # loop, so keep it out of the shared decode/task pool.
        self._wf_stop_evt: threading.Event | None = None
        self._wf_thread: threading.Thread | None = None

        # Coalesce file-add readiness polling so bursts of watcher events cannot
        # queue many blocking batch_new_files tasks and starve decode workers.
        self._pending_new_paths: set[str] = set()
        self._pending_new_lock = threading.Lock()
        self._new_files_task_active = False

        # helpers
        self.metadata_manager = MetadataManager(
            self.cache_dir,
            self.thread_manager,
            stability_interval=self.stability_check_interval,
            stability_retries=self.stability_check_retries,
        )

        self._setup_cache_directory()
        self.moveToThread(QCoreApplication.instance().thread())

        # start file system watcher (watchfiles)
        self._initialize_watchfiles()

    
    def _load_metadata_task(self, image_path: str) -> None:
        """Background worker queued by get_metadata()."""
        if self.is_shutting_down():
            return
        image_path = normalize_path(image_path) or image_path
        meta = self.metadata_manager.load_metadata(image_path)
        if meta:
            with QMutexLocker(self.cache_lock):
                self.metadata_cache[image_path] = meta
                # soft-LRU trim if cache grows very large
                if len(self.metadata_cache) > 10_000:          # tweak if desired
                    self.metadata_cache.popitem(last=False)
            self.request_display_update.emit(image_path)

    @staticmethod
    def _bytes_for_qimage(qimg: QImage) -> int:
        return qimg.bytesPerLine() * qimg.height()

    @staticmethod
    def _normalised_frame_count(frame_count: int | None = 1) -> int:
        try:
            frames = int(frame_count or 1)
        except Exception:
            frames = 1
        return max(1, frames)

    @classmethod
    def _bytes_for_decoded_frames(cls, qsize, frame_count: int | None = 1) -> int:
        """Estimate decoded RGBA memory for an image size and frame count."""
        try:
            width = max(0, int(qsize.width()))
            height = max(0, int(qsize.height()))
        except Exception:
            return 0

        if width <= 0 or height <= 0:
            return 0

        frames = cls._normalised_frame_count(frame_count)

        # Qt commonly expands animated frames to 32-bit image data.  The cache
        # should reserve for decoded frames, not the usually much smaller GIF
        # file size on disk.
        return width * height * 4 * frames

    @classmethod
    def _estimated_gif_cache_bytes(
        cls, path: str, qsize, frame_count: int | None = 1
    ) -> int:
        """Estimate the eventual in-memory cost of a path-backed QMovie."""
        try:
            file_sz = int(os.path.getsize(path))
        except Exception:
            file_sz = 0
        decoded_sz = cls._bytes_for_decoded_frames(qsize, frame_count)
        return max(file_sz, decoded_sz)

    @classmethod
    def _bytes_for_qmovie(cls, movie: QMovie) -> int:
        """Best-effort decoded-frame cost for a cached QMovie."""
        try:
            frame_count = movie.frameCount()
        except Exception:
            frame_count = 1

        try:
            current = movie.currentImage()
            frame_bytes = 0 if current.isNull() else cls._bytes_for_qimage(current)
        except Exception:
            frame_bytes = 0

        if frame_bytes > 0:
            return frame_bytes * cls._normalised_frame_count(frame_count)

        try:
            return cls._bytes_for_decoded_frames(movie.frameRect().size(), frame_count)
        except Exception:
            return 0

    def _cache_entry_bytes(self, path: str, obj) -> int:
        """Best-effort estimate of the memory cost of one cache entry."""
        try:
            if isinstance(obj, QImage):
                return self._bytes_for_qimage(obj)
            if isinstance(obj, QMovie):
                return self._bytes_for_qmovie(obj)
            if obj is None:
                md = self.metadata_cache.get(path)
                if md and 'cache_cost' in md:
                    return int(md['cache_cost'])
                if md and 'file_size' in md:
                    return int(md['file_size'])
                try:
                    return int(os.path.getsize(path))
                except Exception:
                    return 0
        except Exception:
            return 0
        return 0

    def _purge_cache_entry(self, path: str) -> int:
        """Remove an entry from in-memory caches and return bytes freed."""
        freed = 0
        with QMutexLocker(self.cache_lock):
            if path in self.image_cache:
                old = self.image_cache.pop(path)
                freed = self._cache_entry_bytes(path, old)
                self.cache_used_bytes = max(0, self.cache_used_bytes - freed)
            self.metadata_cache.pop(path, None)
            self.currently_active_requests.pop(path, None)
        return freed

    def _publish_mem_event(self) -> None:
        self.event_bus.emit("cache_mem", self.cache_used_bytes, self.cache_limit_bytes)

    def _setup_cache_directory(self) -> None:
        os.makedirs(self.cache_dir, exist_ok=True)

    def _queue_new_files(self, paths: List[str]) -> None:
        """Queue newly discovered paths behind one bounded readiness worker."""
        if self.is_shutting_down() or not paths:
            return

        with self._pending_new_lock:
            self._pending_new_paths.update(paths)
            if self._new_files_task_active:
                return
            self._new_files_task_active = True

        submitted = self.thread_manager.submit_task(
            self._drain_pending_new_files,
            tag="batch_new_files",
        )
        if submitted is None:
            with self._pending_new_lock:
                self._new_files_task_active = False

    def _drain_pending_new_files(self, stop_flag=None) -> None:
        """Drain coalesced new-file batches using at most one pool worker."""
        try:
            while True:
                if self.is_shutting_down() or (stop_flag and stop_flag()):
                    with self._pending_new_lock:
                        self._new_files_task_active = False
                    return

                with self._pending_new_lock:
                    if not self._pending_new_paths:
                        self._new_files_task_active = False
                        return
                    paths = list(self._pending_new_paths)
                    self._pending_new_paths.clear()

                self.process_new_files(paths)
        except Exception:
            with self._pending_new_lock:
                self._new_files_task_active = False
            raise

    # ─────────────────────────────────────────────── file‑watch initialisation
    def _initialize_watchfiles(self) -> None:
        """Start a single *watchfiles* thread covering all image directories."""
        if self.is_shutting_down():
            return
        if self._wf_stop_evt is not None:           # already running
            return

        # Build exclusion list – identical logic to old watchdog version
        directories_to_exclude: set[str] = set()
        for start in self.image_directories:
            directories_to_exclude.update(
                os.path.normpath(p) for p in
                list(self.dest_folders.get(start, {}).values()) +
                [self.delete_folders.get(start, "")]
                if p
            )
        excluded = directories_to_exclude

        # Selection-only mode: only react to file-system events for the files
        # the user explicitly opened (multi-select “playlist” behavior).
        allowed: set[str] | None = None
        if getattr(config, 'selection_only', False):
            allowed = {
                os.path.normpath(os.path.abspath(p))
                for p in (getattr(config, 'selection_files', None) or [])
            }

        stop_evt = threading.Event()
        self._wf_stop_evt = stop_evt

        def _watch_loop():
            logger.debug("[CacheManager] watchfiles started on %d dirs", len(self.image_directories))
            try:
                # watch() yields *sets* of (Change, path) tuples; debounce is ms.
                for changes in watch(
                    *self.image_directories,
                    stop_event=stop_evt,
                    debounce=int(self.debounce_interval * 1000),
                    raise_interrupt=False,
                    ignore_permission_denied=True,
                ):
                    if self.is_shutting_down():
                        break

                    # Snapshot the current working set once per batch. This lets us
                    # treat "added" events for paths already in the list as
                    # modifications (common when the app pre-updates the list for an
                    # undo, and the filesystem event arrives after the move).
                    known_paths = {
                        normalize_path(p) or os.path.normpath(os.path.abspath(p))
                        for p in self.data_service.get_image_list()
                    }

                    added: list[str] = []
                    modified: list[str] = []
                    deleted: list[str] = []

                    for change, path in changes:
                        # Normalize to a stable absolute path. (watchfiles may yield
                        # relative paths if the watched roots were relative.)
                        p = normalize_path(path) or os.path.normpath(os.path.abspath(path))

                        # filter exclusions first
                        if any(p == x or p.startswith(x + os.sep) for x in excluded):
                            continue

                        # In selection-only mode, ignore any file not in the explicit list.
                        if allowed is not None and p not in allowed:
                            continue

                        if not is_image_file(p):
                            continue

                        if change is Change.added:
                            # If the path is already in the working set, treat it
                            # like a content refresh so we re-decode and redraw.
                            if p in known_paths:
                                modified.append(p)
                            else:
                                added.append(p)
                        elif change is Change.modified:
                            modified.append(p)
                        elif change is Change.deleted:
                            deleted.append(p)

                    # de-dupe (watchfiles gives sets; order is not meaningful)
                    added = list(dict.fromkeys(added))
                    modified = list(dict.fromkeys(modified))
                    deleted = list(dict.fromkeys(deleted))

                    # Defer new-file readiness polling through a coalesced worker.
                    # This keeps heavy file churn from filling the shared pool with
                    # blocking stability checks.
                    if added:
                        self._queue_new_files(added)
                    if modified:
                        self.thread_manager.submit_task(
                            self.process_modified_files, paths=modified, tag="batch_mod_files")
                    if deleted:
                        self.thread_manager.submit_task(
                            self.process_deleted_files, paths=deleted, tag="batch_del_files")
            except Exception as exc:
                if not self.is_shutting_down():
                    logger.error(f"[CacheManager] watchfiles loop failed: {exc}")
            finally:
                logger.debug("[CacheManager] watchfiles loop exited")

        # Run the permanent blocking watch loop on a CacheManager-owned thread,
        # not the shared ThreadManager pool used for decode/cache work.
        self._wf_thread = threading.Thread(
            target=_watch_loop,
            name="imaegete-watchfiles",
            daemon=True,
        )
        self._wf_thread.start()

    def _store_movie(self, path: str, movie: QMovie, qsize):
        with QMutexLocker(self.cache_lock):
            # adjust for overwrite
            if path in self.image_cache:
                old = self.image_cache.get(path)
                self.cache_used_bytes = max(0, self.cache_used_bytes - self._cache_entry_bytes(path, old))

            try:
                movie_frame_count = movie.frameCount()
            except Exception:
                movie_frame_count = 1
            cache_cost = max(
                self._cache_entry_bytes(path, movie),
                self._estimated_gif_cache_bytes(path, qsize, movie_frame_count),
            )
            self.image_cache[path] = movie
            self.image_cache.move_to_end(path)
            self.currently_active_requests.pop(path, None)
            self.cache_used_bytes += cache_cost

            # honour the byte budget
            while self.cache_used_bytes > self.cache_limit_bytes and self.image_cache:
                old_path, old_img = self.image_cache.popitem(last=False)
                self.cache_used_bytes = max(0, self.cache_used_bytes - self._cache_entry_bytes(old_path, old_img))
                self.metadata_cache.pop(old_path, None)
            self.currently_active_requests.pop(path, None)

            self.metadata_cache[path] = md = {
                "type": "gif",
                "file_size": os.path.getsize(path),
                "last_modified": os.path.getmtime(path),
                "size": qsize,
                "frame_count": CacheManager._normalised_frame_count(movie_frame_count),
                "cache_cost": cache_cost,
            }
            self.metadata_manager.save_metadata(path, md)
        self._publish_mem_event()
        self.request_display_update.emit(path)

    def _store_qimage(self, path: str, qimg: QImage):
        with QMutexLocker(self.cache_lock):
            # adjust for overwrite
            if path in self.image_cache:
                old = self.image_cache.get(path)
                self.cache_used_bytes = max(0, self.cache_used_bytes - self._cache_entry_bytes(path, old))

            self.image_cache[path] = qimg
            self.cache_used_bytes += self._bytes_for_qimage(qimg)
            self.image_cache.move_to_end(path)

            while self.cache_used_bytes > self.cache_limit_bytes and self.image_cache:
                old_path, old_img = self.image_cache.popitem(last=False)
                self.cache_used_bytes = max(0, self.cache_used_bytes - self._cache_entry_bytes(old_path, old_img))
                self.metadata_cache.pop(old_path, None)

            self.currently_active_requests.pop(path, None)

            self.metadata_cache[path] = md = {
                "type": "image",
                "file_size": os.path.getsize(path),
                "last_modified": os.path.getmtime(path),
                "size": qimg.size(),
            }
            self.metadata_manager.save_metadata(path, md)
        self._publish_mem_event()

    def _store_gif_stub(self, path: str, qsize, frame_count: int | None = 1):
        file_sz = os.path.getsize(path)
        cache_cost = self._estimated_gif_cache_bytes(path, qsize, frame_count)
        with QMutexLocker(self.cache_lock):
            # adjust for overwrite
            if path in self.image_cache:
                old = self.image_cache.get(path)
                self.cache_used_bytes = max(0, self.cache_used_bytes - self._cache_entry_bytes(path, old))

            # Insert a placeholder. GIF display is path-backed, but QMovie will
            # decode and cache frames later, so reserve decoded-frame memory here.
            self.image_cache[path] = None
            self.image_cache.move_to_end(path)
            self.cache_used_bytes += cache_cost
            self.currently_active_requests.pop(path, None)

            self.metadata_cache[path] = md = {
                "type": "gif",
                "file_size": file_sz,
                "last_modified": os.path.getmtime(path),
                "size": qsize,
                "frame_count": CacheManager._normalised_frame_count(frame_count),
                "cache_cost": cache_cost,
            }
            self.metadata_manager.save_metadata(path, md)

            # Evict LRU entries until we’re back under the byte budget. Metadata
            # is populated before this loop so evicting this placeholder subtracts
            # the same decoded-frame cost that was added above.
            while self.cache_used_bytes > self.cache_limit_bytes and self.image_cache:
                old_path, old_img = self.image_cache.popitem(last=False)
                self.cache_used_bytes = max(0, self.cache_used_bytes - self._cache_entry_bytes(old_path, old_img))
                self.metadata_cache.pop(old_path, None)

        self._publish_mem_event()

    @staticmethod
    def _retry_delay_for_attempt(attempt: int) -> float:
        return 0.2 * (2 ** attempt)

    def _drop_active_request(self, image_path: str) -> None:
        with QMutexLocker(self.cache_lock):
            self.currently_active_requests.pop(image_path, None)

    def _submit_delayed_load_retry(
        self,
        image_path: str,
        *,
        attempt: int,
        reason: str,
        delay: float | None = None,
    ) -> bool:
        """Queue a bounded, shutdown-aware retry through ThreadManager."""
        if self.is_shutting_down():
            return False

        p = normalize_path(image_path) or image_path
        retry_attempt = attempt + 1
        retry_delay = self._retry_delay_for_attempt(attempt) if delay is None else delay
        tag = f"retry_{reason}:{os.path.basename(p)}"

        def _retry_after_delay(stop_flag=None):
            deadline = time.monotonic() + retry_delay
            while True:
                if self.is_shutting_down() or (stop_flag and stop_flag()):
                    return
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(remaining, 0.05))

            if self.is_shutting_down() or (stop_flag and stop_flag()):
                return
            self.load_from_disk_and_cache(p, attempt=retry_attempt)

        try:
            return self.thread_manager.submit_task(_retry_after_delay, tag=tag) is not None
        except Exception as exc:
            logger.error(f"[CacheManager] Failed to submit delayed retry for {p}: {exc}")
            return False

    def load_from_disk_and_cache(self, image_path: str, attempt: int = 0):
        """
        Decode either a GIF (QMovie) or still image (QImage), store it
        into the in-memory cache + metadata cache on disk, and then
        tell the UI to redraw.
        """
        image_path = normalize_path(image_path) or image_path
        if not os.path.exists(image_path):
            # If the file vanished, ensure the request isn't left 'active' forever.
            self._drop_active_request(image_path)
            return None

        if not self.metadata_manager.file_is_ready(image_path):
            retry_queued = False
            if attempt < 4 and not self.is_shutting_down():
                retry_queued = self._submit_delayed_load_retry(
                    image_path,
                    attempt=attempt,
                    reason="ready",
                )
            # If we are giving up (no more retries), shutting down, or the retry
            # could not be queued, don't leave the request permanently 'active'.
            if attempt >= 4 or self.is_shutting_down() or not retry_queued:
                self._drop_active_request(image_path)
                if not self.is_shutting_down():
                    self.image_load_failed.emit(image_path, "File not ready")
            return None
        try:
            if image_path.lower().endswith('.gif'):
                reader = QImageReader(image_path)
                if not reader.canRead():
                    err = reader.errorString() or "Unreadable GIF"
                    self._drop_active_request(image_path)
                    self.image_load_failed.emit(image_path, err)
                    return None

                size = reader.size()                 # width / height only
                frame_count = reader.imageCount()
                self._store_gif_stub(image_path, size, frame_count=frame_count)

                # Return the *path* — GUI will create its own QMovie
                self.request_display_update.emit(image_path)
                return image_path
            else:
                # use QImageReader but only treat a NULL image as failure
                reader = QImageReader(image_path)
                img = reader.read()
                if img.isNull():
                    err = reader.errorString() or "Unknown image-load error"
                    logger.error(f"[CacheManager] Failed to read {image_path}: {err}")
                    self._drop_active_request(image_path)
                    self.image_load_failed.emit(image_path, err)
                    return None
                # success: cache & return even if there were warnings
                self._store_qimage(image_path, img)
                result = img
            self.request_display_update.emit(image_path)
            return result
        except Exception as exc:
            retry_queued = False
            if attempt < 4 and not self.is_shutting_down():
                retry_queued = self._submit_delayed_load_retry(
                    image_path,
                    attempt=attempt,
                    reason="exc",
                )
            if attempt >= 4 or self.is_shutting_down() or not retry_queued:
                self._drop_active_request(image_path)
                if not self.is_shutting_down():
                    self.image_load_failed.emit(image_path, str(exc))
            return None

    def process_new_files(self, paths: List[str]) -> None:
        """Add new image files to the working set and prime the cache.

        In selection-only mode, upstream filtering ensures only explicitly
        selected files can be (re-)added (e.g., a deleted file recreated).
        """
        images_before = self.data_service.get_image_list()
        current = set(images_before)
        unseen = [p for p in paths if p not in current and is_image_file(p)]

        ready: list[str] = []
        # For each unseen path, block-wait until the file is stable/decodable
        for p in unseen:
            total_wait = 0.0
            max_wait = self.stability_check_interval * self.stability_check_retries * 5
            while total_wait < max_wait:
                if self.metadata_manager.file_is_ready(p):
                    ready.append(p)
                    break
                time.sleep(self.stability_check_interval)
                total_wait += self.stability_check_interval

        if not ready:
            return

        before_len = len(images_before)
        if hasattr(self.data_service, "extend_image_list"):
            self.data_service.extend_image_list(ready)
        else:
            for p in ready:
                self.data_service.insert_sorted_image(p)

        self.event_bus.emit("update_image_total")

        # If there was no current image (e.g., list was empty), select the first new one.
        if self.data_service.get_current_image_path() is None:
            if hasattr(self.data_service, "extend_image_list"):
                idx = before_len
            else:
                try:
                    idx = self.data_service.get_index_for_image(ready[0])
                except Exception:
                    idx = 0
            self.data_service.set_current_index(idx)
            cur = self.data_service.get_current_image_path()
            if cur:
                self.event_bus.emit("current_image_changed", image_path=cur)

        for p in ready:
            self.thread_manager.submit_task(
                self.load_from_disk_and_cache,
                image_path=p,
                tag=f"refresh:{os.path.basename(p)}")

    def process_modified_files(self, paths: List[str]) -> None:
        """Reload images whose on-disk content changed.

        This keeps cached images + metadata in sync and triggers a redraw if
        the modified file is currently displayed.
        """
        if self.is_shutting_down():
            return

        image_set = set(self.data_service.get_image_list())
        candidates = [p for p in paths if p in image_set and is_image_file(p)]
        if not candidates:
            return

        ready: list[str] = []
        for p in candidates:
            if self.metadata_manager.file_is_ready(p):
                ready.append(p)

        if not ready:
            return

        freed = 0
        for p in ready:
            freed += self._purge_cache_entry(p)
        if freed:
            self._publish_mem_event()

        for p in ready:
            self.thread_manager.submit_task(
                self.load_from_disk_and_cache,
                image_path=p,
                tag=f"reload:{os.path.basename(p)}")

    def process_deleted_files(self, paths: List[str]) -> None:
        """Remove deleted files from the working set and keep UI in sync.

        Edge cases:
        - If the list becomes empty, always emit 'no_images' so the GUI can clear.
        - If the current image disappears but others remain, emit 'current_image_changed'.
        - Ignore deletes for paths that were already removed (e.g., when the app
          moves a file and updates the list pre-emptively).
        """
        current_before = self.data_service.get_current_image_path()
        removed_current = False

        freed = 0
        for p in paths:
            if p == current_before:
                removed_current = True
            freed += self._purge_cache_entry(p)
            # best-effort delete metadata on disk
            try:
                os.remove(self.metadata_manager.get_cache_path(p))
            except FileNotFoundError:
                pass
            except Exception:
                pass

            try:
                self.data_service.remove_image(p)
            except ValueError:
                # already absent
                continue

        if freed:
            self._publish_mem_event()

        if paths:
            self.event_bus.emit("update_image_total")

        images_now = self.data_service.get_image_list()

        # If the list is now empty, always notify.
        if not images_now:
            self.event_bus.emit("no_images")
            return

        # If we removed what was current, advance to the new current.
        if removed_current:
            new_cur = self.data_service.get_current_image_path()
            if new_cur:
                self.event_bus.emit("current_image_changed", image_path=new_cur)
            else:
                self.event_bus.emit("no_images")

    def _load_tag_for_path(self, image_path: str) -> str:
        """Generate a stable, collision-resistant task tag for one image path."""
        p = normalize_path(image_path) or str(image_path)
        h = hashlib.sha1(p.encode('utf-8', 'ignore')).hexdigest()[:12]
        return f"load:{h}"

    def retrieve_image(self, image_path: str, *, active_request: bool = False, background: bool = True):
        """Return an image/movie if cached; otherwise trigger a load.


        If active_request=True, a duplicate in-flight request returns None.

        Active entries also expire so the slideshow can't deadlock if a

        background task was dropped/cancelled.

        """
        p = normalize_path(image_path) or image_path

        with QMutexLocker(self.cache_lock):
            if self.is_shutting_down():
                return None

            # Cache hit.
            if p in self.image_cache:
                cached = self.image_cache.get(p)
                # GIFs may be stored as a stub (None) while we rely on path-based QMovie.
                if cached is None:
                    md = self.metadata_cache.get(p)
                    if md and md.get('type') == 'gif':
                        self.image_cache.move_to_end(p)
                        return p
                elif cached:
                    self.image_cache.move_to_end(p)
                    return cached

            # De-dup in-flight background requests (but expire stuck ones).
            now = time.monotonic()
            started = self.currently_active_requests.get(p)
            if started is not None and active_request:
                if (now - started) < self.ACTIVE_REQUEST_STALE_SECS:
                    return None
                # stale: allow a retry
                self.currently_active_requests.pop(p, None)

            self.currently_active_requests[p] = now

        if background:
            # Background loads go through the thread manager; ensure we never
            # leave the request 'active' if the submission can't happen.
            try:
                if getattr(self.thread_manager, 'is_shutting_down', False):
                    with QMutexLocker(self.cache_lock):
                        self.currently_active_requests.pop(p, None)
                    return None

                tag = self._load_tag_for_path(p)
                self.thread_manager.submit_task(
                    self.load_from_disk_and_cache,
                    image_path=p,
                    tag=tag,
                )
            except Exception as exc:
                with QMutexLocker(self.cache_lock):
                    self.currently_active_requests.pop(p, None)
                self.image_load_failed.emit(p, str(exc))
            return None

        # Synchronous (caller will handle result).
        return self.load_from_disk_and_cache(p)

    def is_shutting_down(self) -> bool:
        return bool(self.shutdown_flag)

    def is_cached(self, image_path: str) -> bool:
        p = normalize_path(image_path) or image_path
        return p in self.image_cache

    def shutdown(self) -> None:
        """Gracefully stop background workers and watcher."""
        self.shutdown_flag = True

        # stop watchfiles loop
        if self._wf_stop_evt:
            self._wf_stop_evt.set()
        wf_thread = self._wf_thread
        if wf_thread and wf_thread.is_alive() and wf_thread is not threading.current_thread():
            wf_thread.join(timeout=max(1.0, self.debounce_interval + 0.5))
            if wf_thread.is_alive():
                logger.debug("[CacheManager] watchfiles thread did not exit before timeout")

        if hasattr(self.thread_manager, 'stop_tasks_by_tag'):
            self.thread_manager.stop_tasks_by_tag('batch_new_files')

        with QMutexLocker(self.cache_lock):
            self.currently_active_requests.clear()

        try:
            self.metadata_manager.shutdown()
        except Exception:
            pass

    def get_metadata(self, image_path: str):
        """Return cached metadata if present; otherwise queue a background load."""
        if self.is_shutting_down():
            return None

        # fast path – already cached
        p = normalize_path(image_path) or image_path
        if p in self.metadata_cache:
            self.metadata_cache.move_to_end(p)
            return self.metadata_cache[p]

        # queue background load (non-blocking)
        self.thread_manager.submit_task(
            self._load_metadata_task,
            image_path=p,
            tag='metadata_load',
        )
        return None




class MetadataManager:
    def __init__(
        self,
        cache_dir: str,
        thread_manager,
        stability_interval: float,
        stability_retries: int,
    ) -> None:
        self.cache_dir = cache_dir
        self.thread_manager = thread_manager
        self.stability_interval = stability_interval
        self.stability_retries = stability_retries
        self.lock = QReadWriteLock()
        self.shutdown_flag = False

    def file_is_ready(self, image_path: str) -> bool:
        stable_needed = 3                     # ← consecutive passes
        stable = 0
        last = None
        waited = 0.0
        budget = self.stability_interval * self.stability_retries * 5
        while waited < budget:
            try:
                size = os.path.getsize(image_path)
            except FileNotFoundError:
                return False
            if last is not None and size == last:
                stable += 1
                if stable >= stable_needed:
                    try:
                        with PILImage.open(image_path) as im:
                            im.verify()
                        return True          # good & verified
                    except _PIL_READY_EXCEPTIONS as exc:
                        logger.debug(
                            "[MetadataManager] Image is not ready/decodable yet: %s (%s: %s)",
                            image_path,
                            type(exc).__name__,
                            exc,
                        )
                        return False
            else:
                stable = 0
            last = size
            time.sleep(self.stability_interval)
            waited += self.stability_interval
        return False

    @staticmethod
    def _metadata_to_json(metadata: dict) -> dict:
        data = dict(metadata)
        size = data.get("size")
        if isinstance(size, QSize):
            data["size"] = {"width": size.width(), "height": size.height()}
        return data

    @staticmethod
    def _metadata_from_json(data: object):
        if not isinstance(data, dict):
            return None

        metadata = dict(data)
        size = metadata.get("size")
        if isinstance(size, dict):
            try:
                metadata["size"] = QSize(int(size["width"]), int(size["height"]))
            except (KeyError, TypeError, ValueError):
                return None
        return metadata

    def save_metadata(self, image_path: str, metadata: dict) -> None:
        if self.shutdown_flag:
            return

        def task():
            if self.shutdown_flag:
                return
            cache_path = self.get_cache_path(image_path)
            current = self.load_metadata(image_path)
            if current == metadata:
                return
            encoded = self._metadata_to_json(metadata)
            tmp_path = f"{cache_path}.tmp"
            self.lock.lockForWrite()
            try:
                with open(tmp_path, "w", encoding="utf-8") as f:
                    json.dump(encoded, f, sort_keys=True, separators=(",", ":"))
                os.replace(tmp_path, cache_path)
            finally:
                try:
                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)
                finally:
                    self.lock.unlock()

        self.thread_manager.submit_task(task, tag="metadata")

    def load_metadata(self, image_path: str):
        cache_path = self.get_cache_path(image_path)
        if not os.path.exists(cache_path):
            return None
        self.lock.lockForRead()
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                return self._metadata_from_json(json.load(f))
        except Exception:
            return None
        finally:
            self.lock.unlock()

    def get_cache_path(self, image_path: str) -> str:
        """
        Instead of using the original basename, produce a SHA-256
        hash of the full image_path and use that as the filename.
        """
        # Compute a hex digest of the absolute image path
        h = hashlib.sha256(os.path.abspath(image_path).encode('utf-8')).hexdigest()
        return os.path.join(self.cache_dir, f"{h}.cache")

    def shutdown(self) -> None:
        self.shutdown_flag = True

