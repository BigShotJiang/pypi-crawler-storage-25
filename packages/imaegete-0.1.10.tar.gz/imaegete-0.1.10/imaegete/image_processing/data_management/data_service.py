import natsort
from PyQt6.QtCore import QRecursiveMutex, QMutexLocker

from imaegete.core import logger
from imaegete.core.path_utils import normalize_path


class ImageDataService:
    """
    A class to manage image data, including the image list, current image path
    This version handles thread safety, so modules like ImageHandler, ImageManager
    no longer need to handle their own locking.
    """

    def __init__(self):
        self._current_image_path = None
        self._image_list = []
        self._sorted_images = []
        self._ongoing_file_tasks = []
        self._current_index = 0
        self._image_list_version = 0
        self.cache_manager = None
        self._initial_image_indexed = None
        self.image_list_lock = QRecursiveMutex()
        self.sorted_images_lock = QRecursiveMutex()
        self.ongoing_file_tasks_lock = QRecursiveMutex()

    def set_initial_image_indexed(self, is_indexed):
        self._initial_image_indexed = is_indexed

    def get_image_path(self, index):
        """
        Get the image path at the specified index.

        :param int index: The index of the image.
        :return: The image path at the given index or None if out of bounds.
        :rtype: str or None
        """
        with QMutexLocker(self.image_list_lock):
            if 0 <= index < len(self._image_list):
                return self._image_list[index]
            return None

    def get_current_image_path(self):
        """
        Get the current image path.

        :return: The current image path.
        :rtype: str
        """
        with QMutexLocker(self.image_list_lock):
            return self._current_image_path

    def set_current_image_path(self, image_path):
        """
        Set the current image path.

        :param str image_path: The path of the current image.
        """
        with QMutexLocker(self.image_list_lock):
            self._current_image_path = image_path

    def image_in_ongoing_file_tasks(self, image_path):
        with QMutexLocker(self.ongoing_file_tasks_lock):
            return image_path in self._ongoing_file_tasks

    def get_sorted_images(self):
        """
        Get the list of sorted images.

        :return: The sorted images.
        :rtype: list
        """
        with QMutexLocker(self.image_list_lock):
            return self._sorted_images.copy()

    def set_sorted_images(self, sorted_images):
        """
        Set the list of sorted images.

        :param list sorted_images: The list of sorted images.
        """
        with QMutexLocker(self.image_list_lock):
            self._sorted_images = sorted_images

    def pop_sorted_images(self, index=None):
        """
        Remove and return the last item from the sorted images list, or the item at the given index.

        :param int index: The index of the image to pop. If None, pop the last image.
        :return: The popped sorted image.
        :rtype: tuple
        """
        with QMutexLocker(self.image_list_lock):
            if index is None:
                index = len(self._sorted_images) - 1
            if self._sorted_images:
                return self._sorted_images.pop(index)

    def pop_image_list(self, index=None):
        """
        Remove and return the last item from the image list, or the item at the given index.

        :param int index: The index of the image to pop. If None, pop the last image.
        :return: The popped image.
        :rtype: str
        """
        with QMutexLocker(self.image_list_lock):
            if index is None:
                index = len(self._image_list) - 1
            image_path = self._image_list.pop(index)
            self._bump_image_list_version()
            return image_path

    def append_sorted_images(self, sorted_tuple):
        """
        Append a tuple to the sorted images list.

        :param tuple sorted_tuple: The tuple to append to the sorted images list.
        """
        with QMutexLocker(self.image_list_lock):
            self._sorted_images.append(sorted_tuple)

    def append_ongoing_file_tasks(self, image_path):
        """
        Append a tuple to the sorted images list.

        :param image_path:
        """
        with QMutexLocker(self.ongoing_file_tasks_lock):
            self._ongoing_file_tasks.append(image_path)

    def get_image_list_len(self):
        """
        Get the length of the image list.

        :return: The number of images in the image list.
        :rtype: int
        """
        with QMutexLocker(self.image_list_lock):
            return len(self._image_list)

    def get_ongoing_file_tasks(self):
        """
        Get the image list.

        :return: The list of images.
        :rtype: list
        """
        with QMutexLocker(self.ongoing_file_tasks_lock):
            return self._ongoing_file_tasks.copy()

    def get_image_list(self):
        """
        Get the image list.

        :return: The list of images.
        :rtype: list
        """
        with QMutexLocker(self.image_list_lock):
            return self._image_list.copy()

    def get_image_list_version(self):
        """Return a monotonic token for image-list membership/order changes."""
        with QMutexLocker(self.image_list_lock):
            return self._image_list_version

    def _bump_image_list_version(self):
        self._image_list_version += 1

    def image_is_current(self, image_path):
        """
        Check if the provided image path is the current image.

        :param str image_path: The path of the image to check.
        :return: True if the image is current, False otherwise.
        :rtype: bool
        """
        p = normalize_path(image_path) or image_path
        with QMutexLocker(self.image_list_lock):
            if self._current_image_path is None:
                return False
            try:
                return self._current_index == self._image_list.index(p)
            except ValueError:
                return False

    def extend_image_list(self, image_list):
        """
        Set the image list.

        :param list image_list: The list of images.
        """
        if not image_list:
            return
        normalized = []
        for pth in image_list:
            np = normalize_path(pth)
            if np:
                normalized.append(np)
        if not normalized:
            return
        with QMutexLocker(self.image_list_lock):
            self._image_list.extend(normalized)
            self._bump_image_list_version()

    def set_ongoing_file_tasks(self, ongoing_file_tasks):
        """
        Set the image list.

        :param ongoing_file_tasks:
        """
        with QMutexLocker(self.ongoing_file_tasks_lock):
            self._ongoing_file_tasks = ongoing_file_tasks

    def set_image_list(self, image_list):
        """
        Set the image list.

        :param list image_list: The list of images.
        """
        normalized = []
        for pth in (image_list or []):
            np = normalize_path(pth)
            if np:
                normalized.append(np)
        with QMutexLocker(self.image_list_lock):
            if self._image_list != normalized:
                self._image_list = normalized
                self._bump_image_list_version()

    def insert_sorted_image(self, image_path):
        """
        Insert an image into the image list while maintaining order based on os_sort_key.

        :param str image_path: The path of the image to insert.
        """
        pth = normalize_path(image_path)
        if not pth:
            return
        with QMutexLocker(self.image_list_lock):
            new_item_key = natsort.os_sort_key(pth)

            index = 0
            while index < len(self._image_list):
                current_item_key = natsort.os_sort_key(self._image_list[index])

                if new_item_key < current_item_key:
                    break
                index += 1

            self._image_list.insert(index, pth)
            self._bump_image_list_version()

            if self._current_image_path in self._image_list:
                self._current_index = self._image_list.index(self._current_image_path)

    def remove_file_task(self, image_path):
        with QMutexLocker(self.ongoing_file_tasks_lock):
            if image_path in self._ongoing_file_tasks:
                self._ongoing_file_tasks.remove(image_path)
            else:
                logger.error(
                    f'[ImageDataService] Image does not exist in the list of ongoing file tasks, cannot remove: {image_path}')

    def remove_image(self, image_path):
        """
        Remove an image from the image list and update the current index accordingly.

        :param str image_path: The path of the image to remove.
        """
        with QMutexLocker(self.image_list_lock):
            pth = normalize_path(image_path) or image_path
            if pth in self._image_list:
                original_index = self._image_list.index(pth)
                self._image_list.remove(pth)
                self._bump_image_list_version()

                if self._current_image_path in self._image_list:
                    self._current_index = self._image_list.index(self._current_image_path)
                elif self._image_list:
                    if self._current_index == len(self._image_list):
                        self._current_index = len(self._image_list) - 1
                    self.set_current_image_to_current_index()
                else:
                    self._current_image_path = None
                    self._current_index = 0
                    logger.info(f'[DataService] Removed last image from image list')
            else:
                raise ValueError(f"Image {pth} not found in the list.")

    def get_current_index(self):
        """
        Get the current index of the image being viewed.

        :return: The current index.
        :rtype: int
        """
        with QMutexLocker(self.image_list_lock):
            return self._current_index

    def set_current_index(self, index):
        """
        Set the current index and update the current image path accordingly.

        The image list can change underneath navigation when the user deletes or
        moves an image and then later undoes that action. Treat this method as
        the boundary that keeps the selected index and selected path coherent:
        an empty list clears selection, and an out-of-range request is clamped
        to the nearest valid image instead of leaving a stale path behind.

        :param int index: The index to set as current.
        """
        with QMutexLocker(self.image_list_lock):
            if not self._image_list:
                self._current_index = 0
                self._current_image_path = None
                return

            if index is None:
                self._current_index = 0
                self._current_image_path = None
                return

            if index < 0:
                index = 0
            elif index >= len(self._image_list):
                index = len(self._image_list) - 1

            self._current_index = index
            self.set_current_image_to_current_index()

    def get_index_for_image(self, image_path):
        """
        Get the index of a specific image.

        :param str image_path: The image path to look up.
        :return: The index of the image in the list.
        :rtype: int
        """
        pth = normalize_path(image_path) or image_path
        with QMutexLocker(self.image_list_lock):
            return self._image_list.index(pth)

    def set_current_image_to_current_index(self):
        """
        Set the current image path based on the current index.
        """
        with QMutexLocker(self.image_list_lock):
            if not self._image_list:
                self._current_image_path = None
                self._current_index = 0
                return

            index = self._current_index or 0
            if index < 0:
                index = 0
            elif index >= len(self._image_list):
                index = len(self._image_list) - 1

            self._current_index = index
            self._current_image_path = self._image_list[index]

    def set_cache_manager(self, cache_manager):
        """
        Set the cache manager for managing image caching.

        :param CacheManager cache_manager: The cache manager to set.
        """
        with QMutexLocker(self.image_list_lock):
            self.cache_manager = cache_manager

    def get_cache_manager(self):
        """
        Get the cache manager for managing image caching.

        :return: The cache manager.
        :rtype: CacheManager
        """
        with QMutexLocker(self.image_list_lock):
            return self.cache_manager
