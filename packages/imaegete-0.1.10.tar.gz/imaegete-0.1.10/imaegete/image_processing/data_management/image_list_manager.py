import os
import random
import time

from PyQt6.QtCore import QThread, QWaitCondition, QMutex, pyqtSignal, QObject, QMutexLocker
from natsort import os_sorted

from glavnaqt.events.bus import create_or_get_shared_event_bus
from imaegete.core import config, logger
from imaegete.core.path_utils import normalize_path
from imaegete.image_processing.data_management.file_operations import is_image_file


class ImageListManager(QObject):
    image_list_updated = pyqtSignal()

    def __init__(self, data_service, thread_manager):
        super().__init__()
        self.event_bus = create_or_get_shared_event_bus()
        self.event_bus.subscribe('refresh_image_list', self.refresh_image_list)
        self.data_service = data_service
        self.thread_manager = thread_manager
        self._start_dirs = os_sorted(config.start_dirs)
        self._shuffled_indices = []
        self._shuffled_image_list_version = None
        self.lock = QMutex()
        self._initial_image_indexed = False
        self.image_list_open_condition = QWaitCondition()
        self.image_list_refresh_complete = QWaitCondition()
        self.refreshing = False


    def _get_folders_to_skip(self):
        folders_to_skip = []
        for start_dir, subfolders in config.dest_folders.items():
            folders_to_skip.extend(subfolders.values())
        for start_dir, delete_folder in config.delete_folders.items():
            folders_to_skip.append(delete_folder)
        return folders_to_skip

    def refresh_image_list(self):
        """
        Kick off one worker per start‐directory, in sorted order.
        """
        # “Selection-only” mode: when the app is launched with multiple files
        # (e.g. file-manager multi-select via Desktop Entry %F), treat those
        # files as the entire navigation set and do *not* recursively scan
        # their parent directories.
        if getattr(config, 'selection_only', False) and getattr(config, 'selection_files', None):
            chosen: list[str] = []
            seen: set[str] = set()
            for p in config.selection_files:
                full = normalize_path(p)
                if not full:
                    continue
                if full in seen:
                    continue
                seen.add(full)
                if os.path.isfile(full) and is_image_file(full):
                    chosen.append(full)

            self.data_service.set_image_list(chosen)

            if chosen:
                cur = self.data_service.get_current_image_path()
                if not cur:
                    self.data_service.set_current_image_path(chosen[0])
                    self.data_service.set_current_index(0)
                elif cur in chosen:
                    self.data_service.set_current_index(chosen.index(cur))
                else:
                    # default to the first selected file
                    self.data_service.set_current_image_path(chosen[0])
                    self.data_service.set_current_index(0)

            self.event_bus.emit('update_image_total')
            self.image_list_updated.emit()
            return
        folders_to_skip = self._get_folders_to_skip()

        # rebuild & sort the queue from config
        self._start_dirs = os_sorted(config.start_dirs)
        self._initial_image_indexed = False

        if self._start_dirs:
            self.refreshing = True
            self.event_bus.emit('show_busy')

        # submit one task per directory (snapshot the list so mutation below
        # doesn’t confuse the loop)
        for directory in list(self._start_dirs):
            self.thread_manager.submit_task(
                self.process_files_in_directory,
                directory=directory,
                folders_to_skip=folders_to_skip,
                tag="refresh_image_list",
                on_finished=self.thread_manager.task_finished_callback
            )


    def process_files_in_directory(self, directory, folders_to_skip, stop_flag):
        """
        Scan a single start‐directory in batches, flush immediately if it’s
        still the head of the queue, otherwise accumulate and flush at end
        under a mutex‑gated “turn‑taking” protocol.
        """
        signal = self.image_list_updated
        thread_id = int(QThread.currentThreadId())
        logger.debug(f"[ImageListManager thread {thread_id}] Processing {directory}")

        # batching setup
        image_list = []
        batch_size = 50
        min_batch_size, max_batch_size = 10, 1000
        target_batch_time = 0.1

        # Walk the directory tree
        for root, _, files in os.walk(directory):
            if stop_flag():
                return
            if os.path.normpath(root) in folders_to_skip:
                continue

            sorted_files = os_sorted(files)
            i = 0
            while i < len(sorted_files):
                if stop_flag():
                    return

                start = time.time()
                batch_images = []

                # build one batch
                while len(batch_images) < batch_size and i < len(sorted_files):
                    if stop_flag():
                        return
                    fp = os.path.join(root, sorted_files[i])
                    if is_image_file(fp):
                        nfp = normalize_path(fp)
                        if nfp:
                            batch_images.append(nfp)
                    i += 1

                # buffer locally
                image_list.extend(batch_images)

                # ——— head‑of‑line immediate flush ————————————————
                if directory == self._start_dirs[0]:
                    # capture length before extending
                    before_len = len(self.data_service.get_image_list())
                    self.data_service.extend_image_list(image_list)

                    # set initial image once, mapping to the global list
                    if not self._initial_image_indexed and image_list:
                        current_path = self.data_service.get_current_image_path()
                        full_list = self.data_service.get_image_list()
                        if (current_path and current_path in image_list):
                            if not full_list:
                                idx = image_list.index(current_path)
                            elif current_path in full_list:
                                idx = full_list.index(current_path)
                            self.data_service.set_current_index(idx)
                            self._initial_image_indexed = True

                        elif not current_path:
                            # use first newly added image
                            self.data_service.set_current_image_path(full_list[before_len])
                            self.data_service.set_current_index(before_len)
                            self._initial_image_indexed = True

                    if signal and image_list:
                        signal.emit()

                    image_list = []

                # adapt batch_size
                dt = time.time() - start
                if dt < target_batch_time and batch_size < max_batch_size:
                    batch_size = min(batch_size * 2, max_batch_size)
                elif dt > target_batch_time and batch_size > min_batch_size:
                    batch_size = max(batch_size // 2, min_batch_size)

        # ─── gate + final flush + pop + wakeAll ───────────────────────────────────────

        locker = QMutexLocker(self.lock)
        try:
            # wait our turn
            while directory != self._start_dirs[0]:
                self.image_list_open_condition.wait(self.lock)

            # flush any leftovers and set initial index if still needed
            if image_list:
                before_len = len(self.data_service.get_image_list())
                self.data_service.extend_image_list(image_list)

                if not self._initial_image_indexed:
                    current_path = self.data_service.get_current_image_path()
                    full_list = self.data_service.get_image_list()
                    if current_path and current_path in full_list:
                        idx = full_list.index(current_path)
                        self.data_service.set_current_index(idx)
                    else:
                        self.data_service.set_current_image_path(full_list[before_len])
                        self.data_service.set_current_index(before_len)
                    self._initial_image_indexed = True

                if signal:
                    signal.emit()

            # pop ourselves and wake next
            self._start_dirs.pop(0)
            self.image_list_open_condition.wakeAll()

        finally:
            del locker  # auto-unlock

        # hide busy once all dirs done
        if not self._start_dirs:
            self.refreshing = False
            self.event_bus.emit('hide_busy')

    def add_image_to_list(self, image_path, index=None):
        """
        Add a new image to the image list at the specified index or at the end.
        """
        image_list = self.data_service.get_image_list()
        if is_image_file(image_path) and image_path not in image_list:
            if index is not None:
                image_list.insert(index, image_path)
            else:
                image_list.append(image_path)
            self.data_service.set_image_list(image_list)

    def remove_image_from_list(self, image_path):
        """
        Remove an image from the image list.
        """
        image_list = self.data_service.get_image_list()
        if image_path in image_list:
            image_list.remove(image_path)
        self.data_service.set_image_list(image_list)

    def pop_image(self):
        """
        Pop an image from the current index in the image list.
        """
        original_index = self.data_service.get_current_index()
        image_path = self.data_service.get_current_image_path()
        if image_path is None:
            return original_index, None

        # Use the canonical remove path so current_index/current_image_path are
        # updated consistently (including the "removed last image" case).
        try:
            self.data_service.remove_image(image_path)
        except Exception:
            # If the list changed out from under us, fall back to a best-effort
            # pop at the recorded index.
            try:
                image_path = self.data_service.pop_image_list(original_index)
            except Exception:
                return original_index, None
        return original_index, image_path

    def _current_index_or_zero(self, image_list):
        """Return a safe current index for arithmetic navigation."""
        if not image_list:
            return 0

        current_index = self.data_service.get_current_index()
        if current_index is None:
            return 0
        if current_index < 0:
            return 0
        if current_index >= len(image_list):
            return len(image_list) - 1
        return current_index

    def set_current_image_by_index(self, index=None):
        if index is not None:
            self.data_service.set_current_index(index)
        elif self.data_service.get_current_image_path() is None:
            self.data_service.set_current_index(0)

        return self.data_service.get_current_image_path()

    def set_first_image(self):
        if len(self.data_service.get_image_list()) > 0:
            return self.set_current_image_by_index(0)

    def set_last_image(self):
        image_list = self.data_service.get_image_list()
        if len(image_list) > 0:
            last_index = len(image_list) - 1
            return self.set_current_image_by_index(last_index)

    def set_next_image(self):
        image_list = self.data_service.get_image_list()
        if len(image_list) > 0:
            current_index = self._current_index_or_zero(image_list)
            next_index = (current_index + 1) % len(image_list)
            return self.set_current_image_by_index(next_index)

    def set_previous_image(self):
        image_list = self.data_service.get_image_list()
        if len(image_list) > 0:
            current_index = self._current_index_or_zero(image_list)
            previous_index = (current_index - 1) % len(image_list)
            return self.set_current_image_by_index(previous_index)

    def _image_list_version(self):
        getter = getattr(self.data_service, "get_image_list_version", None)
        if getter is None:
            return None
        return getter()

    def _ensure_shuffled_indices(self, image_list):
        """Keep the shuffle queue aligned with current image-list membership."""
        version = self._image_list_version()
        if version != self._shuffled_image_list_version:
            self._shuffled_indices = []
            self._shuffled_image_list_version = version

        if self._shuffled_indices:
            image_count = len(image_list)
            if any(idx < 0 or idx >= image_count for idx in self._shuffled_indices):
                self._shuffled_indices = []

        if not self._shuffled_indices:
            self._shuffled_indices = list(range(len(image_list)))
            random.shuffle(self._shuffled_indices)

    def set_random_image(self):
        image_list = self.data_service.get_image_list()
        if len(image_list) > 0:
            self._ensure_shuffled_indices(image_list)
            random_index = self._shuffled_indices.pop(0)
            return self.set_current_image_by_index(random_index)

    # ---------------------------------------------------------------------
    # Shuffle helpers (non-destructive peek + controlled commit)
    #
    # These are used by the slideshow “cache-only / best-effort” path.
    # Prefetching needs to know what the upcoming shuffled images are
    # *without* consuming them. Then, once a frame is actually shown,
    # the slideshow commits by consuming the chosen index.
    # ---------------------------------------------------------------------
    def peek_shuffled_indices(self, count: int = 1):
        """Return the next N shuffled indices without consuming them."""
        image_list = self.data_service.get_image_list()
        if not image_list:
            return []
        self._ensure_shuffled_indices(image_list)
        if count <= 0:
            return []
        return list(self._shuffled_indices[:count])

    def commit_shuffled_index(self, position: int = 0):
        """Consume one shuffled index (optionally skipping ahead) and set it current.

        Args:
            position: 0 commits the *next* shuffled index. If >0, it discards
                the skipped indices too (useful if the head of the queue no
                longer exists / was already shown).

        Returns:
            The selected image path (or None).
        """
        image_list = self.data_service.get_image_list()
        if not image_list:
            return None
        self._ensure_shuffled_indices(image_list)

        if position < 0:
            position = 0
        if position >= len(self._shuffled_indices):
            position = 0

        chosen = self._shuffled_indices[position]
        # discard everything up to and including the chosen element
        del self._shuffled_indices[: position + 1]
        return self.set_current_image_by_index(chosen)


    def defer_shuffled_index(self, position: int = 0):
        """Move one shuffled index (optionally skipping ahead) to the end without selecting it.


        Used by the cache-only slideshow path: if the next shuffled image isn't

        ready yet, we can defer it instead of stalling cadence or discarding it.

        """
        image_list = self.data_service.get_image_list()
        if not image_list:
            return None
        self._ensure_shuffled_indices(image_list)

        if position < 0:
            position = 0
        if position >= len(self._shuffled_indices):
            position = 0

        idx = self._shuffled_indices.pop(position)
        self._shuffled_indices.append(idx)
        return idx

    def has_current_image(self):
        return bool(self.data_service.get_current_image_path())

