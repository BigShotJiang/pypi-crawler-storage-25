# Releasing Imaegete

Imaegete releases are driven from the workstation. GitHub tag-push publishing is no longer the canonical path.

Versions come from git tags via `setuptools-scm`, and the repo-local release scripts build either the normal PyPI artifact set or the TestPyPI variant.

## Dependency order

Imaegete depends on published releases of Confumo and GlavnaQt.

Recommended release order:

1. release `confumo`
2. release `GlavnaQt`
3. release `imaegete`

## Validation

Run the normal checks first:

```bash
scripts/ci/check
scripts/ci/full
```

For a specific tagged release candidate:

```bash
scripts/ci/release-check vX.Y.Z
```

`scripts/ci/full` performs the package build and an optional local Qt smoke import. Linux is the supported release target. Non-Linux smoke checks are exploratory unless a release intentionally broadens platform support.

## Clean-tree requirement

The release build expects:

- a clean working tree with no modified or untracked files
- `HEAD` checked out exactly at the requested tag

This is intentional. It prevents stale generated files or local edits from leaking into the release artifacts.

## Build artifacts locally

Build the PyPI artifacts:

```bash
scripts/release/build pypi vX.Y.Z
```

Build the TestPyPI variant:

```bash
scripts/release/build testpypi vX.Y.Z
```

The TestPyPI build rewrites the package name to `TestImaegete` and rewrites the `GlavnaQt` and `confumo` dependencies to their TestPyPI package names.

Each build clears and repopulates `artifacts/release/<pypi|testpypi>/` with only the expected wheel and sdist for that tag.

## README demo media

The README demo GIF is intentionally treated as a release-hosted latebrum asset rather than a committed repo file.

Publish it after the tagged PyPI/TestPyPI release step with:

```bash
PUBLISH_SSH_TARGET=user@host scripts/publish-demo-media vX.Y.Z /path/to/imaegete-demo.gif
```

That helper publishes the GIF to both:

- `https://latebrum.com/downloads/actx/Imaegete/releases/<tag>/imaegete-demo.gif`
- `https://latebrum.com/downloads/actx/Imaegete/latest/imaegete-demo.gif`

The `releases/<tag>/` path stays immutable and canonical. The `latest/` path exists purely so the README can embed a stable tag-independent URL.

## Publish from the workstation

Upload to PyPI:

```bash
scripts/release/publish pypi vX.Y.Z
```

Upload to TestPyPI:

```bash
scripts/release/publish testpypi vX.Y.Z
```

`TWINE_REPOSITORY_URL` may be set to override the upload endpoint for manual or staging flows.

## Suggested release sequence

1. Run `scripts/ci/check`.
2. Run `scripts/ci/full` on the Linux workstation.
3. Treat non-Linux smoke checks as exploratory unless the release intentionally broadens supported platforms.
4. Run `scripts/ci/release-check vX.Y.Z`.
5. Ensure the working tree is clean.
6. Tag locally with `git tag -a vX.Y.Z -m "vX.Y.Z"`.
7. Check out the tag or otherwise ensure `HEAD` is exactly at that tag.
8. Build and inspect artifacts with `scripts/release/build ...`.
9. Publish from the workstation with `scripts/release/publish ...`.
10. Push the tag after the local release result is confirmed.

There is no GitHub Trusted Publishing dependency in the canonical flow anymore.
