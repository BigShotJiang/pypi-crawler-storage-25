"""Small cProfile helpers for manual Imaegete profiling.

The module is intentionally import-light: importing it must not import the
application entrypoint or initialize the Qt/GlavnaQt/Confumo stack. Running it
as a module still profiles the normal Imaegete GUI entrypoint.
"""

from __future__ import annotations

import atexit
import cProfile
import io
import logging
import pstats
from functools import wraps
from pathlib import Path
from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Any])

_PROFILE_SORT = "cumulative"
_PROFILE_OUTPUT = Path("imaegete_profile.txt")
_PROFILE = cProfile.Profile()
_profile_started = False
_exit_hook_registered = False


def _write_profile(profile: cProfile.Profile, output_path: Path) -> None:
    stats_buffer = io.StringIO()
    stats = pstats.Stats(profile, stream=stats_buffer).sort_stats(_PROFILE_SORT)
    stats.print_stats()
    output_path.write_text(stats_buffer.getvalue(), encoding="utf-8")


def profile_function(func: F) -> F:
    """Decorate ``func`` and write ``<func>_profile.txt`` after one call."""

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        profile = cProfile.Profile()
        profile.enable()
        try:
            return func(*args, **kwargs)
        finally:
            profile.disable()
            _write_profile(profile, Path(f"{func.__name__}_profile.txt"))

    return wrapper  # type: ignore[return-value]


def start_profiling() -> None:
    """Start the process-wide profiler and register one shutdown hook."""

    global _profile_started, _exit_hook_registered
    _PROFILE.enable()
    _profile_started = True

    if not _exit_hook_registered:
        atexit.register(on_exit)
        _exit_hook_registered = True


def stop_profiling(output_path: str | Path = _PROFILE_OUTPUT) -> None:
    """Stop the process-wide profiler and write collected stats if started."""

    global _profile_started
    if not _profile_started:
        return

    _PROFILE.disable()
    _profile_started = False
    _write_profile(_PROFILE, Path(output_path))


def on_exit() -> None:
    """Flush profiler output when profiling was started."""

    stop_profiling()
    logging.getLogger("imaegete").info("[profiler] Application exit triggered")


def run_profiled_app() -> None:
    """Run the normal Imaegete entrypoint under the process-wide profiler."""

    from imaegete.cli import main

    start_profiling()
    main()


if __name__ == "__main__":
    run_profiled_app()
