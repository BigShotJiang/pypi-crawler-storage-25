<!-- .game-of-cards/file-path-map.md
     Project-local content stub injected into goc-shipped skill bodies via
     `!\`cat .game-of-cards/file-path-map.md\`` at documented insertion points.

     Author the content the skills should see. If this file is empty, the
     skills proceed with their generic flow. See the goc README for the
     hook-point catalogue. -->
