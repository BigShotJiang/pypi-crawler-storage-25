"""
Client for report generation via the wizard API.
"""
import time
import logging
from typing import Dict, Any, Optional, List

from .base import BaseClient
from .utils.mcp_markers import mcp_tool, MCPCategory

logger = logging.getLogger(__name__)

REPORT_ENDPOINTS = {
    "wizard_create": "/v1/reports/wizard",
    "wizard_status": "/v1/reports/wizard/jobs/{job_id}",
}

# Available widget tags for report generation.
# Text widgets (h2, h3, h4, p, divider, columns) can repeat.
# Visual widgets should be used at most once each.
AVAILABLE_WIDGETS = {
    # Visual / interactive widgets
    "baseValue": "Base value indicator for the model",
    "binaryoverview": "Binary classification overview (positive/negative rates)",
    "thresholdPlot": "Threshold vs precision/recall trade-off plot",
    "confusionMatrix": "Confusion matrix visualisation",
    "metrics": "Model performance metrics summary",
    "waterfallplot": "SHAP-style waterfall breakdown of a prediction",
    "prCurveRocCurve": "PR curve and ROC curve",
    "health": "Feature health / data drift indicators",
    "table": "Custom data table (provide data as array of row objects)",
    "bulletList": "Bullet point list (provide data as array of strings)",
    "note": "Highlighted note block",
    # Text / structural widgets (always allowed, can repeat)
    "h2": "Section heading",
    "h3": "Sub-section heading",
    "h4": "Minor heading",
    "p": "Paragraph text",
    "divider": "Horizontal divider",
    "columns": "Two-column layout container",
}


class ReportsClient(BaseClient):
    """Client for report creation and management."""

    @staticmethod
    @mcp_tool(category=MCPCategory.ANALYSIS, step=1)
    def available_widgets() -> Dict[str, str]:
        """Return the available widget tags and their descriptions.

        Visual widgets (baseValue, confusionMatrix, etc.) should be used
        at most once per report. Text widgets (h2, p, divider) can repeat.
        """
        return dict(AVAILABLE_WIDGETS)

    @mcp_tool(category=MCPCategory.WRITE, step=2, depends_on=["available_widgets"])
    def create_report(
        self,
        run_id: str,
        report_name: str,
        report_description: str = "",
        is_public: bool = False,
        widgets: Optional[List[str]] = None,
        mode: str = "dynamic",
        max_features: int = 40,
        constraints: Optional[Dict] = None,
        audience: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """
        Start async report generation via the wizard.

        Returns:
            Dict with job_id and status ("accepted")
        """
        data = {
            "run_id": run_id,
            "report_name": report_name,
            "report_description": report_description,
            "is_public": is_public,
            "widgets": widgets,
            "mode": mode,
            "constraints": constraints,
        }
        if audience:
            data["audience"] = audience
        if max_features:
            data["gpt"] = {"max_features": max_features}

        response = self.session._session.post(
            url=f"{self.session.hostname}{REPORT_ENDPOINTS['wizard_create']}",
            json=data,
        )
        return self._handle_response(response)

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Get the status of a wizard report job."""
        url = REPORT_ENDPOINTS["wizard_status"].format(job_id=job_id)
        response = self.session._session.get(
            url=f"{self.session.hostname}{url}",
        )
        return self._handle_response(response)

    @mcp_tool(category=MCPCategory.WRITE, step=2, depends_on=["available_widgets"])
    def create_report_sync(
        self,
        run_id: str,
        report_name: str,
        report_description: str = "",
        is_public: bool = False,
        widgets: Optional[List[str]] = None,
        mode: str = "dynamic",
        max_features: int = 40,
        constraints: Optional[Dict] = None,
        audience: Optional[Dict] = None,
        timeout: int = 120,
        poll_interval: float = 2.0,
    ) -> Dict[str, Any]:
        """
        Create a report synchronously (polls until complete or timeout).

        Returns:
            Dict with status, report_id, version_id
        """
        result = self.create_report(
            run_id=run_id,
            report_name=report_name,
            report_description=report_description,
            is_public=is_public,
            widgets=widgets,
            mode=mode,
            max_features=max_features,
            constraints=constraints,
            audience=audience,
        )

        job_id = result.get("job_id")
        if not job_id:
            return {"status": False, "error": "No job_id returned"}

        elapsed = 0.0
        while elapsed < timeout:
            time.sleep(poll_interval)
            elapsed += poll_interval

            status = self.get_job_status(job_id)
            job_status = status.get("status", "")

            if job_status == "completed":
                return {
                    "status": True,
                    "report_id": status.get("report_id"),
                    "version_id": status.get("version_id"),
                    "duration": status.get("duration"),
                }
            elif job_status in ("failed", "error"):
                return {
                    "status": False,
                    "error": status.get("error", "Report generation failed"),
                }

        raise TimeoutError(
            f"Report generation timed out after {timeout}s (job_id={job_id})"
        )
