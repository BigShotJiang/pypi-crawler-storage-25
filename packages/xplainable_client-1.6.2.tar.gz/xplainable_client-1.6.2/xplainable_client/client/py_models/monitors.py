"""
Monitor (formerly collections) request and response models.
"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel


class CreateMonitorRequest(BaseModel):
    """Request to create a monitor."""
    model_id: str
    name: str
    description: str = ""
    data_source_type: str = "csv"
    threshold: float = 0.5
    schedule_type: str = "manual"


class CreateMonitorResponse(BaseModel):
    """Response from monitor creation."""
    monitor_id: str


class EditMonitorNameRequest(BaseModel):
    """Request to update monitor name."""
    monitor_id: str
    name: str


class EditMonitorDescriptionRequest(BaseModel):
    """Request to update monitor description."""
    monitor_id: str
    description: str


class CreateMonitorItemsRequest(BaseModel):
    """Request to add monitor items."""
    monitor_id: str
    monitor_items: list[dict]


class CreateMonitorItemsResponse(BaseModel):
    """Response from adding monitor items."""
    monitor_item_id: list[str]


class MonitorInfo(BaseModel):
    """Information about a monitor."""
    monitor_id: Optional[str] = None
    id: Optional[str] = None
    model_id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    created_by: Optional[str] = None
    created: Optional[datetime] = None
    threshold: float = 0.5
    data_source_type: str = "csv"

    model_config = {"extra": "allow"}

    @property
    def display_id(self) -> str:
        return self.monitor_id or self.id or "unknown"


class MonitorItemInfo(BaseModel):
    """Information about a monitor item."""
    monitor_item_id: Optional[str] = None
    id: Optional[str] = None
    scenario: Optional[dict] = None
    score: Optional[float] = None
    proba: Optional[float] = None
    notes: Optional[str] = None

    model_config = {"extra": "allow"}

    @property
    def display_id(self) -> str:
        return self.monitor_item_id or self.id or "unknown"
