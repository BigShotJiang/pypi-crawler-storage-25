"""
Agentic pipeline request and response models.
"""
from typing import Optional, List, Any, Dict
from pydantic import BaseModel, Field


class StartRunResponse(BaseModel):
    run_id: str
    status: str


class PendingDecisionResponse(BaseModel):
    decision_type: str
    options: List[Dict[str, Any]]
    context: Dict[str, Any]
    timeout_seconds: Optional[int] = None
    default_option_index: Optional[int] = None


class PhaseStatusResponse(BaseModel):
    phase: str
    status: str
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    error: Optional[str] = None


class SubmitDecisionResponse(BaseModel):
    status: str


class CancelRunResponse(BaseModel):
    success: bool


class SkipPhaseResponse(BaseModel):
    success: bool
    skipped_phase: str
    next_phase: Optional[str] = None


class ChatMessageResponse(BaseModel):
    message_id: str
    content: str
    message_type: str = "text"
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ChatHistoryMessage(BaseModel):
    id: str
    role: str
    content: str
    timestamp: str
    message_type: str = "text"
    metadata: Dict[str, Any] = Field(default_factory=dict)
