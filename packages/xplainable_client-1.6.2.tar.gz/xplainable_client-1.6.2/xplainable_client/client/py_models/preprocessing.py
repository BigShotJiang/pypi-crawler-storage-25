"""
Preprocessing related request and response models.
"""
from typing import List, Dict, Any, Optional
from pydantic import BaseModel


class CreatePreprocessorResponse(BaseModel):
    """Response from preprocessor creation."""
    preprocessor_id: str
    version_id: str


class AddPreprocessorVersionResponse(BaseModel):
    """Response from adding a preprocessor version."""
    version_id: str


class UpdatePreprocessorVersionResponse(BaseModel):
    """Response from updating a preprocessor version."""
    version_id: str


class PreprocessorInfo(BaseModel):
    """Information about a preprocessor."""
    id: str
    name: str
    description: Optional[str] = None
    created_by: str
    created: str
    last_updated: Optional[str] = None


class PreprocessorVersionInfo(BaseModel):
    """Information about a preprocessor version."""
    version_id: str
    preprocessor_id: str
    spec: Optional[Dict[str, Any]] = None
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None
    parent_version_id: Optional[str] = None
    created: Optional[str] = None
    created_by: Optional[str] = None
    python_version: Optional[str] = None
    xplainable_version: Optional[str] = None
