"""
Constants for the Xplainable client.
"""

URL_PREFIX = "/v1"

# Authentication endpoints
AUTH_ENDPOINTS = {
    "connect": f"{URL_PREFIX}/connect",
}

# Model endpoints
MODEL_ENDPOINTS = {
    "create": f"{URL_PREFIX}/models/create",
    "add_version": f"{URL_PREFIX}/models/add-version",
    "list_team_models": f"{URL_PREFIX}/models/teams/{{team_id}}",
    "get_model": f"{URL_PREFIX}/models/{{model_id}}",
    "list_versions": f"{URL_PREFIX}/models/versions/{{model_id}}",
    "list_partitions": f"{URL_PREFIX}/models/partitions/{{version_id}}",
    "link_preprocessor": f"{URL_PREFIX}/preprocessors/link-preprocessor",
    "get_profile": f"{URL_PREFIX}/models/profile/{{version_id}}",
    "get_evaluation": f"{URL_PREFIX}/models/evaluation/{{partition_id}}",
    "get_feature_info": f"{URL_PREFIX}/models/feature-info/{{version_id}}",
}

# Deployment endpoints
DEPLOYMENT_ENDPOINTS = {
    "create": f"{URL_PREFIX}/deployments/create",
    "create_deploy_key": f"{URL_PREFIX}/deployments/create-deploy-key",
    "list_team_deployments": f"{URL_PREFIX}/deployments/teams/{{team_id}}",
    "list_deploy_keys": f"{URL_PREFIX}/deployments/{{deployment_id}}",
    "list_active_team_keys": f"{URL_PREFIX}/deployments/teams/{{team_id}}/active-keys",
    "revoke_key": f"{URL_PREFIX}/deployments/revoke-key",
    "delete": f"{URL_PREFIX}/deployments/{{deployment_id}}",
    "activate": f"{URL_PREFIX}/deployments/{{deployment_id}}/activate",
    "deactivate": f"{URL_PREFIX}/deployments/{{deployment_id}}/deactivate",
    "payload": f"{URL_PREFIX}/deployments/{{deployment_id}}/payload",
}

# Preprocessor endpoints
PREPROCESSOR_ENDPOINTS = {
    "create": f"{URL_PREFIX}/preprocessors/create",
    "add_version": f"{URL_PREFIX}/preprocessors/add",
    "update_version": f"{URL_PREFIX}/preprocessors/update-version",
    "list_team_preprocessors": f"{URL_PREFIX}/preprocessors/teams/{{team_id}}",
    "get": f"{URL_PREFIX}/preprocessors/{{preprocessor_id}}",
    "get_version": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}",
    "get_pipeline": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}/pipeline",
    "preview": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}/preview",
    "fit": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}/fit",
    "check_signature": f"{URL_PREFIX}/preprocessors/check-signature",
    "delete_version": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}",
    "delete_preprocessor": f"{URL_PREFIX}/preprocessors/{{preprocessor_id}}",
}

# Monitor endpoints (formerly collections)
MONITOR_ENDPOINTS = {
    "create": f"{URL_PREFIX}/monitors/create",
    "get_monitor": f"{URL_PREFIX}/monitors/{{monitor_id}}",
    "get_model_monitors": f"{URL_PREFIX}/monitors/model/{{model_id}}",
    "get_team_monitors": f"{URL_PREFIX}/monitors/teams/{{team_id}}",
    "edit_name": f"{URL_PREFIX}/monitors/edit/name",
    "edit_description": f"{URL_PREFIX}/monitors/edit/description",
    "delete": f"{URL_PREFIX}/monitors/delete/{{monitor_id}}",
    "add_items": f"{URL_PREFIX}/monitors/monitor-items/add",
    "get_item": f"{URL_PREFIX}/monitors/monitor-items/{{monitor_item_id}}",
    "delete_item": f"{URL_PREFIX}/monitors/monitor-items/delete/{{monitor_item_id}}",
    "get_alert_rules": f"{URL_PREFIX}/monitors/{{monitor_id}}/alert-rules",
    "create_alert_rule": f"{URL_PREFIX}/monitors/{{monitor_id}}/alert-rules",
}

# Inference endpoints
INFERENCE_ENDPOINTS = {
    "predict": f"{URL_PREFIX}/predict",
}

# Autotrain endpoints
AUTOTRAIN_ENDPOINTS = {
    "summarize": f"{URL_PREFIX}/autotrain/summarize",
    "generate_goals": f"{URL_PREFIX}/autotrain/generate_goals",
    "generate_labels": f"{URL_PREFIX}/autotrain/generate_labels",
    "generate_feature_engineering": f"{URL_PREFIX}/autotrain/generate_feature_engineering",
    "start_autotrain": f"{URL_PREFIX}/autotrain/start_autotrain",
    "check_training_status": f"{URL_PREFIX}/autotrain/check_training_status",
    "train_manual": f"{URL_PREFIX}/autotrain/train_manual",
}

# GPT endpoints
GPT_ENDPOINTS = {
    "generate_report": f"{URL_PREFIX}/models/report/generate",
    "explain_model": f"{URL_PREFIX}/models/explain",
}

# Dataset endpoints
DATASET_ENDPOINTS = {
    "upload": f"{URL_PREFIX}/datasets/upload",
    "get": f"{URL_PREFIX}/datasets/{{dataset_id}}",
    "delete": f"{URL_PREFIX}/datasets/{{dataset_id}}",
    "preview": f"{URL_PREFIX}/datasets/{{dataset_id}}/preview",
    "list_team": f"{URL_PREFIX}/datasets/teams/{{team_id}}",
    "list_children": f"{URL_PREFIX}/datasets/{{dataset_id}}/children",
    "download": f"{URL_PREFIX}/datasets/{{dataset_id}}/download",
}

# Run Endpoints
RUN_ENDPOINTS = {
    "create": f"{URL_PREFIX}/runs",
    "get": f"{URL_PREFIX}/runs/{{run_id}}",
}

# Agentic pipeline endpoints
AGENTIC_ENDPOINTS = {
    "start_run": f"{URL_PREFIX}/agentic/runs",
    "get_run": f"{URL_PREFIX}/agentic/runs/{{run_id}}",
    "pending_decision": f"{URL_PREFIX}/agentic/runs/{{run_id}}/pending-decision",
    "submit_decision": f"{URL_PREFIX}/agentic/runs/{{run_id}}/decisions",
    "get_phases": f"{URL_PREFIX}/agentic/runs/{{run_id}}/phases",
    "cancel": f"{URL_PREFIX}/agentic/runs/{{run_id}}/cancel",
    "skip_phase": f"{URL_PREFIX}/agentic/runs/{{run_id}}/skip-phase",
    "resume": f"{URL_PREFIX}/agentic/runs/{{run_id}}/resume",
    "chat": f"{URL_PREFIX}/agentic/runs/{{run_id}}/chat",
    "chat_history": f"{URL_PREFIX}/agentic/runs/{{run_id}}/chat/history",
    "retrain": f"{URL_PREFIX}/agentic/runs/{{run_id}}/retrain",
    "preprocessing_dag": f"{URL_PREFIX}/agentic/runs/{{run_id}}/preprocessing/dag",
    "column_lineage": f"{URL_PREFIX}/agentic/runs/{{run_id}}/preprocessing/lineage",
}

# Combine all endpoints for backward compatibility
URL_PATHS = {
    **AUTH_ENDPOINTS,
    **{f"models_{k}": v for k, v in MODEL_ENDPOINTS.items()},
    **{f"deployments_{k}": v for k, v in DEPLOYMENT_ENDPOINTS.items()},
    **{f"preprocessors_{k}": v for k, v in PREPROCESSOR_ENDPOINTS.items()},
    **{f"monitors_{k}": v for k, v in MONITOR_ENDPOINTS.items()},
    **{f"datasets_{k}": v for k, v in DATASET_ENDPOINTS.items()},
    **AUTOTRAIN_ENDPOINTS,
    **GPT_ENDPOINTS,
}
