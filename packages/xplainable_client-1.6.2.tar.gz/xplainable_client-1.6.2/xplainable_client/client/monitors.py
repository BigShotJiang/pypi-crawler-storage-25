"""
Monitors client.
"""
from typing import Dict, List, Optional

from .base import BaseClient
from .utils.mcp_markers import mcp_tool, MCPCategory
from .py_models.monitors import (
    CreateMonitorRequest,
    CreateMonitorResponse,
    EditMonitorNameRequest,
    EditMonitorDescriptionRequest,
    CreateMonitorItemsRequest,
    CreateMonitorItemsResponse,
    MonitorInfo,
    MonitorItemInfo,
)
from .utils.constants import MONITOR_ENDPOINTS


class MonitorsClient(BaseClient):
    """Client for managing monitors."""

    @mcp_tool(category=MCPCategory.WRITE)
    def create_monitor(
        self,
        model_id: str,
        name: str,
        description: str = "",
        threshold: float = 0.5,
        data_source_type: str = "csv",
        schedule_type: str = "manual",
    ) -> str:
        """
        Create a new monitor for a model.

        Args:
            model_id: ID of the model
            name: Name of the monitor
            description: Description of the monitor
            threshold: Decision threshold
            data_source_type: Data source type
            schedule_type: Schedule type

        Returns:
            The monitor ID
        """
        request = CreateMonitorRequest(
            model_id=model_id,
            name=name,
            description=description,
            threshold=threshold,
            data_source_type=data_source_type,
            schedule_type=schedule_type,
        )

        response = self.put(
            MONITOR_ENDPOINTS["create"],
            data=request,
            response_model=CreateMonitorResponse,
        )

        return response.monitor_id if hasattr(response, "monitor_id") else response

    @mcp_tool(category=MCPCategory.READ)
    def get_monitor(self, monitor_id: str) -> dict:
        """
        Get a monitor by ID.

        Args:
            monitor_id: ID of the monitor

        Returns:
            Monitor data
        """
        return self.get(
            MONITOR_ENDPOINTS["get_monitor"],
            monitor_id=monitor_id,
        )

    @mcp_tool(category=MCPCategory.READ)
    def get_model_monitors(self, model_id: str) -> List[dict]:
        """
        Get all monitors for a specific model.

        Args:
            model_id: ID of the model

        Returns:
            List of monitor information
        """
        response = self.get(
            MONITOR_ENDPOINTS["get_model_monitors"],
            model_id=model_id,
        )
        if not response:
            return []
        return response

    @mcp_tool(category=MCPCategory.READ)
    def get_team_monitors(self, team_id: Optional[str] = None) -> List[dict]:
        """
        Get all monitors for a team.

        Args:
            team_id: Optional team ID (uses session team_id if not provided)

        Returns:
            List of monitor information
        """
        if not team_id:
            team_id = self.session.team_id
        if not team_id:
            raise ValueError("No team selected. Call set_active_team first.")

        response = self.get(
            MONITOR_ENDPOINTS["get_team_monitors"],
            team_id=team_id,
        )
        if not response:
            return []
        return response

    @mcp_tool(category=MCPCategory.WRITE)
    def update_monitor_name(self, monitor_id: str, name: str) -> dict:
        """
        Update the name of a monitor.

        Args:
            monitor_id: ID of the monitor
            name: New name

        Returns:
            Updated monitor data
        """
        request = EditMonitorNameRequest(monitor_id=monitor_id, name=name)
        return self.patch(MONITOR_ENDPOINTS["edit_name"], data=request)

    @mcp_tool(category=MCPCategory.WRITE)
    def update_monitor_description(self, monitor_id: str, description: str) -> dict:
        """
        Update the description of a monitor.

        Args:
            monitor_id: ID of the monitor
            description: New description

        Returns:
            Updated monitor data
        """
        request = EditMonitorDescriptionRequest(
            monitor_id=monitor_id, description=description
        )
        return self.patch(MONITOR_ENDPOINTS["edit_description"], data=request)

    @mcp_tool(category=MCPCategory.WRITE)
    def delete_monitor(self, monitor_id: str) -> dict:
        """
        Delete a monitor.

        Args:
            monitor_id: ID of the monitor to delete

        Returns:
            Success message
        """
        return self.delete(
            MONITOR_ENDPOINTS["delete"],
            monitor_id=monitor_id,
        )

    @mcp_tool(category=MCPCategory.WRITE)
    def add_monitor_items(
        self, monitor_id: str, monitor_items: list[dict]
    ) -> dict:
        """
        Add items to a monitor.

        Args:
            monitor_id: ID of the monitor
            monitor_items: List of monitor item data

        Returns:
            Created item IDs
        """
        request = CreateMonitorItemsRequest(
            monitor_id=monitor_id, monitor_items=monitor_items
        )
        return self.put(MONITOR_ENDPOINTS["add_items"], data=request)

    @mcp_tool(category=MCPCategory.READ)
    def get_monitor_item(self, monitor_item_id: str) -> dict:
        """
        Get a specific monitor item.

        Args:
            monitor_item_id: ID of the monitor item

        Returns:
            Monitor item data
        """
        return self.get(
            MONITOR_ENDPOINTS["get_item"],
            monitor_item_id=monitor_item_id,
        )

    @mcp_tool(category=MCPCategory.WRITE)
    def delete_monitor_item(self, monitor_item_id: str) -> dict:
        """
        Delete a monitor item.

        Args:
            monitor_item_id: ID of the monitor item

        Returns:
            Success message
        """
        return self.delete(
            MONITOR_ENDPOINTS["delete_item"],
            monitor_item_id=monitor_item_id,
        )

    @mcp_tool(category=MCPCategory.READ)
    def get_alert_rules(self, monitor_id: str) -> dict:
        """
        Get alert rules for a monitor.

        Args:
            monitor_id: ID of the monitor

        Returns:
            Alert rules data
        """
        return self.get(
            MONITOR_ENDPOINTS["get_alert_rules"],
            monitor_id=monitor_id,
        )

    @mcp_tool(category=MCPCategory.WRITE)
    def create_alert_rule(
        self,
        monitor_id: str,
        rule_type: str,
        value: float,
        notify_in_app: bool = True,
        notify_email: bool = False,
    ) -> dict:
        """
        Create an alert rule for a monitor.

        Args:
            monitor_id: ID of the monitor
            rule_type: Type of rule (threshold, trend, volume)
            value: Rule threshold value
            notify_in_app: Send in-app notification
            notify_email: Send email notification

        Returns:
            Created alert rule data
        """
        payload = {
            "rule_type": rule_type,
            "value": value,
            "notify_in_app": notify_in_app,
            "notify_email": notify_email,
        }
        url = self._build_url(
            MONITOR_ENDPOINTS["create_alert_rule"].format(monitor_id=monitor_id)
        )
        response = self.session._session.put(url=url, json=payload)
        return self.session.get_response_content(response)

