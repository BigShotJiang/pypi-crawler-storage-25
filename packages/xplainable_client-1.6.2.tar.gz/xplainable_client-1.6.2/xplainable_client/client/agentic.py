"""
Agentic pipeline client for human-in-the-loop ML training.
"""
from typing import Any, Dict, List, Optional

from .base import BaseClient
from .py_models.agentic import (
    StartRunResponse,
    SubmitDecisionResponse,
    CancelRunResponse,
    SkipPhaseResponse,
    ChatMessageResponse,
)
from .utils.constants import AGENTIC_ENDPOINTS


# Default phases that require human approval
DEFAULT_REQUIRE_APPROVAL = [
    "label_selection",
    "data_preparation",
    "feature_engineering",
    "model_training",
    "model_deployment",
    "report_creation",
    "monitoring_creation",
]


class AgenticClient(BaseClient):
    """Client for managing agentic ML training pipeline runs."""

    def start_run(
        self,
        model_name: str,
        model_description: str = "",
        auto_mode: bool = False,
        require_approval: Optional[List[str]] = None,
        auto_apply_safe_features: bool = True,
        auto_deploy: bool = False,
        run_id: Optional[str] = None,
        user_query: Optional[str] = None,
        phase_plan: Optional[List[str]] = None,
    ) -> StartRunResponse:
        """
        Start a new agentic ML training pipeline run.

        This initiates the full ML workflow: data preparation -> label selection ->
        feature engineering -> model training -> deployment -> reporting -> monitoring.

        The pipeline will pause at each phase listed in require_approval and wait
        for a decision via submit_decision().

        Args:
            model_name: Name for the model being trained
            model_description: Description of the model's purpose
            auto_mode: If True, automatically proceed through phases without approval
            require_approval: List of phases requiring human approval. Defaults to all phases.
                Valid phases: label_selection, data_preparation, feature_engineering,
                model_training, model_deployment, report_creation, monitoring_creation
            auto_apply_safe_features: Automatically apply safe feature engineering suggestions
            auto_deploy: Automatically deploy the model after training
            run_id: Optional existing run ID to resume
            user_query: Optional natural language description of what to build
            phase_plan: Optional ordered list of phases to execute

        Returns:
            StartRunResponse with run_id and status
        """
        if require_approval is None:
            require_approval = list(DEFAULT_REQUIRE_APPROVAL)

        data = {
            "model_name": model_name,
            "model_description": model_description,
            "auto_mode": auto_mode,
            "require_approval": require_approval,
            "auto_apply_safe_features": auto_apply_safe_features,
            "auto_deploy": auto_deploy,
        }
        if run_id:
            data["run_id"] = run_id
        if user_query:
            data["user_query"] = user_query
        if phase_plan:
            data["phase_plan"] = phase_plan

        return self.post(
            AGENTIC_ENDPOINTS["start_run"],
            data=data,
            response_model=StartRunResponse,
        )

    def get_run_state(self, run_id: str) -> dict:
        """
        Get the current state of an agentic pipeline run.

        Use this to poll for run status and see current phase, progress, and results.

        Args:
            run_id: The run ID returned from start_run

        Returns:
            Dict with run state including current phase, status, and any results
        """
        return self.get(
            AGENTIC_ENDPOINTS["get_run"],
            run_id=run_id,
        )

    def get_pending_decision(self, run_id: str) -> Optional[dict]:
        """
        Check if the pipeline is waiting for a human decision.

        When the pipeline reaches a phase listed in require_approval, it pauses
        and creates a pending decision. Call this to see what decision is needed,
        then use submit_decision() to provide your choice.

        Args:
            run_id: The run ID

        Returns:
            Decision info dict with decision_type, options, and context, or None if no decision pending
        """
        result = self.get(
            AGENTIC_ENDPOINTS["pending_decision"],
            run_id=run_id,
        )
        if result is None:
            return None
        if isinstance(result, dict) and not result:
            return None
        return result

    def submit_decision(
        self,
        run_id: str,
        decision_type: str,
        choice_index: Optional[int] = None,
        action: Optional[str] = None,
        custom_value: Optional[Any] = None,
        label_type: Optional[str] = None,
        apply_indices: Optional[List[int]] = None,
        skip_indices: Optional[List[int]] = None,
        selected_indices: Optional[List[int]] = None,
        selected_options: Optional[List[Any]] = None,
        selected_features: Optional[List[Any]] = None,
        skipped: Optional[bool] = None,
        done: Optional[bool] = None,
        report_config: Optional[dict] = None,
        monitoring_config: Optional[dict] = None,
    ) -> SubmitDecisionResponse:
        """
        Submit a decision for a pending approval in the pipeline.

        The required fields depend on the decision_type from get_pending_decision().
        Common patterns:
        - Label selection: decision_type="label_selection", choice_index=N
        - Feature engineering: decision_type="feature_engineering", apply_indices=[...], skip_indices=[...]
        - Model training: decision_type="model_training", choice_index=N
        - Deployment: decision_type="model_deployment", action="approve" or "skip"
        - Report: decision_type="report_creation", report_config={...}
        - Monitoring: decision_type="monitoring_creation", monitoring_config={...}

        Args:
            run_id: The run ID
            decision_type: Type of decision (matches pending decision's decision_type)
            choice_index: Index of chosen option from the options list
            action: Action string (e.g., "approve", "skip", "reject")
            custom_value: Custom value for decisions that accept free-form input
            label_type: Label type for label selection decisions
            apply_indices: Indices of items to apply (e.g., feature engineering steps)
            skip_indices: Indices of items to skip
            selected_indices: Indices of selected items
            selected_options: List of selected option values
            selected_features: List of selected features
            skipped: Whether to skip this phase entirely
            done: Whether the decision process is complete
            report_config: Configuration for report creation
            monitoring_config: Configuration for monitoring setup

        Returns:
            SubmitDecisionResponse with status
        """
        data = {"decision_type": decision_type}
        # Only include non-None optional fields
        if choice_index is not None:
            data["choice_index"] = choice_index
        if action is not None:
            data["action"] = action
        if custom_value is not None:
            data["custom_value"] = custom_value
        if label_type is not None:
            data["label_type"] = label_type
        if apply_indices is not None:
            data["apply_indices"] = apply_indices
        if skip_indices is not None:
            data["skip_indices"] = skip_indices
        if selected_indices is not None:
            data["selected_indices"] = selected_indices
        if selected_options is not None:
            data["selected_options"] = selected_options
        if selected_features is not None:
            data["selected_features"] = selected_features
        if skipped is not None:
            data["skipped"] = skipped
        if done is not None:
            data["done"] = done
        if report_config is not None:
            data["report_config"] = report_config
        if monitoring_config is not None:
            data["monitoring_config"] = monitoring_config

        return self.post(
            AGENTIC_ENDPOINTS["submit_decision"],
            data=data,
            response_model=SubmitDecisionResponse,
            run_id=run_id,
        )

    def get_phases(self, run_id: str) -> list:
        """
        Get the phase execution history for a run.

        Args:
            run_id: The run ID

        Returns:
            List of phase status dicts with phase name, status, timestamps, and any errors
        """
        return self.get(
            AGENTIC_ENDPOINTS["get_phases"],
            run_id=run_id,
        )

    def cancel_run(self, run_id: str) -> CancelRunResponse:
        """
        Cancel a running agentic pipeline.

        Args:
            run_id: The run ID to cancel

        Returns:
            CancelRunResponse with success status
        """
        return self.post(
            AGENTIC_ENDPOINTS["cancel"],
            data={},
            response_model=CancelRunResponse,
            run_id=run_id,
        )

    def skip_phase(self, run_id: str) -> SkipPhaseResponse:
        """
        Skip the current phase and move to the next.

        Args:
            run_id: The run ID

        Returns:
            SkipPhaseResponse with skipped_phase and next_phase
        """
        return self.post(
            AGENTIC_ENDPOINTS["skip_phase"],
            data={},
            response_model=SkipPhaseResponse,
            run_id=run_id,
        )

    def resume_run(self, run_id: str) -> dict:
        """
        Resume a paused run (e.g., after a timed-out decision was auto-resolved).

        Args:
            run_id: The run ID to resume

        Returns:
            Resume result dict
        """
        return self.post(
            AGENTIC_ENDPOINTS["resume"],
            data={},
            run_id=run_id,
        )

    def send_chat(self, run_id: str, content: str) -> ChatMessageResponse:
        """
        Send a chat message to the agentic pipeline and get a response.

        Use this to ask questions about the current state of the run,
        request explanations, or provide additional context.

        Args:
            run_id: The run ID
            content: The message content

        Returns:
            ChatMessageResponse with the pipeline's reply
        """
        return self.post(
            AGENTIC_ENDPOINTS["chat"],
            data={"content": content},
            response_model=ChatMessageResponse,
            run_id=run_id,
        )

    def get_chat_history(self, run_id: str) -> list:
        """
        Get the chat history for a pipeline run.

        Args:
            run_id: The run ID

        Returns:
            List of chat messages with role, content, and timestamp
        """
        return self.get(
            AGENTIC_ENDPOINTS["chat_history"],
            run_id=run_id,
        )

    def retrain(self, run_id: str, params: Optional[Dict[str, Any]] = None) -> dict:
        """
        Retrain a completed run with optional new preprocessing steps or parameters.

        Args:
            run_id: The run ID of the completed run to retrain
            params: Optional dict of retraining parameters

        Returns:
            Retrain result dict
        """
        return self.post(
            AGENTIC_ENDPOINTS["retrain"],
            data=params if params else {},
            run_id=run_id,
        )

    def get_preprocessing_dag(self, run_id: str) -> dict:
        """
        Get the preprocessing DAG (directed acyclic graph) visualisation data for a run.

        Shows how preprocessing steps are connected and their order of execution.

        Args:
            run_id: The run ID

        Returns:
            DAG data dict with nodes and edges
        """
        return self.get(
            AGENTIC_ENDPOINTS["preprocessing_dag"],
            run_id=run_id,
        )

    def get_column_lineage(self, run_id: str) -> dict:
        """
        Get column lineage graph for the run's preprocessing.

        Shows how columns are transformed through the preprocessing pipeline.

        Args:
            run_id: The run ID

        Returns:
            Column lineage data dict
        """
        return self.get(
            AGENTIC_ENDPOINTS["column_lineage"],
            run_id=run_id,
        )
