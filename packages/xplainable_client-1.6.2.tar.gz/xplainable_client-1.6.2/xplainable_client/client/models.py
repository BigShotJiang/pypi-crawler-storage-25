"""
Refactored models client using Pydantic models and base client.
"""
from typing import Any, Dict, List, Optional, Tuple
import pandas as pd
from xplainable.utils.encoders import force_json_compliant

from .base import BaseClient
from .utils.mcp_markers import mcp_tool, MCPCategory
from .py_models.models import (
    CreateModelRequest,
    CreateModelResponse,
    AddVersionRequest,
    AddVersionResponse,
    ModelInfo,
    ModelVersion,
)
from .utils.constants import MODEL_ENDPOINTS, PREPROCESSOR_ENDPOINTS, DATASET_ENDPOINTS


class ModelsClient(BaseClient):
    """Client for managing ML models."""
    
    def create_model(
        self,
        model,
        model_name: str,
        model_description: str,
        x: pd.DataFrame,
        y: pd.Series,
        run_id: Optional[str] = None
    ) -> Tuple[str, str]:
        """
        Create a new model.

        Args:
            model: The XClassifier or XRegressor model
            model_name: Name of the model
            model_description: Description of the model
            x: Feature matrix
            y: Target variable
            run_id: Optional run ID to associate with the model

        Returns:
            Tuple of (model_id, version_id)

        Raises:
            XplainableAPIError: If model creation fails
        """
        model_type, target = self._detect_model_type(model)
        partition_on = model.partition_on if 'Partitioned' in model.__class__.__name__ else None

        # Build partitions data
        partitions = self._build_partitions_data(model, partition_on, x, y)

        # Create request
        request = CreateModelRequest(
            name=model_name,
            description=model_description,
            type=model_type,
            target_name=target,
            algorithm=model.__class__.__name__,
            partition_on=partition_on,
            versions={
                "xplainable_version": self.session.xplainable_version,
                "python_version": self.session.python_version
            },
            partitions=partitions,
            run_id=run_id
        )
        
        # Make request with custom JSON encoding for numpy/pandas objects
        url = self._build_url(MODEL_ENDPOINTS["create"])
        payload = force_json_compliant(request.model_dump(exclude_none=True))
        
        response = self.session._session.post(url=url, json=payload)
        
        # Handle the response - match old client behavior
        if response.status_code == 200:
            # Old client returns the entire content dict
            content = response.json()
            # Check if it's the new format with model_id and version_id
            if 'model_id' in content and 'version_id' in content:
                return content['model_id'], content['version_id']
            # Otherwise return the whole dict (old client behavior)
            return content
        else:
            # Let the error handler deal with it
            content = self._handle_response(response, CreateModelResponse)
            return content.model_id, content.version_id
    
    def add_version(
        self,
        model,
        model_id: str,
        x: pd.DataFrame,
        y: pd.Series
    ) -> str:
        """
        Add a new version to an existing model.
        
        Args:
            model: The XClassifier or XRegressor model
            model_id: ID of the existing model
            x: Feature matrix
            y: Target variable
            
        Returns:
            The new version_id
            
        Raises:
            XplainableAPIError: If version addition fails
        """
        partition_on = model.partition_on if 'Partitioned' in model.__class__.__name__ else None
        
        # Build partitions data
        partitions = self._build_partitions_data(model, partition_on, x, y)
        
        # Create request
        request = AddVersionRequest(
            model_id=model_id,
            partition_on=partition_on,
            versions={
                "xplainable_version": self.session.xplainable_version,
                "python_version": self.session.python_version
            },
            partitions=partitions
        )
        
        # Make request with custom JSON encoding
        response = self.session._session.post(
            url=self._build_url(MODEL_ENDPOINTS["add_version"]),
            json=force_json_compliant(request.model_dump(exclude_none=True))
        )
        
        content = self._handle_response(response, AddVersionResponse)
        return content.version_id
    
    @mcp_tool(category=MCPCategory.READ)
    def list_team_models(self) -> List[ModelInfo]:
        """
        List all models for the current team (based on API key).
        
        This method returns comprehensive information about all models
        accessible to the authenticated user's team.
        
        Returns:
            List of model information including names, descriptions, and metadata
            
        Raises:
            XplainableAPIError: If listing fails
        """
        team_id = self.session.team_id
        if not team_id:
            raise ValueError("No team selected. Call set_active_team first.")
        response = self.get(MODEL_ENDPOINTS["list_team_models"], team_id=team_id)

        # Parse response into list of ModelInfo models
        if not response:
            return []
        return [ModelInfo(**item) for item in response]
    
    @mcp_tool(category=MCPCategory.READ)
    def get_model(self, model_id: str) -> ModelInfo:
        """
        Get detailed information about a model.
        
        Args:
            model_id: ID of the model
            
        Returns:
            Model information
            
        Raises:
            XplainableAPIError: If retrieval fails
        """
        return self.get(
            MODEL_ENDPOINTS["get_model"],
            response_model=ModelInfo,
            model_id=model_id
        )
    
    @mcp_tool(category=MCPCategory.READ)
    def list_model_versions(self, model_id: str) -> List[ModelVersion]:
        """
        List all versions of a model.
        
        Args:
            model_id: ID of the model
            
        Returns:
            List of model versions
            
        Raises:
            XplainableAPIError: If listing fails
        """
        response = self.get(
            MODEL_ENDPOINTS["list_versions"],
            model_id=model_id
        )
        
        # Parse response into list of ModelVersion models
        return [ModelVersion(**item) for item in response]
    
    @mcp_tool(category=MCPCategory.READ)
    def list_model_version_partitions(self, version_id: str) -> Dict[str, Any]:
        """
        List all partitions for a model version.
        
        Args:
            version_id: ID of the model version (or "latest")
            
        Returns:
            Dictionary containing partition information
            
        Raises:
            XplainableAPIError: If listing fails
        """
        return self.get(
            MODEL_ENDPOINTS["list_partitions"],
            version_id=version_id
        )
    
    @mcp_tool(category=MCPCategory.WRITE)
    def link_preprocessor(
        self,
        model_version_id: str,
        preprocessor_version_id: str
    ) -> None:
        """
        Link a model version to a preprocessor version.
        
        Args:
            model_version_id: The model version ID
            preprocessor_version_id: The preprocessor version ID
            
        Raises:
            XplainableAPIError: If linking fails
        """
        payload = {
            "version_id": model_version_id,  # API expects "version_id" for model version
            "preprocessor_version_id": preprocessor_version_id
        }
        
        url = self._build_url(MODEL_ENDPOINTS["link_preprocessor"])
        response = self.session._session.put(url=url, json=payload)
        
        # Handle successful response with potentially empty content
        if response.status_code >= 200 and response.status_code < 300:
            # Check if response has content
            try:
                if response.content:
                    data = response.json()
                    return data if data else {}
                return {}  # Return empty dict for successful empty responses
            except:
                return {}  # Return empty dict if JSON parsing fails
        else:
            # Handle errors normally
            self._handle_response(response, dict)
    
    @mcp_tool(category=MCPCategory.WRITE)
    def train_model(
        self,
        target_column: str,
        model_name: str,
        model_description: str = "",
        file_path: Optional[str] = None,
        dataset_name: Optional[str] = None,
        dataset_id: Optional[str] = None,
        csv_content: Optional[str] = None,
        model_type: str = "classifier",
        preprocessor_version_id: Optional[str] = None,
        drop_columns: Optional[List[str]] = None,
        test_size: float = 0.2,
        max_depth: int = 8,
        min_info_gain: float = 0.0001,
        min_leaf_size: float = 0.0001,
        weight: float = 1.0,
        power_degree: float = 1.0,
        sigmoid_exponent: float = 0.0,
        tail_sensitivity: float = 1.0,
    ) -> dict:
        """Train an xplainable model on a dataset and upload it to the platform.

        Provide ONE of: dataset_id (preferred for hosted MCP), file_path (local CSV),
        dataset_name (xplainable public dataset), or csv_content (raw CSV string).

        Args:
            target_column: Name of the column to predict.
            model_name: Name for the uploaded model.
            model_description: Description for the uploaded model.
            file_path: Path to a local CSV file.
            dataset_name: Name of an xplainable public dataset (e.g. "telco_churn").
            dataset_id: ID of a dataset already on the xplainable platform.
                Use datasets_list_team_datasets to find available IDs. This is the
                preferred method for hosted/remote MCP servers.
            csv_content: Raw CSV string for when file paths aren't accessible.
            model_type: Either "classifier" or "regressor".
            preprocessor_version_id: Optional preprocessor version ID to load
                and apply a fitted pipeline to the features before training.
            drop_columns: Optional list of column names to exclude from features.
            test_size: Fraction of data to hold out for testing (0 to 1).
            max_depth: Maximum depth of the model decision tree.
            min_info_gain: Minimum information gain required to split.
            min_leaf_size: Minimum leaf size as a fraction of training data.
            weight: Model weight parameter.
            power_degree: Power degree parameter.
            sigmoid_exponent: Sigmoid exponent parameter.
            tail_sensitivity: Tail sensitivity parameter.

        Returns:
            Dictionary with model_id, version_id, train/test metrics,
            feature_importances, and train/test sample counts.
        """
        from sklearn.model_selection import train_test_split
        from io import StringIO

        # 1. Load data
        if dataset_id:
            # Download from platform -- works on hosted MCP servers
            response = self.get(DATASET_ENDPOINTS["download"], dataset_id=dataset_id)
            if isinstance(response, str):
                df = pd.read_csv(StringIO(response))
            elif isinstance(response, dict) and "data" in response:
                df = pd.DataFrame(response["data"])
            elif isinstance(response, list):
                df = pd.DataFrame(response)
            else:
                df = pd.DataFrame(response)
        elif file_path:
            df = pd.read_csv(file_path)
        elif dataset_name:
            url = f"https://xplainablepublic.blob.core.windows.net/asset-repository/datasets/{dataset_name}/data.csv"
            df = pd.read_csv(url)
        elif csv_content:
            df = pd.read_csv(StringIO(csv_content))
        else:
            raise ValueError("Provide dataset_id, file_path, dataset_name, or csv_content")

        # 2. Drop columns if requested
        if drop_columns:
            df = df.drop(columns=drop_columns)

        # 3. Split features and target
        x = df.drop(columns=[target_column])
        y = df[target_column]

        # 4. Optionally apply preprocessor pipeline
        if preprocessor_version_id:
            from xplainable_preprocessing.serialization import load_pipeline as deserialize_pipeline
            import base64

            response = self.get(
                PREPROCESSOR_ENDPOINTS["get_pipeline"],
                version_id=preprocessor_version_id,
            )
            pipeline_b64 = response.get("pipeline_binary")
            pipeline = deserialize_pipeline(base64.b64decode(pipeline_b64))
            x = pipeline.transform(x)

        # 5. Train/test split
        x_train, x_test, y_train, y_test = train_test_split(
            x, y, test_size=test_size, random_state=42
        )

        # 6. Create model
        if model_type == "classifier":
            from xplainable.core.models import XClassifier

            model = XClassifier(
                max_depth=max_depth,
                min_info_gain=min_info_gain,
                min_leaf_size=min_leaf_size,
                weight=weight,
                power_degree=power_degree,
                sigmoid_exponent=sigmoid_exponent,
                tail_sensitivity=tail_sensitivity,
            )
        else:
            from xplainable.core.models import XRegressor

            model = XRegressor(
                max_depth=max_depth,
                min_info_gain=min_info_gain,
                min_leaf_size=min_leaf_size,
                weight=weight,
                power_degree=power_degree,
                sigmoid_exponent=sigmoid_exponent,
                tail_sensitivity=tail_sensitivity,
            )

        # 7. Fit
        model.fit(x_train, y_train, target_name=target_column)

        # 8. Compute evaluation metrics
        if model_type == "classifier":
            from sklearn.metrics import (
                accuracy_score,
                roc_auc_score,
                classification_report,
                confusion_matrix,
            )

            y_train_pred = model.predict(x_train)
            y_test_pred = model.predict(x_test)

            # Score probabilities for AUC (handle potential failures gracefully)
            try:
                y_train_prob = model.predict_score(x_train)
                train_auc = roc_auc_score(
                    y_train.map(model.target_map) if model.target_map else y_train,
                    y_train_prob,
                )
            except Exception:
                train_auc = None

            try:
                y_test_prob = model.predict_score(x_test)
                test_auc = roc_auc_score(
                    y_test.map(model.target_map) if model.target_map else y_test,
                    y_test_prob,
                )
            except Exception:
                test_auc = None

            train_metrics = {
                "accuracy": float(accuracy_score(y_train, y_train_pred)),
                "roc_auc": float(train_auc) if train_auc is not None else None,
                "classification_report": classification_report(
                    y_train, y_train_pred, output_dict=True
                ),
                "confusion_matrix": confusion_matrix(y_train, y_train_pred).tolist(),
            }
            test_metrics = {
                "accuracy": float(accuracy_score(y_test, y_test_pred)),
                "roc_auc": float(test_auc) if test_auc is not None else None,
                "classification_report": classification_report(
                    y_test, y_test_pred, output_dict=True
                ),
                "confusion_matrix": confusion_matrix(y_test, y_test_pred).tolist(),
            }
        else:
            from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

            y_train_pred = model.predict(x_train)
            y_test_pred = model.predict(x_test)

            train_metrics = {
                "mse": float(mean_squared_error(y_train, y_train_pred)),
                "rmse": float(mean_squared_error(y_train, y_train_pred, squared=False)),
                "mae": float(mean_absolute_error(y_train, y_train_pred)),
                "r2": float(r2_score(y_train, y_train_pred)),
            }
            test_metrics = {
                "mse": float(mean_squared_error(y_test, y_test_pred)),
                "rmse": float(mean_squared_error(y_test, y_test_pred, squared=False)),
                "mae": float(mean_absolute_error(y_test, y_test_pred)),
                "r2": float(r2_score(y_test, y_test_pred)),
            }

        # 9. Feature importances
        feature_importances = {}
        if hasattr(model, "feature_importances") and model.feature_importances:
            feature_importances = {
                k: float(v) if v is not None else None
                for k, v in model.feature_importances.items()
            }

        # 10. Upload model
        model_id, version_id = self.create_model(
            model, model_name, model_description, x_train, y_train
        )

        # 11. Link preprocessor if one was used
        if preprocessor_version_id:
            self.link_preprocessor(version_id, preprocessor_version_id)

        # 12. Return results
        return {
            "model_id": model_id,
            "version_id": version_id,
            "model_type": model_type,
            "train_metrics": train_metrics,
            "test_metrics": test_metrics,
            "feature_importances": feature_importances,
            "n_train": len(x_train),
            "n_test": len(x_test),
        }

    @mcp_tool(category=MCPCategory.WRITE)
    def refit_model(
        self,
        model_id: str,
        version_id: str,
        target_column: str,
        file_path: Optional[str] = None,
        dataset_name: Optional[str] = None,
        dataset_id: Optional[str] = None,
        csv_content: Optional[str] = None,
        model_type: str = "classifier",
        features: Optional[List[str]] = None,
        preprocessor_version_id: Optional[str] = None,
        drop_columns: Optional[List[str]] = None,
        test_size: float = 0.2,
        max_depth: Optional[int] = None,
        min_info_gain: Optional[float] = None,
        min_leaf_size: Optional[float] = None,
        weight: Optional[float] = None,
        power_degree: Optional[float] = None,
        sigmoid_exponent: Optional[float] = None,
        tail_sensitivity: Optional[float] = None,
    ) -> dict:
        """Rapidly refit an existing model with new parameters without retraining.

        This is orders of magnitude faster than train_model because it reuses
        the pre-computed feature partitions from the original training. Only the
        scores and profile are recomputed with the new parameters.

        Use this to iterate on hyperparameters after an initial train_model call.
        The model structure (splits) stays the same -- only the scoring changes.

        Args:
            model_id: ID of the existing model.
            version_id: ID of the model version to refit.
            target_column: Name of the target column.
            file_path: Path to a local CSV (same data used for training).
            dataset_name: Name of an xplainable public dataset.
            csv_content: Raw CSV string (for remote MCP servers).
            model_type: Either "classifier" or "regressor".
            features: List of feature names to update. Defaults to all features.
            preprocessor_version_id: Preprocessor version ID if one was used in training.
            drop_columns: Columns to drop (same as in original training).
            test_size: Test split fraction (use same value as original training).
            max_depth: New max depth (None = keep current).
            min_info_gain: New min info gain (None = keep current).
            min_leaf_size: New min leaf size (None = keep current).
            weight: New weight (None = keep current).
            power_degree: New power degree (None = keep current).
            sigmoid_exponent: New sigmoid exponent (None = keep current).
            tail_sensitivity: New tail sensitivity (None = keep current).

        Returns:
            Dictionary with new version_id, train/test metrics, feature_importances,
            and the parameters that were changed.
        """
        from sklearn.model_selection import train_test_split
        from xplainable.utils.model_parsers import parse_classifier_response, parse_regressor_response

        # 1. Load the existing model from API
        misc_endpoint = f"/v1/models/{model_id}/versions/{version_id}/full"
        response = self.get(misc_endpoint)

        if model_type == "classifier":
            loaded = parse_classifier_response(response)
            model = loaded.partitions.get("__dataset__", list(loaded.partitions.values())[0])
        else:
            loaded = parse_regressor_response(response)
            model = loaded.partitions.get("__dataset__", list(loaded.partitions.values())[0])

        # 2. Rapid refit -- instant, no data needed
        refit_features = features if features else model.columns
        refit_params = {}
        if max_depth is not None:
            refit_params["max_depth"] = max_depth
        if min_info_gain is not None:
            refit_params["min_info_gain"] = min_info_gain
        if min_leaf_size is not None:
            refit_params["min_leaf_size"] = min_leaf_size
        if weight is not None:
            refit_params["weight"] = weight
        if power_degree is not None:
            refit_params["power_degree"] = power_degree
        if sigmoid_exponent is not None:
            refit_params["sigmoid_exponent"] = sigmoid_exponent
        if tail_sensitivity is not None:
            refit_params["tail_sensitivity"] = tail_sensitivity

        model.update_feature_params(refit_features, **refit_params)

        # 3. Load data for evaluation
        from io import StringIO
        if dataset_id:
            response = self.get(DATASET_ENDPOINTS["download"], dataset_id=dataset_id)
            if isinstance(response, str):
                df = pd.read_csv(StringIO(response))
            elif isinstance(response, dict) and "data" in response:
                df = pd.DataFrame(response["data"])
            elif isinstance(response, list):
                df = pd.DataFrame(response)
            else:
                df = pd.DataFrame(response)
        elif file_path:
            df = pd.read_csv(file_path)
        elif dataset_name:
            url = f"https://xplainablepublic.blob.core.windows.net/asset-repository/datasets/{dataset_name}/data.csv"
            df = pd.read_csv(url)
        elif csv_content:
            df = pd.read_csv(StringIO(csv_content))
        else:
            raise ValueError("Provide dataset_id, file_path, dataset_name, or csv_content")
        if drop_columns:
            df = df.drop(columns=drop_columns)

        x = df.drop(columns=[target_column])
        y = df[target_column]

        if preprocessor_version_id:
            from xplainable_preprocessing.serialization import load_pipeline as deserialize_pipeline
            import base64

            pp_response = self.get(
                PREPROCESSOR_ENDPOINTS["get_pipeline"],
                version_id=preprocessor_version_id,
            )
            pipeline_b64 = pp_response.get("pipeline_binary")
            pipeline = deserialize_pipeline(base64.b64decode(pipeline_b64))
            x = pipeline.transform(x)

        x_train, x_test, y_train, y_test = train_test_split(
            x, y, test_size=test_size, random_state=42
        )

        # 4. Evaluate with refitted model
        if model_type == "classifier":
            from sklearn.metrics import (
                accuracy_score, roc_auc_score, classification_report, confusion_matrix,
            )

            y_train_pred = model.predict(x_train)
            y_test_pred = model.predict(x_test)

            try:
                y_train_prob = model.predict_score(x_train)
                train_auc = roc_auc_score(
                    y_train.map(model.target_map) if model.target_map else y_train,
                    y_train_prob,
                )
            except Exception:
                train_auc = None

            try:
                y_test_prob = model.predict_score(x_test)
                test_auc = roc_auc_score(
                    y_test.map(model.target_map) if model.target_map else y_test,
                    y_test_prob,
                )
            except Exception:
                test_auc = None

            train_metrics = {
                "accuracy": float(accuracy_score(y_train, y_train_pred)),
                "roc_auc": float(train_auc) if train_auc is not None else None,
                "classification_report": classification_report(y_train, y_train_pred, output_dict=True),
                "confusion_matrix": confusion_matrix(y_train, y_train_pred).tolist(),
            }
            test_metrics = {
                "accuracy": float(accuracy_score(y_test, y_test_pred)),
                "roc_auc": float(test_auc) if test_auc is not None else None,
                "classification_report": classification_report(y_test, y_test_pred, output_dict=True),
                "confusion_matrix": confusion_matrix(y_test, y_test_pred).tolist(),
            }
        else:
            from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

            y_train_pred = model.predict(x_train)
            y_test_pred = model.predict(x_test)

            train_metrics = {
                "mse": float(mean_squared_error(y_train, y_train_pred)),
                "rmse": float(mean_squared_error(y_train, y_train_pred, squared=False)),
                "mae": float(mean_absolute_error(y_train, y_train_pred)),
                "r2": float(r2_score(y_train, y_train_pred)),
            }
            test_metrics = {
                "mse": float(mean_squared_error(y_test, y_test_pred)),
                "rmse": float(mean_squared_error(y_test, y_test_pred, squared=False)),
                "mae": float(mean_absolute_error(y_test, y_test_pred)),
                "r2": float(r2_score(y_test, y_test_pred)),
            }

        # 5. Feature importances
        feature_importances = {}
        if hasattr(model, "feature_importances") and model.feature_importances:
            feature_importances = {
                k: float(v) if v is not None else None
                for k, v in model.feature_importances.items()
            }

        # 6. Upload as new version
        new_version_id = self.add_version(model, model_id, x_train, y_train)

        if preprocessor_version_id:
            self.link_preprocessor(new_version_id, preprocessor_version_id)

        return {
            "model_id": model_id,
            "previous_version_id": version_id,
            "new_version_id": new_version_id,
            "parameters_changed": refit_params,
            "train_metrics": train_metrics,
            "test_metrics": test_metrics,
            "feature_importances": feature_importances,
            "n_train": len(x_train),
            "n_test": len(x_test),
        }

    @mcp_tool(category=MCPCategory.READ)
    def get_model_profile(self, version_id: str) -> dict:
        """Get the model profile showing feature contributions and decision boundaries.

        Args:
            version_id: ID of the model version.

        Returns:
            Dictionary containing the model profile data.
        """
        return self.get(MODEL_ENDPOINTS["get_profile"], version_id=version_id)

    @mcp_tool(category=MCPCategory.READ)
    def get_model_evaluation(self, partition_id: str) -> dict:
        """Get detailed evaluation metrics for a model partition.

        Args:
            partition_id: ID of the model partition.

        Returns:
            Dictionary containing evaluation metrics.
        """
        return self.get(MODEL_ENDPOINTS["get_evaluation"], partition_id=partition_id)

    @mcp_tool(category=MCPCategory.READ)
    def get_feature_info(self, version_id: str) -> dict:
        """Get feature information including types, health metrics, and distributions.

        Args:
            version_id: ID of the model version.

        Returns:
            Dictionary containing feature information.
        """
        return self.get(MODEL_ENDPOINTS["get_feature_info"], version_id=version_id)

    # Helper methods (private)

    def _detect_model_type(self, model) -> Tuple[str, str]:
        """
        Detect the model type and target variable name.
        
        Args:
            model: The model object
            
        Returns:
            Tuple of (model_type, target_name)
        """
        # Handle partitioned models
        if 'Partitioned' in model.__class__.__name__:
            model = model.partitions['__dataset__']
        
        cls_name = model.__class__.__name__
        if cls_name == "XClassifier":
            model_type = "binary_classification"
        elif cls_name == "XRegressor":
            model_type = "regression"
        else:
            raise ValueError(f'Model type {cls_name} is not supported')
        
        return model_type, model.target
    
    def _build_partitions_data(
        self,
        model,
        partition_on: Optional[str],
        x: pd.DataFrame,
        y: pd.Series
    ) -> List[Dict[str, Any]]:
        """
        Build partitions data for model creation/versioning.
        
        Args:
            model: The model object
            partition_on: Partition column name
            x: Feature matrix
            y: Target variable
            
        Returns:
            List of partition data dictionaries
        """
        partitions = []
        partitioned_models = ['PartitionedClassifier', 'PartitionedRegressor']
        independent_models = ['XClassifier', 'XRegressor']
        
        if model.__class__.__name__ in partitioned_models:
            for p, m in model.partitions.items():
                if p == '__dataset__':
                    part_x = x
                    part_y = y
                else:
                    part_x = x[x[partition_on].astype(str) == str(p)]
                    part_y = y[y.index.isin(part_x.index)]
                pdata = self._get_partition_data(m, p, part_x, part_y)
                partitions.append(pdata)
                
        elif model.__class__.__name__ in independent_models:
            pdata = self._get_partition_data(model, '__dataset__', x, y)
            partitions.append(pdata)
            
        return partitions
    
    def _get_partition_data(
        self,
        model,
        partition_name: str,
        x: pd.DataFrame,
        y: pd.Series
    ) -> Dict[str, Any]:
        """
        Get partition data for a single partition.
        
        Matches the exact format of the old _models.py implementation.
        """
        import json
        from xplainable.utils.encoders import NpEncoder
        from xplainable.metrics.metrics import evaluate_classification, evaluate_regression
        
        model_type, _ = self._detect_model_type(model)
        
        # Build the core model data - clean all data before JSON encoding
        data = {
            "partition": str(partition_name),
            "profile": json.dumps(force_json_compliant(model._profile, fill_value=None), cls=NpEncoder),
            "feature_importances": json.loads(
                json.dumps(force_json_compliant(model.feature_importances, fill_value=None), cls=NpEncoder)),
            "id_columns": json.loads(
                json.dumps(force_json_compliant(model.id_columns, fill_value=None), cls=NpEncoder)),
            "columns": json.loads(
                json.dumps(force_json_compliant(model.columns, fill_value=None), cls=NpEncoder)),
            "parameters": model.params.to_json(),
            "base_value": json.loads(
                json.dumps(force_json_compliant(model.base_value, fill_value=None), cls=NpEncoder)),
            "feature_map": json.loads(
                json.dumps(force_json_compliant({k: fm.forward for k, fm in model.feature_map.items()}, fill_value=None), cls=NpEncoder)),
            "target_map": json.loads(
                json.dumps(force_json_compliant(model.target_map.reverse, fill_value=None), cls=NpEncoder)),
            "category_meta": json.loads(
                json.dumps(force_json_compliant(model.category_meta, fill_value=None), cls=NpEncoder)),
            "calibration_map": None,
            "support_map": None
        }
        
        # Use exact same model type check as old client
        if model_type == 'binary_classification':
            data.update({
                "calibration_map": json.loads(
                    json.dumps(force_json_compliant(model._calibration_map, fill_value=None), cls=NpEncoder)),
                "support_map": json.loads(
                    json.dumps(force_json_compliant(model._support_map, fill_value=None), cls=NpEncoder))
            })
            
            evaluation = model.metadata.get('evaluation', {})
            if evaluation == {}:
                y_prob = model.predict_score(x)
                
                if model.target_map:
                    y = y.map(model.target_map)
                
                evaluation = {
                    'train': evaluate_classification(y, y_prob)
                }
        
        elif model_type == 'regression':
            evaluation = model.metadata.get('evaluation', {})
            if evaluation == {}:
                y_pred = model.predict(x)
                evaluation = {
                    'train': evaluate_regression(y, y_pred)
                }
        else:
            evaluation = {}
        
        # IMPORTANT: evaluation must be JSON string, not dict
        # Clean NaN/inf values before JSON encoding to prevent PostgreSQL errors
        clean_evaluation = force_json_compliant(evaluation, fill_value=None)
        data["evaluation"] = json.dumps(clean_evaluation, cls=NpEncoder)
        
        # Add training_metadata field (required by server)
        training_metadata = {
            i: v for i, v in model.metadata.items() if i != "evaluation"} if hasattr(model, 'metadata') else {}
        
        # Clean training_metadata before JSON encoding
        clean_training_metadata = force_json_compliant(training_metadata, fill_value=None)
        data["training_metadata"] = json.dumps(clean_training_metadata, cls=NpEncoder)
        
        # Add health_info - server always expects this field
        if x is not None:
            from xplainable.quality.scanner import XScan
            scanner = XScan()
            scanner.scan(x)
            
            results = []
            for i, v in scanner.profile.items():
                feature_info = {
                    "feature": i,
                    "description": '',
                    "type": v['type'],
                    "health_info": json.loads(json.dumps(v, cls=NpEncoder))
                }
                results.append(feature_info)
            
            # Clean health_info before JSON encoding to prevent NaN issues
            clean_results = force_json_compliant(results, fill_value=None)
            data["health_info"] = json.dumps(clean_results, cls=NpEncoder)
        else:
            # Provide empty health_info if x is None
            data["health_info"] = json.dumps([], cls=NpEncoder)
        
        return data