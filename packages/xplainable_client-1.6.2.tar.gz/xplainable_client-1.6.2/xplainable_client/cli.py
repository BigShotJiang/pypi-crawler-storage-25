"""
xplainable CLI -- agent-optimised command-line interface.

Usage:
    xp <service> <action> [args] [--pretty] [--quiet]

Authentication:
    export XPLAINABLE_API_KEY=xp_...
    export XPLAINABLE_HOST=https://platform.xplainable.io  # optional

    Or pass inline: xp --api-key xp_... models list
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

__version__ = "0.1.0"

# Exit codes
EXIT_SUCCESS = 0
EXIT_FAILURE = 1
EXIT_USAGE = 2
EXIT_NOT_FOUND = 3
EXIT_AUTH = 4


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _serialize(obj: Any) -> Any:
    """Convert API response objects to JSON-serializable form."""
    if obj is None:
        return None
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if isinstance(obj, list):
        return [_serialize(item) for item in obj]
    if isinstance(obj, tuple):
        return [_serialize(item) for item in obj]
    if hasattr(obj, "hex"):  # UUID
        return str(obj)
    if hasattr(obj, "to_dict"):  # DataFrame
        return obj.to_dict("records")
    return obj


def _output(data: Any, pretty: bool = False, quiet: bool = False) -> None:
    """Write serialized data to stdout."""
    serialized = _serialize(data)
    if quiet:
        if isinstance(serialized, list):
            for item in serialized:
                if isinstance(item, dict):
                    print(json.dumps(item, default=str))
                else:
                    print(item)
        elif isinstance(serialized, dict):
            for k, v in serialized.items():
                print(f"{k}\t{v}")
        else:
            print(serialized)
    else:
        print(json.dumps(serialized, indent=2 if pretty else None, default=str))


def _error(msg: str) -> None:
    """Write error to stderr."""
    print(f"Error: {msg}", file=sys.stderr)


def _read_json(path: str) -> Any:
    """Read JSON from a file path or parse an inline JSON string."""
    if os.path.isfile(path):
        with open(path) as f:
            return json.load(f)
    try:
        return json.loads(path)
    except json.JSONDecodeError:
        raise ValueError(f"Not a valid JSON file or string: {path}")


def _read_csv(path: str):
    """Lazy-import pandas and read CSV."""
    import pandas as pd

    return pd.read_csv(path)


def _make_client(args: argparse.Namespace):
    """Instantiate XplainableClient from args / environment variables."""
    from xplainable_client.client import XplainableClient

    api_key = getattr(args, "api_key", None) or os.environ.get("XPLAINABLE_API_KEY")
    if not api_key:
        _error("No API key. Set XPLAINABLE_API_KEY or pass --api-key.")
        sys.exit(EXIT_AUTH)

    hostname = (
        getattr(args, "host", None)
        or os.environ.get("XPLAINABLE_HOST", "https://platform.xplainable.io")
    )
    team_id = os.environ.get("XPLAINABLE_TEAM_ID")

    # Redirect stdout -> stderr during init so connection banner
    # doesn't pollute JSON output.
    _real_stdout = sys.stdout
    sys.stdout = sys.stderr
    try:
        client = XplainableClient(
            api_key=api_key, hostname=hostname, team_id=team_id
        )
    except Exception as e:
        sys.stdout = _real_stdout
        _error(str(e))
        sys.exit(EXIT_AUTH)
    finally:
        sys.stdout = _real_stdout

    return client


# ---------------------------------------------------------------------------
# Preprocessing handlers
# ---------------------------------------------------------------------------

def _preprocessing_list(client, args):
    return client.preprocessing.list_preprocessors(
        team_id=getattr(args, "team_id", None)
    )


def _preprocessing_get(client, args):
    return client.preprocessing.get_preprocessor(args.preprocessor_id)


def _preprocessing_create(client, args):
    spec = _read_json(args.spec)
    df = _read_csv(args.data) if args.data else None
    pp_id, v_id = client.preprocessing.create_preprocessor(
        name=args.name, description=args.description, spec=spec, sample_df=df,
    )
    return {"preprocessor_id": pp_id, "version_id": v_id}


def _preprocessing_add_version(client, args):
    spec = _read_json(args.spec)
    df = _read_csv(args.data) if args.data else None
    v_id = client.preprocessing.add_version(
        preprocessor_id=args.preprocessor_id, spec=spec, sample_df=df,
    )
    return {"version_id": v_id}


def _preprocessing_delete(client, args):
    return client.preprocessing.delete_preprocessor(args.preprocessor_id)


def _preprocessing_delete_version(client, args):
    return client.preprocessing.delete_version(args.version_id)


# ---------------------------------------------------------------------------
# Models handlers
# ---------------------------------------------------------------------------

def _models_list(client, _args):
    return client.models.list_team_models()


def _models_get(client, args):
    return client.models.get_model(args.model_id)


def _models_versions(client, args):
    return client.models.list_model_versions(args.model_id)


def _models_partitions(client, args):
    return client.models.list_model_version_partitions(args.version_id)


def _models_link_preprocessor(client, args):
    return client.models.link_preprocessor(
        args.model_version_id, args.preprocessor_version_id
    )


# ---------------------------------------------------------------------------
# Deployments handlers
# ---------------------------------------------------------------------------

def _deployments_list(client, args):
    return client.deployments.list_deployments(
        team_id=getattr(args, "team_id", None)
    )


def _deployments_create(client, args):
    return client.deployments.deploy(args.model_version_id)


def _deployments_activate(client, args):
    return client.deployments.activate_deployment(args.deployment_id)


def _deployments_deactivate(client, args):
    return client.deployments.deactivate_deployment(args.deployment_id)


def _deployments_delete(client, args):
    return client.deployments.delete_deployment(args.deployment_id)


def _deployments_payload(client, args):
    return client.deployments.get_deployment_payload(args.deployment_id)


def _deployments_create_key(client, args):
    return client.deployments.generate_deploy_key(
        deployment_id=args.deployment_id,
        description=args.description or "",
        days_until_expiry=args.expiry_days,
    )


def _deployments_list_keys(client, args):
    return client.deployments.list_deploy_keys(args.deployment_id)


def _deployments_active_key_count(client, args):
    return client.deployments.get_active_team_deploy_keys_count(
        team_id=getattr(args, "team_id", None)
    )


# ---------------------------------------------------------------------------
# Inference handlers
# ---------------------------------------------------------------------------

def _inference_predict(client, args):
    return client.inference.predict(
        filename=args.file,
        model_id=args.model_id,
        version_id=args.version_id,
        threshold=args.threshold,
    )


def _inference_stream(client, args):
    results = list(
        client.inference.stream_predictions(
            filename=args.file,
            model_id=args.model_id,
            version_id=args.version_id,
            threshold=args.threshold,
            batch_size=args.batch_size,
        )
    )
    return results


# ---------------------------------------------------------------------------
# Autotrain handlers
# ---------------------------------------------------------------------------

def _autotrain_summarize(client, args):
    return client.autotrain.summarize_dataset(
        file_path=args.file, team_id=getattr(args, "team_id", None),
    )


def _autotrain_goals(client, args):
    from xplainable_client.client.py_models.autotrain import DatasetSummary

    summary = DatasetSummary(**_read_json(args.summary))
    return client.autotrain.generate_goals(summary=summary, n=args.n)


def _autotrain_labels(client, args):
    from xplainable_client.client.py_models.autotrain import DatasetSummary

    summary = DatasetSummary(**_read_json(args.summary))
    return client.autotrain.generate_labels(summary=summary)


def _autotrain_features(client, args):
    from xplainable_client.client.py_models.autotrain import DatasetSummary

    summary = DatasetSummary(**_read_json(args.summary))
    return client.autotrain.generate_feature_engineering(
        summary=summary, n=args.n,
    )


def _autotrain_insights(client, args):
    from xplainable_client.client.py_models.autotrain import DatasetSummary

    summary = DatasetSummary(**_read_json(args.summary))
    goal = _read_json(args.goal) if args.goal else {}
    return client.autotrain.generate_insights(goal=goal, summary=summary)


def _autotrain_start(client, args):
    from xplainable_client.client.py_models.autotrain import DatasetSummary

    summary = DatasetSummary(**_read_json(args.summary))
    return client.autotrain.start_autotrain(
        model_name=args.model_name,
        model_description=args.model_description,
        summary=summary,
        team_id=getattr(args, "team_id", None),
    )


def _autotrain_train(client, args):
    config = _read_json(args.config)
    return client.autotrain.train_manual(
        label=config["label"],
        model_name=config["model_name"],
        model_description=config["model_description"],
        preprocessor_id=config["preprocessor_id"],
        version_id=config["version_id"],
        team_id=getattr(args, "team_id", None),
        drop_columns=config.get("drop_columns"),
    )


def _autotrain_status(client, args):
    return client.autotrain.check_training_status(args.run_id)


def _autotrain_visualize(client, args):
    from xplainable_client.client.py_models.autotrain import DatasetSummary

    summary = DatasetSummary(**_read_json(args.summary))
    goal = _read_json(args.goal) if args.goal else {}
    return client.autotrain.visualize_data(
        summary=summary, goal=goal, library=args.library,
    )


# ---------------------------------------------------------------------------
# Datasets handlers
# ---------------------------------------------------------------------------

def _datasets_list(client, _args):
    return client.datasets.list_datasets()


def _datasets_list_team(client, _args):
    return client.datasets.list_team_datasets()


def _datasets_load(client, args):
    return client.datasets.load_dataset(args.name)


# ---------------------------------------------------------------------------
# Collections handlers
# ---------------------------------------------------------------------------

def _collections_list(client, args):
    model_id = getattr(args, "model_id", None)
    if model_id:
        return client.monitors.get_model_monitors(model_id)
    return client.monitors.get_team_monitors()


def _collections_list_team(client, _args):
    return client.monitors.get_team_monitors()


def _collections_create(client, args):
    return client.monitors.create_monitor(
        model_id=args.model_id, name=args.name,
        description=args.description or "",
    )


def _collections_delete(client, args):
    return client.monitors.delete_monitor(args.collection_id)


def _collections_scenarios(client, args):
    return client.monitors.get_monitor(args.collection_id)


def _collections_create_scenarios(client, args):
    scenarios = _read_json(args.scenarios)
    return client.monitors.add_monitor_items(args.collection_id, scenarios)


# ---------------------------------------------------------------------------
# Reports (GPT) handlers
# ---------------------------------------------------------------------------

def _reports_generate(client, args):
    return client.gpt.generate_report(
        model_id=args.model_id,
        version_id=args.version_id,
        project_objective=args.objective,
        max_features=args.max_features,
    )


def _reports_explain(client, args):
    return client.gpt.explain_model(
        model_id=args.model_id,
        version_id=args.version_id,
        language=args.language,
        detail_level=args.detail,
    )


def _reports_docs(client, args):
    return client.gpt.generate_documentation(
        model_id=args.model_id, version_id=args.version_id,
    )


# ---------------------------------------------------------------------------
# System handlers
# ---------------------------------------------------------------------------

def _system_ping(client, args):
    if getattr(args, "gateway", False):
        return client.misc.ping_gateway()
    return client.misc.ping_server()


def _system_health(client, _args):
    return client.misc.health_check()


def _system_version(_client, _args):
    """Show local version info (no auth required)."""
    try:
        import xplainable

        xp_ver = xplainable.__version__
    except (ImportError, AttributeError):
        xp_ver = "not installed"

    vi = sys.version_info
    return {
        "cli_version": __version__,
        "xplainable_version": xp_ver,
        "python_version": f"{vi.major}.{vi.minor}.{vi.micro}",
    }


def _system_info(client, args):
    return client.misc.get_model_info(args.model_id, args.version_id)


# ---------------------------------------------------------------------------
# Runs handlers
# ---------------------------------------------------------------------------

def _runs_create(client, args):
    metadata = _read_json(args.metadata) if args.metadata else None
    return client.runs.create_run(
        team_id=client.session.team_id,
        user_id=client.session.user_data.get("user_id", ""),
        name=args.name,
        metadata=metadata,
    )


def _runs_get(client, args):
    return client.runs.get_run(args.run_id)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="xp",
        description="xplainable CLI -- agent-optimised interface to xplainable cloud",
    )
    parser.add_argument(
        "--api-key", dest="api_key",
        help="API key (or set XPLAINABLE_API_KEY)",
    )
    parser.add_argument(
        "--host", help="API hostname (or set XPLAINABLE_HOST)",
    )
    parser.add_argument(
        "--pretty", action="store_true", help="Pretty-print JSON output",
    )
    parser.add_argument(
        "-q", "--quiet", action="store_true",
        help="Bare values, no JSON wrapping",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}",
    )

    svc = parser.add_subparsers(dest="service", help="Service to interact with")

    # ── Preprocessing ─────────────────────────────────────────────────────
    pp = svc.add_parser("preprocessing", help="Manage preprocessing pipelines")
    pp_sub = pp.add_subparsers(dest="action")

    p = pp_sub.add_parser("list", help="List preprocessors")
    p.add_argument("--team-id", dest="team_id")
    p.set_defaults(func=_preprocessing_list)

    p = pp_sub.add_parser("get", help="Get preprocessor details")
    p.add_argument("preprocessor_id")
    p.set_defaults(func=_preprocessing_get)

    p = pp_sub.add_parser("create", help="Create a preprocessor")
    p.add_argument("--name", required=True)
    p.add_argument("--description", required=True)
    p.add_argument("--spec", required=True, help="Path to spec JSON file")
    p.add_argument("--data", help="Path to sample CSV file")
    p.set_defaults(func=_preprocessing_create)

    p = pp_sub.add_parser("add-version", help="Add version to preprocessor")
    p.add_argument("preprocessor_id")
    p.add_argument("--spec", required=True, help="Path to spec JSON file")
    p.add_argument("--data", help="Path to sample CSV file")
    p.set_defaults(func=_preprocessing_add_version)

    p = pp_sub.add_parser("delete", help="Delete a preprocessor")
    p.add_argument("preprocessor_id")
    p.set_defaults(func=_preprocessing_delete)

    p = pp_sub.add_parser("delete-version", help="Delete a preprocessor version")
    p.add_argument("version_id")
    p.set_defaults(func=_preprocessing_delete_version)

    # ── Models ────────────────────────────────────────────────────────────
    m = svc.add_parser("models", help="Manage ML models")
    m_sub = m.add_subparsers(dest="action")

    p = m_sub.add_parser("list", help="List team models")
    p.set_defaults(func=_models_list)

    p = m_sub.add_parser("get", help="Get model details")
    p.add_argument("model_id")
    p.set_defaults(func=_models_get)

    p = m_sub.add_parser("versions", help="List model versions")
    p.add_argument("model_id")
    p.set_defaults(func=_models_versions)

    p = m_sub.add_parser("partitions", help="List version partitions")
    p.add_argument("version_id")
    p.set_defaults(func=_models_partitions)

    p = m_sub.add_parser("link-preprocessor", help="Link model version to preprocessor")
    p.add_argument("model_version_id")
    p.add_argument("preprocessor_version_id")
    p.set_defaults(func=_models_link_preprocessor)

    # ── Deployments ───────────────────────────────────────────────────────
    d = svc.add_parser("deployments", help="Manage deployments")
    d_sub = d.add_subparsers(dest="action")

    p = d_sub.add_parser("list", help="List deployments")
    p.add_argument("--team-id", dest="team_id")
    p.set_defaults(func=_deployments_list)

    p = d_sub.add_parser("create", help="Deploy a model version")
    p.add_argument("model_version_id")
    p.set_defaults(func=_deployments_create)

    p = d_sub.add_parser("activate", help="Activate a deployment")
    p.add_argument("deployment_id")
    p.set_defaults(func=_deployments_activate)

    p = d_sub.add_parser("deactivate", help="Deactivate a deployment")
    p.add_argument("deployment_id")
    p.set_defaults(func=_deployments_deactivate)

    p = d_sub.add_parser("delete", help="Delete a deployment")
    p.add_argument("deployment_id")
    p.set_defaults(func=_deployments_delete)

    p = d_sub.add_parser("payload", help="Get deployment sample payload")
    p.add_argument("deployment_id")
    p.set_defaults(func=_deployments_payload)

    p = d_sub.add_parser("create-key", help="Generate a deploy key")
    p.add_argument("deployment_id")
    p.add_argument("--description", default="")
    p.add_argument("--expiry-days", dest="expiry_days", type=int, default=90)
    p.set_defaults(func=_deployments_create_key)

    p = d_sub.add_parser("list-keys", help="List deploy keys")
    p.add_argument("deployment_id")
    p.set_defaults(func=_deployments_list_keys)

    p = d_sub.add_parser("active-key-count", help="Count active deploy keys")
    p.add_argument("--team-id", dest="team_id")
    p.set_defaults(func=_deployments_active_key_count)

    # ── Inference ─────────────────────────────────────────────────────────
    inf = svc.add_parser("inference", help="Model inference")
    inf_sub = inf.add_subparsers(dest="action")

    p = inf_sub.add_parser("predict", help="Predict from CSV file")
    p.add_argument("file", help="Path to CSV file")
    p.add_argument("--model-id", dest="model_id", required=True)
    p.add_argument("--version-id", dest="version_id", required=True)
    p.add_argument("--threshold", type=float, default=0.5)
    p.set_defaults(func=_inference_predict)

    p = inf_sub.add_parser("stream", help="Stream predictions in batches")
    p.add_argument("file", help="Path to CSV file")
    p.add_argument("--model-id", dest="model_id", required=True)
    p.add_argument("--version-id", dest="version_id", required=True)
    p.add_argument("--threshold", type=float, default=0.5)
    p.add_argument("--batch-size", dest="batch_size", type=int, default=1000)
    p.set_defaults(func=_inference_stream)

    # ── Autotrain ─────────────────────────────────────────────────────────
    at = svc.add_parser("autotrain", help="Automated training workflows")
    at_sub = at.add_subparsers(dest="action")

    p = at_sub.add_parser("summarize", help="Summarize a dataset")
    p.add_argument("file", help="Path to dataset file")
    p.add_argument("--team-id", dest="team_id")
    p.set_defaults(func=_autotrain_summarize)

    p = at_sub.add_parser("goals", help="Generate training goals")
    p.add_argument("summary", help="Path to summary JSON or inline JSON")
    p.add_argument("--n", type=int, default=5, help="Number of goals")
    p.set_defaults(func=_autotrain_goals)

    p = at_sub.add_parser("labels", help="Generate label recommendations")
    p.add_argument("summary", help="Path to summary JSON or inline JSON")
    p.set_defaults(func=_autotrain_labels)

    p = at_sub.add_parser("features", help="Generate feature engineering ideas")
    p.add_argument("summary", help="Path to summary JSON or inline JSON")
    p.add_argument("--n", type=int, default=5, help="Number of recommendations")
    p.set_defaults(func=_autotrain_features)

    p = at_sub.add_parser("insights", help="Generate dataset insights")
    p.add_argument("summary", help="Path to summary JSON or inline JSON")
    p.add_argument("--goal", help="Path to goal JSON or inline JSON")
    p.set_defaults(func=_autotrain_insights)

    p = at_sub.add_parser("start", help="Start autotrain")
    p.add_argument("summary", help="Path to summary JSON or inline JSON")
    p.add_argument("--model-name", dest="model_name", required=True)
    p.add_argument("--model-description", dest="model_description", required=True)
    p.add_argument("--team-id", dest="team_id")
    p.set_defaults(func=_autotrain_start)

    p = at_sub.add_parser("train", help="Manual training from config")
    p.add_argument("config", help="Path to training config JSON")
    p.add_argument("--team-id", dest="team_id")
    p.set_defaults(func=_autotrain_train)

    p = at_sub.add_parser("status", help="Check training status")
    p.add_argument("run_id")
    p.set_defaults(func=_autotrain_status)

    p = at_sub.add_parser("visualize", help="Generate data visualizations")
    p.add_argument("summary", help="Path to summary JSON or inline JSON")
    p.add_argument("--goal", help="Path to goal JSON or inline JSON")
    p.add_argument(
        "--library", default="plotly",
        choices=["plotly", "matplotlib", "seaborn"],
    )
    p.set_defaults(func=_autotrain_visualize)

    # ── Datasets ──────────────────────────────────────────────────────────
    ds = svc.add_parser("datasets", help="Manage datasets")
    ds_sub = ds.add_subparsers(dest="action")

    p = ds_sub.add_parser("list", help="List public datasets")
    p.set_defaults(func=_datasets_list)

    p = ds_sub.add_parser("list-team", help="List team datasets")
    p.set_defaults(func=_datasets_list_team)

    p = ds_sub.add_parser("load", help="Load a public dataset")
    p.add_argument("name")
    p.set_defaults(func=_datasets_load)

    # ── Collections ───────────────────────────────────────────────────────
    col = svc.add_parser("collections", help="Manage model collections")
    col_sub = col.add_subparsers(dest="action")

    p = col_sub.add_parser("list", help="List collections")
    p.add_argument("--model-id", dest="model_id", help="Filter by model ID")
    p.set_defaults(func=_collections_list)

    p = col_sub.add_parser("list-team", help="List team collections")
    p.set_defaults(func=_collections_list_team)

    p = col_sub.add_parser("create", help="Create a collection")
    p.add_argument("--model-id", dest="model_id", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--description", default="")
    p.set_defaults(func=_collections_create)

    p = col_sub.add_parser("delete", help="Delete a collection")
    p.add_argument("model_id")
    p.add_argument("collection_id")
    p.set_defaults(func=_collections_delete)

    p = col_sub.add_parser("scenarios", help="List collection scenarios")
    p.add_argument("collection_id")
    p.set_defaults(func=_collections_scenarios)

    p = col_sub.add_parser("create-scenarios", help="Create scenarios")
    p.add_argument("collection_id")
    p.add_argument("--scenarios", required=True, help="Path to scenarios JSON")
    p.set_defaults(func=_collections_create_scenarios)

    # ── Reports (GPT) ────────────────────────────────────────────────────
    rpt = svc.add_parser("reports", help="GPT-powered reports and explanations")
    rpt_sub = rpt.add_subparsers(dest="action")

    p = rpt_sub.add_parser("generate", help="Generate model report")
    p.add_argument("model_id")
    p.add_argument("version_id")
    p.add_argument("--objective", default="text")
    p.add_argument("--max-features", dest="max_features", type=int, default=15)
    p.set_defaults(func=_reports_generate)

    p = rpt_sub.add_parser("explain", help="Explain model in natural language")
    p.add_argument("model_id")
    p.add_argument("version_id")
    p.add_argument("--language", default="en")
    p.add_argument(
        "--detail", default="medium", choices=["low", "medium", "high"],
    )
    p.set_defaults(func=_reports_explain)

    p = rpt_sub.add_parser("docs", help="Generate model documentation")
    p.add_argument("model_id")
    p.add_argument("version_id")
    p.set_defaults(func=_reports_docs)

    # ── System (top-level commands) ───────────────────────────────────────
    p = svc.add_parser("ping", help="Ping server connectivity")
    p.add_argument("--gateway", action="store_true", help="Ping API gateway")
    p.set_defaults(func=_system_ping)

    p = svc.add_parser("health", help="Comprehensive health check")
    p.set_defaults(func=_system_health)

    p = svc.add_parser("version", help="Show version info")
    p.set_defaults(func=_system_version, no_auth=True)

    p = svc.add_parser("info", help="Get model info without loading")
    p.add_argument("model_id")
    p.add_argument("version_id")
    p.set_defaults(func=_system_info)

    # ── Runs ──────────────────────────────────────────────────────────────
    r = svc.add_parser("runs", help="Manage training runs")
    r_sub = r.add_subparsers(dest="action")

    p = r_sub.add_parser("create", help="Create a training run")
    p.add_argument("--name")
    p.add_argument("--metadata", help="Path to metadata JSON or inline JSON")
    p.set_defaults(func=_runs_create)

    p = r_sub.add_parser("get", help="Get run details")
    p.add_argument("run_id")
    p.set_defaults(func=_runs_get)

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if not hasattr(args, "func"):
        if args.service:
            _error(f"No action specified. Run: xp {args.service} --help")
        else:
            parser.print_help(sys.stderr)
        sys.exit(EXIT_USAGE)

    try:
        no_auth = getattr(args, "no_auth", False)
        client = None if no_auth else _make_client(args)
        result = args.func(client, args)
        _output(
            result,
            pretty=getattr(args, "pretty", False),
            quiet=getattr(args, "quiet", False),
        )
    except SystemExit:
        raise
    except Exception as e:
        _error(str(e))
        code = getattr(e, "status_code", None)
        if code in (401, 403):
            sys.exit(EXIT_AUTH)
        elif code == 404:
            sys.exit(EXIT_NOT_FOUND)
        elif code is not None:
            sys.exit(EXIT_FAILURE)
        else:
            sys.exit(EXIT_FAILURE)


if __name__ == "__main__":
    main()
