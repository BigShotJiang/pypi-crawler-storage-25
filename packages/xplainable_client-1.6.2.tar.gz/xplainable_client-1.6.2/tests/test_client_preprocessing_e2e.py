"""
E2E test: exercise the PreprocessingClient against a running API.

Tests the full spec-based preprocessing lifecycle through the client SDK:
create, get version, load pipeline, fit, preview, add version, list, cleanup.

Run: python tests/test_client_preprocessing_e2e.py
"""

import sys
import time
import traceback

import pandas as pd

# -- Config --
API_KEY = "5a5b02d2-5148-4411-9aff-2c0154ab796e"
HOSTNAME = "http://localhost:8000"
TEAM_ID = "IeQF3SJz2Nk6jPeh"


# -- Sample data --
SAMPLE_DF = pd.DataFrame({
    "age": [25, 30, 35, None, 45, 22],
    "salary": [50000, 65000, 80000, 55000, 120000, 42000],
    "score": [85.5, 92.1, 78.3, None, 88.7, 71.2],
    "rating": [4.2, 3.8, 4.5, 3.1, 4.9, 2.8],
})

SIMPLE_SPEC = {
    "version": "2.0",
    "steps": [
        {"id": "impute", "type": "FillMissingTransformer", "params": {"strategies": {"age": "mean", "score": "median"}, "default": "mean"}},
        {"id": "scale", "type": "StandardScaler", "columns": ["salary", "score"], "params": {}},
    ],
}

UPDATED_SPEC = {
    "version": "2.0",
    "steps": [
        {"id": "impute", "type": "FillMissingTransformer", "params": {"strategies": {"age": "mean", "score": "median"}, "default": "mean"}},
        {"id": "scale", "type": "StandardScaler", "columns": ["salary", "score"], "params": {}},
        {"id": "expr", "type": "ExpressionTransformer", "params": {"expression": "age * rating", "output_column": "age_x_rating"}},
    ],
}


# -- Tests --

def test_create_preprocessor(client):
    """Test 1: Create a preprocessor via spec + sample data."""
    pp_id, v_id = client.preprocessing.create_preprocessor(
        name=f"client_test_{int(time.time())}",
        description="Client SDK E2E test",
        spec=SIMPLE_SPEC,
        sample_df=SAMPLE_DF,
    )
    assert pp_id, "preprocessor_id should be non-empty"
    assert v_id, "version_id should be non-empty"
    return pp_id, v_id


def test_get_version(client, version_id):
    """Test 2: Get version metadata and verify schemas."""
    version = client.preprocessing.get_version(version_id)
    assert version.get("spec"), "spec should be present"
    assert version.get("input_schema"), "input_schema should be present"
    assert version.get("output_schema"), "output_schema should be present"
    output_cols = [c["name"] for c in version["output_schema"]["columns"]]
    assert "salary" in output_cols, f"salary missing from output: {output_cols}"
    assert "score" in output_cols, f"score missing from output: {output_cols}"
    return version


def test_load_pipeline(client, version_id):
    """Test 3: Load the fitted pipeline and transform data."""
    pipeline = client.preprocessing.load_pipeline(version_id)
    result = pipeline.transform(SAMPLE_DF.copy())
    assert isinstance(result, pd.DataFrame), "transform should return a DataFrame"
    assert len(result) == len(SAMPLE_DF), "row count should match"
    # Imputed columns should have no nulls
    assert result["age"].isna().sum() == 0, "age should be imputed (no nulls)"
    assert result["score"].isna().sum() == 0, "score should be imputed (no nulls)"
    return result


def test_preview(client, version_id):
    """Test 4: Preview endpoint returns step deltas and samples."""
    preview = client.preprocessing.preview(version_id, SAMPLE_DF.head(3))
    assert "input_schema" in preview, "preview should have input_schema"
    assert "output_schema" in preview, "preview should have output_schema"
    assert "step_deltas" in preview, "preview should have step_deltas"
    assert "sample_before" in preview, "preview should have sample_before"
    assert "sample_after" in preview, "preview should have sample_after"
    assert len(preview["step_deltas"]) == 2, f"expected 2 step deltas, got {len(preview['step_deltas'])}"
    return preview


def test_fit_version(client, version_id):
    """Test 5: Fit version with fresh data."""
    result = client.preprocessing.fit_version(version_id, SAMPLE_DF)
    assert result.get("input_schema"), "fit should return input_schema"
    assert result.get("output_schema"), "fit should return output_schema"
    return result


def test_add_version(client, preprocessor_id, parent_version_id):
    """Test 6: Add a second version with lineage."""
    new_v_id = client.preprocessing.add_version(
        preprocessor_id=preprocessor_id,
        spec=UPDATED_SPEC,
        sample_df=SAMPLE_DF,
        parent_version_id=parent_version_id,
    )
    assert new_v_id, "new version_id should be non-empty"

    # Verify the new version has the expression step
    version = client.preprocessing.get_version(new_v_id)
    output_cols = [c["name"] for c in version["output_schema"]["columns"]]
    assert "age_x_rating" in output_cols, f"age_x_rating missing from output: {output_cols}"
    assert version.get("parent_version_id") == parent_version_id, "parent_version_id should match"
    return new_v_id


def test_update_version(client, version_id):
    """Test 7: Update an existing version's spec."""
    updated_v_id = client.preprocessing.update_version(
        version_id=version_id,
        spec=UPDATED_SPEC,
        sample_df=SAMPLE_DF,
    )
    assert updated_v_id, "updated version_id should be non-empty"

    version = client.preprocessing.get_version(updated_v_id)
    output_cols = [c["name"] for c in version["output_schema"]["columns"]]
    assert "age_x_rating" in output_cols, f"age_x_rating missing after update: {output_cols}"
    return updated_v_id


def test_list_preprocessors(client, preprocessor_id):
    """Test 8: List preprocessors for the team."""
    preprocessors = client.preprocessing.list_preprocessors()
    assert isinstance(preprocessors, list), "should return a list"
    ids = [p.id for p in preprocessors]
    assert preprocessor_id in ids, f"created preprocessor {preprocessor_id} not in list: {ids}"
    return preprocessors


def test_create_from_pipeline(client):
    """Test 9: Create a preprocessor from a fitted DataFramePipeline object."""
    from xplainable_preprocessing import compile_spec, PipelineSpec

    spec = PipelineSpec(**SIMPLE_SPEC)
    pipeline = compile_spec(spec)
    pipeline.fit(SAMPLE_DF.copy())

    pp_id, v_id = client.preprocessing.create_from_pipeline(
        name=f"client_pipeline_test_{int(time.time())}",
        description="From fitted pipeline",
        pipeline=pipeline,
        df=SAMPLE_DF,
    )
    assert pp_id, "preprocessor_id should be non-empty"
    assert v_id, "version_id should be non-empty"

    # Load it back and verify it works
    loaded = client.preprocessing.load_pipeline(v_id)
    result = loaded.transform(SAMPLE_DF.copy())
    assert result["age"].isna().sum() == 0, "loaded pipeline should impute age"
    return pp_id, v_id


def test_get_preprocessor(client, preprocessor_id):
    """Test 10: Get preprocessor details."""
    info = client.preprocessing.get_preprocessor(preprocessor_id)
    assert info.id == preprocessor_id
    assert info.name, "name should be non-empty"
    return info


def test_delete_version(client, version_id):
    """Test 11: Delete a preprocessor version."""
    result = client.preprocessing.delete_version(version_id)
    # Verify it's gone
    from xplainable_client.client.base import XplainableAPIError
    try:
        client.preprocessing.get_version(version_id)
        raise AssertionError("version should be deleted but get_version succeeded")
    except XplainableAPIError as e:
        assert e.status_code == 404, f"expected 404 after delete, got {e.status_code}"
    return result


def test_delete_preprocessor(client, preprocessor_id):
    """Test 12: Delete a preprocessor."""
    result = client.preprocessing.delete_preprocessor(preprocessor_id)
    # Verify it's gone from the list
    preprocessors = client.preprocessing.list_preprocessors()
    ids = [p.id for p in preprocessors]
    assert preprocessor_id not in ids, f"deleted preprocessor still in list: {ids}"
    return result


# -- Runner --

def main():
    # Import client
    try:
        from xplainable_client import Client
    except ImportError:
        print("ERROR: xplainable_client not importable. Install it first.")
        sys.exit(1)

    # Connect
    print(f"Connecting to {HOSTNAME}...")
    try:
        client = Client(
            api_key=API_KEY,
            hostname=HOSTNAME,
            team_id=TEAM_ID,
        )
    except Exception as e:
        print(f"ERROR: Failed to connect: {e}")
        sys.exit(1)

    print(f"\nRunning client preprocessing E2E tests\n")

    passed = 0
    failed = 0
    failures = []
    created_resources = []  # (preprocessor_id, [version_ids])

    # Test 1: Create
    try:
        pp_id, v_id = test_create_preprocessor(client)
        created_resources.append((pp_id, [v_id]))
        print(f"  PASS  1. Create preprocessor (pp={pp_id[:8]}..., v={v_id[:8]}...)")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("1. Create preprocessor", str(e)))
        print(f"  FAIL  1. Create preprocessor — {e}")
        traceback.print_exc()
        print("\nCannot continue without a preprocessor. Exiting.")
        sys.exit(1)

    # Test 2: Get version
    try:
        test_get_version(client, v_id)
        print(f"  PASS  2. Get version")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("2. Get version", str(e)))
        print(f"  FAIL  2. Get version — {e}")

    # Test 3: Load pipeline
    try:
        test_load_pipeline(client, v_id)
        print(f"  PASS  3. Load pipeline & transform")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("3. Load pipeline", str(e)))
        print(f"  FAIL  3. Load pipeline — {e}")

    # Test 4: Preview
    try:
        test_preview(client, v_id)
        print(f"  PASS  4. Preview")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("4. Preview", str(e)))
        print(f"  FAIL  4. Preview — {e}")

    # Test 5: Fit version
    try:
        test_fit_version(client, v_id)
        print(f"  PASS  5. Fit version")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("5. Fit version", str(e)))
        print(f"  FAIL  5. Fit version — {e}")

    # Test 6: Add version with lineage
    v2_id = None
    try:
        v2_id = test_add_version(client, pp_id, v_id)
        created_resources[0][1].append(v2_id)
        print(f"  PASS  6. Add version with lineage (v2={v2_id[:8]}...)")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("6. Add version", str(e)))
        print(f"  FAIL  6. Add version — {e}")

    # Test 7: Update version
    try:
        test_update_version(client, v_id)
        print(f"  PASS  7. Update version")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("7. Update version", str(e)))
        print(f"  FAIL  7. Update version — {e}")

    # Test 8: List preprocessors
    try:
        test_list_preprocessors(client, pp_id)
        print(f"  PASS  8. List preprocessors")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("8. List preprocessors", str(e)))
        print(f"  FAIL  8. List preprocessors — {e}")

    # Test 9: Create from pipeline
    try:
        pp_id2, v_id2 = test_create_from_pipeline(client)
        created_resources.append((pp_id2, [v_id2]))
        print(f"  PASS  9. Create from pipeline (pp={pp_id2[:8]}..., v={v_id2[:8]}...)")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("9. Create from pipeline", str(e)))
        print(f"  FAIL  9. Create from pipeline — {e}")

    # Test 10: Get preprocessor
    try:
        test_get_preprocessor(client, pp_id)
        print(f"  PASS  10. Get preprocessor")
        passed += 1
    except Exception as e:
        failed += 1
        failures.append(("10. Get preprocessor", str(e)))
        print(f"  FAIL  10. Get preprocessor — {e}")

    # Test 11: Delete version (delete v2 specifically)
    if v2_id:
        try:
            test_delete_version(client, v2_id)
            created_resources[0][1].remove(v2_id)
            print(f"  PASS  11. Delete version")
            passed += 1
        except Exception as e:
            failed += 1
            failures.append(("11. Delete version", str(e)))
            print(f"  FAIL  11. Delete version — {e}")
    else:
        print(f"  SKIP  11. Delete version (no v2 to delete)")

    # Test 12: Delete preprocessor (deletes pp2 from create_from_pipeline)
    if len(created_resources) > 1:
        pp_id2 = created_resources[1][0]
        try:
            # Delete version first, then preprocessor
            for vid in created_resources[1][1]:
                client.preprocessing.delete_version(vid)
            test_delete_preprocessor(client, pp_id2)
            created_resources.pop(1)
            print(f"  PASS  12. Delete preprocessor")
            passed += 1
        except Exception as e:
            failed += 1
            failures.append(("12. Delete preprocessor", str(e)))
            print(f"  FAIL  12. Delete preprocessor — {e}")
    else:
        print(f"  SKIP  12. Delete preprocessor (no second preprocessor)")

    # Cleanup remaining resources via client
    print(f"\nCleaning up...")
    for res_pp_id, res_v_ids in created_resources:
        for vid in res_v_ids:
            try:
                client.preprocessing.delete_version(vid)
            except Exception:
                pass
        try:
            client.preprocessing.delete_preprocessor(res_pp_id)
        except Exception:
            pass

    # Summary
    total = passed + failed
    print(f"\n{'='*60}")
    print(f"Results: {passed}/{total} passed, {failed} failed")
    if failures:
        print("\nFailures:")
        for name, detail in failures:
            print(f"  - {name}: {detail}")
    print(f"{'='*60}")
    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
