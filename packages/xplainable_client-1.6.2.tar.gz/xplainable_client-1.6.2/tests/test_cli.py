"""Tests for the xplainable CLI (xp command)."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from io import StringIO
from unittest import mock

import pytest

from xplainable_client.cli import (
    EXIT_AUTH,
    EXIT_FAILURE,
    EXIT_NOT_FOUND,
    EXIT_SUCCESS,
    EXIT_USAGE,
    _build_parser,
    _output,
    _read_json,
    _serialize,
    main,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _FakePydanticModel:
    """Stub that quacks like a Pydantic BaseModel."""
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def model_dump(self):
        return dict(self.__dict__)


class _FakeUUID:
    """Stub that quacks like a UUID."""
    def __init__(self, val):
        self._val = val
        self.hex = val.replace("-", "")

    def __str__(self):
        return self._val


class _FakeDataFrame:
    """Stub that quacks like a pandas DataFrame."""
    def __init__(self, records):
        self._records = records

    def to_dict(self, orient):
        assert orient == "records"
        return self._records


# ---------------------------------------------------------------------------
# _serialize
# ---------------------------------------------------------------------------

class TestSerialize:
    def test_none(self):
        assert _serialize(None) is None

    def test_pydantic_model(self):
        m = _FakePydanticModel(id="123", name="test")
        assert _serialize(m) == {"id": "123", "name": "test"}

    def test_list_of_models(self):
        models = [
            _FakePydanticModel(id="1"),
            _FakePydanticModel(id="2"),
        ]
        assert _serialize(models) == [{"id": "1"}, {"id": "2"}]

    def test_tuple(self):
        assert _serialize(("a", "b")) == ["a", "b"]

    def test_uuid(self):
        u = _FakeUUID("abc-def")
        assert _serialize(u) == "abc-def"

    def test_dataframe(self):
        df = _FakeDataFrame([{"a": 1}, {"a": 2}])
        assert _serialize(df) == [{"a": 1}, {"a": 2}]

    def test_dict_passthrough(self):
        d = {"key": "value"}
        assert _serialize(d) is d

    def test_string_passthrough(self):
        assert _serialize("hello") == "hello"

    def test_int_passthrough(self):
        assert _serialize(42) == 42


# ---------------------------------------------------------------------------
# _output
# ---------------------------------------------------------------------------

class TestOutput:
    def test_json_compact(self, capsys):
        _output({"a": 1, "b": 2})
        out = capsys.readouterr().out.strip()
        assert json.loads(out) == {"a": 1, "b": 2}
        assert "\n" not in out  # compact

    def test_json_pretty(self, capsys):
        _output({"a": 1}, pretty=True)
        out = capsys.readouterr().out.strip()
        assert json.loads(out) == {"a": 1}
        assert "\n" in out  # indented

    def test_quiet_list(self, capsys):
        _output(["one", "two", "three"], quiet=True)
        lines = capsys.readouterr().out.strip().split("\n")
        assert lines == ["one", "two", "three"]

    def test_quiet_dict(self, capsys):
        _output({"name": "test", "id": 42}, quiet=True)
        lines = capsys.readouterr().out.strip().split("\n")
        assert "name\ttest" in lines
        assert "id\t42" in lines

    def test_quiet_scalar(self, capsys):
        _output(42, quiet=True)
        assert capsys.readouterr().out.strip() == "42"

    def test_pydantic_model_output(self, capsys):
        m = _FakePydanticModel(id="x")
        _output(m)
        out = json.loads(capsys.readouterr().out)
        assert out == {"id": "x"}


# ---------------------------------------------------------------------------
# _read_json
# ---------------------------------------------------------------------------

class TestReadJson:
    def test_from_file(self, tmp_path):
        p = tmp_path / "test.json"
        p.write_text('{"key": "value"}')
        assert _read_json(str(p)) == {"key": "value"}

    def test_from_inline(self):
        assert _read_json('{"a": 1}') == {"a": 1}

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Not a valid JSON"):
            _read_json("not-a-file-and-not-json")


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

class TestParser:
    @pytest.fixture
    def parser(self):
        return _build_parser()

    def test_top_level_help(self, parser):
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--help"])
        assert exc.value.code == 0

    def test_version_flag(self, parser):
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--version"])
        assert exc.value.code == 0

    def test_models_list(self, parser):
        args = parser.parse_args(["models", "list"])
        assert args.service == "models"
        assert args.action == "list"
        assert hasattr(args, "func")

    def test_models_get(self, parser):
        args = parser.parse_args(["models", "get", "abc123"])
        assert args.model_id == "abc123"

    def test_models_versions(self, parser):
        args = parser.parse_args(["models", "versions", "m1"])
        assert args.model_id == "m1"

    def test_models_partitions(self, parser):
        args = parser.parse_args(["models", "partitions", "v1"])
        assert args.version_id == "v1"

    def test_models_link_preprocessor(self, parser):
        args = parser.parse_args(["models", "link-preprocessor", "mv1", "pv1"])
        assert args.model_version_id == "mv1"
        assert args.preprocessor_version_id == "pv1"

    def test_preprocessing_list(self, parser):
        args = parser.parse_args(["preprocessing", "list", "--team-id", "t1"])
        assert args.team_id == "t1"

    def test_preprocessing_create(self, parser):
        args = parser.parse_args([
            "preprocessing", "create",
            "--name", "test", "--description", "desc", "--spec", "s.json",
        ])
        assert args.name == "test"
        assert args.description == "desc"
        assert args.spec == "s.json"
        assert args.data is None

    def test_preprocessing_add_version(self, parser):
        args = parser.parse_args([
            "preprocessing", "add-version", "pp1", "--spec", "s.json", "--data", "d.csv",
        ])
        assert args.preprocessor_id == "pp1"
        assert args.data == "d.csv"

    def test_deployments_create(self, parser):
        args = parser.parse_args(["deployments", "create", "mv1"])
        assert args.model_version_id == "mv1"

    def test_deployments_create_key(self, parser):
        args = parser.parse_args([
            "deployments", "create-key", "d1",
            "--description", "test key", "--expiry-days", "30",
        ])
        assert args.deployment_id == "d1"
        assert args.description == "test key"
        assert args.expiry_days == 30

    def test_inference_predict(self, parser):
        args = parser.parse_args([
            "inference", "predict", "data.csv",
            "--model-id", "m1", "--version-id", "v1", "--threshold", "0.7",
        ])
        assert args.file == "data.csv"
        assert args.model_id == "m1"
        assert args.version_id == "v1"
        assert args.threshold == 0.7

    def test_inference_stream(self, parser):
        args = parser.parse_args([
            "inference", "stream", "data.csv",
            "--model-id", "m1", "--version-id", "v1", "--batch-size", "500",
        ])
        assert args.batch_size == 500

    def test_autotrain_summarize(self, parser):
        args = parser.parse_args(["autotrain", "summarize", "data.csv"])
        assert args.file == "data.csv"

    def test_autotrain_goals(self, parser):
        args = parser.parse_args(["autotrain", "goals", "s.json", "--n", "3"])
        assert args.summary == "s.json"
        assert args.n == 3

    def test_autotrain_start(self, parser):
        args = parser.parse_args([
            "autotrain", "start", "s.json",
            "--model-name", "m", "--model-description", "d",
        ])
        assert args.model_name == "m"
        assert args.model_description == "d"

    def test_autotrain_status(self, parser):
        args = parser.parse_args(["autotrain", "status", "run123"])
        assert args.run_id == "run123"

    def test_datasets_list(self, parser):
        args = parser.parse_args(["datasets", "list"])
        assert hasattr(args, "func")

    def test_datasets_load(self, parser):
        args = parser.parse_args(["datasets", "load", "iris"])
        assert args.name == "iris"

    def test_collections_create(self, parser):
        args = parser.parse_args([
            "collections", "create",
            "--model-id", "m1", "--name", "c1", "--description", "desc",
        ])
        assert args.model_id == "m1"
        assert args.name == "c1"

    def test_collections_delete(self, parser):
        args = parser.parse_args(["collections", "delete", "m1", "c1"])
        assert args.model_id == "m1"
        assert args.collection_id == "c1"

    def test_collections_scenarios(self, parser):
        args = parser.parse_args(["collections", "scenarios", "c1"])
        assert args.collection_id == "c1"

    def test_reports_generate(self, parser):
        args = parser.parse_args([
            "reports", "generate", "m1", "v1",
            "--objective", "predict churn", "--max-features", "10",
        ])
        assert args.model_id == "m1"
        assert args.objective == "predict churn"
        assert args.max_features == 10

    def test_reports_explain(self, parser):
        args = parser.parse_args([
            "reports", "explain", "m1", "v1", "--language", "es", "--detail", "high",
        ])
        assert args.language == "es"
        assert args.detail == "high"

    def test_ping(self, parser):
        args = parser.parse_args(["ping"])
        assert hasattr(args, "func")
        assert not args.gateway

    def test_ping_gateway(self, parser):
        args = parser.parse_args(["ping", "--gateway"])
        assert args.gateway is True

    def test_health(self, parser):
        args = parser.parse_args(["health"])
        assert hasattr(args, "func")

    def test_version_command(self, parser):
        args = parser.parse_args(["version"])
        assert hasattr(args, "func")
        assert args.no_auth is True

    def test_info(self, parser):
        args = parser.parse_args(["info", "m1", "v1"])
        assert args.model_id == "m1"
        assert args.version_id == "v1"

    def test_runs_create(self, parser):
        args = parser.parse_args(["runs", "create", "--name", "my-run"])
        assert args.name == "my-run"

    def test_runs_get(self, parser):
        args = parser.parse_args(["runs", "get", "r1"])
        assert args.run_id == "r1"

    def test_pretty_flag(self, parser):
        args = parser.parse_args(["--pretty", "models", "list"])
        assert args.pretty is True

    def test_quiet_flag(self, parser):
        args = parser.parse_args(["-q", "models", "list"])
        assert args.quiet is True

    def test_api_key_flag(self, parser):
        args = parser.parse_args(["--api-key", "xp_test", "models", "list"])
        assert args.api_key == "xp_test"


# ---------------------------------------------------------------------------
# Service-level help
# ---------------------------------------------------------------------------

class TestServiceHelp:
    """Verify --help works for every service."""

    @pytest.fixture
    def parser(self):
        return _build_parser()

    @pytest.mark.parametrize("service", [
        "preprocessing", "models", "deployments", "inference", "autotrain",
        "datasets", "collections", "reports", "runs",
    ])
    def test_service_help(self, parser, service):
        with pytest.raises(SystemExit) as exc:
            parser.parse_args([service, "--help"])
        assert exc.value.code == 0

    @pytest.mark.parametrize("cmd", [
        ["models", "list", "--help"],
        ["deployments", "create", "--help"],
        ["preprocessing", "create", "--help"],
        ["inference", "predict", "--help"],
        ["autotrain", "summarize", "--help"],
    ])
    def test_action_help(self, parser, cmd):
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(cmd)
        assert exc.value.code == 0


# ---------------------------------------------------------------------------
# main() integration tests (mocked client)
# ---------------------------------------------------------------------------

class TestMain:
    """Test main() end-to-end with a mock client."""

    def _run(self, argv, env=None):
        """Run main() with given argv, return (exit_code, stdout, stderr)."""
        old_argv = sys.argv
        old_env = os.environ.copy()
        stdout = StringIO()
        stderr = StringIO()

        try:
            sys.argv = ["xp"] + argv
            if env:
                os.environ.update(env)

            with mock.patch("sys.stdout", stdout), \
                 mock.patch("sys.stderr", stderr):
                try:
                    main()
                    return EXIT_SUCCESS, stdout.getvalue(), stderr.getvalue()
                except SystemExit as e:
                    return e.code, stdout.getvalue(), stderr.getvalue()
        finally:
            sys.argv = old_argv
            os.environ.clear()
            os.environ.update(old_env)

    def test_no_args_shows_help(self):
        code, _out, err = self._run([])
        assert code == EXIT_USAGE
        assert "xp" in err.lower() or "usage" in err.lower()

    def test_service_no_action_shows_error(self):
        code, _out, err = self._run(
            ["models"],
            env={"XPLAINABLE_API_KEY": "test"},
        )
        assert code == EXIT_USAGE
        assert "No action specified" in err

    def test_no_api_key_exits_auth(self):
        env = {k: v for k, v in os.environ.items() if k != "XPLAINABLE_API_KEY"}
        with mock.patch.dict(os.environ, env, clear=True):
            code, _out, err = self._run(["models", "list"])
        assert code == EXIT_AUTH
        assert "API key" in err

    def test_version_no_auth(self):
        """xp version should work without an API key."""
        code, out, _err = self._run(["version"])
        assert code == EXIT_SUCCESS
        data = json.loads(out)
        assert "cli_version" in data
        assert "python_version" in data

    @mock.patch("xplainable_client.cli._make_client")
    def test_models_list_json(self, mock_make):
        client = mock.MagicMock()
        client.models.list_team_models.return_value = [
            _FakePydanticModel(id="m1", name="Model 1"),
            _FakePydanticModel(id="m2", name="Model 2"),
        ]
        mock_make.return_value = client

        code, out, _err = self._run(["models", "list"])
        assert code == EXIT_SUCCESS
        data = json.loads(out)
        assert len(data) == 2
        assert data[0]["id"] == "m1"

    @mock.patch("xplainable_client.cli._make_client")
    def test_models_list_pretty(self, mock_make):
        client = mock.MagicMock()
        client.models.list_team_models.return_value = [
            _FakePydanticModel(id="m1"),
        ]
        mock_make.return_value = client

        code, out, _err = self._run(["--pretty", "models", "list"])
        assert code == EXIT_SUCCESS
        assert "\n" in out.strip()  # indented

    @mock.patch("xplainable_client.cli._make_client")
    def test_models_list_quiet(self, mock_make):
        client = mock.MagicMock()
        client.models.list_team_models.return_value = [
            _FakePydanticModel(id="m1"),
        ]
        mock_make.return_value = client

        code, out, _err = self._run(["-q", "models", "list"])
        assert code == EXIT_SUCCESS
        # quiet mode outputs one JSON per line for list items
        lines = out.strip().split("\n")
        assert len(lines) == 1
        assert json.loads(lines[0])["id"] == "m1"

    @mock.patch("xplainable_client.cli._make_client")
    def test_models_get(self, mock_make):
        client = mock.MagicMock()
        client.models.get_model.return_value = _FakePydanticModel(
            id="m1", name="Test"
        )
        mock_make.return_value = client

        code, out, _err = self._run(["models", "get", "m1"])
        assert code == EXIT_SUCCESS
        assert json.loads(out)["name"] == "Test"
        client.models.get_model.assert_called_once_with("m1")

    @mock.patch("xplainable_client.cli._make_client")
    def test_deployments_create_key(self, mock_make):
        client = mock.MagicMock()
        client.deployments.generate_deploy_key.return_value = _FakeUUID(
            "abc-123"
        )
        mock_make.return_value = client

        code, out, _err = self._run([
            "deployments", "create-key", "d1",
            "--description", "CI key", "--expiry-days", "30",
        ])
        assert code == EXIT_SUCCESS
        assert json.loads(out) == "abc-123"
        client.deployments.generate_deploy_key.assert_called_once_with(
            deployment_id="d1", description="CI key", days_until_expiry=30,
        )

    @mock.patch("xplainable_client.cli._make_client")
    def test_preprocessing_create(self, mock_make):
        client = mock.MagicMock()
        client.preprocessing.create_preprocessor.return_value = ("pp1", "v1")
        mock_make.return_value = client

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        ) as f:
            json.dump({"version": "2.0", "steps": []}, f)
            spec_path = f.name

        try:
            code, out, _err = self._run([
                "preprocessing", "create",
                "--name", "test", "--description", "desc", "--spec", spec_path,
            ])
            assert code == EXIT_SUCCESS
            data = json.loads(out)
            assert data == {"preprocessor_id": "pp1", "version_id": "v1"}
        finally:
            os.unlink(spec_path)

    @mock.patch("xplainable_client.cli._make_client")
    def test_ping(self, mock_make):
        client = mock.MagicMock()
        client.misc.ping_server.return_value = _FakePydanticModel(
            success=True, response_time=0.05
        )
        mock_make.return_value = client

        code, out, _err = self._run(["ping"])
        assert code == EXIT_SUCCESS
        data = json.loads(out)
        assert data["success"] is True

    @mock.patch("xplainable_client.cli._make_client")
    def test_ping_gateway(self, mock_make):
        client = mock.MagicMock()
        client.misc.ping_gateway.return_value = _FakePydanticModel(
            success=True, response_time=0.03
        )
        mock_make.return_value = client

        code, out, _err = self._run(["ping", "--gateway"])
        assert code == EXIT_SUCCESS
        client.misc.ping_gateway.assert_called_once()
        client.misc.ping_server.assert_not_called()

    @mock.patch("xplainable_client.cli._make_client")
    def test_api_error_exit_code(self, mock_make):
        """API 404 errors should produce exit code 3."""
        client = mock.MagicMock()
        err = Exception("Not found")
        err.status_code = 404
        client.models.get_model.side_effect = err
        mock_make.return_value = client

        code, _out, err_text = self._run(["models", "get", "nonexistent"])
        assert code == EXIT_NOT_FOUND
        assert "Not found" in err_text

    @mock.patch("xplainable_client.cli._make_client")
    def test_auth_error_exit_code(self, mock_make):
        """API 401 errors should produce exit code 4."""
        client = mock.MagicMock()
        err = Exception("Unauthorized")
        err.status_code = 401
        client.models.list_team_models.side_effect = err
        mock_make.return_value = client

        code, _out, err_text = self._run(["models", "list"])
        assert code == EXIT_AUTH
