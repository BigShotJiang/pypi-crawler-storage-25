# midicap
## Stand-alone, pure Python MIDI music captioner and analyzer

***

## Installation

```sh
!pip install midicap
```

***

## Use as follows

```python
import midicap
```

***

### Project Los Angeles
### Tegridy Code 2026
