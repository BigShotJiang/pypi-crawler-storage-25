"""Replay engine — re-run a captured Receipt's prompt N times against the
same vendor + model + temperature and report divergence.

The hash logic in this module is **byte-identical** to
``scripts/paper5_multivendor_replay.py`` and
``scripts/paper4_replay_determinism.py``. The integration test
``tests/test_replay.py`` enforces this against real per-run rows from
``results/benchmarks/paper5/multivendor_anthropic.jsonl``.

The actual N-replay loop requires vendor SDK keys + a captured prompt
(typically supplied via ``optional_payload``). When called with no
captured prompt, ``replay_receipt`` returns a result whose
``divergence_rate`` is ``None`` and ``method`` is ``"replay-skipped"`` —
this is the documented behavior for hash-only Receipts.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional

from chain_receipt_core import Receipt, compute_text_hash, compute_tool_calls_hash


# ============================================================================
# Hash logic — MUST be byte-identical to scripts/paper5_multivendor_replay.py
# (which delegates to scripts/paper4_replay_determinism.py::_seq_full)
# ============================================================================


def _seq_full(seq: List[dict]) -> str:
    """Tool-call sequence with op names + JSON-serialized arg values.

    Reproduces ``scripts/paper4_replay_determinism.py::_seq_full`` byte
    for byte. Do not modify without simultaneously updating that script
    AND ``chain_receipt_core.hash.compute_tool_calls_hash``.
    """
    parts: List[str] = []
    for s in seq:
        args = s.get("args") or {}
        parts.append(s.get("name") + ":" + json.dumps(args, sort_keys=True, default=str))
    return "||".join(parts)


def _seq_op_keys(seq: List[dict]) -> tuple:
    """Tool-call op name + arg-key shape (no values).

    Reproduces ``scripts/paper4_replay_determinism.py::_seq_op_keys``.
    """
    out = []
    for s in seq:
        args = s.get("args") or {}
        if isinstance(args, dict):
            keys = tuple(sorted(args.keys()))
        elif isinstance(args, list):
            keys = ("<list>", len(args))
        else:
            keys = ()
        out.append((s.get("name"), keys))
    return tuple(out)


def _hash(s: str) -> str:
    return "sha256:" + hashlib.sha256(s.encode("utf-8")).hexdigest()


def compare_runs(runs: List[dict]) -> dict:
    """Determinism flags across N runs. Mirror of paper4 ``compare_runs``."""
    if not runs:
        return {}
    answers = [str(r.get("final_answer_norm", "")) for r in runs]
    rationales = [r.get("rationale", "") for r in runs]
    seqs_op_keys = [_seq_op_keys(r.get("tool_call_sequence", [])) for r in runs]
    seqs_full = [_seq_full(r.get("tool_call_sequence", [])) for r in runs]
    counts = [r.get("n_tool_calls", 0) for r in runs]

    def all_equal(xs):
        return all(x == xs[0] for x in xs)

    return {
        "final_answer_consistent": all_equal(answers),
        "tool_seq_identical": all_equal(seqs_op_keys),
        "tool_args_identical": all_equal(seqs_full),
        "rationale_identical": all_equal(rationales),
        "tool_count_min": min(counts),
        "tool_count_max": max(counts),
        "tool_count_range": max(counts) - min(counts),
        "unique_answers": sorted(set(answers)),
        "unique_seq_op_keys": len(set(seqs_op_keys)),
        "unique_full_seqs": len(set(seqs_full)),
        "n_runs": len(runs),
    }


# ============================================================================
# Wilson 95% CI
# ============================================================================


def _wilson_ci(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson score interval — matches the convention used in paper5."""
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = (z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


# ============================================================================
# Public ReplayResult
# ============================================================================


@dataclass
class ReplayResult:
    receipt_hash: str
    n_replays: int
    divergence_rate: Optional[float]
    wilson_ci_lo: Optional[float]
    wilson_ci_hi: Optional[float]
    final_answer_consistent: Optional[bool]
    tool_seq_identical: Optional[bool]
    tool_args_identical: Optional[bool]
    method: str
    runs: List[dict] = field(default_factory=list)
    note: Optional[str] = None


# ============================================================================
# Public entry point
# ============================================================================


def replay_receipt(
    receipt: Receipt,
    *,
    n: int = 10,
    runner: Optional[Callable[[dict], dict]] = None,
) -> ReplayResult:
    """Re-run the captured prompt N times and compute divergence.

    The Receipt MUST carry the original prompt + system prompt in
    ``optional_payload`` for replay to be possible. Privacy-preserving
    Receipts (``optional_payload=null``) cannot be replayed and yield a
    ``method='replay-skipped'`` result.

    ``runner`` is an injectable callable ``(payload_dict) -> per_run_dict``
    expected to return at least:

        {
            "final_answer_norm": str,
            "rationale": str,
            "tool_call_sequence": list[dict],
            "n_tool_calls": int,
        }

    If ``runner`` is not supplied, the SDK uses the
    ``CHAIN_RECEIPT_RUNNER`` env var to look up a registered runner.
    For the v0.1.0 release we ship NO default vendor runners — callers
    who want a vanilla Anthropic / OpenAI / OpenRouter loop should
    import the per-vendor wrappers from
    ``scripts/paper5_multivendor_replay.py`` (kept out of the SDK to
    avoid pinning vendor SDK versions in a methodology dependency).
    """
    from chain_receipt_core import receipt_hash as _rhash

    h = _rhash(receipt)
    payload = receipt.optional_payload or {}

    if not payload:
        return ReplayResult(
            receipt_hash=h,
            n_replays=0,
            divergence_rate=None,
            wilson_ci_lo=None,
            wilson_ci_hi=None,
            final_answer_consistent=None,
            tool_seq_identical=None,
            tool_args_identical=None,
            method="replay-skipped",
            note="optional_payload is null — privacy-preserving Receipt; replay not possible",
        )

    if runner is None:
        runner_id = os.environ.get("CHAIN_RECEIPT_RUNNER")
        if not runner_id:
            return ReplayResult(
                receipt_hash=h,
                n_replays=0,
                divergence_rate=None,
                wilson_ci_lo=None,
                wilson_ci_hi=None,
                final_answer_consistent=None,
                tool_seq_identical=None,
                tool_args_identical=None,
                method="replay-skipped",
                note="no runner supplied and CHAIN_RECEIPT_RUNNER not set",
            )
        runner = _resolve_runner(runner_id)

    runs: List[dict] = []
    for i in range(n):
        per = runner({**payload, "run_idx": i})
        runs.append(per)

    cmp = compare_runs(runs)
    # Divergence on full tool-args sequence is the chain-determinism gate
    n_div = sum(
        1
        for r in runs
        if _seq_full(r.get("tool_call_sequence", []))
        != _seq_full(runs[0].get("tool_call_sequence", []))
    )
    div_rate = n_div / max(len(runs), 1)
    lo, hi = _wilson_ci(n_div, len(runs))

    return ReplayResult(
        receipt_hash=h,
        n_replays=len(runs),
        divergence_rate=div_rate,
        wilson_ci_lo=lo,
        wilson_ci_hi=hi,
        final_answer_consistent=cmp.get("final_answer_consistent"),
        tool_seq_identical=cmp.get("tool_seq_identical"),
        tool_args_identical=cmp.get("tool_args_identical"),
        method="byok-replay-v1",
        runs=runs,
    )


def _resolve_runner(spec: str) -> Callable[[dict], dict]:
    """Look up ``module:callable`` and return it as a runner."""
    if ":" not in spec:
        raise ValueError(
            f"CHAIN_RECEIPT_RUNNER must be 'module:callable', got {spec!r}"
        )
    mod_name, attr = spec.split(":", 1)
    import importlib

    mod = importlib.import_module(mod_name)
    fn = getattr(mod, attr)
    if not callable(fn):
        raise TypeError(f"{spec!r} is not callable")
    return fn


__all__ = [
    "replay_receipt",
    "ReplayResult",
    "compare_runs",
    "_seq_full",
    "_seq_op_keys",
]
