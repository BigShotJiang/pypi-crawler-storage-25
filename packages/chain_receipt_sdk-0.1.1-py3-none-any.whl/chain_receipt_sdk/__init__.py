"""Chain-Receipt SDK — emit, verify, replay, and chain Receipts (v1.0.0).

The SDK is the methodology dependency for the Calibrated Chain-Determinism
paper. Reviewers `pip install chain-receipt-sdk` to reproduce any cited
Receipt with `chain-receipt verify <hash>` or `chain-receipt replay <hash>`.

Public surface:

    from chain_receipt_sdk import (
        # Re-exports from chain_receipt_core for convenience
        Receipt, Interaction, Chain, Stability, Signature, ClientInfo,
        ReceiptBuilder,
        compute_tool_calls_hash, compute_text_hash, receipt_hash,
        verify_receipt, verify_chain, generate_keypair,
        # SDK additions
        ReceiptCallback,            # LangChain BaseCallbackHandler
        ReceiptVerifier,            # HTTP client for verifier endpoint
        LocalChain,                 # ~/.chain-receipt/chain.jsonl read/write
        replay_receipt,             # re-run captured prompt N times
        ReplayResult,
    )
"""
from __future__ import annotations

# Re-export the core surface so callers can `pip install chain-receipt-sdk`
# and never have to import chain_receipt_core directly.
from chain_receipt_core import (
    Receipt,
    Interaction,
    Chain,
    Stability,
    Signature,
    ClientInfo,
    RECEIPT_VERSION,
    canonical_json,
    receipt_hash,
    compute_tool_calls_hash,
    compute_text_hash,
    sha256_hex,
    sign_receipt,
    generate_keypair,
    ReceiptBuilder,
    verify_receipt,
    verify_chain,
    VerifyResult,
)

# SDK additions (lazy where practical to avoid pulling in optional deps)
from chain_receipt_sdk.chain import LocalChain
from chain_receipt_sdk.replay import replay_receipt, ReplayResult
from chain_receipt_sdk.verifier import ReceiptVerifier


def __getattr__(name: str):
    """Lazy-load LangChain callback so `langchain-core` is optional."""
    if name == "ReceiptCallback":
        from chain_receipt_sdk.callback import ReceiptCallback
        return ReceiptCallback
    raise AttributeError(f"module 'chain_receipt_sdk' has no attribute {name!r}")


__version__ = "0.1.0"

__all__ = [
    # core re-exports
    "Receipt",
    "Interaction",
    "Chain",
    "Stability",
    "Signature",
    "ClientInfo",
    "RECEIPT_VERSION",
    "canonical_json",
    "receipt_hash",
    "compute_tool_calls_hash",
    "compute_text_hash",
    "sha256_hex",
    "sign_receipt",
    "generate_keypair",
    "ReceiptBuilder",
    "verify_receipt",
    "verify_chain",
    "VerifyResult",
    # SDK additions
    "ReceiptCallback",  # via __getattr__
    "ReceiptVerifier",
    "LocalChain",
    "replay_receipt",
    "ReplayResult",
    "__version__",
]
