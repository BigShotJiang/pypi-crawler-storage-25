# this_file: tests/test_cli.py

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path

import pytest

from donazopy.cli import Donazopy
from donazopy.providers.base import ProviderAPIError
from donazopy.target import TargetError

ZONE_TEXT = """$ORIGIN example.com.
$TTL 3600
@ IN SOA ns1.example.com. hostmaster.example.com. 2026051201 7200 3600 1209600 3600
@ IN NS ns1.example.com.
ns1 IN A 192.0.2.10
www IN A 192.0.2.20
txt IN TXT "hello world"
"""


class FakeDNSProvider:
    """A minimal in-memory DNS provider for offline CLI tests."""

    def __init__(self, *, zone_text: str = ZONE_TEXT, create_supported: bool = True) -> None:
        self.zone_text = zone_text
        self.create_supported = create_supported
        self.imported: list[tuple[str, str]] = []
        self.deleted: list[str] = []
        self.created: list[str] = []
        self.records: list[Mapping[str, object]] = [
            {"id": "1", "type": "A", "name": "www.example.com", "content": "192.0.2.20"},
            {"id": "2", "type": "TXT", "name": "txt.example.com", "content": "hello world"},
        ]

    def export_zone(self, domain: str) -> str:
        return self.zone_text

    def import_zone(self, domain: str, zone_text: str, *, proxied: bool | None = None) -> Mapping[str, object]:
        self.imported.append((domain, zone_text))
        return {"recs_added": zone_text.count("\n")}

    def list_records(self, domain: str) -> list[Mapping[str, object]]:
        return list(self.records)

    def delete_all_records(self, domain: str) -> Mapping[str, object]:
        self.deleted.append(domain)
        return {"deleted": len(self.records), "failed": 0}

    def list_zones(self) -> list[str]:
        return ["example.com"]

    def create_zone(self, domain: str) -> Mapping[str, object]:
        if not self.create_supported:
            raise ProviderAPIError("creating zones is not supported by this fake provider")
        self.created.append(domain)
        return {"id": f"zone-{domain}", "name": domain}


class FakeRegistrarProvider:
    def __init__(self) -> None:
        self.assigned: list[tuple[str, list[str]]] = []

    def read_nameservers(self, domain: str) -> tuple[str, ...]:
        return ("ns1.example.com", "ns2.example.com")

    def assign_nameservers(self, domain: str, nameservers: Sequence[str]) -> Mapping[str, object]:
        self.assigned.append((domain, list(nameservers)))
        return {"assigned": list(nameservers)}


@pytest.fixture
def dns_provider() -> FakeDNSProvider:
    return FakeDNSProvider()


@pytest.fixture
def registrar_provider() -> FakeRegistrarProvider:
    return FakeRegistrarProvider()


@pytest.fixture
def cli(
    dns_provider: FakeDNSProvider, registrar_provider: FakeRegistrarProvider, monkeypatch: pytest.MonkeyPatch
) -> Donazopy:
    # Make credential loading offline-friendly.
    monkeypatch.setenv("CLOUDFLARE_DNS_TOKEN", "test-token")
    return Donazopy(
        dns_factory=lambda key, credentials, **_: dns_provider,
        registrar_factory=lambda key, credentials, **_: registrar_provider,
    )


def test_version_when_called_then_returns_string() -> None:
    assert isinstance(Donazopy().version(), str)


def test_providers_when_called_then_lists_operational_keys() -> None:
    assert Donazopy().providers() == ["cloudflare", "godaddy", "ionos", "joker"]


def test_status_when_no_target_then_returns_entry_per_provider(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("CLOUDFLARE_DNS_TOKEN", raising=False)
    result = Donazopy().status()

    assert set(result) == {"cloudflare", "godaddy", "ionos", "joker"}
    assert result["cloudflare"]["metadata"]["key"] == "cloudflare"
    assert "credential_status" in result["cloudflare"]


def test_status_when_provider_key_then_returns_single_entry(tmp_path: Path) -> None:
    dotenv_path = tmp_path / ".env"
    dotenv_path.write_text("CLOUDFLARE_DNS_TOKEN=token\n", encoding="utf-8")

    result = Donazopy().status("cloudflare", dotenv_path=str(dotenv_path))

    assert result["metadata"]["key"] == "cloudflare"
    assert result["credential_status"]["complete"] is True


def test_status_when_full_target_then_resolves_provider(tmp_path: Path) -> None:
    dotenv_path = tmp_path / ".env"
    dotenv_path.write_text("CLOUDFLARE_DNS_TOKEN=token\n", encoding="utf-8")

    result = Donazopy().status("cloudflare/example.com:A", dotenv_path=str(dotenv_path))

    assert result["metadata"]["key"] == "cloudflare"


def test_records_when_target_filters_type_then_returns_matching_records(cli: Donazopy) -> None:
    records = cli.records("cloudflare/example.com:TXT")

    assert [record["id"] for record in records] == ["2"]


def test_export_when_skip_ns_and_skip_types_then_filters_zone(cli: Donazopy) -> None:
    result = cli.export("cloudflare/example.com", skip_ns=True, skip_types="TXT")

    assert "NS" not in result
    assert "TXT" not in result
    assert "192.0.2.20" in result
    assert "SOA" in result  # apex SOA is preserved


def test_export_when_output_requested_then_writes_file(cli: Donazopy, tmp_path: Path) -> None:
    output_path = tmp_path / "out.zone"

    result = cli.export("cloudflare/example.com", output=str(output_path))

    assert output_path.read_text(encoding="utf-8") == result


def test_import_zone_when_path_given_then_calls_provider(
    cli: Donazopy, dns_provider: FakeDNSProvider, tmp_path: Path
) -> None:
    zone_path = tmp_path / "example.com.zone"
    zone_path.write_text(ZONE_TEXT, encoding="utf-8")

    cli.import_zone("cloudflare/example.com", str(zone_path))

    assert dns_provider.imported and dns_provider.imported[0][0] == "example.com"


def test_export_when_wildcard_target_then_writes_one_zone_file_per_domain(
    cli: Donazopy, dns_provider: FakeDNSProvider, tmp_path: Path
) -> None:
    dns_provider.zone_text = ZONE_TEXT

    result = cli.export("cloudflare/*", output=str(tmp_path / "zones"))

    assert isinstance(result, dict)
    assert "example.com" in result
    written_path = Path(result["example.com"])
    assert written_path.exists()
    assert written_path.name == "example.com.zone"
    assert "www.example.com." in written_path.read_text(encoding="utf-8")


def test_export_when_wildcard_target_without_output_then_raises(
    cli: Donazopy,
) -> None:
    with pytest.raises(TargetError, match="--output=DIR"):
        cli.export("cloudflare/*")


def test_export_when_output_is_existing_directory_then_writes_domain_named_file(
    cli: Donazopy, tmp_path: Path
) -> None:
    out_dir = tmp_path / "exports"
    out_dir.mkdir()

    cli.export("cloudflare/example.com", output=str(out_dir))

    assert (out_dir / "example.com.zone").exists()


def test_import_zone_when_clean_then_wipes_target_first(
    cli: Donazopy, dns_provider: FakeDNSProvider, tmp_path: Path
) -> None:
    zone_path = tmp_path / "example.com.zone"
    zone_path.write_text(ZONE_TEXT, encoding="utf-8")

    result = cli.import_zone("cloudflare/example.com", str(zone_path), clean=True)

    assert dns_provider.deleted == ["example.com"]
    assert dns_provider.imported and dns_provider.imported[0][0] == "example.com"
    assert isinstance(result, dict)
    assert "cleaned" in result
    assert "import_result" in result


def test_copy_when_clean_then_acts_as_replace(cli: Donazopy, dns_provider: FakeDNSProvider) -> None:
    result = cli.copy("cloudflare/example.com", "cloudflare/*", clean=True, skip_ns=True)

    assert dns_provider.deleted == ["example.com"]
    assert result["replaced"] == {"deleted": 2, "failed": 0}


def test_copy_when_wildcard_source_then_iterates_zones(
    cli: Donazopy, dns_provider: FakeDNSProvider
) -> None:
    dns_provider.list_zones = lambda: ["example.com", "alpha.test", "beta.test"]  # type: ignore[method-assign]

    result = cli.copy("cloudflare/*", "cloudflare/", clean=True, skip_ns=True)

    assert isinstance(result, dict)
    assert result["count"] == 3
    copied = list(result["copied"])  # type: ignore[arg-type]
    assert {entry["dest"]["domain"] for entry in copied} == {"example.com", "alpha.test", "beta.test"}
    # Every destination zone was wiped before import (clean / replace).
    assert set(dns_provider.deleted) == {"example.com", "alpha.test", "beta.test"}


def test_copy_when_wildcard_source_with_concrete_dest_then_raises(cli: Donazopy) -> None:
    with pytest.raises(TargetError, match="wildcard source"):
        cli.copy("cloudflare/*", "cloudflare/example.com")


def test_copy_when_dest_provider_only_then_inherits_source_domain(
    cli: Donazopy, dns_provider: FakeDNSProvider
) -> None:
    """``provider/domain → provider2/`` must copy to the same domain name."""
    result = cli.copy("cloudflare/example.com", "cloudflare/")

    assert isinstance(result, dict)
    assert result["dest"]["domain"] == "example.com"
    assert dns_provider.imported and dns_provider.imported[0][0] == "example.com"


def test_copy_when_wildcard_source_and_wildcard_dest_then_same_as_dest_only(
    cli: Donazopy, dns_provider: FakeDNSProvider
) -> None:
    """``provider1/* → provider2/*`` is equivalent to ``provider1/* → provider2/``."""
    dns_provider.list_zones = lambda: ["alpha.test", "beta.test"]  # type: ignore[method-assign]

    result = cli.copy("cloudflare/*", "cloudflare/*", clean=True)

    assert isinstance(result, dict)
    assert result["count"] == 2
    copied = list(result["copied"])  # type: ignore[arg-type]
    assert {entry["dest"]["domain"] for entry in copied} == {"alpha.test", "beta.test"}


def test_copy_when_replace_then_deletes_then_imports(cli: Donazopy, dns_provider: FakeDNSProvider) -> None:
    result = cli.copy("cloudflare/example.com", "cloudflare/*", replace=True, skip_ns=True)

    assert dns_provider.deleted == ["example.com"]
    assert result["dest"]["domain"] == "example.com"
    assert result["replaced"] == {"deleted": 2, "failed": 0}
    assert result["exported_records"] > 0
    assert dns_provider.imported


def test_copy_when_default_then_creates_dest_zone_first(cli: Donazopy, dns_provider: FakeDNSProvider) -> None:
    result = cli.copy("cloudflare/example.com", "cloudflare/dest.example", replace=True)

    assert dns_provider.created == ["dest.example"]
    assert result["created"] == {"id": "zone-dest.example", "name": "dest.example"}
    assert dns_provider.imported and dns_provider.imported[0][0] == "dest.example"


def test_copy_when_create_false_then_skips_zone_creation(cli: Donazopy, dns_provider: FakeDNSProvider) -> None:
    result = cli.copy("cloudflare/example.com", "cloudflare/dest.example", create=False)

    assert dns_provider.created == []
    assert result["created"] is None


def test_copy_when_dest_provider_cannot_create_zone_then_tolerated(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLOUDFLARE_DNS_TOKEN", "test-token")
    dns_provider = FakeDNSProvider(create_supported=False)
    cli = Donazopy(
        dns_factory=lambda key, credentials, **_: dns_provider,
        registrar_factory=lambda key, credentials, **_: FakeRegistrarProvider(),
    )

    result = cli.copy("cloudflare/example.com", "cloudflare/dest.example")

    assert dns_provider.created == []
    assert result["created"] is None
    assert dns_provider.imported and dns_provider.imported[0][0] == "dest.example"


def test_create_zone_command_when_provider_cannot_create_then_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CLOUDFLARE_DNS_TOKEN", "test-token")
    cli = Donazopy(
        dns_factory=lambda key, credentials, **_: FakeDNSProvider(create_supported=False),
        registrar_factory=lambda key, credentials, **_: FakeRegistrarProvider(),
    )

    with pytest.raises(ProviderAPIError, match="not supported"):
        cli.create_zone("cloudflare/new.example")


def test_create_zone_command_when_called_then_creates_zone(cli: Donazopy, dns_provider: FakeDNSProvider) -> None:
    result = cli.create_zone("cloudflare/new.example")

    assert dns_provider.created == ["new.example"]
    assert result == {"id": "zone-new.example", "name": "new.example"}


def test_nameservers_when_no_args_then_reads(cli: Donazopy) -> None:
    assert cli.nameservers("cloudflare/example.com") == ["ns1.example.com", "ns2.example.com"]


def test_nameservers_when_values_given_then_assigns(cli: Donazopy, registrar_provider: FakeRegistrarProvider) -> None:
    result = cli.nameservers("cloudflare/example.com", "a.iana-servers.net", "b.iana-servers.net")

    assert result == {"assigned": ["a.iana-servers.net", "b.iana-servers.net"]}
    assert registrar_provider.assigned == [("example.com", ["a.iana-servers.net", "b.iana-servers.net"])]


def test_nameservers_when_wildcard_domain_then_reads_all(cli: Donazopy) -> None:
    assert cli.nameservers("cloudflare/*") == {"example.com": ["ns1.example.com", "ns2.example.com"]}


def test_nameservers_when_wildcard_and_values_then_raises(cli: Donazopy) -> None:
    with pytest.raises(TargetError, match="single domain"):
        cli.nameservers("cloudflare/*", "a.iana-servers.net")


def test_domains_when_provider_key_then_lists_zones(cli: Donazopy) -> None:
    assert cli.domains("cloudflare") == ["example.com"]


def test_domains_when_wildcard_target_then_lists_zones(cli: Donazopy) -> None:
    assert cli.domains("cloudflare/*") == ["example.com"]


def test_require_domain_error_when_wildcard_then_points_at_domains_command(cli: Donazopy) -> None:
    with pytest.raises(TargetError, match="donazopy domains"):
        cli.records("cloudflare/*")


def test_diff_when_two_files_then_returns_summary(tmp_path: Path) -> None:
    before = tmp_path / "before.zone"
    after = tmp_path / "after.zone"
    before.write_text(ZONE_TEXT, encoding="utf-8")
    after.write_text(ZONE_TEXT.replace("192.0.2.20", "192.0.2.30"), encoding="utf-8")

    result = Donazopy().diff(str(before), str(after), origin="example.com.")

    assert result["summary"] == "creates=0 updates=1 deletes=0 unchanged=4"


def test_diff_when_target_versus_file_then_returns_summary(cli: Donazopy, tmp_path: Path) -> None:
    file_path = tmp_path / "snapshot.zone"
    file_path.write_text(ZONE_TEXT, encoding="utf-8")

    result = cli.diff("cloudflare/example.com", str(file_path), origin="example.com.")

    assert result["summary"].startswith("creates=0 updates=0 deletes=0")


def test_validate_when_valid_zone_then_reports_origin(tmp_path: Path) -> None:
    zone_path = tmp_path / "example.com.zone"
    zone_path.write_text(ZONE_TEXT, encoding="utf-8")

    result = Donazopy().validate(str(zone_path), origin="example.com.")

    assert result.startswith("valid zone example.com.")


def test_normalize_when_output_requested_then_writes_file(tmp_path: Path) -> None:
    zone_path = tmp_path / "example.com.zone"
    output_path = tmp_path / "normalized.zone"
    zone_path.write_text(ZONE_TEXT, encoding="utf-8")

    result = Donazopy().normalize(str(zone_path), origin="example.com.", output=str(output_path))

    assert "www.example.com. 3600 IN A 192.0.2.20" in result
    assert output_path.read_text(encoding="utf-8") == result


def test_records_when_no_provider_and_ambiguous_target_then_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    # Patch the operational provider list to be empty to force ambiguity.
    import donazopy.cli as cli_module

    monkeypatch.setattr(cli_module, "_operational_keys", lambda: ())
    with pytest.raises(TargetError, match="prefix the target with 'provider/'"):
        Donazopy().records("example.com")


def test_export_when_assign_unsupported_via_cloudflare_then_documented() -> None:
    # Sanity check that the Cloudflare adapter raises a clear error (uses real provider class).
    import httpx

    from donazopy.providers.cloudflare import CloudflareProvider

    provider = CloudflareProvider(
        {"CLOUDFLARE_DNS_TOKEN": "token"},
        client=httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(404))),
    )
    with pytest.raises(ProviderAPIError, match="not supported"):
        provider.assign_nameservers("example.com", ["a.ns", "b.ns"])
