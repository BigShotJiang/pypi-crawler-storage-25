## 0.4.2 (2026-04-03)

### Fix

- **cli**: add the target file’s import root to sys.path ([#23](https://github.com/sidorov-as/c4-diagrams/issues/23))

