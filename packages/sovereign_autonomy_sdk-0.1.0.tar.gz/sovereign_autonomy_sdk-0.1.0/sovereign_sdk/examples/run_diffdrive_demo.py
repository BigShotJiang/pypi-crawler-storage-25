import math
import time

from sovereign_sdk.til.til_core import TemporalInteractionLayer
from sovereign_sdk.sag.governor import (
    UniversalAutonomyGovernor,
    BehaviorLayer2D,
    SafetyLayer2D,
    EnvelopeLayer2D,
)


class DiffDriveControlLoop:
    def __init__(self, til, dt=0.1):
        self.dt = dt
        self.til = til

        self.state = {
            "x": 10.0,
            "y": 10.0,
            "theta": 0.0,
            "v": 0.0,
            "omega": 0.0,
            "target_x": 60.0,
            "target_y": 12.0,
        }

        behavior = BehaviorLayer2D()
        safety = SafetyLayer2D(max_accel=1.5)
        envelope = EnvelopeLayer2D(xmin=0, xmax=80, ymin=0, ymax=24)

        self.gov = UniversalAutonomyGovernor(
            behavior_layer=behavior,
            safety_layer=safety,
            envelope_layer=envelope,
            til=til,
            dt=dt,
        )

    def step(self):
        action = self.gov.decide(self.state)
        ax = action["ax"]
        ay = action["ay"]

        forward_ax = ax * math.cos(self.state["theta"]) + ay * math.sin(self.state["theta"])
        angular_accel = (-ax * math.sin(self.state["theta"]) + ay * math.cos(self.state["theta"])) * 0.1

        self.state["v"] += forward_ax * self.dt
        self.state["omega"] += angular_accel * self.dt

        self.state["theta"] += self.state["omega"] * self.dt
        self.state["x"] += self.state["v"] * math.cos(self.state["theta"]) * self.dt
        self.state["y"] += self.state["v"] * math.sin(self.state["theta"]) * self.dt

        return self.state


def main():
    print("=== Sovereign SDK Demo 2: Differential-Drive Robot ===")

    til = TemporalInteractionLayer()
    loop = DiffDriveControlLoop(til=til, dt=0.1)

    for i in range(60):
        state = loop.step()
        print(
            f"Step {i:03d}: "
            f"x={state['x']:.2f}, y={state['y']:.2f}, "
            f"theta={state['theta']:.2f}, v={state['v']:.2f}"
        )
        time.sleep(0.05)

    print("Demo complete.")


if __name__ == "__main__":
    main()
