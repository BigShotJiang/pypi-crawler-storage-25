import curses
import math
import time
import random

from sovereign_sdk.til.til_core import TemporalInteractionLayer
from sovereign_sdk.sag.governor import (
    UniversalAutonomyGovernor,
    BehaviorLayer2D,
    SafetyLayer2D,
    EnvelopeLayer2D,
)


# ------------------------------------------------------------
# Drone Control Loop
# ------------------------------------------------------------
class DroneControlLoop:
    def __init__(self, til, dt=0.1):
        self.dt = dt
        self.til = til

        self.state = {
            "x": 10.0,
            "y": 10.0,
            "z": 5.0,
            "yaw": 0.0,
            "vx": 0.0,
            "vy": 0.0,
            "vz": 0.0,
            "yaw_rate": 0.0,
            "target_x": 60.0,
            "target_y": 12.0,
            "target_z": 15.0,
        }

        behavior = BehaviorLayer2D()
        safety = SafetyLayer2D(max_accel=2.0)
        envelope = EnvelopeLayer2D(xmin=0, xmax=200, ymin=0, ymax=200)

        self.gov = UniversalAutonomyGovernor(
            behavior_layer=behavior,
            safety_layer=safety,
            envelope_layer=envelope,
            til=til,
            dt=dt,
        )

        # random obstacles
        self.obstacles = [(random.randint(5, 180), random.randint(5, 180)) for _ in range(20)]

    def step(self):
        action = self.gov.decide(self.state)
        ax = action["ax"]
        ay = action["ay"]

        # horizontal accel
        self.state["vx"] += ax * self.dt
        self.state["vy"] += ay * self.dt

        # altitude control
        dz = self.state["target_z"] - self.state["z"]
        self.state["vz"] += dz * 0.1 * self.dt

        # integrate position
        self.state["x"] += self.state["vx"] * self.dt
        self.state["y"] += self.state["vy"] * self.dt
        self.state["z"] += self.state["vz"] * self.dt

        # yaw control
        desired_yaw = math.atan2(
            self.state["target_y"] - self.state["y"],
            self.state["target_x"] - self.state["x"],
        )
        yaw_error = desired_yaw - self.state["yaw"]
        self.state["yaw_rate"] += yaw_error * 0.1 * self.dt
        self.state["yaw_rate"] *= 0.9
        self.state["yaw"] += self.state["yaw_rate"] * self.dt

        # clamp world bounds
        self.state["x"] = max(0, min(199, self.state["x"]))
        self.state["y"] = max(0, min(199, self.state["y"]))
        self.state["z"] = max(0, min(50, self.state["z"]))

        return self.state


# ------------------------------------------------------------
# Rendering Helpers
# ------------------------------------------------------------
def world_to_screen(wx, wy, cam_x, cam_y, width, height):
    sx = int(wx - cam_x + width // 2)
    sy = int(wy - cam_y + height // 2)
    return sx, sy


def draw_grid(stdscr, cam_x, cam_y, width, height):
    for gy in range(0, 200, 5):
        for gx in range(0, 200, 5):
            sx, sy = world_to_screen(gx, gy, cam_x, cam_y, width, height)
            if 0 <= sx < width and 0 <= sy < height:
                try:
                    stdscr.addch(sy, sx, ".")
                except curses.error:
                    pass


def draw_obstacles(stdscr, obstacles, cam_x, cam_y, width, height):
    for ox, oy in obstacles:
        sx, sy = world_to_screen(ox, oy, cam_x, cam_y, width, height)
        if 0 <= sx < width and 0 <= sy < height:
            try:
                stdscr.addch(sy, sx, "#")
            except curses.error:
                pass


def draw_drone(stdscr, x, y, z, yaw, vx, vy, cam_x, cam_y, width, height):
    cx, cy = world_to_screen(x, y, cam_x, cam_y, width, height)

    # drone body
    try:
        stdscr.addch(cy, cx, "O")
        stdscr.addch(cy, cx - 2, "-")
        stdscr.addch(cy, cx + 2, "-")
        stdscr.addch(cy - 1, cx, "|")
        stdscr.addch(cy + 1, cx, "|")
    except curses.error:
        pass

    # heading arrow
    hx = cx + int(math.cos(yaw) * 3)
    hy = cy + int(math.sin(yaw) * 3)
    if 0 <= hx < width and 0 <= hy < height:
        try:
            stdscr.addch(hy, hx, ">")
        except curses.error:
            pass

    # velocity vector
    vx2 = cx + int(vx * 2)
    vy2 = cy + int(vy * 2)
    if 0 <= vx2 < width and 0 <= vy2 < height:
        try:
            stdscr.addch(vy2, vx2, "*")
        except curses.error:
            pass

    # shadow
    if 0 <= cx < width and 0 <= cy < height:
        try:
            stdscr.addch(cy + 2, cx, ".")
        except curses.error:
            pass


def draw_altitude_bar(stdscr, z, height):
    max_z = 50
    bar_height = int((z / max_z) * (height - 2))
    for i in range(height - 2):
        ch = "|" if i < bar_height else " "
        try:
            stdscr.addch(height - 2 - i, 0, ch)
        except curses.error:
            pass


def draw_target(stdscr, tx, ty, cam_x, cam_y, width, height):
    sx, sy = world_to_screen(tx, ty, cam_x, cam_y, width, height)
    if 0 <= sx < width and 0 <= sy < height:
        try:
            stdscr.addch(sy, sx, "T")
        except curses.error:
            pass


# ------------------------------------------------------------
# Main Loop
# ------------------------------------------------------------
def main(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(True)

    height, width = stdscr.getmaxyx()

    til = TemporalInteractionLayer()
    loop = DroneControlLoop(til=til, dt=0.1)

    while True:
        state = loop.step()

        cam_x = state["x"]
        cam_y = state["y"]

        stdscr.clear()

        draw_grid(stdscr, cam_x, cam_y, width, height)
        draw_obstacles(stdscr, loop.obstacles, cam_x, cam_y, width, height)
        draw_target(stdscr, state["target_x"], state["target_y"], cam_x, cam_y, width, height)
        draw_drone(
            stdscr,
            state["x"], state["y"], state["z"],
            state["yaw"],
            state["vx"], state["vy"],
            cam_x, cam_y,
            width, height
        )
        draw_altitude_bar(stdscr, state["z"], height)

        stdscr.addstr(0, 2, f"x={state['x']:.1f} y={state['y']:.1f} z={state['z']:.1f} yaw={state['yaw']:.2f}")

        stdscr.refresh()
        time.sleep(0.05)

        if stdscr.getch() == ord("q"):
            break


if __name__ == "__main__":
    curses.wrapper(main)
