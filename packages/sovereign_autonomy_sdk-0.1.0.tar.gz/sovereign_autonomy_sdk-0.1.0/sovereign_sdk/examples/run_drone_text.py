def main():
    print("Drone demo running (text mode).")
