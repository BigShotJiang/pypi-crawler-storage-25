import curses
import math
import time

from sovereign_sdk.til.til_core import TemporalInteractionLayer
from sovereign_sdk.sag.governor import (
    UniversalAutonomyGovernor,
    BehaviorLayer2D,
    SafetyLayer2D,
    EnvelopeLayer2D,
)


class DiffDriveControlLoop:
    def __init__(self, til, dt=0.1):
        self.dt = dt
        self.til = til

        self.state = {
            "x": 10.0,
            "y": 10.0,
            "theta": 0.0,
            "v": 0.0,
            "omega": 0.0,
            "target_x": 60.0,
            "target_y": 12.0,
        }

        behavior = BehaviorLayer2D()
        safety = SafetyLayer2D(max_accel=2.0)
        envelope = EnvelopeLayer2D(xmin=0, xmax=80, ymin=0, ymax=24)

        self.gov = UniversalAutonomyGovernor(
            behavior_layer=behavior,
            safety_layer=safety,
            envelope_layer=envelope,
            til=til,
            dt=dt,
        )

    def step(self):
        action = self.gov.decide(self.state)
        ax = action["ax"]
        ay = action["ay"]

        forward_ax = ax * math.cos(self.state["theta"]) + ay * math.sin(self.state["theta"])
        angular_accel = (-ax * math.sin(self.state["theta"]) + ay * math.cos(self.state["theta"])) * 0.1

        # integrate velocity
        self.state["v"] += forward_ax * self.dt
        self.state["omega"] += angular_accel * self.dt

        # yaw damping
        self.state["omega"] *= 0.9

        # clamp speed
        max_v = 3.0
        if self.state["v"] > max_v:
            self.state["v"] = max_v
        if self.state["v"] < -max_v:
            self.state["v"] = -max_v

        # integrate pose
        self.state["theta"] += self.state["omega"] * self.dt
        self.state["x"] += self.state["v"] * math.cos(self.state["theta"]) * self.dt
        self.state["y"] += self.state["v"] * math.sin(self.state["theta"]) * self.dt

        # clamp to screen bounds
        if self.state["x"] < 0:
            self.state["x"] = 0
        if self.state["x"] > 79:
            self.state["x"] = 79
        if self.state["y"] < 0:
            self.state["y"] = 0
        if self.state["y"] > 23:
            self.state["y"] = 23

        return self.state


def draw_robot(stdscr, x, y, theta):
    # simple body oriented by theta
    # center at (x, y)
    cx = int(x)
    cy = int(y)

    # heading arrow
    dirs = ["^", ">", "v", "<"]
    idx = int((theta % (2 * math.pi)) / (math.pi / 2)) % 4
    head = dirs[idx]

    try:
        # body
        stdscr.addstr(cy, cx - 1, "[R]")
        # head above / right / below / left
        if head == "^":
            stdscr.addch(cy - 1, cx, "^")
        elif head == "v":
            stdscr.addch(cy + 1, cx, "v")
        elif head == ">":
            stdscr.addch(cy, cx + 2, ">")
        elif head == "<":
            stdscr.addch(cy, cx - 2, "<")
    except curses.error:
        pass


def draw_target(stdscr, tx, ty):
    try:
        stdscr.addch(int(ty), int(tx), "T")
    except curses.error:
        pass


def main(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(True)

    til = TemporalInteractionLayer()
    loop = DiffDriveControlLoop(til=til, dt=0.1)

    while True:
        state = loop.step()

        stdscr.clear()
        draw_target(stdscr, state["target_x"], state["target_y"])
        draw_robot(stdscr, state["x"], state["y"], state["theta"])

        stdscr.addstr(
            0,
            0,
            f"x={state['x']:.2f} y={state['y']:.2f} th={state['theta']:.2f} v={state['v']:.2f}",
        )
        stdscr.addstr(1, 0, "Press 'q' to quit")

        stdscr.refresh()
        time.sleep(0.05)

        ch = stdscr.getch()
        if ch == ord("q"):
            break


if __name__ == "__main__":
    curses.wrapper(main)
