def main():
    print("=== Sovereign SDK Demo Launcher ===")
    print("1) Diff-drive (text)")
    print("2) Drone (text)")
    print("3) Quit")
    choice = input("Select option: ")
    if choice == "1":
        from .run_diffdrive_text import main as dd
        dd()
    elif choice == "2":
        from .run_drone_text import main as dr
        dr()

if __name__ == "__main__":
    main()
