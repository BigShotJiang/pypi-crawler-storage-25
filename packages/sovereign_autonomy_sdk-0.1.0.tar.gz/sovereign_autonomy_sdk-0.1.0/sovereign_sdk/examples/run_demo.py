from sovereign_sdk.til.til_core import TemporalInteractionLayer
from sovereign_sdk.sae.loop import AOSControlLoop
import time


def main():
    print("=== Sovereign Autonomy Engine Demo ===")

    # Initialize TIL + Control Loop
    til = TemporalInteractionLayer()
    loop = AOSControlLoop(til=til, dt=0.1)

    # Run 50 steps of the autonomy loop
    for i in range(50):
        state = loop.step()
        print(
            f"Step {i:03d}: "
            f"x={state['x']:.2f}, y={state['y']:.2f}, "
            f"vx={state['vx']:.2f}, vy={state['vy']:.2f}"
        )
        time.sleep(0.05)

    print("Demo complete.")


if __name__ == "__main__":
    main()
