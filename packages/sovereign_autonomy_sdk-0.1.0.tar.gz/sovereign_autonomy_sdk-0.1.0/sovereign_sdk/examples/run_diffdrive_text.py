def main():
    print("Diff-drive demo running (text mode).")
