# Sovereign Autonomy SDK (SASDK)

The **Sovereign Autonomy SDK (SASDK)** provides a clean, high‑level Python interface for integrating robots, simulations, and intelligent systems with the Sovereign Autonomy Engine (SAE). It exposes a stable, goal‑driven API that lets developers send observations, set goals, and retrieve actions — without exposing any internal engine logic.

SASDK is designed for robotics teams who want to evaluate or integrate advanced autonomous decision‑making without dealing with brittle state machines, complex behavior trees, or custom control loops.

---

## 🚀 Features

- **Simple Python API** for sending observations and receiving actions  
- **Goal‑driven autonomy** with a declarative interface  
- **Deterministic decision loop** suitable for real robots and simulation  
- **Lightweight integration layer** compatible with ROS, Isaac Sim, Webots, Mujoco, and custom robotics stacks  
- **Zero engine exposure** — the autonomy engine remains fully proprietary  
- **Fast evaluation** — install and run a demo in minutes  

---

## 🧠 Why Robotics Teams Use SASDK

Robotics engineers use this SDK to:

- integrate an autonomy engine into their robot stack  
- test advanced decision‑making in simulation  
- evaluate new control strategies without rewriting their system  
- compare your autonomy engine against their existing planner or behavior tree  
- prototype intelligent behaviors quickly  

The SDK acts as the **safe, stable interface** to the underlying autonomy engine.

---

## 📦 Installation

\`\`\`bash
pip install sovereign-autonomy-sdk
\`\`\`

---

## 🧩 Quickstart Example

\`\`\`python
from sovereign_autonomy_sdk import Client

client = Client()
client.set_goal("navigate_to_waypoint")

while True:
    obs = get_sensor_data()
    action = client.decide(obs)
    apply_action(action)
\`\`\`

This minimal loop shows how to connect your robot or simulator to the autonomy engine.

---

## 🔗 Use Cases

- Mobile robots  
- Warehouse automation  
- Manipulation and arms  
- Drones and UAVs  
- Simulation‑only research  
- Multi‑agent systems  
- Autonomous navigation and decision‑making  

---

## 📘 Documentation

Documentation and examples are included in the package and will expand with future releases.

---

## 🛡️ License

MIT or proprietary — choose based on your distribution model.

