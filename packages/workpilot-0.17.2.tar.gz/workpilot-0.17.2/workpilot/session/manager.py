"""
Session manager — JSONL-based conversation persistence with in-memory cache.

Sessions are keyed by (channel, sender_id). Each session stores the
conversation history as append-only JSONL for crash safety.
"""

from __future__ import annotations

import json
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from workpilot.config.schema import ChannelType

# Default sender-id for synthetic/anonymous users on each local channel.
# Keeping these in one place means the "what session does a background
# producer target when it wants to write to the user's own session" query
# (``channel_default_session`` below) resolves to the SAME canonical
# session ID the channel normally uses for that user.
_CHANNEL_DEFAULT_SENDER: dict[str, str] = {
    "web": "web-user",
    "cli": "local",
}


class SessionManager:
    """Manages conversation sessions with optional JSONL persistence."""

    def __init__(self, data_dir: Path | None = None) -> None:
        self._data_dir = data_dir
        if self._data_dir:
            self._data_dir.mkdir(parents=True, exist_ok=True)
        self._sessions: dict[str, list[dict[str, Any]]] = {}

    def list_sessions(self) -> list[dict[str, Any]]:
        """List all known sessions with metadata.

        Returns lightweight metadata without loading full message histories.
        Uses file metadata (size) for on-disk sessions and in-memory
        counts for already-loaded sessions.
        """
        results: list[dict[str, Any]] = []

        # In-memory sessions
        seen: set[str] = set()
        for sid, msgs in self._sessions.items():
            if msgs:
                results.append({"session_id": sid, "message_count": len(msgs)})
                seen.add(sid)

        # On-disk sessions not yet loaded — use file stat instead of loading
        # Skip archive files (e.g. local_cli_2026-03-14.jsonl) — they contain
        # a date suffix from session splitting and are not active sessions.
        if self._data_dir and self._data_dir.exists():
            for path in self._data_dir.glob("*.jsonl"):
                sid = path.stem
                # Skip archive files (contain date suffix like _2026-03-14)
                if re.search(r"_\d{4}-\d{2}-\d{2}$", sid):
                    continue
                if sid not in seen:
                    try:
                        stat = path.stat()
                        # Estimate message count from line count without loading
                        line_count = path.read_text(encoding="utf-8").count("\n")
                        results.append(
                            {
                                "session_id": sid,
                                "message_count": line_count,
                                "size_bytes": stat.st_size,
                            }
                        )
                    except (OSError, ValueError):
                        continue

        return results

    def get_or_create_id(self, channel: ChannelType, sender_id: str) -> str:
        """Get a deterministic session ID for a channel+sender pair."""
        key = f"{channel}_{sender_id}"
        return key

    @classmethod
    def channel_default_session(cls, channel: str) -> str | None:
        """Canonical session ID that ``channel``'s default user writes to.

        Used by outbound producers (``notify`` tool, cron scheduler) to
        stamp ``metadata.target_session_id`` — the ``_capture_for_persist``
        handler routes the entry into the session the user's frontend
        reads on refresh, regardless of which call frame triggered the
        publish (user's own turn, cron running in ``scheduler_<job>``,
        background delegate).

        Derivation: build the raw session ID with the same
        ``f"{channel}_{sender_id}"`` shape that ``get_or_create_id``
        uses, then pass it through ``_normalize_id`` so the result
        matches whatever canonical form the frontend already uses for
        that user. Keeping the shape inlined here (rather than
        instantiating a SessionManager just to call
        ``get_or_create_id``) lets callers treat this as a pure helper;
        the two places that care about the raw format are tested side
        by side in ``tests/test_session.py``.

        Returns ``None`` for channels that don't have a *channel-default*
        user — currently ``cloud``. Cloud DOES have canonical session
        IDs (``cloud_teams`` / ``cloud_web``, produced by
        ``_normalize_id`` and persisted as JSONL like any other
        session) and session JSONL is written regardless of channel —
        we just can't derive which one from the string ``"cloud"``
        alone (it depends on which Bot Framework surface the user is
        on). Outbound producers that need to route to a cloud session
        therefore have to plumb the originating ``session_id`` through
        explicitly:
          * delegate tools: ``NotifyTarget.session_id``
            (``cloud_teams`` / ``cloud_web`` when the originating turn
            was on cloud).
          * cron: ``Job.notify_session_id`` captured at job-creation
            time; ``_publish_to_targets`` uses it for the cloud leg
            when set.
          * notify tool: falls back to the current turn's
            ``_session_id`` when target == current channel (Teams user
            self-notify); otherwise drops the cloud leg to avoid
            duplicating into the originating local session on
            broadcast.
        """
        default_sender = _CHANNEL_DEFAULT_SENDER.get(channel)
        if default_sender is None:
            return None
        # Matches ``SessionManager.get_or_create_id`` shape. If
        # ``get_or_create_id`` ever changes, update this and the
        # corresponding test in ``tests/test_session.py``.
        raw = f"{channel}_{default_sender}"
        return cls._normalize_id(raw)

    # Patterns for old-format cloud session keys (compat with older gateways/data)
    _OLD_TEAMS_RE = re.compile(r"^cloud_teams_.+_.+")  # cloud_teams_{oid}_{conv_id}
    _OLD_WEBCHAT_RE = re.compile(r"^cloud_webchat_")  # cloud_webchat_wc_{oid}

    @staticmethod
    def _normalize_id(session_id: str) -> str:
        """Canonical form: colons/slashes → underscores, legacy IDs → canonical.

        Mappings: old cloud keys (cloud_teams_*, cloud_webchat_*) → cloud_teams/cloud_web;
        old local keys (web_web-user, web_ws-user, cli_local) → local_web/local_cli.
        """
        sid = session_id.replace(":", "_").replace("/", "_")
        # Collapse old-format cloud keys to constants
        if SessionManager._OLD_TEAMS_RE.match(sid):
            return "cloud_teams"
        if SessionManager._OLD_WEBCHAT_RE.match(sid):
            return "cloud_web"
        # Old local session names → canonical
        if sid in ("web_web-user", "web_ws-user"):
            return "local_web"
        if sid == "cli_local":
            return "local_cli"
        return sid

    # Roles accepted by LLM APIs — any other roles are UI-only metadata
    _LLM_ROLES: frozenset[str] = frozenset({"user", "assistant", "system", "tool"})

    # Native Responses API item types that are valid conversation items
    _NATIVE_ITEM_TYPES: frozenset[str] = frozenset(
        {"function_call", "function_call_output", "message", "reasoning", "compaction"}
    )

    def get_messages(self, session_id: str, llm_only: bool = False) -> list[dict[str, Any]]:
        """Get conversation history for a session.

        Returns both Chat Completions format messages (``role``-based) and
        native Responses API items (``type``-based). Callers that need a
        specific format should convert via ``items_to_chat_messages()`` or
        use items directly for the Responses API.

        Parameters
        ----------
        llm_only:
            If True, filter out non-LLM roles (e.g. ``approval_request``)
            that are stored for UI purposes but rejected by the LLM API.
            Also accepts native Responses API items (``function_call``, etc.).

        Note: ``_compaction`` audit entries are always filtered out — they
        are metadata for audit only, not conversation messages.
        """
        session_id = self._normalize_id(session_id)
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        msgs = self._sessions[session_id]
        # Filter out _compaction audit entries (always)
        msgs_filtered = [m for m in msgs if "_compaction" not in m]
        if llm_only:
            return [
                m
                for m in msgs_filtered
                if m.get("role") in self._LLM_ROLES or m.get("type") in self._NATIVE_ITEM_TYPES
            ]
        return msgs_filtered

    def add_message(self, session_id: str, message: dict[str, Any]) -> None:
        """Append a message to the session history.

        Injects ``_ts`` (ISO 8601 UTC timestamp) into the message dict
        before appending, unless the message already has one (e.g. audit
        entries that set their own timestamp).
        """
        session_id = self._normalize_id(session_id)
        if "_ts" not in message:
            message["_ts"] = datetime.now(UTC).isoformat()
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        self._sessions[session_id].append(message)
        self._persist(session_id, message)

    def clear(self, session_id: str) -> None:
        """Clear a session's history and metadata.

        Session JSONL files are archived (renamed with timestamp), not deleted,
        so they remain available for history indexing and audit.
        """
        session_id = self._normalize_id(session_id)
        self._sessions[session_id] = []
        if self._data_dir:
            ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            archive_dir = self._data_dir / "archive"
            created = False
            path = self._session_path(session_id)
            if not path.exists():
                self._maybe_migrate_legacy_session(session_id, path)
            if path.exists():
                if not created:
                    archive_dir.mkdir(parents=True, exist_ok=True)
                    created = True
                path.rename(archive_dir / f"{path.stem}_{ts}{path.suffix}")
            meta = self._meta_path(session_id)
            if meta and meta.exists():
                if not created:
                    archive_dir.mkdir(parents=True, exist_ok=True)
                    created = True
                # Archive as {session_id}_{ts}.meta.json (matches delete glob)
                meta.rename(archive_dir / f"{session_id}_{ts}.meta.json")
            # Archive split files (date-suffixed), but NOT fork sessions
            for split in self._data_dir.glob(f"{session_id}_*.jsonl"):
                if "_fork_" in split.stem:
                    continue
                if not created:
                    archive_dir.mkdir(parents=True, exist_ok=True)
                    created = True
                split.rename(archive_dir / f"{split.stem}_{ts}{split.suffix}")

    def delete(self, session_id: str) -> None:
        """Permanently delete a session's files, metadata, and archived copies."""
        session_id = self._normalize_id(session_id)
        self._sessions.pop(session_id, None)
        if self._data_dir:
            path = self._session_path(session_id)
            if not path.exists():
                self._maybe_migrate_legacy_session(session_id, path)
            if path.exists():
                path.unlink()
            meta = self._meta_path(session_id)
            if meta and meta.exists():
                meta.unlink()
            for split in self._data_dir.glob(f"{session_id}_*.jsonl"):
                if "_fork_" in split.stem:
                    continue
                split.unlink()
            # Also remove archived copies from clear()
            archive_dir = self._data_dir / "archive"
            if archive_dir.exists():
                for f in archive_dir.glob(f"{session_id}_*.jsonl"):
                    f.unlink()
                for f in archive_dir.glob(f"{session_id}_*.meta.json"):
                    f.unlink()

    def trim(self, session_id: str, keep_last: int) -> list[dict[str, Any]]:
        """Trim session to keep only the last N messages **in memory**.

        Returns the trimmed (removed) messages for memory consolidation.
        The disk JSONL file is **not** rewritten — it stays append-only.

        The split point is adjusted so tool-call groups (assistant with
        tool_calls + tool results) are never broken apart.
        """
        session_id = self._normalize_id(session_id)
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        # Operate on the raw in-memory list directly (not the filtered
        # copy from get_messages()) to preserve _compaction audit entries
        # and avoid creating a disconnected copy.
        messages = self._sessions[session_id]
        if len(messages) <= keep_last:
            return []

        # Find safe split point that doesn't break tool-call groups
        idx = len(messages) - keep_last
        while idx > 0 and messages[idx].get("role") == "tool":
            idx -= 1

        trimmed = messages[:idx]
        self._sessions[session_id] = messages[idx:]

        # NOTE: no JSONL rewrite — disk stays append-only.
        # Consolidation uses _ts position tracking via meta.json instead.

        return trimmed

    def replace_messages(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        """Replace in-memory session history without rewriting disk.

        Used after compaction to update the working set while keeping the
        append-only JSONL intact for consolidation.
        """
        session_id = self._normalize_id(session_id)
        self._sessions[session_id] = messages

    def fork(self, session_id: str) -> str:
        """Create a linked empty branch for sub-agents.

        The forked session has empty history but is linked to the parent
        for tracking purposes.
        """
        session_id = self._normalize_id(session_id)
        fork_id = f"{session_id}_fork_{uuid.uuid4().hex[:8]}"
        self._sessions[fork_id] = []
        return fork_id

    def is_loaded(self, session_id: str) -> bool:
        """Check if session is already in memory."""
        return self._normalize_id(session_id) in self._sessions

    def smart_load_session(
        self,
        session_id: str,
        context_limit: int,
        *,
        reserved_tokens: int = 0,
        full_content_turns: int = 5,
    ) -> list[dict[str, Any]]:
        """Load a budget-aware smart tail from the active JSONL file.

        Uses backward fill — walks from newest turn to oldest, accumulating
        until the token budget is exhausted.  Turns are atomic (never split
        assistant↔tool groups).

        - Recent ``full_content_turns`` turns preferentially keep full tool
          content; unconsolidated turns that exceed the cap may still be
          compressed (user + final assistant only).
        - Older turns get tool content replaced with concise placeholders.
        - Budget = ``context_limit - reserved_tokens``, clamped to
          [10K, 45% of context_limit].
        - Unconsolidated messages (after ``last_consolidated_at``) bypass the
          soft cap (compressed to user + final assistant) up to a hard cap
          of 100 messages. Remaining are handled by the next consolidation.

        Archive files are NOT loaded — only the active session file.
        See compaction.md §9.8.
        """
        from workpilot.agent.compaction import (
            _MSG_OVERHEAD,
            _build_tool_placeholder,
            estimate_msg_tokens,
        )

        session_id = self._normalize_id(session_id)
        all_msgs = self._load_from_disk(session_id)
        if not all_msgs:
            self._sessions[session_id] = []
            return []

        # Filter out _compaction audit entries
        msgs = [m for m in all_msgs if "_compaction" not in m]

        # Heal orphan function_calls left by crashes (inject synthetic outputs)
        self._heal_orphan_tool_calls(msgs, session_id)

        # Group into turns (user msg → everything until next user msg)
        turns = self._group_into_turns(msgs)

        if len(turns) <= full_content_turns:
            # Short session — keep everything as-is
            self._sessions[session_id] = msgs
            return msgs

        # Determine which turns are unconsolidated (must always be loaded)
        last_consolidated_at = self.read_meta(session_id).get("last_consolidated_at", "")
        unconsolidated_start = len(turns)  # index of first unconsolidated turn
        for ti, turn in enumerate(turns):
            # A turn is unconsolidated if any message has _ts > last_consolidated_at
            if any(m.get("_ts", "") > last_consolidated_at for m in turn):
                unconsolidated_start = ti
                break

        # Calculate history budget (never exceed what's actually available)
        available = max(0, context_limit - reserved_tokens)
        max_budget = int(context_limit * 0.45)
        budget = max(10_000, min(available, max_budget))

        # Placeholder token estimate (typical placeholder is 30-80 tokens)
        _PLACEHOLDER_ESTIMATE = _MSG_OVERHEAD + 60

        # Backward fill: walk turns from newest to oldest
        # Soft cap at 80 messages — consolidated turns stop here.
        # Unconsolidated turns continue (compressed) up to a hard cap of 100.
        _SOFT_CAP_MSGS = 80
        _HARD_CAP_MSGS = 100

        selected: list[tuple[list[dict[str, Any]], bool]] = []  # (turn_msgs, is_full)
        used_tokens = 0
        total_msgs = 0

        for idx in range(len(turns) - 1, -1, -1):
            turn = turns[idx]
            turns_from_end = len(turns) - 1 - idx
            is_full = turns_from_end < full_content_turns
            is_unconsolidated = idx >= unconsolidated_start

            # Estimate this turn's token cost
            turn_tokens = 0
            for msg in turn:
                if is_full:
                    turn_tokens += estimate_msg_tokens(msg)
                elif (
                    msg.get("role") == "tool"
                    and msg.get("content")
                    and not msg["content"].startswith("[tool result cleared:")
                ):
                    turn_tokens += _PLACEHOLDER_ESTIMATE
                elif msg.get("type") == "function_call_output":
                    output = msg.get("output", "")
                    if not isinstance(output, str):
                        output = (
                            json.dumps(output) if isinstance(output, (dict, list)) else str(output)
                        )
                    if output and not output.startswith("[tool result cleared:"):
                        turn_tokens += _PLACEHOLDER_ESTIMATE
                    else:
                        turn_tokens += estimate_msg_tokens(msg)
                else:
                    turn_tokens += estimate_msg_tokens(msg)

            over_soft = (
                used_tokens + turn_tokens > budget or total_msgs + len(turn) > _SOFT_CAP_MSGS
            )

            if over_soft and not is_unconsolidated:
                # Consolidated turn over soft cap — stop (knowledge is in HISTORY.md)
                if not selected:
                    selected.append((turn, is_full))
                    used_tokens += turn_tokens
                break

            if over_soft and is_unconsolidated:
                # Unconsolidated turn over soft cap — compress to user + final assistant
                compressed = self._compress_turn(turn)
                if total_msgs + len(compressed) > _HARD_CAP_MSGS:
                    break  # hard cap reached — remaining handled by next consolidation
                compressed_tokens = sum(estimate_msg_tokens(m) for m in compressed)
                selected.append((compressed, True))  # already compressed, treat as full
                used_tokens += compressed_tokens
                total_msgs += len(compressed)
                continue

            selected.append((turn, is_full))
            used_tokens += turn_tokens
            total_msgs += len(turn)

        # Reverse to chronological order
        selected.reverse()

        # Flatten turns and apply placeholders to non-recent ones
        result: list[dict[str, Any]] = []
        n_full = sum(1 for _, f in selected if f)
        n_placeholder = len(selected) - n_full

        for turn_msgs, is_full in selected:
            for local_idx, msg in enumerate(turn_msgs):
                if is_full:
                    result.append(msg)
                elif msg.get("type") == "function_call_output":
                    # Native Responses API format — placeholder on `output` field
                    output = msg.get("output", "")
                    if not isinstance(output, str):
                        output = (
                            json.dumps(output) if isinstance(output, (dict, list)) else str(output)
                        )
                    if output and not output.startswith("[tool result cleared:"):
                        is_error = msg.get("is_error", False) or output.startswith(
                            ("Error", "BLOCKED")
                        )
                        tool_name = self._resolve_native_tool_name(turn_msgs, local_idx)
                        placeholder = _build_tool_placeholder(tool_name, output, is_error=is_error)
                        result.append({**msg, "output": placeholder})
                    else:
                        result.append(msg)
                elif (
                    msg.get("role") == "tool"
                    and msg.get("content")
                    and not msg["content"].startswith("[tool result cleared:")
                ):
                    content = msg["content"]
                    is_error = msg.get("is_error", False) or content.startswith(
                        ("Error", "BLOCKED")
                    )
                    tool_name = self._resolve_tool_name(turn_msgs, local_idx)
                    placeholder = _build_tool_placeholder(tool_name, content, is_error=is_error)
                    result.append({**msg, "content": placeholder})
                else:
                    result.append(msg)

        self._sessions[session_id] = result
        n_unconsolidated = len(turns) - unconsolidated_start
        logger.debug(
            "Smart loaded session {}: {} turns ({} full + {} placeholder, {} unconsolidated),"
            " {} msgs, ~{} tokens, budget {}",
            session_id,
            len(selected),
            n_full,
            n_placeholder,
            n_unconsolidated,
            len(result),
            used_tokens,
            budget,
        )
        return result

    def load_session(
        self,
        session_id: str,
        model: str,
        context_limit: int = 0,
        *,
        reserved_tokens: int = 0,
    ) -> list[dict[str, Any]]:
        """Load session items for the agent loop.

        If a compaction blob exists in meta.json and the model supports
        server compaction, returns blob items + post-blob items.
        Otherwise falls back to ``smart_load_session()``.

        ``reserved_tokens`` is forwarded to ``smart_load_session()`` to
        reserve space for the system prompt and current user message.
        """
        session_id = self._normalize_id(session_id)
        from workpilot.providers.client import _supports_server_compaction

        meta = self.read_meta(session_id)
        blob_entry = meta.get("compaction_blob")

        if blob_entry and _supports_server_compaction(model):
            blob_at = blob_entry.get("at", "")
            blobs = blob_entry.get("blobs", [])
            output = blob_entry.get("output", [])

            # Load items persisted AFTER the blob was saved
            post_blob = self.load_disk_messages(session_id, after_ts=blob_at)

            # Heal orphan function_calls after concatenating the full item
            # stream. Tool calls in output may have their results in post_blob
            # (cross-boundary pairs); healing segments independently would
            # mis-detect them as orphans and inject duplicate synthetic outputs.
            # Other sanitization (non-API roles, metadata keys) is done by
            # _prepare_items_for_api() at the provider boundary.
            items: list[dict[str, Any]] = list(blobs) + list(output) + post_blob
            self._heal_orphan_tool_calls(items, session_id)
            self._sessions[session_id] = list(items)
            logger.info(
                "Native session load {}: {} blob + {} output + {} post-blob",
                session_id,
                len(blobs),
                len(output),
                len(post_blob),
            )
            return items

        # No blob or model doesn't support compaction → existing smart load
        return self.smart_load_session(session_id, context_limit, reserved_tokens=reserved_tokens)

    @staticmethod
    def _group_into_turns(
        msgs: list[dict[str, Any]],
    ) -> list[list[dict[str, Any]]]:
        """Group messages into turns (user msg -> everything until next user msg).

        Leading non-user messages (e.g., system summaries) form their own
        turn if they precede the first user message.
        """
        turns: list[list[dict[str, Any]]] = []
        current: list[dict[str, Any]] = []
        for msg in msgs:
            if msg.get("role") == "user" and current:
                turns.append(current)
                current = []
            current.append(msg)
        if current:
            turns.append(current)
        return turns

    @staticmethod
    def _compress_turn(turn: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Compress a turn to user message + final assistant response.

        Drops intermediate tool_calls and tool results, keeping only the
        user input and the last assistant text.  Used for unconsolidated
        turns that exceed the message cap — preserves the conversation
        thread without the bulky tool chain.
        """
        result: list[dict[str, Any]] = []
        # Keep user messages
        for msg in turn:
            if msg.get("role") == "user":
                result.append(msg)

        # Find the last assistant message with actual text content
        last_assistant: dict[str, Any] | None = None
        for msg in reversed(turn):
            if msg.get("role") == "assistant" and msg.get("content"):
                last_assistant = msg
                break

        # Preserve _ts from the last message in the turn for compaction time-gap detection
        last_ts = turn[-1].get("_ts") if turn else None

        if last_assistant is not None:
            # Strip tool_calls from the kept assistant message
            cleaned = {k: v for k, v in last_assistant.items() if k != "tool_calls"}
            if last_ts:
                cleaned["_ts"] = last_ts
            result.append(cleaned)
        else:
            # No text assistant response — build a summary from tool names
            tool_names: list[str] = []
            for msg in turn:
                if msg.get("role") == "assistant":
                    for tc in msg.get("tool_calls", []):
                        name = tc.get("function", {}).get("name", "?")
                        if name not in tool_names:
                            tool_names.append(name)
            summary = ", ".join(tool_names) if tool_names else "no response"
            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": f"[tools used: {summary}]",
            }
            if last_ts:
                assistant_msg["_ts"] = last_ts
            result.append(assistant_msg)

        return result

    @staticmethod
    def _resolve_tool_name(msgs: list[dict[str, Any]], tool_idx: int) -> str:
        """Look backward from a tool message to find its name from assistant tool_calls."""
        tc_id = msgs[tool_idx].get("tool_call_id", "")
        for j in range(tool_idx - 1, -1, -1):
            if msgs[j].get("role") == "assistant":
                for tc in msgs[j].get("tool_calls", []):
                    if tc.get("id") == tc_id:
                        return str(tc.get("function", {}).get("name", "?"))
                break
        return "?"

    @staticmethod
    def _heal_orphan_tool_calls(msgs: list[dict[str, Any]], session_id: str = "") -> int:
        """Inject synthetic outputs for orphan function_call items.

        A crash between persisting the function_call and its output leaves
        orphans in the JSONL.  Rather than silently dropping them (which
        loses context), inject a synthetic ``function_call_output`` so the
        LLM knows a tool was called but the result was lost.

        Also handles Chat-format orphans: assistant messages with
        ``tool_calls`` that have no matching ``role: "tool"`` responses.

        Returns the number of healed items.
        """
        # Collect all output call_ids (native + Chat)
        output_ids: set[str] = set()
        for m in msgs:
            if m.get("type") == "function_call_output" and m.get("call_id"):
                output_ids.add(m["call_id"])
            if m.get("role") == "tool" and m.get("tool_call_id"):
                output_ids.add(m["tool_call_id"])

        healed = 0
        healed_ids: set[str] = set()
        insertions: list[tuple[int, dict[str, Any]]] = []

        for idx, m in enumerate(msgs):
            # Native format: function_call without matching output
            if (
                m.get("type") == "function_call"
                and m.get("call_id")
                and m["call_id"] not in output_ids
                and m["call_id"] not in healed_ids
            ):
                synthetic: dict[str, Any] = {
                    "type": "function_call_output",
                    "call_id": m["call_id"],
                    "output": f"[Result lost — session interrupted before "
                    f"{m.get('name', 'tool')} completed]",
                    "is_error": True,
                }
                # Propagate _ts so compaction time-gap heuristics stay consistent
                if m.get("_ts"):
                    synthetic["_ts"] = m["_ts"]
                insertions.append((idx + 1, synthetic))
                healed_ids.add(m["call_id"])
                healed += 1

            # Chat format: assistant tool_calls without matching tool messages
            if m.get("role") == "assistant" and m.get("tool_calls"):
                for tc in m["tool_calls"]:
                    tc_id = tc.get("id", "")
                    if tc_id and tc_id not in output_ids and tc_id not in healed_ids:
                        name = tc.get("function", {}).get("name", "tool")
                        synthetic_chat: dict[str, Any] = {
                            "role": "tool",
                            "tool_call_id": tc_id,
                            "content": f"[Result lost — session interrupted "
                            f"before {name} completed]",
                            "is_error": True,
                        }
                        if m.get("_ts"):
                            synthetic_chat["_ts"] = m["_ts"]
                        insertions.append((idx + 1, synthetic_chat))
                        healed_ids.add(tc_id)
                        healed += 1

        # Insert in reverse order so indices stay valid
        for insert_idx, item in reversed(insertions):
            msgs.insert(insert_idx, item)

        if healed:
            logger.warning(
                "Healed {} orphan tool call(s) in session {} (crash recovery)",
                healed,
                session_id or "?",
            )

        return healed

    @staticmethod
    def _resolve_native_tool_name(msgs: list[dict[str, Any]], output_idx: int) -> str:
        """Look backward from a function_call_output to find its name from the preceding function_call."""
        call_id = msgs[output_idx].get("call_id", "")
        for j in range(output_idx - 1, -1, -1):
            if msgs[j].get("type") == "function_call" and msgs[j].get("call_id") == call_id:
                return str(msgs[j].get("name", "?"))
        return "?"

    def generate_id(self) -> str:
        return str(uuid.uuid4())

    # ── Meta sidecar ────────────────────────────────────────────────────

    def _meta_path(self, session_id: str) -> Path | None:
        """Return the path to the meta.json sidecar file."""
        if not self._data_dir:
            return None
        safe_id = self._normalize_id(session_id)
        return self._data_dir / f"{safe_id}.meta.json"

    def read_meta(self, session_id: str) -> dict[str, Any]:
        """Read session metadata from the sidecar file."""
        path = self._meta_path(session_id)
        if not path or not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (json.JSONDecodeError, OSError):
            return {}

    def update_meta(self, session_id: str, **fields: Any) -> None:
        """Merge fields into the session metadata sidecar."""
        path = self._meta_path(session_id)
        if not path:
            return
        meta = self.read_meta(session_id)
        meta.update(fields)
        path.write_text(json.dumps(meta, default=str, ensure_ascii=False), encoding="utf-8")

    # ── Disk readers ────────────────────────────────────────────────────

    def load_disk_messages(
        self,
        session_id: str,
        *,
        after_ts: str | None = None,
    ) -> list[dict[str, Any]]:
        """Read messages from the session JSONL on disk.

        Optionally filters to messages with ``_ts > after_ts``.
        Always skips ``_compaction`` audit entries.
        """
        session_id = self._normalize_id(session_id)
        if not self._data_dir:
            return []
        path = self._session_path(session_id)
        if not path.exists():
            return []

        messages: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            # Skip audit entries
            if "_compaction" in msg:
                continue
            # Filter by timestamp
            if after_ts and msg.get("_ts", "") <= after_ts:
                continue
            messages.append(msg)
        return messages

    # ── Session file splitting ──────────────────────────────────────────

    _SPLIT_SIZE_BYTES = 32 * 1024 * 1024  # 32 MB

    def maybe_split_session(self, session_id: str) -> bool:
        """Split session JSONL at >32 MB using dual threshold (2-day / 50-msg).

        Returns True if a split occurred.
        """
        session_id = self._normalize_id(session_id)
        if not self._data_dir:
            return False
        path = self._session_path(session_id)
        if not path.exists():
            return False
        try:
            file_size = path.stat().st_size
        except OSError:
            return False
        if file_size <= self._SPLIT_SIZE_BYTES:
            return False

        # Read all messages from disk
        all_msgs: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    all_msgs.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

        if len(all_msgs) <= 50:
            return False

        now = datetime.now(UTC)
        two_days_ago = now.timestamp() - (2 * 86400)

        # Find 2-day boundary: archive messages ≥2 days old
        day_split = 0
        for i, msg in enumerate(all_msgs):
            ts_str = msg.get("_ts", "")
            if ts_str:
                try:
                    msg_time = datetime.fromisoformat(ts_str).timestamp()
                    if msg_time < two_days_ago:
                        day_split = i + 1
                    else:
                        break
                except (ValueError, TypeError):
                    continue

        # 50-message boundary: keep last 50 messages
        msg_split = max(0, len(all_msgs) - 50)

        # Use whichever keeps more (retain at least 50 msgs AND at least 2 days)
        split_idx = (
            min(day_split, msg_split) if day_split and msg_split else max(day_split, msg_split)
        )
        if split_idx <= 0:
            return False

        archive_msgs = all_msgs[:split_idx]
        keep_msgs = all_msgs[split_idx:]

        # Name archive by the last message date in archived portion
        last_ts = archive_msgs[-1].get("_ts", "")
        if last_ts:
            try:
                last_date = datetime.fromisoformat(last_ts).strftime("%Y-%m-%d")
            except (ValueError, TypeError):
                last_date = now.strftime("%Y-%m-%d")
        else:
            last_date = now.strftime("%Y-%m-%d")

        archive_path = self._data_dir / f"{self._normalize_id(session_id)}_{last_date}.jsonl"

        # Write archive (append if exists)
        with archive_path.open("a", encoding="utf-8") as f:
            for msg in archive_msgs:
                f.write(json.dumps(msg, default=str, ensure_ascii=False) + "\n")

        # Rewrite active file with kept messages only
        with path.open("w", encoding="utf-8") as f:
            for msg in keep_msgs:
                f.write(json.dumps(msg, default=str, ensure_ascii=False) + "\n")

        # Update in-memory cache
        self._sessions[self._normalize_id(session_id)] = keep_msgs

        logger.info(
            "Session split: {} archived {} messages, kept {}",
            session_id,
            len(archive_msgs),
            len(keep_msgs),
        )
        return True

    # ── Internal ────────────────────────────────────────────────────────

    def _session_path(self, session_id: str) -> Path:
        safe_id = self._normalize_id(session_id)
        return self._data_dir / f"{safe_id}.jsonl" if self._data_dir else Path("/dev/null")

    # Old-format file patterns for one-time migration to new constant keys
    _MIGRATE_PATTERNS: dict[str, str] = {
        "cloud_teams": "cloud_teams_*.jsonl",
        "cloud_web": "cloud_webchat_*.jsonl",
        "local_web": "web_w*-user.jsonl",
        "local_cli": "cli_local.jsonl",
    }

    def _maybe_migrate_legacy_session(self, session_id: str, target: Path) -> None:
        """Rename the most recent old-format session file to the canonical name."""
        norm = self._normalize_id(session_id)
        pattern = self._MIGRATE_PATTERNS.get(norm)
        if not pattern or not self._data_dir:
            return
        # Find old primary session files, excluding split archives and forks.
        candidates: list[tuple[float, Path]] = []
        for p in self._data_dir.glob(pattern):
            stem = p.stem
            if "_fork_" in stem or re.search(r"_\d{4}-\d{2}-\d{2}$", stem):
                continue
            try:
                candidates.append((p.stat().st_mtime, p))
            except OSError:
                continue
        if not candidates:
            return
        src = max(candidates, key=lambda item: item[0])[1]
        try:
            src.rename(target)
            logger.info("Migrated session {} -> {}", src.name, target.name)
            # Also migrate the meta sidecar if present
            old_meta = src.with_suffix(".meta.json")
            if old_meta.exists():
                old_meta.rename(target.with_suffix(".meta.json"))
        except OSError as exc:
            logger.warning("Session migration failed: {}", exc)

    def _load_from_disk(self, session_id: str) -> list[dict[str, Any]]:
        if not self._data_dir:
            return []
        path = self._session_path(session_id)
        if not path.exists():
            self._maybe_migrate_legacy_session(session_id, path)
        if not path.exists():
            return []
        messages: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    messages.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return messages

    def _persist(self, session_id: str, message: dict[str, Any]) -> None:
        if not self._data_dir:
            return
        path = self._session_path(session_id)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(message, default=str, ensure_ascii=False) + "\n")
