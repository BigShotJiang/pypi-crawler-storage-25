---
name: teams-message
description: Send Microsoft Teams messages to people, chats, or channels.
metadata:
  activation:
    keywords: [teams message, teams chat, teams channel, send message to, 发消息给]
    patterns:
      - "(?i)\\b(send|post|write|reply|tell|forward)\\b.{0,48}\\bteams\\b"
      - "(?i)\\bteams\\s+(message|msg|chat|channel)\\b"
      - "(?i)\\b(message|msg|chat)\\b.{0,32}\\b(on|in|to|via)\\s+teams\\b"
      - "(?i)(teams上(发|写|说|回|聊)|发到teams)"
      - "(?i)(发消息给|发.*teams.*消息|给.{0,10}发.{0,5}teams)"
      - "(?i)(给.{1,32}发(个|条)?消息|发(个|条)消息给)"
      - "(?i)\\b(send|post)\\s+(a\\s+)?(message|msg)\\s+to\\b"
  requires:
    tools: [MCP_teams]
---

# Teams Message

## Routing

| Intent | Signal | Action |
|---|---|---|
| Message someone else | Has recipient (name, team, channel, email, link) | `MCP_teams_SendMessageToChat` / `MCP_teams_SendMessageToChannel` (this skill) |
| Note to self | 发给我自己, save to Teams, 记一下 | `MCP_teams_SendMessageToSelf(...)` |
| Notify (current user) in Teams | 通知我, notify me, Teams 上提醒我 | `notify(channel='cloud')` — NOT this skill |
| Scheduled reminder via Teams | Teams上N分钟后提醒我, at 4:50 remind me on Teams | `cron(message=..., notify_channels=['cloud'])` — NOT this skill |
| Ambiguous | - | Investigate with read-only APIs; if still unclear, ask once with choices (never ping-pong — one confirm-prompt max). |

## Find the chatId / channelId

Pick the sub-section matching what the user gave you. If `MCP_teams` tools aren't visible, run `tools(name='MCP_teams')` first.

### Self chat

`MCP_teams_SendMessageToSelf(...)` — dedicated, no chatId. Fallback: `MCP_teams_SendMessageToChat(chatId="48:notes", ...)`.

### Teams link

Extract directly from the URL:
- Chat: `.../l/chat/19:...@.../conversations` → chatId
- Channel: `.../l/channel/19:...@...?groupId=...` → channelId + teamId (from `groupId`)

Verify via `MCP_teams_GetChat` / `MCP_teams_GetChannel` only when the URL provenance is uncertain; skip when you know the link is canonical.

### UPN or email

When you already have a UPN (`alias@domain`) or Entra object ID (GUID):

`MCP_teams_CreateChat(chatType="oneOnOne", members_upns=[myUPN, targetUPN])` — idempotent, returns the existing chat or creates one.

- **UPN format**: `alias@domain` (Microsoft corp: usually equals primary SMTP). Proxy SMTP aliases and bare usernames are rejected — fall back to the GUID `id` from user metadata.
- **Self**: pass `"me"` to any user tool; for teams, resolve `myUPN` once via `MCP_user_GetMyDetails`.
- **Shortcut**: if the `MCP_teams_ListChats()` from name resolution already returned a chat with the target UPN in `members`, reuse that chatId — skip `CreateChat`.

### Person's name (resolve → UPN)

Use `MCP_user_GetMultipleUsersDetails` — don't construct UPNs. Search is substring-only on `displayName` (alias/UPN substrings don't match, even with explicit `propertyToSearchBy`). Homonyms, stale accounts, and external guests all compete — a single-hit full-name search can still be wrong. Cross-validate before committing:

1. **Search** with the most specific term (full name > first+last > first name). For a bare first name, extract a full name from conversation/memory first if possible.
2. **Cross-check recent chats**: unfiltered `MCP_teams_ListChats()` → intersect candidate UPNs against chat `members`. Closest "frequently contacted" proxy (`MCP_user` has no relevance ranking).
3. **Free signals**: qualifiers in the user's phrasing ("<name> from the data team" → jobTitle/department/officeLocation); explicit UPN from memory or earlier turns.

**Commit silently only when signals converge** on one candidate. Otherwise follow §Safety "Ambiguous target". Then proceed with §UPN or email above.

### Past chat content (KQL / NL search)

When the target is a chat identified by content (e.g. "continue the deploy discussion"), not a person. Two tools — **KQL first, NL only for exploratory**:

1. `MCP_teams_SearchTeamMessagesQueryParameters(queryString="from:alice@contoso.com AND budget")` — KQL. Supports `from:`, `sent:`, `AND`/`OR`/`NOT`, `"phrase"`. Max 25/page; paginate with `from`/`size`.
2. `MCP_teams_SearchTeamsMessages(message="...")` — NL, Copilot-backed; use when sender/date/keywords are unknown. Returns `chatIds` for follow-up.

Filter chatIds by format:

| Format | Type |
|---|---|
| `19:{guid}_{guid}@unq.gbl.spaces` | 1:1 |
| `19:{hex}@thread.v2` | Group |
| `19:meeting_*@thread.v2` | Meeting |

Verify with `MCP_teams_GetChat` (topic, chatType) + `MCP_teams_ListChatMembers` (displayName, email). One clean match → use it; multiple/ambiguous → show target + draft together for a single confirmation.

### Team/channel name

1. `MCP_teams_ListTeams` → teamId.
2. `MCP_teams_ListChannels` → channelId. No channel specified: prefer `General`, then match team name, then ask.

## Send

- Chat/group: `MCP_teams_SendMessageToChat(chatId=..., content=..., contentType="html")`
- Channel: `MCP_teams_SendMessageToChannel(teamId=..., channelId=..., content=..., contentType="html")`
- Reply in a channel thread: `MCP_teams_ReplyToChannelMessage(teamId=..., channelId=..., messageId=..., content=..., contentType="html")`

Verify the response has `id` + `createdDateTime` before reporting success — a missing `id` is a silent send failure even when the call didn't raise.

### Content

Prefer `html`; use `text` only when explicitly requested. Max 32KB per message.

HTML: no `<style>`/`<script>`/`<iframe>`. Supported: `<b>`, `<i>`, `<a>`, `<ul>`, `<ol>`, `<li>`, `<table>`, `<br>`, `<p>`, `<pre>`, `<code>`. `markdown` contentType does NOT render — convert to HTML.

For @mentions, Adaptive Cards, or message importance, call `MCP_teams_GetRichMessageFormats` first — authoritative mention syntax (`<at>` via the `mentions` param), card templates, and importance levels.

### Message prefix

**Prepend [🤖] by default** (AI-generated indicator). Skip if saved memory or an explicit user turn has disabled it.

`html`: `<b>[🤖]</b> message...` | `text`: `[🤖] message...`

## Safety

- **Cross-org**: confirm before sending to external orgs.
- **Inactive**: `MCP_teams_ListChatMessages` or `MCP_teams_ListChannelMessages` (top=1), check `createdDateTime`. If older than 7 days, confirm.
- **Ambiguous target**: investigate with read-only APIs first, then confirm target + draft in one shot.

## Pitfalls

- `MCP_teams_SearchTeamMessagesQueryParameters` KQL on chatMessage: no `subject:`/`to:`/`hasAttachment:` — only `from:`/`sent:`/keywords/booleans. Unsupported filters fail silently.
- Both search tools cap at 25/page; paginate via `from`/`size` on the KQL tool.
- `MCP_teams_SearchTeamsMessages` (NL) has Substrate indexing lag; prefer KQL for "in the last few minutes".
- `MCP_teams_UpdateChatMessage` only works on your OWN messages.
- `MCP_teams_CreateChat` is idempotent — call directly; don't run an explicit **filtered** `MCP_teams_ListChats(memberUpns=...)` probe just to check if the chat exists (that's 2 calls for what CreateChat handles in 1). The §UPN or email Shortcut is different — it reuses an UNfiltered `ListChats()` already made during name resolution, and that's the correct path.
- `MCP_user_GetMultipleUsersDetails` is substring-matched, no caller-side ranking; `orderby` whitelist is small (`displayName` ✓; `jobTitle`/`givenName`/`relevance` ✗). Top-N unreliable for common first names — use full name, or widen `top` + tiebreakers.
