"""MCP CLI subcommands — workpilot mcp list|add|remove|get|setup|login|logout|test."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

if TYPE_CHECKING:
    import httpx

import typer
import yaml
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    mcp_app,
)
from workpilot.cli.commands import (
    resolve_config_path as _resolve_config_path,
)
from workpilot.cli.commands import (
    resolve_local_config_path as _resolve_local_config_path,
)
from workpilot.config.loader import ensure_schema_line
from workpilot.mcp.defaults import AGENCY_DESCRIPTIONS as _AGENCY_DESCRIPTIONS
from workpilot.mcp.defaults import get_default_description


def _load_yaml(config_path: Path) -> dict[str, Any]:
    return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}


def _save_mcp_servers(config_path: Path, servers: dict[str, dict[str, Any]]) -> None:
    """Update only the tools.mcp_servers section in a workpilot yaml file.

    Preserves the rest of the file as-is by doing targeted text replacement.
    Works for both workpilot.yaml (base) and workpilot.local.yaml (override).
    """

    content = config_path.read_text(encoding="utf-8") if config_path.is_file() else ""

    # Build the new mcp_servers YAML block
    lines: list[str] = []
    for name, srv in servers.items():
        lines.append(f"    {name}:")
        for key, val in srv.items():
            if isinstance(val, list):
                # Flow style for short lists: args: ["mcp", "icm"]
                items = ", ".join(_yaml_scalar(v) for v in val)
                lines.append(f"      {key}: [{items}]")
            elif isinstance(val, dict):
                lines.append(f"      {key}:")
                for dk, dv in val.items():
                    lines.append(f"        {dk}: {_yaml_scalar(dv)}")
            else:
                lines.append(f"      {key}: {_yaml_scalar(val)}")
    new_block = "\n".join(lines)

    # Try to find and replace existing tools.mcp_servers section
    # Pattern: "tools:\n  mcp_servers:\n" followed by indented content until next top-level key
    pattern = r"(tools:\s*\n\s*mcp_servers:\s*\n)((?:\s{4,}\S.*\n)*)"
    if re.search(pattern, content):
        replacement = f"tools:\n  mcp_servers:\n{new_block}\n"
        content = re.sub(pattern, lambda _: replacement, content)
    else:
        # No existing section — insert before channels: or append
        insert_before = re.search(r"^(channels:|cron:|logging:)", content, re.MULTILINE)
        block = f"\ntools:\n  mcp_servers:\n{new_block}\n\n"
        if insert_before:
            pos = insert_before.start()
            content = content[:pos] + block + content[pos:]
        else:
            content = content.rstrip() + "\n" + block

    config_path.write_text(content, encoding="utf-8")
    ensure_schema_line(config_path)


def _yaml_scalar(val: Any) -> str:
    """Format a scalar value for inline YAML."""
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, str):
        # Escape YAML double-quote special characters
        escaped = (
            val.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t")
        )
        return f'"{escaped}"'
    return str(val)


def _auth_label(srv: Any) -> str:
    """Short label for the auth mechanism used by a server."""
    if srv.auth.type == "oauth" and srv.auth.client_id:
        return "entra"
    if srv.auth.type == "oauth":
        return "oauth"
    if srv.auth.type == "bearer":
        return "bearer"
    if srv.auth.type == "implicit":
        return "token"
    return "none"


def _status_label(name: str, srv: Any) -> str:
    """Status label showing token availability."""
    if srv.enabled is False:
        return "[dim]disabled[/dim]"
    suffix = " [dim](auto)[/dim]" if srv.enabled == "auto" else ""
    # Stdio servers handle auth internally — always "ready"
    if srv.command:
        return f"[green]\u2713 ready[/green]{suffix}"
    from workpilot.mcp.auth import has_cached_token

    if has_cached_token(name, srv):
        return f"[green]\u2713 ready[/green]{suffix}"
    return f"[yellow]\u26a0 no token[/yellow]{suffix}"


@mcp_app.command("list")
def mcp_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured MCP servers with auth and token status."""
    cfg = _load_config_safe(config)

    servers = cfg.tools.mcp_servers
    if not servers:
        console.print("[dim]No MCP servers configured.[/dim]")
        return

    table = Table(title="MCP Servers")
    table.add_column("Name", style="bold")
    table.add_column("Description")
    table.add_column("Auth", style="dim")
    table.add_column("Status")

    for name, srv in servers.items():
        desc = (
            srv.description
            if srv.description is not None
            else get_default_description(name, is_agency=srv.is_agency) or ""
        )
        name_display = f"[dim]{name}[/dim]" if not srv.enabled else name
        table.add_row(name_display, desc, _auth_label(srv), _status_label(name, srv))

    console.print(table)


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Argument(..., help="MCP server name"),
    command: list[str] | None = typer.Argument(None, help="Server command and args (after --)"),
    transport: str = typer.Option(
        "stdio", "--transport", "-t", help="Transport: stdio (default) or http"
    ),
    url: str | None = typer.Option(
        None, "--url", help="HTTP endpoint URL (alternative to command)"
    ),
    env: list[str] | None = typer.Option(
        None, "-e", "--env", help="Environment variable KEY=VALUE (repeatable)"
    ),
    timeout: int | None = typer.Option(None, "--timeout", help="Tool call timeout in seconds"),
    risk: int | None = typer.Option(None, "--risk", help="Server default risk score: 0-10"),
    header: list[str] | None = typer.Option(
        None, "--header", help="HTTP header 'Key: Value' (repeatable)"
    ),
    auth: str | None = typer.Option(
        None, "--auth", help="Auth type: oauth (bearer auto-detected from --header)"
    ),
    client_id: str | None = typer.Option(None, "--client-id", help="OAuth client ID"),
    grant_type: str | None = typer.Option(
        None, "--grant-type", help="OAuth grant: authorization_code or client_credentials"
    ),
    callback_port: int | None = typer.Option(None, "--callback-port", help="OAuth callback port"),
    auth_server_url: str | None = typer.Option(
        None, "--auth-server-url", help="OAuth auth server URL (skip discovery)"
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server to the configuration.

    Stdio: workpilot mcp add <name> -- <command> [args...]
    HTTP:  workpilot mcp add --transport http <name> --url <url>
    """
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    # Read local override to update (never touch the base workpilot.yaml)
    local_raw = _load_yaml(local_path) if local_path.is_file() else {}
    tools_section = local_raw.setdefault("tools", {})
    mcp_section = tools_section.setdefault("mcp_servers", {})

    # Collision check: only block if local config has substantial config
    # (not just enabled: true/false). Simple enable/disable entries are
    # overwritten freely — `wp mcp add` is a "configure" action.
    existing = mcp_section.get(name)
    if existing and not force:
        has_real_config = isinstance(existing, dict) and any(k != "enabled" for k in existing)
        if has_real_config:
            console.print(
                f"[yellow]MCP server '{name}' already configured in local config. Use --force to overwrite.[/yellow]"
            )
            raise typer.Exit(1)

    entry: dict[str, Any] = {}

    # Auto-detect well-known servers when no explicit --url or command given.
    user_explicit = transport != "stdio" or url or command
    if not user_explicit:
        from workpilot.mcp.defaults import extract_params

        merged_cfg = _load_config_safe(str(config_path.parent))
        merged_srv = merged_cfg.tools.mcp_servers.get(name)
        if merged_srv and merged_srv.url:
            # Known HTTP server — enable + auth + optional param config
            entry["enabled"] = True
            # Prompt for optional params derived from {var} in url/headers/env
            params = extract_params(merged_srv.url, merged_srv.headers, merged_srv.env)
            if params:
                resolved = _prompt_optional_params(name, params)
                if resolved:
                    # Write resolved URL/headers to local config
                    if merged_srv.url and "{" in merged_srv.url:
                        resolved_url = merged_srv.url
                        for pk, pv in resolved.items():
                            resolved_url = resolved_url.replace(f"{{{pk}}}", pv)
                        if "{" not in resolved_url:
                            entry["url"] = resolved_url
                    if merged_srv.headers:
                        resolved_hdrs: dict[str, str] = {}
                        for hk, hv in merged_srv.headers.items():
                            for pk, pv in resolved.items():
                                hv = hv.replace(f"{{{pk}}}", pv)
                            resolved_hdrs[hk] = hv
                        if resolved_hdrs:
                            entry["headers"] = resolved_hdrs

            mcp_section[name] = entry
            _save_mcp_servers(local_path, mcp_section)
            console.print(
                f"  [green]\u2713[/green] MCP server [bold]{name}[/bold] enabled in [cyan]{local_path}[/cyan]"
            )
            return

    if transport == "http" or url:
        # HTTP transport
        if not url and command:
            url = command[0]  # first positional arg as URL
        if not url:
            console.print("[red]HTTP transport requires --url or a URL argument.[/red]")
            raise typer.Exit(1)
        entry["url"] = url
        # Headers → auth config
        if header:
            for h in header:
                if ":" in h:
                    key, val = h.split(":", 1)
                    key, val = key.strip(), val.strip()
                    if key.lower() == "authorization" and val.lower().startswith("bearer "):
                        entry.setdefault("auth", {})["type"] = "bearer"
                        entry["auth"]["token"] = val[7:]  # strip "Bearer "
        # OAuth auth config (overrides any bearer detected from --header)
        if auth and auth != "oauth":
            console.print(
                f"[red]Invalid --auth '{auth}'. Use 'oauth' (bearer is auto-detected from --header).[/red]"
            )
            raise typer.Exit(1)
        if auth == "oauth" or client_id:
            auth_cfg = entry.setdefault("auth", {})
            auth_cfg.pop("token", None)  # clear conflicting bearer keys
            auth_cfg.pop("token_env", None)
            auth_cfg["type"] = "oauth"
            if client_id:
                auth_cfg["client_id"] = client_id
            if grant_type:
                if grant_type not in ("authorization_code", "client_credentials"):
                    console.print(
                        f"[red]Invalid --grant-type '{grant_type}'. "
                        "Use 'authorization_code' or 'client_credentials'.[/red]"
                    )
                    raise typer.Exit(1)
                auth_cfg["grant_type"] = grant_type
            if callback_port is not None:
                auth_cfg["callback_port"] = callback_port
            if auth_server_url:
                auth_cfg["auth_server_url"] = auth_server_url
        # Env for HTTP (rare but supported)
        if env:
            env_dict: dict[str, str] = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict
    else:
        # Stdio transport
        if not command:
            console.print(
                "[red]Stdio transport requires a command. Usage: wp mcp add <name> -- <command> [args...][/red]"
            )
            raise typer.Exit(1)
        entry["command"] = command[0]
        if len(command) > 1:
            entry["args"] = list(command[1:])
        # Env vars
        if env:
            env_dict = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict

    # Optional per-server overrides
    if timeout is not None:
        entry["timeout"] = timeout
    if risk is not None:
        entry["risk"] = risk

    # Prompt for description if not already set (helps LLM discover the server)
    if "description" not in entry:
        try:
            desc = console.input(
                f"  [dim]Description for [bold]{name}[/bold] "
                "(helps LLM understand when to use it, Enter to skip): [/dim]"
            ).strip()
            if desc:
                entry["description"] = desc[:100]
        except (EOFError, KeyboardInterrupt):
            pass

    mcp_section[name] = entry
    _save_mcp_servers(local_path, mcp_section)
    console.print(
        f"  [green]\u2713[/green] MCP server [bold]{name}[/bold] added to [cyan]{local_path}[/cyan]"
    )

    # Auto-test connectivity
    cfg = _load_config_safe(config)
    ok, msg = _test_single_server(name, cfg)
    if not ok:
        m = msg.lower()
        if "401" in m or "unauthorized" in m or "token" in m or "auth" in m:
            console.print(f"[dim]Tip: run 'workpilot mcp login {name}' to authenticate.[/dim]")


@mcp_app.command("add-json")
def mcp_add_json(
    name: str = typer.Argument(..., help="MCP server name"),
    json_config: str = typer.Argument(..., help="JSON configuration string"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server from a JSON configuration string.

    Example: workpilot mcp add-json icm '{"command":"agency","args":["mcp","icm"],"timeout":60}'
    """

    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    try:
        entry = json.loads(json_config)
    except json.JSONDecodeError as exc:
        console.print(f"[red]Invalid JSON: {exc}[/red]")
        raise typer.Exit(1)

    if not isinstance(entry, dict):
        console.print("[red]JSON must be an object.[/red]")
        raise typer.Exit(1)

    local_raw = (_load_yaml(local_path) if local_path.is_file() else {}) or {}
    mcp_section = local_raw.setdefault("tools", {}).setdefault("mcp_servers", {})

    # Collision check: only block if local config has substantial config
    existing = mcp_section.get(name)
    if existing and not force:
        has_real_config = isinstance(existing, dict) and any(k != "enabled" for k in existing)
        if has_real_config:
            console.print(
                f"[yellow]MCP server '{name}' already configured in local config. Use --force to overwrite.[/yellow]"
            )
            raise typer.Exit(1)
    mcp_section[name] = entry
    _save_mcp_servers(local_path, mcp_section)
    console.print(
        f"  [green]\u2713[/green] MCP server [bold]{name}[/bold] added to [cyan]{local_path}[/cyan]"
    )


@mcp_app.command("remove")
def mcp_remove(
    name: str | None = typer.Argument(None, help="MCP server name to remove"),
    all_servers: bool = typer.Option(
        False, "--all", "-a", help="Remove all locally configured MCP servers"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation for --all"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Remove MCP server(s) from the configuration."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    if all_servers and name:
        console.print("[yellow]Provide either a server name or --all, not both.[/yellow]")
        raise typer.Exit(1)

    if all_servers:
        _remove_all(local_path, force=force)
        return

    if not name:
        console.print("[yellow]Provide a server name or use --all.[/yellow]")
        raise typer.Exit(1)

    # Check existence against merged config
    merged_cfg = _load_config_safe(str(config_path.parent))
    if name not in merged_cfg.tools.mcp_servers:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    removed_from: list[str] = []

    # Remove from local override if present
    if local_path.is_file():
        local_raw = _load_yaml(local_path)
        local_mcp = local_raw.get("tools", {}).get("mcp_servers", {})
        if name in local_mcp:
            del local_mcp[name]
            if local_mcp:
                _save_mcp_servers(local_path, local_mcp)
            else:
                # Last server removed — wipe the tools.mcp_servers key from the file
                tools_sec = local_raw.get("tools", {})
                tools_sec.pop("mcp_servers", None)
                if not tools_sec:
                    local_raw.pop("tools", None)
                from workpilot.config.loader import save_yaml

                save_yaml(local_path, local_raw)
            removed_from.append(str(local_path))

    # Remove from base config if present
    base_raw = _load_yaml(config_path) if config_path.is_file() else {}
    base_mcp = base_raw.get("tools", {}).get("mcp_servers", {})
    if name in base_mcp:
        del base_mcp[name]
        _save_mcp_servers(config_path, base_mcp)
        removed_from.append(str(config_path))

    if removed_from:
        console.print(
            f"  [green]\u2713[/green] MCP server [bold]{name}[/bold] removed"
            f" from [cyan]{', '.join(removed_from)}[/cyan]"
        )
    else:
        console.print(
            f"[yellow]MCP server '{name}' exists in merged config but was not found "
            f"in any editable file (may be inherited via extends: or bundled defaults).[/yellow]"
        )


def _remove_all(local_path: Path, *, force: bool = False) -> None:
    """Remove all MCP servers from local config."""
    local_raw = _load_yaml(local_path) if local_path.is_file() else {}
    if not isinstance(local_raw, dict):
        console.print("[yellow]Local config is not a valid YAML mapping.[/yellow]")
        return
    tools = local_raw.get("tools")
    local_mcp = tools.get("mcp_servers", {}) if isinstance(tools, dict) else {}
    if not isinstance(local_mcp, dict):
        console.print("[yellow]tools.mcp_servers is not a valid YAML mapping.[/yellow]")
        return

    if not local_mcp:
        console.print("[dim]No MCP servers in local config.[/dim]")
        return

    names = list(local_mcp.keys())
    console.print(
        f"  Will remove [bold]{len(names)}[/bold] servers: [cyan]{', '.join(names)}[/cyan]"
    )

    if not force:
        confirm = typer.confirm("  Proceed?", default=False)
        if not confirm:
            console.print("  [dim]Cancelled.[/dim]")
            return

    tools_sec = local_raw.get("tools", {})
    tools_sec.pop("mcp_servers", None)
    if not tools_sec:
        local_raw.pop("tools", None)

    from workpilot.config.loader import save_yaml

    save_yaml(local_path, local_raw)
    console.print(
        f"  [green]\u2713[/green] Removed {len(names)} MCP servers from {local_path.name}"
    )


@mcp_app.command("get")
def mcp_get(
    name: str = typer.Argument(..., help="MCP server name"),
    raw_output: bool = typer.Option(False, "--raw", help="Output as JSON"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show detailed configuration for a specific MCP server."""

    cfg = _load_config_safe(config)
    srv = cfg.tools.mcp_servers.get(name)

    if srv is None:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    if raw_output:
        console.print(json.dumps(srv.model_dump(exclude_none=True), indent=2))
        return

    # Formatted output
    if srv.command:
        transport = "stdio"
        target = f"{srv.command} {' '.join(srv.args)}"
    elif srv.url:
        transport = "http"
        target = srv.url
    else:
        transport = "unknown"
        target = ""

    console.print(f"[bold]Server:[/bold] {name}")
    if srv.description is not None:
        effective_desc = srv.description
    else:
        effective_desc = get_default_description(name, is_agency=srv.is_agency) or ""
    if effective_desc:
        console.print(f"[bold]Description:[/bold] {effective_desc}")
    console.print(f"[bold]Enabled:[/bold] {'yes' if srv.enabled else '[red]no[/red]'}")
    console.print(f"[bold]Transport:[/bold] {transport}")
    console.print(f"[bold]{'Command' if srv.command else 'URL'}:[/bold] {target}")

    if srv.is_agency:
        console.print("[bold]Agency:[/bold] yes (auto-detected)")

    if srv.timeout is not None:
        console.print(f"[bold]Timeout:[/bold] {srv.timeout}s")
    else:
        default = "120s" if srv.is_agency else "60s"
        console.print(f"[bold]Timeout:[/bold] {default} (default)")

    if srv.risk is not None:
        console.print(f"[bold]Risk:[/bold] {srv.risk}")
    else:
        console.print("[bold]Risk:[/bold] (policy/auto)")

    if srv.env:
        env_str = ", ".join(f"{k}=..." for k in srv.env)
        console.print(f"[bold]Env:[/bold] {env_str}")

    if srv.command:
        console.print("[bold]Auth:[/bold] none (stdio — handled internally)")
    else:
        console.print(f"[bold]Auth:[/bold] {srv.auth.type}")


def _test_mcp_connect(
    srv_name: str,
    *,
    command: str | None = None,
    args: list[str] | None = None,
    url: str | None = None,
    headers: dict[str, str] | None = None,
    auth: httpx.Auth | None = None,
    timeout: float = 60.0,
) -> tuple[bool, str, list[dict[str, Any]]]:
    """Low-level connect test. Returns ``(ok, message, tools_list)``."""
    import asyncio as _asyncio

    async def _connect() -> tuple[bool, str, list[dict[str, Any]]]:
        from workpilot.mcp.client import MCPClient

        client = MCPClient(
            command=command,
            args=args,
            url=url,
            headers=headers,
            auth=auth,
            name=srv_name,
            legacy_protocol=command is not None,
        )
        try:
            async with _asyncio.timeout(2 * timeout):
                await client.connect(timeout=timeout)
            tools = await client.list_tools(timeout=timeout)
            protocol = client.protocol_version or "unknown"
            return True, f"{len(tools)} tools (protocol {protocol})", tools
        except TimeoutError:
            return False, f"timeout ({timeout:.0f}s)", []
        except Exception as exc:
            return False, str(exc), []
        finally:
            try:
                await client.disconnect()
            except Exception:
                pass

    try:
        return _asyncio.run(_connect())
    except Exception as exc:
        return False, str(exc), []


def _test_one_sync(
    name: str,
    cfg: Any,
    *,
    timeout_override: int | None = None,
) -> tuple[bool, str, list[dict[str, Any]]]:
    """Full test for one server (auth + connect + list tools).

    Runs everything synchronously (spawns its own event loop).
    Returns ``(ok, message, tools_list)``.
    """
    import asyncio as _asyncio

    srv = cfg.tools.mcp_servers.get(name)
    if srv is None:
        return False, "not found in config", []
    if not srv.enabled:
        return False, "disabled", []
    if not srv.command and not srv.url:
        return False, "no command or url configured", []

    # Timeout
    if timeout_override is not None:
        timeout = max(1.0, float(timeout_override))
    elif srv.timeout is not None:
        timeout = max(1.0, float(srv.timeout))
    elif srv.is_agency:
        timeout = 120.0
    else:
        timeout = 60.0

    # Substitute per-server connectivity-test defaults (e.g. ADO org =
    # "microsoft") into any still-unresolved {var} placeholders so the
    # test can proceed even when the user skipped param prompts during
    # setup. Runtime tool calls still require properly resolved values.
    from workpilot.mcp.defaults import TEST_PARAM_DEFAULTS, resolve_server_params

    test_defaults = TEST_PARAM_DEFAULTS.get(name, {})
    test_url, test_headers_map, _, _ = resolve_server_params(
        srv.url, dict(srv.headers or {}), env=None, overrides=test_defaults
    )

    # Resolve auth
    headers: dict[str, str] | None = None
    auth_provider = None
    if test_url:
        try:
            resolved = _asyncio.run(_resolve_auth_headers_for_test(srv, cfg))
        except Exception:
            resolved = {}
        all_headers = {**test_headers_map, **resolved}
        if any(k.lower() == "authorization" for k in all_headers):
            headers = all_headers
        else:
            # Entra-protected servers: use MSAL (silent → interactive) to
            # bypass MCP SDK OAuth which sends resource+scope that Entra
            # rejects (AADSTS9010010).
            from workpilot.mcp.auth import acquire_entra_token_for_server

            is_entra, entra_token = acquire_entra_token_for_server(
                test_url, test_headers_map, timeout=2.0
            )
            if entra_token:
                headers = {**test_headers_map, "Authorization": f"Bearer {entra_token}"}
            elif not is_entra:
                # Non-Entra server — fall through to SDK OAuth auto-discovery
                try:
                    from workpilot.mcp.oauth_provider import create_oauth_auth

                    auth_provider = _asyncio.run(create_oauth_auth(name, srv, cfg.providers))
                except Exception as exc:
                    if srv.auth.type == "oauth":
                        return False, f"OAuth setup failed: {exc}", []
                    auth_provider = None
                if auth_provider is not None:
                    headers = {
                        k: v for k, v in test_headers_map.items() if k.lower() != "authorization"
                    }
                else:
                    headers = dict(test_headers_map)
            else:
                # Entra server but login failed — still attempt connect (will get 401)
                headers = dict(test_headers_map)

    return _test_mcp_connect(
        name,
        command=srv.command,
        args=srv.args if srv.args else None,
        url=test_url,
        headers=headers,
        auth=auth_provider,
        timeout=timeout,
    )


def _test_single_server(
    name: str,
    cfg: Any,
    *,
    show_tools: bool = False,
    timeout_override: int | None = None,
) -> tuple[bool, str]:
    """Test one server with spinner + result display. Returns (ok, message)."""
    import threading

    from rich.live import Live
    from rich.spinner import Spinner
    from rich.text import Text

    srv = cfg.tools.mcp_servers.get(name)
    if srv is None:
        console.print(f"[red]MCP server '{name}' not found in config.[/red]")
        return False, "not found"

    label = srv.url or (f"{srv.command} {' '.join(srv.args)}" if srv.command else "?")
    spinner = Spinner("dots", text=Text.assemble(("  ", ""), (name, "bold"), f"  {label}"))

    result_holder: list[tuple[bool, str, list[dict[str, Any]]]] = []

    def _run() -> None:
        try:
            result_holder.append(_test_one_sync(name, cfg, timeout_override=timeout_override))
        except Exception as exc:
            result_holder.append((False, str(exc), []))

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    with Live(spinner, console=console, refresh_per_second=4, transient=True):
        t.join()

    ok, msg, tools = result_holder[0] if result_holder else (False, "no result", [])
    icon = "[green]\u2713[/green]" if ok else "[red]\u2717[/red]"
    console.print(f"{icon}  [bold]{name}[/bold]  {msg}")
    if ok and show_tools and tools:
        from rich.table import Table as RichTable

        tbl = RichTable(title=f"Tools ({len(tools)})")
        tbl.add_column("Name", style="bold")
        tbl.add_column("Description")
        for tool in tools:
            tbl.add_row(tool.get("name", "?"), tool.get("description", "")[:80])
        console.print(tbl)
    return ok, msg


def _test_servers_live(
    targets: list[str],
    cfg: Any,
    *,
    show_tools: bool = False,
    timeout_override: int | None = None,
) -> int:
    """Test multiple servers concurrently with live per-server spinners.

    Returns number of servers that passed.
    """
    import threading
    import time

    from rich.live import Live
    from rich.spinner import Spinner
    from rich.table import Table as RichTable
    from rich.text import Text

    # Shared state
    lock = threading.Lock()
    status: dict[str, str] = {n: "waiting" for n in targets}
    results: dict[str, tuple[bool, str, list[dict[str, Any]]]] = {}

    def run_one(name: str) -> None:
        with lock:
            status[name] = "testing"
        try:
            result = _test_one_sync(name, cfg, timeout_override=timeout_override)
        except Exception as exc:
            result = (False, str(exc), [])
        with lock:
            results[name] = result
            status[name] = "done"

    # Build the live display
    spinner_frames = Spinner("dots")

    def render() -> RichTable:
        with lock:
            snap_status = status.copy()
            snap_results = results.copy()
        tbl = RichTable(box=None, show_header=False, padding=(0, 1))
        tbl.add_column(width=2)  # status icon
        tbl.add_column(min_width=18)  # name
        tbl.add_column()  # message
        for name in targets:
            st = snap_status.get(name, "waiting")
            if st == "done":
                ok, msg, _ = snap_results.get(name, (False, "", []))
                icon = "[green]\u2713[/green]" if ok else "[red]\u2717[/red]"
                tbl.add_row(icon, f"[bold]{name}[/bold]", msg)
            elif st == "testing":
                tbl.add_row(
                    spinner_frames,
                    Text(name, style="bold"),
                    Text("connecting...", style="dim"),
                )
            else:
                tbl.add_row("", f"[dim]{name}[/dim]", "")
        return tbl

    # Launch threads
    threads = [threading.Thread(target=run_one, args=(n,), daemon=True) for n in targets]
    for t in threads:
        t.start()

    with Live(
        render(),
        console=console,
        refresh_per_second=4,
        vertical_overflow="visible",
    ) as live:
        while any(t.is_alive() for t in threads):
            time.sleep(0.08)
            live.update(render())
        live.update(render())

    # Show tool details after live display
    if show_tools:
        for name in targets:
            ok, _, tools = results.get(name, (False, "", []))
            if ok and tools:
                tbl = RichTable(title=f"{name} — Tools ({len(tools)})")
                tbl.add_column("Name", style="bold")
                tbl.add_column("Description")
                for tool in tools:
                    tbl.add_row(tool.get("name", "?"), tool.get("description", "")[:80])
                console.print(tbl)

    return sum(1 for ok, _, _ in results.values() if ok)


@mcp_app.command("test")
def mcp_test(
    name: str | None = typer.Argument(None, help="MCP server name (omit for all enabled)"),
    show_tools: bool = typer.Option(False, "--tools", "-t", help="List discovered tools"),
    timeout_override: int | None = typer.Option(
        None, "--timeout", help="Override timeout in seconds"
    ),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Test connectivity and auth for MCP servers.

    Without a name: test all enabled servers with cached tokens.
    With a name: test a specific server.
    """
    cfg = _load_config_safe(config)

    if name is not None:
        ok, _msg = _test_single_server(
            name, cfg, show_tools=show_tools, timeout_override=timeout_override
        )
        if not ok:
            raise typer.Exit(1)
        return

    # Batch mode: test all enabled servers with cached tokens
    from workpilot.mcp.auth import has_cached_token

    targets = []
    for srv_name, srv in cfg.tools.mcp_servers.items():
        if srv.enabled is False:
            continue
        if srv.enabled == "auto" and not has_cached_token(srv_name, srv):
            continue
        targets.append(srv_name)

    if not targets:
        console.print("[dim]No testable servers (all disabled or no cached tokens).[/dim]")
        return

    passed = _test_servers_live(
        targets, cfg, show_tools=show_tools, timeout_override=timeout_override
    )
    console.print(f"\n[bold]Result:[/bold] {passed}/{len(targets)} passed")
    if passed < len(targets):
        raise typer.Exit(1)


async def _resolve_auth_headers_for_test(srv: Any, cfg: Any) -> dict[str, str]:
    """Resolve auth headers for the test command."""
    from workpilot.mcp.auth import resolve_auth_headers

    return await resolve_auth_headers(srv, cfg.providers)


def _refresh_path() -> None:
    """Refresh PATH so a just-installed binary can be found."""

    if sys.platform == "win32":
        try:
            r = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    '[System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + '
                    '[System.Environment]::GetEnvironmentVariable("Path","User")',
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                os.environ["PATH"] = r.stdout.strip()
        except Exception:
            pass
    else:
        # Append common install directories if not already in PATH
        for d in ("~/.local/bin", "~/bin", "/usr/local/bin"):
            expanded = os.path.expanduser(d)
            if os.path.isdir(expanded) and expanded not in os.environ.get("PATH", ""):
                os.environ["PATH"] = expanded + os.pathsep + os.environ.get("PATH", "")


def _ensure_agency_installed(raise_on_failure: bool = True) -> str | None:
    """Check for Agency CLI binary (no auto-install).

    Returns binary path if found, else prints install instructions.
    """
    agency_bin = shutil.which("agency")
    if agency_bin:
        return agency_bin

    if sys.platform == "win32":
        install_cmd = 'iex "& { $(irm https://aka.ms/InstallTool.ps1)} agency"'
    else:
        install_cmd = "curl -sSfL https://aka.ms/InstallTool.sh | sh -s agency"

    console.print(
        "[yellow]Agency CLI not found.[/yellow]\n"
        f"  Install: [cyan]{install_cmd}[/cyan]\n"
        "  [dim]Most servers are available via HTTP without Agency."
        " Use [bold]wp mcp setup[/bold] instead.[/dim]"
    )
    if raise_on_failure:
        raise typer.Exit(1)
    return None


def _is_recommended(name: str) -> bool:
    """True if server should be pre-selected in --all / interactive default.

    Uses detected user profile: core + office always, engineering/data
    only when relevant tools are detected.
    """
    recommended = _get_recommended_servers()
    return name in recommended


# Cache so detection runs once per process.
_recommended_cache: set[str] | None = None


def _get_recommended_servers() -> set[str]:
    """Return the set of server names to pre-select, based on environment detection."""
    global _recommended_cache  # noqa: PLW0603
    if _recommended_cache is not None:
        return _recommended_cache

    from workpilot.mcp.defaults import (
        GROUP_DATA,
        GROUP_ENGINEERING,
        GROUP_OFFICE,
        NOT_RECOMMENDED,
    )

    recommended = set(GROUP_OFFICE)

    # Detector failures must never abort the setup wizard.
    try:
        if _detect_engineering_context():
            recommended |= GROUP_ENGINEERING
    except Exception:
        pass
    try:
        if _detect_data_context():
            recommended |= GROUP_DATA
    except Exception:
        pass

    recommended -= NOT_RECOMMENDED
    _recommended_cache = recommended
    return recommended


def _detect_engineering_context() -> bool:
    """True if dev/engineering tools are detected."""
    import shutil

    for tool in ("git", "gh", "az"):
        if shutil.which(tool):
            return True
    if os.environ.get("GITHUB_TOKEN") or os.environ.get("AZURE_DEVOPS_EXT_PAT"):
        return True
    try:
        ado_org, _ = _detect_ado_remote()
        if ado_org:
            return True
    except Exception:
        pass
    return False


def _detect_data_context() -> bool:
    """True if Kusto/KQL tools or files are detected."""
    import shutil

    if shutil.which("kusto") or shutil.which("fabric-rti-mcp"):
        return True
    if os.environ.get("KUSTO_SERVICE_URI"):
        return True
    # cwd + one level down. OSError catch handles cloud-mount hangs
    # (TimeoutError is an OSError subclass).
    try:
        cwd = Path.cwd()
        if any(cwd.glob("*.kql")) or any(cwd.glob("*/*.kql")):
            return True
    except OSError:
        pass
    return False


def _discover_agency_servers(
    agency_bin: str, http_available: set[str] | None = None
) -> list[tuple[str, str]]:
    """Run `agency mcp --help` and parse available servers.

    Returns list of (name, description) tuples.
    *http_available*: server names already available via HTTP (skipped).
    """

    try:
        result = subprocess.run(
            [agency_bin, "mcp", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        help_text = result.stdout + result.stderr
    except Exception as exc:
        console.print(f"[red]Failed to run 'agency mcp --help': {exc}[/red]")
        raise typer.Exit(1)

    # Skip built-in commands + servers already available via HTTP
    if http_available is None:
        http_available = set()
    skip = {
        "help",
        "remote",
        "local",
        "npx",
        "calculator",
        "stack",
    } | http_available
    discovered: list[tuple[str, str]] = []
    in_commands = False
    for line in help_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("Commands:"):
            in_commands = True
            continue
        if stripped.startswith("Options:"):
            in_commands = False
            continue
        if in_commands and stripped:
            parts = stripped.split(None, 1)
            if parts and parts[0] not in skip:
                name = parts[0]
                desc = parts[1].strip() if len(parts) > 1 else ""
                # Clean up common prefixes from descriptions
                for prefix in ("Launch ", "Launch a "):
                    if desc.startswith(prefix):
                        desc = desc[len(prefix) :]
                        break
                # Use curated description if available, else cleaned help text
                desc = _AGENCY_DESCRIPTIONS.get(name, desc)
                discovered.append((name, desc))

    return discovered


def _detect_ado_remote() -> tuple[str | None, str | None]:
    """Try to detect ADO org and project from current git remote.

    Returns ``(org, project)`` — either may be ``None``.
    """
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        url = result.stdout.strip()
        if not url:
            return None, None

        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        path = parsed.path.lstrip("/") if parsed.path else ""

        # Handle SCP-like SSH remotes: git@ssh.dev.azure.com:v3/org/project/repo
        if not hostname and ":" in url:
            try:
                _, host_path = url.rsplit("@", 1)
                host, raw_path = host_path.split(":", 1)
                hostname = host.lower()
                path = raw_path.lstrip("/")
            except ValueError:
                hostname, path = "", ""

        parts = path.split("/") if path else []

        # https://dev.azure.com/org/project/_git/repo
        if hostname == "dev.azure.com":
            org = parts[0] if len(parts) >= 1 else None
            project = parts[1] if len(parts) >= 2 else None
            return org or None, project or None
        # git@ssh.dev.azure.com:v3/org/project/repo
        if hostname == "ssh.dev.azure.com":
            if len(parts) >= 2 and parts[0] == "v3":
                org = parts[1] if len(parts) >= 2 else None
                project = parts[2] if len(parts) >= 3 else None
                return org or None, project or None
        # https://org.visualstudio.com/project/_git/repo
        if hostname.endswith(".visualstudio.com"):
            org = hostname.split(".")[0] if hostname else None
            project = parts[0] if len(parts) >= 1 else None
            return org or None, project or None
    except Exception:
        pass
    return None, None


def _prompt_optional_params(name: str, params: set[str]) -> dict[str, str]:
    """Prompt user for optional server params.

    *params*: set of parameter names (from ``extract_params``).
    Enter = confirm default / skip if no default.
    Ctrl+C / ESC = skip all params (no config).

    Returns dict of param→value for params the user provided.
    """
    from workpilot.cli.init import _is_tty

    if not _is_tty():
        return {}

    defaults: dict[str, str] = {}

    # Auto-detect ADO org/project from git remote
    if name in ("ado", "bluebird"):
        detected_org, detected_project = _detect_ado_remote()
        if detected_org:
            defaults["organization"] = detected_org
        if detected_project:
            defaults["project"] = detected_project
        detected = {
            k: v for k, v in [("organization", detected_org), ("project", detected_project)] if v
        }
        if detected:
            console.print(f"    [dim]Detected from git remote: {detected}[/dim]")

    console.print("    [dim]Esc skip param, Ctrl+C skip all[/dim]")
    resolved: dict[str, str] = {}
    try:
        from prompt_toolkit import prompt as pt_prompt
        from prompt_toolkit.key_binding import KeyBindings
        from prompt_toolkit.keys import Keys

        _ESC_SENTINEL = "\x1b__skip__"
        bindings = KeyBindings()

        @bindings.add(Keys.Escape)
        def _esc(event: object) -> None:
            buf = getattr(event, "app", None)
            if buf:
                buf.current_buffer.text = _ESC_SENTINEL
                buf.current_buffer.validate_and_handle()

        for param in sorted(params):
            default = defaults.get(param, "")
            label = f"    {param}: "
            val = pt_prompt(label, default=default, key_bindings=bindings).strip()
            if val == _ESC_SENTINEL:
                continue  # Esc → skip this param
            if val:
                resolved[param] = val
            # cleared → skip, leave for runtime
    except (KeyboardInterrupt, EOFError):
        console.print("\n    [dim]skipped[/dim]")
        return {}
    except Exception:
        # prompt_toolkit unavailable or terminal incompatible — skip prompting
        return {}

    return resolved


def _resolve_server_args(name: str) -> list[str]:
    """Prompt user for required server args, using defaults where available."""
    from workpilot.mcp.defaults import SERVER_REGISTRY

    entry = SERVER_REGISTRY.get(name)
    if not entry or not entry.params:
        return []
    defaults: dict[str, str] = {}
    args: list[str] = []

    # Special handling for ADO: auto-detect org/project from git remote
    if name in ("ado", "bluebird"):
        detected_org, detected_project = _detect_ado_remote()
        if detected_org:
            defaults["organization"] = detected_org
        if detected_project:
            defaults["project"] = detected_project

    for param in sorted(entry.params):
        flag = f"--{param.replace('_', '-')}"
        default = defaults.get(param, "")
        prompt = f"    {flag}"
        if default:
            prompt += f" [{default}]"
        prompt += ": "
        val = console.input(prompt).strip() or default
        if val:
            args.extend([flag, val])
        else:
            return []  # user skipped

    return args


def _test_agency_server(
    agency_bin: str, name: str, extra_args: list[str] | None = None
) -> tuple[bool, str]:
    """Test an Agency MCP server using the same MCPClient used at runtime.

    Timeout: 90s for HTTP proxy servers, 180s for npx/uvx package servers.
    """
    from workpilot.mcp.defaults import PACKAGE_SERVERS

    timeout = 180 if name in PACKAGE_SERVERS else 90
    args = ["mcp", name] + (extra_args or [])
    ok, msg, _tools = _test_mcp_connect(name, command=agency_bin, args=args, timeout=timeout)
    if not ok and "timeout" not in msg:
        # Preserve original error truncation for add-agency display
        if "required arguments" in msg.lower():
            msg = msg.split("\n")[-1].strip()[:80]
        else:
            msg = msg[:80]
    elif not ok:
        msg = f"timeout ({timeout}s) — try: agency mcp {name}"
    return ok, msg


# Curated agency descriptions resolved from workpilot.mcp.defaults (imported at top).


def _run_add_agency(
    config_dir: Path,
    *,
    select_all: bool = False,
    dry_run: bool = False,
    skip_test: bool = False,
    raise_on_failure: bool = True,
) -> dict[str, dict[str, Any]] | None:
    """Core add-agency logic shared by ``init`` and ``mcp add-agency``."""
    # 1. Ensure Agency CLI + discover servers
    agency_bin = _ensure_agency_installed(raise_on_failure=raise_on_failure)
    if agency_bin is None:
        return None
    console.print(f"Using agency: {agency_bin}")

    # Build HTTP-available set from merged config (skip these in agency discovery)
    try:
        _merged = _load_config_safe(str(config_dir))
        existing = set(_merged.tools.mcp_servers.keys())
        http_available = {n for n, srv in _merged.tools.mcp_servers.items() if srv.url}
    except Exception:
        existing = set()
        http_available = set()

    discovered = _discover_agency_servers(agency_bin, http_available)
    if not discovered:
        console.print("[yellow]No MCP servers found.[/yellow]")
        return None

    # 2. Filter already-configured — use existing local file if present
    local_path = next(
        (
            config_dir / c
            for c in ("workpilot.local.yaml", "workpilot.local.yml")
            if (config_dir / c).exists()
        ),
        config_dir / "workpilot.local.yaml",
    )
    local_raw = (_load_yaml(local_path) if local_path.is_file() else {}) or {}
    tools_val = local_raw.get("tools")
    tools_sec: dict[str, Any] = tools_val if isinstance(tools_val, dict) else {}
    local_raw["tools"] = tools_sec
    mcp_val = tools_sec.get("mcp_servers")
    mcp_sec: dict[str, Any] = mcp_val if isinstance(mcp_val, dict) else {}
    tools_sec["mcp_servers"] = mcp_sec

    known = existing | set(mcp_sec.keys())
    if known:
        console.print(
            f"[dim]Already configured: {', '.join(n for n, _ in discovered if n in known)}[/dim]"
        )

    # 3. Select servers — show ALL discovered (including already-installed)
    if select_all:
        # --all adds recommended servers not already configured
        selected = [n for n, _ in discovered if n not in known and _is_recommended(n)]
        if not selected:
            console.print(
                "[dim]No servers to add (all already configured).[/dim]\n"
                "  Use [bold]wp mcp add-agency[/bold] (without --all) to pick interactively."
            )
            return None
    else:
        selected = _interactive_select(discovered, known)

    if not selected:
        console.print("No servers selected.")
        return None
    if dry_run:
        console.print(f"\n[dim]--dry-run: would add {len(selected)}: {', '.join(selected)}[/dim]")
        return None

    # 4. Install each server
    total = len(selected)
    if skip_test:
        console.print(f"\nAdding {total} servers [dim](skipping auth test)...[/dim]\n")
    else:
        console.print(f"\nInstalling {total} servers [dim](verifying auth)...[/dim]\n")

    added: dict[str, dict[str, Any]] = {}
    auth_pending: list[str] = []

    for idx, name in enumerate(selected, 1):
        sys.stdout.write(f"  [{idx}/{total}] {name:20s} ")
        sys.stdout.flush()

        # Resolve extra args
        extra_args = _resolve_extra_args(name, select_all)
        if extra_args is None:
            print("skipped")
            continue

        # Test auth
        if skip_test:
            print("added")
        else:
            from workpilot.mcp.defaults import PACKAGE_SERVERS

            timeout = 180 if name in PACKAGE_SERVERS else 90
            sys.stdout.write(f"testing (up to {timeout}s) ")
            sys.stdout.flush()
            ok, info = _test_agency_server(agency_bin, name, extra_args or None)
            if ok:
                print(f" OK  {info}")
            else:
                print(" added (auth pending)")
                auth_pending.append(name)

        # Write entry — description is NOT persisted; resolved at runtime
        # from workpilot.mcp.defaults when config has no explicit description.
        entry: dict[str, Any] = {"command": "agency", "args": ["mcp", name] + extra_args}
        # Risk scoring is handled by mcp_risk_policy in workpilot.yaml
        # (per-tool scores + _rules). Don't write server-level risk here
        # as it would override the fine-grained policy scores.
        added[name] = entry
        mcp_sec[name] = entry
        _save_mcp_servers(local_path, mcp_sec)

    # Summary
    if added:
        console.print(f"\n[green]Added {len(added)} MCP servers to {local_path}.[/green]")
    if auth_pending:
        console.print("[yellow]Auth pending — run to complete login:[/yellow]")
        for n in auth_pending:
            console.print(f"  agency mcp {n}")

    return added or None


def _server_tag(name: str, servers: dict[str, Any] | None) -> str:
    """Short tag: ``http \u00b7 entra \u00b7 on`` or ``stdio \u00b7 auto``."""
    if not servers or name not in servers:
        return ""
    srv = servers[name]
    kind = "http" if getattr(srv, "url", None) else "stdio"
    auth = _auth_label(srv)
    enabled = getattr(srv, "enabled", True)
    if enabled is False:
        state = "off"
    elif enabled == "auto":
        state = "auto"
    else:
        state = "on"
    parts = [kind]
    if auth != "none":
        parts.append(auth)
    parts.append(state)
    return " \u00b7 ".join(parts)


def _group_servers(
    items: list[tuple[str, str]],
) -> list[tuple[str, list[tuple[str, str]]]]:
    """Organize servers into display groups. Returns (group_label, servers) pairs."""
    from workpilot.mcp.defaults import (
        GROUP_DATA,
        GROUP_ENGINEERING,
        GROUP_OFFICE,
        GROUP_SECURITY,
    )

    groups: dict[str, list[tuple[str, str]]] = {
        "Office": [],
        "Engineering": [],
        "Security": [],
        "Data": [],
        "Custom": [],
    }
    for name, desc in items:
        if name in GROUP_OFFICE:
            groups["Office"].append((name, desc))
        elif name in GROUP_ENGINEERING:
            groups["Engineering"].append((name, desc))
        elif name in GROUP_SECURITY:
            groups["Security"].append((name, desc))
        elif name in GROUP_DATA:
            groups["Data"].append((name, desc))
        else:
            groups["Custom"].append((name, desc))
    return [(label, servers) for label, servers in groups.items() if servers]


def _interactive_select(
    available: list[tuple[str, str]],
    known: set[str] | None = None,
    servers: dict[str, Any] | None = None,
) -> list[str]:
    """Show interactive checkbox for server selection.

    Pre-selects recommended servers based on detected user profile.
    Servers are displayed in groups (Office, Engineering, Security, Data, Custom).
    Uses arrow-key navigation in a real terminal, numbered fallback otherwise.

    Args:
        servers: merged server configs — used to show type/status tags.
    """
    known = known or set()
    items = [(n, d) for n, d in available]
    selected: set[str] = set()
    for n, _ in items:
        # User already configured and enabled → always pre-select.
        srv = servers.get(n) if servers else None
        if srv and getattr(srv, "enabled", None) is True:
            selected.add(n)
            continue
        if n in known:
            continue
        if not _is_recommended(n):
            continue
        selected.add(n)

    from workpilot.cli.init import _is_tty

    if _is_tty():
        try:
            return _multiselect_arrows(items, selected, known, servers)
        except Exception:
            pass
    return _multiselect_numbered(items, selected, known, servers)


def _multiselect_arrows(
    items: list[tuple[str, str]],
    selected: set[str],
    known: set[str],
    servers: dict[str, Any] | None = None,
) -> list[str]:
    """Arrow-key multi-select with space-to-toggle. Returns list of selected names."""
    import sys

    from workpilot.cli.init import _read_key

    max_name = max(len(name) for name, _ in items)

    # Build grouped display: list of (is_header, label, item_index).
    grouped = _group_servers(items)
    item_index = {name: i for i, (name, _) in enumerate(items)}
    display_rows: list[tuple[bool, str, int]] = []  # (is_header, label, item_idx)
    selectable_indices: list[int] = []  # indices into display_rows that are items
    for group_label, group_items in grouped:
        display_rows.append((True, group_label, -1))
        for name, _desc in group_items:
            idx = item_index[name]
            row_idx = len(display_rows)
            display_rows.append((False, name, idx))
            selectable_indices.append(row_idx)

    sel_pos = 0  # index into selectable_indices

    # lines: header + blank + display_rows + blank + hint = len(display_rows) + 4
    total_lines = len(display_rows) + 4

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        count = len(selected)
        out.write(f"\033[2K  \033[1mMCP servers\033[0m \033[90m({count} selected)\033[0m\n")
        out.write("\n")
        cur_row = selectable_indices[sel_pos] if sel_pos < len(selectable_indices) else -1
        for row_i, (is_header, label, item_idx) in enumerate(display_rows):
            if is_header:
                out.write(f"\033[2K  \033[2;90m--- {label} ---\033[0m\n")
            else:
                name, desc = items[item_idx]
                check = "\033[36m\u2713\033[0m" if name in selected else " "
                pad = name.ljust(max_name)
                tag = _server_tag(name, servers)
                tags = f"  \033[90m{tag}\033[0m" if tag else ""
                if name in known:
                    tags += "  \033[90m(installed)\033[0m"
                if row_i == cur_row:
                    line = f"  [{check}] \033[1;36m{pad}\033[0m  \033[1m{desc}\033[0m{tags}"
                else:
                    line = f"  [{check}] {pad}  \033[37m{desc}\033[0m{tags}"
                out.write(f"\033[2K{line}\n")
        out.write("\n")
        out.write(
            "\033[2K  \033[2;90m\u2191\u2193 move  Space toggle"
            "  a all  n none  \u23ce Enter confirm  Esc skip\033[0m\n"
        )
        out.flush()

    n_sel = len(selectable_indices)

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)
        while True:
            key = _read_key()
            if key in ("up", "k"):
                sel_pos = (sel_pos - 1) % n_sel
                _render()
            elif key in ("down", "j"):
                sel_pos = (sel_pos + 1) % n_sel
                _render()
            elif key in (" ", "space"):
                row_idx = selectable_indices[sel_pos]
                item_idx = display_rows[row_idx][2]
                name = items[item_idx][0]
                selected ^= {name}
                _render()
            elif key == "a":
                selected.clear()
                selected.update(name for name, _ in items if name not in known)
                _render()
            elif key == "n":
                selected.clear()
                _render()
            elif key == "enter":
                # Erase the rendered menu
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                result = [name for name, _ in items if name in selected]
                return result
            elif key in ("esc", "\x1b", "q"):
                # Esc or q = skip — caller prints the user-facing message.
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return []
            elif key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < n_sel:
                    sel_pos = idx
                    row_idx = selectable_indices[sel_pos]
                    item_idx = display_rows[row_idx][2]
                    selected ^= {items[item_idx][0]}
                    _render()
    finally:
        sys.stdout.write("\033[?25h\033[0m")
        sys.stdout.flush()


def _multiselect_numbered(
    items: list[tuple[str, str]],
    selected: set[str],
    known: set[str],
    servers: dict[str, Any] | None = None,
) -> list[str]:
    """Numbered checkbox fallback for non-TTY. Returns list of selected names."""
    console.print(f"\nAvailable MCP servers ({len(items)}):")
    console.print(
        "[dim]Enter numbers to toggle, 'a' for all new, 'n' for none, Enter to confirm.[/dim]"
    )
    if known:
        console.print("[dim]To remove an installed server:  wp mcp remove <name>[/dim]\n")
    else:
        console.print()

    while True:
        for i, (n, d) in enumerate(items, 1):
            mark = "[cyan]\u2713[/cyan]" if n in selected else " "
            tag = _server_tag(n, servers)
            type_tag = f" [dim]{tag}[/dim]" if tag else ""
            installed_tag = " [dim](installed)[/dim]" if n in known else ""
            console.print(f"  [{mark}] {i:2d}. {n:20s} [bold]{d}[/bold]{type_tag}{installed_tag}")

        choice = (
            console.input(
                f"\n[bold]Toggle ([cyan]1-{len(items)}[/cyan],"
                f" [cyan]a[/cyan]ll, [cyan]n[/cyan]one) or Enter:[/bold] "
            )
            .strip()
            .lower()
        )

        if not choice:
            break
        elif choice == "a":
            selected.clear()
            selected.update(n for n, _ in items if n not in known)
        elif choice == "n":
            selected.clear()
        else:
            for p in choice.replace(",", " ").split():
                try:
                    idx = int(p) - 1
                    if 0 <= idx < len(items):
                        selected ^= {items[idx][0]}
                except ValueError:
                    pass
        console.print()

    return [n for n, _ in items if n in selected]


def _resolve_extra_args(name: str, use_defaults: bool) -> list[str] | None:
    """Resolve extra CLI args for Agency servers that need them.

    Returns [] for no-param servers, list of args, or None if user skips.
    HTTP servers with params always return [] in auto mode (params are
    optional — resolved at runtime by LLM).
    """
    from workpilot.mcp.defaults import SERVER_REGISTRY

    entry = SERVER_REGISTRY.get(name)
    if not entry or not entry.params:
        return []

    if use_defaults:
        # No defaults → skip in auto mode (agency can't resolve {var})
        return None

    print("configuring...")
    return _resolve_server_args(name) or None


def _bulk_login(cfg: Any) -> None:
    """Login to all auth providers needed by configured servers."""
    from workpilot.mcp.auth import _is_github_url, _resolve_github_token, has_msal_account
    from workpilot.mcp.defaults import GH_CLI_CLIENT_ID, GH_MCP_SCOPE, SHARED_ENTRA_CLIENT_ID

    needs_github = any(
        _is_github_url(srv.url) and srv.enabled is not False
        for srv in cfg.tools.mcp_servers.values()
    )
    needs_entra = any(
        srv.auth.client_id == SHARED_ENTRA_CLIENT_ID and srv.enabled is not False
        for srv in cfg.tools.mcp_servers.values()
    )

    if not needs_github and not needs_entra:
        console.print("[dim]No servers require login.[/dim]")
        return

    if needs_github:
        if _resolve_github_token():
            console.print("[green]\u2713[/green] [bold]GitHub[/bold]  token already cached")
        else:
            console.print(
                "[yellow]\u25cb[/yellow] [bold]GitHub[/bold]  "
                "no token \u2014 device code login required"
            )
            try:
                input("  Press Enter to continue (Ctrl+C to skip) ")
                from workpilot.security.github_auth import github_device_login

                token = github_device_login(
                    client_id=GH_CLI_CLIENT_ID, scope=GH_MCP_SCOPE, console=console
                )
                try:
                    from workpilot.security.secrets import get_secret_store

                    get_secret_store().set("GITHUB_TOKEN", token)
                    console.print("[green]\u2713[/green] [bold]GitHub[/bold]  token saved")
                except Exception:
                    pass
            except (EOFError, KeyboardInterrupt):
                console.print("\n  [dim]skipped[/dim]")
            except Exception as exc:
                console.print(f"[red]\u2717[/red] [bold]GitHub[/bold]  {exc}")

    if needs_entra:
        if has_msal_account(SHARED_ENTRA_CLIENT_ID):
            console.print("[green]\u2713[/green] [bold]Entra[/bold]   session already cached")
        else:
            first_scope: list[str] = ["openid"]
            for srv in cfg.tools.mcp_servers.values():
                if srv.auth.client_id == SHARED_ENTRA_CLIENT_ID and srv.auth.scopes:
                    first_scope = srv.auth.scopes
                    break
            console.print(
                "[yellow]\u25cb[/yellow] [bold]Entra[/bold]   "
                "login required \u2014 a browser window will open"
            )
            try:
                input("  Press Enter to continue (Ctrl+C to skip) ")
                from workpilot.utils.auth import acquire_entra_token

                entra_token = acquire_entra_token(
                    tenant_id="organizations",
                    client_id=SHARED_ENTRA_CLIENT_ID,
                    scopes=first_scope,
                )
                if entra_token:
                    console.print("[green]\u2713[/green] [bold]Entra[/bold]   authenticated")
                else:
                    console.print("[red]\u2717[/red] [bold]Entra[/bold]   login failed")
            except (EOFError, KeyboardInterrupt):
                console.print("\n  [dim]skipped[/dim]")
            except Exception as exc:
                console.print(f"[red]\u2717[/red] [bold]Entra[/bold]   {exc}")


@mcp_app.command("login")
def mcp_login(
    name: str | None = typer.Argument(None, help="MCP server name (omit for bulk login)"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Authenticate with MCP servers.

    Without a name: bulk login to all auth providers (Entra + GitHub).
    With a name: login to a specific server.
    """
    import asyncio as _asyncio

    cfg = _load_config_safe(config)

    if name is None:
        _bulk_login(cfg)
        return

    srv = cfg.tools.mcp_servers.get(name)
    if srv is None:
        console.print(f"[red]MCP server '{name}' not found in config.[/red]")
        raise typer.Exit(1)
    if not srv.url:
        console.print(
            f"[red]MCP server '{name}' uses stdio \u2014 OAuth login is not applicable.[/red]"
        )
        raise typer.Exit(1)

    async def _login() -> None:
        auth = srv.auth
        # MSAL path — Entra servers with client_id + scopes
        if auth.client_id and auth.scopes:
            from workpilot.utils.auth import acquire_entra_token

            token = acquire_entra_token(
                tenant_id="organizations",
                client_id=auth.client_id,
                scopes=auth.scopes,
            )
            if token:
                console.print(f"[green]Authenticated with '{name}'.[/green] Token cached via MSAL.")
            else:
                console.print(f"[red]MSAL login failed for '{name}'.[/red]")
            return

        # Discover Entra auth from resource metadata (probe → 401 → metadata)
        import asyncio as _aio

        from workpilot.mcp.auth import discover_entra_auth

        entra_info = await _aio.to_thread(discover_entra_auth, srv.url, srv.headers)  # type: ignore[arg-type]  # checked above
        if entra_info:
            client_id, scopes, tenant_id = entra_info
            from workpilot.utils.auth import acquire_entra_token

            token = acquire_entra_token(
                tenant_id=tenant_id,
                client_id=client_id,
                scopes=scopes,
            )
            if token:
                console.print(f"[green]Authenticated with '{name}'.[/green] Token cached via MSAL.")
            else:
                console.print(f"[red]MSAL login failed for '{name}'.[/red]")
            return

        # SDK OAuth path — generic non-Entra OAuth servers
        import httpx

        from workpilot.mcp.oauth_provider import create_oauth_auth

        provider = await create_oauth_auth(name, srv, cfg.providers)
        if provider is None:
            console.print(
                f"[yellow]MCP server '{name}' uses static bearer auth. "
                "No OAuth login needed.[/yellow]"
            )
            return

        srv_headers = {k: v for k, v in (srv.headers or {}).items() if k.lower() != "authorization"}
        probe_payload = {
            "jsonrpc": "2.0",
            "id": "mcp-login-probe",
            "method": "initialize",
            "params": {"capabilities": {}},
        }
        async with httpx.AsyncClient(auth=provider, headers=srv_headers, timeout=60.0) as client:
            resp = await client.post(srv.url, json=probe_payload)  # type: ignore[arg-type]
            from workpilot.mcp.oauth_storage import MCPTokenStorage

            has_token = await MCPTokenStorage(name).get_tokens() is not None
            if has_token:
                console.print(f"[green]Authenticated with '{name}'.[/green] Token stored.")
            elif resp.status_code < 400:
                console.print(
                    f"[dim]Server returned {resp.status_code} without requiring auth. "
                    "No OAuth token needed.[/dim]"
                )
            else:
                console.print(
                    f"[yellow]Server returned {resp.status_code}. "
                    "Authentication may have failed — try 'mcp test'.[/yellow]"
                )

    try:
        _asyncio.run(_login())
    except Exception as exc:
        console.print(f"[red]OAuth login failed: {exc}[/red]")
        raise typer.Exit(1)


@mcp_app.command("logout")
def mcp_logout(
    name: str | None = typer.Argument(None, help="MCP server name (omit for all)"),
) -> None:
    """Remove stored OAuth tokens for MCP servers.

    Without a name: clear all cached MCP tokens.
    With a name: clear tokens for a specific server.
    """
    from workpilot.mcp.oauth_storage import MCPTokenStorage

    if name is not None:
        MCPTokenStorage(name).clear()
        console.print(f"[green]Removed OAuth tokens for '{name}'.[/green]")
        return

    # Clear all — MSAL cache + per-server token stores
    count = 0
    try:
        from workpilot.utils.helpers import get_auth_dir

        for cache_file in get_auth_dir().glob("token_cache_*.bin"):
            cache_file.unlink(missing_ok=True)
            count += 1
    except Exception:
        pass
    try:
        from workpilot.security.secrets import get_secret_store

        store = get_secret_store()
        if store.get("GITHUB_TOKEN"):
            store.delete("GITHUB_TOKEN")
            count += 1
    except Exception:
        pass
    console.print(f"[green]Cleared {count} cached token(s).[/green]")


# ── Unified MCP setup ───────────────────────────────────────────────────────


# Map: uvx package → (pip package, python module) for fallback
_UVX_FALLBACKS: dict[str, str] = {
    "microsoft-fabric-rti-mcp": "fabric_rti_mcp.server",
}


def _resolve_stdio_command(entry: Any) -> tuple[str, list[str]]:
    """Resolve the actual command + args for a stdio server.

    If the command is ``uvx`` and it's available, use it directly.
    Otherwise, fall back to ``python -m <module>`` after pip-installing
    the package if needed.
    """
    if entry.command != "uvx" or shutil.which("uvx"):
        return entry.command, list(entry.command_args)

    # uvx not available — fall back to pip install + python -m
    pkg_name = entry.command_args[0] if entry.command_args else ""
    module = _UVX_FALLBACKS.get(pkg_name)
    if not module:
        console.print("  [yellow]uvx not found. Install: pip install uv[/yellow]")
        return entry.command, list(entry.command_args)

    # Check if the package is already importable
    try:
        __import__(module.split(".")[0])
    except ImportError:
        console.print(f"  [dim]Installing {pkg_name}...[/dim]")
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg_name, "-q"],
                check=True,
                capture_output=True,
                timeout=120,
            )
        except subprocess.CalledProcessError:
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", pkg_name, "-q", "--user"],
                    check=True,
                    capture_output=True,
                    timeout=120,
                )
            except subprocess.CalledProcessError:
                console.print(f"  [yellow]Failed to install {pkg_name}[/yellow]")
                console.print(f"  [dim]Install manually: pip install {pkg_name}[/dim]")
                return entry.command, list(entry.command_args)
        console.print(f"  [green]\u2713[/green] {pkg_name} installed")

    return sys.executable, ["-m", module]


def _mcp_setup(
    config_dir: Path,
    local_config: dict | None = None,
    *,
    select_all: bool = False,
    quick: bool = False,
    skip_test: bool = False,
    step: int | None = None,
) -> dict[str, Any]:
    """Unified MCP server setup: select \u2192 authenticate \u2192 write config \u2192 verify.

    Called by ``wp mcp setup`` (standalone) and ``wp init`` step [5/5].

    When *local_config* is provided (init path), modifies it in-place.
    When ``None`` (standalone), reads/writes workpilot.local.yaml directly.
    Returns dict of added servers (for summary).
    """

    from workpilot.mcp.defaults import SERVER_REGISTRY

    # Determine config target
    standalone = local_config is None
    if standalone:
        local_path = next(
            (
                config_dir / c
                for c in ("workpilot.local.yaml", "workpilot.local.yml")
                if (config_dir / c).exists()
            ),
            config_dir / "workpilot.local.yaml",
        )
        local_config = (_load_yaml(local_path) if local_path.is_file() else {}) or {}

    assert local_config is not None  # always assigned above
    mcp_section = local_config.setdefault("tools", {}).setdefault("mcp_servers", {})
    # Sub-step prefix: e.g. "5." when called from init step 5.
    _p = f"{step}." if step else ""

    # ── Build server list from merged yaml config ────────────────────
    try:
        merged_cfg = _load_config_safe(str(config_dir))
        merged_servers = merged_cfg.tools.mcp_servers
    except Exception:
        merged_servers = {}

    all_servers: list[tuple[str, str]] = []
    for name, srv in merged_servers.items():
        desc = srv.description or ""
        if not desc:
            reg = SERVER_REGISTRY.get(name)
            if reg:
                desc = reg.description
        all_servers.append((name, desc))
    # Append registry-only servers (e.g. kusto — stdio, not in yaml)
    # Skip legacy/not-recommended entries (workiq, enghub).
    yaml_names = set(merged_servers)
    for name, entry in SERVER_REGISTRY.items():
        if name not in yaml_names and entry.recommended:
            all_servers.append((name, entry.description))

    # ── Select & write config ───────────────────────────────────────
    if not quick:
        console.print(f"  [dim]({_p}1) Select servers[/dim]")
    if select_all:
        selected = [n for n, _ in all_servers if _is_recommended(n)]
    else:
        selected = _interactive_select(all_servers, servers=merged_servers)

    if not selected:
        console.print(
            "  [dim]Skipped \u2014 add servers later with [bold]wp mcp setup[/bold].[/dim]"
        )
        return {}
    added: dict[str, Any] = {}
    all_http_names = {n for n, srv in merged_servers.items() if srv.url}

    for name in selected:
        if name == "github":
            added[name] = {}
        else:
            reg_entry = SERVER_REGISTRY.get(name)
            merged_srv = merged_servers.get(name)
            if reg_entry and reg_entry.command:
                # Stdio server (e.g. kusto via uvx) — merge into existing
                # to preserve user-modified env values.
                existing = mcp_section.get(name, {})
                if not isinstance(existing, dict):
                    existing = {}
                cmd, cmd_args = _resolve_stdio_command(reg_entry)
                existing["enabled"] = True
                existing["command"] = cmd
                existing["args"] = cmd_args
                if reg_entry.env:
                    env = existing.get("env")
                    if not isinstance(env, dict):
                        env = {}
                        existing["env"] = env
                    env.update({k: v for k, v in reg_entry.env.items() if k not in env})
                mcp_section[name] = existing
            elif merged_srv and merged_srv.url:
                # HTTP server — merge into existing local entry to preserve
                # user-added fields (url, headers, env, etc.).
                existing = mcp_section.get(name, {})
                if not isinstance(existing, dict):
                    existing = {}
                existing["enabled"] = True
                # Promote implicit → oauth now that the user has set up auth.
                if merged_srv.auth.type == "implicit" and merged_srv.auth.client_id:
                    existing.setdefault("auth", {})["type"] = "oauth"
                mcp_section[name] = existing
            added[name] = mcp_section.get(name, {})

    # Unselected HTTP servers → disabled
    for name in all_http_names - set(selected):
        mcp_section.setdefault(name, {})["enabled"] = False

    # Save (standalone mode)
    if standalone:
        _save_mcp_servers(local_path, mcp_section)  # type: ignore[possibly-undefined]

    console.print(
        f"  [green]\u2713[/green] [bold]{len(selected)}[/bold] servers configured: "
        f"[cyan]{', '.join(selected)}[/cyan]"
    )

    # ── Authenticate + Verify (grouped, interleaved) ─────────────────
    if not quick and not skip_test and selected:
        console.print(f"  [dim]({_p}2) Authenticate MCP servers & verify tools[/dim]")
        from workpilot.cli.mcp_setup import auth_and_verify

        selected = auth_and_verify(
            selected,
            merged_servers,
            config_dir,
            quick=quick,
        )

        # Sync config: disable servers that were skipped during auth.
        selected_set = set(selected)
        for name in all_http_names - selected_set:
            mcp_section.setdefault(name, {})["enabled"] = False
        if standalone:
            _save_mcp_servers(local_path, mcp_section)  # type: ignore[possibly-undefined]

    if not selected:
        console.print(
            "  [dim]No servers authenticated \u2014 "
            "retry later with [bold]wp mcp setup[/bold].[/dim]"
        )

    selected_set = set(selected)
    return {name: srv for name, srv in added.items() if name in selected_set}


@mcp_app.command("setup")
def mcp_setup_cmd(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    all_servers: bool = typer.Option(False, "--all", help="Select all recommended servers"),
    skip_test: bool = typer.Option(False, "--skip-test", help="Skip connectivity verification"),
) -> None:
    """Interactive MCP server setup: select, authenticate, verify.

    Unified entry point for configuring GitHub, Entra, and Agency MCP servers.
    """
    console.print("\n[bold]MCP Server Setup[/bold]")
    console.print("[dim]Select servers, authenticate, and verify connectivity.[/dim]\n")
    config_path = _resolve_config_path(config)
    _mcp_setup(
        config_dir=config_path.parent,
        select_all=all_servers,
        skip_test=skip_test,
    )
    console.print()


@mcp_app.command("add-agency")
def mcp_add_agency(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    all_servers: bool = typer.Option(
        False, "--all", help="Add all discovered servers without prompting"
    ),
    skip_test: bool = typer.Option(
        False, "--skip-test", help="Skip auth testing (add without verifying)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be added without writing"
    ),
) -> None:
    """Add Agency CLI stdio servers (requires Agency CLI installed).

    Only shows servers not already available via HTTP. Most servers
    are now built-in with direct HTTP support — use 'wp mcp setup' instead.
    """
    config_path = _resolve_config_path(config)
    result = _run_add_agency(
        config_dir=config_path.parent,
        select_all=all_servers,
        skip_test=skip_test,
        dry_run=dry_run,
    )
    if result is None and not dry_run:
        raise typer.Exit(0)
