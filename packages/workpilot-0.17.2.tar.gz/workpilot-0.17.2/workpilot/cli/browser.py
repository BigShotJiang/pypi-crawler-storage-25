"""Browser CLI subcommands — workpilot browser status|open|clear|path.

Manages the *workpilot* persistent browser profile at
``~/.workpilot/browser-profile/<browser>``. The *system* profile
(user's real browser user-data-dir) is intentionally not exposed
here — it is approval-gated at tool-call time and forbidden under
controlled/restricted security profiles.
"""

from __future__ import annotations

import asyncio
import shutil
import sys
from pathlib import Path
from typing import Any

import typer

from workpilot.cli.commands import (
    _load_config_safe,
    browser_app,
    console,
)
from workpilot.utils.helpers import get_data_dir


def _workpilot_profile_dir(browser: str) -> Path:
    """Primary WorkPilot profile dir for *browser*.

    Matches ``BrowserTool._resolve_profile_dir`` initial behaviour: the dir
    follows the configured OS binary (browser=msedge → .../msedge). The
    agent may later reroute to bundled Chromium if the OS binary launch
    fails (that state lives under .../chromium), and ``cdp_attach`` uses
    a distinct ``.../<browser>-cdp`` dir. See ``_workpilot_profile_dirs_all``
    for enumerating every variant that may hold state.
    """
    return get_data_dir() / "browser-profile" / browser


def _workpilot_profile_dirs_all(browser: str) -> list[Path]:
    """Every WorkPilot profile dir that may hold state for *browser*.

    Candidate dirs depend on the configured browser family:
    - ``<browser>/`` — always included as the primary managed profile dir
    - ``chromium/`` — managed-launch fallback, only for Chromium-family
      OS binaries (msedge / chrome) where _effective_engine_name can
      reroute to bundled Chromium after an OS-binary failure
    - ``<browser>-cdp/`` — cdp_attach dir, only for Chromium-family
      engines (cdp_attach is rejected for Firefox, which speaks BiDi
      and not CDP)
    - ``chromium-cdp/`` — cdp_attach fallback, same Chromium-family
      restriction

    Firefox never falls back to Chromium and cdp_attach is unsupported,
    so `workpilot browser clear` / `status` must not touch Chromium dirs
    when the user has `browser=firefox` — they could belong to another
    tool or an older config.

    Only dirs that actually exist on disk are returned.
    """
    root = get_data_dir() / "browser-profile"
    candidates: set[str] = {browser}
    if browser in ("msedge", "chrome"):
        # Managed-launch fallback + cdp_attach with the OS binary +
        # cdp_attach fallback to bundled Chromium.
        candidates.update({"chromium", f"{browser}-cdp", "chromium-cdp"})
    elif browser == "chromium":
        # chromium itself — only the cdp_attach variant applies; the
        # bundled-Chromium "fallback" is the primary dir already.
        candidates.add("chromium-cdp")
    # firefox → just the firefox dir; no Chromium fallback, no CDP.
    return [root / c for c in sorted(candidates) if (root / c).exists()]


def _dir_size_bytes(path: Path) -> int:
    total = 0
    for entry in path.rglob("*"):
        try:
            if entry.is_file():
                total += entry.stat().st_size
        except OSError:
            continue
    return total


def _human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


@browser_app.command("status")
def browser_status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show the current browser profile configuration and disk usage."""
    cfg = _load_config_safe(config)
    browser_cfg = cfg.tools.browser
    sec_profile = cfg.security.profile.value

    # Resolve `auto` so the user sees what will actually run.
    if browser_cfg.profile_mode == "auto":
        resolved_mode = "ephemeral" if sec_profile in ("controlled", "restricted") else "workpilot"
        mode_display = f"auto → {resolved_mode}"
    else:
        resolved_mode = browser_cfg.profile_mode
        mode_display = browser_cfg.profile_mode

    console.print(f"[bold]Browser:[/bold] {browser_cfg.browser}")
    console.print(f"[bold]Profile mode:[/bold] {mode_display}")
    console.print(f"[bold]Headless:[/bold] {browser_cfg.headless}")
    console.print(f"[bold]Security profile:[/bold] {sec_profile}")

    # Print the *effective* profile directory — the one the agent will
    # actually open — so users don't get misled into thinking the
    # WorkPilot dir is in play when a persistent_profile override or a
    # system/ephemeral mode is set. Enumeration of the WorkPilot dirs
    # (including fallback/cdp variants) is still surfaced as supplemental
    # state at the end, because they may hold leftover cookies from a
    # previous run even when the current config points elsewhere.
    if browser_cfg.persistent_profile:
        effective_dir = Path(browser_cfg.persistent_profile).expanduser()
        effective_label = "Effective profile (persistent_profile override)"
    elif resolved_mode == "ephemeral":
        effective_dir = None
        effective_label = "Effective profile"
    elif resolved_mode == "system":
        # Lazy import to avoid pulling BrowserTool into the CLI-only path
        # unless the user actually asked about a system profile.
        from workpilot.agent.tools.browser import _system_profile_dir

        effective_dir = _system_profile_dir(browser_cfg.browser)
        effective_label = "Effective profile (system)"
        if effective_dir is None:
            # System mode was requested but we have no known OS user-data-dir
            # for this browser on this platform (e.g. browser=firefox — the
            # in-tool defaults only cover msedge/chrome on Windows/macOS/
            # Linux). Surface this clearly instead of falling through to
            # the "ephemeral" branch, which would be a lie — the config is
            # system mode, it's just unsupported on this browser/platform.
            console.print(
                f"[bold]{effective_label}:[/bold] [red]unknown — no OS user-data-dir known "
                f"for browser={browser_cfg.browser!r} on platform={sys.platform!r}. "
                "Set tools.browser.persistent_profile to an explicit path.[/red]"
            )
            # Jump past the generic rendering block below.
            effective_dir = None
            effective_label = None
    else:  # workpilot
        effective_dir = _workpilot_profile_dir(browser_cfg.browser)
        effective_label = "Effective profile (workpilot)"

    if effective_dir is None and effective_label is not None:
        # `effective_label is None` means a prior branch already printed
        # a specific error (e.g. system mode unsupported for this browser)
        # and we should not follow up with a generic ephemeral line.
        console.print(f"[bold]{effective_label}:[/bold] [dim]<ephemeral — no persistent dir>[/dim]")
    elif effective_dir is not None and effective_dir.is_dir():
        size = _dir_size_bytes(effective_dir)
        console.print(f"[bold]{effective_label}:[/bold] {effective_dir} ({_human_size(size)})")
    elif effective_dir is not None and effective_dir.exists():
        # Path exists but isn't a directory — typically a misconfigured
        # `persistent_profile` pointing at a regular file or broken
        # symlink. `_dir_size_bytes` would raise NotADirectoryError on
        # that path and crash the status command; surface a clear
        # message instead so the user can fix the config.
        console.print(
            f"[bold]{effective_label}:[/bold] {effective_dir} "
            "[red](exists but is not a directory — check persistent_profile)[/red]"
        )
    elif effective_dir is not None:
        console.print(
            f"[bold]{effective_label}:[/bold] {effective_dir} [dim](not created yet)[/dim]"
        )

    # Always list the WorkPilot dirs as supplemental state (leftover
    # cookies from a previous config, fallback variants, cdp_attach
    # variants) — but only when they actually exist on disk.
    workpilot_dirs = _workpilot_profile_dirs_all(browser_cfg.browser)
    extras = [d for d in workpilot_dirs if d != effective_dir]
    if extras:
        console.print("[bold]Other WorkPilot profile dirs on disk:[/bold]")
        for extra in extras:
            size = _dir_size_bytes(extra)
            console.print(f"  [dim]{extra} ({_human_size(size)})[/dim]")

    rec_dir = (
        Path(browser_cfg.recording_dir).expanduser()
        if browser_cfg.recording_dir
        else (get_data_dir() / "browser-recordings")
    )
    if not rec_dir.exists():
        console.print(f"[bold]Recordings:[/bold] {rec_dir} [dim](empty)[/dim]")
    elif rec_dir.is_dir():
        rec_size = _dir_size_bytes(rec_dir)
        console.print(f"[bold]Recordings:[/bold] {rec_dir} ({_human_size(rec_size)})")
    else:
        # Misconfigured: a file or broken symlink. Don't crash Path.rglob.
        console.print(
            f"[bold]Recordings:[/bold] {rec_dir} [red](not a directory — fix recording_dir config)[/red]"
        )

    if sec_profile in ("controlled", "restricted"):
        console.print(
            "[dim]Note: 'system' profile mode is disabled under this security profile.[/dim]"
        )


@browser_app.command("path")
def browser_path(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Print the absolute path to the WorkPilot profile directory."""
    cfg = _load_config_safe(config)
    console.print(str(_workpilot_profile_dir(cfg.tools.browser.browser)))


@browser_app.command("clear")
def browser_clear(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete the WorkPilot profile directory (cookies, logins, cache).

    Wipes all dir variants the agent may use for this browser config:
    ``<browser>/``, ``chromium/`` (managed-launch fallback), and the
    ``-cdp`` variants for cdp_attach.
    """
    cfg = _load_config_safe(config)
    browser = cfg.tools.browser.browser
    dirs = _workpilot_profile_dirs_all(browser)

    if not dirs:
        console.print(
            f"[dim]Nothing to clear — no WorkPilot profile dirs exist for {browser!r}.[/dim]"
        )
        return

    if not yes:
        dir_list = "\n  ".join(str(d) for d in dirs)
        confirmed = typer.confirm(
            f"Delete the following and all cached logins? This cannot be undone.\n  {dir_list}\n"
        )
        if not confirmed:
            raise typer.Abort()

    for wp_dir in dirs:
        try:
            shutil.rmtree(wp_dir)
        except OSError as exc:
            console.print(f"[red]Failed to remove {wp_dir}: {exc}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]Cleared {wp_dir}[/green]")


@browser_app.command("open")
def browser_open(
    url: str = typer.Option("about:blank", "--url", "-u", help="URL to open"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Launch a headed browser with the WorkPilot profile for manual login setup.

    Use this to sign in to sites interactively; cookies persist for the agent.
    The browser stays open until the user closes the window.
    """
    cfg = _load_config_safe(config)
    browser_cfg = cfg.tools.browser

    try:
        from playwright.async_api import async_playwright
    except ImportError:
        console.print(
            "[red]Playwright is not installed. "
            "Install with: pip install playwright && playwright install[/red]"
        )
        raise typer.Exit(1)

    profile_dir = _workpilot_profile_dir(browser_cfg.browser)
    profile_dir.mkdir(parents=True, exist_ok=True)

    async def _run() -> None:
        pw = await async_playwright().start()
        try:
            launch_kwargs: dict[str, Any] = {"headless": False}
            # Match BrowserTool's initial behaviour: use the configured OS
            # channel so the CLI and agent share the same binary against
            # the same profile dir. If the OS binary is broken on this
            # machine (corporate MDM policy on Edge, etc.), the launch
            # below will fail loudly with a clear error — the user can
            # then set browser=chromium or fix the machine.
            if browser_cfg.browser == "firefox":
                engine = pw.firefox
            elif browser_cfg.browser == "msedge":
                launch_kwargs["channel"] = "msedge"
                engine = pw.chromium
            elif browser_cfg.browser == "chrome":
                launch_kwargs["channel"] = "chrome"
                engine = pw.chromium
            else:
                engine = pw.chromium

            try:
                context = await engine.launch_persistent_context(str(profile_dir), **launch_kwargs)
            except Exception as exc:
                msg = str(exc).lower()
                if "already in use" in msg or "singletonlock" in msg:
                    console.print(
                        f"[red]Profile at {profile_dir} is already in use. "
                        "Close any running browser session and retry.[/red]"
                    )
                    raise typer.Exit(2)
                raise

            # Register the close handler IMMEDIATELY after the context
            # exists — before any navigation or console output — so there's
            # no window where a user could close the browser and leave the
            # CLI hung on `closed.wait()`.
            closed = asyncio.Event()
            # Playwright's BrowserContext "close" event signature varies
            # across versions (no-arg vs one-arg with the context). Accept
            # either with `*args` to avoid a TypeError leaving the CLI
            # hung on `closed.wait()`.
            context.on("close", lambda *_args: closed.set())

            page = context.pages[0] if context.pages else await context.new_page()
            if url and url != "about:blank":
                try:
                    await page.goto(url)
                except Exception as exc:
                    console.print(f"[yellow]Could not navigate to {url}: {exc}[/yellow]")

            console.print(f"[green]Browser opened with WorkPilot profile at {profile_dir}.[/green]")
            console.print("[dim]Close the browser window when you're done.[/dim]")
            await closed.wait()
        finally:
            await pw.stop()

    asyncio.run(_run())
