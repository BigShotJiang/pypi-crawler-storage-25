"""
Shared delivery helper for delegate tools (github_copilot, claude_code, ...).

Delegate tools submit work to an external agent (Copilot CLI, Claude
Agent SDK, etc.) and run it on an ``asyncio.Task`` so the main agent
loop's turn can return immediately with a task id. When the background
task completes the tool routes the raw result back to the user's channel
via ``publish_outbound``.

The ``AgentLoop._capture_for_persist`` bus handler — registered in
Runtime — recognises ``metadata.source == "delegate"``, wraps the
content with a ``[Notification delivered to user at <ts> via <origin>]``
inline framing prefix, and persists the entry as ``role: "system"``
into ``metadata.session_id`` so a browser refresh preserves it.
(No ``[UNTRUSTED_CONTENT]`` envelope — that earlier design was dropped
in favour of uniform role=system framing; trust-level wrapping stays
at the tool-result layer where it belongs.)

This helper owns:

* the disconnected-channel short-circuit (don't publish into a dead
  channel),
* the ``OutboundMessage.metadata`` contract expected by the capture
  handler.

Each delegate tool is still responsible for its own content formatting
(redaction, truncation, success/failure framing) before calling this
helper.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from loguru import logger

from workpilot.bus.events import OutboundMessage
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import ChannelType

if TYPE_CHECKING:
    from workpilot.channels.manager import ChannelManager


@dataclass(frozen=True)
class NotifyTarget:
    """Routing metadata captured at tool-submit time.

    ``session_id`` comes from ``ToolRegistry.execute`` via the injected
    kwarg ``_session_id`` and is propagated on every delegate OutboundMessage
    so ``AgentLoop._capture_for_persist`` can persist the completion into
    the originating user session.
    """

    channel: ChannelType
    channel_id: str
    thread_id: str | None = None
    session_id: str = ""


async def deliver_background_completion(
    bus: MessageBus,
    *,
    target: NotifyTarget,
    content: str,
    task_id: str,
    origin_tool: str,
    channel_manager: ChannelManager | None = None,
    log_prefix: str | None = None,
) -> None:
    """Route a background task completion to the user's channel.

    The caller owns content formatting (redaction, truncation, success /
    failure framing). This helper:

    1. Skips delivery when ``channel_manager`` knows the target channel
       is disconnected AND cannot buffer (CLI/Web); Cloud is exempt
       because its ``send()`` enqueues on a buffered ``_send_queue`` and
       the gateway holds a proactive ``conv_ref``.
    2. Publishes an ``OutboundMessage`` with
       ``metadata.source == "delegate"`` + ``session_id`` so the
       :class:`AgentLoop` outbound-capture handler persists the result
       into the originating session as a ``role: "system"`` entry with
       the standard ``[Notification delivered to user at <ts> via
       <origin>]`` inline framing (no ``[UNTRUSTED_CONTENT]`` wrap —
       trust-level guards live at the tool-result layer).

    Exceptions are logged and swallowed — a failure to notify must not
    crash the already-detached background task.
    """
    prefix = f"{log_prefix} [{task_id}]:" if log_prefix else f"[{task_id}]:"

    # All work — precheck + publish — lives inside the single try/except so
    # a misbehaving channel implementation (is_connected raising during
    # teardown, channel_manager.get hitting a race, etc.) can't escape as
    # an unhandled exception on the detached background asyncio.Task.
    try:
        # Channel-disconnected precheck: skip publish only when there's
        # BOTH no live receiver AND no session to recover via persistence.
        #
        # Background: CLI exits when the REPL closes; Web's push queue is
        # empty during a browser refresh. Historically both cases meant
        # "nowhere to deliver", so we skipped. But now the AgentLoop's
        # outbound-capture handler persists into the session JSONL on
        # ``publish_outbound`` regardless of whether the channel can
        # deliver — so when ``target.session_id`` is present, we MUST
        # still publish so the handler gets the completion even during a
        # transient disconnect (e.g. browser refresh race window — the
        # exact scenario session persistence is designed to fix).
        #
        # Cloud is exempt from the precheck entirely — CloudChannel.send()
        # enqueues on a 500-slot ``_send_queue`` that drains on WSS
        # reconnect, and the gateway holds a Teams ``conv_ref`` for
        # proactive send. A transient ``_ws_connected=False`` window
        # (backoff / token refresh / reconnect) must NOT drop the reply.
        if (
            channel_manager is not None
            and target.channel != ChannelType.CLOUD
            and not target.session_id  # no session → no persistence recovery → skip as before
        ):
            channel = channel_manager.get(target.channel)
            if channel is not None and not channel.is_connected:
                logger.warning(f"{prefix} channel '{target.channel}' disconnected, skipping notify")
                return

        outbound = OutboundMessage(
            channel=target.channel,
            channel_id=target.channel_id,
            content=content,
            thread_id=target.thread_id,
            metadata={
                "source": "delegate",
                "session_id": target.session_id or None,
                "task_id": task_id,
                "_origin": origin_tool,
                "_ts": datetime.now(UTC).isoformat(),
            },
        )
        await bus.publish_outbound(outbound)
        logger.info(
            f"{prefix} delivered completion -> outbound "
            f"(channel={target.channel}, session={target.session_id or 'none'})"
        )
    except Exception as exc:
        logger.warning(f"{prefix} notification failed — {exc}")
