"""
HTTP / web-search / web-fetch tools — API calls, search, and content extraction.
"""

from __future__ import annotations

import asyncio
import html as html_mod
import json
import re
import time
from typing import Any
from urllib.parse import urljoin

import httpx
from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.config.schema import SecurityProfile
from workpilot.security.leak import detect_credentials, redact_credentials
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore
from workpilot.security.sanitizer import Sanitizer
from workpilot.security.ssrf import (
    check_url_invariants,
    enforce_url_safety,
    screen_url_ssrf_sync,
)
from workpilot.security.url_classify import (
    AUTH_HEADER_KEYS,
    classify_url,
    has_credential_leak,
)

# ── HttpRequestTool ──────────────────────────────────────────────────────────


class HttpRequestTool(Tool):
    risk_range = (0, 9)

    def __init__(self, security_profile: SecurityProfile = SecurityProfile.STANDARD) -> None:
        self._security_profile = security_profile

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=60, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        method = (args.get("method", "GET") or "GET").upper()
        url = args.get("url", "")
        headers: dict[str, str] = args.get("headers") or {}
        body: str | None = args.get("body")

        # URL invariants (bad scheme / userinfo / missing hostname) are always
        # rejected at runtime — surface with score=0 so the policy table
        # auto-executes and the runtime error surfaces immediately without an
        # approval prompt for a call that can't succeed.
        if url:
            invariant_issue = check_url_invariants(url)
            if invariant_issue is not None:
                return RiskScore(0, reason=f"Invalid URL: {invariant_issue}")

        # SSRF pre-screen (sync) — applies to every HTTP method. Surfaces
        # private IPs / blocked hostnames so the approval gate fires
        # (loopback → 7, LAN / metadata / other → 9). Controlled/restricted
        # profiles additionally hard-block at execute via enforce_url_safety.
        if url:
            ssrf_hit = screen_url_ssrf_sync(url)
            if ssrf_hit:
                msg, ssrf_score = ssrf_hit
                return RiskScore(ssrf_score, reason=f"SSRF risk: {msg}")

        # URL-level risk (sensitive params, suspicious/unknown domain, etc.)
        url_score, url_reason = classify_url(url) if url else (-1, "No URL")

        # Redacted URL for prompt/reason strings (keeps structure, redacts secrets)
        safe_url = redact_credentials(url) if url else ""

        # Collect hints from headers and body
        hints: list[str] = []
        auth_headers = {k.lower() for k in headers} & AUTH_HEADER_KEYS
        if auth_headers:
            hints.append(f"auth headers: {', '.join(sorted(auth_headers))}")
        if body and has_credential_leak(body):
            hints.append("body contains credential-like content")
        hint_str = f" [{'; '.join(hints)}]" if hints else ""

        is_unknown = url_score < 0
        has_sensitive = bool(hints) or url_score >= 6

        if method == "GET":
            if is_unknown:
                return RiskPrompt(
                    context=f"HTTP GET — {url_reason}.{hint_str}",
                    range=(3, 7),
                    factors=(
                        "3: Read from known safe or internal API",
                        "4: Read from less-known external site",
                        "5: Read from unknown site, or downloads executable content",
                        "6: Request leaks sensitive params or auth tokens",
                        "7: Request to suspicious or untrusted endpoint",
                    ),
                )
            if has_sensitive:
                return RiskScore(
                    max(url_score, 7),
                    reason=f"HTTP GET with sensitive info — {url_reason}{hint_str}",
                )
            return RiskScore(url_score, reason=f"HTTP GET — {url_reason}")
        if method == "DELETE":
            return RiskPrompt(
                context=f"HTTP DELETE to {safe_url}. {url_reason}.{hint_str}",
                range=(5, 8),
                signals=("destructive method",),
                factors=(
                    "5: Delete user-owned resource on known platform",
                    "6: Delete shared resource or on less-known service",
                    "7: Delete on external service with auth headers",
                    "8: Bulk delete or delete on production/critical service",
                ),
            )
        # POST, PUT, PATCH
        return RiskPrompt(
            context=f"HTTP {method} to {safe_url}. {url_reason}.{hint_str}",
            range=(3, 7),
            signals=("write method",),
            factors=(
                "3: Write to local or internal development API",
                "4: Write to known platform (GitHub, Azure DevOps)",
                "5: Write to external service or unknown API",
                "6: Write with auth headers or sensitive body content",
                "7: Write to production service or sends credentials",
            ),
        )

    @property
    def name(self) -> str:
        return "http_request"

    @property
    def description(self) -> str:
        return "Make an HTTP API request."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Target URL (http/https only)"},
                "method": {
                    "type": "string",
                    "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"],
                    "description": "HTTP method (default: GET)",
                },
                "headers": {
                    "type": "object",
                    "description": 'Request headers as key-value pairs, e.g. {"Authorization": "Bearer ..."}',
                    "additionalProperties": {"type": "string"},
                },
                "body": {
                    "type": "string",
                    "description": "Request body string. Set Content-Type header accordingly.",
                },
            },
            "required": ["url"],
        }

    async def execute(self, **kwargs: Any) -> str:
        url: str = kwargs["url"]
        method: str = kwargs.get("method", "GET")
        headers: dict[str, str] = kwargs.get("headers", {})
        body: str | None = kwargs.get("body")

        # Basic URL validation — use the shared invariants helper (case-
        # insensitive scheme parsing, catches missing host / userinfo too)
        # so assess_risk() and execute() agree on what "valid" means.
        invariant_issue = check_url_invariants(url)
        if invariant_issue is not None:
            return f"Error: {invariant_issue}"

        # SSRF runtime enforcement — hard-blocks only in controlled/restricted.
        # Open/standard rely on the assess_risk SSRF score from
        # screen_url_ssrf_sync (7 for loopback, 9 for LAN / metadata / other).
        try:
            await enforce_url_safety(url, self._security_profile)
        except ValueError as exc:
            return f"BLOCKED: {exc}"

        # Outbound leak detection — block requests containing credentials
        scan_text = f"{url} {str(headers)} {body or ''}"
        findings = detect_credentials(scan_text)
        if findings:
            # Security-first: block on any credential pattern. False positives are safer than exfiltration.
            types = ", ".join(sorted({t for t, _ in findings}))
            return (
                f"Blocked: request contains potential credentials ({types}). "
                "Remove sensitive data and retry."
            )

        try:
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
                resp = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    content=body,
                )

            content_type = resp.headers.get("content-type", "")
            if "json" in content_type:
                body_text = json.dumps(resp.json(), indent=2)
            else:
                body_text = resp.text

            return f"HTTP {resp.status_code}\n\n{body_text}"

        except httpx.TimeoutException:
            return "HTTP request timed out"
        except Exception as exc:
            return f"HTTP error: {exc}"


# ── WebSearchTool ────────────────────────────────────────────────────────────

# Regex patterns for DuckDuckGo HTML result parsing (fallback when bs4 unavailable)
_DDG_RESULT_LINK = re.compile(
    r'<a\s+[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
    re.DOTALL,
)
_DDG_RESULT_SNIPPET = re.compile(
    r'<a\s+[^>]*class="result__snippet"[^>]*>(.*?)</a>',
    re.DOTALL,
)
_HTML_TAG = re.compile(r"<[^>]+>")


def _strip_html(text: str) -> str:
    """Remove HTML tags and decode entities."""
    return html_mod.unescape(_HTML_TAG.sub("", text)).strip()


class WebSearchTool(Tool):
    """Search the web using DuckDuckGo HTML search (no API key required)."""

    risk_range = (1, 1)

    _last_request_time: float = 0.0
    _rate_lock: asyncio.Lock = asyncio.Lock()

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=60, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        query = args.get("query", "")
        if has_credential_leak(query):
            return RiskScore(5, reason="Search query contains credential-like content")
        return RiskScore(1, reason="External web search")

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return "Search the web. Returns titles, URLs, and snippets."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The search query"},
                "count": {
                    "type": "integer",
                    "description": "Number of results (default 5, max 10)",
                },
            },
            "required": ["query"],
        }

    async def execute(self, **kwargs: Any) -> str:
        query: str = kwargs["query"]
        count: int = max(1, min(kwargs.get("count", 5), 10))

        if not query.strip():
            return "Error: search query must not be empty"

        # Rate limit: at most 1 request per second
        async with WebSearchTool._rate_lock:
            now = time.monotonic()
            elapsed = now - WebSearchTool._last_request_time
            if elapsed < 1.0:
                await asyncio.sleep(1.0 - elapsed)
            WebSearchTool._last_request_time = time.monotonic()

        try:
            async with httpx.AsyncClient(
                timeout=float(self.metadata.timeout), follow_redirects=True
            ) as client:
                resp = await client.get(
                    "https://html.duckduckgo.com/html/",
                    params={"q": query},
                    headers={"User-Agent": "WorkPilot/0.1 (web_search tool)"},
                )
                resp.raise_for_status()

            results = self._parse_results(resp.text, count)

            if not results:
                return f'No results found for "{query}".'

            lines: list[str] = [f'Search results for "{query}":\n']
            for i, (title, url, snippet) in enumerate(results, 1):
                lines.append(f"[{i}] {title}")
                lines.append(f"    {url}")
                if snippet:
                    lines.append(f"    {snippet}")
                lines.append("")

            return "\n".join(lines).rstrip()

        except httpx.TimeoutException:
            return "Web search timed out"
        except Exception as exc:
            logger.warning(f"web_search failed: {exc}")
            return f"Web search error: {exc}"

    def _parse_results(self, html: str, count: int) -> list[tuple[str, str, str]]:
        """Parse DuckDuckGo HTML results. Prefers BeautifulSoup, falls back to regex."""
        try:
            import bs4  # noqa: F401

            return self._parse_with_bs4(html, count)
        except ImportError:
            return self._parse_with_regex(html, count)

    def _parse_with_bs4(self, html: str, count: int) -> list[tuple[str, str, str]]:
        """Parse results using BeautifulSoup."""
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(html, "html.parser")
        results: list[tuple[str, str, str]] = []

        for result_div in soup.select(".result"):
            if len(results) >= count:
                break

            link_el = result_div.select_one("a.result__a")
            snippet_el = result_div.select_one("a.result__snippet")

            if not link_el:
                continue

            title = link_el.get_text(strip=True)
            url = link_el.get("href", "")
            snippet = snippet_el.get_text(strip=True) if snippet_el else ""

            if title and url:
                results.append((title, str(url), snippet))

        return results

    def _parse_with_regex(self, html: str, count: int) -> list[tuple[str, str, str]]:
        """Parse results using regex fallback."""
        links = _DDG_RESULT_LINK.findall(html)
        snippets = _DDG_RESULT_SNIPPET.findall(html)

        results: list[tuple[str, str, str]] = []
        for i, (url, raw_title) in enumerate(links):
            if len(results) >= count:
                break
            title = _strip_html(raw_title)
            snippet = _strip_html(snippets[i]) if i < len(snippets) else ""
            if title and url:
                results.append((title, url, snippet))

        return results


# ── WebFetchTool ─────────────────────────────────────────────────────────────

_UNTRUSTED_OPEN = "[UNTRUSTED_CONTENT]"
_UNTRUSTED_CLOSE = "[/UNTRUSTED_CONTENT]"


class _FetchCache:
    """Simple TTL cache for web_fetch results (15-min TTL, 100 entries max)."""

    def __init__(self, ttl: float = 900.0, max_entries: int = 100) -> None:
        self._ttl = ttl
        self._max_entries = max_entries
        self._cache: dict[str, tuple[float, str]] = {}
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> str | None:
        async with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            ts, value = entry
            if time.monotonic() - ts > self._ttl:
                del self._cache[key]
                return None
            return value

    async def put(self, key: str, value: str) -> None:
        async with self._lock:
            # Evict expired entries first
            now = time.monotonic()
            expired = [k for k, (ts, _) in self._cache.items() if now - ts > self._ttl]
            for k in expired:
                del self._cache[k]

            # Evict oldest if at capacity
            if len(self._cache) >= self._max_entries:
                oldest_key = min(self._cache, key=lambda k: self._cache[k][0])
                del self._cache[oldest_key]

            self._cache[key] = (now, value)

    async def clear(self) -> None:
        async with self._lock:
            self._cache.clear()


class WebFetchTool(Tool):
    """Fetch a URL and extract readable content (HTML -> markdown or plain text)."""

    risk_range = (0, 9)

    def __init__(self, security_profile: SecurityProfile = SecurityProfile.STANDARD) -> None:
        self._cache = _FetchCache()
        self._security_profile = security_profile

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=60, streaming=True, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        url = args.get("url", "")
        if not url:
            return RiskScore(1, reason="No URL provided")
        invariant_issue = check_url_invariants(url)
        if invariant_issue is not None:
            return RiskScore(0, reason=f"Invalid URL: {invariant_issue}")
        ssrf_hit = screen_url_ssrf_sync(url)
        if ssrf_hit:
            msg, ssrf_score = ssrf_hit
            return RiskScore(ssrf_score, reason=f"SSRF risk: {msg}")
        score, reason = classify_url(url)
        if score < 0:
            return RiskPrompt(
                context=f"Web fetch: {reason}.",
                range=(5, 8),
                factors=(
                    "5: Fetch from community or user-hosted site",
                    "6: Fetch from unknown domain or free hosting",
                    "7: Fetch from suspicious domain or adult/gambling TLD",
                    "8: Fetch from known phishing or malware domain",
                ),
            )
        return RiskScore(score, reason=f"Web fetch — {reason}")

    @property
    def name(self) -> str:
        return "web_fetch"

    @property
    def description(self) -> str:
        return "Fetch a web page and extract readable text."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "The URL to fetch"},
                "selector": {
                    "type": "string",
                    "description": "CSS selector to extract a section, e.g. 'article', '.main-content'",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "Maximum characters to return (default 20000)",
                },
            },
            "required": ["url"],
        }

    async def execute(self, **kwargs: Any) -> str:
        url: str = kwargs["url"]
        selector: str | None = kwargs.get("selector")
        max_chars: int = max(100, min(kwargs.get("max_chars", 20_000), 100_000))

        # Basic URL validation — use the shared invariants helper (case-
        # insensitive scheme parsing, catches missing host / userinfo too)
        # so assess_risk() and execute() agree on what "valid" means.
        invariant_issue = check_url_invariants(url)
        if invariant_issue is not None:
            return f"Error: {invariant_issue}"

        # SSRF runtime enforcement — hard-blocks only in controlled/restricted.
        # Open/standard rely on the assess_risk SSRF score from
        # screen_url_ssrf_sync (7 for loopback, 9 for LAN / metadata / other).
        try:
            await enforce_url_safety(url, self._security_profile)
        except ValueError as e:
            return f"Error: {e}"

        # Cache keys
        raw_cache_key = url + "::raw"
        extracted_cache_key = url

        # Try cache first
        cached_extracted = await self._cache.get(extracted_cache_key)
        cached_raw = await self._cache.get(raw_cache_key)

        if cached_extracted is not None:
            logger.debug(f"web_fetch cache hit: {url}")
            content = cached_extracted
            raw_html = cached_raw  # may be None for non-HTML
        else:
            if self._progress:
                await self._progress(f"Fetching {url}...\n")
            try:
                _MAX_RESPONSE_BYTES = 10 * 1024 * 1024  # 10 MB
                _MAX_REDIRECTS = 5
                current_url = url

                async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
                    for _redirect_i in range(_MAX_REDIRECTS + 1):
                        resp = await client.get(
                            current_url,
                            headers={"User-Agent": "WorkPilot/0.1 (web_fetch tool)"},
                        )
                        if resp.is_redirect:
                            location = resp.headers.get("location")
                            if not location:
                                break
                            # Resolve relative redirects
                            current_url = urljoin(current_url, location)
                            # Invariants + controlled/restricted hard-block.
                            await enforce_url_safety(current_url, self._security_profile)
                            # Under open/standard enforce_url_safety is a
                            # no-op for direct private targets. The
                            # assess_risk approval for this web_fetch was
                            # scored against the *original* URL only, so a
                            # redirect into a private/LAN target would
                            # silently bypass the approval gate. Stop and
                            # tell the caller to re-invoke with the
                            # resolved URL so the gate fires properly.
                            ssrf_hit = screen_url_ssrf_sync(current_url)
                            if ssrf_hit is not None:
                                return (
                                    f"Error: redirect target {current_url} is an "
                                    f"SSRF target ({ssrf_hit[0]}). The approval for "
                                    "this fetch was scored on the original URL only. "
                                    "Re-issue web_fetch against this URL directly if "
                                    "you really want to follow the redirect."
                                )
                            continue
                        break
                    else:
                        return "Error: too many redirects (max 5)"

                    resp.raise_for_status()

                # Enforce response size limit
                content_length = resp.headers.get("content-length")
                if content_length and int(content_length) > _MAX_RESPONSE_BYTES:
                    return (
                        f"Error: response too large ({int(content_length)} bytes, "
                        f"max {_MAX_RESPONSE_BYTES})"
                    )
                if len(resp.content) > _MAX_RESPONSE_BYTES:
                    return (
                        f"Error: response too large ({len(resp.content)} bytes, "
                        f"max {_MAX_RESPONSE_BYTES})"
                    )

                if self._progress:
                    size_kb = len(resp.content) / 1024
                    await self._progress(f"Downloaded {size_kb:.0f}KB from {resp.url}\n")

                content_type = resp.headers.get("content-type", "")
                raw_text = resp.text
                raw_html = None

                if "json" in content_type:
                    import json

                    try:
                        content = json.dumps(resp.json(), indent=2)
                    except Exception:
                        content = raw_text
                elif "html" in content_type:
                    raw_html = raw_text
                    content = self._extract_html(raw_text)
                    await self._cache.put(raw_cache_key, raw_html)
                elif "markdown" in content_type:
                    content = raw_text
                else:
                    content = raw_text

                await self._cache.put(extracted_cache_key, content)

            except httpx.TimeoutException:
                return "Web fetch timed out"
            except ValueError as exc:
                # enforce_url_safety raises ValueError for
                # controlled/restricted redirect targets and invariant
                # violations — surface those with the tool's structured
                # `Error:` prefix instead of the generic "Web fetch error"
                # wrapper so callers can distinguish policy rejections
                # from network / parsing failures.
                logger.warning(f"web_fetch rejected: {exc}")
                return f"Error: {exc}"
            except Exception as exc:
                logger.warning(f"web_fetch failed: {exc}")
                return f"Web fetch error: {exc}"

        # Apply CSS selector on raw HTML if available
        if selector and raw_html is not None:
            try:
                selected = self._apply_selector(raw_html, selector)
                if selected is not None:
                    content = selected
            except Exception as exc:
                logger.warning(f"CSS selector failed: {exc}")

        content = Sanitizer.truncate(content, max_chars)
        return f"{_UNTRUSTED_OPEN}\n{content}\n{_UNTRUSTED_CLOSE}"

    def _extract_html(self, html: str) -> str:
        """Extract readable content from HTML. Prefers bs4+markdownify, falls back to stdlib HTMLParser."""
        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(html, "html.parser")

            # Remove script, style, nav, footer, header tags
            for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
                tag.decompose()

            try:
                import markdownify

                return str(
                    markdownify.markdownify(
                        str(soup.body or soup),
                        heading_style="ATX",
                        strip=["img"],
                    ).strip()
                )
            except ImportError:
                return str(soup.get_text(separator="\n", strip=True))

        except ImportError:
            # Stdlib HTMLParser fallback (avoids regex tag stripping)
            from html.parser import HTMLParser

            class _TextExtractor(HTMLParser):
                def __init__(self) -> None:
                    super().__init__()
                    self._parts: list[str] = []
                    self._skip = False

                def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
                    if tag in ("script", "style"):
                        self._skip = True

                def handle_endtag(self, tag: str) -> None:
                    if tag in ("script", "style"):
                        self._skip = False

                def handle_data(self, data: str) -> None:
                    if not self._skip:
                        self._parts.append(data)

            extractor = _TextExtractor()
            extractor.feed(html)
            extractor.close()
            text = html_mod.unescape(" ".join(extractor._parts))
            text = re.sub(r"\n{3,}", "\n\n", text)
            text = re.sub(r"[ \t]+", " ", text)
            return text.strip()

    def _apply_selector(self, html: str, selector: str) -> str | None:
        """Apply CSS selector to HTML and return extracted text."""
        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(html, "html.parser")
            elements = soup.select(selector)
            if not elements:
                return None

            parts: list[str] = []
            for el in elements:
                try:
                    import markdownify

                    parts.append(
                        markdownify.markdownify(str(el), heading_style="ATX", strip=["img"]).strip()
                    )
                except ImportError:
                    parts.append(el.get_text(separator="\n", strip=True))
            return "\n\n".join(parts)
        except ImportError:
            logger.warning("CSS selector requires beautifulsoup4: pip install beautifulsoup4")
            return None
