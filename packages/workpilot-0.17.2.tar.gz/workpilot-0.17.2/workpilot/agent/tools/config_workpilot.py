"""
config_workpilot tool — lets the agent read, discover, and modify WorkPilot configuration.

The agent can:
- show: read current config (secrets redacted) with a baseHash for optimistic concurrency
- lookup: discover the JSON Schema for a config path (type, description, constraints)
- patch: apply a partial update to workpilot.local.yaml with Pydantic validation
- reload: check when changes take effect
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.config.schema import AppConfig
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore

# ── Deny list — fields that CANNOT be modified via this tool ────────────────
# Credentials and MCP auth material — must use `workpilot secrets` or ${ENV_VAR}.
# Loader-only keys (extends, profiles, env) are blocked by _VALID_TOP_KEYS instead.

_DENY_PATHS: frozenset[str] = frozenset(
    {
        # Credentials — managed via `workpilot secrets set` or ${ENV_VAR}
        "providers.openai.api_key",
        "providers.github_copilot.token",
        "channels.web.api_key",
        "tools.mcp_servers.*.auth",
        "tools.mcp_servers.*.headers",
    }
)

# ── Elevated risk — sensitive paths gated by high risk scores ───────────────
# Instead of hard-blocking, these require human approval at the policy level.
# (pattern, score, reason)
#   Score 9 → standard: HUMAN (no Always Allow); controlled/restricted: REJECT
#   Score 8 → standard: HUMAN (Always Allow available)
#   Score 7 → standard: HUMAN (Always Allow available)

_ELEVATED_RISK: list[tuple[str, int, str]] = [
    # ── Score 9: security governance core ────────────────────────────────
    ("security.profile", 9, "Security profile governs all autonomy levels"),
    ("security.estop", 9, "E-stop is the last-resort safety mechanism"),
    ("security.roles", 9, "RBAC roles control per-user access"),
    ("security.overrides", 9, "Security overrides bypass profile defaults"),
    ("security.require_auth", 9, "Auth gate for multi-user deployments"),
    ("security.default_role", 9, "Default role for unauthenticated users"),
    ("security.secret_backend", 9, "Backend change may lose encrypted credentials"),
    ("security.denied_paths", 9, "Denied paths restrict filesystem access"),
    ("tools.shell.deny_patterns", 9, "Shell deny patterns are the command sandbox"),
    ("tools.mcp_servers.*.command", 9, "MCP server command = arbitrary code execution"),
    ("tools.mcp_servers.*.args", 9, "MCP server args complete arbitrary execution"),
    # ── Score 8: important but less critical ─────────────────────────────
    ("security.audit", 8, "Audit config affects security event logging"),
    ("security.approval", 8, "Approval workflow for human-in-the-loop"),
    ("security.allowlist", 8, "Tool approval memory per user"),
    ("security.auto_migrate_secrets", 8, "Secret migration affects credential storage"),
    ("tools.shell.allow_patterns", 8, "Shell allow patterns bypass deny checks"),
    ("tools.mcp_servers.*.env", 8, "MCP server env may expose secrets"),
    ("tools.mcp_servers.*.risk", 8, "Server risk score affects autonomy requirements"),
    ("tools.mcp_servers.*.tool_risks", 8, "Per-tool risk overrides affect approval flow"),
    ("tools.mcp_servers.*.risk_rules", 8, "Conditional risk rules affect approval flow"),
    # ── Score 7: advisory ────────────────────────────────────────────────
    ("security.risk_context", 7, "Risk context hints for LLM scorer"),
]

# ── Valid top-level keys (rejects loader-only keys: extends, profiles, env) ──

_VALID_TOP_KEYS: frozenset[str] = frozenset(AppConfig.model_fields.keys())


class ConfigWorkpilotTool(Tool):
    """Read or modify WorkPilot configuration via natural language."""

    def __init__(
        self,
        config: AppConfig,
        local_config_path: Path,
        schema: dict[str, Any],
        runtime: Any = None,
    ) -> None:
        self._config = config
        self._local_path = local_config_path
        self._schema = schema
        self._runtime = runtime

    @property
    def name(self) -> str:
        return "config_workpilot"

    @property
    def description(self) -> str:
        return "Read or modify current configuration settings."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["show", "lookup", "patch", "reload"],
                    "description": (
                        "show = read current config (secrets redacted) with a baseHash; "
                        "lookup = get schema info (type, allowed values, description) for a config path; "
                        "patch = update a config value (validates before writing); "
                        "reload = check when changes take effect. "
                        "Sections: providers, agents, tools, skills, security, channels, cron, logging."
                    ),
                },
                "path": {
                    "type": "string",
                    "description": (
                        "Dot-separated config path (e.g. 'logging.level', 'agents.default.model', 'tools.shell.timeout'). "
                        "Use a section name like 'logging' or 'tools' to see all children. "
                        "Omit for show to return the full config. Required for lookup and patch."
                    ),
                },
                "value": {
                    "type": "string",
                    "description": "New value for patch (use lookup to check allowed values). Pass JSON for arrays/objects.",
                },
                "base_hash": {
                    "type": "string",
                    "description": "Hash from a previous show response. Pass to patch to ensure config hasn't changed since you read it. Optional.",
                },
            },
            "required": ["action"],
        }

    risk_range = (0, 10)

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = (args.get("action", "") or "").strip()
        if action == "show":
            return RiskScore(1, reason="Read current config (secrets redacted)")
        if action == "lookup":
            return RiskScore(0, reason="Read config schema")
        if action == "reload":
            return RiskScore(0, reason="Informational — check when changes take effect")
        if action == "patch":
            path = (args.get("path", "") or "").strip()
            if not path:
                return RiskScore(4, reason="Config patch (no path specified)")
            # Non-schema top-level key (extends, profiles, env, etc.)
            top_key = path.split(".")[0]
            if top_key not in _VALID_TOP_KEYS:
                return RiskScore(
                    1, reason=f"Invalid config section '{top_key}' (rejected at execute)"
                )
            # Hard-denied paths (credentials + MCP auth material) → REJECT
            denial = _check_deny_list(path)
            if denial:
                return RiskScore(10, reason=f"Config patch to protected path: {path}")
            # Elevated-risk paths (security governance, sandbox boundaries)
            elevated = _check_elevated_risk(path)
            if elevated:
                score, reason = elevated
                return RiskScore(score, reason=reason)
            # Sensitive runtime-reloadable fields
            if path == "workspace":
                return RiskScore(8, reason="Workspace switch changes security boundary")
            if path == "security.allowed_paths":
                return RiskScore(7, reason="Modifying sandbox allowed paths")
            # Deterministic by path pattern
            leaf = path.rsplit(".", 1)[-1] if "." in path else path
            if path.startswith("logging."):
                return RiskScore(3, reason=f"Config patch: {path} (cosmetic)")
            if leaf in ("format", "level"):
                return RiskScore(3, reason=f"Config patch: {path} (cosmetic)")
            if leaf in ("description", "prompt"):
                return RiskScore(3, reason=f"Config patch: {path} (text only)")
            if leaf in ("timeout", "port", "interval"):
                return RiskScore(4, reason=f"Config patch: {path} (tuning)")
            if leaf in ("model", "max_iterations", "max_spawn_depth"):
                return RiskScore(5, reason=f"Config patch: {path} (agent behavior)")
            if leaf == "enabled":
                return RiskScore(6, reason=f"Config patch: {path} (feature toggle)")
            if leaf in ("url", "endpoint", "host"):
                return RiskScore(6, reason=f"Config patch: {path} (connectivity)")
            # Remaining → LLM
            return RiskPrompt(
                context=f"Config patch: {path}",
                range=(4, 7),
                factors=(
                    "4: Agent behavior or minor structural change",
                    "5: Feature toggle or tool configuration",
                    "6: External connectivity or channel config",
                    "7: Broad change affecting multiple subsystems",
                ),
            )
        # Unknown action → fall through to base class default RiskPrompt
        return super().assess_risk(args)

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        path = kwargs.get("path", "")
        raw_value = kwargs.get("value")
        base_hash = kwargs.get("base_hash")

        if action == "show":
            return self._show(path or None)
        if action == "lookup":
            if not path:
                return "Error: 'path' is required for lookup. Example: 'logging.level'"
            return self._lookup(path)
        if action == "patch":
            if not path:
                return "Error: 'path' is required for patch."
            if "value" not in kwargs:
                return "Error: 'value' is required for patch."
            value = self._parse_value(raw_value)
            return self._patch(path, value, base_hash)
        if action == "reload":
            return (
                "Config changes are written to workpilot.local.yaml. "
                "They take effect on next restart (workpilot chat / workpilot serve)."
            )
        return f"Error: unknown action '{action}'. Use show, lookup, patch, or reload."

    # ── show ────────────────────────────────────────────────────────────────

    def _show(self, path: str | None) -> str:
        # SecretStr fields are serialized as '**********' by Pydantic.
        # Plain dict fields that may contain secrets (env, headers) need explicit masking.
        data = _mask_sensitive_dicts(self._config.model_dump(mode="json"))

        if path:
            value = _get_nested(data, path)
            if value is _MISSING:
                return f"Config path '{path}' not found."
            result: Any = {"path": path, "value": value}
        else:
            result = data

        try:
            local_data = self._load_local()
        except ValueError as exc:
            return str(exc)
        bh = _compute_hash(local_data)
        return json.dumps({"config": result, "baseHash": bh}, indent=2, default=str)

    # ── lookup ──────────────────────────────────────────────────────────────

    def _lookup(self, path: str) -> str:
        node = self._resolve_schema_node(path)
        if node is None:
            return f"Config path '{path}' not found in schema."

        # Build a compact summary for the LLM
        summary: dict[str, Any] = {"path": path}
        _SUMMARY_KEYS = ("type", "description", "default", "enum", "minimum", "maximum", "pattern")
        for key in _SUMMARY_KEYS:
            if key in node:
                summary[key] = node[key]

        # For objects, list child keys
        if node.get("type") == "object" and "properties" in node:
            children: dict[str, str] = {}
            for k, v in node["properties"].items():
                resolved = v
                if "$ref" in v:
                    resolved = self._resolve_ref(v["$ref"])
                children[k] = resolved.get("description", resolved.get("type", ""))
            summary["properties"] = children

        # Show current value (SecretStr masked by Pydantic; sensitive dicts masked explicitly)
        current = _get_nested(_mask_sensitive_dicts(self._config.model_dump(mode="json")), path)
        if current is not _MISSING:
            summary["current_value"] = current

        return json.dumps(summary, indent=2, default=str)

    # ── patch ───────────────────────────────────────────────────────────────

    def _patch(self, path: str, value: Any, base_hash: str | None) -> str:
        # 1. Deny list check (top-level path + all nested keys in value)
        for check_path in _iter_patch_paths(path, value):
            denial = _check_deny_list(check_path)
            if denial:
                return denial

        # 2. Reject keys not in Pydantic schema (blocks loader-only: extends, profiles, env)
        top_key = path.split(".")[0]
        if top_key not in _VALID_TOP_KEYS:
            return (
                f"Error: '{top_key}' is not a valid config section. "
                f"Valid: {', '.join(sorted(_VALID_TOP_KEYS))}"
            )

        # 3. Load existing local override
        try:
            local_data = self._load_local()
        except ValueError as exc:
            return str(exc)

        # 4. Optimistic concurrency
        if base_hash is not None:
            current_hash = _compute_hash(local_data)
            if current_hash != base_hash:
                return (
                    "Error: config changed since last read (hash mismatch). "
                    "Call 'show' again to get the current baseHash."
                )

        # 5. Build nested dict from dot-path
        patch_dict = _build_nested(path, value)

        # 6. Deep-merge into local data
        from workpilot.config.loader import _deep_merge

        merged_local = _deep_merge(local_data, patch_dict)

        # 7. Validate by simulating full config load
        error = self._validate_merged(merged_local)
        if error:
            return error

        # 8. Write
        from workpilot.config.loader import save_yaml

        save_yaml(self._local_path, merged_local)

        # 9. Hot-reload for runtime-sensitive fields
        if path == "workspace" and self._runtime:
            from pathlib import Path as _Path

            new_ws = _Path(str(value)).resolve()
            if not new_ws.is_dir():
                return f"Config saved but workspace not switched: {new_ws} is not a directory"
            self._runtime.switch_workspace(new_ws)
            self._runtime.config.workspace = str(value)
            return f"Workspace switched to {new_ws} (saved to {self._local_path.name})"
        if path == "security.allowed_paths" and self._runtime:
            new_paths = value if isinstance(value, list) else [value] if value else None
            self._runtime.sandbox.set_allowed_paths(new_paths)
            self._runtime.config.security.allowed_paths = new_paths
            return f"Updated allowed_paths (saved to {self._local_path.name})"

        return f"Updated '{path}' in {self._local_path.name}. Changes take effect on next restart."

    # ── Schema navigation ───────────────────────────────────────────────────

    def _resolve_ref(self, ref: str) -> dict[str, Any]:
        """Resolve a $ref like '#/$defs/ShellConfig'."""
        parts = ref.lstrip("#/").split("/")
        node: dict[str, Any] = self._schema
        for part in parts:
            node = node[part]
        return dict(node)

    def _resolve_schema_node(self, dot_path: str) -> dict[str, Any] | None:
        """Navigate to the schema node for a dot-separated path."""
        segments = dot_path.split(".")
        node: dict[str, Any] = self._schema

        for segment in segments:
            node = self._deref(node)
            props = node.get("properties", {})
            if segment in props:
                node = props[segment]
            elif node.get("additionalProperties") and isinstance(
                node["additionalProperties"], dict
            ):
                node = node["additionalProperties"]
            else:
                return None

        return self._deref(node)

    def _deref(self, node: dict[str, Any]) -> dict[str, Any]:
        """Resolve $ref and anyOf wrappers, preserving description."""
        if "$ref" in node:
            resolved = self._resolve_ref(node["$ref"])
            if "description" in node:
                resolved = {**resolved, "description": node["description"]}
            return resolved
        if "anyOf" in node:
            for option in node["anyOf"]:
                if "$ref" in option:
                    resolved = self._resolve_ref(option["$ref"])
                    if "description" in node:
                        resolved = {**resolved, "description": node["description"]}
                    return resolved
                if option.get("type") not in ("null",):
                    merged = {**option}
                    if "description" in node and "description" not in merged:
                        merged["description"] = node["description"]
                    return merged
        return node

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_value(raw: Any) -> Any:
        """Parse a string value into the appropriate Python type.

        The LLM sends value as a string (schema declares type=string for
        provider compatibility). Try JSON parsing first to handle numbers,
        booleans, arrays, and objects. Fall back to raw string.
        """
        if not isinstance(raw, str):
            return raw  # already parsed (e.g. from direct tool call)
        # Try JSON parse for non-string types
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return raw  # keep as string

    def _load_local(self) -> dict[str, Any]:
        """Load local override YAML. Raises ValueError on parse errors."""
        if not self._local_path.is_file():
            return {}
        try:
            data = yaml.safe_load(self._local_path.read_text(encoding="utf-8"))
        except yaml.YAMLError as exc:
            raise ValueError(
                f"Cannot parse {self._local_path.name}: {exc}. "
                "Please fix the YAML syntax before modifying config."
            ) from exc
        if not isinstance(data, dict):
            return {}
        return data

    def _validate_merged(self, merged_local: dict[str, Any]) -> str | None:
        """Validate by merging into the current running config. Return error or None."""
        from pydantic import ValidationError

        from workpilot.config.loader import _deep_merge

        # mode="python" preserves actual types (SecretStr, enums) so validation
        # reflects the real in-memory config, not JSON-masked placeholders.
        full = _deep_merge(self._config.model_dump(mode="python"), merged_local)
        try:
            AppConfig.model_validate(full)
        except ValidationError as exc:
            return f"Validation error: {exc}"
        return None


# ── Module-level helpers (also used by tests) ───────────────────────────────

_MISSING = object()

# Keys whose dict values should be masked in show/lookup output.
# These are plain dict[str, str] fields that may contain secrets
# (not covered by Pydantic SecretStr serialization).
_SENSITIVE_DICT_KEYS: frozenset[str] = frozenset({"env", "headers"})

# Scalar keys that hold credential-like values as plain str (not SecretStr).
_SENSITIVE_SCALAR_KEYS: frozenset[str] = frozenset()


def _mask_sensitive_dicts(obj: Any, _key: str = "") -> Any:
    """Recursively mask values in known-sensitive fields and credential patterns.

    Four layers:
    1. Pydantic ``SecretStr`` → already ``'**********'`` from ``model_dump(mode="json")``
    2. Known sensitive dict keys (``env``, ``headers``) → mask all string values
    3. Known sensitive scalar keys → mask the value
    4. Pattern-based → scrub JWT, AWS, GitHub PAT, Slack, OpenAI-style tokens
       from any remaining string (catches secrets in URLs, free-text fields)
    """
    from workpilot.security.audit import _redact_string

    if isinstance(obj, dict):
        if _key in _SENSITIVE_DICT_KEYS:
            return {
                k: "**********" if isinstance(v, str) else _mask_sensitive_dicts(v, k)
                for k, v in obj.items()
            }
        return {k: _mask_sensitive_dicts(v, k) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_mask_sensitive_dicts(item, _key) for item in obj]
    # Mask sensitive scalar string values
    if _key in _SENSITIVE_SCALAR_KEYS and isinstance(obj, str) and obj:
        return "**********"
    # Pattern-based credential scrubbing for remaining strings
    if isinstance(obj, str):
        return _redact_string(obj)
    return obj


def _get_nested(data: dict[str, Any], dot_path: str) -> Any:
    """Navigate a dict by dot-separated path. Returns _MISSING if not found."""
    cursor: Any = data
    for segment in dot_path.split("."):
        if isinstance(cursor, dict) and segment in cursor:
            cursor = cursor[segment]
        else:
            return _MISSING
    return cursor


def _build_nested(dot_path: str, value: Any) -> dict[str, Any]:
    """Build a nested dict from a dot-path: 'a.b.c' + v → {'a': {'b': {'c': v}}}."""
    segments = dot_path.split(".")
    result: dict[str, Any] = {}
    cursor = result
    for seg in segments[:-1]:
        cursor[seg] = {}
        cursor = cursor[seg]
    cursor[segments[-1]] = value
    return result


def _compute_hash(data: dict[str, Any]) -> str:
    """SHA-256 hash of JSON-serialized config for optimistic concurrency."""
    raw = json.dumps(data, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _iter_patch_paths(prefix: str, obj: Any) -> list[str]:
    """Yield the prefix and all nested dot-paths for dict values."""
    paths = [prefix]
    if isinstance(obj, dict):
        for k, v in obj.items():
            paths.extend(_iter_patch_paths(f"{prefix}.{k}", v))
    return paths


def _is_path_prefix(prefix_parts: list[str], full_parts: list[str]) -> bool:
    """True if *prefix_parts* is a strict prefix of *full_parts* (wildcards in full)."""
    if len(prefix_parts) >= len(full_parts):
        return False
    for i, pp in enumerate(prefix_parts):
        fp = full_parts[i]
        if fp != "*" and pp != fp:
            return False
    return True


def _check_elevated_risk(dot_path: str) -> tuple[int, str] | None:
    """Return ``(score, reason)`` for the highest matching elevated-risk path, or ``None``.

    Checks both directions:
    - **Forward**: path matches or extends an elevated pattern
      (e.g. ``security.estop.enabled`` matches ``security.estop``)
    - **Parent**: path is a strict prefix of an elevated pattern
      (e.g. ``tools.shell`` is a parent of ``tools.shell.deny_patterns``)
      This prevents bypassing risk scoring by patching a broad parent object.
    """
    path_parts = dot_path.split(".")
    best: tuple[int, str] | None = None
    for pattern, score, reason in _ELEVATED_RISK:
        pattern_parts = pattern.split(".")
        # Forward: path matches or extends pattern
        if _match_pattern(path_parts, pattern_parts):
            if best is None or score > best[0]:
                best = (score, reason)
        # Parent: path is a strict prefix of pattern → conservative max
        elif _is_path_prefix(path_parts, pattern_parts):
            if best is None or score > best[0]:
                best = (score, f"Covers elevated child: {pattern}")
    return best


def _check_deny_list(dot_path: str) -> str | None:
    """Return an error message if the path is denied, else None.

    Supports wildcard ``*`` in deny patterns to match any single segment.
    E.g. ``tools.mcp_servers.*.auth`` blocks ``tools.mcp_servers.myserver.auth``.
    """
    path_parts = dot_path.split(".")
    for denied in _DENY_PATHS:
        deny_parts = denied.split(".")
        if _match_pattern(path_parts, deny_parts):
            return (
                f"Error: modifying '{dot_path}' is not permitted. "
                "This field is protected for security reasons."
            )
    return None


def _match_pattern(path_parts: list[str], deny_parts: list[str]) -> bool:
    """Check if path matches a deny pattern (prefix match with * wildcards)."""
    for i, dp in enumerate(deny_parts):
        if i >= len(path_parts):
            return False
        if dp != "*" and dp != path_parts[i]:
            return False
    return True
