"""
Cross-channel notification tool — send messages to any active channel
via the async message bus.

The tool publishes an OutboundMessage to the MessageBus, which routes it
to the appropriate channel handler. Use '*' to broadcast to all channels.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from workpilot.agent.output_parser import extract_outputs
from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.bus.events import OutboundMessage
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import ChannelType
from workpilot.security.risk import RiskAssessment, RiskScore
from workpilot.session.manager import SessionManager


class NotifyTool(Tool):
    """Send notifications to active channels through the message bus."""

    risk_range = (0, 0)

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Notification to user")

    def __init__(
        self,
        bus: MessageBus,
        active_channels_fn: Callable[[], list[ChannelType]] | None = None,
        workspace: Path | None = None,
    ) -> None:
        self._bus = bus
        self._active_channels_fn = active_channels_fn or (lambda: [ChannelType.CLI])
        # ``workspace`` is used to resolve ``workpilot-image://relative/path``
        # refs in the notify content — same markdown-hoist protocol as the
        # agent's main reply. None → falls back to cwd (legacy behaviour
        # when the tool is instantiated without runtime context, e.g. tests).
        self._workspace = workspace or Path.cwd()

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "notify"

    @property
    def description(self) -> str:
        return "Push a notification to the user via their active channel."

    @property
    def parameters(self) -> dict[str, Any]:
        channels = self._active_channels_fn()
        return {
            "type": "object",
            "properties": {
                "channel": {
                    "type": "string",
                    "enum": [*channels, "*"],
                    "description": (
                        "Target channel, or '*' for all active channels. "
                        "cloud: Teams bot & Web Chat via Cloud Gateway."
                    ),
                },
                "content": {
                    "type": "string",
                    "description": "Message content.",
                },
            },
            "required": ["channel", "content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        channel: str = kwargs["channel"]  # from LLM tool call — may be "*" or a channel name
        content: str = kwargs["content"]
        # Registry injects _channel/_channel_id/_session_id from the current conversation
        current_channel = ChannelType.of(kwargs.get("_channel", ""))
        current_channel_id: str = kwargs.get("_channel_id", "")
        current_session_id: str = kwargs.get("_session_id", "")

        if not content.strip():
            return "Error: message content required."

        # Validate ``channel`` explicitly BEFORE any hoist — the hoist
        # writes bytes to the attachment store, and we don't want an
        # invalid-channel typo (e.g. ``"wen"``) to leave files on disk
        # that will never be delivered. JSON-schema ``enum`` restricts
        # channel to ``"*"`` + active channel names, but the tool registry
        # does NOT enforce schema types/enums at runtime — surface the
        # typo here as a clear error instead.
        active_channels = self._active_channels_fn()
        valid_channel_names = {str(ch) for ch in active_channels}
        if channel != "*" and channel not in valid_channel_names:
            valid_list = ", ".join(sorted(valid_channel_names) + ["*"]) or "'*'"
            return f"Error: unknown or inactive channel {channel!r}. Valid options: {valid_list}."
        if channel == "*" and not active_channels:
            # Broadcast with no active channels — same "nothing to deliver"
            # verdict as the typo case. Reject before hoist so we don't
            # persist bytes that can't be routed.
            return "Error: no active channels."

        # Markdown-hoist: same ``workpilot-image://`` protocol as the agent's
        # main reply (see ``workpilot/agent/output_parser.py``). Any sentinel
        # in the notify content gets rewritten to sha form, bytes saved to
        # the store, and the ref list flows to the channel via
        # ``OutboundMessage.attachments``. Failures are kept literal (user
        # sees the broken URL) — same contract as the main-reply path.
        content, hoisted_refs = extract_outputs(content, workspace=self._workspace)
        attachments: list[Any] | None = hoisted_refs or None

        def _meta(target_ch: str) -> dict[str, Any]:
            """Metadata stamp recognised by ``AgentLoop._capture_for_persist``.

            ``target_session_id`` resolution, in order:

            1. ``SessionManager.channel_default_session(target_ch)`` —
               the channel's canonical default session (web → local_web,
               cli → local_cli). Derivable from the channel name alone.
            2. **Self-target on cloud**: cloud has no channel-default
               (cloud_teams and cloud_web depend on which surface the
               user is on — not derivable from ``"cloud"`` alone). When
               the user is ON cloud and notifies themselves (target ==
               current channel), use their current session so the entry
               lands in ``cloud_teams.jsonl`` / ``cloud_web.jsonl``.
            3. Otherwise ``None`` → the capture handler drops the entry.
               Covers cross-channel sends (web user → notify cloud) and
               the cloud leg of a broadcast (no duplicate into the
               originating session).

            We deliberately do NOT stamp ``session_id`` in the metadata:
            the handler's ``target_session_id or session_id`` fallback
            would otherwise pull every per-target outbound back into the
            originating session on broadcast.
            """
            target_sid = SessionManager.channel_default_session(target_ch)
            if (
                target_sid is None
                and current_session_id
                and ChannelType.of(target_ch) == current_channel
            ):
                # Cloud self-notify (user on Teams/WebChat notifying themselves).
                target_sid = current_session_id
            return {
                "source": "notify",
                "_ts": datetime.now(UTC).isoformat(),
                "_origin": "notify",
                "target_session_id": target_sid,
            }

        # Broadcast to all active channels (``active_channels`` was
        # already resolved + checked non-empty in the validate block above).
        if channel == "*":
            targets = active_channels
            results: list[str] = []
            for ch in targets:
                try:
                    # Use real channel_id if notifying the current conversation's channel
                    cid = current_channel_id if ch == current_channel and current_channel_id else ch
                    await self._bus.publish_outbound(
                        OutboundMessage(
                            channel=ChannelType.of(ch),
                            channel_id=cid,
                            content=content,
                            attachments=attachments,
                            metadata=_meta(str(ch)),
                        )
                    )
                    results.append(ch)
                except Exception as exc:
                    logger.error(f"Failed to notify '{ch}': {exc}")
            return f"Notified {len(results)} channels: {', '.join(results)}"

        # Single channel
        cid = current_channel_id if channel == current_channel and current_channel_id else channel
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ChannelType.of(channel),
                    channel_id=cid,
                    content=content,
                    attachments=attachments,
                    metadata=_meta(channel),
                )
            )
            return f"Notified {channel}"
        except Exception as exc:
            logger.error(f"Failed to notify '{channel}': {exc}")
            return f"Error sending to {channel}: {exc}"
