"""
Attachment store — content-addressed file storage.

Two attachment kinds are supported:

- ``image`` — binary image bytes referenced from prompts as
  ``workpilot-attachment://<sha>``; inlined to a ``data:`` URL at the
  provider API boundary (see ``providers/client.py::_resolve_attachment_urls``).
  Sent to the model as ``input_image`` parts, which require a vision-capable
  model.
- ``text`` — UTF-8 decodable text/code/markdown files. The bytes are read
  and inlined as ``input_text`` parts directly, so no vision model is
  required. Size-capped more aggressively than images so they don't blow
  the context window.

The on-disk layout is the same for both — ``~/.workpilot/data/attachments/<sha>.<ext>``.
"""

from __future__ import annotations

import base64
import hashlib
import os
import re
from collections.abc import AsyncIterable, AsyncIterator, Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Literal

from loguru import logger

from workpilot.utils.helpers import ensure_dir, get_data_dir

# ── MIME / extension allowlists ───────────────────────────────────────────────

ALLOWED_IMAGE_TYPES: frozenset[str] = frozenset(
    # SVG intentionally excluded — Teams renders it as a broken-image icon
    # (empirically confirmed 2026-04-25 via scripts/teams_inline_image_probe.py).
    {"image/png", "image/jpeg", "image/gif", "image/webp"}
)

# Known text-ish MIMEs. Browsers serve many code files as ``text/plain`` or
# ``application/octet-stream``, so a filename-extension fallback catches the
# rest (see ``_TEXT_EXTENSIONS``).
_ALLOWED_TEXT_MIMES: frozenset[str] = frozenset(
    {
        "application/graphql",
        "application/javascript",
        "application/json",
        "application/sql",
        "application/toml",
        "application/typescript",
        "application/x-javascript",
        "application/x-toml",
        "application/x-yaml",
        "application/xml",
        "application/yaml",
    }
)

# Extensions we're willing to accept as text even when the browser sends a
# generic MIME (``text/plain``, ``application/octet-stream``, or nothing).
# Curated for common web / backend / cloud / scripting / config formats —
# esoteric languages are deliberately out to keep the surface small.
_TEXT_EXTENSIONS: frozenset[str] = frozenset(
    {
        # plain / docs
        "txt",
        "md",
        "markdown",
        "rst",
        "log",
        # tabular
        "csv",
        "tsv",
        # code
        "py",
        "pyw",
        "js",
        "jsx",
        "mjs",
        "cjs",
        "ts",
        "tsx",
        "rs",
        "go",
        "java",
        "kt",
        "scala",
        "swift",
        "dart",
        "c",
        "cpp",
        "cxx",
        "cc",
        "h",
        "hpp",
        "hxx",
        "cs",
        "fs",
        "vb",
        "rb",
        "php",
        "pl",
        "lua",
        "r",
        # scripts
        "sh",
        "bash",
        "zsh",
        "ps1",
        "bat",
        "cmd",
        # config / data
        "json",
        "yaml",
        "yml",
        "toml",
        "xml",
        "ini",
        "cfg",
        "conf",
        "properties",
        "env",
        # markup
        "html",
        "htm",
        "css",
        "scss",
        "sass",
        "less",
        # domain
        "sql",
        "graphql",
        "proto",
        "tf",
        "hcl",
        # framework
        "vue",
        "svelte",
        "astro",
    }
)

# Per-kind size caps — image bytes ride the wire intact, but text goes into
# the prompt verbatim so we cap more tightly to protect the context window.
MAX_IMAGE_BYTES: int = 32 * 1024 * 1024  # 32 MiB
MAX_TEXT_BYTES: int = 500_000  # 500 KB

AttachmentKind = Literal["image", "text"]

_IMAGE_EXT_BY_MIME: dict[str, str] = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
}
_MIME_BY_IMAGE_EXT: dict[str, str] = {v: k for k, v in _IMAGE_EXT_BY_MIME.items()}
_TEXT_EXT: str = ".txt"

ATTACHMENT_URL_SCHEME = "workpilot-attachment://"


# Fence-language map (for text attachments) lives here so agent + provider
# share the same extension → language table. Keep in sync with
# ``_TEXT_EXTENSIONS`` above.
_FENCE_LANG_BY_EXT: dict[str, str] = {
    "py": "python",
    "pyw": "python",
    "js": "javascript",
    "mjs": "javascript",
    "cjs": "javascript",
    "jsx": "jsx",
    "ts": "typescript",
    "tsx": "tsx",
    "rs": "rust",
    "go": "go",
    "java": "java",
    "kt": "kotlin",
    "scala": "scala",
    "swift": "swift",
    "dart": "dart",
    "c": "c",
    "cpp": "cpp",
    "cxx": "cpp",
    "cc": "cpp",
    "h": "c",
    "hpp": "cpp",
    "hxx": "cpp",
    "cs": "csharp",
    "fs": "fsharp",
    "vb": "vbnet",
    "rb": "ruby",
    "php": "php",
    "pl": "perl",
    "lua": "lua",
    "r": "r",
    "sh": "bash",
    "bash": "bash",
    "zsh": "bash",
    "ps1": "powershell",
    "bat": "batch",
    "cmd": "batch",
    "json": "json",
    "yaml": "yaml",
    "yml": "yaml",
    "toml": "toml",
    "xml": "xml",
    "ini": "ini",
    "cfg": "ini",
    "conf": "ini",
    "properties": "properties",
    "env": "bash",
    "html": "html",
    "htm": "html",
    "css": "css",
    "scss": "scss",
    "sass": "sass",
    "less": "less",
    "sql": "sql",
    "graphql": "graphql",
    "proto": "protobuf",
    "tf": "hcl",
    "hcl": "hcl",
    "vue": "vue",
    "svelte": "svelte",
    "astro": "astro",
    "md": "markdown",
    "markdown": "markdown",
    "csv": "csv",
    "tsv": "tsv",
}


def fence_lang(name: str | None) -> str:
    """Return a fence-language hint for a text attachment (``"python"`` for
    ``foo.py``, ``""`` for unknown extensions)."""
    ext = _extension_of(name)
    return _FENCE_LANG_BY_EXT.get(ext, "") if ext else ""


# Filename sanitizer for embedding in ``<attached_file name="...">`` tags.
# Strips characters that would break the surrounding structure or look like
# prompt-injection scaffolding to the model.
_UNSAFE_NAME_CHARS_RE = re.compile(r'[<>"\x00-\x1f]')


def sanitize_name_for_tag(name: str | None) -> str:
    """Produce a safe display name for an attachment tag. Never empty."""
    if not name:
        return "attachment"
    cleaned = _UNSAFE_NAME_CHARS_RE.sub("_", name).strip()
    return cleaned or "attachment"


def safe_fence(body: str, lang: str = "") -> str:
    """Wrap *body* in a fenced code block whose fence length exceeds the
    longest run of backticks in the body — so markdown attachments with
    their own ``` fences don't close the outer block prematurely."""
    longest = 0
    run = 0
    for ch in body:
        if ch == "`":
            run += 1
            if run > longest:
                longest = run
        else:
            run = 0
    fence = "`" * max(3, longest + 1)
    return f"{fence}{lang}\n{body}\n{fence}"


def render_text_attachment(name: str | None, body: str) -> str:
    """Shared rendering for text attachments — used by both the agent loop
    (build time) and the provider resolver (JSONL replay) so the in-context
    format stays consistent."""
    safe_name = sanitize_name_for_tag(name)
    return (
        f'<attached_file name="{safe_name}">\n'
        f"{safe_fence(body, fence_lang(name))}\n"
        f"</attached_file>"
    )


# ── Classifier ────────────────────────────────────────────────────────────────


def _normalize_mime(content_type: str | None) -> str:
    if not content_type:
        return ""
    return content_type.lower().split(";", 1)[0].strip()


def _extension_of(name: str | None) -> str:
    if not name or "." not in name:
        return ""
    return name.rsplit(".", 1)[-1].lower()


def kind_of(content_type: str | None, name: str | None) -> AttachmentKind | None:
    """Classify an upload. Returns ``None`` if neither image nor text.

    Resolution order:
    1. Image MIME allowlist
    2. Known text MIME allowlist
    3. ``text/*`` generic
    4. Text extension fallback (covers ``application/octet-stream`` +
       ``text/plain`` files that are really code)
    """
    mime = _normalize_mime(content_type)
    if mime in ALLOWED_IMAGE_TYPES:
        return "image"
    if mime in _ALLOWED_TEXT_MIMES or mime.startswith("text/"):
        return "text"
    if _extension_of(name) in _TEXT_EXTENSIONS:
        return "text"
    return None


def cap_for(kind: AttachmentKind) -> int:
    return MAX_IMAGE_BYTES if kind == "image" else MAX_TEXT_BYTES


# ── Store ─────────────────────────────────────────────────────────────────────


class AttachmentError(ValueError):
    """Raised on attachment validation failures."""


@dataclass(frozen=True)
class AttachmentRef:
    sha256: str
    path: str
    content_type: str
    size: int
    kind: AttachmentKind
    name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "sha256": self.sha256,
            "path": self.path,
            "content_type": self.content_type,
            "size": self.size,
            "kind": self.kind,
        }
        if self.name:
            d["name"] = self.name
        return d


def attachments_dir() -> Path:
    return ensure_dir(get_data_dir() / "data" / "attachments")


def _pick_extension(content_type: str, kind: AttachmentKind) -> str:
    """Pick a deterministic extension by ``(content_type, kind)``.

    Derived from content_type only — NOT from the uploaded filename — so the
    same bytes always land at the same path regardless of what the user
    named the file. The original filename is preserved in ``AttachmentRef.name``
    and in the persisted sidecar; it's what drives fence-language detection
    on replay.
    """
    if kind == "image":
        return _IMAGE_EXT_BY_MIME.get(content_type, ".bin")
    return _TEXT_EXT


def _path_for(sha256: str, content_type: str, kind: AttachmentKind) -> Path:
    return attachments_dir() / f"{sha256}{_pick_extension(content_type, kind)}"


def _normalize_content_type(content_type: str) -> str:
    """Strip RFC 7231 parameters (``; charset=...``) and lower-case the
    media type so ``image/png; charset=binary`` and ``IMAGE/PNG`` both
    map to the same stable token used for classification and extension
    selection."""
    if not isinstance(content_type, str):
        return ""
    return content_type.split(";", 1)[0].strip().lower()


def save_attachment(data: bytes, content_type: str, name: str | None = None) -> AttachmentRef:
    """Validate, hash, and persist bytes. Returns a reusable ref.

    Idempotent — if the content-addressed file already exists, the existing
    file is kept and its ref returned.
    """
    content_type = _normalize_content_type(content_type)
    kind = kind_of(content_type, name)
    # Normalise text kinds to "text/plain" so the value returned here
    # matches what ``load_ref()`` reconstructs from disk (we only persist
    # ``<sha>.txt`` regardless of the source MIME — markdown / yaml / py
    # all become text/plain after a round-trip). Preserving the original
    # MIME only in the upload response would be misleading.
    if kind == "text":
        content_type = "text/plain"
    if kind is None:
        raise AttachmentError(
            f"Unsupported attachment: content_type={content_type!r} name={name!r}"
        )
    size = len(data)
    if size == 0:
        raise AttachmentError("Empty attachment")
    cap = cap_for(kind)
    if size > cap:
        raise AttachmentError(f"Attachment too large for kind={kind}: {size} bytes (max {cap})")
    # Reject text that isn't valid UTF-8 — we'd only be able to surface it as
    # text to the LLM, and mojibake makes for bad prompts.
    if kind == "text":
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AttachmentError(f"Text attachment is not valid UTF-8: {exc}") from exc

    sha256 = hashlib.sha256(data).hexdigest()
    path = _path_for(sha256, content_type, kind)
    if not path.exists():
        # Unique tmp suffix per call — two concurrent uploads of the same
        # bytes would otherwise collide on a shared ``<sha>.png.tmp`` and
        # either clobber each other's write or error on replace.
        tmp = path.with_suffix(path.suffix + f".{os.getpid()}.{os.urandom(4).hex()}.tmp")
        try:
            tmp.write_bytes(data)
            tmp.replace(path)
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass

    return AttachmentRef(
        sha256=sha256,
        path=str(path),
        content_type=content_type,
        size=size,
        kind=kind,
        name=name,
    )


_SHA256_HEX_RE = re.compile(r"^[0-9a-f]{64}$")


def _is_valid_sha256(sha256: str) -> bool:
    """Lower-case 64-char hex digest check — guards path traversal from
    untrusted callers (e.g. ``..`` or directory separators would never
    match)."""
    return isinstance(sha256, str) and bool(_SHA256_HEX_RE.fullmatch(sha256))


def load_ref(sha256: str) -> AttachmentRef | None:
    """Look up an on-disk attachment by sha256.

    The on-disk filename is deterministic — one of:
    - ``<sha>.png`` / ``.jpg`` / ``.gif`` / ``.webp`` for images
    - ``<sha>.txt`` for text

    so we stat a handful of known candidates instead of globbing. Input is
    lowercased before validation so callers that forward user-supplied
    digests (API handlers, wire frames) don't need to repeat the
    normalization. Values that don't match 64-char hex return ``None``
    so untrusted input can't produce a path traversal.
    """
    if isinstance(sha256, str):
        sha256 = sha256.lower()
    if not _is_valid_sha256(sha256):
        return None
    dir_ = attachments_dir()
    if not dir_.is_dir():
        return None
    # Images first (fixed MIME → ext map), then the single text filename.
    for ext, mime in _MIME_BY_IMAGE_EXT.items():
        p = dir_ / f"{sha256}{ext}"
        if p.is_file():
            return AttachmentRef(
                sha256=sha256,
                path=str(p),
                content_type=mime,
                size=p.stat().st_size,
                kind="image",
            )
    p_text = dir_ / f"{sha256}{_TEXT_EXT}"
    if p_text.is_file():
        return AttachmentRef(
            sha256=sha256,
            path=str(p_text),
            content_type="text/plain",
            size=p_text.stat().st_size,
            kind="text",
        )
    return None


def load_as_data_url(
    sha256: str,
    *,
    max_inline_data_url_bytes: int | None = None,
) -> str | None:
    """Read an image attachment and encode as a ``data:`` URL.

    Returns ``None`` for missing or non-image attachments. Missing
    attachments are logged with a warning so upstream callers that rely
    on this for rendering can diagnose ``<image missing>`` turns in the
    transcript; non-image attachments return silently because they're
    expected to flow through ``load_as_text`` instead — no error.

    When ``max_inline_data_url_bytes`` is set, returns ``None`` if the
    encoded data URL would exceed the cap — the caller is expected to
    fall back to a metadata-only placeholder via
    :func:`attachment_metadata_text`. The check is performed pre-read
    (using ``ref.size``) so an oversize file is never decoded into RAM.
    """
    ref = load_ref(sha256)
    if ref is None:
        logger.warning("Image attachment missing from local store: {}", sha256)
        return None
    if ref.kind != "image":
        return None
    prefix = f"data:{ref.content_type};base64,"
    if max_inline_data_url_bytes is not None:
        # Compute the FULL data-URL byte length (prefix + base64 payload),
        # because the returned string is the full URL — the cap parameter's
        # contract is "max bytes the caller will inline", not "max base64
        # payload chars". Exact base64 length: ceil(N / 3) * 4.
        b64_len = ((ref.size + 2) // 3) * 4
        if len(prefix) + b64_len > max_inline_data_url_bytes:
            return None
    data = Path(ref.path).read_bytes()
    b64 = base64.b64encode(data).decode("ascii")
    return f"{prefix}{b64}"


def _redact_home(path: str) -> str:
    """Replace the user home prefix with ``~/`` so absolute paths
    embedded in placeholder text don't leak OS account names to remote
    LLM providers. ``C:\\Users\\alice\\.workpilot\\...`` → ``~/.workpilot/...``.

    Uses ``os.path.commonpath`` rather than a raw ``startswith`` so
    sibling paths that merely share a prefix (e.g. ``/home/alice2/...``
    when home is ``/home/alice``) are NOT redacted, and so Windows
    case-insensitivity is handled via ``os.path.normcase``. Falls
    through unchanged when the path doesn't live under the detected
    home directory or when normalization fails.
    """
    try:
        home = str(Path.home())
    except (RuntimeError, OSError):
        return path
    if not home:
        return path
    try:
        normalized_home = os.path.normcase(os.path.normpath(home))
        normalized_path = os.path.normcase(os.path.normpath(path))
    except (TypeError, ValueError, OSError):
        return path
    try:
        if os.path.commonpath([normalized_path, normalized_home]) != normalized_home:
            return path
    except ValueError:
        # commonpath raises on different drives (Windows) or mixed
        # absolute/relative paths — treat as "not under home".
        return path
    rel = os.path.relpath(path, home)
    if rel == ".":
        return "~"
    return f"~/{rel.replace(os.sep, '/')}"


def attachment_metadata_text(
    att_meta: dict[str, Any] | str,
    *,
    header: str = "[Attachment not inlined — too large for LLM body cap]",
) -> str:
    """Render a metadata-only placeholder for an attachment that won't inline.

    Used by the LLM-bound 4-gate guard at two call sites — pass the
    matching ``header`` so the LLM sees the actual reason:

      * Gate 1 (dedupe — same sha already inlined this request)
      * Gate 2 (per-image cap — single image too large; default header)

    Gate 3 (cumulative body budget) uses its own short inline
    placeholder string — it operates after the original sha → data-URL
    resolution is done and doesn't carry the metadata needed to
    populate the body lines below.

    The body lines (name, size, sha, local_path, url) are identical
    across cases so the agent can use the local_path with the
    filesystem tool when downsampling or vision-summary preprocessing
    lands (see GitHub issue #498). ``local_path`` is **redacted**
    against the user's home directory (``~/.workpilot/...``) so the
    placeholder doesn't leak the user's OS account name to the remote
    LLM provider.

    Accepts either a session-style ``_attachments`` entry (dict with
    ``sha256`` / ``size`` / ``content_type`` / ``name`` / ``kind``) or a
    bare sha256 string (looks up via :func:`load_ref`).
    """
    if isinstance(att_meta, str):
        ref = load_ref(att_meta)
        if ref is None:
            return f"[Attachment missing — sha256={att_meta}]"
        sha = att_meta
        size = ref.size
        ct = ref.content_type
        name = ref.name or sha[:12]
        path = _redact_home(str(ref.path))
    else:
        sha = str(att_meta.get("sha256") or "?")
        size = int(att_meta.get("size") or 0)
        ct = str(att_meta.get("content_type") or "application/octet-stream")
        name = str(att_meta.get("name") or sha[:12])
        ref = load_ref(sha) if isinstance(sha, str) and len(sha) == 64 else None
        path = _redact_home(str(ref.path)) if ref else "(unknown)"

    # ``name`` originates from user-supplied filenames — strip newlines /
    # control chars / quote-injection chars before embedding so a crafted
    # filename can't break the placeholder structure or smuggle extra
    # prompt lines into the LLM. Reuses the existing tag sanitizer.
    safe_name = sanitize_name_for_tag(name)
    mib = size / (1024 * 1024)
    return (
        f"{header}\n"
        f"- name: {safe_name}\n"
        f"- type: {ct}\n"
        f"- size: {size:,} bytes ({mib:.2f} MiB)\n"
        f"- sha256: {sha}\n"
        f"- local_path: {path}\n"
        f"- url: {ATTACHMENT_URL_SCHEME}{sha}"
    )


def load_as_text(sha256: str) -> str | None:
    """Read a text attachment and decode as UTF-8.

    Returns ``None`` for missing or non-text attachments, or on decode error
    (shouldn't happen for well-formed uploads — ``save_attachment`` rejects
    non-UTF-8 text).
    """
    ref = load_ref(sha256)
    if ref is None or ref.kind != "text":
        return None
    try:
        return Path(ref.path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        logger.warning("Failed to load text attachment {}: {}", sha256, exc)
        return None


def load_for_outbound(sha256: str) -> dict[str, Any] | None:
    """Load an attachment for outbound relay (agent → channel).

    Returns a dict matching the ``OutboundAttachment`` wire shape (see
    ``design/cloud-gateway/attachments.md`` §4.5) — ``sha256``,
    ``content_type``, ``size``, ``kind``, ``name``, ``bytes_b64`` —
    or ``None`` when the sha is not in the local store.

    Bytes are read + base64-encoded inline; the channel renderer (Teams
    adaptive-card Image, Web Chat <img>) decodes them without a separate
    round-trip to the client.
    """
    ref = load_ref(sha256)
    if ref is None:
        return None
    try:
        data = Path(ref.path).read_bytes()
    except OSError as exc:
        logger.warning("Failed to read outbound attachment {}: {}", sha256, exc)
        return None
    return {
        "sha256": ref.sha256,
        "content_type": ref.content_type,
        "size": ref.size,
        "kind": ref.kind,
        "name": ref.name,
        "bytes_b64": base64.b64encode(data).decode("ascii"),
    }


# These constants are still expressed as **base64 budgets** because the
# only consumer that actually base64-encodes is the Teams Bot Framework
# ``data:`` URI builder (mandated by Bot Connector REST). The WSS
# transport itself uses raw bytes in WPAB binary frames (each attachment
# ships as its own WSS Binary message; bytes never share an envelope
# with the JSON control frame). For the binary-frame paths we derive the
# raw cap on demand (``MAX_OUTBOUND_*_B64 * 3 // 4``), see
# :func:`resolve_outbound_for_binary`.
#
# Per-attachment cap matches the gateway-side
# ``TeamsReplyService.MaxInlineAttachmentBase64`` — empirically validated
# against Teams's renderer 2026-04-25 (see scripts/teams_inline_image_probe.py).
# Cumulative cap bounds the total base64 we'll inline into a single
# Teams activity (HTTP-body protection on the Bot Connector POST).
MAX_OUTBOUND_ATTACHMENT_B64 = 16 * 1024 * 1024  # 16 MiB base64 ≈ 12 MiB raw
MAX_OUTBOUND_CUMULATIVE_B64 = 24 * 1024 * 1024  # 24 MiB cumulative across one activity


def resolve_outbound_refs(
    attachments: Any,
) -> tuple[list[dict[str, Any]] | None, list[str]]:
    """Resolve outbound attachment refs to the on-wire shape.

    Accepts either a list of sha256 strings (looked up via
    ``load_for_outbound``) or pre-resolved dicts (passed through with
    light normalization — useful for tests and callers that already
    hold the bytes). Missing sha refs are silently skipped (with a log
    warning) — the store may have been GC'd or the caller passed a
    bogus sha, and we don't want to echo raw sha IDs back to the user.

    Enforces per-attachment and cumulative base64 caps so a large image
    (or batch) can't overflow the negotiated WSS frame size. **Only
    size-cap drops** are returned as ``[attachment dropped: NAME —
    reason]`` strings the caller can inject into the text so the user
    sees what was skipped for size reasons.

    Shared by ``CloudChannel`` and ``WebChannel``; see
    ``design/cloud-gateway/attachments.md`` §4.5.
    """
    if not attachments:
        return None, []
    # Defensive: reject unexpected types (e.g. a caller passing a single
    # sha string or a dict by mistake). Without this, ``for item in
    # attachments`` would iterate characters / dict keys and produce
    # confusing per-char warnings.
    if not isinstance(attachments, (list, tuple)):
        logger.warning(
            "resolve_outbound_refs: expected list/tuple, got {}",
            type(attachments).__name__,
        )
        return None, []

    from workpilot.utils.helpers import ellipsize

    resolved: list[dict[str, Any]] = []
    drop_notes: list[str] = []
    cumulative = 0

    # Derive a raw-bytes cap from the base64 cap so we can reject oversize
    # attachments via a cheap ``ref.size`` check BEFORE reading + encoding.
    # base64 inflates by 4/3 (+ padding), so ``raw * 4/3 >= b64_cap`` ⇒
    # ``raw >= b64_cap * 3/4``. Anything above that is guaranteed oversize.
    raw_cap = MAX_OUTBOUND_ATTACHMENT_B64 * 3 // 4

    for item in attachments:
        loaded: dict[str, Any] | None
        if isinstance(item, str):
            # Pre-size-check via ``load_ref`` (stat-only, no read) so a
            # stored-but-oversize attachment doesn't trigger a multi-MB
            # read + base64 alloc just to be dropped by the cap below.
            ref = load_ref(item)
            if ref is None:
                logger.warning(
                    "Outbound attachment dropped — sha not in local store: {}",
                    ellipsize(item, 12),
                )
                continue
            if ref.size > raw_cap:
                name = ref.name or item[:8]
                drop_notes.append(f"[attachment dropped: {name} — too large for inline delivery]")
                logger.warning(
                    "Outbound attachment dropped (pre-read size cap) sha={} raw={}",
                    item[:12],
                    ref.size,
                )
                continue
            loaded = load_for_outbound(item)
            if loaded is None:
                # Race: file vanished between stat and read. Treat as missing.
                logger.warning(
                    "Outbound attachment dropped — sha not in local store: {}",
                    ellipsize(item, 12),
                )
                continue
        elif isinstance(item, dict) and "sha256" in item:
            # Dict refs fall into two shapes:
            #   * **already carrying ``bytes_b64``** — e.g. a producer that
            #     pre-encoded, or our own ``load_for_outbound`` result
            #     being re-entered. Pass through, just strip None-valued
            #     keys so the .NET side's ``DefaultIgnoreCondition.WhenWritingNull``
            #     contract stays clean.
            #   * **ref-only** (sha + content_type + size + kind [+ name]) —
            #     produced by the markdown-hoist pipeline in
            #     ``extract_outputs``, where bytes live on disk but haven't
            #     been base64-encoded yet. Resolve from disk now; only
            #     preserve the producer-supplied ``name`` (download
            #     filename) — content_type/size/kind always come from
            #     fresh disk metadata so a buggy/malicious producer can't
            #     poison the wire type (e.g. mislabel a PNG as text/plain).
            if item.get("bytes_b64"):
                loaded = {k: v for k, v in item.items() if v is not None}
            else:
                # Same stat-only pre-check as the sha-string branch:
                # ``save_attachment`` allows images up to ``MAX_IMAGE_BYTES``
                # (32 MiB) — if the producer-referenced store file is over
                # the outbound cap, skip the 32 MiB read + 43 MiB base64
                # alloc that ``load_for_outbound`` would do. Use the
                # authoritative on-disk size, not producer-supplied
                # ``item.get("size")`` (could be wrong or absent).
                sha = str(item["sha256"])
                ref = load_ref(sha)
                if ref is None:
                    logger.warning(
                        "Outbound attachment dropped — sha not in local store: {}",
                        ellipsize(sha, 12),
                    )
                    continue
                if ref.size > raw_cap:
                    name = item.get("name") or ref.name or sha[:8]
                    drop_notes.append(
                        f"[attachment dropped: {name} — too large for inline delivery]"
                    )
                    logger.warning(
                        "Outbound attachment dropped (pre-read size cap) sha={} raw={}",
                        sha[:12],
                        ref.size,
                    )
                    continue
                fresh = load_for_outbound(sha)
                if fresh is None:
                    # Race: file vanished between stat and read.
                    logger.warning(
                        "Outbound attachment dropped — sha not in local store: {}",
                        ellipsize(sha, 12),
                    )
                    continue
                loaded = fresh
                producer_name = item.get("name")
                if producer_name:
                    loaded["name"] = producer_name
        else:
            continue

        b64_len = len(loaded.get("bytes_b64") or "")
        name = loaded.get("name") or str(loaded.get("sha256", ""))[:8]
        if b64_len > MAX_OUTBOUND_ATTACHMENT_B64:
            drop_notes.append(f"[attachment dropped: {name} — too large for inline delivery]")
            logger.warning(
                "Outbound attachment dropped (per-attachment cap) sha={} b64_len={}",
                str(loaded.get("sha256", ""))[:12],
                b64_len,
            )
            continue
        if cumulative + b64_len > MAX_OUTBOUND_CUMULATIVE_B64:
            drop_notes.append(f"[attachment dropped: {name} — frame payload budget]")
            logger.warning(
                "Outbound attachment dropped (cumulative cap) sha={} cumulative={} b64_len={}",
                str(loaded.get("sha256", ""))[:12],
                cumulative,
                b64_len,
            )
            continue
        resolved.append(loaded)
        cumulative += b64_len

    return (resolved or None), drop_notes


def resolve_outbound_for_binary(
    attachments: Any,
) -> tuple[
    list[dict[str, Any]] | None,
    list[Callable[[], AsyncIterable[bytes]]],
    list[str],
]:
    """Resolve outbound refs into ``(metadata_list, stream_factories, drop_notes)``.

    Streaming companion to :func:`resolve_outbound_refs`. Returns:
      * ``metadata_list`` — list of metadata-only dicts (no bytes):
        ``{sha256, content_type, size, kind, name?}``. Inlined into the
        JSON control frame.
      * ``stream_factories`` — list of **callables** (one per attachment,
        in the same order as ``metadata_list``). Each callable, when
        invoked, returns a fresh async iterable yielding the WPAB header
        bytes first, then 64 KiB chunks read from disk on demand. We
        return factories (not iterables directly) so a multi-subscriber
        sender (e.g. self-hosted with two browser tabs open for the
        same user) can build a fresh stream per subscriber — async
        iterators are single-pass.
      * ``drop_notes`` — same as the legacy resolver: human-readable
        notes for size-cap drops.

    Used by the binary-frame transport (``WebChannel`` self-hosted,
    ``CloudChannel`` Cloud). The legacy :func:`resolve_outbound_refs`
    is retained for paths still on JSON-with-base64.

    Cap semantics: ``MAX_OUTBOUND_ATTACHMENT_B64`` and
    ``MAX_OUTBOUND_CUMULATIVE_B64`` are still expressed as base64-budget
    values (because the only consumer that does any base64 — the Teams
    `data:` URI builder — uses those budgets directly). Here we derive
    the raw-byte cap that fits within that base64 budget via the usual
    4/3 inflation factor (``raw <= b64_budget * 3 / 4``); the function
    then enforces caps in raw bytes. Net effect: an attachment that
    would have been accepted under the old JSON+base64 transport is
    accepted here too, no behavioural drift across the migration.

    Pre-read size check is done from ``ref.size`` (stat) so an oversize
    attachment is dropped without ever opening the file.
    """
    from workpilot.security.binary_frame import stream_attachment_data

    if not attachments:
        return None, [], []
    if not isinstance(attachments, (list, tuple)):
        logger.warning(
            "resolve_outbound_for_binary: expected list/tuple, got {}",
            type(attachments).__name__,
        )
        return None, [], []

    from workpilot.utils.helpers import ellipsize

    metadata: list[dict[str, Any]] = []
    factories: list[Callable[[], AsyncIterable[bytes]]] = []
    drop_notes: list[str] = []
    cumulative_raw = 0

    per_raw_cap = MAX_OUTBOUND_ATTACHMENT_B64 * 3 // 4
    cum_raw_cap = MAX_OUTBOUND_CUMULATIVE_B64 * 3 // 4

    for item in attachments:
        sha: str | None = None
        producer_name: str | None = None

        if isinstance(item, str):
            sha = item
        elif isinstance(item, dict) and "sha256" in item:
            sha = str(item["sha256"])
            producer_name = item.get("name") or None
        else:
            continue

        ref = load_ref(sha)
        if ref is None:
            logger.warning(
                "Outbound attachment dropped — sha not in local store: {}",
                ellipsize(sha, 12),
            )
            continue

        if ref.size > per_raw_cap:
            display = producer_name or ref.name or sha[:8]
            drop_notes.append(f"[attachment dropped: {display} — too large for inline delivery]")
            logger.warning(
                "Outbound attachment dropped (per-attachment cap) sha={} raw={}",
                sha[:12],
                ref.size,
            )
            continue
        if cumulative_raw + ref.size > cum_raw_cap:
            display = producer_name or ref.name or sha[:8]
            drop_notes.append(f"[attachment dropped: {display} — frame payload budget]")
            logger.warning(
                "Outbound attachment dropped (cumulative cap) sha={} cumulative_raw={} raw={}",
                sha[:12],
                cumulative_raw,
                ref.size,
            )
            continue

        # Narrow types for the closure: post-checks above guarantee these
        # are non-None and the right shape. mypy can't propagate that
        # through the closure capture, so re-bind locally.
        # Use ``ref.sha256`` (canonical lowercase) rather than the
        # producer-supplied ``sha`` so the JSON metadata, the WPAB
        # binary header, and the browser's object-URL cache key all
        # agree even when a producer passes an upper- or mixed-case
        # digest.
        sha_str: str = ref.sha256
        ct_str: str = ref.content_type
        path_str: str = ref.path
        size_int: int = ref.size

        meta: dict[str, Any] = {
            "sha256": sha_str,
            "content_type": ct_str,
            "size": size_int,
            "kind": ref.kind,
        }
        display_name = producer_name or ref.name
        if display_name:
            meta["name"] = display_name
        metadata.append(meta)

        # Capture by default-arg to bind names for the closure.
        def _factory(
            *,
            _sha: str = sha_str,
            _ct: str = ct_str,
            _path: str = path_str,
            _name: str | None = display_name,
            _size: int = size_int,
        ) -> AsyncIterator[bytes]:
            return stream_attachment_data(
                sha256=_sha,
                content_type=_ct,
                path=_path,
                name=_name,
                size=_size,
            )

        factories.append(_factory)
        cumulative_raw += size_int

    return (metadata or None), factories, drop_notes


def gc_unreferenced(active_sha256s: set[str], older_than: timedelta = timedelta(days=7)) -> int:
    """Delete attachment files not present in *active_sha256s* and older than the cutoff."""
    dir_ = attachments_dir()
    if not dir_.is_dir():
        return 0
    cutoff = datetime.now(UTC) - older_than
    removed = 0
    for p in dir_.iterdir():
        if not p.is_file():
            continue
        sha = p.stem
        if sha in active_sha256s:
            continue
        try:
            mtime = datetime.fromtimestamp(p.stat().st_mtime, tz=UTC)
        except OSError:
            continue
        if mtime > cutoff:
            continue
        try:
            p.unlink()
            removed += 1
        except OSError as exc:
            logger.warning("Failed to GC attachment {}: {}", p, exc)
    return removed
