"""
Relay token validator — verifies tokens forwarded by the Cloud Gateway.

Supports:
  - source == "cloud_webchat": per-message HMAC content signing (E2E)
  - auth_type == "github": validates opaque token via cached GET /user
  - auth_type == "entra": Entra JWT validation (admin_request + future Teams SSO)
  - auth_type is None: accept (transition mode)

See design/cloud-gateway/token-passthrough.md for the full design.
"""

from __future__ import annotations

import base64
import hashlib
import hmac as hmac_mod
import re
import secrets
import time
from hashlib import sha256
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from workpilot.channels.cloud import CloudChannel

# Cache TTL for GitHub /user validation results (seconds).
_GITHUB_CACHE_TTL = 600  # 10 minutes
_GITHUB_CACHE_MAX = 100

# Maximum signing keys stored (per Python client instance).
_SIGNING_KEY_MAX = 50

# JWKS cache: url → (monotonic_time, PyJWKClient).  Shared across instances.
_jwks_cache: dict[str, tuple[float, Any]] = {}
_JWKS_TTL = 3600  # 1 hour

# Valid content_format values (defense-in-depth against \n injection).
_VALID_CONTENT_FORMATS = frozenset({"text", "html", "markdown"})


_SHA256_HEX_RE = re.compile(r"^[0-9a-f]{64}$")


def _canonical_attachments(attachments: Any) -> str:
    """Canonical form of ``attachments[]`` for HMAC-signed payloads.

    Sorted lower-case sha256 values comma-joined — comma is safe because
    valid shas are 64-char hex. Non-hex values are dropped (they can't be
    real refs anyway, and accepting them would let a malformed frame
    destabilise the signed payload). Returns empty string when the frame
    has no valid attachments, which produces the original 5-field signed
    payload (backward-compatible with pre-attachment browser bundles).

    Browser and Python MUST compute identical canonical strings or the
    signature fails. Keep this in sync with the SPA's
    ``canonicalAttachments()`` helper in ``web/src/hooks/useWebSocket.ts``.
    """
    if not isinstance(attachments, list) or not attachments:
        return ""
    shas: list[str] = []
    for a in attachments:
        if not isinstance(a, dict):
            continue
        sha = a.get("sha256")
        if isinstance(sha, str):
            sha = sha.lower()
            if _SHA256_HEX_RE.fullmatch(sha):
                shas.append(sha)
    shas.sort()
    return ",".join(shas)


class RelayValidator:
    """Validates tokens forwarded by the Cloud Gateway relay.

    Holds a back-reference to the owning CloudChannel so that identity
    (``_local_oid`` / ``_local_tid`` / ``_local_github_id``) is always
    read dynamically — if the user re-authenticates with a different
    account, the validator picks up the new identity automatically.
    """

    def __init__(self, channel: CloudChannel, *, require: bool = False) -> None:
        self._channel = channel
        self._require = require
        # Cache: sha256(token)[:16] → { "id": str, "verified_at": float }
        self._github_cache: dict[str, dict[str, Any]] = {}
        # WebChat E2E signing keys: key_id → (oid, key_bytes, last_seq)
        self._signing_keys: dict[str, tuple[str, bytes, int]] = {}

    def validate_message(self, frame: dict[str, Any]) -> bool:
        """Validate a message or approval_response frame.

        Returns True if the frame should be accepted, False to reject.
        """
        # Route WebChat messages to HMAC content signing validation.
        meta = frame.get("metadata")
        source = meta.get("source", "") if isinstance(meta, dict) else ""
        if source == "cloud_webchat":
            return self.validate_webchat(frame)

        auth_type = frame.get("auth_type")

        if auth_type == "github":
            return self._validate_github(frame)

        # Teams SSO: auth_type == "entra" with Entra id_token.
        # When present, validate JWKS signature + OID binding.
        if auth_type == "entra":
            return self._validate_entra_message(frame)

        # Teams without SSO (auth_type is None, source == "cloud_teams"):
        # accept — require_relay_auth only enforces WebChat + admin_request.
        # Teams E2E auth requires SSO opt-in; until then, messages pass through.
        if source == "cloud_teams":
            return True

        # Unknown source with no auth — transition accepts, enforce rejects.
        if self._require:
            logger.warning("Rejecting relay message with missing/unknown auth_type={!r}", auth_type)
            return False
        return True

    def validate_webchat(self, frame: dict[str, Any]) -> bool:
        """Validate WebChat E2E HMAC content signature.

        Checks: key lookup → monotonic seq → timestamp freshness →
        content_format allowlist → HMAC verify → OID match → sender_id overwrite.
        """
        auth_sig = frame.get("auth_sig")
        auth_ts = frame.get("auth_ts")
        auth_seq = frame.get("auth_seq")
        auth_key_id = frame.get("auth_key_id")

        # Use explicit None/empty checks (not truthiness).
        # Note: SPA seq starts at 1 (++seqRef), so "0" never appears in practice.
        def _missing(v: Any) -> bool:
            return v is None or (isinstance(v, str) and not v.strip())

        if _missing(auth_sig) or _missing(auth_ts) or _missing(auth_seq) or _missing(auth_key_id):
            if self._require:
                logger.warning("WebChat auth: missing auth fields — rejected (enforce mode)")
                return False
            logger.debug("WebChat auth: missing auth fields — accepted (transition)")
            return True

        # 1. Key lookup
        entry = self._signing_keys.get(str(auth_key_id))
        if not entry:
            logger.warning("WebChat auth: unknown key_id {}", auth_key_id)
            return False
        oid, key_bytes, last_seq = entry

        # 2. Replay protection: monotonic sequence
        try:
            seq = int(auth_seq)  # type: ignore[arg-type]
        except (ValueError, TypeError):
            logger.warning("WebChat auth: invalid auth_seq")
            return False
        if seq <= last_seq:
            logger.warning("WebChat auth: replayed seq {} <= {}", seq, last_seq)
            return False

        # 3. Freshness
        try:
            ts = int(auth_ts)  # type: ignore[arg-type]
        except (ValueError, TypeError):
            logger.warning("WebChat auth: invalid auth_ts")
            return False
        if abs(time.time() - ts) > 30:
            logger.warning("WebChat auth: timestamp too old (delta={}s)", abs(time.time() - ts))
            return False

        # 4. content_format allowlist
        content_format = frame.get("content_format", "text")
        if content_format not in _VALID_CONTENT_FORMATS:
            logger.warning("WebChat auth: invalid content_format {}", content_format)
            return False

        # 5. HMAC verify (collision-free: \n separator, content is last)
        content = frame.get("content", "")
        # Attachments (optional) bind the sha256 refs into the signed
        # payload so a compromised gateway can't swap the user's sha list
        # for other shas that happen to exist on the client's local
        # attachment store (e.g. pointing to a sensitive doc the user
        # uploaded in an earlier turn). Canonical form: sorted shas
        # comma-joined — comma is safe (shas are lowercase hex). Empty
        # attachments collapse to the original 5-field payload for
        # backward compat with pre-attachment browser bundles.
        atts_canonical = _canonical_attachments(frame.get("attachments"))
        if atts_canonical:
            payload = f"{auth_key_id}\n{auth_seq}\n{auth_ts}\n{content_format}\n{atts_canonical}\n{content}"
        else:
            payload = f"{auth_key_id}\n{auth_seq}\n{auth_ts}\n{content_format}\n{content}"
        expected = hmac_mod.new(key_bytes, payload.encode(), sha256).digest()
        try:
            actual = base64.b64decode(str(auth_sig), validate=True)
        except Exception:
            logger.warning("WebChat auth: invalid base64 auth_sig")
            return False
        if not hmac_mod.compare_digest(expected, actual):
            logger.warning("WebChat auth: HMAC mismatch for key_id {}", auth_key_id)
            return False

        # 6. OID match + sender_id overwrite
        if oid != frame.get("sender_id"):
            logger.warning(
                "WebChat auth: OID mismatch (key={}, sender={})", oid, frame.get("sender_id")
            )
            return False
        frame["sender_id"] = oid  # overwrite with key-store OID

        # 7. Update sequence watermark + refresh LRU position (move to end)
        kid = str(auth_key_id)
        del self._signing_keys[kid]
        self._signing_keys[kid] = (oid, key_bytes, seq)
        return True

    def _validate_entra_message(self, frame: dict[str, Any]) -> bool:
        """Validate a Teams SSO Entra id_token on a message frame.

        Verifies JWKS signature + aud + iss + exp, then checks that the
        OID in the token matches ``sender_id`` (user-bound identity).
        """
        token = frame.get("auth_token")
        if not isinstance(token, str) or not token:
            if self._require:
                logger.warning("Entra auth: missing auth_token — rejected (enforce mode)")
                return False
            logger.debug("Entra auth: missing auth_token — accepted (transition)")
            return True

        claims = self._decode_entra(token)
        if claims is None:
            logger.warning("Entra auth: JWT validation failed")
            return False

        # User-bound identity: OID in signed JWT must match sender_id.
        oid = claims.get("oid")
        if oid != frame.get("sender_id"):
            logger.warning(
                "Entra auth: oid mismatch (jwt={}, sender={})",
                oid,
                frame.get("sender_id"),
            )
            return False
        return True

    def create_signing_key(self, oid: str) -> tuple[str, str]:
        """Generate a signing key for WebChat HMAC.

        Returns ``(base64_key, key_id)``.
        """
        key_bytes = secrets.token_bytes(32)
        key_id = f"wk_{secrets.token_hex(8)}"
        self._signing_keys[key_id] = (oid, key_bytes, 0)
        # Evict oldest if over limit
        if len(self._signing_keys) > _SIGNING_KEY_MAX:
            oldest = next(iter(self._signing_keys))
            del self._signing_keys[oldest]
        return base64.b64encode(key_bytes).decode(), key_id

    def validate_admin(self, frame: dict[str, Any]) -> str | None:
        """Validate an admin_request frame.

        Returns the caller OID on success, None to reject.
        Verifies the Entra JWT if ``auth_token`` is present.
        """
        token = frame.get("auth_token")
        caller_oid = frame.get("caller_oid")

        if not isinstance(token, str) or not token:
            if self._require:
                logger.warning("Admin auth: missing auth_token — rejected (enforce mode)")
                return None
            # Transition mode: trust declared caller_oid (backward compat).
            return caller_oid if isinstance(caller_oid, str) and caller_oid else "unknown"

        # Validate Entra JWT
        claims = self._decode_entra(token)
        if claims is None:
            # Could be JWT invalid OR local config not ready (tid/client_id missing).
            # In transition mode, fall back to declared caller_oid.
            if self._require:
                logger.warning("Admin auth: Entra JWT validation failed — rejected")
                return None
            logger.warning("Admin auth: Entra JWT validation failed — accepted (transition)")
            return caller_oid if isinstance(caller_oid, str) and caller_oid else "unknown"

        oid = claims.get("oid")
        tid = claims.get("tid")

        # Tenant must match the local user's tenant.
        local_tid = self._channel._local_tid
        if local_tid and tid != local_tid:
            logger.warning("Admin auth: tid mismatch (token={}, local={})", tid, local_tid)
            return None

        # OID in token must match the declared caller_oid (if provided).
        if caller_oid and oid != caller_oid:
            logger.warning("Admin auth: oid mismatch (token={}, declared={})", oid, caller_oid)
            return None

        return oid

    def _decode_entra(self, token: str) -> dict[str, Any] | None:
        """Verify an Entra ID JWT via JWKS.

        Returns decoded claims on success, None on failure.
        Uses the local tenant ID for issuer validation.
        Accepts ``client_id`` and ``bot_app_id`` as valid audiences —
        SSO tokens may use either app registration.
        """
        local_tid = self._channel._local_tid
        client_id = self._channel._client_id
        if not local_tid or not client_id:
            logger.debug("Entra JWT: tid or client_id not available — cannot validate")
            return None
        try:
            import jwt as pyjwt

            bot_app_id = getattr(self._channel, "_bot_app_id", "")
            audiences = [aud for aud in (client_id, bot_app_id) if aud]
            jwks_url = f"https://login.microsoftonline.com/{local_tid}/discovery/v2.0/keys"
            jwks_client = _get_jwks(jwks_url)
            signing_key = jwks_client.get_signing_key_from_jwt(token)
            return pyjwt.decode(  # type: ignore[no-any-return]
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=audiences,
                issuer=f"https://login.microsoftonline.com/{local_tid}/v2.0",
                leeway=120,
            )
        except Exception as exc:
            logger.debug("Entra JWT validation failed: {}", exc)
            return None

    def _validate_github(self, frame: dict[str, Any]) -> bool:
        """Validate a GitHub opaque token via cached GET /user."""
        # Early reject if no registered identity — avoids wasted API call.
        local_github_id = self._channel._local_github_id
        if not local_github_id:
            logger.warning("GitHub auth: no registered identity to verify against")
            return False

        token = frame.get("auth_token")
        sender_id = frame.get("sender_id")
        if not isinstance(token, str) or not isinstance(sender_id, str):
            logger.warning("GitHub auth: missing auth_token or sender_id")
            return False

        # Check cache first
        cache_key = hashlib.sha256(token.encode()).hexdigest()[:16]
        cached = self._github_cache.get(cache_key)
        if cached and time.time() - cached["verified_at"] < _GITHUB_CACHE_TTL:
            github_id = cached["id"]
        else:
            # Call GitHub API (blocking — runs in the async receive loop,
            # but validation is fast with a warm cache; cold calls are
            # infrequent since WSS sessions are long-lived).
            from workpilot.security.github_auth import get_github_user

            user = get_github_user(token)
            if user is False:
                # Definitive failure (401) — cache to avoid repeated API calls.
                logger.warning("GitHub auth: token invalid/revoked")
                self._github_cache[cache_key] = {
                    "id": "",
                    "verified_at": time.time(),
                }
                return False
            if not user:
                # Transient failure (network/5xx) — don't cache, retry next time.
                logger.warning("GitHub auth: token validation failed (transient)")
                return False

            github_id = str(user.get("id", ""))
            # Cache the result
            self._github_cache[cache_key] = {
                "id": github_id,
                "verified_at": time.time(),
            }
            # Evict oldest entries if cache is too large
            if len(self._github_cache) > _GITHUB_CACHE_MAX:
                oldest_key = min(
                    self._github_cache, key=lambda k: self._github_cache[k]["verified_at"]
                )
                del self._github_cache[oldest_key]

        # Check 1: sender_id matches token's actual user
        if github_id != sender_id:
            logger.warning(
                "GitHub auth: sender_id mismatch (token={}, frame={})",
                github_id,
                sender_id,
            )
            return False

        # Check 2: token belongs to the registered user.
        if github_id != local_github_id:
            logger.warning(
                "GitHub auth: token user {} != registered user {}",
                github_id,
                local_github_id,
            )
            return False

        return True


def _get_jwks(url: str) -> Any:
    """Get (or cache) a PyJWKClient for the given JWKS URL."""
    import jwt as pyjwt

    now = time.monotonic()
    cached = _jwks_cache.get(url)
    if cached and (now - cached[0]) < _JWKS_TTL:
        return cached[1]
    client = pyjwt.PyJWKClient(url)
    _jwks_cache[url] = (now, client)
    return client
