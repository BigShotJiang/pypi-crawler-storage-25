"""WPAB binary frame codec — used to transport raw attachment bytes over WSS.

Wire format (single WebSocket Binary frame):

    [4 bytes]   magic 'WPAB' = 0x57 0x50 0x41 0x42
    [4 bytes]   header_len (little-endian uint32)
    [N bytes]   JSON header (UTF-8)
    [M bytes]   raw payload bytes

The JSON header is structured but free-form per ``type``:

  * ``attachment_data``  — outbound image bytes accompanying a
    ``response`` / ``push`` JSON control frame. Header carries
    ``sha256``, ``content_type``, ``size``, optionally ``request_id``.
  * ``attachment_upload`` — inbound image bytes (browser/Teams →
    gateway → Python client). Header carries ``request_id``,
    ``content_type``, ``size``, optionally ``name``, ``source``.
  * ``attachment_fetched`` — Python client's reply to a gateway
    ``attachment_fetch`` request. Header carries ``request_id``,
    ``content_type``, ``size``.

Receivers correlate to a preceding JSON control frame by ``sha256``
(outbound) or ``request_id`` (inbound / fetch reply). WSS guarantees
TCP ordering on a single connection, so the control frame always
arrives before the binary that follows it from the same sender.

Replaces the previous "JSON-with-base64" wire convention. See
``design/cloud-gateway/binary-attachment-frames.md`` for full design.
"""

from __future__ import annotations

import asyncio
import json
import struct
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

# 'WPAB' — WorkPilot Attachment Blob.
MAGIC: bytes = b"WPAB"

# Fixed wire preamble: 4-byte magic + 4-byte little-endian uint32
# header length. Public so peers (``workpilot.web.server`` drain cap)
# can size buffers as ``payload + MAX_HEADER_LEN + PREAMBLE_LEN``
# without re-deriving the framing.
PREAMBLE_LEN: int = 8

# Sentinel header sizes — defensive limits on a hostile peer.
# Public so peers (e.g. ``workpilot.web.server`` deriving its
# per-stream drain cap) can size their buffers off the codec's
# advertised maximum and stay in sync if it ever changes.
MAX_HEADER_LEN = 64 * 1024  # 64 KiB header is plenty for any metadata


class BinaryFrameError(ValueError):
    """Raised when a buffer doesn't decode as a valid WPAB binary frame."""


def encode_header(header: dict[str, Any]) -> bytes:
    """Encode just the WPAB preamble + header (no payload bytes).

    Used by the streaming sender — pass this as the first chunk of a
    WSS message, then yield the raw payload chunks. The receiver
    re-assembles all chunks before decoding (the framing across
    fragments is invisible at the WPAB layer).
    """
    header_json = json.dumps(header, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(header_json) > MAX_HEADER_LEN:
        raise BinaryFrameError(f"header too large: {len(header_json)} bytes (max {MAX_HEADER_LEN})")
    return MAGIC + struct.pack("<I", len(header_json)) + header_json


def encode(header: dict[str, Any], raw: bytes) -> bytes:
    """Serialize a header + raw byte payload into a WPAB binary frame.

    The header is JSON-encoded UTF-8; ``raw`` is appended verbatim.
    Equivalent to ``encode_header(header) + raw`` — convenient for
    in-memory frames; for streaming use
    :func:`stream_file_with_header` instead.
    """
    return encode_header(header) + raw


def decode(buf: bytes) -> tuple[dict[str, Any], bytes]:
    """Parse a WPAB binary frame into ``(header_dict, raw_bytes)``.

    Raises ``BinaryFrameError`` if the buffer is too short, the magic
    prefix doesn't match, the header length is over-cap, or the JSON
    header is malformed.
    """
    if len(buf) < 8:
        raise BinaryFrameError(f"frame too short: {len(buf)} bytes (need ≥ 8)")
    if buf[:4] != MAGIC:
        raise BinaryFrameError(f"bad magic: {buf[:4]!r} (expected {MAGIC!r})")
    header_len = struct.unpack("<I", buf[4:8])[0]
    if header_len > MAX_HEADER_LEN:
        raise BinaryFrameError(f"header_len {header_len} exceeds cap {MAX_HEADER_LEN}")
    if len(buf) < 8 + header_len:
        raise BinaryFrameError(
            f"truncated frame: have {len(buf)} bytes, need {8 + header_len} for header"
        )
    try:
        header = json.loads(buf[8 : 8 + header_len].decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise BinaryFrameError(f"malformed JSON header: {exc}") from exc
    if not isinstance(header, dict):
        raise BinaryFrameError(f"header not a dict: {type(header).__name__}")
    raw = buf[8 + header_len :]
    return header, raw


def is_wpab(buf: bytes) -> bool:
    """Quick magic-prefix check without raising — useful for dispatch."""
    return len(buf) >= 4 and buf[:4] == MAGIC


# ── High-level helpers for the common frame types ──────────────────────────


def encode_attachment_data(
    sha256: str,
    content_type: str,
    raw: bytes,
    *,
    name: str | None = None,
) -> bytes:
    """Encode an outbound ``attachment_data`` frame (response/push image)."""
    header: dict[str, Any] = {
        "type": "attachment_data",
        "sha256": sha256,
        "content_type": content_type,
        "size": len(raw),
    }
    if name:
        header["name"] = name
    return encode(header, raw)


def encode_attachment_upload(
    request_id: str,
    content_type: str,
    raw: bytes,
    *,
    name: str | None = None,
    source: str | None = None,
) -> bytes:
    """Encode an inbound ``attachment_upload`` frame (gateway → Python client)."""
    header: dict[str, Any] = {
        "type": "attachment_upload",
        "request_id": request_id,
        "content_type": content_type,
        "size": len(raw),
    }
    if name:
        header["name"] = name
    if source:
        header["source"] = source
    return encode(header, raw)


def encode_attachment_fetched(
    request_id: str,
    content_type: str,
    raw: bytes,
    *,
    sha256: str | None = None,
) -> bytes:
    """Encode a fetch-by-sha reply frame (Python client → gateway)."""
    header: dict[str, Any] = {
        "type": "attachment_fetched",
        "request_id": request_id,
        "content_type": content_type,
        "size": len(raw),
    }
    if sha256:
        header["sha256"] = sha256
    return encode(header, raw)


# ── Streaming helpers (read-from-disk while sending over WSS) ──────────────


# Default chunk size for ``stream_file_with_header`` — 64 KiB balances
# syscall overhead (smaller chunks) against memory residency (larger
# chunks). Picked to match the WSS fragmentation behaviour of
# ``websockets`` so each ``yield`` lands as one WSS continuation frame.
_DEFAULT_STREAM_CHUNK_BYTES = 64 * 1024


async def stream_file_with_header(
    header: dict[str, Any],
    path: str | Path,
    *,
    chunk_size: int = _DEFAULT_STREAM_CHUNK_BYTES,
) -> AsyncIterator[bytes]:
    """Async generator yielding WPAB header bytes followed by file chunks.

    Pass the result to ``websockets.WebSocketClientProtocol.send`` (or
    ``server.send``) — the library accepts an async iterable and emits
    a fragmented binary message, with one WSS continuation frame per
    yield.

    With ``aiofiles`` installed (the ``[all]`` extra; default on the
    Cloud client), the file is read ``chunk_size`` (64 KiB) at a time
    and peak resident memory is bounded by that constant regardless of
    file size. Without ``aiofiles`` (core install only — typically the
    single-machine ``workpilot serve`` path), the fallback reads the
    whole file in one ``asyncio.to_thread`` call and yields it as a
    single chunk; peak memory equals the file size, but the read
    happens off the event loop so concurrent WSS sends don't stall.

    The receiver sees a single logical binary message; ``ws.recv()``
    returns the concatenated bytes. Fragmentation is invisible at the
    application layer.

    **Open-before-yield invariant.** The header is yielded only AFTER
    the source file is opened (or fully read in the no-aiofiles
    fallback). A failure to open / read therefore raises BEFORE any
    bytes hit the wire, so the receiver never sees a partial WPAB
    message; ``websockets.send`` propagates the exception cleanly and
    the producer (``CloudChannel._send_loop`` / ``_push_loop``) drops
    the bundle without a half-sent frame leaking onto the connection.
    """
    p = Path(path) if isinstance(path, str) else path
    try:
        import aiofiles  # type: ignore[import-not-found, import-untyped]
    except ImportError:
        # Synchronous fallback — read the whole file off the event loop
        # via a thread so a multi-MB read doesn't stall WSS sends. Hit
        # only when ``aiofiles`` isn't installed (Cloud client ships it
        # via the ``[all]`` extra); the single-machine ``workpilot serve``
        # path is the typical user. Read happens BEFORE we yield the
        # header so an OS error (file vanished, permission denied,
        # etc.) raises without putting bytes on the wire.
        body = await asyncio.to_thread(p.read_bytes)
        yield encode_header(header)
        yield body
        return

    # Open the file first; if open fails (race with delete, permission,
    # bad fd table), raise BEFORE any header bytes are emitted so the
    # receiver never sees a partial frame.
    async with aiofiles.open(p, "rb") as f:
        yield encode_header(header)
        while True:
            chunk: bytes = await f.read(chunk_size)
            if not chunk:
                return
            yield chunk


async def stream_attachment_data(
    sha256: str,
    content_type: str,
    path: str | Path,
    *,
    name: str | None = None,
    size: int | None = None,
    chunk_size: int = _DEFAULT_STREAM_CHUNK_BYTES,
) -> AsyncIterator[bytes]:
    """Stream an outbound ``attachment_data`` frame from a file on disk.

    Convenience wrapper over :func:`stream_file_with_header` that
    builds the right header for the response/push attachment case.
    """
    if size is None:
        size = Path(path).stat().st_size
    header: dict[str, Any] = {
        "type": "attachment_data",
        "sha256": sha256,
        "content_type": content_type,
        "size": size,
    }
    if name:
        header["name"] = name
    async for chunk in stream_file_with_header(header, path, chunk_size=chunk_size):
        yield chunk


async def stream_attachment_fetched(
    request_id: str,
    content_type: str,
    path: str | Path,
    *,
    sha256: str | None = None,
    size: int | None = None,
    chunk_size: int = _DEFAULT_STREAM_CHUNK_BYTES,
) -> AsyncIterator[bytes]:
    """Stream a fetch-by-sha reply frame from a file on disk."""
    if size is None:
        size = Path(path).stat().st_size
    header: dict[str, Any] = {
        "type": "attachment_fetched",
        "request_id": request_id,
        "content_type": content_type,
        "size": size,
    }
    if sha256:
        header["sha256"] = sha256
    async for chunk in stream_file_with_header(header, path, chunk_size=chunk_size):
        yield chunk
