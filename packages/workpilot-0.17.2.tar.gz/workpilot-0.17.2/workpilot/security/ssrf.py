"""
Shared SSRF (Server-Side Request Forgery) protection.

Validates URLs against private/reserved networks, blocked hostnames,
and DNS rebinding attacks. Used by BrowserTool, HttpRequestTool, and
WebFetchTool.

Enforcement is layered:

1. **URL invariants** — scheme must be http/https, no userinfo
   (``user:password@``), non-empty hostname. Enforced under **every**
   profile by ``check_url_invariants`` / ``enforce_url_safety`` — no
   approval can override them.
2. **DNS rebinding** — a hostname that resolves to a private/reserved IP
   is treated as an obfuscated SSRF attempt. Also enforced under every
   profile via ``check_dns_rebinding`` / ``enforce_url_safety``.
3. **Private-network direct addresses** — literal loopback / LAN IPs and
   blocked hostname suffixes. Profile-gated:
   - ``open`` / ``standard``: surfaced in ``assess_risk`` via
     ``screen_url_ssrf_sync`` as a severity-aware RiskScore (**7** for
     loopback, **9** for LAN / cloud metadata / enterprise-internal /
     other). The normal approval gate decides whether the call proceeds.
     In cron runs, elevation (+1) pushes a LAN score 9 to 10, which the
     policy table auto-rejects without prompting.
   - ``controlled`` / ``restricted``: hard-blocked at runtime via
     ``enforce_url_safety`` even if a user manages to approve. The cron
     score bump doesn't materially change behaviour here — the runtime
     hard-block fires before the policy table is consulted.
"""

from __future__ import annotations

import asyncio
import ipaddress
import socket
from typing import TYPE_CHECKING
from urllib.parse import urlparse

if TYPE_CHECKING:
    from workpilot.config.schema import SecurityProfile

# Loopback — this machine. Dev servers, local databases, etc. Scored 7:
# risky but contained to the user's own host; often a legitimate target.
_LOOPBACK_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
]
_LOOPBACK_HOSTNAMES = {"localhost"}
_LOOPBACK_HOSTNAME_SUFFIXES = (".localhost",)

# LAN / enterprise / cloud metadata. Scored 9: different machines, higher
# blast radius, includes the cloud-metadata credential-theft endpoint.
_LAN_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),  # link-local / cloud metadata
    ipaddress.ip_network("100.64.0.0/10"),  # carrier-grade NAT
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]
_LAN_HOSTNAMES = {"metadata.google.internal"}
_LAN_HOSTNAME_SUFFIXES = (".local", ".internal")

# Aggregate view — DNS rebinding and other checks that don't care about
# severity still need a single blocklist.
_BLOCKED_NETWORKS = _LOOPBACK_NETWORKS + _LAN_NETWORKS
_BLOCKED_HOSTNAMES = _LOOPBACK_HOSTNAMES | _LAN_HOSTNAMES
_BLOCKED_HOSTNAME_SUFFIXES = _LOOPBACK_HOSTNAME_SUFFIXES + _LAN_HOSTNAME_SUFFIXES

# Risk scores for SSRF hits by category — surfaced in assess_risk().
_SSRF_SCORE_LOOPBACK = 7
_SSRF_SCORE_LAN = 9
_SSRF_SCORE_OTHER = 9  # bad scheme, userinfo, missing host


def _classify_ip(
    addr: ipaddress.IPv4Address | ipaddress.IPv6Address,
) -> str | None:
    """Return 'loopback' / 'lan' / None for an IP address.

    Also handles IPv4-mapped IPv6 (e.g. ``::ffff:127.0.0.1``) so an
    attacker cannot bypass SSRF by wrapping a private IPv4 in IPv6.
    """
    if any(addr in net for net in _LOOPBACK_NETWORKS):
        return "loopback"
    if any(addr in net for net in _LAN_NETWORKS):
        return "lan"
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        mapped = addr.ipv4_mapped
        if any(mapped in net for net in _LOOPBACK_NETWORKS):
            return "loopback"
        if any(mapped in net for net in _LAN_NETWORKS):
            return "lan"
    return None


def _is_blocked_ip(addr: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    """Return True if *addr* falls within any blocked network."""
    return _classify_ip(addr) is not None


def check_url_invariants(url: str) -> str | None:
    """Fundamental URL invariants that apply under **every** security profile.

    Returns an error message, or ``None`` if the URL is structurally sound.
    These are not approval-gated — a ``file://`` or ``javascript:`` URL is
    never a legitimate HTTP target, and no amount of user approval should
    permit it at runtime. Called unconditionally from ``enforce_url_safety``
    so the scheme / userinfo / missing-host checks cannot be opted out of
    by picking the ``open`` or ``standard`` profile.
    """
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return f"URL scheme '{parsed.scheme}' not allowed (http/https only)"
    if parsed.username or parsed.password:
        return "URLs with user:password@ are not allowed"
    if not parsed.hostname:
        return "URL must include a hostname"
    return None


def screen_url_ssrf_sync(url: str) -> tuple[str, int] | None:
    """Synchronous SSRF checks (no DNS resolution).

    Returns ``(error_message, suggested_risk_score)`` if the URL fails a
    sync SSRF check, or ``None`` otherwise. The score distinguishes
    **loopback** (7 — same machine; often a dev server) from **LAN /
    enterprise / cloud metadata** (9 — different machines, higher blast
    radius). Does NOT catch DNS rebinding — that needs the async
    ``check_url_safety``. Safe to call from ``assess_risk()``.

    Checks performed:
    1. Scheme must be http or https.
    2. Userinfo (user:password@) is rejected.
    3. Hostname is checked against blocklists.
    4. Literal IP addresses are checked against blocked networks.
    """
    invariant_issue = check_url_invariants(url)
    if invariant_issue is not None:
        return (invariant_issue, _SSRF_SCORE_OTHER)

    parsed = urlparse(url)
    hostname = parsed.hostname or ""
    hostname_lower = hostname.lower()

    # Loopback hostnames first (distinct score).
    if hostname_lower in _LOOPBACK_HOSTNAMES or any(
        hostname_lower.endswith(s) for s in _LOOPBACK_HOSTNAME_SUFFIXES
    ):
        return (
            f"Request to loopback '{hostname}' blocked (SSRF protection)",
            _SSRF_SCORE_LOOPBACK,
        )

    if hostname_lower in _LAN_HOSTNAMES or any(
        hostname_lower.endswith(s) for s in _LAN_HOSTNAME_SUFFIXES
    ):
        return (
            f"Request to LAN/internal '{hostname}' blocked (SSRF protection)",
            _SSRF_SCORE_LAN,
        )

    try:
        addr = ipaddress.ip_address(hostname)
        category = _classify_ip(addr)
        if category == "loopback":
            return (
                f"Request to loopback IP {addr} blocked (SSRF protection)",
                _SSRF_SCORE_LOOPBACK,
            )
        if category == "lan":
            return (
                f"Request to private/reserved IP {addr} blocked (SSRF protection)",
                _SSRF_SCORE_LAN,
            )
    except ValueError:
        pass  # Not a literal IP — hostname, which is fine

    return None


async def check_dns_rebinding(url: str) -> str | None:
    """Detect DNS-rebinding: hostname that resolves to a private/reserved IP.

    Returns an error message, or ``None`` if the hostname resolves cleanly
    (or DNS is unavailable). This is an obfuscation-detection check — a URL
    that *advertises* a public hostname but *resolves* to loopback or LAN is
    structurally untrustworthy regardless of security profile, so it fires
    under every profile.
    """
    hostname = urlparse(url).hostname or ""
    if not hostname:
        return None
    try:
        loop = asyncio.get_running_loop()
        results = await loop.getaddrinfo(hostname, None)
        for _family, _type, _proto, _canonname, sockaddr in results:
            # Strip IPv6 scope IDs (``fe80::1%en0``) — ``getaddrinfo`` on
            # some platforms returns link-local / ULA results with a scope
            # suffix that ``ipaddress.ip_address`` doesn't accept. Without
            # this, a ValueError would escape through ``socket.gaierror``
            # and silently skip the rebinding check for any interface-
            # scoped address.
            raw = sockaddr[0]
            if isinstance(raw, str) and "%" in raw:
                raw = raw.split("%", 1)[0]
            try:
                addr = ipaddress.ip_address(raw)
            except ValueError:
                continue
            if _is_blocked_ip(addr):
                return (
                    f"Hostname '{hostname}' resolves to private IP {addr} "
                    f"(SSRF — DNS rebinding blocked)"
                )
    except socket.gaierror:
        pass  # DNS failure will be caught by the caller
    return None


async def check_url_safety(url: str) -> str | None:
    """Validate a URL against **all** SSRF rules — profile-agnostic / strict.

    This helper always flags direct private/loopback/LAN targets (via
    ``screen_url_ssrf_sync``) and DNS-rebinding hits. It does **not** consult
    the active ``SecurityProfile`` and therefore treats every finding as a
    hard block.

    Tools should generally prefer the split model used by ``http_request``,
    ``web_fetch``, and ``browser``:

    - ``screen_url_ssrf_sync`` inside ``assess_risk`` → surface a severity-
      aware ``RiskScore`` so open/standard can approval-gate private
      targets rather than rejecting them outright.
    - ``enforce_url_safety(url, security_profile)`` at runtime → hard-block
      under controlled/restricted (and always hard-block DNS rebinding /
      scheme / userinfo invariants regardless of profile).

    ``check_url_safety`` is retained for callers that genuinely need the
    strict "no private targets at all" behaviour (and for the SSRF test
    suite). New callers should reach for ``enforce_url_safety`` instead so
    profile-aware approval gating is preserved.

    Returns an error message string if the URL is unsafe, or ``None`` if it
    passes every check.
    """
    sync_hit = screen_url_ssrf_sync(url)
    if sync_hit is not None:
        return sync_hit[0]
    return await check_dns_rebinding(url)


def profile_blocks_ssrf(security_profile: SecurityProfile | str) -> bool:
    """Return True if the given security profile hard-blocks SSRF at runtime.

    Open and standard profiles treat SSRF as an approval-gated risk
    (``screen_url_ssrf_sync`` yields a severity-aware score: 7 for
    loopback, 9 for LAN / metadata / other); controlled and restricted
    hard-block at runtime even if the approval is somehow bypassed.
    """
    value = security_profile.value if hasattr(security_profile, "value") else security_profile
    return value in ("controlled", "restricted")


async def enforce_url_safety(url: str, security_profile: SecurityProfile | str) -> None:
    """Hard-block the URL at runtime per the given security profile.

    URL *invariants* (scheme must be http/https, no userinfo, non-empty
    hostname) and **DNS-rebinding detection** are enforced under *every*
    profile — a URL that advertises a public host but resolves to a
    private IP is an obfuscation attempt, and approving a risk prompt
    must never resurrect ``file://`` or ``javascript:`` access.

    The private-network *direct-address* rules (literal loopback / LAN
    IPs, blocked hostname suffixes) are profile-gated: in ``open`` /
    ``standard`` they are approval-gated via ``screen_url_ssrf_sync``
    (score 7 for loopback, 9 for LAN / metadata / other) in
    ``assess_risk``; in ``controlled`` / ``restricted`` they hard-block
    here as well.
    """
    invariant_issue = check_url_invariants(url)
    if invariant_issue is not None:
        raise ValueError(invariant_issue)

    # Known-private hosts (literal loopback / LAN IPs, blocked hostname
    # suffixes) are already approval-gated in open/standard via
    # ``screen_url_ssrf_sync`` → ``assess_risk``; short-circuit here so
    # the user's approval is honoured and the DNS check below only fires
    # for obfuscation attempts (apparently-public hosts that resolve to
    # private IPs).
    sync_hit = screen_url_ssrf_sync(url)
    if sync_hit is not None:
        if profile_blocks_ssrf(security_profile):
            raise ValueError(sync_hit[0])
        return

    # DNS rebinding (apparently-public host that resolves to a private IP)
    # is an obfuscation attempt — hard-block under every profile.
    rebinding_issue = await check_dns_rebinding(url)
    if rebinding_issue is not None:
        raise ValueError(rebinding_issue)
