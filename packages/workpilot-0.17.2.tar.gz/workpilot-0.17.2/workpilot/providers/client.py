"""
OpenAI-compatible unified provider.

Supports GitHub Copilot, OpenAI direct, and Azure OpenAI.

Routing (GitHub Copilot scope: gpt-5*, claude-*, gemini-*):
- gpt-5*                        → Responses API (fallback to Chat)
- gpt-5.4*/gpt-5.5* on Copilot / codex / *-pro → Responses API only (no fallback)
- claude-*, gemini-*, others     → Chat Completions (fallback to Responses)

Design follows nanobot (HKUDS/nanobot) provider patterns:
- choices[0]-first content merge; tool_calls merged across all choices
- max_completion_tokens for gpt-5.x / o-series (not max_tokens)
- temperature suppressed for reasoning models (gpt-5.x, o-series, reasoning_effort)
- empty-content sanitization (None for assistant+tools, "(empty)" otherwise)
- reasoning_effort forwarded as {"effort": ...} on Responses API
- reasoning_content extracted from Responses API output items
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from loguru import logger

from workpilot.config.schema import ProvidersConfig
from workpilot.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest
from workpilot.providers.model_catalog import GITHUB_COPILOT_REQUEST_BODY_CAP_BYTES
from workpilot.providers.resolver import (
    describe_resolution_failure,
    resolve_credentials,
    resolve_model_chain,
)
from workpilot.providers.usage import TokenUsageTracker

# ── Routing ────────────────────────────────────────────────────────────────────

# GitHub Copilot-specific: gpt-5.4/gpt-5.5 family rejects /chat/completions entirely.
_GITHUB_COPILOT_RESPONSES_ONLY: tuple[str, ...] = ("gpt-5.4", "gpt-5.5")


def _api_model_name(resolved_model: str) -> str:
    for prefix in ("github_copilot/", "github/", "openai/", "azure/", "azure_ai/"):
        if resolved_model.startswith(prefix):
            return resolved_model.removeprefix(prefix)
    return resolved_model


# Credential-failure wording lives in ``resolver.describe_resolution_failure``
# so every call site (``resolve_model``, ``complete``, ``_build_client``) stays
# in sync. Kept as a local alias for readability at the raise points.
_no_credentials_message = describe_resolution_failure


def _requires_responses_api(model_name: str) -> bool:
    """True for models that ONLY work with /v1/responses (no Chat fallback).

    Applies to all *-codex variants and gpt-5.x-pro variants.
    """
    n = model_name.lower()
    return "codex" in n or (n.startswith("gpt-5") and n.endswith("-pro"))


def _must_use_responses_api(resolved_model: str) -> bool:
    """True when Chat Completions fallback is NOT allowed."""
    name = _api_model_name(resolved_model).lower()
    if _requires_responses_api(name):
        return True
    # gpt-5.4/gpt-5.5 family on Copilot endpoint rejects /chat/completions
    if resolved_model.startswith(("github/", "github_copilot/")) and name.startswith(
        _GITHUB_COPILOT_RESPONSES_ONLY
    ):
        return True
    return False


def _should_prefer_responses_api(resolved_model: str) -> bool:
    """True for gpt-5* models — prefer Responses API.

    claude-*, gemini-*, and others stay on Chat Completions
    with automatic fallback to Responses API on ``unsupported_api_for_model``.
    """
    if _must_use_responses_api(resolved_model):
        return True
    name = _api_model_name(resolved_model).lower()
    return name.startswith("gpt-5")


def _supports_server_compaction(resolved_model: str) -> bool:
    """True for models that support server-side compaction via context_management.

    Verified on GitHub Copilot (2026-04-06): gpt-5.4 and gpt-5.5 families, and gpt-5.3+ codex.
    """
    import re

    name = _api_model_name(resolved_model).lower()
    if name.startswith(("gpt-5.4", "gpt-5.5")):
        return True
    if "codex" in name:
        # Parse numeric minor version: gpt-5.3-codex → 3, gpt-5.10-codex → 10
        m = re.search(r"gpt-5\.(\d+)", name)
        if m and int(m.group(1)) >= 3:
            return True
    return False


def _is_chat_unsupported_error(exc: Exception) -> bool:
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        error = body.get("error", {})
        code = str(error.get("code", "")).lower()
        message = str(error.get("message", "")).lower()
        if code == "unsupported_api_for_model":
            return True
        if "/chat/completions" in message:
            return True
    text = str(exc).lower()
    return "unsupported_api_for_model" in text or "/chat/completions endpoint" in text


def _parse_tool_args(raw_args: Any) -> dict[str, Any]:
    """Parse tool-call ``arguments`` to a dict, enforcing the
    ``ToolCallRequest.arguments`` dict-only contract.

    Downstream consumers (agent loop, audit, risk scorer) call ``.get(...)``
    on this field, so a non-dict value would raise at runtime. Inputs:

    - ``dict`` → returned as-is
    - ``None`` or empty / falsy str → ``{}``
    - ``str`` that decodes to a JSON object → that dict
    - ``str`` that fails to decode OR decodes to non-object (list, scalar,
      null, bool) → ``{"raw": <original string>}``
    - any other type → ``{"raw": str(raw_args)}``
    """
    if isinstance(raw_args, dict):
        return raw_args
    if not isinstance(raw_args, str):
        return {"raw": str(raw_args)} if raw_args is not None else {}
    if not raw_args:
        return {}
    try:
        parsed = json.loads(raw_args)
    except json.JSONDecodeError:
        return {"raw": raw_args}
    return parsed if isinstance(parsed, dict) else {"raw": raw_args}


def _finalize_pending_tool_calls(
    pending: dict[int, dict[str, str]],
) -> list[ToolCallRequest]:
    """Convert accumulated Chat-Completions stream-delta state to ToolCallRequests."""
    return [
        ToolCallRequest(
            id=pending[idx]["id"],
            name=pending[idx]["name"],
            arguments=_parse_tool_args(pending[idx]["args"]),
        )
        for idx in sorted(pending.keys())
    ]


# ── Parameter helpers (nanobot patterns) ──────────────────────────────────────

# Model families that require max_completion_tokens instead of max_tokens.
_COMPLETION_TOKENS_FAMILIES: tuple[str, ...] = ("gpt-5", "o1", "o2", "o3", "o4")


def _uses_completion_tokens(model_name: str) -> bool:
    n = model_name.lower()
    return any(n.startswith(f) for f in _COMPLETION_TOKENS_FAMILIES)


def _supports_temperature(model_name: str, reasoning_effort: str | None) -> bool:
    """False for reasoning models — temperature is ignored or rejected."""
    if reasoning_effort and reasoning_effort != "none":
        return False
    n = model_name.lower()
    return not any(n.startswith(f) for f in ("gpt-5", "o1", "o2", "o3", "o4"))


# ── Message sanitization ───────────────────────────────────────────────────────


def _sanitize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize messages for OpenAI-compatible APIs.

    - Strip internal metadata keys (``_``-prefixed and ``is_error``)
    - Empty string content: None for assistant+tool_calls, "(empty)" otherwise
      (avoids 400 errors from providers that reject empty content)
    - tool_call arguments: dict → JSON string
    """
    out = []
    for msg in messages:
        msg = {k: v for k, v in msg.items() if not k.startswith("_") and k != "is_error"}
        role = msg.get("role")
        content = msg.get("content")

        if isinstance(content, str) and not content:
            msg["content"] = None if (role == "assistant" and msg.get("tool_calls")) else "(empty)"

        if msg.get("tool_calls"):
            fixed = []
            for tc in msg["tool_calls"]:
                tc = dict(tc)
                if "function" in tc:
                    fn = dict(tc["function"])
                    if isinstance(fn.get("arguments"), dict):
                        fn["arguments"] = json.dumps(fn["arguments"])
                    tc["function"] = fn
                fixed.append(tc)
            msg["tool_calls"] = fixed

        out.append(msg)
    return out


# ── Responses API helpers ──────────────────────────────────────────────────────


def _responses_input(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert chat-style messages to Responses API input items.

    - tool messages → function_call_output (preserves call_id for multi-turn)
    - assistant + tool_calls → function_call items (fixes "no tool call found" errors)
    """
    items: list[dict[str, Any]] = []
    for msg in _sanitize_messages(messages):
        role = msg.get("role", "user")
        content = msg.get("content") or ""
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False)

        if role == "tool":
            items.append(
                {
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": content,
                }
            )
            continue

        if role not in {"system", "user", "assistant"}:
            role = "user"

        if role == "assistant" and msg.get("tool_calls"):
            # Emit text content first (reasoning preamble from gpt-5.4 etc.),
            # then function_call items — Responses API supports this ordering.
            if content:
                items.append({"role": "assistant", "content": content})
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                args = fn.get("arguments", "{}")
                items.append(
                    {
                        "type": "function_call",
                        "call_id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "arguments": args if isinstance(args, str) else json.dumps(args),
                    }
                )
            continue

        items.append({"role": role, "content": content})

    return items


def _responses_tools(tools: list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
    if not tools:
        return None
    converted = []
    for tool in tools:
        if tool.get("type") != "function":
            continue
        fn = tool.get("function", {})
        converted.append(
            {
                "type": "function",
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {"type": "object", "properties": {}}),
            }
        )
    return converted


def _serialize_output(output_items: Any) -> list[dict[str, Any]]:
    """Convert SDK response output items to dicts safe for storage and re-send.

    Compaction items are stripped to ``{type, id, encrypted_content}`` only —
    other fields (e.g. ``created_by``) cause 400 errors when sent back.
    """
    result: list[dict[str, Any]] = []
    for item in output_items or []:
        if hasattr(item, "model_dump"):
            d = item.model_dump(exclude_none=True)
        elif isinstance(item, dict):
            d = dict(item)
        else:
            d = vars(item) if hasattr(item, "__dict__") else {"_raw": str(item)}
        if d.get("type") == "compaction":
            d = {k: d[k] for k in ("type", "id", "encrypted_content") if k in d}
        # Strip output-only fields from message content parts that cause
        # 400 errors when sent back as input (logprobs is output-only).
        if d.get("type") == "message" and isinstance(d.get("content"), list):
            d["content"] = [
                {k: v for k, v in part.items() if k != "logprobs"}
                if isinstance(part, dict)
                else part
                for part in d["content"]
            ]
        result.append(d)
    return result


_VALID_INPUT_ROLES = frozenset({"user", "assistant", "system", "developer"})
_VALID_INPUT_TYPES = frozenset(
    {"function_call", "function_call_output", "message", "reasoning", "compaction"}
)


# ── LLM-bound body caps (per-call) ────────────────────────────────────────────
# Default budgets derived from the canonical edge cap so a quarterly
# recheck only updates GITHUB_COPILOT_REQUEST_BODY_CAP_BYTES. STRICT
# values are independent recovery floors, intentionally NOT derived
# from CAP because they're a conservative fallback that should fit
# even when text/tools dominate the body.
_BODY_MARGIN_BYTES: int = 512 * 1024
LLM_REQUEST_BODY_BUDGET_BYTES: int = GITHUB_COPILOT_REQUEST_BODY_CAP_BYTES - _BODY_MARGIN_BYTES
LLM_INLINE_IMAGE_DATA_URL_CAP_BYTES: int = LLM_REQUEST_BODY_BUDGET_BYTES - _BODY_MARGIN_BYTES
LLM_REQUEST_BODY_BUDGET_STRICT_BYTES: int = 2 * 1024 * 1024
LLM_INLINE_IMAGE_DATA_URL_CAP_STRICT_BYTES: int = 1 * 1024 * 1024

# CAP > BUDGET > IMAGE > STRICT_BUDGET > STRICT_IMAGE > 0 must hold.
assert (
    GITHUB_COPILOT_REQUEST_BODY_CAP_BYTES
    > LLM_REQUEST_BODY_BUDGET_BYTES
    > LLM_INLINE_IMAGE_DATA_URL_CAP_BYTES
    > LLM_REQUEST_BODY_BUDGET_STRICT_BYTES
    > LLM_INLINE_IMAGE_DATA_URL_CAP_STRICT_BYTES
    > 0
), "LLM body cap invariant broken — recheck constants in client.py + model_catalog.py"


def _resolve_attachment_urls(
    items: list[dict[str, Any]],
    *,
    max_inline_data_url_bytes: int = LLM_INLINE_IMAGE_DATA_URL_CAP_BYTES,
) -> list[dict[str, Any]]:
    """Inline ``workpilot-attachment://<sha>`` refs as ``data:`` URLs.

    Applies two of the four LLM-bound body gates inline:

    * **Gate 1 — sha dedupe**: an attachment referenced by the same
      sha256 in multiple turns is inlined only on its first occurrence
      within this single resolution pass; subsequent occurrences become
      a metadata-only placeholder (the LLM has already seen the bytes).
    * **Gate 2 — per-image cap**: an image whose base64 form would
      exceed ``max_inline_data_url_bytes`` is replaced with a metadata-only
      placeholder text part instead of being inlined.

    Gate 3 (cumulative body budget) is enforced separately by
    :func:`_enforce_body_budget` after this returns. Gate 4 (413
    recovery) lives in ``LLMProvider.complete`` and re-invokes this
    function with strict caps.

    Handles two shapes:
    - In-memory list content: any item whose ``content`` is a list of
      Responses-API or Chat-API parts (``input_image`` / ``image_url``)
      with a ``workpilot-attachment://`` URL. Each such part is rewritten
      to a ``data:`` URL or to a placeholder ``input_text`` / ``text``
      part per Gates 1+2. Runs regardless of role (user / assistant /
      tool).
    - Replayed-from-JSONL user message: ``content`` is a ``str`` and
      ``_attachments`` is a sidecar list of refs. Rebuilt into list-form
      content here so the image is actually sent to the LLM.

    Missing on-disk files are dropped (None return from
    :func:`_resolve_image_sha`); the warning is emitted there, not in
    ``load_as_data_url`` (the per-image cap path bypasses it). Items
    that match neither shape pass through unchanged.
    """
    from workpilot.security.attachments import (
        ATTACHMENT_URL_SCHEME,
        attachment_metadata_text,
        load_as_data_url,
        load_as_text,
        load_ref,
        render_text_attachment,
    )

    # Per-call dedupe — reset every invocation so that re-resolving with
    # strict caps after a 413 starts from a clean slate.
    seen_shas: set[str] = set()

    def _placeholder_for(
        sha: str, att_meta: dict[str, Any] | None, *, header: str
    ) -> dict[str, Any]:
        """Build an ``input_text`` placeholder for a sha that won't inline."""
        meta_obj: dict[str, Any] | str = att_meta if att_meta is not None else sha
        return {
            "type": "input_text",
            "text": attachment_metadata_text(meta_obj, header=header),
        }

    def _resolve_image_sha(
        sha: str,
        att_meta: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Apply Gates 1+2 to a single image sha.

        Returns one of:
          * ``{"type": "input_image", "image_url": "data:..."}`` — inlined
          * ``{"type": "input_text", "text": "..."}``            — placeholder (dedupe / over-cap)
          * ``None``                                              — missing on disk; caller should drop the part entirely (preserves the pre-existing silent-drop semantics for missing files).
        """
        # Probe the on-disk store first so missing vs over-cap can be
        # distinguished. Missing → drop; oversize → placeholder.
        ref = load_ref(sha)
        if ref is None:
            # This direct ``load_ref`` path bypasses ``load_as_data_url``,
            # so we own the warning here. Mirrors the legacy silent-drop
            # behaviour for the caller-visible result (return None) but
            # still gives operators a log line to diagnose missing files.
            logger.warning("Image attachment missing from local store: {}", sha)
            return None
        if ref.kind != "image":
            # Non-image sha referenced in an ``input_image`` part —
            # malformed input (text attachments belong in ``input_text``
            # via ``load_as_text``). Silently drop instead of emitting
            # an "over-cap" placeholder that would misdiagnose the
            # cause for both LLM and operator.
            logger.warning(
                "Non-image attachment ({}) referenced in image part — dropping: {}",
                ref.kind,
                sha,
            )
            return None
        # Gate 1 — dedupe: second occurrence of the same sha within this
        # resolution pass becomes a "same as previously" placeholder. The
        # bytes are already inlined elsewhere in this same request, so
        # the LLM has full visual context — only the human-readable
        # header needs to differ from Gate 2's "too large" wording.
        if sha in seen_shas:
            return _placeholder_for(
                sha,
                att_meta,
                header="[Attachment: same as previously inlined in this request]",
            )
        # Gate 2 — per-image cap: oversize images become metadata
        # placeholders. ``load_as_data_url`` returns None when over cap.
        data_url = load_as_data_url(sha, max_inline_data_url_bytes=max_inline_data_url_bytes)
        if data_url is None:
            # File present (we just stat'd it via load_ref) but base64
            # would exceed the per-image cap → placeholder.
            return _placeholder_for(
                sha,
                att_meta,
                header="[Attachment not inlined — too large for LLM body cap]",
            )
        seen_shas.add(sha)
        return {"type": "input_image", "image_url": data_url}

    out: list[dict[str, Any]] = []
    for item in items:
        role = item.get("role")
        content = item.get("content")
        # Case B — replayed user message with sidecar refs
        if (
            role == "user"
            and isinstance(content, str)
            and isinstance(item.get("_attachments"), list)
            and item["_attachments"]
        ):
            parts: list[dict[str, Any]] = [{"type": "input_text", "text": content}]
            for a in item["_attachments"]:
                if not isinstance(a, dict):
                    continue
                sha = a.get("sha256")
                if not isinstance(sha, str):
                    continue
                # Legacy sessions (pre-text-attachment) lack ``kind``; fall
                # back to on-disk lookup so old JSONL still replays.
                kind = a.get("kind")
                if not kind:
                    ref = load_ref(sha)
                    kind = ref.kind if ref else "image"
                if kind == "image":
                    resolved = _resolve_image_sha(sha, a)
                    if resolved is None:
                        continue  # missing on disk — drop silently
                    parts.append(resolved)
                else:
                    body = load_as_text(sha)
                    if body is None:
                        continue
                    parts.append(
                        {
                            "type": "input_text",
                            "text": render_text_attachment(a.get("name") or sha[:8], body),
                        }
                    )
            # Only rewrite if we actually attached something
            if len(parts) > 1:
                new_item = dict(item)
                new_item["content"] = parts
                out.append(new_item)
                continue
            # else fall through — text-only remains persisted as str
        # Case A — list content with attachment URLs (Responses + Chat shapes)
        if isinstance(content, list):
            changed = False
            new_parts: list[Any] = []
            for part in content:
                if not isinstance(part, dict):
                    new_parts.append(part)
                    continue
                ptype = part.get("type")
                # Responses API: {"type":"input_image","image_url":"<url>"}
                if ptype == "input_image":
                    url = part.get("image_url")
                    if isinstance(url, str) and url.startswith(ATTACHMENT_URL_SCHEME):
                        sha = url[len(ATTACHMENT_URL_SCHEME) :]
                        resolved = _resolve_image_sha(sha)
                        changed = True
                        if resolved is not None:
                            new_parts.append(resolved)
                        # missing → drop silently (legacy behaviour)
                        continue
                # Chat Completions: {"type":"image_url","image_url":{"url":"<url>"}}
                if ptype == "image_url":
                    iu = part.get("image_url")
                    if isinstance(iu, dict):
                        url = iu.get("url")
                        if isinstance(url, str) and url.startswith(ATTACHMENT_URL_SCHEME):
                            sha = url[len(ATTACHMENT_URL_SCHEME) :]
                            resolved = _resolve_image_sha(sha)
                            changed = True
                            if resolved is None:
                                # missing → drop silently
                                continue
                            if resolved.get("type") == "input_image":
                                # Convert Responses-API shape back to Chat-API shape.
                                new_parts.append(
                                    {
                                        "type": "image_url",
                                        "image_url": {"url": resolved["image_url"]},
                                    }
                                )
                            else:
                                # Placeholder text — Chat API uses {"type":"text","text":...}.
                                new_parts.append({"type": "text", "text": resolved["text"]})
                            continue
                new_parts.append(part)
            if changed:
                new_item = dict(item)
                new_item["content"] = new_parts
                out.append(new_item)
                continue
        out.append(item)
    return out


def _enforce_body_budget(
    items: list[dict[str, Any]],
    *,
    budget_bytes: int = LLM_REQUEST_BODY_BUDGET_BYTES,
) -> list[dict[str, Any]]:
    """Gate 3 — drop oldest inline images until serialized body fits.

    Walks turns oldest → newest, replacing each ``input_image`` (or
    Chat-API ``image_url``) part with a ``[Attachment dropped — body
    over budget]`` placeholder, re-measuring after each replacement.
    Stops as soon as the body fits ``budget_bytes`` so the most recent
    visual context is preserved.

    Mutates a deep-ish copy (per-item / per-content-list); the original
    ``items`` list is left untouched.

    Idempotent: items already free of ``input_image`` parts pass
    through unchanged regardless of budget.
    """
    import json

    def _measure(its: list[dict[str, Any]]) -> int:
        return len(json.dumps(its, ensure_ascii=False).encode("utf-8"))

    body_size = _measure(items)
    if body_size <= budget_bytes:
        return items

    # Find every (item_idx, part_idx) holding an image part, in time order.
    image_locations: list[tuple[int, int]] = []
    for i, item in enumerate(items):
        content = item.get("content")
        if not isinstance(content, list):
            continue
        for j, part in enumerate(content):
            if not isinstance(part, dict):
                continue
            ptype = part.get("type")
            if ptype == "input_image":
                image_locations.append((i, j))
            elif ptype == "image_url":
                # Only count Chat-API ``image_url`` parts that resolved
                # to a ``data:`` URL — bare https URLs don't bloat body.
                iu = part.get("image_url")
                if isinstance(iu, dict) and isinstance(iu.get("url"), str):
                    if iu["url"].startswith("data:"):
                        image_locations.append((i, j))

    if not image_locations:
        # Nothing inline to drop — body is text-heavy. Surface to caller
        # via unchanged return; token-limit path will compact further.
        logger.warning(
            "LLM request body over budget ({} bytes > {}) but no inline images to drop",
            body_size,
            budget_bytes,
        )
        return items

    # Build a working copy we can mutate without disturbing inputs.
    working: list[dict[str, Any]] = [
        dict(
            it,
            content=(
                list(it["content"]) if isinstance(it.get("content"), list) else it.get("content")
            ),
        )
        for it in items
    ]

    placeholder_text = "[Attachment dropped — request body over budget; original retained on disk]"
    dropped = 0
    # Drop one image at a time, re-measuring after each, so we drop
    # the MINIMUM count needed and preserve the newest visual context.
    # Re-serialization is O(N × body) in the worst case but realistic
    # sessions have ≤ 10 images / ≤ 6 MiB bodies (~600 ms worst case).
    for item_idx, part_idx in image_locations:
        # Replace this image part with an inline placeholder. Match the
        # API shape (Responses ``input_text`` vs Chat ``text``) using
        # the original part's type as the discriminator.
        original_part = working[item_idx]["content"][part_idx]
        if original_part.get("type") == "input_image":
            new_part = {"type": "input_text", "text": placeholder_text}
        else:
            new_part = {"type": "text", "text": placeholder_text}
        working[item_idx]["content"][part_idx] = new_part
        dropped += 1
        body_size = _measure(working)
        if body_size <= budget_bytes:
            break

    if body_size <= budget_bytes:
        logger.info(
            "LLM body budget enforced — dropped {} inline image(s); body now {} bytes (≤ {})",
            dropped,
            body_size,
            budget_bytes,
        )
    else:
        # Exhausted all images and still over budget — text/tools dominate.
        # Caller (Gate 4 recovery, or token-limit path) will handle further.
        logger.warning(
            "LLM body budget reduction incomplete — dropped {} inline image(s); "
            "body still {} bytes (> {})",
            dropped,
            body_size,
            budget_bytes,
        )
    return working


def _prepare_items_for_api(
    items: list[dict[str, Any]],
    resolved_model: str = "",
) -> list[dict[str, Any]]:
    """Single-pass sanitization of items before any API call.

    Performs ALL cleaning in one place:
    0. Resolve workpilot-attachment:// URLs to data URLs (incl. JSONL replay)
    1. Drop non-API items (``approval_request``, unknown types/roles)
    2. Strip internal metadata keys (``_ts``, ``is_error``, etc.)
    3. Normalize Chat-format items to Responses API native format
    4. Filter compaction items for models that don't support them
    5. Remove orphan ``function_call`` items (no matching ``function_call_output``)
    """
    # ── Pass 0: materialize attachment refs into inline data: URLs ───────
    # Gates 1 (sha dedupe) + 2 (per-image base64 cap) applied here.
    items = _resolve_attachment_urls(items)
    # Gate 3 — keep total request body under the 5 MiB edge proxy cap.
    items = _enforce_body_budget(items)

    # ── Pass 1: filter + strip + normalize ────────────────────────────────
    cleaned: list[dict[str, Any]] = []
    for item in items:
        role = item.get("role", "")
        item_type = item.get("type", "")

        # 1. Strip metadata keys + output-only fields from content parts.
        # is_error is stripped (not an API field) but the item is KEPT —
        # error context helps the LLM avoid retrying failed tools.
        d = {k: v for k, v in item.items() if not k.startswith("_") and k != "is_error"}
        if isinstance(d.get("content"), list):
            d["content"] = [
                {k: v for k, v in part.items() if k != "logprobs"}
                if isinstance(part, dict)
                else part
                for part in d["content"]
            ]

        # 2. Skip empty items (all keys were _-prefixed metadata)
        if not d:
            continue

        # 3. Normalize Chat items to native format (before role validation,
        #    since role:"tool" is not a valid Responses API role but needs conversion)
        if not item_type and (role == "tool" or d.get("tool_calls")):
            cleaned.extend(_responses_input([d]))
            continue

        # 4. Drop non-API items (approval_request, etc.)
        if role and role not in _VALID_INPUT_ROLES and not item_type:
            continue
        if item_type and item_type not in _VALID_INPUT_TYPES:
            continue

        # 5. Filter compaction for unsupported models
        if (
            item_type == "compaction"
            and resolved_model
            and not _supports_server_compaction(resolved_model)
        ):
            continue

        cleaned.append(d)

    # ── Pass 2: remove orphan function_calls ──────────────────────────────
    fc_ids = {i.get("call_id") for i in cleaned if i.get("type") == "function_call"}
    fco_ids = {i.get("call_id") for i in cleaned if i.get("type") == "function_call_output"}
    result: list[dict[str, Any]] = []
    for item in cleaned:
        if item.get("type") == "function_call" and (
            not item.get("call_id") or item.get("call_id") not in fco_ids
        ):
            continue  # orphan function_call — no matching output
        if item.get("type") == "function_call_output" and (
            not item.get("call_id") or item.get("call_id") not in fc_ids
        ):
            continue  # orphan function_call_output — no matching call
        result.append(item)

    # ── Pass 3: keep only the latest reasoning items ─────────────────────
    # Accumulated encrypted_content from multiple reasoning items causes 400
    # on the Copilot proxy. On restart, JSONL may contain many reasoning items
    # from prior turns. Keep only the last reasoning item (matches the in-loop
    # behavior of removing old reasoning before extending with new output).
    reasoning_indices = [i for i, item in enumerate(result) if item.get("type") == "reasoning"]
    if len(reasoning_indices) > 1:
        drop = set(reasoning_indices[:-1])
        result = [item for i, item in enumerate(result) if i not in drop]

    return result


def _parts_to_chat_content(content: list[Any]) -> list[dict[str, Any]]:
    """Translate Responses API content parts → Chat Completions content parts.

    Maps ``input_text``/``text`` → ``text`` and ``input_image`` → ``image_url``.
    Preserves already-Chat-shape ``image_url`` parts. Unknown shapes are dropped.
    """
    out: list[dict[str, Any]] = []
    for part in content:
        if not isinstance(part, dict):
            continue
        pt = part.get("type")
        if pt in ("input_text", "text"):
            text = part.get("text", "")
            if text:
                out.append({"type": "text", "text": text})
        elif pt == "input_image":
            url = part.get("image_url")
            if isinstance(url, dict):
                url = url.get("url")
            if isinstance(url, str) and url:
                out.append({"type": "image_url", "image_url": {"url": url}})
        elif pt == "image_url":
            out.append(part)
    return out


def items_to_chat_messages(
    items: list[dict[str, Any]],
    instructions: str | None = None,
) -> list[dict[str, Any]]:
    """Convert Responses API native items to Chat Completions messages.

    Handles both native items (``type`` field) and legacy Chat items (``role`` field).
    Consecutive ``function_call`` items are batched into one assistant message.
    Preceding assistant commentary is merged into the tool_calls message.
    ``reasoning`` and ``compaction`` items are skipped (not representable).

    Orphan ``function_call`` / ``function_call_output`` items (no matching
    counterpart) are dropped — mirrors the Pass 2 logic in
    ``_prepare_items_for_api`` so the Chat Completions path never produces
    assistant ``tool_calls`` without corresponding ``tool`` messages.
    """
    # ── Pass 0: materialize attachment refs into inline data: URLs ───────
    # Gates 1 + 2 + 3 — same as ``_prepare_items_for_api`` Pass 0.
    items = _resolve_attachment_urls(items)
    items = _enforce_body_budget(items)

    # ── Pre-filter: drop orphan function_call / function_call_output ──
    # Collect paired call_ids first, then filter.  Empty/None ids are
    # excluded so they never accidentally "pair" with each other.
    _fc_ids: set[str] = set()
    _fco_ids: set[str] = set()
    for i in items:
        if i.get("type") == "function_call" and i.get("call_id"):
            _fc_ids.add(i["call_id"])
        elif i.get("type") == "function_call_output" and i.get("call_id"):
            _fco_ids.add(i["call_id"])
        # Also collect from Chat-format: assistant tool_calls ↔ role:"tool"
        if i.get("role") == "assistant" and i.get("tool_calls"):
            for tc in i["tool_calls"]:
                if tc.get("id"):
                    _fc_ids.add(tc["id"])
        if i.get("role") == "tool" and i.get("tool_call_id"):
            _fco_ids.add(i["tool_call_id"])
    _paired_ids = _fc_ids & _fco_ids

    filtered_items: list[dict[str, Any]] = []
    for i in items:
        if i.get("type") == "function_call":
            if not i.get("call_id") or i.get("call_id") not in _paired_ids:
                continue
        elif i.get("type") == "function_call_output":
            if not i.get("call_id") or i.get("call_id") not in _paired_ids:
                continue
        elif i.get("role") == "assistant" and i.get("tool_calls"):
            # Drop unpaired tool_calls from Chat-format assistant messages
            paired_tcs = [tc for tc in i["tool_calls"] if tc.get("id") in _paired_ids]
            if not paired_tcs:
                # All tool_calls orphaned — preserve assistant message
                # only if it has meaningful text (string or content parts)
                content = i.get("content")
                has_text = (isinstance(content, str) and content.strip()) or (
                    isinstance(content, list) and len(content) > 0
                )
                if has_text:
                    filtered_items.append({k: v for k, v in i.items() if k != "tool_calls"})
                continue
            if len(paired_tcs) < len(i["tool_calls"]):
                i = {**i, "tool_calls": paired_tcs}
        elif i.get("role") == "tool":
            if not i.get("tool_call_id") or i.get("tool_call_id") not in _paired_ids:
                continue
        filtered_items.append(i)

    messages: list[dict[str, Any]] = []
    if instructions:
        messages.append({"role": "system", "content": instructions})

    pending_tool_calls: list[dict[str, Any]] = []
    pending_content: str | None = None

    def _extract_text(item: dict[str, Any]) -> str:
        content = item.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for part in content:
                if isinstance(part, dict):
                    text = part.get("text", "") or part.get("refusal", "")
                    if text:
                        parts.append(text)
            return "".join(parts)
        return str(content) if content else ""

    def _flush() -> None:
        nonlocal pending_content
        if pending_tool_calls:
            msg: dict[str, Any] = {
                "role": "assistant",
                "content": pending_content or "",
                "tool_calls": [
                    {
                        "id": fc.get("call_id", fc.get("id", "")),
                        "type": "function",
                        "function": {
                            "name": fc.get("name", ""),
                            "arguments": fc.get("arguments", "{}"),
                        },
                    }
                    for fc in pending_tool_calls
                ],
            }
            messages.append(msg)
            pending_tool_calls.clear()
            pending_content = None
        elif pending_content is not None:
            messages.append({"role": "assistant", "content": pending_content})
            pending_content = None

    for item in filtered_items:
        t = item.get("type", "")
        role = item.get("role", "")

        # Skip non-API items (approval_request, etc.)
        if role and role not in _VALID_INPUT_ROLES and role != "tool" and not t:
            continue

        # Legacy Chat format items (no "type" field, have "role" + possibly "tool_calls")
        if not t and role:
            _flush()
            if role == "tool":
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": item.get("tool_call_id", ""),
                        "content": item.get("content", ""),
                    }
                )
            elif role == "assistant" and item.get("tool_calls"):
                messages.append(item)
            else:
                content = item.get("content", "")
                if role == "user" and isinstance(content, list):
                    translated = _parts_to_chat_content(content)
                    messages.append({"role": role, "content": translated or ""})
                else:
                    messages.append({"role": role, "content": content})
            continue

        # Native Responses API items
        if role in ("user", "system", "developer"):
            _flush()
            content = item.get("content")
            if role == "user" and isinstance(content, list):
                translated = _parts_to_chat_content(content)
                if translated:
                    messages.append({"role": role, "content": translated})
                    continue
            messages.append({"role": role, "content": _extract_text(item)})

        elif t == "function_call":
            pending_tool_calls.append(item)

        elif t == "function_call_output":
            _flush()
            output = item.get("output", "")
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": item.get("call_id", ""),
                    "content": output
                    if isinstance(output, str)
                    else json.dumps(output, ensure_ascii=False),
                }
            )

        elif t == "message" and role == "assistant":
            _flush()  # flush any pending tool_calls or prior assistant content
            pending_content = _extract_text(item)

        # reasoning, compaction → skip

    _flush()
    return messages


def chat_response_to_items(response: Any) -> list[dict[str, Any]]:
    """Convert a Chat Completions response to Responses API native items."""
    if not response.choices:
        return []
    msg = response.choices[0].message
    result: list[dict[str, Any]] = []
    if msg.content:
        result.append({"role": "assistant", "content": msg.content})
    if getattr(msg, "tool_calls", None):
        for tc in msg.tool_calls:
            result.append(
                {
                    "type": "function_call",
                    "call_id": tc.id,
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                }
            )
    return result


# ── Provider ───────────────────────────────────────────────────────────────────


class OpenAIProvider(LLMProvider):
    """Unified provider for GitHub Copilot, OpenAI, and Azure OpenAI.

    Routing (scope: gpt-5*, claude-*, gemini-*):
    - gpt-5*                         → Responses API (fallback to Chat)
    - gpt-5.4* on Copilot / codex / *-pro → Responses API only (no fallback)
    - claude-*, gemini-*, others      → Chat Completions (fallback to Responses)
    """

    def __init__(self, providers: ProvidersConfig | None = None) -> None:
        self._providers = providers or ProvidersConfig()
        self._usage: TokenUsageTracker | None = None
        self._client_cache: dict[tuple[str, str | None, str | None, Any], Any] = {}

    def set_usage_tracker(self, tracker: TokenUsageTracker) -> None:
        """Attach a token usage tracker for cost monitoring."""
        self._usage = tracker

    # ── Request building ───────────────────────────────────────────────────────

    def _build_kwargs(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, Any], dict[str, Any]]:
        """Return (resolved_model, req_kwargs, creds)."""
        resolved_model = model
        creds = resolve_credentials(resolved_model, self._providers)
        model_name = _api_model_name(resolved_model)

        req_kwargs: dict[str, Any] = {
            "model": model_name,
            "messages": _sanitize_messages(messages),
        }

        # Temperature: suppressed for reasoning models (nanobot pattern)
        if temperature is not None and _supports_temperature(model_name, reasoning_effort):
            req_kwargs["temperature"] = temperature

        # max_tokens → max_completion_tokens for gpt-5.x / o-series
        if max_tokens is not None:
            param = "max_completion_tokens" if _uses_completion_tokens(model_name) else "max_tokens"
            req_kwargs[param] = max_tokens

        if tools:
            req_kwargs["tools"] = tools

        # reasoning_effort for chat/completions (gpt-5.x, o-series)
        if reasoning_effort and reasoning_effort != "none":
            req_kwargs["reasoning_effort"] = reasoning_effort

        return resolved_model, req_kwargs, creds

    def _build_client(self, resolved_model: str, creds: dict[str, Any]) -> Any:
        from openai import AsyncAzureOpenAI, AsyncOpenAI

        api_key = creds.get("api_key")
        if not api_key:
            raise ValueError(_no_credentials_message(resolved_model))

        api_base: str | None = creds.get("api_base")
        api_version: str | None = creds.get("api_version")
        extra_headers = creds.get("extra_headers")
        headers_key = (
            tuple(sorted(extra_headers.items()))
            if isinstance(extra_headers, dict)
            else extra_headers
        )
        cache_key = (api_key, api_base, api_version, headers_key)

        if cache_key in self._client_cache:
            return self._client_cache[cache_key]

        client: AsyncAzureOpenAI | AsyncOpenAI
        if resolved_model.startswith(("azure/", "azure_ai/")):
            if not api_base:
                raise ValueError("Azure OpenAI / Azure AI Foundry requires endpoint (api_base)")
            client = AsyncAzureOpenAI(
                api_key=api_key,
                azure_endpoint=api_base,
                api_version=api_version or "2024-10-21",
                default_headers=extra_headers,
            )
        else:
            client = AsyncOpenAI(
                api_key=api_key,
                base_url=api_base,
                default_headers=extra_headers,
            )

        self._client_cache[cache_key] = client
        return client

    # ── Response parsing ───────────────────────────────────────────────────────

    @staticmethod
    def _parse_chat_tool_calls(message: Any) -> list[ToolCallRequest]:
        if not getattr(message, "tool_calls", None):
            return []
        return [
            ToolCallRequest(
                id=tc.id,
                name=tc.function.name,
                arguments=_parse_tool_args(tc.function.arguments),
            )
            for tc in message.tool_calls
        ]

    @staticmethod
    def _merge_choices(response: Any) -> tuple[str, list[ToolCallRequest], str]:
        """Merge content and tool_calls across all choices (nanobot pattern).

        choices[0] is authoritative for content and finish_reason.
        Content from other choices is only used if choices[0] has none.
        Tool calls are merged from ALL choices (GitHub Copilot may split them).
        """
        if not response.choices:
            return "", [], "stop"

        primary = response.choices[0]
        content: str = primary.message.content or ""
        finish_reason: str = primary.finish_reason or "stop"

        all_tool_calls: list[ToolCallRequest] = []
        for choice in response.choices:
            tcs = OpenAIProvider._parse_chat_tool_calls(choice.message)
            all_tool_calls.extend(tcs)
            if not content and choice.message.content:
                content = choice.message.content
            if tcs and choice.finish_reason == "tool_calls":
                finish_reason = "tool_calls"

        if all_tool_calls and finish_reason != "tool_calls":
            finish_reason = "tool_calls"

        if len(response.choices) > 1:
            logger.debug(
                "Chat response has {} choices, merged {} tool_calls",
                len(response.choices),
                len(all_tool_calls),
            )

        return content, all_tool_calls, finish_reason

    @staticmethod
    def _parse_responses_result(
        response: Any,
    ) -> tuple[
        str, list[ToolCallRequest], str | None, int, int, list[dict[str, Any]], list[dict[str, Any]]
    ]:
        """Parse Responses API result.

        Returns (content, tool_calls, reasoning_content, prompt_tokens,
        completion_tokens, compaction_blobs, raw_output).
        """
        content: str = getattr(response, "output_text", "") or ""
        tool_calls: list[ToolCallRequest] = []
        reasoning_parts: list[str] = []
        compaction_blobs: list[dict[str, Any]] = []

        for item in getattr(response, "output", []) or []:
            item_type = getattr(item, "type", None)

            if item_type == "function_call":
                tool_calls.append(
                    ToolCallRequest(
                        id=str(
                            getattr(item, "call_id", None)
                            or getattr(item, "id", None)
                            or "function_call"
                        ),
                        name=getattr(item, "name", ""),
                        arguments=_parse_tool_args(getattr(item, "arguments", "")),
                    )
                )

            elif item_type == "reasoning":
                for part in getattr(item, "content", []) or []:
                    part_type = getattr(part, "type", None)
                    if part_type in ("thinking", "text"):
                        text = getattr(part, "thinking", None) or getattr(part, "text", "")
                        if text:
                            reasoning_parts.append(text)

            elif item_type == "compaction":
                compaction_blobs.append(
                    {
                        "type": "compaction",
                        "id": str(getattr(item, "id", "")),
                        "encrypted_content": str(getattr(item, "encrypted_content", "")),
                    }
                )

            elif item_type == "message" and not content:
                texts: list[str] = []
                for part in getattr(item, "content", []) or []:
                    if getattr(part, "type", None) in ("output_text", "text"):
                        text = getattr(part, "text", "")
                        if text:
                            texts.append(text)
                if texts:
                    content = "".join(texts)

        reasoning_content: str | None = "\n".join(reasoning_parts) if reasoning_parts else None

        usage = getattr(response, "usage", None)
        prompt_tokens = (
            int(getattr(usage, "input_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0)
            if usage
            else 0
        )
        completion_tokens = (
            int(getattr(usage, "output_tokens", 0) or getattr(usage, "completion_tokens", 0) or 0)
            if usage
            else 0
        )

        raw_output = _serialize_output(getattr(response, "output", None))

        return (
            content,
            tool_calls,
            reasoning_content,
            prompt_tokens,
            completion_tokens,
            compaction_blobs,
            raw_output,
        )

    # ── API call helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _build_responses_kwargs(
        req_kwargs: dict[str, Any],
        *,
        resolved_model: str = "",
        compact_threshold: int | None = None,
        native_items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
    ) -> dict[str, Any]:
        """Build Responses API request kwargs.

        Uses ``_prepare_items_for_api()`` for all sanitization (filtering,
        normalization, orphan removal).  Legacy ``messages`` path uses
        ``_responses_input()`` for Chat→native conversion.
        """
        if native_items is not None:
            input_items = _prepare_items_for_api(native_items, resolved_model)
        else:
            input_items = _responses_input(req_kwargs["messages"])

        # instructions: explicit param or extract first system message
        effective_instructions = instructions
        if effective_instructions is None:
            non_system: list[dict[str, Any]] = []
            for item in input_items:
                if effective_instructions is None and item.get("role") == "system":
                    effective_instructions = item.get("content", "")
                else:
                    non_system.append(item)
            input_items = non_system

        resp_kwargs: dict[str, Any] = {
            "model": req_kwargs.get("model", _api_model_name(resolved_model)),
            "input": input_items,
            "truncation": "auto",
        }

        if effective_instructions:
            resp_kwargs["instructions"] = effective_instructions

        # include reasoning encrypted_content for cross-turn fidelity
        if _should_prefer_responses_api(resolved_model or req_kwargs.get("model", "")):
            resp_kwargs["include"] = ["reasoning.encrypted_content"]

        if "temperature" in req_kwargs:
            resp_kwargs["temperature"] = req_kwargs["temperature"]
        if "max_completion_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_completion_tokens"]
        elif "max_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_tokens"]
        if "reasoning_effort" in req_kwargs:
            resp_kwargs["reasoning"] = {"effort": req_kwargs["reasoning_effort"]}

        converted_tools = _responses_tools(req_kwargs.get("tools"))
        if converted_tools:
            resp_kwargs["tools"] = converted_tools

        # Server-side compaction
        if compact_threshold and _supports_server_compaction(resolved_model):
            resp_kwargs["context_management"] = [
                {"type": "compaction", "compact_threshold": max(compact_threshold, 1000)}
            ]

        return resp_kwargs

    async def _complete_via_responses(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
        native_items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> LLMResponse:
        resp_kwargs = self._build_responses_kwargs(
            req_kwargs,
            resolved_model=resolved_model,
            native_items=native_items,
            instructions=instructions,
            compact_threshold=compact_threshold,
        )

        start = time.monotonic()
        response = await client.responses.create(**resp_kwargs)
        elapsed_ms = (time.monotonic() - start) * 1000

        (
            content,
            tool_calls,
            reasoning_content,
            prompt_tokens,
            completion_tokens,
            compaction_blobs,
            raw_output,
        ) = self._parse_responses_result(response)

        # Use our internal prefixed ID (e.g. ``github/gpt-5.4``) as the canonical
        # model identifier. Copilot's Responses API returns a dated snapshot ID
        # in ``response.model`` (e.g. ``gpt-5.4-2026-03-05``) which would break
        # the agent loop's fallback detection and credential resolution if we
        # propagated it upstream — those paths expect the ``<provider>/<name>``
        # shape. Upstream snapshot info is still visible in raw logs.
        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            model=resolved_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=elapsed_ms,
            reasoning_content=reasoning_content,
            raw_output=raw_output,
            compaction_blobs=compaction_blobs,
        )

    async def _complete_via_chat(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
    ) -> LLMResponse:
        start = time.monotonic()
        response = await client.chat.completions.create(**req_kwargs)
        elapsed_ms = (time.monotonic() - start) * 1000

        content, tool_calls, finish_reason = self._merge_choices(response)
        usage = response.usage
        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            model=resolved_model,
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
            duration_ms=elapsed_ms,
        )

    async def _stream_via_responses(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
        native_items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> AsyncIterator[LLMChunk]:
        """Stream via Responses API SSE events."""
        resp_kwargs = self._build_responses_kwargs(
            req_kwargs,
            resolved_model=resolved_model,
            native_items=native_items,
            instructions=instructions,
            compact_threshold=compact_threshold,
        )
        resp_kwargs["stream"] = True

        stream = await client.responses.create(**resp_kwargs)

        prompt_tokens = 0
        completion_tokens = 0

        async for event in stream:
            event_type = getattr(event, "type", "")

            if event_type == "response.output_text.delta":
                yield LLMChunk(
                    content=getattr(event, "delta", ""),
                    model=resolved_model,
                )

            elif event_type == "response.output_item.done":
                # Use the item-level "done" event (fires after all argument
                # deltas) rather than ``function_call_arguments.done``: GitHub
                # Copilot's Responses-API relay sends ``name=None`` and no
                # ``call_id`` on that event, even though the OpenAI SDK schema
                # marks ``name`` as required. The output_item.done event's
                # ``item`` carries call_id, name, and the complete arguments
                # string, and is the canonical source on every backend.
                item = getattr(event, "item", None)
                if item is not None and getattr(item, "type", None) == "function_call":
                    yield LLMChunk(
                        tool_calls=[
                            ToolCallRequest(
                                id=getattr(item, "call_id", "") or "",
                                name=getattr(item, "name", "") or "",
                                arguments=_parse_tool_args(getattr(item, "arguments", "")),
                            )
                        ],
                        finish_reason="tool_calls",
                        model=resolved_model,
                    )

            elif event_type == "response.completed":
                resp = getattr(event, "response", None)
                usage = getattr(resp, "usage", None) if resp else None
                if usage:
                    prompt_tokens = int(
                        getattr(usage, "input_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0
                    )
                    completion_tokens = int(
                        getattr(usage, "output_tokens", 0)
                        or getattr(usage, "completion_tokens", 0)
                        or 0
                    )
                # Extract compaction blobs and raw output from completed response
                if resp:
                    raw_output = _serialize_output(getattr(resp, "output", None))
                    blobs = [i for i in raw_output if i.get("type") == "compaction"]
                    if blobs or raw_output:
                        yield LLMChunk(
                            compaction_blobs=blobs,
                            raw_output=raw_output,
                            model=resolved_model,
                        )

        if self._usage:
            self._usage.record(
                model=resolved_model,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                duration_ms=0,
            )

    async def _stream_via_chat(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
    ) -> AsyncIterator[LLMChunk]:
        """Stream via Chat Completions, aggregating tool-call deltas across chunks.

        OpenAI's Chat Completions stream delivers tool calls as fragments
        keyed by ``delta.tool_calls[i].index``. The first fragment carries
        ``id`` + ``function.name``; subsequent fragments carry
        ``function.arguments`` string-deltas; the terminal chunk has no
        tool_calls and ``finish_reason='tool_calls'``.

        On GitHub Copilot's Claude relay the index is the **content-block**
        position (0 when no commentary; 1–2 after commentary text blocks),
        so the aggregator must key by ``tc_delta.index`` and never assume 0.

        Flush rules:
        - on ``choice.finish_reason`` boundary: yield one chunk with all
          aggregated tool calls and the upstream finish_reason.
        - defensive flush at stream end if pending state remains and no
          finish_reason chunk arrived (truncated upstream).
        """
        response = await client.chat.completions.create(**req_kwargs, stream=True)

        pending: dict[int, dict[str, str]] = {}
        flushed = False
        # Canary: aggregator currently consumes only choices[0]. Empirical
        # validation on GitHub Copilot (incl. sonnet-4.6, which DOES emit
        # multi-choice in non-streaming) shows the streaming relay flattens
        # to choices[0]. WorkPilot's _build_kwargs never sets `n>1`, so
        # multi-choice streaming is structurally unreachable today. If this
        # ever fires we'll know the assumption broke and need to add
        # choice-aware (choice.index, tc_delta.index) keying.
        multi_choice_warned = False

        async for chunk in response:
            if not chunk.choices:
                continue
            if len(chunk.choices) > 1 and not multi_choice_warned:
                logger.error(
                    "Chat stream returned {} choices for '{}'; multiple "
                    "streaming choices are not supported and only choices[0] "
                    "will be consumed. Non-primary choice content / tool_calls "
                    "are being dropped.",
                    len(chunk.choices),
                    resolved_model,
                )
                multi_choice_warned = True
            choice = chunk.choices[0]
            delta = choice.delta

            # Phase 1: accumulate tool-call deltas (state-only, never yielded
            # mid-stream — flushed at finish_reason boundary).
            if delta is not None and getattr(delta, "tool_calls", None):
                for tc_delta in delta.tool_calls:
                    idx = getattr(tc_delta, "index", 0)
                    if idx is None:
                        idx = 0
                    slot = pending.setdefault(idx, {"id": "", "name": "", "args": ""})
                    if getattr(tc_delta, "id", None):
                        slot["id"] = tc_delta.id
                    fn = getattr(tc_delta, "function", None)
                    if fn is not None:
                        if getattr(fn, "name", None):
                            slot["name"] = fn.name
                        if getattr(fn, "arguments", None):
                            slot["args"] += fn.arguments

            # Phase 2: emit a single LLMChunk for upstream chunks that carry
            # observable payload: content delta and/or, on finish_reason,
            # accumulated tool calls. Pure keepalive chunks (no content, no
            # finish_reason, no accumulated state to flush) are intentionally
            # not yielded.
            content = ""
            if delta is not None and getattr(delta, "content", None):
                content = delta.content

            finish_reason = choice.finish_reason
            tool_calls: list[ToolCallRequest] = []
            if finish_reason:
                tool_calls = _finalize_pending_tool_calls(pending)
                pending.clear()
                flushed = True
                # Match _merge_choices: if the upstream relay mislabels the
                # terminal chunk (e.g. finish_reason='stop' but tool calls
                # were emitted), normalize to 'tool_calls' so downstream
                # consumers that key off finish_reason still execute the tools.
                if tool_calls and finish_reason != "tool_calls":
                    finish_reason = "tool_calls"

            if content or finish_reason or tool_calls:
                yield LLMChunk(
                    content=content,
                    tool_calls=tool_calls,
                    finish_reason=finish_reason,
                    model=resolved_model,
                )

        if pending and not flushed:
            logger.warning(
                "Chat stream ended without finish_reason; flushing {} pending tool calls",
                len(pending),
            )
            yield LLMChunk(
                tool_calls=_finalize_pending_tool_calls(pending),
                finish_reason="tool_calls",
                model=resolved_model,
            )

    # ── Public API ─────────────────────────────────────────────────────────────

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
        items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> LLMResponse:
        if items is not None and messages:
            logger.warning(
                "Both items and messages provided; items takes precedence for Responses API"
            )
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(_no_credentials_message(model))

        result: LLMResponse | None = None
        resolved_model = model
        last_error: Exception | None = None

        # Gate 4 — 413 recovery state. The GH Copilot edge proxy 5 MiB
        # cap is shared across every fallback model, so a payload-too-
        # large 413 will hit every candidate identically. Shrink the
        # request body in-place and retry the SAME model before moving
        # on. Retry budget resets each time we ADVANCE to a new model
        # (not on every loop iteration — ``continue`` retries the same
        # idx with shrunk body, so retry_count must persist across them).
        payload_retry_count = 0

        idx = 0
        while idx < len(candidate_models):
            candidate = candidate_models[idx]
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages or [],
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )
            try:
                client = self._build_client(resolved_model, creds)
                call_args: dict[str, Any] = dict(
                    client=client,
                    resolved_model=resolved_model,
                    req_kwargs=req_kwargs,
                )
                if items is not None:
                    call_args["native_items"] = items
                    call_args["instructions"] = instructions
                    call_args["compact_threshold"] = compact_threshold

                # Build Chat-safe kwargs (strip native-only params)
                chat_args = {
                    k: v
                    for k, v in call_args.items()
                    if k not in ("native_items", "instructions", "compact_threshold")
                }
                # If items were provided, always derive Chat messages from them
                # (items are the authoritative source; any pre-existing messages
                # may be stale or incomplete)
                if items is not None:
                    chat_args["req_kwargs"] = dict(req_kwargs)
                    chat_args["req_kwargs"]["messages"] = _sanitize_messages(
                        items_to_chat_messages(items, instructions=instructions)
                    )

                if _should_prefer_responses_api(resolved_model):
                    # Responses API first; fallback to Chat if not required
                    try:
                        result = await self._complete_via_responses(**call_args)
                    except Exception as resp_exc:
                        if _must_use_responses_api(resolved_model):
                            raise
                        logger.warning(
                            "Responses API failed for '{}'; trying Chat Completions: {}",
                            resolved_model,
                            resp_exc,
                        )
                        try:
                            result = await self._complete_via_chat(**chat_args)
                        except Exception:
                            raise resp_exc  # both failed; raise original
                else:
                    # Chat Completions first; fallback to Responses on unsupported
                    try:
                        result = await self._complete_via_chat(**chat_args)
                    except Exception as exc:
                        if _is_chat_unsupported_error(exc):
                            logger.warning(
                                "Model '{}' does not support /chat/completions; "
                                "switching to Responses API",
                                resolved_model,
                            )
                            result = await self._complete_via_responses(**call_args)
                        else:
                            raise

                if idx > 0:
                    logger.warning(
                        "LLM fallback succeeded: '{}' -> '{}'",
                        candidate_models[0],
                        resolved_model,
                    )
                break

            except Exception as exc:
                last_error = exc
                logger.error("LLM error ({}): {}", resolved_model, exc)

                from workpilot.utils.token_errors import (
                    is_payload_too_large_error,
                    is_token_limit_error,
                )

                # Gate 4 — payload-too-large (HTTP 413) recovery.
                # All candidate models share the GH Copilot edge proxy,
                # so the next fallback would 413 with the same body.
                # Strategy: re-resolve with strict per-image / body caps
                # (which already drops images aggressively until body
                # fits 2 MiB) and retry the SAME model. If still 413
                # the non-image payload (tools / instructions / text)
                # alone exceeds the cap; raise so the agent loop can
                # compact + resubmit on the next user turn.
                if is_payload_too_large_error(exc):
                    if payload_retry_count == 0:
                        logger.warning(
                            "LLM 413 on {} — re-resolving with strict caps "
                            "(per-image {} / body {} bytes) and retrying same model",
                            resolved_model,
                            LLM_INLINE_IMAGE_DATA_URL_CAP_STRICT_BYTES,
                            LLM_REQUEST_BODY_BUDGET_STRICT_BYTES,
                        )
                        if items is not None:
                            items = _resolve_attachment_urls(
                                items,
                                max_inline_data_url_bytes=LLM_INLINE_IMAGE_DATA_URL_CAP_STRICT_BYTES,
                            )
                            items = _enforce_body_budget(
                                items,
                                budget_bytes=LLM_REQUEST_BODY_BUDGET_STRICT_BYTES,
                            )
                        if messages:
                            messages = _resolve_attachment_urls(
                                messages,
                                max_inline_data_url_bytes=LLM_INLINE_IMAGE_DATA_URL_CAP_STRICT_BYTES,
                            )
                            messages = _enforce_body_budget(
                                messages,
                                budget_bytes=LLM_REQUEST_BODY_BUDGET_STRICT_BYTES,
                            )
                        payload_retry_count = 1
                        continue  # retry SAME idx
                    # 2nd 413 on same model — strict-cap retry already
                    # dropped images aggressively (down to 2 MiB body),
                    # so the remaining non-image payload alone exceeds
                    # the proxy cap. Re-trying any fallback model burns
                    # API calls without changing the outcome. Raise
                    # instead.
                    logger.error(
                        "LLM 413 persisted on {} after strict-cap retry — "
                        "non-image payload exceeds the proxy cap; raising "
                        "because every fallback model shares the same edge proxy",
                        resolved_model,
                    )
                    raise

                # Token-limit errors: only try the next fallback if it has a
                # larger input limit (e.g. fast chain: gpt-5-mini 128K →
                # claude-haiku 136K).  Otherwise raise immediately so the
                # caller can compact and retry.
                if is_token_limit_error(exc):
                    if idx < len(candidate_models) - 1:
                        from workpilot.providers.model_catalog import get_max_input_tokens

                        current_limit = get_max_input_tokens(resolved_model)
                        next_limit = get_max_input_tokens(candidate_models[idx + 1])
                        if next_limit > current_limit:
                            logger.info(
                                "Token limit exceeded on {} ({}); trying {} ({}) with larger limit",
                                resolved_model,
                                current_limit,
                                candidate_models[idx + 1],
                                next_limit,
                            )
                            idx += 1
                            payload_retry_count = 0  # fresh budget per model
                            continue
                    raise

                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying LLM with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )
            idx += 1
            payload_retry_count = 0  # fresh budget per model

        if result is None:
            if last_error is not None:
                raise last_error
            raise RuntimeError("LLM completion failed without an exception")

        logger.debug(
            "LLM {}: {}+{} tokens, {:.0f}ms, {} tool calls{}",
            resolved_model,
            result.prompt_tokens,
            result.completion_tokens,
            result.duration_ms,
            len(result.tool_calls),
            " [reasoning]" if result.reasoning_content else "",
        )

        if self._usage:
            self._usage.record(
                model=resolved_model,
                prompt_tokens=result.prompt_tokens,
                completion_tokens=result.completion_tokens,
                duration_ms=result.duration_ms,
            )

        return result

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
        items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> AsyncIterator[LLMChunk]:
        if items is not None and messages:
            logger.warning(
                "Both items and messages provided; items takes precedence for Responses API"
            )
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(_no_credentials_message(model))

        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages or [],
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )

            try:
                client = self._build_client(resolved_model, creds)
                call_args: dict[str, Any] = dict(
                    client=client,
                    resolved_model=resolved_model,
                    req_kwargs=req_kwargs,
                )
                if items is not None:
                    call_args["native_items"] = items
                    call_args["instructions"] = instructions
                    call_args["compact_threshold"] = compact_threshold

                # Chat-safe req_kwargs for fallback (convert items → messages + sanitize).
                # When items are provided, always derive from them (authoritative source).
                chat_req_kwargs = dict(req_kwargs)
                if items is not None:
                    chat_req_kwargs["messages"] = _sanitize_messages(
                        items_to_chat_messages(items, instructions=instructions)
                    )

                if _should_prefer_responses_api(resolved_model):
                    # Responses API streaming first
                    emitted_any = False
                    try:
                        async for chunk in self._stream_via_responses(**call_args):
                            emitted_any = True
                            yield chunk
                        if idx > 0:
                            logger.warning(
                                "LLM stream fallback succeeded: '{}' -> '{}'",
                                candidate_models[0],
                                resolved_model,
                            )
                        return
                    except Exception as resp_exc:
                        if _must_use_responses_api(resolved_model) or emitted_any:
                            raise
                        # Fallback to Chat Completions streaming
                        logger.warning(
                            "Responses API stream failed for '{}'; trying Chat Completions: {}",
                            resolved_model,
                            resp_exc,
                        )
                        try:
                            async for chunk in self._stream_via_chat(
                                client=client,
                                resolved_model=resolved_model,
                                req_kwargs=chat_req_kwargs,
                            ):
                                yield chunk
                            return
                        except Exception:
                            raise resp_exc  # both failed; raise original

                else:
                    # Chat Completions streaming first
                    emitted_any = False
                    try:
                        async for chunk in self._stream_via_chat(
                            client=client,
                            resolved_model=resolved_model,
                            req_kwargs=chat_req_kwargs,
                        ):
                            emitted_any = True
                            yield chunk
                        if idx > 0:
                            logger.warning(
                                "LLM stream fallback succeeded: '{}' -> '{}'",
                                candidate_models[0],
                                resolved_model,
                            )
                        return
                    except Exception as exc:
                        # Create-time "unsupported on /chat/completions" only
                        # surfaces on the first iteration of the helper's async
                        # generator. Distinguish from mid-stream errors via
                        # ``not emitted_any``.
                        if not emitted_any and _is_chat_unsupported_error(exc):
                            logger.warning(
                                "Model '{}' does not support /chat/completions; "
                                "switching to Responses API stream",
                                resolved_model,
                            )
                            async for chunk in self._stream_via_responses(**call_args):
                                yield chunk
                            return
                        last_error = exc
                        logger.error(
                            "LLM stream iteration error ({}): {}",
                            resolved_model,
                            exc,
                        )
                        if emitted_any or idx >= len(candidate_models) - 1:
                            raise
                        logger.warning(
                            "Retrying stream with fallback model '{}' after early "
                            "stream failure in '{}'",
                            candidate_models[idx + 1],
                            resolved_model,
                        )

            except Exception as exc:
                last_error = exc
                logger.error("LLM stream error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying stream with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )
                    continue
                raise

        if last_error is not None:
            raise last_error
        raise RuntimeError("LLM stream failed without an exception")
