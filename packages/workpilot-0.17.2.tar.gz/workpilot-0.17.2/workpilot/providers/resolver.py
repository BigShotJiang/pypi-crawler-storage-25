"""
Provider resolver — model alias expansion, credential lookup, and provider factory.

Secrets are read from config (primary) or environment (fallback) and
passed as arguments to SDK clients — never written to ``os.environ``.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

if TYPE_CHECKING:
    from workpilot.providers.client import OpenAIProvider

from loguru import logger
from pydantic import SecretStr

from workpilot.config.schema import ProvidersConfig

# ── helpers ──────────────────────────────────────────────────────────────────


def _secret(value: SecretStr | None) -> str | None:
    """Unwrap a SecretStr, returning *None* for empty / missing / unresolved values."""
    if value is None:
        return None
    plain = value.get_secret_value()
    if not plain:
        return None
    if isinstance(plain, str) and plain.startswith("SECRET["):
        return None  # unresolved SECRET[name] reference — treat as missing
    return plain


def _secret_or_env(value: SecretStr | None, *env_names: str) -> str | None:
    """Return the config value if set, otherwise fall back to secret store / env vars.

    Priority: config SecretStr → SecretStore → os.environ.
    We only *read* — we never write to ``os.environ``.
    """
    result = _secret(value)
    if result:
        return result

    # Check SecretStore (encrypted local store / keyring)
    try:
        from workpilot.security.secrets import get_secret_store

        store = get_secret_store()
        for name in env_names:
            result = store.get(name)
            if result:
                return result
    except Exception as exc:
        from loguru import logger

        logger.debug("Secret store unavailable, falling back to env: {}", exc)

    for name in env_names:
        result = os.environ.get(name)
        if result:
            from loguru import logger

            logger.warning(
                "Secret '{}' loaded from environment variable (plaintext). "
                "For better security, run: workpilot secrets set {}",
                name,
                name,
            )
            return result
    return None


# ── auto-resolution ──────────────────────────────────────────────────────────

# Each entry: (check_fn, model_or_fn, label)
# - check_fn(p)    → truthy when provider is configured
# - model_or_fn    → concrete model string, OR callable(p) → str for dynamic selection
# check_fn / model_or_fn both receive ProvidersConfig.


def _openai_configured(p: ProvidersConfig) -> bool:
    """True when an OpenAI-compatible API key is available (config or env)."""
    return bool(
        _secret_or_env(
            p.openai.api_key,
            "OPENAI_API_KEY",
            "AZURE_API_KEY",
            "AZURE_OPENAI_API_KEY",
            "AZURE_AI_FOUNDRY_API_KEY",
        )
    )


def _resolve_endpoint(p: ProvidersConfig) -> str:
    """Return the configured endpoint, checking config then all known env vars."""
    return (
        p.openai.endpoint
        or os.environ.get("OPENAI_ENDPOINT", "")
        or os.environ.get("AZURE_OPENAI_ENDPOINT", "")
        or os.environ.get("AZURE_AI_FOUNDRY_ENDPOINT", "")
    )


def _is_azure_openai(endpoint: str) -> bool:
    """Check if endpoint is Azure OpenAI Service (*.openai.azure.com)."""
    try:
        # urlparse needs a scheme to populate hostname; add one if missing
        url = endpoint if "://" in endpoint else f"https://{endpoint}"
        hostname = urlparse(url).hostname or ""
        return hostname.endswith(".openai.azure.com")
    except Exception:
        return False


def _openai_model(p: ProvidersConfig) -> str:
    """Return the appropriate model prefix based on the configured endpoint.

    no endpoint          → openai/gpt-4o   (OpenAI direct)
    *.openai.azure.com   → azure/gpt-4o    (Azure OpenAI Service)
    anything else        → azure_ai/gpt-4o (Azure AI Foundry / custom)
    """
    endpoint = _resolve_endpoint(p)
    if not endpoint:
        return "openai/gpt-4o"
    if _is_azure_openai(endpoint):
        return "azure/gpt-4o"
    return "azure_ai/gpt-4o"


# Known aliases that get special resolution.
# Exposed as a module-level public name so other provider modules
# (e.g. ``client.py``) can reference it without reaching into internals.
ALIASES = frozenset({"auto", "fast", "reasoning", "coding"})


def _openai_fast_model(p: ProvidersConfig) -> str:
    """Fast variant of the configured OpenAI-compatible endpoint."""
    endpoint = _resolve_endpoint(p)
    if not endpoint:
        return "openai/gpt-4o-mini"
    if _is_azure_openai(endpoint):
        return "azure/gpt-4o-mini"
    return "azure_ai/gpt-4o-mini"


def _openai_reasoning_model(p: ProvidersConfig) -> str:
    """Reasoning variant of the configured OpenAI-compatible endpoint."""
    endpoint = _resolve_endpoint(p)
    if not endpoint:
        return "openai/o1"
    if _is_azure_openai(endpoint):
        return "azure/o1"
    return "azure_ai/o1"


def _github_configured(p: ProvidersConfig) -> bool:
    return bool(_secret_or_env(p.github_copilot.token, "GITHUB_COPILOT_TOKEN", "GITHUB_TOKEN"))


def list_available_models(providers: ProvidersConfig) -> tuple[list[str], str]:
    """Return ``(github/* model IDs, source)`` available to the authenticated user.

    ``source`` is one of:
    - ``"live"``    — fetched from the Copilot ``/models`` API; filtered to chat
                      models with ``model_picker_enabled`` (actual Copilot
                      entitlements, cached 5 min)
    - ``"catalog"`` — API unreachable or returned a malformed payload; fell
                      back to the static catalog (broader: includes non-Copilot
                      ``github/*`` GitHub Models)
    - ``"none"``    — no GitHub token could be resolved from config, secret
                      store, or environment

    TODO: extend to ``openai/*`` / ``azure/*`` once those providers expose a
    comparable listing endpoint.
    """
    token = _secret_or_env(providers.github_copilot.token, "GITHUB_COPILOT_TOKEN", "GITHUB_TOKEN")
    if not token:
        return [], "none"

    from workpilot.security.github_auth import list_copilot_models

    live = list_copilot_models(token)
    if live is None:
        # API unreachable or schema broken — use the static catalog as a
        # best-effort fallback.
        from workpilot.providers.model_catalog import CONTEXT_WINDOW

        return sorted(k for k in CONTEXT_WINDOW if k.startswith("github/")), "catalog"

    models: set[str] = set()
    for m in live:
        if not isinstance(m, dict):
            continue  # defensive: tolerate unexpected items without crashing
        caps = m.get("capabilities") or {}
        if not isinstance(caps, dict):
            continue
        if caps.get("type") != "chat" or not m.get("model_picker_enabled"):
            continue
        mid = m.get("id")
        if not isinstance(mid, str):
            continue
        # Normalize to match scripts/update_model_catalog.py ingestion so
        # /model output collates with the static catalog keys.
        mid = mid.strip().lower()
        if mid:
            models.add(f"github/{mid}")
    return sorted(models), "live"


# Exposed as module-level public names so other provider modules can
# enforce the same "<provider>/<name>" contract without duplicating the
# tuple or the validation helper.
KNOWN_PROVIDER_PREFIXES: tuple[str, ...] = (
    "github/",
    "github_copilot/",
    "openai/",
    "azure/",
    "azure_ai/",
)


def is_supported_model_id(value: str) -> bool:
    """True when ``value`` is ``<supported-provider>/<non-empty-name>``.

    Rejects prefix-only strings like ``github/`` — they satisfy
    ``startswith`` but have no model name and would produce a confusing
    upstream error when dispatched as-is.
    """
    for prefix in KNOWN_PROVIDER_PREFIXES:
        if value.startswith(prefix) and len(value) > len(prefix):
            return True
    return False


def describe_resolution_failure(model: str) -> str:
    """Explain why model/provider resolution could not proceed for ``model``.

    Centralises the error wording so every call site renders the same
    taxonomy. Two resolution paths share this helper:

    * ``resolve_model()`` and ``OpenAIProvider.complete()`` / ``stream()``
      call it when ``resolve_model_chain(model)`` returns an empty list
      (alias expanded to nothing; ID was malformed).
    * ``OpenAIProvider._build_client()`` calls it when ``resolve_credentials()``
      returned no ``api_key`` for a valid, prefixed concrete ID (case 3
      below).

    Distinguishes three cases:

    1. alias — either no provider credentials configured OR every
       configured candidate was dropped as unsupported (the message
       covers both because the helper cannot tell them apart without
       the ``ProvidersConfig``; callers who want a more specific
       error can special-case their branch)
    2. concrete ID that is not ``<provider>/<name>``
    3. concrete ID with a supported prefix but no credentials for it
    """
    if model in ALIASES:
        return (
            f"Cannot resolve alias '{model}': no candidate produced a valid "
            "`<provider>/<name>` ID. Two possible causes: "
            "(a) no provider credentials are configured, or "
            "(b) the alias / routing candidate list contains no supported entries "
            "(check warning logs above for dropped candidates). "
            "Run `wp init` to re-run setup, or `wp secrets set` one of: "
            "`GITHUB_COPILOT_TOKEN` (Copilot) / "
            "`OPENAI_API_KEY` (OpenAI) / "
            "`AZURE_OPENAI_API_KEY` (Azure OpenAI; also set `AZURE_OPENAI_ENDPOINT`) / "
            "`AZURE_AI_FOUNDRY_API_KEY` (Azure AI Foundry; also set "
            "`AZURE_AI_FOUNDRY_ENDPOINT`)."
        )
    if not is_supported_model_id(model):
        supported = ", ".join(p.rstrip("/") for p in KNOWN_PROVIDER_PREFIXES)
        return (
            f"Cannot resolve model '{model}': not a valid "
            f"`<provider>/<name>` identifier (supported providers: {supported}). "
            "Use `/model` or `--model` with a prefixed ID, or switch to an alias "
            "(auto, fast, reasoning, coding)."
        )
    provider = model.split("/", 1)[0]
    github_hint = (
        "Run `wp init` to re-run setup (GitHub device flow), or "
        "`wp secrets set GITHUB_COPILOT_TOKEN` to paste an existing token."
    )
    hint = {
        "github": github_hint,
        "github_copilot": github_hint,
        "openai": "Run `wp init` to re-run setup, or `wp secrets set OPENAI_API_KEY`.",
        "azure": (
            "Run `wp init` to re-run setup, or `wp secrets set AZURE_OPENAI_API_KEY` "
            "(and set AZURE_OPENAI_ENDPOINT)."
        ),
        "azure_ai": (
            "Run `wp init` to re-run setup, or `wp secrets set AZURE_AI_FOUNDRY_API_KEY` "
            "(and set the endpoint)."
        ),
    }.get(provider, f"Provider '{provider}' is not wired up; no credential resolver exists.")
    return f"No provider credentials configured for '{model}'. {hint}".rstrip()


def _resolve_routing_candidate(
    entry: str,
    providers: ProvidersConfig,
    *,
    require_credentials_for_concrete: bool = True,
) -> str | None:
    """Resolve a configured candidate entry into a concrete model ID.

    Returns ``None`` (with a warning) when the entry is not namespaced
    under a supported provider — guarantees the strict prefix contract
    holds even for candidates sourced from user-configured alias /
    routing lists, not only direct ``/model`` input.
    """
    value = entry.strip()
    if not value:
        return None

    lowered = value.lower()
    if lowered == "openai:auto":
        return _openai_model(providers) if _openai_configured(providers) else None
    if lowered == "openai:fast":
        return _openai_fast_model(providers) if _openai_configured(providers) else None
    if lowered == "openai:reasoning":
        return _openai_reasoning_model(providers) if _openai_configured(providers) else None

    if value.startswith(("github/", "github_copilot/")):
        if require_credentials_for_concrete:
            return value if _github_configured(providers) else None
        return value
    if value.startswith(("openai/", "azure/", "azure_ai/")):
        if require_credentials_for_concrete:
            return value if _openai_configured(providers) else None
        return value

    logger.warning(
        "Routing candidate '{}' is not namespaced under a supported provider "
        "({}); dropping. Configure alias / routing lists with `<provider>/<name>` "
        "entries or the `openai:auto` / `openai:fast` / `openai:reasoning` tokens.",
        value,
        ", ".join(p.rstrip("/") for p in KNOWN_PROVIDER_PREFIXES),
    )
    return None


def resolve_model_chain(model: str, providers: ProvidersConfig | None = None) -> list[str]:
    """Resolve a model/alias into ordered concrete candidates.

    The first entry is the preferred model. Remaining entries are ordered
    failover candidates for runtime fallback.

    A concrete model ID must be namespaced under a supported provider —
    one of ``github/``, ``github_copilot/``, ``openai/``, ``azure/``, or
    ``azure_ai/``. Anything else (bare names like ``gpt-5.4-2026-03-05``
    that leak from the Copilot Responses API body, typos, or unsupported
    providers) is rejected with an empty chain so callers fail fast with
    a useful message rather than silently missing the credential lookup.
    """
    if model not in ALIASES:
        if is_supported_model_id(model):
            return [model]
        logger.warning(
            "Model '{}' is not a valid `<provider>/<name>` identifier "
            "(supported providers: {}). Refusing to resolve.",
            model,
            ", ".join(p.rstrip("/") for p in KNOWN_PROVIDER_PREFIXES),
        )
        return []

    if providers is None:
        logger.warning(
            "No provider config found for '{}' resolution; no fallback candidates available",
            model,
        )
        return []

    candidates: list[str] = []

    def _append_unique(value: str) -> None:
        if value and value not in candidates:
            candidates.append(value)

    def _expand(entries: list[str]) -> None:
        for entry in entries:
            resolved = _resolve_routing_candidate(entry, providers)
            if resolved:
                _append_unique(resolved)

    # Check user-configured alias mapping first.
    alias_map = {
        "auto": providers.aliases.default,
        "fast": providers.aliases.fast,
        "reasoning": providers.aliases.reasoning,
        "coding": providers.aliases.coding,
    }
    configured: Any = alias_map.get(model, "auto")
    has_alias_override = False

    def _expand_alias_item(item: str) -> None:
        # "auto" inside a list means: expand this alias' default routing candidates.
        if item == "auto":
            if model == "fast":
                _expand(providers.routing.fast_candidates)
            elif model == "reasoning":
                _expand(providers.routing.reasoning_candidates)
            else:
                _expand(providers.routing.default_candidates)
            return

        if item in ALIASES:
            if item == model:
                return
            for entry in resolve_model_chain(item, providers):
                _append_unique(entry)
            return

        resolved = _resolve_routing_candidate(
            item,
            providers,
            require_credentials_for_concrete=False,
        )
        if resolved:
            _append_unique(resolved)

    if isinstance(configured, list):
        has_alias_override = True
        logger.debug("Alias '{}' resolved via configured candidate list", model)
        for item in configured:
            if isinstance(item, str):
                _expand_alias_item(item)
    elif configured != "auto":
        has_alias_override = True
        logger.debug("Alias '{}' resolved to '{}' via config", model, configured)
        if configured in ALIASES:
            if configured != model:
                for entry in resolve_model_chain(configured, providers):
                    _append_unique(entry)
        else:
            resolved = _resolve_routing_candidate(
                str(configured),
                providers,
                require_credentials_for_concrete=False,
            )
            if resolved:
                _append_unique(resolved)

    # Alias-specific auto-resolution candidates
    if not has_alias_override:
        if model == "fast":
            _expand(providers.routing.fast_candidates)
        elif model == "reasoning":
            _expand(providers.routing.reasoning_candidates)
        elif model in ("coding", "auto"):
            _expand(providers.routing.default_candidates)

    # For auto/coding we already expanded default candidates above.
    # Keep fast/reasoning chains scoped to their tier, then add only
    # the ultimate fallback model below.

    # Only add OpenAI fallback when an OpenAI-compatible key is configured.
    # Derive the fallback from the configured endpoint so Azure/Foundry users
    # get the right client type (azure/* or azure_ai/*) rather than openai/*.
    if _openai_configured(providers):
        _append_unique(_openai_model(providers))
    elif not candidates:
        logger.warning(
            "No provider credentials found for '{}' resolution and OpenAI key is not configured",
            model,
        )

    return candidates


def resolve_model(model: str, providers: ProvidersConfig | None = None) -> str:
    """Resolve model aliases to the preferred concrete model ID."""
    chain = resolve_model_chain(model, providers)
    if not chain:
        # Delegate wording to the shared helper so the error matches the
        # specific failure mode (invalid prefix, alias-no-creds, etc.)
        # rather than always blaming "alias credentials".
        raise ValueError(describe_resolution_failure(model))
    return chain[0]


# Hardcoded fallbacks when nothing in the user's routing supports vision.
# Ordered by provider credential availability.
_VISION_DEFAULTS_GITHUB = "github/gpt-4.1"
_VISION_DEFAULTS_OPENAI = "openai/gpt-4.1"
_VISION_DEFAULTS_AZURE = "azure/gpt-4.1"


def resolve_vision_model(
    current_model: str,
    providers: ProvidersConfig | None = None,
) -> str | None:
    """Pick a vision-capable model for a turn with image attachments.

    Search order:
    1. If *current_model* already supports vision, return it.
    2. Walk ``resolve_model_chain('auto', providers)`` and return the first
       candidate that supports vision — honours the user's configured routing.
    3. Fall back to a sensible default based on which provider has credentials.

    Returns ``None`` only when no provider credentials are configured at all.
    """
    from workpilot.providers.model_catalog import supports_vision

    if supports_vision(current_model):
        return current_model

    if providers is not None:
        for candidate in resolve_model_chain("auto", providers):
            if supports_vision(candidate):
                return candidate

    if providers is None:
        return None
    if _github_configured(providers):
        return _VISION_DEFAULTS_GITHUB
    if _openai_configured(providers):
        endpoint = _resolve_endpoint(providers)
        if endpoint and _is_azure_openai(endpoint):
            return _VISION_DEFAULTS_AZURE
        return _VISION_DEFAULTS_OPENAI
    return None


# ── credential resolution ────────────────────────────────────────────────────


def resolve_credentials(model: str, providers: ProvidersConfig) -> dict[str, Any]:
    """Return litellm kwargs (``api_key``, ``api_base``, …) for *model*.

    Config values take priority; environment variables are a read-only
    fallback.  Nothing is written to ``os.environ``.
    """
    kwargs: dict[str, Any] = {}

    if model.startswith(("github/", "github_copilot/")):
        # The device-flow OAuth token has Copilot access, not GitHub Models
        # access.  Exchange it for a Copilot session token and route through
        # the Copilot API (OpenAI-compatible).
        github_token = _secret_or_env(
            providers.github_copilot.token, "GITHUB_COPILOT_TOKEN", "GITHUB_TOKEN"
        )
        if github_token:
            from workpilot.security.github_auth import (
                _COPILOT_HEADERS,
                get_copilot_api_base,
                get_copilot_token,
            )

            kwargs["api_key"] = get_copilot_token(github_token)
            kwargs["api_base"] = get_copilot_api_base()
            kwargs["extra_headers"] = _COPILOT_HEADERS

    elif model.startswith(("openai/", "azure/", "azure_ai/")):
        key = _secret_or_env(
            providers.openai.api_key,
            "OPENAI_API_KEY",
            "AZURE_API_KEY",
            "AZURE_OPENAI_API_KEY",
            "AZURE_AI_FOUNDRY_API_KEY",
        )
        if key:
            kwargs["api_key"] = key
        endpoint = _resolve_endpoint(providers)
        if endpoint:
            kwargs["api_base"] = endpoint
        if providers.openai.api_version and model.startswith(("azure/", "azure_ai/")):
            kwargs["api_version"] = providers.openai.api_version

    return kwargs


# ── factory ──────────────────────────────────────────────────────────────────


def get_provider(providers: ProvidersConfig | None = None) -> OpenAIProvider:
    """Create and return a configured OpenAI-compatible provider."""
    from workpilot.providers.client import OpenAIProvider

    return OpenAIProvider(providers=providers)
