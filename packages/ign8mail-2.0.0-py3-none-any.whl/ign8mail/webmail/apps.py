from django.apps import AppConfig


class WebmailConfig(AppConfig):
    name = "ign8mail.webmail"
    label = "webmail"
