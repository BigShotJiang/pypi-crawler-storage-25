# ankor

Workflow monitoring and management for FastAPI apps.

`ankor` adds a self-hosted dashboard and run-tracking API to **any FastAPI application**. Decorate Python functions with `@gtm.workflow` and choose how they are triggered: manually, on a cron schedule, or via a webhook.

**[Full documentation → DOCS.md](../DOCS.md)**

## Install

```bash
pip install ankor

# Required for cron-scheduled workflows:
pip install apscheduler
```

## Quick start

```python
import os
from fastapi import FastAPI
from ankor import ankor

app = FastAPI()

gtm = ankor(
    app,
    db_url=os.environ["GTM_DB_URL"],
    secret=os.environ["GTM_SECRET"],
)

@gtm.workflow
async def enrich_leads(inputs: dict):
    results = call_some_api(inputs["leads"])
    return {"enriched": results}

@gtm.workflow(cron="0 9 * * 1-5")
async def daily_sync(inputs: dict):
    return {"synced": sync_database()}

@gtm.workflow(webhook=True)
async def process_event(inputs: dict):
    return handle(inputs)
```

This mounts the dashboard at `/admin/` and the REST API at `/api/*` on your FastAPI app. See [DOCS.md](../DOCS.md) for the full reference — constructor options, workflow decorator options, nodes, config store, data tables (including row filtering with `RowFilter`, column selection, and ordering with `OrderBy`), and deployment.

## API Routes

All routes are mounted under `/api` on your FastAPI app.

| Method    | Path                                | Auth | Description                                |
| --------- | ----------------------------------- | ---- | ------------------------------------------ |
| POST      | `/api/auth/token`                   | —    | Log in; returns a JWT access token         |
| POST      | `/api/auth/register`                | ✓    | Register a new user account                |
| GET       | `/api/auth/setup-status`            | —    | Check whether initial setup is required    |
| POST      | `/api/auth/setup`                   | —    | Create the first admin account             |
| GET       | `/api/health`                       | —    | Health check                               |
| POST      | `/api/webhooks/{name}`              | —    | Invoke a webhook-enabled workflow          |
| GET       | `/api/workflow-runs`                | ✓    | Paginated list of runs (filterable)        |
| GET       | `/api/workflow-runs/stats`          | ✓    | Status counts + active/recent run lists    |
| GET       | `/api/workflow-runs/{id}`           | ✓    | Full run detail with nodes                 |
| POST      | `/api/workflow-runs/{id}/rerun`     | ✓    | Re-execute a workflow with the same inputs |
| POST      | `/api/workflow-runs/{id}/cancel`    | ✓    | Cancel a specific pending or running run   |
| POST      | `/api/workflow-runs/cancel-pending` | ✓    | Cancel all pending (queued) runs           |
| POST      | `/api/workflow-runs/cancel-all`     | ✓    | Cancel all pending and running runs        |
| GET       | `/api/execution-buckets`            | ✓    | Time-bucketed run counts (charting)        |
| GET       | `/api/workflows`                    | ✓    | List all registered workflow definitions   |
| GET       | `/api/workflows/{name}`             | ✓    | Single workflow definition + stats         |
| PATCH     | `/api/workflows/{name}`             | ✓    | Override cron, timeout, concurrency limit  |
| POST      | `/api/workflows/{name}/trigger`     | ✓    | Manually trigger a workflow                |
| GET       | `/api/configs`                      | ✓    | List all config records                    |
| POST      | `/api/configs`                      | ✓    | Create a config record                     |
| PATCH     | `/api/configs/{id}`                 | ✓    | Update a config record                     |
| DELETE    | `/api/configs/{id}`                 | ✓    | Delete a config record                     |
| GET       | `/api/db-tables`                    | ✓    | List all data tables                       |
| POST      | `/api/db-tables`                    | ✓    | Create a table                             |
| PATCH     | `/api/db-tables/{id}`               | ✓    | Update a table's schema or rows            |
| DELETE    | `/api/db-tables/{id}`               | ✓    | Delete a table                             |
| GET       | `/api/users`                        | ✓    | List all users                             |
| POST      | `/api/users`                        | ✓    | Create a user                              |
| DELETE    | `/api/users/{username}`             | ✓    | Delete a user                              |
| PATCH     | `/api/users/{username}/password`    | ✓    | Change a user's password                   |
| GET       | `/api/tokens`                       | ✓    | List API tokens for the current user       |
| POST      | `/api/tokens`                       | ✓    | Create an API token                        |
| DELETE    | `/api/tokens/{id}`                  | ✓    | Revoke an API token                        |
| GET       | `/api/webhook-token`                | ✓    | Get the webhook signing token              |
| POST      | `/api/webhook-token/rotate`         | ✓    | Rotate the webhook signing token           |
| WebSocket | `/api/ws?token=<jwt>`               | ✓    | Real-time event stream                     |
| GET       | `/admin/`                           | —    | Dashboard SPA                              |

## Package structure

```
api/
├── src/ankor/          # The published library
│   ├── __init__.py         # Exports ankor, RowFilter, OrderBy
│   ├── core.py             # ankor class — mounts router + dashboard
│   ├── auth.py             # JWT creation/verification + bcrypt helpers
│   ├── broadcast.py        # WebSocket pub/sub manager
│   ├── config_store.py     # gtm.config — programmatic config access
│   ├── csv_import.py       # CSV import helpers for data tables
│   ├── database.py         # Async SQLAlchemy engine + session factory + migrations
│   ├── db_store.py         # gtm.db — programmatic data table access (RowFilter, OrderBy)
│   ├── decorator/          # @gtm.workflow / @gtm.node wrappers + run tracking
│   │   ├── __init__.py
│   │   ├── _context.py     # Context vars and shared state dicts
│   │   ├── _drain.py       # Pending-run drain loop + concurrency control
│   │   ├── _execution.py   # Run execution state machine
│   │   ├── _persistence.py # Snapshot persistence helpers
│   │   ├── _serialization.py # Run/node serializers
│   │   ├── node.py         # make_node_wrapper, log, plan, record_db_action
│   │   └── workflow.py     # make_workflow_wrapper
│   ├── deps.py             # get_current_user FastAPI dependency
│   ├── models.py           # WorkflowRun, User, ConfigRecord, DbTable SQLModel models
│   ├── routers/            # All API route handlers + Pydantic response schemas
│   │   ├── __init__.py     # create_router factory
│   │   ├── auth.py         # /auth/* endpoints
│   │   ├── config.py       # /configs/* endpoints
│   │   ├── db_tables.py    # /db-tables/* endpoints
│   │   ├── runs.py         # /workflow-runs/* endpoints
│   │   ├── schemas.py      # Pydantic response models
│   │   ├── users.py        # /users/*, /tokens/*, /webhook-token/* endpoints
│   │   ├── websocket.py    # /ws WebSocket endpoint
│   │   └── workflows.py    # /workflows/* endpoints
│   ├── router.py           # Backward-compat shim — re-exports from routers/
│   ├── seed.py             # Demo data seeder (used by auto_seed=True)
│   ├── trigger_context.py  # TriggerContext dataclass
│   └── static/             # Built React SPA (populated by `pnpm run build`)
├── hatch_build.py          # Build hook — runs `pnpm run build` before packaging
└── pyproject.toml          # Package metadata + hatchling build config
```

## Local development

```bash
cd api
cp .env.example .env        # Set DATABASE_URL and SECRET_KEY
uv sync
uv run alembic upgrade head
uv run python seed.py       # Optional: seed demo data
```

Run the standalone dev server from the monorepo root:

```bash
make dev-api      # FastAPI on :8080 with GTM_DEV=true
make dev-frontend # Vite on :5173 (run concurrently for HMR)
make dev          # Both at once
```

## Requirements

- Python 3.11+
- PostgreSQL database (Supabase, Neon, or self-hosted)
- FastAPI app

## License

MIT
