from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from ankor.database import get_session
from ankor.deps import get_current_user
from ankor.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from ankor.router import create_router
from ankor.trigger_context import TriggerContext


def _build_run(
    name: str = "my_workflow",
    triggered_by: str = "manual",
    trigger_context: dict | None = None,
) -> tuple[WorkflowRun, str]:
    tc = (
        trigger_context
        if trigger_context is not None
        else {
            "type": triggered_by,
            "inputs": {"foo": "bar"},
        }
    )
    run = WorkflowRun(
        id=1,
        workflow_id=1,
        status=WorkflowStatus.success,
        triggered_by=TriggerType(triggered_by),
        data={"trigger_context": tc, "nodes": [], "inputs": {}, "outputs": {}},
    )
    return run, name


def _make_client(
    run: WorkflowRun | None, workflow_name: str = "my_workflow", invoke=None
):
    captured: dict = {}

    async def default_invoke(name: str, ctx: TriggerContext) -> None:
        captured["name"] = name
        captured["ctx"] = ctx

    app = FastAPI()
    router = create_router({}, invoke=invoke or default_invoke)
    app.include_router(router, prefix="/api")

    async def _override_session():
        session = AsyncMock()

        wf = Workflow(id=1, name=workflow_name) if run is not None else None

        async def _mock_get(model_cls, pk):
            if model_cls is WorkflowRun:
                return run
            if model_cls is Workflow:
                return wf
            return None

        session.get = _mock_get
        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")

    return TestClient(app), captured


def test_rerun_run_not_found():
    client, _ = _make_client(run=None)
    resp = client.post("/api/workflow-runs/9999/rerun")
    assert resp.status_code == 404


def test_rerun_workflow_not_registered():
    run, _ = _build_run(name="gone_workflow")

    async def invoke_raises(name: str, ctx: TriggerContext) -> None:
        raise KeyError(name)

    client, _ = _make_client(
        run=run, workflow_name="gone_workflow", invoke=invoke_raises
    )
    resp = client.post(f"/api/workflow-runs/{run.id}/rerun")
    assert resp.status_code == 404
    assert "gone_workflow" in resp.json()["detail"]


def test_rerun_manual_success():
    run, _ = _build_run(
        triggered_by="manual",
        trigger_context={
            "type": "manual",
            "inputs": {"foo": "bar"},
        },
    )
    client, captured = _make_client(run=run)
    resp = client.post(f"/api/workflow-runs/{run.id}/rerun")
    assert resp.status_code == 202
    assert resp.json() == {"status": "accepted"}

    ctx: TriggerContext = captured["ctx"]
    assert ctx.type == "rerun"
    assert ctx.inputs == {"foo": "bar"}
    assert ctx.metadata["originalType"] == "manual"
    assert ctx.metadata["originalRunId"] == str(run.id)


def test_rerun_webhook_preserves_body_and_headers():
    run, _ = _build_run(
        triggered_by="webhook",
        trigger_context={
            "type": "webhook",
            "inputs": {
                "body": {"email": "x@x.com"},
                "headers": {"content-type": "application/json", "x-trace-id": "abc"},
            },
        },
    )
    client, captured = _make_client(run=run)
    resp = client.post(f"/api/workflow-runs/{run.id}/rerun")
    assert resp.status_code == 202

    ctx: TriggerContext = captured["ctx"]
    assert ctx.type == "rerun"
    assert ctx.inputs["body"]["email"] == "x@x.com"
    assert ctx.inputs["headers"]["x-trace-id"] == "abc"
    assert ctx.metadata["originalType"] == "webhook"


def test_rerun_cron_preserves_schedule():
    run, _ = _build_run(
        triggered_by="cron",
        trigger_context={
            "type": "cron",
            "inputs": {},
            "schedule": "0 9 * * 1-5",
        },
    )
    client, captured = _make_client(run=run)
    resp = client.post(f"/api/workflow-runs/{run.id}/rerun")
    assert resp.status_code == 202

    ctx: TriggerContext = captured["ctx"]
    assert ctx.metadata["schedule"] == "0 9 * * 1-5"
    assert ctx.metadata["originalType"] == "cron"


def test_rerun_legacy_run_empty_trigger_context():
    """Runs that predate the trigger_context column use triggered_by as fallback."""
    run, _ = _build_run(triggered_by="webhook", trigger_context={})
    client, captured = _make_client(run=run)
    resp = client.post(f"/api/workflow-runs/{run.id}/rerun")
    assert resp.status_code == 202

    ctx: TriggerContext = captured["ctx"]
    assert ctx.metadata["originalType"] == "webhook"
    assert ctx.inputs == {}


def test_rerun_dispatches_correct_workflow_name():
    run, _ = _build_run(name="enrich_leads")
    client, captured = _make_client(run=run, workflow_name="enrich_leads")
    client.post(f"/api/workflow-runs/{run.id}/rerun")
    assert captured["name"] == "enrich_leads"
