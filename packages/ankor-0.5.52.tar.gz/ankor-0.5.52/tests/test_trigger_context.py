import pytest

from ankor.trigger_context import TriggerContext, _safe_headers


def test_roundtrip_manual():
    ctx = TriggerContext("manual", {"key": "value"})
    restored = TriggerContext.from_db(ctx.to_db())
    assert restored.type == "manual"
    assert restored.inputs == {"key": "value"}
    assert restored.metadata == {}


def test_roundtrip_webhook_with_headers():
    ctx = TriggerContext(
        "webhook",
        {"body": {"email": "x@x.com"}, "headers": {"content-type": "application/json"}},
    )
    restored = TriggerContext.from_db(ctx.to_db())
    assert restored.type == "webhook"
    assert restored.inputs["body"]["email"] == "x@x.com"
    assert restored.inputs["headers"]["content-type"] == "application/json"
    assert restored.metadata == {}


def test_roundtrip_rerun_preserves_metadata():
    ctx = TriggerContext(
        "rerun",
        {"body": {"email": "x@x.com"}, "headers": {}},
        {"original_type": "webhook", "original_run_id": "abc-123"},
    )
    restored = TriggerContext.from_db(ctx.to_db())
    assert restored.type == "rerun"
    assert restored.metadata["original_type"] == "webhook"
    assert restored.metadata["original_run_id"] == "abc-123"


def test_from_db_empty_dict():
    ctx = TriggerContext.from_db({})
    assert ctx.type == "manual"
    assert ctx.inputs == {}
    assert ctx.metadata == {}


def test_from_db_legacy_no_inputs_key():
    ctx = TriggerContext.from_db({"type": "cron", "schedule": "0 9 * * 1-5"})
    assert ctx.type == "cron"
    assert ctx.inputs == {}
    assert ctx.metadata == {"schedule": "0 9 * * 1-5"}


def test_to_db_merges_metadata_at_top_level():
    ctx = TriggerContext("cron", {}, {"schedule": "interval:10s"})
    db = ctx.to_db()
    assert db["type"] == "cron"
    assert db["inputs"] == {}
    assert db["schedule"] == "interval:10s"


def test_safe_headers_strips_sensitive():
    headers = {
        "content-type": "application/json",
        "x-trace-id": "abc",
        "Authorization": "Bearer secret",
        "Cookie": "session=xyz",
        "Set-Cookie": "id=xyz",
        "X-Api-Key": "secret",
    }
    safe = _safe_headers(headers)
    assert safe["content-type"] == "application/json"
    assert safe["x-trace-id"] == "abc"
    assert "Authorization" not in safe
    assert "Cookie" not in safe
    assert "Set-Cookie" not in safe
    assert "X-Api-Key" not in safe


def test_safe_headers_case_insensitive_blocking():
    headers = {"AUTHORIZATION": "Bearer x", "authorization": "Bearer y"}
    assert _safe_headers(headers) == {}


def test_safe_headers_empty():
    assert _safe_headers({}) == {}
