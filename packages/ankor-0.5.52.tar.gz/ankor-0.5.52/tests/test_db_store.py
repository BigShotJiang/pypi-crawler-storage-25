"""Unit tests for DbStore.rows() columns and order_by features.

Covers:
- _build_order_by   — pure function, no DB required
- _build_select_cols — pure function, no DB required
- DbStore.rows()    — mock-based tests verifying SQL construction and column validation
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ankor import OrderBy
from ankor.db_store import (
    DbStore,
    OrderBy,
    _build_order_by,
    _build_select_cols,
)


# ---------------------------------------------------------------------------
# _build_order_by — pure function tests
# ---------------------------------------------------------------------------


class TestBuildOrderBy:
    def test_none_defaults_to_id(self):
        assert _build_order_by(None) == '"id"'

    def test_asc_direction(self):
        result = _build_order_by(OrderBy("amount", "asc"))
        assert result == '"amount" ASC'

    def test_desc_direction(self):
        result = _build_order_by(OrderBy("amount", "desc"))
        assert result == '"amount" DESC'

    def test_direction_case_insensitive_asc(self):
        result = _build_order_by(OrderBy("name", "ASC"))
        assert result == '"name" ASC'

    def test_direction_case_insensitive_desc(self):
        result = _build_order_by(OrderBy("name", "DESC"))
        assert result == '"name" DESC'

    def test_direction_mixed_case(self):
        result = _build_order_by(OrderBy("name", "Desc"))
        assert result == '"name" DESC'

    def test_default_direction_is_asc(self):
        result = _build_order_by(OrderBy("name"))
        assert result == '"name" ASC'

    def test_invalid_direction_raises(self):
        with pytest.raises(ValueError, match="Invalid order direction"):
            _build_order_by(OrderBy("name", "random"))

    def test_invalid_direction_empty_raises(self):
        with pytest.raises(ValueError, match="Invalid order direction"):
            _build_order_by(OrderBy("name", ""))

    def test_hyphenated_column_quoted(self):
        result = _build_order_by(OrderBy("col-2", "asc"))
        assert result == '"col-2" ASC'

    def test_hyphenated_column_desc(self):
        result = _build_order_by(OrderBy("col-name", "desc"))
        assert result == '"col-name" DESC'

    # --- one test per column type to confirm all work ---

    def test_text_column(self):
        result = _build_order_by(OrderBy("name", "asc"))
        assert result == '"name" ASC'

    def test_integer_column(self):
        result = _build_order_by(OrderBy("score", "desc"))
        assert result == '"score" DESC'

    def test_float_column(self):
        result = _build_order_by(OrderBy("rating", "asc"))
        assert result == '"rating" ASC'

    def test_boolean_column(self):
        result = _build_order_by(OrderBy("active", "desc"))
        assert result == '"active" DESC'

    def test_date_column(self):
        result = _build_order_by(OrderBy("created_on", "asc"))
        assert result == '"created_on" ASC'

    def test_json_column_asc(self):
        result = _build_order_by(OrderBy("metadata", "asc"))
        assert result == '"metadata" ASC'

    def test_select_column(self):
        result = _build_order_by(OrderBy("status", "desc"))
        assert result == '"status" DESC'

    def test_column_with_spaces_quoted(self):
        result = _build_order_by(OrderBy("first name", "asc"))
        assert result == '"first name" ASC'

    def test_column_with_double_quotes_escaped(self):
        result = _build_order_by(OrderBy('col"weird', "asc"))
        assert result == '"col""weird" ASC'

    def test_output_contains_no_order_by_keyword(self):
        # The function returns only the expression, not the full clause
        result = _build_order_by(OrderBy("amount", "desc"))
        assert not result.startswith("ORDER BY")

    def test_system_column_updated_at(self):
        result = _build_order_by(OrderBy("updated_at", "desc"))
        assert result == '"updated_at" DESC'

    def test_system_column_created_at(self):
        result = _build_order_by(OrderBy("created_at", "asc"))
        assert result == '"created_at" ASC'


# ---------------------------------------------------------------------------
# _build_select_cols — pure function tests
# ---------------------------------------------------------------------------


class TestBuildSelectCols:
    def test_none_returns_star(self):
        assert _build_select_cols(None) == "*"

    def test_empty_list_returns_star(self):
        assert _build_select_cols([]) == "*"

    def test_single_column_includes_id(self):
        result = _build_select_cols(["name"])
        assert result == '"id", "name"'

    def test_multiple_columns_includes_id(self):
        result = _build_select_cols(["name", "score"])
        assert result == '"id", "name", "score"'

    def test_id_in_columns_not_duplicated(self):
        result = _build_select_cols(["id", "name"])
        assert result == '"id", "name"'
        assert result.count('"id"') == 1

    def test_id_only_not_duplicated(self):
        result = _build_select_cols(["id"])
        assert result == '"id"'

    def test_hyphenated_columns_quoted(self):
        result = _build_select_cols(["col-2", "col-3"])
        assert result == '"id", "col-2", "col-3"'

    def test_single_hyphenated_column(self):
        result = _build_select_cols(["col-1"])
        assert result == '"id", "col-1"'

    def test_order_preserved(self):
        result = _build_select_cols(["zzz", "aaa"])
        assert result == '"id", "zzz", "aaa"'

    def test_three_columns(self):
        result = _build_select_cols(["amount", "status", "created_on"])
        assert result == '"id", "amount", "status", "created_on"'

    def test_column_with_spaces_quoted(self):
        result = _build_select_cols(["first name"])
        assert result == '"id", "first name"'

    def test_column_with_double_quotes_escaped(self):
        result = _build_select_cols(['col"x'])
        assert result == '"id", "col""x"'

    def test_system_column_created_at(self):
        result = _build_select_cols(["created_at"])
        assert result == '"id", "created_at"'

    def test_system_column_updated_at(self):
        result = _build_select_cols(["updated_at"])
        assert result == '"id", "updated_at"'

    def test_duplicate_non_id_column_deduplicated(self):
        result = _build_select_cols(["amount", "amount"])
        assert result == '"id", "amount"'

    def test_all_system_cols(self):
        result = _build_select_cols(["id", "created_at", "updated_at"])
        assert '"id"' in result
        assert '"created_at"' in result
        assert '"updated_at"' in result
        assert result.count('"id"') == 1


# ---------------------------------------------------------------------------
# DbStore.rows() — mock-based integration tests
# ---------------------------------------------------------------------------


def _make_sl(col_type_rows: list[tuple], data_rows: list[dict]) -> tuple:
    """Build a ``_SessionLocal`` mock for ``DbStore.rows()``.

    Returns ``(sl_mock, session_mock)`` so callers can inspect call args.

    - ``session.exec()`` returns a mock DataTable with ``id=1``
    - ``session.execute()`` is called twice:
        * first call → ``col_type_rows`` (for ``_read_col_types``)
        * second call → data row mocks (for the main SELECT)
    """
    mock_table = MagicMock()
    mock_table.id = 1

    exec_result = MagicMock()
    exec_result.first = MagicMock(return_value=mock_table)

    col_result = list(col_type_rows)

    data_result = [MagicMock(_mapping=row) for row in data_rows]

    mock_session = AsyncMock()
    mock_session.exec = AsyncMock(return_value=exec_result)
    mock_session.execute = AsyncMock(side_effect=[col_result, data_result])

    mock_cm = AsyncMock()
    mock_cm.__aenter__ = AsyncMock(return_value=mock_session)
    mock_cm.__aexit__ = AsyncMock(return_value=None)

    sl = MagicMock(return_value=mock_cm)
    return sl, mock_session


def _sql_from_session(mock_session: MagicMock) -> str:
    """Return the SQL string passed on the second execute() call (the main SELECT)."""
    call = mock_session.execute.call_args_list[1]
    return str(call.args[0])


COL_TYPES = [
    ("name", "text"),
    ("score", "int8"),
    ("active", "bool"),
    ("birthday", "date"),
]
ROW_DATA = [{"id": 1, "name": "Alice", "score": 10, "active": True, "birthday": None}]


class TestDbStoreRowsColumns:
    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_no_columns_selects_star(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable")
        sql = _sql_from_session(session)
        assert sql.startswith("SELECT *")

    async def test_columns_selects_specific_fields(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["name", "score"])
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert '"score"' in sql
        assert sql.startswith("SELECT")
        assert "* " not in sql

    async def test_columns_id_always_included(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["name"])
        sql = _sql_from_session(session)
        assert '"id"' in sql

    async def test_columns_id_not_duplicated(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["id", "name"])
        sql = _sql_from_session(session)
        select_clause = sql.split("FROM")[0]
        assert select_clause.count('"id"') == 1

    async def test_columns_unknown_raises_value_error(self):
        sl, _ = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            with pytest.raises(ValueError, match="Unknown columns"):
                await self.store.rows("MyTable", columns=["nonexistent"])

    async def test_columns_multiple_unknown_all_reported(self):
        sl, _ = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            with pytest.raises(ValueError, match="Unknown columns"):
                await self.store.rows("MyTable", columns=["ghost", "phantom"])

    async def test_columns_system_created_at_allowed(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["created_at"])
        sql = _sql_from_session(session)
        assert '"created_at"' in sql

    async def test_columns_system_updated_at_allowed(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["updated_at"])
        sql = _sql_from_session(session)
        assert '"updated_at"' in sql

    async def test_columns_hyphenated(self):
        col_types = [("col-2", "text"), ("col-3", "int8")]
        sl, session = _make_sl(col_types, [{"id": 1, "col-2": "x"}])
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["col-2"])
        sql = _sql_from_session(session)
        assert '"col-2"' in sql

    async def test_columns_order_preserved_in_sql(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["score", "name"])
        sql = _sql_from_session(session)
        score_pos = sql.index('"score"')
        name_pos = sql.index('"name"')
        assert score_pos < name_pos


class TestDbStoreRowsOrderBy:
    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_no_order_by_defaults_to_id(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable")
        sql = _sql_from_session(session)
        assert 'ORDER BY "id"' in sql

    async def test_order_by_asc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("score", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "score" ASC' in sql

    async def test_order_by_desc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("score", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "score" DESC' in sql

    async def test_order_by_text_column_asc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("name", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "name" ASC' in sql

    async def test_order_by_text_column_desc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("name", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "name" DESC' in sql

    async def test_order_by_boolean_column(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("active", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "active" ASC' in sql

    async def test_order_by_date_column(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("birthday", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "birthday" DESC' in sql

    async def test_order_by_system_column(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("created_at", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "created_at" DESC' in sql

    async def test_order_by_hyphenated_column(self):
        col_types = [("col-2", "text")]
        sl, session = _make_sl(col_types, [{"id": 1, "col-2": "x"}])
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("col-2", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "col-2" ASC' in sql

    async def test_order_by_invalid_direction_raises(self):
        sl, _ = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            with pytest.raises(ValueError, match="Invalid order direction"):
                await self.store.rows("MyTable", order_by=OrderBy("score", "sideways"))

    async def test_order_by_default_direction_is_asc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("score"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "score" ASC' in sql


class TestDbStoreRowsCombined:
    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_columns_and_order_by_together(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows(
                "MyTable",
                columns=["name", "score"],
                order_by=OrderBy("score", "desc"),
            )
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert '"score"' in sql
        assert 'ORDER BY "score" DESC' in sql

    async def test_columns_and_filters_together(self):
        from ankor import RowFilter

        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows(
                "MyTable",
                filters=[RowFilter("score", "gt", 5)],
                columns=["name"],
            )
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert "WHERE" in sql
        assert '"score"' in sql

    async def test_all_three_options_together(self):
        from ankor import RowFilter

        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows(
                "MyTable",
                filters=[RowFilter("active", "eq", True)],
                columns=["name", "score"],
                order_by=OrderBy("name", "asc"),
            )
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert '"score"' in sql
        assert "WHERE" in sql
        assert 'ORDER BY "name" ASC' in sql

    async def test_no_options_returns_all_rows(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            rows = await self.store.rows("MyTable")
        assert isinstance(rows, list)
        assert len(rows) == 1

    async def test_no_session_returns_empty_list(self):
        with patch("ankor.database._SessionLocal", None):
            rows = await self.store.rows("MyTable")
        assert rows == []
