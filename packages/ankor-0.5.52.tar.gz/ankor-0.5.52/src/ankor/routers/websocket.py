from __future__ import annotations

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ..auth import decode_token
from ..broadcast import manager


def create_websocket_router() -> APIRouter:
    router = APIRouter()

    @router.websocket("/ws")
    async def ws_endpoint(ws: WebSocket, token: str = ""):
        """Real-time event stream.

        Connect with ?token=<jwt>.  Then send a subscription message:

            {"type": "subscribe", "channel": "workflow_list"}
            {"type": "subscribe", "channel": "workflow_detail", "id": "<run-id>"}

        The server will reply with {"type": "subscribed", "channel": "..."} and
        then push events as they happen:

            workflow_list  → {"type": "run_created"|"run_updated", "data": <WorkflowRunSummary>}
            workflow_detail → {"type": "run_updated", "data": <WorkflowRun>}
        """
        if not decode_token(token):
            await ws.close(code=4001)
            return
        await ws.accept()
        try:
            while True:
                data = await ws.receive_json()
                msg_type = data.get("type")
                if msg_type == "subscribe":
                    channel = data.get("channel", "")
                    if channel == "workflow_detail":
                        run_id = data.get("id", "")
                        channel = f"workflow_detail:{run_id}"
                    if channel:
                        manager.subscribe(ws, channel)
                        await ws.send_json({"type": "subscribed", "channel": channel})
                elif msg_type == "ping":
                    await ws.send_json({"type": "pong"})
        except WebSocketDisconnect:
            manager.disconnect(ws)
        except Exception:
            manager.disconnect(ws)

    return router
