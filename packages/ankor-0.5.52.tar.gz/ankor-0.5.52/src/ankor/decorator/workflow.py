from __future__ import annotations

import asyncio
import functools
from datetime import datetime, timezone

from ..database import _SessionLocal
from ..models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from ..trigger_context import TriggerContext
from ._context import _active_node_slot, _active_run_ctx, _running_tasks
from ._drain import _ensure_drain_task, _notify_drain
from ._execution import _RunExecState, _execute_fn_task
from ._serialization import _run_detail, _run_summary


def make_workflow_wrapper(fn):
    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, _ctx: TriggerContext | None = None):
        if _ctx is None:
            _ctx = TriggerContext("manual", inputs)

        if _SessionLocal is None:
            return await fn(inputs)

        from ..broadcast import manager
        from sqlmodel import func, select

        _parent_ctx = _active_run_ctx.get()
        _parent_run_id: int | None = _parent_ctx.get("run_id") if _parent_ctx else None

        async with _SessionLocal() as session:
            cfg = (await session.exec(
                select(Workflow).where(Workflow.name == fn.__name__)
            )).first()

            if cfg is not None and cfg.max_concurrent_runs is not None:
                if cfg.max_concurrent_runs == 0:
                    return None
                running_count: int = (await session.execute(
                    select(func.count(WorkflowRun.id)).where(
                        WorkflowRun.workflow_id == cfg.id,
                        WorkflowRun.status == WorkflowStatus.running,
                        WorkflowRun.parent_id == None,  # noqa: E711
                    )
                )).scalar_one()
                if running_count >= cfg.max_concurrent_runs:
                    trigger_type = TriggerType(_ctx.type) if _ctx.type in TriggerType._value2member_map_ else TriggerType.manual
                    queued = WorkflowRun(
                        workflow_id=cfg.id,
                        status=WorkflowStatus.pending,
                        triggered_by=trigger_type,
                        data={"trigger_context": _ctx.to_db(), "actions": [], "inputs": inputs, "outputs": {}},
                    )
                    session.add(queued)
                    await session.commit()
                    await session.refresh(queued)
                    await manager.broadcast("workflow_list", {"type": "run_created", "data": _run_summary(queued, fn.__name__)})
                    _ensure_drain_task(fn.__name__, fn)
                    return None

            if cfg is None:
                cfg = Workflow(name=fn.__name__)
                session.add(cfg)
                await session.commit()
                await session.refresh(cfg)

            trigger_type = TriggerType(_ctx.type) if _ctx.type in TriggerType._value2member_map_ else TriggerType.manual
            run = WorkflowRun(
                workflow_id=cfg.id,
                status=WorkflowStatus.running,
                triggered_by=trigger_type,
                parent_id=_parent_run_id,
                data={"trigger_context": _ctx.to_db(), "actions": [], "inputs": inputs, "outputs": {}},
                started_at=datetime.now(timezone.utc),
            )
            session.add(run)
            await session.commit()
            await session.refresh(run)

            await manager.broadcast("workflow_list", {"type": "run_created", "data": _run_summary(run, fn.__name__)})

            ctx: dict = {
                "actions": [], "plan": [], "logs": [], "run_id": run.id, "_action_counter": 0,
                "_run_meta": {
                    "id": run.id,
                    "name": fn.__name__,
                    "triggeredBy": trigger_type.value,
                    "triggerContext": _ctx.to_db(),
                    "inputs": inputs,
                    "outputs": {},
                    "startedAt": run.started_at.isoformat() if run.started_at else None,
                    "finishedAt": None,
                    "createdAt": run.created_at.isoformat(),
                    "parentId": _parent_run_id,
                    "children": [],
                },
            }
            ctx_token = _active_run_ctx.set(ctx)
            slot_token = _active_node_slot.set(None)
            timeout = cfg.timeout_seconds if cfg else None
            coro = fn(inputs)
            fn_task = asyncio.create_task(
                asyncio.wait_for(coro, timeout=timeout) if timeout else coro
            )
            _running_tasks[run.id] = fn_task
            state = _RunExecState(
                run=run, inputs=inputs, name=fn.__name__,
                ctx=ctx, ctx_token=ctx_token, slot_token=slot_token,
            )
            result, was_cancelled, failure_exc = await _execute_fn_task(fn_task, state)

            if not was_cancelled:
                run.finished_at = datetime.now(timezone.utc)
                session.add(run)
                await session.commit()

                await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run, fn.__name__)})
                await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run, fn.__name__)})

                if _parent_ctx is not None:
                    duration_ms = int((run.finished_at - run.started_at).total_seconds() * 1000) if run.started_at else 0
                    parent_slot = _active_node_slot.get()
                    parent_list = parent_slot["children"] if parent_slot is not None else _parent_ctx["actions"]
                    _parent_ctx["_action_counter"] += 1
                    parent_list.append({
                        "id": _parent_ctx["_action_counter"],
                        "name": fn.__name__,
                        "type": "workflow",
                        "status": run.status.value,
                        "inputs": inputs,
                        "outputs": (run.data or {}).get("outputs", {}),
                        "duration_ms": duration_ms,
                        "child_run_id": run.id,
                        "children": [],
                    })

        _notify_drain(fn.__name__)

        if failure_exc is not None:
            raise failure_exc

        return result

    wrapper._gtm_fn = fn
    return wrapper
