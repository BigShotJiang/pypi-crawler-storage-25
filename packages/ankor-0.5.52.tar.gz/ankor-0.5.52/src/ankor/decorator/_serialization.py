from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import WorkflowRun


def _json_safe(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    return obj


def _serialize_action(n: dict) -> dict:
    return {
        "id": n.get("id"),
        "name": n.get("name"),
        "slug": n.get("slug"),
        "type": n.get("type", "node"),
        "status": n.get("status"),
        "inputs": n.get("inputs", {}),
        "outputs": n.get("outputs", {}),
        "durationMs": n.get("duration_ms", 0),
        "logs": n.get("logs"),
        "childRunId": n.get("child_run_id"),
        "children": [_serialize_action(c) for c in n.get("children", [])],
    }


def _run_summary(run: WorkflowRun, workflow_name: str) -> dict:
    d = run.data or {}
    return {
        "id": run.id,
        "name": workflow_name,
        "status": run.status.value,
        "triggeredBy": run.triggered_by.value if hasattr(run.triggered_by, "value") else run.triggered_by,
        "triggerContext": d.get("trigger_context", {}),
        "inputs": d.get("inputs", {}),
        "outputs": d.get("outputs", {}),
        "startedAt": run.started_at.isoformat() if run.started_at else None,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
        "createdAt": run.created_at.isoformat(),
        "parentId": run.parent_id,
        "children": [],
    }


def _run_detail(run: WorkflowRun, workflow_name: str) -> dict:
    d = run.data or {}
    raw = d.get("actions") or d.get("nodes", [])
    return {**_run_summary(run, workflow_name), "actions": [_serialize_action(n) for n in raw]}
