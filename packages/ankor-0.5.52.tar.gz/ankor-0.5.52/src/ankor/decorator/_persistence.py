from __future__ import annotations

import asyncio

from ..database import _SessionLocal
from ..models import WorkflowRun, WorkflowStatus
from ._context import _pending_db_saves
from ._serialization import _json_safe

_SNAPSHOT_DELAY = 0.5


async def _persist_run_snapshot(run_id: int, ctx: dict) -> None:
    if _SessionLocal is None:
        return
    async with _SessionLocal() as session:
        run = await session.get(WorkflowRun, run_id)
        if run is not None and run.status == WorkflowStatus.running:
            run.data = {
                **(run.data or {}),
                "actions": _json_safe(ctx["actions"]),
                "logs": _json_safe(ctx["logs"]),
            }
            session.add(run)
            await session.commit()


def _schedule_snapshot(run_id: int, ctx: dict, delay: float = _SNAPSHOT_DELAY) -> None:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    existing = _pending_db_saves.get(run_id)
    if existing and not existing.done():
        existing.cancel()

    async def _save():
        await asyncio.sleep(delay)
        await _persist_run_snapshot(run_id, ctx)

    _pending_db_saves[run_id] = loop.create_task(_save())
