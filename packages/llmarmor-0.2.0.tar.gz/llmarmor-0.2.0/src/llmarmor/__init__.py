"""LLM Armor - OWASP LLM Top 10 security scanner for AI-powered applications."""

__version__ = "0.2.0"
