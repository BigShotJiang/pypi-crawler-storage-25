import pytest
import pandas as pd
from blendsql import BlendSQL
from blendsql.db import Pandas
from blendsql.common.exceptions import (
    LMFunctionException,
    InvalidBlendSQL,
    TypeResolutionException,
)
from blendsql.ingredients import LLMQA, LLMMap
from tests.utils import select_first_option


@pytest.fixture(scope="session")
def bsql() -> BlendSQL:
    return BlendSQL(
        db=Pandas(
            {
                "w": pd.DataFrame(
                    {"Name": ["Danny", "Emma", "Tony"], "Age": [23, 26, 19]}
                ),
                "classes": pd.DataFrame(
                    {
                        "Id": [4532, 1234, 6653],
                        "Title": ["Computer Science", "Discrete Math", "Philosophy"],
                    }
                ),
            }
        ),
    )


def test_error_on_delete1(bsql):
    with pytest.raises(InvalidBlendSQL):
        _ = bsql.execute(
            query="""
            DELETE FROM w WHERE TRUE;
            """,
        )


def test_error_on_delete2(bsql):
    with pytest.raises(InvalidBlendSQL):
        _ = bsql.execute(
            query="""
            DROP TABLE w;
            """,
        )


def test_error_on_duplicate_ingredient_names(bsql, model):
    with pytest.raises(LMFunctionException):
        _ = bsql.execute(
            """
            SELECT {{LLMMap('Will this fail with the duplicate ingredient names?', c.Title)}} AS "answer" FROM classes c LIMIT 1
            """,
            model=model,
            ingredients=[LLMMap, LLMMap],
        )


def test_vanilla_sql_no_ingredients(bsql):
    _ = bsql.execute(
        """
        SELECT * FROM w
        """
    )


def test_error_on_invalid_ingredient(bsql):
    with pytest.raises(LMFunctionException):
        _ = bsql.execute(
            query="""
            SELECT * w WHERE {{ingredient()}} = TRUE
            """,
            ingredients={"This is not an ingredient type"},
        )


def test_error_on_bad_options_subquery(bsql):
    with pytest.raises(InvalidBlendSQL):
        _ = bsql.execute(
            query="""
            SELECT * FROM w
            WHERE {{
                select_first_option(
                    'I am at a nice cafe right now',
                    w.Name,
                    options=(SELECT * FROM w)
                )
            }}
            """,
            ingredients={select_first_option},
        )


def test_replacement_scan(bsql, model):
    """ad94437"""
    NewIngredient = LLMQA.from_args(num_few_shot_examples=2)
    _ = bsql.execute(
        """
        SELECT * FROM w 
        WHERE w.Name = {{NewIngredient('Will this work?')}}
        """,
        ingredients={NewIngredient},
        model=model,
    )


def test_llmqa_question_f_strings(bsql, model):
    """0218f7f"""
    res = bsql.execute(
        """
        WITH t AS (SELECT * FROM w WHERE Age = 23 LIMIT 1)
        SELECT {{
            LLMQA(
                'Please say "{}"', t.Name
            )    
        }}
        """,
        model=model,
    )
    assert list(res.df().values.flat)[0].startswith("Danny")
    res.print_summary()


def test_llmqa_question_f_string_literals(bsql, model):
    """0218f7f"""
    _ = bsql.execute(
        """
        SELECT {{
            LLMQA(
                'Please say "{}" and "{}"', 4, 'hello'
            )    
        }}
        """,
        model=model,
    )


def test_llmmap_question_f_strings(bsql, model):
    """0218f7f"""
    _ = bsql.execute(
        """
        WITH t AS (SELECT * FROM w WHERE Age = 23 LIMIT 1)
        SELECT c.Title, {{LLMMap('Would someone named {} be good at this subject?', c.Title)}} AS "answer" FROM classes c
        """,
        model=model,
    )


def test_llmqa_in_tuple(bsql, model):
    """cff65b6"""
    _ = bsql.execute(
        """
        SELECT * FROM classes 
        WHERE classes.Title IN ('Discrete Math', {{LLMQA('What did Aristotle study?')}})
        """,
        model=model,
    )


def test_llmmap_on_int(bsql, model):
    """466cc7b"""
    _ = bsql.execute(
        """
        SELECT {{LLMMap('Is this number greater than 20?', Age)}} FROM w;
        """,
        model=model,
    )


def test_verbose_on(bsql, model):
    _ = bsql.execute(
        """
        SELECT {{LLMMap('Is this number greater than 20?', Age)}} FROM w;
        """,
        model=model,
        verbose=True,
    )


def test_llmmap_concatenation_pipes(bsql, model):
    """
    a055026
    """
    _ = bsql.execute(
        """
        SELECT {{LLMMap('How old are they?', 'Name: ' || Name  || 'Age: ' || Age)}} FROM w;
        """,
        model=model,
    )


def test_llmmap_concatenation_concat(bsql, model):
    """
    a055026
    """
    _ = bsql.execute(
        """
        SELECT {{LLMMap('How old are they?', CONCAT('Name: ', Name, 'Age: ', Age))}} FROM w;
        """,
        model=model,
    )


def test_llmmap_concatenation_pipes_with_alias(bsql, model):
    """
    a055026
    """
    _ = bsql.execute(
        """
        WITH t AS (
            SELECT * FROM w
        )
        SELECT {{LLMMap('How old are they?', 'Name: ' || Name  || 'Age: ' || Age)}} FROM t;
        """,
        model=model,
    )


def test_prompt_type_annotation(bsql, model):
    from blendsql import GLOBAL_HISTORY

    _ = bsql.execute(
        """
        SELECT {{LLMMap('Is a famous singer?', Name, options=('yes', 'no'))}} FROM w LIMIT 1
        """,
        model=model,
    )
    assert any(x in GLOBAL_HISTORY[-1] for x in ['["yes", "no"]', "['yes', 'no']"])

    _ = bsql.execute(
        """
        SELECT {{LLMMap('How old are they, probably', Name, options=(21, 14, 12))}} FROM w LIMIT 1
        """,
        model=model,
    )
    assert "[21, 14, 12]" in GLOBAL_HISTORY[-1]


def test_raises_type_resolution_error(bsql, model):
    """965d8fd"""
    with pytest.raises(TypeResolutionException):
        _ = bsql.execute(
            """
            SELECT * FROM w WHERE {{
                LLMMap(
                    'What letter does the name start with?',
                    Name,
                    options=(1, 2, 3)
                )
            }} = 'D'
            """,
            model=model,
        )


def test_warmup(bsql, model):
    """b168717"""
    bsql._warmup(model=model)
