from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.trace_controller_list_traces_response_200 import TraceControllerListTracesResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    app_id: str | Unset = UNSET,
    environment: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    params["appId"] = app_id

    params["environment"] = environment

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/traces",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> TraceControllerListTracesResponse200 | None:
    if response.status_code == 200:
        response_200 = TraceControllerListTracesResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[TraceControllerListTracesResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    app_id: str | Unset = UNSET,
    environment: str | Unset = UNSET,
) -> Response[TraceControllerListTracesResponse200]:
    """
    Args:
        page (float | Unset):
        limit (float | Unset):
        app_id (str | Unset):
        environment (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TraceControllerListTracesResponse200]
    """

    kwargs = _get_kwargs(
        page=page,
        limit=limit,
        app_id=app_id,
        environment=environment,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    app_id: str | Unset = UNSET,
    environment: str | Unset = UNSET,
) -> TraceControllerListTracesResponse200 | None:
    """
    Args:
        page (float | Unset):
        limit (float | Unset):
        app_id (str | Unset):
        environment (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TraceControllerListTracesResponse200
    """

    return sync_detailed(
        client=client,
        page=page,
        limit=limit,
        app_id=app_id,
        environment=environment,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    app_id: str | Unset = UNSET,
    environment: str | Unset = UNSET,
) -> Response[TraceControllerListTracesResponse200]:
    """
    Args:
        page (float | Unset):
        limit (float | Unset):
        app_id (str | Unset):
        environment (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TraceControllerListTracesResponse200]
    """

    kwargs = _get_kwargs(
        page=page,
        limit=limit,
        app_id=app_id,
        environment=environment,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    app_id: str | Unset = UNSET,
    environment: str | Unset = UNSET,
) -> TraceControllerListTracesResponse200 | None:
    """
    Args:
        page (float | Unset):
        limit (float | Unset):
        app_id (str | Unset):
        environment (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TraceControllerListTracesResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            page=page,
            limit=limit,
            app_id=app_id,
            environment=environment,
        )
    ).parsed
