# Agent Replay

Agent Replay lets you load any past execution trace, step through it, inspect each step's input/output/attributes, fork at any point, modify the prompt or input, and rerun from that point. This is the SDK's unique debugging feature — no other framework offers fork-and-rerun.

## Why Replay?

When an agent fails in production — hallucinates, calls the wrong tool, gives a bad answer — you need to understand **why** and test a fix **without re-running the entire pipeline**. Replay lets you:

1. Load the exact trace of the failure
2. Step through to find the problematic step
3. Fork at that step
4. Change the prompt, input, or state
5. Rerun from that point only
6. Compare the original vs fixed result

## Where Do Trace IDs Come From?

Every `agent.run()` automatically generates a trace. The trace ID is returned in the result:

```python
result = agent.run("Help me with my order")
print(result.trace_id)  # "b6acf1ef2c2779bbc2fcf80802ae0534"
```

You can also browse past traces programmatically or via CLI:

```python
from fastaiagent.trace import TraceStore
for t in TraceStore().list_traces(last_hours=24):
    print(f"{t.trace_id}  {t.name}  {t.status}")
```

```bash
fastaiagent traces list --last-hours 24
```

## Loading a Replay

### From Local Trace Storage

```python
from fastaiagent.trace.replay import Replay

# Load by trace ID (from result.trace_id or fastaiagent traces list)
replay = Replay.load("b6acf1ef2c2779bbc2fcf80802ae0534")
```

### From a TraceData Object

```python
from fastaiagent.trace.storage import TraceStore

store = TraceStore()
trace_data = store.get_trace("b6acf1ef2c2779bbc2fcf80802ae0534")
replay = Replay(trace_data)
```

## Viewing the Summary

```python
print(replay.summary())
```

Output:
```
Trace: b6acf1ef2c2779bbc2fcf80802ae0534
Name: agent.support-bot
Status: OK
Spans: 4
Duration: 2025-01-15T10:30:00Z → 2025-01-15T10:30:02.5Z

Steps:
  [0] agent.run
  [1] llm.chat_completion
  [2] tool.search_docs
  [3] llm.chat_completion
```

## Stepping Through

### All Steps

```python
steps = replay.step_through()
for step in steps:
    print(f"Step {step.step}: {step.span_name}")
    if step.attributes:
        print(f"  Attributes: {step.attributes}")
```

### Specific Step

```python
steps = replay.steps()
print(f"Total steps: {len(steps)}")

# Inspect a specific step
step = replay.inspect(2)
print(f"Name: {step.span_name}")
print(f"Span ID: {step.span_id}")
print(f"Timestamp: {step.timestamp}")
print(f"Attributes: {step.attributes}")
```

## ReplayStep

| Field | Type | Description |
|-------|------|-------------|
| `step` | `int` | Step index (0-based) |
| `span_name` | `str` | What happened (e.g., "llm.chat_completion", "tool.search") |
| `span_id` | `str` | Unique span identifier |
| `input` | `dict` | Input to this step |
| `output` | `dict` | Output from this step |
| `attributes` | `dict` | OTel attributes (model, tokens, tool name, etc.) |
| `timestamp` | `str` | When this step executed |

## Forking and Rerunning

The core debugging workflow — fork at the problem step, fix, rerun:

```python
# Step 3 is where the LLM hallucinated
forked = replay.fork_at(step=3)

# Modify what you want to fix
forked.modify_prompt("Always cite the exact policy section number. Never guess.")
forked.modify_input({"query": "refund policy section 4.2"})

# Rerun from that point
result = forked.rerun()
print(f"New output: {result.new_output}")
print(f"Steps executed: {result.steps_executed}")
```

### How `rerun()` reconstructs the agent

`ForkedReplay.rerun()` is a real re-execution, not a stub. Under the hood it:

1. Finds the root `agent.{name}` span in the loaded trace.
2. Reads the [Agent Reconstruction Attributes](../tracing/index.md#agent-reconstruction-attributes-used-by-replay) off that span — `agent.config`, `agent.tools`, `agent.guardrails`, `agent.llm.config`, `agent.system_prompt`, `agent.input` — and decodes them into the canonical `Agent.from_dict` payload.
3. Applies your `modify_prompt` / `modify_config` / `modify_input` modifications on top of that payload.
4. Rebinds tool callables by name via the [`ToolRegistry`](../tools/index.md#toolregistry). Tools created with `FunctionTool(name=..., fn=...)` or the `@tool` decorator auto-register at construction, so replay inside the same process picks them up automatically.
5. Builds a new `Agent` via `Agent.from_dict()` and calls `agent.arun(new_input)`. A new trace is emitted for the rerun, and its `trace_id` is returned on `ReplayResult.trace_id`.

**v1 scope.** The rerun re-executes the agent **from the top** with modifications applied — it does not literally resume the LLM loop at `fork_point` with prior messages pre-seeded. `fork_point` is still recorded and used by `compare()` to mark where divergence logically happened, so downstream tooling sees your intent. Mid-trace resume (replaying captured messages up to `fork_point` then continuing from there) requires a stable per-provider message-history representation and is planned as a follow-up.

**What you need for `rerun()` to work:**

- The SDK is at a version that captures `agent.*` reconstruction attributes (`0.1.7+`). Traces from older versions can still be loaded and stepped through, but `rerun()` will fail to reconstruct the agent — re-run the agent once on the new SDK to capture a rerun-capable trace.
- Any Python tool callables the agent used are registered in the [`ToolRegistry`](../tools/index.md#toolregistry) of the replay process. Importing the module that defines the tools is usually enough.
- `FASTAIAGENT_TRACE_PAYLOADS=0` was not set when the original trace was captured, *if* you want the resolved system prompt to round-trip. When payloads were off, modifications still work but the reconstructed agent uses whatever prompt your code supplies via `modify_prompt()`.

### Available Modifications

| Method | What it changes |
|--------|----------------|
| `modify_prompt(new_prompt)` | System prompt for the LLM call at the fork point |
| `modify_input(new_input)` | Input data passed to the step |
| `modify_config(**kwargs)` | Agent/LLM configuration (temperature, max_tokens, etc.) |
| `modify_state(new_state)` | Chain state (for chain replays) |

Methods return `self` for chaining:

```python
result = (
    replay.fork_at(step=3)
    .modify_prompt("Be more precise.")
    .modify_input({"context": "additional context"})
    .modify_config(temperature=0.2)
    .rerun()
)
```

## Comparing Results

After rerunning, compare the original and fixed execution:

```python
forked = replay.fork_at(step=3)
forked.modify_prompt("New instructions")
result = forked.rerun()

comparison = forked.compare(result)
print(f"Original steps: {len(comparison.original_steps)}")
print(f"Diverged at step: {comparison.diverged_at}")
```

### ComparisonResult

| Field | Type | Description |
|-------|------|-------------|
| `original_steps` | `list[ReplayStep]` | Steps from the original trace |
| `new_steps` | `list[ReplayStep]` | Steps from the rerun (if available) |
| `diverged_at` | `int \| None` | Step index where results diverged |

### ReplayResult

| Field | Type | Description |
|-------|------|-------------|
| `original_output` | `Any` | Output from the original execution |
| `new_output` | `Any` | Output from the rerun |
| `steps_executed` | `int` | Number of steps executed in the rerun |
| `trace_id` | `str \| None` | Trace ID of the original execution |

## CLI Commands

```bash
# Show replay steps for a trace
fastaiagent replay show <trace_id>

# Inspect a specific step
fastaiagent replay inspect <trace_id> 3
```

Example:
```bash
$ fastaiagent replay show b6acf1ef2c27

Trace: b6acf1ef2c2779bbc2fcf80802ae0534
Name: agent.support-bot
Status: OK
Spans: 4

Steps:
  [0] agent.run
  [1] llm.chat_completion
  [2] tool.search_docs
  [3] llm.chat_completion

$ fastaiagent replay inspect b6acf1ef2c27 2

Step 2: tool.search_docs
  Timestamp: 2025-01-15T10:30:01.300Z
  Attributes: {'fastaiagent.tool.name': 'search_docs'}
```

## Debugging Workflow

A typical debugging session:

```python
from fastaiagent.trace import TraceStore
from fastaiagent.trace.replay import Replay

# 1. Find the failing trace
store = TraceStore()
traces = store.search("support-bot")
# Or use: fastaiagent traces list

# 2. Load and inspect
replay = Replay.load(traces[0].trace_id)
print(replay.summary())

# 3. Step through to find the problem
for step in replay.step_through():
    print(f"[{step.step}] {step.span_name}: {step.attributes}")
# Step 3: LLM hallucinated the refund policy ← found it

# 4. Fork and fix
forked = replay.fork_at(step=3)
forked.modify_prompt("Always cite exact policy section numbers from the docs.")

# 5. Rerun and verify
result = forked.rerun()
print(f"Fixed output: {result.new_output}")

# 6. Compare
comparison = forked.compare(result)
print(f"Diverged at step {comparison.diverged_at}")
```

## Error Handling

```python
from fastaiagent._internal.errors import ReplayError

try:
    step = replay.inspect(99)
except ReplayError as e:
    print(f"Error: {e}")  # "Step 99 out of range (0-3)"

try:
    forked = replay.fork_at(-1)
except ReplayError as e:
    print(f"Error: {e}")  # "Step -1 out of range (0-3)"
```

---

## Platform Replay

When connected to the FastAIAgent Platform, you can pull any trace from the platform (including traces from other team members) and replay locally:

```python
import fastaiagent as fa

fa.connect(api_key="fa-...", project="my-project")

# Pull a platform trace and replay locally
replay = Replay.from_platform(trace_id="tr-abc123")
replay.step_through()

# Fork from a platform trace
forked = replay.fork_at(step=3)
forked.modify_prompt("Updated system prompt")
result = forked.rerun()
```

---

## Next Steps

- [Tracing](../tracing/index.md) — How traces are captured and stored
- [Chains Checkpointing](../chains/checkpointing.md) — Resume failed chains from checkpoints
- [Evaluation](../evaluation/index.md) — Systematically test agent quality
