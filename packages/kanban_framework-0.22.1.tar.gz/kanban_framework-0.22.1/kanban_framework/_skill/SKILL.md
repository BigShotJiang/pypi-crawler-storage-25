---
name: kanban
description: "使用 /kanban 命令管理看板任务的全生命周期：初始化看板、创建 TASK-NNN 任务、执行阶段（plan/execute/evaluate）、归档完成、查看状态/进度、恢复中断任务、多迭代工作流。当用户提到 kanban、看板、TASK-NNN、/kanban 命令、任务创建/归档/恢复、或任何看板任务管理意图时使用此技能。"
---

# Kanban 多 Agent 编排系统

基于 FSM 的任务编排框架。编排器不直接管理流程，全部由状态机驱动。

## 命令约定

优先检测 `kanban` CLI（pip 安装），不可用时回退 `python3 -m kanban_framework`（需 PYTHONPATH）。

## 命令路由

**精确命令** 直接匹配，**自然语言** 通过 `kanban nlp` 解析后路由。

| 意图 | 条件 | 路由 |
|------|------|------|
| `work` | 有 task_id | `run` |
| `work` | 无 task_id 且无活跃任务 | 先 `create` 再 `run` |
| `work` | 无 task_id 但有活跃任务 | `run <active_task_id>`（关联到已有任务） |
| `query` | 含查询动词 | `status` / `show` |

**工作意图路由步骤：**
1. `kanban nlp "<用户输入>"` → 获取 intent / task_id / needs_active_task_check
2. 如果 `needs_active_task_check` 为 true → `kanban status` 检查是否有活跃任务
3. 有活跃任务 → 展示当前任务给用户确认，用户同意后 `kanban run <id>`
4. 无活跃任务或用户明确要新建 → `kanban create` + `kanban run`

**硬性约束：** `intent == "work"` 时禁止跳过 FSM 直接调用 skill。所有工作必须通过 `kanban create`/`kanban run` 进入框架。

### 常用命令

```
# 项目初始化与维护
/kanban init                        # 初始化（首次必须执行：询问工号 → task_id_base）
/kanban hook install                # 安装 SessionStart hook（每次会话自动注入任务上下文）
/kanban update                      # 升级到最新版本 + 同步 skill 文件
/kanban check-env                   # 检查环境配置（python / agent sync / gitignore）

# 任务生命周期
/kanban create "<title>"            # 创建任务（默认 light，复杂任务自动 full）
/kanban task edit <id> --mode full  # 切换为 full 模式
/kanban task edit <id> --auto-mode all  # 开启全自动模式
/kanban run <id>                    # 执行当前阶段
/kanban status                      # 看板状态（所有活跃任务）
/kanban show <id>                   # 任务详情
/kanban decide <id> --action <act>  # 用户决策（approve_and_archive 等）
/kanban clean <id>|--all            # 清理归档任务
/kanban recover [<id>]              # 崩溃恢复

# FSM 编排
/kanban workflow next-step <id>     # 获取下一步指令（状态机驱动，所有决策的权威来源）
/kanban workflow mark-step <id> <step_id>  # 标记步骤完成
/kanban workflow progress <id>      # 查看子步骤进度
/kanban workflow replan <id>        # 重置到 plan 阶段重生制品（用户主动要求时使用）

# Inbox 反馈管理（独立于任务归档）
/kanban inbox add <id> "<text>"     # 添加反馈到任务 inbox.md
/kanban inbox process <id>          # 只读分析（scope 分类 + 冲突检测），不修改文件
/kanban inbox archive <id>          # 归档已验证的 [x] 条目到 inbox-archive.md
/kanban inbox add-subtasks <id>     # 从 inbox 分析结果生成补充 subtask

# 多窗口 subtask 协作
/kanban subtask claim <id> <st_id>  # 原子抢占 subtask（已 claim 的拒绝重复抢占）
/kanban subtask unclaim <id> <st_id>  # 释放 subtask 回 pending
/kanban subtask start <id> <st_id>  # claim + 标记 in_progress
/kanban subtask done <id> <st_id>   # 标记完成（可选 --commit-hash --files）
/kanban subtask status <id>         # 查看所有 subtask 状态（含 claimant 信息）

# Dashboard 可视化管理
/kanban dashboard start             # 一键启动 Dashboard（自动 deploy + npm install）
/kanban dashboard stop              # 停止 Dashboard
/kanban dashboard status            # 查看运行状态

# 知识库
/kanban knowledge search <kw>       # 搜索知识库
/kanban knowledge list              # 列出知识条目

# 其他
/kanban guard check-inbox <id>      # 检查 inbox 待处理 + 未验证项
/kanban guard check-pending-subtasks <id>  # 检查阻塞归档的 subtask 状态
```

---

## 核心编排循环（唯一流程控制方式）

编排器不做任何流程决策。所有决策由状态机 `next-step` 返回。

**上下文恢复：** 压缩后或新会话，先调用 `kanban workflow next-step <task_id>` 恢复状态，不凭记忆。

```
循环开始:
  1. result = kanban workflow next-step <task_id>
  2. 根据 result 执行:
     - 有 interactive → 编排器直接处理，在主对话中与用户多轮交互（如 brainstorming）
     - 有 spawn_prompt → 用 Agent tool 启动 subagent，prompt 使用 result.spawn_prompt 的内容
     - 有 user_action → 展示信息给用户，等待用户操作
     - 有 actions → 按顺序执行 CLI 命令
  3. kanban workflow mark-step <task_id> result.step_id
  4. 如 result.phase_complete → kanban workflow complete-phase <task_id>
  5. 如 result.all_complete → 结束
  6. 否则 → 回到 1
```

**编排器禁止行为：**
- 禁止跳过 next-step 自行决定下一步
- 禁止修改 subagent 的 spawn_prompt 内容
- 禁止在 subagent 完成后跟随其建议的后续步骤（subagent 只负责产出发配的文件）
- 禁止直接修改 task.json 的 phase 字段

**流程调度自检：** 每次 subagent 完成后，不要凭记忆判断下一步。先调用 `kanban workflow next-step <task_id>` 获取状态机的权威指令，再行动。长对话中模型容易遗忘当前阶段 — next-step 是恢复上下文的唯一可靠方式。

**轻量模式说明：** 任务创建时自动检测模式。full 模式走完整阶段（含 Plan Review/QA Spec/Spec Review），lightweight 模式跳过这些阶段直接 Plan → Execute → Evaluate(QA only) → Archive。模式由 `next-step` 自动适配，编排器无需关注。

**FSM 校验：** `run`/`transition`/`complete-phase` 命令执行前会自动验证 FSM 状态，检测跳步。如果状态不一致会返回错误和修正指令，按修正指令操作即可。

## 模式说明

### Full vs Lightweight

| | Full | Lightweight |
|---|------|-------------|
| 触发 | 检测到重度信号自动启用 | **默认模式** |
| 阶段 | Plan → Plan Review → QA Spec → Spec Review → Execute → Evaluate → Self-Improve → Retrospective → User Decision → Archive | Plan → Execute → Evaluate(QA only) → User Decision → Archive |
| Plan 确认 | 需要 `user_confirm_spec` | **跳过**（brainstorming 已交互） |
| 适用 | 复杂功能、新模块、架构变更 | Bug 修复、小改动、脚本、配置 |

创建任务时自动推荐模式。用户可手动 `--mode full` 或 `--lightweight`。

### 全自动模式 (Auto Mode)

人工决策点由 **kanban-auto-decider subagent** 替代，不跳过。flags: `brainstorm / iteration / lightweight / archive / worktree / all`。

```
/kanban create "title" --auto-mode all     # 全部自动
/kanban task edit <id> --auto-mode all      # 事后开启
```

auto-decider 置信度 < 0.7 时降级回人工确认。

## Inbox 反馈闭环

**inbox 反馈归档 ≠ 任务归档**。inbox archive 只操作 inbox.md → inbox-archive.md，不影响任务状态。

```
用户反馈 → inbox add → inbox process（只读分析）
  ├─ scope:current → 需实现 → 补充 subtask 或纳入 plan
  ├─ scope:conflict → 暂停，等用户决策
  └─ scope:next-task → 标记 migrated:TASK-NNN → 可归档

实现完成 → [x] 标注 done:<path> → inbox archive → inbox-archive.md
```

**归档必须带标签**：`done:<path>` / `migrated:<TASK-NNN>` / `wontfix:<reason>`。无标签的 `[x]` 被拒绝。

## 多窗口 subtask 协作

```powershell
# 窗口 1                             # 窗口 2
kanban subtask claim TASK-001 ST-001  kanban subtask claim TASK-001 ST-002
# → 原子抢占，ST-002 已被窗口 1 抢占则返回 claimed:false
# ... 编码 ...                        # ... 编码 ...
kanban subtask done TASK-001 ST-001   kanban subtask done TASK-001 ST-002

# 查看全局状态
kanban subtask status TASK-001
# → ST-001: completed | ST-002: in_progress (user2) | ST-003: pending
```

**无 worktree 隔离** — 用户自行判断文件冲突。同一个 subtask 不可被两个窗口同时 claim。

## Git 阶段检查点

每个阶段完成时自动 `git add -f` + `git commit`，task 数据不会因误删丢失。commit 格式: `checkpoint: <phase> (TASK-NNN)`。

`.kanban/` 不应全局 gitignore —— 只排除运行时目录（`.kanban/dashboard/`, `.kanban/reports/`, `.kanban/skills/`），保留 `tasks/` 和 `archive/` 可追踪。

## spawn_prompt 变量

`next-step` 返回的 `spawn_prompt` 中可能包含以下变量，编排器无需替换（已由状态机处理）：

| 变量 | 含义 |
|------|------|
| `$task_id` | 任务 ID |
| `$task_dir` | 任务目录路径 |
| `$report_dir` | 当前迭代报告目录路径 |
| `$iteration` | 当前迭代编号 |
