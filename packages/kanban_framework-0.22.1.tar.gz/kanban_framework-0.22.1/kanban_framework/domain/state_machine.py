"""State machine driver for kanban workflow orchestration.

Instead of the orchestrator remembering the full FSM, it calls
`next_step(task_id)` and receives precise instructions for what to do next.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from kanban_framework.types import Task, Phase, ControlMode
from kanban_framework.infra.filesystem import Filesystem
from kanban_framework.infra.config import Config
from kanban_framework.infra.scheduler import Scheduler


@dataclass
class StepDef:
    id: str
    description: str
    actions: list[str] = field(default_factory=list)
    agent_type: Optional[str] = None
    parallel: bool = False
    user_action: bool = False  # requires human interaction
    spawn_prompt: Optional[str] = None  # complete prompt for subagent
    interactive: bool = False  # orchestrator handles directly with multi-turn user interaction


# ── Step definitions per phase ──────────────────────────────────────────

FULL_STEPS: dict[str, list[StepDef]] = {
    "plan": [
        StepDef("plan.knowledge_search", "知识库检索 — 强制产出 knowledge_used.json",
                actions=["kanban time start $task_id knowledge_search",
                         "spawn kanban-knowledge-capture agent 执行知识检索",
                         "kanban time end $task_id knowledge_search"],
                agent_type="kanban-knowledge-capture",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的知识检索 Agent。\n"
                    "任务目标：从知识库中找到与当前任务相关的所有知识条目，并产出引用清单。\n\n"
                    "参考文件：$task_dir/task.json（任务标题和描述）\n\n"
                    "执行步骤：\n"
                    "1. 读取 task.json 获取任务标题和描述\n"
                    "2. 用 kanban knowledge hybrid \"<任务标题+描述关键词>\" 搜索知识库\n"
                    "3. 对搜索结果逐一判断相关性，筛选出 medium/high 的条目\n"
                    "4. 如无匹配，调用 kanban knowledge semantic \"<任务描述>\" 扩大搜索\n"
                    "5. 仍无匹配则记录原因（如：全新领域、无相关经验）\n\n"
                    "输出：写入 $task_dir/plan/knowledge_used.json，格式：\n"
                    "{\n"
                    '  "matched": [\n'
                    '    {"id": "K001", "title": "...", "relevance": "high",\n'
                    '     "how_to_apply": "当前任务可如何借鉴该条目的具体方式"},\n'
                    '    {"id": "K005", "title": "...", "relevance": "medium",\n'
                    '     "how_to_apply": "..."}\n'
                    "  ],\n"
                    '  "search_queries": ["hybrid 搜索词1", "semantic 搜索词2"],\n'
                    '  "no_match_reason": null\n'
                    "}\n\n"
                    "任务边界：\n"
                    "- 只产出 knowledge_used.json，不修改任何其他文件\n"
                    "- 完成后立即停止，不调用 kanban run/transition/complete-phase\n"
                    "- 不要进入后续阶段\n\n"
                    "完成标志：$task_dir/plan/knowledge_used.json 文件存在且非空。"
                )),
        StepDef("plan.plan_A", "Plan A: 需求澄清（brainstorming）",
                actions=["kanban time start $task_id plan_A",
                         "使用 Skill tool 调用 superpowers:brainstorming，与用户交互完成需求澄清",
                         "产出 spec.md 保存到 $task_dir/spec.md",
                         "kanban time end $task_id plan_A"],
                interactive=True),
        StepDef("plan.check_constraints", "知识库约束检查：编码前搜索相关约束与模式",
                actions=["kanban knowledge hybrid \"$task_title\"",
                         "搜索知识库中与当前任务相关的约束条件、架构模式和已知踩坑记录",
                         "将发现的约束记录到 plan/constraints.md"],
                agent_type="kanban-planner"),
        StepDef("plan.user_confirm_spec", "用户确认 spec.md",
                actions=["展示 spec.md 内容给用户确认"],
                user_action=True),
        StepDef("plan.plan_B", "Plan B: 任务拆解（writing-plans）",
                actions=["kanban time start $task_id plan_B",
                         "spawn writing-plans agent",
                         "kanban time end $task_id plan_B"],
                agent_type="kanban-planner",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的 writing-plans 子任务。"
                    "使用 superpowers:writing-plans 技能完成任务拆解。\n\n"
                    "参考文件：\n"
                    "- $task_dir/spec.md（已由 brainstorming 产出）\n"
                    "- $task_dir/plan/knowledge_used.json（知识库引用清单，必须参考）\n\n"
                    "重要约束：\n"
                    "- 每个 subtask 的 plan/ST-NNN_*.md 必须在开头引用相关知识条目：\n"
                    '  \"知识库参考: [K001] xxx 模式 — 避免 xx 问题\"\n'
                    "- 如 knowledge_used.json 为空或无匹配，请在 plan/index.md 中说明原因\n\n"
                    "任务边界：\n"
                    "- 产出 plan/index.md、plan/ST-NNN_*.md、task_breakdown.json 保存到 $task_dir/\n"
                    "- 完成后立即停止，不要建议或选择执行方式\n"
                    "- 不要调用任何 kanban CLI 命令\n"
                    "- 不要启动 subagent-driven-development 或任何执行流程\n\n"
                    "完成标志：$task_dir/plan/index.md 和 $task_dir/task_breakdown.json 文件存在且非空。"
                )),
        StepDef("plan.complete", "Plan 阶段完成",
                actions=["kanban time end $task_id plan",
                         "kanban guard check-artifacts $task_id plan",
                         "kanban workflow checkpoint $task_id plan",
                         "kanban workflow complete-phase $task_id"]),
    ],
    "plan_review": [
        StepDef("plan_review.spawn", "并行启动 6 维度 Plan Review agents",
                actions=["kanban workflow get-phase-agents plan_review",
                         "spawn 6 plan-reviewer agents (run_in_background=true)"],
                agent_type="kanban-plan-reviewer", parallel=True,
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的 Plan Review 评审员。"
                    "从你负责的维度评审 spec.md 和 plan/ 下的文件。\n\n"
                    "参考文件：$task_dir/spec.md、$task_dir/plan/index.md、$task_dir/task_breakdown.json\n\n"
                    "任务边界：\n"
                    "- 产出评审报告保存到 $report_dir/reviews/plan_review_report.json\n"
                    "- 完成后立即停止\n"
                    "- 不要调用任何 kanban CLI 命令\n"
                    "- 不要修改 spec.md 或 plan 文件\n\n"
                    "完成标志：$report_dir/reviews/plan_review_report.json 文件存在且非空。"
                )),
        StepDef("plan_review.collect", "收集评审报告",
                actions=["kanban workflow collect-plan-review $task_id"]),
        StepDef("plan_review.knowledge_cross_validate", "知识库交叉验证：验证知识引用完整性",
                actions=["kanban time start $task_id knowledge_cross_validate",
                         "spawn kanban-plan-reviewer agent 执行知识引用验证",
                         "kanban time end $task_id knowledge_cross_validate"],
                agent_type="kanban-plan-reviewer",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的知识引用验证 Agent。\n"
                    "检查任务是否充分引用了知识库中的相关经验。\n\n"
                    "参考文件：\n"
                    "- $task_dir/plan/knowledge_used.json（知识检索产出）\n"
                    "- $task_dir/plan/index.md\n"
                    "- $task_dir/plan/ST-NNN_*.md（各 subtask 文件）\n"
                    "- $task_dir/spec.md\n\n"
                    "验证清单（每个维度 0-3 分）：\n"
                    "1. 知识检索完整性 (3分)：knowledge_used.json 是否存在且非空？如为空，无匹配原因是 否合理？\n"
                    "2. 引用到位率 (3分)：plan/*.md 中引用的 K-NNN 条目数是否覆盖了 knowledge_used.json 中的 high+medium 条目？\n"
                    "3. 应用合理性 (3分)：每个引用的 how_to_apply 是否在 subtask 中具体体现？是否存在形式化引用（标了但 没用）？\n\n"
                    "评分规则：\n"
                    "- 总分 = (知识检索完整性 + 引用到位率 + 应用合理性) / 9 * 10\n"
                    "- 总分 < 6.0 视为不通过，需回退到 plan.knowledge_search 重做\n"
                    "- knowledge_used.json 为空但原因合理 → 知识检索完整性给 3 分\n\n"
                    "输出：写入 $report_dir/reviews/knowledge_citation_report.json，格式：\n"
                    '{"scores": {"检索完整性": N, "引用到位率": N, "应用合理性": N},\n'
                    ' "total": N.N, "passed": true/false,\n'
                    ' "unreferenced": ["K001 已匹配但未被任何 plan 文件引用"],\n'
                    ' "formality_only": ["K003 被引用但 subtask 中未体现具体应用"],\n'
                    ' "suggestions": ["建议在 ST-002 中引用 K005 的模式"]}\n\n'
                    "任务边界：\n"
                    "- 只产出 knowledge_citation_report.json，不修改任何其他文件\n"
                    "- 完成后立即停止\n\n"
                    "完成标志：$report_dir/reviews/knowledge_citation_report.json 文件存在且非空。"
                )),
        StepDef("plan_review.check", "评分检查（不达标则重试）",
                actions=["检查 plan_review_report.json 总分 >= pass_threshold"]),
        StepDef("plan_review.complete", "Plan Review 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "qa_spec": [
        StepDef("qa_spec.spawn", "QA Agent 生成 test_spec.md",
                actions=["kanban workflow get-phase-agents qa_spec",
                         "spawn kanban-qa agent (mode=spec)"],
                agent_type="kanban-qa",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的 QA Spec 生成器。"
                    "基于 spec.md 和 plan 文件生成测试规格。\n\n"
                    "参考文件：$task_dir/spec.md、$task_dir/plan/index.md、$task_dir/task_breakdown.json\n\n"
                    "任务边界：\n"
                    "- 产出 test_spec.md 保存到 $task_dir/test_spec.md\n"
                    "- 完成后立即停止\n"
                    "- 不要调用任何 kanban CLI 命令\n"
                    "- 不要进入 spec_review 或执行阶段\n\n"
                    "完成标志：$task_dir/test_spec.md 文件存在且非空。"
                )),
        StepDef("qa_spec.complete", "QA Spec 完成",
                actions=["kanban guard check-artifacts $task_id qa_spec",
                         "kanban workflow complete-phase $task_id"]),
    ],
    "spec_review": [
        StepDef("spec_review.spawn", "Test Spec Reviewer 审核",
                actions=["kanban workflow get-phase-agents spec_review",
                         "spawn kanban-test-spec-reviewer agent"],
                agent_type="kanban-test-spec-reviewer",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的测试规格评审员。"
                    "审核 test_spec.md 的质量和完整性。\n\n"
                    "参考文件：$task_dir/test_spec.md、$task_dir/spec.md\n\n"
                    "任务边界：\n"
                    "- 产出评审报告保存到 $report_dir/reviews/spec_review_report.json\n"
                    "- 完成后立即停止\n"
                    "- 不要调用任何 kanban CLI 命令\n"
                    "- 不要修改 test_spec.md\n\n"
                    "完成标志：$report_dir/reviews/spec_review_report.json 文件存在且非空。"
                )),
        StepDef("spec_review.check", "评分检查",
                actions=["检查 spec_review_report.json 总分 >= pass_threshold"]),
        StepDef("spec_review.user_confirm", "用户确认测试用例",
                actions=["展示 review 摘要 + test_spec.md，approve / revise"],
                user_action=True),
        StepDef("spec_review.complete", "Spec Review 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "execute": [
        StepDef("execute.pitfall_check", "踩坑预警：执行前搜索相关踩坑记录",
                actions=["kanban knowledge similar --tags \"$(kanban knowledge match '$task_title' --json | python3 -c 'import sys,json;print(\\\",\\\".join(json.load(sys.stdin)[\\\"data\\\"][\\\"domains\\\"][:3]))')\" 2>/dev/null || kanban knowledge hybrid \"$task_title 踩坑 注意事项 错误\"",
                         "检查是否有与当前任务相关的已知踩坑记录",
                         "将匹配到的踩坑写入 plan/pitfall_warnings.md"],
                agent_type="kanban-planner"),
        StepDef("execute.spawn", "按拓扑批次 spawn executor agents",
                actions=["计算并行批次（依赖拓扑 + file_ownership）",
                         "每批 spawn kanban-executor agents (run_in_background=true)",
                         "每 subtask 独立 agent，不合并"],
                agent_type="kanban-executor", parallel=True,
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的执行器。"
                    "按 TDD 方式实现分配给你的 subtask。\n\n"
                    "参考文件：$task_dir/plan/ST-NNN_*.md（你的 subtask plan）、$task_dir/test_spec.md\n\n"
                    "任务边界：\n"
                    "- 实现代码并保存到 $output_dir/\n"
                    "- 编写测试并确保通过\n"
                    "- 产出 execution_summary.md 保存到 $report_dir/execute/\n"
                    "- 完成后立即停止\n"
                    "- 不要调用任何 kanban CLI 命令\n"
                    "- 不要进入 evaluate 或后续阶段\n\n"
                    "完成标志：$report_dir/execute/execution_summary.md 文件存在且非空。"
                )),
        StepDef("execute.verify", "验证执行产物",
                actions=["kanban guard check-artifacts $task_id execute"]),
        StepDef("execute.commit", "Git 提交执行产物",
                actions=["kanban workflow checkpoint $task_id execute"]),
        StepDef("execute.complete", "Execute 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "evaluate": [
        StepDef("evaluate.spawn", "并行启动评估 agents",
                actions=["kanban workflow get-phase-agents evaluate",
                         "spawn 4 角色 agents (run_in_background=true)"],
                agent_type="kanban-code-reviewer", parallel=True,
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的评估员。"
                    "从你负责的角色（code_reviewer/qa/pm/designer）评估代码质量。\n\n"
                    "参考文件：$task_dir/ 下的所有实现代码和测试\n\n"
                    "任务边界：\n"
                    "- 产出评审报告保存到 $report_dir/reviews/{role}_report.json\n"
                    "- 完成后立即停止\n"
                    "- 不要调用任何 kanban CLI 命令\n"
                    "- 不要修改任何代码文件\n\n"
                    "完成标志：$report_dir/reviews/{role}_report.json 文件存在且非空。"
                )),
        StepDef("evaluate.e2e_run", "E2E 测试执行（如项目配置了 E2E）",
                actions=["检查 $task_dir/test_profile.md 是否定义了 E2E 策略",
                         "如有 E2E 配置则 spawn kanban-e2e-runner agent 执行浏览器测试",
                         "无配置则跳过此步骤"],
                agent_type="kanban-e2e-runner",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的 E2E 测试执行器。\n"
                    "在浏览器中实际验证功能是否正常工作。\n\n"
                    "参考文件：\n"
                    "- $task_dir/test_profile.md（E2E 测试策略）\n"
                    "- $task_dir/test_spec.md（测试用例）\n"
                    "- $task_dir/ 下的实现代码\n\n"
                    "任务边界：\n"
                    "- 启动浏览器执行 E2E 场景\n"
                    "- 产出 E2E 测试报告保存到 $report_dir/reviews/e2e_report.json\n"
                    "- 如无 E2E 配置或浏览器不可用，产出说明性报告并完成\n"
                    "- 完成后立即停止\n"
                    "- 不要调用任何 kanban CLI 命令\n\n"
                    "完成标志：$report_dir/reviews/e2e_report.json 文件存在且非空。"
                )),
        StepDef("evaluate.collect_scores", "收集评分（自动同步）",
                actions=["评分已由 complete-phase 自动同步"]),
        StepDef("evaluate.check_score", "自迭代决策（禁止询问用户）",
                actions=["kanban workflow self-improve-check $task_id",
                         "all_pass → Retrospective",
                         "hot(>=7.0) → 自动回 Execute",
                         "full(<7.0) → 自动回 Plan"]),
        StepDef("evaluate.commit", "Git 提交评估结果",
                actions=["kanban workflow checkpoint $task_id evaluate"]),
        StepDef("evaluate.complete", "Evaluate 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "retrospective": [
        StepDef("retrospective.spawn", "并行启动复盘 agents",
                actions=["kanban workflow get-phase-agents retrospective",
                         "spawn 3 agents: retrospective/acceptance/knowledge (parallel)"],
                parallel=True,
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的复盘 agent。"
                    "完成复盘总结、验收文档和知识提取。\n\n"
                    "参考文件：$task_dir/ 下的所有产物\n\n"
                    "任务边界：\n"
                    "- 产出 retrospective.md 和 acceptance.md 保存到 $task_dir/\n"
                    "- 产出 knowledge_extracted.json 保存到 $report_dir/\n"
                    "- 完成后立即停止\n"
                    "- 不要调用任何 kanban CLI 命令\n\n"
                    "完成标志：$task_dir/retrospective.md 和 $task_dir/acceptance.md 文件存在。"
                )),
        StepDef("retrospective.knowledge_import", "导入提取的知识",
                actions=["complete-phase 自动导入 knowledge_extracted.json"]),
        StepDef("retrospective.complete", "Retrospective 完成",
                actions=["kanban guard check-artifacts $task_id retrospective",
                         "kanban workflow checkpoint $task_id retrospective",
                         "kanban workflow complete-phase $task_id"]),
    ],
    "user_decision": [
        StepDef("user_decision.present", "展示变更摘要",
                actions=["展示 retrospective + acceptance + 变更全景"],
                user_action=True),
        StepDef("user_decision.wait", "等待用户决策",
                actions=["kanban decide $task_id --action <approve_and_archive|abort|restart>"],
                user_action=True),
    ],
    "archive": [
        StepDef("archive.merge", "合并 worktree 代码",
                actions=["kanban worktree merge $task_id"]),
        StepDef("archive.guard", "归档 Guards — inbox + subtask + stray",
                actions=["kanban guard check-inbox $task_id",
                         "kanban guard check-pending-subtasks $task_id",
                         "kanban guard check-archive-stray $task_id"]),
        StepDef("archive.cleanup", "清理 worktree",
                actions=["kanban worktree remove $task_id",
                         "kanban clean $task_id"]),
    ],
}

LIGHTWEIGHT_STEPS: dict[str, list[StepDef]] = {
    "plan": [
        StepDef("plan.plan_A", "Plan: 需求澄清（brainstorming，轻量）",
                actions=["kanban time start $task_id plan_A",
                         "使用 Skill tool 调用 superpowers:brainstorming",
                         "产出 spec.md 保存到 $task_dir/spec.md",
                         "kanban time end $task_id plan_A"],
                interactive=True),
        StepDef("plan.check_constraints", "知识库约束检查：编码前搜索相关约束与模式",
                actions=["kanban knowledge hybrid \"$task_title\"",
                         "搜索知识库中与当前任务相关的约束条件、架构模式和已知踩坑记录",
                         "将发现的约束记录到 plan/constraints.md"],
                agent_type="kanban-planner"),
        # Lightweight: no user_confirm_spec - brainstorming already
        # gathered requirements interactively, proceed to task breakdown
        StepDef("plan.plan_B", "Plan: 任务拆解（writing-plans）",
                actions=["kanban time start $task_id plan_B",
                         "spawn writing-plans agent",
                         "kanban time end $task_id plan_B"],
                agent_type="kanban-planner",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的 writing-plans 子任务。"
                    "使用 superpowers:writing-plans 技能完成任务拆解。\n\n"
                    "参考文件：$task_dir/spec.md（已由 brainstorming 产出）\n\n"
                    "任务边界：\n"
                    "- 产出 plan/index.md、plan/ST-NNN_*.md、task_breakdown.json 保存到 $task_dir/\n"
                    "- 完成后立即停止，不要建议或选择执行方式\n"
                    "- 不要调用任何 kanban CLI 命令\n\n"
                    "完成标志：$task_dir/plan/index.md 和 $task_dir/task_breakdown.json 文件存在且非空。"
                )),
        StepDef("plan.complete", "Plan 阶段完成",
                actions=["kanban time end $task_id plan",
                         "kanban guard check-artifacts $task_id plan",
                         "kanban workflow checkpoint $task_id plan",
                         "kanban workflow complete-phase $task_id"]),
    ],
    "execute": FULL_STEPS["execute"],
    "evaluate": [
        StepDef("evaluate.spawn_qa", "QA 单角色评估 (lightweight)",
                actions=["spawn kanban-qa agent (eval mode)"],
                agent_type="kanban-qa"),
        StepDef("evaluate.e2e_run", "E2E 测试执行（如项目配置了 E2E）",
                actions=["检查 $task_dir/test_profile.md 是否定义了 E2E 策略",
                         "如有 E2E 配置则 spawn kanban-e2e-runner agent",
                         "无配置则跳过此步骤"],
                agent_type="kanban-e2e-runner",
                spawn_prompt=(
                    "你是 kanban 任务 $task_id 的 E2E 测试执行器。\n"
                    "在浏览器中实际验证功能是否正常工作。\n\n"
                    "参考文件：$task_dir/test_profile.md、$task_dir/test_spec.md\n\n"
                    "任务边界：\n"
                    "- 启动浏览器执行 E2E 场景\n"
                    "- 产出报告保存到 $report_dir/reviews/e2e_report.json\n"
                    "- 如无 E2E 配置或浏览器不可用，产出说明性报告并完成\n"
                    "- 完成后立即停止\n\n"
                    "完成标志：$report_dir/reviews/e2e_report.json 文件存在且非空。"
                )),
        StepDef("evaluate.collect_score", "收集评分",
                actions=["评分已由 complete-phase 自动同步"]),
        StepDef("evaluate.check_score", "评分检查",
                actions=["kanban workflow self-improve-check $task_id"]),
        StepDef("evaluate.complete", "Evaluate 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "user_decision": FULL_STEPS["user_decision"],
    "archive": FULL_STEPS["archive"],
}


def _get_steps(mode: str) -> dict[str, list[StepDef]]:
    if mode == "lightweight":
        return LIGHTWEIGHT_STEPS
    return FULL_STEPS


def _get_phase_order(lightweight: bool) -> list[Phase]:
    if lightweight:
        return Scheduler.LIGHTWEIGHT_PHASE_ORDER
    return Scheduler.PHASE_ORDER


# ── Progress tracking ───────────────────────────────────────────────────

def _progress_path(fs: Filesystem, task_id: str) -> Path:
    return fs.task_dir(task_id) / "progress.json"


def load_progress(fs: Filesystem, task_id: str) -> dict:
    pp = _progress_path(fs, task_id)
    if pp.is_file():
        return json.loads(pp.read_text(encoding="utf-8"))
    return {"task_id": task_id, "steps": {}}


def save_progress(fs: Filesystem, task_id: str, progress: dict) -> None:
    pp = _progress_path(fs, task_id)
    pp.parent.mkdir(parents=True, exist_ok=True)
    pp.write_text(json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")


def mark_step(fs: Filesystem, task_id: str, step_id: str, status: str = "completed") -> dict:
    progress = load_progress(fs, task_id)
    progress["steps"][step_id] = {
        "status": status,
        "updated_at": time.time(),
    }
    save_progress(fs, task_id, progress)
    return progress


# ── Core: determine next step ───────────────────────────────────────────

@dataclass
class NextStepResult:
    task_id: str
    phase: str
    step_id: str
    step_index: int
    total_steps: int
    description: str
    actions: list[str]
    agent_type: Optional[str] = None
    parallel: bool = False
    user_action: bool = False
    phase_complete: bool = False
    all_complete: bool = False
    context_files: list[str] = field(default_factory=list)
    knowledge_summary: Optional[dict] = None  # #211: knowledge_used.json summary
    message: str = ""
    spawn_prompt: Optional[str] = None
    interactive: bool = False
    available_steps: list[dict] = field(default_factory=list)   # manual mode: available steps for user selection
    control_mode: str = "semi"  # current control mode


def next_step(fs: Filesystem, config: Config, task: Task) -> NextStepResult:
    """Determine the exact next action for a task."""
    steps_map = _get_steps("lightweight" if task.lightweight else "full")
    progress = load_progress(fs, task.id)
    completed_steps = {k for k, v in progress.get("steps", {}).items() if v.get("status") == "completed"}

    phase_value = task.phase.value

    # Check if task is in draft status
    if task.status.value == "draft":
        return NextStepResult(
            task_id=task.id, phase=phase_value, step_id="draft.promote",
            step_index=0, total_steps=1,
            description="任务处于 draft 状态，需要 promote 到正式流程",
            actions=["kanban task promote " + task.id],
            message="draft 任务需要先 promote",
        )

    # Check if archived
    if task.status.value in ("archived", "cancelled"):
        return NextStepResult(
            task_id=task.id, phase=phase_value, step_id="done",
            step_index=0, total_steps=0,
            description="任务已归档/取消",
            actions=[], all_complete=True,
            message="任务已结束",
        )

    # Manual mode: return available steps for user selection
    if task.control_mode == ControlMode.MANUAL:
        skipped_steps = {k for k, v in progress.get("steps", {}).items() if v.get("status") == "skipped"}
        from kanban_framework.domain.step_registry import build_step_dag, get_available_steps
        dag = build_step_dag(lightweight=task.lightweight)
        available = get_available_steps(dag, completed_steps, skipped_steps)
        if not available:
            return NextStepResult(
                task_id=task.id, phase=task.phase.value, step_id="all_done",
                step_index=0, total_steps=0,
                description="所有步骤已完成",
                actions=[], all_complete=True,
                control_mode="manual",
            )
        return NextStepResult(
            task_id=task.id,
            phase=task.phase.value,
            step_id="manual.select",
            step_index=0,
            total_steps=len(dag["steps"]),
            description="手动模式 — 请选择下一步",
            actions=[],
            user_action=True,
            available_steps=available,
            control_mode="manual",
            message=f"手动模式: {len(available)} 个可用步骤",
        )

    # Get steps for current phase
    phase_steps = steps_map.get(phase_value, [])
    if not phase_steps:
        return NextStepResult(
            task_id=task.id, phase=phase_value, step_id="unknown",
            step_index=0, total_steps=0,
            description=f"阶段 {phase_value} 无定义步骤",
            actions=["kanban workflow transition " + task.id],
            message="未知阶段，尝试 transition 推进",
        )

    # Find first incomplete step
    for i, step in enumerate(phase_steps):
        if step.id not in completed_steps:
            context_files = _get_context_files(fs, task, phase_value)
            # Resolve spawn_prompt template variables
            prompt = step.spawn_prompt
            if prompt:
                td = fs.task_dir(task.id)
                iter_dir = td / f"iteration-{task.iteration}"
                prompt = prompt.replace("$task_id", task.id)
                prompt = prompt.replace("$task_dir", str(td))
                prompt = prompt.replace("$report_dir", str(iter_dir))
                prompt = prompt.replace("$iteration", str(task.iteration))
            return NextStepResult(
                task_id=task.id,
                phase=phase_value,
                step_id=step.id,
                step_index=i,
                total_steps=len(phase_steps),
                description=step.description,
                actions=[a.replace("$task_id", task.id) for a in step.actions],
                agent_type=step.agent_type,
                parallel=step.parallel,
                user_action=step.user_action,
                context_files=context_files,
                knowledge_summary=_load_knowledge_summary(fs, task),
                message=f"当前阶段: {phase_value}, 步骤 {i+1}/{len(phase_steps)}: {step.description}",
                spawn_prompt=prompt,
                interactive=step.interactive,
            )

    # All steps in current phase are complete — transition to next phase
    phase_order = _get_phase_order(task.lightweight)
    current_idx = None
    for idx, p in enumerate(phase_order):
        if p == task.phase:
            current_idx = idx
            break

    if current_idx is not None and current_idx < len(phase_order) - 1:
        next_phase = phase_order[current_idx + 1]
        return NextStepResult(
            task_id=task.id,
            phase=phase_value,
            step_id=f"transition_to_{next_phase.value}",
            step_index=len(phase_steps),
            total_steps=len(phase_steps),
            description=f"阶段 {phase_value} 全部完成，准备进入 {next_phase.value}",
            actions=[
                f"kanban workflow transition {task.id} {next_phase.value}",
                f"kanban workflow next-step {task.id}",
            ],
            phase_complete=True,
            message=f"阶段 {phase_value} 完成 → {next_phase.value}",
        )

    return NextStepResult(
        task_id=task.id, phase=phase_value, step_id="all_done",
        step_index=len(phase_steps), total_steps=len(phase_steps),
        description="所有阶段已完成",
        actions=[], all_complete=True,
        message="任务流程全部完成",
    )


def _load_knowledge_summary(fs: Filesystem, task: Task) -> dict | None:
    """Load knowledge_used.json and return a lightweight summary for next-step output."""
    import json
    kf = fs.task_dir(task.id) / "plan" / "knowledge_used.json"
    if not kf.is_file():
        return None
    try:
        data = json.loads(kf.read_text(encoding="utf-8"))
        matched = data.get("matched", [])
        return {
            "matched_count": len(matched),
            "top_matches": [
                {"id": m["id"], "title": m["title"], "relevance": m.get("relevance", ""),
                 "how_to_apply": m.get("how_to_apply", "")[:100]}
                for m in matched[:5]
            ],
            "no_match_reason": data.get("no_match_reason"),
        }
    except (json.JSONDecodeError, OSError):
        return None


def _get_context_files(fs: Filesystem, task: Task, phase: str) -> list[str]:
    td = fs.task_dir(task.id)
    files = []
    candidates = [
        td / "task.json",
        td / "spec.md",
        td / "inbox.md",
        td / "task_breakdown.json",
        td / "test_spec.md",
    ]
    for c in candidates:
        if c.is_file():
            files.append(str(c.relative_to(fs.kanban_dir)))
    return files


def next_step_to_dict(result: NextStepResult) -> dict:
    return {
        "task_id": result.task_id,
        "phase": result.phase,
        "step_id": result.step_id,
        "step_index": result.step_index,
        "total_steps": result.total_steps,
        "description": result.description,
        "actions": result.actions,
        "agent_type": result.agent_type,
        "parallel": result.parallel,
        "user_action": result.user_action,
        "phase_complete": result.phase_complete,
        "all_complete": result.all_complete,
        "context_files": result.context_files,
        "knowledge_summary": result.knowledge_summary,
        "message": result.message,
        "spawn_prompt": result.spawn_prompt,
        "interactive": result.interactive,
        "available_steps": result.available_steps,
        "control_mode": result.control_mode,
    }


def rollback_step(fs: Filesystem, task_id: str, target_step_id: str) -> dict:
    """Reset target step and all subsequent steps to pending. Preserve artifacts."""
    from kanban_framework.domain.step_registry import build_step_dag

    progress = load_progress(fs, task_id)
    steps = progress.get("steps", {})

    # Read task to determine lightweight flag
    try:
        task_path = fs.task_dir(task_id) / "task.json"
        task_data = json.loads(task_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {"error": f"task {task_id} not found or invalid", "rolled_back": []}
    lightweight = task_data.get("lightweight", False)

    dag = build_step_dag(lightweight=lightweight)
    all_step_ids = [s["id"] for s in dag["steps"]]

    # Find index of target step
    try:
        target_idx = all_step_ids.index(target_step_id)
    except ValueError:
        return {"error": f"step {target_step_id} not found in workflow", "rolled_back": []}

    # Reset target and all subsequent steps to pending
    rolled_back = []
    for step_id in all_step_ids[target_idx:]:
        if step_id in steps:
            old_status = steps[step_id].get("status", "pending")
            if old_status != "pending":
                steps[step_id] = {"status": "pending", "updated_at": time.time()}
                rolled_back.append({"id": step_id, "from": old_status, "to": "pending"})

    progress["steps"] = steps
    save_progress(fs, task_id, progress)
    return {"task_id": task_id, "target": target_step_id, "rolled_back": rolled_back}
