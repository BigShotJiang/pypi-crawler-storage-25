"""
cirqit.circuit - Main QuantumCircuit class
"""

import numpy as np
from .statevector import StateVector
from .gates import GATE_REGISTRY


class QuantumCircuit:
    """
    Main quantum circuit class.

    Example
    -------
    >>> from cirqit import QuantumCircuit
    >>> qc = QuantumCircuit(2)
    >>> qc.h(0)
    >>> qc.cnot(0, 1)
    >>> qc.measure_all()
    >>> result = qc.run(shots=1024)
    >>> print(result)
    >>> qc.draw()
    """

    def __init__(self, n_qubits: int, n_classical: int = None, name: str = "circuit"):
        assert n_qubits >= 1, "Need at least 1 qubit"
        self.n_qubits = n_qubits
        self.n_classical = n_classical or n_qubits
        self.name = name
        self._ops = []               # Operation log
        self._measured_qubits = []   # Qubits with measure ops
        self._noise_model = None     # Optional noise model
        self._sv = StateVector(n_qubits)

    # ─── Single-Qubit Gates ──────────────────────────────────────────────────

    def i(self, qubit):
        self._add_op('i', [qubit])
        return self

    def x(self, qubit):
        self._add_op('x', [qubit])
        return self

    def y(self, qubit):
        self._add_op('y', [qubit])
        return self

    def z(self, qubit):
        self._add_op('z', [qubit])
        return self

    def h(self, qubit):
        self._add_op('h', [qubit])
        return self

    def s(self, qubit):
        self._add_op('s', [qubit])
        return self

    def t(self, qubit):
        self._add_op('t', [qubit])
        return self

    def sdg(self, qubit):
        self._add_op('sdg', [qubit])
        return self

    def tdg(self, qubit):
        self._add_op('tdg', [qubit])
        return self

    def sx(self, qubit):
        self._add_op('sx', [qubit])
        return self

    def rx(self, theta, qubit):
        self._add_op('rx', [qubit], [theta])
        return self

    def ry(self, theta, qubit):
        self._add_op('ry', [qubit], [theta])
        return self

    def rz(self, theta, qubit):
        self._add_op('rz', [qubit], [theta])
        return self

    def p(self, phi, qubit):
        self._add_op('p', [qubit], [phi])
        return self

    def u(self, theta, phi, lam, qubit):
        self._add_op('u', [qubit], [theta, phi, lam])
        return self

    # ─── Two-Qubit Gates ────────────────────────────────────────────────────

    def cnot(self, control, target):
        self._add_op('cnot', [control, target])
        return self

    def cx(self, control, target):
        return self.cnot(control, target)

    def cy(self, control, target):
        self._add_op('cy', [control, target])
        return self

    def cz(self, control, target):
        self._add_op('cz', [control, target])
        return self

    def swap(self, q0, q1):
        self._add_op('swap', [q0, q1])
        return self

    def iswap(self, q0, q1):
        self._add_op('iswap', [q0, q1])
        return self

    def crx(self, theta, control, target):
        self._add_op('crx', [control, target], [theta])
        return self

    def cry(self, theta, control, target):
        self._add_op('cry', [control, target], [theta])
        return self

    def crz(self, theta, control, target):
        self._add_op('crz', [control, target], [theta])
        return self

    def cp(self, phi, control, target):
        self._add_op('cp', [control, target], [phi])
        return self

    # ─── Three-Qubit Gates ───────────────────────────────────────────────────

    def ccx(self, ctrl0, ctrl1, target):
        self._add_op('ccx', [ctrl0, ctrl1, target])
        return self

    def toffoli(self, ctrl0, ctrl1, target):
        return self.ccx(ctrl0, ctrl1, target)

    def cswap(self, control, q0, q1):
        self._add_op('cswap', [control, q0, q1])
        return self

    def fredkin(self, control, q0, q1):
        return self.cswap(control, q0, q1)

    # ─── Barriers / Reset ────────────────────────────────────────────────────

    def barrier(self, *qubits):
        """Visual separator only (no physical operation)."""
        self._ops.append({'name': 'barrier', 'qubits': list(qubits or range(self.n_qubits)), 'params': []})
        return self

    def reset(self, qubit):
        """Reset qubit to |0>."""
        self._ops.append({'name': 'reset', 'qubits': [qubit], 'params': []})
        return self

    # ─── Measurement ─────────────────────────────────────────────────────────

    def measure(self, qubit, clbit=None):
        if qubit not in self._measured_qubits:
            self._measured_qubits.append(qubit)
        self._ops.append({'name': 'measure', 'qubits': [qubit], 'params': []})
        return self

    def measure_all(self):
        for q in range(self.n_qubits):
            self.measure(q)
        return self

    # ─── Custom unitary ──────────────────────────────────────────────────────

    def unitary(self, matrix, qubits, label='U'):
        """Apply an arbitrary unitary matrix."""
        matrix = np.array(matrix, dtype=complex)
        self._ops.append({
            'name': label, 'qubits': list(qubits),
            'params': [], 'matrix': matrix
        })
        return self

    # ─── Noise ───────────────────────────────────────────────────────────────

    def set_noise_model(self, noise_model):
        self._noise_model = noise_model
        return self

    # ─── Run ─────────────────────────────────────────────────────────────────

    def run(self, shots: int = 1024, seed: int = None) -> dict:
        """Execute circuit and return measurement counts."""
        if seed is not None:
            np.random.seed(seed)

        self._sv.reset()
        nm = self._noise_model

        for op in self._ops:
            name = op['name']
            qubits = op['qubits']
            params = op.get('params', [])

            if name in ('barrier', 'measure'):
                continue

            if name == 'reset':
                self._sv.measure_qubit(qubits[0])
                continue

            # Custom unitary
            if 'matrix' in op:
                mat = op['matrix']
                if mat.shape == (2, 2):
                    self._sv.apply_single(mat, qubits[0])
                elif mat.shape == (4, 4):
                    self._sv.apply_two(mat, qubits[0], qubits[1])
                elif mat.shape == (8, 8):
                    self._sv.apply_three(mat, qubits[0], qubits[1], qubits[2])
                continue

            # Lookup gate
            gate_fn = GATE_REGISTRY.get(name.lower())
            if gate_fn is None:
                raise ValueError(f"Unknown gate: {name}")

            mat = gate_fn(*params)

            if len(qubits) == 1:
                self._sv.apply_single(mat, qubits[0])
                if nm:
                    nm.apply_gate_noise(name, self._sv, qubits[0])
            elif len(qubits) == 2:
                self._sv.apply_two(mat, qubits[0], qubits[1])
            elif len(qubits) == 3:
                self._sv.apply_three(mat, qubits[0], qubits[1], qubits[2])

        # Measure
        if not self._measured_qubits:
            return {}

        counts = self._sv.measure_all(shots)
        if nm:
            counts = nm.apply_readout_noise(counts)
        return counts

    def statevector(self) -> np.ndarray:
        """Get final statevector (runs without measurement)."""
        self._sv.reset()
        for op in self._ops:
            name = op['name']
            if name in ('barrier', 'measure', 'reset'):
                continue
            qubits = op['qubits']
            params = op.get('params', [])
            if 'matrix' in op:
                mat = op['matrix']
                if mat.shape == (2, 2):
                    self._sv.apply_single(mat, qubits[0])
                elif mat.shape == (4, 4):
                    self._sv.apply_two(mat, qubits[0], qubits[1])
                elif mat.shape == (8, 8):
                    self._sv.apply_three(mat, qubits[0], qubits[1], qubits[2])
                continue
            gate_fn = GATE_REGISTRY.get(name.lower())
            if gate_fn:
                mat = gate_fn(*params)
                if len(qubits) == 1:
                    self._sv.apply_single(mat, qubits[0])
                elif len(qubits) == 2:
                    self._sv.apply_two(mat, qubits[0], qubits[1])
                elif len(qubits) == 3:
                    self._sv.apply_three(mat, qubits[0], qubits[1], qubits[2])
        return self._sv

    def probabilities(self) -> dict:
        """Return state probabilities without measurement."""
        sv = self.statevector()
        probs = sv.probabilities()
        result = {}
        for i, p in enumerate(probs):
            if p > 1e-10:
                result[format(i, f'0{self.n_qubits}b')] = float(p)
        return result

    def bloch_vector(self, qubit: int) -> tuple:
        """Bloch sphere coordinates for a qubit after circuit execution."""
        sv = self.statevector()
        return sv.bloch_vector(qubit)

    # ─── Visualization ───────────────────────────────────────────────────────

    def draw(self, output='text', figsize=None, show=True):
        """
        Draw the circuit.
        output: 'text' (ASCII) | 'mpl' (matplotlib)
        """
        gate_ops = [op for op in self._ops if op['name'] not in ('measure', 'barrier')]
        if output == 'text':
            from .visualize import draw_ascii
            draw_ascii(gate_ops, self.n_qubits, self._measured_qubits)
        elif output == 'mpl':
            from .visualize import draw_matplotlib
            fig = draw_matplotlib(gate_ops, self.n_qubits, self._measured_qubits, figsize)
            if show:
                import matplotlib.pyplot as plt
                plt.show()
            return fig
        else:
            raise ValueError("output must be 'text' or 'mpl'")

    def plot_histogram(self, counts: dict = None, shots: int = 1024, show=True):
        """Plot measurement histogram."""
        from .visualize import plot_histogram
        if counts is None:
            counts = self.run(shots=shots)
        fig = plot_histogram(counts, title=f"Circuit: {self.name}")
        if show:
            import matplotlib.pyplot as plt
            plt.show()
        return fig

    def plot_bloch(self, qubit: int = 0, show=True):
        """Plot Bloch sphere for a qubit."""
        from .visualize import plot_bloch_sphere
        bx, by, bz = self.bloch_vector(qubit)
        fig = plot_bloch_sphere(bx, by, bz, qubit)
        if show:
            import matplotlib.pyplot as plt
            plt.show()
        return fig

    # ─── Circuit Info ─────────────────────────────────────────────────────────

    def depth(self) -> int:
        """Circuit depth (number of gate layers)."""
        return len([op for op in self._ops if op['name'] not in ('barrier',)])

    def count_ops(self) -> dict:
        """Count of each gate type."""
        counts = {}
        for op in self._ops:
            n = op['name']
            counts[n] = counts.get(n, 0) + 1
        return counts

    def copy(self):
        """Return a copy of the circuit."""
        import copy
        return copy.deepcopy(self)

    def inverse(self):
        """Return inverse (dagger) circuit."""
        inv = QuantumCircuit(self.n_qubits, self.n_classical, name=self.name + "_inv")
        dag_map = {'s': 'sdg', 'sdg': 's', 't': 'tdg', 'tdg': 't'}
        for op in reversed(self._ops):
            name = op['name']
            if name in ('measure', 'barrier', 'reset'):
                continue
            inv_name = dag_map.get(name, name)
            inv_params = [-p for p in op.get('params', [])]
            inv._ops.append({'name': inv_name, 'qubits': op['qubits'], 'params': inv_params})
        return inv

    def compose(self, other):
        """Append another circuit to this one."""
        assert other.n_qubits == self.n_qubits
        import copy
        new = self.copy()
        new._ops.extend(copy.deepcopy(other._ops))
        new._measured_qubits = list(set(new._measured_qubits + other._measured_qubits))
        return new

    # ─── Internal ─────────────────────────────────────────────────────────────

    def _add_op(self, name, qubits, params=None):
        self._ops.append({'name': name, 'qubits': qubits, 'params': params or []})

    def __repr__(self):
        return (f"QuantumCircuit('{self.name}', n_qubits={self.n_qubits}, "
                f"depth={self.depth()}, gates={self.count_ops()})")

    def __len__(self):
        return self.depth()

    def run_async(self, shots: int = 1024, seed: int = None, noise_model=None):
        """
        Run circuit as a background job with unique Job ID.

        Returns a CirQitJob object immediately.
        Call .result() to block and get counts.

        Example
        -------
        >>> job = qc.run_async(shots=1024)
        >>> print(job.job_id)
        >>> counts = job.result()
        >>> job.summary()
        """
        from .job import CirQitJob, JobRegistry
        import copy
        circ_copy = copy.deepcopy(self)
        job = CirQitJob(
            circuit=circ_copy,
            shots=shots,
            seed=seed,
            backend="statevector",
            noise_model=noise_model
        )
        JobRegistry.register(job)
        return job
