"""
cirqit.density_matrix - Density matrix simulator
=================================================
Supports mixed states, open quantum systems, full Kraus noise.
More accurate than statevector for noisy circuits.

Usage
-----
>>> from cirqit.density_matrix import DensityMatrix
>>> dm = DensityMatrix(2)
>>> dm.apply_h(0)
>>> dm.apply_cnot(0, 1)
>>> print(dm)
>>> print(dm.measure_all(shots=1024))
"""

import numpy as np
from .gates import GATE_REGISTRY, I


class DensityMatrix:
    """
    Density matrix rho for n qubits.
    rho is a 2^n x 2^n complex matrix.
    Pure state: rho = |psi><psi|
    Mixed state: rho = sum_i p_i |psi_i><psi_i|
    """

    def __init__(self, n_qubits: int):
        self.n = n_qubits
        self.dim = 2 ** n_qubits
        # Start in |00...0><00...0|
        self.rho = np.zeros((self.dim, self.dim), dtype=complex)
        self.rho[0, 0] = 1.0

    def reset(self):
        self.rho = np.zeros((self.dim, self.dim), dtype=complex)
        self.rho[0, 0] = 1.0

    # ─── Gate application ─────────────────────────────────────────────────────

    def _full_unitary(self, gate: np.ndarray, qubit: int) -> np.ndarray:
        """Expand single-qubit gate to full 2^n space."""
        ops = [I() if q != qubit else gate for q in range(self.n)]
        U = ops[0]
        for op in ops[1:]:
            U = np.kron(U, op)
        return U

    def _full_two_qubit(self, gate: np.ndarray, q0: int, q1: int) -> np.ndarray:
        """Expand 4x4 gate to full 2^n space."""
        dim = self.dim
        n = self.n
        U = np.zeros((dim, dim), dtype=complex)
        for i in range(dim):
            for j in range(dim):
                bi0 = (i >> (n - 1 - q0)) & 1
                bi1 = (i >> (n - 1 - q1)) & 1
                bj0 = (j >> (n - 1 - q0)) & 1
                bj1 = (j >> (n - 1 - q1)) & 1
                mask = ~((1 << (n-1-q0)) | (1 << (n-1-q1)))
                if (i & mask) != (j & mask):
                    continue
                ri = bi0 * 2 + bi1
                rj = bj0 * 2 + bj1
                U[i, j] = gate[ri, rj]
        return U

    def apply_gate(self, gate: np.ndarray, qubit: int):
        """Apply single-qubit gate: rho -> U rho U†"""
        U = self._full_unitary(gate, qubit)
        self.rho = U @ self.rho @ U.conj().T

    def apply_two_qubit(self, gate: np.ndarray, q0: int, q1: int):
        """Apply two-qubit gate: rho -> U rho U†"""
        U = self._full_two_qubit(gate, q0, q1)
        self.rho = U @ self.rho @ U.conj().T

    def apply_kraus(self, kraus_ops: list, qubit: int):
        """
        Apply a quantum channel via Kraus operators.
        rho -> sum_k K_k rho K_k†
        kraus_ops: list of 2x2 numpy arrays
        """
        new_rho = np.zeros_like(self.rho)
        for K in kraus_ops:
            K_full = self._full_unitary(K, qubit)
            new_rho += K_full @ self.rho @ K_full.conj().T
        self.rho = new_rho

    # ─── Noise channels via Kraus ─────────────────────────────────────────────

    def depolarize(self, qubit: int, p: float):
        """Depolarizing channel: (1-p)rho + p/3*(X rho X + Y rho Y + Z rho Z)"""
        from .gates import X, Y, Z
        K0 = np.sqrt(1 - p) * np.eye(2, dtype=complex)
        K1 = np.sqrt(p / 3) * X()
        K2 = np.sqrt(p / 3) * Y()
        K3 = np.sqrt(p / 3) * Z()
        self.apply_kraus([K0, K1, K2, K3], qubit)

    def amplitude_damp(self, qubit: int, gamma: float):
        """Amplitude damping channel."""
        K0 = np.array([[1, 0], [0, np.sqrt(1 - gamma)]], dtype=complex)
        K1 = np.array([[0, np.sqrt(gamma)], [0, 0]], dtype=complex)
        self.apply_kraus([K0, K1], qubit)

    def phase_damp(self, qubit: int, gamma: float):
        """Phase damping (dephasing) channel."""
        K0 = np.array([[1, 0], [0, np.sqrt(1 - gamma)]], dtype=complex)
        K1 = np.array([[0, 0], [0, np.sqrt(gamma)]], dtype=complex)
        self.apply_kraus([K0, K1], qubit)

    def bit_flip(self, qubit: int, p: float):
        from .gates import X
        K0 = np.sqrt(1 - p) * np.eye(2, dtype=complex)
        K1 = np.sqrt(p) * X()
        self.apply_kraus([K0, K1], qubit)

    def phase_flip(self, qubit: int, p: float):
        from .gates import Z
        K0 = np.sqrt(1 - p) * np.eye(2, dtype=complex)
        K1 = np.sqrt(p) * Z()
        self.apply_kraus([K0, K1], qubit)

    def thermal_relax(self, qubit: int, t1: float, t2: float, t_gate: float):
        """Combined T1/T2 thermal relaxation."""
        gamma1 = 1 - np.exp(-t_gate / t1)
        gamma2 = 1 - np.exp(-t_gate / t2)
        self.amplitude_damp(qubit, gamma1)
        self.phase_damp(qubit, gamma2)

    # ─── Measurement & observables ────────────────────────────────────────────

    def probabilities(self) -> np.ndarray:
        """Diagonal of density matrix = measurement probabilities."""
        return np.real(np.diag(self.rho))

    def measure_all(self, shots: int = 1024) -> dict:
        probs = self.probabilities()
        probs = np.abs(probs) / np.sum(np.abs(probs))
        outcomes = np.random.choice(self.dim, size=shots, p=probs)
        counts = {}
        for o in outcomes:
            key = format(o, f'0{self.n}b')
            counts[key] = counts.get(key, 0) + 1
        return dict(sorted(counts.items()))

    def expectation(self, observable: np.ndarray) -> float:
        """<O> = Tr(O rho)"""
        return float(np.real(np.trace(observable @ self.rho)))

    def purity(self) -> float:
        """Tr(rho^2). Pure state = 1, maximally mixed = 1/2^n."""
        return float(np.real(np.trace(self.rho @ self.rho)))

    def von_neumann_entropy(self) -> float:
        """S(rho) = -Tr(rho log rho)"""
        eigenvalues = np.linalg.eigvalsh(self.rho)
        eigenvalues = eigenvalues[eigenvalues > 1e-12]
        return float(-np.sum(eigenvalues * np.log2(eigenvalues)))

    def fidelity(self, other) -> float:
        """Fidelity between two density matrices."""
        sqrt_rho = self._matrix_sqrt(self.rho)
        M = sqrt_rho @ other.rho @ sqrt_rho
        sqrt_M = self._matrix_sqrt(M)
        return float(np.real(np.trace(sqrt_M)) ** 2)

    def partial_trace(self, keep_qubits: list):
        """
        Partial trace — trace out all qubits NOT in keep_qubits.
        Returns reduced density matrix as numpy array.
        """
        n = self.n
        keep = sorted(keep_qubits)
        trace_out = [q for q in range(n) if q not in keep]
        rho = self.rho.reshape([2] * (2 * n))
        for q in sorted(trace_out, reverse=True):
            rho = np.trace(rho, axis1=q, axis2=q + n)
            n -= 1
        new_dim = 2 ** len(keep)
        return rho.reshape(new_dim, new_dim)

    def concurrence(self) -> float:
        """Concurrence for 2-qubit states (entanglement measure)."""
        assert self.n == 2, "Concurrence defined for 2 qubits only"
        from .gates import Y
        sy = Y()
        sigma_yy = np.kron(sy, sy)
        rho_tilde = sigma_yy @ self.rho.conj() @ sigma_yy
        M = self.rho @ rho_tilde
        eigenvalues = np.sqrt(np.abs(np.linalg.eigvals(M)))
        eigenvalues = np.sort(eigenvalues)[::-1]
        C = max(0.0, eigenvalues[0] - eigenvalues[1] - eigenvalues[2] - eigenvalues[3])
        return float(np.real(C))

    def bloch_vector(self, qubit: int) -> tuple:
        """Bloch vector (x, y, z) for single qubit via partial trace."""
        from .gates import X, Y, Z
        rho_q = self.partial_trace([qubit])
        bx = float(np.real(np.trace(X() @ rho_q)))
        by = float(np.real(np.trace(Y() @ rho_q)))
        bz = float(np.real(np.trace(Z() @ rho_q)))
        return bx, by, bz

    def _matrix_sqrt(self, M: np.ndarray) -> np.ndarray:
        vals, vecs = np.linalg.eigh(M)
        vals = np.maximum(vals, 0)
        return vecs @ np.diag(np.sqrt(vals)) @ vecs.conj().T

    def is_valid(self) -> bool:
        """Check rho is positive semidefinite, hermitian, trace 1."""
        is_herm = np.allclose(self.rho, self.rho.conj().T, atol=1e-8)
        is_trace1 = abs(np.trace(self.rho) - 1.0) < 1e-8
        eigenvalues = np.linalg.eigvalsh(self.rho)
        is_psd = np.all(eigenvalues >= -1e-8)
        return bool(is_herm and is_trace1 and is_psd)

    def __repr__(self):
        lines = [f"DensityMatrix ({self.n} qubits, purity={self.purity():.4f}):"]
        probs = self.probabilities()
        for i, p in enumerate(probs):
            if p > 1e-6:
                basis = format(i, f'0{self.n}b')
                lines.append(f"  |{basis}⟩⟨{basis}|: {p:.4f}")
        return "\n".join(lines)
