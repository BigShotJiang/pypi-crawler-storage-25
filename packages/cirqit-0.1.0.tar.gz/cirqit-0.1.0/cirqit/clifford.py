"""
cirqit.clifford - Clifford / Stabilizer simulator
==================================================
Uses the Aaronson-Gottesman (2004) binary tableau algorithm.
Runs 100+ qubits in milliseconds on a laptop.

Supported gates: H, X, Y, Z, S, Sdg, CX/CNOT, CZ, SWAP, measure
NOT supported: T, Rx, Ry, Rz, Toffoli (non-Clifford)

Reference: arXiv:quant-ph/0406196
"""

import numpy as np


# ─── Stabilizer Tableau ───────────────────────────────────────────────────────

class StabilizerTableau:
    """
    Binary symplectic tableau for n qubits.

    Rows 0..n-1      : destabilizer generators
    Rows n..2n-1     : stabilizer generators

    Each row: [x0..x(n-1) | z0..z(n-1) | r]
      x_i, z_i : Pauli X/Z bits
      r         : phase bit (0 = +1, 1 = -1)

    Shape: (2n, 2n+1) bool array
    """

    def __init__(self, n: int):
        self.n = n
        # Initialize to |00...0> state
        # Stabilizers: Z_i for each qubit
        # Destabilizers: X_i for each qubit
        self.tab = np.zeros((2 * n, 2 * n + 1), dtype=np.int8)
        for i in range(n):
            self.tab[i, i] = 1          # destabilizer: X_i
            self.tab[i + n, i + n] = 1  # stabilizer:   Z_i

    # ─── Gate operations ──────────────────────────────────────────────────────

    def h(self, qubit: int):
        """Hadamard: X↔Z, phase update"""
        n = self.n
        q = qubit
        for i in range(2 * n):
            x = self.tab[i, q]
            z = self.tab[i, q + n]
            # r ^= x & z  (phase flip when both X and Z)
            self.tab[i, 2 * n] ^= x & z
            # swap x and z
            self.tab[i, q], self.tab[i, q + n] = z, x

    def s(self, qubit: int):
        """S gate (phase): Z unchanged, X → iXZ"""
        n = self.n
        q = qubit
        for i in range(2 * n):
            x = self.tab[i, q]
            z = self.tab[i, q + n]
            self.tab[i, 2 * n] ^= x & z
            self.tab[i, q + n] ^= x

    def sdg(self, qubit: int):
        """S† gate = S S S"""
        self.s(qubit)
        self.s(qubit)
        self.s(qubit)

    def x(self, qubit: int):
        """Pauli X = H S S H"""
        self.h(qubit)
        self.s(qubit)
        self.s(qubit)
        self.h(qubit)

    def y(self, qubit: int):
        """Pauli Y = i X Z"""
        self.x(qubit)
        self.z(qubit)

    def z(self, qubit: int):
        """Pauli Z = S S"""
        self.s(qubit)
        self.s(qubit)

    def cnot(self, control: int, target: int):
        """CNOT (CX) gate"""
        n = self.n
        a, b = control, target
        for i in range(2 * n):
            xa, za = self.tab[i, a], self.tab[i, a + n]
            xb, zb = self.tab[i, b], self.tab[i, b + n]
            # phase: r ^= xa & zb & (xb ^ za ^ 1)
            self.tab[i, 2 * n] ^= xa & zb & ((xb ^ za ^ 1) & 1)
            self.tab[i, b] ^= xa       # xb ^= xa
            self.tab[i, a + n] ^= zb   # za ^= zb

    def cx(self, control: int, target: int):
        return self.cnot(control, target)

    def cz(self, q0: int, q1: int):
        """CZ = H(q1) CNOT H(q1)"""
        self.h(q1)
        self.cnot(q0, q1)
        self.h(q1)

    def swap(self, q0: int, q1: int):
        """SWAP = CNOT CNOT CNOT"""
        self.cnot(q0, q1)
        self.cnot(q1, q0)
        self.cnot(q0, q1)

    def cy(self, control: int, target: int):
        """CY = Sdg(target) CNOT S(target)"""
        self.sdg(target)
        self.cnot(control, target)
        self.s(target)

    # ─── Measurement ──────────────────────────────────────────────────────────

    def measure(self, qubit: int) -> int:
        """
        Measure qubit in Z basis. Returns 0 or 1.
        Collapses state. Aaronson-Gottesman Algorithm 1.
        """
        n = self.n
        a = qubit

        # Find stabilizer row i in [n, 2n) with x-bit set on qubit a
        p = None
        for i in range(n, 2 * n):
            if self.tab[i, a]:
                p = i
                break

        if p is not None:
            # Random outcome
            for i in range(2 * n):
                if i != p and self.tab[i, a]:
                    self._rowsum(i, p)
            # Copy stabilizer p -> destabilizer p-n
            self.tab[p - n] = self.tab[p].copy()
            # Set stabilizer p = +-Z_a
            self.tab[p] = 0
            self.tab[p, a + n] = 1
            outcome = np.random.randint(0, 2)
            self.tab[p, 2 * n] = outcome
            return outcome
        else:
            # Deterministic: scratch rowsum over destabilizers
            scratch = np.zeros(2 * n + 1, dtype=np.int8)
            for i in range(n):
                if self.tab[i, a]:
                    scratch = self._rowsum_scratch(scratch, self.tab[i + n])
            return int(scratch[2 * n])

    def measure_all(self, shots: int = 1024) -> dict:
        """Run shots measurements, resetting state each time."""
        counts = {}
        import copy
        for _ in range(shots):
            tab_copy = copy.deepcopy(self)
            bits = ''.join(str(tab_copy.measure(q)) for q in range(self.n))
            counts[bits] = counts.get(bits, 0) + 1
        return dict(sorted(counts.items()))

    # ─── Internal helpers ──────────────────────────────────────────────────────

    def _g(self, x1, z1, x2, z2) -> int:
        """Phase function for rowsum."""
        if x1 == 0 and z1 == 0:
            return 0
        if x1 == 1 and z1 == 1:
            return int(z2) - int(x2)
        if x1 == 1 and z1 == 0:
            return int(z2) * (2 * int(x2) - 1)
        # x1==0, z1==1
        return int(x2) * (1 - 2 * int(z2))

    def _rowsum(self, target: int, source: int):
        """In-place rowsum: tab[target] = tab[source] * tab[target]"""
        n = self.n
        r_t = int(self.tab[target, 2 * n])
        r_s = int(self.tab[source, 2 * n])
        phase_sum = 2 * r_t + 2 * r_s
        for j in range(n):
            phase_sum += self._g(
                self.tab[source, j], self.tab[source, j + n],
                self.tab[target, j], self.tab[target, j + n]
            )
        # r_new
        if phase_sum % 4 == 0:
            self.tab[target, 2 * n] = 0
        elif phase_sum % 4 == 2:
            self.tab[target, 2 * n] = 1
        # x and z bits
        self.tab[target, :n] ^= self.tab[source, :n]
        self.tab[target, n:2*n] ^= self.tab[source, n:2*n]

    def _rowsum_scratch(self, row: np.ndarray, source: np.ndarray) -> np.ndarray:
        """Rowsum into a scratch row (for deterministic measurement)."""
        n = self.n
        r_t = int(row[2 * n])
        r_s = int(source[2 * n])
        phase_sum = 2 * r_t + 2 * r_s
        for j in range(n):
            phase_sum += self._g(
                source[j], source[j + n],
                row[j], row[j + n]
            )
        result = row.copy()
        if phase_sum % 4 == 0:
            result[2 * n] = 0
        elif phase_sum % 4 == 2:
            result[2 * n] = 1
        result[:n] ^= source[:n]
        result[n:2*n] ^= source[n:2*n]
        return result

    def __repr__(self):
        lines = [f"StabilizerTableau ({self.n} qubits)"]
        lines.append("  Stabilizers:")
        for i in range(self.n, 2 * self.n):
            lines.append("    " + self._row_str(i))
        return "\n".join(lines)

    def _row_str(self, i: int) -> str:
        n = self.n
        r = self.tab[i, 2 * n]
        s = "-" if r else "+"
        pauli = ""
        for j in range(n):
            x = self.tab[i, j]
            z = self.tab[i, j + n]
            if x == 0 and z == 0:
                pauli += "I"
            elif x == 1 and z == 0:
                pauli += "X"
            elif x == 0 and z == 1:
                pauli += "Z"
            else:
                pauli += "Y"
        return s + pauli


# ─── CliffordCircuit ──────────────────────────────────────────────────────────

class CliffordCircuit:
    """
    Quantum circuit using the Clifford stabilizer simulator.
    Handles 100+ qubits efficiently.

    Supported gates: H, X, Y, Z, S, Sdg, CNOT/CX, CZ, CY, SWAP
    NOT supported: T, Tdg, Rx, Ry, Rz, Toffoli (non-Clifford)

    Example
    -------
    >>> from cirqit.clifford import CliffordCircuit
    >>> qc = CliffordCircuit(100)
    >>> qc.h(0)
    >>> for i in range(99):
    ...     qc.cnot(i, i+1)
    >>> qc.measure_all()
    >>> result = qc.run(shots=1024)
    >>> print(result)
    """

    CLIFFORD_GATES = {'h', 'x', 'y', 'z', 's', 'sdg', 'cnot', 'cx', 'cz', 'cy', 'swap', 'measure', 'barrier'}

    def __init__(self, n_qubits: int, name: str = "clifford_circuit"):
        assert n_qubits >= 1
        self.n_qubits = n_qubits
        self.name = name
        self._ops = []
        self._measured_qubits = []

    # ─── Gates ────────────────────────────────────────────────────────────────

    def h(self, qubit):
        self._ops.append({'name': 'h', 'qubits': [qubit]})
        return self

    def x(self, qubit):
        self._ops.append({'name': 'x', 'qubits': [qubit]})
        return self

    def y(self, qubit):
        self._ops.append({'name': 'y', 'qubits': [qubit]})
        return self

    def z(self, qubit):
        self._ops.append({'name': 'z', 'qubits': [qubit]})
        return self

    def s(self, qubit):
        self._ops.append({'name': 's', 'qubits': [qubit]})
        return self

    def sdg(self, qubit):
        self._ops.append({'name': 'sdg', 'qubits': [qubit]})
        return self

    def cnot(self, control, target):
        self._ops.append({'name': 'cnot', 'qubits': [control, target]})
        return self

    def cx(self, control, target):
        return self.cnot(control, target)

    def cz(self, q0, q1):
        self._ops.append({'name': 'cz', 'qubits': [q0, q1]})
        return self

    def cy(self, control, target):
        self._ops.append({'name': 'cy', 'qubits': [control, target]})
        return self

    def swap(self, q0, q1):
        self._ops.append({'name': 'swap', 'qubits': [q0, q1]})
        return self

    def barrier(self, *qubits):
        return self

    def measure(self, qubit):
        if qubit not in self._measured_qubits:
            self._measured_qubits.append(qubit)
        self._ops.append({'name': 'measure', 'qubits': [qubit]})
        return self

    def measure_all(self):
        for q in range(self.n_qubits):
            self.measure(q)
        return self

    # ─── Run ──────────────────────────────────────────────────────────────────

    def _build_tableau(self) -> StabilizerTableau:
        tab = StabilizerTableau(self.n_qubits)
        gate_map = {
            'h': tab.h, 'x': tab.x, 'y': tab.y, 'z': tab.z,
            's': tab.s, 'sdg': tab.sdg,
            'cnot': tab.cnot, 'cx': tab.cnot,
            'cz': tab.cz, 'cy': tab.cy, 'swap': tab.swap,
        }
        for op in self._ops:
            name = op['name']
            if name in ('measure', 'barrier'):
                continue
            fn = gate_map.get(name)
            if fn is None:
                raise ValueError(f"Gate '{name}' is not a Clifford gate. "
                                 f"Supported: {sorted(self.CLIFFORD_GATES)}")
            fn(*op['qubits'])
        return tab

    def run(self, shots: int = 1024, seed: int = None) -> dict:
        """Execute circuit and return measurement counts."""
        if seed is not None:
            np.random.seed(seed)
        if not self._measured_qubits:
            return {}

        base_tab = self._build_tableau()
        measured = sorted(self._measured_qubits)
        # Fast batch measurement using array copy instead of deepcopy
        orig_data = base_tab.tab.copy()
        counts = {}
        for _ in range(shots):
            base_tab.tab = orig_data.copy()
            bits = ''.join(str(base_tab.measure(q)) for q in measured)
            counts[bits] = counts.get(bits, 0) + 1
        return dict(sorted(counts.items()))

    def stabilizers(self) -> list:
        """Return stabilizer generators as strings."""
        tab = self._build_tableau()
        return [tab._row_str(i) for i in range(self.n_qubits, 2 * self.n_qubits)]

    def draw(self):
        """ASCII circuit drawing."""
        print(f"\n{'='*55}")
        print(f"  CirQit Clifford — {self.name} ({self.n_qubits} qubits)")
        print(f"{'='*55}")
        gate_ops = [op for op in self._ops if op['name'] not in ('measure', 'barrier')]
        # Show first 20 qubits max in ASCII
        show_n = min(self.n_qubits, 20)
        lines = [f"q{i:>3}: ─" for i in range(show_n)]
        for op in gate_ops:
            name = op['name'].upper()
            qubits = op['qubits']
            if len(qubits) == 1:
                q = qubits[0]
                if q < show_n:
                    label = f"[{name}]─"
                    pad = len(label)
                    for i in range(show_n):
                        if i == q:
                            lines[i] += label
                        else:
                            lines[i] += "─" * pad
            elif len(qubits) == 2:
                ctrl, tgt = qubits
                label_c = f"[●]─"
                label_t = f"[{name}]─"
                pad = max(len(label_c), len(label_t))
                for i in range(show_n):
                    if i == ctrl:
                        lines[i] += label_c.ljust(pad, '─')
                    elif i == tgt:
                        lines[i] += label_t.ljust(pad, '─')
                    else:
                        lines[i] += "─" * pad
        for q in self._measured_qubits:
            if q < show_n:
                lines[q] += "[M]─"
        for line in lines:
            print("  " + line)
        if self.n_qubits > 20:
            print(f"  ... ({self.n_qubits - 20} more qubits not shown)")
        print(f"{'='*55}\n")

    def depth(self) -> int:
        return len([op for op in self._ops if op['name'] != 'barrier'])

    def count_ops(self) -> dict:
        counts = {}
        for op in self._ops:
            counts[op['name']] = counts.get(op['name'], 0) + 1
        return counts

    def __repr__(self):
        return (f"CliffordCircuit('{self.name}', n_qubits={self.n_qubits}, "
                f"depth={self.depth()}, ops={self.count_ops()})")

    def run_async(self, shots: int = 1024, seed: int = None):
        """Run as background job with unique Job ID."""
        from .job import CirQitJob, JobRegistry
        import copy
        circ_copy = copy.deepcopy(self)
        job = CirQitJob(
            circuit=circ_copy,
            shots=shots,
            seed=seed,
            backend="clifford-stabilizer"
        )
        JobRegistry.register(job)
        return job


# ─── Convenience: large-scale presets ────────────────────────────────────────

def ghz_clifford(n: int) -> CliffordCircuit:
    """n-qubit GHZ state using Clifford gates."""
    qc = CliffordCircuit(n, name=f'ghz_{n}')
    qc.h(0)
    for i in range(n - 1):
        qc.cnot(i, i + 1)
    return qc


def qec_steane() -> CliffordCircuit:
    """Steane [[7,1,3]] quantum error correction encoding."""
    qc = CliffordCircuit(7, name='steane_7_1_3')
    # Encode logical |0>
    qc.h(0); qc.h(1); qc.h(3)
    qc.cnot(0, 6); qc.cnot(1, 5); qc.cnot(3, 5)
    qc.cnot(0, 4); qc.cnot(1, 4); qc.cnot(3, 6)
    qc.cnot(0, 2); qc.cnot(1, 2); qc.cnot(3, 2)
    return qc


def surface_code_patch(d: int) -> CliffordCircuit:
    """
    Simplified surface code patch — d*d qubits.
    Just stabilizer measurements (X and Z checks).
    """
    n = d * d
    qc = CliffordCircuit(n, name=f'surface_code_d{d}')
    # X stabilizers
    for row in range(d - 1):
        for col in range(d):
            q = row * d + col
            qc.h(q)
            if col > 0:
                qc.cnot(q, q - 1)
            if col < d - 1:
                qc.cnot(q, q + 1)
            qc.h(q)
    return qc


def random_clifford(n: int, depth: int, seed: int = None) -> CliffordCircuit:
    """Random Clifford circuit."""
    if seed is not None:
        np.random.seed(seed)
    qc = CliffordCircuit(n, name='random_clifford')
    single = ['h', 'x', 'y', 'z', 's', 'sdg']
    two = ['cnot', 'cz', 'swap']
    for _ in range(depth):
        for q in range(n):
            if np.random.random() < 0.6:
                gate = np.random.choice(single)
                getattr(qc, gate)(q)
            elif n > 1 and np.random.random() < 0.4:
                tgt = (q + 1) % n
                gate = np.random.choice(two)
                getattr(qc, gate)(q, tgt)
    return qc


# ─── Fast batch measurement (optimized for large qubits) ──────────────────────

def _fast_measure_all(tab_orig: StabilizerTableau, shots: int, measured_qubits: list) -> dict:
    """
    Optimized batch measurement: avoids full deepcopy per shot.
    Saves tableau state as numpy array and restores it.
    """
    import copy
    n = tab_orig.n
    # Save original tableau as bytes for fast restore
    orig_data = tab_orig.tab.copy()
    counts = {}
    for _ in range(shots):
        tab_orig.tab = orig_data.copy()
        bits = ''.join(str(tab_orig.measure(q)) for q in measured_qubits)
        counts[bits] = counts.get(bits, 0) + 1
    # Restore
    tab_orig.tab = orig_data
    return dict(sorted(counts.items()))

