"""
cirqit.visualize - Circuit visualization (ASCII + matplotlib)
"""

import numpy as np


def draw_ascii(operations, n_qubits, measured_qubits):
    """Draw circuit as ASCII art."""
    lines = [f"q{i}: ─" for i in range(n_qubits)]
    
    for op in operations:
        name = op['name'].upper()
        qubits = op['qubits']
        params = op.get('params', [])

        if len(qubits) == 1:
            q = qubits[0]
            if params:
                label = f"[{name}({', '.join(f'{p:.2f}' for p in params)})]─"
            else:
                label = f"[{name}]─"
            pad_len = len(label)
            for i in range(n_qubits):
                if i == q:
                    lines[i] += label
                else:
                    lines[i] += "─" * pad_len

        elif len(qubits) == 2:
            ctrl, tgt = qubits
            label_ctrl = f"[●]─"
            label_tgt  = f"[{name}]─"
            pad = max(len(label_ctrl), len(label_tgt))
            label_ctrl = label_ctrl.ljust(pad, "─")
            label_tgt  = label_tgt.ljust(pad, "─")
            wire = "─│─".ljust(pad, "─")

            for i in range(n_qubits):
                if i == ctrl:
                    lines[i] += label_ctrl
                elif i == tgt:
                    lines[i] += label_tgt
                else:
                    # vertical wire if between ctrl and tgt
                    mn, mx = min(ctrl, tgt), max(ctrl, tgt)
                    if mn < i < mx:
                        lines[i] += wire
                    else:
                        lines[i] += "─" * pad

        elif len(qubits) == 3:
            q0, q1, q2 = qubits
            label = f"[{name}]─"
            pad = len(label)
            for i in range(n_qubits):
                if i in qubits:
                    lines[i] += label
                else:
                    lines[i] += "─" * pad

    # Measurement markers
    for q in measured_qubits:
        lines[q] += "[M]─"

    print("\n" + "=" * 60)
    print("  CIRQIT — Quantum Circuit")
    print("=" * 60)
    for line in lines:
        print("  " + line)
    print("=" * 60 + "\n")


def draw_matplotlib(operations, n_qubits, measured_qubits, figsize=None):
    """Draw circuit using matplotlib."""
    try:
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches
        from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    except ImportError:
        raise ImportError("matplotlib required: pip install matplotlib")

    # Color scheme
    COLORS = {
        'H': '#4A90E2', 'X': '#E24A4A', 'Y': '#E28A4A',
        'Z': '#4AE28A', 'S': '#9B4AE2', 'T': '#E2C44A',
        'RX': '#4AB8E2', 'RY': '#E24AB8', 'RZ': '#B8E24A',
        'CNOT': '#E24A4A', 'CX': '#E24A4A', 'CZ': '#4AE28A',
        'SWAP': '#E2A04A', 'CCX': '#8A4AE2', 'TOFFOLI': '#8A4AE2',
        'MEASURE': '#2A2A2A', 'DEFAULT': '#7A7A7A'
    }

    col_width = 1.2
    row_height = 1.0
    box_w, box_h = 0.8, 0.5

    n_cols = len(operations) + 1
    if figsize is None:
        figsize = (max(8, n_cols * col_width + 2), max(3, n_qubits * row_height + 1.5))

    fig, ax = plt.subplots(figsize=figsize, facecolor='#0D0D1A')
    ax.set_facecolor('#0D0D1A')
    ax.set_xlim(-0.5, n_cols * col_width + 0.5)
    ax.set_ylim(-0.5, n_qubits * row_height + 0.5)
    ax.axis('off')

    # Title
    ax.text(n_cols * col_width / 2, n_qubits * row_height + 0.2,
            'CIRQIT — Quantum Circuit',
            ha='center', va='bottom', color='#88AAFF',
            fontsize=12, fontweight='bold', fontfamily='monospace')

    # Qubit wires
    for q in range(n_qubits):
        y = (n_qubits - 1 - q) * row_height
        ax.axhline(y=y, xmin=0.02, xmax=0.98, color='#334466', lw=1.2, zorder=1)
        ax.text(-0.3, y, f'q{q}', ha='right', va='center',
                color='#88CCFF', fontsize=9, fontfamily='monospace')

    # Draw gates
    for col_idx, op in enumerate(operations):
        name = op['name'].upper()
        qubits = op['qubits']
        params = op.get('params', [])
        x = (col_idx + 1) * col_width
        color = COLORS.get(name, COLORS['DEFAULT'])

        if len(qubits) == 1:
            q = qubits[0]
            y = (n_qubits - 1 - q) * row_height
            label = name
            if params:
                label += f"\n{', '.join(f'{p:.2f}' for p in params)}"
            box = FancyBboxPatch((x - box_w/2, y - box_h/2), box_w, box_h,
                                  boxstyle="round,pad=0.05",
                                  facecolor=color, edgecolor='white',
                                  linewidth=1, zorder=3, alpha=0.9)
            ax.add_patch(box)
            ax.text(x, y, label, ha='center', va='center',
                    color='white', fontsize=7.5, fontweight='bold',
                    fontfamily='monospace', zorder=4)

        elif len(qubits) == 2:
            ctrl, tgt = qubits
            yc = (n_qubits - 1 - ctrl) * row_height
            yt = (n_qubits - 1 - tgt) * row_height
            # Control dot
            ax.plot(x, yc, 'o', color=color, markersize=10, zorder=4)
            # Vertical line
            ax.plot([x, x], [yc, yt], color=color, lw=2, zorder=2)
            # Target box
            box = FancyBboxPatch((x - box_w/2, yt - box_h/2), box_w, box_h,
                                  boxstyle="round,pad=0.05",
                                  facecolor=color, edgecolor='white',
                                  linewidth=1, zorder=3, alpha=0.9)
            ax.add_patch(box)
            ax.text(x, yt, name, ha='center', va='center',
                    color='white', fontsize=7.5, fontweight='bold',
                    fontfamily='monospace', zorder=4)

        elif len(qubits) == 3:
            q0, q1, q2 = qubits
            ys = [(n_qubits - 1 - q) * row_height for q in [q0, q1, q2]]
            ax.plot([x, x], [min(ys), max(ys)], color=color, lw=2, zorder=2)
            for qi, y in zip([q0, q1, q2], ys):
                if qi == q2:
                    box = FancyBboxPatch((x - box_w/2, y - box_h/2), box_w, box_h,
                                          boxstyle="round,pad=0.05",
                                          facecolor=color, edgecolor='white',
                                          linewidth=1, zorder=3, alpha=0.9)
                    ax.add_patch(box)
                    ax.text(x, y, name, ha='center', va='center',
                            color='white', fontsize=7, fontweight='bold',
                            fontfamily='monospace', zorder=4)
                else:
                    ax.plot(x, y, 'o', color=color, markersize=8, zorder=4)

    # Measurement symbols
    m_x = (len(operations) + 1) * col_width
    for q in measured_qubits:
        y = (n_qubits - 1 - q) * row_height
        box = FancyBboxPatch((m_x - box_w/2, y - box_h/2), box_w, box_h,
                              boxstyle="round,pad=0.05",
                              facecolor='#1A1A2E', edgecolor='#FFCC44',
                              linewidth=1.5, zorder=3)
        ax.add_patch(box)
        ax.text(m_x, y, 'M', ha='center', va='center',
                color='#FFCC44', fontsize=9, fontweight='bold',
                fontfamily='monospace', zorder=4)

    plt.tight_layout()
    return fig


def plot_histogram(counts: dict, title: str = "Measurement Results", figsize=(10, 5)):
    """Plot measurement outcome histogram."""
    try:
        import matplotlib.pyplot as plt
        import matplotlib.cm as cm
    except ImportError:
        raise ImportError("matplotlib required: pip install matplotlib")

    states = list(counts.keys())
    values = list(counts.values())
    total = sum(values)
    probs = [v / total for v in values]

    colors = cm.plasma(np.linspace(0.2, 0.9, len(states)))

    fig, axes = plt.subplots(1, 2, figsize=figsize, facecolor='#0D0D1A')

    # Counts bar
    ax1 = axes[0]
    ax1.set_facecolor('#0D0D1A')
    bars = ax1.bar(states, values, color=colors, edgecolor='white', linewidth=0.5)
    ax1.set_xlabel('Basis State', color='#88CCFF', fontsize=10)
    ax1.set_ylabel('Counts', color='#88CCFF', fontsize=10)
    ax1.set_title('Counts', color='#88AAFF', fontsize=11, fontweight='bold')
    ax1.tick_params(colors='#88CCFF', rotation=45)
    for spine in ax1.spines.values():
        spine.set_edgecolor('#334466')
    for bar, v in zip(bars, values):
        ax1.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.5,
                 str(v), ha='center', va='bottom', color='white', fontsize=8)

    # Probability bar
    ax2 = axes[1]
    ax2.set_facecolor('#0D0D1A')
    bars2 = ax2.bar(states, probs, color=colors, edgecolor='white', linewidth=0.5)
    ax2.set_xlabel('Basis State', color='#88CCFF', fontsize=10)
    ax2.set_ylabel('Probability', color='#88CCFF', fontsize=10)
    ax2.set_title('Probabilities', color='#88AAFF', fontsize=11, fontweight='bold')
    ax2.tick_params(colors='#88CCFF', rotation=45)
    for spine in ax2.spines.values():
        spine.set_edgecolor('#334466')
    for bar, p in zip(bars2, probs):
        ax2.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.002,
                 f'{p:.3f}', ha='center', va='bottom', color='white', fontsize=8)

    fig.suptitle(title, color='#88AAFF', fontsize=13, fontweight='bold', y=1.01)
    plt.tight_layout()
    return fig


def plot_bloch_sphere(bx: float, by: float, bz: float, qubit: int = 0):
    """Plot Bloch sphere for a single qubit state."""
    try:
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D
    except ImportError:
        raise ImportError("matplotlib required: pip install matplotlib")

    fig = plt.figure(figsize=(6, 6), facecolor='#0D0D1A')
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor('#0D0D1A')

    # Sphere
    u, v = np.mgrid[0:2*np.pi:40j, 0:np.pi:20j]
    xs = np.cos(u) * np.sin(v)
    ys = np.sin(u) * np.sin(v)
    zs = np.cos(v)
    ax.plot_wireframe(xs, ys, zs, color='#334466', alpha=0.3, linewidth=0.5)

    # Axes
    for axis, label in [([1,0,0], '|+⟩'), ([-1,0,0], '|−⟩'),
                         ([0,1,0], '|i+⟩'), ([0,-1,0], '|i−⟩'),
                         ([0,0,1], '|0⟩'), ([0,0,-1], '|1⟩')]:
        ax.plot([0, axis[0]], [0, axis[1]], [0, axis[2]], 'gray', lw=0.8, alpha=0.5)
        ax.text(axis[0]*1.15, axis[1]*1.15, axis[2]*1.15, label,
                color='#88CCFF', fontsize=8, ha='center')

    # Bloch vector
    ax.quiver(0, 0, 0, bx, by, bz, color='#FF6644', linewidth=2.5,
              arrow_length_ratio=0.15)
    ax.scatter([bx], [by], [bz], color='#FF6644', s=60, zorder=5)

    ax.set_title(f'Bloch Sphere — q{qubit}', color='#88AAFF',
                 fontsize=11, fontweight='bold')
    ax.set_xlim([-1.2, 1.2]); ax.set_ylim([-1.2, 1.2]); ax.set_zlim([-1.2, 1.2])
    ax.tick_params(colors='#334466')
    plt.tight_layout()
    return fig
