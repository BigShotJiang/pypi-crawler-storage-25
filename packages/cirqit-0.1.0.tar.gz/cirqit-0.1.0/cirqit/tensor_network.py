"""
cirqit.tensor_network - Matrix Product State (MPS) simulator
=============================================================
Handles 50-500 qubits for low-entanglement circuits.
Uses SVD-based truncation to keep bond dimension manageable.

Supported: all single-qubit gates, CNOT, CZ, SWAP (adjacent + non-adjacent)
Bond dimension chi controls accuracy vs speed tradeoff.

Usage
-----
>>> from cirqit.tensor_network import MPSSimulator
>>> mps = MPSSimulator(100, chi=32)
>>> mps.h(0)
>>> for i in range(99):
...     mps.cnot(i, i+1)
>>> print(mps.measure_all(shots=512))
"""

import numpy as np


class MPSSimulator:
    """
    Matrix Product State simulator.

    Parameters
    ----------
    n_qubits : int
        Number of qubits (supports 2 to 500+)
    chi : int
        Maximum bond dimension. Higher = more accurate but slower.
        chi=16: fast, low entanglement
        chi=32: balanced (default)
        chi=64: high accuracy
        chi=128: near-exact for most circuits
    """

    def __init__(self, n_qubits: int, chi: int = 32):
        assert n_qubits >= 2
        self.n = n_qubits
        self.chi = chi
        self._init_mps()
        self._ops = []

    def _init_mps(self):
        """Initialize MPS for |00...0> state."""
        self.tensors = []
        for i in range(self.n):
            if i == 0:
                # Shape: (1, 2, chi_r) but starts as (1, 2, 1)
                t = np.zeros((1, 2, 1), dtype=complex)
                t[0, 0, 0] = 1.0
            elif i == self.n - 1:
                t = np.zeros((1, 2, 1), dtype=complex)
                t[0, 0, 0] = 1.0
            else:
                t = np.zeros((1, 2, 1), dtype=complex)
                t[0, 0, 0] = 1.0
            self.tensors.append(t)
        self.singular_values = [np.array([1.0])] * (self.n - 1)

    def reset(self):
        self._init_mps()

    # ─── Single-qubit gates ───────────────────────────────────────────────────

    def _apply_single(self, gate: np.ndarray, qubit: int):
        """Apply 2x2 gate to single qubit tensor."""
        t = self.tensors[qubit]  # shape (chi_l, 2, chi_r)
        # Contract gate with physical index
        # t_new[a, s', b] = sum_s gate[s', s] * t[a, s, b]
        t_new = np.einsum('sp,apb->asb', gate, t)
        self.tensors[qubit] = t_new

    def h(self, q):
        from .gates import H
        self._apply_single(H(), q)
        return self

    def x(self, q):
        from .gates import X
        self._apply_single(X(), q)
        return self

    def y(self, q):
        from .gates import Y
        self._apply_single(Y(), q)
        return self

    def z(self, q):
        from .gates import Z
        self._apply_single(Z(), q)
        return self

    def s(self, q):
        from .gates import S
        self._apply_single(S(), q)
        return self

    def t(self, q):
        from .gates import T
        self._apply_single(T(), q)
        return self

    def sdg(self, q):
        from .gates import Sdg
        self._apply_single(Sdg(), q)
        return self

    def tdg(self, q):
        from .gates import Tdg
        self._apply_single(Tdg(), q)
        return self

    def rx(self, theta, q):
        from .gates import RX
        self._apply_single(RX(theta), q)
        return self

    def ry(self, theta, q):
        from .gates import RY
        self._apply_single(RY(theta), q)
        return self

    def rz(self, theta, q):
        from .gates import RZ
        self._apply_single(RZ(theta), q)
        return self

    def p(self, phi, q):
        from .gates import P
        self._apply_single(P(phi), q)
        return self

    def u(self, theta, phi, lam, q):
        from .gates import U
        self._apply_single(U(theta, phi, lam), q)
        return self

    def sx(self, q):
        from .gates import SX
        self._apply_single(SX(), q)
        return self

    # ─── Two-qubit gates ──────────────────────────────────────────────────────

    def _apply_two_adjacent(self, gate: np.ndarray, q0: int, q1: int):
        """Apply 4x4 gate to adjacent qubits using SVD."""
        assert abs(q0 - q1) == 1
        left, right = min(q0, q1), max(q0, q1)

        tL = self.tensors[left]   # (chi_l, 2, chi_m)
        tR = self.tensors[right]  # (chi_m, 2, chi_r)

        chi_l = tL.shape[0]
        chi_m = tL.shape[2]
        chi_r = tR.shape[2]

        # Merge: theta[chi_l, 2, 2, chi_r]
        theta = np.einsum('apb,bqc->apqc', tL, tR)

        # Reshape for gate application
        theta_mat = theta.reshape(chi_l * 2, 2 * chi_r)

        # Apply gate (reshape gate to act on physical indices)
        g = gate.reshape(2, 2, 2, 2)  # (s0', s1', s0, s1)

        # Full contraction: theta[a,p,q,c] gate[r,s,p,q] -> result[a,r,s,c]
        theta_4d = theta.reshape(chi_l, 2, 2, chi_r)
        if q0 > q1:
            g = g.transpose(1, 0, 3, 2)

        theta_new = np.einsum('apqc,rspq->arsc', theta_4d, g)
        # theta_new: (chi_l, 2, 2, chi_r)

        # SVD truncation
        theta_mat = theta_new.reshape(chi_l * 2, 2 * chi_r)
        U, S, Vh = np.linalg.svd(theta_mat, full_matrices=False)

        # Truncate to chi
        chi_new = min(len(S), self.chi)
        U = U[:, :chi_new]
        S = S[:chi_new]
        Vh = Vh[:chi_new, :]

        self.singular_values[left] = S

        # Reshape back
        self.tensors[left]  = U.reshape(chi_l, 2, chi_new)
        self.tensors[right] = (np.diag(S) @ Vh).reshape(chi_new, 2, chi_r)

    def _apply_two_nonadjacent(self, gate: np.ndarray, q0: int, q1: int):
        """Apply gate to non-adjacent qubits via SWAP network."""
        left, right = min(q0, q1), max(q0, q1)
        from .gates import SWAP
        # Swap left qubit next to right qubit
        for i in range(left, right - 1):
            self._apply_two_adjacent(SWAP(), i, i + 1)
        # Apply gate to (right-1, right)
        self._apply_two_adjacent(gate, right - 1, right)
        # Swap back
        for i in range(right - 2, left - 1, -1):
            self._apply_two_adjacent(SWAP(), i, i + 1)

    def cnot(self, ctrl, tgt):
        from .gates import CNOT
        if abs(ctrl - tgt) == 1:
            self._apply_two_adjacent(CNOT(), ctrl, tgt)
        else:
            self._apply_two_nonadjacent(CNOT(), ctrl, tgt)
        return self

    def cx(self, ctrl, tgt):
        return self.cnot(ctrl, tgt)

    def cz(self, q0, q1):
        from .gates import CZ
        if abs(q0 - q1) == 1:
            self._apply_two_adjacent(CZ(), q0, q1)
        else:
            self._apply_two_nonadjacent(CZ(), q0, q1)
        return self

    def swap(self, q0, q1):
        from .gates import SWAP
        if abs(q0 - q1) == 1:
            self._apply_two_adjacent(SWAP(), q0, q1)
        else:
            self._apply_two_nonadjacent(SWAP(), q0, q1)
        return self

    def crz(self, theta, ctrl, tgt):
        from .gates import CRZ
        if abs(ctrl - tgt) == 1:
            self._apply_two_adjacent(CRZ(theta), ctrl, tgt)
        else:
            self._apply_two_nonadjacent(CRZ(theta), ctrl, tgt)
        return self

    def cp(self, phi, ctrl, tgt):
        from .gates import CP
        if abs(ctrl - tgt) == 1:
            self._apply_two_adjacent(CP(phi), ctrl, tgt)
        else:
            self._apply_two_nonadjacent(CP(phi), ctrl, tgt)
        return self

    # ─── Measurement ──────────────────────────────────────────────────────────

    def _contract_all(self) -> np.ndarray:
        """Contract entire MPS to full statevector (only for small n)."""
        result = self.tensors[0]  # (1, 2, chi)
        result = result[0]        # (2, chi)
        for i in range(1, self.n):
            t = self.tensors[i]   # (chi, 2, chi)
            result = np.einsum('ac,cbd->abd', result, t)
            # result: (2^i, 2, chi)
            result = result.reshape(-1, result.shape[-1])
        result = result[:, 0]  # (2^n,)
        return result

    def _measure_qubit_mps(self, qubit: int) -> tuple:
        """Measure single qubit by contracting with left/right environments."""
        # Build left environment
        env_l = np.ones((1, 1), dtype=complex)
        for i in range(qubit):
            t = self.tensors[i]  # (chi_l, 2, chi_r)
            # Contract: env[a,b] t[b,s,c] t*[a,s,d] -> env[c,d]
            env_l = np.einsum('ab,bsc,asd->cd', env_l, t, t.conj())

        # Build right environment
        env_r = np.ones((1, 1), dtype=complex)
        for i in range(self.n - 1, qubit, -1):
            t = self.tensors[i]  # (chi_l, 2, chi_r)
            env_r = np.einsum('ab,cab,dab->cd', env_r, t, t.conj())

        t = self.tensors[qubit]  # (chi_l, 2, chi_r)
        # prob[s] = sum_{a,b,c,d} env_l[a,c] t[a,s,b] t*[c,s,d] env_r[b,d]
        prob = np.zeros(2)
        for s in range(2):
            ts = t[:, s, :]  # (chi_l, chi_r)
            prob[s] = float(np.real(np.einsum('ac,ab,cd,bd->', env_l, ts, ts.conj(), env_r)))

        total = prob.sum()
        if total < 1e-12:
            return 0, 0.5
        prob /= total

        outcome = np.random.choice([0, 1], p=prob)

        # Project and renormalize this tensor
        t_proj = t[:, outcome:outcome+1, :].copy()
        norm = np.sqrt(max(prob[outcome] * total, 1e-12))
        t_proj /= np.sqrt(prob[outcome]) if prob[outcome] > 1e-12 else 1.0
        self.tensors[qubit] = t_proj

        return outcome, prob[outcome]

    def sample(self) -> str:
        """Draw one sample via Born-rule sampling on each qubit sequentially."""
        import copy
        # Deep copy state before sampling
        tensors_backup = [t.copy() for t in self.tensors]
        sv_backup = [s.copy() for s in self.singular_values]

        bits = ''
        for q in range(self.n):
            outcome, _ = self._measure_qubit_mps(q)
            bits += str(outcome)

        # Restore state
        self.tensors = [t.copy() for t in tensors_backup]
        self.singular_values = [s.copy() for s in sv_backup]
        return bits

    def measure_all(self, shots: int = 1024) -> dict:
        """Sample from MPS distribution."""
        counts = {}
        for _ in range(shots):
            bits = self.sample()
            counts[bits] = counts.get(bits, 0) + 1
        return dict(sorted(counts.items()))

    def entanglement_entropy(self, bond: int) -> float:
        """Von Neumann entanglement entropy at bond between qubit bond and bond+1."""
        S = self.singular_values[bond]
        S_norm = S / np.linalg.norm(S)
        probs = S_norm ** 2
        probs = probs[probs > 1e-12]
        return float(-np.sum(probs * np.log2(probs)))

    def max_bond_dim(self) -> int:
        """Current maximum bond dimension."""
        return max(t.shape[0] for t in self.tensors)

    def __repr__(self):
        return (f"MPSSimulator({self.n} qubits, chi={self.chi}, "
                f"max_bond={self.max_bond_dim()})")
