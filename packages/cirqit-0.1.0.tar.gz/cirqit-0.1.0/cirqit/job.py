"""
cirqit.job - Job system for circuit execution
==============================================

Gives every circuit run a unique Job ID with status tracking.

Usage
-----
>>> job = qc.run_async(shots=1024)
>>> print(job.job_id)       # CRQ-20260403-a3f9b2c1
>>> print(job.status)       # QUEUED / RUNNING / DONE / ERROR
>>> print(job.result())     # {'00': 512, '11': 512}
>>> print(job.runtime)      # 0.023s
>>> job.summary()           # full printout
"""

import uuid
import time
import threading
from datetime import datetime
from enum import Enum


class JobStatus(Enum):
    QUEUED  = "QUEUED"
    RUNNING = "RUNNING"
    DONE    = "DONE"
    ERROR   = "ERROR"


class CirQitJob:
    """
    Represents a single circuit execution job.
    Runs in background thread, tracks status and timing.
    """

    def __init__(self, circuit, shots: int, seed=None, backend: str = "statevector", noise_model=None):
        # Job identity
        date_str = datetime.now().strftime("%Y%m%d")
        short_id = uuid.uuid4().hex[:8]
        self.job_id = f"CRQ-{date_str}-{short_id}"

        # Metadata
        self.circuit_name = getattr(circuit, 'name', 'circuit')
        self.n_qubits     = circuit.n_qubits
        self.shots        = shots
        self.seed         = seed
        self.backend      = backend
        self.submitted_at = datetime.now()

        # State
        self._status   = JobStatus.QUEUED
        self._result   = None
        self._error    = None
        self._start_t  = None
        self._end_t    = None
        self._circuit  = circuit
        self._nm       = noise_model

        # Print job submission info
        self._print_submitted()

        # Run in background thread
        self._thread = threading.Thread(target=self._execute, daemon=True)
        self._thread.start()

    # ─── Execution ────────────────────────────────────────────────────────────

    def _execute(self):
        self._status  = JobStatus.RUNNING
        self._start_t = time.perf_counter()
        self._print_running()
        try:
            if self._nm is not None:
                self._circuit.set_noise_model(self._nm)
            result = self._circuit.run(shots=self.shots, seed=self.seed)
            self._result = result
            self._status = JobStatus.DONE
        except Exception as e:
            self._error  = str(e)
            self._status = JobStatus.ERROR
        finally:
            self._end_t = time.perf_counter()
            self._print_done()

    # ─── Public API ───────────────────────────────────────────────────────────

    @property
    def status(self) -> str:
        return self._status.value

    @property
    def runtime(self) -> str:
        if self._start_t is None:
            return "—"
        end = self._end_t if self._end_t else time.perf_counter()
        elapsed = end - self._start_t
        if elapsed < 1:
            return f"{elapsed*1000:.1f}ms"
        return f"{elapsed:.3f}s"

    def result(self, timeout: float = 60.0) -> dict:
        """Block until job completes, then return counts dict."""
        self._thread.join(timeout=timeout)
        if self._status == JobStatus.ERROR:
            raise RuntimeError(f"Job {self.job_id} failed: {self._error}")
        if self._status != JobStatus.DONE:
            raise TimeoutError(f"Job {self.job_id} did not complete within {timeout}s")
        return self._result

    def wait(self, timeout: float = 60.0):
        """Block until done."""
        self._thread.join(timeout=timeout)
        return self

    def cancel(self):
        """Cancel is not supported for synchronous backends."""
        print(f"  ⚠ Job {self.job_id} — cancel not supported on local backends")

    def summary(self):
        """Print full job summary."""
        w = 58
        sep = "─" * w
        print(f"\n┌{sep}┐")
        print(f"│  {'CIRQIT JOB SUMMARY':<{w-2}}│")
        print(f"├{sep}┤")
        print(f"│  Job ID       : {self.job_id:<{w-17}}│")
        print(f"│  Circuit      : {self.circuit_name:<{w-17}}│")
        print(f"│  Qubits       : {self.n_qubits:<{w-17}}│")
        print(f"│  Shots        : {self.shots:<{w-17}}│")
        print(f"│  Backend      : {self.backend:<{w-17}}│")
        print(f"│  Submitted    : {self.submitted_at.strftime('%Y-%m-%d %H:%M:%S'):<{w-17}}│")
        print(f"│  Status       : {self.status:<{w-17}}│")
        print(f"│  Runtime      : {self.runtime:<{w-17}}│")
        if self._result:
            top = sorted(self._result.items(), key=lambda x: -x[1])[:5]
            top_str = "  ".join(f"|{k}⟩:{v}" for k,v in top)
            print(f"├{sep}┤")
            print(f"│  Top outcomes : {top_str[:w-17]:<{w-17}}│")
        if self._error:
            print(f"│  Error        : {str(self._error)[:w-17]:<{w-17}}│")
        print(f"└{sep}┘\n")

    # ─── Print helpers ────────────────────────────────────────────────────────

    def _print_submitted(self):
        print(f"\n  ┌─ JOB SUBMITTED ─────────────────────────────┐")
        print(f"  │  ID      : {self.job_id}")
        print(f"  │  Circuit : {self.circuit_name} ({self.n_qubits} qubits, {self.shots} shots)")
        print(f"  │  Backend : {self.backend}")
        print(f"  │  Status  : {JobStatus.QUEUED.value}")
        print(f"  └─────────────────────────────────────────────┘")

    def _print_running(self):
        print(f"  ⟳ [{self.job_id}] Status: RUNNING...")

    def _print_done(self):
        if self._status == JobStatus.DONE:
            print(f"  ✓ [{self.job_id}] Status: DONE  |  Runtime: {self.runtime}")
        else:
            print(f"  ✗ [{self.job_id}] Status: ERROR  |  {self._error}")

    def __repr__(self):
        return f"CirQitJob(id='{self.job_id}', status={self.status}, runtime={self.runtime})"


# ─── Job Registry ─────────────────────────────────────────────────────────────

class JobRegistry:
    """Global registry of all jobs in this session."""
    _jobs: dict = {}

    @classmethod
    def register(cls, job: CirQitJob):
        cls._jobs[job.job_id] = job

    @classmethod
    def get(cls, job_id: str) -> CirQitJob:
        if job_id not in cls._jobs:
            raise KeyError(f"Job '{job_id}' not found in registry")
        return cls._jobs[job_id]

    @classmethod
    def list_jobs(cls):
        """Print all jobs in this session."""
        if not cls._jobs:
            print("  No jobs in this session.")
            return
        print(f"\n  {'JOB ID':<28} {'CIRCUIT':<16} {'STATUS':<10} {'RUNTIME'}")
        print(f"  {'─'*28} {'─'*16} {'─'*10} {'─'*10}")
        for job in cls._jobs.values():
            print(f"  {job.job_id:<28} {job.circuit_name[:15]:<16} {job.status:<10} {job.runtime}")
        print()

    @classmethod
    def clear(cls):
        cls._jobs.clear()


# Global registry instance
_registry = JobRegistry()


def list_jobs():
    """Print all jobs submitted in this session."""
    JobRegistry.list_jobs()


def get_job(job_id: str) -> CirQitJob:
    """Retrieve a job by its ID."""
    return JobRegistry.get(job_id)
