"""
cirqit.qasm - OpenQASM 2.0 import/export
=========================================

Usage
-----
>>> from cirqit.qasm import to_qasm, from_qasm
>>>
>>> # Export
>>> qasm_str = to_qasm(qc)
>>> print(qasm_str)
>>>
>>> # Import
>>> qc2 = from_qasm(qasm_str)
>>> qc2.run(shots=1024)
>>>
>>> # Save/load file
>>> to_qasm_file(qc, 'circuit.qasm')
>>> qc3 = from_qasm_file('circuit.qasm')
"""

import re
from .circuit import QuantumCircuit


# ─── Gate name mapping ────────────────────────────────────────────────────────

GATE_TO_QASM = {
    'h': 'h', 'x': 'x', 'y': 'y', 'z': 'z',
    's': 's', 't': 't', 'sdg': 'sdg', 'tdg': 'tdg',
    'sx': 'sx',
    'rx': 'rx', 'ry': 'ry', 'rz': 'rz',
    'p': 'p', 'u': 'u',
    'cnot': 'cx', 'cx': 'cx',
    'cz': 'cz', 'cy': 'cy',
    'swap': 'swap',
    'crx': 'crx', 'cry': 'cry', 'crz': 'crz',
    'cp': 'cp',
    'ccx': 'ccx', 'toffoli': 'ccx',
    'cswap': 'cswap', 'fredkin': 'cswap',
}

QASM_TO_GATE = {v: k for k, v in GATE_TO_QASM.items()}
QASM_TO_GATE['cx'] = 'cnot'

# Gates with parameters
PARAM_GATES = {'rx', 'ry', 'rz', 'p', 'u', 'crx', 'cry', 'crz', 'cp'}

# Number of qubits per gate
GATE_QUBITS = {
    'h':1,'x':1,'y':1,'z':1,'s':1,'t':1,'sdg':1,'tdg':1,'sx':1,
    'rx':1,'ry':1,'rz':1,'p':1,'u':1,
    'cx':2,'cz':2,'cy':2,'swap':2,'crx':2,'cry':2,'crz':2,'cp':2,
    'ccx':3,'cswap':3,
}


# ─── Export ───────────────────────────────────────────────────────────────────

def to_qasm(circuit: QuantumCircuit) -> str:
    """Convert QuantumCircuit to OpenQASM 2.0 string."""
    n = circuit.n_qubits
    nc = circuit.n_classical

    lines = [
        'OPENQASM 2.0;',
        'include "qelib1.inc";',
        f'qreg q[{n}];',
        f'creg c[{nc}];',
        '',
    ]

    creg_idx = 0
    for op in circuit._ops:
        name = op['name']
        qubits = op['qubits']
        params = op.get('params', [])

        if name == 'barrier':
            qubit_str = ', '.join(f'q[{q}]' for q in qubits)
            lines.append(f'barrier {qubit_str};')
            continue

        if name == 'measure':
            q = qubits[0]
            lines.append(f'measure q[{q}] -> c[{creg_idx % nc}];')
            creg_idx += 1
            continue

        if name == 'reset':
            lines.append(f'reset q[{qubits[0]}];')
            continue

        qasm_name = GATE_TO_QASM.get(name, name)
        qubit_str = ', '.join(f'q[{q}]' for q in qubits)

        if params:
            param_str = ', '.join(_format_angle(p) for p in params)
            lines.append(f'{qasm_name}({param_str}) {qubit_str};')
        else:
            lines.append(f'{qasm_name} {qubit_str};')

    return '\n'.join(lines)


def _format_angle(angle: float) -> str:
    """Format angle as clean fraction of pi if possible."""
    import math
    if abs(angle) < 1e-10:
        return '0'
    for num, den in [(1,1),(1,2),(1,4),(3,4),(1,3),(2,3),(3,2),(2,1),(3,1)]:
        for sign in [1, -1]:
            val = sign * num * math.pi / den
            if abs(angle - val) < 1e-8:
                if den == 1:
                    return f"{'pi' if sign==1 else '-pi'}" if num==1 else f"{sign*num}*pi"
                return f"{'pi' if sign==1 else '-pi'}/{den}" if num==1 else f"{sign*num}*pi/{den}"
    return f'{angle:.8f}'


def to_qasm_file(circuit: QuantumCircuit, filepath: str):
    """Save circuit to .qasm file."""
    qasm = to_qasm(circuit)
    with open(filepath, 'w') as f:
        f.write(qasm)
    print(f"  Saved: {filepath}")


# ─── Import ───────────────────────────────────────────────────────────────────

def from_qasm(qasm_str: str) -> QuantumCircuit:
    """Parse OpenQASM 2.0 string and return QuantumCircuit."""
    lines = [l.strip() for l in qasm_str.strip().split('\n')]
    lines = [l for l in lines if l and not l.startswith('//')]

    n_qubits = 1
    n_classical = 1
    name = 'from_qasm'

    # First pass: find registers
    for line in lines:
        if line.startswith('qreg'):
            m = re.search(r'qreg\s+\w+\[(\d+)\]', line)
            if m:
                n_qubits = int(m.group(1))
        elif line.startswith('creg'):
            m = re.search(r'creg\s+\w+\[(\d+)\]', line)
            if m:
                n_classical = int(m.group(1))

    qc = QuantumCircuit(n_qubits, n_classical, name=name)

    # Second pass: parse gates
    for line in lines:
        if any(line.startswith(k) for k in ('OPENQASM', 'include', 'qreg', 'creg', '//')):
            continue

        # Measure
        if line.startswith('measure'):
            m = re.search(r'measure\s+\w+\[(\d+)\]', line)
            if m:
                qc.measure(int(m.group(1)))
            continue

        # Barrier
        if line.startswith('barrier'):
            qubits = [int(x) for x in re.findall(r'\[(\d+)\]', line)]
            qc.barrier(*qubits)
            continue

        # Reset
        if line.startswith('reset'):
            m = re.search(r'\[(\d+)\]', line)
            if m:
                qc.reset(int(m.group(1)))
            continue

        # Gate with parameters: name(params) qubits;
        m = re.match(r'(\w+)\(([^)]+)\)\s+(.+);', line)
        if m:
            gate_name = m.group(1).lower()
            params_str = m.group(2)
            qubits_str = m.group(3)
            params = [_parse_angle(p.strip()) for p in params_str.split(',')]
            qubits = [int(x) for x in re.findall(r'\[(\d+)\]', qubits_str)]
            _apply_gate(qc, gate_name, params, qubits)
            continue

        # Gate without parameters: name qubits;
        m = re.match(r'(\w+)\s+(.+);', line)
        if m:
            gate_name = m.group(1).lower()
            qubits_str = m.group(2)
            qubits = [int(x) for x in re.findall(r'\[(\d+)\]', qubits_str)]
            _apply_gate(qc, gate_name, [], qubits)

    return qc


def _parse_angle(s: str) -> float:
    """Parse angle expression like 'pi/2', '3*pi/4', '1.5708'."""
    import math
    s = s.strip()
    s = s.replace('pi', str(math.pi))
    try:
        return float(eval(s, {"__builtins__": {}}, {'sqrt': math.sqrt}))
    except Exception:
        return float(s)


def _apply_gate(qc: QuantumCircuit, name: str, params: list, qubits: list):
    """Apply a parsed gate to a circuit."""
    cirqit_name = QASM_TO_GATE.get(name, name)

    gate_map_0p = {
        'h','x','y','z','s','t','sdg','tdg','sx',
        'cnot','cx','cz','cy','swap',
        'ccx','toffoli','cswap','fredkin',
        'i'
    }
    gate_map_1p = {'rx','ry','rz','p','crx','cry','crz','cp'}

    if cirqit_name in gate_map_0p:
        getattr(qc, cirqit_name)(*qubits)
    elif cirqit_name in gate_map_1p:
        getattr(qc, cirqit_name)(params[0], *qubits)
    elif cirqit_name == 'u' and len(params) == 3:
        qc.u(params[0], params[1], params[2], qubits[0])
    else:
        print(f"  Warning: unknown gate '{name}' — skipped")


def from_qasm_file(filepath: str) -> QuantumCircuit:
    """Load circuit from .qasm file."""
    with open(filepath, 'r') as f:
        return from_qasm(f.read())
