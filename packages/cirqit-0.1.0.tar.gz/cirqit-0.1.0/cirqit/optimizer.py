"""
cirqit.optimizer - Circuit optimization passes
===============================================
Reduces circuit depth and gate count via:
- Gate cancellation (X X = I, H H = I, etc.)
- Rotation merging (Rx(a) Rx(b) = Rx(a+b))
- Commutation-based reordering
- Redundant gate removal

Usage
-----
>>> from cirqit.optimizer import optimize
>>> qc_opt = optimize(qc, passes=['cancel', 'merge_rotations', 'commute'])
>>> print(f"Before: depth={qc.depth()}")
>>> print(f"After:  depth={qc_opt.depth()}")
"""

import numpy as np
from .circuit import QuantumCircuit


# ─── Self-inverse gates (G G = I) ─────────────────────────────────────────────
SELF_INVERSE = {'h', 'x', 'y', 'z', 'cnot', 'cx', 'swap', 'cz'}

# ─── Rotation gates that can be merged ────────────────────────────────────────
ROTATION_GATES = {'rx', 'ry', 'rz', 'p'}

# ─── Commutation rules: gate A commutes with gate B on different qubits ───────
# Format: frozenset({gate_a, gate_b}) -> True if they always commute
COMMUTES = {
    frozenset({'x', 'rx'}): True,
    frozenset({'z', 'rz'}): True,
    frozenset({'z', 'p'}):  True,
    frozenset({'rz', 'p'}): True,
    frozenset({'h', 'h'}):  True,
}


def _ops_commute(op1: dict, op2: dict) -> bool:
    """Check if two operations commute (safe to reorder)."""
    q1 = set(op1['qubits'])
    q2 = set(op2['qubits'])
    if not q1 & q2:
        return True  # Disjoint qubits always commute
    n1, n2 = op1['name'], op2['name']
    return COMMUTES.get(frozenset({n1, n2}), False)


def _angle_mod(theta: float) -> float:
    """Normalize angle to (-pi, pi]."""
    return ((theta + np.pi) % (2 * np.pi)) - np.pi


# ─── Optimization passes ──────────────────────────────────────────────────────

def pass_cancel_self_inverse(ops: list) -> list:
    """
    Cancel consecutive self-inverse gates on same qubits.
    H H = I, X X = I, CNOT CNOT = I, etc.
    """
    changed = True
    while changed:
        changed = False
        new_ops = []
        i = 0
        while i < len(ops):
            if (i + 1 < len(ops)
                    and ops[i]['name'] in SELF_INVERSE
                    and ops[i]['name'] == ops[i+1]['name']
                    and ops[i]['qubits'] == ops[i+1]['qubits']):
                i += 2  # Cancel pair
                changed = True
            else:
                new_ops.append(ops[i])
                i += 1
        ops = new_ops
    return ops


def pass_merge_rotations(ops: list) -> list:
    """
    Merge consecutive rotation gates on same qubit.
    Rx(a) Rx(b) = Rx(a+b), Ry(a) Ry(b) = Ry(a+b), etc.
    Removes if merged angle ~ 0 (mod 2pi).
    """
    changed = True
    while changed:
        changed = False
        new_ops = []
        i = 0
        while i < len(ops):
            op = ops[i]
            if (op['name'] in ROTATION_GATES
                    and i + 1 < len(ops)
                    and ops[i+1]['name'] == op['name']
                    and ops[i+1]['qubits'] == op['qubits']):
                merged_angle = _angle_mod(op['params'][0] + ops[i+1]['params'][0])
                if abs(merged_angle) < 1e-9:
                    i += 2  # Both cancel
                    changed = True
                else:
                    merged_op = dict(op)
                    merged_op['params'] = [merged_angle]
                    new_ops.append(merged_op)
                    i += 2
                    changed = True
            else:
                new_ops.append(op)
                i += 1
        ops = new_ops
    return ops


def pass_remove_zero_rotations(ops: list) -> list:
    """Remove rotation gates with angle ~ 0."""
    clean = []
    for op in ops:
        if op['name'] in ROTATION_GATES:
            angle = op['params'][0] if op['params'] else 0
            if abs(_angle_mod(angle)) < 1e-9:
                continue  # Skip ~zero rotation
        clean.append(op)
    return clean


def pass_remove_identity(ops: list) -> list:
    """Remove explicit identity gates."""
    return [op for op in ops if op['name'] != 'i']


def pass_commute_single_past_two(ops: list) -> list:
    """
    Push single-qubit gates past two-qubit gates when they commute.
    Helps expose more cancellation opportunities.
    """
    changed = True
    while changed:
        changed = False
        for i in range(len(ops) - 1):
            op1 = ops[i]
            op2 = ops[i + 1]
            # Move single-qubit earlier if it commutes with two-qubit
            if (len(op1['qubits']) == 2
                    and len(op2['qubits']) == 1
                    and _ops_commute(op1, op2)):
                ops[i], ops[i+1] = ops[i+1], ops[i]
                changed = True
                break
    return ops


def pass_peephole(ops: list) -> list:
    """
    Peephole optimizations:
    - T T = S
    - S S = Z
    - S S S = Sdg
    - Z Z = I
    - X X X = X
    """
    replacements = {
        ('t',   't'):          [('s',   [])],
        ('s',   's'):          [('z',   [])],
        ('s',   's',   's'):   [('sdg', [])],
        ('z',   'z'):          [],
        ('tdg', 'tdg'):        [('sdg', [])],
    }
    changed = True
    while changed:
        changed = False
        new_ops = []
        i = 0
        while i < len(ops):
            matched = False
            for pattern, replacement in replacements.items():
                n = len(pattern)
                if i + n <= len(ops):
                    window = ops[i:i+n]
                    if (all(w['name'] == p for w, p in zip(window, pattern))
                            and all(w['qubits'] == window[0]['qubits'] for w in window)):
                        for r_name, r_params in replacement:
                            new_ops.append({
                                'name': r_name,
                                'qubits': window[0]['qubits'],
                                'params': r_params
                            })
                        i += n
                        matched = True
                        changed = True
                        break
            if not matched:
                new_ops.append(ops[i])
                i += 1
        ops = new_ops
    return ops


# ─── Main optimizer ───────────────────────────────────────────────────────────

ALL_PASSES = [
    'remove_identity',
    'remove_zero_rotations',
    'cancel',
    'merge_rotations',
    'peephole',
    'commute',
]


def optimize(circuit: QuantumCircuit,
             passes: list = None,
             iterations: int = 3,
             verbose: bool = False) -> QuantumCircuit:
    """
    Optimize a quantum circuit.

    Parameters
    ----------
    circuit  : QuantumCircuit
    passes   : list of pass names to apply (default: all)
    iterations : number of optimization rounds
    verbose  : print stats

    Returns
    -------
    Optimized QuantumCircuit (copy)
    """
    import copy
    passes = passes or ALL_PASSES

    ops = copy.deepcopy(circuit._ops)
    original_depth = len([op for op in ops if op['name'] != 'barrier'])

    pass_fns = {
        'cancel':               pass_cancel_self_inverse,
        'merge_rotations':      pass_merge_rotations,
        'remove_zero_rotations': pass_remove_zero_rotations,
        'remove_identity':      pass_remove_identity,
        'commute':              pass_commute_single_past_two,
        'peephole':             pass_peephole,
    }

    # Separate gate ops from measure/barrier
    gate_ops = [op for op in ops if op['name'] not in ('measure', 'barrier')]
    measure_ops = [op for op in ops if op['name'] == 'measure']

    for iteration in range(iterations):
        prev_len = len(gate_ops)
        for pass_name in passes:
            fn = pass_fns.get(pass_name)
            if fn:
                gate_ops = fn(gate_ops)
        if len(gate_ops) == prev_len:
            break  # Converged

    # Rebuild circuit
    opt = QuantumCircuit(circuit.n_qubits, circuit.n_classical, name=circuit.name + '_opt')
    opt._ops = gate_ops + measure_ops
    opt._measured_qubits = copy.deepcopy(circuit._measured_qubits)

    if verbose:
        new_depth = len(gate_ops)
        reduction = original_depth - new_depth
        pct = 100 * reduction / max(original_depth, 1)
        print(f"  Optimizer: {original_depth} → {new_depth} gates "
              f"({reduction} removed, {pct:.1f}% reduction)")
        ops_before = circuit.count_ops()
        ops_after = opt.count_ops()
        for gate in set(list(ops_before.keys()) + list(ops_after.keys())):
            b = ops_before.get(gate, 0)
            a = ops_after.get(gate, 0)
            if b != a:
                print(f"    {gate}: {b} → {a}")

    return opt


def compare(original: QuantumCircuit, optimized: QuantumCircuit):
    """Print comparison between original and optimized circuit."""
    print(f"\n{'='*50}")
    print(f"  Circuit Optimization Report")
    print(f"{'='*50}")
    print(f"  Circuit : {original.name}")
    print(f"  Qubits  : {original.n_qubits}")
    print(f"{'─'*50}")
    print(f"  {'Metric':<20} {'Before':>10} {'After':>10} {'Saved':>8}")
    print(f"{'─'*50}")

    d_before = original.depth()
    d_after  = optimized.depth()
    print(f"  {'Depth':<20} {d_before:>10} {d_after:>10} {d_before-d_after:>8}")

    ops_b = original.count_ops()
    ops_a = optimized.count_ops()
    total_b = sum(v for k, v in ops_b.items() if k not in ('measure', 'barrier'))
    total_a = sum(v for k, v in ops_a.items() if k not in ('measure', 'barrier'))
    print(f"  {'Total gates':<20} {total_b:>10} {total_a:>10} {total_b-total_a:>8}")

    for gate in sorted(set(list(ops_b.keys()) + list(ops_a.keys()))):
        if gate in ('measure', 'barrier'):
            continue
        b = ops_b.get(gate, 0)
        a = ops_a.get(gate, 0)
        if b > 0 or a > 0:
            print(f"  {'  '+gate:<20} {b:>10} {a:>10} {b-a:>8}")

    print(f"{'='*50}\n")
