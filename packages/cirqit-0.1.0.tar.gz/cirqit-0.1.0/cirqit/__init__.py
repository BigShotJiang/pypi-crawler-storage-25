"""
cirqit - A pure NumPy quantum circuit simulator
================================================

Quick Start
-----------
>>> from cirqit import QuantumCircuit
>>> qc = QuantumCircuit(2)
>>> qc.h(0)
>>> qc.cnot(0, 1)
>>> qc.measure_all()
>>> result = qc.run(shots=1024)
>>> print(result)
>>> qc.draw()

Noise Example
-------------
>>> from cirqit import QuantumCircuit
>>> from cirqit.noise import DepolarizingChannel, NoiseModel
>>> nm = NoiseModel()
>>> nm.add_gate_error('h', DepolarizingChannel(0.01))
>>> qc = QuantumCircuit(1)
>>> qc.h(0)
>>> qc.set_noise_model(nm)
>>> qc.measure_all()
>>> print(qc.run(shots=1000))

Algorithms
----------
>>> from cirqit.algorithms import bell_state, qft, grover_diffusion
>>> bell = bell_state('00')
>>> bell.measure_all()
>>> print(bell.run(shots=1024))
"""

__version__ = "0.1.0"
__author__ = "Muhammad"
__license__ = "MIT"

from .circuit import QuantumCircuit
from .statevector import StateVector
from .clifford import CliffordCircuit
from .job import CirQitJob, list_jobs, get_job
from . import density_matrix
from . import tensor_network
from . import vqc
from . import optimizer
from . import qasm
from . import qec
from .vqc import VQC, Parameter
from .optimizer import optimize
from .qasm import to_qasm, from_qasm, to_qasm_file, from_qasm_file
from . import noise
from . import algorithms
from . import visualize
from . import gates
from . import clifford

__all__ = [
    "QuantumCircuit",
    "StateVector",
    "CliffordCircuit",
    "CirQitJob",
    "list_jobs",
    "get_job",
    "density_matrix",
    "tensor_network",
    "vqc", "VQC", "Parameter",
    "optimizer", "optimize",
    "qasm", "to_qasm", "from_qasm",
    "qec",
    "noise",
    "algorithms",
    "visualize",
    "gates",
    "clifford",
]
