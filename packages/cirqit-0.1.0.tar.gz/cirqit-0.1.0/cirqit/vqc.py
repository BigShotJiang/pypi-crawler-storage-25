"""
cirqit.vqc - Variational Quantum Circuits
==========================================
Parameterized circuits with automatic gradient computation
via the parameter-shift rule.

Usage
-----
>>> from cirqit.vqc import VQC, Parameter
>>> theta = Parameter('theta', 0.5)
>>> phi   = Parameter('phi', 1.2)
>>>
>>> qc = VQC(2)
>>> qc.ry(theta, 0)
>>> qc.cnot(0, 1)
>>> qc.ry(phi, 1)
>>> qc.measure_all()
>>>
>>> # Compute expectation value
>>> cost = qc.expectation_z(observable_qubit=0)
>>> print(cost)
>>>
>>> # Gradients via parameter-shift rule
>>> grads = qc.gradients()
>>> print(grads)  # {'theta': -0.479, 'phi': 0.231}
>>>
>>> # Optimize (gradient descent)
>>> history = qc.optimize(steps=100, lr=0.1)
"""

import numpy as np
from .circuit import QuantumCircuit


class Parameter:
    """A trainable parameter for VQC."""

    def __init__(self, name: str, value: float = 0.0):
        self.name = name
        self.value = float(value)

    def __float__(self):
        return self.value

    def __repr__(self):
        return f"Parameter('{self.name}', value={self.value:.4f})"


class VQC:
    """
    Variational Quantum Circuit.
    Supports Parameter objects in gate arguments.
    Gradients computed via parameter-shift rule.
    """

    def __init__(self, n_qubits: int, name: str = "vqc"):
        self.n_qubits = n_qubits
        self.name = name
        self._ops = []
        self._params = {}        # name -> Parameter
        self._measured_qubits = []

    # ─── Parameterized gates ──────────────────────────────────────────────────

    def _register(self, param):
        if isinstance(param, Parameter):
            self._params[param.name] = param
        return param

    def ry(self, theta, qubit):
        self._register(theta)
        self._ops.append({'gate': 'ry', 'param': theta, 'qubits': [qubit]})
        return self

    def rx(self, theta, qubit):
        self._register(theta)
        self._ops.append({'gate': 'rx', 'param': theta, 'qubits': [qubit]})
        return self

    def rz(self, theta, qubit):
        self._register(theta)
        self._ops.append({'gate': 'rz', 'param': theta, 'qubits': [qubit]})
        return self

    def p(self, phi, qubit):
        self._register(phi)
        self._ops.append({'gate': 'p', 'param': phi, 'qubits': [qubit]})
        return self

    def crz(self, theta, ctrl, tgt):
        self._register(theta)
        self._ops.append({'gate': 'crz', 'param': theta, 'qubits': [ctrl, tgt]})
        return self

    # Fixed gates (no parameter)
    def h(self, qubit):
        self._ops.append({'gate': 'h', 'param': None, 'qubits': [qubit]})
        return self

    def x(self, qubit):
        self._ops.append({'gate': 'x', 'param': None, 'qubits': [qubit]})
        return self

    def cnot(self, ctrl, tgt):
        self._ops.append({'gate': 'cnot', 'param': None, 'qubits': [ctrl, tgt]})
        return self

    def cx(self, ctrl, tgt):
        return self.cnot(ctrl, tgt)

    def cz(self, q0, q1):
        self._ops.append({'gate': 'cz', 'param': None, 'qubits': [q0, q1]})
        return self

    def measure_all(self):
        for q in range(self.n_qubits):
            self._measured_qubits.append(q)
        return self

    def measure(self, qubit):
        self._measured_qubits.append(qubit)
        return self

    # ─── Build concrete circuit ───────────────────────────────────────────────

    def _build(self, param_overrides: dict = None) -> QuantumCircuit:
        """Build a concrete QuantumCircuit with current parameter values."""
        overrides = param_overrides or {}
        qc = QuantumCircuit(self.n_qubits, name=self.name)
        for op in self._ops:
            gate = op['gate']
            param = op['param']
            qubits = op['qubits']
            if param is None:
                val = None
            elif isinstance(param, Parameter):
                val = overrides.get(param.name, param.value)
            else:
                val = float(param)

            if gate in ('h', 'x', 'cnot', 'cx', 'cz'):
                getattr(qc, gate)(*qubits)
            else:
                getattr(qc, gate)(val, *qubits)

        for q in set(self._measured_qubits):
            qc.measure(q)
        return qc

    # ─── Execution ────────────────────────────────────────────────────────────

    def run(self, shots: int = 1024, seed: int = None) -> dict:
        """Run circuit with current parameter values."""
        return self._build().run(shots=shots, seed=seed)

    def statevector(self):
        """Get statevector with current parameters."""
        return self._build().statevector()

    def expectation_z(self, qubit: int = 0, shots: int = 2048) -> float:
        """
        <Z> on a qubit = P(0) - P(1).
        Used as cost function for optimization.
        """
        counts = self.run(shots=shots)
        total = sum(counts.values())
        exp_val = 0.0
        for bitstring, count in counts.items():
            bit = int(bitstring[qubit])
            exp_val += count * (1 - 2 * bit)
        return exp_val / total

    def expectation_observable(self, observable: np.ndarray, shots: int = 4096) -> float:
        """<psi|O|psi> via statevector."""
        sv = self.statevector()
        state = sv.state
        return float(np.real(state.conj() @ observable @ state))

    # ─── Gradients ────────────────────────────────────────────────────────────

    def gradients(self, shots: int = 2048, shift: float = np.pi / 2) -> dict:
        """
        Compute gradients for all parameters via parameter-shift rule.
        d<f>/d_theta = [f(theta + pi/2) - f(theta - pi/2)] / 2
        Returns dict: {param_name: gradient_value}
        """
        grads = {}
        for name, param in self._params.items():
            orig = param.value

            # Forward shift
            param.value = orig + shift
            f_plus = self.expectation_z(shots=shots)

            # Backward shift
            param.value = orig - shift
            f_minus = self.expectation_z(shots=shots)

            grads[name] = (f_plus - f_minus) / 2.0
            param.value = orig  # restore

        return grads

    def gradient_observable(self, observable: np.ndarray, shift: float = np.pi / 2) -> dict:
        """Exact gradients via statevector (no shots needed)."""
        grads = {}
        for name, param in self._params.items():
            orig = param.value
            param.value = orig + shift
            f_plus = self.expectation_observable(observable)
            param.value = orig - shift
            f_minus = self.expectation_observable(observable)
            grads[name] = (f_plus - f_minus) / 2.0
            param.value = orig
        return grads

    # ─── Optimization ─────────────────────────────────────────────────────────

    def optimize(self, steps: int = 100, lr: float = 0.1,
                 shots: int = 2048, verbose: bool = True,
                 callback=None) -> list:
        """
        Gradient descent optimization.
        Minimizes expectation_z (qubit 0).
        Returns list of cost values per step.
        """
        history = []
        for step in range(steps):
            cost = self.expectation_z(shots=shots)
            history.append(cost)
            grads = self.gradients(shots=shots)

            # Update parameters
            for name, param in self._params.items():
                param.value -= lr * grads[name]

            if verbose and (step % max(1, steps // 10) == 0 or step == steps - 1):
                param_str = "  ".join(f"{n}={p.value:.3f}" for n, p in self._params.items())
                print(f"  Step {step:>4}: cost={cost:.4f}  [{param_str}]")

            if callback:
                callback(step, cost, self._params)

        return history

    def optimize_adam(self, steps: int = 100, lr: float = 0.01,
                      beta1: float = 0.9, beta2: float = 0.999,
                      eps: float = 1e-8, shots: int = 2048,
                      verbose: bool = True) -> list:
        """Adam optimizer for VQC."""
        m = {n: 0.0 for n in self._params}
        v = {n: 0.0 for n in self._params}
        history = []

        for step in range(1, steps + 1):
            cost = self.expectation_z(shots=shots)
            history.append(cost)
            grads = self.gradients(shots=shots)

            for name, param in self._params.items():
                g = grads[name]
                m[name] = beta1 * m[name] + (1 - beta1) * g
                v[name] = beta2 * v[name] + (1 - beta2) * g**2
                m_hat = m[name] / (1 - beta1**step)
                v_hat = v[name] / (1 - beta2**step)
                param.value -= lr * m_hat / (np.sqrt(v_hat) + eps)

            if verbose and (step % max(1, steps // 10) == 0 or step == steps - 1):
                param_str = "  ".join(f"{n}={p.value:.3f}" for n, p in self._params.items())
                print(f"  Adam {step:>4}: cost={cost:.4f}  [{param_str}]")

        return history

    def get_params(self) -> dict:
        return {n: p.value for n, p in self._params.items()}

    def set_params(self, values: dict):
        for name, val in values.items():
            if name in self._params:
                self._params[name].value = val

    def param_count(self) -> int:
        return len(self._params)

    def __repr__(self):
        return (f"VQC('{self.name}', n_qubits={self.n_qubits}, "
                f"params={self.param_count()}, layers={len(self._ops)})")


# ─── Common VQC ansatze ───────────────────────────────────────────────────────

def hardware_efficient_ansatz(n_qubits: int, depth: int) -> VQC:
    """
    Hardware-efficient ansatz: Ry-Rz layers + CNOT entanglement.
    Standard in quantum chemistry and optimization.
    """
    vqc = VQC(n_qubits, name=f'HEA_{n_qubits}q_{depth}d')
    for d in range(depth):
        for q in range(n_qubits):
            vqc.ry(Parameter(f'ry_{d}_{q}', np.random.uniform(0, 2*np.pi)), q)
            vqc.rz(Parameter(f'rz_{d}_{q}', np.random.uniform(0, 2*np.pi)), q)
        for q in range(n_qubits - 1):
            vqc.cnot(q, q + 1)
    return vqc


def strongly_entangling_ansatz(n_qubits: int, depth: int) -> VQC:
    """
    Strongly entangling layers (Schuld et al. 2020).
    """
    vqc = VQC(n_qubits, name=f'SEL_{n_qubits}q_{depth}d')
    for d in range(depth):
        for q in range(n_qubits):
            vqc.rx(Parameter(f'rx_{d}_{q}', np.random.uniform(0, 2*np.pi)), q)
            vqc.ry(Parameter(f'ry_{d}_{q}', np.random.uniform(0, 2*np.pi)), q)
            vqc.rz(Parameter(f'rz_{d}_{q}', np.random.uniform(0, 2*np.pi)), q)
        for q in range(n_qubits):
            vqc.cnot(q, (q + d + 1) % n_qubits)
    return vqc


def qaoa_ansatz(n_qubits: int, p: int) -> tuple:
    """
    QAOA ansatz for combinatorial optimization.
    Returns (vqc, gamma_params, beta_params)
    """
    vqc = VQC(n_qubits, name=f'QAOA_{n_qubits}q_p{p}')
    gammas = []
    betas = []

    for layer in range(p):
        g = Parameter(f'gamma_{layer}', np.random.uniform(0, np.pi))
        b = Parameter(f'beta_{layer}', np.random.uniform(0, np.pi))
        gammas.append(g)
        betas.append(b)

        # Problem unitary (example: MaxCut on path graph)
        for q in range(n_qubits - 1):
            vqc.cnot(q, q + 1)
            vqc.rz(g, q + 1)
            vqc.cnot(q, q + 1)

        # Mixer unitary
        for q in range(n_qubits):
            vqc.rx(b, q)

    return vqc, gammas, betas
