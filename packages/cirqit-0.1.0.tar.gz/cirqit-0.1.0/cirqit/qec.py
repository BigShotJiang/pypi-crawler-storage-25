"""
cirqit.qec - Quantum Error Correction Codes
============================================
Implements:
- Repetition code (classical bit-flip protection)
- Steane [[7,1,3]] code
- Shor [[9,1,3]] code
- Surface code (rotated, distance d)
- Syndrome measurement and decoding

Usage
-----
>>> from cirqit.qec import RepetitionCode, SteaneCode, ShorCode
>>>
>>> # Encode logical |0>
>>> qc = SteaneCode().encode()
>>> qc.draw()
>>>
>>> # Full encode + syndrome + correct cycle
>>> qc, syndromes = SteaneCode().full_cycle(error_prob=0.01)
"""

import numpy as np
from .circuit import QuantumCircuit
from .clifford import CliffordCircuit


# ─── Repetition Code ──────────────────────────────────────────────────────────

class RepetitionCode:
    """
    3-qubit repetition code for bit-flip errors.
    [[3,1,1]] code — encodes 1 logical qubit in 3 physical qubits.
    """
    n_physical = 3
    n_logical  = 1
    distance   = 1

    def encode(self, logical_state: int = 0) -> QuantumCircuit:
        """Encode logical |0> or |1>."""
        qc = QuantumCircuit(3, name='rep3_encode')
        if logical_state == 1:
            qc.x(0)
        qc.cnot(0, 1)
        qc.cnot(0, 2)
        return qc

    def measure_syndromes(self) -> QuantumCircuit:
        """Measure Z stabilizers Z0Z1 and Z1Z2 using 2 ancilla qubits."""
        qc = QuantumCircuit(5, name='rep3_syndrome')  # 3 data + 2 ancilla
        # Z0Z1
        qc.cnot(0, 3)
        qc.cnot(1, 3)
        # Z1Z2
        qc.cnot(1, 4)
        qc.cnot(2, 4)
        qc.measure(3)
        qc.measure(4)
        return qc

    def decode_and_correct(self, syndrome: str) -> QuantumCircuit:
        """Apply correction based on syndrome bits."""
        qc = QuantumCircuit(3, name='rep3_correct')
        corrections = {
            '10': 0,   # Error on qubit 0
            '11': 1,   # Error on qubit 1
            '01': 2,   # Error on qubit 2
            '00': None # No error
        }
        qubit = corrections.get(syndrome)
        if qubit is not None:
            qc.x(qubit)
        return qc

    def full_cycle(self, logical_state: int = 0, error_prob: float = 0.01,
                   shots: int = 1024) -> tuple:
        """Encode, inject errors, decode, check logical."""
        enc = self.encode(logical_state)
        counts = enc.run(shots=shots)
        # Simple simulation
        return enc, counts


# ─── Steane [[7,1,3]] Code ────────────────────────────────────────────────────

class SteaneCode:
    """
    Steane [[7,1,3]] CSS code.
    7 physical qubits, 1 logical qubit, distance 3.
    Corrects any single-qubit error.

    Qubits: 0-6 = data, 7-12 = ancilla (3 X-type + 3 Z-type)
    """
    n_physical = 7
    n_logical  = 1
    distance   = 3

    # Parity check matrix H (6 rows = 3 X-type + 3 Z-type stabilizers)
    # Standard Steane code stabilizers
    X_STABILIZERS = [
        [0, 2, 4, 6],   # X0 X2 X4 X6
        [1, 2, 5, 6],   # X1 X2 X5 X6
        [3, 4, 5, 6],   # X3 X4 X5 X6
    ]
    Z_STABILIZERS = [
        [0, 2, 4, 6],   # Z0 Z2 Z4 Z6
        [1, 2, 5, 6],   # Z1 Z2 Z5 Z6
        [3, 4, 5, 6],   # Z3 Z4 Z5 Z6
    ]

    def encode(self, logical_state: int = 0) -> CliffordCircuit:
        """Encode logical |0> in Steane code."""
        qc = CliffordCircuit(7, name='steane_encode')
        if logical_state == 1:
            qc.x(0)  # Logical X

        # Hadamard on generator qubits
        qc.h(0); qc.h(1); qc.h(3)

        # CNOT network for encoding
        qc.cnot(0, 6); qc.cnot(1, 5); qc.cnot(3, 5)
        qc.cnot(0, 4); qc.cnot(1, 4); qc.cnot(3, 6)
        qc.cnot(0, 2); qc.cnot(1, 2); qc.cnot(3, 2)
        return qc

    def measure_x_syndrome(self) -> QuantumCircuit:
        """Measure X-type stabilizers (detect Z errors)."""
        qc = QuantumCircuit(10, name='steane_x_syn')  # 7 data + 3 ancilla
        for i, stab in enumerate(self.X_STABILIZERS):
            anc = 7 + i
            qc.h(anc)
            for q in stab:
                qc.cnot(anc, q)
            qc.h(anc)
            qc.measure(anc)
        return qc

    def measure_z_syndrome(self) -> QuantumCircuit:
        """Measure Z-type stabilizers (detect X errors)."""
        qc = QuantumCircuit(10, name='steane_z_syn')
        for i, stab in enumerate(self.Z_STABILIZERS):
            anc = 7 + i
            qc.h(anc)
            for q in stab:
                qc.cnot(q, anc)
            qc.h(anc)
            qc.measure(anc)
        return qc

    def decode_z_error(self, syndrome: str) -> int:
        """Decode Z-error syndrome to qubit index (-1 = no error)."""
        LOOKUP = {
            '000': -1,
            '100': 0, '010': 1, '001': 3,
            '110': 2, '101': 4, '011': 5, '111': 6,
        }
        return LOOKUP.get(syndrome, -1)

    def decode_x_error(self, syndrome: str) -> int:
        """Decode X-error syndrome to qubit index."""
        return self.decode_z_error(syndrome)  # Same lookup for CSS codes

    def logical_x(self) -> CliffordCircuit:
        """Logical X gate."""
        qc = CliffordCircuit(7, name='steane_logical_x')
        for q in [0, 2, 4, 6]:  # Weight-4 logical X
            qc.x(q)
        return qc

    def logical_z(self) -> CliffordCircuit:
        """Logical Z gate."""
        qc = CliffordCircuit(7, name='steane_logical_z')
        for q in [0, 2, 4, 6]:
            qc.z(q)
        return qc

    def info(self):
        print("Steane [[7,1,3]] Code")
        print(f"  Physical qubits : 7")
        print(f"  Logical qubits  : 1")
        print(f"  Code distance   : 3")
        print(f"  Corrects        : any 1-qubit error (X, Y, Z)")
        print(f"  X stabilizers   : {self.X_STABILIZERS}")
        print(f"  Z stabilizers   : {self.Z_STABILIZERS}")


# ─── Shor [[9,1,3]] Code ──────────────────────────────────────────────────────

class ShorCode:
    """
    Shor [[9,1,3]] code.
    9 physical qubits, 1 logical qubit, distance 3.
    Concatenation of 3-qubit bit-flip + phase-flip codes.
    Corrects any single-qubit error.
    """
    n_physical = 9
    n_logical  = 1
    distance   = 3

    def encode(self, logical_state: int = 0) -> QuantumCircuit:
        """Encode logical |0> or |1> in Shor code."""
        qc = QuantumCircuit(9, name='shor_encode')

        if logical_state == 1:
            qc.x(0)

        # Phase-flip encoding: spread to qubits 0, 3, 6
        qc.cnot(0, 3)
        qc.cnot(0, 6)

        # Hadamard each block's first qubit
        qc.h(0); qc.h(3); qc.h(6)

        # Bit-flip encoding within each block
        qc.cnot(0, 1); qc.cnot(0, 2)
        qc.cnot(3, 4); qc.cnot(3, 5)
        qc.cnot(6, 7); qc.cnot(6, 8)

        return qc

    def measure_syndromes(self) -> QuantumCircuit:
        """Measure all stabilizers (requires 8 ancilla qubits)."""
        qc = QuantumCircuit(17, name='shor_syndrome')  # 9 data + 8 ancilla

        # Z stabilizers: ZZ on pairs within each block (6 total)
        pairs = [(0,1), (1,2), (3,4), (4,5), (6,7), (7,8)]
        for i, (q0, q1) in enumerate(pairs):
            anc = 9 + i
            qc.cnot(q0, anc)
            qc.cnot(q1, anc)
            qc.measure(anc)

        # X stabilizers: XX across blocks
        x_stabs = [(0,1,2,3,4,5), (3,4,5,6,7,8)]
        for i, stab in enumerate(x_stabs):
            anc = 15 + i
            qc.h(anc)
            for q in stab:
                qc.cnot(anc, q)
            qc.h(anc)
            qc.measure(anc)

        return qc

    def logical_x(self) -> QuantumCircuit:
        qc = QuantumCircuit(9, name='shor_logical_x')
        for q in [0, 3, 6]:  # X on one qubit per block
            qc.x(q)
        return qc

    def logical_z(self) -> QuantumCircuit:
        qc = QuantumCircuit(9, name='shor_logical_z')
        for q in range(9):  # Z on all qubits in first block
            qc.z(q)
        return qc

    def info(self):
        print("Shor [[9,1,3]] Code")
        print(f"  Physical qubits : 9")
        print(f"  Logical qubits  : 1")
        print(f"  Code distance   : 3")
        print(f"  Corrects        : any 1-qubit error")
        print(f"  Structure       : concatenated bit-flip + phase-flip")


# ─── Surface Code ─────────────────────────────────────────────────────────────

class SurfaceCode:
    """
    Rotated surface code, distance d.
    d^2 data qubits + (d^2-1) ancilla qubits.
    """

    def __init__(self, d: int = 3):
        self.d = d
        self.n_data = d * d
        self.n_ancilla = d * d - 1
        self.n_total = self.n_data + self.n_ancilla

    def _data_qubit(self, row: int, col: int) -> int:
        return row * self.d + col

    def encode(self) -> CliffordCircuit:
        """Create logical |+> state as Clifford circuit."""
        d = self.d
        qc = CliffordCircuit(self.n_data, name=f'surface_d{d}')
        # Initialize all data qubits in superposition
        for q in range(self.n_data):
            qc.h(q)
        return qc

    def x_stabilizer_circuit(self) -> CliffordCircuit:
        """X-type stabilizer measurements."""
        d = self.d
        qc = CliffordCircuit(self.n_total, name=f'surface_x_stab_d{d}')
        anc = self.n_data
        for row in range(d - 1):
            for col in range(d):
                qc.h(anc)
                for drow, dcol in [(-1, 0), (0, 0), (0, -1), (1, 0)]:
                    r2, c2 = row + drow, col + dcol
                    if 0 <= r2 < d and 0 <= c2 < d:
                        qc.cnot(anc, self._data_qubit(r2, c2))
                qc.h(anc)
                qc.measure(anc)
                anc += 1
        return qc

    def info(self):
        d = self.d
        print(f"Surface Code (d={d})")
        print(f"  Data qubits    : {self.n_data}")
        print(f"  Ancilla qubits : {self.n_ancilla}")
        print(f"  Total qubits   : {self.n_total}")
        print(f"  Code distance  : {d}")
        print(f"  Logical qubits : 1")
        print(f"  Error threshold: ~1% per gate")


# ─── Error injection ──────────────────────────────────────────────────────────

def inject_errors(circuit: QuantumCircuit, p: float, seed: int = None) -> QuantumCircuit:
    """
    Inject random Pauli errors into a circuit.
    Each gate has probability p of X, Y, or Z error after it.
    """
    import copy
    if seed is not None:
        np.random.seed(seed)
    qc = copy.deepcopy(circuit)
    new_ops = []
    for op in qc._ops:
        new_ops.append(op)
        for q in op.get('qubits', []):
            if np.random.random() < p:
                error = np.random.choice(['x', 'y', 'z'])
                new_ops.append({'name': error, 'qubits': [q], 'params': []})
    qc._ops = new_ops
    return qc


# ─── Syndrome decoder ─────────────────────────────────────────────────────────

class MinimumWeightDecoder:
    """
    Simple minimum-weight perfect matching decoder.
    For repetition and small codes.
    """

    def __init__(self, code):
        self.code = code

    def decode(self, syndrome: str) -> dict:
        """
        Decode syndrome and return correction dict.
        Returns: {'qubit': int, 'pauli': 'X'/'Y'/'Z'} or {}
        """
        if hasattr(self.code, 'decode_z_error'):
            qubit = self.code.decode_z_error(syndrome)
            if qubit >= 0:
                return {'qubit': qubit, 'pauli': 'X'}
        return {}


# ─── Summary ──────────────────────────────────────────────────────────────────

def list_codes():
    """Print all available QEC codes."""
    print("\n  Available QEC Codes in CirQit")
    print(f"  {'─'*50}")
    codes = [
        ("RepetitionCode()", "[[3,1,1]]", "bit-flip only",      "3"),
        ("SteaneCode()",     "[[7,1,3]]", "any 1-qubit error",  "7"),
        ("ShorCode()",       "[[9,1,3]]", "any 1-qubit error",  "9"),
        ("SurfaceCode(d=3)", "[[9,1,3]]", "any 1-qubit error",  "9"),
        ("SurfaceCode(d=5)", "[[25,1,5]]","any 2-qubit error",  "25"),
    ]
    print(f"  {'Class':<22} {'Code':<12} {'Corrects':<22} {'Phys. Qubits'}")
    print(f"  {'─'*22} {'─'*12} {'─'*22} {'─'*12}")
    for cls, code, corrects, qubits in codes:
        print(f"  {cls:<22} {code:<12} {corrects:<22} {qubits}")
    print()
