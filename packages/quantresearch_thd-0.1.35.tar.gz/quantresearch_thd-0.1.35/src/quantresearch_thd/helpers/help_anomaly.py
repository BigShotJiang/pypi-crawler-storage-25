import pandas as pd
import numpy as np
import plotly.graph_objects as go
from IPython.display import display, Markdown
import logging
import warnings
warnings.filterwarnings("ignore")
from .utils import (get_stl_period,
                        process_stats_group,
                                    process_group,
                                   )
from .iso_forest_general import detect_outliers_isf_general
from .ewma import ewma_with_anomalies_rolling_group
from .fb_prophet import detect_time_series_anomalies_fb_walkforward
from .iso_forest_timeseries import detect_time_series_anomalies_isoforest
from .DB_scan import detect_time_series_anomalies_dbscan
from .Preprocessing import (create_full_calendar_and_interpolate, 
                            calculate_ensemble_scores)
from .evaluation_plots import (anomaly_overview_plot, 
                               anomaly_percentile_plot,
                               anomaly_sd_plot, 
                               anomaly_mad_plot, 
                               anomaly_iqr_plot, 
                               anomaly_ewma_plot, 
                               anomaly_fb_plot, 
                               anomaly_dbscan_plot, 
                               anomaly_isolation_forest_plot)
from .utils import (print_success_message,
                    anomaly_summary_chart)


from .config import MODEL_CONFIG


def help_anomaly(topic=None):
    
    #example_df = get_example_df()

    if topic == None:
        help_overview()
    elif topic.lower()[:7] == 'percent':
        help_percentile()
    elif topic.lower() == 'iqr':
        help_iqr()
    elif topic.lower()[:2] == 'fb' or topic.lower()[:5] == 'proph':
        help_fb()
    elif topic.lower() == 'ewma':
        help_ewma()
    elif topic.lower()[:2] == 'db':
        help_dbscan()
    elif topic.lower()[:3] == 'iso':
        help_isofor()
    elif topic.lower()[:2] in ['st', 'sd']:
        help_sd()
    elif topic.lower()[:3] == 'mad':
        help_mad()
    elif topic.lower()[:3] == 'imp' or topic.lower()[:4] == 'miss':
        help_imputation()
    elif topic.lower()[:5] == 'final' or topic.lower()[:6] == 'result':
        help_final_results()
    



unique_ids = ["key", "channel"] 
variable = "views"
date_column =  "week_start"
freq = "W-MON"
eval_period = 1
imputation_method = "median"
percentile_threshold = 0.02
SD_threshold = 3
mad_threshold = 5
mad_scale_factor = 0.6745
IQR_threshold = 3
magnitude_threshold=0
alpha = 0.3
sigma = 2
prophet_CI = 0.95
contamination = 0.05
sensitivity = 0.95
random_state = 42
max_records = 156
enabled_models=['PERCENTILE', 'SD', 'MAD', 'IQR', 'EWMA', 'FB', 'ISF', 'DBSCAN']


def get_example_df():
    """
    Generates a sample dataset and runs all 8 models to demonstrate 
    the quantresearch_thd functionality.
    """
    
    # 1. Create dummy time-series data
    views = [
        223006, 145101, 136508, 119284, 151332, 169419, 158795, 163725, 161911, 153131, 
        178292, 188910, 192736, 165486, 157370, 151250, 151699, 144465, 167651, 185210, 
        172594, 176735, 158885, 140992, 184203, 235889, 203074, 203714, 162486, 227249, 
        243952, 241711, 213386, 183171, 176070, 185944, 191282, 180852, 219299, 271454, 
        216265, 150586, 123755, 126039, 117597, 103758, 133977, 144088, 143186, 247731, 
        267901, 289105, 378025, 221419, 119153, 117262, 135635, 157462, 158551, 162637, 
        157246, 144626, 129089, 153280, 145880, 130291, 114119, 112931, 110593, 120172, 
        185307, 213343, 164825, 153140, 127525, 128465, 180317, 232471, 229766, 129962, 
        98732, 181722, 198247, 222167, 175792, 131070, 154662, 158707, 152083, 151097, 
        194114, 230775, 195828, 150668, 119488, 118110, 165357, 150681, 151303, 137414, 
        126470, 223347, 222285, 244610, 277318
    ]

    example_df = pd.DataFrame({
        'key': ['PLP>appliances>refrigerators'] * len(views),
        'channel': ['raw_desktop_views'] * len(views),
        'week_start': pd.date_range(start='2023-11-27', periods=len(views), freq=freq),
        'views': views
    })
    

    # 2. Preprocessing
    # Assuming create_full_calendar_and_interpolate returns a tuple (df, success, exclusion)
    example_df = create_full_calendar_and_interpolate(
    example_df, unique_ids, variable, date_column, freq, max_records, imputation_method, eval_period
)[0]

    # Silence Prophet/CmdStanPy noise
    logging.getLogger('fbprophet').setLevel(logging.ERROR)
    logging.getLogger('cmdstanpy').disabled = True
    
    df_percentile, df_std,df_mad,df_iqr = process_stats_group(
                    example_df, variable, date_column, eval_period, freq, percentile_threshold,
                    SD_threshold, mad_threshold, mad_scale_factor, IQR_threshold,magnitude_threshold
                )
    
    df_ewma = ewma_with_anomalies_rolling_group(example_df, unique_ids, variable, date_column, alpha, sigma, eval_period)
    df_fb = detect_time_series_anomalies_fb_walkforward(example_df,variable,date_column,eval_period,prophet_CI)
    df_isofor =detect_time_series_anomalies_isoforest(example_df, variable, date_column, eval_period)
    
    # 4. Handle Isolation Forest Logic (Consolidating General + Time-series)
    df_isogen = detect_outliers_isf_general(example_df, variable, contamination, random_state, eval_period)
                                                      
                                                      # Combine General and Timeseries results based on Train/Test set
    isf_combined = df_isogen.merge(
                df_isofor[unique_ids + [date_column, 'IsolationForest_score_timeseries', 
                                        'IsolationForest_score_low_timeseries', 
                                        'is_IsolationForest_anomaly_timeseries', 
                                        'IsolationForest_anomaly_timeseries']], 
                on=unique_ids + [date_column], how='inner'
            )
            
           
    for suffix in ['', '_low']:
        # For boolean/categorical 'anomaly' and numeric scores
        main_col = f'IsolationForest_score{suffix}'
        ts_col = f'IsolationForest_score{suffix}_timeseries'
        gen_col = f'IsolationForest_score{suffix}_general'
                
        # Coalesce: Use TS if not null, else use General
        isf_combined[main_col] = isf_combined[ts_col].fillna(isf_combined[gen_col])

    # Specifically handle the 'is_Anomaly' boolean flag
    isf_combined['IsolationForest_anomaly'] = (
        isf_combined['IsolationForest_anomaly_timeseries']
            .fillna(isf_combined['IsolationForest_anomaly_general'])
            )
    isf_combined['is_IsolationForest_anomaly'] = (
                isf_combined['is_IsolationForest_anomaly_timeseries']
                .fillna(isf_combined['is_IsolationForest_anomaly_general'])
            )
                                                                              
            #print(isf_combined.head(50))
            #print(isf_combined.tail(50))                                                                 
                                                                              
    df_ISF = isf_combined[unique_ids + [date_column] + MODEL_CONFIG['ISF']]

    # 5. Final Model (DBSCAN)
    df_dbscan = detect_time_series_anomalies_dbscan(
            example_df, variable, date_column, eval_period, sensitivity
        )

    # 6. Concatenate Results
    # Identify non-original columns to avoid duplicates during join
    orig_cols = example_df.columns.to_list()
    decomp_cols = ['base_signal', 'residual', 'residual_proportion'] # Common column
    
    # Combine stats models without duplicating shared columns
    stats_combined = pd.concat([
        df_percentile.drop(columns=orig_cols, errors='ignore'), # Contains base_signal and residual
        df_iqr.drop(columns=orig_cols + [c for c in decomp_cols if c in df_iqr.columns], errors='ignore'),
        df_mad.drop(columns=orig_cols + [c for c in decomp_cols if c in df_mad.columns], errors='ignore'),
        df_std.drop(columns=orig_cols + [c for c in decomp_cols if c in df_std.columns], errors='ignore')
    ], axis=1)

    combined_df = pd.concat([
        example_df,
        stats_combined,
        df_ewma.drop(columns=orig_cols, errors='ignore'),
        df_fb.drop(columns=orig_cols, errors='ignore'),
        df_ISF.drop(columns=orig_cols, errors='ignore'),
        df_dbscan.drop(columns=orig_cols, errors='ignore')
    ], axis=1)

    # 7. Calculate Final Ensemble Scores
    final_example_df = calculate_ensemble_scores(combined_df, variable, unique_ids, date_column, enabled_models)
    
    # Optional: assign to a global variable for notebook access
    globals()['anomaly_example_df'] = final_example_df
    
    return final_example_df
    


def help_overview():
    display(Markdown(overview_msg))
    example_df = get_example_df()
    display(example_df[['key', 'channel', 'week_start', 'views']].tail(12))
    display(Markdown(overview_msg2))
    anomaly_overview_plot(example_df, unique_ids, variable, date_column, eval_period, show_anomaly_scores_on_main_plot=False)


def help_percentile():
    display(Markdown(percentile_msg))
    example_df = get_example_df()
    anomaly_percentile_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)
    
def help_sd():
    display(Markdown(sd_msg))
    example_df = get_example_df()
    anomaly_sd_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)
    
def help_mad():
    display(Markdown(mad_msg))
    example_df = get_example_df()
    anomaly_mad_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)


def help_iqr():
    display(Markdown(iqr_msg))
    example_df = get_example_df()
    anomaly_iqr_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)



def help_ewma():
    display(Markdown(ewma_msg))
    example_df = get_example_df()
    anomaly_ewma_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)


def help_fb():
    display(Markdown(fb_msg))
    example_df = get_example_df()
    anomaly_fb_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)
    
def help_isofor():
    display(Markdown(isofor_msg))
    example_df = get_example_df()
    anomaly_isolation_forest_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)


def help_dbscan():
    display(Markdown(dbscan_msg))
    example_df = get_example_df()
    anomaly_dbscan_plot(example_df, unique_ids, variable, date_column, eval_period, final_anomalies=False)

def help_imputation():
    display(Markdown(imputation_msg))

def help_final_results():
    display(Markdown(anomaly_final_msg))
    

overview_msg = """
# 🕵️ The Anomaly Detection Function
---
This package performs anomaly detection on time series data using an ensemble of different models

```python

def timeseries_anomaly_detection(
    master_data = None, 
    unique_ids = None, 
    variable = None,
    date_column = None,
    freq = "W-MON",
    eval_period = 1,
    max_records = None,
    imputation_method = "median",
    percentile_threshold = 0.02,
    SD_threshold = 3,
    mad_threshold = 5, 
    mad_scale_factor = 0.6745,
    IQR_threshold = 3,
    magnitude_threshold=0,
    alpha = 0.3, 
    sigma = 2, 
    prophet_CI = 0.95, 
    contamination = 0.05, 
    sensitivity = 0.95,
    random_state = 42,
    enabled_models=['PERCENTILE', 'SD', 'MAD', 'IQR', 'EWMA', 'FB', 'ISF', 'DBSCAN']
):
    

```
     
## 📌 MANDATORY ARGUMENTS
   
* **master_data** (pd.DataFrame) : Name of your dataframe containing inputs to be evaluated for anomalies
                                   include variables, dates, and unique_ids.
* **unique_ids** (list[str])  : List of columns used to segment data ['SKU', 'channel', "store_id"].
* **variable** (str)             : The numerical target column name to analyze for presence of anomalies.
* **date_column** (str)          : The datetime column representing the time dimension ["date","week","month"].
* **freq** (str)                : Frequency of the date column. Default: 'W-MON'. Accepts 'D', or 'MS'.

## ⚙️ OPTIONAL ARGUMENTS
* **eval_period** (int)         : Number of trailing records or periods to evaluate for anomalies. Default: 1.
* **max_records** (int)         : Max history to consider starting from the most recent date. Default: all history
* **imputation_method**         : Technique to fill missing time units. Default: 'linear'. Acceptable values are : 'mean',                                     'mode', 'zero', 'linear'
* **percentile_threshold** (int): Percentile parameter, Identifies top 2 and bottom 2 percentile as anomaly. Default: 0.02.
* **SD_threshold** (int)        : SD parameter, controls the number of deviation from mean. Default: 3.
* **mad_threshold** (int)       : MAD parameter, controls Median Absolute Deviation sensitivity. Default: 5.
* **mad_scale_factor** (int)    : MAD parameter, The scaling constant used to normalize the MAD. Default: 0.6745.
* **IQR_threshold** (int)       : IQR parameter, controls IQR multiplicative term. Default: 3.
* **magnitude_threshold** (int) : statistical model parameter, controls the % deviation from base_signal as a gate for                                         statistical anomaly check. Accepts 0 to 1. Default: 0.
* **alpha** (float)             : EWMA parameter, controls the smoothing factor for EWMA trend. Default: 0.3.
* **sigma** (float)             : EWMA parameter, determines the standard deviation multiplier for upper and lower                                             bounds. Default: 2.
* **prophet_CI** (float)        : Prophet parameter, determines the confidence interval. Range 0 to 1,                                                         Default: 0.95.
* **contamination** (float)     : Isolation Forest parameter, expected % of outliers (0 to 0.5). Default: 0.05. 
* **sensitivity** (float)       : DBSCAN parameter controls the anomaly detection threshold by inversely adjusting the                                         Epsilon radius. Higher sensitivity results in smaller radius. Default: 0.95. 
* **random_state** (int)        : Seed for model reproducibility. Default: 42.
* **enable_models** (list)      : selected model list. Default : ['PERCENTILE', 'SD', 'MAD', 'IQR', 'EWMA', 'FB', 'ISF','DBSCAN']
## 📤 RETURNS

`tuple` [pd.DataFrame, pd.DataFrame]:

* **final_results**         :   The main output, a dataframe that identifies anomalies with `Anomaly_Votes` and                                               `is_Anomaly`.
* **evaluation_report**     :   Summary of imputation%, record counts, and anomaly rates.

---

FYI, to see a description about the final results table, use this command:

```python
help_anomaly('final')
```

---

You can see information about specific models used in the anomaly pipeline with any of the following commands:

```python
help_anomaly('percentile')
help_anomaly('iqr')
help_anomaly('mad')
help_anomaly('std')
help_anomaly('ewma')
help_anomaly('prophet')
help_anomaly('dbscan')
help_anomaly('iso') # For information on isolation forest
```

---

The `run_pipeline` function handles end-to-end processing — from data cleaning and imputation to executing multiple machine learning models in parallel and aggregating their results into a final "Consensus" anomaly flag.

---

Speaking of imputation, run this command to learn more about available imputation methods:

```python
help_anomaly('imputation')
```

---

## 📋 Functional Overview
The pipeline takes raw master data, partitions it into groups by unique ID, applies a suite of 8 different anomaly detection methods, and then flags observations as anomalies where at least half of the models consider the observation an anomaly.

The master data DataFrame that you pass into the anomaly detection pipeline needs to have at least 3 columns - unique ID, date, and a target variable. The unique ID can be defined by multiple columns.

Here is an example of a DataFrame that has two columns that comprise the unique ID `['key', 'channel']`, `week_start` is the date column, and `views` is the target variable:"""


overview_msg2 = """
## 🧠 Core Execution Stages

### 1. Preprocessing & imputation
* **Interpolation:** Before modeling, the function imputates target variable values for missing dates to ensure time-series continuity. Fill gaps in the `variable` column to prevent model crashes.

* **STL Decomposition:** Every group is decomposed into **Trend**, **Seasonality**, and **Residuals**.

* **Normalization:** The pipeline calculates the **Residual Proportion** (Actual - Base)/Base. All core statistical models are trained on this normalized ratio, making the pipeline **scale-invariant**.

### 2. Statistical Baseline Models (Local Execution)
The pipeline first runs four computationally light models sequentially on each group:
* **Percentile & IQR:** Non-parametric bounds detection.
* **SD (Standard Deviation) & MAD (Median Absolute Deviation):** Variance-based detection.

### 3. Parallel Machine Learning Suite (`process_group`)
To maximize performance, the pipeline uses `joblib.Parallel` to run intensive models across all available CPU cores. The `process_group` utility acts as a **router**, sending data to the correct engine based on the model key:
* **FB (Prophet):** Walk-forward time-series forecasting.
* **EWMA:** Exponentially weighted moving averages.
* **ISF (Isolation Forest):** Unsupervised isolation of anomalies.
* **DBSCAN:** Density-based spatial clustering.

### 4. Majority Voting (Ensemble Logic)
The power of this pipeline lies in its **Consensus Model**. After all models finish, the pipeline calculates:
* **`Anomaly_Votes`**: The sum of flags across all 8 methods.

* **`is_Anomaly`**: A final boolean set to **True** only if at least **4 models** agree that the point is an outlier.

### 5. Cleansing & Reconstruction

* **Lenient Boundary Clipping:** Anomalies are "cleansed" by clipping them to the most conservative boundary suggested by the voting models.

* **Proportional Scale-Back: ** Boundaries are projected from the percentage domain back into raw units using the formula: Base x (1 + Proportion).

## 📤 Key Output Columns
* **`refresh_date`**: The timestamp of when the pipeline was executed.
* **`Anomaly_Votes`**: Total count of models that flagged the row.
* **`is_Anomaly`**: The final "Gold Standard" anomaly flag.
* **Individual Model Flags**: Columns like `is_FB_anomaly`, `is_IQR_anomaly`, etc., for granular auditing.
* **`raw_total_views_cleansed`**: The sanitized version of the input variable for downstream use.
* **`is_conflict`**: Boolean indicating if models disagreed on the direction (High vs. Low).

## 💡 Usage Context
Use `run_pipeline` when you need high-reliability automated auditing. By combining STL-based proportional modeling with an ensemble of ML algorithms, it effectively handles heteroscedasticity (varying volatility) and provides explainable, robust results for diverse business metrics.
---
## 📊 Evaluation Plot
The plot below shows an example of anomalies identified by the process:
"""


percentile_msg = """# 📈 PERCENTILE MODEL
---

The `detect_outliers_percentile` function  is a sophisticated anomaly detection tool that combines **Seasonal-Trend Decomposition (STL)** with dynamic percentile estimation to identify relative outliers. 

## 📋 Functional Overview
The model measures how far a data point deviates from its expected baseline (Trend + Seasonality). By evaluating the **Residual Proportion**, the model ensures that detection sensitivity is scale-invariant—meaning it is just as effective at detecting a 10% drop in high-volume peak seasons as it is in low-volume off-seasons.

## 🧠 Core Logic Stages

### 1.  Data Preparation and Validation
* **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
prevent statistically insignificant results.

* **Copying:** It creates a copy of the input group to ensure the original data remains unaltered during the calculation process.

### 2. Signal Extraction (STL)
Before statistical testing begins, the function uses **STL Decomposition** to break the time series into Trend, Seasonality, and Residual components.
* **Base Signal:** Calculated as `Trend + Seasonality`.
* **Residual Proportion:**  Calculated as `(Actual - Base)/Base`. This normalized metric is the primary input for the outlier detection.

### 3. Proportional Thresholding
* **Normal Range:** The model establishes behavior based on the the bottom and top two percentiles of the historical Residual Proportion.
* **Dynamic Adaptation:**  It uses an expanding window for the evaluation period. As each new point is tested, the historical distribution of "proportional noise" is recalculated, allowing the model to adapt to changing volatility.

### 4. Reconstruction (Scale-Back)
Once the proportional bounds (e.g., -15% and +20%) are determined, they are projected back onto the raw unit scale:
* **Thresholds:** `Base x (1 + Proportion_bound)`.

## 📤 Key Output Columns
The function appends the following columns to the returned DataFrame:
* **`Percentile_low` / `Percentile_high`**: The thresholds translated back into raw units (e.g., Views).
* **`Percentile_anomaly`**: A categorical label (likely "High," "Low," or "Normal") generated by the external `classify` function.
* **`is_Percentile_anomaly`**:  Boolean flag indicating if the proportion exceeded historical noise limits.

## 💡 Usage Context
This model is superior for Heteroscedastic data—where the variance increases as volume increases. By focusing on the percentage of the error relative to the base, it suppresses false positives that commonly occur at the peaks of high-volume cycles.

---
## 📊 Evaluation Plot
The plot below demonstrates how the Percentile model establishes proportional bounds around the STL-derived base signal:
"""

iqr_msg = iqr_msg = """
# 📊 IQR MODEL (Interquartile Range)
---

The `detect_outliers_iqr` function is a robust, non-parametric anomaly detection tool that combines **Seasonal-Trend Decomposition (STL)** with **dynamic Interquartile Range (IQR)** estimation to identify relative outliers.

## 🔍 Functional Overview
the model evaluates the **Residual Proportion** rather than raw values. By measuring the percentage deviation from an expected baseline **(Trend + Seasonality)**, the model maintains consistent sensitivity across different volume scales. This prevents **high-volume noise** from triggering false positives while ensuring **low-volume drops** are still accurately captured.

## 🧠 Core Logic Stages

### 1.  Data Preparation and Validation
* **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
prevent statistically insignificant results.

* **Copying:** It creates a copy of the input group to ensure the original data remains unaltered during the calculation process.

### 2. Signal Extraction (STL)
Before statistical testing begins, the function uses **STL Decomposition** to break the time series into Trend, Seasonality, and Residual components.
* **Base Signal:** Calculated as `Trend + Seasonality`.
* **Residual Proportion:**  Calculated as `(Actual - Base)/Base`. This normalized metric is the primary input for the outlier detection.

### 3. Proportional Fencing
* **"Normal" Range:** The model identifies behavior based on the 25th `(Q1)` and 75th `(Q3)` percentiles of the historical Residual Proportion.

* **Tukey's Fences:** Boundaries are established using the standard IQR multiplier (typically 3.0 for extreme outliers):
    * `Lower_Proportion = Q1 - (3*IQR)`

    * `Upper_Proportion = Q3 + (3*IQR)`

* **Dynamic Adaptation:** The model utilizes a rolling window (typically 52 weeks) to recalculate the `Q1`, `Q3`, and `IQR` at every point in the time series. This ensures that the thresholds are always representative of the local volatility and recent historical context.

### 4. Reconstruction (Scale-Back)
The proportional boundaries are translated back into raw unit thresholds (e.g., Views):
* **Thresholds:** `Base x (1 + Proportion_bound)`.


## 📤 Key Output Columns
The function appends several analytical columns to the returned DataFrame:
* **`Q1` / `Q3` / `IQR`**: The proportional boundaries. Q1, Q3 are translated back into raw unit thresholds (e.g., Views).
* **`IQR_low` / `IQR_high`**: The calculated thresholds translated back into raw units.
* **`IQR_anomaly`**: A descriptive label (e.g., "High," "Low," or "Normal").
* **`is_IQR_anomaly`**:  Boolean flag indicating if the proportion exceeded the 3x IQR fences.

## 💡 Usage Context
The IQR method is highly effective for datasets where the noise distribution is **non-Gaussian** or contains heavy tails. By focusing on the **Residual Proportion**, it handles **Heteroscedasticity** naturally—ensuring that the "width" of the anomaly detection band is always proportional to the current volume of the time series.

---
## 📊 Evaluation Plot
The plot below demonstrates how the IQR model establishes proportional bounds around the STL-derived base signal:
"""


fb_msg = """
# 🚀 Facebook Prophet Walk-Forward Model
---

The `detect_time_series_anomalies_fb_walkforward` function is a sophisticated forecasting tool designed for **iterative anomaly detection**. It utilizes the Facebook Prophet library to perform a **walk-forward validation**, forecasting one data point at a time and expanding the training set as it progresses.

## 📋 Functional Overview
Unlike standard batch forecasting, this function operates by simulating a real-world scenario where the model is updated as soon as new data arrives. It establishes a **cutoff date** based on the specified `eval_period`, then iteratively predicts the next point, compares it to the observed value, and incorporates that value back into the training history.

## 🧠 Core Logic Stages

### 1. Data Preparation and Cutoff
* **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
prevent statistically insignificant results.
* **Standardization:** The input data is sorted by date and converted to **datetime objects** to ensure proper time-series alignment.
* **Partitioning:** The dataset is split into an **Initial Training Set** (all data before the cutoff) and an **Evaluation Set** (the rolling forecast window).

### 2. Walk-Forward Loop (Sequential Testing)
* **Model Fitting:** For every point in the evaluation set, a new **Prophet model** is initialized with weekly and yearly seasonality enabled.
* **One-Step Forecast:** The model generates a prediction (`yhat`) and an uncertainty interval (`yhat_lower`, `yhat_upper`) specifically for the **next single point**.
* **Dynamic Training Expansion:** After each prediction, the actual observed value is appended to the training data. This ensures the model learns from the most recent information before making the next prediction.
* **Robust Error Handling:** If the Prophet fit fails, the function falls back to a **baseline persistence model** (last observed value) to prevent pipeline failure.

### 3. Anomaly Classification
* **Uncertainty Bounds:** Anomalies are defined by the `prophet_CI` parameter. Any observation falling outside the predicted upper or lower bounds is flagged.
* **Residual Calculation:** The function computes the **FB_residual** (Actual - Forecast) to quantify the magnitude of deviations.

## 📤 Key Output Columns
The function appends the following columns to the returned DataFrame:
* **`FB_forecast`**: The point estimate predicted by Prophet for that date.
* **`FB_low` / `FB_high`**: The dynamic boundaries based on the specified uncertainty interval.
* **`FB_residual`**: The difference between the actual observed metric and the forecast.
* **`FB_anomaly`**: A categorical label designating the deviation as **"high"** or **"low"**.
* **`is_FB_anomaly`**: A boolean flag identifying outliers in the evaluation region.


## 💡 Usage Context
This approach is highly effective for metrics with **strong seasonality and complex trends**. Because it uses a walk-forward loop, it is significantly more accurate than a static forecast for long evaluation periods, as it corrects itself based on the most recent trends. It is ideal for detecting "sudden" shifts that standard statistical models (like Z-Score) might miss.

---
### 📊 Evaluation Strategy
This function strictly ignores the training region for anomaly reporting, ensuring that all reported anomalies are based on "out-of-sample" performance where the model had no prior knowledge of the specific data point being tested.

---
## 📊 Evaluation Plot
The plot below shows an example of how the FB Prophet model sets bounds and anomaly regions:
"""


dbscan_msg = """
# 🌀 DBSCAN Walk-Forward Anomaly Detection
---

The `detect_time_series_anomalies_dbscan` function implements a **density-based clustering** approach for time-series anomaly detection. It utilizes an **iterative walk-forward validation** strategy to identify data points that exist in "low-density" regions of the feature space.

## 📋 Functional Overview
This function transforms a univariate time series into a high-dimensional feature space using **dynamic lags** and **rolling statistics**. It then applies the **DBSCAN** (Density-Based Spatial Clustering of Applications with Noise) algorithm to distinguish between dense clusters of "normal" behavior and sparse "noise" points (anomalies).



## 🧠 Core Logic & Helper Utilities

### 1. Dynamic Feature Engineering (`get_dynamic_lags`)
Instead of using fixed lags, the function uses the **Autocorrelation Function (ACF)** to find the 10 most significant seasonal patterns in the data.
* **Baseline:** Always includes lags 1, 2, and 3 to capture immediate momentum.
* **Significance:** Uses a 75% confidence interval ($\\\\alpha=0.25$) to identify meaningful historical dependencies.

### 2. Automated Parameter Tuning (`find_optimal_epsilon`)
DBSCAN is highly sensitive to the **Epsilon ($\\\\epsilon$)** parameter (the neighborhood radius). 
* **Proxy Elbow Method:** The function automatically calculates $\\\\epsilon$ by analyzing the distance to the $k$-th nearest neighbor for all training points.
* **Density Threshold:** It sets $\\\\epsilon$ at the **95th percentile** of these distances, ensuring that 95% of training data is considered "dense" while the most isolated 5% are candidates for noise.

### 3. Walk-Forward Iteration
For each period in the `eval_period`:
* **Feature Construction:** Builds a matrix containing the variable, its dynamic lags, rolling means, rolling standard deviations, and a linear trend component.
* **Scaling:** Fits a `StandardScaler` **only on training data** to prevent data leakage.
* **Novelty Detection:** Since DBSCAN cannot "predict" on new points, the function uses a **Nearest Neighbors proxy**. If the distance from a new test point to its $k$-th neighbor in the training set is greater than the trained $\\\\epsilon$, it is flagged as an anomaly.

## 📤 Key Output Columns
* **`dbscan_score`**: The distance from the point to the $\\\\epsilon$ boundary (positive values indicate anomalies).
* **`is_DBSCAN_anomaly`**: A boolean flag identifying outliers.
* **Generated Features**: Includes all dynamic lags (`lagX`) and rolling statistics (`roll_mean_W`) used during the fit.

## 💡 Usage Context
DBSCAN is exceptionally powerful for detecting **contextual anomalies**—points that might look "normal" in value but are "weird" given their recent history or seasonal context. Because it is density-based, it can find anomalies in non-linear or multi-modal distributions where simple percentile or Z-score methods would fail.

---
### ⚠️ Performance Note
This model is computationally more intensive than statistical methods due to the iterative re-fitting of the `NearestNeighbors` and `DBSCAN` models. It is best suited for high-priority metrics where accuracy is more critical than processing speed.

---
## 📊 Evaluation Plot
The plot below shows an example of how the DBSCAN model flags anomalies:
"""


ewma_msg = """
# 📉 EWMA Rolling Anomaly Detection
---

The `ewma_with_anomalies_rolling_group` function implements a **statistically weighted** approach to identifying outliers. It uses an **Expanding Window** (Walk-Forward) strategy to adapt to recent trends while maintaining a memory of historical data.

## 📋 Functional Overview
This function calculates the **Exponentially Weighted Moving Average (EWMA)**, which assigns higher importance to recent observations. By combining this forecast with a dynamic standard deviation "envelope," the function identifies points that deviate significantly from the expected trend.

## 🧠 Core Logic Components

### 1. Forecast Engine (`ewma_forecast`)
* **Weighting Mechanism:** Uses an `alpha` parameter (between 0 and 1) to determine the "decay" of information. A **higher alpha** makes the model more sensitive to recent changes.
* **Calculation:** Employs the formula:
      EWMA_t = alpha x Y_t + (1 - alpha).EWMA_t-1

## 📤 Key Output Columns
The function returns a concatenated DataFrame containing:
* **`EWMA_forecast`**: The predicted value for that timestamp.
* **`STD`**: The standard deviation used to calculate the threshold.
* **`EWMA_high` / `EWMA_low`**: The dynamic boundaries (the "envelope") for the test period.
* **`is_EWMA_anomaly`**: A boolean flag indicating if the actual value fell outside the limits.

## 💡 Usage Context
EWMA is ideal for **streaming-style data** or metrics that exhibit **level shifts**. Because it weights recent data more heavily than a simple moving average, it is faster to adapt to new "normals" while still filtering out minor noise.

---
### ⚙️ Parameter Tuning
* **`alpha`**: Adjust this to control how quickly the model "forgets" old data (Typical range: `0.1 - 0.3`).
* **`sigma`**: Adjust this to control sensitivity. A **lower sigma** results in more anomalies, while a **higher sigma** (e.g., `3.0`) only flags extreme outliers.

---
## 📊 Evaluation Plot
The plot below shows an example of how the EWMA model sets bounds and anomaly regions:
"""


isofor_msg = """
# 🌲 Isolation Forest Time-Series Anomaly Detection
---

The `detect_time_series_anomalies_isoforest` function implements an **unsupervised machine learning** approach to outlier detection. Unlike traditional statistical models that define "normal" regions, this model explicitly identifies anomalies by **isolating** them in a high-dimensional feature space.

## 📋 Functional Overview
This function utilizes a **walk-forward validation** strategy. For every evaluation point, it dynamically engineers a unique feature set, fits a forest of decision trees, and determines if the current observation is an outlier based on how easily it can be isolated from historical data.



## 🧠 Core Logic & Helper Utilities

### 1. Dynamic Feature Engineering (`get_dynamic_lags`)
To capture the temporal structure of the data, the model doesn't just look at the raw value; it looks at the **context**.
* **Autocorrelation (ACF):** The function calculates the **10 most significant lags** based on the data's historical patterns.
* **Momentum:** It always includes lags 1, 2, and 3 to ensure immediate short-term trends are captured.
* **Rolling Statistics:** It automatically calculates **rolling means** and **standard deviations** at multiple scales (quarter-lag, half-lag, and full-lag intervals).

### 2. Isolation Forest Model Configuration
The model builds **200 trees** (`n_estimators`) to ensure a stable anomaly score.
* **Contamination:** A baseline assumption that **1%** of the data is inherently noisy.
* **Decision Function:** The model calculates an anomaly score where lower, more negative values indicate a higher likelihood of being an outlier.

### 3. Dual-Threshold Validation
To reduce "false positives," the function uses two layers of verification:
1.  **Contamination Anomaly:** The standard output from the sklearn model based on the 1% threshold.
2.  **Statistical Threshold:** A custom "safety" bound calculated as:
    > $$Mean(Positive Scores) - 3 \\times Std(Positive Scores)$$
**Result:** A point is only flagged as `True` if **both** the ML model and the statistical threshold agree it is an anomaly.

## 📤 Key Output Columns
* **`IsolationForest_timeseries_score`**: The decision score (anomaly score).
* **`is_IsolationForest_timeseries_anomaly`**: The final boolean flag for anomalies.
* **Engineered Features**: All `lagX`, `roll_meanX`, and `roll_stdX` columns created during the process.

## 💡 Usage Context
Isolation Forest is exceptionally powerful for **multi-dimensional anomalies**. Because it considers lags, rolling stats, and trend simultaneously, it can detect "subtle" anomalies where the value might look normal, but the **relationship** between the value and its recent history is broken.

---
### ⚙️ Implementation Strategy
The function handles the "test" points one-by-one in a loop. After each prediction, the training set expands to include the latest observed value, ensuring the forest is always aware of the most recent data trends before predicting the next point.

---
## 📊 Evaluation Plot
The plot below shows an example of how the Isolation Forest model flags anomalies:
"""


mad_msg = """
# 🛡️ MAD Anomaly Detection Model
---

**Robust Statistics Meets Time-Series Decomposition**

A robust measure of central tendency and spread for the residual proportion. MAD is less sensitive to extreme outliers than Standard Deviation, making it ideal for "dirty" time-series data. In the current model MAD (Median Absolute Deviation) is implemented on the **residuals proportion** of an STL (Seasonal-Trend decomposition using LOESS) process. By evaluating the percentage deviation relative to a dynamic base signal, the model isolates true "shocks" while remaining resilient to scale shifts between peak and off-peak seasons.

## 📋 Functional Overview

The function identifies anomalies by calculating the deviation of residuals from their median. It uses a Multiplicative Approach: first removing underlying trends and seasonal cycles to establish a `base_signal`, then calculating the ratio of the remaining noise.

## 🧠 Core Logic Stages

### 1.  Data Preparation and Validation
* **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
prevent statistically insignificant results.

* **Copying:** It creates a copy of the input group to ensure the original data remains unaltered during the calculation process.

### 2. Signal Extraction (STL)
Before statistical testing begins, the function uses **STL Decomposition** to break the time series into Trend, Seasonality, and Residual components.
* **Base Signal:** Calculated as `Trend + Seasonality`.
* **Residual Proportion:**  Calculated as `(Actual - Base)/Base`. This normalized metric is the primary input for the outlier detection.

### 3. Proportional Fencing
* **The MAD Formula:** It calculates the Median Absolute Deviation of the proportions: MAD = median(|p_i - median(p)|).

* **Scaling:**  It uses a `mad_scale_factor` (default 0.6745) to make the MAD comparable to a standard deviation for a normal distribution.

* **Proportional Bounds:** 

    * `Lower_Proportion = Median - (mad_threshold x MAD/mad_scale_factor)` 

    * `Upper_Proportion = Median + (mad_threshold x MAD/mad_scale_factor)` 


### 4. Expanding Window & Reconstruction
* **Dynamic Adaptation:** The model utilizes a rolling window (typically 52 weeks) to recalculate the `Median` and `MAD` at every point in the time series. This ensures that the thresholds are always representative of the local volatility and recent historical context.

* **Scale-Back:** The proportional bounds are projected back to raw units:
    * **Thresholds:** `Base x (1 + Proportion_bound)`.

## 📤 Key Output Columns
The function appends several analytical columns to the returned DataFrame:
* **`Median / MAD`**: Robust central tendency and spread of the residual proportions. Median is translated back into raw unit thresholds (e.g., Views).
* **`MAD_low / MAD_high`**: Thresholds translated back into raw units (e.g., Views).
* **`MAD_anomaly`**: A descriptive label (e.g., "High," "Low," or "Normal").
* **`is_MAD_anomaly`**:  Boolean flag indicating a robust statistical outlier.


## 💡 Usage Context

The MAD model is the "gold standard" for univariate outlier detection. It is highly recommended for:

- Data with extreme spikes that would skew Mean-based (SD) models.
- Non-normally distributed datasets.
- Scenarios requiring scale-invariant detection across high and low-volume groups.
---
## 📊 Evaluation Plot
The plot below demonstrates how the MAD model establishes proportional bounds around the STL-derived base signal:
"""


sd_msg = """

# 📈 Standard-Deviation–Based Outlier Detection (Expanding Window)

This function detects anomalies using a Mean ± N Standard Deviation rule applied to the **Residual Proportion** of an STL-decomposed time series.


## 📋 Functional Overview

the model evaluates the percentage deviation relative to the expected baseline (Trend + Seasonality). This ensures that the "width" of the detection band scales automatically with the volume of the data, effectively handling **Heteroscedasticity**.

## 🧠 Core Logic Stages

### 1.  Data Preparation and Validation
* **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
prevent statistically insignificant results.

* **Copying:** It creates a copy of the input group to ensure the original data remains unaltered during the calculation process.

### 2. Signal Extraction (STL)
Before statistical testing begins, the function uses **STL Decomposition** to break the time series into Trend, Seasonality, and Residual components.
* **Base Signal:** Calculated as `Trend + Seasonality`.
* **Residual Proportion:**  Calculated as `(Actual - Base)/Base`. This normalized metric is the primary input for the outlier detection.

### 3. Rolling Window Thresholding
* **Continuous Calculation:** The model utilizes a **rolling window** (typically 52 weeks) to calculate the Mean and Standard Deviation of the Residual Proportions at every point in the time series.

* **Dynamic Bounds:**  It establishes proportional bounds: Mean+-(N x SD) based on the historical distribution of noise within the window.

* **Adaptive Nature:** By recalculating at each step, the model continuously adapts to shifts in volatility and baseline noise throughout the entire series, rather than relying on a static training set.

### 4. Reconstruction

* **Scale-Back:** The proportional bounds are projected back to raw units:
    * **Thresholds:** `Base x (1 + Proportion_bound)`.

## 📤 Key Output Columns
The function appends several analytical columns to the returned DataFrame:
* **`Mean / SD:`**: Calculated on the residual proportions. Mean is translated back into raw unit thresholds for reporting(e.g., Views).
* **`SD_low / SD_high`**: Thresholds translated back into raw units (e.g., Views).
* **`SD_anomaly`**: A descriptive label (e.g., "High," "Low," or "Normal").
* **`is_SD_anomaly`**:  Boolean flag indicating the proportion exceeded the N-SD limit.


## 💡 Usage Context

The Standard Deviation model is ideal for identifying anomalies in data that follows a relatively Normal (Gaussian) distribution of noise. By applying it to the Residual Proportion, this model becomes particularly powerful for:

- Scale-Invariant Detection: Detecting a 10% drop in traffic regardless of whether the baseline is 1,000 or 1,000,000.

- Heteroscedastic Data: Handling time series where the variance naturally expands during peak periods and contracts during off-peaks.

- Predictable Volatility: Best used when the historical noise profile is stable enough that a "multiple of standard deviation" remains a meaningful threshold for the business.
---
## 📊 Evaluation Plot
The plot below demonstrates how the SD model establishes proportional bounds around the STL-derived base signal:
"""

imputation_msg = """
### 🧩 Missing Data Imputation Options

**median** (default)  
*Fills missing values with the median of the available data.*  
Use when the data contains outliers and robustness matters.

**linear**  
*Imputes missing values by drawing a straight line between neighboring points.*  
Use when the data changes smoothly over time and gaps are small.

**mean**  
*Replaces missing values with the average of the available data.*  
Use when the data is roughly symmetric with few extreme values.

**mode**  
*Fills missing values with the most frequent value.*  
Use for categorical data or discrete signals with a dominant value.

**zero**  
*Fills missing values with zero.*  
Use when zero has real semantic meaning (e.g., no activity or demand).
"""

anomaly_final_msg = """
# 📘 Final Results Data Dictionary

### **Overview**
This dataset contains the results of a robust anomaly detection pipeline that utilizes Statistical Methods,<br>
Time-Series Forecasting, and Machine Learning algorithms. It is the primary dataset for evaluation,<br>
visualization, and investigation of anomalous behavior over time.<br>

---

### **Column Definitions of Added Columns**

| Column Name | Description |
| :--- | :--- |
| **`is_missing_record`** | `True` if the original data point was missing and imputed; `False` otherwise. |
| **`Percentile_low`** | Lower bound of percentiles method. |
| **`Percentile_high`** | Upper bound percentiles method. |
| **`Percentile_anomaly`** | Classification of anomaly status by the Percentile model ('low', 'high', 'none'). |
| **`is_Percentile_anomaly`** | Boolean flag indicating if the Percentile model detected an anomaly. |
| **`Mean`** | The rolling average of the residual proportion. Scaled back to raw units for reporting. |
| **`SD`** | rolling Standard Deviation of residual proportion. |
| **`SD_low`** | Lower bound calculated as Mean(prior to scaling back) - SD_threshold*σ. |
| **`SD_high`** | Upper bound calculated as Mean(prior to scaling back) + SD_threshold*σ. |
| **`SD_anomaly`** | Classification of anomaly status by the Standard Deviation model. |
| **`is_SD_anomaly`** | Boolean flag indicating if the SD model detected an anomaly. |
| **`Median`** |  Rolling Median of the residual proportion. Scaled back to raw units for reportin. |
| **`MAD`** | Median Absolute Deviation of residual proportion at each data point from median (prior to scaling back). |
| **`MAD_low`** | Lower bound calculated using Median - MAD threshold. |
| **`MAD_high`** | Upper bound calculated using Median + MAD threshold. |
| **`MAD_anomaly`** | Classification of anomaly status by the MAD model. |
| **`is_MAD_anomaly`** | Boolean flag indicating if the MAD model detected an anomaly. |
| **`Q1`** | The rolling 25th percentile (First Quartile) of residual proportion. Scaled back to raw units for reporting |
| **`Q3`** | The rolling 75th percentile (Third Quartile) of residual proportion. Scaled back to raw units for reporting. |
| **`IQR`** | Interquartile Range (Q3 - Q1) of residual proportion prior to scaling back. |
| **`IQR_low`** | Lower bound calculated as Q1 (prior to scaling back) - IQR_threshold * IQR. Scaled back to raw units |
| **`IQR_high`** | Upper bound calculated as Q3 (prior to scaling back) + IQR_threshold * IQR. Scaled back to raw units |
| **`IQR_anomaly`** | Classification of anomaly status by the IQR model. |
| **`is_IQR_anomaly`** | Boolean flag indicating if the IQR model detected an anomaly. |
| **`EWMA_forecast`** | Predicted value generated by the Exponentially Weighted Moving Average model. |
| **`STD`** | Standard deviation of the residuals used in EWMA bounds. |
| **`EWMA_high`** | Upper bound for the EWMA forecast. |
| **`EWMA_low`** | Lower bound for the EWMA forecast. |
| **`EWMA_residual`** | The difference between the actual value and the EWMA forecast. |
| **`EWMA_anomaly`** | Classification of anomaly status by the EWMA model. |
| **`is_EWMA_anomaly`** | Boolean flag indicating if the EWMA model detected an anomaly. |
| **`FB_forecast`** | Predicted value generated by the Facebook Prophet model. |
| **`FB_low`** | Lower uncertainty interval bound from Prophet. |
| **`FB_high`** | Upper uncertainty interval bound from Prophet. |
| **`FB_residual`** | The difference between the actual value and the Prophet forecast. |
| **`FB_anomaly`** | Classification of anomaly status by the Prophet model. |
| **`is_FB_anomaly`** | Boolean flag indicating if the Prophet model detected an anomaly. |
| **`IsolationForest_score`** | Raw anomaly score from the Isolation Forest algorithm (lower is more anomalous). |
| **`IsolationForest_score_low`** | Threshold used to identify anomalies in Isolation Forest. |
| **`IsolationForest_anomaly`** | Classification of anomaly status by Isolation Forest. |
| **`is_IsolationForest_anomaly`** | Boolean flag indicating if Isolation Forest detected an anomaly. |
| **`DBSCAN_score`** | Distance/density score from the DBSCAN algorithm. |
| **`DBSCAN_score_high`** | Threshold used to identify anomalies in DBSCAN. |
| **`DBSCAN_anomaly`** | Classification of anomaly status by DBSCAN. |
| **`is_DBSCAN_anomaly`** | Boolean flag indicating if DBSCAN detected an anomaly. |
| **`Anomaly_Votes`** | The count of individual models that flagged the record as an anomaly. |
| **`Vote_Cnt`** | The total number of models available/run for this record. |
| **`Anomaly_Votes_Display`** | Readable string format of the vote (e.g., `"2 out of 7"`). |
| **`is_conflict`** | A boolean flag indicating a directional disagreement within the ensemble. |
| **`consensus_type`** | Indicates the prevailing direction of the anomaly based on the net sum of model votes. |
| **`max_threshold`** | The upper boundary used for data cleansing. |
| **`min_threshold`** | The lower boundary used for data cleansing. |
| **`raw_total_views_cleansed`** | The final "corrected" version of the input variable. |
| **`Percentile_score_scaled`** | Normalized severity score (0-100) for the Percentile model. |
| **`SD_score_scaled`** | Normalized severity score (0-100) for the SD model. |
| **`MAD_score_scaled`** | Normalized severity score (0-100) for the MAD model. |
| **`IQR_score_scaled`** | Normalized severity score (0-100) for the IQR model. |
| **`EWMA_score_scaled`** | Normalized severity score (0-100) for the EWMA model. |
| **`FB_score_scaled`** | Normalized severity score (0-100) for the Prophet model. |
| **`IsolationForest_score_scaled`** | Normalized severity score (0-100) for Isolation Forest. |
| **`DBSCAN_score_scaled`** | Normalized severity score (0-100) for DBSCAN. |
| **`Anomaly_Score`** | **Final Ensemble Score (0-100)**. A weighted aggregation of all model outputs. |
| **`anom_score_cat`** | **Severity Category**: `Normal`, `Suspect`, `Anomaly`, or `Critical`. |
| **`is_Anomaly`** | **Final Decision**. `True` if the ensemble score exceeds the threshold; `False` otherwise. |
"""