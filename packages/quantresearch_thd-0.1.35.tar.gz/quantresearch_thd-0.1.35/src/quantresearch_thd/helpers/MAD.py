import pandas as pd
import numpy as np
from .Preprocessing import classify, get_optimal_window



def detect_outliers_mad(group, variable, date_column, mad_threshold, mad_scale_factor, eval_period,magnitude_threshold):
    """
    # 🛡️ MAD Anomaly Detection Model
    ---

    **Robust Statistics Meets Time-Series Decomposition**

    The current implementation of the MAD (Median Absolute Deviation) model operates on the residuals of an STL (Seasonal-Trend decomposition using LOESS) process. By evaluating the percentage deviation relative to a dynamic base signal, the model isolates true "shocks" while remaining resilient to scale shifts between peak and off-peak seasons.

    ## 📋 Functional Overview

    The function identifies anomalies by calculating the deviation of residuals from their median. It uses a Multiplicative Approach: first removing underlying trends and seasonal cycles to establish a `base_signal`, then calculating the ratio of the remaining noise.

    ## 🧠 Core Logic Stages

    ### 1.  Data Preparation and Validation
    * **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
    prevent statistically insignificant results.

    * **Copying:** It creates a copy of the input group to ensure the original data remains unaltered during the calculation process.

    ### 2. Signal Extraction (STL)
    Before statistical testing begins, the function uses **STL Decomposition** to break the time series into Trend, Seasonality, and Residual components.
    * **Base Signal:** Calculated as `Trend + Seasonality`.
    * **Residual Proportion:**  Calculated as `(Actual - Base)/Base`. This normalized metric is the primary input for the outlier detection.

    ### 3. Proportional Fencing
    * **The MAD Formula:** It calculates the Median Absolute Deviation of the proportions: MAD = median(|p_i - median(p)|).

    * **Scaling:**  It uses a `mad_scale_factor` (default 0.6745) to make the MAD comparable to a standard deviation for a normal distribution.

    * **Proportional Bounds:** 

        * `Lower_Proportion = Median - (Threshold x MAD/Scale})` 

        * `Upper_Proportion = Q3 + (3*IQR)`


    ### 4. Expanding Window & Reconstruction
    * **Dynamic Adaptation:** The model utilizes a rolling window (typically 52 weeks) to recalculate the `Median` and `MAD` at every point in the time series. This ensures that the thresholds are always representative of the local volatility and recent historical context.

    * **Scale-Back:** The proportional bounds are projected back to raw units:
        * **Thresholds:** `Base x (1 + Proportion_bound)`.

    ## 📤 Key Output Columns
    The function appends several analytical columns to the returned DataFrame:
    * **`Median / MAD`**: Robust central tendency and spread of the residual proportions. Median is translated back into raw unit thresholds (e.g., Views).
    * **`MAD_low / MAD_high`**: Thresholds translated back into raw units (e.g., Views).
    * **`MAD_anomaly`**: A descriptive label (e.g., "High," "Low," or "Normal").
    * **`is_MAD_anomaly`**:  Boolean flag indicating a robust statistical outlier.


    ## 💡 Usage Context

    The MAD model is the "gold standard" for univariate outlier detection. It is highly recommended for:

    - Data with extreme spikes that would skew Mean-based (SD) models.
    - Non-normally distributed datasets.
    - Scenarios requiring scale-invariant detection across high and low-volume groups.
    ---
    """
    n = len(group)
    if n < 10:
        return pd.DataFrame(columns=group.columns)

    group = group.copy().sort_values(date_column)
    group[date_column] = pd.to_datetime(group[date_column])
    
    # 1. Determine Window Size
    window_size = get_optimal_window(group, date_column)
    train_size = n - eval_period

    # 2. Initialize Original Columns
    cols_to_init = ['Median', 'MAD', 'MAD_low', 'MAD_high', 'set', 'MAD_anomaly']
    for col in cols_to_init:
        group[col] = None
    group['is_MAD_anomaly'] = False

    vals = group[variable].values
    base_signals = group['base_signal'].values
    residuals= group['residual'].values
   

    # 3. Process with Sliding/Adaptive Window
    for i in range(n):
        current_set = "TRAIN" if i < train_size else "TEST"
        
        start_idx = max(0, i - window_size)
        window_data = vals[start_idx:i]
        
        if len(window_data) == 0:
            window_data = vals[0:1]

        # --- CORE MAD MATH ---
        curr_median = np.nanmedian(window_data)
        raw_mad = np.nanmedian(np.abs(window_data - curr_median))
        
        # --- NEW: MINIMUM NOISE FLOOR ---
        # We calculate a floor based on the absolute average level of the window.
        # This prevents the threshold from collapsing to near-zero.
        # 0.05 (5%) is a standard starting point for business residuals.
        noise_floor = np.abs(np.nanmean(window_data)) * 0.1
        effective_mad = max(raw_mad, noise_floor)
        
        # Avoid division by zero
        if effective_mad == 0:
            lower_mad = curr_median
            upper_mad = curr_median
        else:
            # Use effective_mad (which includes the floor) for the margin
            margin = (mad_threshold * effective_mad) / mad_scale_factor
            lower_mad = curr_median - margin
            upper_mad = curr_median + margin
            
        current_val = vals[i]
        current_base = base_signals[i]
        current_res = residuals[i]
        
         # --- CONTEXTUAL ANOMALY LOGIC ---
        # Statistical check: Breach of bands
        is_statistical_anomaly = (current_val < lower_mad) or (current_val > upper_mad)
        
        # Contextual check: Is the deviation > 30% of the baseline?
        is_contextual_anomaly = False
        if current_base > 0:
            is_contextual_anomaly = (abs(current_res) / current_base) > magnitude_threshold #
            
        # Final flag: Both must be true
        is_final_anomaly = is_statistical_anomaly and is_contextual_anomaly

        # Populate columns
        group.iloc[i, group.columns.get_loc('Median')] = curr_median
        group.iloc[i, group.columns.get_loc('MAD')] = raw_mad  # Store raw MAD for visibility
        group.iloc[i, group.columns.get_loc('MAD_low')] = lower_mad
        group.iloc[i, group.columns.get_loc('MAD_high')] = upper_mad
        group.iloc[i, group.columns.get_loc('set')] = current_set
        group.iloc[i, group.columns.get_loc('MAD_anomaly')] = classify(current_val, lower_mad, upper_mad) if is_final_anomaly else "none"
        group.iloc[i, group.columns.get_loc('is_MAD_anomaly')] = is_final_anomaly

    group['is_MAD_anomaly'] = group['is_MAD_anomaly'].astype(bool)
    group[date_column] = pd.to_datetime(group[date_column])
    
    return group