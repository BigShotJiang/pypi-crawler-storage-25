import pandas as pd
import numpy as np
import re
from datetime import datetime
from statsmodels.tsa.stattools import acf
from statsmodels.tsa.seasonal import STL
from .percentile import detect_outliers_percentile
from .STD import detect_outliers_sd
from .MAD import detect_outliers_mad
from .IQR import detect_outliers_iqr
from .iso_forest_general import detect_outliers_isf_general
from .ewma import ewma_with_anomalies_rolling_group
from .fb_prophet import detect_time_series_anomalies_fb_walkforward
from .iso_forest_timeseries import detect_time_series_anomalies_isoforest
from .DB_scan import detect_time_series_anomalies_dbscan

from IPython.display import display, Markdown

def get_stl_period(freq):
    """Determines the seasonal period for STL based on frequency string."""
    if not isinstance(freq, str): return 7
    f = freq.upper()
    if f.startswith('D'): return 7
    if f.startswith('W'): return 4
    if f.startswith('M'): return 12
    return 7

def process_stats_group(group, variable, date_column, eval_period, freq, percentile_threshold,
                        SD_threshold, mad_threshold, mad_scale_factor, IQR_threshold, magnitude_threshold):
    """
    Parallel worker: Decomposes group, calculates residual proportions, 
    runs 4 models on proportions, and reconstructs original scale.
    """
    group = group.copy().sort_values(date_column)
    
    # 1. STL Decomposition on TRAIN only
    train_size = len(group) - eval_period
    train_data = group.iloc[:train_size]
    period = get_stl_period(freq)
    stl = STL(train_data[variable], period=period, robust=True).fit()
    
    # Extract components (Trend logic per your previous implementation)
    train_trend = train_data[variable].rolling(window=period, center=False, min_periods=1).median()
    train_seasonal = stl.seasonal
    
    # 2. Project for EVAL period (Avoid Leakage)
    seasonal_cycle = train_seasonal.iloc[-period:].values
    eval_seasonal = np.tile(seasonal_cycle, int(np.ceil(eval_period/period)))[:eval_period]
    eval_trend = np.full(eval_period, train_trend.iloc[-1])
    
    # 3. Base Signal Calculation
    group['base_signal'] = np.concatenate([train_trend + train_seasonal, 
                                           eval_trend + eval_seasonal])
    
    # 4. CALCULATE PROPORTION OF RESIDUALS
    group['residual'] = group[variable] - group['base_signal']
    # Use replace(0, np.nan) to avoid division by zero errors
    group['residual_proportion'] = group['residual'] / group['base_signal'].replace(0, np.nan)
    # Fill remaining NaNs (where both residual and base are 0) with 0
    group['residual_proportion'] = group['residual_proportion'].fillna(0)

    # 5. Run Models on Proportions
    # NOTE: These models now detect outliers in the '% deviation' distribution
    res_p = detect_outliers_percentile(group, 'residual_proportion', date_column, eval_period, percentile_threshold)
    res_s = detect_outliers_sd(group, 'residual_proportion', date_column, eval_period, SD_threshold, magnitude_threshold)
    res_m = detect_outliers_mad(group, 'residual_proportion', date_column, mad_threshold, mad_scale_factor, eval_period, magnitude_threshold)
    res_i = detect_outliers_iqr(group, 'residual_proportion', date_column, eval_period, IQR_threshold, magnitude_threshold)

    # 6. Multiplicative Scale Reconstruction
    for res_df in [res_p, res_s, res_m, res_i]:
        res_df['base_signal'] = group['base_signal'].values
        res_df['residual'] = group['residual'].values
        
        # Identify columns to scale (bounds and statistics)
        cols = [c for c in res_df.columns if any(w in c for w in ['low', 'high', 'Mean', 'Median','Q1', 'Q3'])]
        
        # Back to original scale: val_original = base_signal * (1 + proportion_val)
        for col in cols:
            res_df[col] = res_df['base_signal'] * (1 + res_df[col])
            
        # Apply zero-floor safety
        low_cols = [c for c in cols if 'low' in c]
        res_df[low_cols] = res_df[low_cols].clip(lower=0)
        high_cols = [c for c in cols if 'high' in c]
        res_df[high_cols] = res_df[high_cols].clip(lower=0)

    return (res_p, res_s, res_m, res_i)

def process_group(model, name, group, unique_ids, variable,
                  date_column, alpha, sigma, eval_period, prophet_CI, contamination,sensitivity, random_state):

    if model == "ISF_general":
        return detect_outliers_isf_general(group, variable, contamination, random_state, eval_period)

    if model == "EWMA":
        return ewma_with_anomalies_rolling_group(
            group, unique_ids, variable, date_column, alpha, sigma, eval_period
        )

    if model == "FB":
        return detect_time_series_anomalies_fb_walkforward(
            group, variable, date_column, eval_period, prophet_CI
        )
    
    if model == 'ISF_timeseries':
        return detect_time_series_anomalies_isoforest(
            group, variable, date_column, eval_period
        )
    
    if model == 'DBSCAN':
        return detect_time_series_anomalies_dbscan(
            group, variable, date_column, eval_period, sensitivity
        )


import re

class Colors:

    BLUE = '\033[94m'

    RED = '\033[91m'

    END = '\033[0m'

    BOLD = '\033[1m'

    BOLD_ITALIC = "\033[1;3m"

    RESET = "\033[0m"
    
    BG_WHITE = '\033[47m'
    
    BLACK = '\033[30m'
    
    GREEN = '\033[92m'
    
    YELLOW = '\033[93m'
    
    CYAN = '\033[36m'
    
    BOX = '\033[48;5;243m\033[38;5;255m'
    
    
#  PRINTING UTILITIES ---

def print_header(title, color=Colors.BLUE):
    """
    Prints a centered, bold header. 
    Borders are always Blue, but the Title color is configurable (default Red).
    """
    width = 70
    border = "=" * width
    
    # Border is blue
    print(f"\n{Colors.BLUE}{Colors.BOLD}{border}")
    
    # Title uses the passed 'color' parameter (e.g., Red)
    print(f"{color}{title:^{width}}")
    
    # Border is blue
    print(f"{Colors.BLUE}{border}{Colors.END}")
    
def print_success_message(final_results,unique_ids, is_assigned):
    
    # Calculate unique groups actually evaluated in final_results
    evaluated_groups = final_results.groupby(unique_ids).ngroups
    
    # Success Message
    print("-" * 70)
    print(f"{Colors.BOLD}{Colors.GREEN}✔ Anomaly detection pipeline successfully ran for {evaluated_groups:,} unique_ids.{Colors.END}")
    
    # Logic for auto-saving notification
    if not is_assigned:
        print(f"{Colors.YELLOW}📀 NOTE: Since variables are not assigned from the user,{Colors.END}")
        print(f"{Colors.YELLOW}the following dataframes were generated as part of the output:{Colors.END}")
        print(f" {Colors.BOX} final_results {Colors.END}     : dataframe containing the evaluation of each record")
        print(f" {Colors.BOX} evaluation_report {Colors.END} : contains aggregate metrics for each unique_id")
    
    print("-" * 70)
    
    
def anomaly_summary_chart(df, evaluation_report, unique_ids):
    
    print_header("ANOMALY DETECTION EXECUTIVE SUMMARY", Colors.GREEN)
      # --- 1. Data health Report
    total_groups = len(evaluation_report)
    
    # Calculate unique groups actually evaluated in final_results
    evaluated_groups = df.groupby(unique_ids).ngroups
    Evaluated_records = len(df)
    total_anomalies = df['is_Anomaly'].fillna(False).astype(bool).sum()
    anomaly_rate = (total_anomalies / Evaluated_records) * 100 if Evaluated_records > 0 else 0
    
    # Helper formatters
    def print_stats_rows(stats):
        label_width = 45
        value_width = 22
        for label, val in stats:
            # Strip ANSI colors for padding calculation
            visible_val = re.sub(r'\033\[[0-9;]*m', '', str(val))
            padding = " " * (value_width - len(visible_val))
            print(f"{label:<{label_width}} : {padding}{val}")

    # --- 3. EXECUTION SUMMARY ---
   
    exec_stats = [
        ["Evaluated Unique IDs", f"{evaluated_groups:,}"],
        ["Evaluated Records", f"{Evaluated_records:,}"],
        ["Detected Anomalies", f"{Colors.RED}{total_anomalies:,}{Colors.END}"],
        ["Anomaly Rate", f"{Colors.RED}{anomaly_rate:.1f}%{Colors.END}"]
    ]

    exec_stats = print_stats_rows(exec_stats)
    
    # Using Cyan for the footer line as discussed earlier
    print(f"{Colors.BLUE}{'='*70}{Colors.END}\n")
    
def rank_anomaly_impact(anomaly_final, unique_ids, variable, eval_period):
    """
    Ranks groups based on a normalized impact metric: 
    (Normalized Volume * Anomaly Status * Anomaly Score).
    
    Returns:
        pd.DataFrame: Top 5 groups by 'interest_score'.
    """
    
    # 1. Filter for the evaluation window
    # We take the last 'eval_period' rows for each unique_id group
    eval_only_df = anomaly_final.groupby(unique_ids).tail(eval_period).copy()

    # 2. Normalize the variable (Volume) to a 0-1 scale across all groups
    v_min = eval_only_df[variable].min()
    v_max = eval_only_df[variable].max()
    
    # Avoid division by zero if all values are identical
    denominator = (v_max - v_min) if (v_max - v_min) != 0 else 1e-9
    eval_only_df['norm_variable'] = (eval_only_df[variable] - v_min) / denominator

    # 3. Calculate Impact Metric
    # Formula: Normalized Volume * Binary Anomaly * Magnitude of Anomaly Score
    eval_only_df['impact_metric'] = (
        eval_only_df['norm_variable'] * eval_only_df['is_Anomaly'].astype(int) * eval_only_df['Anomaly_Score']
    )

    # 4. Aggregate metrics for ranking
    top_groups = eval_only_df.groupby(unique_ids).agg({
        'impact_metric': 'mean',
        'is_Anomaly': ['mean', 'sum']
    }).reset_index()

    # 5. Flatten the multi-index columns from the agg result
    top_groups.columns = [
        '_'.join(col).strip('_') if isinstance(col, tuple) else col 
        for col in top_groups.columns.values
    ]
    
    # Filter: Only keep groups that had at least one actual anomaly in the eval period
    top_groups = top_groups[top_groups['is_Anomaly_sum'] > 0]

    # 6. Rename and Sort
    # Renaming 'is_Anomaly_mean' to 'mean' satisfies downstream plotting helpers
    top_5_ranked = (
        top_groups.rename(columns={
            'impact_metric_mean': 'interest_score',
            'is_Anomaly_mean': 'mean',
            'is_Anomaly_sum': 'sum'
        })
        .sort_values('interest_score', ascending=False)
        .head(5)
    )

    return top_5_ranked


def top_anomaly_stats(top_5_groups, unique_ids):
    """Prints stats for the top 5 groups based on the calculated Impact Metric."""
    if top_5_groups.empty:
        print(f"{Colors.YELLOW}No data available for anomaly stats.{Colors.END}")
        return

    title = f"TOP 5 unique_ids with high ANOMALY RATE during evaluation period ({' | '.join(unique_ids)}):"
    print_header(title)

    for _, row in top_5_groups.iterrows():
        # Reconstruct the label from unique_ids columns
        if len(unique_ids) > 1:
            group_label = " | ".join([str(row[col]) for col in unique_ids])
        else:
            group_label = str(row[unique_ids[0]])

        # Formatting values
        # rate_val is the percentage of records in the eval_period that were anomalous
        rate_val = row['mean'] * 100 
        impact_val = row['interest_score']
        
        rate_str = f"{Colors.RED}{rate_val:.1f}%{Colors.END}"
        count_str = f"({Colors.RED}{int(row['sum'])}{Colors.END} anomalies)"
        impact_str = f"Impact Score: {Colors.CYAN}{impact_val:.2f}{Colors.END}"
        
        print(f" - {group_label:} :{impact_str} | Rate: {rate_str} {count_str}")
        


def display_help_code_block(top_5_anomaly_groups, unique_ids, variable, date_column, eval_period):
    """
    Generates and displays an HTML/Markdown block containing a pre-formatted 
    code snippet for investigating the top anomalous ID.
    """
    if top_5_anomaly_groups.empty:
        return
    
    # 1. Build the human-readable description (e.g., `Region` = 'East' and `Store` = '12')
    # We pull the first row of the top 5 as the example
    top_row = top_5_anomaly_groups[unique_ids].head(1).iloc[0]
    
    uid_example_list = []
    id_values = []
    
    for col in unique_ids:
        val = top_row[col]
        id_values.append(val)
        uid_example_list.append(f"`{col}` = '{val}'")
        
    uid_example_str = " and ".join(uid_example_list)

    # 2. Define the Python code template to be displayed
    code_content = f"""id_values = {id_values}
mask = final_results[unique_ids].eq(id_values).all(axis=1)
group_df = final_results[mask]

evaluation_info(
    group_df,
    unique_ids,
    variable,
    date_column,
    eval_period)"""

    # 3. Wrap code in a styled HTML box for better UI in Jupyter
    code_block_html = f"""
<div style="background-color: ghostwhite; padding: 15px; border: 1px solid #d1d1d1; border-radius: 8px; width: fit-content;">
<pre style="background-color: ghostwhite; margin: 0; font-family: 'Cascadia Code', 'Courier New', monospace; white-space: pre;">{code_content}</pre>
</div>
"""

    # 4. Final Markdown Assembly
    help_info = f"""
---
You can generate detailed plots of individual anomaly detection models per `unique_id`.
If your anomaly detection table is `final_results`, and you want to investigate the group where {uid_example_str}, copy and paste this block into a new cell:

{code_block_html}
---
"""
    display(Markdown(help_info))
    
    
## HTML tables

def get_anomaly_summary_html(final_results, evaluation_report, unique_ids):
    # Calculate Metrics
    evaluated_groups = final_results.groupby(unique_ids).ngroups
    evaluated_records = len(final_results)
    total_anomalies = final_results['is_Anomaly'].fillna(False).astype(bool).sum()
    anomaly_rate = (total_anomalies / evaluated_records) * 100 if evaluated_records > 0 else 0

    # Build the HTML Table
    # Using 'white-space: pre' and specific padding to force character alignment
    html_table = f"""
    <div style="font-family: 'Courier New', Courier, monospace; background-color: #ffffff; padding: 20px; width: 700px; color: #000;">
        <table style="width: 100%; border-collapse: collapse; table-layout: fixed; border: none;">
            
            <tr>
                <td colspan="3" style="color: #0056b3; font-size: 14px; padding: 0 0 5px 40px; white-space: nowrap; letter-spacing: 0;">
                    {"="*80}
                </td>
            </tr>
            
            <tr>
                <td colspan="3" style="text-align: center; font-weight: bold; color: #28a745; font-size: 16px; padding: 10px 0;">
                    ANOMALY DETECTION EXECUTIVE SUMMARY
                </td>
            </tr>
            
            <tr>
                <td colspan="3" style="color: #0056b3; font-size: 14px; padding: 0 0 15px 40px; white-space: nowrap; letter-spacing: 0;">
                    {"="*80}
                </td>
            </tr>
            
            <tr style="height: 30px;">
                <td style="width: 40%; text-align: left; padding-left: 40px; font-size: 15px;">Evaluated Unique IDs</td>
                <td style="width: 10%; text-align: center; font-size: 15px;">:</td>
                <td style="width: 50%; text-align: right; padding-right: 60px; font-size: 15px;">{evaluated_groups:,}</td>
            </tr>
            <tr style="height: 30px;">
                <td style="text-align: left; padding-left: 40px; font-size: 15px;">Evaluated Records</td>
                <td style="text-align: center; font-size: 15px;">:</td>
                <td style="text-align: right; padding-right: 60px; font-size: 15px;">{evaluated_records:,}</td>
            </tr>
            <tr style="height: 30px;">
                <td style="text-align: left; padding-left: 40px; font-size: 15px;">Detected Anomalies</td>
                <td style="text-align: center; font-size: 15px;">:</td>
                <td style="text-align: right; padding-right: 60px; font-size: 15px; color: #b22222; font-weight: bold;">{total_anomalies:,}</td>
            </tr>
            <tr style="height: 30px;">
                <td style="text-align: left; padding-left: 40px; font-size: 15px;">Anomaly Rate</td>
                <td style="text-align: center; font-size: 15px;">:</td>
                <td style="text-align: right; padding-right: 60px; font-size: 15px; color: #b22222; font-weight: bold;">{anomaly_rate:.1f}%</td>
            </tr>
            
            <tr>
                <td colspan="3" style="color: #0056b3; font-size: 14px; padding: 15px 0 0 40px; white-space: nowrap; letter-spacing: 0;">
                    {"="*80}
                </td>
            </tr>
        </table>
    </div>
    """
    return html_table


def get_top_anomaly_stats_html(top_5_groups, unique_ids):
    if top_5_groups.empty:
        return "<div style='color: orange;'>No data available for anomaly stats.</div>"

    title = "TOP 5 unique_ids with high ANOMALY RATE during evaluation period"
    
    LEFT_PAD = "15px"
    # We use a large container but let the table define the column widths
    CONTAINER_WIDTH = "1000px" 
    
    # Adjusted line length
    EQUALS_LINE = "=" * 130 
    blue_line_style = f"color: #0056b3; font-size: 14px; padding-left: {LEFT_PAD}; white-space: nowrap;"

    html_output = f"""
    <div style="font-family: 'Courier New', Courier, monospace; background-color: #ffffff; padding: 20px; width: {CONTAINER_WIDTH}; color: #000;">
        
        <table style="border-collapse: collapse; border: none; margin: 0; width: auto;">
            
            <tr>
                <td colspan="5" style="{blue_line_style} padding-bottom: 5px;">
                    {EQUALS_LINE}
                </td>
            </tr>
            
            <tr>
                <td colspan="5" style="color: #0056b3; font-weight: bold; font-size: 16px; padding: 15px 0; text-align: center;">
                    {title}
                </td>
            </tr>

            <tr style="font-weight: bold; color: #000; background-color: #f8f9fa;">
                <td style="width: 1%; padding: 12px 20px 12px {LEFT_PAD}; text-align: left; white-space: nowrap;">UNIQUE_ID</td>
                <td style="width: 20px; text-align: center;">|</td>
                <td style="width: 150px; text-align: center; white-space: nowrap;">IMPACT SCORE</td>
                <td style="width: 20px; text-align: center;">|</td>
                <td style="width: 300px; text-align: left; padding-left: 20px; white-space: nowrap;">ANOMALY RATE (COUNT)</td>
            </tr>

            <tr>
                <td colspan="5" style="{blue_line_style} padding-top: 5px; padding-bottom: 15px;">
                    {EQUALS_LINE}
                </td>
            </tr>
    """

    for i, (_, row) in enumerate(top_5_groups.iterrows()):
        group_label = ">".join([str(row[col]).strip() for col in unique_ids])
        rate_val = row['mean'] * 100 
        impact_val = row['interest_score']
        anomaly_count = int(row['sum'])
        
        bg_color = "#f9f9f9" if i % 2 != 0 else "#ffffff"

        html_output += f"""
            <tr style="vertical-align: middle; background-color: {bg_color}; border-bottom: 1px solid #f0f0f0;">
                <td style="padding: 10px 20px 10px {LEFT_PAD}; text-align: left; font-size: 0.95em; white-space: nowrap;">
                    {group_label}
                </td>
                <td style="text-align: center; color: #999;">|</td>
                <td style="text-align: center; color: #17a2b8; font-weight: bold;">
                    {impact_val:.2f}
                </td>
                <td style="text-align: center; color: #999;">|</td>
                <td style="text-align: left; padding-left: 40px; white-space: nowrap;">
                    <span style="color: #b22222; font-weight: bold;">{rate_val:.1f}%</span>
                    <span style="color: #b22222; font-size: 0.9em;"> ({anomaly_count} anomalies)</span>
                </td>
            </tr>
        """

    html_output += f"""
            <tr>
                <td colspan="5" style="{blue_line_style} padding-top: 15px;">
                    {EQUALS_LINE}
                </td>
            </tr>
        </table>
    </div>
    """
    
    return html_output


def model_performance_html_table(final_results):
    model_cols = [col for col in final_results.columns if col.startswith('is_') and col.endswith('_anomaly') and col != 'is_Anomaly']
    evaluated_records = len(final_results)
    
    chart_data = []
    for col in model_cols:
        name = col.replace('is_', '').replace('_anomaly', '').replace('IsolationForest', 'IF').replace('Percentile','PCNTL')
        count = int(final_results[col].sum())
        rate = (count / evaluated_records * 100) if evaluated_records > 0 else 0
        chart_data.append({'name': name, 'count': count, 'rate': rate})
        
    chart_data.sort(key=lambda x: x['count'], reverse=True)

    final_count = int(final_results['is_Anomaly'].sum())
    final_rate = (final_count / evaluated_records * 100) if evaluated_records > 0 else 0
    chart_data.append({'name': 'FINAL (is_Anomaly)', 'count': final_count, 'rate': final_rate})

    max_count = max([d['count'] for d in chart_data]) if chart_data else 1

    # --- HTML Building ---
    # Increased width to 1000px to accommodate the longer horizontal lines
    html = f"""
    <div style="font-family: 'Courier New', Courier, monospace; background-color: #ffffff; padding: 15px; color: #333; line-height: 1.1; width: 1000px;">
        
        <div style="color: #0056b3; letter-spacing: -1px; font-size: 0.9em; white-space: nowrap;">{"="*120}</div>
        <div style="color: #28a745; font-weight: bold; text-align: center; margin: 4px 0; font-size: 1.1em; width: 85%;">MODEL PERFORMANCE REPORT</div>
        <div style="color: #0056b3; letter-spacing: -1px; font-size: 0.9em; white-space: nowrap;">{"="*120}</div>
        
        <table style="width: 100%; border-collapse: collapse; margin-top: 5px;">
    """

    for i, entry in enumerate(chart_data):
        is_final = "FINAL" in entry['name']
        bar_color = "#b22222" if is_final else "#b8860b"
        text_color = "#b22222" if is_final else "#b8860b"
        
        bg_color = "#f2f2f2" if i % 2 != 0 else "#ffffff"
        
        # Keep bar width at 55 to leave room for the anomaly count text on the right
        bar_width = (entry['count'] / max_count) * 55 

        html += f"""
            <tr style="background-color: {bg_color};">
                <td style="width: 200px; padding: 6px 10px 6px 40px; text-align: left; vertical-align: middle;">{entry['name']}</td>
                <td style="width: 15px; padding: 0; text-align: center; vertical-align: middle; color: #999;">|</td>
                <td style="width: 60px; color: {text_color}; text-align: right; padding-right: 20px; vertical-align: middle;">{entry['rate']:5.1f}%</td>
                <td style="padding: 4px 0; vertical-align: middle;">
                    <div style="display: flex; align-items: center;">
                        <div style="background-color: {bar_color}; width: {bar_width}%; height: 22px; min-width: 2px;"></div>
                        <span style="padding-left: 10px; white-space: nowrap; font-size: 0.95em;">{entry['count']:,} anomalies</span>
                    </div>
                </td>
            </tr>
        """

    html += f"""
        </table>
        <div style="color: #0056b3; letter-spacing: -1px; margin-top: 5px; font-size: 0.9em; white-space: nowrap;">{"="*120}</div>
    </div>
    """
    
    return html