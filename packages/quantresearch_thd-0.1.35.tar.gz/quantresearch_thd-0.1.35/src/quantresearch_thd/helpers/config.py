MODEL_CONFIG = {
    'DECOMPOSITION': ['base_signal', 'residual'],
    'PERCENTILE': ['Percentile_low', 'Percentile_high','Percentile_anomaly', 'is_Percentile_anomaly'],
    'SD': ['Mean', 'SD', 'SD_low', 'SD_high', 'SD_anomaly','is_SD_anomaly'],
    'MAD': ['Median', 'MAD', 'MAD_low', 'MAD_high', 'MAD_anomaly','is_MAD_anomaly'],
    'IQR': ['Q1', 'Q3', 'IQR', 'IQR_low', 'IQR_high', 'IQR_anomaly', 'is_IQR_anomaly'],
    'EWMA': ['EWMA_forecast', 'EWMA_STD','EWMA_low','EWMA_high','EWMA_residual', 'EWMA_anomaly', 'is_EWMA_anomaly'],
    'FB': ['FB_forecast', 'FB_low', 'FB_high', 'FB_residual', 'FB_anomaly', 'is_FB_anomaly'],
    'ISF': ['IsolationForest_score', 'IsolationForest_score_low', 'is_IsolationForest_anomaly', 'IsolationForest_anomaly'],
    'DBSCAN': ['DBSCAN_score','DBSCAN_anomaly', 'is_DBSCAN_anomaly']
}