import pandas as pd
import numpy as np
import statistics
from .Preprocessing import classify

# # EWMA functions

def ewma_with_anomalies_rolling_group(group, group_columns, variable, date_column, alpha, sigma, eval_period):
    """
    # 📉 EWMA Rolling Anomaly Detection
    ---

    The `ewma_with_anomalies_rolling_group` function implements a **statistically weighted** approach to identifying outliers. It uses an **Expanding Window** (Walk-Forward) strategy to adapt to recent trends while maintaining a memory of historical data.

    ## 📋 Functional Overview
    This function calculates the **Exponentially Weighted Moving Average (EWMA)**, which assigns higher importance to recent observations. By combining this forecast with a dynamic standard deviation "envelope," the function identifies points that deviate significantly from the expected trend.

    ## 🧠 Core Logic Components

    ### 1. Forecast Engine (`ewma_forecast`)
    * **Weighting Mechanism:** Uses an `alpha` parameter (between 0 and 1) to determine the "decay" of information. A **higher alpha** makes the model more sensitive to recent changes.
    * **Calculation:** Employs the formula:
          EWMA_t = alpha x Y_t + (1 - alpha).EWMA_t-1

    ## 📤 Key Output Columns
    The function returns a concatenated DataFrame containing:
    * **`EWMA_forecast`**: The predicted value for that timestamp.
    * **`STD`**: The standard deviation used to calculate the threshold.
    * **`EWMA_high` / `EWMA_low`**: The dynamic boundaries (the "envelope") for the test period.
    * **`is_EWMA_anomaly`**: A boolean flag indicating if the actual value fell outside the limits.

    ## 💡 Usage Context
    EWMA is ideal for **streaming-style data** or metrics that exhibit **level shifts**. Because it weights recent data more heavily than a simple moving average, it is faster to adapt to new "normals" while still filtering out minor noise.

    ---
    ### ⚙️ Parameter Tuning
    * **`alpha`**: Adjust this to control how quickly the model "forgets" old data (Typical range: `0.1 - 0.3`).
    * **`sigma`**: Adjust this to control sensitivity. A **lower sigma** results in more anomalies, while a **higher sigma** (e.g., `3.0`) only flags extreme outliers.

    ---
    """
    # 1. Prepare Data
    group = group.sort_values(date_column).reset_index(drop=True)
    vals = group[variable].astype(float)
    
    # 2. Calculate Statistics (Vectorized)
    # Shift(1) ensures we use history only (no data leakage)
    ewma_forecast = vals.ewm(alpha=alpha, adjust=False).mean().shift(1)
    std_expanding = vals.expanding().std().shift(1)
    
    # 3. Construct Output DataFrame
    results = group[group_columns + [date_column]].copy()
    results[variable] = vals
    results["alpha"] = alpha
    results["sigma"] = sigma
    
    # 4. Handle Nulls for the first two rows (The "Backfill" logic)
    # Backfilling allows us to have a baseline even for the very first point
    results["EWMA_forecast"] = ewma_forecast.bfill()
    results["EWMA_STD"] = std_expanding.bfill().fillna(0) # fillna(0) in case there's only 1 row total
    
    # 5. Define Bounds (Now that nulls are handled)
    results["EWMA_high"] = results["EWMA_forecast"] + (sigma * results["EWMA_STD"])
    results["EWMA_low"] = (results["EWMA_forecast"] - (sigma * results["EWMA_STD"])).clip(lower=0)
    
    # 6. USE THE CLASSIFY FUNCTION
    # Note: Ensure 'classify' function is defined in your script!
    results["EWMA_anomaly"] = results.apply(
        lambda row: classify(row[variable], row["EWMA_low"], row["EWMA_high"]), 
        axis=1
    )
    
    # If the first row was backfilled, we should force it to 'none' 
    # to be safe since it's not a "real" statistical forecast.
    results.loc[0, "EWMA_anomaly"] = 'none'
    
    # 7. Final Flags and Labels
    results["is_EWMA_anomaly"] = results["EWMA_anomaly"] != 'none'
    results["EWMA_residual"] = vals - results["EWMA_forecast"]
    
    results["set"] = "TRAIN"
    if eval_period > 0 and len(results) >= eval_period:
        results.iloc[-eval_period:, results.columns.get_loc("set")] = "TEST"
        
    results[date_column] = pd.to_datetime(results[date_column])
    
    return results