import pandas as pd
import numpy as np
from .Preprocessing import classify, get_optimal_window



def detect_outliers_sd(group, variable, date_column, eval_period, SD_threshold,magnitude_threshold):
    """
    # 📈 Standard-Deviation–Based Outlier Detection (Expanding Window)

    This function detects anomalies using a Mean ± N Standard Deviation rule applied to the **Residual Proportion** of an STL-decomposed time series.


    ## 📋 Functional Overview

    the model evaluates the percentage deviation relative to the expected baseline (Trend + Seasonality). This ensures that the "width" of the detection band scales automatically with the volume of the data, effectively handling **Heteroscedasticity**.

    ## 🧠 Core Logic Stages

    ### 1.  Data Preparation and Validation
    * **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
    prevent statistically insignificant results.

    * **Copying:** It creates a copy of the input group to ensure the original data remains unaltered during the calculation process.

    ### 2. Signal Extraction (STL)
    Before statistical testing begins, the function uses **STL Decomposition** to break the time series into Trend, Seasonality, and Residual components.
    * **Base Signal:** Calculated as `Trend + Seasonality`.
    * **Residual Proportion:**  Calculated as `(Actual - Base)/Base`. This normalized metric is the primary input for the outlier detection.

    ### 3. Rolling Window Thresholding
    * **Continuous Calculation:** The model utilizes a **rolling window** (typically 52 weeks) to calculate the Mean and Standard Deviation of the Residual Proportions at every point in the time series.

    * **Dynamic Bounds:**  It establishes proportional bounds: Mean+-(N x SD) based on the historical distribution of noise within the window.

    * **Adaptive Nature:** By recalculating at each step, the model continuously adapts to shifts in volatility and baseline noise throughout the entire series, rather than relying on a static training set.

    ### 4. Reconstruction

    * **Scale-Back:** The proportional bounds are projected back to raw units:
        * **Thresholds:** `Base x (1 + Proportion_bound)`.

    ## 📤 Key Output Columns
    The function appends several analytical columns to the returned DataFrame:
    * **`Mean / SD:`**: Calculated on the residual proportions. Mean is translated back into raw unit thresholds for reporting(e.g., Views).
    * **`SD_low / SD_high`**: Thresholds translated back into raw units (e.g., Views).
    * **`SD_anomaly`**: A descriptive label (e.g., "High," "Low," or "Normal").
    * **`is_SD_anomaly`**:  Boolean flag indicating the proportion exceeded the N-SD limit.


    ## 💡 Usage Context

    The Standard Deviation model is ideal for identifying anomalies in data that follows a relatively Normal (Gaussian) distribution of noise. By applying it to the Residual Proportion, this model becomes particularly powerful for:

    - Scale-Invariant Detection: Detecting a 10% drop in traffic regardless of whether the baseline is 1,000 or 1,000,000.

    - Heteroscedastic Data: Handling time series where the variance naturally expands during peak periods and contracts during off-peaks.

    - Predictable Volatility: Best used when the historical noise profile is stable enough that a "multiple of standard deviation" remains a meaningful threshold for the business.
    ---
    """
    n = len(group)
    if n < 10:
        return pd.DataFrame(columns=group.columns)

    group = group.copy().sort_values(date_column)
    group[date_column] = pd.to_datetime(group[date_column])
    
    window_size = get_optimal_window(group, date_column)
    train_size = n - eval_period

    cols_to_init = ['Mean', 'SD', 'SD_low', 'SD_high', 'set', 'SD_anomaly']
    for col in cols_to_init:
        group[col] = None
    group['is_SD_anomaly'] = False

    vals = group[variable].values
    base_signals = group['base_signal'].values
    residuals= group['residual'].values

    for i in range(n):
        current_set = "TRAIN" if i < train_size else "TEST"
        start_idx = max(0, i - window_size)
        window_data = vals[start_idx:i]
        
        if len(window_data) == 0:
            window_data = vals[0:1]

        # --- SD MATH ---
        curr_mean = np.nanmean(window_data)
        raw_std = np.nanstd(window_data)
        
        # --- NEW: MINIMUM NOISE FLOOR (The 10% Rule) ---
        # If the SD is tiny, we force it to be at least 10% of the mean.
        # This prevents the 'tight threshold' trap.
        noise_floor = np.abs(curr_mean) * 0.10
        effective_std = max(raw_std, noise_floor)
        
        lower_sd = curr_mean - (SD_threshold * effective_std)
        upper_sd = curr_mean + (SD_threshold * effective_std)
        
        current_val = vals[i]
        current_base = base_signals[i]
        current_res = residuals[i]
        
         # --- CONTEXTUAL ANOMALY LOGIC ---
        # Statistical check: Breach of bands
        is_statistical_anomaly = (current_val < lower_sd) or (current_val > upper_sd)
        
        # Contextual check: Is the deviation > 30% of the baseline?
        is_contextual_anomaly = False
        if current_base > 0:
            is_contextual_anomaly = (abs(current_res) / current_base) > magnitude_threshold #
            
        # Final flag: Both must be true
        is_final_anomaly = is_statistical_anomaly and is_contextual_anomaly

        group.iloc[i, group.columns.get_loc('Mean')] = curr_mean
        group.iloc[i, group.columns.get_loc('SD')] = raw_std
        group.iloc[i, group.columns.get_loc('SD_low')] = lower_sd
        group.iloc[i, group.columns.get_loc('SD_high')] = upper_sd
        group.iloc[i, group.columns.get_loc('set')] = current_set
        group.iloc[i, group.columns.get_loc('SD_anomaly')] = classify(current_val, lower_sd, upper_sd) if is_final_anomaly else "none"
        group.iloc[i, group.columns.get_loc('is_SD_anomaly')] = is_final_anomaly

    group['is_SD_anomaly'] = group['is_SD_anomaly'].astype(bool)
    group[date_column] = pd.to_datetime(group[date_column])
    
    return group