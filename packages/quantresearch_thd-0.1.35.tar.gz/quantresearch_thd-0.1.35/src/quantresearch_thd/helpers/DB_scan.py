import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from statsmodels.tsa.stattools import acf
from .Preprocessing import get_dynamic_lags


def build_simple_filler_model(df, variable, sensitivity):
    """
    Creates a baseline using only global value and velocity.
    Used to fill gaps where the walk-forward model cannot compute.
    """
    filler_df = df.copy()
    
    # 1. Pre-processing
    filler_df['proc_val'] = filler_df[variable].ffill().bfill()
    filler_df['velocity'] = filler_df['proc_val'].diff().fillna(0)
    
    # 2. Scaling
    features = ['proc_val', 'velocity']
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(filler_df[features])
    
    # 3. Parameter Logic (Global)
    min_samples = 6
    neigh = NearestNeighbors(n_neighbors=min_samples).fit(scaled_data)
    distances, _ = neigh.kneighbors(scaled_data)
    eps = max(np.percentile(distances[:, -1], 92) * sensitivity, 0.2)
    
    # 4. Score Generation
    v_scale = np.vectorize(calculate_scaled_score)
    simple_scores = v_scale(distances[:, -1], eps)
    
    return pd.DataFrame({
        'simple_score': simple_scores,
        'simple_anomaly': (distances[:, -1] > eps)
    }, index=df.index)


def find_optimal_epsilon(X_scaled: np.ndarray, k: int, sensitivity: float) -> float:
    if len(X_scaled) <= k: return 0.5
    neigh = NearestNeighbors(n_neighbors=k).fit(X_scaled)
    distances, _ = neigh.kneighbors(X_scaled)
    # TIGHTENED: Changed from 90th to 80th percentile to shrink the "normal" bubble
    return max(np.percentile(distances[:, -1], 80) * sensitivity, 0.1)


def calculate_scaled_score(k_distance, epsilon):
    ratio = k_distance / (epsilon + 1e-10)
    if ratio <= 1.0:
        return ratio * 0.49
    else:
        return 0.51 + 0.49 * (1 - np.exp(-1.5 * (ratio - 1)))

def detect_time_series_anomalies_dbscan(
    group, 
    variable, 
    date_column, 
    eval_period, 
    sensitivity # Nudged down to increase detection rate
):
    """
    # 🌀 DBSCAN Walk-Forward Anomaly Detection
    ---

    The `detect_time_series_anomalies_dbscan` function implements a **density-based clustering** approach for time-series anomaly detection. It utilizes an **iterative walk-forward validation** strategy to identify data points that exist in "low-density" regions of the feature space.

    ## 📋 Functional Overview
    This function transforms a univariate time series into a high-dimensional feature space using **dynamic lags** and  **rolling statistics**. It then applies the **DBSCAN** (Density-Based Spatial Clustering of Applications with Noise) algorithm to distinguish between dense clusters of "normal" behavior and sparse "noise" points (anomalies).



    ## 🧠 Core Logic & Helper Utilities

    ### 1. Dynamic Feature Engineering (`get_dynamic_lags`)
    Instead of using fixed lags, the function uses the **Autocorrelation Function (ACF)** to find the 10 most significant seasonal patterns in the data.
    * **Baseline:** Always includes lags 1, 2, and 3 to capture immediate momentum.
    * **Significance:** Uses a 75% confidence interval ($\\\\alpha=0.25$) to identify meaningful historical dependencies.

    ### 2. Automated Parameter Tuning (`find_optimal_epsilon`)
    DBSCAN is highly sensitive to the **Epsilon ($\\\\epsilon$)** parameter (the neighborhood radius). 
    * **Proxy Elbow Method:** The function automatically calculates $\\\\epsilon$ by analyzing the distance to the $k$-th nearest neighbor for all training points.
    * **Density Threshold:** It sets $\\\\epsilon$ at the **95th percentile** of these distances, ensuring that 95% of training data is considered "dense" while the most isolated 5% are candidates for noise.

    ### 3. Walk-Forward Iteration
    For each period in the `eval_period`:
    * **Feature Construction:** Builds a matrix containing the variable, its dynamic lags, rolling means, rolling standard deviations, and a linear trend component.
    * **Scaling:** Fits a `StandardScaler` **only on training data** to prevent data leakage.
    * **Novelty Detection:** Since DBSCAN cannot "predict" on new points, the function uses a **Nearest Neighbors proxy**. If the distance from a new test point to its $k$-th neighbor in the training set is greater than the trained $\\\\epsilon$, it is flagged as an anomaly.

    ## 📤 Key Output Columns
    * **`dbscan_score`**: The distance from the point to the $\\\\epsilon$ boundary (positive values indicate anomalies).
    * **`is_DBSCAN_anomaly`**: A boolean flag identifying outliers.
    * **Generated Features**: Includes all dynamic lags (`lagX`) and rolling statistics (`roll_mean_W`) used during the fit.

    ## 💡 Usage Context
    DBSCAN is exceptionally powerful for detecting **contextual anomalies**—points that might look "normal" in value but are "weird" given their recent history or seasonal context. Because it is density-based, it can find anomalies in non-linear or multi-modal distributions where simple percentile or Z-score methods would fail.

    ---
    ### ⚠️ Performance Note
    This model is computationally more intensive than statistical methods due to the iterative re-fitting of the `NearestNeighbors` and `DBSCAN` models. It is best suited for high-priority metrics where accuracy is more critical than processing speed.

    ---

    """
    group = group.reset_index(drop=True)
    group_orig = group.copy()
    df_proc = group[[variable, date_column]].copy()
    df_proc[date_column] = pd.to_datetime(df_proc[date_column])
    df_proc = df_proc.sort_values(date_column).reset_index(drop=True)
    
    try:
        all_results = []
        train_cutoff_idx = len(df_proc) - eval_period
        
        # --- BALANCED NOISE REDUCTION ---
        # 5-day window is the 'sweet spot' for 3% detection
        df_proc['smoothed_val'] = df_proc[variable].rolling(window=5, min_periods=1).mean()
        df_proc['velocity'] = df_proc['smoothed_val'].diff()
        
        features = ['smoothed_val', 'velocity']
        
        # Min samples set to 6 for better local sensitivity
        min_samples = 6 

        def find_eps_balanced(X, k, sens):
            if len(X) <= k: return 0.5
            neigh = NearestNeighbors(n_neighbors=k).fit(X)
            dist, _ = neigh.kneighbors(X)
            # 92nd percentile targets the 3% detection range effectively
            return max(np.percentile(dist[:, -1], 92) * sens, 0.2)

        # --- STEP 1: TRAIN ---
        test_start_date = df_proc.iloc[train_cutoff_idx][date_column]
        train_df = df_proc[df_proc[date_column] < test_start_date].dropna().copy()
        
        scaler = StandardScaler()
        train_sc = scaler.fit_transform(train_df[features])
        eps = find_eps_balanced(train_sc, min_samples, sensitivity)
        
        dbscan = DBSCAN(eps=eps, min_samples=min_samples).fit(train_sc)
        
        train_df['k_distance'] = eps 
        train_df['epsilon_threshold'] = eps
        train_df['is_DBSCAN_anomaly'] = (dbscan.labels_ == -1)
        all_results.append(train_df)

        # --- STEP 2: WALK FORWARD ---
        model_df = df_proc.dropna().reset_index(drop=True)
        test_indices = model_df[model_df[date_column] >= test_start_date].index
        for idx in test_indices:
            # Look back 80 points for a stable but reactive baseline
            curr_train = model_df.iloc[max(0, idx-80):idx].copy()
            curr_test = model_df.iloc[[idx]].copy()
            
            sc = StandardScaler()
            tr_sc = sc.fit_transform(curr_train[features])
            te_sc = sc.transform(curr_test[features])
            
            local_eps = find_eps_balanced(tr_sc, min_samples, sensitivity)
            nn_test = NearestNeighbors(n_neighbors=min_samples).fit(tr_sc)
            d, _ = nn_test.kneighbors(te_sc)
            
            curr_test['k_distance'] = d[0][-1]
            curr_test['epsilon_threshold'] = local_eps
            curr_test['is_DBSCAN_anomaly'] = d[0][-1] > local_eps
            all_results.append(curr_test)

        # --- STEP 3: CONSOLIDATE ---
        res_df = pd.concat(all_results).drop_duplicates(subset=[date_column])
        v_scale = np.vectorize(calculate_scaled_score)
        res_df['DBSCAN_score'] = v_scale(res_df['k_distance'], res_df['epsilon_threshold'])
        
        res_df['is_DBSCAN_anomaly'] = res_df['is_DBSCAN_anomaly'].astype(bool)
        #res_df['DBSCAN_anomaly'] = np.where(res_df['is_DBSCAN_anomaly'], 'high', 'none')
        #res_df['DBSCAN_score_high'] = res_df['is_DBSCAN_anomaly'].astype(int)

        group_orig[date_column] = pd.to_datetime(group_orig[date_column])
        final = group_orig.merge(
            res_df[[date_column, 'DBSCAN_score','is_DBSCAN_anomaly']], 
            on=date_column, how='left'
        )
        # Use the filler model for missing scores (e.g., initial rows or rows with NaNs)
        filler = build_simple_filler_model(group_orig, variable, sensitivity)
        final['DBSCAN_score'] = final['DBSCAN_score'].fillna(filler['simple_score'])
        #final['DBSCAN_score_high'] = final['DBSCAN_score_high'].fillna(0).astype(int)
        final['is_DBSCAN_anomaly']= final['is_DBSCAN_anomaly'].fillna(filler['simple_anomaly']).astype(bool)
        final['DBSCAN_anomaly'] = np.where(final['is_DBSCAN_anomaly'], 'high', 'none')
        
        return final

    except Exception as e:
        print(f"Error in DBSCAN: {e}")
        for col in ["DBSCAN_score", "DBSCAN_score_high", "is_DBSCAN_anomaly", "DBSCAN_anomaly"]:
            group_orig[col] = 0
        return group_orig