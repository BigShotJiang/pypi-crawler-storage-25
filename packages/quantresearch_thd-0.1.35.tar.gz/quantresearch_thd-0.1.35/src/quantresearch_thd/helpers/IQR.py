import pandas as pd
import numpy as np
from .Preprocessing import classify, get_optimal_window



def detect_outliers_iqr(group, variable, date_column, eval_period, IQR_threshold,magnitude_threshold):
    """
    # 📊 IQR MODEL (Interquartile Range)
    ---

    The `detect_outliers_iqr` function is a robust, non-parametric anomaly detection tool that combines **Seasonal-Trend Decomposition (STL)** with **dynamic Interquartile Range (IQR)** estimation to identify relative outliers.

    ## 🔍 Functional Overview
    the model evaluates the **Residual Proportion** rather than raw values. By measuring the percentage deviation from an expected baseline **(Trend + Seasonality)**, the model maintains consistent sensitivity across different volume scales. This prevents **high-volume noise** from triggering false positives while ensuring **low-volume drops** are still accurately captured.

    ## 🧠 Core Logic Stages

    ### 1.  Data Preparation and Validation
    * **Minimum Threshold:** The function requires at least **10+Eval_period data points** to run; otherwise, it returns an empty DataFrame to
    prevent statistically insignificant results.

    * **Copying:** It creates a copy of the input group to ensure the original data remains unaltered during the calculation process.

    ### 2. Signal Extraction (STL)
    Before statistical testing begins, the function uses **STL Decomposition** to break the time series into Trend, Seasonality, and Residual components.
    * **Base Signal:** Calculated as `Trend + Seasonality`.
    * **Residual Proportion:**  Calculated as `(Actual - Base)/Base`. This normalized metric is the primary input for the outlier detection.

    ### 3. Proportional Fencing
    * **"Normal" Range:** The model identifies behavior based on the 25th `(Q1)` and 75th `(Q3)` percentiles of the historical Residual Proportion.

    * **Tukey's Fences:** Boundaries are established using the standard IQR multiplier (typically 3.0 for extreme outliers):
        * `Lower_Proportion = Q1 - (3*IQR)`

        * `Upper_Proportion = Q3 + (3*IQR)`

    * **Dynamic Adaptation:** The model utilizes a rolling window (typically 52 weeks) to recalculate the `Q1`, `Q3`, and `IQR` at every point in the time series. This ensures that the thresholds are always representative of the local volatility and recent historical context.

    ### 4. Reconstruction (Scale-Back)
    The proportional boundaries are translated back into raw unit thresholds (e.g., Views):
    * **Thresholds:** `Base x (1 + Proportion_bound)`.


    ## 📤 Key Output Columns
    The function appends several analytical columns to the returned DataFrame:
    * **`Q1` / `Q3` / `IQR`**: The proportional boundaries. Q1, Q3 are translated back into raw unit thresholds (e.g., Views).
    * **`IQR_low` / `IQR_high`**: The calculated thresholds translated back into raw units.
    * **`IQR_anomaly`**: A descriptive label (e.g., "High," "Low," or "Normal").
    * **`is_IQR_anomaly`**:  Boolean flag indicating if the proportion exceeded the 3x IQR fences.

    ## 💡 Usage Context
    The IQR method is highly effective for datasets where the noise distribution is **non-Gaussian** or contains heavy tails. By focusing on the **Residual Proportion**, it handles **Heteroscedasticity** naturally—ensuring that the "width" of the anomaly detection band is always proportional to the current volume of the time series.
    """
    n = len(group)
    if n < 10:
        return pd.DataFrame(columns=group.columns)

    group = group.copy().sort_values(date_column)
    group[date_column] = pd.to_datetime(group[date_column])
    
    # 1. Determine Window Size based on Frequency
    window_size = get_optimal_window(group, date_column)
    #print(window_size)
    
    # Define training vs evaluation split index
    train_size = n - eval_period
    
    # Initialize all original columns
    cols_to_init = ['Q1', 'Q3', 'IQR', 'IQR_low', 'IQR_high', 'set', 'IQR_anomaly']
    for col in cols_to_init:
        group[col] = None
    group['is_IQR_anomaly'] = False

    vals = group[variable].values
    base_signals = group['base_signal'].values
    residuals= group['residual'].values

    # 2. Process the entire dataset using the Sliding/Adaptive Window
    for i in range(n):
        # Identify if we are in the initial TRAIN block or the TEST block
        current_set = "TRAIN" if i < train_size else "TEST"
        
        # SLIDING WINDOW LOGIC:
        # We look back 'window_size' points, but never include the current point 'i' 
        # to ensure the anomaly doesn't contaminate the baseline.
        start_idx = max(0, i - window_size)
        window_data = vals[start_idx:i]
        
        # Fallback for the very first point in the dataset
        if len(window_data) == 0:
            window_data = vals[0:1]

        q1 = np.nanpercentile(window_data, 25)
        q3 = np.nanpercentile(window_data, 75)
        iqr = q3 - q1
        # If the IQR is too small, use a percentage of the mean instead
        min_iqr = np.nanmean(window_data) * 0.1  # 5% of the average value
        actual_iqr = max(iqr, min_iqr)
        
        low = q1 - (IQR_threshold * iqr)
        high = q3 + (IQR_threshold * iqr)
        current_val = vals[i]
        current_base = base_signals[i]
        current_res = residuals[i]
        
        # --- CONTEXTUAL ANOMALY LOGIC ---
        # Statistical check: Breach of bands
        is_statistical_anomaly = (current_val < low) or (current_val > high)
        
        # Contextual check: Is the deviation > 30% of the baseline?
        is_contextual_anomaly = False
        if current_base > 0:
            is_contextual_anomaly = (abs(current_res) / current_base) > magnitude_threshold #
            
        # Final flag: Both must be true
        is_final_anomaly = is_statistical_anomaly and is_contextual_anomaly
        
        # Populate all original columns
        group.iloc[i, group.columns.get_loc('Q1')] = q1
        group.iloc[i, group.columns.get_loc('Q3')] = q3
        group.iloc[i, group.columns.get_loc('IQR')] = iqr
        group.iloc[i, group.columns.get_loc('IQR_low')] = low
        group.iloc[i, group.columns.get_loc('IQR_high')] = high
        group.iloc[i, group.columns.get_loc('set')] = current_set
        group.iloc[i, group.columns.get_loc('IQR_anomaly')] = classify(current_val, low, high) if is_final_anomaly else "none"
        group.iloc[i, group.columns.get_loc('is_IQR_anomaly')] = is_final_anomaly
    # Final formatting
    group['is_IQR_anomaly'] = group['is_IQR_anomaly'].astype(bool)
    group[date_column] = pd.to_datetime(group[date_column])
    
    return group