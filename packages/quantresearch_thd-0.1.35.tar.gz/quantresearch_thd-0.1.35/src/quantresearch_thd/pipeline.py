import pandas as pd
import numpy as np
from datetime import date
import joblib
from joblib import Parallel, delayed
import contextlib
from tqdm.auto import tqdm
from .helpers.Preprocessing import (create_full_calendar_and_interpolate,
                                    calculate_ensemble_scores,
                                    min_records_extraction,
                                    
                                   )
from .helpers.utils import (get_stl_period,
                                    process_stats_group,
                                    process_group,
                                    print_success_message,
                                    anomaly_summary_chart,
                                    rank_anomaly_impact,
                                    top_anomaly_stats,
                                    display_help_code_block
                                   )
from .helpers.config import MODEL_CONFIG


# --- Progress Bar Context Manager ---
@contextlib.contextmanager
def tqdm_joblib(tqdm_object):
    """Context manager to patch joblib to report into tqdm progress bar"""
    class TqdmBatchCompletionCallback(joblib.parallel.BatchCompletionCallBack):
        def __call__(self, *args, **kwargs):
            tqdm_object.update(self.batch_size)
            return super().__call__(*args, **kwargs)

    old_callback = joblib.parallel.BatchCompletionCallBack
    joblib.parallel.BatchCompletionCallBack = TqdmBatchCompletionCallback
    try:
        yield tqdm_object
    finally:
        joblib.parallel.BatchCompletionCallBack = old_callback
        # We DO NOT close the pbar here so it can be reused for the next model
        



def run_pipeline(master_data, unique_ids, variable, date_column, freq,
                 eval_period, max_records, imputation_method,
                 percentile_threshold, SD_threshold, mad_threshold, 
                 mad_scale_factor, IQR_threshold, magnitude_threshold, alpha, sigma, 
                 prophet_CI, contamination, sensitivity, random_state, is_assigned,
                 enabled_models):
    
    # 1. Initialization & Preprocessing
    enabled_models = [m.upper() for m in enabled_models]
    if max_records is not None:
        max_records = max_records + eval_period

    final_data, success_report = create_full_calendar_and_interpolate(
        master_data, unique_ids, variable, date_column, freq, max_records, imputation_method, eval_period
    )
    
    # Filter groups with at least 5 valid data points
    groups = [(n, g) for n, g in final_data.groupby(unique_ids) if g[variable].notna().sum() >= 5]
    
    # Calculate Total Operations for Progress Bar
    stats_keys = {'PERCENTILE', 'SD', 'MAD', 'IQR'}
    run_stats = any(m in enabled_models for m in stats_keys)
    other_ts_models = [m for m in ['EWMA', 'FB', 'DBSCAN'] if m in enabled_models]
    isf_op = 2 if 'ISF' in enabled_models else 0 # ISF runs two parallel passes
    
    total_operations = len(groups) * ((1 if run_stats else 0) + len(other_ts_models) + isf_op)
    results_map = {}

    # 2. Execution Loop
    with tqdm(total=total_operations, desc="Running Anomaly Detection Pipeline") as pbar:
        
        # --- BATCH 1: STATS ON RESIDUALS (STL) ---
        if run_stats:
            with tqdm_joblib(pbar):
                stats_raw = Parallel(n_jobs=-1)(delayed(process_stats_group)(
                    g, variable, date_column, eval_period, freq, percentile_threshold,
                    SD_threshold, mad_threshold, mad_scale_factor, IQR_threshold,magnitude_threshold
                ) for n, g in groups)
            
            # Unpack results into map if they were requested
            if 'PERCENTILE' in enabled_models: results_map['PERCENTILE'] = pd.concat([r[0] for r in stats_raw])
            if 'SD' in enabled_models: results_map['SD'] = pd.concat([r[1] for r in stats_raw])
            if 'MAD' in enabled_models: results_map['MAD'] = pd.concat([r[2] for r in stats_raw])
            if 'IQR' in enabled_models: results_map['IQR'] = pd.concat([r[3] for r in stats_raw])
            
            first_available = next(iter(stats_keys.intersection(results_map.keys())))
            results_map['DECOMPOSITION'] = results_map[first_available][unique_ids + [date_column, 'base_signal', 'residual']]
            
            
        # --- BATCH 2: STANDARD TIME SERIES MODELS ---
        for model_key in ['EWMA', 'FB', 'DBSCAN']:
            if model_key in enabled_models:
                with tqdm_joblib(pbar):
                    raw = Parallel(n_jobs=-1)(delayed(process_group)(
                        model_key, n, g, unique_ids, variable, date_column, 
                        alpha, sigma, eval_period, prophet_CI, contamination,sensitivity,random_state
                    ) for n, g in groups)
                    results_map[model_key] = pd.concat(raw)

        # --- BATCH 3: ISOLATION FOREST (Ensemble Logic) ---
        if 'ISF' in enabled_models:
            with tqdm_joblib(pbar):
                res_gen = Parallel(n_jobs=-1)(delayed(process_group)(
                    'ISF_general', n, g, unique_ids, variable, date_column, 
                    alpha, sigma, eval_period, prophet_CI, contamination, sensitivity, random_state
                ) for n, g in groups)
                res_ts = Parallel(n_jobs=-1)(delayed(process_group)(
                    'ISF_timeseries', n, g, unique_ids, variable, date_column, 
                    alpha, sigma, eval_period, prophet_CI, contamination,sensitivity, random_state
                ) for n, g in groups)
            
            isf_gen_df = pd.concat(res_gen)
            isf_ts_df = pd.concat(res_ts)
            
            # Combine General and Timeseries results based on Train/Test set
            isf_combined = isf_gen_df.merge(
                isf_ts_df[unique_ids + [date_column, 'IsolationForest_score_timeseries', 
                                        'IsolationForest_score_low_timeseries', 
                                        'is_IsolationForest_anomaly_timeseries', 
                                        'IsolationForest_anomaly_timeseries']], 
                on=unique_ids + [date_column], how='inner'
            )
            
           
            for suffix in ['', '_low']:
                # For boolean/categorical 'anomaly' and numeric scores
                main_col = f'IsolationForest_score{suffix}'
                ts_col = f'IsolationForest_score{suffix}_timeseries'
                gen_col = f'IsolationForest_score{suffix}_general'
                
                # Coalesce: Use TS if not null, else use General
                isf_combined[main_col] = isf_combined[ts_col].fillna(isf_combined[gen_col])

            # Specifically handle the 'is_Anomaly' boolean flag
            isf_combined['IsolationForest_anomaly'] = (
            isf_combined['IsolationForest_anomaly_timeseries']
                .fillna(isf_combined['IsolationForest_anomaly_general'])
            )
            isf_combined['is_IsolationForest_anomaly'] = (
                isf_combined['is_IsolationForest_anomaly_timeseries']
                .fillna(isf_combined['is_IsolationForest_anomaly_general'])
            )
                                                                              
            #print(isf_combined.head(50))
            #print(isf_combined.tail(50))                                                                 
                                                                              
            results_map['ISF'] = isf_combined[unique_ids + [date_column] + MODEL_CONFIG['ISF']]

    # 3. Dynamic Merging
    anomaly = final_data.copy()
    

        # Add DECOMPOSITION to the keys we iterate over
    models_to_merge = (['DECOMPOSITION'] if run_stats else [])+enabled_models 

    for model_key in models_to_merge:
        if model_key in results_map:
            cols_to_extract = unique_ids + [date_column] + MODEL_CONFIG[model_key]
            # Ensure we only pick columns that actually exist in the result dataframe
            valid_cols = [c for c in cols_to_extract if c in results_map[model_key].columns]
            
            anomaly = anomaly.merge(
                results_map[model_key][valid_cols], 
                on=unique_ids + [date_column], 
                how='inner'
            )
    
    from .helpers.evaluation_plots import (summary_pie_plot,
                                       anomaly_stacked_bar_plot, 
                                       anomaly_variable_score_plot, 
                                       anomaly_overview_plot,
                                       model_performance_chart,
                                        display_top_anomaly_plots)

    from IPython.display import display, Markdown
    
    # --- Final Ensemble & Scoring ---
    anomaly_final = calculate_ensemble_scores(anomaly, variable, unique_ids, date_column, enabled_models)
    # 1. Handle non-finite values (inf/NaN) and cap range
    anomaly_final['Anomaly_Score'] = (
    anomaly_final['Anomaly_Score']
    .replace([np.inf, -np.inf], np.nan)
    .fillna(0)
    .clip(lower=0, upper=100)
    )
    #print(anomaly_final.Anomaly_Score.describe())
        
    # # --- Cleansing Mechanism ---
    # anomaly_final = cleanse_anomalies_directional(
    #         anomaly_final, 
    #         variable, 
    #         enabled_models
    #     )
    
    globals()['anomaly_df'] = anomaly_final
    #print(anomaly_final.head())
    #print(f"Successfully processed {len(success_report)} groups.")
    
    # --- UPDATE SUCCESS REPORT WITH ANOMALY STATS ---
    #  Calculate stats per group from the final results
    group_stats = anomaly_final.groupby(unique_ids)['is_Anomaly'].agg(
        anomalies='sum',
        # Multiply mean by 100 and round to 1 decimal
        anomaly_rate=lambda x: round(x.mean() * 100, 1)
    ).reset_index()

    # 2. Merge these stats into the success_report
    evaluation_report = success_report.merge(group_stats, on=unique_ids, how='left')
    
    ## ---------- DASHBOARD ----------------##
    # -----1. Sucess_message -----------
    print_success_message(anomaly_final,unique_ids, is_assigned)
    
    # ------2. Data health Summary ----------------
    anomaly_summary_chart(anomaly_final, evaluation_report, unique_ids)
    
    print("")

    # ----------3. Pie chart ------------------------------
    # ------------------------------
    
    # Get data for pie chart
    pie_chart_df = anomaly_final['is_Anomaly'].value_counts().reset_index()
    pie_chart_df['is_Anomaly'] = np.where(pie_chart_df['is_Anomaly'] == True, 'Anomalous Records', 'Normal Records')
    pie_chart_df = pie_chart_df.rename(columns={'is_Anomaly': 'Records'})
    # Pie chart
    summary_pie_plot(pie_chart_df, title=f"Anomaly Detection Summary for {len(anomaly_final[unique_ids].drop_duplicates())} Unique IDs")
    
    # -------------------4. Stacked anomaly chart --------------------------------------------------
    anomaly_stacked_bar_plot(anomaly_final, unique_ids, variable, date_column, secondary_line=variable)
    
    # -------------------5. Anomaly score distribution plot --------------------------------------------------
    # Anomaly score distribution plot
    anomaly_variable_score_plot(anomaly_final, unique_ids, variable, date_column)
    
    # -------------------6. model_performance_chart --------------------------------------------------
    model_performance_chart(anomaly_final)

    # -------------------7. Top 5 anomalous groups stats --------------------------------------------------
    top_5_anomaly_groups = rank_anomaly_impact(anomaly_final, unique_ids, variable, eval_period)
    
    top_anomaly_stats(top_5_anomaly_groups, unique_ids)

    # ------------------------------------8. Top 5 anomalous groups charts ---------------------------------
    display_top_anomaly_plots(top_5_anomaly_groups, anomaly_final, unique_ids, variable, date_column, eval_period)
    
    # ------------------------------------9. help function  --------------------------------------------------
    display_help_code_block(top_5_anomaly_groups, unique_ids, variable, date_column, eval_period)
 

    anomaly_final = anomaly_final.drop(["normal_val","anomaly_val"], axis =1)
    
    return anomaly_final, evaluation_report

