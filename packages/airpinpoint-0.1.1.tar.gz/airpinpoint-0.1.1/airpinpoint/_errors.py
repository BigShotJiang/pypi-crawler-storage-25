from __future__ import annotations

from typing import Any, Dict, Optional


class AirPinpointError(Exception):
    """Base error for all AirPinpoint SDK errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class APIError(AirPinpointError):
    """Error returned by the AirPinpoint API."""

    status_code: int
    body: Any
    headers: Dict[str, str]
    code: Optional[str]

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        body: Any = None,
        headers: Optional[Dict[str, str]] = None,
        code: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body
        self.headers = headers or {}
        self.code = code

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(status_code={self.status_code}, "
            f"message={self.message!r})"
        )


class AuthenticationError(APIError):
    """401 Unauthorized."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(status_code=401, **kwargs)


class NotFoundError(APIError):
    """404 Not Found."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(status_code=404, **kwargs)


class ValidationError(APIError):
    """400 Bad Request."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(status_code=400, **kwargs)


class RateLimitError(APIError):
    """429 Too Many Requests."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(status_code=429, **kwargs)


class InternalError(APIError):
    """500+ Server Error."""

    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 500)
        super().__init__(**kwargs)


class APIConnectionError(AirPinpointError):
    """Network-level connection error."""

    def __init__(self, message: str = "Connection error", *, cause: Optional[Exception] = None) -> None:
        super().__init__(message)
        self.cause = cause


class WebhookSignatureError(AirPinpointError):
    """Invalid webhook signature."""

    pass


def _make_error(
    status_code: int,
    body: Any,
    headers: Optional[Dict[str, str]] = None,
) -> APIError:
    """Factory function to create the appropriate error subclass."""
    if isinstance(body, dict):
        message = body.get("detail", str(body))
    else:
        message = str(body) if body else f"HTTP {status_code}"

    kwargs: Dict[str, Any] = dict(message=message, body=body, headers=headers)

    if status_code == 400:
        return ValidationError(**kwargs)
    if status_code == 401:
        return AuthenticationError(**kwargs)
    if status_code == 404:
        return NotFoundError(**kwargs)
    if status_code == 429:
        return RateLimitError(**kwargs)
    if status_code >= 500:
        return InternalError(status_code=status_code, **kwargs)
    return APIError(status_code=status_code, **kwargs)
