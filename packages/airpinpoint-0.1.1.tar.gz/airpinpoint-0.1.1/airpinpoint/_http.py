from __future__ import annotations

import logging
import random
import time
from typing import Any, Dict, List, Optional, Type, TypeVar, Union

import httpx
from pydantic import BaseModel

from ._constants import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT_CONNECT,
    DEFAULT_TIMEOUT_POOL,
    DEFAULT_TIMEOUT_READ,
    DEFAULT_TIMEOUT_WRITE,
    VERSION,
)
from ._errors import APIConnectionError, _make_error
from ._types import Body, Headers, Query

logger = logging.getLogger("airpinpoint")

T = TypeVar("T", bound=BaseModel)

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def _default_timeout() -> httpx.Timeout:
    return httpx.Timeout(
        connect=DEFAULT_TIMEOUT_CONNECT,
        read=DEFAULT_TIMEOUT_READ,
        write=DEFAULT_TIMEOUT_WRITE,
        pool=DEFAULT_TIMEOUT_POOL,
    )


def _default_headers(api_key: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": f"AirPinpoint-Python/{VERSION}",
    }


def _backoff_delay(attempt: int) -> float:
    delay = min(0.5 * (2**attempt) + random.random() * 0.5, 8.0)
    return delay


def _should_retry(response: httpx.Response) -> bool:
    return response.status_code in _RETRYABLE_STATUS_CODES


def _parse_response(response: httpx.Response) -> Any:
    if response.status_code == 204:
        return None
    try:
        data = response.json()
    except Exception:
        data = response.text
    if response.is_success:
        return data
    headers = dict(response.headers)
    raise _make_error(response.status_code, data, headers)


def _build_query(params: Query) -> Dict[str, str]:
    """Serialize query params, omitting None values and converting types."""
    result: Dict[str, str] = {}
    for key, value in params.items():
        if value is None:
            continue
        if isinstance(value, bool):
            result[key] = str(value).lower()
        elif hasattr(value, "isoformat"):
            result[key] = value.isoformat()
        else:
            result[key] = str(value)
    return result


class SyncHTTPClient:
    """Synchronous HTTP client wrapping httpx.Client."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Headers] = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        headers = _default_headers(api_key)
        if default_headers:
            headers.update(default_headers)
        self._client = httpx.Client(
            timeout=timeout or _default_timeout(),
            headers=headers,
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        query: Optional[Query] = None,
        body: Body = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        params = _build_query(query) if query else None
        json_body = body

        logger.debug("%s %s params=%s", method, url, params)

        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(
                    method, url, params=params, json=json_body
                )
            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    time.sleep(_backoff_delay(attempt))
                    continue
                raise APIConnectionError(
                    message=f"Connection error: {exc}", cause=exc
                ) from exc

            if _should_retry(response) and attempt < self._max_retries:
                retry_after = response.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = float(retry_after)
                    except ValueError:
                        delay = _backoff_delay(attempt)
                else:
                    delay = _backoff_delay(attempt)
                logger.debug(
                    "Retrying %s %s (attempt %d, status %d, delay %.2fs)",
                    method, url, attempt + 1, response.status_code, delay,
                )
                time.sleep(delay)
                continue

            return _parse_response(response)

        if last_exc is not None:
            raise APIConnectionError(
                message=f"Connection error after {self._max_retries + 1} attempts",
                cause=last_exc,
            )
        raise APIConnectionError(message="Max retries exceeded")

    def get(self, path: str, *, query: Optional[Query] = None) -> Any:
        return self.request("GET", path, query=query)

    def post(self, path: str, *, body: Body = None, query: Optional[Query] = None) -> Any:
        return self.request("POST", path, body=body, query=query)

    def patch(self, path: str, *, body: Body = None) -> Any:
        return self.request("PATCH", path, body=body)

    def delete(self, path: str) -> Any:
        return self.request("DELETE", path)

    def close(self) -> None:
        self._client.close()


class AsyncHTTPClient:
    """Asynchronous HTTP client wrapping httpx.AsyncClient."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Headers] = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        headers = _default_headers(api_key)
        if default_headers:
            headers.update(default_headers)
        self._client = httpx.AsyncClient(
            timeout=timeout or _default_timeout(),
            headers=headers,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        query: Optional[Query] = None,
        body: Body = None,
    ) -> Any:
        import asyncio

        url = f"{self._base_url}{path}"
        params = _build_query(query) if query else None
        json_body = body

        logger.debug("%s %s params=%s", method, url, params)

        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(
                    method, url, params=params, json=json_body
                )
            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    await asyncio.sleep(_backoff_delay(attempt))
                    continue
                raise APIConnectionError(
                    message=f"Connection error: {exc}", cause=exc
                ) from exc

            if _should_retry(response) and attempt < self._max_retries:
                retry_after = response.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = float(retry_after)
                    except ValueError:
                        delay = _backoff_delay(attempt)
                else:
                    delay = _backoff_delay(attempt)
                logger.debug(
                    "Retrying %s %s (attempt %d, status %d, delay %.2fs)",
                    method, url, attempt + 1, response.status_code, delay,
                )
                await asyncio.sleep(delay)
                continue

            return _parse_response(response)

        if last_exc is not None:
            raise APIConnectionError(
                message=f"Connection error after {self._max_retries + 1} attempts",
                cause=last_exc,
            )
        raise APIConnectionError(message="Max retries exceeded")

    async def get(self, path: str, *, query: Optional[Query] = None) -> Any:
        return await self.request("GET", path, query=query)

    async def post(self, path: str, *, body: Body = None, query: Optional[Query] = None) -> Any:
        return await self.request("POST", path, body=body, query=query)

    async def patch(self, path: str, *, body: Body = None) -> Any:
        return await self.request("PATCH", path, body=body)

    async def delete(self, path: str) -> Any:
        return await self.request("DELETE", path)

    async def close(self) -> None:
        await self._client.aclose()
