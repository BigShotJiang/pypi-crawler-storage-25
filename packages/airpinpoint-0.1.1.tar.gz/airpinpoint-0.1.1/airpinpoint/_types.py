from __future__ import annotations

from typing import Any, Dict, Optional, Union


class _NotGiven:
    """Sentinel to distinguish 'not provided' from None in PATCH requests.

    NOT_GIVEN fields are omitted from the request body entirely.
    None fields are sent as JSON null.
    """

    _instance: Optional[_NotGiven] = None

    def __new__(cls) -> _NotGiven:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "NOT_GIVEN"

    def __bool__(self) -> bool:
        return False


NOT_GIVEN = _NotGiven()
NotGivenOr = Union[_NotGiven, Any]

Headers = Dict[str, str]
Query = Dict[str, Any]
Body = Optional[Dict[str, Any]]
