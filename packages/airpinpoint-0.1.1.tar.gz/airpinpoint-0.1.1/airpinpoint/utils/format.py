from __future__ import annotations

from typing import Any, Dict, List, Sequence, Tuple

from .geo import _get_coords


def to_geojson(locations: Sequence[Any]) -> Dict[str, Any]:
    """Convert a sequence of locations to a GeoJSON FeatureCollection of Points."""
    features = [to_geojson_point(loc) for loc in locations]
    return {
        "type": "FeatureCollection",
        "features": features,
    }


def to_geojson_point(location: Any) -> Dict[str, Any]:
    """Convert a single location to a GeoJSON Feature<Point>."""
    lat, lng = _get_coords(location)
    properties: Dict[str, Any] = {}
    for attr in ("id", "name", "timestamp", "horizontal_accuracy", "battery_level"):
        val = getattr(location, attr, None)
        if val is not None:
            if hasattr(val, "isoformat"):
                val = val.isoformat()
            properties[attr] = val
    altitude = getattr(location, "altitude", None)
    coords: List[float] = [lng, lat]
    if altitude is not None:
        coords.append(float(altitude))
    return {
        "type": "Feature",
        "geometry": {
            "type": "Point",
            "coordinates": coords,
        },
        "properties": properties,
    }


def to_geojson_line_string(locations: Sequence[Any]) -> Dict[str, Any]:
    """Convert a sequence of locations to a GeoJSON Feature<LineString>."""
    coordinates: List[List[float]] = []
    for loc in locations:
        lat, lng = _get_coords(loc)
        altitude = getattr(loc, "altitude", None)
        coord: List[float] = [lng, lat]
        if altitude is not None:
            coord.append(float(altitude))
        coordinates.append(coord)
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": coordinates,
        },
        "properties": {},
    }


def encode_polyline(locations: Sequence[Any], precision: int = 5) -> str:
    """Encode locations to a Google Encoded Polyline string."""
    result: List[str] = []
    prev_lat = 0
    prev_lng = 0
    factor = 10**precision

    for loc in locations:
        lat, lng = _get_coords(loc)
        lat_e5 = round(lat * factor)
        lng_e5 = round(lng * factor)

        result.append(_encode_value(lat_e5 - prev_lat))
        result.append(_encode_value(lng_e5 - prev_lng))

        prev_lat = lat_e5
        prev_lng = lng_e5

    return "".join(result)


def decode_polyline(encoded: str, precision: int = 5) -> List[Tuple[float, float]]:
    """Decode a Google Encoded Polyline string to a list of (latitude, longitude) tuples."""
    coordinates: List[Tuple[float, float]] = []
    index = 0
    lat = 0
    lng = 0
    factor = 10**precision

    while index < len(encoded):
        lat_delta, index = _decode_value(encoded, index)
        lng_delta, index = _decode_value(encoded, index)
        lat += lat_delta
        lng += lng_delta
        coordinates.append((lat / factor, lng / factor))

    return coordinates


def _encode_value(value: int) -> str:
    value = ~(value << 1) if value < 0 else (value << 1)
    chunks: List[str] = []
    while value >= 0x20:
        chunks.append(chr((0x20 | (value & 0x1F)) + 63))
        value >>= 5
    chunks.append(chr(value + 63))
    return "".join(chunks)


def _decode_value(encoded: str, index: int) -> Tuple[int, int]:
    result = 0
    shift = 0
    while True:
        b = ord(encoded[index]) - 63
        index += 1
        result |= (b & 0x1F) << shift
        shift += 5
        if b < 0x20:
            break
    return (~(result >> 1) if (result & 1) else (result >> 1)), index
