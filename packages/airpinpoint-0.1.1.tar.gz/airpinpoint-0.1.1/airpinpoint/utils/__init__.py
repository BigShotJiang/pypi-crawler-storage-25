from __future__ import annotations

from .analysis import (
    Stop,
    Trip,
    cluster_locations,
    detect_stops,
    detect_trips,
    dwell_time,
    simplify_path,
    speed,
)
from .battery import battery_health_status, estimate_battery_days_remaining
from .filter import deduplicate, filter_by_accuracy, filter_by_speed, filter_stale
from .format import (
    decode_polyline,
    encode_polyline,
    to_geojson,
    to_geojson_line_string,
    to_geojson_point,
)
from .geo import (
    bearing,
    buffer_geofence,
    distance,
    distance_to_geofence,
    is_inside_circle,
    is_inside_geofence,
    is_inside_polygon,
)

__all__ = [
    "Stop",
    "Trip",
    "battery_health_status",
    "bearing",
    "buffer_geofence",
    "cluster_locations",
    "decode_polyline",
    "deduplicate",
    "detect_stops",
    "detect_trips",
    "distance",
    "distance_to_geofence",
    "dwell_time",
    "encode_polyline",
    "estimate_battery_days_remaining",
    "filter_by_accuracy",
    "filter_by_speed",
    "filter_stale",
    "is_inside_circle",
    "is_inside_geofence",
    "is_inside_polygon",
    "simplify_path",
    "speed",
    "to_geojson",
    "to_geojson_line_string",
    "to_geojson_point",
]
