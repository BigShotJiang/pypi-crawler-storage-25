from __future__ import annotations

import math
from typing import Any, List, Protocol, Sequence, runtime_checkable

EARTH_RADIUS_M = 6_371_008.8


@runtime_checkable
class HasCoords(Protocol):
    @property
    def latitude(self) -> float | None: ...
    @property
    def longitude(self) -> float | None: ...


def _to_rad(deg: float) -> float:
    return deg * math.pi / 180.0


def _to_deg(rad: float) -> float:
    return rad * 180.0 / math.pi


def _get_coords(obj: Any) -> tuple[float, float]:
    lat = getattr(obj, "latitude", None)
    lng = getattr(obj, "longitude", None)
    if lat is None or lng is None:
        raise ValueError(f"Object must have non-null latitude and longitude, got {lat}, {lng}")
    return float(lat), float(lng)


def distance(a: Any, b: Any) -> float:
    """Haversine distance in meters between two points.

    Accepts any objects with .latitude and .longitude attributes.
    """
    lat1, lon1 = _get_coords(a)
    lat2, lon2 = _get_coords(b)

    d_lat = _to_rad(lat2 - lat1)
    d_lon = _to_rad(lon2 - lon1)

    a_val = (
        math.sin(d_lat / 2) ** 2
        + math.cos(_to_rad(lat1)) * math.cos(_to_rad(lat2)) * math.sin(d_lon / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a_val), math.sqrt(1 - a_val))
    return EARTH_RADIUS_M * c


def bearing(a: Any, b: Any) -> float:
    """Forward azimuth in degrees [0, 360) from point a to point b."""
    lat1, lon1 = _get_coords(a)
    lat2, lon2 = _get_coords(b)

    d_lon = _to_rad(lon2 - lon1)
    lat1_r = _to_rad(lat1)
    lat2_r = _to_rad(lat2)

    x = math.sin(d_lon) * math.cos(lat2_r)
    y = math.cos(lat1_r) * math.sin(lat2_r) - math.sin(lat1_r) * math.cos(lat2_r) * math.cos(d_lon)
    theta = math.atan2(x, y)
    return (_to_deg(theta) + 360) % 360


def is_inside_circle(point: Any, center: Any, radius_m: float) -> bool:
    """Check if a point is within a circle defined by center and radius in meters."""
    return distance(point, center) <= radius_m


def is_inside_polygon(point: Any, polygon: Sequence[Any]) -> bool:
    """Ray-casting point-in-polygon test.

    polygon: sequence of objects with .latitude/.longitude forming a closed ring.
    """
    px, py = _get_coords(point)
    n = len(polygon)
    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = _get_coords(polygon[i])
        xj, yj = _get_coords(polygon[j])
        if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


def is_inside_geofence(point: Any, geofence: Any) -> bool:
    """Check if a point is inside a circular geofence (GeofenceBase-compatible object)."""
    return is_inside_circle(point, geofence, geofence.radius)


def distance_to_geofence(point: Any, geofence: Any) -> float:
    """Distance in meters from a point to the nearest edge of a circular geofence.

    Returns 0 if inside.
    """
    d = distance(point, geofence)
    return max(0.0, d - geofence.radius)


def buffer_geofence(geofence: Any, meters: float) -> Any:
    """Return a copy of a geofence with the radius expanded (or shrunk) by meters.

    Works with any object that has .latitude, .longitude, .radius, .name, .id.
    Returns a dict with the geofence attributes.
    """
    return {
        "id": getattr(geofence, "id", None),
        "name": getattr(geofence, "name", None),
        "latitude": geofence.latitude,
        "longitude": geofence.longitude,
        "radius": max(0.0, geofence.radius + meters),
    }
