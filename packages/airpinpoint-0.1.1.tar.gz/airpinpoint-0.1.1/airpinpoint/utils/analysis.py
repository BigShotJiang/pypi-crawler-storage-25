from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence

from .geo import _get_coords, distance


@dataclass
class Stop:
    """A detected stop (dwell cluster)."""
    center_latitude: float
    center_longitude: float
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    duration_ms: float
    location_count: int
    locations: List[Any] = field(default_factory=list)


@dataclass
class Trip:
    """A detected trip segment between stops."""
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    distance_m: float
    duration_ms: float
    locations: List[Any] = field(default_factory=list)


def _get_timestamp(obj: Any) -> Optional[datetime]:
    ts = getattr(obj, "timestamp", None)
    if ts is None:
        ts = getattr(obj, "created_at", None)
    if isinstance(ts, str):
        return datetime.fromisoformat(ts)
    return ts


def speed(loc1: Any, loc2: Any) -> float:
    """Speed in m/s between two timestamped locations."""
    d = distance(loc1, loc2)
    t1 = _get_timestamp(loc1)
    t2 = _get_timestamp(loc2)
    if t1 is None or t2 is None:
        raise ValueError("Both locations must have timestamps to calculate speed")
    dt = abs((t2 - t1).total_seconds())
    if dt == 0:
        return 0.0
    return d / dt


def detect_stops(
    locations: Sequence[Any],
    *,
    radius_m: float = 50.0,
    min_duration_ms: float = 300_000,
) -> List[Stop]:
    """Identify dwell clusters in a sequence of locations.

    A stop is a cluster of points within radius_m that spans at least min_duration_ms.
    """
    if len(locations) < 2:
        return []

    stops: List[Stop] = []
    cluster: List[Any] = [locations[0]]

    for i in range(1, len(locations)):
        loc = locations[i]
        anchor = cluster[0]
        d = distance(anchor, loc)

        if d <= radius_m:
            cluster.append(loc)
        else:
            t_start = _get_timestamp(cluster[0])
            t_end = _get_timestamp(cluster[-1])
            if t_start and t_end:
                dur = (t_end - t_start).total_seconds() * 1000
            else:
                dur = 0
            if dur >= min_duration_ms and len(cluster) >= 2:
                lats = [_get_coords(c)[0] for c in cluster]
                lngs = [_get_coords(c)[1] for c in cluster]
                stops.append(
                    Stop(
                        center_latitude=sum(lats) / len(lats),
                        center_longitude=sum(lngs) / len(lngs),
                        start_time=t_start,
                        end_time=t_end,
                        duration_ms=dur,
                        location_count=len(cluster),
                        locations=list(cluster),
                    )
                )
            cluster = [loc]

    # Handle last cluster
    if len(cluster) >= 2:
        t_start = _get_timestamp(cluster[0])
        t_end = _get_timestamp(cluster[-1])
        if t_start and t_end:
            dur = (t_end - t_start).total_seconds() * 1000
        else:
            dur = 0
        if dur >= min_duration_ms:
            lats = [_get_coords(c)[0] for c in cluster]
            lngs = [_get_coords(c)[1] for c in cluster]
            stops.append(
                Stop(
                    center_latitude=sum(lats) / len(lats),
                    center_longitude=sum(lngs) / len(lngs),
                    start_time=t_start,
                    end_time=t_end,
                    duration_ms=dur,
                    location_count=len(cluster),
                    locations=list(cluster),
                )
            )

    return stops


def detect_trips(
    locations: Sequence[Any],
    *,
    stop_radius_m: float = 50.0,
    stop_min_duration_ms: float = 300_000,
) -> List[Trip]:
    """Identify trip segments between stops."""
    stops = detect_stops(
        locations, radius_m=stop_radius_m, min_duration_ms=stop_min_duration_ms
    )
    if not stops:
        if len(locations) >= 2:
            total_dist = sum(
                distance(locations[i], locations[i + 1])
                for i in range(len(locations) - 1)
            )
            t_start = _get_timestamp(locations[0])
            t_end = _get_timestamp(locations[-1])
            dur = (t_end - t_start).total_seconds() * 1000 if t_start and t_end else 0
            return [
                Trip(
                    start_time=t_start,
                    end_time=t_end,
                    distance_m=total_dist,
                    duration_ms=dur,
                    locations=list(locations),
                )
            ]
        return []

    trips: List[Trip] = []
    stop_set = set()
    for s in stops:
        for loc in s.locations:
            stop_set.add(id(loc))

    current_trip: List[Any] = []
    for loc in locations:
        if id(loc) in stop_set:
            if len(current_trip) >= 2:
                total_dist = sum(
                    distance(current_trip[i], current_trip[i + 1])
                    for i in range(len(current_trip) - 1)
                )
                t_start = _get_timestamp(current_trip[0])
                t_end = _get_timestamp(current_trip[-1])
                dur = (t_end - t_start).total_seconds() * 1000 if t_start and t_end else 0
                trips.append(
                    Trip(
                        start_time=t_start,
                        end_time=t_end,
                        distance_m=total_dist,
                        duration_ms=dur,
                        locations=current_trip,
                    )
                )
            current_trip = []
        else:
            current_trip.append(loc)

    if len(current_trip) >= 2:
        total_dist = sum(
            distance(current_trip[i], current_trip[i + 1])
            for i in range(len(current_trip) - 1)
        )
        t_start = _get_timestamp(current_trip[0])
        t_end = _get_timestamp(current_trip[-1])
        dur = (t_end - t_start).total_seconds() * 1000 if t_start and t_end else 0
        trips.append(
            Trip(
                start_time=t_start,
                end_time=t_end,
                distance_m=total_dist,
                duration_ms=dur,
                locations=current_trip,
            )
        )

    return trips


def dwell_time(locations: Sequence[Any], geofence: Any) -> float:
    """Total milliseconds spent inside a geofence.

    Sums time between consecutive in-fence location pairs.
    """
    from .geo import is_inside_geofence

    total_ms = 0.0
    prev_inside = False
    prev_ts: Optional[datetime] = None

    for loc in locations:
        inside = is_inside_geofence(loc, geofence)
        ts = _get_timestamp(loc)

        if inside and prev_inside and ts and prev_ts:
            total_ms += abs((ts - prev_ts).total_seconds()) * 1000

        prev_inside = inside
        prev_ts = ts

    return total_ms


def simplify_path(
    locations: Sequence[Any],
    tolerance_m: float = 10.0,
) -> List[Any]:
    """Douglas-Peucker path simplification using distance tolerance in meters."""
    if len(locations) <= 2:
        return list(locations)

    max_dist = 0.0
    max_idx = 0
    start = locations[0]
    end = locations[-1]

    for i in range(1, len(locations) - 1):
        d = _point_to_line_distance(locations[i], start, end)
        if d > max_dist:
            max_dist = d
            max_idx = i

    if max_dist > tolerance_m:
        left = simplify_path(locations[: max_idx + 1], tolerance_m)
        right = simplify_path(locations[max_idx:], tolerance_m)
        return left[:-1] + right
    else:
        return [locations[0], locations[-1]]


def _point_to_line_distance(point: Any, line_start: Any, line_end: Any) -> float:
    """Approximate cross-track distance from a point to a great-circle line."""
    d_start = distance(line_start, point)
    d_total = distance(line_start, line_end)
    if d_total == 0:
        return d_start

    from .geo import _to_rad, bearing as calc_bearing

    bearing_start_end = _to_rad(calc_bearing(line_start, line_end))
    bearing_start_point = _to_rad(calc_bearing(line_start, point))

    import math

    cross_track = abs(
        math.asin(
            math.sin(d_start / 6_371_008.8)
            * math.sin(bearing_start_point - bearing_start_end)
        )
        * 6_371_008.8
    )
    return cross_track


def cluster_locations(
    locations: Sequence[Any],
    *,
    radius_m: float = 100.0,
    min_points: int = 2,
) -> List[List[Any]]:
    """DBSCAN-style density clustering of locations.

    Returns a list of clusters, where each cluster is a list of locations.
    """
    visited = set()
    clusters: List[List[Any]] = []

    for i, loc in enumerate(locations):
        if i in visited:
            continue

        neighbors = []
        for j, other in enumerate(locations):
            if distance(loc, other) <= radius_m:
                neighbors.append(j)

        if len(neighbors) < min_points:
            continue

        cluster: List[Any] = []
        queue = list(neighbors)
        for idx in queue:
            if idx in visited:
                continue
            visited.add(idx)
            cluster.append(locations[idx])

            sub_neighbors = []
            for j, other in enumerate(locations):
                if distance(locations[idx], other) <= radius_m:
                    sub_neighbors.append(j)
            if len(sub_neighbors) >= min_points:
                for sn in sub_neighbors:
                    if sn not in visited:
                        queue.append(sn)

        if cluster:
            clusters.append(cluster)

    return clusters
