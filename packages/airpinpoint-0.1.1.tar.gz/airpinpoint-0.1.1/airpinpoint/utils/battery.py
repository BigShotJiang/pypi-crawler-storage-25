from __future__ import annotations

from typing import Any, Optional


def estimate_battery_days_remaining(battery_info: Any) -> Optional[int]:
    """Estimate days of battery remaining from a BatteryInfo object.

    Uses estimated_days_remaining if available, otherwise calculates from
    battery_percentage assuming linear drain over battery_months.
    """
    edr = getattr(battery_info, "estimated_days_remaining", None)
    if edr is not None:
        return int(edr)

    pct = getattr(battery_info, "battery_percentage", None)
    months = getattr(battery_info, "battery_months", None)
    if pct is not None and months is not None and months > 0:
        total_days = months * 30
        return int(total_days * (pct / 100.0))

    return None


def battery_health_status(battery_info: Any) -> str:
    """Return battery health status: 'good', 'low', 'critical', or 'replace'.

    Thresholds:
    - good: > 30 days or > 30%
    - low: 15-30 days or 15-30%
    - critical: 1-14 days or 5-14%
    - replace: 0 days or < 5%
    """
    days = estimate_battery_days_remaining(battery_info)
    pct = getattr(battery_info, "battery_percentage", None)

    if days is not None:
        if days <= 0:
            return "replace"
        if days <= 14:
            return "critical"
        if days <= 30:
            return "low"
        return "good"

    if pct is not None:
        pct = float(pct)
        if pct < 5:
            return "replace"
        if pct < 15:
            return "critical"
        if pct < 30:
            return "low"
        return "good"

    return "good"
