from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, List, Optional, Sequence

from .geo import _get_coords, distance


def filter_by_accuracy(
    locations: Sequence[Any],
    max_accuracy_m: float,
) -> List[Any]:
    """Keep only locations with horizontal accuracy <= max_accuracy_m.

    Locations without horizontal_accuracy are kept (assumed valid).
    """
    result: List[Any] = []
    for loc in locations:
        acc = getattr(loc, "horizontal_accuracy", None)
        if acc is None or acc <= max_accuracy_m:
            result.append(loc)
    return result


def filter_by_speed(
    locations: Sequence[Any],
    max_speed_mps: float,
) -> List[Any]:
    """Remove GPS teleport jumps by filtering locations that imply impossible speed.

    Compares consecutive pairs. The first location is always kept.
    """
    if len(locations) == 0:
        return []

    result: List[Any] = [locations[0]]
    for i in range(1, len(locations)):
        d = distance(locations[i - 1], locations[i])
        t1 = _get_ts(locations[i - 1])
        t2 = _get_ts(locations[i])
        if t1 is not None and t2 is not None:
            dt = abs((t2 - t1).total_seconds())
            if dt > 0 and d / dt > max_speed_mps:
                continue
        result.append(locations[i])
    return result


def filter_stale(
    locations: Sequence[Any],
    max_age_ms: float,
    *,
    now: Optional[datetime] = None,
) -> List[Any]:
    """Remove locations older than max_age_ms milliseconds."""
    reference = now or datetime.now(timezone.utc)
    result: List[Any] = []
    for loc in locations:
        ts = _get_ts(loc)
        if ts is None:
            result.append(loc)
            continue
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        age_ms = (reference - ts).total_seconds() * 1000
        if age_ms <= max_age_ms:
            result.append(loc)
    return result


def deduplicate(
    locations: Sequence[Any],
    *,
    distance_threshold_m: float = 1.0,
    time_threshold_ms: float = 1000.0,
) -> List[Any]:
    """Remove near-duplicate locations.

    Two consecutive locations are considered duplicates if they are both
    within distance_threshold_m and time_threshold_ms of each other.
    """
    if len(locations) == 0:
        return []

    result: List[Any] = [locations[0]]
    for i in range(1, len(locations)):
        prev = result[-1]
        curr = locations[i]

        d = distance(prev, curr)
        if d > distance_threshold_m:
            result.append(curr)
            continue

        t1 = _get_ts(prev)
        t2 = _get_ts(curr)
        if t1 is not None and t2 is not None:
            dt_ms = abs((t2 - t1).total_seconds()) * 1000
            if dt_ms > time_threshold_ms:
                result.append(curr)
                continue
        else:
            result.append(curr)
            continue

    return result


def _get_ts(obj: Any) -> Optional[datetime]:
    ts = getattr(obj, "timestamp", None)
    if ts is None:
        ts = getattr(obj, "created_at", None)
    if isinstance(ts, str):
        return datetime.fromisoformat(ts)
    return ts
