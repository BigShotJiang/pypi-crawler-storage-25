from __future__ import annotations

import os
from typing import Optional

import httpx

from ._constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES
from ._http import AsyncHTTPClient, SyncHTTPClient, _default_timeout
from ._types import Headers
from .resources.account import Account, AsyncAccount
from .resources.geofences import AsyncGeofences, Geofences
from .resources.share_links import AsyncShareLinks, ShareLinks
from .resources.trackables import AsyncTrackables, Trackables
from .resources.usage import AsyncUsage, Usage


class AirPinpoint:
    """Synchronous AirPinpoint API client.

    Usage:
        client = AirPinpoint(api_key="...")
        trackables = client.trackables.list()

        # As context manager
        with AirPinpoint(api_key="...") as client:
            trackables = client.trackables.list()
    """

    trackables: Trackables
    geofences: Geofences
    share_links: ShareLinks
    account: Account
    usage: Usage

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Headers] = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("AIRPINPOINT_API_KEY")
        if not resolved_key:
            raise ValueError(
                "api_key must be provided or set AIRPINPOINT_API_KEY environment variable"
            )

        self._http = SyncHTTPClient(
            api_key=resolved_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )

        self.trackables = Trackables(self._http)
        self.geofences = Geofences(self._http)
        self.share_links = ShareLinks(self._http)
        self.account = Account(self._http)
        self.usage = Usage(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> AirPinpoint:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncAirPinpoint:
    """Asynchronous AirPinpoint API client.

    Usage:
        client = AsyncAirPinpoint(api_key="...")
        trackables = await client.trackables.list()

        # As context manager
        async with AsyncAirPinpoint(api_key="...") as client:
            trackables = await client.trackables.list()
    """

    trackables: AsyncTrackables
    geofences: AsyncGeofences
    share_links: AsyncShareLinks
    account: AsyncAccount
    usage: AsyncUsage

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Headers] = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("AIRPINPOINT_API_KEY")
        if not resolved_key:
            raise ValueError(
                "api_key must be provided or set AIRPINPOINT_API_KEY environment variable"
            )

        self._http = AsyncHTTPClient(
            api_key=resolved_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )

        self.trackables = AsyncTrackables(self._http)
        self.geofences = AsyncGeofences(self._http)
        self.share_links = AsyncShareLinks(self._http)
        self.account = AsyncAccount(self._http)
        self.usage = AsyncUsage(self._http)

    async def close(self) -> None:
        await self._http.close()

    async def __aenter__(self) -> AsyncAirPinpoint:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
