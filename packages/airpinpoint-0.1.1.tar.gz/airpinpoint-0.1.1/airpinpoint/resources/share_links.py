from __future__ import annotations

from typing import Any, Dict

from .._http import AsyncHTTPClient, SyncHTTPClient


class ShareLinkResponse:
    """Response from creating a share link."""

    def __init__(self, share_url: str) -> None:
        self.share_url = share_url

    def __repr__(self) -> str:
        return f"ShareLinkResponse(share_url={self.share_url!r})"


class ShareLinks:
    """Synchronous share links resource."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def create(
        self,
        *,
        trackable_id: str,
        hours: int,
    ) -> ShareLinkResponse:
        data = self._client.post(
            "/share-links",
            body={"trackableId": trackable_id, "hours": hours},
        )
        return ShareLinkResponse(share_url=data["shareUrl"])


class AsyncShareLinks:
    """Asynchronous share links resource."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def create(
        self,
        *,
        trackable_id: str,
        hours: int,
    ) -> ShareLinkResponse:
        data = await self._client.post(
            "/share-links",
            body={"trackableId": trackable_id, "hours": hours},
        )
        return ShareLinkResponse(share_url=data["shareUrl"])
