from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._constants import DEFAULT_LIMIT
from .._http import AsyncHTTPClient, SyncHTTPClient
from .._pagination import AsyncPage, SyncPage
from .._types import NOT_GIVEN, NotGivenOr, _NotGiven
from ..types.geofence import GeofenceBase
from ..types.shared import Message
from ..types.webhook import (
    WebhookDeliveryBase,
    WebhookDeliveryDetail,
    WebhookTestResponse,
)


def _strip_not_given(d: Dict[str, Any]) -> Dict[str, Any]:
    """Remove NOT_GIVEN values from a dict for PATCH requests."""
    return {k: v for k, v in d.items() if not isinstance(v, _NotGiven)}


class GeofenceWebhooks:
    """Synchronous geofence webhook deliveries sub-resource."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def list(
        self,
        geofence_id: str,
        *,
        limit: int = DEFAULT_LIMIT,
        successful: Optional[bool] = None,
    ) -> SyncPage[WebhookDeliveryBase]:
        query: dict[str, Any] = {"limit": limit}
        if successful is not None:
            query["successful"] = successful
        data = self._client.get(
            f"/geofences/{geofence_id}/webhooks",
            query=query,
        )
        items = [WebhookDeliveryBase.model_validate(item) for item in data]
        return SyncPage(
            data=items,
            model=WebhookDeliveryBase,
            fetch_page=self.list,
            skip=0,
            limit=limit,
            extra_params={
                "geofence_id": geofence_id,
                "successful": successful,
            },
        )

    def retrieve(
        self,
        geofence_id: str,
        delivery_id: str,
    ) -> WebhookDeliveryDetail:
        data = self._client.get(
            f"/geofences/{geofence_id}/webhooks/{delivery_id}"
        )
        return WebhookDeliveryDetail.model_validate(data)


class AsyncGeofenceWebhooks:
    """Asynchronous geofence webhook deliveries sub-resource."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def list(
        self,
        geofence_id: str,
        *,
        limit: int = DEFAULT_LIMIT,
        successful: Optional[bool] = None,
    ) -> AsyncPage[WebhookDeliveryBase]:
        query: dict[str, Any] = {"limit": limit}
        if successful is not None:
            query["successful"] = successful
        data = await self._client.get(
            f"/geofences/{geofence_id}/webhooks",
            query=query,
        )
        items = [WebhookDeliveryBase.model_validate(item) for item in data]
        return AsyncPage(
            data=items,
            model=WebhookDeliveryBase,
            fetch_page=self.list,
            skip=0,
            limit=limit,
            extra_params={
                "geofence_id": geofence_id,
                "successful": successful,
            },
        )

    async def retrieve(
        self,
        geofence_id: str,
        delivery_id: str,
    ) -> WebhookDeliveryDetail:
        data = await self._client.get(
            f"/geofences/{geofence_id}/webhooks/{delivery_id}"
        )
        return WebhookDeliveryDetail.model_validate(data)


class Geofences:
    """Synchronous geofences resource."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client
        self.webhooks = GeofenceWebhooks(client)

    def list(
        self,
        *,
        skip: int = 0,
        limit: int = DEFAULT_LIMIT,
        trackable_id: Optional[str] = None,
    ) -> SyncPage[GeofenceBase]:
        query: dict[str, Any] = {"skip": skip, "limit": limit}
        if trackable_id is not None:
            query["trackable_id"] = trackable_id
        data = self._client.get("/geofences", query=query)
        items = [GeofenceBase.model_validate(item) for item in data]
        return SyncPage(
            data=items,
            model=GeofenceBase,
            fetch_page=self.list,
            skip=skip,
            limit=limit,
            extra_params={"trackable_id": trackable_id},
        )

    def create(
        self,
        *,
        name: str,
        latitude: float,
        longitude: float,
        radius: float,
        notify_type: Optional[str] = None,
        notify_destination: Optional[str] = None,
        trackable_id: Optional[List[str]] = None,
        webhook_secret: Optional[str] = None,
        webhook_enabled: Optional[bool] = None,
        webhook_headers: Optional[Dict[str, str]] = None,
    ) -> GeofenceBase:
        body: Dict[str, Any] = {
            "name": name,
            "latitude": latitude,
            "longitude": longitude,
            "radius": radius,
        }
        if notify_type is not None:
            body["notifyType"] = notify_type
        if notify_destination is not None:
            body["notifyDestination"] = notify_destination
        if trackable_id is not None:
            body["trackableId"] = trackable_id
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        if webhook_enabled is not None:
            body["webhookEnabled"] = webhook_enabled
        if webhook_headers is not None:
            body["webhookHeaders"] = webhook_headers
        data = self._client.post("/geofences", body=body)
        return GeofenceBase.model_validate(data)

    def update(
        self,
        geofence_id: str,
        *,
        name: NotGivenOr[Optional[str]] = NOT_GIVEN,
        latitude: NotGivenOr[Optional[float]] = NOT_GIVEN,
        longitude: NotGivenOr[Optional[float]] = NOT_GIVEN,
        radius: NotGivenOr[Optional[float]] = NOT_GIVEN,
        notify_type: NotGivenOr[Optional[str]] = NOT_GIVEN,
        notify_destination: NotGivenOr[Optional[str]] = NOT_GIVEN,
        trackable_id: NotGivenOr[Optional[List[str]]] = NOT_GIVEN,
        webhook_secret: NotGivenOr[Optional[str]] = NOT_GIVEN,
        webhook_enabled: NotGivenOr[Optional[bool]] = NOT_GIVEN,
        webhook_headers: NotGivenOr[Optional[Dict[str, str]]] = NOT_GIVEN,
    ) -> GeofenceBase:
        body = _strip_not_given(
            {
                "name": name,
                "latitude": latitude,
                "longitude": longitude,
                "radius": radius,
                "notifyType": notify_type,
                "notifyDestination": notify_destination,
                "trackableId": trackable_id,
                "webhookSecret": webhook_secret,
                "webhookEnabled": webhook_enabled,
                "webhookHeaders": webhook_headers,
            }
        )
        data = self._client.patch(f"/geofences/{geofence_id}", body=body)
        return GeofenceBase.model_validate(data)

    def delete(self, geofence_id: str) -> Message:
        data = self._client.delete(f"/geofences/{geofence_id}")
        return Message.model_validate(data)

    def test_webhook(
        self,
        geofence_id: str,
        *,
        event_type: str = "entry",
    ) -> WebhookTestResponse:
        data = self._client.post(
            f"/geofences/{geofence_id}/test-webhook",
            body={"geofenceId": geofence_id, "eventType": event_type},
        )
        return WebhookTestResponse.model_validate(data)


class AsyncGeofences:
    """Asynchronous geofences resource."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client
        self.webhooks = AsyncGeofenceWebhooks(client)

    async def list(
        self,
        *,
        skip: int = 0,
        limit: int = DEFAULT_LIMIT,
        trackable_id: Optional[str] = None,
    ) -> AsyncPage[GeofenceBase]:
        query: dict[str, Any] = {"skip": skip, "limit": limit}
        if trackable_id is not None:
            query["trackable_id"] = trackable_id
        data = await self._client.get("/geofences", query=query)
        items = [GeofenceBase.model_validate(item) for item in data]
        return AsyncPage(
            data=items,
            model=GeofenceBase,
            fetch_page=self.list,
            skip=skip,
            limit=limit,
            extra_params={"trackable_id": trackable_id},
        )

    async def create(
        self,
        *,
        name: str,
        latitude: float,
        longitude: float,
        radius: float,
        notify_type: Optional[str] = None,
        notify_destination: Optional[str] = None,
        trackable_id: Optional[List[str]] = None,
        webhook_secret: Optional[str] = None,
        webhook_enabled: Optional[bool] = None,
        webhook_headers: Optional[Dict[str, str]] = None,
    ) -> GeofenceBase:
        body: Dict[str, Any] = {
            "name": name,
            "latitude": latitude,
            "longitude": longitude,
            "radius": radius,
        }
        if notify_type is not None:
            body["notifyType"] = notify_type
        if notify_destination is not None:
            body["notifyDestination"] = notify_destination
        if trackable_id is not None:
            body["trackableId"] = trackable_id
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        if webhook_enabled is not None:
            body["webhookEnabled"] = webhook_enabled
        if webhook_headers is not None:
            body["webhookHeaders"] = webhook_headers
        data = await self._client.post("/geofences", body=body)
        return GeofenceBase.model_validate(data)

    async def update(
        self,
        geofence_id: str,
        *,
        name: NotGivenOr[Optional[str]] = NOT_GIVEN,
        latitude: NotGivenOr[Optional[float]] = NOT_GIVEN,
        longitude: NotGivenOr[Optional[float]] = NOT_GIVEN,
        radius: NotGivenOr[Optional[float]] = NOT_GIVEN,
        notify_type: NotGivenOr[Optional[str]] = NOT_GIVEN,
        notify_destination: NotGivenOr[Optional[str]] = NOT_GIVEN,
        trackable_id: NotGivenOr[Optional[List[str]]] = NOT_GIVEN,
        webhook_secret: NotGivenOr[Optional[str]] = NOT_GIVEN,
        webhook_enabled: NotGivenOr[Optional[bool]] = NOT_GIVEN,
        webhook_headers: NotGivenOr[Optional[Dict[str, str]]] = NOT_GIVEN,
    ) -> GeofenceBase:
        body = _strip_not_given(
            {
                "name": name,
                "latitude": latitude,
                "longitude": longitude,
                "radius": radius,
                "notifyType": notify_type,
                "notifyDestination": notify_destination,
                "trackableId": trackable_id,
                "webhookSecret": webhook_secret,
                "webhookEnabled": webhook_enabled,
                "webhookHeaders": webhook_headers,
            }
        )
        data = await self._client.patch(f"/geofences/{geofence_id}", body=body)
        return GeofenceBase.model_validate(data)

    async def delete(self, geofence_id: str) -> Message:
        data = await self._client.delete(f"/geofences/{geofence_id}")
        return Message.model_validate(data)

    async def test_webhook(
        self,
        geofence_id: str,
        *,
        event_type: str = "entry",
    ) -> WebhookTestResponse:
        data = await self._client.post(
            f"/geofences/{geofence_id}/test-webhook",
            body={"geofenceId": geofence_id, "eventType": event_type},
        )
        return WebhookTestResponse.model_validate(data)
