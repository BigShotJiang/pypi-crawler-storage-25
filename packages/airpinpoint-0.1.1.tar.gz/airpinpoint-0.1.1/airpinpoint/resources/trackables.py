from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

from .._constants import DEFAULT_LIMIT
from .._http import AsyncHTTPClient, SyncHTTPClient
from .._pagination import AsyncPage, SyncPage
from ..types.location import LocationBase
from ..types.shared import BatteryInfo, Message
from ..types.trackable import TrackableDetail


class Trackables:
    """Synchronous trackables resource."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def list(
        self,
        *,
        skip: int = 0,
        limit: int = DEFAULT_LIMIT,
    ) -> SyncPage[TrackableDetail]:
        data = self._client.get(
            "/trackables",
            query={"skip": skip, "limit": limit},
        )
        items = [TrackableDetail.model_validate(item) for item in data]
        return SyncPage(
            data=items,
            model=TrackableDetail,
            fetch_page=self.list,
            skip=skip,
            limit=limit,
        )

    def retrieve(self, trackable_id: str) -> TrackableDetail:
        data = self._client.get(f"/trackables/{trackable_id}")
        return TrackableDetail.model_validate(data)

    def current_location(self, trackable_id: str) -> LocationBase:
        data = self._client.get(f"/trackables/{trackable_id}/current_location")
        return LocationBase.model_validate(data)

    def location_history(
        self,
        trackable_id: str,
        *,
        skip: int = 0,
        limit: int = DEFAULT_LIMIT,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> SyncPage[LocationBase]:
        query: dict[str, Any] = {"skip": skip, "limit": limit}
        if start_time is not None:
            query["start_time"] = start_time
        if end_time is not None:
            query["end_time"] = end_time
        data = self._client.get(
            f"/trackables/{trackable_id}/locations",
            query=query,
        )
        items = [LocationBase.model_validate(item) for item in data]
        return SyncPage(
            data=items,
            model=LocationBase,
            fetch_page=self.location_history,
            skip=skip,
            limit=limit,
            extra_params={
                "trackable_id": trackable_id,
                "start_time": start_time,
                "end_time": end_time,
            },
        )

    def battery(self, trackable_id: str) -> BatteryInfo:
        data = self._client.get(f"/trackables/{trackable_id}/battery")
        return BatteryInfo.model_validate(data)

    def reset_battery(
        self,
        trackable_id: str,
        *,
        battery_months: int,
    ) -> Message:
        data = self._client.post(
            f"/trackables/{trackable_id}/battery",
            body={"batteryMonths": battery_months},
        )
        return Message.model_validate(data)


class AsyncTrackables:
    """Asynchronous trackables resource."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def list(
        self,
        *,
        skip: int = 0,
        limit: int = DEFAULT_LIMIT,
    ) -> AsyncPage[TrackableDetail]:
        data = await self._client.get(
            "/trackables",
            query={"skip": skip, "limit": limit},
        )
        items = [TrackableDetail.model_validate(item) for item in data]
        return AsyncPage(
            data=items,
            model=TrackableDetail,
            fetch_page=self.list,
            skip=skip,
            limit=limit,
        )

    async def retrieve(self, trackable_id: str) -> TrackableDetail:
        data = await self._client.get(f"/trackables/{trackable_id}")
        return TrackableDetail.model_validate(data)

    async def current_location(self, trackable_id: str) -> LocationBase:
        data = await self._client.get(
            f"/trackables/{trackable_id}/current_location"
        )
        return LocationBase.model_validate(data)

    async def location_history(
        self,
        trackable_id: str,
        *,
        skip: int = 0,
        limit: int = DEFAULT_LIMIT,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> AsyncPage[LocationBase]:
        query: dict[str, Any] = {"skip": skip, "limit": limit}
        if start_time is not None:
            query["start_time"] = start_time
        if end_time is not None:
            query["end_time"] = end_time
        data = await self._client.get(
            f"/trackables/{trackable_id}/locations",
            query=query,
        )
        items = [LocationBase.model_validate(item) for item in data]
        return AsyncPage(
            data=items,
            model=LocationBase,
            fetch_page=self.location_history,
            skip=skip,
            limit=limit,
            extra_params={
                "trackable_id": trackable_id,
                "start_time": start_time,
                "end_time": end_time,
            },
        )

    async def battery(self, trackable_id: str) -> BatteryInfo:
        data = await self._client.get(f"/trackables/{trackable_id}/battery")
        return BatteryInfo.model_validate(data)

    async def reset_battery(
        self,
        trackable_id: str,
        *,
        battery_months: int,
    ) -> Message:
        data = await self._client.post(
            f"/trackables/{trackable_id}/battery",
            body={"batteryMonths": battery_months},
        )
        return Message.model_validate(data)
