from __future__ import annotations

from .._http import AsyncHTTPClient, SyncHTTPClient
from ..types.account import User


class Account:
    """Synchronous account resource."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def retrieve(self) -> User:
        data = self._client.get("/account")
        return User.model_validate(data)


class AsyncAccount:
    """Asynchronous account resource."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def retrieve(self) -> User:
        data = await self._client.get("/account")
        return User.model_validate(data)
