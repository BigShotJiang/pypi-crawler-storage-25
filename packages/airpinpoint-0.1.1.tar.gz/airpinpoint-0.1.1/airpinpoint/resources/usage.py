from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, Optional, Union

from .._http import AsyncHTTPClient, SyncHTTPClient


class Usage:
    """Synchronous usage resource."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def retrieve(
        self,
        *,
        start_date: Optional[Union[date, datetime, str]] = None,
        end_date: Optional[Union[date, datetime, str]] = None,
    ) -> Any:
        query: Dict[str, Any] = {}
        if start_date is not None:
            query["start_date"] = start_date
        if end_date is not None:
            query["end_date"] = end_date
        return self._client.get("/usage", query=query)

    def total(
        self,
        *,
        start_date: Optional[Union[date, datetime, str]] = None,
        end_date: Optional[Union[date, datetime, str]] = None,
    ) -> int:
        query: Dict[str, Any] = {}
        if start_date is not None:
            query["start_date"] = start_date
        if end_date is not None:
            query["end_date"] = end_date
        return self._client.get("/usage/total", query=query)


class AsyncUsage:
    """Asynchronous usage resource."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def retrieve(
        self,
        *,
        start_date: Optional[Union[date, datetime, str]] = None,
        end_date: Optional[Union[date, datetime, str]] = None,
    ) -> Any:
        query: Dict[str, Any] = {}
        if start_date is not None:
            query["start_date"] = start_date
        if end_date is not None:
            query["end_date"] = end_date
        return await self._client.get("/usage", query=query)

    async def total(
        self,
        *,
        start_date: Optional[Union[date, datetime, str]] = None,
        end_date: Optional[Union[date, datetime, str]] = None,
    ) -> int:
        query: Dict[str, Any] = {}
        if start_date is not None:
            query["start_date"] = start_date
        if end_date is not None:
            query["end_date"] = end_date
        return await self._client.get("/usage/total", query=query)
