from __future__ import annotations

import hashlib
import hmac
import json
from typing import Union

from ._errors import WebhookSignatureError
from .types.webhook import WebhookEvent


class Webhook:
    """Webhook signature verification and event construction."""

    @staticmethod
    def construct_event(
        payload: Union[str, bytes],
        signature: str,
        secret: str,
    ) -> WebhookEvent:
        """Verify a webhook signature and parse the event payload.

        Args:
            payload: Raw request body (string or bytes).
            signature: Value of the X-AirPinpoint-Signature header.
            secret: Your webhook secret configured on the geofence.

        Returns:
            Parsed WebhookEvent.

        Raises:
            WebhookSignatureError: If the signature is invalid.
        """
        if isinstance(payload, bytes):
            payload_str = payload.decode("utf-8")
        else:
            payload_str = payload

        expected = hmac.new(
            secret.encode("utf-8"),
            payload_str.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        if not hmac.compare_digest(expected, signature):
            raise WebhookSignatureError(
                "Webhook signature verification failed. "
                "Ensure you are using the correct webhook secret."
            )

        try:
            data = json.loads(payload_str)
        except json.JSONDecodeError as exc:
            raise WebhookSignatureError(
                f"Failed to parse webhook payload as JSON: {exc}"
            ) from exc

        return WebhookEvent.model_validate(data)
