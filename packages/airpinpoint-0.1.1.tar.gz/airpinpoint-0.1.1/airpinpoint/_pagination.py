from __future__ import annotations

from typing import (
    Any,
    AsyncIterator,
    Callable,
    Awaitable,
    Generic,
    Iterator,
    List,
    Optional,
    Type,
    TypeVar,
)

from pydantic import BaseModel

from ._constants import DEFAULT_LIMIT

T = TypeVar("T", bound=BaseModel)


class SyncPage(Generic[T]):
    """Synchronous paginated result that supports iteration across all pages.

    Usage:
        # Get first page
        page = client.trackables.list()
        for item in page.data:
            print(item)

        # Auto-paginate across all pages
        for item in client.trackables.list():
            print(item)
    """

    def __init__(
        self,
        *,
        data: List[T],
        model: Type[T],
        fetch_page: Callable[..., Any],
        skip: int,
        limit: int,
        extra_params: Optional[dict[str, Any]] = None,
    ) -> None:
        self._data = data
        self._model = model
        self._fetch_page = fetch_page
        self._skip = skip
        self._limit = limit
        self._extra_params = extra_params or {}

    @property
    def data(self) -> List[T]:
        return self._data

    @property
    def has_more(self) -> bool:
        return len(self._data) == self._limit

    def __iter__(self) -> Iterator[T]:
        page = self
        while True:
            yield from page.data
            if not page.has_more:
                break
            page = page._fetch_page(
                skip=page._skip + page._limit,
                limit=page._limit,
                **page._extra_params,
            )

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"SyncPage(data=[...{len(self._data)} items], has_more={self.has_more})"


class AsyncPage(Generic[T]):
    """Asynchronous paginated result that supports async iteration across all pages.

    Usage:
        # Get first page
        page = await client.trackables.list()
        for item in page.data:
            print(item)

        # Auto-paginate across all pages
        async for item in await client.trackables.list():
            print(item)
    """

    def __init__(
        self,
        *,
        data: List[T],
        model: Type[T],
        fetch_page: Callable[..., Awaitable[Any]],
        skip: int,
        limit: int,
        extra_params: Optional[dict[str, Any]] = None,
    ) -> None:
        self._data = data
        self._model = model
        self._fetch_page = fetch_page
        self._skip = skip
        self._limit = limit
        self._extra_params = extra_params or {}

    @property
    def data(self) -> List[T]:
        return self._data

    @property
    def has_more(self) -> bool:
        return len(self._data) == self._limit

    async def __aiter__(self) -> AsyncIterator[T]:
        page = self
        while True:
            for item in page.data:
                yield item
            if not page.has_more:
                break
            page = await page._fetch_page(
                skip=page._skip + page._limit,
                limit=page._limit,
                **page._extra_params,
            )

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"AsyncPage(data=[...{len(self._data)} items], has_more={self.has_more})"
