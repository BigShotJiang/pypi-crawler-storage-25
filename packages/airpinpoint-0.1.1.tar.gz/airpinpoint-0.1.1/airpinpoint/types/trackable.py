from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from .location import LocationBase
from .shared import BatteryInfo


class TrackableBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    model: Optional[str] = None
    name: Optional[str] = None
    enabled: bool
    created_at: datetime = Field(alias="createdAt")
    paired_at: Optional[datetime] = Field(None, alias="pairedAt")


class TrackableDetail(TrackableBase):
    last_known_location: Optional[LocationBase] = Field(
        None, alias="lastKnownLocation"
    )
    battery_info: Optional[BatteryInfo] = Field(None, alias="batteryInfo")
