from __future__ import annotations

from typing import Any, Dict


class UsageRecord(Dict[str, Any]):
    """Usage data returned by the API. Structure may vary."""

    pass
