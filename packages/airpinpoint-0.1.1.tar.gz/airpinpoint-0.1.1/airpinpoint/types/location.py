from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class LocationBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    trackable_id: str = Field(alias="trackableId")
    name: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    altitude: Optional[float] = None
    horizontal_accuracy: Optional[float] = Field(None, alias="horizontalAccuracy")
    vertical_accuracy: Optional[float] = Field(None, alias="verticalAccuracy")
    battery_level: Optional[float] = Field(None, alias="batteryLevel")
    timestamp: Optional[datetime] = None
    is_old: Optional[bool] = Field(None, alias="isOld")
    is_inaccurate: Optional[bool] = Field(None, alias="isInaccurate")
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")
    deleted_at: Optional[datetime] = Field(None, alias="deletedAt")
