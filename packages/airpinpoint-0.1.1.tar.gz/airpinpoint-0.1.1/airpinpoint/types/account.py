from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class User(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: UUID
    name: Optional[str] = None
    email: Optional[str] = None
    email_verified: Optional[datetime] = Field(None, alias="emailVerified")
    image: Optional[str] = None
