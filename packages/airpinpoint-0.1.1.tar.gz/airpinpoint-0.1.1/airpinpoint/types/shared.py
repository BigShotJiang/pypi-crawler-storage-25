from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Message(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    message: str


class BatteryInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    last_battery_reset: Optional[datetime] = Field(None, alias="lastBatteryReset")
    battery_months: Optional[int] = Field(None, alias="batteryMonths")
    estimated_days_remaining: Optional[int] = Field(None, alias="estimatedDaysRemaining")
    battery_percentage: Optional[float] = Field(None, alias="batteryPercentage")


class BatteryResetRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    battery_months: int = Field(alias="batteryMonths")
