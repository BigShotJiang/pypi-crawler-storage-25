from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class WebhookDeliveryBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    geofence_id: str = Field(alias="geofenceId")
    trackable_id: str = Field(alias="trackableId")
    event_type: str = Field(alias="eventType")
    successful: bool
    response_status: Optional[int] = Field(None, alias="responseStatus")
    attempted_at: datetime = Field(alias="attemptedAt")


class WebhookDeliveryDetail(WebhookDeliveryBase):
    payload: Dict[str, Any]
    response_body: Optional[str] = Field(None, alias="responseBody")


class WebhookTestRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    geofence_id: str = Field(alias="geofenceId")
    event_type: str = Field("entry", alias="eventType")


class WebhookTestResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    success: bool
    message: str
    delivery_id: Optional[str] = Field(None, alias="deliveryId")


class WebhookEvent(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    event: str
    occurred_at: str
    geofence: Dict[str, Any]
    beacon: Dict[str, Any]
    location: Dict[str, Any]
