from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class GeofenceBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    latitude: float
    longitude: float
    radius: float
    notify_type: Optional[str] = Field(None, alias="notifyType")
    notify_destination: Optional[str] = Field(None, alias="notifyDestination")
    trackable_id: List[str] = Field(default_factory=list, alias="trackableId")
    webhook_enabled: Optional[bool] = Field(False, alias="webhookEnabled")
    last_webhook_success: Optional[datetime] = Field(
        None, alias="lastWebhookSuccess"
    )


class GeofenceCreateParams(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: str
    latitude: float
    longitude: float
    radius: float
    notify_type: Optional[str] = Field(None, alias="notifyType")
    notify_destination: Optional[str] = Field(None, alias="notifyDestination")
    trackable_id: List[str] = Field(default_factory=list, alias="trackableId")
    webhook_secret: Optional[str] = Field(None, alias="webhookSecret")
    webhook_enabled: Optional[bool] = Field(None, alias="webhookEnabled")
    webhook_headers: Optional[Dict[str, str]] = Field(None, alias="webhookHeaders")


class GeofenceUpdateParams(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    radius: Optional[float] = None
    notify_type: Optional[str] = Field(None, alias="notifyType")
    notify_destination: Optional[str] = Field(None, alias="notifyDestination")
    trackable_id: Optional[List[str]] = Field(None, alias="trackableId")
    webhook_secret: Optional[str] = Field(None, alias="webhookSecret")
    webhook_enabled: Optional[bool] = Field(None, alias="webhookEnabled")
    webhook_headers: Optional[Dict[str, str]] = Field(None, alias="webhookHeaders")
