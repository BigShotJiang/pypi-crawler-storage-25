"""Live API verification for airpinpoint Python SDK."""

from airpinpoint import AirPinpoint, NotFoundError, APIError
from airpinpoint import utils
import json

API_KEY = "4ae52282-349b-4cdd-b544-84470889af95"
passed = 0
failed = 0


def test(name, fn):
    global passed, failed
    try:
        fn()
        print(f"  PASS  {name}")
        passed += 1
    except Exception as e:
        print(f"  FAIL  {name}: {e}")
        failed += 1


client = AirPinpoint(api_key=API_KEY)

# --- 1. Account ---
def test_account():
    user = client.account.retrieve()
    print(f"         user.id={user.id}, email={user.email}, name={user.name}")
    assert user.id is not None

test("account.retrieve()", test_account)

# --- 2. Trackables list ---
loc_trackable_id = None
def test_trackables_list():
    global loc_trackable_id
    page = client.trackables.list()
    print(f"         count={len(page.data)}, has_more={page.has_more}")
    if page.data:
        t = page.data[0]
        print(f"         first: id={t.id}, name={t.name}, enabled={t.enabled}")
    # Find a trackable that has location data for subsequent tests
    for t in client.trackables.list():
        if t.last_known_location and t.last_known_location.latitude:
            loc_trackable_id = t.id
            print(f"         with location: id={t.id}, name={t.name}")
            break
    assert isinstance(page.data, list)

test("trackables.list()", test_trackables_list)

# --- 3. Current location ---
def test_current_location():
    if loc_trackable_id is None:
        print("         skipped (no trackable with location data)")
        return
    loc = client.trackables.current_location(loc_trackable_id)
    print(f"         lat={loc.latitude}, lng={loc.longitude}, ts={loc.timestamp}")

test("trackables.current_location()", test_current_location)

# --- 4. Location history ---
def test_location_history():
    if loc_trackable_id is None:
        print("         skipped (no trackable with location data)")
        return
    page = client.trackables.location_history(loc_trackable_id, limit=3)
    print(f"         count={len(page.data)}, has_more={page.has_more}")
    for loc in page.data[:2]:
        print(f"         - lat={loc.latitude}, lng={loc.longitude}, ts={loc.timestamp}")

test("trackables.location_history(limit=3)", test_location_history)

# --- 5. Auto-pagination ---
def test_auto_pagination():
    count = 0
    for t in client.trackables.list(limit=2):
        count += 1
        if count >= 5:
            break
    print(f"         iterated {count} trackables (limit=2 per page, stopped at 5)")
    assert count >= 0

test("auto-pagination (limit=2, break at 5)", test_auto_pagination)

# --- 6. Error handling: NotFoundError ---
def test_not_found():
    try:
        client.trackables.retrieve("nonexistent-id-12345")
        assert False, "Should have raised NotFoundError"
    except NotFoundError as e:
        print(f"         caught NotFoundError: status={e.status_code}, msg={e.message!r}")
    except APIError as e:
        # Some APIs might return 400 or 422 instead of 404 for bad IDs
        print(f"         caught APIError: status={e.status_code}, msg={e.message!r}")

test("error handling (NotFoundError)", test_not_found)

# --- 7. Geofences list ---
def test_geofences_list():
    page = client.geofences.list()
    print(f"         count={len(page.data)}, has_more={page.has_more}")
    if page.data:
        g = page.data[0]
        print(f"         first: id={g.id}, name={g.name}, radius={g.radius}")

test("geofences.list()", test_geofences_list)

# --- 8. Usage ---
def test_usage():
    total = client.usage.total()
    print(f"         total={total}")

test("usage.total()", test_usage)

# --- 9. Utility: distance ---
def test_utils_distance():
    class Pt:
        def __init__(self, lat, lng):
            self.latitude = lat
            self.longitude = lng

    nyc = Pt(40.7128, -74.0060)
    la = Pt(34.0522, -118.2437)
    d = utils.distance(nyc, la)
    print(f"         NYC -> LA = {d/1000:.1f} km")
    assert 3900 < d / 1000 < 4000

test("utils.distance(NYC, LA)", test_utils_distance)

# --- 10. Utility: is_inside_circle ---
def test_utils_circle():
    class Pt:
        def __init__(self, lat, lng):
            self.latitude = lat
            self.longitude = lng

    center = Pt(37.7749, -122.4194)
    near = Pt(37.7750, -122.4195)
    far = Pt(40.7128, -74.0060)
    assert utils.is_inside_circle(near, center, 100)
    assert not utils.is_inside_circle(far, center, 100)
    print(f"         near point inside 100m: True, far point inside 100m: False")

test("utils.is_inside_circle()", test_utils_circle)

# --- 11. Utility: to_geojson ---
def test_utils_geojson():
    class Pt:
        def __init__(self, lat, lng):
            self.latitude = lat
            self.longitude = lng

    pts = [Pt(37.77, -122.42), Pt(37.78, -122.41)]
    geojson = utils.to_geojson(pts)
    assert geojson["type"] == "FeatureCollection"
    assert len(geojson["features"]) == 2
    print(f"         FeatureCollection with {len(geojson['features'])} features")

    line = utils.to_geojson_line_string(pts)
    assert line["geometry"]["type"] == "LineString"
    print(f"         LineString with {len(line['geometry']['coordinates'])} coords")

test("utils.to_geojson()", test_utils_geojson)

# --- 12. Utility: encode/decode polyline ---
def test_utils_polyline():
    class Pt:
        def __init__(self, lat, lng):
            self.latitude = lat
            self.longitude = lng

    pts = [Pt(38.5, -120.2), Pt(40.7, -120.95), Pt(43.252, -126.453)]
    encoded = utils.encode_polyline(pts)
    decoded = utils.decode_polyline(encoded)
    print(f"         encoded='{encoded}', decoded {len(decoded)} points")
    assert len(decoded) == 3
    assert abs(decoded[0][0] - 38.5) < 0.001

test("utils.encode_polyline() / decode_polyline()", test_utils_polyline)

# --- 13. Utility: battery ---
def test_utils_battery():
    class BInfo:
        estimated_days_remaining = 45
        battery_percentage = 60.0
        battery_months = 12

    info = BInfo()
    days = utils.estimate_battery_days_remaining(info)
    status = utils.battery_health_status(info)
    print(f"         days_remaining={days}, status={status}")
    assert days == 45
    assert status == "good"

test("utils.battery_health_status()", test_utils_battery)

# --- 14. Context manager ---
def test_context_manager():
    with AirPinpoint(api_key=API_KEY) as c:
        user = c.account.retrieve()
        assert user.id is not None
    print(f"         context manager opened and closed cleanly")

test("context manager (with statement)", test_context_manager)

# --- Summary ---
print(f"\n{'='*50}")
print(f"  Results: {passed} passed, {failed} failed, {passed + failed} total")
print(f"{'='*50}")
