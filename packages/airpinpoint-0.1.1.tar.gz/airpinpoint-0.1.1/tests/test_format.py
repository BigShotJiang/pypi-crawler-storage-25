"""Tests for airpinpoint.utils.format module."""
from __future__ import annotations

from types import SimpleNamespace

from airpinpoint.utils.format import (
    to_geojson,
    to_geojson_point,
    to_geojson_line_string,
    encode_polyline,
    decode_polyline,
)


def pt(lat: float, lng: float) -> SimpleNamespace:
    return SimpleNamespace(latitude=lat, longitude=lng)


class TestToGeoJSONPoint:
    def test_basic(self):
        feature = to_geojson_point(pt(37.7749, -122.4194))
        assert feature["type"] == "Feature"
        assert feature["geometry"]["type"] == "Point"
        assert feature["geometry"]["coordinates"] == [-122.4194, 37.7749]

    def test_with_altitude(self):
        loc = SimpleNamespace(latitude=37.7749, longitude=-122.4194, altitude=50)
        feature = to_geojson_point(loc)
        assert feature["geometry"]["coordinates"] == [-122.4194, 37.7749, 50]


class TestToGeoJSON:
    def test_feature_collection(self):
        locs = [pt(37.7749, -122.4194), pt(34.0522, -118.2437)]
        fc = to_geojson(locs)
        assert fc["type"] == "FeatureCollection"
        assert len(fc["features"]) == 2
        assert fc["features"][0]["geometry"]["coordinates"] == [-122.4194, 37.7749]

    def test_empty(self):
        fc = to_geojson([])
        assert fc["type"] == "FeatureCollection"
        assert fc["features"] == []


class TestToGeoJSONLineString:
    def test_line_string(self):
        locs = [pt(37.7749, -122.4194), pt(34.0522, -118.2437), pt(40.7128, -74.0060)]
        feature = to_geojson_line_string(locs)
        assert feature["type"] == "Feature"
        assert feature["geometry"]["type"] == "LineString"
        assert len(feature["geometry"]["coordinates"]) == 3
        assert feature["geometry"]["coordinates"][0] == [-122.4194, 37.7749]


class TestPolyline:
    def test_roundtrip(self):
        coords = [pt(38.5, -120.2), pt(40.7, -120.95), pt(43.252, -126.453)]
        encoded = encode_polyline(coords)
        decoded = decode_polyline(encoded)
        assert len(decoded) == 3
        for i, (lat, lng) in enumerate(decoded):
            assert abs(lat - coords[i].latitude) < 0.00002
            assert abs(lng - coords[i].longitude) < 0.00002

    def test_google_reference(self):
        coords = [pt(38.5, -120.2), pt(40.7, -120.95), pt(43.252, -126.453)]
        assert encode_polyline(coords) == "_p~iF~ps|U_ulLnnqC_mqNvxq`@"

    def test_empty(self):
        assert encode_polyline([]) == ""
        assert decode_polyline("") == []

    def test_single_point(self):
        coords = [pt(41.0, -74.0)]
        encoded = encode_polyline(coords)
        decoded = decode_polyline(encoded)
        assert len(decoded) == 1
        assert abs(decoded[0][0] - 41.0) < 0.00002

    def test_negative_coords(self):
        coords = [pt(-33.8688, 151.2093), pt(-37.8136, 144.9631)]
        encoded = encode_polyline(coords)
        decoded = decode_polyline(encoded)
        assert abs(decoded[0][0] - (-33.8688)) < 0.00002
        assert abs(decoded[0][1] - 151.2093) < 0.00002
