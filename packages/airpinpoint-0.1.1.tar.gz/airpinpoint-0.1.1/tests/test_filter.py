"""Tests for airpinpoint.utils.filter module."""
from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

from airpinpoint.utils.filter import (
    filter_by_accuracy,
    filter_by_speed,
    filter_stale,
    deduplicate,
)


def loc(lat: float, lng: float, ts: str, acc: float | None = None) -> SimpleNamespace:
    return SimpleNamespace(
        latitude=lat,
        longitude=lng,
        timestamp=datetime.fromisoformat(ts),
        horizontal_accuracy=acc,
    )


class TestFilterByAccuracy:
    def test_removes_above_threshold(self):
        locs = [
            loc(37.7, -122.4, "2026-01-01T00:00:00+00:00", 10),
            loc(37.8, -122.5, "2026-01-01T00:01:00+00:00", 200),
            loc(37.9, -122.6, "2026-01-01T00:02:00+00:00", 30),
        ]
        filtered = filter_by_accuracy(locs, 50)
        assert len(filtered) == 2

    def test_keeps_null_accuracy(self):
        locs = [
            loc(37.7, -122.4, "2026-01-01T00:00:00+00:00"),
            loc(37.8, -122.5, "2026-01-01T00:01:00+00:00", 100),
        ]
        filtered = filter_by_accuracy(locs, 50)
        assert len(filtered) == 1

    def test_empty(self):
        assert filter_by_accuracy([], 50) == []


class TestFilterBySpeed:
    def test_removes_teleport(self):
        locs = [
            loc(37.7749, -122.4194, "2026-01-01T00:00:00+00:00"),
            loc(37.7750, -122.4195, "2026-01-01T00:00:10+00:00"),
            loc(40.7128, -74.0060, "2026-01-01T00:00:11+00:00"),  # teleport
            loc(37.7751, -122.4196, "2026-01-01T00:00:20+00:00"),
        ]
        filtered = filter_by_speed(locs, 100)
        assert len(filtered) < 4

    def test_keeps_normal_speed(self):
        locs = [
            loc(37.7749, -122.4194, "2026-01-01T00:00:00+00:00"),
            loc(37.7750, -122.4195, "2026-01-01T00:01:00+00:00"),
            loc(37.7751, -122.4196, "2026-01-01T00:02:00+00:00"),
        ]
        assert len(filter_by_speed(locs, 100)) == 3

    def test_empty(self):
        assert filter_by_speed([], 100) == []


class TestFilterStale:
    def test_removes_old(self):
        now = datetime(2026, 1, 1, 23, 0, 0, tzinfo=timezone.utc)
        locs = [
            loc(37.7, -122.4, "2026-01-01T00:00:00+00:00"),  # 23h old
            loc(37.8, -122.5, "2026-01-01T12:00:00+00:00"),  # 11h old
            loc(37.9, -122.6, "2026-01-01T22:00:00+00:00"),  # 1h old
        ]
        filtered = filter_stale(locs, 12 * 60 * 60 * 1000, now=now)
        assert len(filtered) == 2


class TestDeduplicate:
    def test_removes_duplicates(self):
        locs = [
            loc(37.7749, -122.4194, "2026-01-01T00:00:00+00:00"),
            loc(37.7749, -122.4194, "2026-01-01T00:00:01+00:00"),
            loc(37.7749, -122.4194, "2026-01-01T00:00:02+00:00"),
            loc(37.8000, -122.5000, "2026-01-01T00:05:00+00:00"),
        ]
        deduped = deduplicate(locs, distance_threshold_m=10, time_threshold_ms=30_000)
        assert len(deduped) == 2

    def test_keeps_far_apart(self):
        locs = [
            loc(37.0, -122.0, "2026-01-01T00:00:00+00:00"),
            loc(38.0, -123.0, "2026-01-01T00:00:01+00:00"),
        ]
        assert len(deduplicate(locs, distance_threshold_m=5)) == 2

    def test_empty(self):
        assert deduplicate([]) == []
