"""Tests for airpinpoint.utils.battery module."""
from __future__ import annotations

from types import SimpleNamespace

from airpinpoint.utils.battery import (
    estimate_battery_days_remaining,
    battery_health_status,
)


def info(**kwargs) -> SimpleNamespace:
    defaults = {
        "estimated_days_remaining": None,
        "battery_percentage": None,
        "battery_months": None,
    }
    defaults.update(kwargs)
    return SimpleNamespace(**defaults)


class TestEstimateBatteryDaysRemaining:
    def test_direct_value(self):
        assert estimate_battery_days_remaining(info(estimated_days_remaining=45)) == 45

    def test_from_percentage_and_months(self):
        days = estimate_battery_days_remaining(info(battery_percentage=50, battery_months=12))
        assert days is not None
        assert 150 < days < 200

    def test_no_data(self):
        assert estimate_battery_days_remaining(info()) is None


class TestBatteryHealthStatus:
    def test_good(self):
        assert battery_health_status(info(estimated_days_remaining=100)) == "good"

    def test_low(self):
        assert battery_health_status(info(estimated_days_remaining=20)) == "low"

    def test_critical(self):
        assert battery_health_status(info(estimated_days_remaining=10)) == "critical"

    def test_replace(self):
        assert battery_health_status(info(estimated_days_remaining=0)) == "replace"

    def test_percentage_fallback_good(self):
        assert battery_health_status(info(battery_percentage=50)) == "good"

    def test_percentage_fallback_low(self):
        assert battery_health_status(info(battery_percentage=20)) == "low"

    def test_percentage_fallback_critical(self):
        assert battery_health_status(info(battery_percentage=10)) == "critical"

    def test_percentage_fallback_replace(self):
        assert battery_health_status(info(battery_percentage=2)) == "replace"

    def test_no_data_default(self):
        assert battery_health_status(info()) == "good"
