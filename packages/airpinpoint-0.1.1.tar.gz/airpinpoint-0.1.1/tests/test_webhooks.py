"""Tests for airpinpoint._webhook module."""
from __future__ import annotations

import hashlib
import hmac
import json

import pytest

from airpinpoint import Webhook
from airpinpoint._errors import WebhookSignatureError


def sign(payload: str, secret: str) -> str:
    return hmac.new(
        secret.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


SAMPLE_PAYLOAD = json.dumps({
    "event": "geofence.entry",
    "occurred_at": "2026-01-01T00:00:00Z",
    "geofence": {"id": "gf-1", "name": "HQ", "latitude": 37.7, "longitude": -122.4, "radius": 500},
    "beacon": {"id": "b-1", "name": "Tracker A", "type": "apple"},
    "location": {"latitude": 37.75, "longitude": -122.42, "accuracy": 15, "timestamp": "2026-01-01T00:00:00Z"},
})


class TestConstructEvent:
    def test_valid_signature(self):
        secret = "whsec_test123"
        sig = sign(SAMPLE_PAYLOAD, secret)
        event = Webhook.construct_event(SAMPLE_PAYLOAD, sig, secret)
        assert event.event == "geofence.entry"
        assert event.geofence["name"] == "HQ"
        assert event.beacon["id"] == "b-1"

    def test_invalid_signature(self):
        with pytest.raises(WebhookSignatureError, match="signature verification failed"):
            Webhook.construct_event(SAMPLE_PAYLOAD, "bad_sig", "secret")

    def test_wrong_secret(self):
        sig = sign(SAMPLE_PAYLOAD, "correct_secret")
        with pytest.raises(WebhookSignatureError):
            Webhook.construct_event(SAMPLE_PAYLOAD, sig, "wrong_secret")

    def test_tampered_payload(self):
        secret = "whsec_test123"
        sig = sign(SAMPLE_PAYLOAD, secret)
        tampered = SAMPLE_PAYLOAD.replace("geofence.entry", "geofence.exit")
        with pytest.raises(WebhookSignatureError):
            Webhook.construct_event(tampered, sig, secret)

    def test_bytes_payload(self):
        secret = "whsec_test123"
        sig = sign(SAMPLE_PAYLOAD, secret)
        event = Webhook.construct_event(SAMPLE_PAYLOAD.encode(), sig, secret)
        assert event.event == "geofence.entry"

    def test_invalid_json(self):
        secret = "test"
        payload = "not json"
        sig = sign(payload, secret)
        with pytest.raises(WebhookSignatureError, match="JSON"):
            Webhook.construct_event(payload, sig, secret)
