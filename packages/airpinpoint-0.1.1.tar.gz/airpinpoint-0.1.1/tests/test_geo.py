"""Tests for airpinpoint.utils.geo module."""
from __future__ import annotations

import pytest
from types import SimpleNamespace

from airpinpoint.utils.geo import (
    distance,
    bearing,
    is_inside_circle,
    is_inside_polygon,
    is_inside_geofence,
    distance_to_geofence,
    buffer_geofence,
)


def pt(lat: float, lng: float) -> SimpleNamespace:
    return SimpleNamespace(latitude=lat, longitude=lng)


def gf(lat: float, lng: float, radius: float) -> SimpleNamespace:
    return SimpleNamespace(latitude=lat, longitude=lng, radius=radius, id="gf-1", name="Test")


NYC = pt(40.7128, -74.0060)
LA = pt(34.0522, -118.2437)
SF = pt(37.7749, -122.4194)
LONDON = pt(51.5074, -0.1278)
TOKYO = pt(35.6762, 139.6503)


class TestDistance:
    def test_nyc_to_la(self):
        d = distance(NYC, LA)
        assert 3_930_000 < d < 3_940_000

    def test_sf_to_la(self):
        d = distance(SF, LA)
        assert 555_000 < d < 563_000

    def test_london_to_tokyo(self):
        d = distance(LONDON, TOKYO)
        assert 9_550_000 < d < 9_600_000

    def test_same_point(self):
        assert distance(NYC, NYC) == 0

    def test_symmetric(self):
        assert abs(distance(NYC, LA) - distance(LA, NYC)) < 1

    def test_antipodal(self):
        d = distance(pt(90, 0), pt(-90, 0))
        assert 20_000_000 < d < 20_100_000

    def test_equator_crossing(self):
        d = distance(pt(1, 0), pt(-1, 0))
        assert 220_000 < d < 225_000

    def test_null_coords_raise(self):
        with pytest.raises(ValueError):
            distance(SimpleNamespace(latitude=None, longitude=0), pt(0, 0))


class TestBearing:
    def test_due_north(self):
        b = bearing(pt(0, 0), pt(1, 0))
        assert abs(b) < 1 or abs(b - 360) < 1

    def test_due_east(self):
        b = bearing(pt(0, 0), pt(0, 1))
        assert abs(b - 90) < 1

    def test_due_south(self):
        b = bearing(pt(1, 0), pt(0, 0))
        assert abs(b - 180) < 1

    def test_due_west(self):
        b = bearing(pt(0, 1), pt(0, 0))
        assert abs(b - 270) < 1

    def test_nyc_to_la_westward(self):
        b = bearing(NYC, LA)
        assert 265 < b < 280

    def test_range_0_360(self):
        b = bearing(LA, NYC)
        assert 0 <= b < 360


class TestIsInsideCircle:
    def test_inside(self):
        assert is_inside_circle(pt(37.775, -122.419), SF, 500) is True

    def test_outside(self):
        assert is_inside_circle(LA, SF, 100_000) is False

    def test_center(self):
        assert is_inside_circle(SF, SF, 1) is True

    def test_boundary(self):
        d = distance(SF, NYC)
        assert is_inside_circle(NYC, SF, d) is True


class TestIsInsidePolygon:
    SQUARE = [
        pt(37.78, -122.43),
        pt(37.78, -122.41),
        pt(37.77, -122.41),
        pt(37.77, -122.43),
    ]

    def test_inside(self):
        assert is_inside_polygon(pt(37.775, -122.42), self.SQUARE) is True

    def test_outside(self):
        assert is_inside_polygon(pt(37.79, -122.42), self.SQUARE) is False

    def test_far_away(self):
        assert is_inside_polygon(NYC, self.SQUARE) is False

    def test_triangle(self):
        tri = [pt(0, 0), pt(2, 1), pt(0, 2)]
        assert is_inside_polygon(pt(1, 1), tri) is True
        assert is_inside_polygon(pt(3, 1), tri) is False


class TestIsInsideGeofence:
    def test_inside(self):
        fence = gf(37.7749, -122.4194, 1000)
        assert is_inside_geofence(pt(37.775, -122.419), fence) is True

    def test_outside(self):
        fence = gf(37.7749, -122.4194, 1000)
        assert is_inside_geofence(pt(37.8, -122.5), fence) is False


class TestDistanceToGeofence:
    def test_inside_returns_zero(self):
        fence = gf(37.7749, -122.4194, 1000)
        assert distance_to_geofence(pt(37.775, -122.419), fence) == 0

    def test_outside_returns_positive(self):
        fence = gf(37.7749, -122.4194, 1000)
        d = distance_to_geofence(LA, fence)
        assert d > 0
        full_dist = distance(LA, pt(37.7749, -122.4194))
        assert abs(d - (full_dist - 1000)) < 10


class TestBufferGeofence:
    def test_expand(self):
        fence = gf(37.7, -122.4, 500)
        buffered = buffer_geofence(fence, 200)
        assert buffered["radius"] == 700
        assert buffered["latitude"] == 37.7

    def test_shrink_clamps(self):
        fence = gf(37.7, -122.4, 100)
        shrunk = buffer_geofence(fence, -200)
        assert shrunk["radius"] == 0

    def test_preserves_props(self):
        fence = gf(37.7, -122.4, 500)
        buffered = buffer_geofence(fence, 50)
        assert buffered["name"] == "Test"
        assert buffered["id"] == "gf-1"
