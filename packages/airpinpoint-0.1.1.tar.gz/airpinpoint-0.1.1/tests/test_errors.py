"""Tests for airpinpoint._errors module."""
from __future__ import annotations

from airpinpoint._errors import (
    AirPinpointError,
    APIError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    InternalError,
    APIConnectionError,
    WebhookSignatureError,
    _make_error,
)


class TestMakeError:
    def test_401(self):
        err = _make_error(401, {"detail": "Invalid API key"})
        assert isinstance(err, AuthenticationError)
        assert err.status_code == 401
        assert err.message == "Invalid API key"

    def test_404(self):
        err = _make_error(404, {"detail": "Beacon not found"})
        assert isinstance(err, NotFoundError)
        assert err.status_code == 404

    def test_400(self):
        err = _make_error(400, {"detail": "Invalid params"})
        assert isinstance(err, ValidationError)
        assert err.status_code == 400

    def test_429(self):
        err = _make_error(429, {"detail": "Rate limit exceeded"})
        assert isinstance(err, RateLimitError)
        assert err.status_code == 429

    def test_500(self):
        err = _make_error(500, {"detail": "Server error"})
        assert isinstance(err, InternalError)
        assert err.status_code == 500

    def test_502(self):
        err = _make_error(502, None)
        assert isinstance(err, InternalError)
        assert err.status_code == 502

    def test_403_base(self):
        err = _make_error(403, {"detail": "Forbidden"})
        assert isinstance(err, APIError)
        assert not isinstance(err, AuthenticationError)
        assert err.status_code == 403

    def test_string_body(self):
        err = _make_error(400, "Bad request")
        assert err.message == "Bad request"

    def test_none_body(self):
        err = _make_error(500, None)
        assert "500" in err.message


class TestErrorHierarchy:
    def test_api_error_is_airpinpoint_error(self):
        err = AuthenticationError(message="test")
        assert isinstance(err, AirPinpointError)
        assert isinstance(err, APIError)
        assert isinstance(err, Exception)

    def test_connection_error(self):
        cause = Exception("timeout")
        err = APIConnectionError("Connection failed", cause=cause)
        assert isinstance(err, AirPinpointError)
        assert err.cause is cause

    def test_webhook_error(self):
        err = WebhookSignatureError("bad sig")
        assert isinstance(err, AirPinpointError)

    def test_repr(self):
        err = NotFoundError(message="not found")
        assert "404" in repr(err)
        assert "not found" in repr(err)
