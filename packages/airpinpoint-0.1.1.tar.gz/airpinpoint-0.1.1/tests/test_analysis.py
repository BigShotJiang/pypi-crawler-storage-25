"""Tests for airpinpoint.utils.analysis module."""
from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

from airpinpoint.utils.analysis import (
    speed,
    detect_stops,
    detect_trips,
    dwell_time,
    simplify_path,
    cluster_locations,
)


def loc(lat: float, lng: float, ts: str) -> SimpleNamespace:
    return SimpleNamespace(
        latitude=lat,
        longitude=lng,
        timestamp=datetime.fromisoformat(ts),
    )


def pt(lat: float, lng: float) -> SimpleNamespace:
    return SimpleNamespace(latitude=lat, longitude=lng)


class TestSpeed:
    def test_normal_speed(self):
        a = loc(37.7749, -122.4194, "2026-01-01T00:00:00+00:00")
        b = loc(37.7849, -122.4194, "2026-01-01T00:01:00+00:00")
        s = speed(a, b)
        assert 15 < s < 20  # ~1.1km in 60s

    def test_zero_time_returns_zero(self):
        ts = "2026-01-01T00:00:00+00:00"
        assert speed(loc(37.7, -122.4, ts), loc(37.8, -122.5, ts)) == 0

    def test_same_location(self):
        a = loc(37.7, -122.4, "2026-01-01T00:00:00+00:00")
        b = loc(37.7, -122.4, "2026-01-01T01:00:00+00:00")
        assert speed(a, b) == 0

    def test_missing_timestamp_raises(self):
        a = SimpleNamespace(latitude=37.7, longitude=-122.4, timestamp=None)
        b = loc(37.8, -122.5, "2026-01-01T00:00:00+00:00")
        with pytest.raises(ValueError):
            speed(a, b)


class TestDetectStops:
    def test_detects_stop_cluster(self):
        locs = [
            loc(37.7749 + i * 0.00001, -122.4194, f"2026-01-01T00:0{i}:00+00:00")
            for i in range(6)
        ]
        locs.append(loc(37.8, -122.5, "2026-01-01T00:10:00+00:00"))
        stops = detect_stops(locs, radius_m=100, min_duration_ms=60_000)
        assert len(stops) == 1
        assert stops[0].duration_ms >= 60_000

    def test_empty_input(self):
        assert detect_stops([]) == []

    def test_single_input(self):
        assert detect_stops([loc(37.7, -122.4, "2026-01-01T00:00:00+00:00")]) == []

    def test_no_stops_when_moving(self):
        locs = [
            loc(37.7, -122.4, "2026-01-01T00:00:00+00:00"),
            loc(38.0, -122.4, "2026-01-01T00:05:00+00:00"),
            loc(38.3, -122.4, "2026-01-01T00:10:00+00:00"),
        ]
        stops = detect_stops(locs, radius_m=50, min_duration_ms=300_000)
        assert len(stops) == 0


class TestDetectTrips:
    def test_one_trip_no_stops(self):
        locs = [
            loc(37.7, -122.4, "2026-01-01T00:00:00+00:00"),
            loc(37.8, -122.3, "2026-01-01T00:30:00+00:00"),
            loc(37.9, -122.2, "2026-01-01T01:00:00+00:00"),
        ]
        trips = detect_trips(locs)
        assert len(trips) == 1
        assert trips[0].distance_m > 0

    def test_empty(self):
        assert detect_trips([]) == []


class TestDwellTime:
    def test_all_inside(self):
        fence = SimpleNamespace(latitude=37.7749, longitude=-122.4194, radius=500)
        locs = [
            loc(37.775, -122.419, "2026-01-01T00:00:00+00:00"),
            loc(37.775, -122.419, "2026-01-01T00:10:00+00:00"),
            loc(37.775, -122.419, "2026-01-01T00:20:00+00:00"),
        ]
        assert dwell_time(locs, fence) == 20 * 60 * 1000

    def test_all_outside(self):
        fence = SimpleNamespace(latitude=37.7749, longitude=-122.4194, radius=100)
        locs = [
            loc(38.0, -123.0, "2026-01-01T00:00:00+00:00"),
            loc(38.1, -123.1, "2026-01-01T00:10:00+00:00"),
        ]
        assert dwell_time(locs, fence) == 0

    def test_entry_and_exit(self):
        fence = SimpleNamespace(latitude=37.7749, longitude=-122.4194, radius=5000)
        locs = [
            loc(38.0, -123.0, "2026-01-01T00:00:00+00:00"),       # outside
            loc(37.775, -122.419, "2026-01-01T00:10:00+00:00"),    # inside
            loc(37.775, -122.419, "2026-01-01T00:20:00+00:00"),    # inside
            loc(38.0, -123.0, "2026-01-01T00:30:00+00:00"),        # outside
        ]
        assert dwell_time(locs, fence) == 10 * 60 * 1000


class TestSimplifyPath:
    def test_straight_line(self):
        locs = [pt(0, 0), pt(0.5, 0.5), pt(1, 1)]
        simplified = simplify_path(locs, 10)
        assert len(simplified) == 2

    def test_deviation_preserved(self):
        locs = [pt(0, 0), pt(0.5, 1), pt(1, 0)]
        simplified = simplify_path(locs, 10)
        assert len(simplified) == 3

    def test_few_points(self):
        assert len(simplify_path([pt(0, 0), pt(1, 1)], 10)) == 2
        assert len(simplify_path([pt(0, 0)], 10)) == 1
        assert len(simplify_path([], 10)) == 0


class TestClusterLocations:
    def test_single_cluster(self):
        locs = [pt(37.775, -122.419), pt(37.7751, -122.4191), pt(37.7752, -122.4192)]
        clusters = cluster_locations(locs, radius_m=200, min_points=2)
        assert len(clusters) == 1
        assert len(clusters[0]) == 3

    def test_empty(self):
        assert cluster_locations([]) == []

    def test_no_cluster_below_min_points(self):
        locs = [pt(37.0, -122.0), pt(38.0, -123.0)]
        clusters = cluster_locations(locs, radius_m=100, min_points=2)
        assert len(clusters) == 0
