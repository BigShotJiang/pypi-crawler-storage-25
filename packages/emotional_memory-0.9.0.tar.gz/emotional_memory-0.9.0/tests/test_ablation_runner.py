"""Integration tests for the ablation study runner."""

from __future__ import annotations

import pytest

from benchmarks.ablation.runner import run_ablation_study
from benchmarks.realistic.runner import DATASET, load_dataset


def test_ablation_study_structure() -> None:
    dataset = load_dataset()
    results = run_ablation_study(dataset, n_bootstrap=100, seed=0)

    # Benchmark id must be derived from dataset.name — not a hardcoded literal.
    assert results["benchmark"] == f"ablation_{dataset.name}"
    assert results["benchmark"] == "ablation_realistic_recall_v1"
    assert len(results["variants"]) == 8

    variant_names = [v["variant"] for v in results["variants"]]
    assert variant_names == [
        "full",
        "no_appraisal",
        "no_mood",
        "no_momentum",
        "no_resonance",
        "no_reconsolidation",
        "dual_path",
        "aft_keyword_synchronous",
    ]

    for v in results["variants"]:
        assert "aggregate_metrics" in v
        assert "challenge_type_metrics" in v
        assert isinstance(v["aggregate_metrics"]["top1_accuracy"], float)

    assert len(results["pairwise_vs_full"]) == 7
    pairwise_names = [r["variant"] for r in results["pairwise_vs_full"]]
    assert "no_appraisal" in pairwise_names
    assert "no_resonance" in pairwise_names
    assert "no_reconsolidation" in pairwise_names
    assert "dual_path" in pairwise_names
    assert "aft_keyword_synchronous" in pairwise_names

    for row in results["pairwise_vs_full"]:
        assert row["baseline"] == "full"
        for metric in ("top1", "hit_at_k"):
            m = row[metric]
            assert "diff" in m
            assert "ci_lower" in m
            assert "ci_upper" in m
            assert "p_bootstrap" in m
            assert "p_mcnemar" in m
            assert 0.0 <= m["p_bootstrap"] <= 1.0
            assert 0.0 <= m["p_mcnemar"] <= 1.0

    assert results["statistics"]["n_bootstrap"] == 100
    assert results["statistics"]["ci_method"] == "bootstrap_percentile"


@pytest.mark.parametrize(
    "path,expected_suffix",
    [
        (DATASET, "realistic_recall_v1"),
    ],
)
def test_ablation_benchmark_id_derived_from_dataset(path: object, expected_suffix: str) -> None:
    from pathlib import Path

    dataset = load_dataset(Path(str(path)))
    results = run_ablation_study(dataset, n_bootstrap=20, seed=0)
    assert results["benchmark"] == f"ablation_{expected_suffix}"
    assert results["base_benchmark"] == expected_suffix
