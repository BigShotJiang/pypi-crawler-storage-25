# Resolving Topological Faults

*Documentation pending.*
