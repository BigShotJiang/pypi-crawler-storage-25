# The Archetype Model

*Documentation pending.*
