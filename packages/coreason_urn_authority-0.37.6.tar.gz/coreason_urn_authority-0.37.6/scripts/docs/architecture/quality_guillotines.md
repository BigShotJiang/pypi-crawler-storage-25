# Quality Guillotines

*Documentation pending.*
