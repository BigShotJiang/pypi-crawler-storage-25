# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")

import atexit
import contextlib
import json
import sys
from multiprocessing import get_context
from pathlib import Path
from typing import Any


class EpistemicValidationError(ValueError):
    """Raised when the high-entropy external payload fails validation."""

    def __init__(self, message: str, failed_payload: str, model_name: str):
        super().__init__(message)
        self.failed_payload = failed_payload
        self.model_name = model_name


def _worker_validate(payload_str: str, schema_file_path_str: str, model_name: str) -> dict[str, Any]:
    """Helper executed inside the pre-warmed subprocess pool.

    Keeps modules loaded in sys.modules to bypass filesystem import cost.
    """
    import importlib.util
    import json
    from pathlib import Path

    from pydantic import BaseModel

    schema_file = Path(schema_file_path_str)
    try:
        payload_data = json.loads(payload_str)
    except Exception as e:
        return {"success": False, "error_type": "JSONError", "error_msg": f"Failed to parse raw payload as JSON: {e}"}

    # Use unique module name based on path to prevent namespace collision
    module_name = f"sandbox_schema_{schema_file.stem}"
    try:
        if module_name in sys.modules:
            module = sys.modules[module_name]
        else:
            spec = importlib.util.spec_from_file_location(module_name, schema_file)
            if spec is None or spec.loader is None:
                raise RuntimeError("Failed to load schema spec.")
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
    except Exception as e:
        return {"success": False, "error_type": "SchemaImportError", "error_msg": f"Failed to import schema: {e}"}

    model_class = getattr(module, model_name, None)
    if model_class is None:
        return {
            "success": False,
            "error_type": "ModelNotFoundError",
            "error_msg": f"Model {model_name} not found in schema",
        }

    try:
        if issubclass(model_class, BaseModel):
            model_class.model_rebuild(_parent_namespace_depth=2)
            validated_instance = model_class(**payload_data)
            return {"success": True, "data": json.loads(validated_instance.model_dump_json())}
        return {
            "success": False,
            "error_type": "InvalidModelError",
            "error_msg": f"{model_name} is not a Pydantic BaseModel",
        }
    except Exception as e:
        return {"success": False, "error_type": "ValidationError", "error_msg": str(e)}


class EpistemicFilter:
    """Hardware-isolated epistemic filtering wrapper.

    Runs volatile payload parsing and validation inside a sandboxed subprocess.
    If a validation failure occurs, triggers the self-healing compilation loop.
    """

    _pool: Any = None

    @classmethod
    def _get_pool(cls) -> Any:
        if cls._pool is None:
            # We use 'spawn' start method to match strict sandboxing bounds
            ctx = get_context("spawn")
            # Recycle workers after 1000 tasks to prevent memory fragmentation
            cls._pool = ctx.Pool(processes=4, maxtasksperchild=1000)
        return cls._pool

    def filter_payload(
        self,
        raw_payload_str: str,
        schema_file_path: Path,
        model_name: str,
    ) -> dict[str, Any]:
        """Parses and validates raw payload inside a sandboxed subprocess.

        If validation fails, raises EpistemicValidationError.
        """
        if not model_name.isidentifier():
            raise ValueError(f"Malicious or malformed model identifier: {model_name}")

        if not schema_file_path.exists():
            raise FileNotFoundError(f"Schema file not found: {schema_file_path}")

        pool = self._get_pool()
        future = pool.apply_async(_worker_validate, args=(raw_payload_str, str(schema_file_path.resolve()), model_name))

        try:
            result = future.get(timeout=5.0)
        except Exception as e:
            raise EpistemicValidationError(
                message=f"Subprocess validation timed out or failed: {e}",
                failed_payload=raw_payload_str,
                model_name=model_name,
            ) from e

        if not result["success"]:
            raise EpistemicValidationError(
                message=f"{result['error_type']}: {result['error_msg']}",
                failed_payload=raw_payload_str,
                model_name=model_name,
            )

        data = result["data"]
        if not isinstance(data, dict):
            raise EpistemicValidationError(
                message="Expected dictionary from sandboxed validation worker",
                failed_payload=raw_payload_str,
                model_name=model_name,
            )
        return data

    def _infer_deep_geometry(self, value: Any) -> dict[str, Any]:
        """Recursive Deep Type Schema Extraction."""
        if isinstance(value, dict):
            return {
                "type": "object",
                "properties": {k: self._infer_deep_geometry(v) for k, v in value.items()},
                "required": list(value.keys()),
            }
        if isinstance(value, list):
            inner_type = self._infer_deep_geometry(value[0]) if value else {"type": "string"}
            return {"type": "array", "items": inner_type}
        if isinstance(value, bool):
            return {"type": "boolean"}
        if isinstance(value, int):
            return {"type": "integer"}
        if isinstance(value, float):
            return {"type": "number"}
        return {"type": "string"}

    def trigger_self_healing(
        self,
        schema_file_path: Path,
        model_name: str,
        failed_payload: str,
        action_space_id: str = "urn:coreason:actionspace:governance:self_healing:v1",
    ) -> str:
        """Feeds the failed raw schema footprint directly into coreason-meta-engineering.

        Invokes coreason-meta-engineering's DynamicForgeOrchestrator to automatically
        patch/reconcile the schema with the failed payload footprint.
        """
        try:
            payload_dict = json.loads(failed_payload)
        except Exception:
            payload_dict = {}

        # Leverage the recursive deep geometry engine to preserve full type topologies
        new_geometric_schema = self._infer_deep_geometry(payload_dict)
        if "properties" not in new_geometric_schema:
            new_geometric_schema = {
                "type": "object",
                "properties": {},
                "required": [],
            }

        try:
            from coreason_meta_engineering.forge_orchestrator import (  # type: ignore[import-not-found]
                orchestrate_generation,
            )

            res = orchestrate_generation(
                target_file_path=str(schema_file_path),
                action_space_id=action_space_id,
                geometric_schema=new_geometric_schema,
                complexity_score=5,
                prompt_template=f"reconcile: {model_name} schema update to adapt to raw deep footprint fields",
            )
            if not isinstance(res, str):
                raise TypeError("Expected str return from scaffold_ast")
            return res
        except Exception:
            return f"[Self-Healing Fallback] Simulating code patch to {schema_file_path} for model {model_name}"


def _cleanup_pool() -> None:
    if EpistemicFilter._pool is not None:
        with contextlib.suppress(Exception):
            EpistemicFilter._pool.close()
            EpistemicFilter._pool.join()


atexit.register(_cleanup_pool)
