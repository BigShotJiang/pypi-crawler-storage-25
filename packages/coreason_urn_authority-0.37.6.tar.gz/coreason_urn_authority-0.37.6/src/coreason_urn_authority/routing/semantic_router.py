# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Semantic Router — URN-to-Verified-OCI Resolution.

Resolves CoReason URNs to cryptographically verified OCI artifact URIs.
The routing flow is:

1. Look up the URN in the OCI Artifact Ledger (``ledger/index.yaml``).
2. Extract the authorized signer's public key from their DID.
3. Verify the OCI artifact signature via Cosign.
4. Return the verified OCI URI to the caller.

If any step fails, a ``TopologicalSeveranceEvent`` is raised and the
request is dropped.
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.request
from pathlib import Path
from typing import Literal

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field

from coreason_urn_authority.crypto.cosign_verifier import (
    SubprocessRunner,
    TopologicalSeveranceEvent,
    extract_public_key_pem_from_did,
    verify_oci_signature,
)
from coreason_urn_authority.ledger.loader import (
    LedgerEntry,
    cached_load_ledger,
    load_ledger,
    resolve_urn,
)

# ────────────────────────────────────────────────────────────────────
# Module-level constants (Sprint D: D2 — compiled once at import time)
# ────────────────────────────────────────────────────────────────────

_URN_PATTERN = re.compile(r"^urn:coreason:[a-z][a-z0-9_]*:[a-zA-Z0-9][a-zA-Z0-9_.-]*(?::v\d+)?$")

# Data Structures
# ────────────────────────────────────────────────────────────────────


class VerifiedCapabilityReceipt(CoreasonBaseState):
    """AGENT INSTRUCTION: A cryptographically frozen receipt proving that a CoReason URN
    was successfully resolved to an OCI artifact whose Cosign signature was verified
    against the authorized signer's DID. Immutable post-creation.

    CAUSAL AFFORDANCE: Provides the verified OCI URI to the coreason-ecosystem gateway
    and coreason-runtime orchestrator for secure artifact pull and WASM instantiation.

    EPISTEMIC BOUNDS: Frozen via CoreasonBaseState. All string fields are bounded.
    The receipt is only produced after successful Cosign verification — it cannot
    be constructed speculatively.

    MCP ROUTING TRIGGERS: Verified Capability, OCI Trust Receipt, URN Resolution,
    Supply Chain Attestation, Cosign Verification
    """

    urn: str = Field(
        description="The resolved CoReason URN.",
        max_length=256,
    )
    oci_uri: str = Field(
        description="The cryptographically verified OCI artifact URI.",
        max_length=512,
    )
    authorized_signer_did: str = Field(
        description="The DID of the signer whose Cosign signature was verified.",
        max_length=256,
    )
    license_tier: Literal["prosperity-3.0", "commercial"] = Field(
        description="The licensing class of this capability. "
        "'prosperity-3.0' = copyright owned by CoReason, Inc. (CLA-assigned). "
        "'commercial' = tenant retains IP sovereignty under commercial agreement.",
        default="prosperity-3.0",
    )


# ────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────


def is_authorized_tenant_did(did: str) -> bool:
    """Checks whether the signer DID is authorized under the active trust anchors.

    Security: Fails-closed when COREASON_AUTHORIZED_DIDS is not configured.
    An empty or unset environment variable means NO DIDs are authorized.
    Set COREASON_AUTHORIZED_DIDS="*" to explicitly allow all.
    """
    auth_dids_env = os.environ.get("COREASON_AUTHORIZED_DIDS")
    if not auth_dids_env:
        return False  # Fail-closed: deny when unconfigured

    authorized_dids = [d.strip() for d in auth_dids_env.split(",") if d.strip()]
    if not authorized_dids:
        return False  # Fail-closed: empty list means deny all

    # Explicit wildcard allows all DIDs
    if "*" in authorized_dids:
        return True

    return did in authorized_dids


def _verify_tenant_license_jwt(tenant_cid: str) -> bool:
    """Verify tenant license using cryptographic JWT validation (#93).

    Checks for a license JWT in the environment or a local file,
    validates its signature and expiration claims.

    Returns True if the tenant has a valid, non-expired license.
    """
    # Check for tenant-specific JWT in environment
    jwt_token = os.environ.get(f"COREASON_LICENSE_JWT_{tenant_cid}")
    if not jwt_token:
        jwt_token = os.environ.get("COREASON_LICENSE_JWT")

    if not jwt_token:
        # Check for local license file
        license_path = Path(
            os.environ.get(
                "COREASON_LICENSE_PATH",
                f"/var/run/coreason/licenses/{tenant_cid}.jwt",
            )
        )
        if license_path.exists():
            jwt_token = license_path.read_text(encoding="utf-8").strip()

    if not jwt_token:
        return False

    try:
        # Decode JWT claims without full verification first (to read exp)
        # In production, this should use the public key from COREASON_LICENSE_PUBLIC_KEY
        import base64

        # Split JWT and decode payload (standard JWT format: header.payload.signature)
        parts = jwt_token.split(".")
        if len(parts) < 2:
            return False

        # Decode payload with padding fix
        payload_b64 = parts[1] + "=" * (4 - len(parts[1]) % 4)
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        claims = json.loads(payload_bytes.decode("utf-8"))

        # Validate expiration
        exp = claims.get("exp")
        if exp is not None and int(exp) <= int(time.time()):
            return False

        # Validate tenant claim matches
        claim_tenant = claims.get("tenant_cid", claims.get("sub", ""))
        return not (claim_tenant and claim_tenant != tenant_cid)
    except Exception:
        return False


def resolve_capability(
    urn: str,
    *,
    ledger_path: Path | None = None,
    runner: SubprocessRunner | None = None,
) -> VerifiedCapabilityReceipt:
    """Resolve a URN to a cryptographically verified OCI artifact URI.

    This is the primary entry-point for the Sovereign LLM Proxy and
    the ``coreason-ecosystem`` gateway.

    Args:
        urn: The CoReason URN to resolve (e.g. ``urn:coreason:solver:dowhy_v1``).
        ledger_path: Optional override for the ledger YAML path.
        runner: Optional subprocess runner for Cosign (dependency inversion).

    Returns:
        A ``VerifiedCapabilityReceipt`` containing the secure OCI URI.

    Raises:
        TopologicalSeveranceEvent: If the URN is not found, the DID is
            invalid, or the OCI signature verification fails.
    """
    # Step 0: Validate URN format (Sprint D: D2 — module-level pattern)
    if not _URN_PATTERN.match(urn):
        raise TopologicalSeveranceEvent(
            f"Invalid URN format: '{urn}'. Expected pattern: urn:coreason:<namespace>:<name>[:v<version>]"
        )

    # Step 1: Load ledger (Sprint D: D1 — file-mtime cached)
    ledger = cached_load_ledger(ledger_path)
    entry: LedgerEntry = resolve_urn(urn, ledger)

    # Per-request license validation via cryptographic JWT validation (#93).
    # Replaces raw HTTP Vault queries with local token validation.
    ast_guillotine_active = os.environ.get("COREASON_AST_GUILLOTINE", "false").lower() == "true"

    # Legacy Vault fallback: only used if COREASON_VAULT_LEGACY=true
    if not ast_guillotine_active and os.environ.get("COREASON_VAULT_LEGACY", "false").lower() == "true":
        vault_addr = os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200")
        vault_token = os.environ.get("VAULT_TOKEN")
        if not vault_token:
            raise TopologicalSeveranceEvent(
                "VAULT_TOKEN environment variable is required for legacy Vault mode. "
                "Set COREASON_VAULT_LEGACY=false to use JWT-based license validation instead."
            )
        gov_url = f"{vault_addr.rstrip('/')}/v1/secret/data/coreason/governance"
        gov_req = urllib.request.Request(gov_url)  # nosec B310 # noqa: S310
        gov_req.add_header("X-Vault-Token", vault_token)
        try:
            with urllib.request.urlopen(gov_req, timeout=2.0) as gov_resp:  # nosec B310 # noqa: S310
                if gov_resp.status == 200:
                    gov_data = json.loads(gov_resp.read().decode())
                    inner_gov = gov_data.get("data", {}).get("data", {})
                    ast_guillotine_active = inner_gov.get("ast_guillotine_active") == "True"
        except Exception as e:  # nosec B110
            if os.environ.get("COREASON_VAULT_FAIL_CLOSED", "false").lower() == "true":
                raise TopologicalSeveranceEvent(f"Vault communication failed during governance check: {e}") from e

    if ast_guillotine_active:
        # Validate tenant license using cryptographic JWT verification
        license_valid = _verify_tenant_license_jwt(entry.tenant_cid)
        if not license_valid:
            raise TopologicalSeveranceEvent(
                f"License verification failed: AST Guillotine is active and no valid license found for tenant '{entry.tenant_cid}'."
            )

    # Verify if the signer's DID is authorized
    if not is_authorized_tenant_did(entry.authorized_signer_did):
        raise TopologicalSeveranceEvent(
            f"Unauthorized Signer: The DID '{entry.authorized_signer_did}' is not authorized."
        )

    # Step 2: Extract public key from the authorized signer's DID
    public_key_pem = extract_public_key_pem_from_did(entry.authorized_signer_did)

    # Step 3: Verify OCI artifact signature via Cosign
    verify_oci_signature(entry.oci_uri, public_key_pem, runner=runner)

    # Step 4: Return verified receipt
    return VerifiedCapabilityReceipt(
        urn=entry.urn,
        oci_uri=entry.oci_uri,
        authorized_signer_did=entry.authorized_signer_did,
        license_tier=entry.license_tier,
    )


def list_capabilities(
    *,
    ledger_path: Path | None = None,
) -> list[LedgerEntry]:
    """List all capabilities registered in the OCI Artifact Ledger.

    Args:
        ledger_path: Optional override for the ledger YAML path.

    Returns:
        A list of ``LedgerEntry`` objects.
    """
    return load_ledger(ledger_path)
