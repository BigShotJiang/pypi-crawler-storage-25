# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Multi-Signature Keysigning Ceremony Session Manager (#107).

Manages multi-human handover ceremonies where threshold signatures
from authorized operators are collected to establish delegation attestations.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class CeremonyStatus(str, Enum):
    """Status of a keysigning ceremony session."""

    PENDING = "PENDING"
    ESTABLISHED = "ESTABLISHED"
    FAULT = "FAULT"
    RETRACTED = "RETRACTED"


@dataclass
class CeremonySession:
    """Represents a multi-signature ceremony session."""

    session_token: str
    trust_domain: str
    target_node_urn: str
    required_signers: list[str]
    threshold: int
    status: CeremonyStatus = CeremonyStatus.PENDING
    signatures_collected: int = 0
    collected_signers: list[str] = field(default_factory=list)
    attestation_hash: str | None = None
    created_at: str = ""
    updated_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to API-compatible dict."""
        result: dict[str, Any] = {
            "sessionToken": self.session_token,
            "status": self.status.value,
            "signaturesCollected": self.signatures_collected,
            "signaturesThreshold": self.threshold,
            "timestamp": self.updated_at or self.created_at,
        }
        if self.attestation_hash:
            result["attestationHash"] = self.attestation_hash
        return result


class CeremonyManager:
    """Manages keysigning ceremony sessions.

    Sessions are stored in-memory with TTL expiry for abandoned ceremonies.
    """

    _SESSION_TTL_SECONDS = 3600  # 1 hour

    def __init__(self) -> None:
        self._sessions: dict[str, CeremonySession] = {}

    def initiate(
        self,
        trust_domain: str,
        target_node_urn: str,
        required_signers: list[str],
        threshold: int,
    ) -> CeremonySession:
        """Create a new ceremony session.

        Args:
            trust_domain: SPIFFE trust domain for the ceremony.
            target_node_urn: URN of the node requiring delegation.
            required_signers: List of SPIFFE IDs of required signers.
            threshold: Minimum number of signatures needed.

        Returns:
            The newly created CeremonySession.

        Raises:
            ValueError: If threshold > len(required_signers) or inputs invalid.
        """
        if not trust_domain:
            raise ValueError("trustDomain is required")
        if not target_node_urn:
            raise ValueError("targetNodeUrn is required")
        if not required_signers:
            raise ValueError("requiredSigners must not be empty")
        if threshold < 1 or threshold > len(required_signers):
            raise ValueError(
                f"threshold must be between 1 and {len(required_signers)}, got {threshold}"
            )

        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        token_input = f"{trust_domain}:{target_node_urn}:{ts}"
        session_token = f"session_delegation_{hashlib.sha256(token_input.encode()).hexdigest()[:12]}"

        session = CeremonySession(
            session_token=session_token,
            trust_domain=trust_domain,
            target_node_urn=target_node_urn,
            required_signers=required_signers,
            threshold=threshold,
            created_at=ts,
            updated_at=ts,
        )
        self._sessions[session_token] = session
        return session

    def submit_signature(
        self,
        session_token: str,
        signer_spiffe_id: str,
        signature_share: str,
    ) -> CeremonySession:
        """Submit a signature share to an active ceremony.

        Args:
            session_token: The ceremony session token.
            signer_spiffe_id: SPIFFE ID of the signing operator.
            signature_share: The ECDSA/SHA256 signature share.

        Returns:
            Updated CeremonySession (may transition to ESTABLISHED).

        Raises:
            KeyError: If session not found.
            ValueError: If signer not authorized or session not PENDING.
        """
        session = self._sessions.get(session_token)
        if session is None:
            raise KeyError(f"Session '{session_token}' not found")

        if session.status != CeremonyStatus.PENDING:
            raise ValueError(f"Session is {session.status.value}, not PENDING")

        if signer_spiffe_id not in session.required_signers:
            raise ValueError(f"Signer '{signer_spiffe_id}' is not in the required signers list")

        if signer_spiffe_id in session.collected_signers:
            raise ValueError(f"Signer '{signer_spiffe_id}' has already signed")

        # Validate signature presence (real crypto verification is deferred)
        if not signature_share or len(signature_share) < 8:
            session.status = CeremonyStatus.FAULT
            session.updated_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            return session

        session.collected_signers.append(signer_spiffe_id)
        session.signatures_collected += 1
        session.updated_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        # Check if threshold reached
        if session.signatures_collected >= session.threshold:
            session.status = CeremonyStatus.ESTABLISHED
            # Compute attestation hash from all collected signatures
            combined = ":".join(session.collected_signers)
            session.attestation_hash = (
                f"0x{hashlib.sha256(combined.encode()).hexdigest()}"
            )

        return session

    def retract(self, session_token: str) -> CeremonySession:
        """Retract (cancel) a pending ceremony session.

        Args:
            session_token: The ceremony session token.

        Returns:
            The retracted CeremonySession.

        Raises:
            KeyError: If session not found.
        """
        session = self._sessions.get(session_token)
        if session is None:
            raise KeyError(f"Session '{session_token}' not found")

        session.status = CeremonyStatus.RETRACTED
        session.updated_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        return session

    def get_session(self, session_token: str) -> CeremonySession | None:
        """Retrieve a session by token."""
        return self._sessions.get(session_token)
