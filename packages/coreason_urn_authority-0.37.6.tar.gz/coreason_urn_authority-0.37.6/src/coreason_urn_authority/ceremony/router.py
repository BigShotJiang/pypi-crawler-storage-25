# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Keysigning Ceremony REST Router (#107).

Provides endpoints for multi-signature human keysigning ceremonies:
- POST /initiate — create a ceremony session
- POST /sign — submit a signature share
- POST /retract — cancel a ceremony
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from coreason_urn_authority.ceremony.session import CeremonyManager

ceremony_router = APIRouter(
    prefix="/api/v1/auth/delegation/ceremony",
    tags=["Keysigning Ceremony"],
)

# Module-level ceremony manager singleton
_manager = CeremonyManager()


def get_ceremony_manager() -> CeremonyManager:
    """Return the module-level CeremonyManager singleton."""
    return _manager


# ────────────────────────────────────────────────────────────────────
# Request/Response Models
# ────────────────────────────────────────────────────────────────────


class InitiateRequest(BaseModel):
    trust_domain: str = Field(..., alias="trustDomain")
    target_node_urn: str = Field(..., alias="targetNodeUrn")
    required_signers: list[str] = Field(..., alias="requiredSigners")
    threshold: int

    class Config:
        populate_by_name = True


class SignRequest(BaseModel):
    session_token: str = Field(..., alias="sessionToken")
    signer_spiffe_id: str = Field(..., alias="signerSpiffeId")
    signature_share: str = Field(..., alias="signatureShare")
    timestamp: str | None = None

    class Config:
        populate_by_name = True


class RetractRequest(BaseModel):
    session_token: str = Field(..., alias="sessionToken")

    class Config:
        populate_by_name = True


# ────────────────────────────────────────────────────────────────────
# Endpoints
# ────────────────────────────────────────────────────────────────────


@ceremony_router.post("/initiate")
async def initiate_ceremony(request: InitiateRequest) -> dict[str, Any]:
    """Create a new multi-signature ceremony session."""
    try:
        session = _manager.initiate(
            trust_domain=request.trust_domain,
            target_node_urn=request.target_node_urn,
            required_signers=request.required_signers,
            threshold=request.threshold,
        )
        return session.to_dict()
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e)) from e


@ceremony_router.post("/sign")
async def submit_signature(request: SignRequest) -> dict[str, Any]:
    """Submit a signature share to an active ceremony session."""
    try:
        session = _manager.submit_signature(
            session_token=request.session_token,
            signer_spiffe_id=request.signer_spiffe_id,
            signature_share=request.signature_share,
        )
        return session.to_dict()
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e)) from e


@ceremony_router.post("/retract")
async def retract_ceremony(request: RetractRequest) -> dict[str, Any]:
    """Retract (cancel) a pending ceremony session."""
    try:
        session = _manager.retract(session_token=request.session_token)
        return session.to_dict()
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
