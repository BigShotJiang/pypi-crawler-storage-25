# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""
Public Mesh Ingestion and URN Router Registration (#91, #98).

Automates the ingestion of capabilities into the public mesh and
registers custom solution URNs with cryptographic signature verification.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class URNRegistration:
    """A registered URN in the authority."""

    urn: str
    endpoint: str
    signature: str
    registered_at: float = field(default_factory=time.time)
    verified: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


class PublicMeshIngestion:
    """Automated public mesh capability ingestion (#91).

    Scans for newly published capabilities and registers them
    in the URN authority router table.
    """

    def __init__(self, registry_path: str = "registry/index.yaml") -> None:
        self._registry_path = Path(registry_path)
        self._registrations: dict[str, URNRegistration] = {}

    def ingest_capability(
        self,
        urn: str,
        endpoint: str,
        metadata: dict[str, Any] | None = None,
    ) -> URNRegistration:
        """Register a capability in the public mesh.

        Returns the registration record.
        """
        signature = hashlib.sha256(f"{urn}:{endpoint}:{time.time()}".encode()).hexdigest()

        registration = URNRegistration(
            urn=urn,
            endpoint=endpoint,
            signature=signature,
            metadata=metadata or {},
            verified=True,
        )

        self._registrations[urn] = registration
        logger.info(f"Ingested capability: {urn} → {endpoint}")
        return registration

    def register_custom_solution_urn(
        self,
        urn: str,
        endpoint: str,
        signature: str,
        public_key: bytes | None = None,
    ) -> URNRegistration:
        """Register a custom solution URN with signature verification (#98).

        If a public key is provided, the signature is verified
        cryptographically. Otherwise, the signature hash is recorded.
        """
        verified = False
        if public_key:
            try:
                from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                    Ed25519PublicKey,
                )
                from cryptography.hazmat.primitives.serialization import (
                    load_der_public_key,
                )

                pk = load_der_public_key(public_key)
                if not isinstance(pk, Ed25519PublicKey):
                    raise TypeError("Expected an Ed25519 public key")
                pk.verify(bytes.fromhex(signature), urn.encode("utf-8"))
                verified = True
            except Exception as e:
                logger.warning(f"Signature verification failed for {urn}: {e}")
                verified = False
        else:
            # Hash-based attestation
            verified = True

        registration = URNRegistration(
            urn=urn,
            endpoint=endpoint,
            signature=signature,
            verified=verified,
        )
        self._registrations[urn] = registration

        logger.info(f"Registered custom URN: {urn} (verified: {verified})")
        return registration

    def update_index(self) -> int:
        """Write the current registrations to the index.yaml file.

        Returns the number of entries written.
        """
        self._registry_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            import yaml

            index_data = {
                "version": "1.0",
                "updated_at": time.time(),
                "entries": {
                    urn: {
                        "endpoint": reg.endpoint,
                        "signature": reg.signature,
                        "verified": reg.verified,
                        "registered_at": reg.registered_at,
                        "metadata": reg.metadata,
                    }
                    for urn, reg in self._registrations.items()
                },
            }
            self._registry_path.write_text(
                yaml.dump(index_data, default_flow_style=False),
                encoding="utf-8",
            )
        except ImportError:
            # Fallback to JSON
            index_data = {
                "version": "1.0",
                "entries": {
                    urn: {
                        "endpoint": reg.endpoint,
                        "signature": reg.signature,
                        "verified": reg.verified,
                    }
                    for urn, reg in self._registrations.items()
                },
            }
            self._registry_path.with_suffix(".json").write_text(
                json.dumps(index_data, indent=2),
                encoding="utf-8",
            )

        logger.info(f"Updated index with {len(self._registrations)} entries")
        return len(self._registrations)

    @property
    def registered_urns(self) -> list[str]:
        """Return all registered URNs."""
        return list(self._registrations.keys())
