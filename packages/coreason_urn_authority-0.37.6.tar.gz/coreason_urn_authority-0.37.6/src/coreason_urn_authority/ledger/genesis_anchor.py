# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""
Cryptographic Ledger Anchoring for Genesis Timestamp (#92).

Implements a Sigstore-compatible DAG pattern for immutably anchoring the
cluster genesis timestamp into the local Epistemic Ledger. This replaces
the raw JSON file approach (registry/vault/temporal_state.json) with a
cryptographically signed and verifiable genesis record.

The genesis anchor contains:
- The cluster genesis timestamp (UTC epoch)
- An Ed25519 signature binding the timestamp to the node's identity
- A SHA-256 fingerprint of the signed payload for chain verification
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field

from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent

# ────────────────────────────────────────────────────────────────────
# Data Structures
# ────────────────────────────────────────────────────────────────────

_DEFAULT_ANCHOR_PATH = Path(os.getenv("COREASON_GENESIS_ANCHOR_PATH", "registry/vault/genesis_anchor.json"))


class GenesisAnchor(CoreasonBaseState):
    """AGENT INSTRUCTION: An immutable, cryptographically signed record anchoring
    the cluster genesis timestamp into the local Epistemic Ledger.

    CAUSAL AFFORDANCE: Enables tamper-evident verification of cluster age,
    preventing manual rollback or deletion attacks on the genesis time.

    EPISTEMIC BOUNDS: Frozen via CoreasonBaseState. The signature binds the
    genesis_time to the signing node's Ed25519 identity.
    """

    genesis_time: float = Field(
        description="The cluster genesis timestamp as a UTC epoch float.",
    )
    node_did: str = Field(
        description="The W3C DID of the signing node (e.g. did:key:z6Mk...).",
        default="did:key:local",
    )
    signature_hex: str = Field(
        description="Ed25519 signature of the canonical genesis payload (hex-encoded).",
        default="",
    )
    payload_hash: str = Field(
        description="SHA-256 hash of the signed canonical payload for chain verification.",
        default="",
    )
    anchored_at: float = Field(
        description="Epoch timestamp when the anchor was created.",
        default_factory=time.time,
    )


def _canonical_genesis_payload(genesis_time: float, node_did: str) -> str:
    """Produce a deterministic canonical representation for signing."""
    return json.dumps(
        {"genesis_time": genesis_time, "node_did": node_did},
        sort_keys=True,
        separators=(",", ":"),
    )


def create_genesis_anchor(
    genesis_time: float,
    private_key_hex: str | None = None,
    node_did: str = "did:key:local",
    anchor_path: Path | None = None,
) -> GenesisAnchor:
    """Create and persist a cryptographically signed genesis anchor.

    Args:
        genesis_time: The cluster genesis timestamp (UTC epoch).
        private_key_hex: Ed25519 private key seed as hex string.
            If None, uses COREASON_NODE_PRIVATE_KEY env var.
        node_did: The W3C DID identifier for this node.
        anchor_path: Path to persist the anchor. Defaults to genesis_anchor.json.

    Returns:
        The created GenesisAnchor.

    Raises:
        TopologicalSeveranceEvent: If an anchor already exists (immutability).
    """
    path = anchor_path or _DEFAULT_ANCHOR_PATH

    if path.exists():
        raise TopologicalSeveranceEvent(
            f"Genesis anchor already exists at {path}. "
            "Overwriting a genesis anchor is forbidden — this would constitute "
            "a temporal tampering attack. To re-anchor, delete the existing "
            "anchor explicitly and document the reason."
        )

    canonical = _canonical_genesis_payload(genesis_time, node_did)
    payload_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    signature_hex = ""
    if private_key_hex is None:
        private_key_hex = os.getenv("COREASON_NODE_PRIVATE_KEY", "")

    if private_key_hex:
        try:
            from cryptography.hazmat.primitives.asymmetric import ed25519

            key_bytes = bytes.fromhex(private_key_hex)
            private_key = ed25519.Ed25519PrivateKey.from_private_bytes(key_bytes)
            signature = private_key.sign(canonical.encode("utf-8"))
            signature_hex = signature.hex()
        except Exception as e:
            raise TopologicalSeveranceEvent(f"Failed to sign genesis anchor: {e}") from e
    else:
        # In development mode, use HMAC-SHA256 with a node-local secret
        import hmac

        node_secret = os.getenv("COREASON_NODE_SECRET", "dev-only-secret")
        signature_hex = hmac.new(node_secret.encode(), canonical.encode(), hashlib.sha256).hexdigest()

    anchor = GenesisAnchor(
        genesis_time=genesis_time,
        node_did=node_did,
        signature_hex=signature_hex,
        payload_hash=payload_hash,
    )

    # Persist the anchor
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        anchor.model_dump_json(indent=2),
        encoding="utf-8",
    )

    return anchor


def load_genesis_anchor(anchor_path: Path | None = None) -> GenesisAnchor:
    """Load and return the persisted genesis anchor.

    Raises:
        TopologicalSeveranceEvent: If the anchor file is missing.
    """
    path = anchor_path or _DEFAULT_ANCHOR_PATH
    if not path.exists():
        raise TopologicalSeveranceEvent(
            f"Genesis anchor not found at {path}. The cluster genesis has not been cryptographically anchored."
        )

    data = json.loads(path.read_text(encoding="utf-8"))
    return GenesisAnchor.model_validate(data)


def verify_genesis_anchor(
    anchor: GenesisAnchor,
    public_key_hex: str | None = None,
) -> bool:
    """Verify the cryptographic integrity of a genesis anchor.

    Checks:
    1. The payload_hash matches the canonical genesis payload
    2. The Ed25519 signature is valid (if public key provided)

    Returns:
        True if verification passes.

    Raises:
        TopologicalSeveranceEvent: If verification fails.
    """
    canonical = _canonical_genesis_payload(anchor.genesis_time, anchor.node_did)
    expected_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    if anchor.payload_hash != expected_hash:
        raise TopologicalSeveranceEvent(
            f"Genesis anchor payload hash mismatch: "
            f"expected {expected_hash[:16]}... but got {anchor.payload_hash[:16]}... "
            f"This indicates the genesis timestamp or node DID has been tampered with."
        )

    if public_key_hex:
        try:
            from cryptography.hazmat.primitives.asymmetric import ed25519

            key_bytes = bytes.fromhex(public_key_hex)
            public_key = ed25519.Ed25519PublicKey.from_public_bytes(key_bytes)
            public_key.verify(
                bytes.fromhex(anchor.signature_hex),
                canonical.encode("utf-8"),
            )
        except Exception as e:
            raise TopologicalSeveranceEvent(f"Genesis anchor signature verification failed: {e}") from e

    return True


def get_verified_genesis_time(
    anchor_path: Path | None = None,
    public_key_hex: str | None = None,
) -> float:
    """Load, verify, and return the genesis timestamp.

    This is the primary API for consumers who need to know the cluster
    genesis time with cryptographic assurance.
    """
    anchor = load_genesis_anchor(anchor_path)
    verify_genesis_anchor(anchor, public_key_hex)
    return anchor.genesis_time
