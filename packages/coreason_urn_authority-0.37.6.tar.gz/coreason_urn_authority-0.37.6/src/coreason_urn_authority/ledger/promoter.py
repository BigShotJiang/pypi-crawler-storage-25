# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""OCI Artifact Ledger Promoter.

Automates the addition of new URNs to the ledger.
"""

from pathlib import Path

from ruamel.yaml import YAML

from coreason_urn_authority.ledger.loader import LedgerEntry, MCPRegistryRef


def append_to_ledger(
    ledger_path: Path,
    urn: str,
    oci_uri: str,
    did: str,
    tenant_cid: str,
    mcp_namespace: str | None = None,
) -> None:
    """Appends a new capability to the YAML ledger while preserving comments.

    Args:
        ledger_path: Path to the ledger YAML file.
        urn: The CoReason URN.
        oci_uri: The OCI artifact URI.
        did: The W3C did:key of the authorized signer.
        tenant_cid: The tenant capability identifier.
        mcp_namespace: Optional MCP Registry reverse-DNS namespace.
    """
    mcp_registry = None
    if mcp_namespace:
        mcp_registry = MCPRegistryRef(
            namespace=mcp_namespace,
            registry_url="https://registry.modelcontextprotocol.io",
            verified=True,
        )

    entry_model = LedgerEntry(
        urn=urn,
        oci_uri=oci_uri,
        authorized_signer_did=did,
        tenant_cid=tenant_cid,
        mcp_registry=mcp_registry,
    )

    yaml_parser = YAML()
    yaml_parser.preserve_quotes = True
    yaml_parser.indent(mapping=2, sequence=4, offset=2)

    import filelock

    lock_path = ledger_path.with_suffix(".lock")

    with filelock.FileLock(lock_path, timeout=10.0):
        if ledger_path.exists():
            with open(ledger_path, encoding="utf-8") as f:
                ledger_content = yaml_parser.load(f)
        else:
            ledger_content = None

        if ledger_content is None:
            ledger_content = {}

        if "capabilities" not in ledger_content or ledger_content["capabilities"] is None:
            ledger_content["capabilities"] = []

        # Convert model to native dict
        entry_dict = entry_model.model_dump(exclude_none=True)
        ledger_content["capabilities"].append(entry_dict)

        with open(ledger_path, "w", encoding="utf-8") as f:
            yaml_parser.dump(ledger_content, f)
