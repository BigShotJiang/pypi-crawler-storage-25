# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at [https://prosperitylicense.com/versions/3.0.0](https://prosperitylicense.com/versions/3.0.0)
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.

from pathlib import Path

import pytest

from coreason_urn_authority.cli import main
from coreason_urn_authority.crypto.cosign_verifier import (
    TopologicalSeveranceEvent,
    compute_canonical_hash,
    verify_code_attestation,
)
from coreason_urn_authority.epistemic import EpistemicFilter, EpistemicValidationError

SCHEMA_CODE = """from pydantic import BaseModel

class UserPayload(BaseModel):
    name: str
    age: int
"""

VALID_PAYLOAD = '{"name": "Alice", "age": 30}'
INVALID_PAYLOAD_SCHEMA = '{"name": "Alice"}'  # missing age
INVALID_PAYLOAD_JSON = '{"name": "Alice", age: 30'  # invalid JSON


def test_code_attestation_success(tmp_path: Path) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    expected_hash = compute_canonical_hash(code_content)

    # 1. Direct hash verification
    verify_code_attestation(code_file, expected_hash)

    # 2. Sidecar file verification (sidecar_1 pattern)
    hash_file = code_file.with_suffix(".py.hash")
    hash_file.write_text(expected_hash, encoding="utf-8")
    verify_code_attestation(code_file, None)


def test_code_attestation_sidecar_2(tmp_path: Path) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    expected_hash = compute_canonical_hash(code_content)

    # sidecar_2 pattern: parent / (name + ".hash")
    hash_file = tmp_path / "app.py.hash"
    hash_file.write_text(expected_hash, encoding="utf-8")
    verify_code_attestation(code_file, None)


def test_code_attestation_nonexistent_file(tmp_path: Path) -> None:
    nonexistent = tmp_path / "ghost.py"
    with pytest.raises(TopologicalSeveranceEvent, match="Attestation target code file does not exist"):
        verify_code_attestation(nonexistent, None)


def test_code_attestation_read_error(tmp_path: Path) -> None:
    # A directory path cannot be read_text, triggering the exception block
    dir_path = tmp_path / "my_dir"
    dir_path.mkdir()
    with pytest.raises(TopologicalSeveranceEvent, match="Failed to read and hash target file"):
        verify_code_attestation(dir_path, None)


def test_code_attestation_expected_hash_path(tmp_path: Path) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    expected_hash = compute_canonical_hash(code_content)
    hash_path = tmp_path / "expected.hash"
    hash_path.write_text(expected_hash, encoding="utf-8")

    # Pass Path object
    verify_code_attestation(code_file, hash_path)

    # Pass nonexistent Path object
    nonexistent_hash_path = tmp_path / "ghost.hash"
    with pytest.raises(TopologicalSeveranceEvent, match="Expected hash file path does not exist"):
        verify_code_attestation(code_file, nonexistent_hash_path)


def test_code_attestation_empty_expected_hash(tmp_path: Path) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    with pytest.raises(TopologicalSeveranceEvent, match="Empty expected hash"):
        verify_code_attestation(code_file, "")


def test_code_attestation_mismatch(tmp_path: Path) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    wrong_hash = compute_canonical_hash("different content")

    with pytest.raises(TopologicalSeveranceEvent, match="Zero-Trust Attestation Handshake Failed"):
        verify_code_attestation(code_file, wrong_hash)


def test_code_attestation_missing_sidecar(tmp_path: Path) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    with pytest.raises(TopologicalSeveranceEvent, match="No sidecar hash file found"):
        verify_code_attestation(code_file, None)


def test_epistemic_filtering_success(tmp_path: Path) -> None:
    schema_file = tmp_path / "schema.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    filt = EpistemicFilter()
    res = filt.filter_payload(VALID_PAYLOAD, schema_file, "UserPayload")
    assert res["name"] == "Alice"
    assert res["age"] == 30


def test_epistemic_filtering_missing_schema_file(tmp_path: Path) -> None:
    nonexistent_schema = tmp_path / "ghost_schema.py"
    filt = EpistemicFilter()
    with pytest.raises(FileNotFoundError, match="Schema file not found"):
        filt.filter_payload(VALID_PAYLOAD, nonexistent_schema, "UserPayload")


def test_epistemic_filtering_validation_error(tmp_path: Path) -> None:
    schema_file = tmp_path / "schema.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    filt = EpistemicFilter()
    with pytest.raises(EpistemicValidationError) as excinfo:
        filt.filter_payload(INVALID_PAYLOAD_SCHEMA, schema_file, "UserPayload")
    assert excinfo.value.model_name == "UserPayload"
    assert "ValidationError" in excinfo.value.args[0]


def test_epistemic_filtering_json_error(tmp_path: Path) -> None:
    schema_file = tmp_path / "schema.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    filt = EpistemicFilter()
    with pytest.raises(EpistemicValidationError) as excinfo:
        filt.filter_payload(INVALID_PAYLOAD_JSON, schema_file, "UserPayload")
    assert "JSONError" in excinfo.value.args[0]


def test_epistemic_self_healing_simulated(tmp_path: Path) -> None:
    schema_file = tmp_path / "schema.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    filt = EpistemicFilter()
    # Payload covering boolean, integer, float, list, and string type-check branches
    rich_invalid_payload = '{"is_active": true, "count": 10, "ratio": 1.5, "items": ["a", "b"], "name": "Alice"}'
    res = filt.trigger_self_healing(schema_file, "UserPayload", rich_invalid_payload)
    assert len(res) > 0

    # Also check JSON exception fallback branch inside trigger_self_healing
    res_bad_json = filt.trigger_self_healing(schema_file, "UserPayload", "invalid { json")
    assert len(res_bad_json) > 0


def test_cli_verify_attestation_success(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    expected_hash = compute_canonical_hash(code_content)

    main(["verify-attestation", str(code_file), "--expected-hash", expected_hash])
    captured = capsys.readouterr()
    assert "Attestation succeeded" in captured.out


def test_cli_verify_attestation_failure(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    code_file = tmp_path / "app.py"
    code_content = "print('Hello World')\n"
    code_file.write_text(code_content, encoding="utf-8")

    wrong_hash = compute_canonical_hash("different content")

    with pytest.raises(SystemExit) as excinfo:
        main(["verify-attestation", str(code_file), "--expected-hash", wrong_hash])
    assert excinfo.value.code == 1
    captured = capsys.readouterr()
    assert "Error:" in captured.out


def test_cli_filter_payload_success(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    schema_file = tmp_path / "schema.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    payload_file = tmp_path / "payload.json"
    payload_file.write_text(VALID_PAYLOAD, encoding="utf-8")

    main(["filter-payload", str(schema_file), "UserPayload", str(payload_file)])
    captured = capsys.readouterr()
    assert "Payload validation succeeded" in captured.out
    assert "Alice" in captured.out


def test_cli_filter_payload_read_error(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    schema_file = tmp_path / "schema.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    with pytest.raises(SystemExit) as excinfo:
        main(["filter-payload", str(schema_file), "UserPayload", "nonexistent_payload.json"])
    assert excinfo.value.code == 1
    captured = capsys.readouterr()
    assert "Error reading payload file" in captured.out


def test_cli_filter_payload_failure_with_self_healing(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    schema_file = tmp_path / "schema.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    payload_file = tmp_path / "payload.json"
    payload_file.write_text(INVALID_PAYLOAD_SCHEMA, encoding="utf-8")

    with pytest.raises(SystemExit) as excinfo:
        main(["filter-payload", str(schema_file), "UserPayload", str(payload_file), "--trigger-self-healing"])
    assert excinfo.value.code == 1
    captured = capsys.readouterr()
    assert "Validation Error" in captured.out
    assert "Triggering self-healing" in captured.out
    assert "Self-healing successfully completed" in captured.out


def test_cli_filter_payload_failure_with_self_healing_error(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    # Trigger a self-healing failure (e.g. invalid target schema path)
    payload_file = tmp_path / "payload.json"
    payload_file.write_text(INVALID_PAYLOAD_SCHEMA, encoding="utf-8")

    # Pass a nonexistent schema_file but let the first check pass by mocking or bypassing.
    # Actually, filter_payload checks if schema exists, so we make it a valid file but it's empty, causing validation to fail.
    empty_schema_file = tmp_path / "empty_schema.py"
    empty_schema_file.write_text("", encoding="utf-8")
    with pytest.raises(SystemExit) as excinfo:
        main(["filter-payload", str(empty_schema_file), "UserPayload", str(payload_file), "--trigger-self-healing"])
    assert excinfo.value.code == 1
    captured = capsys.readouterr()
    assert "Validation Error" in captured.out


def test_epistemic_deep_geometry_inference() -> None:
    filt = EpistemicFilter()
    rich_payload = {
        "user": {"name": "Bob", "metadata": {"active": True, "score": 4.5}},
        "tags": ["admin", "dev"],
        "age": 42,
    }
    schema = filt._infer_deep_geometry(rich_payload)
    assert schema["type"] == "object"
    assert "user" in schema["properties"]
    user_schema = schema["properties"]["user"]
    assert user_schema["type"] == "object"
    assert user_schema["required"] == ["name", "metadata"]

    metadata_schema = user_schema["properties"]["metadata"]
    assert metadata_schema["type"] == "object"
    assert metadata_schema["properties"]["active"]["type"] == "boolean"
    assert metadata_schema["properties"]["score"]["type"] == "number"


def test_epistemic_filtering_benchmark(tmp_path: Path) -> None:
    import subprocess
    import sys
    import time

    # 1. Warm up the pool
    schema_file = tmp_path / "schema_bench.py"
    schema_file.write_text(SCHEMA_CODE, encoding="utf-8")

    filt = EpistemicFilter()
    filt.filter_payload(VALID_PAYLOAD, schema_file, "UserPayload")

    # Measure warm pool latency
    start_pool = time.perf_counter()
    for _ in range(5):
        filt.filter_payload(VALID_PAYLOAD, schema_file, "UserPayload")
    end_pool = time.perf_counter()
    avg_pool_ms = ((end_pool - start_pool) / 5) * 1000

    # Measure simulated legacy subprocess spawn latency
    driver_code = """import sys, json, importlib.util
from pathlib import Path
payload_data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
spec = importlib.util.spec_from_file_location("mod", sys.argv[2])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
model = getattr(module, sys.argv[3])
model.model_rebuild()
inst = model(**payload_data)
"""
    driver_file = tmp_path / "driver_bench.py"
    driver_file.write_text(driver_code, encoding="utf-8")

    payload_file = tmp_path / "payload_bench.json"
    payload_file.write_text(VALID_PAYLOAD, encoding="utf-8")

    start_legacy = time.perf_counter()
    for _ in range(5):
        subprocess.run(
            [sys.executable, str(driver_file), str(payload_file), str(schema_file), "UserPayload"],
            capture_output=True,
            check=True,
        )
    end_legacy = time.perf_counter()
    avg_legacy_ms = ((end_legacy - start_legacy) / 5) * 1000

    print(f"\n[BENCHMARK] Legacy spawn: {avg_legacy_ms:.2f}ms | Warm Pool: {avg_pool_ms:.2f}ms")

    # The pool should be significantly faster (at least 2x faster, usually 10x-30x faster)
    import os

    if os.environ.get("COREASON_STRICT_BENCHMARK", "false").lower() == "true":
        assert avg_pool_ms < avg_legacy_ms
