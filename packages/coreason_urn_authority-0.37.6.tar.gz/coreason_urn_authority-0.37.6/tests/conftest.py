# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Global test fixtures for coreason-urn-authority."""

from __future__ import annotations

import pytest


@pytest.fixture(autouse=True)
def _allow_all_dids(monkeypatch: pytest.MonkeyPatch) -> None:
    """By default, allow all DIDs in tests.

    Sprint C changed is_authorized_tenant_did() to fail-closed when
    COREASON_AUTHORIZED_DIDS is unset. This fixture sets the wildcard
    to preserve backward-compatible test behavior.
    """
    monkeypatch.setenv("COREASON_AUTHORIZED_DIDS", "*")
