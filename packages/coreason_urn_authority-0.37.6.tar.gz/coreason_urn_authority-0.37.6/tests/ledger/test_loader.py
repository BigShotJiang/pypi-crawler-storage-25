# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the OCI Artifact Ledger Loader.

All tests use real YAML files written to temporary directories —
no mocking, per the Anti-Mock directive.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent
from coreason_urn_authority.ledger.loader import (
    LedgerEntry,
    load_ledger,
    resolve_urn,
)


def _write_ledger(tmp_path: Path, capabilities: list[dict[str, str]]) -> Path:
    """Write a real YAML ledger file to a temporary directory."""
    ledger_path = tmp_path / "index.yaml"
    ledger_path.write_text(
        yaml.dump({"capabilities": capabilities}, default_flow_style=False),
        encoding="utf-8",
    )
    return ledger_path


class TestLoadLedger:
    """Tests for loading the YAML ledger."""

    def test_load_success(self, tmp_path: Path) -> None:
        path = _write_ledger(
            tmp_path,
            [
                {
                    "urn": "urn:coreason:solver:test_v1",
                    "oci_uri": "ghcr.io/test:v1",
                    "authorized_signer_did": "did:key:z6MkTest",
                },
            ],
        )
        entries = load_ledger(path)
        assert len(entries) == 1
        assert entries[0].urn == "urn:coreason:solver:test_v1"
        assert entries[0].oci_uri == "ghcr.io/test:v1"
        assert entries[0].authorized_signer_did == "did:key:z6MkTest"

    def test_load_multiple_entries(self, tmp_path: Path) -> None:
        path = _write_ledger(
            tmp_path,
            [
                {
                    "urn": "urn:coreason:solver:a_v1",
                    "oci_uri": "ghcr.io/a:v1",
                    "authorized_signer_did": "did:key:z6MkA",
                },
                {
                    "urn": "urn:coreason:oracle:b_v1",
                    "oci_uri": "ghcr.io/b:v1",
                    "authorized_signer_did": "did:key:z6MkB",
                },
            ],
        )
        entries = load_ledger(path)
        assert len(entries) == 2
        assert entries[0].urn == "urn:coreason:solver:a_v1"
        assert entries[1].urn == "urn:coreason:oracle:b_v1"

    def test_load_empty_capabilities(self, tmp_path: Path) -> None:
        path = _write_ledger(tmp_path, [])
        entries = load_ledger(path)
        assert entries == []

    def test_load_empty_file(self, tmp_path: Path) -> None:
        path = tmp_path / "index.yaml"
        path.write_text("", encoding="utf-8")
        entries = load_ledger(path)
        assert entries == []

    def test_load_missing_file(self, tmp_path: Path) -> None:
        missing = tmp_path / "nonexistent.yaml"
        with pytest.raises(TopologicalSeveranceEvent, match="OCI Ledger not found"):
            load_ledger(missing)

    def test_load_malformed_entry_missing_urn(self, tmp_path: Path) -> None:
        path = _write_ledger(
            tmp_path,
            [
                {
                    "oci_uri": "ghcr.io/test:v1",
                    "authorized_signer_did": "did:key:z6MkTest",
                },
            ],
        )
        with pytest.raises(TopologicalSeveranceEvent, match="missing required fields"):
            load_ledger(path)

    def test_load_malformed_entry_missing_oci_uri(self, tmp_path: Path) -> None:
        path = _write_ledger(
            tmp_path,
            [
                {
                    "urn": "urn:coreason:solver:test_v1",
                    "authorized_signer_did": "did:key:z6MkTest",
                },
            ],
        )
        with pytest.raises(TopologicalSeveranceEvent, match="missing required fields"):
            load_ledger(path)

    def test_load_default_ledger(self) -> None:
        """The bundled index.yaml should load successfully."""
        entries = load_ledger()
        assert len(entries) > 0
        for entry in entries:
            assert entry.urn.startswith("urn:coreason:")
            assert entry.authorized_signer_did.startswith("did:key:")

    def test_entry_immutability(self, tmp_path: Path) -> None:
        path = _write_ledger(
            tmp_path,
            [
                {
                    "urn": "urn:coreason:solver:test_v1",
                    "oci_uri": "ghcr.io/test:v1",
                    "authorized_signer_did": "did:key:z6MkTest",
                },
            ],
        )
        entries = load_ledger(path)
        with pytest.raises(ValidationError):
            entries[0].urn = "tampered"


class TestResolveURN:
    """Tests for URN resolution within the ledger."""

    def test_resolve_found(self) -> None:
        ledger = [
            LedgerEntry(
                urn="urn:coreason:solver:test_v1",
                oci_uri="ghcr.io/test:v1",
                authorized_signer_did="did:key:z6MkTest",
            ),
        ]
        entry = resolve_urn("urn:coreason:solver:test_v1", ledger)
        assert entry.oci_uri == "ghcr.io/test:v1"

    def test_resolve_not_found(self) -> None:
        ledger = [
            LedgerEntry(
                urn="urn:coreason:solver:test_v1",
                oci_uri="ghcr.io/test:v1",
                authorized_signer_did="did:key:z6MkTest",
            ),
        ]
        with pytest.raises(TopologicalSeveranceEvent, match="not found in OCI Ledger"):
            resolve_urn("urn:coreason:solver:nonexistent_v1", ledger)

    def test_resolve_empty_ledger(self) -> None:
        with pytest.raises(TopologicalSeveranceEvent, match="not found in OCI Ledger"):
            resolve_urn("urn:coreason:solver:any_v1", [])

    def test_resolve_returns_correct_entry(self) -> None:
        ledger = [
            LedgerEntry(urn="urn:a", oci_uri="ghcr.io/a:v1", authorized_signer_did="did:key:zA"),
            LedgerEntry(urn="urn:b", oci_uri="ghcr.io/b:v1", authorized_signer_did="did:key:zB"),
        ]
        entry = resolve_urn("urn:b", ledger)
        assert entry.oci_uri == "ghcr.io/b:v1"
        assert entry.authorized_signer_did == "did:key:zB"


def test_resolve_custom_solution_urns_and_did_decoding() -> None:
    """Verify that resolving registered Custom Solution URNs yields a valid entry

    and that the developer DID correctly decodes to PEM.
    """
    from coreason_urn_authority.crypto.cosign_verifier import (
        extract_public_key_pem_from_did,
    )

    custom_urns = [
        "urn:coreason:oracle:ontological_vocabulary:v1",
        "urn:coreason:effector:sovereign_etl:v1",
        "urn:coreason:solver:market_access_rebate_opt:v1",
        "urn:coreason:node:autonomous_agent_lifecycle:v1",
        "urn:coreason:solver:high_stakes_reasoning:v1",
        "urn:coreason:node:edge_sensor_sandboxed:v1",
    ]

    ledger = load_ledger()
    for urn in custom_urns:
        entry = resolve_urn(urn, ledger)
        assert entry is not None
        assert entry.urn == urn
        # Verify that the authorized_signer_did decodes to a valid PEM string
        pem = extract_public_key_pem_from_did(entry.authorized_signer_did)
        assert pem.startswith("-----BEGIN PUBLIC KEY-----\n")
        assert pem.strip().endswith("-----END PUBLIC KEY-----")


# ---------------------------------------------------------------------------
# Sprint D: Ledger Cache Tests (D5.1)
# ---------------------------------------------------------------------------


class TestCachedLoadLedger:
    """Tests for cached_load_ledger with file-mtime caching."""

    def test_returns_same_on_unchanged_file(self, tmp_path: Path) -> None:
        from coreason_urn_authority.ledger.loader import (
            _ledger_cache,
            cached_load_ledger,
        )

        _ledger_cache.invalidate()  # Clean state
        path = _write_ledger(
            tmp_path,
            [{"urn": "urn:coreason:solver:a_v1", "oci_uri": "ghcr.io/a:v1", "authorized_signer_did": "did:key:zA"}],
        )
        first = cached_load_ledger(path)
        second = cached_load_ledger(path)
        assert first is second  # Same object = cache hit

    def test_reloads_on_mtime_change(self, tmp_path: Path) -> None:
        import os

        from coreason_urn_authority.ledger.loader import (
            _ledger_cache,
            cached_load_ledger,
        )

        _ledger_cache.invalidate()
        path = _write_ledger(
            tmp_path,
            [{"urn": "urn:coreason:solver:a_v1", "oci_uri": "ghcr.io/a:v1", "authorized_signer_did": "did:key:zA"}],
        )
        first = cached_load_ledger(path)
        assert len(first) == 1

        # Modify file with different content
        import time

        time.sleep(0.05)
        _write_ledger(
            tmp_path,
            [
                {"urn": "urn:coreason:solver:a_v1", "oci_uri": "ghcr.io/a:v1", "authorized_signer_did": "did:key:zA"},
                {"urn": "urn:coreason:solver:b_v1", "oci_uri": "ghcr.io/b:v1", "authorized_signer_did": "did:key:zB"},
            ],
        )
        # Touch the file to change mtime (in case the write was too fast)
        os.utime(path, None)

        second = cached_load_ledger(path)
        assert len(second) == 2
        assert first is not second  # Different object = cache miss

    def test_independent_paths(self, tmp_path: Path) -> None:
        from coreason_urn_authority.ledger.loader import (
            _ledger_cache,
            cached_load_ledger,
        )

        _ledger_cache.invalidate()
        dir_a = tmp_path / "a"
        dir_a.mkdir()
        dir_b = tmp_path / "b"
        dir_b.mkdir()

        path_a = _write_ledger(
            dir_a,
            [{"urn": "urn:coreason:solver:a_v1", "oci_uri": "ghcr.io/a:v1", "authorized_signer_did": "did:key:zA"}],
        )
        path_b = _write_ledger(
            dir_b,
            [
                {"urn": "urn:coreason:solver:b_v1", "oci_uri": "ghcr.io/b:v1", "authorized_signer_did": "did:key:zB"},
                {"urn": "urn:coreason:solver:c_v1", "oci_uri": "ghcr.io/c:v1", "authorized_signer_did": "did:key:zC"},
            ],
        )

        result_a = cached_load_ledger(path_a)
        result_b = cached_load_ledger(path_b)
        assert len(result_a) == 1
        assert len(result_b) == 2

    def test_invalidate_clears_cache(self, tmp_path: Path) -> None:
        from coreason_urn_authority.ledger.loader import (
            _ledger_cache,
            cached_load_ledger,
        )

        _ledger_cache.invalidate()
        path = _write_ledger(
            tmp_path,
            [{"urn": "urn:coreason:solver:a_v1", "oci_uri": "ghcr.io/a:v1", "authorized_signer_did": "did:key:zA"}],
        )
        first = cached_load_ledger(path)
        _ledger_cache.invalidate()
        second = cached_load_ledger(path)
        assert first is not second  # Different object after invalidation


# ---------------------------------------------------------------------------
# Sprint D: Module-Level URN Pattern Test (D5.2)
# ---------------------------------------------------------------------------


def test_urn_pattern_is_module_level_constant() -> None:
    """Verify _URN_PATTERN is compiled at module level, not per-call."""
    from coreason_urn_authority.routing.semantic_router import _URN_PATTERN

    assert _URN_PATTERN is not None
    assert _URN_PATTERN.match("urn:coreason:solver:test_v1")
    assert not _URN_PATTERN.match("invalid")
