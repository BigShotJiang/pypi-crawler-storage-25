# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the Semantic Router — URN-to-Verified-OCI Resolution.

Uses dependency inversion for the cosign subprocess runner and real
YAML ledger files. No mocking.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent
from coreason_urn_authority.routing.semantic_router import (
    VerifiedCapabilityReceipt,
    is_authorized_tenant_did,
    list_capabilities,
    resolve_capability,
)


def _write_test_ledger(tmp_path: Path) -> Path:
    """Write a test ledger with a valid Ed25519 DID."""
    # Generate a valid did:key for an Ed25519 key (32 zero bytes)
    raw_pubkey = bytes(32)
    multicodec_bytes = b"\xed\x01" + raw_pubkey
    n = int.from_bytes(multicodec_bytes, "big")
    alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    chars: list[int] = []
    while n > 0:
        n, remainder = divmod(n, 58)
        chars.append(alphabet[remainder])
    for byte in multicodec_bytes:
        if byte == 0:
            chars.append(alphabet[0])
        else:
            break
    encoded = bytes(reversed(chars)).decode("ascii")
    did_key = f"did:key:z{encoded}"

    ledger_path = tmp_path / "index.yaml"
    ledger_path.write_text(
        yaml.dump(
            {
                "capabilities": [
                    {
                        "urn": "urn:coreason:solver:test_v1",
                        "oci_uri": "ghcr.io/coreason-ai/test-solver:v1.0.0",
                        "authorized_signer_did": did_key,
                    },
                ]
            },
            default_flow_style=False,
        ),
        encoding="utf-8",
    )
    return ledger_path


def _success_runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
    """Deterministic runner that simulates successful cosign verification."""
    return subprocess.CompletedProcess(
        args=["cosign", "verify"],
        returncode=0,
        stdout=json.dumps([{"critical": {"identity": {}}}]),
        stderr="",
    )


def _failure_runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
    """Deterministic runner that simulates cosign verification failure."""
    return subprocess.CompletedProcess(
        args=["cosign", "verify"],
        returncode=1,
        stdout="",
        stderr="Error: no matching signatures: signature mismatch",
    )


class TestResolveCapability:
    """Tests for the resolve_capability function."""

    def test_successful_resolution(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        receipt = resolve_capability(
            "urn:coreason:solver:test_v1",
            ledger_path=ledger_path,
            runner=_success_runner,
        )
        assert isinstance(receipt, VerifiedCapabilityReceipt)
        assert receipt.urn == "urn:coreason:solver:test_v1"
        assert receipt.oci_uri == "ghcr.io/coreason-ai/test-solver:v1.0.0"

    def test_unknown_urn_raises_severance(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="not found in OCI Ledger"):
            resolve_capability(
                "urn:coreason:solver:nonexistent_v1",
                ledger_path=ledger_path,
                runner=_success_runner,
            )

    def test_tampered_signature_raises_severance(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="OCI signature verification failed"):
            resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=ledger_path,
                runner=_failure_runner,
            )

    def test_receipt_is_immutable(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        receipt = resolve_capability(
            "urn:coreason:solver:test_v1",
            ledger_path=ledger_path,
            runner=_success_runner,
        )
        with pytest.raises(ValidationError):
            receipt.urn = "tampered"

    def test_missing_ledger_raises_severance(self, tmp_path: Path) -> None:
        with pytest.raises(TopologicalSeveranceEvent, match="OCI Ledger not found"):
            resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=tmp_path / "nonexistent.yaml",
                runner=_success_runner,
            )


class TestListCapabilities:
    """Tests for the list_capabilities function."""

    def test_list_returns_entries(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        entries = list_capabilities(ledger_path=ledger_path)
        assert len(entries) == 1
        assert entries[0].urn == "urn:coreason:solver:test_v1"

    def test_list_empty_ledger(self, tmp_path: Path) -> None:
        ledger_path = tmp_path / "index.yaml"
        ledger_path.write_text(yaml.dump({"capabilities": []}), encoding="utf-8")
        entries = list_capabilities(ledger_path=ledger_path)
        assert entries == []


class TestAuthorizedTenantDID:
    """Tests for authorized tenant DID validation."""

    def test_authorized_did_success(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)

        # Determine the DID from the test ledger
        from coreason_urn_authority.ledger.loader import load_ledger

        entries = load_ledger(ledger_path)
        did = entries[0].authorized_signer_did

        import os

        old_val = os.environ.get("COREASON_AUTHORIZED_DIDS")
        try:
            os.environ["COREASON_AUTHORIZED_DIDS"] = did
            receipt = resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=ledger_path,
                runner=_success_runner,
            )
            assert receipt.authorized_signer_did == did
        finally:
            if old_val is not None:
                os.environ["COREASON_AUTHORIZED_DIDS"] = old_val
            else:
                del os.environ["COREASON_AUTHORIZED_DIDS"]

    def test_unauthorized_did_failure(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)

        import os

        old_val = os.environ.get("COREASON_AUTHORIZED_DIDS")
        try:
            os.environ["COREASON_AUTHORIZED_DIDS"] = "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB"
            with pytest.raises(TopologicalSeveranceEvent, match="Unauthorized Signer"):
                resolve_capability(
                    "urn:coreason:solver:test_v1",
                    ledger_path=ledger_path,
                    runner=_success_runner,
                )
        finally:
            if old_val is not None:
                os.environ["COREASON_AUTHORIZED_DIDS"] = old_val
            else:
                del os.environ["COREASON_AUTHORIZED_DIDS"]


class TestVaultFailClosed:
    """Tests for Vault fail-closed logic under connection exceptions."""

    def test_vault_fail_closed_governance_exception(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        monkeypatch.setenv("COREASON_VAULT_FAIL_CLOSED", "true")
        monkeypatch.setenv("COREASON_VAULT_LEGACY", "true")
        monkeypatch.setenv("VAULT_TOKEN", "test-token")
        # Point to a completely invalid port/address to trigger urllib connection exception
        monkeypatch.setenv("VAULT_ADDR", "http://127.0.0.1:9999")

        with pytest.raises(TopologicalSeveranceEvent, match="Vault communication failed during governance check"):
            resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=ledger_path,
                runner=_success_runner,
            )

    def test_vault_fail_open_by_default(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        # Verify that by default (or set to false), it doesn't fail closed
        monkeypatch.setenv("COREASON_VAULT_FAIL_CLOSED", "false")
        monkeypatch.setenv("COREASON_VAULT_LEGACY", "true")
        monkeypatch.setenv("VAULT_TOKEN", "test-token")
        monkeypatch.setenv("VAULT_ADDR", "http://127.0.0.1:9999")

        receipt = resolve_capability(
            "urn:coreason:solver:test_v1",
            ledger_path=ledger_path,
            runner=_success_runner,
        )
        assert isinstance(receipt, VerifiedCapabilityReceipt)


class TestURNFormatValidation:
    """Tests for URN format validation in resolve_capability (Sprint C: C1.1)."""

    def test_valid_urn_format(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        receipt = resolve_capability(
            "urn:coreason:solver:test_v1",
            ledger_path=ledger_path,
            runner=_success_runner,
        )
        assert receipt.urn == "urn:coreason:solver:test_v1"

    def test_empty_urn_rejected(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="Invalid URN format"):
            resolve_capability("", ledger_path=ledger_path, runner=_success_runner)

    def test_non_urn_string_rejected(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="Invalid URN format"):
            resolve_capability("not-a-urn", ledger_path=ledger_path, runner=_success_runner)

    def test_wrong_namespace_prefix_rejected(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="Invalid URN format"):
            resolve_capability("urn:other:solver:test", ledger_path=ledger_path, runner=_success_runner)

    def test_incomplete_urn_rejected(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="Invalid URN format"):
            resolve_capability("urn:coreason:", ledger_path=ledger_path, runner=_success_runner)

    def test_urn_with_spaces_rejected(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="Invalid URN format"):
            resolve_capability("urn:coreason:solver:test v1", ledger_path=ledger_path, runner=_success_runner)

    def test_urn_with_version_accepted(self, tmp_path: Path) -> None:
        """URNs with :v<version> suffix should pass format validation."""
        ledger_path = _write_test_ledger(tmp_path)
        # Will pass format check but fail on ledger lookup
        with pytest.raises(TopologicalSeveranceEvent, match="not found in OCI Ledger"):
            resolve_capability("urn:coreason:solver:test_v1:v2", ledger_path=ledger_path, runner=_success_runner)


class TestFailClosedAuthorization:
    """Tests for is_authorized_tenant_did fail-closed behavior (Sprint C: C2.2)."""

    def test_unset_env_denies(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("COREASON_AUTHORIZED_DIDS", raising=False)
        assert is_authorized_tenant_did("did:key:zABC123") is False

    def test_empty_string_denies(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_AUTHORIZED_DIDS", "")
        assert is_authorized_tenant_did("did:key:zABC123") is False

    def test_whitespace_only_denies(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_AUTHORIZED_DIDS", "  ,  ,  ")
        assert is_authorized_tenant_did("did:key:zABC123") is False

    def test_wildcard_allows_all(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_AUTHORIZED_DIDS", "*")
        assert is_authorized_tenant_did("did:key:zAnything") is True

    def test_specific_did_match(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_AUTHORIZED_DIDS", "did:key:zABC,did:key:zDEF")
        assert is_authorized_tenant_did("did:key:zABC") is True
        assert is_authorized_tenant_did("did:key:zDEF") is True
        assert is_authorized_tenant_did("did:key:zGHI") is False


class TestVaultTokenRequired:
    """Tests for VAULT_TOKEN required in legacy mode (Sprint C: C2.1)."""

    def test_vault_legacy_without_token_raises(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        monkeypatch.setenv("COREASON_VAULT_LEGACY", "true")
        monkeypatch.delenv("VAULT_TOKEN", raising=False)
        with pytest.raises(TopologicalSeveranceEvent, match="VAULT_TOKEN environment variable is required"):
            resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=ledger_path,
                runner=_success_runner,
            )

    def test_vault_legacy_with_token_proceeds(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        monkeypatch.setenv("COREASON_VAULT_LEGACY", "true")
        monkeypatch.setenv("VAULT_TOKEN", "real-token")
        monkeypatch.setenv("VAULT_ADDR", "http://127.0.0.1:9999")
        # Will fail on Vault connection, not on missing token
        receipt = resolve_capability(
            "urn:coreason:solver:test_v1",
            ledger_path=ledger_path,
            runner=_success_runner,
        )
        assert isinstance(receipt, VerifiedCapabilityReceipt)
