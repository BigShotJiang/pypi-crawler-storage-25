# Copyright (c) 2026 CoReason, Inc.

"""Tests for Keysigning Ceremony Session Manager (#107)."""

from __future__ import annotations

import pytest

from coreason_urn_authority.ceremony.session import (
    CeremonyManager,
    CeremonyStatus,
)


ALICE = "spiffe://coreason.internal/tenant/operator/alice"
BOB = "spiffe://coreason.internal/tenant/operator/bob"
CAROL = "spiffe://coreason.internal/tenant/operator/carol"


class TestCeremonyManager:
    """Tests for the CeremonyManager lifecycle."""

    def _make_manager(self) -> CeremonyManager:
        return CeremonyManager()

    def test_initiate_creates_pending_session(self) -> None:
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:inference-solver:01h3x",
            required_signers=[ALICE, BOB],
            threshold=2,
        )
        assert session.status == CeremonyStatus.PENDING
        assert session.signatures_collected == 0
        assert session.threshold == 2
        assert session.session_token.startswith("session_delegation_")

    def test_initiate_invalid_threshold_too_high(self) -> None:
        mgr = self._make_manager()
        with pytest.raises(ValueError, match="threshold"):
            mgr.initiate(
                trust_domain="coreason.internal",
                target_node_urn="urn:coreason:node:test:01",
                required_signers=[ALICE],
                threshold=5,
            )

    def test_initiate_invalid_threshold_zero(self) -> None:
        mgr = self._make_manager()
        with pytest.raises(ValueError, match="threshold"):
            mgr.initiate(
                trust_domain="coreason.internal",
                target_node_urn="urn:coreason:node:test:01",
                required_signers=[ALICE],
                threshold=0,
            )

    def test_initiate_empty_signers(self) -> None:
        mgr = self._make_manager()
        with pytest.raises(ValueError, match="requiredSigners"):
            mgr.initiate(
                trust_domain="coreason.internal",
                target_node_urn="urn:coreason:node:test:01",
                required_signers=[],
                threshold=1,
            )

    def test_sign_increments_count(self) -> None:
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:test:01",
            required_signers=[ALICE, BOB],
            threshold=2,
        )
        updated = mgr.submit_signature(
            session_token=session.session_token,
            signer_spiffe_id=ALICE,
            signature_share="3045022100e4d0f5aabbccdd",
        )
        assert updated.signatures_collected == 1
        assert updated.status == CeremonyStatus.PENDING

    def test_sign_threshold_reached_establishes(self) -> None:
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:test:01",
            required_signers=[ALICE, BOB],
            threshold=2,
        )
        mgr.submit_signature(session.session_token, ALICE, "3045022100aabb")
        updated = mgr.submit_signature(session.session_token, BOB, "3045022100ccdd")
        assert updated.status == CeremonyStatus.ESTABLISHED
        assert updated.attestation_hash is not None
        assert updated.attestation_hash.startswith("0x")

    def test_sign_invalid_signer_rejected(self) -> None:
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:test:01",
            required_signers=[ALICE, BOB],
            threshold=2,
        )
        with pytest.raises(ValueError, match="not in the required"):
            mgr.submit_signature(session.session_token, CAROL, "3045022100aabb")

    def test_sign_duplicate_signer_rejected(self) -> None:
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:test:01",
            required_signers=[ALICE, BOB],
            threshold=2,
        )
        mgr.submit_signature(session.session_token, ALICE, "3045022100aabb")
        with pytest.raises(ValueError, match="already signed"):
            mgr.submit_signature(session.session_token, ALICE, "3045022100ccdd")

    def test_sign_bad_signature_faults(self) -> None:
        """Too-short signature share should cause FAULT."""
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:test:01",
            required_signers=[ALICE],
            threshold=1,
        )
        updated = mgr.submit_signature(session.session_token, ALICE, "bad")
        assert updated.status == CeremonyStatus.FAULT

    def test_sign_unknown_session_raises(self) -> None:
        mgr = self._make_manager()
        with pytest.raises(KeyError):
            mgr.submit_signature("nonexistent_token", ALICE, "sig")

    def test_retract_cancels_session(self) -> None:
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:test:01",
            required_signers=[ALICE],
            threshold=1,
        )
        retracted = mgr.retract(session.session_token)
        assert retracted.status == CeremonyStatus.RETRACTED

    def test_retract_unknown_session_raises(self) -> None:
        mgr = self._make_manager()
        with pytest.raises(KeyError):
            mgr.retract("nonexistent_token")

    def test_to_dict_serialization(self) -> None:
        mgr = self._make_manager()
        session = mgr.initiate(
            trust_domain="coreason.internal",
            target_node_urn="urn:coreason:node:test:01",
            required_signers=[ALICE, BOB],
            threshold=2,
        )
        d = session.to_dict()
        assert d["sessionToken"] == session.session_token
        assert d["status"] == "PENDING"
        assert d["signaturesCollected"] == 0
        assert d["signaturesThreshold"] == 2
        assert "timestamp" in d
