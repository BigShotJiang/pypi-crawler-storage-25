"""Unit tests for the raipii Python SDK."""
import pytest
import responses as rsps_lib

import raipii
from raipii.exceptions import (
    AuthenticationError,
    NotFoundError,
    QuotaExceededError,
    ValidationError,
)

BASE = "https://api.raipii.com"
API_KEY = "ps_live_testkey000000000000000000000000000000000000000000"


@pytest.fixture
def client():
    return raipii.Raipii(api_key=API_KEY)


# ---------------------------------------------------------------------------
# sanitize
# ---------------------------------------------------------------------------

@rsps_lib.activate
def test_sanitize_token_mode(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/sanitize",
        json={
            "session_id": "ps_sess_abc123",
            "conversation_id": None,
            "sanitized_text": "Call [PERSON_1] at [EMAIL_1]",
            "entities_found": [
                {
                    "type": "PERSON",
                    "original": "John Smith",
                    "replacement": "[PERSON_1]",
                    "position": [5, 15],
                    "confidence": 0.99,
                },
                {
                    "type": "EMAIL",
                    "original": "john@acme.com",
                    "replacement": "[EMAIL_1]",
                    "position": [19, 32],
                    "confidence": 1.0,
                },
            ],
            "char_count": 32,
            "usage": {"chars_billed": 32},
        },
        status=200,
    )

    result = client.sanitize("Call John Smith at john@acme.com")

    assert result.session_id == "ps_sess_abc123"
    assert result.sanitized_text == "Call [PERSON_1] at [EMAIL_1]"
    assert len(result.entities_found) == 2
    assert result.entities_found[0].type == "PERSON"
    assert result.entities_found[0].original == "John Smith"
    assert result.usage.chars_billed == 32

    sent = rsps_lib.calls[0].request
    import json
    body = json.loads(sent.body)
    assert body["mode"] == "token"
    assert body["text"] == "Call John Smith at john@acme.com"


@rsps_lib.activate
def test_sanitize_fake_substitute_mode(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/sanitize",
        json={
            "session_id": "ps_sess_fake1",
            "conversation_id": None,
            "sanitized_text": "Call Michael Torres at m.torres@email.net",
            "entities_found": [],
            "char_count": 40,
            "usage": {"chars_billed": 40},
        },
    )

    result = client.sanitize("Call John Smith at john@acme.com", mode="fake_substitute")
    assert result.sanitized_text == "Call Michael Torres at m.torres@email.net"


@rsps_lib.activate
def test_sanitize_with_conversation_id(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/sanitize",
        json={
            "session_id": "ps_sess_conv1",
            "conversation_id": "ps_conv_xyz",
            "sanitized_text": "[PERSON_1] again",
            "entities_found": [],
            "char_count": 15,
            "usage": {"chars_billed": 15},
        },
    )

    result = client.sanitize("John again", conversation_id="ps_conv_xyz")
    assert result.conversation_id == "ps_conv_xyz"

    import json
    body = json.loads(rsps_lib.calls[0].request.body)
    assert body["conversation_id"] == "ps_conv_xyz"


@rsps_lib.activate
def test_sanitize_auth_error(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/sanitize",
        json={"error": "Invalid or missing API key"},
        status=401,
    )
    with pytest.raises(AuthenticationError):
        client.sanitize("some text")


@rsps_lib.activate
def test_sanitize_quota_exceeded(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/sanitize",
        json={"error": "Monthly character limit exceeded"},
        status=402,
    )
    with pytest.raises(QuotaExceededError):
        client.sanitize("some text")


# ---------------------------------------------------------------------------
# restore
# ---------------------------------------------------------------------------

@rsps_lib.activate
def test_restore(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/restore",
        json={
            "restored_text": "Call John Smith for help.",
            "substitutions_reversed": 1,
            "usage": {"chars_billed": 30},
        },
    )

    result = client.restore("Call [PERSON_1] for help.", "ps_sess_abc123")

    assert result.restored_text == "Call John Smith for help."
    assert result.substitutions_reversed == 1

    import json
    body = json.loads(rsps_lib.calls[0].request.body)
    assert body["session_id"] == "ps_sess_abc123"
    assert body["text"] == "Call [PERSON_1] for help."


@rsps_lib.activate
def test_restore_session_not_found(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/restore",
        json={"error": "Session not found or expired"},
        status=404,
    )
    with pytest.raises(NotFoundError):
        client.restore("text", "ps_sess_expired")


# ---------------------------------------------------------------------------
# detect
# ---------------------------------------------------------------------------

@rsps_lib.activate
def test_detect_pii_found(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/detect",
        json={
            "entities_found": [
                {
                    "type": "US_SSN",
                    "value": "392-45-7810",
                    "confidence": 1.0,
                    "position": [10, 21],
                    "detection_method": "regex",
                }
            ],
            "pii_detected": True,
            "risk_level": "HIGH",
            "usage": {"chars_billed": 21},
        },
    )

    result = client.detect("My SSN is 392-45-7810")

    assert result.pii_detected is True
    assert result.risk_level == "HIGH"
    assert len(result.entities_found) == 1
    assert result.entities_found[0].type == "US_SSN"
    assert result.entities_found[0].detection_method == "regex"


@rsps_lib.activate
def test_detect_no_pii(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/detect",
        json={
            "entities_found": [],
            "pii_detected": False,
            "risk_level": "NONE",
            "usage": {"chars_billed": 13},
        },
    )

    result = client.detect("Hello, world!")
    assert result.pii_detected is False
    assert result.risk_level == "NONE"


# ---------------------------------------------------------------------------
# conversations
# ---------------------------------------------------------------------------

@rsps_lib.activate
def test_create_conversation(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/conversations",
        json={
            "conversation_id": "ps_conv_newone",
            "expires_at": "2026-04-10T12:00:00",
        },
        status=201,
    )

    conv = client.conversations.create(ttl=3600)

    assert conv.conversation_id == "ps_conv_newone"
    assert conv.expires_at == "2026-04-10T12:00:00"

    import json
    body = json.loads(rsps_lib.calls[0].request.body)
    assert body["ttl"] == 3600


# ---------------------------------------------------------------------------
# client construction
# ---------------------------------------------------------------------------

def test_missing_api_key(monkeypatch):
    monkeypatch.delenv("RAIPII_API_KEY", raising=False)
    with pytest.raises(ValueError, match="No API key provided"):
        raipii.Raipii()


def test_api_key_from_env(monkeypatch):
    monkeypatch.setenv("RAIPII_API_KEY", API_KEY)
    c = raipii.Raipii()
    assert c._api_key == API_KEY


# ---------------------------------------------------------------------------
# retry logic
# ---------------------------------------------------------------------------

@rsps_lib.activate
def test_retry_on_503_then_success(monkeypatch):
    # Fail twice with 503, succeed on third attempt
    monkeypatch.setattr("time.sleep", lambda _: None)  # no actual sleeping in tests
    for _ in range(2):
        rsps_lib.add(
            rsps_lib.POST,
            f"{BASE}/v1/sanitize",
            json={"error": "Detection service unavailable"},
            status=503,
        )
    rsps_lib.add(
        rsps_lib.POST,
        f"{BASE}/v1/sanitize",
        json={
            "session_id": "ps_sess_retry",
            "conversation_id": None,
            "sanitized_text": "ok",
            "entities_found": [],
            "char_count": 2,
            "usage": {"chars_billed": 2},
        },
        status=200,
    )

    client = raipii.Raipii(api_key=API_KEY, base_url=BASE)
    result = client.sanitize("ok")
    assert result.session_id == "ps_sess_retry"
    assert len(rsps_lib.calls) == 3


@rsps_lib.activate
def test_retry_exhausted_raises(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda _: None)
    for _ in range(4):  # more than max_retries=3
        rsps_lib.add(
            rsps_lib.POST,
            f"{BASE}/v1/sanitize",
            json={"error": "Detection service unavailable"},
            status=503,
        )

    client = raipii.Raipii(api_key=API_KEY, base_url=BASE, max_retries=3)
    with pytest.raises(raipii.ServiceUnavailableError):
        client.sanitize("text")
    # Should have tried max_retries+1 = 4 times
    assert len(rsps_lib.calls) == 4
