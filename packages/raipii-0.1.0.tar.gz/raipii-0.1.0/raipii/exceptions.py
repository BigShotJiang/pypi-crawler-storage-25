class RaipiiError(Exception):
    """Base exception for all raipii errors."""
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response or {}


class AuthenticationError(RaipiiError):
    """Invalid or missing API key (401)."""


class QuotaExceededError(RaipiiError):
    """Monthly character limit reached (402)."""


class NotFoundError(RaipiiError):
    """Session or resource not found (404)."""


class ValidationError(RaipiiError):
    """Bad request — invalid parameters (400)."""


class ServiceUnavailableError(RaipiiError):
    """Detection backend temporarily unavailable (503)."""


class RateLimitError(RaipiiError):
    """Too many requests (429)."""
