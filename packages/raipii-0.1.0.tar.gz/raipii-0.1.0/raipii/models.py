from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class EntityFound:
    type: str
    original: str
    replacement: str
    position: Tuple[int, int]
    confidence: float

    @classmethod
    def _from_dict(cls, d: dict) -> "EntityFound":
        return cls(
            type=d["type"],
            original=d.get("original", d.get("value", "")),
            replacement=d.get("replacement", ""),
            position=tuple(d["position"]),
            confidence=d.get("confidence", 1.0),
        )


@dataclass
class DetectedEntity:
    type: str
    value: str
    confidence: float
    position: Tuple[int, int]
    detection_method: str

    @classmethod
    def _from_dict(cls, d: dict) -> "DetectedEntity":
        return cls(
            type=d["type"],
            value=d["value"],
            confidence=d.get("confidence", 1.0),
            position=tuple(d["position"]),
            detection_method=d.get("detection_method", "regex"),
        )


@dataclass
class Usage:
    chars_billed: int

    @classmethod
    def _from_dict(cls, d: dict) -> "Usage":
        return cls(chars_billed=d.get("chars_billed", 0))


@dataclass
class SanitizeResult:
    session_id: str
    sanitized_text: str
    entities_found: List[EntityFound]
    char_count: int
    usage: Usage
    conversation_id: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "SanitizeResult":
        return cls(
            session_id=d["session_id"],
            sanitized_text=d["sanitized_text"],
            entities_found=[EntityFound._from_dict(e) for e in d.get("entities_found", [])],
            char_count=d.get("char_count", 0),
            usage=Usage._from_dict(d.get("usage", {})),
            conversation_id=d.get("conversation_id"),
        )


@dataclass
class RestoreResult:
    restored_text: str
    substitutions_reversed: int
    usage: Usage

    @classmethod
    def _from_dict(cls, d: dict) -> "RestoreResult":
        return cls(
            restored_text=d["restored_text"],
            substitutions_reversed=d.get("substitutions_reversed", 0),
            usage=Usage._from_dict(d.get("usage", {})),
        )


@dataclass
class DetectResult:
    entities_found: List[DetectedEntity]
    pii_detected: bool
    risk_level: str
    usage: Usage

    @classmethod
    def _from_dict(cls, d: dict) -> "DetectResult":
        return cls(
            entities_found=[DetectedEntity._from_dict(e) for e in d.get("entities_found", [])],
            pii_detected=d.get("pii_detected", False),
            risk_level=d.get("risk_level", "NONE"),
            usage=Usage._from_dict(d.get("usage", {})),
        )


@dataclass
class Conversation:
    conversation_id: str
    expires_at: str

    @classmethod
    def _from_dict(cls, d: dict) -> "Conversation":
        return cls(
            conversation_id=d["conversation_id"],
            expires_at=d.get("expires_at", ""),
        )
