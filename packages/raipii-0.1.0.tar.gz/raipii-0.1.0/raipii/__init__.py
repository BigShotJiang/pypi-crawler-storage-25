"""raipii — PII detection and sanitization SDK."""

from .client import Raipii
from .exceptions import (
    AuthenticationError,
    NotFoundError,
    QuotaExceededError,
    RaipiiError,
    RateLimitError,
    ServiceUnavailableError,
    ValidationError,
)
from .models import (
    Conversation,
    DetectResult,
    DetectedEntity,
    EntityFound,
    RestoreResult,
    SanitizeResult,
    Usage,
)

__version__ = "0.1.0"
__all__ = [
    "Raipii",
    # exceptions
    "RaipiiError",
    "AuthenticationError",
    "QuotaExceededError",
    "NotFoundError",
    "ValidationError",
    "ServiceUnavailableError",
    "RateLimitError",
    # models
    "SanitizeResult",
    "RestoreResult",
    "DetectResult",
    "DetectedEntity",
    "EntityFound",
    "Conversation",
    "Usage",
]
