from __future__ import annotations

import os
import time
from typing import Dict, List, Optional

import requests

from .exceptions import (
    AuthenticationError,
    NotFoundError,
    QuotaExceededError,
    RaipiiError,
    RateLimitError,
    ServiceUnavailableError,
    ValidationError,
)
from .models import Conversation, DetectResult, RestoreResult, SanitizeResult

DEFAULT_BASE_URL = "https://api.raipii.com"
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 3
_RETRYABLE_STATUSES = {429, 503}


def _raise_for_status(response: requests.Response) -> dict:
    if response.ok:
        return response.json()

    try:
        body = response.json()
        message = body.get("error", response.text)
    except Exception:
        body = {}
        message = response.text

    status = response.status_code
    if status == 400:
        raise ValidationError(message, status_code=status, response=body)
    if status == 401:
        raise AuthenticationError(message, status_code=status, response=body)
    if status == 402:
        raise QuotaExceededError(message, status_code=status, response=body)
    if status == 404:
        raise NotFoundError(message, status_code=status, response=body)
    if status == 429:
        raise RateLimitError(message, status_code=status, response=body)
    if status == 503:
        raise ServiceUnavailableError(message, status_code=status, response=body)
    raise RaipiiError(message, status_code=status, response=body)


class _ConversationsResource:
    def __init__(self, client: "Raipii"):
        self._client = client

    def create(self, ttl: int = 86400, metadata: Optional[Dict] = None) -> Conversation:
        """
        Start a new multi-turn conversation session.

        Args:
            ttl: Session lifetime in seconds (default 86400 = 24 hrs).
            metadata: Optional key-value pairs attached to the conversation.

        Returns:
            Conversation with conversation_id and expires_at.
        """
        body = {"ttl": ttl}
        if metadata:
            body["metadata"] = metadata
        data = self._client._post("/v1/conversations", body)
        return Conversation._from_dict(data)


class Raipii:
    """
    raipii Python SDK client.

    Usage::

        import raipii

        ps = raipii.Raipii(api_key="ps_live_...")

        result = ps.sanitize("Call John at john@acme.com", mode="fake_substitute")
        response = your_llm(result.sanitized_text)
        original = ps.restore(response, result.session_id)
        print(original.restored_text)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        """
        Args:
            api_key: Your raipii API key (ps_live_...). Falls back to the
                     RAIPII_API_KEY environment variable if not provided.
            base_url: Override the API base URL (useful for testing).
            timeout: HTTP request timeout in seconds (default 30).
            max_retries: Maximum retries on 429/503 with exponential backoff (default 3).
        """
        key = api_key or os.environ.get("RAIPII_API_KEY")
        if not key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the RAIPII_API_KEY "
                "environment variable. Get a free key at https://raipii.com"
            )
        self._api_key = key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._session = requests.Session()
        self._session.headers.update({"Authorization": f"Bearer {key}"})

        self.conversations = _ConversationsResource(self)

    # ------------------------------------------------------------------
    # Core API methods
    # ------------------------------------------------------------------

    def sanitize(
        self,
        text: str,
        *,
        mode: str = "token",
        entities: Optional[List[str]] = None,
        session_ttl: int = 3600,
        conversation_id: Optional[str] = None,
        confidence_threshold: Optional[float] = None,
    ) -> SanitizeResult:
        """
        Detect and sanitize PII in *text*.

        Args:
            text: The prompt or string to sanitize.
            mode: One of ``"token"`` (default), ``"fake_substitute"``, or ``"redact"``.
                  - ``token`` — replaces PII with labelled tokens like ``[EMAIL_1]``
                  - ``fake_substitute`` — replaces PII with realistic Faker-generated values
                  - ``redact`` — replaces PII with ``[REDACTED]``
            entities: Optional list of entity types to detect. Detects all by default.
            session_ttl: Session expiry in seconds (default 3600). Used by :meth:`restore`.
            conversation_id: ID from :meth:`conversations.create` for multi-turn sessions.
            confidence_threshold: Override the account-level Comprehend confidence threshold.

        Returns:
            :class:`SanitizeResult` with ``sanitized_text``, ``session_id``,
            ``entities_found``, and usage info.

        Example::

            result = ps.sanitize(
                "Hi, I'm John Smith — john@acme.com",
                mode="fake_substitute",
            )
            print(result.sanitized_text)   # "Hi, I'm Michael Torres — m.torres@email.net"
            print(result.session_id)       # "ps_sess_..."
        """
        body: dict = {"text": text, "mode": mode, "session_ttl": session_ttl}
        if entities is not None:
            body["entities"] = entities
        if conversation_id is not None:
            body["conversation_id"] = conversation_id
        if confidence_threshold is not None:
            body["confidence_threshold"] = confidence_threshold

        data = self._post("/v1/sanitize", body)
        return SanitizeResult._from_dict(data)

    def restore(self, text: str, session_id: str) -> RestoreResult:
        """
        Restore original PII values in an LLM response using a prior session.

        Args:
            text: The LLM response containing tokens or fake values.
            session_id: The ``session_id`` from a previous :meth:`sanitize` call.

        Returns:
            :class:`RestoreResult` with ``restored_text`` and ``substitutions_reversed``.

        Example::

            response = your_llm(result.sanitized_text)
            original = ps.restore(response, result.session_id)
            print(original.restored_text)
        """
        data = self._post("/v1/restore", {"text": text, "session_id": session_id})
        return RestoreResult._from_dict(data)

    def detect(
        self,
        text: str,
        *,
        entities: Optional[List[str]] = None,
        confidence_threshold: Optional[float] = None,
    ) -> DetectResult:
        """
        Detect PII in *text* without sanitizing.

        Args:
            text: Text to scan for PII.
            entities: Optional list of entity types to detect.
            confidence_threshold: Override the account-level confidence threshold.

        Returns:
            :class:`DetectResult` with ``entities_found``, ``pii_detected``,
            and ``risk_level`` (``"NONE"``, ``"LOW"``, ``"MEDIUM"``, ``"HIGH"``).

        Example::

            result = ps.detect("My SSN is 392-45-7810")
            if result.pii_detected:
                print(f"Risk: {result.risk_level}")
                for entity in result.entities_found:
                    print(f"  {entity.type}: {entity.value}")
        """
        body: dict = {"text": text}
        if entities is not None:
            body["entities"] = entities
        if confidence_threshold is not None:
            body["confidence_threshold"] = confidence_threshold

        data = self._post("/v1/detect", body)
        return DetectResult._from_dict(data)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post(self, path: str, body: dict) -> dict:
        url = f"{self._base_url}{path}"
        last_exc: Exception = RaipiiError("No attempts made")
        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                wait = 2 ** (attempt - 1)  # 1s, 2s, 4s
                time.sleep(wait)
            response = self._session.post(url, json=body, timeout=self._timeout)
            if response.status_code not in _RETRYABLE_STATUSES:
                return _raise_for_status(response)
            try:
                last_exc = _raise_for_status(response)  # type: ignore[assignment]
            except RaipiiError as exc:
                last_exc = exc
        raise last_exc
