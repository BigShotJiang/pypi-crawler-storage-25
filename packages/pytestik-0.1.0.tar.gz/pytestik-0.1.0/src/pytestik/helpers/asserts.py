import pytest
import numpy as np
from collections.abc import Sequence


def assert_equal(a, b, *, abs: float = 1e-12) -> None:
    # float-like
    try:
        af = float(a)
        bf = float(b)
        assert af == pytest.approx(bf, abs=abs)
        return
    except Exception:
        pass

    # numpy arrays
    if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
        assert np.asarray(a) == pytest.approx(np.asarray(b), abs=abs)
        return

    # sequences (list/tuple)
    if isinstance(a, Sequence) and isinstance(b, Sequence) and not isinstance(a, (str, bytes)):
        assert len(a) == len(b)
        for x, y in zip(a, b):
            assert_equal(x, y, abs=abs)
        return

    # fallback
    assert a == b

def assert_equals(*pairs, abs: float = 1e-12) -> None:
    for a, b in pairs:
        assert_equal(a, b, abs=abs)