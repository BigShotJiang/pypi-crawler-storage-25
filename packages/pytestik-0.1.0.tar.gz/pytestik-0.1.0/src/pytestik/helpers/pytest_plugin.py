import h5py
import pytest

@pytest.fixture
def h5mem():
    f = h5py.File("mem.h5", "w", driver="core", backing_store=False)
    try:
        yield f
    finally:
        f.close()