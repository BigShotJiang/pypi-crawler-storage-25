def get_first(enum_cls):
    return next(iter(enum_cls))
