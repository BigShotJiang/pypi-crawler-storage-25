# !/usr/bin/python
# coding=utf-8
import threading
import logging as internal_logging
import re
import unicodedata
from typing import Union, List, Optional, Any, Callable
from pythontk.core_utils.class_property import ClassProperty


class StripHtmlFormatter(internal_logging.Formatter):
    """Formatter that strips HTML tags from the message."""

    def format(self, record):
        # Save original message
        original_msg = record.msg
        if (
            isinstance(original_msg, str)
            and "<" in original_msg
            and ">" in original_msg
        ):
            # Strip tags for this formatting operation
            record.msg = re.sub(r"<[^>]+>", "", original_msg)

        # Format with stripped message
        formatted = super().format(record)

        # Restore original message (in case other handlers need the HTML)
        record.msg = original_msg
        return formatted


class LevelAwareFormatter(internal_logging.Formatter):
    """Formatter that dynamically selects format per-record based on log level.

    Unlike a static Formatter, this ensures RESULT/SUCCESS/NOTICE messages
    use their designated formats (without logger name) even when the handler
    accepts multiple levels.
    """

    def __init__(self, logger=None, strip_html=False):
        super().__init__()
        self._logger_ref = logger
        self._strip_html = strip_html

    def format(self, record):
        logger = self._logger_ref
        base_fmt = LoggerExt._get_base_format(record.levelno, logger=logger)
        prefix = getattr(logger, "_log_prefix", "") if logger else ""
        suffix = getattr(logger, "_log_suffix", "") if logger else ""
        fmt = base_fmt.replace("%(message)s", f"{prefix}%(message)s{suffix}")

        ts = getattr(logger, "_log_timestamp", None) if logger else None
        if ts:
            fmt = f"[%(asctime)s] {fmt}"
            self.datefmt = ts
        else:
            self.datefmt = None

        self._style._fmt = fmt

        if self._strip_html:
            original = record.msg
            if isinstance(original, str) and "<" in original and ">" in original:
                record.msg = re.sub(r"<[^>]+>", "", original)
            result = super().format(record)
            record.msg = original
            return result

        return super().format(record)


class LoggerExt:
    _text_handler = None  # Can be instance or class

    # Define custom log levels
    PROGRESS = 15
    SUCCESS = 25
    RESULT = 35
    NOTICE = 45

    DEFAULT_BOX_WIDTH = 120

    # Default log colors (Hex)
    LOG_COLORS = {
        "DEBUG": "#AAAAAA",  # Neutral gray
        "INFO": "#FFFFFF",  # Pure white
        "PROGRESS": "#00CCFF",  # Cyan
        "WARNING": "#FFF5B7",  # Pastel yellow
        "ERROR": "#FFCCCC",  # Pastel pink
        "CRITICAL": "#CC3333",  # Strong red
        "SUCCESS": "#CCFFCC",  # Pastel green
        "RESULT": "#CCFFFF",  # Pastel teal
        "NOTICE": "#E5CCFF",  # Pastel lavender
    }

    # HTML Presets for formatting log messages
    HTML_PRESETS = {
        "default": '<span style="color:{color}">{message}</span>',
        "bold": '<span style="color:{color}; font-weight:bold">{message}</span>',
        "italic": '<span style="color:{color}; font-style:italic">{message}</span>',
        "header": '<br><h3 style="color:{color}">{message}</h3>',
        "highlight": '<br><hl style="color:{color}">{message}</hl>',
    }

    # Default presets for log levels
    LEVEL_PRESETS = {
        "DEBUG": "italic",
        "CRITICAL": "bold",
    }

    # Base log formats
    BASE_FORMATS = {
        "default": "[%(levelname)s] %(name)s: %(message)s",
        "debug": "[%(levelname)s] %(name)s: %(message)s",
        "success": "[%(levelname)s] %(message)s",
        "result": "[%(levelname)s] %(message)s",
        "notice": "[%(levelname)s] %(message)s",
    }

    @classmethod
    def patch(cls, logger: internal_logging.Logger) -> None:
        """Patch the logger with additional methods and setup."""
        if getattr(logger, "_logger_ext_patched", False):
            return
        logger._logger_ext_patched = True

        # Preserve the original setLevel method
        if not hasattr(logger, "internal_setLevel"):
            logger.internal_setLevel = logger.setLevel

        # Register custom levels
        cls._register_custom_levels()

        # Initialize error spam prevention
        logger._error_cache = {}
        logger._spam_prevention_enabled = True
        logger._cache_duration = 300  # 5 minutes default

        # Patch logger methods
        cls._patch_logger_methods(logger)

        # Initialize log formats and formatter selector
        logger._formatter_selector = cls._select_formatter.__get__(logger)
        logger.set_log_prefix = cls._set_log_prefix.__get__(logger)
        logger.set_log_suffix = cls._set_log_suffix.__get__(logger)
        logger._log_prefix = ""
        logger._log_suffix = ""
        logger._log_timestamp = None  # "%H:%M:%S" example of time only

        # Add property for log_timestamp that updates formatters
        def get_log_timestamp(self):
            return getattr(self, "_log_timestamp", None)

        def set_log_timestamp(self, value):
            self._log_timestamp = value
            LoggerExt._update_handler_formatters(self)

        logger.__class__.log_timestamp = property(get_log_timestamp, set_log_timestamp)

        # Add default handlers if none exist
        if not logger.handlers:
            cls._add_handler(logger, handler_type="stream")

    @staticmethod
    def _register_custom_levels() -> None:
        """Register custom log levels."""
        levels = {
            LoggerExt.PROGRESS: "PROGRESS",
            LoggerExt.SUCCESS: "SUCCESS",
            LoggerExt.RESULT: "RESULT",
            LoggerExt.NOTICE: "NOTICE",
        }
        for level, name in levels.items():
            internal_logging.addLevelName(level, name)

    @staticmethod
    def _patch_logger_methods(logger: internal_logging.Logger) -> None:
        """Patch logger with additional methods."""
        # Handle methods that don't need self (take no args or non-self first arg)
        direct_methods = {
            "set_text_handler": LoggerExt._set_text_handler,
            "get_text_handler": LoggerExt._get_text_handler,
            "log_link": LoggerExt._log_link,
        }
        for name, method in direct_methods.items():
            setattr(logger, name, method)

        # Handle methods that need self as first argument
        def make_method_wrapper(method):
            def wrapper(*args, **kwargs):
                return method(logger, *args, **kwargs)

            return wrapper

        wrapped_methods = {
            "setLevel": LoggerExt._set_level,
            "add_file_handler": LoggerExt._add_file_handler,
            "add_stream_handler": LoggerExt._add_stream_handler,
            "add_text_widget_handler": LoggerExt._add_text_widget_handler,
            "setup_logging_redirect": LoggerExt._setup_logging_redirect,
            "success": LoggerExt._success,
            "result": LoggerExt._result,
            "notice": LoggerExt._notice,
            "progress": LoggerExt._progress,
            "log_box": LoggerExt._log_box,
            "log_divider": LoggerExt._log_divider,
            "log_raw": LoggerExt._log_raw,
            "hide_logger_name": LoggerExt._hide_logger_name,
            "error_once": LoggerExt._error_once,
            "warning_once": LoggerExt._warning_once,
            "set_spam_prevention": LoggerExt._set_spam_prevention,
            "clear_error_cache": LoggerExt._clear_error_cache,
            "info": LoggerExt._info,
            "debug": LoggerExt._debug,
            "warning": LoggerExt._warning,
            "error": LoggerExt._error,
            "critical": LoggerExt._critical,
        }

        for name, method in wrapped_methods.items():
            setattr(logger, name, make_method_wrapper(method))

    @staticmethod
    def _log_custom(logger, level_int, msg, *args, **kwargs):
        """Log with optional custom formatting (preset/color)."""
        preset = kwargs.pop("preset", None)
        color_level = kwargs.pop("color", None)

        # Heuristic for positional args: (color, preset) or (preset)
        if isinstance(msg, str) and not preset and not color_level:
            if len(args) == 2 and isinstance(args[0], str) and isinstance(args[1], str):
                # Check if args[1] is a known preset
                if args[1] in LoggerExt.HTML_PRESETS:
                    color_level = args[0]
                    preset = args[1]
                    args = ()
            elif len(args) == 1 and isinstance(args[0], str):
                if args[0] in LoggerExt.HTML_PRESETS:
                    preset = args[0]
                    args = ()
                elif args[0].upper() in LoggerExt.LOG_COLORS:
                    color_level = args[0]
                    args = ()

        if preset or color_level:
            if not color_level:
                color_level = internal_logging.getLevelName(level_int)

            formatted_msg = LoggerExt.format_message_as_html(msg, color_level, preset)
            internal_logging.Logger.log(
                logger, level_int, formatted_msg, *args, **kwargs
            )
        else:
            internal_logging.Logger.log(logger, level_int, msg, *args, **kwargs)

    @staticmethod
    def _info(logger, msg, *args, **kwargs):
        LoggerExt._log_custom(logger, internal_logging.INFO, msg, *args, **kwargs)

    @staticmethod
    def _debug(logger, msg, *args, **kwargs):
        LoggerExt._log_custom(logger, internal_logging.DEBUG, msg, *args, **kwargs)

    @staticmethod
    def _warning(logger, msg, *args, **kwargs):
        LoggerExt._log_custom(logger, internal_logging.WARNING, msg, *args, **kwargs)

    @staticmethod
    def _error(logger, msg, *args, **kwargs):
        LoggerExt._log_custom(logger, internal_logging.ERROR, msg, *args, **kwargs)

    @staticmethod
    def _critical(logger, msg, *args, **kwargs):
        LoggerExt._log_custom(logger, internal_logging.CRITICAL, msg, *args, **kwargs)

    @staticmethod
    def _select_formatter(
        self, level: int, strip_html: bool = False
    ) -> internal_logging.Formatter:
        """Select formatter based on the log level."""
        prefix = getattr(self, "_log_prefix", "")
        suffix = getattr(self, "_log_suffix", "")
        base_format = LoggerExt._get_base_format(
            level, logger=self
        )  # Pass self as logger here
        format_string = base_format.replace(
            "%(message)s", f"{prefix}%(message)s{suffix}"
        )

        formatter_cls = StripHtmlFormatter if strip_html else internal_logging.Formatter

        log_timestamp = getattr(self, "_log_timestamp", None)
        if log_timestamp:
            format_string = "[%(asctime)s] " + format_string
            formatter = formatter_cls(format_string, datefmt=log_timestamp)
        else:
            formatter = formatter_cls(format_string)
        return formatter

    @staticmethod
    def _get_base_format(level: int, logger=None) -> str:
        """Return the base format string based on the log level."""
        # Get the original format based on level
        if level == LoggerExt.SUCCESS:
            fmt = LoggerExt.BASE_FORMATS["success"]
        elif level == LoggerExt.RESULT:
            fmt = LoggerExt.BASE_FORMATS["result"]
        elif level == LoggerExt.NOTICE:
            fmt = LoggerExt.BASE_FORMATS["notice"]
        elif level <= internal_logging.DEBUG:
            fmt = LoggerExt.BASE_FORMATS["debug"]
        else:
            fmt = LoggerExt.BASE_FORMATS["default"]

        # If we have a logger instance and it has _hide_logger_name set to False,
        # strip the name from the format
        if logger and hasattr(logger, "_hide_logger_name") and logger._hide_logger_name:
            fmt = fmt.replace("%(name)s: ", "")

        return fmt

    @staticmethod
    def _add_handler(
        logger: internal_logging.Logger, handler_type: str, **kwargs
    ) -> None:
        """Add a handler to the logger, skipping if an equivalent one exists."""
        # Deduplicate: check for existing handler of same type targeting the same widget
        target_widget = kwargs.get("widget")
        for existing in logger.handlers:
            if handler_type == "text_widget" and target_widget is not None:
                if getattr(existing, "widget", None) is target_widget:
                    return  # already attached
            elif handler_type == "file":
                import os

                target_file = os.path.abspath(kwargs.get("filename", "logfile.log"))
                if (
                    isinstance(existing, internal_logging.FileHandler)
                    and getattr(existing, "baseFilename", None) == target_file
                ):
                    return

        handler = None
        if handler_type == "stream":
            handler = internal_logging.StreamHandler()
        elif handler_type == "file":
            handler = internal_logging.FileHandler(
                kwargs.get("filename", "logfile.log")
            )
        elif handler_type == "text_widget":
            handler_cls = LoggerExt._get_text_handler()
            # Check if the handler accepts monospace argument
            import inspect

            sig = inspect.signature(handler_cls)
            handler_kwargs = {"widget": kwargs.get("widget")}
            if "monospace" in sig.parameters:
                handler_kwargs["monospace"] = kwargs.get("monospace", True)
            if "use_html" in sig.parameters:
                handler_kwargs["use_html"] = kwargs.get("use_html", True)

            handler = handler_cls(**handler_kwargs)

        if handler:
            level = kwargs.get("level", internal_logging.WARNING)
            handler.setLevel(level)

            # Use level-aware formatter with HTML stripping for file/stream
            strip_html = handler_type in ["file", "stream"]
            handler.setFormatter(
                LevelAwareFormatter(logger=logger, strip_html=strip_html)
            )

            logger.addHandler(handler)

    @staticmethod
    def _add_file_handler(
        self, filename: str = "logfile.log", level: int = internal_logging.WARNING
    ) -> None:
        """Add a file handler to the logger."""
        LoggerExt._add_handler(
            self, handler_type="file", filename=filename, level=level
        )

    @staticmethod
    def _add_stream_handler(self, level: int = internal_logging.WARNING) -> None:
        """Add a stream handler to the logger."""
        LoggerExt._add_handler(self, handler_type="stream", level=level)

    @staticmethod
    def _add_text_widget_handler(
        self,
        text_widget: object,
        level: int = internal_logging.WARNING,
        monospace: bool = True,
    ) -> None:
        """Add a text widget handler to the logger."""
        LoggerExt._add_handler(
            self,
            handler_type="text_widget",
            widget=text_widget,
            level=level,
            monospace=monospace,
        )

    @staticmethod
    def _update_handler_formatters(logger: internal_logging.Logger) -> None:
        """Update all handler formatters with level-aware formatting."""
        for handler in logger.handlers:
            is_file_or_stream = isinstance(
                handler,
                (internal_logging.FileHandler, internal_logging.StreamHandler),
            ) and not isinstance(handler, DefaultTextLogHandler)

            handler.setFormatter(
                LevelAwareFormatter(logger=logger, strip_html=is_file_or_stream)
            )

    @staticmethod
    def _set_level(self, level: Union[int, str]) -> None:
        """Set the log level and sync all handler levels."""
        if isinstance(level, str):
            level = internal_logging._nameToLevel.get(
                level.upper(), internal_logging.INFO
            )
        self.internal_setLevel(level)  # Call the preserved original method
        # Sync handler levels whenever level changes (not on every logger access)
        for handler in self.handlers:
            handler.setLevel(level)

    @staticmethod
    def _set_text_handler(handler: Union[type, object]) -> None:
        """Set a custom text handler class or instance."""
        LoggerExt._text_handler = handler

    @staticmethod
    def _get_text_handler() -> type:
        if LoggerExt._text_handler is None:
            return DefaultTextLogHandler
        if isinstance(LoggerExt._text_handler, type):
            return LoggerExt._text_handler  # it's a class
        return LoggerExt._text_handler.__class__  # it's an instance

    @staticmethod
    def _log_raw(self, message: str) -> None:
        """Write a raw message without level, prefix, or formatting."""
        # Write directly to all handler streams (console, files)
        for handler in self.handlers:
            stream = getattr(handler, "stream", None)
            if stream:
                try:
                    # Check if we should strip HTML
                    msg_to_write = message
                    if handler.formatter and isinstance(
                        handler.formatter, StripHtmlFormatter
                    ):
                        msg_to_write = re.sub(r"<[^>]+>", "", message)

                    stream.write(msg_to_write + "\n")
                    stream.flush()
                except Exception as e:
                    print(f"Logging error (raw write): {e}")
            else:  # For handlers without a stream (e.g., DefaultTextLogHandler), use emit
                try:
                    record = self.makeRecord(
                        name=self.name,
                        level=internal_logging.INFO,
                        fn="",
                        lno=0,
                        msg=message,
                        args=None,
                        exc_info=None,
                    )
                    record.raw = True  # <-- ADD THIS
                    handler.emit(record)

                except Exception as e:
                    print(f"Logging error (raw emit): {e}")

    @staticmethod
    def _char_width(ch: str) -> int:
        """Return the display/column width of a single character.

        Uses ``wcwidth`` if available, otherwise falls back to a heuristic
        based on ``unicodedata.east_asian_width`` plus known wide symbol
        ranges (Dingbats, Miscellaneous Symbols, emoji, etc.) whose glyphs
        typically occupy two columns in modern monospace fonts even though
        Unicode classifies them as narrow or ambiguous.
        """
        try:
            import wcwidth as _wcwidth

            w = _wcwidth.wcwidth(ch)
            return max(w, 0)
        except (ImportError, Exception):
            pass

        cp = ord(ch)
        # East Asian Fullwidth / Wide → always 2
        eaw = unicodedata.east_asian_width(ch)
        if eaw in ("W", "F"):
            return 2
        # Common symbol blocks that render as 2 columns in many terminals
        # (Dingbats, Misc Symbols, Misc Symbols & Arrows, Supplemental Arrows-B)
        if (
            0x2600 <= cp <= 0x27BF  # Misc Symbols + Dingbats
            or 0x2B50 <= cp <= 0x2B55  # stars, circles
            or 0x1F300
            <= cp
            <= 0x1FAFF  # Misc Symbols & Pictographs … Symbols Extended-A
            or 0xFE00 <= cp <= 0xFE0F  # Variation Selectors
            or 0x200D == cp  # ZWJ
        ):
            return 2
        return 1

    # Regex for stripping HTML tags when measuring visible text width.
    _HTML_TAG_RE = re.compile(r"<[^>]+>")

    @staticmethod
    def _display_width(text: str) -> int:
        """Return the display/column width of *text*.

        HTML tags (``<span ...>``, ``<a ...>``, etc.) are stripped before
        measuring so that embedded markup does not inflate the count.
        """
        visible = LoggerExt._HTML_TAG_RE.sub("", text)
        return sum(LoggerExt._char_width(ch) for ch in visible)

    @staticmethod
    def _pad(text: str, target_width: int, fill: str = " ", align: str = "left") -> str:
        """Pad *text* to *target_width* display columns using *fill* char."""
        current = LoggerExt._display_width(text)
        deficit = max(target_width - current, 0)
        if align == "right":
            return fill * deficit + text
        elif align == "center":
            left = deficit // 2
            right = deficit - left
            return fill * left + text + fill * right
        else:  # left
            return text + fill * deficit

    @staticmethod
    def _truncate(text: str, max_display_width: int, ellipsis: str = "…") -> str:
        """Truncate *text* to *max_display_width* display columns with ellipsis."""
        dw = LoggerExt._display_width
        if dw(text) <= max_display_width:
            return text
        ellipsis_w = dw(ellipsis)
        result = []
        current_width = 0
        for ch in text:
            ch_w = LoggerExt._char_width(ch)
            if current_width + ch_w + ellipsis_w > max_display_width:
                break
            result.append(ch)
            current_width += ch_w
        return "".join(result) + ellipsis

    @staticmethod
    def _hard_wrap_word(word: str, max_display_width: int) -> tuple:
        """Hard-wrap a single word that exceeds *max_display_width*.

        Returns ``(complete_lines, remaining_fragment, remaining_width)``.
        """
        lines = []
        chars = []
        w = 0
        for ch in word:
            ch_w = LoggerExt._char_width(ch)
            if w + ch_w > max_display_width:
                lines.append("".join(chars))
                chars = [ch]
                w = ch_w
            else:
                chars.append(ch)
                w += ch_w
        return lines, "".join(chars), w

    # Sentinel that never appears in real text, used to protect spaces
    # inside HTML tags from being split by _wrap_text.
    _TAG_SPACE = "\x00"

    @staticmethod
    def _wrap_text(text: str, max_display_width: int) -> List[str]:
        """Wrap *text* to fit within *max_display_width* display columns.

        Breaks at word boundaries when possible, otherwise hard-wraps.
        HTML tags are protected so that spaces inside attributes are never
        used as break points.
        Returns a list of wrapped lines.
        """
        dw = LoggerExt._display_width
        if dw(text) <= max_display_width:
            return [text]

        # Protect spaces inside HTML tags by replacing them with a sentinel
        sentinel = LoggerExt._TAG_SPACE
        has_tags = "<" in text and ">" in text
        if has_tags:

            def _protect_tag_spaces(m: "re.Match") -> str:
                return m.group(0).replace(" ", sentinel)

            text = LoggerExt._HTML_TAG_RE.sub(_protect_tag_spaces, text)

        words = text.split(" ")
        lines = []
        current_line = ""
        current_width = 0

        for word in words:
            word_width = dw(word)
            # Words containing HTML tags must never be hard-wrapped
            # (splitting characters inside tags produces broken markup).
            word_has_tag = has_tags and "<" in word
            if current_width == 0:
                if word_width <= max_display_width or word_has_tag:
                    current_line = word
                    current_width = word_width
                else:
                    extra, current_line, current_width = LoggerExt._hard_wrap_word(
                        word, max_display_width
                    )
                    lines.extend(extra)
            elif current_width + 1 + word_width <= max_display_width:
                current_line += " " + word
                current_width += 1 + word_width
            else:
                lines.append(current_line)
                if word_width <= max_display_width or word_has_tag:
                    current_line = word
                    current_width = word_width
                else:
                    extra, current_line, current_width = LoggerExt._hard_wrap_word(
                        word, max_display_width
                    )
                    lines.extend(extra)

        if current_line:
            lines.append(current_line)

        # Restore protected spaces inside HTML tags
        if has_tags:
            lines = [line.replace(sentinel, " ") for line in lines]

        return lines

    def _log_box(
        self,
        title: str,
        items: List[str] = None,
        align: str = "left",
        level: str = None,
        max_width: Optional[int] = None,
    ) -> int:
        """Print an ASCII box with title and optional list of lines. Returns box width.

        Parameters:
            max_width: Maximum box width in display columns.  Falls back to
                ``self.box_width`` if set, otherwise ``DEFAULT_BOX_WIDTH``.
        """
        padding = 1
        # Use non-breaking space to prevent HTML space collapsing in handlers
        space = "\u00a0"

        if max_width is None:
            max_width = getattr(self, "box_width", LoggerExt.DEFAULT_BOX_WIDTH)

        dw = LoggerExt._display_width
        wrap = LoggerExt._wrap_text
        content = [title] + (items or [])
        longest = max(dw(line) for line in content)

        # Clamp to max_width (subtract 2 for borders, 2 for padding)
        max_content = max_width - 2 - padding * 2
        if max_content < 4:
            max_content = 4  # minimum usable width

        needs_wrap = longest > max_content
        all_wrapped_title = None
        all_wrapped_items = None

        # Pre-wrap all content to the clamped width so we can measure the
        # actual longest wrapped line and shrink the box to fit.
        if needs_wrap:
            wrap_width = max_content
            all_wrapped_title = wrap(title, wrap_width)
            all_wrapped_items = []
            for item in (items or []):
                all_wrapped_items.append(wrap(item, wrap_width))

            # Recalculate longest from the wrapped output
            longest = 0
            for wl in all_wrapped_title:
                w = dw(wl)
                if w > longest:
                    longest = w
            for wrapped_group in all_wrapped_items:
                for wl in wrapped_group:
                    w = dw(wl)
                    if w > longest:
                        longest = w

        inner_width = longest + padding * 2
        width = inner_width + 2  # full box width including sides

        top = "╔" + "═" * inner_width + "╗"

        # Wrap title lines to fit
        title_lines = all_wrapped_title if needs_wrap else wrap(title, longest)
        title_rows = []
        for tl in title_lines:
            tl_padded = LoggerExt._pad(tl, longest, fill=space, align=align)
            title_rows.append("║" + space * padding + tl_padded + space * padding + "║")

        sep = "╟" + "─" * inner_width + "╢"
        bottom = "╚" + "═" * inner_width + "╝"

        lines = [top] + title_rows
        if items:
            lines.append(sep)
            for idx, item in enumerate(items):
                wrapped = all_wrapped_items[idx] if needs_wrap else wrap(item, inner_width - 1)
                for wl in wrapped:
                    item_padded = LoggerExt._pad(wl, inner_width - 1, fill=space)
                    item_line = space + item_padded
                    lines.append(f"║{item_line}║")
        lines.append(bottom)

        box_text = "\n".join(lines)
        color = LoggerExt.get_color(level) if level else None
        if color:
            box_text = f'<span style="color:{color}">{box_text}</span>'
        LoggerExt._log_raw(self, box_text)

        return width

    @staticmethod
    def _log_link(text: str, action: str, **params: str) -> str:
        """Return an HTML ``<a>`` tag for embedding clickable links in log messages.

        The link uses a custom ``action://`` URI scheme that is never opened
        by a browser — handlers (e.g. ``QTextBrowser.anchorClicked``) parse
        the URL and dispatch the action.

        Parameters:
            text:   Visible link label (HTML-escaped automatically).
            action: Action verb (e.g. ``"select"``, ``"reveal"``).
            **params: Arbitrary key-value pairs appended as query string.

        Returns:
            An ``<a href="action://ACTION?k=v&…">text</a>`` string that can
            be embedded in any log message via f-string::

                link = logger.log_link("pCube1", "select", node="|group1|pCube1")
                logger.info(f"Missing object: {link}")
        """
        import html
        from urllib.parse import urlencode

        safe_text = html.escape(text, quote=False)
        query = urlencode(params) if params else ""
        href = f"action://{action}?{query}" if query else f"action://{action}"
        # No spaces in the tag — _wrap_text splits on spaces and would
        # break the tag if any are present inside attributes.
        return f'<a href="{href}" style="text-decoration:underline">' f"{safe_text}</a>"

    @staticmethod
    def _log_divider(self, width: Optional[int] = None, char: str = "─") -> None:
        """Print a clean divider line. If width is given, use that."""
        if width is None:
            width = 60  # fallback default
        LoggerExt._log_raw(self, char * width)

    # Public API for the custom log levels (SUCCESS, RESULT, NOTICE)
    @staticmethod
    def _success(self, msg: str, *args, **kwargs) -> None:
        # Call the original log method to avoid recursion
        internal_logging.Logger.__dict__["log"](
            self, LoggerExt.SUCCESS, f"{msg}", *args, **kwargs
        )

    @staticmethod
    def _result(self, msg: str, *args, **kwargs) -> None:
        internal_logging.Logger.__dict__["log"](
            self, LoggerExt.RESULT, f"{msg}", *args, **kwargs
        )

    @staticmethod
    def _notice(self, msg: str, *args, **kwargs) -> None:
        internal_logging.Logger.__dict__["log"](
            self, LoggerExt.NOTICE, f"{msg}", *args, **kwargs
        )

    @staticmethod
    def _progress(self, msg: str, *args, **kwargs) -> None:
        internal_logging.Logger.__dict__["log"](
            self, LoggerExt.PROGRESS, f"{msg}", *args, **kwargs
        )

    @staticmethod
    def _set_log_prefix(self, prefix: str) -> None:
        """Set a prefix that will appear before all log messages."""
        self._log_prefix = prefix
        LoggerExt._update_handler_formatters(self)

    @staticmethod
    def _set_log_suffix(self, suffix: str) -> None:
        """Set a suffix that will appear after all log messages."""
        self._log_suffix = suffix
        LoggerExt._update_handler_formatters(self)

    @staticmethod
    def _setup_logging_redirect(
        self,
        target: Union[str, object],
        level: int = internal_logging.INFO,
        monospace: bool = True,
    ) -> None:
        """Redirect logging output to a specified target.
        :param target: Can be a filename (str), a stream (e.g., sys.stdout), or a widget (object).
        :param level: The log level for the redirection.
        :param monospace: Whether to use monospace font for text widgets.
        """
        self.setLevel(level)  # <-- Always set logger level!
        if isinstance(target, str):
            self.add_file_handler(filename=target, level=level)
        elif hasattr(target, "write"):
            stream_handler = internal_logging.StreamHandler(stream=target)
            stream_handler.setLevel(level)
            stream_handler.setFormatter(
                LevelAwareFormatter(logger=self, strip_html=True)
            )
            self.addHandler(stream_handler)
        elif hasattr(target, "append"):
            self.add_text_widget_handler(
                text_widget=target, level=level, monospace=monospace
            )
        else:
            raise ValueError("Unsupported target type for logging redirection.")

    @staticmethod
    def _hide_logger_name(self, hide: bool = True) -> None:
        """Control whether the logger name is displayed in log messages.

        Args:
            hide: If True (default), omit the logger name for cleaner output.
                  If False, include the logger name in messages.
        """
        self._hide_logger_name = hide
        LoggerExt._update_handler_formatters(self)

    @staticmethod
    def _should_log_error(
        logger: internal_logging.Logger, message: str, cache_key: Optional[str] = None
    ) -> tuple[bool, str]:
        """Check if an error should be logged to prevent spam."""
        if not getattr(logger, "_spam_prevention_enabled", True):
            return True, ""

        import time

        # Generate cache key if not provided
        if cache_key is None:
            import hashlib

            cache_key = hashlib.md5(message.encode()).hexdigest()[:12]

        current_time = time.time()
        cache_duration = getattr(logger, "_cache_duration", 300)
        error_cache = getattr(logger, "_error_cache", {})

        # Check if we've seen this error recently
        if cache_key in error_cache:
            last_time, count = error_cache[cache_key]

            # If within cache duration, increment count and skip logging
            if current_time - last_time < cache_duration:
                error_cache[cache_key] = (last_time, count + 1)
                return (
                    False,
                    f" (suppressed {count} similar error{'s' if count != 1 else ''})",
                )

        # Log the error and cache it
        error_cache[cache_key] = (current_time, 1)
        return True, ""

    @staticmethod
    def _error_once(
        logger: internal_logging.Logger,
        message: str,
        *args,
        cache_key: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Log an error with automatic spam prevention."""
        should_log, suffix = LoggerExt._should_log_error(logger, message, cache_key)

        if should_log:
            # Log the full error with suffix
            full_message = f"{message}{suffix}"
            logger.error(full_message, *args, **kwargs)
        else:
            # Log a brief debug message for suppressed errors
            logger.debug(f"Suppressed duplicate error: {message[:50]}...")

    @staticmethod
    def _warning_once(
        logger: internal_logging.Logger,
        message: str,
        *args,
        cache_key: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Log a warning with automatic spam prevention."""
        should_log, suffix = LoggerExt._should_log_error(logger, message, cache_key)

        if should_log:
            full_message = f"{message}{suffix}"
            logger.warning(full_message, *args, **kwargs)
        else:
            logger.debug(f"Suppressed duplicate warning: {message[:50]}...")

    @staticmethod
    def _set_spam_prevention(
        logger: internal_logging.Logger, enabled: bool = True, cache_duration: int = 300
    ) -> None:
        """Configure spam prevention settings."""
        logger._spam_prevention_enabled = enabled
        logger._cache_duration = cache_duration
        if not enabled:
            logger._error_cache.clear()

    @staticmethod
    def _clear_error_cache(logger: internal_logging.Logger) -> None:
        """Clear the error cache."""
        logger._error_cache.clear()

    @classmethod
    def get_color(cls, level: str) -> str:
        """Get the color code for a given log level."""
        return cls.LOG_COLORS.get(level.upper(), "#FFFFFF")

    @classmethod
    def register_html_preset(cls, name: str, format_str: str) -> None:
        """Register a new HTML preset."""
        cls.HTML_PRESETS[name] = format_str

    @classmethod
    def get_html_preset(cls, name: str) -> str:
        """Get an HTML preset by name."""
        return cls.HTML_PRESETS.get(name, cls.HTML_PRESETS["default"])

    @classmethod
    def format_message_as_html(
        cls, message: str, level: str, preset: str = None
    ) -> str:
        """Format a message using HTML presets."""
        color = cls.get_color(level)

        # Determine preset
        if not preset:
            # Use level-based default if available, otherwise default
            preset = cls.LEVEL_PRESETS.get(level.upper(), "default")

        fmt = cls.get_html_preset(preset)
        return fmt.format(color=color, message=message)


class DefaultTextLogHandler(internal_logging.Handler):
    """A generic thread-safe logging handler that writes logs to any widget
    supporting .append(str). Supports raw output, optional HTML color formatting,
    and optional monospace font styling.
    """

    def __init__(self, widget: object, use_html: bool = True, monospace: bool = False):
        super().__init__()
        self.widget = widget
        self.setLevel(internal_logging.NOTSET)
        self.use_html = use_html
        self.monospace = monospace

    def emit(self, record: internal_logging.LogRecord) -> None:
        try:
            if getattr(record, "raw", False):
                msg = record.getMessage()
                if self.monospace:
                    msg = f'<span style="font-family:monospace; white-space:pre;">{msg}</span>'
                threading.Timer(0, self._safe_append, args=(msg,)).start()
            else:
                msg = self.format(record)
                if self.use_html:
                    # Check for preset in extra args
                    preset = getattr(record, "preset", None)
                    formatted = LoggerExt.format_message_as_html(
                        msg, record.levelname, preset
                    )

                    if self.monospace:
                        formatted = f'<span style="font-family:monospace; white-space:pre-wrap;">{formatted}</span>'
                    threading.Timer(0, self._safe_append, args=(formatted,)).start()
                else:
                    threading.Timer(0, self._safe_append, args=(msg,)).start()
        except Exception as e:
            print(f"DefaultTextLogHandler emit error: {e}")

    def _safe_append(self, formatted_msg: str) -> None:
        try:
            if hasattr(self.widget, "append"):
                self.widget.append(formatted_msg)
            elif hasattr(self.widget, "insert"):
                self.widget.insert("end", formatted_msg + "\n")
            else:
                print(formatted_msg)
        except Exception as e:
            print(f"DefaultTextLogHandler append error: {e}")

    def get_color(self, level: str) -> str:
        return LoggerExt.get_color(level)


class TableMixin:
    """Mixin for formatting data as ASCII tables."""

    def format_table(
        self,
        data: List[List[Any]],
        headers: List[str],
        title: Optional[str] = None,
        col_max_width: int = 60,
        max_width: int = 160,
    ) -> str:
        """Formats a list of lists as an ASCII table.

        Args:
            data: List of rows, where each row is a list of values.
            headers: List of column headers.
            title: Optional title for the table.
            col_max_width: Maximum width for any single column.
            max_width: Maximum total table width in characters.

        Returns:
            Formatted table string.
        """
        if not data:
            return ""

        # Ensure data matches headers
        num_cols = len(headers)
        processed_data = []
        for row in data:
            # Pad row if too short
            if len(row) < num_cols:
                row = list(row) + [""] * (num_cols - len(row))
            # Truncate row if too long
            elif len(row) > num_cols:
                row = row[:num_cols]
            processed_data.append([str(item) for item in row])

        # Calculate column widths
        col_widths = [len(h) for h in headers]
        for row in processed_data:
            for i, val in enumerate(row):
                col_widths[i] = max(col_widths[i], len(val))

        # Clamp per-column widths
        col_widths = [min(w, col_max_width) for w in col_widths]

        # Clamp total table width: separators add 3 chars (" | ") between columns
        separator_width = 3 * (num_cols - 1) if num_cols > 1 else 0
        total = sum(col_widths) + separator_width
        if total > max_width:
            available = max_width - separator_width
            if available < num_cols:
                available = num_cols  # at least 1 char per column
            # Shrink columns proportionally
            ratio = available / sum(col_widths)
            col_widths = [max(1, int(w * ratio)) for w in col_widths]
            # Distribute any remaining space due to rounding
            diff = available - sum(col_widths)
            for i in range(abs(diff)):
                if diff > 0:
                    col_widths[i % num_cols] += 1
                elif col_widths[i % num_cols] > 1:
                    col_widths[i % num_cols] -= 1

        # Create format string
        # e.g. "{:<20} | {:<10} | {:<10}"
        fmt = " | ".join([f"{{:<{w}}}" for w in col_widths])

        lines = []

        # Title
        if title:
            table_total = sum(col_widths) + separator_width
            lines.append(title[:max_width] if len(title) > max_width else title)
            lines.append("-" * min(len(title), table_total, max_width))

        # Header (truncate headers to fit potentially shrunk columns)
        trunc_headers = []
        for i, h in enumerate(headers):
            w = col_widths[i]
            if len(h) > w:
                h = h[: w - 3] + "..." if w > 3 else h[:w]
            trunc_headers.append(h)
        lines.append(fmt.format(*trunc_headers))
        lines.append("-+-".join(["-" * w for w in col_widths]))

        # Rows
        for row in processed_data:
            # Truncate values if needed
            trunc_row = []
            for i, val in enumerate(row):
                w = col_widths[i]
                if len(val) > w:
                    val = val[: w - 3] + "..."
                trunc_row.append(val)

            lines.append(fmt.format(*trunc_row))

        return "\n".join(lines)

    def log_table(
        self,
        data: List[List[Any]],
        headers: List[str],
        title: Optional[str] = None,
        level: str = "info",
    ) -> None:
        """Logs a formatted table.

        Args:
            data: List of rows.
            headers: List of column headers.
            title: Optional title.
            level: Logging level (info, warning, error, etc.)
        """
        table_str = self.format_table(data, headers, title)
        if not table_str:
            return

        # Log each line
        # Assumes self has a logger property or attribute
        logger = getattr(self, "logger", None)

        if logger:
            # If logger is a standard python logger
            log_method = getattr(logger, level.lower(), logger.info)

            # If using LoggerExt custom levels, handle them if passed as string
            if hasattr(logger, "log_raw"):
                # Use log_raw if available to avoid prefix duplication if any
                # But log_raw might not respect level.
                # Let's stick to standard logging for now, or check if log_raw exists.
                pass

            # For tables, we often want to print them raw without prefixes if possible,
            # or just log them line by line.

            # If the logger has a 'log_raw' method (from LoggerExt maybe?), use it?
            # LoggerExt doesn't seem to have log_raw in the snippet I read,
            # but SceneDiagnostics uses self.logger.log_raw.
            # Let's check if log_raw is available.
            if hasattr(logger, "log_raw"):
                # We rely on format_table to include the title if provided.
                lines = table_str.split("\n")
                for line in lines:
                    logger.log_raw(line)
            else:
                for line in table_str.split("\n"):
                    log_method(line)
        else:
            print(table_str)


class LoggingMixin(TableMixin):
    """Mixin class for logging utilities.

    Provides a logger for each class and a shared class logger across instances.
    Includes methods for setting log levels, adding handlers, and redirecting logs.
    """

    _logger: internal_logging.Logger = None
    _class_logger = None

    # Expose formatting constants
    LOG_COLORS = LoggerExt.LOG_COLORS
    HTML_PRESETS = LoggerExt.HTML_PRESETS
    log_link = staticmethod(LoggerExt._log_link)

    def __init__(self, *args, log_level: Optional[Union[int, str]] = None, **kwargs):
        super().__init__(*args, **kwargs)
        if log_level is not None:
            self.set_log_level(log_level)

    @ClassProperty
    def logger(cls) -> internal_logging.Logger:
        if cls.__dict__.get("_logger") is None:
            name = f"{cls.__module__}.{cls.__qualname__}"
            logger = internal_logging.Logger(name, internal_logging.NOTSET)  # CHANGED
            logger.propagate = False
            logger.parent = None
            LoggerExt.patch(logger)

            if not logger.handlers:
                logger.add_stream_handler()

            cls._logger = logger

        return cls._logger

    @ClassProperty
    def class_logger(cls) -> internal_logging.Logger:
        if cls.__dict__.get("_class_logger") is None:
            name = f"{cls.__module__}.{cls.__name__}.class"
            logger = internal_logging.getLogger(name)
            logger.setLevel(internal_logging.NOTSET)  # CHANGED
            logger.propagate = False
            LoggerExt.patch(logger)
            cls._class_logger = logger
        return cls._class_logger

    @ClassProperty
    def logging(cls):
        """Access to Python's internal logging module (aliased)."""
        return internal_logging

    @classmethod
    def set_log_level(cls, level: int | str):
        """Set log level for the class logger and its handlers."""
        if isinstance(level, str):
            level = getattr(internal_logging, level.upper(), internal_logging.WARNING)

        cls.logger.setLevel(level)
        for handler in cls.logger.handlers:
            handler.setLevel(level)


# -------------------------------------------------------------------------------

if __name__ == "__main__":
    ...

# -------------------------------------------------------------------------------
