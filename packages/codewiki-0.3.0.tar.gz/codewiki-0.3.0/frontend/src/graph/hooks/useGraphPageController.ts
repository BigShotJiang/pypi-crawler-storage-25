import { useCallback, useEffect, useMemo, useRef, useState, type MouseEvent } from "react";

import { analyzeRepo, updateRepo } from "../../api/runs";
import { getRepoGraphStatus } from "../../api/graph";
import type { GraphResponse, GraphStatusResponse } from "../../api/types";
import { useRepos } from "../../hooks/useRepos";
import type { HiddenVisualNodeOption } from "../GraphFiltersPanel";
import {
  collectTypes,
  collectEdgeTypes,
  countDefaultHiddenIsolatedCommunities,
  defaultFullEdgeTypes,
  defaultReadableEdgeTypes,
  deriveContainment,
  drilldownRootVisualId,
  filterKey,
  filterRawGraph,
  isFileLikeNode,
  hasDetailedCommunities,
  hasHierarchicalCommunities,
  summarizeVisualGraph,
  toggleSetValue,
  type CommunityLevelMode,
  type DrilldownContainerSelection,
  type FlowNode,
  type GraphDensityMode,
  type GraphViewMode
} from "../graphModel";
import {
  onHideVisualNode,
  onHighlightRelatedNodes,
  onOpenContainerDrilldown,
  onOpenFileDetail,
  onOpenSourceRef,
  type SourceRefNavigationDetail
} from "../navigationEvents";
import {
  canShowInFileDetail,
  findBestNodeForSourceRef,
  findOverviewVisualIdForRawNode,
  normalizeSourceRefDetail
} from "../navigation/sourceRefMatching";
import { useVisualGraph } from "../useVisualGraph";
import { useRepoGraph } from "./useRepoGraph";

const DEFAULT_HIDDEN_NODE_TYPES = new Set(["module"]);

function defaultSelectedNodeTypes(types: Iterable<string>): Set<string> {
  const allTypes = [...types];
  const selectedTypes = allTypes.filter((type) => !DEFAULT_HIDDEN_NODE_TYPES.has(type));
  return new Set(selectedTypes.length > 0 ? selectedTypes : allTypes);
}

export function useGraphPageController({
  selectedRepoId,
  onSelectedRepoChange
}: {
  selectedRepoId: string;
  onSelectedRepoChange: (repoId: string) => void;
}) {
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<GraphViewMode>("overview");
  const [densityMode, setDensityMode] = useState<GraphDensityMode>("readable");
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedVisualId, setSelectedVisualId] = useState<string | null>(null);
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);
  const [focusNodeId, setFocusNodeId] = useState<string | null>(null);
  const [drilldownContainer, setDrilldownContainer] = useState<DrilldownContainerSelection | null>(null);
  const [selectedNodeTypes, setSelectedNodeTypes] = useState<Set<string>>(new Set());
  const [selectedEdgeTypes, setSelectedEdgeTypes] = useState<Set<string>>(new Set());
  const [showInferredCalls, setShowInferredCalls] = useState(false);
  const [showIsolatedCommunities, setShowIsolatedCommunities] = useState(false);
  const [communityLevelMode, setCommunityLevelMode] = useState<CommunityLevelMode>("parents");
  const [communityScopeParentId, setCommunityScopeParentId] = useState<string | null>(null);
  const [hiddenVisualIds, setHiddenVisualIds] = useState<Set<string>>(new Set());
  const [highlightedRawNodeIds, setHighlightedRawNodeIds] = useState<Set<string>>(new Set());
  const [highlightLabel, setHighlightLabel] = useState("Ask-related");
  const [graphReloadToken, setGraphReloadToken] = useState(0);
  const [analysisTask, setAnalysisTask] = useState<"analyze" | "update" | null>(null);
  const [analysisMessage, setAnalysisMessage] = useState<string | null>(null);
  const pendingRelatedNodeIdsRef = useRef<string[]>([]);
  const pendingSourceRefRef = useRef<SourceRefNavigationDetail | null>(null);

  const { repos, selectedRepo, loading: repoLoading, error: repoError } = useRepos({
    selectedRepoId,
    onRepoChange: onSelectedRepoChange
  });

  const applyRelatedNodeHighlight = useCallback((repoGraph: GraphResponse, nodeIds: string[]) => {
    const graphNodeIds = new Set(repoGraph.nodes.map((node) => node.id));
    const validNodeIds = nodeIds.filter((nodeId) => graphNodeIds.has(nodeId));
    setHighlightLabel("Ask-related");
    setHighlightedRawNodeIds(new Set(validNodeIds));
    if (validNodeIds.length === 0) {
      return;
    }

    const firstNodeId = validNodeIds[0];
    const firstNode = repoGraph.nodes.find((node) => node.id === firstNodeId) ?? null;
    const visualId = findOverviewVisualIdForRawNode(repoGraph, firstNodeId);
    const visualNode = repoGraph.nodes.find((node) => node.id === visualId) ?? null;
    setSelectedNodeId(firstNodeId);
    setSelectedVisualId(visualId);
    setSelectedFileId(
      firstNode && isFileLikeNode(firstNode)
        ? firstNode.id
        : visualNode && isFileLikeNode(visualNode)
          ? visualNode.id
          : null
    );
    setFocusNodeId(firstNodeId);
    setViewMode("overview");
  }, []);

  const applySourceRefNavigation = useCallback((repoGraph: GraphResponse, detail: SourceRefNavigationDetail) => {
    const match = findBestNodeForSourceRef(repoGraph, detail);
    if (!match) {
      setHighlightLabel("Wiki source");
      setHighlightedRawNodeIds(new Set());
      setError(`No graph node matched ${detail.filePath}`);
      return;
    }

    const { fileNode, targetNode } = match;
    setError(null);
    setHighlightLabel("Wiki source");
    setHighlightedRawNodeIds(new Set([targetNode.id]));
    setSelectedNodeTypes((current) => new Set([...current, fileNode.type, targetNode.type]));
    setHiddenVisualIds((current) => {
      const next = new Set(current);
      next.delete(fileNode.id);
      next.delete(`file-detail:${fileNode.id}`);
      next.delete(targetNode.id);
      return next;
    });
    setSelectedFileId(fileNode.id);
    setSelectedNodeId(targetNode.id);
    setSelectedVisualId(isFileLikeNode(targetNode) ? `file-detail:${fileNode.id}` : targetNode.id);
    setFocusNodeId(targetNode.id);
    setViewMode("file");
  }, []);

  const resetGraphSelection = useCallback(() => {
    setSelectedNodeId(null);
    setSelectedVisualId(null);
    setSelectedFileId(null);
    setFocusNodeId(null);
    setDrilldownContainer(null);
    setHiddenVisualIds(new Set());
    setHighlightedRawNodeIds(new Set());
  }, []);

  const handleGraphLoaded = useCallback(
    (repoGraph: GraphResponse) => {
      setError(null);
      const firstFile = repoGraph.nodes.find(isFileLikeNode) ?? repoGraph.nodes[0] ?? null;

      setSelectedNodeTypes(defaultSelectedNodeTypes(repoGraph.nodes.map((node) => node.type)));
      setSelectedEdgeTypes(defaultReadableEdgeTypes(collectEdgeTypes(repoGraph.edges)));
      setShowInferredCalls(false);
      setShowIsolatedCommunities(false);
      setCommunityLevelMode(defaultCommunityLevelMode());
      setCommunityScopeParentId(null);
      setDensityMode("readable");
      setSelectedNodeId(firstFile?.id ?? null);
      setSelectedVisualId(null);
      setSelectedFileId(firstFile && isFileLikeNode(firstFile) ? firstFile.id : null);
      setFocusNodeId(firstFile?.id ?? null);
      setDrilldownContainer(null);
      setHiddenVisualIds(new Set());
      setViewMode("overview");
      if (pendingRelatedNodeIdsRef.current.length > 0) {
        applyRelatedNodeHighlight(repoGraph, pendingRelatedNodeIdsRef.current);
        pendingRelatedNodeIdsRef.current = [];
      } else if (pendingSourceRefRef.current) {
        applySourceRefNavigation(repoGraph, pendingSourceRefRef.current);
        pendingSourceRefRef.current = null;
      } else {
        setHighlightedRawNodeIds(new Set());
      }
    },
    [applyRelatedNodeHighlight, applySourceRefNavigation]
  );

  const { graph, loading: graphLoading } = useRepoGraph({
    selectedRepoId,
    reloadToken: graphReloadToken,
    onGraphLoaded: handleGraphLoaded,
    onGraphReset: resetGraphSelection,
    onGraphError: setError
  });

  const containment = useMemo(() => deriveContainment(graph), [graph]);
  const nodeTypes = useMemo(() => collectTypes(graph?.nodes ?? []), [graph?.nodes]);
  const edgeTypes = useMemo(() => (graph ? collectEdgeTypes(graph.edges) : []), [graph]);

  const filteredGraph = useMemo(
    () => filterRawGraph(graph, selectedNodeTypes, selectedEdgeTypes, showInferredCalls),
    [graph, selectedEdgeTypes, selectedNodeTypes, showInferredCalls]
  );
  const hiddenIsolatedCommunityCount = useMemo(
    () =>
      countDefaultHiddenIsolatedCommunities(
        graph?.communities ?? [],
        filteredGraph,
        containment,
        communityLevelMode,
        communityScopeParentId
      ),
    [communityLevelMode, communityScopeParentId, containment, filteredGraph, graph?.communities]
  );
  const communityHierarchyAvailable = useMemo(
    () => hasHierarchicalCommunities(graph?.communities ?? []),
    [graph?.communities]
  );
  const detailedCommunitiesAvailable = useMemo(
    () => hasDetailedCommunities(graph?.communities ?? []),
    [graph?.communities]
  );

  useEffect(() => {
    if (!graph || viewMode !== "file" || selectedFileId) {
      return;
    }
    const nextFile = graph.nodes.find(isFileLikeNode);
    if (nextFile) {
      setSelectedFileId(nextFile.id);
      setSelectedNodeId(nextFile.id);
      setSelectedVisualId(`file-detail:${nextFile.id}`);
    }
  }, [graph, selectedFileId, viewMode]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") {
        return;
      }
      setSelectedVisualId(null);
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const viewLayoutKey =
    viewMode === "file"
      ? selectedFileId ?? "none"
      : viewMode === "focus"
        ? focusNodeId ?? "none"
        : viewMode === "drilldown"
          ? drilldownContainer?.id ?? "none"
          : "stable";
  const requestedFlowKey = `${selectedRepoId}:${viewMode}:${viewLayoutKey}:${filterKey(
    selectedNodeTypes
  )}:${filterKey(selectedEdgeTypes)}:${showInferredCalls}:${showIsolatedCommunities}:${densityMode}:${communityLevelMode}:${communityScopeParentId ?? "all"}`;

  const { baseVisualGraph, visualGraph, selectedVisualData, layoutLoading, activeFlowKey } = useVisualGraph({
    graph,
    filteredGraph,
    containment,
    viewMode,
    densityMode,
    selectedFileId,
    selectedNodeId: viewMode === "focus" ? focusNodeId : selectedNodeId,
    drilldownContainer,
    selectedVisualId,
    hiddenVisualIds,
    highlightedRawNodeIds,
    showIsolatedCommunities,
    communityLevelMode,
    communityScopeParentId,
    flowKey: requestedFlowKey
  });

  const handleNavigateToNode = useCallback(
    (nodeId: string, edgeType?: string) => {
      if (!graph) {
        return;
      }
      const targetNode = graph.nodes.find((candidate) => candidate.id === nodeId);
      if (!targetNode) {
        setError(`Node not found: ${nodeId}`);
        return;
      }

      const targetFileId = isFileLikeNode(targetNode) ? targetNode.id : containment.fileByNode.get(targetNode.id) ?? null;
      const showInFileDetail = Boolean(targetFileId && canShowInFileDetail(targetNode));
      const nextVisualId = showInFileDetail
        ? isFileLikeNode(targetNode)
          ? `file-detail:${targetFileId}`
          : targetNode.id
        : targetNode.id;

      setError(null);
      setHighlightLabel("Reference");
      setHighlightedRawNodeIds(new Set([targetNode.id]));
      setSelectedNodeTypes((current) => {
        const next = new Set(current);
        next.add(targetNode.type);
        if (targetFileId) {
          const fileNode = containment.nodeById.get(targetFileId);
          if (fileNode) {
            next.add(fileNode.type);
          }
        }
        return next;
      });
      if (edgeType) {
        setSelectedEdgeTypes((current) => new Set([...current, edgeType]));
      }
      setHiddenVisualIds((current) => {
        const next = new Set(current);
        const revealRawIds = new Set([targetNode.id]);
        if (targetFileId) {
          revealRawIds.add(targetFileId);
        }

        baseVisualGraph.nodes.forEach((visualNode) => {
          const shouldReveal =
            visualNode.id === targetNode.id ||
            visualNode.id === targetFileId ||
            visualNode.id === `file-detail:${targetFileId}` ||
            visualNode.id === nextVisualId ||
            visualNode.data.rawNodeIds.some((rawId) => revealRawIds.has(rawId));
          if (shouldReveal) {
            next.delete(visualNode.id);
          }
        });
        next.delete(targetNode.id);
        if (targetFileId) {
          next.delete(targetFileId);
          next.delete(`file-detail:${targetFileId}`);
        }
        next.delete(nextVisualId);
        return next;
      });
      setSelectedFileId(targetFileId);
      setSelectedNodeId(targetNode.id);
      setFocusNodeId(targetNode.id);
      setSelectedVisualId(nextVisualId);
      setViewMode(showInFileDetail ? "file" : "focus");
    },
    [baseVisualGraph.nodes, containment.fileByNode, containment.nodeById, graph]
  );

  const hiddenNodes = useMemo<HiddenVisualNodeOption[]>(() => {
    const nodeById = new Map(baseVisualGraph.nodes.map((node) => [node.id, node]));
    return [...hiddenVisualIds]
      .map((nodeId) => {
        const node = nodeById.get(nodeId);
        if (!node) {
          return {
            id: nodeId,
            label: nodeId,
            type: "hidden",
            meta: "not in current view"
          };
        }
        const data = node.data;
        return {
          id: node.id,
          label: data.kind === "container" ? data.title : data.label,
          type: data.kind === "container" ? data.containerType : data.nodeType,
          meta: data.pathLabel
        };
      })
      .sort((left, right) => left.label.localeCompare(right.label));
  }, [baseVisualGraph.nodes, hiddenVisualIds]);

  const selectedNode = useMemo(
    () => graph?.nodes.find((node) => node.id === selectedNodeId) ?? null,
    [graph?.nodes, selectedNodeId]
  );

  const selectedDetailRawIds = useMemo(
    () => selectedVisualData?.rawNodeIds ?? (selectedNodeId ? [selectedNodeId] : []),
    [selectedNodeId, selectedVisualData]
  );

  const selectedNodeEdges = useMemo(() => {
    const rawIds = new Set(selectedDetailRawIds);
    return graph?.edges.filter((edge) => rawIds.has(edge.source) || rawIds.has(edge.target)) ?? [];
  }, [graph?.edges, selectedDetailRawIds]);

  const graphStats = useMemo(
    () => summarizeVisualGraph(graph, filteredGraph, visualGraph),
    [filteredGraph, graph, visualGraph]
  );

  const toggleNodeType = useCallback((type: string) => {
    setSelectedNodeTypes((current) => toggleSetValue(current, type));
  }, []);

  const toggleEdgeType = useCallback((type: string) => {
    setSelectedEdgeTypes((current) => toggleSetValue(current, type));
  }, []);

  const resetFilters = useCallback(() => {
    setSelectedNodeTypes(defaultSelectedNodeTypes(nodeTypes));
    setSelectedEdgeTypes(densityMode === "readable" ? defaultReadableEdgeTypes(edgeTypes) : defaultFullEdgeTypes(edgeTypes));
    setShowInferredCalls(densityMode === "full");
    setShowIsolatedCommunities(false);
    setCommunityLevelMode(defaultCommunityLevelMode());
    setCommunityScopeParentId(null);
  }, [densityMode, edgeTypes, nodeTypes]);

  const selectCommunityLevelMode = useCallback((mode: CommunityLevelMode, scopeParentId: string | null = null) => {
    setCommunityLevelMode(mode);
    setCommunityScopeParentId(scopeParentId);
    setSelectedVisualId(null);
    setSelectedNodeId(null);
    setSelectedFileId(null);
    setFocusNodeId(null);
    setDrilldownContainer(null);
    setViewMode("overview");
  }, []);

  const toggleDensityMode = useCallback(() => {
    setDensityMode((current) => {
      const next: GraphDensityMode = current === "readable" ? "full" : "readable";
      setSelectedEdgeTypes(next === "readable" ? defaultReadableEdgeTypes(edgeTypes) : defaultFullEdgeTypes(edgeTypes));
      setShowInferredCalls(next === "full");
      return next;
    });
  }, [edgeTypes]);

  const showHiddenNode = useCallback((nodeId: string) => {
    setHiddenVisualIds((current) => {
      const next = new Set(current);
      next.delete(nodeId);
      return next;
    });
  }, []);

  const showAllHiddenNodes = useCallback(() => {
    setHiddenVisualIds(new Set());
  }, []);

  const clearHighlights = useCallback(() => {
    setHighlightedRawNodeIds(new Set());
  }, []);

  useEffect(() => {
    if (!selectedRepoId || !analysisTask) {
      return;
    }

    let cancelled = false;
    const refreshProgress = async () => {
      try {
        const status = await getRepoGraphStatus(selectedRepoId);
        if (cancelled) {
          return;
        }
        setAnalysisMessage(runningAnalysisMessage(analysisTask, status));
      } catch {
        // Keep the existing running banner if progress polling is temporarily unavailable.
      }
    };

    void refreshProgress();
    const intervalId = window.setInterval(refreshProgress, 2000);
    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [analysisTask, selectedRepoId]);

  const openOverview = useCallback(() => {
    setViewMode("overview");
    setCommunityLevelMode(defaultCommunityLevelMode());
    setCommunityScopeParentId(null);
    setSelectedVisualId(null);
    setSelectedNodeId(null);
    setSelectedFileId(null);
    setFocusNodeId(null);
  }, []);

  const openFileDetail = useCallback(
    (fileId: string) => {
      const fileNode = graph?.nodes.find((node) => node.id === fileId) ?? null;
      if (fileNode) {
        setSelectedNodeTypes((current) => new Set([...current, fileNode.type]));
      }
      setSelectedVisualId(`file-detail:${fileId}`);
      setSelectedNodeId(fileId);
      setSelectedFileId(fileId);
      setFocusNodeId(fileId);
      setViewMode("file");
    },
    [graph?.nodes]
  );

  const openCommunityChildren = useCallback(
    (communityId?: string, communityLevel?: number): boolean => {
      const resolvedCommunityId = communityIdFromVisualId(communityId);
      const resolvedLevel =
        communityLevel ??
        graph?.communities?.find((community) => community.id === resolvedCommunityId)?.level;
      const nextMode = nextCommunityLevelMode(graph, resolvedCommunityId, resolvedLevel);
      if (!nextMode || !resolvedCommunityId) {
        return false;
      }
      setCommunityLevelMode(nextMode);
      setCommunityScopeParentId(resolvedCommunityId);
      setSelectedVisualId(null);
      setSelectedNodeId(null);
      setSelectedFileId(null);
      setDrilldownContainer(null);
      setViewMode("overview");
      return true;
    },
    [graph]
  );

  const openContainerDrilldown = useCallback(
    (container: DrilldownContainerSelection) => {
      if (
        container.containerType === "community" &&
        openCommunityChildren(container.communityId ?? container.id, container.communityLevel)
      ) {
        return;
      }
      const firstFileId =
        container.rawNodeIds.find((rawNodeId) => {
          const rawNode = containment.nodeById.get(rawNodeId);
          return Boolean(rawNode && isFileLikeNode(rawNode));
        }) ?? null;
      setDrilldownContainer(container);
      setSelectedVisualId(drilldownRootVisualId(container.id));
      setSelectedNodeId(firstFileId);
      setSelectedFileId(firstFileId);
      setFocusNodeId(firstFileId);
      setViewMode("drilldown");
    },
    [containment.nodeById, openCommunityChildren]
  );

  const runFullAnalysis = useCallback(async () => {
    if (!selectedRepoId || analysisTask) {
      return;
    }
    setAnalysisTask("analyze");
    setAnalysisMessage("Running full analysis...");
    setError(null);
    try {
      const result = await analyzeRepo(selectedRepoId);
      setAnalysisMessage(
        `Analysis complete: ${result.node_count} nodes, ${result.edge_count} edges, ${result.chunk_count} chunks, ${result.community_count} communities.`
      );
      setGraphReloadToken((value) => value + 1);
    } catch (apiError) {
      setAnalysisMessage(null);
      setError(apiError instanceof Error ? apiError.message : "Repository analysis failed");
    } finally {
      setAnalysisTask(null);
    }
  }, [analysisTask, selectedRepoId]);

  const runIncrementalUpdate = useCallback(async () => {
    if (!selectedRepoId || analysisTask) {
      return;
    }
    setAnalysisTask("update");
    setAnalysisMessage("Running incremental update...");
    setError(null);
    try {
      const result = await updateRepo(selectedRepoId, {
        refresh_chunks: true,
        regenerate_wiki: true
      });
      const staleSuffix = result.stale_pages.length ? ` ${result.stale_pages.length} wiki pages refreshed.` : "";
      setAnalysisMessage(
        `Update complete: ${result.node_count} nodes, ${result.edge_count} edges, ${result.chunk_count} chunks.${staleSuffix}`
      );
      setGraphReloadToken((value) => value + 1);
    } catch (apiError) {
      setAnalysisMessage(null);
      setError(apiError instanceof Error ? apiError.message : "Repository update failed");
    } finally {
      setAnalysisTask(null);
    }
  }, [analysisTask, selectedRepoId]);

  useEffect(() => {
    return onOpenFileDetail((detail) => {
      const fileId = detail?.fileId;
      if (fileId) {
        openFileDetail(fileId);
      }
    });
  }, [openFileDetail]);

  useEffect(() => {
    return onOpenContainerDrilldown((detail) => {
      if (
        !detail?.id ||
        !detail.title ||
        !detail.pathLabel ||
        !Array.isArray(detail.rawNodeIds) ||
        (detail.containerType !== "community" && detail.containerType !== "directory")
      ) {
        return;
      }
      openContainerDrilldown({
        id: detail.id,
        title: detail.title,
        pathLabel: detail.pathLabel,
        containerType: detail.containerType,
        communityId: detail.communityId,
        communityLevel: detail.communityLevel,
        parentCommunityId: detail.parentCommunityId,
        rawNodeIds: detail.rawNodeIds
      });
    });
  }, [openContainerDrilldown]);

  useEffect(() => {
    return onHideVisualNode((detail) => {
      const nodeId = detail?.nodeId;
      if (!nodeId) {
        return;
      }
      setHiddenVisualIds((current) => {
        const next = new Set(current);
        next.add(nodeId);
        return next;
      });
      setSelectedVisualId((current) => (current === nodeId ? null : current));
      setSelectedNodeId((current) => (current === nodeId ? null : current));
    });
  }, []);

  useEffect(() => {
    return onHighlightRelatedNodes((detail) => {
      const repoId = detail?.repoId;
      const nodeIds = detail?.nodeIds?.filter(Boolean) ?? [];
      if (repoId && repoId !== selectedRepoId) {
        pendingRelatedNodeIdsRef.current = nodeIds;
        onSelectedRepoChange(repoId);
        return;
      }
      if (!graph) {
        pendingRelatedNodeIdsRef.current = nodeIds;
        return;
      }
      applyRelatedNodeHighlight(graph, nodeIds);
    });
  }, [applyRelatedNodeHighlight, graph, onSelectedRepoChange, selectedRepoId]);

  useEffect(() => {
    return onOpenSourceRef((eventDetail) => {
      const detail = normalizeSourceRefDetail(eventDetail);
      if (!detail) {
        return;
      }
      if (detail.repoId && detail.repoId !== selectedRepoId) {
        pendingSourceRefRef.current = detail;
        onSelectedRepoChange(detail.repoId);
        return;
      }
      if (!graph) {
        pendingSourceRefRef.current = detail;
        return;
      }
      applySourceRefNavigation(graph, detail);
    });
  }, [applySourceRefNavigation, graph, onSelectedRepoChange, selectedRepoId]);

  const handleNodeClick = useCallback(
    (_: MouseEvent, node: FlowNode) => {
      const data = node.data;
      const primaryNodeId = data.kind === "container" ? data.primaryNodeId ?? null : data.codeNode.id;
      if (viewMode === "overview" && data.kind === "container" && data.containerType === "directory") {
        openContainerDrilldown({
          id: node.id,
          title: data.title,
          pathLabel: data.pathLabel,
          containerType: data.containerType,
          communityId: data.communityId,
          communityLevel: data.communityLevel,
          parentCommunityId: data.parentCommunityId,
          rawNodeIds: data.rawNodeIds
        });
        return;
      }
      if (viewMode === "overview" && data.kind === "container" && data.containerType === "community") {
        setDrilldownContainer({
          id: node.id,
          title: data.title,
          pathLabel: data.pathLabel,
          containerType: data.containerType,
          communityId: data.communityId,
          communityLevel: data.communityLevel,
          parentCommunityId: data.parentCommunityId,
          rawNodeIds: data.rawNodeIds
        });
        setSelectedVisualId(node.id);
        setSelectedNodeId(null);
        setSelectedFileId(null);
        return;
      }

      setSelectedVisualId(node.id);
      setSelectedNodeId(primaryNodeId);

      if (viewMode !== "file") {
        setSelectedFileId(data.fileId ?? null);
      }
    },
    [openContainerDrilldown, viewMode]
  );

  const handleNodeDoubleClick = useCallback(
    (_: MouseEvent, node: FlowNode) => {
      const data = node.data;
      if (data.kind === "code" && isFileLikeNode(data.codeNode) && data.fileId) {
        openFileDetail(data.fileId);
        return;
      }
      if (data.kind === "container" && data.containerType === "file" && data.fileId) {
        openFileDetail(data.fileId);
        return;
      }
      if (viewMode === "overview" && data.kind === "container" && data.containerType === "community") {
        openContainerDrilldown({
          id: node.id,
          title: data.title,
          pathLabel: data.pathLabel,
          containerType: "community",
          communityId: data.communityId,
          communityLevel: data.communityLevel,
          parentCommunityId: data.parentCommunityId,
          rawNodeIds: data.rawNodeIds
        });
        return;
      }
      const primaryNodeId = data.kind === "container" ? data.primaryNodeId ?? null : data.codeNode.id;
      if (viewMode === "focus" && primaryNodeId) {
        setFocusNodeId(primaryNodeId);
        setSelectedNodeId(primaryNodeId);
        setSelectedVisualId(primaryNodeId);
      }
    },
    [openContainerDrilldown, openFileDetail, viewMode]
  );

  const selectMode = useCallback(
    (mode: GraphViewMode) => {
      if (mode === "drilldown" && drilldownContainer) {
        if (openCommunityChildren(drilldownContainer.communityId ?? drilldownContainer.id, drilldownContainer.communityLevel)) {
          return;
        }
        setViewMode(mode);
        setSelectedVisualId(drilldownRootVisualId(drilldownContainer.id));
        setSelectedNodeId(null);
        return;
      }
      setViewMode(mode);
      if (mode === "file" && selectedFileId) {
        setSelectedVisualId(`file-detail:${selectedFileId}`);
        setSelectedNodeId(selectedFileId);
      }
      if (mode === "overview") {
        setCommunityLevelMode(defaultCommunityLevelMode());
        setCommunityScopeParentId(null);
        if (selectedFileId) {
          setSelectedVisualId(selectedFileId);
          setSelectedNodeId(selectedFileId);
        }
      }
      if (mode === "focus" && selectedNodeId) {
        setFocusNodeId(selectedNodeId);
        setSelectedVisualId(selectedNodeId);
      }
    },
    [drilldownContainer, openCommunityChildren, selectedFileId, selectedNodeId]
  );

  const hasRenderedGraph = baseVisualGraph.nodes.length > 0;
  const isLoading = repoLoading || graphLoading || (layoutLoading && !hasRenderedGraph);

  return {
    repos,
    selectedRepo,
    repoLoading,
    repoError,
    error,
    analysisTask,
    analysisMessage,
    viewMode,
    densityMode,
    drilldownContainer,
    drilldownAvailable: Boolean(drilldownContainer),
    selectedFileId,
    selectedNodeId,
    nodeTypes,
    edgeTypes,
    selectedNodeTypes,
    selectedEdgeTypes,
    showInferredCalls,
    showIsolatedCommunities,
    communityLevelMode,
    communityScopeParentId,
    communityHierarchyAvailable,
    detailedCommunitiesAvailable,
    hiddenIsolatedCommunityCount,
    highlightedRawNodeIds,
    highlightLabel,
    hiddenNodes,
    graphStats,
    graph,
    visualGraph,
    selectedVisualData,
    selectedNode,
    selectedNodeEdges,
    containment,
    flowKey: activeFlowKey,
    isLoading,
    graphLoaded: Boolean(graph),
    actions: {
      selectMode,
      toggleNodeType,
      toggleEdgeType,
      toggleDensityMode,
      setShowInferredCalls,
      setShowIsolatedCommunities,
      setCommunityLevelMode: selectCommunityLevelMode,
      resetFilters,
      showHiddenNode,
      showAllHiddenNodes,
      clearHighlights,
      openOverview,
      openFileDetail,
      runFullAnalysis,
      runIncrementalUpdate,
      handleNodeClick,
      handleNodeDoubleClick,
      handleNavigateToNode
    }
  };
}

function defaultCommunityLevelMode(): CommunityLevelMode {
  return "parents";
}

function runningAnalysisMessage(
  task: "analyze" | "update",
  status: GraphStatusResponse
): string {
  const prefix = task === "analyze" ? "Analyzing" : "Updating";
  return `${prefix}... Nodes ${status.node_count} / Edges ${status.edge_count} / Chunks ${status.chunk_count}`;
}

function communityIdFromVisualId(value?: string): string | undefined {
  return value?.startsWith("community:") ? value.slice("community:".length) : value;
}

function nextCommunityLevelMode(
  graph: GraphResponse | null,
  communityId?: string,
  communityLevel?: number
): CommunityLevelMode | null {
  if (!graph || !communityId) {
    return null;
  }
  const communities = graph.communities ?? [];
  if (communityLevel === 0 && communities.some((community) => community.parent_id === communityId && community.level === 1)) {
    return "children";
  }
  if (communityLevel === 1 && communities.some((community) => community.parent_id === communityId && community.level === 2)) {
    return "details";
  }
  return null;
}
