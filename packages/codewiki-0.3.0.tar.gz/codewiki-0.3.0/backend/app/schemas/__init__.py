"""Pydantic API schemas."""

