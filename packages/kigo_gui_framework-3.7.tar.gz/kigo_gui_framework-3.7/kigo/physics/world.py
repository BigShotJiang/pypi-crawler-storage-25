from ctypes import byref
from kigo.physics._native.bindings import lib, Vec2

class PhysicsWorld:
    def __init__(self):
        lib.world_reset()

    def create_body(self, x, y, vx=0, vy=0, mass=1.0, static=False):
        return lib.body_create(
            float(x), float(y),
            float(vx), float(vy),
            float(mass),
            int(static),
        )

    def apply_force(self, body_id, fx, fy):
        lib.body_apply_force(body_id, float(fx), float(fy))

    def set_acceleration(self, body_id, ax, ay):
        lib.body_set_acceleration(body_id, float(ax), float(ay))

    def clear_acceleration(self, body_id):
        lib.body_clear_acceleration(body_id)

    def step(self, dt):
        lib.world_step(float(dt))

    def get_position(self, body_id):
        pos = Vec2()
        lib.body_get_position(body_id, byref(pos))
        return pos.x, pos.y