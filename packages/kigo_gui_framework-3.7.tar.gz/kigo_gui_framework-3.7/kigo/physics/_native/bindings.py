from ctypes import *
from pathlib import Path
import sys

_dir = Path(__file__).parent

if sys.platform.startswith("win"):
    lib = CDLL(str(_dir / "physics.dll"))
elif sys.platform == "darwin":
    lib = CDLL(str(_dir / "libphysics.dylib"))
else:
    lib = CDLL(str(_dir / "libphysics.so"))

class Vec2(Structure):
    _fields_ = [
        ("x", c_float),
        ("y", c_float),
    ]

lib.world_reset.argtypes = []
lib.world_reset.restype = None

lib.body_create.argtypes = [
    c_float, c_float,
    c_float, c_float,
    c_float,
    c_int
]
lib.body_create.restype = c_int

lib.body_apply_force.argtypes = [c_int, c_float, c_float]
lib.body_apply_force.restype = None

lib.body_set_acceleration.argtypes = [c_int, c_float, c_float]
lib.body_set_acceleration.restype = None

lib.body_clear_acceleration.argtypes = [c_int]
lib.body_clear_acceleration.restype = None

lib.world_step.argtypes = [c_float]
lib.world_step.restype = None

lib.body_get_position.argtypes = [c_int, POINTER(Vec2)]
lib.body_get_position.restype = None