# kigo/render/dx/renderer.py
from kigo.render.base.renderer import BaseRenderer

class DXRenderer(BaseRenderer):
    def initialize(self):
        print("DirectX renderer initialized (Windows)")

    def draw(self):
        pass
