# kigo/render/wgpu/renderer.py
import wgpu
from rendercanvas.qt import RenderCanvas
from kigo.render.base.renderer import BaseRenderer

class WGPURenderer(BaseRenderer):
    def initialize(self):
        self.canvas = RenderCanvas(qt_parent=self.window)
        self.context = self.canvas.get_wgpu_context()

        adapter = wgpu.gpu.request_adapter_sync(
            power_preference="high-performance"
        )
        self.device = adapter.request_device_sync()

        self.format = self.context.get_preferred_format(adapter)
        self.context.configure(
            device=self.device,
            format=self.format,
        )

    def draw(self):
        current_tex = self.context.get_current_texture()
        encoder = self.device.create_command_encoder()

        pass_enc = encoder.begin_render_pass(
            color_attachments=[{
                "view": current_tex,
                "load_op": wgpu.LoadOp.clear,
                "store_op": wgpu.StoreOp.store,
                "clear_value": (0, 0, 0, 1),
            }]
        )

        pass_enc.end()
        self.device.queue.submit([encoder.finish()])