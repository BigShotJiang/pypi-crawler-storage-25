import torch
import torch.nn as nn
import torch.nn.functional as F
from os import path, makedirs
from torch import optim
from torch.optim.lr_scheduler import CosineAnnealingLR, MultiStepLR
from threading import Thread, Event
from torch.utils.data import DataLoader
import datetime
import torchvision
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ..BaseModel.IModel import IModel
from ..BaseModel.eModelBase import eModelExportType, eOptimizerType
from ..BaseModel.eSegmentationModel import eDinoUperNetModel
from .DinoUperNetConfig import TrainingConfig
import os
import gc
import warnings

warnings.filterwarnings("ignore", message="xFormers is not available")

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False

try:
    import albumentations as A
    from albumentations.pytorch import ToTensorV2
    ALBUMENTATIONS_AVAILABLE = True
except ImportError:
    ALBUMENTATIONS_AVAILABLE = False

try:
    import openvino as ov
    OPENVINO_AVAILABLE = True
except ImportError:
    OPENVINO_AVAILABLE = False


# ── PPM ───────────────────────────────────────────────────────────────────────

class _PPM(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, pool_scales: tuple = (1, 2, 3, 6)):
        super().__init__()
        self.stages = nn.ModuleList([
            nn.Sequential(
                nn.AdaptiveAvgPool2d(scale),
                nn.Conv2d(in_channels, out_channels, 1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
            )
            for scale in pool_scales
        ])
        self.bottleneck = nn.Sequential(
            nn.Conv2d(in_channels + out_channels * len(pool_scales), out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h, w = x.shape[2:]
        pooled = [
            F.interpolate(stage(x), size=(h, w), mode="bilinear", align_corners=False)
            for stage in self.stages
        ]
        return self.bottleneck(torch.cat([x] + pooled, dim=1))

class _Feature2Pyramid(nn.Module):
    """
    Port từ mmseg.models.necks.Feature2Pyramid.
    Biến 4 ViT features cùng resolution thành multi-scale pyramid.
      scale 4.0  → ConvTranspose2d x2 (stack 2 lần, có BN+GELU ở giữa)
      scale 2.0  → ConvTranspose2d x1
      scale 1.0  → Identity
      scale 0.5  → MaxPool2d(2)
      scale 0.25 → MaxPool2d(4)
    Dùng BatchNorm2d (single-GPU). Nếu DDP thì đổi sang SyncBatchNorm.
    """
    _VALID = (4.0, 2.0, 1.0, 0.5, 0.25)

    def __init__(self, embed_dim: int, rescales=(2.0, 1.0, 0.5, 0.25)):
        super().__init__()
        rescales = [float(r) for r in rescales]
        for r in rescales:
            if r not in self._VALID:
                raise ValueError(f"Invalid rescale {r}. Valid: {self._VALID}")
        self.rescales = rescales

        self.ops = nn.ModuleList()
        for r in rescales:
            if r == 4.0:
                op = nn.Sequential(
                    nn.ConvTranspose2d(embed_dim, embed_dim, kernel_size=2, stride=2),
                    nn.BatchNorm2d(embed_dim),
                    nn.GELU(),
                    nn.ConvTranspose2d(embed_dim, embed_dim, kernel_size=2, stride=2),
                )
            elif r == 2.0:
                op = nn.ConvTranspose2d(embed_dim, embed_dim, kernel_size=2, stride=2)
            elif r == 1.0:
                op = nn.Identity()
            elif r == 0.5:
                op = nn.MaxPool2d(kernel_size=2, stride=2)
            elif r == 0.25:
                op = nn.MaxPool2d(kernel_size=4, stride=4)
            self.ops.append(op)

    def forward(self, inputs):
        assert len(inputs) == len(self.ops), \
            f"Expected {len(self.ops)} features, got {len(inputs)}"
        return tuple(op(x) for op, x in zip(self.ops, inputs))

# ── UPerHead ──────────────────────────────────────────────────────────────────

class _UPerHead(nn.Module):
    def __init__(self, in_channels: int = 384, channels: int = 512, num_classes: int = 2,
                 pool_scales: tuple = (1, 2, 3, 6), dropout: float = 0.1):
        super().__init__()
        self.ppm = _PPM(in_channels, channels, pool_scales)
        self.lateral_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(in_channels, channels, 1, bias=False),
                nn.BatchNorm2d(channels),
                nn.ReLU(inplace=True),
            )
            for _ in range(3)
        ])
        self.fpn_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(channels, channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(channels),
                nn.ReLU(inplace=True),
            )
            for _ in range(3)
        ])
        self.head = nn.Sequential(
            nn.Conv2d(channels * 4, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout),
            nn.Conv2d(channels, num_classes, 1),
        )

    def forward(self, features: tuple) -> torch.Tensor:
        f1, f2, f3, f4 = features
        ppm_out = self.ppm(f4)
        lat = [conv(f) for conv, f in zip(self.lateral_convs, [f1, f2, f3])]
        lat[2] = lat[2] + F.interpolate(ppm_out, size=lat[2].shape[2:], mode="bilinear", align_corners=False)
        lat[1] = lat[1] + F.interpolate(lat[2],  size=lat[1].shape[2:], mode="bilinear", align_corners=False)
        lat[0] = lat[0] + F.interpolate(lat[1],  size=lat[0].shape[2:], mode="bilinear", align_corners=False)
        fpn_outs = [conv(l) for conv, l in zip(self.fpn_convs, lat)]
        fpn_outs.append(ppm_out)
        ref = fpn_outs[0].shape[2:]
        fpn_outs = [F.interpolate(x, size=ref, mode="bilinear", align_corners=False) for x in fpn_outs]
        return self.head(torch.cat(fpn_outs, dim=1))


# ── AuxHead ───────────────────────────────────────────────────────────────────

class _AuxHead(nn.Module):
    def __init__(self, in_channels: int = 384, channels: int = 256,
                 num_classes: int = 2, dropout: float = 0.1):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout),
            nn.Conv2d(channels, num_classes, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.conv(x)


# ── _DINOv2Segmentation ───────────────────────────────────────────────────────

class _DINOv2Segmentation(nn.Module):
    def __init__(self, num_classes: int = 2, backbone_name: str = "dinov2_vits14",
                 feature_dim: int = 384, decoder_channels: int = 512,
                 dropout: float = 0.1, pool_scales: tuple = (1, 2, 3, 6),
                 layer_indices: tuple = (2, 5, 8, 11),
                 scale_factors: tuple = (2.0, 1.0, 0.5, 0.25)):
        super().__init__()
        self.backbone     = torch.hub.load("facebookresearch/dinov2", backbone_name, pretrained=True)
        self.layer_indices = list(layer_indices)
        self.scale_factors = list(scale_factors)

        self.neck = _Feature2Pyramid(embed_dim=feature_dim, rescales=scale_factors)

        self.decode_head  = _UPerHead(
            in_channels=feature_dim, num_classes=num_classes,
            channels=decoder_channels, dropout=dropout, pool_scales=pool_scales,
        )
        self.aux_head = _AuxHead(
            in_channels=feature_dim,
            channels=max(decoder_channels // 2, 256),
            num_classes=num_classes,
            dropout=dropout,
        )

    def forward(self, x: torch.Tensor):
        H, W      = x.shape[2:]
        patch_size = self.backbone.patch_size
        pH, pW    = H // patch_size, W // patch_size

        intermediate = self.backbone.get_intermediate_layers(
            x, n=self.layer_indices, return_class_token=False
        )

        features = []
        for feat in intermediate:
            B, _, D = feat.shape
            feat = feat.reshape(B, pH, pW, D).permute(0, 3, 1, 2).contiguous()
            features.append(feat)
        features = self.neck(features)   # ⬅ Feature2Pyramid xử lý multi-scale

        main_logits = self.decode_head(tuple(features))
        main_logits = F.interpolate(main_logits, size=(H, W), mode="bilinear", align_corners=False)

        if self.training:
            aux_logits = self.aux_head(features[2])
            aux_logits = F.interpolate(aux_logits, size=(H, W), mode="bilinear", align_corners=False)
            return main_logits, aux_logits

        return main_logits


_ARCH_LAYER_MAP = {
    eDinoUperNetModel.DINO_S: ("dinov2_vits14", 384,  [2, 5,  8,  11], [2.0, 1.0, 0.5, 0.25]),
    eDinoUperNetModel.DINO_B: ("dinov2_vitb14", 768,  [2, 5,  8,  11], [2.0, 1.0, 0.5, 0.25]),
    eDinoUperNetModel.DINO_L: ("dinov2_vitl14", 1024, [5, 11, 17, 23], [2.0, 1.0, 0.5, 0.25]),
}


# ── ONNX Wrapper ──────────────────────────────────────────────────────────────

class _ONNXWrapper(nn.Module):
    def __init__(self, model: _DINOv2Segmentation):
        super().__init__()
        self.model = model
        self.model.eval()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x).argmax(dim=1, keepdim=True)


# ── SegDataset ────────────────────────────────────────────────────────────────

class _SegDataset(torchvision.datasets.ImageFolder):
    _IMG_EXTS  = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}
    _MASK_EXTS = ['.png', '.jpg', '.jpeg']

    def __init__(self, root: str, transform=None):
        self.root       = root
        self.images_dir = path.join(root, "images")
        self.masks_dir  = path.join(root, "masks")
        self.transform  = transform

        if not path.isdir(self.images_dir):
            raise FileNotFoundError(f"images/ not found: {self.images_dir}")
        if not path.isdir(self.masks_dir):
            raise FileNotFoundError(f"masks/ not found: {self.masks_dir}")

        self.filenames = sorted(
            f for f in os.listdir(self.images_dir)
            if path.splitext(f)[1].lower() in self._IMG_EXTS
        )
        if not self.filenames:
            raise RuntimeError(f"No images found in {self.images_dir}")

        missing = []
        self._mask_filenames = []
        for fname in self.filenames:
            stem  = path.splitext(fname)[0]
            found = None
            for ext in self._MASK_EXTS:
                candidate = path.join(self.masks_dir, stem + ext)
                if path.exists(candidate):
                    found = stem + ext
                    break
            if found is None:
                missing.append(fname)
            else:
                self._mask_filenames.append(found)

        if missing:
            raise RuntimeError(
                f"Missing masks for {len(missing)} images: {missing[:5]}"
                + ('...' if len(missing) > 5 else '')
            )

        self.classes      = ['__segmentation__']
        self.class_to_idx = {'__segmentation__': 0}

    def __len__(self):
        return len(self.filenames)

    def __getitem__(self, idx):
        image = np.array(Image.open(path.join(self.images_dir, self.filenames[idx])).convert("RGB"))
        mask  = np.array(Image.open(path.join(self.masks_dir,  self._mask_filenames[idx])))
        if mask.ndim == 3:
            mask = mask[..., 0]

        if self.transform is not None:
            aug   = self.transform(image=image, mask=mask)
            image = aug["image"]
            mask  = aug["mask"].long()
        else:
            mask = torch.from_numpy(mask).long()

        return image, mask


# ── DinoUperNet ───────────────────────────────────────────────────────────────

class DinoUperNet(IModel):

    @property
    def IsTraining(self):
        return self._isTraining

    @IsTraining.setter
    def IsTraining(self, value):
        self._isTraining = value

    @property
    def IsStopTraining(self):
        return self._isStopTraining

    @IsStopTraining.setter
    def IsStopTraining(self, value):
        self._isStopTraining = value

    def __init__(self):
        self.cfg               = TrainingConfig()
        self._isTraining       = False
        self._isStopTraining   = False
        self.StopTrainingEvent = Event()
        self.model             = None
        self.callbacks         = None
        self.ClassesNumber     = 0
        self.ProcessName       = ""
        self.Device            = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._log_file         = None

    def _write_log(self, msg: str):
        print(msg)
        if self._log_file:
            self._log_file.write(msg + "\n")
            self._log_file.flush()

    @staticmethod
    def _count_params(model):
        total     = sum(p.numel() for p in model.parameters())
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        return trainable, total

    @staticmethod
    def _update_confusion(preds, labels, num_classes, ignore_index, hist):
        mask  = labels != ignore_index
        p     = preds[mask].cpu()
        l     = labels[mask].cpu()
        hist += torch.bincount(l * num_classes + p, minlength=num_classes ** 2).reshape(num_classes, num_classes)

    @staticmethod
    def _miou_from_hist(hist: torch.Tensor) -> float:
        inter = hist.diag().float()
        union = (hist.sum(1) + hist.sum(0) - hist.diag()).float()
        valid = union > 0
        return (inter[valid] / union[valid]).mean().item() * 100.0 if valid.any() else 0.0

    @staticmethod
    def _pixel_acc_from_hist(hist: torch.Tensor) -> float:
        return (hist.diag().sum() / hist.sum().clamp(min=1)).item() * 100.0

    @staticmethod
    def _compute_class_weights(loader: DataLoader, num_classes: int,
                               ignore_index: int, device: torch.device,
                               max_samples: int = 500) -> torch.Tensor:
        freq    = torch.zeros(num_classes, dtype=torch.float64)
        scanned = 0
        for _, labels in loader:
            flat = labels.reshape(-1)
            mask = flat != ignore_index
            flat = flat[mask]
            if flat.numel() > 0:
                freq += torch.bincount(flat.long(), minlength=num_classes)[:num_classes].double()
            scanned += labels.shape[0]
            if scanned >= max_samples:
                break
        freq_nonzero = freq[freq > 0]
        if len(freq_nonzero) == 0:
            return torch.ones(num_classes, device=device)
        median  = freq_nonzero.median()
        weights = torch.where(freq > 0, median / freq.clamp(min=1), torch.zeros_like(freq))
        weights = weights / weights.sum() * num_classes
        return weights.float().to(device)

    # ── Load weight ───────────────────────────────────────────────────
    def LoadWeight(self, weightPath: str = None):
        model_params = self.cfg.get_by_category("ModelParams")
        arch         = model_params["Architecture"]
        backbone_name, feature_dim, layer_indices, scale_factors = _ARCH_LAYER_MAP.get(
            arch, ("dinov2_vits14", 384, [2, 5, 8, 11], [2.0, 1.0, 0.5, 0.25])
        )
        model = _DINOv2Segmentation(
            num_classes      = self.ClassesNumber,
            backbone_name    = backbone_name,
            feature_dim      = feature_dim,
            decoder_channels = model_params["DecoderChannels"],
            dropout          = model_params["Dropout"],
            pool_scales      = model_params["PoolScales"],
            layer_indices    = layer_indices,
            scale_factors    = scale_factors,
        )
        if weightPath and path.exists(weightPath):
            state_dict = torch.load(weightPath, map_location=self.Device)
            cleaned    = {(k[7:] if k.startswith('module.') else k): v for k, v in state_dict.items()}
            model.load_state_dict(cleaned, strict=False)
        model.to(self.Device)
        return model

    # ── Augmentation ──────────────────────────────────────────────────
    def PrepareAugmentation(self):
        if not ALBUMENTATIONS_AVAILABLE:
            raise RuntimeError("albumentations is required: pip install albumentations")

        aug_params   = self.cfg.get_by_category("Augmentation")
        model_params = self.cfg.get_by_category("ModelParams")
        imageSize    = model_params["ImageSize"]

        patch_size = 14
        if imageSize % patch_size != 0:
            imageSize = round(imageSize / patch_size) * patch_size
            self._write_log(f"[WARN] ImageSize adjusted to {imageSize} (must be divisible by {patch_size})")

        hue       = aug_params["HueFactor"]
        hue_limit = min(max(abs(hue[0]), abs(hue[1])) if isinstance(hue, (list, tuple)) else abs(hue), 0.5)

        # A.RandomResizedCrop(
        #         size=(imageSize, imageSize),
        #         scale=(aug_params["LongSideScaleMin"], 1.0),
        #         ratio=(0.75, 1.33),
        #     ),

        train_transform = A.Compose([
            A.Resize(imageSize, imageSize),
            A.HorizontalFlip(p=aug_params["HFlipP"]),
            A.ColorJitter(
                brightness=aug_params["BrightnessFactor"],
                contrast=aug_params["ContrastFactor"],
                saturation=aug_params["SaturationFactor"],
                hue=hue_limit,
                p=aug_params["ColorJitterP"],
            ),
            A.GaussianBlur(blur_limit=aug_params["GaussianBlurLimit"], p=aug_params["GaussianBlurP"]),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225], max_pixel_value=255.0),
            ToTensorV2(),
        ], is_check_shapes=False)

        val_transform = A.Compose([
            A.Resize(imageSize, imageSize),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225], max_pixel_value=255.0),
            ToTensorV2(),
        ], is_check_shapes=False)

        return train_transform, val_transform

    # ── Optimizer ─────────────────────────────────────────────────────
    def _build_optimizer(self, model: _DINOv2Segmentation, warmup_factor: float = 1.0):
        """
        2 param groups (backbone frozen):
          decode_head  — HeadLR
          aux_head     — HeadLR
        """
        trainParams    = self.cfg.get_by_category("Training")
        backboneParams = self.cfg.get_by_category("Backbone")

        head_lr = backboneParams["HeadLR"] * warmup_factor
        wd      = trainParams["WeightDecay"]

        param_groups = [
             {"params": model.neck.parameters(),        "lr": head_lr, "weight_decay": wd, "name": "neck"},
            {"params": model.decode_head.parameters(), "lr": head_lr, "weight_decay": wd, "name": "decode_head"},
            {"params": model.aux_head.parameters(),    "lr": head_lr, "weight_decay": wd, "name": "aux_head"},
        ]

        opt_type = trainParams["OptimizerType"]
        if opt_type == eOptimizerType.Adam:
            return optim.Adam(param_groups)
        elif opt_type == eOptimizerType.AdamW:
            return optim.AdamW(param_groups)
        elif opt_type == eOptimizerType.SGD:
            return optim.SGD(param_groups, momentum=trainParams.get("Momentum", 0.9))
        elif opt_type == eOptimizerType.RMSprop:
            return optim.RMSprop(param_groups, momentum=trainParams.get("Momentum", 0.9))
        else:
            raise ValueError(f"Unknown OptimizerType: {opt_type}")

    def _set_lr(self, optimizer, head_lr: float):
        for g in optimizer.param_groups:
            g["lr"] = head_lr

    def _get_head_lr(self, optimizer) -> float:
        for g in optimizer.param_groups:
            if g["name"] == "decode_head":
                return g["lr"]
        return 0.0

    def _build_scheduler(self, optimizer, remaining_epochs: int):
        schedulerParams = self.cfg.get_by_category("Scheduler")
        if schedulerParams["Scheduler"] == "cosine":
            sched = CosineAnnealingLR(optimizer, T_max=remaining_epochs, eta_min=schedulerParams["LRMin"])
            self._write_log(f"Scheduler: CosineAnnealingLR (eta_min={schedulerParams['LRMin']}, T_max={remaining_epochs})")
        else:
            sched = MultiStepLR(optimizer, milestones=schedulerParams["LRMilestones"], gamma=schedulerParams["LRGamma"])
            self._write_log(f"Scheduler: MultiStepLR milestones={schedulerParams['LRMilestones']} gamma={schedulerParams['LRGamma']}")
        return sched

    def _apply_warmup_lr(self, optimizer, epoch_idx: int, total_warmup: int,
                         backboneParams: dict, warmupParams: dict):
        """Linear warmup cho head LR."""
        progress = (epoch_idx + 1) / max(total_warmup, 1)
        factor   = warmupParams["WarmupStartFactor"] + (1.0 - warmupParams["WarmupStartFactor"]) * progress
        self._set_lr(optimizer, backboneParams["HeadLR"] * factor)

    # ── Train (public entry) ──────────────────────────────────────────
    def Train(self, callbacks=None):
        try:
            if self.IsTraining:
                return

            self.IsTraining  = True
            self.callbacks   = callbacks
            self.StopTrainingEvent.clear()

            self.Train_Transform, self.Val_Transform = self.PrepareAugmentation()

            modelParams = self.cfg.get_by_category("ModelParams")
            dataParams  = self.cfg.get_by_category("DataPaths")
            trainParams = self.cfg.get_by_category("Training")

            self.ProcessName = (
                f"DinoUperNet_{modelParams['Architecture'].name}"
                f"_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            )

            datasetPath = dataParams["DatasetPath"]
            train_dataset = _SegDataset(path.join(datasetPath, "train"), transform=self.Train_Transform)
            val_dataset   = _SegDataset(path.join(datasetPath, "val"),   transform=self.Val_Transform)

            self.ClassesNumber = modelParams["NumClasses"] if modelParams["NumClasses"] > 1 else len(train_dataset.classes)

            self.TrainLoader = DataLoader(
                train_dataset, batch_size=trainParams["BatchSize"],
                shuffle=True, num_workers=4, pin_memory=True,
            )
            self.ValLoader = DataLoader(
                val_dataset, batch_size=trainParams["BatchSize"],
                shuffle=False, num_workers=4, pin_memory=True,
            )

            project_name = modelParams.get("Project", "TrainResult")
            saveFolder   = path.join(project_name, self.ProcessName)
            makedirs(saveFolder, exist_ok=True)
            self._log_file = open(path.join(saveFolder, "training.log"), 'w')

            # Backbone frozen — chỉ train decode_head + aux_head
            self.model = self.LoadWeight()
            for p in self.model.backbone.parameters():
                p.requires_grad = False

            self._write_log("Backbone: frozen — training decode_head + aux_head only")

            warmupFactor   = self.cfg.get_by_category("Warmup")["WarmupStartFactor"]
            self.optimizer = self._build_optimizer(self.model, warmup_factor=warmupFactor)

            Thread(target=self.__train_model, name="TrainThread", daemon=True).start()

        except Exception as ex:
            self.IsTraining = False
            msg = f"Error while preparing training: {ex}"
            print(msg)
            if callbacks:
                callbacks("Error", msg)

    # ── Training loop ─────────────────────────────────────────────────
    def __train_model(self):
        try:
            trainParams   = self.cfg.get_by_category("Training")
            warmupParams  = self.cfg.get_by_category("Warmup")
            backboneParams = self.cfg.get_by_category("Backbone")

            num_epochs          = trainParams["Epochs"]
            early_stop_patience = trainParams["Patience"]
            warmupEpochs        = warmupParams["WarmupEpochs"]
            ignore_index        = 255
            aux_loss_weight     = 0.4

            self._write_log("Computing class weights (median frequency balancing)...")
            class_weights = self._compute_class_weights(
                self.TrainLoader, self.ClassesNumber, ignore_index, self.Device
            )
            criterion = nn.CrossEntropyLoss(weight=class_weights, ignore_index=ignore_index)
            self._write_log(f"Class weights: min={class_weights.min():.4f} max={class_weights.max():.4f}")

            self._train_loss_history    = []
            self._val_loss_history      = []
            self._train_pix_acc_history = []
            self._val_pix_acc_history   = []
            self._train_miou_history    = []
            self._val_miou_history      = []

            trainable, total = self._count_params(self.model)
            self._write_log(f"Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}% trainable)")

            best_val_miou      = 0.0
            early_stop_counter = 0

            save_folder = path.join(
                self.cfg.get_by_category("ModelParams").get("Project", "TrainResult"),
                self.ProcessName
            )

            # Build scheduler — nếu warmup=0 thì build ngay, nếu không thì sau warmup
            scheduler = None
            if warmupEpochs == 0:
                self._set_lr(self.optimizer, backboneParams["HeadLR"])
                scheduler = self._build_scheduler(self.optimizer, num_epochs)
                self._write_log("No warmup — scheduler started from epoch 0")

            for epoch in range(num_epochs):
                self._write_log(f"\nEpoch {epoch+1}/{num_epochs}")
                self._write_log('-' * 40)

                # ── Train ─────────────────────────────────────────────
                self.model.train()
                running_loss = 0.0
                train_hist   = torch.zeros(self.ClassesNumber, self.ClassesNumber, dtype=torch.long)

                loader = (tqdm(self.TrainLoader, desc=f"Epoch {epoch+1} [Train]", leave=False)
                          if TQDM_AVAILABLE else self.TrainLoader)

                for images, labels in loader:
                    images = images.to(self.Device)
                    labels = labels.to(self.Device).long()

                    self.optimizer.zero_grad()
                    main_logits, aux_logits = self.model(images)
                    loss = criterion(main_logits, labels) + aux_loss_weight * criterion(aux_logits, labels)
                    loss.backward()
                    self.optimizer.step()

                    running_loss += loss.item() * images.size(0)
                    self._update_confusion(main_logits.detach().argmax(1), labels,
                                           self.ClassesNumber, ignore_index, train_hist)
                    del main_logits, aux_logits

                del loader

                epoch_loss    = running_loss / len(self.TrainLoader.dataset)
                epoch_miou    = self._miou_from_hist(train_hist)
                epoch_pix_acc = self._pixel_acc_from_hist(train_hist)
                self._write_log(f"Train | Loss: {epoch_loss:.4f} | Pix Acc: {epoch_pix_acc:.2f}% | mIoU: {epoch_miou:.2f}%")
                self._train_loss_history.append(epoch_loss)
                self._train_pix_acc_history.append(epoch_pix_acc)
                self._train_miou_history.append(epoch_miou)

                # ── Validate ──────────────────────────────────────────
                self.model.eval()
                val_loss = 0.0
                val_hist = torch.zeros(self.ClassesNumber, self.ClassesNumber, dtype=torch.long)

                loader = (tqdm(self.ValLoader, desc=f"Epoch {epoch+1} [Val]", leave=False)
                          if TQDM_AVAILABLE else self.ValLoader)

                with torch.no_grad():
                    for images, labels in loader:
                        images = images.to(self.Device)
                        labels = labels.to(self.Device).long()
                        logits = self.model(images)
                        val_loss += criterion(logits, labels).item() * images.size(0)
                        self._update_confusion(logits.detach().argmax(1), labels,
                                               self.ClassesNumber, ignore_index, val_hist)
                        del logits

                del loader

                epoch_val_loss    = val_loss / len(self.ValLoader.dataset)
                epoch_val_miou    = self._miou_from_hist(val_hist)
                epoch_val_pix_acc = self._pixel_acc_from_hist(val_hist)
                self._write_log(f"Val   | Loss: {epoch_val_loss:.4f} | Pix Acc: {epoch_val_pix_acc:.2f}% | mIoU: {epoch_val_miou:.2f}%")
                self._val_loss_history.append(epoch_val_loss)
                self._val_pix_acc_history.append(epoch_val_pix_acc)
                self._val_miou_history.append(epoch_val_miou)

                if self.callbacks:
                    self.callbacks("Info",
                        f"Epoch {epoch+1}/{num_epochs} | "
                        f"Val Loss: {epoch_val_loss:.4f} | "
                        f"Val Pix Acc: {epoch_val_pix_acc:.2f}% | "
                        f"Val mIoU: {epoch_val_miou:.2f}%"
                    )

                if (epoch + 1) % 5 == 0 or epoch == 0:
                    self._plot_results(save_folder)
                    self._plot_pixel_accuracy(save_folder)
                    self._plot_miou(save_folder)

                # ── Best model + Early stopping ───────────────────────
                if epoch_val_miou > best_val_miou:
                    best_val_miou = epoch_val_miou
                    self.__saveModel(self.model, "best.pth")
                    self._write_log(f"Val mIoU improved: {best_val_miou:.2f}% — saved best.pth")
                    early_stop_counter = 0
                else:
                    early_stop_counter += 1
                    self._write_log(f"No improvement {early_stop_counter}/{early_stop_patience}")
                    if self.callbacks:
                        self.callbacks("Info", f"No improvement {early_stop_counter}/{early_stop_patience}")
                    if early_stop_patience > 0 and early_stop_counter >= early_stop_patience:
                        self._write_log(f"Early stopping at epoch {epoch+1}")
                        if self.callbacks:
                            self.callbacks("Info", f"Early stopping at epoch {epoch+1}")
                        break

                # ── LR schedule ───────────────────────────────────────
                if warmupEpochs > 0 and epoch < warmupEpochs:
                    self._apply_warmup_lr(self.optimizer, epoch, warmupEpochs, backboneParams, warmupParams)

                    if epoch + 1 == warmupEpochs:
                        # Warmup xong — reset về target LR rồi build scheduler
                        self._set_lr(self.optimizer, backboneParams["HeadLR"])
                        remaining = max(num_epochs - epoch - 1, 1)
                        scheduler = self._build_scheduler(self.optimizer, remaining)
                        self._write_log(f"Warmup done — scheduler started (remaining={remaining})")

                elif scheduler is not None:
                    scheduler.step()
                    self._write_log(f"LR — head: {self._get_head_lr(self.optimizer):.2e}")

                if self.IsStopTraining:
                    break

                torch.cuda.empty_cache()
                gc.collect()

            # ── Done ──────────────────────────────────────────────────
            msg = f"Training done | Best Val mIoU: {best_val_miou:.2f}%"
            self._write_log(msg)
            if self.callbacks:
                self.callbacks("Info", msg)

            self.__saveModel(self.model, "last.pth")

            if self._log_file:
                self._log_file.close()
                self._log_file = None

            self._plot_results(save_folder)
            self._plot_pixel_accuracy(save_folder)
            self._plot_miou(save_folder)

            model_params  = self.cfg.get_by_category("ModelParams")
            weightsFolder = path.join(save_folder, "Weights")
            for weight_file in ["best.pth", "last.pth"]:
                weight_path = path.join(weightsFolder, weight_file)
                if path.exists(weight_path):
                    self.Export(weight_path, eModelExportType.ONNX, model_params["ImageSize"])

            if self.model and hasattr(self.model, 'cpu'):
                self.model.cpu()
            del self.model
            self.model = None
            torch.cuda.empty_cache()

            self.IsTraining = False
            self.StopTrainingEvent.set()

        except Exception as ex:
            import traceback
            self._write_log(f"Training error: {ex}\n{traceback.format_exc()}")
            if self.callbacks:
                self.callbacks("Error", f"Training error: {ex}")
            self.IsTraining = False
            self.StopTrainingEvent.set()

    # ── Save ──────────────────────────────────────────────────────────
    def __saveModel(self, model, modelName: str):
        save_path = path.join(
            self.cfg.get_by_category("ModelParams").get("Project", "TrainResult"),
            self.ProcessName, "Weights", modelName
        )
        makedirs(path.dirname(save_path), exist_ok=True)
        torch.save(model.state_dict(), save_path)

    # ── Plots ─────────────────────────────────────────────────────────
    def _plot_results(self, save_dir: str):
        if not getattr(self, '_train_loss_history', None):
            return
        fig, ax = plt.subplots(figsize=(10, 4))
        e = range(1, len(self._train_loss_history) + 1)
        ax.plot(e, self._train_loss_history, 'b-o', label='Train Loss')
        if getattr(self, '_val_loss_history', None):
            ax.plot(e, self._val_loss_history, 'r-o', label='Val Loss')
        ax.set_xlabel('Epoch'); ax.set_ylabel('Loss'); ax.legend(); ax.grid(True)
        fig.suptitle(self.ProcessName)
        fig.savefig(path.join(save_dir, 'results.png'), dpi=150, bbox_inches='tight')
        plt.close('all')

    def _plot_pixel_accuracy(self, save_dir: str):
        if not getattr(self, '_train_pix_acc_history', None):
            return
        fig, ax = plt.subplots(figsize=(10, 4))
        e = range(1, len(self._train_pix_acc_history) + 1)
        ax.plot(e, self._train_pix_acc_history, 'b-o', label='Train Pix Acc')
        if getattr(self, '_val_pix_acc_history', None):
            ax.plot(e, self._val_pix_acc_history, 'r-o', label='Val Pix Acc')
        ax.set_xlabel('Epoch'); ax.set_ylabel('Pixel Accuracy (%)'); ax.legend(); ax.grid(True)
        fig.suptitle(self.ProcessName)
        fig.savefig(path.join(save_dir, 'pixel_accuracy.png'), dpi=150, bbox_inches='tight')
        plt.close('all')

    def _plot_miou(self, save_dir: str):
        if not getattr(self, '_train_miou_history', None):
            return
        fig, ax = plt.subplots(figsize=(10, 4))
        e = range(1, len(self._train_miou_history) + 1)
        ax.plot(e, self._train_miou_history, 'b-o', label='Train mIoU')
        if getattr(self, '_val_miou_history', None):
            ax.plot(e, self._val_miou_history, 'r-o', label='Val mIoU')
        ax.set_xlabel('Epoch'); ax.set_ylabel('mIoU (%)'); ax.legend(); ax.grid(True)
        fig.suptitle(self.ProcessName)
        fig.savefig(path.join(save_dir, 'miou.png'), dpi=150, bbox_inches='tight')
        plt.close('all')

    # ── Export ────────────────────────────────────────────────────────
    def Export(self, pathToPytorchModel: str, exportType: eModelExportType, exportImageSize: int = None):
        tempModel = None
        try:
            self.ClassesNumber = self.ClassesNumber or 2
            tempModel = self.LoadWeight(pathToPytorchModel)

            match exportType:
                case eModelExportType.ONNX:
                    model_params = self.cfg.get_by_category("ModelParams")
                    image_size   = exportImageSize or model_params["ImageSize"]
                    patch_size   = 14
                    if image_size % patch_size != 0:
                        image_size = round(image_size / patch_size) * patch_size
                        print(f"[WARN] image_size adjusted to {image_size}")

                    onnx_path = path.splitext(pathToPytorchModel)[0] + ".onnx"
                    print("=" * 60)
                    print(f"ONNX EXPORT  input=(1,3,{image_size},{image_size})  opset=17")
                    print("=" * 60)

                    wrapper = _ONNXWrapper(tempModel)
                    dummy   = torch.randn(1, 3, image_size, image_size, device=self.Device)

                    with torch.no_grad():
                        torch.onnx.export(
                            wrapper, dummy, onnx_path,
                            opset_version=17, input_names=["input"], output_names=["output"],
                            dynamic_axes=None, do_constant_folding=True, export_params=True,
                        )

                    print(f"[OK] Saved: {onnx_path}  ({os.path.getsize(onnx_path)/1024/1024:.1f} MB)")

                    try:
                        import onnx
                        onnx.checker.check_model(onnx.load(onnx_path))
                        print("[OK] ONNX structure valid")
                    except ImportError:
                        print("[SKIP] onnx not installed")
                    except Exception as e:
                        print(f"[WARN] ONNX check: {e}")

                    try:
                        import onnxruntime as ort
                        with torch.no_grad():
                            torch_out = wrapper(dummy).cpu().numpy()
                        providers = (["CUDAExecutionProvider", "CPUExecutionProvider"]
                                     if "CUDAExecutionProvider" in ort.get_available_providers()
                                     else ["CPUExecutionProvider"])
                        sess     = ort.InferenceSession(onnx_path, providers=providers)
                        onnx_out = sess.run(None, {sess.get_inputs()[0].name: dummy.cpu().numpy()})[0]
                        mismatch = (torch_out != onnx_out).sum()
                        print(f"Verification: {mismatch}/{torch_out.size} pixels mismatch "
                              f"({'PASS' if mismatch == 0 else 'WARN'})")
                        del sess
                    except ImportError:
                        print("[SKIP] onnxruntime not installed")
                    except Exception as e:
                        print(f"[WARN] Verification: {e}")

                    try:
                        import onnxsim, onnx as ox
                        simp, ok = onnxsim.simplify(ox.load(onnx_path), check_n=3, perform_optimization=True)
                        if ok:
                            backup = onnx_path.replace(".onnx", "_original.onnx")
                            os.replace(onnx_path, backup)
                            ox.save(simp, onnx_path)
                            print(f"[OK] Simplified: {os.path.getsize(backup)/1024/1024:.1f}MB "
                                  f"→ {os.path.getsize(onnx_path)/1024/1024:.1f}MB")
                    except ImportError:
                        print("[SKIP] onnx-simplifier not installed")
                    except Exception as e:
                        print(f"[WARN] Simplification: {e}")

                    print("[DONE] ONNX export complete")

                case eModelExportType.OpenVINO:
                    if not OPENVINO_AVAILABLE:
                        raise RuntimeError("OpenVINO not installed: pip install openvino")
                    model_params = self.cfg.get_by_category("ModelParams")
                    _, feature_dim, _, _ = _ARCH_LAYER_MAP.get(
                        model_params["Architecture"], ("", 384, None, None)
                    )
                    image_size = exportImageSize or model_params["ImageSize"]
                    export_head = _UPerHead(
                        in_channels=feature_dim, num_classes=self.ClassesNumber,
                        channels=model_params["DecoderChannels"],
                        dropout=model_params["Dropout"],
                        pool_scales=model_params["PoolScales"],
                    )
                    export_head.load_state_dict(tempModel.decode_head.state_dict(), strict=True)
                    export_head.eval()
                    pH, pW = image_size // 14, image_size // 14
                    dummy  = torch.randn(1, feature_dim * 4, pH, pW)
                    base   = path.splitext(pathToPytorchModel)[0]
                    onnx_p = base + ".onnx"
                    torch.onnx.export(
                        export_head, dummy, onnx_p,
                        input_names=["features"], output_names=["logits"],
                        dynamic_axes={"features": {0: "batch"}, "logits": {0: "batch"}},
                        opset_version=17,
                    )
                    ov_model = ov.convert_model(onnx_p, example_input=dummy)
                    ov.save_model(ov_model, base + ".xml")
                    print(f"[OK] OpenVINO: {base}.xml")
                    del ov_model

                case _:
                    print(f"[WARN] Unknown export type: {exportType}")

        except Exception as ex:
            print(f"Export error: {ex}")
            if self.callbacks:
                self.callbacks("Error", f"Export error: {ex}")
            raise
        finally:
            if tempModel and hasattr(tempModel, 'cpu'):
                tempModel.cpu()
            del tempModel
            torch.cuda.empty_cache()

    # ── Stop / Predict ────────────────────────────────────────────────
    def StopTraining(self):
        self.IsStopTraining = True
        self.StopTrainingEvent.wait(timeout=120)
        self.IsStopTraining = False

    def Predict(self, img) -> np.ndarray:
        if self.model is None:
            raise RuntimeError("Model not loaded. Call LoadWeight first.")
        self.model.eval()
        with torch.no_grad():
            if isinstance(img, np.ndarray):
                t = torch.from_numpy(img).permute(2, 0, 1).unsqueeze(0).float() / 255.0
            elif isinstance(img, Image.Image):
                t = torchvision.transforms.functional.to_tensor(img).unsqueeze(0)
            else:
                t = img
            return self.model(t.to(self.Device)).argmax(1).squeeze(0).cpu().numpy()

    def BatchPredict(self, batchImg) -> np.ndarray:
        if self.model is None:
            raise RuntimeError("Model not loaded. Call LoadWeight first.")
        self.model.eval()
        with torch.no_grad():
            if isinstance(batchImg, np.ndarray):
                t = torch.from_numpy(batchImg).permute(0, 3, 1, 2).float() / 255.0
            else:
                t = batchImg
            return self.model(t.to(self.Device)).argmax(1).cpu().numpy()