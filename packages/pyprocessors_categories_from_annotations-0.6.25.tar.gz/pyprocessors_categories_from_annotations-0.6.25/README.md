# pyprocessors_categories_from_annotations

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_categories_from_annotations)](https://github.com/oterrier/pyprocessors_categories_from_annotations/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_categories_from_annotations/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_categories_from_annotations/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_categories_from_annotations)](https://codecov.io/gh/oterrier/pyprocessors_categories_from_annotations)
[![docs](https://img.shields.io/readthedocs/pyprocessors_categories_from_annotations)](https://pyprocessors_categories_from_annotations.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_categories_from_annotations)](https://pypi.org/project/pyprocessors_categories_from_annotations/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_categories_from_annotations)](https://pypi.org/project/pyprocessors_categories_from_annotations/)

CategoriesFromAnnotations annotations coming from different annotators

## Installation

You can simply `pip install pyprocessors_categories_from_annotations`.

## Developing

### Pre-requesites

You will need to install `uv` (for managing the virtual environment and running tests):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_categories_from_annotations
```

### Running the test suite

You can run the full test suite with:

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

You can build the HTML documentation with:

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
