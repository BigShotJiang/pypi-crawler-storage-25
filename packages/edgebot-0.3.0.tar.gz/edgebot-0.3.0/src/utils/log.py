"""
Структурированное логирование для Cloudflare Workers.

Cloudflare Workers Logs различает уровни записей по источнику:
  - print()          -> level = "log"
  - console.debug()  -> level = "debug"
  - console.info()   -> level = "info"
  - console.warn()   -> level = "warn"
  - console.error()  -> level = "error"

Чтобы в логах удобно фильтровать по уровню и сразу видеть контекст,
сообщения формируются как JSON вида:

    {"msg": "...", "src": "edgebot.xxx", "<key>": <value>, ...}

Для локального запуска (без js.console) есть fallback на print с префиксом.
"""

from json import dumps
from typing import Any

from js import console as _console  # type: ignore[attr-defined]
_HAS_CONSOLE = True


def _format(message: str, source: str, fields: dict[str, Any]) -> str:
    try:
        payload: dict[str, Any] = {"msg": message, "src": source}
        payload.update(fields)
        return dumps(payload, default=repr, ensure_ascii=False)
    except Exception:
        return dumps({"msg": message, "src": source, "_dump_error": True})


def _emit(level: str, message: str, source: str, **fields: Any) -> None:
    body = _format(message, source, fields)
    method = getattr(_console, level, None) or _console.log
    method(body)


def debug(message: str, *, source: str = "edgebot", **fields: Any) -> None:
    """Диагностическое сообщение (скрыто по умолчанию в production)."""
    _emit("debug", message, source, **fields)


def info(message: str, *, source: str = "edgebot", **fields: Any) -> None:
    """Информационное сообщение о нормальном ходе работы."""
    _emit("info", message, source, **fields)


def warn(message: str, *, source: str = "edgebot", **fields: Any) -> None:
    """Предупреждение: штатно, но требует внимания."""
    _emit("warn", message, source, **fields)


def error(message: str, *, source: str = "edgebot", **fields: Any) -> None:
    """Ошибка: операция не выполнилась."""
    _emit("error", message, source, **fields)


__all__ = ["debug", "info", "warn", "error"]
