"""
Компиляция callback-паттернов UIComponent в регулярные выражения.

Паттерн экрана — строка вида "toggle", "del:{user_id}", "page:{num}". Вместе с
префиксом компонента (например, "prof") она превращается в regex с именованными
группами: "^prof:del:(?P<user_id>[^:]+)$". Этот regex используется в
UIComponent.handle_callback для матчинга и автоматического извлечения параметров
из callback_data.

Отдельно поддерживается fallback-паттерн "*": он срабатывает ТОЛЬКО если ни
один обычный паттерн компонента не подошёл, но префикс совпал. На компонент
допускается не более одного fallback; нарушение контракта ловится в
collect_routes и выбрасывает UIError.
"""

import re
from typing import Any, Callable, NamedTuple, Optional

from ..exceptions import UIError


_PLACEHOLDER_RE = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)\}")
_PATTERN_ATTR = "__ui_pattern__"


class Route(NamedTuple):
    """Скомпилированный роут одного метода-хендлера компонента."""

    regex: re.Pattern
    method_name: str
    is_fallback: bool


def compile_pattern(prefix: str, pattern: str) -> re.Pattern:
    """
    Собрать регулярку для callback_data.

    Правила:
      - "*" → ловит всё в рамках префикса: ^{prefix}:.+$.
        Требуется ненулевой остаток, иначе мы бы сматчили чистый "{prefix}:",
        что маловероятно и обычно означает ошибку на стороне вызывающего.
      - иначе литералы экранируются через re.escape, а {name} превращается
        в именованную группу (?P<name>[^:]+). Это намеренно запрещает
        двоеточие внутри значения параметра — структура callback_data всегда
        разбирается по ":".

    Args:
        prefix: __prefix__ компонента (не пустой).
        pattern: строка из декоратора @UIComponent.callback(...).

    Returns:
        Скомпилированный re.Pattern.
    """
    if not prefix:
        raise UIError("compile_pattern: prefix must be non-empty")
    if pattern == "*":
        return re.compile(rf"^{re.escape(prefix)}:.+$")

    parts: list[str] = []
    last = 0
    for match in _PLACEHOLDER_RE.finditer(pattern):
        parts.append(re.escape(pattern[last:match.start()]))
        parts.append(f"(?P<{match.group(1)}>[^:]+)")
        last = match.end()
    parts.append(re.escape(pattern[last:]))
    body = "".join(parts)
    return re.compile(rf"^{re.escape(prefix)}:{body}$")


def collect_routes(cls: type) -> tuple[list[Route], Optional[Route]]:
    """
    Пройтись по классу, собрать все методы, помеченные @UIComponent.callback.

    Возвращает пару (обычные роуты, fallback-роут или None). Fallback-роут —
    это метод, помеченный паттерном "*"; допускается не более одного.

    Порядок обычных роутов — в порядке определения методов в классе (через
    dir() мы теряем этот порядок, поэтому используем cls.__dict__ снизу вверх
    по MRO, начиная с ближайших предков).

    Args:
        cls: класс-наследник UIComponent.

    Returns:
        (список обычных Route, опционально один fallback Route).

    Raises:
        UIError: если в классе определено больше одного fallback-паттерна.
    """
    prefix = getattr(cls, "__prefix__", "")
    if not prefix:
        return [], None

    seen: set[str] = set()
    routes: list[Route] = []
    fallback: Optional[Route] = None

    # Обходим MRO от предков к потомку, чтобы переопределения в подклассе
    # переписывали одноимённые методы предка, а порядок определения
    # сохранялся.
    for klass in reversed(cls.__mro__):
        for name, attr in klass.__dict__.items():
            if not callable(attr):
                continue
            pattern = getattr(attr, _PATTERN_ATTR, None)
            if pattern is None:
                continue
            if name in seen:
                continue
            seen.add(name)

            regex = compile_pattern(prefix, pattern)
            is_fallback = pattern == "*"
            route = Route(regex=regex, method_name=name, is_fallback=is_fallback)

            if is_fallback:
                if fallback is not None:
                    raise UIError(
                        f"{cls.__name__}: only one fallback '*' callback is allowed "
                        f"per component (got '{fallback.method_name}' and '{name}')"
                    )
                fallback = route
            else:
                routes.append(route)

    return routes, fallback


def mark_pattern(func: Callable[..., Any], pattern: str) -> Callable[..., Any]:
    """
    Технический хелпер: проставить функции атрибут __ui_pattern__. Используется
    декоратором UIComponent.callback. Вынесен отдельно, чтобы инкапсулировать
    имя атрибута в этом модуле.
    """
    setattr(func, _PATTERN_ATTR, pattern)
    return func
