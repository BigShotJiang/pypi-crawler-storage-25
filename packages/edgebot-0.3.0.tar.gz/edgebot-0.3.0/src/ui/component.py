"""
Базовый класс атомарного UI-экрана.

UIComponent инкапсулирует три вещи:
  - контроллер: методы, реагирующие на нажатия inline-кнопок (через
    декоратор @UIComponent.callback). Маршрутизация строится автоматически
    по паттернам callback_data в момент создания класса
    (__init_subclass__).
  - вью: дефолтные ключи реестров (prompt/markup) или inline-шаблон text.
  - поведение: методы send() и update() собирают промпт + клавиатуру и
    отправляют/редактируют сообщение через Context.

Компоненты — синглтоны, состояние никогда не живёт в инстансе. Все данные
экрана тянутся из Context (KV, реестры пользователей и т.д.) и из
параметров, извлечённых из callback_data.
"""

from typing import Any, Callable, ClassVar, Optional, TYPE_CHECKING, Union

from ..exceptions import UIError
from ..keyboard import InlineKeyboard
from ..utils import log
from .prompts import Prompt
from .routing import Route, collect_routes, mark_pattern

if TYPE_CHECKING:
    from ..context import Context


_NOT_MODIFIED_MARKER = "message is not modified"


class UIComponent:
    """
    Базовый класс UI-экрана. Наследники задают:
      - __prefix__: уникальный префикс для callback_data (обязательно);
      - prompt / markup: ключи в PromptRegistry / KeyboardRegistry (опционально);
      - text: inline-шаблон как шорткат вместо регистрации промпта (опционально);
      - методы, декорированные @UIComponent.callback(pattern);
      - метод open(ctx, **kwargs) — точка входа для первичного рендера экрана.

    Пример:

        class ProfileScreen(UIComponent):
            __prefix__ = "profile"
            prompt = "profile_main"
            markup = "profile_main"

            async def open(self, ctx: Context) -> None:
                user_id = ctx.from_user["id"]
                user = await ctx.users.get(user_id)
                kw = {"username": user["username"], "is_active": user["is_active"]}
                await self.send(ctx, prompt_kwargs=kw, markup_kwargs=kw)

            @UIComponent.callback("toggle")
            async def on_toggle(self, ctx: Context) -> None:
                ...
    """

    __prefix__: ClassVar[str] = ""
    text: ClassVar[str] = ""
    prompt: ClassVar[Optional[str]] = None
    markup: ClassVar[Optional[str]] = None

    _routes: ClassVar[list[Route]] = []
    _fallback_route: ClassVar[Optional[Route]] = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if not cls.__prefix__:
            raise UIError(f"{cls.__name__}: __prefix__ must be defined and non-empty")
        cls._routes, cls._fallback_route = collect_routes(cls)

    @classmethod
    def callback(cls, pattern: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """
        Декоратор для привязки метода к паттерну callback_data.

        Паттерн пишется БЕЗ префикса компонента — префикс приклеивается
        автоматически. Внутри паттерна можно использовать переменные
        {name}: они превратятся в именованные группы regex и будут переданы
        в метод как kwargs с тем же именем.

        Специальный паттерн "*" — fallback: срабатывает, если префикс совпал,
        но никакой другой паттерн не подошёл. На компонент допускается не
        более одного fallback.

        Args:
            pattern: строковый паттерн (например, "toggle", "del:{user_id}", "*").
        """
        if not pattern:
            raise UIError("UIComponent.callback: pattern must be non-empty")

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            return mark_pattern(func, pattern)

        return decorator

    async def open(self, ctx: "Context", **kwargs: Any) -> None:
        """
        Первичная точка входа в экран. Наследник обязан переопределить.

        Обычно внутри:
          1) вытягиваем данные из KV / реестров;
          2) вызываем self.send(ctx, prompt_kwargs=..., markup_kwargs=...).

        Args:
            ctx: контекст апдейта Telegram.
            **kwargs: произвольные параметры открытия (например, user_id для
                админских экранов).
        """
        raise NotImplementedError(
            f"{type(self).__name__}.open() must be implemented"
        )

    def _resolve_prompt(
        self,
        ctx: "Context",
        prompt: Union[str, Prompt, None],
        prompt_kwargs: Optional[dict[str, Any]],
    ) -> Prompt:
        """
        Определить источник промпта и получить объект Prompt.

        Приоритет:
          1) аргумент prompt (str → реестр; Prompt → используем как есть);
          2) self.prompt (ключ в реестре);
          3) self.text (inline-шаблон → оборачиваем в Prompt).
        """
        kwargs = prompt_kwargs or {}

        if isinstance(prompt, Prompt):
            return prompt
        if isinstance(prompt, str):
            return ctx.prompts.get(prompt, **kwargs)
        if self.prompt:
            return ctx.prompts.get(self.prompt, **kwargs)
        if self.text:
            return Prompt(self.text)

        raise UIError(
            f"{type(self).__name__}: no prompt source — set class attr `prompt` "
            f"(key in PromptRegistry) or `text` (inline template), or pass `prompt=`"
        )

    def _resolve_markup(
        self,
        ctx: "Context",
        markup: Union[str, InlineKeyboard, None],
        markup_kwargs: Optional[dict[str, Any]],
    ) -> Optional[InlineKeyboard]:
        """
        Определить источник клавиатуры и вернуть InlineKeyboard (без build()).

        Приоритет:
          1) аргумент markup (str → реестр; InlineKeyboard → используем как есть);
          2) self.markup (ключ в реестре);
          3) None — у экрана нет клавиатуры (допустимо).
        """
        kwargs = markup_kwargs or {}

        if isinstance(markup, InlineKeyboard):
            return markup
        if isinstance(markup, str):
            return ctx.keyboards.get(markup, **kwargs)
        if self.markup:
            return ctx.keyboards.get(self.markup, **kwargs)
        return None

    def _finalize(
        self,
        prompt_obj: Prompt,
        kb_obj: Optional[InlineKeyboard],
        prompt_kwargs: Optional[dict[str, Any]],
    ) -> tuple[str, Optional[dict[str, Any]]]:
        """Собрать финальный текст и reply_markup для передачи в Context."""
        text = prompt_obj.render(**(prompt_kwargs or {}))
        reply_markup = kb_obj.build(prefix=self.__prefix__) if kb_obj is not None else None
        return text, reply_markup

    async def send(
        self,
        ctx: "Context",
        *,
        prompt: Union[str, Prompt, None] = None,
        markup: Union[str, InlineKeyboard, None] = None,
        prompt_kwargs: Optional[dict[str, Any]] = None,
        markup_kwargs: Optional[dict[str, Any]] = None,
        parse_mode: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Отправить новое сообщение экрана.

        Args:
            ctx: контекст апдейта.
            prompt: явный источник промпта (ключ или Prompt). Если None —
                используется self.prompt либо self.text.
            markup: явный источник клавиатуры (ключ или InlineKeyboard). Если
                None — используется self.markup (если задан).
            prompt_kwargs: данные для фабрики промпта и для Prompt.render.
            markup_kwargs: данные для фабрики клавиатуры.
            parse_mode: режим парсинга текста (по умолчанию — bot.parse_mode).

        Returns:
            Ответ Telegram API.
        """
        prompt_obj = self._resolve_prompt(ctx, prompt, prompt_kwargs)
        kb_obj = self._resolve_markup(ctx, markup, markup_kwargs)
        text, reply_markup = self._finalize(prompt_obj, kb_obj, prompt_kwargs)
        return await ctx.send(text, reply_markup=reply_markup, parse_mode=parse_mode)

    async def update(
        self,
        ctx: "Context",
        *,
        prompt: Union[str, Prompt, None] = None,
        markup: Union[str, InlineKeyboard, None] = None,
        prompt_kwargs: Optional[dict[str, Any]] = None,
        markup_kwargs: Optional[dict[str, Any]] = None,
        parse_mode: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """
        Обновить (edit) текущее сообщение. Если Telegram возвращает ошибку
        "message is not modified" — пишем warning через внутренний логер и
        тихо возвращаем None.

        Остальные ошибки пробрасываются без изменений.
        """
        prompt_obj = self._resolve_prompt(ctx, prompt, prompt_kwargs)
        kb_obj = self._resolve_markup(ctx, markup, markup_kwargs)
        text, reply_markup = self._finalize(prompt_obj, kb_obj, prompt_kwargs)

        try:
            return await ctx.edit_message(
                text,
                reply_markup=reply_markup,
                parse_mode=parse_mode,
            )
        except Exception as exc:
            if _NOT_MODIFIED_MARKER in str(exc):
                log.warn(
                    "UI update skipped: message is not modified",
                    source=f"edgebot.ui.{type(self).__name__}",
                    prefix=self.__prefix__,
                )
                return None
            raise

    def matches(self, callback_data: str) -> bool:
        """Быстрая проверка «это callback нашего компонента?»."""
        return callback_data.startswith(f"{self.__prefix__}:")

    async def handle_callback(self, ctx: "Context") -> bool:
        """
        Попытаться обработать callback_query.

        Последовательность:
          1) отсев по startswith;
          2) first-match по обычным роутам; параметры из regex-групп
             пробрасываются в метод как kwargs;
          3) если ничего не подошло — fallback "*" (если задан).

        Returns:
            True, если что-то сработало и внешний роутер должен остановиться.
        """
        data = ctx.callback_data or ""
        if not data or not self.matches(data):
            return False

        for route in self._routes:
            match = route.regex.match(data)
            if match is None:
                continue
            method = getattr(self, route.method_name)
            await method(ctx, **match.groupdict())
            return True

        if self._fallback_route is not None:
            method = getattr(self, self._fallback_route.method_name)
            await method(ctx)
            return True

        return False
