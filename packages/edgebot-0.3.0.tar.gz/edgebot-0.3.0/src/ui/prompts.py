"""
Реестр промптов (текстовых сообщений) и билдер Prompt.

Промпт — это текстовая «вьюха» экрана, симметрично клавиатуре. Фабрика в
реестре получает данные (prompt_kwargs) и возвращает готовый Prompt.

Ответственность за форматирование распределена так:
  - фабрика отвечает за СТРУКТУРУ (из каких секций собрать Prompt, какие
    условные блоки добавить), но может оставить в тексте плейсхолдеры вида
    {name} — для финальной подстановки.
  - Prompt.render(**kwargs) — финальная подстановка через str.format_map.
    Отсутствующий ключ → KeyError (чтоб не маскировать ошибки разработчика).

UI-движок (UIComponent) передаёт один и тот же dict и в фабрику реестра, и
в render(), чтобы не дублировать данные.
"""

from typing import Any, Callable

from ..exceptions import PromptNotFound
from ._filtering import filter_kwargs


class Prompt:
    """
    Композитный текстовый билдер. Хранит упорядоченный список частей (parts)
    и умеет рендериться в одну строку через "\\n".join + необязательный
    str.format_map.

    Поддерживает композицию: append/prepend позволяют дописать блоки к
    промпту, уже полученному из реестра (шапку/подвал/предупреждение).
    """

    def __init__(self, template: str = "") -> None:
        """
        Args:
            template: стартовый шаблон. Может быть пустым — тогда промпт
                наполняется через append/prepend.
        """
        self._parts: list[str] = []
        if template:
            self._parts.append(template)

    def append(self, text: str) -> "Prompt":
        """Добавить блок в конец."""
        self._parts.append(text)
        return self

    def prepend(self, text: str) -> "Prompt":
        """Добавить блок в начало."""
        self._parts.insert(0, text)
        return self

    def render(self, **kwargs: Any) -> str:
        """
        Склеить части через "\\n" и, если переданы kwargs, прогнать через
        str.format_map. Отсутствующий ключ → KeyError.
        """
        joined = "\n".join(self._parts)
        if not kwargs:
            return joined
        return joined.format_map(kwargs)


class PromptRegistry:
    """
    Реестр фабрик промптов. Фабрика — это обычная функция, декорированная
    через @registry.register("key"), принимающая именованные параметры и
    возвращающая Prompt.

    При вызове get(key, **kwargs) реестр авто-фильтрует kwargs под сигнатуру
    фабрики (строгий контракт: фабрика объявляет только нужные ей параметры,
    лишние тихо отбрасываются). Если фабрика объявляет **kwargs — фильтр
    отключается.
    """

    def __init__(self) -> None:
        self._builders: dict[str, Callable[..., Prompt]] = {}

    def register(self, key: str) -> Callable[[Callable[..., Prompt]], Callable[..., Prompt]]:
        """
        Декоратор регистрации фабрики промпта.

        Args:
            key: строковый ключ, по которому UIComponent будет запрашивать
                промпт через ctx.prompts.get(key, ...).
        """
        def decorator(func: Callable[..., Prompt]) -> Callable[..., Prompt]:
            self._builders[key] = func
            return func
        return decorator

    def has(self, key: str) -> bool:
        """Проверить наличие зарегистрированного промпта."""
        return key in self._builders

    def get(self, key: str, **kwargs: Any) -> Prompt:
        """
        Вызвать фабрику по ключу, вернуть Prompt.

        Args:
            key: ключ промпта.
            **kwargs: данные экрана. Авто-фильтруются по сигнатуре фабрики.

        Returns:
            Готовый к render() объект Prompt.

        Raises:
            PromptNotFound: если ключ не зарегистрирован.
            TypeError: если контракт фабрики нарушен (например, вернула не Prompt).
        """
        builder = self._builders.get(key)
        if builder is None:
            raise PromptNotFound(f"Prompt '{key}' is not registered")

        accepted = filter_kwargs(builder, kwargs)
        result = builder(**accepted)
        if not isinstance(result, Prompt):
            raise TypeError(
                f"Prompt factory '{key}' must return Prompt, got {type(result).__name__}"
            )
        return result
