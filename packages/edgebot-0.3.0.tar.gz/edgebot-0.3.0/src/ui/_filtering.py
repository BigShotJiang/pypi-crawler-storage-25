"""
Вспомогательная интроспекция фабрик для реестров UI-модуля.

Реестры клавиатур и промптов получают один общий dict с данными экрана
(prompt_kwargs / markup_kwargs) и прокидывают его в фабрики-функции. Чтобы
разработчик мог писать фабрики со строгой сигнатурой (без ловушек **kwargs),
но случайно не падать на «лишних» ключах, движок авто-фильтрует входной dict
по объявленным параметрам фабрики.

Контракт фильтрации:
  - если фабрика объявляет **kwargs → фильтрация отключена, фабрике летит всё;
  - иначе → оставляем только те ключи, что объявлены позиционными или
    keyword-параметрами.

Результаты интроспекции кэшируются на уровне функции, чтобы не дёргать
inspect.signature при каждом вызове.
"""

from inspect import Parameter, signature
from typing import Any, Callable, Optional


def _accepted_kwargs(func: Callable[..., Any]) -> Optional[frozenset[str]]:
    """
    Возвращает набор имён параметров, которые объявлены в сигнатуре fun,
    либо None, если функция принимает произвольные **kwargs (тогда фильтр
    отключается, а фабрика отвечает сама за себя).
    """
    cache: Optional[frozenset[str]] = getattr(func, "__edgebot_accepted__", None)
    if cache is not None or getattr(func, "__edgebot_accepted_any__", False):
        if getattr(func, "__edgebot_accepted_any__", False):
            return None
        return cache

    names: set[str] = set()
    accepts_any = False
    for param in signature(func).parameters.values():
        if param.kind is Parameter.VAR_KEYWORD:
            accepts_any = True
            break
        if param.kind in (
            Parameter.POSITIONAL_OR_KEYWORD,
            Parameter.KEYWORD_ONLY,
            Parameter.POSITIONAL_ONLY,
        ):
            names.add(param.name)

    if accepts_any:
        setattr(func, "__edgebot_accepted_any__", True)
        return None

    frozen = frozenset(names)
    setattr(func, "__edgebot_accepted__", frozen)
    return frozen


def filter_kwargs(func: Callable[..., Any], kwargs: dict[str, Any]) -> dict[str, Any]:
    """
    Отфильтровать kwargs под сигнатуру func.

    Если func принимает **kwargs — возвращаем kwargs без изменений. Иначе
    оставляем только ключи, объявленные в сигнатуре. Если kwargs пуст, сразу
    возвращаем пустой dict без интроспекции (дёшево и часто).
    """
    if not kwargs:
        return {}
    accepted = _accepted_kwargs(func)
    if accepted is None:
        return kwargs
    return {k: v for k, v in kwargs.items() if k in accepted}
