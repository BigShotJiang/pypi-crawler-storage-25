"""
Реестр билдеров inline-клавиатур.

Аналогично PromptRegistry: фабрика-функция, декорированная через
@registry.register("key"), принимает именованные параметры и возвращает
именно объект InlineKeyboard (не сырой dict). Финализацию в dict выполняет
UI-движок непосредственно перед отправкой в Telegram (InlineKeyboard.build()
с правильным prefix).

Такая «поздняя» сборка позволяет UI-компоненту добавлять контекстные кнопки
к готовой клавиатуре из реестра через InlineKeyboard.extend().
"""

from typing import Any, Callable

from ..exceptions import KeyboardNotFound
from ..keyboard import InlineKeyboard
from ._filtering import filter_kwargs


class KeyboardRegistry:
    """
    Реестр фабрик InlineKeyboard.

    Контракт:
      - фабрика обязана возвращать InlineKeyboard (не dict);
      - фабрика объявляет только нужные ей параметры. Реестр сам отфильтрует
        лишние из общего dict (строгий контракт + авто-фильтр);
      - если фабрика объявляет **kwargs — фильтр отключается, фабрика
        отвечает сама.
    """

    def __init__(self) -> None:
        self._builders: dict[str, Callable[..., InlineKeyboard]] = {}

    def register(
        self, key: str
    ) -> Callable[[Callable[..., InlineKeyboard]], Callable[..., InlineKeyboard]]:
        """
        Декоратор регистрации билдера.

        Args:
            key: строковый ключ, по которому UIComponent будет запрашивать
                клавиатуру через ctx.keyboards.get(key, ...).
        """
        def decorator(func: Callable[..., InlineKeyboard]) -> Callable[..., InlineKeyboard]:
            self._builders[key] = func
            return func
        return decorator

    def has(self, key: str) -> bool:
        """Проверить наличие зарегистрированной клавиатуры."""
        return key in self._builders

    def get(self, key: str, **kwargs: Any) -> InlineKeyboard:
        """
        Вызвать билдер по ключу и вернуть объект InlineKeyboard.

        Args:
            key: ключ клавиатуры.
            **kwargs: данные экрана. Авто-фильтруются по сигнатуре фабрики.

        Returns:
            InlineKeyboard (не финализированный — без build()).

        Raises:
            KeyboardNotFound: если ключ не зарегистрирован.
            TypeError: если фабрика вернула не InlineKeyboard.
        """
        builder = self._builders.get(key)
        if builder is None:
            raise KeyboardNotFound(f"Keyboard '{key}' is not registered")

        accepted = filter_kwargs(builder, kwargs)
        result = builder(**accepted)
        if not isinstance(result, InlineKeyboard):
            raise TypeError(
                f"Keyboard factory '{key}' must return InlineKeyboard, "
                f"got {type(result).__name__}"
            )
        return result
