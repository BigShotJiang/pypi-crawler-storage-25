"""
Внутренний реестр UI-компонентов, подключённых к Bot.

Хранит компоненты по __prefix__ и обеспечивает уникальность префиксов.
Публичный API наружу не торчит — использование только из Bot.
"""

from typing import Iterator

from ..exceptions import DuplicatePrefixError
from .component import UIComponent


class _UIComponentRegistry:
    """Коллекция UIComponent, индексированная по __prefix__."""

    def __init__(self) -> None:
        self._by_prefix: dict[str, UIComponent] = {}
        self._ordered: list[UIComponent] = []

    def add(self, component: UIComponent) -> None:
        """
        Зарегистрировать компонент. Префикс должен быть уникален в рамках
        одного Bot — при попытке добавить второй компонент с тем же префиксом
        бросается DuplicatePrefixError (и для того же инстанса тоже, чтобы не
        маскировать случайный двойной register_ui).
        """
        prefix = component.__prefix__
        if prefix in self._by_prefix:
            raise DuplicatePrefixError(
                f"UI component with prefix '{prefix}' is already registered: "
                f"{type(self._by_prefix[prefix]).__name__} "
                f"(new: {type(component).__name__})"
            )
        self._by_prefix[prefix] = component
        self._ordered.append(component)

    def __iter__(self) -> Iterator[UIComponent]:
        return iter(self._ordered)

    def __len__(self) -> int:
        return len(self._ordered)
