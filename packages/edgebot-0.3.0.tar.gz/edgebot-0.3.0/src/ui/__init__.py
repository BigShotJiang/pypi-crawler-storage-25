"""
UI-модуль EdgeBot: компоненты-экраны, реестры клавиатур и промптов.

Архитектура (MVC-подобная, адаптированная под stateless Cloudflare Workers):
  - Model: `ctx.users` и другие KV-реестры (edgebot.storage).
  - View:
      * `KeyboardRegistry` → фабрики InlineKeyboard по ключу;
      * `PromptRegistry`   → фабрики Prompt по ключу.
  - Controller: `UIComponent` — атомарный экран с автоматической
    маршрутизацией callback_data по декораторам `@UIComponent.callback`.
"""

from .component import UIComponent
from .keyboards import KeyboardRegistry
from .prompts import Prompt, PromptRegistry

__all__ = [
    "UIComponent",
    "KeyboardRegistry",
    "PromptRegistry",
    "Prompt",
]
