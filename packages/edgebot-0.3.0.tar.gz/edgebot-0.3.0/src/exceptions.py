"""
Базовые исключения EdgeBot SDK.

Все исключения SDK наследуются от EdgeBotError, чтобы прикладной код
мог ловить любую ошибку библиотеки одним except.
"""


class EdgeBotError(Exception):
    """Корень иерархии исключений EdgeBot SDK."""


class UIError(EdgeBotError):
    """Базовая ошибка UI-движка (UIComponent, реестры клавиатур и промптов)."""


class KeyboardNotFound(UIError):
    """Запрошен ключ клавиатуры, которого нет в KeyboardRegistry."""


class PromptNotFound(UIError):
    """Запрошен ключ промпта, которого нет в PromptRegistry."""


class DuplicatePrefixError(UIError):
    """Попытка зарегистрировать в Bot два UI-компонента с одинаковым __prefix__."""
