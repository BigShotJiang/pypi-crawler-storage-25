"""
Классы для создания клавиатур (inline и обычных).

Биндер InlineKeyboard поддерживает концепцию относительных и абсолютных
callback-путей, которая используется UI-движком для позднего связывания
префикса компонента (см. edgebot.ui.component.UIComponent).

Правила для callback_data при вызове build(prefix=...):
  - "foo"       (относительный) + prefix="prof"  -> "prof:foo"
  - "foo"       (относительный) + prefix=None/"" -> "foo" (как есть)
  - "/menu:x"   (абсолютный)    + любой prefix   -> "menu:x" (слэш срезается)
  - url-кнопки префикс не затрагивает.

build() идемпотентен: повторный вызов на том же билдере даёт тот же результат,
исходные словари кнопок не мутируются.
"""

from typing import Any, Optional


class InlineKeyboard:
    """
    Билдер для создания inline-клавиатур под сообщениями.

    Пример использования:
        keyboard = InlineKeyboard()
        keyboard.button('Кнопка 1', callback_data='btn1')
        keyboard.button('Кнопка 2', callback_data='btn2')
        keyboard.row()
        keyboard.button('Ссылка', url='https://example.com')

        await ctx.reply('Выбери действие:', reply_markup=keyboard.build())
    """

    def __init__(self):
        self.keyboard: list[list[dict[str, Any]]] = []
        self.current_row: list[dict[str, Any]] = []

    def button(
        self,
        text: str,
        callback_data: Optional[str] = None,
        url: Optional[str] = None,
    ) -> "InlineKeyboard":
        """
        Добавляет кнопку в текущий ряд.

        Args:
            text: Текст на кнопке.
            callback_data: Данные для callback (взаимоисключающее с url).
                Может быть относительным ("toggle") или абсолютным ("/menu:home").
            url: Ссылка (взаимоисключающее с callback_data).

        Returns:
            self для chaining.
        """
        btn: dict[str, Any] = {"text": text}

        if callback_data:
            btn["callback_data"] = callback_data
        elif url:
            btn["url"] = url
        else:
            raise ValueError("Button must have either callback_data or url")

        self.current_row.append(btn)
        return self

    def row(self) -> "InlineKeyboard":
        """
        Завершает текущий ряд и начинает новый.

        Returns:
            self для chaining.
        """
        if self.current_row:
            self.keyboard.append(self.current_row)
            self.current_row = []
        return self

    def extend(self, other: "InlineKeyboard") -> "InlineKeyboard":
        """
        Добавить ряды другой клавиатуры в конец текущей. Используется для
        композиции: UI-компонент может взять готовую клавиатуру из реестра и
        добавить к ней контекстные элементы.

        Args:
            other: другой InlineKeyboard. Его current_row финализируется.

        Returns:
            self для chaining.
        """
        self.row()
        other.row()
        for row in other.keyboard:
            self.keyboard.append([btn.copy() for btn in row])
        return self

    def build(self, prefix: Optional[str] = None) -> dict[str, Any]:
        """
        Возвращает готовый reply_markup для отправки в Telegram API.

        Args:
            prefix: префикс, который приклеится ко всем относительным
                callback_data. Абсолютные пути (начинающиеся с "/") всегда
                игнорируют префикс, у них лишь срезается ведущий слэш.
                None/"" — префиксация выключена, относительные пути идут как есть.

        Returns:
            Словарь {"inline_keyboard": [[...], ...]}.
        """
        rows = list(self.keyboard)
        if self.current_row:
            rows.append(list(self.current_row))

        normalized_prefix = prefix or ""
        result: list[list[dict[str, Any]]] = []
        for row in rows:
            new_row: list[dict[str, Any]] = []
            for btn in row:
                new_btn = btn.copy()
                cb_data = new_btn.get("callback_data")
                if cb_data is not None:
                    if cb_data.startswith("/"):
                        new_btn["callback_data"] = cb_data[1:]
                    elif normalized_prefix:
                        new_btn["callback_data"] = f"{normalized_prefix}:{cb_data}"
                new_row.append(new_btn)
            result.append(new_row)

        return {"inline_keyboard": result}
