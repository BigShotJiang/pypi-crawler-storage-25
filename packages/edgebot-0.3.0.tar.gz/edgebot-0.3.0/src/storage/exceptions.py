"""
Исключения слоя хранилищ EdgeBot SDK.
"""

from ..exceptions import EdgeBotError


class StorageError(EdgeBotError):
    """Любая ошибка слоя хранилищ."""


class KVError(StorageError):
    """Ошибка операций с KV-хранилищем."""


class UsersError(StorageError):
    """Ошибка реестра пользователей."""


class UserAlreadyExists(UsersError):
    """Попытка create на уже существующий user_id."""
