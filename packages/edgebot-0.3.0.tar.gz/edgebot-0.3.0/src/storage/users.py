"""
Реестр пользователей бота на KV-хранилище.

Ключ: <prefix><user_id>. Значение: JSON dict с произвольными полями
прикладного кода плюс служебные created_at / updated_at.
"""

from typing import Any, Optional, AsyncIterator

from .kv import KVStore
from .exceptions import UserAlreadyExists
from ..utils import now


class UserRegistry:
    """
    Реестр людей поверх KV.
    Ключ: <prefix><user_id>, где user_id — это telegram from_user.id.
    Значение: JSON dict с произвольными полями прикладных данных; поля
    created_at и updated_at (ISO-8601 UTC) дописываются автоматически.
    """

    def __init__(self, kv: Any, *, prefix: str = "user:"):
        """
        Инициализировать реестр.

        Args:
            kv: KV-биндинг из env (например, env.USERS) либо готовый KVStore.
            prefix: префикс ключей внутри неймспейса.
        """
        self._store = kv if isinstance(kv, KVStore) else KVStore(kv)
        self._prefix = prefix

    def _key(self, user_id: int) -> str:
        """Собрать KV-ключ для заданного user_id."""
        return f"{self._prefix}{user_id}"

    async def get(self, user_id: int) -> Optional[dict]:
        """
        Прочитать запись пользователя.

        Args:
            user_id: telegram from_user.id.

        Returns:
            Словарь с данными пользователя или None, если записи нет.
        """
        return await self._store.get(self._key(user_id))

    async def exists(self, user_id: int) -> bool:
        """
        Проверить наличие записи пользователя.

        Args:
            user_id: telegram from_user.id.

        Returns:
            True, если запись есть.
        """
        return await self._store.exists(self._key(user_id))

    async def create(
        self,
        user_id: int,
        data: dict,
        *,
        ttl: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> dict:
        """
        Создать новую запись пользователя.
        Автоматически проставляет created_at и updated_at.

        Args:
            user_id: telegram from_user.id.
            data: прикладные поля записи (без служебных created_at/updated_at).
            ttl: время жизни записи в секундах; None — хранить вечно.
            metadata: небольшие метаданные ключа для iter/list если необходимо.

        Returns:
            Итоговую сохранённую запись.

        Raises:
            UserAlreadyExists: если запись с таким user_id уже есть.
        """
        if await self.exists(user_id):
            raise UserAlreadyExists(f"user_id={user_id} already exists")
        timestamp = now()
        record = {**data, "created_at": timestamp, "updated_at": timestamp}
        await self._store.put(self._key(user_id), record, ttl=ttl, metadata=metadata)
        return record

    async def upsert(
        self,
        user_id: int,
        data: dict,
        *,
        ttl: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> dict:
        """
        Создать новую или полностью заменить существующую запись.
        Сохраняет прежний created_at (если запись была), всегда обновляет updated_at.

        Args:
            user_id: telegram from_user.id.
            data: полный набор прикладных полей записи.
            ttl: время жизни записи в секундах; None — хранить вечно.
            metadata: небольшие метаданные ключа.

        Returns:
            Итоговую сохранённую запись.
        """
        existing = await self.get(user_id)
        timestamp = now()
        created_at = existing["created_at"] if existing and "created_at" in existing else timestamp
        record = {**data, "created_at": created_at, "updated_at": timestamp}
        await self._store.put(self._key(user_id), record, ttl=ttl, metadata=metadata)
        return record

    async def update(
        self,
        user_id: int,
        data: dict,
        *,
        ttl: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> Optional[dict]:
        """
        Частично обновить поля существующей записи (merge верхнего уровня).

        Args:
            user_id: telegram from_user.id.
            data: поля, которые нужно добавить/перезаписать.
            ttl: время жизни записи в секундах; None — хранить вечно.
            metadata: небольшие метаданные ключа.

        Returns:
            Итоговую сохранённую запись или None, если записи нет.
        """
        existing = await self.get(user_id)
        if existing is None:
            return None
        record = {**existing, **data, "updated_at": now()}
        await self._store.put(self._key(user_id), record, ttl=ttl, metadata=metadata)
        return record

    async def delete(self, user_id: int) -> None:
        """
        Удалить запись пользователя. Идемпотентно: не падает, если записи не было.

        Args:
            user_id: telegram from_user.id.
        """
        await self._store.delete(self._key(user_id))

    async def iter_ids(self, *, batch: int = 1000) -> AsyncIterator[int]:
        """
        Асинхронно итерировать user_id всех записей без чтения значений.
        Пропускает ключи, в которых после префикса не число.

        Args:
            batch: размер страницы при листании KV.

        Yields:
            user_id (int) по одному.
        """
        prefix_len = len(self._prefix)
        async for key in self._store.iter_keys(prefix=self._prefix, batch=batch):
            try:
                yield int(key.name[prefix_len:])
            except ValueError:
                continue

    async def items(self, *, batch: int = 1000) -> AsyncIterator[tuple[int, dict]]:
        """
        Асинхронно итерировать пары (user_id, data) всех записей.
        Читает значение каждого ключа отдельным get-запросом (дороже, чем iter_ids).

        Args:
            batch: размер страницы при листании KV.

        Yields:
            Пары (user_id, data) по одной.
        """
        async for user_id in self.iter_ids(batch=batch):
            data = await self.get(user_id)
            if data is not None:
                yield user_id, data
