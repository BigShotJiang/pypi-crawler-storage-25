"""
Ядро JS <-> Python мостов для Cloudflare Workers runtime (Pyodide).

Инкапсулирует работу с pyodide.ffi, чтобы остальной SDK и прикладной код
не знали про детали Pyodide и не повторяли одни и те же преобразования.
"""

from typing import Any

from js import Object  # type: ignore[attr-defined]
from pyodide.ffi import to_js as _to_js  # type: ignore[attr-defined]


# В билде Pyodide для Cloudflare Workers класс JsNull/JsUndefined инстанса
# приходит из `_pyodide._core_docs`, а `pyodide.ffi.JsNull` — другой объект
# (re-export из нативного ядра, не совпадающий с классом инстанса).
# Поэтому isinstance-проверка ненадёжна; проверяем по имени типа.
_JS_NULLISH_NAMES = frozenset({"JsNull", "JsUndefined"})


def to_js_object(value: Any) -> Any:
    """
    Python dict/list -> plain JS Object/Array (рекурсивно).

    Нужно там, где Cloudflare API требует именно Object, а не Map
    (KV options, D1 bindings, R2 options, Queues body, DO stub RPC и т.д.).
    """
    return _to_js(value, dict_converter=Object.fromEntries)


def to_py(value: Any) -> Any:
    """
    JsProxy -> Python с нормализацией nullish-значений.

    - Python None и JS null/undefined -> Python None.
    - JsProxy с методом .to_py() -> результат конвертации.
    - Python-значение (str/int/dict/…) -> возвращается как есть.
    """
    if value is None or type(value).__name__ in _JS_NULLISH_NAMES:
        return None
    convert = getattr(value, "to_py", None)
    return convert() if callable(convert) else value
