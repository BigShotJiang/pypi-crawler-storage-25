"""Helpers for local git actions scoped to a configured workspace."""

from __future__ import annotations

import subprocess
from pathlib import Path


def commit_local_file(project_path: str, relative_path: str, message: str) -> str:
    """Stage a single changed file and create a git commit.

    Returns the new commit SHA. Kept for callers that still operate on one
    file; multi-file solutions should use ``commit_local_files``.
    """
    return commit_local_files(project_path, [relative_path], message)


def commit_local_files(
    project_path: str, relative_paths: list[str], message: str
) -> str:
    """Stage multiple changed files and create a single git commit.

    All paths are validated against path traversal before any git action
    runs, so an attempt to commit a mix of valid + traversing paths fails
    cleanly without leaving a half-staged index. Returns the new commit SHA.
    """
    if not relative_paths:
        raise ValueError("commit_local_files: relative_paths is empty")

    project_root = Path(project_path).resolve()
    for relative_path in relative_paths:
        target = (project_root / relative_path).resolve()
        if not str(target).startswith(str(project_root)):
            raise ValueError(
                f"Path traversal detected: {relative_path} "
                "resolves outside project root"
            )

    _run_git(project_root, "rev-parse", "--show-toplevel")
    _run_git(project_root, "add", "--", *relative_paths)
    _run_git(project_root, "commit", "-m", message)
    return _run_git(project_root, "rev-parse", "HEAD")


def _run_git(project_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=str(project_root),
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=15,
    )
    if completed.returncode != 0:
        stderr = (completed.stderr or "").strip()
        stdout = (completed.stdout or "").strip()
        detail = stderr or stdout or "git command failed"
        raise RuntimeError(detail)
    return (completed.stdout or "").strip()
