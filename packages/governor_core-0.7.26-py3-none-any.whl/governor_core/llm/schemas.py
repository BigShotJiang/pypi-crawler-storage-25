"""Pydantic schemas for LLM request/response structures."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class SolutionRequest(BaseModel):
    """Input to an LLM provider for solution generation."""

    opportunity_type: str
    affected_table: str
    severity_score: int
    evidence_snapshot: dict[str, Any]
    explanation: str
    dbt_model_name: str | None = None
    source_files: dict[str, str] | None = None  # {file_path: content}
    manifest_metadata: dict[str, Any] | None = None  # relevant manifest node data
    bigquery_job_samples: list[dict[str, Any]] | None = None  # sample job data
    # Enriched context fields (spec 050)
    compiled_sql: str | None = None
    upstream_models: list[dict[str, Any]] | None = None
    downstream_dependents: list[dict[str, Any]] | None = None
    macro_summary: list[dict[str, str]] | None = None
    dry_run_baseline: dict[str, Any] | None = None
    # Lineage analysis context (spec 051)
    lineage_candidates: list[dict[str, Any]] | None = None
    lineage_notes: list[str] | None = None
    # Specialist override (spec 052): focused system instruction for this opportunity type
    specialist_instruction: str | None = None
    # Column type info from INFORMATION_SCHEMA (spec 066)
    column_types: dict[str, str] | None = None  # {column_name: BQ_DATA_TYPE}
    # Solution guardrails (spec 055): effective allow-list for this generation run
    allowed_solution_policy_tags: list[str] | None = None


class FileChange(BaseModel):
    """A single file modification proposed by the LLM."""

    file_path: str
    change_type: Literal["sql_change", "project_config_change", "schema_change"]
    before_content: str | None = None
    after_content: str


class SettingRecommendation(BaseModel):
    """A BigQuery infrastructure setting recommendation."""

    current_value: str
    recommended_value: str
    affected_resource: str


class SolutionResponse(BaseModel):
    """Structured output from an LLM provider."""

    resolution_category: Literal["dbt_project_change", "bigquery_infrastructure"]
    explanation: str
    risk_level: Literal["low", "medium", "high"]
    risk_justification: str
    # For dbt project changes
    file_changes: list[FileChange] | None = None
    # For BigQuery infrastructure changes
    setting_recommendation: SettingRecommendation | None = None


class VerificationResult(BaseModel):
    """Structured output from the solution verification agent."""

    safe: bool = Field(description="True if the proposed change is safe to apply.")
    issues: list[str] = Field(
        default_factory=list,
        description="List of issues found. Empty when safe is True.",
    )


class DDLFixResult(BaseModel):
    """Structured output from the DDL error fix agent."""

    fixed_content: str = Field(
        description="The corrected file content with the DDL error fixed."
    )
    explanation: str = Field(
        default="",
        description="Brief explanation of what was changed to fix the error.",
    )


class LLMMetadata(BaseModel):
    """Metadata about an LLM API call for observability."""

    provider: str
    model: str
    prompt_tokens: int = Field(default=0)
    completion_tokens: int = Field(default=0)
    total_tokens: int = Field(default=0)
    latency_ms: int = Field(default=0)


class DownstreamPatchRequest(BaseModel):
    """Spec 128: input for proposing a partition-filter patch on a downstream model.

    Narrowly scoped to the "add one WHERE clause filtering on the upstream's
    partition column" task. Not a replacement for SolutionRequest; this path
    runs outside the ADK opportunity pipeline.
    """

    downstream_file_path: str
    downstream_before_content: str
    downstream_compiled_sql: str | None = None
    upstream_model_name: str
    upstream_table_fqn: str
    partition_column: str
    partition_data_type: str  # "date" | "timestamp" | "datetime" | "int64" | ...
    default_filter_expression: str  # conservative default per research R4


class DownstreamPatchResponse(BaseModel):
    """Structured output for a per-downstream patch proposal.

    ``status="patched"`` means ``after_content`` is a concrete file-replacement.
    ``status="abstain"`` means the LLM refused to propose a patch; caller must
    surface the reason and flag the downstream as requiring manual editing.
    """

    status: Literal["patched", "abstain"]
    after_content: str | None = None
    filter_expression: str | None = None
    explanation: str = ""
    abstain_reason: str | None = None
