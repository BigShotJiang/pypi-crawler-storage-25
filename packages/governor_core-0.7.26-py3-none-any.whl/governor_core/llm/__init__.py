"""LLM provider abstraction layer for solution generation."""

from __future__ import annotations

import logging

from governor_core.llm.base import LLMProvider

logger = logging.getLogger("app.llm")


def is_llm_configured() -> bool:
    """Check whether LLM provider configuration is complete.

    Returns True if an API key is present, False otherwise.
    """
    from governor_core.setup.runtime import get_runtime_llm_api_key

    return get_runtime_llm_api_key() is not None


def get_llm_provider() -> LLMProvider | None:
    """Create and return an LLM provider based on settings.

    Returns None if LLM_API_KEY is absent (graceful degradation).
    Logs a warning when configuration is incomplete.
    """
    from governor_core.core.config import get_settings
    from governor_core.setup.runtime import get_runtime_llm_api_key

    settings = get_settings()
    api_key = get_runtime_llm_api_key()

    if not api_key:
        logger.warning(
            "LLM provider not configured: LLM_API_KEY is not set. "
            "Solution generation will be disabled."
        )
        return None

    provider_type = settings.llm_provider.lower()

    if provider_type == "gemini":
        from governor_core.llm.gemini import GeminiProvider

        return GeminiProvider(api_key=api_key)

    logger.error(
        "Unsupported LLM provider type: %s. "
        "Supported providers: gemini. Solution generation will be disabled.",
        provider_type,
    )
    return None
