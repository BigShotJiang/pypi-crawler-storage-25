"""Abstract base class for LLM providers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from governor_core.llm.schemas import (
    DDLFixResult,
    DownstreamPatchRequest,
    DownstreamPatchResponse,
    LLMMetadata,
    SolutionRequest,
    SolutionResponse,
    VerificationResult,
)


class LLMProvider(ABC):
    """Abstract interface for LLM providers.

    Implementations wrap a specific LLM service (e.g., Gemini, OpenAI)
    and translate SolutionRequest into provider-specific API calls.
    """

    @abstractmethod
    def generate(
        self, request: SolutionRequest
    ) -> tuple[SolutionResponse, LLMMetadata]:
        """Generate a solution for a cost optimization opportunity.

        Args:
            request: Structured request containing opportunity evidence,
                     source code (if applicable), and manifest metadata.

        Returns:
            Tuple of (parsed response, metadata with token usage and latency).

        Raises:
            LLMRequestError: If the API call fails after retries.
            LLMResponseValidationError: If the response doesn't match the schema.
        """
        ...

    @abstractmethod
    def verify(
        self,
        file_path: str,
        before_content: str,
        after_content: str,
        change_context: str,
    ) -> VerificationResult:
        """Verify that a proposed file change is safe and complete.

        A second-pass review that checks the generated solution preserves
        all business logic, is a complete file, and only changes what
        is necessary for the stated optimization.

        Args:
            file_path: The file being modified.
            before_content: Original file content from GitHub.
            after_content: Proposed modified content from the generator.
            change_context: Why the change is being made (opportunity explanation).

        Returns:
            VerificationResult with safe flag and any issues found.
        """
        ...

    @abstractmethod
    def fix_ddl_error(
        self,
        file_path: str,
        file_content: str,
        ddl_error: str,
        opportunity_type: str,
    ) -> DDLFixResult:
        """Fix a DDL validation error in a proposed file change.

        Called when a BigQuery DDL dry-run fails (e.g. partition_by type
        mismatch).  Sends the current file content and the error message
        to the LLM, which returns a corrected version of the file.

        Args:
            file_path: The file being modified.
            file_content: Current proposed content that failed DDL validation.
            ddl_error: The BigQuery error message from the failed dry-run.
            opportunity_type: The optimization type (e.g. partition_pruning).

        Returns:
            DDLFixResult with the corrected file content.
        """
        ...

    @abstractmethod
    def propose_downstream_patch(
        self, request: DownstreamPatchRequest
    ) -> tuple[DownstreamPatchResponse, LLMMetadata]:
        """Spec 128: propose a single WHERE-clause patch on a downstream dbt
        model that broke shadow validation because it queries an upstream with
        ``require_partition_filter=true`` without filtering on the partition
        column.

        The patch is intentionally narrow — one additional ``WHERE`` clause —
        and the LLM may abstain if the minimal edit would change downstream
        semantics or cannot be composed with an existing filter.

        Args:
            request: Downstream + upstream context and the conservative default
                filter expression to propose when the LLM has no strong reason
                to diverge.

        Returns:
            Tuple of (``DownstreamPatchResponse``, metadata). Always returns;
            a declined patch manifests as ``status="abstain"``.

        Raises:
            LLMRequestError: If the API call fails after retries.
            LLMResponseValidationError: If the response doesn't match the schema.
        """
        ...
