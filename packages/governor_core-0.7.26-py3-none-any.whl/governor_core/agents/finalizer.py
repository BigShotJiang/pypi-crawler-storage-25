"""Pipeline request/result conversion for ADK solution generation.

Provides:
- PipelineRequest: typed input to ADKPipeline.run()
- _request_to_state(): converts PipelineRequest → flat JSON-serializable dict for ADK session state
- _state_to_generation_result(): parses ADK session state → GenerationResult
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from governor_core.llm.schemas import LLMMetadata
from governor_core.solutions.exceptions import LLMResponseValidationError
from governor_core.solutions.generator import (
    GenerationResult,
    SolutionData,
    _DBT_CHANGE_TYPES,
    _infer_change_type,
)

from governor_core.github.client import (
    GitHubAuthenticationError,
    GitHubConnectionError,
    GitHubFileNotFoundError,
)

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from governor_core.github.client import GitHubAppClient

logger = logging.getLogger("app.agents.finalizer")


@dataclass
class PipelineRequest:
    """Input to the ADK pipeline, derived from SolutionGenerator.generate() args."""

    opportunity_type: str
    opportunity_id: str
    affected_table: str
    severity_score: int
    explanation: str
    evidence_snapshot: dict[str, Any]
    dbt_model_name: str | None
    repo_slug: str | None
    commit_sha: str | None
    dbt_prefix: str
    project_id: str
    manifest_version_id: str | None
    config_id: str
    # Pre-computed context (lineage analysis, dry-run baseline)
    dry_run_baseline: dict[str, Any] | None
    lineage_candidates: list[dict[str, Any]]
    lineage_notes: list[str]
    # Pre-fetched GitHub context (populated in generator Step 1 before the pipeline starts)
    # In Phase 4+, these are populated by the ParallelContextGatherer tools instead.
    source_files: dict[str, str] | None = None
    compiled_sql: str | None = None
    upstream_models: list[dict[str, Any]] | None = None
    manifest_metadata: dict[str, Any] | None = None
    job_samples: list[dict[str, Any]] | None = None
    allowed_solution_policy_tags: list[str] | None = None
    # Injected dependencies (not stored in session state — not JSON-serializable)
    github_client: "GitHubAppClient | None" = None
    db_session: "Session | None" = None


def _request_to_state(request: PipelineRequest) -> dict[str, Any]:
    """Convert a PipelineRequest to a flat, JSON-serializable ADK session state dict.

    Complex fields (dicts, lists) are JSON-encoded as strings so that all state
    values are primitive types, compatible with InMemorySessionService.

    Returns:
        Dict suitable for passing as state= to session_service.create_session().
    """
    state: dict[str, Any] = {
        "opportunity_type": request.opportunity_type,
        "opportunity_id": str(request.opportunity_id),
        "affected_table": request.affected_table,
        "severity_score": request.severity_score,
        "explanation": request.explanation,
        "evidence_snapshot_json": json.dumps(request.evidence_snapshot, default=str),
        "dbt_model_name": request.dbt_model_name,
        "repo_slug": request.repo_slug,
        "commit_sha": request.commit_sha,
        "dbt_prefix": request.dbt_prefix or "",
        "project_id": request.project_id,
        "manifest_version_id": str(request.manifest_version_id)
        if request.manifest_version_id
        else None,
        "config_id": str(request.config_id),
    }

    if request.dry_run_baseline is not None:
        state["dry_run_baseline_json"] = json.dumps(
            request.dry_run_baseline, default=str
        )

    if request.lineage_candidates:
        state["lineage_candidates_json"] = json.dumps(
            request.lineage_candidates, default=str
        )

    if request.lineage_notes:
        state["lineage_notes_json"] = json.dumps(request.lineage_notes)

    # Pre-fetched context (Phase 3: populated before pipeline; Phase 4+: populated by tools)
    if request.source_files is not None:
        state["source_files_json"] = json.dumps(request.source_files)

    if request.compiled_sql is not None:
        state["compiled_sql"] = request.compiled_sql

    if request.upstream_models is not None:
        state["upstream_models_json"] = json.dumps(request.upstream_models, default=str)

    if request.manifest_metadata is not None:
        state["manifest_metadata_json"] = json.dumps(
            request.manifest_metadata, default=str
        )

    if request.job_samples is not None:
        state["job_samples_json"] = json.dumps(request.job_samples, default=str)

    if request.allowed_solution_policy_tags is not None:
        state["allowed_solution_policy_tags_json"] = json.dumps(
            request.allowed_solution_policy_tags
        )

    return state


def _state_to_generation_result(
    state: dict[str, Any],
    github_client: Any = None,
    local_project_path: str | None = None,
) -> GenerationResult:
    """Convert ADK session state to a GenerationResult.

    Reads solution_json and generation_metadata_json from state,
    parses them into the SolutionData / LLMMetadata structure expected
    by SolutionService.

    Replicates the key logic from SolutionGenerator._response_to_solution_data():
    - Looks up before_content from source_files_json (real GitHub file content)
    - Applies dbt_prefix to file_path
    - Infers change_type from file extension

    Args:
        state: Final ADK session.state dict after pipeline completes.

    Returns:
        GenerationResult with solutions and metadata.

    Raises:
        LLMResponseValidationError: If solution_json is absent or unparseable.
    """
    solution_json = state.get("solution_json")
    if not solution_json:
        raise LLMResponseValidationError(
            "ADK pipeline completed without producing solution_json in session state"
        )

    try:
        solution_dict = json.loads(solution_json)
    except (json.JSONDecodeError, TypeError) as exc:
        raise LLMResponseValidationError(
            f"solution_json is not valid JSON: {exc}"
        ) from exc

    resolution_category = solution_dict.get("resolution_category", "dbt_project_change")

    # Parse source_files early — needed for deterministic category override below
    source_files: dict[str, str] = {}
    source_files_raw = state.get("source_files_json")
    if source_files_raw:
        try:
            source_files = json.loads(source_files_raw)
        except (json.JSONDecodeError, TypeError):
            pass

    # Downstream files are legitimate before_content sources for multi-file
    # fixes (e.g. enforcing require_partition_filter upstream + patching
    # downstream WHERE clauses). Merge them in without overwriting the
    # target model's own entries.
    downstream_raw = state.get("downstream_source_files_json")
    if downstream_raw:
        try:
            downstream_files = json.loads(downstream_raw) or {}
            for path, content in downstream_files.items():
                source_files.setdefault(path, content)
        except (json.JSONDecodeError, TypeError):
            pass

    # Override resolution_category deterministically (mirrors generator._infer_resolution_category).
    # For opportunity types that are always dbt changes when source code is available,
    # force dbt_project_change even if the LLM returned bigquery_infrastructure.
    opportunity_type = state.get("opportunity_type", "")
    if (
        opportunity_type in _DBT_CHANGE_TYPES
        and source_files
        and resolution_category != "dbt_project_change"
    ):
        logger.info(
            "Overriding LLM resolution_category %s → dbt_project_change for %s",
            resolution_category,
            opportunity_type,
        )
        resolution_category = "dbt_project_change"

    # Parse metadata
    metadata_json = state.get("generation_metadata_json")
    if metadata_json:
        try:
            metadata_dict = json.loads(metadata_json)
            metadata = LLMMetadata(
                provider=metadata_dict.get("provider", "gemini"),
                model=metadata_dict.get("model", "unknown"),
                prompt_tokens=metadata_dict.get("prompt_tokens", 0),
                completion_tokens=metadata_dict.get("completion_tokens", 0),
                total_tokens=metadata_dict.get("total_tokens", 0),
                latency_ms=metadata_dict.get("latency_ms", 0),
            )
        except (json.JSONDecodeError, TypeError, KeyError) as exc:
            logger.warning("Could not parse generation_metadata_json: %s", exc)
            metadata = LLMMetadata(provider="gemini", model="unknown")
    else:
        metadata = LLMMetadata(provider="gemini", model="unknown")

    repo_slug = state.get("repo_slug")
    commit_sha = state.get("commit_sha")
    dbt_prefix = state.get("dbt_prefix") or ""

    # Build solutions list
    solutions: list[SolutionData] = []

    if resolution_category == "bigquery_infrastructure":
        setting = solution_dict.get("setting_recommendation") or {}
        solutions.append(
            SolutionData(
                resolution_category="bigquery_infrastructure",
                explanation=solution_dict.get("explanation", ""),
                risk_level=solution_dict.get("risk_level", "medium"),
                risk_justification=solution_dict.get("risk_justification", ""),
                current_setting_value=setting.get("current_value"),
                recommended_setting_value=setting.get("recommended_value"),
                affected_resource=setting.get("affected_resource"),
                trust_tier=solution_dict.get("trust_tier", "requires_review"),
                validation_report=_try_parse_validation_report(state),
            )
        )
    else:
        # dbt_project_change — may have multiple file_changes
        file_changes = solution_dict.get("file_changes") or []

        if file_changes:
            for fc in file_changes:
                original_path = fc.get("file_path", "")

                # Apply dbt subdirectory prefix to file_path (mirrors _response_to_solution_data)
                file_path = original_path
                if (
                    dbt_prefix
                    and file_path
                    and not file_path.startswith(f"{dbt_prefix}/")
                ):
                    file_path = f"{dbt_prefix}/{file_path}"

                # Infer change_type deterministically from file extension
                change_type = (
                    _infer_change_type(file_path)
                    if file_path
                    else fc.get("change_type")
                )

                # Resolve before_content from pre-fetched GitHub files (real content)
                before_content: str | None = None
                if source_files and original_path:
                    if original_path in source_files:
                        before_content = source_files[original_path]
                    elif dbt_prefix and file_path in source_files:
                        before_content = source_files[file_path]
                    elif dbt_prefix and original_path.startswith(f"{dbt_prefix}/"):
                        # LLM returned path with prefix already — strip for lookup
                        stripped = original_path[len(dbt_prefix) + 1 :]
                        if stripped in source_files:
                            before_content = source_files[stripped]

                # On-demand fetch: if file not in pre-fetched source context,
                # try to retrieve it from disk (local/CLI mode) or GitHub
                # (cloud mode). Local mode is checked first and never falls
                # through to GitHub.
                if before_content is None and original_path:
                    if local_project_path:
                        from governor_core.workspace.detection import read_local_file

                        fetched = read_local_file(local_project_path, original_path)
                        if fetched is not None:
                            before_content = fetched
                            source_files[original_path] = fetched
                    elif source_files and github_client and repo_slug:
                        logger.info(
                            "LLM proposed change for %s — not in source context, fetching on demand",
                            original_path,
                        )
                        try:
                            prefixed = (
                                f"{dbt_prefix}/{original_path}"
                                if dbt_prefix
                                else original_path
                            )
                            fetched = github_client.get_file_content(
                                repo_slug, prefixed, ref=commit_sha
                            )
                            before_content = fetched
                            source_files[original_path] = fetched
                        except (
                            GitHubFileNotFoundError,
                            GitHubConnectionError,
                            GitHubAuthenticationError,
                        ):
                            pass

                # Fall back to LLM-provided before_content only when source not available
                if before_content is None:
                    before_content = fc.get("before_content")

                after_content = fc.get("after_content", "")

                # Skip files we still can't resolve after on-demand fetch.
                # A file_path without before_content would be rejected by
                # SolutionService.store_solution for dbt_project_change, so
                # drop it here with a clear log instead of propagating a
                # malformed solution to storage.
                if file_path and before_content is None:
                    logger.warning(
                        "LLM proposed change for %s but file not found "
                        "(local_project_path=%s, repo=%s), skipping",
                        original_path,
                        local_project_path,
                        repo_slug,
                    )
                    continue

                # Skip no-op changes
                if before_content and before_content == after_content:
                    logger.debug("Skipping no-op change for %s", file_path)
                    continue

                solutions.append(
                    SolutionData(
                        resolution_category="dbt_project_change",
                        explanation=solution_dict.get("explanation", ""),
                        risk_level=solution_dict.get("risk_level", "medium"),
                        risk_justification=solution_dict.get("risk_justification", ""),
                        file_path=file_path,
                        change_type=change_type,
                        before_content=before_content,
                        after_content=after_content,
                        repository=repo_slug,
                        commit_sha=commit_sha,
                        trust_tier=solution_dict.get("trust_tier", "requires_review"),
                        validation_report=_try_parse_validation_report(state),
                    )
                )
        else:
            # No file_changes — infrastructure fallback or no-source path
            solutions.append(
                SolutionData(
                    resolution_category="dbt_project_change",
                    explanation=solution_dict.get("explanation", ""),
                    risk_level=solution_dict.get("risk_level", "medium"),
                    risk_justification=solution_dict.get("risk_justification", ""),
                    trust_tier=solution_dict.get("trust_tier", "requires_review"),
                    validation_report=_try_parse_validation_report(state),
                )
            )

    return GenerationResult(
        solutions=solutions,
        metadata=metadata,
        resolution_category=resolution_category,
    )


def _try_parse_validation_report(state: dict[str, Any]) -> dict | None:
    """Try to parse validation_report_json from state; return None on failure."""
    report_json = state.get("validation_report_json")
    if not report_json:
        return None
    try:
        return json.loads(report_json)
    except (json.JSONDecodeError, TypeError):
        return None
