"""Spec 132: ``RequirePartitionFilterProvider`` — reference implementation of
the ``GuardrailProvider`` interface, migrated from the spec-128 agent module.

All logic is byte-for-byte from the pre-refactor ``agents/downstream_patch/agent.py``;
only the module boundary and the call shape change. The agent module keeps a
thin top-level ``propose_patch()`` function that delegates here, so spec-128
tests that called the function directly continue to pass unchanged.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from governor_core.agents.downstream_patch.prompts.downstream_partition_filter import (
    default_filter_expression,
)
from governor_core.agents.downstream_patch.providers.base import GuardrailProvider
from governor_core.llm.schemas import DownstreamPatchRequest
from governor_core.shadow.failure_analysis import DownstreamFailure, DownstreamPatch

if TYPE_CHECKING:
    from governor_core.llm.base import LLMProvider

logger = logging.getLogger("app.agents.downstream_patch.require_partition_filter")


# Reused by the thin ``agents/downstream_patch/agent.py`` wrapper for
# backwards-compat with spec-128 tests that import UpstreamPartitionContext
# directly from the agent module.
from governor_core.agents.downstream_patch.agent import UpstreamPartitionContext  # noqa: E402


class RequirePartitionFilterProvider(GuardrailProvider):
    """Guardrail provider for the ``add_require_partition_filter`` template
    (spec 127). Proposes a one-clause ``WHERE`` edit per failing downstream so
    the downstream survives the upstream's new partition-filter requirement.
    """

    template_id = "add_require_partition_filter"

    def build_upstream_context(
        self,
        solution,
        manifest_content: dict,
        shadow_run_id: str,
    ) -> UpstreamPartitionContext | None:
        """Derive the upstream partition column + data type from the manifest
        node for the model this solution targets. Returns ``None`` when the
        upstream cannot be located or is missing ``partition_by`` metadata.
        """
        opportunity = getattr(solution, "opportunity", None)
        if opportunity is None:
            return None
        model_name = getattr(opportunity, "dbt_model_name", None)
        if not model_name:
            return None

        nodes = (manifest_content or {}).get("nodes", {}) or {}
        node = None
        for node_id, candidate in nodes.items():
            if node_id.split(".")[-1] == model_name:
                node = candidate
                break
        if node is None:
            return None

        config_block = node.get("config") or {}
        partition_by = config_block.get("partition_by") or {}
        partition_column: str | None = None
        partition_data_type = "date"
        if isinstance(partition_by, dict):
            partition_column = partition_by.get("field")
            partition_data_type = (partition_by.get("data_type") or "date").lower()
        elif isinstance(partition_by, str):
            partition_column = partition_by

        if not partition_column:
            return None

        relation_name = node.get("relation_name") or ""
        return UpstreamPartitionContext(
            upstream_model_name=model_name,
            upstream_table_fqn=relation_name or model_name,
            partition_column=partition_column,
            partition_data_type=partition_data_type,
            source_shadow_run_id=str(shadow_run_id),
        )

    async def propose_patch(
        self,
        failure: DownstreamFailure,
        context: UpstreamPartitionContext,
        *,
        llm_provider: "LLMProvider",
    ) -> DownstreamPatch:
        """Propose a partition-filter patch for one failing downstream.

        Behaviour is identical to the pre-refactor top-level function in
        ``agent.py`` — moved here so the pipeline calls it through the
        registry.
        """
        default_filter = default_filter_expression(
            context.partition_column, context.partition_data_type
        )
        if default_filter is None:
            return _manual_required(
                failure=failure,
                context=context,
                abstain_reason=(
                    f"No safe default partition filter for data type "
                    f"'{context.partition_data_type}'. Integer-range and unknown "
                    f"partition types require a manual edit so downstream semantics "
                    f"are not guessed."
                ),
            )

        request = DownstreamPatchRequest(
            downstream_file_path=failure.original_file_path,
            downstream_before_content=_load_downstream_source(failure),
            downstream_compiled_sql=failure.compiled_sql,
            upstream_model_name=context.upstream_model_name,
            upstream_table_fqn=context.upstream_table_fqn,
            partition_column=context.partition_column,
            partition_data_type=context.partition_data_type,
            default_filter_expression=default_filter,
        )

        try:
            response, _metadata = await asyncio.to_thread(
                llm_provider.propose_downstream_patch, request
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception(
                "Downstream-patch LLM call raised for %s: translating to manual_required",
                failure.original_file_path,
            )
            return _manual_required(
                failure=failure,
                context=context,
                abstain_reason=f"LLM call failed: {exc}",
            )

        if response.status == "abstain":
            return _manual_required(
                failure=failure,
                context=context,
                abstain_reason=response.abstain_reason or "LLM abstained (no reason given)",
            )

        after_content = response.after_content or ""
        if not after_content.strip():
            return _manual_required(
                failure=failure,
                context=context,
                abstain_reason="LLM returned patched status but empty after_content",
            )

        return DownstreamPatch(
            file_path=failure.original_file_path,
            before_content=request.downstream_before_content,
            after_content=after_content,
            proposal_meta={
                "upstream_model": context.upstream_model_name,
                "partition_column": context.partition_column,
                "partition_data_type": context.partition_data_type,
                "proposed_filter": response.filter_expression or default_filter,
                "status": "proposed",
                "abstain_reason": None,
                "source_shadow_run_id": context.source_shadow_run_id,
                "edited_at": None,
                "explanation": response.explanation,
                "change_type": "downstream_partition_filter_patch",
            },
            status="proposed",
        )


def _manual_required(
    *,
    failure: DownstreamFailure,
    context: UpstreamPartitionContext,
    abstain_reason: str,
) -> DownstreamPatch:
    """Build a ``manual_required`` patch carrying the abstention reason."""
    before_content = _load_downstream_source(failure)
    return DownstreamPatch(
        file_path=failure.original_file_path,
        before_content=before_content,
        after_content=before_content,
        proposal_meta={
            "upstream_model": context.upstream_model_name,
            "partition_column": context.partition_column,
            "partition_data_type": context.partition_data_type,
            "proposed_filter": None,
            "status": "manual_required",
            "abstain_reason": abstain_reason,
            "source_shadow_run_id": context.source_shadow_run_id,
            "edited_at": None,
            "explanation": "",
            "change_type": "downstream_partition_filter_patch",
            "flagged_at": datetime.now(timezone.utc).isoformat(),
        },
        status="manual_required",
    )


def _load_downstream_source(failure: DownstreamFailure) -> str:
    """Fallback to ``compiled_sql`` when the raw on-disk content is unavailable
    (matches the pre-refactor behaviour)."""
    if failure.compiled_sql:
        return failure.compiled_sql
    return ""
