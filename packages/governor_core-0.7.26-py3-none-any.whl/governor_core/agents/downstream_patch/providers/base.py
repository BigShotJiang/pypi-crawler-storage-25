"""Spec 132: ``GuardrailProvider`` abstract base class.

A provider owns one breaking-change guardrail's knowledge: how to build
the per-solution upstream context, and how to propose a per-downstream
patch. The spec-128 pipeline (shadow post-run hook → solutions/service
→ web reshadow route → UI sub-cards) is guardrail-agnostic and consults
the registry to dispatch; no pipeline file compares `template_id` against
a hard-coded string any more.

See ``specs/132-generalize-auto-patch/research.md`` R2 for the design
rationale. Adding a second guardrail in a future spec means writing one
provider subclass and calling ``register_provider(MyProvider())`` — zero
pipeline edits.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from governor_core.llm.base import LLMProvider
    from governor_core.shadow.failure_analysis import (
        DownstreamFailure,
        DownstreamPatch,
    )


class GuardrailProvider(ABC):
    """Abstract interface for a breaking-change guardrail's downstream-patch
    provider. Concrete providers are registered by ``template_id`` so that
    the spec-128 pipeline dispatches polymorphically rather than comparing
    strings inline.
    """

    # Registry key. Concrete subclasses MUST set this to the template_id
    # of the template they support (e.g. "add_require_partition_filter").
    # Not a ``@property`` — keeps registry introspection possible without
    # instantiating the provider.
    template_id: str = ""

    @abstractmethod
    def build_upstream_context(
        self,
        solution: Any,
        manifest_content: dict,
        shadow_run_id: str,
    ) -> Any | None:
        """Build the provider-specific context that ``propose_patch`` will
        consume.

        Returns ``None`` when the context cannot be built (e.g. the manifest
        does not describe the affected upstream in the shape this provider
        needs). The pipeline treats a ``None`` context as "skip patch
        generation for this solution" — not an error.

        The return type is intentionally provider-specific. The pipeline
        treats it as opaque: it holds it, passes it to ``propose_patch``,
        and never inspects its fields.
        """

    @abstractmethod
    async def propose_patch(
        self,
        failure: "DownstreamFailure",
        context: Any,
        *,
        llm_provider: "LLMProvider",
    ) -> "DownstreamPatch":
        """Propose a patch for one failing downstream model.

        Always returns a ``DownstreamPatch``. An LLM abstention, a
        provider-specific abort condition, or any content error manifests
        as ``status="manual_required"`` — never an exception. Per spec-128
        FR-011, one provider failure MUST NOT block sibling downstreams.
        """
