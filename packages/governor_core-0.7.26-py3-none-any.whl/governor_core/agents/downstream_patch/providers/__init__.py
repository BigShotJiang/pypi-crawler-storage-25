"""Spec 132: guardrail-provider registry.

Providers self-register at import time. Pipeline code consults this
registry — see ``shadow/service.py`` post-run hook,
``solutions/service.generate_downstream_patches``, and the web reshadow
route.
"""

from __future__ import annotations

from governor_core.agents.downstream_patch.providers.base import GuardrailProvider

_REGISTRY: dict[str, GuardrailProvider] = {}


def register_provider(provider: GuardrailProvider) -> None:
    """Add ``provider`` to the registry, keyed by ``provider.template_id``.

    Raises ``ValueError`` on duplicate registration — determinism over
    last-write-wins. If a future spec legitimately needs polymorphism on
    the same template_id, this function is the single point to change.
    """
    tid = provider.template_id
    if not tid:
        raise ValueError(
            "GuardrailProvider.template_id must be a non-empty string; "
            f"got {tid!r} on {type(provider).__name__}"
        )
    if tid in _REGISTRY:
        raise ValueError(
            f"duplicate GuardrailProvider registration for template_id {tid!r}"
        )
    _REGISTRY[tid] = provider


def get_provider(template_id: str | None) -> GuardrailProvider | None:
    """Return the provider registered for ``template_id``, or ``None``.

    The pipeline uses a ``None`` result as the "silent no-op" signal
    (spec 128 FR-009 / spec 132 FR-009).
    """
    if not template_id:
        return None
    return _REGISTRY.get(template_id)


def registered_template_ids() -> tuple[str, ...]:
    """Return the registered ``template_id``s as a tuple suitable for
    exposing to the web Jinja env (spec 132 R5). Ordering mirrors
    insertion order, which is deterministic by import order."""
    return tuple(_REGISTRY.keys())


# ---------------------------------------------------------------------------
# Self-registration of built-in providers
# ---------------------------------------------------------------------------
# Note: upstream_partition_by from spec 131 does NOT register — partitioning
# an unpartitioned upstream is not a breaking change that requires downstream
# patches. The pipeline's "no provider → no-op" path is correct for it.

from governor_core.agents.downstream_patch.providers.require_partition_filter import (  # noqa: E402
    RequirePartitionFilterProvider,
)

register_provider(RequirePartitionFilterProvider())


__all__ = [
    "GuardrailProvider",
    "get_provider",
    "register_provider",
    "registered_template_ids",
]
