"""Spec 128 downstream-patch agent.

Spec 132 refactor: the guardrail-specific logic now lives in the
``providers/`` package. This module retains ``UpstreamPartitionContext``
and a top-level ``propose_patch`` function for backwards-compat with
spec-128 tests that import them directly. Both delegate to the
``RequirePartitionFilterProvider``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from governor_core.shadow.failure_analysis import DownstreamFailure, DownstreamPatch

if TYPE_CHECKING:
    from governor_core.llm.base import LLMProvider

logger = logging.getLogger("app.agents.downstream_patch")


@dataclass(frozen=True)
class UpstreamPartitionContext:
    """Context about the upstream model whose guardrail triggered the failure."""

    upstream_model_name: str
    upstream_table_fqn: str
    partition_column: str
    partition_data_type: str  # "date" | "timestamp" | "datetime" | "int64" | ...
    source_shadow_run_id: str


async def propose_patch(
    failure: DownstreamFailure,
    context: UpstreamPartitionContext,
    *,
    llm_provider: "LLMProvider",
) -> DownstreamPatch:
    """Spec 128 top-level entry; retained for backwards-compat with tests
    that import it directly. Spec 132: delegates to the registered
    ``RequirePartitionFilterProvider`` so all concrete behaviour lives in
    exactly one place.
    """
    # Local import to avoid a circular chain:
    #     providers/__init__.py → require_partition_filter.py → agent.py
    #     (for UpstreamPartitionContext re-export)
    from governor_core.agents.downstream_patch.providers.require_partition_filter import (
        RequirePartitionFilterProvider,
    )

    return await RequirePartitionFilterProvider().propose_patch(
        failure, context, llm_provider=llm_provider
    )
