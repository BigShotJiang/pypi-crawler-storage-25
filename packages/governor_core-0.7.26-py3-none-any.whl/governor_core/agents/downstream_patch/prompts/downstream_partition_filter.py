"""Prompt fragments for the downstream-patch agent (spec 128).

The bulk of the system instruction lives in ``GeminiProvider._DOWNSTREAM_PATCH_INSTRUCTION``
so that different provider implementations can tune it for their own quirks.
This file only holds the default-filter policy constants — centralised here so
tests can assert the conservative-range contract from research R4.
"""

from __future__ import annotations

# Spec 128 research R4: conservative default range for DATE / TIMESTAMP / DATETIME
# partitions. 30 days is wide enough to keep most downstream aggregations
# meaningful, narrow enough to cut full-scan costs materially if the user
# applies without editing.
DEFAULT_TEMPORAL_FILTER_DAYS = 30

_TEMPORAL_TYPES = {"date", "timestamp", "datetime"}
_INGESTION_TIME_TYPES = {"ingestion_time", "_partitiontime", "_partitiondate"}


def default_filter_expression(partition_column: str, data_type: str) -> str | None:
    """Return the conservative default filter expression for a given
    partition column + data type, or ``None`` if no safe default exists
    (integer partitions, unknown types — the agent must abstain instead).
    """
    normalized = data_type.strip().lower()
    if normalized in _TEMPORAL_TYPES:
        return (
            f"{partition_column} >= CURRENT_DATE() - INTERVAL "
            f"{DEFAULT_TEMPORAL_FILTER_DAYS} DAY"
        )
    if normalized in _INGESTION_TIME_TYPES:
        return (
            f"_PARTITIONDATE >= CURRENT_DATE() - INTERVAL "
            f"{DEFAULT_TEMPORAL_FILTER_DAYS} DAY"
        )
    return None
