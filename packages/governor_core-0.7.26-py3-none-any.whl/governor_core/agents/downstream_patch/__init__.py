"""Spec 128: downstream-patch specialist.

Spec 132 refactor: the template-specific logic now lives in the
``providers/`` package; see ``providers/__init__.py`` for the registry
and ``providers/require_partition_filter.py`` for the reference
implementation. The pipeline (shadow/service, solutions/service, web
reshadow route, UI template) dispatches through ``get_provider()`` —
no hard-coded ``template_id`` strings remain.

This module re-exports the spec-128 surface (``UpstreamPartitionContext``,
``propose_patch``) for backwards-compat with existing callers and tests.
"""

from governor_core.agents.downstream_patch.agent import (
    UpstreamPartitionContext,
    propose_patch,
)
from governor_core.agents.downstream_patch.providers import (
    GuardrailProvider,
    get_provider,
    register_provider,
    registered_template_ids,
)

__all__ = [
    "GuardrailProvider",
    "UpstreamPartitionContext",
    "get_provider",
    "propose_patch",
    "register_provider",
    "registered_template_ids",
]
