"""Partition pruning specialist pipeline (spec 052)."""

from __future__ import annotations

from typing import Any

from google.adk.agents import SequentialAgent


def build_partition_pruning_pipeline(
    llm_provider: Any,
    github_client: Any = None,
    db_session: Any = None,
    db_session_factory: Any = None,
    local_project_path: str | None = None,
) -> SequentialAgent:
    """Build the PartitionPruningPipeline specialist."""
    from governor_core.agents.prompts.partition_pruning import PARTITION_PRUNING_INSTRUCTION
    from governor_core.agents.specialists.base import build_specialist_pipeline

    return build_specialist_pipeline(
        name="PartitionPruningPipeline",
        specialist_instruction=PARTITION_PRUNING_INSTRUCTION,
        llm_provider=llm_provider,
        github_client=github_client,
        db_session=db_session,
        db_session_factory=db_session_factory,
        local_project_path=local_project_path,
    )
