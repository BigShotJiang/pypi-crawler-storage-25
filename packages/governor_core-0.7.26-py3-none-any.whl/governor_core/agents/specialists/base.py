"""Base factory for specialist solution pipelines (spec 052).

Provides:
- ParallelContextGathererAgent: a BaseAgent that runs all 5 context-fetch
  tool functions concurrently using asyncio.gather(), writing results to
  session state for the downstream code generator.
- build_specialist_pipeline(): factory that constructs a SequentialAgent
  combining context gathering and specialist LLM code generation.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any

from google.adk.agents import BaseAgent, LoopAgent, SequentialAgent
from google.adk.events import Event, EventActions

from governor_core.solutions.exceptions import LLMRequestError, LLMResponseValidationError

if TYPE_CHECKING:
    from google.adk.agents.invocation_context import InvocationContext

logger = logging.getLogger("app.agents.specialists.base")

# Import tool functions at module level so tests can patch them via
# "app.agents.specialists.base.fetch_source_files" etc.
from governor_core.agents.tools import (  # noqa: E402
    fetch_column_types,
    fetch_compiled_sql,
    fetch_downstream_sources,
    fetch_job_samples,
    fetch_manifest_metadata,
    fetch_source_files,
    fetch_upstream_models,
)


class ParallelContextGathererAgent(BaseAgent):
    """Fetches all 5 context types concurrently using asyncio.gather().

    Runs fetch_source_files, fetch_compiled_sql, fetch_upstream_models,
    fetch_manifest_metadata, and fetch_job_samples in parallel threads.
    Writes all results to session state via EventActions.state_delta.

    This avoids sequential I/O latency: all 5 fetches complete in the
    time of the slowest individual fetch (rather than the sum of all).

    If any key is already in state (pre-fetched before the pipeline),
    the corresponding tool is skipped to avoid redundant work.
    """

    github_client: Any = None
    db_session: Any = None
    db_session_factory: Any = None
    local_project_path: Any = None

    async def _run_async_impl(self, ctx: "InvocationContext"):
        state = ctx.session.state

        # Build a simple dict-backed mock tool context for tool functions.
        # ADK tools read/write via tool_context.state — we use the session
        # state dict directly so writes are visible in the final state_delta.
        tool_state: dict[str, Any] = dict(state)
        # In local/CLI mode we read sources from disk and never contact
        # GitHub. `_local_project_path` takes precedence inside fetch tools.
        if self.local_project_path:
            tool_state["_local_project_path"] = self.local_project_path
        if self.github_client is not None:
            tool_state["_github_client"] = self.github_client
        if self.db_session_factory is not None:
            tool_state["_db_session_factory"] = self.db_session_factory
        elif self.db_session is not None:
            tool_state["_db_session"] = self.db_session

        class _ToolCtx:
            def __init__(self, s: dict) -> None:
                self.state = s

        tool_ctx = _ToolCtx(tool_state)

        # Build tasks for any context not already in state
        tasks = []

        if not state.get("source_files_json"):
            # Build file_paths_json from manifest_metadata if available
            manifest_raw = state.get("manifest_metadata_json")
            file_paths: list[str] = []
            if manifest_raw:
                try:
                    meta = json.loads(manifest_raw)
                    if meta and meta.get("original_file_path"):
                        file_paths = [meta["original_file_path"]]
                except (json.JSONDecodeError, TypeError, KeyError):
                    pass
            tasks.append(
                (
                    "source_files",
                    asyncio.to_thread(
                        fetch_source_files, json.dumps(file_paths), tool_ctx
                    ),
                )
            )
        else:
            tool_state["source_files_json"] = state["source_files_json"]

        if not state.get("compiled_sql"):
            tasks.append(
                ("compiled_sql", asyncio.to_thread(fetch_compiled_sql, tool_ctx))
            )
        else:
            tool_state["compiled_sql"] = state["compiled_sql"]

        if not state.get("upstream_models_json"):
            tasks.append(
                ("upstream_models", asyncio.to_thread(fetch_upstream_models, tool_ctx))
            )
        else:
            tool_state["upstream_models_json"] = state["upstream_models_json"]

        if not state.get("manifest_metadata_json"):
            tasks.append(
                (
                    "manifest_metadata",
                    asyncio.to_thread(fetch_manifest_metadata, tool_ctx),
                )
            )
        else:
            tool_state["manifest_metadata_json"] = state["manifest_metadata_json"]

        if not state.get("job_samples_json"):
            tasks.append(
                ("job_samples", asyncio.to_thread(fetch_job_samples, tool_ctx))
            )
        else:
            tool_state["job_samples_json"] = state["job_samples_json"]

        if not state.get("column_types_json"):
            tasks.append(
                ("column_types", asyncio.to_thread(fetch_column_types, tool_ctx))
            )
        else:
            tool_state["column_types_json"] = state["column_types_json"]

        if not state.get("downstream_source_files_json"):
            tasks.append(
                (
                    "downstream_sources",
                    asyncio.to_thread(fetch_downstream_sources, tool_ctx),
                )
            )
        else:
            tool_state["downstream_source_files_json"] = state[
                "downstream_source_files_json"
            ]

        if tasks:
            labels = [t[0] for t in tasks]
            coros = [t[1] for t in tasks]
            results = await asyncio.gather(*coros, return_exceptions=True)

            for label, result in zip(labels, results):
                if isinstance(result, Exception):
                    logger.warning("Context fetch failed for %s: %s", label, result)

        # Build state_delta from keys written by tool functions
        state_delta: dict[str, Any] = {}
        for key in (
            "source_files_json",
            "compiled_sql",
            "upstream_models_json",
            "manifest_metadata_json",
            "job_samples_json",
            "column_types_json",
            "downstream_source_files_json",
        ):
            if key in tool_state and tool_state[key] != state.get(key):
                state_delta[key] = tool_state[key]

        logger.info(
            "ParallelContextGatherer completed: fetched_keys=%s",
            list(state_delta.keys()),
        )

        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            actions=EventActions(state_delta=state_delta)
            if state_delta
            else EventActions(),
        )


class SpecialistSolverAgent(BaseAgent):
    """Specialist LLM solver with a focused system instruction.

    Like GeneralSolver but applies a per-opportunity-type system instruction
    to the LLM request (via SolutionRequest.specialist_instruction).
    Reads context from session state and calls the injected LLMProvider.

    On retry iterations (when validation_feedback is in state), the feedback
    is appended to the specialist instruction so the LLM can correct its prior
    attempt. This enables the LoopAgent-based validation loop (Phase 5).
    """

    model_config = {"arbitrary_types_allowed": True, "extra": "forbid"}

    llm_provider: Any
    specialist_instruction: str

    async def _run_async_impl(self, ctx: "InvocationContext"):
        from governor_core.agents.specialists.general import _build_request_from_state

        state = ctx.session.state
        request = _build_request_from_state(state)

        # Build effective instruction — include validation feedback on retries
        effective_instruction = self.specialist_instruction
        feedback = state.get("validation_feedback")
        retry_count = state.get("retry_count", 0)
        if feedback and retry_count > 0:
            effective_instruction = (
                f"{self.specialist_instruction}\n\n"
                f"## Previous Attempt Validation Feedback (Retry {retry_count})\n"
                f"Your previous solution failed validation. Please correct the following issues:\n"
                f"{feedback}"
            )
            logger.info(
                "%s retry %d with feedback: %s", self.name, retry_count, feedback[:200]
            )

        # Inject the specialist system instruction so GeminiProvider prepends
        # it to the user prompt (see SolutionRequest.specialist_instruction).
        request = request.model_copy(
            update={"specialist_instruction": effective_instruction}
        )

        try:
            response, metadata = await asyncio.to_thread(
                self.llm_provider.generate, request
            )
        except (LLMRequestError, LLMResponseValidationError) as exc:
            logger.error("SpecialistSolverAgent LLM call failed: %s", exc)
            raise

        solution_json = response.model_dump_json()
        metadata_json = metadata.model_dump_json()

        logger.info(
            "%s completed: category=%s, tokens=%d",
            self.name,
            response.resolution_category,
            metadata.total_tokens,
        )

        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            actions=EventActions(
                state_delta={
                    "raw_solution_json": solution_json,
                    "generation_metadata_json": metadata_json,
                }
            ),
        )


class ValidatorAgent(BaseAgent):
    """Validates the draft solution in state and signals loop exit if valid.

    Calls validate_and_maybe_exit() to check the solution. If valid,
    validate_and_maybe_exit() sets escalate=True (exits LoopAgent) and
    copies raw_solution_json → solution_json. If invalid, it writes
    validation_feedback to state for the next solver iteration.

    This agent exists within a LoopAgent alongside SpecialistSolverAgent.
    """

    async def _run_async_impl(self, ctx: "InvocationContext"):
        from governor_core.agents.tools import validate_and_maybe_exit

        state = ctx.session.state

        # Use a COPY of state so we can compute a meaningful delta after the tool runs.
        # validate_and_maybe_exit() writes to tool_ctx.state — comparing the copy to
        # the original lets us build state_delta accurately.
        tool_state: dict[str, Any] = dict(state)

        class _Actions:
            escalate: bool = False

        class _ToolCtx:
            def __init__(self, s: dict) -> None:
                self.state = s
                self.actions = _Actions()

        tool_ctx = _ToolCtx(tool_state)
        result = validate_and_maybe_exit(tool_ctx)

        escalate = bool(tool_ctx.actions.escalate)
        state_delta: dict[str, Any] = {}

        # Propagate state changes made by the tool (tool_state vs original state)
        for key in (
            "validation_passed",
            "validation_feedback",
            "validation_report_json",
            "retry_count",
            "solution_json",
        ):
            if key in tool_state and tool_state[key] != state.get(key):
                state_delta[key] = tool_state[key]

        logger.info(
            "ValidatorAgent: status=%s, escalate=%s, retry_count=%s",
            result.get("status"),
            escalate,
            state.get("retry_count", 0),
        )

        from google.adk.events import EventActions as _EA

        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            actions=_EA(state_delta=state_delta, escalate=escalate),
        )


_MAX_REFINEMENT_ITERATIONS = 3


def build_specialist_pipeline(
    name: str,
    specialist_instruction: str,
    llm_provider: Any,
    github_client: Any = None,
    db_session: Any = None,
    db_session_factory: Any = None,
    local_project_path: str | None = None,
    max_iterations: int = _MAX_REFINEMENT_ITERATIONS,
) -> SequentialAgent:
    """Build a SequentialAgent for a focused opportunity-type specialist.

    The pipeline has three stages:
    1. ParallelContextGathererAgent — fetches all 5 context types concurrently.
    2. LoopAgent("RefinementLoop") — wraps SpecialistSolverAgent + ValidatorAgent:
       - SpecialistSolverAgent generates a solution (calls LLM with focused instruction)
       - ValidatorAgent validates the solution; if valid sets escalate=True to exit loop;
         if invalid writes validation_feedback to state for the next iteration
    3. Post-loop check raises LLMResponseValidationError if no valid solution produced.

    Args:
        name: Pipeline name (e.g. "JoinExplosionPipeline").
        specialist_instruction: System-level focused instruction for the LLM.
        llm_provider: Injected LLMProvider (e.g. GeminiProvider).
        github_client: Optional GitHub client for source-file context tools.
        db_session: Optional DB session for manifest/job context tools.
        max_iterations: Maximum refinement attempts (default 3).

    Returns:
        SequentialAgent ready to be registered as a sub-agent of OpportunityRouter.
    """
    gatherer = ParallelContextGathererAgent(
        name=f"{name}_ContextGatherer",
        github_client=github_client,
        db_session=db_session,
        db_session_factory=db_session_factory,
        local_project_path=local_project_path,
    )
    solver = SpecialistSolverAgent(
        name=f"{name}_Solver",
        llm_provider=llm_provider,
        specialist_instruction=specialist_instruction,
    )
    validator = ValidatorAgent(name=f"{name}_Validator")

    refinement_loop = LoopAgent(
        name=f"{name}_RefinementLoop",
        sub_agents=[solver, validator],
        max_iterations=max_iterations,
    )

    # Post-loop finalizer: if validation_passed is not True after all iterations,
    # copy raw_solution_json → solution_json as best effort (requires_review tier).
    post_loop = _PostLoopFinalizerAgent(name=f"{name}_Finalizer")

    return SequentialAgent(
        name=name,
        sub_agents=[gatherer, refinement_loop, post_loop],
    )


class _PostLoopFinalizerAgent(BaseAgent):
    """Ensures solution_json is set after the refinement loop completes.

    If validation passed, solution_json was already set by validate_and_maybe_exit.
    If all iterations failed, copies raw_solution_json → solution_json so that
    the pipeline always produces a result (with validation_passed=False flagged).
    """

    async def _run_async_impl(self, ctx: "InvocationContext"):
        state = ctx.session.state
        state_delta: dict[str, Any] = {}

        if not state.get("solution_json") and state.get("raw_solution_json"):
            # All iterations failed — surface best attempt with validation warning
            logger.warning(
                "%s: validation loop exhausted, surfacing best attempt as requires_review",
                self.name,
            )
            state_delta["solution_json"] = state["raw_solution_json"]
            if not state.get("validation_passed"):
                state_delta["validation_passed"] = False

        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            actions=EventActions(state_delta=state_delta)
            if state_delta
            else EventActions(),
        )
