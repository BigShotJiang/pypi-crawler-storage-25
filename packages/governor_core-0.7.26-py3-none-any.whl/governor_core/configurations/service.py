from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from hashlib import sha256

from google.api_core.exceptions import GoogleAPIError
from google.cloud.exceptions import GoogleCloudError
from sqlalchemy.orm import Session

from governor_core.configurations.models import ManifestConfiguration
from governor_core.configurations.schemas import (
    ManifestConfigurationCreate,
    ManifestConfigurationUpdate,
)
from governor_core.gcp.clients import (
    GCPCredentialsError,
    list_gcp_projects,
    list_gcs_buckets,
    list_gcs_path,
    validate_gcs_manifest,
)
from governor_core.opportunities.catalog import build_effective_rule_selection
from governor_core.setup.runtime import create_github_client, is_github_configured

logger = logging.getLogger("app.configurations")


def _resolve_auto_shadow_create_defaults(
    caller_value: bool | None,
) -> dict[str, bool]:
    """Spec 130: compute the kwargs for ``auto_shadow_validate_safe_solutions``
    (and the coupled ``shadow_validation_enabled``) when creating a new
    ``ManifestConfiguration``.

    - When the caller explicitly supplies a value (``True`` or ``False``),
      honour it. A ``True`` also flips ``shadow_validation_enabled`` on
      (preserving spec 124's coupling; the worker gate requires both).
    - When the caller supplies ``None`` (unspecified) AND we are in CLI/local
      mode, default both flags to ``True``.
    - Otherwise (cloud/PR mode, or mode detection fails), return ``{}`` so the
      column-level default (``False``) takes effect. Fail-closed on the safer
      side.
    """
    if caller_value is True:
        return {
            "auto_shadow_validate_safe_solutions": True,
            "shadow_validation_enabled": True,
        }
    if caller_value is False:
        return {"auto_shadow_validate_safe_solutions": False}

    # caller_value is None — consult mode.
    try:
        from governor_core.core.config import is_local_mode

        if is_local_mode():
            return {
                "auto_shadow_validate_safe_solutions": True,
                "shadow_validation_enabled": True,
            }
    except Exception:  # noqa: BLE001 — mode detection must never break creation
        logger.warning(
            "spec-130: is_local_mode() raised; falling back to cloud default (False)",
            exc_info=True,
        )
    return {}


# ---------------------------------------------------------------------------
# Module-level TTL caches for dropdown search
# ---------------------------------------------------------------------------

_CACHE_TTL = 300  # 5 minutes

_bucket_cache: dict = {"data": [], "fetched_at": 0.0}
_repo_cache: dict = {"data": [], "fetched_at": 0.0}


class ConfigurationError(Exception):
    """Base error for configuration operations."""


class DuplicateLocationError(ConfigurationError):
    """Raised when duplicate manifest locations are submitted."""


class GCSValidationError(ConfigurationError):
    """Raised when the manifest location fails GCS validation."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class ConcurrencyError(ConfigurationError):
    """Raised when an optimistic concurrency conflict is detected."""


class NotFoundError(ConfigurationError):
    """Raised when a configuration is not found."""


class EnableWithoutGithubError(ConfigurationError):
    """Raised when enabling a config without a remote repo or local path."""


class ManualManifestUploadError(ConfigurationError):
    """Raised when a manual manifest upload fails validation."""


class ManifestConfigurationService:
    def __init__(self, db: Session) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def is_github_configured() -> bool:
        """Return True if all GitHub App settings are present."""
        return is_github_configured()

    # ------------------------------------------------------------------
    # Dropdown search helpers
    # ------------------------------------------------------------------

    def list_all_accessible_buckets(self) -> list[str]:
        """Return all GCS buckets across all accessible GCP projects (cached)."""
        now = time.time()
        if now - _bucket_cache["fetched_at"] < _CACHE_TTL:
            return _bucket_cache["data"]

        projects = list_gcp_projects()
        all_buckets: set[str] = set()
        for project in projects:
            try:
                buckets = list_gcs_buckets(project["project_id"])
                all_buckets.update(buckets)
            except GoogleCloudError, GCPCredentialsError:
                logger.warning(
                    "Failed to list buckets for project %s", project["project_id"]
                )

        result = sorted(all_buckets)
        _bucket_cache["data"] = result
        _bucket_cache["fetched_at"] = time.time()
        return result

    def search_buckets(self, query: str) -> list[str]:
        """Filter accessible buckets by case-insensitive CONTAINS match."""
        buckets = self.list_all_accessible_buckets()
        if not query:
            return buckets
        q = query.lower()
        return [b for b in buckets if q in b.lower()]

    def list_all_accessible_repos(self) -> list[dict[str, str]]:
        """Return all repos from the GitHub App installation (cached)."""
        if not self.is_github_configured():
            return []

        now = time.time()
        if now - _repo_cache["fetched_at"] < _CACHE_TTL:
            return _repo_cache["data"]

        client = create_github_client()
        if client is None:
            return []
        repos = client.list_installation_repos()
        _repo_cache["data"] = repos
        _repo_cache["fetched_at"] = time.time()
        return repos

    def search_repos(self, query: str) -> list[dict[str, str]]:
        """Filter accessible repos by case-insensitive CONTAINS on full_name."""
        repos = self.list_all_accessible_repos()
        if not query:
            return repos
        q = query.lower()
        return [r for r in repos if q in r["full_name"].lower()]

    # ------------------------------------------------------------------
    # GCS path browsing
    # ------------------------------------------------------------------

    @staticmethod
    def search_gcs_paths(bucket_name: str, prefix: str = "") -> dict:
        """List GCS directories under a bucket/prefix for dropdown browsing.

        Returns a dict with ``prefixes`` (list of subdirectory names, capped
        at 10), ``current_prefix`` (the normalised prefix used), and
        ``parent_prefix`` (one level up, or empty string at root).
        """
        try:
            result = list_gcs_path(bucket_name, prefix)
            prefixes = result.get("prefixes", [])[:10]
        except (GoogleCloudError, GCPCredentialsError) as exc:
            logger.warning(
                "GCS path listing failed for %s/%s: %s", bucket_name, prefix, exc
            )
            return {
                "prefixes": [],
                "current_prefix": prefix,
                "parent_prefix": "",
                "error": str(exc),
            }

        # Normalise prefix for consistent display
        current_prefix = prefix
        if current_prefix and not current_prefix.endswith("/"):
            current_prefix += "/"

        # Compute parent prefix
        parent_prefix = ""
        if current_prefix:
            # Remove trailing slash, then go up one level
            trimmed = current_prefix.rstrip("/")
            if "/" in trimmed:
                parent_prefix = trimmed.rsplit("/", 1)[0] + "/"
            # else: parent is root (empty string)

        return {
            "prefixes": prefixes,
            "current_prefix": current_prefix,
            "parent_prefix": parent_prefix,
        }

    # ------------------------------------------------------------------
    # GCP project helpers
    # ------------------------------------------------------------------

    def get_available_gcp_projects(self) -> list[dict[str, str]]:
        """Return all GCP projects (no filtering — multiple configs per project allowed)."""
        return list_gcp_projects()

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def create_configuration(
        self,
        data: ManifestConfigurationCreate,
        user_id: str,
    ) -> ManifestConfiguration:
        """Create a new manifest configuration.

        Schedule validation and APScheduler registration are responsibilities
        of the shell (web/cli). This service persists the configuration only.
        """
        # Check for duplicate manifest location globally
        self._check_duplicate_location(
            data.manifest_source,
            data.bucket_name,
            data.path_prefix,
            data.object_name,
        )

        # Validate manifest location against GCS
        self._validate_location(
            data.manifest_source,
            data.bucket_name,
            data.path_prefix,
            data.object_name,
        )

        # Resolve display name for default naming
        gcp_project_name = self._resolve_gcp_project_name(data.gcp_project_id)

        name = self._derive_default_name(data, gcp_project_name)

        config = ManifestConfiguration(
            name=name.strip(),
            gcp_project_id=data.gcp_project_id,
            gcp_project_name=gcp_project_name,
            github_repo=data.github_repo,
            manifest_source=data.manifest_source,
            bucket_name=data.bucket_name,
            path_prefix=data.path_prefix,
            object_name=data.object_name,
            status="active",
            lookback_window_days=data.lookback_window_days,
            resolution_period_days=data.resolution_period_days,
            auto_pr_trust_tier=data.auto_pr_trust_tier,
            local_project_path=getattr(data, "local_project_path", None),
            watched_rule_types=data.watched_rule_types,
            allowed_solution_policy_tags=data.allowed_solution_policy_tags,
            min_solution_cost_usd=data.min_solution_cost_usd,
            storage_billing_min_savings_usd=data.storage_billing_min_savings_usd,
            # Checkbox: only set when explicitly posted. Defaults to the
            # column default (False) otherwise. Enabling auto-validate also
            # flips the master shadow_validation_enabled switch — the two
            # are coupled because the worker gate requires both, and the UI
            # only exposes the one checkbox.
            #
            # Spec 130: when the caller did not supply a value AND we are in
            # CLI/local mode, default the flag to True. Cloud/PR mode falls
            # through to the column default (False). Fail-closed on any
            # mode-detection error — preserving the safer cloud default.
            **_resolve_auto_shadow_create_defaults(
                data.auto_shadow_validate_safe_solutions
            ),
            schedule_type=data.schedule_type,
            schedule_value=data.schedule_value,
            schedule_enabled=data.schedule_enabled,
            created_by_id=user_id,
            updated_by_id=user_id,
        )
        self._db.add(config)
        self._db.commit()
        self._db.refresh(config)

        return config

    def get_configuration(self, config_id: str) -> ManifestConfiguration | None:
        """Fetch a configuration by ID."""
        return (
            self._db.query(ManifestConfiguration)
            .filter(ManifestConfiguration.id == config_id)
            .one_or_none()
        )

    def list_configurations(self) -> list[ManifestConfiguration]:
        """List all configurations ordered by name."""
        return (
            self._db.query(ManifestConfiguration)
            .order_by(ManifestConfiguration.name)
            .all()
        )

    def update_configuration(
        self,
        config_id: str,
        data: ManifestConfigurationUpdate,
        user_id: str,
    ) -> ManifestConfiguration:
        """Update an existing configuration with optimistic concurrency.

        Schedule validation and APScheduler registration are responsibilities
        of the shell (web/cli).
        """
        config = self.get_configuration(config_id)
        if not config:
            raise NotFoundError(f"Configuration '{config_id}' not found.")

        # Optimistic concurrency check
        if config.version != data.version:
            raise ConcurrencyError(
                "This configuration was modified by another user. "
                "Please reload and try again."
            )

        # Check for duplicate manifest location (excluding self)
        self._check_duplicate_location(
            data.manifest_source,
            data.bucket_name,
            data.path_prefix,
            data.object_name,
            exclude_id=config_id,
        )

        # Validate manifest location against GCS
        self._validate_location(
            data.manifest_source,
            data.bucket_name,
            data.path_prefix,
            data.object_name,
        )

        # Schedule validation is a shell concern (web/cli).
        previous_selection = build_effective_rule_selection(config.watched_rule_types)
        new_selection = build_effective_rule_selection(data.watched_rule_types)
        deselected_rule_types = set(previous_selection.configured_rule_types) - set(
            new_selection.configured_rule_types
        )

        # Update fields
        explicit_name = (data.name or "").strip() if data.name is not None else ""
        if explicit_name:
            config.name = explicit_name
        elif data.local_project_path:
            local_name = self._derive_local_project_name(data.local_project_path)
            if local_name:
                config.name = local_name
        config.github_repo = data.github_repo
        if data.gcp_project_id is not None:
            config.gcp_project_id = data.gcp_project_id
        config.manifest_source = data.manifest_source
        config.bucket_name = data.bucket_name
        config.path_prefix = data.path_prefix
        config.object_name = data.object_name
        config.lookback_window_days = data.lookback_window_days
        config.resolution_period_days = data.resolution_period_days
        config.auto_pr_trust_tier = data.auto_pr_trust_tier
        config.local_project_path = data.local_project_path
        config.storage_billing_min_savings_usd = data.storage_billing_min_savings_usd
        config.min_solution_cost_usd = data.min_solution_cost_usd
        config.watched_rule_types = data.watched_rule_types
        config.allowed_solution_policy_tags = data.allowed_solution_policy_tags
        if data.auto_shadow_validate_safe_solutions is not None:
            config.auto_shadow_validate_safe_solutions = (
                data.auto_shadow_validate_safe_solutions
            )
            # Coupled flag: enabling auto-validate implies the master
            # shadow_validation_enabled toggle is on. The worker requires
            # both, and the UI only exposes this one checkbox.
            if data.auto_shadow_validate_safe_solutions:
                config.shadow_validation_enabled = True

        # Update schedule fields if provided
        if data.schedule_type is not None:
            config.schedule_type = data.schedule_type
        if data.schedule_value is not None:
            config.schedule_value = data.schedule_value
        if data.schedule_enabled is not None:
            config.schedule_enabled = data.schedule_enabled

        config.updated_by_id = user_id
        config.updated_at = datetime.now(timezone.utc)
        config.version += 1

        self._db.commit()
        self._db.refresh(config)

        # APScheduler registration on schedule changes is a shell concern.
        if deselected_rule_types:
            from governor_core.opportunities.service import OpportunityService

            opportunity_service = OpportunityService(self._db)
            opportunity_service.resolve_opportunities_for_rule_types(
                config.id, deselected_rule_types
            )
            self._db.commit()
            self._db.refresh(config)

        return config

    def disable_configuration(self, config_id: str, user_id: str) -> None:
        """Disable a configuration."""
        config = self.get_configuration(config_id)
        if not config:
            raise NotFoundError(f"Configuration '{config_id}' not found.")
        config.status = "disabled"
        config.updated_by_id = user_id
        config.updated_at = datetime.now(timezone.utc)
        config.version += 1
        self._db.commit()

    def enable_configuration(self, config_id: str, user_id: str) -> None:
        """Enable a disabled configuration."""
        config = self.get_configuration(config_id)
        if not config:
            raise NotFoundError(f"Configuration '{config_id}' not found.")
        if not config.github_repo and not config.local_project_path:
            raise EnableWithoutGithubError(
                "Cannot enable configuration without a repository or local dbt project path. "
                "Please set one first."
            )
        config.status = "active"
        config.updated_by_id = user_id
        config.updated_at = datetime.now(timezone.utc)
        config.version += 1
        self._db.commit()

    def delete_configuration(self, config_id: str) -> None:
        """Delete a configuration."""
        config = self.get_configuration(config_id)
        if not config:
            raise NotFoundError(f"Configuration '{config_id}' not found.")
        self._db.delete(config)
        self._db.commit()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_gcp_project_name(self, gcp_project_id: str) -> str | None:
        """Look up the display name for a GCP project ID."""
        try:
            projects = list_gcp_projects()
            for p in projects:
                if p["project_id"] == gcp_project_id:
                    return p["display_name"] or None
        except GoogleCloudError, GCPCredentialsError, GoogleAPIError:
            logger.warning("Could not resolve GCP project name for %s", gcp_project_id)
        return None

    def _derive_default_name(
        self,
        data: ManifestConfigurationCreate,
        gcp_project_name: str | None,
    ) -> str:
        """Derive a stable configuration name for both cloud and local projects."""
        explicit_name = (data.name or "").strip()
        if explicit_name:
            return explicit_name

        if data.local_project_path:
            local_name = self._derive_local_project_name(data.local_project_path)
            if local_name:
                return local_name

        repo = data.github_repo.rstrip("/").removesuffix(".git")
        if repo:
            return repo.split("/")[-1] if "/" in repo else repo

        if gcp_project_name:
            return gcp_project_name

        gcp_project_id = data.gcp_project_id.strip()
        if gcp_project_id:
            return gcp_project_id

        return "local-project"

    @staticmethod
    def _derive_local_project_name(local_project_path: str) -> str | None:
        normalized_path = local_project_path.strip()
        if not normalized_path:
            return None

        # Prefer the dbt project's ``name`` from ``dbt_project.yml`` via the
        # workspace detector (which also walks parents to find the project
        # root). Falls back to the path basename if detection fails.
        try:
            from governor_core.workspace.detection import detect_workspace

            workspace = detect_workspace(normalized_path)
            if workspace.dbt_project_name:
                return workspace.dbt_project_name
            if workspace.project_path:
                normalized_path = workspace.project_path
        except ImportError, OSError:
            logger.debug(
                "Workspace detection unavailable while deriving local project name",
                exc_info=True,
            )

        project_dir = os.path.basename(os.path.normpath(normalized_path))
        return project_dir or None

    def _check_duplicate_location(
        self,
        manifest_source: str,
        bucket_name: str | None,
        path_prefix: str | None,
        object_name: str | None,
        exclude_id: str | None = None,
    ) -> None:
        """Raise if a configuration with the same manifest location already exists."""
        if manifest_source != "gcs":
            return

        query = self._db.query(ManifestConfiguration).filter(
            ManifestConfiguration.bucket_name == bucket_name,
            ManifestConfiguration.path_prefix == path_prefix,
            ManifestConfiguration.object_name == object_name,
        )
        if exclude_id:
            query = query.filter(ManifestConfiguration.id != exclude_id)
        existing = query.one_or_none()
        if existing:
            raise DuplicateLocationError(
                f"A configuration already exists for manifest location: "
                f"gs://{bucket_name}/{path_prefix}/{object_name}"
            )

    def _validate_location(
        self,
        manifest_source: str,
        bucket_name: str | None,
        path_prefix: str | None,
        object_name: str | None,
    ) -> None:
        """Validate manifest location against GCS. Raises on failure."""
        if manifest_source != "gcs":
            return

        result = validate_gcs_manifest(
            bucket_name or "",
            path_prefix or "",
            object_name or "",
        )
        if not result.valid:
            raise GCSValidationError(result.error or "Unknown validation error")

    def store_uploaded_manifest(
        self,
        config_id: str,
        manifest_bytes: bytes,
        user_id: str,
    ) -> tuple[ManifestConfiguration, bool]:
        from governor_core.sync.models import ManifestVersion, SyncOperation

        config = self.get_configuration(config_id)
        if not config:
            raise NotFoundError(f"Configuration '{config_id}' not found.")
        if config.manifest_source not in {"manual_upload", "local"}:
            raise ManualManifestUploadError(
                "Manual uploads are only available for manual-upload configurations."
            )

        try:
            manifest_content = json.loads(manifest_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ManualManifestUploadError(
                "Manifest upload must be valid UTF-8 JSON."
            ) from exc

        if not isinstance(manifest_content, dict):
            raise ManualManifestUploadError("Manifest upload must be a JSON object.")

        now = datetime.now(timezone.utc)
        content_hash = sha256(
            json.dumps(manifest_content, sort_keys=True).encode("utf-8")
        ).hexdigest()

        latest_version = (
            self._db.query(ManifestVersion)
            .filter(ManifestVersion.config_id == config_id)
            .order_by(ManifestVersion.retrieved_at.desc())
            .first()
        )

        sync = SyncOperation(
            config_id=config.id,
            status="completed",
            queued_at=now,
            started_at=now,
            completed_at=now,
            triggered_by="manual_upload",
            initiated_by_id=user_id,
        )
        self._db.add(sync)
        self._db.flush()

        created_new_version = False
        if latest_version and latest_version.content_hash == content_hash:
            sync.manifests_updated_count = 0
            sync.used_manifest_version_id = latest_version.id
        else:
            manifest_version = ManifestVersion(
                config_id=config.id,
                sync_id=sync.id,
                content_hash=content_hash,
                content=manifest_content,
                retrieved_at=now,
            )
            self._db.add(manifest_version)
            self._db.flush()
            sync.manifests_updated_count = 1
            sync.used_manifest_version_id = manifest_version.id
            created_new_version = True

        self._db.commit()
        self._db.refresh(config)
        return config, created_new_version
