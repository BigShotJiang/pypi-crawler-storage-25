from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from governor_core.db.base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class ManifestConfiguration(Base):
    __tablename__ = "manifest_configurations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    gcp_project_id: Mapped[str] = mapped_column(String(128), nullable=False)
    gcp_project_name: Mapped[Optional[str]] = mapped_column(String(255))
    github_repo: Mapped[Optional[str]] = mapped_column(String(512))
    manifest_source: Mapped[str] = mapped_column(
        String(32), nullable=False, default="gcs"
    )
    bucket_name: Mapped[Optional[str]] = mapped_column(String(222), nullable=True)
    path_prefix: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    object_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="active")
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    created_by_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )
    updated_by_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=False
    )

    # Rolling observation window settings
    lookback_window_days: Mapped[int | None] = mapped_column(
        Integer, nullable=True, default=None
    )
    resolution_period_days: Mapped[int | None] = mapped_column(
        Integer, nullable=True, default=None
    )

    # Auto-PR override
    auto_pr_trust_tier: Mapped[Optional[str]] = mapped_column(String(16), nullable=True)

    # Local workspace path (spec 084) — dbt project root on developer's machine
    local_project_path: Mapped[Optional[str]] = mapped_column(
        String(1024), nullable=True
    )

    # Storage billing analysis threshold
    storage_billing_min_savings_usd: Mapped[Optional[float]] = mapped_column(
        Numeric(precision=12, scale=2), nullable=True, default=None
    )

    # Minimum query cost to generate solutions — opportunities below this are
    # detected but not queued for solution generation.
    min_solution_cost_usd: Mapped[Optional[float]] = mapped_column(
        Numeric(precision=12, scale=2), nullable=True, default=None
    )

    # Per-project watched detection rules. NULL = inherit all enabled rules.
    watched_rule_types: Mapped[list[str] | None] = mapped_column(
        JSONB, nullable=True, default=None
    )

    # Per-project allowed solution policy tags. NULL = inherit all supported tags.
    allowed_solution_policy_tags: Mapped[list[str] | None] = mapped_column(
        JSONB, nullable=True, default=None
    )

    # Shadow validation (spec 110)
    shadow_validation_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    # Spec 124: auto-run shadow validation for Safe (low-risk) solutions
    auto_shadow_validate_safe_solutions: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    shadow_budget_usd: Mapped[float] = mapped_column(
        Numeric(precision=10, scale=4), nullable=False, default=10.0
    )
    shadow_cascade_cap: Mapped[int] = mapped_column(
        Integer, nullable=False, default=20
    )
    shadow_timeout_seconds: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1800
    )
    shadow_reconciliation_threshold_hours: Mapped[int] = mapped_column(
        Integer, nullable=False, default=24
    )

    # Schedule settings
    schedule_type: Mapped[str] = mapped_column(
        String(16), nullable=False, default="interval"
    )
    schedule_value: Mapped[str] = mapped_column(
        String(128), nullable=False, default="24"
    )
    schedule_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True
    )
    schedule_last_run_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    sync_operations: Mapped[list["SyncOperation"]] = relationship(  # noqa: F821
        "SyncOperation",
        back_populates="configuration",
        cascade="all, delete-orphan",
    )
    manifest_versions: Mapped[list["ManifestVersion"]] = relationship(  # noqa: F821
        "ManifestVersion",
        back_populates="configuration",
        cascade="all, delete-orphan",
    )
    opportunities: Mapped[list["Opportunity"]] = relationship(  # noqa: F821
        "Opportunity",
        back_populates="configuration",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("ix_mc_gcp_project_id", "gcp_project_id"),
        Index("ix_mc_status", "status"),
        Index("ix_mc_schedule_enabled", "schedule_enabled"),
        UniqueConstraint(
            "bucket_name",
            "path_prefix",
            "object_name",
            name="uq_mc_manifest_location",
        ),
    )
