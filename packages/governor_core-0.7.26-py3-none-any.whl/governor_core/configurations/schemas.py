from __future__ import annotations

import re
from datetime import datetime

from pydantic import BaseModel, field_validator, model_validator

from governor_core.opportunities.catalog import get_detection_rule_map
from governor_core.solutions.policy import get_solution_policy_map

# GCS bucket naming rules: 3-222 chars, lowercase letters/numbers/hyphens/underscores/dots,
# must start and end with letter or number.
_BUCKET_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,220}[a-z0-9]$")

# GitHub repo format: owner/repo or full URL
_GITHUB_REPO_RE = re.compile(
    r"^([a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+|https?://github\.com/[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+)$"
)


def _normalize_optional_path(value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip()
    return value or None


# ---------------------------------------------------------------------------
# Input schemas
# ---------------------------------------------------------------------------


class ManifestConfigurationCreate(BaseModel):
    gcp_project_id: str
    name: str | None = None
    github_repo: str
    manifest_source: str = "gcs"
    bucket_name: str | None = None
    path_prefix: str | None = ""
    object_name: str | None = "manifest.json"
    schedule_type: str = "interval"
    schedule_value: str = "24"
    schedule_enabled: bool = True
    lookback_window_days: int | None = None
    resolution_period_days: int | None = None
    auto_pr_trust_tier: str | None = None
    local_project_path: str | None = None
    watched_rule_types: list[str] | None = None
    allowed_solution_policy_tags: list[str] | None = None
    min_solution_cost_usd: float | None = None
    # Fields added to keep the "New Configuration" form aligned with the
    # "Edit Configuration" form (detail.html) — both pages now accept the
    # same advanced-settings knobs.
    storage_billing_min_savings_usd: float | None = None
    auto_shadow_validate_safe_solutions: bool | None = None

    @field_validator("min_solution_cost_usd")
    @classmethod
    def validate_min_solution_cost_create(cls, v: float | None) -> float | None:
        if v is not None and v < 0:
            raise ValueError("Minimum solution cost must be 0 or greater.")
        return v

    @field_validator("storage_billing_min_savings_usd")
    @classmethod
    def validate_storage_billing_min_savings_create(
        cls, v: float | None
    ) -> float | None:
        if v is not None and v < 0:
            raise ValueError("Minimum savings threshold must be 0 or greater.")
        return v

    @field_validator("auto_pr_trust_tier")
    @classmethod
    def validate_auto_pr_trust_tier(cls, v: str | None) -> str | None:
        if v is not None and v not in (
            "disabled",
            "guaranteed_safe",
            "validated",
            "requires_review",
        ):
            raise ValueError("Invalid auto-PR trust tier.")
        return v

    @field_validator("lookback_window_days")
    @classmethod
    def validate_lookback(cls, v: int | None) -> int | None:
        if v is not None and v < 1:
            raise ValueError("Lookback window must be at least 1 day.")
        return v

    @field_validator("resolution_period_days")
    @classmethod
    def validate_resolution(cls, v: int | None) -> int | None:
        if v is not None and v < 1:
            raise ValueError("Resolution period must be at least 1 day.")
        return v

    @field_validator("watched_rule_types")
    @classmethod
    def validate_watched_rule_types(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return None
        valid_rule_ids = set(get_detection_rule_map())
        deduped: list[str] = []
        seen: set[str] = set()
        invalid: list[str] = []
        for rule_type in v:
            value = str(rule_type).strip()
            if not value or value in seen:
                continue
            if value not in valid_rule_ids:
                invalid.append(value)
                continue
            deduped.append(value)
            seen.add(value)
        if invalid:
            raise ValueError("Unknown watched rule ids: " + ", ".join(sorted(invalid)))
        return deduped

    @field_validator("allowed_solution_policy_tags")
    @classmethod
    def validate_allowed_solution_policy_tags(
        cls, v: list[str] | None
    ) -> list[str] | None:
        if v is None:
            return None
        valid_policy_ids = set(get_solution_policy_map())
        deduped: list[str] = []
        seen: set[str] = set()
        invalid: list[str] = []
        for policy_tag in v:
            value = str(policy_tag).strip()
            if not value or value in seen:
                continue
            if value not in valid_policy_ids:
                invalid.append(value)
                continue
            deduped.append(value)
            seen.add(value)
        if invalid:
            raise ValueError(
                "Unknown solution policy tags: " + ", ".join(sorted(invalid))
            )
        return deduped

    @field_validator("gcp_project_id")
    @classmethod
    def validate_gcp_project_id(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("GCP project selection is required.")
        return v

    @field_validator("manifest_source")
    @classmethod
    def validate_manifest_source(cls, v: str) -> str:
        value = v.strip() or "gcs"
        if value not in {"gcs", "manual_upload", "local"}:
            raise ValueError("Invalid manifest source.")
        return value

    @field_validator("local_project_path")
    @classmethod
    def validate_local_project_path(cls, v: str | None) -> str | None:
        return _normalize_optional_path(v)

    @field_validator("github_repo")
    @classmethod
    def validate_github_repo(cls, v: str) -> str:
        v = v.strip()
        if not v:
            return ""
        if not _GITHUB_REPO_RE.match(v):
            raise ValueError(
                "Invalid GitHub repository format. Use 'owner/repo' or "
                "'https://github.com/owner/repo'."
            )
        return v

    @field_validator("bucket_name")
    @classmethod
    def validate_bucket_name(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        if not v:
            return None
        if not _BUCKET_NAME_RE.match(v):
            raise ValueError(
                "Invalid bucket name. Use 3-222 characters: lowercase letters, "
                "numbers, hyphens, underscores, or dots. Must start and end with "
                "a letter or number."
            )
        return v

    @field_validator("path_prefix")
    @classmethod
    def validate_path_prefix(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip().rstrip("/")
        if v.startswith("/"):
            raise ValueError("Path prefix must not start with '/'.")
        return v

    @field_validator("object_name")
    @classmethod
    def validate_object_name(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        if not v:
            return None
        return v

    @model_validator(mode="after")
    def validate_manifest_location(self):
        if self.manifest_source in {"manual_upload", "local"}:
            self.bucket_name = None
            self.path_prefix = None
            self.object_name = None
            return self

        if not self.bucket_name:
            raise ValueError("Bucket name is required.")
        if not self.object_name:
            raise ValueError("Object name is required.")
        if self.path_prefix is None:
            self.path_prefix = ""
        return self


class ManifestConfigurationUpdate(BaseModel):
    name: str | None = None
    gcp_project_id: str | None = None
    github_repo: str
    manifest_source: str = "gcs"
    bucket_name: str | None = None
    path_prefix: str | None = ""
    object_name: str | None = "manifest.json"
    version: int
    lookback_window_days: int | None = None
    resolution_period_days: int | None = None
    auto_pr_trust_tier: str | None = None
    local_project_path: str | None = None
    schedule_type: str | None = None
    schedule_value: str | None = None
    schedule_enabled: bool | None = None
    storage_billing_min_savings_usd: float | None = None
    min_solution_cost_usd: float | None = None
    watched_rule_types: list[str] | None = None
    allowed_solution_policy_tags: list[str] | None = None
    auto_shadow_validate_safe_solutions: bool | None = None

    @field_validator("storage_billing_min_savings_usd")
    @classmethod
    def validate_storage_billing_min_savings(cls, v: float | None) -> float | None:
        if v is not None and v < 0:
            raise ValueError("Minimum savings threshold must be 0 or greater.")
        return v

    @field_validator("min_solution_cost_usd")
    @classmethod
    def validate_min_solution_cost(cls, v: float | None) -> float | None:
        if v is not None and v < 0:
            raise ValueError("Minimum solution cost must be 0 or greater.")
        return v

    @field_validator("auto_pr_trust_tier")
    @classmethod
    def validate_auto_pr_trust_tier(cls, v: str | None) -> str | None:
        if v is not None and v not in (
            "disabled",
            "guaranteed_safe",
            "validated",
            "requires_review",
        ):
            raise ValueError("Invalid auto-PR trust tier.")
        return v

    @field_validator("manifest_source")
    @classmethod
    def validate_manifest_source(cls, v: str) -> str:
        value = v.strip() or "gcs"
        if value not in {"gcs", "manual_upload", "local"}:
            raise ValueError("Invalid manifest source.")
        return value

    @field_validator("gcp_project_id")
    @classmethod
    def validate_update_gcp_project_id(cls, v: str | None) -> str | None:
        if v is None:
            return None
        value = v.strip()
        if not value:
            raise ValueError("GCP project selection is required.")
        return value

    @field_validator("local_project_path")
    @classmethod
    def validate_local_project_path(cls, v: str | None) -> str | None:
        return _normalize_optional_path(v)

    @field_validator("lookback_window_days")
    @classmethod
    def validate_lookback(cls, v: int | None) -> int | None:
        if v is not None and v < 1:
            raise ValueError("Lookback window must be at least 1 day.")
        return v

    @field_validator("resolution_period_days")
    @classmethod
    def validate_resolution(cls, v: int | None) -> int | None:
        if v is not None and v < 1:
            raise ValueError("Resolution period must be at least 1 day.")
        return v

    @field_validator("watched_rule_types")
    @classmethod
    def validate_watched_rule_types(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return None
        valid_rule_ids = set(get_detection_rule_map())
        deduped: list[str] = []
        seen: set[str] = set()
        invalid: list[str] = []
        for rule_type in v:
            value = str(rule_type).strip()
            if not value or value in seen:
                continue
            if value not in valid_rule_ids:
                invalid.append(value)
                continue
            deduped.append(value)
            seen.add(value)
        if invalid:
            raise ValueError("Unknown watched rule ids: " + ", ".join(sorted(invalid)))
        return deduped

    @field_validator("allowed_solution_policy_tags")
    @classmethod
    def validate_allowed_solution_policy_tags(
        cls, v: list[str] | None
    ) -> list[str] | None:
        if v is None:
            return None
        valid_policy_ids = set(get_solution_policy_map())
        deduped: list[str] = []
        seen: set[str] = set()
        invalid: list[str] = []
        for policy_tag in v:
            value = str(policy_tag).strip()
            if not value or value in seen:
                continue
            if value not in valid_policy_ids:
                invalid.append(value)
                continue
            deduped.append(value)
            seen.add(value)
        if invalid:
            raise ValueError(
                "Unknown solution policy tags: " + ", ".join(sorted(invalid))
            )
        return deduped

    @field_validator("github_repo")
    @classmethod
    def validate_github_repo(cls, v: str) -> str:
        v = v.strip()
        if not v:
            return ""
        if not _GITHUB_REPO_RE.match(v):
            raise ValueError(
                "Invalid GitHub repository format. Use 'owner/repo' or "
                "'https://github.com/owner/repo'."
            )
        return v

    @field_validator("bucket_name")
    @classmethod
    def validate_bucket_name(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        if not v:
            return None
        if not _BUCKET_NAME_RE.match(v):
            raise ValueError(
                "Invalid bucket name. Use 3-222 characters: lowercase letters, "
                "numbers, hyphens, underscores, or dots. Must start and end with "
                "a letter or number."
            )
        return v

    @field_validator("path_prefix")
    @classmethod
    def validate_path_prefix(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip().rstrip("/")
        if v.startswith("/"):
            raise ValueError("Path prefix must not start with '/'.")
        return v

    @field_validator("object_name")
    @classmethod
    def validate_object_name(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        if not v:
            return None
        return v

    @model_validator(mode="after")
    def validate_manifest_location(self):
        if self.manifest_source in {"manual_upload", "local"}:
            self.bucket_name = None
            self.path_prefix = None
            self.object_name = None
            return self

        if not self.bucket_name:
            raise ValueError("Bucket name is required.")
        if not self.object_name:
            raise ValueError("Object name is required.")
        if self.path_prefix is None:
            self.path_prefix = ""
        return self


# ---------------------------------------------------------------------------
# Output schemas
# ---------------------------------------------------------------------------


class ManifestConfigurationOut(BaseModel):
    id: str
    name: str
    gcp_project_id: str
    gcp_project_name: str | None
    github_repo: str | None
    manifest_source: str
    bucket_name: str | None
    path_prefix: str | None
    object_name: str | None
    status: str
    version: int
    local_project_path: str | None = None
    lookback_window_days: int | None = None
    resolution_period_days: int | None = None
    watched_rule_types: list[str] | None = None
    allowed_solution_policy_tags: list[str] | None = None
    created_at: datetime
    created_by_id: str
    updated_at: datetime
    updated_by_id: str


class ManifestConfigurationSummary(BaseModel):
    id: str
    name: str
    gcp_project_id: str
    github_repo: str | None
    manifest_source: str
    bucket_name: str | None
    path_prefix: str | None
    object_name: str | None
    status: str
    local_project_path: str | None = None
    lookback_window_days: int | None = None
    resolution_period_days: int | None = None
    watched_rule_types: list[str] | None = None
    allowed_solution_policy_tags: list[str] | None = None
