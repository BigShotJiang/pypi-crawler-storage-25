"""Public API surface of ``governor_core``.

Shells (``governor-web``, ``governor-cli``) SHOULD import from this module
rather than reaching into engine sub-packages. Contract:
``specs/120-monorepo-split/contracts/package-boundaries.md``.
"""

from __future__ import annotations

# --- Database / session -----------------------------------------------------

from governor_core.db.base import Base
from governor_core.db.session import (
    SessionLocal,
    create_engine_for_url,
    engine,
    get_session,
)
from governor_core.db.sqlite_compat import apply_sqlite_compat, attach_sqlite_pragmas

# --- Core settings ----------------------------------------------------------

from governor_core.core.config import Settings, get_settings

# --- Domain models ----------------------------------------------------------

from governor_core.configurations.models import ManifestConfiguration
from governor_core.opportunities.models import (
    DetectionJob,
    Opportunity,
    OpportunityDetectionHistory,
    OpportunitySavingsEstimate,
)
from governor_core.pullrequests.models import PullRequestRecord
from governor_core.shadow.models import ShadowModelExecution, ShadowValidationRun
from governor_core.solutions.models import Solution, SolutionJob
from governor_core.sync.models import (
    BigQueryJob,
    ManifestVersion,
    SyncError,
    SyncOperation,
    TableStorageMetric,
)

# --- Services ---------------------------------------------------------------

from governor_core.configurations.service import ManifestConfigurationService
from governor_core.opportunities.catalog import (
    build_effective_rule_selection,
    get_builtin_rule_classes,
    get_detection_rule_catalog,
    get_detection_rule_map,
    get_grouped_detection_rule_catalog,
    register_detection_rule_class,
)
from governor_core.opportunities.service import OpportunityService
from governor_core.solutions.generator import SolutionGenerator
from governor_core.solutions.service import SolutionService
from governor_core.sync.service import SyncService
from governor_core.sync.worker import Worker

# --- External clients -------------------------------------------------------

from governor_core.dbt.uv_runner import DbtUvRunner
from governor_core.github.client import GitHubAppClient
from governor_core.llm.gemini import GeminiProvider

# --- Telemetry --------------------------------------------------------------

from governor_core.telemetry.tracing import configure_tracing, instrument_sqlalchemy

__all__ = [
    # db
    "Base",
    "SessionLocal",
    "create_engine_for_url",
    "engine",
    "get_session",
    "apply_sqlite_compat",
    "attach_sqlite_pragmas",
    # settings
    "Settings",
    "get_settings",
    # models
    "ManifestConfiguration",
    "DetectionJob",
    "Opportunity",
    "OpportunityDetectionHistory",
    "OpportunitySavingsEstimate",
    "PullRequestRecord",
    "ShadowModelExecution",
    "ShadowValidationRun",
    "Solution",
    "SolutionJob",
    "BigQueryJob",
    "ManifestVersion",
    "SyncError",
    "SyncOperation",
    "TableStorageMetric",
    # services
    "ManifestConfigurationService",
    "OpportunityService",
    "SolutionGenerator",
    "SolutionService",
    "SyncService",
    "Worker",
    "build_effective_rule_selection",
    "get_builtin_rule_classes",
    "get_detection_rule_catalog",
    "get_detection_rule_map",
    "get_grouped_detection_rule_catalog",
    "register_detection_rule_class",
    # external clients
    "DbtUvRunner",
    "GitHubAppClient",
    "GeminiProvider",
    # telemetry
    "configure_tracing",
    "instrument_sqlalchemy",
]
