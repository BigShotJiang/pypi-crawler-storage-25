"""Engine-side runtime config (GCP/GitHub credential resolution)."""
