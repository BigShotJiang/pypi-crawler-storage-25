"""Shared solution guardrail policy catalog and classification helpers."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import yaml

from governor_core.solutions.templates.base import TemplateResult
from governor_core.solutions.templates.config_parser import parse_config_block

_DEFAULT_POLICY_CATALOG: tuple[tuple[str, str, str], ...] = (
    (
        "sql_change",
        "SQL changes",
        "Allow changes to SQL logic inside dbt model files.",
    ),
    (
        "schema_change",
        "Schema/YAML changes",
        "Allow changes to schema, source, or model YAML definitions.",
    ),
    (
        "dbt_config_change",
        "dbt config changes",
        "Allow config-only dbt changes such as cluster_by, partition_by, or require_partition_filter.",
    ),
    (
        "materialization_change",
        "Materialization changes",
        "Allow changes that modify dbt materialization semantics such as table, view, or incremental.",
    ),
    (
        "bigquery_infrastructure",
        "BigQuery infrastructure changes",
        "Allow non-dbt setting recommendations such as storage billing or slot-related infrastructure changes.",
    ),
)

_PROJECT_CONFIG_FILENAMES = frozenset(
    {"dbt_project.yml", "dbt_project.yaml", "packages.yml", "packages.yaml"}
)
_MATERIALIZED_VALUE_RE = re.compile(r"\bmaterialized\s*[:=]")


@dataclass(frozen=True)
class SolutionPolicyCatalogEntry:
    policy_tag: str
    display_name: str
    description: str


@dataclass(frozen=True)
class EffectiveSolutionPolicy:
    mode: Literal["all", "custom"]
    configured_policy_tags: list[str]
    unknown_policy_tags: list[str]
    effective_policy_tags: list[str]


@dataclass(frozen=True)
class SolutionPolicyEvaluation:
    mode: Literal["all", "custom"]
    configured_policy_tags: list[str]
    unknown_policy_tags: list[str]
    effective_policy_tags: list[str]
    candidate_policy_tags: list[str]
    blocked_policy_tags: list[str]
    allowed: bool
    reason: str | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "configured_policy_tags": self.configured_policy_tags,
            "unknown_policy_tags": self.unknown_policy_tags,
            "effective_policy_tags": self.effective_policy_tags,
            "candidate_policy_tags": self.candidate_policy_tags,
            "blocked_policy_tags": self.blocked_policy_tags,
            "allowed": self.allowed,
            "reason": self.reason,
        }


def get_solution_policy_catalog() -> list[SolutionPolicyCatalogEntry]:
    return [
        SolutionPolicyCatalogEntry(
            policy_tag=policy_tag,
            display_name=display_name,
            description=description,
        )
        for policy_tag, display_name, description in _DEFAULT_POLICY_CATALOG
    ]


def get_solution_policy_map() -> dict[str, SolutionPolicyCatalogEntry]:
    return {entry.policy_tag: entry for entry in get_solution_policy_catalog()}


def get_default_solution_policy_tags() -> list[str]:
    return [entry.policy_tag for entry in get_solution_policy_catalog()]


def build_effective_solution_policy(
    configured_policy_tags: list[str] | None,
    catalog: list[SolutionPolicyCatalogEntry] | None = None,
) -> EffectiveSolutionPolicy:
    catalog = catalog or get_solution_policy_catalog()
    policy_map = {entry.policy_tag: entry for entry in catalog}

    if configured_policy_tags is None:
        effective_policy_tags = [entry.policy_tag for entry in catalog]
        return EffectiveSolutionPolicy(
            mode="all",
            configured_policy_tags=effective_policy_tags,
            unknown_policy_tags=[],
            effective_policy_tags=effective_policy_tags,
        )

    deduped_policy_tags = _dedupe_policy_tags(configured_policy_tags)
    effective_policy_tags: list[str] = []
    unknown_policy_tags: list[str] = []

    for policy_tag in deduped_policy_tags:
        if policy_tag not in policy_map:
            unknown_policy_tags.append(policy_tag)
            continue
        effective_policy_tags.append(policy_tag)

    return EffectiveSolutionPolicy(
        mode="custom",
        configured_policy_tags=effective_policy_tags,
        unknown_policy_tags=unknown_policy_tags,
        effective_policy_tags=effective_policy_tags,
    )


def classify_template_policy_tags(template_result: TemplateResult) -> set[str]:
    explicit = {
        str(policy_tag).strip()
        for policy_tag in template_result.policy_tags
        if str(policy_tag).strip()
    }
    if explicit:
        return explicit

    resolution_category = (
        "bigquery_infrastructure"
        if (template_result.parameters or {}).get("resolution_category")
        == "bigquery_infrastructure"
        else "dbt_project_change"
    )
    return classify_solution_policy_tags(
        resolution_category=resolution_category,
        change_type=template_result.change_type or None,
        file_path=template_result.file_path or None,
        before_content=template_result.before_content or None,
        after_content=template_result.after_content or None,
    )


def classify_solution_policy_tags(
    resolution_category: str,
    change_type: str | None,
    file_path: str | None,
    before_content: str | None,
    after_content: str | None,
) -> set[str]:
    if resolution_category == "bigquery_infrastructure":
        return {"bigquery_infrastructure"}

    normalized_file_path = file_path or ""
    filename = Path(normalized_file_path).name
    tags: set[str] = set()

    if normalized_file_path.endswith(".sql"):
        config_changed = _sql_config_changed(before_content, after_content)
        materialized_changed = _sql_materialization_changed(
            before_content, after_content
        )
        sql_body_changed = _sql_body_changed(before_content, after_content)

        if config_changed:
            tags.add("dbt_config_change")
        if materialized_changed:
            tags.update({"dbt_config_change", "materialization_change"})
        if sql_body_changed or not tags:
            tags.add("sql_change")
        return tags

    if normalized_file_path.endswith((".yml", ".yaml")):
        if (
            filename in _PROJECT_CONFIG_FILENAMES
            or change_type == "project_config_change"
        ):
            tags.add("dbt_config_change")
        else:
            tags.add("schema_change")

        if _yaml_materialization_changed(before_content, after_content):
            tags.add("materialization_change")
        return tags

    if change_type == "project_config_change":
        tags.add("dbt_config_change")
        if _text_materialization_changed(before_content, after_content):
            tags.add("materialization_change")
        return tags

    if change_type == "schema_change":
        tags.add("schema_change")
        if _text_materialization_changed(before_content, after_content):
            tags.add("materialization_change")
        return tags

    return {"sql_change"}


def evaluate_solution_policy(
    candidate_policy_tags: set[str] | list[str],
    configured_policy_tags: list[str] | None,
    effective_policy: EffectiveSolutionPolicy | None = None,
) -> SolutionPolicyEvaluation:
    policy = effective_policy or build_effective_solution_policy(configured_policy_tags)
    candidate = sorted(
        {str(tag).strip() for tag in candidate_policy_tags if str(tag).strip()}
    )
    blocked = [tag for tag in candidate if tag not in policy.effective_policy_tags]

    return SolutionPolicyEvaluation(
        mode=policy.mode,
        configured_policy_tags=policy.configured_policy_tags,
        unknown_policy_tags=policy.unknown_policy_tags,
        effective_policy_tags=policy.effective_policy_tags,
        candidate_policy_tags=candidate,
        blocked_policy_tags=blocked,
        allowed=not blocked,
        reason="configuration_disallows_policy_tags" if blocked else None,
    )


def _dedupe_policy_tags(policy_tags: list[str] | None) -> list[str]:
    if not policy_tags:
        return []

    deduped: list[str] = []
    seen: set[str] = set()
    for policy_tag in policy_tags:
        value = str(policy_tag).strip()
        if not value or value in seen:
            continue
        deduped.append(value)
        seen.add(value)
    return deduped


def _sql_config_changed(before_content: str | None, after_content: str | None) -> bool:
    before_props = _sql_config_properties(before_content)
    after_props = _sql_config_properties(after_content)
    return before_props != after_props


def _sql_materialization_changed(
    before_content: str | None, after_content: str | None
) -> bool:
    before_value = _sql_config_properties(before_content).get("materialized")
    after_value = _sql_config_properties(after_content).get("materialized")
    return before_value != after_value


def _sql_body_changed(before_content: str | None, after_content: str | None) -> bool:
    return _strip_sql_config_block(before_content) != _strip_sql_config_block(
        after_content
    )


def _sql_config_properties(content: str | None) -> dict[str, str]:
    if not content:
        return {}

    block = parse_config_block(content)
    if block is None:
        return {}
    return dict(block.properties)


def _strip_sql_config_block(content: str | None) -> str:
    if not content:
        return ""

    block = parse_config_block(content)
    if block is None:
        return content.strip()

    stripped = (content[: block.start] + content[block.end :]).strip()
    return stripped


def _yaml_materialization_changed(
    before_content: str | None, after_content: str | None
) -> bool:
    before_map = _extract_materialized_values(_safe_yaml_load(before_content))
    after_map = _extract_materialized_values(_safe_yaml_load(after_content))
    if before_map is None or after_map is None:
        return _text_materialization_changed(before_content, after_content)
    return before_map != after_map


def _safe_yaml_load(content: str | None) -> Any | None:
    if not content:
        return {}

    try:
        return yaml.safe_load(content) or {}
    except yaml.YAMLError:
        return None


def _extract_materialized_values(
    data: Any,
    prefix: str = "",
) -> dict[str, Any] | None:
    if data is None:
        return None

    values: dict[str, Any] = {}

    if isinstance(data, dict):
        for key, value in data.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            if key == "materialized":
                values[path] = value
            nested = _extract_materialized_values(value, path)
            if nested is None:
                return None
            values.update(nested)
        return values

    if isinstance(data, list):
        for index, item in enumerate(data):
            item_prefix = f"{prefix}[{index}]"
            nested = _extract_materialized_values(item, item_prefix)
            if nested is None:
                return None
            values.update(nested)
        return values

    return values


def _text_materialization_changed(
    before_content: str | None, after_content: str | None
) -> bool:
    before = before_content or ""
    after = after_content or ""
    before_has = bool(_MATERIALIZED_VALUE_RE.search(before))
    after_has = bool(_MATERIALIZED_VALUE_RE.search(after))
    return before_has != after_has or (
        before_has and after_has and before.strip() != after.strip()
    )
