"""Service layer for solution job management and solution CRUD.

Spec 128 (auto-patch downstreams) extends the use of ``Solution.file_changes``
(JSONB, spec 126) without changing its schema. When an ``add_require_partition_filter``
solution's shadow validation surfaces in-project failing downstreams,
``generate_downstream_patches()`` splices per-downstream patch entries into
``Solution.file_changes``. Each spec-128 patch entry carries an optional
``proposal_meta`` sub-dict with the following fields::

    proposal_meta = {
        "upstream_model": str,           # e.g. "events"
        "partition_column": str,         # e.g. "event_date"
        "partition_data_type": str,      # "date" | "timestamp" | "datetime" | "int" | ...
        "proposed_filter": str,          # the suggested filter expression
        "status": "proposed" | "edited" | "manual_required" | "applied",
        "abstain_reason": str | None,    # only present when status == "manual_required"
        "source_shadow_run_id": str,     # UUID of the shadow run that surfaced the failure
        "edited_at": str | None,         # ISO timestamp, set when user overrides filter
    }

State transitions: ``proposed`` → ``edited`` (user override) → ``applied`` (written to disk).
``manual_required`` is emitted when the LLM abstains; transitions to ``edited`` only when
the user hand-writes content. Re-generation preserves ``edited`` and ``applied`` entries
verbatim so user work is never discarded. All spec-128 behaviour is gated on
``is_local_mode()``; in cloud/PR mode this extension is dormant.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from governor_core.core.config import get_settings
from governor_core.opportunities.models import Opportunity
from governor_core.opportunities.presentation import sync_opportunity_solution_snapshots
from governor_core.solutions.exceptions import (
    LLMNotConfiguredError,
    SolutionJobExistsError,
)
from governor_core.solutions.models import Solution, SolutionJob

logger = logging.getLogger("app.solutions.service")

# Fallback used when a configuration has no explicit `min_solution_cost_usd`.
# The recommendation-state resolver imports this so the UI's "Skipped — below
# cost threshold" label stays consistent with what actually gated queueing.
DEFAULT_MIN_SOLUTION_COST_USD = Decimal("5")

# Approximate LLM pricing per million tokens (input, output) in USD.
# Used to compute process cost per solution job.
_LLM_PRICES_PER_MILLION: dict[str, tuple[float, float]] = {
    "gemini-2.0-flash": (0.075, 0.30),
    "gemini-2.0-flash-001": (0.075, 0.30),
    "gemini-1.5-flash": (0.075, 0.30),
    "gemini-1.5-flash-001": (0.075, 0.30),
    "gemini-1.5-pro": (1.25, 5.00),
    "gemini-1.5-pro-001": (1.25, 5.00),
}
_LLM_DEFAULT_PRICES = (0.50, 1.50)  # conservative fallback


def _estimate_llm_cost(
    prompt_tokens: int | None,
    completion_tokens: int | None,
    model: str | None,
) -> Decimal:
    """Return estimated LLM API cost in USD for one solution job invocation."""
    if not prompt_tokens and not completion_tokens:
        return Decimal("0")
    input_price, output_price = _LLM_PRICES_PER_MILLION.get(
        (model or "").lower(), _LLM_DEFAULT_PRICES
    )
    cost = (
        (prompt_tokens or 0) * input_price
        + (completion_tokens or 0) * output_price
    ) / 1_000_000
    return Decimal(str(round(cost, 6)))


def get_solution_job_stale_cutoff() -> datetime:
    """Return the timestamp before which in-progress jobs are considered stale."""
    settings = get_settings()
    return datetime.now(timezone.utc) - timedelta(
        minutes=max(1, settings.solution_job_stale_timeout_minutes)
    )


class SolutionService:
    """Service for solution job lifecycle and solution storage."""

    def __init__(self, db: Session) -> None:
        self._db = db

    def reclaim_stale_in_progress_jobs(
        self, *, opportunity_id: str | None = None
    ) -> int:
        """Mark stale in-progress jobs as failed so they stop blocking work."""
        cutoff = get_solution_job_stale_cutoff()
        query = self._db.query(SolutionJob).filter(
            SolutionJob.status == "in_progress",
            SolutionJob.started_at.isnot(None),
            SolutionJob.started_at < cutoff,
        )
        if opportunity_id:
            query = query.filter(SolutionJob.opportunity_id == opportunity_id)

        stale_jobs = query.all()
        if not stale_jobs:
            return 0

        completed_at = datetime.now(timezone.utc)
        for job in stale_jobs:
            job.status = "failed"
            job.completed_at = completed_at
            job.error_stage = "storage"
            job.error_message = (
                "Marked failed after exceeding the in-progress timeout. "
                "The worker likely exited before completing the job."
            )

        self._db.commit()
        logger.warning(
            "Marked %d stale in-progress solution job(s) as failed",
            len(stale_jobs),
        )
        return len(stale_jobs)

    # ------------------------------------------------------------------
    # Solution Job CRUD (US1)
    # ------------------------------------------------------------------

    def create_solution_job(
        self,
        opportunity_id: str,
        config_id: str,
        detection_job_id: str | None = None,
    ) -> SolutionJob:
        """Queue a solution generation job for an opportunity.

        Raises:
            SolutionJobExistsError: If a queued/in_progress job already exists.
            LLMNotConfiguredError: If LLM is not configured.
            ValueError: If opportunity not found or not active.
        """
        from governor_core.llm import is_llm_configured

        if not is_llm_configured():
            raise LLMNotConfiguredError(
                "LLM provider is not configured. Set LLM_API_KEY to enable."
            )

        self.reclaim_stale_in_progress_jobs(opportunity_id=opportunity_id)

        opp = self._db.get(Opportunity, opportunity_id)
        if not opp:
            raise ValueError(f"Opportunity {opportunity_id} not found")
        if opp.status != "active":
            raise ValueError(f"Opportunity {opportunity_id} is not active")

        # Check for existing queued/in_progress job
        existing = (
            self._db.query(SolutionJob)
            .filter(
                SolutionJob.opportunity_id == opportunity_id,
                SolutionJob.status.in_(["queued", "in_progress"]),
            )
            .first()
        )
        if existing:
            raise SolutionJobExistsError(
                f"Solution job already exists for opportunity {opportunity_id}"
            )

        job = SolutionJob(
            id=str(uuid.uuid4()),
            opportunity_id=opportunity_id,
            detection_job_id=detection_job_id,
            config_id=config_id,
            status="queued",
        )
        self._db.add(job)
        try:
            self._db.commit()
        except IntegrityError as exc:
            self._db.rollback()
            raise SolutionJobExistsError(
                f"Solution job already exists for opportunity {opportunity_id}"
            ) from exc
        self._db.refresh(job)

        logger.info(
            "Created solution job %s for opportunity %s", job.id, opportunity_id
        )
        return job

    def get_pending_solution_job(self) -> SolutionJob | None:
        """FIFO poll for the next queued solution job.

        Uses SELECT ... FOR UPDATE SKIP LOCKED for safe concurrent access.
        Returns the oldest queued job, or None.
        """
        self.reclaim_stale_in_progress_jobs()
        dialect = self._db.bind.dialect.name if self._db.bind else "sqlite"

        if dialect == "postgresql":
            stmt = (
                select(SolutionJob)
                .where(SolutionJob.status == "queued")
                .order_by(SolutionJob.queued_at.asc())
                .limit(1)
                .with_for_update(skip_locked=True)
            )
        else:
            # SQLite doesn't support FOR UPDATE SKIP LOCKED
            stmt = (
                select(SolutionJob)
                .where(SolutionJob.status == "queued")
                .order_by(SolutionJob.queued_at.asc())
                .limit(1)
            )

        return self._db.scalars(stmt).first()

    def claim_solution_job(self, job_id: str) -> bool:
        """Atomically claim a job (queued -> in_progress).

        Returns True if claimed, False if already claimed or not found.
        """
        job = self._db.get(SolutionJob, job_id)
        if not job or job.status != "queued":
            return False

        job.status = "in_progress"
        job.started_at = datetime.now(timezone.utc)
        self._db.commit()
        return True

    def complete_solution_job(
        self,
        job_id: str,
        solutions_count: int,
        llm_metadata: dict | None = None,
        resolution_category: str | None = None,
        trust_tier: str | None = None,
    ) -> None:
        """Mark a solution job as completed with metrics."""
        job = self._db.get(SolutionJob, job_id)
        if not job:
            return

        job.status = "completed"
        job.completed_at = datetime.now(timezone.utc)
        job.solutions_generated_count = solutions_count
        job.resolution_category = resolution_category
        job.trust_tier = trust_tier

        if llm_metadata:
            job.llm_provider = llm_metadata.get("provider")
            job.llm_model = llm_metadata.get("model")
            job.prompt_tokens = llm_metadata.get("prompt_tokens")
            job.completion_tokens = llm_metadata.get("completion_tokens")
            job.llm_latency_ms = llm_metadata.get("latency_ms")

            # Accumulate LLM process cost onto the opportunity
            llm_cost = _estimate_llm_cost(
                job.prompt_tokens, job.completion_tokens, job.llm_model
            )
            if llm_cost > 0 and job.opportunity_id:
                opp = self._db.get(Opportunity, job.opportunity_id)
                if opp is not None:
                    existing = opp.process_cost_usd or Decimal("0")
                    opp.process_cost_usd = existing + llm_cost

        self._db.commit()

    def fail_solution_job(
        self,
        job_id: str,
        error_message: str,
        error_stage: str,
    ) -> None:
        """Mark a solution job as failed. Increments lifetime_retry_count."""
        job = self._db.get(SolutionJob, job_id)
        if not job:
            return

        job.status = "failed"
        job.completed_at = datetime.now(timezone.utc)
        job.error_message = error_message[:2000]  # Truncate long error messages
        job.error_stage = error_stage
        job.lifetime_retry_count = job.lifetime_retry_count + 1

        self._db.commit()

    def queue_solutions_for_detection(
        self,
        detection_job_id: str,
        config_id: str,
    ) -> list[SolutionJob]:
        """After detection completes, queue solution jobs for qualifying opportunities.

        Finds active opportunities for the config, filters out those with:
        - Current solutions (matching latest manifest version)
        - Pending solution jobs (queued/in_progress)
        - Permanently failed jobs (lifetime_retry_count >= max)
        """
        from governor_core.core.config import get_settings
        from governor_core.llm import is_llm_configured

        if not is_llm_configured():
            logger.info("LLM not configured, skipping solution job queueing")
            return []

        settings = get_settings()
        max_lifetime = settings.llm_max_lifetime_retries
        queue_limit = max(0, settings.solution_queue_detection_limit)

        self.reclaim_stale_in_progress_jobs()

        if queue_limit == 0:
            logger.info(
                "Solution queue detection limit is 0, skipping solution job queueing"
            )
            return []

        # Rank by current cost first so the default queue focuses on the
        # most expensive unresolved opportunities for this detection.
        # Skip cascade-delegated opportunities — their root cause gets
        # the solution job instead (spec 082).
        from sqlalchemy import or_

        from governor_core.configurations.models import ManifestConfiguration

        config = self._db.get(ManifestConfiguration, config_id)
        min_cost = (
            Decimal(str(config.min_solution_cost_usd))
            if config and config.min_solution_cost_usd is not None
            else DEFAULT_MIN_SOLUTION_COST_USD
        )

        opp_filters = [
            Opportunity.config_id == config_id,
            Opportunity.status == "active",
            or_(
                Opportunity.cascade_status.is_(None),
                Opportunity.cascade_status == "root",
            ),
        ]
        if min_cost > 0:
            opp_filters.append(Opportunity.current_cost_estimate >= min_cost)

        opportunities = (
            self._db.query(Opportunity)
            .filter(*opp_filters)
            .order_by(
                Opportunity.current_cost_estimate.desc(),
                Opportunity.expected_savings.desc(),
                Opportunity.created_at.asc(),
            )
            .all()
        )

        # Local mode: one SolutionJob per model. Multiple detection rules
        # can flag the same dbt model — we generate one fix for the model,
        # not one per rule. The highest-cost opportunity (first in the
        # ordered list) is the representative; the others remain visible
        # in the Opportunities list but never get their own job.
        from governor_core.core.config import is_local_mode

        if is_local_mode():
            seen_models: set[str] = set()
            deduped: list[Opportunity] = []
            for opp in opportunities:
                key = opp.dbt_model_name or f"__no_model__:{opp.id}"
                if key in seen_models:
                    continue
                seen_models.add(key)
                deduped.append(opp)
            opportunities = deduped

        created_jobs: list[SolutionJob] = []

        for opp in opportunities:
            if len(created_jobs) >= queue_limit:
                break

            # Skip if there's a pending solution job
            has_pending = (
                self._db.query(SolutionJob)
                .filter(
                    SolutionJob.opportunity_id == opp.id,
                    SolutionJob.status.in_(["queued", "in_progress"]),
                )
                .first()
            )
            if has_pending:
                continue

            # Skip if permanently failed
            last_failed = (
                self._db.query(SolutionJob)
                .filter(
                    SolutionJob.opportunity_id == opp.id,
                    SolutionJob.status == "failed",
                )
                .order_by(SolutionJob.created_at.desc())
                .first()
            )
            if last_failed and last_failed.lifetime_retry_count >= max_lifetime:
                continue

            # Check if current solution exists for latest manifest version
            if opp.manifest_version_id:
                has_current = (
                    self._db.query(Solution)
                    .filter(
                        Solution.opportunity_id == opp.id,
                        Solution.manifest_version_id == opp.manifest_version_id,
                    )
                    .first()
                )
                if has_current:
                    continue

            # Queue the job
            job = SolutionJob(
                id=str(uuid.uuid4()),
                opportunity_id=opp.id,
                detection_job_id=detection_job_id,
                config_id=config_id,
                status="queued",
            )
            self._db.add(job)
            created_jobs.append(job)

        if created_jobs:
            self._db.commit()
            for job in created_jobs:
                self._db.refresh(job)
            logger.info(
                "Queued %d solution jobs for detection %s (limit=%d)",
                len(created_jobs),
                detection_job_id,
                queue_limit,
            )

        return created_jobs

    # ------------------------------------------------------------------
    # Solution CRUD (US4)
    # ------------------------------------------------------------------

    def store_solution(
        self,
        opportunity_id: str,
        solution_job_id: str,
        manifest_version_id: str | None,
        solution_data: dict,
    ) -> Solution:
        """Store a generated solution with version management.

        Determines version_number, creates Solution record, purges oldest
        if count exceeds 3 for (opportunity_id, file_path).
        """
        resolution_category = solution_data["resolution_category"]
        file_path = solution_data.get("file_path")

        # Category-specific validation
        # dbt_project_change with file_changes requires all fields;
        # without file_changes (no source code) only explanation is needed.
        if resolution_category == "dbt_project_change" and solution_data.get(
            "file_path"
        ):
            for field in (
                "file_path",
                "before_content",
                "after_content",
                "change_type",
            ):
                if not solution_data.get(field):
                    raise ValueError(f"dbt_project_change requires non-null {field}")
        elif resolution_category == "bigquery_infrastructure":
            for field in (
                "current_setting_value",
                "recommended_setting_value",
                "affected_resource",
            ):
                if not solution_data.get(field):
                    raise ValueError(
                        f"bigquery_infrastructure requires non-null {field}"
                    )

        # Determine version number
        max_version = (
            self._db.query(func.max(Solution.version_number))
            .filter(
                Solution.opportunity_id == opportunity_id,
                Solution.file_path == file_path
                if file_path
                else Solution.file_path.is_(None),
            )
            .scalar()
        )
        version_number = (max_version or 0) + 1

        solution = Solution(
            id=str(uuid.uuid4()),
            opportunity_id=opportunity_id,
            solution_job_id=solution_job_id,
            manifest_version_id=manifest_version_id,
            resolution_category=resolution_category,
            version_number=version_number,
            file_changes=solution_data.get("file_changes"),
            file_path=file_path,
            change_type=solution_data.get("change_type"),
            before_content=solution_data.get("before_content"),
            after_content=solution_data.get("after_content"),
            repository=solution_data.get("repository"),
            commit_sha=solution_data.get("commit_sha"),
            current_setting_value=solution_data.get("current_setting_value"),
            recommended_setting_value=solution_data.get("recommended_setting_value"),
            affected_resource=solution_data.get("affected_resource"),
            explanation=solution_data["explanation"],
            risk_level=solution_data["risk_level"],
            risk_justification=solution_data["risk_justification"],
            trust_tier=solution_data.get("trust_tier"),
            validation_report=solution_data.get("validation_report"),
            dry_run_original=solution_data.get("dry_run_original"),
            dry_run_modified=solution_data.get("dry_run_modified"),
            compiled_after_sql=solution_data.get("compiled_after_sql"),
        )
        self._db.add(solution)
        self._db.flush()

        # Purge oldest if count exceeds 3
        self._purge_old_versions(opportunity_id, file_path, max_keep=3)

        sync_opportunity_solution_snapshots(self._db, [opportunity_id])

        self._db.commit()
        self._db.refresh(solution)
        return solution

    def get_solutions_for_opportunity(
        self,
        opportunity_id: str,
        latest_only: bool = True,
    ) -> list[Solution]:
        """Retrieve solutions for an opportunity.

        Args:
            opportunity_id: The opportunity ID.
            latest_only: If True, return only the highest version per file/setting.

        Returns:
            List of Solution records ordered by file_path, version_number DESC.
        """
        query = (
            self._db.query(Solution)
            .filter(Solution.opportunity_id == opportunity_id)
            .order_by(Solution.file_path, Solution.version_number.desc())
        )

        if latest_only:
            # Subquery: max version per file_path for this opportunity
            subq = (
                self._db.query(
                    Solution.file_path,
                    func.max(Solution.version_number).label("max_version"),
                )
                .filter(Solution.opportunity_id == opportunity_id)
                .group_by(Solution.file_path)
                .subquery()
            )

            query = (
                self._db.query(Solution)
                .join(
                    subq,
                    (Solution.file_path == subq.c.file_path)
                    & (Solution.version_number == subq.c.max_version),
                )
                .filter(Solution.opportunity_id == opportunity_id)
                .order_by(Solution.file_path, Solution.version_number.desc())
            )

        return query.all()

    def _purge_old_versions(
        self, opportunity_id: str, file_path: str | None, max_keep: int = 3
    ) -> None:
        """Delete oldest versions beyond max_keep for a given (opportunity_id, file_path)."""
        if file_path:
            condition = Solution.file_path == file_path
        else:
            condition = Solution.file_path.is_(None)

        versions = (
            self._db.query(Solution)
            .filter(
                Solution.opportunity_id == opportunity_id,
                condition,
            )
            .order_by(Solution.version_number.desc())
            .all()
        )

        if len(versions) > max_keep:
            for old in versions[max_keep:]:
                self._db.delete(old)

    # ------------------------------------------------------------------
    # Dashboard (US5)
    # ------------------------------------------------------------------

    def get_solution_jobs_dashboard(self) -> dict:
        """Return solution job counts for the queue dashboard."""
        now = datetime.now(timezone.utc)
        day_ago = now - timedelta(hours=24)

        pending = (
            self._db.query(func.count(SolutionJob.id))
            .filter(SolutionJob.status == "queued")
            .scalar()
            or 0
        )
        running = (
            self._db.query(func.count(SolutionJob.id))
            .filter(SolutionJob.status == "in_progress")
            .scalar()
            or 0
        )
        completed_24h = (
            self._db.query(func.count(SolutionJob.id))
            .filter(
                SolutionJob.status == "completed",
                SolutionJob.completed_at >= day_ago,
            )
            .scalar()
            or 0
        )
        failed_24h = (
            self._db.query(func.count(SolutionJob.id))
            .filter(
                SolutionJob.status == "failed",
                SolutionJob.completed_at >= day_ago,
            )
            .scalar()
            or 0
        )

        return {
            "pending": pending,
            "running": running,
            "completed_24h": completed_24h,
            "failed_24h": failed_24h,
        }

    def cancel_solution_job(self, job_id: str) -> bool:
        """Cancel a queued solution job (queued -> failed).

        Returns True if cancelled, False if not found or not queued.
        """
        job = self._db.get(SolutionJob, job_id)
        if not job or job.status != "queued":
            return False

        job.status = "failed"
        job.error_message = "Cancelled by administrator"
        job.completed_at = datetime.now(timezone.utc)
        self._db.commit()
        return True

    def requeue_opportunity_solution(self, opportunity_id: str) -> SolutionJob:
        """Delete existing solutions for one opportunity and re-queue a job.

        Returns:
            The newly created SolutionJob.

        Raises:
            LLMNotConfiguredError: If LLM is not configured.
            ValueError: If opportunity not found or not active.
        """
        from governor_core.llm import is_llm_configured

        if not is_llm_configured():
            raise LLMNotConfiguredError(
                "LLM provider is not configured. Set LLM_API_KEY to enable."
            )

        opp = self._db.get(Opportunity, opportunity_id)
        if not opp:
            raise ValueError(f"Opportunity {opportunity_id} not found")
        if opp.status not in ("active", "pr_pending"):
            raise ValueError(f"Opportunity {opportunity_id} is not in active state")

        # Delete existing solutions
        self._db.query(Solution).filter(
            Solution.opportunity_id == opportunity_id
        ).delete(synchronize_session="fetch")

        self._mark_active_solution_jobs_failed(
            opportunity_ids=[opportunity_id],
            error_message="Superseded by regeneration request",
        )

        # Create new queued job
        job = SolutionJob(
            id=str(uuid.uuid4()),
            opportunity_id=opportunity_id,
            config_id=opp.config_id,
            status="queued",
        )
        self._db.add(job)
        self._db.commit()
        self._db.refresh(job)

        logger.info(
            "Re-queued solution job %s for opportunity %s",
            job.id,
            opportunity_id,
        )
        return job

    def requeue_all_solutions(self) -> int:
        """Delete existing solutions and re-queue jobs for all active opportunities.

        This is useful when the solution generator logic has been fixed and
        you want to regenerate all solutions from scratch.

        Returns:
            Number of solution jobs queued.
        """
        from governor_core.llm import is_llm_configured

        if not is_llm_configured():
            raise LLMNotConfiguredError(
                "LLM provider is not configured. Set LLM_API_KEY to enable."
            )

        # Find all active opportunities
        opportunities = (
            self._db.query(Opportunity).filter(Opportunity.status == "active").all()
        )

        if not opportunities:
            return 0

        opp_ids = [opp.id for opp in opportunities]

        # Delete existing solutions for these opportunities
        self._db.query(Solution).filter(Solution.opportunity_id.in_(opp_ids)).delete(
            synchronize_session="fetch"
        )

        self._mark_active_solution_jobs_failed(
            opportunity_ids=opp_ids,
            error_message="Superseded by bulk regeneration request",
        )

        # Create new queued jobs
        created = 0
        for opp in opportunities:
            job = SolutionJob(
                id=str(uuid.uuid4()),
                opportunity_id=opp.id,
                config_id=opp.config_id,
                status="queued",
            )
            self._db.add(job)
            created += 1

        self._db.commit()
        logger.info("Re-queued %d solution jobs for regeneration", created)
        return created

    def _mark_active_solution_jobs_failed(
        self,
        *,
        opportunity_ids: list[str],
        error_message: str,
    ) -> int:
        """Preserve job history while clearing any active work for re-queueing."""
        if not opportunity_ids:
            return 0

        completed_at = datetime.now(timezone.utc)
        updated = (
            self._db.query(SolutionJob)
            .filter(
                SolutionJob.opportunity_id.in_(opportunity_ids),
                SolutionJob.status.in_(["queued", "in_progress"]),
            )
            .update(
                {
                    "status": "failed",
                    "error_message": error_message,
                    "error_stage": "storage",
                    "completed_at": completed_at,
                },
                synchronize_session="fetch",
            )
        )
        return updated

    # ------------------------------------------------------------------
    # Version history (US7)
    # ------------------------------------------------------------------

    def get_solution_versions(
        self, opportunity_id: str, file_path: str
    ) -> list[Solution]:
        """Return all versions for a specific file, ordered by version DESC."""
        return (
            self._db.query(Solution)
            .filter(
                Solution.opportunity_id == opportunity_id,
                Solution.file_path == file_path,
            )
            .order_by(Solution.version_number.desc())
            .all()
        )


# =========================================================================
# Spec 128: downstream-patch bundle helpers
# =========================================================================


def generate_downstream_patches(
    db: Session,
    solution_id: str,
    *,
    llm_provider=None,
) -> list[dict]:
    """Extend ``solution.file_changes`` with a WHERE-clause patch per failing
    in-project downstream surfaced by the most recent shadow run.

    Called both (a) automatically by the shadow post-run hook after
    validation on an ``add_require_partition_filter`` solution fails in
    local mode, and (b) on explicit user request via the web route.

    Idempotency contract (spec 128 research R6):

    - Existing ``file_changes`` entries with ``proposal_meta.status in
      ("edited", "applied")`` are preserved verbatim.
    - Existing entries in ``proposed`` or ``manual_required`` state are
      refreshed from the latest LLM call.
    - New entries are appended for previously-unseen failing downstreams.

    Returns the full updated ``file_changes`` list for the solution. Commit
    is the caller's responsibility.
    """
    import asyncio

    from governor_core.agents.downstream_patch.providers import get_provider
    from governor_core.core.config import is_local_mode
    from governor_core.shadow.failure_analysis import identify_failing_downstreams
    from governor_core.shadow.models import ShadowValidationRun
    from governor_core.solutions.models import Solution

    if not is_local_mode():
        logger.debug("spec-128 generate_downstream_patches: cloud mode, skipping")
        return []

    solution = db.get(Solution, solution_id)
    if solution is None:
        logger.info("spec-128 generate_downstream_patches: solution %s not found", solution_id)
        return []

    validation_report = solution.validation_report or {}
    template_id = validation_report.get("template_id")
    # Spec 132: dispatch via the guardrail-provider registry. A missing
    # provider is the "silent no-op" path (FR-009) — we skip silently for
    # solutions whose template_id does not identify a breaking-change
    # guardrail (e.g. spec 131's upstream_partition_by).
    provider = get_provider(template_id)
    if provider is None:
        logger.debug(
            "spec-128/132 generate_downstream_patches: no guardrail provider registered "
            "for template_id=%r, skipping",
            template_id,
        )
        return []

    latest_run = (
        db.query(ShadowValidationRun)
        .filter(ShadowValidationRun.solution_id == solution_id)
        .order_by(ShadowValidationRun.created_at.desc())
        .first()
    )
    if latest_run is None:
        return []

    manifest_content = _load_manifest_for_solution(db, solution)
    failures = identify_failing_downstreams(db, latest_run.id, manifest_content)
    in_project_failures = [f for f in failures if f.is_in_project]
    if not in_project_failures:
        return list(solution.file_changes or [])

    if llm_provider is None:
        llm_provider = _resolve_llm_provider()
        if llm_provider is None:
            logger.warning(
                "spec-128 generate_downstream_patches: no LLM provider configured, aborting"
            )
            return list(solution.file_changes or [])

    upstream_ctx = provider.build_upstream_context(
        solution, manifest_content, str(latest_run.id)
    )
    if upstream_ctx is None:
        logger.warning(
            "spec-128/132 generate_downstream_patches: provider %s returned no "
            "upstream context for solution %s",
            type(provider).__name__,
            solution_id,
        )
        return list(solution.file_changes or [])

    existing = list(solution.file_changes or [])
    existing_by_path: dict[str, dict] = {
        entry.get("file_path"): entry for entry in existing if entry.get("file_path")
    }

    # Per-failure patch dispatch via the provider. Sequential for MVP;
    # parallelise later.
    async def _gather():
        tasks = [
            provider.propose_patch(f, upstream_ctx, llm_provider=llm_provider)
            for f in in_project_failures
        ]
        return await asyncio.gather(*tasks)

    patches = asyncio.run(_gather())

    updated: list[dict] = []
    # Keep upstream entry first (spec 127 guardrail), then every non-downstream
    # entry in original order, then the refreshed downstream patches.
    upstream_and_other: list[dict] = []
    for entry in existing:
        entry_change_type = (entry.get("proposal_meta") or {}).get("change_type")
        if entry_change_type != "downstream_partition_filter_patch":
            upstream_and_other.append(entry)
    updated.extend(upstream_and_other)

    for patch in patches:
        prior = existing_by_path.get(patch.file_path)
        if prior and (prior.get("proposal_meta") or {}).get("status") in (
            "edited",
            "applied",
        ):
            updated.append(prior)
            continue
        updated.append(
            {
                "file_path": patch.file_path,
                "before_content": patch.before_content,
                "after_content": patch.after_content,
                "change_type": "downstream_partition_filter_patch",
                "proposal_meta": patch.proposal_meta,
            }
        )

    solution.file_changes = updated
    solution.updated_at = datetime.now(timezone.utc)
    return updated


def _load_manifest_for_solution(db: Session, solution) -> dict:
    """Best-effort resolve the dbt manifest content associated with the
    solution's configuration. Falls back to ``{}``; downstream callers treat
    an empty manifest as "no in-project matches" which is safe."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.sync.models import ManifestVersion

    opportunity = db.query(Opportunity).filter(Opportunity.id == solution.opportunity_id).first()
    if opportunity is None or opportunity.config_id is None:
        return {}
    config = db.get(ManifestConfiguration, opportunity.config_id)
    if config is None:
        return {}

    latest_manifest = (
        db.query(ManifestVersion)
        .filter(ManifestVersion.config_id == config.id)
        .order_by(ManifestVersion.created_at.desc())
        .first()
    )
    if latest_manifest is None:
        return {}
    return latest_manifest.content or {}


def _derive_upstream_context(solution, shadow_run_id, manifest_content):
    """Pull the partition column + data type off the guarded upstream model."""
    from governor_core.agents.downstream_patch import UpstreamPartitionContext

    # The spec-127 solution carries the upstream dbt model via opportunity + file_path.
    opportunity = getattr(solution, "opportunity", None)
    if opportunity is None:
        return None

    model_name = opportunity.dbt_model_name
    if not model_name:
        return None

    nodes = (manifest_content or {}).get("nodes", {}) or {}
    node = None
    for node_id, candidate in nodes.items():
        if node_id.split(".")[-1] == model_name:
            node = candidate
            break
    if node is None:
        return None

    config_block = node.get("config") or {}
    partition_by = config_block.get("partition_by") or {}
    partition_column = None
    partition_data_type = "date"
    if isinstance(partition_by, dict):
        partition_column = partition_by.get("field")
        partition_data_type = (partition_by.get("data_type") or "date").lower()
    elif isinstance(partition_by, str):
        partition_column = partition_by

    if not partition_column:
        return None

    relation_name = node.get("relation_name") or ""
    return UpstreamPartitionContext(
        upstream_model_name=model_name,
        upstream_table_fqn=relation_name or model_name,
        partition_column=partition_column,
        partition_data_type=partition_data_type,
        source_shadow_run_id=str(shadow_run_id),
    )


class PartialApplyError(RuntimeError):
    """Raised by apply_bundle_atomically when files landed but the rename
    sequence was interrupted mid-way. The message identifies which files
    successfully landed and which did not, so the user can recover."""


def apply_bundle_atomically(
    project_path: str,
    file_changes: list[dict],
    *,
    solution_id: str,
) -> list[str]:
    """Write every file in ``file_changes`` to the local working tree with
    all-or-nothing semantics (research R7).

    Strategy:
    1. Validate every target path is inside ``project_path`` (path-traversal guard).
    2. Write each target's ``after_content`` to a sibling
       ``<target>.governor-<solution_id>-tmp`` file.
    3. If any step-2 write fails, delete every tmp file that landed and raise —
       no target has been touched.
    4. Rename each tmp onto its target in sequence.
    5. If step 4 fails mid-sequence, leave the marker file
       ``<project>/.governor-bundle-state.<solution_id>`` describing which
       files are new vs. still tmp, and raise ``PartialApplyError`` with a
       clear recovery message.

    Returns the list of written absolute target paths.
    """
    import os
    from pathlib import Path

    if not file_changes:
        return []

    project_root = Path(project_path).resolve()
    targets: list[tuple[Path, str, Path]] = []  # (target_abs, after_content, tmp_path)
    for entry in file_changes:
        rel = entry.get("file_path")
        content = entry.get("after_content")
        if not rel or content is None:
            raise ValueError(
                f"spec-128 atomic apply: file_change missing file_path or after_content: {entry}"
            )
        target = (project_root / rel).resolve()
        if not str(target).startswith(str(project_root)):
            raise ValueError(
                f"spec-128 atomic apply: path {rel} escapes project {project_path}"
            )
        tmp = target.with_name(target.name + f".governor-{solution_id}-tmp")
        targets.append((target, content, tmp))

    # Phase 1: write every tmp file. Any failure here rolls back all tmps.
    written_tmps: list[Path] = []
    try:
        for target, content, tmp in targets:
            tmp.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(content, encoding="utf-8")
            written_tmps.append(tmp)
    except Exception as exc:
        for tmp in written_tmps:
            try:
                tmp.unlink()
            except OSError:
                logger.warning("spec-128 atomic apply: cleanup failed for %s", tmp)
        raise RuntimeError(
            f"spec-128 atomic apply: write-tmp phase failed on {tmp}: {exc}"
        ) from exc

    # Phase 2: rename each tmp onto its target. Mid-sequence failure surfaces
    # a deterministic marker file; we deliberately do NOT try to "roll forward"
    # silently because the failed rename may indicate a transient external
    # constraint (permissions, mount issues) that needs user intervention.
    renamed: list[str] = []
    marker_path = project_root / f".governor-bundle-state.{solution_id}"
    for target, _content, tmp in targets:
        try:
            os.replace(tmp, target)
            renamed.append(str(target))
        except OSError as exc:
            # Persist the state marker so the user knows what's partial.
            remaining = [
                str(t) for t, _c, _tmp in targets if str(t) not in renamed
            ]
            marker_path.write_text(
                "Partial apply. Successfully renamed:\n"
                + "\n".join(renamed)
                + "\n\nNot yet renamed (tmp files may still exist):\n"
                + "\n".join(remaining)
                + f"\n\nError on {target}: {exc}\n",
                encoding="utf-8",
            )
            raise PartialApplyError(
                f"spec-128 atomic apply: rename failed on {target} after {len(renamed)} "
                f"file(s) already landed. Marker written to {marker_path}. "
                f"Inspect the marker and clean up manually: remaining .tmp files "
                f"can be deleted; successfully-renamed files are good."
            ) from exc

    return renamed


def _resolve_llm_provider():
    """Construct the default LLMProvider.

    Delegates to ``governor_core.llm.get_llm_provider()`` — the canonical
    helper that reads the API key from the same runtime state the web
    settings UI writes to. Returns ``None`` when no provider is configured
    (caller handles graceful degradation)."""
    try:
        from governor_core.llm import get_llm_provider

        return get_llm_provider()
    except Exception:  # noqa: BLE001 — any construction failure → skip
        logger.exception("spec-128 _resolve_llm_provider: unable to build provider")
        return None
