"""Safe change template catalog for deterministic solution generation.

Templates are tried in registry order. First match wins.
If no template matches, returns None (proceed to LLM).

Spec 051: ``match_upstream_template`` applies cluster_by / partition_by
config changes to *upstream* models identified by lineage analysis.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from governor_core.solutions.templates.base import BaseTemplate, TemplateResult
from governor_core.solutions.templates.config_parser import (
    has_config_property,
    insert_config_property,
    merge_config_list,
)

if TYPE_CHECKING:
    from governor_core.dbt.lineage_analyzer import UpstreamCandidate

logger = logging.getLogger("app.solutions.templates")

_TEMPLATE_REGISTRY: list[BaseTemplate] = []


def register_template(template: BaseTemplate) -> None:
    """Register a template in the catalog."""
    _TEMPLATE_REGISTRY.append(template)
    logger.debug("Registered template: %s", template.template_id)


def match_template(
    opportunity,
    source_files: dict[str, str] | None,
    manifest_metadata: dict[str, Any] | None,
) -> TemplateResult | None:
    """Try all registered templates and return the first match.

    Args:
        opportunity: Opportunity ORM model.
        source_files: Dict mapping file path to content, or None.
        manifest_metadata: Parsed manifest node data, or None.

    Returns:
        TemplateResult if a template matched and was applied successfully,
        None if no template applies (caller should proceed to LLM).
    """
    effective_source_files = source_files or {}

    for template in _TEMPLATE_REGISTRY:
        if opportunity.opportunity_type not in template.applicable_types:
            continue

        try:
            if template.matches(opportunity, effective_source_files, manifest_metadata):
                result = template.apply(
                    opportunity, effective_source_files, manifest_metadata
                )
                if result is not None:
                    logger.info(
                        "Template %s matched for opportunity %s",
                        template.template_id,
                        getattr(opportunity, "id", "?"),
                    )
                    return result
        except (ValueError, KeyError, RuntimeError):
            logger.exception(
                "Template %s failed for opportunity %s, skipping",
                template.template_id,
                getattr(opportunity, "id", "?"),
            )

    return None


def match_upstream_template(
    opportunity,
    candidate: UpstreamCandidate,
    upstream_source_files: dict[str, str],
) -> TemplateResult | None:
    """Apply a cluster_by config change to an upstream model (spec 051).

    Uses the lineage analyzer's UpstreamCandidate (which already has the
    columns to cluster on) and the upstream model's source file to produce
    a deterministic config change.

    Args:
        opportunity: Opportunity ORM model.
        candidate: UpstreamCandidate from lineage analysis.
        upstream_source_files: Dict mapping file path to content.

    Returns:
        TemplateResult targeting the upstream model, or None if the
        config change cannot be applied.
    """
    file_path = candidate.original_file_path
    if file_path not in upstream_source_files:
        logger.debug(
            "Upstream file %s not found in source files, skipping template",
            file_path,
        )
        return None

    before_content = upstream_source_files[file_path]
    columns = candidate.suggested_cluster_columns
    if not columns:
        return None

    quality_map = candidate.column_quality or {}
    excluded_columns = [
        col
        for col, details in quality_map.items()
        if details.get("classification") == "poor" and col not in columns
    ]

    # Apply cluster_by config change
    if has_config_property(before_content, "cluster_by"):
        after_content = merge_config_list(before_content, "cluster_by", columns)
        if after_content is None:
            logger.info(
                "Upstream %s already clustered on all suggested columns",
                candidate.name,
            )
            return None
    else:
        value = "[" + ", ".join(f'"{col}"' for col in columns) + "]"
        after_content = insert_config_property(before_content, "cluster_by", value)
        if after_content is None:
            logger.debug(
                "Could not insert cluster_by into upstream model %s",
                candidate.name,
            )
            return None

    col_list = ", ".join(columns)
    explanation = (
        f"Added cluster_by = [{col_list}] to upstream model '{candidate.name}' "
        f"to fix {opportunity.opportunity_type} in downstream model "
        f"'{getattr(opportunity, 'dbt_model_name', 'unknown')}'. "
        f"{candidate.reason}"
    )
    if excluded_columns:
        excluded_summary = ", ".join(excluded_columns)
        explanation += (
            f" Excluded poor-quality join keys from clustering: {excluded_summary}."
        )

    return TemplateResult(
        template_id="upstream_cluster_by",
        file_path=file_path,
        before_content=before_content,
        after_content=after_content,
        change_type="project_config_change",
        explanation=explanation,
        policy_tags=["dbt_config_change"],
        parameters={
            "columns": columns,
            "upstream_model": candidate.name,
            "affected_model": getattr(opportunity, "dbt_model_name", None),
            **({"column_quality": quality_map} if quality_map else {}),
            **({"excluded_columns": excluded_columns} if excluded_columns else {}),
        },
        rollback=(
            "Remove the cluster_by property from the upstream model's config block. "
            "If cluster_by existed before with different columns, restore "
            "the original column list."
        ),
    )


def match_upstream_partition_template(
    opportunity,
    candidate: UpstreamCandidate,
    upstream_source_files: dict[str, str],
) -> TemplateResult | None:
    """Spec 131: apply a ``partition_by`` config change to an upstream model
    whose output is the source of the hot data for a ``partition_pruning``
    opportunity.

    Returns ``None`` (no solution emitted) when any of:

    - The candidate's analyzer abstained (``suggested_partition_by is None``).
    - The upstream is already partitioned (``current_partition_by is not None``).
    - The upstream's source file isn't available to overlay.
    - The emitted ``partition_by`` carries the placeholder flag AND the
      current file couldn't have the existing ``partition_by`` safely inserted.
    """
    if candidate.suggested_partition_by is None:
        return None
    if candidate.current_partition_by is not None:
        return None

    file_path = candidate.original_file_path
    if not file_path or file_path not in upstream_source_files:
        return None

    before_content = upstream_source_files[file_path]
    proposed = candidate.suggested_partition_by

    # Build the dbt partition_by config expression. Temporal partitions emit
    # ``partition_by={'field': '<col>', 'data_type': '<type>'}``; INT64 bucket
    # partitions emit a range_partitioning placeholder so the user must fill
    # in start/end/interval before apply (spec 131 R3).
    if proposed.get("placeholder"):
        range_spec = proposed.get("range") or {}
        value = (
            "{"
            f'"field": "{proposed["field"]}", '
            f'"data_type": "{proposed.get("data_type", "int64")}", '
            '"range": {'
            f'"start": {range_spec.get("start", "TODO")!r}, '
            f'"end": {range_spec.get("end", "TODO")!r}, '
            f'"interval": {range_spec.get("interval", "TODO")!r}'
            "}"
            "}"
        )
    else:
        value = (
            "{"
            f'"field": "{proposed["field"]}", '
            f'"data_type": "{proposed["data_type"]}"'
            "}"
        )

    if has_config_property(before_content, "partition_by"):
        # Defensive: current_partition_by was None in the candidate so the
        # manifest didn't know about it, but the file may still contain one
        # (manifest drift). Refuse rather than stomp.
        logger.info(
            "Upstream %s source file already declares partition_by; skipping",
            candidate.name,
        )
        return None

    after_content = insert_config_property(before_content, "partition_by", value)
    if after_content is None:
        logger.debug(
            "Could not insert partition_by into upstream model %s", candidate.name
        )
        return None

    affected_model = getattr(opportunity, "dbt_model_name", None)
    explanation = (
        f"Added partition_by for '{candidate.name}' "
        f"({proposed.get('data_type', '?')} column '{proposed.get('field', '?')}') "
        f"to unlock partition pruning for downstream model '{affected_model}'. "
        f"{candidate.partition_reason or ''}"
    ).strip()

    parameters: dict = {
        "upstream_model": candidate.name,
        "affected_model": affected_model,
        "partition_by": proposed,
    }
    if proposed.get("placeholder"):
        parameters["manual_required"] = True

    return TemplateResult(
        template_id="upstream_partition_by",
        file_path=file_path,
        before_content=before_content,
        after_content=after_content,
        change_type="project_config_change",
        explanation=explanation,
        policy_tags=["dbt_config_change"],
        parameters=parameters,
        rollback=(
            "Remove the partition_by property from the upstream model's "
            "config block. Note: dropping a partition definition after data "
            "has been written typically requires a full refresh of the "
            "affected table — not a free undo."
        ),
    )


def get_registry() -> list[BaseTemplate]:
    """Return the current template registry (for testing)."""
    return list(_TEMPLATE_REGISTRY)


# Register built-in templates
# Note: AddClusterByTemplate and AddJoinKeyClusterTemplate remain disabled
# for direct (self-targeting) use (spec 039). Upstream-targeting cluster_by
# is handled by match_upstream_template() above (spec 051).
# from governor_core.solutions.templates.add_cluster_by import AddClusterByTemplate  # noqa: E402
# from governor_core.solutions.templates.add_join_key_cluster import (  # noqa: E402
#     AddJoinKeyClusterTemplate,
# )
# Disabled (spec 047): partition_by self-targeting.
# from governor_core.solutions.templates.add_partition_by import AddPartitionByTemplate  # noqa: E402

from governor_core.core.config import is_local_mode  # noqa: E402
from governor_core.solutions.templates.switch_storage_billing import (  # noqa: E402
    SwitchStorageBillingTemplate,
)
from governor_core.solutions.templates.remove_dead_ctes import (  # noqa: E402
    RemoveDeadCtesTemplate,
)
from governor_core.solutions.templates.remove_dead_columns import (  # noqa: E402
    RemoveDeadColumnsTemplate,
)
from governor_core.solutions.templates.remove_redundant_order_bys import (  # noqa: E402
    RemoveRedundantOrderBysTemplate,
)
from governor_core.solutions.templates.remove_unused_joins import (  # noqa: E402
    RemoveUnusedJoinsTemplate,
)

register_template(SwitchStorageBillingTemplate())
register_template(RemoveDeadCtesTemplate())
register_template(RemoveDeadColumnsTemplate())
register_template(RemoveRedundantOrderBysTemplate())
register_template(RemoveUnusedJoinsTemplate())

# Spec 127: re-enable require_partition_filter guardrail, local/CLI mode only.
# Cloud/PR mode cannot guarantee downstream-consumer safety without manual
# coordination; local mode relies on human review + local shadow validation.
if is_local_mode():
    from governor_core.solutions.templates.add_require_partition_filter import (  # noqa: E402
        AddRequirePartitionFilterTemplate,
    )

    register_template(AddRequirePartitionFilterTemplate())
