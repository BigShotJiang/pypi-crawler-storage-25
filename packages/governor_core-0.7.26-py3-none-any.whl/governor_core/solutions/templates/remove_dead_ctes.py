"""Deterministic solution template for dead_cte opportunities."""

from __future__ import annotations

import logging
import re
from typing import Any

from governor_core.solutions.templates.base import BaseTemplate, TemplateResult

logger = logging.getLogger("app.solutions.templates.remove_dead_ctes")


def _find_cte_segment(sql: str, cte_name: str) -> tuple[int, int] | None:
    """Return the text span for a named CTE definition in a WITH clause."""
    pattern = re.compile(
        r"\b" + re.escape(cte_name) + r"\s+as\s*\(",
        re.IGNORECASE,
    )
    match = pattern.search(sql)
    if not match:
        return None

    segment_start = match.start()
    open_pos = match.end() - 1
    depth = 0
    close_pos: int | None = None

    for idx in range(open_pos, len(sql)):
        char = sql[idx]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                close_pos = idx
                break

    if close_pos is None:
        return None

    segment_end = close_pos + 1

    trailing_ws = segment_end
    while trailing_ws < len(sql) and sql[trailing_ws] in " \t":
        trailing_ws += 1
    if trailing_ws < len(sql) and sql[trailing_ws] == ",":
        trailing_ws += 1
        while trailing_ws < len(sql) and sql[trailing_ws] in " \t\r\n":
            trailing_ws += 1
        return segment_start, trailing_ws

    leading_ws = segment_start
    while leading_ws > 0 and sql[leading_ws - 1] in " \t":
        leading_ws -= 1
    if leading_ws > 0 and sql[leading_ws - 1] == ",":
        return leading_ws - 1, segment_end

    return segment_start, segment_end


def _cleanup_empty_with(sql: str) -> str:
    """Remove a dangling WITH keyword when all CTEs have been deleted."""
    return re.sub(r"(?is)^\s*with\s*(?=select\b)", "", sql, count=1).lstrip("\r\n")


def _remove_cte_from_sql(sql: str, cte_name: str) -> str | None:
    """Remove a named CTE block from SQL while preserving other text."""
    segment = _find_cte_segment(sql, cte_name)
    if segment is None:
        logger.debug("Could not locate dead CTE %s in SQL", cte_name)
        return None

    start, end = segment
    updated = sql[:start] + sql[end:]
    return _cleanup_empty_with(updated)


class RemoveDeadCtesTemplate(BaseTemplate):
    """Deterministic template that removes unused CTE blocks."""

    template_id = "remove_dead_ctes"
    applicable_types = {"dead_cte"}

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        evidence = opportunity.evidence_snapshot or {}
        dead_ctes = evidence.get("dead_ctes", [])
        file_path = (manifest_metadata or {}).get("original_file_path", "")
        return bool(dead_ctes and file_path and source_files.get(file_path))

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        evidence = opportunity.evidence_snapshot or {}
        dead_ctes: list[str] = evidence.get("dead_ctes", [])
        file_path = (manifest_metadata or {}).get("original_file_path", "")
        before_content = source_files.get(file_path, "")
        if not before_content or not dead_ctes:
            return None

        content = before_content
        removed_ctes: list[str] = []
        for cte_name in dead_ctes:
            updated = _remove_cte_from_sql(content, cte_name)
            if updated is not None:
                content = updated
                removed_ctes.append(cte_name)

        if content == before_content or not removed_ctes:
            return None

        model_name = (manifest_metadata or {}).get("name", opportunity.affected_table)
        cte_list = "\n".join(f"  - `{cte}`" for cte in removed_ctes)
        explanation = (
            f"Removed {len(removed_ctes)} unused CTE(s) from `{model_name}`.\n\n"
            f"**Dead CTEs removed:**\n{cte_list}\n\n"
            "**What changed:** Only the unused CTE definition blocks were removed. "
            "All surviving CTEs, Jinja refs, and the final SELECT were left intact."
        )

        return TemplateResult(
            template_id=self.template_id,
            file_path=file_path,
            before_content=before_content,
            after_content=content,
            change_type="sql_change",
            explanation=explanation,
            policy_tags=["sql_change"],
            parameters={
                "dead_ctes": removed_ctes,
                "model_name": model_name,
            },
            rollback=(
                f"Re-add the removed CTE definition blocks in `{file_path}`. "
                f"The removed CTEs were: {', '.join(removed_ctes)}."
            ),
        )

    def rollback_instructions(self) -> str:
        return "Re-add the removed CTE definitions to the dbt model file."
