"""Deterministic solution template for unused_join opportunities."""

from __future__ import annotations

import logging
import re
from typing import Any

from governor_core.solutions.templates.base import BaseTemplate, TemplateResult

logger = logging.getLogger("app.solutions.templates.remove_unused_joins")

_JOIN_KEYWORDS = (
    "left outer join",
    "left join",
    "right outer join",
    "right join",
    "full outer join",
    "full join",
    "inner join",
    "cross join",
    "join",
)
_CLAUSE_KEYWORDS = (
    "where",
    "group by",
    "having",
    "qualify",
    "order by",
    "limit",
    "union",
)


def _find_cte_boundaries(sql: str, cte_name: str) -> tuple[int, int] | None:
    """Find the body span of a named CTE."""
    pattern = re.compile(
        r"\b" + re.escape(cte_name) + r"\s+as\s*\(",
        re.IGNORECASE,
    )
    match = pattern.search(sql)
    if not match:
        return None

    open_pos = match.end() - 1
    depth = 0
    for idx in range(open_pos, len(sql)):
        char = sql[idx]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return open_pos + 1, idx
    return None


def _is_word_char(char: str) -> bool:
    return char.isalnum() or char == "_"


def _find_top_level_keyword_positions(
    sql: str,
    keywords: tuple[str, ...],
) -> list[tuple[int, str]]:
    """Return `(index, keyword)` pairs for top-level keywords in SQL text."""
    sorted_keywords = tuple(sorted(keywords, key=len, reverse=True))
    positions: list[tuple[int, str]] = []
    depth = 0
    quote: str | None = None
    line_comment = False
    block_comment = False
    idx = 0

    while idx < len(sql):
        char = sql[idx]
        next_two = sql[idx : idx + 2]

        if line_comment:
            if char == "\n":
                line_comment = False
            idx += 1
            continue

        if block_comment:
            if next_two == "*/":
                block_comment = False
                idx += 2
            else:
                idx += 1
            continue

        if quote is not None:
            if char == "\\" and idx + 1 < len(sql):
                idx += 2
                continue
            if char == quote:
                quote = None
            idx += 1
            continue

        if next_two == "--":
            line_comment = True
            idx += 2
            continue
        if next_two == "/*":
            block_comment = True
            idx += 2
            continue
        if char in {"'", '"', "`"}:
            quote = char
            idx += 1
            continue
        if char == "(":
            depth += 1
            idx += 1
            continue
        if char == ")":
            depth = max(depth - 1, 0)
            idx += 1
            continue

        if depth != 0:
            idx += 1
            continue

        prev_char = sql[idx - 1] if idx > 0 else ""
        if prev_char and _is_word_char(prev_char):
            idx += 1
            continue

        matched_keyword: str | None = None
        for keyword in sorted_keywords:
            chunk = sql[idx : idx + len(keyword)]
            if chunk.lower() != keyword:
                continue
            next_char = sql[idx + len(keyword)] if idx + len(keyword) < len(sql) else ""
            if next_char and _is_word_char(next_char):
                continue
            matched_keyword = keyword
            break

        if matched_keyword is not None:
            positions.append((idx, matched_keyword))
            idx += len(matched_keyword)
            continue

        idx += 1

    return positions


def _segment_matches_alias(segment: str, join_alias: str) -> bool:
    """Return True when a JOIN segment targets the expected alias."""
    on_positions = _find_top_level_keyword_positions(segment, ("on",))
    if not on_positions:
        return False
    target_sql = segment[: on_positions[0][0]].strip()
    return bool(
        re.search(
            rf"(?is)(?:as\s+)?{re.escape(join_alias)}\s*$",
            target_sql,
        )
    )


def _find_join_segment(cte_body: str, join_alias: str) -> tuple[int, int] | None:
    """Return the text span of the named top-level LEFT JOIN."""
    positions = _find_top_level_keyword_positions(
        cte_body,
        _JOIN_KEYWORDS + _CLAUSE_KEYWORDS,
    )

    for idx, (start, keyword) in enumerate(positions):
        if keyword not in {"left join", "left outer join"}:
            continue

        end = positions[idx + 1][0] if idx + 1 < len(positions) else len(cte_body)
        segment = cte_body[start:end]
        if not _segment_matches_alias(segment, join_alias):
            continue

        line_start = cte_body.rfind("\n", 0, start) + 1
        remove_start = line_start if not cte_body[line_start:start].strip() else start
        return remove_start, end

    return None


def _remove_join_from_cte(sql: str, cte_name: str, join_alias: str) -> str | None:
    """Remove one top-level LEFT JOIN from a named CTE."""
    boundaries = _find_cte_boundaries(sql, cte_name)
    if boundaries is None:
        logger.debug(
            "Could not locate CTE %s while removing join %s", cte_name, join_alias
        )
        return None

    body_start, body_end = boundaries
    body = sql[body_start:body_end]
    segment = _find_join_segment(body, join_alias)
    if segment is None:
        logger.debug(
            "Could not locate join alias %s inside CTE %s", join_alias, cte_name
        )
        return None

    start, end = segment
    updated_body = body[:start] + body[end:]
    return sql[:body_start] + updated_body + sql[body_end:]


class RemoveUnusedJoinsTemplate(BaseTemplate):
    """Deterministic template that removes conservatively unused LEFT JOINs."""

    template_id = "remove_unused_joins"
    applicable_types = {"unused_join"}

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        evidence = opportunity.evidence_snapshot or {}
        joins = evidence.get("unused_joins", [])
        file_path = (manifest_metadata or {}).get("original_file_path", "")
        return bool(joins and file_path and source_files.get(file_path))

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        evidence = opportunity.evidence_snapshot or {}
        unused_joins: list[dict[str, Any]] = evidence.get("unused_joins", [])
        file_path = (manifest_metadata or {}).get("original_file_path", "")
        before_content = source_files.get(file_path, "")
        if not before_content or not unused_joins:
            return None

        content = before_content
        removed_joins: list[dict[str, Any]] = []
        for join in unused_joins:
            updated = _remove_join_from_cte(
                content,
                str(join["cte_name"]),
                str(join["join_alias"]),
            )
            if updated is None:
                continue
            content = updated
            removed_joins.append(join)

        if content == before_content or not removed_joins:
            return None

        model_name = (manifest_metadata or {}).get("name", opportunity.affected_table)
        join_list = "\n".join(
            f"  - `{item['cte_name']}` -> `{item['join_alias']}`"
            for item in removed_joins
        )
        explanation = (
            f"Removed {len(removed_joins)} unused LEFT JOIN(s) from `{model_name}`.\n\n"
            f"**JOINs removed:**\n{join_list}\n\n"
            "**What changed:** Only the listed LEFT JOIN clauses were removed. "
            "SELECT expressions, retained joins, filters, grouping, and Jinja refs "
            "were left intact."
        )

        return TemplateResult(
            template_id=self.template_id,
            file_path=file_path,
            before_content=before_content,
            after_content=content,
            change_type="sql_change",
            explanation=explanation,
            policy_tags=["sql_change"],
            parameters={
                "model_name": model_name,
                "unused_joins": removed_joins,
            },
            rollback=(
                f"Re-add the removed LEFT JOIN clauses in `{file_path}`. "
                "Review the stored evidence for the affected aliases and CTEs."
            ),
        )

    def rollback_instructions(self) -> str:
        return "Re-add the removed LEFT JOIN clauses to the affected CTEs."
