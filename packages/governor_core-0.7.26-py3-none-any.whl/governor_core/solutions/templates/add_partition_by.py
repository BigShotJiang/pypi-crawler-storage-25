"""Template: add partition_by config to a dbt model for partition_pruning opportunities."""

from __future__ import annotations

import logging
from typing import Any

from governor_core.solutions.templates.base import BaseTemplate, TemplateResult
from governor_core.solutions.templates.config_parser import (
    get_config_property,
    has_config_property,
    insert_config_property,
)

logger = logging.getLogger("app.solutions.templates.add_partition_by")


class AddPartitionByTemplate(BaseTemplate):
    """Adds partition_by configuration to a dbt model SQL file.

    Applicable to partition_pruning opportunities where evidence data
    contains a recommended partition column.
    """

    template_id = "add_partition_by"
    applicable_types = {"partition_pruning"}
    required_params = ["column", "data_type"]

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        if opportunity.opportunity_type not in self.applicable_types:
            return False

        if not source_files:
            return False

        column, data_type, _granularity = self._extract_partition_params(opportunity)
        if not column:
            return False

        model_path = self._find_model_path(source_files, manifest_metadata)
        if not model_path:
            return False

        # Check if partition_by already exists
        content = source_files.get(model_path, "")
        if has_config_property(content, "partition_by"):
            # Already partitioned — check if same column
            existing = get_config_property(content, "partition_by")
            if existing and column in existing:
                return False  # Same column, no change needed
            # Different column — skip (changing partition is destructive)
            logger.info(
                "Model %s already has partition_by with different column, skipping template",
                model_path,
            )
            return False

        return True

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        column, data_type, granularity = self._extract_partition_params(opportunity)
        if not column:
            return None

        model_path = self._find_model_path(source_files, manifest_metadata)
        if not model_path or model_path not in source_files:
            return None

        before_content = source_files[model_path]

        # Double-check: skip if already partitioned
        if has_config_property(before_content, "partition_by"):
            return None

        # Build partition_by value as a dbt-compatible dict.
        # For TIMESTAMP/DATETIME columns, BigQuery requires granularity
        # (e.g. TIMESTAMP_TRUNC(col, DAY)), so we must include it.
        if granularity:
            partition_value = (
                f'{{"field": "{column}", '
                f'"data_type": "{data_type}", '
                f'"granularity": "{granularity}"}}'
            )
        else:
            partition_value = f'{{"field": "{column}", "data_type": "{data_type}"}}'

        after_content = insert_config_property(
            before_content, "partition_by", partition_value
        )
        if after_content is None:
            return None

        granularity_note = f", granularity: {granularity}" if granularity else ""
        return TemplateResult(
            template_id=self.template_id,
            file_path=model_path,
            before_content=before_content,
            after_content=after_content,
            change_type="project_config_change",
            explanation=(
                f"Added partition_by configuration on column '{column}' "
                f"(data_type: {data_type}{granularity_note}) to enable "
                f"partition pruning. This allows BigQuery to skip scanning "
                f"irrelevant partitions, reducing bytes processed and cost."
            ),
            policy_tags=["dbt_config_change"],
            parameters={
                "column": column,
                "data_type": data_type,
                **({"granularity": granularity} if granularity else {}),
            },
            rollback=self.rollback_instructions(),
        )

    def rollback_instructions(self) -> str:
        return (
            "Remove the partition_by property from the model's config block. "
            "Note: if the table was already materialized with partitioning, "
            "a full refresh may be needed after removing the config."
        )

    def _extract_partition_params(self, opportunity) -> tuple[str, str, str | None]:
        """Extract partition column, data type, and granularity from evidence.

        Returns (column, data_type, granularity).  For TIMESTAMP/DATETIME
        columns BigQuery requires granularity (e.g. "day") in the dbt
        ``partition_by`` dict, otherwise the DDL fails.
        """
        evidence = getattr(opportunity, "evidence_snapshot", None)
        if not evidence or not isinstance(evidence, dict):
            return "", "", None

        column = evidence.get("recommended_partition_column", "")
        if not column:
            column = evidence.get("partition_column", "")

        # Use actual BigQuery data type when available
        bq_data_type = evidence.get("partition_data_type", "")
        if bq_data_type:
            from governor_core.dbt.column_lookup import resolve_bq_partition_data_type

            data_type, granularity = resolve_bq_partition_data_type(bq_data_type)
        else:
            data_type, granularity = "date", None

        return column, data_type, granularity

    def _find_model_path(
        self,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> str | None:
        """Find the SQL model file path from source files."""
        if manifest_metadata:
            original_path = manifest_metadata.get("original_file_path")
            if original_path and original_path in source_files:
                return original_path

        for path in source_files:
            if path.endswith(".sql") and not path.endswith("dbt_project.yml"):
                return path

        return None
