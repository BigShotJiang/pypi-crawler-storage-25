"""SQL structural comparison using sqlglot AST parsing.

Parses before/after SQL files into abstract syntax trees and compares
them structurally to detect additions, removals, and modifications of
columns, CTEs, JOINs, WHERE clauses, GROUP BY, and ORDER BY.

Pre-processes SQL through jinja_strip to handle dbt Jinja2 templating.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp

from governor_core.solutions.validation.jinja_strip import strip_jinja


class ParseError(Exception):
    """Raised when SQL cannot be parsed into an AST."""


@dataclass
class StructuralComparison:
    """Result of comparing two SQL ASTs structurally."""

    columns_added: list[str] = field(default_factory=list)
    columns_removed: list[str] = field(default_factory=list)
    columns_modified: list[str] = field(default_factory=list)
    ctes_added: list[str] = field(default_factory=list)
    ctes_removed: list[str] = field(default_factory=list)
    joins_added: list[str] = field(default_factory=list)
    joins_removed: list[str] = field(default_factory=list)
    where_changed: bool = False
    group_by_changed: bool = False
    order_by_changed: bool = False
    config_changes: list[str] = field(default_factory=list)


def compare_sql(
    before: str, after: str, dialect: str = "bigquery"
) -> StructuralComparison:
    """Parse both SQL strings with sqlglot, extract and compare structure.

    Before parsing, strips Jinja2 expressions via the jinja_strip module.
    Raises ParseError if either file cannot be parsed.

    Args:
        before: Original SQL content (may contain Jinja2).
        after: Modified SQL content (may contain Jinja2).
        dialect: SQL dialect for sqlglot parsing. Defaults to "bigquery".

    Returns:
        StructuralComparison with detected differences.

    Raises:
        ParseError: If either SQL string cannot be parsed after Jinja2 stripping.
    """
    before_strip = strip_jinja(before)
    after_strip = strip_jinja(after)

    if not before_strip.success or not after_strip.success:
        raise ParseError(
            "Complex Jinja2 templating prevented clean stripping. "
            "Cannot produce reliable AST comparison."
        )

    before_sql = before_strip.sql
    after_sql = after_strip.sql

    # Detect config-only changes: if the stripped SQL bodies are identical
    # but expressions were replaced, the diff is config-only.
    config_changes: list[str] = []
    if before_sql == after_sql:
        if before_strip.expressions_replaced != after_strip.expressions_replaced:
            config_changes.append("jinja_config_block_changed")
        # Even if expressions match, check if the raw files differed
        # only in config blocks by comparing raw input vs stripped output.
        if before != after:
            config_changes.append("config_only_change")
        return StructuralComparison(config_changes=config_changes)

    before_ast = _parse(before_sql, dialect)
    after_ast = _parse(after_sql, dialect)

    # Extract structural elements from both ASTs
    before_columns = _extract_select_columns(before_ast)
    after_columns = _extract_select_columns(after_ast)

    before_ctes = _extract_cte_names(before_ast)
    after_ctes = _extract_cte_names(after_ast)

    before_joins = _extract_join_tables(before_ast)
    after_joins = _extract_join_tables(after_ast)

    before_where = _extract_where(before_ast)
    after_where = _extract_where(after_ast)

    before_group_by = _extract_group_by(before_ast)
    after_group_by = _extract_group_by(after_ast)

    before_order_by = _extract_order_by(before_ast)
    after_order_by = _extract_order_by(after_ast)

    # Compare columns
    before_col_set = set(before_columns)
    after_col_set = set(after_columns)
    columns_added = sorted(after_col_set - before_col_set)
    columns_removed = sorted(before_col_set - after_col_set)

    # Detect modified columns: same alias but different expression.
    # Build maps of alias -> full expression string for common columns.
    columns_modified = _detect_modified_columns(before_ast, after_ast)

    # Compare CTEs
    before_cte_set = set(before_ctes)
    after_cte_set = set(after_ctes)
    ctes_added = sorted(after_cte_set - before_cte_set)
    ctes_removed = sorted(before_cte_set - after_cte_set)

    # Compare JOINs
    before_join_set = set(before_joins)
    after_join_set = set(after_joins)
    joins_added = sorted(after_join_set - before_join_set)
    joins_removed = sorted(before_join_set - after_join_set)

    # Compare WHERE, GROUP BY, ORDER BY
    where_changed = before_where != after_where
    group_by_changed = before_group_by != after_group_by
    order_by_changed = before_order_by != after_order_by

    return StructuralComparison(
        columns_added=columns_added,
        columns_removed=columns_removed,
        columns_modified=columns_modified,
        ctes_added=ctes_added,
        ctes_removed=ctes_removed,
        joins_added=joins_added,
        joins_removed=joins_removed,
        where_changed=where_changed,
        group_by_changed=group_by_changed,
        order_by_changed=order_by_changed,
        config_changes=config_changes,
    )


def _parse(sql: str, dialect: str) -> exp.Expression:
    """Parse SQL string into a sqlglot AST.

    Raises ParseError if parsing fails.
    """
    try:
        ast = sqlglot.parse_one(sql, dialect=dialect)
    except sqlglot.errors.ParseError as exc:
        raise ParseError(f"Failed to parse SQL: {exc}") from exc
    except sqlglot.errors.SqlglotError as exc:
        raise ParseError(f"Unexpected error parsing SQL: {exc}") from exc
    return ast


def _extract_select_columns(ast: exp.Expression) -> list[str]:
    """Extract column aliases/names from the outermost SELECT.

    Returns a list of column identifiers. For aliased expressions,
    uses the alias. For bare column references, uses the column name.
    For complex expressions without an alias, uses the SQL string.
    """
    columns: list[str] = []
    # Find the outermost SELECT statement
    select = ast.find(exp.Select)
    if select is None:
        return columns

    for expr in select.expressions:
        if isinstance(expr, exp.Alias):
            columns.append(expr.alias)
        elif isinstance(expr, exp.Column):
            columns.append(expr.name)
        elif isinstance(expr, exp.Star):
            columns.append("*")
        else:
            # Use the SQL representation for complex expressions
            columns.append(expr.sql())

    return columns


def _extract_cte_names(ast: exp.Expression) -> list[str]:
    """Extract CTE alias names from the AST."""
    names: list[str] = []
    for cte in ast.find_all(exp.CTE):
        alias = cte.alias
        if alias:
            names.append(alias)
    return names


def _extract_join_tables(ast: exp.Expression) -> list[str]:
    """Extract table names from JOIN clauses."""
    tables: list[str] = []
    for join in ast.find_all(exp.Join):
        # The join's "this" is the table/subquery being joined
        table_expr = join.this
        if isinstance(table_expr, exp.Table):
            name = table_expr.name
            if table_expr.alias:
                name = f"{name} AS {table_expr.alias}"
            tables.append(name)
        elif isinstance(table_expr, exp.Subquery) and table_expr.alias:
            tables.append(f"subquery AS {table_expr.alias}")
        elif hasattr(table_expr, "alias") and table_expr.alias:
            tables.append(table_expr.alias)
        else:
            tables.append(table_expr.sql())
    return tables


def _extract_where(ast: exp.Expression) -> str | None:
    """Extract the normalized WHERE clause as a string, or None."""
    where = ast.find(exp.Where)
    if where is None:
        return None
    return where.sql(dialect="bigquery")


def _extract_group_by(ast: exp.Expression) -> str | None:
    """Extract the normalized GROUP BY clause as a string, or None."""
    group = ast.find(exp.Group)
    if group is None:
        return None
    return group.sql(dialect="bigquery")


def _extract_order_by(ast: exp.Expression) -> str | None:
    """Extract the normalized ORDER BY clause as a string, or None."""
    order = ast.find(exp.Order)
    if order is None:
        return None
    return order.sql(dialect="bigquery")


def _detect_modified_columns(
    before_ast: exp.Expression, after_ast: exp.Expression
) -> list[str]:
    """Detect columns present in both before and after but with different expressions.

    Compares columns that share the same alias or name but have different
    underlying SQL expressions.
    """
    before_map = _build_column_expression_map(before_ast)
    after_map = _build_column_expression_map(after_ast)

    modified: list[str] = []
    for name in sorted(set(before_map) & set(after_map)):
        if before_map[name] != after_map[name]:
            modified.append(name)

    return modified


def _build_column_expression_map(ast: exp.Expression) -> dict[str, str]:
    """Build a map of column name/alias -> expression SQL for the outermost SELECT."""
    col_map: dict[str, str] = {}
    select = ast.find(exp.Select)
    if select is None:
        return col_map

    for expr in select.expressions:
        if isinstance(expr, exp.Alias):
            col_map[expr.alias] = expr.this.sql(dialect="bigquery")
        elif isinstance(expr, exp.Column):
            col_map[expr.name] = expr.sql(dialect="bigquery")
        elif isinstance(expr, exp.Star):
            col_map["*"] = "*"
        else:
            key = expr.sql(dialect="bigquery")
            col_map[key] = key

    return col_map
