"""YAML structural comparison for dbt schema files.

Parses before/after YAML strings and compares their structure
recursively to detect added, removed, and modified keys.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import yaml

from governor_core.solutions.validation.ast_validator import ParseError


@dataclass
class YamlComparison:
    """Result of comparing two YAML documents structurally."""

    keys_added: list[str] = field(default_factory=list)
    keys_removed: list[str] = field(default_factory=list)
    keys_modified: list[str] = field(default_factory=list)


def compare_yaml(before: str, after: str) -> YamlComparison:
    """Parse both YAML strings and compare keys/values.

    Walks the parsed YAML structures recursively, comparing keys
    at each level. Keys are reported using dot-separated paths
    (e.g., "models.my_model.columns").

    Args:
        before: Original YAML content.
        after: Modified YAML content.

    Returns:
        YamlComparison with detected differences.

    Raises:
        ParseError: If either YAML string cannot be parsed.
    """
    before_data = _parse_yaml(before, "before")
    after_data = _parse_yaml(after, "after")

    added: list[str] = []
    removed: list[str] = []
    modified: list[str] = []

    _compare_recursive(before_data, after_data, "", added, removed, modified)

    return YamlComparison(
        keys_added=sorted(added),
        keys_removed=sorted(removed),
        keys_modified=sorted(modified),
    )


def _parse_yaml(content: str, label: str) -> object:
    """Parse a YAML string safely.

    Args:
        content: YAML string to parse.
        label: Label for error messages ("before" or "after").

    Returns:
        Parsed YAML data (dict, list, or scalar).

    Raises:
        ParseError: If YAML parsing fails.
    """
    try:
        data = yaml.safe_load(content)
    except yaml.YAMLError as exc:
        raise ParseError(f"Failed to parse {label} YAML: {exc}") from exc
    # safe_load returns None for empty documents
    if data is None:
        return {}
    return data


def _compare_recursive(
    before: object,
    after: object,
    prefix: str,
    added: list[str],
    removed: list[str],
    modified: list[str],
) -> None:
    """Recursively compare two YAML structures.

    Args:
        before: Parsed YAML structure from the original file.
        after: Parsed YAML structure from the modified file.
        prefix: Dot-separated key path prefix for nested keys.
        added: Accumulator list for added key paths.
        removed: Accumulator list for removed key paths.
        modified: Accumulator list for modified key paths.
    """
    if isinstance(before, dict) and isinstance(after, dict):
        _compare_dicts(before, after, prefix, added, removed, modified)
    elif isinstance(before, list) and isinstance(after, list):
        _compare_lists(before, after, prefix, added, removed, modified)
    else:
        # Type changed or scalar value changed
        if before != after:
            path = prefix if prefix else "<root>"
            modified.append(path)


def _compare_dicts(
    before: dict,
    after: dict,
    prefix: str,
    added: list[str],
    removed: list[str],
    modified: list[str],
) -> None:
    """Compare two dictionaries recursively."""
    before_keys = set(before.keys())
    after_keys = set(after.keys())

    for key in sorted(after_keys - before_keys):
        path = f"{prefix}.{key}" if prefix else str(key)
        added.append(path)

    for key in sorted(before_keys - after_keys):
        path = f"{prefix}.{key}" if prefix else str(key)
        removed.append(path)

    for key in sorted(before_keys & after_keys):
        path = f"{prefix}.{key}" if prefix else str(key)
        _compare_recursive(before[key], after[key], path, added, removed, modified)


def _compare_lists(
    before: list,
    after: list,
    prefix: str,
    added: list[str],
    removed: list[str],
    modified: list[str],
) -> None:
    """Compare two lists.

    For lists of dicts with a 'name' key (common in dbt schema files),
    uses the name as a key for matching. Otherwise falls back to
    positional comparison.
    """
    # Check if both lists contain dicts with 'name' keys (dbt pattern)
    if _is_named_list(before) and _is_named_list(after):
        _compare_named_lists(before, after, prefix, added, removed, modified)
        return

    # Positional comparison for other lists
    max_len = max(len(before), len(after))
    for i in range(max_len):
        item_path = f"{prefix}[{i}]"
        if i >= len(before):
            added.append(item_path)
        elif i >= len(after):
            removed.append(item_path)
        else:
            _compare_recursive(before[i], after[i], item_path, added, removed, modified)


def _is_named_list(items: list) -> bool:
    """Check if a list consists of dicts that all have a 'name' key."""
    if not items:
        return False
    return all(isinstance(item, dict) and "name" in item for item in items)


def _compare_named_lists(
    before: list[dict],
    after: list[dict],
    prefix: str,
    added: list[str],
    removed: list[str],
    modified: list[str],
) -> None:
    """Compare lists of named dicts (e.g., dbt model/column definitions).

    Matches items by their 'name' key rather than position.
    """
    before_map = {item["name"]: item for item in before}
    after_map = {item["name"]: item for item in after}

    before_names = set(before_map.keys())
    after_names = set(after_map.keys())

    for name in sorted(after_names - before_names):
        path = f"{prefix}.{name}" if prefix else str(name)
        added.append(path)

    for name in sorted(before_names - after_names):
        path = f"{prefix}.{name}" if prefix else str(name)
        removed.append(path)

    for name in sorted(before_names & after_names):
        path = f"{prefix}.{name}" if prefix else str(name)
        _compare_recursive(
            before_map[name], after_map[name], path, added, removed, modified
        )
