"""SQLAlchemy ORM models for solution generation."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON

from governor_core.db.base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class SolutionJob(Base):
    """Asynchronous solution generation task.

    Tracks the lifecycle of generating a solution for a single opportunity.
    Status transitions: queued -> in_progress -> completed/failed
    """

    __tablename__ = "solution_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    opportunity_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    detection_job_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("detection_jobs.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="queued")
    resolution_category: Mapped[str | None] = mapped_column(String(32), nullable=True)
    queued_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    lifetime_retry_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    max_lifetime_retries: Mapped[int] = mapped_column(
        Integer, nullable=False, default=10
    )
    failure_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_stage: Mapped[str | None] = mapped_column(String(32), nullable=True)
    llm_provider: Mapped[str | None] = mapped_column(String(32), nullable=True)
    llm_model: Mapped[str | None] = mapped_column(String(64), nullable=True)
    prompt_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    completion_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    llm_latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    solutions_generated_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    trust_tier: Mapped[str | None] = mapped_column(String(16), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    opportunity: Mapped["Opportunity"] = relationship(
        "Opportunity",
        foreign_keys=[opportunity_id],
    )
    solutions: Mapped[list["Solution"]] = relationship(
        "Solution",
        back_populates="solution_job",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        CheckConstraint(
            "status IN ('queued', 'in_progress', 'completed', 'failed')",
            name="ck_sj_status",
        ),
        CheckConstraint(
            "retry_count >= 0 AND retry_count <= 5",
            name="ck_sj_retry_count",
        ),
        CheckConstraint(
            "resolution_category IS NULL OR resolution_category IN ('dbt_project_change', 'bigquery_infrastructure')",
            name="ck_sj_resolution_category",
        ),
        CheckConstraint(
            "error_stage IS NULL OR error_stage IN ('github_retrieval', 'llm_request', 'response_parsing', 'storage', 'validation')",
            name="ck_sj_error_stage",
        ),
        CheckConstraint(
            "trust_tier IS NULL OR trust_tier IN ('guaranteed_safe', 'validated', 'requires_review')",
            name="ck_sj_trust_tier",
        ),
        Index("ix_sj_status_queued_at", "status", "queued_at"),
        Index("ix_sj_trust_tier", "trust_tier"),
        Index(
            "uq_solution_jobs_active_opportunity",
            "opportunity_id",
            unique=True,
            postgresql_where=text("status IN ('queued', 'in_progress')"),
            sqlite_where=text("status IN ('queued', 'in_progress')"),
        ),
    )


class Solution(Base):
    """Generated before/after representation for a cost optimization opportunity.

    One row per file (dbt changes) or per setting (BigQuery changes).
    Versioned per (opportunity_id, file_path) with a max of 3 versions.
    """

    __tablename__ = "solutions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    opportunity_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    solution_job_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("solution_jobs.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    manifest_version_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("manifest_versions.id", ondelete="SET NULL"),
        nullable=True,
    )
    resolution_category: Mapped[str] = mapped_column(String(32), nullable=False)
    version_number: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    # dbt project change fields
    # file_changes is the canonical representation for multi-file solutions
    # (e.g. enforcing require_partition_filter upstream + downstream filter
    # edits). The legacy single-file columns stay populated with the primary
    # (first) entry for backward compatibility with older readers.
    file_changes: Mapped[list[dict] | None] = mapped_column(
        JSONB().with_variant(JSON, "sqlite"), nullable=True
    )
    file_path: Mapped[str | None] = mapped_column(String(512), nullable=True)
    change_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    before_content: Mapped[str | None] = mapped_column(Text, nullable=True)
    after_content: Mapped[str | None] = mapped_column(Text, nullable=True)
    compiled_after_sql: Mapped[str | None] = mapped_column(Text, nullable=True)
    repository: Mapped[str | None] = mapped_column(String(256), nullable=True)
    commit_sha: Mapped[str | None] = mapped_column(String(40), nullable=True)
    # BigQuery infrastructure fields
    current_setting_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    recommended_setting_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    affected_resource: Mapped[str | None] = mapped_column(String(512), nullable=True)
    # Common fields
    explanation: Mapped[str] = mapped_column(Text, nullable=False)
    risk_level: Mapped[str] = mapped_column(String(16), nullable=False)
    risk_justification: Mapped[str] = mapped_column(Text, nullable=False)
    trust_tier: Mapped[str | None] = mapped_column(String(16), nullable=True)
    validation_report: Mapped[dict | None] = mapped_column(
        JSONB().with_variant(JSON, "sqlite"), nullable=True
    )
    # Dry run results (spec 040) — cached from BigQuery dry run API
    dry_run_original: Mapped[dict | None] = mapped_column(
        JSONB().with_variant(JSON, "sqlite"), nullable=True
    )
    dry_run_modified: Mapped[dict | None] = mapped_column(
        JSONB().with_variant(JSON, "sqlite"), nullable=True
    )
    # Shadow validation (spec 110)
    shadow_validation_run_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey(
            "shadow_validation_runs.id",
            ondelete="SET NULL",
            use_alter=True,
            name="fk_solutions_shadow_validation_run_id",
        ),
        nullable=True,
    )
    applied_locally_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    local_apply_resolution: Mapped[str | None] = mapped_column(
        String(64), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    solution_job: Mapped["SolutionJob"] = relationship(
        "SolutionJob",
        back_populates="solutions",
    )

    @property
    def normalized_file_changes(self) -> list[dict]:
        """Return the file changes as a list of dicts regardless of storage.

        Prefers the ``file_changes`` JSONB column (multi-file solutions).
        Falls back to a single-element list reconstructed from the legacy
        single-file columns so older rows and cloud-mode writes keep working.
        Returns an empty list when the row is a bigquery_infrastructure
        solution or has no file content at all.
        """
        if self.file_changes:
            return list(self.file_changes)
        if self.file_path and self.after_content is not None:
            return [
                {
                    "file_path": self.file_path,
                    "change_type": self.change_type,
                    "before_content": self.before_content,
                    "after_content": self.after_content,
                }
            ]
        return []

    __table_args__ = (
        CheckConstraint(
            "resolution_category IN ('dbt_project_change', 'bigquery_infrastructure')",
            name="ck_sol_resolution_category",
        ),
        CheckConstraint(
            "risk_level IN ('low', 'medium', 'high')",
            name="ck_sol_risk_level",
        ),
        CheckConstraint(
            "change_type IS NULL OR change_type IN ('sql_change', 'project_config_change', 'schema_change')",
            name="ck_sol_change_type",
        ),
        CheckConstraint(
            "trust_tier IS NULL OR trust_tier IN ('guaranteed_safe', 'validated', 'requires_review')",
            name="ck_sol_trust_tier",
        ),
        Index(
            "ix_sol_opportunity_file_version",
            "opportunity_id",
            "file_path",
            "version_number",
        ),
        Index("ix_sol_resolution_category", "resolution_category"),
        Index("ix_sol_trust_tier", "trust_tier"),
    )


# Import here to make relationship strings resolve
from governor_core.opportunities.models import Opportunity  # noqa: E402, F401
from governor_core.sync.models import ManifestVersion  # noqa: E402, F401
