from __future__ import annotations

from typing import Any

from governor_core.solutions.policy import classify_solution_policy_tags


def _strip_dbt_config_blocks(sql: str) -> str:
    """Remove dbt ``{{ config(...) }}`` blocks from raw model SQL."""
    from governor_core.solutions.templates.config_parser import parse_config_block

    stripped_sql = sql
    while True:
        block = parse_config_block(stripped_sql)
        if block is None:
            return stripped_sql
        stripped_sql = stripped_sql[: block.start] + stripped_sql[block.end :]


def _normalize_configless_sql(sql: str | None) -> str:
    """Normalize SQL after removing config blocks for body-only comparisons."""
    if not sql:
        return ""
    configless = _strip_dbt_config_blocks(sql)
    return "\n".join(line.rstrip() for line in configless.splitlines()).strip()


def _contains_dbt_jinja(sql: str | None) -> bool:
    """Whether SQL still contains dbt/Jinja template markers."""
    if not sql:
        return False
    return any(marker in sql for marker in ("{{", "{%", "{#"))


def _is_config_only_validation_report(validation_report: dict[str, Any] | None) -> bool:
    """Return True when validation evidence shows only dbt config changes."""
    if not isinstance(validation_report, dict):
        return False

    steps = validation_report.get("steps")
    if not isinstance(steps, list):
        return False

    for step in steps:
        if not isinstance(step, dict):
            continue
        if step.get("type") != "structural_comparison":
            continue

        details = step.get("details")
        if not isinstance(details, dict):
            continue

        config_changes = details.get("config_changes")
        if not config_changes:
            continue

        if any(
            details.get(key)
            for key in (
                "columns_added",
                "columns_removed",
                "columns_modified",
                "ctes_added",
                "ctes_removed",
                "joins_added",
                "joins_removed",
            )
        ):
            continue

        if any(
            bool(details.get(key))
            for key in ("where_changed", "group_by_changed", "order_by_changed")
        ):
            continue

        return True

    return False


def solution_is_config_only_change(solution: Any) -> bool:
    """Whether the solution is a config-only change with no optimized SQL diff."""
    if getattr(solution, "change_type", None) == "project_config_change":
        return True

    before_content = getattr(solution, "before_content", None)
    after_content = getattr(solution, "after_content", None)
    if isinstance(before_content, str) and isinstance(after_content, str):
        if _normalize_configless_sql(before_content) == _normalize_configless_sql(
            after_content
        ):
            return True

    validation_report = getattr(solution, "validation_report", None)
    return _is_config_only_validation_report(validation_report)


def solution_prefers_possible_savings_display(solution: Any) -> bool:
    """Whether savings UI should stay on estimated/possible savings.

    Dry-run deltas are misleading for dbt config and materialization changes,
    because they do not reliably represent the runtime impact of config-driven
    optimizations such as partitioning, clustering, or materialization shifts.
    """
    if getattr(solution, "resolution_category", None) != "dbt_project_change":
        return False

    policy_tags = classify_solution_policy_tags(
        resolution_category=getattr(solution, "resolution_category", "") or "",
        change_type=getattr(solution, "change_type", None),
        file_path=getattr(solution, "file_path", None),
        before_content=getattr(solution, "before_content", None),
        after_content=getattr(solution, "after_content", None),
    )
    return bool({"dbt_config_change", "materialization_change"} & policy_tags)


def solution_supports_optimized_dry_run(solution: Any) -> bool:
    """Whether a solution has a real optimized SQL artifact worth displaying."""
    if getattr(solution, "resolution_category", None) != "dbt_project_change":
        return False

    if solution_prefers_possible_savings_display(solution):
        return False

    if solution_is_config_only_change(solution):
        return False

    if getattr(solution, "dry_run_modified", None) is not None:
        return True

    compiled_after_sql = getattr(solution, "compiled_after_sql", None)
    if not isinstance(compiled_after_sql, str) or not compiled_after_sql.strip():
        return False

    if _contains_dbt_jinja(compiled_after_sql):
        return False

    return True


def solution_requires_dry_run_backfill(solution: Any) -> bool:
    """Whether request/background backfill still has useful dry-run work to do."""
    if getattr(solution, "resolution_category", None) != "dbt_project_change":
        return False

    if getattr(solution, "dry_run_original", None) is None:
        return True

    return solution_supports_optimized_dry_run(solution) and (
        getattr(solution, "dry_run_modified", None) is None
    )
