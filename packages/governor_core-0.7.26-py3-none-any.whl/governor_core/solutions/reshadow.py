"""Spec 128: kick off a fresh shadow validation against the current bundle.

Supersedes any in-flight shadow run for the same solution so the UI always
reflects the latest result (FR-012). The overlay is ``solution.file_changes``
as it currently stands — every entry, regardless of ``proposal_meta.status`` —
so the user's in-progress edits are what gets validated.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session

logger = logging.getLogger("app.solutions.reshadow")


def kick_off_reshadow(db: Session, solution):
    """Mark in-flight shadow runs for ``solution`` as superseded and enqueue
    a fresh one. Returns the new ``ShadowValidationRun`` row.

    The actual shadow execution flows through the existing
    ``run_shadow_validation()`` entry point from spec 110, invoked by whichever
    caller holds the builder/metrics/gate callables. This helper handles only
    the persistence state transition — the caller threads the run through the
    builder.
    """
    from governor_core.shadow.models import ShadowValidationRun

    in_flight = (
        db.query(ShadowValidationRun)
        .filter(
            ShadowValidationRun.solution_id == solution.id,
            ShadowValidationRun.status.in_(("queued", "running")),
        )
        .all()
    )
    for run in in_flight:
        run.status = "superseded"
        run.finished_at = datetime.now(timezone.utc)
        logger.info("spec-128 reshadow: superseded in-flight run %s", run.id)


    from governor_core.opportunities.models import Opportunity

    manifest_version_id = getattr(solution, "manifest_version_id", None)
    config_id = None

    # Prefer solution_job.config_id when available (cheapest).
    sj = getattr(solution, "solution_job", None)
    if sj is not None:
        config_id = getattr(sj, "config_id", None)

    # Fall back to the opportunity lookup.
    if config_id is None and solution.opportunity_id:
        opp = db.get(Opportunity, solution.opportunity_id)
        if opp is not None:
            config_id = opp.config_id
            if manifest_version_id is None:
                manifest_version_id = getattr(opp, "manifest_version_id", None)

    if config_id is None:
        raise ValueError(
            f"spec-128 reshadow: cannot resolve config_id for solution {solution.id}"
        )

    hex12 = str(solution.id).replace("-", "")[:12]
    new_run = ShadowValidationRun(
        solution_id=solution.id,
        config_id=config_id,
        manifest_version_id=manifest_version_id,
        status="queued",
        triggered_by="manual",
        solution_id_hex12=hex12,
        created_at=datetime.now(timezone.utc),
    )
    db.add(new_run)
    db.flush()
    logger.info(
        "spec-128 reshadow: queued new run %s for solution %s",
        new_run.id,
        solution.id,
    )
    return new_run
