"""Shadow-name minting + invariant enforcement.

Every BigQuery DDL issued by the shadow subsystem MUST pass through
`enforce_shadow_name()` as a guard against accidental writes to production
tables. This is the single audit surface — reviewers can verify that no
CREATE/DROP bypasses this guard.
"""

from __future__ import annotations

from governor_core.shadow.exceptions import ShadowInvariantViolation

_SUFFIX_HEX_CHARS = 12


def _solution_id_hex12(solution_id: str) -> str:
    """First 12 hex chars of a UUID string, dashes stripped.

    Examples:
        '550e8400-e29b-41d4-a716-446655440000' -> '550e8400e29b'
    """
    stripped = solution_id.replace("-", "")
    if len(stripped) < _SUFFIX_HEX_CHARS:
        raise ValueError(
            f"solution_id too short to derive suffix: {solution_id!r}"
        )
    return stripped[:_SUFFIX_HEX_CHARS]


def mint_shadow_suffix(solution_id: str) -> str:
    """Return the canonical suffix for shadow artifacts of this solution."""
    return f"__governor_{_solution_id_hex12(solution_id)}"


def mint_shadow_name(base_name: str, solution_id: str) -> str:
    """Return the shadow-qualified table name for a base dbt node name."""
    suffix = mint_shadow_suffix(solution_id)
    # BigQuery allows 1024-char table names but dbt and ergonomics favour shorter.
    max_base_len = 240 - len(suffix)
    if len(base_name) > max_base_len:
        base_name = base_name[:max_base_len]
    return f"{base_name}{suffix}"


def enforce_shadow_name(table_name: str, solution_id: str) -> None:
    """Raise if `table_name` lacks the expected shadow suffix for this solution."""
    suffix = mint_shadow_suffix(solution_id)
    if suffix not in table_name:
        raise ShadowInvariantViolation(
            f"refusing to operate on table {table_name!r}: missing suffix {suffix!r}"
        )
