"""Exception types for the shadow subsystem."""

from __future__ import annotations


class ShadowError(Exception):
    """Base class for shadow-validation errors."""


class ShadowSkipped(ShadowError):
    """Gating refused to run shadow validation. Carries a reason."""

    def __init__(self, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(f"{reason}: {detail}" if detail else reason)


class ShadowFailed(ShadowError):
    """Shadow validation ran but failed. Carries a failure reason."""

    def __init__(self, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(f"{reason}: {detail}" if detail else reason)


class ShadowCleanupError(ShadowError):
    """Cleanup of one or more shadow artifacts failed."""


class ShadowInvariantViolation(ShadowError):
    """A shadow code path attempted an operation on a non-shadow table name."""
