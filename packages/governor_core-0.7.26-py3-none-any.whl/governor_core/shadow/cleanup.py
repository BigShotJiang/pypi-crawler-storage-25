"""Cleanup of shadow artifacts.

Every shadow run, on success or failure, attempts to drop every shadow
artifact it created. All DROPs pass through `enforce_shadow_name()` as a
guard — a shadow code path MUST NEVER drop a table lacking the expected
suffix.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable

from governor_core.shadow.naming import enforce_shadow_name

logger = logging.getLogger("app.shadow.cleanup")


@dataclass
class CleanupResult:
    deleted: list[str] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)  # (name, error)


class BqAdapter:
    """Thin interface the cleanup module needs from BigQuery.

    Defined as a duck-typed protocol rather than importing the real client so
    the cleanup module is unit-testable without google-cloud-bigquery.
    Implementations should expose:
        list_tables(dataset: str) -> list[str]
        drop_table(dataset: str, name: str) -> None
    """


def cleanup_run(
    *,
    solution_id: str,
    dataset: str,
    bq: Callable | object,
    candidate_names: list[str] | None = None,
) -> CleanupResult:
    """Drop every shadow artifact matching the solution's suffix.

    Args:
        solution_id: the solution UUID whose suffix we will drop.
        dataset: target BigQuery dataset.
        bq: an object with `list_tables(dataset)` and `drop_table(dataset, name)`
            methods (or equivalent callables). In production, an adapter that
            wraps `google.cloud.bigquery.Client`.
        candidate_names: optional pre-computed list of table names to consider.
            If omitted, we call `bq.list_tables(dataset)`.
    """
    result = CleanupResult()
    names = candidate_names if candidate_names is not None else bq.list_tables(dataset)
    for name in names:
        try:
            enforce_shadow_name(name, solution_id)
        except Exception:
            # Not a shadow artifact for this solution — leave alone.
            continue
        try:
            bq.drop_table(dataset, name)
            result.deleted.append(name)
        except Exception as e:  # noqa: BLE001
            logger.warning("failed to drop shadow artifact %s: %s", name, e)
            result.failed.append((name, str(e)))
    return result
