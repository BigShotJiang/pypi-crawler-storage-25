"""Compute empirical deltas between baseline and shadow runs."""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal


# BigQuery on-demand pricing — $6.25 per TiB processed (2026). Keep in sync
# with the pricing constant used elsewhere in the platform.
_BQ_USD_PER_BYTE = Decimal("6.25") / (Decimal(1024) ** 4)


@dataclass
class ModelMetric:
    """Captured metrics for one model in one phase."""

    model_name: str
    bytes_processed: int | None = None
    slot_ms: int | None = None
    duration_ms: int | None = None
    row_count: int | None = None
    error_type: str | None = None
    error_message: str | None = None

    @property
    def cost_usd(self) -> Decimal:
        if self.bytes_processed is None:
            return Decimal("0")
        return Decimal(self.bytes_processed) * _BQ_USD_PER_BYTE


@dataclass
class ModelDiff:
    model_name: str
    baseline: ModelMetric | None
    shadow: ModelMetric | None
    row_count_parity: bool
    bytes_regressed: bool  # True if shadow bytes > baseline bytes


@dataclass
class DiffResult:
    per_model: list[ModelDiff] = field(default_factory=list)
    total_baseline_bytes: int = 0
    total_shadow_bytes: int = 0
    total_baseline_slot_ms: int = 0
    total_shadow_slot_ms: int = 0
    total_baseline_cost_usd: Decimal = field(default_factory=lambda: Decimal("0"))
    total_shadow_cost_usd: Decimal = field(default_factory=lambda: Decimal("0"))

    @property
    def bytes_delta_pct(self) -> Decimal | None:
        if self.total_baseline_bytes == 0:
            return None
        delta = Decimal(self.total_shadow_bytes - self.total_baseline_bytes)
        return (delta / Decimal(self.total_baseline_bytes)) * Decimal("100")

    @property
    def cost_delta_usd(self) -> Decimal:
        return self.total_shadow_cost_usd - self.total_baseline_cost_usd

    @property
    def any_row_count_mismatch(self) -> bool:
        return any(not d.row_count_parity for d in self.per_model)

    @property
    def mismatched_models(self) -> list[str]:
        return [d.model_name for d in self.per_model if not d.row_count_parity]

    @property
    def regressed_models(self) -> list[str]:
        return [d.model_name for d in self.per_model if d.bytes_regressed]

    @property
    def errored_in_shadow_only(self) -> list[str]:
        """Models that succeeded in baseline but errored in shadow."""
        out = []
        for d in self.per_model:
            if (
                d.shadow is not None
                and d.shadow.error_type is not None
                and (d.baseline is None or d.baseline.error_type is None)
            ):
                out.append(d.model_name)
        return out


def compute_deltas(
    baseline: list[ModelMetric],
    shadow: list[ModelMetric],
    *,
    parity_waived_models: set[str] | None = None,
) -> DiffResult:
    """Compute per-model and totals diff. Returns a DiffResult."""
    waived = parity_waived_models or set()
    baseline_by_name = {m.model_name: m for m in baseline}
    shadow_by_name = {m.model_name: m for m in shadow}
    all_models = sorted(set(baseline_by_name) | set(shadow_by_name))

    result = DiffResult()
    for name in all_models:
        b = baseline_by_name.get(name)
        s = shadow_by_name.get(name)

        parity = True
        if name not in waived and b is not None and s is not None:
            if b.row_count is not None and s.row_count is not None:
                parity = b.row_count == s.row_count

        regressed = False
        if b is not None and s is not None:
            if b.bytes_processed is not None and s.bytes_processed is not None:
                regressed = s.bytes_processed > b.bytes_processed

        result.per_model.append(
            ModelDiff(
                model_name=name,
                baseline=b,
                shadow=s,
                row_count_parity=parity,
                bytes_regressed=regressed,
            )
        )

        if b is not None:
            result.total_baseline_bytes += b.bytes_processed or 0
            result.total_baseline_slot_ms += b.slot_ms or 0
            result.total_baseline_cost_usd += b.cost_usd
        if s is not None:
            result.total_shadow_bytes += s.bytes_processed or 0
            result.total_shadow_slot_ms += s.slot_ms or 0
            result.total_shadow_cost_usd += s.cost_usd

    return result
