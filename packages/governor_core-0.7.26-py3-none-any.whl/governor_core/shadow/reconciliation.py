"""Reconcile orphaned shadow artifacts.

An artifact is orphaned if either:
  - no `shadow_validation_runs` row exists for its `<hex12>` suffix, OR
  - the bound run is in a terminal state AND its `updated_at` is older than
    the configuration's reconciliation threshold.

The reconcile job is invoked via the CLI (`governor shadow reconcile`). It
never deletes artifacts bound to in-progress (queued/running) runs.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Callable

from sqlalchemy import select
from sqlalchemy.orm import Session

from governor_core.shadow.models import TERMINAL_STATUSES, ShadowValidationRun

logger = logging.getLogger("app.shadow.reconciliation")

_ARTIFACT_RE = re.compile(r"__governor_([0-9a-f]{12})")


@dataclass
class ReconcileReport:
    deleted: list[str] = field(default_factory=list)
    retained: list[str] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)


def _extract_hex12(table_name: str) -> str | None:
    m = _ARTIFACT_RE.search(table_name)
    return m.group(1) if m else None


def reconcile(
    db: Session,
    *,
    configuration,  # ManifestConfiguration
    dataset: str,
    bq: object,
    now: datetime | None = None,
    candidate_names: list[str] | None = None,
) -> ReconcileReport:
    """Sweep orphaned shadow artifacts in `dataset`."""
    now = now or datetime.now(timezone.utc)
    threshold = timedelta(hours=configuration.shadow_reconciliation_threshold_hours)
    report = ReconcileReport()

    names = candidate_names if candidate_names is not None else bq.list_tables(dataset)

    # Build hex12 → run lookup for all runs ever created against this config
    runs_by_hex12: dict[str, ShadowValidationRun] = {}
    for run in db.execute(
        select(ShadowValidationRun).where(
            ShadowValidationRun.config_id == configuration.id
        )
    ).scalars():
        runs_by_hex12[run.solution_id_hex12] = run

    for name in names:
        hex12 = _extract_hex12(name)
        if hex12 is None:
            # Not a shadow artifact — leave alone
            continue

        bound_run = runs_by_hex12.get(hex12)
        if bound_run is None:
            # Unbound artifact — delete
            try:
                bq.drop_table(dataset, name)
                report.deleted.append(name)
            except Exception as e:  # noqa: BLE001
                report.failed.append((name, str(e)))
            continue

        if bound_run.status not in TERMINAL_STATUSES:
            # Active run — do not touch
            report.retained.append(name)
            continue

        age = now - bound_run.updated_at.replace(tzinfo=timezone.utc) if bound_run.updated_at.tzinfo is None else now - bound_run.updated_at
        if age < threshold:
            # Terminal but still fresh — keep for now
            report.retained.append(name)
            continue

        try:
            bq.drop_table(dataset, name)
            report.deleted.append(name)
        except Exception as e:  # noqa: BLE001
            report.failed.append((name, str(e)))

    return report
