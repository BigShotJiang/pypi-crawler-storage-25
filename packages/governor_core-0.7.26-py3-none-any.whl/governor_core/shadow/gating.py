"""Pre-flight gating for shadow validation runs.

Runs a sequence of checks BEFORE any BigQuery DDL is issued. Any failure
raises `ShadowSkipped` with a reason. Gates are deliberately cheap
(sub-second total) so the service never burns slot time on work that
would be refused later.

Order of checks (first to fail wins):
    1. shadow_validation_enabled on the config
    2. No concurrent run for this config
    3. Target model has a supported materialization
    4. Cascade size within cap
    5. Estimated baseline cost within budget cap (BigQuery dry-run)
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Callable, Protocol

from sqlalchemy import select
from sqlalchemy.orm import Session

from governor_core.shadow.cascade import discover_cascade, node_id_to_model_name
from governor_core.shadow.diff import _BQ_USD_PER_BYTE
from governor_core.shadow.exceptions import ShadowSkipped
from governor_core.shadow.models import ShadowValidationRun

logger = logging.getLogger("app.shadow.gating")

SUPPORTED_MATERIALIZATIONS = frozenset({"table", "view", "incremental"})


class DryRunFn(Protocol):
    def __call__(self, *, model_node_ids: list[str], manifest_content: dict) -> int:
        """Return total estimated bytes across all models (sum of dry-run estimates)."""
        ...


def _dry_run_not_implemented(*, model_node_ids, manifest_content):  # noqa: ARG001
    raise NotImplementedError(
        "dry-run cost estimate requires live BigQuery client — "
        "pass dry_run_fn=... to evaluate_gates or skip to disable budget gating"
    )


def _model_materialization(manifest_content: dict, node_id: str) -> str | None:
    node = (manifest_content.get("nodes") or {}).get(node_id)
    if not node:
        return None
    config = node.get("config") or {}
    return config.get("materialized")


def evaluate_gates(
    db: Session,
    *,
    solution,
    configuration,
    manifest_content: dict,
    target_node_id: str,
    dry_run_fn: Callable | None = None,
) -> list[str]:
    """Run all gating checks. On success, returns the cascade node-id list.

    Raises `ShadowSkipped(reason)` if any gate fails.
    """
    # 1. Feature enabled?
    if not configuration.shadow_validation_enabled:
        raise ShadowSkipped("disabled", "set shadow_validation_enabled=true on config")

    # 2. Concurrent run?
    existing = db.execute(
        select(ShadowValidationRun)
        .where(ShadowValidationRun.config_id == configuration.id)
        .where(ShadowValidationRun.status.in_(("queued", "running")))
        .where(ShadowValidationRun.solution_id != solution.id)
    ).scalars().first()
    if existing is not None:
        raise ShadowSkipped(
            "concurrent_run_in_flight",
            f"another shadow run is active: {existing.id}",
        )

    # 3. Materialization supported?
    materialization = _model_materialization(manifest_content, target_node_id)
    if materialization and materialization not in SUPPORTED_MATERIALIZATIONS:
        raise ShadowSkipped(
            "materialization_unsupported",
            f"target model materializes as {materialization!r}",
        )

    # 4. Cascade size within cap?
    cascade = discover_cascade(
        manifest_content,
        target_node_id,
        max_size=configuration.shadow_cascade_cap + 1,
    )
    if not cascade:
        raise ShadowSkipped(
            "materialization_unsupported",
            f"target {target_node_id!r} is not a dbt model",
        )
    if len(cascade) > configuration.shadow_cascade_cap:
        raise ShadowSkipped(
            "cascade_too_large",
            f"{len(cascade)} > {configuration.shadow_cascade_cap}",
        )

    # 5. Estimated baseline cost within budget?
    if dry_run_fn is not None:
        estimated_bytes = dry_run_fn(
            model_node_ids=cascade, manifest_content=manifest_content
        )
        estimated_usd = Decimal(estimated_bytes) * _BQ_USD_PER_BYTE
        cap = Decimal(str(configuration.shadow_budget_usd))
        if estimated_usd > cap:
            raise ShadowSkipped(
                "budget_exceeded",
                f"estimate ${estimated_usd:.2f} > cap ${cap:.2f}",
            )

    return cascade
