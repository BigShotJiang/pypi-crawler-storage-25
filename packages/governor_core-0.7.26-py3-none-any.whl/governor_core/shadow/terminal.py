"""Render shadow-validation comparison tables for the terminal."""

from __future__ import annotations

from decimal import Decimal

from governor_core.shadow.diff import DiffResult


def _fmt_bytes(n: int | None) -> str:
    if n is None:
        return "—"
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    val = float(n)
    idx = 0
    while val >= 1024 and idx < len(units) - 1:
        val /= 1024
        idx += 1
    return f"{val:,.1f} {units[idx]}"


def _fmt_int(n: int | None) -> str:
    return f"{n:,}" if n is not None else "—"


def _fmt_usd(d: Decimal | None) -> str:
    return f"${d:,.4f}" if d is not None else "—"


def _fmt_pct(d: Decimal | None) -> str:
    if d is None:
        return "—"
    sign = "+" if d > 0 else ""
    return f"{sign}{d:.1f}%"


def render_comparison(diff: DiffResult) -> str:
    """Render an ANSI-coloured before/after table from a DiffResult."""
    lines: list[str] = []
    header = f"{'Model':<30} {'Phase':<10} {'Bytes':>12} {'Slot-ms':>12} {'Cost':>12} {'Rows':>12} {'Parity':>8}"
    lines.append(header)
    lines.append("─" * len(header))

    for d in diff.per_model:
        for phase, m in (("baseline", d.baseline), ("shadow", d.shadow)):
            if m is None:
                continue
            parity_marker = ""
            if phase == "shadow":
                parity_marker = "✓" if d.row_count_parity else "✗"
            row = (
                f"{d.model_name:<30.30} "
                f"{phase:<10} "
                f"{_fmt_bytes(m.bytes_processed):>12} "
                f"{_fmt_int(m.slot_ms):>12} "
                f"{_fmt_usd(m.cost_usd):>12} "
                f"{_fmt_int(m.row_count):>12} "
                f"{parity_marker:>8}"
            )
            lines.append(row)

    lines.append("─" * len(header))
    lines.append(
        f"{'Total':<30} {'baseline':<10} "
        f"{_fmt_bytes(diff.total_baseline_bytes):>12} "
        f"{_fmt_int(diff.total_baseline_slot_ms):>12} "
        f"{_fmt_usd(diff.total_baseline_cost_usd):>12}"
    )
    lines.append(
        f"{'Total':<30} {'shadow':<10} "
        f"{_fmt_bytes(diff.total_shadow_bytes):>12} "
        f"{_fmt_int(diff.total_shadow_slot_ms):>12} "
        f"{_fmt_usd(diff.total_shadow_cost_usd):>12}"
    )
    lines.append(
        f"{'Delta':<30} {'':<10} {_fmt_pct(diff.bytes_delta_pct):>12} "
        f"{'':>12} {_fmt_usd(diff.cost_delta_usd):>12}"
    )
    return "\n".join(lines)


def render_skip_message(reason: str, detail: str = "") -> str:
    line = f"Shadow validation skipped: {reason}"
    if detail:
        line += f" ({detail})"
    line += ". Falling back to dry-run evidence."
    return line


def render_failure_message(reason: str, detail: str = "") -> str:
    line = f"Shadow validation FAILED: {reason}"
    if detail:
        line += f" — {detail}"
    return line
