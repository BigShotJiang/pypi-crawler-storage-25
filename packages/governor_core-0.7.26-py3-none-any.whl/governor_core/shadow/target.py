"""Generate the dbt `dbt_project.yml` overlay that renames cascade models to
their shadow equivalents via `+alias`.

The overlay is applied when invoking dbt by writing a transient
dbt_project.yml fragment into a workspace copy of the user's project. The
`+alias` config causes dbt to materialise each model at the aliased name
instead of its default name.
"""

from __future__ import annotations

from governor_core.shadow.cascade import node_id_to_model_name
from governor_core.shadow.naming import mint_shadow_name


def build_alias_overlay(
    cascade_node_ids: list[str],
    project_name: str,
    solution_id: str,
) -> dict:
    """Build a dbt_project.yml overlay dict that aliases every cascade model.

    Args:
        cascade_node_ids: List of dbt node ids (model.<project>.<name>).
        project_name: The dbt project name (second segment of the node id).
        solution_id: UUID string; drives the shadow name suffix.

    Returns:
        Dict shaped like {'models': {<project_name>: {<model>: {'+alias': ...}}}}
        suitable for merging into dbt_project.yml.
    """
    aliases: dict[str, dict] = {}
    for node_id in cascade_node_ids:
        model_name = node_id_to_model_name(node_id)
        aliases[model_name] = {"+alias": mint_shadow_name(model_name, solution_id)}
    return {"models": {project_name: aliases}}


def extract_project_name(manifest_content: dict) -> str | None:
    """Return the dbt project name as stored in manifest.json's metadata, or None."""
    return (manifest_content.get("metadata") or {}).get("project_name")
