"""Shadow validation orchestration.

The service orchestrates: gating → cascade discovery → (optionally) baseline
build → shadow build → metric capture → diff → persistence → cleanup.

Builder and metrics collection are injected as callables so the service can
be unit-tested without live BigQuery or dbt. Default implementations raise
NotImplementedError until the live integration lands (T015/T017 follow-up).
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from typing import Callable, Protocol

from sqlalchemy.orm import Session

from governor_core.shadow.builder import BuildResult, cleanup_workspace
from governor_core.shadow.cascade import discover_cascade, node_id_to_model_name
from governor_core.shadow.cleanup import CleanupResult, cleanup_run
from governor_core.shadow.diff import DiffResult, ModelMetric, compute_deltas
from governor_core.shadow.exceptions import ShadowSkipped
from governor_core.shadow.gating import evaluate_gates
from governor_core.shadow.models import ShadowModelExecution, ShadowValidationRun
from governor_core.shadow.naming import _solution_id_hex12

logger = logging.getLogger("app.shadow.service")


class BuilderFn(Protocol):
    def __call__(self, *, phase: str, cascade: list[str], run_id: str) -> BuildResult:
        ...


class MetricsFn(Protocol):
    def __call__(
        self, *, run_results: dict, expected_models: list[str]
    ) -> list[ModelMetric]:
        ...


@dataclass
class ShadowRunOutput:
    run: ShadowValidationRun
    diff: DiffResult | None = None
    skipped: bool = False
    skipped_reason: str | None = None


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _build_fn_not_implemented(*, phase, cascade, run_id):  # noqa: ARG001
    raise NotImplementedError(
        "real builder not yet wired — pass builder_fn=... to run_shadow_validation"
    )


def _invoke_builder(
    builder_fn: Callable,
    *,
    phase: str,
    cascade: list[str],
    run_id: str,
    output_callback: Callable[[str], None] | None,
):
    """Call ``builder_fn`` with ``output_callback`` when accepted, else fall
    back to the old three-kwarg signature.

    The caller previously passed three kwargs. Live dbt streaming requires a
    fourth — ``output_callback`` — but some builder wrappers (tests, manual
    SSE routes that already own their own stream) don't accept it. Probe the
    signature once and adapt.
    """
    import inspect

    if output_callback is None:
        return builder_fn(phase=phase, cascade=cascade, run_id=run_id)

    try:
        sig = inspect.signature(builder_fn)
    except (TypeError, ValueError):
        sig = None

    accepts = False
    if sig is not None:
        params = sig.parameters
        accepts = "output_callback" in params or any(
            p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()
        )

    if accepts:
        return builder_fn(
            phase=phase,
            cascade=cascade,
            run_id=run_id,
            output_callback=output_callback,
        )
    return builder_fn(phase=phase, cascade=cascade, run_id=run_id)


def _metrics_fn_not_implemented(*, run_results, expected_models):  # noqa: ARG001
    raise NotImplementedError(
        "real metrics fetcher not yet wired — pass metrics_fn=... to run_shadow_validation"
    )


def run_shadow_validation(
    db: Session,
    *,
    solution,  # app.solutions.models.Solution
    configuration,  # app.configurations.models.ManifestConfiguration
    manifest_content: dict,
    target_node_id: str,
    builder_fn: BuilderFn | Callable = _build_fn_not_implemented,
    metrics_fn: MetricsFn | Callable = _metrics_fn_not_implemented,
    gate_fn: Callable | None = None,
    cleanup_bq: object | None = None,
    cleanup_dataset: str | None = None,
    progress_callback=None,  # Callable[[str, str], None] — (event_type, payload)
    triggered_by: str = "manual",  # spec 124: 'manual' or 'auto'
) -> ShadowRunOutput:
    """Run shadow validation end-to-end.

    Creates a `ShadowValidationRun` row, runs gating, (on success) executes
    baseline + shadow, captures metrics, computes deltas, persists, and
    links the run to the solution. Does NOT execute live against BigQuery
    unless `builder_fn` / `metrics_fn` are provided — otherwise will raise
    NotImplementedError after gating (useful for unit tests that stub these).
    """
    logger.info(
        "Shadow validation starting for solution %s (target=%s, triggered_by=%s)",
        solution.id,
        target_node_id,
        triggered_by,
    )

    # Create the run row up front so gating failures still leave an audit record.
    hex12 = _solution_id_hex12(solution.id)
    run = ShadowValidationRun(
        id=str(uuid.uuid4()),
        solution_id=solution.id,
        config_id=configuration.id,
        status="queued",
        triggered_by=triggered_by,
        cascade_size=0,
        estimated_baseline_cost_usd=Decimal("0"),
        budget_cap_usd=Decimal(str(configuration.shadow_budget_usd)),
        cascade_cap=configuration.shadow_cascade_cap,
        timeout_seconds=configuration.shadow_timeout_seconds,
        solution_id_hex12=hex12,
    )
    db.add(run)
    db.flush()

    # Accumulator for all log events — persisted to run.build_logs so the
    # UI can re-display them after the live SSE terminal has closed.
    collected_log_lines: list[str] = []

    def _emit_early(event: str, payload: str = "") -> None:
        if event in ("line", "phase", "result") and payload:
            prefix = {"line": "", "phase": "▸ ", "result": "● "}[event]
            collected_log_lines.append(f"{prefix}{payload}")
        if progress_callback is not None:
            try:
                progress_callback(event, payload)
            except Exception:  # noqa: BLE001
                pass

    def _persist_logs() -> None:
        if collected_log_lines:
            joined = "\n".join(collected_log_lines)
            if len(joined) > 200_000:
                joined = joined[-200_000:]
            run.build_logs = joined

    _emit_early("phase", "gating: checking")

    # Gating (injected — Phase 4 implements the real gating function)
    if gate_fn is not None:
        try:
            cascade = gate_fn(
                db=db,
                solution=solution,
                configuration=configuration,
                manifest_content=manifest_content,
                target_node_id=target_node_id,
            )
            run.cascade_size = len(cascade)
        except ShadowSkipped as skip:
            run.transition_to("skipped")
            run.skipped_reason = skip.reason
            _emit_early("result", f"skipped: {skip.reason}")
            _persist_logs()
            db.commit()
            logger.info(
                "Shadow validation %s skipped at gating: %s",
                run.id,
                skip.reason,
            )
            return ShadowRunOutput(run=run, skipped=True, skipped_reason=skip.reason)
    else:
        cascade = discover_cascade(
            manifest_content,
            target_node_id,
            max_size=configuration.shadow_cascade_cap + 1,
        )
        run.cascade_size = len(cascade)
        if len(cascade) > configuration.shadow_cascade_cap:
            run.transition_to("skipped")
            run.skipped_reason = "cascade_too_large"
            _emit_early("result", "skipped: cascade_too_large")
            _persist_logs()
            db.commit()
            logger.info(
                "Shadow validation %s skipped: cascade_too_large (size=%d cap=%d)",
                run.id,
                len(cascade),
                configuration.shadow_cascade_cap,
            )
            return ShadowRunOutput(
                run=run, skipped=True, skipped_reason="cascade_too_large"
            )

    model_names = [node_id_to_model_name(n) for n in cascade]

    # Transition queued → running AND commit immediately so the row is
    # visible to other sessions (the UI needs to detect the in-flight run
    # to hide the "Run Comparison" button). Without this commit the row
    # stays unseen until the full cascade finishes 30-60 minutes later.
    run.transition_to("running")
    db.commit()
    db.refresh(run)
    logger.info(
        "Shadow validation %s entered 'running' for solution %s "
        "(triggered_by=%s, cascade_size=%d)",
        run.id,
        solution.id,
        triggered_by,
        run.cascade_size,
    )

    def _do_cleanup() -> None:
        if cleanup_bq is None or cleanup_dataset is None:
            return
        try:
            cleanup_run(
                solution_id=solution.id,
                dataset=cleanup_dataset,
                bq=cleanup_bq,
            )
        except Exception as e:  # noqa: BLE001
            logger.warning("cleanup failed for run %s: %s", run.id, e)

    # Reuse _emit_early for the main try block (identical accumulate +
    # progress_callback forwarding; no need for a separate helper).
    _emit = _emit_early

    # Throttled persistence of build_logs so auto runs (which have no SSE
    # client) surface live terminal output in the UI. Manual runs already
    # stream via SSE; this is cheap and uniform across modes. The throttle
    # keeps commit volume sane on high-volume dbt output.
    import time  # local import — std lib, no cost
    _last_persist = [time.time()]

    def _maybe_persist_logs() -> None:
        now_ts = time.time()
        if now_ts - _last_persist[0] < 3.0:
            return
        _last_persist[0] = now_ts
        _persist_logs()
        try:
            db.commit()
        except Exception:  # noqa: BLE001
            db.rollback()

    def _dbt_line_cb(line: str) -> None:
        """Route each dbt stdout line through the same _emit machinery so
        it lands in collected_log_lines and is periodically flushed to the
        run row's build_logs."""
        _emit("line", line)
        _maybe_persist_logs()

    try:
        _emit("phase", f"cascade: {len(cascade)} model(s)")

        def _surface_build_error(result) -> None:
            """Emit any build error details (stderr / error_message) so the
            user sees why dbt failed instead of just 'FAILED'."""
            err = getattr(result, "error_message", None)
            if err:
                for line in err.splitlines():
                    if line.strip():
                        _emit("line", line)
            stderr = getattr(result, "stderr", "") or ""
            if stderr:
                for line in stderr.splitlines()[-30:]:  # last 30 lines is enough
                    if line.strip():
                        _emit("line", line)

        # Baseline
        _emit("phase", "baseline: starting")
        logger.info(
            "Shadow validation %s: baseline phase starting (cascade=%d models)",
            run.id,
            len(cascade),
        )
        run.baseline_started_at = _now()
        baseline_result = _invoke_builder(
            builder_fn,
            phase="baseline",
            cascade=cascade,
            run_id=run.id,
            output_callback=_dbt_line_cb,
        )
        run.baseline_completed_at = _now()
        _emit(
            "phase",
            f"baseline: {'ok' if baseline_result.success else 'FAILED'} "
            f"({baseline_result.models_count if hasattr(baseline_result,'models_count') else len((baseline_result.run_results or {}).get('results',[]))} models)",
        )
        baseline_duration_s = (
            (run.baseline_completed_at - run.baseline_started_at).total_seconds()
            if run.baseline_started_at and run.baseline_completed_at
            else 0.0
        )
        logger.info(
            "Shadow validation %s: baseline phase %s in %.1fs",
            run.id,
            "succeeded" if baseline_result.success else "FAILED",
            baseline_duration_s,
        )
        if not baseline_result.success:
            _surface_build_error(baseline_result)
            run.transition_to("baseline_failed")
            run.failure_reason = "baseline_failed"
            _emit("result", "baseline_failed")
            _persist_logs()
            db.commit()
            return ShadowRunOutput(run=run)

        # Shadow
        _emit("phase", "shadow: starting")
        logger.info(
            "Shadow validation %s: shadow phase starting",
            run.id,
        )
        run.shadow_started_at = _now()
        shadow_result = _invoke_builder(
            builder_fn,
            phase="shadow",
            cascade=cascade,
            run_id=run.id,
            output_callback=_dbt_line_cb,
        )
        run.shadow_completed_at = _now()
        _emit(
            "phase",
            f"shadow: {'ok' if shadow_result.success else 'FAILED'}",
        )
        shadow_duration_s = (
            (run.shadow_completed_at - run.shadow_started_at).total_seconds()
            if run.shadow_started_at and run.shadow_completed_at
            else 0.0
        )
        logger.info(
            "Shadow validation %s: shadow phase %s in %.1fs",
            run.id,
            "succeeded" if shadow_result.success else "FAILED",
            shadow_duration_s,
        )
        if not shadow_result.success:
            _surface_build_error(shadow_result)

        # Metrics — read from run_results of each just-completed build
        baseline_metrics = metrics_fn(
            run_results=baseline_result.run_results, expected_models=model_names
        )
        shadow_metrics = metrics_fn(
            run_results=shadow_result.run_results, expected_models=model_names
        )

        # Persist per-model executions
        for metric_list, phase_name in (
            (baseline_metrics, "baseline"),
            (shadow_metrics, "shadow"),
        ):
            for m in metric_list:
                db.add(
                    ShadowModelExecution(
                        id=str(uuid.uuid4()),
                        shadow_run_id=run.id,
                        phase=phase_name,
                        model_name=m.model_name,
                        materialized_table_name=m.model_name,
                        bytes_processed=m.bytes_processed,
                        slot_ms=m.slot_ms,
                        duration_ms=m.duration_ms,
                        row_count=m.row_count,
                        cost_usd=m.cost_usd,
                        error_type=m.error_type,
                        error_message=m.error_message,
                    )
                )

        diff = compute_deltas(baseline_metrics, shadow_metrics)
        run.total_baseline_bytes = diff.total_baseline_bytes
        run.total_shadow_bytes = diff.total_shadow_bytes
        run.total_baseline_slot_ms = diff.total_baseline_slot_ms
        run.total_shadow_slot_ms = diff.total_shadow_slot_ms
        run.total_baseline_cost_usd = diff.total_baseline_cost_usd
        run.total_shadow_cost_usd = diff.total_shadow_cost_usd
        run.bytes_delta_pct = diff.bytes_delta_pct
        run.cost_delta_usd = diff.cost_delta_usd

        # Determine success / failure based on diff
        if diff.errored_in_shadow_only:
            run.transition_to("shadow_failed")
            run.failure_reason = "downstream_error"
            _emit("result", "downstream_error")
        elif diff.any_row_count_mismatch:
            run.transition_to("shadow_failed")
            run.failure_reason = "row_count_mismatch"
            _emit("result", "row_count_mismatch")
        else:
            run.transition_to("succeeded")
            solution.shadow_validation_run_id = run.id
            _emit("result", "succeeded")

        _persist_logs()
        db.commit()
        logger.info(
            "Shadow validation %s finished: status=%s "
            "cost_delta_usd=%s bytes_delta_pct=%s",
            run.id,
            run.status,
            run.cost_delta_usd,
            run.bytes_delta_pct,
        )
        _maybe_generate_downstream_patches(db, solution, run, diff)
        return ShadowRunOutput(run=run, diff=diff)

    except Exception as e:  # noqa: BLE001
        logger.exception("shadow run failed: %s", e)
        if run.status == "running":
            run.transition_to("shadow_failed")
            run.failure_reason = "unexpected_error"
        _persist_logs()
        db.commit()
        raise
    finally:
        _do_cleanup()
        # Remove the temporary dbt workspaces once metrics have been read.
        cleanup_workspace(getattr(locals().get("baseline_result"), "workspace_dir", None))
        cleanup_workspace(getattr(locals().get("shadow_result"), "workspace_dir", None))


def _maybe_generate_downstream_patches(db, solution, run, diff) -> None:
    """Spec 128 post-run hook; spec 132 generalised to dispatch via the
    guardrail-provider registry.

    When shadow validation on a solution whose ``template_id`` is registered
    as a downstream-patch guardrail failed with in-project downstreams,
    trigger patch generation and splice the results into
    ``solution.file_changes``. Swallows every failure so the shadow path
    itself never breaks because the bonus patch generation tripped.

    Solutions whose ``template_id`` is NOT in the registry (e.g. the
    ``upstream_partition_by`` template from spec 131, which is not a
    breaking change for downstreams) are silently ignored — the no-op
    path covered by FR-009.
    """
    from governor_core.agents.downstream_patch.providers import get_provider
    from governor_core.core.config import is_local_mode

    if not is_local_mode():
        return
    if run is None or (getattr(run, "status", "") != "shadow_failed"):
        return
    validation_report = getattr(solution, "validation_report", None) or {}
    template_id = validation_report.get("template_id")
    if get_provider(template_id) is None:
        return
    if diff is None or not getattr(diff, "errored_in_shadow_only", None):
        return

    try:
        from governor_core.solutions.service import generate_downstream_patches

        generate_downstream_patches(db, str(solution.id))
        db.commit()
    except Exception:  # noqa: BLE001
        logger.exception(
            "spec-128 post-run hook: downstream-patch generation failed for solution %s",
            getattr(solution, "id", "?"),
        )
        db.rollback()
