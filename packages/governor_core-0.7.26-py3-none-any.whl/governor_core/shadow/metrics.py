"""Extract per-model execution metrics from dbt run_results.json.

dbt-bigquery's adapter_response on each result includes:
    - bytes_processed
    - bytes_billed
    - slot_ms
    - rows_affected
    - job_id

We read these directly — no separate INFORMATION_SCHEMA.JOBS query needed.
"""

from __future__ import annotations

import logging

from governor_core.shadow.diff import ModelMetric

logger = logging.getLogger("app.shadow.metrics")


def _node_id_to_name(node_id: str) -> str:
    parts = node_id.split(".")
    return parts[-1] if parts else node_id


def metrics_from_run_results(
    *,
    run_results: dict,
    expected_models: list[str],
) -> list[ModelMetric]:
    """Turn dbt run_results into a list of ModelMetric (one per expected model)."""
    results = run_results.get("results", []) if run_results else []

    by_name: dict[str, dict] = {}
    for r in results:
        node_id = r.get("unique_id", "")
        name = _node_id_to_name(node_id)
        if name:
            by_name[name] = r

    metrics: list[ModelMetric] = []
    for name in expected_models:
        r = by_name.get(name)
        if r is None:
            metrics.append(ModelMetric(model_name=name))
            continue

        adapter = r.get("adapter_response") or {}
        timing = r.get("timing") or []
        exec_time_ms = 0
        for t in timing:
            if t.get("name") == "execute":
                # timing entries have started_at / completed_at ISO strings
                # Duration in the dbt result is already summed as `execution_time`.
                break
        exec_time_ms = int((r.get("execution_time") or 0) * 1000)

        status = r.get("status", "")
        error_type = None
        error_message = None
        if status != "success":
            error_type = status
            error_message = r.get("message")

        metrics.append(
            ModelMetric(
                model_name=name,
                bytes_processed=adapter.get("bytes_processed"),
                slot_ms=adapter.get("slot_ms"),
                duration_ms=exec_time_ms,
                row_count=adapter.get("rows_affected"),
                error_type=error_type,
                error_message=error_message,
            )
        )
    return metrics
