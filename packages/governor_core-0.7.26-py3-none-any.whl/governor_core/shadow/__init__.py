"""Shadow model empirical validation (spec 110).

Materialises proposed dbt optimisations alongside production tables in an
isolated namespace (`__governor_<hex12>` suffix), runs baseline + shadow
cascades, captures empirical BigQuery metrics, and surfaces the comparison
via the Governor CLI for local-mode users.
"""
