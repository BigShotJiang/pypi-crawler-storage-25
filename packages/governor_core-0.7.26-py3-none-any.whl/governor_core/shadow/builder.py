"""Invoke dbt for a cascade build (baseline or shadow phase).

Thin wrapper over `app.dbt.uv_runner.DbtUvRunner.build_models`. Stages a
temporary copy of the user's dbt project, applies the shadow alias overlay,
writes the solution's modified SQL for the shadow phase, generates a
profiles dir, and invokes dbt.
"""

from __future__ import annotations

import logging
import os
import shutil
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import yaml

from governor_core.dbt.uv_runner import DbtUvRunner
from governor_core.shadow.cascade import node_id_to_model_name
from governor_core.shadow.naming import _solution_id_hex12
from governor_core.shadow.target import extract_project_name

logger = logging.getLogger("app.shadow.builder")


def _find_user_dbt(project_path: Path) -> str | None:
    """Locate a dbt executable the user already has set up.

    Checks (in order):
      1. <project>/.venv/bin/dbt  — project-local virtualenv
      2. <project>/venv/bin/dbt   — common alternative name
      3. `dbt` on the process PATH (inherited from the shell that launched
         Governor). This matches whatever the user would get by typing
         `dbt` in that same shell.

    Returns the absolute path to dbt, or None if none found.
    """
    import shutil as _sh

    project_candidates = [
        project_path / ".venv" / "bin" / "dbt",
        project_path / "venv" / "bin" / "dbt",
    ]
    for cand in project_candidates:
        if cand.is_file() and os.access(cand, os.X_OK):
            return str(cand)

    path_dbt = _sh.which("dbt")
    if path_dbt:
        return path_dbt
    return None


def _run_dbt_subprocess_streaming(
    *,
    dbt_bin: str,
    project_dir: str,
    selector: str,
    profiles_dir: str,
    timeout: int,
    output_callback=None,
) -> "DbtRunResult":
    """Run `dbt build --select <selector>` using the given dbt executable.

    Streams stdout line-by-line via output_callback. Returns a DbtRunResult
    matching what DbtUvRunner.build_models_streaming returns so the rest of
    the builder is unchanged.
    """
    import subprocess
    import time as _time

    from governor_core.dbt.uv_runner import BuildResult as _BR

    cmd = [
        dbt_bin,
        "build",
        "--select",
        selector,
        "--profiles-dir",
        profiles_dir,
        "--project-dir",
        project_dir,
    ]
    start = _time.monotonic()
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=os.environ.copy(),
        )
        collected: list[str] = []
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.rstrip("\n")
            collected.append(line)
            if output_callback is not None:
                try:
                    output_callback(line)
                except Exception:  # noqa: BLE001
                    pass
        exit_code = proc.wait(timeout=timeout)
        duration_ms = int((_time.monotonic() - start) * 1000)
        # Try to read run_results.json that dbt wrote into project_dir/target/
        rr_path = Path(project_dir) / "target" / "run_results.json"
        run_results = None
        if rr_path.exists():
            try:
                import json as _json

                run_results = _json.loads(rr_path.read_text())
            except Exception:  # noqa: BLE001
                run_results = None
        combined = "\n".join(collected)
        return _BR(
            success=(exit_code == 0),
            exit_code=exit_code,
            run_results=run_results,
            models_count=(
                len((run_results or {}).get("results", [])) if run_results else 0
            ),
            stdout=combined,
            stderr="" if exit_code == 0 else combined[-4096:],
            duration_ms=duration_ms,
        )
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        duration_ms = int((_time.monotonic() - start) * 1000)
        return _BR(
            success=False,
            exit_code=-1,
            stderr=f"Build timed out after {timeout}s",
            duration_ms=duration_ms,
        )
    except (OSError, RuntimeError) as e:
        duration_ms = int((_time.monotonic() - start) * 1000)
        return _BR(
            success=False,
            exit_code=-1,
            stderr=str(e),
            duration_ms=duration_ms,
        )


# Forward declaration for type annotation above
from governor_core.dbt.uv_runner import BuildResult as DbtRunResult  # noqa: E402


@dataclass
class BuildResult:
    """Result of a baseline or shadow dbt run."""

    phase: str
    started_at: datetime
    completed_at: datetime
    success: bool
    run_results: dict = field(default_factory=dict)
    workspace_dir: str | None = None
    error_message: str | None = None


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _phase_suffix(solution_id: str, phase: str) -> str:
    """Artifact suffix for a phase — both phases share the __governor_<hex12>
    root so cleanup / reconciliation sweep them both."""
    assert phase in ("baseline", "shadow")
    return f"__governor_{_solution_id_hex12(solution_id)}_{phase}"


def _alias_overlay_yaml(
    cascade_node_ids: list[str],
    project_name: str,
    suffix: str,
    manifest_content: dict | None = None,
) -> dict:
    """dbt_project.yml overlay giving every cascade model a `+alias`.

    Nests the alias config at the model's full dbt fqn path (e.g.
    `models.<project>.marts.rpt_storm_correlation`) so dbt actually
    applies it. Without the correct nesting dbt emits an unused-path
    warning and silently falls back to the default name — meaning
    shadow would materialise into production tables.

    Falls back to flat `models.<project>.<model_name>` nesting when
    the manifest content is not available (unit tests pass stubs).
    """
    overlay_models: dict = {}
    nodes = (manifest_content or {}).get("nodes") or {}

    def _insert_at_fqn(fqn: list[str], model_cfg: dict) -> None:
        cursor = overlay_models
        for segment in fqn[:-1]:
            cursor = cursor.setdefault(segment, {})
        cursor[fqn[-1]] = model_cfg

    for node_id in cascade_node_ids:
        model = node_id_to_model_name(node_id)
        model_cfg = {"+alias": f"{model}{suffix}"}
        node = nodes.get(node_id)
        fqn = (node or {}).get("fqn")
        if isinstance(fqn, list) and fqn:
            _insert_at_fqn(fqn, model_cfg)
        else:
            overlay_models.setdefault(project_name, {})[model] = model_cfg

    return {"models": overlay_models}


def _merge_overlay_into_project_yml(project_dir: Path, overlay: dict) -> None:
    """Merge `overlay` into the project's dbt_project.yml (in place)."""
    project_yml_path = project_dir / "dbt_project.yml"
    if not project_yml_path.exists():
        raise FileNotFoundError(f"dbt_project.yml not found at {project_yml_path}")
    existing = yaml.safe_load(project_yml_path.read_text()) or {}
    # Deep-merge overlay["models"][project] into existing["models"][project]
    existing_models = existing.setdefault("models", {})
    for project_name, models in overlay.get("models", {}).items():
        existing_project_models = existing_models.setdefault(project_name, {})
        for model_name, config in models.items():
            existing_project_models.setdefault(model_name, {}).update(config)
    project_yml_path.write_text(yaml.safe_dump(existing, sort_keys=False))


def _copy_project_to_workspace(src: Path, dst: Path) -> None:
    """Copy the user's dbt project to a temp workspace, excluding transient dirs.

    dst may already exist (tempfile.mkdtemp creates it); dirs_exist_ok=True
    makes copytree tolerate that.
    """
    # NOTE: dbt_packages/ is NOT excluded — it contains real installed
    # dependencies that dbt needs at run time. target/ and logs/ are
    # transient outputs and safe to skip.
    shutil.copytree(
        src,
        dst,
        ignore=shutil.ignore_patterns(
            "target", "logs", ".user.yml", "__pycache__", ".git", "venv", ".venv"
        ),
        dirs_exist_ok=True,
    )


def _verify_shadow_destinations_via_bq(
    *,
    run_results: dict,
    suffix: str,
    gcp_project: str,
    region: str = "us",
    max_wait_seconds: int = 90,
    poll_interval_seconds: int = 5,
) -> str | None:
    """Deterministically verify every model dbt just ran materialised
    into a table whose name carries our shadow suffix.

    Flow:
      1. Build a per-node map {unique_id: root_job_id} from
         adapter_response.job_id in run_results.
      2. Independently compute the expected table name per node:
         node_id_to_model_name(unique_id) + suffix.
      3. Query INFORMATION_SCHEMA.JOBS for the root job_ids AND any
         jobs whose parent_job_id matches a root (covers SCRIPT jobs
         used by incremental models, where the root has no
         destination_table but its children do).
      4. For each node, collect all destination_table.table_id values
         reachable from its root + children. The expected table MUST
         appear in that set — if not, ABORT.

    Returns an error string on failure, None on success.
    """
    import time as _time

    from google.cloud import bigquery

    # 1. Per-node root job_id + expected table name
    node_root_job: dict[str, str] = {}
    expected_per_node: dict[str, str] = {}
    for r in run_results.get("results") or []:
        unique_id = r.get("unique_id") or ""
        if not unique_id.startswith("model."):
            continue
        adapter = r.get("adapter_response") or {}
        jid = adapter.get("job_id")
        if not jid:
            continue
        node_root_job[unique_id] = jid
        expected_per_node[unique_id] = (
            node_id_to_model_name(unique_id) + suffix
        )

    if not node_root_job:
        return (
            "SAFETY ABORT: no BigQuery job_ids found in run_results; "
            "cannot verify destination tables. Aborting."
        )

    root_jids = list(set(node_root_job.values()))

    # 3. Query JOBS for roots + children
    client = bigquery.Client(project=gcp_project)
    root_params = ", ".join(f"@r{i}" for i in range(len(root_jids)))
    sql = f"""
        SELECT
            job_id,
            parent_job_id,
            destination_table.table_id AS table_id
        FROM `{gcp_project}.region-{region}`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
        WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 HOUR)
          AND (job_id IN ({root_params}) OR parent_job_id IN ({root_params}))
    """
    query_params = [
        bigquery.ScalarQueryParameter(f"r{i}", "STRING", jid)
        for i, jid in enumerate(root_jids)
    ]
    config = bigquery.QueryJobConfig(query_parameters=query_params)

    # Poll until every root has at least one row with a non-null table_id
    # (SCRIPT roots have null destination_table; their children carry it).
    deadline = _time.monotonic() + max_wait_seconds
    # {root_jid: set_of_table_ids}
    per_root_tables: dict[str, set[str]] = {r: set() for r in root_jids}
    while _time.monotonic() < deadline:
        try:
            job = client.query(sql, job_config=config)
            rows = list(job.result())
        except Exception as exc:  # noqa: BLE001
            return (
                "SAFETY ABORT: could not query INFORMATION_SCHEMA.JOBS: "
                f"{exc}. Aborting."
            )
        for row in rows:
            parent = row.get("parent_job_id") or ""
            jid = row.get("job_id") or ""
            tid = row.get("table_id") or ""
            if not tid:
                continue
            if parent in per_root_tables:
                per_root_tables[parent].add(tid)
            elif jid in per_root_tables:
                per_root_tables[jid].add(tid)
        if all(per_root_tables[r] for r in root_jids):
            break
        _time.sleep(poll_interval_seconds)

    # 4. Verify per-node: the expected table name MUST be in the set of
    # destination tables reachable from that node's root job.
    violations: list[str] = []
    for node_id, jid in node_root_job.items():
        expected = expected_per_node[node_id]
        observed = per_root_tables.get(jid, set())
        if expected not in observed:
            violations.append(
                f"{node_id}: expected destination table "
                f"containing {expected!r}, BigQuery wrote to "
                f"{sorted(observed) or 'NONE'}"
            )

    if violations:
        detail = "; ".join(violations)
        return (
            "SAFETY ABORT: shadow alias verification failed per node. "
            f"{detail}. Aborting to avoid production-table writes."
        )

    return None


def _apply_shadow_file_change(
    workspace_dir: Path, relative_file_path: str, after_content: str
) -> None:
    """Overwrite `relative_file_path` inside the workspace with `after_content`."""
    target = workspace_dir / relative_file_path
    if not target.exists():
        raise FileNotFoundError(
            f"target model file not found in workspace: {target}"
        )
    target.write_text(after_content)


def run_dbt_cascade(
    *,
    phase: str,
    cascade: list[str],
    run_id: str,  # noqa: ARG001 — caller uses this for its own bookkeeping
    solution,
    configuration,
    manifest_content: dict,
    dbt_version: str = "1.8.0",
    output_callback=None,  # Callable[[str], None] for live stdout streaming
) -> BuildResult:
    """Run baseline or shadow dbt build.

    Stages a temp copy of the user's project, injects alias overlays so every
    cascade model materialises to a `__governor_<hex12>_<phase>` name,
    overwrites the target file for the shadow phase, and invokes
    `DbtUvRunner.build_models(selector='<target>+')`.
    """
    started_at = _now()

    local_project_path = configuration.local_project_path
    if not local_project_path:
        return BuildResult(
            phase=phase,
            started_at=started_at,
            completed_at=_now(),
            success=False,
            error_message="configuration has no local_project_path set",
        )

    project_name = extract_project_name(manifest_content) or "dbt_project"
    target_node_id = cascade[0] if cascade else ""
    target_model_name = node_id_to_model_name(target_node_id)
    suffix = _phase_suffix(solution.id, phase)

    workspace = Path(tempfile.mkdtemp(prefix=f"governor-shadow-{phase}-"))
    try:
        _copy_project_to_workspace(Path(local_project_path), workspace)

        # Shadow phase: overwrite every proposed file (target + any
        # downstream edits in the same solution) with the LLM's content.
        # Multi-file solutions are stored in ``solution.file_changes``;
        # fall back to the legacy single-file columns when that's None.
        if phase == "shadow":
            for entry in solution.normalized_file_changes:
                fp = entry.get("file_path")
                after = entry.get("after_content")
                if fp and after:
                    _apply_shadow_file_change(workspace, fp, after)

        # Both phases: alias every cascade model so materialisation targets
        # the phase-specific shadow suffix (production tables are untouched).
        overlay = _alias_overlay_yaml(
            cascade, project_name, suffix, manifest_content=manifest_content
        )
        _merge_overlay_into_project_yml(workspace, overlay)

        # Use the user's existing dbt profiles. dbt looks in two places:
        #   1. the project directory itself (profiles.yml next to dbt_project.yml)
        #   2. ~/.dbt/profiles.yml
        # We check in the same order and pass --profiles-dir at the first hit.
        candidates = [
            Path(local_project_path),
            Path(os.path.expanduser("~/.dbt")),
        ]
        profiles_dir = None
        for cand in candidates:
            if (cand / "profiles.yml").is_file():
                profiles_dir = str(cand)
                break
        if profiles_dir is None:
            return BuildResult(
                phase=phase,
                started_at=started_at,
                completed_at=_now(),
                success=False,
                error_message=(
                    "No profiles.yml found. Looked in: "
                    f"{local_project_path}/profiles.yml, ~/.dbt/profiles.yml. "
                    "Create one with your BigQuery credentials before running "
                    "shadow validation."
                ),
            )

        # Prefer the user's own dbt (project venv, then PATH). Only fall back
        # to the uv-managed venv if no user dbt is available.
        user_dbt = _find_user_dbt(Path(local_project_path))
        if user_dbt:
            if output_callback is not None:
                output_callback(f"[dbt] using user's dbt at {user_dbt}")
            result = _run_dbt_subprocess_streaming(
                dbt_bin=user_dbt,
                project_dir=str(workspace),
                selector=f"{target_model_name}+",
                profiles_dir=profiles_dir,
                timeout=configuration.shadow_timeout_seconds,
                output_callback=output_callback,
            )
        else:
            if output_callback is not None:
                output_callback(
                    "[dbt] no user dbt found (checked <project>/.venv, "
                    "<project>/venv, PATH) — falling back to uv-managed venv"
                )
            runner = DbtUvRunner()
            if output_callback is not None:
                result = runner.build_models_streaming(
                    project_dir=str(workspace),
                    selector=f"{target_model_name}+",
                    dbt_version=dbt_version,
                    profiles_dir=profiles_dir,
                    target_name=None,
                    timeout=configuration.shadow_timeout_seconds,
                    output_callback=output_callback,
                )
            else:
                result = runner.build_models(
                    project_dir=str(workspace),
                    selector=f"{target_model_name}+",
                    dbt_version=dbt_version,
                    profiles_dir=profiles_dir,
                    target_name=None,
                    timeout=configuration.shadow_timeout_seconds,
                )

        completed_at = _now()

        # SAFETY CHECK: confirm the alias actually applied by asking
        # BigQuery directly. For every model in run_results we take the
        # adapter_response.job_id, query INFORMATION_SCHEMA.JOBS for the
        # job's destination_table, and verify it carries our shadow
        # suffix. Ground truth — never trust stdout or run_results.name.
        #
        # If ANY destination_table lacks the suffix, we ABORT. This is
        # the only thing standing between us and silently writing to
        # production tables.
        if result.success and result.run_results:
            safety_err = _verify_shadow_destinations_via_bq(
                run_results=result.run_results,
                suffix=suffix,
                gcp_project=configuration.gcp_project_id,
            )
            if safety_err:
                return BuildResult(
                    phase=phase,
                    started_at=started_at,
                    completed_at=completed_at,
                    success=False,
                    run_results=result.run_results or {},
                    workspace_dir=str(workspace),
                    error_message=safety_err,
                )

        return BuildResult(
            phase=phase,
            started_at=started_at,
            completed_at=completed_at,
            success=result.success,
            run_results=result.run_results or {},
            workspace_dir=str(workspace),
            error_message=None if result.success else (result.stderr or "dbt build failed"),
        )
    except Exception as e:  # noqa: BLE001
        logger.exception("shadow build failed: %s", e)
        return BuildResult(
            phase=phase,
            started_at=started_at,
            completed_at=_now(),
            success=False,
            workspace_dir=str(workspace),
            error_message=str(e),
        )
    finally:
        # Leave workspace on disk — cleanup of the physical dir happens after
        # metric capture (metrics need to read run_results.json which lives
        # in workspace/target/). Caller is responsible for removing the workspace.
        pass


def cleanup_workspace(workspace_dir: str | None) -> None:
    """Remove a build workspace once metrics have been captured."""
    if not workspace_dir:
        return
    try:
        shutil.rmtree(workspace_dir, ignore_errors=True)
    except OSError as e:
        logger.warning("failed to remove workspace %s: %s", workspace_dir, e)
