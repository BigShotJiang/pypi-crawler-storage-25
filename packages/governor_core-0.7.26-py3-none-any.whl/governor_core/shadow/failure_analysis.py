"""Shadow-validation failure analysis for spec 128.

When shadow validation fails on an ``add_require_partition_filter`` solution,
downstream dbt models that query the guarded upstream without a partition
filter fail to build. This module exposes:

- shared data types (``DownstreamFailure``, ``DownstreamPatch``)
- the identification function ``identify_failing_downstreams()`` that walks
  the persisted ``shadow_model_executions`` rows and classifies each failure
  as in-project (we can propose a patch) or external (we cannot).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from sqlalchemy.orm import Session


@dataclass(frozen=True)
class DownstreamFailure:
    """A single dbt model that broke during the shadow phase of a validation run.

    ``is_in_project`` distinguishes project-owned models (we can propose a
    patch) from vendor-package models (we cannot — vendor code is not ours to
    edit).
    """

    node_id: str
    model_name: str
    original_file_path: str
    package_name: str
    error_type: str
    error_message: str | None
    is_in_project: bool
    compiled_sql: str | None


PatchStatus = Literal["proposed", "edited", "manual_required", "applied"]


@dataclass(frozen=True)
class DownstreamPatch:
    """A per-downstream-file patch proposal that will be spliced into
    ``Solution.file_changes``.

    The ``proposal_meta`` dict mirrors the sub-dict shape documented in
    ``solutions/service.py`` and in ``specs/128-auto-patch-downstreams/data-model.md``.
    Status transitions:

    - ``proposed``         — fresh LLM output
    - ``edited``           — user overrode the filter expression
    - ``manual_required``  — LLM abstained; user must hand-write the fix
    - ``applied``          — written to disk through the atomic apply helper
    """

    file_path: str
    before_content: str
    after_content: str
    proposal_meta: dict
    status: PatchStatus


def identify_failing_downstreams(
    db: Session,
    shadow_run_id: str,
    manifest_content: dict[str, Any],
) -> list[DownstreamFailure]:
    """Return the list of downstream models that failed shadow validation.

    A failure is any ``ShadowModelExecution`` where ``phase == "shadow"`` and
    ``error_type IS NOT NULL``. Each failure is classified in-project vs.
    external by comparing the matched manifest node's ``package_name`` against
    the project's own ``metadata.project_name``.

    Args:
        db: Active SQLAlchemy session.
        shadow_run_id: UUID string of the shadow run to inspect.
        manifest_content: Parsed dbt manifest.json. Used to look up the node
            by short model_name and to resolve ``original_file_path``,
            ``package_name``, and compiled SQL.

    Returns:
        A list of ``DownstreamFailure`` records — possibly empty. Vendor-package
        models are included with ``is_in_project=False`` so callers can still
        surface them (e.g. "manual follow-up needed") without proposing a patch.
    """
    from governor_core.shadow.models import ShadowModelExecution

    project_name = (
        (manifest_content or {}).get("metadata", {}).get("project_name")
        or (manifest_content or {}).get("metadata", {}).get("adapter_type")
        or ""
    )
    nodes = (manifest_content or {}).get("nodes", {}) or {}
    by_short_name: dict[str, tuple[str, dict]] = {}
    for node_id, node in nodes.items():
        short = node_id.split(".")[-1]
        # Prefer project's own node when multiple packages share a short name.
        if short not in by_short_name or node.get("package_name") == project_name:
            by_short_name[short] = (node_id, node)

    rows = (
        db.query(ShadowModelExecution)
        .filter(
            ShadowModelExecution.shadow_run_id == shadow_run_id,
            ShadowModelExecution.phase == "shadow",
            ShadowModelExecution.error_type.isnot(None),
        )
        .all()
    )

    failures: list[DownstreamFailure] = []
    for row in rows:
        match = by_short_name.get(row.model_name)
        if match is None:
            failures.append(
                DownstreamFailure(
                    node_id=row.model_name,
                    model_name=row.model_name,
                    original_file_path="",
                    package_name="",
                    error_type=row.error_type or "unknown",
                    error_message=row.error_message,
                    is_in_project=False,
                    compiled_sql=None,
                )
            )
            continue

        node_id, node = match
        pkg = node.get("package_name") or ""
        failures.append(
            DownstreamFailure(
                node_id=node_id,
                model_name=row.model_name,
                original_file_path=node.get("original_file_path", ""),
                package_name=pkg,
                error_type=row.error_type or "unknown",
                error_message=row.error_message,
                is_in_project=(project_name != "" and pkg == project_name),
                compiled_sql=(
                    node.get("compiled_code") or node.get("raw_code") or None
                ),
            )
        )

    return failures
