"""SQLAlchemy ORM models for shadow validation (spec 110)."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from governor_core.db.base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


# Legal status transitions. Enforced in Python — not in SQL — for operational
# flexibility during implementation.
_LEGAL_TRANSITIONS: dict[str, set[str]] = {
    "queued": {"running", "skipped"},
    "running": {
        "succeeded",
        "shadow_failed",
        "baseline_failed",
        "timed_out",
        "quota_exhausted",
    },
    "succeeded": set(),
    "shadow_failed": set(),
    "baseline_failed": set(),
    "skipped": set(),
    "timed_out": set(),
    "quota_exhausted": set(),
}

TERMINAL_STATUSES = frozenset(
    {
        "succeeded",
        "shadow_failed",
        "baseline_failed",
        "skipped",
        "timed_out",
        "quota_exhausted",
    }
)


class ShadowValidationRun(Base):
    """A single attempt to empirically validate a solution."""

    __tablename__ = "shadow_validation_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    solution_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("solutions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    manifest_version_id: Mapped[Optional[str]] = mapped_column(
        String(36),
        ForeignKey("manifest_versions.id", ondelete="SET NULL"),
        nullable=True,
    )
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="queued"
    )
    # Spec 124: provenance marker — 'manual' (user click) or 'auto' (worker).
    triggered_by: Mapped[str] = mapped_column(
        String(16), nullable=False, default="manual"
    )
    skipped_reason: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    failure_reason: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    cascade_size: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    estimated_baseline_cost_usd: Mapped[Decimal] = mapped_column(
        Numeric(10, 4), nullable=False, default=Decimal("0")
    )
    budget_cap_usd: Mapped[Decimal] = mapped_column(
        Numeric(10, 4), nullable=False, default=Decimal("10")
    )
    cascade_cap: Mapped[int] = mapped_column(Integer, nullable=False, default=20)
    timeout_seconds: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1800
    )
    baseline_started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    baseline_completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    shadow_started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    shadow_completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    total_baseline_bytes: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True
    )
    total_baseline_slot_ms: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True
    )
    total_baseline_cost_usd: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(12, 4), nullable=True
    )
    total_shadow_bytes: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True
    )
    total_shadow_slot_ms: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True
    )
    total_shadow_cost_usd: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(12, 4), nullable=True
    )
    bytes_delta_pct: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(8, 4), nullable=True
    )
    cost_delta_usd: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(12, 4), nullable=True
    )
    solution_id_hex12: Mapped[str] = mapped_column(
        String(12), nullable=False, index=True
    )
    # Captured dbt stdout from baseline + shadow phases, persisted so the
    # UI can re-display logs after the live SSE terminal has closed.
    build_logs: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    executions: Mapped[list["ShadowModelExecution"]] = relationship(
        "ShadowModelExecution",
        back_populates="shadow_run",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("ix_svr_config_status", "config_id", "status"),
        Index(
            "uq_svr_single_active_per_config",
            "config_id",
            unique=True,
            postgresql_where=text("status IN ('queued', 'running')"),
            sqlite_where=text("status IN ('queued', 'running')"),
        ),
    )

    def transition_to(self, new_status: str) -> None:
        """Validate and apply a status transition."""
        legal = _LEGAL_TRANSITIONS.get(self.status, set())
        if new_status not in legal:
            raise ValueError(
                f"illegal shadow-run transition {self.status!r} -> {new_status!r}"
            )
        self.status = new_status


class ShadowModelExecution(Base):
    """Per-model execution metrics for one phase of one shadow run."""

    __tablename__ = "shadow_model_executions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    shadow_run_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("shadow_validation_runs.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    phase: Mapped[str] = mapped_column(String(16), nullable=False)
    model_name: Mapped[str] = mapped_column(String(512), nullable=False)
    materialized_table_name: Mapped[str] = mapped_column(
        String(1024), nullable=False
    )
    bq_job_id: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    bytes_processed: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    slot_ms: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    duration_ms: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    row_count: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    cost_usd: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(12, 4), nullable=True
    )
    error_type: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    shadow_run: Mapped["ShadowValidationRun"] = relationship(
        "ShadowValidationRun", back_populates="executions"
    )

    __table_args__ = (
        CheckConstraint("phase IN ('baseline', 'shadow')", name="ck_sme_phase"),
        Index(
            "uq_sme_run_phase_model",
            "shadow_run_id",
            "phase",
            "model_name",
            unique=True,
        ),
    )
