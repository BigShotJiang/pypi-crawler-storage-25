"""Downstream-cascade discovery from a stored dbt manifest.

Given the root model node_id and the `child_map` from manifest.json, returns a
deterministically-ordered list of [root, ...downstream dbt nodes]. Non-model
nodes (sources, tests, exposures) are filtered out.
"""

from __future__ import annotations

from collections import deque


def discover_cascade(
    manifest_content: dict,
    target_node_id: str,
    *,
    max_size: int | None = None,
) -> list[str]:
    """Return [target, ...downstream models] via BFS over the manifest's child_map.

    Args:
        manifest_content: Parsed manifest.json.
        target_node_id: dbt node id like "model.my_project.fct_orders".
        max_size: If given and the cascade exceeds this size, discovery
            stops early and the returned list is truncated.

    Returns:
        Ordered list with `target_node_id` first, then downstream models in
        BFS order. Only nodes whose id begins with "model." are included.
    """
    child_map: dict[str, list[str]] = manifest_content.get("child_map", {}) or {}

    if not target_node_id.startswith("model."):
        return []

    result: list[str] = [target_node_id]
    seen: set[str] = {target_node_id}
    queue: deque[str] = deque([target_node_id])

    while queue:
        if max_size is not None and len(result) >= max_size:
            break
        current = queue.popleft()
        for child in child_map.get(current, []):
            if child in seen or not child.startswith("model."):
                continue
            seen.add(child)
            result.append(child)
            queue.append(child)
            if max_size is not None and len(result) >= max_size:
                break

    return result


def node_id_to_model_name(node_id: str) -> str:
    """Extract the dbt model name from a node_id.

    Examples:
        'model.my_project.fct_orders' -> 'fct_orders'
    """
    parts = node_id.split(".")
    return parts[-1] if parts else node_id
