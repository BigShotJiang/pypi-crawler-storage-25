from __future__ import annotations

from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from governor_core.core.config import get_settings
from governor_core.db.sqlite_compat import attach_sqlite_pragmas


def create_engine_for_url(database_url: str) -> Engine:
    """Create a SQLAlchemy engine for the given URL.

    Applies the SQLite compat pragmas when the URL targets SQLite. Use this
    from the CLI to bind to ``sqlite:///~/.governor/state.db`` without the
    engine-wide defaults.
    """
    engine = create_engine(database_url, pool_pre_ping=True)
    attach_sqlite_pragmas(engine)
    return engine


_settings = get_settings()
engine: Engine = create_engine_for_url(_settings.database_url)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
