from __future__ import annotations

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Shared declarative base for all Governor ORM models.

    Both ``governor_core`` (engine tables) and ``governor_web`` (auth/audit/
    settings tables) declare their models against this same Base. The single
    shared metadata lets a single SQLAlchemy Session read/write across the
    whole schema while Alembic env files per package filter autogenerate to
    the tables they own (see ``include_object`` in each env.py).
    """

    pass


def _import_core_models() -> None:
    """Register all engine-owned models on ``Base.metadata``.

    Called at import time so anyone who imports ``governor_core.db.base``
    sees the full engine-side metadata.
    """
    from governor_core.configurations import models as _cfg  # noqa: F401
    from governor_core.opportunities import models as _opp  # noqa: F401
    from governor_core.pullrequests import models as _pr  # noqa: F401
    from governor_core.solutions import models as _sol  # noqa: F401
    from governor_core.sync import models as _sync  # noqa: F401
    from governor_core.shadow import models as _shadow  # noqa: F401


_import_core_models()
