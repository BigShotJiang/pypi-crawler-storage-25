"""SQLite compatibility shim — promoted from tests/unit/fixtures/database.py.

Governor's production deployment runs Postgres; the CLI defaults to SQLite.
Several SQLAlchemy column types used in engine-owned models are Postgres-only
at the dialect level (``JSONB``, ``ARRAY``, native ``UUID``). This shim
transparently substitutes SQLite-compatible equivalents when an engine is
created against a ``sqlite:`` URL so the same ORM definitions work on both
backends.

Importing this module has no effect until ``apply_sqlite_compat()`` is called
against a bound metadata object.
"""

from __future__ import annotations

import logging

from sqlalchemy import JSON, MetaData, event
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.engine import Engine

logger = logging.getLogger(__name__)


def apply_sqlite_compat(metadata: MetaData) -> None:
    """Substitute PG-only column types with SQLite-compatible ones.

    Must be called AFTER all models have registered with the metadata but
    BEFORE the first create_all()/migration call. Idempotent.
    """
    for table in metadata.sorted_tables:
        for column in table.columns:
            if isinstance(column.type, JSONB):
                column.type = JSON()
            elif isinstance(column.type, ARRAY):
                # SQLite has no native array; JSON is the pragmatic substitute.
                column.type = JSON()


def declare_web_stub_tables(metadata: MetaData) -> None:
    """Register minimal stub definitions for web-owned tables that core FKs to.

    Core-owned ORM models declare foreign keys like ``ForeignKey("users.id")``.
    Running core Alembic alone (e.g., from the CLI) requires the referenced
    tables to exist in ``Base.metadata`` for schema sorting to succeed. These
    stubs provide the minimum shape SQLAlchemy needs — the full columns are
    created by web Alembic migrations in cloud deployments.

    Skipped entirely if ``governor_web`` is already imported (its User / other
    web models have the authoritative definitions). This makes the function
    safe to call from the CLI even in a workspace where both packages are
    installed side-by-side.
    """
    import sys

    if "governor_web" in sys.modules:
        return

    from sqlalchemy import Column, String, Table

    web_stub_tables = (
        ("users", [Column("id", String(36), primary_key=True)]),
        ("verification_runs", [Column("id", String(36), primary_key=True)]),
    )
    for name, columns in web_stub_tables:
        if name in metadata.tables:
            continue
        Table(name, metadata, *columns)


def attach_sqlite_pragmas(engine: Engine) -> None:
    """Set runtime PRAGMAs for SQLite engines.

    - ``foreign_keys=ON`` — enable FK enforcement (off by default on SQLite).
    - ``journal_mode=WAL`` — better concurrency for a single-writer CLI.
    """
    if engine.dialect.name != "sqlite":
        return

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, _connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.close()
