"""SQLAlchemy ORM model for pull request records."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from governor_core.db.base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class PullRequestRecord(Base):
    """Tracks a GitHub pull request created or collected from GitHub.

    For Governor-created PRs, opportunity_id/solution_id/created_by are set.
    For collected (discovered) PRs, these fields may be null.
    """

    __tablename__ = "pull_request_records"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    opportunity_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="SET NULL"),
        nullable=True,
    )
    solution_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("solutions.id", ondelete="SET NULL"),
        nullable=True,
    )
    repository: Mapped[str] = mapped_column(String(256), nullable=False)
    branch_name: Mapped[str] = mapped_column(String(256), nullable=False)
    pr_number: Mapped[int] = mapped_column(Integer, nullable=False)
    pr_url: Mapped[str] = mapped_column(String(1024), nullable=False)
    commit_sha: Mapped[str] = mapped_column(String(40), nullable=False)
    base_branch: Mapped[str] = mapped_column(String(256), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="open")
    created_by: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("users.id"),
        nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    merged_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    opportunity: Mapped["Opportunity | None"] = relationship(  # noqa: F821
        "Opportunity",
    )
    solution: Mapped["Solution | None"] = relationship(  # noqa: F821
        "Solution",
    )

    __table_args__ = (
        UniqueConstraint("repository", "pr_number", name="uq_pr_repo_number"),
        CheckConstraint(
            "status IN ('open', 'merged', 'closed')",
            name="ck_pr_status",
        ),
        Index("ix_pr_status", "status"),
    )


class PrLineageImpact(Base):
    """Caches downstream lineage cost impact analysis for a PR + manifest version pair.

    Keyed by (pr_id, manifest_version_id). Naturally invalidated when a new
    manifest sync creates a new manifest_version_id.
    """

    __tablename__ = "pr_lineage_impacts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    pr_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("pull_request_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    manifest_version_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_versions.id", ondelete="CASCADE"),
        nullable=False,
    )
    affected_model_name: Mapped[str] = mapped_column(String(512), nullable=False)
    affected_column: Mapped[str] = mapped_column(String(256), nullable=False)
    change_type: Mapped[str] = mapped_column(String(16), nullable=False)
    total_estimated_savings: Mapped[Decimal] = mapped_column(
        Numeric(12, 4), nullable=False, default=Decimal("0")
    )
    beneficiary_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_downstream_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    impact_results: Mapped[list] = mapped_column(
        JSONB, nullable=False, default=list
    )
    computed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    __table_args__ = (
        UniqueConstraint(
            "pr_id", "manifest_version_id", name="uq_pr_lineage_pr_manifest"
        ),
        Index("ix_pr_lineage_impacts_pr_id", "pr_id"),
    )
