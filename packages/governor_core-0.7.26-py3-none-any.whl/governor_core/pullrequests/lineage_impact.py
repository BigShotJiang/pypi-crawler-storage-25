"""Downstream lineage cost impact analysis for PR detail page.

Traverses the dbt manifest DAG downstream from a changed model,
detects which downstream models benefit from partition/cluster pruning,
and estimates the monthly cost savings per model.

Core class: DownstreamLineageAnalyzer
  - Takes manifest content (JSONB dict) and an injectable jobs query callable
  - Pure business logic — no direct DB access inside the class
  - Results are serialisable for caching in pr_lineage_impacts table
"""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from typing import Callable

from governor_core.opportunities.savings_estimator import (
    estimate_cluster_savings,
    estimate_partition_savings_without_metadata,
    extract_table_predicates,
)

logger = logging.getLogger(__name__)

# BigQuery on-demand: $6.25 per TiB
_BQ_PRICE_PER_BYTE = Decimal("6.25") / Decimal(str(1024**4))

# Look back up to 90 days of job history per downstream model
_OBSERVATION_DAYS = 90


# ---------------------------------------------------------------------------
# Runtime data structures (not persisted directly)
# ---------------------------------------------------------------------------


@dataclass
class DownstreamImpactResult:
    model_name: str
    relation_name: str
    dependency_path: list[str]  # model names root → this node
    depth: int
    included: bool
    inclusion_reason: str
    expression_type: str | None  # 'WHERE' | 'JOIN' | 'HAVING' | None
    estimated_bytes_saved_per_run: int | None
    estimated_monthly_cost_usd: Decimal | None
    confidence: str | None  # 'high' | 'medium' | 'low'
    jobs_analyzed: int
    run_frequency_per_day: float | None


@dataclass
class LineageImpactSummary:
    pr_id: str
    affected_model_name: str
    affected_column: str
    change_type: str  # 'partition' | 'cluster'
    total_estimated_savings: Decimal
    beneficiary_count: int
    total_downstream_count: int
    results: list[DownstreamImpactResult]
    is_projected: bool  # True if PR is open/unmerged


# ---------------------------------------------------------------------------
# Main analyser
# ---------------------------------------------------------------------------


class DownstreamLineageAnalyzer:
    """BFS downstream DAG traversal with per-model savings estimation."""

    def __init__(
        self,
        manifest_content: dict,
        bigquery_jobs_query: Callable[[str], list[dict]],
    ) -> None:
        self._manifest = manifest_content
        self._bigquery_jobs_query = bigquery_jobs_query

    def compute(
        self,
        root_model_name: str,
        affected_column: str,
        change_type: str,  # 'partition' | 'cluster'
        max_depth: int = 6,
    ) -> list[DownstreamImpactResult]:
        """Traverse downstream DAG and estimate savings per model.

        1. BFS through manifest child_map starting from root_model_name.
        2. For each downstream node: check compiled SQL for predicates on
           affected_column via the node's direct parent.
        3. If predicate found: query job history, estimate savings.
        4. Deduplicate diamond dependencies (shortest path wins).
        5. Return all nodes (included + excluded) sorted: beneficiaries first,
           then by savings descending.
        """
        child_map = self._manifest.get("child_map", {})
        nodes = self._manifest.get("nodes", {})

        if not child_map or not nodes:
            return []

        root_uid = _find_model_unique_id(nodes, root_model_name)
        if not root_uid:
            logger.debug("Root model %r not found in manifest nodes", root_model_name)
            return []

        root_relation_name = nodes[root_uid].get("relation_name") or ""

        results: list[DownstreamImpactResult] = []
        # visited maps uid → minimum depth seen, for diamond dedup
        visited: dict[str, int] = {}

        # Queue entries: (uid, dep_path, depth, parent_relation_name)
        queue: deque = deque()
        queue.append((root_uid, [root_model_name], 0, root_relation_name))

        while queue:
            uid, path, depth, parent_relation_name = queue.popleft()

            if depth >= max_depth:
                continue

            children = child_map.get(uid, [])
            for child_uid in children:
                if not child_uid.startswith("model."):
                    continue

                child_node = nodes.get(child_uid)
                if not child_node:
                    continue

                # Skip if already seen at equal or shallower depth (diamond dedup)
                if child_uid in visited and visited[child_uid] <= depth + 1:
                    continue
                visited[child_uid] = depth + 1

                model_name = child_node.get("name") or ""
                relation_name = child_node.get("relation_name") or ""
                compiled_code = child_node.get("compiled_code") or ""
                dep_path = path + [model_name]

                # Check compiled SQL for predicates on the affected column
                has_filter, expression_type = _check_column_filter(
                    compiled_code, parent_relation_name, affected_column
                )

                jobs_analyzed = 0
                estimated_bytes: int | None = None
                estimated_cost: Decimal | None = None
                confidence: str | None = None
                run_freq: float | None = None

                if has_filter and relation_name:
                    try:
                        jobs = self._bigquery_jobs_query(relation_name)
                        jobs_analyzed = len(jobs)
                        if jobs:
                            est = _estimate_downstream_savings(
                                jobs=jobs,
                                parent_relation_name=parent_relation_name,
                                affected_column=affected_column,
                                change_type=change_type,
                            )
                            estimated_bytes = est["bytes_saved_per_run"]
                            estimated_cost = est["monthly_cost_usd"]
                            confidence = est["confidence"]
                            run_freq = est["run_frequency_per_day"]
                    except (KeyError, ValueError, TypeError, ZeroDivisionError):
                        logger.debug(
                            "Savings estimation failed for model %r",
                            model_name,
                            exc_info=True,
                        )

                included = (
                    has_filter
                    and jobs_analyzed > 0
                    and estimated_cost is not None
                    and estimated_cost > Decimal("0")
                )

                inclusion_reason = _build_inclusion_reason(
                    has_filter=has_filter,
                    jobs_analyzed=jobs_analyzed,
                    affected_column=affected_column,
                    change_type=change_type,
                    expression_type=expression_type,
                )

                results.append(
                    DownstreamImpactResult(
                        model_name=model_name,
                        relation_name=relation_name,
                        dependency_path=dep_path,
                        depth=depth + 1,
                        included=included,
                        inclusion_reason=inclusion_reason,
                        expression_type=expression_type,
                        estimated_bytes_saved_per_run=estimated_bytes,
                        estimated_monthly_cost_usd=estimated_cost,
                        confidence=confidence,
                        jobs_analyzed=jobs_analyzed,
                        run_frequency_per_day=run_freq,
                    )
                )

                # Enqueue children — pass this model's relation_name as parent
                queue.append((child_uid, dep_path, depth + 1, relation_name))

        # Sort: beneficiaries first, then by savings descending, then alpha
        results.sort(
            key=lambda r: (
                not r.included,
                -(float(r.estimated_monthly_cost_usd) if r.estimated_monthly_cost_usd else 0.0),
                r.model_name,
            )
        )
        return results


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _find_model_unique_id(nodes: dict, model_name: str) -> str | None:
    """Return the first unique_id matching a dbt model by name."""
    for uid, node in nodes.items():
        if uid.startswith("model.") and node.get("name") == model_name:
            return uid
    return None


def _check_column_filter(
    compiled_sql: str,
    parent_relation_name: str,
    affected_column: str,
) -> tuple[bool, str | None]:
    """Check compiled SQL for partition-compatible predicates on affected_column.

    Checks against the parent model's relation_name. Returns (has_filter, expression_type).
    """
    if not compiled_sql or not parent_relation_name or not affected_column:
        return False, None

    predicates = extract_table_predicates(
        sql=compiled_sql,
        target_table=parent_relation_name,
        target_columns=[affected_column],
    )
    compatible = [p for p in predicates if p.is_partition_compatible]
    if not compatible:
        return False, None

    return True, "WHERE"


def _estimate_downstream_savings(
    jobs: list[dict],
    parent_relation_name: str,
    affected_column: str,
    change_type: str,
) -> dict:
    """Estimate monthly savings for a downstream model from its job history.

    For each job, re-parses SQL predicates on the parent model and applies
    partition/cluster pruning heuristics to the bytes billed.

    Returns a dict with keys:
        bytes_saved_per_run, monthly_cost_usd, confidence, run_frequency_per_day
    """
    total_bytes_saved = 0
    total_cost_saved = Decimal("0")
    jobs_with_filters = 0
    valid_jobs = 0

    # Observation window from job creation times
    creation_times: list[datetime] = [
        j["creation_time"]
        for j in jobs
        if isinstance(j.get("creation_time"), datetime)
    ]
    if len(creation_times) >= 2:
        delta = max(creation_times) - min(creation_times)
        observation_days = max(delta.days, 1)
    else:
        observation_days = _OBSERVATION_DAYS

    for job in jobs:
        sql = job.get("query") or ""
        bytes_billed = int(job.get("total_bytes_billed") or 0)
        if not sql or bytes_billed <= 0:
            continue
        valid_jobs += 1

        predicates = extract_table_predicates(
            sql, parent_relation_name, [affected_column]
        )
        compatible = [p for p in predicates if p.is_partition_compatible]
        if not compatible:
            continue

        jobs_with_filters += 1

        if change_type == "partition":
            est = estimate_partition_savings_without_metadata(
                predicates=predicates,
                partition_column=affected_column,
                total_bytes=bytes_billed,
            )
            bytes_saved = est.pruned_bytes
        else:
            # cluster
            est_c = estimate_cluster_savings(
                predicates=predicates,
                cluster_columns=[affected_column],
                table_stats=None,
                remaining_bytes=bytes_billed,
            )
            bytes_saved = est_c.pruned_bytes

        cost_saved = Decimal(str(bytes_saved)) * _BQ_PRICE_PER_BYTE
        total_bytes_saved += bytes_saved
        total_cost_saved += cost_saved

    confidence = _compute_confidence(valid_jobs, jobs_with_filters)

    if jobs_with_filters == 0:
        return {
            "bytes_saved_per_run": None,
            "monthly_cost_usd": None,
            "confidence": confidence,
            "run_frequency_per_day": len(jobs) / observation_days if observation_days > 0 else None,
        }

    monthly_factor = Decimal("30") / Decimal(str(observation_days))
    monthly_projection = total_cost_saved * monthly_factor
    bytes_per_run = total_bytes_saved // jobs_with_filters
    run_freq = len(jobs) / observation_days if observation_days > 0 else None

    return {
        "bytes_saved_per_run": bytes_per_run,
        "monthly_cost_usd": monthly_projection,
        "confidence": confidence,
        "run_frequency_per_day": run_freq,
    }


def _compute_confidence(jobs_analyzed: int, jobs_with_filters: int) -> str:
    if jobs_analyzed == 0:
        return "low"
    coverage = jobs_with_filters / jobs_analyzed
    if jobs_analyzed >= 20 and coverage >= 0.80:
        return "high"
    if jobs_analyzed >= 5 and coverage >= 0.40:
        return "medium"
    return "low"


def _build_inclusion_reason(
    has_filter: bool,
    jobs_analyzed: int,
    affected_column: str,
    change_type: str,
    expression_type: str | None,
) -> str:
    if not has_filter:
        return f"No filter on `{affected_column}` — full table scan"
    if jobs_analyzed == 0:
        return f"Filters on `{affected_column}` — no job history, savings not estimated"
    pruning_label = f"{change_type} pruning"
    clause = (expression_type or "WHERE").upper()
    return f"{clause} on `{affected_column}` — {pruning_label} applies"


# ---------------------------------------------------------------------------
# Summary builders (called from route)
# ---------------------------------------------------------------------------


def build_summary_from_results(
    pr,
    manifest_version,
    results: list[DownstreamImpactResult],
    affected_column: str,
    change_type: str,
    root_model_name: str,
) -> LineageImpactSummary:
    """Build LineageImpactSummary from freshly-computed results."""
    included = [r for r in results if r.included]
    total_savings = sum(
        (r.estimated_monthly_cost_usd or Decimal("0") for r in included),
        Decimal("0"),
    )
    return LineageImpactSummary(
        pr_id=pr.id,
        affected_model_name=root_model_name,
        affected_column=affected_column,
        change_type=change_type,
        total_estimated_savings=total_savings,
        beneficiary_count=len(included),
        total_downstream_count=len(results),
        results=results,
        is_projected=pr.status == "open",
    )


def build_summary(cached, pr) -> LineageImpactSummary:
    """Reconstruct LineageImpactSummary from a cached PrLineageImpact DB row."""
    results = [
        DownstreamImpactResult(
            model_name=r.get("model_name", ""),
            relation_name=r.get("relation_name", ""),
            dependency_path=r.get("dependency_path", []),
            depth=r.get("depth", 0),
            included=r.get("included", False),
            inclusion_reason=r.get("inclusion_reason", ""),
            expression_type=r.get("expression_type"),
            estimated_bytes_saved_per_run=r.get("estimated_bytes_saved_per_run"),
            estimated_monthly_cost_usd=(
                Decimal(str(r["estimated_monthly_cost_usd"]))
                if r.get("estimated_monthly_cost_usd") is not None
                else None
            ),
            confidence=r.get("confidence"),
            jobs_analyzed=r.get("jobs_analyzed", 0),
            run_frequency_per_day=r.get("run_frequency_per_day"),
        )
        for r in (cached.impact_results or [])
    ]
    return LineageImpactSummary(
        pr_id=pr.id,
        affected_model_name=cached.affected_model_name,
        affected_column=cached.affected_column,
        change_type=cached.change_type,
        total_estimated_savings=cached.total_estimated_savings,
        beneficiary_count=cached.beneficiary_count,
        total_downstream_count=cached.total_downstream_count,
        results=results,
        is_projected=pr.status == "open",
    )


def results_to_json(results: list[DownstreamImpactResult]) -> list[dict]:
    """Serialise results list for storage in JSONB impact_results column."""
    return [
        {
            "model_name": r.model_name,
            "relation_name": r.relation_name,
            "dependency_path": list(r.dependency_path),
            "depth": r.depth,
            "included": r.included,
            "inclusion_reason": r.inclusion_reason,
            "expression_type": r.expression_type,
            "estimated_bytes_saved_per_run": r.estimated_bytes_saved_per_run,
            "estimated_monthly_cost_usd": (
                float(r.estimated_monthly_cost_usd)
                if r.estimated_monthly_cost_usd is not None
                else None
            ),
            "confidence": r.confidence,
            "jobs_analyzed": r.jobs_analyzed,
            "run_frequency_per_day": r.run_frequency_per_day,
        }
        for r in results
    ]
