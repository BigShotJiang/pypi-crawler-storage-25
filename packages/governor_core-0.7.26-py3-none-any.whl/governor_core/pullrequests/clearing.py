"""Clearing status logic — flags opportunities as 'clearing' when a merged PR
affects their dbt model or any downstream model in the DAG.

The clearing window is 15 days from the PR merge date, giving cost data time
to settle before drawing conclusions about savings.
"""

from __future__ import annotations

import logging
import os
import re
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from sqlalchemy.exc import SQLAlchemyError

from governor_core.configurations.models import ManifestConfiguration
from governor_core.github.client import (
    GitHubAppClient,
    GitHubAuthenticationError,
    GitHubConnectionError,
    GitHubRateLimitError,
)
from governor_core.opportunities.models import Opportunity
from governor_core.pullrequests.models import PullRequestRecord
from governor_core.sync.models import ManifestVersion

logger = logging.getLogger("app.pullrequests.clearing")

CLEARING_WINDOW_DAYS = 15


def apply_clearing_status(db: Session, github_client: GitHubAppClient) -> dict:
    """Scan merged PRs and set clearing status on affected opportunities.

    For each merged PR within the last 15 days:
    1. Fetch changed files from GitHub
    2. Extract dbt model names from .sql file paths
    3. Use the manifest child_map to find downstream models
    4. Set status='clearing' on matching opportunities

    Also expires any clearing status past 15 days.

    Returns:
        Dict with counts: cleared, expired, errors.
    """
    counts = {"cleared": 0, "expired": 0, "errors": 0}

    # 1. Expire old clearing statuses
    counts["expired"] = _expire_clearing(db)

    # 2. Find merged PRs within the clearing window
    cutoff = datetime.now(timezone.utc) - timedelta(days=CLEARING_WINDOW_DAYS)
    merged_prs = (
        db.query(PullRequestRecord)
        .filter(
            PullRequestRecord.status == "merged",
            PullRequestRecord.merged_at.isnot(None),
            PullRequestRecord.merged_at >= cutoff,
        )
        .all()
    )

    if not merged_prs:
        db.commit()
        return counts

    # 3. For each PR, determine affected models and set clearing
    for pr in merged_prs:
        try:
            cleared = _apply_clearing_for_pr(db, github_client, pr)
            counts["cleared"] += cleared
        except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError, SQLAlchemyError, KeyError, ValueError) as exc:
            counts["errors"] += 1
            logger.exception(
                "Error applying clearing for PR #%d in %s",
                pr.pr_number,
                pr.repository,
            )

    db.commit()
    logger.info(
        "Clearing status applied: cleared=%d, expired=%d, errors=%d",
        counts["cleared"],
        counts["expired"],
        counts["errors"],
    )
    return counts


def _expire_clearing(db: Session) -> int:
    """Revert opportunities whose clearing window has passed back to active."""
    now = datetime.now(timezone.utc)
    expired = (
        db.query(Opportunity)
        .filter(
            Opportunity.status == "clearing",
            Opportunity.clearing_until.isnot(None),
            Opportunity.clearing_until <= now,
        )
        .all()
    )
    for opp in expired:
        opp.status = "active"
        opp.clearing_until = None
        opp.clearing_pr_number = None
        opp.clearing_repository = None
        # Clear cascade fields for fresh analysis next cycle (spec 082)
        opp.cascade_group_id = None
        opp.cascade_root_id = None
        opp.cascade_status = None
    return len(expired)


def _apply_clearing_for_pr(
    db: Session, github_client: GitHubAppClient, pr: PullRequestRecord
) -> int:
    """Set clearing status on opportunities affected by a single merged PR.

    Returns the number of opportunities set to clearing.
    """
    merged_at = pr.merged_at
    if merged_at.tzinfo is None:
        merged_at = merged_at.replace(tzinfo=timezone.utc)
    clearing_until = merged_at + timedelta(days=CLEARING_WINDOW_DAYS)

    # If clearing window already passed, skip
    if clearing_until <= datetime.now(timezone.utc):
        return 0

    # Get changed files from GitHub
    try:
        pr_files = github_client.get_pull_request_files(pr.repository, pr.pr_number)
    except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError):
        logger.warning(
            "Could not fetch files for PR #%d in %s", pr.pr_number, pr.repository
        )
        raise

    # Extract dbt model names from .sql files
    changed_models = set()
    for f in pr_files:
        fname = os.path.basename(f["filename"])
        if fname.endswith(".sql"):
            changed_models.add(re.sub(r"\.sql$", "", fname))

    if not changed_models:
        return 0

    # Get the latest manifest to find downstream models
    all_affected = set(changed_models)
    downstream = _find_downstream_models(db, pr.repository, changed_models)
    all_affected.update(downstream)

    # Find opportunities matching these model names
    opportunities = (
        db.query(Opportunity)
        .filter(
            Opportunity.dbt_model_name.in_(all_affected),
            Opportunity.status.in_(["active", "clearing"]),
        )
        .all()
    )

    cleared_count = 0
    cascade_group_ids: set[str] = set()

    for opp in opportunities:
        # Only update if not already clearing with a later expiry
        if (
            opp.status != "clearing"
            or opp.clearing_until is None
            or opp.clearing_until < clearing_until
        ):
            opp.status = "clearing"
            opp.clearing_until = clearing_until
            opp.clearing_pr_number = pr.pr_number
            opp.clearing_repository = pr.repository
            cleared_count += 1

            # Track cascade groups for propagation (spec 082)
            if opp.cascade_group_id:
                cascade_group_ids.add(opp.cascade_group_id)

    # Propagate clearing to cascade group members (spec 082)
    if cascade_group_ids:
        cascade_members = (
            db.query(Opportunity)
            .filter(
                Opportunity.cascade_group_id.in_(cascade_group_ids),
                Opportunity.status.in_(["active"]),
            )
            .all()
        )
        for member in cascade_members:
            member.status = "clearing"
            member.clearing_until = clearing_until
            member.clearing_pr_number = pr.pr_number
            member.clearing_repository = pr.repository
            cleared_count += 1

    return cleared_count


def _find_downstream_models(
    db: Session, repository: str, model_names: set[str]
) -> set[str]:
    """Use the manifest child_map to find all downstream dbt model names.

    Performs BFS through the DAG starting from the changed models.
    """
    # Get the config for this repo
    config = (
        db.query(ManifestConfiguration)
        .filter(
            ManifestConfiguration.github_repo == repository,
            ManifestConfiguration.status == "active",
        )
        .first()
    )
    if not config:
        return set()

    # Get the latest manifest version
    manifest_version = (
        db.query(ManifestVersion)
        .filter(ManifestVersion.config_id == config.id)
        .order_by(ManifestVersion.retrieved_at.desc())
        .first()
    )
    if not manifest_version or not manifest_version.content:
        return set()

    manifest = manifest_version.content
    nodes = manifest.get("nodes", {})
    child_map = manifest.get("child_map", {})

    if not child_map:
        return set()

    # Map model names to unique_ids
    name_to_uid: dict[str, str] = {}
    uid_to_name: dict[str, str] = {}
    for uid, node in nodes.items():
        if uid.startswith("model."):
            name = node.get("name", "")
            name_to_uid[name] = uid
            uid_to_name[uid] = name

    # BFS from changed models through child_map
    downstream_names: set[str] = set()
    queue = []
    visited: set[str] = set()

    for model_name in model_names:
        uid = name_to_uid.get(model_name)
        if uid:
            queue.append(uid)
            visited.add(uid)

    while queue:
        current = queue.pop(0)
        children = child_map.get(current, [])
        for child_uid in children:
            if child_uid in visited:
                continue
            visited.add(child_uid)
            if child_uid.startswith("model."):
                name = uid_to_name.get(child_uid)
                if name:
                    downstream_names.add(name)
                queue.append(child_uid)

    return downstream_names
