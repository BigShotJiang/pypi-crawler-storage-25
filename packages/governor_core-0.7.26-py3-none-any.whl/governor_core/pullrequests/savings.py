"""Post-merge savings calculator (spec 068).

Compares BigQuery job costs before and after a PR merge to verify
whether Governor's optimizations actually reduced costs.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import and_, func, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from governor_core.opportunities.models import Opportunity
from governor_core.pullrequests.models import PullRequestRecord
from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("app.pullrequests.savings")

# Configuration
BASELINE_WINDOW_DAYS = 14
MEASUREMENT_WINDOW_DAYS = 14
MIN_JOBS_FOR_BASELINE = 3
MIN_JOBS_FOR_MEASUREMENT = 3

# BigQuery on-demand pricing: $6.25 per TiB billed
_BQ_COST_PER_BYTE = Decimal("6.25") / Decimal(str(1024**4))


def _avg_cost_from_jobs(
    db: Session,
    config_id: str,
    affected_table: str,
    window_start: datetime,
    window_end: datetime,
) -> tuple[Decimal | None, int]:
    """Query BigQueryJob for average cost in a time window.

    Returns (avg_cost_per_run, job_count). avg_cost is None if no jobs found.
    Uses total_bytes_billed to compute cost (more reliable than total_cost
    which may be null for some job types).
    """
    filters = [
        BigQueryJob.config_id == config_id,
        BigQueryJob.destination_table == affected_table,
        BigQueryJob.creation_time >= window_start,
        BigQueryJob.creation_time < window_end,
        BigQueryJob.job_state == "DONE",
        # Exclude cache hits — they process 0 bytes and would skew the average
        BigQueryJob.cache_hit.isnot(True),
        BigQueryJob.total_bytes_billed.isnot(None),
    ]

    result = db.execute(
        select(
            func.avg(BigQueryJob.total_bytes_billed),
            func.count(),
        ).where(and_(*filters))
    ).one()

    avg_bytes = result[0]
    job_count = result[1] or 0

    if avg_bytes is None or job_count == 0:
        return None, 0

    avg_cost = Decimal(str(avg_bytes)) * _BQ_COST_PER_BYTE
    return avg_cost, job_count


def calculate_verified_savings(db: Session, opportunity: Opportunity) -> str:
    """Calculate verified savings for a single opportunity.

    Compares average BigQuery job costs in pre-merge and post-merge windows.

    Args:
        db: Active database session.
        opportunity: The resolved opportunity to calculate savings for.

    Returns:
        The updated verified_savings_status string.
    """
    # Load the PR record to get merged_at
    pr_record = (
        db.query(PullRequestRecord)
        .filter(PullRequestRecord.opportunity_id == opportunity.id)
        .one_or_none()
    )

    if not pr_record or not pr_record.merged_at:
        opportunity.verified_savings_status = "insufficient_data"
        opportunity.verified_savings_calculated_at = datetime.now(timezone.utc)
        return "insufficient_data"

    merged_at = pr_record.merged_at
    if merged_at.tzinfo is None:
        merged_at = merged_at.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)

    # Define time windows
    pre_start = merged_at - timedelta(days=BASELINE_WINDOW_DAYS)
    pre_end = merged_at
    post_start = merged_at
    post_end = min(merged_at + timedelta(days=MEASUREMENT_WINDOW_DAYS), now)

    # Query pre-merge costs
    pre_avg_cost, pre_count = _avg_cost_from_jobs(
        db, opportunity.config_id, opportunity.affected_table, pre_start, pre_end
    )

    # Query post-merge costs
    post_avg_cost, post_count = _avg_cost_from_jobs(
        db, opportunity.config_id, opportunity.affected_table, post_start, post_end
    )

    # Update opportunity with raw data
    opportunity.pre_merge_avg_cost = pre_avg_cost
    opportunity.post_merge_avg_cost = post_avg_cost
    opportunity.pre_merge_job_count = pre_count
    opportunity.post_merge_job_count = post_count
    opportunity.verified_savings_calculated_at = now

    # Determine status
    if pre_count < MIN_JOBS_FOR_BASELINE:
        status = "insufficient_data"
        opportunity.verified_savings = None
    elif post_count < MIN_JOBS_FOR_MEASUREMENT:
        # Still within measurement window — keep collecting
        days_since_merge = (now - merged_at).days
        if days_since_merge <= MEASUREMENT_WINDOW_DAYS + 7:
            status = "collecting"
        else:
            # Window has passed but not enough jobs — insufficient data
            status = "insufficient_data"
        opportunity.verified_savings = None
    else:
        # Both windows have enough data — compute savings
        savings = pre_avg_cost - post_avg_cost
        opportunity.verified_savings = savings
        if savings < Decimal("0"):
            status = "negative"
        else:
            status = "confirmed"

    opportunity.verified_savings_status = status

    logger.info(
        "Verified savings for opportunity %s: status=%s, "
        "pre_avg=$%.4f (%d jobs), post_avg=$%.4f (%d jobs), savings=$%.4f",
        opportunity.id,
        status,
        float(pre_avg_cost or 0),
        pre_count,
        float(post_avg_cost or 0),
        post_count,
        float(opportunity.verified_savings or 0),
    )

    return status


def recalculate_all_pending(db: Session) -> dict:
    """Recalculate verified savings for all pending/collecting opportunities.

    Returns:
        Dict with counts: {"processed": N, "confirmed": N, "collecting": N,
                           "negative": N, "insufficient_data": N}
    """
    opportunities = (
        db.query(Opportunity)
        .filter(
            Opportunity.verified_savings_status.in_(("pending", "collecting"))
        )
        .all()
    )

    if not opportunities:
        return {"processed": 0, "confirmed": 0, "collecting": 0,
                "negative": 0, "insufficient_data": 0}

    counts = {"processed": len(opportunities), "confirmed": 0, "collecting": 0,
              "negative": 0, "insufficient_data": 0}

    for opp in opportunities:
        try:
            status = calculate_verified_savings(db, opp)
            counts[status] = counts.get(status, 0) + 1
        except (SQLAlchemyError, ValueError, TypeError) as exc:
            logger.exception(
                "Error calculating verified savings for opportunity %s", opp.id
            )

    db.commit()

    logger.info(
        "Post-merge savings recalculation complete: processed=%d, "
        "confirmed=%d, collecting=%d, negative=%d, insufficient_data=%d",
        counts["processed"],
        counts["confirmed"],
        counts["collecting"],
        counts["negative"],
        counts["insufficient_data"],
    )
    return counts


def execute_savings_calculation() -> None:
    """APScheduler callback — opens DB session, runs savings recalculation."""
    from governor_core.db.session import SessionLocal

    session = SessionLocal()
    try:
        recalculate_all_pending(session)
    except (SQLAlchemyError, ValueError, TypeError):
        logger.exception("Error in post-merge savings calculation")
        session.rollback()
    finally:
        session.close()
