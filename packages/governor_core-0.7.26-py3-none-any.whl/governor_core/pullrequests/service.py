"""Service for creating GitHub pull requests from solutions."""

from __future__ import annotations

import logging
import re
import uuid

from sqlalchemy.orm import Session

from governor_core.utils.formatters import format_usd
from governor_core.github.client import (
    GitHubAppClient,
    GitHubAuthenticationError,
    GitHubConnectionError,
    GitHubFileNotFoundError,
    GitHubRateLimitError,
)
from governor_core.opportunities.models import Opportunity
from governor_core.pullrequests.exceptions import (
    DuplicatePRError,
    FileDriftError,
    PRCreationError,
)
from governor_core.pullrequests.models import PullRequestRecord
from governor_core.solutions.models import Solution

logger = logging.getLogger("app.pullrequests")


class PullRequestService:
    """Orchestrates GitHub pull request creation from solutions."""

    def __init__(self, db: Session, github_client: GitHubAppClient) -> None:
        self._db = db
        self._github = github_client

    def create_pr(
        self,
        opportunity_id: str,
        solution_id: str,
        user_id: str,
    ) -> PullRequestRecord:
        """Create a pull request for a solution.

        Args:
            opportunity_id: The opportunity to create a PR for.
            solution_id: The primary solution to use.
            user_id: The user who initiated the PR creation.

        Returns:
            The created PullRequestRecord.

        Raises:
            PRCreationError: If validation fails.
            DuplicatePRError: If a PR already exists.
            FileDriftError: If files have changed since solution was generated.
        """
        # 1. Load and validate opportunity
        opportunity = (
            self._db.query(Opportunity)
            .filter(Opportunity.id == opportunity_id)
            .one_or_none()
        )
        if not opportunity:
            raise PRCreationError("Opportunity not found.")

        # 2. Check for existing PR
        existing_pr = (
            self._db.query(PullRequestRecord)
            .filter(PullRequestRecord.opportunity_id == opportunity_id)
            .one_or_none()
        )
        if existing_pr:
            if existing_pr.status == "open":
                raise DuplicatePRError(existing_pr.pr_url)
            # Previous PR was merged or closed — remove old record so we
            # can create a new one (unique constraint on opportunity_id).
            logger.info(
                "Removing previous %s PR record %s for opportunity %s",
                existing_pr.status,
                existing_pr.id,
                opportunity_id,
            )
            self._db.delete(existing_pr)
            self._db.flush()

        # Allow pr_pending if the old PR was merged/closed (cleaned up above)
        if opportunity.status not in ("active", "pr_pending"):
            raise PRCreationError("Opportunity is not in active state.")

        # 3. Load solution(s) — latest version for each file_path
        solutions = self._get_latest_solutions(opportunity_id)
        if not solutions:
            raise PRCreationError("No solutions found for this opportunity.")

        # Find the primary solution
        primary = next((s for s in solutions if s.id == solution_id), None)
        if not primary:
            raise PRCreationError("Solution not found.")

        # 4. Validate solution
        if primary.resolution_category != "dbt_project_change":
            raise PRCreationError(
                "Pull requests can only be created for dbt project changes."
            )
        if not primary.repository:
            raise PRCreationError("Solution does not have a target repository.")

        # Filter to dbt_project_change solutions with file paths
        file_solutions = [
            s
            for s in solutions
            if s.resolution_category == "dbt_project_change"
            and s.file_path
            and s.after_content
            and s.repository == primary.repository
        ]
        if not file_solutions:
            raise PRCreationError("No file changes found in the solution.")

        repo = primary.repository

        # 5. Get default branch and HEAD SHA
        default_branch = self._github.get_default_branch(repo)
        head_sha = self._github.get_branch_head_sha(repo, default_branch)

        # 5a. Resolve file paths — detect dbt subdirectory prefix if needed
        repo_paths = self._resolve_repo_paths(repo, file_solutions)

        # 6. Drift check — compare current file with before_content
        for sol in file_solutions:
            if sol.before_content:
                actual_path = repo_paths[sol.file_path]
                current_content = self._github.get_file_content(repo, actual_path)
                if current_content != sol.before_content:
                    # Log details for debugging drift mismatches
                    logger.warning(
                        "Drift detected on %s: current len=%d, before len=%d, "
                        "match_stripped=%s",
                        actual_path,
                        len(current_content),
                        len(sol.before_content),
                        current_content.strip() == sol.before_content.strip(),
                    )
                    raise FileDriftError(
                        f"The file {actual_path} has changed since this "
                        f"solution was generated. Please regenerate the solution."
                    )

        # 7. Create branch (retry once on conflict)
        from governor_core.github.client import GitHubConnectionError

        branch_name = _generate_branch_name(opportunity)
        try:
            self._github.create_branch(repo, branch_name, head_sha)
        except GitHubConnectionError as exc:
            if "already exists" in str(exc).lower():
                branch_name = _generate_branch_name(opportunity)
                self._github.create_branch(repo, branch_name, head_sha)
            else:
                raise

        # 8. Commit all file changes (using resolved repo paths)
        file_changes = [
            {"path": repo_paths[sol.file_path], "content": sol.after_content}
            for sol in file_solutions
        ]
        commit_message = _build_commit_message(opportunity, file_solutions)
        commit_sha = self._github.create_file_commit(
            repo, branch_name, file_changes, commit_message
        )

        # 9. Open PR
        pr_title = _build_pr_title(opportunity, file_solutions)
        pr_body = _build_pr_description(opportunity, file_solutions)
        pr_result = self._github.create_pull_request(
            repo=repo,
            head=branch_name,
            base=default_branch,
            title=pr_title,
            body=pr_body,
            draft=False,
        )

        # 10. Create PullRequestRecord
        pr_record = PullRequestRecord(
            id=str(uuid.uuid4()),
            opportunity_id=opportunity_id,
            solution_id=solution_id,
            repository=repo,
            branch_name=branch_name,
            pr_number=pr_result["number"],
            pr_url=pr_result["html_url"],
            commit_sha=commit_sha,
            base_branch=default_branch,
            status="open",
            created_by=user_id,
        )
        self._db.add(pr_record)

        # 11. Update opportunity status
        opportunity.status = "pr_pending"

        self._db.commit()
        self._db.refresh(pr_record)
        return pr_record

    def _get_latest_solutions(self, opportunity_id: str) -> list[Solution]:
        """Get the latest version of each solution for an opportunity.

        For solutions with a file_path, returns the latest version per file.
        For solutions without a file_path (e.g. bigquery_infrastructure),
        returns the latest version.
        """
        all_solutions = (
            self._db.query(Solution)
            .filter(Solution.opportunity_id == opportunity_id)
            .all()
        )

        # Group by file_path and keep latest version
        by_path: dict[str | None, Solution] = {}
        for sol in all_solutions:
            key = sol.file_path
            if key is None:
                # For non-file solutions, use id as key (keep each)
                by_path[sol.id] = sol
            elif key not in by_path or sol.version_number > by_path[key].version_number:
                by_path[key] = sol

        return list(by_path.values())

    def _resolve_repo_paths(
        self, repo: str, solutions: list[Solution]
    ) -> dict[str, str]:
        """Map solution file_path → actual repo path.

        Handles the case where the dbt project lives in a subdirectory
        (e.g. 'dbt-project/') but the solution file_path doesn't include it.
        Checks the first solution's path; if not found, detects the dbt prefix.

        Returns:
            Dict mapping solution.file_path → repo path (possibly prefixed).
        """
        if not solutions:
            return {}

        first = solutions[0]
        if not first.file_path:
            return {s.file_path: s.file_path for s in solutions if s.file_path}

        # Check if the stored path already works
        try:
            self._github.get_file_content(repo, first.file_path)
            return {s.file_path: s.file_path for s in solutions if s.file_path}
        except GitHubFileNotFoundError:
            pass

        # Detect dbt subdirectory prefix
        prefix = self._detect_dbt_prefix(repo)
        if prefix:
            result: dict[str, str] = {}
            for s in solutions:
                if s.file_path:
                    if s.file_path.startswith(f"{prefix}/"):
                        result[s.file_path] = s.file_path
                    else:
                        result[s.file_path] = f"{prefix}/{s.file_path}"
            return result

        # No prefix found — return paths as-is (will fail at drift check)
        return {s.file_path: s.file_path for s in solutions if s.file_path}

    def _detect_dbt_prefix(self, repo: str) -> str:
        """Detect if dbt_project.yml lives in a subdirectory.

        Returns the subdirectory name (e.g. 'dbt-project') or empty string.
        """
        try:
            self._github.get_file_content(repo, "dbt_project.yml")
            return ""
        except GitHubFileNotFoundError:
            pass

        try:
            entries = self._github.get_directory_listing(repo, "")
            for entry in entries:
                if "." in entry.split("/")[-1]:
                    continue
                try:
                    self._github.get_file_content(repo, f"{entry}/dbt_project.yml")
                    logger.info("Detected dbt prefix '%s/' in %s", entry, repo)
                    return entry
                except GitHubFileNotFoundError:
                    continue
        except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError) as exc:
            logger.warning("Could not detect dbt prefix in %s: %s", repo, exc)

        return ""


def _generate_branch_name(opportunity: Opportunity) -> str:
    """Generate a unique branch name from an opportunity.

    Format: governor/{opp_type_slug}/{table_slug}-{short_uuid}
    """
    opp_slug = _slugify(opportunity.opportunity_type)
    table_slug = _slugify(opportunity.affected_table.split(".")[-1])
    short_id = uuid.uuid4().hex[:8]
    return f"governor/{opp_slug}/{table_slug}-{short_id}"


def _slugify(text: str) -> str:
    """Convert text to a URL-safe slug."""
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


def _build_pr_title(opportunity: Opportunity, solutions: list[Solution]) -> str:
    """Build a short PR title."""
    model = opportunity.dbt_model_name or opportunity.affected_table.split(".")[-1]
    return f"perf({model}): optimize to reduce BigQuery costs"


def _build_commit_message(opportunity: Opportunity, solutions: list[Solution]) -> str:
    """Build a Conventional Commits formatted commit message.

    Includes: type/scope/description, Problem, Solution, Rationale,
    Expected outcome, Risk, and Governor-Opportunity footer.
    """
    model = opportunity.dbt_model_name or opportunity.affected_table.split(".")[-1]
    first_sol = solutions[0]

    parts = [
        f"perf({model}): optimize {opportunity.affected_table} to reduce BigQuery costs",
        "",
        f"Problem: {opportunity.explanation}",
        "",
        f"Solution: {first_sol.explanation}",
        "",
        (
            f"Rationale: Governor detected {opportunity.opportunity_type} on "
            f"{opportunity.affected_table} with severity {opportunity.severity_score}/100."
        ),
        "",
        f"Expected outcome: {format_usd(opportunity.expected_savings)}/month savings",
        "",
        f"Risk: {first_sol.risk_level} \u2014 {first_sol.risk_justification}",
        "",
        f"Governor-Opportunity: {opportunity.id}",
    ]
    return "\n".join(parts)


def _build_pr_description(opportunity: Opportunity, solutions: list[Solution]) -> str:
    """Build a markdown PR description with Governor branding."""
    first_sol = solutions[0]

    file_list = "\n".join(
        f"- `{sol.file_path}` — {sol.change_type or 'change'}"
        for sol in solutions
        if sol.file_path
    )

    # Risk emoji
    risk_emoji = {
        "low": "\U0001f7e2",
        "medium": "\U0001f7e1",
        "high": "\U0001f534",
    }.get(first_sol.risk_level, "")

    # LLM metadata from the solution job (if available via relationship)
    llm_section = ""
    job = getattr(first_sol, "solution_job", None)
    if job and job.llm_model:
        tokens = ""
        if job.prompt_tokens is not None and job.completion_tokens is not None:
            tokens = (
                f" \u00b7 tokens: {job.prompt_tokens:,} / {job.completion_tokens:,}"
            )
        latency = ""
        if job.llm_latency_ms is not None:
            latency_s = job.llm_latency_ms / 1000
            latency = f" \u00b7 latency: {latency_s:.1f}s"
        llm_section = (
            f"\n### Generation\n- **Model**: `{job.llm_model}`{tokens}{latency}\n"
        )

    # Trust verification section (spec 030)
    trust_section = _build_trust_section(solutions)

    return f"""## Governor Cost Optimization

> This pull request was auto-generated by Governor and requires
> human review before merging.

### Opportunity
| | |
|---|---|
| **Type** | {opportunity.opportunity_type} |
| **Table** | `{opportunity.affected_table}` |
| **dbt Model** | `{opportunity.dbt_model_name or "n/a"}` |
| **Severity** | {opportunity.severity_score}/100 |
| **Expected Savings** | {format_usd(opportunity.expected_savings)}/month |

### Explanation
{opportunity.explanation}

### Solution
{first_sol.explanation}

### Files Changed
{file_list}

### Risk Assessment
{risk_emoji} **{first_sol.risk_level.upper()}**: {first_sol.risk_justification}
{llm_section}{trust_section}
---
*Generated by Governor \u00b7 Opportunity: `{opportunity.id}`*"""


def _get_trust_tier(solutions: list[Solution]) -> str:
    """Get the aggregate trust tier across solutions (most cautious wins)."""
    tier_order = {"guaranteed_safe": 0, "validated": 1, "requires_review": 2}
    tiers = [getattr(s, "trust_tier", None) or "requires_review" for s in solutions]
    return max(tiers, key=lambda t: tier_order.get(t, 2))


def _build_trust_section(solutions: list[Solution]) -> str:
    """Build the trust verification section for PR description."""
    tier = _get_trust_tier(solutions)

    tier_labels = {
        "guaranteed_safe": "\U0001f7e2 **Guaranteed Safe** — Template-based deterministic change",
        "validated": "\U0001f7e2 **Validated** — Structural analysis confirms additive-only changes",
        "requires_review": "\U0001f7e1 **Requires Review** — Changes could not be fully verified",
    }
    tier_label = tier_labels.get(tier, tier_labels["requires_review"])

    warning = ""
    if tier == "requires_review":
        warning = (
            "\n> **\u26a0\ufe0f Warning**: This solution has not been fully verified by "
            "Governor's structural analysis. Please review all changes carefully "
            "before merging. The changes may include modifications that could not "
            "be automatically classified as safe.\n"
        )

    return f"\n### Trust Verification\n{tier_label}\n{warning}"


def _is_requires_review(solutions: list[Solution]) -> bool:
    """Check if any solution requires review (forces draft PR)."""
    return _get_trust_tier(solutions) == "requires_review"
