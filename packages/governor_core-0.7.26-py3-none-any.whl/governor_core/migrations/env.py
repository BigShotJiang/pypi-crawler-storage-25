from __future__ import annotations

from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from governor_core.core.config import get_settings  # noqa: E402
from governor_core.db.base import Base  # noqa: E402

# Import engine-owned models explicitly so Alembic autogenerate sees them.
# (``_import_core_models()`` in db.base also does this, but explicit is clearer.)
from governor_core.configurations import models as _cfg  # noqa: F401 E402
from governor_core.opportunities import models as _opp  # noqa: F401 E402
from governor_core.pullrequests import models as _pr  # noqa: F401 E402
from governor_core.shadow import models as _shadow  # noqa: F401 E402
from governor_core.solutions import models as _sol  # noqa: F401 E402
from governor_core.sync import models as _sync  # noqa: F401 E402

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name, disable_existing_loggers=False)

settings = get_settings()
config.set_main_option("sqlalchemy.url", settings.database_url)

target_metadata = Base.metadata

# Tables owned by governor-web. Alembic autogenerate in the core env
# must NEVER touch these (they are managed by packages/web/alembic.ini).
_WEB_OWNED_TABLES = frozenset(
    {
        "users",
        "roles",
        "user_roles",
        "sessions",
        "audit_events",
        "password_reset_tokens",
        "invitations",
        "notifications",
        "setup_state",
        "organisation_settings",
        "verification_runs",
        "verification_checks",
        "apscheduler_jobs",
    }
)


def include_object(object, name, type_, reflected, compare_to):
    """Exclude web-owned tables and APScheduler from core autogenerate."""
    if type_ == "table" and name in _WEB_OWNED_TABLES:
        return False
    return True


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        include_object=include_object,
        version_table="alembic_core_version",
    )

    with context.begin_transaction():
        context.run_migrations()


def _rename_legacy_version_table(connection) -> None:
    """Rename ``alembic_version`` → ``alembic_core_version`` on existing DBs.

    Before spec 120 (the monorepo split) the legacy Alembic chain tracked its
    revision in the default ``alembic_version`` table. Post-split the core
    stream uses ``alembic_core_version`` instead. When a pre-split database
    is first upgraded against the new config, Alembic sees no
    ``alembic_core_version`` table, creates one empty, then tries to replay
    the entire chain from scratch — which fails on ``CREATE TABLE roles``
    because the tables already exist.

    This runs BEFORE any migration and preserves the existing revision
    pointer by renaming the table. Idempotent: the rename only fires when
    the legacy table exists *and* the new name doesn't.

    SQLite is skipped — fresh CLI installs create ``alembic_core_version``
    directly via ``Base.metadata.create_all`` + stamp head (governor_cli.state).
    """
    dialect_name = connection.dialect.name
    if dialect_name == "sqlite":
        return

    if dialect_name != "postgresql":
        # Other dialects: best-effort via information_schema.
        return

    from sqlalchemy import text

    has_legacy = connection.execute(
        text(
            "SELECT to_regclass('public.alembic_version') IS NOT NULL"
        )
    ).scalar()
    has_new = connection.execute(
        text(
            "SELECT to_regclass('public.alembic_core_version') IS NOT NULL"
        )
    ).scalar()

    if has_legacy and not has_new:
        connection.execute(
            text("ALTER TABLE alembic_version RENAME TO alembic_core_version")
        )


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        # Bootstrap: if this is an existing pre-split database, rename the
        # legacy alembic_version table before Alembic inspects it.
        _rename_legacy_version_table(connection)
        connection.commit()

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            include_object=include_object,
            version_table="alembic_core_version",
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
