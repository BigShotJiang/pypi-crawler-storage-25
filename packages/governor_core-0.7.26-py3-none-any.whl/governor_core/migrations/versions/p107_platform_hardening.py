"""Platform hardening: new tables and extended columns (spec 107).

- New tables: password_reset_tokens, invitations, notifications
- Extended audit_events: details (JSONB), target_entity_type, target_entity_id, widen event_type
- Extended sync_operations: retry_count, failure_reason, last_error
- Extended solution_jobs: failure_reason

Revision ID: p107_hardening01
Revises: s1t2u3v4w5x6
Create Date: 2026-04-16

"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "p107_hardening01"
down_revision = "s1t2u3v4w5x6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # --- New tables ---

    op.create_table(
        "password_reset_tokens",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False, index=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
        ),
    )

    op.create_table(
        "invitations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column(
            "invited_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        sa.Column("token_hash", sa.String(255), nullable=False, index=True),
        sa.Column("role", sa.String(32), nullable=False, server_default="viewer"),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("accepted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
        ),
    )

    op.create_table(
        "notifications",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("link", sa.String(512), nullable=True),
        sa.Column("read_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
        ),
    )

    # --- Extend audit_events ---

    op.alter_column(
        "audit_events",
        "event_type",
        type_=sa.String(64),
        existing_type=sa.String(32),
    )
    op.add_column(
        "audit_events",
        sa.Column("details", postgresql.JSONB(), nullable=True),
    )
    op.add_column(
        "audit_events",
        sa.Column("target_entity_type", sa.String(64), nullable=True),
    )
    op.add_column(
        "audit_events",
        sa.Column("target_entity_id", sa.String(36), nullable=True),
    )

    # --- Extend sync_operations ---

    op.add_column(
        "sync_operations",
        sa.Column("retry_count", sa.Integer(), nullable=False, server_default="0"),
    )
    op.add_column(
        "sync_operations",
        sa.Column("failure_reason", sa.String(64), nullable=True),
    )
    op.add_column(
        "sync_operations",
        sa.Column("last_error", sa.Text(), nullable=True),
    )

    # --- Extend solution_jobs ---

    op.add_column(
        "solution_jobs",
        sa.Column("failure_reason", sa.String(64), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("solution_jobs", "failure_reason")
    op.drop_column("sync_operations", "last_error")
    op.drop_column("sync_operations", "failure_reason")
    op.drop_column("sync_operations", "retry_count")
    op.drop_column("audit_events", "target_entity_id")
    op.drop_column("audit_events", "target_entity_type")
    op.drop_column("audit_events", "details")
    op.alter_column(
        "audit_events",
        "event_type",
        type_=sa.String(32),
        existing_type=sa.String(64),
    )
    op.drop_table("notifications")
    op.drop_table("invitations")
    op.drop_table("password_reset_tokens")
