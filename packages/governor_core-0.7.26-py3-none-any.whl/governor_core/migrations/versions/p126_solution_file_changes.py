"""Add file_changes JSONB to solutions.

Revision ID: p126_solution_file_changes
Revises: p124_auto_shadow
Create Date: 2026-04-22

A single logical solution can now span multiple files (e.g. enforcing
``require_partition_filter=true`` on an upstream model + patching every
downstream model's WHERE clause). ``file_changes`` stores the ordered list;
the legacy single-file columns (``file_path``, ``before_content``,
``after_content``, ``change_type``) remain populated with the primary
(first) entry so cloud readers that haven't been updated keep working.

"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "p126_solution_file_changes"
down_revision = "p124_auto_shadow"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "solutions",
        sa.Column(
            "file_changes",
            postgresql.JSONB().with_variant(sa.JSON(), "sqlite"),
            nullable=True,
        ),
    )


def downgrade() -> None:
    op.drop_column("solutions", "file_changes")
