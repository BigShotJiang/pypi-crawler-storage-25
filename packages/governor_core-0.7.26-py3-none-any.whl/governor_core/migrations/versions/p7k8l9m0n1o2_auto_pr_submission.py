"""Auto-PR submission: organisation settings, per-project override, system user.

Revision ID: p7k8l9m0n1o2
Revises: o6j7k8l9m0n1
Create Date: 2026-02-19
"""

import uuid

from alembic import op
import sqlalchemy as sa

# Sentinel password hash for the system user. The bytes below are a valid
# bcrypt-shaped string that matches no plausible password — the user can
# never authenticate. Pre-split this migration imported ``bcrypt`` and
# generated a random hash; the import was removed during spec 120 to keep
# ``governor-core`` free of web-only dependencies.
_SYSTEM_USER_SENTINEL_HASH = (
    "$2b$12$" + "0" * 22 + "." * 31
)[:60]

revision = "p7k8l9m0n1o2"
down_revision = "o6j7k8l9m0n1"
branch_labels = None
depends_on = None

SYSTEM_USER_ID = "00000000-0000-0000-0000-000000000001"
SYSTEM_USER_EMAIL = "system@governor.internal"


def upgrade() -> None:
    # 1. Create organisation_settings table
    op.create_table(
        "organisation_settings",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("setting_key", sa.String(128), unique=True, nullable=False),
        sa.Column("setting_value", sa.String(512), nullable=False),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=True,
        ),
    )

    # 2. Add auto_pr_trust_tier column to manifest_configurations
    op.add_column(
        "manifest_configurations",
        sa.Column("auto_pr_trust_tier", sa.String(16), nullable=True),
    )
    # CHECK constraint (skip for SQLite)
    bind = op.get_bind()
    if bind.dialect.name != "sqlite":
        op.create_check_constraint(
            "ck_mc_auto_pr_trust_tier",
            "manifest_configurations",
            "auto_pr_trust_tier IN ('disabled', 'guaranteed_safe', 'validated', 'requires_review')",
        )

    # 3. Insert system sentinel user
    op.execute(
        sa.text(
            "INSERT INTO users (id, email, display_name, password_hash, status, theme_preference, created_at, updated_at) "
            "VALUES (:id, :email, :display_name, :password_hash, :status, :theme_preference, NOW(), NOW())"
        ).bindparams(
            id=SYSTEM_USER_ID,
            email=SYSTEM_USER_EMAIL,
            display_name="Governor Bot",
            password_hash=_SYSTEM_USER_SENTINEL_HASH,
            status="system",
            theme_preference="auto",
        )
    )

    # 4. Insert initial org setting row
    op.execute(
        sa.text(
            "INSERT INTO organisation_settings (id, setting_key, setting_value, updated_at) "
            "VALUES (:id, :key, :value, NOW())"
        ).bindparams(
            id=str(uuid.uuid4()),
            key="auto_pr_trust_tier_threshold",
            value="disabled",
        )
    )


def downgrade() -> None:
    # Remove org setting
    op.execute(
        sa.text(
            "DELETE FROM organisation_settings WHERE setting_key = 'auto_pr_trust_tier_threshold'"
        )
    )

    # Remove system user
    op.execute(
        sa.text("DELETE FROM users WHERE id = :id").bindparams(id=SYSTEM_USER_ID)
    )

    # Remove auto_pr_trust_tier column
    bind = op.get_bind()
    if bind.dialect.name != "sqlite":
        op.drop_constraint(
            "ck_mc_auto_pr_trust_tier", "manifest_configurations", type_="check"
        )
    op.drop_column("manifest_configurations", "auto_pr_trust_tier")

    # Drop organisation_settings table
    op.drop_table("organisation_settings")
