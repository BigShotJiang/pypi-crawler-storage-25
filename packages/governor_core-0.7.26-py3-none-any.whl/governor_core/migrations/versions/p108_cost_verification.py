"""Add cost_verification_runs table (spec 108).

Revision ID: p108_cost_verify01
Revises: p107_hardening01
Create Date: 2026-04-16

"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "p108_cost_verify01"
down_revision = "p107_hardening01"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "cost_verification_runs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "opportunity_id",
            sa.String(36),
            sa.ForeignKey("opportunities.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        ),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "solution_id",
            sa.String(36),
            sa.ForeignKey("solutions.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column(
            "baseline_sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("status", sa.String(16), nullable=False, server_default="queued"),
        sa.Column("dbt_selector", sa.String(255), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("baseline_costs", postgresql.JSONB(), nullable=True),
        sa.Column("verification_costs", postgresql.JSONB(), nullable=True),
        sa.Column("cost_comparison", postgresql.JSONB(), nullable=True),
        sa.Column("net_delta_usd", sa.Numeric(10, 4), nullable=True),
        sa.Column("model_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
        ),
    )


def downgrade() -> None:
    op.drop_table("cost_verification_runs")
