"""Add build_logs column to shadow_validation_runs (spec 110 follow-up).

Stores the captured stdout from both baseline and shadow dbt builds so the
opportunity-detail page can re-display the logs after a successful run
(the live SSE terminal is only available during the run itself).

Revision ID: p111_shadow_logs
Revises: p110_shadow_valid
Create Date: 2026-04-17

"""

import sqlalchemy as sa
from alembic import op

revision = "p111_shadow_logs"
down_revision = "p110_shadow_valid"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "shadow_validation_runs",
        sa.Column("build_logs", sa.Text(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("shadow_validation_runs", "build_logs")
