"""Add min_solution_cost_usd to manifest_configurations.

Revision ID: s1t2u3v4w5x6
Revises: r9s0t1u2v3w4
Create Date: 2026-04-15
"""

from alembic import op
import sqlalchemy as sa


revision = "s1t2u3v4w5x6"
down_revision = "r9s0t1u2v3w4"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "min_solution_cost_usd",
            sa.Numeric(precision=12, scale=2),
            nullable=True,
        ),
    )


def downgrade():
    op.drop_column("manifest_configurations", "min_solution_cost_usd")
