"""Spec 120 monorepo split — core split-point.

Renames the legacy ``alembic_version`` table to ``alembic_core_version`` if it
still exists (idempotent on fresh databases). This is the first revision in
the core stream after the split; the parent is the last legacy head so the
historical chain remains linear.

No schema changes are applied to any domain table.
"""

from __future__ import annotations

from alembic import op

revision = "split_120_core"
down_revision = "p111_shadow_logs"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Rename legacy alembic_version table to the new core-owned name.
    # Idempotent: IF EXISTS skips the rename on fresh databases where
    # Alembic will create alembic_core_version itself.
    op.execute("ALTER TABLE IF EXISTS alembic_version RENAME TO alembic_core_version")


def downgrade() -> None:
    op.execute("ALTER TABLE IF EXISTS alembic_core_version RENAME TO alembic_version")
