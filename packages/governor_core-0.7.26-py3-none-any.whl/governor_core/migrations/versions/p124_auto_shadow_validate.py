"""Spec 124: auto-shadow-validation opt-in + trigger provenance.

Adds two columns:
- manifest_configurations.auto_shadow_validate_safe_solutions (default false)
  per-config opt-in; when true the worker auto-enqueues a shadow validation
  for newly-completed low-risk (Safe) solutions.
- shadow_validation_runs.triggered_by (default 'manual')
  provenance marker: 'manual' (user clicked Run Comparison) or 'auto'
  (worker-initiated). Backfills existing rows to 'manual' which is accurate.

No FKs, no data migration, both columns NOT NULL with defaults so the upgrade
is safe on a populated database.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "p124_auto_shadow"
down_revision = "split_120_core"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "auto_shadow_validate_safe_solutions",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )
    op.add_column(
        "shadow_validation_runs",
        sa.Column(
            "triggered_by",
            sa.String(length=16),
            nullable=False,
            server_default="manual",
        ),
    )


def downgrade() -> None:
    op.drop_column("shadow_validation_runs", "triggered_by")
    op.drop_column(
        "manifest_configurations", "auto_shadow_validate_safe_solutions"
    )
