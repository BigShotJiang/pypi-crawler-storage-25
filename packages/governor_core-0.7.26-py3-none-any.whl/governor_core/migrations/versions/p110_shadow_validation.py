"""Add shadow validation tables + configuration + solution columns (spec 110).

Revision ID: p110_shadow_valid
Revises: p108_cost_verify01
Create Date: 2026-04-17

"""

import sqlalchemy as sa
from alembic import op

revision = "p110_shadow_valid"
down_revision = "p108_cost_verify01"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "shadow_validation_runs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "solution_id",
            sa.String(36),
            sa.ForeignKey("solutions.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        ),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        ),
        sa.Column(
            "manifest_version_id",
            sa.String(36),
            sa.ForeignKey("manifest_versions.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("status", sa.String(32), nullable=False, server_default="queued"),
        sa.Column("skipped_reason", sa.String(64), nullable=True),
        sa.Column("failure_reason", sa.String(64), nullable=True),
        sa.Column("cascade_size", sa.Integer, nullable=False, server_default="0"),
        sa.Column(
            "estimated_baseline_cost_usd",
            sa.Numeric(10, 4),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "budget_cap_usd", sa.Numeric(10, 4), nullable=False, server_default="10"
        ),
        sa.Column("cascade_cap", sa.Integer, nullable=False, server_default="20"),
        sa.Column(
            "timeout_seconds", sa.Integer, nullable=False, server_default="1800"
        ),
        sa.Column("baseline_started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("baseline_completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("shadow_started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("shadow_completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("total_baseline_bytes", sa.BigInteger, nullable=True),
        sa.Column("total_baseline_slot_ms", sa.BigInteger, nullable=True),
        sa.Column("total_baseline_cost_usd", sa.Numeric(12, 4), nullable=True),
        sa.Column("total_shadow_bytes", sa.BigInteger, nullable=True),
        sa.Column("total_shadow_slot_ms", sa.BigInteger, nullable=True),
        sa.Column("total_shadow_cost_usd", sa.Numeric(12, 4), nullable=True),
        sa.Column("bytes_delta_pct", sa.Numeric(8, 4), nullable=True),
        sa.Column("cost_delta_usd", sa.Numeric(12, 4), nullable=True),
        sa.Column("solution_id_hex12", sa.String(12), nullable=False, index=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index(
        "ix_svr_config_status",
        "shadow_validation_runs",
        ["config_id", "status"],
    )
    op.create_index(
        "uq_svr_single_active_per_config",
        "shadow_validation_runs",
        ["config_id"],
        unique=True,
        postgresql_where=sa.text("status IN ('queued', 'running')"),
        sqlite_where=sa.text("status IN ('queued', 'running')"),
    )

    op.create_table(
        "shadow_model_executions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "shadow_run_id",
            sa.String(36),
            sa.ForeignKey("shadow_validation_runs.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        ),
        sa.Column("phase", sa.String(16), nullable=False),
        sa.Column("model_name", sa.String(512), nullable=False),
        sa.Column("materialized_table_name", sa.String(1024), nullable=False),
        sa.Column("bq_job_id", sa.String(1024), nullable=True),
        sa.Column("bytes_processed", sa.BigInteger, nullable=True),
        sa.Column("slot_ms", sa.BigInteger, nullable=True),
        sa.Column("duration_ms", sa.BigInteger, nullable=True),
        sa.Column("row_count", sa.BigInteger, nullable=True),
        sa.Column("cost_usd", sa.Numeric(12, 4), nullable=True),
        sa.Column("error_type", sa.String(64), nullable=True),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.CheckConstraint(
            "phase IN ('baseline', 'shadow')", name="ck_sme_phase"
        ),
    )
    op.create_index(
        "uq_sme_run_phase_model",
        "shadow_model_executions",
        ["shadow_run_id", "phase", "model_name"],
        unique=True,
    )

    # manifest_configurations additions
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "shadow_validation_enabled",
            sa.Boolean,
            nullable=False,
            server_default=sa.text("false"),
        ),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "shadow_budget_usd",
            sa.Numeric(10, 4),
            nullable=False,
            server_default="10",
        ),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "shadow_cascade_cap", sa.Integer, nullable=False, server_default="20"
        ),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "shadow_timeout_seconds",
            sa.Integer,
            nullable=False,
            server_default="1800",
        ),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "shadow_reconciliation_threshold_hours",
            sa.Integer,
            nullable=False,
            server_default="24",
        ),
    )

    # solutions additions
    op.add_column(
        "solutions",
        sa.Column(
            "shadow_validation_run_id",
            sa.String(36),
            sa.ForeignKey("shadow_validation_runs.id", ondelete="SET NULL"),
            nullable=True,
        ),
    )
    op.add_column(
        "solutions",
        sa.Column(
            "applied_locally_at", sa.DateTime(timezone=True), nullable=True
        ),
    )
    op.add_column(
        "solutions",
        sa.Column("local_apply_resolution", sa.String(64), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("solutions", "local_apply_resolution")
    op.drop_column("solutions", "applied_locally_at")
    op.drop_column("solutions", "shadow_validation_run_id")

    op.drop_column(
        "manifest_configurations", "shadow_reconciliation_threshold_hours"
    )
    op.drop_column("manifest_configurations", "shadow_timeout_seconds")
    op.drop_column("manifest_configurations", "shadow_cascade_cap")
    op.drop_column("manifest_configurations", "shadow_budget_usd")
    op.drop_column("manifest_configurations", "shadow_validation_enabled")

    op.drop_index("uq_sme_run_phase_model", table_name="shadow_model_executions")
    op.drop_table("shadow_model_executions")

    op.drop_index("uq_svr_single_active_per_config", table_name="shadow_validation_runs")
    op.drop_index("ix_svr_config_status", table_name="shadow_validation_runs")
    op.drop_table("shadow_validation_runs")
