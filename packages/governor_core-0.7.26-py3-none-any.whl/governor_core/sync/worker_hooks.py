"""Hooks the sync/solution worker calls out to web-only subsystems.

The worker lives in ``governor_core`` but some side-effects (writing
audit events, reading organisation settings, identifying the sentinel
user) are web-shell concerns. Rather than import web modules from core,
the worker accepts a ``WorkerHooks`` instance and delegates. The default
``NullHooks`` makes all operations no-ops; ``governor_web`` provides a
real implementation wired up at startup.
"""

from __future__ import annotations

from typing import Any, Protocol

from sqlalchemy.orm import Session


class WorkerHooks(Protocol):
    """Optional web-side extensions the worker delegates to."""

    def get_auto_pr_trust_tier_threshold(self, db: Session) -> str:
        """Return the configured auto-PR trust tier threshold, or ``'disabled'``."""
        ...

    def find_system_user_id(self, db: Session) -> str | None:
        """Return the sentinel system user's id, or None if not configured."""
        ...

    def record_audit_event(
        self,
        db: Session,
        *,
        event_type: str,
        outcome: str,
        user_id: str | None = None,
        user_agent: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Write an audit event, if the deployment supports auditing."""
        ...


class NullHooks:
    """Default no-op ``WorkerHooks`` implementation.

    Used by the CLI and any deployment that doesn't need an audit log.
    """

    def get_auto_pr_trust_tier_threshold(self, db: Session) -> str:
        return "disabled"

    def find_system_user_id(self, db: Session) -> str | None:
        return None

    def record_audit_event(
        self,
        db: Session,
        *,
        event_type: str,
        outcome: str,
        user_id: str | None = None,
        user_agent: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        # No-op. Web provides a real implementation.
        return None
