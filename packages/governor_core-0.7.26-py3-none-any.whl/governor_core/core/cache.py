"""In-memory TTL cache utility for Governor.

Provides a simple key-based TTL cache with invalidation.
Disabled in test environment to ensure test isolation.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Callable


class TTLCache:
    """Thread-safe in-memory cache with per-key TTL expiration."""

    def __init__(self, default_ttl: int = 60, enabled: bool = True) -> None:
        self._default_ttl = default_ttl
        self._enabled = enabled
        self._store: dict[str, tuple[Any, float]] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Any | None:
        if not self._enabled:
            return None
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, expires_at = entry
            if time.monotonic() > expires_at:
                del self._store[key]
                return None
            return value

    def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        if not self._enabled:
            return
        effective_ttl = ttl if ttl is not None else self._default_ttl
        with self._lock:
            self._store[key] = (value, time.monotonic() + effective_ttl)

    def get_or_set(
        self, key: str, factory: Callable[[], Any], ttl: int | None = None
    ) -> Any:
        """Get a cached value, or compute and cache it using factory."""
        cached = self.get(key)
        if cached is not None:
            return cached
        value = factory()
        self.set(key, value, ttl)
        return value

    def invalidate(self, key: str) -> None:
        with self._lock:
            self._store.pop(key, None)

    def invalidate_prefix(self, prefix: str) -> None:
        """Invalidate all keys starting with the given prefix."""
        with self._lock:
            keys_to_remove = [k for k in self._store if k.startswith(prefix)]
            for k in keys_to_remove:
                del self._store[k]

    def clear(self) -> None:
        with self._lock:
            self._store.clear()


# Global app cache instance — initialized by create_app()
app_cache = TTLCache(default_ttl=60, enabled=True)


def get_cache() -> TTLCache:
    return app_cache


def configure_cache(enabled: bool = True, default_ttl: int = 60) -> None:
    global app_cache
    app_cache = TTLCache(default_ttl=default_ttl, enabled=enabled)
