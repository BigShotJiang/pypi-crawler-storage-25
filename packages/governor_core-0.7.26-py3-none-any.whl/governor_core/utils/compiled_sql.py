"""Compiled SQL utilities for extracting and patching compiled_code from dbt manifests."""

from __future__ import annotations

import difflib
import logging

from sqlalchemy.orm import Session

logger = logging.getLogger("app.utils.compiled_sql")


def get_compiled_sql(
    db: Session,
    manifest_version_id: str | None,
    dbt_model_name: str | None,
) -> str | None:
    """Retrieve compiled_code from the manifest for a given dbt model.

    Args:
        db: Database session.
        manifest_version_id: ID of the ManifestVersion to query.
        dbt_model_name: Name of the dbt model (e.g. 'stg_gsod_weather').

    Returns:
        The compiled SQL string, or None if not found.
    """
    if not manifest_version_id or not dbt_model_name:
        return None

    from governor_core.sync.models import ManifestVersion

    mv = (
        db.query(ManifestVersion)
        .filter(ManifestVersion.id == manifest_version_id)
        .one_or_none()
    )
    if not mv or not mv.content:
        return None

    nodes = mv.content.get("nodes", {})
    for _node_key, node_data in nodes.items():
        if not isinstance(node_data, dict):
            continue
        if node_data.get("name") == dbt_model_name:
            return node_data.get("compiled_code")

    return None


def apply_diff_to_compiled(
    before_content: str,
    after_content: str,
    compiled_code: str,
) -> str | None:
    """Apply the diff between before/after dbt source onto compiled SQL.

    This works because Governor's changes are either:
    - Config-only (cluster_by, partition_by): these compile to nothing,
      so the compiled SQL is unchanged.
    - Plain SQL changes (WHERE, JOIN): identical in raw and compiled.

    Uses difflib.SequenceMatcher to identify changed blocks in the raw
    source, then applies those same insertions/deletions/replacements
    to the compiled code by matching context lines.

    Args:
        before_content: Original dbt source (with Jinja).
        after_content: Modified dbt source (with Jinja).
        compiled_code: Original compiled SQL from manifest.

    Returns:
        Modified compiled SQL, or None if the diff cannot be applied.
    """
    before_content = _strip_config_blocks(before_content)
    after_content = _strip_config_blocks(after_content)

    before_lines = [
        line for line in before_content.splitlines() if not _is_config_line(line)
    ]
    after_lines = [
        line for line in after_content.splitlines() if not _is_config_line(line)
    ]

    sm = difflib.SequenceMatcher(None, before_lines, after_lines)
    opcodes = sm.get_opcodes()
    compiled_lines = compiled_code.splitlines()
    has_sql_changes = False

    for tag, i1, i2, j1, j2 in opcodes:
        if tag == "equal":
            continue

        has_sql_changes = True
        removed_lines = before_lines[i1:i2]
        added_lines = after_lines[j1:j2]
        prev_context = before_lines[i1 - 1] if i1 > 0 else None
        next_context = before_lines[i2] if i2 < len(before_lines) else None

        if tag in {"replace", "delete"}:
            start = _find_subsequence(
                compiled_lines,
                removed_lines,
                prev_context=prev_context,
                next_context=next_context,
            )
            if start is None:
                logger.debug(
                    "Cannot apply diff to compiled SQL: removed block not found"
                )
                return None

            compiled_lines[start : start + len(removed_lines)] = added_lines
            continue

        if tag == "insert":
            insert_at = _find_insertion_index(
                compiled_lines,
                prev_context=prev_context,
                next_context=next_context,
            )
            if insert_at is None:
                logger.debug(
                    "Cannot apply diff to compiled SQL: insertion context not found"
                )
                return None

            compiled_lines[insert_at:insert_at] = added_lines

    if not has_sql_changes:
        return compiled_code

    return "\n".join(compiled_lines)


def _strip_config_blocks(sql: str) -> str:
    """Remove full dbt ``{{ config(...) }}`` blocks before diffing."""
    from governor_core.solutions.templates.config_parser import parse_config_block

    stripped_sql = sql
    while True:
        block = parse_config_block(stripped_sql)
        if block is None:
            return stripped_sql
        stripped_sql = stripped_sql[: block.start] + stripped_sql[block.end :]


def _is_config_line(line: str) -> bool:
    """Check if a line is part of a dbt config/Jinja block."""
    stripped = line.strip()
    return (
        stripped.startswith("{{")
        or stripped.startswith("}}")
        or stripped.startswith("{%")
        or stripped.startswith("%}")
        or stripped.startswith("{#")
        or stripped.startswith("#}")
        or "config(" in stripped
        or stripped == ""
    )


def _find_subsequence(
    haystack: list[str],
    needle: list[str],
    *,
    prev_context: str | None,
    next_context: str | None,
) -> int | None:
    """Find a contiguous block, preferring matches with stable neighbors."""
    if not needle:
        return None

    needle_len = len(needle)
    for require_context in (True, False):
        for idx in range(len(haystack) - needle_len + 1):
            if haystack[idx : idx + needle_len] != needle:
                continue

            if require_context and prev_context is not None:
                if idx == 0 or haystack[idx - 1] != prev_context:
                    continue

            if require_context and next_context is not None:
                next_idx = idx + needle_len
                if next_idx >= len(haystack) or haystack[next_idx] != next_context:
                    continue

            return idx

    return None


def _find_insertion_index(
    compiled_lines: list[str],
    *,
    prev_context: str | None,
    next_context: str | None,
) -> int | None:
    """Find the insertion point using the nearest unchanged context lines."""
    if prev_context is not None and next_context is not None:
        for idx in range(len(compiled_lines) - 1):
            if (
                compiled_lines[idx] == prev_context
                and compiled_lines[idx + 1] == next_context
            ):
                return idx + 1

    if prev_context is not None:
        for idx, line in enumerate(compiled_lines):
            if line == prev_context:
                return idx + 1

    if next_context is not None:
        for idx, line in enumerate(compiled_lines):
            if line == next_context:
                return idx

    if not compiled_lines:
        return 0

    return None
