"""Column lookup helper for validating cluster_by/partition_by suggestions.

Queries TableColumnMetadata to get real column names from INFORMATION_SCHEMA.COLUMNS
for a given dbt manifest node's underlying BigQuery table.
"""

from __future__ import annotations

import logging
from collections.abc import Callable

from sqlalchemy.orm import Session

from governor_core.sync.models import TableColumnMetadata

logger = logging.getLogger("app.dbt.column_lookup")


def make_column_lookup(
    db: Session,
    config_id: str,
) -> Callable[[dict], set[str] | None]:
    """Create a column lookup callable for use with analyze_upstream().

    Returns a function that takes a manifest node dict and returns a set
    of lowercase column names from INFORMATION_SCHEMA, or None if no
    column data exists for that table.

    The lookup caches results per (dataset, table) to avoid repeated queries.

    Args:
        db: SQLAlchemy session
        config_id: ManifestConfiguration ID to scope the query

    Returns:
        Callable that maps manifest node → set of column names or None
    """
    cache: dict[tuple[str, str], set[str] | None] = {}

    def lookup(node: dict) -> set[str] | None:
        # Extract BigQuery table coordinates from manifest node
        dataset = node.get("schema", "")
        table_name = node.get("alias") or node.get("name", "")

        if not dataset or not table_name:
            return None

        cache_key = (dataset.lower(), table_name.lower())
        if cache_key in cache:
            return cache[cache_key]

        rows = (
            db.query(TableColumnMetadata.column_name)
            .filter(
                TableColumnMetadata.config_id == config_id,
                TableColumnMetadata.dataset_name == dataset,
                TableColumnMetadata.table_name == table_name,
            )
            .all()
        )

        if not rows:
            logger.debug(
                "No column metadata for %s.%s (config %s)",
                dataset,
                table_name,
                config_id,
            )
            cache[cache_key] = None
            return None

        columns = {row[0].lower() for row in rows}
        cache[cache_key] = columns
        logger.debug(
            "Resolved %d columns for %s.%s from INFORMATION_SCHEMA",
            len(columns),
            dataset,
            table_name,
        )
        return columns

    return lookup


def make_column_type_lookup(
    db: Session,
    config_id: str,
) -> Callable[[dict], dict[str, str] | None]:
    """Create a column type lookup callable.

    Returns a function that takes a manifest node dict and returns a dict
    mapping lowercase column names to their BigQuery data types (e.g.
    ``{"strike_date": "TIMESTAMP", "id": "STRING"}``), or ``None`` if no
    column metadata is available for that table.

    Args:
        db: SQLAlchemy session
        config_id: ManifestConfiguration ID to scope the query

    Returns:
        Callable that maps manifest node → {column_name: data_type} or None
    """
    cache: dict[tuple[str, str], dict[str, str] | None] = {}

    def lookup(node: dict) -> dict[str, str] | None:
        dataset = node.get("schema", "")
        table_name = node.get("alias") or node.get("name", "")

        if not dataset or not table_name:
            return None

        cache_key = (dataset.lower(), table_name.lower())
        if cache_key in cache:
            return cache[cache_key]

        rows = (
            db.query(TableColumnMetadata.column_name, TableColumnMetadata.data_type)
            .filter(
                TableColumnMetadata.config_id == config_id,
                TableColumnMetadata.dataset_name == dataset,
                TableColumnMetadata.table_name == table_name,
            )
            .all()
        )

        if not rows:
            cache[cache_key] = None
            return None

        col_types = {row[0].lower(): row[1].upper() for row in rows}
        cache[cache_key] = col_types
        logger.debug(
            "Resolved %d column types for %s.%s from INFORMATION_SCHEMA",
            len(col_types),
            dataset,
            table_name,
        )
        return col_types

    return lookup


def resolve_bq_partition_data_type(bq_data_type: str) -> tuple[str, str | None]:
    """Map a BigQuery data type to the dbt partition_by data_type and granularity.

    BigQuery only accepts these partition expressions:
    - DATE column → data_type="date"
    - TIMESTAMP column → data_type="timestamp", granularity="day"
    - DATETIME column → data_type="datetime", granularity="day"
    - INT64 column → data_type="int64" (range partitioning)

    Args:
        bq_data_type: The BigQuery data type string (e.g. "TIMESTAMP", "DATE")

    Returns:
        Tuple of (dbt_data_type, granularity_or_none).
        Example: ("timestamp", "day") or ("date", None)
    """
    normalized = bq_data_type.strip().upper()
    if normalized == "DATE":
        return "date", None
    if normalized in ("TIMESTAMP", "TIMESTAMP WITH TIME ZONE"):
        return "timestamp", "day"
    if normalized in ("DATETIME", "DATETIME WITHOUT TIME ZONE"):
        return "datetime", "day"
    if normalized in ("INT64", "INTEGER", "INT", "SMALLINT", "BIGINT", "TINYINT"):
        return "int64", None
    # Default to date — safest for unknown types
    return "date", None
