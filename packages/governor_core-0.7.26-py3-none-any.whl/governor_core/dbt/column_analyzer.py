"""Dead column analysis using dbt manifest and sqlglot.

Two analysis modes:

1. Intra-model analysis (primary):
   Finds columns selected in a CTE that are never referenced by any
   subsequent CTE or the model's final SELECT. Entirely self-contained —
   no downstream models required.

   Algorithm:
     a. For each non-ephemeral model node with at least one CTE.
     b. For each CTE in the WITH clause (in order):
        - Extract visible output column names (alias preferred).
        - Skip if the CTE does SELECT *.
        - Skip if a subsequent CTE or the outer SELECT does SELECT * directly
          FROM this CTE (conservative — all columns treated as used).
        - Collect all column name references from all subsequent CTEs and the
          outer SELECT.
        - Dead columns = output columns not found in the reference set.

2. Cross-model analysis (kept for reference / future hints):
   Identifies columns selected by an upstream model that are never referenced
   by any downstream model child. Requires analysing the full manifest DAG.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from governor_core.solutions.validation.jinja_strip import strip_jinja

logger = logging.getLogger("app.dbt.column_analyzer")


@dataclass
class ColumnAnalysis:
    """Result of dead column analysis for one upstream model."""

    model_unique_id: str
    model_name: str
    affected_table: str  # "project.dataset.table" for opportunity.affected_table
    raw_code: str  # jinja source SQL — used for diff generation
    output_columns: list[str]  # source column names (before aliasing)
    alias_map: dict[str, str]  # { output_name → source_name }
    dead_columns: list[str]  # source names of columns unused by any downstream
    downstream_models: list[str]  # model names whose SQL was analysed
    produces_star: bool  # True if the model itself does SELECT *
    skipped_reason: str | None = None


@dataclass
class CteDeadColumns:
    """Dead columns found in a single CTE of a model."""

    cte_name: str
    dead_columns: list[str]  # output names (alias or bare) never referenced downstream
    all_columns: list[str]  # all output column names from this CTE's SELECT
    dead_column_categories: dict[str, str] = field(default_factory=dict)
    all_column_categories: dict[str, str] = field(default_factory=dict)


@dataclass
class IntraModelAnalysis:
    """Result of intra-model dead column analysis for one model."""

    model_unique_id: str
    model_name: str
    affected_table: str  # "project.dataset.table"
    raw_code: str  # original Jinja SQL — used for template application
    cte_dead_columns: list[CteDeadColumns]  # CTEs that have dead columns


@dataclass
class DeadCteAnalysis:
    """Result of intra-model dead CTE analysis for one model."""

    model_unique_id: str
    model_name: str
    affected_table: str
    raw_code: str
    dead_ctes: list[str]
    total_cte_count: int


@dataclass
class RedundantOrderByAnalysis:
    """Result of intra-model redundant ORDER BY analysis for one model."""

    model_unique_id: str
    model_name: str
    affected_table: str
    raw_code: str
    redundant_order_bys: list[str]
    total_cte_count: int


@dataclass
class UnusedJoinOccurrence:
    """One conservatively removable join inside a CTE."""

    cte_name: str
    join_alias: str
    joined_source_name: str
    join_keys: list[str]


@dataclass
class UnusedJoinAnalysis:
    """Result of intra-model unused join analysis for one model."""

    model_unique_id: str
    model_name: str
    affected_table: str
    raw_code: str
    unused_joins: list[UnusedJoinOccurrence]
    total_join_count: int


@dataclass(frozen=True)
class CteOutputSpec:
    """Visible output metadata for one CTE select expression."""

    output_name: str
    category: str


def analyze_all_intra_model(
    manifest_content: dict,
    min_dead_columns: int = 1,
    excluded_patterns: list[str] | None = None,
) -> list[IntraModelAnalysis]:
    """Analyse all models in the manifest for intra-model dead columns.

    An "intra-model dead column" is a column selected in a CTE within a model's
    SQL that is never referenced by any subsequent CTE or the model's final SELECT.
    This analysis is entirely self-contained — no downstream models are needed.

    Args:
        manifest_content: Parsed manifest.json dict.
        min_dead_columns: Minimum dead columns per CTE to include.
        excluded_patterns: Regex patterns for column names to always treat as used.

    Returns:
        List of IntraModelAnalysis for models that have intra-model dead columns.
    """
    nodes: dict[str, Any] = manifest_content.get("nodes", {})
    excluded_patterns = excluded_patterns or []
    results: list[IntraModelAnalysis] = []

    for unique_id, node in nodes.items():
        if not unique_id.startswith("model."):
            continue
        if not isinstance(node, dict):
            continue

        # Skip ephemeral models — they're inlined, not materialised as tables
        config = node.get("config", {}) or {}
        if config.get("materialized") == "ephemeral":
            continue

        # Prefer raw_code (keeps Jinja for the template); fall back to compiled SQL
        sql = (
            node.get("raw_code")
            or node.get("raw_sql")
            or node.get("compiled_code")
            or node.get("compiled_sql")
            or ""
        )
        if not sql.strip():
            continue

        analysis = _analyze_single_model_intra(
            unique_id, node, sql, excluded_patterns, min_dead_columns
        )
        if analysis is not None and analysis.cte_dead_columns:
            results.append(analysis)

    return results


def analyze_all_dead_ctes(
    manifest_content: dict,
    min_dead_ctes: int = 1,
) -> list[DeadCteAnalysis]:
    """Analyse all models in the manifest for unused CTE definitions."""
    nodes: dict[str, Any] = manifest_content.get("nodes", {})
    results: list[DeadCteAnalysis] = []

    for unique_id, node in nodes.items():
        if not unique_id.startswith("model."):
            continue
        if not isinstance(node, dict):
            continue

        config = node.get("config", {}) or {}
        if config.get("materialized") == "ephemeral":
            continue

        sql = (
            node.get("raw_code")
            or node.get("raw_sql")
            or node.get("compiled_code")
            or node.get("compiled_sql")
            or ""
        )
        if not sql.strip():
            continue

        analysis = _analyze_single_model_dead_ctes(
            unique_id=unique_id,
            node=node,
            sql=sql,
            min_dead_ctes=min_dead_ctes,
        )
        if analysis is not None and analysis.dead_ctes:
            results.append(analysis)

    return results


def analyze_intra_model_dead_outputs_by_category(
    manifest_content: dict,
    *,
    target_category: str,
    min_dead_columns: int = 1,
    excluded_patterns: list[str] | None = None,
) -> list[IntraModelAnalysis]:
    """Return intra-model dead outputs filtered to a specific expression category."""
    analyses = analyze_all_intra_model(
        manifest_content=manifest_content,
        min_dead_columns=1,
        excluded_patterns=excluded_patterns,
    )
    filtered_results: list[IntraModelAnalysis] = []

    for analysis in analyses:
        filtered_ctes: list[CteDeadColumns] = []
        for cte in analysis.cte_dead_columns:
            matching_dead = [
                col
                for col in cte.dead_columns
                if cte.dead_column_categories.get(col) == target_category
            ]
            if len(matching_dead) < min_dead_columns:
                continue

            filtered_ctes.append(
                CteDeadColumns(
                    cte_name=cte.cte_name,
                    dead_columns=matching_dead,
                    all_columns=cte.all_columns,
                    dead_column_categories={
                        col: cte.dead_column_categories[col] for col in matching_dead
                    },
                    all_column_categories=cte.all_column_categories,
                )
            )

        if filtered_ctes:
            filtered_results.append(
                IntraModelAnalysis(
                    model_unique_id=analysis.model_unique_id,
                    model_name=analysis.model_name,
                    affected_table=analysis.affected_table,
                    raw_code=analysis.raw_code,
                    cte_dead_columns=filtered_ctes,
                )
            )

    return filtered_results


def analyze_redundant_order_bys(
    manifest_content: dict,
    *,
    min_redundant_order_bys: int = 1,
) -> list[RedundantOrderByAnalysis]:
    """Detect top-level ORDER BY clauses in intermediate CTEs that do no work."""
    nodes: dict[str, Any] = manifest_content.get("nodes", {})
    results: list[RedundantOrderByAnalysis] = []

    for unique_id, node in nodes.items():
        if not unique_id.startswith("model.") or not isinstance(node, dict):
            continue

        config = node.get("config", {}) or {}
        if config.get("materialized") == "ephemeral":
            continue

        sql = (
            node.get("raw_code")
            or node.get("raw_sql")
            or node.get("compiled_code")
            or node.get("compiled_sql")
            or ""
        )
        if not sql.strip():
            continue

        analysis = _analyze_single_model_redundant_order_bys(
            unique_id=unique_id,
            node=node,
            sql=sql,
            min_redundant_order_bys=min_redundant_order_bys,
        )
        if analysis is not None and analysis.redundant_order_bys:
            results.append(analysis)

    return results


def analyze_unused_joins(
    manifest_content: dict,
    *,
    min_unused_joins: int = 1,
) -> list[UnusedJoinAnalysis]:
    """Detect conservatively removable LEFT JOINs inside model CTEs."""
    nodes: dict[str, Any] = manifest_content.get("nodes", {})
    results: list[UnusedJoinAnalysis] = []

    for unique_id, node in nodes.items():
        if not unique_id.startswith("model.") or not isinstance(node, dict):
            continue

        config = node.get("config", {}) or {}
        if config.get("materialized") == "ephemeral":
            continue

        sql = (
            node.get("raw_code")
            or node.get("raw_sql")
            or node.get("compiled_code")
            or node.get("compiled_sql")
            or ""
        )
        if not sql.strip():
            continue

        analysis = _analyze_single_model_unused_joins(
            unique_id=unique_id,
            node=node,
            sql=sql,
            min_unused_joins=min_unused_joins,
        )
        if analysis is not None and analysis.unused_joins:
            results.append(analysis)

    return results


def analyze_dead_cte_suppressed_findings(sql: str) -> list[dict[str, Any]]:
    """Summarize lower-priority findings hidden by a dead-CTE opportunity."""
    strip_result = strip_jinja(sql)
    sql_to_parse = strip_result.sql or sql

    try:
        ast = sqlglot.parse_one(
            sql_to_parse,
            dialect="bigquery",
            error_level=sqlglot.ErrorLevel.WARN,
        )
    except SqlglotError:
        logger.debug("Failed to parse SQL for dead CTE suppression analysis")
        return []

    if not isinstance(ast, exp.Select):
        return []

    with_clause = ast.args.get("with_")
    if not with_clause:
        return []

    cte_list = list(with_clause.expressions)
    if not cte_list:
        return []

    dead_ctes = _find_dead_ctes(cte_list, ast)
    if not dead_ctes:
        return []

    dead_cte_names = {name.lower() for name in dead_ctes}
    dead_outputs = [
        cte
        for cte in _find_cte_dead_columns(
            cte_list,
            ast,
            excluded_patterns=[],
            min_dead_columns=1,
        )
        if cte.cte_name.lower() in dead_cte_names
    ]

    suppressed: list[dict[str, Any]] = []

    plain_items = _scoped_dead_output_items(dead_outputs, target_category="column")
    if plain_items:
        suppressed.append(
            _build_suppressed_finding(
                rule_type="dead_column",
                display_name="Dead Column",
                reason=(
                    "Hidden because removing the entire dead CTE also removes these "
                    "plain unused columns."
                ),
                items=plain_items,
            )
        )

    window_items = _scoped_dead_output_items(dead_outputs, target_category="window")
    if window_items:
        suppressed.append(
            _build_suppressed_finding(
                rule_type="dead_window_expression",
                display_name="Dead Window Expression",
                reason=(
                    "Hidden because removing the entire dead CTE also removes these "
                    "unused window outputs."
                ),
                items=window_items,
            )
        )

    aggregate_items = _scoped_dead_output_items(
        dead_outputs, target_category="aggregate"
    )
    if aggregate_items:
        suppressed.append(
            _build_suppressed_finding(
                rule_type="unused_aggregation_output",
                display_name="Unused Aggregation Output",
                reason=(
                    "Hidden because removing the entire dead CTE also removes these "
                    "unused aggregate outputs."
                ),
                items=aggregate_items,
            )
        )

    redundant_items = [
        cte_name
        for cte_name in _find_redundant_order_bys(cte_list)
        if cte_name.lower() in dead_cte_names
    ]
    if redundant_items:
        suppressed.append(
            _build_suppressed_finding(
                rule_type="redundant_order_by",
                display_name="Redundant Order By",
                reason=(
                    "Hidden because removing the dead CTE removes the redundant sort "
                    "work first."
                ),
                items=redundant_items,
            )
        )

    unused_join_items: list[str] = []
    cte_map = _build_cte_select_map(cte_list)
    for cte in cte_list:
        cte_name = cte.alias_or_name
        if cte_name.lower() not in dead_cte_names:
            continue
        inner = cte.this
        if isinstance(inner, exp.Subquery):
            inner = inner.this
        if not isinstance(inner, exp.Select):
            continue
        for join in _find_unused_joins_in_select(cte_name, inner, cte_map):
            join_keys = ", ".join(join.join_keys)
            unused_join_items.append(
                f"{join.cte_name} -> {join.join_alias} ({join_keys})"
            )

    if unused_join_items:
        suppressed.append(
            _build_suppressed_finding(
                rule_type="unused_join",
                display_name="Unused Join",
                reason=(
                    "Hidden because removing the dead CTE also removes these "
                    "conservatively removable joins."
                ),
                items=unused_join_items,
            )
        )

    return suppressed


def _analyze_single_model_dead_ctes(
    *,
    unique_id: str,
    node: dict,
    sql: str,
    min_dead_ctes: int,
) -> DeadCteAnalysis | None:
    """Analyse one model for dead CTEs using backward reachability."""
    strip_result = strip_jinja(sql)
    sql_to_parse = strip_result.sql or sql

    try:
        ast = sqlglot.parse_one(
            sql_to_parse,
            dialect="bigquery",
            error_level=sqlglot.ErrorLevel.WARN,
        )
    except SqlglotError:
        logger.debug("Failed to parse SQL for dead CTE analysis of %s", unique_id)
        return None

    if not isinstance(ast, exp.Select):
        return None

    with_clause = ast.args.get("with_")
    if not with_clause:
        return None

    cte_list = list(with_clause.expressions)
    if not cte_list:
        return None

    dead_ctes = _find_dead_ctes(cte_list, ast)
    if len(dead_ctes) < min_dead_ctes:
        return None

    return DeadCteAnalysis(
        model_unique_id=unique_id,
        model_name=node.get("name", unique_id),
        affected_table=_resolve_table_name(node),
        raw_code=sql,
        dead_ctes=dead_ctes,
        total_cte_count=len(cte_list),
    )


def _analyze_single_model_redundant_order_bys(
    *,
    unique_id: str,
    node: dict,
    sql: str,
    min_redundant_order_bys: int,
) -> RedundantOrderByAnalysis | None:
    """Analyse one model for redundant top-level ORDER BY clauses in CTEs."""
    strip_result = strip_jinja(sql)
    sql_to_parse = strip_result.sql or sql

    try:
        ast = sqlglot.parse_one(
            sql_to_parse,
            dialect="bigquery",
            error_level=sqlglot.ErrorLevel.WARN,
        )
    except SqlglotError:
        logger.debug(
            "Failed to parse SQL for redundant ORDER BY analysis of %s", unique_id
        )
        return None

    if not isinstance(ast, exp.Select):
        return None

    with_clause = ast.args.get("with_")
    if not with_clause:
        return None

    cte_list = list(with_clause.expressions)
    dead_cte_names = {name.lower() for name in _find_dead_ctes(cte_list, ast)}
    redundant = _find_redundant_order_bys(cte_list, ignored_ctes=dead_cte_names)
    if len(redundant) < min_redundant_order_bys:
        return None

    return RedundantOrderByAnalysis(
        model_unique_id=unique_id,
        model_name=node.get("name", unique_id),
        affected_table=_resolve_table_name(node),
        raw_code=sql,
        redundant_order_bys=redundant,
        total_cte_count=len(cte_list),
    )


def _analyze_single_model_unused_joins(
    *,
    unique_id: str,
    node: dict,
    sql: str,
    min_unused_joins: int,
) -> UnusedJoinAnalysis | None:
    """Analyse one model for conservatively removable LEFT JOINs."""
    strip_result = strip_jinja(sql)
    sql_to_parse = strip_result.sql or sql

    try:
        ast = sqlglot.parse_one(
            sql_to_parse,
            dialect="bigquery",
            error_level=sqlglot.ErrorLevel.WARN,
        )
    except SqlglotError:
        logger.debug("Failed to parse SQL for unused join analysis of %s", unique_id)
        return None

    if not isinstance(ast, exp.Select):
        return None

    with_clause = ast.args.get("with_")
    if not with_clause:
        return None

    cte_list = list(with_clause.expressions)
    dead_cte_names = {name.lower() for name in _find_dead_ctes(cte_list, ast)}
    cte_map = _build_cte_select_map(cte_list)
    total_join_count = 0
    unused_joins: list[UnusedJoinOccurrence] = []

    for cte in cte_list:
        cte_name = cte.alias_or_name
        if cte_name.lower() in dead_cte_names:
            continue
        inner = cte.this
        if isinstance(inner, exp.Subquery):
            inner = inner.this
        if not isinstance(inner, exp.Select):
            continue

        joins = inner.args.get("joins", []) or []
        total_join_count += len(joins)
        unused_joins.extend(_find_unused_joins_in_select(cte_name, inner, cte_map))

    if len(unused_joins) < min_unused_joins:
        return None

    return UnusedJoinAnalysis(
        model_unique_id=unique_id,
        model_name=node.get("name", unique_id),
        affected_table=_resolve_table_name(node),
        raw_code=sql,
        unused_joins=unused_joins,
        total_join_count=total_join_count,
    )


def _analyze_single_model_intra(
    unique_id: str,
    node: dict,
    sql: str,
    excluded_patterns: list[str],
    min_dead_columns: int,
) -> IntraModelAnalysis | None:
    """Analyse a single model's SQL for intra-model dead columns."""
    strip_result = strip_jinja(sql)
    sql_to_parse = strip_result.sql or sql

    try:
        ast = sqlglot.parse_one(
            sql_to_parse,
            dialect="bigquery",
            error_level=sqlglot.ErrorLevel.WARN,
        )
    except SqlglotError:
        logger.debug("Failed to parse SQL for intra-model analysis of %s", unique_id)
        return None

    if not isinstance(ast, exp.Select):
        return None

    with_clause = ast.args.get("with_")
    if not with_clause:
        # No CTEs — no intra-model dead columns possible
        return None

    cte_list = list(with_clause.expressions)
    if not cte_list:
        return None

    cte_dead_columns = _find_cte_dead_columns(
        cte_list,
        ast,
        excluded_patterns,
        min_dead_columns,
        ignored_ctes={name.lower() for name in _find_dead_ctes(cte_list, ast)},
    )

    return IntraModelAnalysis(
        model_unique_id=unique_id,
        model_name=node.get("name", unique_id),
        affected_table=_resolve_table_name(node),
        raw_code=sql,
        cte_dead_columns=cte_dead_columns,
    )


def _find_cte_dead_columns(
    cte_list: list,
    outer_select: exp.Select,
    excluded_patterns: list[str],
    min_dead_columns: int,
    ignored_ctes: set[str] | None = None,
) -> list[CteDeadColumns]:
    """Find dead columns in each CTE of a model's WITH clause."""
    results: list[CteDeadColumns] = []
    ignored_ctes = ignored_ctes or set()

    for i, cte in enumerate(cte_list):
        cte_name = cte.alias_or_name
        if cte_name.lower() in ignored_ctes:
            continue

        # Get the CTE's inner SELECT
        inner = cte.this
        if isinstance(inner, exp.Subquery):
            inner = inner.this
        if not isinstance(inner, exp.Select):
            logger.debug("CTE %s inner is not a Select — skipping", cte_name)
            continue

        # Extract output column names (alias takes precedence — it's the visible name)
        output_specs, produces_star = _extract_cte_output_specs(inner)
        output_cols = [spec.output_name for spec in output_specs]
        output_categories = {spec.output_name: spec.category for spec in output_specs}
        if produces_star:
            logger.debug("CTE %s uses SELECT * — skipping", cte_name)
            continue
        if not output_cols:
            continue

        subsequent = cte_list[i + 1 :]

        # If any subsequent query does SELECT * directly FROM this CTE, all
        # columns are consumed — skip conservatively.
        if _is_cte_star_consumed(cte_name.lower(), subsequent, outer_select):
            logger.debug(
                "CTE %s is star-consumed by a subsequent CTE or outer SELECT — skipping",
                cte_name,
            )
            continue

        # Collect all column name references from subsequent CTEs + outer SELECT.
        # For the outer SELECT we exclude the WITH clause so that column names
        # that appear only in CTE SELECT lists aren't mistakenly treated as refs.
        referenced_cols: set[str] = set()
        for sub_cte in subsequent:
            sub_inner = sub_cte.this
            if isinstance(sub_inner, exp.Subquery):
                sub_inner = sub_inner.this
            if sub_inner is not None:
                referenced_cols |= _collect_col_refs(sub_inner)
        referenced_cols |= _collect_outer_select_refs(outer_select)

        dead = [
            col
            for col in output_cols
            if col not in referenced_cols
            and not _matches_excluded(col, excluded_patterns)
        ]

        if len(dead) >= min_dead_columns:
            results.append(
                CteDeadColumns(
                    cte_name=cte_name,
                    dead_columns=dead,
                    all_columns=output_cols,
                    dead_column_categories={
                        col: output_categories[col]
                        for col in dead
                        if col in output_categories
                    },
                    all_column_categories=output_categories,
                )
            )

    return results


def _find_dead_ctes(
    cte_list: list,
    outer_select: exp.Select,
) -> list[str]:
    """Return CTE names not reachable from the final query.

    Reachability is computed backwards:
    - seed the graph with CTEs referenced by the final SELECT
    - walk dependencies from each reachable CTE to the earlier CTEs it reads

    Any CTE not reached is dead. Recursive/self-referential CTEs are skipped
    conservatively rather than being flagged.
    """
    cte_names = [cte.alias_or_name.lower() for cte in cte_list]
    cte_name_set = set(cte_names)
    dependency_graph: dict[str, set[str]] = {}
    recursive_ctes: set[str] = set()

    for cte in cte_list:
        cte_name = cte.alias_or_name.lower()
        inner = cte.this
        if isinstance(inner, exp.Subquery):
            inner = inner.this
        if inner is None:
            dependency_graph[cte_name] = set()
            continue

        table_refs = _collect_table_refs(inner)
        dependencies = {ref for ref in table_refs if ref in cte_name_set}
        if cte_name in dependencies:
            recursive_ctes.add(cte_name)
            dependencies.discard(cte_name)
        dependency_graph[cte_name] = dependencies

    reachable: set[str] = set()
    stack = [
        ref
        for ref in _collect_outer_select_table_refs(outer_select)
        if ref in cte_name_set
    ]

    while stack:
        current = stack.pop()
        if current in reachable:
            continue
        reachable.add(current)
        stack.extend(
            dependency
            for dependency in dependency_graph.get(current, set())
            if dependency not in reachable
        )

    return [
        cte.alias_or_name
        for cte in cte_list
        if cte.alias_or_name.lower() not in reachable
        and cte.alias_or_name.lower() not in recursive_ctes
    ]


def _find_redundant_order_bys(
    cte_list: list,
    *,
    ignored_ctes: set[str] | None = None,
) -> list[str]:
    """Find CTEs whose top-level ORDER BY is redundant."""
    redundant: list[str] = []
    ignored_ctes = ignored_ctes or set()
    for cte in cte_list:
        if cte.alias_or_name.lower() in ignored_ctes:
            continue
        inner = cte.this
        if isinstance(inner, exp.Subquery):
            inner = inner.this
        if not isinstance(inner, exp.Select):
            continue
        if inner.args.get("order") is None:
            continue
        if inner.args.get("limit") is not None or inner.args.get("offset") is not None:
            continue
        redundant.append(cte.alias_or_name)
    return redundant


def _build_cte_select_map(cte_list: list) -> dict[str, exp.Select]:
    """Map lower-cased CTE names to their inner Select nodes."""
    cte_map: dict[str, exp.Select] = {}
    for cte in cte_list:
        inner = cte.this
        if isinstance(inner, exp.Subquery):
            inner = inner.this
        if isinstance(inner, exp.Select):
            cte_map[cte.alias_or_name.lower()] = inner
    return cte_map


def _find_unused_joins_in_select(
    cte_name: str,
    select: exp.Select,
    cte_map: dict[str, exp.Select],
) -> list[UnusedJoinOccurrence]:
    """Return conservatively removable LEFT JOINs for one SELECT."""
    joins = select.args.get("joins", []) or []
    if not joins:
        return []
    if _select_body_has_star(select):
        return []

    qualifier_refs, has_unqualified = _collect_non_join_qualifier_refs(select)
    if has_unqualified:
        return []

    results: list[UnusedJoinOccurrence] = []
    for join in joins:
        if str(join.args.get("side") or "").upper() != "LEFT":
            continue

        source_name, join_alias = _join_source_identity(join)
        if not source_name or not join_alias:
            continue
        if join_alias in qualifier_refs:
            continue

        on_expr = join.args.get("on")
        join_keys = _extract_join_keys_for_alias(on_expr, join_alias)
        if not join_keys:
            continue

        if not _join_rhs_unique_on_keys(join.this, source_name, join_keys, cte_map):
            continue

        results.append(
            UnusedJoinOccurrence(
                cte_name=cte_name,
                join_alias=join_alias,
                joined_source_name=source_name,
                join_keys=sorted(join_keys),
            )
        )

    return results


def _extract_cte_output_columns(
    cte_select: exp.Select,
) -> tuple[list[str], bool]:
    """Extract visible output column names from a CTE's SELECT clause.

    Returns (column_names, produces_star).
    Uses the alias name when available — that is the name visible to subsequent CTEs.
    Skips complex expressions without an alias (they can't be referenced by name).
    """
    specs, produces_star = _extract_cte_output_specs(cte_select)
    return [spec.output_name for spec in specs], produces_star


def _extract_cte_output_specs(
    cte_select: exp.Select,
) -> tuple[list[CteOutputSpec], bool]:
    """Extract visible output names plus a coarse expression category."""
    specs: list[CteOutputSpec] = []
    for expr in cte_select.expressions:
        if isinstance(expr, exp.Star):
            return [], True
        if isinstance(expr, exp.Column) and isinstance(expr.this, exp.Star):
            return [], True
        if isinstance(expr, exp.Alias):
            specs.append(
                CteOutputSpec(
                    output_name=expr.alias.lower(),
                    category=_classify_output_expression(expr.this),
                )
            )
        elif isinstance(expr, exp.Column):
            specs.append(
                CteOutputSpec(
                    output_name=expr.name.lower(),
                    category="column",
                )
            )
        # Complex expressions without aliases are intentionally skipped because
        # downstream SQL cannot reference them by a stable output name.
    return specs, False


def _classify_output_expression(expression: exp.Expression | None) -> str:
    """Classify a SELECT expression into a coarse output category."""
    if expression is None:
        return "other"
    if isinstance(expression, exp.Window) or expression.find(exp.Window):
        return "window"
    if isinstance(expression, exp.AggFunc) or expression.find(exp.AggFunc):
        return "aggregate"
    if isinstance(expression, exp.Column):
        return "column"
    return "other"


def _scoped_dead_output_items(
    cte_dead_columns: list[CteDeadColumns],
    *,
    target_category: str,
) -> list[str]:
    """Return `cte.column` items for dead outputs in a specific category."""
    items: list[str] = []
    for cte in cte_dead_columns:
        for col in cte.dead_columns:
            if cte.dead_column_categories.get(col) == target_category:
                items.append(f"{cte.cte_name}.{col}")
    return items


def _build_suppressed_finding(
    *,
    rule_type: str,
    display_name: str,
    reason: str,
    items: list[str],
) -> dict[str, Any]:
    """Build a UI-friendly suppressed finding summary."""
    ctes = sorted({item.split(".", 1)[0] for item in items if "." in item})
    return {
        "rule_type": rule_type,
        "display_name": display_name,
        "count": len(items),
        "reason": reason,
        "items": items,
        "ctes": ctes,
    }


def _is_cte_star_consumed(
    cte_name_lower: str,
    subsequent_ctes: list,
    outer_select: exp.Select,
) -> bool:
    """Return True if a subsequent SELECT * or SELECT t.* directly references this CTE.

    Only inspects the immediate FROM/JOIN clause of each SELECT (not recursive),
    to avoid false positives from nested CTEs that happen to reference the same name.
    """

    def _direct_from_map(sel: exp.Select) -> dict[str, str]:
        """Build {alias: actual_name} from the direct FROM and JOIN tables only."""
        result: dict[str, str] = {}
        from_node = sel.args.get("from_")
        if from_node and isinstance(from_node.this, exp.Table):
            tbl = from_node.this
            actual = tbl.name.lower()
            alias = tbl.alias.lower() if tbl.alias else actual
            result[alias] = actual
            result[actual] = actual
        for join in sel.args.get("joins", []) or []:
            if isinstance(join.this, exp.Table):
                tbl = join.this
                actual = tbl.name.lower()
                alias = tbl.alias.lower() if tbl.alias else actual
                result[alias] = actual
                result[actual] = actual
        return result

    def _check_select(sel: exp.Select) -> bool:
        from_map = _direct_from_map(sel)
        if cte_name_lower not in from_map.values():
            return False  # Our CTE is not directly in the FROM clause
        for expr in sel.expressions:
            if isinstance(expr, exp.Star):
                return True  # bare SELECT *
            if isinstance(expr, exp.Column) and isinstance(expr.this, exp.Star):
                # table.* — check if that table resolves to our CTE
                tbl_qualifier = expr.table.lower() if expr.table else None
                if tbl_qualifier is None:
                    return True  # unqualified .* — conservative
                if from_map.get(tbl_qualifier) == cte_name_lower:
                    return True
        return False

    if _check_select(outer_select):
        return True

    for sub_cte in subsequent_ctes:
        inner = sub_cte.this
        if isinstance(inner, exp.Subquery):
            inner = inner.this
        if isinstance(inner, exp.Select) and _check_select(inner):
            return True

    return False


def _collect_col_refs(node: exp.Expression) -> set[str]:
    """Collect all column names referenced anywhere in an AST node."""
    refs: set[str] = set()
    for col in node.find_all(exp.Column):
        name = col.name
        if name and name != "*":
            refs.add(name.lower())
    return refs


def _collect_table_refs(node: exp.Expression) -> set[str]:
    """Collect referenced table / CTE names from an AST node."""
    refs: set[str] = set()
    for table in node.find_all(exp.Table):
        name = table.name
        if name:
            refs.add(name.lower())
    return refs


def _collect_non_join_qualifier_refs(select: exp.Select) -> tuple[set[str], bool]:
    """Collect table qualifiers referenced outside JOIN/ON clauses.

    Returns `(qualifiers, has_unqualified_columns)`.
    """
    refs: set[str] = set()
    has_unqualified = False
    for key in ("expressions", "where", "group", "having", "qualify", "order"):
        node = select.args.get(key)
        if not node:
            continue
        nodes = node if isinstance(node, list) else [node]
        for item in nodes:
            for col in item.find_all(exp.Column):
                if isinstance(col.this, exp.Star):
                    continue
                if col.table:
                    refs.add(col.table.lower())
                else:
                    has_unqualified = True
    return refs, has_unqualified


def _select_body_has_star(select: exp.Select) -> bool:
    """Return True when the SELECT list uses a star expression."""
    for expr in select.expressions:
        if isinstance(expr, exp.Star):
            return True
        if isinstance(expr, exp.Column) and isinstance(expr.this, exp.Star):
            return True
    return False


def _join_source_identity(join: exp.Join) -> tuple[str | None, str | None]:
    """Return `(source_name, alias)` for a JOIN target."""
    target = join.this
    if isinstance(target, exp.Table):
        source_name = target.name.lower()
        alias = target.alias.lower() if target.alias else source_name
        return source_name, alias
    if isinstance(target, exp.Subquery):
        alias = target.alias_or_name.lower() if target.alias_or_name else None
        source_name = alias
        return source_name, alias
    return None, None


def _extract_join_keys_for_alias(
    on_expr: exp.Expression | None,
    join_alias: str,
) -> set[str] | None:
    """Extract right-side join keys from a simple conjunction of equality predicates."""
    if on_expr is None:
        return None

    comparisons = _flatten_and_conditions(on_expr)
    if not comparisons:
        return None

    join_keys: set[str] = set()
    for comparison in comparisons:
        if not isinstance(comparison, exp.EQ):
            return None

        left = comparison.this
        right = comparison.expression
        if not isinstance(left, exp.Column) or not isinstance(right, exp.Column):
            return None
        if not left.table or not right.table:
            return None

        if left.table.lower() == join_alias and right.table.lower() != join_alias:
            join_keys.add(left.name.lower())
        elif right.table.lower() == join_alias and left.table.lower() != join_alias:
            join_keys.add(right.name.lower())
        else:
            return None

    return join_keys


def _flatten_and_conditions(expr: exp.Expression) -> list[exp.Expression]:
    """Flatten a boolean AND tree into a list of predicates."""
    if isinstance(expr, exp.And):
        return _flatten_and_conditions(expr.this) + _flatten_and_conditions(
            expr.expression
        )
    return [expr]


def _join_rhs_unique_on_keys(
    join_target: exp.Expression,
    source_name: str,
    join_keys: set[str],
    cte_map: dict[str, exp.Select],
) -> bool:
    """Return True when the right side is provably unique on the join keys."""
    target_select: exp.Select | None = None
    if isinstance(join_target, exp.Subquery) and isinstance(
        join_target.this, exp.Select
    ):
        target_select = join_target.this
    elif source_name in cte_map:
        target_select = cte_map[source_name]

    if target_select is None:
        return False

    return _select_unique_on_keys(target_select, join_keys)


def _select_unique_on_keys(select: exp.Select, join_keys: set[str]) -> bool:
    """Return True when a SELECT is structurally unique on the given keys."""
    normalized_keys = {key.lower() for key in join_keys}
    if not normalized_keys:
        return False

    if select.args.get("distinct") is not None:
        output_cols, produces_star = _extract_cte_output_columns(select)
        return not produces_star and set(output_cols) == normalized_keys

    group = select.args.get("group")
    if group is None:
        return False

    group_cols: list[str] = []
    for expr in group.expressions:
        if not isinstance(expr, exp.Column):
            return False
        group_cols.append(expr.name.lower())
    return set(group_cols) == normalized_keys


# Keys on exp.Select that hold the query body (excluding WITH clause).
_SELECT_BODY_KEYS = (
    "expressions",
    "from_",
    "joins",
    "where",
    "group",
    "having",
    "order",
    "limit",
)


def _collect_outer_select_refs(sel: exp.Select) -> set[str]:
    """Collect column refs from a SELECT node, deliberately skipping the WITH clause.

    Using the plain `_collect_col_refs(sel)` on an outer SELECT that carries
    a WITH clause would traverse the CTE bodies and falsely mark their own
    SELECT-list column names as "referenced" in the outer query.
    """
    refs: set[str] = set()
    for key in _SELECT_BODY_KEYS:
        node = sel.args.get(key)
        if node:
            if isinstance(node, list):
                for n in node:
                    refs |= _collect_col_refs(n)
            else:
                refs |= _collect_col_refs(node)
    return refs


def _collect_outer_select_table_refs(sel: exp.Select) -> set[str]:
    """Collect table refs from a SELECT node, deliberately skipping the WITH clause."""
    refs: set[str] = set()
    for key in _SELECT_BODY_KEYS:
        node = sel.args.get(key)
        if node:
            if isinstance(node, list):
                for n in node:
                    refs |= _collect_table_refs(n)
            else:
                refs |= _collect_table_refs(node)
    return refs


def analyze_manifest(
    manifest_content: dict,
    min_column_count: int = 3,
    excluded_patterns: list[str] | None = None,
) -> list[ColumnAnalysis]:
    """Analyse a dbt manifest and return dead column findings for all eligible models.

    Eligible models:
      - Resource type: model node (unique_id starts with "model.")
      - Not ephemeral (config.materialized != "ephemeral")
      - Not a leaf (has at least one downstream model child in child_map)
      - Has parseable compiled_code
      - Outermost SELECT does not use SELECT *
      - Has at least min_column_count output columns

    Args:
        manifest_content: Parsed manifest.json dict.
        min_column_count: Minimum output columns to analyse (avoid tiny models).
        excluded_patterns: Regex patterns for column names to always treat as used.

    Returns:
        List of ColumnAnalysis for models that have dead columns.
    """
    nodes: dict[str, Any] = manifest_content.get("nodes", {})
    child_map: dict[str, list[str]] = manifest_content.get("child_map", {})
    excluded_patterns = excluded_patterns or []

    results: list[ColumnAnalysis] = []

    for unique_id, node in nodes.items():
        if not unique_id.startswith("model."):
            continue

        if not isinstance(node, dict):
            continue

        # Skip ephemeral models — they're inlined, not materialized as tables
        config = node.get("config", {}) or {}
        if config.get("materialized") == "ephemeral":
            continue

        # Skip leaf models (no downstream model children)
        if _is_leaf_model(unique_id, child_map):
            continue

        # Skip fact and dimension tables — these are terminal business entities
        # queried by BI tools and ad-hoc SQL outside the dbt DAG.
        # Removing columns from them based solely on dbt lineage is unsafe.
        model_name = node.get("name", "")
        if model_name.startswith(("fct_", "dim_")):
            logger.debug(
                "Skipping %s: fact/dimension tables are not analysed for dead columns",
                model_name,
            )
            continue

        # Prefer compiled SQL; fall back to raw_code (jinja_strip handles Jinja templates)
        compiled_code = (
            node.get("compiled_code")
            or node.get("compiled_sql")
            or node.get("raw_code")
            or node.get("raw_sql")
            or ""
        )
        if not compiled_code.strip():
            logger.debug(
                "Skipping %s: no compiled_code or raw_code available",
                node.get("name", unique_id),
            )
            continue

        # Extract output column list and alias map
        output_columns, alias_map, produces_star = _extract_model_output_columns(
            compiled_code
        )

        if produces_star:
            logger.debug(
                "Skipping %s: upstream SELECT * cannot determine output columns",
                node.get("name", unique_id),
            )
            continue

        if len(output_columns) < min_column_count:
            logger.debug(
                "Skipping %s: only %d output columns (min=%d)",
                node.get("name", unique_id),
                len(output_columns),
                min_column_count,
            )
            continue

        # Collect column references from all downstream model children
        model_name = node.get("name", unique_id)
        used_output_names: set[str] = set()
        has_star_downstream = False
        downstream_model_names: list[str] = []

        model_children = [
            child_id
            for child_id in child_map.get(unique_id, [])
            if child_id.startswith("model.")
        ]

        for child_id in model_children:
            child_node = nodes.get(child_id)
            if not child_node or not isinstance(child_node, dict):
                # Cannot analyse — treat conservatively
                logger.debug(
                    "Child %s not found in nodes for upstream %s — treating conservatively",
                    child_id,
                    model_name,
                )
                has_star_downstream = True
                break

            child_compiled = (
                child_node.get("compiled_code")
                or child_node.get("compiled_sql")
                or child_node.get("raw_code")
                or child_node.get("raw_sql")
                or ""
            )
            if not child_compiled.strip():
                # Cannot parse child → treat conservatively
                logger.debug(
                    "Child %s has no compiled_code or raw_code — treating conservatively",
                    child_node.get("name", child_id),
                )
                has_star_downstream = True
                break

            refs, is_star = _extract_downstream_references(child_compiled, model_name)
            child_name = child_node.get("name", child_id)
            downstream_model_names.append(child_name)

            if is_star:
                logger.debug(
                    "Child %s uses SELECT * from %s — skipping upstream",
                    child_name,
                    model_name,
                )
                has_star_downstream = True
                break

            used_output_names |= refs

        if has_star_downstream:
            continue

        # Resolve aliases: downstream used output_name Y → mark source col X as used.
        # alias_map = { output_name → source_name }
        used_source_cols: set[str] = set()
        for used_name in used_output_names:
            # If downstream used the alias (output name), map back to the source name.
            # If downstream used the source name directly (no alias), keep as-is.
            source = alias_map.get(used_name.lower(), used_name)
            used_source_cols.add(source.lower())
            # Also add the used name itself (handles cases where downstream uses
            # the source column name directly even if there's an alias)
            used_source_cols.add(used_name.lower())

        # Compute dead columns: output columns not found in used source cols
        dead_columns = [
            col
            for col in output_columns
            if col.lower() not in used_source_cols
            and not _matches_excluded(col, excluded_patterns)
        ]

        if not dead_columns:
            continue

        results.append(
            ColumnAnalysis(
                model_unique_id=unique_id,
                model_name=model_name,
                affected_table=_resolve_table_name(node),
                raw_code=node.get("raw_code") or node.get("raw_sql") or compiled_code,
                output_columns=output_columns,
                alias_map=alias_map,
                dead_columns=dead_columns,
                downstream_models=downstream_model_names,
                produces_star=False,
            )
        )

    return results


def _extract_model_output_columns(
    compiled_code: str,
) -> tuple[list[str], dict[str, str], bool]:
    """Parse compiled SQL and return (output_col_names, alias_map, produces_star).

    output_col_names: source column names (the name before AS, or the bare col name)
    alias_map: { output_name_lower → source_col_name_lower } for alias resolution
    produces_star: True if the outermost SELECT contains SELECT *

    Returns ([], {}, False) on parse error (logged at debug level).
    """
    strip_result = strip_jinja(compiled_code)
    sql_to_parse = strip_result.sql if strip_result.sql else compiled_code

    try:
        ast = sqlglot.parse_one(sql_to_parse, dialect="bigquery")
    except SqlglotError:
        logger.debug("Failed to parse upstream compiled SQL for column extraction")
        return [], {}, False

    select = ast.find(exp.Select)
    if select is None:
        return [], {}, False

    output_columns: list[str] = []
    alias_map: dict[str, str] = {}

    for expr in select.expressions:
        if isinstance(expr, exp.Star):
            return [], {}, True

        if isinstance(expr, exp.Alias):
            alias_name = expr.alias  # the output name (e.g. "id")
            # Source column: the expression being aliased
            inner = expr.this
            if isinstance(inner, exp.Column):
                source_name = inner.name  # e.g. "station_id"
            else:
                # Complex expression aliased — use alias as both source and output
                source_name = alias_name

            output_columns.append(source_name)
            alias_map[alias_name.lower()] = source_name.lower()

        elif isinstance(expr, exp.Column):
            col_name = expr.name
            output_columns.append(col_name)

        # Other expressions (functions, literals, etc.) without an alias — skip
        # They can't be referenced by column name in downstream SQL

    return output_columns, alias_map, False


def _extract_downstream_references(
    downstream_compiled: str,
    upstream_model_name: str,
) -> tuple[set[str], bool]:
    """Parse downstream compiled SQL and return (referenced_col_names, uses_star).

    referenced_col_names: all column names found in the downstream SQL.
    uses_star: True if SELECT * is detected anywhere in the downstream SQL.

    Conservative by design:
    - Any SELECT * anywhere → uses_star=True (treat all upstream cols as used)
    - Parse failure → return (set(), True) (treat conservatively)
    - Ambiguous scope → use all column names found anywhere in the SQL

    The function does NOT attempt table-scoped resolution — it collects ALL
    column names found in the downstream SQL. This is over-conservative (may
    mark a column as used due to a name collision with a different table's
    column), but it never produces false positives.
    """
    strip_result = strip_jinja(downstream_compiled)
    sql_to_parse = strip_result.sql if strip_result.sql else downstream_compiled

    try:
        ast = sqlglot.parse_one(sql_to_parse, dialect="bigquery")
    except SqlglotError:
        logger.debug(
            "Failed to parse downstream compiled SQL — treating conservatively"
        )
        return set(), True

    # Check for SELECT * anywhere in the AST.
    # sqlglot represents both `*` and `table.*` as:
    #   - bare exp.Star() directly in SELECT expressions, OR
    #   - exp.Column(this=exp.Star(), table=...) for qualified `table.*`
    for select in ast.find_all(exp.Select):
        for expr in select.expressions:
            if isinstance(expr, exp.Star):
                return set(), True
            # table.* → exp.Column(this=exp.Star(), table=Identifier(...))
            if isinstance(expr, exp.Column) and isinstance(expr.this, exp.Star):
                return set(), True

    # Collect all column names referenced anywhere in the SQL.
    # Skip entries where the "name" is "*" (catches any remaining star variants).
    referenced: set[str] = set()
    for col in ast.find_all(exp.Column):
        name = col.name
        if name and name != "*":
            referenced.add(name.lower())

    return referenced, False


def _is_leaf_model(unique_id: str, child_map: dict) -> bool:
    """Return True if the model has no downstream model children.

    Exposures, tests, snapshots, and seeds are not considered model children.
    Only entries starting with 'model.' count as downstream model consumers.
    """
    children = child_map.get(unique_id, [])
    model_children = [c for c in children if c.startswith("model.")]
    return len(model_children) == 0


def _resolve_table_name(node: dict) -> str:
    """Return 'project.dataset.table' from a manifest node dict.

    Falls back gracefully if fields are missing.
    """
    database = node.get("database", "")
    schema = node.get("schema", "")
    identifier = node.get("identifier") or node.get("name", "")
    return f"{database}.{schema}.{identifier}"


def _matches_excluded(col_name: str, patterns: list[str]) -> bool:
    """Return True if col_name matches any of the excluded regex patterns."""
    for pattern in patterns:
        try:
            if re.search(pattern, col_name, re.IGNORECASE):
                return True
        except re.error:
            logger.debug("Invalid excluded pattern '%s' — skipping", pattern)
    return False
