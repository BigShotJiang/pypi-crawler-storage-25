"""Column quality profiler for join key analysis.

Profiles join key columns in BigQuery to detect poor data quality
(high NULL ratio, low cardinality) that would make clustering useless.
Produces quality classifications used by the solution generator to
suggest root-cause-aware fixes instead of blind cluster_by suggestions.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from google.cloud.exceptions import GoogleCloudError

logger = logging.getLogger("app.dbt.column_profiler")

# Thresholds (configurable defaults, not hard rules)
_NULL_RATIO_GOOD = 0.10  # < 10% NULLs
_NULL_RATIO_POOR = 0.50  # > 50% NULLs
_DISTINCT_GOOD = 100
_DISTINCT_POOR = 10
_MIN_ROWS_FOR_CARDINALITY_CHECK = 100_000
_DOMINANT_VALUE_MARGINAL = 0.50
_DOMINANT_VALUE_POOR = 0.80
_MIN_ROWS_FOR_DOMINANCE_CHECK = 10_000
_NULL_SENTINEL = "__governor_null__"


@dataclass
class ColumnQuality:
    """Quality assessment for a single column."""

    column_name: str
    total_rows: int
    null_count: int
    null_ratio: float
    approx_distinct: int
    classification: str  # "good", "marginal", "poor"
    reason: str
    dominant_value: str | None = None
    dominant_count: int | None = None
    dominant_ratio: float | None = None


def build_profile_query(
    project_id: str,
    dataset: str,
    table: str,
    columns: list[str],
) -> str:
    """Build a lightweight profiling query for the given columns.

    Uses COUNTIF(col IS NULL) and APPROX_COUNT_DISTINCT(col) for each column
    in a single query. This reads only the relevant columns (cheap on
    columnar storage) and uses HyperLogLog for cardinality estimation.

    Args:
        project_id: GCP project ID
        dataset: BigQuery dataset name
        table: BigQuery table name
        columns: List of column names to profile

    Returns:
        SQL string ready for execution

    Raises:
        ValueError: If columns list is empty or contains invalid identifiers
    """
    if not columns:
        raise ValueError("columns must not be empty")

    # Validate identifiers to prevent SQL injection
    for col in columns:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", col):
            raise ValueError(f"Invalid column identifier: {col!r}")

    if not re.fullmatch(r"[A-Za-z0-9_-]+", dataset):
        raise ValueError(f"Invalid dataset identifier: {dataset!r}")

    if not re.fullmatch(r"[A-Za-z0-9_-]+", table):
        raise ValueError(f"Invalid table identifier: {table!r}")

    select_parts = ["COUNT(*) AS total_rows"]
    for col in columns:
        select_parts.append(f"COUNTIF(`{col}` IS NULL) AS `{col}__nulls`")
        select_parts.append(f"APPROX_COUNT_DISTINCT(`{col}`) AS `{col}__distinct`")
        top_expr = (
            "APPROX_TOP_COUNT("
            f"COALESCE(CAST(`{col}` AS STRING), '{_NULL_SENTINEL}'), 1)"
            "[SAFE_OFFSET(0)]"
        )
        select_parts.append(f"{top_expr}.value AS `{col}__top_value`")
        select_parts.append(f"{top_expr}.count AS `{col}__top_count`")

    select_clause = ",\n  ".join(select_parts)
    return f"SELECT\n  {select_clause}\nFROM `{project_id}`.`{dataset}`.`{table}`"


def classify_column(
    column_name: str,
    null_count: int,
    approx_distinct: int,
    total_rows: int,
    dominant_value: str | None = None,
    dominant_count: int | None = None,
) -> ColumnQuality:
    """Classify a column's quality for clustering suitability.

    Args:
        column_name: Name of the column
        null_count: Number of NULL values
        approx_distinct: Approximate count of distinct non-NULL values
        total_rows: Total row count in the table

    Returns:
        ColumnQuality with classification and reason
    """
    null_ratio = null_count / total_rows if total_rows > 0 else 0.0
    dominant_ratio = (
        (dominant_count or 0) / total_rows
        if total_rows > 0 and dominant_count is not None
        else None
    )

    reasons: list[str] = []
    classification = "good"

    # Check NULL ratio
    if null_ratio > _NULL_RATIO_POOR:
        classification = "poor"
        reasons.append(
            f"{null_ratio:.0%} NULL — NULLs on both sides of a join cause "
            f"cartesian products"
        )
    elif null_ratio > _NULL_RATIO_GOOD:
        if classification != "poor":
            classification = "marginal"
        reasons.append(f"{null_ratio:.0%} NULL — may cause partial cartesian products")

    # Check cardinality (only meaningful for large tables)
    if total_rows >= _MIN_ROWS_FOR_CARDINALITY_CHECK:
        if approx_distinct < _DISTINCT_POOR:
            classification = "poor"
            reasons.append(
                f"only {approx_distinct} distinct values across "
                f"{total_rows:,} rows — clustering provides no benefit"
            )
        elif approx_distinct < _DISTINCT_GOOD:
            if classification == "good":
                classification = "marginal"
            reasons.append(
                f"{approx_distinct} distinct values across "
                f"{total_rows:,} rows — low cardinality for clustering"
            )

    # Even on medium-sized tables, a single dominant placeholder value
    # (for example "unknown") makes clustering ineffective.
    if (
        dominant_ratio is not None
        and total_rows >= _MIN_ROWS_FOR_DOMINANCE_CHECK
        and approx_distinct <= _DISTINCT_POOR
    ):
        display_value = "NULL" if dominant_value == _NULL_SENTINEL else dominant_value
        if dominant_ratio >= _DOMINANT_VALUE_POOR or (
            dominant_ratio >= _DOMINANT_VALUE_MARGINAL
            and approx_distinct <= _DISTINCT_POOR
        ):
            classification = "poor"
            reasons.append(
                f"top value {display_value!r} covers {dominant_ratio:.0%} of rows — "
                f"dominant low-cardinality values provide no clustering benefit"
            )
        elif dominant_ratio >= _DOMINANT_VALUE_MARGINAL and classification == "good":
            classification = "marginal"
            reasons.append(
                f"top value {display_value!r} covers {dominant_ratio:.0%} of rows — "
                f"distribution is heavily skewed for clustering"
            )

    if not reasons:
        reasons.append("good cardinality and low NULL ratio")

    return ColumnQuality(
        column_name=column_name,
        total_rows=total_rows,
        null_count=null_count,
        null_ratio=null_ratio,
        approx_distinct=approx_distinct,
        dominant_value=None if dominant_value == _NULL_SENTINEL else dominant_value,
        dominant_count=dominant_count,
        dominant_ratio=dominant_ratio,
        classification=classification,
        reason="; ".join(reasons),
    )


def profile_columns(
    project_id: str,
    dataset: str,
    table: str,
    columns: list[str],
) -> dict[str, ColumnQuality] | None:
    """Profile columns in BigQuery and return quality classifications.

    Executes a single profiling query against the table and classifies
    each column. Returns None on any failure (graceful fallback).

    Args:
        project_id: GCP project ID
        dataset: BigQuery dataset name
        table: BigQuery table name
        columns: List of column names to profile

    Returns:
        Dict mapping column name → ColumnQuality, or None on failure
    """
    if not columns:
        return None

    try:
        from governor_core.gcp.clients import get_bigquery_client

        sql = build_profile_query(project_id, dataset, table, columns)
        client = get_bigquery_client(project_id=project_id)

        from google.cloud.bigquery import QueryJobConfig

        job_config = QueryJobConfig()
        job_config.use_query_cache = True

        query_job = client.query(sql, job_config=job_config, timeout=30)
        rows = list(query_job.result(timeout=30))

        if not rows:
            logger.warning(
                "Profile query returned no rows for %s.%s.%s",
                project_id,
                dataset,
                table,
            )
            return None

        row = dict(rows[0].items())
        total_rows = row.get("total_rows", 0)

        if total_rows == 0:
            logger.info(
                "Table %s.%s.%s is empty, skipping profiling",
                project_id,
                dataset,
                table,
            )
            return None

        result: dict[str, ColumnQuality] = {}
        for col in columns:
            null_count = row.get(f"{col}__nulls", 0)
            approx_distinct = row.get(f"{col}__distinct", 0)
            dominant_value = row.get(f"{col}__top_value")
            dominant_count = row.get(f"{col}__top_count")
            result[col] = classify_column(
                col,
                null_count,
                approx_distinct,
                total_rows,
                dominant_value=dominant_value,
                dominant_count=dominant_count,
            )

        logger.info(
            "Profiled %d columns on %s.%s.%s (%d rows): %s",
            len(columns),
            project_id,
            dataset,
            table,
            total_rows,
            {c: q.classification for c, q in result.items()},
        )
        return result

    except (GoogleCloudError, KeyError, ValueError, TypeError) as exc:
        logger.warning(
            "Column profiling failed for %s.%s.%s: %s",
            project_id,
            dataset,
            table,
            exc,
        )
        return None


def make_column_quality_lookup(
    project_id: str,
) -> callable:
    """Create a column quality lookup callable for use with analyze_upstream().

    Returns a function that takes a manifest node dict and a list of column
    names, profiles them in BigQuery, and returns quality classifications.

    Results are cached per (dataset, table, columns_tuple) to avoid repeated queries.
    """
    cache: dict[tuple[str, str, tuple[str, ...]], dict[str, ColumnQuality] | None] = {}

    def lookup(node: dict, columns: list[str]) -> dict[str, ColumnQuality] | None:
        dataset = node.get("schema", "")
        table_name = node.get("alias") or node.get("name", "")

        if not dataset or not table_name or not columns:
            return None

        cache_key = (
            dataset.lower(),
            table_name.lower(),
            tuple(sorted(c.lower() for c in columns)),
        )
        if cache_key in cache:
            return cache[cache_key]

        result = profile_columns(project_id, dataset, table_name, columns)
        cache[cache_key] = result
        return result

    return lookup
