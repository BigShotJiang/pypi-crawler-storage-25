"""uv venv-based dbt compile and parse runner.

Uses `uv` to create isolated virtual environments with the correct dbt version,
then runs dbt commands as subprocesses. Venvs are cached for reuse across compiles.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from governor_core.core.config import get_settings
from governor_core.dbt.profiles import ProfilesGenerator

logger = logging.getLogger("app.dbt.uv_runner")

_STDERR_MAX_BYTES = 10240  # 10KB


@dataclass
class CompileResult:
    """Result of a dbt compile operation."""

    compiled_sql: str | None = None
    success: bool = False
    exit_code: int = -1
    stdout: str = ""
    stderr: str = ""
    duration_ms: int = 0


@dataclass
class ParseResult:
    """Result of a dbt parse operation."""

    manifest: dict | None = None
    success: bool = False
    exit_code: int = -1
    stderr: str = ""
    duration_ms: int = 0


@dataclass
class BuildResult:
    """Result of a dbt build operation."""

    success: bool = False
    exit_code: int = -1
    run_results: dict | None = None
    models_count: int = 0
    stdout: str = ""
    stderr: str = ""
    duration_ms: int = 0


class DbtUvRunner:
    """Manages uv virtual environments for dbt compile/parse operations."""

    _venv_lock = threading.Lock()

    def __init__(self, venv_base_dir: str | None = None):
        settings = get_settings()
        base = venv_base_dir or settings.dbt_venv_base_dir
        self._venv_base = Path(base).expanduser()

    def is_available(self) -> bool:
        """Check if uv is installed and accessible.

        Returns True if uv responds to --version.
        Returns False if uv is not installed or inaccessible.
        Never raises.
        """
        try:
            subprocess.run(
                ["uv", "--version"],
                capture_output=True,
                timeout=5,
            )
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            return False

    def ensure_venv(self, dbt_version: str) -> Path:
        """Create or reuse a cached venv with the correct dbt version.

        Installs dbt-core pinned to the manifest version and dbt-bigquery
        (unpinned, resolved to a compatible version by uv).

        Returns path to the venv directory.
        Raises RuntimeError if venv creation or dbt installation fails.
        """
        venv_dir = self._venv_base / dbt_version
        marker = venv_dir / ".governor-ready"

        if marker.exists():
            return venv_dir

        with self._venv_lock:
            # Double-check after acquiring lock (another thread may have created it)
            if marker.exists():
                return venv_dir

            return self._create_venv(venv_dir, marker, dbt_version)

    def _create_venv(self, venv_dir: Path, marker: Path, dbt_version: str) -> Path:
        """Create a new venv with dbt installed. Called under _venv_lock."""
        # Create parent directories if needed
        venv_dir.parent.mkdir(parents=True, exist_ok=True)

        logger.info(
            "Creating dbt venv: version=%s path=%s",
            dbt_version,
            venv_dir,
        )

        try:
            # Create venv with Python 3.12
            subprocess.run(
                ["uv", "venv", str(venv_dir), "--python", "3.12"],
                check=True,
                capture_output=True,
                timeout=30,
            )

            # Ensure venv directory exists (uv venv creates it, but guard for edge cases)
            venv_dir.mkdir(parents=True, exist_ok=True)

            # Install dbt-core pinned to the manifest version + dbt-bigquery
            # (unpinned — uv resolves the latest adapter compatible with the
            # pinned dbt-core).  Since dbt 1.8+ the adapter has its own
            # independent version scheme, so we cannot assume
            # dbt-bigquery=={dbt_core_version} exists.
            python_path = venv_dir / "bin" / "python"
            subprocess.run(
                [
                    "uv",
                    "pip",
                    "install",
                    "--python",
                    str(python_path),
                    f"dbt-core=={dbt_version}",
                    "dbt-bigquery",
                ],
                check=True,
                capture_output=True,
                timeout=300,
            )

            # Write marker file to indicate venv is ready
            marker.write_text(dbt_version)
            logger.info("dbt venv ready: version=%s", dbt_version)
            return venv_dir

        except subprocess.CalledProcessError as exc:
            stderr = (
                exc.stderr.decode("utf-8", errors="replace")
                if isinstance(exc.stderr, bytes)
                else str(exc.stderr)
            )
            raise RuntimeError(
                f"Failed to create dbt venv for version {dbt_version}: {stderr}"
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(
                f"Timed out creating dbt venv for version {dbt_version}"
            ) from exc

    def compile_model(
        self,
        project_dir: str,
        model_name: str,
        dbt_version: str,
        profiles_dir: str,
        target_name: str | None = None,
        timeout: int | None = None,
    ) -> CompileResult:
        """Compile a single dbt model using the cached uv venv.

        Returns CompileResult with compiled_sql on success, or error details on failure.
        Never raises — all errors captured in CompileResult.
        """
        settings = get_settings()
        if timeout is None:
            timeout = settings.dbt_compile_timeout

        logger.info(
            "Starting dbt compile for model=%s dbt_version=%s",
            model_name,
            dbt_version,
        )
        start = time.monotonic()

        try:
            venv_dir = self.ensure_venv(dbt_version)
            dbt_bin = str(venv_dir / "bin" / "dbt")

            cmd = [
                dbt_bin,
                "compile",
                "--select",
                model_name,
                "--profiles-dir",
                profiles_dir,
                "--project-dir",
                project_dir,
            ]
            if target_name:
                cmd.extend(["--target", target_name])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=os.environ.copy(),
            )

            stdout = result.stdout or ""
            stderr = (result.stderr or "")[:_STDERR_MAX_BYTES]

            # Read compiled SQL from target directory
            compiled_sql = self._find_compiled_sql(project_dir, model_name)

            duration_ms = int((time.monotonic() - start) * 1000)
            success = result.returncode == 0 and compiled_sql is not None

            if success:
                logger.info(
                    "dbt compile succeeded: model=%s duration_ms=%d exit_code=%d",
                    model_name,
                    duration_ms,
                    result.returncode,
                )
            else:
                # dbt often writes errors to stdout, so log both
                output_detail = stderr[:2000] or stdout[:2000]
                logger.warning(
                    "dbt compile failed: model=%s duration_ms=%d exit_code=%d output=%s",
                    model_name,
                    duration_ms,
                    result.returncode,
                    output_detail,
                )

            return CompileResult(
                compiled_sql=compiled_sql,
                success=success,
                exit_code=result.returncode,
                stdout=stdout,
                stderr=stderr,
                duration_ms=duration_ms,
            )

        except subprocess.TimeoutExpired:
            duration_ms = int((time.monotonic() - start) * 1000)
            return CompileResult(
                success=False,
                exit_code=-1,
                stderr=f"Compile timed out after {timeout}s",
                duration_ms=duration_ms,
            )
        except (subprocess.CalledProcessError, OSError, RuntimeError) as exc:
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.warning(
                "dbt compile exception: model=%s duration_ms=%d error=%s",
                model_name,
                duration_ms,
                exc,
            )
            return CompileResult(
                success=False,
                exit_code=-1,
                stderr=str(exc)[:_STDERR_MAX_BYTES],
                duration_ms=duration_ms,
            )

    def parse_project(
        self,
        project_dir: str,
        dbt_version: str,
        profile_name: str,
        timeout: int | None = None,
    ) -> ParseResult:
        """Parse a dbt project without BQ connection (for context enrichment).

        Returns ParseResult with manifest dict on success, or error details on failure.
        Never raises — all errors captured in ParseResult.
        """
        settings = get_settings()
        if timeout is None:
            timeout = settings.dbt_compile_timeout

        logger.info(
            "Starting dbt parse for project=%s dbt_version=%s",
            project_dir,
            dbt_version,
        )
        start = time.monotonic()
        profiles_dir: str | None = None

        try:
            venv_dir = self.ensure_venv(dbt_version)
            dbt_bin = str(venv_dir / "bin" / "dbt")

            # Generate stub profiles (no real credentials needed for parse)
            profiles_dir = ProfilesGenerator.generate_parse_profiles(
                profile_name=profile_name,
            )

            result = subprocess.run(
                [
                    dbt_bin,
                    "parse",
                    "--profiles-dir",
                    profiles_dir,
                    "--project-dir",
                    project_dir,
                ],
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            stderr = (result.stderr or "")[:_STDERR_MAX_BYTES]

            # Read manifest.json from target directory
            manifest = self._read_manifest(project_dir)

            duration_ms = int((time.monotonic() - start) * 1000)
            return ParseResult(
                manifest=manifest,
                success=result.returncode == 0 and manifest is not None,
                exit_code=result.returncode,
                stderr=stderr,
                duration_ms=duration_ms,
            )

        except subprocess.TimeoutExpired:
            duration_ms = int((time.monotonic() - start) * 1000)
            return ParseResult(
                success=False,
                exit_code=-1,
                stderr=f"Parse timed out after {timeout}s",
                duration_ms=duration_ms,
            )
        except (subprocess.CalledProcessError, OSError, RuntimeError) as exc:
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.warning("dbt parse failed: %s", exc)
            return ParseResult(
                success=False,
                exit_code=-1,
                stderr=str(exc)[:_STDERR_MAX_BYTES],
                duration_ms=duration_ms,
            )
        finally:
            if profiles_dir:
                try:
                    import shutil

                    shutil.rmtree(profiles_dir, ignore_errors=True)
                except OSError:
                    pass

    def build_models(
        self,
        project_dir: str,
        selector: str,
        dbt_version: str,
        profiles_dir: str,
        target_name: str | None = None,
        timeout: int = 600,
    ) -> BuildResult:
        """Run dbt build with a selector (e.g., 'model_name+' for downstream).

        Returns BuildResult with run_results dict on success, or error details.
        Never raises — all errors captured in BuildResult.
        """
        logger.info(
            "Starting dbt build: selector=%s dbt_version=%s project=%s",
            selector,
            dbt_version,
            project_dir,
        )
        start = time.monotonic()

        try:
            venv_dir = self.ensure_venv(dbt_version)
            dbt_bin = str(venv_dir / "bin" / "dbt")

            cmd = [
                dbt_bin,
                "build",
                "--select",
                selector,
                "--profiles-dir",
                profiles_dir,
                "--project-dir",
                project_dir,
            ]
            if target_name:
                cmd.extend(["--target", target_name])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=os.environ.copy(),
            )

            stdout = result.stdout or ""
            stderr = (result.stderr or "")[:_STDERR_MAX_BYTES]
            duration_ms = int((time.monotonic() - start) * 1000)

            # Read run_results.json from target directory
            run_results = self._read_run_results(project_dir)
            models_count = 0
            if run_results and "results" in run_results:
                models_count = len(run_results["results"])

            success = result.returncode == 0

            if success:
                logger.info(
                    "dbt build succeeded: selector=%s models=%d duration_ms=%d",
                    selector,
                    models_count,
                    duration_ms,
                )
            else:
                output_detail = stderr[:2000] or stdout[:2000]
                logger.warning(
                    "dbt build failed: selector=%s exit_code=%d output=%s",
                    selector,
                    result.returncode,
                    output_detail,
                )

            return BuildResult(
                success=success,
                exit_code=result.returncode,
                run_results=run_results,
                models_count=models_count,
                stdout=stdout,
                stderr=stderr,
                duration_ms=duration_ms,
            )

        except subprocess.TimeoutExpired:
            duration_ms = int((time.monotonic() - start) * 1000)
            # Try to read partial run_results even on timeout
            run_results = self._read_run_results(project_dir)
            models_count = len(run_results.get("results", [])) if run_results else 0
            return BuildResult(
                success=False,
                exit_code=-1,
                run_results=run_results,
                models_count=models_count,
                stderr=f"Build timed out after {timeout}s",
                duration_ms=duration_ms,
            )
        except (subprocess.CalledProcessError, OSError, RuntimeError) as exc:
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.warning(
                "dbt build exception: selector=%s error=%s", selector, exc
            )
            return BuildResult(
                success=False,
                exit_code=-1,
                stderr=str(exc)[:_STDERR_MAX_BYTES],
                duration_ms=duration_ms,
            )

    def build_models_streaming(
        self,
        project_dir: str,
        selector: str,
        dbt_version: str,
        profiles_dir: str,
        target_name: str | None = None,
        timeout: int = 600,
        output_callback=None,  # Callable[[str], None] — invoked per stdout line
    ) -> BuildResult:
        """Like build_models, but streams stdout line-by-line via callback.

        Uses Popen + line-buffered stdout so downstream UIs can show live
        progress while dbt runs. All other semantics match build_models.
        """
        logger.info(
            "Starting dbt build (streaming): selector=%s dbt_version=%s project=%s",
            selector,
            dbt_version,
            project_dir,
        )
        start = time.monotonic()

        try:
            venv_dir = self.ensure_venv(dbt_version)
            dbt_bin = str(venv_dir / "bin" / "dbt")
            cmd = [
                dbt_bin,
                "build",
                "--select",
                selector,
                "--profiles-dir",
                profiles_dir,
                "--project-dir",
                project_dir,
            ]
            if target_name:
                cmd.extend(["--target", target_name])

            # ``PYTHONUNBUFFERED=1`` forces dbt's own Python runtime to
            # flush stdout on every newline instead of block-buffering it
            # 4-8 KB at a time. Without this, streaming consumers (the
            # shadow-validation terminal in the UI) see bursts — or long
            # stalls — rather than line-by-line progress while dbt parses
            # and compiles.
            env = os.environ.copy()
            env["PYTHONUNBUFFERED"] = "1"

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,  # line-buffered on our side; PYTHONUNBUFFERED covers dbt's side
                env=env,
            )

            collected: list[str] = []
            try:
                assert proc.stdout is not None
                for line in proc.stdout:
                    line = line.rstrip("\n")
                    collected.append(line)
                    if output_callback is not None:
                        try:
                            output_callback(line)
                        except Exception as cb_err:  # noqa: BLE001
                            logger.debug("output_callback raised: %s", cb_err)
                exit_code = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
                duration_ms = int((time.monotonic() - start) * 1000)
                run_results = self._read_run_results(project_dir)
                return BuildResult(
                    success=False,
                    exit_code=-1,
                    run_results=run_results,
                    models_count=(
                        len(run_results.get("results", [])) if run_results else 0
                    ),
                    stderr=f"Build timed out after {timeout}s",
                    duration_ms=duration_ms,
                )

            duration_ms = int((time.monotonic() - start) * 1000)
            run_results = self._read_run_results(project_dir)
            models_count = 0
            if run_results and "results" in run_results:
                models_count = len(run_results["results"])
            combined = "\n".join(collected)
            stderr_excerpt = combined[-_STDERR_MAX_BYTES:]
            return BuildResult(
                success=(exit_code == 0),
                exit_code=exit_code,
                run_results=run_results,
                models_count=models_count,
                stdout=combined,
                stderr="" if exit_code == 0 else stderr_excerpt,
                duration_ms=duration_ms,
            )
        except (OSError, RuntimeError) as exc:
            duration_ms = int((time.monotonic() - start) * 1000)
            return BuildResult(
                success=False,
                exit_code=-1,
                stderr=str(exc)[:_STDERR_MAX_BYTES],
                duration_ms=duration_ms,
            )

    def _read_run_results(self, project_dir: str) -> dict | None:
        """Read run_results.json from target/ directory."""
        rr_path = Path(project_dir) / "target" / "run_results.json"
        if not rr_path.exists():
            return None
        try:
            return json.loads(rr_path.read_text())
        except (json.JSONDecodeError, OSError):
            return None

    def _find_compiled_sql(self, project_dir: str, model_name: str) -> str | None:
        """Find compiled SQL in target/compiled/ directory."""
        target_dir = Path(project_dir) / "target" / "compiled"
        if not target_dir.exists():
            return None

        # Search for model_name.sql recursively in target/compiled/
        for sql_file in target_dir.rglob(f"{model_name}.sql"):
            return sql_file.read_text()

        return None

    def _read_manifest(self, project_dir: str) -> dict | None:
        """Read manifest.json from target/ directory."""
        manifest_path = Path(project_dir) / "target" / "manifest.json"
        if not manifest_path.exists():
            return None

        try:
            return json.loads(manifest_path.read_text())
        except (json.JSONDecodeError, OSError):
            return None
