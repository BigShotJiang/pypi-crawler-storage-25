"""Governor engine package — detection, solutions, agents, shadow validation."""

from governor_core.google_sdk_compat import apply_google_sdk_py314_compat

apply_google_sdk_py314_compat()

__version__ = "0.7.0"
