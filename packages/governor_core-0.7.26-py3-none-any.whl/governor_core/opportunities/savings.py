"""Shared savings computation used by both the Dashboard and the
Opportunity Explorer.

Savings numbers come from **one source only**: the shadow validation
cascade (dbt build baseline vs shadow, run against live BigQuery). No
heuristics, no detection-time estimates, no pre-flight dry-run deltas.

Contract:
    compute_possible_savings_for_opportunity(...) returns the savings
    delta observed by the last succeeded shadow validation for that
    opportunity, or Decimal("0") if none exists or the delta is
    non-positive. The function is pure — callers load the shadow data
    via get_latest_shadow_savings_map() and pass it in.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from governor_core.opportunities.presentation import to_decimal


def get_latest_shadow_savings_map(
    db: Session, opp_ids: list[str]
) -> dict[str, Decimal]:
    """Return a mapping of ``opportunity_id`` → shadow-validated savings.

    ``ShadowValidationRun.cost_delta_usd`` is defined as
    ``total_shadow_cost_usd - total_baseline_cost_usd`` (see
    ``shadow.diff.Diff.cost_delta_usd``). A cheaper proposed build has a
    NEGATIVE delta, so displayed savings are ``-delta``. We take the
    latest succeeded run per opportunity and clamp proposals that made
    the build more expensive (positive delta) to zero — those contribute
    nothing to the displayed savings total.
    """
    if not opp_ids:
        return {}

    from governor_core.shadow.models import ShadowValidationRun
    from governor_core.solutions.models import Solution

    rows = db.execute(
        select(
            Solution.opportunity_id,
            ShadowValidationRun.cost_delta_usd,
            ShadowValidationRun.updated_at,
        )
        .join(
            ShadowValidationRun,
            ShadowValidationRun.solution_id == Solution.id,
        )
        .where(
            Solution.opportunity_id.in_(opp_ids),
            ShadowValidationRun.status == "succeeded",
        )
        .order_by(ShadowValidationRun.updated_at.desc())
    ).all()

    latest: dict[str, Decimal] = {}
    for opp_id, cost_delta_usd, _updated in rows:
        if opp_id in latest:
            continue  # already captured latest (sorted desc)
        delta = to_decimal(cost_delta_usd)
        if delta is None:
            latest[opp_id] = Decimal("0")
        else:
            # Savings = baseline - shadow = -delta. Clamp to 0.
            latest[opp_id] = max(Decimal("0"), -delta)
    return latest


def compute_possible_savings_for_opportunity(
    *,
    shadow_savings: Decimal | float | int | str | None,
    active_solution_job_status: str | None = None,
    # Remaining kwargs kept for API compatibility with existing callers —
    # they're no longer consulted. Removing them would require touching
    # every call site; keeping them as no-ops keeps the blast radius small.
    opportunity_type: str | None = None,  # noqa: ARG001
    expected_savings: Any = None,  # noqa: ARG001
    occurrence_count: int | None = None,  # noqa: ARG001
    latest_solution: dict[str, Any] | None = None,  # noqa: ARG001
    workload_per_run_savings: Any = None,  # noqa: ARG001
) -> Decimal:
    """Return the shadow-validated savings for one opportunity.

    Returns Decimal("0") when:
      * a SolutionJob is still queued/in_progress (shadow hasn't run yet),
      * no succeeded ShadowValidationRun exists for this opportunity,
      * the shadow delta is zero or negative.
    """
    if active_solution_job_status in ("queued", "in_progress"):
        return Decimal("0")

    delta = to_decimal(shadow_savings)
    if delta is None or delta <= 0:
        return Decimal("0")
    return delta
