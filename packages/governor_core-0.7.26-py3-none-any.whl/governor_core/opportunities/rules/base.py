"""
Base detection rule interface and data classes.

Provides the abstract base class that all detection rules must implement,
and the OpportunityCandidate dataclass for detection results.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


AnalysisSurface = Literal["build", "consumption", "ingestion"]


@dataclass
class OpportunityCandidate:
    """
    Candidate opportunity produced by a detection rule.

    Contains all data needed to create or update an Opportunity record.
    """

    opportunity_type: str
    affected_table: str
    severity_score: int  # 1-100
    evidence_snapshot: dict[str, Any]
    current_cost_estimate: Decimal
    expected_savings: Decimal
    explanation: str
    related_job_ids: list[str]
    dbt_model_name: str | None = None
    config_id: str | None = None
    confidence: float = 1.0  # 0.0-1.0, used for severity adjustment


class BaseDetectionRule(ABC):
    """
    Abstract base class for detection rules.

    Each rule implements detection logic for one opportunity type.
    Rules are stateless and receive all data needed via detect().
    """

    @property
    @abstractmethod
    def rule_type(self) -> str:
        """
        Unique identifier for this rule type.

        Examples: 'shuffle_spill', 'slot_contention', 'join_explosion'
        """
        pass

    @property
    @abstractmethod
    def default_thresholds(self) -> dict[str, Any]:
        """
        Default threshold configuration for this rule.

        These can be overridden via configuration.
        """
        pass

    @property
    def display_name(self) -> str:
        """Human-friendly rule name for UI surfaces."""
        return self.rule_type.replace("_", " ").title()

    @property
    def description(self) -> str:
        """Short UI-facing description of the rule."""
        return ""

    @property
    def analysis_surface(self) -> AnalysisSurface:
        """Return which warehouse layer this rule analyzes."""
        return "build"

    @abstractmethod
    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """
        Analyze jobs and return detected opportunities.

        Args:
            jobs: BigQuery job records for the project
            manifest_content: dbt manifest JSON (may be None)
            thresholds: Threshold configuration (merged with defaults)

        Returns:
            List of OpportunityCandidate (may be empty)

        Implementation Notes:
            - Handle incomplete data gracefully (reduced confidence)
            - Generate actionable explanations
            - Include evidence snapshot with detection metrics
            - Return empty list if no opportunities detected
        """
        pass

    def get_thresholds(
        self, config_thresholds: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Merge configuration thresholds with defaults.

        Args:
            config_thresholds: Optional threshold overrides

        Returns:
            Merged threshold configuration
        """
        thresholds = self.default_thresholds.copy()
        if config_thresholds:
            thresholds.update(config_thresholds)
        return thresholds

    def correlate_dbt_model(
        self,
        table_name: str,
        manifest_content: dict | None,
    ) -> str | None:
        """
        Find dbt model name for a given table.

        Args:
            table_name: Full table name (project.dataset.table)
            manifest_content: dbt manifest JSON

        Returns:
            dbt model name if found, None otherwise
        """
        if not manifest_content:
            return None

        nodes = manifest_content.get("nodes", {})
        for node_id, node in nodes.items():
            if not node_id.startswith("model."):
                continue

            # Check if node's relation_name matches the table
            relation_name = node.get("relation_name")
            if relation_name and relation_name.lower() == table_name.lower():
                return node.get("name")

            # Also check database.schema.identifier combination
            database = node.get("database", "")
            schema = node.get("schema", "")
            identifier = node.get("identifier") or node.get("name", "")
            full_name = f"{database}.{schema}.{identifier}"
            if full_name.lower() == table_name.lower():
                return node.get("name")

        return None
