"""Dead Column Detection Rule.

Identifies columns selected within a CTE of a dbt model that are never
referenced by any subsequent CTE or the model's final SELECT. Analysis
is entirely intra-model — no downstream lineage required.

Signal: dbt manifest raw_code SQL parsing (sqlglot)
Confidence: 0.65 — savings estimate assumes uniform column width
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from governor_core.dbt.column_analyzer import (
    CteDeadColumns,
    IntraModelAnalysis,
    analyze_all_intra_model,
)
from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


class DeadColumnRule(BaseDetectionRule):
    """
    Detects dead columns — columns selected in a CTE that are never referenced
    by any subsequent CTE or the model's final SELECT within the same model.

    Signal: dbt manifest raw_code / compiled_code parsed by sqlglot
    Confidence: 0.65 (savings estimate assumes uniform column width distribution)
    """

    @property
    def rule_type(self) -> str:
        return "dead_column"

    @property
    def display_name(self) -> str:
        return "Dead Column"

    @property
    def description(self) -> str:
        return "Detect plain projected columns in reachable dbt model CTEs that are never referenced downstream."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "enabled": True,
            "min_dead_columns": 1,
            "min_column_count": 3,  # kept for API compatibility
            "excluded_column_patterns": [],
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """Analyse manifest for intra-model dead column opportunities.

        Args:
            jobs: BigQuery job records (used for savings estimation only).
            manifest_content: dbt manifest JSON dict (required).
            thresholds: Threshold configuration.

        Returns:
            List of OpportunityCandidate, one per model with dead columns in CTEs.
        """
        if not manifest_content:
            return []

        min_dead = thresholds.get("min_dead_columns", 1)
        excluded = thresholds.get("excluded_column_patterns", [])

        # Build table → jobs index for savings estimation
        jobs_by_table: dict[str, list[BigQueryJob]] = {}
        for job in jobs:
            if job.destination_table:
                jobs_by_table.setdefault(job.destination_table, []).append(job)

        analyses = analyze_all_intra_model(
            manifest_content,
            min_dead_columns=min_dead,
            excluded_patterns=excluded,
        )
        analyses = self._filter_to_plain_columns(analyses, min_dead)

        candidates: list[OpportunityCandidate] = []
        for analysis in analyses:
            candidate = self._build_candidate(analysis, jobs_by_table)
            if candidate:
                candidates.append(candidate)

        return candidates

    def _filter_to_plain_columns(
        self,
        analyses: list[IntraModelAnalysis],
        min_dead_columns: int,
    ) -> list[IntraModelAnalysis]:
        """Keep only dead outputs that are plain projected columns.

        Window and aggregate outputs are surfaced by dedicated rules.
        """
        filtered_results: list[IntraModelAnalysis] = []
        for analysis in analyses:
            filtered_ctes: list[CteDeadColumns] = []
            for cte in analysis.cte_dead_columns:
                matching_dead = [
                    col
                    for col in cte.dead_columns
                    if cte.dead_column_categories.get(col) == "column"
                ]
                if len(matching_dead) < min_dead_columns:
                    continue

                filtered_ctes.append(
                    CteDeadColumns(
                        cte_name=cte.cte_name,
                        dead_columns=matching_dead,
                        all_columns=cte.all_columns,
                        dead_column_categories={
                            col: cte.dead_column_categories[col]
                            for col in matching_dead
                        },
                        all_column_categories=cte.all_column_categories,
                    )
                )

            if filtered_ctes:
                filtered_results.append(
                    IntraModelAnalysis(
                        model_unique_id=analysis.model_unique_id,
                        model_name=analysis.model_name,
                        affected_table=analysis.affected_table,
                        raw_code=analysis.raw_code,
                        cte_dead_columns=filtered_ctes,
                    )
                )

        return filtered_results

    def _build_candidate(
        self,
        analysis: IntraModelAnalysis,
        jobs_by_table: dict[str, list[BigQueryJob]],
    ) -> OpportunityCandidate | None:
        """Build an OpportunityCandidate from an IntraModelAnalysis result."""
        table_jobs = jobs_by_table.get(analysis.affected_table, [])
        byte_samples = [
            j.total_bytes_processed
            for j in table_jobs
            if j.total_bytes_processed is not None
        ]
        avg_bytes = sum(byte_samples) / len(byte_samples) if byte_samples else 0.0

        # Aggregate dead columns across all flagged CTEs
        all_dead_cols = [
            col for cte in analysis.cte_dead_columns for col in cte.dead_columns
        ]
        all_cols_count = sum(len(cte.all_columns) for cte in analysis.cte_dead_columns)
        dead_count = len(all_dead_cols)
        dead_fraction = dead_count / max(all_cols_count, 1)

        avg_cost_per_run = estimate_cost_from_bytes_processed(avg_bytes)
        cost_saved = estimate_cost_from_bytes_processed(avg_bytes * dead_fraction)

        severity = calculate_severity(
            estimated_savings=cost_saved,
            confidence=0.65,
            frequency=len(table_jobs),
        )

        # Build explanation
        cte_parts = []
        for cte in analysis.cte_dead_columns:
            dead_str = ", ".join(f"'{c}'" for c in cte.dead_columns)
            cte_parts.append(
                f"CTE '{cte.cte_name}' selects {dead_str} but never uses "
                f"{'it' if len(cte.dead_columns) == 1 else 'them'} downstream"
            )

        explanation = (
            f"Model '{analysis.model_name}' has {dead_count} column(s) selected in "
            f"CTE(s) that are never referenced by subsequent CTEs or the final SELECT. "
            f"{'. '.join(cte_parts)}. "
            f"Removing these columns reduces computation at every materialisation. "
            f"Savings estimate assumes uniform column width (confidence: 0.65)."
        )

        cte_dead_for_evidence = [
            {
                "cte_name": cte.cte_name,
                "dead_columns": cte.dead_columns,
                "all_columns": cte.all_columns,
            }
            for cte in analysis.cte_dead_columns
        ]

        evidence: dict[str, Any] = {
            "dead_columns": all_dead_cols,
            "cte_dead_columns": cte_dead_for_evidence,
            "total_columns": all_cols_count,
            "dead_count": dead_count,
            "model_cte_count": len(analysis.cte_dead_columns),
            "estimated_bytes_saved_per_run": round(avg_bytes * dead_fraction),
            "sample_job_count": len(table_jobs),
            "sample_job_count_with_bytes": len(byte_samples),
        }

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=analysis.affected_table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=avg_cost_per_run,
            expected_savings=cost_saved,
            explanation=explanation,
            related_job_ids=[j.job_id for j in table_jobs[:10]],
            dbt_model_name=analysis.model_name,
            confidence=0.65,
        )
