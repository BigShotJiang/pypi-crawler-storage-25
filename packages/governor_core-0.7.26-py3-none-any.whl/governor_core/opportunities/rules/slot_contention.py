"""
Slot Contention Detection Rule.

Detects queries experiencing slot contention using BigQuery's `slot_contention`
signal and queue time calculation.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Any

from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.opportunities.scoring import calculate_severity, estimate_savings_from_cost

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


class SlotContentionRule(BaseDetectionRule):
    """
    Detects slot contention opportunities from BigQuery performance insights
    and queue time analysis.

    Signal: slot_contention == true (primary) OR queue_time_ratio > 30% (secondary)
    Confidence: HIGH - Direct boolean signal plus reliable timestamp calculation
    """

    @property
    def rule_type(self) -> str:
        return "slot_contention"

    @property
    def display_name(self) -> str:
        return "Slot Contention"

    @property
    def description(self) -> str:
        return (
            "Detect queries that spend significant time queued or contending for slots."
        )

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "queue_time_ratio_threshold": 0.30,  # 30% of total time in queue
            "min_duration_seconds": 60,  # Minimum 1 minute total duration
            "min_job_cost_usd": Decimal("0"),  # BigQuery ML signals are high-confidence
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """
        Analyze jobs for slot contention issues.

        Triggers:
        1. slot_contention == true for any stage (confidence: 1.0)
        2. queue_time / total_time > 30% (confidence: 0.9)
        """
        queue_time_ratio_threshold = thresholds.get("queue_time_ratio_threshold", 0.30)
        min_duration = thresholds.get("min_duration_seconds", 60)
        min_cost = thresholds.get("min_job_cost_usd", Decimal("0.10"))

        candidates: list[OpportunityCandidate] = []
        table_jobs: dict[
            str, list[tuple[BigQueryJob, float, float]]
        ] = {}  # (job, queue_ratio, confidence)

        for job in jobs:
            # Skip jobs without destination table
            if not job.destination_table:
                continue

            # Skip low-cost jobs
            if job.total_cost is None or job.total_cost < min_cost:
                continue

            # Skip short queries
            duration_sec = (job.duration_ms or 0) / 1000
            if duration_sec < min_duration:
                continue

            # Check for contention signals
            has_flag, flag_confidence = self._check_slot_contention_flag(job)
            queue_ratio = self._calculate_queue_ratio(job)

            confidence = 0.0
            detected = False

            # Direct flag takes precedence
            if has_flag:
                confidence = flag_confidence
                detected = True
            elif queue_ratio is not None and queue_ratio > queue_time_ratio_threshold:
                confidence = 0.9
                detected = True

            if not detected:
                continue

            # Group by table
            table = job.destination_table
            if table not in table_jobs:
                table_jobs[table] = []
            table_jobs[table].append((job, queue_ratio or 0, confidence))

        # Create opportunity for each affected table
        for table, job_data in table_jobs.items():
            candidate = self._create_candidate(
                table, job_data, manifest_content, thresholds
            )
            if candidate:
                candidates.append(candidate)

        return candidates

    def _check_slot_contention_flag(self, job: BigQueryJob) -> tuple[bool, float]:
        """
        Check if job has slot_contention signal.

        Returns (has_flag, confidence)
        """
        if not job.performance_insights:
            return False, 0.0

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])

        for stage in stages:
            if stage.get("slot_contention") is True:
                return True, 1.0

        return False, 0.0

    def _calculate_queue_ratio(self, job: BigQueryJob) -> float | None:
        """
        Calculate queue time as ratio of total time.

        queue_ratio = (start_time - creation_time) / (end_time - creation_time)
        """
        if not job.creation_time or not job.start_time or not job.end_time:
            return None

        creation = job.creation_time
        start = job.start_time
        end = job.end_time

        # Ensure timestamps are comparable
        if (
            isinstance(creation, datetime)
            and isinstance(start, datetime)
            and isinstance(end, datetime)
        ):
            total_time = (end - creation).total_seconds()
            queue_time = (start - creation).total_seconds()

            if total_time <= 0:
                return None

            return queue_time / total_time

        return None

    def _create_candidate(
        self,
        table: str,
        job_data: list[
            tuple[BigQueryJob, float, float]
        ],  # (job, queue_ratio, confidence)
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> OpportunityCandidate | None:
        """Create opportunity candidate for a table with slot contention."""
        if not job_data:
            return None

        jobs = [j for j, _, _ in job_data]
        queue_ratios = [q for _, q, _ in job_data]
        confidences = [c for _, _, c in job_data]

        # Aggregate metrics
        total_cost = sum(j.total_cost or Decimal("0") for j in jobs)
        total_slot_ms = sum(j.total_slot_ms or 0 for j in jobs)
        avg_queue_ratio = sum(queue_ratios) / len(queue_ratios) if queue_ratios else 0
        max_confidence = max(confidences) if confidences else 0.9

        # Get representative job
        representative = max(jobs, key=lambda j: j.total_cost or Decimal("0"))

        # Calculate queue time for representative
        queue_seconds = 0.0
        execution_seconds = 0.0
        if (
            representative.creation_time
            and representative.start_time
            and representative.end_time
        ):
            queue_seconds = (
                representative.start_time - representative.creation_time
            ).total_seconds()
            execution_seconds = (
                representative.end_time - representative.start_time
            ).total_seconds()

        # Estimate savings (slot contention typically adds 20-30% overhead)
        expected_savings = estimate_savings_from_cost(total_cost, 20.0)

        # Calculate severity
        severity = calculate_severity(
            estimated_savings=expected_savings,
            confidence=max_confidence,
            frequency=len(jobs),
        )

        # Check for direct flag
        has_flag, _ = self._check_slot_contention_flag(representative)

        # Build evidence snapshot
        evidence = {
            "slot_contention_flag": has_flag,
            "queue_time_seconds": round(queue_seconds, 1),
            "execution_time_seconds": round(execution_seconds, 1),
            "queue_ratio_percent": round(avg_queue_ratio * 100, 1),
            "total_slot_ms": total_slot_ms,
            "job_cost_usd": float(total_cost),
            "affected_job_count": len(jobs),
            "sample_job_ids": [j.job_id for j in jobs[:5]],
        }

        # Generate explanation
        queue_pct = round(avg_queue_ratio * 100, 1)
        explanation = (
            f"Queries on table '{table}' experienced slot contention, "
            f"waiting {round(queue_seconds)}s in queue ({queue_pct}% of total time). "
            f"This indicates resource pressure. Consider: scheduling during off-peak hours, "
            f"optimizing concurrent query patterns, or reviewing slot reservation allocation."
        )

        # Correlate with dbt model
        dbt_model = self.correlate_dbt_model(table, manifest_content)

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=total_cost,
            expected_savings=expected_savings,
            explanation=explanation,
            related_job_ids=[j.job_id for j in jobs],
            dbt_model_name=dbt_model,
            confidence=max_confidence,
        )
