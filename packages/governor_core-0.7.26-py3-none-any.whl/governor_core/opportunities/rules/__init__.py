"""
Detection rules module.

Contains pluggable detection rules for identifying cost optimization opportunities.
"""

from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate

__all__ = ["BaseDetectionRule", "OpportunityCandidate"]
