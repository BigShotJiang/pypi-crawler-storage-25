"""Cross-project opportunity explorer service.

Provides query methods for browsing, filtering, sorting, and grouping
opportunities across all projects.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import Select, and_, case, false, func, or_, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from governor_core.configurations.models import ManifestConfiguration
from governor_core.opportunities.catalog import (
    build_effective_rule_selection,
    get_detection_rule_catalog,
)
from governor_core.opportunities.models import DetectionJob, Opportunity, OpportunitySavingsEstimate
from governor_core.opportunities.presentation import (
    build_inherited_pending_savings_display,
    build_cost_display,
    build_possible_savings_display,
    get_exact_local_workload_kinds,
    get_active_solution_job_statuses,
    get_last_job_details,
    get_latest_solution_snapshots,
    get_permanently_failed_opp_ids,
    to_decimal,
)
from governor_core.opportunities.recommendation_state import resolve_state
from governor_core.opportunities.savings import (
    compute_possible_savings_for_opportunity,
    get_latest_shadow_savings_map,
)
from governor_core.solutions.models import Solution
from governor_core.utils.pagination import PaginationContext

_TABLE_SORT_COLUMN = func.lower(
    func.coalesce(Opportunity.dbt_model_name, Opportunity.affected_table)
)
_ALWAYS_HIDDEN_EXPLORER_TYPES = (
    "storage_billing_optimization",
    "clustering",
    "clustering_not_leveraged",
)


def _normalize_workload_kind(workload_kind: str | None) -> str:
    if workload_kind in ("build", "consumption"):
        return workload_kind
    # All Governor opportunities target manifest-managed dbt models.
    # When job metadata is missing, default to "build" rather than
    # showing a misleading "other/query" label.
    return "build"


def _apply_status_filter(
    base: Select, status: str, *, collapse_pending_states: bool = False
) -> Select:
    """Apply an opportunity status filter, optionally collapsing pending states."""
    if status == "active":
        return base.where(Opportunity.status == "active")
    if status == "resolved":
        return base.where(Opportunity.status == "resolved")
    if status in {"pr_pending", "clearing"}:
        if collapse_pending_states:
            return base.where(Opportunity.status.in_(("pr_pending", "clearing")))
        return base.where(Opportunity.status == status)
    return base


# State sort priority: Safe first, then Upstream fix, then others
_STATE_SORT = case(
    (
        and_(
            Opportunity.latest_solution_id.isnot(None),
            Opportunity.latest_solution_risk_level == "low",
        ),
        1,
    ),
    (Opportunity.cascade_status == "delegated", 2),
    (
        and_(
            Opportunity.latest_solution_id.isnot(None),
            Opportunity.latest_solution_risk_level == "medium",
        ),
        3,
    ),
    (
        and_(
            Opportunity.latest_solution_id.isnot(None),
            Opportunity.latest_solution_risk_level == "high",
        ),
        4,
    ),
    else_=5,
)

# Spec 125: worst-case state severity rank for the model-grouped view.
# Higher severity number wins. Safety invariant (FR-004): a model with any
# high_risk finding must never display as safe at the aggregated level.
_MODEL_STATE_SEVERITY_RANK: dict[str, int] = {
    "high_risk": 8,
    "failed": 7,
    "requires_review": 6,
    "awaiting": 5,
    "generating": 4,
    "upstream_fix": 3,
    "safe": 2,
    # ``skipped`` (below configured min-cost threshold) is deliberate and
    # benign — ranked lower than ``awaiting`` (not-yet-analyzed) but above
    # ``resolved`` so mixed-state models still surface it.
    "skipped": 1,
    "resolved": 0,
}


def _rollup_worst_state(states: list[str]) -> str:
    """Return the most severe state from a list. Empty list -> 'awaiting'."""
    if not states:
        return "awaiting"
    return max(
        states,
        key=lambda s: _MODEL_STATE_SEVERITY_RANK.get(s, 0),
    )


def _opportunity_to_state_key(
    opp: dict,
    min_cost_by_config: dict[str, float | None] | None = None,
) -> str:
    """Map an opportunity view-dict to a severity-rank state key.

    The mapping mirrors ``resolve_state`` in recommendation_state.py but
    returns one of the keys used by ``_MODEL_STATE_SEVERITY_RANK``
    (high_risk / failed / requires_review / awaiting / generating /
    upstream_fix / safe / skipped / resolved).

    Pass ``min_cost_by_config`` to surface the ``skipped`` state for
    opportunities whose query cost is below the per-config
    ``min_solution_cost_usd`` threshold. Leave it unset to preserve the
    legacy four-terminal behaviour (used by unit tests).
    """
    if opp.get("status") == "resolved":
        return "resolved"
    if opp.get("has_solution"):
        risk = opp.get("solution_risk_level")
        if risk == "high":
            return "high_risk"
        if risk == "medium":
            return "requires_review"
        return "safe"  # low or None-with-solution defaults to safe
    job_status = opp.get("solution_job_status")
    if job_status in ("queued", "in_progress"):
        return "generating"
    if opp.get("cascade_status") == "delegated":
        return "upstream_fix"
    if job_status == "failed":
        return "failed"

    if min_cost_by_config:
        threshold = min_cost_by_config.get(opp.get("config_id"))
        # Mirror the queueing fallback so the grouped explorer stays
        # consistent with the single-opportunity resolver: a NULL
        # column value means "use the system default".
        if threshold is None:
            from governor_core.solutions.service import (
                DEFAULT_MIN_SOLUTION_COST_USD,
            )

            threshold = DEFAULT_MIN_SOLUTION_COST_USD
        cost = opp.get("query_cost_value") or opp.get("current_cost_estimate")
        if (
            float(threshold) > 0
            and cost is not None
            and to_decimal(cost) is not None
            and to_decimal(cost) < to_decimal(threshold)
        ):
            return "skipped"
    return "awaiting"


def _sort_model_groups(
    groups: list[dict], sort_column: str, sort_direction: str
) -> list[dict]:
    """Sort model groups by an aggregate column with a stable alpha tiebreaker."""
    reverse = sort_direction == "desc"

    def key_for(g: dict):
        if sort_column == "project":
            return (g["project_name"] or "", g["dbt_model_name"] or "")
        if sort_column in ("table", "object"):
            return (g["dbt_model_name"] or "", "")
        if sort_column == "cost":
            v = g.get("total_query_cost_value")
            return (v if v is not None else Decimal("-1"), g["dbt_model_name"] or "")
        if sort_column == "savings":
            v = g.get("total_savings_value")
            return (v if v is not None else Decimal("-1"), g["dbt_model_name"] or "")
        if sort_column == "age":
            return (
                g.get("last_detected_at") or datetime.min,
                g["dbt_model_name"] or "",
            )
        # Default / "state": severity rank (lower first when asc)
        return (
            _MODEL_STATE_SEVERITY_RANK.get(g["worst_state"], 0),
            g["dbt_model_name"] or "",
        )

    return sorted(groups, key=key_for, reverse=reverse)


# Column name → SQLAlchemy column mapping for sort
_SORT_COLUMNS = {
    "severity": Opportunity.severity_score,
    "cost": Opportunity.current_cost_estimate,
    "savings": Opportunity.expected_savings,
    "age": Opportunity.last_detected_at,
    "occurrence": Opportunity.occurrence_count,
    "project": ManifestConfiguration.name,
    "type": Opportunity.opportunity_type,
    "table": _TABLE_SORT_COLUMN,
    "status": Opportunity.status,
    "state": _STATE_SORT,
}


def _apply_sort(base, sort_column: str, sort_direction: str) -> Select:
    """Apply a deterministic sort order to opportunity queries."""
    col = _SORT_COLUMNS.get(sort_column, Opportunity.severity_score)
    if sort_column == "table":
        secondary = [
            Opportunity.affected_table.asc(),
            Opportunity.opportunity_type.asc(),
        ]
        if sort_direction == "asc":
            return base.order_by(col.asc(), *secondary)
        return base.order_by(
            col.desc(),
            Opportunity.affected_table.desc(),
            Opportunity.opportunity_type.desc(),
        )
    if sort_column == "state":
        cost_tiebreak = Opportunity.current_cost_estimate.desc().nullslast()
        if sort_direction == "asc":
            return base.order_by(col.asc(), cost_tiebreak)
        return base.order_by(col.desc(), cost_tiebreak)
    if sort_direction == "asc":
        return base.order_by(col.asc())
    return base.order_by(col.desc())


def _get_rule_visibility(
    watched_rule_types: list[str] | None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    catalog = get_detection_rule_catalog()
    known_rule_types = tuple(
        dict.fromkeys(
            [
                *(entry.rule_type.lower() for entry in catalog),
                *_ALWAYS_HIDDEN_EXPLORER_TYPES,
            ]
        )
    )
    selection = build_effective_rule_selection(watched_rule_types, catalog)
    visible_rule_types = tuple(
        rule_type.lower()
        for rule_type in selection.effective_rule_types
        if rule_type not in _ALWAYS_HIDDEN_EXPLORER_TYPES
    )
    return known_rule_types, visible_rule_types


def _load_workload_estimates(
    db: Session, opportunity_ids: list[str]
) -> dict[str, OpportunitySavingsEstimate]:
    if not opportunity_ids:
        return {}

    try:
        rows = (
            db.execute(
                select(OpportunitySavingsEstimate).where(
                    OpportunitySavingsEstimate.opportunity_id.in_(opportunity_ids)
                )
            )
            .scalars()
            .all()
        )
    except SQLAlchemyError:
        return {}

    return {estimate.opportunity_id: estimate for estimate in rows}


class OpportunityExplorerService:
    """Cross-project opportunity query service."""

    def __init__(self, db: Session) -> None:
        self.db = db

    def _get_active_config_visible_types(
        self, project_ids: list[str] | None = None
    ) -> dict[str, tuple[tuple[str, ...], tuple[str, ...]]]:
        query = select(
            ManifestConfiguration.id,
            ManifestConfiguration.watched_rule_types,
        ).where(ManifestConfiguration.status == "active")
        if project_ids:
            query = query.where(ManifestConfiguration.id.in_(project_ids))
        rows = self.db.execute(query).all()
        return {
            config_id: _get_rule_visibility(watched_rule_types)
            for config_id, watched_rule_types in rows
        }

    def _build_visible_opportunity_clause(self, project_ids: list[str] | None = None):
        visible_types_by_config = self._get_active_config_visible_types(project_ids)
        conditions = [
            and_(
                Opportunity.config_id == config_id,
                or_(
                    (
                        func.lower(Opportunity.opportunity_type).in_(visible_types)
                        if visible_types
                        else false()
                    ),
                    (
                        ~func.lower(Opportunity.opportunity_type).in_(known_rule_types)
                        if known_rule_types
                        else false()
                    ),
                ),
            )
            for config_id, (
                known_rule_types,
                visible_types,
            ) in visible_types_by_config.items()
        ]
        if not conditions:
            return false()
        return or_(*conditions)

    # ------------------------------------------------------------------
    # Filter option population (Q5)
    # ------------------------------------------------------------------

    def get_available_projects(self) -> list[tuple[str, str]]:
        """Return (id, name) tuples for all active ManifestConfigurations."""
        rows = self.db.execute(
            select(ManifestConfiguration.id, ManifestConfiguration.name)
            .where(ManifestConfiguration.status == "active")
            .order_by(ManifestConfiguration.name)
        ).all()
        return [(r[0], r[1]) for r in rows]

    def get_available_types(self) -> list[str]:
        """Return currently visible rule types from active configurations."""
        visible_types = {
            rule_type
            for _, types in self._get_active_config_visible_types().values()
            for rule_type in types
        }
        return sorted(visible_types)

    def _latest_local_detection_job_id(self) -> str | None:
        """Return the latest completed detection job ID, or None."""
        return self.db.execute(
            select(DetectionJob.id)
            .where(DetectionJob.status == "completed")
            .order_by(DetectionJob.completed_at.desc())
            .limit(1)
        ).scalar_one_or_none()

    def _apply_local_scope(self, base):
        """No-op in core.

        The CLI scopes to the latest detection job itself before calling the
        explorer; the web surface scopes by user-selected filters. Core never
        applies a 'local' scope — that was a leak of CLI concerns into the
        engine, removed by spec 120.
        """
        return base

    # ------------------------------------------------------------------
    # Flat list query (Q1) with pagination
    # ------------------------------------------------------------------

    def query_opportunities(
        self,
        *,
        search: str = "",
        status: str = "active",
        project_ids: list[str] | None = None,
        type_names: list[str] | None = None,
        sort_column: str = "cost",
        sort_direction: str = "desc",
        page: int = 1,
        page_size: int = 10,
        max_items: int | None = None,
        smart_view: str = "",
        date_start: datetime | None = None,
        date_end: datetime | None = None,
        collapse_pending_states: bool = False,
    ) -> tuple[list[dict], PaginationContext]:
        """Query opportunities with filtering, sorting, and pagination.

        Returns (list of opportunity dicts for current page, PaginationContext).
        """
        visible_clause = self._build_visible_opportunity_clause(project_ids)
        base = (
            select(
                Opportunity,
                ManifestConfiguration.name.label("project_name"),
            )
            .join(
                ManifestConfiguration,
                Opportunity.config_id == ManifestConfiguration.id,
            )
            .where(ManifestConfiguration.status == "active")
            .where(visible_clause)
        )

        base = self._apply_local_scope(base)

        # Apply smart view overrides first
        if smart_view == "quick-wins":
            # Active + has low-risk solution
            base = base.where(Opportunity.status == "active")
            base = base.where(
                Opportunity.id.in_(
                    select(Solution.opportunity_id)
                    .where(Solution.risk_level == "low")
                    .distinct()
                )
            )
            sort_column = "savings"
            sort_direction = "desc"
        elif smart_view == "chronic":
            # Active + occurrence_count > 20
            base = base.where(Opportunity.status == "active")
            base = base.where(Opportunity.occurrence_count > 20)
            sort_column = "occurrence"
            sort_direction = "desc"
        elif smart_view == "unaddressed":
            # Active + no solution + severity >= 70
            base = base.where(Opportunity.status == "active")
            base = base.where(
                ~Opportunity.id.in_(select(Solution.opportunity_id).distinct())
            )
            base = base.where(Opportunity.severity_score >= 70)
            sort_column = "severity"
            sort_direction = "desc"
        else:
            # Apply manual status filter
            base = _apply_status_filter(
                base,
                status,
                collapse_pending_states=collapse_pending_states,
            )

        # Search filter (ILIKE with wildcard escaping)
        if search:
            escaped = (
                search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like_pattern = f"%{escaped}%"
            base = base.where(
                Opportunity.opportunity_type.ilike(like_pattern, escape="\\")
                | Opportunity.affected_table.ilike(like_pattern, escape="\\")
                | Opportunity.dbt_model_name.ilike(like_pattern, escape="\\")
            )

        # Project filter
        if project_ids:
            base = base.where(Opportunity.config_id.in_(project_ids))

        # Type filter
        if type_names:
            base = base.where(
                func.lower(Opportunity.opportunity_type).in_(
                    [type_name.lower() for type_name in type_names]
                )
            )

        # Date range filter
        if date_start:
            base = base.where(Opportunity.created_at >= date_start)
        if date_end:
            base = base.where(Opportunity.created_at <= date_end)

        # Count total
        count_q = select(func.count()).select_from(base.subquery())
        total_items = self.db.execute(count_q).scalar() or 0

        if max_items is not None:
            total_items = min(total_items, max(0, max_items))
            page = 1

        pagination = PaginationContext(
            page=max(1, page), page_size=page_size, total_items=total_items
        )
        # Clamp page
        if pagination.page > pagination.total_pages:
            pagination = PaginationContext(
                page=pagination.total_pages,
                page_size=page_size,
                total_items=total_items,
            )

        # Sort
        base = _apply_sort(base, sort_column, sort_direction)

        # Paginate
        limit = page_size
        offset = (pagination.page - 1) * page_size
        if max_items is not None:
            offset = 0
            limit = min(page_size, max_items)
        rows = self.db.execute(base.offset(offset).limit(limit)).all()

        # Build result dicts
        opp_ids = []
        results = []
        row_opportunities = [row[0] for row in rows]
        # Batch lookup: latest job metadata per opportunity
        last_job_details_map = get_last_job_details(self.db, row_opportunities)
        exact_local_workload_map = (
            get_exact_local_workload_kinds(self.db, row_opportunities)
            if False
            else {}
        )
        active_solution_job_status_map = get_active_solution_job_statuses(
            self.db, [row[0].id for row in rows]
        )
        for row in rows:
            opp: Opportunity = row[0]
            project_name: str = row[1]
            opp_ids.append(opp.id)
            latest_job_details = last_job_details_map.get(opp.id, {})
            workload_kind = (
                exact_local_workload_map.get(opp.id)
                or _normalize_workload_kind(latest_job_details.get("workload_kind"))
                if False
                else _normalize_workload_kind(latest_job_details.get("workload_kind"))
            )
            # Use cached latest_solution fields as fallback for has_solution
            cached_has_solution = opp.latest_solution_id is not None
            cached_risk_level = opp.latest_solution_risk_level if cached_has_solution else None
            results.append(
                {
                    "id": opp.id,
                    "config_id": opp.config_id,
                    "project_name": project_name,
                    "opportunity_type": opp.opportunity_type,
                    "affected_table": opp.affected_table,
                    "dbt_model_name": opp.dbt_model_name,
                    "severity_score": opp.severity_score,
                    "current_cost_estimate": opp.current_cost_estimate,
                    "expected_savings": opp.expected_savings,
                    "status": opp.status,
                    "cascade_status": opp.cascade_status,
                    "cascade_root_id": opp.cascade_root_id,
                    "occurrence_count": opp.occurrence_count,
                    "created_at": opp.created_at,
                    "last_detected_at": opp.last_detected_at,
                    "has_solution": cached_has_solution,
                    "solution_risk_level": cached_risk_level,
                    "avg_query_cost": latest_job_details.get("total_cost"),
                    "dry_run_original_cost": None,
                    "dry_run_modified_cost": None,
                    "query_cost_value": None,
                    "query_cost_source_label": None,
                    "query_workload_kind": workload_kind,
                    "query_workload_label": workload_kind.title()
                    if workload_kind
                    else ("Unclassified" if False else "Query"),
                    "optimized_cost_value": None,
                    "optimized_cost_source_label": None,
                    "optimized_delta_direction": None,
                    "solution_job_status": active_solution_job_status_map.get(opp.id),
                    "prefers_possible_savings_display": False,
                }
            )

        cascade_root_ids = [
            row[0].cascade_root_id
            for row in rows
            if row[0].cascade_status == "delegated" and row[0].cascade_root_id
        ]

        # Batch solution risk + dry run cost lookup
        if opp_ids:
            latest_solution_map = get_latest_solution_snapshots(
                self.db,
                list(dict.fromkeys([*opp_ids, *cascade_root_ids])),
                schedule_missing_dry_runs=True,
            )
            root_opportunities = (
                {
                    opp.id: opp
                    for opp in self.db.execute(
                        select(Opportunity).where(Opportunity.id.in_(cascade_root_ids))
                    )
                    .scalars()
                    .all()
                }
                if cascade_root_ids
                else {}
            )

            wl_estimates_map = _load_workload_estimates(self.db, opp_ids)
            # Single source of truth for row savings: the shadow
            # validation cascade. Per-opp value is the positive
            # ``cost_delta_usd`` (baseline - shadow) of the latest
            # succeeded run, or Decimal(0) when none exists.
            shadow_savings_map = get_latest_shadow_savings_map(self.db, opp_ids)

            for r in results:
                latest_solution = latest_solution_map.get(r["id"])
                if latest_solution:
                    r["has_solution"] = True
                    r["solution_risk_level"] = latest_solution.get("risk_level")
                    r["dry_run_original_cost"] = latest_solution.get(
                        "dry_run_original_cost"
                    )
                    r["dry_run_modified_cost"] = latest_solution.get(
                        "dry_run_modified_cost"
                    )
                    r["prefers_possible_savings_display"] = latest_solution.get(
                        "prefers_possible_savings_display",
                        False,
                    )
                r.update(
                    build_cost_display(
                        current_cost_estimate=r["current_cost_estimate"],
                        latest_job_cost=last_job_details_map.get(r["id"], {}).get(
                            "total_cost"
                        ),
                        dry_run_original_cost=r["dry_run_original_cost"],
                        dry_run_modified_cost=r["dry_run_modified_cost"],
                        use_dry_run_original_for_query_cost=latest_solution.get(
                            "supports_optimized_dry_run",
                            False,
                        )
                        if latest_solution
                        else False,
                        prefer_possible_savings_display=r[
                            "prefers_possible_savings_display"
                        ],
                    )
                )

                r.update(
                    build_possible_savings_display(
                        shadow_savings=shadow_savings_map.get(r["id"]),
                    )
                )
                if r.get("possible_savings_value") is None and r.get("cascade_root_id"):
                    # Delegated cascade row — surface the root model's
                    # shadow savings as "pending" inherited context.
                    root_id = r["cascade_root_id"]
                    root_opp = root_opportunities.get(root_id)
                    r.update(
                        build_inherited_pending_savings_display(
                            root_possible_savings_value=shadow_savings_map.get(
                                root_id
                            ),
                            root_model_name=root_opp.dbt_model_name
                            if root_opp
                            else None,
                        )
                    )

        # Compute recommendation state for each row
        permanently_failed = get_permanently_failed_opp_ids(self.db, opp_ids)
        # Load the per-config minimum-query-cost threshold once so we can
        # mark sub-threshold rows as ``skipped_below_threshold`` instead of
        # letting them sit on the catch-all ``awaiting`` label forever.
        config_min_cost_map = self._load_min_solution_cost_map(
            {r.get("config_id") for r in results if r.get("config_id")}
        )
        for r in results:
            # Check if cascade root has a solution
            root_has_solution = False
            if r.get("cascade_root_id") and opp_ids:
                root_has_solution = bool(
                    latest_solution_map.get(r["cascade_root_id"])
                )
            r["recommendation_state"] = resolve_state(
                opportunity_status=r["status"],
                cascade_status=r.get("cascade_status"),
                cascade_root_has_solution=root_has_solution,
                solution_job_status=r.get("solution_job_status"),
                has_solutions=r.get("has_solution", False),
                has_pr=False,  # PR data not available in explorer list view
                job_permanently_failed=r["id"] in permanently_failed,
                current_cost_estimate=r.get("current_cost_estimate"),
                min_solution_cost_usd=config_min_cost_map.get(r.get("config_id")),
            )

        return results, pagination

    def _load_min_solution_cost_map(
        self, config_ids: set[str | None]
    ) -> dict[str, float | None]:
        """Return a mapping of config_id → min_solution_cost_usd.

        Configs without the column populated fall back to ``None``; the
        caller threads that through to ``resolve_state`` which treats it
        as "no threshold" (i.e. never marks anything ``skipped``).
        """
        config_ids = {cid for cid in config_ids if cid}
        if not config_ids:
            return {}
        rows = self.db.execute(
            select(
                ManifestConfiguration.id,
                ManifestConfiguration.min_solution_cost_usd,
            ).where(ManifestConfiguration.id.in_(config_ids))
        ).all()
        return {row.id: row.min_solution_cost_usd for row in rows}

    # ------------------------------------------------------------------
    # Summary cards aggregation (Q3)
    # ------------------------------------------------------------------

    def get_summary_cards(
        self,
        *,
        search: str = "",
        status: str = "active",
        project_ids: list[str] | None = None,
        type_names: list[str] | None = None,
        smart_view: str = "",
        date_start: datetime | None = None,
        date_end: datetime | None = None,
        collapse_pending_states: bool = False,
    ) -> dict:
        """Return aggregated summary metrics for filtered opportunities."""
        visible_clause = self._build_visible_opportunity_clause(project_ids)
        base = (
            select(Opportunity)
            .join(
                ManifestConfiguration,
                Opportunity.config_id == ManifestConfiguration.id,
            )
            .where(ManifestConfiguration.status == "active")
            .where(visible_clause)
        )

        # (Legacy local-mode scoping removed in spec 120; CLI scopes externally.)

        # Apply same filters as query_opportunities
        if smart_view == "quick-wins":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                Opportunity.id.in_(
                    select(Solution.opportunity_id)
                    .where(Solution.risk_level == "low")
                    .distinct()
                )
            )
        elif smart_view == "chronic":
            base = base.where(Opportunity.status == "active")
            base = base.where(Opportunity.occurrence_count > 20)
        elif smart_view == "unaddressed":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                ~Opportunity.id.in_(select(Solution.opportunity_id).distinct())
            )
            base = base.where(Opportunity.severity_score >= 70)
        else:
            base = _apply_status_filter(
                base,
                status,
                collapse_pending_states=collapse_pending_states,
            )

        if search:
            escaped = (
                search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like_pattern = f"%{escaped}%"
            base = base.where(
                Opportunity.opportunity_type.ilike(like_pattern, escape="\\")
                | Opportunity.affected_table.ilike(like_pattern, escape="\\")
                | Opportunity.dbt_model_name.ilike(like_pattern, escape="\\")
            )

        if project_ids:
            base = base.where(Opportunity.config_id.in_(project_ids))
        if type_names:
            base = base.where(
                func.lower(Opportunity.opportunity_type).in_(
                    [type_name.lower() for type_name in type_names]
                )
            )
        if date_start:
            base = base.where(Opportunity.created_at >= date_start)
        if date_end:
            base = base.where(Opportunity.created_at <= date_end)

        # Build subquery from filtered set
        sub = base.subquery()

        visible_opps = (
            self.db.execute(
                select(Opportunity).where(Opportunity.id.in_(select(sub.c.id)))
            )
            .scalars()
            .all()
        )
        active_opps = [opp for opp in visible_opps if opp.status == "active"]
        active_count = len(active_opps)
        visible_opportunity_ids = [o.id for o in visible_opps]

        latest_solution_map = get_latest_solution_snapshots(
            self.db, visible_opportunity_ids
        )
        # Single source of truth: latest succeeded shadow validation run
        # per opportunity. All "savings" figures on this page derive from
        # it — no dry-run, no heuristic.
        shadow_savings_map = get_latest_shadow_savings_map(
            self.db, visible_opportunity_ids
        )
        process_cost_map = {
            o.id: o.process_cost_usd or Decimal("0") for o in visible_opps
        }
        total_savings = Decimal("0")
        for opportunity_id in visible_opportunity_ids:
            shadow_delta = shadow_savings_map.get(opportunity_id)
            if shadow_delta is None or shadow_delta <= 0:
                continue
            process_cost = process_cost_map.get(opportunity_id, Decimal("0"))
            total_savings += max(Decimal("0"), shadow_delta - process_cost)

        # Total query cost: sum the same per-row query cost basis used by the
        # visible explorer table so the summary matches what the user sees.
        # A model's query cost is a property of the model, not of each
        # detected issue — dedupe by (config_id, dbt_model_name) and take
        # the max cost per model so N issues on one model don't multiply
        # the displayed total.
        last_job_details_map = get_last_job_details(self.db, visible_opps)
        total_query_cost = Decimal("0")
        workload_query_costs = {
            "build": Decimal("0"),
            "consumption": Decimal("0"),
            "other": Decimal("0"),
        }
        model_max_cost: dict[tuple, tuple[Decimal, str]] = {}
        for opp in visible_opps:
            latest_solution = latest_solution_map.get(opp.id, {})
            workload_kind = _normalize_workload_kind(
                last_job_details_map.get(opp.id, {}).get("workload_kind")
            )
            latest_job_cost = last_job_details_map.get(opp.id, {}).get("total_cost")
            cost_display = build_cost_display(
                current_cost_estimate=opp.current_cost_estimate,
                latest_job_cost=latest_job_cost,
                dry_run_original_cost=latest_solution.get("dry_run_original_cost"),
                dry_run_modified_cost=latest_solution.get("dry_run_modified_cost"),
                use_dry_run_original_for_query_cost=latest_solution.get(
                    "supports_optimized_dry_run",
                    False,
                )
                if latest_solution
                else False,
                prefer_possible_savings_display=latest_solution.get(
                    "prefers_possible_savings_display",
                    False,
                )
                if latest_solution
                else False,
            )
            query_cost_value = cost_display.get("query_cost_value")
            if query_cost_value is not None:
                model_name = getattr(opp, "dbt_model_name", None)
                if model_name:
                    key = (opp.config_id, model_name)
                    prev = model_max_cost.get(key)
                    if prev is None or query_cost_value > prev[0]:
                        model_max_cost[key] = (query_cost_value, workload_kind)
                else:
                    total_query_cost += query_cost_value
                    workload_query_costs[workload_kind] += query_cost_value
        for qc, wk in model_max_cost.values():
            total_query_cost += qc
            workload_query_costs[wk] += qc

        # With solutions count (active, has at least one solution)
        with_solutions_count = (
            self.db.execute(
                select(func.count())
                .select_from(sub)
                .where(sub.c.status == "active")
                .where(sub.c.id.in_(select(Solution.opportunity_id).distinct()))
            ).scalar()
            or 0
        )

        active_solution_job_status_map = get_active_solution_job_statuses(
            self.db, visible_opportunity_ids
        )
        total_possible_savings = Decimal("0")
        workload_possible_savings = {
            "build": Decimal("0"),
            "consumption": Decimal("0"),
            "other": Decimal("0"),
        }
        # Unified with the row SAVINGS column: only the shadow-validation
        # delta contributes. No heuristic, no dry-run, no workload fallback.
        for opp in visible_opps:
            workload_kind = _normalize_workload_kind(
                last_job_details_map.get(opp.id, {}).get("workload_kind")
            )
            possible_savings_value = compute_possible_savings_for_opportunity(
                shadow_savings=shadow_savings_map.get(opp.id),
                active_solution_job_status=active_solution_job_status_map.get(
                    opp.id
                ),
            )
            if possible_savings_value > 0:
                total_possible_savings += possible_savings_value
                workload_possible_savings[workload_kind] += possible_savings_value

        # Verified post-merge savings (spec 068), net of process cost
        verified_rows = self.db.execute(
            select(
                Opportunity.verified_savings,
                Opportunity.process_cost_usd,
            )
            .where(Opportunity.verified_savings_status == "confirmed")
            .where(Opportunity.verified_savings > 0)
        ).all()
        verified_post_merge_savings = Decimal("0")
        verified_count = len(verified_rows)
        for row in verified_rows:
            gross = row.verified_savings or Decimal("0")
            cost = row.process_cost_usd or Decimal("0")
            verified_post_merge_savings += max(Decimal("0"), gross - cost)

        collecting_count = (
            self.db.execute(
                select(func.count()).where(
                    Opportunity.verified_savings_status == "collecting"
                )
            ).scalar()
            or 0
        )

        # Count clearing opportunities
        clearing_count = (
            self.db.execute(
                select(func.count()).select_from(sub).where(sub.c.status == "clearing")
            ).scalar()
            or 0
        )

        total_process_costs = sum(
            (o.process_cost_usd or Decimal("0")) for o in visible_opps
        )

        clearing_savings = sum(
            (o.expected_savings or Decimal("0"))
            for o in visible_opps
            if o.status == "clearing"
        )

        return {
            "active_count": active_count,
            "clearing_count": clearing_count,
            "with_solutions_count": with_solutions_count,
            "total_savings": total_savings,
            "total_possible_savings": total_possible_savings,
            "total_query_cost": total_query_cost,
            "build_query_cost": workload_query_costs["build"],
            "consumption_query_cost": workload_query_costs["consumption"],
            "other_query_cost": workload_query_costs["other"],
            "build_possible_savings": workload_possible_savings["build"],
            "consumption_possible_savings": workload_possible_savings["consumption"],
            "other_possible_savings": workload_possible_savings["other"],
            "verified_post_merge_savings": verified_post_merge_savings,
            "verified_count": verified_count,
            "collecting_count": collecting_count,
            "total_process_costs": total_process_costs,
            "clearing_savings": clearing_savings,
        }

    # ------------------------------------------------------------------
    # Model-grouped view (spec 125, local mode)
    # ------------------------------------------------------------------

    def query_model_groups(
        self,
        *,
        search: str = "",
        status: str = "active",
        project_ids: list[str] | None = None,
        type_names: list[str] | None = None,
        sort_column: str = "state",
        sort_direction: str = "asc",
        page: int = 1,
        page_size: int = 10,
        smart_view: str = "",
        date_start: datetime | None = None,
        date_end: datetime | None = None,
        collapse_pending_states: bool = False,
    ) -> tuple[list[dict], PaginationContext]:
        """Spec 125: return opportunities grouped by dbt model, one row per model.

        Fetches all matching opportunities via ``query_opportunities`` (with
        pagination disabled for the pre-group fetch), groups in Python by
        ``(config_id, dbt_model_name)``, applies sort + pagination over the
        resulting groups, and returns ``(groups, PaginationContext)``.

        Opportunities with a null/empty ``dbt_model_name`` (storage/infra
        recommendations) are excluded from grouping per research Decision 6.
        """
        # 1. Fetch all matching opportunities (no pagination yet).
        all_opps, _ = self.query_opportunities(
            search=search,
            status=status,
            project_ids=project_ids,
            type_names=type_names,
            sort_column=sort_column,
            sort_direction=sort_direction,
            page=1,
            page_size=100_000,  # effectively-all; local projects are small
            smart_view=smart_view,
            date_start=date_start,
            date_end=date_end,
            collapse_pending_states=collapse_pending_states,
        )

        # Preload per-config thresholds so sub-threshold opportunities are
        # tagged ``skipped`` rather than falling through to ``awaiting`` —
        # matches the per-row behaviour on the non-grouped explorer table.
        min_cost_by_config = self._load_min_solution_cost_map(
            {opp.get("config_id") for opp in all_opps if opp.get("config_id")}
        )

        # 2. Group by (config_id, dbt_model_name). Skip opps with no model.
        groups_map: dict[tuple[str, str], dict] = {}
        for opp in all_opps:
            model_name = opp.get("dbt_model_name")
            if not model_name:
                continue
            key = (opp["config_id"], model_name)
            g = groups_map.setdefault(
                key,
                {
                    "config_id": opp["config_id"],
                    "project_name": opp["project_name"],
                    "dbt_model_name": model_name,
                    "affected_table": opp["affected_table"],
                    "opportunity_count": 0,
                    "opportunity_types": set(),
                    "_workload_kinds": set(),
                    "total_query_cost_value": Decimal("0"),
                    "_has_any_cost": False,
                    "total_savings_value": Decimal("0"),
                    "_has_any_savings": False,
                    "_states": [],
                    "last_detected_at": None,
                    "opportunity_ids": [],
                    "_group_opps": [],
                },
            )
            g["opportunity_count"] += 1
            g["opportunity_types"].add(opp["opportunity_type"])
            g["_workload_kinds"].add(opp.get("query_workload_kind") or "unclassified")
            g["opportunity_ids"].append(opp["id"])
            g["_group_opps"].append(opp)

            qcost = opp.get("query_cost_value") or opp.get("current_cost_estimate")
            if qcost is not None:
                qcost_dec = to_decimal(qcost) or Decimal("0")
                # A model's query cost is a property of the model, not of
                # each detected issue. Summing per-opportunity multiplies
                # the same cost by the number of rules that matched. Take
                # the maximum reported cost across the group's opportunities
                # as the representative model cost.
                if qcost_dec > g["total_query_cost_value"]:
                    g["total_query_cost_value"] = qcost_dec
                g["_has_any_cost"] = True

            # Skip contributing to the group's savings total while a
            # SolutionJob for this opportunity is still queued/in_progress.
            # The pre-solution fallback to ``expected_savings`` is a heuristic
            # the user shouldn't trust yet — the summary "Estimated Savings"
            # card uses the same gate via
            # ``compute_possible_savings_for_opportunity``, so excluding it
            # here keeps the two numbers aligned. The row renders "—" until
            # generation finishes, at which point the real figure lands.
            # Only shadow-validated savings contribute. ``possible_savings_value``
            # on the row was populated via build_possible_savings_display()
            # which now returns the shadow delta (or None). No heuristic
            # fallback — raw ``expected_savings`` must never bleed into this
            # total.
            job_status = opp.get("solution_job_status")
            if job_status not in ("queued", "in_progress"):
                savings = opp.get("possible_savings_value")
                if savings is not None:
                    g["total_savings_value"] += to_decimal(savings) or Decimal("0")
                    g["_has_any_savings"] = True

            g["_states"].append(
                _opportunity_to_state_key(opp, min_cost_by_config)
            )

            ldet = opp.get("last_detected_at")
            if ldet and (
                g["last_detected_at"] is None or ldet > g["last_detected_at"]
            ):
                g["last_detected_at"] = ldet

        # 3. Finalise per-group aggregates.
        groups: list[dict] = []
        for g in groups_map.values():
            if not g["_has_any_cost"]:
                g["total_query_cost_value"] = None
            if not g["_has_any_savings"]:
                g["total_savings_value"] = None

            wl_kinds = g.pop("_workload_kinds")
            if "build" in wl_kinds and "consumption" in wl_kinds:
                g["workload_kind"] = "mixed"
            elif "build" in wl_kinds:
                g["workload_kind"] = "build"
            elif "consumption" in wl_kinds:
                g["workload_kind"] = "consumption"
            else:
                g["workload_kind"] = "unclassified"

            g["worst_state"] = _rollup_worst_state(g.pop("_states"))
            g["opportunity_types"] = sorted(g["opportunity_types"])
            # Remove internal scratch
            g.pop("_has_any_cost", None)
            g.pop("_has_any_savings", None)
            g.pop("_group_opps", None)
            groups.append(g)

        # 4. Sort groups.
        groups = _sort_model_groups(groups, sort_column, sort_direction)

        # 5. Paginate over groups.
        total_items = len(groups)
        pagination = PaginationContext(
            page=max(1, page),
            page_size=page_size,
            total_items=total_items,
        )
        if pagination.page > pagination.total_pages and pagination.total_pages > 0:
            pagination = PaginationContext(
                page=pagination.total_pages,
                page_size=page_size,
                total_items=total_items,
            )
        offset = (pagination.page - 1) * page_size
        return groups[offset : offset + page_size], pagination

    # ------------------------------------------------------------------
    # Grouped view (Q4)
    # ------------------------------------------------------------------

    def get_grouped_opportunities(
        self,
        *,
        group_by: str = "project",
        search: str = "",
        status: str = "active",
        project_ids: list[str] | None = None,
        type_names: list[str] | None = None,
        sort_column: str = "cost",
        sort_direction: str = "desc",
        smart_view: str = "",
        date_start: datetime | None = None,
        date_end: datetime | None = None,
        collapse_pending_states: bool = False,
    ) -> list[dict]:
        """Return grouped opportunities with headers and subtotals.

        Each group dict has: group_id, group_name, opportunity_count,
        total_savings, and opportunities (list of dicts).
        """
        # Get all matching opportunities (no pagination in grouped mode)
        visible_clause = self._build_visible_opportunity_clause(project_ids)
        base = (
            select(
                Opportunity,
                ManifestConfiguration.name.label("project_name"),
            )
            .join(
                ManifestConfiguration,
                Opportunity.config_id == ManifestConfiguration.id,
            )
            .where(ManifestConfiguration.status == "active")
            .where(visible_clause)
        )

        # (Legacy local-mode scoping removed in spec 120; CLI scopes externally.)

        # Apply same filters
        if smart_view == "quick-wins":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                Opportunity.id.in_(
                    select(Solution.opportunity_id)
                    .where(Solution.risk_level == "low")
                    .distinct()
                )
            )
        elif smart_view == "chronic":
            base = base.where(Opportunity.status == "active")
            base = base.where(Opportunity.occurrence_count > 20)
        elif smart_view == "unaddressed":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                ~Opportunity.id.in_(select(Solution.opportunity_id).distinct())
            )
            base = base.where(Opportunity.severity_score >= 70)
        else:
            base = _apply_status_filter(
                base,
                status,
                collapse_pending_states=collapse_pending_states,
            )

        if search:
            escaped = (
                search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like_pattern = f"%{escaped}%"
            base = base.where(
                Opportunity.opportunity_type.ilike(like_pattern, escape="\\")
                | Opportunity.affected_table.ilike(like_pattern, escape="\\")
                | Opportunity.dbt_model_name.ilike(like_pattern, escape="\\")
            )

        if project_ids:
            base = base.where(Opportunity.config_id.in_(project_ids))
        if type_names:
            base = base.where(
                func.lower(Opportunity.opportunity_type).in_(
                    [type_name.lower() for type_name in type_names]
                )
            )
        if date_start:
            base = base.where(Opportunity.created_at >= date_start)
        if date_end:
            base = base.where(Opportunity.created_at <= date_end)

        # Sort within groups
        base = _apply_sort(base, sort_column, sort_direction)

        rows = self.db.execute(base).all()

        # Batch solution risk + dry run cost + last job cost for all results
        all_opps = [row[0] for row in rows]
        all_ids = [opp.id for opp in all_opps]
        latest_solution_map = get_latest_solution_snapshots(
            self.db,
            all_ids,
            schedule_missing_dry_runs=True,
        )
        last_job_details_map = (
            get_last_job_details(self.db, all_opps) if all_opps else {}
        )
        exact_local_workload_map = (
            get_exact_local_workload_kinds(self.db, all_opps)
            if all_opps and False
            else {}
        )
        active_solution_job_status_map = get_active_solution_job_statuses(
            self.db, all_ids
        )

        wl_estimates_map = _load_workload_estimates(self.db, all_ids)
        shadow_savings_map = get_latest_shadow_savings_map(self.db, all_ids)

        # Group results
        groups: dict[str, dict] = {}
        for row in rows:
            opp: Opportunity = row[0]
            project_name: str = row[1]

            if group_by == "project":
                group_id = opp.config_id
                group_name = project_name
            else:  # type
                group_id = opp.opportunity_type
                group_name = opp.opportunity_type

            if group_id not in groups:
                groups[group_id] = {
                    "group_id": group_id,
                    "group_name": group_name,
                    "opportunity_count": 0,
                    "total_savings": Decimal("0"),
                    "opportunities": [],
                }

            g = groups[group_id]
            g["opportunity_count"] += 1

            latest_solution = latest_solution_map.get(opp.id, {})
            latest_job_details = last_job_details_map.get(opp.id, {})
            workload_kind = (
                exact_local_workload_map.get(opp.id)
                or _normalize_workload_kind(latest_job_details.get("workload_kind"))
                if False
                else _normalize_workload_kind(latest_job_details.get("workload_kind"))
            )
            has_sol = bool(latest_solution) or opp.latest_solution_id is not None
            sol_risk = (
                latest_solution.get("risk_level")
                if latest_solution
                else opp.latest_solution_risk_level
            )
            entry = {
                "id": opp.id,
                "config_id": opp.config_id,
                "project_name": project_name,
                "opportunity_type": opp.opportunity_type,
                "affected_table": opp.affected_table,
                "dbt_model_name": opp.dbt_model_name,
                "severity_score": opp.severity_score,
                "current_cost_estimate": opp.current_cost_estimate,
                "expected_savings": opp.expected_savings,
                "status": opp.status,
                "cascade_status": opp.cascade_status,
                "cascade_root_id": opp.cascade_root_id,
                "occurrence_count": opp.occurrence_count,
                "created_at": opp.created_at,
                "last_detected_at": opp.last_detected_at,
                "has_solution": has_sol,
                "solution_risk_level": sol_risk,
                "avg_query_cost": latest_job_details.get("total_cost"),
                "dry_run_original_cost": latest_solution.get("dry_run_original_cost"),
                "dry_run_modified_cost": latest_solution.get("dry_run_modified_cost"),
                "solution_job_status": active_solution_job_status_map.get(opp.id),
                "prefers_possible_savings_display": latest_solution.get(
                    "prefers_possible_savings_display",
                    False,
                ),
                "query_workload_kind": workload_kind,
                "query_workload_label": workload_kind.title()
                if workload_kind
                else ("Unclassified" if False else "Query"),
            }
            entry.update(
                build_cost_display(
                    current_cost_estimate=opp.current_cost_estimate,
                    latest_job_cost=latest_job_details.get("total_cost"),
                    dry_run_original_cost=latest_solution.get("dry_run_original_cost"),
                    dry_run_modified_cost=latest_solution.get("dry_run_modified_cost"),
                    use_dry_run_original_for_query_cost=latest_solution.get(
                        "supports_optimized_dry_run",
                        False,
                    )
                    if latest_solution
                    else False,
                    prefer_possible_savings_display=entry[
                        "prefers_possible_savings_display"
                    ],
                )
            )
            entry.update(
                build_possible_savings_display(
                    shadow_savings=shadow_savings_map.get(opp.id),
                )
            )
            if entry["possible_savings_value"] is not None:
                g["total_savings"] += entry["possible_savings_value"]
            g["opportunities"].append(entry)

        # Compute recommendation state for grouped rows
        permanently_failed = get_permanently_failed_opp_ids(self.db, all_ids)
        config_min_cost_map = self._load_min_solution_cost_map(
            {
                entry.get("config_id")
                for g_data in groups.values()
                for entry in g_data["opportunities"]
                if entry.get("config_id")
            }
        )
        for g_data in groups.values():
            for entry in g_data["opportunities"]:
                root_has_solution = bool(
                    latest_solution_map.get(entry.get("cascade_root_id"))
                ) if entry.get("cascade_root_id") else False
                entry["recommendation_state"] = resolve_state(
                    opportunity_status=entry["status"],
                    cascade_status=entry.get("cascade_status"),
                    cascade_root_has_solution=root_has_solution,
                    solution_job_status=entry.get("solution_job_status"),
                    has_solutions=entry.get("has_solution", False),
                    has_pr=False,
                    job_permanently_failed=entry["id"] in permanently_failed,
                    current_cost_estimate=entry.get("current_cost_estimate"),
                    min_solution_cost_usd=config_min_cost_map.get(
                        entry.get("config_id")
                    ),
                )

        # Sort groups by total_savings DESC
        sorted_groups = sorted(
            groups.values(), key=lambda g: g["total_savings"], reverse=True
        )
        return sorted_groups
