"""Helpers for run_results-driven build heuristics.

This module turns local dbt ``run_results.json`` runtime hotspots into
conservative, config-only recommendation hints that can be surfaced through
existing Governor opportunity types.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from governor_core.opportunities.savings_estimator import extract_table_predicates

_SUCCESS_STATUSES = frozenset({"success", "pass", "warn", "skipped"})
_PARTITIONABLE_BQ_TYPES = frozenset({"DATE", "TIMESTAMP", "DATETIME", "INT64"})
_SUPPORTED_MATERIALIZATIONS = frozenset({"table", "incremental"})
_MAX_CLUSTER_COLUMNS = 4
_TEMPORAL_NAME_PRIORITIES: tuple[tuple[str, int], ...] = (
    ("event_date", 100),
    ("partition_date", 95),
    ("date", 90),
    ("_date", 85),
    ("created_at", 82),
    ("updated_at", 80),
    ("_at", 75),
    ("timestamp", 72),
    ("_ts", 68),
    ("time", 60),
    ("day", 55),
    ("month", 45),
)


@dataclass(frozen=True)
class RunResultsHotspot:
    """A manifest-backed model hotspot extracted from run_results.json."""

    unique_id: str
    model_name: str
    relation_name: str
    execution_time_s: float
    status: str
    node: dict[str, Any]
    result: dict[str, Any]


def build_run_results_job_index(
    run_results_json: dict[str, Any] | None,
    synced_jobs: list[Any],
) -> dict[str, tuple[dict[str, Any], Any]]:
    """Build a mapping from dbt model name to (run_result_entry, BigQueryJob).

    Uses ``adapter_response.job_id`` from run_results to directly link each
    dbt model execution to its synced BigQuery job — no table-name matching.

    Returns:
        Dict keyed by model name (e.g. ``"stg_orders"``), values are tuples
        of ``(run_result_entry_dict, BigQueryJob_instance)``.
    """
    if not run_results_json or not synced_jobs:
        return {}

    jobs_by_id = {
        str(getattr(job, "job_id", "") or "").strip(): job
        for job in synced_jobs
        if getattr(job, "job_id", None)
    }
    if not jobs_by_id:
        return {}

    index: dict[str, tuple[dict[str, Any], Any]] = {}
    for result in run_results_json.get("results") or []:
        if not isinstance(result, dict):
            continue
        adapter_response = result.get("adapter_response") or {}
        job_id = str(adapter_response.get("job_id") or "").strip()
        if not job_id:
            continue
        bq_job = jobs_by_id.get(job_id)
        if bq_job is None:
            continue

        unique_id = str(result.get("unique_id") or "").strip()
        model_name = unique_id.split(".")[-1] if unique_id else ""
        if not model_name:
            continue

        # First entry wins (in case of duplicate model names)
        if model_name not in index:
            index[model_name] = (result, bq_job)

    return index


def normalize_relation_name(value: str | None) -> str | None:
    """Normalize a relation name for case-insensitive matching."""
    if not value:
        return None
    cleaned = str(value).strip().replace("`", "")
    return cleaned.lower() if cleaned else None


def relation_name_for_node(node: dict[str, Any] | None) -> str | None:
    """Return a normalized manifest relation name for a dbt model node."""
    if not isinstance(node, dict):
        return None

    relation_name = normalize_relation_name(node.get("relation_name"))
    if relation_name:
        return relation_name

    database = str(node.get("database") or "").strip("`")
    schema = str(node.get("schema") or "").strip("`")
    identifier = str(
        node.get("alias") or node.get("identifier") or node.get("name") or ""
    ).strip("`")
    parts = [part for part in (database, schema, identifier) if part]
    if not parts:
        return None
    return ".".join(parts).lower()


def node_supports_config_heuristics(node: dict[str, Any] | None) -> bool:
    """Return whether the manifest node can receive config-only optimizations."""
    if not isinstance(node, dict):
        return False
    if node.get("resource_type") != "model":
        return False
    materialized = str((node.get("config") or {}).get("materialized") or "").lower()
    return materialized in _SUPPORTED_MATERIALIZATIONS


def extract_run_results_hotspots(
    run_results_json: dict[str, Any] | None,
    manifest_content: dict[str, Any] | None,
    *,
    min_execution_time_s: float,
) -> list[RunResultsHotspot]:
    """Extract conservative model hotspots from ``run_results.json``."""
    if not run_results_json or not manifest_content:
        return []

    nodes = manifest_content.get("nodes") or {}
    hotspots: list[RunResultsHotspot] = []

    for result in run_results_json.get("results") or []:
        if not isinstance(result, dict):
            continue
        unique_id = str(result.get("unique_id") or "").strip()
        if not unique_id:
            continue
        node = nodes.get(unique_id)
        if not node_supports_config_heuristics(node):
            continue

        execution_time_s = _extract_execution_time(result)
        status = str(result.get("status") or "unknown").lower()
        is_success_like = status in _SUCCESS_STATUSES
        if is_success_like and execution_time_s < min_execution_time_s:
            continue

        relation_name = relation_name_for_node(node)
        model_name = str(node.get("name") or "")
        if not relation_name or not model_name:
            continue

        hotspots.append(
            RunResultsHotspot(
                unique_id=unique_id,
                model_name=model_name,
                relation_name=relation_name,
                execution_time_s=execution_time_s,
                status=status,
                node=node,
                result=result,
            )
        )

    hotspots.sort(
        key=lambda hotspot: (
            hotspot.execution_time_s,
            0 if hotspot.status not in _SUCCESS_STATUSES else 1,
            hotspot.model_name,
        ),
        reverse=True,
    )
    return hotspots


def build_table_column_type_index(
    table_columns: list[Any] | None,
) -> dict[str, dict[str, str]]:
    """Index synced INFORMATION_SCHEMA column types by relation name."""
    index: dict[str, dict[str, str]] = {}
    if not table_columns:
        return index

    for row in table_columns:
        project_id = str(getattr(row, "project_id", "") or "").strip("`")
        dataset_name = str(getattr(row, "dataset_name", "") or "").strip("`")
        table_name = str(getattr(row, "table_name", "") or "").strip("`")
        column_name = str(getattr(row, "column_name", "") or "").strip("`")
        data_type = str(getattr(row, "data_type", "") or "").upper()
        if not dataset_name or not table_name or not column_name or not data_type:
            continue

        relation_variants = {
            ".".join(
                part for part in (project_id, dataset_name, table_name) if part
            ).lower(),
            f"{dataset_name}.{table_name}".lower(),
            table_name.lower(),
        }
        for relation in relation_variants:
            if not relation:
                continue
            relation_columns = index.setdefault(relation, {})
            relation_columns[column_name.lower()] = data_type

    return index


def extract_existing_partition_field(node: dict[str, Any] | None) -> str | None:
    """Extract the configured partition field from a manifest node, if present."""
    config = (node or {}).get("config") or {}
    partition_by = config.get("partition_by")
    if isinstance(partition_by, dict):
        field = partition_by.get("field")
        if field:
            return str(field)
    if isinstance(partition_by, str):
        return partition_by
    return None


def extract_existing_cluster_columns(node: dict[str, Any] | None) -> list[str]:
    """Extract configured cluster_by columns from a manifest node."""
    config = (node or {}).get("config") or {}
    cluster_by = config.get("cluster_by")
    if isinstance(cluster_by, str):
        return [cluster_by]
    if isinstance(cluster_by, list):
        return [str(value) for value in cluster_by if str(value).strip()]
    return []


def related_jobs_for_table(jobs: list[Any], relation_name: str) -> list[Any]:
    """Return jobs that build or reference the given relation."""
    relation_key = normalize_relation_name(relation_name)
    if not relation_key:
        return []

    related: list[Any] = []
    for job in jobs:
        destination_key = normalize_relation_name(
            getattr(job, "destination_table", None)
        )
        referenced_keys = {
            key
            for key in _normalize_referenced_tables(
                getattr(job, "referenced_tables", None)
            )
            if key
        }
        if destination_key == relation_key or relation_key in referenced_keys:
            related.append(job)
    return related


def total_job_cost(jobs: list[Any]) -> Decimal:
    """Return the summed cost for a list of BigQuery jobs."""
    total = Decimal("0")
    for job in jobs:
        value = getattr(job, "total_cost", None)
        if value is None:
            continue
        total += Decimal(str(value))
    return total


def total_bytes_processed(jobs: list[Any]) -> int:
    """Return summed bytes processed across jobs."""
    return sum(int(getattr(job, "total_bytes_processed", 0) or 0) for job in jobs)


def job_ids(jobs: list[Any], *, limit: int | None = None) -> list[str]:
    """Collect job IDs from a list of BigQuery jobs."""
    collected: list[str] = []
    for job in jobs:
        job_id = str(getattr(job, "job_id", "") or "").strip()
        if not job_id:
            continue
        collected.append(job_id)
        if limit is not None and len(collected) >= limit:
            break
    return collected


def choose_partition_column(
    *,
    relation_name: str,
    eligible_columns: dict[str, str],
    jobs: list[Any],
    compiled_sql: str | None = None,
) -> tuple[str | None, str | None, str | None]:
    """Choose a candidate partition column and explain why it won."""
    inferred_column, inferred_type = infer_partition_column_from_sql(compiled_sql)
    if not eligible_columns:
        if inferred_column and inferred_type:
            return inferred_column, "sql_temporal_predicate", inferred_type
        return None, None, None

    predicate_scores = _score_partition_columns_from_jobs(
        relation_name=relation_name,
        eligible_columns=list(eligible_columns.keys()),
        jobs=jobs,
    )
    if predicate_scores:
        column_name = max(
            predicate_scores.items(),
            key=lambda item: (item[1], item[0]),
        )[0]
        return column_name, "predicate_usage", eligible_columns.get(column_name)

    if (
        inferred_column
        and inferred_type
        and inferred_column.lower() in eligible_columns
    ):
        normalized = inferred_column.lower()
        return normalized, "sql_temporal_predicate", eligible_columns.get(normalized)

    ranked_temporal_columns = sorted(
        eligible_columns.keys(),
        key=lambda column: (_temporal_name_score(column), column),
        reverse=True,
    )
    if not ranked_temporal_columns:
        return None, None, None

    best_column = ranked_temporal_columns[0]
    if _temporal_name_score(best_column) <= 0:
        return None, None, None
    return best_column, "temporal_column_name", eligible_columns.get(best_column)


def compiled_sql_for_hotspot(hotspot: RunResultsHotspot) -> str:
    """Return the richest compiled SQL available for a run_results hotspot."""
    for container in (hotspot.result, hotspot.node):
        if not isinstance(container, dict):
            continue
        compiled_sql = container.get("compiled_code")
        if isinstance(compiled_sql, str) and compiled_sql.strip():
            return compiled_sql
    return ""


def extract_cluster_candidate_columns(
    *,
    compiled_sql: str | None,
    valid_columns: set[str] | None,
    existing_cluster_columns: list[str],
) -> list[str]:
    """Extract candidate cluster columns from compiled SQL."""
    if not compiled_sql:
        return []

    try:
        parsed = sqlglot.parse_one(compiled_sql, dialect="bigquery")
    except SqlglotError:
        return []

    columns: list[str] = []
    seen: set[str] = set()
    existing_lower = {column.lower() for column in existing_cluster_columns}

    for join in parsed.find_all(exp.Join):
        on_clause = join.args.get("on")
        if on_clause is None:
            continue
        for col in on_clause.find_all(exp.Column):
            _append_cluster_column(
                columns=columns,
                seen=seen,
                valid_columns=valid_columns,
                existing_lower=existing_lower,
                column_name=col.name,
            )

    for group in parsed.find_all(exp.Group):
        for col in group.find_all(exp.Column):
            _append_cluster_column(
                columns=columns,
                seen=seen,
                valid_columns=valid_columns,
                existing_lower=existing_lower,
                column_name=col.name,
            )

    return columns[:_MAX_CLUSTER_COLUMNS]


def evidence_source_with_run_results(existing_source: str | None = None) -> str:
    """Merge evidence source labels for job insights and run_results."""
    source = (existing_source or "").strip()
    if not source:
        return "run_results"
    if source == "jobs_insights":
        return "jobs_insights_and_run_results"
    if source == "run_results":
        return source
    if "run_results" in source:
        return source
    return f"{source}_and_run_results"


def partitionable_columns_for_relation(
    column_type_index: dict[str, dict[str, str]],
    relation_name: str,
) -> dict[str, str]:
    """Return partition-compatible columns for a relation."""
    columns = (
        column_type_index.get(relation_name)
        or column_type_index.get(".".join(relation_name.split(".")[-2:]))
        or column_type_index.get(relation_name.split(".")[-1])
        or {}
    )
    return {
        column_name: bq_type
        for column_name, bq_type in columns.items()
        if bq_type in _PARTITIONABLE_BQ_TYPES
    }


def columns_for_relation(
    column_type_index: dict[str, dict[str, str]],
    relation_name: str,
) -> set[str] | None:
    """Return all known columns for a relation."""
    columns = (
        column_type_index.get(relation_name)
        or column_type_index.get(".".join(relation_name.split(".")[-2:]))
        or column_type_index.get(relation_name.split(".")[-1])
    )
    if not columns:
        return None
    return set(columns.keys())


def _extract_execution_time(result: dict[str, Any]) -> float:
    value = result.get("execution_time")
    try:
        if value is not None:
            return float(value)
    except TypeError, ValueError:
        return 0.0
    return 0.0


def _normalize_referenced_tables(value: Any) -> list[str]:
    if not value:
        return []
    normalized: list[str] = []
    if isinstance(value, list):
        for item in value:
            if isinstance(item, str):
                relation = normalize_relation_name(item)
                if relation:
                    normalized.append(relation)
                continue
            if isinstance(item, dict):
                project_id = str(
                    item.get("project_id") or item.get("project") or ""
                ).strip("`")
                dataset_id = str(
                    item.get("dataset_id") or item.get("dataset") or ""
                ).strip("`")
                table_id = str(item.get("table_id") or item.get("table") or "").strip(
                    "`"
                )
                relation = normalize_relation_name(
                    ".".join(
                        part for part in (project_id, dataset_id, table_id) if part
                    )
                )
                if relation:
                    normalized.append(relation)
    return normalized


def _score_partition_columns_from_jobs(
    *,
    relation_name: str,
    eligible_columns: list[str],
    jobs: list[Any],
) -> dict[str, Decimal]:
    scores: dict[str, Decimal] = {}

    for job in jobs:
        sql = getattr(job, "query", None) or ""
        if not sql:
            continue
        bytes_processed = int(getattr(job, "total_bytes_processed", 0) or 0)
        weight = Decimal(str(max(bytes_processed, 1)))
        predicates = extract_table_predicates(sql, relation_name, eligible_columns)
        for predicate in predicates:
            if not predicate.is_partition_compatible:
                continue
            multiplier = _predicate_weight(predicate.operator, predicate.values)
            if multiplier <= 0:
                continue
            scores[predicate.column] = scores.get(predicate.column, Decimal("0")) + (
                weight * multiplier
            )
    return scores


def _predicate_weight(operator: str, values: list[str | None]) -> Decimal:
    if operator == "eq":
        return Decimal("1.0")
    if operator == "in":
        value_count = max(sum(1 for value in values if value is not None), 1)
        return Decimal("1.0") / Decimal(str(value_count))
    if operator == "between":
        return Decimal("0.7")
    if operator in {"gt", "gte", "lt", "lte"}:
        return Decimal("0.55")
    if operator == "is_null":
        return Decimal("0.10")
    return Decimal("0")


def _temporal_name_score(column_name: str) -> int:
    lowered = column_name.lower()
    for pattern, score in _TEMPORAL_NAME_PRIORITIES:
        if lowered == pattern or lowered.endswith(pattern):
            return score
    return 0


def infer_partition_column_from_sql(
    compiled_sql: str | None,
) -> tuple[str | None, str | None]:
    """Infer a partition candidate directly from compiled SQL predicates."""
    if not compiled_sql:
        return None, None

    try:
        parsed = sqlglot.parse_one(compiled_sql, dialect="bigquery")
    except SqlglotError:
        return None, None

    candidates: dict[str, str] = {}
    for where in parsed.find_all(exp.Where):
        for col in where.find_all(exp.Column):
            column_name = str(col.name or "").strip()
            if not column_name or _temporal_name_score(column_name) <= 0:
                continue
            candidates[column_name.lower()] = _infer_temporal_type(column_name)

    if not candidates:
        return None, None

    best_column = max(
        candidates.keys(),
        key=lambda column: (_temporal_name_score(column), column),
    )
    return best_column, candidates[best_column]


def _infer_temporal_type(column_name: str) -> str:
    lowered = column_name.lower()
    if lowered == "date" or lowered.endswith("_date") or lowered.endswith("_day"):
        return "DATE"
    return "TIMESTAMP"


def _append_cluster_column(
    *,
    columns: list[str],
    seen: set[str],
    valid_columns: set[str] | None,
    existing_lower: set[str],
    column_name: str | None,
) -> None:
    if not column_name:
        return
    normalized = column_name.lower()
    if normalized in seen or normalized in existing_lower:
        return
    if valid_columns is not None and normalized not in valid_columns:
        return
    seen.add(normalized)
    columns.append(column_name)
