"""Cost-verification run model (spec 108).

Moved to core during the spec 120 monorepo split: cost verification is an
engine concern (runs BigQuery queries, computes cost deltas, updates
``Opportunity.verified_savings``). The setup-wizard ``VerificationRun`` and
``VerificationCheck`` models remain in ``governor_web`` because those are
admin-facing web flows.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from governor_core.db.base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class CostVerificationRun(Base):
    """Tracks a cost impact verification build and its results."""

    __tablename__ = "cost_verification_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    opportunity_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
    )
    solution_id: Mapped[Optional[str]] = mapped_column(
        String(36),
        ForeignKey("solutions.id", ondelete="SET NULL"),
        nullable=True,
    )
    baseline_sync_id: Mapped[Optional[str]] = mapped_column(
        String(36),
        ForeignKey("sync_operations.id", ondelete="SET NULL"),
        nullable=True,
    )
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default="queued"
    )
    dbt_selector: Mapped[str] = mapped_column(String(255), nullable=False)
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    baseline_costs: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    verification_costs: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    cost_comparison: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    net_delta_usd: Mapped[Optional[float]] = mapped_column(
        Numeric(10, 4), nullable=True
    )
    model_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
