"""
Cost Optimization Opportunity Detection module.

Provides detection framework for identifying BigQuery cost optimization
opportunities from synced job statistics.
"""

from governor_core.opportunities.models import DetectionJob, Opportunity

__all__ = ["DetectionJob", "Opportunity"]
