"""Cost impact verification service.

Orchestrates the before/after cost comparison:
1. Find baseline costs from the developer's last dbt build (captured during sync)
2. Run dbt build with the optimization applied
3. Compare per-model BigQuery costs
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy.orm import Session

from governor_core.opportunities.cost_verification_models import CostVerificationRun

logger = logging.getLogger("app.verification.cost")

_JOB_ID_PATTERN = re.compile(r"Job ID:\s*([A-Za-z0-9_:-]+)")


class CostVerificationService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def find_baseline_sync(self, config_id: str):
        """Find the most recent completed sync with run_results_json."""
        from governor_core.sync.models import SyncOperation

        return (
            self._db.query(SyncOperation)
            .filter(
                SyncOperation.config_id == config_id,
                SyncOperation.status == "completed",
                SyncOperation.run_results_json.isnot(None),
            )
            .order_by(SyncOperation.completed_at.desc())
            .first()
        )

    def extract_job_ids_from_run_results(
        self, run_results: dict
    ) -> dict[str, str]:
        """Extract model_name → job_id mapping from run_results.

        Returns dict keyed by model unique_id (e.g., 'model.project.stg_orders')
        with values being the BigQuery job ID.
        """
        model_job_map: dict[str, str] = {}
        for result in run_results.get("results", []):
            unique_id = result.get("unique_id", "")
            if not unique_id.startswith("model."):
                continue

            # Try adapter_response.job_id first
            adapter = result.get("adapter_response", {})
            job_id = adapter.get("job_id")

            # Fallback: parse from message
            if not job_id:
                message = adapter.get("_message", "") or result.get("message", "")
                match = _JOB_ID_PATTERN.search(message)
                if match:
                    job_id = match.group(1)

            if job_id:
                model_job_map[unique_id] = job_id

        return model_job_map

    def lookup_job_costs(
        self, job_ids: list[str], gcp_project_id: str
    ) -> dict[str, Decimal]:
        """Query BigQuery INFORMATION_SCHEMA for actual job costs.

        Returns dict of job_id → cost_usd.
        """
        if not job_ids:
            return {}

        from governor_core.gcp.clients import query_information_schema_jobs_by_ids

        try:
            rows = query_information_schema_jobs_by_ids(
                gcp_project_id, job_ids
            )
        except Exception:
            logger.warning("Failed to query BQ for job costs", exc_info=True)
            return {}

        cost_map: dict[str, Decimal] = {}
        for row in rows:
            jid = row.get("job_id")
            cost = row.get("total_cost")
            if jid and cost is not None:
                cost_map[jid] = Decimal(str(cost))
        return cost_map

    def discover_downstream_models(
        self,
        manifest_content: dict,
        model_name: str,
        max_depth: int = 10,
    ) -> list[str]:
        """Find all downstream model unique_ids via BFS on child_map.

        Args:
            manifest_content: Parsed manifest.json dict
            model_name: Short model name (e.g., 'stg_orders')
            max_depth: Max traversal depth

        Returns:
            List of unique_ids including the source model.
        """
        child_map = manifest_content.get("child_map", {})
        nodes = manifest_content.get("nodes", {})

        # Find the unique_id for this model name
        source_uid = None
        for uid, node in nodes.items():
            if uid.startswith("model.") and node.get("name") == model_name:
                source_uid = uid
                break

        if not source_uid:
            logger.warning("Model %s not found in manifest", model_name)
            return []

        # BFS downstream
        visited: set[str] = set()
        queue: list[tuple[str, int]] = [(source_uid, 0)]
        result: list[str] = []

        while queue:
            uid, depth = queue.pop(0)
            if uid in visited or depth > max_depth:
                continue
            visited.add(uid)
            if uid.startswith("model."):
                result.append(uid)
            for child in child_map.get(uid, []):
                if child.startswith("model.") and child not in visited:
                    queue.append((child, depth + 1))

        return result

    def build_cost_comparison(
        self,
        downstream_models: list[str],
        baseline_model_costs: dict[str, Decimal],
        verification_model_costs: dict[str, Decimal],
        changed_model_uid: str,
    ) -> dict:
        """Build the per-model cost comparison structure.

        Returns dict with 'models' list and 'summary' totals.
        """
        models = []
        total_before = Decimal("0")
        total_after = Decimal("0")

        for uid in downstream_models:
            short_name = uid.split(".")[-1] if "." in uid else uid
            before = baseline_model_costs.get(uid)
            after = verification_model_costs.get(uid)

            before_val = before if before is not None else None
            after_val = after if after is not None else None

            delta = None
            pct_change = None
            if before_val is not None and after_val is not None:
                delta = after_val - before_val
                if before_val > 0:
                    pct_change = float(
                        (delta / before_val) * 100
                    )

            if before_val is not None:
                total_before += before_val
            if after_val is not None:
                total_after += after_val

            models.append({
                "unique_id": uid,
                "model_name": short_name,
                "is_changed_model": uid == changed_model_uid,
                "before_cost_usd": float(before_val) if before_val is not None else None,
                "after_cost_usd": float(after_val) if after_val is not None else None,
                "delta_usd": float(delta) if delta is not None else None,
                "pct_change": round(pct_change, 1) if pct_change is not None else None,
                "status": "compared" if delta is not None else "partial",
            })

        net_delta = total_after - total_before

        return {
            "models": models,
            "summary": {
                "total_before_usd": float(total_before),
                "total_after_usd": float(total_after),
                "net_delta_usd": float(net_delta),
                "net_pct_change": (
                    round(float((net_delta / total_before) * 100), 1)
                    if total_before > 0
                    else None
                ),
                "model_count": len(models),
                "is_saving": net_delta < 0,
            },
        }

    def run_verification(
        self,
        verification_run: CostVerificationRun,
        config,
        opportunity,
        manifest_content: dict,
    ) -> CostVerificationRun:
        """Execute the full verification flow.

        1. Extract baseline costs from the baseline sync's run_results
        2. Discover downstream models
        3. Run dbt build with selector
        4. Extract verification costs
        5. Build comparison
        """
        from governor_core.core.config import get_settings
        from governor_core.dbt.uv_runner import DbtUvRunner

        settings = get_settings()
        now = datetime.now(timezone.utc)
        verification_run.status = "running"
        verification_run.started_at = now
        self._db.commit()

        try:
            # Step 1: Extract baseline costs
            from governor_core.sync.models import SyncOperation

            baseline_sync_op = None
            if verification_run.baseline_sync_id:
                baseline_sync_op = self._db.get(
                    SyncOperation, verification_run.baseline_sync_id
                )

            baseline_model_jobs: dict[str, str] = {}
            if baseline_sync_op and baseline_sync_op.run_results_json:
                baseline_model_jobs = self.extract_job_ids_from_run_results(
                    baseline_sync_op.run_results_json
                )

            baseline_job_costs = self.lookup_job_costs(
                list(baseline_model_jobs.values()),
                config.gcp_project_id,
            )
            baseline_model_costs: dict[str, Decimal] = {}
            for uid, jid in baseline_model_jobs.items():
                if jid in baseline_job_costs:
                    baseline_model_costs[uid] = baseline_job_costs[jid]

            verification_run.baseline_costs = {
                uid: float(cost)
                for uid, cost in baseline_model_costs.items()
            }

            # Step 2: Discover downstream models
            model_name = opportunity.dbt_model_name
            if not model_name:
                table = opportunity.affected_table or ""
                model_name = table.split(".")[-1] if "." in table else table

            downstream = self.discover_downstream_models(
                manifest_content, model_name
            )
            if not downstream:
                downstream_names = [model_name]
            else:
                downstream_names = downstream

            # Find the changed model uid
            changed_uid = None
            for uid in downstream_names:
                if uid.split(".")[-1] == model_name:
                    changed_uid = uid
                    break

            # Step 3: Run dbt build
            runner = DbtUvRunner()
            selector = f"{model_name}+"
            verification_run.dbt_selector = selector

            build_result = runner.build_models(
                project_dir=config.local_project_path,
                selector=selector,
                dbt_version=settings.dbt_default_version,
                profiles_dir=(
                    settings.dbt_profiles_dir
                    or config.local_project_path
                ),
                target_name=settings.dbt_target_name,
                timeout=600,
            )

            if not build_result.run_results:
                verification_run.status = "failed"
                verification_run.error_message = (
                    f"dbt build failed (exit {build_result.exit_code}): "
                    f"{build_result.stderr[:500]}"
                )
                verification_run.completed_at = datetime.now(timezone.utc)
                self._db.commit()
                return verification_run

            # Step 4: Extract verification costs
            verification_model_jobs = self.extract_job_ids_from_run_results(
                build_result.run_results
            )
            verification_job_costs = self.lookup_job_costs(
                list(verification_model_jobs.values()),
                config.gcp_project_id,
            )
            verification_model_costs: dict[str, Decimal] = {}
            for uid, jid in verification_model_jobs.items():
                if jid in verification_job_costs:
                    verification_model_costs[uid] = verification_job_costs[jid]

            verification_run.verification_costs = {
                uid: float(cost)
                for uid, cost in verification_model_costs.items()
            }

            # Step 5: Build comparison
            comparison = self.build_cost_comparison(
                downstream_models=downstream_names,
                baseline_model_costs=baseline_model_costs,
                verification_model_costs=verification_model_costs,
                changed_model_uid=changed_uid or "",
            )

            verification_run.cost_comparison = comparison
            verification_run.net_delta_usd = comparison["summary"]["net_delta_usd"]
            verification_run.model_count = comparison["summary"]["model_count"]
            verification_run.status = "completed"
            verification_run.completed_at = datetime.now(timezone.utc)
            self._db.commit()

            logger.info(
                "Cost verification completed: opp=%s models=%d net_delta=$%.4f",
                opportunity.id,
                verification_run.model_count,
                verification_run.net_delta_usd or 0,
            )
            return verification_run

        except Exception as exc:
            verification_run.status = "failed"
            verification_run.error_message = str(exc)[:1000]
            verification_run.completed_at = datetime.now(timezone.utc)
            self._db.commit()
            logger.error(
                "Cost verification failed: opp=%s error=%s",
                verification_run.opportunity_id,
                exc,
                exc_info=True,
            )
            return verification_run
