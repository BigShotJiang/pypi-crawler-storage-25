"""Historical savings reconstruction for active opportunities.

This module rebuilds possible savings from stored detection history plus the
historical BigQuery jobs that were analyzed when the issue was detected.

It is intentionally conservative:
- only supported "possible savings" rule types are considered
- only positive detections inside the requested window are counted
- when historical evidence cannot be reconstructed, callers can fall back to
  the older per-run heuristic display
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Iterable

from sqlalchemy import select
from sqlalchemy.orm import Session

from governor_core.opportunities.catalog import get_detection_rule_catalog
from governor_core.opportunities.models import (
    DetectionJob,
    Opportunity,
    OpportunityDetectionHistory,
)
from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.sync.models import BigQueryJob

_SUPPORTED_HISTORICAL_RULE_TYPES = frozenset(
    {
        "shuffle_spill",
        "slot_contention",
        "join_explosion",
        "partition_pruning",
    }
)


def _zero() -> Decimal:
    return Decimal("0")


def _coerce_decimal(value: Decimal | None) -> Decimal:
    return value if isinstance(value, Decimal) else Decimal("0")


def _history_day_key(value: datetime) -> datetime.date:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).date()


@dataclass
class HistoricalSavingsBreakdown:
    """Historical reconstructed savings for a set of opportunities."""

    savings_by_opportunity_id: dict[str, Decimal] = field(default_factory=dict)
    cost_by_opportunity_id: dict[str, Decimal] = field(default_factory=dict)
    matched_detection_counts: dict[str, int] = field(default_factory=dict)

    def savings_for(self, opportunity_id: str) -> Decimal:
        return self.savings_by_opportunity_id.get(opportunity_id, Decimal("0"))

    def cost_for(self, opportunity_id: str) -> Decimal:
        return self.cost_by_opportunity_id.get(opportunity_id, Decimal("0"))

    def has_history(self, opportunity_id: str) -> bool:
        return self.matched_detection_counts.get(opportunity_id, 0) > 0


def calculate_historical_possible_savings(
    db: Session,
    opportunities: Iterable[Opportunity],
    *,
    start_date: datetime,
    end_date: datetime,
) -> HistoricalSavingsBreakdown:
    """Rebuild historical possible savings for active supported opportunities.

    For each positive detection event in the requested window we re-run the
    originating rule against the historical jobs for that detection sync. This
    gives us period-based savings instead of today's "latest run" snapshot.
    """

    eligible_opps = [
        opp
        for opp in opportunities
        if opp.status == "active"
        and opp.opportunity_type in _SUPPORTED_HISTORICAL_RULE_TYPES
    ]
    if not eligible_opps:
        return HistoricalSavingsBreakdown()

    opps_by_id = {opp.id: opp for opp in eligible_opps}
    opportunity_ids = list(opps_by_id)

    history_rows = db.execute(
        select(
            OpportunityDetectionHistory.opportunity_id,
            OpportunityDetectionHistory.detection_job_id,
            OpportunityDetectionHistory.detected_at,
        )
        .where(
            OpportunityDetectionHistory.opportunity_id.in_(opportunity_ids),
            OpportunityDetectionHistory.detected_at >= start_date,
            OpportunityDetectionHistory.detected_at <= end_date,
        )
        .order_by(OpportunityDetectionHistory.detected_at.asc())
    ).all()
    if not history_rows:
        return HistoricalSavingsBreakdown()

    detection_job_ids = list({row.detection_job_id for row in history_rows})
    detection_rows = db.execute(
        select(DetectionJob.id, DetectionJob.sync_id).where(
            DetectionJob.id.in_(detection_job_ids)
        )
    ).all()
    sync_id_by_detection_job = {
        detection_job_id: sync_id for detection_job_id, sync_id in detection_rows
    }
    if not sync_id_by_detection_job:
        return HistoricalSavingsBreakdown()

    sync_ids = list({sync_id for sync_id in sync_id_by_detection_job.values()})
    jobs = (
        db.execute(
            select(BigQueryJob).where(
                BigQueryJob.sync_id.in_(sync_ids),
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
            )
        )
        .scalars()
        .all()
    )
    if not jobs:
        return HistoricalSavingsBreakdown()

    jobs_by_sync: dict[str, list[BigQueryJob]] = defaultdict(list)
    jobs_by_sync_and_day: dict[tuple[str, datetime.date], list[BigQueryJob]] = (
        defaultdict(list)
    )
    for job in jobs:
        jobs_by_sync[job.sync_id].append(job)
        jobs_by_sync_and_day[(job.sync_id, _history_day_key(job.creation_time))].append(
            job
        )

    rules_by_type: dict[str, BaseDetectionRule] = {}
    for entry in get_detection_rule_catalog():
        if not entry.enabled or entry.rule_type not in _SUPPORTED_HISTORICAL_RULE_TYPES:
            continue
        rules_by_type[entry.rule_type] = entry.rule_class()
    if not rules_by_type:
        return HistoricalSavingsBreakdown()

    history_counts_by_pair = Counter(
        (row.opportunity_id, row.detection_job_id) for row in history_rows
    )
    candidate_cache: dict[
        tuple[str, str, datetime.date | None], list[OpportunityCandidate]
    ] = {}
    savings_by_opportunity_id: dict[str, Decimal] = defaultdict(_zero)
    cost_by_opportunity_id: dict[str, Decimal] = defaultdict(_zero)
    matched_detection_counts: dict[str, int] = defaultdict(int)

    for row in history_rows:
        opportunity = opps_by_id.get(row.opportunity_id)
        if opportunity is None:
            continue

        rule = rules_by_type.get(opportunity.opportunity_type)
        sync_id = sync_id_by_detection_job.get(row.detection_job_id)
        if rule is None or not sync_id:
            continue

        # Backfilled history stores many day-level detections against one current
        # detection_job_id. In that case, reconstruct only that specific day's jobs.
        day_key = None
        if history_counts_by_pair[(row.opportunity_id, row.detection_job_id)] > 1:
            day_key = _history_day_key(row.detected_at)

        cache_key = (rule.rule_type, sync_id, day_key)
        candidates = candidate_cache.get(cache_key)
        if candidates is None:
            historical_jobs = (
                jobs_by_sync_and_day.get((sync_id, day_key), [])
                if day_key is not None
                else jobs_by_sync.get(sync_id, [])
            )
            candidates = (
                rule.detect(historical_jobs, None, rule.get_thresholds())
                if historical_jobs
                else []
            )
            candidate_cache[cache_key] = candidates

        match = next(
            (
                candidate
                for candidate in candidates
                if candidate.opportunity_type == opportunity.opportunity_type
                and candidate.affected_table == opportunity.affected_table
            ),
            None,
        )
        if match is None:
            continue

        historical_savings = _coerce_decimal(match.expected_savings)
        historical_cost = _coerce_decimal(match.current_cost_estimate)
        if historical_savings <= 0:
            continue

        savings_by_opportunity_id[opportunity.id] += historical_savings
        cost_by_opportunity_id[opportunity.id] += historical_cost
        matched_detection_counts[opportunity.id] += 1

    return HistoricalSavingsBreakdown(
        savings_by_opportunity_id=dict(savings_by_opportunity_id),
        cost_by_opportunity_id=dict(cost_by_opportunity_id),
        matched_detection_counts=dict(matched_detection_counts),
    )
