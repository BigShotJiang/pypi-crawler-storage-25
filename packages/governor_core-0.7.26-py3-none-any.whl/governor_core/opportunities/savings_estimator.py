"""
Workload-based savings estimation engine for partition & cluster recommendations.

Analyses synced BigQuery job SQL to estimate how much data would be pruned
by the recommended partitioning or clustering configuration.

Pipeline:
  1. Parse WHERE/JOIN predicates from each job's SQL using sqlglot
  2. Estimate partition pruning savings per job (using INFORMATION_SCHEMA.PARTITIONS data)
  3. Estimate cluster pruning savings per job (using column cardinality tiers)
  4. Aggregate into an opportunity-level savings estimate with confidence scoring
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from decimal import Decimal

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from governor_core.opportunities.savings_models import (
    ClusterEstimate,
    ColumnStats,
    JobSavingsDetail,
    OpportunitySavingsEstimate,
    PartitionEstimate,
    PartitionStats,
    Predicate,
    SavingsRecommendation,
    TableStats,
)

logger = logging.getLogger(__name__)

# BigQuery on-demand pricing: $6.25 per TiB
_BQ_PRICE_PER_TB = Decimal("6.25")
_BYTES_PER_TB = Decimal(str(1024**4))
_BQ_PRICE_PER_BYTE = _BQ_PRICE_PER_TB / _BYTES_PER_TB

# Maximum jobs to analyse per opportunity (sample by cost if exceeded)
_MAX_JOBS = 1000

_HEURISTIC_PARTITION_EQ_PRUNING = 0.85
_HEURISTIC_PARTITION_RANGE_PRUNING = 0.35
_HEURISTIC_PARTITION_MIN_PRUNING = 0.05
_DEFAULT_CLUSTER_EQ_PRUNING_WITHOUT_STATS = 0.35
_DEFAULT_CLUSTER_RANGE_PRUNING_WITHOUT_STATS = 0.20
_DEFAULT_CLUSTER_NULL_PRUNING_WITHOUT_STATS = 0.02


# ---------------------------------------------------------------------------
# 1. SQL Predicate Extractor
# ---------------------------------------------------------------------------


def _resolve_table_alias(
    parsed: exp.Expression,
    target_table: str,
) -> set[str]:
    """Find all aliases used for target_table in FROM / JOIN clauses."""
    aliases: set[str] = set()
    target_lower = target_table.lower()
    target_parts = target_lower.split(".")

    for table_node in parsed.find_all(exp.Table):
        table_name = (table_node.name or "").lower()
        catalog = (table_node.catalog or "").lower()
        db = (table_node.db or "").lower()

        # Match on full qualified name or just table name
        full_name = ".".join(p for p in [catalog, db, table_name] if p)
        matched = (
            table_name == target_parts[-1]
            or full_name == target_lower
            or (
                len(target_parts) >= 2
                and f"{db}.{table_name}" == ".".join(target_parts[-2:])
            )
        )

        if matched:
            alias = table_node.alias
            if alias:
                aliases.add(alias.lower())
            aliases.add(table_name)

    return aliases


def _is_function_wrapped(column_node: exp.Expression) -> bool:
    """Check if a column reference is wrapped in a function call."""
    parent = column_node.parent
    while parent is not None:
        if isinstance(parent, (exp.Anonymous, exp.Func)) and not isinstance(
            parent, (exp.Cast,)
        ):
            return True
        if isinstance(
            parent,
            (
                exp.Where,
                exp.Join,
                exp.And,
                exp.Or,
                exp.Not,
                exp.Paren,
                exp.Binary,
                exp.Between,
                exp.In,
            ),
        ):
            return False
        parent = parent.parent
    return False


def _extract_literal_value(node: exp.Expression) -> str | None:
    """Extract a string representation of a literal value."""
    if isinstance(node, exp.Literal):
        return node.this
    if isinstance(node, exp.Neg) and isinstance(node.this, exp.Literal):
        return f"-{node.this.this}"
    return None


def _column_matches(
    col_node: exp.Column,
    target_columns: list[str],
    table_aliases: set[str],
) -> str | None:
    """Check if a column node references one of our target columns.

    Returns the matched column name (lowercase) or None.
    """
    col_name = (col_node.name or "").lower()
    col_table = (col_node.table or "").lower()

    if col_name not in [c.lower() for c in target_columns]:
        return None

    # If column has a table qualifier, check it matches our aliases
    if col_table and col_table not in table_aliases:
        return None

    return col_name


def extract_table_predicates(
    sql: str,
    target_table: str,
    target_columns: list[str],
) -> list[Predicate]:
    """Parse SQL and extract WHERE/JOIN predicates on target columns.

    Args:
        sql: The BigQuery SQL to parse.
        target_table: Fully-qualified or short table name.
        target_columns: Columns we care about (partition/cluster columns).

    Returns:
        List of Predicate objects found.
    """
    if not sql or not target_columns:
        return []

    try:
        parsed_list = sqlglot.parse(sql, read="bigquery", error_level="warn")
    except SqlglotError:
        logger.debug("sqlglot failed to parse SQL for predicate extraction")
        return []

    predicates: list[Predicate] = []
    target_cols_lower = [c.lower() for c in target_columns]

    for parsed in parsed_list:
        if parsed is None:
            continue

        table_aliases = _resolve_table_alias(parsed, target_table)
        if not table_aliases:
            # Table not referenced in this statement
            continue

        # Walk all comparison / filter nodes
        for node in parsed.walk():
            _extract_from_node(node, target_cols_lower, table_aliases, predicates)

    return predicates


def _extract_from_node(
    node: exp.Expression,
    target_cols: list[str],
    table_aliases: set[str],
    predicates: list[Predicate],
) -> None:
    """Extract predicates from a single AST node."""

    # Equality / comparison: col = val, col > val, etc.
    if isinstance(node, (exp.EQ, exp.GT, exp.GTE, exp.LT, exp.LTE, exp.NEQ)):
        op_map = {
            exp.EQ: "eq",
            exp.GT: "gt",
            exp.GTE: "gte",
            exp.LT: "lt",
            exp.LTE: "lte",
            exp.NEQ: "neq",
        }
        left, right = node.left, node.right

        # Check if left side is our column
        for col_node in [left, right]:
            other = right if col_node is left else left
            if isinstance(col_node, exp.Column):
                matched = _column_matches(col_node, target_cols, table_aliases)
                if matched:
                    val = _extract_literal_value(other)
                    func_wrapped = _is_function_wrapped(col_node)
                    predicates.append(
                        Predicate(
                            column=matched,
                            operator=op_map[type(node)],
                            values=[val] if val is not None else [],
                            is_partition_compatible=not func_wrapped,
                        )
                    )
                    return
            # Check if column is inside a function (e.g., DATE(col) = '...')
            elif isinstance(col_node, (exp.Anonymous, exp.Func)):
                for inner_col in col_node.find_all(exp.Column):
                    matched = _column_matches(inner_col, target_cols, table_aliases)
                    if matched:
                        val = _extract_literal_value(other)
                        predicates.append(
                            Predicate(
                                column=matched,
                                operator=op_map[type(node)],
                                values=[val] if val is not None else [],
                                is_partition_compatible=False,
                            )
                        )
                        return

    # BETWEEN: col BETWEEN a AND b
    elif isinstance(node, exp.Between):
        col_node = node.this
        if isinstance(col_node, exp.Column):
            matched = _column_matches(col_node, target_cols, table_aliases)
            if matched:
                low = _extract_literal_value(node.args.get("low"))
                high = _extract_literal_value(node.args.get("high"))
                predicates.append(
                    Predicate(
                        column=matched,
                        operator="between",
                        values=[low, high],
                        is_partition_compatible=True,
                    )
                )
        elif isinstance(col_node, (exp.Anonymous, exp.Func)):
            for inner_col in col_node.find_all(exp.Column):
                matched = _column_matches(inner_col, target_cols, table_aliases)
                if matched:
                    low = _extract_literal_value(node.args.get("low"))
                    high = _extract_literal_value(node.args.get("high"))
                    predicates.append(
                        Predicate(
                            column=matched,
                            operator="between",
                            values=[low, high],
                            is_partition_compatible=False,
                        )
                    )

    # IN: col IN (a, b, c)
    elif isinstance(node, exp.In):
        col_node = node.this
        if isinstance(col_node, exp.Column):
            matched = _column_matches(col_node, target_cols, table_aliases)
            if matched:
                vals = []
                for expr in node.expressions:
                    v = _extract_literal_value(expr)
                    if v is not None:
                        vals.append(v)
                predicates.append(
                    Predicate(
                        column=matched,
                        operator="in",
                        values=vals,
                        is_partition_compatible=True,
                    )
                )

    # IS NULL / IS NOT NULL
    elif isinstance(node, exp.Is):
        col_node = node.left
        if isinstance(col_node, exp.Column):
            matched = _column_matches(col_node, target_cols, table_aliases)
            if matched:
                if isinstance(node.args.get("expression"), exp.Null):
                    # Check if it's IS NOT NULL (wrapped in Not)
                    is_not = isinstance(node.parent, exp.Not)
                    predicates.append(
                        Predicate(
                            column=matched,
                            operator="is_not_null" if is_not else "is_null",
                            values=[],
                            is_partition_compatible=True,
                        )
                    )


# ---------------------------------------------------------------------------
# 2. Partition Pruning Estimator
# ---------------------------------------------------------------------------


def _partition_id_from_value(value: str, partition_type: str) -> str | None:
    """Convert a literal date/timestamp value to a BigQuery partition_id string."""
    # Strip quotes if present
    value = value.strip("'\"").strip()
    normalized = re.sub(r"\s+UTC$", "+00:00", value, flags=re.IGNORECASE)
    normalized = normalized.replace("Z", "+00:00")

    try:
        dt = datetime.fromisoformat(normalized)
    except ValueError:
        dt = None

    if dt is None:
        for fmt in (
            "%Y-%m-%d",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S.%f",
        ):
            try:
                dt = datetime.strptime(value, fmt)
                break
            except ValueError:
                continue

    if dt is not None:
        if partition_type == "DAY":
            return dt.strftime("%Y%m%d")
        if partition_type == "MONTH":
            return dt.strftime("%Y%m")
        if partition_type == "YEAR":
            return dt.strftime("%Y")
        if partition_type == "HOUR":
            return dt.strftime("%Y%m%d%H")

    # Try plain YYYYMMDD
    cleaned = re.sub(r"[^0-9]", "", value)
    if len(cleaned) >= 8:
        return (
            cleaned[:8]
            if partition_type == "DAY"
            else cleaned[:6]
            if partition_type == "MONTH"
            else cleaned[:4]
        )

    return None


def _heuristic_partition_pruning_fraction(predicate: Predicate) -> float:
    """Low-confidence pruning estimate when exact partition metadata is unavailable."""
    if predicate.operator == "eq":
        return _HEURISTIC_PARTITION_EQ_PRUNING
    if predicate.operator == "in":
        value_count = max(sum(1 for value in predicate.values if value is not None), 1)
        return max(
            _HEURISTIC_PARTITION_MIN_PRUNING,
            _HEURISTIC_PARTITION_EQ_PRUNING - ((value_count - 1) * 0.10),
        )
    if predicate.operator == "between":
        return _HEURISTIC_PARTITION_RANGE_PRUNING
    if predicate.operator in {"gt", "gte", "lt", "lte"}:
        return _HEURISTIC_PARTITION_RANGE_PRUNING - 0.05
    if predicate.operator == "is_null":
        return 0.10
    return 0.0


def estimate_partition_savings_without_metadata(
    predicates: list[Predicate],
    partition_column: str,
    total_bytes: int,
) -> PartitionEstimate:
    """Estimate partition pruning with predicate-only heuristics.

    This path is intentionally conservative and should be treated as low
    confidence compared with INFORMATION_SCHEMA-backed estimates.
    """
    if total_bytes <= 0:
        return PartitionEstimate(0, 0, 0.0, False, True)

    part_preds = [p for p in predicates if p.column == partition_column.lower()]
    if not part_preds:
        return PartitionEstimate(0, total_bytes, 0.0, False, True)

    compatible_preds = [p for p in part_preds if p.is_partition_compatible]
    if not compatible_preds:
        return PartitionEstimate(0, total_bytes, 0.0, True, False)

    pruned_fraction = max(
        (_heuristic_partition_pruning_fraction(pred) for pred in compatible_preds),
        default=0.0,
    )
    pruned_bytes = int(total_bytes * pruned_fraction)

    return PartitionEstimate(
        pruned_bytes=pruned_bytes,
        total_bytes=total_bytes,
        pruned_fraction=pruned_fraction,
        filter_found=True,
        partition_compatible=True,
    )


def estimate_partition_savings(
    predicates: list[Predicate],
    partition_column: str,
    partition_stats: PartitionStats,
) -> PartitionEstimate:
    """Estimate bytes saved from partition pruning for a single query.

    Returns a PartitionEstimate with the fraction of bytes that would be pruned.
    """
    total_bytes = partition_stats.total_bytes
    if total_bytes <= 0:
        return PartitionEstimate(0, 0, 0.0, False, True)

    # Find predicates on the partition column
    part_preds = [p for p in predicates if p.column == partition_column.lower()]

    if not part_preds:
        return PartitionEstimate(0, total_bytes, 0.0, False, True)

    # Check if any predicate is partition-incompatible (function-wrapped)
    has_compatible = any(p.is_partition_compatible for p in part_preds)
    if not has_compatible:
        return PartitionEstimate(0, total_bytes, 0.0, True, False)

    # Use the most restrictive compatible predicate
    compatible_preds = [p for p in part_preds if p.is_partition_compatible]

    matched_partitions: set[str] = set()

    for pred in compatible_preds:
        if pred.operator == "eq" and pred.values:
            pid = _partition_id_from_value(
                pred.values[0], partition_stats.partition_type
            )
            if pid:
                matched_partitions.add(pid)

        elif pred.operator == "in" and pred.values:
            for v in pred.values:
                if v:
                    pid = _partition_id_from_value(v, partition_stats.partition_type)
                    if pid:
                        matched_partitions.add(pid)

        elif pred.operator in ("gte", "gt") and pred.values:
            pid = _partition_id_from_value(
                pred.values[0], partition_stats.partition_type
            )
            if pid:
                for part_id in partition_stats.partitions:
                    if part_id >= pid:
                        matched_partitions.add(part_id)

        elif pred.operator in ("lte", "lt") and pred.values:
            pid = _partition_id_from_value(
                pred.values[0], partition_stats.partition_type
            )
            if pid:
                for part_id in partition_stats.partitions:
                    if part_id <= pid:
                        matched_partitions.add(part_id)

        elif pred.operator == "between" and len(pred.values) >= 2:
            low_pid = (
                _partition_id_from_value(pred.values[0], partition_stats.partition_type)
                if pred.values[0]
                else None
            )
            high_pid = (
                _partition_id_from_value(pred.values[1], partition_stats.partition_type)
                if pred.values[1]
                else None
            )
            if low_pid and high_pid:
                for part_id in partition_stats.partitions:
                    if low_pid <= part_id <= high_pid:
                        matched_partitions.add(part_id)

    matched_partition_bytes = 0

    # If we matched specific partitions, calculate bytes for those partitions
    if matched_partitions:
        for pid in matched_partitions:
            info = partition_stats.partitions.get(pid)
            if info:
                matched_partition_bytes += info.total_logical_bytes
            else:
                # Unknown partition — conservative: assume average size
                avg_bytes = total_bytes // max(len(partition_stats.partitions), 1)
                matched_partition_bytes += avg_bytes
    else:
        matched_partition_bytes = _estimate_matched_partition_bytes_without_ids(
            compatible_preds,
            partition_stats,
        )

    pruned_bytes = max(total_bytes - matched_partition_bytes, 0)
    pruned_fraction = pruned_bytes / total_bytes if total_bytes > 0 else 0.0

    return PartitionEstimate(
        pruned_bytes=pruned_bytes,
        total_bytes=total_bytes,
        pruned_fraction=pruned_fraction,
        filter_found=True,
        partition_compatible=True,
    )


def _estimate_matched_partition_bytes_without_ids(
    compatible_preds: list[Predicate],
    partition_stats: PartitionStats,
) -> int:
    """Approximate matched bytes when partition IDs cannot be resolved exactly."""
    total_bytes = partition_stats.total_bytes
    partition_count = max(len(partition_stats.partitions), 1)
    avg_partition_bytes = max(total_bytes // partition_count, 1)
    matched_candidates: list[int] = []

    for pred in compatible_preds:
        if pred.operator == "eq":
            matched_candidates.append(avg_partition_bytes)
        elif pred.operator == "in":
            value_count = max(sum(1 for value in pred.values if value is not None), 1)
            matched_candidates.append(
                min(avg_partition_bytes * value_count, total_bytes)
            )
        elif pred.operator == "between":
            matched_candidates.append(int(total_bytes * 0.65))
        elif pred.operator in {"gt", "gte", "lt", "lte"}:
            matched_candidates.append(int(total_bytes * 0.70))
        elif pred.operator == "is_null":
            matched_candidates.append(int(total_bytes * 0.90))

    if matched_candidates:
        return max(min(matched_candidates), 1)

    return int(total_bytes * 0.80)


# ---------------------------------------------------------------------------
# 3. Cluster Pruning Estimator
# ---------------------------------------------------------------------------

# Conservative pruning tiers based on column cardinality
_CLUSTER_PRUNING_TIERS = [
    (10_000, 0.95),  # > 10K distinct: 95% pruning on equality
    (1_000, 0.90),  # 1K-10K: 90%
    (100, 0.70),  # 100-1K: 70%
    (10, 0.50),  # 10-100: 50%
    (0, 0.20),  # < 10: 20% (low cardinality, minimal benefit)
]


def _cardinality_pruning_factor(distinct_values: int) -> float:
    """Map column cardinality to conservative pruning estimate for equality filter."""
    for threshold, factor in _CLUSTER_PRUNING_TIERS:
        if distinct_values >= threshold:
            return factor
    return 0.0


def estimate_cluster_savings(
    predicates: list[Predicate],
    cluster_columns: list[str],
    table_stats: TableStats | None,
    column_stats: dict[str, ColumnStats] | None = None,
    remaining_bytes: int | None = None,
    cluster_position_offset: int = 0,
) -> ClusterEstimate:
    """Estimate bytes saved from cluster-key-aligned block pruning.

    Args:
        predicates: Parsed predicates from the query.
        cluster_columns: Recommended cluster columns (ordered).
        table_stats: Table-level storage statistics.
        column_stats: Optional cardinality data per column.
        remaining_bytes: Bytes after partition pruning (use this instead of total if set).
        cluster_position_offset: Existing leading cluster columns already on the table.
    """
    if not cluster_columns:
        return ClusterEstimate(0, 0, 0.0, False)

    if remaining_bytes is not None:
        effective_bytes = remaining_bytes
    elif table_stats:
        effective_bytes = (
            table_stats.total_billable_bytes or table_stats.total_logical_bytes
        )
    else:
        effective_bytes = 0

    if effective_bytes <= 0:
        return ClusterEstimate(0, 0, 0.0, False)

    cluster_cols_lower = [c.lower() for c in cluster_columns]

    # Find predicates on cluster columns
    col_predicates: dict[str, list[Predicate]] = {}
    for pred in predicates:
        if pred.column in cluster_cols_lower:
            col_predicates.setdefault(pred.column, []).append(pred)

    if not col_predicates:
        return ClusterEstimate(0, effective_bytes, 0.0, False)

    # Calculate pruning per cluster column
    # BigQuery clusters in column order — first column has most impact
    combined_kept_fraction = 1.0

    for i, col in enumerate(cluster_cols_lower):
        preds = col_predicates.get(col, [])
        if not preds:
            continue

        has_stats = bool(column_stats and col in column_stats)
        distinct = column_stats[col].approx_distinct if has_stats else 0

        # Find the best (most restrictive) predicate for this column
        best_pruning = 0.0

        for pred in preds:
            if pred.operator in ("eq", "in"):
                if has_stats:
                    pruning = _cardinality_pruning_factor(distinct)
                else:
                    pruning = _DEFAULT_CLUSTER_EQ_PRUNING_WITHOUT_STATS
                # For IN with multiple values, reduce pruning proportionally
                if pred.operator == "in" and pred.values:
                    n_values = len(pred.values)
                    # Each additional value reduces the pruning
                    pruning = max(
                        pruning * (1 - (n_values - 1) / max(distinct, n_values)), 0.0
                    )
                best_pruning = max(best_pruning, pruning)

            elif pred.operator in ("gt", "gte", "lt", "lte", "between"):
                range_pruning = (
                    0.50 if has_stats else _DEFAULT_CLUSTER_RANGE_PRUNING_WITHOUT_STATS
                )
                best_pruning = max(best_pruning, range_pruning)

            elif pred.operator in ("is_not_null",):
                # IS NOT NULL: minimal pruning unless high NULL ratio
                if has_stats:
                    null_ratio = column_stats[col].null_ratio
                    best_pruning = max(best_pruning, null_ratio * 0.8)
                else:
                    best_pruning = max(
                        best_pruning,
                        _DEFAULT_CLUSTER_NULL_PRUNING_WITHOUT_STATS,
                    )

        # Columns beyond the first cluster column get reduced benefit
        if i + cluster_position_offset > 0:
            best_pruning *= 0.5

        combined_kept_fraction *= 1 - best_pruning

    pruned_fraction = 1 - combined_kept_fraction
    pruned_bytes = int(effective_bytes * pruned_fraction)

    return ClusterEstimate(
        pruned_bytes=pruned_bytes,
        total_bytes=effective_bytes,
        pruned_fraction=pruned_fraction,
        filter_found=True,
    )


# ---------------------------------------------------------------------------
# 4. Opportunity-Level Aggregator
# ---------------------------------------------------------------------------


def _bytes_to_usd(bytes_saved: int) -> Decimal:
    """Convert bytes saved to USD using BigQuery on-demand pricing."""
    return Decimal(str(bytes_saved)) * _BQ_PRICE_PER_BYTE


def _compute_confidence(
    jobs_analyzed: int,
    jobs_with_filters: int,
) -> str:
    """Determine confidence level from job count and filter coverage."""
    if jobs_analyzed == 0:
        return "low"

    coverage = jobs_with_filters / jobs_analyzed

    if jobs_analyzed >= 20 and coverage >= 0.80:
        return "high"
    if jobs_analyzed >= 5 and coverage >= 0.40:
        return "medium"
    return "low"


def _downgrade_confidence(confidence: str) -> str:
    if confidence == "high":
        return "medium"
    return "low"


def estimate_opportunity_savings(
    opportunity_id: str,
    recommendation: SavingsRecommendation,
    jobs: list[dict],
    target_table: str,
    partition_stats: PartitionStats | None,
    table_stats: TableStats | None,
    column_stats: dict[str, ColumnStats] | None = None,
    observation_days: int = 30,
) -> OpportunitySavingsEstimate:
    """Aggregate per-job savings into an opportunity-level estimate.

    Args:
        opportunity_id: The opportunity being estimated.
        recommendation: Recommended partition/cluster columns.
        jobs: List of dicts with keys: job_id, query, total_bytes_billed, total_cost.
        target_table: The table being optimised.
        partition_stats: Partition distribution (None if table not partitioned).
        table_stats: Table-level storage statistics.
        column_stats: Column cardinality data keyed by lowercase column name.
        observation_days: Number of days the jobs span.
    """
    # Determine which columns to look for in predicates
    target_columns: list[str] = []
    if recommendation.partition_column:
        target_columns.append(recommendation.partition_column)
    target_columns.extend(recommendation.cluster_columns)

    if not target_columns:
        return OpportunitySavingsEstimate(opportunity_id=opportunity_id)

    # Determine recommendation type from the recommendation itself, not from
    # whichever metadata happened to load successfully.
    has_partition = recommendation.partition_column is not None
    has_cluster = len(recommendation.cluster_columns) > 0
    if has_partition and has_cluster:
        rec_type = "both"
    elif has_partition:
        rec_type = "partition"
    else:
        rec_type = "cluster"

    original_job_count = len(jobs)

    # Sample if too many jobs
    if original_job_count > _MAX_JOBS:
        jobs = sorted(jobs, key=lambda j: j.get("total_cost") or 0, reverse=True)[
            :_MAX_JOBS
        ]
        sample_ratio = Decimal(str(len(jobs))) / Decimal(str(original_job_count))
    else:
        sample_ratio = Decimal("1")

    total_cost_saved = Decimal("0")
    total_bytes_scanned = 0
    total_bytes_saved = 0
    jobs_with_partition_filter = 0
    jobs_with_cluster_filter = 0
    job_details: list[JobSavingsDetail] = []

    for job in jobs:
        sql = job.get("query") or ""
        job_id = job.get("job_id", "")
        bytes_billed = int(job.get("total_bytes_billed") or 0)
        job_cost = Decimal(str(job.get("total_cost") or 0))

        if not sql or bytes_billed <= 0:
            continue

        total_bytes_scanned += bytes_billed

        # Parse predicates
        predicates = extract_table_predicates(sql, target_table, target_columns)

        partition_savings_bytes = 0
        cluster_savings_bytes = 0
        has_part_filter = False
        has_clust_filter = False

        # Partition pruning
        if has_partition and recommendation.partition_column:
            if partition_stats is not None:
                part_est = estimate_partition_savings(
                    predicates,
                    recommendation.partition_column,
                    partition_stats,
                )
            else:
                part_est = estimate_partition_savings_without_metadata(
                    predicates,
                    recommendation.partition_column,
                    bytes_billed,
                )
            if part_est.filter_found:
                has_part_filter = True
                # Scale partition pruning to this job's bytes
                partition_savings_bytes = int(bytes_billed * part_est.pruned_fraction)

        # Cluster pruning (on remaining bytes after partition pruning)
        if has_cluster:
            remaining = bytes_billed - partition_savings_bytes
            if remaining > 0:
                clust_est = estimate_cluster_savings(
                    predicates,
                    recommendation.cluster_columns,
                    table_stats,
                    column_stats=column_stats,
                    remaining_bytes=remaining,
                    cluster_position_offset=recommendation.cluster_position_offset,
                )
                if clust_est.filter_found:
                    has_clust_filter = True
                    cluster_savings_bytes = int(remaining * clust_est.pruned_fraction)

        job_bytes_saved = partition_savings_bytes + cluster_savings_bytes
        job_savings_usd = _bytes_to_usd(job_bytes_saved)

        # Sanity cap: savings cannot exceed job cost
        if job_savings_usd > job_cost:
            job_savings_usd = job_cost
            job_bytes_saved = bytes_billed

        if has_part_filter:
            jobs_with_partition_filter += 1
        if has_clust_filter:
            jobs_with_cluster_filter += 1

        total_bytes_saved += job_bytes_saved
        total_cost_saved += job_savings_usd

        job_details.append(
            JobSavingsDetail(
                job_id=job_id,
                job_cost=job_cost,
                bytes_billed=bytes_billed,
                partition_savings_usd=_bytes_to_usd(partition_savings_bytes),
                cluster_savings_usd=_bytes_to_usd(cluster_savings_bytes),
                total_savings_usd=job_savings_usd,
                has_partition_filter=has_part_filter,
                has_cluster_filter=has_clust_filter,
            )
        )

    # Scale back up if we sampled
    if sample_ratio != Decimal("1"):
        total_cost_saved = total_cost_saved / sample_ratio
        total_bytes_saved = int(total_bytes_saved / float(sample_ratio))
        total_bytes_scanned = int(total_bytes_scanned / float(sample_ratio))

    jobs_analyzed = len(job_details)
    jobs_with_filters = max(jobs_with_partition_filter, jobs_with_cluster_filter)

    per_run_savings = total_cost_saved / max(jobs_analyzed, 1)
    monthly_factor = Decimal(str(30)) / Decimal(str(max(observation_days, 1)))
    monthly_projection = total_cost_saved * monthly_factor

    filter_coverage = Decimal(str(jobs_with_filters * 100)) / Decimal(
        str(max(jobs_analyzed, 1))
    )
    confidence = _compute_confidence(jobs_analyzed, jobs_with_filters)
    if has_partition and partition_stats is None:
        confidence = _downgrade_confidence(confidence)
    if has_cluster and not column_stats:
        confidence = _downgrade_confidence(confidence)

    return OpportunitySavingsEstimate(
        opportunity_id=opportunity_id,
        recommendation_type=rec_type,
        partition_column=recommendation.partition_column,
        cluster_columns=list(recommendation.cluster_columns),
        jobs_analyzed=jobs_analyzed,
        jobs_with_partition_filter=jobs_with_partition_filter,
        jobs_with_cluster_filter=jobs_with_cluster_filter,
        total_bytes_scanned=total_bytes_scanned,
        total_bytes_saved=total_bytes_saved,
        total_cost_saved=total_cost_saved,
        per_run_savings=per_run_savings,
        monthly_projection=monthly_projection,
        confidence=confidence,
        filter_coverage_pct=filter_coverage,
        observation_days=observation_days,
        job_details=job_details,
    )
