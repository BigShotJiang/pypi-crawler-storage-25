"""
Service layer for Cost Optimization Opportunity Detection.

Provides CRUD operations, deduplication, and lifecycle management for
detection jobs and opportunities.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from governor_core.opportunities.exceptions import (
    ActiveDetectionJobExistsError,
    DetectionJobExistsError,
    DetectionJobNotFoundError,
    LatestCompletedSyncNotFoundError,
    SyncNotCompletedError,
)
from governor_core.opportunities.models import (
    DetectionJob,
    Opportunity,
    OpportunityDetectionHistory,
)
from governor_core.opportunities.rules.base import OpportunityCandidate

if TYPE_CHECKING:
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.sync.models import SyncOperation
    from sqlalchemy.orm import Session


logger = logging.getLogger(__name__)


class OpportunityService:
    """
    Service for managing detection jobs and opportunities.

    Provides:
    - Detection job queuing and lifecycle management
    - Opportunity persistence with table-level deduplication
    - Opportunity lifecycle management (resolution, purge)
    """

    def __init__(self, db: Session) -> None:
        """Initialize with database session."""
        self.db = db

    # -------------------------------------------------------------------------
    # Detection Job Management
    # -------------------------------------------------------------------------

    def create_detection_job(
        self,
        config_id: str,
        sync_id: str,
    ) -> DetectionJob:
        """
        Queue a detection job after sync completion.

        Args:
            config_id: Project sync configuration ID
            sync_id: Completed sync operation ID

        Returns:
            DetectionJob with status='queued'

        Raises:
            DetectionJobExistsError: If job already exists for this sync
            SyncNotCompletedError: If sync is not completed
        """
        # Verify sync is completed
        from governor_core.sync.models import SyncOperation

        sync = self.db.get(SyncOperation, sync_id)
        if not sync:
            raise SyncNotCompletedError(sync_id, "not_found")
        if sync.status != "completed":
            raise SyncNotCompletedError(sync_id, sync.status)

        # Check for existing detection job
        existing = self.db.execute(
            select(DetectionJob).where(DetectionJob.sync_id == sync_id)
        ).scalar_one_or_none()

        if existing:
            raise DetectionJobExistsError(sync_id)

        # Create new detection job
        job = DetectionJob(
            config_id=config_id,
            sync_id=sync_id,
            status="queued",
        )
        self.db.add(job)
        self.db.flush()

        logger.info(f"Detection job queued: {job.id} for sync {sync_id}")
        return job

    def get_latest_completed_sync(self, config_id: str) -> SyncOperation | None:
        """Return the latest completed sync for a configuration."""
        from governor_core.sync.models import SyncOperation

        return (
            self.db.execute(
                select(SyncOperation)
                .where(
                    SyncOperation.config_id == config_id,
                    SyncOperation.status == "completed",
                )
                .order_by(
                    SyncOperation.completed_at.desc(),
                    SyncOperation.queued_at.desc(),
                )
            )
            .scalars()
            .first()
        )

    def queue_detection_rerun_for_latest_sync(self, config_id: str) -> DetectionJob:
        """Queue a detection rerun using the latest completed sync data."""
        sync = self.get_latest_completed_sync(config_id)
        if not sync:
            raise LatestCompletedSyncNotFoundError(config_id)
        return self.create_detection_rerun_job(config_id=config_id, sync_id=sync.id)

    def create_detection_rerun_job(self, config_id: str, sync_id: str) -> DetectionJob:
        """Queue a new detection job for a completed sync that has run before."""
        from governor_core.sync.models import SyncOperation

        sync = self.db.get(SyncOperation, sync_id)
        if not sync:
            raise SyncNotCompletedError(sync_id, "not_found")
        if sync.status != "completed":
            raise SyncNotCompletedError(sync_id, sync.status)

        active_job = self.db.execute(
            select(DetectionJob).where(
                DetectionJob.sync_id == sync_id,
                DetectionJob.status.in_(("queued", "in_progress")),
            )
        ).scalar_one_or_none()
        if active_job:
            raise ActiveDetectionJobExistsError(config_id, sync_id)

        job = DetectionJob(
            config_id=config_id,
            sync_id=sync_id,
            status="queued",
        )
        self.db.add(job)
        try:
            self.db.flush()
        except IntegrityError as exc:
            self.db.rollback()
            raise ActiveDetectionJobExistsError(config_id, sync_id) from exc

        logger.info("Detection rerun queued: %s for sync %s", job.id, sync_id)
        return job

    def get_detection_job(self, detection_job_id: str) -> DetectionJob | None:
        """
        Retrieve a detection job by ID.

        Args:
            detection_job_id: Detection job UUID

        Returns:
            DetectionJob or None if not found
        """
        return self.db.get(DetectionJob, detection_job_id)

    def get_pending_detection_job(self) -> DetectionJob | None:
        """
        Get the next queued detection job for processing (FIFO).

        Returns:
            Oldest queued DetectionJob or None if queue empty
        """
        result = self.db.execute(
            select(DetectionJob)
            .where(DetectionJob.status == "queued")
            .order_by(DetectionJob.queued_at.asc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    def claim_detection_job(self, detection_job_id: str) -> bool:
        """
        Atomically claim a detection job for processing.

        Uses optimistic locking to ensure only one worker can claim a job.

        Args:
            detection_job_id: Detection job to claim

        Returns:
            True if claimed successfully, False if already claimed
        """
        result = self.db.execute(
            update(DetectionJob)
            .where(
                DetectionJob.id == detection_job_id,
                DetectionJob.status == "queued",
            )
            .values(
                status="in_progress",
                started_at=datetime.now(timezone.utc),
                updated_at=datetime.now(timezone.utc),
            )
        )

        if result.rowcount == 1:
            self.db.flush()
            logger.info(f"Detection job claimed: {detection_job_id}")
            return True

        logger.warning(f"Failed to claim detection job: {detection_job_id}")
        return False

    def complete_detection_job(
        self,
        detection_job_id: str,
        found_count: int,
        updated_count: int,
        resolved_count: int,
    ) -> DetectionJob:
        """
        Mark a detection job as completed.

        Args:
            detection_job_id: Detection job ID
            found_count: New opportunities created
            updated_count: Existing opportunities updated
            resolved_count: Opportunities marked resolved

        Returns:
            Updated DetectionJob

        Raises:
            DetectionJobNotFoundError: If job not found
        """
        job = self.db.get(DetectionJob, detection_job_id)
        if not job:
            raise DetectionJobNotFoundError(detection_job_id)

        job.status = "completed"
        job.completed_at = datetime.now(timezone.utc)
        job.opportunities_found_count = found_count
        job.opportunities_updated_count = updated_count
        job.opportunities_resolved_count = resolved_count
        self.db.flush()

        logger.info(
            f"Detection job completed: {detection_job_id}, "
            f"found={found_count}, updated={updated_count}, resolved={resolved_count}"
        )
        return job

    def fail_detection_job(
        self,
        detection_job_id: str,
        error_message: str,
    ) -> DetectionJob:
        """
        Mark a detection job as failed, potentially retrying.

        If retry_count < 3, increments retry and sets status back to 'queued'.
        Otherwise, sets status to 'failed' permanently.

        Args:
            detection_job_id: Detection job ID
            error_message: Sanitized error description

        Returns:
            Updated DetectionJob

        Raises:
            DetectionJobNotFoundError: If job not found
        """
        job = self.db.get(DetectionJob, detection_job_id)
        if not job:
            raise DetectionJobNotFoundError(detection_job_id)

        job.retry_count += 1
        job.error_message = error_message

        if job.retry_count < 3:
            # Retry with exponential backoff (handled by worker polling)
            job.status = "queued"
            job.started_at = None
            logger.warning(
                f"Detection job {detection_job_id} failed, retry {job.retry_count}/3: {error_message}"
            )
        else:
            # Permanent failure
            job.status = "failed"
            job.completed_at = datetime.now(timezone.utc)
            logger.error(
                f"Detection job {detection_job_id} permanently failed after 3 retries: {error_message}"
            )

        self.db.flush()
        return job

    # -------------------------------------------------------------------------
    # Opportunity Management
    # -------------------------------------------------------------------------

    def persist_opportunity(
        self,
        config_id: str,
        manifest_version_id: str | None,
        detection_job_id: str,
        candidate: OpportunityCandidate,
        lookback_window_days: int = 30,
    ) -> tuple[Opportunity, str]:
        """
        Persist or update an opportunity with manifest-level deduplication.

        Deduplication key: (opportunity_type, affected_table, config_id)

        Args:
            config_id: Manifest location ID (stable identity)
            manifest_version_id: Manifest version active at detection time
            detection_job_id: Detection job that found this opportunity
            candidate: Opportunity data from detection rule

        Returns:
            Tuple of (Opportunity, action) where action is:
            - 'created': New opportunity created
            - 'updated': Existing active opportunity updated
            - 'reactivated': Resolved opportunity reactivated
        """
        # Check for existing opportunity
        existing = self.db.execute(
            select(Opportunity).where(
                Opportunity.opportunity_type == candidate.opportunity_type,
                Opportunity.affected_table == candidate.affected_table,
                Opportunity.config_id == config_id,
            )
        ).scalar_one_or_none()

        now = datetime.now(timezone.utc)

        if existing:
            action = "updated"
            if existing.status == "resolved":
                if existing.verified_savings_status is not None:
                    # Resolved via merged PR — do NOT reactivate.
                    # The issue is still detected but cost tracking is in progress.
                    # Update detection tracking but keep resolved status.
                    existing.last_detected_at = now
                    existing.consecutive_clean_days = 0
                    existing.last_detection_job_id = detection_job_id
                    self.db.flush()
                    return existing, "skipped_pr_resolved"
                # Reactivate resolved opportunity (auto-resolved, no PR)
                existing.status = "active"
                existing.resolved_at = None
                action = "reactivated"

            # Update with fresh data
            existing.severity_score = candidate.severity_score
            existing.evidence_snapshot = candidate.evidence_snapshot
            existing.current_cost_estimate = candidate.current_cost_estimate
            existing.expected_savings = candidate.expected_savings
            existing.explanation = candidate.explanation
            existing.related_job_ids = candidate.related_job_ids
            existing.dbt_model_name = candidate.dbt_model_name
            existing.manifest_version_id = manifest_version_id
            existing.last_detection_job_id = detection_job_id

            # Rolling window: update detection tracking
            existing.last_detected_at = now
            existing.consecutive_clean_days = 0

            self.db.flush()

            # Create detection history entry
            history_entry = OpportunityDetectionHistory(
                opportunity_id=existing.id,
                detection_job_id=detection_job_id,
                detected_at=now,
            )
            self.db.add(history_entry)
            self.db.flush()

            # Recalculate occurrence count
            self.recalculate_occurrence_count(existing.id, lookback_window_days)

            logger.debug(
                f"Opportunity {action}: {existing.id} "
                f"({candidate.opportunity_type} on {candidate.affected_table})"
            )
            return existing, action

        # Create new opportunity
        opportunity = Opportunity(
            config_id=config_id,
            manifest_version_id=manifest_version_id,
            opportunity_type=candidate.opportunity_type,
            affected_table=candidate.affected_table,
            status="active",
            severity_score=candidate.severity_score,
            evidence_snapshot=candidate.evidence_snapshot,
            current_cost_estimate=candidate.current_cost_estimate,
            expected_savings=candidate.expected_savings,
            explanation=candidate.explanation,
            related_job_ids=candidate.related_job_ids,
            dbt_model_name=candidate.dbt_model_name,
            first_detection_job_id=detection_job_id,
            last_detection_job_id=detection_job_id,
            last_detected_at=now,
            consecutive_clean_days=0,
        )
        self.db.add(opportunity)
        self.db.flush()

        # Create detection history entry
        history_entry = OpportunityDetectionHistory(
            opportunity_id=opportunity.id,
            detection_job_id=detection_job_id,
            detected_at=now,
        )
        self.db.add(history_entry)
        self.db.flush()

        # Recalculate occurrence count
        self.recalculate_occurrence_count(opportunity.id, lookback_window_days)

        logger.debug(
            f"Opportunity created: {opportunity.id} "
            f"({candidate.opportunity_type} on {candidate.affected_table})"
        )
        return opportunity, "created"

    def mark_resolved(
        self,
        config_id: str,
        detected_keys: set[tuple[str, str]],
    ) -> int:
        """
        Mark opportunities not re-detected as resolved, scoped to a single manifest.

        Only affects opportunities under the specified manifest location.
        Sibling manifests' opportunities are NOT affected.

        Args:
            config_id: Manifest location that was analysed
            detected_keys: Set of (opportunity_type, affected_table) pairs detected

        Returns:
            Count of opportunities marked resolved
        """
        # Get all active opportunities for this manifest
        active_opportunities = (
            self.db.execute(
                select(Opportunity).where(
                    Opportunity.config_id == config_id,
                    Opportunity.status == "active",
                )
            )
            .scalars()
            .all()
        )

        resolved_count = 0
        now = datetime.now(timezone.utc)

        for opp in active_opportunities:
            key = (opp.opportunity_type, opp.affected_table)
            if key not in detected_keys:
                opp.status = "resolved"
                opp.resolved_at = now
                resolved_count += 1
                logger.debug(
                    f"Opportunity resolved: {opp.id} "
                    f"({opp.opportunity_type} on {opp.affected_table})"
                )

        if resolved_count > 0:
            self.db.flush()
            logger.info(
                f"Marked {resolved_count} opportunities as resolved "
                f"for manifest {config_id}"
            )

        return resolved_count

    def evaluate_resolution(
        self,
        config_id: str,
        detected_keys: set[tuple[str, str]],
        resolution_period_days: int = 15,
    ) -> int:
        """
        Evaluate active/clearing opportunities for resolution based on consecutive
        clean days.

        Two-phase lifecycle:
        - active → clearing: when opportunity not detected in latest sync
        - clearing → resolved: after resolution_period_days consecutive clean days
        - clearing → active: if re-detected during the clearing window

        Args:
            config_id: Manifest configuration that was analysed
            detected_keys: Set of (opportunity_type, affected_table) pairs detected
            resolution_period_days: Consecutive clean days before resolution

        Returns:
            Count of opportunities resolved
        """
        # Fetch both active and clearing opportunities
        candidates = (
            self.db.execute(
                select(Opportunity).where(
                    Opportunity.config_id == config_id,
                    Opportunity.status.in_(["active", "clearing"]),
                )
            )
            .scalars()
            .all()
        )

        resolved_count = 0
        clearing_count = 0
        reactivated_count = 0
        now = datetime.now(timezone.utc)
        today = now.date()

        for opp in candidates:
            key = (opp.opportunity_type, opp.affected_table)

            if key in detected_keys:
                # Re-detected: if it was clearing, reactivate it — BUT only
                # if this is detection-based clearing (no clearing_until).
                # PR-based clearing (clearing_until set) must not be overridden
                # by re-detection; the cost data is still settling.
                if opp.status == "clearing" and opp.clearing_until is None:
                    opp.status = "active"
                    opp.consecutive_clean_days = 0
                    reactivated_count += 1
                    logger.debug(
                        f"Opportunity reactivated: {opp.id} "
                        f"({opp.opportunity_type} on {opp.affected_table})"
                    )
                continue

            # Safety: skip if no last_detected_at (no history yet)
            if opp.last_detected_at is None:
                continue

            # Calculate consecutive clean days based on calendar days
            clean_days = (today - opp.last_detected_at.date()).days
            opp.consecutive_clean_days = clean_days

            if clean_days >= resolution_period_days:
                # Phase 2: clearing → resolved
                opp.status = "resolved"
                opp.resolved_at = now
                resolved_count += 1
                logger.debug(
                    f"Opportunity resolved: {opp.id} "
                    f"({opp.opportunity_type} on {opp.affected_table}) "
                    f"after {clean_days} consecutive clean days"
                )
            elif opp.status == "active":
                # Phase 1: active → clearing (first time not detected)
                opp.status = "clearing"
                clearing_count += 1
                # Delete solutions and cancel pending jobs — the issue may
                # already be fixed so the old solution is stale.
                self._clear_solutions_for_opportunity(opp.id)
                opp.latest_solution_dry_run_original_cost = None
                opp.latest_solution_dry_run_modified_cost = None
                logger.debug(
                    f"Opportunity clearing: {opp.id} "
                    f"({opp.opportunity_type} on {opp.affected_table}) "
                    f"clean_days={clean_days}"
                )

        self.db.flush()

        if resolved_count > 0:
            logger.info(
                f"Resolved {resolved_count} opportunities for config {config_id} "
                f"(threshold: {resolution_period_days} days)"
            )
        if clearing_count > 0:
            logger.info(
                f"Moved {clearing_count} opportunities to clearing for config {config_id}"
            )
        if reactivated_count > 0:
            logger.info(
                f"Reactivated {reactivated_count} opportunities for config {config_id}"
            )

        return resolved_count

    def _clear_solutions_for_opportunity(self, opportunity_id: str) -> None:
        """Delete solutions and cancel pending solution jobs for an opportunity."""
        from governor_core.solutions.models import Solution, SolutionJob

        # Cancel pending/in-progress solution jobs
        self.db.query(SolutionJob).filter(
            SolutionJob.opportunity_id == opportunity_id,
            SolutionJob.status.in_(["queued", "in_progress"]),
        ).update(
            {
                "status": "failed",
                "error_message": "Cancelled: opportunity entered clearing status",
                "completed_at": datetime.now(timezone.utc),
            },
            synchronize_session="fetch",
        )

        # Delete solutions
        deleted = (
            self.db.query(Solution)
            .filter(Solution.opportunity_id == opportunity_id)
            .delete(synchronize_session="fetch")
        )
        if deleted:
            logger.debug(
                "Cleared %d solution(s) for clearing opportunity %s",
                deleted,
                opportunity_id,
            )

    def resolve_opportunities_for_rule_types(
        self,
        config_id: str,
        rule_types: set[str],
    ) -> int:
        """
        Resolve active opportunities for deselected rule types under one config.

        Args:
            config_id: Manifest configuration ID
            rule_types: Opportunity rule types to resolve

        Returns:
            Count of active opportunities resolved
        """
        if not rule_types:
            return 0

        opportunities = (
            self.db.execute(
                select(Opportunity).where(
                    Opportunity.config_id == config_id,
                    Opportunity.status == "active",
                    Opportunity.opportunity_type.in_(sorted(rule_types)),
                )
            )
            .scalars()
            .all()
        )

        if not opportunities:
            return 0

        now = datetime.now(timezone.utc)
        for opportunity in opportunities:
            opportunity.status = "resolved"
            opportunity.resolved_at = now

        self.db.flush()
        logger.info(
            "Resolved %s active opportunities for config %s due to deselected rules %s",
            len(opportunities),
            config_id,
            sorted(rule_types),
        )
        return len(opportunities)

    def recalculate_occurrence_count(
        self,
        opportunity_id: str,
        lookback_window_days: int = 30,
    ) -> int:
        """
        Recalculate occurrence_count from detection history.

        Counts distinct calendar days with at least one detection history entry
        within the lookback window.

        Args:
            opportunity_id: Opportunity to recalculate
            lookback_window_days: Days to look back

        Returns:
            The computed occurrence count
        """
        from sqlalchemy import func

        cutoff = datetime.now(timezone.utc) - timedelta(days=lookback_window_days)

        count = self.db.execute(
            select(
                func.count(
                    func.distinct(func.date(OpportunityDetectionHistory.detected_at))
                )
            ).where(
                OpportunityDetectionHistory.opportunity_id == opportunity_id,
                OpportunityDetectionHistory.detected_at >= cutoff,
            )
        ).scalar_one()

        # Update the opportunity
        opp = self.db.get(Opportunity, opportunity_id)
        if opp:
            opp.occurrence_count = count
            self.db.flush()

        return count

    def purge_detection_history(self, retention_days: int = 90) -> int:
        """
        Delete detection history entries older than retention_days.

        Called alongside purge_resolved() on schedule.

        Args:
            retention_days: Days to retain detection history (default 90)

        Returns:
            Count of entries purged
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)

        to_delete = (
            self.db.execute(
                select(OpportunityDetectionHistory).where(
                    OpportunityDetectionHistory.detected_at < cutoff,
                )
            )
            .scalars()
            .all()
        )

        count = len(to_delete)
        for entry in to_delete:
            self.db.delete(entry)

        if count > 0:
            self.db.flush()
            logger.info(
                f"Purged {count} detection history entries older than {retention_days} days"
            )

        return count

    def backfill_detection_history(
        self,
        config_id: str,
        detection_job_id: str,
        lookback_window_days: int = 30,
    ) -> int:
        """
        Backfill detection history from historical BigQuery jobs on first sync.

        Groups all BigQuery jobs for the config (within lookback window) by calendar day,
        runs detection rules against each day's jobs, and creates detection history entries.

        Args:
            config_id: Manifest configuration ID
            detection_job_id: Current detection job ID
            lookback_window_days: Days to look back for historical jobs

        Returns:
            Total detection history entries created
        """
        from governor_core.sync.models import BigQueryJob
        from governor_core.opportunities.detector import DetectionEngine, select_rules_for_config

        cutoff = datetime.now(timezone.utc) - timedelta(days=lookback_window_days)

        # Load all BigQuery jobs for this config within the lookback window
        jobs = list(
            self.db.execute(
                select(BigQueryJob).where(
                    BigQueryJob.config_id == config_id,
                    BigQueryJob.creation_time >= cutoff,
                )
            )
            .scalars()
            .all()
        )

        if not jobs:
            logger.info(f"No historical jobs found for backfill (config={config_id})")
            return 0

        # Group jobs by calendar day
        from collections import defaultdict

        jobs_by_day: dict[str, list] = defaultdict(list)
        for job in jobs:
            day_key = job.creation_time.date().isoformat()
            jobs_by_day[day_key].append(job)

        # Get the latest manifest content for running detection rules
        from governor_core.configurations.models import ManifestConfiguration

        config: ManifestConfiguration | None = self.db.get(
            ManifestConfiguration, config_id
        )
        manifest_content = None
        if config and config.manifest_versions:
            latest_version = sorted(
                config.manifest_versions,
                key=lambda v: v.created_at,
                reverse=True,
            )[0]
            manifest_content = (
                latest_version.content if hasattr(latest_version, "content") else None
            )

        # Run detection for each day
        engine = DetectionEngine()
        selected_rules = select_rules_for_config(engine.get_enabled_rules(), config)
        total_entries = 0

        logger.info(
            "Backfill rule selection for config %s: mode=%s configured=%s effective=%s unavailable=%s unknown=%s",
            config_id,
            selected_rules.mode,
            selected_rules.configured_rule_types,
            selected_rules.effective_rule_types,
            selected_rules.unavailable_rule_types,
            selected_rules.unknown_rule_types,
        )

        for day_key in sorted(jobs_by_day.keys()):
            day_jobs = jobs_by_day[day_key]
            day_start = datetime.fromisoformat(day_key).replace(tzinfo=timezone.utc)

            # Run detection rules against this day's jobs
            for rule in selected_rules.effective_rules:
                try:
                    thresholds = rule.get_thresholds()
                    candidates = rule.detect(day_jobs, manifest_content, thresholds)

                    for candidate in candidates:
                        # Look up the opportunity by dedup key
                        opp = self.db.execute(
                            select(Opportunity).where(
                                Opportunity.opportunity_type
                                == candidate.opportunity_type,
                                Opportunity.affected_table == candidate.affected_table,
                                Opportunity.config_id == config_id,
                            )
                        ).scalar_one_or_none()

                        if opp:
                            entry = OpportunityDetectionHistory(
                                opportunity_id=opp.id,
                                detection_job_id=detection_job_id,
                                detected_at=day_start,
                            )
                            self.db.add(entry)
                            total_entries += 1

                except (SQLAlchemyError, ValueError, TypeError, KeyError) as e:
                    logger.warning(
                        f"Backfill rule {rule.rule_type} failed for day {day_key}: {e}"
                    )

        if total_entries > 0:
            self.db.flush()

            # Recalculate occurrence counts for all affected opportunities
            affected_opps = (
                self.db.execute(
                    select(Opportunity).where(
                        Opportunity.config_id == config_id,
                        Opportunity.status == "active",
                    )
                )
                .scalars()
                .all()
            )

            for opp in affected_opps:
                self.recalculate_occurrence_count(opp.id, lookback_window_days)

        logger.info(
            f"Backfill completed for config {config_id}: "
            f"{total_entries} history entries created from {len(jobs_by_day)} days"
        )

        return total_entries

    def purge_resolved(self, retention_days: int = 90) -> int:
        """
        Permanently delete resolved opportunities past retention period.

        Args:
            retention_days: Days to retain resolved opportunities (default 90)

        Returns:
            Count of opportunities deleted
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)

        # Get opportunities to delete
        to_delete = (
            self.db.execute(
                select(Opportunity).where(
                    Opportunity.status == "resolved",
                    Opportunity.resolved_at < cutoff,
                )
            )
            .scalars()
            .all()
        )

        count = len(to_delete)
        for opp in to_delete:
            self.db.delete(opp)

        if count > 0:
            self.db.flush()
            logger.info(
                f"Purged {count} resolved opportunities older than {retention_days} days"
            )

        return count

    def get_opportunities_for_config(
        self,
        config_id: str,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Opportunity]:
        """
        List opportunities for a manifest configuration.

        Args:
            config_id: Manifest configuration ID
            status: Filter by status ('active', 'resolved') or None for all
            limit: Maximum records to return
            offset: Pagination offset

        Returns:
            List of opportunities ordered by severity_score DESC
        """
        query = select(Opportunity).where(Opportunity.config_id == config_id)

        if status:
            query = query.where(Opportunity.status == status)

        query = (
            query.order_by(Opportunity.severity_score.desc())
            .offset(offset)
            .limit(limit)
        )

        return list(self.db.execute(query).scalars().all())

    def get_opportunities_count_for_config(
        self,
        config_id: str,
        status: str | None = None,
    ) -> int:
        """
        Count opportunities for a manifest configuration.

        Args:
            config_id: Manifest configuration ID
            status: Filter by status or None for all

        Returns:
            Count of matching opportunities
        """
        from sqlalchemy import func

        query = select(func.count(Opportunity.id)).where(
            Opportunity.config_id == config_id
        )

        if status:
            query = query.where(Opportunity.status == status)

        return self.db.execute(query).scalar_one()


def run_scheduled_purge(db: "Session", retention_days: int = 90) -> int:
    """
    Scheduled task to purge resolved opportunities past retention period.

    This function is designed to be called by a scheduler (cron, APScheduler, etc.)
    or manually via CLI. It creates a service instance and runs the purge.

    Args:
        db: Database session
        retention_days: Days to retain resolved opportunities (default 90)

    Returns:
        Count of opportunities purged

    Example usage with cron (daily at 2am):
        0 2 * * * cd /app && python -c "from governor_core.db.session import SessionLocal; \\
            from governor_core.opportunities.service import run_scheduled_purge; \\
            db = SessionLocal(); run_scheduled_purge(db); db.commit(); db.close()"

    Example usage with APScheduler:
        scheduler.add_job(
            run_scheduled_purge,
            'cron',
            hour=2,
            args=[SessionLocal()],
        )
    """
    service = OpportunityService(db)
    count = service.purge_resolved(retention_days=retention_days)
    history_count = service.purge_detection_history(retention_days=retention_days)
    logger.info(
        f"Scheduled purge completed: {count} opportunities purged, "
        f"{history_count} detection history entries purged"
    )
    return count
