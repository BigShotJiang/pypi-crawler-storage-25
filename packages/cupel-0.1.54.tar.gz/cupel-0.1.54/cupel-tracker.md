# cupel — project tracker

> separates precious LLMs from base LLMs. works with any OpenAI/Anthropic compatible API

## what cupel does

cupel sends the same prompts to multiple LLMs (local or API — Anthropic, OpenRouter, OpenAI), collects responses, scores them with a configurable judge, and shows results on a leaderboard — in the browser or terminal.

ships with a web UI. `pip install cupel && cupel` → browser opens → user is exploring real eval data in under 10 seconds.

## project structure

```
cupel/                              ← repo root (at /Users/tolitius/1/fun/cupel)
├── pyproject.toml                  ← hatchling build, entry point: cupel.cli:main
├── README.md
├── cupel-tracker.md                ← this file
├── config.yml                      ← user config (not packaged)
├── config.example.yml
├── .env                            ← user secrets (not packaged)
├── _env.example
├── eval.py                         ← backward-compat wrapper (old CLI)
├── server.py                       ← backward-compat wrapper (old server)
│
├── cupel/                          ← the Python package (this ships via pip)
│   ├── __init__.py                 ← __version__ = "0.1.0"
│   ├── __main__.py                 ← python -m cupel support
│   ├── cli.py          (509 lines) ← argparse: cupel run/judge/ui/init, cmd_run, cmd_judge
│   ├── eval.py         (513 lines) ← core engine: call_llm, run_prompt, score_one, run_eval, judge_results
│   ├── server.py      (1100 lines) ← FastAPI app, all API endpoints, SSE jobs, _start_ui()
│   ├── config.py       (125 lines) ← DEFAULTS, load_config, load_dotenv, get_api_config, get_judge_config, get_providers_config, LOCAL_PROVIDER_KEYS, resolve_api_key_for_port
│   ├── discovery.py    (146 lines) ← discover_providers(), detect_hardware(), PROBE_PORTS
│   ├── display.py       (76 lines) ← rich terminal: build_table, score_symbol, shorten_model
│   ├── ui/                         ← web dashboard (ships with package, no npm/node)
│   │   ├── index.html   (144 lines) ← shell: Preact+HTM from CDN, topbar (with provider avatars), sidebar (with spacer), hash router
│   │   ├── style.css    (946 lines) ← Stone theme (dark warm gray #1f1e1c, burnt orange accent), 8-tier type scale
│   │   └── pages/
│   │       ├── dashboard.js (442 lines) ← leaderboard table, category breakdown, detail panel, welcome banner, local/examples filters
│   │       ├── run.js       (566 lines) ← "Bench It" page: Models (click-outside-close), IQ Tasks, Judge, Connections, SSE progress, localStorage persistence
│   │       ├── results.js   (186 lines) ← result file browser with sortable columns, expandable detail rows, tagging, delete
│   │       ├── author.js    (217 lines) ← LLM-assisted prompt authoring with live timer and token stats, reads default gen model from config
│   │       ├── evalset.js    (89 lines) ← prompt browser with expandable rubrics
│   │       └── settings.js  (521 lines) ← provider presets (local+cloud), key validation, model fetching with pricing, judge Local/Remote toggle, default gen model, provider test
│   └── data/                       ← ships with package
│       ├── example-run.json        ← pre-baked: 5 models × 8 prompts, scored by Claude Opus 4.6
│       ├── starter-eval-set.json   ← 8-prompt starter set (quick first run)
│       └── eval-set.example.json   ← full 22-prompt example
│
├── eval-sets/                      ← user's eval sets (not packaged)
│   ├── eval-set.json               ← 22 prompts (the full "tolitius eval set v2")
│   └── what-am-i-looking-at.png    ← image for prompt #1 (vision)
│
├── eval-results/                   ← generated output (25+ result JSONs)
│
└── guidelines/                     ← design docs (not packaged)
    ├── cupel-stone-reference.html  ← THE visual reference — match this exactly
    ├── first-run-experience.md     ← first-run flow design doc
    ├── leaderboard.html            ← old Bloomberg-style reference (superseded by Stone)
    └── ui-design-style.md          ← old style doc (superseded by Stone)
```

## how to run

```bash
pip install cupel          # from PyPI (or pip install -e . for dev)
cupel                      # opens browser if no config.yml, prints help if config exists
cupel ui                   # always opens browser
cupel run                  # CLI: collect responses
cupel judge results/*.json # CLI: score with judge model
cupel init                 # create config.yml + eval-sets/eval-set.json
python -m cupel            # same as above
uvicorn cupel.server:app --reload --port 8042  # dev mode
```

## API endpoints (cupel/server.py)

| endpoint | method | purpose |
|---|---|---|
| `/api/state` | GET | `{first_run, has_config, has_eval_set}` — first_run is true when no user results exist |
| `/api/providers` | GET | probe local ports + merge external providers from config. returns `[{url, port, status, models, source, name}]` |
| `/api/providers/keys` | GET | which API key env vars are set: `{ANTHROPIC_API_KEY: true, OPENROUTER_API_KEY: false}` |
| `/api/providers/test` | POST | test connectivity to a provider — tries `/models` endpoint, returns `{ok, models, detail}`. handles connection refused, timeout, auth errors |
| `/api/providers/fetch-models` | POST | fetch model lists from provider APIs (browser can't due to CORS). returns `{models: [{id, pricing?}]}` with per-token pricing when available. Anthropic returns hardcoded models+pricing; OpenAI/OpenRouter call `/models` endpoint |
| `/api/env-check` | GET | check if an arbitrary env var is set: `{key, set}` |
| `/api/hardware` | GET | detect machine: `{name, memory, spec}` |
| `/api/config` | GET/PUT | read/write config.yml as JSON (includes `providers` array, `judge`, `generation_model`) |
| `/api/eval-set` | GET/PUT | read/write eval-set.json (falls back to starter set) |
| `/api/eval-set/prompts` | POST | add a single prompt with auto-ID |
| `/api/results` | GET | list result files with summary metadata + tags |
| `/api/results/leaderboard` | GET | aggregated leaderboard: merges user results + example data, sorted by pct. hardware shows provider name for external runs |
| `/api/results/{filename}` | GET/DELETE | get one result JSON / delete a result file |
| `/api/results/{filename}/tag` | POST | tag a result (stored in `.tags.json`) |
| `/api/compare` | GET | `?prompt_id=N` → all model responses for that prompt (includes examples) |
| `/api/jobs` | POST/GET | start a run/judge job / list all jobs |
| `/api/jobs/{id}` | GET/DELETE | job status / cancel a running job |
| `/api/jobs/{id}/stream` | GET | SSE stream of progress events |
| `/api/generate-prompt` | POST | LLM-assisted prompt generation (accepts `model` param, returns `{prompt, elapsed, prompt_tokens, completion_tokens}`) |
| `/api/init` | POST | create config.yml + eval-set.json |

### provider merging (`/api/providers`)
Local providers are discovered by probing ports. External providers come from `config.providers[]`. Each gets a `source` field (`"local"` or `"external"`). External providers have `status: "configured"` (not "online" since they aren't probed).

### per-model provider resolution (`_resolve_provider`)
When a job uses a model, `_resolve_provider(cfg, model, model_urls)` checks:
1. `config.providers` first — if the model appears in a provider's `models` list, that provider's `api_url` and `api_key_env` are used
2. `model_urls` from UI selection — resolves API key from URL port via `resolve_api_key_for_port()`
3. Falls back to `get_api_config()` (LLM_API_URL/LLM_API_KEY env vars)

### API key resolution for local providers
Each local provider has its own env var: `OMLX_API_KEY`, `OLLAMA_API_KEY`, `LM_STUDIO_API_KEY`, `SGLANG_API_KEY`. `resolve_api_key_for_port(port)` checks the provider-specific key first, falls back to `LLM_API_KEY` for backward compat. Defined in `config.py` `LOCAL_PROVIDER_KEYS` dict.

### .env search order
`load_dotenv()` searches: cwd `.env` → `~/.cupel/.env` → package parent `.env` → home `.env`. First found wins. Only sets vars not already in env.

### leaderboard hardware vs provider
The leaderboard endpoint checks `api_url` from each result file:
- Local URLs (localhost/127.0.0.1) → show local hardware (`Apple M5 Max 128 GB`)
- External URLs → derive provider name (`OpenRouter`, `Anthropic`, `OpenAI`, or hostname)

### generate-prompt JSON extraction
LLM responses often contain thinking text before JSON. The extraction:
1. Searches backwards from last `}` to find a valid `json.loads` candidate (skips stray `{` in thinking text)
2. If no complete JSON found, repairs truncated output (closes open strings and braces)
3. Normalizes field names (`Title`→`title`, `question`→`prompt`, `scoring_rubric`→`rubric`, etc.)
4. Returns `{elapsed, prompt_tokens, completion_tokens}` stats alongside the parsed prompt

### leaderboard response shape
```json
{
  "entries": [{
    "model": "Qwen3-235B-A22B-4bit",
    "total_score": 22, "max_score": 24, "pct": 91.7,
    "scores_by_prompt": [{"id": 3, "score": 3, "elapsed": 32.4, "tokens": 650, "category": "clojure_code", "title": "..."}],
    "hardware": {"name": "Apple M5 Max", "memory": "128 GB"},
    "is_example": true, "self_judged": false,
    "filename": null, "judge_model": "claude-opus-4-6",
    "tok_per_sec": 20.3, "avg_time": 34.2, "timestamp": "20260320_143022"
  }],
  "prompts": [{"id": 3, "category": "clojure_code", "title": "..."}],
  "max_score": 24
}
```

For external provider runs, `hardware` is `{"name": "OpenRouter", "memory": ""}` instead of local machine info.

### job model
Jobs run as asyncio background tasks. In-memory dict of `job_id → Job`.
- `_run_job()` loads image via `find_image()`, then calls `run_prompt()` one at a time, resolving provider per model via `_resolve_provider()`
- After run, auto-judges (self-judge or configured judge)
- SSE events: `{model, prompt_id, status, elapsed}`, then `{type: "complete"}` or `{type: "cancelled"}`
- Partial results saved even when cancelled

### path conventions in server.py
- `PKG_DIR = Path(__file__).parent` — bundled files (ui/, data/)
- `Path.cwd()` — user files (config.yml, .env, eval-results/, eval-sets/)
- `DATA_DIR = PKG_DIR / "data"` — example-run.json, starter-eval-set.json
- `UI_DIR = PKG_DIR / "ui"` — static files served at /
- `RESULTS_DIR = Path.cwd() / "eval-results"`
- `_config_path()` → `Path.cwd() / "config.yml"`
- `_eval_set_path()` → `Path.cwd() / "eval-sets" / "eval-set.json"`

## UI architecture

**Frontend**: Preact + HTM loaded from CDN (esm.sh). No npm, no build step. ES modules in `cupel/ui/pages/`.

**Shell** (index.html): topbar (logo + crumb + provider avatar/name/status pills), sidebar (6 icon buttons with custom SVGs, Settings pushed to bottom via flex spacer), main content area. Hash router (`#/dashboard`, `#/run`, etc.) dynamically imports page modules.

**Sidebar order**: Dashboard, Bench It, Author, Eval Set, Results, Settings. Settings has `spacer: true` which renders a `flex:1` div before it, pushing it to the bottom.

**Page components access Preact via `window.__preact`** — set by index.html: `{h, render, Component, useState, useEffect, useCallback, html}`.

### sidebar icons
Custom SVGs: dashboard (bar chart), run (lightning bolt), results (stacked layers), author (pencil), evalset (grid with dots), settings (gear with center circle).

### pages

| page | route | what it does |
|---|---|---|
| dashboard.js | `#/dashboard` | title strip ("cupel" left / hardware right), stats strip (models, prompts, peak speed, "local only" + "show examples" checkboxes), leaderboard table with per-row judge+hardware/provider metadata, category breakdown, detail panel, welcome banner, sortable columns |
| run.js | `#/run` | "Bench It" — Models (provider-grouped multiselect), IQ Tasks (category group chips), Judge (pre-populated from config default), Connections with provider avatars, SSE progress grid, Stop button |
| results.js | `#/results` | result file list with sortable columns: model, date, score, scored (N/M), judge. clickable rows expand inline detail panel (per-prompt scores, judge reasons, collapsible response/thinking). tag management, delete |
| author.js | `#/author` | describe → pick category (grouped dropdown + custom) → pick model (provider-grouped, reads default from config.generation_model) → generate with live timer → review token stats → edit → save |
| evalset.js | `#/evalset` | browse all prompts with expandable rubrics |
| settings.js | `#/settings` | section order: Hardware → Eval Set → Temp/Tokens → Default Judge (Local/Remote toggle) → Default Generation Model → Provider Keys → Providers (presets + test) → Save |

### topbar (index.html)
Shows online local providers with avatar + name + green dot + URL + model count. Provider info derived from port: 8000→⬢ oMLX, 11434→◎ Ollama, 1234→▣ LM Studio, 30000→◈ SGLang.

### dashboard.js key details
- Fetches `/api/results/leaderboard`, `/api/state`, `/api/hardware`
- Leaderboard rendered as `<table>` — uses classes: `.lb`, `.td-rank`, `.td-model-name`, `.td-bar`, `.bar-track`, `.bar-fill`, `.td-score`, `.td-pct`, `.td-delta`, `.td-speed`
- **Column order**: `# | Model | Score(bar) | % | Pts | Speed | Avg | Δ`. Model column uses `width:1%;white-space:nowrap` to shrink to content, Score bar takes remaining space
- **Accuracy % is the hero number** (20px bold, 22px for winner). Pts demoted to 14px secondary. This avoids misleading comparisons when prompt counts differ across runs
- Winner row (rank #1): class `winner` — warm background, bright orange text/bar
- Example rows: class `is-example` — opacity 0.45
- Sort state: `sortCol`/`sortDir` — all columns clickable
- Detail panel: clicking a row fetches `/api/results/{filename}` and shows per-prompt scores, rubric, judge reasons, collapsible response/thinking
- Welcome banner: shown after 2s on first_run, shows discovered providers, "Run N prompts" CTA
- Title strip: "cupel" left + hardware info right (same row). No subtitle.
- Per-row metadata: shows judge model (or "self-judged" in warning color) + hardware (local) or provider name (external)
- Stats strip: Models, Prompts, Peak Speed, vertically stacked "local only" + "show examples" checkboxes
- **"local only" filter**: `localOnly` state, filters entries by `hardware.memory` presence (cloud runs have empty memory, local runs have e.g. "128 GB")
- Category breakdown table: limited to top 6 models

### run.js key details
- Sections top-to-bottom: **Models → IQ Tasks → Judge → Connections**
- Models: multiselect dropdown with checkboxes, **grouped by provider** (`<optgroup>`). Local and external (API) providers shown. Selected models shown as removable tags. **Click-outside-to-close**: `useEffect` listens for mousedown outside `.model-dropdown-container` when dropdown is open
- IQ Tasks: **category group chips** instead of starter/full radio. Groups: `all`, `starter`, `coding`, `systems`, `reasoning`, `science & ml`, `ops & security`, `general`. Multiple selectable (union). Counts derived from eval set data
- Judge: dropdown grouped by provider with `<optgroup>`. **Pre-populated from config.judge.model** on mount (fetches `/api/config`). Self-judge warning only shows when explicitly set to null, not when using config default
- Connections: shows all providers (local + external) with avatars. Provider name by port (oMLX=8000, Ollama=11434, LM Studio=1234, SGLang=30000), external providers get ☁ avatar
- "Bench It" button in header row, hardware info next to it. **Selections (models, IQ tasks, judge) persist during and after runs**
- **localStorage persistence**: model selections saved to `cupel:bench-models`, IQ task selections saved to `cupel:bench-cats`. Written synchronously inside `toggleModel`/`toggleCat` state updaters. Restored via `useState` lazy initializers on mount. `userChangedModels`/`userChangedCats` flags initialized from localStorage presence. Auto-select effects also check `localStorage.getItem()` directly as a safety net
- SSE progress: connects to `/api/jobs/{id}/stream`, renders grid with text-only status: `...`=running, `jdg`=judging, score=done, `ERR`=error
- Stop button: `DELETE /api/jobs/{id}` → sets cancelled flag → SSE delivers `{type: "cancelled"}`

#### category group mapping
```javascript
CAT_GROUPS = [
  { key: 'coding',    cats: ['clojure_code', 'python_coding', 'clojure_ecosystem'] },
  { key: 'systems',   cats: ['system_design', 'distributed_systems', 'frontend_architecture'] },
  { key: 'reasoning', cats: ['diagnostic_reasoning', 'math_estimation', 'business_logic'] },
  { key: 'science',   cats: ['ml_architecture', 'chemistry'] },
  { key: 'ops',       cats: ['security', 'networking', 'observability'] },
  { key: 'general',   cats: ['domain_knowledge', 'assistant_competence', 'meta', 'multimodal'] },
]
```

### results.js key details
- Sortable columns: Model, Date, Score, Scored, Judge, Tags (click header to sort, arrow indicator)
- **Clickable expandable rows**: clicking a row fetches `/api/results/{filename}` and expands an inline detail panel below the row. Click again to collapse. Shows: model name, judge, score summary, per-prompt list with score badges (color-coded), categories, judge reasons, elapsed time, collapsible response/thinking sections
- Tag and delete buttons use `stopPropagation` to avoid triggering row expansion
- Scored column: shows `num_scored/num_prompts` (e.g. "17/17")
- Judge column: shows which model scored each file

### author.js key details
- Category: `<select>` grouped by CAT_GROUPS with `<optgroup>`. "enter your own…" as first option → reveals text input
- Generation model: `<select>` grouped by provider (local + external API). **Reads default from `config.generation_model`** on mount (fetches `/api/config`). Falls back to first available model if not set
- Live timer: `useEffect` + `setInterval` increments `elapsed` state every second while generating. Shows "● thinking… 12s"
- Token stats: on completion shows "✓ 632 tokens in 3.2s (285 prompt → 632 completion)"
- Error display: reads `detail` from error response body, shows in red box + console
- Generated prompt unwrapping: trusts server normalization, falls back to raw content

### settings.js key details

**Section order** (top to bottom):
1. Hardware
2. Eval Set Path
3. Temperature + Max Output Tokens
4. Default Judge (Local/Remote toggle)
5. Default Generation Model
6. Provider Keys (read-only status)
7. Providers (add/remove/test) — right above Save button. "+ Add Provider" button uses `btn-ghost` with a large (28px) orange "+" sign
8. Save Configuration

**Default Judge**: Local/Remote toggle buttons. Local shows auto-discovered providers; Remote shows configured external providers. Only saves `judge.model` to config (no `api_url`/`api_key_env` — resolved at runtime). Backward compat: `get_judge_config()` still reads old-style `api_url`/`api_key_env` from config if present.

**Default Generation Model**: dropdown of all available models grouped by provider. Saves to `config.generation_model`. Used by Author page as initial model.

**Provider presets**: Two rows of preset buttons:
```
local   [oMLX] [Ollama] [LM Studio] [SGLang]
cloud   [Anthropic] [OpenRouter] [OpenAI] [Custom]
```
Clicking a preset pre-fills name, api_url, api_key_env. Known presets defined in `KNOWN_PROVIDERS` array with `group: 'local'|'cloud'`.

**Key validation**: After api_key_env is filled, calls `GET /api/env-check`. Shows:
- Cloud providers: green "key found" or red "key missing — add to .env or ~/.cupel/.env" (blocks Add Provider)
- Local providers: green "key found" or gray "not set — add to .env if your server requires a key" (does NOT block)

**Model fetching**: "Fetch models" button calls `POST /api/providers/fetch-models`. Returns `[{id, pricing?}]`. Shows checkbox list with pricing labels: `model-name    $3 in / $15 out`. Pricing displayed as $/M tokens. Pre-checks fallback models from preset. Available for cloud (when key found) and local presets.

**Test Connection**: "Test Connection" button in add form, plus "test" button on each existing provider card. Calls `POST /api/providers/test`. Shows inline result: "connected (5 models)" or "connection refused — is the server running?" or "HTTP 401 — check API key".

**Per-provider API keys**: Local provider presets use dedicated env vars (`OMLX_API_KEY`, `OLLAMA_API_KEY`, `LM_STUDIO_API_KEY`, `SGLANG_API_KEY`). Cloud providers use their standard keys (`ANTHROPIC_API_KEY`, `OPENROUTER_API_KEY`, `OPENAI_API_KEY`).

## design system — "Stone" theme

Reference file: `guidelines/cupel-stone-reference.html` — this is the VISUAL TRUTH. When in doubt, match it.

### colors
```css
--bg: #1f1e1c           /* dark warm gray — NOT mid-gray */
--bg-alt: #2a2826       /* bar tracks, alternate backgrounds */
--bg-hover: #32302d     /* hover states */
--bg-panel: #262523     /* topbar, sidebar, panels */
--bg-winner: #2a2520    /* #1 row warm background */
--border: #3e3b38       /* primary borders */
--border-subtle: #332f2d
--text: #e4e0da         /* primary text — WHITE, not orange */
--text-2: #a09a92       /* secondary */
--text-3: #6a6560       /* tertiary, labels */
--accent: #d46a3a       /* burnt orange — #1 rank, active nav, header border, CTAs */
--accent-bright: #e8793f /* winner row elements */
--good: #6aaa6a
--warn: #d4a844
--bad: #c45050
```

### critical style rules
- Logo "cupel" is **WHITE** (`var(--text)`), NOT orange
- Background is **#1f1e1c** (dark warm gray), NOT foggy mid-gray
- Winner bar: opacity 0.85, background `--accent-bright`. 2nd=0.6, 3rd=0.5, rest=0.38
- No rounded corners, no shadows, no gradients, no blue/purple/cyan
- Fonts: Anybody (labels/titles/prose) + IBM Plex Mono (data/numbers/model names)
- Leaderboard header: 2px solid `--accent` bottom border
- Primary buttons: dark text on orange background (`color: #1f1e1c; background: var(--accent)`)

### type scale (8 tiers)
Holistic font-size system — IBM Plex Mono needs larger sizes on dark backgrounds for readability.

| Tier | Size | Role |
|------|------|------|
| XS | 10px | Micro-tags (`.ex-tag`), glyphs, checkbox marks |
| S | 12px | Uppercase labels, units ("tok/s"), small metadata |
| M | 13px | Table headers, secondary data, metadata, chips, disclosure summaries |
| L | 14px | Data cells, body text, form labels, buttons, judge reasons |
| XL | 15px | Model names, stat values, section headings |
| 2XL | 17px | Page titles, winner model/rank |
| 3XL | 20px | Hero accuracy % numbers |
| 4XL | 22px | Score badge, winner accuracy % |

### CSS variable aliases (for backward compat in inline styles)
```css
--bg-0: var(--bg)       --bg-1: var(--bg-panel)
--bg-2: var(--bg-hover) --bg-3: var(--bg-alt)
--text-0: var(--text)   --text-1: var(--text-2)
```

## eval engine (cupel/eval.py)

### key functions
- `call_llm(api_url, api_key, model, prompt, ...)` → `{content, thinking, elapsed_seconds, prompt_tokens, completion_tokens, total_tokens}`
- `_call_llm_raw(...)` — low-level HTTP POST; handles Anthropic vs OpenAI response formats, strips leaked `<think>` tags, captures native tool_calls. Sends `HTTP-Referer` + `X-OpenRouter-Title: cupel` + `User-Agent: cupel/0.1` headers for app identification
- `find_image(image_filename, image_dir)` → base64 string or None. Searches: image_dir → cwd → eval-sets/ → package root → home → ~/eval-images/
- `run_prompt(api_url, api_key, model, p, cfg, image_b64)` → `(result_dict, status_str)` — handles single-turn and multi-turn. Skips prompt #1 (IMAGE_PROMPT_ID) if image_b64 is None
- `_run_multi_turn(...)` — accumulates message history, calls model per turn, handles `inject_after` (for simulated tool results)
- `score_one(api_url, api_key, judge_model, prompt_text, rubric, response_text, responses)` → `(score, reason)`
- `run_eval(models, prompts, cfg, api_url, api_key, image_b64, on_progress)` → `(all_results, saved_files)`
- `judge_results(data_files, judge_model, judge_url, judge_key, rubric_by_id, prompt_by_id, on_progress)` → updated data_files

### HTTP headers for app identification
All outgoing LLM API calls include:
```
HTTP-Referer: https://github.com/tolitius/cupel
X-OpenRouter-Title: cupel
User-Agent: cupel/0.1
```
OpenRouter requires `HTTP-Referer` + `X-OpenRouter-Title` to show the app name in its dashboard (otherwise shows "Unknown").

### provider discovery (cupel/discovery.py)
- Probes ports: 8000 (oMLX/vLLM), 11434 (Ollama), 1234 (LM Studio), 30000 (SGLang)
- Uses per-port API keys via `resolve_api_key_for_port()` — e.g. port 8000 checks `OMLX_API_KEY` first, falls back to `LLM_API_KEY`
- Treats HTTP 401/403 as "online" (server running, just needs auth)
- Checks `LLM_API_URL` env first, then probes known ports

### config (cupel/config.py)
- `DEFAULTS`: eval_set=`eval-sets/eval-set.json`, output_dir=`./eval-results`, temp=0, max_tokens=16384, generation_model=""
- `IMAGE_PROMPT_ID = 1` (prompt #1 is the vision prompt)
- `LOCAL_PROVIDER_KEYS = {8000: "OMLX_API_KEY", 11434: "OLLAMA_API_KEY", 1234: "LM_STUDIO_API_KEY", 30000: "SGLANG_API_KEY"}`
- `resolve_api_key_for_port(port)` — checks provider-specific key first, falls back to `LLM_API_KEY`
- `load_config()` — looks in cwd then package parent for config.yml
- `load_dotenv()` — loads .env from: cwd → `~/.cupel/.env` → package parent → home
- `get_providers_config(cfg)` — returns `cfg.providers` list or `[]`

### external providers config
```yaml
# config.yml
providers:
  - name: anthropic
    api_url: https://api.anthropic.com/v1/messages
    api_key_env: ANTHROPIC_API_KEY
    models: [claude-opus-4-6, claude-sonnet-4-6]
  - name: openrouter
    api_url: https://openrouter.ai/api/v1/chat/completions
    api_key_env: OPENROUTER_API_KEY
    models: [google/gemini-2.5-pro, deepseek/deepseek-r1]
  - name: omlx
    api_url: http://localhost:8000/v1/chat/completions
    api_key_env: OMLX_API_KEY
    models: [Qwen3.5-122B-A10B-4bit]
```

### .env file
```bash
# ~/.cupel/.env or project .env
OMLX_API_KEY=4242
OLLAMA_API_KEY=abc
ANTHROPIC_API_KEY=sk-ant-...
OPENROUTER_API_KEY=sk-or-...
# Legacy (still works as fallback for local providers):
# LLM_API_KEY=4242
```

## eval set structure

22 prompts in "tolitius eval set v2":
```
 1  multimodal               Image ID — Quantum Tunneling (requires image)
 2  security                 EDR Terminal Visibility
 3  clojure_code             Clojure Code Reading — expand-all-vars
 4  distributed_systems      Kafka Storage Internals
 5  ml_architecture          MoE Architecture — Router and Active Params
 6  python_coding            Thread-Safe Python Decorator
 7  business_logic           Invoice Reserved vs Pending Logic
 8  clojure_ecosystem        Clojure State Management — mount vs Component vs Integrant
 9  frontend_architecture    Microfrontend Decomposition
10  domain_knowledge         Telecom Data Model — Parcel/Address/Drop
11  system_design            AI Agent for Production Support
12  observability            Prometheus Counter Over Time Range
13  networking               VLAN / Subnet Troubleshooting
14  math_estimation          Model Memory from Quantization
15  diagnostic_reasoning     Fridge Airflow Troubleshooting
16  meta                     Benchmark Design Criteria
17  chemistry                Stoichiometry — CO2 from Pentane Combustion
18  assistant_competence     Multi-Entity Data Report — Student Tracker
19  assistant_competence     Constrained Report — Meeting Notes Formatter
20  assistant_competence     Data Pivot — Quarterly Sales with Filtering
21  assistant_competence     Tool Calling — School Status Check (multi-turn)
22  assistant_competence     Tool Calling — Conditional Workflow (multi-turn)
```

**Starter set** (8 prompts for quick first run): IDs 3, 7, 10, 11, 14, 15, 18, 21

**Example run data** (cupel/data/example-run.json): 5 models × 8 starter prompts, scored by Claude Opus 4.6:
- Qwen3-235B-A22B-4bit (22/24), Mistral-Large-3-123B-4bit (20/24), Qwen3-32B-8bit (18/24), Gemma-3-27B-8bit (14/24), Llama-4-Scout-17B-4bit (10/24)

## result file format

Each result JSON:
```json
{
  "model": "Qwen3.5-35B-A3B-bf16",
  "api_url": "http://localhost:8000/v1/chat/completions",
  "thinking_budget": null,
  "timestamp": "20260325_002242",
  "eval_set": "tolitius eval set v2",
  "judge": "claude-opus-4-6",
  "judge_url": "https://api.anthropic.com/v1/messages",
  "results": [
    {
      "id": 3, "title": "...", "category": "clojure_code",
      "prompt": "...", "response": "...", "thinking": "...",
      "elapsed_seconds": 12.3, "completion_tokens": 650,
      "score": 3, "judge_reason": "...", "judge_model": "claude-opus-4-6"
    }
  ]
}
```

Multi-turn results additionally have: `"turns": [...]`, `"responses": ["turn1 response", "turn2 response"]`

## known issues / things to fix

1. **Old root-level files**: `eval.py`, `server.py`, `eval-set.json`, `what-am-i-looking-at.png` still exist at repo root as backward-compat wrappers. Should be cleaned up or properly wrapped.
2. **Self-judge warning**: the UI shows a warning banner but doesn't visually distinguish self-judged score cells (dashed borders not implemented in dashboard table)
3. **Welcome banner**: the "Run N prompts" button navigates to `#/run` but doesn't pre-select a model
4. **Category breakdown**: shows all categories from all prompts even if a model only ran 8 of 22 — results in misleading 0/3 scores for categories not tested
5. **Provider discovery**: runs synchronously on server import (`load_dotenv()` is called at module level), which blocks for ~2s × 4 ports on every import
6. **No `cupel judge` from UI**: the run page auto-judges after running, but there's no way to re-judge existing results from the UI
7. **~~Page state lost on navigation~~**: ~~hash-based routing re-mounts page components when navigating away and back — run selections, author progress, etc. are lost.~~ **Fixed for Bench It page**: model and IQ task selections now persist via `localStorage`. Author page progress still lost on navigation.

## user context

- Mac M5 Max, 128GB unified memory
- Primary inference server: oMLX on localhost:8000 (key: OMLX_API_KEY)
- Judge: Claude Opus 4.6 via Anthropic API
- External providers: OpenRouter for cloud models (grok, gemini, etc.)
- Communication style: lowercase, terse, direct. Code over prose. Show don't tell.
- Prefers: Clojure ecosystem, distributed systems, practical domain knowledge
