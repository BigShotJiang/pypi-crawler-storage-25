import math

class Calculator:
    def __init__(self):
        self.history = []

    def add_to_history(self, operation):
        self.history.append(operation)

    def calculate(self, op, x, y=None):
        """
    Perform mathematical calculations.

    Args:
        op (str): The operator ('+', '-', '*', '/', 'pow', 'sqrt').
        x (float): The first number.
        y (float, optional): The second number. 
        
    Note: 
        For 'sqrt', the 'y' parameter is ignored. Only 'x' is required.
    """
        try:
            if op == '+':
                result = x + y
            elif op == '-':
                result = x - y
            elif op == '*':
                result = x * y
            elif op == '/':
                if y == 0:
                    raise ZeroDivisionError("Can't be divided by zero!")
                result = x / y
            elif op == 'pow':
                result = math.pow(x, y)
            elif op == 'sqrt':
                if x < 0:
                    raise ValueError("The square root of a negative number cannot be taken!")
                result = math.sqrt(x)
            else:
                return "Invalid Transaction!"

            # Geçmişe kaydet
            self.add_to_history(f"{x} {op} {y if y is not None else ''} = {result}")
            return result

        except Exception as e:
            return f"An error occurred: {e}"

    def show_history(self):
        print("\n--- Transaction History ---")
        for item in self.history:
            print(item)
