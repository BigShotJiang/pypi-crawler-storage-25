import time
import dataclasses
import logging
from typing import Optional, List, Dict, Any, Callable

from ..user_context import set_current_user, clear_current_user, add_to_request_context
from .models import UserInfo, AccessKeyVerifyResult, AigcAuthError
from .client import AigcAuthClient

logger = logging.getLogger(__name__)


def setLogger(log):
    global logger
    logger = log


class AuthMiddleware:
    """
    通用认证中间件

    支持 FastAPI 和 Flask

    FastAPI 使用方法:
        from fastapi import FastAPI, Request
        from sdk import AigcAuthClient, AuthMiddleware

        app = FastAPI()
        client = AigcAuthClient(app_id="xxx", app_secret="xxx")
        auth_middleware = AuthMiddleware(client)

        @app.middleware("http")
        async def auth_middleware_handler(request: Request, call_next):
            return await auth_middleware.fastapi_middleware(request, call_next)

    Flask 使用方法:
        from flask import Flask
        from sdk import AigcAuthClient, AuthMiddleware

        app = Flask(__name__)
        client = AigcAuthClient(app_id="xxx", app_secret="xxx")
        auth_middleware = AuthMiddleware(client)

        @app.before_request
        def before_request():
            return auth_middleware.flask_before_request()
    """

    def __init__(
        self,
        client: AigcAuthClient,
        exclude_paths: List[str] = None,
        exclude_prefixes: List[str] = None,
        enable_stats: bool = True,
        stats_api_url: Optional[str] = None
    ):
        """
        初始化中间件

        Args:
            client: AigcAuthClient 实例
            exclude_paths: 排除的路径列表（精确匹配）
            exclude_prefixes: 排除的路径前缀列表
            enable_stats: 是否启用接口统计（默认启用）
            stats_api_url: 统计接口 URL（可选，默认使用 client.base_url/sdk）
        """
        self.client = client
        self.exclude_paths = exclude_paths or []
        self.exclude_prefixes = exclude_prefixes or []
        self.enable_stats = enable_stats
        
        # 如果启用统计，初始化全局统计收集器
        if self.enable_stats:
            self.stats_api_url = stats_api_url or f"{self.client.base_url}/sdk"
            self._init_global_stats_collector()
    
    def _init_global_stats_collector(self):
        """初始化全局统计收集器（只初始化一次）"""
        if not self.enable_stats:
            return
        
        try:
            from ..api_stats_collector import init_api_stats_collector, get_api_stats_collector
            
            # 检查是否已经初始化
            if get_api_stats_collector() is not None:
                return
            
            init_api_stats_collector(
                api_url=self.stats_api_url,
                app_id=self.client.app_id,
                app_secret=self.client.app_secret,
                batch_size=10,
                flush_interval=5.0,
                enabled=True
            )
        except Exception as e:
            logger.warning(f"初始化统计收集器失败: {e}")
    
    @staticmethod
    def _collect_flask_request_params(request) -> Dict[str, Any]:
        """
        收集 Flask 请求的所有参数
        
        Args:
            request: Flask request 对象
            
        Returns:
            包含 headers, query_params, view_params, request_body, form_params 的字典
        """
        try:
            params = {
                "headers": dict(request.headers),
                "query_params": request.args.to_dict(flat=False),
                "view_params": request.view_args or {},
                "request_body": None,
                "form_params": None
            }
            
            # 获取 content-type
            content_type = request.headers.get('Content-Type', '').lower()
            
            # 获取请求体（使用白名单方式，只处理已知安全的内容类型）
            if request.is_json:
                try:
                    params["request_body"] = request.get_json(silent=True)
                except Exception:
                    pass
            elif 'application/x-www-form-urlencoded' in content_type:
                # 表单数据
                if request.form:
                    params["form_params"] = request.form.to_dict(flat=False)
            elif 'multipart/form-data' in content_type:
                # 文件上传请求，不读取 request.data，避免损坏文件流
                # 只收集表单字段（非文件字段）
                if request.form:
                    params["form_params"] = request.form.to_dict(flat=False)
            elif content_type.startswith('text/') and request.data and len(request.data) < 10240:
                # 只读取文本类型的请求体，且限制大小避免内存问题
                try:
                    params["request_body"] = request.data.decode('utf-8')
                except Exception:
                    pass
            # 其他类型（如 application/octet-stream 等二进制流）直接跳过，不读取
            
            return params
        except Exception as e:
            logger.warning(f"收集Flask请求参数失败: {e}")
            return {}
    
    @staticmethod
    async def _collect_fastapi_request_params(request) -> Dict[str, Any]:
        """
        收集 FastAPI 请求的所有参数
        
        Args:
            request: FastAPI Request 对象
            
        Returns:
            包含 headers, query_params, view_params, request_body, form_params 的字典
        """
        try:
            params = {
                "headers": dict(request.headers),
                "query_params": dict(request.query_params),
                "view_params": dict(request.path_params),
                "request_body": None,
                "form_params": None
            }
            
            # 获取请求体（使用白名单方式，只处理已知安全的内容类型）
            content_type = request.headers.get("content-type", "").lower()
            # 读取请求体（需要特殊处理以避免消耗流）
            body = b""
            if request.method in ["POST", "PUT", "PATCH"]:
                try:
                    body = await request.body()
                except:
                    pass
            params["request_body"] = body.decode('utf-8', errors='ignore')
            
            if "application/json" in content_type:
                try:
                    params["request_body"] = await request.json()
                except Exception:
                    pass
            elif "application/x-www-form-urlencoded" in content_type:
                try:
                    form = await request.form()
                    params["form_params"] = {k: v for k, v in form.items()}
                except Exception:
                    pass
            elif "multipart/form-data" in content_type:
                # 文件上传请求，不读取 body，避免损坏文件流
                params["form_params"] = {"skipped_multipart": True}
            # 其他类型（如 application/octet-stream 等二进制流）直接跳过，不读取
            
            # 添加 ip_address、user_agent 等常用字段到 request_context
            # 提取 IP 地址（优先使用 x-real-ip）
            headers = params['headers']
            ip_address = headers.get('x-real-ip') or headers.get('X-Real-IP') or headers.get('x-forwarded-for') or headers.get('X-Forwarded-For', '')
            if ip_address:
                # x-forwarded-for 可能包含多个 IP，取第一个
                ip_address = ip_address.split(',')[0].strip()
            # 提取 User-Agent
            user_agent = headers.get('user-agent') or headers.get('User-Agent')
            
            add_to_request_context(
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            return params
        except Exception as e:
            logger.warning(f"收集FastAPI请求参数失败: {e}")
            return {}
    
    def _collect_stats(
        self,
        api_path: str,
        api_method: str,
        status_code: int,
        response_time: float,
        token: str,
        error_message: Optional[str] = None,
        request_params: Optional[Dict[str, Any]] = None
    ):
        """收集接口统计"""
        if not self.enable_stats:
            return
        
        try:
            from ..api_stats_collector import get_api_stats_collector
            collector = get_api_stats_collector()
            if collector:
                collector.collect(
                    api_path=api_path,
                    api_method=api_method,
                    status_code=status_code,
                    response_time=response_time,
                    token=token,
                    error_message=error_message,
                    request_params=request_params
                )
        except Exception:
            pass  # 静默失败

    def _should_skip(self, path: str) -> bool:
        """检查是否应该跳过验证"""
        if path in self.exclude_paths:
            return True
        for prefix in self.exclude_prefixes:
            if path.startswith(prefix):
                return True
        return False

    def _is_access_key(self, token: str) -> bool:
        """判断 token 是否为访问密钥"""
        return token and token.startswith("ak_")

    def _verify_access_key_token(self, token: str) -> UserInfo:
        """
        验证访问密钥并返回用户信息（仅 user 级 key 返回 UserInfo）

        Raises:
            AigcAuthError: 验证失败时抛出
        """
        result = self.client.verify_access_key(token)

        if not result.valid:
            raise AigcAuthError(401, "访问密钥无效或已过期")

        if result.key_type == "user":
            return UserInfo(
                id=result.user_id,
                username=result.username or "",
                nickname=result.nickname,
                email=result.email,
                is_admin=result.is_admin,
            )
        elif result.key_type == "app":
            # app 级 key：校验 app_id 与 SDK 配置匹配
            if str(result.app_id) != str(self.client.app_id):
                raise AigcAuthError(403, "访问密钥与应用不匹配")
            # 返回合成 UserInfo，确保下游能获取到认证上下文
            return UserInfo(
                id=0,
                username=f"ak_app_{result.app_id}",
                nickname=f"{result.key_name or '应用密钥'}(App:{result.app_id})",
                is_admin=False,
            )
        elif result.key_type == "global":
            # 全局 key：直接通过，返回合成管理员身份
            return UserInfo(
                id=0,
                username="ak_global",
                nickname=f"{result.key_name or '全局密钥'}(Global)",
                is_admin=True,
            )

        raise AigcAuthError(401, "访问密钥类型无效")

    def _extract_token(self, authorization: str) -> Optional[str]:
        """从 Authorization header 提取 token"""
        token = None
        if not authorization:
            token = None
        elif not authorization.startswith("Bearer "):
            token = None
        else:
            token = authorization[7:]
        # 添加鉴权应用相关的信息
        add_to_request_context(token=token, app_id=self.client.app_id, app_secret=self.client.app_secret)
        return token

    def get_fastapi_middleware_class(self, user_info_callback: Callable = None):
        """
        获取 FastAPI 中间件类（推荐使用，避免请求体读取问题）
        
        使用方法:
            from starlette.middleware.base import BaseHTTPMiddleware
            app.add_middleware(auth_middleware.get_fastapi_middleware_class())
        
        Returns:
            继承于 BaseHTTPMiddleware 的中间件类
        """
        from fastapi.responses import JSONResponse
        from starlette.middleware.base import BaseHTTPMiddleware
        
        auth_middleware_instance = self
        
        class AuthHTTPMiddleware(BaseHTTPMiddleware):
            async def dispatch(self, request, call_next):
                path = request.url.path
                start_time = time.time()
                
                # 收集请求参数
                request_params = await auth_middleware_instance._collect_fastapi_request_params(request) if auth_middleware_instance.enable_stats else None

                # 检查是否跳过
                if auth_middleware_instance._should_skip(path):
                    return await call_next(request)

                # 获取 Authorization header
                authorization = request.headers.get("Authorization")
                token = auth_middleware_instance._extract_token(authorization)

                if not token:
                    logger.warning("AuthMiddleware未提供认证信息")
                    response_time = time.time() - start_time
                    auth_middleware_instance._collect_stats(path, request.method, 401, response_time, "", "未提供认证信息", request_params)
                    return JSONResponse(
                        status_code=401,
                        content={"code": 401, "message": "未提供认证信息", "data": None}
                    )

                # 验证 token / access key
                try:
                    if auth_middleware_instance._is_access_key(token):
                        # Access Key 验证路径
                        user_info = auth_middleware_instance._verify_access_key_token(token)
                        request.state.user_info = user_info
                        if user_info:
                            set_current_user(dataclasses.asdict(user_info))
                            if user_info_callback:
                                await user_info_callback(request, user_info)
                    else:
                        # JWT Token 验证路径
                        user_info = auth_middleware_instance.client.get_user_info(token)
                        # 将用户信息存储到 request.state
                        request.state.user_info = user_info
                        # 设置上下文
                        set_current_user(dataclasses.asdict(user_info))
                        if user_info_callback:
                            await user_info_callback(request, user_info)
                except AigcAuthError as e:
                    logger.error(f"AuthMiddleware认证失败: {e.message}")
                    response_time = time.time() - start_time
                    auth_middleware_instance._collect_stats(path, request.method, 401, response_time, token, e.message, request_params)
                    return JSONResponse(
                        status_code=401,
                        content={"code": e.code, "message": e.message, "data": None}
                    )
                
                # 处理请求
                try:
                    response = await call_next(request)
                    response_time = time.time() - start_time
                    auth_middleware_instance._collect_stats(path, request.method, response.status_code, response_time, token, None, request_params)
                    return response
                except Exception as e:
                    response_time = time.time() - start_time
                    auth_middleware_instance._collect_stats(path, request.method, 500, response_time, token, str(e), request_params)
                    raise
                finally:
                    clear_current_user()
        
        return AuthHTTPMiddleware

    async def fastapi_middleware(self, request, call_next, user_info_callback: Callable = None):
        """
        FastAPI 中间件（旧方法，推荐使用 get_fastapi_middleware_class）

        使用方法:
            @app.middleware("http")
            async def auth(request: Request, call_next):
                return await auth_middleware.fastapi_middleware(request, call_next)
        """
        from fastapi.responses import JSONResponse
        
        # 处理代理头部，确保重定向（如果有）使用正确的协议
        forwarded_proto = request.headers.get("x-forwarded-proto")
        if forwarded_proto:
            request.scope["scheme"] = forwarded_proto

        path = request.url.path
        start_time = time.time()
        
        # 获取 Authorization header
        authorization = request.headers.get("Authorization")
        token = self._extract_token(authorization)

        # 检查是否跳过
        if self._should_skip(path):
            return await call_next(request)

        if not token:
            logger.warning("AuthMiddleware未提供认证信息")
            response_time = time.time() - start_time
            # 收集请求参数
            request_params = await self._collect_fastapi_request_params(request) if self.enable_stats else None
            self._collect_stats(path, request.method, 401, response_time, "", "未提供认证信息", request_params)
            return JSONResponse(
                status_code=401,
                content={"code": 401, "message": "未提供认证信息", "data": None}
            )

        # 验证 token / access key
        try:
            if self._is_access_key(token):
                # Access Key 验证路径
                user_info = self._verify_access_key_token(token)
                request.state.user_info = user_info
                if user_info:
                    set_current_user(dataclasses.asdict(user_info))
                    if user_info_callback:
                        await user_info_callback(request, user_info)
            else:
                # JWT Token 验证路径
                user_info = self.client.get_user_info(token)
                # 将用户信息存储到 request.state
                request.state.user_info = user_info
                # 设置上下文
                set_current_user(dataclasses.asdict(user_info))
                if user_info_callback:
                    await user_info_callback(request, user_info)
        except AigcAuthError as e:
            logger.error(f"AuthMiddleware认证失败: {e.message}")
            response_time = time.time() - start_time
            # 收集请求参数
            request_params = await self._collect_fastapi_request_params(request) if self.enable_stats else None
            self._collect_stats(path, request.method, 401, response_time, token, e.message, request_params)
            return JSONResponse(
                status_code=401,
                content={"code": e.code, "message": e.message, "data": None}
            )
        
        # 处理请求
        try:
            response = await call_next(request)
            response_time = time.time() - start_time
            # 收集请求参数
            request_params = await self._collect_fastapi_request_params(request) if self.enable_stats else None
            self._collect_stats(path, request.method, response.status_code, response_time, token, None, request_params)
            return response
        except Exception as e:
            # 收集请求参数
            request_params = await self._collect_fastapi_request_params(request) if self.enable_stats else None
            response_time = time.time() - start_time
            self._collect_stats(path, request.method, 500, response_time, token, str(e), request_params)
            raise
        finally:
            clear_current_user()

    def flask_before_request(self, user_info_callback: Callable = None):
        """
        Flask before_request 处理器

        使用方法:
            @app.before_request
            def before_request():
                return auth_middleware.flask_before_request(user_info_callback=user_info_callback)
        """
        from flask import request, jsonify, g

        path = request.path
        # 记录开始时间到 g 对象
        g.start_time = time.time()
        
        # 收集请求参数
        g.request_params = self._collect_flask_request_params(request) if self.enable_stats else None
        
        # 获取 Authorization header
        authorization = request.headers.get("Authorization")
        token = self._extract_token(authorization)

        # 检查是否跳过
        if self._should_skip(path):
            return None

        if not token:
            logger.warning("AuthMiddleware未提供认证信息")
            response_time = time.time() - g.start_time
            self._collect_stats(path, request.method, 401, response_time, "", "未提供认证信息", g.request_params)
            return jsonify({
                "code": 401,
                "message": "未提供认证信息",
                "data": None
            }), 401

        # 验证 token / access key
        try:
            if self._is_access_key(token):
                # Access Key 验证路径
                user_info = self._verify_access_key_token(token)
                g.user_info = user_info
                if user_info:
                    set_current_user(dataclasses.asdict(user_info))
                    if user_info_callback:
                        user_info_callback(request, user_info)
            else:
                # JWT Token 验证路径
                user_info = self.client.get_user_info(token)
                # 将用户信息存储到 flask.g
                g.user_info = user_info
                # 设置上下文
                set_current_user(dataclasses.asdict(user_info))
                if user_info_callback:
                    user_info_callback(request, user_info)
        except AigcAuthError as e:
            logger.error(f"AuthMiddleware认证失败: {e.message}")
            response_time = time.time() - g.start_time
            self._collect_stats(path, request.method, 401, response_time, token, e.message, g.request_params)
            return jsonify({
                "code": e.code,
                "message": e.message,
                "data": None
            }), 401

        return None
    
    def flask_after_request(self, response):
        """
        Flask after_request 处理器（用于收集响应统计）

        使用方法:
            @app.after_request
            def after_request(response):
                return auth_middleware.flask_after_request(response)
        """
        from flask import request, g
        
        # 清除上下文
        clear_current_user()
        
        if hasattr(g, 'start_time'):
            response_time = time.time() - g.start_time
            request_params = getattr(g, 'request_params', None)
            # 从 request 的 Authorization header 获取 token
            authorization = request.headers.get("Authorization")
            token = self._extract_token(authorization) or ""
            self._collect_stats(
                request.path,
                request.method,
                response.status_code,
                response_time,
                token,
                None,
                request_params
            )
        
        return response

    def get_current_user_fastapi(self, request) -> Optional[UserInfo]:
        """
        FastAPI 中获取当前用户

        Args:
            request: FastAPI Request 对象

        Returns:
            UserInfo: 用户信息，如果未登录返回 None
        """
        return getattr(request.state, "user_info", None)

    def get_current_user_flask(self) -> Optional[UserInfo]:
        """
        Flask 中获取当前用户

        Returns:
            UserInfo: 用户信息，如果未登录返回 None
        """
        from flask import g
        return getattr(g, "user_info", None)
