"""
AIGC Auth Python SDK - 核心模块

本包由 sdk.py 拆分为以下模块:
- models.py: UserInfo, TokenVerifyResult, AigcAuthError
- client.py: AigcAuthClient
- middleware.py: AuthMiddleware
- decorators.py: require_auth, create_fastapi_auth_dependency
"""

import logging

from .models import UserInfo, TokenVerifyResult, AigcAuthError
from .client import AigcAuthClient
from .middleware import AuthMiddleware
from .decorators import require_auth, create_fastapi_auth_dependency

logger = logging.getLogger(__name__)


def setLogger(log):
    global logger
    logger = log

    try:
        from .client import setLogger as client_setLogger
        client_setLogger(log)
    except Exception as e:
        print(f"Failed to set logger for sdk.client module: {e}")

    try:
        from .middleware import setLogger as middleware_setLogger
        middleware_setLogger(log)
    except Exception as e:
        print(f"Failed to set logger for sdk.middleware module: {e}")

    try:
        from .decorators import setLogger as decorators_setLogger
        decorators_setLogger(log)
    except Exception as e:
        print(f"Failed to set logger for sdk.decorators module: {e}")


__all__ = [
    "UserInfo",
    "TokenVerifyResult",
    "AigcAuthError",
    "AigcAuthClient",
    "AuthMiddleware",
    "require_auth",
    "create_fastapi_auth_dependency",
    "setLogger",
]
