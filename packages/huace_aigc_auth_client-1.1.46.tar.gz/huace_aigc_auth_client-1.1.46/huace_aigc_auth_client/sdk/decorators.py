import logging
from functools import wraps
from typing import Callable, List, Optional

from .client import AigcAuthClient
from .models import AigcAuthError, UserInfo

logger = logging.getLogger(__name__)


def setLogger(log):
    global logger
    logger = log


def require_auth(
    client: AigcAuthClient, permissions: List[str] = None, any_permission: bool = False
):
    """
    FastAPI 路由装饰器，要求用户登录
    如果使用了 middleware，不需要使用该装饰器
    middleware 会自动验证 token，并且注入用户信息到上下文
    参见 middleware.py 和 ../user_context.py

    Args:
        client: AigcAuthClient 实例
        permissions: 需要的权限列表（可选）
        any_permission: 是否只需要任意一个权限，默认需要全部

    使用方法:
        @app.get("/protected")
        @require_auth(client)
        def protected_route(user_info: UserInfo):
            return {"user": user_info.username}

        @app.get("/admin")
        @require_auth(client, permissions=["admin:access"])
        def admin_route(user_info: UserInfo):
            return {"admin": True}
    """

    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 尝试从 FastAPI 获取 request
            request = kwargs.get("request")
            if request is None:
                for arg in args:
                    if hasattr(arg, "headers"):
                        request = arg
                        break

            if request is None:
                raise AigcAuthError(401, "无法获取请求对象")

            authorization = request.headers.get("Authorization")
            user_info = client.get_user_info_from_header(authorization)

            if user_info is None:
                raise AigcAuthError(401, "未登录或 Token 已过期")

            # 检查权限
            if permissions:
                if any_permission:
                    if not user_info.has_any_permission(permissions):
                        raise AigcAuthError(403, "权限不足")
                else:
                    if not user_info.has_all_permissions(permissions):
                        raise AigcAuthError(403, "权限不足")

            # 将用户信息注入到 kwargs
            kwargs["user_info"] = user_info
            return func(*args, **kwargs)

        return wrapper

    return decorator


def create_fastapi_auth_dependency(client: AigcAuthClient):
    """
    创建 FastAPI 认证依赖

    使用方法:
        from fastapi import Depends
        from sdk import AigcAuthClient, create_fastapi_auth_dependency

        client = AigcAuthClient(app_id="xxx", app_secret="xxx")
        get_current_user = create_fastapi_auth_dependency(client)

        @app.get("/me")
        async def get_me(user: UserInfo = Depends(get_current_user)):
            return {"username": user.username}
    """
    from fastapi import HTTPException, Request

    async def get_current_user(request: Request) -> UserInfo:
        authorization = request.headers.get("Authorization")
        user_info = client.get_user_info_from_header(authorization)

        if user_info is None:
            logger.warning("FastAPI依赖未登录或Token已过期")
            raise HTTPException(status_code=401, detail="未登录或 Token 已过期")

        return user_info

    return get_current_user
