from typing import Optional, List
from dataclasses import dataclass


@dataclass
class UserInfo:
    """用户信息"""
    id: int
    username: str
    nickname: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    avatar: Optional[str] = None
    roles: List[str] = None
    permissions: List[str] = None
    department: Optional[str] = None
    company: Optional[str] = None
    is_admin: Optional[bool] = None
    status: Optional[str] = None

    def __post_init__(self):
        if self.roles is None:
            self.roles = []
        if self.permissions is None:
            self.permissions = []

    def has_role(self, role: str) -> bool:
        """检查是否拥有指定角色"""
        return role in self.roles

    def has_permission(self, permission: str) -> bool:
        """检查是否拥有指定权限"""
        return permission in self.permissions

    def has_any_permission(self, permissions: List[str]) -> bool:
        """检查是否拥有任意一个权限"""
        return any(p in self.permissions for p in permissions)

    def has_all_permissions(self, permissions: List[str]) -> bool:
        """检查是否拥有所有权限"""
        return all(p in self.permissions for p in permissions)


@dataclass
class TokenVerifyResult:
    """Token 验证结果"""
    valid: bool
    user_id: Optional[str] = None
    username: Optional[str] = None
    expires_at: Optional[str] = None


@dataclass
class AccessKeyVerifyResult:
    """访问密钥验证结果"""
    valid: bool
    key_type: Optional[str] = None  # "app" / "global" / "user"
    key_id: Optional[int] = None
    key_name: Optional[str] = None
    app_id: Optional[int] = None
    user_id: Optional[int] = None
    username: Optional[str] = None
    nickname: Optional[str] = None
    email: Optional[str] = None
    is_admin: Optional[bool] = None


class AigcAuthError(Exception):
    """AIGC Auth SDK 异常"""
    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")
