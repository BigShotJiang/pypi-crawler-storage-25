import os
import time
import hashlib
import json
import requests
import logging
from typing import Optional, List, Dict, Any, Tuple

from ..user_context import get_trace_id
from .models import UserInfo, TokenVerifyResult, AccessKeyVerifyResult, AigcAuthError

logger = logging.getLogger(__name__)


def setLogger(log):
    global logger
    logger = log


# 尝试加载 .env 文件
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


class AigcAuthClient:
    """
    AIGC Auth 客户端

    使用方法:
        client = AigcAuthClient(
            app_id="your_app_id",
            app_secret="your_app_secret",
            base_url="后端 API 鉴权地址"
        )

        # 验证 token
        result = client.verify_token(token)

        # 获取用户信息
        user = client.get_user_info(token)

        # 检查权限
        results = client.check_permissions(token, ["user:read", "user:write"])
    """

    def __init__(
        self,
        app_id: Optional[str] = None,
        app_secret: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 30,
        cache_ttl: int = 300  # 缓存有效期（秒），默认 5 分钟
    ):
        """
        初始化客户端

        Args:
            app_id: 应用 ID，可从环境变量 AIGC_AUTH_APP_ID 读取
            app_secret: 应用密鑰，可从环境变量 AIGC_AUTH_APP_SECRET 读取
            base_url: API 基础 URL，可从环境变量 AIGC_AUTH_BASE_URL 读取
            timeout: 请求超时时间（秒）
            cache_ttl: 缓存有效期（秒），默认 300 秒（5 分钟）
        """
        self.app_id = app_id or os.getenv("AIGC_AUTH_APP_ID")
        self.app_secret = app_secret or os.getenv("AIGC_AUTH_APP_SECRET")
        self.base_url = (
            base_url or
            os.getenv("AIGC_AUTH_BASE_URL")
        )
        self.timeout = timeout
        self.cache_ttl = cache_ttl
        
        # 缓存存储: {cache_key: (data, timestamp)}
        self._cache: Dict[str, Tuple[Dict, float]] = {}

        if not self.app_id or not self.app_secret:
            raise ValueError(
                "必须提供 app_id 和 app_secret，"
                "可通过参数传入或设置环境变量 AIGC_AUTH_APP_ID 和 AIGC_AUTH_APP_SECRET"
            )

    def _get_headers(self) -> Dict[str, str]:
        """获取请求头"""
        headers = {
            "Content-Type": "application/json",
            "X-App-ID": self.app_id,
            "X-App-Secret": self.app_secret
        }
        trace_id = get_trace_id()
        if trace_id:
            headers["X-Trace-ID"] = trace_id
        return headers

    def _generate_cache_key(self, token: str, url: str, method: str, extra_data: Dict = None) -> str:
        """
        生成缓存键
        
        Args:
            token: 用户 token
            url: 请求 URL
            method: 请求方法
            extra_data: 额外的请求参数（会被排序后拼接到 key 中）
            
        Returns:
            str: 缓存键（使用 hash 以节省内存）
        """
        key_string = f"{token}:{url}:{method}"
        
        # 如果有额外参数，将其排序后拼接到 key 中
        if extra_data:
            # 对参数进行排序并转换为字符串
            sorted_data = json.dumps(extra_data, sort_keys=True, ensure_ascii=False)
            key_string = f"{key_string}:{sorted_data}"
        
        return hashlib.md5(key_string.encode()).hexdigest()

    def _get_from_cache(self, cache_key: str) -> Optional[Dict]:
        """
        从缓存中获取数据
        
        Args:
            cache_key: 缓存键
            
        Returns:
            Optional[Dict]: 缓存的数据，如果缓存不存在或已过期则返回 None
        """
        if cache_key not in self._cache:
            return None
        
        data, timestamp = self._cache[cache_key]
        current_time = time.time()
        
        # 检查缓存是否过期
        if current_time - timestamp > self.cache_ttl:
            # 清理过期缓存
            del self._cache[cache_key]
            return None
        
        return data

    def _set_cache(self, cache_key: str, data: Dict):
        """
        设置缓存
        
        Args:
            cache_key: 缓存键
            data: 要缓存的数据
        """
        self._cache[cache_key] = (data, time.time())
        
        # 简单的缓存清理：如果缓存数量过多，清理所有过期的缓存
        if len(self._cache) > 1000:
            self._clean_expired_cache()

    def _clean_expired_cache(self):
        """清理所有过期的缓存"""
        current_time = time.time()
        expired_keys = [
            key for key, (_, timestamp) in self._cache.items()
            if current_time - timestamp > self.cache_ttl
        ]
        for key in expired_keys:
            del self._cache[key]

    def clear_cache(self):
        """清空所有缓存"""
        self._cache.clear()

    def _request(self, method: str, endpoint: str, data: Dict = None, token: str = None, headers: Dict[str, str] = None) -> Dict:
        """
        发送请求
        
        Args:
            method: 请求方法
            endpoint: 端点路径
            data: 请求数据
            token: 用户 token（用于缓存键）
            headers: 自定义请求头（会与默认 headers 合并，自定义的优先）
            
        Returns:
            Dict: 响应数据
        """
        url = f"{self.base_url}/sdk{endpoint}"
        
        # 如果提供了 token，尝试从缓存中获取
        if token:
            # 从 data 中提取 token 之外的参数作为额外的缓存键信息
            extra_data = None
            if data:
                extra_data = {k: v for k, v in data.items() if k != "token"}
            
            cache_key = self._generate_cache_key(token, url, method, extra_data)
            cached_data = self._get_from_cache(cache_key)
            if cached_data is not None:
                return cached_data
        
        try:
            # 合并 headers：默认 headers + 自定义 headers（自定义的优先）
            request_headers = self._get_headers()
            if headers:
                request_headers.update(headers)
            
            response = requests.request(
                method=method,
                url=url,
                json=data,
                headers=request_headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            result = response.json()

            if result.get("code") != 0:
                logger.error(f"AigcAuthClient 请求错误: {result}")
                raise AigcAuthError(
                    result.get("code", -1),
                    result.get("message", "未知错误")
                )

            response_data = result.get("data", {})
            
            # 如果请求成功且提供了 token，缓存响应数据
            if token:
                self._set_cache(cache_key, response_data)
            
            return response_data

        except requests.exceptions.RequestException as e:
            logger.error(f"AigcAuthClient 请求失败: {str(e)}")
            raise AigcAuthError(-1, f"请求失败: {str(e)}")

    def verify_token(self, token: str) -> TokenVerifyResult:
        """
        验证 Token

        Args:
            token: 用户的 access_token

        Returns:
            TokenVerifyResult: 验证结果
        """
        data = self._request("POST", "/token/verify", {"token": token}, token=token)
        return TokenVerifyResult(
            valid=data.get("valid", False),
            user_id=data.get("userId"),
            username=data.get("username"),
            expires_at=data.get("expiresAt")
        )

    def get_user_info(self, token: str) -> UserInfo:
        """
        获取用户信息

        Args:
            token: 用户的 access_token

        Returns:
            UserInfo: 用户信息

        Raises:
            AigcAuthError: 当 token 无效或用户不存在时
        """
        data = self._request("POST", "/user/info", {"token": token}, token=token)
        return UserInfo(
            id=data.get("id"),
            username=data.get("username"),
            nickname=data.get("nickname"),
            email=data.get("email"),
            phone=data.get("phone"),
            avatar=data.get("avatar"),
            roles=data.get("roles", []),
            permissions=data.get("permissions", []),
            department=data.get("department"),
            company=data.get("company"),
            is_admin=data.get("is_admin"),
            status=data.get("status")
        )

    def check_permissions(
        self,
        token: str,
        permission_codes: List[str]
    ) -> Dict[str, bool]:
        """
        批量检查权限

        Args:
            token: 用户的 access_token
            permission_codes: 权限代码列表

        Returns:
            Dict[str, bool]: 权限检查结果，key 为权限代码，value 为是否拥有
        """
        data = self._request("POST", "/permission/check", {
            "token": token,
            "permissionCodes": permission_codes
        }, token=token)
        return data.get("results", {})

    def verify_access_key(self, access_key: str) -> AccessKeyVerifyResult:
        """
        验证访问密钥

        Args:
            access_key: 访问密钥 (ak_...)

        Returns:
            AccessKeyVerifyResult: 验证结果
        """
        data = self._request("POST", "/access-key/verify", {"accessKey": access_key})
        return AccessKeyVerifyResult(
            valid=data.get("valid", False),
            key_type=data.get("keyType"),
            key_id=data.get("keyId"),
            key_name=data.get("keyName"),
            app_id=data.get("appId"),
            user_id=data.get("userId"),
            username=data.get("username"),
            nickname=data.get("nickname"),
            email=data.get("email"),
            is_admin=data.get("isAdmin"),
        )

    def get_user_info_from_header(self, authorization: str) -> Optional[UserInfo]:
        """
        从 Authorization header 获取用户信息

        Args:
            authorization: Authorization header 的値，格式为 "Bearer {token}"

        Returns:
            UserInfo: 用户信息，如果验证失败返回 None
        """
        if not authorization:
            return None

        if not authorization.startswith("Bearer "):
            return None

        token = authorization[7:]  # 移除 "Bearer " 前缀

        try:
            return self.get_user_info(token)
        except AigcAuthError:
            return None

    # ============ 批量用户查询 ============

    def batch_get_users(self, usernames: List[str]) -> Dict[str, Any]:
        """
        批量获取用户信息

        通过用户名列表查询用户，返回属于当前应用或全局用户的信息。

        Args:
            usernames: 用户名列表（最多 100 个）

        Returns:
            Dict: 查询结果
                - users: List[Dict] 用户信息列表
                - not_found: List[str] 未找到的用户名列表
        """
        return self._request("POST", "/users/batch", {"usernames": usernames})

    def batch_get_users_by_ids(self, user_ids: List[int]) -> Dict[str, Any]:
        """
        通过用户ID批量获取用户信息

        返回属于当前应用或全局用户的信息，未找到的返回"未知用户"占位。

        Args:
            user_ids: 用户ID列表（最多 100 个）

        Returns:
            Dict: 查询结果
                - users: List[Dict] 用户信息列表（按请求顺序，未找到的为占位数据）
        """
        return self._request("POST", "/users/batch-by-ids", {"userIds": user_ids})

    # ============ 用户同步相关方法 ============

    def sync_user_to_auth(self, user_data: Dict[str, Any], headers: Dict[str, str] = None) -> Dict[str, Any]:
        """
        同步用户到 aigc-auth（用于旧系统初始化同步）

        Args:
            user_data: 用户数据，必须包含 username，以及 password 或 password_hashed 二选一
                - password: 明文密码
                - password_hashed: 已加密的密码哈希（bcrypt 格式）
            headers: 自定义请求头（可选）

        Returns:
            Dict: 同步结果
                - success: bool 是否成功
                - created: bool 是否新建（False 表示已存在）
                - user_id: int 用户ID
                - message: str 消息
        """
        return self._request("POST", "/sync/user", user_data, headers=headers)

    def batch_sync_users_to_auth(self, users: List[Dict[str, Any]], headers: Dict[str, str] = None) -> Dict[str, Any]:
        """
        批量同步用户到 aigc-auth

        Args:
            users: 用户数据列表，每个用户必须包含 username，以及 password 或 password_hashed 二选一
            headers: 自定义请求头（可选）

        Returns:
            Dict: 批量同步结果
                - total: int 总数
                - success: int 成功数
                - failed: int 失败数
                - skipped: int 跳过数（已存在）
                - errors: List[Dict] 错误详情
        """
        return self._request("POST", "/sync/batch", {"users": users}, headers=headers)

    def register_webhook(self, webhook_url: str, events: List[str], secret: Optional[str] = None) -> Dict[str, Any]:
        """
        注册 webhook 接收增量用户

        Args:
            webhook_url: webhook 接收地址
            events: 订阅的事件列表，如 ["user.created", "user.updated"]
            secret: webhook 签名密鑰

        Returns:
            Dict: 注册结果
                - webhook_id: str webhook ID
                - success: bool 是否成功
        """
        return self._request("POST", "/webhook/register", {
            "url": webhook_url,
            "events": events,
            "secret": secret
        })

    def unregister_webhook(self, webhook_id: str) -> Dict[str, Any]:
        """
        注销 webhook

        Args:
            webhook_id: webhook ID

        Returns:
            Dict: 注销结果
        """
        return self._request("POST", "/webhook/unregister", {"webhookId": webhook_id})
