import unittest

from src.aiel_sdk.core.types import Message
from src.aiel_sdk.integrations.openai.core_adapter import (
    OpenAIChatModelAdapter,
    OpenAIEmbeddingModelAdapter,
)
from src.aiel_sdk.integrations.openai.facade import ChatOpenAI, OpenAIEmbeddings


class _FakeIntegrationsService:
    def invoke_action(self, workspace_id, project_id, connection_id, action, payload=None, request_id=None):
        if action == "openai.chat.completions.create":
            return {
                "choices": [
                    {
                        "message": {"role": "assistant", "content": "hello"},
                        "finish_reason": "stop",
                    }
                ]
            }
        if action == "openai.embeddings.create":
            return {"data": [{"embedding": [0.1, 0.2]}]}
        return {}


class _FakeClient:
    def __init__(self):
        self.integrations = _FakeIntegrationsService()


class OpenAICoreAdapterTests(unittest.TestCase):
    def test_chat_adapter_returns_chat_response(self):
        client = _FakeClient()
        chat = ChatOpenAI(
            client=client,
            workspace_id="w1",
            project_id="p1",
            connection_id="c1",
            model="gpt-4.1",
        )
        adapter = OpenAIChatModelAdapter(inner=chat)
        out = adapter.invoke([Message(role="user", content="hello")])
        self.assertEqual(out.message.role, "assistant")
        self.assertEqual(out.message.content, "hello")

    def test_embedding_adapter_invoke_contract(self):
        client = _FakeClient()
        emb = OpenAIEmbeddings(
            client=client,
            workspace_id="w1",
            project_id="p1",
            connection_id="c1",
            model="text-embedding-3-small",
        )
        adapter = OpenAIEmbeddingModelAdapter(inner=emb)
        out = adapter.invoke("hello")
        self.assertEqual(out.vectors, [[0.1, 0.2]])


if __name__ == "__main__":
    unittest.main(verbosity=2)
