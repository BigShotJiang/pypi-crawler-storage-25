import unittest

from src.aiel_sdk.adapters.langchain.langgraph import make_messages_node
from src.aiel_sdk.core.types import ChatResponse, Message


class _Model:
    def invoke(self, messages, **kwargs):
        _ = kwargs
        return ChatResponse(message=Message(role="assistant", content="ok"))


class LangGraphAdapterTests(unittest.TestCase):
    def test_messages_node_appends_history(self):
        node = make_messages_node(_Model())
        state = {"messages": [Message(role="user", content="hello")]}
        out = node(state)
        self.assertEqual(len(out["messages"]), 2)
        self.assertEqual(out["messages"][0].role, "user")
        self.assertEqual(out["messages"][1].role, "assistant")


if __name__ == "__main__":
    unittest.main(verbosity=2)
