from ._version import SDK_VERSION
from .context import Context
from .registry import get_registry, reset_registry
from .decorators import tool, agent, router, flow, flow_graph
from .http import http
from .mcp import mcp_server
from .validate import validate_contracts
from .client import AielClient
from .errors import AielError, ApiError, ContractViolation, RuntimeDependencyError

from aiel_integrations import IntegrationsClient # legacy


__all__ = [
    "SDK_VERSION",
    "Context",
    "get_registry", "reset_registry",
    "tool", "agent", "router", "flow", "flow_graph",
    "http", "mcp_server",
    "validate_contracts",
    "IntegrationsClient",  # legacy
    "AielClient",          # new
    "AielError",
    "ApiError",
    "ContractViolation",
    "RuntimeDependencyError",
]
