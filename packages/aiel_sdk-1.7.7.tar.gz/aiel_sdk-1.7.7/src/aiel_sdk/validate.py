from __future__ import annotations
from .registry import get_registry
from .signature import validate_min_positional_args

def validate_contracts() -> None:
    reg = get_registry()
    for name, exp in reg.tools.items():
        validate_min_positional_args(f"tool:{name}", exp.fn, min_args=2, expected_shape="ctx, input")
    for name, exp in reg.agents.items():
        validate_min_positional_args(f"agent:{name}", exp.fn, min_args=2, expected_shape="ctx, state/payload")
    for name, exp in reg.routers.items():
        validate_min_positional_args(f"router:{name}", exp.fn, min_args=2, expected_shape="ctx, state")
    for name, exp in reg.flows.items():
        if exp.fn is not None:
            validate_min_positional_args(f"flow:{name}", exp.fn, min_args=2, expected_shape="ctx, state/payload")
