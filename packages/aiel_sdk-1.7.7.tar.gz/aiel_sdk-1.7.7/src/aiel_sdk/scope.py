from __future__ import annotations

from typing import Tuple

from .client import AielClient


def ensure_non_empty(value: str | None, name: str) -> str:
    v = (value or "").strip()
    if not v:
        raise ValueError(f"{name} must be non-empty")
    return v


def resolve_workspace_project(
    client: AielClient,
    *,
    workspace_id: str | None = None,
    project_id: str | None = None,
) -> Tuple[str, str]:
    c_ws: str | None = None
    c_proj: str | None = None
    if hasattr(client, "resolve_scope"):
        c_ws, c_proj = client.resolve_scope()

    ws = ensure_non_empty(workspace_id or c_ws, "workspace_id")
    proj = ensure_non_empty(project_id or c_proj, "project_id")
    return ws, proj
