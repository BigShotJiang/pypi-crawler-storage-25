from __future__ import annotations

from abc import ABC, abstractmethod

from .types import (
    DEFAULT_POSTGRES_CAPABILITIES,
    PostgresCapabilities,
    PostgresInsertRequest,
    PostgresInsertResult,
    PostgresQueryRequest,
    PostgresQueryResult,
)


class PostgresClient(ABC):
    """Framework-agnostic Postgres client for Integrations actions."""

    @property
    def capabilities(self) -> PostgresCapabilities:
        return DEFAULT_POSTGRES_CAPABILITIES

    @abstractmethod
    def query(self, *, req: PostgresQueryRequest) -> PostgresQueryResult:
        raise NotImplementedError

    @abstractmethod
    def insert(self, *, req: PostgresInsertRequest) -> PostgresInsertResult:
        raise NotImplementedError
