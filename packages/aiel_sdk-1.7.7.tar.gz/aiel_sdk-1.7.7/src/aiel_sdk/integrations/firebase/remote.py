"""
aiel_sdk.integrations.firebase.remote
=====================================

Remote-backed Firebase operations via the AIEL Integrations API.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from ...client import AielClient
from ...scope import ensure_non_empty, resolve_workspace_project
from .types import (
    DEFAULT_FIREBASE_CAPABILITIES,
    FirebaseCapabilities,
    FirebaseDeleteResult,
    FirebaseDocDeleteRequest,
    FirebaseDocGetRequest,
    FirebaseDocPutRequest,
    FirebaseDocQueryRequest,
    FirebaseDocQueryResult,
    FirebaseDocResult,
    FirebasePingResult,
)

Json = Dict[str, Any]


class RemoteFirebase:
    @property
    def capabilities(self) -> FirebaseCapabilities:
        return DEFAULT_FIREBASE_CAPABILITIES

    def __init__(
        self,
        client: AielClient,
        *,
        workspace_id: str | None = None,
        project_id: str | None = None,
        connection_id: str,
    ) -> None:
        self._c = client
        self._ws, self._proj = resolve_workspace_project(
            client,
            workspace_id=workspace_id,
            project_id=project_id,
        )
        self._conn = ensure_non_empty(connection_id, "connection_id")

    def _invoke(
        self,
        *,
        action: str,
        params: Optional[Json] = None,
        request_id: str | None = None,
    ) -> Any:
        return self._c.integrations.invoke_action(
            self._ws,
            self._proj,
            connection_id=self._conn,
            action=action,
            payload={"params": params or {}},
            request_id=request_id,
        )

    def doc_get(self, req: FirebaseDocGetRequest, *, request_id: str | None = None) -> FirebaseDocResult:
        raw = self._invoke(action="firebase.doc.get", params=req.to_params(), request_id=request_id)
        return FirebaseDocResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def doc_put(self, req: FirebaseDocPutRequest, *, request_id: str | None = None) -> FirebaseDocResult:
        raw = self._invoke(action="firebase.doc.put", params=req.to_params(), request_id=request_id)
        return FirebaseDocResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def doc_delete(
        self,
        req: FirebaseDocDeleteRequest,
        *,
        request_id: str | None = None,
    ) -> FirebaseDeleteResult:
        raw = self._invoke(action="firebase.doc.delete", params=req.to_params(), request_id=request_id)
        return FirebaseDeleteResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def doc_query(
        self,
        req: FirebaseDocQueryRequest,
        *,
        request_id: str | None = None,
    ) -> FirebaseDocQueryResult:
        raw = self._invoke(action="firebase.doc.query", params=req.to_params(), request_id=request_id)
        return FirebaseDocQueryResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def ping(self, *, request_id: str | None = None) -> FirebasePingResult:
        raw = self._invoke(action="firebase.ping", params={}, request_id=request_id)
        return FirebasePingResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})
