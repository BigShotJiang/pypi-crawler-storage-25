# Customer Support Copilot (Real-world Example)

This example shows how to run a production-style support workflow that:
- triages a customer billing request
- researches account and dispute context in Postgres
- decides the best next action
- executes and logs that action
- generates a customer-ready response

## Product outcome
Use this flow when you want faster, more consistent billing support decisions with clear audit trails.

## What users get
- Faster response time for common billing issues
- Consistent decisions based on account and risk context
- Clear rationale attached to every action
- Persistent memory across requests (short-term checkpoints + long-term preferences)

## How the flow works
1. Triage customer request
2. If billing-related, pull account/invoice/dispute context from Postgres
3. Score risk and select resolution path
4. Persist action to `support_case_actions`
5. Return a customer-facing response

## Architecture highlights
- Runtime-native handler (`aiel_handler`) and HTTP endpoints
- LangGraph orchestration with conditional routing
- Memory enabled via `checkpointer` and `store`
- Strict runtime context from `UserContext().load()`
- Resource selection by UUID in payload:
  - `openai_resource_id`
  - `postgres_resource_id`

## Entry point
- `main.py` in this folder

## Suggested database tables
- `customer_accounts(account_id, plan_name, mrr, status, renewal_date)`
- `invoices(invoice_id, account_id, due_date, amount, status)`
- `payment_disputes(dispute_id, account_id, created_at, amount, reason, status)`
- `support_case_actions(id, case_id, account_id, user_id, action, risk_level, reasoning, created_at)`
