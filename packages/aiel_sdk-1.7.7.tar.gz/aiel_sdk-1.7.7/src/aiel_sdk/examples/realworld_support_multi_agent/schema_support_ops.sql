-- Schema for realworld_support_multi_agent example
-- Database: support_ops

CREATE TABLE IF NOT EXISTS customer_accounts (
  account_id TEXT PRIMARY KEY,
  plan_name TEXT NOT NULL,
  mrr NUMERIC(12,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  renewal_date DATE
);

CREATE TABLE IF NOT EXISTS invoices (
  invoice_id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES customer_accounts(account_id) ON DELETE CASCADE,
  due_date DATE NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS payment_disputes (
  dispute_id BIGSERIAL PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES customer_accounts(account_id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  amount NUMERIC(12,2) NOT NULL,
  reason TEXT,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS support_case_actions (
  id BIGSERIAL PRIMARY KEY,
  case_id TEXT NOT NULL,
  account_id TEXT NOT NULL REFERENCES customer_accounts(account_id) ON DELETE RESTRICT,
  user_id TEXT NOT NULL,
  action TEXT NOT NULL,
  risk_level TEXT NOT NULL,
  reasoning TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_invoices_account_due ON invoices (account_id, due_date DESC);
CREATE INDEX IF NOT EXISTS idx_disputes_account_created ON payment_disputes (account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_case_actions_case_id ON support_case_actions (case_id);

