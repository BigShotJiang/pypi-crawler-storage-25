from __future__ import annotations
import inspect
from typing import Any, Callable

from .registry import get_registry
from .exports import ToolExport, AgentExport, RouterExport, FlowExport, HttpHandlerExport
from .signature import validate_min_positional_args

def _meta(fn: Callable[..., Any]) -> tuple[str, str, bool]:
    return fn.__module__, fn.__qualname__, inspect.iscoroutinefunction(fn)

def tool(name: str):
    def decorator(fn: Callable[..., Any]):
        reg = get_registry()
        module, qualname, is_async = _meta(fn)
        reg.tools[name] = ToolExport(name=name, fn=fn, module=module, qualname=qualname, is_async=is_async)
        return fn
    return decorator

def agent(name: str):
    def decorator(fn: Callable[..., Any]):
        reg = get_registry()
        module, qualname, is_async = _meta(fn)
        definition = AgentExport(name=name, fn=fn, module=module, qualname=qualname, is_async=is_async)
        reg.agents[name] = definition
        setattr(fn, "__aiel_agent_definition__", definition)
        return fn
    return decorator

def router(
    name: str,
    *,
    description: str | None = None,
    version: str = "1.0",
    tags: tuple[str, ...] = (),
):
    def decorator(fn: Callable[..., Any]):
        validate_min_positional_args(f"router:{name}", fn, min_args=2, expected_shape="ctx, state")
        reg = get_registry()
        module, qualname, is_async = _meta(fn)
        definition = RouterExport(
            name=name,
            fn=fn,
            module=module,
            qualname=qualname,
            is_async=is_async,
            description=description,
            version=version,
            tags=tags,
        )
        reg.routers[name] = definition
        setattr(fn, "__aiel_router_definition__", definition)
        return fn
    return decorator

def flow(name: str):
    def decorator(fn: Callable[..., Any]):
        reg = get_registry()
        module, qualname, _ = _meta(fn)
        reg.flows[name] = FlowExport(name=name, fn=fn, graph_builder=None, module=module, qualname=qualname)
        return fn
    return decorator

def flow_graph(name: str, builder: Callable[..., Any]):
    reg = get_registry()
    module, qualname, _ = _meta(builder)
    reg.flows[name] = FlowExport(name=name, fn=None, graph_builder=builder, module=module, qualname=qualname)
    return builder

def http_get(path: str):
    def decorator(fn: Callable[..., Any]):
        reg = get_registry()
        module, qualname, is_async = _meta(fn)
        reg.http_handlers.append(HttpHandlerExport("GET", path, fn, module, qualname, is_async))
        return fn
    return decorator

def http_post(path: str):
    def decorator(fn: Callable[..., Any]):
        reg = get_registry()
        module, qualname, is_async = _meta(fn)
        reg.http_handlers.append(HttpHandlerExport("POST", path, fn, module, qualname, is_async))
        return fn
    return decorator
