from __future__ import annotations

from typing import List

from aiel_sdk.errors import RuntimeDependencyError

try:
    from langchain_core.embeddings import Embeddings
except Exception as e:  # pragma: no cover
    raise RuntimeDependencyError("langchain-core", "pip install 'aiel-sdk[langchain]'") from e

from ...core.protocols import EmbeddingModel


class AIELLangChainEmbeddings(Embeddings):
    def __init__(self, inner: EmbeddingModel) -> None:
        self.inner = inner

    def embed_query(self, text: str) -> List[float]:
        return self.inner.embed_query(text)

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return self.inner.embed_documents(texts)
