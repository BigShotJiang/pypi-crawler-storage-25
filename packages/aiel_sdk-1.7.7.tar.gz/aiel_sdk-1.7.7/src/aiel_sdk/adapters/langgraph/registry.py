from __future__ import annotations

import inspect
from typing import Any, Callable, Union

from ...registry import get_registry
from ...signature import positional_param_count

Target = Union[str, Callable[..., Any]]


def _definition_from_agent(target: Target) -> tuple[Callable[..., Any], bool]:
    if isinstance(target, str):
        reg = get_registry()
        definition = reg.agents.get(target)
        if definition is None:
            raise KeyError(f"Unknown agent: {target}")
        return definition.fn, definition.is_async
    if callable(target):
        return target, inspect.iscoroutinefunction(target)
    raise TypeError(f"Unsupported agent target: {type(target)!r}")


def _definition_from_router(target: Target) -> tuple[Callable[..., Any], bool]:
    if isinstance(target, str):
        reg = get_registry()
        definition = reg.routers.get(target)
        if definition is None:
            raise KeyError(f"Unknown router: {target}")
        return definition.fn, definition.is_async
    if callable(target):
        return target, inspect.iscoroutinefunction(target)
    raise TypeError(f"Unsupported router target: {type(target)!r}")


async def _invoke_with_ctx_state_runtime(fn: Callable[..., Any], is_async: bool, state: Any, runtime: Any) -> Any:
    ctx = getattr(runtime, "context", None)
    positional, has_var_positional = positional_param_count(fn)

    if has_var_positional or positional >= 3:
        if is_async:
            return await fn(ctx, state, runtime)
        return fn(ctx, state, runtime)

    if is_async:
        return await fn(ctx, state)
    return fn(ctx, state)


def to_langgraph_node(agent: Target) -> Callable[..., Any]:
    fn, is_async = _definition_from_agent(agent)

    async def node(state: Any, runtime: Any) -> Any:
        return await _invoke_with_ctx_state_runtime(fn, is_async, state, runtime)

    return node


def to_langgraph_router(router_target: Target) -> Callable[..., Any]:
    fn, is_async = _definition_from_router(router_target)

    async def router(state: Any, runtime: Any) -> Any:
        return await _invoke_with_ctx_state_runtime(fn, is_async, state, runtime)

    return router
