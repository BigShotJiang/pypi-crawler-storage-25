"""
Ray 分布式业务日志组件。

特性:
- 9 列竖线分隔的人眼友好格式(时间 | 级别 | pipeline_id | pipeline_instance_id |
  node_id | node_task_id | key | 文件:行号 | 内容)。
- 区分 Ray header / worker 节点: header 写 header.log, worker 按 key 拆分文件。
- 本地目录隔离: ${LOG_BASE_DIR}/${PIPELINE_INSTANCE_ID}_${NODE_TASK_ID}/。
- flush(key=...) 上传 OSS 并删除本地文件; 上传失败也删除(带指数退避重试)。

向后兼容: 保留 setup_logging / get_service_logger / set_service_context /
get_log_file_path / logger 等旧 API。
"""

from __future__ import annotations

import logging
import os
import re
import sys
import threading
import time
from dataclasses import dataclass, replace
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_LOG_BASE_DIR = "/tmp/logs"
DEFAULT_LOG_OSS_PATH_PREFIX = "data-process-platform/task-logs/logs"
DEFAULT_RESULT_OSS_BUCKET = "infra-hads-artifacts"

HEADER_FILE_NAME = "header.log"
WORKER_DEFAULT_FILE_NAME = "worker_default.log"
_WORKER_DEFAULT_KEY_SENTINEL = "__worker_default__"

MAX_FILENAME_LEN = 128
MISSING = "-"
UNKNOWN = "unknown"

LINE_COLUMN_COUNT = 9
LINE_SEP = " | "

_UNSAFE_FS_CHARS_RE = re.compile(r'[\x00-\x1f\x7f\/\\\:\*\?"<>\|]')


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def sanitize_key(key: Any) -> str:
    """清洗 key 作为文件名安全部分。"""
    if key is None:
        return "unnamed"
    s = str(key)
    s = _UNSAFE_FS_CHARS_RE.sub("_", s)
    s = s.strip().strip(".").strip()
    if len(s) > MAX_FILENAME_LEN:
        s = s[:MAX_FILENAME_LEN]
    if not s:
        return "unnamed"
    return s


def _escape_for_line(s: Any) -> str:
    """转义字段值为单行安全字符串(不含 '|' 与换行)。"""
    if s is None:
        return MISSING
    text = str(s)
    if text == "":
        return MISSING
    text = text.replace("|", "｜")
    text = text.replace("\r", "\\r").replace("\n", "\\n")
    text = text.replace("\x0b", "\\v").replace("\x0c", "\\f")
    text = text.replace("\x1c", "\\x1c").replace("\x1d", "\\x1d").replace("\x1e", "\\x1e")
    text = text.replace("\x85", "\\x85")
    text = text.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    return text


def _now_ms_str() -> str:
    now = datetime.now()
    return now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"


# ---------------------------------------------------------------------------
# LogContext
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LogContext:
    pipeline_id: str = MISSING
    pipeline_instance_id: str = MISSING
    node_id: str = MISSING
    node_task_id: str = MISSING

    @classmethod
    def from_env(cls, overrides: Optional[Dict[str, Any]] = None) -> "LogContext":
        def _pick(env_key: str) -> str:
            val = os.environ.get(env_key)
            if val is None or str(val).strip() == "":
                return MISSING
            return str(val)

        ctx = cls(
            pipeline_id=_pick("DATA_TRACK_PIPELINE_ID"),
            pipeline_instance_id=_pick("DATA_TRACK_PIPELINE_INSTANCE_ID"),
            node_id=_pick("DATA_TRACK_NODE_ID"),
            node_task_id=_pick("DATA_TRACK_NODE_TASK_ID"),
        )
        if overrides:
            allowed = {"pipeline_id", "pipeline_instance_id", "node_id", "node_task_id"}
            clean = {}
            for k, v in overrides.items():
                if k not in allowed:
                    continue
                if v is None or str(v).strip() == "":
                    clean[k] = MISSING
                else:
                    clean[k] = str(v)
            if clean:
                ctx = replace(ctx, **clean)
        return ctx

    def dir_segment(self) -> str:
        pi = self.pipeline_instance_id if self.pipeline_instance_id != MISSING else UNKNOWN
        nt = self.node_task_id if self.node_task_id != MISSING else UNKNOWN
        # 目录名本身也需要 sanitize(pi/nt 理论上是 id, 但保险起见)
        return f"{sanitize_key(pi)}_{sanitize_key(nt)}"

    def oss_path_segments(self) -> Tuple[str, str, str]:
        pid = self.pipeline_id if self.pipeline_id != MISSING else UNKNOWN
        pi = self.pipeline_instance_id if self.pipeline_instance_id != MISSING else UNKNOWN
        nt = self.node_task_id if self.node_task_id != MISSING else UNKNOWN
        return pid, pi, nt


# ---------------------------------------------------------------------------
# LineFormatter
# ---------------------------------------------------------------------------


class LineFormatter:
    """固定 9 列的竖线分隔格式化器(P6)。"""

    def format(
        self,
        ts: Optional[datetime],
        level: str,
        ctx: LogContext,
        key: Optional[str],
        caller_file: Optional[str],
        caller_line: Optional[int],
        message: Any,
    ) -> str:
        if ts is None:
            ts_str = _now_ms_str()
        else:
            ts_str = ts.strftime("%Y-%m-%d %H:%M:%S.") + f"{ts.microsecond // 1000:03d}"
        level_str = _escape_for_line(level or "INFO")
        pid = _escape_for_line(ctx.pipeline_id)
        pi = _escape_for_line(ctx.pipeline_instance_id)
        nid = _escape_for_line(ctx.node_id)
        nt = _escape_for_line(ctx.node_task_id)
        key_str = _escape_for_line(key) if key not in (None, "") else MISSING
        if caller_file:
            line_no = caller_line if caller_line is not None else MISSING
            file_line = _escape_for_line(f"{caller_file}:{line_no}")
        else:
            file_line = MISSING
        msg_str = _escape_for_line(message)
        cols = [ts_str, level_str, pid, pi, nid, nt, key_str, file_line, msg_str]
        return LINE_SEP.join(cols)


# ---------------------------------------------------------------------------
# FileSink
# ---------------------------------------------------------------------------


class FileSink:
    """单文件日志写入器(线程安全)。"""

    def __init__(self, key: Optional[str], file_path: str):
        self.key = key
        self.file_path = file_path
        self._lock = threading.Lock()
        self._fh = None  # lazy open

    def _ensure_open(self) -> None:
        if self._fh is None:
            # line buffering (buffering=1), POSIX append 语义可保证单行原子
            self._fh = open(self.file_path, "a", encoding="utf-8", buffering=1)

    def write_line(self, line: str) -> None:
        with self._lock:
            try:
                self._ensure_open()
                self._fh.write(line + "\n")
            except OSError as e:  # 本地写失败不影响业务
                print(
                    f"[logger WARN] write failed for {self.file_path}: {e}",
                    file=sys.stderr,
                )

    def close(self) -> None:
        with self._lock:
            if self._fh is not None:
                try:
                    self._fh.flush()
                    self._fh.close()
                except OSError:
                    pass
                finally:
                    self._fh = None


# ---------------------------------------------------------------------------
# LogRouter
# ---------------------------------------------------------------------------


class LogRouter:
    """按 file_key 管理 FileSink 的线程安全路由表。"""

    def __init__(self):
        self._map: Dict[Optional[str], FileSink] = {}
        self._lock = threading.Lock()

    def get_or_create(
        self,
        file_key: Optional[str],
        base_dir: str,
        filename: str,
        original_key: Optional[str] = None,
    ) -> FileSink:
        with self._lock:
            sink = self._map.get(file_key)
            if sink is not None:
                return sink
            # 确保目录存在
            try:
                os.makedirs(base_dir, exist_ok=True)
            except OSError as e:
                # 目录创建失败, 用 /dev/null 等价的 NullSink 代替?
                # 简化: 仍尝试创建 FileSink, write 时报错被捕获
                print(
                    f"[logger WARN] mkdir failed for {base_dir}: {e}",
                    file=sys.stderr,
                )
            file_path = os.path.join(base_dir, filename)
            sink = FileSink(key=original_key, file_path=file_path)
            self._map[file_key] = sink
            return sink

    def pop(self, file_key: Optional[str]) -> Optional[FileSink]:
        with self._lock:
            return self._map.pop(file_key, None)

    def drain(self) -> List[Tuple[Optional[str], FileSink]]:
        with self._lock:
            items = list(self._map.items())
            self._map.clear()
            return items

    def is_empty(self) -> bool:
        with self._lock:
            return not self._map


# ---------------------------------------------------------------------------
# OSSUploader (with retry)
# ---------------------------------------------------------------------------


class OSSUploader:
    """日志上传器: 封装 alibabacloud_oss_v2 上传 + 指数退避重试。"""

    def __init__(self):
        self._enabled: bool = False
        self._client = None
        self._bucket_name: Optional[str] = None
        self._warned: bool = False
        self._init_client()

    def _init_client(self) -> None:
        """延迟初始化 OSS V2 客户端。凭证缺失或 SDK 未安装时静默禁用。"""
        ak = os.environ.get("OSS_ACCESS_KEY_ID_FOR_LOG")
        sk = os.environ.get("OSS_ACCESS_KEY_SECRET_FOR_LOG")
        endpoint = os.environ.get("OSS_ENDPOINT_FOR_LOG")
        bucket_name = (
            os.environ.get("RESULT_OSS_BUCKET", "").strip()
            or os.environ.get("OSS_BUCKET_NAME_FOR_LOG")
            or DEFAULT_RESULT_OSS_BUCKET
        )
        # 从 endpoint 推断 region (如 https://oss-cn-shanghai.aliyuncs.com -> cn-shanghai)
        # 注意: 内网 endpoint 如 oss-cn-shanghai-internal.aliyuncs.com 需要去掉 -internal
        region = os.environ.get("OSS_REGION_FOR_LOG", "")
        if not region and endpoint:
            import re as _re
            m = _re.search(r"oss-([a-z0-9-]+)\.", endpoint)
            if m:
                region = m.group(1)
                # 去掉 -internal 后缀（内网 endpoint 标识，不是 region 的一部分）
                region = _re.sub(r"-internal$", "", region)

        if not all([ak, sk]):
            self._enabled = False
            if not self._warned:
                print(
                    "[logger WARN] OSS credentials incomplete "
                    "(OSS_ACCESS_KEY_ID_FOR_LOG / OSS_ACCESS_KEY_SECRET_FOR_LOG), "
                    "log upload disabled.",
                    file=sys.stderr,
                )
                self._warned = True
            return

        try:
            import alibabacloud_oss_v2 as oss  # type: ignore
        except ImportError:
            self._enabled = False
            if not self._warned:
                print(
                    "[logger WARN] alibabacloud-oss-v2 SDK not installed, "
                    "log upload disabled. pip install alibabacloud-oss-v2",
                    file=sys.stderr,
                )
                self._warned = True
            return
        except Exception as e:
            self._enabled = False
            if not self._warned:
                print(
                    f"[logger WARN] alibabacloud_oss_v2 import failed "
                    f"({type(e).__name__}: {e}), log upload disabled.",
                    file=sys.stderr,
                )
                self._warned = True
            return

        try:
            cred = oss.credentials.StaticCredentialsProvider(ak, sk)
            cfg = oss.config.load_default()
            cfg.credentials_provider = cred
            if region:
                cfg.region = region
            if endpoint:
                cfg.endpoint = endpoint
            self._client = oss.Client(cfg)
            self._bucket_name = bucket_name
            self._put_object_request_cls = oss.PutObjectRequest
            self._enabled = True
        except Exception as e:  # noqa: BLE001
            self._enabled = False
            print(
                f"[logger WARN] failed to init OSS V2 client: {e}",
                file=sys.stderr,
            )

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def bucket_name(self) -> Optional[str]:
        return self._bucket_name

    @staticmethod
    def build_oss_key(ctx: LogContext, filename: str) -> str:
        prefix = os.environ.get(
            "LOG_OSS_PATH_PREFIX", DEFAULT_LOG_OSS_PATH_PREFIX
        ).strip().strip("/")
        pid, pi, nt = ctx.oss_path_segments()
        return f"{prefix}/{pid}/{pi}/{nt}/{filename}"

    @staticmethod
    def _is_retryable(e: BaseException) -> bool:
        """判断 OSS 上传异常是否可重试。"""
        try:
            import alibabacloud_oss_v2 as oss  # type: ignore
            if isinstance(e, oss.exceptions.OperationError):
                # OperationError 包含 status_code; 5xx 可重试, 4xx 不可重试
                err_str = str(e).lower()
                if "accessdenied" in err_str or "nosuchbucket" in err_str:
                    return False
                if "serviceunavailable" in err_str or "internalerror" in err_str:
                    return True
        except (ImportError, Exception):
            pass
        # 兜底: 按异常消息关键字判断
        msg = f"{type(e).__name__}:{e}"
        retryable_kw = [
            "timeout", "TimeoutError",
            "ConnectionError", "ConnectionReset", "ConnectionAborted",
            "Errno 104", "Errno 111", "Errno 110",
            "NetworkError", "ServiceUnavailable", "InternalError",
            "RequestTimeTooSkewed",
        ]
        low = msg.lower()
        return any(kw.lower() in low for kw in retryable_kw)

    def upload_with_retry(
        self,
        local_path: str,
        ctx: LogContext,
        basename: str,
    ) -> str:
        """上传本地文件到 OSS, 失败按指数退避重试。成功返回 OSS object key。"""
        if not self._enabled or self._client is None:
            raise RuntimeError("OSS uploader not enabled")

        max_retries = _env_int("LOG_OSS_MAX_RETRIES", 3, minimum=1)
        base_delay = _env_float("LOG_OSS_RETRY_DELAY", 1.0, minimum=0.0)
        backoff = _env_float("LOG_OSS_RETRY_BACKOFF", 2.0, minimum=1.0)
        max_delay = _env_float("LOG_OSS_RETRY_MAX_DELAY", 30.0, minimum=0.0)

        oss_key = self.build_oss_key(ctx, basename)
        delay = base_delay
        last_exc: Optional[BaseException] = None

        for attempt in range(1, max_retries + 1):
            try:
                self._client.put_object_from_file(
                    self._put_object_request_cls(
                        bucket=self._bucket_name,
                        key=oss_key,
                    ),
                    local_path,
                )
                if attempt > 1:
                    print(
                        f"[logger INFO] OSS upload succeeded on attempt {attempt}: "
                        f"oss://{self._bucket_name}/{oss_key}",
                        file=sys.stderr,
                    )
                return oss_key
            except Exception as e:  # noqa: BLE001
                last_exc = e
                if not self._is_retryable(e):
                    raise
                if attempt >= max_retries:
                    raise
                sleep_for = min(delay, max_delay)
                print(
                    f"[logger WARN] OSS upload failed "
                    f"(attempt {attempt}/{max_retries}): "
                    f"{type(e).__name__}: {e}, retrying in {sleep_for:.1f}s",
                    file=sys.stderr,
                )
                time.sleep(sleep_for)
                delay *= backoff

        if last_exc is not None:
            raise last_exc
        raise RuntimeError("upload_with_retry: unreachable")


def _env_int(name: str, default: int, minimum: Optional[int] = None) -> int:
    try:
        v = int(os.environ.get(name, default))
    except (TypeError, ValueError):
        v = default
    if minimum is not None and v < minimum:
        v = minimum
    return v


def _env_float(name: str, default: float, minimum: Optional[float] = None) -> float:
    try:
        v = float(os.environ.get(name, default))
    except (TypeError, ValueError):
        v = default
    if minimum is not None and v < minimum:
        v = minimum
    return v


# ---------------------------------------------------------------------------
# RayLogger (core)
# ---------------------------------------------------------------------------

_LEVEL_ORDER = {
    "DEBUG": 10,
    "INFO": 20,
    "WARNING": 30,
    "ERROR": 40,
    "CRITICAL": 50,
}


class RayLogger:
    """进程内单例的核心 logger。

    - role: 'header' / 'worker' / 'auto'。
    - 懒初始化: 首次 info/flush 等调用会自动 init(role='auto')。
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._initialized = False
        self.role: Literal["header", "worker", "auto"] = "auto"
        self.level: int = logging.INFO
        self._context_overrides: Optional[Dict[str, Any]] = None
        self.router: LogRouter = LogRouter()
        self.formatter: LineFormatter = LineFormatter()
        self._uploader: Optional[OSSUploader] = None
        self._base_dir: Optional[str] = None
        self._base_dir_created: bool = False
        self._worker_default_warned: bool = False
        # 用于 get_service_logger / set_service_context 兼容
        self._service_name: Optional[str] = None
        self._service_version: Optional[str] = None

    @property
    def context(self) -> LogContext:
        """每次访问时实时从环境变量读取, 合并 overrides。"""
        return LogContext.from_env(self._context_overrides)

    # ---- init ----
    def init(
        self,
        role: Literal["header", "worker", "auto"] = "auto",
        level: str = "INFO",
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        with self._lock:
            if role not in ("header", "worker", "auto"):
                role = "auto"
            self.role = role
            lvl_name = (level or "INFO").upper()
            self.level = _LEVEL_ORDER.get(lvl_name, logging.INFO)
            if context:
                self._context_overrides = context
            if not self._initialized:
                self._uploader = OSSUploader()
                self._initialized = True

    def _ensure_initialized(self) -> None:
        if not self._initialized:
            self.init(role="auto")

    def _compute_base_dir(self) -> str:
        base = os.environ.get("LOG_BASE_DIR", DEFAULT_LOG_BASE_DIR)
        return os.path.join(base, self.context.dir_segment())

    def _ensure_base_dir(self) -> Optional[str]:
        """延迟创建 base_dir（首次写入时才确定，此时环境变量已就绪）。"""
        if self._base_dir is not None and self._base_dir_created:
            return self._base_dir
        self._base_dir = self._compute_base_dir()
        try:
            os.makedirs(self._base_dir, exist_ok=True)
            self._base_dir_created = True
        except OSError as e:
            print(
                f"[logger WARN] mkdir failed for {self._base_dir}: {e}, "
                f"falling back to console-only.",
                file=sys.stderr,
            )
            self._base_dir = None
        return self._base_dir

    # ---- role / routing ----
    def _resolve_file_key(self, call_key: Optional[str]) -> Optional[str]:
        """返回路由 key: None(header) / '__worker_default__' / user-key。"""
        if self.role == "header":
            return None
        if self.role == "worker":
            if call_key is None or call_key == "":
                # worker 模式未传 key
                if not self._worker_default_warned:
                    print(
                        "[logger WARN] worker role called without 'key', "
                        "writing to worker_default.log",
                        file=sys.stderr,
                    )
                    self._worker_default_warned = True
                return _WORKER_DEFAULT_KEY_SENTINEL
            return str(call_key)
        # auto
        if call_key is None or call_key == "":
            return None
        return str(call_key)

    def _file_name_of(self, file_key: Optional[str]) -> str:
        if file_key is None:
            return HEADER_FILE_NAME
        if file_key == _WORKER_DEFAULT_KEY_SENTINEL:
            return WORKER_DEFAULT_FILE_NAME
        return f"{sanitize_key(file_key)}.log"

    # ---- write ----
    def _caller(self, depth: int) -> Tuple[Optional[str], Optional[int]]:
        try:
            frame = sys._getframe(depth)
        except ValueError:
            return None, None
        if frame is None:
            return None, None
        co = frame.f_code
        return os.path.basename(co.co_filename), frame.f_lineno

    def _write(
        self,
        level_name: str,
        message: Any,
        key: Optional[str],
        caller_depth: int,
        include_exc: bool = False,
    ) -> None:
        self._ensure_initialized()
        level_num = _LEVEL_ORDER.get(level_name, logging.INFO)
        if level_num < self.level:
            return

        file_key = self._resolve_file_key(key)
        filename = self._file_name_of(file_key)
        # 日志列中的 key: 原始用户 key(未 sanitize), 缺失写 "-"
        line_key = None
        if key is not None and str(key) != "":
            line_key = str(key)

        caller_file, caller_line = self._caller(caller_depth)

        # 业务日志可能因 service_name/version 存在, 作为 message 前缀附加
        msg_text = str(message)
        if self._service_name:
            prefix = f"[{self._service_name}"
            if self._service_version:
                prefix += f" v{self._service_version}"
            prefix += "] "
            msg_text = prefix + msg_text

        line = self.formatter.format(
            ts=datetime.now(),
            level=level_name,
            ctx=self.context,
            key=line_key,
            caller_file=caller_file,
            caller_line=caller_line,
            message=msg_text,
        )

        # 写文件
        base_dir = self._ensure_base_dir()
        if base_dir is not None:
            sink = self.router.get_or_create(
                file_key=file_key,
                base_dir=base_dir,
                filename=filename,
                original_key=line_key,
            )
            sink.write_line(line)

        # 同步输出到 console(Ray 自动采集)
        stream = sys.stderr if level_num >= logging.ERROR else sys.stdout
        try:
            stream.write(line + "\n")
        except Exception:  # noqa: BLE001
            pass

        # 异常堆栈附加(多行, 为保持可解析, 以 "# " 前缀开头, 同时原样保留)
        if include_exc:
            exc_info = sys.exc_info()
            if exc_info and exc_info[0] is not None:
                import traceback

                tb = "".join(traceback.format_exception(*exc_info)).rstrip()
                # 写入本地文件
                if base_dir is not None:
                    sink = self.router.get_or_create(
                        file_key=file_key,
                        base_dir=base_dir,
                        filename=filename,
                        original_key=line_key,
                    )
                    for ln in tb.splitlines():
                        sink.write_line("# " + ln)
                try:
                    stream.write(tb + "\n")
                except Exception:  # noqa: BLE001
                    pass

    # ---- public logging API ----
    # 签名兼容标准 logging: info(msg, *args, **kwargs)
    # 同时支持新 API: info(msg='...', key='...')
    def debug(self, msg: Any = "", *args: Any, key: Optional[str] = None, **_kw: Any) -> None:
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {' '.join(str(a) for a in args)}"
        self._write("DEBUG", msg, key, caller_depth=3)

    def info(self, msg: Any = "", *args: Any, key: Optional[str] = None, **_kw: Any) -> None:
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {' '.join(str(a) for a in args)}"
        self._write("INFO", msg, key, caller_depth=3)

    def warning(self, msg: Any = "", *args: Any, key: Optional[str] = None, **_kw: Any) -> None:
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {' '.join(str(a) for a in args)}"
        self._write("WARNING", msg, key, caller_depth=3)

    # alias, 兼容 logging 风格
    def warn(self, msg: Any = "", *args: Any, key: Optional[str] = None, **_kw: Any) -> None:
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {' '.join(str(a) for a in args)}"
        self._write("WARNING", msg, key, caller_depth=3)

    def error(
        self,
        msg: Any = "",
        *args: Any,
        key: Optional[str] = None,
        exc_info: bool = False,
        **_kw: Any,
    ) -> None:
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {' '.join(str(a) for a in args)}"
        self._write("ERROR", msg, key, caller_depth=3, include_exc=bool(exc_info))

    def exception(self, msg: Any = "", *args: Any, key: Optional[str] = None, **_kw: Any) -> None:
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {' '.join(str(a) for a in args)}"
        self._write("ERROR", msg, key, caller_depth=3, include_exc=True)

    def critical(self, msg: Any = "", *args: Any, key: Optional[str] = None, **_kw: Any) -> None:
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {' '.join(str(a) for a in args)}"
        self._write("CRITICAL", msg, key, caller_depth=3)

    # ---- flush / upload / cleanup ----
    def _flush_one(
        self, file_key: Optional[str], sink: FileSink
    ) -> None:
        """关闭 sink -> 尝试上传 -> 无论成败删除本地。"""
        try:
            sink.close()
        except Exception as e:  # noqa: BLE001
            print(
                f"[logger WARN] close failed for {sink.file_path}: {e}",
                file=sys.stderr,
            )

        # 上传(仅当 uploader 可用且文件存在)
        if self._uploader and self._uploader.enabled and os.path.exists(sink.file_path):
            try:
                filename = os.path.basename(sink.file_path)
                oss_key = self._uploader.upload_with_retry(
                    sink.file_path, self.context, filename
                )
                bucket = self._uploader.bucket_name
                print(
                    f"[logger INFO] uploaded log to oss://{bucket}/{oss_key}",
                    file=sys.stderr,
                )
            except Exception as e:  # noqa: BLE001
                print(
                    f"[logger ERROR] OSS upload failed for {sink.file_path}: "
                    f"{type(e).__name__}: {e}",
                    file=sys.stderr,
                )

        # 无论上传成功失败, 删除本地(Story 4 AC#4 / Story 7 AC#3)
        try:
            if os.path.exists(sink.file_path):
                os.remove(sink.file_path)
        except OSError as e:
            print(
                f"[logger WARN] remove failed for {sink.file_path}: {e}",
                file=sys.stderr,
            )

    def flush(self, key: Optional[str] = None) -> None:
        """flush 指定 key 对应的日志: 关闭 -> 上传 -> 删本地。幂等。"""
        self._ensure_initialized()
        # 解析 file_key(不触发 worker_default 的 WARN; 如果 role=worker 且 key=None
        # 且从未写过, 这里 pop 会得到 None, 幂等 no-op)
        if self.role == "header":
            file_key: Optional[str] = None
        elif self.role == "worker":
            if key is None or key == "":
                file_key = _WORKER_DEFAULT_KEY_SENTINEL
            else:
                file_key = str(key)
        else:  # auto
            if key is None or key == "":
                file_key = None
            else:
                file_key = str(key)

        sink = self.router.pop(file_key)
        if sink is None:
            return
        self._flush_one(file_key, sink)

    def flush_all(self) -> None:
        """flush 当前进程所有 key 的日志。幂等。"""
        self._ensure_initialized()
        items = self.router.drain()
        for file_key, sink in items:
            self._flush_one(file_key, sink)

    # ---- 兼容辅助 ----
    def set_service_context(
        self, service_name: Optional[str], version: Optional[str] = None
    ) -> None:
        with self._lock:
            self._service_name = service_name
            self._service_version = version

    def get_header_log_path(self) -> Optional[str]:
        if not self._initialized:
            return None
        base_dir = self._ensure_base_dir()
        if base_dir is None:
            return None
        if self.role == "worker":
            return None
        return os.path.join(base_dir, HEADER_FILE_NAME)


# ---------------------------------------------------------------------------
# Module-level singleton & public API
# ---------------------------------------------------------------------------

_global_ray_logger: Optional[RayLogger] = None
_global_ray_logger_lock = threading.Lock()


def _get_ray_logger() -> RayLogger:
    global _global_ray_logger
    if _global_ray_logger is None:
        with _global_ray_logger_lock:
            if _global_ray_logger is None:
                _global_ray_logger = RayLogger()
    return _global_ray_logger


# ---- 新 API(直接函数调用也可) ----

def init(
    role: Literal["header", "worker", "auto"] = "auto",
    level: str = "INFO",
    context: Optional[Dict[str, Any]] = None,
) -> None:
    _get_ray_logger().init(role=role, level=level, context=context)


def flush(key: Optional[str] = None) -> None:
    _get_ray_logger().flush(key=key)


def flush_all() -> None:
    _get_ray_logger().flush_all()


# ---- 向后兼容: setup_logging / get_log_file_path ----

def setup_logging(
    level: str = "INFO",
    json_format: bool = False,  # noqa: ARG001  保留签名兼容, 新 logger 始终文本格式
    service_name: str = "unknown",
    version: Optional[str] = None,
) -> Optional[str]:
    """向后兼容接口: 初始化全局 logger 并设置 service_name/version。

    返回 header.log 的本地路径(若处于 header/auto 模式)。
    """
    rl = _get_ray_logger()
    rl.init(role="auto", level=level)
    rl.set_service_context(service_name, version)
    return rl.get_header_log_path()


def get_log_file_path() -> Optional[str]:
    """向后兼容接口: 返回 header.log 本地路径(若存在)。"""
    rl = _get_ray_logger()
    return rl.get_header_log_path()


def set_service_context(
    service_name: Optional[str], version: Optional[str] = None
) -> None:
    """向后兼容接口: 设置服务名/版本, 会作为日志 message 前缀。"""
    _get_ray_logger().set_service_context(service_name, version)


# ---------------------------------------------------------------------------
# 向后兼容: ServiceLoggerAdapter (旧接口, 适配到新 RayLogger)
# ---------------------------------------------------------------------------


class ServiceLoggerAdapter:
    """向后兼容: 旧的 ServiceLoggerAdapter 接口适配到 RayLogger。

    暴露 info/debug/warning/error/exception 方法, 接受 msg 位置参数或关键字参数,
    并透传 'extra' 等 logging 风格参数(被忽略, 但不报错)。
    """

    def __init__(self, name: str, version: Optional[str] = None):
        self.service_name = name
        self.version = version
        self._rl = _get_ray_logger()

    def _call(
        self,
        level: str,
        msg: Any,
        *args: Any,
        exc_info: bool = False,
        key: Optional[str] = None,
        **_ignored: Any,
    ) -> None:
        # 模拟 logging 的 % formatting
        if args:
            try:
                msg = str(msg) % args
            except (TypeError, ValueError):
                msg = f"{msg} {args}"
        # 临时挂载 service_name/version(仅此次调用)
        # 为简化实现, 直接使用全局 set_service_context; 旧代码模型里 adapter 就是绑定的
        self._rl.set_service_context(self.service_name, self.version)
        if level == "DEBUG":
            self._rl._write("DEBUG", msg, key, caller_depth=3)
        elif level == "WARNING":
            self._rl._write("WARNING", msg, key, caller_depth=3)
        elif level == "ERROR":
            self._rl._write("ERROR", msg, key, caller_depth=3, include_exc=bool(exc_info))
        elif level == "CRITICAL":
            self._rl._write("CRITICAL", msg, key, caller_depth=3)
        else:
            self._rl._write("INFO", msg, key, caller_depth=3)

    def debug(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._call("DEBUG", msg, *args, **kwargs)

    def info(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._call("INFO", msg, *args, **kwargs)

    def warning(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._call("WARNING", msg, *args, **kwargs)

    # alias
    def warn(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._call("WARNING", msg, *args, **kwargs)

    def error(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._call("ERROR", msg, *args, **kwargs)

    def exception(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        kwargs["exc_info"] = True
        self._call("ERROR", msg, *args, **kwargs)

    def critical(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._call("CRITICAL", msg, *args, **kwargs)


def get_service_logger(
    name: str, version: Optional[str] = None
) -> ServiceLoggerAdapter:
    """向后兼容接口: 返回一个按 service_name 命名的 adapter。"""
    # 确保 RayLogger 已初始化且挂上 service 信息
    _get_ray_logger().init(role="auto")
    _get_ray_logger().set_service_context(name, version)
    return ServiceLoggerAdapter(name, version)


# ---------------------------------------------------------------------------
# _LazyLogger: 模块级代理, 兼容 `from ... import logger; logger.info(...)`
# ---------------------------------------------------------------------------


class _LazyLogger:
    """将属性访问代理到 RayLogger 单例。保留惰性绑定, 兼容 Ray 序列化场景。"""

    # 将这些方法转到 RayLogger; 其它属性仍可通过 __getattr__ 走代理
    _METHODS = {
        "init", "flush", "flush_all",
        "debug", "info", "warning", "warn",
        "error", "exception", "critical",
        "set_service_context",
        "get_header_log_path",
    }

    def __getattr__(self, name: str) -> Any:
        rl = _get_ray_logger()
        if name in self._METHODS:
            return getattr(rl, name)
        # 其它属性(context / role / router / ...)也直接代理
        return getattr(rl, name)

    def __repr__(self) -> str:
        rl = _get_ray_logger()
        return f"<LazyLogger role={rl.role} initialized={rl._initialized}>"


# 模块级单例, 用户 `from hello_datap_component_base import logger` 即可
logger = _LazyLogger()


__all__ = [
    "logger",
    "init",
    "flush",
    "flush_all",
    "setup_logging",
    "get_log_file_path",
    "set_service_context",
    "get_service_logger",
    "ServiceLoggerAdapter",
    # 内部但可能对测试有用
    "LogContext",
    "LineFormatter",
    "FileSink",
    "LogRouter",
    "OSSUploader",
    "RayLogger",
    "sanitize_key",
]
