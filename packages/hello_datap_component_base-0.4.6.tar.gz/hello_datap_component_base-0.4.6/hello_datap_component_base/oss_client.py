"""
阿里云 OSS（对象存储）客户端
用于上传日志文件和任务结果到 OSS

使用 alibabacloud_oss_v2 SDK (V2)。
"""
import json
import os
import re
import logging
from typing import Optional, Dict, Any
from pathlib import Path

logger = logging.getLogger(__name__)

# 任务结果上传的默认 OSS 配置
DEFAULT_RESULT_OSS_BUCKET = "infra-hads-artifacts"
RESULT_OSS_PREFIX = "data-process-platform/task-result"


def _get_region_from_endpoint(endpoint: str) -> str:
    """从 endpoint 推断 region, 如 https://oss-cn-shanghai.aliyuncs.com -> cn-shanghai
    内网 endpoint 如 oss-cn-shanghai-internal.aliyuncs.com 也能正确提取。
    """
    m = re.search(r"oss-([a-z0-9-]+)\.", endpoint)
    if not m:
        return ""
    region = m.group(1)
    # 去掉 -internal 后缀（内网 endpoint 标识，不是 region 的一部分）
    region = re.sub(r"-internal$", "", region)
    return region


class OSSClient:
    """阿里云 OSS 客户端 (V2 SDK)"""

    def __init__(self):
        """初始化 OSS 客户端（延迟加载）"""
        self._client = None
        self._bucket_name: Optional[str] = None
        self._initialized = False

    def _init_client(self):
        """初始化 OSS V2 客户端（延迟加载）"""
        if self._initialized:
            return

        try:
            import alibabacloud_oss_v2 as oss
        except ImportError:
            logger.warning(
                "未安装阿里云 OSS V2 SDK，无法上传文件。"
                "请安装: pip install alibabacloud-oss-v2"
            )
            self._initialized = True
            return
        except Exception as e:
            logger.error(f"导入 alibabacloud_oss_v2 失败: {e}")
            self._initialized = True
            return

        endpoint = os.environ.get('OSS_ENDPOINT_FOR_LOG')
        access_key_id = os.environ.get('OSS_ACCESS_KEY_ID_FOR_LOG')
        access_key_secret = os.environ.get('OSS_ACCESS_KEY_SECRET_FOR_LOG')
        bucket_name = os.environ.get('OSS_BUCKET_NAME_FOR_LOG')
        region = os.environ.get('OSS_REGION_FOR_LOG', '')

        if not endpoint:
            self._initialized = True
            return

        if not all([access_key_id, access_key_secret, bucket_name]):
            logger.warning(
                "OSS 配置不完整，无法上传文件。"
                "需要设置: OSS_ACCESS_KEY_ID_FOR_LOG, "
                "OSS_ACCESS_KEY_SECRET_FOR_LOG, OSS_BUCKET_NAME_FOR_LOG"
            )
            self._initialized = True
            return

        if not region:
            region = _get_region_from_endpoint(endpoint)

        try:
            cred = oss.credentials.StaticCredentialsProvider(
                access_key_id, access_key_secret
            )
            cfg = oss.config.load_default()
            cfg.credentials_provider = cred
            if region:
                cfg.region = region
            cfg.endpoint = endpoint
            self._client = oss.Client(cfg)
            self._bucket_name = bucket_name
            self._initialized = True
            logger.info(f"OSS V2 客户端初始化成功，Bucket: {bucket_name}")
        except Exception as e:
            logger.error(f"初始化 OSS V2 客户端失败: {e}")
            self._initialized = True

    def upload_file(
        self,
        local_file_path: str,
        oss_object_key: Optional[str] = None,
    ) -> bool:
        """上传文件到 OSS"""
        self._init_client()

        if not self._client:
            return False

        file_path = Path(local_file_path)
        if not file_path.exists():
            logger.warning(f"文件不存在: {local_file_path}")
            return False

        try:
            import alibabacloud_oss_v2 as oss

            if oss_object_key is None:
                oss_object_key = file_path.name

            oss_path_prefix = os.environ.get('OSS_LOG_PATH_PREFIX', '')
            if oss_path_prefix:
                if not oss_path_prefix.endswith('/'):
                    oss_path_prefix += '/'
                oss_object_key = oss_path_prefix + oss_object_key

            self._client.put_object_from_file(
                oss.PutObjectRequest(
                    bucket=self._bucket_name,
                    key=oss_object_key,
                ),
                str(local_file_path),
            )
            logger.info(f"文件已上传到 OSS: {oss_object_key}")
            return True
        except Exception as e:
            logger.error(f"上传文件到 OSS 失败: {e}", exc_info=True)
            return False

    def upload_log_file(self, log_file_path: str) -> bool:
        return self.upload_file(log_file_path)


def get_oss_client() -> Optional[OSSClient]:
    """获取 OSS 客户端实例"""
    if not os.environ.get('OSS_ENDPOINT_FOR_LOG'):
        return None
    client = OSSClient()
    client._init_client()
    if not client._client:
        return None
    return client


def upload_result_to_oss(result: Dict[str, Any], task_id: str) -> Optional[str]:
    """
    上传任务结果 JSON 到 OSS

    路径: oss://{RESULT_OSS_BUCKET}/data-process-platform/task-result/{task_id}.json
    """
    try:
        import alibabacloud_oss_v2 as oss
    except ImportError:
        logger.error(
            "未安装阿里云 OSS V2 SDK，无法上传结果。"
            "请安装: pip install alibabacloud-oss-v2"
        )
        return None
    except Exception as e:
        logger.error(f"导入 alibabacloud_oss_v2 失败: {e}")
        return None

    endpoint = os.environ.get('OSS_ENDPOINT_FOR_LOG')
    access_key_id = os.environ.get('OSS_ACCESS_KEY_ID_FOR_LOG')
    access_key_secret = os.environ.get('OSS_ACCESS_KEY_SECRET_FOR_LOG')

    if not all([endpoint, access_key_id, access_key_secret]):
        logger.error(
            "OSS 认证信息不完整，无法上传结果。"
            "需要: OSS_ENDPOINT_FOR_LOG, OSS_ACCESS_KEY_ID_FOR_LOG, "
            "OSS_ACCESS_KEY_SECRET_FOR_LOG"
        )
        return None

    try:
        result_oss_bucket = (
            os.environ.get("RESULT_OSS_BUCKET", "").strip()
            or DEFAULT_RESULT_OSS_BUCKET
        )
        region = os.environ.get('OSS_REGION_FOR_LOG', '')
        if not region:
            region = _get_region_from_endpoint(endpoint)

        cred = oss.credentials.StaticCredentialsProvider(
            access_key_id, access_key_secret
        )
        cfg = oss.config.load_default()
        cfg.credentials_provider = cred
        if region:
            cfg.region = region
        cfg.endpoint = endpoint
        client = oss.Client(cfg)

        oss_object_key = f"{RESULT_OSS_PREFIX}/{task_id}.json"
        result_json = json.dumps(result, ensure_ascii=False, indent=2)

        client.put_object(
            oss.PutObjectRequest(
                bucket=result_oss_bucket,
                key=oss_object_key,
                body=result_json.encode('utf-8'),
            )
        )

        oss_url = f"oss://{result_oss_bucket}/{oss_object_key}"
        logger.info(f"任务结果已上传到 OSS: {oss_url}")
        return oss_url

    except Exception as e:
        logger.error(f"上传任务结果到 OSS 失败: {e}", exc_info=True)
        return None
