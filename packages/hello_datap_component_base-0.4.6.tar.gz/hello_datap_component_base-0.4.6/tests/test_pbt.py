"""PBT tests for correctness properties P2/P4/P6/P7 (Tasks 11.1-11.5).

All tests use a fresh RayLogger per example via manual reset.
"""

import importlib
import os
import tempfile
from datetime import datetime

from hypothesis import given, settings, HealthCheck
from hypothesis.strategies import text, lists, tuples, integers

_mod = importlib.import_module("hello_datap_component_base.logger")
LineFormatter = _mod.LineFormatter
LogContext = _mod.LogContext
LINE_SEP = _mod.LINE_SEP
LINE_COLUMN_COUNT = _mod.LINE_COLUMN_COUNT
sanitize_key = _mod.sanitize_key


def _reset_logger(tmpdir: str):
    """Reset global singleton and point to tmpdir."""
    os.environ["LOG_BASE_DIR"] = tmpdir
    os.environ.pop("DATA_TRACK_PIPELINE_ID", None)
    os.environ.pop("DATA_TRACK_PIPELINE_INSTANCE_ID", None)
    os.environ.pop("DATA_TRACK_NODE_ID", None)
    os.environ.pop("DATA_TRACK_NODE_TASK_ID", None)
    _mod._global_ray_logger = None


# ---- 11.3 P6: column count stability ----

_fmt = LineFormatter()
_ctx = LogContext()
_ts = datetime(2026, 1, 1)


@given(msg=text(), key=text(), ctx_val=text())
@settings(max_examples=300)
def test_p6_column_count(msg, key, ctx_val):
    ctx = LogContext(
        pipeline_id=ctx_val,
        pipeline_instance_id=ctx_val,
        node_id=ctx_val,
        node_task_id=ctx_val,
    )
    line = _fmt.format(
        ts=_ts, level="INFO", ctx=ctx, key=key,
        caller_file="x.py", caller_line=1, message=msg,
    )
    assert len(line.split(LINE_SEP)) == LINE_COLUMN_COUNT


# ---- 11.1 P2: routing correctness ----

# Use simple ASCII keys to avoid sanitize collisions in this test
_safe_key = text(
    alphabet="abcdefghijklmnopqrstuvwxyz0123456789",
    min_size=1, max_size=10,
)
_msg = text(min_size=1, max_size=50)


@given(entries=lists(tuples(_safe_key, _msg), min_size=1, max_size=20))
@settings(
    max_examples=30,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
)
def test_p2_routing(entries):
    """Messages with same key end up in same file; different keys in different files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        _reset_logger(tmpdir)
        from hello_datap_component_base import logger
        logger.init(role="auto")

        for key, msg in entries:
            logger.info(key=key, msg=msg)

        # Read files
        rl = _mod._get_ray_logger()
        base = rl._base_dir
        if not os.path.exists(base):
            return

        # Group expected messages by sanitized key
        expected = {}
        for key, msg in entries:
            sk = sanitize_key(key)
            expected.setdefault(sk, []).append(msg)

        for sk, msgs in expected.items():
            fpath = os.path.join(base, f"{sk}.log")
            assert os.path.exists(fpath), f"missing file for key={sk}"
            with open(fpath) as f:
                lines = [l.rstrip() for l in f if l.strip()]
            # Each line's message column (last) should contain the expected msg
            file_msgs = [l.split(LINE_SEP)[-1] for l in lines]
            assert len(file_msgs) == len(msgs)


# ---- 11.2 P4: append order ----

@given(msgs=lists(_msg, min_size=2, max_size=20))
@settings(
    max_examples=30,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
)
def test_p4_order(msgs):
    """Messages written to same key appear in order."""
    with tempfile.TemporaryDirectory() as tmpdir:
        _reset_logger(tmpdir)
        from hello_datap_component_base import logger
        logger.init(role="auto")

        key = "order_test"
        for m in msgs:
            logger.info(key=key, msg=m)

        rl = _mod._get_ray_logger()
        fpath = os.path.join(rl._base_dir, f"{sanitize_key(key)}.log")
        if not os.path.exists(fpath):
            return
        with open(fpath) as f:
            lines = [l.rstrip("\n") for l in f if l.rstrip("\n")]
        file_msgs = [l.split(LINE_SEP)[-1] for l in lines]
        # escape_for_line transforms, so compare escaped versions
        from hello_datap_component_base.logger import _escape_for_line
        expected = [_escape_for_line(m) for m in msgs]
        assert file_msgs == expected


# ---- 11.5 P7: no handle leak after flush_all ----

@given(n_keys=integers(min_value=1, max_value=10))
@settings(
    max_examples=20,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
)
def test_p7_no_handle_leak(n_keys):
    with tempfile.TemporaryDirectory() as tmpdir:
        _reset_logger(tmpdir)
        from hello_datap_component_base import logger
        logger.init(role="auto")

        for i in range(n_keys):
            logger.info(key=f"key_{i}", msg=f"msg_{i}")

        logger.flush_all()

        rl = _mod._get_ray_logger()
        assert rl.router.is_empty(), "router should be empty after flush_all"
