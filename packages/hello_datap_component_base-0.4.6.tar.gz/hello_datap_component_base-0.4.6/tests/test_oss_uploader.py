"""Unit tests for OSSUploader retry logic (Task 6.5 / 6.6).

Updated for alibabacloud_oss_v2 SDK.
"""

import os
import tempfile
from unittest.mock import MagicMock, patch

import pytest
from hypothesis import given, settings, HealthCheck
from hypothesis.strategies import integers

from hello_datap_component_base.logger import OSSUploader, LogContext


# ---------------------------------------------------------------------------
# Helpers: build a fake OSSUploader with a mock client
# ---------------------------------------------------------------------------

def _make_uploader() -> OSSUploader:
    """Create an OSSUploader with mocked internals (no real SDK)."""
    up = OSSUploader.__new__(OSSUploader)
    up._enabled = True
    up._client = MagicMock()
    up._bucket_name = "test-bucket"
    up._warned = False
    # Mock PutObjectRequest so upload_with_retry doesn't need the real SDK
    up._put_object_request_cls = MagicMock()
    return up


def _make_ctx() -> LogContext:
    return LogContext(
        pipeline_id="1001",
        pipeline_instance_id="inst-1",
        node_id="n1",
        node_task_id="t1",
    )


def _tmp_file(tmpdir: str) -> str:
    path = os.path.join(tmpdir, "test.log")
    with open(path, "w") as f:
        f.write("log content\n")
    return path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestBuildOssKey:
    def test_default_prefix(self):
        ctx = _make_ctx()
        key = OSSUploader.build_oss_key(ctx, "header.log")
        assert key == "data-process-platform/task-logs/logs/1001/inst-1/t1/header.log"

    def test_custom_prefix(self, monkeypatch):
        monkeypatch.setenv("LOG_OSS_PATH_PREFIX", "custom/prefix")
        ctx = _make_ctx()
        key = OSSUploader.build_oss_key(ctx, "bag.log")
        assert key == "custom/prefix/1001/inst-1/t1/bag.log"


class TestUploadWithRetry:
    def test_success_first_try(self, monkeypatch):
        monkeypatch.setenv("LOG_OSS_MAX_RETRIES", "3")
        with tempfile.TemporaryDirectory() as tmpdir:
            up = _make_uploader()
            path = _tmp_file(tmpdir)
            ctx = _make_ctx()
            oss_key = up.upload_with_retry(path, ctx, "test.log")
            assert "test.log" in oss_key
            up._client.put_object_from_file.assert_called_once()

    def test_retry_then_success(self, monkeypatch):
        monkeypatch.setenv("LOG_OSS_MAX_RETRIES", "3")
        monkeypatch.setenv("LOG_OSS_RETRY_DELAY", "0.01")
        with tempfile.TemporaryDirectory() as tmpdir:
            up = _make_uploader()
            path = _tmp_file(tmpdir)
            ctx = _make_ctx()
            up._client.put_object_from_file.side_effect = [
                ConnectionError("timeout"),
                ConnectionError("timeout"),
                MagicMock(),  # success
            ]
            oss_key = up.upload_with_retry(path, ctx, "test.log")
            assert up._client.put_object_from_file.call_count == 3
            assert "test.log" in oss_key

    def test_all_retries_exhausted(self, monkeypatch):
        monkeypatch.setenv("LOG_OSS_MAX_RETRIES", "3")
        monkeypatch.setenv("LOG_OSS_RETRY_DELAY", "0.01")
        with tempfile.TemporaryDirectory() as tmpdir:
            up = _make_uploader()
            path = _tmp_file(tmpdir)
            ctx = _make_ctx()
            up._client.put_object_from_file.side_effect = ConnectionError("timeout")
            with pytest.raises(ConnectionError):
                up.upload_with_retry(path, ctx, "test.log")
            assert up._client.put_object_from_file.call_count == 3

    def test_non_retryable_fails_immediately(self, monkeypatch):
        monkeypatch.setenv("LOG_OSS_MAX_RETRIES", "5")
        monkeypatch.setenv("LOG_OSS_RETRY_DELAY", "0.01")
        with tempfile.TemporaryDirectory() as tmpdir:
            up = _make_uploader()
            path = _tmp_file(tmpdir)
            ctx = _make_ctx()
            up._client.put_object_from_file.side_effect = ValueError("bad param")
            with pytest.raises(ValueError):
                up.upload_with_retry(path, ctx, "test.log")
            assert up._client.put_object_from_file.call_count == 1

    def test_not_enabled_raises(self):
        up = _make_uploader()
        up._enabled = False
        with pytest.raises(RuntimeError, match="not enabled"):
            up.upload_with_retry("/tmp/x", _make_ctx(), "x.log")


class TestPBTRetryBound:
    """P3b: retry count == LOG_OSS_MAX_RETRIES when always failing."""

    @given(max_retries=integers(min_value=1, max_value=5))
    @settings(max_examples=20, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_retry_count_matches_config(self, max_retries, monkeypatch):
        monkeypatch.setenv("LOG_OSS_MAX_RETRIES", str(max_retries))
        monkeypatch.setenv("LOG_OSS_RETRY_DELAY", "0.001")
        with tempfile.TemporaryDirectory() as tmpdir:
            up = _make_uploader()
            path = _tmp_file(tmpdir)
            ctx = _make_ctx()
            up._client.put_object_from_file.side_effect = ConnectionError("timeout")
            with pytest.raises(ConnectionError):
                up.upload_with_retry(path, ctx, "test.log")
            assert up._client.put_object_from_file.call_count == max_retries
