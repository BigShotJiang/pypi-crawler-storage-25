"""PBT tests for sanitize_key and _escape_for_line (Task 1.4)."""

import re
from hypothesis import given, settings
from hypothesis.strategies import text

from hello_datap_component_base.logger import (
    sanitize_key,
    _escape_for_line,
    MAX_FILENAME_LEN,
    _UNSAFE_FS_CHARS_RE,
)


# ---- sanitize_key properties ----

@given(text())
@settings(max_examples=500)
def test_sanitize_key_no_illegal_chars(s: str):
    """P: sanitize_key result contains no filesystem-unsafe characters."""
    result = sanitize_key(s)
    assert _UNSAFE_FS_CHARS_RE.search(result) is None, (
        f"illegal char in sanitize_key({s!r}) -> {result!r}"
    )


@given(text())
@settings(max_examples=500)
def test_sanitize_key_length_bound(s: str):
    """P: sanitize_key result length <= MAX_FILENAME_LEN."""
    result = sanitize_key(s)
    assert len(result) <= MAX_FILENAME_LEN


@given(text())
@settings(max_examples=500)
def test_sanitize_key_non_empty(s: str):
    """P: sanitize_key never returns empty string."""
    result = sanitize_key(s)
    assert len(result) > 0


def test_sanitize_key_none():
    assert sanitize_key(None) == "unnamed"


def test_sanitize_key_empty():
    assert sanitize_key("") == "unnamed"


def test_sanitize_key_dots_only():
    assert sanitize_key("...") == "unnamed"


def test_sanitize_key_slash():
    assert "/" not in sanitize_key("a/b/c")


def test_sanitize_key_long():
    result = sanitize_key("x" * 300)
    assert len(result) == MAX_FILENAME_LEN


# ---- _escape_for_line properties ----

@given(text())
@settings(max_examples=500)
def test_escape_no_pipe(s: str):
    """P: _escape_for_line result contains no literal '|'."""
    result = _escape_for_line(s)
    assert "|" not in result, f"pipe in _escape_for_line({s!r}) -> {result!r}"


@given(text())
@settings(max_examples=500)
def test_escape_no_newline(s: str):
    """P: _escape_for_line result contains no literal newline/CR/FF/VT/line-sep."""
    result = _escape_for_line(s)
    assert "\n" not in result, f"newline in result: {result!r}"
    assert "\r" not in result, f"CR in result: {result!r}"
    assert "\x0b" not in result, f"VT in result: {result!r}"
    assert "\x0c" not in result, f"FF in result: {result!r}"
    assert "\u2028" not in result, f"LS in result: {result!r}"
    assert "\u2029" not in result, f"PS in result: {result!r}"


def test_escape_none():
    assert _escape_for_line(None) == "-"


def test_escape_empty():
    assert _escape_for_line("") == "-"
