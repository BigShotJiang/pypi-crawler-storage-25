"""Unit tests for FileSink (Task 4.4)."""

import os
import tempfile
import threading

from hello_datap_component_base.logger import FileSink


def test_multithread_write_integrity():
    """100 threads x 100 writes -> 10000 complete lines, no interleaving."""
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test.log")
        sink = FileSink(key="test", file_path=path)

        n_threads = 100
        n_writes = 100
        barrier = threading.Barrier(n_threads)

        def writer(tid: int):
            barrier.wait()
            for i in range(n_writes):
                sink.write_line(f"T{tid:03d}-L{i:03d}")

        threads = [
            threading.Thread(target=writer, args=(t,))
            for t in range(n_threads)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        sink.close()

        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        assert len(lines) == n_threads * n_writes, (
            f"expected {n_threads * n_writes}, got {len(lines)}"
        )
        # Each line should match pattern T###-L###
        for i, line in enumerate(lines):
            stripped = line.rstrip("\n")
            assert stripped.startswith("T") and "-L" in stripped, (
                f"line {i} corrupted: {line!r}"
            )


def test_close_idempotent():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test.log")
        sink = FileSink(key="k", file_path=path)
        sink.write_line("hello")
        sink.close()
        sink.close()  # should not raise
        assert sink._fh is None


def test_write_after_close_reopens():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test.log")
        sink = FileSink(key="k", file_path=path)
        sink.write_line("line1")
        sink.close()
        sink.write_line("line2")
        sink.close()
        with open(path) as f:
            lines = f.readlines()
        assert len(lines) == 2
