"""Unit tests for LogContext (Task 2.5)."""

import os
import pytest
from hello_datap_component_base.logger import LogContext, MISSING, UNKNOWN


ENV_KEYS = [
    "DATA_TRACK_PIPELINE_ID",
    "DATA_TRACK_PIPELINE_INSTANCE_ID",
    "DATA_TRACK_NODE_ID",
    "DATA_TRACK_NODE_TASK_ID",
]


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Remove all DATA_TRACK_* env vars before each test."""
    for k in ENV_KEYS:
        monkeypatch.delenv(k, raising=False)


class TestFromEnvAllMissing:
    def test_defaults(self):
        ctx = LogContext.from_env()
        assert ctx.pipeline_id == MISSING
        assert ctx.pipeline_instance_id == MISSING
        assert ctx.node_id == MISSING
        assert ctx.node_task_id == MISSING

    def test_dir_segment_all_missing(self):
        ctx = LogContext.from_env()
        assert ctx.dir_segment() == f"{UNKNOWN}_{UNKNOWN}"

    def test_oss_path_all_missing(self):
        ctx = LogContext.from_env()
        assert ctx.oss_path_segments() == (UNKNOWN, UNKNOWN, UNKNOWN)


class TestFromEnvPartial:
    def test_only_pipeline_id(self, monkeypatch):
        monkeypatch.setenv("DATA_TRACK_PIPELINE_ID", "42")
        ctx = LogContext.from_env()
        assert ctx.pipeline_id == "42"
        assert ctx.pipeline_instance_id == MISSING
        assert ctx.node_id == MISSING
        assert ctx.node_task_id == MISSING

    def test_dir_segment_partial(self, monkeypatch):
        monkeypatch.setenv("DATA_TRACK_PIPELINE_INSTANCE_ID", "inst-1")
        ctx = LogContext.from_env()
        assert ctx.dir_segment() == f"inst-1_{UNKNOWN}"


class TestFromEnvFull:
    def test_all_set(self, monkeypatch):
        monkeypatch.setenv("DATA_TRACK_PIPELINE_ID", "1001")
        monkeypatch.setenv("DATA_TRACK_PIPELINE_INSTANCE_ID", "20260430")
        monkeypatch.setenv("DATA_TRACK_NODE_ID", "node-x")
        monkeypatch.setenv("DATA_TRACK_NODE_TASK_ID", "task-y")
        ctx = LogContext.from_env()
        assert ctx.pipeline_id == "1001"
        assert ctx.pipeline_instance_id == "20260430"
        assert ctx.node_id == "node-x"
        assert ctx.node_task_id == "task-y"
        assert ctx.dir_segment() == "20260430_task-y"
        assert ctx.oss_path_segments() == ("1001", "20260430", "task-y")


class TestOverrides:
    def test_override_replaces_env(self, monkeypatch):
        monkeypatch.setenv("DATA_TRACK_PIPELINE_ID", "env-val")
        ctx = LogContext.from_env(overrides={"pipeline_id": "override-val"})
        assert ctx.pipeline_id == "override-val"

    def test_override_none_becomes_missing(self):
        ctx = LogContext.from_env(overrides={"pipeline_id": None})
        assert ctx.pipeline_id == MISSING

    def test_override_empty_becomes_missing(self):
        ctx = LogContext.from_env(overrides={"pipeline_id": ""})
        assert ctx.pipeline_id == MISSING

    def test_unknown_override_ignored(self):
        ctx = LogContext.from_env(overrides={"bogus_field": "x"})
        assert not hasattr(ctx, "bogus_field") or ctx.pipeline_id == MISSING


class TestFrozen:
    def test_immutable(self):
        ctx = LogContext.from_env()
        with pytest.raises(AttributeError):
            ctx.pipeline_id = "new"  # type: ignore[misc]
