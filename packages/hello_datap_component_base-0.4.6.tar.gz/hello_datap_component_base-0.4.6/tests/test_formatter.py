"""PBT tests for LineFormatter (Task 3.5, P6)."""

from datetime import datetime
from hypothesis import given, settings
from hypothesis.strategies import text, datetimes

from hello_datap_component_base.logger import (
    LineFormatter,
    LogContext,
    LINE_SEP,
    LINE_COLUMN_COUNT,
)

_fmt = LineFormatter()
_fixed_ts = datetime(2026, 4, 30, 14, 23, 45, 123000)
_default_ctx = LogContext()


@given(msg=text(), key=text(), ctx_val=text())
@settings(max_examples=500)
def test_column_count_always_9(msg: str, key: str, ctx_val: str):
    """P6: any message/key/context -> split produces exactly 9 columns."""
    ctx = LogContext(
        pipeline_id=ctx_val,
        pipeline_instance_id=ctx_val,
        node_id=ctx_val,
        node_task_id=ctx_val,
    )
    line = _fmt.format(
        ts=_fixed_ts,
        level="INFO",
        ctx=ctx,
        key=key,
        caller_file="test.py",
        caller_line=42,
        message=msg,
    )
    cols = line.split(LINE_SEP)
    assert len(cols) == LINE_COLUMN_COUNT, (
        f"expected {LINE_COLUMN_COUNT} columns, got {len(cols)}: {line!r}"
    )


@given(msg=text())
@settings(max_examples=200)
def test_no_raw_newlines_in_output(msg: str):
    """Formatted line must not contain raw newlines."""
    line = _fmt.format(
        ts=_fixed_ts,
        level="ERROR",
        ctx=_default_ctx,
        key=None,
        caller_file="x.py",
        caller_line=1,
        message=msg,
    )
    assert "\n" not in line
    assert "\r" not in line


def test_missing_fields_use_dash():
    line = _fmt.format(
        ts=_fixed_ts,
        level="INFO",
        ctx=_default_ctx,
        key=None,
        caller_file=None,
        caller_line=None,
        message="hello",
    )
    cols = line.split(LINE_SEP)
    assert len(cols) == 9
    # key, caller should be "-"
    assert cols[6] == "-"  # key
    assert cols[7] == "-"  # file:line


def test_timestamp_format():
    line = _fmt.format(
        ts=_fixed_ts,
        level="INFO",
        ctx=_default_ctx,
        key=None,
        caller_file="a.py",
        caller_line=1,
        message="m",
    )
    ts_col = line.split(LINE_SEP)[0]
    assert ts_col == "2026-04-30 14:23:45.123"
