"""End-to-end tests for RayLogger (Tasks 10.1 - 10.5)."""

import os
import tempfile
from unittest.mock import patch, MagicMock

import pytest

# We need a fresh RayLogger per test, so we reset the global singleton.
from hello_datap_component_base import logger as _logger_proxy
import importlib
_mod = importlib.import_module("hello_datap_component_base.logger")


@pytest.fixture(autouse=True)
def _fresh_logger(monkeypatch, tmp_path):
    """Reset global RayLogger singleton and point LOG_BASE_DIR to tmp."""
    monkeypatch.setenv("LOG_BASE_DIR", str(tmp_path))
    # Reset singleton
    _mod._global_ray_logger = None
    yield
    # Cleanup: drain any remaining sinks
    rl = _mod._global_ray_logger
    if rl is not None:
        try:
            rl.router.drain()
        except Exception:
            pass
    _mod._global_ray_logger = None


def _set_ctx(monkeypatch):
    monkeypatch.setenv("DATA_TRACK_PIPELINE_ID", "1001")
    monkeypatch.setenv("DATA_TRACK_PIPELINE_INSTANCE_ID", "inst-1")
    monkeypatch.setenv("DATA_TRACK_NODE_ID", "node-x")
    monkeypatch.setenv("DATA_TRACK_NODE_TASK_ID", "task-y")


def _log_dir(tmp_path) -> str:
    return os.path.join(str(tmp_path), "inst-1_task-y")


# ---- 10.1 Header E2E ----

class TestE2EHeader:
    def test_header_log_created_with_9_columns(self, monkeypatch, tmp_path):
        _set_ctx(monkeypatch)
        from hello_datap_component_base import logger
        logger.init(role="header")
        for i in range(5):
            logger.info(msg=f"msg-{i}")

        header_path = os.path.join(_log_dir(tmp_path), "header.log")
        assert os.path.exists(header_path)
        with open(header_path) as f:
            lines = [l.rstrip() for l in f if l.strip()]
        assert len(lines) == 5
        for line in lines:
            cols = line.split(" | ")
            assert len(cols) == 9, f"bad columns: {line}"
            # P1: context fields match
            assert cols[2] == "1001"
            assert cols[3] == "inst-1"
            assert cols[4] == "node-x"
            assert cols[5] == "task-y"

    def test_header_key_in_field_not_filename(self, monkeypatch, tmp_path):
        """header role + key passed -> still writes to header.log."""
        _set_ctx(monkeypatch)
        from hello_datap_component_base import logger
        logger.init(role="header")
        logger.info(key="bag_001", msg="test")
        header_path = os.path.join(_log_dir(tmp_path), "header.log")
        assert os.path.exists(header_path)
        # bag_001.log should NOT exist
        bag_path = os.path.join(_log_dir(tmp_path), "bag_001.log")
        assert not os.path.exists(bag_path)


# ---- 10.2 Worker E2E ----

class TestE2EWorker:
    def test_worker_separate_files(self, monkeypatch, tmp_path):
        _set_ctx(monkeypatch)
        from hello_datap_component_base import logger
        logger.init(role="worker")
        logger.info(key="bag_001", msg="a")
        logger.info(key="bag_002", msg="b")

        d = _log_dir(tmp_path)
        assert os.path.exists(os.path.join(d, "bag_001.log"))
        assert os.path.exists(os.path.join(d, "bag_002.log"))

    def test_flush_deletes_one_keeps_other(self, monkeypatch, tmp_path):
        _set_ctx(monkeypatch)
        from hello_datap_component_base import logger
        logger.init(role="worker")
        logger.info(key="bag_001", msg="a")
        logger.info(key="bag_002", msg="b")

        # flush bag_001 (OSS not configured -> upload fails silently, local deleted)
        logger.flush(key="bag_001")

        d = _log_dir(tmp_path)
        assert not os.path.exists(os.path.join(d, "bag_001.log"))
        assert os.path.exists(os.path.join(d, "bag_002.log"))


# ---- 10.3 Flush fail still deletes local ----

class TestE2EFlushFail:
    def test_flush_oss_fail_still_deletes_local(self, monkeypatch, tmp_path):
        _set_ctx(monkeypatch)
        from hello_datap_component_base import logger
        logger.init(role="worker")
        logger.info(key="bag_fail", msg="data")

        d = _log_dir(tmp_path)
        assert os.path.exists(os.path.join(d, "bag_fail.log"))

        # OSS not configured -> upload will fail -> local should still be deleted
        logger.flush(key="bag_fail")
        assert not os.path.exists(os.path.join(d, "bag_fail.log"))


# ---- 10.4 Idempotent flush ----

class TestE2EIdempotent:
    def test_flush_multiple_times_no_error(self, monkeypatch, tmp_path):
        _set_ctx(monkeypatch)
        from hello_datap_component_base import logger
        logger.init(role="worker")
        logger.info(key="bag_idem", msg="x")
        for _ in range(5):
            logger.flush(key="bag_idem")  # should not raise


# ---- 10.5 Worker default ----

class TestE2EWorkerDefault:
    def test_worker_no_key_writes_default(self, monkeypatch, tmp_path, capsys):
        _set_ctx(monkeypatch)
        from hello_datap_component_base import logger
        logger.init(role="worker")
        logger.info(msg="no key 1")
        logger.info(msg="no key 2")

        d = _log_dir(tmp_path)
        default_path = os.path.join(d, "worker_default.log")
        assert os.path.exists(default_path)
        with open(default_path) as f:
            lines = f.readlines()
        assert len(lines) == 2

        # WARN should appear in stderr (only once)
        captured = capsys.readouterr()
        assert "worker_default" in captured.err or "worker_default" in captured.out
