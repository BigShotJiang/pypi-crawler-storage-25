"""Unit tests for LogRouter (Task 5.5)."""

import os
import tempfile
import threading

from hello_datap_component_base.logger import LogRouter


def test_get_or_create_same_key_returns_same_instance():
    with tempfile.TemporaryDirectory() as tmpdir:
        router = LogRouter()
        s1 = router.get_or_create("k1", tmpdir, "k1.log")
        s2 = router.get_or_create("k1", tmpdir, "k1.log")
        assert s1 is s2


def test_concurrent_get_or_create_same_key():
    """Multiple threads calling get_or_create for same key get same sink."""
    with tempfile.TemporaryDirectory() as tmpdir:
        router = LogRouter()
        results = []
        barrier = threading.Barrier(50)

        def worker():
            barrier.wait()
            sink = router.get_or_create("shared", tmpdir, "shared.log")
            results.append(id(sink))

        threads = [threading.Thread(target=worker) for _ in range(50)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(set(results)) == 1, "all threads should get same sink"


def test_pop_then_get_or_create_returns_new():
    with tempfile.TemporaryDirectory() as tmpdir:
        router = LogRouter()
        s1 = router.get_or_create("k1", tmpdir, "k1.log")
        popped = router.pop("k1")
        assert popped is s1
        s2 = router.get_or_create("k1", tmpdir, "k1.log")
        assert s2 is not s1


def test_pop_nonexistent_returns_none():
    router = LogRouter()
    assert router.pop("nope") is None


def test_drain_returns_all_and_empties():
    with tempfile.TemporaryDirectory() as tmpdir:
        router = LogRouter()
        router.get_or_create("a", tmpdir, "a.log")
        router.get_or_create("b", tmpdir, "b.log")
        router.get_or_create(None, tmpdir, "header.log")
        items = router.drain()
        assert len(items) == 3
        assert router.is_empty()


def test_drain_empty_router():
    router = LogRouter()
    assert router.drain() == []
    assert router.is_empty()
