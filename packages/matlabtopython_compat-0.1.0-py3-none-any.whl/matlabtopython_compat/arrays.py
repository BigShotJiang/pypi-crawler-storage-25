"""
Array helpers for converted MATLAB code.

Two common MATLAB patterns that don't have a clean one-liner equivalent
in plain numpy:

1. `X(:)` — column-major flatten. numpy's `.flatten()` defaults to
   row-major, which gives different element order. `flatten_fortran`
   forces `order='F'` so converted code matches MATLAB semantics.

2. `[sorted, idx] = sort(X)` — returns BOTH the sorted values and the
   original indices. numpy splits these into `np.sort` and `np.argsort`;
   `sort_with_index` returns the pair in one call.
"""

from __future__ import annotations
from typing import Tuple

try:
    import numpy as np
except ImportError:  # pragma: no cover — numpy is a hard dep
    raise


def flatten_fortran(a):
    """MATLAB `A(:)` — flatten in column-major (Fortran) order."""
    return np.asarray(a).flatten(order="F")


def sort_with_index(a, axis: int = -1, descending: bool = False) -> Tuple:
    """
    MATLAB `[sorted, idx] = sort(X)` — returns (sorted_values, indices).
    indices are 0-based (numpy convention); use +1 if you're porting a
    loop that literally iterates 1..N.
    """
    arr = np.asarray(a)
    idx = np.argsort(arr, axis=axis)
    if descending:
        idx = np.flip(idx, axis=axis)
    sorted_vals = np.take_along_axis(arr, idx, axis=axis) if arr.ndim > 0 else arr[idx]
    return sorted_vals, idx
