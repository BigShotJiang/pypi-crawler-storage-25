"""
MATLAB compatibility helpers for Python code converted by matlabtopython.com.

When the matlabtopython converter emits a construct that has no clean
numpy/scipy equivalent, it imports a helper from this package. Everything
here is a small, well-documented shim — no hidden behavior.

Install:
    pip install matlabtopython-compat

Typical import block the converter emits:
    from matlabtopython_compat import CellArray, Struct, sprintf, tic, toc
"""

from .cell_array import CellArray
from .struct import Struct
from .format import sprintf, fprintf
from .timing import tic, toc
from .arrays import flatten_fortran, sort_with_index

__all__ = [
    "CellArray",
    "Struct",
    "sprintf",
    "fprintf",
    "tic",
    "toc",
    "flatten_fortran",
    "sort_with_index",
]

__version__ = "0.1.0"
