"""rgbd_pd_viewer — Open3D GUI viewer for RGB-D frames and back-projected point clouds."""

from .viewer import (
    PointCloudApp,
    build_o3d_pointcloud,
    crop_and_resize,
    get_sorted_frame_pairs,
    load_frame,
)

__version__ = "0.1.0"

__all__ = [
    "PointCloudApp",
    "build_o3d_pointcloud",
    "crop_and_resize",
    "get_sorted_frame_pairs",
    "load_frame",
    "__version__",
]
