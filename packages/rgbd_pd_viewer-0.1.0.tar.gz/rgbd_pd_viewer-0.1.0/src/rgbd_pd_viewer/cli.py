"""Command-line entry point: `rgbd-pd-viewer`.

Two usage modes
---------------

1. Pass everything on the command line (single frame):

       rgbd-pd-viewer RGB DEPTH [INTRINSICS]

   The positional order is fixed:
       RGB         path to the RGB image  (.jpg / .png / .bmp / .tiff)
       DEPTH       path to the depth file (.npy / .npz)
       INTRINSICS  pinhole intrinsics as fx,fy,cx,cy  (four floats,
                   comma-separated, no spaces, in pixels, in that exact order).
                   Optional — defaults to 640,640,320,240.

   Example:
       rgbd-pd-viewer color.png depth.npy 640,640,320,240

2. Launch the GUI empty and pick files from inside:

       rgbd-pd-viewer
       rgbd-pd-viewer --intrinsics 640,640,320,240    # set intrinsics up-front

   then click 'Load Primary RGBD…' in the sidebar to navigate your local
   filesystem and choose the depth + RGB. Intrinsics can also be edited
   live in the sidebar (Apply Intrinsics).

Directory mode (still available for multi-frame sequences):

       rgbd-pd-viewer --depth-dir D --rgb-dir R \
                      [--intrinsics fx,fy,cx,cy] \
                      [--depth-suffix _480_640.npy] [--rgb-suffix .jpg]
"""

import argparse
import os
import sys
from typing import Optional, Tuple


INTRINSICS_HELP = (
    "Camera intrinsics as four comma-separated floats: fx,fy,cx,cy "
    "(pixels, in that exact order). Default: 640,640,320,240."
)
DEFAULT_INTRINSICS = (640.0, 640.0, 320.0, 240.0)


def _parse_intrinsics(s: Optional[str]) -> Tuple[float, float, float, float]:
    if s is None:
        return DEFAULT_INTRINSICS
    parts = [t.strip() for t in s.split(",")]
    if len(parts) != 4:
        raise argparse.ArgumentTypeError(
            f"intrinsics must be 'fx,fy,cx,cy' (4 floats), got: {s!r}"
        )
    try:
        vals = tuple(float(p) for p in parts)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"intrinsics must be 4 floats: {exc}"
        ) from None
    return vals  # type: ignore[return-value]


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="rgbd-pd-viewer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "Open3D GUI viewer for RGB-D frames. Back-projects depth + RGB to a "
            "coloured point cloud with point picking and Robot Base Marker."
        ),
        epilog=(
            "Modes:\n"
            "  rgbd-pd-viewer RGB DEPTH [fx,fy,cx,cy]    single frame, all from CLI\n"
            "  rgbd-pd-viewer                            launch empty UI; pick files inside\n"
            "  rgbd-pd-viewer --depth-dir D --rgb-dir R  multi-frame sequence\n"
        ),
    )

    # Positional (mode 1)
    p.add_argument("rgb", nargs="?", default=None,
                   help="path to RGB image (.jpg/.png/.bmp/.tiff)")
    p.add_argument("depth", nargs="?", default=None,
                   help="path to depth file (.npy/.npz)")
    p.add_argument("intrinsics", nargs="?", default=None,
                   help=INTRINSICS_HELP)

    # Flag form of intrinsics — useful with directory mode or UI-only mode
    p.add_argument("--intrinsics", dest="intrinsics_flag", default=None,
                   help=INTRINSICS_HELP)

    # Directory mode
    dgrp = p.add_argument_group("directory mode (multi-frame)")
    dgrp.add_argument("--depth-dir", default=None,
                      help="directory of depth files")
    dgrp.add_argument("--rgb-dir", default=None,
                      help="directory of RGB images")
    dgrp.add_argument("--depth-suffix", default="_480_640.npy",
                      help="suffix to match depth files (default: %(default)s)")
    dgrp.add_argument("--rgb-suffix", default=".jpg",
                      help="suffix to match RGB files (default: %(default)s)")

    # Rendering
    rgrp = p.add_argument_group("rendering")
    rgrp.add_argument("--depth-scale", type=float, default=1.0,
                      help="multiplier applied to raw depth values "
                           "(e.g. 0.001 for RealSense uint16 mm). Default: %(default)s")
    rgrp.add_argument("--max-depth", type=float, default=10.0,
                      help="clip points with Z >= this value (metres). "
                           "Default: %(default)s")
    rgrp.add_argument("--max-points", type=int, default=None,
                      help="uniform-stride subsample cap; omit to keep all points")

    # Optional calibration
    cgrp = p.add_argument_group("optional calibration")
    cgrp.add_argument("--t-wc-init", default=None,
                      help="JSON saved by 'Save T_wc to JSON…'; pre-populates "
                           "the Robot Base Marker on launch")
    return p


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)

    # Resolve intrinsics: positional takes precedence over --intrinsics flag.
    intr_src = args.intrinsics if args.intrinsics is not None else args.intrinsics_flag
    try:
        fx, fy, cx, cy = _parse_intrinsics(intr_src)
    except argparse.ArgumentTypeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    has_positional = (args.rgb is not None) or (args.depth is not None)
    has_dir        = (args.depth_dir is not None) or (args.rgb_dir is not None)

    if has_positional and has_dir:
        print("error: cannot mix positional RGB/DEPTH with --depth-dir/--rgb-dir.",
              file=sys.stderr)
        return 2

    pairs = []

    if has_positional:
        if args.rgb is None or args.depth is None:
            print("error: positional mode needs BOTH 'RGB DEPTH' (in that order).",
                  file=sys.stderr)
            return 2
        if not os.path.isfile(args.rgb):
            print(f"error: RGB file not found: {args.rgb}", file=sys.stderr)
            return 1
        if not os.path.isfile(args.depth):
            print(f"error: depth file not found: {args.depth}", file=sys.stderr)
            return 1
        pairs = [(args.depth, args.rgb)]

    elif has_dir:
        if args.depth_dir is None or args.rgb_dir is None:
            print("error: --depth-dir and --rgb-dir must be given together.",
                  file=sys.stderr)
            return 2
        if not os.path.isdir(args.depth_dir):
            print(f"error: depth dir not found: {args.depth_dir}", file=sys.stderr)
            return 1
        if not os.path.isdir(args.rgb_dir):
            print(f"error: RGB dir not found: {args.rgb_dir}", file=sys.stderr)
            return 1
        from .viewer import get_sorted_frame_pairs
        pairs = get_sorted_frame_pairs(
            args.depth_dir, args.rgb_dir,
            depth_suffix=args.depth_suffix, rgb_suffix=args.rgb_suffix,
        )
        if not pairs:
            print(
                "error: no matched depth/RGB pairs found. "
                f"Looked for *{args.depth_suffix} in {args.depth_dir} "
                f"with matching *{args.rgb_suffix} in {args.rgb_dir}.",
                file=sys.stderr,
            )
            return 1
        print(f"Loaded {len(pairs)} frame pair(s).")

    else:
        print("No source provided — opening empty UI. "
              "Click 'Load Primary RGBD…' in the sidebar to choose files.")

    # Import lazily so `--help` doesn't pay the open3d import cost.
    from .viewer import PointCloudApp
    app = PointCloudApp(
        pairs=pairs,
        fx=fx, fy=fy, cx=cx, cy=cy,
        depth_scale=args.depth_scale,
        max_depth=args.max_depth,
        max_points=args.max_points,
    )

    if args.t_wc_init:
        app.load_default_T_wc(args.t_wc_init)

    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
