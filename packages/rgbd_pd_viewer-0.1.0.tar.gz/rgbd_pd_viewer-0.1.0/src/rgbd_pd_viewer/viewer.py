"""
Point cloud viewer — depth + RGB → Open3D GUI (proper depth rendering).

Controls:
    Prev / Next               switch frames
    Frame number input + Go   jump to any frame
    Grid: OFF/ON              show / hide XYZ coordinate axes
    Azimuth / Elevation / Distance sliders  rotate without mouse
    Mouse left-drag           rotate
    Mouse scroll              zoom
    Mouse right-drag          pan
    Shift + Left-click        pick a point and read its camera-frame XYZ
    Robot Base Marker         place + nudge a sphere onto the robot base,
                              then save T_wc / T_cw to JSON
"""

import os
import glob
import numpy as np
from PIL import Image
import pathlib

import open3d as o3d
import open3d.visualization.gui      as gui
import open3d.visualization.rendering as rendering


# ---------------------------------------------------------------------------
# Generic crop-then-resize loader  (importable by other modules)
# ---------------------------------------------------------------------------

def crop_and_resize(source, target_h: int = 480, target_w: int = 640):
    """
    Load an image or depth map, crop to the target aspect ratio, then resize.
    Never stretches — always crop first, reshape second.

    Args:
        source   : file path (.jpg/.png/.npy/.npz) OR numpy array (H,W)/(H,W,3).
        target_h : target height (default 480)
        target_w : target width  (default 640)

    Returns:
        RGB image  → (target_h, target_w, 3) uint8
        Depth map  → (target_h, target_w)    float32

    Crop rule:
        input too wide  →  crop left & right  (centre crop)
        input too tall  →  crop top  & bottom (centre crop)
    """
    if not isinstance(source, np.ndarray):
        path   = pathlib.Path(source)
        suffix = path.suffix.lower()
        if suffix == ".npy":
            arr = np.load(str(path)).astype(np.float32)
            if arr.ndim == 3:
                arr = arr[:, :, 0]
            is_depth = True
        elif suffix == ".npz":
            npz = np.load(str(path))
            key = "depth" if "depth" in npz else npz.files[0]
            arr = npz[key].astype(np.float32)
            if arr.ndim == 3:
                arr = arr[:, :, 0]
            is_depth = True
        elif suffix in (".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif"):
            arr = np.array(Image.open(str(path)).convert("RGB"))
            is_depth = False
        else:
            raise ValueError(f"Unsupported file type: {suffix}")
    else:
        arr      = source
        is_depth = (arr.ndim == 2)

    oh, ow    = arr.shape[:2]
    target_ar = target_w / target_h
    input_ar  = ow / oh

    if abs(input_ar - target_ar) > 1e-4:
        if input_ar > target_ar:
            new_w = int(round(oh * target_ar))
            sx    = (ow - new_w) // 2
            arr   = arr[:, sx: sx + new_w]
        else:
            new_h = int(round(ow / target_ar))
            sy    = (oh - new_h) // 2
            arr   = arr[sy: sy + new_h, :]

    ch, cw = arr.shape[:2]
    if (ch, cw) != (target_h, target_w):
        mode   = "F" if is_depth else "RGB"
        pil    = Image.fromarray(arr, mode=mode)
        pil    = pil.resize((target_w, target_h), Image.BILINEAR)
        arr    = np.array(pil)

    return arr.astype(np.float32) if is_depth else arr.astype(np.uint8)


# ---------------------------------------------------------------------------
# Point cloud helpers (generic)
# ---------------------------------------------------------------------------

def build_o3d_pointcloud(
    depth: np.ndarray,
    rgb:   np.ndarray,
    fx: float, fy: float,
    cx: float, cy: float,
    depth_scale: float = 1.0,
    max_depth:   float = 10.0,
    max_points:  int   = None,
) -> o3d.geometry.PointCloud:
    """
    Back-project depth + RGB into an Open3D PointCloud with per-point colours.

    Args:
        depth       : (H, W) float32, depth in metres (after scaling)
        rgb         : (H, W, 3) uint8
        max_points  : uniform-stride subsample cap; None = keep all points
    """
    H, W = depth.shape
    Z    = depth.astype(np.float64) * depth_scale

    u  = np.arange(W, dtype=np.float64)
    v  = np.arange(H, dtype=np.float64)
    uu, vv = np.meshgrid(u, v)

    mask = (Z > 0) & (Z < max_depth)
    xyz  = np.stack([(uu - cx) * Z / fx,
                     (vv - cy) * Z / fy,
                     Z], axis=-1)[mask]
    col  = (rgb[mask].astype(np.float32) / 255.0
            if rgb.dtype == np.uint8 else rgb[mask].astype(np.float32))

    if max_points and len(xyz) > max_points:
        stride = max(1, len(xyz) // max_points)
        xyz = xyz[::stride]
        col = col[::stride]

    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(xyz)
    pcd.colors = o3d.utility.Vector3dVector(col)
    return pcd


# ---------------------------------------------------------------------------
# Data loading helpers
# ---------------------------------------------------------------------------

def load_frame(depth_path: str, rgb_path: str):
    """Return (depth (H,W) float32, rgb (H,W,3) uint8) after crop+resize."""
    depth = crop_and_resize(depth_path)
    rgb   = crop_and_resize(rgb_path)
    return depth, rgb


def get_sorted_frame_pairs(
    depth_dir:    str,
    rgb_dir:      str,
    depth_suffix: str = "_480_640.npy",
    rgb_suffix:   str = ".jpg",
):
    """
    Pair depth files with RGB files by matching the frame_id stem.

        depth: <frame_id><depth_suffix>
        rgb  : <frame_id><rgb_suffix>
    """
    depth_files = sorted(glob.glob(os.path.join(depth_dir, f"*{depth_suffix}")))
    pairs = []
    for dp in depth_files:
        frame_id = os.path.basename(dp).replace(depth_suffix, "")
        rp = os.path.join(rgb_dir, frame_id + rgb_suffix)
        if os.path.exists(rp):
            pairs.append((dp, rp))
        else:
            print(f"[warning] no RGB match for {os.path.basename(dp)}, skipped.")
    return pairs


# ---------------------------------------------------------------------------
# Open3D GUI Application
# ---------------------------------------------------------------------------

class PointCloudApp:
    _PCD  = "pcd"
    _GRID = "grid"
    _CAM  = "camera_marker"

    def __init__(self, pairs=None, fx=640.0, fy=640.0, cx=320.0, cy=240.0,
                 depth_scale=1.0, max_depth=10.0, max_points=None):
        self.pairs       = list(pairs) if pairs else []
        self.N           = len(self.pairs)
        self.fx, self.fy = fx, fy
        self.cx, self.cy = cx, cy
        self.depth_scale = depth_scale
        self.max_depth   = max_depth
        self.max_points  = max_points
        self.idx              = 0
        self.show_grid        = False
        self.show_cam         = True
        self._center          = np.zeros(3)
        self._extra_pcd_idx   = 0
        self._pending_depth   = None
        self._extra_depths    = {}
        self._extra_rgbs      = {}
        self._last_pick_world = None
        self._base_pos        = None
        self._base_R_cw       = np.eye(3, dtype=np.float64)

        app = gui.Application.instance
        app.initialize()

        self.win = app.create_window("Point Cloud Viewer", 1440, 860)
        em = self.win.theme.font_size
        sep = int(em * 0.4)

        self._scene = gui.SceneWidget()
        self._scene.scene = rendering.Open3DScene(self.win.renderer)
        self._scene.scene.set_background([0.06, 0.06, 0.10, 1.0])
        self._scene.set_on_mouse(self._on_mouse_widget)

        self._mat            = rendering.MaterialRecord()
        self._mat.shader     = "defaultUnlit"
        self._mat.point_size = 2.5

        SIDEBAR_W = int(em * 20)
        mg = gui.Margins(int(em * 0.8), int(em * 0.8),
                         int(em * 0.8), int(em * 0.8))
        panel = gui.Vert(sep, mg)

        panel.add_child(self._label("Point Cloud Viewer",
                                    bold=True, color=(0.91, 0.27, 0.38)))
        panel.add_child(gui.Label(""))

        panel.add_child(self._label("Active Sources", color=(0.55, 0.85, 0.55)))

        def _trimdir(p, n=34):
            d = os.path.dirname(p)
            return d if len(d) <= n else "..." + d[-(n-3):]
        self._trimdir = _trimdir
        if self.N > 0:
            d0, r0 = self.pairs[0]
            primary_text = (f"[Primary]\n  D: {_trimdir(d0)}\n  R: {_trimdir(r0)}")
        else:
            primary_text = "[Primary]\n  (none — click Load Primary RGBD…)"
        self._lbl_primary = self._label(primary_text, color=(0.75, 0.75, 0.75))
        panel.add_child(self._lbl_primary)

        cb_primary = gui.Checkbox("Show Primary")
        cb_primary.checked = True
        def on_show_primary(checked):
            self._scene.scene.show_geometry(self._PCD, checked)
        cb_primary.set_on_checked(on_show_primary)
        panel.add_child(cb_primary)

        btn_load_primary = gui.Button("Load Primary RGBD…")
        btn_load_primary.set_on_clicked(self._load_primary_dialog)
        panel.add_child(btn_load_primary)

        frame_text = (f"Frame 0000 / {self.N - 1}" if self.N > 0
                      else "Frame —  /  —")
        self._lbl_frame = self._label(frame_text, color=(0.65, 0.65, 0.65))
        panel.add_child(self._lbl_frame)
        panel.add_child(gui.Label(""))

        row = gui.Horiz(sep)
        b_prev = gui.Button("<  Prev");  b_prev.set_on_clicked(self._go_prev)
        b_next = gui.Button("Next  >");  b_next.set_on_clicked(self._go_next)
        row.add_stretch(); row.add_child(b_prev)
        row.add_child(b_next); row.add_stretch()
        panel.add_child(row)
        panel.add_child(gui.Label(""))

        panel.add_child(gui.Label("Jump to frame:"))
        row2 = gui.Horiz(sep)
        self._num = gui.NumberEdit(gui.NumberEdit.INT)
        self._num.int_value = 0
        self._num.set_limits(0, max(0, self.N - 1))
        b_go = gui.Button("Go");  b_go.set_on_clicked(self._go_jump)
        row2.add_child(self._num); row2.add_child(b_go)
        panel.add_child(row2)
        panel.add_child(gui.Label(""))

        # ── Camera Intrinsics ────────────────────────────────────────────────
        panel.add_child(self._label("--- Camera Intrinsics ---",
                                    color=(0.65, 0.65, 0.65)))
        panel.add_child(self._label(
            "Pinhole, in pixels, after crop+resize\nto 480 x 640.",
            color=(0.4, 0.4, 0.4)))

        def _intr_field(name, init):
            row = gui.Horiz(sep)
            row.add_child(gui.Label(f"  {name}:"))
            ed = gui.NumberEdit(gui.NumberEdit.DOUBLE)
            ed.double_value = float(init)
            ed.set_limits(0.1, 1e6)
            row.add_child(ed)
            panel.add_child(row)
            return ed

        self._ed_fx = _intr_field("fx", self.fx)
        self._ed_fy = _intr_field("fy", self.fy)
        self._ed_cx = _intr_field("cx", self.cx)
        self._ed_cy = _intr_field("cy", self.cy)
        btn_intr = gui.Button("Apply Intrinsics")
        btn_intr.set_on_clicked(self._apply_intrinsics)
        panel.add_child(btn_intr)
        panel.add_child(gui.Label(""))

        self._btn_grid = gui.Button("Grid: OFF")
        self._btn_grid.set_on_clicked(self._toggle_grid)
        panel.add_child(self._btn_grid)

        self._btn_cam = gui.Button("Camera Marker: ON")
        self._btn_cam.set_on_clicked(self._toggle_cam_marker)
        panel.add_child(self._btn_cam)
        panel.add_child(gui.Label(""))

        panel.add_child(self._label("--- Point Picker ---",
                                    color=(0.65, 0.65, 0.65)))
        panel.add_child(self._label(
            "Shift + Left-click on a point\nto read its depth (Z, metres).",
            color=(0.4, 0.4, 0.4)))
        self._lbl_pick = self._label(
            "Pick: (none yet)", color=(0.85, 0.85, 0.55))
        panel.add_child(self._lbl_pick)
        panel.add_child(gui.Label(""))

        panel.add_child(self._label("--- Robot Base Marker ---",
                                    color=(0.65, 0.65, 0.65)))
        panel.add_child(self._label(
            "Place a sphere at the picked point,\n"
            "then nudge it onto the robot base.\n"
            "Save = robot-base position in camera\n"
            "frame (T_cw translation).",
            color=(0.4, 0.4, 0.4)))

        self._lbl_base_pos = self._label(
            "Sphere: (none)", color=(1.0, 0.4, 0.85))
        panel.add_child(self._lbl_base_pos)

        btn_place = gui.Button("Place sphere at last pick")
        btn_place.set_on_clicked(self._base_place_at_pick)
        panel.add_child(btn_place)

        panel.add_child(gui.Label("Nudge step (m):"))
        self._base_step_input = gui.NumberEdit(gui.NumberEdit.DOUBLE)
        self._base_step_input.double_value = 0.01
        self._base_step_input.set_limits(0.0001, 1.0)
        panel.add_child(self._base_step_input)

        for axis_idx, axis_name in [(0, "X"), (1, "Y"), (2, "Z")]:
            row = gui.Horiz(sep)
            bn = gui.Button(f"{axis_name} -")
            bn.set_on_clicked(lambda a=axis_idx: self._base_nudge(a, -1))
            row.add_child(bn)
            bp = gui.Button(f"{axis_name} +")
            bp.set_on_clicked(lambda a=axis_idx: self._base_nudge(a, +1))
            row.add_child(bp)
            panel.add_child(row)

        panel.add_child(gui.Label(""))
        panel.add_child(self._label("Rotation step (deg):", color=(0.7, 0.7, 0.7)))
        self._base_rot_step = gui.NumberEdit(gui.NumberEdit.DOUBLE)
        self._base_rot_step.double_value = 5.0
        self._base_rot_step.set_limits(0.1, 90.0)
        panel.add_child(self._base_rot_step)

        for axis_idx, axis_name in [(0, "Rx"), (1, "Ry"), (2, "Rz")]:
            row = gui.Horiz(sep)
            bn = gui.Button(f"{axis_name} -")
            bn.set_on_clicked(lambda a=axis_idx: self._base_rotate(a, -1))
            row.add_child(bn)
            bp = gui.Button(f"{axis_name} +")
            bp.set_on_clicked(lambda a=axis_idx: self._base_rotate(a, +1))
            row.add_child(bp)
            panel.add_child(row)

        btn_reset_rot = gui.Button("Reset rotation (identity)")
        btn_reset_rot.set_on_clicked(self._base_reset_rotation)
        panel.add_child(btn_reset_rot)
        panel.add_child(gui.Label(""))

        btn_save_base = gui.Button("Save T_wc to JSON…")
        btn_save_base.set_on_clicked(self._base_save_dialog)
        panel.add_child(btn_save_base)
        panel.add_child(gui.Label(""))

        panel.add_child(self._label("--- Rotation Controls ---",
                                    color=(0.65, 0.65, 0.65)))
        panel.add_child(gui.Label(
            "Drag sliders to rotate.\nMouse also works freely."))
        panel.add_child(gui.Label(""))

        panel.add_child(gui.Label("Azimuth  (H-rotate)  0°–360°"))
        self._sl_az = gui.Slider(gui.Slider.DOUBLE)
        self._sl_az.set_limits(0, 360);  self._sl_az.double_value = 45.0
        self._sl_az.set_on_value_changed(lambda _: self._apply_camera())
        panel.add_child(self._sl_az)

        panel.add_child(gui.Label("Elevation  (V-angle)  −80°–80°"))
        self._sl_el = gui.Slider(gui.Slider.DOUBLE)
        self._sl_el.set_limits(-80, 80);  self._sl_el.double_value = 25.0
        self._sl_el.set_on_value_changed(lambda _: self._apply_camera())
        panel.add_child(self._sl_el)

        panel.add_child(gui.Label("Distance  (zoom)  0.3×–6×"))
        self._sl_dist = gui.Slider(gui.Slider.DOUBLE)
        self._sl_dist.set_limits(0.3, 6.0);  self._sl_dist.double_value = 2.0
        self._sl_dist.set_on_value_changed(lambda _: self._apply_camera())
        panel.add_child(self._sl_dist)

        panel.add_child(gui.Label(""))
        panel.add_child(self._label(
            "Mouse:\n  left-drag   rotate\n  scroll      zoom\n  right-drag  pan",
            color=(0.4, 0.4, 0.4)))

        panel.add_child(gui.Label(""))
        panel.add_child(self._label("--- Add Extra Sources ---",
                                    color=(0.65, 0.65, 0.65)))
        panel.add_child(self._label(
            "Extra PCDs render together with the\n"
            "primary sequence in the same scene.",
            color=(0.4, 0.4, 0.4)))
        panel.add_child(gui.Label(""))

        btn_add = gui.Button("+ Add Source (depth + RGB)")
        btn_add.set_on_clicked(self._add_source_dialog)
        panel.add_child(btn_add)
        panel.add_child(gui.Label(""))

        self._sources_list = gui.ScrollableVert(sep)
        panel.add_child(self._sources_list)

        self.win.add_child(self._scene)
        self.win.add_child(panel)

        def on_layout(_ctx):
            r  = self.win.content_rect
            panel.frame  = gui.Rect(r.x, r.y, SIDEBAR_W, r.height)
            self._scene.frame = gui.Rect(
                r.x + SIDEBAR_W, r.y, r.width - SIDEBAR_W, r.height)

        self.win.set_on_layout(on_layout)

        if self.N > 0:
            self._load_frame(0, init_camera=True)
        else:
            # No primary loaded — set up a sane default camera so the empty
            # scene is still interactable. Will be re-initialised on the first
            # Load Primary RGBD….
            self._center = np.array([0.0, 0.0, 1.0])
            self._draw_camera_marker()

    @staticmethod
    def _label(text, bold=False, color=None):
        lbl = gui.Label(text)
        if color:
            lbl.text_color = gui.Color(*color)
        return lbl

    def _build_pcd(self, idx) -> o3d.geometry.PointCloud:
        depth, rgb = load_frame(*self.pairs[idx])
        return build_o3d_pointcloud(
            depth, rgb,
            fx=self.fx, fy=self.fy, cx=self.cx, cy=self.cy,
            depth_scale=self.depth_scale,
            max_depth=self.max_depth,
            max_points=self.max_points,
        )

    def _load_frame(self, idx, init_camera=False):
        self.idx = idx
        sc = self._scene.scene

        if sc.has_geometry(self._PCD):
            sc.remove_geometry(self._PCD)

        pcd = self._build_pcd(idx)
        sc.add_geometry(self._PCD, pcd, self._mat)

        dp, rp = self.pairs[idx]
        def _short(p, n=32):
            b = os.path.basename(p)
            return b if len(b) <= n else "..." + b[-(n-3):]
        self._lbl_frame.text = (
            f"Frame {idx:04d} / {self.N - 1}\n"
            f"  D: {_short(dp)}\n"
            f"  R: {_short(rp)}"
        )
        dp = os.path.basename(dp)
        self.win.set_needs_layout()

        if init_camera:
            bounds = sc.bounding_box
            self._scene.setup_camera(60.0, bounds, bounds.get_center())
            self._center = np.asarray(bounds.get_center())
            extent    = np.asarray(bounds.get_extent())
            init_dist = float(np.linalg.norm(extent)) * 0.75
            init_dist = max(0.3, init_dist)
            self._sl_dist.double_value = init_dist
            self._sl_dist.set_limits(max(0.05, init_dist * 0.1),
                                     init_dist * 5.0)

        self._apply_camera()
        self._draw_camera_marker()

        print(f"[{idx:>4d}/{self.N-1}]  {dp}")

    def _apply_camera(self):
        az = np.radians(self._sl_az.double_value)
        el = np.radians(self._sl_el.double_value)
        d  = self._sl_dist.double_value
        c  = self._center
        eye = c + np.array([d * np.cos(el) * np.cos(az),
                             d * np.cos(el) * np.sin(az),
                             d * np.sin(el)])
        up  = np.array([0.0, 0.0, 1.0])
        self._scene.look_at(c, eye, up)

    def _draw_camera_marker(self):
        sc = self._scene.scene
        if not self.show_cam:
            return

        origin = np.zeros(3)

        scene_depth = float(np.linalg.norm(self._center))
        if scene_depth < 0.1:
            scene_depth = 1.0
        near = scene_depth * 0.05
        far  = scene_depth * 0.20

        W, H = 640.0, 480.0
        fx, fy = self.fx, self.fy
        cx, cy = self.cx, self.cy
        corners_uv = [(-0.5, -0.5), (W - 0.5, -0.5),
                      (W - 0.5, H - 0.5), (-0.5, H - 0.5)]
        dirs = [np.array([(u - cx) / fx, (v - cy) / fy, 1.0])
                for u, v in corners_uv]
        dirs = [d / np.linalg.norm(d) for d in dirs]

        near_pts = [d * near for d in dirs]
        far_pts  = [d * far  for d in dirs]

        pts = [origin] + near_pts + far_pts
        lines = (
            [[0, 1], [0, 2], [0, 3], [0, 4]]
            + [[1, 2], [2, 3], [3, 4], [4, 1]]
            + [[5, 6], [6, 7], [7, 8], [8, 5]]
            + [[1, 5], [2, 6], [3, 7], [4, 8]]
        )
        yellow = [1.0, 0.9, 0.0]
        colors = [yellow] * len(lines)

        frustum = o3d.geometry.LineSet()
        frustum.points = o3d.utility.Vector3dVector(pts)
        frustum.lines  = o3d.utility.Vector2iVector(lines)
        frustum.colors = o3d.utility.Vector3dVector(colors)

        r = scene_depth * 0.015
        sphere = o3d.geometry.TriangleMesh.create_sphere(radius=r)
        sphere.paint_uniform_color([1.0, 0.9, 0.0])
        sphere.compute_vertex_normals()

        mat_mesh = rendering.MaterialRecord()
        mat_mesh.shader = "defaultLit"

        mat_line = rendering.MaterialRecord()
        mat_line.shader = "unlitLine"
        mat_line.line_width = 1.5

        for name in (self._CAM, self._CAM + "_line"):
            if sc.has_geometry(name):
                sc.remove_geometry(name)

        sc.add_geometry(self._CAM,           sphere,  mat_mesh)
        sc.add_geometry(self._CAM + "_line", frustum, mat_line)

    def _on_mouse_widget(self, event):
        is_pick = (
            event.type == gui.MouseEvent.Type.BUTTON_DOWN
            and event.is_modifier_down(gui.KeyModifier.SHIFT)
        )
        if not is_pick:
            return gui.SceneWidget.EventCallbackResult.IGNORED

        frame = self._scene.frame
        rel_x = int(event.x - frame.x)
        rel_y = int(event.y - frame.y)

        def depth_callback(depth_image):
            depth_arr = np.asarray(depth_image)
            h, w = depth_arr.shape
            picked_xyz = None
            if not (0 <= rel_x < w and 0 <= rel_y < h):
                text = "Pick: out of view"
            else:
                d = float(depth_arr[rel_y, rel_x])
                if d >= 1.0:
                    text = (f"Pick @ pixel ({rel_x},{rel_y})\n"
                            "  (no point under cursor)")
                else:
                    world = self._scene.scene.camera.unproject(
                        event.x, event.y, d, frame.width, frame.height)
                    wx, wy, wz = float(world[0]), float(world[1]), float(world[2])
                    rng = float(np.sqrt(wx * wx + wy * wy + wz * wz))
                    picked_xyz = np.array([wx, wy, wz], dtype=np.float64)
                    text = (f"Pick @ pixel ({rel_x},{rel_y})\n"
                            f"  Camera XYZ:\n"
                            f"   ({wx:+.4f}, {wy:+.4f}, {wz:+.4f}) m\n"
                            f"  Depth (Z): {wz:.4f} m\n"
                            f"  Range:     {rng:.4f} m")

            def update_label():
                self._lbl_pick.text = text
                if picked_xyz is not None:
                    self._last_pick_world = picked_xyz
                self.win.set_needs_layout()
                print(f"[Pick] {text}")

            gui.Application.instance.post_to_main_thread(
                self.win, update_label)

        self._scene.scene.scene.render_to_depth_image(depth_callback)
        return gui.SceneWidget.EventCallbackResult.HANDLED

    _BASE_SPHERE = "robot_base_marker"
    _BASE_AXES   = "robot_base_axes"

    def _base_place_at_pick(self):
        if self._last_pick_world is None:
            print("[BaseMarker] No pick yet — Shift+click a point first.")
            return
        self._base_pos = self._last_pick_world.copy()
        self._draw_base_marker()
        self._update_base_label()

    def _base_nudge(self, axis: int, sign: int):
        if self._base_pos is None:
            print("[BaseMarker] Place the sphere first.")
            return
        step = float(self._base_step_input.double_value) * sign
        world_axis_in_cam = self._base_R_cw[:, axis]
        self._base_pos = self._base_pos + step * world_axis_in_cam
        self._draw_base_marker()
        self._update_base_label()

    def _base_rotate(self, axis: int, sign: int):
        if self._base_pos is None:
            print("[BaseMarker] Place the sphere first.")
            return
        deg = float(self._base_rot_step.double_value) * sign
        rad = np.deg2rad(deg)
        c, s = np.cos(rad), np.sin(rad)
        if axis == 0:
            R_local = np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
        elif axis == 1:
            R_local = np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
        else:
            R_local = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
        self._base_R_cw = self._base_R_cw @ R_local
        self._draw_base_marker()
        self._update_base_label()

    def _base_reset_rotation(self):
        self._base_R_cw = np.eye(3, dtype=np.float64)
        if self._base_pos is not None:
            self._draw_base_marker()
            self._update_base_label()

    def _draw_base_marker(self):
        sc = self._scene.scene
        if sc.has_geometry(self._BASE_SPHERE):
            sc.remove_geometry(self._BASE_SPHERE)
        sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.02)
        sphere.compute_vertex_normals()
        sphere.paint_uniform_color([1.0, 0.15, 0.7])
        sphere.translate(self._base_pos)
        mat_lit = rendering.MaterialRecord()
        mat_lit.shader = "defaultLit"
        sc.add_geometry(self._BASE_SPHERE, sphere, mat_lit)

        if sc.has_geometry(self._BASE_AXES):
            sc.remove_geometry(self._BASE_AXES)
        axes = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.15)
        axes.compute_vertex_normals()
        T = np.eye(4)
        T[:3, :3] = self._base_R_cw
        T[:3, 3]  = self._base_pos
        axes.transform(T)
        sc.add_geometry(self._BASE_AXES, axes, mat_lit)

    def _update_base_label(self):
        p = self._base_pos
        Xw, Yw, Zw = self._base_R_cw[:, 0], self._base_R_cw[:, 1], self._base_R_cw[:, 2]
        self._lbl_base_pos.text = (
            f"Sphere (camera frame):\n"
            f"  ({p[0]:+.4f}, {p[1]:+.4f}, {p[2]:+.4f}) m\n"
            f"World +X in cam: ({Xw[0]:+.2f}, {Xw[1]:+.2f}, {Xw[2]:+.2f})\n"
            f"World +Y in cam: ({Yw[0]:+.2f}, {Yw[1]:+.2f}, {Yw[2]:+.2f})\n"
            f"World +Z in cam: ({Zw[0]:+.2f}, {Zw[1]:+.2f}, {Zw[2]:+.2f})")
        self.win.set_needs_layout()

    def load_default_T_wc(self, path: str):
        """Initial-load helper: read T_wc JSON and pre-populate marker state."""
        if not (path and os.path.isfile(path)):
            return
        import json as _json
        try:
            d = _json.load(open(path))
        except Exception as e:
            print(f"[BaseMarker] could not load {path}: {e}")
            return
        if "robot_base_in_camera_xyz" in d:
            self._base_pos = np.array(d["robot_base_in_camera_xyz"], dtype=np.float64)
        elif "T_cw" in d:
            self._base_pos = np.array(d["T_cw"], dtype=np.float64)[:3, 3]
        else:
            return
        if "T_cw" in d:
            R_cw = np.array(d["T_cw"], dtype=np.float64)[:3, :3]
            if R_cw.shape == (3, 3):
                self._base_R_cw = R_cw
        self._draw_base_marker()
        self._update_base_label()
        print(f"[BaseMarker] auto-loaded {path}")
        print(f"             pos = {self._base_pos.tolist()}")
        print(f"             R_cw =\n{self._base_R_cw}")

    def _base_save_dialog(self):
        if self._base_pos is None:
            print("[BaseMarker] Nothing to save (place sphere first).")
            return
        dlg = gui.FileDialog(gui.FileDialog.SAVE, "Save T_wc JSON", self.win.theme)
        dlg.add_filter(".json", "JSON")
        dlg.set_on_done(self._base_save_done)
        dlg.set_on_cancel(lambda: self.win.close_dialog())
        self.win.show_dialog(dlg)

    def _base_save_done(self, path: str):
        self.win.close_dialog()
        if not path.endswith(".json"):
            path = path + ".json"
        p = self._base_pos
        R_cw = self._base_R_cw
        T_cw = np.eye(4)
        T_cw[:3, :3] = R_cw
        T_cw[:3, 3]  = p
        T_wc = np.linalg.inv(T_cw)
        rot_is_identity = bool(np.allclose(R_cw, np.eye(3)))
        out = {
            "robot_base_in_camera_xyz": p.tolist(),
            "T_cw": T_cw.tolist(),
            "T_wc": T_wc.tolist(),
            "R_cw": R_cw.tolist(),
            "rotation": ("identity (only translation set)" if rot_is_identity
                         else "manually adjusted via Rx/Ry/Rz buttons"),
            "convention": (
                "World origin = robot base. T_cw maps world→camera; "
                "T_cw[:3,:3] = R_cw (cols = world axes in camera frame); "
                "T_cw[:3,3] = robot-base position in camera frame. "
                "T_wc = inv(T_cw)."
            ),
            "source": "manual alignment via rgbd_pd_viewer Robot Base Marker",
        }
        import json as _json
        with open(path, "w") as f:
            _json.dump(out, f, indent=2)
        print(f"[BaseMarker] saved → {path}")
        print(f"             robot_base_in_camera_xyz = ({p[0]:+.4f}, {p[1]:+.4f}, {p[2]:+.4f}) m")
        print(f"             R_cw =\n{R_cw}")

    def _go_prev(self):
        if self.N == 0:
            print("[Primary] No primary loaded — click 'Load Primary RGBD…' first.")
            return
        self._load_frame((self.idx - 1) % self.N)

    def _go_next(self):
        if self.N == 0:
            print("[Primary] No primary loaded — click 'Load Primary RGBD…' first.")
            return
        self._load_frame((self.idx + 1) % self.N)

    def _go_jump(self):
        if self.N == 0:
            print("[Primary] No primary loaded — click 'Load Primary RGBD…' first.")
            return
        self._load_frame(int(self._num.int_value) % self.N)

    # ── Load Primary via in-app file dialog ──────────────────────────────────

    def _load_primary_dialog(self):
        """Two-step dialog: pick depth file, then matching RGB file.
        Replaces (or initialises) the primary single-frame source."""
        self._pending_depth = None

        def on_depth_done(depth_path):
            self._pending_depth = depth_path
            self.win.close_dialog()
            dlg2 = gui.FileDialog(gui.FileDialog.OPEN,
                                  "Step 2 – Select RGB image (primary)",
                                  self.win.theme)
            dlg2.add_filter(".jpg .jpeg .png .bmp",
                            "Image files (.jpg .jpeg .png .bmp)")
            dlg2.add_filter("", "All files")
            dlg2.set_path(os.path.dirname(depth_path))
            dlg2.set_on_cancel(lambda: self.win.close_dialog())
            dlg2.set_on_done(on_rgb_done)
            self.win.show_dialog(dlg2)

        def on_rgb_done(rgb_path):
            self.win.close_dialog()
            self._set_primary([(self._pending_depth, rgb_path)])

        dlg1 = gui.FileDialog(gui.FileDialog.OPEN,
                              "Step 1 – Select depth file (.npy / .npz)",
                              self.win.theme)
        dlg1.add_filter(".npy .npz", "Depth files (.npy .npz)")
        dlg1.add_filter("", "All files")
        dlg1.set_path(os.path.expanduser("~"))
        dlg1.set_on_cancel(lambda: self.win.close_dialog())
        dlg1.set_on_done(on_depth_done)
        self.win.show_dialog(dlg1)

    def _set_primary(self, pairs):
        """Replace the primary sequence with `pairs` and re-render."""
        if not pairs:
            return
        self.pairs = list(pairs)
        self.N     = len(self.pairs)
        self.idx   = 0
        self._num.set_limits(0, max(0, self.N - 1))
        self._num.int_value = 0
        d0, r0 = self.pairs[0]
        self._lbl_primary.text = (
            f"[Primary]\n  D: {self._trimdir(d0)}\n  R: {self._trimdir(r0)}"
        )
        self._load_frame(0, init_camera=True)

    # ── Apply edited intrinsics ──────────────────────────────────────────────

    def _apply_intrinsics(self):
        """Read fx/fy/cx/cy from sidebar fields and rebuild primary + extras."""
        try:
            self.fx = float(self._ed_fx.double_value)
            self.fy = float(self._ed_fy.double_value)
            self.cx = float(self._ed_cx.double_value)
            self.cy = float(self._ed_cy.double_value)
        except Exception as exc:
            self._show_error(f"Invalid intrinsics:\n{exc}")
            return

        if self.N > 0:
            self._load_frame(self.idx, init_camera=False)

        for geo_name, depth in list(self._extra_depths.items()):
            rgb = self._extra_rgbs.get(geo_name)
            if rgb is None:
                continue
            pcd = build_o3d_pointcloud(
                depth, rgb,
                self.fx, self.fy, self.cx, self.cy,
                self.depth_scale, self.max_depth, self.max_points,
            )
            sc = self._scene.scene
            if sc.has_geometry(geo_name):
                sc.remove_geometry(geo_name)
            sc.add_geometry(geo_name, pcd, self._mat)

        # Re-draw camera frustum (its shape depends on fx/fy/cx/cy)
        self._draw_camera_marker()
        print(f"[Intrinsics] fx={self.fx} fy={self.fy} cx={self.cx} cy={self.cy}")

    def _toggle_cam_marker(self):
        self.show_cam = not self.show_cam
        sc = self._scene.scene
        if not self.show_cam:
            for name in (self._CAM, self._CAM + "_line"):
                if sc.has_geometry(name):
                    sc.remove_geometry(name)
            self._btn_cam.text = "Camera Marker: OFF"
        else:
            self._draw_camera_marker()
            self._btn_cam.text = "Camera Marker: ON"
        self.win.set_needs_layout()

    def _toggle_grid(self):
        self.show_grid = not self.show_grid
        sc = self._scene.scene
        if self.show_grid:
            axes = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.3)
            mat  = rendering.MaterialRecord()
            mat.shader = "defaultLit"
            sc.add_geometry(self._GRID, axes, mat)
            self._btn_grid.text = "Grid: ON"
        else:
            if sc.has_geometry(self._GRID):
                sc.remove_geometry(self._GRID)
            self._btn_grid.text = "Grid: OFF"
        self.win.set_needs_layout()

    def _add_source_dialog(self):
        self._pending_depth = None

        def on_depth_done(depth_path):
            self._pending_depth = depth_path
            self.win.close_dialog()
            dlg2 = gui.FileDialog(gui.FileDialog.OPEN,
                                  "Step 2 – Select RGB image", self.win.theme)
            dlg2.add_filter(".jpg .jpeg .png .bmp",
                            "Image files (.jpg .jpeg .png .bmp)")
            dlg2.add_filter("", "All files")
            dlg2.set_path(os.path.dirname(depth_path))
            dlg2.set_on_cancel(lambda: self.win.close_dialog())
            dlg2.set_on_done(on_rgb_done)
            self.win.show_dialog(dlg2)

        def on_rgb_done(rgb_path):
            self.win.close_dialog()
            self._load_extra_source(self._pending_depth, rgb_path)

        dlg1 = gui.FileDialog(gui.FileDialog.OPEN,
                              "Step 1 – Select depth file (.npy / .npz)",
                              self.win.theme)
        dlg1.add_filter(".npy .npz", "Depth files (.npy .npz)")
        dlg1.add_filter("", "All files")
        dlg1.set_path(os.path.expanduser("~"))
        dlg1.set_on_cancel(lambda: self.win.close_dialog())
        dlg1.set_on_done(on_depth_done)
        self.win.show_dialog(dlg1)

    def _load_extra_source(self, depth_path, rgb_path, scale_a=1.0, scale_b=0.0):
        geo_name = f"extra_{self._extra_pcd_idx}"
        self._extra_pcd_idx += 1
        try:
            depth, rgb = load_frame(depth_path, rgb_path)
            self._extra_depths[geo_name] = depth
            self._extra_rgbs[geo_name]   = rgb
            depth_c = np.clip(depth * scale_a + scale_b, 0.0, None).astype(np.float32)
            pcd = build_o3d_pointcloud(
                depth_c, rgb,
                self.fx, self.fy, self.cx, self.cy,
                self.depth_scale, self.max_depth, self.max_points,
            )
            self._scene.scene.add_geometry(geo_name, pcd, self._mat)
            self._add_source_row(geo_name, depth_path, rgb_path, scale_a, scale_b)
            print(f"[Extra] added {geo_name}: A={scale_a} B={scale_b}  "
                  f"depth={depth_path}  rgb={rgb_path}")
        except Exception as exc:
            self._show_error(f"Failed to load source:\n{exc}")

    def _add_source_row(self, geo_name, depth_path, rgb_path,
                        init_a=1.0, init_b=0.0):
        em  = self.win.theme.font_size
        sep = int(em * 0.3)

        row = gui.Vert(sep)

        n = self._extra_pcd_idx
        row.add_child(self._label(f"[Extra {n}]", color=(0.55, 0.85, 0.55)))

        def short(p, n=28):
            b = os.path.basename(p)
            return b if len(b) <= n else "..." + b[-(n - 3):]

        def short_dir(p, n=30):
            d = os.path.dirname(p)
            return d if len(d) <= n else "..." + d[-(n-3):]

        row.add_child(self._label(f"  D: {short(depth_path)}",
                                  color=(0.75, 0.75, 0.75)))
        row.add_child(self._label(f"     {short_dir(depth_path)}",
                                  color=(0.45, 0.55, 0.65)))
        row.add_child(self._label(f"  R: {short(rgb_path)}",
                                  color=(0.75, 0.75, 0.75)))
        row.add_child(self._label(f"     {short_dir(rgb_path)}",
                                  color=(0.45, 0.55, 0.65)))

        ctrl = gui.Horiz(sep)

        cb = gui.Checkbox("Show")
        cb.checked = True
        def on_show(checked, n=geo_name):
            self._scene.scene.show_geometry(n, checked)
        cb.set_on_checked(on_show)

        btn_rm = gui.Button("Remove")
        def on_remove(n=geo_name, r=row):
            sc = self._scene.scene
            if sc.has_geometry(n):
                sc.remove_geometry(n)
            self._extra_depths.pop(n, None)
            self._extra_rgbs.pop(n, None)
            r.visible = False
            self.win.set_needs_layout()
        btn_rm.set_on_clicked(on_remove)

        ctrl.add_child(cb)
        ctrl.add_stretch()
        ctrl.add_child(btn_rm)
        row.add_child(ctrl)

        row.add_child(self._label("  Depth: A x depth + B",
                                  color=(0.65, 0.65, 0.65)))

        ab_row = gui.Horiz(sep)
        ab_row.add_child(gui.Label("A:"))
        edit_a = gui.NumberEdit(gui.NumberEdit.DOUBLE)
        edit_a.double_value = init_a
        edit_a.set_limits(-100.0, 100.0)
        ab_row.add_child(edit_a)
        ab_row.add_child(gui.Label("  B:"))
        edit_b = gui.NumberEdit(gui.NumberEdit.DOUBLE)
        edit_b.double_value = init_b
        edit_b.set_limits(-100.0, 100.0)
        ab_row.add_child(edit_b)
        row.add_child(ab_row)

        btn_apply = gui.Button("Apply Scale")
        def on_apply(n=geo_name, ea=edit_a, eb=edit_b):
            self._reapply_scale(n, ea.double_value, eb.double_value)
        btn_apply.set_on_clicked(on_apply)
        row.add_child(btn_apply)

        sep_lbl = gui.Label("- " * 14)
        sep_lbl.text_color = gui.Color(0.25, 0.25, 0.25)
        row.add_child(sep_lbl)

        self._sources_list.add_child(row)
        self.win.set_needs_layout()

    def _reapply_scale(self, geo_name: str, a: float, b: float):
        depth = self._extra_depths.get(geo_name)
        rgb   = self._extra_rgbs.get(geo_name)
        if depth is None:
            self._show_error(f"No cached depth for {geo_name}.\n"
                             "Source may have been removed.")
            return
        try:
            depth_c = np.clip(depth * a + b, 0.0, None).astype(np.float32)
            pcd = build_o3d_pointcloud(
                depth_c, rgb,
                self.fx, self.fy, self.cx, self.cy,
                self.depth_scale, self.max_depth, self.max_points,
            )
            sc = self._scene.scene
            if sc.has_geometry(geo_name):
                sc.remove_geometry(geo_name)
            sc.add_geometry(geo_name, pcd, self._mat)
            print(f"[Scale] {geo_name}  A={a:.4f}  B={b:.4f}")
        except Exception as exc:
            self._show_error(f"Scale apply failed:\n{exc}")

    def _show_error(self, msg: str):
        em  = self.win.theme.font_size
        dlg = gui.Dialog("Error")
        body = gui.Vert(int(em * 0.5), gui.Margins(em))
        body.add_child(gui.Label(msg))
        ok_btn = gui.Button("OK")
        ok_btn.set_on_clicked(lambda: self.win.close_dialog())
        body.add_child(ok_btn)
        dlg.add_child(body)
        self.win.show_dialog(dlg)

    def run(self):
        gui.Application.instance.run()
