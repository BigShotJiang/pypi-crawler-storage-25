from typing import List

import chromadb

from .db import VectorDataBaseProvider, VectorSearchResponse, VectorSearchResponseItem


class ChromaDbProvider(VectorDataBaseProvider):
    def __init__(
        self,
        collection: chromadb.Collection,
        n_results=5,
        max_distance=0.25,
    ):
        self.collection = collection
        self.n_results = n_results
        self.max_distance = max_distance

    def search(self, query: str) -> VectorSearchResponse:
        results = self.collection.query(query_texts=[query], n_results=self.n_results)
        ids = results.get("ids", [[]])[0]
        documents = results.get("documents", [[]])[0]
        if not ids or not documents:
            return VectorSearchResponse(answers=[])
        metadatas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]
        answers = []
        for doc_id, text, meta, distance in zip(ids, documents, metadatas, distances):
            if distance > self.max_distance:
                continue
            source = meta.get("source") if meta else None
            processed = meta.get("processed") if meta else None
            answers.append(
                VectorSearchResponseItem(
                    id=doc_id,
                    text=text,
                    source=source or doc_id,
                    processed=processed or False,
                )
            )
        return VectorSearchResponse(answers=answers)

    def update_processed(self, ids: List[str]):
        if not ids:
            return
        self.collection.update(
            ids=ids, metadatas=[{"processed": True} for i in range(len(ids))]
        )
