from typing import Optional

import requests
from piki_rag.common.exception import LLMProviderException

from .llm_provider import LLMProvider


class OpenRouterProvider(LLMProvider):

    def __init__(
        self,
        api_key: str,
        model_name: str,
        system_message: str,
        temperature: int = 0.7,
        max_tokens: int = 1000,
        timeout_seconds: int = 60,
    ):
        self.api_key = api_key
        self.model_name = model_name
        self.api_url = "https://openrouter.ai/api/v1/chat/completions"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        self.system_message = system_message
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout_seconds = timeout_seconds

    def generate(
        self,
        prompt: str,
    ) -> str:
        messages = []
        if self.system_message:
            messages.append({"role": "system", "content": self.system_message})
        messages.append({"role": "user", "content": prompt})
        payload = {
            "model": self.model_name,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        try:
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=self.timeout_seconds,
            )
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            raise LLMProviderException(
                status_code=response.status_code, message=response.text
            )
        except LLMProviderException:
            raise
        except Exception as e:
            raise LLMProviderException() from e
