"""ASC parity tests for spec and generated client behavior."""
