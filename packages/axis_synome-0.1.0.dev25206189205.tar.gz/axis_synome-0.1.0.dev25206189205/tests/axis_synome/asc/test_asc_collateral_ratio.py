"""Tests for collateral_portfolio and asc_collateral_ratio."""

import pytest

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.asc_collateral_ratio import (
    asc_collateral_ratio,
    asc_collateral_ratio_satisfied,
    collateral_portfolio,
)

from .mocks import MOCK_ADDRESS

SPARK = EligiblePrimeAgentASC.SPARK


def test_collateral_portfolio_sums_all_positions():
    # Includes both ASC-qualifying and non-qualifying assets.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
        Position(
            asset=Asset(
                token=Token.WBTC,
                protocol=Protocol.CENTRIFUGE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.WBTC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=900.0,
        ),
    ]
    assert collateral_portfolio(positions) == 1000.0


# asc_collateral_ratio
def test_asc_collateral_ratio_positive_when_compliant():
    # asc=100 (USDC LitePSM), portfolio=100, min_pct=0.05
    # slack = 100 - 100*0.05 = 95
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
    ]
    assert asc_collateral_ratio(SPARK, positions) == pytest.approx(95.0)


def test_asc_collateral_ratio_negative_when_non_compliant():
    # asc=10 (USDC LitePSM), large non-ASC position grows portfolio to 10_010
    # slack = 10 - 10_010*0.05 = 10 - 500.5 = -490.5
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=10.0,
        ),
        Position(
            asset=Asset(
                token=Token.WBTC,
                protocol=Protocol.CENTRIFUGE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.WBTC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=10_000.0,
        ),
    ]
    assert asc_collateral_ratio(SPARK, positions) == pytest.approx(-490.5)
    # TODO: We should discuss how to deal with decimals in floating numbers as this test is very sensitive to that. We could consider using a Decimal type for all USD values in the future.


# External data bridge
def test_bridge_asc_collateral_ratio(spark_positions):
    """Shows asc_collateral_ratio against user-fetched positions.

    All positions in spark_positions are owned by Spark, so:
        portfolio = asc = 2150
        slack = 2150 - 2150*0.05 = 2042.5 (hence compliant)
    """
    result = asc_collateral_ratio(SPARK, spark_positions)
    assert result == pytest.approx(2042.5)


# asc_collateral_ratio_satisfied (boolean predicate)
def test_asc_collateral_ratio_satisfied_true_when_compliant():
    # asc=100 (USDC LitePSM), portfolio=100, min_pct=0.05, slack=95 >= 0 => True
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
    ]
    assert asc_collateral_ratio_satisfied(SPARK, positions) is True


def test_asc_collateral_ratio_satisfied_false_when_non_compliant():
    # asc=10, large non-ASC position, slack=-490.5 < 0 => False
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=10.0,
        ),
        Position(
            asset=Asset(
                token=Token.WBTC,
                protocol=Protocol.CENTRIFUGE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.WBTC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=10_000.0,
        ),
    ]
    assert asc_collateral_ratio_satisfied(SPARK, positions) is False
