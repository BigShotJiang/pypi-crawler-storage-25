"""Tests for latent_asc.

Each test isolates a single inclusion or exclusion rule.
The scenario test at the bottom validates the full fixture at once.
"""

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC, PrimeAgentData
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.latent_asc import latent_asc

from . import mocks
from .mocks import MOCK_ADDRESS

SPARK = EligiblePrimeAgentASC.SPARK


# Inclusion rules
def test_cash_stablecoin_in_pool_not_paired_with_usds_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.CURVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
            pool_paired_with_usds=False,
        )
    ]
    assert latent_asc(SPARK, positions) == 100.0


def test_cash_stablecoin_in_sparklend_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=200.0,
        )
    ]
    assert latent_asc(SPARK, positions) == 200.0


def test_cash_stablecoin_in_aave_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDT,
                protocol=Protocol.AAVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDT,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=150.0,
        )
    ]
    assert latent_asc(SPARK, positions) == 150.0


def test_cash_stablecoin_in_morpho_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.DAI,
                protocol=Protocol.MORPHO,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.DAI,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
        )
    ]
    assert latent_asc(SPARK, positions) == 300.0


def test_cash_stablecoin_in_alm_proxy_counts():
    # alm_proxy is a governance-assigned protocol. Arkis is a real protocol
    # not in any classification set, so it isolates the alm_proxy path.
    from enum import Enum

    _agent = PrimeAgentData(
        name="Spark", assets=[], psm_protocols=set(), networks=set(), alm_proxy=Protocol.ARKIS
    )
    prime = Enum("_TestPrime", {"SPARK": _agent})["SPARK"]
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.ARKIS,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    assert latent_asc(prime, positions) == 500.0


# Exclusion rules
def test_pool_paired_with_usds_is_excluded():
    # Paired-with-USDS pools count toward resting ASC, not latent.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.CURVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
            pool_paired_with_usds=True,
        )
    ]
    assert latent_asc(SPARK, positions) == 0.0


def test_pool_with_unknown_pairing_counts_as_latent():
    # pool_paired_with_usds=None means pairing is unknown.
    # The formula treats None as falsy (not paired), so the position
    # contributes to latent ASC rather than resting ASC.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.CURVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=200.0,
            pool_paired_with_usds=None,
        )
    ]
    assert latent_asc(SPARK, positions) == 200.0


def test_non_cash_stablecoin_in_lending_is_excluded():
    # Only CASH_STABLECOINS (USDC, USDS, DAI, USDT) qualify.
    positions = [
        Position(
            asset=Asset(
                token=Token.WBTC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.WBTC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=999.0,
        )
    ]
    assert latent_asc(SPARK, positions) == 0.0


def test_alm_proxy_without_prime_config_is_excluded():
    # SPARK has no alm_proxy set, so Arkis positions are not counted.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.ARKIS,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    assert latent_asc(SPARK, positions) == 0.0


# Full scenario
def test_full_latent_scenario():
    # 100 + 200 + 150 + 300 = 750.0
    assert latent_asc(SPARK, mocks.spark_latent_positions()) == 750.0
