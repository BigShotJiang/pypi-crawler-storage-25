"""Pre-built Position fixtures and a bridge for user-fetched external data.

Bridge pattern: External data (API response, CSV row, database record) arrives as a plain dict.
``positions_from_records()`` converts it into ``Position`` objects that the ASC formulas can consume.

    api_records = [
        {"token": "USDC", "protocol": "LitePSM", "network": "Ethereum Mainnet", "value_usd": 500_000.0},
        {"token": "USDC", "protocol": "SparkLend", "network": "Ethereum Mainnet", "value_usd": 200_000.0},
    ]
    positions = positions_from_records(api_records)
    result = asc(SPARK, positions)
"""

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec_support.evm_address import EvmAddress

SPARK = EligiblePrimeAgentASC.SPARK  # noqa: F401 — re-exported for convenience

MOCK_ADDRESS = EvmAddress("0x1121F4e21eD8B9BC1BB9A2952cDD8639aC897784")


def spark_resting_positions() -> list[Position]:
    """Positions owned by Spark that count toward resting ASC.

    Covers every inclusion rule:
    - USDC in LitePSM (L1 PSM) = 100.0
    - USDC in PSM3 on Arbitrum (L2 PSM) = 200.0
    - USDC in PSM3 on Base (L2 PSM) = 150.0
    - USDC in Curve paired with USDS = 300.0
    - USDS in Uniswap paired with USDS = 250.0
    - USDC in GUNI at 0.01% fee tier = 400.0
                                total = 1 400.0
    """
    return [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.PSM3,
                network=Network.ARBITRUM,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=200.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.PSM3,
                network=Network.BASE,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=150.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.CURVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
            pool_paired_with_usds=True,
        ),
        Position(
            asset=Asset(
                token=Token.USDS,
                protocol=Protocol.UNISWAP,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDS,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=250.0,
            pool_paired_with_usds=True,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.GUNI,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=400.0,
            fee_tier=0.0001,
        ),
    ]


def spark_latent_positions() -> list[Position]:
    """Positions owned by Spark that count toward latent ASC.

    Covers every inclusion rule:
    - USDC in Curve NOT paired with USDS = 100.0
    - USDC in SparkLend (lending) = 200.0
    - USDT in Aave (lending) = 150.0
    - DAI in Morpho (lending) = 300.0
                            total = 750.0
    """
    return [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.CURVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
            pool_paired_with_usds=False,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=200.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDT,
                protocol=Protocol.AAVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDT,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=150.0,
        ),
        Position(
            asset=Asset(
                token=Token.DAI,
                protocol=Protocol.MORPHO,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.DAI,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
        ),
    ]


def positions_from_records(records: list[dict]) -> list[Position]:
    """Bridge: convert user-fetched records into Position objects.

    Args:
        records: Raw rows from an API response, CSV, or database query.
    Returns:
        A list of ``Position`` objects ready to pass directly to ``asc()``,
        ``resting_asc()``, or ``latent_asc()``.
    """
    return [
        Position(
            asset=Asset(
                token=Token(r["token"]),
                protocol=Protocol(r["protocol"]),
                network=Network(r["network"]),
                address=r.get("address", MOCK_ADDRESS),
                underlying_asset=Token(r["token"]),
                underlying_asset_address=r.get("underlying_asset_address", MOCK_ADDRESS),
                underlying_asset_source=r.get("underlying_asset_source", ""),
            ),
            value_usd=float(r["value_usd"]),
            pool_paired_with_usds=r.get("pool_paired_with_usds"),
            fee_tier=r.get("fee_tier"),
        )
        for r in records
    ]
