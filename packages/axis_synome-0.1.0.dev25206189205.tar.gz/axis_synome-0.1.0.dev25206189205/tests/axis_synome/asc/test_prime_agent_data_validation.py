"""Validation constraint tests for PrimeAgentData.

Covers:
- name: min_length=1
- min_pct_asc_of_collateral: [0.0, 1.0]
- validation toggle: VALIDATION_DISABLED=1 skips constraints
"""

from typing import Annotated

import pytest
from pydantic import ValidationError

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.primes import PrimeAgentData
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token

from .mocks import MOCK_ADDRESS

# name: min_length=1


def test_empty_name_raises():
    with pytest.raises(ValidationError):
        PrimeAgentData(
            name="",
            assets=[
                Asset(
                    token=Token.USDC,
                    protocol=Protocol.LITE_PSM,
                    network=Network.ETHEREUM_MAINNET,
                    address=MOCK_ADDRESS,
                    underlying_asset=Token.USDC,
                    underlying_asset_address=MOCK_ADDRESS,
                    underlying_asset_source="",
                )
            ],
            psm_protocols={Protocol.LITE_PSM},
            networks={Network.ETHEREUM_MAINNET},
        )


# min_pct_asc_of_collateral: [0.0, 1.0]


def test_min_pct_asc_of_collateral_below_zero_raises():
    with pytest.raises(ValidationError):
        PrimeAgentData(
            name="Spark",
            assets=[
                Asset(
                    token=Token.USDC,
                    protocol=Protocol.LITE_PSM,
                    network=Network.ETHEREUM_MAINNET,
                    address=MOCK_ADDRESS,
                    underlying_asset=Token.USDC,
                    underlying_asset_address=MOCK_ADDRESS,
                    underlying_asset_source="",
                )
            ],
            psm_protocols={Protocol.LITE_PSM},
            networks={Network.ETHEREUM_MAINNET},
            min_pct_asc_of_collateral=-0.01,
        )


def test_min_pct_asc_of_collateral_above_one_raises():
    with pytest.raises(ValidationError):
        PrimeAgentData(
            name="Spark",
            assets=[
                Asset(
                    token=Token.USDC,
                    protocol=Protocol.LITE_PSM,
                    network=Network.ETHEREUM_MAINNET,
                    address=MOCK_ADDRESS,
                    underlying_asset=Token.USDC,
                    underlying_asset_address=MOCK_ADDRESS,
                    underlying_asset_source="",
                )
            ],
            psm_protocols={Protocol.LITE_PSM},
            networks={Network.ETHEREUM_MAINNET},
            min_pct_asc_of_collateral=1.01,
        )


# validation toggle


def test_validation_disabled_skips_constraints(monkeypatch):
    """With VALIDATION_DISABLED=1, a decorated class skips pydantic checks."""
    from pydantic import Field

    import axis_synome.spec_support.validated_dataclass as vd_mod
    from axis_synome.spec_support.validated_dataclass import validated_dataclass

    monkeypatch.setattr(vd_mod, "_VALIDATE", False)

    @validated_dataclass
    class _Data:
        name: Annotated[str, Field(min_length=1)]

    # name="" would raise ValidationError when validation is enabled
    obj = _Data(name="")
    assert obj.name == ""
