"""Tests for ratio_latent_asc."""

import pytest

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC, PrimeAgentData
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.ratio_latent_asc import (
    latent_asc_ratio_satisfied,
    ratio_latent_asc,
)

from .mocks import MOCK_ADDRESS

SPARK = EligiblePrimeAgentASC.SPARK


def test_max_pct_latent_asc_defaults_to_0_25():
    # max_pct_latent_asc defaults to 0.25 (the protocol maximum).
    prime = PrimeAgentData(name="Spark", assets=[], psm_protocols=set(), networks=set())
    assert prime.max_pct_latent_asc == 0.25


def test_max_pct_latent_asc_rejects_values_above_cap():
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        PrimeAgentData(
            name="Spark", assets=[], psm_protocols=set(), networks=set(), max_pct_latent_asc=0.30
        )


# Compliance scenarios
def test_positive_slack_when_latent_within_cap():
    # resting=1000 (USDC LitePSM), latent=100 (USDC SparkLend)
    # total=1100, cap=1100*0.25=275, slack=275-100=175
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
    ]
    assert ratio_latent_asc(SPARK, positions) == pytest.approx(175.0)


def test_negative_slack_when_latent_exceeds_cap():
    # resting=100 (USDC LitePSM), latent=600 (USDC SparkLend)
    # total=700, cap=700*0.25=175, slack=175-600=-425
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=600.0,
        ),
    ]
    assert ratio_latent_asc(SPARK, positions) == pytest.approx(-425.0)


def test_zero_slack_when_latent_equals_cap_exactly():
    # resting=300, latent=100 // total=400, cap=400*0.25=100, slack=0
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
    ]
    assert ratio_latent_asc(SPARK, positions) == pytest.approx(0.0)


# External data bridge
def test_bridge_ratio_latent_asc(spark_positions):
    """Shows ratio_latent_asc against user-fetched positions.

    resting=1400, latent=750, total=2150
    cap = 2150 * 0.25 = 537.5
    slack = 537.5 - 750 = -212.5  (latent exceeds the permitted cap)

    A negative result is a signal to the prime to rebalance latent
    positions into resting ones.
    """
    result = ratio_latent_asc(SPARK, spark_positions)
    assert result == pytest.approx(-212.5)


# latent_asc_ratio_satisfied (boolean predicate)
def test_latent_asc_ratio_satisfied_true_when_within_cap():
    # resting=1000, latent=100, total=1100, cap=275, slack=175 >= 0 => True
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
    ]
    assert latent_asc_ratio_satisfied(SPARK, positions) is True


def test_latent_asc_ratio_satisfied_false_when_exceeds_cap():
    # resting=100, latent=600, total=700, cap=175, slack=-425 < 0 => False
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=600.0,
        ),
    ]
    assert latent_asc_ratio_satisfied(SPARK, positions) is False


def test_latent_asc_ratio_satisfied_true_when_exactly_at_cap():
    # resting=300, latent=100, total=400, cap=100, slack=0 => True (boundary)
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
    ]
    assert latent_asc_ratio_satisfied(SPARK, positions) is True
