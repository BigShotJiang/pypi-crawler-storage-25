import pytest

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.dab import dab_required

from .mocks import MOCK_ADDRESS

SPARK = EligiblePrimeAgentASC.SPARK


# dab_required
def test_dab_required_is_fraction_of_asc():
    # asc = resting(USDC LitePSM=200) + latent(USDC SparkLend=100) = 300
    # required = 300 * 0.25 = 75
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=200.0,
        ),
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.SPARKLEND,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=100.0,
        ),
    ]
    assert dab_required(SPARK, positions) == pytest.approx(75.0)
