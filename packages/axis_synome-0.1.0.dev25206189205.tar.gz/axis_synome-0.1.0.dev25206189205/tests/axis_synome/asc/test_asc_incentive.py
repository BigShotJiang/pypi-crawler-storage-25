"""Tests for asc_incentive."""

import pytest

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.asc_incentive import asc_incentive

from .mocks import MOCK_ADDRESS

SPARK = EligiblePrimeAgentASC.SPARK


def test_positive_incentive_when_base_above_tbill():
    # asc=1000, base=0.05, tbill=0.03
    # incentive = 1000*0.02 = 20
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        ),
    ]
    assert asc_incentive(
        SPARK, positions, base_rate=0.05, treasury_bill_rate=0.03
    ) == pytest.approx(20.0)


def test_zero_incentive_when_rates_equal():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        ),
    ]
    assert asc_incentive(
        SPARK, positions, base_rate=0.04, treasury_bill_rate=0.04
    ) == pytest.approx(0.0)


def test_negative_incentive_when_base_below_tbill():
    # Can occur when the treasury bill rate exceeds the base rate.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        ),
    ]
    assert asc_incentive(
        SPARK, positions, base_rate=0.03, treasury_bill_rate=0.05
    ) == pytest.approx(-20.0)


def test_incentive_scales_with_asc_amount():
    # Doubling the position doubles the incentive.
    positions_small = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    positions_large = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        )
    ]
    small = asc_incentive(SPARK, positions_small, base_rate=0.05, treasury_bill_rate=0.03)
    large = asc_incentive(SPARK, positions_large, base_rate=0.05, treasury_bill_rate=0.03)
    assert large == pytest.approx(2 * small)


# External data bridge
def test_bridge_asc_incentive(spark_positions):
    """Shows asc_incentive against user-fetched positions.

    asc=2150, base=0.05, tbill=0.03 // incentive = 2150*0.02 = 43.0

    The rate parameters (base_rate, treasury_bill_rate) are supplied by the
    caller — they come from a separate governance or market data source,
    not from the position records.
    """
    result = asc_incentive(SPARK, spark_positions, base_rate=0.05, treasury_bill_rate=0.03)
    assert result == pytest.approx(43.0)
