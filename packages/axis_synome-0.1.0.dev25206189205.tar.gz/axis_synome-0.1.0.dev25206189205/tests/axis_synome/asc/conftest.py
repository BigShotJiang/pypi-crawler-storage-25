"""Shared pytest fixtures for ASC formula tests."""

import pytest

from . import mocks


@pytest.fixture
def spark_positions():
    # fetch the data as step 1: replace this list with your real data source
    #   raw_data = your_api.fetch_positions(prime="Spark")
    #   raw_data = client.query("SELECT * FROM positions WHERE owner = 'Spark'")

    # Each record needs: token, protocol, network, value_usd.
    # Optional: pool_paired_with_usds, fee_tier.

    raw_data = [
        # resting ASC positions
        {"token": "USDC", "protocol": "LitePSM", "network": "Ethereum Mainnet", "value_usd": 100.0},
        {"token": "USDC", "protocol": "PSM3", "network": "Arbitrum", "value_usd": 200.0},
        {"token": "USDC", "protocol": "PSM3", "network": "Base", "value_usd": 150.0},
        {
            "token": "USDC",
            "protocol": "Curve",
            "network": "Ethereum Mainnet",
            "value_usd": 300.0,
            "pool_paired_with_usds": True,
        },
        {
            "token": "USDS",
            "protocol": "Uniswap",
            "network": "Ethereum Mainnet",
            "value_usd": 250.0,
            "pool_paired_with_usds": True,
        },
        {
            "token": "USDC",
            "protocol": "GUNI",
            "network": "Ethereum Mainnet",
            "value_usd": 400.0,
            "fee_tier": 0.0001,
        },
        # latent ASC positions
        {
            "token": "USDC",
            "protocol": "Curve",
            "network": "Ethereum Mainnet",
            "value_usd": 100.0,
            "pool_paired_with_usds": False,
        },
        {
            "token": "USDC",
            "protocol": "SparkLend",
            "network": "Ethereum Mainnet",
            "value_usd": 200.0,
        },
        {"token": "USDT", "protocol": "Aave", "network": "Ethereum Mainnet", "value_usd": 150.0},
        {"token": "DAI", "protocol": "Morpho", "network": "Ethereum Mainnet", "value_usd": 300.0},
    ]
    # Map as the second step: convert raw records into typed Position objects
    return mocks.positions_from_records(raw_data)
    # resting = 100 + 200 + 150 + 300 + 250 + 400 = 1400.0
    # latent  = 100 + 200 + 150 + 300 = 750.0
    # asc = 2150.0
