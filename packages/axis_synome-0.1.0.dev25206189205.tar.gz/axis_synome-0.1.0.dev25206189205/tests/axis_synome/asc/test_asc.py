"""Tests for the combined asc formula.

Also demonstrates the external data bridge: how to attach user-fetched
data (an API response, CSV rows, etc.) to the formulas using
``positions_from_records()``.
"""

from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC, PrimeAgent, PrimeAgentData
from axis_synome.spec.asc.formulas.asc import asc

from . import mocks

SPARK = EligiblePrimeAgentASC.SPARK


def test_total_asc_equals_resting_plus_latent():
    positions = mocks.spark_resting_positions() + mocks.spark_latent_positions()
    # resting = 1400.0,  latent = 750.0
    assert asc(SPARK, positions) == 2150.0


def test_exempt_prime_is_not_eligible():
    # Keel is ASC-exempt; EligiblePrimeAgentASC (the enum) excludes exempt primes.
    assert PrimeAgent.KEEL.value.asc_exempt is True
    assert PrimeAgent.KEEL.value not in [m.value for m in EligiblePrimeAgentASC]


def test_unregistered_prime_agent_is_rejected():
    # A raw PrimeAgentData not registered in EligiblePrimeAgentASC cannot be used
    # in formulas — they expect an enum member with a .value attribute.
    import pytest

    new_prime = PrimeAgentData(name="New Prime", assets=[], psm_protocols=set(), networks=set())
    with pytest.raises(AttributeError):
        asc(new_prime, [])  # ty: ignore[invalid-argument-type]


def test_asc_is_zero_when_no_positions():
    assert asc(SPARK, []) == 0.0


# External data bridge
def test_bridge_from_api_response():
    """Shows how to attach user-fetched data to the formulas."""
    api_records = [
        # resting: USDC in LitePSM
        {
            "token": "USDC",
            "protocol": "LitePSM",
            "network": "Ethereum Mainnet",
            "value_usd": 1000.0,
        },
        # latent: USDC in SparkLend
        {
            "token": "USDC",
            "protocol": "SparkLend",
            "network": "Ethereum Mainnet",
            "value_usd": 500.0,
        },
    ]

    positions = mocks.positions_from_records(api_records)
    assert asc(SPARK, positions) == 1500.0  # 1000 resting + 500 latent


def test_bridge_with_optional_fields():
    """Optional fields (pool_paired_with_usds, fee_tier) are passed through when present."""
    api_records = [
        # resting: USDC in Curve paired with USDS
        {
            "token": "USDC",
            "protocol": "Curve",
            "network": "Ethereum Mainnet",
            "value_usd": 300.0,
            "pool_paired_with_usds": True,
        },
        # resting: USDC in GUNI with eligible fee tier
        {
            "token": "USDC",
            "protocol": "GUNI",
            "network": "Ethereum Mainnet",
            "value_usd": 400.0,
            "fee_tier": 0.0001,
        },
    ]

    positions = mocks.positions_from_records(api_records)
    assert asc(SPARK, positions) == 700.0  # 300 + 400, both resting
