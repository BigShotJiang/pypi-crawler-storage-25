from __future__ import annotations

import inspect
from dataclasses import fields
from enum import Enum

import pytest

from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC as SpecEligiblePrimeAgentASC
from axis_synome.spec.asc.entities.types import Position as SpecPosition
from axis_synome.spec.asc.formulas.asc import asc as spec_asc
from axis_synome.spec.asc.formulas.latent_asc import latent_asc as spec_latent_asc
from axis_synome.spec.asc.formulas.ratio_latent_asc import ratio_latent_asc as spec_ratio_latent_asc

from .mocks import spark_latent_positions, spark_resting_positions

client_prime_module = pytest.importorskip("client.synome.entities._shared.axis_asc_entities_primes")
client_asset_module = pytest.importorskip("client.synome.entities.asc.axis_asc_entities_assets")
client_network_module = pytest.importorskip("client.synome.entities.asc.axis_asc_entities_networks")
client_protocol_module = pytest.importorskip(
    "client.synome.entities.asc.axis_asc_entities_protocol_sets"
)
client_token_module = pytest.importorskip("client.synome.entities.asc.axis_asc_entities_tokens")
client_position_module = pytest.importorskip(
    "client.synome.entities._shared.axis_asc_entities_types"
)
client_asc_module = pytest.importorskip("client.synome.formulas.asc")
client_latent_module = pytest.importorskip("client.synome.formulas.latent_asc")
client_ratio_module = pytest.importorskip("client.synome.formulas.ratio_latent_asc")
client_resting_module = pytest.importorskip("client.synome.formulas.resting_asc")

ClientPrimeAgent = client_prime_module.PrimeAgent
ClientEligiblePrimeAgentASC = client_prime_module.EligiblePrimeAgentASC
ClientAsset = client_asset_module.Asset
ClientNetwork = client_network_module.Network
ClientProtocol = client_protocol_module.Protocol
ClientToken = client_token_module.Token
ClientPosition = client_position_module.Position


# Spec-derived test parameters for resilience
_TEST_PRIME_NAME = "Spark"
_TEST_MAX_PCT_LATENT_ASC = 0.25


def _enum_member_by_name(enum_cls: type[Enum], name: str) -> Enum:
    """Return enum member by human-readable name (e.g., "Spark" -> SPARK)."""
    candidate = name.upper().replace(" ", "_")
    try:
        return enum_cls[candidate]
    except KeyError as error:
        raise AssertionError(
            f"Could not find enum member {candidate} in {enum_cls.__name__}"
        ) from error


def _prime_payload(prime: object) -> object:
    """Return dataclass payload for enum-backed prime objects."""
    if isinstance(prime, Enum):
        return prime.value
    return prime


def _make_spec_prime() -> SpecEligiblePrimeAgentASC:
    """Create a spec eligible-prime enum member for parity checks."""
    return SpecEligiblePrimeAgentASC(
        _enum_member_by_name(SpecEligiblePrimeAgentASC, _TEST_PRIME_NAME)
    )


def _make_client_prime() -> ClientEligiblePrimeAgentASC:
    """Create a client eligible-prime enum member aligned with spec-side construction."""
    return ClientEligiblePrimeAgentASC(
        _enum_member_by_name(ClientEligiblePrimeAgentASC, _TEST_PRIME_NAME)
    )


def _make_spec_positions() -> list[SpecPosition]:
    """Load spec fixture positions for the test prime (resting + latent combined)."""
    return spark_resting_positions() + spark_latent_positions()


def _make_client_positions() -> list[ClientPosition]:
    """Load same fixture positions as spec, cast them to client entity types."""
    positions = spark_resting_positions() + spark_latent_positions()

    converted: list[ClientPosition] = []
    for position in positions:
        asset = position.asset
        converted_asset = ClientAsset(
            token=ClientToken(asset.token.value),
            network=ClientNetwork(asset.network.value),
            protocol=ClientProtocol(asset.protocol.value),
            address=asset.address,
            underlying_asset=ClientToken(asset.underlying_asset.value),
            underlying_asset_address=asset.underlying_asset_address,
            underlying_asset_source=asset.underlying_asset_source,
            source=asset.source,
        )
        converted.append(
            ClientPosition(
                asset=converted_asset,
                value_usd=position.value_usd,
                pool_paired_with_usds=position.pool_paired_with_usds,
                fee_tier=position.fee_tier,
            )
        )

    return converted


def test_generated_prime_agent_structure_matches_spec() -> None:
    """Verify generated ASC entity structure stays aligned with the spec entity."""
    client_agent = _prime_payload(_make_client_prime())
    spec_agent = _prime_payload(_make_spec_prime())

    assert client_agent.name == spec_agent.name  # ty: ignore[unresolved-attribute]

    for field in fields(spec_agent):  # ty: ignore[invalid-argument-type]
        assert hasattr(client_agent, field.name), (
            f"Generated PrimeAgent missing field: {field.name}"
        )
        client_type = type(getattr(client_agent, field.name))
        spec_type = type(getattr(spec_agent, field.name))
        assert client_type.__name__ == spec_type.__name__, (
            f"Field {field.name} type mismatch: "
            f"generated={client_type.__name__}, "
            f"spec={spec_type.__name__}"
        )


def test_generated_asc_formulas_accept_prime_agent_when_entity_signature_is_emitted() -> None:
    """Guard direct PrimeAgent signatures only in ASC-specific parity coverage."""
    formula_modules = (
        client_asc_module,
        client_latent_module,
        client_ratio_module,
        client_resting_module,
    )
    client_prime = _make_client_prime()

    for formula_module in formula_modules:
        formula_functions = [
            getattr(formula_module, attr_name)
            for attr_name in dir(formula_module)
            if attr_name.startswith("formula_") and callable(getattr(formula_module, attr_name))
        ]

        for formula_func in formula_functions:
            signature = inspect.signature(formula_func)
            kwargs: dict[str, object] = {}
            supports_prime_agent = False

            for param in signature.parameters.values():
                annotation = param.annotation
                annotation_name = (
                    annotation
                    if isinstance(annotation, str)
                    else getattr(annotation, "__name__", "")
                )

                if annotation in {
                    ClientPrimeAgent,
                    ClientEligiblePrimeAgentASC,
                } or annotation_name in {"PrimeAgent", "EligiblePrimeAgentASC"}:
                    supports_prime_agent = True
                    kwargs[param.name] = client_prime
                    continue

                if param.default is not inspect._empty:
                    continue

                if "position" in param.name:
                    kwargs[param.name] = []
                else:
                    kwargs[param.name] = 1.0

            if not supports_prime_agent:
                continue

            result = formula_func(**kwargs)
            assert isinstance(result, int | float)
            return

    pytest.skip(
        "Generated ASC formulas currently flatten entity inputs to scalar parameters; "
        "no direct PrimeAgent signature is emitted yet."
    )


def test_ratio_latent_asc_forward_looking_signature_parity() -> None:
    """Verify ratio_latent_asc formula parity for forward-looking signature evolution.

    This test adapts to signature changes in the generated client, ensuring
    compatibility across different codegen strategies (entity-aware vs scalar-flattened).
    """
    signature = inspect.signature(client_ratio_module.formula_ratio_latent_asc)
    spec_prime = _make_spec_prime()
    client_prime = _make_client_prime()
    spec_positions = _make_spec_positions()
    client_positions = _make_client_positions()

    # ratio_latent_asc accesses max_pct_latent_asc via prime.max_pct_latent_asc;
    # it is not a separate function parameter.  We control the value through the
    # prime entity itself (default is _TEST_MAX_PCT_LATENT_ASC = 0.25).
    spec_value = spec_ratio_latent_asc(spec_prime, spec_positions)
    if len(signature.parameters) == 2:
        # Entity-aware signature: (prime, positions) — spec formula copied as-is
        client_value = client_ratio_module.formula_ratio_latent_asc(
            client_prime,
            client_positions,
        )
    elif len(signature.parameters) == 3:
        # Entity-aware signature with explicit max_pct_latent_asc parameter
        client_value = client_ratio_module.formula_ratio_latent_asc(
            client_prime,
            client_positions,
            max_pct_latent_asc=_TEST_MAX_PCT_LATENT_ASC,
        )
    elif len(signature.parameters) == 4:
        # Scalar-flattened signature: (latent_value, max_pct, prime, total_value)
        latent_value = spec_latent_asc(spec_prime, spec_positions)
        total_value = spec_asc(spec_prime, spec_positions)
        client_value = client_ratio_module.formula_ratio_latent_asc(
            latent_value,
            _TEST_MAX_PCT_LATENT_ASC,
            client_prime,
            total_value,
        )
    else:
        pytest.fail(
            f"Unsupported ratio_latent_asc signature shape: {len(signature.parameters)} parameters"
        )

    assert client_value == pytest.approx(spec_value)
