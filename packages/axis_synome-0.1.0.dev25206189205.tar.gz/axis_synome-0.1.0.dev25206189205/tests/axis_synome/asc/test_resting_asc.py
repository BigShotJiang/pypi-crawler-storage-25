"""Tests for resting_asc.

Each test isolates a single inclusion or exclusion rule.
The scenario test at the bottom validates the full fixture at once.
"""

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.resting_asc import resting_asc

from . import mocks
from .mocks import MOCK_ADDRESS

# Inclusion rules


def test_usdc_in_litepsm_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        )
    ]
    assert resting_asc(positions) == 1000.0


def test_usdc_in_psm3_on_arbitrum_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.PSM3,
                network=Network.ARBITRUM,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    assert resting_asc(positions) == 500.0


def test_usdc_in_psm3_on_base_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.PSM3,
                network=Network.BASE,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    assert resting_asc(positions) == 500.0


def test_usdc_in_psm3_on_unichain_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.PSM3,
                network=Network.UNICHAIN,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    assert resting_asc(positions) == 500.0


def test_usdc_in_psm3_on_optimism_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.PSM3,
                network=Network.OPTIMISM,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    assert resting_asc(positions) == 500.0


def test_cash_stablecoin_in_pool_paired_with_usds_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.CURVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
            pool_paired_with_usds=True,
        )
    ]
    assert resting_asc(positions) == 300.0


def test_usdc_in_guni_at_001pct_fee_tier_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.GUNI,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=400.0,
            fee_tier=0.0001,
        )
    ]
    assert resting_asc(positions) == 400.0


def test_usdc_in_guni_at_005pct_fee_tier_counts():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.GUNI,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=400.0,
            fee_tier=0.0005,
        )
    ]
    assert resting_asc(positions) == 400.0


# Exclusion rules
def test_psm3_on_ethereum_mainnet_is_excluded():
    # PSM3 only counts on L2 networks, not on Ethereum mainnet.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.PSM3,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=500.0,
        )
    ]
    assert resting_asc(positions) == 0.0


def test_pool_not_paired_with_usds_is_excluded():
    # Unpaired pools contribute to latent ASC, not resting.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.CURVE,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=300.0,
            pool_paired_with_usds=False,
        )
    ]
    assert resting_asc(positions) == 0.0


def test_guni_at_ineligible_fee_tier_is_excluded():
    positions = [
        Position(
            asset=Asset(
                token=Token.USDC,
                protocol=Protocol.GUNI,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDC,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=400.0,
            fee_tier=0.003,
        )
    ]
    assert resting_asc(positions) == 0.0


def test_non_usdc_in_litepsm_is_excluded():
    # LitePSM only qualifies for USDC, not other stablecoins.
    positions = [
        Position(
            asset=Asset(
                token=Token.USDS,
                protocol=Protocol.LITE_PSM,
                network=Network.ETHEREUM_MAINNET,
                address=MOCK_ADDRESS,
                underlying_asset=Token.USDS,
                underlying_asset_address=MOCK_ADDRESS,
                underlying_asset_source="",
            ),
            value_usd=1000.0,
        )
    ]
    assert resting_asc(positions) == 0.0


# Full scenario
def test_full_resting_scenario():
    # 100 + 200 + 150 + 300 + 250 + 400 = 1400.0
    assert resting_asc(mocks.spark_resting_positions()) == 1400.0
