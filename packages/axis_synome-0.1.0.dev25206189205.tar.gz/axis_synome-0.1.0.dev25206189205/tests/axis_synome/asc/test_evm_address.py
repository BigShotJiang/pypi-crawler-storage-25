"""Tests for EVM address EIP-55 checksum validation."""

import pytest

from axis_synome.spec_support.evm_address import EvmAddress, validate_eip55


class TestEvmAddressValidation:
    # EIP-55 official test vectors: https://eips.ethereum.org/EIPS/eip-55
    def test_valid_eip55_normal_1(self) -> None:
        addr = "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed"
        assert validate_eip55(addr) == addr

    def test_valid_eip55_normal_2(self) -> None:
        addr = "0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359"
        assert validate_eip55(addr) == addr

    def test_valid_eip55_normal_3(self) -> None:
        addr = "0xdbF03B407c01E7cD3CBea99509d93f8DDDC8C6FB"
        assert validate_eip55(addr) == addr

    def test_valid_eip55_normal_4(self) -> None:
        addr = "0xD1220A0cf47c7B9Be7A2E6BA89F429762e7b9aDb"
        assert validate_eip55(addr) == addr

    def test_valid_eip55_all_caps_1(self) -> None:
        addr = "0x52908400098527886E0F7030069857D2E4169EE7"
        assert validate_eip55(addr) == addr

    def test_valid_eip55_all_caps_2(self) -> None:
        addr = "0x8617E340B3D01FA5F11F306F4090FD50E238070D"
        assert validate_eip55(addr) == addr

    def test_valid_eip55_all_lower_1(self) -> None:
        addr = "0xde709f2102306220921060314715629080e2fb77"
        assert validate_eip55(addr) == addr

    def test_valid_eip55_all_lower_2(self) -> None:
        addr = "0x27b1fdb04752bbc536007a920d24acb045561c26"
        assert validate_eip55(addr) == addr

    def test_too_short_raises(self) -> None:
        with pytest.raises(ValueError):
            validate_eip55("0xdead")

    def test_too_long_raises(self) -> None:
        with pytest.raises(ValueError):
            validate_eip55("0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed00")

    def test_missing_prefix_raises(self) -> None:
        with pytest.raises(ValueError):
            validate_eip55("5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed")

    def test_wrong_checksum_raises(self) -> None:
        # Valid hex length but wrong mixed-case checksum
        with pytest.raises(ValueError):
            validate_eip55("0xab5801a7d398351b8be11c439e05c5b3259aec9b")


class TestEvmAddressConstruction:
    def test_valid_address_constructs(self) -> None:
        addr = EvmAddress("0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed")
        assert str(addr) == "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed"

    def test_bad_value_raises(self) -> None:
        with pytest.raises(ValueError):
            EvmAddress("bad")

    def test_wrong_checksum_raises(self) -> None:
        with pytest.raises(ValueError):
            EvmAddress("0xab5801a7d398351b8be11c439e05c5b3259aec9b")

    def test_burn_address_raises(self) -> None:
        with pytest.raises(ValueError):
            EvmAddress("0x0000000000000000000000000000000000000000")
