"""Tests for the loss_given_default formula.

Reference: A.3.2.2.1.1.1.1.1.2 — Calculate Loss Given Default
"""

import pytest

from axis_synome.spec.risk_capital.formulas.required_risk_capital import loss_given_default


class TestLossGivenDefault:
    def test_zero_slippage_no_loss(self):
        """With no slippage, the liquidation buffer absorbs all risk."""
        # LP=0.05, S=0, LT=0.825 → recovery = 0.95 * 1.0 / 0.825 = 1.1515 > 1
        assert loss_given_default(0.05, 0.0, 0.825) == 0.0

    def test_small_slippage_no_loss(self):
        """A small slippage is absorbed by the buffer."""
        # LP=0.05, S=0.10, LT=0.825 → recovery = 0.95 * 0.9 / 0.825 = 1.036 > 1
        result = loss_given_default(0.05, 0.10, 0.825)
        assert result == 0.0

    def test_large_slippage_produces_loss(self):
        """A slippage larger than the buffer produces positive LGD."""
        # LP=0.05, S=0.40, LT=0.825 → recovery = 0.95 * 0.6 / 0.825 = 0.6909
        # LGD = 1 - 0.6909 = 0.3091
        result = loss_given_default(0.05, 0.40, 0.825)
        assert result == pytest.approx(0.3091, abs=0.001)

    def test_full_slippage_total_loss(self):
        """At 100% slippage, recovery is zero → LGD = 1."""
        result = loss_given_default(0.05, 1.0, 0.825)
        assert result == 1.0

    def test_result_is_never_negative(self):
        """LGD is clamped to [0, 1]."""
        for gap_int in range(0, 101):
            slippage = gap_int / 100
            assert loss_given_default(0.05, slippage, 0.825) >= 0.0

    def test_lgd_increases_monotonically_with_slippage(self):
        prev = 0.0
        for gap_int in range(0, 101):
            slippage = gap_int / 100
            result = loss_given_default(0.05, slippage, 0.825)
            assert result >= prev
            prev = result

    def test_matches_atlas_formula_directly(self):
        """Verify the formula matches LGD = max(0, 1 - (1-LP)(1-S)/LT)."""
        lp, s, lt = 0.10, 0.15, 0.8
        expected = max(0.0, 1.0 - (1.0 - lp) * (1.0 - s) / lt)
        result = loss_given_default(lp, s, lt)
        assert result == pytest.approx(expected, abs=1e-10)


class TestLossGivenDefaultEdgeCases:
    def test_high_threshold_high_penalty(self):
        """High LT with high LP leaves little buffer."""
        # LP=0.10, S=0.05, LT=0.90 → recovery = 0.9 * 0.95 / 0.90 = 0.95
        # LGD = 1 - 0.95 = 0.05
        result = loss_given_default(0.10, 0.05, 0.90)
        assert result > 0.0
        assert result == pytest.approx(0.05, abs=0.001)

    def test_low_threshold_generous_buffer(self):
        """Low LT means large buffer, absorbs significant slippage."""
        # LP=0.05, S=0.20, LT=0.50 → recovery = 0.95 * 0.80 / 0.50 = 1.52 > 1
        result = loss_given_default(0.05, 0.20, 0.50)
        assert result == 0.0
