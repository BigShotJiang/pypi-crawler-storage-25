"""Tests for the flake8 plugin adapter."""

import ast
import textwrap

from axis_synome.spec_validator.flake8_plugin import SpecSubsetChecker


def _run_plugin(source: str, filename: str = "/repo/axis_synome/spec/test.py") -> list[tuple]:
    """Run the flake8 plugin on *source* and return all reported errors."""
    tree = ast.parse(textwrap.dedent(source))
    checker = SpecSubsetChecker(tree, filename)
    return list(checker.run())


class TestSkipsNonSpecFiles:
    def test_non_spec_file(self):
        source = "class Foo:\n    pass\n"
        errors = _run_plugin(source, filename="/repo/src/synome/module.py")
        assert errors == []


class TestReportsSpecErrors:
    def test_class_def_in_spec(self):
        source = "class Foo:\n    pass\n"
        errors = _run_plugin(source)
        assert len(errors) >= 1
        assert errors[0][2].startswith("AXS001")
        assert "class definitions" in errors[0][2] or "@dataclass classes" in errors[0][2]

    def test_valid_spec_no_errors(self):
        source = """\
        def compute_value(x: float) -> float:
            result = x + 1.0
            return result
        """
        errors = _run_plugin(source)
        assert errors == []

    def test_error_has_line_and_col(self):
        source = "class Foo:\n    pass\n"
        errors = _run_plugin(source)
        lineno, col, msg, checker_type = errors[0]
        assert lineno == 1
        assert col == 0
        assert checker_type is SpecSubsetChecker


class TestSkipMarker:
    def test_skip_marker_respected(self, tmp_path):
        spec_file = tmp_path / "axis_synome" / "spec" / "test.py"
        spec_file.parent.mkdir(parents=True)
        spec_file.write_text("# validate-spec: skip\nclass Foo:\n    pass\n")
        tree = ast.parse(spec_file.read_text())
        checker = SpecSubsetChecker(tree, str(spec_file))
        errors = list(checker.run())
        assert errors == []
