"""Tests for the spec validator checker."""

import ast
from pathlib import Path

import pytest

from axis_synome.spec_validator.checker import SpecChecker, validate_file


def check(source: str) -> list[str]:
    """Parse source and run SpecChecker, returning errors."""
    tree = ast.parse(source)
    checker = SpecChecker("<test>")
    checker.visit(tree)
    return checker.errors


class TestValidSpec:
    def test_real_spec_passes(self):
        spec = (
            Path(__file__).resolve().parents[3]
            / "src"
            / "axis_synome"
            / "spec"
            / "asc"
            / "formulas"
            / "asc.py"
        )
        if not spec.exists():
            pytest.skip("spec file not found")
        errors = validate_file(spec)
        assert errors == []

    def test_simple_function(self):
        assert check("def f(x: float) -> float:\n    return x + 1\n") == []

    def test_assignment_and_arithmetic(self):
        src = "def f(a: float, b: float) -> float:\n    c = a * b + 1.0\n    return c\n"
        assert check(src) == []

    def test_annotated_assignment(self):
        src = "def f(x: float) -> float:\n    y: float = x * 2\n    return y\n"
        assert check(src) == []

    def test_if_else_banned(self):
        # if/else control flow is allowed, but conditional assignments are not
        src = "def f(x: float) -> float:\n    if x > 0:\n        y = x\n    else:\n        y = 0.0\n    return y\n"
        errors = check(src)
        assert any("Conditional assignments" in e for e in errors)

    def test_if_else_return_allowed(self):
        src = "def f(x: float) -> float:\n    if x > 0:\n        return x\n    else:\n        return 0.0\n"
        assert check(src) == []

    def test_ternary(self):
        src = "def f(x: float) -> float:\n    y = x if x > 0 else 0.0\n    return y\n"
        assert check(src) == []

    def test_allowed_builtins(self):
        src = "def f(a: float, b: float) -> float:\n    return max(a, min(b, abs(a)))\n"
        assert check(src) == []

    def test_math_calls(self):
        src = "import math\ndef f(x: float) -> float:\n    return math.log(x)\n"
        assert check(src) == []

    def test_sum_with_generator(self):
        src = 'def f(a: float, b: float) -> float:\n    items = [("a", a), ("b", b)]\n    return sum(v for name, v in items)\n'
        assert check(src) == []

    def test_compute_call(self):
        src = "def compute_a(x: float) -> float:\n    return x\ndef f(x: float) -> float:\n    return compute_a(x)\n"
        assert check(src) == []

    def test_module_level_assign(self):
        src = "THRESHOLD = 0.3\ndef f(x: float) -> float:\n    return x\n"
        assert check(src) == []


class TestDisallowedConstructs:
    def test_for_loop(self):
        src = "def f(x: float) -> float:\n    total = 0.0\n    for i in items:\n        total = total + i\n    return total\n"
        errors = check(src)
        assert any("For" in e for e in errors)

    def test_class_def(self):
        errors = check("class Foo:\n    pass\n")
        assert any("class definitions" in e or "@dataclass classes" in e for e in errors)

    def test_lambda(self):
        errors = check("def f(x: float) -> float:\n    g = lambda y: y + 1\n    return g(x)\n")
        assert any("lambda" in e for e in errors)

    def test_try_except(self):
        errors = check(
            "def f() -> float:\n    try:\n        return 1.0\n    except:\n        return 0.0\n"
        )
        assert any("try/except" in e for e in errors)

    def test_with_statement(self):
        errors = check("def f() -> float:\n    with open('x') as fh:\n        return 1.0\n")
        assert any("with statements" in e for e in errors)

    def test_raise(self):
        errors = check("def f() -> float:\n    raise ValueError('no')\n")
        assert any("raise" in e for e in errors)

    def test_assert(self):
        errors = check("def f(x: float) -> float:\n    assert x > 0\n    return x\n")
        assert any("assert" in e for e in errors)

    def test_delete(self):
        errors = check("def f() -> float:\n    x = 1\n    del x\n    return 0.0\n")
        assert any("del" in e for e in errors)

    def test_global(self):
        errors = check("def f() -> float:\n    global x\n    return 0.0\n")
        assert any("global" in e for e in errors)

    def test_nonlocal(self):
        # nonlocal requires enclosing scope, so nest it
        errors = check(
            "def f() -> float:\n    x = 1\n    def g():\n        nonlocal x\n    return 0.0\n"
        )
        assert any("nested function" in e for e in errors)

    def test_list_comprehension(self):
        errors = check("def f() -> float:\n    xs = [x for x in range(10)]\n    return 0.0\n")
        assert any("list comprehension" in e for e in errors)

    def test_dict_comprehension(self):
        errors = check("def f() -> float:\n    d = {k: v for k, v in items}\n    return 0.0\n")
        assert any("dict comprehension" in e for e in errors)

    def test_set_comprehension(self):
        errors = check("def f() -> float:\n    s = {x for x in items}\n    return 0.0\n")
        assert any("set comprehension" in e for e in errors)

    def test_fstring(self):
        errors = check("def f(x: float) -> float:\n    s = f'value: {x}'\n    return x\n")
        assert any("f-string" in e for e in errors)

    def test_walrus_operator(self):
        # Walrus operator is disallowed even though if statements are allowed.
        errors = check(
            "def f(x: float) -> float:\n    if (y := x + 1) > 0:\n        return y\n    return 0.0\n"
        )
        assert any("walrus" in e for e in errors)

    def test_async_function(self):
        errors = check("async def f() -> float:\n    return 1.0\n")
        assert any("async" in e for e in errors)

    def test_nested_function(self):
        errors = check("def f() -> float:\n    def g():\n        return 1.0\n    return g()\n")
        assert any("nested function" in e for e in errors)

    def test_decorator(self):
        errors = check("def noop(f):\n    return f\n@noop\ndef g() -> float:\n    return 1.0\n")
        assert any("decorator" in e for e in errors)

    def test_match_statement(self):
        errors = check(
            "def f(x: float) -> float:\n    match x:\n        case 1:\n            return 1.0\n    return 0.0\n"
        )
        assert any("match" in e for e in errors)


class TestImportValidation:
    def test_allowed_import(self):
        assert check("import math\n") == []

    def test_disallowed_import(self):
        errors = check("import os\n")
        assert any('"os" is not allowed' in e for e in errors)

    def test_allowed_from_import_axis(self):
        src = "from axis_synome.spec.utils import some_helper\n"
        assert check(src) == []

    def test_disallowed_from_module(self):
        errors = check("from os.path import join\n")
        assert any('"os.path" is not allowed' in e for e in errors)


class TestCallValidation:
    def test_user_defined_call_allowed(self):
        src = "def f() -> float:\n    return some_function(1.0)\n"
        assert check(src) == []

    def test_allowed_builtins(self):
        src = "def f(a: float, b: float) -> float:\n    return max(a, min(b, abs(a)))\n"
        assert check(src) == []

    def test_disallowed_builtin_exec(self):
        errors = check("def f() -> float:\n    exec('pass')\n    return 0.0\n")
        assert any('builtin "exec" is not allowed' in e for e in errors)

    def test_disallowed_builtin_open(self):
        errors = check("def f() -> float:\n    open('file')\n    return 0.0\n")
        assert any('builtin "open" is not allowed' in e for e in errors)

    def test_disallowed_builtin_eval(self):
        errors = check("def f() -> float:\n    return eval('1 + 1')\n")
        assert any('builtin "eval" is not allowed' in e for e in errors)

    def test_allowed_math_function(self):
        src = "import math\ndef f(x: float) -> float:\n    return math.log(x)\n"
        assert check(src) == []

    def test_disallowed_math_function(self):
        src = "import math\ndef f(x: float) -> float:\n    return math.acos(x)\n"
        errors = check(src)
        assert any('"acos" is not an allowed math function' in e for e in errors)


class TestUnderscoreNames:
    def test_underscore_name(self):
        errors = check("def f() -> float:\n    _private = 1\n    return 0.0\n")
        assert any('starts with "_"' in e for e in errors)

    def test_underscore_attribute(self):
        errors = check("def f(x: float) -> float:\n    return x.__class__\n")
        assert any('starts with "_"' in e for e in errors)

    def test_bare_underscore_ok(self):
        src = "def f() -> float:\n    _ = 1\n    return 0.0\n"
        # bare _ is allowed (used as throwaway)
        name_errors = [e for e in check(src) if 'starts with "_"' in e]
        assert name_errors == []


class TestEnumAndPydantic:
    def test_enum_class_allowed(self):
        src = "from enum import Enum\nclass Status(Enum):\n    A = 'a'\n    B = 'b'\n"
        assert check(src) == []

    def test_enum_with_docstring_allowed(self):
        src = "from enum import Enum\nclass Status(Enum):\n    'A status enum.'\n    A = 'a'\n"
        assert check(src) == []

    def test_enum_method_disallowed(self):
        src = "from enum import Enum\nclass Status(Enum):\n    A = 'a'\n    def label(self): return self.value\n"
        errors = check(src)
        assert any("methods are not allowed in Enum" in e for e in errors)

    def test_from_enum_import_allowed(self):
        assert check("from enum import Enum\n") == []

    def test_from_pydantic_import_allowed(self):
        assert check("from pydantic import Field\n") == []

    def test_from_pydantic_dataclasses_import_allowed(self):
        assert check("from pydantic.dataclasses import dataclass\n") == []


class TestSkipMarker:
    def test_skip_marker(self, tmp_path):
        f = tmp_path / "skipped.py"
        f.write_text("# validate-spec: skip\nclass Foo: pass\n")
        assert validate_file(f) is None

    def test_no_skip_marker(self, tmp_path):
        f = tmp_path / "checked.py"
        f.write_text("class Foo: pass\n")
        result = validate_file(f)
        assert result is not None
        assert len(result) > 0
