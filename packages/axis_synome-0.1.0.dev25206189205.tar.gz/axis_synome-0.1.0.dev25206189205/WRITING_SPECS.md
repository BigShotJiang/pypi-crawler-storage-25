# How to Write Axis Specs

This guide distills the principles and conventions used in `python/axis_synome/src/axis_synome/spec`. It is expected that new specs follow these
principles as much as possible. The purpose of the principles and conventions is ensure that specs remain parseable, convertible to (SymPy-backed) mathematical expressions, and that they become easy to read and navigate.

This is to facilitate the following goals, paraphrased from the [Axis Synome TechSpec](https://www.notion.so/Axis-Synome-Tech-Spec-30ab87693a5a8024ab3fe29ba5c3421c?source=copy_link):

> - Single source of truth: Specs are the authoritative definition of governance‑controlled formulas and parameters. All other artifacts derive deterministically.
> - Human‑readable/writable: Plain Python with type hints; works with standard PR reviews and diffs.
> - Machine‑verifiable: Statically checkable for types, dependency completeness, and allowed language subset before merge.
> - Declarative and implementation‑agnostic: Defines abstract interfaces (formulas, parameters) without hard dependencies on concrete math engines; clients register concrete primitives to execute.
> - Auditable/versioned: Entire change history in Git; enables point‑in‑time reconstruction and recomputation.


## Core Principles

Specs encode Atlas calculation rules directly in typed Python.
They are declarative, deterministic, side‑effect‑free computations; no I/O or mutable state.

They are organized into the `axis_synome.spec` namespace which contains a submodule/subdirectory `entities/` that defines dataclasses and Enums for domain inputs and constants. Many of these correspond to or stem from Atlas abstractions (typically, A6). In addition there are submodules grouped by calculation concepts (Atlas‑style, e.g., capital composition, credit risk, exposure transformation/mitigation). Asset classes live in `entities/` rather than as top‑level spec organization. This structure is pragmatic and reversible. Each of these submodules contains formulas:

- Formulas are pure functions over entities that specify computations.
- Each set of formulas that corresponds to a specific risk calculation, e.g., for a specific asset class is organized into its own namespace.
- Functions are kept small; compose into top‑level results.
- Independently testable and extractor‑friendly.
- Raw inputs in; full computation inside
  - Formulas accept raw entities/placeholders, not precomputed intermediates.
  - Each formula performs its own eligibility filtering which is done as much as possible through typing the inputs that it accepts.
- Policy/eligibility encoded in types
  - Use Specialized Enums for closed‑world sets (e.g., `EligiblePrimeAgentASC`).
  - (Membership checks must work with enum members and raw values).
  - Exemptions encoded structurally (exempt members absent from eligible Enum).
  - Functions that accept closed‑world Enums implicitly define relations over those domains; tooling can traverse these relations as a graph.

## The Graph

Instances of dataclasses are nodes; instances in Enums are nodes (enums are sets of nodes); (formula) functions are nodes.

What induces edges:
- Composition relationships: Fields in dataclasses, such as a `PrimeAgent` dataclass having a field `assets` of type `set[Asset]` - each concrete PrimeAgent (node) implicitly has edges to each asset in the `assets` set.
- Entities defined as closed‑world sets (Enums) form explicit connections to functions that accept them. A signature like `def asc(prime: EligiblePrime, positions: list[Position]) -> float:`, where `EligiblePrime` is an Enum-type consisting of `PrimeAgent` instances, induces an edge between each of those `PrimeAgent` instances and the `asc` function/formula.
- Function -> function references: When a (formula) function "calls" another (formula) function, that induces an edge between the caller and callee. Because of the restricted Python language subset, these function references are extracted from the Abstract Syntax Tree (AST) obtained by parsing the functions without needing to actually "run" the functions.
- Function -> Parameter references: When a function references a global constant (a Parameter), this induces an edge between the parameter and the function.

Relations are traversable: clients and tooling can evaluate predicates across the full domain (e.g., for all `prime in EligiblePrime`) and across Cartesian products (e.g., `EligiblePrime × StableCoinAsset`). Types make these edges explicit and safe to analyze without executing specs.

## Building Blocks

### Documentation and Provenance

- Prefer function docstrings for descriptive text. Put the human‑readable description of what a formula does into the function’s docstring. Docstrings are code‑adjacent, IDE/hover friendly, and can be used to generate documentation.
- As functions are also math formulas and documentation from docstrs will also be used for the mathematical exposition, avoid Python specific terminology.
- Avoid duplicating long‑form descriptions in metadata.
- Put Atlas provenance in docstrings using reST-style fields such as `:source_uuid: ...`.
- In `python/axis_synome/src/**/formulas/*.py`, public functions are treated as formulas by convention, so plain return types like `-> float` or `-> bool` are preferred.
- Outside formula modules, docstring fields such as `:source_uuid:` provide explicit opt-in for formula discovery.
- For constants and parameters, use `Final[...]` and trailing string literal docstrings.
- Avoid per‑formula READMEs. Prefer generating documentation from docstrings to keep content in sync with code.

Examples:

```python
def asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """
    Total Actively Stabilizing Capital for a prime.

    Sum of resting and latent ASC for a given prime over its positions.

    :source_uuid: 62495dee-8d2a-45d4-87c4-01150e3db3c8
    """
    ...


# If no corresponding Atlas section exists, just omit the marker and keep the docstring:


def asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """
    Total Actively Stabilizing Capital for a prime.

    Sum of resting and latent ASC for a given prime over its positions.
    """
    ...
```

### Parameters

- Use `Final[T]` for governance‑set constants.
- Parameter names plus structured docstring markers like `:source_uuid:` provide machine‑readable identities used in the graph, audits, and codegen. Place human‑readable descriptions in trailing constant docstrings.

### Units

TBD; placeholder section for now

Units will be managed through ouput types of functions and by setting the value of variables.
Specific unit types are introduced as part of entities definition files.

For instance, a float-compatible `usd` type may be introduced (this is used in some examples below, but note that types are still very much WIP)


### Parameters

- Represent global parameters as module‑level, annotated constants.
- Use `typing.Final` as the constant marker and place descriptive text and Atlas provenance in the trailing string literal docstring.
- When parameters vary per entity (e.g., per Prime), model them as fields on the entity dataclass with validation (e.g., `pydantic.dataclasses.dataclass` + `Field`).
- If a constant has no relevant Atlas section, just omit the `:source_uuid:` marker and provide the human description as the trailing string literal docstring.

Example:

```python
from typing import Final

MAX_LATENT_ASC: Final[usd] = 0.25  # usd is a floating point value compatible with Python float
"""Maximum latent ASC fraction.

:source_uuid: 5e300cdb-b221-4b6f-9c4a-11502133a1f9
"""
```

Constant descriptions (docstrings)

- For constants, place the human‑readable description as a bare string literal immediately following the assignment. The parser treats this trailing string as the constant’s “docstring” and extracts it into the graph.
- Keep `source_uuid` and other structured fields in the trailing docstring using markers such as `:source_uuid: ...`.

Example:

```python
from typing import Final

DAB_REQUIRED_PCT: Final[float] = 0.25
"""Required DAB as a fraction of total ASC.

:source_uuid: 1e129119-a2ce-4978-b235-c50f2a1c5e2e
"""
```

---

### Entities and Types

- Use pydantic `@dataclass` with typed fields; prefer other dataclasses and Enums for fields over plain primitives when possible.
- Encode static boolean attributes via set membership (Enums over instances of the class) rather than booleans on the class, enabling closed‑world restrictions in function signatures.
- Avoid nullable fields; they force conditional logic and complicate math mapping. If unavoidable, centralize adaptation before formulas.

Entities that are defined in the Atlas (and subject to governance) and defined as concrete instances of the respective dataclass objects. For instance, a PrimeAgent is a concrete instantiation of the PrimeAgent dataclass, e.g.,
```python
SKYBASE = PrimeAgent(name="Skybase")
```

Some dataclasses do not have concrete instances defined in entities - these merely serve as interface types to interact with formula functions. An example on such a class is the Position dataclass:

```python
from pydantic.dataclasses import dataclass
from axis_synome.spec.asc.entities.tokens import (
    TokenSymbol,
)  # TokenSymbol is an Enum, i.e, a closed-set
from axis_synome.spec.asc.entities.protocol_sets import Protocol  # Ditto
from axis_synome.spec.asc.entities.prime_agents import SpecificPrimeAgent  # Ditto


@dataclass(frozen=True)
class Position:
    token: TokenSymbol
    protocol: Protocol
    value_usd: Annotated[float, Field(gt=0)]
    owner: SpecificPrimeAgent
```

Note that all entity fields are typed to a closed set, the set of allowed values are in each case
a fixed set instiantiated objects. `value_usd` is additionally restricted with an annotation ensuring that only positive values are supplied.

#### Entities Layout (Formula‑Local vs Common)

- Start formula‑local: keep entities within each formula’s package initially (`axis/<formula>/entities/`).
- Uplift to shared only when needed: introduce shared entities at top level (`axis/entities/`) when the same entities are used by multiple formulas and sharing materially reduces duplication. A pragmatic threshold is when a third, independent formula reuses the same entities.
- Don’t add empty common folders: only create and populate shared folders when you actually have shared entities.
- Moving entities is a breaking change: import paths change when uplifting to shared. Provide re‑exports where feasible during transitions and bump the major version when breaking import paths.
### Formulas

- Formula functions are pure: `(inputs) -> output`, but process inputs to intermediate values by calling other formula functions (or by utilizing a restricted set of built-in functions and external functions)
- In formula modules, prefer plain return types and put structured provenance such as `source_uuid` in the docstring. Outside formula modules, docstring fields such as `:source_uuid:` provide explicit opt-in.
- They accept closed‑world Enums to encode eligibility and preconditions; use union types for overlapping eligible sets when needed.
- Compose helpers; keep inclusion/exclusion criteria explicit in docstrings.

#### Language subset (enforced)
- No mutation: No `a = a + 5`, `list.append`, in‑place ops.
- No name shadowing: each local variable must be assigned exactly once per function. Reassignments are not allowed. Error: "Name 'X' is shadowed (reassigned); each symbol must have a unique, unambiguous source."
- No conditional definitions: `if/else` control flow is allowed, but assignments inside conditional branches are not. Use ternary expressions (`x if cond else y`) for conditional values. Error: "Conditional assignments are not allowed; refactor into separate functions with explicit typing."
- No import shadowing: do not assign to a variable that shadows an imported name (e.g., `from axis_synome.spec.asc import denominator; denominator = ...`). Error: "Name 'X' shadows an import; use a unique local name or call the imported function directly."
- No imperative control flow: avoid `while`, `break`, `continue`, and exceptions.
- Allowed declarative constructs: list/generator comprehensions, conditional expressions (`x if cond else y`), and `range()` strictly within comprehensions.
- Imports: Only within the spec itself plus `math` and approved support packages.
- No side effects: No I/O, network, or filesystem.
- Disallowed in formulas: class definitions, nested function definitions, and dict/set literals or comprehensions.

Extractor‑friendly arithmetic: scalar ops, `sum`, `min`/`max`, `math.sqrt`, and ternary conditionals. Avoid complex control flow; prefer simple, composable helpers.

**Examples**:

**Instead of reassignment (shadowing) — WRONG**:
```python
def compute(x: float) -> float:
    result = x * 2
    result = result + 1  # ❌ WRONG: 'result' reassigned (shadowing)
    return result
```

**Use assignments once — CORRECT**:
```python
def compute(x: float) -> float:
    doubled = x * 2
    final = doubled + 1  # ✓ CORRECT: unique name
    return final
```

**Instead of if/else for assignments — WRONG**:
```python
def penalty(concentration: float) -> float:
    if concentration > 0.30:  # ❌ WRONG: conditional assignment block
        penalty_value = 1.0 + (concentration - 0.30) / 0.70
    else:
        penalty_value = 1.0
    return penalty_value
```

**Use ternary expressions — CORRECT**:
```python
def penalty(concentration: float) -> float:
    excess = concentration - 0.30
    penalty_value = (
        1.0
        if concentration <= 0.30  # ✓ CORRECT: ternary expression
        else 1.0 + (excess / 0.70)
    )
    return penalty_value
```

#### Example

A simple example of a function is given below:

```python
def asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """
    Total Actively Stabilizing Capital for a prime.

    Computes the sum of resting and latent ASC for a given prime over its positions.
    """
    # Enum values are concrete PrimeAgent instances
    resting_asc_usd: float = resting_asc(positions)
    latent_asc_usd: float = latent_asc(prime, positions)
    return resting_asc_usd + latent_asc_usd
```

Function bodies should be simple and extractor‑friendly: prefer local variable bindings and a final return. Comprehensions and expression returns are allowed; avoid loops, mutation, and exceptions.

Each of those assignments induces a formula definition, `formula_id(resting_asc_usd) = ...`, where `formula_id(resting_asc_usd)` is a mapping of the local identifier `resting_asc_usd` to a global unique identifier.

Similarly, the return statement induces a formula definition, `formula_id(asc) = formula_id(resting_asc_usd) + formula_id(latent_asc_usd)`.

In formula modules, the function can just return a plain scalar type and carry provenance in the
docstring, e.g. `def asc(...) -> float: ...`.

#### Boolean functions as constraints


Boolean constraint functions that take closed‑world sets (e.g., `EligiblePrime`) or combinations (`EligiblePrime × StableCoinAsset`) are intended to hold for all such elements. Tooling should evaluate them across the full domain to verify compliance.

Specification functions that take one or more closed-world Entity argument are constraints that should hold true for **all** combinations of the matching inputs to the functions.

```python
def compliant_prime(
    prime: EligiblePrimeAgentASC,
) -> bool: ...
```

Multi-input constraints are evaluated across the Cartesian product of their closed-world domains:

For instance, we might have a constraint that two distinct primes do not share an asset:

```python
def portfolio_diversification(
    prime_a: PrimeAgentAll,
    prime_b: PrimeAgentAll,
) -> bool:
    """Verifies that no two distinct primes hold the same asset above a threshold.

    :source_uuid: 62495dee-8d2a-45d4-87c4-01150e3db3c8
    """
    return prime_a == prime_b or not (asset in prime_a.assets and asset in prime_b.assets)
```

Assuming that `PrimeAgentAll` is an Enum consisting of prime agent instances, tooling evaluates this constraint across the Cartesian product `PrimeAgentAll × PrimeAgentAll`, ensuring the predicate holds for all combinations where prime_a ≠ prime_b.


### Testing

- Happy‑path tests only (internal initially): provide one simple, end‑to‑end test per formula demonstrating basic execution flow. Avoid asserting on highly specific numerical guarantees unless essential; prefer sanity checks that exercise the graph and opaque boundaries.
- Location: keep tests under `python/axis_synome/tests/` organized by concept/module. Treat these as internal by default; they can be published later based on demand.
- Declarative first: specs are declarative and amenable to static verification; tests complement by documenting usage and catching regressions in opaque integrations.

#### Reference Implementations for Opaque Functions

- Opaque functions (e.g., ARIMA) are too complex to fully specify as pure math. To execute happy‑path tests, provide a minimal “test math engine” or reference implementation used only by tests.
- Do not publish as an official runtime dependency initially. If users request a ready‑made engine, consider publishing a separate package later.
- Multiple valid approaches may exist; tests should pick one concrete implementation as an example without constraining others.


## Starter Template

Start a new spec module with (simplified example; in real modules, entities typically live in their own package folder):

```python
# parameters.py
from typing import Final

THRESHOLD: Final[float] = 1_000_000.0
"""Example threshold constant.

:source_uuid: 62495dee-8d2a-45d4-87c4-01150e3db3c8
"""
```

```python
# entities/items.py
from dataclasses import dataclass
from enum import Enum


@dataclass(frozen=True)
class Item:
    owner: str
    value_usd: float


class EligibleOwner(Enum):
    ALPHA = "Alpha"
    BETA = "Beta"


# Closed‑world set of item instances
class ItemSet(Enum):
    ITEM_A = Item(owner="Alpha", value_usd=500_000.0)
    ITEM_B = Item(owner="Beta", value_usd=1_500_000.0)
```

```python
# formulas.py
from .parameters import THRESHOLD
from .entities.items import ItemSet, EligibleOwner


# Example relation across closed‑world sets (owner × item)
def item_owned_by(owner: EligibleOwner, item: ItemSet) -> bool:
    return item.value.owner == owner.value


# Structured Enum inputs and composition
# (functions take Enums whose members are structured dataclasses, and call other spec functions)


def item_value(item: ItemSet) -> float:
    return item.value.value_usd


def owner_item_value(owner: EligibleOwner, item: ItemSet) -> float:
    # Calls two spec helpers: a predicate and a value projector
    return item_value(item) if item_owned_by(owner, item) else 0.0


def total_value(
    owner: EligibleOwner,
) -> float:
    """Total value for an eligible owner.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    # Computes over the closed‑world ItemSet domain
    return sum(owner_item_value(owner, it) for it in ItemSet)


def threshold_satisfied(owner: EligibleOwner) -> bool:
    # Boolean constraint calling another spec function
    return total_value(owner) >= THRESHOLD
```

## Allowed Python Subset (author‑facing)

- Allowed
  - Expressions: arithmetic, boolean ops, comparisons, ternary `x if c else y`.
  - Aggregators: `sum`, `min`, `max`, `any`, `all` over generator expressions.
  - Generator expressions and simple `range(...)` where needed.
  - Selected `math.*` (e.g., `log`, `exp`, `sqrt`, `pow`).
  - Imports from `axis_synome.spec`, `synome`, `typing`, `dataclasses`, `enum`, `pydantic`, and bare `math`.

- Avoid / Disallowed
  - Mutation, I/O, networking, side effects; exceptions and `try/except`.
  - Dict/set comprehensions; f‑strings; walrus `:=`; `yield`/`await`/`async`.
  - Methods in dataclasses/Enums; nested function defs inside formulas.
  - For‑loops inside formulas: permitted for variable tracking only; not converted by the parser. Prefer generator expressions + aggregators.

- Violations and fixes (common patterns)
  - For‑loop → Use `sum(expr for x in xs)` / `any(...)` / `all(...)`.
  - List comprehension → Use a generator expression.
  - Dict/set comprehension → Move structure to entities or precompute outside formulas.
  - Unapproved builtin/import → Use only allowlisted builtins/import prefixes.
  - Methods in dataclasses/Enums → Move logic to free functions.

## Parser Support

The parser extracts formulas from typed Python by walking the function AST and lowering supported constructs to SymPy. Highlights and limits:

- Expressions supported (convert_python_to_sympy):
  - Literals: bool, int, float; strings become symbols.
  - Names and attribute access; `base__attr` flattened as `attr(base)` symbolically.
  - Unary: `-x`, `+x`, `not x`.
  - Binary: `+`, `-`, `*`, `/`, `**`, `%`, `//` (as uninterpreted function).
  - Boolean ops: `and`, `or`.
  - Comparisons: `> >= < <= == !=` (non‑eager relational classes).
  - Ternary: `a if cond else b` → SymPy `Piecewise`.
  - Generators with `range(...)` in comprehensions; start/stop supported, step must be 1.
  - Subscripts: `x[i]` → `IndexedBase('x')[i]`; tuple/slice mapped to SymPy tuple.
  - Calls: `sum(...)` lowering for simple generator/list patterns; `min`/`max`; `float('inf')`; unknown calls become uninterpreted `Function(name)(...)`.
  - `any(...)` / `all(...)` over a single generator: lowered to a predicate array and an aggregator Function with bounds.
  - `math.log/exp/sqrt/pow` mapped to SymPy; other `math.*` become namespaced uninterpreted functions.
  - List/Generator comprehensions that aren’t lowered become placeholder symbols.

- Statements supported (statement_handler):
  - Assignments and annotated assignments emit intermediate formulas; underscore‑prefixed locals are inlined only.
  - Tuple destructuring: `a, b = ...` emits per‑name formulas; also supports destructuring of call results.
  - if/else statements: merged into `Piecewise` expressions (first assignment per name in each branch).
  - Returns: simple name (renamed to final), tuple returns (per‑element formulas), list‑comprehension returns (element equality + array symbol), `all/any` over a single generator (predicate array + aggregator function), normal expressions.
  - Special sum(...) expansion: expands a single‑generator `sum(expr for v in LIST)` where `LIST` was defined earlier as a list literal captured by the handler.

- Known limits:
  - for‑loops are not converted (only variable tracking); use comprehensions + `sum(...)` patterns.
  - Exceptions, class definitions, and nested function definitions inside formulas are not supported.
  - Multiple generators, complex iterables, or range steps other than 1 are skipped.
  - Dict literals and dict comprehensions are disallowed in formulas. Set comprehensions are not currently supported by the parser; if used, they will not be converted and may fallback to uninterpreted forms.
  - Exceptions and side effects are out of scope by design.

Formula extraction: in `python/axis_synome/src/**/formulas/*.py`, the parser treats public functions as formulas by convention and reads `source_uuid` from docstring fields such as `:source_uuid: ...`. Outside formula modules, those docstring fields remain the explicit opt-in. Prefer putting descriptions in docstrings; units are not required and can be documented there as needed.

---

## Validation & Tooling

Use the Makefile targets to run checks consistently:

- Lint (ruff): `make lint` → `uv run ruff check .`
- Format (ruff): `make format` or `make format-check`
- Specs lint (flake8 in specs): `make lint-specs` (runs from `python/axis_synome/`)
- Type check (Ty): `make typecheck` (runs `ty check` for `src/` and `explorations/`)
- All checks: `make check-all`

### Motivation

- Keep specs both human-friendly and machine-verifiable. Authors write normal, readable Python, while tools guarantee the code stays inside a safe, declarative subset that the parser can lower to SymPy.
- Prevent parser surprises. The spec validator rejects constructs the parser cannot reliably translate (e.g., arbitrary loops, side effects), so extraction remains deterministic and auditable.
- Preserve the dependency graph. Strong, explicit types on entities, parameters, and formula signatures allow static traversal of relationships without executing code.

### What Each Tool Checks

- Ruff (style/quality)
  - Enforces consistent formatting and a curated lint set across the repo. It does not encode spec-subset rules; treat its feedback as code hygiene and readability improvements.
  - Run: `make lint` for checks, `make fix` to auto-fix, `make format` for formatting.

- Flake8 (spec-subset validator)
  - In `python/axis_synome/`, Flake8 runs a custom plugin that emits AXS00x errors when a file uses constructs outside the allowed subset defined in `axis_synome.spec_validator.python_subset`.
  - Examples of disallowed patterns: nested functions in formulas, methods in dataclasses/Enums, non-whitelisted imports, f-strings, dict/set comprehensions, `try/except`, `yield`, walrus `:=`, unapproved builtins.
  - Only spec files are validated by the plugin; editor integrations surface these as AXS diagnostics.
  - Run: `make lint-specs` (executes from `python/axis_synome/`).

- Ty (static type checking)
  - Validates function signatures, dataclass fields, and return types across runtime code and specs. Types must line up; otherwise the graph edges inferred from signatures become unsound.
  - Encourages narrow, precise types on inputs/outputs (e.g., closed-world Enums, `Final`, and precise scalar return types).
  - Run: `make typecheck`.

### How Checks Align With The Parser

- Single source of truth for the subset. The same allowlist powering the Flake8 plugin (`axis_synome.spec_validator.python_subset`) is used by the parser when walking function ASTs to produce SymPy. If Flake8 passes, the parser will not encounter unexpected statement/expression kinds.
- Safe constructs are lowered deterministically. Comprehensions, boolean ops, comparisons, `sum/min/max`, selected `math.*`, and simple conditionals become SymPy expressions or uninterpreted functions with clear bounds.
- Disallowed constructs block extraction early. If you see an `AXS001 ... is not allowed` error, change the code to an allowed equivalent (e.g., use a generator expression and `sum(...)` instead of a loop; prefer ternary `x if c else y` over complex branching inside expressions).

### Types And The Graph

- Signatures define edges. A formula like `def asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float` induces edges from each `EligiblePrimeAgentASC` member to `asc`, and from any sub-formulas it calls to `asc`.
- Closed-world Enums enable universal and product quantification. Boolean constraints over Enums are checked over all members or Cartesian products without execution, thanks to types.
- Entities and parameters carry semantics. Dataclass fields typed to domain-specific classes and typed constants such as `Final[T]` provide machine-readable identities; `source_uuid` comes from docstring markers such as `:source_uuid:` and is used in graph labeling, audits, and downstream codegen. Place long‑form descriptions in docstrings.
- Type checking safeguards graph integrity. If you widen a type (e.g., `Any` or a loose `str`) you reduce the graph’s precision; Ty will highlight mismatches so specs remain traversable and analyzable.

### Typical Violations And Fixes

- For-loops inside formulas → Replace with generator expressions plus `sum(...)`, `any(...)`, or `all(...)`.
- Dict/set comprehensions → Move structure-building to entities or use lists/tuples; keep formula bodies expression-centric.
- Unapproved builtins/imports → Use only builtins in the allowlist and imports under permitted prefixes (`axis_synome.spec`, `typing`, `dataclasses`, `enum`, `pydantic`, `synome`, or `math`).
- Methods in dataclasses/Enums → Move logic into free functions; limit classes to annotated fields (dataclasses) or constant members (Enums).
- Missing/loose types → Add precise argument and return annotations; prefer closed-world Enums where policy implies eligibility.

### CI Expectations

- PRs changing specs must pass: `make lint-specs`, `make typecheck`, and style checks via Ruff. This ensures the parser can extract formulas, the dependency graph remains sound, and code stays readable.

---

### AXS quick reference (representative messages)

- decorators are not allowed on spec functions
- list comprehensions are not allowed (use generator expressions)
- only @dataclass classes are allowed / methods are not allowed in dataclasses
- methods are not allowed in Enum classes
- import "X" is not allowed / import from "X" is not allowed
- builtin "open" is not allowed; permitted builtins: [...]
- f-strings are not allowed

---

## Math-to-Python-Spec Examples

These hypothetical examples show how mathematical expression/equations can be converted into an equivalent spec representation.

1) Portfolio USD value

$\mathrm{PortfolioUSD} = H_{\mathrm{USDC}} + H_{\mathrm{USDT}} + H_{\mathrm{USDS}} +  H_{\mathrm{DAI}}$

```python
def portfolio_usd(h_usdc: float, h_usdt: float, h_usds: float, h_dai: float) -> float:
    """Total USD across stablecoin holdings.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    holdings = [("USDC", h_usdc), ("USDT", h_usdt), ("USDS", h_usds), ("DAI", h_dai)]
    total: float = sum(value for _, value in holdings)
    return total
```

2) Collateralization (margin and boolean predicate)

$\mathrm{margin} = \dfrac{\mathrm{assetsUSD}}{\mathrm{debtUSD}} - \mathrm{minRatio}$

$\mathrm{collateral\_ratio\_satisfied} \iff \mathrm{margin} \ge 0$

```python
def collateral_ratio_margin(assets_usd: float, debt_usd: float, min_ratio: float) -> float:
    """Collateral ratio minus minimum.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    ratio: float = assets_usd / debt_usd
    margin: float = ratio - min_ratio
    return margin


def collateral_ratio_satisfied(assets_usd: float, debt_usd: float, min_ratio: float) -> bool:
    """True when collateral ratio meets or exceeds the minimum.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    return collateral_ratio_margin(assets_usd, debt_usd, min_ratio) >= 0.0
```

3) Volatility haircut (piecewise via ternary)

$\mathrm{haircut}(\sigma_{30\mathrm{d}}) = \begin{cases}
  0.02, & \sigma_{30\mathrm{d}} < 0.2 \\
  0.05, & \text{otherwise}
\end{cases}$

```python
def volatility_haircut(
    vol_30d: float,
) -> float:
    """Haircut by 30d volatility threshold.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    return 0.02 if vol_30d < 0.2 else 0.05
```

4) Venue concentration cap

$T = U_{\mathrm{PSM}} + U_{\mathrm{Curve}} + U_{\mathrm{Uni}}$

$w_{\mathrm{PSM}}=U_{\mathrm{PSM}}/T,\quad w_{\mathrm{Curve}}=U_{\mathrm{Curve}}/T,\quad w_{\mathrm{Uni}}=U_{\mathrm{Uni}}/T$

$\max\{w_{\mathrm{PSM}}, w_{\mathrm{Curve}}, w_{\mathrm{Uni}}\} \le \mathrm{cap}$

```python
def max_venue_concentration(psm_usd: float, curve_usd: float, uni_usd: float, cap: float) -> bool:
    """True when the maximum venue share is at or below the cap.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    total: float = psm_usd + curve_usd + uni_usd
    w_psm: float = psm_usd / total
    w_curve: float = curve_usd / total
    w_uni: float = uni_usd / total
    return max(w_psm, w_curve, w_uni) <= cap
## Quickstart

- Purpose
  - Make specs both human‑readable and machine‑verifiable.
  - Keep all formulas declarative and side‑effect‑free for deterministic parsing.
  - Use types (dataclasses, Enums, precise signatures) to encode policy and traversable relations.

- Minimal template
  - Parameters: `Final[T]` for governance‑set constants, with provenance in trailing docstrings.
  - Entities: frozen dataclasses and closed‑world Enums of concrete instances.
  - Formulas: pure functions over these types with precise return types; put provenance in docstrings.

- Do / Don’t (subset cheat‑sheet)
  - Do: use generator expressions + `sum/min/max/any/all`, ternary `x if c else y`, selected `math.*`, and composition of small helpers.
  - Don’t: mutate state, raise/try/except, use dict/set comprehensions, f‑strings, walrus `:=`, I/O, or unapproved imports/builtins.

- Author loop
  - `make lint-specs` (subset validation via Flake8 AXS plugin)
  - `make typecheck` (static typing with Ty)
  - `make check-all` (style + subset + types)

```

5) Present value of discounted cash flows

$\mathrm{PV} = \sum_{i=0}^{n-1} \dfrac{\mathrm{CF}_i}{(1+r)^{i+1}}$

```python
def present_value(cashflows: list[float], r: float) -> float:
    """Present value of discounted cash flows.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    n: int = len(cashflows)
    return sum(cashflows[i] / (1.0 + r) ** (i + 1) for i in range(n))
```

6) All positions above a threshold (universal predicate)

$\forall i \in \{0,\dots,n-1\}:\; p_i \ge \tau$

```python
def all_positions_above(positions: list[float], threshold: float) -> bool:
    """All positions above a threshold.

    :source_uuid: DOC-EXAMPLE-UUID
    """
    return all(p >= threshold for p in positions)
```

## Opaque Functions (Use Sparingly)

Use only when the operation cannot be expressed in the allowed, parser‑friendly subset, or is so complex (e.g., ARIMA/GARCH/ML/DNN) that a full mathematical spec is infeasible. Prefer parser‑friendly constructs first (comprehensions + sum/min/max/any/all, simple math.*, scalar per‑element helpers).

- Approach 1 — PascalCase (Uninterpreted Function)
  - What: a normal spec function that the parser represents as an uninterpreted SymPy function; prints clearly and composes symbolically.
  - When: you need a symbolic placeholder; runtime can be pure‑Python or evaluation isn’t required in tests. Good for things like ArgMaxIndex(values).
  - How: define a plain function in the spec with a pure‑Python implementation and precise types; try to keep it as declarative as possible even though it is not translated to math, i.e., it still should throw exceptions or have side-effects.

- Approach 2 — Spec Wrapper + MathEngine (External Packages)
  - What: a thin spec wrapper that delegates to a pluggable runtime engine (installed via `set_engine`). The parser treats the call as uninterpreted; runtime can use NumPy/StatsModels/etc.
  - When: the operation truly requires external packages or model fitting (e.g., rolling_var, GARCH/ARIMA); you need production‑grade runtime while keeping the spec parseable.
  - How:
    - Define engine contract (add to your project’s `opaque/engine.py`):
      - `class MathEngine(ABC):`
        - `@abstractmethod`
        - `def rolling_var(self, returns: list[float], window: int, confidence: float) -> list[float]: ...`
    - Add thin wrapper in an opaque module (e.g., `axis/.../opaque/statistical.py`) that simply calls `get_engine().rolling_var(...)`.
    - Provide/install an engine in tests/apps: `from axis_synome.spec.ima.opaque import set_engine; set_engine(ReferenceMathEngine())`.

- Authoring Rules
  - Keep wrappers zero‑logic (no exceptions/branching); just delegate to `get_engine()`.
  - Use precise, stable types and consistent snake_case names.
  - Briefly document new opaque functions in `opaque/README.md` (purpose, signature, runtime notes).

## Atlas Integration

- Keep Atlas UUIDs in docstrings using `:source_uuid: ...` when available. If no Atlas section applies, omit the marker entirely.
- Prefer docstrings in specs as the authoritative descriptive source. Atlas Markdown pages can be “hollowed out” to minimal anchors that link back to Synome specs and reuse docstrings when possible. This approach avoids duplicate, drifting descriptions. Pending Atlas Access team alignment.

## Versioning and Backwards Compatibility

- Early phase: limited backwards‑compatibility promises. We may iterate quickly across major versions.
- Breaking changes (e.g., moving entities from formula‑local to shared `axis/entities/`, changing import paths) require a major version bump.
- Where feasible, provide temporary re‑exports/shims to ease upgrades, but prefer clarity over long‑term indirection.
