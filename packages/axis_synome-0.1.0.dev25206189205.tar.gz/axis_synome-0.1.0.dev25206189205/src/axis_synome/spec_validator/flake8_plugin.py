"""Flake8 plugin adapter for the spec subset validator.

Wraps the existing SpecChecker so editors (VS Code, PyCharm) can show
spec-validation errors as inline diagnostics.

Error codes use the ``AXS`` prefix (e.g. ``AXS001``).
"""

from __future__ import annotations

import ast
from collections.abc import Generator
from pathlib import Path

from .checker import SKIP_MARKER, SpecChecker


class SpecSubsetChecker:
    """Flake8 AST checker that delegates to :class:`SpecChecker`."""

    name = "synome-spec-validator"
    version = "0.1.0"

    def __init__(self, tree: ast.AST, filename: str) -> None:
        self._tree = tree
        self._filename = filename

    def run(self) -> Generator[tuple[int, int, str, type], None, None]:
        # Only check spec files (under axis_synome/spec/), skip the validator's own code.
        path = Path(self._filename)
        parts = path.parts + path.resolve().parts
        if "axis_synome" not in parts:
            return
        if "spec_validator" in parts:
            return
        if "spec" not in parts:
            return

        # Respect the skip marker on the first line.
        try:
            with Path(self._filename).open() as f:
                first_line = f.readline()
            if SKIP_MARKER in first_line:
                return
        except OSError:
            pass

        checker = SpecChecker(self._filename)
        checker.visit(self._tree)

        for lineno, col_offset, msg in checker.structured_errors:
            yield (lineno, col_offset, f"AXS001 {msg}", type(self))
