"""Spec validator: checks that spec files use only an allowed subset of Python."""

from .checker import SpecChecker, validate_file

__all__ = ["SpecChecker", "validate_file"]
