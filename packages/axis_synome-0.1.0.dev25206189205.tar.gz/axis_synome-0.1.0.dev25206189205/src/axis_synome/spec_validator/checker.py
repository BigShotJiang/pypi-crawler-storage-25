"""AST-based checker that validates spec files use only an allowed Python subset."""

import ast
import builtins
from pathlib import Path

from axis_synome.spec_validator.python_subset import (
    ALLOWED_BARE_IMPORTS,
    ALLOWED_BUILTINS,
    ALLOWED_EXPRESSION_TYPES,
    ALLOWED_FROM_IMPORT_PREFIXES,
    ALLOWED_FUNCTION_BODY_STATEMENTS,
    ALLOWED_MATH_FUNCTION_NAMES,
    ALLOWED_MODULE_CALL_PREFIXES,
    ALLOWED_MODULE_STATEMENTS,
)

_PYTHON_BUILTINS: frozenset[str] = frozenset(dir(builtins))

SKIP_MARKER = "# validate-spec: skip"


class SpecChecker(ast.NodeVisitor):
    """Walks an AST and collects errors for constructs outside the allowed subset."""

    def __init__(self, filename: str) -> None:
        self.filename = filename
        self.errors: list[str] = []
        self.structured_errors: list[tuple[int, int, str]] = []
        self._in_function = False
        self._module_imported_names: set[str] = set()  # Track imports for shadowing detection
        self._function_assigned_names: set[str] = set()  # Track assignments for shadowing detection

    def _error(self, node: ast.AST, msg: str) -> None:
        lineno = getattr(node, "lineno", 0)
        col_offset = getattr(node, "col_offset", 0)
        self.errors.append(f"Line {lineno}: {msg}")
        self.structured_errors.append((lineno, col_offset, msg))

    def generic_visit(self, node: ast.AST) -> None:
        """Apply expression allowlist checks for nodes without explicit handlers."""
        if isinstance(node, ast.expr) and type(node) not in ALLOWED_EXPRESSION_TYPES:
            self._error(node, f"{type(node).__name__} expressions are not allowed")
            return
        super().generic_visit(node)

    # ------------------------------------------------------------------
    # Module level
    # ------------------------------------------------------------------

    def visit_Module(self, node: ast.Module) -> None:
        # Validate trailing string literal constant docstrings where present.
        self._validate_constant_docstrings(node)
        # Pre-scan for imported names for shadowing detection
        for stmt in node.body:
            if isinstance(stmt, (ast.Import, ast.ImportFrom)):
                for alias in stmt.names:
                    self._module_imported_names.add(alias.asname or alias.name)

        # Validate module structure
        for stmt in node.body:
            if type(stmt) not in ALLOWED_MODULE_STATEMENTS:
                # Dispatch to explicit visit_* handlers for nice error messages.
                # Fall back to a generic error if no handler exists.
                method = getattr(self, f"visit_{type(stmt).__name__}", None)
                if method:
                    method(stmt)
                else:
                    self._error(stmt, f"{type(stmt).__name__} is not allowed at module level")
            else:
                self.visit(stmt)

    def _validate_constant_docstrings(self, node: ast.Module) -> None:
        """Validate trailing string literal docstrings for documented constants."""
        body = list(getattr(node, "body", []))
        for i, stmt in enumerate(body):
            target: ast.Name | None = None
            if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                target = stmt.target
            elif (
                isinstance(stmt, ast.Assign)
                and len(stmt.targets) == 1
                and isinstance(stmt.targets[0], ast.Name)
            ):
                target = stmt.targets[0]

            if target is None or not target.id.isupper():
                continue

            if i + 1 < len(body):
                nxt = body[i + 1]
                if isinstance(nxt, ast.Expr) and isinstance(
                    getattr(nxt, "value", None), ast.Constant
                ):
                    val = nxt.value
                    if isinstance(getattr(val, "value", None), str) and not str(val.value).strip():
                        self._error(
                            stmt,
                            f"Constant '{target.id}' trailing string literal docstring must not be empty",
                        )

    # ------------------------------------------------------------------
    # Function definitions
    # ------------------------------------------------------------------

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        if self._in_function:
            self._error(node, "nested function definitions are not allowed")
            return

        if node.decorator_list:
            self._error(node, "decorators are not allowed on spec functions")

        was_in_function = self._in_function
        self._in_function = True
        prev_assigned_names = self._function_assigned_names
        self._function_assigned_names = set()  # Reset for each function scope
        try:
            for stmt in node.body:
                if type(stmt) not in ALLOWED_FUNCTION_BODY_STATEMENTS:
                    method = getattr(self, f"visit_{type(stmt).__name__}", None)
                    if method:
                        method(stmt)
                    else:
                        self._error(
                            stmt,
                            f"{type(stmt).__name__} is not allowed in function bodies",
                        )
                else:
                    # Check for shadowing before processing
                    if isinstance(stmt, (ast.Assign, ast.AnnAssign)):
                        self._check_assignment_shadowing(stmt)
                    self.visit(stmt)
        finally:
            self._in_function = was_in_function
            self._function_assigned_names = prev_assigned_names

    # ------------------------------------------------------------------
    # Imports
    # ------------------------------------------------------------------

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            if alias.name not in ALLOWED_BARE_IMPORTS:
                self._error(node, f'import "{alias.name}" is not allowed')

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        top_level = module.split(".")[0]
        if top_level not in ALLOWED_FROM_IMPORT_PREFIXES:
            self._error(node, f'import from "{module}" is not allowed')

    # ------------------------------------------------------------------
    # Names
    # ------------------------------------------------------------------

    def visit_Name(self, node: ast.Name) -> None:
        if node.id.startswith("_") and node.id != "_":
            self._error(node, f'"{node.id}" starts with "_"')
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr.startswith("_") and node.attr != "_":
            self._error(node, f'attribute "{node.attr}" starts with "_"')
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Function calls
    # ------------------------------------------------------------------

    def visit_Call(self, node: ast.Call) -> None:
        self._check_call_target(node)
        self.generic_visit(node)

    def _check_call_target(self, node: ast.Call) -> None:
        func = node.func

        # math.log(...) etc.
        if (
            isinstance(func, ast.Attribute)
            and isinstance(func.value, ast.Name)
            and func.value.id in ALLOWED_MODULE_CALL_PREFIXES
        ):
            if func.attr not in ALLOWED_MATH_FUNCTION_NAMES:
                self._error(
                    node,
                    f'"{func.attr}" is not an allowed math function: '
                    f"{sorted(ALLOWED_MATH_FUNCTION_NAMES)}",
                )
            return

        if isinstance(func, ast.Name):
            name = func.id
            # Only a curated set of Python builtins is allowed.
            if name in _PYTHON_BUILTINS and name not in ALLOWED_BUILTINS:
                self._error(
                    node,
                    f'builtin "{name}" is not allowed; '
                    f"permitted builtins: {sorted(ALLOWED_BUILTINS)}",
                )
            # Everything else (user-defined functions, axis/synome imports)
            # is allowed.
            return

    # ------------------------------------------------------------------
    # Expressions — generic allowlist check
    # ------------------------------------------------------------------

    def visit_Expr(self, node: ast.Expr) -> None:
        self.visit(node.value)

    # Explicitly disallowed expression types with clear messages

    def visit_Lambda(self, node: ast.Lambda) -> None:
        self._error(node, "lambda expressions are not allowed")

    def visit_ListComp(self, node: ast.ListComp) -> None:
        self._error(node, "list comprehensions are not allowed (use generator expressions)")

    def visit_DictComp(self, node: ast.DictComp) -> None:
        self._error(node, "dict comprehensions are not allowed")

    def visit_SetComp(self, node: ast.SetComp) -> None:
        self._error(node, "set comprehensions are not allowed")

    def visit_JoinedStr(self, node: ast.JoinedStr) -> None:
        self._error(node, "f-strings are not allowed")

    def visit_NamedExpr(self, node: ast.NamedExpr) -> None:
        self._error(node, "walrus operator (:=) is not allowed")

    def visit_Yield(self, node: ast.Yield) -> None:
        self._error(node, "yield is not allowed")

    def visit_YieldFrom(self, node: ast.YieldFrom) -> None:
        self._error(node, "yield from is not allowed")

    def visit_Await(self, node: ast.Await) -> None:
        self._error(node, "await is not allowed")

    # Explicitly disallowed statement types

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        if not self._in_function and type(node) in ALLOWED_MODULE_STATEMENTS:
            # Allow Enum subclasses (e.g. class Foo(Enum): ...) and StrEnum subclasses.
            enum_names = {"Enum", "StrEnum", "IntEnum", "IntFlag", "Flag"}
            is_enum = any(
                (isinstance(b, ast.Name) and b.id in enum_names)
                or (isinstance(b, ast.Attribute) and b.attr in enum_names)
                for b in node.bases
            )
            if is_enum:
                for stmt in node.body:
                    if isinstance(stmt, ast.Assign):
                        continue
                    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant):
                        continue  # docstring
                    if isinstance(stmt, ast.FunctionDef):
                        self._error(stmt, "methods are not allowed in Enum classes")
                    else:
                        self._error(stmt, f"{type(stmt).__name__} is not allowed in Enum classes")
                return
            # Only @dataclass or @validated_dataclass decorated classes are allowed.
            allowed_dataclass_decorators = {"dataclass", "validated_dataclass"}
            if not any(
                (isinstance(d, ast.Name) and d.id in allowed_dataclass_decorators)
                or (isinstance(d, ast.Attribute) and d.attr in allowed_dataclass_decorators)
                for d in node.decorator_list
            ):
                self._error(node, "only @dataclass classes are allowed")
                return
            # Validate the class body: only annotated assignments and docstrings.
            for stmt in node.body:
                if isinstance(stmt, ast.AnnAssign):
                    continue
                if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant):
                    continue  # docstring
                if isinstance(stmt, ast.FunctionDef):
                    self._error(stmt, "methods are not allowed in dataclasses")
                else:
                    self._error(stmt, f"{type(stmt).__name__} is not allowed in dataclasses")
            return
        self._error(node, "class definitions are not allowed")

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._error(node, "async functions are not allowed")

    def visit_With(self, node: ast.With) -> None:
        self._error(node, "with statements are not allowed")

    def visit_AsyncWith(self, node: ast.AsyncWith) -> None:
        self._error(node, "async with statements are not allowed")

    def visit_AsyncFor(self, node: ast.AsyncFor) -> None:
        self._error(node, "async for statements are not allowed")

    def visit_Try(self, node: ast.Try) -> None:
        self._error(node, "try/except is not allowed")

    def visit_TryStar(self, node: ast.TryStar) -> None:
        self._error(node, "try/except* is not allowed")

    def visit_Raise(self, node: ast.Raise) -> None:
        self._error(node, "raise is not allowed")

    def visit_Assert(self, node: ast.Assert) -> None:
        self._error(node, "assert is not allowed")

    def visit_Delete(self, node: ast.Delete) -> None:
        self._error(node, "del is not allowed")

    def visit_Global(self, node: ast.Global) -> None:
        self._error(node, "global statements are not allowed")

    def visit_Nonlocal(self, node: ast.Nonlocal) -> None:
        self._error(node, "nonlocal statements are not allowed")

    def visit_Match(self, node: ast.Match) -> None:
        self._error(node, "match statements are not allowed")

    def visit_If(self, node: ast.If) -> None:
        # Allow conditional control flow, but keep assignment provenance unambiguous.
        self.visit(node.test)

        for branch in (node.body, node.orelse):
            for stmt in branch:
                if isinstance(stmt, (ast.Assign, ast.AnnAssign)):
                    self._error(
                        stmt,
                        "Conditional assignments are not allowed; refactor into separate functions with explicit typing.",
                    )
                    continue

                if type(stmt) not in ALLOWED_FUNCTION_BODY_STATEMENTS:
                    method = getattr(self, f"visit_{type(stmt).__name__}", None)
                    if method:
                        method(stmt)
                    else:
                        self._error(
                            stmt,
                            f"{type(stmt).__name__} is not allowed in function bodies",
                        )
                else:
                    self.visit(stmt)

    # ------------------------------------------------------------------
    # Shadowing detection
    # ------------------------------------------------------------------

    def _check_assignment_shadowing(self, node: ast.Assign | ast.AnnAssign) -> None:
        """Check for name shadowing (reassignment) and import shadowing."""
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]

        for target in targets:
            if isinstance(target, ast.Name):
                name = target.id
                # Check 0a: Name shadowing (reassignment within same function)
                if name in self._function_assigned_names:
                    self._error(
                        node,
                        f"Name '{name}' is shadowed (reassigned); each symbol must have a unique, unambiguous source.",
                    )
                # Check 0c: Import shadowing
                elif name in self._module_imported_names:
                    self._error(
                        node,
                        f"Name '{name}' shadows an import; use a unique local name or call the imported function directly.",
                    )
                else:
                    self._function_assigned_names.add(name)


def validate_file(path: Path) -> list[str] | None:
    """Validate a spec file against the allowed Python subset.

    Returns a list of error strings, an empty list if valid,
    or ``None`` if the file has a skip marker.
    """
    source = path.read_text()
    first_line = source.partition("\n")[0]
    if SKIP_MARKER in first_line:
        return None
    tree = ast.parse(source, filename=str(path))
    checker = SpecChecker(str(path))
    checker.visit(tree)
    return checker.errors
