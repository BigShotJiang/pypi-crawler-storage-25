"""Defines the allowed Python subset for spec files.

This is the single source of truth used by both:
- axis_synome.spec_validator (static validation / flake8 plugin)
- synome.parser (Python to SymPy conversion)
"""

import ast

#
# Statement types
#

ALLOWED_MODULE_STATEMENTS: frozenset[type] = frozenset({
    ast.FunctionDef,
    ast.ClassDef,
    ast.Import,
    ast.ImportFrom,
    ast.Expr,  # docstrings and standalone calls
    ast.Assign,
    ast.AnnAssign,
})

ALLOWED_FUNCTION_BODY_STATEMENTS: frozenset[type] = frozenset({
    ast.Assign,
    ast.AnnAssign,
    ast.Return,
    ast.If,
    ast.Expr,  # docstrings and standalone calls
})

#
# Expression types
#

ALLOWED_EXPRESSION_TYPES: frozenset[type] = frozenset({
    ast.BinOp,
    ast.UnaryOp,
    ast.Compare,
    ast.BoolOp,
    ast.IfExp,
    ast.Call,
    ast.Name,
    ast.Constant,
    ast.Attribute,
    ast.Tuple,
    ast.List,
    ast.Dict,  # Dict literals for parameters (not in formulas)
    ast.Set,  # Set literals for parameters (not in formulas)
    ast.GeneratorExp,
    ast.ListComp,  # List comprehensions
    ast.Subscript,
})

#
# Imports
#

ALLOWED_BARE_IMPORTS: frozenset[str] = frozenset({
    "math",
})

ALLOWED_FROM_IMPORT_PREFIXES: frozenset[str] = frozenset({
    "axis_synome",
    "dataclasses",
    "enum",
    "pydantic",
    "synome",
    "typing",
})

#
# Callable names
#

ALLOWED_BUILTINS: frozenset[str] = frozenset({
    # numeric and aggregation
    "min",
    "max",
    "sum",
    "abs",
    "round",
    # casting / constants
    "float",
    "int",
    # sequences and quantifiers supported by the parser
    "len",
    "range",
    "all",
    "any",
})

ALLOWED_MATH_FUNCTION_NAMES: frozenset[str] = frozenset({
    "log",
    "exp",
    "sqrt",
    "pow",
})

#
# Call patterns
#

ALLOWED_MODULE_CALL_PREFIXES: frozenset[str] = frozenset({
    "math",
})
