"""Formula metadata conveyed via ``Annotated`` return types.

This module lives in ``axis-common`` so that both spec files and the
synome parser can reference the canonical ``Metadata`` class without
introducing a circular dependency.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Metadata:
    """Formula metadata conveyed via ``Annotated`` return types.

    Spec functions annotate their return type to describe the formula
    without importing anything from synome::

        def my_func(...) -> Annotated[float, Metadata(description="...", source_uuid="...")]:
    """

    description: str = ""
    source_uuid: str = ""
