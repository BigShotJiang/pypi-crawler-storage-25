import os
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    # Type checkers see validated_dataclass as the standard dataclass decorator
    # so they can infer the generated __init__ signature correctly.
    validated_dataclass = dataclass
else:
    _VALIDATE = os.getenv("VALIDATION_DISABLED") != "1"

    def validated_dataclass(cls=None, **kwargs):
        """Dataclass decorator with pydantic validation enabled by default.

        Set ``VALIDATION_DISABLED=1`` to skip validation (e.g. in performance-critical paths)."""

        def wrap(cls):
            cls = dataclass(cls, **kwargs)

            if _VALIDATE:
                from pydantic import TypeAdapter

                adapter = TypeAdapter(cls)
                original_init = cls.__init__

                def _validated_init(self, **data):
                    adapter.validate_python(data)
                    original_init(self, **data)

                cls.__init__ = _validated_init

            return cls

        if cls is None:
            return wrap
        return wrap(cls)
