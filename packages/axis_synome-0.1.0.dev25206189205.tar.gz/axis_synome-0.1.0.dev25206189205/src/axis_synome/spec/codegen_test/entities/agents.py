from dataclasses import dataclass, field


@dataclass
class SampleAgent:
    name: str
    proxy: str | None = None
    output_tokens: set[str] = field(default_factory=set)
    networks: set[str] = field(default_factory=set)


DEFAULT_SAMPLE_AGENT = SampleAgent(name="default")
