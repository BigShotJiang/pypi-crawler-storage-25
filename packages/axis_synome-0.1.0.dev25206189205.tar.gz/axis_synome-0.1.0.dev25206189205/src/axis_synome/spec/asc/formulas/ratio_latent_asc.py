from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.latent_asc import latent_asc
from axis_synome.spec.asc.formulas.resting_asc import resting_asc


def ratio_latent_asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """Latent ASC ratio slack.

    Returns the arithmetic result unconditionally.  A negative value means
    LatentASC exceeds the permitted fraction of total ASC.

    :source_uuid: 5e300cdb-b221-4b6f-9c4a-11502133a1f9
    """
    agent = prime.value
    latent_usd: float = latent_asc(prime, positions)
    total_usd: float = resting_asc(positions) + latent_usd
    return total_usd * agent.max_pct_latent_asc - latent_usd


def latent_asc_ratio_satisfied(prime: EligiblePrimeAgentASC, positions: list[Position]) -> bool:
    """Boolean latent ASC ratio compliance predicate. True iff ratio_latent_asc >= 0.

    :source_uuid: 5e300cdb-b221-4b6f-9c4a-11502133a1f9
    """
    return ratio_latent_asc(prime, positions) >= 0.0
