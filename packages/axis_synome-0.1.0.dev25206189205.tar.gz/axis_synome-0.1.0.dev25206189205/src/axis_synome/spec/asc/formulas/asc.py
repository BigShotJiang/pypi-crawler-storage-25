from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.latent_asc import latent_asc
from axis_synome.spec.asc.formulas.resting_asc import resting_asc


def asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """
    Total Actively Stabilizing Capital for a prime.

    :source_uuid: 62495dee-8d2a-45d4-87c4-01150e3db3c8
    """
    resting_asc_usd: float = resting_asc(positions)
    latent_asc_usd: float = latent_asc(prime, positions)
    return resting_asc_usd + latent_asc_usd
