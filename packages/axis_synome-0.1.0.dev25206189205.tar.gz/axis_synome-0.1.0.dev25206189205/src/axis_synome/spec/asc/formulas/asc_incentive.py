from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.latent_asc import latent_asc
from axis_synome.spec.asc.formulas.resting_asc import resting_asc

# base_float and treasury_bill_rate are both expressed as params.


def asc_incentive(
    prime: EligiblePrimeAgentASC,
    positions: list[Position],
    base_rate: float,
    treasury_bill_rate: float,
) -> float:
    """ASC incentive payment: eligible ASC times (base_rate - treasury_bill_rate).

    :source_uuid: 693330d6-9072-4054-bd61-d788537e34e8
    """
    eligible_asc_usd: float = resting_asc(positions) + latent_asc(prime, positions)
    return eligible_asc_usd * (base_rate - treasury_bill_rate)
