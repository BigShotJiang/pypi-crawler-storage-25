from typing import Final

from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.types import Position
from axis_synome.spec.asc.formulas.latent_asc import latent_asc
from axis_synome.spec.asc.formulas.resting_asc import resting_asc

DAB_REQUIRED_PCT: Final[float] = 0.25
"""Required DAB as a fraction of total ASC.

:source_uuid: 1e129119-a2ce-4978-b235-c50f2a1c5e2e
"""


def dab_required(
    prime: EligiblePrimeAgentASC,
    positions: list[Position],
) -> float:
    """Required DAB: DAB_REQUIRED_PCT of ASC.

    :source_uuid: 1e129119-a2ce-4978-b235-c50f2a1c5e2e
    """
    asc_usd = resting_asc(positions) + latent_asc(prime, positions)
    return asc_usd * DAB_REQUIRED_PCT
