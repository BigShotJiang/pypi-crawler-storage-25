from axis_synome.spec.asc.entities.primes import EligiblePrimeAgentASC
from axis_synome.spec.asc.entities.protocol_sets import LENDING_PROTOCOLS, POOL_PROTOCOLS
from axis_synome.spec.asc.entities.tokens import CASH_STABLECOINS
from axis_synome.spec.asc.entities.types import Position


def latent_asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """Latent ASC for a prime: which is the stabilizing capital not immediately liquid.

    Includes:
    - Cash stablecoins in Curve/Uniswap pools NOT paired with USDS
    - Cash stablecoins in lending protocols (SparkLend, Aave, Morpho)
    - Cash stablecoins in the prime's ALM proxy

    Pool positions paired with USDS are excluded (those contribute to
    RestingASC).

    :source_uuid: 35ce6b38-9fc1-456e-93da-10ab1468a8bf
    """
    agent = prime.value
    return sum(
        p.value_usd
        for p in positions
        if p.asset.underlying_asset in CASH_STABLECOINS
        and (
            (p.asset.protocol in POOL_PROTOCOLS and not p.pool_paired_with_usds)
            or p.asset.protocol in LENDING_PROTOCOLS
            or (agent.alm_proxy and p.asset.protocol == agent.alm_proxy)
        )
    )
